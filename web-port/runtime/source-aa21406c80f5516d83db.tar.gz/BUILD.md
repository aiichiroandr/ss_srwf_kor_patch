# Mobile web runtime source snapshot

Runtime 0129dbf47402596f6a53, mobile-core-v2. Based on the deployed desktop source
3c1c72226a61ee8d7631. Includes generated translation units, runtime,
third-party sources/notices and build adapters. No ROM, BIOS or extracted binary
game data is included. Execution requires the user's own supported disc image.
Desktop remains on the previous immutable runtime.

With Emscripten 6.0.13, CMake and Ninja available:

```sh
emcmake cmake -S generated -B out -G Ninja -DCMAKE_PROJECT_INCLUDE_BEFORE="$PWD/tools/web-toolchain.cmake" -DSATURN_EXTRA="$PWD/tools/web-target.cmake" -DSATURN_NO_SDL=ON -DSATURN_VDP1_GPL=ON -DCMAKE_BUILD_TYPE=Release
cmake --build out --target saturn --parallel 4
python3 tools/optimize-frame-copy.py out/saturn.js
```

The deterministic JS post-link step snapshots the memory view once per
synchronous frame copy, as in the desktop runtime. The mobile-only C++ changes
add a read-only VDP1 row view and sparse normal-background composition paths.
Two or more active backgrounds retain the fixed original layer traversal.
Game and sound clocks, audio generation, resolution and frame cadence are
unchanged. No audio DSP/slot skipping or profiling build option is enabled.

170 native runtime tests passed. VDP2 tests compare every pixel with the prior
compositor, including 96 additional layer-mask/priority/gradation fixtures.
This is not physical-phone performance or listening validation.

See LICENSE and THIRD_PARTY.md for component notices, including GPL v2 or later
VDP1 code. This snapshot does not grant rights to the original game assets.

Mobile v4 adds a deterministic mobile-only JavaScript post-link step:

```sh
python3 tools/pause-mobile-clock.py out/saturn.js
```

The worker accumulates time spent waiting at the mobile pause gate in
Module.srwPauseOffset. Native monotonic time excludes that wait, preventing
short-pause catch-up. WASM and desktop artifacts are unchanged.

Mobile v5 additionally changes only runtime/src/host/host_web.cpp:
256-frame PCM packets and mobile host deadline/composition callbacks.
The browser worker supplies Module.srwMobileTiming from the accompanying
web-port/mobile-timing.mjs. Without that adapter, presentation and pacing
retain their previous decisions. No game translation, sound chip or raster
timing implementation is changed. Native tests above describe the v2 baseline;
v5 validation uses host-controller tests and browser initialization checks.

Mobile v7 replaces integrated phase corrections with queue-depth wait planning and reports requested/actual sleep and non-sleep elapsed time through the accompanying mobile-timing.mjs adapter. Without an adapter, native wall-clock pacing is retained. No game or sound-chip translation changes.
