// Browser worker host. Disc I/O stays in WORKERFS; only frames and audio leave it.
#include "saturn.h"
#include "host.h"
#include "sound.h"
#include <emscripten.h>
#include <chrono>
#include <thread>
#include <vector>

EM_JS(void, web_frame, (const uint32_t* pixels, int w, int h, double frame), {
    const rgba = new Uint8ClampedArray(w * h * 4);
    for (let i = 0; i < w * h; ++i) {
        const p = HEAPU32[(pixels >>> 2) + i];
        rgba[i*4] = (p >>> 16) & 255;
        rgba[i*4+1] = (p >>> 8) & 255;
        rgba[i*4+2] = p & 255;
        rgba[i*4+3] = 255;
    }
    postMessage({type:"frame", w, h, frame, rgba}, [rgba.buffer]);
});
EM_JS(int, web_pad, (), {
    return Module.srwPad ? Atomics.load(Module.srwPad, 0) : 0;
});
EM_JS(int, web_fast, (), {
    return Module.srwPad ? Atomics.load(Module.srwPad, 1) : 0;
});
EM_JS(void, web_audio, (const int16_t* lr, int frames), {
    const samples = HEAP16.slice(lr >>> 1, (lr >>> 1) + frames*2);
    postMessage({type:"audio", samples}, [samples.buffer]);
});
#ifdef SRWF_FINAL_UI
#include "final-intermission.h"
static final_ui::Navigation menu_navigation;
EM_JS(int, web_menu_request, (), {
    return Module.srwPad && Module.srwPad.length >= 4 ? Atomics.exchange(Module.srwPad,2,0) : 0;
});
EM_JS(int, web_menu_epoch, (), {
    return Module.srwPad && Module.srwPad.length >= 4 ? Atomics.load(Module.srwPad,3) : 0;
});
EM_JS(void, web_menu_state, (int active, int cursor, int epoch, int busy, int funds, int turns), {
    const key = [active,cursor,epoch,busy,funds,turns].join(":");
    if (Module.menuStateKey === key) return;
    Module.menuStateKey = key;
    postMessage({type:"intermission", active:!!active, cursor, epoch, busy:!!busy, funds, turns});
});
static void menu_tick() {
    const auto state = final_ui::snapshot([](uint32_t a){return ld8(a);}, [](uint32_t a){return ld32(a);});
    const int request = web_menu_request();
    menu_navigation.tick(state,sat_vblanks(),request,web_menu_epoch());
    web_menu_state(state.active,state.cursor,menu_navigation.epoch,menu_navigation.busy,
        (ld8(0x0020000a)<<16)|(ld8(0x0020000b)<<8)|ld8(0x0020000c), ld16(0x0020000e));
}
#endif
bool host_launch(SaturnConfig&) { return false; }
bool host_open() { return true; }
EM_JS(int, web_mobile_frame, (double frame, int fast), {
    return Module.srwMobileTiming ? Module.srwMobileTiming.wantsFrame(frame, !!fast) : (!fast || frame % 2 === 0);
});
EM_JS(double, web_mobile_pace, (), {
    return Module.srwMobileTiming && Module.srwMobileTiming.planWait ? Module.srwMobileTiming.planWait() : -1;
});
EM_JS(void, web_mobile_pace_report, (double requested, double actual, double non_sleep), {
    if(Module.srwMobileTiming && Module.srwMobileTiming.recordPace)
        Module.srwMobileTiming.recordPace(requested,actual,non_sleep);
});
bool host_wants_frame() { return web_mobile_frame(double(sat_vblanks()), web_fast()); }
void host_present(const Frame& f) {
    web_frame(f.px.data(), f.w, f.h, double(sat_vblanks()));
}
void host_pace(uint64_t now) {
#ifdef SRWF_FINAL_UI
    menu_tick();
#endif
    static double base = emscripten_get_now();
    const double target = double(now)/1e6;
    static double virtual_base = target;
    static int previous_speed = 1;
    const int speed = web_fast() ? 2 : 1;
    sound_set_game_speed(speed);
    const double wall = emscripten_get_now();
    if (speed != previous_speed) {
        base = wall;
        virtual_base = target;
        previous_speed = speed;
    }
    static double previous_end = wall;
    const double non_sleep = wall - previous_end;
    double delay = base + (target - virtual_base) / speed - wall;
    const double mobile_delay = web_mobile_pace();
    if (mobile_delay >= 0) {
        // Audio depth is the deadline: no cumulative phase correction or
        // inherited wait can survive a depleted queue.
        delay = mobile_delay;
        base = wall;
        virtual_base = target;
    }
    if (delay > 0) std::this_thread::sleep_for(std::chrono::microseconds(int64_t(delay*1000)));
    else if (delay < -250) { base = wall; virtual_base = target; }
    previous_end = emscripten_get_now();
    if (mobile_delay >= 0) web_mobile_pace_report(delay, previous_end - wall, non_sleep);
}
uint16_t host_pad(int slot) {
    if (slot != 0) return 0;
#ifdef SRWF_FINAL_UI
    if (menu_navigation.busy) return menu_navigation.pad;
#endif
    return uint16_t(web_pad());
}
bool host_pad_connected(int slot) { return slot == 0; }
bool host_audio_open() { return true; }
// PCM is already generated at the independent audio-domain rate.
void host_audio_push(const int16_t* lr, int frames) {
    // Device polls can generate only a handful of samples. One Web Audio source
    // per poll overwhelms the browser; mobile sends bounded ~5.8 ms packets.
    static std::vector<int16_t> pending;
    pending.insert(pending.end(), lr, lr + frames * 2);
    size_t used = 0;
    while (pending.size() - used >= 512) {
        web_audio(pending.data() + used, 256);
        used += 512;
    }
    if (used) pending.erase(pending.begin(), pending.begin() + used);
}
void host_audio_report() {}
