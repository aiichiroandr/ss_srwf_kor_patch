#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace mobile_profile {
inline constexpr unsigned slot_count = 5;
inline constexpr unsigned histogram_bins = 96;

constexpr std::array<double, histogram_bins> make_bounds() {
    std::array<double, histogram_bins> result{};
    double value = 0.001;
    for (unsigned i = 0; i < histogram_bins; ++i) {
        result[i] = value;
        value *= 1.189207115002721;
    }
    return result;
}

inline constexpr auto bounds = make_bounds();

struct Distribution {
    double total = 0;
    double maximum = 0;
    uint32_t count = 0;
    std::array<uint32_t, histogram_bins + 1> histogram{};

    void add(double ms) {
        ms = std::max(0.0, ms);
        total += ms;
        maximum = std::max(maximum, ms);
        ++count;
        const auto bin = std::lower_bound(bounds.begin(), bounds.end(), ms) - bounds.begin();
        ++histogram[bin];
    }

    double percentile_upper(double fraction) const {
        if (!count) return 0;
        const uint32_t rank = std::max(1u, uint32_t(std::ceil(fraction * count)));
        uint32_t cumulative = 0;
        for (unsigned i = 0; i < histogram.size(); ++i) {
            cumulative += histogram[i];
            if (cumulative >= rank) return i < histogram_bins ? std::min(bounds[i], maximum) : maximum;
        }
        return maximum;
    }
};
}
