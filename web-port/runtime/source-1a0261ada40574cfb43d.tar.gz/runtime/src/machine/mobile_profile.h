#pragma once
#if defined(__EMSCRIPTEN__) && defined(SRWF_MOBILE_PROFILE)
#include <emscripten.h>
#include "mobile_profile_stats.h"
namespace mobile_profile {
inline Distribution inclusive[slot_count], exclusive[slot_count];
inline double window_start_ms = -1;
inline unsigned window_start_frame = 0, window_id = 0, speed_mask = 0;
inline bool partial_window = true;
struct Scope;
inline Scope* current = nullptr;

struct Scope {
    int slot;
    double start;
    double children = 0;
    Scope* parent;

    explicit Scope(int s) : slot(s), start(emscripten_get_now()), parent(current) {
        if (window_start_ms < 0) window_start_ms = start;
        current = this;
    }

    ~Scope() {
        const double elapsed = std::max(0.0, emscripten_get_now() - start);
        inclusive[slot].add(elapsed);
        exclusive[slot].add(std::max(0.0, elapsed - children));
        if (parent) parent->children += elapsed;
        current = parent;
    }
};

inline void report(unsigned frame, int speed = 1) {
    speed_mask |= speed == 2 ? 2u : 1u;
    if (window_start_ms < 0) window_start_ms = emscripten_get_now();
    if (frame < window_start_frame) {
        for (unsigned i = 0; i < slot_count; ++i) inclusive[i] = exclusive[i] = {};
        window_start_frame = frame;
        window_start_ms = emscripten_get_now();
        speed_mask = speed == 2 ? 2u : 1u;
        partial_window = true;
        return;
    }
    if (frame - window_start_frame < 120) return;
    const double now = emscripten_get_now();
    double values[slot_count * 12]{};
    for (unsigned i = 0; i < slot_count; ++i) {
        const Distribution* distributions[2] = {&inclusive[i], &exclusive[i]};
        for (unsigned j = 0; j < 2; ++j) {
            const auto& d = *distributions[j];
            const unsigned at = i * 12 + j * 6;
            values[at] = d.total;
            values[at + 1] = d.count;
            values[at + 2] = d.percentile_upper(0.50);
            values[at + 3] = d.percentile_upper(0.95);
            values[at + 4] = d.percentile_upper(0.99);
            values[at + 5] = d.maximum;
        }
    }
    EM_ASM({ (() => {
        const names = ['sound', 'draw', 'compose', 'interpolate', 'sleep'];
        const stats = {};
        const fields = ['totalMs', 'count', 'p50UpperMs', 'p95UpperMs', 'p99UpperMs', 'maxMs'];
        const base = $0 >>> 3;
        for (let slot = 0; slot < names.length; ++slot) {
            const result = {};
            for (let kind = 0; kind < 2; ++kind) {
                const distribution = {};
                for (let field = 0; field < fields.length; ++field) {
                    distribution[fields[field]] = HEAPF64[base + slot * 12 + kind * 6 + field];
                }
                result[kind === 0 ? 'inclusive' : 'exclusive'] = distribution;
            }
            stats[names[slot]] = result;
        }
        const result = {
            type: 'core-profile', schema: 2, windowId: $1,
            windowStartFrame: $2, frame: $3, windowStartMs: $4,
            windowEndMs: $5, wallMs: $5 - $4, speedMask: $6,
            partialWindow: !!$7, quantileMode: 'histogram-upper-bound', stats
        };
        for (const name of names) {
            result[name + 'Ms'] = stats[name].inclusive.totalMs;
            result[name + 'Calls'] = stats[name].inclusive.count;
            result[name + 'Peak'] = stats[name].inclusive.maxMs;
        }
        postMessage(result);
    })(); }, values, ++window_id, window_start_frame, frame, window_start_ms, now, speed_mask, int(partial_window));
    window_start_frame = frame;
    window_start_ms = now;
    speed_mask = 0;
    partial_window = false;
    for (unsigned i = 0; i < slot_count; ++i) inclusive[i] = exclusive[i] = {};
}
}
#else
namespace mobile_profile {
struct Scope { explicit Scope(int) {} };
inline void report(unsigned, int = 1) {}
}
#endif
