from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
old='var _emscripten_get_now=()=>performance.timeOrigin+performance.now();'
new='var _emscripten_get_now=()=>performance.timeOrigin+performance.now()-(Module.srwPauseOffset||0);'
assert s.count(old)==1, 'Unexpected Emscripten clock; refuse patch'
p.write_text(s.replace(old,new))
