#include "saturn.h"
#include "test.h"
#include <vector>

namespace {
constexpr uint32_t BASE = 0x060E0000, PROGRAM = 0x060E1000;
void library_call(SH2Context& c) { ++c.r[0]; c.pc = c.pr; }
const SH2FuncEntry library_entries[] = {{BASE, library_call}};
const SH2FuncEntry program_entries[] = {{PROGRAM, library_call}};
struct SavedDispatch {
    std::vector<const SH2Module*> active;
    uint8_t memory[0x1040];
    SavedDispatch() {
        std::memcpy(memory, g_wram_h + 0xE0000, sizeof(memory));
        for (int i = 0; i < sh2_active_slots(); ++i) {
            active.push_back(sh2_active_slot(i));
            sh2_set_active_slot(i, nullptr);
        }
    }
    ~SavedDispatch() {
        for (int i = 0; i < sh2_active_slots(); ++i) sh2_set_active_slot(i, active[i]);
        std::memcpy(g_wram_h + 0xE0000, memory, sizeof(memory));
    }
};
void image(uint32_t address, uint8_t value) {
    for (uint32_t i = 0; i < 64; ++i) st8(address + i, value);
}
bool starts_program(SH2Context& c, uint32_t address) {
    try { sh2_call(c, address); }
    catch (...) { return true; }  // ProgramStart is private to the machine.
    return false;
}
}

// Registered only in the standalone runtime tests; CRCs are for 64 equal bytes.
extern const SH2Module test_callable_module{
    "test-resident", BASE, 64, 0x8209EA3B, library_entries, 1, nullptr, nullptr, true};
extern const SH2Module test_replacement_module{
    "test-replacement", BASE, 64, 0x41F5776D, library_entries, 1, nullptr, nullptr, false};
extern const SH2Module test_program_module{
    "test-program", PROGRAM, 64, 0xB671FE60, program_entries, 1, nullptr, nullptr, false};

TEST(active_callable_entry_keeps_its_caller_after_resident_data_changes) {
    SavedDispatch restore;
    image(BASE, 0x11);
    sh2_activate(&test_callable_module);
    SH2Context c{};
    c.pr = 0x06068992;
    CHECK_EQ(starts_program(c, BASE), false);
    CHECK_EQ(c.r[0], 1);
    st8(BASE + 63, 0x7F);  // ON/OFF or another mutable resident setting.
    CHECK_EQ(sh2_identify(BASE), nullptr);
    CHECK_EQ(starts_program(c, BASE), false);
    CHECK_EQ(c.r[0], 2);
    CHECK_EQ(c.pc, c.pr);
    CHECK_EQ(starts_program(c, BASE | 0x20000000), false);
    CHECK_EQ(c.r[0], 3);
}

TEST(new_program_image_still_replaces_an_active_callable_entry) {
    SavedDispatch restore;
    image(BASE, 0x11);
    sh2_activate(&test_callable_module);
    image(BASE, 0x22);
    CHECK_EQ(sh2_identify(BASE), &test_replacement_module);
    SH2Context c{};
    CHECK_EQ(starts_program(c, BASE), true);
    CHECK_EQ(c.r[0], 0);
}

TEST(non_callable_program_base_still_starts_after_its_data_changes) {
    SavedDispatch restore;
    image(PROGRAM, 0x33);
    sh2_activate(&test_program_module);
    st8(PROGRAM + 63, 0x7F);
    SH2Context c{};
    CHECK_EQ(starts_program(c, PROGRAM), true);
    CHECK_EQ(c.r[0], 0);
}

namespace {
void replacement_call(SH2Context& c) { c.r[0] += 17; }
const SH2FuncEntry changed_entries[] = {{BASE, replacement_call}};
const SH2Module changed_module{"changed", BASE, 64, 0, changed_entries, 1, nullptr, nullptr, false};
}
TEST(dispatch_cached_overlay_is_invalidated_by_activation_and_restore) {
    SavedDispatch restore;
    sh2_activate(&test_callable_module);
    CHECK_EQ(sh2_lookup(BASE), library_call);
    CHECK_EQ(sh2_lookup(BASE | 0x20000000u), library_call);
    sh2_activate(&changed_module);
    CHECK_EQ(sh2_lookup(BASE), replacement_call);
    sh2_set_active_slot(0, &test_callable_module);
    CHECK_EQ(sh2_lookup(BASE), library_call);
    sh2_set_active_slot(0, nullptr);
    CHECK_EQ(sh2_lookup(BASE), nullptr);
    sh2_activate(&changed_module);
    CHECK_EQ(sh2_lookup(BASE), replacement_call);
    CHECK_EQ(sh2_lookup(BASE + 2), nullptr);
}
TEST(dispatch_cache_collisions_preserve_full_address_and_slot_precedence) {
    SavedDispatch restore;
    // Same direct-mapped index: both address shifts toggle the same bit.
    constexpr uint32_t OTHER = BASE ^ 0x2002u;
    const SH2FuncEntry entries[] = {{BASE,library_call},{OTHER,replacement_call}};
    const SH2Module module{"collision",BASE,0x2040,0,entries,2,nullptr,nullptr,false};
    sh2_activate(&module);
    for (int i=0;i<100;++i) {
        CHECK_EQ(sh2_lookup(BASE),library_call);
        CHECK_EQ(sh2_lookup(OTHER),replacement_call);
        CHECK_EQ(sh2_lookup(OTHER | 0x20000000u),replacement_call);
    }
    sh2_set_active_slot(1,&changed_module);
    CHECK_EQ(sh2_lookup(BASE),library_call); // earliest matching slot wins
    sh2_set_active_slot(0,nullptr);
    CHECK_EQ(sh2_lookup(BASE),replacement_call);
    CHECK_EQ(sh2_lookup(OTHER),nullptr);
}
