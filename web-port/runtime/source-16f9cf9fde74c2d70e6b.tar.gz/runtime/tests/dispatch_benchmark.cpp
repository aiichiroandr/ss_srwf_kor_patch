#include "saturn.h"
#include <chrono>
#include <cstdio>
#include <vector>
static void target(SH2Context&) {}
__attribute__((noinline)) static SH2Func reference(uint32_t addr) {
 if(addr>>29==1)addr&=0x1fffffffu;
 for(int i=0;i<sh2_active_slots();++i){
  auto m=sh2_active_slot(i);if(!m||addr-m->base>=m->size)continue;
  uint32_t lo=0,hi=m->nfuncs;
  while(lo<hi){auto mid=(lo+hi)/2;if(m->funcs[mid].addr<addr)lo=mid+1;else hi=mid;}
  if(lo<m->nfuncs&&m->funcs[lo].addr==addr)return m->funcs[lo].fn;
 }return nullptr;
}
int main(){
 std::vector<SH2FuncEntry> entries;for(unsigned i=0;i<8192;++i)entries.push_back({0x06004000+i*32,target});
 SH2Module m{"benchmark",0x06004000,8192*32,0,entries.data(),(uint32_t)entries.size(),nullptr,nullptr,false};
 sh2_activate(&m); double ms[2]{}; volatile uintptr_t checksum=0;
 for(int round=0;round<6;++round)for(int j=0;j<2;++j){int which=(round+j)&1;auto t=std::chrono::steady_clock::now();
  for(unsigned i=0;i<2000000;++i){unsigned a=entries[(i*73)%127].addr;auto f=which?sh2_lookup(a):reference(a);checksum=checksum^(uintptr_t)f;}
  ms[which]+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count();
 }
 std::printf("{\"referenceMs\":%.3f,\"cachedMs\":%.3f,\"reductionPercent\":%.2f,\"checksum\":%llu}\n",ms[0],ms[1],100*(1-ms[1]/ms[0]),(unsigned long long)checksum);
}
