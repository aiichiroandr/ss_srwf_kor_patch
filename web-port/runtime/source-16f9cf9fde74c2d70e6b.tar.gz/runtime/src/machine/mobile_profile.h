#pragma once
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
namespace mobile_profile {
inline double ms[5]={},peak[5]={};inline unsigned calls[5]={};
struct Scope {int slot;double start;Scope(int s):slot(s),start(emscripten_get_now()){} ~Scope(){double d=emscripten_get_now()-start;ms[slot]+=d;if(d>peak[slot])peak[slot]=d;++calls[slot];}};
inline void report(unsigned frame){
 static double last=emscripten_get_now();static unsigned prior=0;
 if(frame-prior<120)return;
 double now=emscripten_get_now();
 EM_ASM({postMessage({type:'core-profile',frame:$0,wallMs:$1,soundMs:$2,drawMs:$3,composeMs:$4,interpolateMs:$5,sleepMs:$6,soundCalls:$7,drawCalls:$8,composeCalls:$9,interpolateCalls:$10,soundPeak:$11,drawPeak:$12,composePeak:$13});},frame,now-last,ms[0],ms[1],ms[2],ms[3],ms[4],calls[0],calls[1],calls[2],calls[3],peak[0],peak[1],peak[2]);
 last=now;prior=frame;for(int i=0;i<5;i++){ms[i]=peak[i]=0;calls[i]=0;}
}
}
#else
namespace mobile_profile {struct Scope {Scope(int){}};inline void report(unsigned){}}
#endif
