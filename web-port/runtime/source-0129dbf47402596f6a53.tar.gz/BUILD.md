# Mobile web runtime source snapshot

Runtime 0129dbf47402596f6a53, mobile-core-v2. Based on the deployed desktop source
3c1c72226a61ee8d7631. Includes generated translation units, runtime,
third-party sources/notices and build adapters. No ROM, BIOS or extracted binary
game data is included. Execution requires the user's own supported disc image.
Desktop remains on the previous immutable runtime.

With Emscripten 6.0.13, CMake and Ninja available:

```sh
emcmake cmake -S generated -B out -G Ninja -DCMAKE_PROJECT_INCLUDE_BEFORE="$PWD/tools/web-toolchain.cmake" -DSATURN_EXTRA="$PWD/tools/web-target.cmake" -DSATURN_NO_SDL=ON -DSATURN_VDP1_GPL=ON -DCMAKE_BUILD_TYPE=Release
cmake --build out --target saturn --parallel 4
python3 tools/optimize-frame-copy.py out/saturn.js
```

The deterministic JS post-link step snapshots the memory view once per
synchronous frame copy, as in the desktop runtime. The mobile-only C++ changes
add a read-only VDP1 row view and sparse normal-background composition paths.
Two or more active backgrounds retain the fixed original layer traversal.
Game and sound clocks, audio generation, resolution and frame cadence are
unchanged. No audio DSP/slot skipping or profiling build option is enabled.

170 native runtime tests passed. VDP2 tests compare every pixel with the prior
compositor, including 96 additional layer-mask/priority/gradation fixtures.
This is not physical-phone performance or listening validation.

See LICENSE and THIRD_PARTY.md for component notices, including GPL v2 or later
VDP1 code. This snapshot does not grant rights to the original game assets.
