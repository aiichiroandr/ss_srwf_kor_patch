# Deterministic post-link optimization; Wasm and all other glue stay unchanged.
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
before='for(let i=0;i<w*h;++i){const p=(growMemViews(),HEAPU32)[(pixels>>>2)+i];'
after='const pixelHeap=(growMemViews(),HEAPU32);for(let i=0;i<w*h;++i){const p=pixelHeap[(pixels>>>2)+i];'
assert s.count(before)==1, 'Expected one frame copier'
p.write_text(s.replace(before,after))
