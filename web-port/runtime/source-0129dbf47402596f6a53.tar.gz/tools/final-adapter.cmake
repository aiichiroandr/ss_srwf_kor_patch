target_sources(saturn PRIVATE "${CMAKE_CURRENT_LIST_DIR}/final-installer-adapter.cpp")
