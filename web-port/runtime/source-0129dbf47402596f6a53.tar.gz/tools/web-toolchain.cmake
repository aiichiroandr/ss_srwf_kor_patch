# Load before project() so every generated and runtime object uses the same ABI.
# Keep the native build directory and its compiler settings separate.
set(CMAKE_C_FLAGS_INIT "-pthread -fwasm-exceptions")
set(CMAKE_CXX_FLAGS_INIT "-pthread -fwasm-exceptions")
set(CMAKE_EXE_LINKER_FLAGS_INIT "-pthread -fwasm-exceptions -sPTHREAD_POOL_SIZE=3 -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=134217728 -sSTACK_SIZE=8388608 -sASYNCIFY=1")
