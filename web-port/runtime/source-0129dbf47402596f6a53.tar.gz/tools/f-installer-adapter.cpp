#include "saturn.h"
#include "f-installer-check.h"
namespace {
void installed(SH2Context&, uint32_t) {
    verify_f_installer();
    sh2_activate(sh2_module("SRWF_INSTALLED"));
    sh2_activate(sh2_module("F_LOW"));
    sat_note("F Korean installer verified; installed code active");
}
struct Register { Register() { sh2_hook_add(0x0028E6F4u, installed); } } registration;
}
