// Validate the original installer output, then select its statically recompiled image.
#include "saturn.h"
namespace {
void installed(SH2Context&, uint32_t) {
    if (ld32(0x06004900u) != 0xd001402bu) sat_fatal("Korean installer hook verification failed at 06004900");
    if (ld32(0x06004904u) != 0x00090009u) sat_fatal("Korean installer hook verification failed at 06004904");
    if (ld32(0x06004908u) != 0x060db600u) sat_fatal("Korean installer hook verification failed at 06004908");
    if (ld32(0x06004b14u) != 0xd001402bu) sat_fatal("Korean installer hook verification failed at 06004B14");
    if (ld32(0x06004b18u) != 0x00090009u) sat_fatal("Korean installer hook verification failed at 06004B18");
    if (ld32(0x06004b1cu) != 0x060db400u) sat_fatal("Korean installer hook verification failed at 06004B1C");
    if (ld32(0x06017578u) != 0x060dad4au) sat_fatal("Korean installer hook verification failed at 06017578");
    if (ld32(0x06018c7cu) != 0xd101412bu) sat_fatal("Korean installer hook verification failed at 06018C7C");
    if (ld32(0x06018c80u) != 0x00093130u) sat_fatal("Korean installer hook verification failed at 06018C80");
    if (ld32(0x06018c84u) != 0x060da9f0u) sat_fatal("Korean installer hook verification failed at 06018C84");
    if (ld32(0x0606ee88u) != 0xd001402bu) sat_fatal("Korean installer hook verification failed at 0606EE88");
    if (ld32(0x0606ee8cu) != 0x00090009u) sat_fatal("Korean installer hook verification failed at 0606EE8C");
    if (ld32(0x0606ee90u) != 0x060db000u) sat_fatal("Korean installer hook verification failed at 0606EE90");
    if (ld32(0x0606f350u) != 0xe612410bu) sat_fatal("Korean installer hook verification failed at 0606F350");
    if (ld32(0x0606f3c0u) != 0xe606e513u) sat_fatal("Korean installer hook verification failed at 0606F3C0");
    if (ld32(0x060ae368u) != 0xd301432bu) sat_fatal("Korean installer hook verification failed at 060AE368");
    if (ld32(0x060ae36cu) != 0x00090009u) sat_fatal("Korean installer hook verification failed at 060AE36C");
    if (ld32(0x060ae370u) != 0x060db300u) sat_fatal("Korean installer hook verification failed at 060AE370");
    if (ld32(0x060b8c68u) != 0x060dad12u) sat_fatal("Korean installer hook verification failed at 060B8C68");
    if (ld32(0x060b8c8cu) != 0x060dad34u) sat_fatal("Korean installer hook verification failed at 060B8C8C");
    if (ld32(0x060bbb80u) != 0x060db800u) sat_fatal("Korean installer hook verification failed at 060BBB80");
    if (ld32(0x060bbb84u) != 0x260da006u) sat_fatal("Korean installer hook verification failed at 060BBB84");
    if (ld32(0x060bbc78u) != 0x260d9fe6u) sat_fatal("Korean installer hook verification failed at 060BBC78");
    const SH2Module* resident = sh2_module("FIN_RESIDENT");
    if (!resident || sh2_identify(resident->base) != resident)
        sat_fatal("Korean resident copy does not match the compiled image");
    sh2_activate(sh2_module("SRWFIN_INSTALLED"));
    sh2_activate(resident);
    sat_note("Korean installer verified; installed code active");
}
struct Register { Register() { sh2_hook_add(0x0028BFE8u, installed); } } registration;
}
