target_sources(saturn PRIVATE "${CMAKE_CURRENT_LIST_DIR}/f-installer-adapter.cpp")
target_include_directories(saturn PRIVATE "${CMAKE_CURRENT_LIST_DIR}/../build/inputs")
