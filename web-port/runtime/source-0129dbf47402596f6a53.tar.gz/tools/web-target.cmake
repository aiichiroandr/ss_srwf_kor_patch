set_target_properties(saturn PROPERTIES SUFFIX ".js")
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/p_fin_installer_funcs.h")
  include("${CMAKE_CURRENT_LIST_DIR}/final-adapter.cmake")
  target_compile_definitions(saturn_host PRIVATE SRWF_FINAL_UI=1)
  target_include_directories(saturn_host PRIVATE "${CMAKE_CURRENT_LIST_DIR}")
endif()
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/p_f_installer_funcs.h")
  include("${CMAKE_CURRENT_LIST_DIR}/f-adapter.cmake")
endif()
target_link_options(saturn PRIVATE
    "-sMODULARIZE=1" "-sEXPORT_NAME=createSaturn"
    "-sEXPORTED_RUNTIME_METHODS=FS,WORKERFS,callMain"
    "-sFORCE_FILESYSTEM=1" "-lworkerfs.js"
    "-sEXIT_RUNTIME=1")
