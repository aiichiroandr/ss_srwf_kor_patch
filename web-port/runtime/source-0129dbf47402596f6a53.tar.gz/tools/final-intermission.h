#pragma once
#include <cstdint>
// Korean Final v0.3c: script interpreter, active menu descriptor and cursor bank.
// This bridge reads guest data. Actions use ordinary Saturn controller input only.
namespace final_ui {
struct Snapshot { bool active; unsigned cursor; };
template<class R8, class R32> Snapshot snapshot(R8 byte, R32 word) {
    // Moving the original cursor visits these two script PCs while redrawing.
    // They retain the same root descriptor/bank. Treating them as scene exit
    // cancels our queued A and forces users to click the destination twice.
    const auto script = word(0x060c6d70) & 0x1fffffff;
    const bool root = script == 0x0022379e || script == 0x0022383e || script == 0x00223748;
    const bool active = root
        && (word(0x060c9820) & 0x1fffffff) == 0x002557b3
        && byte(0x060c9560) == 25 && byte(0x060c95f9) < 8
        && word(0x002557b3) == 0x42a54a02;
    return {active, unsigned(byte(0x060c95f9))};
}
struct Navigation {
    unsigned epoch = 0;
    bool active = false, busy = false;
    int target = -1;
    uint16_t pad = 0;
    uint64_t until = 0, deadline = 0;
    uint64_t cursor_ready = 0;
    unsigned observed_cursor = 0;
    bool confirming = false;
    void tick(Snapshot state, uint64_t frame, int request = 0, unsigned request_epoch = 0) {
        if (state.active != active) {
            active = state.active;
            ++epoch;
            busy = false; target = -1; pad = 0; confirming = false;
            observed_cursor = state.cursor; cursor_ready = frame + 24;
        }
        if (!active) return;
        if (state.cursor != observed_cursor) {
            observed_cursor = state.cursor;
            cursor_ready = frame + 24;
        }
        if (request >= 1 && request <= 8 && request_epoch == epoch && !busy) {
            target = request - 1; busy = true; confirming = false;
            until = frame + 4; deadline = frame + 360; pad = 0;
        }
        if (!busy) return;
        if (frame >= deadline) { busy = false; target = -1; pad = 0; return; }
        if (frame < until) return;
        // The original redraw consumes input edges while rebuilding its menu.
        // Wait through that redraw before moving again or confirming.
        if (pad) { pad = 0; until = frame + 24; return; }
        if (confirming) return; // One A edge only; never press A inside the destination screen.
        if (frame < cursor_ready) return; // Count readiness from guest acknowledgement, not our pulse.
        if (state.cursor == unsigned(target)) { pad = 0x400; confirming = true; }
        else pad = ((target - int(state.cursor) + 8) % 8 <= 4) ? 0x2000 : 0x1000;
        until = frame + 8;
    }
};
}
