#include "saturn.h"
#include "test.h"

TEST(dmac_burst_copies_all_longwords_and_advances_both_addresses) {
    onchip_reset(0);
    const uint32_t src = 0x06010000, dst = 0x25C10000;
    for (unsigned k = 0; k < 16; ++k) {
        st32(src + k * 4, 0x10203040u + k);
        st32(dst + k * 4, 0);
    }
    st32(dst + 64, 0xDEADBEEF);
    auto write = [](uint32_t a, uint32_t v) { onchip_write(g_master, a, v, 4); };
    write(0xFFFFFF80, src);
    write(0xFFFFFF84, dst);
    write(0xFFFFFF88, 16); // TCR counts longwords, i.e. four 16-byte bursts.
    write(0xFFFFFF8C, 0x5E01); // increment both, burst, auto request, enabled
    write(0xFFFFFFB0, 1);
    for (unsigned k = 0; k < 16; ++k) CHECK_EQ(ld32(dst + k * 4), 0x10203040u + k);
    CHECK_EQ(ld32(dst + 64), 0xDEADBEEF);
    CHECK_EQ(onchip_read(g_master, 0xFFFFFF80, 4), src + 64);
    CHECK_EQ(onchip_read(g_master, 0xFFFFFF84, 4), dst + 64);
    CHECK_EQ(onchip_read(g_master, 0xFFFFFF88, 4), 0);
}

// The expected values are a * b // c in Python's integers.
TEST(mul_div_is_exact_including_products_past_64_bits) {
    CHECK_EQ(sat_mul_div(1000000000ull, 1746818182u, 65000000000ull), 26874125ull);
    CHECK_EQ(sat_mul_div(9223372036854788153ull, 1746818182u, 65000000000ull), 247870061128127969ull);
    CHECK_EQ(sat_mul_div(18446744073709551615ull, 1734687500u, 61000000000ull), 524579284596115374ull);
    CHECK_EQ(sat_mul_div(123456789012345ull, 1746818182u, 61000000000ull), 3535353503903ull);
    CHECK_EQ(sat_mul_div(18446744073709551615ull, 4294967295u, 140737488355327ull), 562949953290243ull);
}

// Mednafen's NTSC master clock is 1 746 818 182 Hz: φ is a 65th of it at 320 dots and a 61st at 352.
TEST(the_on_chip_timers_count_at_320_dots_rate_until_smpc_changes_the_clock) {
    onchip_reset(0);
    CHECK_EQ(onchip_phi_clocks(1000000000ull), 26874125ull);
    smpc_write(0x1F, 0x0E);                     // CKCHG352
    CHECK_EQ(onchip_phi_clocks(1000000000ull), 28636363ull);
    smpc_write(0x1F, 0x0F);                     // CKCHG320
    CHECK_EQ(onchip_phi_clocks(1000000000ull), 26874125ull);
}

// VDP1's cycles become time the other way, at the same two rates.
TEST(phi_clocks_take_their_time_at_320_dots_rate_or_352s) {
    onchip_reset(0);
    CHECK_EQ(onchip_phi_ns(1000), 37210ull);
    CHECK_EQ(onchip_phi_ns(26874125), 999999967ull);
    smpc_write(0x1F, 0x0E);                     // CKCHG352
    CHECK_EQ(onchip_phi_ns(1000), 34920ull);
    smpc_write(0x1F, 0x0F);                     // CKCHG320
    CHECK_EQ(onchip_phi_ns(1000), 37210ull);
}

TEST(division_shadow_result_survives_loading_the_next_dividend) {
    onchip_reset(0);
    auto write = [](uint32_t a, uint32_t v) { onchip_write(g_master, a, v, 4); };
    auto read = [](uint32_t a) { return onchip_read(g_master, a, 4); };
    write(0xFFFFFF00, 7);
    write(0xFFFFFF04, 100);
    CHECK_EQ(read(0xFFFFFF1C), 14);
    CHECK_EQ(read(0xFFFFFF18), 2);
    CHECK_EQ(read(0xFFFFFF3C), 14);
    write(0xFFFFFF10, 1);
    CHECK_EQ(read(0xFFFFFF18), 2);
    write(0xFFFFFF14, 0);
    CHECK_EQ(read(0xFFFFFF1C), 613566756);
    CHECK_EQ(read(0xFFFFFF18), 4);
    write(0xFFFFFF24, (uint32_t)-100);
    CHECK_EQ(read(0xFFFFFF1C), (uint32_t)-14);
    CHECK_EQ(read(0xFFFFFF38), (uint32_t)-2);
}

#include "rate_clock.h"
TEST(audio_clock_preserves_continuity_across_acceleration_and_return) {
    AudioRateClock clock;
    CHECK_EQ(clock.advance(1000000000, 1), 1000000000);
    CHECK_EQ(clock.advance(2000000000, 2), 1500000000);
    CHECK_EQ(clock.advance(3000000000, 1), 2500000000);
    CHECK_EQ(clock.advance(3000000001, 2), 2500000000);
    CHECK_EQ(clock.advance(3000000002, 2), 2500000001);
}
