// What the generated modules.cpp defines for a game, for a build with no game in it.
#include "saturn/sh2.h"

extern const SH2Module test_callable_module, test_replacement_module, test_program_module;
extern const SH2Module* const g_sh2_modules[] = {
    &test_callable_module, &test_replacement_module, &test_program_module
};
extern const int g_sh2_nmodules = 3;
extern const uint32_t g_sh2_tasks[2] = {0, 0};
extern const SH2TaskSwitch g_sh2_task_switches[] = {{0, 0, 0, 0, 0}};
extern const int g_sh2_ntask_switches = 0;
