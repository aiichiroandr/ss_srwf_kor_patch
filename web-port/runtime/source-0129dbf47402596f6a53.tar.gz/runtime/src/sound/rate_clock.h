#pragma once
#include <cstdint>
// Accumulate elapsed time, not absolute_time / speed: switching must not rewind
// music or create a burst of overdue samples. Units are half nanoseconds.
struct AudioRateClock {
    uint64_t machine = 0, half_ns = 0;
    uint64_t advance(uint64_t now, unsigned speed) {
        if (now < machine) { machine = now; half_ns = now * 2; }
        half_ns += (now - machine) * (speed == 2 ? 1 : 2);
        machine = now;
        return half_ns / 2;
    }
};
