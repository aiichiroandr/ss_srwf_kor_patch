#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0606E258(SH2Context& c) {
    ran[1569] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606E258 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606E25A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606E25C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606E25E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606E260 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606E262 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606E264 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606E266 sts.l pr,@-r15
    c.r[15] -= 16;  // 0606E268 add #-16,r15
    c.r[14] = c.r[15];  // 0606E26A mov r15,r14
    c.r[1] = ld32(0x0606E350u);  // 0606E26C mov.l 0x0606E350,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E272u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E272u) return; }  // 0606E26E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606E354u);  // 0606E272 mov.l 0x0606E354,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E278u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E278u) return; }  // 0606E274 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606E358u);  // 0606E278 mov.l 0x0606E358,r1
    c.r[4] = ld32(c.r[1]);  // 0606E27A mov.l @r1,r4
    c.r[1] = ld32(0x0606E35Cu);  // 0606E27C mov.l 0x0606E35C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E282u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E282u) return; }  // 0606E27E jsr @r1 ; nop
    c.r[1] = ld32(0x0606E360u);  // 0606E282 mov.l 0x0606E360,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E288u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E288u) return; }  // 0606E284 jsr @r1 ; nop
    c.r[11] = ld32(0x0606E364u);  // 0606E288 mov.l 0x0606E364,r11
    c.r[10] = ld32(0x0606E368u);  // 0606E28A mov.l 0x0606E368,r10
    c.r[9] = ld32(0x0606E36Cu);  // 0606E28C mov.l 0x0606E36C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0606E28E mov.b @r11,r1
    c.r[5] = 0x0u;  // 0606E290 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0606E292 extu.b r1,r1
    c.r[0] = c.r[1];  // 0606E294 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606E296 mov.b @(r0,r10),r6
    c.r[4] = 0x0u;  // 0606E298 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E29Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E29Eu) return; }  // 0606E29A jsr @r9 ; extu.b r6,r6
    c.r[8] = ld32(0x0606E370u);  // 0606E29E mov.l 0x0606E370,r8
    c.r[1] = ld32(c.r[8]);  // 0606E2A0 mov.l @r8,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606E34Au);  // 0606E2A2 mov.w 0x0606E34A,r12
    c.r[0] = c.r[1];  // 0606E2A4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606E2A6 mov.b @(r0,r12),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606E2A8 extu.b r2,r2
    c.r[2] += 6;  // 0606E2AA add #6,r2
    c.r[1] = ld32(0x0606E374u);  // 0606E2AC mov.l 0x0606E374,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0606E2AE dmuls.l r1,r2
    c.r[5] = 0x0u;  // 0606E2B0 mov #0,r5
    c.r[4] = 0x0u;  // 0606E2B2 mov #0,r4
    c.r[6] = c.mach;  // 0606E2B4 sts mach,r6
    c.r[6] += c.r[2];  // 0606E2B6 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0606E2B8 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0606E2BA shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0606E2BC shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0606E2BE subc r2,r2
    { const uint32_t x = c.r[9]; c.pr = 0x0606E2C4u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E2C4u) return; }  // 0606E2C0 jsr @r9 ; sub r2,r6
    c.r[1] = ld32(c.r[8]);  // 0606E2C4 mov.l @r8,r1
    c.r[0] = c.r[1];  // 0606E2C6 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606E2C8 mov.b @(r0,r12),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0606E2CA mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606E2CC extu.b r1,r1
    c.r[0] = c.r[1];  // 0606E2CE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606E2D0 mov.b @(r0,r10),r1
    c.r[3] = 0x7u;  // 0606E2D2 mov #7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606E2D4 extu.b r1,r1
    c.r[1] -= 1;  // 0606E2D6 add #-1,r1
    c.macl = c.r[1] * c.r[3];  // 0606E2D8 mul.l r3,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0606E2DA extu.b r7,r2
    c.r[1] = c.macl;  // 0606E2DC sts macl,r1
    c.r[2] -= c.r[1];  // 0606E2DE sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0606E2E0 cmp/gt r3,r2
    { const bool k = c.t; c.r[4] = c.r[3]; if (k) { goto L_0606E2EE; } }  // 0606E2E2 bt/s 0x0606E2EE ; mov r3,r4
    c.r[0] = c.r[7];  // 0606E2E6 mov r7,r0
    c.r[0] -= c.r[1];  // 0606E2E8 sub r1,r0
    c.r[1] = c.r[0];  // 0606E2EA mov r0,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0606E2EC extu.b r1,r4
L_0606E2EE:
    c.r[8] = ld32(0x0606E378u);  // 0606E2EE mov.l 0x0606E378,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E2F4u; c.r[13] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E2F4u) return; }  // 0606E2F0 jsr @r8 ; mov r4,r13
    c.r[1] = ld32(0x0606E364u);  // 0606E2F4 mov.l 0x0606E364,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E2F6 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606E2F8 extu.b r1,r0
    c.r[1] = ld32(0x0606E368u);  // 0606E2FA mov.l 0x0606E368,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606E2FC mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 0606E2FE mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606E300 extu.b r1,r1
    c.r[1] -= 1;  // 0606E302 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0606E304 mul.l r2,r1
    c.r[9] = c.macl;  // 0606E306 sts macl,r9
    c.r[1] = c.macl;  // 0606E308 sts macl,r1
    c.r[1] += c.r[13];  // 0606E30A add r13,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0606E30C cmp/ge r1,r9
    if (c.t) { goto L_0606E3F4; }  // 0606E30E bt 0x0606E3F4
    c.r[11] = c.r[8];  // 0606E310 mov r8,r11
    c.r[10] = ld32(0x0606E358u);  // 0606E312 mov.l 0x0606E358,r10
L_0606E314:
    c.r[1] = ld32(0x0606E370u);  // 0606E314 mov.l 0x0606E370,r1
    c.r[2] = ld32(c.r[1]);  // 0606E316 mov.l @r1,r2
    c.r[1] = c.r[9];  // 0606E318 mov r9,r1
    c.r[1] += c.r[1];  // 0606E31A add r1,r1
    c.r[2] += c.r[1];  // 0606E31C add r1,r2
    c.r[2] += 1;  // 0606E31E add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606E320 mov.b @r2,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606E322 extu.b r1,r12
    c.r[1] = c.r[12];  // 0606E324 mov r12,r1
    c.r[1] <<= 2;  // 0606E326 shll2 r1
    c.r[1] += c.r[12];  // 0606E328 add r12,r1
    c.r[2] = ld32(c.r[10]);  // 0606E32A mov.l @r10,r2
    c.r[1] <<= 2;  // 0606E32C shll2 r1
    c.r[2] += c.r[1];  // 0606E32E add r1,r2
    c.r[2] += 51;  // 0606E330 add #51,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606E332 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606E334 mov r1,r0
    c.r[0] >>= 2;  // 0606E336 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606E338 shlr r0
    c.r[0] &= 0x1u;  // 0606E33A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606E33C tst r0,r0
    if (c.t) { goto L_0606E37C; }  // 0606E33E bt 0x0606E37C
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606E34Cu);  // 0606E340 mov.w 0x0606E34C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606E346u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E346u) return; }  // 0606E342 jsr @r11 ; nop
    c.r[4] = 0x2u; goto L_0606E384;  // 0606E346 bra 0x0606E384 ; mov #2,r4
L_0606E37C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606E478u);  // 0606E37C mov.w 0x0606E478,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606E382u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E382u) return; }  // 0606E37E jsr @r11 ; nop
    c.r[4] = 0x1u;  // 0606E382 mov #1,r4
L_0606E384:
    { const uint32_t x = c.r[11]; c.pr = 0x0606E388u; c.r[8] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E388u) return; }  // 0606E384 jsr @r11 ; mov r12,r8
    c.r[8] <<= 2;  // 0606E388 shll2 r8
    c.r[8] += c.r[12];  // 0606E38A add r12,r8
    c.r[1] = ld32(c.r[10]);  // 0606E38C mov.l @r10,r1
    c.r[8] <<= 2;  // 0606E38E shll2 r8
    c.r[1] += c.r[8];  // 0606E390 add r8,r1
    c.r[1] += 44;  // 0606E392 add #44,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E394 mov.w @r1,r4
    c.r[5] = c.r[12];  // 0606E396 mov r12,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E47Au);  // 0606E398 mov.w 0x0606E47A,r1
    c.r[4] += c.r[1];  // 0606E39A add r1,r4
    c.r[1] = ld32(0x0606E480u);  // 0606E39C mov.l 0x0606E480,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E3A2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E3A2u) return; }  // 0606E39E jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[10]);  // 0606E3A2 mov.l @r10,r1
    c.r[5] = 0x0u;  // 0606E3A4 mov #0,r5
    c.r[1] += c.r[8];  // 0606E3A6 add r8,r1
    c.r[1] += 48;  // 0606E3A8 add #48,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E3AA mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606E3AC mov #0,r4
    c.r[1] = ld32(0x0606E484u);  // 0606E3AE mov.l 0x0606E484,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E3B4u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E3B4u) return; }  // 0606E3B0 jsr @r1 ; extu.w r6,r6
    c.r[2] = ld32(c.r[10]);  // 0606E3B4 mov.l @r10,r2
    c.r[2] += c.r[8];  // 0606E3B6 add r8,r2
    c.r[1] = c.r[2];  // 0606E3B8 mov r2,r1
    c.r[1] += 62;  // 0606E3BA add #62,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E3BC mov.b @r1,r5
    c.r[2] += 61;  // 0606E3BE add #61,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606E3C0 mov.b @r2,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0606E3C2 extu.b r5,r5
    c.r[1] = ld32(0x0606E488u);  // 0606E3C4 mov.l 0x0606E488,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E3CAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E3CAu) return; }  // 0606E3C6 jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(c.r[10]);  // 0606E3CA mov.l @r10,r1
    c.r[1] += c.r[8];  // 0606E3CC add r8,r1
    c.r[1] += 58;  // 0606E3CE add #58,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E3D0 mov.b @r1,r5
    c.r[1] = ld32(0x0606E48Cu);  // 0606E3D2 mov.l 0x0606E48C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E3D8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E3D8u) return; }  // 0606E3D4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606E490u);  // 0606E3D8 mov.l 0x0606E490,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E3DA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606E3DC extu.b r1,r0
    c.r[1] = ld32(0x0606E494u);  // 0606E3DE mov.l 0x0606E494,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606E3E0 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606E3E2 extu.b r2,r2
    c.r[2] -= 1;  // 0606E3E4 add #-1,r2
    c.r[1] = 0x7u;  // 0606E3E6 mov #7,r1
    c.macl = c.r[2] * c.r[1];  // 0606E3E8 mul.l r1,r2
    c.r[9] += 1;  // 0606E3EA add #1,r9
    c.r[1] = c.macl;  // 0606E3EC sts macl,r1
    c.r[1] += c.r[13];  // 0606E3EE add r13,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0606E3F0 cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_0606E314; }  // 0606E3F2 bf 0x0606E314
L_0606E3F4:
    c.r[8] = ld32(0x0606E498u);  // 0606E3F4 mov.l 0x0606E498,r8
    c.r[1] = ld32(0x0606E49Cu);  // 0606E3F6 mov.l 0x0606E49C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606E3F8 mov.b @r8,r4
    c.r[5] = c.r[14];  // 0606E3FA mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606E400u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E400u) return; }  // 0606E3FC jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0606E490u);  // 0606E400 mov.l 0x0606E490,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E402 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606E404 extu.b r1,r0
    c.r[1] = ld32(0x0606E494u);  // 0606E406 mov.l 0x0606E494,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606E408 mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 0606E40A mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606E40C extu.b r1,r1
    c.r[1] -= 1;  // 0606E40E add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0606E410 mul.l r2,r1
    c.r[1] = ld32(0x0606E4A0u);  // 0606E412 mov.l 0x0606E4A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606E414 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0606E416 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606E418 extu.b r1,r1
    c.r[2] += c.r[1];  // 0606E41A add r1,r2
    c.r[1] = ld32(0x0606E4A4u);  // 0606E41C mov.l 0x0606E4A4,r1
    c.r[1] = ld32(c.r[1]);  // 0606E41E mov.l @r1,r1
    c.r[2] += c.r[2];  // 0606E420 add r2,r2
    c.r[1] += c.r[2];  // 0606E422 add r2,r1
    c.r[1] += 1;  // 0606E424 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E426 mov.b @r1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606E428 extu.b r1,r12
    c.r[1] = ld32(0x0606E4A8u);  // 0606E42A mov.l 0x0606E4A8,r1
    c.r[2] = ld32(c.r[1]);  // 0606E42C mov.l @r1,r2
    c.r[1] = c.r[12];  // 0606E42E mov r12,r1
    c.r[1] <<= 2;  // 0606E430 shll2 r1
    c.r[1] += c.r[12];  // 0606E432 add r12,r1
    c.r[1] <<= 2;  // 0606E434 shll2 r1
    c.r[2] += c.r[1];  // 0606E436 add r1,r2
    c.r[2] += 52;  // 0606E438 add #52,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606E43A mov.w @r2,r1
    c.r[1] <<= 16;  // 0606E43C shll16 r1
    c.r[1] <<= 2;  // 0606E43E shll2 r1
    c.r[1] += c.r[1];  // 0606E440 add r1,r1
    c.r[1] <<= 2;  // 0606E442 shll2 r1
    c.r[1] >>= 16;  // 0606E444 shlr16 r1
    c.r[1] <<= 2;  // 0606E446 shll2 r1
    c.r[1] >>= 8;  // 0606E448 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606E44A tst r1,r1
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0606E452; } }  // 0606E44C bf/s 0x0606E452 ; mov #0,r4
    c.r[4] = 0x30u;  // 0606E450 mov #48,r4
L_0606E452:
    c.r[0] = c.r[14];  // 0606E452 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606E454 mov.b @(r0,r12),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606E456 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E47Cu);  // 0606E458 mov.w 0x0606E47C,r1
    c.t = c.r[3] == c.r[1];  // 0606E45A cmp/eq r1,r3
    { const bool k = c.t; c.r[13] = c.r[4]; if (k) { goto L_0606E4B0; } }  // 0606E45C bt/s 0x0606E4B0 ; mov r4,r13
    c.r[1] = ld32(0x0606E4ACu);  // 0606E460 mov.l 0x0606E4AC,r1
    c.r[2] = ld32(c.r[1]);  // 0606E462 mov.l @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606E464 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606E466 extu.b r1,r1
    c.r[1] <<= 2;  // 0606E468 shll2 r1
    c.r[1] <<= 2;  // 0606E46A shll2 r1
    c.r[1] += c.r[2];  // 0606E46C add r2,r1
    c.r[1] += 40;  // 0606E46E add #40,r1
    c.r[0] = c.r[1];  // 0606E470 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606E472 mov.b @(r0,r3),r1
    c.r[6] = c.r[1] & 0xFFu; goto L_0606E4B2;  // 0606E474 bra 0x0606E4B2 ; extu.b r1,r6
L_0606E4B0:
    c.r[6] = 0x0u;  // 0606E4B0 mov #0,r6
L_0606E4B2:
    c.r[5] = 0x0u;  // 0606E4B2 mov #0,r5
    c.r[0] = ld32(0x0606E620u);  // 0606E4B4 mov.l 0x0606E620,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E4BAu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E4BAu) return; }  // 0606E4B6 jsr @r0 ; mov r13,r4
    c.r[10] = ld32(0x0606E624u);  // 0606E4BA mov.l 0x0606E624,r10
    c.r[8] = c.r[12];  // 0606E4BC mov r12,r8
    c.r[8] <<= 2;  // 0606E4BE shll2 r8
    c.r[11] = c.r[8];  // 0606E4C0 mov r8,r11
    c.r[11] += c.r[12];  // 0606E4C2 add r12,r11
    c.r[11] <<= 2;  // 0606E4C4 shll2 r11
    c.r[5] = 0x0u;  // 0606E4C6 mov #0,r5
    c.r[1] = ld32(c.r[10]);  // 0606E4C8 mov.l @r10,r1
    c.r[4] = c.r[13];  // 0606E4CA mov r13,r4
    c.r[1] += c.r[11];  // 0606E4CC add r11,r1
    c.r[1] += 52;  // 0606E4CE add #52,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E4D0 mov.w @r1,r6
    c.r[0] = ld32(0x0606E620u);  // 0606E4D2 mov.l 0x0606E620,r0
    c.r[6] <<= 16;  // 0606E4D4 shll16 r6
    c.r[6] <<= 2;  // 0606E4D6 shll2 r6
    c.r[6] += c.r[6];  // 0606E4D8 add r6,r6
    c.r[6] <<= 2;  // 0606E4DA shll2 r6
    c.r[6] >>= 16;  // 0606E4DC shlr16 r6
    c.r[6] <<= 2;  // 0606E4DE shll2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x0606E4E4u; c.r[6] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E4E4u) return; }  // 0606E4E0 jsr @r0 ; shlr8 r6
    c.r[0] = 0x2u;  // 0606E4E4 mov #2,r0
    c.r[8] |= c.r[0];  // 0606E4E6 or r0,r8
    c.r[8] = c.r[8] & 0xFFu;  // 0606E4E8 extu.b r8,r8
    c.r[9] = ld32(0x0606E628u);  // 0606E4EA mov.l 0x0606E628,r9
    c.r[5] = 0x2u;  // 0606E4EC mov #2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606E4F2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E4F2u) return; }  // 0606E4EE jsr @r9 ; mov r8,r4
    c.r[5] = 0x0u;  // 0606E4F2 mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606E4F8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E4F8u) return; }  // 0606E4F4 jsr @r9 ; mov r8,r4
    c.r[5] = 0x1u;  // 0606E4F8 mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606E4FEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E4FEu) return; }  // 0606E4FA jsr @r9 ; mov r8,r4
    c.r[5] = 0x3u;  // 0606E4FE mov #3,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606E504u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E504u) return; }  // 0606E500 jsr @r9 ; mov r8,r4
    c.r[5] = 0x0u;  // 0606E504 mov #0,r5
    c.r[1] = ld32(c.r[10]);  // 0606E506 mov.l @r10,r1
    c.r[4] = 0x30u;  // 0606E508 mov #48,r4
    c.r[1] += c.r[11];  // 0606E50A add r11,r1
    c.r[1] += 59;  // 0606E50C add #59,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E50E mov.b @r1,r6
    c.r[0] = ld32(0x0606E620u);  // 0606E510 mov.l 0x0606E620,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E516u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E516u) return; }  // 0606E512 jsr @r0 ; extu.b r6,r6
    c.r[1] = ld32(0x0606E62Cu);  // 0606E516 mov.l 0x0606E62C,r1
    c.r[5] = 0x0u;  // 0606E518 mov #0,r5
    c.r[1] = ld32(c.r[1]);  // 0606E51A mov.l @r1,r1
    c.r[4] = 0x0u;  // 0606E51C mov #0,r4
    c.r[1] += 9;  // 0606E51E add #9,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E520 mov.b @r1,r6
    c.r[0] = ld32(0x0606E620u);  // 0606E522 mov.l 0x0606E620,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E528u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E528u) return; }  // 0606E524 jsr @r0 ; extu.b r6,r6
    c.r[5] = 0x0u;  // 0606E528 mov #0,r5
    c.r[1] = ld32(c.r[10]);  // 0606E52A mov.l @r10,r1
    c.r[4] = 0x30u;  // 0606E52C mov #48,r4
    c.r[1] += c.r[11];  // 0606E52E add r11,r1
    c.r[1] += 54;  // 0606E530 add #54,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E532 mov.w @r1,r6
    c.r[0] = ld32(0x0606E620u);  // 0606E534 mov.l 0x0606E620,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E53Au; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E53Au) return; }  // 0606E536 jsr @r0 ; extu.w r6,r6
    c.r[1] = ld32(c.r[10]);  // 0606E53A mov.l @r10,r1
    c.r[1] += 24;  // 0606E53C add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E53E mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0606E540 extu.w r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E616u);  // 0606E542 mov.w 0x0606E616,r1
    c.t = c.r[6] == c.r[1];  // 0606E544 cmp/eq r1,r6
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0606E560; } }  // 0606E546 bf/s 0x0606E560 ; mov #0,r5
    c.r[8] = ld32(0x0606E630u);  // 0606E54A mov.l 0x0606E630,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E550u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E550u) return; }  // 0606E54C jsr @r8 ; mov #3,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E554u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E554u) return; }  // 0606E550 jsr @r8 ; mov #0,r4
    c.r[4] = ld32(0x0606E634u);  // 0606E554 mov.l 0x0606E634,r4
    c.r[1] = ld32(0x0606E638u);  // 0606E556 mov.l 0x0606E638,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E55Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E55Cu) return; }  // 0606E558 jsr @r1 ; nop
    goto L_0606E566;  // 0606E55C bra 0x0606E566 ; nop
L_0606E560:
    c.r[0] = ld32(0x0606E620u);  // 0606E560 mov.l 0x0606E620,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E566u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E566u) return; }  // 0606E562 jsr @r0 ; mov #0,r4
L_0606E566:
    c.r[1] = ld32(0x0606E624u);  // 0606E566 mov.l 0x0606E624,r1
    c.r[2] = ld32(c.r[1]);  // 0606E568 mov.l @r1,r2
    c.r[1] = c.r[12];  // 0606E56A mov r12,r1
    c.r[1] <<= 2;  // 0606E56C shll2 r1
    c.r[1] += c.r[12];  // 0606E56E add r12,r1
    c.r[1] <<= 2;  // 0606E570 shll2 r1
    c.r[2] += c.r[1];  // 0606E572 add r1,r2
    c.r[2] += 60;  // 0606E574 add #60,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606E576 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606E578 extu.b r1,r1
    c.r[4] = c.r[1];  // 0606E57A mov r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606E57C tst r4,r4
    if (!c.t) { goto L_0606E588; }  // 0606E57E bf 0x0606E588
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606E618u);  // 0606E580 mov.w 0x0606E618,r5
    c.r[4] = ld32(0x0606E63Cu);  // 0606E582 mov.l 0x0606E63C,r4
    goto L_0606E590;  // 0606E584 bra 0x0606E590 ; nop
L_0606E588:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606E618u);  // 0606E588 mov.w 0x0606E618,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E61Au);  // 0606E58A mov.w 0x0606E61A,r1
    c.r[4] += c.r[1];  // 0606E58C add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606E58E extu.w r4,r4
L_0606E590:
    c.r[1] = ld32(0x0606E640u);  // 0606E590 mov.l 0x0606E640,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E596u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E596u) return; }  // 0606E592 jsr @r1 ; nop
    c.r[1] = ld32(0x0606E624u);  // 0606E596 mov.l 0x0606E624,r1
    c.r[2] = ld32(c.r[1]);  // 0606E598 mov.l @r1,r2
    c.r[1] = c.r[12];  // 0606E59A mov r12,r1
    c.r[1] <<= 2;  // 0606E59C shll2 r1
    c.r[1] += c.r[12];  // 0606E59E add r12,r1
    c.r[1] <<= 2;  // 0606E5A0 shll2 r1
    c.r[2] += c.r[1];  // 0606E5A2 add r1,r2
    c.r[1] = c.r[2];  // 0606E5A4 mov r2,r1
    c.r[1] += 51;  // 0606E5A6 add #51,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E5A8 mov.b @r1,r0
    c.r[2] += 52;  // 0606E5AA add #52,r2
    c.r[0] &= 0x1u;  // 0606E5AC and #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606E5AE mov.b @r2,r1
    c.r[0] <<= 2;  // 0606E5B0 shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0606E5B2 extu.b r1,r1
    c.r[1] >>= 2;  // 0606E5B4 shlr2 r1
    c.r[1] >>= 2;  // 0606E5B6 shlr2 r1
    c.r[1] >>= 2;  // 0606E5B8 shlr2 r1
    c.r[0] |= c.r[1];  // 0606E5BA or r1,r0
    c.r[1] = ld32(0x0606E644u);  // 0606E5BC mov.l 0x0606E644,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606E5BE mov.b @(r0,r1),r5
    c.r[1] = ld32(0x0606E648u);  // 0606E5C0 mov.l 0x0606E648,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E5C6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E5C6u) return; }  // 0606E5C2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606E64Cu);  // 0606E5C6 mov.l 0x0606E64C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606E61Cu);  // 0606E5C8 mov.w 0x0606E61C,r0
    c.r[2] = 0x1u;  // 0606E5CA mov #1,r2
    c.r[7] = 0x2u;  // 0606E5CC mov #2,r7
    c.r[6] = 0x22u;  // 0606E5CE mov #34,r6
    c.r[1] = ld32(c.r[1]);  // 0606E5D0 mov.l @r1,r1
    c.r[5] = 0x4u;  // 0606E5D2 mov #4,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606E5D4 mov.b @(r0,r1),r1
    c.r[4] = 0x3u;  // 0606E5D6 mov #3,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0606E5D8 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E5DA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606E5DC mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606E5DE mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0606E5E0 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E5E2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E5E4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606E5E6 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E5E8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E5EA mov.l r1,@-r15
    c.r[1] = 0x7u;  // 0606E5EC mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E5EE mov.l r1,@-r15
    c.r[1] = ld32(0x0606E650u);  // 0606E5F0 mov.l 0x0606E650,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E5F6u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E5F6u) return; }  // 0606E5F2 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 0606E5F6 add #40,r15
    c.r[1] = ld32(0x0606E654u);  // 0606E5F8 mov.l 0x0606E654,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E5FEu; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E5FEu) return; }  // 0606E5FA jsr @r1 ; mov #9,r4
    c.r[14] += 16;  // 0606E5FE add #16,r14
    c.r[15] = c.r[14];  // 0606E600 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606E602 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606E604 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606E606 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606E608 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606E60A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606E60C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606E60E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606E61Eu);  // 0606E610 mov.w 0x0606E61E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606E612 rts ; mov.l @r15+,r8
}

void f_0606E660(SH2Context& c) {
    ran[1570] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606E660 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606E662 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606E664 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606E666 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606E668 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606E66A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606E66C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606E66E sts.l pr,@-r15
    c.r[15] -= 56;  // 0606E670 add #-56,r15
    c.r[14] = c.r[15];  // 0606E672 mov r15,r14
    c.r[0] = ld32(0x0606E74Cu);  // 0606E674 mov.l 0x0606E74C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E67Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E67Au) return; }  // 0606E676 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x0606E750u);  // 0606E67A mov.l 0x0606E750,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E680u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E680u) return; }  // 0606E67C jsr @r1 ; mov #0,r4
    c.r[3] = ld32(0x0606E754u);  // 0606E680 mov.l 0x0606E754,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606E686u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E686u) return; }  // 0606E682 jsr @r3 ; nop
    c.r[2] = ld32(0x0606E758u);  // 0606E686 mov.l 0x0606E758,r2
    c.r[0] = ld32(0x0606E75Cu);  // 0606E688 mov.l 0x0606E75C,r0
    c.r[1] = ld32(0x0606E760u);  // 0606E68A mov.l 0x0606E760,r1
    c.r[3] = ld32(0x0606E764u);  // 0606E68C mov.l 0x0606E764,r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606E748u);  // 0606E68E mov.w 0x0606E748,r5
    c.r[4] = ld32(0x0606E768u);  // 0606E690 mov.l 0x0606E768,r4
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606E692 mov.b @r0,r7
    c.r[8] = ld32(0x0606E76Cu);  // 0606E694 mov.l 0x0606E76C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E696 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 0606E698 extu.b r7,r7
    c.r[7] += c.r[1];  // 0606E69A add r1,r7
    c.r[1] = 0x30u;  // 0606E69C mov #48,r1
    c.r[1] += c.r[14];  // 0606E69E add r14,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606E6A0 mov.b @r3,r0
    c.r[7] <<= 2;  // 0606E6A2 shll2 r7
    c.r[7] <<= 2;  // 0606E6A4 shll2 r7
    c.r[7] <<= 2;  // 0606E6A6 shll2 r7
    c.r[3] = 0x30u;  // 0606E6A8 mov #48,r3
    c.r[3] += c.r[14];  // 0606E6AA add r14,r3
    st8(c.r[3], c.r[0]);  // 0606E6AC mov.b r0,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E6AE mov.b @r1,r1
    c.r[3] = ld32(0x0606E770u);  // 0606E6B0 mov.l 0x0606E770,r3
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606E6B2 mov.b @r3,r6
    c.r[0] = c.r[2];  // 0606E6B4 mov r2,r0
    c.r[2] = ld32(c.r[0] + c.r[5]);  // 0606E6B6 mov.l @(r0,r5),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606E6B8 extu.b r1,r1
    st32(c.r[14] + 44, c.r[2]);  // 0606E6BA mov.l r2,@(44,r14)
    c.r[7] += c.r[2];  // 0606E6BC add r2,r7
    c.r[1] += c.r[6];  // 0606E6BE add r6,r1
    c.r[0] = c.r[1];  // 0606E6C0 mov r1,r0
    c.r[1] = 0x2Cu;  // 0606E6C2 mov #44,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606E6C4 mov.b @(r0,r7),r7
    c.r[1] += c.r[14];  // 0606E6C6 add r14,r1
    c.r[0] = 0x2Cu;  // 0606E6C8 mov #44,r0
    st8(c.r[0] + c.r[14], c.r[7]);  // 0606E6CA mov.b r7,@(r0,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E6CC mov.b @r1,r1
    c.r[5] = 0x22u;  // 0606E6CE mov #34,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0606E6D0 extu.b r1,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0606E6D6u; st32(c.r[14] + 8, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E6D6u) return; }  // 0606E6D2 jsr @r8 ; mov.l r1,@(8,r14)
    c.r[2] = c.r[0];  // 0606E6D6 mov r0,r2
    c.r[5] = 0x4u;  // 0606E6D8 mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606E6DEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E6DEu) return; }  // 0606E6DA jsr @r8 ; mov r2,r4
    c.r[3] = ld32(c.r[14] + 8);  // 0606E6DE mov.l @(8,r14),r3
    c.r[2] = c.r[0];  // 0606E6E0 mov r0,r2
    c.r[3] += c.r[3];  // 0606E6E2 add r3,r3
    st32(c.r[14] + 44, c.r[3]);  // 0606E6E4 mov.l r3,@(44,r14)
    c.r[0] = ld32(c.r[14] + 44);  // 0606E6E6 mov.l @(44,r14),r0
    c.r[3] += c.r[2];  // 0606E6E8 add r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606E6EA mov.b @(r0,r2),r2
    c.r[3] += 1;  // 0606E6EC add #1,r3
    st32(c.r[14] + 20, c.r[2]);  // 0606E6EE mov.l r2,@(20,r14)
    st32(c.r[14] + 16, c.r[3]);  // 0606E6F0 mov.l r3,@(16,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606E6F2 mov.b @r3,r2
    c.r[1] = ld32(c.r[14] + 20);  // 0606E6F4 mov.l @(20,r14),r1
    c.r[0] = c.r[2];  // 0606E6F6 mov r2,r0
    c.r[0] &= 0x7Fu;  // 0606E6F8 and #127,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606E6FA tst r1,r1
    { const bool k = !c.t; st32(c.r[14] + 24, c.r[0]); if (k) { goto L_0606E706; } }  // 0606E6FC bf/s 0x0606E706 ; mov.l r0,@(24,r14)
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606E700 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606E70C; } }  // 0606E702 bt/s 0x0606E70C ; mov #0,r0
L_0606E706:
    c.r[3] = 0x4u;  // 0606E706 mov #4,r3
    st32(c.r[14] + 12, c.r[3]); goto L_0606E70E;  // 0606E708 bra 0x0606E70E ; mov.l r3,@(12,r14)
L_0606E70C:
    st32(c.r[14] + 12, c.r[0]);  // 0606E70C mov.l r0,@(12,r14)
L_0606E70E:
    c.r[1] = ld32(0x0606E764u);  // 0606E70E mov.l 0x0606E764,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E710 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606E712 extu.b r1,r2
    c.r[2] += c.r[2];  // 0606E714 add r2,r2
    c.r[2] -= 7;  // 0606E716 add #-7,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0606E718 cmp/pz r2
    { const bool k = c.t; c.r[2] = c.r[2] & 0xFFu; if (k) { goto L_0606E724; } }  // 0606E71A bt/s 0x0606E724 ; extu.b r2,r2
    c.r[1] = 0x0u;  // 0606E71E mov #0,r1
    st32(c.r[14], c.r[1]); goto L_0606E726;  // 0606E720 bra 0x0606E726 ; mov.l r1,@r14
L_0606E724:
    st32(c.r[14], c.r[2]);  // 0606E724 mov.l r2,@r14
L_0606E726:
    c.r[2] = ld32(c.r[14]);  // 0606E726 mov.l @r14,r2
    c.r[1] = 0x26u;  // 0606E728 mov #38,r1
    c.r[2] += 16;  // 0606E72A add #16,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606E72C cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] = 0x16u; if (k) { goto L_0606E734; } }  // 0606E72E bf/s 0x0606E734 ; mov #22,r3
    st32(c.r[14], c.r[3]);  // 0606E732 mov.l r3,@r14
L_0606E734:
    c.r[1] = ld32(0x0606E75Cu);  // 0606E734 mov.l 0x0606E75C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E736 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0606E738 extu.b r1,r4
    c.r[4] += c.r[4];  // 0606E73A add r4,r4
    c.r[1] = 0xDu;  // 0606E73C mov #13,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0606E73E cmp/gt r1,r4
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_0606E774; } }  // 0606E740 bt/s 0x0606E774 ; mov.l @(12,r14),r0
    c.r[4] += 3; goto L_0606E778;  // 0606E744 bra 0x0606E778 ; add #3,r4
L_0606E774:
    c.r[4] -= 10;  // 0606E774 add #-10,r4
    c.r[4] -= c.r[0];  // 0606E776 sub r0,r4
L_0606E778:
    c.r[4] = c.r[4] & 0xFFu;  // 0606E778 extu.b r4,r4
    st32(c.r[14] + 4, c.r[4]);  // 0606E77A mov.l r4,@(4,r14)
    c.r[12] = 0x0u;  // 0606E77C mov #0,r12
    c.r[2] = ld32(0x0606E9B4u);  // 0606E77E mov.l 0x0606E9B4,r2
    c.r[1] = ld32(0x0606E9B8u);  // 0606E780 mov.l 0x0606E9B8,r1
    c.r[0] = 0x2Cu;  // 0606E782 mov #44,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E784 mov.w @r1,r3
    c.r[0] += c.r[14];  // 0606E786 add r14,r0
    c.r[1] = 0x2Cu;  // 0606E788 mov #44,r1
    c.r[1] += c.r[14];  // 0606E78A add r14,r1
    st16(c.r[1], c.r[3]);  // 0606E78C mov.w r3,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0606E78E mov.w @r0,r0
    c.r[11] = c.r[0] & 0xFFFFu;  // 0606E790 extu.w r0,r11
    c.r[11] += 1;  // 0606E792 add #1,r11
    c.r[1] = c.r[11];  // 0606E794 mov r11,r1
    c.r[1] += c.r[1];  // 0606E796 add r1,r1
    c.r[1] += c.r[11];  // 0606E798 add r11,r1
    c.r[1] <<= 2;  // 0606E79A shll2 r1
    st32(c.r[14] + 40, c.r[1]);  // 0606E79C mov.l r1,@(40,r14)
L_0606E79E:
    c.r[3] = ld32(0x0606E9BCu);  // 0606E79E mov.l 0x0606E9BC,r3
    c.r[0] = ld32(0x0606E9C0u);  // 0606E7A0 mov.l 0x0606E9C0,r0
    c.r[1] = ld32(0x0606E9C4u);  // 0606E7A2 mov.l 0x0606E9C4,r1
    c.r[4] = 0x3Fu;  // 0606E7A4 mov #63,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606E7A6 mov.b @r3,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[12] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0606E7A8 dmuls.l r1,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606E7AA mov.b @r0,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0606E7AC extu.b r2,r2
    c.r[2] += c.r[0];  // 0606E7AE add r0,r2
    c.r[2] += c.r[2];  // 0606E7B0 add r2,r2
    c.r[2] -= 2;  // 0606E7B2 add #-2,r2
    c.r[0] = c.r[12];  // 0606E7B4 mov r12,r0
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 0606E7B6 shll r0
    { uint32_t a = c.r[0], b = c.r[0], t = c.t; c.r[0] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0606E7B8 subc r0,r0
    c.r[3] = c.mach;  // 0606E7BA sts mach,r3
    c.r[3] -= c.r[0];  // 0606E7BC sub r0,r3
    st32(c.r[14] + 28, c.r[3]);  // 0606E7BE mov.l r3,@(28,r14)
    c.r[3] += c.r[3];  // 0606E7C0 add r3,r3
    c.r[1] = ld32(c.r[14] + 28);  // 0606E7C2 mov.l @(28,r14),r1
    c.r[0] = c.r[12];  // 0606E7C4 mov r12,r0
    c.r[3] += c.r[1];  // 0606E7C6 add r1,r3
    c.r[3] += c.r[3];  // 0606E7C8 add r3,r3
    c.r[0] -= c.r[3];  // 0606E7CA sub r3,r0
    st32(c.r[14] + 32, c.r[0]);  // 0606E7CC mov.l r0,@(32,r14)
    c.r[2] += c.r[0];  // 0606E7CE add r0,r2
    c.r[8] = c.r[2] & 0xFFu;  // 0606E7D0 extu.b r2,r8
    c.r[1] = ld32(0x0606E9C8u);  // 0606E7D2 mov.l 0x0606E9C8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E7D4 mov.b @r1,r2
    c.r[3] = ld32(0x0606E9CCu);  // 0606E7D6 mov.l 0x0606E9CC,r3
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606E7D8 mov.b @r3,r3
    c.r[6] = c.r[8];  // 0606E7DA mov r8,r6
    c.r[0] = ld32(c.r[14] + 28);  // 0606E7DC mov.l @(28,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0606E7DE extu.b r2,r2
    c.r[2] += c.r[3];  // 0606E7E0 add r3,r2
    c.r[2] += c.r[2];  // 0606E7E2 add r2,r2
    c.r[2] -= 2;  // 0606E7E4 add #-2,r2
    c.r[2] += c.r[0];  // 0606E7E6 add r0,r2
    c.r[5] = c.r[2] & 0xFFu;  // 0606E7E8 extu.b r2,r5
    c.r[7] = c.r[5];  // 0606E7EA mov r5,r7
    c.t = c.r[8] > c.r[4];  // 0606E7EC cmp/hi r4,r8
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0606E7F4; } }  // 0606E7EE bf/s 0x0606E7F4 ; mov #0,r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606E9A4u);  // 0606E7F2 mov.w 0x0606E9A4,r2
L_0606E7F4:
    c.t = c.r[5] > c.r[4];  // 0606E7F4 cmp/hi r4,r5
    { const bool k = !c.t; c.r[10] = c.r[2]; if (k) { goto L_0606E800; } }  // 0606E7F6 bf/s 0x0606E800 ; mov r2,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E9A6u);  // 0606E7FA mov.w 0x0606E9A6,r1
    c.r[2] += c.r[1];  // 0606E7FC add r1,r2
    c.r[10] = c.r[2];  // 0606E7FE mov r2,r10
L_0606E800:
    c.r[10] += c.r[10];  // 0606E800 add r10,r10
    c.r[1] = 0x3Fu;  // 0606E802 mov #63,r1
    c.r[6] &= c.r[1];  // 0606E804 and r1,r6
    c.r[6] += c.r[6];  // 0606E806 add r6,r6
    c.r[3] = ld32(0x0606E9D0u);  // 0606E808 mov.l 0x0606E9D0,r3
    c.r[6] += c.r[3];  // 0606E80A add r3,r6
    c.r[10] += c.r[6];  // 0606E80C add r6,r10
    c.r[7] &= c.r[1];  // 0606E80E and r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606E9A8u);  // 0606E810 mov.w 0x0606E9A8,r0
    c.r[1] = c.r[12];  // 0606E812 mov r12,r1
    c.r[1] += c.r[1];  // 0606E814 add r1,r1
    c.r[3] = ld32(0x0606E9D4u);  // 0606E816 mov.l 0x0606E9D4,r3
    c.r[1] += c.r[3];  // 0606E818 add r3,r1
    c.r[1] += 2;  // 0606E81A add #2,r1
    st32(c.r[14] + 48, c.r[1]);  // 0606E81C mov.l r1,@(48,r14)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606E9AAu);  // 0606E81E mov.w 0x0606E9AA,r2
    c.macl = c.r[7] * c.r[0];  // 0606E820 mul.l r0,r7
    c.r[3] = 0x36u;  // 0606E822 mov #54,r3
    c.r[3] += c.r[14];  // 0606E824 add r14,r3
    c.r[9] = c.macl;  // 0606E826 sts macl,r9
    c.r[0] = c.r[10];  // 0606E828 mov r10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0606E82A mov.w @(r0,r9),r1
    c.r[8] = c.r[11] & 0xFFFFu;  // 0606E82C extu.w r11,r8
    c.r[0] = 0x36u;  // 0606E82E mov #54,r0
    st16(c.r[0] + c.r[14], c.r[1]);  // 0606E830 mov.w r1,@(r0,r14)
    c.r[0] = 0x2Eu;  // 0606E832 mov #46,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606E834 mov.w @r3,r3
    c.r[0] += c.r[14];  // 0606E836 add r14,r0
    c.r[3] &= c.r[2];  // 0606E838 and r2,r3
    st32(c.r[14] + 44, c.r[3]);  // 0606E83A mov.l r3,@(44,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0606E83C mov.w @r0,r1
    c.r[6] = 0x8u;  // 0606E83E mov #8,r6
    c.r[0] = ld32(c.r[14] + 48);  // 0606E840 mov.l @(48,r14),r0
    c.r[3] = ld32(0x0606E9B4u);  // 0606E842 mov.l 0x0606E9B4,r3
    st16(c.r[0], c.r[1]);  // 0606E844 mov.w r1,@r0
    c.r[5] = ld32(c.r[3] + 4);  // 0606E846 mov.l @(4,r3),r5
    c.r[7] = 0x8u;  // 0606E848 mov #8,r7
    c.r[4] = ld32(c.r[3]);  // 0606E84A mov.l @r3,r4
    c.r[0] = ld32(0x0606E9D8u);  // 0606E84C mov.l 0x0606E9D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E852u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E852u) return; }  // 0606E84E jsr @r0 ; mov.l r8,@-r15
    c.r[7] = c.r[12];  // 0606E852 mov r12,r7
    c.r[7] <<= 2;  // 0606E854 shll2 r7
    c.r[7] += c.r[7];  // 0606E856 add r7,r7
    c.r[7] <<= 2;  // 0606E858 shll2 r7
    c.r[1] = ld32(0x0606E9DCu);  // 0606E85A mov.l 0x0606E9DC,r1
    c.r[7] += c.r[1];  // 0606E85C add r1,r7
    c.r[3] = c.r[11];  // 0606E85E mov r11,r3
    c.r[3] <<= 2;  // 0606E860 shll2 r3
    c.r[3] += c.r[3];  // 0606E862 add r3,r3
    c.r[0] = ld32(0x0606E9B4u);  // 0606E864 mov.l 0x0606E9B4,r0
    c.r[6] = 0x3u;  // 0606E866 mov #3,r6
    c.r[5] = c.r[8];  // 0606E868 mov r8,r5
    c.r[4] = ld32(c.r[0] + 4);  // 0606E86A mov.l @(4,r0),r4
    c.r[1] = ld32(0x0606E9E0u);  // 0606E86C mov.l 0x0606E9E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E872u; c.r[4] += c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E872u) return; }  // 0606E86E jsr @r1 ; add r3,r4
    c.r[0] = c.r[10];  // 0606E872 mov r10,r0
    c.r[1] = 0x2Eu;  // 0606E874 mov #46,r1
    c.r[1] += c.r[14];  // 0606E876 add r14,r1
    c.r[3] = 0xFu;  // 0606E878 mov #15,r3
    c.r[7] = 0x0u;  // 0606E87A mov #0,r7
    c.r[10] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0606E87C mov.w @(r0,r9),r10
    c.r[5] = c.r[8];  // 0606E87E mov r8,r5
    c.r[0] = 0x2Eu;  // 0606E880 mov #46,r0
    st16(c.r[0] + c.r[14], c.r[10]);  // 0606E882 mov.w r10,@(r0,r14)
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E884 mov.w @r1,r2
    c.r[0] = 0x10u;  // 0606E886 mov #16,r0
    c.r[2] >>= 8;  // 0606E888 shlr8 r2
    c.r[2] >>= 2;  // 0606E88A shlr2 r2
    c.r[2] >>= 2;  // 0606E88C shlr2 r2
    c.r[2] &= c.r[3];  // 0606E88E and r3,r2
    c.r[2] |= c.r[0];  // 0606E890 or r0,r2
    c.r[1] = c.r[11];  // 0606E892 mov r11,r1
    c.r[1] <<= 2;  // 0606E894 shll2 r1
    c.r[1] += c.r[11];  // 0606E896 add r11,r1
    c.r[1] += c.r[1];  // 0606E898 add r1,r1
    c.r[3] = ld32(0x0606E9B4u);  // 0606E89A mov.l 0x0606E9B4,r3
    c.r[0] = ld32(0x0606E9E4u);  // 0606E89C mov.l 0x0606E9E4,r0
    c.r[4] = ld32(c.r[3] + 8);  // 0606E89E mov.l @(8,r3),r4
    c.r[6] = c.r[2];  // 0606E8A0 mov r2,r6
    c.r[4] += c.r[1];  // 0606E8A2 add r1,r4
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0606E8A4 mov.l r0,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E9A8u);  // 0606E8A6 mov.w 0x0606E9A8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606E8A8 mov.l r1,@-r15
    c.r[3] = 0x0u;  // 0606E8AA mov #0,r3
    c.r[0] = ld32(0x0606E9E8u);  // 0606E8AC mov.l 0x0606E9E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606E8B2u; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E8B2u) return; }  // 0606E8AE jsr @r0 ; mov.l r3,@-r15
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606E9ACu);  // 0606E8B2 mov.w 0x0606E9AC,r13
    c.r[1] = 0x23u;  // 0606E8B4 mov #35,r1
    c.r[1] += c.r[14];  // 0606E8B6 add r14,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E8B8 mov.b @r1,r4
    c.r[0] = ld32(0x0606E9ECu);  // 0606E8BA mov.l 0x0606E9EC,r0
    c.r[3] = ld32(c.r[14]);  // 0606E8BC mov.l @r14,r3
    c.r[9] = ld32(0x0606E9F0u);  // 0606E8BE mov.l 0x0606E9F0,r9
    c.r[10] = ld32(c.r[0] + c.r[13]);  // 0606E8C0 mov.l @(r0,r13),r10
    c.r[4] += c.r[3];  // 0606E8C2 add r3,r4
    c.r[4] <<= 2;  // 0606E8C4 shll2 r4
    c.r[4] += c.r[4];  // 0606E8C6 add r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606E9AEu);  // 0606E8C8 mov.w 0x0606E9AE,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0606E8CEu; c.r[4] += c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E8CEu) return; }  // 0606E8CA jsr @r9 ; add r0,r4
    c.r[4] = c.r[0];  // 0606E8CE mov r0,r4
    c.r[5] = c.r[1];  // 0606E8D0 mov r1,r5
    c.r[1] = ld32(0x0606E9F4u);  // 0606E8D2 mov.l 0x0606E9F4,r1
    c.r[6] = ld32(c.r[1]);  // 0606E8D4 mov.l @r1,r6
    c.r[3] = ld32(0x0606E9F8u);  // 0606E8D6 mov.l 0x0606E9F8,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606E8DCu; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E8DCu) return; }  // 0606E8D8 jsr @r3 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0606E8DC mov r0,r4
    c.r[8] = ld32(0x0606E9FCu);  // 0606E8DE mov.l 0x0606E9FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E8E4u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E8E4u) return; }  // 0606E8E0 jsr @r8 ; mov r1,r5
    c.r[2] = c.r[0];  // 0606E8E4 mov r0,r2
    c.r[0] = ld32(c.r[14] + 40);  // 0606E8E6 mov.l @(40,r14),r0
    c.r[3] = 0x1Fu;  // 0606E8E8 mov #31,r3
    st32(c.r[0] + c.r[10], c.r[2]);  // 0606E8EA mov.l r2,@(r0,r10)
    c.r[0] = ld32(0x0606E9ECu);  // 0606E8EC mov.l 0x0606E9EC,r0
    c.r[13] = ld32(c.r[0] + c.r[13]);  // 0606E8EE mov.l @(r0,r13),r13
    c.r[3] += c.r[14];  // 0606E8F0 add r14,r3
    c.r[1] = ld32(c.r[14] + 40);  // 0606E8F2 mov.l @(40,r14),r1
    st32(c.r[14] + 36, c.r[13]);  // 0606E8F4 mov.l r13,@(36,r14)
    c.r[1] += c.r[13];  // 0606E8F6 add r13,r1
    st32(c.r[14] + 36, c.r[1]);  // 0606E8F8 mov.l r1,@(36,r14)
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606E8FA mov.b @r3,r4
    c.r[0] = ld32(c.r[14] + 4);  // 0606E8FC mov.l @(4,r14),r0
    c.r[4] += c.r[0];  // 0606E8FE add r0,r4
    c.r[4] <<= 2;  // 0606E900 shll2 r4
    c.r[4] += c.r[4];  // 0606E902 add r4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E908u; c.r[4] -= 112; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E908u) return; }  // 0606E904 jsr @r9 ; add #-112,r4
    c.r[4] = c.r[0];  // 0606E908 mov r0,r4
    c.r[5] = c.r[1];  // 0606E90A mov r1,r5
    c.r[1] = ld32(0x0606E9F4u);  // 0606E90C mov.l 0x0606E9F4,r1
    c.r[6] = ld32(c.r[1]);  // 0606E90E mov.l @r1,r6
    c.r[3] = ld32(0x0606E9F8u);  // 0606E910 mov.l 0x0606E9F8,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606E916u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E916u) return; }  // 0606E912 jsr @r3 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0606E916 mov r0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E91Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E91Cu) return; }  // 0606E918 jsr @r8 ; mov r1,r5
    c.r[2] = c.r[0];  // 0606E91C mov r0,r2
    c.r[15] += 16;  // 0606E91E add #16,r15
    c.r[12] += 1;  // 0606E920 add #1,r12
    st32(c.r[14] + 44, c.r[12]);  // 0606E922 mov.l r12,@(44,r14)
    c.r[1] = 0x2Fu;  // 0606E924 mov #47,r1
    c.r[1] += c.r[14];  // 0606E926 add r14,r1
    c.r[0] = ld32(c.r[14] + 36);  // 0606E928 mov.l @(36,r14),r0
    c.r[11] += 1;  // 0606E92A add #1,r11
    c.r[3] = ld32(c.r[14] + 40);  // 0606E92C mov.l @(40,r14),r3
    st32(c.r[0] + 4, c.r[2]);  // 0606E92E mov.l r2,@(4,r0)
    c.r[3] += 12;  // 0606E930 add #12,r3
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E932 mov.b @r1,r12
    c.r[0] = 0x23u;  // 0606E934 mov #35,r0
    c.t = (int32_t)c.r[12] > (int32_t)c.r[0];  // 0606E936 cmp/gt r0,r12
    { const bool k = c.t; st32(c.r[14] + 40, c.r[3]); if (k) { goto L_0606E940; } }  // 0606E938 bt/s 0x0606E940 ; mov.l r3,@(40,r14)
    SH2_POLL(c); goto L_0606E79E;  // 0606E93C bra 0x0606E79E ; nop
L_0606E940:
    c.r[9] = ld32(0x0606EA00u);  // 0606E940 mov.l 0x0606EA00,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0606E946u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E946u) return; }  // 0606E942 jsr @r9 ; mov.l @r14,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E94Au; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E94Au) return; }  // 0606E946 jsr @r9 ; mov.l @(4,r14),r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606E9B0u);  // 0606E94A mov.w 0x0606E9B0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E950u; c.r[11] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E950u) return; }  // 0606E94C jsr @r9 ; mov #0,r11
    { const uint32_t x = c.r[9]; c.pr = 0x0606E954u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E954u) return; }  // 0606E950 jsr @r9 ; mov.l @r14,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E958u; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E958u) return; }  // 0606E954 jsr @r9 ; mov.l @(4,r14),r4
    c.r[4] = ld32(0x0606EA04u);  // 0606E958 mov.l 0x0606EA04,r4
    c.r[8] = ld32(0x0606EA08u);  // 0606E95A mov.l 0x0606EA08,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E960u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E960u) return; }  // 0606E95C jsr @r8 ; mov #34,r5
    c.r[2] = c.r[0];  // 0606E960 mov r0,r2
    c.r[5] = 0x3u;  // 0606E962 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606E968u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E968u) return; }  // 0606E964 jsr @r8 ; mov r2,r4
    st32(c.r[14] + 16, c.r[0]);  // 0606E968 mov.l r0,@(16,r14)
    c.r[3] = c.r[0];  // 0606E96A mov r0,r3
    c.r[10] = c.r[8];  // 0606E96C mov r8,r10
    c.r[9] = ld32(0x0606EA0Cu);  // 0606E96E mov.l 0x0606EA0C,r9
    c.r[1] = ld32(c.r[14] + 8);  // 0606E970 mov.l @(8,r14),r1
    c.r[13] = 0x2u;  // 0606E972 mov #2,r13
    c.r[1] += c.r[1];  // 0606E974 add r1,r1
    c.r[3] += c.r[1];  // 0606E976 add r1,r3
    st32(c.r[14] + 16, c.r[3]);  // 0606E978 mov.l r3,@(16,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 0606E97A mov.l @(16,r14),r0
L_0606E97C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606E97C mov.b @(r0,r11),r1
    c.r[1] -= 100;  // 0606E97E add #-100,r1
    c.r[12] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0606E980 exts.b r1,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 0606E982 tst r12,r12
    if (!c.t) { goto L_0606EA10; }  // 0606E984 bf 0x0606EA10
    c.r[1] = ld32(0x0606EA00u);  // 0606E986 mov.l 0x0606EA00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E98Cu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E98Cu) return; }  // 0606E988 jsr @r1 ; mov #6,r4
    c.r[4] = ld32(0x0606EA04u);  // 0606E98C mov.l 0x0606EA04,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606E992u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E992u) return; }  // 0606E98E jsr @r10 ; mov #23,r5
    c.r[2] = c.r[0];  // 0606E992 mov r0,r2
    c.r[5] = 0x4u;  // 0606E994 mov #4,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606E99Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E99Au) return; }  // 0606E996 jsr @r10 ; mov r2,r4
    c.r[2] = c.r[0];  // 0606E99A mov r0,r2
    c.r[6] = 0x0u;  // 0606E99C mov #0,r6
    c.r[5] = 0x0u;  // 0606E99E mov #0,r5
    c.r[4] = c.r[2]; goto L_0606EA4A;  // 0606E9A0 bra 0x0606EA4A ; mov r2,r4
L_0606EA10:
    c.r[3] = ld32(0x0606EB5Cu);  // 0606EA10 mov.l 0x0606EB5C,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606EA16u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA16u) return; }  // 0606EA12 jsr @r3 ; mov #6,r4
    c.t = (int32_t)c.r[12] >= 0;  // 0606EA16 cmp/pz r12
    { const bool k = c.t; c.r[6] = c.r[12]; if (k) { goto L_0606EA1E; } }  // 0606EA18 bt/s 0x0606EA1E ; mov r12,r6
    c.r[6] = 0u - c.r[12];  // 0606EA1C neg r12,r6
L_0606EA1E:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606EB52u);  // 0606EA1E mov.w 0x0606EB52,r5
    c.r[0] = ld32(0x0606EB60u);  // 0606EA20 mov.l 0x0606EB60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606EA26u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA26u) return; }  // 0606EA22 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x0606EB5Cu);  // 0606EA26 mov.l 0x0606EB5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EA2Cu; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA2Cu) return; }  // 0606EA28 jsr @r1 ; mov #14,r4
    c.t = (int32_t)c.r[12] > 0;  // 0606EA2C cmp/pl r12
    { const bool k = c.t; c.r[8] = c.r[13] & 0xFFu; if (k) { goto L_0606EA38; } }  // 0606EA2E bt/s 0x0606EA38 ; extu.b r13,r8
    c.r[8] = c.r[11];  // 0606EA32 mov r11,r8
    c.r[8] += 1;  // 0606EA34 add #1,r8
    c.r[8] = c.r[8] & 0xFFu;  // 0606EA36 extu.b r8,r8
L_0606EA38:
    c.r[4] = ld32(0x0606EB64u);  // 0606EA38 mov.l 0x0606EB64,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606EA3Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA3Eu) return; }  // 0606EA3A jsr @r10 ; mov #23,r5
    c.r[5] = 0x4u;  // 0606EA3E mov #4,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606EA44u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA44u) return; }  // 0606EA40 jsr @r10 ; mov r0,r4
    c.r[6] = 0x0u;  // 0606EA44 mov #0,r6
    c.r[5] = c.r[8];  // 0606EA46 mov r8,r5
    c.r[4] = c.r[0];  // 0606EA48 mov r0,r4
L_0606EA4A:
    { const uint32_t x = c.r[9]; c.pr = 0x0606EA4Eu; c.r[13] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA4Eu) return; }  // 0606EA4A jsr @r9 ; add #-1,r13
    c.r[11] += 1;  // 0606EA4E add #1,r11
    c.r[1] = 0x1u;  // 0606EA50 mov #1,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 0606EA52 cmp/gt r1,r11
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 16); if (k) { SH2_POLL(c); goto L_0606E97C; } }  // 0606EA54 bf/s 0x0606E97C ; mov.l @(16,r14),r0
    c.r[0] = ld32(c.r[14] + 8);  // 0606EA58 mov.l @(8,r14),r0
    c.t = c.r[0] == 0xBu;  // 0606EA5A cmp/eq #11,r0
    if (!c.t) { goto L_0606EA78; }  // 0606EA5C bf 0x0606EA78
    c.r[1] = ld32(0x0606EB68u);  // 0606EA5E mov.l 0x0606EB68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EA60 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606EA62 extu.b r1,r0
    c.r[0] >>= 2;  // 0606EA64 shlr2 r0
    c.r[0] >>= 2;  // 0606EA66 shlr2 r0
    c.r[0] >>= 2;  // 0606EA68 shlr2 r0
    c.r[1] = ld32(0x0606EB6Cu);  // 0606EA6A mov.l 0x0606EB6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606EA6C mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606EB54u);  // 0606EA6E mov.w 0x0606EB54,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606EA70 extu.b r1,r1
    c.r[4] = c.r[1];  // 0606EA72 mov r1,r4
    c.r[4] |= c.r[2]; goto L_0606EA7E;  // 0606EA74 bra 0x0606EA7E ; or r2,r4
L_0606EA78:
    c.r[4] = ld32(c.r[14] + 8);  // 0606EA78 mov.l @(8,r14),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606EB54u);  // 0606EA7A mov.w 0x0606EB54,r1
    c.r[4] |= c.r[1];  // 0606EA7C or r1,r4
L_0606EA7E:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606EB56u);  // 0606EA7E mov.w 0x0606EB56,r5
    c.r[1] = ld32(0x0606EB70u);  // 0606EA80 mov.l 0x0606EB70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EA86u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA86u) return; }  // 0606EA82 jsr @r1 ; nop
    c.r[3] = ld32(c.r[14] + 12);  // 0606EA86 mov.l @(12,r14),r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606EA88 tst r3,r3
    if (c.t) { goto L_0606EB28; }  // 0606EA8A bt 0x0606EB28
    c.r[8] = ld32(0x0606EB5Cu);  // 0606EA8C mov.l 0x0606EB5C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606EA92u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA92u) return; }  // 0606EA8E jsr @r8 ; mov #4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606EB58u);  // 0606EA92 mov.w 0x0606EB58,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606EA98u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA98u) return; }  // 0606EA94 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0606EA9Cu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EA9Cu) return; }  // 0606EA98 jsr @r8 ; mov #6,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606EAA0u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAA0u) return; }  // 0606EA9C jsr @r8 ; mov.l @r14,r4
    c.r[1] = 0x7u;  // 0606EAA0 mov #7,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0606EAA2 mov.l @(4,r14),r0
    c.r[1] += c.r[14];  // 0606EAA4 add r14,r1
    c.r[0] += 9;  // 0606EAA6 add #9,r0
    st32(c.r[14] + 4, c.r[0]);  // 0606EAA8 mov.l r0,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EAAA mov.b @r1,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0606EAB0u; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAB0u) return; }  // 0606EAAC jsr @r8 ; extu.b r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606EAB4u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAB4u) return; }  // 0606EAB0 jsr @r8 ; mov #17,r4
    c.r[9] = ld32(0x0606EB74u);  // 0606EAB4 mov.l 0x0606EB74,r9
    c.r[4] = ld32(0x0606EB64u);  // 0606EAB6 mov.l 0x0606EB64,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606EABCu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EABCu) return; }  // 0606EAB8 jsr @r9 ; mov #23,r5
    c.r[2] = c.r[0];  // 0606EABC mov r0,r2
    c.r[5] = 0x5u;  // 0606EABE mov #5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606EAC4u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAC4u) return; }  // 0606EAC0 jsr @r9 ; mov r2,r4
    c.r[2] = c.r[0];  // 0606EAC4 mov r0,r2
    c.r[6] = 0x0u;  // 0606EAC6 mov #0,r6
    c.r[5] = 0x0u;  // 0606EAC8 mov #0,r5
    c.r[3] = ld32(0x0606EB78u);  // 0606EACA mov.l 0x0606EB78,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606EAD0u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAD0u) return; }  // 0606EACC jsr @r3 ; mov r2,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606EAD4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAD4u) return; }  // 0606EAD0 jsr @r8 ; mov #0,r4
    c.r[4] = ld32(0x0606EB64u);  // 0606EAD4 mov.l 0x0606EB64,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606EADAu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EADAu) return; }  // 0606EAD6 jsr @r9 ; mov #23,r5
    c.r[2] = c.r[0];  // 0606EADA mov r0,r2
    c.r[5] = 0x5u;  // 0606EADC mov #5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606EAE2u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAE2u) return; }  // 0606EADE jsr @r9 ; mov r2,r4
    c.r[2] = c.r[0];  // 0606EAE2 mov r0,r2
    c.r[6] = 0x0u;  // 0606EAE4 mov #0,r6
    c.r[5] = 0x1u;  // 0606EAE6 mov #1,r5
    c.r[0] = ld32(0x0606EB78u);  // 0606EAE8 mov.l 0x0606EB78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606EAEEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAEEu) return; }  // 0606EAEA jsr @r0 ; mov r2,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606EB52u);  // 0606EAEE mov.w 0x0606EB52,r12
    c.r[13] = ld32(0x0606EB60u);  // 0606EAF0 mov.l 0x0606EB60,r13
    c.r[5] = c.r[12];  // 0606EAF2 mov r12,r5
    c.r[6] = ld32(c.r[14] + 20);  // 0606EAF4 mov.l @(20,r14),r6
    { const uint32_t x = c.r[13]; c.pr = 0x0606EAFAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAFAu) return; }  // 0606EAF6 jsr @r13 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606EAFEu; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EAFEu) return; }  // 0606EAFA jsr @r8 ; mov #14,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606EB02u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB02u) return; }  // 0606EAFE jsr @r8 ; mov #0,r4
    c.r[4] = ld32(0x0606EB64u);  // 0606EB02 mov.l 0x0606EB64,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606EB08u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB08u) return; }  // 0606EB04 jsr @r9 ; mov #23,r5
    c.r[2] = c.r[0];  // 0606EB08 mov r0,r2
    c.r[5] = 0x5u;  // 0606EB0A mov #5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606EB10u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB10u) return; }  // 0606EB0C jsr @r9 ; mov r2,r4
    c.r[2] = c.r[0];  // 0606EB10 mov r0,r2
    c.r[6] = 0x0u;  // 0606EB12 mov #0,r6
    c.r[5] = 0x2u;  // 0606EB14 mov #2,r5
    c.r[1] = ld32(0x0606EB78u);  // 0606EB16 mov.l 0x0606EB78,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EB1Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB1Cu) return; }  // 0606EB18 jsr @r1 ; mov r2,r4
    c.r[5] = c.r[12];  // 0606EB1C mov r12,r5
    c.r[6] = ld32(c.r[14] + 24);  // 0606EB1E mov.l @(24,r14),r6
    { const uint32_t x = c.r[13]; c.pr = 0x0606EB24u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB24u) return; }  // 0606EB20 jsr @r13 ; mov #0,r4
    c.r[4] = 0xEu; goto L_0606EB30;  // 0606EB24 bra 0x0606EB30 ; mov #14,r4
L_0606EB28:
    c.r[8] = ld32(0x0606EB5Cu);  // 0606EB28 mov.l 0x0606EB5C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606EB2Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB2Eu) return; }  // 0606EB2A jsr @r8 ; mov #0,r4
    c.r[4] = 0x0u;  // 0606EB2E mov #0,r4
L_0606EB30:
    { const uint32_t x = c.r[8]; c.pr = 0x0606EB34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB34u) return; }  // 0606EB30 jsr @r8 ; nop
    c.r[1] = ld32(0x0606EB7Cu);  // 0606EB34 mov.l 0x0606EB7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EB3Au; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB3Au) return; }  // 0606EB36 jsr @r1 ; mov #10,r4
    c.r[14] += 56;  // 0606EB3A add #56,r14
    c.r[15] = c.r[14];  // 0606EB3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606EB3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606EB40 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606EB42 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606EB44 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606EB46 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606EB48 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606EB4A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606EB5Au);  // 0606EB4C mov.w 0x0606EB5A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606EB4E rts ; mov.l @r15+,r8
}

void f_0606EB80(SH2Context& c) {
    ran[1571] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606EB80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606EB82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606EB84 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606EB86 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606EB88 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606EB8A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606EB8C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606EB8E mov r15,r14
    c.r[1] = ld32(0x0606EC94u);  // 0606EB90 mov.l 0x0606EC94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EB96u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB96u) return; }  // 0606EB92 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606EC98u);  // 0606EB96 mov.l 0x0606EC98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EB9Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EB9Cu) return; }  // 0606EB98 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606EC9Cu);  // 0606EB9C mov.l 0x0606EC9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EBA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EBA2u) return; }  // 0606EB9E jsr @r1 ; nop
    c.r[1] = ld32(0x0606ECA0u);  // 0606EBA2 mov.l 0x0606ECA0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EBA4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606EBA6 extu.b r1,r1
    c.r[1] += c.r[1];  // 0606EBA8 add r1,r1
    c.r[1] -= 3;  // 0606EBAA add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606EBAC cmp/pz r1
    { const bool k = c.t; c.r[10] = c.r[1] & 0xFFu; if (k) { goto L_0606EBB4; } }  // 0606EBAE bt/s 0x0606EBB4 ; extu.b r1,r10
    c.r[10] = 0x0u;  // 0606EBB2 mov #0,r10
L_0606EBB4:
    c.r[2] = c.r[10];  // 0606EBB4 mov r10,r2
    c.r[2] += 11;  // 0606EBB6 add #11,r2
    c.r[1] = 0x27u;  // 0606EBB8 mov #39,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606EBBA cmp/gt r1,r2
    if (!c.t) { goto L_0606EBC0; }  // 0606EBBC bf 0x0606EBC0
    c.r[10] = 0x1Du;  // 0606EBBE mov #29,r10
L_0606EBC0:
    c.r[1] = ld32(0x0606ECA4u);  // 0606EBC0 mov.l 0x0606ECA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EBC2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606EBC4 extu.b r1,r1
    c.r[1] += c.r[1];  // 0606EBC6 add r1,r1
    c.r[1] -= 3;  // 0606EBC8 add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606EBCA cmp/pz r1
    { const bool k = c.t; c.r[9] = c.r[1] & 0xFFu; if (k) { goto L_0606EBD2; } }  // 0606EBCC bt/s 0x0606EBD2 ; extu.b r1,r9
    c.r[9] = 0x0u;  // 0606EBD0 mov #0,r9
L_0606EBD2:
    c.r[2] = c.r[9];  // 0606EBD2 mov r9,r2
    c.r[2] += 14;  // 0606EBD4 add #14,r2
    c.r[1] = 0x1Au;  // 0606EBD6 mov #26,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606EBD8 cmp/gt r1,r2
    if (!c.t) { goto L_0606EBDE; }  // 0606EBDA bf 0x0606EBDE
    c.r[9] = 0xCu;  // 0606EBDC mov #12,r9
L_0606EBDE:
    c.r[11] = ld32(0x0606ECA8u);  // 0606EBDE mov.l 0x0606ECA8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0606EBE4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EBE4u) return; }  // 0606EBE0 jsr @r11 ; mov r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606EBE8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EBE8u) return; }  // 0606EBE4 jsr @r11 ; mov r9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606EC8Cu);  // 0606EBE8 mov.w 0x0606EC8C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606EBEEu; c.r[8] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EBEEu) return; }  // 0606EBEA jsr @r11 ; mov r10,r8
    c.r[8] += 1;  // 0606EBEE add #1,r8
    c.r[8] = c.r[8] & 0xFFu;  // 0606EBF0 extu.b r8,r8
    { const uint32_t x = c.r[11]; c.pr = 0x0606EBF6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EBF6u) return; }  // 0606EBF2 jsr @r11 ; mov r8,r4
    c.r[9] += 1;  // 0606EBF6 add #1,r9
    c.r[7] = 0x7u;  // 0606EBF8 mov #7,r7
    { const uint32_t x = c.r[11]; c.pr = 0x0606EBFEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EBFEu) return; }  // 0606EBFA jsr @r11 ; mov r9,r4
    c.r[6] = 0x9u;  // 0606EBFE mov #9,r6
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606EC00 mov.l r7,@-r15
    c.r[12] = 0x1u;  // 0606EC02 mov #1,r12
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606EC04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606EC06 mov.l r12,@-r15
    c.r[1] = 0x0u;  // 0606EC08 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606EC0A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606EC0C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606EC0E mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606EC10 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606EC12 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606EC14 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606EC16 mov.l r12,@-r15
    c.r[1] = ld32(0x0606ECACu);  // 0606EC18 mov.l 0x0606ECAC,r1
    c.r[7] = 0x2u;  // 0606EC1A mov #2,r7
    c.r[5] = c.r[9];  // 0606EC1C mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606EC22u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC22u) return; }  // 0606EC1E jsr @r1 ; mov r8,r4
    c.r[15] += 40;  // 0606EC22 add #40,r15
    c.r[1] = 0xFu;  // 0606EC24 mov #15,r1
    c.t = c.r[10] > c.r[1];  // 0606EC26 cmp/hi r1,r10
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0606EC2E; } }  // 0606EC28 bt/s 0x0606EC2E ; mov #0,r10
    c.r[10] = 0x1Bu;  // 0606EC2C mov #27,r10
L_0606EC2E:
    { const uint32_t x = c.r[11]; c.pr = 0x0606EC32u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC32u) return; }  // 0606EC2E jsr @r11 ; mov r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606EC36u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC36u) return; }  // 0606EC32 jsr @r11 ; mov r12,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606EC8Eu);  // 0606EC36 mov.w 0x0606EC8E,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606EC3Cu; c.r[10] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC3Cu) return; }  // 0606EC38 jsr @r11 ; add #1,r10
    { const uint32_t x = c.r[11]; c.pr = 0x0606EC40u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC40u) return; }  // 0606EC3C jsr @r11 ; extu.b r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606EC44u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC44u) return; }  // 0606EC40 jsr @r11 ; mov #2,r4
    c.r[8] = ld32(0x0606ECB0u);  // 0606EC44 mov.l 0x0606ECB0,r8
    c.r[9] = ld32(0x0606ECB4u);  // 0606EC46 mov.l 0x0606ECB4,r9
    c.r[1] = ld32(c.r[8]);  // 0606EC48 mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606EC4A mov #0,r5
    c.r[1] += 16;  // 0606EC4C add #16,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EC4E mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606EC50 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0606EC52 extu.b r6,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0606EC58u; c.t = c.r[6] & 1; c.r[6] >>= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC58u) return; }  // 0606EC54 jsr @r9 ; shlr r6
    c.r[5] = 0x0u;  // 0606EC58 mov #0,r5
    c.r[2] = ld32(c.r[8]);  // 0606EC5A mov.l @r8,r2
    c.r[4] = 0x0u;  // 0606EC5C mov #0,r4
    c.r[1] = c.r[2];  // 0606EC5E mov r2,r1
    c.r[1] += 10;  // 0606EC60 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606EC62 mov.w @r1,r1
    c.r[2] += 12;  // 0606EC64 add #12,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606EC66 mov.b @r2,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606EC68 extu.w r1,r1
    c.r[1] <<= 8;  // 0606EC6A shll8 r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606EC6C extu.b r6,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0606EC72u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC72u) return; }  // 0606EC6E jsr @r9 ; or r1,r6
    c.r[1] = ld32(0x0606ECB8u);  // 0606EC72 mov.l 0x0606ECB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EC78u; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EC78u) return; }  // 0606EC74 jsr @r1 ; mov #11,r4
    c.r[15] = c.r[14];  // 0606EC78 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606EC7A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606EC7C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606EC7E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606EC80 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606EC82 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606EC84 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606EC90u);  // 0606EC86 mov.w 0x0606EC90,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606EC88 rts ; mov.l @r15+,r8
}

void f_0606ECBC(SH2Context& c) {
    ran[1572] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606ECBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606ECBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606ECC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606ECC2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606ECC4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606ECC6 mov r15,r14
    c.r[1] = ld32(0x0606ED88u);  // 0606ECC8 mov.l 0x0606ED88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ECCEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ECCEu) return; }  // 0606ECCA jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606ED8Cu);  // 0606ECCE mov.l 0x0606ED8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ECD4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ECD4u) return; }  // 0606ECD0 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606ED90u);  // 0606ECD4 mov.l 0x0606ED90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ECDAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ECDAu) return; }  // 0606ECD6 jsr @r1 ; nop
    c.r[1] = ld32(0x0606ED94u);  // 0606ECDA mov.l 0x0606ED94,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606ECDC mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0606ECDE extu.b r1,r9
    c.r[9] >>= 2;  // 0606ECE0 shlr2 r9
    c.r[9] >>= 2;  // 0606ECE2 shlr2 r9
    c.r[1] = 0x9u;  // 0606ECE4 mov #9,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0606ECE6 cmp/gt r1,r9
    if (!c.t) { goto L_0606ECF0; }  // 0606ECE8 bf 0x0606ECF0
    c.r[9] += 12;  // 0606ECEA add #12,r9
    goto L_0606ECF2;  // 0606ECEC bra 0x0606ECF2 ; nop
L_0606ECF0:
    c.r[9] += 48;  // 0606ECF0 add #48,r9
L_0606ECF2:
    c.r[1] = ld32(0x0606ED98u);  // 0606ECF2 mov.l 0x0606ED98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ECF8u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ECF8u) return; }  // 0606ECF4 jsr @r1 ; extu.b r9,r4
    c.r[1] = ld32(0x0606ED94u);  // 0606ECF8 mov.l 0x0606ED94,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606ECFA mov.b @r1,r0
    c.r[9] = 0xFu;  // 0606ECFC mov #15,r9
    c.r[9] &= c.r[0];  // 0606ECFE and r0,r9
    c.r[1] = 0x9u;  // 0606ED00 mov #9,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0606ED02 cmp/gt r1,r9
    if (!c.t) { goto L_0606ED0C; }  // 0606ED04 bf 0x0606ED0C
    c.r[9] += 12;  // 0606ED06 add #12,r9
    goto L_0606ED0E;  // 0606ED08 bra 0x0606ED0E ; nop
L_0606ED0C:
    c.r[9] += 48;  // 0606ED0C add #48,r9
L_0606ED0E:
    c.r[1] = ld32(0x0606ED98u);  // 0606ED0E mov.l 0x0606ED98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ED14u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ED14u) return; }  // 0606ED10 jsr @r1 ; extu.b r9,r4
    c.r[1] = ld32(0x0606ED94u);  // 0606ED14 mov.l 0x0606ED94,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606ED16 mov.b @r1,r1
    c.r[8] = 0x0u;  // 0606ED18 mov #0,r8
    c.r[10] = ld32(0x0606ED9Cu);  // 0606ED1A mov.l 0x0606ED9C,r10
    c.r[9] = c.r[1] & 0xFFu;  // 0606ED1C extu.b r1,r9
    c.r[9] <<= 2;  // 0606ED1E shll2 r9
    c.r[9] <<= 2;  // 0606ED20 shll2 r9
    c.r[2] = c.r[9];  // 0606ED22 mov r9,r2
L_0606ED24:
    c.r[2] += c.r[8];  // 0606ED24 add r8,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0606ED26 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606ED2E; } }  // 0606ED28 bt/s 0x0606ED2E ; mov r2,r1
    c.r[1] += 7;  // 0606ED2C add #7,r1
L_0606ED2E:
    c.r[0] = c.r[1];  // 0606ED2E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0606ED30 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0606ED32 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0606ED34 shar r0
    c.r[1] = ld32(0x0606EDA0u);  // 0606ED36 mov.l 0x0606EDA0,r1
    c.r[1] = ld32(c.r[1]);  // 0606ED38 mov.l @r1,r1
    c.r[5] = c.r[2];  // 0606ED3A mov r2,r5
    c.r[0] += c.r[1];  // 0606ED3C add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606ED84u);  // 0606ED3E mov.w 0x0606ED84,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606ED40 mov.b @(r0,r1),r1
    c.t = (int32_t)c.r[2] >= 0;  // 0606ED42 cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0606ED4A; } }  // 0606ED44 bt/s 0x0606ED4A ; extu.b r1,r4
    c.r[5] += 7;  // 0606ED48 add #7,r5
L_0606ED4A:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0606ED4A shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0606ED4C shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0606ED4E shar r5
    c.r[5] <<= 2;  // 0606ED50 shll2 r5
    c.r[5] += c.r[5];  // 0606ED52 add r5,r5
    c.r[5] -= c.r[2];  // 0606ED54 sub r2,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606ED5Au; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ED5Au) return; }  // 0606ED56 jsr @r10 ; add #7,r5
    c.r[0] &= 0x1u;  // 0606ED5A and #1,r0
    c.r[0] += 48;  // 0606ED5C add #48,r0
    c.r[1] = ld32(0x0606ED98u);  // 0606ED5E mov.l 0x0606ED98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ED64u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ED64u) return; }  // 0606ED60 jsr @r1 ; extu.b r0,r4
    c.r[8] += 1;  // 0606ED64 add #1,r8
    c.r[1] = 0xFu;  // 0606ED66 mov #15,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606ED68 cmp/gt r1,r8
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { SH2_POLL(c); goto L_0606ED24; } }  // 0606ED6A bf/s 0x0606ED24 ; mov r9,r2
    c.r[1] = ld32(0x0606EDA4u);  // 0606ED6E mov.l 0x0606EDA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606ED74u; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ED74u) return; }  // 0606ED70 jsr @r1 ; mov #12,r4
    c.r[15] = c.r[14];  // 0606ED74 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606ED76 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606ED78 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606ED7A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606ED7C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606ED86u);  // 0606ED7E mov.w 0x0606ED86,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606ED80 rts ; mov.l @r15+,r8
}

void f_0606EDA8(SH2Context& c) {
    ran[1573] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606EDA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606EDAA sts.l pr,@-r15
    c.r[15] -= 12;  // 0606EDAC add #-12,r15
    c.r[14] = c.r[15];  // 0606EDAE mov r15,r14
    c.r[1] = ld32(0x0606EE6Cu);  // 0606EDB0 mov.l 0x0606EE6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EDB6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EDB6u) return; }  // 0606EDB2 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606EE70u);  // 0606EDB6 mov.l 0x0606EE70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EDBCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EDBCu) return; }  // 0606EDB8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606EE74u);  // 0606EDBC mov.l 0x0606EE74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EDC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EDC2u) return; }  // 0606EDBE jsr @r1 ; nop
    c.r[1] = ld32(0x0606EE78u);  // 0606EDC2 mov.l 0x0606EE78,r1
    c.r[1] = ld32(c.r[1]);  // 0606EDC4 mov.l @r1,r1
    c.r[1] += 1;  // 0606EDC6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EDC8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606EDCA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606EDCC tst r1,r1
    { const bool k = c.t; c.r[1] = 0xFFFFFFAEu; if (k) { goto L_0606EDEC; } }  // 0606EDCE bt/s 0x0606EDEC ; mov #-82,r1
    st8(c.r[14], c.r[1]);  // 0606EDD2 mov.b r1,@r14
    c.r[2] = c.r[14];  // 0606EDD4 mov r14,r2
    c.r[2] += 1;  // 0606EDD6 add #1,r2
    c.r[1] = 0xFFFFFF93u;  // 0606EDD8 mov #-109,r1
    st8(c.r[2], c.r[1]);  // 0606EDDA mov.b r1,@r2
    c.r[2] = c.r[14];  // 0606EDDC mov r14,r2
    c.r[2] += 2;  // 0606EDDE add #2,r2
    c.r[1] = 0xFFFFFFB7u;  // 0606EDE0 mov #-73,r1
    st8(c.r[2], c.r[1]);  // 0606EDE2 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0606EDE4 mov r14,r2
    c.r[2] += 3;  // 0606EDE6 add #3,r2
    c.r[1] = 0xFFFFFFDAu; goto L_0606EE06;  // 0606EDE8 bra 0x0606EE06 ; mov #-38,r1
L_0606EDEC:
    c.r[1] = 0xFFFFFFCDu;  // 0606EDEC mov #-51,r1
    st8(c.r[14], c.r[1]);  // 0606EDEE mov.b r1,@r14
    c.r[2] = c.r[14];  // 0606EDF0 mov r14,r2
    c.r[2] += 1;  // 0606EDF2 add #1,r2
    c.r[1] = 0xFFFFFFB2u;  // 0606EDF4 mov #-78,r1
    st8(c.r[2], c.r[1]);  // 0606EDF6 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0606EDF8 mov r14,r2
    c.r[2] += 2;  // 0606EDFA add #2,r2
    c.r[1] = 0xFFFFFFC6u;  // 0606EDFC mov #-58,r1
    st8(c.r[2], c.r[1]);  // 0606EDFE mov.b r1,@r2
    c.r[2] = c.r[14];  // 0606EE00 mov r14,r2
    c.r[2] += 3;  // 0606EE02 add #3,r2
    c.r[1] = 0xFFFFFFE5u;  // 0606EE04 mov #-27,r1
L_0606EE06:
    st8(c.r[2], c.r[1]);  // 0606EE06 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0606EE08 mov r14,r2
    c.r[2] += 4;  // 0606EE0A add #4,r2
    c.r[1] = 0x0u;  // 0606EE0C mov #0,r1
    st8(c.r[2], c.r[1]);  // 0606EE0E mov.b r1,@r2
    c.r[2] = c.r[14];  // 0606EE10 mov r14,r2
    c.r[1] = ld32(0x0606EE7Cu);  // 0606EE12 mov.l 0x0606EE7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EE14 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606EE16 extu.b r1,r0
    c.r[0] >>= 2;  // 0606EE18 shlr2 r0
    c.r[0] >>= 2;  // 0606EE1A shlr2 r0
    c.r[1] = 0x9u;  // 0606EE1C mov #9,r1
    c.t = c.r[0] > c.r[1];  // 0606EE1E cmp/hi r1,r0
    { const bool k = !c.t; c.r[2] += 5; if (k) { goto L_0606EE28; } }  // 0606EE20 bf/s 0x0606EE28 ; add #5,r2
    c.r[0] += 12; goto L_0606EE2A;  // 0606EE24 bra 0x0606EE2A ; add #12,r0
L_0606EE28:
    c.r[0] |= 0x30u;  // 0606EE28 or #48,r0
L_0606EE2A:
    st8(c.r[2], c.r[0]);  // 0606EE2A mov.b r0,@r2
    c.r[1] = ld32(0x0606EE7Cu);  // 0606EE2C mov.l 0x0606EE7C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EE2E mov.b @r1,r0
    c.r[2] = c.r[14];  // 0606EE30 mov r14,r2
    c.r[0] &= 0xFu;  // 0606EE32 and #15,r0
    c.r[1] = 0x9u;  // 0606EE34 mov #9,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0606EE36 cmp/gt r1,r0
    { const bool k = !c.t; c.r[2] += 6; if (k) { goto L_0606EE40; } }  // 0606EE38 bf/s 0x0606EE40 ; add #6,r2
    c.r[0] += 12; goto L_0606EE42;  // 0606EE3C bra 0x0606EE42 ; add #12,r0
L_0606EE40:
    c.r[0] += 48;  // 0606EE40 add #48,r0
L_0606EE42:
    st8(c.r[2], c.r[0]);  // 0606EE42 mov.b r0,@r2
    c.r[2] = c.r[14];  // 0606EE44 mov r14,r2
    c.r[2] += 7;  // 0606EE46 add #7,r2
    c.r[1] = 0xFFFFFFFFu;  // 0606EE48 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0606EE4A mov.b r1,@r2
    c.r[1] = ld32(0x0606EE80u);  // 0606EE4C mov.l 0x0606EE80,r1
    c.r[6] = 0x0u;  // 0606EE4E mov #0,r6
    c.r[5] = c.r[14];  // 0606EE50 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606EE56u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EE56u) return; }  // 0606EE52 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606EE84u);  // 0606EE56 mov.l 0x0606EE84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EE5Cu; c.r[4] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EE5Cu) return; }  // 0606EE58 jsr @r1 ; mov #13,r4
    c.r[14] += 12;  // 0606EE5C add #12,r14
    c.r[15] = c.r[14];  // 0606EE5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606EE60 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606EE68u);  // 0606EE62 mov.w 0x0606EE68,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606EE64 rts ; mov.l @r15+,r14
}

void f_0606EE88(SH2Context& c) {
    ran[1574] = 1;
L_0606EE88:
    c.r[0] = ld32(0x0606EE90u);  // 0606EE88 mov.l 0x0606EE90,r0
L_0606EE8A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0606EE88u: goto L_0606EE88; case 0x0606EE8Au: goto L_0606EE8A; default: sh2_call(c, x); return; } }  // 0606EE8A jmp @r0 ; nop
}

void f_0606EE94(SH2Context& c) {
    ran[1575] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606EE94 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606EE96 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606EEF8u);  // 0606EE98 mov.w 0x0606EEF8,r3
    c.r[15] += c.r[3];  // 0606EE9A add r3,r15
    c.r[14] = c.r[15];  // 0606EE9C mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606EEFAu);  // 0606EE9E mov.w 0x0606EEFA,r0
    c.r[2] = c.r[14];  // 0606EEA0 mov r14,r2
    c.r[2] += c.r[0];  // 0606EEA2 add r0,r2
    c.r[1] = 0x1u;  // 0606EEA4 mov #1,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 0606EEA6 mov.b r1,@(r0,r14)
    c.r[2] += 1;  // 0606EEA8 add #1,r2
    c.r[1] = 0x0u;  // 0606EEAA mov #0,r1
    st8(c.r[2], c.r[1]);  // 0606EEAC mov.b r1,@r2
    c.r[6] = ld32(0x0606EEFCu);  // 0606EEAE mov.l 0x0606EEFC,r6
    c.r[1] = c.r[6];  // 0606EEB0 mov r6,r1
    c.r[1] += 1;  // 0606EEB2 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EEB4 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606EEB6 extu.b r2,r2
    c.r[1] = ld32(0x0606EF00u);  // 0606EEB8 mov.l 0x0606EF00,r1
    c.r[3] = ld32(c.r[1]);  // 0606EEBA mov.l @r1,r3
    c.r[2] <<= 2;  // 0606EEBC shll2 r2
    c.r[2] <<= 2;  // 0606EEBE shll2 r2
    c.r[2] += c.r[3];  // 0606EEC0 add r3,r2
    c.r[2] += 3;  // 0606EEC2 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606EEC4 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606EEC6 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606EEC8 shlr r0
    c.r[0] &= 0x3u;  // 0606EECA and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606EECC tst r0,r0
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_0606EF04; } }  // 0606EECE bf/s 0x0606EF04 ; mov #0,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606EED2 mov.b @r6,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606EED4 extu.b r1,r2
    c.r[2] <<= 2;  // 0606EED6 shll2 r2
    c.r[2] <<= 2;  // 0606EED8 shll2 r2
    c.r[2] += c.r[3];  // 0606EEDA add r3,r2
    c.r[1] = c.r[2];  // 0606EEDC mov r2,r1
    c.r[1] += 3;  // 0606EEDE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EEE0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606EEE2 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606EEE4 shlr r0
    c.r[0] &= 0x3u;  // 0606EEE6 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606EEE8 tst r0,r0
    if (!c.t) { goto L_0606EF20; }  // 0606EEEA bf 0x0606EF20
    c.r[1] = ld32(c.r[2] + 12);  // 0606EEEC mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606EEEE tst r1,r1
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0606EF24; } }  // 0606EEF0 bt/s 0x0606EF24 ; tst r13,r13
    c.r[13] = 0x1u; goto L_0606EF22;  // 0606EEF4 bra 0x0606EF22 ; mov #1,r13
L_0606EF04:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606EF04 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606EF06 extu.b r1,r1
    c.r[1] <<= 2;  // 0606EF08 shll2 r1
    c.r[1] <<= 2;  // 0606EF0A shll2 r1
    c.r[1] += c.r[3];  // 0606EF0C add r3,r1
    c.r[1] += 3;  // 0606EF0E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EF10 mov.b @r1,r1
    c.r[0] = 0x3u;  // 0606EF12 mov #3,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606EF14 shlr r1
    c.r[1] &= c.r[0];  // 0606EF16 and r0,r1
    c.r[0] = c.r[1];  // 0606EF18 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0606EF1A cmp/eq #1,r0
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0606EF24; } }  // 0606EF1C bf/s 0x0606EF24 ; tst r13,r13
L_0606EF20:
    c.r[13] = 0x1u;  // 0606EF20 mov #1,r13
L_0606EF22:
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606EF22 tst r13,r13
L_0606EF24:
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0606EF36; } }  // 0606EF24 bt/s 0x0606EF36 ; mov r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F056u);  // 0606EF28 mov.w 0x0606F056,r0
    c.r[1] += c.r[0];  // 0606EF2A add r0,r1
    c.r[2] = 0x0u;  // 0606EF2C mov #0,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 0606EF2E mov.b r2,@(r0,r14)
    c.r[1] += 1;  // 0606EF30 add #1,r1
    c.r[2] = 0x1u;  // 0606EF32 mov #1,r2
    st8(c.r[1], c.r[2]);  // 0606EF34 mov.b r2,@r1
L_0606EF36:
    c.r[1] = ld32(0x0606F064u);  // 0606EF36 mov.l 0x0606F064,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EF3Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EF3Cu) return; }  // 0606EF38 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606F068u);  // 0606EF3C mov.l 0x0606F068,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EF42u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EF42u) return; }  // 0606EF3E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606F06Cu);  // 0606EF42 mov.l 0x0606F06C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EF48u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EF48u) return; }  // 0606EF44 jsr @r1 ; nop
    c.r[1] = ld32(0x0606F070u);  // 0606EF48 mov.l 0x0606F070,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EF4Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EF4Eu) return; }  // 0606EF4A jsr @r1 ; mov #1,r4
    c.r[0] = 0x0u;  // 0606EF4E mov #0,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F058u);  // 0606EF50 mov.w 0x0606F058,r7
    c.r[7] += c.r[14];  // 0606EF52 add r14,r7
    st32(c.r[7], c.r[0]);  // 0606EF54 mov.l r0,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F056u);  // 0606EF56 mov.w 0x0606F056,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F05Au);  // 0606EF58 mov.w 0x0606F05A,r7
    c.r[7] += c.r[14];  // 0606EF5A add r14,r7
    st32(c.r[7], c.r[0]);  // 0606EF5C mov.l r0,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F05Au);  // 0606EF5E mov.w 0x0606F05A,r7
    c.r[7] += c.r[14];  // 0606EF60 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606EF62 mov.l @r7,r0
    c.r[11] = ld32(0x0606F074u);  // 0606EF64 mov.l 0x0606F074,r11
    c.r[0] += c.r[14];  // 0606EF66 add r14,r0
    st32(c.r[7], c.r[0]);  // 0606EF68 mov.l r0,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F05Au);  // 0606EF6A mov.w 0x0606F05A,r7
    c.r[7] += c.r[14];  // 0606EF6C add r14,r7
    c.r[12] = ld32(c.r[7]);  // 0606EF6E mov.l @r7,r12
L_0606EF70:
    c.r[0] = ld32(0x0606F078u);  // 0606EF70 mov.l 0x0606F078,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606EF72 mov.b @r12,r1
    c.r[7] = ld32(0x0606F07Cu);  // 0606EF74 mov.l 0x0606F07C,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606EF76 extu.b r1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606EF78 mov.b @(r0,r1),r6
    c.r[4] = c.r[14];  // 0606EF7A mov r14,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0606EF7C extu.b r6,r6
    c.r[2] = c.r[6];  // 0606EF7E mov r6,r2
    c.r[1] = ld32(c.r[7]);  // 0606EF80 mov.l @r7,r1
    c.r[2] <<= 2;  // 0606EF82 shll2 r2
    c.r[2] <<= 2;  // 0606EF84 shll2 r2
    c.r[2] += c.r[1];  // 0606EF86 add r1,r2
    c.r[2] += 2;  // 0606EF88 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606EF8A mov.b @r2,r5
    c.r[1] = ld32(0x0606F080u);  // 0606EF8C mov.l 0x0606F080,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606EF92u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EF92u) return; }  // 0606EF8E jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0606EF92 mov r14,r1
    c.r[1] += 14;  // 0606EF94 add #14,r1
    c.r[2] = ld32(0x0606F084u);  // 0606EF96 mov.l 0x0606F084,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EF98 mov.b @r1,r5
    c.r[4] = c.r[14];  // 0606EF9A mov r14,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0606EF9C extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F05Cu);  // 0606EF9E mov.w 0x0606F05C,r1
    { const uint32_t x = c.r[2]; c.pr = 0x0606EFA4u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606EFA4u) return; }  // 0606EFA0 jsr @r2 ; add r1,r4
    c.r[1] = ld32(0x0606F088u);  // 0606EFA4 mov.l 0x0606F088,r1
    c.r[1] = ld32(c.r[1]);  // 0606EFA6 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606F05Eu);  // 0606EFA8 mov.w 0x0606F05E,r2
    c.r[0] = c.r[1];  // 0606EFAA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606EFAC mov.b @(r0,r2),r1
    c.r[7] = 0x10u;  // 0606EFAE mov #16,r7
    c.r[1] &= c.r[7];  // 0606EFB0 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606EFB2 tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_0606EFDC; } }  // 0606EFB4 bf/s 0x0606EFDC ; mov #0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606EFB8 mov.b @r12,r1
    c.r[0] = ld32(0x0606F078u);  // 0606EFBA mov.l 0x0606F078,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0606EFBC extu.b r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606EFBE mov.b @(r0,r1),r1
    c.r[7] = ld32(0x0606F07Cu);  // 0606EFC0 mov.l 0x0606F07C,r7
    c.r[2] = ld32(c.r[7]);  // 0606EFC2 mov.l @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606EFC4 extu.b r1,r1
    c.r[1] <<= 2;  // 0606EFC6 shll2 r1
    c.r[1] <<= 2;  // 0606EFC8 shll2 r1
    c.r[1] += c.r[2];  // 0606EFCA add r2,r1
    c.r[1] += 7;  // 0606EFCC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606EFCE mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606EFD0 mov #1,r0
    c.r[1] >>= 2;  // 0606EFD2 shlr2 r1
    c.r[1] &= c.r[0];  // 0606EFD4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606EFD6 tst r1,r1
    { const bool k = c.t; c.r[13] = c.r[3]; if (k) { goto L_0606EFE0; } }  // 0606EFD8 bt/s 0x0606EFE0 ; mov r3,r13
L_0606EFDC:
    c.r[3] = 0x1u;  // 0606EFDC mov #1,r3
    c.r[13] = c.r[3];  // 0606EFDE mov r3,r13
L_0606EFE0:
    c.r[1] = ld32(0x0606F088u);  // 0606EFE0 mov.l 0x0606F088,r1
    c.r[1] = ld32(c.r[1]);  // 0606EFE2 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F05Eu);  // 0606EFE4 mov.w 0x0606F05E,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606EFE6 mov.b @(r0,r1),r0
    c.r[0] &= 0x10u;  // 0606EFE8 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606EFEA tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_0606F034; } }  // 0606EFEC bf/s 0x0606F034 ; mov #0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606EFF0 mov.b @r12,r1
    c.r[0] = ld32(0x0606F078u);  // 0606EFF2 mov.l 0x0606F078,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0606EFF4 extu.b r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606EFF6 mov.b @(r0,r1),r1
    c.r[7] = ld32(0x0606F07Cu);  // 0606EFF8 mov.l 0x0606F07C,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0606EFFA extu.b r1,r2
    c.r[1] = ld32(c.r[7]);  // 0606EFFC mov.l @r7,r1
    c.r[2] <<= 2;  // 0606EFFE shll2 r2
    c.r[2] <<= 2;  // 0606F000 shll2 r2
    c.r[2] += c.r[1];  // 0606F002 add r1,r2
    c.r[1] = c.r[2];  // 0606F004 mov r2,r1
    c.r[1] += 7;  // 0606F006 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F008 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606F00A mov #1,r0
    c.r[1] >>= 2;  // 0606F00C shlr2 r1
    c.r[1] &= c.r[0];  // 0606F00E and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606F010 tst r1,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0606F038; } }  // 0606F012 bt/s 0x0606F038 ; tst r3,r3
    c.r[2] += 3;  // 0606F016 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606F018 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606F01A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606F01C shlr r0
    c.r[0] &= 0x3u;  // 0606F01E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606F020 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0606F034; } }  // 0606F022 bt/s 0x0606F034 ; mov r14,r1
    c.r[1] += 22;  // 0606F026 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F028 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606F060u);  // 0606F02A mov.w 0x0606F060,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606F02C extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0606F02E cmp/hi r2,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0606F038; } }  // 0606F030 bt/s 0x0606F038 ; tst r3,r3
L_0606F034:
    c.r[3] = 0x1u;  // 0606F034 mov #1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606F036 tst r3,r3
L_0606F038:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606F08C; } }  // 0606F038 bt/s 0x0606F08C ; mov #0,r5
    c.r[1] = c.r[14];  // 0606F03C mov r14,r1
    c.r[1] += 22;  // 0606F03E add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F040 mov.w @r1,r6
    c.r[4] = 0x1u;  // 0606F042 mov #1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606F048u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F048u) return; }  // 0606F044 jsr @r11 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 0606F048 mov r14,r1
    c.r[1] += 26;  // 0606F04A add #26,r1
    c.r[5] = 0x0u;  // 0606F04C mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F04E mov.w @r1,r6
    c.r[4] = 0x1u;  // 0606F050 mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_0606F098;  // 0606F052 bra 0x0606F098 ; extu.w r6,r6
L_0606F08C:
    c.r[6] = 0xFFFFFFFFu;  // 0606F08C mov #-1,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0606F092u; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F092u) return; }  // 0606F08E jsr @r11 ; mov #81,r4
    c.r[6] = 0xFFFFFFFFu;  // 0606F092 mov #-1,r6
    c.r[5] = 0x0u;  // 0606F094 mov #0,r5
    c.r[4] = 0x51u;  // 0606F096 mov #81,r4
L_0606F098:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F09Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F09Cu) return; }  // 0606F098 jsr @r11 ; nop
    c.r[1] = c.r[14];  // 0606F09C mov r14,r1
    c.r[1] += 26;  // 0606F09E add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F0A0 mov.w @r1,r5
    c.r[6] = 0xDu;  // 0606F0A2 mov #13,r6
    c.r[1] = c.r[14];  // 0606F0A4 mov r14,r1
    c.r[1] += 22;  // 0606F0A6 add #22,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F0A8 mov.w @r1,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0606F0AA extu.w r5,r5
    c.r[1] = ld32(0x0606F204u);  // 0606F0AC mov.l 0x0606F204,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F0B2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F0B2u) return; }  // 0606F0AE jsr @r1 ; extu.w r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606F0B2 tst r13,r13
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_0606F0E6; } }  // 0606F0B4 bt/s 0x0606F0E6 ; mov #-1,r6
    c.r[1] = c.r[14];  // 0606F0B8 mov r14,r1
    c.r[1] += 24;  // 0606F0BA add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F0BC mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0606F0BE extu.w r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F1F0u);  // 0606F0C0 mov.w 0x0606F1F0,r1
    c.t = c.r[6] == c.r[1];  // 0606F0C2 cmp/eq r1,r6
    if (!c.t) { goto L_0606F0D2; }  // 0606F0C4 bf 0x0606F0D2
    c.r[6] = 0xFFFFFFFEu;  // 0606F0C6 mov #-2,r6
    c.r[5] = 0x0u;  // 0606F0C8 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0606F0CEu; c.r[4] = 0x31u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F0CEu) return; }  // 0606F0CA jsr @r11 ; mov #49,r4
    c.r[6] = 0xFFFFFFFEu; goto L_0606F0EE;  // 0606F0CE bra 0x0606F0EE ; mov #-2,r6
L_0606F0D2:
    c.r[5] = 0x0u;  // 0606F0D2 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0606F0D8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F0D8u) return; }  // 0606F0D4 jsr @r11 ; mov #1,r4
    c.r[1] = c.r[14];  // 0606F0D8 mov r14,r1
    c.r[1] += 28;  // 0606F0DA add #28,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F0DC mov.w @r1,r6
    c.r[5] = 0x0u;  // 0606F0DE mov #0,r5
    c.r[4] = 0x1u;  // 0606F0E0 mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_0606F0F2;  // 0606F0E2 bra 0x0606F0F2 ; extu.w r6,r6
L_0606F0E6:
    c.r[5] = 0x0u;  // 0606F0E6 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0606F0ECu; c.r[4] = 0x31u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F0ECu) return; }  // 0606F0E8 jsr @r11 ; mov #49,r4
    c.r[6] = 0xFFFFFFFFu;  // 0606F0EC mov #-1,r6
L_0606F0EE:
    c.r[5] = 0x0u;  // 0606F0EE mov #0,r5
    c.r[4] = 0x31u;  // 0606F0F0 mov #49,r4
L_0606F0F2:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F0F6u; c.r[10] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F0F6u) return; }  // 0606F0F2 jsr @r11 ; mov r14,r10
    c.r[1] = c.r[14];  // 0606F0F6 mov r14,r1
    c.r[1] += 28;  // 0606F0F8 add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F0FA mov.w @r1,r5
    c.r[6] = 0x6u;  // 0606F0FC mov #6,r6
    c.r[1] = c.r[14];  // 0606F0FE mov r14,r1
    c.r[1] += 24;  // 0606F100 add #24,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606F102 mov.w @r1,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0606F104 extu.w r5,r5
    c.r[1] = ld32(0x0606F204u);  // 0606F106 mov.l 0x0606F204,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F10Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F10Cu) return; }  // 0606F108 jsr @r1 ; extu.w r4,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606F1F2u);  // 0606F10C mov.w 0x0606F1F2,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F1F4u);  // 0606F10E mov.w 0x0606F1F4,r1
    c.r[8] = ld32(0x0606F208u);  // 0606F110 mov.l 0x0606F208,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0606F112 mov.w @r14,r4
    c.r[5] = c.r[9];  // 0606F114 mov r9,r5
    c.r[4] += c.r[1];  // 0606F116 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F11Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F11Cu) return; }  // 0606F118 jsr @r8 ; extu.w r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F1F6u);  // 0606F11C mov.w 0x0606F1F6,r0
    c.r[10] += c.r[0];  // 0606F11E add r0,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F1F8u);  // 0606F120 mov.w 0x0606F1F8,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0606F122 mov.w @(r0,r14),r4
    c.r[5] = c.r[9];  // 0606F124 mov r9,r5
    c.r[4] += c.r[1];  // 0606F126 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F12Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F12Cu) return; }  // 0606F128 jsr @r8 ; extu.w r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606F12C tst r13,r13
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606F13C; } }  // 0606F12E bt/s 0x0606F13C ; mov #0,r5
    c.r[10] += 2;  // 0606F132 add #2,r10
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606F134 mov.b @r10,r6
    c.r[4] = 0x0u;  // 0606F136 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu; goto L_0606F140;  // 0606F138 bra 0x0606F140 ; extu.b r6,r6
L_0606F13C:
    c.r[6] = 0xFFFFFFFFu;  // 0606F13C mov #-1,r6
    c.r[4] = 0x20u;  // 0606F13E mov #32,r4
L_0606F140:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F144u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F144u) return; }  // 0606F140 jsr @r11 ; nop
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606F144 mov.b @r12,r1
    c.r[10] = ld32(0x0606F20Cu);  // 0606F146 mov.l 0x0606F20C,r10
    c.r[0] = c.r[1] & 0xFFu;  // 0606F148 extu.b r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606F14A mov.b @(r0,r10),r3
    c.r[2] = 0x2u;  // 0606F14C mov #2,r2
    c.r[1] = c.r[3];  // 0606F14E mov r3,r1
    c.r[1] += 5;  // 0606F150 add #5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606F152 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606F154 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = c.r[3] & 0xFFu; if (k) { goto L_0606F188; } }  // 0606F156 bt/s 0x0606F188 ; extu.b r3,r1
    c.r[1] = c.r[3] & 0xFFu;  // 0606F15A extu.b r3,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606F1F2u);  // 0606F15C mov.w 0x0606F1F2,r8
    c.r[8] -= c.r[1];  // 0606F15E sub r1,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 0606F160 extu.w r8,r8
    c.r[9] = ld32(0x0606F210u);  // 0606F162 mov.l 0x0606F210,r9
    c.r[4] = ld32(0x0606F214u);  // 0606F164 mov.l 0x0606F214,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606F16Au; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F16Au) return; }  // 0606F166 jsr @r9 ; mov #23,r5
    c.r[5] = 0x7u;  // 0606F16A mov #7,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606F170u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F170u) return; }  // 0606F16C jsr @r9 ; mov r0,r4
    c.r[5] = c.r[8];  // 0606F170 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606F176u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F176u) return; }  // 0606F172 jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x0606F218u);  // 0606F176 mov.l 0x0606F218,r1
    c.r[6] = 0x0u;  // 0606F178 mov #0,r6
    c.r[5] = c.r[0];  // 0606F17A mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F180u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F180u) return; }  // 0606F17C jsr @r1 ; mov #0,r4
    c.r[6] = 0x0u;  // 0606F180 mov #0,r6
    c.r[5] = 0x0u;  // 0606F182 mov #0,r5
    c.r[4] = 0x30u; goto L_0606F22E;  // 0606F184 bra 0x0606F22E ; mov #48,r4
L_0606F188:
    c.r[2] = c.r[1];  // 0606F188 mov r1,r2
    c.r[2] <<= 2;  // 0606F18A shll2 r2
    c.r[2] += c.r[1];  // 0606F18C add r1,r2
    c.r[2] <<= 2;  // 0606F18E shll2 r2
    c.r[1] = c.r[14];  // 0606F190 mov r14,r1
    c.r[1] += 44;  // 0606F192 add #44,r1
    c.r[0] = c.r[1];  // 0606F194 mov r1,r0
    c.r[9] = ld32(0x0606F210u);  // 0606F196 mov.l 0x0606F210,r9
    c.r[5] = 0xEu;  // 0606F198 mov #14,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0606F19A mov.w @(r0,r2),r8
    c.r[4] = ld32(0x0606F214u);  // 0606F19C mov.l 0x0606F214,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606F1A2u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F1A2u) return; }  // 0606F19E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0606F1A2 mov r0,r1
    c.r[5] = c.r[8];  // 0606F1A4 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606F1AAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F1AAu) return; }  // 0606F1A6 jsr @r9 ; mov r1,r4
    c.r[2] = c.r[0];  // 0606F1AA mov r0,r2
    c.r[1] = ld32(0x0606F218u);  // 0606F1AC mov.l 0x0606F218,r1
    c.r[6] = 0x0u;  // 0606F1AE mov #0,r6
    c.r[5] = c.r[2];  // 0606F1B0 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F1B6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F1B6u) return; }  // 0606F1B2 jsr @r1 ; mov #0,r4
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F1FAu);  // 0606F1B6 mov.w 0x0606F1FA,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606F1B8 mov.b @r12,r1
    c.r[7] += c.r[14];  // 0606F1BA add r14,r7
    c.r[7] = ld32(c.r[7]);  // 0606F1BC mov.l @r7,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0606F1BE extu.b r1,r2
    c.r[0] = c.r[2];  // 0606F1C0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606F1C2 mov.b @(r0,r10),r1
    c.t = (c.r[7] & c.r[7]) == 0;  // 0606F1C4 tst r7,r7
    c.r[6] = c.r[1] & 0xFFu;  // 0606F1C6 extu.b r1,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F1FCu);  // 0606F1C8 mov.w 0x0606F1FC,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606F1CA mov.l @(r0,r14),r0
    c.r[1] = c.t;  // 0606F1CC movt r1
    c.r[1] += c.r[0];  // 0606F1CE add r0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F1D0 mov.b @r1,r1
    c.r[0] = ld32(0x0606F21Cu);  // 0606F1D2 mov.l 0x0606F21C,r0
    c.r[4] = c.r[1] & 0xFFu;  // 0606F1D4 extu.b r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0606F1D6 mov.b @(r0,r4),r1
    c.r[5] = c.r[1] & 0xFFu;  // 0606F1D8 extu.b r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606F1DA mov.b @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606F1DC extu.b r1,r3
    c.r[0] = c.r[4];  // 0606F1DE mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606F1E0 mov.b @(r0,r10),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606F1FEu);  // 0606F1E2 mov.w 0x0606F1FE,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606F1E4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606F1E6 cmp/eq r2,r1
    if (!c.t) { goto L_0606F220; }  // 0606F1E8 bf 0x0606F220
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F200u);  // 0606F1EA mov.w 0x0606F200,r1
    c.r[1] |= c.r[3]; goto L_0606F222;  // 0606F1EC bra 0x0606F222 ; or r3,r1
L_0606F220:
    c.r[1] = c.r[3] & 0xFFu;  // 0606F220 extu.b r3,r1
L_0606F222:
    c.r[0] = ld32(0x0606F28Cu);  // 0606F222 mov.l 0x0606F28C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606F228u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F228u) return; }  // 0606F224 jsr @r0 ; mov r1,r4
    c.r[6] = c.r[0] & 0xFFu;  // 0606F228 extu.b r0,r6
    c.r[5] = 0x0u;  // 0606F22A mov #0,r5
    c.r[4] = 0x0u;  // 0606F22C mov #0,r4
L_0606F22E:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F232u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F232u) return; }  // 0606F22E jsr @r11 ; nop
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606F232 tst r13,r13
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606F242; } }  // 0606F234 bt/s 0x0606F242 ; mov #0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F284u);  // 0606F238 mov.w 0x0606F284,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0606F23A mov.b @(r0,r14),r6
    c.r[4] = 0x0u;  // 0606F23C mov #0,r4
    c.r[6] = c.r[6] & 0xFFu; goto L_0606F246;  // 0606F23E bra 0x0606F246 ; extu.b r6,r6
L_0606F242:
    c.r[6] = 0xFFFFFFFFu;  // 0606F242 mov #-1,r6
    c.r[4] = 0x30u;  // 0606F244 mov #48,r4
L_0606F246:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F24Au; c.r[12] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F24Au) return; }  // 0606F246 jsr @r11 ; add #1,r12
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F286u);  // 0606F24A mov.w 0x0606F286,r7
    c.r[7] += c.r[14];  // 0606F24C add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606F24E mov.l @r7,r0
    c.r[0] += 1;  // 0606F250 add #1,r0
    st32(c.r[7], c.r[0]);  // 0606F252 mov.l r0,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606F286u);  // 0606F254 mov.w 0x0606F286,r7
    c.r[7] += c.r[14];  // 0606F256 add r14,r7
    c.r[7] = ld32(c.r[7]);  // 0606F258 mov.l @r7,r7
    c.r[1] = 0x1u;  // 0606F25A mov #1,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0606F25C cmp/gt r1,r7
    if (c.t) { goto L_0606F264; }  // 0606F25E bt 0x0606F264
    SH2_POLL(c); goto L_0606EF70;  // 0606F260 bra 0x0606EF70 ; nop
L_0606F264:
    c.r[1] = ld32(0x0606F290u);  // 0606F264 mov.l 0x0606F290,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F26Au; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F26Au) return; }  // 0606F266 jsr @r1 ; mov #14,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F288u);  // 0606F26A mov.w 0x0606F288,r3
    c.r[14] += c.r[3];  // 0606F26C add r3,r14
    c.r[15] = c.r[14];  // 0606F26E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606F270 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606F272 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606F274 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606F276 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606F278 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606F27A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606F27C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F28Au);  // 0606F27E mov.w 0x0606F28A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606F280 rts ; mov.l @r15+,r8
}

void f_0606F294(SH2Context& c) {
    ran[1576] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606F294 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606F296 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606F298 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606F29A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606F29C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606F29E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606F2A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606F2A2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F3E2u);  // 0606F2A4 mov.w 0x0606F3E2,r3
    c.r[15] += c.r[3];  // 0606F2A6 add r3,r15
    c.r[14] = c.r[15];  // 0606F2A8 mov r15,r14
    c.r[1] = ld32(0x0606F3ECu);  // 0606F2AA mov.l 0x0606F3EC,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F2AC mov.b @r1,r6
    c.r[4] = c.r[14];  // 0606F2AE mov r14,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0606F2B0 extu.b r6,r6
    c.r[1] = ld32(0x0606F3F0u);  // 0606F2B2 mov.l 0x0606F3F0,r1
    c.r[2] = c.r[6];  // 0606F2B4 mov r6,r2
    c.r[1] = ld32(c.r[1]);  // 0606F2B6 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606F2B8 shll2 r2
    c.r[2] <<= 2;  // 0606F2BA shll2 r2
    c.r[2] += c.r[1];  // 0606F2BC add r1,r2
    c.r[2] += 2;  // 0606F2BE add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606F2C0 mov.b @r2,r5
    c.r[1] = ld32(0x0606F3F4u);  // 0606F2C2 mov.l 0x0606F3F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F2C8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F2C8u) return; }  // 0606F2C4 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0606F3F8u);  // 0606F2C8 mov.l 0x0606F3F8,r1
    c.r[2] = ld32(c.r[1]);  // 0606F2CA mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F3E4u);  // 0606F2CC mov.w 0x0606F3E4,r1
    c.r[0] = c.r[2];  // 0606F2CE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F2D0 mov.b @(r0,r1),r1
    c.r[9] = 0x0u;  // 0606F2D2 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606F2D4 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0606F2D6 cmp/ge r1,r9
    { const bool k = c.t; c.r[12] = 0x4u; if (k) { goto L_0606F31C; } }  // 0606F2D8 bt/s 0x0606F31C ; mov #4,r12
    c.r[6] = c.r[2];  // 0606F2DC mov r2,r6
    c.r[5] = c.r[1];  // 0606F2DE mov r1,r5
    c.r[7] = c.r[6];  // 0606F2E0 mov r6,r7
    c.r[3] = 0x0u;  // 0606F2E2 mov #0,r3
L_0606F2E4:
    c.r[0] = c.r[3];  // 0606F2E4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606F2E6 mov.b @(r0,r6),r1
    c.r[4] = 0x7Fu;  // 0606F2E8 mov #127,r4
    c.r[4] &= c.r[1];  // 0606F2EA and r1,r4
    c.r[1] = c.r[7];  // 0606F2EC mov r7,r1
    c.r[1] += 1;  // 0606F2EE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F2F0 mov.b @r1,r2
    c.r[4] <<= 8;  // 0606F2F2 shll8 r4
    c.r[2] = c.r[2] & 0xFFu;  // 0606F2F4 extu.b r2,r2
    c.r[2] |= c.r[4];  // 0606F2F6 or r4,r2
    c.r[1] = 0x14u;  // 0606F2F8 mov #20,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0606F2FA mulu.w r1,r2
    c.r[2] = c.macl;  // 0606F2FC sts macl,r2
    c.r[1] = c.r[14];  // 0606F2FE mov r14,r1
    c.r[1] += 51;  // 0606F300 add #51,r1
    c.r[0] = c.r[1];  // 0606F302 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606F304 mov.b @(r0,r2),r1
    c.r[1] >>= 2;  // 0606F306 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606F308 shlr r1
    c.r[0] = 0x1u;  // 0606F30A mov #1,r0
    c.r[1] &= c.r[0];  // 0606F30C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606F30E tst r1,r1
    { const bool k = c.t; c.r[7] += 2; if (k) { goto L_0606F31C; } }  // 0606F310 bt/s 0x0606F31C ; add #2,r7
    c.r[9] += 1;  // 0606F314 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[5];  // 0606F316 cmp/ge r5,r9
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0606F2E4; } }  // 0606F318 bf/s 0x0606F2E4 ; add #2,r3
L_0606F31C:
    c.r[1] = ld32(0x0606F3F8u);  // 0606F31C mov.l 0x0606F3F8,r1
    c.r[1] = ld32(c.r[1]);  // 0606F31E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F3E4u);  // 0606F320 mov.w 0x0606F3E4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F322 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606F324 extu.b r1,r1
    c.t = c.r[9] == c.r[1];  // 0606F326 cmp/eq r1,r9
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_0606F330; } }  // 0606F328 bf/s 0x0606F330 ; mov r12,r1
    c.r[1] -= 1;  // 0606F32C add #-1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606F32E extu.b r1,r12
L_0606F330:
    c.r[1] = ld32(0x0606F3FCu);  // 0606F330 mov.l 0x0606F3FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F336u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F336u) return; }  // 0606F332 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606F400u);  // 0606F336 mov.l 0x0606F400,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F33Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F33Cu) return; }  // 0606F338 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606F404u);  // 0606F33C mov.l 0x0606F404,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F342u; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F342u) return; }  // 0606F33E jsr @r1 ; mov #0,r10
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606F3E6u);  // 0606F342 mov.w 0x0606F3E6,r4
    c.r[1] = c.r[12];  // 0606F344 mov r12,r1
    c.r[1] += c.r[1];  // 0606F346 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606F348 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F34A mov.l r1,@-r15
    c.r[1] = ld32(0x0606F408u);  // 0606F34C mov.l 0x0606F408,r1
    c.r[7] = 0x6u;  // 0606F34E mov #6,r7
    c.r[6] = 0x12u;  // 0606F350 mov #18,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0606F356u; c.r[5] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F356u) return; }  // 0606F352 jsr @r1 ; mov #16,r5
    c.r[9] = 0x0u;  // 0606F356 mov #0,r9
    c.r[15] += 4;  // 0606F358 add #4,r15
    c.r[11] = ld32(0x0606F40Cu);  // 0606F35A mov.l 0x0606F40C,r11
    c.r[13] = ld32(0x0606F410u);  // 0606F35C mov.l 0x0606F410,r13
    c.r[0] = c.r[9];  // 0606F35E mov r9,r0
L_0606F360:
    c.t = c.r[0] == 0x1u;  // 0606F360 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0606F36A; } }  // 0606F362 bf/s 0x0606F36A ; mov r12,r0
    c.t = c.r[0] == 0x4u;  // 0606F366 cmp/eq #4,r0
    if (!c.t) { goto L_0606F394; }  // 0606F368 bf 0x0606F394
L_0606F36A:
    c.r[8] = c.r[9] & 0xFFFFu;  // 0606F36A extu.w r9,r8
    c.r[4] = ld32(0x0606F414u);  // 0606F36C mov.l 0x0606F414,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606F372u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F372u) return; }  // 0606F36E jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 0606F372 mov r0,r1
    c.r[5] = 0x7u;  // 0606F374 mov #7,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0606F37Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F37Au) return; }  // 0606F376 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606F37A mov r0,r1
    c.r[5] = c.r[8];  // 0606F37C mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0606F382u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F382u) return; }  // 0606F37E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606F382 mov r0,r1
    c.r[6] = 0x0u;  // 0606F384 mov #0,r6
    c.r[5] = c.r[1];  // 0606F386 mov r1,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0606F38Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F38Cu) return; }  // 0606F388 jsr @r13 ; mov #0,r4
    c.r[1] = ld32(0x0606F418u);  // 0606F38C mov.l 0x0606F418,r1
    c.r[0] = c.r[10];  // 0606F38E mov r10,r0
    st8(c.r[0] + c.r[1], c.r[9]);  // 0606F390 mov.b r9,@(r0,r1)
    c.r[10] += 1;  // 0606F392 add #1,r10
L_0606F394:
    c.r[9] += 1;  // 0606F394 add #1,r9
    c.r[1] = 0x3u;  // 0606F396 mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0606F398 cmp/gt r1,r9
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_0606F360; } }  // 0606F39A bf/s 0x0606F360 ; mov r9,r0
    c.r[1] = ld32(0x0606F41Cu);  // 0606F39E mov.l 0x0606F41C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F3A4u; c.r[4] = 0x37u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F3A4u) return; }  // 0606F3A0 jsr @r1 ; mov #55,r4
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606F3A4 mov.l r12,@-r15
    c.r[2] = 0x1u;  // 0606F3A6 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F3A8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F3AA mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0606F3AC mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F3AE mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F3B0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F3B2 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F3B4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F3B6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606F3B8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F3BA mov.l r2,@-r15
    c.r[1] = ld32(0x0606F420u);  // 0606F3BC mov.l 0x0606F420,r1
    c.r[7] = 0x2u;  // 0606F3BE mov #2,r7
    c.r[6] = 0x6u;  // 0606F3C0 mov #6,r6
    c.r[5] = 0x13u;  // 0606F3C2 mov #19,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F3C8u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F3C8u) return; }  // 0606F3C4 jsr @r1 ; mov #17,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F3E8u);  // 0606F3C8 mov.w 0x0606F3E8,r3
    c.r[14] += c.r[3];  // 0606F3CA add r3,r14
    c.r[15] = c.r[14];  // 0606F3CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606F3CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606F3D0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606F3D2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606F3D4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606F3D6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606F3D8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606F3DA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F3EAu);  // 0606F3DC mov.w 0x0606F3EA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606F3DE rts ; mov.l @r15+,r8
}

void f_0606F424(SH2Context& c) {
    ran[1577] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606F424 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606F426 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606F428 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606F42A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606F42C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606F42E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606F430 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606F432 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F5A2u);  // 0606F434 mov.w 0x0606F5A2,r3
    c.r[15] += c.r[3];  // 0606F436 add r3,r15
    c.r[14] = c.r[15];  // 0606F438 mov r15,r14
    c.r[1] = ld32(0x0606F5ACu);  // 0606F43A mov.l 0x0606F5AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F440u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F440u) return; }  // 0606F43C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606F5B0u);  // 0606F440 mov.l 0x0606F5B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F446u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F446u) return; }  // 0606F442 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606F5B4u);  // 0606F446 mov.l 0x0606F5B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F44Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F44Cu) return; }  // 0606F448 jsr @r1 ; nop
    c.r[1] = ld32(0x0606F5B8u);  // 0606F44C mov.l 0x0606F5B8,r1
    c.r[1] = ld32(c.r[1]);  // 0606F44E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F5A4u);  // 0606F450 mov.w 0x0606F5A4,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F452 mov.b @(r0,r1),r7
    c.r[1] = ld32(0x0606F5BCu);  // 0606F454 mov.l 0x0606F5BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F456 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606F458 extu.b r1,r0
    c.r[1] = ld32(0x0606F5C0u);  // 0606F45A mov.l 0x0606F5C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F45C mov.b @(r0,r1),r1
    c.r[6] = 0xBu;  // 0606F45E mov #11,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0606F460 extu.b r1,r1
    c.r[1] -= 1;  // 0606F462 add #-1,r1
    c.macl = c.r[1] * c.r[6];  // 0606F464 mul.l r6,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0606F466 extu.b r7,r2
    c.r[1] = c.macl;  // 0606F468 sts macl,r1
    c.r[2] -= c.r[1];  // 0606F46A sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0606F46C cmp/gt r6,r2
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_0606F47A; } }  // 0606F46E bt/s 0x0606F47A ; mov r7,r0
    c.r[0] -= c.r[1];  // 0606F472 sub r1,r0
    c.r[1] = c.r[0];  // 0606F474 mov r0,r1
    c.r[4] = c.r[1] & 0xFFu; goto L_0606F47C;  // 0606F476 bra 0x0606F47C ; extu.b r1,r4
L_0606F47A:
    c.r[4] = c.r[6];  // 0606F47A mov r6,r4
L_0606F47C:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F5A6u);  // 0606F47C mov.w 0x0606F5A6,r3
    c.r[3] += c.r[14];  // 0606F47E add r14,r3
    st32(c.r[3], c.r[4]);  // 0606F480 mov.l r4,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F5A6u);  // 0606F482 mov.w 0x0606F5A6,r0
    c.r[0] += c.r[14];  // 0606F484 add r14,r0
    c.r[7] = 0x24u;  // 0606F486 mov #36,r7
    c.r[6] = 0x4u;  // 0606F488 mov #4,r6
    c.r[1] = ld32(c.r[0]);  // 0606F48A mov.l @r0,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606F5A8u);  // 0606F48C mov.w 0x0606F5A8,r4
    c.r[1] += c.r[1];  // 0606F48E add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606F490 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F492 mov.l r1,@-r15
    c.r[1] = ld32(0x0606F5C4u);  // 0606F494 mov.l 0x0606F5C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F49Au; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F49Au) return; }  // 0606F496 jsr @r1 ; mov #1,r5
    c.r[9] = ld32(0x0606F5B8u);  // 0606F49A mov.l 0x0606F5B8,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606F5A4u);  // 0606F49C mov.w 0x0606F5A4,r8
    c.r[10] = 0x1u;  // 0606F49E mov #1,r10
    c.r[3] = 0xBu;  // 0606F4A0 mov #11,r3
    c.r[7] = 0x2u;  // 0606F4A2 mov #2,r7
    c.r[6] = 0x22u;  // 0606F4A4 mov #34,r6
    c.r[1] = ld32(c.r[9]);  // 0606F4A6 mov.l @r9,r1
    c.r[5] = 0x5u;  // 0606F4A8 mov #5,r5
    c.r[0] = c.r[1];  // 0606F4AA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606F4AC mov.b @(r0,r8),r1
    c.r[4] = 0x4u;  // 0606F4AE mov #4,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0606F4B0 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F4B2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606F4B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606F4B6 mov.l r10,@-r15
    c.r[1] = 0x0u;  // 0606F4B8 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F4BA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F4BC mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606F4BE mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F4C0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F4C2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0606F4C4 mov.l r3,@-r15
    c.r[1] = ld32(0x0606F5C8u);  // 0606F4C6 mov.l 0x0606F5C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F4CCu; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F4CCu) return; }  // 0606F4C8 jsr @r1 ; mov.l r10,@-r15
    c.r[15] += 44;  // 0606F4CC add #44,r15
    c.r[1] = ld32(0x0606F5CCu);  // 0606F4CE mov.l 0x0606F5CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F4D4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F4D4u) return; }  // 0606F4D0 jsr @r1 ; mov r10,r4
    c.r[13] = ld32(0x0606F5BCu);  // 0606F4D4 mov.l 0x0606F5BC,r13
    c.r[12] = ld32(0x0606F5C0u);  // 0606F4D6 mov.l 0x0606F5C0,r12
    c.r[11] = ld32(0x0606F5D0u);  // 0606F4D8 mov.l 0x0606F5D0,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606F4DA mov.b @r13,r1
    c.r[5] = 0x0u;  // 0606F4DC mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0606F4DE extu.b r1,r1
    c.r[0] = c.r[1];  // 0606F4E0 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606F4E2 mov.b @(r0,r12),r6
    c.r[4] = 0x0u;  // 0606F4E4 mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606F4EAu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F4EAu) return; }  // 0606F4E6 jsr @r11 ; extu.b r6,r6
    c.r[1] = ld32(c.r[9]);  // 0606F4EA mov.l @r9,r1
    c.r[0] = c.r[1];  // 0606F4EC mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606F4EE mov.b @(r0,r8),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606F4F0 extu.b r2,r2
    c.r[2] += 10;  // 0606F4F2 add #10,r2
    c.r[1] = ld32(0x0606F5D4u);  // 0606F4F4 mov.l 0x0606F5D4,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0606F4F6 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 0606F4F8 mov #0,r5
    c.r[4] = 0x0u;  // 0606F4FA mov #0,r4
    c.r[6] = c.mach;  // 0606F4FC sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0606F4FE shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0606F500 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0606F502 subc r2,r2
    { const uint32_t x = c.r[11]; c.pr = 0x0606F508u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F508u) return; }  // 0606F504 jsr @r11 ; sub r2,r6
    c.r[1] = ld32(c.r[9]);  // 0606F508 mov.l @r9,r1
    c.r[0] = c.r[1];  // 0606F50A mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606F50C mov.b @(r0,r8),r7
    c.r[6] = ld32(0x0606F5D8u);  // 0606F50E mov.l 0x0606F5D8,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606F510 mov.b @r6,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0606F512 extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606F514 extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 0606F516 cmp/hs r1,r2
    if (c.t) { goto L_0606F51C; }  // 0606F518 bt 0x0606F51C
    st8(c.r[6], c.r[7]);  // 0606F51A mov.b r7,@r6
L_0606F51C:
    c.r[1] = ld32(0x0606F5DCu);  // 0606F51C mov.l 0x0606F5DC,r1
    c.r[5] = 0x0u;  // 0606F51E mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606F520 mov.b @r6,r6
    c.r[4] = 0x0u;  // 0606F522 mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F524 mov.b @r1,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606F526 extu.b r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0606F528 extu.b r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0606F52Eu; c.r[6] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F52Eu) return; }  // 0606F52A jsr @r11 ; sub r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606F52E mov.b @r13,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606F530 extu.b r1,r7
    c.r[0] = c.r[7];  // 0606F532 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606F534 mov.b @(r0,r12),r1
    c.r[3] = 0xBu;  // 0606F536 mov #11,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606F538 extu.b r1,r1
    c.r[1] -= 1;  // 0606F53A add #-1,r1
    c.macl = c.r[1] * c.r[3];  // 0606F53C mul.l r3,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606F5A8u);  // 0606F53E mov.w 0x0606F5A8,r6
    c.r[1] = ld32(0x0606F5E0u);  // 0606F540 mov.l 0x0606F5E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F542 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0606F544 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606F546 extu.b r1,r1
    c.r[2] += c.r[1];  // 0606F548 add r1,r2
    c.r[1] = ld32(c.r[9]);  // 0606F54A mov.l @r9,r1
    c.r[2] += c.r[2];  // 0606F54C add r2,r2
    c.r[1] += c.r[2];  // 0606F54E add r2,r1
    c.r[1] += 1;  // 0606F550 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F552 mov.b @r1,r5
    c.r[4] = c.r[14];  // 0606F554 mov r14,r4
    c.r[1] = ld32(0x0606F5E4u);  // 0606F556 mov.l 0x0606F5E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F55Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F55Cu) return; }  // 0606F558 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0606F55C mov r14,r1
    c.r[1] += 14;  // 0606F55E add #14,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606F5AAu);  // 0606F560 mov.w 0x0606F5AA,r9
    c.r[9] += c.r[14];  // 0606F562 add r14,r9
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F564 mov.b @r1,r5
    c.r[4] = c.r[9];  // 0606F566 mov r9,r4
    c.r[1] = ld32(0x0606F5E8u);  // 0606F568 mov.l 0x0606F5E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F56Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F56Eu) return; }  // 0606F56A jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0606F5ECu);  // 0606F56E mov.l 0x0606F5EC,r1
    c.r[1] = ld32(c.r[1]);  // 0606F570 mov.l @r1,r1
    c.r[1] += 9;  // 0606F572 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F574 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606F576 mov #1,r0
    c.r[1] >>= 2;  // 0606F578 shlr2 r1
    c.r[1] &= c.r[0];  // 0606F57A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606F57C tst r1,r1
    if (c.t) { goto L_0606F600; }  // 0606F57E bt 0x0606F600
    c.r[1] = ld32(0x0606F5F0u);  // 0606F580 mov.l 0x0606F5F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F586u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F586u) return; }  // 0606F582 jsr @r1 ; mov #4,r4
    c.r[4] = ld32(0x0606F5F4u);  // 0606F586 mov.l 0x0606F5F4,r4
    c.r[8] = ld32(0x0606F5F8u);  // 0606F588 mov.l 0x0606F5F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606F58Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F58Eu) return; }  // 0606F58A jsr @r8 ; mov #23,r5
    c.r[5] = 0x8u;  // 0606F58E mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606F594u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F594u) return; }  // 0606F590 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606F5FCu);  // 0606F594 mov.l 0x0606F5FC,r1
    c.r[6] = 0x0u;  // 0606F596 mov #0,r6
    c.r[5] = c.r[10];  // 0606F598 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F59Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F59Eu) return; }  // 0606F59A jsr @r1 ; mov r0,r4
    c.r[9] += 2; goto L_0606F620;  // 0606F59E bra 0x0606F620 ; add #2,r9
L_0606F600:
    c.r[1] = ld32(0x0606F798u);  // 0606F600 mov.l 0x0606F798,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F606u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F606u) return; }  // 0606F602 jsr @r1 ; mov #4,r4
    c.r[4] = ld32(0x0606F79Cu);  // 0606F606 mov.l 0x0606F79C,r4
    c.r[8] = ld32(0x0606F7A0u);  // 0606F608 mov.l 0x0606F7A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606F60Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F60Eu) return; }  // 0606F60A jsr @r8 ; mov #23,r5
    c.r[5] = 0x8u;  // 0606F60E mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606F614u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F614u) return; }  // 0606F610 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606F7A4u);  // 0606F614 mov.l 0x0606F7A4,r1
    c.r[6] = 0x0u;  // 0606F616 mov #0,r6
    c.r[5] = 0x0u;  // 0606F618 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F61Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F61Eu) return; }  // 0606F61A jsr @r1 ; mov r0,r4
    c.r[9] += 9;  // 0606F61E add #9,r9
L_0606F620:
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606F620 mov.b @r9,r6
    c.r[5] = 0x0u;  // 0606F622 mov #0,r5
    c.r[4] = 0x0u;  // 0606F624 mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606F62Au; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F62Au) return; }  // 0606F626 jsr @r11 ; extu.b r6,r6
    c.r[1] = ld32(0x0606F7A8u);  // 0606F62A mov.l 0x0606F7A8,r1
    c.r[1] = ld32(c.r[1]);  // 0606F62C mov.l @r1,r1
    c.r[1] += 9;  // 0606F62E add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F630 mov.b @r1,r1
    c.r[3] = 0x3u;  // 0606F632 mov #3,r3
    c.r[1] &= c.r[3];  // 0606F634 and r3,r1
    c.r[0] = c.r[1];  // 0606F636 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0606F638 cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = 0x4u; if (k) { goto L_0606F644; } }  // 0606F63A bf/s 0x0606F644 ; mov #4,r4
    c.r[1] = ld32(0x0606F798u);  // 0606F63E mov.l 0x0606F798,r1
    goto L_0606F654;  // 0606F640 bra 0x0606F654 ; nop
L_0606F644:
    c.t = c.r[0] == 0x2u;  // 0606F644 cmp/eq #2,r0
    if (!c.t) { goto L_0606F650; }  // 0606F646 bf 0x0606F650
    c.r[4] = 0x6u;  // 0606F648 mov #6,r4
    c.r[1] = ld32(0x0606F798u);  // 0606F64A mov.l 0x0606F798,r1
    goto L_0606F654;  // 0606F64C bra 0x0606F654 ; nop
L_0606F650:
    c.r[1] = ld32(0x0606F798u);  // 0606F650 mov.l 0x0606F798,r1
    c.r[4] = 0x6u;  // 0606F652 mov #6,r4
L_0606F654:
    { const uint32_t x = c.r[1]; c.pr = 0x0606F658u; c.r[9] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F658u) return; }  // 0606F654 jsr @r1 ; mov #3,r9
    c.r[1] = ld32(0x0606F7A8u);  // 0606F658 mov.l 0x0606F7A8,r1
    c.r[4] = ld32(0x0606F79Cu);  // 0606F65A mov.l 0x0606F79C,r4
    c.r[1] = ld32(c.r[1]);  // 0606F65C mov.l @r1,r1
    c.r[8] = ld32(0x0606F7A0u);  // 0606F65E mov.l 0x0606F7A0,r8
    c.r[1] += 9;  // 0606F660 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F662 mov.b @r1,r1
    c.r[5] = 0x17u;  // 0606F664 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606F66Au; c.r[9] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F66Au) return; }  // 0606F666 jsr @r8 ; and r1,r9
    c.r[1] = c.r[0];  // 0606F66A mov r0,r1
    c.r[5] = 0x9u;  // 0606F66C mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606F672u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F672u) return; }  // 0606F66E jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0606F672 mov r0,r2
    c.r[1] = ld32(0x0606F7A4u);  // 0606F674 mov.l 0x0606F7A4,r1
    c.r[6] = 0x0u;  // 0606F676 mov #0,r6
    c.r[5] = c.r[9];  // 0606F678 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F67Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F67Eu) return; }  // 0606F67A jsr @r1 ; mov r2,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F78Au);  // 0606F67E mov.w 0x0606F78A,r3
    c.r[3] += c.r[14];  // 0606F680 add r14,r3
    c.r[8] = ld32(0x0606F798u);  // 0606F682 mov.l 0x0606F798,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606F688u; c.r[4] = ld32(c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F688u) return; }  // 0606F684 jsr @r8 ; mov.l @r3,r4
    c.r[1] = ld32(0x0606F7ACu);  // 0606F688 mov.l 0x0606F7AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F68A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606F68C extu.b r1,r2
    c.r[1] = ld32(0x0606F7B0u);  // 0606F68E mov.l 0x0606F7B0,r1
    c.r[0] = c.r[2];  // 0606F690 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F692 mov.b @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F78Au);  // 0606F694 mov.w 0x0606F78A,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606F696 extu.b r1,r1
    c.r[1] -= 1;  // 0606F698 add #-1,r1
    c.r[2] = 0xBu;  // 0606F69A mov #11,r2
    c.macl = c.r[1] * c.r[2];  // 0606F69C mul.l r2,r1
    c.r[3] += c.r[14];  // 0606F69E add r14,r3
    c.r[3] = ld32(c.r[3]);  // 0606F6A0 mov.l @r3,r3
    c.r[10] = c.macl;  // 0606F6A2 sts macl,r10
    c.r[1] = c.macl;  // 0606F6A4 sts macl,r1
    c.r[1] += c.r[3];  // 0606F6A6 add r3,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0606F6A8 cmp/ge r1,r10
    { const bool k = !c.t; c.r[11] = c.r[8]; if (k) { goto L_0606F6B2; } }  // 0606F6AA bf/s 0x0606F6B2 ; mov r8,r11
    goto L_0606F818;  // 0606F6AE bra 0x0606F818 ; nop
L_0606F6B2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F78Cu);  // 0606F6B2 mov.w 0x0606F78C,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F78Eu);  // 0606F6B4 mov.w 0x0606F78E,r0
    st32(c.r[0] + c.r[14], c.r[3]);  // 0606F6B6 mov.l r3,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F78Eu);  // 0606F6B8 mov.w 0x0606F78E,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 0606F6BA mov.l @(r0,r14),r12
    c.r[12] += c.r[14];  // 0606F6BC add r14,r12
    c.r[13] = c.r[12];  // 0606F6BE mov r12,r13
    c.r[13] += 9;  // 0606F6C0 add #9,r13
L_0606F6C2:
    c.r[1] = ld32(0x0606F7B4u);  // 0606F6C2 mov.l 0x0606F7B4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606F790u);  // 0606F6C4 mov.w 0x0606F790,r6
    c.r[2] = ld32(c.r[1]);  // 0606F6C6 mov.l @r1,r2
    c.r[4] = c.r[14];  // 0606F6C8 mov r14,r4
    c.r[1] = c.r[10];  // 0606F6CA mov r10,r1
    c.r[1] += c.r[1];  // 0606F6CC add r1,r1
    c.r[2] += c.r[1];  // 0606F6CE add r1,r2
    c.r[2] += 1;  // 0606F6D0 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606F6D2 mov.b @r2,r5
    c.r[1] = ld32(0x0606F7B8u);  // 0606F6D4 mov.l 0x0606F7B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F6DAu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F6DAu) return; }  // 0606F6D6 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0606F6DA mov r14,r1
    c.r[1] += 14;  // 0606F6DC add #14,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F6DE mov.b @r1,r5
    c.r[4] = c.r[12];  // 0606F6E0 mov r12,r4
    c.r[1] = ld32(0x0606F7BCu);  // 0606F6E2 mov.l 0x0606F7BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F6E8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F6E8u) return; }  // 0606F6E4 jsr @r1 ; extu.b r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606F792u);  // 0606F6E8 mov.w 0x0606F792,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606F6EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F6EEu) return; }  // 0606F6EA jsr @r11 ; nop
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606F6EE mov.b @r13,r1
    c.r[2] = 0x63u;  // 0606F6F0 mov #99,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606F6F2 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606F6F4 cmp/hi r2,r1
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_0606F6FC; } }  // 0606F6F6 bt/s 0x0606F6FC ; mov #1,r4
    c.r[4] = 0x4u;  // 0606F6FA mov #4,r4
L_0606F6FC:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F700u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F700u) return; }  // 0606F6FC jsr @r11 ; nop
    c.r[1] = ld32(0x0606F7B4u);  // 0606F700 mov.l 0x0606F7B4,r1
    c.r[0] = c.r[10];  // 0606F702 mov r10,r0
    c.r[1] = ld32(c.r[1]);  // 0606F704 mov.l @r1,r1
    c.r[0] += c.r[0];  // 0606F706 add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F708 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606F70A extu.b r1,r1
    c.r[1] >>= 2;  // 0606F70C shlr2 r1
    c.r[1] >>= 2;  // 0606F70E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606F710 shlr r1
    c.r[1] >>= 2;  // 0606F712 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606F714 tst r1,r1
    if (c.t) { goto L_0606F720; }  // 0606F716 bt 0x0606F720
    { const uint32_t x = c.r[11]; c.pr = 0x0606F71Cu; c.r[4] = 0x37u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F71Cu) return; }  // 0606F718 jsr @r11 ; mov #55,r4
    c.r[4] = 0x38u; goto L_0606F726;  // 0606F71C bra 0x0606F726 ; mov #56,r4
L_0606F720:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F724u; c.r[4] = 0x35u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F724u) return; }  // 0606F720 jsr @r11 ; mov #53,r4
    c.r[4] = 0x36u;  // 0606F724 mov #54,r4
L_0606F726:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F72Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F72Au) return; }  // 0606F726 jsr @r11 ; nop
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606F790u);  // 0606F72A mov.w 0x0606F790,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F794u);  // 0606F72C mov.w 0x0606F794,r1
    c.r[8] = ld32(0x0606F7C0u);  // 0606F72E mov.l 0x0606F7C0,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0606F730 mov.w @r14,r4
    c.r[5] = c.r[9];  // 0606F732 mov r9,r5
    c.r[4] += c.r[1];  // 0606F734 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F73Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F73Au) return; }  // 0606F736 jsr @r8 ; extu.w r4,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F78Eu);  // 0606F73A mov.w 0x0606F78E,r3
    c.r[3] += c.r[14];  // 0606F73C add r14,r3
    c.r[0] = ld32(c.r[3]);  // 0606F73E mov.l @r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606F796u);  // 0606F740 mov.w 0x0606F796,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0606F742 mov.w @(r0,r14),r4
    c.r[5] = c.r[9];  // 0606F744 mov r9,r5
    c.r[4] += c.r[1];  // 0606F746 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F74Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F74Cu) return; }  // 0606F748 jsr @r8 ; extu.w r4,r4
    c.r[1] = ld32(0x0606F7A8u);  // 0606F74C mov.l 0x0606F7A8,r1
    c.r[1] = ld32(c.r[1]);  // 0606F74E mov.l @r1,r1
    c.r[1] += 9;  // 0606F750 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F752 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606F754 mov #1,r0
    c.r[1] >>= 2;  // 0606F756 shlr2 r1
    c.r[1] &= c.r[0];  // 0606F758 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606F75A tst r1,r1
    if (!c.t) { goto L_0606F7C8; }  // 0606F75C bf 0x0606F7C8
    { const uint32_t x = c.r[11]; c.pr = 0x0606F762u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F762u) return; }  // 0606F75E jsr @r11 ; mov #4,r4
    c.r[8] = ld32(0x0606F7A0u);  // 0606F762 mov.l 0x0606F7A0,r8
    c.r[4] = ld32(0x0606F79Cu);  // 0606F764 mov.l 0x0606F79C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F76Au; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F76Au) return; }  // 0606F766 jsr @r8 ; mov #23,r5
    c.r[5] = 0x8u;  // 0606F76A mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606F770u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F770u) return; }  // 0606F76C jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606F7A4u);  // 0606F770 mov.l 0x0606F7A4,r1
    c.r[6] = 0x0u;  // 0606F772 mov #0,r6
    c.r[5] = 0x1u;  // 0606F774 mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F77Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F77Au) return; }  // 0606F776 jsr @r1 ; mov r0,r4
    c.r[1] = c.r[12];  // 0606F77A mov r12,r1
    c.r[1] += 2;  // 0606F77C add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F77E mov.b @r1,r6
    c.r[5] = 0x0u;  // 0606F780 mov #0,r5
    c.r[4] = 0x0u;  // 0606F782 mov #0,r4
    c.r[1] = ld32(0x0606F7C4u);  // 0606F784 mov.l 0x0606F7C4,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_0606F7EE;  // 0606F786 bra 0x0606F7EE ; extu.b r6,r6
L_0606F7C8:
    { const uint32_t x = c.r[11]; c.pr = 0x0606F7CCu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F7CCu) return; }  // 0606F7C8 jsr @r11 ; mov #4,r4
    c.r[8] = ld32(0x0606F840u);  // 0606F7CC mov.l 0x0606F840,r8
    c.r[4] = ld32(0x0606F844u);  // 0606F7CE mov.l 0x0606F844,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F7D4u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F7D4u) return; }  // 0606F7D0 jsr @r8 ; mov #23,r5
    c.r[5] = 0x8u;  // 0606F7D4 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606F7DAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F7DAu) return; }  // 0606F7D6 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606F848u);  // 0606F7DA mov.l 0x0606F848,r1
    c.r[6] = 0x0u;  // 0606F7DC mov #0,r6
    c.r[5] = 0x0u;  // 0606F7DE mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F7E4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F7E4u) return; }  // 0606F7E0 jsr @r1 ; mov r0,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606F7E4 mov.b @r13,r6
    c.r[1] = ld32(0x0606F84Cu);  // 0606F7E6 mov.l 0x0606F84C,r1
    c.r[5] = 0x0u;  // 0606F7E8 mov #0,r5
    c.r[4] = 0x0u;  // 0606F7EA mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0606F7EC extu.b r6,r6
L_0606F7EE:
    { const uint32_t x = c.r[1]; c.pr = 0x0606F7F2u; c.r[10] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F7F2u) return; }  // 0606F7EE jsr @r1 ; add #1,r10
    c.r[1] = ld32(0x0606F850u);  // 0606F7F2 mov.l 0x0606F850,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F7F4 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606F7F6 extu.b r1,r2
    c.r[1] = ld32(0x0606F854u);  // 0606F7F8 mov.l 0x0606F854,r1
    c.r[0] = c.r[2];  // 0606F7FA mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606F7FC mov.b @(r0,r1),r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F838u);  // 0606F7FE mov.w 0x0606F838,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606F800 extu.b r2,r2
    c.r[2] -= 1;  // 0606F802 add #-1,r2
    c.r[1] = 0xBu;  // 0606F804 mov #11,r1
    c.macl = c.r[2] * c.r[1];  // 0606F806 mul.l r1,r2
    c.r[3] += c.r[14];  // 0606F808 add r14,r3
    c.r[3] = ld32(c.r[3]);  // 0606F80A mov.l @r3,r3
    c.r[1] = c.macl;  // 0606F80C sts macl,r1
    c.r[1] += c.r[3];  // 0606F80E add r3,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0606F810 cmp/ge r1,r10
    if (c.t) { goto L_0606F818; }  // 0606F812 bt 0x0606F818
    SH2_POLL(c); goto L_0606F6C2;  // 0606F814 bra 0x0606F6C2 ; nop
L_0606F818:
    c.r[1] = ld32(0x0606F858u);  // 0606F818 mov.l 0x0606F858,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F81Eu; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F81Eu) return; }  // 0606F81A jsr @r1 ; mov #15,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606F83Au);  // 0606F81E mov.w 0x0606F83A,r3
    c.r[14] += c.r[3];  // 0606F820 add r3,r14
    c.r[15] = c.r[14];  // 0606F822 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606F824 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606F826 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606F828 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606F82A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606F82C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606F82E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606F830 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F83Cu);  // 0606F832 mov.w 0x0606F83C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606F834 rts ; mov.l @r15+,r8
}

void f_0606F85C(SH2Context& c) {
    ran[1578] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606F85C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606F85E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606F860 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606F862 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606F864 sts.l pr,@-r15
    c.r[9] = ld32(0x0606F8F4u);  // 0606F866 mov.l 0x0606F8F4,r9
    c.r[1] = ld32(c.r[9]);  // 0606F868 mov.l @r9,r1
    c.r[14] = c.r[15];  // 0606F86A mov r15,r14
    c.r[1] += 1;  // 0606F86C add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F86E mov.b @r1,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606F8EAu);  // 0606F870 mov.w 0x0606F8EA,r10
    c.r[10] &= c.r[0];  // 0606F872 and r0,r10
    c.r[10] >>= 2;  // 0606F874 shlr2 r10
    c.r[10] >>= 2;  // 0606F876 shlr2 r10
    c.r[10] >>= 2;  // 0606F878 shlr2 r10
    c.r[1] = ld32(0x0606F8F8u);  // 0606F87A mov.l 0x0606F8F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F880u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F880u) return; }  // 0606F87C jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0606F8FCu);  // 0606F880 mov.l 0x0606F8FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F886u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F886u) return; }  // 0606F882 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0606F900u);  // 0606F886 mov.l 0x0606F900,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F88Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F88Cu) return; }  // 0606F888 jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606F8ECu);  // 0606F88C mov.w 0x0606F8EC,r4
    c.r[8] = ld32(0x0606F904u);  // 0606F88E mov.l 0x0606F904,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606F894u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F894u) return; }  // 0606F890 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0606F898u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F898u) return; }  // 0606F894 jsr @r8 ; mov #0,r4
    c.r[4] = c.r[10];  // 0606F898 mov r10,r4
    c.r[4] <<= 2;  // 0606F89A shll2 r4
    c.r[4] += c.r[4];  // 0606F89C add r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F8A2u; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8A2u) return; }  // 0606F89E jsr @r8 ; shll2 r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606F8EEu);  // 0606F8A2 mov.w 0x0606F8EE,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F8A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8A8u) return; }  // 0606F8A4 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0606F8ACu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8ACu) return; }  // 0606F8A8 jsr @r8 ; mov r10,r4
    c.r[1] = ld32(0x0606F908u);  // 0606F8AC mov.l 0x0606F908,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F8B2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8B2u) return; }  // 0606F8AE jsr @r1 ; mov #0,r4
    c.r[2] = ld32(c.r[9]);  // 0606F8B2 mov.l @r9,r2
    c.r[4] = c.r[10];  // 0606F8B4 mov r10,r4
    c.r[1] = c.r[2];  // 0606F8B6 mov r2,r1
    c.r[1] += 2;  // 0606F8B8 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F8BA mov.b @r1,r6
    c.r[2] += 1;  // 0606F8BC add #1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606F8BE mov.b @r2,r0
    c.r[6] = c.r[6] & 0xFFu;  // 0606F8C0 extu.b r6,r6
    c.r[0] &= 0x3Fu;  // 0606F8C2 and #63,r0
    c.r[1] = ld32(0x0606F90Cu);  // 0606F8C4 mov.l 0x0606F90C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F8CAu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8CAu) return; }  // 0606F8C6 jsr @r1 ; mov r0,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606F8F0u);  // 0606F8CA mov.w 0x0606F8F0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606F8D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8D0u) return; }  // 0606F8CC jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0606F8D4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8D4u) return; }  // 0606F8D0 jsr @r8 ; mov r10,r4
    c.r[1] = ld32(0x0606F910u);  // 0606F8D4 mov.l 0x0606F910,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F8DAu; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F8DAu) return; }  // 0606F8D6 jsr @r1 ; mov #16,r4
    c.r[15] = c.r[14];  // 0606F8DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606F8DC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606F8DE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606F8E0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606F8E2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F8F2u);  // 0606F8E4 mov.w 0x0606F8F2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606F8E6 rts ; mov.l @r15+,r8
}

void f_0606F914(SH2Context& c) {
    ran[1579] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606F914 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606F916 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606F918 mov r15,r14
    c.r[1] = ld32(0x0606F964u);  // 0606F91A mov.l 0x0606F964,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F920u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F920u) return; }  // 0606F91C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606F968u);  // 0606F920 mov.l 0x0606F968,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F926u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F926u) return; }  // 0606F922 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606F96Cu);  // 0606F926 mov.l 0x0606F96C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F92Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F92Cu) return; }  // 0606F928 jsr @r1 ; nop
    c.r[7] = 0x2u;  // 0606F92C mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606F92E mov.l r7,@-r15
    c.r[2] = 0x1u;  // 0606F930 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F932 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F934 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0606F936 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F938 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F93A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F93C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F93E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F940 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606F942 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F944 mov.l r2,@-r15
    c.r[1] = ld32(0x0606F970u);  // 0606F946 mov.l 0x0606F970,r1
    c.r[6] = 0x6u;  // 0606F948 mov #6,r6
    c.r[5] = 0x9u;  // 0606F94A mov #9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F950u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F950u) return; }  // 0606F94C jsr @r1 ; mov #17,r4
    c.r[15] += 40;  // 0606F950 add #40,r15
    c.r[1] = ld32(0x0606F974u);  // 0606F952 mov.l 0x0606F974,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F958u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F958u) return; }  // 0606F954 jsr @r1 ; mov #17,r4
    c.r[15] = c.r[14];  // 0606F958 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606F95A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F962u);  // 0606F95C mov.w 0x0606F962,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606F95E rts ; mov.l @r15+,r14
}

void f_0606F978(SH2Context& c) {
    ran[1580] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606F978 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606F97A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606F97C mov r15,r14
    c.r[1] = ld32(0x0606F9E8u);  // 0606F97E mov.l 0x0606F9E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F984u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F984u) return; }  // 0606F980 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606F9ECu);  // 0606F984 mov.l 0x0606F9EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F98Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F98Au) return; }  // 0606F986 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606F9F0u);  // 0606F98A mov.l 0x0606F9F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F990u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F990u) return; }  // 0606F98C jsr @r1 ; nop
    c.r[1] = ld32(0x0606F9F4u);  // 0606F990 mov.l 0x0606F9F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606F992 mov.l @r1,r1
    c.r[1] += 1;  // 0606F994 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606F996 mov.b @r1,r6
    c.r[1] = c.r[6] & 0xFFu;  // 0606F998 extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606F99A tst r1,r1
    { const bool k = c.t; c.r[6] += 14; if (k) { goto L_0606F9A6; } }  // 0606F99C bt/s 0x0606F9A6 ; add #14,r6
    c.r[1] = ld32(0x0606F9F8u);  // 0606F9A0 mov.l 0x0606F9F8,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_0606F9AA;  // 0606F9A2 bra 0x0606F9AA ; extu.b r6,r6
L_0606F9A6:
    c.r[1] = ld32(0x0606F9F8u);  // 0606F9A6 mov.l 0x0606F9F8,r1
    c.r[6] = 0x3u;  // 0606F9A8 mov #3,r6
L_0606F9AA:
    c.r[5] = 0x1Au;  // 0606F9AA mov #26,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F9B0u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F9B0u) return; }  // 0606F9AC jsr @r1 ; mov #1,r4
    c.r[7] = 0x2u;  // 0606F9B0 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606F9B2 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 0606F9B4 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F9B6 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F9B8 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0606F9BA mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F9BC mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F9BE mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F9C0 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F9C2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606F9C4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606F9C6 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606F9C8 mov.l r2,@-r15
    c.r[1] = ld32(0x0606F9FCu);  // 0606F9CA mov.l 0x0606F9FC,r1
    c.r[6] = 0x5u;  // 0606F9CC mov #5,r6
    c.r[5] = 0xFu;  // 0606F9CE mov #15,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606F9D4u; c.r[4] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F9D4u) return; }  // 0606F9D0 jsr @r1 ; mov #27,r4
    c.r[15] += 40;  // 0606F9D4 add #40,r15
    c.r[1] = ld32(0x0606FA00u);  // 0606F9D6 mov.l 0x0606FA00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606F9DCu; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606F9DCu) return; }  // 0606F9D8 jsr @r1 ; mov #18,r4
    c.r[15] = c.r[14];  // 0606F9DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606F9DE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606F9E6u);  // 0606F9E0 mov.w 0x0606F9E6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606F9E2 rts ; mov.l @r15+,r14
}

void f_0606FA04(SH2Context& c) {
    ran[1581] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606FA04 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606FA06 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606FA08 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606FA0A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606FA0C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606FA0E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606FA10 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606FA12 sts.l pr,@-r15
    c.r[15] -= 128;  // 0606FA14 add #-128,r15
    c.r[14] = c.r[15];  // 0606FA16 mov r15,r14
    c.r[2] = c.r[14];  // 0606FA18 mov r14,r2
    c.r[2] += 104;  // 0606FA1A add #104,r2
    c.r[1] = 0xBu;  // 0606FA1C mov #11,r1
    st8(c.r[2], c.r[1]);  // 0606FA1E mov.b r1,@r2
    c.r[7] = 0x0u;  // 0606FA20 mov #0,r7
    c.r[0] = 0x6Cu;  // 0606FA22 mov #108,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 0606FA24 mov.l r7,@(r0,r14)
    c.r[7] = 0x1u;  // 0606FA26 mov #1,r7
    c.r[0] = 0x70u;  // 0606FA28 mov #112,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 0606FA2A mov.l r7,@(r0,r14)
    c.r[3] = c.r[14];  // 0606FA2C mov r14,r3
    c.r[3] += 96;  // 0606FA2E add #96,r3
    c.r[2] = c.r[14];  // 0606FA30 mov r14,r2
    c.r[2] += 100;  // 0606FA32 add #100,r2
    c.r[1] = ld32(0x0606FAF0u);  // 0606FA34 mov.l 0x0606FAF0,r1
    c.r[5] = 0x1u;  // 0606FA36 mov #1,r5
    c.r[6] = 0x1u;  // 0606FA38 mov #1,r6
    c.r[7] = 0x0u;  // 0606FA3A mov #0,r7
    c.r[0] = 0x74u;  // 0606FA3C mov #116,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FA3E mov.b @r1,r1
    c.r[0] += c.r[14];  // 0606FA40 add r14,r0
    c.r[1] >>= 2;  // 0606FA42 shlr2 r1
    c.r[1] >>= 2;  // 0606FA44 shlr2 r1
    c.r[5] &= c.r[1];  // 0606FA46 and r1,r5
    st8(c.r[2], c.r[5]);  // 0606FA48 mov.b r5,@r2
    c.r[2] = c.r[14];  // 0606FA4A mov r14,r2
    c.r[1] = ld32(0x0606FAF4u);  // 0606FA4C mov.l 0x0606FAF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FA4E mov.b @r1,r1
    c.r[2] += 101;  // 0606FA50 add #101,r2
    c.r[1] >>= 2;  // 0606FA52 shlr2 r1
    c.r[1] >>= 2;  // 0606FA54 shlr2 r1
    c.r[6] &= c.r[1];  // 0606FA56 and r1,r6
    st8(c.r[2], c.r[6]);  // 0606FA58 mov.b r6,@r2
    st8(c.r[3], c.r[5]);  // 0606FA5A mov.b r5,@r3
    c.r[1] = c.r[14];  // 0606FA5C mov r14,r1
    c.r[1] += 97;  // 0606FA5E add #97,r1
    st8(c.r[1], c.r[6]);  // 0606FA60 mov.b r6,@r1
    st32(c.r[0], c.r[7]);  // 0606FA62 mov.l r7,@r0
    c.r[1] = ld32(0x0606FAF8u);  // 0606FA64 mov.l 0x0606FAF8,r1
    c.r[1] = ld32(c.r[1]);  // 0606FA66 mov.l @r1,r1
    c.r[1] += 1;  // 0606FA68 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FA6A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606FA6C extu.b r1,r3
    c.r[0] = c.r[3];  // 0606FA6E mov r3,r0
    c.t = c.r[0] == 0x3u;  // 0606FA70 cmp/eq #3,r0
    if (!c.t) { goto L_0606FA7E; }  // 0606FA72 bf 0x0606FA7E
    c.r[1] = ld32(0x0606FAFCu);  // 0606FA74 mov.l 0x0606FAFC,r1
    c.r[11] = ld32(c.r[1]);  // 0606FA76 mov.l @r1,r11
    c.r[1] = ld32(0x0606FB00u);  // 0606FA78 mov.l 0x0606FB00,r1
    c.r[12] = ld32(c.r[1]); goto L_0606FB80;  // 0606FA7A bra 0x0606FB80 ; mov.l @r1,r12
L_0606FA7E:
    c.r[1] = ld32(0x0606FB04u);  // 0606FA7E mov.l 0x0606FB04,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FA80 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606FA82 extu.b r2,r2
    c.r[1] = ld32(0x0606FB08u);  // 0606FA84 mov.l 0x0606FB08,r1
    c.r[1] = ld32(c.r[1]);  // 0606FA86 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606FA88 shll2 r2
    c.r[2] <<= 2;  // 0606FA8A shll2 r2
    c.r[2] += c.r[1];  // 0606FA8C add r1,r2
    c.r[2] += 3;  // 0606FA8E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606FA90 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606FA92 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606FA94 shlr r0
    c.r[0] &= 0x3u;  // 0606FA96 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606FA98 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0606FAB4; } }  // 0606FA9A bf/s 0x0606FAB4 ; tst r3,r3
    { const bool k = !c.t; c.r[7] = 0x70u; if (k) { goto L_0606FAB4; } }  // 0606FA9E bf/s 0x0606FAB4 ; mov #112,r7
    c.r[7] += c.r[14];  // 0606FAA2 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FAA4 mov.l @r7,r0
    c.r[7] = 0x6Cu;  // 0606FAA6 mov #108,r7
    c.r[7] += c.r[14];  // 0606FAA8 add r14,r7
    st32(c.r[7], c.r[0]);  // 0606FAAA mov.l r0,@r7
    c.r[0] = 0x0u;  // 0606FAAC mov #0,r0
    c.r[7] = 0x70u;  // 0606FAAE mov #112,r7
    c.r[7] += c.r[14];  // 0606FAB0 add r14,r7
    st32(c.r[7], c.r[0]);  // 0606FAB2 mov.l r0,@r7
L_0606FAB4:
    c.r[7] = 0x70u;  // 0606FAB4 mov #112,r7
    c.r[7] += c.r[14];  // 0606FAB6 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FAB8 mov.l @r7,r0
    c.r[8] = ld32(0x0606FB0Cu);  // 0606FABA mov.l 0x0606FB0C,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606FABC mov.b @(r0,r8),r4
    c.r[9] = ld32(0x0606FB10u);  // 0606FABE mov.l 0x0606FB10,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0606FAC4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FAC4u) return; }  // 0606FAC0 jsr @r9 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0606FAC4 mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606FAC6 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606FAECu);  // 0606FAC8 mov.w 0x0606FAEC,r1
    c.t = c.r[2] == c.r[1];  // 0606FACA cmp/eq r1,r2
    { const bool k = c.t; c.r[7] = 0x70u; if (k) { goto L_0606FB16; } }  // 0606FACC bt/s 0x0606FB16 ; mov #112,r7
    c.r[1] = ld32(0x0606FAF8u);  // 0606FAD0 mov.l 0x0606FAF8,r1
    c.r[1] = ld32(c.r[1]);  // 0606FAD2 mov.l @r1,r1
    c.r[1] += 1;  // 0606FAD4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FAD6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606FAD8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606FADA tst r1,r1
    { const bool k = !c.t; c.r[7] += c.r[14]; if (k) { goto L_0606FB14; } }  // 0606FADC bf/s 0x0606FB14 ; add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FAE0 mov.l @r7,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606FAE2 mov.b @(r0,r8),r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606FAE8u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FAE8u) return; }  // 0606FAE4 jsr @r9 ; extu.b r4,r4
    c.r[1] = c.r[0]; goto L_0606FB1E;  // 0606FAE8 bra 0x0606FB1E ; mov r0,r1
L_0606FB14:
    c.r[7] = 0x70u;  // 0606FB14 mov #112,r7
L_0606FB16:
    c.r[7] += c.r[14];  // 0606FB16 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FB18 mov.l @r7,r0
    c.r[1] = ld32(0x0606FDACu);  // 0606FB1A mov.l 0x0606FDAC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606FB1C mov.b @(r0,r1),r1
L_0606FB1E:
    c.r[1] = c.r[1] & 0xFFu;  // 0606FB1E extu.b r1,r1
    c.r[0] = 0x70u;  // 0606FB20 mov #112,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 0606FB22 mov.l r1,@(r0,r14)
    c.r[10] = c.r[14];  // 0606FB24 mov r14,r10
    c.r[10] += 96;  // 0606FB26 add #96,r10
    c.r[9] = ld32(0x0606FDB0u);  // 0606FB28 mov.l 0x0606FDB0,r9
    c.r[7] = 0x6Cu;  // 0606FB2A mov #108,r7
    c.r[7] += c.r[14];  // 0606FB2C add r14,r7
    c.r[1] = ld32(c.r[9]);  // 0606FB2E mov.l @r9,r1
    c.r[8] = ld32(0x0606FDACu);  // 0606FB30 mov.l 0x0606FDAC,r8
    c.r[0] = ld32(c.r[7]);  // 0606FB32 mov.l @r7,r0
    c.r[1] += 1;  // 0606FB34 add #1,r1
    c.r[7] = 0x6Cu;  // 0606FB36 mov #108,r7
    c.r[7] += c.r[14];  // 0606FB38 add r14,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FB3A mov.b @r1,r6
    c.r[7] = ld32(0x0606FDB4u);  // 0606FB3C mov.l 0x0606FDB4,r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606FB3E mov.b @(r0,r8),r4
    c.r[6] <<= 2;  // 0606FB40 shll2 r6
    c.r[6] <<= 2;  // 0606FB42 shll2 r6
    c.r[6] <<= 2;  // 0606FB44 shll2 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606FB46 mov.b @(r0,r10),r1
    c.r[4] = c.r[4] & 0xFFu;  // 0606FB48 extu.b r4,r4
    c.r[6] |= c.r[1];  // 0606FB4A or r1,r6
    c.r[0] = 0x70u;  // 0606FB4C mov #112,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 0606FB4E mov.l @(r0,r14),r5
    { const uint32_t x = c.r[7]; c.pr = 0x0606FB54u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FB54u) return; }  // 0606FB50 jsr @r7 ; extu.b r6,r6
    c.r[11] = c.r[0];  // 0606FB54 mov r0,r11
    c.r[7] = 0x6Cu;  // 0606FB56 mov #108,r7
    c.r[1] = ld32(c.r[9]);  // 0606FB58 mov.l @r9,r1
    c.r[7] += c.r[14];  // 0606FB5A add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FB5C mov.l @r7,r0
    c.r[1] += 1;  // 0606FB5E add #1,r1
    c.r[7] = 0x6Cu;  // 0606FB60 mov #108,r7
    c.r[7] += c.r[14];  // 0606FB62 add r14,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FB64 mov.b @r1,r6
    c.r[7] = ld32(0x0606FDB8u);  // 0606FB66 mov.l 0x0606FDB8,r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606FB68 mov.b @(r0,r8),r4
    c.r[6] <<= 2;  // 0606FB6A shll2 r6
    c.r[6] <<= 2;  // 0606FB6C shll2 r6
    c.r[6] <<= 2;  // 0606FB6E shll2 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606FB70 mov.b @(r0,r10),r1
    c.r[4] = c.r[4] & 0xFFu;  // 0606FB72 extu.b r4,r4
    c.r[6] |= c.r[1];  // 0606FB74 or r1,r6
    c.r[0] = 0x70u;  // 0606FB76 mov #112,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 0606FB78 mov.l @(r0,r14),r5
    { const uint32_t x = c.r[7]; c.pr = 0x0606FB7Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FB7Eu) return; }  // 0606FB7A jsr @r7 ; extu.b r6,r6
    c.r[12] = c.r[0];  // 0606FB7E mov r0,r12
L_0606FB80:
    c.r[7] = 0x6Cu;  // 0606FB80 mov #108,r7
    c.r[7] += c.r[14];  // 0606FB82 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FB84 mov.l @r7,r0
    c.r[1] = ld32(0x0606FDACu);  // 0606FB86 mov.l 0x0606FDAC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606FB88 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606FB8A extu.b r2,r2
    c.r[1] = ld32(0x0606FDBCu);  // 0606FB8C mov.l 0x0606FDBC,r1
    c.r[1] = ld32(c.r[1]);  // 0606FB8E mov.l @r1,r1
    c.r[2] <<= 2;  // 0606FB90 shll2 r2
    c.r[2] <<= 2;  // 0606FB92 shll2 r2
    c.r[2] += c.r[1];  // 0606FB94 add r1,r2
    c.r[2] += 2;  // 0606FB96 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606FB98 mov.b @r2,r2
    c.r[1] = ld32(0x0606FDC0u);  // 0606FB9A mov.l 0x0606FDC0,r1
    c.r[3] = ld32(c.r[1]);  // 0606FB9C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606FB9E extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606FBA0 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606FBA2 mul.l r1,r2
    c.r[1] = c.macl;  // 0606FBA4 sts macl,r1
    c.r[1] += c.r[3];  // 0606FBA6 add r3,r1
    c.r[1] += 15;  // 0606FBA8 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FBAA mov.b @r1,r1
    c.r[4] = c.r[14];  // 0606FBAC mov r14,r4
    c.r[13] = c.r[1] & 0xFFu;  // 0606FBAE extu.b r1,r13
    c.r[1] = ld32(0x0606FDC4u);  // 0606FBB0 mov.l 0x0606FDC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FBB6u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FBB6u) return; }  // 0606FBB2 jsr @r1 ; mov r13,r5
    c.r[8] = 0x1u;  // 0606FBB6 mov #1,r8
    c.r[9] = 0x0u;  // 0606FBB8 mov #0,r9
    c.r[10] = c.r[13];  // 0606FBBA mov r13,r10
    c.r[10] += c.r[10];  // 0606FBBC add r10,r10
    c.r[10] += c.r[13];  // 0606FBBE add r13,r10
    c.r[10] <<= 2;  // 0606FBC0 shll2 r10
L_0606FBC2:
    c.r[0] = ld32(0x0606FDC8u);  // 0606FBC2 mov.l 0x0606FDC8,r0
    c.r[1] = ld32(c.r[0]);  // 0606FBC4 mov.l @r0,r1
    c.r[4] = c.r[14];  // 0606FBC6 mov r14,r4
    c.r[1] += c.r[10];  // 0606FBC8 add r10,r1
    c.r[1] += 2;  // 0606FBCA add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FBCC mov.b @r1,r5
    c.r[7] = ld32(0x0606FDCCu);  // 0606FBCE mov.l 0x0606FDCC,r7
    c.r[5] += c.r[8];  // 0606FBD0 add r8,r5
    { const uint32_t x = c.r[7]; c.pr = 0x0606FBD6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FBD6u) return; }  // 0606FBD2 jsr @r7 ; extu.b r5,r5
    c.r[1] = c.r[0];  // 0606FBD6 mov r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606FBD8 extu.w r1,r1
    c.r[8] += 1;  // 0606FBDA add #1,r8
    c.r[0] = 0x4u;  // 0606FBDC mov #4,r0
    c.t = (int32_t)c.r[8] > (int32_t)c.r[0];  // 0606FBDE cmp/gt r0,r8
    { const bool k = !c.t; c.r[9] += c.r[1]; if (k) { SH2_POLL(c); goto L_0606FBC2; } }  // 0606FBE0 bf/s 0x0606FBC2 ; add r1,r9
    c.r[7] = ld32(0x0606FDC8u);  // 0606FBE4 mov.l 0x0606FDC8,r7
    c.r[0] = 0x78u;  // 0606FBE6 mov #120,r0
    c.r[3] = ld32(c.r[7]);  // 0606FBE8 mov.l @r7,r3
    c.r[0] += c.r[14];  // 0606FBEA add r14,r0
    c.r[7] = c.r[13];  // 0606FBEC mov r13,r7
    c.r[7] += c.r[7];  // 0606FBEE add r7,r7
    st32(c.r[0], c.r[7]);  // 0606FBF0 mov.l r7,@r0
    c.r[0] = 0x78u;  // 0606FBF2 mov #120,r0
    c.r[0] += c.r[14];  // 0606FBF4 add r14,r0
    c.r[7] = ld32(c.r[0]);  // 0606FBF6 mov.l @r0,r7
    c.r[7] += c.r[13];  // 0606FBF8 add r13,r7
    st32(c.r[0], c.r[7]);  // 0606FBFA mov.l r7,@r0
    c.r[0] = 0x78u;  // 0606FBFC mov #120,r0
    c.r[0] += c.r[14];  // 0606FBFE add r14,r0
    c.r[7] = ld32(c.r[0]);  // 0606FC00 mov.l @r0,r7
    c.r[7] <<= 2;  // 0606FC02 shll2 r7
    st32(c.r[0], c.r[7]);  // 0606FC04 mov.l r7,@r0
    c.r[0] = 0x78u;  // 0606FC06 mov #120,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606FC08 mov.l @(r0,r14),r0
    c.r[3] += c.r[0];  // 0606FC0A add r0,r3
    c.r[3] += 4;  // 0606FC0C add #4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606FC0E mov.w @r3,r1
    c.r[1] += c.r[12];  // 0606FC10 add r12,r1
    st16(c.r[3], c.r[1]);  // 0606FC12 mov.w r1,@r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606FC14 mov.w @r3,r2
    c.r[1] = c.r[2];  // 0606FC16 mov r2,r1
    c.r[1] -= c.r[12];  // 0606FC18 sub r12,r1
    c.r[1] += c.r[9];  // 0606FC1A add r9,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606FC1C cmp/pz r1
    if (c.t) { goto L_0606FC24; }  // 0606FC1E bt 0x0606FC24
    c.r[12] = c.r[9];  // 0606FC20 mov r9,r12
    c.r[12] += c.r[2];  // 0606FC22 add r2,r12
L_0606FC24:
    c.r[2] -= c.r[12];  // 0606FC24 sub r12,r2
    st16(c.r[3], c.r[2]);  // 0606FC26 mov.w r2,@r3
    c.r[1] = ld32(0x0606FDD0u);  // 0606FC28 mov.l 0x0606FDD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FC2Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC2Eu) return; }  // 0606FC2A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606FDD4u);  // 0606FC2E mov.l 0x0606FDD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FC34u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC34u) return; }  // 0606FC30 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606FDD8u);  // 0606FC34 mov.l 0x0606FDD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FC3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC3Au) return; }  // 0606FC36 jsr @r1 ; nop
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606FD9Cu);  // 0606FC3A mov.w 0x0606FD9C,r8
    c.r[9] = ld32(0x0606FDDCu);  // 0606FC3C mov.l 0x0606FDDC,r9
    c.r[5] = c.r[11];  // 0606FC3E mov r11,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606FC44u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC44u) return; }  // 0606FC40 jsr @r9 ; mov r8,r4
    c.r[5] = c.r[12];  // 0606FC44 mov r12,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606FC4Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC4Au) return; }  // 0606FC46 jsr @r9 ; mov r8,r4
    c.r[7] = 0x6Cu;  // 0606FC4A mov #108,r7
    c.r[7] += c.r[14];  // 0606FC4C add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FC4E mov.l @r7,r0
    c.r[1] = ld32(0x0606FDACu);  // 0606FC50 mov.l 0x0606FDAC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606FC52 mov.b @(r0,r1),r4
    c.r[0] = ld32(0x0606FDE0u);  // 0606FC54 mov.l 0x0606FDE0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606FC5Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC5Au) return; }  // 0606FC56 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0606FC5A mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606FC5C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606FC5E tst r1,r1
    { const bool k = c.t; c.r[10] = c.r[14]; if (k) { goto L_0606FD06; } }  // 0606FC60 bt/s 0x0606FD06 ; mov r14,r10
    c.r[10] += 48;  // 0606FC64 add #48,r10
    c.r[1] = ld32(0x0606FDC4u);  // 0606FC66 mov.l 0x0606FDC4,r1
    c.r[5] = c.r[13];  // 0606FC68 mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606FC6Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC6Eu) return; }  // 0606FC6A jsr @r1 ; mov r10,r4
    c.r[8] = ld32(0x0606FDE4u);  // 0606FC6E mov.l 0x0606FDE4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC74u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC74u) return; }  // 0606FC70 jsr @r8 ; mov #4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FD9Eu);  // 0606FC74 mov.w 0x0606FD9E,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC7Au; c.r[9] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC7Au) return; }  // 0606FC76 jsr @r8 ; mov r14,r9
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC7Eu; c.r[4] = 0x2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC7Eu) return; }  // 0606FC7A jsr @r8 ; mov #46,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC82u; c.r[4] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC82u) return; }  // 0606FC7E jsr @r8 ; mov #13,r4
    c.r[9] += 104;  // 0606FC82 add #104,r9
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606FC84 mov.b @r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC8Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC8Au) return; }  // 0606FC86 jsr @r8 ; extu.b r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC8Eu; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC8Eu) return; }  // 0606FC8A jsr @r8 ; mov #18,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FDA0u);  // 0606FC8E mov.w 0x0606FDA0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC94u) return; }  // 0606FC90 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0606FC98u; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FC98u) return; }  // 0606FC94 jsr @r8 ; mov #14,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606FC98 mov.b @r9,r4
    c.r[4] += 1;  // 0606FC9A add #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FCA0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FCA0u) return; }  // 0606FC9C jsr @r8 ; extu.b r4,r4
    c.r[4] = ld32(0x0606FDE8u);  // 0606FCA0 mov.l 0x0606FDE8,r4
    c.r[8] = ld32(0x0606FDECu);  // 0606FCA2 mov.l 0x0606FDEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606FCA8u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FCA8u) return; }  // 0606FCA4 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 0606FCA8 mov r0,r1
    c.r[5] = 0xAu;  // 0606FCAA mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FCB0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FCB0u) return; }  // 0606FCAC jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0606FCB0 mov r0,r2
    c.r[1] = ld32(0x0606FDF0u);  // 0606FCB2 mov.l 0x0606FDF0,r1
    c.r[6] = 0x0u;  // 0606FCB4 mov #0,r6
    c.r[5] = 0x4u;  // 0606FCB6 mov #4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606FCBCu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FCBCu) return; }  // 0606FCB8 jsr @r1 ; mov r2,r4
    c.r[7] = ld32(0x0606FDC8u);  // 0606FCBC mov.l 0x0606FDC8,r7
    c.r[0] = 0x78u;  // 0606FCBE mov #120,r0
    c.r[1] = ld32(c.r[7]);  // 0606FCC0 mov.l @r7,r1
    c.r[0] += c.r[14];  // 0606FCC2 add r14,r0
    c.r[7] = ld32(c.r[0]);  // 0606FCC4 mov.l @r0,r7
    c.r[7] += c.r[1];  // 0606FCC6 add r1,r7
    st32(c.r[0], c.r[7]);  // 0606FCC8 mov.l r7,@r0
    c.r[0] = 0x78u;  // 0606FCCA mov #120,r0
    c.r[0] += c.r[14];  // 0606FCCC add r14,r0
    c.r[7] = ld32(c.r[0]);  // 0606FCCE mov.l @r0,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606FDA2u);  // 0606FCD0 mov.w 0x0606FDA2,r5
    c.r[7] += 2;  // 0606FCD2 add #2,r7
    st32(c.r[0], c.r[7]);  // 0606FCD4 mov.l r7,@r0
    c.r[0] = 0x78u;  // 0606FCD6 mov #120,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0606FCD8 mov.l @(r0,r14),r7
    c.r[4] = 0x0u;  // 0606FCDA mov #0,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606FCDC mov.b @r7,r6
    c.r[1] = ld32(0x0606FDF4u);  // 0606FCDE mov.l 0x0606FDF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FCE4u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FCE4u) return; }  // 0606FCE0 jsr @r1 ; extu.b r6,r6
    c.r[6] = c.r[9];  // 0606FCE4 mov r9,r6
    c.r[5] = c.r[10];  // 0606FCE6 mov r10,r5
    c.r[4] = c.r[14];  // 0606FCE8 mov r14,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606FCEA mov.b @r9,r1
    c.r[0] = ld32(0x0606FDF8u);  // 0606FCEC mov.l 0x0606FDF8,r0
    c.r[1] += 4;  // 0606FCEE add #4,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0606FCF4u; st8(c.r[9], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FCF4u) return; }  // 0606FCF0 jsr @r0 ; mov.b r1,@r9
    c.r[2] = c.r[0];  // 0606FCF4 mov r0,r2
    c.r[0] = 0x1u;  // 0606FCF6 mov #1,r0
    c.r[7] = 0x74u;  // 0606FCF8 mov #116,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606FCFA mov.b @r9,r1
    c.r[7] += c.r[14];  // 0606FCFC add r14,r7
    c.r[2] += c.r[1];  // 0606FCFE add r1,r2
    st8(c.r[9], c.r[2]);  // 0606FD00 mov.b r2,@r9
    st32(c.r[7], c.r[0]); goto L_0606FD20;  // 0606FD02 bra 0x0606FD20 ; mov.l r0,@r7
L_0606FD06:
    c.r[8] = ld32(0x0606FDE4u);  // 0606FD06 mov.l 0x0606FDE4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606FD0Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FD0Cu) return; }  // 0606FD08 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FD10u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FD10u) return; }  // 0606FD0C jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FD14u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FD14u) return; }  // 0606FD10 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FD18u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FD18u) return; }  // 0606FD14 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FD1Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FD1Cu) return; }  // 0606FD18 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FD20u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FD20u) return; }  // 0606FD1C jsr @r8 ; mov #0,r4
L_0606FD20:
    c.r[1] = ld32(0x0606FDB0u);  // 0606FD20 mov.l 0x0606FDB0,r1
    c.r[1] = ld32(c.r[1]);  // 0606FD22 mov.l @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606FDA4u);  // 0606FD24 mov.w 0x0606FDA4,r13
    c.r[1] += 1;  // 0606FD26 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FD28 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606FD2A extu.b r1,r1
    c.r[0] = c.r[1];  // 0606FD2C mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0606FD2E cmp/eq #3,r0
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_0606FE04; } }  // 0606FD30 bf/s 0x0606FE04 ; mov #0,r12
    c.r[5] = ld32(0x0606FDFCu);  // 0606FD34 mov.l 0x0606FDFC,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FDA6u);  // 0606FD36 mov.w 0x0606FDA6,r4
    c.r[7] = 0xFu;  // 0606FD38 mov #15,r7
    c.macl = c.r[7] * c.r[4];  // 0606FD3A mul.l r4,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606FDA8u);  // 0606FD3C mov.w 0x0606FDA8,r6
    c.r[1] = ld32(c.r[5]);  // 0606FD3E mov.l @r5,r1
    c.r[2] = c.macl;  // 0606FD40 sts macl,r2
    c.r[2] += c.r[1];  // 0606FD42 add r1,r2
    c.r[0] = c.r[2];  // 0606FD44 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606FD46 mov.b @(r0,r6),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606FD48 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606FD4A tst r3,r3
    { const bool k = !c.t; c.r[2] += 4; if (k) { goto L_0606FD54; } }  // 0606FD4C bf/s 0x0606FD54 ; add #4,r2
    goto L_0606FE52;  // 0606FD50 bra 0x0606FE52 ; nop
L_0606FD54:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606FD54 mov.b @r2,r1
    c.r[11] = 0x1u;  // 0606FD56 mov #1,r11
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[3];  // 0606FD58 cmp/ge r3,r11
    { const bool k = c.t; c.r[13] = c.r[1] & 0xFFu; if (k) { goto L_0606FE52; } }  // 0606FD5A bt/s 0x0606FE52 ; extu.b r1,r13
    c.r[8] = ld32(0x0606FE00u);  // 0606FD5E mov.l 0x0606FE00,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606FDAAu);  // 0606FD60 mov.w 0x0606FDAA,r10
    c.r[12] = c.r[11];  // 0606FD62 mov r11,r12
    c.r[3] = 0x8u;  // 0606FD64 mov #8,r3
    c.r[7] = 0xFu;  // 0606FD66 mov #15,r7
    c.macl = c.r[7] * c.r[4];  // 0606FD68 mul.l r4,r7
L_0606FD6A:
    c.r[1] = ld32(c.r[5]);  // 0606FD6A mov.l @r5,r1
    c.r[2] = c.macl;  // 0606FD6C sts macl,r2
    c.r[2] += c.r[1];  // 0606FD6E add r1,r2
    c.r[2] += c.r[3];  // 0606FD70 add r3,r2
    c.r[2] += 4;  // 0606FD72 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606FD74 mov.b @r2,r1
    c.r[9] = ld32(c.r[8]);  // 0606FD76 mov.l @r8,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606FD78 extu.b r1,r1
    c.r[9] += c.r[1];  // 0606FD7A add r1,r9
    c.r[0] = c.r[9];  // 0606FD7C mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606FD7E mov.b @(r0,r10),r1
    c.r[11] += 1;  // 0606FD80 add #1,r11
    c.r[1] += 1;  // 0606FD82 add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0606FD84 mov.b r1,@(r0,r10)
    c.r[1] = ld32(c.r[5]);  // 0606FD86 mov.l @r5,r1
    c.r[2] = c.macl;  // 0606FD88 sts macl,r2
    c.r[2] += c.r[1];  // 0606FD8A add r1,r2
    c.r[0] = c.r[2];  // 0606FD8C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606FD8E mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606FD90 extu.b r1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 0606FD92 cmp/ge r1,r11
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_0606FD6A; } }  // 0606FD94 bf/s 0x0606FD6A ; add #8,r3
    goto L_0606FE52;  // 0606FD98 bra 0x0606FE52 ; nop
L_0606FE04:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606FE04 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_0606FE52; } }  // 0606FE06 bf/s 0x0606FE52 ; mov r14,r1
    c.r[7] = 0x6Cu;  // 0606FE0A mov #108,r7
    c.r[7] += c.r[14];  // 0606FE0C add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FE0E mov.l @r7,r0
    c.r[1] += 96;  // 0606FE10 add #96,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606FE12 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606FE14 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606FE16 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x70u; if (k) { goto L_0606FE52; } }  // 0606FE18 bt/s 0x0606FE52 ; mov #112,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 0606FE1C mov.l @(r0,r14),r2
    c.r[1] = ld32(0x0606FFE0u);  // 0606FE1E mov.l 0x0606FFE0,r1
    c.r[1] = ld32(c.r[1]);  // 0606FE20 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606FE22 shll2 r2
    c.r[2] <<= 2;  // 0606FE24 shll2 r2
    c.r[2] += c.r[1];  // 0606FE26 add r1,r2
    c.r[1] = c.r[2];  // 0606FE28 mov r2,r1
    c.r[1] += 7;  // 0606FE2A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FE2C mov.b @r1,r1
    c.r[7] = 0x1u;  // 0606FE2E mov #1,r7
    c.r[1] >>= 2;  // 0606FE30 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606FE32 shlr r1
    c.r[1] &= c.r[7];  // 0606FE34 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606FE36 tst r1,r1
    { const bool k = c.t; c.r[2] += 2; if (k) { goto L_0606FE52; } }  // 0606FE38 bt/s 0x0606FE52 ; add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606FE3C mov.b @r2,r2
    c.r[1] = ld32(0x0606FFE4u);  // 0606FE3E mov.l 0x0606FFE4,r1
    c.r[3] = ld32(c.r[1]);  // 0606FE40 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606FE42 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606FE44 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606FE46 mul.l r1,r2
    c.r[1] = c.macl;  // 0606FE48 sts macl,r1
    c.r[1] += c.r[3];  // 0606FE4A add r3,r1
    c.r[1] += 26;  // 0606FE4C add #26,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606FE4E mov.b @r1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0606FE50 extu.b r1,r13
L_0606FE52:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606FFD2u);  // 0606FE52 mov.w 0x0606FFD2,r1
    c.t = c.r[13] == c.r[1];  // 0606FE54 cmp/eq r1,r13
    { const bool k = !c.t; c.r[2] = 0x8u; if (k) { goto L_0606FE5E; } }  // 0606FE56 bf/s 0x0606FE5E ; mov #8,r2
    goto L_0606FF84;  // 0606FE5A bra 0x0606FF84 ; nop
L_0606FE5E:
    c.r[1] = ld32(0x0606FFE8u);  // 0606FE5E mov.l 0x0606FFE8,r1
    c.r[1] = ld32(c.r[1]);  // 0606FE60 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606FFD4u);  // 0606FE62 mov.w 0x0606FFD4,r0
    c.r[1] += c.r[13];  // 0606FE64 add r13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606FE66 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606FE68 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606FE6A cmp/hi r2,r1
    if (!c.t) { goto L_0606FE72; }  // 0606FE6C bf 0x0606FE72
    goto L_0606FF84;  // 0606FE6E bra 0x0606FF84 ; nop
L_0606FE72:
    c.r[10] = ld32(0x0606FFECu);  // 0606FE72 mov.l 0x0606FFEC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0606FE78u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FE78u) return; }  // 0606FE74 jsr @r10 ; mov #4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FFD6u);  // 0606FE78 mov.w 0x0606FFD6,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FE7Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FE7Eu) return; }  // 0606FE7A jsr @r10 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x0606FE82u; c.r[4] = 0x2Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FE82u) return; }  // 0606FE7E jsr @r10 ; mov #47,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FE86u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FE86u) return; }  // 0606FE82 jsr @r10 ; mov #5,r4
    c.r[7] = c.r[14];  // 0606FE86 mov r14,r7
    c.r[7] += 104;  // 0606FE88 add #104,r7
    c.r[0] = 0x7Cu;  // 0606FE8A mov #124,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 0606FE8C mov.l r7,@(r0,r14)
    c.r[0] = 0x7Cu;  // 0606FE8E mov #124,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0606FE90 mov.l @(r0,r14),r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606FE92 mov.b @r7,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FE98u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FE98u) return; }  // 0606FE94 jsr @r10 ; extu.b r4,r4
    c.t = (c.r[12] & c.r[12]) == 0;  // 0606FE98 tst r12,r12
    { const bool k = c.t; c.r[5] = 0xFu; if (k) { goto L_0606FEF2; } }  // 0606FE9A bt/s 0x0606FEF2 ; mov #15,r5
    c.r[4] = ld32(0x0606FFF0u);  // 0606FE9E mov.l 0x0606FFF0,r4
    c.r[8] = ld32(0x0606FFF4u);  // 0606FEA0 mov.l 0x0606FFF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606FEA6u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEA6u) return; }  // 0606FEA2 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 0606FEA6 mov r0,r1
    c.r[5] = 0xAu;  // 0606FEA8 mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FEAEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEAEu) return; }  // 0606FEAA jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606FEAE mov r0,r1
    c.r[5] = 0x15u;  // 0606FEB0 mov #21,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FEB6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEB6u) return; }  // 0606FEB2 jsr @r8 ; mov r1,r4
    c.r[12] = c.r[0];  // 0606FEB6 mov r0,r12
    c.r[5] = 0x1u;  // 0606FEB8 mov #1,r5
    c.r[0] = ld32(0x0606FFF8u);  // 0606FEBA mov.l 0x0606FFF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606FEC0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEC0u) return; }  // 0606FEBC jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 0606FEC0 mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606FEC2 extu.b r1,r11
    c.r[4] = c.r[11];  // 0606FEC4 mov r11,r4
    c.r[4] += 4;  // 0606FEC6 add #4,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FECCu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FECCu) return; }  // 0606FEC8 jsr @r10 ; extu.b r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FFD8u);  // 0606FECC mov.w 0x0606FFD8,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FED2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FED2u) return; }  // 0606FECE jsr @r10 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x0606FED6u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FED6u) return; }  // 0606FED2 jsr @r10 ; mov #6,r4
    c.r[7] = 0x7Cu;  // 0606FED6 mov #124,r7
    c.r[7] += c.r[14];  // 0606FED8 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FEDA mov.l @r7,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606FEDC mov.b @r0,r4
    c.r[4] += 1;  // 0606FEDE add #1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FEE4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEE4u) return; }  // 0606FEE0 jsr @r10 ; extu.b r4,r4
    c.r[6] = c.r[11] & 0xFFu;  // 0606FEE4 extu.b r11,r6
    c.r[1] = ld32(0x0606FFFCu);  // 0606FEE6 mov.l 0x0606FFFC,r1
    c.r[5] = c.r[12];  // 0606FEE8 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606FEEEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEEEu) return; }  // 0606FEEA jsr @r1 ; mov #1,r4
    goto L_0606FF6A;  // 0606FEEE bra 0x0606FF6A ; nop
L_0606FEF2:
    c.r[9] = ld32(0x0606FFF0u);  // 0606FEF2 mov.l 0x0606FFF0,r9
    c.r[8] = ld32(0x0606FFF4u);  // 0606FEF4 mov.l 0x0606FFF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606FEFAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FEFAu) return; }  // 0606FEF6 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0606FEFA mov r0,r1
    c.r[5] = c.r[13];  // 0606FEFC mov r13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF02u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF02u) return; }  // 0606FEFE jsr @r8 ; mov r1,r4
    c.r[12] = c.r[0];  // 0606FF02 mov r0,r12
    c.r[5] = 0x1u;  // 0606FF04 mov #1,r5
    c.r[7] = ld32(0x0606FFF8u);  // 0606FF06 mov.l 0x0606FFF8,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0606FF0Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF0Cu) return; }  // 0606FF08 jsr @r7 ; mov r12,r4
    c.r[1] = c.r[0];  // 0606FF0C mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606FF0E extu.b r1,r11
    c.r[4] = c.r[11];  // 0606FF10 mov r11,r4
    c.r[4] += 20;  // 0606FF12 add #20,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FF18u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF18u) return; }  // 0606FF14 jsr @r10 ; extu.b r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FFD8u);  // 0606FF18 mov.w 0x0606FFD8,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FF1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF1Eu) return; }  // 0606FF1A jsr @r10 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x0606FF22u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF22u) return; }  // 0606FF1E jsr @r10 ; mov #6,r4
    c.r[0] = 0x7Cu;  // 0606FF22 mov #124,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0606FF24 mov.l @(r0,r14),r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606FF26 mov.b @r7,r4
    c.r[4] += 1;  // 0606FF28 add #1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606FF2Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF2Eu) return; }  // 0606FF2A jsr @r10 ; extu.b r4,r4
    c.r[5] = 0x17u;  // 0606FF2E mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF34u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF34u) return; }  // 0606FF30 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0606FF34 mov r0,r1
    c.r[5] = 0xAu;  // 0606FF36 mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF3Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF3Cu) return; }  // 0606FF38 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606FF3C mov r0,r1
    c.r[10] = ld32(0x06070000u);  // 0606FF3E mov.l 0x06070000,r10
    c.r[6] = 0x0u;  // 0606FF40 mov #0,r6
    c.r[5] = 0xAu;  // 0606FF42 mov #10,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606FF48u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF48u) return; }  // 0606FF44 jsr @r10 ; mov r1,r4
    c.r[6] = c.r[11] & 0xFFu;  // 0606FF48 extu.b r11,r6
    c.r[1] = ld32(0x0606FFFCu);  // 0606FF4A mov.l 0x0606FFFC,r1
    c.r[5] = c.r[12];  // 0606FF4C mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606FF52u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF52u) return; }  // 0606FF4E jsr @r1 ; mov #1,r4
    c.r[5] = 0x17u;  // 0606FF52 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF58u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF58u) return; }  // 0606FF54 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0606FF58 mov r0,r1
    c.r[5] = 0xAu;  // 0606FF5A mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF60u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF60u) return; }  // 0606FF5C jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606FF60 mov r0,r1
    c.r[6] = 0x0u;  // 0606FF62 mov #0,r6
    c.r[5] = 0xBu;  // 0606FF64 mov #11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606FF6Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF6Au) return; }  // 0606FF66 jsr @r10 ; mov r1,r4
L_0606FF6A:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606FFDAu);  // 0606FF6A mov.w 0x0606FFDA,r4
    c.r[1] = ld32(0x0606FFECu);  // 0606FF6C mov.l 0x0606FFEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FF72u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF72u) return; }  // 0606FF6E jsr @r1 ; nop
    c.r[1] = ld32(0x0606FFE8u);  // 0606FF72 mov.l 0x0606FFE8,r1
    c.r[3] = ld32(c.r[1]);  // 0606FF74 mov.l @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606FFD4u);  // 0606FF76 mov.w 0x0606FFD4,r2
    c.r[3] += c.r[13];  // 0606FF78 add r13,r3
    c.r[0] = c.r[3];  // 0606FF7A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606FF7C mov.b @(r0,r2),r1
    c.r[1] += 1;  // 0606FF7E add #1,r1
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0606FF8E;  // 0606FF80 bra 0x0606FF8E ; mov.b r1,@(r0,r2)
L_0606FF84:
    c.r[8] = ld32(0x0606FFECu);  // 0606FF84 mov.l 0x0606FFEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF8Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF8Au) return; }  // 0606FF86 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606FF8Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF8Eu) return; }  // 0606FF8A jsr @r8 ; mov #0,r4
L_0606FF8E:
    c.r[1] = ld32(0x06070004u);  // 0606FF8E mov.l 0x06070004,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606FF94u; c.r[4] = 0x13u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606FF94u) return; }  // 0606FF90 jsr @r1 ; mov #19,r4
    c.r[7] = 0x74u;  // 0606FF94 mov #116,r7
    c.r[7] += c.r[14];  // 0606FF96 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FF98 mov.l @r7,r0
    c.r[0] += c.r[0];  // 0606FF9A add r0,r0
    st32(c.r[7], c.r[0]);  // 0606FF9C mov.l r0,@r7
    c.r[7] = 0x74u;  // 0606FF9E mov #116,r7
    c.r[7] += c.r[14];  // 0606FFA0 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FFA2 mov.l @r7,r0
    c.r[0] += 2;  // 0606FFA4 add #2,r0
    st32(c.r[7], c.r[0]);  // 0606FFA6 mov.l r0,@r7
    c.r[7] = 0x74u;  // 0606FFA8 mov #116,r7
    c.r[7] += c.r[14];  // 0606FFAA add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FFAC mov.l @r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606FFDCu);  // 0606FFAE mov.w 0x0606FFDC,r1
    c.r[0] |= c.r[1];  // 0606FFB0 or r1,r0
    st32(c.r[7], c.r[0]);  // 0606FFB2 mov.l r0,@r7
    c.r[7] = 0x74u;  // 0606FFB4 mov #116,r7
    c.r[7] += c.r[14];  // 0606FFB6 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0606FFB8 mov.l @r7,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606FFDEu);  // 0606FFBA mov.w 0x0606FFDE,r3
    c.r[14] += c.r[3];  // 0606FFBC add r3,r14
    c.r[15] = c.r[14];  // 0606FFBE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606FFC0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606FFC2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606FFC4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606FFC6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606FFC8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606FFCA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606FFCC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606FFCE rts ; mov.l @r15+,r8
}

void f_06070008(SH2Context& c) {
    ran[1582] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06070008 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607000A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607000C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607000E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06070010 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06070012 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06070014 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06070016 sts.l pr,@-r15
    c.r[15] -= 28;  // 06070018 add #-28,r15
    c.r[14] = c.r[15];  // 0607001A mov r15,r14
    st32(c.r[14], c.r[4]);  // 0607001C mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0607001E mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06070020 mov.l r6,@(8,r14)
    c.r[13] = 0x0u;  // 06070022 mov #0,r13
    c.r[3] = 0x5u;  // 06070024 mov #5,r3
    c.r[2] = ld32(c.r[14]);  // 06070026 mov.l @r14,r2
L_06070028:
    c.r[1] = ld32(c.r[14] + 4);  // 06070028 mov.l @(4,r14),r1
    c.r[2] += c.r[13];  // 0607002A add r13,r2
    c.r[2] += 24;  // 0607002C add #24,r2
    c.r[1] += c.r[13];  // 0607002E add r13,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070030 mov.b @r2,r2
    c.r[1] += 24;  // 06070032 add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070034 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06070036 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06070038 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0607003A cmp/eq r1,r2
    if (!c.t) { goto L_06070046; }  // 0607003C bf 0x06070046
    c.r[13] += 1;  // 0607003E add #1,r13
    c.t = (int32_t)c.r[13] > (int32_t)c.r[3];  // 06070040 cmp/gt r3,r13
    { const bool k = !c.t; c.r[2] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_06070028; } }  // 06070042 bf/s 0x06070028 ; mov.l @r14,r2
L_06070046:
    c.r[0] = 0x0u;  // 06070046 mov #0,r0
    st32(c.r[14] + 20, c.r[0]);  // 06070048 mov.l r0,@(20,r14)
    c.r[12] = ld32(0x06070250u);  // 0607004A mov.l 0x06070250,r12
    c.r[11] = 0x3u;  // 0607004C mov #3,r11
    c.r[10] = ld32(c.r[14] + 4);  // 0607004E mov.l @(4,r14),r10
L_06070050:
    c.r[5] = c.r[10];  // 06070050 mov r10,r5
    c.r[5] += 30;  // 06070052 add #30,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06070054 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06070056 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06070058 tst r1,r1
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 20); if (k) { goto L_0607008C; } }  // 0607005A bt/s 0x0607008C ; mov.l @(20,r14),r7
    c.r[8] = 0x0u;  // 0607005E mov #0,r8
    c.r[9] = c.r[5];  // 06070060 mov r5,r9
    c.r[1] = ld32(c.r[14]);  // 06070062 mov.l @r14,r1
L_06070064:
    c.r[1] += c.r[8];  // 06070064 add r8,r1
    c.r[1] += 30;  // 06070066 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070068 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0607006A extu.b r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0607006C tst r4,r4
    if (c.t) { goto L_0607007C; }  // 0607006E bt 0x0607007C
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06070070 mov.b @r9,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06070076u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070076u) return; }  // 06070072 jsr @r12 ; extu.b r5,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070076 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_06070086; } }  // 06070078 bf/s 0x06070086 ; mov r8,r0
L_0607007C:
    c.r[8] += 1;  // 0607007C add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[11];  // 0607007E cmp/gt r11,r8
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_06070064; } }  // 06070080 bf/s 0x06070064 ; mov.l @r14,r1
    c.r[0] = c.r[8];  // 06070084 mov r8,r0
L_06070086:
    c.t = c.r[0] == 0x4u;  // 06070086 cmp/eq #4,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 20); if (k) { goto L_06070096; } }  // 06070088 bt/s 0x06070096 ; mov.l @(20,r14),r7
L_0607008C:
    c.r[10] += 1;  // 0607008C add #1,r10
    c.r[7] += 1;  // 0607008E add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[11];  // 06070090 cmp/gt r11,r7
    { const bool k = !c.t; st32(c.r[14] + 20, c.r[7]); if (k) { SH2_POLL(c); goto L_06070050; } }  // 06070092 bf/s 0x06070050 ; mov.l r7,@(20,r14)
L_06070096:
    c.r[0] = 0x0u;  // 06070096 mov #0,r0
    st32(c.r[14] + 24, c.r[0]);  // 06070098 mov.l r0,@(24,r14)
    c.r[12] = ld32(0x06070250u);  // 0607009A mov.l 0x06070250,r12
    c.r[11] = 0x3u;  // 0607009C mov #3,r11
    c.r[10] = ld32(c.r[14] + 4);  // 0607009E mov.l @(4,r14),r10
L_060700A0:
    c.r[5] = c.r[10];  // 060700A0 mov r10,r5
    c.r[5] += 30;  // 060700A2 add #30,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060700A4 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060700A6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060700A8 tst r1,r1
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 24); if (k) { goto L_060700DC; } }  // 060700AA bt/s 0x060700DC ; mov.l @(24,r14),r7
    c.r[8] = 0x0u;  // 060700AE mov #0,r8
    c.r[9] = c.r[5];  // 060700B0 mov r5,r9
    c.r[1] = ld32(c.r[14]);  // 060700B2 mov.l @r14,r1
L_060700B4:
    c.r[1] += c.r[8];  // 060700B4 add r8,r1
    c.r[1] += 30;  // 060700B6 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060700B8 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060700BA extu.b r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060700BC tst r4,r4
    if (c.t) { goto L_060700CC; }  // 060700BE bt 0x060700CC
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060700C0 mov.b @r9,r5
    { const uint32_t x = c.r[12]; c.pr = 0x060700C6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060700C6u) return; }  // 060700C2 jsr @r12 ; extu.b r5,r5
    c.t = c.r[0] == 0x1u;  // 060700C6 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060700D6; } }  // 060700C8 bt/s 0x060700D6 ; mov r8,r0
L_060700CC:
    c.r[8] += 1;  // 060700CC add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[11];  // 060700CE cmp/gt r11,r8
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_060700B4; } }  // 060700D0 bf/s 0x060700B4 ; mov.l @r14,r1
    c.r[0] = c.r[8];  // 060700D4 mov r8,r0
L_060700D6:
    c.t = c.r[0] == 0x4u;  // 060700D6 cmp/eq #4,r0
    { const bool k = !c.t; c.r[7] = ld32(c.r[14] + 24); if (k) { goto L_060700E6; } }  // 060700D8 bf/s 0x060700E6 ; mov.l @(24,r14),r7
L_060700DC:
    c.r[10] += 1;  // 060700DC add #1,r10
    c.r[7] += 1;  // 060700DE add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[11];  // 060700E0 cmp/gt r11,r7
    { const bool k = !c.t; st32(c.r[14] + 24, c.r[7]); if (k) { SH2_POLL(c); goto L_060700A0; } }  // 060700E2 bf/s 0x060700A0 ; mov.l r7,@(24,r14)
L_060700E6:
    c.r[0] = c.r[13];  // 060700E6 mov r13,r0
    c.t = c.r[0] == 0x6u;  // 060700E8 cmp/eq #6,r0
    c.r[1] = c.t;  // 060700EA movt r1
    c.r[7] = 0x1u;  // 060700EC mov #1,r7
    c.r[0] = ld32(c.r[14] + 20);  // 060700EE mov.l @(20,r14),r0
    c.r[1] ^= c.r[7];  // 060700F0 xor r7,r1
    c.t = c.r[0] == 0x4u;  // 060700F2 cmp/eq #4,r0
    c.r[2] = c.t;  // 060700F4 movt r2
    c.r[2] ^= c.r[7];  // 060700F6 xor r7,r2
    c.r[0] = ld32(c.r[14] + 24);  // 060700F8 mov.l @(24,r14),r0
    c.t = c.r[0] == 0x4u;  // 060700FA cmp/eq #4,r0
    { const bool k = c.t; c.r[1] += c.r[2]; if (k) { goto L_06070102; } }  // 060700FC bt/s 0x06070102 ; add r2,r1
    c.r[1] += 1;  // 06070100 add #1,r1
L_06070102:
    c.r[4] = c.r[1] & 0xFFu;  // 06070102 extu.b r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06070104 tst r4,r4
    { const bool k = c.t; st32(c.r[14] + 12, c.r[4]); if (k) { goto L_0607012E; } }  // 06070106 bt/s 0x0607012E ; mov.l r4,@(12,r14)
    c.r[8] = ld32(0x06070254u);  // 0607010A mov.l 0x06070254,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06070110u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070110u) return; }  // 0607010C jsr @r8 ; mov #4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607024Cu);  // 06070110 mov.w 0x0607024C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070116u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070116u) return; }  // 06070112 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14] + 12);  // 06070116 mov.l @(12,r14),r4
    c.r[4] += 46;  // 06070118 add #46,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607011Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607011Eu) return; }  // 0607011A jsr @r8 ; extu.b r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070122u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070122u) return; }  // 0607011E jsr @r8 ; mov #5,r4
    c.r[7] = ld32(c.r[14] + 8);  // 06070122 mov.l @(8,r14),r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06070124 mov.b @r7,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607012Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607012Au) return; }  // 06070126 jsr @r8 ; extu.b r4,r4
    c.r[0] = c.r[13]; goto L_06070136;  // 0607012A bra 0x06070136 ; mov r13,r0
L_0607012E:
    c.r[1] = ld32(0x06070254u);  // 0607012E mov.l 0x06070254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070134u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070134u) return; }  // 06070130 jsr @r1 ; mov #0,r4
    c.r[0] = c.r[13];  // 06070134 mov r13,r0
L_06070136:
    c.t = c.r[0] == 0x6u;  // 06070136 cmp/eq #6,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 4); if (k) { goto L_060701BA; } }  // 06070138 bt/s 0x060701BA ; mov.l @(4,r14),r7
    c.r[13] += c.r[7];  // 0607013C add r7,r13
    c.r[13] += 24;  // 0607013E add #24,r13
    c.r[10] = ld32(0x06070258u);  // 06070140 mov.l 0x06070258,r10
    c.r[9] = ld32(0x0607025Cu);  // 06070142 mov.l 0x0607025C,r9
    c.r[5] = 0x10u;  // 06070144 mov #16,r5
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06070146 mov.b @r13,r8
    c.r[4] = c.r[10];  // 06070148 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0607014Eu; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607014Eu) return; }  // 0607014A jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 0607014E mov r0,r1
    c.r[5] = c.r[8];  // 06070150 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06070156u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070156u) return; }  // 06070152 jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 06070156 mov r0,r12
    c.r[5] = 0x1u;  // 06070158 mov #1,r5
    c.r[0] = ld32(0x06070260u);  // 0607015A mov.l 0x06070260,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06070160u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070160u) return; }  // 0607015C jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 06070160 mov r0,r1
    c.r[13] = c.r[1] & 0xFFu;  // 06070162 extu.b r1,r13
    c.r[4] = c.r[13];  // 06070164 mov r13,r4
    c.r[4] += 20;  // 06070166 add #20,r4
    c.r[11] = ld32(0x06070254u);  // 06070168 mov.l 0x06070254,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0607016Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607016Eu) return; }  // 0607016A jsr @r11 ; extu.b r4,r4
    c.r[5] = 0x17u;  // 0607016E mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06070174u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070174u) return; }  // 06070170 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 06070174 mov r0,r1
    c.r[5] = 0xAu;  // 06070176 mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607017Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607017Cu) return; }  // 06070178 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607017C mov r0,r1
    c.r[8] = ld32(0x06070264u);  // 0607017E mov.l 0x06070264,r8
    c.r[6] = 0x0u;  // 06070180 mov #0,r6
    c.r[5] = 0x5u;  // 06070182 mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070188u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070188u) return; }  // 06070184 jsr @r8 ; mov r1,r4
    c.r[6] = c.r[13] & 0xFFu;  // 06070188 extu.b r13,r6
    c.r[1] = ld32(0x06070268u);  // 0607018A mov.l 0x06070268,r1
    c.r[5] = c.r[12];  // 0607018C mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06070192u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070192u) return; }  // 0607018E jsr @r1 ; mov #1,r4
    c.r[5] = 0x17u;  // 06070192 mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06070198u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070198u) return; }  // 06070194 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 06070198 mov r0,r1
    c.r[5] = 0xAu;  // 0607019A mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060701A0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701A0u) return; }  // 0607019C jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060701A0 mov r0,r1
    c.r[6] = 0x0u;  // 060701A2 mov #0,r6
    c.r[5] = 0x6u;  // 060701A4 mov #6,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060701AAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701AAu) return; }  // 060701A6 jsr @r8 ; mov r1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607024Eu);  // 060701AA mov.w 0x0607024E,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060701B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701B0u) return; }  // 060701AC jsr @r11 ; nop
    c.r[7] = ld32(c.r[14] + 8);  // 060701B0 mov.l @(8,r14),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060701B2 mov.b @r7,r1
    c.r[1] += 2;  // 060701B4 add #2,r1
    st8(c.r[7], c.r[1]); goto L_060701C0;  // 060701B6 bra 0x060701C0 ; mov.b r1,@r7
L_060701BA:
    c.r[1] = ld32(0x06070254u);  // 060701BA mov.l 0x06070254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060701C0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701C0u) return; }  // 060701BC jsr @r1 ; mov #0,r4
L_060701C0:
    c.r[0] = ld32(c.r[14] + 20);  // 060701C0 mov.l @(20,r14),r0
    c.t = c.r[0] == 0x4u;  // 060701C2 cmp/eq #4,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 4); if (k) { goto L_0607026C; } }  // 060701C4 bt/s 0x0607026C ; mov.l @(4,r14),r7
    c.r[7] += c.r[0];  // 060701C8 add r0,r7
    c.r[7] += 30;  // 060701CA add #30,r7
    st32(c.r[14] + 20, c.r[7]);  // 060701CC mov.l r7,@(20,r14)
    c.r[10] = ld32(0x06070258u);  // 060701CE mov.l 0x06070258,r10
    c.r[9] = ld32(0x0607025Cu);  // 060701D0 mov.l 0x0607025C,r9
    c.r[5] = 0x11u;  // 060701D2 mov #17,r5
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060701D4 mov.b @r7,r8
    c.r[4] = c.r[10];  // 060701D6 mov r10,r4
    c.r[8] = c.r[8] & 0xFFu;  // 060701D8 extu.b r8,r8
    c.r[8] -= 32;  // 060701DA add #-32,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060701E0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701E0u) return; }  // 060701DC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060701E0 mov r0,r1
    c.r[5] = c.r[8];  // 060701E2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060701E8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701E8u) return; }  // 060701E4 jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 060701E8 mov r0,r12
    c.r[5] = 0x1u;  // 060701EA mov #1,r5
    c.r[0] = ld32(0x06070260u);  // 060701EC mov.l 0x06070260,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060701F2u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060701F2u) return; }  // 060701EE jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 060701F2 mov r0,r1
    c.r[13] = c.r[1] & 0xFFu;  // 060701F4 extu.b r1,r13
    c.r[4] = c.r[13];  // 060701F6 mov r13,r4
    c.r[4] += 17;  // 060701F8 add #17,r4
    c.r[11] = ld32(0x06070254u);  // 060701FA mov.l 0x06070254,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06070200u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070200u) return; }  // 060701FC jsr @r11 ; extu.b r4,r4
    c.r[5] = 0x17u;  // 06070200 mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06070206u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070206u) return; }  // 06070202 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 06070206 mov r0,r1
    c.r[5] = 0xAu;  // 06070208 mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607020Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607020Eu) return; }  // 0607020A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607020E mov r0,r1
    c.r[8] = ld32(0x06070264u);  // 06070210 mov.l 0x06070264,r8
    c.r[6] = 0x0u;  // 06070212 mov #0,r6
    c.r[5] = 0x7u;  // 06070214 mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607021Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607021Au) return; }  // 06070216 jsr @r8 ; mov r1,r4
    c.r[6] = c.r[13] & 0xFFu;  // 0607021A extu.b r13,r6
    c.r[1] = ld32(0x06070268u);  // 0607021C mov.l 0x06070268,r1
    c.r[5] = c.r[12];  // 0607021E mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06070224u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070224u) return; }  // 06070220 jsr @r1 ; mov #1,r4
    c.r[5] = 0x17u;  // 06070224 mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607022Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607022Au) return; }  // 06070226 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 0607022A mov r0,r1
    c.r[5] = 0xAu;  // 0607022C mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06070232u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070232u) return; }  // 0607022E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06070232 mov r0,r1
    c.r[6] = 0x0u;  // 06070234 mov #0,r6
    c.r[5] = 0x6u;  // 06070236 mov #6,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607023Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607023Cu) return; }  // 06070238 jsr @r8 ; mov r1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607024Eu);  // 0607023C mov.w 0x0607024E,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06070242u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070242u) return; }  // 0607023E jsr @r11 ; nop
    c.r[7] = ld32(c.r[14] + 8);  // 06070242 mov.l @(8,r14),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06070244 mov.b @r7,r1
    c.r[1] += 2;  // 06070246 add #2,r1
    st8(c.r[7], c.r[1]); goto L_06070272;  // 06070248 bra 0x06070272 ; mov.b r1,@r7
L_0607026C:
    c.r[1] = ld32(0x06070368u);  // 0607026C mov.l 0x06070368,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070272u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070272u) return; }  // 0607026E jsr @r1 ; mov #0,r4
L_06070272:
    c.r[0] = ld32(c.r[14] + 24);  // 06070272 mov.l @(24,r14),r0
    c.t = c.r[0] == 0x4u;  // 06070274 cmp/eq #4,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[14]); if (k) { goto L_0607033E; } }  // 06070276 bt/s 0x0607033E ; mov.l @r14,r7
    c.r[7] += c.r[0];  // 0607027A add r0,r7
    c.r[7] += 30;  // 0607027C add #30,r7
    st32(c.r[14], c.r[7]);  // 0607027E mov.l r7,@r14
    c.r[10] = ld32(0x0607036Cu);  // 06070280 mov.l 0x0607036C,r10
    c.r[9] = ld32(0x06070370u);  // 06070282 mov.l 0x06070370,r9
    c.r[5] = 0x11u;  // 06070284 mov #17,r5
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06070286 mov.b @r7,r8
    c.r[4] = c.r[10];  // 06070288 mov r10,r4
    c.r[8] = c.r[8] & 0xFFu;  // 0607028A extu.b r8,r8
    c.r[8] -= 32;  // 0607028C add #-32,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06070292u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070292u) return; }  // 0607028E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06070292 mov r0,r1
    c.r[5] = c.r[8];  // 06070294 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607029Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607029Au) return; }  // 06070296 jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 0607029A mov r0,r12
    c.r[0] = ld32(c.r[14] + 4);  // 0607029C mov.l @(4,r14),r0
    c.r[7] = ld32(c.r[14] + 24);  // 0607029E mov.l @(24,r14),r7
    c.r[5] = 0x11u;  // 060702A0 mov #17,r5
    c.r[0] += c.r[7];  // 060702A2 add r7,r0
    c.r[0] += 30;  // 060702A4 add #30,r0
    st32(c.r[14] + 4, c.r[0]);  // 060702A6 mov.l r0,@(4,r14)
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060702A8 mov.b @r0,r8
    c.r[4] = c.r[10];  // 060702AA mov r10,r4
    c.r[8] = c.r[8] & 0xFFu;  // 060702AC extu.b r8,r8
    c.r[8] -= 32;  // 060702AE add #-32,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060702B4u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702B4u) return; }  // 060702B0 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060702B4 mov r0,r1
    c.r[5] = c.r[8];  // 060702B6 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060702BCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702BCu) return; }  // 060702B8 jsr @r9 ; mov r1,r4
    st32(c.r[14] + 16, c.r[0]);  // 060702BC mov.l r0,@(16,r14)
    c.r[8] = ld32(0x06070374u);  // 060702BE mov.l 0x06070374,r8
    c.r[5] = 0x1u;  // 060702C0 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060702C6u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702C6u) return; }  // 060702C2 jsr @r8 ; mov r12,r4
    c.r[1] = c.r[0];  // 060702C6 mov r0,r1
    c.r[13] = c.r[1] & 0xFFu;  // 060702C8 extu.b r1,r13
    c.r[4] = ld32(c.r[14] + 16);  // 060702CA mov.l @(16,r14),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060702D0u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702D0u) return; }  // 060702CC jsr @r8 ; mov #1,r5
    c.r[1] = c.r[0];  // 060702D0 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060702D2 extu.b r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 060702D4 mov.l r1,@(20,r14)
    c.r[4] = c.r[1];  // 060702D6 mov r1,r4
    c.r[4] += c.r[13];  // 060702D8 add r13,r4
    c.r[4] += 16;  // 060702DA add #16,r4
    c.r[0] = ld32(0x06070368u);  // 060702DC mov.l 0x06070368,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060702E2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702E2u) return; }  // 060702DE jsr @r0 ; extu.b r4,r4
    c.r[6] = c.r[13] & 0xFFu;  // 060702E2 extu.b r13,r6
    c.r[11] = ld32(0x06070378u);  // 060702E4 mov.l 0x06070378,r11
    c.r[5] = c.r[12];  // 060702E6 mov r12,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060702ECu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702ECu) return; }  // 060702E8 jsr @r11 ; mov #1,r4
    c.r[5] = 0x17u;  // 060702EC mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060702F2u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702F2u) return; }  // 060702EE jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 060702F2 mov r0,r1
    c.r[5] = 0xAu;  // 060702F4 mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060702FAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060702FAu) return; }  // 060702F6 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060702FA mov r0,r1
    c.r[8] = ld32(0x0607037Cu);  // 060702FC mov.l 0x0607037C,r8
    c.r[6] = 0x0u;  // 060702FE mov #0,r6
    c.r[5] = 0x8u;  // 06070300 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070306u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070306u) return; }  // 06070302 jsr @r8 ; mov r1,r4
    c.r[7] = 0x17u;  // 06070306 mov #23,r7
    c.r[7] += c.r[14];  // 06070308 add r14,r7
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607030A mov.b @r7,r7
    c.r[4] = 0x1u;  // 0607030C mov #1,r4
    c.r[5] = ld32(c.r[14] + 16);  // 0607030E mov.l @(16,r14),r5
    { const uint32_t x = c.r[11]; c.pr = 0x06070314u; c.r[6] = c.r[7] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070314u) return; }  // 06070310 jsr @r11 ; extu.b r7,r6
    c.r[5] = 0x17u;  // 06070314 mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607031Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607031Au) return; }  // 06070316 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 0607031A mov r0,r1
    c.r[5] = 0xAu;  // 0607031C mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06070322u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070322u) return; }  // 0607031E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06070322 mov r0,r1
    c.r[6] = 0x0u;  // 06070324 mov #0,r6
    c.r[5] = 0x9u;  // 06070326 mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607032Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607032Cu) return; }  // 06070328 jsr @r8 ; mov r1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070366u);  // 0607032C mov.w 0x06070366,r4
    c.r[0] = ld32(0x06070368u);  // 0607032E mov.l 0x06070368,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06070334u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070334u) return; }  // 06070330 jsr @r0 ; nop
    c.r[7] = ld32(c.r[14] + 8);  // 06070334 mov.l @(8,r14),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06070336 mov.b @r7,r1
    c.r[1] += 2;  // 06070338 add #2,r1
    st8(c.r[7], c.r[1]); goto L_06070344;  // 0607033A bra 0x06070344 ; mov.b r1,@r7
L_0607033E:
    c.r[1] = ld32(0x06070368u);  // 0607033E mov.l 0x06070368,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070344u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070344u) return; }  // 06070340 jsr @r1 ; mov #0,r4
L_06070344:
    c.r[0] = ld32(c.r[14] + 12);  // 06070344 mov.l @(12,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070346 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0607034E; } }  // 06070348 bt/s 0x0607034E ; mov #0,r1
    c.r[1] = 0x2u;  // 0607034C mov #2,r1
L_0607034E:
    c.r[14] += 28;  // 0607034E add #28,r14
    c.r[15] = c.r[14];  // 06070350 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06070352 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06070354 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06070356 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06070358 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607035A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607035C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607035E mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06070360 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 06070362 rts ; mov r1,r0
}

void f_06070380(SH2Context& c) {
    ran[1583] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06070380 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06070382 mov r15,r14
    c.r[2] = c.r[4] & 0xFFu;  // 06070384 extu.b r4,r2
    c.r[3] = c.r[5] & 0xFFu;  // 06070386 extu.b r5,r3
    c.t = c.r[2] == c.r[3];  // 06070388 cmp/eq r3,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060703C2; } }  // 0607038A bt/s 0x060703C2 ; mov #0,r0
    c.r[4] = c.r[2];  // 0607038E mov r2,r4
    c.r[4] -= 33;  // 06070390 add #-33,r4
    c.r[2] = c.r[4] & 0xFFu;  // 06070392 extu.b r4,r2
    c.r[1] = 0x2Cu;  // 06070394 mov #44,r1
    c.t = c.r[2] > c.r[1];  // 06070396 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060703C6; } }  // 06070398 bt/s 0x060703C6 ; mov r14,r15
    c.r[1] = ld32(0x060703CCu);  // 0607039C mov.l 0x060703CC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[4] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0607039E dmuls.l r1,r4
    c.r[3] -= 33;  // 060703A0 add #-33,r3
    c.r[2] = c.mach;  // 060703A2 sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060703A4 shar r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060703A6 dmuls.l r1,r3
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060703A8 shll r4
    { uint32_t a = c.r[4], b = c.r[4], t = c.t; c.r[4] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060703AA subc r4,r4
    c.r[2] -= c.r[4];  // 060703AC sub r4,r2
    c.r[1] = c.mach;  // 060703AE sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060703B0 shar r1
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060703B2 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060703B4 subc r3,r3
    c.r[1] -= c.r[3];  // 060703B6 sub r3,r1
    c.t = c.r[2] == c.r[1];  // 060703B8 cmp/eq r1,r2
    if (!c.t) { goto L_060703C6; }  // 060703BA bf 0x060703C6
    c.r[0] = 0x1u;  // 060703BC mov #1,r0
    goto L_060703C6;  // 060703BE bra 0x060703C6 ; nop
L_060703C2:
    c.r[0] = 0x2u;  // 060703C2 mov #2,r0
    c.r[15] = c.r[14];  // 060703C4 mov r14,r15
L_060703C6:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060703C6 rts ; mov.l @r15+,r14
}

void f_060703D0(SH2Context& c) {
    ran[1584] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060703D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060703D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060703D4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060703D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060703D8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060703DA mov r15,r14
    c.r[1] = ld32(0x0607049Cu);  // 060703DC mov.l 0x0607049C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060703E2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060703E2u) return; }  // 060703DE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060704A0u);  // 060703E2 mov.l 0x060704A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060703E8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060703E8u) return; }  // 060703E4 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060704A4u);  // 060703E8 mov.l 0x060704A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060703EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060703EEu) return; }  // 060703EA jsr @r1 ; nop
    c.r[1] = ld32(0x060704A8u);  // 060703EE mov.l 0x060704A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060703F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060703F2 extu.b r1,r1
    c.r[1] += c.r[1];  // 060703F4 add r1,r1
    c.r[1] -= 12;  // 060703F6 add #-12,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060703F8 cmp/pz r1
    { const bool k = c.t; c.r[10] = c.r[1] & 0xFFu; if (k) { goto L_06070400; } }  // 060703FA bt/s 0x06070400 ; extu.b r1,r10
    c.r[10] = 0x0u;  // 060703FE mov #0,r10
L_06070400:
    c.r[2] = c.r[10];  // 06070400 mov r10,r2
    c.r[2] += 28;  // 06070402 add #28,r2
    c.r[1] = 0x27u;  // 06070404 mov #39,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06070406 cmp/gt r1,r2
    if (!c.t) { goto L_0607040C; }  // 06070408 bf 0x0607040C
    c.r[10] = 0xCu;  // 0607040A mov #12,r10
L_0607040C:
    c.r[1] = ld32(0x060704ACu);  // 0607040C mov.l 0x060704AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607040E mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06070410 extu.b r1,r2
    c.r[2] += c.r[2];  // 06070412 add r2,r2
    c.r[1] = c.r[2];  // 06070414 mov r2,r1
    c.r[1] -= 3;  // 06070416 add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06070418 cmp/pz r1
    { const bool k = c.t; c.r[9] = c.r[2] & 0xFFu; if (k) { goto L_06070420; } }  // 0607041A bt/s 0x06070420 ; extu.b r2,r9
    c.r[9] = 0x3u;  // 0607041E mov #3,r9
L_06070420:
    c.r[2] = c.r[9];  // 06070420 mov r9,r2
    c.r[2] += 9;  // 06070422 add #9,r2
    c.r[1] = 0x1Au;  // 06070424 mov #26,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06070426 cmp/gt r1,r2
    if (!c.t) { goto L_0607042C; }  // 06070428 bf 0x0607042C
    c.r[9] = 0x11u;  // 0607042A mov #17,r9
L_0607042C:
    c.r[8] = ld32(0x060704B0u);  // 0607042C mov.l 0x060704B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06070432u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070432u) return; }  // 0607042E jsr @r8 ; mov r10,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070436u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070436u) return; }  // 06070432 jsr @r8 ; mov r9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070498u);  // 06070436 mov.w 0x06070498,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607043Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607043Cu) return; }  // 06070438 jsr @r8 ; nop
    c.r[4] = 0x1u;  // 0607043C mov #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070442u; c.r[4] |= c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070442u) return; }  // 0607043E jsr @r8 ; or r10,r4
    c.r[4] = c.r[9];  // 06070442 mov r9,r4
    c.r[4] += 1;  // 06070444 add #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607044Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607044Au) return; }  // 06070446 jsr @r8 ; extu.b r4,r4
    c.r[1] = ld32(0x060704B4u);  // 0607044A mov.l 0x060704B4,r1
    c.r[5] = 0x0u;  // 0607044C mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607044E mov.b @r1,r6
    c.r[4] = 0x0u;  // 06070450 mov #0,r4
    c.r[1] = ld32(0x060704B8u);  // 06070452 mov.l 0x060704B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070458u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070458u) return; }  // 06070454 jsr @r1 ; extu.b r6,r6
    c.r[9] += 6;  // 06070458 add #6,r9
    c.r[5] = c.r[9] & 0xFFu;  // 0607045A extu.b r9,r5
    c.r[10] += 11;  // 0607045C add #11,r10
    c.r[4] = c.r[10] & 0xFFu;  // 0607045E extu.b r10,r4
    c.r[7] = 0x2u;  // 06070460 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06070462 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 06070464 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070466 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070468 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0607046A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607046C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607046E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070470 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070472 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070474 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06070476 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070478 mov.l r2,@-r15
    c.r[1] = ld32(0x060704BCu);  // 0607047A mov.l 0x060704BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070480u; c.r[6] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070480u) return; }  // 0607047C jsr @r1 ; mov #5,r6
    c.r[15] += 40;  // 06070480 add #40,r15
    c.r[1] = ld32(0x060704C0u);  // 06070482 mov.l 0x060704C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070488u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070488u) return; }  // 06070484 jsr @r1 ; mov #20,r4
    c.r[15] = c.r[14];  // 06070488 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607048A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607048C mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607048E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06070490 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607049Au);  // 06070492 mov.w 0x0607049A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06070494 rts ; mov.l @r15+,r8
}

void f_060704C4(SH2Context& c) {
    ran[1585] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060704C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060704C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060704C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060704CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060704CC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060704CE mov r15,r14
    c.r[1] = ld32(0x06070584u);  // 060704D0 mov.l 0x06070584,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060704D6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060704D6u) return; }  // 060704D2 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06070588u);  // 060704D6 mov.l 0x06070588,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060704DCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060704DCu) return; }  // 060704D8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607058Cu);  // 060704DC mov.l 0x0607058C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060704E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060704E2u) return; }  // 060704DE jsr @r1 ; nop
    c.r[1] = ld32(0x06070590u);  // 060704E2 mov.l 0x06070590,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060704E4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060704E6 extu.b r1,r1
    c.r[1] += c.r[1];  // 060704E8 add r1,r1
    c.r[1] -= 5;  // 060704EA add #-5,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060704EC cmp/pz r1
    { const bool k = c.t; c.r[10] = c.r[1] & 0xFFu; if (k) { goto L_060704F4; } }  // 060704EE bt/s 0x060704F4 ; extu.b r1,r10
    c.r[10] = 0x0u;  // 060704F2 mov #0,r10
L_060704F4:
    c.r[2] = c.r[10];  // 060704F4 mov r10,r2
    c.r[2] += 14;  // 060704F6 add #14,r2
    c.r[1] = 0x27u;  // 060704F8 mov #39,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060704FA cmp/gt r1,r2
    if (!c.t) { goto L_06070500; }  // 060704FC bf 0x06070500
    c.r[10] = 0x1Au;  // 060704FE mov #26,r10
L_06070500:
    c.r[1] = ld32(0x06070594u);  // 06070500 mov.l 0x06070594,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070502 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06070504 extu.b r1,r2
    c.r[2] += c.r[2];  // 06070506 add r2,r2
    c.r[1] = c.r[2];  // 06070508 mov r2,r1
    c.r[1] -= 3;  // 0607050A add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607050C cmp/pz r1
    { const bool k = c.t; c.r[9] = c.r[2] & 0xFFu; if (k) { goto L_06070514; } }  // 0607050E bt/s 0x06070514 ; extu.b r2,r9
    c.r[9] = 0x3u;  // 06070512 mov #3,r9
L_06070514:
    c.r[2] = c.r[9];  // 06070514 mov r9,r2
    c.r[2] += 9;  // 06070516 add #9,r2
    c.r[1] = 0x1Au;  // 06070518 mov #26,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607051A cmp/gt r1,r2
    if (!c.t) { goto L_06070520; }  // 0607051C bf 0x06070520
    c.r[9] = 0x11u;  // 0607051E mov #17,r9
L_06070520:
    c.r[8] = ld32(0x06070598u);  // 06070520 mov.l 0x06070598,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06070526u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070526u) return; }  // 06070522 jsr @r8 ; mov r10,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607052Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607052Au) return; }  // 06070526 jsr @r8 ; mov r9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070580u);  // 0607052A mov.w 0x06070580,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070530u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070530u) return; }  // 0607052C jsr @r8 ; nop
    c.r[4] = c.r[10];  // 06070530 mov r10,r4
    c.r[4] += 1;  // 06070532 add #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070538u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070538u) return; }  // 06070534 jsr @r8 ; extu.b r4,r4
    c.r[4] = c.r[9];  // 06070538 mov r9,r4
    c.r[4] += 1;  // 0607053A add #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070540u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070540u) return; }  // 0607053C jsr @r8 ; extu.b r4,r4
    c.r[9] += 6;  // 06070540 add #6,r9
    c.r[5] = c.r[9] & 0xFFu;  // 06070542 extu.b r9,r5
    c.r[10] += 8;  // 06070544 add #8,r10
    c.r[4] = c.r[10] & 0xFFu;  // 06070546 extu.b r10,r4
    c.r[7] = 0x2u;  // 06070548 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0607054A mov.l r7,@-r15
    c.r[2] = 0x1u;  // 0607054C mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607054E mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070550 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06070552 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070554 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070556 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070558 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607055A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607055C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0607055E mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070560 mov.l r2,@-r15
    c.r[1] = ld32(0x0607059Cu);  // 06070562 mov.l 0x0607059C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070568u; c.r[6] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070568u) return; }  // 06070564 jsr @r1 ; mov #5,r6
    c.r[15] += 40;  // 06070568 add #40,r15
    c.r[1] = ld32(0x060705A0u);  // 0607056A mov.l 0x060705A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070570u; c.r[4] = 0x15u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070570u) return; }  // 0607056C jsr @r1 ; mov #21,r4
    c.r[15] = c.r[14];  // 06070570 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06070572 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06070574 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06070576 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06070578 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06070582u);  // 0607057A mov.w 0x06070582,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607057C rts ; mov.l @r15+,r8
}

void f_060705A4(SH2Context& c) {
    ran[1586] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060705A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060705A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060705A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060705AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060705AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060705AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060705B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060705B2 sts.l pr,@-r15
    c.r[1] = ld32(0x06070740u);  // 060705B4 mov.l 0x06070740,r1
    c.r[1] = ld32(c.r[1]);  // 060705B6 mov.l @r1,r1
    c.r[15] -= 40;  // 060705B8 add #-40,r15
    c.r[1] += 1;  // 060705BA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060705BC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060705BE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060705C0 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06070614; } }  // 060705C2 bt/s 0x06070614 ; mov r15,r14
    c.r[0] = 0xDu;  // 060705C6 mov #13,r0
    st32(c.r[14] + 28, c.r[0]);  // 060705C8 mov.l r0,@(28,r14)
    c.r[0] = ld32(0x06070744u);  // 060705CA mov.l 0x06070744,r0
    st32(c.r[14] + 36, c.r[0]);  // 060705CC mov.l r0,@(36,r14)
    c.r[9] = 0x0u;  // 060705CE mov #0,r9
    c.r[5] = 0x9u;  // 060705D0 mov #9,r5
    c.r[13] = ld32(c.r[14] + 28);  // 060705D2 mov.l @(28,r14),r13
    c.r[1] = ld32(0x06070748u);  // 060705D4 mov.l 0x06070748,r1
    st32(c.r[14] + 32, c.r[13]);  // 060705D6 mov.l r13,@(32,r14)
    c.r[7] = ld32(c.r[1]);  // 060705D8 mov.l @r1,r7
    c.r[2] = 0x0u;  // 060705DA mov #0,r2
    c.r[1] = ld32(0x0607074Cu);  // 060705DC mov.l 0x0607074C,r1
    c.r[3] = c.r[7];  // 060705DE mov r7,r3
    c.r[6] = ld32(c.r[1]);  // 060705E0 mov.l @r1,r6
L_060705E2:
    c.r[0] = c.r[2];  // 060705E2 mov r2,r0
    c.r[4] = 0x7Fu;  // 060705E4 mov #127,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060705E6 mov.b @(r0,r7),r1
    c.r[9] += 1;  // 060705E8 add #1,r9
    c.r[4] &= c.r[1];  // 060705EA and r1,r4
    c.r[4] <<= 8;  // 060705EC shll8 r4
    c.r[1] = c.r[3];  // 060705EE mov r3,r1
    c.r[1] += 1;  // 060705F0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060705F2 mov.b @r1,r1
    c.r[3] += 2;  // 060705F4 add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060705F6 extu.b r1,r1
    c.r[1] |= c.r[4];  // 060705F8 or r4,r1
    c.r[4] = c.r[1];  // 060705FA mov r1,r4
    c.r[4] += c.r[4];  // 060705FC add r4,r4
    c.r[4] += c.r[1];  // 060705FE add r1,r4
    c.r[4] <<= 2;  // 06070600 shll2 r4
    c.r[0] = c.r[4];  // 06070602 mov r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06070604 mov.w @(r0,r6),r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[5];  // 06070606 cmp/gt r5,r9
    c.r[0] = c.r[2];  // 06070608 mov r2,r0
    st16(c.r[0] + c.r[14], c.r[1]);  // 0607060A mov.w r1,@(r0,r14)
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_060705E2; } }  // 0607060C bf/s 0x060705E2 ; add #2,r2
    goto L_0607064C;  // 06070610 bra 0x0607064C ; nop
L_06070614:
    c.r[13] = 0x6u;  // 06070614 mov #6,r13
    st32(c.r[14] + 28, c.r[13]);  // 06070616 mov.l r13,@(28,r14)
    c.r[0] = 0xBu;  // 06070618 mov #11,r0
    st32(c.r[14] + 32, c.r[0]);  // 0607061A mov.l r0,@(32,r14)
    c.r[13] = ld32(0x06070750u);  // 0607061C mov.l 0x06070750,r13
    st32(c.r[14] + 36, c.r[13]);  // 0607061E mov.l r13,@(36,r14)
    c.r[9] = 0x0u;  // 06070620 mov #0,r9
    c.r[6] = 0x9u;  // 06070622 mov #9,r6
    c.r[1] = ld32(0x06070748u);  // 06070624 mov.l 0x06070748,r1
    c.r[3] = ld32(c.r[1]);  // 06070626 mov.l @r1,r3
    c.r[2] = 0x0u;  // 06070628 mov #0,r2
    c.r[7] = c.r[3];  // 0607062A mov r3,r7
L_0607062C:
    c.r[0] = c.r[2];  // 0607062C mov r2,r0
    c.r[5] = 0x7Fu;  // 0607062E mov #127,r5
    c.r[2] += 2;  // 06070630 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06070632 mov.b @(r0,r7),r1
    c.r[9] += 1;  // 06070634 add #1,r9
    c.r[5] &= c.r[1];  // 06070636 and r1,r5
    c.r[5] <<= 8;  // 06070638 shll8 r5
    c.r[1] = c.r[3];  // 0607063A mov r3,r1
    c.r[1] += 1;  // 0607063C add #1,r1
    c.r[3] += 2;  // 0607063E add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070640 mov.b @r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[6];  // 06070642 cmp/gt r6,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06070644 extu.b r1,r1
    c.r[1] |= c.r[5];  // 06070646 or r5,r1
    { const bool k = !c.t; st16(c.r[0] + c.r[14], c.r[1]); if (k) { SH2_POLL(c); goto L_0607062C; } }  // 06070648 bf/s 0x0607062C ; mov.w r1,@(r0,r14)
L_0607064C:
    c.r[1] = ld32(0x06070754u);  // 0607064C mov.l 0x06070754,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070652u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070652u) return; }  // 0607064E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06070758u);  // 06070652 mov.l 0x06070758,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070658u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070658u) return; }  // 06070654 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607075Cu);  // 06070658 mov.l 0x0607075C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607065A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607065C extu.b r1,r1
    c.r[1] += c.r[1];  // 0607065E add r1,r1
    c.r[1] -= 4;  // 06070660 add #-4,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06070662 cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_0607066E; } }  // 06070664 bt/s 0x0607066E ; extu.b r1,r1
    c.r[13] = 0x0u;  // 06070668 mov #0,r13
    st32(c.r[14] + 20, c.r[13]); goto L_06070670;  // 0607066A bra 0x06070670 ; mov.l r13,@(20,r14)
L_0607066E:
    st32(c.r[14] + 20, c.r[1]);  // 0607066E mov.l r1,@(20,r14)
L_06070670:
    c.r[0] = 0x0u;  // 06070670 mov #0,r0
    st32(c.r[14] + 24, c.r[0]);  // 06070672 mov.l r0,@(24,r14)
    c.r[1] = ld32(0x06070748u);  // 06070674 mov.l 0x06070748,r1
    c.r[2] = ld32(c.r[1]);  // 06070676 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607073Cu);  // 06070678 mov.w 0x0607073C,r1
    c.r[0] = c.r[2];  // 0607067A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607067C mov.b @(r0,r1),r1
    c.r[13] = ld32(c.r[14] + 24);  // 0607067E mov.l @(24,r14),r13
    c.r[1] = c.r[1] & 0xFFu;  // 06070680 extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 06070682 cmp/ge r1,r13
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_060706CE; } }  // 06070684 bt/s 0x060706CE ; mov #0,r9
    c.r[12] = ld32(0x06070760u);  // 06070688 mov.l 0x06070760,r12
    c.r[10] = 0x0u;  // 0607068A mov #0,r10
L_0607068C:
    c.r[0] = c.r[10];  // 0607068C mov r10,r0
    c.r[4] = ld32(0x06070764u);  // 0607068E mov.l 0x06070764,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06070690 mov.w @(r0,r14),r8
    c.r[13] = ld32(0x06070768u);  // 06070692 mov.l 0x06070768,r13
    c.r[5] = ld32(c.r[14] + 32);  // 06070694 mov.l @(32,r14),r5
    { const uint32_t x = c.r[13]; c.pr = 0x0607069Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607069Au) return; }  // 06070696 jsr @r13 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0607069A mov r0,r1
    c.r[5] = c.r[8];  // 0607069C mov r8,r5
    { const uint32_t x = c.r[13]; c.pr = 0x060706A2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060706A2u) return; }  // 0607069E jsr @r13 ; mov r1,r4
    c.r[8] = c.r[0];  // 060706A2 mov r0,r8
    c.r[5] = 0x0u;  // 060706A4 mov #0,r5
    { const uint32_t x = c.r[12]; c.pr = 0x060706AAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060706AAu) return; }  // 060706A6 jsr @r12 ; mov r8,r4
    c.r[1] = c.r[0];  // 060706AA mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 060706AC extu.b r1,r11
    c.r[5] = 0x1u;  // 060706AE mov #1,r5
    { const uint32_t x = c.r[12]; c.pr = 0x060706B4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060706B4u) return; }  // 060706B0 jsr @r12 ; mov r8,r4
    c.r[0] = ld32(c.r[14] + 24);  // 060706B4 mov.l @(24,r14),r0
    c.t = c.r[11] > c.r[0];  // 060706B6 cmp/hi r0,r11
    if (!c.t) { goto L_060706BC; }  // 060706B8 bf 0x060706BC
    st32(c.r[14] + 24, c.r[11]);  // 060706BA mov.l r11,@(24,r14)
L_060706BC:
    c.r[1] = ld32(0x06070748u);  // 060706BC mov.l 0x06070748,r1
    c.r[1] = ld32(c.r[1]);  // 060706BE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607073Cu);  // 060706C0 mov.w 0x0607073C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060706C2 mov.b @(r0,r1),r1
    c.r[9] += 1;  // 060706C4 add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 060706C6 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060706C8 cmp/ge r1,r9
    { const bool k = !c.t; c.r[10] += 2; if (k) { SH2_POLL(c); goto L_0607068C; } }  // 060706CA bf/s 0x0607068C ; add #2,r10
L_060706CE:
    c.r[2] = ld32(c.r[14] + 20);  // 060706CE mov.l @(20,r14),r2
    c.r[13] = ld32(c.r[14] + 24);  // 060706D0 mov.l @(24,r14),r13
    c.r[1] = 0x26u;  // 060706D2 mov #38,r1
    c.r[2] += c.r[13];  // 060706D4 add r13,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060706D6 cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = 0u - c.r[13]; if (k) { goto L_060706E2; } }  // 060706D8 bf/s 0x060706E2 ; neg r13,r1
    c.r[1] += 38;  // 060706DC add #38,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060706DE extu.b r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 060706E0 mov.l r1,@(20,r14)
L_060706E2:
    c.r[9] = 0x0u;  // 060706E2 mov #0,r9
    c.r[3] = ld32(0x0607076Cu);  // 060706E4 mov.l 0x0607076C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060706E6 mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607073Eu);  // 060706E8 mov.w 0x0607073E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060706EA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060706EC cmp/eq r2,r1
    { const bool k = c.t; c.r[6] = 0x12u; if (k) { goto L_06070710; } }  // 060706EE bt/s 0x06070710 ; mov #18,r6
    c.r[7] = c.r[2];  // 060706F2 mov r2,r7
    c.r[2] = c.r[3];  // 060706F4 mov r3,r2
L_060706F6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060706F6 mov.b @r2,r1
    c.r[0] = ld32(c.r[14] + 28);  // 060706F8 mov.l @(28,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 060706FA extu.b r1,r1
    c.t = c.r[1] == c.r[0];  // 060706FC cmp/eq r0,r1
    if (c.t) { goto L_06070710; }  // 060706FE bt 0x06070710
    c.r[9] += 1;  // 06070700 add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[6];  // 06070702 cmp/gt r6,r9
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06070710; } }  // 06070704 bt/s 0x06070710 ; add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070708 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607070A extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0607070C cmp/eq r7,r1
    if (!c.t) { SH2_POLL(c); goto L_060706F6; }  // 0607070E bf 0x060706F6
L_06070710:
    c.r[1] = ld32(0x0607076Cu);  // 06070710 mov.l 0x0607076C,r1
    c.r[0] = c.r[9];  // 06070712 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06070714 mov.b @(r0,r1),r1
    c.r[13] = ld32(c.r[14] + 28);  // 06070716 mov.l @(28,r14),r13
    c.r[1] = c.r[1] & 0xFFu;  // 06070718 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 0607071A cmp/eq r13,r1
    { const bool k = c.t; c.r[9] += 1; if (k) { goto L_06070722; } }  // 0607071C bt/s 0x06070722 ; add #1,r9
    c.r[9] = 0x1u;  // 06070720 mov #1,r9
L_06070722:
    c.r[1] = ld32(0x06070770u);  // 06070722 mov.l 0x06070770,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070724 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06070726 extu.b r1,r2
    c.r[1] = c.r[2];  // 06070728 mov r2,r1
    c.r[1] += c.r[1];  // 0607072A add r1,r1
    c.r[1] -= 3;  // 0607072C add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607072E cmp/pz r1
    { const bool k = c.t; c.r[2] += c.r[9]; if (k) { goto L_06070774; } }  // 06070730 bt/s 0x06070774 ; add r9,r2
    c.r[9] += c.r[9];  // 06070734 add r9,r9
    c.r[9] += 1;  // 06070736 add #1,r9
    c.r[11] = c.r[9] & 0xFFu; goto L_0607077A;  // 06070738 bra 0x0607077A ; extu.b r9,r11
L_06070774:
    c.r[2] += c.r[2];  // 06070774 add r2,r2
    c.r[2] -= 2;  // 06070776 add #-2,r2
    c.r[11] = c.r[2] & 0xFFu;  // 06070778 extu.b r2,r11
L_0607077A:
    c.r[12] = ld32(0x060708A0u);  // 0607077A mov.l 0x060708A0,r12
    c.r[1] = ld32(c.r[12]);  // 0607077C mov.l @r12,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06070894u);  // 0607077E mov.w 0x06070894,r10
    c.r[0] = c.r[1];  // 06070780 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06070782 mov.b @(r0,r10),r1
    c.r[2] = c.r[11];  // 06070784 mov r11,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06070786 extu.b r1,r3
    c.r[3] += c.r[3];  // 06070788 add r3,r3
    c.r[2] += c.r[3];  // 0607078A add r3,r2
    c.r[1] = 0x1Bu;  // 0607078C mov #27,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607078E cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = 0u - c.r[3]; if (k) { goto L_06070798; } }  // 06070790 bf/s 0x06070798 ; neg r3,r1
    c.r[1] += 25;  // 06070794 add #25,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06070796 extu.b r1,r11
L_06070798:
    c.r[1] = ld32(0x060708A4u);  // 06070798 mov.l 0x060708A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607079Eu; c.r[13] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607079Eu) return; }  // 0607079A jsr @r1 ; mov #32,r13
    c.r[1] = ld32(c.r[12]);  // 0607079E mov.l @r12,r1
    c.r[0] = c.r[1];  // 060707A0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060707A2 mov.b @(r0,r10),r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070896u);  // 060707A4 mov.w 0x06070896,r4
    c.r[1] += c.r[1];  // 060707A6 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060707A8 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060707AA mov.l r1,@-r15
    c.r[7] = ld32(c.r[14] + 24);  // 060707AC mov.l @(24,r14),r7
    c.r[6] = c.r[11];  // 060707AE mov r11,r6
    c.r[1] = ld32(0x060708A8u);  // 060707B0 mov.l 0x060708A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060707B6u; c.r[5] = ld32(c.r[14] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060707B6u) return; }  // 060707B2 jsr @r1 ; mov.l @(20,r14),r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070898u);  // 060707B6 mov.w 0x06070898,r4
    c.r[8] = ld32(0x060708ACu);  // 060707B8 mov.l 0x060708AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060707BEu; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060707BEu) return; }  // 060707BA jsr @r8 ; mov #0,r9
    c.r[4] = ld32(c.r[14] + 20);  // 060707BE mov.l @(20,r14),r4
    c.r[4] += 1;  // 060707C0 add #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060707C6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060707C6u) return; }  // 060707C2 jsr @r8 ; extu.b r4,r4
    c.r[1] = c.r[11];  // 060707C6 mov r11,r1
    c.r[1] += 1;  // 060707C8 add #1,r1
    c.r[1] |= c.r[13];  // 060707CA or r13,r1
    { const uint32_t x = c.r[8]; c.pr = 0x060707D0u; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060707D0u) return; }  // 060707CC jsr @r8 ; extu.b r1,r4
    c.r[1] = ld32(c.r[12]);  // 060707D0 mov.l @r12,r1
    c.r[0] = c.r[1];  // 060707D2 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060707D4 mov.b @(r0,r10),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060707DAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060707DAu) return; }  // 060707D6 jsr @r8 ; extu.b r4,r4
    c.r[1] = ld32(c.r[12]);  // 060707DA mov.l @r12,r1
    c.r[0] = c.r[1];  // 060707DC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060707DE mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060707E0 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060707E2 cmp/ge r1,r9
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06070836; } }  // 060707E4 bt/s 0x06070836 ; add #4,r15
    c.r[10] = c.r[8];  // 060707E8 mov r8,r10
    c.r[8] = 0x0u;  // 060707EA mov #0,r8
L_060707EC:
    c.r[1] = ld32(c.r[12]);  // 060707EC mov.l @r12,r1
    c.r[0] = c.r[1];  // 060707EE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060707F0 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060707F2 extu.b r1,r1
    c.r[1] >>= 2;  // 060707F4 shlr2 r1
    c.r[1] >>= 2;  // 060707F6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060707F8 shlr r1
    c.r[1] >>= 2;  // 060707FA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060707FC tst r1,r1
    if (c.t) { goto L_0607080A; }  // 060707FE bt 0x0607080A
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607089Au);  // 06070800 mov.w 0x0607089A,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06070806u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070806u) return; }  // 06070802 jsr @r10 ; nop
    c.r[4] = 0x2u; goto L_06070812;  // 06070806 bra 0x06070812 ; mov #2,r4
L_0607080A:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607089Au);  // 0607080A mov.w 0x0607089A,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06070810u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070810u) return; }  // 0607080C jsr @r10 ; nop
    c.r[4] = 0x1u;  // 06070810 mov #1,r4
L_06070812:
    { const uint32_t x = c.r[10]; c.pr = 0x06070816u; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070816u) return; }  // 06070812 jsr @r10 ; add #1,r9
    c.r[0] = c.r[8];  // 06070816 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06070818 mov.w @(r0,r14),r1
    c.r[4] = ld32(c.r[14] + 36);  // 0607081A mov.l @(36,r14),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06070896u);  // 0607081C mov.w 0x06070896,r5
    c.r[4] += c.r[1];  // 0607081E add r1,r4
    c.r[1] = ld32(0x060708B0u);  // 06070820 mov.l 0x060708B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070826u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070826u) return; }  // 06070822 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[12]);  // 06070826 mov.l @r12,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06070894u);  // 06070828 mov.w 0x06070894,r2
    c.r[0] = c.r[1];  // 0607082A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607082C mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607082E extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06070830 cmp/ge r1,r9
    { const bool k = !c.t; c.r[8] += 2; if (k) { SH2_POLL(c); goto L_060707EC; } }  // 06070832 bf/s 0x060707EC ; add #2,r8
L_06070836:
    c.r[11] += 1;  // 06070836 add #1,r11
    c.r[5] = c.r[11] & 0xFFu;  // 06070838 extu.b r11,r5
    c.r[0] = 0x17u;  // 0607083A mov #23,r0
    c.r[0] += c.r[14];  // 0607083C add r14,r0
    c.r[13] = ld32(c.r[14] + 20);  // 0607083E mov.l @(20,r14),r13
    c.r[1] = ld32(0x060708A0u);  // 06070840 mov.l 0x060708A0,r1
    c.r[13] += 1;  // 06070842 add #1,r13
    st32(c.r[14] + 20, c.r[13]);  // 06070844 mov.l r13,@(20,r14)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06070846 mov.b @r0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06070894u);  // 06070848 mov.w 0x06070894,r2
    c.r[1] = ld32(c.r[1]);  // 0607084A mov.l @r1,r1
    c.r[4] = c.r[0] & 0xFFu;  // 0607084C extu.b r0,r4
    c.r[0] = c.r[1];  // 0607084E mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06070850 mov.b @(r0,r2),r3
    c.r[7] = 0x2u;  // 06070852 mov #2,r7
    c.r[3] = c.r[3] & 0xFFu;  // 06070854 extu.b r3,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06070856 mov.l r3,@-r15
    c.r[2] = 0x1u;  // 06070858 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607085A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607085C mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0607085E mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070860 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070862 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070864 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070866 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070868 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607086A mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607086C mov.l r2,@-r15
    c.r[1] = ld32(0x060708B4u);  // 0607086E mov.l 0x060708B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070874u; c.r[6] = ld32(c.r[14] + 24); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070874u) return; }  // 06070870 jsr @r1 ; mov.l @(24,r14),r6
    c.r[15] += 40;  // 06070874 add #40,r15
    c.r[1] = ld32(0x060708B8u);  // 06070876 mov.l 0x060708B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607087Cu; c.r[4] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607087Cu) return; }  // 06070878 jsr @r1 ; mov #22,r4
    c.r[14] += 40;  // 0607087C add #40,r14
    c.r[15] = c.r[14];  // 0607087E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06070880 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06070882 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06070884 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06070886 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06070888 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607088A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607088C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607089Cu);  // 0607088E mov.w 0x0607089C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06070890 rts ; mov.l @r15+,r8
}

void f_060708BC(SH2Context& c) {
    ran[1587] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060708BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060708BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060708C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060708C2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060708C4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060708C6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060708C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060708CA sts.l pr,@-r15
    c.r[15] -= 4;  // 060708CC add #-4,r15
    c.r[14] = c.r[15];  // 060708CE mov r15,r14
    c.r[1] = ld32(0x06070960u);  // 060708D0 mov.l 0x06070960,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060708D6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060708D6u) return; }  // 060708D2 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06070964u);  // 060708D6 mov.l 0x06070964,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060708DCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060708DCu) return; }  // 060708D8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06070968u);  // 060708DC mov.l 0x06070968,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060708DE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060708E0 extu.b r1,r1
    c.r[1] += c.r[1];  // 060708E2 add r1,r1
    c.r[1] -= 2;  // 060708E4 add #-2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060708E6 extu.b r1,r10
    c.r[2] = c.r[10];  // 060708E8 mov r10,r2
    c.r[2] += 8;  // 060708EA add #8,r2
    c.r[1] = 0x26u;  // 060708EC mov #38,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060708EE cmp/gt r1,r2
    if (!c.t) { goto L_060708F4; }  // 060708F0 bf 0x060708F4
    c.r[10] = 0x1Eu;  // 060708F2 mov #30,r10
L_060708F4:
    c.r[1] = ld32(0x0607096Cu);  // 060708F4 mov.l 0x0607096C,r1
    c.r[1] = ld32(c.r[1]);  // 060708F6 mov.l @r1,r1
    c.r[1] += 1;  // 060708F8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060708FA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060708FC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060708FE tst r1,r1
    { const bool k = c.t; c.r[4] = 0x5u; if (k) { goto L_06070906; } }  // 06070900 bt/s 0x06070906 ; mov #5,r4
    c.r[4] = 0x7u;  // 06070904 mov #7,r4
L_06070906:
    c.r[13] = c.r[4];  // 06070906 mov r4,r13
    c.r[5] = 0x0u;  // 06070908 mov #0,r5
    c.r[3] = ld32(0x06070970u);  // 0607090A mov.l 0x06070970,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607090C mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607095Eu);  // 0607090E mov.w 0x0607095E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06070910 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06070912 cmp/eq r2,r1
    { const bool k = c.t; c.r[6] = 0x12u; if (k) { goto L_06070934; } }  // 06070914 bt/s 0x06070934 ; mov #18,r6
    c.r[7] = c.r[2];  // 06070918 mov r2,r7
    c.r[2] = c.r[3];  // 0607091A mov r3,r2
L_0607091C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607091C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607091E extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06070920 cmp/eq r13,r1
    if (c.t) { goto L_06070934; }  // 06070922 bt 0x06070934
    c.r[5] += 1;  // 06070924 add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[6];  // 06070926 cmp/gt r6,r5
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06070934; } }  // 06070928 bt/s 0x06070934 ; add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607092C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607092E extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 06070930 cmp/eq r7,r1
    if (!c.t) { SH2_POLL(c); goto L_0607091C; }  // 06070932 bf 0x0607091C
L_06070934:
    c.r[1] = ld32(0x06070970u);  // 06070934 mov.l 0x06070970,r1
    c.r[0] = c.r[5];  // 06070936 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06070938 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607093A extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 0607093C cmp/eq r13,r1
    { const bool k = c.t; c.r[5] += 1; if (k) { goto L_06070944; } }  // 0607093E bt/s 0x06070944 ; add #1,r5
    c.r[5] = 0x1u;  // 06070942 mov #1,r5
L_06070944:
    c.r[1] = ld32(0x06070974u);  // 06070944 mov.l 0x06070974,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070946 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06070948 extu.b r1,r2
    c.r[1] = c.r[2];  // 0607094A mov r2,r1
    c.r[1] += c.r[1];  // 0607094C add r1,r1
    c.r[1] -= 3;  // 0607094E add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06070950 cmp/pz r1
    { const bool k = c.t; c.r[2] += c.r[5]; if (k) { goto L_06070978; } }  // 06070952 bt/s 0x06070978 ; add r5,r2
    c.r[5] += c.r[5];  // 06070956 add r5,r5
    c.r[5] += 1;  // 06070958 add #1,r5
    c.r[8] = c.r[5] & 0xFFu; goto L_0607097E;  // 0607095A bra 0x0607097E ; extu.b r5,r8
L_06070978:
    c.r[2] += c.r[2];  // 06070978 add r2,r2
    c.r[2] -= 2;  // 0607097A add #-2,r2
    c.r[8] = c.r[2] & 0xFFu;  // 0607097C extu.b r2,r8
L_0607097E:
    c.r[2] = c.r[8];  // 0607097E mov r8,r2
    c.r[2] += 2;  // 06070980 add #2,r2
    c.r[1] = 0x1Bu;  // 06070982 mov #27,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06070984 cmp/gt r1,r2
    if (!c.t) { goto L_0607098A; }  // 06070986 bf 0x0607098A
    c.r[8] = 0x17u;  // 06070988 mov #23,r8
L_0607098A:
    c.r[1] = c.r[10];  // 0607098A mov r10,r1
    c.r[1] += 6;  // 0607098C add #6,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0607098E extu.b r1,r13
    c.r[2] = c.r[13];  // 06070990 mov r13,r2
    c.r[2] += 7;  // 06070992 add #7,r2
    c.r[1] = 0x26u;  // 06070994 mov #38,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06070996 cmp/gt r1,r2
    if (!c.t) { goto L_0607099E; }  // 06070998 bf 0x0607099E
    c.r[13] = 0x1Du;  // 0607099A mov #29,r13
    c.r[10] = 0x17u;  // 0607099C mov #23,r10
L_0607099E:
    c.r[1] = c.r[8];  // 0607099E mov r8,r1
    c.r[1] += 3;  // 060709A0 add #3,r1
    c.r[12] = c.r[1] & 0xFFu;  // 060709A2 extu.b r1,r12
    c.r[2] = c.r[12];  // 060709A4 mov r12,r2
    c.r[2] += 6;  // 060709A6 add #6,r2
    c.r[1] = 0x1Au;  // 060709A8 mov #26,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060709AA cmp/gt r1,r2
    if (!c.t) { goto L_060709B2; }  // 060709AC bf 0x060709B2
    c.r[12] = 0x16u;  // 060709AE mov #22,r12
    c.r[8] = 0x13u;  // 060709B0 mov #19,r8
L_060709B2:
    c.r[1] = ld32(0x06070A70u);  // 060709B2 mov.l 0x06070A70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060709B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709B8u) return; }  // 060709B4 jsr @r1 ; nop
    c.r[11] = (uint32_t)(int16_t)ld16(0x06070A6Cu);  // 060709B8 mov.w 0x06070A6C,r11
    c.r[9] = ld32(0x06070A74u);  // 060709BA mov.l 0x06070A74,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060709C0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709C0u) return; }  // 060709BC jsr @r9 ; mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060709C4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709C4u) return; }  // 060709C0 jsr @r9 ; mov r10,r4
    c.r[4] = 0x20u;  // 060709C4 mov #32,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060709CAu; c.r[4] |= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709CAu) return; }  // 060709C6 jsr @r9 ; or r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060709CEu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709CEu) return; }  // 060709CA jsr @r9 ; mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060709D2u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709D2u) return; }  // 060709CE jsr @r9 ; mov r13,r4
    c.r[0] = c.r[12];  // 060709D2 mov r12,r0
    c.r[0] |= 0x20u;  // 060709D4 or #32,r0
    st32(c.r[14], c.r[0]);  // 060709D6 mov.l r0,@r14
    { const uint32_t x = c.r[9]; c.pr = 0x060709DCu; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709DCu) return; }  // 060709D8 jsr @r9 ; mov.l @r14,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060709E0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709E0u) return; }  // 060709DC jsr @r9 ; mov r11,r4
    c.r[10] += 1;  // 060709E0 add #1,r10
    { const uint32_t x = c.r[9]; c.pr = 0x060709E6u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709E6u) return; }  // 060709E2 jsr @r9 ; extu.b r10,r4
    c.r[8] += 1;  // 060709E6 add #1,r8
    c.r[0] = 0x20u;  // 060709E8 mov #32,r0
    c.r[8] |= c.r[0];  // 060709EA or r0,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060709F0u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060709F0u) return; }  // 060709EC jsr @r9 ; extu.b r8,r4
    c.r[1] = ld32(0x06070A78u);  // 060709F0 mov.l 0x06070A78,r1
    c.r[4] = ld32(0x06070A7Cu);  // 060709F2 mov.l 0x06070A7C,r4
    c.r[1] = ld32(c.r[1]);  // 060709F4 mov.l @r1,r1
    c.r[10] = ld32(0x06070A80u);  // 060709F6 mov.l 0x06070A80,r10
    c.r[1] += 1;  // 060709F8 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060709FA mov.b @r1,r8
    c.r[5] = 0x17u;  // 060709FC mov #23,r5
    c.r[8] += 2;  // 060709FE add #2,r8
    { const uint32_t x = c.r[10]; c.pr = 0x06070A04u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A04u) return; }  // 06070A00 jsr @r10 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06070A04 mov r0,r1
    c.r[5] = 0x6u;  // 06070A06 mov #6,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06070A0Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A0Cu) return; }  // 06070A08 jsr @r10 ; mov r1,r4
    c.r[2] = c.r[0];  // 06070A0C mov r0,r2
    c.r[1] = ld32(0x06070A84u);  // 06070A0E mov.l 0x06070A84,r1
    c.r[6] = 0x0u;  // 06070A10 mov #0,r6
    c.r[5] = c.r[8];  // 06070A12 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06070A18u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A18u) return; }  // 06070A14 jsr @r1 ; mov r2,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070A1Cu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A1Cu) return; }  // 06070A18 jsr @r9 ; mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070A20u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A20u) return; }  // 06070A1C jsr @r9 ; mov r13,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070A24u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A24u) return; }  // 06070A20 jsr @r9 ; mov.l @r14,r4
    c.r[12] += 1;  // 06070A24 add #1,r12
    c.r[5] = c.r[12] & 0xFFu;  // 06070A26 extu.b r12,r5
    c.r[13] += 1;  // 06070A28 add #1,r13
    c.r[4] = c.r[13] & 0xFFu;  // 06070A2A extu.b r13,r4
    c.r[7] = 0x2u;  // 06070A2C mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06070A2E mov.l r7,@-r15
    c.r[2] = 0x1u;  // 06070A30 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070A32 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070A34 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06070A36 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070A38 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070A3A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070A3C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070A3E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06070A40 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06070A42 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06070A44 mov.l r2,@-r15
    c.r[1] = ld32(0x06070A88u);  // 06070A46 mov.l 0x06070A88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070A4Cu; c.r[6] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A4Cu) return; }  // 06070A48 jsr @r1 ; mov #5,r6
    c.r[15] += 40;  // 06070A4C add #40,r15
    c.r[1] = ld32(0x06070A8Cu);  // 06070A4E mov.l 0x06070A8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070A54u; c.r[4] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070A54u) return; }  // 06070A50 jsr @r1 ; mov #23,r4
    c.r[14] += 4;  // 06070A54 add #4,r14
    c.r[15] = c.r[14];  // 06070A56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06070A58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06070A5A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06070A5C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06070A5E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06070A60 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06070A62 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06070A64 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06070A6Eu);  // 06070A66 mov.w 0x06070A6E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06070A68 rts ; mov.l @r15+,r8
}

void f_06070A90(SH2Context& c) {
    ran[1588] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06070A90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06070A92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06070A94 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06070A96 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06070A98 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06070A9A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06070A9C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06070A9E sts.l pr,@-r15
    c.r[15] -= 48;  // 06070AA0 add #-48,r15
    c.r[14] = c.r[15];  // 06070AA2 mov r15,r14
    c.r[1] = ld32(0x06070BE4u);  // 06070AA4 mov.l 0x06070BE4,r1
    c.r[2] = ld32(c.r[1]);  // 06070AA6 mov.l @r1,r2
    c.r[11] = 0x0u;  // 06070AA8 mov #0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06070BDEu);  // 06070AAA mov.w 0x06070BDE,r1
    c.r[0] = c.r[2];  // 06070AAC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06070AAE mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 06070AB0 mov #16,r0
    c.r[1] &= c.r[0];  // 06070AB2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06070AB4 tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06070AD8; } }  // 06070AB6 bf/s 0x06070AD8 ; mov #0,r3
    c.r[1] = ld32(0x06070BE8u);  // 06070ABA mov.l 0x06070BE8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070ABC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06070ABE extu.b r2,r2
    c.r[1] = ld32(0x06070BECu);  // 06070AC0 mov.l 0x06070BEC,r1
    c.r[1] = ld32(c.r[1]);  // 06070AC2 mov.l @r1,r1
    c.r[2] <<= 2;  // 06070AC4 shll2 r2
    c.r[2] <<= 2;  // 06070AC6 shll2 r2
    c.r[2] += c.r[1];  // 06070AC8 add r1,r2
    c.r[2] += 7;  // 06070ACA add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070ACC mov.b @r2,r1
    c.r[0] = c.r[1];  // 06070ACE mov r1,r0
    c.r[0] >>= 2;  // 06070AD0 shlr2 r0
    c.r[0] &= 0x1u;  // 06070AD2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070AD4 tst r0,r0
    if (c.t) { goto L_06070ADA; }  // 06070AD6 bt 0x06070ADA
L_06070AD8:
    c.r[3] = 0x1u;  // 06070AD8 mov #1,r3
L_06070ADA:
    c.r[1] = ld32(0x06070BE4u);  // 06070ADA mov.l 0x06070BE4,r1
    c.r[2] = ld32(c.r[1]);  // 06070ADC mov.l @r1,r2
    c.r[13] = c.r[3];  // 06070ADE mov r3,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06070BDEu);  // 06070AE0 mov.w 0x06070BDE,r1
    c.r[0] = c.r[2];  // 06070AE2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06070AE4 mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 06070AE6 mov #16,r0
    c.r[1] &= c.r[0];  // 06070AE8 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06070AEA tst r1,r1
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06070B2E; } }  // 06070AEC bf/s 0x06070B2E ; mov #0,r8
    c.r[1] = ld32(0x06070BE8u);  // 06070AF0 mov.l 0x06070BE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070AF2 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06070AF4 extu.b r1,r2
    c.r[1] = ld32(0x06070BECu);  // 06070AF6 mov.l 0x06070BEC,r1
    c.r[1] = ld32(c.r[1]);  // 06070AF8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06070AFA shll2 r2
    c.r[2] <<= 2;  // 06070AFC shll2 r2
    c.r[2] += c.r[1];  // 06070AFE add r1,r2
    c.r[1] = c.r[2];  // 06070B00 mov r2,r1
    c.r[1] += 7;  // 06070B02 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070B04 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06070B06 mov r1,r0
    c.r[0] >>= 2;  // 06070B08 shlr2 r0
    c.r[0] &= 0x1u;  // 06070B0A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070B0C tst r0,r0
    { const bool k = c.t; c.r[2] += 3; if (k) { goto L_06070B30; } }  // 06070B0E bt/s 0x06070B30 ; add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070B12 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06070B14 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06070B16 shlr r0
    c.r[0] &= 0x3u;  // 06070B18 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070B1A tst r0,r0
    if (c.t) { goto L_06070B2E; }  // 06070B1C bt 0x06070B2E
    c.r[1] = ld32(0x06070BF0u);  // 06070B1E mov.l 0x06070BF0,r1
    c.r[1] = ld32(c.r[1]);  // 06070B20 mov.l @r1,r1
    c.r[1] += 22;  // 06070B22 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070B24 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06070BE0u);  // 06070B26 mov.w 0x06070BE0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06070B28 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06070B2A cmp/hi r2,r1
    if (c.t) { goto L_06070B30; }  // 06070B2C bt 0x06070B30
L_06070B2E:
    c.r[8] = 0x1u;  // 06070B2E mov #1,r8
L_06070B30:
    c.r[1] = ld32(0x06070BF4u);  // 06070B30 mov.l 0x06070BF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070B36u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B36u) return; }  // 06070B32 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06070BF8u);  // 06070B36 mov.l 0x06070BF8,r1
    c.r[0] = ld32(0x06070BFCu);  // 06070B38 mov.l 0x06070BFC,r0
    c.pr = 0x06070B3Eu; c.r[1] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, 0x060710FAu); if (c.pc != 0x06070B3Eu) return;  // 06070B3A bsr 0x060710FA ; mov.l @r1,r1
    c.r[5] = 0x1u;  // 06070B3E mov #1,r5
    c.r[1] += 42;  // 06070B40 add #42,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070B42 mov.w @r1,r7
    c.r[4] = 0x0u;  // 06070B44 mov #0,r4
    c.r[7] <<= 16;  // 06070B46 shll16 r7
    c.r[7] += c.r[7];  // 06070B48 add r7,r7
    c.r[7] >>= 16;  // 06070B4A shlr16 r7
    c.r[7] += c.r[7];  // 06070B4C add r7,r7
    c.r[7] >>= 8;  // 06070B4E shlr8 r7
    c.r[1] = 0x0u;  // 06070B50 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06070B56u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B56u) return; }  // 06070B52 jsr @r0 ; mov.l r1,@-r15
    c.r[1] = ld32(0x06070C00u);  // 06070B56 mov.l 0x06070C00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070B5Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B5Cu) return; }  // 06070B58 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06070C04u);  // 06070B5C mov.l 0x06070C04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070B62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B62u) return; }  // 06070B5E jsr @r1 ; nop
    c.r[1] = ld32(0x06070C08u);  // 06070B62 mov.l 0x06070C08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070B68u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B68u) return; }  // 06070B64 jsr @r1 ; mov #1,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 06070B68 tst r8,r8
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06070B92; } }  // 06070B6A bt/s 0x06070B92 ; add #4,r15
    c.r[8] = ld32(0x06070BF0u);  // 06070B6E mov.l 0x06070BF0,r8
    c.r[9] = ld32(0x06070C0Cu);  // 06070B70 mov.l 0x06070C0C,r9
    c.r[1] = ld32(c.r[8]);  // 06070B72 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06070B74 mov #0,r5
    c.r[1] += 22;  // 06070B76 add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070B78 mov.w @r1,r6
    c.r[4] = 0x1u;  // 06070B7A mov #1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070B80u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B80u) return; }  // 06070B7C jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 06070B80 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06070B82 mov #0,r5
    c.r[1] += 26;  // 06070B84 add #26,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070B86 mov.w @r1,r6
    c.r[4] = 0x1u;  // 06070B88 mov #1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070B8Eu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B8Eu) return; }  // 06070B8A jsr @r9 ; extu.w r6,r6
    goto L_06070BA4;  // 06070B8E bra 0x06070BA4 ; nop
L_06070B92:
    c.r[8] = ld32(0x06070C0Cu);  // 06070B92 mov.l 0x06070C0C,r8
    c.r[6] = 0xFFFFFFFFu;  // 06070B94 mov #-1,r6
    c.r[5] = 0x0u;  // 06070B96 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070B9Cu; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070B9Cu) return; }  // 06070B98 jsr @r8 ; mov #81,r4
    c.r[6] = 0xFFFFFFFFu;  // 06070B9C mov #-1,r6
    c.r[5] = 0x0u;  // 06070B9E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070BA4u; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070BA4u) return; }  // 06070BA0 jsr @r8 ; mov #81,r4
L_06070BA4:
    c.r[9] = ld32(0x06070BF0u);  // 06070BA4 mov.l 0x06070BF0,r9
    c.r[2] = ld32(c.r[9]);  // 06070BA6 mov.l @r9,r2
    c.r[6] = 0xBu;  // 06070BA8 mov #11,r6
    c.r[1] = c.r[2];  // 06070BAA mov r2,r1
    c.r[1] += 26;  // 06070BAC add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070BAE mov.w @r1,r5
    c.r[2] += 22;  // 06070BB0 add #22,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06070BB2 mov.w @r2,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06070BB4 extu.w r5,r5
    c.r[1] = ld32(0x06070C10u);  // 06070BB6 mov.l 0x06070C10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070BBCu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070BBCu) return; }  // 06070BB8 jsr @r1 ; extu.w r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 06070BBC tst r13,r13
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_06070C2A; } }  // 06070BBE bt/s 0x06070C2A ; mov #-1,r6
    c.r[1] = ld32(c.r[9]);  // 06070BC2 mov.l @r9,r1
    c.r[1] += 24;  // 06070BC4 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070BC6 mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06070BC8 extu.w r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06070BE2u);  // 06070BCA mov.w 0x06070BE2,r1
    c.t = c.r[6] == c.r[1];  // 06070BCC cmp/eq r1,r6
    if (!c.t) { goto L_06070C14; }  // 06070BCE bf 0x06070C14
    c.r[6] = 0xFFFFFFFEu;  // 06070BD0 mov #-2,r6
    c.r[8] = ld32(0x06070C0Cu);  // 06070BD2 mov.l 0x06070C0C,r8
    c.r[5] = 0x0u;  // 06070BD4 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070BDAu; c.r[4] = 0x31u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070BDAu) return; }  // 06070BD6 jsr @r8 ; mov #49,r4
    c.r[6] = 0xFFFFFFFEu; goto L_06070C34;  // 06070BDA bra 0x06070C34 ; mov #-2,r6
L_06070C14:
    c.r[8] = ld32(0x06070D70u);  // 06070C14 mov.l 0x06070D70,r8
    c.r[5] = 0x0u;  // 06070C16 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070C1Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C1Cu) return; }  // 06070C18 jsr @r8 ; mov #1,r4
    c.r[1] = ld32(c.r[9]);  // 06070C1C mov.l @r9,r1
    c.r[5] = 0x0u;  // 06070C1E mov #0,r5
    c.r[1] += 28;  // 06070C20 add #28,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070C22 mov.w @r1,r6
    c.r[4] = 0x1u;  // 06070C24 mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_06070C38;  // 06070C26 bra 0x06070C38 ; extu.w r6,r6
L_06070C2A:
    c.r[8] = ld32(0x06070D70u);  // 06070C2A mov.l 0x06070D70,r8
    c.r[5] = 0x0u;  // 06070C2C mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070C32u; c.r[4] = 0x31u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C32u) return; }  // 06070C2E jsr @r8 ; mov #49,r4
    c.r[6] = 0xFFFFFFFFu;  // 06070C32 mov #-1,r6
L_06070C34:
    c.r[5] = 0x0u;  // 06070C34 mov #0,r5
    c.r[4] = 0x31u;  // 06070C36 mov #49,r4
L_06070C38:
    { const uint32_t x = c.r[8]; c.pr = 0x06070C3Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C3Cu) return; }  // 06070C38 jsr @r8 ; nop
    c.r[1] = ld32(0x06070D74u);  // 06070C3C mov.l 0x06070D74,r1
    c.r[2] = ld32(c.r[1]);  // 06070C3E mov.l @r1,r2
    c.r[6] = 0x4u;  // 06070C40 mov #4,r6
    c.r[1] = c.r[2];  // 06070C42 mov r2,r1
    c.r[1] += 28;  // 06070C44 add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070C46 mov.w @r1,r5
    c.r[2] += 24;  // 06070C48 add #24,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06070C4A mov.w @r2,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06070C4C extu.w r5,r5
    c.r[1] = ld32(0x06070D78u);  // 06070C4E mov.l 0x06070D78,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070C54u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C54u) return; }  // 06070C50 jsr @r1 ; extu.w r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 06070C54 tst r13,r13
    if (c.t) { goto L_06070CA4; }  // 06070C56 bt 0x06070CA4
    c.r[1] = ld32(0x06070D7Cu);  // 06070C58 mov.l 0x06070D7C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070C5A mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06070C5C extu.b r2,r2
    c.r[1] = ld32(0x06070D80u);  // 06070C5E mov.l 0x06070D80,r1
    c.r[1] = ld32(c.r[1]);  // 06070C60 mov.l @r1,r1
    c.r[2] <<= 2;  // 06070C62 shll2 r2
    c.r[2] <<= 2;  // 06070C64 shll2 r2
    c.r[2] += c.r[1];  // 06070C66 add r1,r2
    c.r[2] += 7;  // 06070C68 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070C6A mov.b @r2,r1
    c.r[0] = c.r[1];  // 06070C6C mov r1,r0
    c.r[0] >>= 2;  // 06070C6E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06070C70 shlr r0
    c.r[0] >>= 2;  // 06070C72 shlr2 r0
    c.r[0] &= 0x1u;  // 06070C74 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070C76 tst r0,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06070C7E; } }  // 06070C78 bt/s 0x06070C7E ; mov #0,r9
    c.r[9] = 0x4u;  // 06070C7C mov #4,r9
L_06070C7E:
    c.r[1] = ld32(0x06070D84u);  // 06070C7E mov.l 0x06070D84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070C84u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C84u) return; }  // 06070C80 jsr @r1 ; mov #2,r4
    c.r[4] = c.r[9];  // 06070C84 mov r9,r4
    c.r[4] += 37;  // 06070C86 add #37,r4
    c.r[8] = ld32(0x06070D88u);  // 06070C88 mov.l 0x06070D88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06070C8Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C8Eu) return; }  // 06070C8A jsr @r8 ; extu.b r4,r4
    c.r[4] = c.r[9];  // 06070C8E mov r9,r4
    c.r[4] += 38;  // 06070C90 add #38,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070C96u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C96u) return; }  // 06070C92 jsr @r8 ; extu.b r4,r4
    c.r[4] = c.r[9];  // 06070C96 mov r9,r4
    c.r[4] += 39;  // 06070C98 add #39,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070C9Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070C9Eu) return; }  // 06070C9A jsr @r8 ; extu.b r4,r4
    c.r[9] += 40;  // 06070C9E add #40,r9
    { const uint32_t x = c.r[8]; c.pr = 0x06070CA4u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070CA4u) return; }  // 06070CA0 jsr @r8 ; extu.b r9,r4
L_06070CA4:
    c.r[9] = ld32(0x06070D8Cu);  // 06070CA4 mov.l 0x06070D8C,r9
    c.r[1] = ld32(c.r[9]);  // 06070CA6 mov.l @r9,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070CA8 mov.w @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06070D68u);  // 06070CAA mov.w 0x06070D68,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06070D6Au);  // 06070CAC mov.w 0x06070D6A,r1
    c.r[4] += c.r[1];  // 06070CAE add r1,r4
    c.r[1] = ld32(0x06070D90u);  // 06070CB0 mov.l 0x06070D90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070CB6u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070CB6u) return; }  // 06070CB2 jsr @r1 ; extu.w r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 06070CB6 tst r13,r13
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06070CD8; } }  // 06070CB8 bt/s 0x06070CD8 ; mov #0,r5
    c.r[8] = ld32(0x06070D70u);  // 06070CBC mov.l 0x06070D70,r8
    c.r[1] = ld32(c.r[9]);  // 06070CBE mov.l @r9,r1
    c.r[1] += 2;  // 06070CC0 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070CC2 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06070CC4 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070CCAu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070CCAu) return; }  // 06070CC6 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(c.r[9]);  // 06070CCA mov.l @r9,r1
    c.r[5] = 0x0u;  // 06070CCC mov #0,r5
    c.r[1] += 9;  // 06070CCE add #9,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070CD0 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06070CD2 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu; goto L_06070CE6;  // 06070CD4 bra 0x06070CE6 ; extu.b r6,r6
L_06070CD8:
    c.r[8] = ld32(0x06070D70u);  // 06070CD8 mov.l 0x06070D70,r8
    c.r[6] = 0xFFFFFFFFu;  // 06070CDA mov #-1,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06070CE0u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070CE0u) return; }  // 06070CDC jsr @r8 ; mov #32,r4
    c.r[6] = 0xFFFFFFFFu;  // 06070CE0 mov #-1,r6
    c.r[5] = 0x0u;  // 06070CE2 mov #0,r5
    c.r[4] = 0x30u;  // 06070CE4 mov #48,r4
L_06070CE6:
    { const uint32_t x = c.r[8]; c.pr = 0x06070CEAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070CEAu) return; }  // 06070CE6 jsr @r8 ; nop
    c.r[10] = (uint32_t)(int16_t)ld16(0x06070D68u);  // 06070CEA mov.w 0x06070D68,r10
    c.r[1] = ld32(0x06070D74u);  // 06070CEC mov.l 0x06070D74,r1
    c.r[1] = ld32(c.r[1]);  // 06070CEE mov.l @r1,r1
    c.r[8] = ld32(0x06070D90u);  // 06070CF0 mov.l 0x06070D90,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070CF2 mov.w @r1,r4
    c.r[5] = c.r[10];  // 06070CF4 mov r10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06070D6Cu);  // 06070CF6 mov.w 0x06070D6C,r1
    c.r[4] += c.r[1];  // 06070CF8 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070CFEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070CFEu) return; }  // 06070CFA jsr @r8 ; extu.w r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 06070CFE tst r13,r13
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06070DEC; } }  // 06070D00 bt/s 0x06070DEC ; mov #0,r9
L_06070D04:
    c.r[1] = ld32(0x06070D8Cu);  // 06070D04 mov.l 0x06070D8C,r1
    c.r[1] = ld32(c.r[1]);  // 06070D06 mov.l @r1,r1
    c.r[1] += c.r[9];  // 06070D08 add r9,r1
    c.r[1] += 30;  // 06070D0A add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070D0C mov.b @r1,r1
    c.r[4] = ld32(0x06070D94u);  // 06070D0E mov.l 0x06070D94,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06070D10 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06070D12 tst r1,r1
    { const bool k = c.t; c.r[4] += c.r[1]; if (k) { goto L_06070D1A; } }  // 06070D14 bt/s 0x06070D1A ; add r1,r4
    c.r[4] -= 32;  // 06070D18 add #-32,r4
L_06070D1A:
    c.r[4] = c.r[4] & 0xFFFFu;  // 06070D1A extu.w r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070D20u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070D20u) return; }  // 06070D1C jsr @r8 ; mov r10,r5
    c.r[9] += 1;  // 06070D20 add #1,r9
    c.r[1] = 0x3u;  // 06070D22 mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06070D24 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06070D04; }  // 06070D26 bf 0x06070D04
    c.r[1] = ld32(0x06070D7Cu);  // 06070D28 mov.l 0x06070D7C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070D2A mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06070D2C extu.b r2,r2
    c.r[1] = ld32(0x06070D80u);  // 06070D2E mov.l 0x06070D80,r1
    c.r[1] = ld32(c.r[1]);  // 06070D30 mov.l @r1,r1
    c.r[2] <<= 2;  // 06070D32 shll2 r2
    c.r[2] <<= 2;  // 06070D34 shll2 r2
    c.r[2] += c.r[1];  // 06070D36 add r1,r2
    c.r[2] += 3;  // 06070D38 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070D3A mov.b @r2,r1
    c.r[0] = c.r[1];  // 06070D3C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06070D3E shlr r0
    c.r[0] &= 0x3u;  // 06070D40 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06070D42 tst r0,r0
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06070D5C; } }  // 06070D44 bt/s 0x06070D5C ; mov #0,r6
    c.r[8] = ld32(0x06070D70u);  // 06070D48 mov.l 0x06070D70,r8
    c.r[5] = 0x0u;  // 06070D4A mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070D50u; c.r[4] = 0x50u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070D50u) return; }  // 06070D4C jsr @r8 ; mov #80,r4
    c.r[6] = 0x0u;  // 06070D50 mov #0,r6
    c.r[5] = 0x0u;  // 06070D52 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070D58u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070D58u) return; }  // 06070D54 jsr @r8 ; mov #64,r4
    goto L_06070DDC;  // 06070D58 bra 0x06070DDC ; nop
L_06070D5C:
    c.r[1] = ld32(0x06070D8Cu);  // 06070D5C mov.l 0x06070D8C,r1
    c.r[1] = ld32(c.r[1]);  // 06070D5E mov.l @r1,r1
    c.r[1] += 2;  // 06070D60 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070D62 mov.b @r1,r1
    c.r[9] = 0x1u; goto L_06070DAC;  // 06070D64 bra 0x06070DAC ; mov #1,r9
L_06070D98:
    c.r[8] = ld32(0x06070F14u);  // 06070D98 mov.l 0x06070F14,r8
    c.r[0] = ld32(0x06070F18u);  // 06070D9A mov.l 0x06070F18,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06070DA0u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070DA0u) return; }  // 06070D9C jsr @r0 ; mov.l @r8,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06070DA0 extu.w r0,r1
    c.r[11] += c.r[1];  // 06070DA2 add r1,r11
    c.r[1] = ld32(c.r[8]);  // 06070DA4 mov.l @r8,r1
    c.r[1] += 2;  // 06070DA6 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070DA8 mov.b @r1,r1
    c.r[9] += 1;  // 06070DAA add #1,r9
L_06070DAC:
    c.r[2] = c.r[1] & 0xFFu;  // 06070DAC extu.b r1,r2
    c.r[1] = 0x62u;  // 06070DAE mov #98,r1
    c.t = c.r[2] > c.r[1];  // 06070DB0 cmp/hi r1,r2
    if (c.t) { goto L_06070DB6; }  // 06070DB2 bt 0x06070DB6
    c.r[2] += 1;  // 06070DB4 add #1,r2
L_06070DB6:
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[2];  // 06070DB6 cmp/ge r2,r9
    { const bool k = !c.t; c.r[5] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_06070D98; } }  // 06070DB8 bf/s 0x06070D98 ; extu.b r9,r5
    c.r[8] = ld32(0x06070F14u);  // 06070DBC mov.l 0x06070F14,r8
    c.r[9] = ld32(0x06070F1Cu);  // 06070DBE mov.l 0x06070F1C,r9
    c.r[1] = ld32(c.r[8]);  // 06070DC0 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06070DC2 mov #0,r5
    c.r[1] += 4;  // 06070DC4 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070DC6 mov.w @r1,r1
    c.r[4] = 0x0u;  // 06070DC8 mov #0,r4
    c.r[11] -= c.r[1];  // 06070DCA sub r1,r11
    { const uint32_t x = c.r[9]; c.pr = 0x06070DD0u; c.r[6] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070DD0u) return; }  // 06070DCC jsr @r9 ; mov r11,r6
    c.r[1] = ld32(c.r[8]);  // 06070DD0 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06070DD2 mov #0,r5
    c.r[1] += 4;  // 06070DD4 add #4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070DD6 mov.w @r1,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06070DDCu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070DDCu) return; }  // 06070DD8 jsr @r9 ; mov #64,r4
L_06070DDC:
    c.r[8] = ld32(0x06070F20u);  // 06070DDC mov.l 0x06070F20,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06070DE2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070DE2u) return; }  // 06070DDE jsr @r8 ; mov #0,r4
    c.r[1] = ld32(0x06070F24u);  // 06070DE2 mov.l 0x06070F24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070DE8u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070DE8u) return; }  // 06070DE4 jsr @r1 ; extu.b r0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06070DECu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070DECu) return; }  // 06070DE8 jsr @r8 ; mov #1,r4
L_06070DEC:
    c.r[1] = ld32(0x06070F14u);  // 06070DEC mov.l 0x06070F14,r1
    c.r[2] = ld32(c.r[1]);  // 06070DEE mov.l @r1,r2
    c.r[1] = c.r[2];  // 06070DF0 mov r2,r1
    c.r[1] += 8;  // 06070DF2 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070DF4 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06070DF6 extu.b r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06070F0Au);  // 06070DF8 mov.w 0x06070F0A,r1
    c.t = c.r[5] == c.r[1];  // 06070DFA cmp/eq r1,r5
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06070ED2; } }  // 06070DFC bt/s 0x06070ED2 ; mov #0,r9
    c.r[2] += 34;  // 06070E00 add #34,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070E02 mov.b @r2,r1
    c.r[12] = 0x1u;  // 06070E04 mov #1,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06070E06 extu.b r1,r1
    c.r[1] >>= 2;  // 06070E08 shlr2 r1
    c.r[1] >>= 2;  // 06070E0A shlr2 r1
    c.r[1] -= 2;  // 06070E0C add #-2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06070E0E extu.b r1,r1
    c.t = c.r[1] > c.r[12];  // 06070E10 cmp/hi r12,r1
    if (c.t) { goto L_06070ED2; }  // 06070E12 bt 0x06070ED2
    c.r[1] = ld32(0x06070F28u);  // 06070E14 mov.l 0x06070F28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070E1Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E1Au) return; }  // 06070E16 jsr @r1 ; mov r14,r4
    c.r[1] = c.r[14];  // 06070E1A mov r14,r1
    c.r[1] += 42;  // 06070E1C add #42,r1
    c.r[0] = ld32(0x06070F2Cu);  // 06070E1E mov.l 0x06070F2C,r0
    c.r[6] = c.r[12];  // 06070E20 mov r12,r6
    c.r[5] = c.r[12];  // 06070E22 mov r12,r5
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06070E24 mov.w @r1,r7
    c.r[4] = 0x0u;  // 06070E26 mov #0,r4
    c.r[7] <<= 16;  // 06070E28 shll16 r7
    c.r[7] += c.r[7];  // 06070E2A add r7,r7
    c.r[7] >>= 16;  // 06070E2C shlr16 r7
    c.r[7] += c.r[7];  // 06070E2E add r7,r7
    c.r[7] >>= 8;  // 06070E30 shlr8 r7
    c.r[1] = 0x0u;  // 06070E32 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06070E38u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E38u) return; }  // 06070E34 jsr @r0 ; mov.l r1,@-r15
    c.r[9] = ld32(0x06070F24u);  // 06070E38 mov.l 0x06070F24,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06070E3Eu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E3Eu) return; }  // 06070E3A jsr @r9 ; mov #4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070F0Cu);  // 06070E3E mov.w 0x06070F0C,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070E44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E44u) return; }  // 06070E40 jsr @r9 ; nop
    { const uint32_t x = c.r[9]; c.pr = 0x06070E48u; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E48u) return; }  // 06070E44 jsr @r9 ; mov #11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070E4Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E4Cu) return; }  // 06070E48 jsr @r9 ; mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070E50u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E50u) return; }  // 06070E4C jsr @r9 ; mov #0,r4
    c.r[11] = ld32(0x06070F30u);  // 06070E50 mov.l 0x06070F30,r11
    c.r[10] = ld32(0x06070F34u);  // 06070E52 mov.l 0x06070F34,r10
    c.r[5] = 0xDu;  // 06070E54 mov #13,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[14]);  // 06070E56 mov.w @r14,r8
    c.r[4] = c.r[11];  // 06070E58 mov r11,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06070E5Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E5Eu) return; }  // 06070E5A jsr @r10 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06070E5E mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06070E64u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E64u) return; }  // 06070E60 jsr @r10 ; mov r0,r4
    c.r[1] = ld32(0x06070F38u);  // 06070E64 mov.l 0x06070F38,r1
    c.r[6] = 0x0u;  // 06070E66 mov #0,r6
    c.r[5] = c.r[0];  // 06070E68 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06070E6Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E6Eu) return; }  // 06070E6A jsr @r1 ; mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070E72u; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E72u) return; }  // 06070E6E jsr @r9 ; mov #9,r4
    c.r[5] = 0x17u;  // 06070E72 mov #23,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06070E78u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E78u) return; }  // 06070E74 jsr @r10 ; mov r11,r4
    c.r[5] = 0x8u;  // 06070E78 mov #8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06070E7Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E7Eu) return; }  // 06070E7A jsr @r10 ; mov r0,r4
    c.r[8] = ld32(0x06070F3Cu);  // 06070E7E mov.l 0x06070F3C,r8
    c.r[6] = 0x0u;  // 06070E80 mov #0,r6
    c.r[5] = c.r[12];  // 06070E82 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070E88u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E88u) return; }  // 06070E84 jsr @r8 ; mov r0,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06070F0Eu);  // 06070E88 mov.w 0x06070F0E,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06070E8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E8Eu) return; }  // 06070E8A jsr @r9 ; nop
    c.r[5] = 0x17u;  // 06070E8E mov #23,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06070E94u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E94u) return; }  // 06070E90 jsr @r10 ; mov r11,r4
    c.r[5] = 0x8u;  // 06070E94 mov #8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06070E9Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070E9Au) return; }  // 06070E96 jsr @r10 ; mov r0,r4
    c.r[6] = 0x0u;  // 06070E9A mov #0,r6
    c.r[5] = 0x0u;  // 06070E9C mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06070EA2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070EA2u) return; }  // 06070E9E jsr @r8 ; mov r0,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 06070EA2 tst r13,r13
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06070EB8; } }  // 06070EA4 bt/s 0x06070EB8 ; add #4,r15
    c.r[1] = c.r[14];  // 06070EA8 mov r14,r1
    c.r[1] += 2;  // 06070EAA add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070EAC mov.b @r1,r6
    c.r[5] = 0x0u;  // 06070EAE mov #0,r5
    c.r[4] = 0x0u;  // 06070EB0 mov #0,r4
    c.r[1] = ld32(0x06070F1Cu);  // 06070EB2 mov.l 0x06070F1C,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_06070EC0;  // 06070EB4 bra 0x06070EC0 ; extu.b r6,r6
L_06070EB8:
    c.r[1] = ld32(0x06070F1Cu);  // 06070EB8 mov.l 0x06070F1C,r1
    c.r[6] = 0xFFFFFFFFu;  // 06070EBA mov #-1,r6
    c.r[5] = 0x0u;  // 06070EBC mov #0,r5
    c.r[4] = 0x20u;  // 06070EBE mov #32,r4
L_06070EC0:
    { const uint32_t x = c.r[1]; c.pr = 0x06070EC4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070EC4u) return; }  // 06070EC0 jsr @r1 ; nop
    c.r[1] = ld32(0x06070F1Cu);  // 06070EC4 mov.l 0x06070F1C,r1
    c.r[6] = 0x0u;  // 06070EC6 mov #0,r6
    c.r[5] = 0x0u;  // 06070EC8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06070ECEu; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070ECEu) return; }  // 06070ECA jsr @r1 ; mov #48,r4
    c.t = (c.r[13] & c.r[13]) == 0; goto L_06070EE2;  // 06070ECE bra 0x06070EE2 ; tst r13,r13
L_06070ED2:
    c.r[10] = ld32(0x06070F24u);  // 06070ED2 mov.l 0x06070F24,r10
    c.r[8] = 0x4u;  // 06070ED4 mov #4,r8
L_06070ED6:
    { const uint32_t x = c.r[10]; c.pr = 0x06070EDAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070EDAu) return; }  // 06070ED6 jsr @r10 ; mov #0,r4
    c.r[9] += 1;  // 06070EDA add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[8];  // 06070EDC cmp/gt r8,r9
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { SH2_POLL(c); goto L_06070ED6; } }  // 06070EDE bf/s 0x06070ED6 ; tst r13,r13
L_06070EE2:
    { const bool k = c.t; c.r[4] = 0x19u; if (k) { goto L_06070EEC; } }  // 06070EE2 bt/s 0x06070EEC ; mov #25,r4
    c.r[1] = ld32(0x06070F40u);  // 06070EE6 mov.l 0x06070F40,r1
    c.r[4] = 0x18u; goto L_06070EEE;  // 06070EE8 bra 0x06070EEE ; mov #24,r4
L_06070EEC:
    c.r[1] = ld32(0x06070F40u);  // 06070EEC mov.l 0x06070F40,r1
L_06070EEE:
    { const uint32_t x = c.r[1]; c.pr = 0x06070EF2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070EF2u) return; }  // 06070EEE jsr @r1 ; nop
    c.r[14] += 48;  // 06070EF2 add #48,r14
    c.r[15] = c.r[14];  // 06070EF4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06070EF6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06070EF8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06070EFA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06070EFC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06070EFE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06070F00 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06070F02 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06070F10u);  // 06070F04 mov.w 0x06070F10,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06070F06 rts ; mov.l @r15+,r8
}

void f_06070F44(SH2Context& c) {
    ran[1589] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06070F44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06070F46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06070F48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06070F4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06070F4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06070F4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06070F50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06070F52 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 06070F54 mov r4,r8
    c.r[0] = ld32(0x06071130u);  // 06070F56 mov.l 0x06071130,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06070F58 mov.b @r0,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06070F5A extu.b r0,r0
    c.r[0] <<= 2;  // 06070F5C shll2 r0
    c.r[0] <<= 2;  // 06070F5E shll2 r0
    c.r[1] = ld32(0x06071134u);  // 06070F60 mov.l 0x06071134,r1
    c.r[9] = ld32(c.r[1]);  // 06070F62 mov.l @r1,r9
    c.r[9] += c.r[0];  // 06070F64 add r0,r9
    c.r[10] = ld32(0x06071138u);  // 06070F66 mov.l 0x06071138,r10
    c.r[11] = 0x0u;  // 06070F68 mov #0,r11
    c.r[12] = 0xAu;  // 06070F6A mov #10,r12
    c.r[13] = 0x0u;  // 06070F6C mov #0,r13
    c.r[14] = 0x0u;  // 06070F6E mov #0,r14
L_06070F70:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06070F70 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06070F72 extu.b r1,r1
    c.r[1] += c.r[9];  // 06070F74 add r9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06070F76 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06070F78 extu.b r1,r1
    c.r[2] = c.r[10];  // 06070F7A mov r10,r2
    c.r[2] += 1;  // 06070F7C add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06070F7E mov.b @r2,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06070F80 extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06070F82 tst r2,r2
    if (!c.t) { goto L_06070F90; }  // 06070F84 bf 0x06070F90
    c.r[2] = ld32(0x0607113Cu);  // 06070F86 mov.l 0x0607113C,r2
    c.t = c.r[1] == c.r[2];  // 06070F88 cmp/eq r2,r1
    if (c.t) { goto L_06071040; }  // 06070F8A bt 0x06071040
    goto L_06070F94;  // 06070F8C bra 0x06070F94 ; nop
L_06070F90:
    c.t = (c.r[1] & c.r[2]) == 0;  // 06070F90 tst r2,r1
    if (c.t) { goto L_06071040; }  // 06070F92 bt 0x06071040
L_06070F94:
    c.r[0] = c.r[10];  // 06070F94 mov r10,r0
    c.r[0] += 3;  // 06070F96 add #3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06070F98 mov.b @r0,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06070F9A extu.b r2,r2
    c.r[1] = c.r[12];  // 06070F9C mov r12,r1
    c.r[1] += c.r[2];  // 06070F9E add r2,r1
    c.r[3] = 0x38u;  // 06070FA0 mov #56,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06070FA2 cmp/gt r3,r1
    if (!c.t) { goto L_06070FAA; }  // 06070FA4 bf 0x06070FAA
    c.r[12] = 0xAu;  // 06070FA6 mov #10,r12
    c.r[13] += 2;  // 06070FA8 add #2,r13
L_06070FAA:
    c.r[11] += 1;  // 06070FAA add #1,r11
    c.t = (c.r[8] & c.r[8]) == 0;  // 06070FAC tst r8,r8
    if (c.t) { goto L_06071034; }  // 06070FAE bt 0x06071034
    c.r[2] = c.r[12];  // 06070FB0 mov r12,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06070FB2 shlr r2
    c.r[1] = ld32(0x06071140u);  // 06070FB4 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FBAu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FBAu) return; }  // 06070FB6 jsr @r1 ; mov r2,r4
    c.r[1] = ld32(0x06071144u);  // 06070FBA mov.l 0x06071144,r1
    c.r[2] = ld32(c.r[1]);  // 06070FBC mov.l @r1,r2
    c.r[2] += c.r[13];  // 06070FBE add r13,r2
    c.r[1] = ld32(0x06071140u);  // 06070FC0 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FC6u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FC6u) return; }  // 06070FC2 jsr @r1 ; mov r2,r4
    c.r[2] = 0x1u;  // 06070FC6 mov #1,r2
    c.t = (c.r[12] & c.r[2]) == 0;  // 06070FC8 tst r2,r12
    if (!c.t) { goto L_06070FF0; }  // 06070FCA bf 0x06070FF0
    c.r[2] = 0x3u;  // 06070FCC mov #3,r2
    c.r[1] = ld32(0x06071140u);  // 06070FCE mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FD4u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FD4u) return; }  // 06070FD0 jsr @r1 ; mov r2,r4
    c.r[2] = 0xFFFFFFFCu;  // 06070FD4 mov #-4,r2
    c.r[1] = ld32(0x06071140u);  // 06070FD6 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FDCu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FDCu) return; }  // 06070FD8 jsr @r1 ; mov r2,r4
    c.r[2] = 0x0u;  // 06070FDC mov #0,r2
    c.r[1] = ld32(0x06071140u);  // 06070FDE mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FE4u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FE4u) return; }  // 06070FE0 jsr @r1 ; mov r2,r4
    c.r[2] = 0x0u;  // 06070FE4 mov #0,r2
    c.r[1] = ld32(0x06071140u);  // 06070FE6 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FECu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FECu) return; }  // 06070FE8 jsr @r1 ; mov r2,r4
    goto L_06071020;  // 06070FEC bra 0x06071020 ; nop
L_06070FF0:
    c.r[2] = 0x5u;  // 06070FF0 mov #5,r2
    c.r[1] = ld32(0x06071140u);  // 06070FF2 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06070FF8u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06070FF8u) return; }  // 06070FF4 jsr @r1 ; mov r2,r4
    c.r[2] = 0xFFFFFFF2u;  // 06070FF8 mov #-14,r2
    c.r[1] = ld32(0x06071140u);  // 06070FFA mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071000u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071000u) return; }  // 06070FFC jsr @r1 ; mov r2,r4
    c.r[2] = 0xFFFFFFE2u;  // 06071000 mov #-30,r2
    c.r[1] = ld32(0x06071140u);  // 06071002 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071008u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071008u) return; }  // 06071004 jsr @r1 ; mov r2,r4
    c.r[2] = 0xFFFFFFFCu;  // 06071008 mov #-4,r2
    c.r[1] = ld32(0x06071140u);  // 0607100A mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071010u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071010u) return; }  // 0607100C jsr @r1 ; mov r2,r4
    c.r[2] = 0xFFFFFFFFu;  // 06071010 mov #-1,r2
    c.r[1] = ld32(0x06071140u);  // 06071012 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071018u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071018u) return; }  // 06071014 jsr @r1 ; mov r2,r4
    c.r[2] = 0x0u;  // 06071018 mov #0,r2
    c.r[1] = ld32(0x06071140u);  // 0607101A mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071020u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071020u) return; }  // 0607101C jsr @r1 ; mov r2,r4
L_06071020:
    c.r[1] = c.r[10];  // 06071020 mov r10,r1
    c.r[1] += 2;  // 06071022 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071024 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06071026 extu.b r1,r1
    c.r[4] = ld32(0x06071148u);  // 06071028 mov.l 0x06071148,r4
    c.r[4] += c.r[1];  // 0607102A add r1,r4
    c.r[5] = ld32(0x0607113Cu);  // 0607102C mov.l 0x0607113C,r5
    c.r[1] = ld32(0x0607114Cu);  // 0607102E mov.l 0x0607114C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071034u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071034u) return; }  // 06071030 jsr @r1 ; nop
L_06071034:
    c.r[1] = c.r[10];  // 06071034 mov r10,r1
    c.r[1] += 3;  // 06071036 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071038 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607103A extu.b r1,r1
    c.r[12] += c.r[1];  // 0607103C add r1,r12
    c.r[12] += 2;  // 0607103E add #2,r12
L_06071040:
    c.r[10] += 4;  // 06071040 add #4,r10
    c.r[14] += 1;  // 06071042 add #1,r14
    c.r[1] = 0xFu;  // 06071044 mov #15,r1
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[1];  // 06071046 cmp/ge r1,r14
    if (!c.t) { SH2_POLL(c); goto L_06070F70; }  // 06071048 bf 0x06070F70
    c.t = (c.r[11] & c.r[11]) == 0;  // 0607104A tst r11,r11
    if (!c.t) { goto L_06071090; }  // 0607104C bf 0x06071090
    c.r[11] = 0x1u;  // 0607104E mov #1,r11
    c.t = (c.r[8] & c.r[8]) == 0;  // 06071050 tst r8,r8
    if (c.t) { goto L_06071090; }  // 06071052 bt 0x06071090
    c.r[2] = 0x5u;  // 06071054 mov #5,r2
    c.r[1] = ld32(0x06071140u);  // 06071056 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607105Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607105Cu) return; }  // 06071058 jsr @r1 ; mov r2,r4
    c.r[1] = ld32(0x06071144u);  // 0607105C mov.l 0x06071144,r1
    c.r[2] = ld32(c.r[1]);  // 0607105E mov.l @r1,r2
    c.r[1] = ld32(0x06071140u);  // 06071060 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071066u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071066u) return; }  // 06071062 jsr @r1 ; mov r2,r4
    c.r[2] = 0x3u;  // 06071066 mov #3,r2
    c.r[1] = ld32(0x06071140u);  // 06071068 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607106Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607106Eu) return; }  // 0607106A jsr @r1 ; mov r2,r4
    c.r[2] = 0xFFFFFFFCu;  // 0607106E mov #-4,r2
    c.r[1] = ld32(0x06071140u);  // 06071070 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071076u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071076u) return; }  // 06071072 jsr @r1 ; mov r2,r4
    c.r[2] = 0x0u;  // 06071076 mov #0,r2
    c.r[1] = ld32(0x06071140u);  // 06071078 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607107Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607107Eu) return; }  // 0607107A jsr @r1 ; mov r2,r4
    c.r[2] = 0x0u;  // 0607107E mov #0,r2
    c.r[1] = ld32(0x06071140u);  // 06071080 mov.l 0x06071140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071086u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071086u) return; }  // 06071082 jsr @r1 ; mov r2,r4
    c.r[4] = ld32(0x06071150u);  // 06071086 mov.l 0x06071150,r4
    c.r[5] = ld32(0x0607113Cu);  // 06071088 mov.l 0x0607113C,r5
    c.r[1] = ld32(0x0607114Cu);  // 0607108A mov.l 0x0607114C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071090u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071090u) return; }  // 0607108C jsr @r1 ; nop
L_06071090:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06071090 tst r8,r8
    if (!c.t) { goto L_060710E4; }  // 06071092 bf 0x060710E4
    c.r[2] = 0x10u;  // 06071094 mov #16,r2
    c.r[2] -= c.r[13];  // 06071096 sub r13,r2
    c.r[1] = ld32(0x06071144u);  // 06071098 mov.l 0x06071144,r1
    st32(c.r[1], c.r[2]);  // 0607109A mov.l r2,@r1
    c.r[1] = c.r[13];  // 0607109C mov r13,r1
    c.r[1] <<= 2;  // 0607109E shll2 r1
    c.r[2] = ld32(0x06071154u);  // 060710A0 mov.l 0x06071154,r2
    c.r[2] += c.r[1];  // 060710A2 add r1,r2
    c.r[3] = ld32(c.r[2]); c.r[2] += 4;  // 060710A4 mov.l @r2+,r3
    c.r[1] = ld32(0x06071158u);  // 060710A6 mov.l 0x06071158,r1
    c.r[0] = c.r[3];  // 060710A8 mov r3,r0
    c.r[0] >>= 16;  // 060710AA shlr16 r0
    c.r[0] >>= 8;  // 060710AC shlr8 r0
    st8(c.r[1], c.r[0]);  // 060710AE mov.b r0,@r1
    c.r[1] += 1;  // 060710B0 add #1,r1
    c.r[0] = c.r[3];  // 060710B2 mov r3,r0
    c.r[0] >>= 16;  // 060710B4 shlr16 r0
    st8(c.r[1], c.r[0]);  // 060710B6 mov.b r0,@r1
    c.r[1] += 1;  // 060710B8 add #1,r1
    c.r[0] = c.r[3];  // 060710BA mov r3,r0
    c.r[0] >>= 8;  // 060710BC shlr8 r0
    st8(c.r[1], c.r[0]);  // 060710BE mov.b r0,@r1
    c.r[1] += 1;  // 060710C0 add #1,r1
    st8(c.r[1], c.r[3]);  // 060710C2 mov.b r3,@r1
    c.r[3] = ld32(c.r[2]); c.r[2] += 4;  // 060710C4 mov.l @r2+,r3
    c.r[1] = ld32(0x0607115Cu);  // 060710C6 mov.l 0x0607115C,r1
    c.r[0] = c.r[3];  // 060710C8 mov r3,r0
    c.r[0] >>= 16;  // 060710CA shlr16 r0
    c.r[0] >>= 8;  // 060710CC shlr8 r0
    st8(c.r[1], c.r[0]);  // 060710CE mov.b r0,@r1
    c.r[1] += 1;  // 060710D0 add #1,r1
    c.r[0] = c.r[3];  // 060710D2 mov r3,r0
    c.r[0] >>= 16;  // 060710D4 shlr16 r0
    st8(c.r[1], c.r[0]);  // 060710D6 mov.b r0,@r1
    c.r[1] += 1;  // 060710D8 add #1,r1
    c.r[0] = c.r[3];  // 060710DA mov r3,r0
    c.r[0] >>= 8;  // 060710DC shlr8 r0
    st8(c.r[1], c.r[0]);  // 060710DE mov.b r0,@r1
    c.r[1] += 1;  // 060710E0 add #1,r1
    st8(c.r[1], c.r[3]);  // 060710E2 mov.b r3,@r1
L_060710E4:
    c.r[0] = c.r[11];  // 060710E4 mov r11,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060710E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060710E8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060710EA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060710EC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060710EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060710F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060710F2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060710F4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060710F6 rts ; nop
}

void f_060710FA(SH2Context& c) {
    ran[1590] = 1;
    c.t = (c.r[13] & c.r[13]) == 0;  // 060710FA tst r13,r13
    if (!c.t) { goto L_06071102; }  // 060710FC bf 0x06071102
    { const uint32_t x = c.pr; c.r[6] = 0x9u; c.pc = x; return; }  // 060710FE rts ; mov #9,r6
L_06071102:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06071102 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071104 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06071106 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06071108 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 0607110A mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 0607110C mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0607110E mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06071110 sts.l pr,@-r15
    c.pr = 0x06071116u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, 0x06070F44u); if (c.pc != 0x06071116u) return;  // 06071112 bsr 0x06070F44 ; mov #0,r4
    c.r[1] = ld32(0x06071144u);  // 06071116 mov.l 0x06071144,r1
    c.r[6] = ld32(c.r[1]);  // 06071118 mov.l @r1,r6
    c.r[6] -= 7;  // 0607111A add #-7,r6
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607111C lds.l @r15+,pr
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 0607111E mov.l @r15+,r7
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 06071120 mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 06071122 mov.l @r15+,r4
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 06071124 mov.l @r15+,r3
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 06071126 mov.l @r15+,r2
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 06071128 mov.l @r15+,r1
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 0607112A mov.l @r15+,r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0607112C rts ; nop
}

void f_060712A4(SH2Context& c) {
    ran[1591] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060712A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060712A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060712A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060712AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060712AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060712AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060712B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060712B2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06071362u);  // 060712B4 mov.w 0x06071362,r3
    c.r[1] = ld32(0x0607136Cu);  // 060712B6 mov.l 0x0607136C,r1
    c.r[1] = ld32(c.r[1]);  // 060712B8 mov.l @r1,r1
    c.r[15] += c.r[3];  // 060712BA add r3,r15
    c.r[1] += 1;  // 060712BC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060712BE mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060712C0 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060712C2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060712CC; } }  // 060712C4 bt/s 0x060712CC ; mov r15,r14
    c.r[1] = ld32(0x06071370u);  // 060712C8 mov.l 0x06071370,r1
    st8(c.r[1], c.r[2]);  // 060712CA mov.b r2,@r1
L_060712CC:
    c.r[1] = ld32(0x06071370u);  // 060712CC mov.l 0x06071370,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060712CE mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071364u);  // 060712D0 mov.w 0x06071364,r12
    c.r[12] += c.r[14];  // 060712D2 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060712D4 extu.b r1,r1
    c.r[0] = c.r[1];  // 060712D6 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 060712D8 cmp/eq #4,r0
    c.r[0] = 0x1u;  // 060712DA mov #1,r0
    { const bool k = !c.t; st32(c.r[12], c.r[0]); if (k) { goto L_060712E8; } }  // 060712DC bf/s 0x060712E8 ; mov.l r0,@r12
    c.r[0] = 0x0u;  // 060712E0 mov #0,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071364u);  // 060712E2 mov.w 0x06071364,r12
    c.r[12] += c.r[14];  // 060712E4 add r14,r12
    st32(c.r[12], c.r[0]);  // 060712E6 mov.l r0,@r12
L_060712E8:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071364u);  // 060712E8 mov.w 0x06071364,r12
    c.r[12] += c.r[14];  // 060712EA add r14,r12
    c.r[1] = ld32(0x06071374u);  // 060712EC mov.l 0x06071374,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060712F2u; c.r[4] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060712F2u) return; }  // 060712EE jsr @r1 ; mov.l @r12,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071364u);  // 060712F2 mov.w 0x06071364,r0
    c.r[0] += c.r[14];  // 060712F4 add r14,r0
    c.r[1] = ld32(0x06071378u);  // 060712F6 mov.l 0x06071378,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060712FCu; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060712FCu) return; }  // 060712F8 jsr @r1 ; mov.l @r0,r4
    c.r[1] = ld32(0x0607137Cu);  // 060712FC mov.l 0x0607137C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071302u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071302u) return; }  // 060712FE jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x06071366u);  // 06071302 mov.w 0x06071366,r4
    c.r[8] = ld32(0x06071380u);  // 06071304 mov.l 0x06071380,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607130Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607130Au) return; }  // 06071306 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0607130Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607130Eu) return; }  // 0607130A jsr @r8 ; mov #0,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071364u);  // 0607130E mov.w 0x06071364,r12
    c.r[12] += c.r[14];  // 06071310 add r14,r12
    c.r[4] = ld32(c.r[12]);  // 06071312 mov.l @r12,r4
    c.r[4] <<= 2;  // 06071314 shll2 r4
    c.r[4] += c.r[4];  // 06071316 add r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607131Cu; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607131Cu) return; }  // 06071318 jsr @r8 ; shll2 r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06071368u);  // 0607131C mov.w 0x06071368,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06071322u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071322u) return; }  // 0607131E jsr @r8 ; nop
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071364u);  // 06071322 mov.w 0x06071364,r0
    c.r[0] += c.r[14];  // 06071324 add r14,r0
    { const uint32_t x = c.r[8]; c.pr = 0x0607132Au; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607132Au) return; }  // 06071326 jsr @r8 ; mov.l @r0,r4
    c.r[1] = ld32(0x06071384u);  // 0607132A mov.l 0x06071384,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071330u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071330u) return; }  // 0607132C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06071388u);  // 06071330 mov.l 0x06071388,r1
    c.r[1] = ld32(c.r[1]);  // 06071332 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607136Au);  // 06071334 mov.w 0x0607136A,r2
    c.r[0] = c.r[1];  // 06071336 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06071338 mov.b @(r0,r2),r7
    c.r[1] = ld32(0x0607138Cu);  // 0607133A mov.l 0x0607138C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607133C mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607133E extu.b r1,r3
    c.r[1] = ld32(0x06071390u);  // 06071340 mov.l 0x06071390,r1
    c.r[0] = c.r[3];  // 06071342 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06071344 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06071346 extu.b r1,r1
    c.r[1] -= 1;  // 06071348 add #-1,r1
    c.r[3] = 0xBu;  // 0607134A mov #11,r3
    c.macl = c.r[1] * c.r[3];  // 0607134C mul.l r3,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0607134E extu.b r7,r2
    c.r[1] = c.macl;  // 06071350 sts macl,r1
    c.r[2] -= c.r[1];  // 06071352 sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06071354 cmp/gt r3,r2
    { const bool k = c.t; c.r[12] = c.r[7]; if (k) { goto L_06071394; } }  // 06071356 bt/s 0x06071394 ; mov r7,r12
    c.r[12] -= c.r[1];  // 0607135A sub r1,r12
    c.r[1] = c.r[12];  // 0607135C mov r12,r1
    c.r[4] = c.r[1] & 0xFFu; goto L_06071396;  // 0607135E bra 0x06071396 ; extu.b r1,r4
L_06071394:
    c.r[4] = c.r[3];  // 06071394 mov r3,r4
L_06071396:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071510u);  // 06071396 mov.w 0x06071510,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06071398 mov.l r4,@(r0,r14)
    c.r[13] = (uint32_t)(int16_t)ld16(0x06071512u);  // 0607139A mov.w 0x06071512,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071510u);  // 0607139C mov.w 0x06071510,r12
    c.r[12] += c.r[14];  // 0607139E add r14,r12
    c.r[7] = 0x24u;  // 060713A0 mov #36,r7
    c.r[6] = 0x4u;  // 060713A2 mov #4,r6
    c.r[5] = 0x1u;  // 060713A4 mov #1,r5
    c.r[1] = ld32(c.r[12]);  // 060713A6 mov.l @r12,r1
    c.r[1] += c.r[1];  // 060713A8 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060713AA extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060713AC mov.l r1,@-r15
    c.r[1] = ld32(0x06071520u);  // 060713AE mov.l 0x06071520,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060713B4u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060713B4u) return; }  // 060713B0 jsr @r1 ; mov r13,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06071514u);  // 060713B4 mov.w 0x06071514,r4
    c.r[0] = ld32(0x06071524u);  // 060713B6 mov.l 0x06071524,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060713BCu; c.r[8] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060713BCu) return; }  // 060713B8 jsr @r0 ; mov #1,r8
    c.r[12] = ld32(0x06071524u);  // 060713BC mov.l 0x06071524,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060713C2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060713C2u) return; }  // 060713BE jsr @r12 ; mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071516u);  // 060713C2 mov.w 0x06071516,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 060713C4 mov.l @(r0,r14),r4
    c.r[4] <<= 2;  // 060713C6 shll2 r4
    c.r[4] += c.r[4];  // 060713C8 add r4,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060713CEu; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060713CEu) return; }  // 060713CA jsr @r12 ; shll2 r4
    c.r[9] = ld32(0x06071528u);  // 060713CE mov.l 0x06071528,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071518u);  // 060713D0 mov.w 0x06071518,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607151Au);  // 060713D2 mov.w 0x0607151A,r12
    c.r[12] += c.r[14];  // 060713D4 add r14,r12
    c.r[7] = 0x2u;  // 060713D6 mov #2,r7
    c.r[1] = ld32(c.r[9]);  // 060713D8 mov.l @r9,r1
    c.r[6] = 0xFu;  // 060713DA mov #15,r6
    st32(c.r[12], c.r[0]);  // 060713DC mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607151Au);  // 060713DE mov.w 0x0607151A,r12
    c.r[12] += c.r[14];  // 060713E0 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060713E2 mov.l @r12,r0
    c.r[5] = 0x5u;  // 060713E4 mov #5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060713E6 mov.b @(r0,r1),r1
    c.r[4] = 0x6u;  // 060713E8 mov #6,r4
    c.r[1] = c.r[1] & 0xFFu;  // 060713EA extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060713EC mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060713EE mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060713F0 mov.l r8,@-r15
    c.r[1] = 0x0u;  // 060713F2 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060713F4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060713F6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060713F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060713FA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060713FC mov.l r1,@-r15
    c.r[0] = 0xBu;  // 060713FE mov #11,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06071400 mov.l r0,@-r15
    c.r[1] = ld32(0x0607152Cu);  // 06071402 mov.l 0x0607152C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071408u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071408u) return; }  // 06071404 jsr @r1 ; mov.l r8,@-r15
    c.r[15] += 44;  // 06071408 add #44,r15
    c.r[1] = ld32(0x06071530u);  // 0607140A mov.l 0x06071530,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071410u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071410u) return; }  // 0607140C jsr @r1 ; mov r8,r4
    c.r[11] = ld32(0x06071534u);  // 06071410 mov.l 0x06071534,r11
    c.r[10] = ld32(0x06071538u);  // 06071412 mov.l 0x06071538,r10
    c.r[8] = ld32(0x0607153Cu);  // 06071414 mov.l 0x0607153C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06071416 mov.b @r11,r1
    c.r[5] = 0x0u;  // 06071418 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607141A extu.b r1,r1
    c.r[0] = c.r[1];  // 0607141C mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607141E mov.b @(r0,r10),r6
    c.r[4] = 0x0u;  // 06071420 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06071426u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071426u) return; }  // 06071422 jsr @r8 ; extu.b r6,r6
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607151Au);  // 06071426 mov.w 0x0607151A,r12
    c.r[1] = ld32(c.r[9]);  // 06071428 mov.l @r9,r1
    c.r[12] += c.r[14];  // 0607142A add r14,r12
    c.r[0] = ld32(c.r[12]);  // 0607142C mov.l @r12,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607142E mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06071430 extu.b r2,r2
    c.r[2] += 10;  // 06071432 add #10,r2
    c.r[1] = ld32(0x06071540u);  // 06071434 mov.l 0x06071540,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06071436 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06071438 mov #0,r5
    c.r[4] = 0x0u;  // 0607143A mov #0,r4
    c.r[6] = c.mach;  // 0607143C sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0607143E shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06071440 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06071442 subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06071448u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071448u) return; }  // 06071444 jsr @r8 ; sub r2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06071448 mov.b @r11,r1
    c.r[12] = 0xBu;  // 0607144A mov #11,r12
    c.r[2] = c.r[1] & 0xFFu;  // 0607144C extu.b r1,r2
    c.r[0] = c.r[2];  // 0607144E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06071450 mov.b @(r0,r10),r1
    c.r[6] = c.r[13];  // 06071452 mov r13,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06071454 extu.b r1,r1
    c.r[1] -= 1;  // 06071456 add #-1,r1
    c.macl = c.r[1] * c.r[12];  // 06071458 mul.l r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607151Cu);  // 0607145A mov.w 0x0607151C,r0
    c.r[0] += c.r[14];  // 0607145C add r14,r0
    c.r[12] = c.macl;  // 0607145E sts macl,r12
    st32(c.r[0], c.r[12]);  // 06071460 mov.l r12,@r0
    c.r[1] = ld32(0x06071544u);  // 06071462 mov.l 0x06071544,r1
    c.r[0] = c.r[2];  // 06071464 mov r2,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607151Cu);  // 06071466 mov.w 0x0607151C,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06071468 mov.b @(r0,r1),r1
    c.r[12] += c.r[14];  // 0607146A add r14,r12
    c.r[0] = ld32(c.r[12]);  // 0607146C mov.l @r12,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607146E extu.b r1,r1
    c.r[0] += c.r[1];  // 06071470 add r1,r0
    st32(c.r[12], c.r[0]);  // 06071472 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607151Cu);  // 06071474 mov.w 0x0607151C,r12
    c.r[12] += c.r[14];  // 06071476 add r14,r12
    c.r[2] = ld32(c.r[12]);  // 06071478 mov.l @r12,r2
    c.r[4] = c.r[14];  // 0607147A mov r14,r4
    c.r[1] = ld32(c.r[9]);  // 0607147C mov.l @r9,r1
    c.r[2] += c.r[2];  // 0607147E add r2,r2
    c.r[0] = c.r[1];  // 06071480 mov r1,r0
    c.r[12] = 0x7Fu;  // 06071482 mov #127,r12
    c.r[1] += c.r[2];  // 06071484 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06071486 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06071488 add #1,r1
    c.r[3] &= c.r[12];  // 0607148A and r12,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607148C mov.b @r1,r2
    c.r[3] <<= 8;  // 0607148E shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06071490 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06071492 or r3,r2
    c.r[1] = ld32(0x06071548u);  // 06071494 mov.l 0x06071548,r1
    c.r[1] = ld32(c.r[1]);  // 06071496 mov.l @r1,r1
    c.r[2] <<= 2;  // 06071498 shll2 r2
    c.r[2] <<= 2;  // 0607149A shll2 r2
    c.r[2] += c.r[1];  // 0607149C add r1,r2
    c.r[2] += 2;  // 0607149E add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060714A0 mov.b @r2,r5
    c.r[1] = ld32(0x0607154Cu);  // 060714A2 mov.l 0x0607154C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060714A8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714A8u) return; }  // 060714A4 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 060714A8 mov r14,r1
    c.r[1] += 14;  // 060714AA add #14,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607151Eu);  // 060714AC mov.w 0x0607151E,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060714AE mov.b @r1,r5
    c.r[4] += c.r[14];  // 060714B0 add r14,r4
    c.r[1] = ld32(0x06071550u);  // 060714B2 mov.l 0x06071550,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060714B8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714B8u) return; }  // 060714B4 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06071554u);  // 060714B8 mov.l 0x06071554,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060714BA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060714BC extu.b r1,r1
    c.r[0] = c.r[1];  // 060714BE mov r1,r0
    c.t = c.r[0] == 0x3u;  // 060714C0 cmp/eq #3,r0
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_060714CC; } }  // 060714C2 bt/s 0x060714CC ; cmp/eq #4,r0
    if (!c.t) { goto L_06071564; }  // 060714C6 bf 0x06071564
    goto L_060714EE;  // 060714C8 bra 0x060714EE ; nop
L_060714CC:
    c.r[12] = ld32(0x06071524u);  // 060714CC mov.l 0x06071524,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060714D2u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714D2u) return; }  // 060714CE jsr @r12 ; mov #6,r4
    c.r[4] = ld32(0x06071558u);  // 060714D2 mov.l 0x06071558,r4
    c.r[8] = ld32(0x0607155Cu);  // 060714D4 mov.l 0x0607155C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060714DAu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714DAu) return; }  // 060714D6 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 060714DA mov r0,r1
    c.r[5] = 0x8u;  // 060714DC mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060714E2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714E2u) return; }  // 060714DE jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 060714E2 mov r0,r2
    c.r[1] = ld32(0x06071560u);  // 060714E4 mov.l 0x06071560,r1
    c.r[6] = 0x0u;  // 060714E6 mov #0,r6
    c.r[5] = 0x6u;  // 060714E8 mov #6,r5
    c.r[4] = c.r[2]; goto L_06071588;  // 060714EA bra 0x06071588 ; mov r2,r4
L_060714EE:
    c.r[0] = ld32(0x06071524u);  // 060714EE mov.l 0x06071524,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060714F4u; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714F4u) return; }  // 060714F0 jsr @r0 ; mov #9,r4
    c.r[4] = ld32(0x06071558u);  // 060714F4 mov.l 0x06071558,r4
    c.r[8] = ld32(0x0607155Cu);  // 060714F6 mov.l 0x0607155C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060714FCu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060714FCu) return; }  // 060714F8 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 060714FC mov r0,r1
    c.r[5] = 0x8u;  // 060714FE mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071504u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071504u) return; }  // 06071500 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06071504 mov r0,r2
    c.r[1] = ld32(0x06071560u);  // 06071506 mov.l 0x06071560,r1
    c.r[6] = 0x0u;  // 06071508 mov #0,r6
    c.r[5] = 0x8u;  // 0607150A mov #8,r5
    c.r[4] = c.r[2]; goto L_06071588;  // 0607150C bra 0x06071588 ; mov r2,r4
L_06071564:
    c.r[1] = ld32(0x060716B8u);  // 06071564 mov.l 0x060716B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607156Au; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607156Au) return; }  // 06071566 jsr @r1 ; mov #10,r4
    c.r[1] = ld32(0x060716BCu);  // 0607156A mov.l 0x060716BC,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607156C mov.b @r1,r8
    c.r[4] = ld32(0x060716C0u);  // 0607156E mov.l 0x060716C0,r4
    c.r[9] = ld32(0x060716C4u);  // 06071570 mov.l 0x060716C4,r9
    c.r[5] = 0x17u;  // 06071572 mov #23,r5
    c.r[8] += 3;  // 06071574 add #3,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0607157Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607157Au) return; }  // 06071576 jsr @r9 ; extu.b r8,r8
    c.r[5] = 0x8u;  // 0607157A mov #8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06071580u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071580u) return; }  // 0607157C jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x060716C8u);  // 06071580 mov.l 0x060716C8,r1
    c.r[6] = 0x0u;  // 06071582 mov #0,r6
    c.r[5] = c.r[8];  // 06071584 mov r8,r5
    c.r[4] = c.r[0];  // 06071586 mov r0,r4
L_06071588:
    { const uint32_t x = c.r[1]; c.pr = 0x0607158Cu; c.r[12] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607158Cu) return; }  // 06071588 jsr @r1 ; mov #16,r12
    c.r[1] = ld32(0x060716CCu);  // 0607158C mov.l 0x060716CC,r1
    c.r[2] = ld32(c.r[1]);  // 0607158E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060716AEu);  // 06071590 mov.w 0x060716AE,r1
    c.r[0] = c.r[2];  // 06071592 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06071594 mov.b @(r0,r1),r1
    c.r[1] &= c.r[12];  // 06071596 and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06071598 tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_060715D4; } }  // 0607159A bf/s 0x060715D4 ; mov #0,r3
    c.r[1] = ld32(0x060716D0u);  // 0607159E mov.l 0x060716D0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060716B0u);  // 060715A0 mov.w 0x060716B0,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 060715A2 mov.l @(r0,r14),r2
    c.r[12] = 0x7Fu;  // 060715A4 mov #127,r12
    c.r[1] = ld32(c.r[1]);  // 060715A6 mov.l @r1,r1
    c.r[2] += c.r[2];  // 060715A8 add r2,r2
    c.r[0] = c.r[1];  // 060715AA mov r1,r0
    c.r[1] += c.r[2];  // 060715AC add r2,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060715AE mov.b @(r0,r2),r7
    c.r[1] += 1;  // 060715B0 add #1,r1
    c.r[7] &= c.r[12];  // 060715B2 and r12,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060715B4 mov.b @r1,r2
    c.r[7] <<= 8;  // 060715B6 shll8 r7
    c.r[2] = c.r[2] & 0xFFu;  // 060715B8 extu.b r2,r2
    c.r[2] |= c.r[7];  // 060715BA or r7,r2
    c.r[1] = ld32(0x060716D4u);  // 060715BC mov.l 0x060716D4,r1
    c.r[1] = ld32(c.r[1]);  // 060715BE mov.l @r1,r1
    c.r[2] <<= 2;  // 060715C0 shll2 r2
    c.r[2] <<= 2;  // 060715C2 shll2 r2
    c.r[2] += c.r[1];  // 060715C4 add r1,r2
    c.r[2] += 7;  // 060715C6 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060715C8 mov.b @r2,r1
    c.r[0] = 0x1u;  // 060715CA mov #1,r0
    c.r[1] >>= 2;  // 060715CC shlr2 r1
    c.r[1] &= c.r[0];  // 060715CE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060715D0 tst r1,r1
    if (c.t) { goto L_060715D6; }  // 060715D2 bt 0x060715D6
L_060715D4:
    c.r[3] = 0x1u;  // 060715D4 mov #1,r3
L_060715D6:
    c.r[12] = (uint32_t)(int16_t)ld16(0x060716B2u);  // 060715D6 mov.w 0x060716B2,r12
    c.r[12] += c.r[14];  // 060715D8 add r14,r12
    st32(c.r[12], c.r[3]);  // 060715DA mov.l r3,@r12
    c.r[1] = ld32(0x060716CCu);  // 060715DC mov.l 0x060716CC,r1
    c.r[1] = ld32(c.r[1]);  // 060715DE mov.l @r1,r1
    c.r[1] += 9;  // 060715E0 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060715E2 mov.b @r1,r1
    c.r[0] = 0x3u;  // 060715E4 mov #3,r0
    c.r[1] >>= 2;  // 060715E6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060715E8 shlr r1
    c.r[1] >>= 2;  // 060715EA shlr2 r1
    c.r[1] &= c.r[0];  // 060715EC and r0,r1
    c.r[0] = c.r[1];  // 060715EE mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060715F0 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_060715FC; } }  // 060715F2 bt/s 0x060715FC ; cmp/eq #2,r0
    if (!c.t) { goto L_060716DC; }  // 060715F6 bf 0x060716DC
    goto L_06071654;  // 060715F8 bra 0x06071654 ; nop
L_060715FC:
    c.r[11] = ld32(0x060716B8u);  // 060715FC mov.l 0x060716B8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06071602u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071602u) return; }  // 060715FE jsr @r11 ; mov #2,r4
    c.r[9] = ld32(0x060716C0u);  // 06071602 mov.l 0x060716C0,r9
    c.r[8] = ld32(0x060716C4u);  // 06071604 mov.l 0x060716C4,r8
    c.r[5] = 0x17u;  // 06071606 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607160Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607160Cu) return; }  // 06071608 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0607160C mov r0,r1
    c.r[5] = 0x8u;  // 0607160E mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071614u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071614u) return; }  // 06071610 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06071614 mov r0,r1
    c.r[10] = ld32(0x060716C8u);  // 06071616 mov.l 0x060716C8,r10
    c.r[6] = 0x0u;  // 06071618 mov #0,r6
    c.r[5] = 0x3u;  // 0607161A mov #3,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06071620u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071620u) return; }  // 0607161C jsr @r10 ; mov r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06071624u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071624u) return; }  // 06071620 jsr @r11 ; mov #4,r4
    c.r[5] = 0x17u;  // 06071624 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607162Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607162Au) return; }  // 06071626 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0607162A mov r0,r1
    c.r[5] = 0x8u;  // 0607162C mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071632u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071632u) return; }  // 0607162E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06071632 mov r0,r1
    c.r[6] = 0x0u;  // 06071634 mov #0,r6
    c.r[5] = 0x0u;  // 06071636 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607163Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607163Cu) return; }  // 06071638 jsr @r10 ; mov r1,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x060716B2u);  // 0607163C mov.w 0x060716B2,r12
    c.r[12] += c.r[14];  // 0607163E add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06071640 mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06071642 tst r12,r12
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06071734; } }  // 06071644 bt/s 0x06071734 ; mov #0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060716B4u);  // 06071648 mov.w 0x060716B4,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607164A mov.b @(r0,r14),r6
    c.r[1] = ld32(0x060716D8u);  // 0607164C mov.l 0x060716D8,r1
    c.r[4] = 0x0u;  // 0607164E mov #0,r4
    c.r[6] = c.r[6] & 0xFFu; goto L_0607173C;  // 06071650 bra 0x0607173C ; extu.b r6,r6
L_06071654:
    c.r[11] = ld32(0x060716B8u);  // 06071654 mov.l 0x060716B8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0607165Au; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607165Au) return; }  // 06071656 jsr @r11 ; mov #4,r4
    c.r[9] = ld32(0x060716C0u);  // 0607165A mov.l 0x060716C0,r9
    c.r[8] = ld32(0x060716C4u);  // 0607165C mov.l 0x060716C4,r8
    c.r[5] = 0x17u;  // 0607165E mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071664u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071664u) return; }  // 06071660 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 06071664 mov r0,r1
    c.r[5] = 0x8u;  // 06071666 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607166Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607166Cu) return; }  // 06071668 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607166C mov r0,r1
    c.r[10] = ld32(0x060716C8u);  // 0607166E mov.l 0x060716C8,r10
    c.r[6] = 0x0u;  // 06071670 mov #0,r6
    c.r[5] = 0x0u;  // 06071672 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06071678u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071678u) return; }  // 06071674 jsr @r10 ; mov r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607167Cu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607167Cu) return; }  // 06071678 jsr @r11 ; mov #4,r4
    c.r[5] = 0x17u;  // 0607167C mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071682u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071682u) return; }  // 0607167E jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 06071682 mov r0,r1
    c.r[5] = 0x8u;  // 06071684 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607168Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607168Au) return; }  // 06071686 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607168A mov r0,r1
    c.r[6] = 0x0u;  // 0607168C mov #0,r6
    c.r[5] = 0x1u;  // 0607168E mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06071694u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071694u) return; }  // 06071690 jsr @r10 ; mov r1,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060716B2u);  // 06071694 mov.w 0x060716B2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06071696 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06071698 tst r0,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06071734; } }  // 0607169A bt/s 0x06071734 ; mov #0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060716B6u);  // 0607169E mov.w 0x060716B6,r1
    c.r[1] += c.r[14];  // 060716A0 add r14,r1
    c.r[1] += 2;  // 060716A2 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060716A4 mov.b @r1,r6
    c.r[4] = 0x0u;  // 060716A6 mov #0,r4
    c.r[1] = ld32(0x060716D8u);  // 060716A8 mov.l 0x060716D8,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_0607173C;  // 060716AA bra 0x0607173C ; extu.b r6,r6
L_060716DC:
    c.r[11] = ld32(0x0607187Cu);  // 060716DC mov.l 0x0607187C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060716E2u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060716E2u) return; }  // 060716DE jsr @r11 ; mov #6,r4
    c.r[9] = ld32(0x06071880u);  // 060716E2 mov.l 0x06071880,r9
    c.r[8] = ld32(0x06071884u);  // 060716E4 mov.l 0x06071884,r8
    c.r[5] = 0x17u;  // 060716E6 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060716ECu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060716ECu) return; }  // 060716E8 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 060716EC mov r0,r1
    c.r[5] = 0x8u;  // 060716EE mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060716F4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060716F4u) return; }  // 060716F0 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060716F4 mov r0,r1
    c.r[10] = ld32(0x06071888u);  // 060716F6 mov.l 0x06071888,r10
    c.r[6] = 0x0u;  // 060716F8 mov #0,r6
    c.r[5] = 0x2u;  // 060716FA mov #2,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06071700u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071700u) return; }  // 060716FC jsr @r10 ; mov r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06071704u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071704u) return; }  // 06071700 jsr @r11 ; mov #4,r4
    c.r[5] = 0x17u;  // 06071704 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607170Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607170Au) return; }  // 06071706 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0607170A mov r0,r1
    c.r[5] = 0x8u;  // 0607170C mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071712u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071712u) return; }  // 0607170E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06071712 mov r0,r1
    c.r[6] = 0x0u;  // 06071714 mov #0,r6
    c.r[5] = 0x0u;  // 06071716 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607171Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607171Cu) return; }  // 06071718 jsr @r10 ; mov r1,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607186Eu);  // 0607171C mov.w 0x0607186E,r12
    c.r[12] += c.r[14];  // 0607171E add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06071720 mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06071722 tst r12,r12
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06071734; } }  // 06071724 bt/s 0x06071734 ; mov #0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071870u);  // 06071728 mov.w 0x06071870,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607172A mov.b @(r0,r14),r6
    c.r[1] = ld32(0x0607188Cu);  // 0607172C mov.l 0x0607188C,r1
    c.r[4] = 0x0u;  // 0607172E mov #0,r4
    c.r[6] = c.r[6] & 0xFFu; goto L_0607173C;  // 06071730 bra 0x0607173C ; extu.b r6,r6
L_06071734:
    c.r[1] = ld32(0x0607188Cu);  // 06071734 mov.l 0x0607188C,r1
    c.r[6] = 0xFFFFFFFFu;  // 06071736 mov #-1,r6
    c.r[5] = 0x0u;  // 06071738 mov #0,r5
    c.r[4] = 0x30u;  // 0607173A mov #48,r4
L_0607173C:
    { const uint32_t x = c.r[1]; c.pr = 0x06071740u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071740u) return; }  // 0607173C jsr @r1 ; nop
    c.r[1] = ld32(0x06071890u);  // 06071740 mov.l 0x06071890,r1
    c.r[1] = ld32(c.r[1]);  // 06071742 mov.l @r1,r1
    c.r[1] += 9;  // 06071744 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071746 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06071748 mov #3,r0
    c.r[1] >>= 2;  // 0607174A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607174C shlr r1
    c.r[1] &= c.r[0];  // 0607174E and r0,r1
    c.r[0] = c.r[1];  // 06071750 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06071752 cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = 0x4u; if (k) { goto L_0607175E; } }  // 06071754 bf/s 0x0607175E ; mov #4,r4
    c.r[1] = ld32(0x0607187Cu);  // 06071758 mov.l 0x0607187C,r1
    goto L_0607176E;  // 0607175A bra 0x0607176E ; nop
L_0607175E:
    c.t = c.r[0] == 0x2u;  // 0607175E cmp/eq #2,r0
    if (!c.t) { goto L_0607176A; }  // 06071760 bf 0x0607176A
    c.r[4] = 0x6u;  // 06071762 mov #6,r4
    c.r[1] = ld32(0x0607187Cu);  // 06071764 mov.l 0x0607187C,r1
    goto L_0607176E;  // 06071766 bra 0x0607176E ; nop
L_0607176A:
    c.r[1] = ld32(0x0607187Cu);  // 0607176A mov.l 0x0607187C,r1
    c.r[4] = 0x6u;  // 0607176C mov #6,r4
L_0607176E:
    { const uint32_t x = c.r[1]; c.pr = 0x06071772u; c.r[12] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071772u) return; }  // 0607176E jsr @r1 ; mov #3,r12
    c.r[1] = ld32(0x06071890u);  // 06071772 mov.l 0x06071890,r1
    c.r[4] = ld32(0x06071880u);  // 06071774 mov.l 0x06071880,r4
    c.r[1] = ld32(c.r[1]);  // 06071776 mov.l @r1,r1
    c.r[8] = ld32(0x06071884u);  // 06071778 mov.l 0x06071884,r8
    c.r[1] += 9;  // 0607177A add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607177C mov.b @r1,r1
    c.r[5] = 0x17u;  // 0607177E mov #23,r5
    c.r[9] = c.r[1];  // 06071780 mov r1,r9
    c.r[9] >>= 2;  // 06071782 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06071784 shlr r9
    { const uint32_t x = c.r[8]; c.pr = 0x0607178Au; c.r[9] &= c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607178Au) return; }  // 06071786 jsr @r8 ; and r12,r9
    c.r[1] = c.r[0];  // 0607178A mov r0,r1
    c.r[5] = 0x9u;  // 0607178C mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071792u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071792u) return; }  // 0607178E jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06071792 mov r0,r2
    c.r[1] = ld32(0x06071888u);  // 06071794 mov.l 0x06071888,r1
    c.r[6] = 0x0u;  // 06071796 mov #0,r6
    c.r[5] = c.r[9];  // 06071798 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607179Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607179Eu) return; }  // 0607179A jsr @r1 ; mov r2,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071872u);  // 0607179E mov.w 0x06071872,r0
    c.r[0] += c.r[14];  // 060717A0 add r14,r0
    c.r[8] = ld32(0x0607187Cu);  // 060717A2 mov.l 0x0607187C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060717A8u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060717A8u) return; }  // 060717A4 jsr @r8 ; mov.l @r0,r4
    c.r[1] = ld32(0x06071894u);  // 060717A8 mov.l 0x06071894,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060717AA mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060717AC extu.b r1,r2
    c.r[1] = ld32(0x06071898u);  // 060717AE mov.l 0x06071898,r1
    c.r[0] = c.r[2];  // 060717B0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060717B2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060717B4 extu.b r1,r1
    c.r[1] -= 1;  // 060717B6 add #-1,r1
    c.r[2] = 0xBu;  // 060717B8 mov #11,r2
    c.macl = c.r[1] * c.r[2];  // 060717BA mul.l r2,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071874u);  // 060717BC mov.w 0x06071874,r12
    c.r[12] += c.r[14];  // 060717BE add r14,r12
    c.r[0] = c.macl;  // 060717C0 sts macl,r0
    st32(c.r[12], c.r[0]);  // 060717C2 mov.l r0,@r12
    c.r[1] = c.macl;  // 060717C4 sts macl,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071872u);  // 060717C6 mov.w 0x06071872,r12
    c.r[12] += c.r[14];  // 060717C8 add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071874u);  // 060717CA mov.w 0x06071874,r0
    c.r[12] = ld32(c.r[12]);  // 060717CC mov.l @r12,r12
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060717CE mov.l @(r0,r14),r0
    c.r[1] += c.r[12];  // 060717D0 add r12,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 060717D2 cmp/ge r1,r0
    { const bool k = !c.t; c.r[11] = c.r[8]; if (k) { goto L_060717DC; } }  // 060717D4 bf/s 0x060717DC ; mov r8,r11
    goto L_06071B7C;  // 060717D8 bra 0x06071B7C ; nop
L_060717DC:
    c.r[13] = ld32(0x0607188Cu);  // 060717DC mov.l 0x0607188C,r13
    c.r[9] = c.macl;  // 060717DE sts macl,r9
    c.r[9] += c.r[9];  // 060717E0 add r9,r9
L_060717E2:
    c.r[12] = ld32(0x0607189Cu);  // 060717E2 mov.l 0x0607189C,r12
    c.r[3] = 0x7Fu;  // 060717E4 mov #127,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06071876u);  // 060717E6 mov.w 0x06071876,r6
    c.r[1] = ld32(c.r[12]);  // 060717E8 mov.l @r12,r1
    c.r[4] = c.r[14];  // 060717EA mov r14,r4
    c.r[0] = c.r[1];  // 060717EC mov r1,r0
    c.r[1] += c.r[9];  // 060717EE add r9,r1
    c.r[1] += 1;  // 060717F0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060717F2 mov.b @(r0,r9),r2
    c.r[12] = ld32(0x060718A0u);  // 060717F4 mov.l 0x060718A0,r12
    c.r[3] &= c.r[2];  // 060717F6 and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060717F8 mov.b @r1,r2
    c.r[3] <<= 8;  // 060717FA shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 060717FC extu.b r2,r2
    c.r[2] |= c.r[3];  // 060717FE or r3,r2
    c.r[1] = ld32(c.r[12]);  // 06071800 mov.l @r12,r1
    c.r[2] <<= 2;  // 06071802 shll2 r2
    c.r[2] <<= 2;  // 06071804 shll2 r2
    c.r[2] += c.r[1];  // 06071806 add r1,r2
    c.r[2] += 2;  // 06071808 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607180A mov.b @r2,r5
    c.r[1] = ld32(0x060718A4u);  // 0607180C mov.l 0x060718A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071812u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071812u) return; }  // 0607180E jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 06071812 mov r14,r1
    c.r[1] += 14;  // 06071814 add #14,r1
    c.r[2] = ld32(0x060718A8u);  // 06071816 mov.l 0x060718A8,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071818 mov.b @r1,r5
    c.r[4] = c.r[14];  // 0607181A mov r14,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0607181C extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071878u);  // 0607181E mov.w 0x06071878,r1
    { const uint32_t x = c.r[2]; c.pr = 0x06071824u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071824u) return; }  // 06071820 jsr @r2 ; add r1,r4
    c.r[1] = ld32(0x060718ACu);  // 06071824 mov.l 0x060718AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607182Au; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607182Au) return; }  // 06071826 jsr @r1 ; mov #2,r4
    c.r[0] = ld32(0x0607189Cu);  // 0607182A mov.l 0x0607189C,r0
    c.r[1] = ld32(c.r[0]);  // 0607182C mov.l @r0,r1
    c.r[3] = 0x7Fu;  // 0607182E mov #127,r3
    c.r[0] = c.r[1];  // 06071830 mov r1,r0
    c.r[1] += c.r[9];  // 06071832 add r9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06071834 mov.b @(r0,r9),r2
    c.r[1] += 1;  // 06071836 add #1,r1
    c.r[3] &= c.r[2];  // 06071838 and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607183A mov.b @r1,r2
    c.r[3] <<= 8;  // 0607183C shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607183E extu.b r2,r2
    c.r[2] |= c.r[3];  // 06071840 or r3,r2
    c.r[1] = ld32(c.r[12]);  // 06071842 mov.l @r12,r1
    c.r[2] <<= 2;  // 06071844 shll2 r2
    c.r[2] <<= 2;  // 06071846 shll2 r2
    c.r[2] += c.r[1];  // 06071848 add r1,r2
    c.r[2] += 4;  // 0607184A add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607184C mov.b @r2,r1
    c.r[12] = 0x1u;  // 0607184E mov #1,r12
    c.r[1] >>= 2;  // 06071850 shlr2 r1
    c.r[1] >>= 2;  // 06071852 shlr2 r1
    c.r[1] >>= 2;  // 06071854 shlr2 r1
    c.r[1] &= c.r[12];  // 06071856 and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06071858 tst r1,r1
    if (c.t) { goto L_060718B4; }  // 0607185A bt 0x060718B4
    c.r[1] = ld32(0x060718B0u);  // 0607185C mov.l 0x060718B0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607185E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06071860 extu.b r1,r0
    c.t = c.r[0] == 0x4u;  // 06071862 cmp/eq #4,r0
    if (c.t) { goto L_060718B4; }  // 06071864 bt 0x060718B4
    { const uint32_t x = c.r[11]; c.pr = 0x0607186Au; c.r[4] = 0x39u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607186Au) return; }  // 06071866 jsr @r11 ; mov #57,r4
    c.r[4] = 0x3Au; goto L_060718BA;  // 0607186A bra 0x060718BA ; mov #58,r4
L_060718B4:
    { const uint32_t x = c.r[11]; c.pr = 0x060718B8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060718B8u) return; }  // 060718B4 jsr @r11 ; mov #0,r4
    c.r[4] = 0x0u;  // 060718B8 mov #0,r4
L_060718BA:
    { const uint32_t x = c.r[11]; c.pr = 0x060718BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060718BEu) return; }  // 060718BA jsr @r11 ; nop
    c.r[1] = ld32(0x06071A74u);  // 060718BE mov.l 0x06071A74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060718C4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060718C4u) return; }  // 060718C0 jsr @r1 ; mov #1,r4
    c.r[1] = c.r[14];  // 060718C4 mov r14,r1
    c.r[1] += 24;  // 060718C6 add #24,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060718C8 mov.w @r1,r3
    c.r[2] = c.r[3] & 0xFFFFu;  // 060718CA extu.w r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060718CC tst r2,r2
    { const bool k = c.t; c.r[8] = 0x8u; if (k) { goto L_060718F0; } }  // 060718CE bt/s 0x060718F0 ; mov #8,r8
    c.r[1] = c.r[14];  // 060718D2 mov r14,r1
    c.r[1] += 28;  // 060718D4 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060718D6 mov.w @r1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 060718D8 extu.w r1,r5
    c.t = c.r[2] == c.r[5];  // 060718DA cmp/eq r5,r2
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_060718F0; } }  // 060718DC bt/s 0x060718F0 ; mov #0,r8
    c.r[1] = 0x7u;  // 060718E0 mov #7,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060718E2 mulu.w r1,r3
    c.r[7] = ld32(0x06071A78u);  // 060718E4 mov.l 0x06071A78,r7
    { const uint32_t x = c.r[7]; c.pr = 0x060718EAu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060718EAu) return; }  // 060718E6 jsr @r7 ; sts macl,r4
    c.r[1] = 0u - c.r[0];  // 060718EA neg r0,r1
    c.r[1] += 7;  // 060718EC add #7,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060718EE extu.b r1,r8
L_060718F0:
    c.r[1] = ld32(0x06071A7Cu);  // 060718F0 mov.l 0x06071A7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060718F2 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060718F4 extu.b r1,r0
    c.t = c.r[0] == 0x4u;  // 060718F6 cmp/eq #4,r0
    { const bool k = c.t; c.r[8] += c.r[8]; if (k) { goto L_0607190C; } }  // 060718F8 bt/s 0x0607190C ; add r8,r8
    c.r[4] = c.r[8];  // 060718FC mov r8,r4
    c.r[4] -= 128;  // 060718FE add #-128,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06071904u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071904u) return; }  // 06071900 jsr @r11 ; extu.b r4,r4
    c.r[8] -= 127;  // 06071904 add #-127,r8
    c.r[8] = c.r[8] & 0xFFu;  // 06071906 extu.b r8,r8
    c.r[4] = c.r[8]; goto L_06071912;  // 06071908 bra 0x06071912 ; mov r8,r4
L_0607190C:
    { const uint32_t x = c.r[11]; c.pr = 0x06071910u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071910u) return; }  // 0607190C jsr @r11 ; mov #0,r4
    c.r[4] = 0x0u;  // 06071910 mov #0,r4
L_06071912:
    { const uint32_t x = c.r[11]; c.pr = 0x06071916u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071916u) return; }  // 06071912 jsr @r11 ; nop
    c.r[0] = ld32(0x06071A80u);  // 06071916 mov.l 0x06071A80,r0
    c.r[3] = 0x7Fu;  // 06071918 mov #127,r3
    c.r[1] = ld32(c.r[0]);  // 0607191A mov.l @r0,r1
    c.r[12] = ld32(0x06071A84u);  // 0607191C mov.l 0x06071A84,r12
    c.r[0] = c.r[1];  // 0607191E mov r1,r0
    c.r[1] += c.r[9];  // 06071920 add r9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06071922 mov.b @(r0,r9),r2
    c.r[1] += 1;  // 06071924 add #1,r1
    c.r[3] &= c.r[2];  // 06071926 and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071928 mov.b @r1,r2
    c.r[3] <<= 8;  // 0607192A shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607192C extu.b r2,r2
    c.r[2] |= c.r[3];  // 0607192E or r3,r2
    c.r[1] = ld32(c.r[12]);  // 06071930 mov.l @r12,r1
    c.r[2] <<= 2;  // 06071932 shll2 r2
    c.r[2] <<= 2;  // 06071934 shll2 r2
    c.r[2] += c.r[1];  // 06071936 add r1,r2
    c.r[2] += 7;  // 06071938 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607193A mov.b @r2,r1
    c.r[0] = 0x1u;  // 0607193C mov #1,r0
    c.r[1] >>= 2;  // 0607193E shlr2 r1
    c.r[1] >>= 2;  // 06071940 shlr2 r1
    c.r[1] &= c.r[0];  // 06071942 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06071944 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_06071956; } }  // 06071946 bt/s 0x06071956 ; mov #0,r4
    c.r[1] = ld32(0x06071A7Cu);  // 0607194A mov.l 0x06071A7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607194C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607194E extu.b r1,r0
    c.t = c.r[0] == 0x4u;  // 06071950 cmp/eq #4,r0
    if (c.t) { goto L_06071956; }  // 06071952 bt 0x06071956
    c.r[4] = 0x2Du;  // 06071954 mov #45,r4
L_06071956:
    { const uint32_t x = c.r[11]; c.pr = 0x0607195Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607195Au) return; }  // 06071956 jsr @r11 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071A68u);  // 0607195A mov.w 0x06071A68,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0607195C mov.w @r14,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06071A6Au);  // 0607195E mov.w 0x06071A6A,r5
    c.r[4] += c.r[1];  // 06071960 add r1,r4
    c.r[1] = ld32(0x06071A88u);  // 06071962 mov.l 0x06071A88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071968u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071968u) return; }  // 06071964 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x06071A8Cu);  // 06071968 mov.l 0x06071A8C,r1
    c.r[2] = ld32(c.r[1]);  // 0607196A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0607196C mov r2,r1
    c.r[1] += 9;  // 0607196E add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071970 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06071972 mov r1,r0
    c.r[0] >>= 2;  // 06071974 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06071976 shlr r0
    c.r[0] >>= 2;  // 06071978 shlr2 r0
    c.r[0] &= 0x3u;  // 0607197A and #3,r0
    c.t = c.r[0] == 0x1u;  // 0607197C cmp/eq #1,r0
    if (!c.t) { goto L_06071984; }  // 0607197E bf 0x06071984
    goto L_06071A9C;  // 06071980 bra 0x06071A9C ; nop
L_06071984:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071A6Cu);  // 06071984 mov.w 0x06071A6C,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06071986 mov.b @(r0,r2),r0
    c.r[0] &= 0x10u;  // 06071988 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607198A tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_060719C0; } }  // 0607198C bf/s 0x060719C0 ; mov #0,r3
    c.r[12] = ld32(0x06071A80u);  // 06071990 mov.l 0x06071A80,r12
    c.r[1] = ld32(c.r[12]);  // 06071992 mov.l @r12,r1
    c.r[7] = 0x7Fu;  // 06071994 mov #127,r7
    c.r[0] = c.r[1];  // 06071996 mov r1,r0
    c.r[1] += c.r[9];  // 06071998 add r9,r1
    c.r[1] += 1;  // 0607199A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607199C mov.b @(r0,r9),r2
    c.r[12] = ld32(0x06071A84u);  // 0607199E mov.l 0x06071A84,r12
    c.r[7] &= c.r[2];  // 060719A0 and r2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060719A2 mov.b @r1,r2
    c.r[7] <<= 8;  // 060719A4 shll8 r7
    c.r[2] = c.r[2] & 0xFFu;  // 060719A6 extu.b r2,r2
    c.r[2] |= c.r[7];  // 060719A8 or r7,r2
    c.r[1] = ld32(c.r[12]);  // 060719AA mov.l @r12,r1
    c.r[2] <<= 2;  // 060719AC shll2 r2
    c.r[2] <<= 2;  // 060719AE shll2 r2
    c.r[2] += c.r[1];  // 060719B0 add r1,r2
    c.r[2] += 7;  // 060719B2 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060719B4 mov.b @r2,r1
    c.r[0] = 0x1u;  // 060719B6 mov #1,r0
    c.r[1] >>= 2;  // 060719B8 shlr2 r1
    c.r[1] &= c.r[0];  // 060719BA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060719BC tst r1,r1
    if (c.t) { goto L_060719C2; }  // 060719BE bt 0x060719C2
L_060719C0:
    c.r[3] = 0x1u;  // 060719C0 mov #1,r3
L_060719C2:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071A6Eu);  // 060719C2 mov.w 0x06071A6E,r12
    c.r[12] += c.r[14];  // 060719C4 add r14,r12
    st32(c.r[12], c.r[3]);  // 060719C6 mov.l r3,@r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071A70u);  // 060719C8 mov.w 0x06071A70,r1
    c.r[10] = c.r[14];  // 060719CA mov r14,r10
    c.r[10] += c.r[1];  // 060719CC add r1,r10
    c.r[0] = c.r[14];  // 060719CE mov r14,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060719D0 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06071A6Au);  // 060719D2 mov.w 0x06071A6A,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071A72u);  // 060719D4 mov.w 0x06071A72,r1
    c.r[4] += c.r[1];  // 060719D6 add r1,r4
    c.r[1] = ld32(0x06071A88u);  // 060719D8 mov.l 0x06071A88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060719DEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060719DEu) return; }  // 060719DA jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x06071A8Cu);  // 060719DE mov.l 0x06071A8C,r1
    c.r[1] = ld32(c.r[1]);  // 060719E0 mov.l @r1,r1
    c.r[1] += 9;  // 060719E2 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060719E4 mov.b @r1,r1
    c.r[12] = 0x3u;  // 060719E6 mov #3,r12
    c.r[1] >>= 2;  // 060719E8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060719EA shlr r1
    c.r[1] >>= 2;  // 060719EC shlr2 r1
    c.r[1] &= c.r[12];  // 060719EE and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060719F0 tst r1,r1
    if (c.t) { goto L_06071A22; }  // 060719F2 bt 0x06071A22
    { const uint32_t x = c.r[11]; c.pr = 0x060719F8u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060719F8u) return; }  // 060719F4 jsr @r11 ; mov #4,r4
    c.r[8] = ld32(0x06071A90u);  // 060719F8 mov.l 0x06071A90,r8
    c.r[4] = ld32(0x06071A94u);  // 060719FA mov.l 0x06071A94,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06071A00u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A00u) return; }  // 060719FC jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06071A00 mov r0,r1
    c.r[5] = 0x8u;  // 06071A02 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071A08u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A08u) return; }  // 06071A04 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06071A08 mov r0,r2
    c.r[1] = ld32(0x06071A98u);  // 06071A0A mov.l 0x06071A98,r1
    c.r[6] = 0x0u;  // 06071A0C mov #0,r6
    c.r[5] = 0x0u;  // 06071A0E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071A14u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A14u) return; }  // 06071A10 jsr @r1 ; mov r2,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071A6Eu);  // 06071A14 mov.w 0x06071A6E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06071A16 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06071A18 tst r0,r0
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_06071A5E; } }  // 06071A1A bt/s 0x06071A5E ; mov #-1,r6
    c.r[10] += 9; goto L_06071A50;  // 06071A1E bra 0x06071A50 ; add #9,r10
L_06071A22:
    { const uint32_t x = c.r[11]; c.pr = 0x06071A26u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A26u) return; }  // 06071A22 jsr @r11 ; mov #4,r4
    c.r[8] = ld32(0x06071A90u);  // 06071A26 mov.l 0x06071A90,r8
    c.r[4] = ld32(0x06071A94u);  // 06071A28 mov.l 0x06071A94,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06071A2Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A2Eu) return; }  // 06071A2A jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06071A2E mov r0,r1
    c.r[5] = 0x8u;  // 06071A30 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071A36u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A36u) return; }  // 06071A32 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06071A36 mov r0,r2
    c.r[1] = ld32(0x06071A98u);  // 06071A38 mov.l 0x06071A98,r1
    c.r[6] = 0x0u;  // 06071A3A mov #0,r6
    c.r[5] = 0x1u;  // 06071A3C mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071A42u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A42u) return; }  // 06071A3E jsr @r1 ; mov r2,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071A6Eu);  // 06071A42 mov.w 0x06071A6E,r12
    c.r[12] += c.r[14];  // 06071A44 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06071A46 mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06071A48 tst r12,r12
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_06071A5E; } }  // 06071A4A bt/s 0x06071A5E ; mov #-1,r6
    c.r[10] += 2;  // 06071A4E add #2,r10
L_06071A50:
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06071A50 mov.b @r10,r6
    c.r[5] = 0x0u;  // 06071A52 mov #0,r5
    c.r[4] = 0x0u;  // 06071A54 mov #0,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06071A5Au; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A5Au) return; }  // 06071A56 jsr @r13 ; extu.b r6,r6
    c.r[9] += 2; goto L_06071B48;  // 06071A5A bra 0x06071B48 ; add #2,r9
L_06071A5E:
    c.r[5] = 0x0u;  // 06071A5E mov #0,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06071A64u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071A64u) return; }  // 06071A60 jsr @r13 ; mov #48,r4
    c.r[9] += 2; goto L_06071B48;  // 06071A64 bra 0x06071B48 ; add #2,r9
L_06071A9C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071BC8u);  // 06071A9C mov.w 0x06071BC8,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06071A9E mov.b @(r0,r2),r0
    c.r[0] &= 0x10u;  // 06071AA0 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06071AA2 tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06071AF6; } }  // 06071AA4 bf/s 0x06071AF6 ; mov #0,r3
    c.r[0] = ld32(0x06071BDCu);  // 06071AA8 mov.l 0x06071BDC,r0
    c.r[7] = 0x7Fu;  // 06071AAA mov #127,r7
    c.r[1] = ld32(c.r[0]);  // 06071AAC mov.l @r0,r1
    c.r[12] = ld32(0x06071BE0u);  // 06071AAE mov.l 0x06071BE0,r12
    c.r[0] = c.r[1];  // 06071AB0 mov r1,r0
    c.r[1] += c.r[9];  // 06071AB2 add r9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06071AB4 mov.b @(r0,r9),r2
    c.r[1] += 1;  // 06071AB6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071AB8 mov.b @r1,r1
    c.r[7] &= c.r[2];  // 06071ABA and r2,r7
    c.r[7] <<= 8;  // 06071ABC shll8 r7
    c.r[2] = c.r[1] & 0xFFu;  // 06071ABE extu.b r1,r2
    c.r[2] |= c.r[7];  // 06071AC0 or r7,r2
    c.r[1] = ld32(c.r[12]);  // 06071AC2 mov.l @r12,r1
    c.r[2] <<= 2;  // 06071AC4 shll2 r2
    c.r[2] <<= 2;  // 06071AC6 shll2 r2
    c.r[2] += c.r[1];  // 06071AC8 add r1,r2
    c.r[1] = c.r[2];  // 06071ACA mov r2,r1
    c.r[1] += 7;  // 06071ACC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071ACE mov.b @r1,r1
    c.r[0] = 0x1u;  // 06071AD0 mov #1,r0
    c.r[1] >>= 2;  // 06071AD2 shlr2 r1
    c.r[1] &= c.r[0];  // 06071AD4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06071AD6 tst r1,r1
    { const bool k = c.t; c.r[2] += 3; if (k) { goto L_06071AF8; } }  // 06071AD8 bt/s 0x06071AF8 ; add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06071ADC mov.b @r2,r1
    c.r[0] = c.r[1];  // 06071ADE mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06071AE0 shlr r0
    c.r[0] &= 0x3u;  // 06071AE2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06071AE4 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06071AF6; } }  // 06071AE6 bt/s 0x06071AF6 ; mov r14,r1
    c.r[1] += 22;  // 06071AEA add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071AEC mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06071BCAu);  // 06071AEE mov.w 0x06071BCA,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06071AF0 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06071AF2 cmp/hi r2,r1
    if (c.t) { goto L_06071AF8; }  // 06071AF4 bt 0x06071AF8
L_06071AF6:
    c.r[3] = 0x1u;  // 06071AF6 mov #1,r3
L_06071AF8:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071BCCu);  // 06071AF8 mov.w 0x06071BCC,r12
    c.r[12] += c.r[14];  // 06071AFA add r14,r12
    st32(c.r[12], c.r[3]);  // 06071AFC mov.l r3,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071BCCu);  // 06071AFE mov.w 0x06071BCC,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06071B00 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06071B02 tst r0,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06071B22; } }  // 06071B04 bt/s 0x06071B22 ; mov #0,r5
    c.r[1] = c.r[14];  // 06071B08 mov r14,r1
    c.r[1] += 22;  // 06071B0A add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071B0C mov.w @r1,r6
    c.r[4] = 0x1u;  // 06071B0E mov #1,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06071B14u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071B14u) return; }  // 06071B10 jsr @r13 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 06071B14 mov r14,r1
    c.r[1] += 26;  // 06071B16 add #26,r1
    c.r[5] = 0x0u;  // 06071B18 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071B1A mov.w @r1,r6
    c.r[4] = 0x1u;  // 06071B1C mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_06071B2E;  // 06071B1E bra 0x06071B2E ; extu.w r6,r6
L_06071B22:
    c.r[6] = 0xFFFFFFFFu;  // 06071B22 mov #-1,r6
    { const uint32_t x = c.r[13]; c.pr = 0x06071B28u; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071B28u) return; }  // 06071B24 jsr @r13 ; mov #81,r4
    c.r[6] = 0xFFFFFFFFu;  // 06071B28 mov #-1,r6
    c.r[5] = 0x0u;  // 06071B2A mov #0,r5
    c.r[4] = 0x51u;  // 06071B2C mov #81,r4
L_06071B2E:
    { const uint32_t x = c.r[13]; c.pr = 0x06071B32u; c.r[9] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071B32u) return; }  // 06071B2E jsr @r13 ; add #2,r9
    c.r[1] = c.r[14];  // 06071B32 mov r14,r1
    c.r[1] += 26;  // 06071B34 add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071B36 mov.w @r1,r5
    c.r[6] = 0xBu;  // 06071B38 mov #11,r6
    c.r[1] = c.r[14];  // 06071B3A mov r14,r1
    c.r[1] += 22;  // 06071B3C add #22,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071B3E mov.w @r1,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06071B40 extu.w r5,r5
    c.r[1] = ld32(0x06071BE4u);  // 06071B42 mov.l 0x06071BE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071B48u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071B48u) return; }  // 06071B44 jsr @r1 ; extu.w r4,r4
L_06071B48:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071BCEu);  // 06071B48 mov.w 0x06071BCE,r12
    c.r[12] += c.r[14];  // 06071B4A add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06071B4C mov.l @r12,r0
    c.r[1] = ld32(0x06071BE8u);  // 06071B4E mov.l 0x06071BE8,r1
    c.r[0] += 1;  // 06071B50 add #1,r0
    st32(c.r[12], c.r[0]);  // 06071B52 mov.l r0,@r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071B54 mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071BD0u);  // 06071B56 mov.w 0x06071BD0,r12
    c.r[2] = c.r[1] & 0xFFu;  // 06071B58 extu.b r1,r2
    c.r[1] = ld32(0x06071BECu);  // 06071B5A mov.l 0x06071BEC,r1
    c.r[0] = c.r[2];  // 06071B5C mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06071B5E mov.b @(r0,r1),r2
    c.r[12] += c.r[14];  // 06071B60 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06071B62 mov.l @r12,r12
    c.r[2] = c.r[2] & 0xFFu;  // 06071B64 extu.b r2,r2
    c.r[2] -= 1;  // 06071B66 add #-1,r2
    c.r[1] = 0xBu;  // 06071B68 mov #11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071BCEu);  // 06071B6A mov.w 0x06071BCE,r0
    c.macl = c.r[2] * c.r[1];  // 06071B6C mul.l r1,r2
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06071B6E mov.l @(r0,r14),r0
    c.r[1] = c.macl;  // 06071B70 sts macl,r1
    c.r[1] += c.r[12];  // 06071B72 add r12,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06071B74 cmp/ge r1,r0
    if (c.t) { goto L_06071B7C; }  // 06071B76 bt 0x06071B7C
    SH2_POLL(c); goto L_060717E2;  // 06071B78 bra 0x060717E2 ; nop
L_06071B7C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06071BD2u);  // 06071B7C mov.w 0x06071BD2,r4
    c.r[8] = ld32(0x06071BF0u);  // 06071B7E mov.l 0x06071BF0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06071B84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071B84u) return; }  // 06071B80 jsr @r8 ; nop
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071BD4u);  // 06071B84 mov.w 0x06071BD4,r12
    c.r[12] += c.r[14];  // 06071B86 add r14,r12
    { const uint32_t x = c.r[8]; c.pr = 0x06071B8Cu; c.r[4] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071B8Cu) return; }  // 06071B88 jsr @r8 ; mov.l @r12,r4
    c.r[1] = ld32(0x06071BF4u);  // 06071B8C mov.l 0x06071BF4,r1
    c.r[1] = ld32(c.r[1]);  // 06071B8E mov.l @r1,r1
    c.r[0] = 0x3u;  // 06071B90 mov #3,r0
    c.r[1] += 9;  // 06071B92 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071B94 mov.b @r1,r1
    c.r[1] >>= 2;  // 06071B96 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06071B98 shlr r1
    c.r[1] >>= 2;  // 06071B9A shlr2 r1
    c.r[1] &= c.r[0];  // 06071B9C and r0,r1
    c.r[0] = c.r[1];  // 06071B9E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06071BA0 cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = 0x1Au; if (k) { goto L_06071BA8; } }  // 06071BA2 bf/s 0x06071BA8 ; mov #26,r4
    c.r[4] = 0x1Bu;  // 06071BA6 mov #27,r4
L_06071BA8:
    c.r[1] = ld32(0x06071BF8u);  // 06071BA8 mov.l 0x06071BF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071BAEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071BAEu) return; }  // 06071BAA jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x06071BD6u);  // 06071BAE mov.w 0x06071BD6,r3
    c.r[14] += c.r[3];  // 06071BB0 add r3,r14
    c.r[15] = c.r[14];  // 06071BB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06071BB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06071BB6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06071BB8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06071BBA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06071BBC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06071BBE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06071BC0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071BD8u);  // 06071BC2 mov.w 0x06071BD8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06071BC4 rts ; mov.l @r15+,r8
}

void f_06071BFC(SH2Context& c) {
    ran[1592] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06071BFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06071BFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06071C00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06071C02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06071C04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06071C06 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06071C08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06071C0A sts.l pr,@-r15
    c.r[15] -= 96;  // 06071C0C add #-96,r15
    c.r[14] = c.r[15];  // 06071C0E mov r15,r14
    c.r[1] = ld32(0x06071D3Cu);  // 06071C10 mov.l 0x06071D3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071C16u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071C16u) return; }  // 06071C12 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06071D40u);  // 06071C16 mov.l 0x06071D40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071C1Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071C1Cu) return; }  // 06071C18 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06071D44u);  // 06071C1C mov.l 0x06071D44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071C22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071C22u) return; }  // 06071C1E jsr @r1 ; nop
    c.r[1] = ld32(0x06071D48u);  // 06071C22 mov.l 0x06071D48,r1
    c.r[2] = ld32(c.r[1]);  // 06071C24 mov.l @r1,r2
    c.r[1] = ld32(0x06071D4Cu);  // 06071C26 mov.l 0x06071D4C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071C28 mov.b @r1,r1
    c.r[4] = c.r[14];  // 06071C2A mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06071C2C extu.b r1,r1
    c.r[1] += c.r[1];  // 06071C2E add r1,r1
    c.r[2] += c.r[1];  // 06071C30 add r1,r2
    c.r[2] += 1;  // 06071C32 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06071C34 mov.b @r2,r5
    c.r[1] = ld32(0x06071D50u);  // 06071C36 mov.l 0x06071D50,r1
    c.r[5] = c.r[5] & 0xFFu;  // 06071C38 extu.b r5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071C3Eu; c.r[8] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071C3Eu) return; }  // 06071C3A jsr @r1 ; mov r5,r8
    c.r[1] = ld32(0x06071D54u);  // 06071C3E mov.l 0x06071D54,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071C40 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06071C42 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06071C44 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_06071C66; } }  // 06071C46 bt/s 0x06071C66 ; extu.b r8,r5
    c.r[1] = ld32(0x06071D58u);  // 06071C4A mov.l 0x06071D58,r1
    c.r[2] = ld32(c.r[1]);  // 06071C4C mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071D32u);  // 06071C4E mov.w 0x06071D32,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071D34u);  // 06071C50 mov.w 0x06071D34,r1
    c.r[2] += c.r[1];  // 06071C52 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06071C54 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06071C56 extu.b r1,r1
    c.r[1] <<= 2;  // 06071C58 shll2 r1
    c.r[1] += c.r[1];  // 06071C5A add r1,r1
    c.r[2] += c.r[1];  // 06071C5C add r1,r2
    c.r[2] += 4;  // 06071C5E add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06071C60 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06071C62 extu.b r1,r8
    c.r[5] = c.r[8] & 0xFFu;  // 06071C64 extu.b r8,r5
L_06071C66:
    c.r[4] = c.r[14];  // 06071C66 mov r14,r4
    c.r[1] = ld32(0x06071D50u);  // 06071C68 mov.l 0x06071D50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071C6Eu; c.r[4] += 48; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071C6Eu) return; }  // 06071C6A jsr @r1 ; add #48,r4
    c.r[1] = ld32(0x06071D5Cu);  // 06071C6E mov.l 0x06071D5C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071C70 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06071C72 extu.b r1,r0
    c.r[1] = ld32(0x06071D60u);  // 06071C74 mov.l 0x06071D60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06071C76 mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 06071C78 extu.b r1,r0
    c.r[1] = c.r[14];  // 06071C7A mov r14,r1
    c.r[1] += 24;  // 06071C7C add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06071C7E mov.b @(r0,r1),r1
    c.r[9] = c.r[1] & 0xFFu;  // 06071C80 extu.b r1,r9
    c.r[1] = ld32(0x06071D64u);  // 06071C82 mov.l 0x06071D64,r1
    c.r[1] = ld32(c.r[1]);  // 06071C84 mov.l @r1,r1
    c.r[1] += 1;  // 06071C86 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071C88 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06071C8A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06071C8C tst r1,r1
    { const bool k = !c.t; c.r[9] += 62; if (k) { goto L_06071C96; } }  // 06071C8E bf/s 0x06071C96 ; add #62,r9
    c.r[9] = c.r[9] & 0xFFFFu; goto L_06071C98;  // 06071C92 bra 0x06071C98 ; extu.w r9,r9
L_06071C96:
    c.r[9] = 0x5Du;  // 06071C96 mov #93,r9
L_06071C98:
    c.r[4] = ld32(0x06071D68u);  // 06071C98 mov.l 0x06071D68,r4
    c.r[8] = ld32(0x06071D6Cu);  // 06071C9A mov.l 0x06071D6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06071CA0u; c.r[5] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CA0u) return; }  // 06071C9C jsr @r8 ; mov #16,r5
    c.r[5] = c.r[9];  // 06071CA0 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06071CA6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CA6u) return; }  // 06071CA2 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06071D70u);  // 06071CA6 mov.l 0x06071D70,r1
    c.r[6] = 0x0u;  // 06071CA8 mov #0,r6
    c.r[5] = c.r[0];  // 06071CAA mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071CB0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CB0u) return; }  // 06071CAC jsr @r1 ; mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06071D36u);  // 06071CB0 mov.w 0x06071D36,r5
    c.r[1] = c.r[14];  // 06071CB2 mov r14,r1
    c.r[1] += 48;  // 06071CB4 add #48,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071CB6 mov.w @r1,r4
    c.r[9] = ld32(0x06071D74u);  // 06071CB8 mov.l 0x06071D74,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071D38u);  // 06071CBA mov.w 0x06071D38,r1
    c.r[4] += c.r[1];  // 06071CBC add r1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06071CC2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CC2u) return; }  // 06071CBE jsr @r9 ; extu.w r4,r4
    c.r[1] = c.r[14];  // 06071CC2 mov r14,r1
    c.r[1] += 58;  // 06071CC4 add #58,r1
    c.r[8] = ld32(0x06071D78u);  // 06071CC6 mov.l 0x06071D78,r8
    c.r[5] = 0x0u;  // 06071CC8 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071CCA mov.w @r1,r6
    c.r[4] = 0x0u;  // 06071CCC mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06071CD2u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CD2u) return; }  // 06071CCE jsr @r8 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 06071CD2 mov r14,r1
    c.r[1] += 60;  // 06071CD4 add #60,r1
    c.r[5] = 0x0u;  // 06071CD6 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071CD8 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06071CDA mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06071CE0u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CE0u) return; }  // 06071CDC jsr @r8 ; extu.w r6,r6
    c.r[8] = 0x0u;  // 06071CE0 mov #0,r8
    c.r[13] = ld32(0x06071D7Cu);  // 06071CE2 mov.l 0x06071D7C,r13
    c.r[11] = ld32(0x06071D80u);  // 06071CE4 mov.l 0x06071D80,r11
    c.r[12] = c.r[9];  // 06071CE6 mov r9,r12
L_06071CE8:
    c.r[1] = c.r[14];  // 06071CE8 mov r14,r1
    c.r[1] += 24;  // 06071CEA add #24,r1
    c.r[0] = c.r[1];  // 06071CEC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06071CEE mov.b @(r0,r8),r1
    c.r[5] = c.r[14];  // 06071CF0 mov r14,r5
    c.r[9] = c.r[1] & 0xFFu;  // 06071CF2 extu.b r1,r9
    c.r[1] = ld32(0x06071D54u);  // 06071CF4 mov.l 0x06071D54,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071CF6 mov.b @r1,r6
    c.r[4] = c.r[9];  // 06071CF8 mov r9,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06071CFEu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071CFEu) return; }  // 06071CFA jsr @r13 ; extu.b r6,r6
    c.r[1] = c.r[0];  // 06071CFE mov r0,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06071D3Au);  // 06071D00 mov.w 0x06071D3A,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06071D06u; c.r[10] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071D06u) return; }  // 06071D02 jsr @r11 ; extu.b r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071D36u);  // 06071D06 mov.w 0x06071D36,r1
    c.t = c.r[9] == c.r[1];  // 06071D08 cmp/eq r1,r9
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06071D20; } }  // 06071D0A bf/s 0x06071D20 ; mov r14,r1
    { const uint32_t x = c.r[11]; c.pr = 0x06071D12u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071D12u) return; }  // 06071D0E jsr @r11 ; mov #1,r4
    c.r[4] = ld32(0x06071D84u);  // 06071D12 mov.l 0x06071D84,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06071D18u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071D18u) return; }  // 06071D14 jsr @r12 ; mov r9,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06071D1Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071D1Cu) return; }  // 06071D18 jsr @r11 ; mov #0,r4
    c.r[8] += 1; goto L_06071DAA;  // 06071D1C bra 0x06071DAA ; add #1,r8
L_06071D20:
    c.r[1] += 58;  // 06071D20 add #58,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071D22 mov.w @r1,r1
    c.r[2] = c.r[10] & 0xFFFFu;  // 06071D24 extu.w r10,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06071D26 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 06071D28 cmp/hi r1,r2
    if (!c.t) { goto L_06071D88; }  // 06071D2A bf 0x06071D88
    c.r[4] = 0x2u;  // 06071D2C mov #2,r4
    goto L_06071D8A;  // 06071D2E bra 0x06071D8A ; nop
L_06071D88:
    c.r[4] = 0x1u;  // 06071D88 mov #1,r4
L_06071D8A:
    { const uint32_t x = c.r[11]; c.pr = 0x06071D8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071D8Eu) return; }  // 06071D8A jsr @r11 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x06071E1Eu);  // 06071D8E mov.w 0x06071E1E,r1
    c.r[9] |= c.r[1];  // 06071D90 or r1,r9
    c.r[5] = (uint32_t)(int16_t)ld16(0x06071E20u);  // 06071D92 mov.w 0x06071E20,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06071D98u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071D98u) return; }  // 06071D94 jsr @r12 ; mov r9,r4
    c.t = (c.r[10] & c.r[10]) == 0;  // 06071D98 tst r10,r10
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_06071DA0; } }  // 06071D9A bt/s 0x06071DA0 ; mov #-1,r6
    c.r[6] = c.r[10];  // 06071D9E mov r10,r6
L_06071DA0:
    c.r[1] = ld32(0x06071E24u);  // 06071DA0 mov.l 0x06071E24,r1
    c.r[5] = 0x0u;  // 06071DA2 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071DA8u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071DA8u) return; }  // 06071DA4 jsr @r1 ; mov #48,r4
    c.r[8] += 1;  // 06071DA8 add #1,r8
L_06071DAA:
    c.r[1] = 0x5u;  // 06071DAA mov #5,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06071DAC cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06071CE8; }  // 06071DAE bf 0x06071CE8
    c.r[8] = 0x0u;  // 06071DB0 mov #0,r8
    c.r[7] = c.r[1];  // 06071DB2 mov r1,r7
    c.r[2] = c.r[14];  // 06071DB4 mov r14,r2
    c.r[2] += 24;  // 06071DB6 add #24,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06071E20u);  // 06071DB8 mov.w 0x06071E20,r3
    c.r[0] = c.r[2];  // 06071DBA mov r2,r0
L_06071DBC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06071DBC mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06071DBE extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06071DC0 cmp/eq r3,r1
    if (c.t) { goto L_06071DCA; }  // 06071DC2 bt 0x06071DCA
    c.r[8] += 1;  // 06071DC4 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 06071DC6 cmp/gt r7,r8
    if (!c.t) { SH2_POLL(c); goto L_06071DBC; }  // 06071DC8 bf 0x06071DBC
L_06071DCA:
    c.r[1] = c.r[8] & 0xFFFFu;  // 06071DCA extu.w r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071DCC mov.l r1,@-r15
    c.r[2] = 0x1u;  // 06071DCE mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06071DD0 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06071DD2 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071DD4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071DD6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06071DD8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06071DDA mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071DDC mov.l r1,@-r15
    c.r[1] = 0x5u;  // 06071DDE mov #5,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071DE0 mov.l r1,@-r15
    c.r[7] = 0x2u;  // 06071DE2 mov #2,r7
    c.r[2] = c.r[8];  // 06071DE4 mov r8,r2
    c.r[1] = 0x3u;  // 06071DE6 mov #3,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06071DE8 cmp/gt r1,r2
    { const bool k = !c.t; c.r[15] -= 4; st32(c.r[15], c.r[7]); if (k) { goto L_06071DF0; } }  // 06071DEA bf/s 0x06071DF0 ; mov.l r7,@-r15
    c.r[2] = c.r[1];  // 06071DEE mov r1,r2
L_06071DF0:
    c.r[1] = c.r[2] & 0xFFu;  // 06071DF0 extu.b r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071DF2 mov.l r1,@-r15
    c.r[1] = ld32(0x06071E28u);  // 06071DF4 mov.l 0x06071E28,r1
    c.r[6] = 0x6u;  // 06071DF6 mov #6,r6
    c.r[5] = 0x16u;  // 06071DF8 mov #22,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071DFEu; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071DFEu) return; }  // 06071DFA jsr @r1 ; mov #5,r4
    c.r[15] += 40;  // 06071DFE add #40,r15
    c.r[1] = ld32(0x06071E2Cu);  // 06071E00 mov.l 0x06071E2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071E06u; c.r[4] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E06u) return; }  // 06071E02 jsr @r1 ; mov #29,r4
    c.r[14] += 96;  // 06071E06 add #96,r14
    c.r[15] = c.r[14];  // 06071E08 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06071E0A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06071E0C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06071E0E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06071E10 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06071E12 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06071E14 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06071E16 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071E22u);  // 06071E18 mov.w 0x06071E22,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06071E1A rts ; mov.l @r15+,r8
}

void f_06071E30(SH2Context& c) {
    ran[1593] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06071E30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06071E32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06071E34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06071E36 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06071E38 mov r15,r14
    c.r[1] = ld32(0x06071EA4u);  // 06071E3A mov.l 0x06071EA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071E40u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E40u) return; }  // 06071E3C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06071EA8u);  // 06071E40 mov.l 0x06071EA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071E46u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E46u) return; }  // 06071E42 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06071EACu);  // 06071E46 mov.l 0x06071EAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071E4Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E4Cu) return; }  // 06071E48 jsr @r1 ; nop
    c.r[8] = ld32(0x06071EB0u);  // 06071E4C mov.l 0x06071EB0,r8
    c.r[9] = ld32(0x06071EB4u);  // 06071E4E mov.l 0x06071EB4,r9
    c.r[5] = ld32(c.r[8] + 8);  // 06071E50 mov.l @(8,r8),r5
    c.r[6] = 0x0u;  // 06071E52 mov #0,r6
    c.r[1] = c.r[5];  // 06071E54 mov r5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06071E56 mov.b @r1+,r2
    c.r[4] = 0x0u;  // 06071E58 mov #0,r4
    c.r[2] = c.r[2] & 0xFFu;  // 06071E5A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071E5C mov.b @r1,r1
    c.r[2] <<= 8;  // 06071E5E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06071E60 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06071E62 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06071E64 exts.w r2,r2
    { const uint32_t x = c.r[9]; c.pr = 0x06071E6Au; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E6Au) return; }  // 06071E66 jsr @r9 ; add r2,r5
    c.r[5] = ld32(c.r[8] + 8);  // 06071E6A mov.l @(8,r8),r5
    c.r[6] = 0x0u;  // 06071E6C mov #0,r6
    c.r[1] = c.r[5];  // 06071E6E mov r5,r1
    c.r[1] += 2;  // 06071E70 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071E72 mov.b @r1,r2
    c.r[4] = 0x0u;  // 06071E74 mov #0,r4
    c.r[2] = c.r[2] & 0xFFu;  // 06071E76 extu.b r2,r2
    c.r[1] = c.r[5];  // 06071E78 mov r5,r1
    c.r[1] += 3;  // 06071E7A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071E7C mov.b @r1,r1
    c.r[2] <<= 8;  // 06071E7E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06071E80 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06071E82 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06071E84 exts.w r2,r2
    c.r[5] += c.r[2];  // 06071E86 add r2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06071E8Cu; c.r[5] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E8Cu) return; }  // 06071E88 jsr @r9 ; add #2,r5
    c.r[1] = ld32(0x06071EB8u);  // 06071E8C mov.l 0x06071EB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071E92u; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071E92u) return; }  // 06071E8E jsr @r1 ; mov #30,r4
    c.r[15] = c.r[14];  // 06071E92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06071E94 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06071E96 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06071E98 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06071EA0u);  // 06071E9A mov.w 0x06071EA0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06071E9C rts ; mov.l @r15+,r8
}

void f_06071EBC(SH2Context& c) {
    ran[1594] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06071EBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06071EBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06071EC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06071EC2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06071EC4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06071EC6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06071EC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06071ECA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06071FF8u);  // 06071ECC mov.w 0x06071FF8,r3
    c.r[15] += c.r[3];  // 06071ECE add r3,r15
    c.r[14] = c.r[15];  // 06071ED0 mov r15,r14
    c.r[1] = ld32(0x06072004u);  // 06071ED2 mov.l 0x06072004,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071ED8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071ED8u) return; }  // 06071ED4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072008u);  // 06071ED8 mov.l 0x06072008,r1
    c.r[1] = ld32(c.r[1]);  // 06071EDA mov.l @r1,r1
    c.r[1] += 1;  // 06071EDC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071EDE mov.b @r1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 06071EE0 extu.b r1,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06071EE2 tst r13,r13
    { const bool k = !c.t; c.r[11] = c.r[14]; if (k) { goto L_06071F70; } }  // 06071EE4 bf/s 0x06071F70 ; mov r14,r11
    c.r[8] = ld32(0x0607200Cu);  // 06071EE8 mov.l 0x0607200C,r8
    c.r[2] = c.r[8];  // 06071EEA mov r8,r2
    c.r[2] += 88;  // 06071EEC add #88,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06071FFAu);  // 06071EEE mov.w 0x06071FFA,r12
    c.r[11] += c.r[12];  // 06071EF0 add r12,r11
    c.r[0] = c.r[14];  // 06071EF2 mov r14,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06071FFCu);  // 06071EF4 mov.w 0x06071FFC,r3
    c.r[10] = c.r[14];  // 06071EF6 mov r14,r10
    c.r[10] += c.r[3];  // 06071EF8 add r3,r10
    c.r[9] = ld32(0x06072010u);  // 06071EFA mov.l 0x06072010,r9
    c.r[7] = ld32(0x06072014u);  // 06071EFC mov.l 0x06072014,r7
    c.r[6] = 0x0u;  // 06071EFE mov #0,r6
    c.r[5] = 0xFFFFFFFFu;  // 06071F00 mov #-1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06071F02 mov.w @r2,r1
    st16(c.r[0] + c.r[12], c.r[1]);  // 06071F04 mov.w r1,@(r0,r12)
    c.r[1] = 0x30u;  // 06071F06 mov #48,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06071F08 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06071F0A mov.w @r2,r1
    c.r[0] = ld32(0x06072018u);  // 06071F0C mov.l 0x06072018,r0
    st16(c.r[9], c.r[1]);  // 06071F0E mov.w r1,@r9
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06071F10 mov.l r0,@-r15
    c.r[0] = ld32(0x0607201Cu);  // 06071F12 mov.l 0x0607201C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06071F18u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071F18u) return; }  // 06071F14 jsr @r0 ; mov #17,r4
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06071F18 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06071F1A mov.l r14,@-r15
    c.r[0] = c.r[14];  // 06071F1C mov r14,r0
    c.r[1] = 0xAu;  // 06071F1E mov #10,r1
    c.r[7] = c.r[10];  // 06071F20 mov r10,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 06071F22 mov.w @(r0,r12),r2
    c.r[6] = c.r[11];  // 06071F24 mov r11,r6
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06071F26 mulu.w r1,r2
    c.r[5] = ld32(0x06072018u);  // 06071F28 mov.l 0x06072018,r5
    c.r[2] = ld32(c.r[8] + 8);  // 06071F2A mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 06071F2C sts macl,r1
    c.r[2] += c.r[1];  // 06071F2E add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06071F30 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 06071F32 mov.l @(4,r8),r1
    c.r[4] = ld32(0x06072014u);  // 06071F34 mov.l 0x06072014,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071F36 mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 06071F38 mov.l @r8,r1
    c.r[0] = ld32(0x06072020u);  // 06071F3A mov.l 0x06072020,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071F3C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06071F3E mov.l r13,@-r15
    c.r[1] = 0x1u;  // 06071F40 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06071F42 mov.l r1,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x06071F48u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071F48u) return; }  // 06071F44 jsr @r0 ; mov.l r13,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06071F48 mov.w @r9,r1
    c.r[2] = ld32(c.r[8] + 12);  // 06071F4A mov.l @(12,r8),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06071F4C extu.w r1,r1
    c.r[3] = c.r[1];  // 06071F4E mov r1,r3
    c.r[3] += c.r[3];  // 06071F50 add r3,r3
    c.r[3] += c.r[1];  // 06071F52 add r1,r3
    c.r[3] <<= 2;  // 06071F54 shll2 r3
    c.r[0] = c.r[3];  // 06071F56 mov r3,r0
    st32(c.r[0] + c.r[2], c.r[13]);  // 06071F58 mov.l r13,@(r0,r2)
    c.r[2] = ld32(0x06072024u);  // 06071F5A mov.l 0x06072024,r2
    c.r[1] = ld32(c.r[8] + 12);  // 06071F5C mov.l @(12,r8),r1
    c.r[0] = c.r[2];  // 06071F5E mov r2,r0
    c.r[3] += c.r[1];  // 06071F60 add r1,r3
    c.r[1] = ld32(0x06072028u);  // 06071F62 mov.l 0x06072028,r1
    st32(c.r[3] + 4, c.r[1]);  // 06071F64 mov.l r1,@(4,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06071FFEu);  // 06071F66 mov.w 0x06071FFE,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06071F68 mov.w @(r0,r3),r1
    c.r[15] += 36;  // 06071F6A add #36,r15
    c.r[1] += 1;  // 06071F6C add #1,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 06071F6E mov.w r1,@(r0,r3)
L_06071F70:
    c.r[1] = ld32(0x0607202Cu);  // 06071F70 mov.l 0x0607202C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071F76u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071F76u) return; }  // 06071F72 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072030u);  // 06071F76 mov.l 0x06072030,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071F7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071F7Cu) return; }  // 06071F78 jsr @r1 ; nop
    c.r[10] = ld32(0x06072034u);  // 06071F7C mov.l 0x06072034,r10
    c.r[11] = ld32(0x06072038u);  // 06071F7E mov.l 0x06072038,r11
    c.r[1] = ld32(c.r[10]);  // 06071F80 mov.l @r10,r1
    c.r[5] = 0x0u;  // 06071F82 mov #0,r5
    c.r[1] += 5;  // 06071F84 add #5,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071F86 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06071F88 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06071F8A extu.b r6,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06071F90u; c.r[6] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071F90u) return; }  // 06071F8C jsr @r11 ; add #-1,r6
    c.r[4] = ld32(0x0607203Cu);  // 06071F90 mov.l 0x0607203C,r4
    c.r[1] = ld32(c.r[10]);  // 06071F92 mov.l @r10,r1
    c.r[9] = ld32(0x06072040u);  // 06071F94 mov.l 0x06072040,r9
    c.r[1] += 7;  // 06071F96 add #7,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06071F98 mov.b @r1,r8
    c.r[5] = 0x16u;  // 06071F9A mov #22,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06071FA0u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071FA0u) return; }  // 06071F9C jsr @r9 ; extu.b r8,r8
    c.r[5] = c.r[8];  // 06071FA0 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06071FA6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071FA6u) return; }  // 06071FA2 jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x06072044u);  // 06071FA6 mov.l 0x06072044,r1
    c.r[6] = 0x0u;  // 06071FA8 mov #0,r6
    c.r[5] = c.r[0];  // 06071FAA mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06071FB0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071FB0u) return; }  // 06071FAC jsr @r1 ; mov #0,r4
    c.r[1] = ld32(c.r[10]);  // 06071FB0 mov.l @r10,r1
    c.r[5] = 0x0u;  // 06071FB2 mov #0,r5
    c.r[1] += 14;  // 06071FB4 add #14,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071FB6 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06071FB8 mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06071FBEu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071FBEu) return; }  // 06071FBA jsr @r11 ; extu.w r6,r6
    c.r[5] = 0x0u;  // 06071FBE mov #0,r5
    c.r[2] = ld32(c.r[10]);  // 06071FC0 mov.l @r10,r2
    c.r[4] = 0x0u;  // 06071FC2 mov #0,r4
    c.r[1] = c.r[2];  // 06071FC4 mov r2,r1
    c.r[1] += 10;  // 06071FC6 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06071FC8 mov.w @r1,r1
    c.r[2] += 12;  // 06071FCA add #12,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06071FCC mov.b @r2,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06071FCE extu.w r1,r1
    c.r[1] <<= 8;  // 06071FD0 shll8 r1
    c.r[6] = c.r[6] & 0xFFu;  // 06071FD2 extu.b r6,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06071FD8u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071FD8u) return; }  // 06071FD4 jsr @r11 ; or r1,r6
    c.r[1] = ld32(0x06072048u);  // 06071FD8 mov.l 0x06072048,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06071FDEu; c.r[4] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06071FDEu) return; }  // 06071FDA jsr @r1 ; mov #31,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06072000u);  // 06071FDE mov.w 0x06072000,r3
    c.r[14] += c.r[3];  // 06071FE0 add r3,r14
    c.r[15] = c.r[14];  // 06071FE2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06071FE4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06071FE6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06071FE8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06071FEA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06071FEC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06071FEE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06071FF0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072002u);  // 06071FF2 mov.w 0x06072002,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06071FF4 rts ; mov.l @r15+,r8
}

void f_0607204C(SH2Context& c) {
    ran[1595] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0607204C tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0607204E tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072050 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072052 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072054 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06072056 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06072058 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607205A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607205C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607205E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06072188u);  // 06072060 mov.w 0x06072188,r3
    c.r[15] += c.r[3];  // 06072062 add r3,r15
    c.r[14] = c.r[15];  // 06072064 mov r15,r14
    c.r[1] = ld32(0x06072190u);  // 06072066 mov.l 0x06072190,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607206Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607206Cu) return; }  // 06072068 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072194u);  // 0607206C mov.l 0x06072194,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072072u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072072u) return; }  // 0607206E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072198u);  // 06072072 mov.l 0x06072198,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072078u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072078u) return; }  // 06072074 jsr @r1 ; nop
    c.r[1] = ld32(0x0607219Cu);  // 06072078 mov.l 0x0607219C,r1
    c.r[1] = ld32(c.r[1]);  // 0607207A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607218Au);  // 0607207C mov.w 0x0607218A,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607207E mov.b @(r0,r1),r7
    c.r[1] = ld32(0x060721A0u);  // 06072080 mov.l 0x060721A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072082 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06072084 extu.b r1,r0
    c.r[1] = ld32(0x060721A4u);  // 06072086 mov.l 0x060721A4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072088 mov.b @(r0,r1),r1
    c.r[2] = c.r[7] & 0xFFu;  // 0607208A extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607208C extu.b r1,r1
    c.r[1] -= 1;  // 0607208E add #-1,r1
    c.r[3] = c.r[1];  // 06072090 mov r1,r3
    c.r[3] <<= 2;  // 06072092 shll2 r3
    c.r[3] += c.r[1];  // 06072094 add r1,r3
    c.r[3] += c.r[3];  // 06072096 add r3,r3
    c.r[2] -= c.r[3];  // 06072098 sub r3,r2
    c.r[1] = 0xAu;  // 0607209A mov #10,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607209C cmp/gt r1,r2
    { const bool k = c.t; c.r[4] = c.r[1]; if (k) { goto L_060720A8; } }  // 0607209E bt/s 0x060720A8 ; mov r1,r4
    c.r[1] = c.r[7];  // 060720A2 mov r7,r1
    c.r[1] -= c.r[3];  // 060720A4 sub r3,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060720A6 extu.b r1,r4
L_060720A8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607218Cu);  // 060720A8 mov.w 0x0607218C,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 060720AA mov.l r4,@(r0,r14)
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607218Eu);  // 060720AC mov.w 0x0607218E,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607218Cu);  // 060720AE mov.w 0x0607218C,r13
    c.r[13] += c.r[14];  // 060720B0 add r14,r13
    c.r[7] = 0x24u;  // 060720B2 mov #36,r7
    c.r[6] = 0x4u;  // 060720B4 mov #4,r6
    c.r[1] = ld32(c.r[13]);  // 060720B6 mov.l @r13,r1
    c.r[1] += 1;  // 060720B8 add #1,r1
    c.r[1] += c.r[1];  // 060720BA add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060720BC extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060720BE mov.l r1,@-r15
    c.r[1] = ld32(0x060721A8u);  // 060720C0 mov.l 0x060721A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060720C6u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060720C6u) return; }  // 060720C2 jsr @r1 ; mov #1,r5
    c.r[1] = ld32(0x0607219Cu);  // 060720C6 mov.l 0x0607219C,r1
    c.r[1] = ld32(c.r[1]);  // 060720C8 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607218Au);  // 060720CA mov.w 0x0607218A,r2
    c.r[0] = c.r[1];  // 060720CC mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060720CE mov.b @(r0,r2),r2
    c.r[1] = ld32(0x060721ACu);  // 060720D0 mov.l 0x060721AC,r1
    c.r[1] = ld32(c.r[1]);  // 060720D2 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060720D4 extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060720D6 dmulu.l r1,r2
    c.r[1] = c.mach;  // 060720D8 sts mach,r1
    c.r[1] >>= 2;  // 060720DA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060720DC shlr r1
    c.r[7] = c.r[1] & 0xFFu;  // 060720DE extu.b r1,r7
    c.r[7] += c.r[2];  // 060720E0 add r2,r7
    c.r[3] = c.r[1];  // 060720E2 mov r1,r3
    c.r[3] <<= 2;  // 060720E4 shll2 r3
    c.r[3] += c.r[1];  // 060720E6 add r1,r3
    c.r[3] += c.r[3];  // 060720E8 add r3,r3
    c.r[2] -= c.r[3];  // 060720EA sub r3,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060720EC extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060720EE tst r2,r2
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_060720F6; } }  // 060720F0 bt/s 0x060720F6 ; add #4,r15
    c.r[7] += 1;  // 060720F4 add #1,r7
L_060720F6:
    c.r[1] = c.r[7] & 0xFFFFu;  // 060720F6 extu.w r7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060720F8 mov.l r1,@-r15
    c.r[8] = 0x1u;  // 060720FA mov #1,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060720FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060720FE mov.l r8,@-r15
    c.r[1] = 0x0u;  // 06072100 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072102 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072104 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072106 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072108 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607210A mov.l r1,@-r15
    c.r[1] = 0xBu;  // 0607210C mov #11,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607210E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072110 mov.l r8,@-r15
    c.r[1] = ld32(0x060721B0u);  // 06072112 mov.l 0x060721B0,r1
    c.r[7] = 0x2u;  // 06072114 mov #2,r7
    c.r[6] = 0x11u;  // 06072116 mov #17,r6
    c.r[5] = 0x5u;  // 06072118 mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607211Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607211Eu) return; }  // 0607211A jsr @r1 ; mov #2,r4
    c.r[15] += 40;  // 0607211E add #40,r15
    c.r[1] = ld32(0x060721B4u);  // 06072120 mov.l 0x060721B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072126u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072126u) return; }  // 06072122 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060721A0u);  // 06072126 mov.l 0x060721A0,r1
    c.r[8] = ld32(0x060721B8u);  // 06072128 mov.l 0x060721B8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607212A mov.b @r1,r1
    c.r[5] = 0x0u;  // 0607212C mov #0,r5
    c.r[2] = c.r[1] & 0xFFu;  // 0607212E extu.b r1,r2
    c.r[1] = ld32(0x060721A4u);  // 06072130 mov.l 0x060721A4,r1
    c.r[0] = c.r[2];  // 06072132 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072134 mov.b @(r0,r1),r6
    c.r[4] = 0x0u;  // 06072136 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607213Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607213Cu) return; }  // 06072138 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(0x0607219Cu);  // 0607213C mov.l 0x0607219C,r1
    c.r[1] = ld32(c.r[1]);  // 0607213E mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607218Au);  // 06072140 mov.w 0x0607218A,r2
    c.r[0] = c.r[1];  // 06072142 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072144 mov.b @(r0,r2),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06072146 extu.b r2,r2
    c.r[2] += 9;  // 06072148 add #9,r2
    c.r[1] = ld32(0x060721BCu);  // 0607214A mov.l 0x060721BC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0607214C dmuls.l r1,r2
    c.r[5] = 0x0u;  // 0607214E mov #0,r5
    c.r[4] = 0x0u;  // 06072150 mov #0,r4
    c.r[6] = c.mach;  // 06072152 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06072154 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06072156 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06072158 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0607215A subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06072160u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072160u) return; }  // 0607215C jsr @r8 ; sub r2,r6
    c.r[1] = ld32(0x060721C0u);  // 06072160 mov.l 0x060721C0,r1
    c.r[1] = ld32(c.r[1]);  // 06072162 mov.l @r1,r1
    c.r[1] += 9;  // 06072164 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072166 mov.b @r1,r1
    c.r[13] = 0x3u;  // 06072168 mov #3,r13
    c.r[1] >>= 2;  // 0607216A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607216C shlr r1
    c.r[1] >>= 2;  // 0607216E shlr2 r1
    c.r[1] &= c.r[13];  // 06072170 and r13,r1
    c.r[0] = c.r[1];  // 06072172 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06072174 cmp/eq #1,r0
    { const bool k = c.t; c.r[11] = 0x3u; if (k) { goto L_060721C4; } }  // 06072176 bt/s 0x060721C4 ; mov #3,r11
    c.t = c.r[0] == 0x2u;  // 0607217A cmp/eq #2,r0
    if (c.t) { goto L_06072184; }  // 0607217C bt 0x06072184
    c.r[11] = 0x7u;  // 0607217E mov #7,r11
    c.r[9] = c.r[11] & 0xFFFFu; goto L_060721C6;  // 06072180 bra 0x060721C6 ; extu.w r11,r9
L_06072184:
    c.r[11] = 0x0u; goto L_060721C4;  // 06072184 bra 0x060721C4 ; mov #0,r11
L_060721C4:
    c.r[9] = c.r[11] & 0xFFFFu;  // 060721C4 extu.w r11,r9
L_060721C6:
    c.r[10] = ld32(0x0607234Cu);  // 060721C6 mov.l 0x0607234C,r10
    c.r[8] = ld32(0x06072350u);  // 060721C8 mov.l 0x06072350,r8
    c.r[5] = 0x17u;  // 060721CA mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060721D0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721D0u) return; }  // 060721CC jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 060721D0 mov r0,r1
    c.r[5] = 0x8u;  // 060721D2 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060721D8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721D8u) return; }  // 060721D4 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060721D8 mov r0,r1
    c.r[5] = c.r[9];  // 060721DA mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060721E0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721E0u) return; }  // 060721DC jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060721E0 mov r0,r1
    c.r[9] = ld32(0x06072354u);  // 060721E2 mov.l 0x06072354,r9
    c.r[6] = 0x0u;  // 060721E4 mov #0,r6
    c.r[5] = c.r[1];  // 060721E6 mov r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060721ECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721ECu) return; }  // 060721E8 jsr @r9 ; mov #0,r4
    c.r[1] = ld32(0x06072358u);  // 060721EC mov.l 0x06072358,r1
    c.r[13] = 0x3u;  // 060721EE mov #3,r13
    c.r[1] = ld32(c.r[1]);  // 060721F0 mov.l @r1,r1
    c.r[5] = 0x17u;  // 060721F2 mov #23,r5
    c.r[1] += 9;  // 060721F4 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060721F6 mov.b @r1,r1
    c.r[4] = c.r[10];  // 060721F8 mov r10,r4
    c.r[11] = c.r[1];  // 060721FA mov r1,r11
    c.r[11] >>= 2;  // 060721FC shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 060721FE shlr r11
    { const uint32_t x = c.r[8]; c.pr = 0x06072204u; c.r[11] &= c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072204u) return; }  // 06072200 jsr @r8 ; and r13,r11
    c.r[1] = c.r[0];  // 06072204 mov r0,r1
    c.r[5] = 0x9u;  // 06072206 mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607220Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607220Cu) return; }  // 06072208 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607220C mov r0,r1
    c.r[5] = c.r[11];  // 0607220E mov r11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06072214u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072214u) return; }  // 06072210 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072214 mov r0,r1
    c.r[6] = 0x0u;  // 06072216 mov #0,r6
    c.r[5] = c.r[1];  // 06072218 mov r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607221Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607221Eu) return; }  // 0607221A jsr @r9 ; mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072340u);  // 0607221E mov.w 0x06072340,r0
    c.r[0] += c.r[14];  // 06072220 add r14,r0
    c.r[1] = ld32(0x0607235Cu);  // 06072222 mov.l 0x0607235C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072228u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072228u) return; }  // 06072224 jsr @r1 ; mov.l @r0,r4
    c.r[1] = ld32(0x06072360u);  // 06072228 mov.l 0x06072360,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607222A mov.b @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072340u);  // 0607222C mov.w 0x06072340,r13
    c.r[2] = c.r[1] & 0xFFu;  // 0607222E extu.b r1,r2
    c.r[1] = ld32(0x06072364u);  // 06072230 mov.l 0x06072364,r1
    c.r[0] = c.r[2];  // 06072232 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072234 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06072236 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06072238 extu.b r1,r1
    c.r[1] -= 1;  // 0607223A add #-1,r1
    c.r[11] = c.r[1];  // 0607223C mov r1,r11
    c.r[11] <<= 2;  // 0607223E shll2 r11
    c.r[11] += c.r[1];  // 06072240 add r1,r11
    c.r[1] = ld32(c.r[13]);  // 06072242 mov.l @r13,r1
    c.r[11] += c.r[11];  // 06072244 add r11,r11
    c.r[1] += c.r[11];  // 06072246 add r11,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06072248 cmp/ge r1,r11
    if (!c.t) { goto L_06072250; }  // 0607224A bf 0x06072250
    goto L_06072482;  // 0607224C bra 0x06072482 ; nop
L_06072250:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072342u);  // 06072250 mov.w 0x06072342,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072344u);  // 06072252 mov.w 0x06072344,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06072254 mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072344u);  // 06072256 mov.w 0x06072344,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06072258 mov.l @(r0,r14),r12
    c.r[12] += c.r[14];  // 0607225A add r14,r12
    c.r[0] = c.r[12];  // 0607225C mov r12,r0
    c.r[0] += 2;  // 0607225E add #2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072346u);  // 06072260 mov.w 0x06072346,r13
    c.r[13] += c.r[14];  // 06072262 add r14,r13
    st32(c.r[13], c.r[0]);  // 06072264 mov.l r0,@r13
L_06072266:
    c.r[13] = ld32(0x06072368u);  // 06072266 mov.l 0x06072368,r13
    c.r[10] = c.r[11];  // 06072268 mov r11,r10
    c.r[10] += c.r[10];  // 0607226A add r10,r10
    c.r[3] = 0x7Fu;  // 0607226C mov #127,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06072348u);  // 0607226E mov.w 0x06072348,r6
    c.r[1] = ld32(c.r[13]);  // 06072270 mov.l @r13,r1
    c.r[4] = c.r[14];  // 06072272 mov r14,r4
    c.r[0] = c.r[1];  // 06072274 mov r1,r0
    c.r[1] += c.r[10];  // 06072276 add r10,r1
    c.r[1] += 1;  // 06072278 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607227A mov.b @(r0,r10),r2
    c.r[13] = ld32(0x0607236Cu);  // 0607227C mov.l 0x0607236C,r13
    c.r[3] &= c.r[2];  // 0607227E and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072280 mov.b @r1,r2
    c.r[3] <<= 8;  // 06072282 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06072284 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06072286 or r3,r2
    c.r[1] = ld32(c.r[13]);  // 06072288 mov.l @r13,r1
    c.r[2] <<= 2;  // 0607228A shll2 r2
    c.r[2] <<= 2;  // 0607228C shll2 r2
    c.r[2] += c.r[1];  // 0607228E add r1,r2
    c.r[2] += 2;  // 06072290 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06072292 mov.b @r2,r5
    c.r[1] = ld32(0x06072370u);  // 06072294 mov.l 0x06072370,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607229Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607229Au) return; }  // 06072296 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0607229A mov r14,r1
    c.r[1] += 14;  // 0607229C add #14,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607229E mov.b @r1,r5
    c.r[4] = c.r[12];  // 060722A0 mov r12,r4
    c.r[1] = ld32(0x06072374u);  // 060722A2 mov.l 0x06072374,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060722A8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722A8u) return; }  // 060722A4 jsr @r1 ; extu.b r5,r5
    c.r[0] = ld32(0x06072368u);  // 060722A8 mov.l 0x06072368,r0
    c.r[3] = 0x7Fu;  // 060722AA mov #127,r3
    c.r[8] = ld32(0x06072350u);  // 060722AC mov.l 0x06072350,r8
    c.r[5] = 0x17u;  // 060722AE mov #23,r5
    c.r[1] = ld32(c.r[0]);  // 060722B0 mov.l @r0,r1
    c.r[4] = ld32(0x0607234Cu);  // 060722B2 mov.l 0x0607234C,r4
    c.r[0] = c.r[1];  // 060722B4 mov r1,r0
    c.r[1] += c.r[10];  // 060722B6 add r10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060722B8 mov.b @(r0,r10),r2
    c.r[1] += 1;  // 060722BA add #1,r1
    c.r[3] &= c.r[2];  // 060722BC and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060722BE mov.b @r1,r2
    c.r[3] <<= 8;  // 060722C0 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 060722C2 extu.b r2,r2
    c.r[2] |= c.r[3];  // 060722C4 or r3,r2
    c.r[1] = ld32(c.r[13]);  // 060722C6 mov.l @r13,r1
    c.r[2] <<= 2;  // 060722C8 shll2 r2
    c.r[2] <<= 2;  // 060722CA shll2 r2
    c.r[2] += c.r[1];  // 060722CC add r1,r2
    c.r[1] = c.r[2];  // 060722CE mov r2,r1
    c.r[1] += 3;  // 060722D0 add #3,r1
    c.r[13] = 0x1u;  // 060722D2 mov #1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060722D4 mov.b @r1,r1
    c.r[2] += 4;  // 060722D6 add #4,r2
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060722D8 mov.b @r2,r9
    c.r[1] &= c.r[13];  // 060722DA and r13,r1
    c.r[1] += c.r[1];  // 060722DC add r1,r1
    c.r[9] = c.r[9] & 0xFFu;  // 060722DE extu.b r9,r9
    c.r[9] >>= 2;  // 060722E0 shlr2 r9
    c.r[9] >>= 2;  // 060722E2 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060722E4 shlr r9
    c.r[9] >>= 2;  // 060722E6 shlr2 r9
    { const uint32_t x = c.r[8]; c.pr = 0x060722ECu; c.r[9] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722ECu) return; }  // 060722E8 jsr @r8 ; or r1,r9
    c.r[1] = c.r[0];  // 060722EC mov r0,r1
    c.r[5] = 0xBu;  // 060722EE mov #11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060722F4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722F4u) return; }  // 060722F0 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060722F4 mov r0,r1
    c.r[5] = c.r[9];  // 060722F6 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060722FCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722FCu) return; }  // 060722F8 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 060722FC mov r0,r2
    c.r[1] = ld32(0x06072354u);  // 060722FE mov.l 0x06072354,r1
    c.r[6] = 0x0u;  // 06072300 mov #0,r6
    c.r[5] = c.r[2];  // 06072302 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072308u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072308u) return; }  // 06072304 jsr @r1 ; mov #0,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072344u);  // 06072308 mov.w 0x06072344,r13
    c.r[13] += c.r[14];  // 0607230A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0607230C mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607234Au);  // 0607230E mov.w 0x0607234A,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06072310 mov.w @(r0,r14),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072348u);  // 06072312 mov.w 0x06072348,r5
    c.r[4] += c.r[1];  // 06072314 add r1,r4
    c.r[1] = ld32(0x06072378u);  // 06072316 mov.l 0x06072378,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607231Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607231Cu) return; }  // 06072318 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x06072358u);  // 0607231C mov.l 0x06072358,r1
    c.r[2] = ld32(c.r[1]);  // 0607231E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06072320 mov r2,r1
    c.r[1] += 9;  // 06072322 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072324 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06072326 mov #3,r0
    c.r[1] >>= 2;  // 06072328 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607232A shlr r1
    c.r[1] >>= 2;  // 0607232C shlr2 r1
    c.r[1] &= c.r[0];  // 0607232E and r0,r1
    c.r[0] = c.r[1];  // 06072330 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06072332 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0607237C; } }  // 06072334 bt/s 0x0607237C ; cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0607242A; } }  // 06072338 bt/s 0x0607242A ; mov r12,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]); goto L_0607244C;  // 0607233C bra 0x0607244C ; mov.w @r14,r4
L_0607237C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060724B6u);  // 0607237C mov.w 0x060724B6,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607237E mov.b @(r0,r2),r0
    c.r[0] &= 0x10u;  // 06072380 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06072382 tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_060723DA; } }  // 06072384 bf/s 0x060723DA ; mov #0,r3
    c.r[13] = ld32(0x060724C8u);  // 06072388 mov.l 0x060724C8,r13
    c.r[1] = ld32(c.r[13]);  // 0607238A mov.l @r13,r1
    c.r[7] = 0x7Fu;  // 0607238C mov #127,r7
    c.r[0] = c.r[1];  // 0607238E mov r1,r0
    c.r[1] += c.r[10];  // 06072390 add r10,r1
    c.r[1] += 1;  // 06072392 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06072394 mov.b @(r0,r10),r2
    c.r[13] = ld32(0x060724CCu);  // 06072396 mov.l 0x060724CC,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072398 mov.b @r1,r1
    c.r[7] &= c.r[2];  // 0607239A and r2,r7
    c.r[7] <<= 8;  // 0607239C shll8 r7
    c.r[2] = c.r[1] & 0xFFu;  // 0607239E extu.b r1,r2
    c.r[2] |= c.r[7];  // 060723A0 or r7,r2
    c.r[1] = ld32(c.r[13]);  // 060723A2 mov.l @r13,r1
    c.r[2] <<= 2;  // 060723A4 shll2 r2
    c.r[2] <<= 2;  // 060723A6 shll2 r2
    c.r[2] += c.r[1];  // 060723A8 add r1,r2
    c.r[1] = c.r[2];  // 060723AA mov r2,r1
    c.r[1] += 7;  // 060723AC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060723AE mov.b @r1,r1
    c.r[0] = 0x1u;  // 060723B0 mov #1,r0
    c.r[1] >>= 2;  // 060723B2 shlr2 r1
    c.r[1] &= c.r[0];  // 060723B4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060723B6 tst r1,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_060723DE; } }  // 060723B8 bt/s 0x060723DE ; tst r3,r3
    c.r[2] += 3;  // 060723BC add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060723BE mov.b @r2,r1
    c.r[0] = c.r[1];  // 060723C0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060723C2 shlr r0
    c.r[0] &= 0x3u;  // 060723C4 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060723C6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060723DA; } }  // 060723C8 bt/s 0x060723DA ; mov r14,r1
    c.r[1] += 22;  // 060723CC add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060723CE mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060724B8u);  // 060723D0 mov.w 0x060724B8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060723D2 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 060723D4 cmp/hi r2,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_060723DE; } }  // 060723D6 bt/s 0x060723DE ; tst r3,r3
L_060723DA:
    c.r[3] = 0x1u;  // 060723DA mov #1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060723DC tst r3,r3
L_060723DE:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060723FE; } }  // 060723DE bt/s 0x060723FE ; mov #0,r5
    c.r[1] = c.r[14];  // 060723E2 mov r14,r1
    c.r[1] += 22;  // 060723E4 add #22,r1
    c.r[8] = ld32(0x060724D0u);  // 060723E6 mov.l 0x060724D0,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060723E8 mov.w @r1,r6
    c.r[4] = 0x1u;  // 060723EA mov #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060723F0u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060723F0u) return; }  // 060723EC jsr @r8 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 060723F0 mov r14,r1
    c.r[1] += 26;  // 060723F2 add #26,r1
    c.r[5] = 0x0u;  // 060723F4 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060723F6 mov.w @r1,r6
    c.r[4] = 0x1u;  // 060723F8 mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_0607240C;  // 060723FA bra 0x0607240C ; extu.w r6,r6
L_060723FE:
    c.r[8] = ld32(0x060724D0u);  // 060723FE mov.l 0x060724D0,r8
    c.r[6] = 0xFFFFFFFFu;  // 06072400 mov #-1,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06072406u; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072406u) return; }  // 06072402 jsr @r8 ; mov #81,r4
    c.r[6] = 0xFFFFFFFFu;  // 06072406 mov #-1,r6
    c.r[5] = 0x0u;  // 06072408 mov #0,r5
    c.r[4] = 0x51u;  // 0607240A mov #81,r4
L_0607240C:
    { const uint32_t x = c.r[8]; c.pr = 0x06072410u; c.r[11] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072410u) return; }  // 0607240C jsr @r8 ; add #1,r11
    c.r[1] = c.r[14];  // 06072410 mov r14,r1
    c.r[1] += 26;  // 06072412 add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072414 mov.w @r1,r5
    c.r[6] = 0xBu;  // 06072416 mov #11,r6
    c.r[1] = c.r[14];  // 06072418 mov r14,r1
    c.r[1] += 22;  // 0607241A add #22,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607241C mov.w @r1,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0607241E extu.w r5,r5
    c.r[1] = ld32(0x060724D4u);  // 06072420 mov.l 0x060724D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072426u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072426u) return; }  // 06072422 jsr @r1 ; extu.w r4,r4
    goto L_0607245A;  // 06072426 bra 0x0607245A ; nop
L_0607242A:
    c.r[1] += 9;  // 0607242A add #9,r1
    c.r[8] = ld32(0x060724D0u);  // 0607242C mov.l 0x060724D0,r8
    c.r[5] = 0x0u;  // 0607242E mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072430 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06072432 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06072438u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072438u) return; }  // 06072434 jsr @r8 ; extu.b r6,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x060724BAu);  // 06072438 mov.w 0x060724BA,r13
    c.r[13] += c.r[14];  // 0607243A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0607243C mov.l @r13,r0
    c.r[5] = 0x0u;  // 0607243E mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06072440 mov.b @r0,r6
    c.r[4] = 0x0u;  // 06072442 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06072448u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072448u) return; }  // 06072444 jsr @r8 ; extu.b r6,r6
    c.r[11] += 1; goto L_0607245A;  // 06072448 bra 0x0607245A ; add #1,r11
L_0607244C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060724BCu);  // 0607244C mov.w 0x060724BC,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060724BEu);  // 0607244E mov.w 0x060724BE,r5
    c.r[4] += c.r[1];  // 06072450 add r1,r4
    c.r[1] = ld32(0x060724D8u);  // 06072452 mov.l 0x060724D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072458u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072458u) return; }  // 06072454 jsr @r1 ; extu.w r4,r4
    c.r[11] += 1;  // 06072458 add #1,r11
L_0607245A:
    c.r[1] = ld32(0x060724DCu);  // 0607245A mov.l 0x060724DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607245C mov.b @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x060724C0u);  // 0607245E mov.w 0x060724C0,r13
    c.r[2] = c.r[1] & 0xFFu;  // 06072460 extu.b r1,r2
    c.r[1] = ld32(0x060724E0u);  // 06072462 mov.l 0x060724E0,r1
    c.r[0] = c.r[2];  // 06072464 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072466 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06072468 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0607246A mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607246C extu.b r1,r1
    c.r[1] -= 1;  // 0607246E add #-1,r1
    c.r[2] = c.r[1];  // 06072470 mov r1,r2
    c.r[2] <<= 2;  // 06072472 shll2 r2
    c.r[2] += c.r[1];  // 06072474 add r1,r2
    c.r[2] += c.r[2];  // 06072476 add r2,r2
    c.r[2] += c.r[13];  // 06072478 add r13,r2
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[2];  // 0607247A cmp/ge r2,r11
    if (c.t) { goto L_06072482; }  // 0607247C bt 0x06072482
    SH2_POLL(c); goto L_06072266;  // 0607247E bra 0x06072266 ; nop
L_06072482:
    c.r[1] = ld32(0x060724E4u);  // 06072482 mov.l 0x060724E4,r1
    c.r[1] = ld32(c.r[1]);  // 06072484 mov.l @r1,r1
    c.r[1] += 9;  // 06072486 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072488 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607248A mov r1,r0
    c.r[0] >>= 2;  // 0607248C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607248E shlr r0
    c.r[0] >>= 2;  // 06072490 shlr2 r0
    c.r[0] &= 0x3u;  // 06072492 and #3,r0
    c.r[0] |= 0x20u;  // 06072494 or #32,r0
    c.r[1] = ld32(0x060724E8u);  // 06072496 mov.l 0x060724E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607249Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607249Cu) return; }  // 06072498 jsr @r1 ; mov r0,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060724C2u);  // 0607249C mov.w 0x060724C2,r3
    c.r[14] += c.r[3];  // 0607249E add r3,r14
    c.r[15] = c.r[14];  // 060724A0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060724A2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060724A4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060724A6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060724A8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060724AA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060724AC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060724AE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060724C4u);  // 060724B0 mov.w 0x060724C4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060724B2 rts ; mov.l @r15+,r8
}

void f_06072050(SH2Context& c) {
    ran[1596] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072050 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072052 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072054 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06072056 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06072058 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607205A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607205C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607205E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06072188u);  // 06072060 mov.w 0x06072188,r3
    c.r[15] += c.r[3];  // 06072062 add r3,r15
    c.r[14] = c.r[15];  // 06072064 mov r15,r14
    c.r[1] = ld32(0x06072190u);  // 06072066 mov.l 0x06072190,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607206Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607206Cu) return; }  // 06072068 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072194u);  // 0607206C mov.l 0x06072194,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072072u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072072u) return; }  // 0607206E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072198u);  // 06072072 mov.l 0x06072198,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072078u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072078u) return; }  // 06072074 jsr @r1 ; nop
    c.r[1] = ld32(0x0607219Cu);  // 06072078 mov.l 0x0607219C,r1
    c.r[1] = ld32(c.r[1]);  // 0607207A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607218Au);  // 0607207C mov.w 0x0607218A,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607207E mov.b @(r0,r1),r7
    c.r[1] = ld32(0x060721A0u);  // 06072080 mov.l 0x060721A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072082 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06072084 extu.b r1,r0
    c.r[1] = ld32(0x060721A4u);  // 06072086 mov.l 0x060721A4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072088 mov.b @(r0,r1),r1
    c.r[2] = c.r[7] & 0xFFu;  // 0607208A extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607208C extu.b r1,r1
    c.r[1] -= 1;  // 0607208E add #-1,r1
    c.r[3] = c.r[1];  // 06072090 mov r1,r3
    c.r[3] <<= 2;  // 06072092 shll2 r3
    c.r[3] += c.r[1];  // 06072094 add r1,r3
    c.r[3] += c.r[3];  // 06072096 add r3,r3
    c.r[2] -= c.r[3];  // 06072098 sub r3,r2
    c.r[1] = 0xAu;  // 0607209A mov #10,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607209C cmp/gt r1,r2
    { const bool k = c.t; c.r[4] = c.r[1]; if (k) { goto L_060720A8; } }  // 0607209E bt/s 0x060720A8 ; mov r1,r4
    c.r[1] = c.r[7];  // 060720A2 mov r7,r1
    c.r[1] -= c.r[3];  // 060720A4 sub r3,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060720A6 extu.b r1,r4
L_060720A8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607218Cu);  // 060720A8 mov.w 0x0607218C,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 060720AA mov.l r4,@(r0,r14)
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607218Eu);  // 060720AC mov.w 0x0607218E,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607218Cu);  // 060720AE mov.w 0x0607218C,r13
    c.r[13] += c.r[14];  // 060720B0 add r14,r13
    c.r[7] = 0x24u;  // 060720B2 mov #36,r7
    c.r[6] = 0x4u;  // 060720B4 mov #4,r6
    c.r[1] = ld32(c.r[13]);  // 060720B6 mov.l @r13,r1
    c.r[1] += 1;  // 060720B8 add #1,r1
    c.r[1] += c.r[1];  // 060720BA add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060720BC extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060720BE mov.l r1,@-r15
    c.r[1] = ld32(0x060721A8u);  // 060720C0 mov.l 0x060721A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060720C6u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060720C6u) return; }  // 060720C2 jsr @r1 ; mov #1,r5
    c.r[1] = ld32(0x0607219Cu);  // 060720C6 mov.l 0x0607219C,r1
    c.r[1] = ld32(c.r[1]);  // 060720C8 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607218Au);  // 060720CA mov.w 0x0607218A,r2
    c.r[0] = c.r[1];  // 060720CC mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060720CE mov.b @(r0,r2),r2
    c.r[1] = ld32(0x060721ACu);  // 060720D0 mov.l 0x060721AC,r1
    c.r[1] = ld32(c.r[1]);  // 060720D2 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060720D4 extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060720D6 dmulu.l r1,r2
    c.r[1] = c.mach;  // 060720D8 sts mach,r1
    c.r[1] >>= 2;  // 060720DA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060720DC shlr r1
    c.r[7] = c.r[1] & 0xFFu;  // 060720DE extu.b r1,r7
    c.r[7] += c.r[2];  // 060720E0 add r2,r7
    c.r[3] = c.r[1];  // 060720E2 mov r1,r3
    c.r[3] <<= 2;  // 060720E4 shll2 r3
    c.r[3] += c.r[1];  // 060720E6 add r1,r3
    c.r[3] += c.r[3];  // 060720E8 add r3,r3
    c.r[2] -= c.r[3];  // 060720EA sub r3,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060720EC extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060720EE tst r2,r2
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_060720F6; } }  // 060720F0 bt/s 0x060720F6 ; add #4,r15
    c.r[7] += 1;  // 060720F4 add #1,r7
L_060720F6:
    c.r[1] = c.r[7] & 0xFFFFu;  // 060720F6 extu.w r7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060720F8 mov.l r1,@-r15
    c.r[8] = 0x1u;  // 060720FA mov #1,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060720FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060720FE mov.l r8,@-r15
    c.r[1] = 0x0u;  // 06072100 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072102 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072104 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072106 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072108 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607210A mov.l r1,@-r15
    c.r[1] = 0xBu;  // 0607210C mov #11,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607210E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072110 mov.l r8,@-r15
    c.r[1] = ld32(0x060721B0u);  // 06072112 mov.l 0x060721B0,r1
    c.r[7] = 0x2u;  // 06072114 mov #2,r7
    c.r[6] = 0x11u;  // 06072116 mov #17,r6
    c.r[5] = 0x5u;  // 06072118 mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607211Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607211Eu) return; }  // 0607211A jsr @r1 ; mov #2,r4
    c.r[15] += 40;  // 0607211E add #40,r15
    c.r[1] = ld32(0x060721B4u);  // 06072120 mov.l 0x060721B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072126u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072126u) return; }  // 06072122 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060721A0u);  // 06072126 mov.l 0x060721A0,r1
    c.r[8] = ld32(0x060721B8u);  // 06072128 mov.l 0x060721B8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607212A mov.b @r1,r1
    c.r[5] = 0x0u;  // 0607212C mov #0,r5
    c.r[2] = c.r[1] & 0xFFu;  // 0607212E extu.b r1,r2
    c.r[1] = ld32(0x060721A4u);  // 06072130 mov.l 0x060721A4,r1
    c.r[0] = c.r[2];  // 06072132 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072134 mov.b @(r0,r1),r6
    c.r[4] = 0x0u;  // 06072136 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607213Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607213Cu) return; }  // 06072138 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(0x0607219Cu);  // 0607213C mov.l 0x0607219C,r1
    c.r[1] = ld32(c.r[1]);  // 0607213E mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607218Au);  // 06072140 mov.w 0x0607218A,r2
    c.r[0] = c.r[1];  // 06072142 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072144 mov.b @(r0,r2),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06072146 extu.b r2,r2
    c.r[2] += 9;  // 06072148 add #9,r2
    c.r[1] = ld32(0x060721BCu);  // 0607214A mov.l 0x060721BC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0607214C dmuls.l r1,r2
    c.r[5] = 0x0u;  // 0607214E mov #0,r5
    c.r[4] = 0x0u;  // 06072150 mov #0,r4
    c.r[6] = c.mach;  // 06072152 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06072154 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06072156 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06072158 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0607215A subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06072160u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072160u) return; }  // 0607215C jsr @r8 ; sub r2,r6
    c.r[1] = ld32(0x060721C0u);  // 06072160 mov.l 0x060721C0,r1
    c.r[1] = ld32(c.r[1]);  // 06072162 mov.l @r1,r1
    c.r[1] += 9;  // 06072164 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072166 mov.b @r1,r1
    c.r[13] = 0x3u;  // 06072168 mov #3,r13
    c.r[1] >>= 2;  // 0607216A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607216C shlr r1
    c.r[1] >>= 2;  // 0607216E shlr2 r1
    c.r[1] &= c.r[13];  // 06072170 and r13,r1
    c.r[0] = c.r[1];  // 06072172 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06072174 cmp/eq #1,r0
    { const bool k = c.t; c.r[11] = 0x3u; if (k) { goto L_060721C4; } }  // 06072176 bt/s 0x060721C4 ; mov #3,r11
    c.t = c.r[0] == 0x2u;  // 0607217A cmp/eq #2,r0
    if (c.t) { goto L_06072184; }  // 0607217C bt 0x06072184
    c.r[11] = 0x7u;  // 0607217E mov #7,r11
    c.r[9] = c.r[11] & 0xFFFFu; goto L_060721C6;  // 06072180 bra 0x060721C6 ; extu.w r11,r9
L_06072184:
    c.r[11] = 0x0u; goto L_060721C4;  // 06072184 bra 0x060721C4 ; mov #0,r11
L_060721C4:
    c.r[9] = c.r[11] & 0xFFFFu;  // 060721C4 extu.w r11,r9
L_060721C6:
    c.r[10] = ld32(0x0607234Cu);  // 060721C6 mov.l 0x0607234C,r10
    c.r[8] = ld32(0x06072350u);  // 060721C8 mov.l 0x06072350,r8
    c.r[5] = 0x17u;  // 060721CA mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060721D0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721D0u) return; }  // 060721CC jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 060721D0 mov r0,r1
    c.r[5] = 0x8u;  // 060721D2 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060721D8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721D8u) return; }  // 060721D4 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060721D8 mov r0,r1
    c.r[5] = c.r[9];  // 060721DA mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060721E0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721E0u) return; }  // 060721DC jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060721E0 mov r0,r1
    c.r[9] = ld32(0x06072354u);  // 060721E2 mov.l 0x06072354,r9
    c.r[6] = 0x0u;  // 060721E4 mov #0,r6
    c.r[5] = c.r[1];  // 060721E6 mov r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060721ECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060721ECu) return; }  // 060721E8 jsr @r9 ; mov #0,r4
    c.r[1] = ld32(0x06072358u);  // 060721EC mov.l 0x06072358,r1
    c.r[13] = 0x3u;  // 060721EE mov #3,r13
    c.r[1] = ld32(c.r[1]);  // 060721F0 mov.l @r1,r1
    c.r[5] = 0x17u;  // 060721F2 mov #23,r5
    c.r[1] += 9;  // 060721F4 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060721F6 mov.b @r1,r1
    c.r[4] = c.r[10];  // 060721F8 mov r10,r4
    c.r[11] = c.r[1];  // 060721FA mov r1,r11
    c.r[11] >>= 2;  // 060721FC shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 060721FE shlr r11
    { const uint32_t x = c.r[8]; c.pr = 0x06072204u; c.r[11] &= c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072204u) return; }  // 06072200 jsr @r8 ; and r13,r11
    c.r[1] = c.r[0];  // 06072204 mov r0,r1
    c.r[5] = 0x9u;  // 06072206 mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607220Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607220Cu) return; }  // 06072208 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607220C mov r0,r1
    c.r[5] = c.r[11];  // 0607220E mov r11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06072214u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072214u) return; }  // 06072210 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072214 mov r0,r1
    c.r[6] = 0x0u;  // 06072216 mov #0,r6
    c.r[5] = c.r[1];  // 06072218 mov r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607221Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607221Eu) return; }  // 0607221A jsr @r9 ; mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072340u);  // 0607221E mov.w 0x06072340,r0
    c.r[0] += c.r[14];  // 06072220 add r14,r0
    c.r[1] = ld32(0x0607235Cu);  // 06072222 mov.l 0x0607235C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072228u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072228u) return; }  // 06072224 jsr @r1 ; mov.l @r0,r4
    c.r[1] = ld32(0x06072360u);  // 06072228 mov.l 0x06072360,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607222A mov.b @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072340u);  // 0607222C mov.w 0x06072340,r13
    c.r[2] = c.r[1] & 0xFFu;  // 0607222E extu.b r1,r2
    c.r[1] = ld32(0x06072364u);  // 06072230 mov.l 0x06072364,r1
    c.r[0] = c.r[2];  // 06072232 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072234 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06072236 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06072238 extu.b r1,r1
    c.r[1] -= 1;  // 0607223A add #-1,r1
    c.r[11] = c.r[1];  // 0607223C mov r1,r11
    c.r[11] <<= 2;  // 0607223E shll2 r11
    c.r[11] += c.r[1];  // 06072240 add r1,r11
    c.r[1] = ld32(c.r[13]);  // 06072242 mov.l @r13,r1
    c.r[11] += c.r[11];  // 06072244 add r11,r11
    c.r[1] += c.r[11];  // 06072246 add r11,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06072248 cmp/ge r1,r11
    if (!c.t) { goto L_06072250; }  // 0607224A bf 0x06072250
    goto L_06072482;  // 0607224C bra 0x06072482 ; nop
L_06072250:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072342u);  // 06072250 mov.w 0x06072342,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072344u);  // 06072252 mov.w 0x06072344,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06072254 mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072344u);  // 06072256 mov.w 0x06072344,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06072258 mov.l @(r0,r14),r12
    c.r[12] += c.r[14];  // 0607225A add r14,r12
    c.r[0] = c.r[12];  // 0607225C mov r12,r0
    c.r[0] += 2;  // 0607225E add #2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072346u);  // 06072260 mov.w 0x06072346,r13
    c.r[13] += c.r[14];  // 06072262 add r14,r13
    st32(c.r[13], c.r[0]);  // 06072264 mov.l r0,@r13
L_06072266:
    c.r[13] = ld32(0x06072368u);  // 06072266 mov.l 0x06072368,r13
    c.r[10] = c.r[11];  // 06072268 mov r11,r10
    c.r[10] += c.r[10];  // 0607226A add r10,r10
    c.r[3] = 0x7Fu;  // 0607226C mov #127,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06072348u);  // 0607226E mov.w 0x06072348,r6
    c.r[1] = ld32(c.r[13]);  // 06072270 mov.l @r13,r1
    c.r[4] = c.r[14];  // 06072272 mov r14,r4
    c.r[0] = c.r[1];  // 06072274 mov r1,r0
    c.r[1] += c.r[10];  // 06072276 add r10,r1
    c.r[1] += 1;  // 06072278 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607227A mov.b @(r0,r10),r2
    c.r[13] = ld32(0x0607236Cu);  // 0607227C mov.l 0x0607236C,r13
    c.r[3] &= c.r[2];  // 0607227E and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072280 mov.b @r1,r2
    c.r[3] <<= 8;  // 06072282 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06072284 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06072286 or r3,r2
    c.r[1] = ld32(c.r[13]);  // 06072288 mov.l @r13,r1
    c.r[2] <<= 2;  // 0607228A shll2 r2
    c.r[2] <<= 2;  // 0607228C shll2 r2
    c.r[2] += c.r[1];  // 0607228E add r1,r2
    c.r[2] += 2;  // 06072290 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06072292 mov.b @r2,r5
    c.r[1] = ld32(0x06072370u);  // 06072294 mov.l 0x06072370,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607229Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607229Au) return; }  // 06072296 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0607229A mov r14,r1
    c.r[1] += 14;  // 0607229C add #14,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607229E mov.b @r1,r5
    c.r[4] = c.r[12];  // 060722A0 mov r12,r4
    c.r[1] = ld32(0x06072374u);  // 060722A2 mov.l 0x06072374,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060722A8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722A8u) return; }  // 060722A4 jsr @r1 ; extu.b r5,r5
    c.r[0] = ld32(0x06072368u);  // 060722A8 mov.l 0x06072368,r0
    c.r[3] = 0x7Fu;  // 060722AA mov #127,r3
    c.r[8] = ld32(0x06072350u);  // 060722AC mov.l 0x06072350,r8
    c.r[5] = 0x17u;  // 060722AE mov #23,r5
    c.r[1] = ld32(c.r[0]);  // 060722B0 mov.l @r0,r1
    c.r[4] = ld32(0x0607234Cu);  // 060722B2 mov.l 0x0607234C,r4
    c.r[0] = c.r[1];  // 060722B4 mov r1,r0
    c.r[1] += c.r[10];  // 060722B6 add r10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060722B8 mov.b @(r0,r10),r2
    c.r[1] += 1;  // 060722BA add #1,r1
    c.r[3] &= c.r[2];  // 060722BC and r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060722BE mov.b @r1,r2
    c.r[3] <<= 8;  // 060722C0 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 060722C2 extu.b r2,r2
    c.r[2] |= c.r[3];  // 060722C4 or r3,r2
    c.r[1] = ld32(c.r[13]);  // 060722C6 mov.l @r13,r1
    c.r[2] <<= 2;  // 060722C8 shll2 r2
    c.r[2] <<= 2;  // 060722CA shll2 r2
    c.r[2] += c.r[1];  // 060722CC add r1,r2
    c.r[1] = c.r[2];  // 060722CE mov r2,r1
    c.r[1] += 3;  // 060722D0 add #3,r1
    c.r[13] = 0x1u;  // 060722D2 mov #1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060722D4 mov.b @r1,r1
    c.r[2] += 4;  // 060722D6 add #4,r2
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060722D8 mov.b @r2,r9
    c.r[1] &= c.r[13];  // 060722DA and r13,r1
    c.r[1] += c.r[1];  // 060722DC add r1,r1
    c.r[9] = c.r[9] & 0xFFu;  // 060722DE extu.b r9,r9
    c.r[9] >>= 2;  // 060722E0 shlr2 r9
    c.r[9] >>= 2;  // 060722E2 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060722E4 shlr r9
    c.r[9] >>= 2;  // 060722E6 shlr2 r9
    { const uint32_t x = c.r[8]; c.pr = 0x060722ECu; c.r[9] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722ECu) return; }  // 060722E8 jsr @r8 ; or r1,r9
    c.r[1] = c.r[0];  // 060722EC mov r0,r1
    c.r[5] = 0xBu;  // 060722EE mov #11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060722F4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722F4u) return; }  // 060722F0 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060722F4 mov r0,r1
    c.r[5] = c.r[9];  // 060722F6 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060722FCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060722FCu) return; }  // 060722F8 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 060722FC mov r0,r2
    c.r[1] = ld32(0x06072354u);  // 060722FE mov.l 0x06072354,r1
    c.r[6] = 0x0u;  // 06072300 mov #0,r6
    c.r[5] = c.r[2];  // 06072302 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072308u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072308u) return; }  // 06072304 jsr @r1 ; mov #0,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x06072344u);  // 06072308 mov.w 0x06072344,r13
    c.r[13] += c.r[14];  // 0607230A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0607230C mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607234Au);  // 0607230E mov.w 0x0607234A,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06072310 mov.w @(r0,r14),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072348u);  // 06072312 mov.w 0x06072348,r5
    c.r[4] += c.r[1];  // 06072314 add r1,r4
    c.r[1] = ld32(0x06072378u);  // 06072316 mov.l 0x06072378,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607231Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607231Cu) return; }  // 06072318 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x06072358u);  // 0607231C mov.l 0x06072358,r1
    c.r[2] = ld32(c.r[1]);  // 0607231E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06072320 mov r2,r1
    c.r[1] += 9;  // 06072322 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072324 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06072326 mov #3,r0
    c.r[1] >>= 2;  // 06072328 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607232A shlr r1
    c.r[1] >>= 2;  // 0607232C shlr2 r1
    c.r[1] &= c.r[0];  // 0607232E and r0,r1
    c.r[0] = c.r[1];  // 06072330 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06072332 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0607237C; } }  // 06072334 bt/s 0x0607237C ; cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0607242A; } }  // 06072338 bt/s 0x0607242A ; mov r12,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]); goto L_0607244C;  // 0607233C bra 0x0607244C ; mov.w @r14,r4
L_0607237C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060724B6u);  // 0607237C mov.w 0x060724B6,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607237E mov.b @(r0,r2),r0
    c.r[0] &= 0x10u;  // 06072380 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06072382 tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_060723DA; } }  // 06072384 bf/s 0x060723DA ; mov #0,r3
    c.r[13] = ld32(0x060724C8u);  // 06072388 mov.l 0x060724C8,r13
    c.r[1] = ld32(c.r[13]);  // 0607238A mov.l @r13,r1
    c.r[7] = 0x7Fu;  // 0607238C mov #127,r7
    c.r[0] = c.r[1];  // 0607238E mov r1,r0
    c.r[1] += c.r[10];  // 06072390 add r10,r1
    c.r[1] += 1;  // 06072392 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06072394 mov.b @(r0,r10),r2
    c.r[13] = ld32(0x060724CCu);  // 06072396 mov.l 0x060724CC,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072398 mov.b @r1,r1
    c.r[7] &= c.r[2];  // 0607239A and r2,r7
    c.r[7] <<= 8;  // 0607239C shll8 r7
    c.r[2] = c.r[1] & 0xFFu;  // 0607239E extu.b r1,r2
    c.r[2] |= c.r[7];  // 060723A0 or r7,r2
    c.r[1] = ld32(c.r[13]);  // 060723A2 mov.l @r13,r1
    c.r[2] <<= 2;  // 060723A4 shll2 r2
    c.r[2] <<= 2;  // 060723A6 shll2 r2
    c.r[2] += c.r[1];  // 060723A8 add r1,r2
    c.r[1] = c.r[2];  // 060723AA mov r2,r1
    c.r[1] += 7;  // 060723AC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060723AE mov.b @r1,r1
    c.r[0] = 0x1u;  // 060723B0 mov #1,r0
    c.r[1] >>= 2;  // 060723B2 shlr2 r1
    c.r[1] &= c.r[0];  // 060723B4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060723B6 tst r1,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_060723DE; } }  // 060723B8 bt/s 0x060723DE ; tst r3,r3
    c.r[2] += 3;  // 060723BC add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060723BE mov.b @r2,r1
    c.r[0] = c.r[1];  // 060723C0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060723C2 shlr r0
    c.r[0] &= 0x3u;  // 060723C4 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060723C6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060723DA; } }  // 060723C8 bt/s 0x060723DA ; mov r14,r1
    c.r[1] += 22;  // 060723CC add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060723CE mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060724B8u);  // 060723D0 mov.w 0x060724B8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060723D2 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 060723D4 cmp/hi r2,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_060723DE; } }  // 060723D6 bt/s 0x060723DE ; tst r3,r3
L_060723DA:
    c.r[3] = 0x1u;  // 060723DA mov #1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060723DC tst r3,r3
L_060723DE:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060723FE; } }  // 060723DE bt/s 0x060723FE ; mov #0,r5
    c.r[1] = c.r[14];  // 060723E2 mov r14,r1
    c.r[1] += 22;  // 060723E4 add #22,r1
    c.r[8] = ld32(0x060724D0u);  // 060723E6 mov.l 0x060724D0,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060723E8 mov.w @r1,r6
    c.r[4] = 0x1u;  // 060723EA mov #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060723F0u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060723F0u) return; }  // 060723EC jsr @r8 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 060723F0 mov r14,r1
    c.r[1] += 26;  // 060723F2 add #26,r1
    c.r[5] = 0x0u;  // 060723F4 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060723F6 mov.w @r1,r6
    c.r[4] = 0x1u;  // 060723F8 mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_0607240C;  // 060723FA bra 0x0607240C ; extu.w r6,r6
L_060723FE:
    c.r[8] = ld32(0x060724D0u);  // 060723FE mov.l 0x060724D0,r8
    c.r[6] = 0xFFFFFFFFu;  // 06072400 mov #-1,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06072406u; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072406u) return; }  // 06072402 jsr @r8 ; mov #81,r4
    c.r[6] = 0xFFFFFFFFu;  // 06072406 mov #-1,r6
    c.r[5] = 0x0u;  // 06072408 mov #0,r5
    c.r[4] = 0x51u;  // 0607240A mov #81,r4
L_0607240C:
    { const uint32_t x = c.r[8]; c.pr = 0x06072410u; c.r[11] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072410u) return; }  // 0607240C jsr @r8 ; add #1,r11
    c.r[1] = c.r[14];  // 06072410 mov r14,r1
    c.r[1] += 26;  // 06072412 add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072414 mov.w @r1,r5
    c.r[6] = 0xBu;  // 06072416 mov #11,r6
    c.r[1] = c.r[14];  // 06072418 mov r14,r1
    c.r[1] += 22;  // 0607241A add #22,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607241C mov.w @r1,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0607241E extu.w r5,r5
    c.r[1] = ld32(0x060724D4u);  // 06072420 mov.l 0x060724D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072426u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072426u) return; }  // 06072422 jsr @r1 ; extu.w r4,r4
    goto L_0607245A;  // 06072426 bra 0x0607245A ; nop
L_0607242A:
    c.r[1] += 9;  // 0607242A add #9,r1
    c.r[8] = ld32(0x060724D0u);  // 0607242C mov.l 0x060724D0,r8
    c.r[5] = 0x0u;  // 0607242E mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072430 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06072432 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06072438u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072438u) return; }  // 06072434 jsr @r8 ; extu.b r6,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x060724BAu);  // 06072438 mov.w 0x060724BA,r13
    c.r[13] += c.r[14];  // 0607243A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0607243C mov.l @r13,r0
    c.r[5] = 0x0u;  // 0607243E mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06072440 mov.b @r0,r6
    c.r[4] = 0x0u;  // 06072442 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06072448u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072448u) return; }  // 06072444 jsr @r8 ; extu.b r6,r6
    c.r[11] += 1; goto L_0607245A;  // 06072448 bra 0x0607245A ; add #1,r11
L_0607244C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060724BCu);  // 0607244C mov.w 0x060724BC,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060724BEu);  // 0607244E mov.w 0x060724BE,r5
    c.r[4] += c.r[1];  // 06072450 add r1,r4
    c.r[1] = ld32(0x060724D8u);  // 06072452 mov.l 0x060724D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072458u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072458u) return; }  // 06072454 jsr @r1 ; extu.w r4,r4
    c.r[11] += 1;  // 06072458 add #1,r11
L_0607245A:
    c.r[1] = ld32(0x060724DCu);  // 0607245A mov.l 0x060724DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607245C mov.b @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x060724C0u);  // 0607245E mov.w 0x060724C0,r13
    c.r[2] = c.r[1] & 0xFFu;  // 06072460 extu.b r1,r2
    c.r[1] = ld32(0x060724E0u);  // 06072462 mov.l 0x060724E0,r1
    c.r[0] = c.r[2];  // 06072464 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072466 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06072468 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0607246A mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607246C extu.b r1,r1
    c.r[1] -= 1;  // 0607246E add #-1,r1
    c.r[2] = c.r[1];  // 06072470 mov r1,r2
    c.r[2] <<= 2;  // 06072472 shll2 r2
    c.r[2] += c.r[1];  // 06072474 add r1,r2
    c.r[2] += c.r[2];  // 06072476 add r2,r2
    c.r[2] += c.r[13];  // 06072478 add r13,r2
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[2];  // 0607247A cmp/ge r2,r11
    if (c.t) { goto L_06072482; }  // 0607247C bt 0x06072482
    SH2_POLL(c); goto L_06072266;  // 0607247E bra 0x06072266 ; nop
L_06072482:
    c.r[1] = ld32(0x060724E4u);  // 06072482 mov.l 0x060724E4,r1
    c.r[1] = ld32(c.r[1]);  // 06072484 mov.l @r1,r1
    c.r[1] += 9;  // 06072486 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072488 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607248A mov r1,r0
    c.r[0] >>= 2;  // 0607248C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607248E shlr r0
    c.r[0] >>= 2;  // 06072490 shlr2 r0
    c.r[0] &= 0x3u;  // 06072492 and #3,r0
    c.r[0] |= 0x20u;  // 06072494 or #32,r0
    c.r[1] = ld32(0x060724E8u);  // 06072496 mov.l 0x060724E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607249Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607249Cu) return; }  // 06072498 jsr @r1 ; mov r0,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060724C2u);  // 0607249C mov.w 0x060724C2,r3
    c.r[14] += c.r[3];  // 0607249E add r3,r14
    c.r[15] = c.r[14];  // 060724A0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060724A2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060724A4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060724A6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060724A8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060724AA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060724AC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060724AE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060724C4u);  // 060724B0 mov.w 0x060724C4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060724B2 rts ; mov.l @r15+,r8
}

void f_060724EC(SH2Context& c) {
    ran[1597] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060724EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060724EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060724F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060724F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060724F4 mov r15,r14
    c.r[1] = ld32(0x0607254Cu);  // 060724F6 mov.l 0x0607254C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060724FCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060724FCu) return; }  // 060724F8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06072550u);  // 060724FC mov.l 0x06072550,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072502u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072502u) return; }  // 060724FE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06072554u);  // 06072502 mov.l 0x06072554,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072508u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072508u) return; }  // 06072504 jsr @r1 ; nop
    c.r[1] = ld32(0x06072558u);  // 06072508 mov.l 0x06072558,r1
    c.r[4] = ld32(0x0607255Cu);  // 0607250A mov.l 0x0607255C,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607250C mov.b @r1,r1
    c.r[9] = ld32(0x06072560u);  // 0607250E mov.l 0x06072560,r9
    c.r[0] = c.r[1] & 0xFFu;  // 06072510 extu.b r1,r0
    c.r[1] = ld32(0x06072564u);  // 06072512 mov.l 0x06072564,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072514 mov.b @(r0,r1),r8
    c.r[5] = 0x17u;  // 06072516 mov #23,r5
    c.r[8] = c.r[8] & 0xFFu;  // 06072518 extu.b r8,r8
    c.r[8] += 4;  // 0607251A add #4,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06072520u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072520u) return; }  // 0607251C jsr @r9 ; extu.w r8,r8
    c.r[5] = 0xBu;  // 06072520 mov #11,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06072526u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072526u) return; }  // 06072522 jsr @r9 ; mov r0,r4
    c.r[5] = c.r[8];  // 06072526 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607252Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607252Cu) return; }  // 06072528 jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x06072568u);  // 0607252C mov.l 0x06072568,r1
    c.r[6] = 0x0u;  // 0607252E mov #0,r6
    c.r[5] = c.r[0];  // 06072530 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072536u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072536u) return; }  // 06072532 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607256Cu);  // 06072536 mov.l 0x0607256C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607253Cu; c.r[4] = 0x23u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607253Cu) return; }  // 06072538 jsr @r1 ; mov #35,r4
    c.r[15] = c.r[14];  // 0607253C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607253E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06072540 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06072542 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607254Au);  // 06072544 mov.w 0x0607254A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06072546 rts ; mov.l @r15+,r8
}

void f_06072570(SH2Context& c) {
    ran[1598] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 06072570 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 06072572 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072574 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072576 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072578 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607257A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607257C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607257E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06072580 mov r15,r14
    c.r[1] = ld32(0x0607269Cu);  // 06072582 mov.l 0x0607269C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072588u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072588u) return; }  // 06072584 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A0u);  // 06072588 mov.l 0x060726A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607258Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607258Eu) return; }  // 0607258A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A4u);  // 0607258E mov.l 0x060726A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072594u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072594u) return; }  // 06072590 jsr @r1 ; nop
    c.r[6] = ld32(0x060726A8u);  // 06072594 mov.l 0x060726A8,r6
    c.r[1] = ld32(0x060726ACu);  // 06072596 mov.l 0x060726AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072598 mov.b @r1,r1
    c.r[11] = ld32(0x060726B0u);  // 0607259A mov.l 0x060726B0,r11
    c.r[2] = c.r[1] & 0xFFu;  // 0607259C extu.b r1,r2
    c.r[1] = ld32(0x060726B4u);  // 0607259E mov.l 0x060726B4,r1
    c.r[0] = c.r[2];  // 060725A0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725A2 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060726B8u);  // 060725A4 mov.l 0x060726B8,r4
    c.r[2] = ld32(0x060726BCu);  // 060725A6 mov.l 0x060726BC,r2
    c.r[2] = ld32(c.r[2]);  // 060725A8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060725AA extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060725AC dmulu.l r2,r1
    c.r[9] = ld32(0x060726C0u);  // 060725AE mov.l 0x060726C0,r9
    c.r[7] = ld32(c.r[11]);  // 060725B0 mov.l @r11,r7
    c.r[2] = c.mach;  // 060725B2 sts mach,r2
    c.r[2] >>= 2;  // 060725B4 shlr2 r2
    c.r[3] = c.r[2];  // 060725B6 mov r2,r3
    c.r[3] <<= 2;  // 060725B8 shll2 r3
    c.r[3] += c.r[2];  // 060725BA add r2,r3
    c.r[1] -= c.r[3];  // 060725BC sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060725BE extu.b r1,r1
    c.r[3] = c.r[1];  // 060725C0 mov r1,r3
    c.r[3] += c.r[3];  // 060725C2 add r3,r3
    c.r[3] += c.r[1];  // 060725C4 add r1,r3
    c.r[3] += c.r[3];  // 060725C6 add r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060725C8 extu.b r2,r2
    c.r[3] += c.r[2];  // 060725CA add r2,r3
    c.r[3] += c.r[3];  // 060725CC add r3,r3
    c.r[7] += c.r[3];  // 060725CE add r3,r7
    c.r[7] += 1;  // 060725D0 add #1,r7
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060725D2 mov.b @r7,r8
    c.r[5] = 0x10u;  // 060725D4 mov #16,r5
    st8(c.r[6], c.r[8]);  // 060725D6 mov.b r8,@r6
    c.r[8] = c.r[8] & 0xFFu;  // 060725D8 extu.b r8,r8
    c.r[8] += 62;  // 060725DA add #62,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060725E0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E0u) return; }  // 060725DC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060725E0 mov r0,r1
    c.r[5] = c.r[8];  // 060725E2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060725E8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E8u) return; }  // 060725E4 jsr @r9 ; mov r1,r4
    c.r[2] = c.r[0];  // 060725E8 mov r0,r2
    c.r[1] = ld32(0x060726C4u);  // 060725EA mov.l 0x060726C4,r1
    c.r[6] = 0x0u;  // 060725EC mov #0,r6
    c.r[5] = c.r[2];  // 060725EE mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060725F4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725F4u) return; }  // 060725F0 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060725F4 mov.l @r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072692u);  // 060725F6 mov.w 0x06072692,r1
    c.r[0] = c.r[2];  // 060725F8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725FA mov.b @(r0,r1),r1
    c.r[8] = 0x0u;  // 060725FC mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060725FE extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072600 cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[11]; if (k) { goto L_0607267A; } }  // 06072602 bt/s 0x0607267A ; mov r11,r9
    c.r[10] = ld32(0x060726C8u);  // 06072606 mov.l 0x060726C8,r10
L_06072608:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06072694u);  // 06072608 mov.w 0x06072694,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607260Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607260Eu) return; }  // 0607260A jsr @r10 ; nop
    c.r[2] = c.r[8];  // 0607260E mov r8,r2
    c.r[3] = ld32(c.r[9]);  // 06072610 mov.l @r9,r3
    c.r[2] += c.r[2];  // 06072612 add r2,r2
    c.r[0] = c.r[3];  // 06072614 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072616 mov.b @(r0,r2),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06072618 extu.b r1,r7
    c.r[1] = c.r[7];  // 0607261A mov r7,r1
    c.r[1] >>= 2;  // 0607261C shlr2 r1
    c.r[1] >>= 2;  // 0607261E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072620 shlr r1
    c.r[1] >>= 2;  // 06072622 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072624 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06072640; } }  // 06072626 bt/s 0x06072640 ; mov #1,r4
    c.r[0] = 0x7Fu;  // 0607262A mov #127,r0
    c.r[7] &= c.r[0];  // 0607262C and r0,r7
    c.r[3] += c.r[2];  // 0607262E add r2,r3
    c.r[3] += 1;  // 06072630 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072632 mov.b @r3,r1
    c.r[7] <<= 8;  // 06072634 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06072636 extu.b r1,r1
    c.r[1] |= c.r[7];  // 06072638 or r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607263A tst r1,r1
    if (c.t) { goto L_06072640; }  // 0607263C bt 0x06072640
    c.r[4] = 0x2u;  // 0607263E mov #2,r4
L_06072640:
    { const uint32_t x = c.r[10]; c.pr = 0x06072644u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072644u) return; }  // 06072640 jsr @r10 ; nop
    c.r[2] = c.r[8];  // 06072644 mov r8,r2
    c.r[2] += c.r[2];  // 06072646 add r2,r2
    c.r[1] = ld32(c.r[9]);  // 06072648 mov.l @r9,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072696u);  // 0607264A mov.w 0x06072696,r5
    c.r[0] = c.r[1];  // 0607264C mov r1,r0
    c.r[1] += c.r[2];  // 0607264E add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072650 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06072652 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072654 mov.b @r1,r4
    c.r[0] = 0x7Fu;  // 06072656 mov #127,r0
    c.r[3] &= c.r[0];  // 06072658 and r0,r3
    c.r[3] <<= 8;  // 0607265A shll8 r3
    c.r[4] = c.r[4] & 0xFFu;  // 0607265C extu.b r4,r4
    c.r[4] |= c.r[3];  // 0607265E or r3,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072698u);  // 06072660 mov.w 0x06072698,r1
    c.r[4] += c.r[1];  // 06072662 add r1,r4
    c.r[1] = ld32(0x060726CCu);  // 06072664 mov.l 0x060726CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607266Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607266Au) return; }  // 06072666 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[9]);  // 0607266A mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06072692u);  // 0607266C mov.w 0x06072692,r2
    c.r[0] = c.r[1];  // 0607266E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072670 mov.b @(r0,r2),r1
    c.r[8] += 1;  // 06072672 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06072674 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072676 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06072608; }  // 06072678 bf 0x06072608
L_0607267A:
    c.r[1] = ld32(0x060726D0u);  // 0607267A mov.l 0x060726D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072680u; c.r[4] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072680u) return; }  // 0607267C jsr @r1 ; mov #36,r4
    c.r[15] = c.r[14];  // 06072680 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06072682 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06072684 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06072686 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06072688 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607268A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607269Au);  // 0607268C mov.w 0x0607269A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607268E rts ; mov.l @r15+,r8
}

void f_06072574(SH2Context& c) {
    ran[1599] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072574 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072576 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072578 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607257A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607257C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607257E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06072580 mov r15,r14
    c.r[1] = ld32(0x0607269Cu);  // 06072582 mov.l 0x0607269C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072588u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072588u) return; }  // 06072584 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A0u);  // 06072588 mov.l 0x060726A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607258Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607258Eu) return; }  // 0607258A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A4u);  // 0607258E mov.l 0x060726A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072594u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072594u) return; }  // 06072590 jsr @r1 ; nop
    c.r[6] = ld32(0x060726A8u);  // 06072594 mov.l 0x060726A8,r6
    c.r[1] = ld32(0x060726ACu);  // 06072596 mov.l 0x060726AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072598 mov.b @r1,r1
    c.r[11] = ld32(0x060726B0u);  // 0607259A mov.l 0x060726B0,r11
    c.r[2] = c.r[1] & 0xFFu;  // 0607259C extu.b r1,r2
    c.r[1] = ld32(0x060726B4u);  // 0607259E mov.l 0x060726B4,r1
    c.r[0] = c.r[2];  // 060725A0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725A2 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060726B8u);  // 060725A4 mov.l 0x060726B8,r4
    c.r[2] = ld32(0x060726BCu);  // 060725A6 mov.l 0x060726BC,r2
    c.r[2] = ld32(c.r[2]);  // 060725A8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060725AA extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060725AC dmulu.l r2,r1
    c.r[9] = ld32(0x060726C0u);  // 060725AE mov.l 0x060726C0,r9
    c.r[7] = ld32(c.r[11]);  // 060725B0 mov.l @r11,r7
    c.r[2] = c.mach;  // 060725B2 sts mach,r2
    c.r[2] >>= 2;  // 060725B4 shlr2 r2
    c.r[3] = c.r[2];  // 060725B6 mov r2,r3
    c.r[3] <<= 2;  // 060725B8 shll2 r3
    c.r[3] += c.r[2];  // 060725BA add r2,r3
    c.r[1] -= c.r[3];  // 060725BC sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060725BE extu.b r1,r1
    c.r[3] = c.r[1];  // 060725C0 mov r1,r3
    c.r[3] += c.r[3];  // 060725C2 add r3,r3
    c.r[3] += c.r[1];  // 060725C4 add r1,r3
    c.r[3] += c.r[3];  // 060725C6 add r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060725C8 extu.b r2,r2
    c.r[3] += c.r[2];  // 060725CA add r2,r3
    c.r[3] += c.r[3];  // 060725CC add r3,r3
    c.r[7] += c.r[3];  // 060725CE add r3,r7
    c.r[7] += 1;  // 060725D0 add #1,r7
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060725D2 mov.b @r7,r8
    c.r[5] = 0x10u;  // 060725D4 mov #16,r5
    st8(c.r[6], c.r[8]);  // 060725D6 mov.b r8,@r6
    c.r[8] = c.r[8] & 0xFFu;  // 060725D8 extu.b r8,r8
    c.r[8] += 62;  // 060725DA add #62,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060725E0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E0u) return; }  // 060725DC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060725E0 mov r0,r1
    c.r[5] = c.r[8];  // 060725E2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060725E8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E8u) return; }  // 060725E4 jsr @r9 ; mov r1,r4
    c.r[2] = c.r[0];  // 060725E8 mov r0,r2
    c.r[1] = ld32(0x060726C4u);  // 060725EA mov.l 0x060726C4,r1
    c.r[6] = 0x0u;  // 060725EC mov #0,r6
    c.r[5] = c.r[2];  // 060725EE mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060725F4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725F4u) return; }  // 060725F0 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060725F4 mov.l @r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072692u);  // 060725F6 mov.w 0x06072692,r1
    c.r[0] = c.r[2];  // 060725F8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725FA mov.b @(r0,r1),r1
    c.r[8] = 0x0u;  // 060725FC mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060725FE extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072600 cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[11]; if (k) { goto L_0607267A; } }  // 06072602 bt/s 0x0607267A ; mov r11,r9
    c.r[10] = ld32(0x060726C8u);  // 06072606 mov.l 0x060726C8,r10
L_06072608:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06072694u);  // 06072608 mov.w 0x06072694,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607260Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607260Eu) return; }  // 0607260A jsr @r10 ; nop
    c.r[2] = c.r[8];  // 0607260E mov r8,r2
    c.r[3] = ld32(c.r[9]);  // 06072610 mov.l @r9,r3
    c.r[2] += c.r[2];  // 06072612 add r2,r2
    c.r[0] = c.r[3];  // 06072614 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072616 mov.b @(r0,r2),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06072618 extu.b r1,r7
    c.r[1] = c.r[7];  // 0607261A mov r7,r1
    c.r[1] >>= 2;  // 0607261C shlr2 r1
    c.r[1] >>= 2;  // 0607261E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072620 shlr r1
    c.r[1] >>= 2;  // 06072622 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072624 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06072640; } }  // 06072626 bt/s 0x06072640 ; mov #1,r4
    c.r[0] = 0x7Fu;  // 0607262A mov #127,r0
    c.r[7] &= c.r[0];  // 0607262C and r0,r7
    c.r[3] += c.r[2];  // 0607262E add r2,r3
    c.r[3] += 1;  // 06072630 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072632 mov.b @r3,r1
    c.r[7] <<= 8;  // 06072634 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06072636 extu.b r1,r1
    c.r[1] |= c.r[7];  // 06072638 or r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607263A tst r1,r1
    if (c.t) { goto L_06072640; }  // 0607263C bt 0x06072640
    c.r[4] = 0x2u;  // 0607263E mov #2,r4
L_06072640:
    { const uint32_t x = c.r[10]; c.pr = 0x06072644u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072644u) return; }  // 06072640 jsr @r10 ; nop
    c.r[2] = c.r[8];  // 06072644 mov r8,r2
    c.r[2] += c.r[2];  // 06072646 add r2,r2
    c.r[1] = ld32(c.r[9]);  // 06072648 mov.l @r9,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072696u);  // 0607264A mov.w 0x06072696,r5
    c.r[0] = c.r[1];  // 0607264C mov r1,r0
    c.r[1] += c.r[2];  // 0607264E add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072650 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06072652 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072654 mov.b @r1,r4
    c.r[0] = 0x7Fu;  // 06072656 mov #127,r0
    c.r[3] &= c.r[0];  // 06072658 and r0,r3
    c.r[3] <<= 8;  // 0607265A shll8 r3
    c.r[4] = c.r[4] & 0xFFu;  // 0607265C extu.b r4,r4
    c.r[4] |= c.r[3];  // 0607265E or r3,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072698u);  // 06072660 mov.w 0x06072698,r1
    c.r[4] += c.r[1];  // 06072662 add r1,r4
    c.r[1] = ld32(0x060726CCu);  // 06072664 mov.l 0x060726CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607266Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607266Au) return; }  // 06072666 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[9]);  // 0607266A mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06072692u);  // 0607266C mov.w 0x06072692,r2
    c.r[0] = c.r[1];  // 0607266E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072670 mov.b @(r0,r2),r1
    c.r[8] += 1;  // 06072672 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06072674 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072676 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06072608; }  // 06072678 bf 0x06072608
L_0607267A:
    c.r[1] = ld32(0x060726D0u);  // 0607267A mov.l 0x060726D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072680u; c.r[4] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072680u) return; }  // 0607267C jsr @r1 ; mov #36,r4
    c.r[15] = c.r[14];  // 06072680 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06072682 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06072684 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06072686 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06072688 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607268A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607269Au);  // 0607268C mov.w 0x0607269A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607268E rts ; mov.l @r15+,r8
}

void f_060726D4(SH2Context& c) {
    ran[1600] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060726D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060726D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060726D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060726DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060726DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060726DE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060726E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060726E2 sts.l pr,@-r15
    c.r[15] -= 48;  // 060726E4 add #-48,r15
    c.r[14] = c.r[15];  // 060726E6 mov r15,r14
    c.r[1] = ld32(0x06072814u);  // 060726E8 mov.l 0x06072814,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060726EEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060726EEu) return; }  // 060726EA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072818u);  // 060726EE mov.l 0x06072818,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060726F4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060726F4u) return; }  // 060726F0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607281Cu);  // 060726F4 mov.l 0x0607281C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060726FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060726FAu) return; }  // 060726F6 jsr @r1 ; nop
    c.r[1] = ld32(0x06072820u);  // 060726FA mov.l 0x06072820,r1
    c.r[1] = ld32(c.r[1]);  // 060726FC mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607280Cu);  // 060726FE mov.w 0x0607280C,r2
    c.r[0] = c.r[1];  // 06072700 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072702 mov.b @(r0,r2),r1
    c.r[10] = c.r[1] & 0xFFu;  // 06072704 extu.b r1,r10
    c.r[1] = ld32(0x06072824u);  // 06072706 mov.l 0x06072824,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072708 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607270A extu.b r1,r2
    c.r[1] = ld32(0x06072828u);  // 0607270C mov.l 0x06072828,r1
    c.r[0] = c.r[2];  // 0607270E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072710 mov.b @(r0,r1),r1
    c.r[10] += 1;  // 06072712 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06072714 extu.b r1,r1
    c.r[1] -= 1;  // 06072716 add #-1,r1
    c.r[2] = 0xBu;  // 06072718 mov #11,r2
    c.macl = c.r[1] * c.r[2];  // 0607271A mul.l r2,r1
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 0607271C shar r10
    c.r[0] = c.r[10];  // 0607271E mov r10,r0
    c.r[1] = c.macl;  // 06072720 sts macl,r1
    c.r[0] -= c.r[1];  // 06072722 sub r1,r0
    c.r[1] = c.r[0];  // 06072724 mov r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06072726 cmp/gt r2,r1
    { const bool k = !c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_0607272E; } }  // 06072728 bf/s 0x0607272E ; extu.b r1,r1
    c.r[1] = c.r[2];  // 0607272C mov r2,r1
L_0607272E:
    c.r[12] = c.r[1];  // 0607272E mov r1,r12
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607280Eu);  // 06072730 mov.w 0x0607280E,r9
    c.r[1] += c.r[1];  // 06072732 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06072734 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072736 mov.l r1,@-r15
    c.r[1] = ld32(0x0607282Cu);  // 06072738 mov.l 0x0607282C,r1
    c.r[7] = 0x24u;  // 0607273A mov #36,r7
    c.r[6] = 0x4u;  // 0607273C mov #4,r6
    c.r[5] = 0x1u;  // 0607273E mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072744u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072744u) return; }  // 06072740 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x06072830u);  // 06072744 mov.l 0x06072830,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607274Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607274Au) return; }  // 06072746 jsr @r1 ; mov #1,r4
    c.r[0] = ld32(0x06072824u);  // 0607274A mov.l 0x06072824,r0
    c.r[13] = ld32(0x06072828u);  // 0607274C mov.l 0x06072828,r13
    c.r[11] = ld32(0x06072834u);  // 0607274E mov.l 0x06072834,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06072750 mov.b @r0,r1
    c.r[5] = 0x0u;  // 06072752 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06072754 extu.b r1,r1
    c.r[0] = c.r[1];  // 06072756 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06072758 mov.b @(r0,r13),r6
    c.r[4] = 0x0u;  // 0607275A mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072760u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072760u) return; }  // 0607275C jsr @r11 ; extu.b r6,r6
    c.r[2] = c.r[10];  // 06072760 mov r10,r2
    c.r[2] += 10;  // 06072762 add #10,r2
    c.r[1] = ld32(0x06072838u);  // 06072764 mov.l 0x06072838,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06072766 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06072768 mov #0,r5
    c.r[4] = 0x0u;  // 0607276A mov #0,r4
    c.r[6] = c.mach;  // 0607276C sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0607276E shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06072770 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06072772 subc r2,r2
    { const uint32_t x = c.r[11]; c.pr = 0x06072778u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072778u) return; }  // 06072774 jsr @r11 ; sub r2,r6
    c.r[8] = ld32(0x0607283Cu);  // 06072778 mov.l 0x0607283C,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072810u);  // 0607277A mov.w 0x06072810,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607277C mov.b @r8,r4
    c.r[4] = c.r[4] & 0xFFu;  // 0607277E extu.b r4,r4
    c.r[4] |= c.r[1];  // 06072780 or r1,r4
    c.r[1] = ld32(0x06072840u);  // 06072782 mov.l 0x06072840,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072788u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072788u) return; }  // 06072784 jsr @r1 ; mov r9,r5
    c.r[0] = ld32(0x06072824u);  // 06072788 mov.l 0x06072824,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0607278A mov.b @r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607278C extu.b r1,r3
    c.r[0] = c.r[3];  // 0607278E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06072790 mov.b @(r0,r13),r1
    c.r[9] = 0x16u;  // 06072792 mov #22,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06072794 extu.b r1,r1
    c.r[1] -= 1;  // 06072796 add #-1,r1
    c.macl = c.r[1] * c.r[9];  // 06072798 mul.l r9,r1
    c.r[1] = ld32(0x06072844u);  // 0607279A mov.l 0x06072844,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607279C mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0607279E sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060727A0 extu.b r1,r1
    c.r[2] += c.r[1];  // 060727A2 add r1,r2
    c.r[0] = ld32(0x06072820u);  // 060727A4 mov.l 0x06072820,r0
    c.r[1] = ld32(c.r[0]);  // 060727A6 mov.l @r0,r1
    c.r[2] += c.r[2];  // 060727A8 add r2,r2
    c.r[1] += c.r[2];  // 060727AA add r2,r1
    c.r[1] += 1;  // 060727AC add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060727AE mov.b @r1,r5
    c.r[4] = c.r[14];  // 060727B0 mov r14,r4
    c.r[1] = ld32(0x06072848u);  // 060727B2 mov.l 0x06072848,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060727B8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727B8u) return; }  // 060727B4 jsr @r1 ; extu.b r5,r5
    c.r[6] = 0x0u;  // 060727B8 mov #0,r6
    c.r[5] = c.r[14];  // 060727BA mov r14,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060727BC mov.b @r8,r4
    c.r[0] = ld32(0x0607284Cu);  // 060727BE mov.l 0x0607284C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060727C4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727C4u) return; }  // 060727C0 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 060727C4 mov r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060727C6 extu.b r1,r10
    c.r[15] += 4;  // 060727C8 add #4,r15
    c.t = (c.r[10] & c.r[10]) == 0;  // 060727CA tst r10,r10
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_060727D2; } }  // 060727CC bt/s 0x060727D2 ; mov #-1,r6
    c.r[6] = c.r[10];  // 060727D0 mov r10,r6
L_060727D2:
    c.r[5] = 0x0u;  // 060727D2 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060727D8u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727D8u) return; }  // 060727D4 jsr @r11 ; mov #48,r4
    c.r[1] = ld32(0x06072850u);  // 060727D8 mov.l 0x06072850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060727DEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727DEu) return; }  // 060727DA jsr @r1 ; mov r12,r4
    c.r[0] = ld32(0x06072820u);  // 060727DE mov.l 0x06072820,r0
    c.r[1] = ld32(c.r[0]);  // 060727E0 mov.l @r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607280Cu);  // 060727E2 mov.w 0x0607280C,r2
    c.r[0] = c.r[1];  // 060727E4 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060727E6 mov.b @(r0,r2),r3
    c.r[0] = ld32(0x06072824u);  // 060727E8 mov.l 0x06072824,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060727EA mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060727EC extu.b r1,r1
    c.r[0] = c.r[1];  // 060727EE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060727F0 mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060727F2 extu.b r1,r1
    c.r[1] -= 1;  // 060727F4 add #-1,r1
    c.macl = c.r[1] * c.r[9];  // 060727F6 mul.l r9,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060727F8 extu.b r3,r2
    c.r[1] = c.macl;  // 060727FA sts macl,r1
    c.r[2] -= c.r[1];  // 060727FC sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 060727FE cmp/gt r9,r2
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06072854; } }  // 06072800 bt/s 0x06072854 ; mov r3,r0
    c.r[0] -= c.r[1];  // 06072804 sub r1,r0
    c.r[1] = c.r[0];  // 06072806 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06072856;  // 06072808 bra 0x06072856 ; extu.b r1,r1
L_06072854:
    c.r[1] = c.r[9];  // 06072854 mov r9,r1
L_06072856:
    c.r[12] = c.r[1];  // 06072856 mov r1,r12
    c.r[13] = ld32(0x0607294Cu);  // 06072858 mov.l 0x0607294C,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072946u);  // 0607285A mov.w 0x06072946,r0
    c.r[11] = ld32(0x06072950u);  // 0607285C mov.l 0x06072950,r11
    c.r[9] = ld32(0x06072954u);  // 0607285E mov.l 0x06072954,r9
    c.r[1] = ld32(c.r[13]);  // 06072860 mov.l @r13,r1
    c.r[8] = 0x16u;  // 06072862 mov #22,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072864 mov.b @(r0,r1),r2
    c.r[3] = 0x1u;  // 06072866 mov #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06072868 mov.b @r11,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607286A extu.b r2,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0607286C extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607286E mov.b @(r0,r9),r1
    c.r[10] = c.r[2];  // 06072870 mov r2,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06072872 extu.b r1,r1
    c.r[1] -= 1;  // 06072874 add #-1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06072876 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06072878 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607287A mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607287C mov.l r3,@-r15
    c.macl = c.r[1] * c.r[8];  // 0607287E mul.l r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06072880 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06072882 mov.l r3,@-r15
    c.r[1] = c.macl;  // 06072884 sts macl,r1
    c.r[10] -= c.r[1];  // 06072886 sub r1,r10
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[10];  // 06072888 cmp/ge r10,r3
    c.r[10] = c.t;  // 0607288A movt r10
    c.r[1] = 0x0u;  // 0607288C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607288E mov.l r1,@-r15
    c.r[1] = 0x7u;  // 06072890 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072892 mov.l r1,@-r15
    c.t = (c.r[10] & c.r[10]) == 0;  // 06072894 tst r10,r10
    { const bool k = c.t; c.r[1] = 0xBu; if (k) { goto L_0607289C; } }  // 06072896 bt/s 0x0607289C ; mov #11,r1
    c.r[1] = c.r[3];  // 0607289A mov r3,r1
L_0607289C:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607289C mov.l r1,@-r15
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060728A4; } }  // 0607289E bt/s 0x060728A4 ; mov #2,r1
    c.r[1] = c.r[3];  // 060728A2 mov r3,r1
L_060728A4:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060728A4 mov.l r1,@-r15
    c.r[1] = ld32(0x06072958u);  // 060728A6 mov.l 0x06072958,r1
    c.r[7] = 0x2u;  // 060728A8 mov #2,r7
    c.r[6] = 0xDu;  // 060728AA mov #13,r6
    c.r[5] = 0x5u;  // 060728AC mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060728B2u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060728B2u) return; }  // 060728AE jsr @r1 ; mov #3,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060728B2 mov.b @r11,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060728B4 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060728B6 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060728B8 extu.b r1,r1
    c.r[1] -= 1;  // 060728BA add #-1,r1
    c.macl = c.r[1] * c.r[8];  // 060728BC mul.l r8,r1
    c.r[10] = c.macl;  // 060728BE sts macl,r10
    c.r[1] = c.macl;  // 060728C0 sts macl,r1
    c.r[1] += c.r[12];  // 060728C2 add r12,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060728C4 cmp/ge r1,r10
    { const bool k = c.t; c.r[15] += 40; if (k) { goto L_060729C6; } }  // 060728C6 bt/s 0x060729C6 ; add #40,r15
    c.r[11] = ld32(0x0607295Cu);  // 060728CA mov.l 0x0607295C,r11
    c.r[9] = c.macl;  // 060728CC sts macl,r9
    c.r[9] += c.r[9];  // 060728CE add r9,r9
L_060728D0:
    c.r[1] = ld32(c.r[13]);  // 060728D0 mov.l @r13,r1
    c.r[1] += c.r[9];  // 060728D2 add r9,r1
    c.r[1] += 1;  // 060728D4 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060728D6 mov.b @r1,r4
    c.r[0] = ld32(0x06072960u);  // 060728D8 mov.l 0x06072960,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060728DEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060728DEu) return; }  // 060728DA jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 060728DE extu.b r0,r2
    c.r[1] = ld32(0x06072964u);  // 060728E0 mov.l 0x06072964,r1
    c.r[3] = c.r[2];  // 060728E2 mov r2,r3
    c.r[7] = ld32(c.r[1]);  // 060728E4 mov.l @r1,r7
    c.r[3] <<= 2;  // 060728E6 shll2 r3
    c.r[3] <<= 2;  // 060728E8 shll2 r3
    c.r[3] += c.r[7];  // 060728EA add r7,r3
    c.r[1] = c.r[3];  // 060728EC mov r3,r1
    c.r[1] += 4;  // 060728EE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060728F0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060728F2 mov r1,r0
    c.r[0] >>= 2;  // 060728F4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060728F6 shlr r0
    c.r[0] >>= 2;  // 060728F8 shlr2 r0
    c.r[0] &= 0x1u;  // 060728FA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060728FC tst r0,r0
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0607290A; } }  // 060728FE bt/s 0x0607290A ; shll2 r2
    c.r[3] += 6;  // 06072902 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072904 mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06072906 extu.b r1,r2
    c.r[2] <<= 2;  // 06072908 shll2 r2
L_0607290A:
    c.r[2] <<= 2;  // 0607290A shll2 r2
    c.r[2] += c.r[7];  // 0607290C add r7,r2
    c.r[2] += 7;  // 0607290E add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06072910 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06072912 mov r1,r0
    c.r[0] >>= 2;  // 06072914 shlr2 r0
    c.r[0] >>= 2;  // 06072916 shlr2 r0
    c.r[0] &= 0x1u;  // 06072918 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607291A tst r0,r0
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_06072922; } }  // 0607291C bt/s 0x06072922 ; mov #0,r4
    c.r[4] = 0x2Du;  // 06072920 mov #45,r4
L_06072922:
    { const uint32_t x = c.r[11]; c.pr = 0x06072926u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072926u) return; }  // 06072922 jsr @r11 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x06072948u);  // 06072926 mov.w 0x06072948,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607292Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607292Cu) return; }  // 06072928 jsr @r11 ; nop
    c.r[1] = ld32(c.r[13]);  // 0607292C mov.l @r13,r1
    c.r[0] = c.r[1];  // 0607292E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06072930 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06072932 extu.b r1,r1
    c.r[1] >>= 2;  // 06072934 shlr2 r1
    c.r[1] >>= 2;  // 06072936 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072938 shlr r1
    c.r[1] >>= 2;  // 0607293A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607293C tst r1,r1
    if (c.t) { goto L_06072968; }  // 0607293E bt 0x06072968
    c.r[4] = 0x2u;  // 06072940 mov #2,r4
    goto L_0607296A;  // 06072942 bra 0x0607296A ; nop
L_06072968:
    c.r[4] = 0x1u;  // 06072968 mov #1,r4
L_0607296A:
    { const uint32_t x = c.r[11]; c.pr = 0x0607296Eu; c.r[10] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607296Eu) return; }  // 0607296A jsr @r11 ; add #1,r10
    c.r[1] = ld32(c.r[13]);  // 0607296E mov.l @r13,r1
    c.r[1] += c.r[9];  // 06072970 add r9,r1
    c.r[1] += 1;  // 06072972 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072974 mov.b @r1,r1
    c.r[0] = ld32(0x06072A18u);  // 06072976 mov.l 0x06072A18,r0
    c.r[2] = c.r[1] & 0xFFu;  // 06072978 extu.b r1,r2
    c.r[8] = c.r[2];  // 0607297A mov r2,r8
    c.r[8] += c.r[8];  // 0607297C add r8,r8
    c.r[8] += c.r[2];  // 0607297E add r2,r8
    c.r[1] = ld32(c.r[0]);  // 06072980 mov.l @r0,r1
    c.r[8] <<= 2;  // 06072982 shll2 r8
    c.r[0] = c.r[8];  // 06072984 mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06072986 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072A10u);  // 06072988 mov.w 0x06072A10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072A12u);  // 0607298A mov.w 0x06072A12,r1
    c.r[4] += c.r[1];  // 0607298C add r1,r4
    c.r[1] = ld32(0x06072A1Cu);  // 0607298E mov.l 0x06072A1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072994u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072994u) return; }  // 06072990 jsr @r1 ; extu.w r4,r4
    c.r[0] = ld32(0x06072A18u);  // 06072994 mov.l 0x06072A18,r0
    c.r[5] = 0x0u;  // 06072996 mov #0,r5
    c.r[1] = ld32(c.r[0]);  // 06072998 mov.l @r0,r1
    c.r[4] = 0x0u;  // 0607299A mov #0,r4
    c.r[8] += c.r[1];  // 0607299C add r1,r8
    c.r[8] += 10;  // 0607299E add #10,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060729A0 mov.w @r8,r6
    c.r[1] = ld32(0x06072A20u);  // 060729A2 mov.l 0x06072A20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060729A8u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729A8u) return; }  // 060729A4 jsr @r1 ; extu.w r6,r6
    c.r[1] = ld32(0x06072A24u);  // 060729A8 mov.l 0x06072A24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060729AA mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060729AC extu.b r1,r2
    c.r[1] = ld32(0x06072A28u);  // 060729AE mov.l 0x06072A28,r1
    c.r[0] = c.r[2];  // 060729B0 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060729B2 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 060729B4 extu.b r2,r2
    c.r[2] -= 1;  // 060729B6 add #-1,r2
    c.r[1] = 0x16u;  // 060729B8 mov #22,r1
    c.macl = c.r[2] * c.r[1];  // 060729BA mul.l r1,r2
    c.r[1] = c.macl;  // 060729BC sts macl,r1
    c.r[1] += c.r[12];  // 060729BE add r12,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060729C0 cmp/ge r1,r10
    { const bool k = !c.t; c.r[9] += 2; if (k) { SH2_POLL(c); goto L_060728D0; } }  // 060729C2 bf/s 0x060728D0 ; add #2,r9
L_060729C6:
    c.r[0] = 0x1u;  // 060729C6 mov #1,r0
    c.r[12] &= c.r[0];  // 060729C8 and r0,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 060729CA tst r12,r12
    if (c.t) { goto L_060729F2; }  // 060729CC bt 0x060729F2
    c.r[8] = ld32(0x06072A2Cu);  // 060729CE mov.l 0x06072A2C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060729D4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729D4u) return; }  // 060729D0 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729D8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729D8u) return; }  // 060729D4 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729DCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729DCu) return; }  // 060729D8 jsr @r8 ; mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072A10u);  // 060729DC mov.w 0x06072A10,r5
    c.r[4] = ld32(0x06072A30u);  // 060729DE mov.l 0x06072A30,r4
    c.r[1] = ld32(0x06072A1Cu);  // 060729E0 mov.l 0x06072A1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060729E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729E6u) return; }  // 060729E2 jsr @r1 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060729EAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729EAu) return; }  // 060729E6 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729EEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729EEu) return; }  // 060729EA jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729F2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729F2u) return; }  // 060729EE jsr @r8 ; mov #0,r4
L_060729F2:
    c.r[1] = ld32(0x06072A34u);  // 060729F2 mov.l 0x06072A34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060729F8u; c.r[4] = 0x25u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729F8u) return; }  // 060729F4 jsr @r1 ; mov #37,r4
    c.r[14] += 48;  // 060729F8 add #48,r14
    c.r[15] = c.r[14];  // 060729FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060729FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060729FE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06072A00 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06072A02 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06072A04 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06072A06 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06072A08 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072A14u);  // 06072A0A mov.w 0x06072A14,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06072A0C rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
