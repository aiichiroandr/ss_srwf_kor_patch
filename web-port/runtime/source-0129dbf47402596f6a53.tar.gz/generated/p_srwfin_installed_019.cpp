#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0604BDA0(SH2Context& c) {
    ran[1228] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604BDA0 mov.l r14,@-r15
    c.r[3] = ld32(0x0604BDD4u);  // 0604BDA2 mov.l 0x0604BDD4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604BDA4 mov.w @r3,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604BDA6 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604BDA8 tst r2,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604BDCC; } }  // 0604BDAA bt/s 0x0604BDCC ; mov r15,r14
    c.r[2] >>= 2;  // 0604BDAE shlr2 r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604BDB0 tst r2,r2
    if (!c.t) { goto L_0604BDB6; }  // 0604BDB2 bf 0x0604BDB6
    c.r[2] = 0x1u;  // 0604BDB4 mov #1,r2
L_0604BDB6:
    c.r[1] -= c.r[2];  // 0604BDB6 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0604BDB8 mov.w r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604BDBA mov.w @r4,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0604BDBC extu.w r3,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604BDBE cmp/gt r2,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0604BDC8; } }  // 0604BDC0 bf/s 0x0604BDC8 ; mov r3,r1
    c.r[1] -= c.r[2]; goto L_0604BDCA;  // 0604BDC4 bra 0x0604BDCA ; sub r2,r1
L_0604BDC8:
    c.r[1] = 0x0u;  // 0604BDC8 mov #0,r1
L_0604BDCA:
    st16(c.r[4], c.r[1]);  // 0604BDCA mov.w r1,@r4
L_0604BDCC:
    c.r[15] = c.r[14];  // 0604BDCC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604BDCE rts ; mov.l @r15+,r14
}

void f_0604BDD8(SH2Context& c) {
    ran[1229] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604BDD8 mov.l r14,@-r15
    c.r[3] = ld32(0x0604BE14u);  // 0604BDDA mov.l 0x0604BE14,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604BDDC mov.w @r3,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604BDDE extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604BDE0 tst r2,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604BE0C; } }  // 0604BDE2 bt/s 0x0604BE0C ; mov r15,r14
    c.r[2] >>= 2;  // 0604BDE6 shlr2 r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604BDE8 tst r2,r2
    if (!c.t) { goto L_0604BDEE; }  // 0604BDEA bf 0x0604BDEE
    c.r[2] = 0x1u;  // 0604BDEC mov #1,r2
L_0604BDEE:
    c.r[1] -= c.r[2];  // 0604BDEE sub r2,r1
    st16(c.r[3], c.r[1]);  // 0604BDF0 mov.w r1,@r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604BDF2 mov.w @r4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BE12u);  // 0604BDF4 mov.w 0x0604BE12,r1
    c.r[3] = c.r[7] & 0xFFFFu;  // 0604BDF6 extu.w r7,r3
    c.t = c.r[3] == c.r[1];  // 0604BDF8 cmp/eq r1,r3
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0604BE0E; } }  // 0604BDFA bt/s 0x0604BE0E ; mov r14,r15
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0604BDFE cmp/gt r2,r3
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0604BE08; } }  // 0604BE00 bf/s 0x0604BE08 ; mov r7,r1
    c.r[1] -= c.r[2]; goto L_0604BE0A;  // 0604BE04 bra 0x0604BE0A ; sub r2,r1
L_0604BE08:
    c.r[1] = 0x0u;  // 0604BE08 mov #0,r1
L_0604BE0A:
    st16(c.r[4], c.r[1]);  // 0604BE0A mov.w r1,@r4
L_0604BE0C:
    c.r[15] = c.r[14];  // 0604BE0C mov r14,r15
L_0604BE0E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604BE0E rts ; mov.l @r15+,r14
}

void f_0604BE18(SH2Context& c) {
    ran[1230] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604BE18 mov.l r14,@-r15
    c.r[3] = ld32(0x0604BE58u);  // 0604BE1A mov.l 0x0604BE58,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604BE1C mov.w @r3,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604BE1E extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604BE20 tst r2,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604BE4E; } }  // 0604BE22 bt/s 0x0604BE4E ; mov r15,r14
    c.r[2] >>= 2;  // 0604BE26 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604BE28 shlr r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604BE2A tst r2,r2
    if (!c.t) { goto L_0604BE30; }  // 0604BE2C bf 0x0604BE30
    c.r[2] = 0x1u;  // 0604BE2E mov #1,r2
L_0604BE30:
    c.r[1] -= c.r[2];  // 0604BE30 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0604BE32 mov.w r1,@r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604BE34 mov.w @r4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BE54u);  // 0604BE36 mov.w 0x0604BE54,r1
    c.r[3] = c.r[7] & 0xFFFFu;  // 0604BE38 extu.w r7,r3
    c.t = c.r[3] == c.r[1];  // 0604BE3A cmp/eq r1,r3
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0604BE50; } }  // 0604BE3C bt/s 0x0604BE50 ; mov r14,r15
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0604BE40 cmp/gt r2,r3
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0604BE4A; } }  // 0604BE42 bf/s 0x0604BE4A ; mov r7,r1
    c.r[1] -= c.r[2]; goto L_0604BE4C;  // 0604BE46 bra 0x0604BE4C ; sub r2,r1
L_0604BE4A:
    c.r[1] = 0x0u;  // 0604BE4A mov #0,r1
L_0604BE4C:
    st16(c.r[4], c.r[1]);  // 0604BE4C mov.w r1,@r4
L_0604BE4E:
    c.r[15] = c.r[14];  // 0604BE4E mov r14,r15
L_0604BE50:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604BE50 rts ; mov.l @r15+,r14
}

void f_0604BE5C(SH2Context& c) {
    ran[1231] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604BE5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604BE5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604BE60 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604BE62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604BE64 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604BE66 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604BE68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604BE6A sts.l pr,@-r15
    c.r[15] -= 8;  // 0604BE6C add #-8,r15
    c.r[14] = c.r[15];  // 0604BE6E mov r15,r14
    c.r[12] = c.r[5];  // 0604BE70 mov r5,r12
    c.r[13] = c.r[6];  // 0604BE72 mov r6,r13
    c.r[9] = c.r[4] & 0xFFu;  // 0604BE74 extu.b r4,r9
    c.r[1] = 0x2u;  // 0604BE76 mov #2,r1
    c.r[1] &= c.r[9];  // 0604BE78 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BE7A tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0604BE82; } }  // 0604BE7C bf/s 0x0604BE82 ; mov #0,r2
    c.r[2] = 0x13u;  // 0604BE80 mov #19,r2
L_0604BE82:
    c.r[1] = 0x1u;  // 0604BE82 mov #1,r1
    c.r[1] &= c.r[9];  // 0604BE84 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BE86 tst r1,r1
    if (c.t) { goto L_0604BE90; }  // 0604BE88 bt 0x0604BE90
    c.r[2] += 9;  // 0604BE8A add #9,r2
    c.r[1] = c.r[2] & 0xFFFFu; goto L_0604BE94;  // 0604BE8C bra 0x0604BE94 ; extu.w r2,r1
L_0604BE90:
    c.r[2] += 11;  // 0604BE90 add #11,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0604BE92 extu.w r2,r1
L_0604BE94:
    c.r[10] = c.r[1];  // 0604BE94 mov r1,r10
    c.r[8] = 0x1u;  // 0604BE96 mov #1,r8
    c.r[8] &= c.r[9];  // 0604BE98 and r9,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604BE9A tst r8,r8
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_0604BEA2; } }  // 0604BE9C bt/s 0x0604BEA2 ; mov #0,r3
    c.r[3] = 0x2u;  // 0604BEA0 mov #2,r3
L_0604BEA2:
    c.r[11] = c.r[3];  // 0604BEA2 mov r3,r11
    c.r[0] = ld32(0x0604BF9Cu);  // 0604BEA4 mov.l 0x0604BF9C,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0604BEA6 mov.w @r12,r4
    c.r[5] = c.r[14];  // 0604BEA8 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604BEAEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BEAEu) return; }  // 0604BEAA jsr @r0 ; extu.w r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0604BEAE mov.w @r12,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604BF86u);  // 0604BEB0 mov.w 0x0604BF86,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604BEB2 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0604BEB4 cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] = c.r[0]; if (k) { goto L_0604BEF4; } }  // 0604BEB6 bf/s 0x0604BEF4 ; mov r0,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604BEBA tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_0604BEF6; } }  // 0604BEBC bt/s 0x0604BEF6 ; mov r13,r0
    c.r[3] = c.r[11];  // 0604BEC0 mov r11,r3
    c.r[3] <<= 2;  // 0604BEC2 shll2 r3
    c.r[3] <<= 2;  // 0604BEC4 shll2 r3
    c.r[3] <<= 2;  // 0604BEC6 shll2 r3
    c.r[3] += c.r[10];  // 0604BEC8 add r10,r3
    c.r[3] += c.r[3];  // 0604BECA add r3,r3
    c.r[2] = ld32(0x0604BFA0u);  // 0604BECC mov.l 0x0604BFA0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF88u);  // 0604BECE mov.w 0x0604BF88,r1
    c.r[0] = c.r[3];  // 0604BED0 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604BED2 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604BFA4u);  // 0604BED4 mov.l 0x0604BFA4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF8Au);  // 0604BED6 mov.w 0x0604BF8A,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604BED8 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604BFA8u);  // 0604BEDA mov.l 0x0604BFA8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF8Cu);  // 0604BEDC mov.w 0x0604BF8C,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604BEDE mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604BFACu);  // 0604BEE0 mov.l 0x0604BFAC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF8Eu);  // 0604BEE2 mov.w 0x0604BF8E,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604BEE4 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604BFB0u);  // 0604BEE6 mov.l 0x0604BFB0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF90u);  // 0604BEE8 mov.w 0x0604BF90,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604BEEA mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604BFB4u);  // 0604BEEC mov.l 0x0604BFB4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF92u);  // 0604BEEE mov.w 0x0604BF92,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_0604BFF4;  // 0604BEF0 bra 0x0604BFF4 ; mov.w r1,@(r0,r2)
L_0604BEF4:
    c.r[0] = c.r[13];  // 0604BEF4 mov r13,r0
L_0604BEF6:
    c.t = c.r[0] == 0x1u;  // 0604BEF6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { goto L_0604BF38; } }  // 0604BEF8 bf/s 0x0604BF38 ; mov r5,r0
    c.t = c.r[0] == 0x5u;  // 0604BEFC cmp/eq #5,r0
    { const bool k = !c.t; c.r[0] = ~c.r[9]; if (k) { goto L_0604BF38; } }  // 0604BEFE bf/s 0x0604BF38 ; not r9,r0
    c.r[0] &= 0x1u;  // 0604BF02 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BF04 tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0604BF38; } }  // 0604BF06 bt/s 0x0604BF38 ; mov #0,r7
    c.r[4] = 0x4u;  // 0604BF0A mov #4,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604BF94u);  // 0604BF0C mov.w 0x0604BF94,r3
    c.r[5] = ld32(0x0604BFB8u);  // 0604BF0E mov.l 0x0604BFB8,r5
L_0604BF10:
    c.r[7] += 1;  // 0604BF10 add #1,r7
    c.r[1] = c.r[10];  // 0604BF12 mov r10,r1
    c.r[1] -= c.r[7];  // 0604BF14 sub r7,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604BF16 extu.w r1,r6
    c.r[2] = c.r[11];  // 0604BF18 mov r11,r2
    c.r[2] <<= 2;  // 0604BF1A shll2 r2
    c.r[2] <<= 2;  // 0604BF1C shll2 r2
    c.r[2] <<= 2;  // 0604BF1E shll2 r2
    c.r[2] += c.r[6];  // 0604BF20 add r6,r2
    c.r[2] += c.r[2];  // 0604BF22 add r2,r2
    c.r[1] = ld32(0x0604BFBCu);  // 0604BF24 mov.l 0x0604BFBC,r1
    c.r[0] = c.r[2];  // 0604BF26 mov r2,r0
    st16(c.r[0] + c.r[1], c.r[3]);  // 0604BF28 mov.w r3,@(r0,r1)
    c.r[1] = c.r[3];  // 0604BF2A mov r3,r1
    c.r[1] += 1;  // 0604BF2C add #1,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 0604BF2E cmp/gt r4,r7
    { const bool k = !c.t; st16(c.r[0] + c.r[5], c.r[1]); if (k) { SH2_POLL(c); goto L_0604BF10; } }  // 0604BF30 bf/s 0x0604BF10 ; mov.w r1,@(r0,r5)
    c.r[8] = c.r[12]; goto L_0604BFF6;  // 0604BF34 bra 0x0604BFF6 ; mov r12,r8
L_0604BF38:
    c.r[13] = 0x0u;  // 0604BF38 mov #0,r13
    c.r[7] = 0x0u;  // 0604BF3A mov #0,r7
    c.r[1] = 0x1u;  // 0604BF3C mov #1,r1
    c.r[1] &= c.r[9];  // 0604BF3E and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BF40 tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0604BF4E; } }  // 0604BF42 bf/s 0x0604BF4E ; mov #0,r2
L_0604BF46:
    c.r[1] = 0x4u;  // 0604BF46 mov #4,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604BF48 cmp/gt r1,r2
    { const bool k = c.t; c.r[8] = c.r[12]; if (k) { goto L_0604BFF6; } }  // 0604BF4A bt/s 0x0604BFF6 ; mov r12,r8
L_0604BF4E:
    c.r[1] = c.r[7];  // 0604BF4E mov r7,r1
L_0604BF50:
    c.r[1] += 1;  // 0604BF50 add #1,r1
    c.r[0] = c.r[10];  // 0604BF52 mov r10,r0
    c.r[0] -= c.r[1];  // 0604BF54 sub r1,r0
    c.r[1] = c.r[0];  // 0604BF56 mov r0,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 0604BF58 cmp/ge r5,r7
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { goto L_0604BF70; } }  // 0604BF5A bf/s 0x0604BF70 ; extu.w r1,r6
    c.r[1] = 0x1u;  // 0604BF5E mov #1,r1
    c.r[1] &= c.r[9];  // 0604BF60 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BF62 tst r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF96u);  // 0604BF64 mov.w 0x0604BF96,r1
    { const bool k = c.t; c.r[3] = c.r[1]; if (k) { goto L_0604BFCA; } }  // 0604BF66 bt/s 0x0604BFCA ; mov r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604BF98u);  // 0604BF6A mov.w 0x0604BF98,r1
    c.r[3] = c.r[1]; goto L_0604BFCA;  // 0604BF6C bra 0x0604BFCA ; mov r1,r3
L_0604BF70:
    c.r[0] = c.r[14];  // 0604BF70 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604BF72 mov.b @(r0,r7),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0604BF74 extu.b r1,r3
    c.r[3] += c.r[3];  // 0604BF76 add r3,r3
    c.r[1] = 0x1u;  // 0604BF78 mov #1,r1
    c.r[1] &= c.r[9];  // 0604BF7A and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BF7C tst r1,r1
    if (c.t) { goto L_0604BFC0; }  // 0604BF7E bt 0x0604BFC0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604BF9Au);  // 0604BF80 mov.w 0x0604BF9A,r2
    c.r[2] += c.r[3]; goto L_0604BFC4;  // 0604BF82 bra 0x0604BFC4 ; add r3,r2
L_0604BFC0:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604C0BEu);  // 0604BFC0 mov.w 0x0604C0BE,r2
    c.r[2] += c.r[3];  // 0604BFC2 add r3,r2
L_0604BFC4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0C0u);  // 0604BFC4 mov.w 0x0604C0C0,r1
    c.r[2] |= c.r[1];  // 0604BFC6 or r1,r2
    c.r[3] = c.r[2];  // 0604BFC8 mov r2,r3
L_0604BFCA:
    c.r[1] = c.r[11];  // 0604BFCA mov r11,r1
    c.r[1] <<= 2;  // 0604BFCC shll2 r1
    c.r[1] <<= 2;  // 0604BFCE shll2 r1
    c.r[1] <<= 2;  // 0604BFD0 shll2 r1
    c.r[1] += c.r[6];  // 0604BFD2 add r6,r1
    c.r[1] += c.r[1];  // 0604BFD4 add r1,r1
    c.r[0] = ld32(0x0604C0D8u);  // 0604BFD6 mov.l 0x0604C0D8,r0
    st16(c.r[0] + c.r[1], c.r[3]);  // 0604BFD8 mov.w r3,@(r0,r1)
    c.r[0] = ld32(0x0604C0DCu);  // 0604BFDA mov.l 0x0604C0DC,r0
    c.r[3] += 1;  // 0604BFDC add #1,r3
    st16(c.r[0] + c.r[1], c.r[3]);  // 0604BFDE mov.w r3,@(r0,r1)
    c.r[7] += 1;  // 0604BFE0 add #1,r7
    c.r[1] = 0x1u;  // 0604BFE2 mov #1,r1
    c.r[1] &= c.r[9];  // 0604BFE4 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BFE6 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { SH2_POLL(c); goto L_0604BF46; } }  // 0604BFE8 bt/s 0x0604BF46 ; mov r7,r2
    c.r[1] = 0x2u;  // 0604BFEC mov #2,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0604BFEE cmp/gt r1,r7
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { SH2_POLL(c); goto L_0604BF50; } }  // 0604BFF0 bf/s 0x0604BF50 ; mov r7,r1
L_0604BFF4:
    c.r[8] = c.r[12];  // 0604BFF4 mov r12,r8
L_0604BFF6:
    c.r[8] += 2;  // 0604BFF6 add #2,r8
    c.r[0] = ld32(0x0604C0E0u);  // 0604BFF8 mov.l 0x0604C0E0,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604BFFA mov.w @r8,r4
    c.r[5] = c.r[14];  // 0604BFFC mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604C002u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C002u) return; }  // 0604BFFE jsr @r0 ; extu.w r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604C002 mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604C0C2u);  // 0604C004 mov.w 0x0604C0C2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604C006 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0604C008 cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] = c.r[0]; if (k) { goto L_0604C04C; } }  // 0604C00A bf/s 0x0604C04C ; mov r0,r5
    c.r[1] = 0x1u;  // 0604C00E mov #1,r1
    c.r[1] &= c.r[9];  // 0604C010 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C012 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_0604C04E; } }  // 0604C014 bt/s 0x0604C04E ; mov r13,r0
    c.r[3] = c.r[11];  // 0604C018 mov r11,r3
    c.r[3] <<= 2;  // 0604C01A shll2 r3
    c.r[3] <<= 2;  // 0604C01C shll2 r3
    c.r[3] <<= 2;  // 0604C01E shll2 r3
    c.r[3] += c.r[10];  // 0604C020 add r10,r3
    c.r[3] += c.r[3];  // 0604C022 add r3,r3
    c.r[2] = ld32(0x0604C0E4u);  // 0604C024 mov.l 0x0604C0E4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0C4u);  // 0604C026 mov.w 0x0604C0C4,r1
    c.r[0] = c.r[3];  // 0604C028 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C02A mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C0E8u);  // 0604C02C mov.l 0x0604C0E8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0C6u);  // 0604C02E mov.w 0x0604C0C6,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C030 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C0ECu);  // 0604C032 mov.l 0x0604C0EC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0C8u);  // 0604C034 mov.w 0x0604C0C8,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C036 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C0F0u);  // 0604C038 mov.l 0x0604C0F0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0CAu);  // 0604C03A mov.w 0x0604C0CA,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C03C mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C0F4u);  // 0604C03E mov.l 0x0604C0F4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0CCu);  // 0604C040 mov.w 0x0604C0CC,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C042 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C0F8u);  // 0604C044 mov.l 0x0604C0F8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0CEu);  // 0604C046 mov.w 0x0604C0CE,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_0604C150;  // 0604C048 bra 0x0604C150 ; mov.w r1,@(r0,r2)
L_0604C04C:
    c.r[0] = c.r[13];  // 0604C04C mov r13,r0
L_0604C04E:
    c.t = c.r[0] == 0x1u;  // 0604C04E cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { goto L_0604C08E; } }  // 0604C050 bf/s 0x0604C08E ; mov r5,r0
    c.t = c.r[0] == 0x5u;  // 0604C054 cmp/eq #5,r0
    { const bool k = !c.t; c.r[0] = ~c.r[9]; if (k) { goto L_0604C08E; } }  // 0604C056 bf/s 0x0604C08E ; not r9,r0
    c.r[0] &= 0x1u;  // 0604C05A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604C05C tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0604C090; } }  // 0604C05E bt/s 0x0604C090 ; mov #0,r7
    c.r[12] = 0x4u;  // 0604C062 mov #4,r12
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604C0D0u);  // 0604C064 mov.w 0x0604C0D0,r3
    c.r[9] = 0x40u;  // 0604C066 mov #64,r9
    c.r[4] = ld32(0x0604C0D8u);  // 0604C068 mov.l 0x0604C0D8,r4
    c.r[5] = ld32(0x0604C0DCu);  // 0604C06A mov.l 0x0604C0DC,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604C0D2u);  // 0604C06C mov.w 0x0604C0D2,r8
L_0604C06E:
    c.r[2] = c.r[7];  // 0604C06E mov r7,r2
    c.r[2] += 1;  // 0604C070 add #1,r2
    c.r[1] = c.r[10];  // 0604C072 mov r10,r1
    c.r[1] += c.r[2];  // 0604C074 add r2,r1
    c.macl = c.r[11] * c.r[9];  // 0604C076 mul.l r9,r11
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604C078 extu.w r1,r6
    c.r[7] = c.r[2];  // 0604C07A mov r2,r7
    c.r[0] = c.macl;  // 0604C07C sts macl,r0
    c.r[0] += c.r[6];  // 0604C07E add r6,r0
    c.r[0] += c.r[0];  // 0604C080 add r0,r0
    st16(c.r[0] + c.r[4], c.r[3]);  // 0604C082 mov.w r3,@(r0,r4)
    c.t = (int32_t)c.r[7] > (int32_t)c.r[12];  // 0604C084 cmp/gt r12,r7
    { const bool k = !c.t; st16(c.r[0] + c.r[5], c.r[8]); if (k) { SH2_POLL(c); goto L_0604C06E; } }  // 0604C086 bf/s 0x0604C06E ; mov.w r8,@(r0,r5)
    c.r[14] += 8; goto L_0604C152;  // 0604C08A bra 0x0604C152 ; add #8,r14
L_0604C08E:
    c.r[7] = 0x0u;  // 0604C08E mov #0,r7
L_0604C090:
    c.r[1] = 0x1u;  // 0604C090 mov #1,r1
    c.r[1] &= c.r[9];  // 0604C092 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C094 tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0604C0A0; } }  // 0604C096 bf/s 0x0604C0A0 ; mov #0,r2
L_0604C09A:
    c.r[1] = 0x4u;  // 0604C09A mov #4,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604C09C cmp/gt r1,r2
    if (c.t) { goto L_0604C150; }  // 0604C09E bt 0x0604C150
L_0604C0A0:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 0604C0A0 cmp/ge r5,r7
L_0604C0A2:
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0604C0FC; } }  // 0604C0A2 bf/s 0x0604C0FC ; mov r7,r1
    c.r[1] += 1;  // 0604C0A6 add #1,r1
    c.r[1] += c.r[10];  // 0604C0A8 add r10,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604C0AA extu.w r1,r6
    c.r[1] = 0x1u;  // 0604C0AC mov #1,r1
    c.r[1] &= c.r[9];  // 0604C0AE and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C0B0 tst r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0D4u);  // 0604C0B2 mov.w 0x0604C0D4,r1
    { const bool k = c.t; c.r[3] = c.r[1]; if (k) { goto L_0604C124; } }  // 0604C0B4 bt/s 0x0604C124 ; mov r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C0D6u);  // 0604C0B8 mov.w 0x0604C0D6,r1
    c.r[3] = c.r[1]; goto L_0604C124;  // 0604C0BA bra 0x0604C124 ; mov r1,r3
L_0604C0FC:
    c.r[1] = c.r[10];  // 0604C0FC mov r10,r1
    c.r[1] += c.r[5];  // 0604C0FE add r5,r1
    c.r[1] -= c.r[7];  // 0604C100 sub r7,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604C102 extu.w r1,r6
    c.r[0] = c.r[14];  // 0604C104 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604C106 mov.b @(r0,r7),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0604C108 extu.b r1,r3
    c.r[3] += c.r[3];  // 0604C10A add r3,r3
    c.r[1] = 0x1u;  // 0604C10C mov #1,r1
    c.r[1] &= c.r[9];  // 0604C10E and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C110 tst r1,r1
    if (c.t) { goto L_0604C11A; }  // 0604C112 bt 0x0604C11A
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604C166u);  // 0604C114 mov.w 0x0604C166,r2
    c.r[2] += c.r[3]; goto L_0604C11E;  // 0604C116 bra 0x0604C11E ; add r3,r2
L_0604C11A:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604C168u);  // 0604C11A mov.w 0x0604C168,r2
    c.r[2] += c.r[3];  // 0604C11C add r3,r2
L_0604C11E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C16Au);  // 0604C11E mov.w 0x0604C16A,r1
    c.r[2] |= c.r[1];  // 0604C120 or r1,r2
    c.r[3] = c.r[2];  // 0604C122 mov r2,r3
L_0604C124:
    c.r[1] = c.r[11];  // 0604C124 mov r11,r1
    c.r[1] <<= 2;  // 0604C126 shll2 r1
    c.r[1] <<= 2;  // 0604C128 shll2 r1
    c.r[1] <<= 2;  // 0604C12A shll2 r1
    c.r[1] += c.r[6];  // 0604C12C add r6,r1
    c.r[1] += c.r[1];  // 0604C12E add r1,r1
    c.r[0] = ld32(0x0604C16Cu);  // 0604C130 mov.l 0x0604C16C,r0
    st16(c.r[0] + c.r[1], c.r[3]);  // 0604C132 mov.w r3,@(r0,r1)
    c.r[0] = ld32(0x0604C170u);  // 0604C134 mov.l 0x0604C170,r0
    c.r[3] += 1;  // 0604C136 add #1,r3
    st16(c.r[0] + c.r[1], c.r[3]);  // 0604C138 mov.w r3,@(r0,r1)
    c.r[2] = c.r[7];  // 0604C13A mov r7,r2
    c.r[2] += 1;  // 0604C13C add #1,r2
    c.r[1] = 0x1u;  // 0604C13E mov #1,r1
    c.r[1] &= c.r[9];  // 0604C140 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C142 tst r1,r1
    { const bool k = c.t; c.r[7] = c.r[2]; if (k) { SH2_POLL(c); goto L_0604C09A; } }  // 0604C144 bt/s 0x0604C09A ; mov r2,r7
    c.r[1] = 0x2u;  // 0604C148 mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604C14A cmp/gt r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[7] >= (int32_t)c.r[5]; if (k) { SH2_POLL(c); goto L_0604C0A2; } }  // 0604C14C bf/s 0x0604C0A2 ; cmp/ge r5,r7
L_0604C150:
    c.r[14] += 8;  // 0604C150 add #8,r14
L_0604C152:
    c.r[15] = c.r[14];  // 0604C152 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604C154 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604C156 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604C158 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604C15A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604C15C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604C15E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604C160 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604C162 rts ; mov.l @r15+,r8
}

void f_0604C17C(SH2Context& c) {
    ran[1232] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604C17C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604C17E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604C180 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604C182 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604C184 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604C186 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604C188 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604C18A sts.l pr,@-r15
    c.r[15] -= 72;  // 0604C18C add #-72,r15
    c.r[14] = c.r[15];  // 0604C18E mov r15,r14
    st32(c.r[14] + 56, c.r[5]);  // 0604C190 mov.l r5,@(56,r14)
    c.r[4] = c.r[4] & 0xFFu;  // 0604C192 extu.b r4,r4
    c.r[0] = 0x44u;  // 0604C194 mov #68,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 0604C196 mov.l r4,@(r0,r14)
    c.r[6] = c.r[6] & 0xFFFFu;  // 0604C198 extu.w r6,r6
    st32(c.r[14] + 60, c.r[6]);  // 0604C19A mov.l r6,@(60,r14)
    c.r[10] = c.r[14];  // 0604C19C mov r14,r10
    c.r[10] += 24;  // 0604C19E add #24,r10
    c.r[1] = ld32(0x0604C3C0u);  // 0604C1A0 mov.l 0x0604C3C0,r1
    st32(c.r[14] + 24, c.r[1]);  // 0604C1A2 mov.l r1,@(24,r14)
    c.r[7] = ld32(0x0604C3C4u);  // 0604C1A4 mov.l 0x0604C3C4,r7
    st32(c.r[10] + 4, c.r[7]);  // 0604C1A6 mov.l r7,@(4,r10)
    c.r[2] = c.r[14];  // 0604C1A8 mov r14,r2
    c.r[2] += 32;  // 0604C1AA add #32,r2
    c.r[1] = ld32(0x0604C3C8u);  // 0604C1AC mov.l 0x0604C3C8,r1
    st32(c.r[14] + 32, c.r[1]);  // 0604C1AE mov.l r1,@(32,r14)
    c.r[3] = ld32(0x0604C3CCu);  // 0604C1B0 mov.l 0x0604C3CC,r3
    st32(c.r[2] + 4, c.r[3]);  // 0604C1B2 mov.l r3,@(4,r2)
    c.r[2] = c.r[14];  // 0604C1B4 mov r14,r2
    c.r[2] += 40;  // 0604C1B6 add #40,r2
    c.r[1] = ld32(0x0604C3D0u);  // 0604C1B8 mov.l 0x0604C3D0,r1
    st32(c.r[14] + 40, c.r[1]);  // 0604C1BA mov.l r1,@(40,r14)
    st32(c.r[2] + 4, c.r[7]);  // 0604C1BC mov.l r7,@(4,r2)
    c.r[2] = c.r[14];  // 0604C1BE mov r14,r2
    c.r[2] += 48;  // 0604C1C0 add #48,r2
    c.r[1] = ld32(0x0604C3D4u);  // 0604C1C2 mov.l 0x0604C3D4,r1
    st32(c.r[14] + 48, c.r[1]);  // 0604C1C4 mov.l r1,@(48,r14)
    st32(c.r[2] + 4, c.r[3]);  // 0604C1C6 mov.l r3,@(4,r2)
    c.r[1] = ld32(0x0604C3D8u);  // 0604C1C8 mov.l 0x0604C3D8,r1
    c.r[13] = ld32(0x0604C3DCu);  // 0604C1CA mov.l 0x0604C3DC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0604C1D0u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C1D0u) return; }  // 0604C1CC jsr @r13 ; mov.b @r1,r4
    c.r[4] = c.r[0];  // 0604C1D0 mov r0,r4
    c.r[5] = c.r[1];  // 0604C1D2 mov r1,r5
    c.r[1] = ld32(0x0604C3E0u);  // 0604C1D4 mov.l 0x0604C3E0,r1
    c.r[8] = ld32(c.r[1]);  // 0604C1D6 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0604C1D8 mov.l @(4,r1),r9
    c.r[0] = ld32(0x0604C3E4u);  // 0604C1DA mov.l 0x0604C3E4,r0
    c.r[6] = c.r[8];  // 0604C1DC mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604C1E2u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C1E2u) return; }  // 0604C1DE jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604C1E2 mov r0,r4
    c.r[11] = ld32(0x0604C3E8u);  // 0604C1E4 mov.l 0x0604C3E8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0604C1EAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C1EAu) return; }  // 0604C1E6 jsr @r11 ; mov r1,r5
    c.r[13] = 0x40u;  // 0604C1EA mov #64,r13
    c.r[13] += c.r[14];  // 0604C1EC add r14,r13
    st32(c.r[13], c.r[0]);  // 0604C1EE mov.l r0,@r13
    c.r[0] = 0x44u;  // 0604C1F0 mov #68,r0
    c.r[0] += c.r[14];  // 0604C1F2 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0604C1F4 mov.l @r0,r13
    c.r[13] <<= 2;  // 0604C1F6 shll2 r13
    c.r[13] += c.r[13];  // 0604C1F8 add r13,r13
    st32(c.r[0], c.r[13]);  // 0604C1FA mov.l r13,@r0
    c.r[13] = 0x44u;  // 0604C1FC mov #68,r13
    c.r[13] += c.r[14];  // 0604C1FE add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0604C200 mov.l @r13,r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0604C202 mov.l @(r0,r10),r1
    c.r[12] = c.r[14];  // 0604C204 mov r14,r12
    c.r[0] = 0x40u;  // 0604C206 mov #64,r0
    c.r[0] += c.r[14];  // 0604C208 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0604C20A mov.l @r0,r13
    c.r[12] += 12;  // 0604C20C add #12,r12
    c.r[13] += c.r[1];  // 0604C20E add r1,r13
    st32(c.r[0], c.r[13]);  // 0604C210 mov.l r13,@r0
    c.r[1] = ld32(0x0604C3ECu);  // 0604C212 mov.l 0x0604C3EC,r1
    c.r[0] = ld32(0x0604C3DCu);  // 0604C214 mov.l 0x0604C3DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604C21Au; c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C21Au) return; }  // 0604C216 jsr @r0 ; mov.b @r1,r4
    c.r[4] = c.r[0];  // 0604C21A mov r0,r4
    c.r[5] = c.r[1];  // 0604C21C mov r1,r5
    c.r[6] = c.r[8];  // 0604C21E mov r8,r6
    c.r[13] = ld32(0x0604C3E4u);  // 0604C220 mov.l 0x0604C3E4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0604C226u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C226u) return; }  // 0604C222 jsr @r13 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604C226 mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0604C22Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C22Cu) return; }  // 0604C228 jsr @r11 ; mov r1,r5
    c.r[2] = c.r[0];  // 0604C22C mov r0,r2
    c.r[0] = 0x44u;  // 0604C22E mov #68,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0604C230 mov.l @(r0,r14),r0
    c.r[7] = 0x7u;  // 0604C232 mov #7,r7
    c.r[10] += c.r[0];  // 0604C234 add r0,r10
    c.r[1] = ld32(c.r[10] + 4);  // 0604C236 mov.l @(4,r10),r1
    c.r[6] = 0x3Du;  // 0604C238 mov #61,r6
    c.r[2] += c.r[1];  // 0604C23A add r1,r2
    st32(c.r[12] + 4, c.r[2]);  // 0604C23C mov.l r2,@(4,r12)
    c.r[1] = ld32(0x0604C3F0u);  // 0604C23E mov.l 0x0604C3F0,r1
    st32(c.r[12] + 8, c.r[1]);  // 0604C240 mov.l r1,@(8,r12)
    c.r[1] = ld32(0x0604C3F4u);  // 0604C242 mov.l 0x0604C3F4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C244 mov.w @r1,r5
    c.r[4] = c.r[14];  // 0604C246 mov r14,r4
    c.r[1] = ld32(0x0604C3F8u);  // 0604C248 mov.l 0x0604C3F8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C24A mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C3BEu);  // 0604C24C mov.w 0x0604C3BE,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C24E mov.l r1,@-r15
    c.r[1] = 0x3u;  // 0604C250 mov #3,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C252 mov.l r1,@-r15
    c.r[1] = ld32(0x0604C3FCu);  // 0604C254 mov.l 0x0604C3FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C25Au; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C25Au) return; }  // 0604C256 jsr @r1 ; extu.w r5,r5
    c.r[1] = ld32(c.r[14] + 56);  // 0604C25A mov.l @(56,r14),r1
    c.r[1] += 2;  // 0604C25C add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C25E mov.w @r1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0604C260 extu.w r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0604C262 tst r5,r5
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_0604C27C; } }  // 0604C264 bt/s 0x0604C27C ; add #12,r15
    c.r[13] = ld32(c.r[14] + 56);  // 0604C268 mov.l @(56,r14),r13
    c.r[0] = 0x3Eu;  // 0604C26A mov #62,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0604C26C mov.w @r13,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0604C26E mov.w @(r0,r14),r0
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[0] & 0xFFFFu);  // 0604C270 mulu.w r0,r1
    c.r[7] = ld32(0x0604C400u);  // 0604C272 mov.l 0x0604C400,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0604C278u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C278u) return; }  // 0604C274 jsr @r7 ; sts macl,r4
    c.r[11] = c.r[0]; goto L_0604C27E;  // 0604C278 bra 0x0604C27E ; mov r0,r11
L_0604C27C:
    c.r[11] = ld32(c.r[14] + 60);  // 0604C27C mov.l @(60,r14),r11
L_0604C27E:
    c.r[1] = c.r[11];  // 0604C27E mov r11,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C280 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C282 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C284 shar r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 0604C286 extu.w r1,r12
    c.r[10] = 0x0u;  // 0604C288 mov #0,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[12];  // 0604C28A cmp/ge r12,r10
    { const bool k = c.t; c.t = (int32_t)c.r[11] >= 0; if (k) { goto L_0604C2E2; } }  // 0604C28C bt/s 0x0604C2E2 ; cmp/pz r11
    c.r[0] = c.r[14];  // 0604C290 mov r14,r0
    c.r[0] += 12;  // 0604C292 add #12,r0
    c.r[13] = 0x44u;  // 0604C294 mov #68,r13
    c.r[13] += c.r[14];  // 0604C296 add r14,r13
    st32(c.r[13], c.r[0]);  // 0604C298 mov.l r0,@r13
    c.r[9] = ld32(0x0604C404u);  // 0604C29A mov.l 0x0604C404,r9
    c.r[8] = 0x0u;  // 0604C29C mov #0,r8
L_0604C29E:
    c.r[1] = ld32(0x0604C3DCu);  // 0604C29E mov.l 0x0604C3DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C2A4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C2A4u) return; }  // 0604C2A0 jsr @r1 ; mov r8,r4
    c.r[4] = c.r[0];  // 0604C2A4 mov r0,r4
    c.r[5] = c.r[1];  // 0604C2A6 mov r1,r5
    c.r[1] = ld32(0x0604C3E0u);  // 0604C2A8 mov.l 0x0604C3E0,r1
    c.r[6] = ld32(c.r[1]);  // 0604C2AA mov.l @r1,r6
    c.r[13] = ld32(0x0604C3E4u);  // 0604C2AC mov.l 0x0604C3E4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0604C2B2u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C2B2u) return; }  // 0604C2AE jsr @r13 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0604C2B2 mov r0,r4
    c.r[5] = c.r[1];  // 0604C2B4 mov r1,r5
    c.r[0] = ld32(0x0604C3E8u);  // 0604C2B6 mov.l 0x0604C3E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604C2BCu; c.r[13] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C2BCu) return; }  // 0604C2B8 jsr @r0 ; mov #64,r13
    c.r[1] = c.r[0];  // 0604C2BC mov r0,r1
    c.r[13] += c.r[14];  // 0604C2BE add r14,r13
    c.r[5] = c.r[14];  // 0604C2C0 mov r14,r5
    c.r[13] = ld32(c.r[13]);  // 0604C2C2 mov.l @r13,r13
    c.r[0] = 0x44u;  // 0604C2C4 mov #68,r0
    c.r[1] += c.r[13];  // 0604C2C6 add r13,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604C2C8 mov.l r1,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604C2CA mov.w @r9,r1
    c.r[0] += c.r[14];  // 0604C2CC add r14,r0
    c.r[1] += 34;  // 0604C2CE add #34,r1
    st16(c.r[14], c.r[1]);  // 0604C2D0 mov.w r1,@r14
    c.r[1] = ld32(0x0604C408u);  // 0604C2D2 mov.l 0x0604C408,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C2D8u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C2D8u) return; }  // 0604C2D4 jsr @r1 ; mov.l @r0,r4
    c.r[10] += 1;  // 0604C2D8 add #1,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[12];  // 0604C2DA cmp/ge r12,r10
    { const bool k = !c.t; c.r[8] += 8; if (k) { SH2_POLL(c); goto L_0604C29E; } }  // 0604C2DC bf/s 0x0604C29E ; add #8,r8
    c.t = (int32_t)c.r[11] >= 0;  // 0604C2E0 cmp/pz r11
L_0604C2E2:
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0604C2E8; } }  // 0604C2E2 bt/s 0x0604C2E8 ; mov r11,r1
    c.r[1] += 7;  // 0604C2E6 add #7,r1
L_0604C2E8:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C2E8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C2EA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C2EC shar r1
    c.r[1] <<= 2;  // 0604C2EE shll2 r1
    c.r[1] += c.r[1];  // 0604C2F0 add r1,r1
    c.r[10] = c.r[11];  // 0604C2F2 mov r11,r10
    c.r[10] -= c.r[1];  // 0604C2F4 sub r1,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0604C2F6 tst r10,r10
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 60); if (k) { goto L_0604C346; } }  // 0604C2F8 bt/s 0x0604C346 ; mov.l @(60,r14),r1
    c.r[8] = c.r[14];  // 0604C2FC mov r14,r8
    c.r[4] = c.r[12];  // 0604C2FE mov r12,r4
    c.r[4] <<= 2;  // 0604C300 shll2 r4
    c.r[1] = ld32(0x0604C3DCu);  // 0604C302 mov.l 0x0604C3DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C308u; c.r[4] += c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C308u) return; }  // 0604C304 jsr @r1 ; add r4,r4
    c.r[4] = c.r[0];  // 0604C308 mov r0,r4
    c.r[5] = c.r[1];  // 0604C30A mov r1,r5
    c.r[1] = ld32(0x0604C3E0u);  // 0604C30C mov.l 0x0604C3E0,r1
    c.r[6] = ld32(c.r[1]);  // 0604C30E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0604C310 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0604C3E4u);  // 0604C312 mov.l 0x0604C3E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C318u; c.r[8] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C318u) return; }  // 0604C314 jsr @r1 ; add #12,r8
    c.r[4] = c.r[0];  // 0604C318 mov r0,r4
    c.r[13] = ld32(0x0604C3E8u);  // 0604C31A mov.l 0x0604C3E8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0604C320u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C320u) return; }  // 0604C31C jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604C320 mov r0,r1
    c.r[0] = 0x40u;  // 0604C322 mov #64,r0
    c.r[0] += c.r[14];  // 0604C324 add r14,r0
    c.r[10] += 26;  // 0604C326 add #26,r10
    c.r[0] = ld32(c.r[0]);  // 0604C328 mov.l @r0,r0
    c.r[5] = c.r[14];  // 0604C32A mov r14,r5
    c.r[1] += c.r[0];  // 0604C32C add r0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604C32E mov.l r1,@(12,r14)
    c.r[1] = ld32(0x0604C404u);  // 0604C330 mov.l 0x0604C404,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C332 mov.w @r1,r1
    c.r[4] = c.r[8];  // 0604C334 mov r8,r4
    c.r[10] += c.r[1];  // 0604C336 add r1,r10
    c.r[1] = ld32(0x0604C408u);  // 0604C338 mov.l 0x0604C408,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C33Eu; st16(c.r[14], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C33Eu) return; }  // 0604C33A jsr @r1 ; mov.w r10,@r14
    c.r[1] = c.r[12];  // 0604C33E mov r12,r1
    c.r[1] += 1;  // 0604C340 add #1,r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 0604C342 extu.w r1,r12
    c.r[1] = ld32(c.r[14] + 60);  // 0604C344 mov.l @(60,r14),r1
L_0604C346:
    c.r[10] = 0x0u;  // 0604C346 mov #0,r10
    c.r[1] -= c.r[11];  // 0604C348 sub r11,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C34A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C34C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C34E shar r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0604C350 cmp/ge r1,r10
    { const bool k = c.t; c.r[8] = c.r[14]; if (k) { goto L_0604C3A8; } }  // 0604C352 bt/s 0x0604C3A8 ; mov r14,r8
    c.r[8] += 12;  // 0604C356 add #12,r8
    c.r[9] = ld32(0x0604C404u);  // 0604C358 mov.l 0x0604C404,r9
    c.r[4] = c.r[12];  // 0604C35A mov r12,r4
L_0604C35C:
    c.r[4] += c.r[10];  // 0604C35C add r10,r4
    c.r[4] <<= 2;  // 0604C35E shll2 r4
    c.r[1] = ld32(0x0604C3DCu);  // 0604C360 mov.l 0x0604C3DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C366u; c.r[4] += c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C366u) return; }  // 0604C362 jsr @r1 ; add r4,r4
    c.r[4] = c.r[0];  // 0604C366 mov r0,r4
    c.r[5] = c.r[1];  // 0604C368 mov r1,r5
    c.r[1] = ld32(0x0604C3E0u);  // 0604C36A mov.l 0x0604C3E0,r1
    c.r[6] = ld32(c.r[1]);  // 0604C36C mov.l @r1,r6
    c.r[13] = ld32(0x0604C3E4u);  // 0604C36E mov.l 0x0604C3E4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0604C374u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C374u) return; }  // 0604C370 jsr @r13 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0604C374 mov r0,r4
    c.r[5] = c.r[1];  // 0604C376 mov r1,r5
    c.r[0] = ld32(0x0604C3E8u);  // 0604C378 mov.l 0x0604C3E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604C37Eu; c.r[13] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C37Eu) return; }  // 0604C37A jsr @r0 ; mov #64,r13
    c.r[1] = c.r[0];  // 0604C37E mov r0,r1
    c.r[13] += c.r[14];  // 0604C380 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0604C382 mov.l @r13,r13
    c.r[5] = c.r[14];  // 0604C384 mov r14,r5
    c.r[1] += c.r[13];  // 0604C386 add r13,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604C388 mov.l r1,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604C38A mov.w @r9,r1
    c.r[1] += 26;  // 0604C38C add #26,r1
    st16(c.r[14], c.r[1]);  // 0604C38E mov.w r1,@r14
    c.r[1] = ld32(0x0604C408u);  // 0604C390 mov.l 0x0604C408,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C396u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C396u) return; }  // 0604C392 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(c.r[14] + 60);  // 0604C396 mov.l @(60,r14),r1
    c.r[10] += 1;  // 0604C398 add #1,r10
    c.r[1] -= c.r[11];  // 0604C39A sub r11,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C39C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C39E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604C3A0 shar r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0604C3A2 cmp/ge r1,r10
    { const bool k = !c.t; c.r[4] = c.r[12]; if (k) { SH2_POLL(c); goto L_0604C35C; } }  // 0604C3A4 bf/s 0x0604C35C ; mov r12,r4
L_0604C3A8:
    c.r[14] += 72;  // 0604C3A8 add #72,r14
    c.r[15] = c.r[14];  // 0604C3AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604C3AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604C3AE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604C3B0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604C3B2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604C3B4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604C3B6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604C3B8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604C3BA rts ; mov.l @r15+,r8
}

void f_0604C40C(SH2Context& c) {
    ran[1233] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604C40C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604C40E mov r15,r14
    c.r[1] = ld32(0x0604C4E0u);  // 0604C410 mov.l 0x0604C4E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C412 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604C414 mov r1,r0
    c.r[0] >>= 2;  // 0604C416 shlr2 r0
    c.r[0] >>= 2;  // 0604C418 shlr2 r0
    c.r[0] >>= 2;  // 0604C41A shlr2 r0
    c.r[0] &= 0x1u;  // 0604C41C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604C41E tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[4] & 0xFFFFu; if (k) { goto L_0604C42A; } }  // 0604C420 bt/s 0x0604C42A ; extu.w r4,r3
    c.r[1] = ld32(0x0604C4E4u);  // 0604C424 mov.l 0x0604C4E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0604C42E;  // 0604C426 bra 0x0604C42E ; mov.b @r1,r1
L_0604C42A:
    c.r[1] = ld32(0x0604C4E8u);  // 0604C42A mov.l 0x0604C4E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C42C mov.b @r1,r1
L_0604C42E:
    c.r[0] = 0x3u;  // 0604C42E mov #3,r0
    c.r[2] = c.r[1];  // 0604C430 mov r1,r2
    c.r[2] >>= 2;  // 0604C432 shlr2 r2
    c.r[2] &= c.r[0];  // 0604C434 and r0,r2
    c.r[1] = 0x3u;  // 0604C436 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0604C438 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0604C4C2; } }  // 0604C43A bt/s 0x0604C4C2 ; mov r14,r15
    c.r[1] = c.r[2];  // 0604C43E mov r2,r1
    c.r[1] += c.r[1];  // 0604C440 add r1,r1
    c.r[0] = 0x0604C44Cu;  // 0604C442 mova 0x0604C44C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604C444 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604C446 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604C454u: goto L_0604C454; case 0x0604C486u: goto L_0604C486; case 0x0604C4A4u: goto L_0604C4A4; default: sh2_call(c, x); return; } }  // 0604C448 jmp @r0 ; nop
L_0604C454:
    c.r[1] = ld32(0x0604C4E0u);  // 0604C454 mov.l 0x0604C4E0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C456 mov.w @r1,r1
    c.r[0] = c.r[1];  // 0604C458 mov r1,r0
    c.r[0] >>= 2;  // 0604C45A shlr2 r0
    c.r[0] >>= 2;  // 0604C45C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604C45E shlr r0
    c.r[0] >>= 2;  // 0604C460 shlr2 r0
    c.r[0] &= 0x3u;  // 0604C462 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604C464 tst r0,r0
    { const bool k = !c.t; c.r[3] += c.r[3]; if (k) { goto L_0604C4C0; } }  // 0604C466 bf/s 0x0604C4C0 ; add r3,r3
    c.r[2] = ld32(0x0604C4ECu);  // 0604C46A mov.l 0x0604C4EC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4C6u);  // 0604C46C mov.w 0x0604C4C6,r1
    c.r[0] = c.r[3];  // 0604C46E mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C470 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F0u);  // 0604C472 mov.l 0x0604C4F0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4C8u);  // 0604C474 mov.w 0x0604C4C8,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C476 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F4u);  // 0604C478 mov.l 0x0604C4F4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4CAu);  // 0604C47A mov.w 0x0604C4CA,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C47C mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F8u);  // 0604C47E mov.l 0x0604C4F8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4CCu);  // 0604C480 mov.w 0x0604C4CC,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_0604C4C0;  // 0604C482 bra 0x0604C4C0 ; mov.w r1,@(r0,r2)
L_0604C486:
    c.r[3] += c.r[3];  // 0604C486 add r3,r3
    c.r[2] = ld32(0x0604C4ECu);  // 0604C488 mov.l 0x0604C4EC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4CEu);  // 0604C48A mov.w 0x0604C4CE,r1
    c.r[0] = c.r[3];  // 0604C48C mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C48E mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F0u);  // 0604C490 mov.l 0x0604C4F0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4D0u);  // 0604C492 mov.w 0x0604C4D0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C494 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F4u);  // 0604C496 mov.l 0x0604C4F4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4D2u);  // 0604C498 mov.w 0x0604C4D2,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C49A mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F8u);  // 0604C49C mov.l 0x0604C4F8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4D4u);  // 0604C49E mov.w 0x0604C4D4,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_0604C4C0;  // 0604C4A0 bra 0x0604C4C0 ; mov.w r1,@(r0,r2)
L_0604C4A4:
    c.r[3] += c.r[3];  // 0604C4A4 add r3,r3
    c.r[2] = ld32(0x0604C4ECu);  // 0604C4A6 mov.l 0x0604C4EC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4D6u);  // 0604C4A8 mov.w 0x0604C4D6,r1
    c.r[0] = c.r[3];  // 0604C4AA mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C4AC mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F0u);  // 0604C4AE mov.l 0x0604C4F0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4D8u);  // 0604C4B0 mov.w 0x0604C4D8,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C4B2 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F4u);  // 0604C4B4 mov.l 0x0604C4F4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4DAu);  // 0604C4B6 mov.w 0x0604C4DA,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C4B8 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x0604C4F8u);  // 0604C4BA mov.l 0x0604C4F8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C4DCu);  // 0604C4BC mov.w 0x0604C4DC,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604C4BE mov.w r1,@(r0,r2)
L_0604C4C0:
    c.r[15] = c.r[14];  // 0604C4C0 mov r14,r15
L_0604C4C2:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604C4C2 rts ; mov.l @r15+,r14
}

void f_0604C4FC(SH2Context& c) {
    ran[1234] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604C4FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604C4FE mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0604C500 extu.w r4,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0604C502 cmp/pz r4
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0604C516; } }  // 0604C504 bf/s 0x0604C516 ; mov #-1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604C59Cu);  // 0604C508 mov.w 0x0604C59C,r2
L_0604C50A:
    c.r[4] += c.r[2];  // 0604C50A add r2,r4
    c.r[1] = c.r[0];  // 0604C50C mov r0,r1
    c.r[1] += 1;  // 0604C50E add #1,r1
    c.t = (int32_t)c.r[4] >= 0;  // 0604C510 cmp/pz r4
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1]; if (k) { SH2_POLL(c); goto L_0604C50A; } }  // 0604C512 bt/s 0x0604C50A ; exts.b r1,r0
L_0604C516:
    c.r[1] = c.r[5];  // 0604C516 mov r5,r1
    c.r[1] += 4;  // 0604C518 add #4,r1
    st8(c.r[1], c.r[0]);  // 0604C51A mov.b r0,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C59Eu);  // 0604C51C mov.w 0x0604C59E,r1
    c.r[4] += c.r[1];  // 0604C51E add r1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0604C520 cmp/pz r4
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0604C534; } }  // 0604C522 bf/s 0x0604C534 ; mov #-1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604C5A0u);  // 0604C526 mov.w 0x0604C5A0,r2
L_0604C528:
    c.r[4] += c.r[2];  // 0604C528 add r2,r4
    c.r[1] = c.r[0];  // 0604C52A mov r0,r1
    c.r[1] += 1;  // 0604C52C add #1,r1
    c.t = (int32_t)c.r[4] >= 0;  // 0604C52E cmp/pz r4
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1]; if (k) { SH2_POLL(c); goto L_0604C528; } }  // 0604C530 bt/s 0x0604C528 ; exts.b r1,r0
L_0604C534:
    c.r[1] = c.r[5];  // 0604C534 mov r5,r1
    c.r[1] += 3;  // 0604C536 add #3,r1
    st8(c.r[1], c.r[0]);  // 0604C538 mov.b r0,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C5A2u);  // 0604C53A mov.w 0x0604C5A2,r1
    c.r[4] += c.r[1];  // 0604C53C add r1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0604C53E cmp/pz r4
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0604C550; } }  // 0604C540 bf/s 0x0604C550 ; mov #-1,r0
L_0604C544:
    c.r[4] -= 100;  // 0604C544 add #-100,r4
    c.r[1] = c.r[0];  // 0604C546 mov r0,r1
    c.r[1] += 1;  // 0604C548 add #1,r1
    c.t = (int32_t)c.r[4] >= 0;  // 0604C54A cmp/pz r4
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1]; if (k) { SH2_POLL(c); goto L_0604C544; } }  // 0604C54C bt/s 0x0604C544 ; exts.b r1,r0
L_0604C550:
    c.r[1] = c.r[5];  // 0604C550 mov r5,r1
    c.r[1] += 2;  // 0604C552 add #2,r1
    st8(c.r[1], c.r[0]);  // 0604C554 mov.b r0,@r1
    c.r[4] += 100;  // 0604C556 add #100,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0604C558 cmp/pz r4
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0604C56A; } }  // 0604C55A bf/s 0x0604C56A ; mov #-1,r0
L_0604C55E:
    c.r[4] -= 10;  // 0604C55E add #-10,r4
    c.r[1] = c.r[0];  // 0604C560 mov r0,r1
    c.r[1] += 1;  // 0604C562 add #1,r1
    c.t = (int32_t)c.r[4] >= 0;  // 0604C564 cmp/pz r4
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1]; if (k) { SH2_POLL(c); goto L_0604C55E; } }  // 0604C566 bt/s 0x0604C55E ; exts.b r1,r0
L_0604C56A:
    c.r[1] = c.r[5];  // 0604C56A mov r5,r1
    c.r[1] += 1;  // 0604C56C add #1,r1
    st8(c.r[1], c.r[0]);  // 0604C56E mov.b r0,@r1
    c.r[4] += 10;  // 0604C570 add #10,r4
    st8(c.r[5], c.r[4]);  // 0604C572 mov.b r4,@r5
    c.r[1] = c.r[5];  // 0604C574 mov r5,r1
    c.r[1] += 4;  // 0604C576 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C578 mov.b @r1,r1
    c.r[0] = 0x5u; goto L_0604C58E;  // 0604C57A bra 0x0604C58E ; mov #5,r0
L_0604C57E:
    c.r[1] -= 1;  // 0604C57E add #-1,r1
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0604C580 exts.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0604C582 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_0604C596; } }  // 0604C584 bt/s 0x0604C596 ; mov r0,r1
    c.r[1] += c.r[5];  // 0604C588 add r5,r1
    c.r[1] -= 1;  // 0604C58A add #-1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C58C mov.b @r1,r1
L_0604C58E:
    c.r[1] = c.r[1] & 0xFFu;  // 0604C58E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C590 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0604C57E; } }  // 0604C592 bt/s 0x0604C57E ; mov r0,r1
L_0604C596:
    c.r[15] = c.r[14];  // 0604C596 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604C598 rts ; mov.l @r15+,r14
}

void f_0604C5AC(SH2Context& c) {
    ran[1235] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604C5AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604C5AE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604C5B0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604C5B2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604C5B4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604C5B6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604C5B8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604C5BA sts.l pr,@-r15
    c.r[15] -= 60;  // 0604C5BC add #-60,r15
    c.r[1] = ld32(0x0604C770u);  // 0604C5BE mov.l 0x0604C770,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C5C0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C5C2 extu.b r1,r1
    c.r[1] >>= 2;  // 0604C5C4 shlr2 r1
    c.r[1] >>= 2;  // 0604C5C6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604C5C8 shlr r1
    c.r[1] >>= 2;  // 0604C5CA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C5CC tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604C662; } }  // 0604C5CE bf/s 0x0604C662 ; mov r15,r14
    c.r[1] = ld32(0x0604C774u);  // 0604C5D2 mov.l 0x0604C774,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C5D4 mov.w @r1,r3
    c.r[2] = c.r[3] & 0xFFFFu;  // 0604C5D6 extu.w r3,r2
    c.r[1] = ld32(0x0604C778u);  // 0604C5D8 mov.l 0x0604C778,r1
    c.t = c.r[2] == c.r[1];  // 0604C5DA cmp/eq r1,r2
    if (!c.t) { goto L_0604C5E6; }  // 0604C5DC bf 0x0604C5E6
    c.r[1] = ld32(0x0604C77Cu);  // 0604C5DE mov.l 0x0604C77C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C5E0 mov.w @r1,r1
    c.r[1] += 44; goto L_0604C5EC;  // 0604C5E2 bra 0x0604C5EC ; add #44,r1
L_0604C5E6:
    c.r[1] = ld32(0x0604C780u);  // 0604C5E6 mov.l 0x0604C780,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C5E8 mov.w @r1,r1
    c.r[1] += c.r[3];  // 0604C5EA add r3,r1
L_0604C5EC:
    c.r[5] = c.r[1] & 0xFFFFu;  // 0604C5EC extu.w r1,r5
    c.r[0] = c.r[14];  // 0604C5EE mov r14,r0
    c.r[0] += 12;  // 0604C5F0 add #12,r0
    st32(c.r[14] + 52, c.r[0]);  // 0604C5F2 mov.l r0,@(52,r14)
    c.r[1] = ld32(0x0604C784u);  // 0604C5F4 mov.l 0x0604C784,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C5F6 mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C762u);  // 0604C5F8 mov.w 0x0604C762,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C5FA mov.l r1,@-r15
    c.r[1] = 0x0u;  // 0604C5FC mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C5FE mov.l r1,@-r15
    c.r[1] = ld32(0x0604C788u);  // 0604C600 mov.l 0x0604C788,r1
    c.r[7] = 0x7u;  // 0604C602 mov #7,r7
    c.r[4] = ld32(c.r[14] + 52);  // 0604C604 mov.l @(52,r14),r4
    { const uint32_t x = c.r[1]; c.pr = 0x0604C60Au; c.r[6] = 0x34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C60Au) return; }  // 0604C606 jsr @r1 ; mov #52,r6
    c.r[10] = c.r[14];  // 0604C60A mov r14,r10
    c.r[1] = ld32(0x0604C78Cu);  // 0604C60C mov.l 0x0604C78C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C60E mov.b @r1,r4
    c.r[13] = ld32(0x0604C790u);  // 0604C610 mov.l 0x0604C790,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C764u);  // 0604C612 mov.w 0x0604C764,r1
    { const uint32_t x = c.r[13]; c.pr = 0x0604C618u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C618u) return; }  // 0604C614 jsr @r13 ; add r1,r4
    c.r[4] = c.r[0];  // 0604C618 mov r0,r4
    c.r[5] = c.r[1];  // 0604C61A mov r1,r5
    c.r[1] = ld32(0x0604C794u);  // 0604C61C mov.l 0x0604C794,r1
    c.r[8] = ld32(c.r[1]);  // 0604C61E mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0604C620 mov.l @(4,r1),r9
    c.r[12] = ld32(0x0604C798u);  // 0604C622 mov.l 0x0604C798,r12
    c.r[6] = c.r[8];  // 0604C624 mov r8,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0604C62Au; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C62Au) return; }  // 0604C626 jsr @r12 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604C62A mov r0,r4
    c.r[11] = ld32(0x0604C79Cu);  // 0604C62C mov.l 0x0604C79C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0604C632u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C632u) return; }  // 0604C62E jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604C632 mov r0,r1
    st32(c.r[14] + 36, c.r[1]);  // 0604C634 mov.l r1,@(36,r14)
    c.r[1] = ld32(0x0604C7A0u);  // 0604C636 mov.l 0x0604C7A0,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C638 mov.b @r1,r4
    c.r[10] += 36;  // 0604C63A add #36,r10
    { const uint32_t x = c.r[13]; c.pr = 0x0604C640u; c.r[4] += 60; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C640u) return; }  // 0604C63C jsr @r13 ; add #60,r4
    c.r[4] = c.r[0];  // 0604C640 mov r0,r4
    c.r[5] = c.r[1];  // 0604C642 mov r1,r5
    c.r[6] = c.r[8];  // 0604C644 mov r8,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0604C64Au; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C64Au) return; }  // 0604C646 jsr @r12 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604C64A mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0604C650u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C650u) return; }  // 0604C64C jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604C650 mov r0,r1
    st32(c.r[10] + 4, c.r[1]);  // 0604C652 mov.l r1,@(4,r10)
    c.r[1] = ld32(0x0604C7A4u);  // 0604C654 mov.l 0x0604C7A4,r1
    st32(c.r[10] + 8, c.r[1]);  // 0604C656 mov.l r1,@(8,r10)
    c.r[1] = ld32(0x0604C7A8u);  // 0604C658 mov.l 0x0604C7A8,r1
    c.r[5] = ld32(c.r[14] + 52);  // 0604C65A mov.l @(52,r14),r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604C660u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C660u) return; }  // 0604C65C jsr @r1 ; mov r10,r4
    c.r[15] += 12;  // 0604C660 add #12,r15
L_0604C662:
    c.r[0] = 0x0u;  // 0604C662 mov #0,r0
    st32(c.r[14] + 48, c.r[0]);  // 0604C664 mov.l r0,@(48,r14)
    c.r[0] = c.r[14];  // 0604C666 mov r14,r0
    c.r[0] += 24;  // 0604C668 add #24,r0
    st32(c.r[14] + 56, c.r[0]);  // 0604C66A mov.l r0,@(56,r14)
    c.r[13] = ld32(0x0604C7ACu);  // 0604C66C mov.l 0x0604C7AC,r13
L_0604C66E:
    c.r[1] = c.r[13];  // 0604C66E mov r13,r1
    c.r[1] += 64;  // 0604C670 add #64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C672 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C674 extu.b r1,r1
    c.r[1] >>= 2;  // 0604C676 shlr2 r1
    c.r[1] >>= 2;  // 0604C678 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604C67A shlr r1
    c.r[1] >>= 2;  // 0604C67C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C67E tst r1,r1
    if (c.t) { goto L_0604C73C; }  // 0604C680 bt 0x0604C73C
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604C766u);  // 0604C682 mov.w 0x0604C766,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604C684 mov.w @(r0,r13),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0604C686 extu.w r1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604C768u);  // 0604C688 mov.w 0x0604C768,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604C68A mov.w @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604C68C extu.w r1,r1
    c.r[1] += c.r[8];  // 0604C68E add r8,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0604C690 cmp/ge r1,r8
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_0604C6B8; } }  // 0604C692 bt/s 0x0604C6B8 ; mov r14,r5
L_0604C696:
    c.r[5] += 12;  // 0604C696 add #12,r5
    c.r[4] = c.r[14];  // 0604C698 mov r14,r4
    c.r[0] = ld32(0x0604C7A8u);  // 0604C69A mov.l 0x0604C7A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604C6A0u; c.r[4] += 36; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C6A0u) return; }  // 0604C69C jsr @r0 ; add #36,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C766u);  // 0604C6A0 mov.w 0x0604C766,r1
    c.r[0] = c.r[13];  // 0604C6A2 mov r13,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604C6A4 mov.w @(r0,r1),r2
    c.r[8] += 1;  // 0604C6A6 add #1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C768u);  // 0604C6A8 mov.w 0x0604C768,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604C6AA mov.w @(r0,r1),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604C6AC extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604C6AE extu.w r1,r1
    c.r[2] += c.r[1];  // 0604C6B0 add r1,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 0604C6B2 cmp/ge r2,r8
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_0604C696; } }  // 0604C6B4 bf/s 0x0604C696 ; mov r14,r5
L_0604C6B8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C76Au);  // 0604C6B8 mov.w 0x0604C76A,r1
    c.r[0] = ld32(0x0604C7ACu);  // 0604C6BA mov.l 0x0604C7AC,r0
    c.r[7] = 0x7u;  // 0604C6BC mov #7,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604C6BE mov.b @(r0,r1),r6
    c.r[4] = c.r[14];  // 0604C6C0 mov r14,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C76Cu);  // 0604C6C2 mov.w 0x0604C76C,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604C6C4 mov.w @(r0,r1),r5
    c.r[6] = c.r[6] & 0xFFu;  // 0604C6C6 extu.b r6,r6
    c.r[1] = ld32(0x0604C7B0u);  // 0604C6C8 mov.l 0x0604C7B0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C6CA mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C762u);  // 0604C6CC mov.w 0x0604C762,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C6CE mov.l r1,@-r15
    c.r[1] = 0x0u;  // 0604C6D0 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604C6D2 mov.l r1,@-r15
    c.r[1] = ld32(0x0604C788u);  // 0604C6D4 mov.l 0x0604C788,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C6DAu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C6DAu) return; }  // 0604C6D6 jsr @r1 ; extu.w r5,r5
    c.r[1] = c.r[13];  // 0604C6DA mov r13,r1
    c.r[1] += 70;  // 0604C6DC add #70,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604C6DE mov.w @r1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604C6E0 extu.w r2,r2
    c.r[1] = ld32(0x0604C778u);  // 0604C6E2 mov.l 0x0604C778,r1
    c.t = c.r[2] == c.r[1];  // 0604C6E4 cmp/eq r1,r2
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_0604C73C; } }  // 0604C6E6 bt/s 0x0604C73C ; add #12,r15
    c.r[1] = ld32(0x0604C78Cu);  // 0604C6EA mov.l 0x0604C78C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C6EC mov.b @r1,r4
    c.r[12] = ld32(0x0604C790u);  // 0604C6EE mov.l 0x0604C790,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0604C6F4u; c.r[4] += 32; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C6F4u) return; }  // 0604C6F0 jsr @r12 ; add #32,r4
    c.r[4] = c.r[0];  // 0604C6F4 mov r0,r4
    c.r[5] = c.r[1];  // 0604C6F6 mov r1,r5
    c.r[1] = ld32(0x0604C794u);  // 0604C6F8 mov.l 0x0604C794,r1
    c.r[8] = ld32(c.r[1]);  // 0604C6FA mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0604C6FC mov.l @(4,r1),r9
    c.r[11] = ld32(0x0604C798u);  // 0604C6FE mov.l 0x0604C798,r11
    c.r[6] = c.r[8];  // 0604C700 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0604C706u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C706u) return; }  // 0604C702 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604C706 mov r0,r4
    c.r[10] = ld32(0x0604C79Cu);  // 0604C708 mov.l 0x0604C79C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0604C70Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C70Eu) return; }  // 0604C70A jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604C70E mov r0,r1
    st32(c.r[14] + 24, c.r[1]);  // 0604C710 mov.l r1,@(24,r14)
    c.r[1] = ld32(0x0604C7A0u);  // 0604C712 mov.l 0x0604C7A0,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C714 mov.b @r1,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0604C71Au; c.r[4] += 80; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C71Au) return; }  // 0604C716 jsr @r12 ; add #80,r4
    c.r[4] = c.r[0];  // 0604C71A mov r0,r4
    c.r[5] = c.r[1];  // 0604C71C mov r1,r5
    c.r[6] = c.r[8];  // 0604C71E mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0604C724u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C724u) return; }  // 0604C720 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604C724 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604C72Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C72Au) return; }  // 0604C726 jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604C72A mov r0,r1
    c.r[0] = ld32(c.r[14] + 56);  // 0604C72C mov.l @(56,r14),r0
    c.r[4] = ld32(c.r[14] + 56);  // 0604C72E mov.l @(56,r14),r4
    st32(c.r[0] + 4, c.r[1]);  // 0604C730 mov.l r1,@(4,r0)
    c.r[1] = ld32(0x0604C7A4u);  // 0604C732 mov.l 0x0604C7A4,r1
    st32(c.r[0] + 8, c.r[1]);  // 0604C734 mov.l r1,@(8,r0)
    c.r[0] = ld32(0x0604C7A8u);  // 0604C736 mov.l 0x0604C7A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604C73Cu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C73Cu) return; }  // 0604C738 jsr @r0 ; mov r14,r5
L_0604C73C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604C76Eu);  // 0604C73C mov.w 0x0604C76E,r1
    c.r[13] += c.r[1];  // 0604C73E add r1,r13
    c.r[0] = ld32(c.r[14] + 48);  // 0604C740 mov.l @(48,r14),r0
    c.r[1] = 0x3u;  // 0604C742 mov #3,r1
    c.r[0] += 1;  // 0604C744 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0604C746 cmp/gt r1,r0
    { const bool k = !c.t; st32(c.r[14] + 48, c.r[0]); if (k) { SH2_POLL(c); goto L_0604C66E; } }  // 0604C748 bf/s 0x0604C66E ; mov.l r0,@(48,r14)
    c.r[14] += 60;  // 0604C74C add #60,r14
    c.r[15] = c.r[14];  // 0604C74E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604C750 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604C752 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604C754 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604C756 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604C758 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604C75A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604C75C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604C75E rts ; mov.l @r15+,r8
}

void f_0604C7B4(SH2Context& c) {
    ran[1236] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604C7B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604C7B6 sts.l pr,@-r15
    c.r[1] = ld32(0x0604C7CCu);  // 0604C7B8 mov.l 0x0604C7CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C7BEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C7BEu) return; }  // 0604C7BA jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0604C7D0u);  // 0604C7BE mov.l 0x0604C7D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C7C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C7C4u) return; }  // 0604C7C0 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0604C7C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604C7C6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604C7C8 rts ; mov.l @r15+,r14
}

void f_0604C7D8(SH2Context& c) {
    ran[1237] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604C7D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604C7DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604C7DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604C7DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604C7E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604C7E2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604C7E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604C7E6 sts.l pr,@-r15
    c.r[15] -= 12;  // 0604C7E8 add #-12,r15
    c.r[2] = ld32(0x0604CA7Cu);  // 0604C7EA mov.l 0x0604CA7C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604C7EC mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0604C7EE extu.w r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604C7F0 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604C804; } }  // 0604C7F2 bt/s 0x0604C804 ; mov r15,r14
    c.t = c.r[0] == 0x8u;  // 0604C7F6 cmp/eq #8,r0
    { const bool k = c.t; c.r[1] = 0x10u; if (k) { goto L_0604C800; } }  // 0604C7F8 bt/s 0x0604C800 ; mov #16,r1
    goto L_0604CB28;  // 0604C7FC bra 0x0604CB28 ; nop
L_0604C800:
    st16(c.r[2], c.r[1]); goto L_0604CB28;  // 0604C800 bra 0x0604CB28 ; mov.w r1,@r2
L_0604C804:
    c.r[3] = ld32(0x0604CA80u);  // 0604C804 mov.l 0x0604CA80,r3
    c.r[1] = ld32(c.r[3] + 12);  // 0604C806 mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C808 tst r1,r1
    { const bool k = c.t; c.r[1] -= 1; if (k) { goto L_0604C812; } }  // 0604C80A bt/s 0x0604C812 ; add #-1,r1
    st32(c.r[3] + 12, c.r[1]); goto L_0604CB28;  // 0604C80E bra 0x0604CB28 ; mov.l r1,@(12,r3)
L_0604C812:
    c.r[7] = ld32(c.r[3] + 4);  // 0604C812 mov.l @(4,r3),r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604C814 tst r7,r7
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0604C81E; } }  // 0604C816 bf/s 0x0604C81E ; mov r7,r1
    goto L_0604CB28;  // 0604C81A bra 0x0604CB28 ; nop
L_0604C81E:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604C81E mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604C820 extu.b r2,r2
    c.r[0] = c.r[2];  // 0604C822 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C824 mov.b @r1,r1
    c.r[0] <<= 8;  // 0604C826 shll8 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604C828 extu.b r1,r1
    c.r[0] |= c.r[1];  // 0604C82A or r1,r0
    c.t = c.r[0] == 0x11u;  // 0604C82C cmp/eq #17,r0
    { const bool k = c.t; c.r[1] = 0x11u; if (k) { goto L_0604C882; } }  // 0604C82E bt/s 0x0604C882 ; mov #17,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0604C832 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x12u; if (k) { goto L_0604C84A; } }  // 0604C834 bt/s 0x0604C84A ; cmp/eq #18,r0
    c.t = c.r[0] == 0xFu;  // 0604C838 cmp/eq #15,r0
    { const bool k = !c.t; c.t = c.r[0] == 0x10u; if (k) { goto L_0604C842; } }  // 0604C83A bf/s 0x0604C842 ; cmp/eq #16,r0
    goto L_0604CB24;  // 0604C83E bra 0x0604CB24 ; nop
L_0604C842:
    if (c.t) { goto L_0604C8A0; }  // 0604C842 bt 0x0604C8A0
    c.r[14] += 12;  // 0604C844 add #12,r14
    c.r[15] = c.r[14]; goto L_0604CB2C;  // 0604C846 bra 0x0604CB2C ; mov r14,r15
L_0604C84A:
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0604C866; } }  // 0604C84A bt/s 0x0604C866 ; mov r3,r1
    c.r[1] = ld32(0x0604CA84u);  // 0604C84E mov.l 0x0604CA84,r1
    c.t = c.r[0] == c.r[1];  // 0604C850 cmp/eq r1,r0
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_0604C85A; } }  // 0604C852 bt/s 0x0604C85A ; add #1,r3
    goto L_0604CB28;  // 0604C856 bra 0x0604CB28 ; nop
L_0604C85A:
    c.r[1] = 0xFFFFFFFFu;  // 0604C85A mov #-1,r1
    st8(c.r[3], c.r[1]); goto L_0604CB28;  // 0604C85C bra 0x0604CB28 ; mov.b r1,@r3
L_0604C860:
    c.r[1] = ld32(0x0604CA88u);  // 0604C860 mov.l 0x0604CA88,r1
    st16(c.r[1], c.r[3]); goto L_0604C8DC;  // 0604C862 bra 0x0604C8DC ; mov.w r3,@r1
L_0604C866:
    c.r[1] += 1;  // 0604C866 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C868 mov.b @r1,r0
    c.r[0] |= 0xC0u;  // 0604C86A or #192,r0
    st8(c.r[1], c.r[0]);  // 0604C86C mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604C86E mov.b @r3,r1
    c.r[2] = 0x1u;  // 0604C870 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604C872 extu.b r1,r1
    c.r[1] >>= 2;  // 0604C874 shlr2 r1
    c.r[1] >>= 2;  // 0604C876 shlr2 r1
    c.r[1] >>= 2;  // 0604C878 shlr2 r1
    c.t = c.r[1] > c.r[2];  // 0604C87A cmp/hi r2,r1
    if (c.t) { goto L_0604C882; }  // 0604C87C bt 0x0604C882
    goto L_0604CB28;  // 0604C87E bra 0x0604CB28 ; nop
L_0604C882:
    c.r[2] = ld32(0x0604CA80u);  // 0604C882 mov.l 0x0604CA80,r2
    c.r[1] = c.r[2];  // 0604C884 mov r2,r1
    c.r[1] += 1;  // 0604C886 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C888 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0604C88A or #128,r0
    st8(c.r[1], c.r[0]);  // 0604C88C mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604C88E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C890 extu.b r1,r1
    c.r[1] >>= 2;  // 0604C892 shlr2 r1
    c.r[1] >>= 2;  // 0604C894 shlr2 r1
    c.r[1] >>= 2;  // 0604C896 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C898 tst r1,r1
    if (!c.t) { goto L_0604C8A0; }  // 0604C89A bf 0x0604C8A0
    goto L_0604CB28;  // 0604C89C bra 0x0604CB28 ; nop
L_0604C8A0:
    c.r[2] = ld32(0x0604CA88u);  // 0604C8A0 mov.l 0x0604CA88,r2
    c.r[1] = 0x0u;  // 0604C8A2 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0604C8A4 mov.w r1,@r2
    c.r[1] = ld32(0x0604CA80u);  // 0604C8A6 mov.l 0x0604CA80,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0604C8A8 mov.l @(4,r1),r2
    c.r[3] = 0x0u;  // 0604C8AA mov #0,r3
    c.r[1] = c.r[2];  // 0604C8AC mov r2,r1
    c.r[1] += 2;  // 0604C8AE add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C8B0 mov.b @r1,r1
    c.r[2] += 3;  // 0604C8B2 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604C8B4 extu.b r1,r1
    c.r[7] = c.r[1];  // 0604C8B6 mov r1,r7
    c.r[7] <<= 8;  // 0604C8B8 shll8 r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604C8BA mov.b @r2,r1
    c.r[6] = ld32(0x0604CA8Cu);  // 0604C8BC mov.l 0x0604CA8C,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604C8BE extu.b r1,r1
    c.r[7] |= c.r[1];  // 0604C8C0 or r1,r7
    c.r[0] = c.r[3];  // 0604C8C2 mov r3,r0
L_0604C8C4:
    c.r[0] += c.r[0];  // 0604C8C4 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 0604C8C6 mov.w @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604C8C8 extu.w r1,r1
    c.t = c.r[1] == c.r[7];  // 0604C8CA cmp/eq r7,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { SH2_POLL(c); goto L_0604C860; } }  // 0604C8CC bt/s 0x0604C860 ; mov r3,r1
    c.r[1] += 1;  // 0604C8D0 add #1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0604C8D2 extu.w r1,r3
    c.r[1] = 0xFu;  // 0604C8D4 mov #15,r1
    c.t = c.r[3] > c.r[1];  // 0604C8D6 cmp/hi r1,r3
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0604C8C4; } }  // 0604C8D8 bf/s 0x0604C8C4 ; mov r3,r0
L_0604C8DC:
    c.r[1] = ld32(0x0604CA90u);  // 0604C8DC mov.l 0x0604CA90,r1
    c.r[7] = 0x10u;  // 0604C8DE mov #16,r7
    c.r[6] = 0x0u;  // 0604C8E0 mov #0,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C8E2 mov.b @r1,r5
    c.r[4] = 0x30u;  // 0604C8E4 mov #48,r4
    c.r[5] += 42;  // 0604C8E6 add #42,r5
    c.r[1] = ld32(0x0604CA94u);  // 0604C8E8 mov.l 0x0604CA94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604C8EEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C8EEu) return; }  // 0604C8EA jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0604CA98u);  // 0604C8EE mov.l 0x0604CA98,r1
    c.r[13] = 0x1u;  // 0604C8F0 mov #1,r13
    st16(c.r[1], c.r[13]);  // 0604C8F2 mov.w r13,@r1
    c.r[8] = ld32(0x0604CA80u);  // 0604C8F4 mov.l 0x0604CA80,r8
    c.r[2] = ld32(c.r[8] + 4);  // 0604C8F6 mov.l @(4,r8),r2
    c.r[1] = c.r[2];  // 0604C8F8 mov r2,r1
    c.r[1] += 2;  // 0604C8FA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C8FC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C8FE extu.b r1,r1
    c.r[9] = c.r[1];  // 0604C900 mov r1,r9
    c.r[9] <<= 8;  // 0604C902 shll8 r9
    c.r[1] = c.r[2];  // 0604C904 mov r2,r1
    c.r[1] += 3;  // 0604C906 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C908 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C90A extu.b r1,r1
    c.r[9] |= c.r[1];  // 0604C90C or r1,r9
    c.r[9] >>= 2;  // 0604C90E shlr2 r9
    c.r[9] >>= 2;  // 0604C910 shlr2 r9
    c.r[9] >>= 2;  // 0604C912 shlr2 r9
    st32(c.r[14] + 4, c.r[9]);  // 0604C914 mov.l r9,@(4,r14)
    c.r[1] = c.r[2];  // 0604C916 mov r2,r1
    c.r[1] += 4;  // 0604C918 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C91A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C91C extu.b r1,r1
    c.r[0] = c.r[1];  // 0604C91E mov r1,r0
    c.r[0] <<= 8;  // 0604C920 shll8 r0
    c.r[1] = c.r[2];  // 0604C922 mov r2,r1
    c.r[1] += 5;  // 0604C924 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C926 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C928 extu.b r1,r1
    c.r[0] |= c.r[1];  // 0604C92A or r1,r0
    c.r[11] = c.r[0];  // 0604C92C mov r0,r11
    c.r[1] = c.r[2];  // 0604C92E mov r2,r1
    c.r[1] += 6;  // 0604C930 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C932 mov.b @r1,r1
    c.r[11] >>= 2;  // 0604C934 shlr2 r11
    c.r[11] >>= 2;  // 0604C936 shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 0604C938 shlr r11
    c.r[11] >>= 2;  // 0604C93A shlr2 r11
    c.r[10] = c.r[1];  // 0604C93C mov r1,r10
    c.r[10] <<= 16;  // 0604C93E shll16 r10
    c.r[10] <<= 8;  // 0604C940 shll8 r10
    c.r[1] = c.r[2];  // 0604C942 mov r2,r1
    c.r[1] += 7;  // 0604C944 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C946 mov.b @r1,r1
    c.r[12] = 0x7Fu;  // 0604C948 mov #127,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0604C94A extu.b r1,r1
    c.r[1] <<= 16;  // 0604C94C shll16 r1
    c.r[10] |= c.r[1];  // 0604C94E or r1,r10
    c.r[1] = c.r[2];  // 0604C950 mov r2,r1
    c.r[1] += 8;  // 0604C952 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C954 mov.b @r1,r1
    c.r[2] += 9;  // 0604C956 add #9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604C958 extu.b r1,r1
    c.r[1] <<= 8;  // 0604C95A shll8 r1
    c.r[10] |= c.r[1];  // 0604C95C or r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604C95E mov.b @r2,r1
    c.r[12] &= c.r[0];  // 0604C960 and r0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0604C962 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0604C964 or r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604CA74u);  // 0604C966 mov.w 0x0604CA74,r1
    c.t = c.r[9] == c.r[1];  // 0604C968 cmp/eq r1,r9
    { const bool k = !c.t; st32(c.r[14], c.r[10]); if (k) { goto L_0604C97E; } }  // 0604C96A bf/s 0x0604C97E ; mov.l r10,@r14
    c.r[1] = ld32(0x0604CA9Cu);  // 0604C96E mov.l 0x0604CA9C,r1
    c.r[1] = ld32(c.r[1]);  // 0604C970 mov.l @r1,r1
    c.r[1] += 8;  // 0604C972 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C974 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0604C976 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604C978 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0604C990; } }  // 0604C97A bt/s 0x0604C990 ; mov r8,r2
L_0604C97E:
    c.r[0] = ld32(0x0604CAA0u);  // 0604C97E mov.l 0x0604CAA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604C984u; c.r[4] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C984u) return; }  // 0604C980 jsr @r0 ; mov #22,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0604C984 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604C986 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0604CA10; } }  // 0604C988 bt/s 0x0604CA10 ; mov r8,r2
    c.r[8] = ld32(0x0604CA80u);  // 0604C98C mov.l 0x0604CA80,r8
    c.r[2] = c.r[8];  // 0604C98E mov r8,r2
L_0604C990:
    c.r[2] += 1;  // 0604C990 add #1,r2
    c.r[4] = ld32(0x0604CAA4u);  // 0604C992 mov.l 0x0604CAA4,r4
    c.r[0] = ld32(0x0604CAA8u);  // 0604C994 mov.l 0x0604CAA8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604C996 mov.b @r2,r1
    c.r[5] = 0x5u;  // 0604C998 mov #5,r5
    c.r[1] += 1;  // 0604C99A add #1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0604C9A0u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604C9A0u) return; }  // 0604C99C jsr @r0 ; mov.b r1,@r2
    c.r[7] = c.r[0];  // 0604C9A0 mov r0,r7
    c.r[0] = c.r[11];  // 0604C9A2 mov r11,r0
    c.r[0] += c.r[0];  // 0604C9A4 add r0,r0
    c.r[0] += c.r[11];  // 0604C9A6 add r11,r0
    c.r[2] = c.r[0];  // 0604C9A8 mov r0,r2
    c.r[2] += c.r[7];  // 0604C9AA add r7,r2
    c.r[1] = c.r[2];  // 0604C9AC mov r2,r1
    c.r[1] += 1;  // 0604C9AE add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604C9B0 mov.b @(r0,r7),r3
    c.r[2] += 2;  // 0604C9B2 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C9B4 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0604C9B6 extu.b r3,r3
    c.r[3] <<= 16;  // 0604C9B8 shll16 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604C9BA extu.b r1,r1
    c.r[1] <<= 8;  // 0604C9BC shll8 r1
    c.r[3] |= c.r[1];  // 0604C9BE or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604C9C0 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C9C2 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0604C9C4 or r1,r3
    c.r[3] += c.r[7];  // 0604C9C6 add r7,r3
    c.r[1] = c.r[12];  // 0604C9C8 mov r12,r1
    c.r[1] -= 1;  // 0604C9CA add #-1,r1
    c.r[2] = c.r[1];  // 0604C9CC mov r1,r2
    c.r[2] += c.r[2];  // 0604C9CE add r2,r2
    c.r[2] += c.r[1];  // 0604C9D0 add r1,r2
    c.r[2] += c.r[2];  // 0604C9D2 add r2,r2
    c.r[3] += c.r[2];  // 0604C9D4 add r2,r3
    c.r[1] = c.r[3];  // 0604C9D6 mov r3,r1
    c.r[1] += 3;  // 0604C9D8 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C9DA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604C9DC extu.b r2,r2
    c.r[2] <<= 16;  // 0604C9DE shll16 r2
    c.r[1] = c.r[3];  // 0604C9E0 mov r3,r1
    c.r[1] += 4;  // 0604C9E2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604C9E4 mov.b @r1,r1
    c.r[3] += 5;  // 0604C9E6 add #5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604C9E8 extu.b r1,r1
    c.r[1] <<= 8;  // 0604C9EA shll8 r1
    c.r[2] |= c.r[1];  // 0604C9EC or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604C9EE mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604C9F0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604C9F2 or r1,r2
    c.r[2] += 1;  // 0604C9F4 add #1,r2
    c.r[1] = ld32(0x0604CAACu);  // 0604C9F6 mov.l 0x0604CAAC,r1
    c.r[1] = ld32(c.r[1]);  // 0604C9F8 mov.l @r1,r1
    c.r[2] <<= 2;  // 0604C9FA shll2 r2
    c.r[2] <<= 2;  // 0604C9FC shll2 r2
    c.r[2] <<= 2;  // 0604C9FE shll2 r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0604CA00 dmulu.l r1,r2
    c.r[1] = c.mach;  // 0604CA02 sts mach,r1
    c.r[2] -= c.r[1];  // 0604CA04 sub r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604CA06 shlr r2
    c.r[1] += c.r[2];  // 0604CA08 add r2,r1
    c.r[1] >>= 8;  // 0604CA0A shlr8 r1
    st32(c.r[8] + 12, c.r[1]); goto L_0604CB02;  // 0604CA0C bra 0x0604CB02 ; mov.l r1,@(12,r8)
L_0604CA10:
    c.r[2] += 1;  // 0604CA10 add #1,r2
    c.r[10] = ld32(0x0604CAB0u);  // 0604CA12 mov.l 0x0604CAB0,r10
    c.r[11] <<= 2;  // 0604CA14 shll2 r11
    c.r[11] <<= 2;  // 0604CA16 shll2 r11
    c.r[11] += c.r[11];  // 0604CA18 add r11,r11
    c.r[11] <<= 2;  // 0604CA1A shll2 r11
    c.r[12] -= 1;  // 0604CA1C add #-1,r12
    c.r[11] |= c.r[12];  // 0604CA1E or r12,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604CA20 mov.b @r2,r1
    c.r[8] = ld32(0x0604CAA8u);  // 0604CA22 mov.l 0x0604CAA8,r8
    c.r[1] += 1;  // 0604CA24 add #1,r1
    st8(c.r[2], c.r[1]);  // 0604CA26 mov.b r1,@r2
    st32(c.r[14] + 8, c.r[10]);  // 0604CA28 mov.l r10,@(8,r14)
    c.r[1] = c.r[10];  // 0604CA2A mov r10,r1
    c.r[1] += 68;  // 0604CA2C add #68,r1
    st16(c.r[1], c.r[13]);  // 0604CA2E mov.w r13,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0604CA30 mov.l @(8,r14),r1
    c.r[5] = 0x1Cu;  // 0604CA32 mov #28,r5
    c.r[1] += 70;  // 0604CA34 add #70,r1
    st16(c.r[1], c.r[11]);  // 0604CA36 mov.w r11,@r1
    c.r[11] = ld32(0x0604CAA4u);  // 0604CA38 mov.l 0x0604CAA4,r11
    { const uint32_t x = c.r[8]; c.pr = 0x0604CA3Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CA3Eu) return; }  // 0604CA3A jsr @r8 ; mov r11,r4
    c.r[5] = c.r[9];  // 0604CA3E mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604CA44u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CA44u) return; }  // 0604CA40 jsr @r8 ; mov r0,r4
    c.r[5] = 0x1Cu;  // 0604CA44 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604CA4Au; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CA4Au) return; }  // 0604CA46 jsr @r8 ; mov r11,r4
    c.r[5] = c.r[9];  // 0604CA4A mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604CA50u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CA50u) return; }  // 0604CA4C jsr @r8 ; mov r0,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x0604CA76u);  // 0604CA50 mov.w 0x0604CA76,r12
    c.r[13] = ld32(0x0604CAB4u);  // 0604CA52 mov.l 0x0604CAB4,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604CA78u);  // 0604CA54 mov.w 0x0604CA78,r1
    c.r[9] += c.r[1];  // 0604CA56 add r1,r9
    c.r[2] = c.r[9] & 0xFFFFu;  // 0604CA58 extu.w r9,r2
    c.r[1] = 0x1u;  // 0604CA5A mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0604CA5C cmp/hi r1,r2
    { const bool k = c.t; c.r[5] = 0x1Cu; if (k) { goto L_0604CAB8; } }  // 0604CA5E bt/s 0x0604CAB8 ; mov #28,r5
    c.r[10] += 64;  // 0604CA62 add #64,r10
    st32(c.r[14] + 8, c.r[10]);  // 0604CA64 mov.l r10,@(8,r14)
    c.r[1] = ld32(0x0604CA9Cu);  // 0604CA66 mov.l 0x0604CA9C,r1
    c.r[1] = ld32(c.r[1]);  // 0604CA68 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604CA7Au);  // 0604CA6A mov.w 0x0604CA7A,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604CA6C mov.b @(r0,r1),r0
    c.r[0] &= 0x1u;  // 0604CA6E and #1,r0
    st16(c.r[10], c.r[0]); goto L_0604CAFC;  // 0604CA70 bra 0x0604CAFC ; mov.w r0,@r10
L_0604CAB8:
    { const uint32_t x = c.r[8]; c.pr = 0x0604CABCu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CABCu) return; }  // 0604CAB8 jsr @r8 ; mov r11,r4
    c.r[5] = ld32(c.r[14] + 4);  // 0604CABC mov.l @(4,r14),r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604CAC2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CAC2u) return; }  // 0604CABE jsr @r8 ; mov r0,r4
    c.r[9] = c.r[0];  // 0604CAC2 mov r0,r9
    c.r[5] = 0x1Cu;  // 0604CAC4 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604CACAu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CACAu) return; }  // 0604CAC6 jsr @r8 ; mov r11,r4
    c.r[5] = ld32(c.r[14] + 4);  // 0604CACA mov.l @(4,r14),r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604CAD0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CAD0u) return; }  // 0604CACC jsr @r8 ; mov r0,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604CAD0 mov.b @r9,r4
    c.r[0] += 1;  // 0604CAD2 add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604CAD4 mov.b @r0,r1
    c.r[2] = 0x0u;  // 0604CAD6 mov #0,r2
    c.r[3] = ld32(c.r[14] + 8);  // 0604CAD8 mov.l @(8,r14),r3
    c.r[4] = c.r[4] & 0xFFu;  // 0604CADA extu.b r4,r4
    c.r[4] <<= 8;  // 0604CADC shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0604CADE extu.b r1,r1
    c.r[4] |= c.r[1];  // 0604CAE0 or r1,r4
    { const uint32_t x = c.r[13]; c.pr = 0x0604CAE6u; c.r[4] &= c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CAE6u) return; }  // 0604CAE2 jsr @r13 ; and r12,r4
    c.r[0] = c.r[4] & 0xFFFFu;  // 0604CAE6 extu.w r4,r0
    c.r[1] = 0x6u;  // 0604CAE8 mov #6,r1
    c.t = c.r[0] > c.r[1];  // 0604CAEA cmp/hi r1,r0
    { const bool k = !c.t; c.r[3] += 64; if (k) { goto L_0604CAF8; } }  // 0604CAEC bf/s 0x0604CAF8 ; add #64,r3
    c.t = c.r[0] == 0x11u;  // 0604CAF0 cmp/eq #17,r0
    { const bool k = c.t; c.t = c.r[0] == 0x14u; if (k) { goto L_0604CAF8; } }  // 0604CAF2 bt/s 0x0604CAF8 ; cmp/eq #20,r0
    if (!c.t) { goto L_0604CAFA; }  // 0604CAF6 bf 0x0604CAFA
L_0604CAF8:
    c.r[2] = 0x1u;  // 0604CAF8 mov #1,r2
L_0604CAFA:
    st16(c.r[3], c.r[2]);  // 0604CAFA mov.w r2,@r3
L_0604CAFC:
    c.r[2] = ld32(0x0604CB40u);  // 0604CAFC mov.l 0x0604CB40,r2
    c.r[1] = 0x2u;  // 0604CAFE mov #2,r1
    st16(c.r[2], c.r[1]);  // 0604CB00 mov.w r1,@r2
L_0604CB02:
    c.r[6] = ld32(0x0604CB44u);  // 0604CB02 mov.l 0x0604CB44,r6
    c.r[1] = ld32(0x0604CB48u);  // 0604CB04 mov.l 0x0604CB48,r1
    c.r[7] = 0x0u;  // 0604CB06 mov #0,r7
    c.r[5] = 0x2u;  // 0604CB08 mov #2,r5
    c.r[10] = ld32(c.r[14]);  // 0604CB0A mov.l @r14,r10
    c.r[4] = 0x0u;  // 0604CB0C mov #0,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0604CB12u; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CB12u) return; }  // 0604CB0E jsr @r1 ; mov.l r10,@-r15
    c.r[1] = ld32(0x0604CB4Cu);  // 0604CB12 mov.l 0x0604CB4C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CB14 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0604CB16 or #128,r0
    st8(c.r[1], c.r[0]);  // 0604CB18 mov.b r0,@r1
    c.r[1] = ld32(0x0604CB50u);  // 0604CB1A mov.l 0x0604CB50,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0604CB1C mov.l @(4,r1),r2
    c.r[2] += 10;  // 0604CB1E add #10,r2
    st32(c.r[1] + 4, c.r[2]); goto L_0604CB28;  // 0604CB20 bra 0x0604CB28 ; mov.l r2,@(4,r1)
L_0604CB24:
    c.r[7] += 4;  // 0604CB24 add #4,r7
    st32(c.r[3] + 4, c.r[7]);  // 0604CB26 mov.l r7,@(4,r3)
L_0604CB28:
    c.r[14] += 12;  // 0604CB28 add #12,r14
    c.r[15] = c.r[14];  // 0604CB2A mov r14,r15
L_0604CB2C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604CB2C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604CB2E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604CB30 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604CB32 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604CB34 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604CB36 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604CB38 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604CB3A rts ; mov.l @r15+,r8
}

void f_0604CB54(SH2Context& c) {
    ran[1238] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604CB54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604CB56 sts.l pr,@-r15
    c.r[7] = c.r[4];  // 0604CB58 mov r4,r7
    c.r[7] += 20;  // 0604CB5A add #20,r7
    c.r[1] = c.r[4];  // 0604CB5C mov r4,r1
    c.r[1] += 21;  // 0604CB5E add #21,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CB60 mov.b @r7,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604CBDEu);  // 0604CB62 mov.w 0x0604CBDE,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CB64 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CB66 extu.b r2,r2
    c.r[2] <<= 8;  // 0604CB68 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CB6A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CB6C or r1,r2
    c.r[1] = c.r[6] & 0xFFFFu;  // 0604CB6E extu.w r6,r1
    c.t = c.r[2] == c.r[1];  // 0604CB70 cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604CBA6; } }  // 0604CB72 bt/s 0x0604CBA6 ; mov r15,r14
    c.r[1] = ld32(0x0604CBE0u);  // 0604CB76 mov.l 0x0604CBE0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CB78 mov.b @r1,r1
    c.r[3] = c.r[4];  // 0604CB7A mov r4,r3
    c.r[3] += 21;  // 0604CB7C add #21,r3
    c.r[5] = c.r[1] & 0xFFu;  // 0604CB7E extu.b r1,r5
L_0604CB80:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CB80 mov.b @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CB82 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CB84 extu.b r2,r2
    c.r[2] <<= 8;  // 0604CB86 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CB88 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CB8A or r1,r2
    c.t = c.r[2] == c.r[5];  // 0604CB8C cmp/eq r5,r2
    if (c.t) { goto L_0604CBA6; }  // 0604CB8E bt 0x0604CBA6
    c.r[7] += 6;  // 0604CB90 add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CB92 mov.b @r7,r1
    c.r[3] += 6;  // 0604CB94 add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CB96 mov.b @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CB98 extu.b r1,r1
    c.r[1] <<= 8;  // 0604CB9A shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CB9C extu.b r2,r2
    c.r[1] |= c.r[2];  // 0604CB9E or r2,r1
    c.r[2] = c.r[6] & 0xFFFFu;  // 0604CBA0 extu.w r6,r2
    c.t = c.r[1] == c.r[2];  // 0604CBA2 cmp/eq r2,r1
    if (!c.t) { SH2_POLL(c); goto L_0604CB80; }  // 0604CBA4 bf 0x0604CB80
L_0604CBA6:
    c.r[1] = c.r[7];  // 0604CBA6 mov r7,r1
    c.r[1] += 2;  // 0604CBA8 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CBAA mov.b @r1,r5
    c.r[0] = ld32(0x0604CBE4u);  // 0604CBAC mov.l 0x0604CBE4,r0
    c.r[1] = c.r[7];  // 0604CBAE mov r7,r1
    c.r[1] += 3;  // 0604CBB0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CBB2 mov.b @r1,r1
    c.r[5] <<= 16;  // 0604CBB4 shll16 r5
    c.r[5] <<= 8;  // 0604CBB6 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604CBB8 extu.b r1,r1
    c.r[1] <<= 16;  // 0604CBBA shll16 r1
    c.r[5] |= c.r[1];  // 0604CBBC or r1,r5
    c.r[1] = c.r[7];  // 0604CBBE mov r7,r1
    c.r[1] += 4;  // 0604CBC0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CBC2 mov.b @r1,r1
    c.r[7] += 5;  // 0604CBC4 add #5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604CBC6 extu.b r1,r1
    c.r[1] <<= 8;  // 0604CBC8 shll8 r1
    c.r[5] |= c.r[1];  // 0604CBCA or r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CBCC mov.b @r7,r1
    c.r[6] = 0x0u;  // 0604CBCE mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604CBD0 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0604CBD6u; c.r[5] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CBD6u) return; }  // 0604CBD2 jsr @r0 ; or r1,r5
    c.r[15] = c.r[14];  // 0604CBD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604CBD8 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604CBDA rts ; mov.l @r15+,r14
}

void f_0604CBE8(SH2Context& c) {
    ran[1239] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604CBE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604CBEA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604CBEC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604CBEE mov r15,r14
    c.r[8] = c.r[4];  // 0604CBF0 mov r4,r8
    c.r[3] = ld32(0x0604CD48u);  // 0604CBF2 mov.l 0x0604CD48,r3
    c.r[2] = ld32(0x0604CD4Cu);  // 0604CBF4 mov.l 0x0604CD4C,r2
    c.r[1] = c.r[2];  // 0604CBF6 mov r2,r1
    c.r[1] += 6;  // 0604CBF8 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CBFA mov.w @r1,r1
    c.r[5] = ld32(0x0604CD50u);  // 0604CBFC mov.l 0x0604CD50,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604CBFE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604CC00 tst r1,r1
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_0604CC08; } }  // 0604CC02 bt/s 0x0604CC08 ; mov r8,r6
    c.r[5] = c.r[2];  // 0604CC06 mov r2,r5
L_0604CC08:
    c.r[2] = ld32(0x0604CD54u);  // 0604CC08 mov.l 0x0604CD54,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604CC0A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604CC0C extu.b r1,r1
    c.r[0] = c.r[1];  // 0604CC0E mov r1,r0
    c.r[0] >>= 2;  // 0604CC10 shlr2 r0
    c.r[0] >>= 2;  // 0604CC12 shlr2 r0
    c.r[0] >>= 2;  // 0604CC14 shlr2 r0
    c.r[0] &= 0x1u;  // 0604CC16 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CC18 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0604CCD6; } }  // 0604CC1A bt/s 0x0604CCD6 ; mov r1,r0
    c.r[0] >>= 2;  // 0604CC1E shlr2 r0
    c.r[0] >>= 2;  // 0604CC20 shlr2 r0
    c.r[0] &= 0x1u;  // 0604CC22 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CC24 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0604CC3C; } }  // 0604CC26 bt/s 0x0604CC3C ; mov r1,r0
    c.r[1] = c.r[8];  // 0604CC2A mov r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604CC2C mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CC2E extu.b r2,r2
    c.r[5] = c.r[2];  // 0604CC30 mov r2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CC32 mov.b @r1,r1
    c.r[5] <<= 8;  // 0604CC34 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604CC36 extu.b r1,r1
    c.r[5] |= c.r[1]; goto L_0604CD36;  // 0604CC38 bra 0x0604CD36 ; or r1,r5
L_0604CC3C:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604CC3C shlr r0
    c.r[0] &= 0x1u;  // 0604CC3E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CC40 tst r0,r0
    if (!c.t) { goto L_0604CC66; }  // 0604CC42 bf 0x0604CC66
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CC44 mov.b @r3,r0
    c.r[0] &= 0x1Fu;  // 0604CC46 and #31,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CC48 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0604CC68; } }  // 0604CC4A bt/s 0x0604CC68 ; mov r5,r1
    c.r[1] = c.r[8];  // 0604CC4E mov r8,r1
    c.r[1] += 12;  // 0604CC50 add #12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CC52 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CC54 extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CC56 mov r8,r1
    c.r[1] += 13;  // 0604CC58 add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CC5A mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CC5C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CC5E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CC60 or r1,r2
    c.r[2] += 12; goto L_0604CD34;  // 0604CC62 bra 0x0604CD34 ; add #12,r2
L_0604CC66:
    c.r[1] = c.r[5];  // 0604CC66 mov r5,r1
L_0604CC68:
    c.r[1] += 14;  // 0604CC68 add #14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CC6A mov.w @r1,r2
    c.r[5] += 16;  // 0604CC6C add #16,r5
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0604CC6E mov.w @r5,r5
    c.r[1] = ld32(0x0604CD58u);  // 0604CC70 mov.l 0x0604CD58,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CC72 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604CC74 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604CC76 extu.w r1,r1
    c.r[2] -= c.r[1];  // 0604CC78 sub r1,r2
    c.r[1] = 0x64u;  // 0604CC7A mov #100,r1
    c.macl = c.r[2] * c.r[1];  // 0604CC7C mul.l r1,r2
    c.r[7] = ld32(0x0604CD5Cu);  // 0604CC7E mov.l 0x0604CD5C,r7
    c.r[5] = c.r[5] & 0xFFFFu;  // 0604CC80 extu.w r5,r5
    { const uint32_t x = c.r[7]; c.pr = 0x0604CC86u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CC86u) return; }  // 0604CC82 jsr @r7 ; sts macl,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0604CC86 extu.w r0,r1
    c.r[2] = c.r[1];  // 0604CC88 mov r1,r2
    c.r[1] = 0x59u;  // 0604CC8A mov #89,r1
    c.t = c.r[2] > c.r[1];  // 0604CC8C cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0604CCA6; } }  // 0604CC8E bf/s 0x0604CCA6 ; mov r6,r1
    c.r[1] += 6;  // 0604CC92 add #6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CC94 mov.b @r1,r2
    c.r[6] += 7;  // 0604CC96 add #7,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0604CC98 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604CC9A mov.b @r6,r1
    c.r[2] <<= 8;  // 0604CC9C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CC9E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CCA0 or r1,r2
    c.r[2] += 6; goto L_0604CD34;  // 0604CCA2 bra 0x0604CD34 ; add #6,r2
L_0604CCA6:
    c.r[1] = 0x1Du;  // 0604CCA6 mov #29,r1
    c.t = c.r[2] > c.r[1];  // 0604CCA8 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0604CCC2; } }  // 0604CCAA bf/s 0x0604CCC2 ; mov r6,r1
    c.r[1] += 4;  // 0604CCAE add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CCB0 mov.b @r1,r2
    c.r[6] += 5;  // 0604CCB2 add #5,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0604CCB4 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604CCB6 mov.b @r6,r1
    c.r[2] <<= 8;  // 0604CCB8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CCBA extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CCBC or r1,r2
    c.r[2] += 4; goto L_0604CD34;  // 0604CCBE bra 0x0604CD34 ; add #4,r2
L_0604CCC2:
    c.r[1] += 2;  // 0604CCC2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CCC4 mov.b @r1,r2
    c.r[6] += 3;  // 0604CCC6 add #3,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0604CCC8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604CCCA mov.b @r6,r1
    c.r[2] <<= 8;  // 0604CCCC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CCCE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CCD0 or r1,r2
    c.r[2] += 2; goto L_0604CD34;  // 0604CCD2 bra 0x0604CD34 ; add #2,r2
L_0604CCD6:
    c.r[0] >>= 2;  // 0604CCD6 shlr2 r0
    c.r[0] &= 0x3u;  // 0604CCD8 and #3,r0
    c.t = c.r[0] == 0x1u;  // 0604CCDA cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0604CCF6; } }  // 0604CCDC bf/s 0x0604CCF6 ; mov r8,r1
    c.r[1] += 14;  // 0604CCE0 add #14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CCE2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CCE4 extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CCE6 mov r8,r1
    c.r[1] += 15;  // 0604CCE8 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CCEA mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CCEC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CCEE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CCF0 or r1,r2
    c.r[2] += 14; goto L_0604CD34;  // 0604CCF2 bra 0x0604CD34 ; add #14,r2
L_0604CCF6:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604CCF6 mov.w @r2,r1
    c.r[0] = c.r[1];  // 0604CCF8 mov r1,r0
    c.r[0] >>= 2;  // 0604CCFA shlr2 r0
    c.r[0] >>= 2;  // 0604CCFC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604CCFE shlr r0
    c.r[0] >>= 2;  // 0604CD00 shlr2 r0
    c.r[0] &= 0x3u;  // 0604CD02 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CD04 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0604CD20; } }  // 0604CD06 bt/s 0x0604CD20 ; mov r8,r1
    c.r[1] += 10;  // 0604CD0A add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CD0C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CD0E extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CD10 mov r8,r1
    c.r[1] += 11;  // 0604CD12 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CD14 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CD16 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CD18 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CD1A or r1,r2
    c.r[2] += 10; goto L_0604CD34;  // 0604CD1C bra 0x0604CD34 ; add #10,r2
L_0604CD20:
    c.r[1] += 8;  // 0604CD20 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CD22 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CD24 extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CD26 mov r8,r1
    c.r[1] += 9;  // 0604CD28 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CD2A mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CD2C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CD2E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CD30 or r1,r2
    c.r[2] += 8;  // 0604CD32 add #8,r2
L_0604CD34:
    c.r[5] = c.r[2] & 0xFFFFu;  // 0604CD34 extu.w r2,r5
L_0604CD36:
    c.r[0] = ld32(0x0604CD60u);  // 0604CD36 mov.l 0x0604CD60,r0
    c.r[6] = 0x1u;  // 0604CD38 mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604CD3Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CD3Eu) return; }  // 0604CD3A jsr @r0 ; mov r8,r4
    c.r[15] = c.r[14];  // 0604CD3E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604CD40 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604CD42 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604CD44 rts ; mov.l @r15+,r8
}

void f_0604CD64(SH2Context& c) {
    ran[1240] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604CD64 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604CD66 sts.l pr,@-r15
    c.r[1] = ld32(0x0604CE84u);  // 0604CD68 mov.l 0x0604CE84,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CD6A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604CD6C mov r1,r0
    c.r[0] >>= 2;  // 0604CD6E shlr2 r0
    c.r[0] &= 0x3u;  // 0604CD70 and #3,r0
    c.r[1] = 0x1u;  // 0604CD72 mov #1,r1
    c.t = c.r[0] > c.r[1];  // 0604CD74 cmp/hi r1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604CDC8; } }  // 0604CD76 bt/s 0x0604CDC8 ; mov r15,r14
    c.r[1] = ld32(0x0604CE88u);  // 0604CD7A mov.l 0x0604CE88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CD7C mov.w @r1,r1
    c.r[0] = c.r[1];  // 0604CD7E mov r1,r0
    c.r[0] >>= 2;  // 0604CD80 shlr2 r0
    c.r[0] >>= 2;  // 0604CD82 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604CD84 shlr r0
    c.r[0] >>= 2;  // 0604CD86 shlr2 r0
    c.r[0] &= 0x3u;  // 0604CD88 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CD8A tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[4]; if (k) { goto L_0604CDCA; } }  // 0604CD8C bt/s 0x0604CDCA ; mov r4,r7
    c.t = c.r[0] == 0x3u;  // 0604CD90 cmp/eq #3,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_0604CDAC; } }  // 0604CD92 bf/s 0x0604CDAC ; mov r4,r1
    c.r[1] += 18;  // 0604CD96 add #18,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CD98 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CD9A extu.b r2,r2
    c.r[1] = c.r[4];  // 0604CD9C mov r4,r1
    c.r[1] += 19;  // 0604CD9E add #19,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CDA0 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CDA2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CDA4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CDA6 or r1,r2
    c.r[2] += 18; goto L_0604CDC0;  // 0604CDA8 bra 0x0604CDC0 ; add #18,r2
L_0604CDAC:
    c.r[1] += 16;  // 0604CDAC add #16,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CDAE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CDB0 extu.b r2,r2
    c.r[1] = c.r[4];  // 0604CDB2 mov r4,r1
    c.r[1] += 17;  // 0604CDB4 add #17,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CDB6 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CDB8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CDBA extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CDBC or r1,r2
    c.r[2] += 16;  // 0604CDBE add #16,r2
L_0604CDC0:
    c.r[5] = c.r[2] & 0xFFFFu;  // 0604CDC0 extu.w r2,r5
    c.r[0] = ld32(0x0604CE8Cu);  // 0604CDC2 mov.l 0x0604CE8C,r0
    c.r[6] = 0x2u; goto L_0604CE74;  // 0604CDC4 bra 0x0604CE74 ; mov #2,r6
L_0604CDC8:
    c.r[7] = c.r[4];  // 0604CDC8 mov r4,r7
L_0604CDCA:
    c.r[7] += 20;  // 0604CDCA add #20,r7
    c.r[1] = c.r[4];  // 0604CDCC mov r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CDCE mov.b @r7,r2
    c.r[1] += 21;  // 0604CDD0 add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CDD2 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CDD4 extu.b r2,r2
    c.r[2] <<= 8;  // 0604CDD6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CDD8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CDDA or r1,r2
    c.r[1] = ld32(0x0604CE90u);  // 0604CDDC mov.l 0x0604CE90,r1
    c.t = c.r[2] == c.r[1];  // 0604CDDE cmp/eq r1,r2
    { const bool k = c.t; c.r[6] = c.r[1]; if (k) { goto L_0604CE00; } }  // 0604CDE0 bt/s 0x0604CE00 ; mov r1,r6
    c.r[3] = c.r[4];  // 0604CDE4 mov r4,r3
    c.r[3] += 21;  // 0604CDE6 add #21,r3
    c.r[7] += 6;  // 0604CDE8 add #6,r7
L_0604CDEA:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CDEA mov.b @r7,r2
    c.r[3] += 6;  // 0604CDEC add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CDEE mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CDF0 extu.b r2,r2
    c.r[2] <<= 8;  // 0604CDF2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CDF4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CDF6 or r1,r2
    c.t = c.r[2] == c.r[6];  // 0604CDF8 cmp/eq r6,r2
    { const bool k = !c.t; c.r[7] += 6; if (k) { SH2_POLL(c); goto L_0604CDEA; } }  // 0604CDFA bf/s 0x0604CDEA ; add #6,r7
    c.r[7] -= 6;  // 0604CDFE add #-6,r7
L_0604CE00:
    c.r[7] += 6;  // 0604CE00 add #6,r7
    c.r[3] = c.r[7];  // 0604CE02 mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0604CE04 mov.b @r3+,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604CE80u);  // 0604CE06 mov.w 0x0604CE80,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604CE08 extu.b r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CE0A mov.b @r3,r2
    c.r[1] <<= 8;  // 0604CE0C shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CE0E extu.b r2,r2
    c.r[1] |= c.r[2];  // 0604CE10 or r2,r1
    c.r[2] = c.r[6] & 0xFFFFu;  // 0604CE12 extu.w r6,r2
    c.t = c.r[1] == c.r[2];  // 0604CE14 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0604CE48; } }  // 0604CE16 bt/s 0x0604CE48 ; mov r7,r1
    c.r[1] = ld32(0x0604CE94u);  // 0604CE1A mov.l 0x0604CE94,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CE1C mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0604CE1E extu.b r1,r5
L_0604CE20:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CE20 mov.b @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CE22 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CE24 extu.b r2,r2
    c.r[2] <<= 8;  // 0604CE26 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CE28 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CE2A or r1,r2
    c.t = c.r[2] == c.r[5];  // 0604CE2C cmp/eq r5,r2
    if (c.t) { goto L_0604CE46; }  // 0604CE2E bt 0x0604CE46
    c.r[7] += 6;  // 0604CE30 add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CE32 mov.b @r7,r1
    c.r[3] += 6;  // 0604CE34 add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CE36 mov.b @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CE38 extu.b r1,r1
    c.r[1] <<= 8;  // 0604CE3A shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604CE3C extu.b r2,r2
    c.r[1] |= c.r[2];  // 0604CE3E or r2,r1
    c.r[2] = c.r[6] & 0xFFFFu;  // 0604CE40 extu.w r6,r2
    c.t = c.r[1] == c.r[2];  // 0604CE42 cmp/eq r2,r1
    if (!c.t) { SH2_POLL(c); goto L_0604CE20; }  // 0604CE44 bf 0x0604CE20
L_0604CE46:
    c.r[1] = c.r[7];  // 0604CE46 mov r7,r1
L_0604CE48:
    c.r[1] += 2;  // 0604CE48 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CE4A mov.b @r1,r5
    c.r[0] = ld32(0x0604CE8Cu);  // 0604CE4C mov.l 0x0604CE8C,r0
    c.r[1] = c.r[7];  // 0604CE4E mov r7,r1
    c.r[1] += 3;  // 0604CE50 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CE52 mov.b @r1,r1
    c.r[5] <<= 16;  // 0604CE54 shll16 r5
    c.r[5] <<= 8;  // 0604CE56 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604CE58 extu.b r1,r1
    c.r[1] <<= 16;  // 0604CE5A shll16 r1
    c.r[5] |= c.r[1];  // 0604CE5C or r1,r5
    c.r[1] = c.r[7];  // 0604CE5E mov r7,r1
    c.r[1] += 4;  // 0604CE60 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CE62 mov.b @r1,r1
    c.r[7] += 5;  // 0604CE64 add #5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604CE66 extu.b r1,r1
    c.r[1] <<= 8;  // 0604CE68 shll8 r1
    c.r[5] |= c.r[1];  // 0604CE6A or r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604CE6C mov.b @r7,r1
    c.r[6] = 0x2u;  // 0604CE6E mov #2,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604CE70 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0604CE72 or r1,r5
L_0604CE74:
    { const uint32_t x = c.r[0]; c.pr = 0x0604CE78u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CE78u) return; }  // 0604CE74 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 0604CE78 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604CE7A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604CE7C rts ; mov.l @r15+,r14
}

void f_0604CE98(SH2Context& c) {
    ran[1241] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604CE98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604CE9A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604CE9C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604CE9E mov r15,r14
    c.r[8] = c.r[4];  // 0604CEA0 mov r4,r8
    c.r[2] = ld32(0x0604CFF8u);  // 0604CEA2 mov.l 0x0604CFF8,r2
    c.r[1] = c.r[2];  // 0604CEA4 mov r2,r1
    c.r[1] += 6;  // 0604CEA6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CEA8 mov.w @r1,r1
    c.r[5] = ld32(0x0604CFFCu);  // 0604CEAA mov.l 0x0604CFFC,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604CEAC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604CEAE tst r1,r1
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_0604CEB6; } }  // 0604CEB0 bt/s 0x0604CEB6 ; mov r8,r6
    c.r[5] = c.r[2];  // 0604CEB4 mov r2,r5
L_0604CEB6:
    c.r[2] = ld32(0x0604D000u);  // 0604CEB6 mov.l 0x0604D000,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604CEB8 mov.b @r2,r1
    c.r[3] = ld32(0x0604D004u);  // 0604CEBA mov.l 0x0604D004,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604CEBC extu.b r1,r1
    c.r[0] = c.r[1];  // 0604CEBE mov r1,r0
    c.r[0] >>= 2;  // 0604CEC0 shlr2 r0
    c.r[0] >>= 2;  // 0604CEC2 shlr2 r0
    c.r[0] >>= 2;  // 0604CEC4 shlr2 r0
    c.r[0] &= 0x1u;  // 0604CEC6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CEC8 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0604CF86; } }  // 0604CECA bt/s 0x0604CF86 ; mov r1,r0
    c.r[0] >>= 2;  // 0604CECE shlr2 r0
    c.r[0] >>= 2;  // 0604CED0 shlr2 r0
    c.r[0] &= 0x1u;  // 0604CED2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CED4 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0604CEEC; } }  // 0604CED6 bt/s 0x0604CEEC ; mov r1,r0
    c.r[1] = c.r[8];  // 0604CEDA mov r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604CEDC mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CEDE extu.b r2,r2
    c.r[5] = c.r[2];  // 0604CEE0 mov r2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CEE2 mov.b @r1,r1
    c.r[5] <<= 8;  // 0604CEE4 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604CEE6 extu.b r1,r1
    c.r[5] |= c.r[1]; goto L_0604CFE6;  // 0604CEE8 bra 0x0604CFE6 ; or r1,r5
L_0604CEEC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604CEEC shlr r0
    c.r[0] &= 0x1u;  // 0604CEEE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CEF0 tst r0,r0
    if (!c.t) { goto L_0604CF16; }  // 0604CEF2 bf 0x0604CF16
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604CEF4 mov.b @r3,r0
    c.r[0] &= 0x1Fu;  // 0604CEF6 and #31,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CEF8 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0604CF18; } }  // 0604CEFA bt/s 0x0604CF18 ; mov r5,r1
    c.r[1] = c.r[8];  // 0604CEFE mov r8,r1
    c.r[1] += 12;  // 0604CF00 add #12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF02 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CF04 extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CF06 mov r8,r1
    c.r[1] += 13;  // 0604CF08 add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF0A mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CF0C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CF0E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CF10 or r1,r2
    c.r[2] += 12; goto L_0604CFE4;  // 0604CF12 bra 0x0604CFE4 ; add #12,r2
L_0604CF16:
    c.r[1] = c.r[5];  // 0604CF16 mov r5,r1
L_0604CF18:
    c.r[1] += 14;  // 0604CF18 add #14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CF1A mov.w @r1,r2
    c.r[5] += 16;  // 0604CF1C add #16,r5
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0604CF1E mov.w @r5,r5
    c.r[1] = ld32(0x0604D008u);  // 0604CF20 mov.l 0x0604D008,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604CF22 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604CF24 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604CF26 extu.w r1,r1
    c.r[2] -= c.r[1];  // 0604CF28 sub r1,r2
    c.r[1] = 0x64u;  // 0604CF2A mov #100,r1
    c.macl = c.r[2] * c.r[1];  // 0604CF2C mul.l r1,r2
    c.r[7] = ld32(0x0604D00Cu);  // 0604CF2E mov.l 0x0604D00C,r7
    c.r[5] = c.r[5] & 0xFFFFu;  // 0604CF30 extu.w r5,r5
    { const uint32_t x = c.r[7]; c.pr = 0x0604CF36u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CF36u) return; }  // 0604CF32 jsr @r7 ; sts macl,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0604CF36 extu.w r0,r1
    c.r[2] = c.r[1];  // 0604CF38 mov r1,r2
    c.r[1] = 0x59u;  // 0604CF3A mov #89,r1
    c.t = c.r[2] > c.r[1];  // 0604CF3C cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0604CF56; } }  // 0604CF3E bf/s 0x0604CF56 ; mov r6,r1
    c.r[1] += 6;  // 0604CF42 add #6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF44 mov.b @r1,r2
    c.r[6] += 7;  // 0604CF46 add #7,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0604CF48 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604CF4A mov.b @r6,r1
    c.r[2] <<= 8;  // 0604CF4C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CF4E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CF50 or r1,r2
    c.r[2] += 6; goto L_0604CFE4;  // 0604CF52 bra 0x0604CFE4 ; add #6,r2
L_0604CF56:
    c.r[1] = 0x1Du;  // 0604CF56 mov #29,r1
    c.t = c.r[2] > c.r[1];  // 0604CF58 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0604CF72; } }  // 0604CF5A bf/s 0x0604CF72 ; mov r6,r1
    c.r[1] += 4;  // 0604CF5E add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF60 mov.b @r1,r2
    c.r[6] += 5;  // 0604CF62 add #5,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0604CF64 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604CF66 mov.b @r6,r1
    c.r[2] <<= 8;  // 0604CF68 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CF6A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CF6C or r1,r2
    c.r[2] += 4; goto L_0604CFE4;  // 0604CF6E bra 0x0604CFE4 ; add #4,r2
L_0604CF72:
    c.r[1] += 2;  // 0604CF72 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF74 mov.b @r1,r2
    c.r[6] += 3;  // 0604CF76 add #3,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0604CF78 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604CF7A mov.b @r6,r1
    c.r[2] <<= 8;  // 0604CF7C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CF7E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CF80 or r1,r2
    c.r[2] += 2; goto L_0604CFE4;  // 0604CF82 bra 0x0604CFE4 ; add #2,r2
L_0604CF86:
    c.r[0] >>= 2;  // 0604CF86 shlr2 r0
    c.r[0] &= 0x3u;  // 0604CF88 and #3,r0
    c.t = c.r[0] == 0x1u;  // 0604CF8A cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0604CFA6; } }  // 0604CF8C bf/s 0x0604CFA6 ; mov r8,r1
    c.r[1] += 14;  // 0604CF90 add #14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF92 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CF94 extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CF96 mov r8,r1
    c.r[1] += 15;  // 0604CF98 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CF9A mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CF9C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CF9E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CFA0 or r1,r2
    c.r[2] += 14; goto L_0604CFE4;  // 0604CFA2 bra 0x0604CFE4 ; add #14,r2
L_0604CFA6:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604CFA6 mov.w @r2,r1
    c.r[0] = c.r[1];  // 0604CFA8 mov r1,r0
    c.r[0] >>= 2;  // 0604CFAA shlr2 r0
    c.r[0] >>= 2;  // 0604CFAC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604CFAE shlr r0
    c.r[0] >>= 2;  // 0604CFB0 shlr2 r0
    c.r[0] &= 0x3u;  // 0604CFB2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604CFB4 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0604CFD0; } }  // 0604CFB6 bt/s 0x0604CFD0 ; mov r8,r1
    c.r[1] += 10;  // 0604CFBA add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CFBC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CFBE extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CFC0 mov r8,r1
    c.r[1] += 11;  // 0604CFC2 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CFC4 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CFC6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CFC8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CFCA or r1,r2
    c.r[2] += 10; goto L_0604CFE4;  // 0604CFCC bra 0x0604CFE4 ; add #10,r2
L_0604CFD0:
    c.r[1] += 8;  // 0604CFD0 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CFD2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604CFD4 extu.b r2,r2
    c.r[1] = c.r[8];  // 0604CFD6 mov r8,r1
    c.r[1] += 9;  // 0604CFD8 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604CFDA mov.b @r1,r1
    c.r[2] <<= 8;  // 0604CFDC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604CFDE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604CFE0 or r1,r2
    c.r[2] += 8;  // 0604CFE2 add #8,r2
L_0604CFE4:
    c.r[5] = c.r[2] & 0xFFFFu;  // 0604CFE4 extu.w r2,r5
L_0604CFE6:
    c.r[0] = ld32(0x0604D010u);  // 0604CFE6 mov.l 0x0604D010,r0
    c.r[6] = 0x3u;  // 0604CFE8 mov #3,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604CFEEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604CFEEu) return; }  // 0604CFEA jsr @r0 ; mov r8,r4
    c.r[15] = c.r[14];  // 0604CFEE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604CFF0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604CFF2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604CFF4 rts ; mov.l @r15+,r8
}

void f_0604D014(SH2Context& c) {
    ran[1242] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604D014 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604D016 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604D018 mov r15,r14
    c.r[2] = ld32(0x0604D068u);  // 0604D01A mov.l 0x0604D068,r2
    c.r[4] = ld32(c.r[2] + 12);  // 0604D01C mov.l @(12,r2),r4
    c.r[1] = ld32(0x0604D06Cu);  // 0604D01E mov.l 0x0604D06C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604D024u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D024u) return; }  // 0604D020 jsr @r1 ; add r2,r4
    c.r[1] = ld32(0x0604D070u);  // 0604D024 mov.l 0x0604D070,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604D026 mov.w @r1,r1
    c.r[2] = ld32(0x0604D074u);  // 0604D028 mov.l 0x0604D074,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D02A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D02C tst r1,r1
    if (c.t) { goto L_0604D032; }  // 0604D02E bt 0x0604D032
    c.r[2] = ld32(0x0604D078u);  // 0604D030 mov.l 0x0604D078,r2
L_0604D032:
    c.r[1] = ld32(c.r[2] + 12);  // 0604D032 mov.l @(12,r2),r1
    c.r[2] += c.r[1];  // 0604D034 add r1,r2
    c.r[1] = ld32(0x0604D07Cu);  // 0604D036 mov.l 0x0604D07C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604D03Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D03Cu) return; }  // 0604D038 jsr @r1 ; mov r2,r4
    c.r[2] = ld32(0x0604D074u);  // 0604D03C mov.l 0x0604D074,r2
    c.r[4] = ld32(c.r[2] + 12);  // 0604D03E mov.l @(12,r2),r4
    c.r[1] = ld32(0x0604D080u);  // 0604D040 mov.l 0x0604D080,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604D046u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D046u) return; }  // 0604D042 jsr @r1 ; add r2,r4
    c.r[1] = ld32(0x0604D084u);  // 0604D046 mov.l 0x0604D084,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604D048 mov.w @r1,r1
    c.r[2] = ld32(0x0604D068u);  // 0604D04A mov.l 0x0604D068,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D04C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D04E tst r1,r1
    if (c.t) { goto L_0604D054; }  // 0604D050 bt 0x0604D054
    c.r[2] = ld32(0x0604D088u);  // 0604D052 mov.l 0x0604D088,r2
L_0604D054:
    c.r[1] = ld32(c.r[2] + 12);  // 0604D054 mov.l @(12,r2),r1
    c.r[2] += c.r[1];  // 0604D056 add r1,r2
    c.r[1] = ld32(0x0604D08Cu);  // 0604D058 mov.l 0x0604D08C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604D05Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D05Eu) return; }  // 0604D05A jsr @r1 ; mov r2,r4
    c.r[15] = c.r[14];  // 0604D05E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604D060 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604D062 rts ; mov.l @r15+,r14
}

void f_0604D090(SH2Context& c) {
    ran[1243] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604D090 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604D092 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604D094 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604D096 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604D098 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604D09A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604D09C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604D09E sts.l pr,@-r15
    c.r[15] -= 4;  // 0604D0A0 add #-4,r15
    c.r[14] = c.r[15];  // 0604D0A2 mov r15,r14
    c.r[12] = c.r[4] & 0xFFFFu;  // 0604D0A4 extu.w r4,r12
    c.r[8] = ld32(0x0604D198u);  // 0604D0A6 mov.l 0x0604D198,r8
    c.r[9] = ld32(0x0604D19Cu);  // 0604D0A8 mov.l 0x0604D19C,r9
    c.r[5] = 0x2u;  // 0604D0AA mov #2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604D0B0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D0B0u) return; }  // 0604D0AC jsr @r9 ; mov r8,r4
    st32(c.r[14], c.r[0]);  // 0604D0B0 mov.l r0,@r14
    c.r[10] = c.r[12];  // 0604D0B2 mov r12,r10
    c.r[10] >>= 2;  // 0604D0B4 shlr2 r10
    c.r[10] >>= 2;  // 0604D0B6 shlr2 r10
    c.r[10] >>= 2;  // 0604D0B8 shlr2 r10
    c.r[7] = 0xFFFFFFFFu;  // 0604D0BA mov #-1,r7
    c.r[3] = 0x0u;  // 0604D0BC mov #0,r3
    c.r[1] = ld32(0x0604D1A0u);  // 0604D0BE mov.l 0x0604D1A0,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604D18Cu);  // 0604D0C0 mov.w 0x0604D18C,r13
    c.r[11] = c.r[1];  // 0604D0C2 mov r1,r11
L_0604D0C4:
    c.r[2] = c.r[11];  // 0604D0C4 mov r11,r2
    c.r[2] += 108;  // 0604D0C6 add #108,r2
    c.r[6] = ld32(c.r[2]);  // 0604D0C8 mov.l @r2,r6
    c.t = c.r[6] == c.r[12];  // 0604D0CA cmp/eq r12,r6
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0604D176; } }  // 0604D0CC bt/s 0x0604D176 ; mov r6,r1
    c.r[1] >>= 2;  // 0604D0D0 shlr2 r1
    c.r[1] >>= 2;  // 0604D0D2 shlr2 r1
    c.r[1] >>= 2;  // 0604D0D4 shlr2 r1
    c.t = c.r[1] == c.r[10];  // 0604D0D6 cmp/eq r10,r1
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0604D0DE; } }  // 0604D0D8 bf/s 0x0604D0DE ; mov r11,r0
    c.r[7] = ld32(c.r[0] + c.r[13]);  // 0604D0DC mov.l @(r0,r13),r7
L_0604D0DE:
    c.r[0] = c.r[6];  // 0604D0DE mov r6,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0604D0E0 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[1] = 0xFu; if (k) { goto L_0604D16E; } }  // 0604D0E2 bf/s 0x0604D16E ; mov #15,r1
    c.r[0] = c.r[7];  // 0604D0E6 mov r7,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0604D0E8 cmp/eq #-1,r0
    { const bool k = !c.t; st32(c.r[2], c.r[12]); if (k) { goto L_0604D168; } }  // 0604D0EA bf/s 0x0604D168 ; mov.l r12,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604D18Eu);  // 0604D0EE mov.w 0x0604D18E,r1
    c.r[1] &= c.r[10];  // 0604D0F0 and r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604D190u);  // 0604D0F2 mov.w 0x0604D190,r2
    c.t = c.r[1] == c.r[2];  // 0604D0F4 cmp/eq r2,r1
    if (!c.t) { goto L_0604D0FE; }  // 0604D0F6 bf 0x0604D0FE
    c.r[5] = c.r[10];  // 0604D0F8 mov r10,r5
    goto L_0604D12C;  // 0604D0FA bra 0x0604D12C ; nop
L_0604D0FE:
    c.r[4] = ld32(0x0604D198u);  // 0604D0FE mov.l 0x0604D198,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604D104u; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D104u) return; }  // 0604D100 jsr @r9 ; mov #28,r5
    c.r[5] = c.r[10];  // 0604D104 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604D10Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D10Au) return; }  // 0604D106 jsr @r9 ; mov r0,r4
    c.r[8] = c.r[0];  // 0604D10A mov r0,r8
    c.r[4] = ld32(0x0604D198u);  // 0604D10C mov.l 0x0604D198,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604D112u; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D112u) return; }  // 0604D10E jsr @r9 ; mov #28,r5
    c.r[5] = c.r[10];  // 0604D112 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604D118u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D118u) return; }  // 0604D114 jsr @r9 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604D118 mov.b @r8,r1
    c.r[0] += 1;  // 0604D11A add #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604D11C extu.b r1,r1
    c.r[5] = c.r[1];  // 0604D11E mov r1,r5
    c.r[5] <<= 8;  // 0604D120 shll8 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604D122 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D124 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0604D126 or r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604D192u);  // 0604D128 mov.w 0x0604D192,r1
    c.r[5] &= c.r[1];  // 0604D12A and r1,r5
L_0604D12C:
    c.r[0] = ld32(0x0604D1A4u);  // 0604D12C mov.l 0x0604D1A4,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0604D194u);  // 0604D12E mov.w 0x0604D194,r9
    c.r[8] = ld32(0x0604D1A8u);  // 0604D130 mov.l 0x0604D1A8,r8
    c.r[1] = ld32(c.r[0]);  // 0604D132 mov.l @r0,r1
    c.r[7] = c.r[5];  // 0604D134 mov r5,r7
    c.macl = c.r[1] * c.r[9];  // 0604D136 mul.l r9,r1
    c.r[6] = 0x2u;  // 0604D138 mov #2,r6
    c.r[4] = 0x5u;  // 0604D13A mov #5,r4
    c.r[1] = c.macl;  // 0604D13C sts macl,r1
    c.r[1] += c.r[8];  // 0604D13E add r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604D140 mov.l r1,@-r15
    c.r[0] = ld32(0x0604D1ACu);  // 0604D142 mov.l 0x0604D1AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604D148u; c.r[5] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D148u) return; }  // 0604D144 jsr @r0 ; mov.l @r14,r5
    c.r[0] = ld32(0x0604D1A4u);  // 0604D148 mov.l 0x0604D1A4,r0
    c.r[1] = ld32(c.r[0]);  // 0604D14A mov.l @r0,r1
    c.macl = c.r[1] * c.r[9];  // 0604D14C mul.l r9,r1
    c.r[0] = c.r[11];  // 0604D14E mov r11,r0
    c.r[1] = c.macl;  // 0604D150 sts macl,r1
    c.r[1] += c.r[8];  // 0604D152 add r8,r1
    st32(c.r[0] + c.r[13], c.r[1]);  // 0604D154 mov.l r1,@(r0,r13)
    c.r[0] = ld32(0x0604D1A4u);  // 0604D156 mov.l 0x0604D1A4,r0
    c.r[1] = ld32(c.r[0]);  // 0604D158 mov.l @r0,r1
    c.r[0] = c.r[1];  // 0604D15A mov r1,r0
    c.t = c.r[0] == 0x9u;  // 0604D15C cmp/eq #9,r0
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_0604D176; } }  // 0604D15E bt/s 0x0604D176 ; add #1,r1
    c.r[0] = ld32(0x0604D1A4u);  // 0604D162 mov.l 0x0604D1A4,r0
    st32(c.r[0], c.r[1]); goto L_0604D176;  // 0604D164 bra 0x0604D176 ; mov.l r1,@r0
L_0604D168:
    c.r[0] = c.r[11];  // 0604D168 mov r11,r0
    st32(c.r[0] + c.r[13], c.r[7]); goto L_0604D176;  // 0604D16A bra 0x0604D176 ; mov.l r7,@(r0,r13)
L_0604D16E:
    c.r[3] += 1;  // 0604D16E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0604D170 cmp/gt r1,r3
    { const bool k = !c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_0604D0C4; } }  // 0604D172 bf/s 0x0604D0C4 ; add #4,r11
L_0604D176:
    c.r[14] += 4;  // 0604D176 add #4,r14
    c.r[15] = c.r[14];  // 0604D178 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604D17A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604D17C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604D17E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604D180 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604D182 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604D184 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604D186 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604D188 rts ; mov.l @r15+,r8
}

void f_0604D1B0(SH2Context& c) {
    ran[1244] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604D1B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604D1B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604D1B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604D1B6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604D1B8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604D1BA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604D1BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604D1BE sts.l pr,@-r15
    c.r[15] -= 32;  // 0604D1C0 add #-32,r15
    c.r[14] = c.r[15];  // 0604D1C2 mov r15,r14
    c.r[12] = c.r[4];  // 0604D1C4 mov r4,r12
    c.r[9] = c.r[5];  // 0604D1C6 mov r5,r9
    c.r[6] = c.r[6] & 0xFFu;  // 0604D1C8 extu.b r6,r6
    st32(c.r[14], c.r[6]);  // 0604D1CA mov.l r6,@r14
    c.r[1] = 0x3u;  // 0604D1CC mov #3,r1
    c.t = c.r[6] > c.r[1];  // 0604D1CE cmp/hi r1,r6
    { const bool k = c.t; c.r[9] += c.r[12]; if (k) { goto L_0604D1EC; } }  // 0604D1D0 bt/s 0x0604D1EC ; add r12,r9
    c.r[13] = c.r[6];  // 0604D1D4 mov r6,r13
    c.r[13] <<= 2;  // 0604D1D6 shll2 r13
    c.r[13] <<= 2;  // 0604D1D8 shll2 r13
    c.r[13] += c.r[13];  // 0604D1DA add r13,r13
    c.r[13] <<= 2;  // 0604D1DC shll2 r13
    c.r[1] = ld32(0x0604D2E4u);  // 0604D1DE mov.l 0x0604D2E4,r1
    c.r[13] += c.r[1];  // 0604D1E0 add r1,r13
    c.r[11] = c.r[6];  // 0604D1E2 mov r6,r11
    c.r[11] <<= 8;  // 0604D1E4 shll8 r11
    c.r[1] = ld32(0x0604D2E8u);  // 0604D1E6 mov.l 0x0604D2E8,r1
    c.r[11] += c.r[1]; goto L_0604D1F0;  // 0604D1E8 bra 0x0604D1F0 ; add r1,r11
L_0604D1EC:
    c.r[13] = ld32(0x0604D2ECu);  // 0604D1EC mov.l 0x0604D2EC,r13
    c.r[11] = ld32(0x0604D2F0u);  // 0604D1EE mov.l 0x0604D2F0,r11
L_0604D1F0:
    c.r[1] = ld32(c.r[14]);  // 0604D1F0 mov.l @r14,r1
    c.r[0] = 0x2u;  // 0604D1F2 mov #2,r0
    c.r[1] &= c.r[0];  // 0604D1F4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D1F6 tst r1,r1
    if (c.t) { goto L_0604D286; }  // 0604D1F8 bt 0x0604D286
    c.r[1] = ld32(0x0604D2F4u);  // 0604D1FA mov.l 0x0604D2F4,r1
    c.r[2] = ld32(c.r[1]);  // 0604D1FC mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604D2DEu);  // 0604D1FE mov.w 0x0604D2DE,r1
    c.r[0] = c.r[2];  // 0604D200 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604D202 mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 0604D204 mov #4,r0
    c.r[1] &= c.r[0];  // 0604D206 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D208 tst r1,r1
    if (!c.t) { goto L_0604D220; }  // 0604D20A bf 0x0604D220
    c.r[1] = ld32(0x0604D2F8u);  // 0604D20C mov.l 0x0604D2F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D20E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604D210 mov r1,r0
    c.r[0] >>= 2;  // 0604D212 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604D214 shlr r0
    c.r[0] >>= 2;  // 0604D216 shlr2 r0
    c.r[0] &= 0x1u;  // 0604D218 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0604D21A cmp/eq #1,r0
    { const bool k = !c.t; c.r[7] = 0x1Eu; if (k) { goto L_0604D22A; } }  // 0604D21C bf/s 0x0604D22A ; mov #30,r7
L_0604D220:
    c.r[3] = ld32(0x0604D2FCu);  // 0604D220 mov.l 0x0604D2FC,r3
    c.r[1] = c.r[3];  // 0604D222 mov r3,r1
    c.r[2] = ld32(0x0604D300u);  // 0604D224 mov.l 0x0604D300,r2
    c.r[1] += 6; goto L_0604D2B4;  // 0604D226 bra 0x0604D2B4 ; add #6,r1
L_0604D22A:
    c.r[4] = ld32(0x0604D304u);  // 0604D22A mov.l 0x0604D304,r4
    c.r[1] = c.r[4];  // 0604D22C mov r4,r1
    c.r[1] += 1;  // 0604D22E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D230 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604D232 extu.b r2,r2
    c.r[1] = ld32(0x0604D308u);  // 0604D234 mov.l 0x0604D308,r1
    c.r[5] = ld32(c.r[1]);  // 0604D236 mov.l @r1,r5
    c.r[2] <<= 2;  // 0604D238 shll2 r2
    c.r[2] <<= 2;  // 0604D23A shll2 r2
    c.r[2] += c.r[5];  // 0604D23C add r5,r2
    c.r[2] += 2;  // 0604D23E add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604D240 mov.b @r2,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604D242 extu.b r2,r2
    c.macl = c.r[2] * c.r[7];  // 0604D244 mul.l r7,r2
    c.r[1] = ld32(0x0604D30Cu);  // 0604D246 mov.l 0x0604D30C,r1
    c.r[6] = ld32(c.r[1]);  // 0604D248 mov.l @r1,r6
    c.r[0] = c.macl;  // 0604D24A sts macl,r0
    c.r[0] += c.r[6];  // 0604D24C add r6,r0
    st32(c.r[14] + 28, c.r[0]);  // 0604D24E mov.l r0,@(28,r14)
    c.r[1] = c.r[0];  // 0604D250 mov r0,r1
    c.r[1] += 15;  // 0604D252 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D254 mov.b @r1,r1
    c.r[2] = ld32(0x0604D310u);  // 0604D256 mov.l 0x0604D310,r2
    c.r[3] = ld32(c.r[2]);  // 0604D258 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604D25A extu.b r1,r1
    c.r[2] = c.r[1];  // 0604D25C mov r1,r2
    c.r[2] += c.r[2];  // 0604D25E add r2,r2
    c.r[2] += c.r[1];  // 0604D260 add r1,r2
    c.r[2] <<= 2;  // 0604D262 shll2 r2
    c.r[0] = c.r[2];  // 0604D264 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0604D266 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D268 extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604D26A mov.l r1,@(12,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604D26C mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D26E extu.b r1,r1
    c.r[1] <<= 2;  // 0604D270 shll2 r1
    c.r[1] <<= 2;  // 0604D272 shll2 r1
    c.r[1] += c.r[5];  // 0604D274 add r5,r1
    c.r[1] += 2;  // 0604D276 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D278 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D27A extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 0604D27C mul.l r7,r1
    c.r[8] = c.r[2];  // 0604D27E mov r2,r8
    c.r[7] = c.macl;  // 0604D280 sts macl,r7
    c.r[7] += c.r[6]; goto L_0604D36A;  // 0604D282 bra 0x0604D36A ; add r6,r7
L_0604D286:
    c.r[1] = ld32(0x0604D2F4u);  // 0604D286 mov.l 0x0604D2F4,r1
    c.r[2] = ld32(c.r[1]);  // 0604D288 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604D2DEu);  // 0604D28A mov.w 0x0604D2DE,r1
    c.r[0] = c.r[2];  // 0604D28C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604D28E mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 0604D290 mov #4,r0
    c.r[1] &= c.r[0];  // 0604D292 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D294 tst r1,r1
    if (!c.t) { goto L_0604D2AC; }  // 0604D296 bf 0x0604D2AC
    c.r[1] = ld32(0x0604D2F8u);  // 0604D298 mov.l 0x0604D2F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D29A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604D29C mov r1,r0
    c.r[0] >>= 2;  // 0604D29E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604D2A0 shlr r0
    c.r[0] >>= 2;  // 0604D2A2 shlr2 r0
    c.r[0] &= 0x1u;  // 0604D2A4 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0604D2A6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] = 0x1Eu; if (k) { goto L_0604D314; } }  // 0604D2A8 bf/s 0x0604D314 ; mov #30,r6
L_0604D2AC:
    c.r[3] = ld32(0x0604D300u);  // 0604D2AC mov.l 0x0604D300,r3
    c.r[1] = c.r[3];  // 0604D2AE mov r3,r1
    c.r[1] += 6;  // 0604D2B0 add #6,r1
    c.r[2] = ld32(0x0604D2FCu);  // 0604D2B2 mov.l 0x0604D2FC,r2
L_0604D2B4:
    c.r[3] += 10;  // 0604D2B4 add #10,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604D2B6 mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604D2E0u);  // 0604D2B8 mov.w 0x0604D2E0,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D2BA extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604D2BC mov.l r1,@(12,r14)
    c.r[1] = c.r[2];  // 0604D2BE mov r2,r1
    c.r[1] += 6;  // 0604D2C0 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604D2C2 mov.w @r1,r1
    st32(c.r[14] + 8, c.r[0]);  // 0604D2C4 mov.l r0,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 0604D2C6 mov.l @(8,r14),r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D2C8 extu.w r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0604D2CA mov.l r1,@(16,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604D2CC mov.w @r3,r1
    c.r[2] += 10;  // 0604D2CE add #10,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D2D0 extu.w r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 0604D2D2 mov.l r1,@(20,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604D2D4 mov.w @r2,r1
    st32(c.r[14] + 4, c.r[0]);  // 0604D2D6 mov.l r0,@(4,r14)
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D2D8 extu.w r1,r1
    st32(c.r[14] + 24, c.r[1]); goto L_0604D3A6;  // 0604D2DA bra 0x0604D3A6 ; mov.l r1,@(24,r14)
L_0604D314:
    c.r[7] = ld32(0x0604D568u);  // 0604D314 mov.l 0x0604D568,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0604D316 mov.b @r7+,r2
    c.r[1] = ld32(0x0604D56Cu);  // 0604D318 mov.l 0x0604D56C,r1
    c.r[4] = ld32(c.r[1]);  // 0604D31A mov.l @r1,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0604D31C extu.b r2,r2
    c.r[2] <<= 2;  // 0604D31E shll2 r2
    c.r[2] <<= 2;  // 0604D320 shll2 r2
    c.r[2] += c.r[4];  // 0604D322 add r4,r2
    c.r[2] += 2;  // 0604D324 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604D326 mov.b @r2,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604D328 extu.b r2,r2
    c.macl = c.r[2] * c.r[6];  // 0604D32A mul.l r6,r2
    c.r[1] = ld32(0x0604D570u);  // 0604D32C mov.l 0x0604D570,r1
    c.r[5] = ld32(c.r[1]);  // 0604D32E mov.l @r1,r5
    c.r[0] = c.macl;  // 0604D330 sts macl,r0
    c.r[0] += c.r[5];  // 0604D332 add r5,r0
    st32(c.r[14] + 28, c.r[0]);  // 0604D334 mov.l r0,@(28,r14)
    c.r[1] = c.r[0];  // 0604D336 mov r0,r1
    c.r[1] += 15;  // 0604D338 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D33A mov.b @r1,r1
    c.r[2] = ld32(0x0604D574u);  // 0604D33C mov.l 0x0604D574,r2
    c.r[3] = ld32(c.r[2]);  // 0604D33E mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604D340 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604D342 mov r1,r2
    c.r[2] += c.r[2];  // 0604D344 add r2,r2
    c.r[2] += c.r[1];  // 0604D346 add r1,r2
    c.r[2] <<= 2;  // 0604D348 shll2 r2
    c.r[0] = c.r[2];  // 0604D34A mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0604D34C mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D34E extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604D350 mov.l r1,@(12,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D352 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D354 extu.b r1,r1
    c.r[1] <<= 2;  // 0604D356 shll2 r1
    c.r[1] <<= 2;  // 0604D358 shll2 r1
    c.r[1] += c.r[4];  // 0604D35A add r4,r1
    c.r[1] += 2;  // 0604D35C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D35E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D360 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 0604D362 mul.l r6,r1
    c.r[8] = c.r[2];  // 0604D364 mov r2,r8
    c.r[7] = c.macl;  // 0604D366 sts macl,r7
    c.r[7] += c.r[5];  // 0604D368 add r5,r7
L_0604D36A:
    c.r[1] = c.r[7];  // 0604D36A mov r7,r1
    c.r[1] += 15;  // 0604D36C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D36E mov.b @r1,r1
    c.r[8] += c.r[3];  // 0604D370 add r3,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604D372 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604D374 mov r1,r2
    c.r[2] += c.r[2];  // 0604D376 add r2,r2
    c.r[2] += c.r[1];  // 0604D378 add r1,r2
    c.r[2] <<= 2;  // 0604D37A shll2 r2
    c.r[0] = c.r[2];  // 0604D37C mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0604D37E mov.w @(r0,r3),r1
    c.r[8] += 8;  // 0604D380 add #8,r8
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D382 extu.w r1,r1
    c.r[0] = ld32(c.r[14] + 28);  // 0604D384 mov.l @(28,r14),r0
    st32(c.r[14] + 16, c.r[1]);  // 0604D386 mov.l r1,@(16,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604D388 mov.w @r0,r1
    c.r[6] = c.r[2];  // 0604D38A mov r2,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D38C extu.w r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 0604D38E mov.l r1,@(20,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604D390 mov.w @r7,r1
    c.r[6] += c.r[3];  // 0604D392 add r3,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D394 extu.w r1,r1
    st32(c.r[14] + 24, c.r[1]);  // 0604D396 mov.l r1,@(24,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604D398 mov.b @r8,r1
    c.r[6] += 8;  // 0604D39A add #8,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604D39C extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0604D39E mov.l r1,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604D3A0 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D3A2 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0604D3A4 mov.l r1,@(8,r14)
L_0604D3A6:
    c.r[7] = c.r[9];  // 0604D3A6 mov r9,r7
L_0604D3A8:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0604D3A8 mov.b @r7+,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0604D3AA extu.b r2,r1
    c.r[5] = c.r[1];  // 0604D3AC mov r1,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D3AE mov.b @r7,r6
    c.r[5] <<= 8;  // 0604D3B0 shll8 r5
    c.r[1] = c.r[6] & 0xFFu;  // 0604D3B2 extu.b r6,r1
    c.r[5] |= c.r[1];  // 0604D3B4 or r1,r5
    c.r[0] = c.r[5];  // 0604D3B6 mov r5,r0
    c.t = c.r[0] == 0xAu;  // 0604D3B8 cmp/eq #10,r0
    { const bool k = !c.t; c.r[3] = c.r[5]; if (k) { goto L_0604D3C2; } }  // 0604D3BA bf/s 0x0604D3C2 ; mov r5,r3
    goto L_0604D9AA;  // 0604D3BE bra 0x0604D9AA ; nop
L_0604D3C2:
    c.r[0] = 0xAu;  // 0604D3C2 mov #10,r0
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 0604D3C4 cmp/gt r0,r5
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0604D450; } }  // 0604D3C6 bt/s 0x0604D450 ; mov r5,r0
    c.t = c.r[0] == 0x4u;  // 0604D3CA cmp/eq #4,r0
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D3D4; } }  // 0604D3CC bf/s 0x0604D3D4 ; mov r9,r1
    goto L_0604D76A;  // 0604D3D0 bra 0x0604D76A ; nop
L_0604D3D4:
    c.r[1] = 0x4u;  // 0604D3D4 mov #4,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0604D3D6 cmp/gt r1,r5
    { const bool k = c.t; c.t = c.r[0] == 0x7u; if (k) { goto L_0604D412; } }  // 0604D3D8 bt/s 0x0604D412 ; cmp/eq #7,r0
    c.t = c.r[0] == 0x1u;  // 0604D3DC cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D3E6; } }  // 0604D3DE bf/s 0x0604D3E6 ; mov r9,r1
    goto L_0604D6A4;  // 0604D3E2 bra 0x0604D6A4 ; nop
L_0604D3E6:
    c.r[1] = 0x1u;  // 0604D3E6 mov #1,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0604D3E8 cmp/gt r1,r5
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0604D3FC; } }  // 0604D3EA bt/s 0x0604D3FC ; cmp/eq #2,r0
    c.t = (c.r[5] & c.r[5]) == 0;  // 0604D3EE tst r5,r5
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D3F8; } }  // 0604D3F0 bf/s 0x0604D3F8 ; mov r9,r1
    goto L_0604D668;  // 0604D3F4 bra 0x0604D668 ; nop
L_0604D3F8:
    c.r[0] = 0x0u; goto L_0604DB76;  // 0604D3F8 bra 0x0604DB76 ; mov #0,r0
L_0604D3FC:
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D404; } }  // 0604D3FC bf/s 0x0604D404 ; mov r9,r1
    goto L_0604D6F4;  // 0604D400 bra 0x0604D6F4 ; nop
L_0604D404:
    c.t = c.r[0] == 0x3u;  // 0604D404 cmp/eq #3,r0
    { const bool k = !c.t; c.r[1] += 2; if (k) { goto L_0604D40E; } }  // 0604D406 bf/s 0x0604D40E ; add #2,r1
    goto L_0604D730;  // 0604D40A bra 0x0604D730 ; nop
L_0604D40E:
    c.r[0] = 0x0u; goto L_0604DB76;  // 0604D40E bra 0x0604DB76 ; mov #0,r0
L_0604D412:
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D41A; } }  // 0604D412 bf/s 0x0604D41A ; mov r9,r1
    goto L_0604D8BC;  // 0604D416 bra 0x0604D8BC ; nop
L_0604D41A:
    c.r[1] = 0x7u;  // 0604D41A mov #7,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0604D41C cmp/gt r1,r5
    { const bool k = c.t; c.t = c.r[0] == 0x5u; if (k) { goto L_0604D436; } }  // 0604D41E bt/s 0x0604D436 ; cmp/eq #5,r0
    { const bool k = !c.t; c.t = c.r[0] == 0x6u; if (k) { goto L_0604D42A; } }  // 0604D422 bf/s 0x0604D42A ; cmp/eq #6,r0
    goto L_0604D7D6;  // 0604D426 bra 0x0604D7D6 ; nop
L_0604D42A:
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D432; } }  // 0604D42A bf/s 0x0604D432 ; mov r9,r1
    goto L_0604D810;  // 0604D42E bra 0x0604D810 ; nop
L_0604D432:
    c.r[0] = 0x0u; goto L_0604DB76;  // 0604D432 bra 0x0604DB76 ; mov #0,r0
L_0604D436:
    c.r[0] = c.r[5];  // 0604D436 mov r5,r0
    c.t = c.r[0] == 0x8u;  // 0604D438 cmp/eq #8,r0
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D442; } }  // 0604D43A bf/s 0x0604D442 ; mov r9,r1
    goto L_0604D8F4;  // 0604D43E bra 0x0604D8F4 ; nop
L_0604D442:
    c.t = c.r[0] == 0x9u;  // 0604D442 cmp/eq #9,r0
    { const bool k = !c.t; c.r[1] += 2; if (k) { goto L_0604D44C; } }  // 0604D444 bf/s 0x0604D44C ; add #2,r1
    goto L_0604D950;  // 0604D448 bra 0x0604D950 ; nop
L_0604D44C:
    c.r[0] = 0x0u; goto L_0604DB76;  // 0604D44C bra 0x0604DB76 ; mov #0,r0
L_0604D450:
    c.t = c.r[0] == 0xFu;  // 0604D450 cmp/eq #15,r0
    { const bool k = !c.t; c.r[1] = 0xFu; if (k) { goto L_0604D45A; } }  // 0604D452 bf/s 0x0604D45A ; mov #15,r1
    goto L_0604DAE4;  // 0604D456 bra 0x0604DAE4 ; nop
L_0604D45A:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0604D45A cmp/gt r1,r5
    { const bool k = c.t; c.t = c.r[0] == 0xCu; if (k) { goto L_0604D486; } }  // 0604D45C bt/s 0x0604D486 ; cmp/eq #12,r0
    { const bool k = !c.t; c.r[1] = 0xCu; if (k) { goto L_0604D468; } }  // 0604D460 bf/s 0x0604D468 ; mov #12,r1
    goto L_0604DA12;  // 0604D464 bra 0x0604DA12 ; nop
L_0604D468:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 0604D468 cmp/ge r1,r5
    { const bool k = c.t; c.t = c.r[0] == 0xDu; if (k) { goto L_0604D472; } }  // 0604D46A bt/s 0x0604D472 ; cmp/eq #13,r0
    goto L_0604D9D4;  // 0604D46E bra 0x0604D9D4 ; nop
L_0604D472:
    { const bool k = !c.t; c.t = c.r[0] == 0xEu; if (k) { goto L_0604D47A; } }  // 0604D472 bf/s 0x0604D47A ; cmp/eq #14,r0
    goto L_0604DA7E;  // 0604D476 bra 0x0604DA7E ; nop
L_0604D47A:
    { const bool k = !c.t; c.r[2] <<= 16; if (k) { goto L_0604D482; } }  // 0604D47A bf/s 0x0604D482 ; shll16 r2
    goto L_0604DAD2;  // 0604D47E bra 0x0604DAD2 ; nop
L_0604D482:
    c.r[0] = 0x0u; goto L_0604DB76;  // 0604D482 bra 0x0604DB76 ; mov #0,r0
L_0604D486:
    c.r[0] = c.r[3];  // 0604D486 mov r3,r0
    c.t = c.r[0] == 0x13u;  // 0604D488 cmp/eq #19,r0
    { const bool k = !c.t; c.r[1] = 0x13u; if (k) { goto L_0604D492; } }  // 0604D48A bf/s 0x0604D492 ; mov #19,r1
    goto L_0604DB02;  // 0604D48E bra 0x0604DB02 ; nop
L_0604D492:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0604D492 cmp/ge r1,r3
    { const bool k = !c.t; c.t = c.r[0] == 0x14u; if (k) { goto L_0604D4B8; } }  // 0604D494 bf/s 0x0604D4B8 ; cmp/eq #20,r0
    if (!c.t) { goto L_0604D49E; }  // 0604D498 bf 0x0604D49E
    goto L_0604DB20;  // 0604D49A bra 0x0604DB20 ; nop
L_0604D49E:
    c.r[1] = ld32(0x0604D578u);  // 0604D49E mov.l 0x0604D578,r1
    c.t = c.r[3] == c.r[1];  // 0604D4A0 cmp/eq r1,r3
    { const bool k = c.t; c.r[6] = 0x2u; if (k) { goto L_0604D4AA; } }  // 0604D4A2 bt/s 0x0604D4AA ; mov #2,r6
    goto L_0604DB74;  // 0604D4A6 bra 0x0604DB74 ; nop
L_0604D4AA:
    c.r[0] = ld32(0x0604D57Cu);  // 0604D4AA mov.l 0x0604D57C,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x0604D562u);  // 0604D4AC mov.w 0x0604D562,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604D4B2u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D4B2u) return; }  // 0604D4AE jsr @r0 ; mov r13,r4
    c.r[9] += 2;  // 0604D4B2 add #2,r9
    c.r[0] = c.r[9]; goto L_0604DB76;  // 0604D4B4 bra 0x0604DB76 ; mov r9,r0
L_0604D4B8:
    st8(c.r[13], c.r[2]);  // 0604D4B8 mov.b r2,@r13
    c.r[3] = c.r[13];  // 0604D4BA mov r13,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0604D4BC mov.b @r7+,r1
    c.r[3] += 1;  // 0604D4BE add #1,r3
    st8(c.r[3], c.r[1]);  // 0604D4C0 mov.b r1,@r3
    c.r[1] = c.r[7];  // 0604D4C2 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604D4C4 mov.b @r1+,r2
    c.r[3] += 1;  // 0604D4C6 add #1,r3
    st8(c.r[3], c.r[2]);  // 0604D4C8 mov.b r2,@r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604D4CA mov.b @r1+,r2
    c.r[3] += 1;  // 0604D4CC add #1,r3
    st8(c.r[3], c.r[2]);  // 0604D4CE mov.b r2,@r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604D4D0 mov.b @r1+,r2
    c.r[3] += 1;  // 0604D4D2 add #1,r3
    st8(c.r[3], c.r[2]);  // 0604D4D4 mov.b r2,@r3
    c.r[3] += 1;  // 0604D4D6 add #1,r3
    c.r[2] = c.r[13];  // 0604D4D8 mov r13,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D4DA mov.b @r1,r1
    c.r[2] += 6;  // 0604D4DC add #6,r2
    st8(c.r[3], c.r[1]);  // 0604D4DE mov.b r1,@r3
    c.r[1] = c.r[11];  // 0604D4E0 mov r11,r1
    c.r[1] >>= 16;  // 0604D4E2 shlr16 r1
    c.r[1] >>= 8;  // 0604D4E4 shlr8 r1
    st8(c.r[2], c.r[1]);  // 0604D4E6 mov.b r1,@r2
    c.r[2] = c.r[13];  // 0604D4E8 mov r13,r2
    c.r[2] += 7;  // 0604D4EA add #7,r2
    c.r[1] = c.r[11];  // 0604D4EC mov r11,r1
    c.r[1] >>= 16;  // 0604D4EE shlr16 r1
    st8(c.r[2], c.r[1]);  // 0604D4F0 mov.b r1,@r2
    c.r[2] = c.r[13];  // 0604D4F2 mov r13,r2
    c.r[2] += 8;  // 0604D4F4 add #8,r2
    c.r[1] = c.r[11];  // 0604D4F6 mov r11,r1
    c.r[1] >>= 8;  // 0604D4F8 shlr8 r1
    st8(c.r[2], c.r[1]);  // 0604D4FA mov.b r1,@r2
    c.r[1] = c.r[13];  // 0604D4FC mov r13,r1
    c.r[1] += 9;  // 0604D4FE add #9,r1
    st8(c.r[1], c.r[11]);  // 0604D500 mov.b r11,@r1
    c.r[1] = c.r[9];  // 0604D502 mov r9,r1
    c.r[1] += 2;  // 0604D504 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D506 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D508 extu.b r1,r1
    c.r[10] = c.r[1];  // 0604D50A mov r1,r10
    c.r[10] <<= 8;  // 0604D50C shll8 r10
    c.r[1] = c.r[9];  // 0604D50E mov r9,r1
    c.r[1] += 3;  // 0604D510 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D512 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D514 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0604D516 or r1,r10
    c.r[1] = ld32(0x0604D580u);  // 0604D518 mov.l 0x0604D580,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D51A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604D51C mov r1,r0
    c.r[0] >>= 2;  // 0604D51E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604D520 shlr r0
    c.r[0] >>= 2;  // 0604D522 shlr2 r0
    c.r[0] &= 0x1u;  // 0604D524 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0604D526 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0604D5B0; } }  // 0604D528 bf/s 0x0604D5B0 ; mov r10,r2
    c.r[2] >>= 2;  // 0604D52C shlr2 r2
    c.r[2] >>= 2;  // 0604D52E shlr2 r2
    c.r[2] >>= 2;  // 0604D530 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604D564u);  // 0604D532 mov.w 0x0604D564,r1
    c.t = c.r[2] == c.r[1];  // 0604D534 cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0604D5B0; } }  // 0604D536 bf/s 0x0604D5B0 ; mov.l @r14,r0
    c.r[1] = 0x4u;  // 0604D53A mov #4,r1
    c.t = c.r[0] > c.r[1];  // 0604D53C cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0604D5A2; } }  // 0604D53E bt/s 0x0604D5A2 ; mov r13,r1
    c.r[1] = c.r[0];  // 0604D542 mov r0,r1
    c.r[1] += c.r[1];  // 0604D544 add r1,r1
    c.r[0] = 0x0604D550u;  // 0604D546 mova 0x0604D550,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604D548 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604D54A add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604D55Au: goto L_0604D55A; case 0x0604D588u: goto L_0604D588; default: sh2_call(c, x); return; } }  // 0604D54C jmp @r0 ; nop
L_0604D55A:
    c.r[0] = 0x3Fu;  // 0604D55A mov #63,r0
    c.r[1] = ld32(0x0604D584u);  // 0604D55C mov.l 0x0604D584,r1
    c.r[10] &= c.r[0]; goto L_0604D58E;  // 0604D55E bra 0x0604D58E ; and r0,r10
L_0604D588:
    c.r[0] = 0x3Fu;  // 0604D588 mov #63,r0
    c.r[10] &= c.r[0];  // 0604D58A and r0,r10
    c.r[1] = ld32(0x0604D6E4u);  // 0604D58C mov.l 0x0604D6E4,r1
L_0604D58E:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604D58E mov.w @r1,r1
    c.r[0] = 0x1u;  // 0604D590 mov #1,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D592 extu.w r1,r1
    c.r[1] |= c.r[0];  // 0604D594 or r0,r1
    c.r[1] <<= 2;  // 0604D596 shll2 r1
    c.r[1] <<= 2;  // 0604D598 shll2 r1
    c.r[1] <<= 2;  // 0604D59A shll2 r1
    c.r[1] |= c.r[10];  // 0604D59C or r10,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 0604D59E extu.w r1,r10
    c.r[1] = c.r[13];  // 0604D5A0 mov r13,r1
L_0604D5A2:
    c.r[1] += 2;  // 0604D5A2 add #2,r1
    c.r[2] = c.r[10];  // 0604D5A4 mov r10,r2
    c.r[2] >>= 8;  // 0604D5A6 shlr8 r2
    st8(c.r[1], c.r[2]);  // 0604D5A8 mov.b r2,@r1
    c.r[1] = c.r[13];  // 0604D5AA mov r13,r1
    c.r[1] += 3;  // 0604D5AC add #3,r1
    st8(c.r[1], c.r[10]);  // 0604D5AE mov.b r10,@r1
L_0604D5B0:
    c.r[1] = ld32(0x0604D6E8u);  // 0604D5B0 mov.l 0x0604D6E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604D5B6u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D5B6u) return; }  // 0604D5B2 jsr @r1 ; mov r10,r4
    c.r[10] >>= 2;  // 0604D5B6 shlr2 r10
    c.r[10] >>= 2;  // 0604D5B8 shlr2 r10
    c.r[10] >>= 2;  // 0604D5BA shlr2 r10
    c.r[8] = ld32(0x0604D6ECu);  // 0604D5BC mov.l 0x0604D6EC,r8
    c.r[4] = ld32(0x0604D6F0u);  // 0604D5BE mov.l 0x0604D6F0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604D5C4u; c.r[5] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D5C4u) return; }  // 0604D5C0 jsr @r8 ; mov #13,r5
    c.r[5] = c.r[10];  // 0604D5C4 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604D5CAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D5CAu) return; }  // 0604D5C6 jsr @r8 ; mov r0,r4
    c.r[7] = c.r[0];  // 0604D5CA mov r0,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604D6E0u);  // 0604D5CC mov.w 0x0604D6E0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]); goto L_0604D5EC;  // 0604D5CE bra 0x0604D5EC ; mov.b @r7,r2
L_0604D5D2:
    st8(c.r[11], c.r[2]);  // 0604D5D2 mov.b r2,@r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D5D4 mov.b @r7,r1
    c.r[1] += 21;  // 0604D5D6 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D5D8 extu.b r1,r1
    c.t = c.r[1] > c.r[0];  // 0604D5DA cmp/hi r0,r1
    if (c.t) { goto L_0604D5E6; }  // 0604D5DC bt 0x0604D5E6
    c.r[7] += 1;  // 0604D5DE add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D5E0 mov.b @r7,r1
    c.r[11] += 1;  // 0604D5E2 add #1,r11
    st8(c.r[11], c.r[1]);  // 0604D5E4 mov.b r1,@r11
L_0604D5E6:
    c.r[7] += 1;  // 0604D5E6 add #1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D5E8 mov.b @r7,r2
    c.r[11] += 1;  // 0604D5EA add #1,r11
L_0604D5EC:
    c.r[1] = c.r[2] & 0xFFu;  // 0604D5EC extu.b r2,r1
    c.t = c.r[1] == c.r[3];  // 0604D5EE cmp/eq r3,r1
    { const bool k = !c.t; c.r[0] = 0xAu; if (k) { SH2_POLL(c); goto L_0604D5D2; } }  // 0604D5F0 bf/s 0x0604D5D2 ; mov #10,r0
    c.r[1] = 0xFFFFFFF6u;  // 0604D5F4 mov #-10,r1
    st8(c.r[11], c.r[1]);  // 0604D5F6 mov.b r1,@r11
    c.r[1] = c.r[9];  // 0604D5F8 mov r9,r1
    c.r[1] += 6;  // 0604D5FA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D5FC mov.b @r1,r1
    c.r[2] = c.r[1];  // 0604D5FE mov r1,r2
    c.r[2] <<= 16;  // 0604D600 shll16 r2
    c.r[2] <<= 8;  // 0604D602 shll8 r2
    c.r[1] = c.r[9];  // 0604D604 mov r9,r1
    c.r[1] += 7;  // 0604D606 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D608 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D60A extu.b r1,r1
    c.r[1] <<= 16;  // 0604D60C shll16 r1
    c.r[2] |= c.r[1];  // 0604D60E or r1,r2
    c.r[1] = c.r[9];  // 0604D610 mov r9,r1
    c.r[1] += 8;  // 0604D612 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D614 mov.b @r1,r1
    c.r[7] = c.r[12];  // 0604D616 mov r12,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604D618 extu.b r1,r1
    c.r[1] <<= 8;  // 0604D61A shll8 r1
    c.r[2] |= c.r[1];  // 0604D61C or r1,r2
    c.r[1] = c.r[9];  // 0604D61E mov r9,r1
    c.r[1] += 9;  // 0604D620 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D622 mov.b @r1,r1
    c.r[0] = c.r[12];  // 0604D624 mov r12,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604D626 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D628 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604D62A mov.b @(r0,r2),r1
    c.r[7] += c.r[2];  // 0604D62C add r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604D62E extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604D6E0u);  // 0604D630 mov.w 0x0604D6E0,r2
    c.t = c.r[1] == c.r[2];  // 0604D632 cmp/eq r2,r1
    { const bool k = c.t; c.r[11] += 1; if (k) { goto L_0604D65C; } }  // 0604D634 bt/s 0x0604D65C ; add #1,r11
L_0604D638:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D638 mov.b @r7,r1
    st8(c.r[11], c.r[1]);  // 0604D63A mov.b r1,@r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D63C mov.b @r7,r1
    c.r[0] = 0xAu;  // 0604D63E mov #10,r0
    c.r[1] += 21;  // 0604D640 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D642 extu.b r1,r1
    c.t = c.r[1] > c.r[0];  // 0604D644 cmp/hi r0,r1
    if (c.t) { goto L_0604D650; }  // 0604D646 bt 0x0604D650
    c.r[7] += 1;  // 0604D648 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D64A mov.b @r7,r1
    c.r[11] += 1;  // 0604D64C add #1,r11
    st8(c.r[11], c.r[1]);  // 0604D64E mov.b r1,@r11
L_0604D650:
    c.r[7] += 1;  // 0604D650 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D652 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D654 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0604D656 cmp/eq r2,r1
    { const bool k = !c.t; c.r[11] += 1; if (k) { SH2_POLL(c); goto L_0604D638; } }  // 0604D658 bf/s 0x0604D638 ; add #1,r11
L_0604D65C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604D65C mov.b @r7,r1
    c.r[13] += 10;  // 0604D65E add #10,r13
    c.r[9] += 10;  // 0604D660 add #10,r9
    st8(c.r[11], c.r[1]);  // 0604D662 mov.b r1,@r11
    c.r[11] += 1; SH2_POLL(c); goto L_0604D3A6;  // 0604D664 bra 0x0604D3A6 ; add #1,r11
L_0604D668:
    c.r[1] += 2;  // 0604D668 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D66A mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 20);  // 0604D66C mov.l @(20,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604D66E extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D670 mov r9,r1
    c.r[1] += 3;  // 0604D672 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D674 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D676 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D678 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D67A or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D67C cmp/eq r0,r2
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D686; } }  // 0604D67E bt/s 0x0604D686 ; mov r9,r1
    goto L_0604D8B2;  // 0604D682 bra 0x0604D8B2 ; nop
L_0604D686:
    c.r[1] += 4;  // 0604D686 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D688 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D68A mov r9,r1
    c.r[1] += 5;  // 0604D68C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D68E mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D690 shll16 r2
    c.r[2] <<= 8;  // 0604D692 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D694 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D696 shll16 r1
    c.r[2] |= c.r[1];  // 0604D698 or r1,r2
    c.r[1] = c.r[9];  // 0604D69A mov r9,r1
    c.r[1] += 6;  // 0604D69C add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D69E mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D6A0 bra 0x0604DB60 ; add #7,r9
L_0604D6A4:
    c.r[1] += 2;  // 0604D6A4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D6A6 mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 20);  // 0604D6A8 mov.l @(20,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604D6AA extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D6AC mov r9,r1
    c.r[1] += 3;  // 0604D6AE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D6B0 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D6B2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D6B4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D6B6 or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D6B8 cmp/eq r0,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D6C2; } }  // 0604D6BA bf/s 0x0604D6C2 ; mov r9,r1
    goto L_0604D8B2;  // 0604D6BE bra 0x0604D8B2 ; nop
L_0604D6C2:
    c.r[1] += 4;  // 0604D6C2 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D6C4 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D6C6 mov r9,r1
    c.r[1] += 5;  // 0604D6C8 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D6CA mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D6CC shll16 r2
    c.r[2] <<= 8;  // 0604D6CE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D6D0 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D6D2 shll16 r1
    c.r[2] |= c.r[1];  // 0604D6D4 or r1,r2
    c.r[1] = c.r[9];  // 0604D6D6 mov r9,r1
    c.r[1] += 6;  // 0604D6D8 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D6DA mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D6DC bra 0x0604DB60 ; add #7,r9
L_0604D6F4:
    c.r[1] += 2;  // 0604D6F4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D6F6 mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 24);  // 0604D6F8 mov.l @(24,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604D6FA extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D6FC mov r9,r1
    c.r[1] += 3;  // 0604D6FE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D700 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D702 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D704 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D706 or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D708 cmp/eq r0,r2
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D712; } }  // 0604D70A bt/s 0x0604D712 ; mov r9,r1
    goto L_0604D8B2;  // 0604D70E bra 0x0604D8B2 ; nop
L_0604D712:
    c.r[1] += 4;  // 0604D712 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D714 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D716 mov r9,r1
    c.r[1] += 5;  // 0604D718 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D71A mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D71C shll16 r2
    c.r[2] <<= 8;  // 0604D71E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D720 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D722 shll16 r1
    c.r[2] |= c.r[1];  // 0604D724 or r1,r2
    c.r[1] = c.r[9];  // 0604D726 mov r9,r1
    c.r[1] += 6;  // 0604D728 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D72A mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D72C bra 0x0604DB60 ; add #7,r9
L_0604D730:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D730 mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 24);  // 0604D732 mov.l @(24,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604D734 extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D736 mov r9,r1
    c.r[1] += 3;  // 0604D738 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D73A mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D73C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D73E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D740 or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D742 cmp/eq r0,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D74C; } }  // 0604D744 bf/s 0x0604D74C ; mov r9,r1
    goto L_0604D8B2;  // 0604D748 bra 0x0604D8B2 ; nop
L_0604D74C:
    c.r[1] += 4;  // 0604D74C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D74E mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D750 mov r9,r1
    c.r[1] += 5;  // 0604D752 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D754 mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D756 shll16 r2
    c.r[2] <<= 8;  // 0604D758 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D75A extu.b r1,r1
    c.r[1] <<= 16;  // 0604D75C shll16 r1
    c.r[2] |= c.r[1];  // 0604D75E or r1,r2
    c.r[1] = c.r[9];  // 0604D760 mov r9,r1
    c.r[1] += 6;  // 0604D762 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D764 mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D766 bra 0x0604DB60 ; add #7,r9
L_0604D76A:
    c.r[1] += 2;  // 0604D76A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D76C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D76E extu.b r1,r1
    c.r[2] = c.r[1];  // 0604D770 mov r1,r2
    c.r[2] <<= 8;  // 0604D772 shll8 r2
    c.r[1] = c.r[9];  // 0604D774 mov r9,r1
    c.r[1] += 3;  // 0604D776 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D778 mov.b @r1,r1
    c.r[0] = ld32(c.r[14] + 12);  // 0604D77A mov.l @(12,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604D77C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D77E or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D780 cmp/eq r0,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D7A4; } }  // 0604D782 bf/s 0x0604D7A4 ; mov r9,r1
    c.r[1] += 4;  // 0604D786 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D788 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D78A mov r9,r1
    c.r[1] += 5;  // 0604D78C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D78E mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D790 shll16 r2
    c.r[2] <<= 8;  // 0604D792 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D794 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D796 shll16 r1
    c.r[2] |= c.r[1];  // 0604D798 or r1,r2
    c.r[1] = c.r[9];  // 0604D79A mov r9,r1
    c.r[1] += 6;  // 0604D79C add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D79E mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D7A0 bra 0x0604DB60 ; add #7,r9
L_0604D7A4:
    c.r[3] = ld32(c.r[14] + 4);  // 0604D7A4 mov.l @(4,r14),r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604D8B6u);  // 0604D7A6 mov.w 0x0604D8B6,r6
    c.t = c.r[3] == c.r[6];  // 0604D7A8 cmp/eq r6,r3
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_0604D8A6; } }  // 0604D7AA bt/s 0x0604D8A6 ; mov r2,r5
    c.r[1] = ld32(0x0604D8B8u);  // 0604D7AE mov.l 0x0604D8B8,r1
    c.r[7] = ld32(c.r[1]);  // 0604D7B0 mov.l @r1,r7
    c.r[0] = c.r[3];  // 0604D7B2 mov r3,r0
L_0604D7B4:
    c.r[0] += c.r[0];  // 0604D7B4 add r0,r0
    c.r[0] += c.r[3];  // 0604D7B6 add r3,r0
    c.r[0] <<= 2;  // 0604D7B8 shll2 r0
    c.r[2] = c.r[0];  // 0604D7BA mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0604D7BC mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D7BE extu.w r1,r1
    c.t = c.r[1] == c.r[5];  // 0604D7C0 cmp/eq r5,r1
    { const bool k = c.t; c.r[2] += c.r[7]; if (k) { goto L_0604D84A; } }  // 0604D7C2 bt/s 0x0604D84A ; add r7,r2
    c.r[2] += 8;  // 0604D7C6 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604D7C8 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0604D7CA extu.b r1,r3
    c.t = c.r[3] == c.r[6];  // 0604D7CC cmp/eq r6,r3
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0604D7B4; } }  // 0604D7CE bf/s 0x0604D7B4 ; mov r3,r0
    goto L_0604D8A6;  // 0604D7D2 bra 0x0604D8A6 ; nop
L_0604D7D6:
    c.r[1] = c.r[9];  // 0604D7D6 mov r9,r1
    c.r[1] += 2;  // 0604D7D8 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D7DA mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 12);  // 0604D7DC mov.l @(12,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604D7DE extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D7E0 mov r9,r1
    c.r[1] += 3;  // 0604D7E2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D7E4 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D7E6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D7E8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D7EA or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D7EC cmp/eq r0,r2
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D8B2; } }  // 0604D7EE bt/s 0x0604D8B2 ; mov r9,r1
    c.r[1] += 4;  // 0604D7F2 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D7F4 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D7F6 mov r9,r1
    c.r[1] += 5;  // 0604D7F8 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D7FA mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D7FC shll16 r2
    c.r[2] <<= 8;  // 0604D7FE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D800 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D802 shll16 r1
    c.r[2] |= c.r[1];  // 0604D804 or r1,r2
    c.r[1] = c.r[9];  // 0604D806 mov r9,r1
    c.r[1] += 6;  // 0604D808 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D80A mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D80C bra 0x0604DB60 ; add #7,r9
L_0604D810:
    c.r[1] += 2;  // 0604D810 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D812 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604D814 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604D816 mov r1,r2
    c.r[2] <<= 8;  // 0604D818 shll8 r2
    c.r[1] = c.r[9];  // 0604D81A mov r9,r1
    c.r[1] += 3;  // 0604D81C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D81E mov.b @r1,r1
    c.r[0] = ld32(c.r[14] + 16);  // 0604D820 mov.l @(16,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604D822 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D824 or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D826 cmp/eq r0,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D878; } }  // 0604D828 bf/s 0x0604D878 ; mov r9,r1
    c.r[1] += 4;  // 0604D82C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D82E mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D830 mov r9,r1
    c.r[1] += 5;  // 0604D832 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D834 mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D836 shll16 r2
    c.r[2] <<= 8;  // 0604D838 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D83A extu.b r1,r1
    c.r[1] <<= 16;  // 0604D83C shll16 r1
    c.r[2] |= c.r[1];  // 0604D83E or r1,r2
    c.r[1] = c.r[9];  // 0604D840 mov r9,r1
    c.r[1] += 6;  // 0604D842 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D844 mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D846 bra 0x0604DB60 ; add #7,r9
L_0604D84A:
    c.r[1] = c.r[9];  // 0604D84A mov r9,r1
    c.r[1] += 4;  // 0604D84C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D84E mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D850 mov r9,r1
    c.r[1] += 5;  // 0604D852 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D854 mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D856 shll16 r2
    c.r[2] <<= 8;  // 0604D858 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D85A extu.b r1,r1
    c.r[1] <<= 16;  // 0604D85C shll16 r1
    c.r[2] |= c.r[1];  // 0604D85E or r1,r2
    c.r[1] = c.r[9];  // 0604D860 mov r9,r1
    c.r[1] += 6;  // 0604D862 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D864 mov.b @r1,r1
    c.r[9] += 7;  // 0604D866 add #7,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0604D868 extu.b r1,r1
    c.r[1] <<= 8;  // 0604D86A shll8 r1
    c.r[2] |= c.r[1];  // 0604D86C or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604D86E mov.b @r9,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0604D870 extu.b r1,r9
    c.r[9] |= c.r[2];  // 0604D872 or r2,r9
    c.r[9] += c.r[12]; goto L_0604D8A6;  // 0604D874 bra 0x0604D8A6 ; add r12,r9
L_0604D878:
    c.r[3] = ld32(c.r[14] + 8);  // 0604D878 mov.l @(8,r14),r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604D8B6u);  // 0604D87A mov.w 0x0604D8B6,r6
    c.t = c.r[3] == c.r[6];  // 0604D87C cmp/eq r6,r3
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_0604D8A6; } }  // 0604D87E bt/s 0x0604D8A6 ; mov r2,r5
    c.r[1] = ld32(0x0604D8B8u);  // 0604D882 mov.l 0x0604D8B8,r1
    c.r[7] = ld32(c.r[1]);  // 0604D884 mov.l @r1,r7
    c.r[0] = c.r[3];  // 0604D886 mov r3,r0
L_0604D888:
    c.r[0] += c.r[0];  // 0604D888 add r0,r0
    c.r[0] += c.r[3];  // 0604D88A add r3,r0
    c.r[0] <<= 2;  // 0604D88C shll2 r0
    c.r[2] = c.r[0];  // 0604D88E mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0604D890 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604D892 extu.w r1,r1
    c.t = c.r[1] == c.r[5];  // 0604D894 cmp/eq r5,r1
    { const bool k = c.t; c.r[2] += c.r[7]; if (k) { SH2_POLL(c); goto L_0604D84A; } }  // 0604D896 bt/s 0x0604D84A ; add r7,r2
    c.r[2] += 8;  // 0604D89A add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604D89C mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0604D89E extu.b r1,r3
    c.t = c.r[3] == c.r[6];  // 0604D8A0 cmp/eq r6,r3
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0604D888; } }  // 0604D8A2 bf/s 0x0604D888 ; mov r3,r0
L_0604D8A6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604D8B6u);  // 0604D8A6 mov.w 0x0604D8B6,r1
    c.t = c.r[3] == c.r[1];  // 0604D8A8 cmp/eq r1,r3
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_0604D8B2; } }  // 0604D8AA bt/s 0x0604D8B2 ; mov r9,r7
    SH2_POLL(c); goto L_0604D3A8;  // 0604D8AE bra 0x0604D3A8 ; nop
L_0604D8B2:
    c.r[9] += 8; SH2_POLL(c); goto L_0604D3A6;  // 0604D8B2 bra 0x0604D3A6 ; add #8,r9
L_0604D8BC:
    c.r[1] += 2;  // 0604D8BC add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8BE mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 16);  // 0604D8C0 mov.l @(16,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604D8C2 extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D8C4 mov r9,r1
    c.r[1] += 3;  // 0604D8C6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8C8 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D8CA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D8CC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D8CE or r1,r2
    c.t = c.r[2] == c.r[0];  // 0604D8D0 cmp/eq r0,r2
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0604D8B2; } }  // 0604D8D2 bt/s 0x0604D8B2 ; mov r9,r1
    c.r[1] += 4;  // 0604D8D6 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8D8 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D8DA mov r9,r1
    c.r[1] += 5;  // 0604D8DC add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8DE mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D8E0 shll16 r2
    c.r[2] <<= 8;  // 0604D8E2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D8E4 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D8E6 shll16 r1
    c.r[2] |= c.r[1];  // 0604D8E8 or r1,r2
    c.r[1] = c.r[9];  // 0604D8EA mov r9,r1
    c.r[1] += 6;  // 0604D8EC add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8EE mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D8F0 bra 0x0604DB60 ; add #7,r9
L_0604D8F4:
    c.r[1] += 2;  // 0604D8F4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8F6 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604D8F8 extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D8FA mov r9,r1
    c.r[1] += 3;  // 0604D8FC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D8FE mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D900 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D902 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D904 or r1,r2
    c.r[3] = c.r[2];  // 0604D906 mov r2,r3
    c.r[1] = ld32(0x0604DA44u);  // 0604D908 mov.l 0x0604DA44,r1
    c.r[1] = ld32(c.r[1]);  // 0604D90A mov.l @r1,r1
    c.r[3] >>= 2;  // 0604D90C shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0604D90E shlr r3
    c.r[3] += c.r[1];  // 0604D910 add r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604DA3Eu);  // 0604D912 mov.w 0x0604DA3E,r1
    c.r[0] = c.r[3];  // 0604D914 mov r3,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604D916 mov.b @(r0,r1),r4
    c.r[4] = c.r[4] & 0xFFu;  // 0604D918 extu.b r4,r4
    c.r[1] = ~c.r[2];  // 0604D91A not r2,r1
    c.r[0] = 0x7u;  // 0604D91C mov #7,r0
    c.r[1] &= c.r[0];  // 0604D91E and r0,r1
    c.r[0] = ld32(0x0604DA48u);  // 0604D920 mov.l 0x0604DA48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604D926u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D926u) return; }  // 0604D922 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604D926 mov r0,r1
    c.r[0] = 0x1u;  // 0604D928 mov #1,r0
    c.r[1] &= c.r[0];  // 0604D92A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D92C tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0604D8B2; } }  // 0604D92E bf/s 0x0604D8B2 ; mov r9,r1
    c.r[1] += 4;  // 0604D932 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D934 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D936 mov r9,r1
    c.r[1] += 5;  // 0604D938 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D93A mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D93C shll16 r2
    c.r[2] <<= 8;  // 0604D93E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D940 extu.b r1,r1
    c.r[1] <<= 16;  // 0604D942 shll16 r1
    c.r[2] |= c.r[1];  // 0604D944 or r1,r2
    c.r[1] = c.r[9];  // 0604D946 mov r9,r1
    c.r[1] += 6;  // 0604D948 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D94A mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D94C bra 0x0604DB60 ; add #7,r9
L_0604D950:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D950 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604D952 extu.b r2,r2
    c.r[1] = c.r[9];  // 0604D954 mov r9,r1
    c.r[1] += 3;  // 0604D956 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D958 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604D95A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D95C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604D95E or r1,r2
    c.r[3] = c.r[2];  // 0604D960 mov r2,r3
    c.r[1] = ld32(0x0604DA44u);  // 0604D962 mov.l 0x0604DA44,r1
    c.r[1] = ld32(c.r[1]);  // 0604D964 mov.l @r1,r1
    c.r[3] >>= 2;  // 0604D966 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0604D968 shlr r3
    c.r[3] += c.r[1];  // 0604D96A add r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604DA3Eu);  // 0604D96C mov.w 0x0604DA3E,r1
    c.r[0] = c.r[3];  // 0604D96E mov r3,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604D970 mov.b @(r0,r1),r4
    c.r[4] = c.r[4] & 0xFFu;  // 0604D972 extu.b r4,r4
    c.r[1] = ~c.r[2];  // 0604D974 not r2,r1
    c.r[0] = 0x7u;  // 0604D976 mov #7,r0
    c.r[1] &= c.r[0];  // 0604D978 and r0,r1
    c.r[0] = ld32(0x0604DA48u);  // 0604D97A mov.l 0x0604DA48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604D980u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604D980u) return; }  // 0604D97C jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604D980 mov r0,r1
    c.r[0] = 0x1u;  // 0604D982 mov #1,r0
    c.r[1] &= c.r[0];  // 0604D984 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D986 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0604D8B2; } }  // 0604D988 bt/s 0x0604D8B2 ; mov r9,r1
    c.r[1] += 4;  // 0604D98C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D98E mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604D990 mov r9,r1
    c.r[1] += 5;  // 0604D992 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D994 mov.b @r1,r1
    c.r[2] <<= 16;  // 0604D996 shll16 r2
    c.r[2] <<= 8;  // 0604D998 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604D99A extu.b r1,r1
    c.r[1] <<= 16;  // 0604D99C shll16 r1
    c.r[2] |= c.r[1];  // 0604D99E or r1,r2
    c.r[1] = c.r[9];  // 0604D9A0 mov r9,r1
    c.r[1] += 6;  // 0604D9A2 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D9A4 mov.b @r1,r1
    c.r[9] += 7; goto L_0604DB60;  // 0604D9A6 bra 0x0604DB60 ; add #7,r9
L_0604D9AA:
    c.r[1] = ld32(c.r[14]);  // 0604D9AA mov.l @r14,r1
    c.r[0] = 0x2u;  // 0604D9AC mov #2,r0
    c.r[1] &= c.r[0];  // 0604D9AE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D9B0 tst r1,r1
    if (c.t) { goto L_0604D9CE; }  // 0604D9B2 bt 0x0604D9CE
    c.r[1] = ld32(0x0604DA4Cu);  // 0604D9B4 mov.l 0x0604DA4C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D9B6 mov.b @r1,r1
L_0604D9B8:
    c.r[0] = c.r[1];  // 0604D9B8 mov r1,r0
    c.r[0] >>= 2;  // 0604D9BA shlr2 r0
    c.r[0] >>= 2;  // 0604D9BC shlr2 r0
L_0604D9BE:
    c.r[0] &= 0x1u;  // 0604D9BE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604D9C0 tst r0,r0
    if (c.t) { goto L_0604D9C8; }  // 0604D9C2 bt 0x0604D9C8
    goto L_0604DB42;  // 0604D9C4 bra 0x0604DB42 ; nop
L_0604D9C8:
    c.r[9] += 6;  // 0604D9C8 add #6,r9
    c.r[7] = c.r[9]; SH2_POLL(c); goto L_0604D3A8;  // 0604D9CA bra 0x0604D3A8 ; mov r9,r7
L_0604D9CE:
    c.r[1] = ld32(0x0604DA50u);  // 0604D9CE mov.l 0x0604DA50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); goto L_0604D9B8;  // 0604D9D0 bra 0x0604D9B8 ; mov.b @r1,r1
L_0604D9D4:
    c.r[1] = ld32(c.r[14]);  // 0604D9D4 mov.l @r14,r1
    c.r[0] = 0x2u;  // 0604D9D6 mov #2,r0
    c.r[1] &= c.r[0];  // 0604D9D8 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604D9DA tst r1,r1
    if (c.t) { goto L_0604D9F8; }  // 0604D9DC bt 0x0604D9F8
    c.r[1] = ld32(0x0604DA4Cu);  // 0604D9DE mov.l 0x0604DA4C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D9E0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604D9E2 mov r1,r0
    c.r[0] >>= 2;  // 0604D9E4 shlr2 r0
    c.r[0] >>= 2;  // 0604D9E6 shlr2 r0
    c.r[0] &= 0x1u;  // 0604D9E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604D9EA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604D9F4; } }  // 0604D9EC bt/s 0x0604D9F4 ; mov r9,r1
    goto L_0604DB70;  // 0604D9F0 bra 0x0604DB70 ; nop
L_0604D9F4:
    c.r[1] += 2; goto L_0604DB46;  // 0604D9F4 bra 0x0604DB46 ; add #2,r1
L_0604D9F8:
    c.r[1] = ld32(0x0604DA50u);  // 0604D9F8 mov.l 0x0604DA50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604D9FA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604D9FC mov r1,r0
    c.r[0] >>= 2;  // 0604D9FE shlr2 r0
    c.r[0] >>= 2;  // 0604DA00 shlr2 r0
    c.r[0] &= 0x1u;  // 0604DA02 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604DA04 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604DA0E; } }  // 0604DA06 bt/s 0x0604DA0E ; mov r9,r1
    goto L_0604DB70;  // 0604DA0A bra 0x0604DB70 ; nop
L_0604DA0E:
    c.r[1] += 2; goto L_0604DB46;  // 0604DA0E bra 0x0604DB46 ; add #2,r1
L_0604DA12:
    c.r[1] = ld32(0x0604DA54u);  // 0604DA12 mov.l 0x0604DA54,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604DA14 mov.w @r1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604DA16 extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604DA40u);  // 0604DA18 mov.w 0x0604DA40,r1
    c.t = c.r[2] > c.r[1];  // 0604DA1A cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604DA58; } }  // 0604DA1C bf/s 0x0604DA58 ; mov r9,r1
    c.r[1] += 10;  // 0604DA20 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA22 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604DA24 mov r9,r1
    c.r[1] += 11;  // 0604DA26 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA28 mov.b @r1,r1
    c.r[2] <<= 16;  // 0604DA2A shll16 r2
    c.r[2] <<= 8;  // 0604DA2C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604DA2E extu.b r1,r1
    c.r[1] <<= 16;  // 0604DA30 shll16 r1
    c.r[2] |= c.r[1];  // 0604DA32 or r1,r2
    c.r[1] = c.r[9];  // 0604DA34 mov r9,r1
    c.r[1] += 12;  // 0604DA36 add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA38 mov.b @r1,r1
    c.r[9] += 13; goto L_0604DB60;  // 0604DA3A bra 0x0604DB60 ; add #13,r9
L_0604DA58:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604DB8Cu);  // 0604DA58 mov.w 0x0604DB8C,r1
    c.t = c.r[2] > c.r[1];  // 0604DA5A cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604DB42; } }  // 0604DA5C bf/s 0x0604DB42 ; mov r9,r1
    c.r[1] += 6;  // 0604DA60 add #6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA62 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604DA64 mov r9,r1
    c.r[1] += 7;  // 0604DA66 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA68 mov.b @r1,r1
    c.r[2] <<= 16;  // 0604DA6A shll16 r2
    c.r[2] <<= 8;  // 0604DA6C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604DA6E extu.b r1,r1
    c.r[1] <<= 16;  // 0604DA70 shll16 r1
    c.r[2] |= c.r[1];  // 0604DA72 or r1,r2
    c.r[1] = c.r[9];  // 0604DA74 mov r9,r1
    c.r[1] += 8;  // 0604DA76 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA78 mov.b @r1,r1
    c.r[9] += 9; goto L_0604DB60;  // 0604DA7A bra 0x0604DB60 ; add #9,r9
L_0604DA7E:
    c.r[0] = ld32(0x0604DB90u);  // 0604DA7E mov.l 0x0604DB90,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DA84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DA84u) return; }  // 0604DA80 jsr @r0 ; nop
    c.r[1] = c.r[9];  // 0604DA84 mov r9,r1
    c.r[1] += 2;  // 0604DA86 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA88 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604DA8A extu.b r2,r2
    c.r[1] = c.r[9];  // 0604DA8C mov r9,r1
    c.r[1] += 3;  // 0604DA8E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DA90 mov.b @r1,r1
    c.r[2] <<= 8;  // 0604DA92 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604DA94 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604DA96 or r1,r2
    c.macl = c.r[0] * c.r[2];  // 0604DA98 mul.l r2,r0
    c.r[0] = c.macl;  // 0604DA9A sts macl,r0
    c.r[0] >>= 16;  // 0604DA9C shlr16 r0
    c.r[0] += 1;  // 0604DA9E add #1,r0
    c.r[0] <<= 2;  // 0604DAA0 shll2 r0
    c.r[2] = c.r[0];  // 0604DAA2 mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0604DAA4 mov.b @(r0,r9),r1
    c.r[2] += c.r[9];  // 0604DAA6 add r9,r2
    c.r[9] = c.r[1];  // 0604DAA8 mov r1,r9
    c.r[9] <<= 16;  // 0604DAAA shll16 r9
    c.r[9] <<= 8;  // 0604DAAC shll8 r9
    c.r[1] = c.r[2];  // 0604DAAE mov r2,r1
    c.r[1] += 1;  // 0604DAB0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DAB2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604DAB4 extu.b r1,r1
    c.r[1] <<= 16;  // 0604DAB6 shll16 r1
    c.r[9] |= c.r[1];  // 0604DAB8 or r1,r9
    c.r[1] = c.r[2];  // 0604DABA mov r2,r1
    c.r[1] += 2;  // 0604DABC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DABE mov.b @r1,r1
    c.r[2] += 3;  // 0604DAC0 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604DAC2 extu.b r1,r1
    c.r[1] <<= 8;  // 0604DAC4 shll8 r1
    c.r[9] |= c.r[1];  // 0604DAC6 or r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604DAC8 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604DACA extu.b r1,r1
    c.r[9] |= c.r[1];  // 0604DACC or r1,r9
    c.r[9] += c.r[12]; SH2_POLL(c); goto L_0604D3A6;  // 0604DACE bra 0x0604D3A6 ; add r12,r9
L_0604DAD2:
    c.r[2] <<= 8;  // 0604DAD2 shll8 r2
    c.r[1] = c.r[6] & 0xFFu;  // 0604DAD4 extu.b r6,r1
    c.r[1] <<= 16;  // 0604DAD6 shll16 r1
    c.r[2] |= c.r[1];  // 0604DAD8 or r1,r2
    c.r[1] = c.r[9];  // 0604DADA mov r9,r1
    c.r[1] += 2;  // 0604DADC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DADE mov.b @r1,r1
    c.r[9] += 3; goto L_0604DB60;  // 0604DAE0 bra 0x0604DB60 ; add #3,r9
L_0604DAE4:
    st8(c.r[13], c.r[2]);  // 0604DAE4 mov.b r2,@r13
    c.r[3] = c.r[13];  // 0604DAE6 mov r13,r3
    c.r[3] += 1;  // 0604DAE8 add #1,r3
    c.r[13] += 4;  // 0604DAEA add #4,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0604DAEC mov.b @r7+,r1
    c.r[9] += 4;  // 0604DAEE add #4,r9
    st8(c.r[3], c.r[1]);  // 0604DAF0 mov.b r1,@r3
    c.r[1] = c.r[7];  // 0604DAF2 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604DAF4 mov.b @r1+,r2
    c.r[3] += 1;  // 0604DAF6 add #1,r3
    st8(c.r[3], c.r[2]);  // 0604DAF8 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DAFA mov.b @r1,r1
    c.r[3] += 1;  // 0604DAFC add #1,r3
    st8(c.r[3], c.r[1]); SH2_POLL(c); goto L_0604D3A6;  // 0604DAFE bra 0x0604D3A6 ; mov.b r1,@r3
L_0604DB02:
    c.r[8] = ld32(0x0604DB94u);  // 0604DB02 mov.l 0x0604DB94,r8
    c.r[4] = ld32(0x0604DB98u);  // 0604DB04 mov.l 0x0604DB98,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604DB0Au; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DB0Au) return; }  // 0604DB06 jsr @r8 ; mov #28,r5
    c.r[5] = ld32(c.r[14] + 12);  // 0604DB0A mov.l @(12,r14),r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604DB10u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DB10u) return; }  // 0604DB0C jsr @r8 ; mov r0,r4
    c.r[0] += 3;  // 0604DB10 add #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604DB12 mov.b @r0,r1
    c.r[0] = c.r[1];  // 0604DB14 mov r1,r0
    c.r[0] >>= 2;  // 0604DB16 shlr2 r0
    c.r[0] >>= 2;  // 0604DB18 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604DB1A shlr r0
    c.r[0] >>= 2; SH2_POLL(c); goto L_0604D9BE;  // 0604DB1C bra 0x0604D9BE ; shlr2 r0
L_0604DB20:
    c.r[8] = ld32(0x0604DB94u);  // 0604DB20 mov.l 0x0604DB94,r8
    c.r[4] = ld32(0x0604DB98u);  // 0604DB22 mov.l 0x0604DB98,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604DB28u; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DB28u) return; }  // 0604DB24 jsr @r8 ; mov #28,r5
    c.r[5] = ld32(c.r[14] + 16);  // 0604DB28 mov.l @(16,r14),r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604DB2Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DB2Eu) return; }  // 0604DB2A jsr @r8 ; mov r0,r4
    c.r[0] += 3;  // 0604DB2E add #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604DB30 mov.b @r0,r1
    c.r[0] = c.r[1];  // 0604DB32 mov r1,r0
    c.r[0] >>= 2;  // 0604DB34 shlr2 r0
    c.r[0] >>= 2;  // 0604DB36 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604DB38 shlr r0
    c.r[0] >>= 2;  // 0604DB3A shlr2 r0
    c.r[0] &= 0x1u;  // 0604DB3C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604DB3E tst r0,r0
    if (c.t) { goto L_0604DB70; }  // 0604DB40 bt 0x0604DB70
L_0604DB42:
    c.r[1] = c.r[9];  // 0604DB42 mov r9,r1
    c.r[1] += 2;  // 0604DB44 add #2,r1
L_0604DB46:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DB46 mov.b @r1,r2
    c.r[1] = c.r[9];  // 0604DB48 mov r9,r1
    c.r[1] += 3;  // 0604DB4A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DB4C mov.b @r1,r1
    c.r[2] <<= 16;  // 0604DB4E shll16 r2
    c.r[2] <<= 8;  // 0604DB50 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604DB52 extu.b r1,r1
    c.r[1] <<= 16;  // 0604DB54 shll16 r1
    c.r[2] |= c.r[1];  // 0604DB56 or r1,r2
    c.r[1] = c.r[9];  // 0604DB58 mov r9,r1
    c.r[1] += 4;  // 0604DB5A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DB5C mov.b @r1,r1
    c.r[9] += 5;  // 0604DB5E add #5,r9
L_0604DB60:
    c.r[1] = c.r[1] & 0xFFu;  // 0604DB60 extu.b r1,r1
    c.r[1] <<= 8;  // 0604DB62 shll8 r1
    c.r[2] |= c.r[1];  // 0604DB64 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604DB66 mov.b @r9,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0604DB68 extu.b r1,r9
    c.r[9] |= c.r[2];  // 0604DB6A or r2,r9
    c.r[9] += c.r[12]; SH2_POLL(c); goto L_0604D3A6;  // 0604DB6C bra 0x0604D3A6 ; add r12,r9
L_0604DB70:
    c.r[9] += 6; SH2_POLL(c); goto L_0604D3A6;  // 0604DB70 bra 0x0604D3A6 ; add #6,r9
L_0604DB74:
    c.r[0] = 0x0u;  // 0604DB74 mov #0,r0
L_0604DB76:
    c.r[14] += 32;  // 0604DB76 add #32,r14
    c.r[15] = c.r[14];  // 0604DB78 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604DB7A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604DB7C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604DB7E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604DB80 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604DB82 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604DB84 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604DB86 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604DB88 rts ; mov.l @r15+,r8
}

void f_0604DB9C(SH2Context& c) {
    ran[1245] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604DB9C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604DB9E mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604DBA0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0604DBA2 rts ; mov #0,r0
}

void f_0604DC10(SH2Context& c) {
    ran[1246] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604DC10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604DC12 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604DC14 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604DC16 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604DC18 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604DC1A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604DC1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604DC1E sts.l pr,@-r15
    c.r[15] -= 52;  // 0604DC20 add #-52,r15
    c.r[8] = ld32(0x0604DCD0u);  // 0604DC22 mov.l 0x0604DCD0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604DC24 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604DC26 extu.b r1,r1
    c.r[1] >>= 2;  // 0604DC28 shlr2 r1
    c.r[1] >>= 2;  // 0604DC2A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604DC2C shlr r1
    c.r[1] >>= 2;  // 0604DC2E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604DC30 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604DC3A; } }  // 0604DC32 bf/s 0x0604DC3A ; mov r15,r14
    goto L_0604DE96;  // 0604DC36 bra 0x0604DE96 ; nop
L_0604DC3A:
    c.r[1] = ld32(0x0604DCD4u);  // 0604DC3A mov.l 0x0604DCD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DC40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DC40u) return; }  // 0604DC3C jsr @r1 ; nop
    c.r[1] = ld32(0x0604DCD8u);  // 0604DC40 mov.l 0x0604DCD8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DC42 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604DC44 extu.b r1,r1
    c.r[1] >>= 2;  // 0604DC46 shlr2 r1
    c.r[1] >>= 2;  // 0604DC48 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604DC4A shlr r1
    c.r[1] >>= 2;  // 0604DC4C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604DC4E tst r1,r1
    if (c.t) { goto L_0604DC58; }  // 0604DC50 bt 0x0604DC58
    c.r[1] = ld32(0x0604DCDCu);  // 0604DC52 mov.l 0x0604DCDC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DC58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DC58u) return; }  // 0604DC54 jsr @r1 ; nop
L_0604DC58:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604DC58 mov.b @r8,r1
    c.r[0] = c.r[1];  // 0604DC5A mov r1,r0
    c.r[0] >>= 2;  // 0604DC5C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604DC5E shlr r0
    c.r[0] >>= 2;  // 0604DC60 shlr2 r0
    c.r[0] &= 0x1u;  // 0604DC62 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604DC64 tst r0,r0
    if (c.t) { goto L_0604DC6E; }  // 0604DC66 bt 0x0604DC6E
    c.r[1] = ld32(0x0604DCE0u);  // 0604DC68 mov.l 0x0604DCE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DC6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DC6Eu) return; }  // 0604DC6A jsr @r1 ; nop
L_0604DC6E:
    c.r[8] += 1;  // 0604DC6E add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604DC70 mov.b @r8,r1
    c.r[0] = c.r[1];  // 0604DC72 mov r1,r0
    c.r[0] >>= 2;  // 0604DC74 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604DC76 shlr r0
    c.r[0] &= 0x1u;  // 0604DC78 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604DC7A tst r0,r0
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_0604DC84; } }  // 0604DC7C bf/s 0x0604DC84 ; mov #0,r11
    goto L_0604DE96;  // 0604DC80 bra 0x0604DE96 ; nop
L_0604DC84:
    c.r[1] = ld32(0x0604DCE4u);  // 0604DC84 mov.l 0x0604DCE4,r1
    c.r[2] = ld32(c.r[1]);  // 0604DC86 mov.l @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604DCCAu);  // 0604DC88 mov.w 0x0604DCCA,r7
    c.r[6] = 0x0u;  // 0604DC8A mov #0,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604DCCCu);  // 0604DC8C mov.w 0x0604DCCC,r3
    c.r[0] = c.r[6];  // 0604DC8E mov r6,r0
L_0604DC90:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604DC90 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604DC92 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0604DC94 cmp/eq r7,r1
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0604DC9E; } }  // 0604DC96 bf/s 0x0604DC9E ; mov r11,r1
    c.r[1] += 1;  // 0604DC9A add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0604DC9C extu.b r1,r11
L_0604DC9E:
    c.r[6] += 16;  // 0604DC9E add #16,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[3];  // 0604DCA0 cmp/gt r3,r6
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { SH2_POLL(c); goto L_0604DC90; } }  // 0604DCA2 bf/s 0x0604DC90 ; mov r6,r0
    c.r[13] = 0x0u;  // 0604DCA6 mov #0,r13
    c.r[12] = 0x0u;  // 0604DCA8 mov #0,r12
    c.r[5] = c.r[12];  // 0604DCAA mov r12,r5
    c.r[1] = ld32(0x0604DCE8u);  // 0604DCAC mov.l 0x0604DCE8,r1
    c.r[4] = ld32(c.r[1]);  // 0604DCAE mov.l @r1,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x0604DCCAu);  // 0604DCB0 mov.w 0x0604DCCA,r9
    c.r[8] = ld32(0x0604DCECu);  // 0604DCB2 mov.l 0x0604DCEC,r8
    c.r[10] = 0x0u;  // 0604DCB4 mov #0,r10
    c.r[6] = c.r[4];  // 0604DCB6 mov r4,r6
L_0604DCB8:
    c.r[0] = c.r[10];  // 0604DCB8 mov r10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0604DCBA mov.w @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604DCBC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604DCBE tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_0604DCF0; } }  // 0604DCC0 bf/s 0x0604DCF0 ; mov r12,r1
    c.r[1] += 1;  // 0604DCC4 add #1,r1
    c.r[12] = c.r[1] & 0xFFu; goto L_0604DD1C;  // 0604DCC6 bra 0x0604DD1C ; extu.b r1,r12
L_0604DCF0:
    c.r[1] = c.r[6];  // 0604DCF0 mov r6,r1
    c.r[1] += 15;  // 0604DCF2 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DCF4 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0604DCF6 extu.b r1,r2
    c.t = c.r[2] == c.r[9];  // 0604DCF8 cmp/eq r9,r2
    if (c.t) { goto L_0604DD1C; }  // 0604DCFA bt 0x0604DD1C
    c.r[3] = ld32(c.r[8]);  // 0604DCFC mov.l @r8,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604DEB4u);  // 0604DCFE mov.w 0x0604DEB4,r7
    c.r[1] = c.r[13];  // 0604DD00 mov r13,r1
L_0604DD02:
    c.r[1] += 1;  // 0604DD02 add #1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0604DD04 extu.b r1,r13
    c.r[1] = c.r[2];  // 0604DD06 mov r2,r1
    c.r[1] += c.r[1];  // 0604DD08 add r1,r1
    c.r[1] += c.r[2];  // 0604DD0A add r2,r1
    c.r[1] <<= 2;  // 0604DD0C shll2 r1
    c.r[1] += c.r[3];  // 0604DD0E add r3,r1
    c.r[1] += 8;  // 0604DD10 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DD12 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0604DD14 extu.b r1,r2
    c.t = c.r[2] == c.r[7];  // 0604DD16 cmp/eq r7,r2
    { const bool k = !c.t; c.r[1] = c.r[13]; if (k) { SH2_POLL(c); goto L_0604DD02; } }  // 0604DD18 bf/s 0x0604DD02 ; mov r13,r1
L_0604DD1C:
    c.r[6] += 30;  // 0604DD1C add #30,r6
    c.r[5] += 1;  // 0604DD1E add #1,r5
    c.r[1] = 0x7Fu;  // 0604DD20 mov #127,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0604DD22 cmp/gt r1,r5
    { const bool k = !c.t; c.r[10] += 30; if (k) { SH2_POLL(c); goto L_0604DCB8; } }  // 0604DD24 bf/s 0x0604DCB8 ; add #30,r10
    c.r[1] = 0xFFFFFF80u;  // 0604DD28 mov #-128,r1
    c.r[1] -= c.r[13];  // 0604DD2A sub r13,r1
    c.r[0] = ld32(0x0604DEB8u);  // 0604DD2C mov.l 0x0604DEB8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DD32u; c.r[13] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DD32u) return; }  // 0604DD2E jsr @r0 ; extu.b r1,r13
    c.r[1] = c.r[0];  // 0604DD32 mov r0,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604DD34 extu.w r1,r6
    c.r[5] = ld32(0x0604DEBCu);  // 0604DD36 mov.l 0x0604DEBC,r5
    c.r[0] = ld32(0x0604DEC0u);  // 0604DD38 mov.l 0x0604DEC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DD3Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DD3Eu) return; }  // 0604DD3A jsr @r0 ; mov r14,r4
    c.r[5] = 0x0u;  // 0604DD3E mov #0,r5
    c.r[0] = ld32(0x0604DEC4u);  // 0604DD40 mov.l 0x0604DEC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DD46u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DD46u) return; }  // 0604DD42 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 0604DD46 mov r0,r1
    c.r[5] = c.r[1];  // 0604DD48 mov r1,r5
    c.r[0] = ld32(0x0604DEC8u);  // 0604DD4A mov.l 0x0604DEC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DD50u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DD50u) return; }  // 0604DD4C jsr @r0 ; mov r14,r4
    c.r[7] = ld32(0x0604DECCu);  // 0604DD50 mov.l 0x0604DECC,r7
    c.r[1] = c.r[7];  // 0604DD52 mov r7,r1
    c.r[1] += 90;  // 0604DD54 add #90,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DD56 mov.b @r1,r10
    c.r[0] = ld32(0x0604DED0u);  // 0604DD58 mov.l 0x0604DED0,r0
    c.r[3] = ld32(c.r[7]);  // 0604DD5A mov.l @r7,r3
    c.r[1] = c.r[7];  // 0604DD5C mov r7,r1
    c.r[1] += 88;  // 0604DD5E add #88,r1
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604DD60 mov.w @r1,r9
    c.r[10] = c.r[10] & 0xFFu;  // 0604DD62 extu.b r10,r10
    c.r[9] = c.r[9] & 0xFFFFu;  // 0604DD64 extu.w r9,r9
    c.r[6] = c.r[9];  // 0604DD66 mov r9,r6
    c.r[6] <<= 2;  // 0604DD68 shll2 r6
    c.r[6] += c.r[6];  // 0604DD6A add r6,r6
    c.r[3] += c.r[6];  // 0604DD6C add r6,r3
    c.r[2] = c.r[3];  // 0604DD6E mov r3,r2
    c.r[1] = c.r[3];  // 0604DD70 mov r3,r1
    c.r[1] -= 4;  // 0604DD72 add #-4,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604DD74 mov.w @r1,r8
    c.r[2] -= 8;  // 0604DD76 add #-8,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604DD78 mov.w @r2,r2
    c.r[3] -= 6;  // 0604DD7A add #-6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604DD7C mov.w @r3,r1
    c.r[8] = c.r[8] & 0xFFFFu;  // 0604DD7E extu.w r8,r8
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604DD80 mulu.w r1,r2
    c.r[8] <<= 2;  // 0604DD82 shll2 r8
    c.r[8] += c.r[8];  // 0604DD84 add r8,r8
    c.r[1] = ld32(c.r[7] + 4);  // 0604DD86 mov.l @(4,r7),r1
    c.r[4] = c.macl;  // 0604DD88 sts macl,r4
    c.r[6] += c.r[1];  // 0604DD8A add r1,r6
    c.r[6] -= 6;  // 0604DD8C add #-6,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604DD8E mov.w @r6,r5
    c.r[4] <<= 2;  // 0604DD90 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0604DD96u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DD96u) return; }  // 0604DD92 jsr @r0 ; extu.w r5,r5
    c.r[2] = c.r[0];  // 0604DD96 mov r0,r2
    c.r[2] += 31;  // 0604DD98 add #31,r2
    c.r[1] = ld32(0x0604DED4u);  // 0604DD9A mov.l 0x0604DED4,r1
    c.r[2] &= c.r[1];  // 0604DD9C and r1,r2
    c.r[8] += c.r[2];  // 0604DD9E add r2,r8
    c.r[1] = ld32(0x0604DED8u);  // 0604DDA0 mov.l 0x0604DED8,r1
    c.r[8] += c.r[1];  // 0604DDA2 add r1,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604DDA4 mov.l r8,@-r15
    c.r[7] = c.r[10];  // 0604DDA6 mov r10,r7
    c.r[6] = c.r[9];  // 0604DDA8 mov r9,r6
    c.r[5] = ld32(0x0604DEDCu);  // 0604DDAA mov.l 0x0604DEDC,r5
    c.r[0] = ld32(0x0604DEC0u);  // 0604DDAC mov.l 0x0604DEC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DDB2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DDB2u) return; }  // 0604DDAE jsr @r0 ; mov r14,r4
    c.r[5] = 0x0u;  // 0604DDB2 mov #0,r5
    c.r[0] = ld32(0x0604DEC4u);  // 0604DDB4 mov.l 0x0604DEC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DDBAu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DDBAu) return; }  // 0604DDB6 jsr @r0 ; mov #8,r4
    c.r[1] = c.r[0];  // 0604DDBA mov r0,r1
    c.r[5] = c.r[1];  // 0604DDBC mov r1,r5
    c.r[0] = ld32(0x0604DEC8u);  // 0604DDBE mov.l 0x0604DEC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DDC4u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DDC4u) return; }  // 0604DDC0 jsr @r0 ; mov r14,r4
    c.r[2] = ld32(0x0604DEE0u);  // 0604DDC4 mov.l 0x0604DEE0,r2
    c.r[1] = c.r[2];  // 0604DDC6 mov r2,r1
    c.r[1] += 117;  // 0604DDC8 add #117,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DDCA mov.b @r1,r7
    c.r[8] = ld32(0x0604DEE4u);  // 0604DDCC mov.l 0x0604DEE4,r8
    c.r[1] = c.r[2];  // 0604DDCE mov r2,r1
    c.r[1] += 79;  // 0604DDD0 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DDD2 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 0604DDD4 extu.b r7,r7
    c.r[7] += c.r[1];  // 0604DDD6 add r1,r7
    c.r[1] = c.r[2];  // 0604DDD8 mov r2,r1
    c.r[1] += 116;  // 0604DDDA add #116,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DDDC mov.b @r1,r6
    c.r[2] += 78;  // 0604DDDE add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604DDE0 mov.b @r2,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0604DDE2 extu.b r6,r6
    c.r[2] = ld32(c.r[8]);  // 0604DDE4 mov.l @r8,r2
    c.r[6] += c.r[1];  // 0604DDE6 add r1,r6
    c.r[1] = c.r[2];  // 0604DDE8 mov r2,r1
    c.r[1] += 6;  // 0604DDEA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604DDEC mov.b @r1,r1
    c.r[2] += 4;  // 0604DDEE add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604DDF0 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604DDF2 mov.l r1,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604DDF4 mov.b @r2,r1
    c.r[5] = ld32(0x0604DEE8u);  // 0604DDF6 mov.l 0x0604DEE8,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604DDF8 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604DDFA mov.l r1,@-r15
    c.r[1] = ld32(0x0604DEECu);  // 0604DDFC mov.l 0x0604DEEC,r1
    c.r[2] = c.r[7];  // 0604DDFE mov r7,r2
    c.r[1] = ld32(c.r[1]);  // 0604DE00 mov.l @r1,r1
    c.r[2] <<= 2;  // 0604DE02 shll2 r2
    c.r[2] <<= 2;  // 0604DE04 shll2 r2
    c.r[2] <<= 2;  // 0604DE06 shll2 r2
    c.r[2] += c.r[1];  // 0604DE08 add r1,r2
    c.r[0] = c.r[2];  // 0604DE0A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0604DE0C mov.b @(r0,r6),r1
    c.r[4] = c.r[14];  // 0604DE0E mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0604DE10 extu.b r1,r1
    c.r[0] = ld32(0x0604DEC0u);  // 0604DE12 mov.l 0x0604DEC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE18u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE18u) return; }  // 0604DE14 jsr @r0 ; mov.l r1,@-r15
    c.r[5] = 0x1u;  // 0604DE18 mov #1,r5
    c.r[0] = ld32(0x0604DEC4u);  // 0604DE1A mov.l 0x0604DEC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE20u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE20u) return; }  // 0604DE1C jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 0604DE20 mov r0,r1
    c.r[5] = c.r[1];  // 0604DE22 mov r1,r5
    c.r[0] = ld32(0x0604DEC8u);  // 0604DE24 mov.l 0x0604DEC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE2Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE2Au) return; }  // 0604DE26 jsr @r0 ; mov r14,r4
    c.r[5] = ld32(0x0604DEF0u);  // 0604DE2A mov.l 0x0604DEF0,r5
    c.r[1] = ld32(c.r[8]);  // 0604DE2C mov.l @r8,r1
    c.r[4] = c.r[14];  // 0604DE2E mov r14,r4
    c.r[1] += 18;  // 0604DE30 add #18,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604DE32 mov.w @r1,r7
    c.r[0] = ld32(0x0604DEC0u);  // 0604DE34 mov.l 0x0604DEC0,r0
    c.r[1] = ld32(0x0604DEF4u);  // 0604DE36 mov.l 0x0604DEF4,r1
    c.r[1] = ld32(c.r[1]);  // 0604DE38 mov.l @r1,r1
    c.r[7] <<= 16;  // 0604DE3A shll16 r7
    c.r[7] <<= 2;  // 0604DE3C shll2 r7
    c.r[7] += c.r[7];  // 0604DE3E add r7,r7
    c.r[7] <<= 2;  // 0604DE40 shll2 r7
    c.r[1] += 42;  // 0604DE42 add #42,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604DE44 mov.w @r1,r6
    c.r[7] >>= 16;  // 0604DE46 shlr16 r7
    c.r[7] <<= 2;  // 0604DE48 shll2 r7
    c.r[7] >>= 8;  // 0604DE4A shlr8 r7
    c.r[6] <<= 16;  // 0604DE4C shll16 r6
    c.r[6] += c.r[6];  // 0604DE4E add r6,r6
    c.r[6] >>= 16;  // 0604DE50 shlr16 r6
    c.r[6] += c.r[6];  // 0604DE52 add r6,r6
    c.r[6] >>= 8;  // 0604DE54 shlr8 r6
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604DE56 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604DE58 mov.l r12,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE5Eu; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE5Eu) return; }  // 0604DE5A jsr @r0 ; mov.l r11,@-r15
    c.r[5] = 0x1Au;  // 0604DE5E mov #26,r5
    c.r[0] = ld32(0x0604DEC4u);  // 0604DE60 mov.l 0x0604DEC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE66u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE66u) return; }  // 0604DE62 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 0604DE66 mov r0,r1
    c.r[5] = c.r[1];  // 0604DE68 mov r1,r5
    c.r[0] = ld32(0x0604DEC8u);  // 0604DE6A mov.l 0x0604DEC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE70u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE70u) return; }  // 0604DE6C jsr @r0 ; mov r14,r4
    c.r[0] = ld32(0x0604DEB8u);  // 0604DE70 mov.l 0x0604DEB8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE76u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE76u) return; }  // 0604DE72 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0604DE76 mov r0,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604DE78 extu.w r1,r6
    c.r[5] = ld32(0x0604DEBCu);  // 0604DE7A mov.l 0x0604DEBC,r5
    c.r[0] = ld32(0x0604DEC0u);  // 0604DE7C mov.l 0x0604DEC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE82u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE82u) return; }  // 0604DE7E jsr @r0 ; mov r14,r4
    c.r[5] = 0x0u;  // 0604DE82 mov #0,r5
    c.r[0] = ld32(0x0604DEC4u);  // 0604DE84 mov.l 0x0604DEC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE8Au; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE8Au) return; }  // 0604DE86 jsr @r0 ; mov #4,r4
    c.r[1] = c.r[0];  // 0604DE8A mov r0,r1
    c.r[5] = c.r[1];  // 0604DE8C mov r1,r5
    c.r[0] = ld32(0x0604DEC8u);  // 0604DE8E mov.l 0x0604DEC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604DE94u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE94u) return; }  // 0604DE90 jsr @r0 ; mov r14,r4
    c.r[15] += 28;  // 0604DE94 add #28,r15
L_0604DE96:
    c.r[1] = ld32(0x0604DEF8u);  // 0604DE96 mov.l 0x0604DEF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DE9Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DE9Cu) return; }  // 0604DE98 jsr @r1 ; nop
    c.r[3] = ld32(0x0604DEFCu);  // 0604DE9C mov.l 0x0604DEFC,r3
    c.r[1] = ld32(c.r[3] + 4);  // 0604DE9E mov.l @(4,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604DEA0 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0604DF0A; } }  // 0604DEA2 bt/s 0x0604DF0A ; mov r3,r2
    c.r[2] += 12;  // 0604DEA6 add #12,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604DEA8 mov.b @r2,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604DEB6u);  // 0604DEAA mov.w 0x0604DEB6,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604DEAC mov.b @r3,r0
    c.r[1] &= c.r[7];  // 0604DEAE and r7,r1
    c.r[0] &= 0x7Fu; goto L_0604DF00;  // 0604DEB0 bra 0x0604DF00 ; and #127,r0
L_0604DF00:
    c.r[0] |= c.r[1];  // 0604DF00 or r1,r0
    st8(c.r[3], c.r[0]);  // 0604DF02 mov.b r0,@r3
    c.r[0] = c.r[7];  // 0604DF04 mov r7,r0
    c.r[0] |= 0x80u;  // 0604DF06 or #128,r0
    st8(c.r[2], c.r[0]);  // 0604DF08 mov.b r0,@r2
L_0604DF0A:
    c.r[14] += 52;  // 0604DF0A add #52,r14
    c.r[15] = c.r[14];  // 0604DF0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604DF0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF10 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF12 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF14 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF16 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF18 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF1A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604DF1C rts ; mov.l @r15+,r8
}

void f_0604DF20(SH2Context& c) {
    ran[1247] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604DF20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604DF22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604DF24 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604DF26 mov r15,r14
    c.r[6] = c.r[6] & 0xFFFFu;  // 0604DF28 extu.w r6,r6
    c.r[8] = c.r[7] & 0xFFFFu;  // 0604DF2A extu.w r7,r8
    c.r[1] = ld32(c.r[14] + 12);  // 0604DF2C mov.l @(12,r14),r1
    c.r[7] = 0x20u;  // 0604DF2E mov #32,r7
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604DF30 extu.w r1,r2
    c.r[1] = c.r[2];  // 0604DF32 mov r2,r1
    c.r[1] >>= 8;  // 0604DF34 shlr8 r1
    c.r[1] += c.r[1];  // 0604DF36 add r1,r1
    c.r[1] >>= 8;  // 0604DF38 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604DF3A tst r1,r1
    { const bool k = !c.t; c.r[9] = ld32(c.r[14] + 16); if (k) { goto L_0604DF42; } }  // 0604DF3C bf/s 0x0604DF42 ; mov.l @(16,r14),r9
    c.r[7] = 0x40u;  // 0604DF40 mov #64,r7
L_0604DF42:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604DF8Au);  // 0604DF42 mov.w 0x0604DF8A,r1
    c.r[2] &= c.r[1];  // 0604DF44 and r1,r2
    c.r[2] <<= 8;  // 0604DF46 shll8 r2
    c.r[2] <<= 2;  // 0604DF48 shll2 r2
    c.r[2] <<= 2;  // 0604DF4A shll2 r2
    c.r[3] = 0x0u;  // 0604DF4C mov #0,r3
    c.t = c.r[3] >= c.r[8];  // 0604DF4E cmp/hs r8,r3
    { const bool k = c.t; c.r[0] = c.r[2] & 0xFFFFu; if (k) { goto L_0604DF80; } }  // 0604DF50 bt/s 0x0604DF80 ; extu.w r2,r0
    c.r[7] -= c.r[6];  // 0604DF54 sub r6,r7
    c.r[7] += c.r[7];  // 0604DF56 add r7,r7
L_0604DF58:
    c.r[2] = 0x0u;  // 0604DF58 mov #0,r2
    c.t = c.r[2] >= c.r[6];  // 0604DF5A cmp/hs r6,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0604DF76; } }  // 0604DF5C bt/s 0x0604DF76 ; mov r3,r1
L_0604DF60:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); c.r[4] += 2;  // 0604DF60 mov.w @r4+,r1
    c.r[1] |= c.r[0];  // 0604DF62 or r0,r1
    c.r[1] += c.r[9];  // 0604DF64 add r9,r1
    st16(c.r[5], c.r[1]);  // 0604DF66 mov.w r1,@r5
    c.r[1] = c.r[2];  // 0604DF68 mov r2,r1
    c.r[1] += 1;  // 0604DF6A add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604DF6C extu.w r1,r2
    c.t = c.r[2] >= c.r[6];  // 0604DF6E cmp/hs r6,r2
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_0604DF60; } }  // 0604DF70 bf/s 0x0604DF60 ; add #2,r5
    c.r[1] = c.r[3];  // 0604DF74 mov r3,r1
L_0604DF76:
    c.r[1] += 1;  // 0604DF76 add #1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0604DF78 extu.w r1,r3
    c.t = c.r[3] >= c.r[8];  // 0604DF7A cmp/hs r8,r3
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { SH2_POLL(c); goto L_0604DF58; } }  // 0604DF7C bf/s 0x0604DF58 ; add r7,r5
L_0604DF80:
    c.r[15] = c.r[14];  // 0604DF80 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF82 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604DF84 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604DF86 rts ; mov.l @r15+,r8
}

void f_0604DF8C(SH2Context& c) {
    ran[1248] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604DF8C mov.l r14,@-r15
    c.r[2] = 0x0u;  // 0604DF8E mov #0,r2
    c.t = c.r[2] >= c.r[6];  // 0604DF90 cmp/hs r6,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604DFA6; } }  // 0604DF92 bt/s 0x0604DFA6 ; mov r15,r14
L_0604DF96:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); c.r[4] += 2;  // 0604DF96 mov.w @r4+,r1
    st16(c.r[5], c.r[1]);  // 0604DF98 mov.w r1,@r5
    c.r[1] = c.r[2];  // 0604DF9A mov r2,r1
    c.r[1] += 1;  // 0604DF9C add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0604DF9E extu.w r1,r2
    c.t = c.r[2] >= c.r[6];  // 0604DFA0 cmp/hs r6,r2
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_0604DF96; } }  // 0604DFA2 bf/s 0x0604DF96 ; add #2,r5
L_0604DFA6:
    c.r[15] = c.r[14];  // 0604DFA6 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604DFA8 rts ; mov.l @r15+,r14
}

void f_0604DFAC(SH2Context& c) {
    ran[1249] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604DFAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604DFAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604DFB0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604DFB2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604DFB4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604DFB6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604DFB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604DFBA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604DFBC mov r15,r14
    c.r[3] = ld32(0x0604E0A0u);  // 0604DFBE mov.l 0x0604E0A0,r3
    c.r[1] = ld32(0x0604E0A4u);  // 0604DFC0 mov.l 0x0604E0A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DFC6u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DFC6u) return; }  // 0604DFC2 jsr @r1 ; mov.w @r3,r4
    c.r[11] = ld32(0x0604E0A8u);  // 0604DFC6 mov.l 0x0604E0A8,r11
    c.r[3] = ld32(0x0604E0ACu);  // 0604DFC8 mov.l 0x0604E0AC,r3
    c.r[5] = ld32(c.r[3]);  // 0604DFCA mov.l @r3,r5
    c.r[13] = ld32(0x0604E0B0u);  // 0604DFCC mov.l 0x0604E0B0,r13
    c.r[1] = ld32(c.r[11]);  // 0604DFCE mov.l @r11,r1
    c.r[10] = ld32(0x0604E0B4u);  // 0604DFD0 mov.l 0x0604E0B4,r10
    c.r[4] = ld32(c.r[13]);  // 0604DFD2 mov.l @r13,r4
    c.r[5] += c.r[1];  // 0604DFD4 add r1,r5
    c.r[1] = ld32(c.r[10]);  // 0604DFD6 mov.l @r10,r1
    c.r[4] += c.r[1];  // 0604DFD8 add r1,r4
    c.r[1] = ld32(0x0604E0B8u);  // 0604DFDA mov.l 0x0604E0B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DFE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DFE0u) return; }  // 0604DFDC jsr @r1 ; nop
    c.r[3] = ld32(0x0604E0BCu);  // 0604DFE0 mov.l 0x0604E0BC,r3
    c.r[5] = ld32(c.r[3]);  // 0604DFE2 mov.l @r3,r5
    c.r[3] = ld32(0x0604E0C0u);  // 0604DFE4 mov.l 0x0604E0C0,r3
    c.r[1] = ld32(0x0604E0C4u);  // 0604DFE6 mov.l 0x0604E0C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604DFECu; c.r[4] = ld32(c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604DFECu) return; }  // 0604DFE8 jsr @r1 ; mov.l @r3,r4
    c.r[3] = ld32(0x0604E0C8u);  // 0604DFEC mov.l 0x0604E0C8,r3
    c.r[5] = ld32(c.r[3]);  // 0604DFEE mov.l @r3,r5
    c.r[1] = ld32(c.r[11]);  // 0604DFF0 mov.l @r11,r1
    c.r[12] = ld32(0x0604E0CCu);  // 0604DFF2 mov.l 0x0604E0CC,r12
    c.r[4] = ld32(c.r[12]);  // 0604DFF4 mov.l @r12,r4
    c.r[5] += c.r[1];  // 0604DFF6 add r1,r5
    c.r[1] = ld32(c.r[10]);  // 0604DFF8 mov.l @r10,r1
    c.r[4] += c.r[1];  // 0604DFFA add r1,r4
    c.r[1] = ld32(0x0604E0D0u);  // 0604DFFC mov.l 0x0604E0D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E002u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E002u) return; }  // 0604DFFE jsr @r1 ; nop
    c.r[9] = ld32(0x0604E0D4u);  // 0604E002 mov.l 0x0604E0D4,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604E004 mov.b @r9,r1
    c.r[8] = ld32(0x0604E0D8u);  // 0604E006 mov.l 0x0604E0D8,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604E008 mov.b @r8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0604E00A extu.b r1,r1
    c.r[2] = c.r[4] & 0xFFu;  // 0604E00C extu.b r4,r2
    c.t = c.r[1] == c.r[2];  // 0604E00E cmp/eq r2,r1
    { const bool k = c.t; c.r[4] += 1; if (k) { goto L_0604E028; } }  // 0604E010 bt/s 0x0604E028 ; add #1,r4
    c.r[1] = ld32(0x0604E0DCu);  // 0604E014 mov.l 0x0604E0DC,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E016 mov.b @r1,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0604E018 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0604E01A extu.b r5,r5
    c.r[5] >>= 2;  // 0604E01C shlr2 r5
    c.r[1] = ld32(0x0604E0E0u);  // 0604E01E mov.l 0x0604E0E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E024u; c.r[5] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E024u) return; }  // 0604E020 jsr @r1 ; shlr2 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604E024 mov.b @r8,r1
    st8(c.r[9], c.r[1]);  // 0604E026 mov.b r1,@r9
L_0604E028:
    c.r[2] = ld32(0x0604E0E4u);  // 0604E028 mov.l 0x0604E0E4,r2
    c.r[1] = c.r[2];  // 0604E02A mov r2,r1
    c.r[1] += 96;  // 0604E02C add #96,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604E02E mov.w @r1,r1
    c.r[3] = ld32(0x0604E0A0u);  // 0604E030 mov.l 0x0604E0A0,r3
    st16(c.r[3], c.r[1]);  // 0604E032 mov.w r1,@r3
    c.r[1] = c.r[2];  // 0604E034 mov r2,r1
    c.r[1] += 80;  // 0604E036 add #80,r1
    c.r[1] = ld32(c.r[1]);  // 0604E038 mov.l @r1,r1
    st32(c.r[13], c.r[1]);  // 0604E03A mov.l r1,@r13
    c.r[1] = c.r[2];  // 0604E03C mov r2,r1
    c.r[1] += 84;  // 0604E03E add #84,r1
    c.r[1] = ld32(c.r[1]);  // 0604E040 mov.l @r1,r1
    c.r[3] = ld32(0x0604E0ACu);  // 0604E042 mov.l 0x0604E0AC,r3
    st32(c.r[3], c.r[1]);  // 0604E044 mov.l r1,@r3
    c.r[1] = c.r[2];  // 0604E046 mov r2,r1
    c.r[1] += 100;  // 0604E048 add #100,r1
    c.r[1] = ld32(c.r[1]);  // 0604E04A mov.l @r1,r1
    st32(c.r[10], c.r[1]);  // 0604E04C mov.l r1,@r10
    c.r[1] = c.r[2];  // 0604E04E mov r2,r1
    c.r[1] += 104;  // 0604E050 add #104,r1
    c.r[1] = ld32(c.r[1]);  // 0604E052 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E09Cu);  // 0604E054 mov.w 0x0604E09C,r0
    st32(c.r[11], c.r[1]);  // 0604E056 mov.l r1,@r11
    c.r[1] = c.r[2];  // 0604E058 mov r2,r1
    c.r[1] += 88;  // 0604E05A add #88,r1
    c.r[1] = ld32(c.r[1]);  // 0604E05C mov.l @r1,r1
    c.r[3] = ld32(0x0604E0C0u);  // 0604E05E mov.l 0x0604E0C0,r3
    st32(c.r[3], c.r[1]);  // 0604E060 mov.l r1,@r3
    c.r[1] = c.r[2];  // 0604E062 mov r2,r1
    c.r[1] += 92;  // 0604E064 add #92,r1
    c.r[1] = ld32(c.r[1]);  // 0604E066 mov.l @r1,r1
    c.r[3] = ld32(0x0604E0BCu);  // 0604E068 mov.l 0x0604E0BC,r3
    st32(c.r[3], c.r[1]);  // 0604E06A mov.l r1,@r3
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0604E06C mov.l @(r0,r2),r1
    st32(c.r[12], c.r[1]);  // 0604E06E mov.l r1,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E09Eu);  // 0604E070 mov.w 0x0604E09E,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0604E072 mov.l @(r0,r2),r1
    c.r[3] = ld32(0x0604E0C8u);  // 0604E074 mov.l 0x0604E0C8,r3
    st32(c.r[3], c.r[1]);  // 0604E076 mov.l r1,@r3
    c.r[1] = ld32(0x0604E0E8u);  // 0604E078 mov.l 0x0604E0E8,r1
    c.r[1] = ld32(c.r[1]);  // 0604E07A mov.l @r1,r1
    c.r[1] += 8;  // 0604E07C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E07E mov.b @r1,r1
    c.r[15] = c.r[14];  // 0604E080 mov r14,r15
    c.r[0] = c.r[1];  // 0604E082 mov r1,r0
    c.r[0] >>= 2;  // 0604E084 shlr2 r0
    c.r[0] &= 0x1u;  // 0604E086 and #1,r0
    st8(c.r[8], c.r[0]);  // 0604E088 mov.b r0,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E08A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604E08C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604E08E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604E090 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604E092 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604E094 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604E096 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E098 rts ; mov.l @r15+,r8
}

void f_0604E0F4(SH2Context& c) {
    ran[1250] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0604E0F4 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0604E0F6 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604E0F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E0FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E0FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E0FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604E100 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604E102 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E104 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E106 sts.l pr,@-r15
    c.r[15] -= 4;  // 0604E108 add #-4,r15
    c.r[13] = ld32(0x0604E2DCu);  // 0604E10A mov.l 0x0604E2DC,r13
    c.r[1] = c.r[13];  // 0604E10C mov r13,r1
    c.r[1] += 117;  // 0604E10E add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E110 mov.b @r1,r3
    c.r[0] = ld32(0x0604E2E0u);  // 0604E112 mov.l 0x0604E2E0,r0
    c.r[1] = c.r[13];  // 0604E114 mov r13,r1
    c.r[1] += 79;  // 0604E116 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E118 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0604E11A extu.b r3,r3
    c.r[3] += c.r[1];  // 0604E11C add r1,r3
    c.r[1] = c.r[13];  // 0604E11E mov r13,r1
    c.r[1] += 116;  // 0604E120 add #116,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E122 mov.b @r1,r2
    c.r[3] <<= 2;  // 0604E124 shll2 r3
    c.r[3] <<= 2;  // 0604E126 shll2 r3
    c.r[3] <<= 2;  // 0604E128 shll2 r3
    c.r[1] = c.r[13];  // 0604E12A mov r13,r1
    c.r[1] += 78;  // 0604E12C add #78,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E12E mov.b @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0604E130 extu.b r2,r2
    c.r[1] = ld32(c.r[0]);  // 0604E132 mov.l @r0,r1
    c.r[2] += c.r[7];  // 0604E134 add r7,r2
    c.r[3] += c.r[1];  // 0604E136 add r1,r3
    c.r[0] = c.r[3];  // 0604E138 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604E13A mov.b @(r0,r2),r1
    c.r[14] = c.r[15];  // 0604E13C mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0604E13E extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0604E140 mov.l r1,@r14
    c.r[0] = ld32(0x0604E2E4u);  // 0604E142 mov.l 0x0604E2E4,r0
    c.r[1] = c.r[13];  // 0604E144 mov r13,r1
    c.r[12] = ld32(c.r[0] + 12);  // 0604E146 mov.l @(12,r0),r12
    c.r[1] += 108;  // 0604E148 add #108,r1
    c.r[0] = ld32(0x0604E2E8u);  // 0604E14A mov.l 0x0604E2E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604E150u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E150u) return; }  // 0604E14C jsr @r0 ; mov.w @r1,r4
    c.r[4] = c.r[0];  // 0604E150 mov r0,r4
    c.r[5] = c.r[1];  // 0604E152 mov r1,r5
    c.r[1] = ld32(0x0604E2ECu);  // 0604E154 mov.l 0x0604E2EC,r1
    c.r[8] = ld32(c.r[1]);  // 0604E156 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0604E158 mov.l @(4,r1),r9
    c.r[11] = ld32(0x0604E2F0u);  // 0604E15A mov.l 0x0604E2F0,r11
    c.r[6] = c.r[8];  // 0604E15C mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0604E162u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E162u) return; }  // 0604E15E jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604E162 mov r0,r4
    c.r[10] = ld32(0x0604E2F4u);  // 0604E164 mov.l 0x0604E2F4,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0604E16Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E16Au) return; }  // 0604E166 jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604E16A mov r0,r1
    st32(c.r[12], c.r[1]);  // 0604E16C mov.l r1,@r12
    c.r[0] = ld32(0x0604E2E4u);  // 0604E16E mov.l 0x0604E2E4,r0
    c.r[1] = c.r[13];  // 0604E170 mov r13,r1
    c.r[12] = ld32(c.r[0] + 12);  // 0604E172 mov.l @(12,r0),r12
    c.r[1] += 110;  // 0604E174 add #110,r1
    c.r[0] = ld32(0x0604E2E8u);  // 0604E176 mov.l 0x0604E2E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604E17Cu; c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E17Cu) return; }  // 0604E178 jsr @r0 ; mov.w @r1,r4
    c.r[4] = c.r[0];  // 0604E17C mov r0,r4
    c.r[5] = c.r[1];  // 0604E17E mov r1,r5
    c.r[6] = c.r[8];  // 0604E180 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0604E186u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E186u) return; }  // 0604E182 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604E186 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604E18Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E18Cu) return; }  // 0604E188 jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604E18C mov r0,r1
    st32(c.r[12] + 4, c.r[1]);  // 0604E18E mov.l r1,@(4,r12)
    c.r[1] = ld32(0x0604E2E0u);  // 0604E190 mov.l 0x0604E2E0,r1
    c.r[1] += 16;  // 0604E192 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E194 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0604E196 mov #1,r0
    c.r[1] >>= 2;  // 0604E198 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E19A shlr r1
    c.r[1] >>= 2;  // 0604E19C shlr2 r1
    c.r[1] &= c.r[0];  // 0604E19E and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E1A0 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0604E1FC; } }  // 0604E1A2 bt/s 0x0604E1FC ; mov.l @r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E2D8u);  // 0604E1A6 mov.w 0x0604E2D8,r1
    c.t = c.r[0] == c.r[1];  // 0604E1A8 cmp/eq r1,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0604E1FC; } }  // 0604E1AA bt/s 0x0604E1FC ; mov r13,r1
    c.r[1] += 118;  // 0604E1AE add #118,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E1B0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604E1B2 extu.b r1,r1
    c.r[1] >>= 2;  // 0604E1B4 shlr2 r1
    c.r[1] >>= 2;  // 0604E1B6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E1B8 shlr r1
    c.r[1] >>= 2;  // 0604E1BA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E1BC tst r1,r1
    { const bool k = !c.t; c.r[13] += 122; if (k) { goto L_0604E1FC; } }  // 0604E1BE bf/s 0x0604E1FC ; add #122,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604E1C2 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604E1C4 extu.b r1,r1
    c.r[1] >>= 2;  // 0604E1C6 shlr2 r1
    c.r[1] >>= 2;  // 0604E1C8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E1CA shlr r1
    c.r[1] >>= 2;  // 0604E1CC shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E1CE tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_0604E1FC; } }  // 0604E1D0 bf/s 0x0604E1FC ; mov r0,r2
    c.r[1] = ld32(0x0604E2F8u);  // 0604E1D4 mov.l 0x0604E2F8,r1
    c.r[1] = ld32(c.r[1]);  // 0604E1D6 mov.l @r1,r1
    c.r[2] <<= 2;  // 0604E1D8 shll2 r2
    c.r[2] <<= 2;  // 0604E1DA shll2 r2
    c.r[2] += c.r[1];  // 0604E1DC add r1,r2
    c.r[2] += 3;  // 0604E1DE add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604E1E0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0604E1E2 mov r1,r0
    c.r[0] >>= 2;  // 0604E1E4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604E1E6 shlr r0
    c.r[0] &= 0x3u;  // 0604E1E8 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604E1EA tst r0,r0
    if (!c.t) { goto L_0604E1FC; }  // 0604E1EC bf 0x0604E1FC
    c.r[0] = ld32(0x0604E2E4u);  // 0604E1EE mov.l 0x0604E2E4,r0
    c.r[1] = ld32(c.r[0] + 12);  // 0604E1F0 mov.l @(12,r0),r1
    c.r[3] = ld32(c.r[1] + 4);  // 0604E1F2 mov.l @(4,r1),r3
    c.r[0] = ld32(0x0604E2E0u);  // 0604E1F4 mov.l 0x0604E2E0,r0
    c.r[2] = ld32(c.r[0] + 4);  // 0604E1F6 mov.l @(4,r0),r2
    c.r[3] += c.r[2];  // 0604E1F8 add r2,r3
    st32(c.r[1] + 4, c.r[3]);  // 0604E1FA mov.l r3,@(4,r1)
L_0604E1FC:
    c.r[1] = ld32(0x0604E2E4u);  // 0604E1FC mov.l 0x0604E2E4,r1
    c.r[5] = ld32(c.r[1] + 8);  // 0604E1FE mov.l @(8,r1),r5
    c.r[4] = ld32(c.r[1] + 12);  // 0604E200 mov.l @(12,r1),r4
    c.r[1] = ld32(0x0604E2FCu);  // 0604E202 mov.l 0x0604E2FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E208u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E208u) return; }  // 0604E204 jsr @r1 ; nop
    c.r[3] = ld32(0x0604E2E0u);  // 0604E208 mov.l 0x0604E2E0,r3
    c.r[1] = c.r[3];  // 0604E20A mov r3,r1
    c.r[1] += 16;  // 0604E20C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E20E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604E210 mov r1,r0
    c.r[0] >>= 2;  // 0604E212 shlr2 r0
    c.r[0] >>= 2;  // 0604E214 shlr2 r0
    c.r[0] >>= 2;  // 0604E216 shlr2 r0
    c.r[0] &= 0x1u;  // 0604E218 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604E21A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0604E2B6; } }  // 0604E21C bt/s 0x0604E2B6 ; mov r3,r1
    c.r[1] += 18;  // 0604E220 add #18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E222 mov.b @r1,r1
    c.r[0] = ld32(c.r[14]);  // 0604E224 mov.l @r14,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0604E226 extu.b r1,r2
    c.t = c.r[2] == c.r[0];  // 0604E228 cmp/eq r0,r2
    if (c.t) { goto L_0604E24A; }  // 0604E22A bt 0x0604E24A
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E2D8u);  // 0604E22C mov.w 0x0604E2D8,r1
    c.t = c.r[2] == c.r[1];  // 0604E22E cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0604E24A; } }  // 0604E230 bt/s 0x0604E24A ; shll2 r2
    c.r[1] = ld32(0x0604E2F8u);  // 0604E234 mov.l 0x0604E2F8,r1
    c.r[2] <<= 2;  // 0604E236 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0604E238 mov.l @r1,r1
    c.r[3] += 17;  // 0604E23A add #17,r3
    c.r[2] += c.r[1];  // 0604E23C add r1,r2
    c.r[2] += 3;  // 0604E23E add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604E240 mov.b @r2,r0
    c.r[1] = 0x0u;  // 0604E242 mov #0,r1
    c.r[0] |= 0x40u;  // 0604E244 or #64,r0
    st8(c.r[2], c.r[0]);  // 0604E246 mov.b r0,@r2
    st8(c.r[3], c.r[1]);  // 0604E248 mov.b r1,@r3
L_0604E24A:
    c.r[2] = ld32(0x0604E2E0u);  // 0604E24A mov.l 0x0604E2E0,r2
    c.r[1] = c.r[2];  // 0604E24C mov r2,r1
    c.r[1] += 18;  // 0604E24E add #18,r1
    c.r[0] = 0x3u;  // 0604E250 mov #3,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0604E252 mov.b @(r0,r14),r0
    st8(c.r[1], c.r[0]);  // 0604E254 mov.b r0,@r1
    c.r[0] = ld32(c.r[14]);  // 0604E256 mov.l @r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E2D8u);  // 0604E258 mov.w 0x0604E2D8,r1
    c.t = c.r[0] == c.r[1];  // 0604E25A cmp/eq r1,r0
    { const bool k = c.t; c.r[7] = c.r[2]; if (k) { goto L_0604E2C2; } }  // 0604E25C bt/s 0x0604E2C2 ; mov r2,r7
    c.r[7] += 17;  // 0604E260 add #17,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604E262 mov.b @r7,r2
    c.r[1] = ld32(0x0604E300u);  // 0604E264 mov.l 0x0604E300,r1
    c.r[1] = ld32(c.r[1]);  // 0604E266 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604E268 extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0604E26A dmulu.l r1,r2
    c.r[1] = c.mach;  // 0604E26C sts mach,r1
    c.r[1] >>= 2;  // 0604E26E shlr2 r1
    c.r[1] >>= 2;  // 0604E270 shlr2 r1
    c.r[3] = c.r[1];  // 0604E272 mov r1,r3
    c.r[3] <<= 2;  // 0604E274 shll2 r3
    c.r[3] += c.r[1];  // 0604E276 add r1,r3
    c.r[3] <<= 2;  // 0604E278 shll2 r3
    c.r[2] -= c.r[3];  // 0604E27A sub r3,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604E27C extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604E27E tst r2,r2
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_0604E2AE; } }  // 0604E280 bf/s 0x0604E2AE ; mov r0,r2
    c.r[1] = ld32(0x0604E2F8u);  // 0604E284 mov.l 0x0604E2F8,r1
    c.r[1] = ld32(c.r[1]);  // 0604E286 mov.l @r1,r1
    c.r[2] <<= 2;  // 0604E288 shll2 r2
    c.r[2] <<= 2;  // 0604E28A shll2 r2
    c.r[2] += c.r[1];  // 0604E28C add r1,r2
    c.r[2] += 3;  // 0604E28E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604E290 mov.b @r2,r1
    c.r[0] = 0x1u;  // 0604E292 mov #1,r0
    c.r[3] = c.r[1];  // 0604E294 mov r1,r3
    c.r[3] >>= 2;  // 0604E296 shlr2 r3
    c.r[3] >>= 2;  // 0604E298 shlr2 r3
    c.r[3] >>= 2;  // 0604E29A shlr2 r3
    c.r[3] &= c.r[0];  // 0604E29C and r0,r3
    c.r[3] ^= c.r[0];  // 0604E29E xor r0,r3
    c.r[3] <<= 2;  // 0604E2A0 shll2 r3
    c.r[3] <<= 2;  // 0604E2A2 shll2 r3
    c.r[3] <<= 2;  // 0604E2A4 shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E2DAu);  // 0604E2A6 mov.w 0x0604E2DA,r0
    c.r[1] &= c.r[0];  // 0604E2A8 and r0,r1
    c.r[1] |= c.r[3];  // 0604E2AA or r3,r1
    st8(c.r[2], c.r[1]);  // 0604E2AC mov.b r1,@r2
L_0604E2AE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604E2AE mov.b @r7,r1
    c.r[1] += 1;  // 0604E2B0 add #1,r1
    st8(c.r[7], c.r[1]); goto L_0604E2C2;  // 0604E2B2 bra 0x0604E2C2 ; mov.b r1,@r7
L_0604E2B6:
    c.r[1] += 18;  // 0604E2B6 add #18,r1
    c.r[2] = 0xFFFFFFFFu;  // 0604E2B8 mov #-1,r2
    st8(c.r[1], c.r[2]);  // 0604E2BA mov.b r2,@r1
    c.r[3] += 17;  // 0604E2BC add #17,r3
    c.r[1] = 0x0u;  // 0604E2BE mov #0,r1
    st8(c.r[3], c.r[1]);  // 0604E2C0 mov.b r1,@r3
L_0604E2C2:
    c.r[14] += 4;  // 0604E2C2 add #4,r14
    c.r[15] = c.r[14];  // 0604E2C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E2C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2C8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2CA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2CC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2CE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2D2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E2D4 rts ; mov.l @r15+,r8
}

void f_0604E0F8(SH2Context& c) {
    ran[1251] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604E0F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E0FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E0FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E0FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604E100 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604E102 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E104 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E106 sts.l pr,@-r15
    c.r[15] -= 4;  // 0604E108 add #-4,r15
    c.r[13] = ld32(0x0604E2DCu);  // 0604E10A mov.l 0x0604E2DC,r13
    c.r[1] = c.r[13];  // 0604E10C mov r13,r1
    c.r[1] += 117;  // 0604E10E add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E110 mov.b @r1,r3
    c.r[0] = ld32(0x0604E2E0u);  // 0604E112 mov.l 0x0604E2E0,r0
    c.r[1] = c.r[13];  // 0604E114 mov r13,r1
    c.r[1] += 79;  // 0604E116 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E118 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0604E11A extu.b r3,r3
    c.r[3] += c.r[1];  // 0604E11C add r1,r3
    c.r[1] = c.r[13];  // 0604E11E mov r13,r1
    c.r[1] += 116;  // 0604E120 add #116,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E122 mov.b @r1,r2
    c.r[3] <<= 2;  // 0604E124 shll2 r3
    c.r[3] <<= 2;  // 0604E126 shll2 r3
    c.r[3] <<= 2;  // 0604E128 shll2 r3
    c.r[1] = c.r[13];  // 0604E12A mov r13,r1
    c.r[1] += 78;  // 0604E12C add #78,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E12E mov.b @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0604E130 extu.b r2,r2
    c.r[1] = ld32(c.r[0]);  // 0604E132 mov.l @r0,r1
    c.r[2] += c.r[7];  // 0604E134 add r7,r2
    c.r[3] += c.r[1];  // 0604E136 add r1,r3
    c.r[0] = c.r[3];  // 0604E138 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604E13A mov.b @(r0,r2),r1
    c.r[14] = c.r[15];  // 0604E13C mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0604E13E extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0604E140 mov.l r1,@r14
    c.r[0] = ld32(0x0604E2E4u);  // 0604E142 mov.l 0x0604E2E4,r0
    c.r[1] = c.r[13];  // 0604E144 mov r13,r1
    c.r[12] = ld32(c.r[0] + 12);  // 0604E146 mov.l @(12,r0),r12
    c.r[1] += 108;  // 0604E148 add #108,r1
    c.r[0] = ld32(0x0604E2E8u);  // 0604E14A mov.l 0x0604E2E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604E150u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E150u) return; }  // 0604E14C jsr @r0 ; mov.w @r1,r4
    c.r[4] = c.r[0];  // 0604E150 mov r0,r4
    c.r[5] = c.r[1];  // 0604E152 mov r1,r5
    c.r[1] = ld32(0x0604E2ECu);  // 0604E154 mov.l 0x0604E2EC,r1
    c.r[8] = ld32(c.r[1]);  // 0604E156 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0604E158 mov.l @(4,r1),r9
    c.r[11] = ld32(0x0604E2F0u);  // 0604E15A mov.l 0x0604E2F0,r11
    c.r[6] = c.r[8];  // 0604E15C mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0604E162u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E162u) return; }  // 0604E15E jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604E162 mov r0,r4
    c.r[10] = ld32(0x0604E2F4u);  // 0604E164 mov.l 0x0604E2F4,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0604E16Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E16Au) return; }  // 0604E166 jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604E16A mov r0,r1
    st32(c.r[12], c.r[1]);  // 0604E16C mov.l r1,@r12
    c.r[0] = ld32(0x0604E2E4u);  // 0604E16E mov.l 0x0604E2E4,r0
    c.r[1] = c.r[13];  // 0604E170 mov r13,r1
    c.r[12] = ld32(c.r[0] + 12);  // 0604E172 mov.l @(12,r0),r12
    c.r[1] += 110;  // 0604E174 add #110,r1
    c.r[0] = ld32(0x0604E2E8u);  // 0604E176 mov.l 0x0604E2E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604E17Cu; c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E17Cu) return; }  // 0604E178 jsr @r0 ; mov.w @r1,r4
    c.r[4] = c.r[0];  // 0604E17C mov r0,r4
    c.r[5] = c.r[1];  // 0604E17E mov r1,r5
    c.r[6] = c.r[8];  // 0604E180 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0604E186u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E186u) return; }  // 0604E182 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604E186 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604E18Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E18Cu) return; }  // 0604E188 jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 0604E18C mov r0,r1
    st32(c.r[12] + 4, c.r[1]);  // 0604E18E mov.l r1,@(4,r12)
    c.r[1] = ld32(0x0604E2E0u);  // 0604E190 mov.l 0x0604E2E0,r1
    c.r[1] += 16;  // 0604E192 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E194 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0604E196 mov #1,r0
    c.r[1] >>= 2;  // 0604E198 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E19A shlr r1
    c.r[1] >>= 2;  // 0604E19C shlr2 r1
    c.r[1] &= c.r[0];  // 0604E19E and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E1A0 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0604E1FC; } }  // 0604E1A2 bt/s 0x0604E1FC ; mov.l @r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E2D8u);  // 0604E1A6 mov.w 0x0604E2D8,r1
    c.t = c.r[0] == c.r[1];  // 0604E1A8 cmp/eq r1,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0604E1FC; } }  // 0604E1AA bt/s 0x0604E1FC ; mov r13,r1
    c.r[1] += 118;  // 0604E1AE add #118,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E1B0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604E1B2 extu.b r1,r1
    c.r[1] >>= 2;  // 0604E1B4 shlr2 r1
    c.r[1] >>= 2;  // 0604E1B6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E1B8 shlr r1
    c.r[1] >>= 2;  // 0604E1BA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E1BC tst r1,r1
    { const bool k = !c.t; c.r[13] += 122; if (k) { goto L_0604E1FC; } }  // 0604E1BE bf/s 0x0604E1FC ; add #122,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604E1C2 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604E1C4 extu.b r1,r1
    c.r[1] >>= 2;  // 0604E1C6 shlr2 r1
    c.r[1] >>= 2;  // 0604E1C8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E1CA shlr r1
    c.r[1] >>= 2;  // 0604E1CC shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E1CE tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_0604E1FC; } }  // 0604E1D0 bf/s 0x0604E1FC ; mov r0,r2
    c.r[1] = ld32(0x0604E2F8u);  // 0604E1D4 mov.l 0x0604E2F8,r1
    c.r[1] = ld32(c.r[1]);  // 0604E1D6 mov.l @r1,r1
    c.r[2] <<= 2;  // 0604E1D8 shll2 r2
    c.r[2] <<= 2;  // 0604E1DA shll2 r2
    c.r[2] += c.r[1];  // 0604E1DC add r1,r2
    c.r[2] += 3;  // 0604E1DE add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604E1E0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0604E1E2 mov r1,r0
    c.r[0] >>= 2;  // 0604E1E4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604E1E6 shlr r0
    c.r[0] &= 0x3u;  // 0604E1E8 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604E1EA tst r0,r0
    if (!c.t) { goto L_0604E1FC; }  // 0604E1EC bf 0x0604E1FC
    c.r[0] = ld32(0x0604E2E4u);  // 0604E1EE mov.l 0x0604E2E4,r0
    c.r[1] = ld32(c.r[0] + 12);  // 0604E1F0 mov.l @(12,r0),r1
    c.r[3] = ld32(c.r[1] + 4);  // 0604E1F2 mov.l @(4,r1),r3
    c.r[0] = ld32(0x0604E2E0u);  // 0604E1F4 mov.l 0x0604E2E0,r0
    c.r[2] = ld32(c.r[0] + 4);  // 0604E1F6 mov.l @(4,r0),r2
    c.r[3] += c.r[2];  // 0604E1F8 add r2,r3
    st32(c.r[1] + 4, c.r[3]);  // 0604E1FA mov.l r3,@(4,r1)
L_0604E1FC:
    c.r[1] = ld32(0x0604E2E4u);  // 0604E1FC mov.l 0x0604E2E4,r1
    c.r[5] = ld32(c.r[1] + 8);  // 0604E1FE mov.l @(8,r1),r5
    c.r[4] = ld32(c.r[1] + 12);  // 0604E200 mov.l @(12,r1),r4
    c.r[1] = ld32(0x0604E2FCu);  // 0604E202 mov.l 0x0604E2FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E208u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E208u) return; }  // 0604E204 jsr @r1 ; nop
    c.r[3] = ld32(0x0604E2E0u);  // 0604E208 mov.l 0x0604E2E0,r3
    c.r[1] = c.r[3];  // 0604E20A mov r3,r1
    c.r[1] += 16;  // 0604E20C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E20E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604E210 mov r1,r0
    c.r[0] >>= 2;  // 0604E212 shlr2 r0
    c.r[0] >>= 2;  // 0604E214 shlr2 r0
    c.r[0] >>= 2;  // 0604E216 shlr2 r0
    c.r[0] &= 0x1u;  // 0604E218 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604E21A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0604E2B6; } }  // 0604E21C bt/s 0x0604E2B6 ; mov r3,r1
    c.r[1] += 18;  // 0604E220 add #18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E222 mov.b @r1,r1
    c.r[0] = ld32(c.r[14]);  // 0604E224 mov.l @r14,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0604E226 extu.b r1,r2
    c.t = c.r[2] == c.r[0];  // 0604E228 cmp/eq r0,r2
    if (c.t) { goto L_0604E24A; }  // 0604E22A bt 0x0604E24A
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E2D8u);  // 0604E22C mov.w 0x0604E2D8,r1
    c.t = c.r[2] == c.r[1];  // 0604E22E cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0604E24A; } }  // 0604E230 bt/s 0x0604E24A ; shll2 r2
    c.r[1] = ld32(0x0604E2F8u);  // 0604E234 mov.l 0x0604E2F8,r1
    c.r[2] <<= 2;  // 0604E236 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0604E238 mov.l @r1,r1
    c.r[3] += 17;  // 0604E23A add #17,r3
    c.r[2] += c.r[1];  // 0604E23C add r1,r2
    c.r[2] += 3;  // 0604E23E add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604E240 mov.b @r2,r0
    c.r[1] = 0x0u;  // 0604E242 mov #0,r1
    c.r[0] |= 0x40u;  // 0604E244 or #64,r0
    st8(c.r[2], c.r[0]);  // 0604E246 mov.b r0,@r2
    st8(c.r[3], c.r[1]);  // 0604E248 mov.b r1,@r3
L_0604E24A:
    c.r[2] = ld32(0x0604E2E0u);  // 0604E24A mov.l 0x0604E2E0,r2
    c.r[1] = c.r[2];  // 0604E24C mov r2,r1
    c.r[1] += 18;  // 0604E24E add #18,r1
    c.r[0] = 0x3u;  // 0604E250 mov #3,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0604E252 mov.b @(r0,r14),r0
    st8(c.r[1], c.r[0]);  // 0604E254 mov.b r0,@r1
    c.r[0] = ld32(c.r[14]);  // 0604E256 mov.l @r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E2D8u);  // 0604E258 mov.w 0x0604E2D8,r1
    c.t = c.r[0] == c.r[1];  // 0604E25A cmp/eq r1,r0
    { const bool k = c.t; c.r[7] = c.r[2]; if (k) { goto L_0604E2C2; } }  // 0604E25C bt/s 0x0604E2C2 ; mov r2,r7
    c.r[7] += 17;  // 0604E260 add #17,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604E262 mov.b @r7,r2
    c.r[1] = ld32(0x0604E300u);  // 0604E264 mov.l 0x0604E300,r1
    c.r[1] = ld32(c.r[1]);  // 0604E266 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604E268 extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0604E26A dmulu.l r1,r2
    c.r[1] = c.mach;  // 0604E26C sts mach,r1
    c.r[1] >>= 2;  // 0604E26E shlr2 r1
    c.r[1] >>= 2;  // 0604E270 shlr2 r1
    c.r[3] = c.r[1];  // 0604E272 mov r1,r3
    c.r[3] <<= 2;  // 0604E274 shll2 r3
    c.r[3] += c.r[1];  // 0604E276 add r1,r3
    c.r[3] <<= 2;  // 0604E278 shll2 r3
    c.r[2] -= c.r[3];  // 0604E27A sub r3,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604E27C extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604E27E tst r2,r2
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_0604E2AE; } }  // 0604E280 bf/s 0x0604E2AE ; mov r0,r2
    c.r[1] = ld32(0x0604E2F8u);  // 0604E284 mov.l 0x0604E2F8,r1
    c.r[1] = ld32(c.r[1]);  // 0604E286 mov.l @r1,r1
    c.r[2] <<= 2;  // 0604E288 shll2 r2
    c.r[2] <<= 2;  // 0604E28A shll2 r2
    c.r[2] += c.r[1];  // 0604E28C add r1,r2
    c.r[2] += 3;  // 0604E28E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604E290 mov.b @r2,r1
    c.r[0] = 0x1u;  // 0604E292 mov #1,r0
    c.r[3] = c.r[1];  // 0604E294 mov r1,r3
    c.r[3] >>= 2;  // 0604E296 shlr2 r3
    c.r[3] >>= 2;  // 0604E298 shlr2 r3
    c.r[3] >>= 2;  // 0604E29A shlr2 r3
    c.r[3] &= c.r[0];  // 0604E29C and r0,r3
    c.r[3] ^= c.r[0];  // 0604E29E xor r0,r3
    c.r[3] <<= 2;  // 0604E2A0 shll2 r3
    c.r[3] <<= 2;  // 0604E2A2 shll2 r3
    c.r[3] <<= 2;  // 0604E2A4 shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E2DAu);  // 0604E2A6 mov.w 0x0604E2DA,r0
    c.r[1] &= c.r[0];  // 0604E2A8 and r0,r1
    c.r[1] |= c.r[3];  // 0604E2AA or r3,r1
    st8(c.r[2], c.r[1]);  // 0604E2AC mov.b r1,@r2
L_0604E2AE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604E2AE mov.b @r7,r1
    c.r[1] += 1;  // 0604E2B0 add #1,r1
    st8(c.r[7], c.r[1]); goto L_0604E2C2;  // 0604E2B2 bra 0x0604E2C2 ; mov.b r1,@r7
L_0604E2B6:
    c.r[1] += 18;  // 0604E2B6 add #18,r1
    c.r[2] = 0xFFFFFFFFu;  // 0604E2B8 mov #-1,r2
    st8(c.r[1], c.r[2]);  // 0604E2BA mov.b r2,@r1
    c.r[3] += 17;  // 0604E2BC add #17,r3
    c.r[1] = 0x0u;  // 0604E2BE mov #0,r1
    st8(c.r[3], c.r[1]);  // 0604E2C0 mov.b r1,@r3
L_0604E2C2:
    c.r[14] += 4;  // 0604E2C2 add #4,r14
    c.r[15] = c.r[14];  // 0604E2C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E2C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2C8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2CA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2CC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2CE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604E2D2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E2D4 rts ; mov.l @r15+,r8
}

void f_0604E304(SH2Context& c) {
    ran[1252] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604E304 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E306 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E308 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E30A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604E30C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604E30E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E310 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E312 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604E3A2u);  // 0604E314 mov.w 0x0604E3A2,r3
    c.r[15] += c.r[3];  // 0604E316 add r3,r15
    c.r[14] = c.r[15];  // 0604E318 mov r15,r14
    c.r[10] = (uint32_t)(int16_t)ld16(0x0604E3A4u);  // 0604E31A mov.w 0x0604E3A4,r10
    c.r[10] += c.r[14];  // 0604E31C add r14,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E3A6u);  // 0604E31E mov.w 0x0604E3A6,r11
    c.r[11] += c.r[14];  // 0604E320 add r14,r11
    c.r[4] = c.r[4] & 0xFFu;  // 0604E322 extu.b r4,r4
    c.r[12] = c.r[5] & 0xFFFFu;  // 0604E324 extu.w r5,r12
    c.r[6] = c.r[6] & 0xFFFFu;  // 0604E326 extu.w r6,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0604E328 extu.b r7,r7
    c.r[13] = ld32(0x0604E3B0u);  // 0604E32A mov.l 0x0604E3B0,r13
    c.r[0] = ld32(0x0604E3B4u);  // 0604E32C mov.l 0x0604E3B4,r0
    c.r[9] = ld32(c.r[10]);  // 0604E32E mov.l @r10,r9
    c.r[5] = 0x0u;  // 0604E330 mov #0,r5
    c.r[8] = ld32(c.r[11]);  // 0604E332 mov.l @r11,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0604E3A8u);  // 0604E334 mov.w 0x0604E3A8,r10
    c.r[10] += c.r[14];  // 0604E336 add r14,r10
    st32(c.r[10], c.r[6]);  // 0604E338 mov.l r6,@r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E3AAu);  // 0604E33A mov.w 0x0604E3AA,r11
    c.r[11] += c.r[14];  // 0604E33C add r14,r11
    st32(c.r[11], c.r[7]);  // 0604E33E mov.l r7,@r11
    c.r[7] = 0xFFFFFFFFu;  // 0604E340 mov #-1,r7
    { const uint32_t x = c.r[0]; c.pr = 0x0604E346u; c.r[6] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E346u) return; }  // 0604E342 jsr @r0 ; mov r13,r6
    c.r[7] = ld32(0x0604E3B8u);  // 0604E346 mov.l 0x0604E3B8,r7
    c.r[6] = c.r[7];  // 0604E348 mov r7,r6
    c.r[6] -= 2;  // 0604E34A add #-2,r6
    c.t = (c.r[9] & c.r[9]) == 0;  // 0604E34C tst r9,r9
    { const bool k = !c.t; c.r[15] -= 4; st32(c.r[15], c.r[8]); if (k) { goto L_0604E354; } }  // 0604E34E bf/s 0x0604E354 ; mov.l r8,@-r15
    c.r[9] = c.r[14];  // 0604E352 mov r14,r9
L_0604E354:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E354 mov.l r9,@-r15
    c.r[3] = c.r[7];  // 0604E356 mov r7,r3
    c.r[3] -= 90;  // 0604E358 add #-90,r3
    c.r[1] = 0xAu;  // 0604E35A mov #10,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0604E3AAu);  // 0604E35C mov.w 0x0604E3AA,r10
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604E35E mov.w @r6,r2
    c.r[10] += c.r[14];  // 0604E360 add r14,r10
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604E362 mulu.w r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E3A8u);  // 0604E364 mov.w 0x0604E3A8,r11
    c.r[2] = ld32(c.r[3] + 8);  // 0604E366 mov.l @(8,r3),r2
    c.r[1] = c.macl;  // 0604E368 sts macl,r1
    c.r[2] += c.r[1];  // 0604E36A add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0604E36C mov.l r2,@-r15
    c.r[1] = ld32(c.r[3] + 4);  // 0604E36E mov.l @(4,r3),r1
    c.r[11] += c.r[14];  // 0604E370 add r14,r11
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604E372 mov.l r1,@-r15
    c.r[1] = ld32(c.r[3]);  // 0604E374 mov.l @r3,r1
    c.r[0] = ld32(0x0604E3BCu);  // 0604E376 mov.l 0x0604E3BC,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604E378 mov.l r1,@-r15
    c.r[10] = ld32(c.r[10]);  // 0604E37A mov.l @r10,r10
    c.r[5] = ld32(0x0604E3C0u);  // 0604E37C mov.l 0x0604E3C0,r5
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E37E mov.l r10,@-r15
    c.r[11] = ld32(c.r[11]);  // 0604E380 mov.l @r11,r11
    c.r[4] = c.r[13];  // 0604E382 mov r13,r4
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E384 mov.l r11,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x0604E38Au; c.r[15] -= 4; st32(c.r[15], c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E38Au) return; }  // 0604E386 jsr @r0 ; mov.l r12,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604E3ACu);  // 0604E38A mov.w 0x0604E3AC,r3
    c.r[14] += c.r[3];  // 0604E38C add r3,r14
    c.r[15] = c.r[14];  // 0604E38E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E390 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604E392 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604E394 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604E396 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604E398 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604E39A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604E39C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E39E rts ; mov.l @r15+,r8
}

void f_0604E3C4(SH2Context& c) {
    ran[1253] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604E3C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E3C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E3C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E3CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604E3CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604E3CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E3D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E3D2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604E524u);  // 0604E3D4 mov.w 0x0604E524,r3
    c.r[15] += c.r[3];  // 0604E3D6 add r3,r15
    c.r[14] = c.r[15];  // 0604E3D8 mov r15,r14
    c.r[5] = c.r[5] & 0xFFu;  // 0604E3DA extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E526u);  // 0604E3DC mov.w 0x0604E526,r0
    st32(c.r[0] + c.r[14], c.r[5]);  // 0604E3DE mov.l r5,@(r0,r14)
    c.r[12] = c.r[6] & 0xFFu;  // 0604E3E0 extu.b r6,r12
    c.r[7] = c.r[7] & 0xFFu;  // 0604E3E2 extu.b r7,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E528u);  // 0604E3E4 mov.w 0x0604E528,r11
    c.r[11] += c.r[14];  // 0604E3E6 add r14,r11
    st32(c.r[11], c.r[7]);  // 0604E3E8 mov.l r7,@r11
    c.r[6] = 0x0u;  // 0604E3EA mov #0,r6
    st8(c.r[14], c.r[6]);  // 0604E3EC mov.b r6,@r14
    c.r[1] = c.r[14];  // 0604E3EE mov r14,r1
    c.r[1] += 1;  // 0604E3F0 add #1,r1
    c.r[7] = 0x1u;  // 0604E3F2 mov #1,r7
    st8(c.r[1], c.r[7]);  // 0604E3F4 mov.b r7,@r1
    c.r[1] = c.r[14];  // 0604E3F6 mov r14,r1
    c.r[1] += 2;  // 0604E3F8 add #2,r1
    c.r[3] = 0x2u;  // 0604E3FA mov #2,r3
    st8(c.r[1], c.r[3]);  // 0604E3FC mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604E3FE mov r14,r1
    c.r[1] += 3;  // 0604E400 add #3,r1
    c.r[2] = 0x3u;  // 0604E402 mov #3,r2
    st8(c.r[1], c.r[2]);  // 0604E404 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0604E406 mov r14,r1
    c.r[1] += 4;  // 0604E408 add #4,r1
    st8(c.r[1], c.r[7]);  // 0604E40A mov.b r7,@r1
    c.r[1] = c.r[14];  // 0604E40C mov r14,r1
    c.r[1] += 5;  // 0604E40E add #5,r1
    st8(c.r[1], c.r[6]);  // 0604E410 mov.b r6,@r1
    c.r[1] = c.r[14];  // 0604E412 mov r14,r1
    c.r[1] += 6;  // 0604E414 add #6,r1
    st8(c.r[1], c.r[2]);  // 0604E416 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0604E418 mov r14,r1
    c.r[1] += 7;  // 0604E41A add #7,r1
    st8(c.r[1], c.r[3]);  // 0604E41C mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604E41E mov r14,r1
    c.r[1] += 8;  // 0604E420 add #8,r1
    st8(c.r[1], c.r[3]);  // 0604E422 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604E424 mov r14,r1
    c.r[1] += 9;  // 0604E426 add #9,r1
    st8(c.r[1], c.r[2]);  // 0604E428 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0604E42A mov r14,r1
    c.r[1] += 10;  // 0604E42C add #10,r1
    st8(c.r[1], c.r[6]);  // 0604E42E mov.b r6,@r1
    c.r[1] = c.r[14];  // 0604E430 mov r14,r1
    c.r[1] += 11;  // 0604E432 add #11,r1
    st8(c.r[1], c.r[7]);  // 0604E434 mov.b r7,@r1
    c.r[1] = c.r[14];  // 0604E436 mov r14,r1
    c.r[1] += 12;  // 0604E438 add #12,r1
    st8(c.r[1], c.r[2]);  // 0604E43A mov.b r2,@r1
    c.r[1] = c.r[14];  // 0604E43C mov r14,r1
    c.r[1] += 13;  // 0604E43E add #13,r1
    st8(c.r[1], c.r[3]);  // 0604E440 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604E442 mov r14,r1
    c.r[1] += 14;  // 0604E444 add #14,r1
    st8(c.r[1], c.r[7]);  // 0604E446 mov.b r7,@r1
    c.r[1] = c.r[14];  // 0604E448 mov r14,r1
    c.r[1] += 15;  // 0604E44A add #15,r1
    st8(c.r[1], c.r[6]);  // 0604E44C mov.b r6,@r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E526u);  // 0604E44E mov.w 0x0604E526,r13
    c.r[13] += c.r[14];  // 0604E450 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0604E452 mov.l @r13,r13
    c.r[1] = 0x1u;  // 0604E454 mov #1,r1
    c.t = c.r[13] > c.r[1];  // 0604E456 cmp/hi r1,r13
    { const bool k = !c.t; c.r[9] = c.r[4]; if (k) { goto L_0604E46A; } }  // 0604E458 bf/s 0x0604E46A ; mov r4,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E528u);  // 0604E45C mov.w 0x0604E528,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0604E45E mov.l @(r0,r14),r0
    c.r[1] = 0x20u;  // 0604E460 mov #32,r1
    c.t = c.r[0] > c.r[1];  // 0604E462 cmp/hi r1,r0
    if (c.t) { goto L_0604E46A; }  // 0604E464 bt 0x0604E46A
    goto L_0604E70A;  // 0604E466 bra 0x0604E70A ; nop
L_0604E46A:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E526u);  // 0604E46A mov.w 0x0604E526,r11
    c.r[11] += c.r[14];  // 0604E46C add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0604E46E mov.l @r11,r11
    c.r[1] = 0x1u;  // 0604E470 mov #1,r1
    c.r[1] &= c.r[11];  // 0604E472 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E474 tst r1,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0604E484; } }  // 0604E476 bt/s 0x0604E484 ; mov #0,r6
    c.r[1] = 0x20u;  // 0604E47A mov #32,r1
    c.t = c.r[12] > c.r[1];  // 0604E47C cmp/hi r1,r12
    if (c.t) { goto L_0604E484; }  // 0604E47E bt 0x0604E484
    goto L_0604E70A;  // 0604E480 bra 0x0604E70A ; nop
L_0604E484:
    c.r[8] = c.r[14];  // 0604E484 mov r14,r8
    c.r[8] += 16;  // 0604E486 add #16,r8
    c.r[7] = ld32(0x0604E53Cu);  // 0604E488 mov.l 0x0604E53C,r7
    c.r[10] = (uint32_t)(int16_t)ld16(0x0604E52Au);  // 0604E48A mov.w 0x0604E52A,r10
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604E52Cu);  // 0604E48C mov.w 0x0604E52C,r4
L_0604E48E:
    c.r[5] = 0x0u;  // 0604E48E mov #0,r5
    c.r[0] = c.r[7];  // 0604E490 mov r7,r0
L_0604E492:
    c.r[5] += 1;  // 0604E492 add #1,r5
    c.r[11] = 0x1Fu;  // 0604E494 mov #31,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0604E496 mov.w @(r0,r10),r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[11];  // 0604E498 cmp/gt r11,r5
    st16(c.r[8], c.r[1]);  // 0604E49A mov.w r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0604E49C mov.w @(r0,r4),r1
    c.r[8] += 2;  // 0604E49E add #2,r8
    st16(c.r[8], c.r[1]);  // 0604E4A0 mov.w r1,@r8
    { const bool k = !c.t; c.r[8] += 2; if (k) { SH2_POLL(c); goto L_0604E492; } }  // 0604E4A2 bf/s 0x0604E492 ; add #2,r8
    c.r[5] = 0x0u;  // 0604E4A6 mov #0,r5
    c.r[3] = 0x1Fu;  // 0604E4A8 mov #31,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604E52Eu);  // 0604E4AA mov.w 0x0604E52E,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E530u);  // 0604E4AC mov.w 0x0604E530,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E532u);  // 0604E4AE mov.w 0x0604E532,r13
    c.r[13] += c.r[14];  // 0604E4B0 add r14,r13
    st32(c.r[13], c.r[0]);  // 0604E4B2 mov.l r0,@r13
L_0604E4B4:
    c.r[0] = c.r[7];  // 0604E4B4 mov r7,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E532u);  // 0604E4B6 mov.w 0x0604E532,r11
    c.r[11] += c.r[14];  // 0604E4B8 add r14,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0604E4BA mov.w @(r0,r2),r1
    c.r[5] += 1;  // 0604E4BC add #1,r5
    st16(c.r[8], c.r[1]);  // 0604E4BE mov.w r1,@r8
    c.r[0] = ld32(c.r[11]);  // 0604E4C0 mov.l @r11,r0
    c.t = (int32_t)c.r[5] > (int32_t)c.r[3];  // 0604E4C2 cmp/gt r3,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0604E4C4 mov.w @(r0,r7),r1
    c.r[8] += 2;  // 0604E4C6 add #2,r8
    st16(c.r[8], c.r[1]);  // 0604E4C8 mov.w r1,@r8
    { const bool k = !c.t; c.r[8] += 2; if (k) { SH2_POLL(c); goto L_0604E4B4; } }  // 0604E4CA bf/s 0x0604E4B4 ; add #2,r8
    c.r[6] += 1;  // 0604E4CE add #1,r6
    c.r[1] = 0x1Fu;  // 0604E4D0 mov #31,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0604E4D2 cmp/gt r1,r6
    if (!c.t) { SH2_POLL(c); goto L_0604E48E; }  // 0604E4D4 bf 0x0604E48E
    c.r[8] = c.r[14];  // 0604E4D6 mov r14,r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E526u);  // 0604E4D8 mov.w 0x0604E526,r13
    c.r[13] += c.r[14];  // 0604E4DA add r14,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E526u);  // 0604E4DC mov.w 0x0604E526,r11
    c.r[0] = ld32(c.r[13]);  // 0604E4DE mov.l @r13,r0
    c.r[11] += c.r[14];  // 0604E4E0 add r14,r11
    c.r[0] <<= 8;  // 0604E4E2 shll8 r0
    c.r[0] <<= 2;  // 0604E4E4 shll2 r0
    c.r[0] <<= 2;  // 0604E4E6 shll2 r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E534u);  // 0604E4E8 mov.w 0x0604E534,r13
    c.r[13] += c.r[14];  // 0604E4EA add r14,r13
    st32(c.r[13], c.r[0]);  // 0604E4EC mov.l r0,@r13
    c.r[11] = ld32(c.r[11]);  // 0604E4EE mov.l @r11,r11
    c.r[1] = 0x1u;  // 0604E4F0 mov #1,r1
    c.t = c.r[11] > c.r[1];  // 0604E4F2 cmp/hi r1,r11
    { const bool k = !c.t; c.r[8] += 16; if (k) { goto L_0604E540; } }  // 0604E4F4 bf/s 0x0604E540 ; add #16,r8
    c.r[1] = c.r[12];  // 0604E4F8 mov r12,r1
    c.r[1] <<= 2;  // 0604E4FA shll2 r1
    c.r[1] <<= 2;  // 0604E4FC shll2 r1
    c.r[1] <<= 2;  // 0604E4FE shll2 r1
    c.r[9] += c.r[1];  // 0604E500 add r1,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E528u);  // 0604E502 mov.w 0x0604E528,r13
    c.r[13] += c.r[14];  // 0604E504 add r14,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E536u);  // 0604E506 mov.w 0x0604E536,r11
    c.r[0] = ld32(c.r[13]);  // 0604E508 mov.l @r13,r0
    c.r[11] += c.r[14];  // 0604E50A add r14,r11
    c.r[0] -= 32;  // 0604E50C add #-32,r0
    st32(c.r[13], c.r[0]);  // 0604E50E mov.l r0,@r13
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0604E510 mov.b @r11,r11
    c.r[0] = 0x20u;  // 0604E512 mov #32,r0
    c.r[13] = c.r[11] & 0xFFu;  // 0604E514 extu.b r11,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E538u);  // 0604E516 mov.w 0x0604E538,r11
    c.r[11] += c.r[14];  // 0604E518 add r14,r11
    st32(c.r[11], c.r[13]);  // 0604E51A mov.l r13,@r11
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E53Au);  // 0604E51C mov.w 0x0604E53A,r13
    c.r[13] += c.r[14];  // 0604E51E add r14,r13
    st32(c.r[13], c.r[0]); goto L_0604E55E;  // 0604E520 bra 0x0604E55E ; mov.l r0,@r13
L_0604E540:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E5A4u);  // 0604E540 mov.w 0x0604E5A4,r11
    c.r[11] += c.r[14];  // 0604E542 add r14,r11
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0604E544 mov.b @r11,r7
    c.r[1] = 0x20u;  // 0604E546 mov #32,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0604E548 extu.b r7,r2
    c.t = c.r[2] > c.r[1];  // 0604E54A cmp/hi r1,r2
    if (!c.t) { goto L_0604E550; }  // 0604E54C bf 0x0604E550
    c.r[7] = 0x20u;  // 0604E54E mov #32,r7
L_0604E550:
    c.r[7] = c.r[7] & 0xFFu;  // 0604E550 extu.b r7,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E5A6u);  // 0604E552 mov.w 0x0604E5A6,r13
    c.r[13] += c.r[14];  // 0604E554 add r14,r13
    st32(c.r[13], c.r[7]);  // 0604E556 mov.l r7,@r13
    c.r[11] = 0x0u;  // 0604E558 mov #0,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E5A8u);  // 0604E55A mov.w 0x0604E5A8,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 0604E55C mov.l r11,@(r0,r14)
L_0604E55E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E5AAu);  // 0604E55E mov.w 0x0604E5AA,r0
    c.r[0] += c.r[14];  // 0604E560 add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E5AAu);  // 0604E562 mov.w 0x0604E5AA,r11
    c.r[0] = ld32(c.r[0]);  // 0604E564 mov.l @r0,r0
    c.r[11] += c.r[14];  // 0604E566 add r14,r11
    c.r[0] &= 0x1u;  // 0604E568 and #1,r0
    st32(c.r[11], c.r[0]);  // 0604E56A mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E5AAu);  // 0604E56C mov.w 0x0604E5AA,r11
    c.r[11] += c.r[14];  // 0604E56E add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0604E570 mov.l @r11,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 0604E572 tst r11,r11
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_0604E58E; } }  // 0604E574 bt/s 0x0604E58E ; mov r12,r2
    c.r[9] += 64;  // 0604E578 add #64,r9
    c.r[12] -= 32;  // 0604E57A add #-32,r12
    c.r[0] = 0x20u;  // 0604E57C mov #32,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E5ACu);  // 0604E57E mov.w 0x0604E5AC,r13
    c.r[13] += c.r[14];  // 0604E580 add r14,r13
    st32(c.r[13], c.r[0]);  // 0604E582 mov.l r0,@r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E5ACu);  // 0604E584 mov.w 0x0604E5AC,r11
    c.r[11] += c.r[14];  // 0604E586 add r14,r11
    c.r[13] = ld32(c.r[11]);  // 0604E588 mov.l @r11,r13
    c.r[10] = c.r[12] & 0xFFu; goto L_0604E5B6;  // 0604E58A bra 0x0604E5B6 ; extu.b r12,r10
L_0604E58E:
    c.r[1] = c.r[2] & 0xFFu;  // 0604E58E extu.b r2,r1
    c.r[3] = 0x20u;  // 0604E590 mov #32,r3
    c.t = c.r[1] > c.r[3];  // 0604E592 cmp/hi r3,r1
    if (!c.t) { goto L_0604E598; }  // 0604E594 bf 0x0604E598
    c.r[2] = 0x20u;  // 0604E596 mov #32,r2
L_0604E598:
    c.t = c.r[12] > c.r[3];  // 0604E598 cmp/hi r3,r12
    { const bool k = !c.t; c.r[10] = c.r[2] & 0xFFu; if (k) { goto L_0604E5AE; } }  // 0604E59A bf/s 0x0604E5AE ; extu.b r2,r10
    c.r[12] -= 32;  // 0604E59E add #-32,r12
    c.r[1] = c.r[12] & 0xFFu; goto L_0604E5B0;  // 0604E5A0 bra 0x0604E5B0 ; extu.b r12,r1
L_0604E5AE:
    c.r[1] = 0x0u;  // 0604E5AE mov #0,r1
L_0604E5B0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E722u);  // 0604E5B0 mov.w 0x0604E722,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 0604E5B2 mov.l r1,@(r0,r14)
    c.r[13] = 0x0u;  // 0604E5B4 mov #0,r13
L_0604E5B6:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E724u);  // 0604E5B6 mov.w 0x0604E724,r11
    c.r[11] += c.r[14];  // 0604E5B8 add r14,r11
    st32(c.r[11], c.r[13]);  // 0604E5BA mov.l r13,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E726u);  // 0604E5BC mov.w 0x0604E726,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0604E5BE mov.l @(r0,r14),r0
    c.r[6] = 0x0u;  // 0604E5C0 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[0];  // 0604E5C2 cmp/ge r0,r6
    if (!c.t) { goto L_0604E5CA; }  // 0604E5C4 bf 0x0604E5CA
    goto L_0604E6CA;  // 0604E5C6 bra 0x0604E6CA ; nop
L_0604E5CA:
    c.r[12] = (uint32_t)(int16_t)ld16(0x0604E728u);  // 0604E5CA mov.w 0x0604E728,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E72Au);  // 0604E5CC mov.w 0x0604E72A,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E72Cu);  // 0604E5CE mov.w 0x0604E72C,r11
    c.r[11] += c.r[14];  // 0604E5D0 add r14,r11
    st32(c.r[11], c.r[13]);  // 0604E5D2 mov.l r13,@r11
L_0604E5D4:
    c.r[5] = 0x0u;  // 0604E5D4 mov #0,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[10];  // 0604E5D6 cmp/ge r10,r5
    if (c.t) { goto L_0604E6A6; }  // 0604E5D8 bt 0x0604E6A6
    c.r[4] = c.r[8];  // 0604E5DA mov r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E72Eu);  // 0604E5DC mov.w 0x0604E72E,r0
    c.r[11] = ld32(c.r[0] + c.r[14]);  // 0604E5DE mov.l @(r0,r14),r11
    c.r[11] += c.r[6];  // 0604E5E0 add r6,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E730u);  // 0604E5E2 mov.w 0x0604E730,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 0604E5E4 mov.l r11,@(r0,r14)
    c.r[4] += 2;  // 0604E5E6 add #2,r4
L_0604E5E8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E732u);  // 0604E5E8 mov.w 0x0604E732,r1
    c.r[3] = c.r[1];  // 0604E5EA mov r1,r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E730u);  // 0604E5EC mov.w 0x0604E730,r13
    c.r[13] += c.r[14];  // 0604E5EE add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604E734u);  // 0604E5F0 mov.w 0x0604E734,r0
    c.r[0] += c.r[14];  // 0604E5F2 add r14,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604E5F4 mov.w @r9,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E724u);  // 0604E5F6 mov.w 0x0604E724,r11
    c.r[7] = ld32(c.r[13]);  // 0604E5F8 mov.l @r13,r7
    c.r[11] += c.r[14];  // 0604E5FA add r14,r11
    c.r[0] = ld32(c.r[0]);  // 0604E5FC mov.l @r0,r0
    c.r[3] &= c.r[2];  // 0604E5FE and r2,r3
    c.r[7] <<= 2;  // 0604E600 shll2 r7
    c.r[7] <<= 2;  // 0604E602 shll2 r7
    c.r[7] <<= 2;  // 0604E604 shll2 r7
    c.r[7] += c.r[0];  // 0604E606 add r0,r7
    c.r[2] = ld32(c.r[11]);  // 0604E608 mov.l @r11,r2
    c.r[0] = c.r[3];  // 0604E60A mov r3,r0
    c.r[2] += c.r[5];  // 0604E60C add r5,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E736u);  // 0604E60E mov.w 0x0604E736,r11
    c.r[11] += c.r[14];  // 0604E610 add r14,r11
    c.r[13] = ld32(c.r[11]);  // 0604E612 mov.l @r11,r13
    c.r[5] += 1;  // 0604E614 add #1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0604E616 mov.b @(r0,r13),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E738u);  // 0604E618 mov.w 0x0604E738,r11
    c.r[0] = c.r[7];  // 0604E61A mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0604E61C mov.b r1,@(r0,r2)
    c.r[7] = c.r[3];  // 0604E61E mov r3,r7
    c.r[7] <<= 2;  // 0604E620 shll2 r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604E73Au);  // 0604E622 mov.w 0x0604E73A,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]); c.r[9] += 2;  // 0604E624 mov.w @r9+,r1
    c.r[0] = c.r[14];  // 0604E626 mov r14,r0
    c.r[2] &= c.r[1];  // 0604E628 and r1,r2
    c.r[3] = c.r[2];  // 0604E62A mov r2,r3
    c.r[3] >>= 8;  // 0604E62C shlr8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0604E62E mov.b @(r0,r3),r1
    c.r[11] += c.r[14];  // 0604E630 add r14,r11
    c.r[13] = ld32(c.r[11]);  // 0604E632 mov.l @r11,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0604E634 extu.b r1,r1
    c.r[1] += c.r[7];  // 0604E636 add r7,r1
    c.r[1] += c.r[1];  // 0604E638 add r1,r1
    c.r[0] = c.r[1];  // 0604E63A mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604E63C mov.w @(r0,r13),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E738u);  // 0604E63E mov.w 0x0604E738,r11
    c.r[1] |= c.r[2];  // 0604E640 or r2,r1
    st16(c.r[8], c.r[1]);  // 0604E642 mov.w r1,@r8
    c.r[1] = c.r[14];  // 0604E644 mov r14,r1
    c.r[1] += 1;  // 0604E646 add #1,r1
    c.r[0] = c.r[1];  // 0604E648 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0604E64A mov.b @(r0,r3),r1
    c.r[11] += c.r[14];  // 0604E64C add r14,r11
    c.r[13] = ld32(c.r[11]);  // 0604E64E mov.l @r11,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0604E650 extu.b r1,r1
    c.r[1] += c.r[7];  // 0604E652 add r7,r1
    c.r[1] += c.r[1];  // 0604E654 add r1,r1
    c.r[0] = c.r[1];  // 0604E656 mov r1,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E738u);  // 0604E658 mov.w 0x0604E738,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604E65A mov.w @(r0,r13),r1
    c.r[11] += c.r[14];  // 0604E65C add r14,r11
    c.r[1] |= c.r[2];  // 0604E65E or r2,r1
    st16(c.r[4], c.r[1]);  // 0604E660 mov.w r1,@r4
    c.r[1] = c.r[14];  // 0604E662 mov r14,r1
    c.r[1] += 2;  // 0604E664 add #2,r1
    c.r[0] = c.r[1];  // 0604E666 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0604E668 mov.b @(r0,r3),r1
    c.r[4] += 4;  // 0604E66A add #4,r4
    c.r[13] = ld32(c.r[11]);  // 0604E66C mov.l @r11,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0604E66E extu.b r1,r1
    c.r[1] += c.r[7];  // 0604E670 add r7,r1
    c.r[1] += c.r[1];  // 0604E672 add r1,r1
    c.r[0] = c.r[1];  // 0604E674 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604E676 mov.w @(r0,r13),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E738u);  // 0604E678 mov.w 0x0604E738,r11
    c.r[1] |= c.r[2];  // 0604E67A or r2,r1
    c.r[0] = c.r[8];  // 0604E67C mov r8,r0
    st16(c.r[0] + c.r[12], c.r[1]);  // 0604E67E mov.w r1,@(r0,r12)
    c.r[1] = c.r[14];  // 0604E680 mov r14,r1
    c.r[1] += 3;  // 0604E682 add #3,r1
    c.r[0] = c.r[1];  // 0604E684 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0604E686 mov.b @(r0,r3),r1
    c.r[11] += c.r[14];  // 0604E688 add r14,r11
    c.r[13] = ld32(c.r[11]);  // 0604E68A mov.l @r11,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0604E68C extu.b r1,r1
    c.r[7] += c.r[1];  // 0604E68E add r1,r7
    c.r[7] += c.r[7];  // 0604E690 add r7,r7
    c.r[0] = c.r[7];  // 0604E692 mov r7,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E72Cu);  // 0604E694 mov.w 0x0604E72C,r11
    c.r[11] += c.r[14];  // 0604E696 add r14,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604E698 mov.w @(r0,r13),r1
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[10];  // 0604E69A cmp/ge r10,r5
    c.r[0] = ld32(c.r[11]);  // 0604E69C mov.l @r11,r0
    c.r[2] |= c.r[1];  // 0604E69E or r1,r2
    st16(c.r[0] + c.r[8], c.r[2]);  // 0604E6A0 mov.w r2,@(r0,r8)
    { const bool k = !c.t; c.r[8] += 4; if (k) { SH2_POLL(c); goto L_0604E5E8; } }  // 0604E6A2 bf/s 0x0604E5E8 ; add #4,r8
L_0604E6A6:
    c.r[6] += 1;  // 0604E6A6 add #1,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E722u);  // 0604E6A8 mov.w 0x0604E722,r13
    c.r[13] += c.r[14];  // 0604E6AA add r14,r13
    c.r[0] = c.r[12];  // 0604E6AC mov r12,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E726u);  // 0604E6AE mov.w 0x0604E726,r11
    c.r[1] = ld32(c.r[13]);  // 0604E6B0 mov.l @r13,r1
    c.r[11] += c.r[14];  // 0604E6B2 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0604E6B4 mov.l @r11,r11
    c.r[1] += c.r[1];  // 0604E6B6 add r1,r1
    c.r[9] += c.r[1];  // 0604E6B8 add r1,r9
    c.r[1] = c.r[10];  // 0604E6BA mov r10,r1
    c.r[1] += c.r[1];  // 0604E6BC add r1,r1
    c.r[0] -= c.r[1];  // 0604E6BE sub r1,r0
    c.r[1] = c.r[0];  // 0604E6C0 mov r0,r1
    c.r[1] += c.r[1];  // 0604E6C2 add r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[11];  // 0604E6C4 cmp/ge r11,r6
    { const bool k = !c.t; c.r[8] += c.r[1]; if (k) { SH2_POLL(c); goto L_0604E5D4; } }  // 0604E6C6 bf/s 0x0604E5D4 ; add r1,r8
L_0604E6CA:
    c.r[8] = ld32(0x0604E744u);  // 0604E6CA mov.l 0x0604E744,r8
    c.r[1] = 0x1u;  // 0604E6CC mov #1,r1
    st8(c.r[8], c.r[1]);  // 0604E6CE mov.b r1,@r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604E73Cu);  // 0604E6D0 mov.w 0x0604E73C,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E73Eu);  // 0604E6D2 mov.w 0x0604E73E,r13
    c.r[13] += c.r[14];  // 0604E6D4 add r14,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E740u);  // 0604E6D6 mov.w 0x0604E740,r11
    c.r[11] += c.r[14];  // 0604E6D8 add r14,r11
    c.r[0] = ld32(c.r[13]);  // 0604E6DA mov.l @r13,r0
    c.r[4] = c.r[14];  // 0604E6DC mov r14,r4
    c.r[0] += c.r[0];  // 0604E6DE add r0,r0
    st32(c.r[13], c.r[0]);  // 0604E6E0 mov.l r0,@r13
    c.r[13] = ld32(c.r[11]);  // 0604E6E2 mov.l @r11,r13
    c.r[4] += 16;  // 0604E6E4 add #16,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E73Eu);  // 0604E6E6 mov.w 0x0604E73E,r11
    c.r[11] += c.r[14];  // 0604E6E8 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0604E6EA mov.l @r11,r11
    c.r[1] = ld32(0x0604E748u);  // 0604E6EC mov.l 0x0604E748,r1
    c.r[13] += c.r[11];  // 0604E6EE add r11,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604E740u);  // 0604E6F0 mov.w 0x0604E740,r11
    c.r[11] += c.r[14];  // 0604E6F2 add r14,r11
    st32(c.r[11], c.r[13]);  // 0604E6F4 mov.l r13,@r11
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604E740u);  // 0604E6F6 mov.w 0x0604E740,r13
    c.r[13] += c.r[14];  // 0604E6F8 add r14,r13
    c.r[5] = ld32(c.r[13]);  // 0604E6FA mov.l @r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604E700u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E700u) return; }  // 0604E6FC jsr @r1 ; mov #14,r7
    c.r[1] = ld32(0x0604E74Cu);  // 0604E700 mov.l 0x0604E74C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E706u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E706u) return; }  // 0604E702 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0604E706 mov #0,r1
    st8(c.r[8], c.r[1]);  // 0604E708 mov.b r1,@r8
L_0604E70A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604E742u);  // 0604E70A mov.w 0x0604E742,r3
    c.r[14] += c.r[3];  // 0604E70C add r3,r14
    c.r[15] = c.r[14];  // 0604E70E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E710 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604E712 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604E714 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604E716 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604E718 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604E71A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604E71C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E71E rts ; mov.l @r15+,r8
}

void f_0604E750(SH2Context& c) {
    ran[1254] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604E750 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E752 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E754 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E756 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604E758 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604E75A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E75C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E75E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604E760 mov r15,r14
    c.r[11] = 0x0u;  // 0604E762 mov #0,r11
    c.r[10] = 0x0u;  // 0604E764 mov #0,r10
    c.r[13] = ld32(0x0604E84Cu);  // 0604E766 mov.l 0x0604E84C,r13
    c.r[12] = ld32(0x0604E850u);  // 0604E768 mov.l 0x0604E850,r12
L_0604E76A:
    c.r[0] = ld32(0x0604E854u);  // 0604E76A mov.l 0x0604E854,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0604E76C mov.b @(r0,r10),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0604E76E extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E844u);  // 0604E770 mov.w 0x0604E844,r1
    c.t = c.r[2] == c.r[1];  // 0604E772 cmp/eq r1,r2
    { const bool k = c.t; c.r[7] = c.r[2]; if (k) { goto L_0604E826; } }  // 0604E774 bt/s 0x0604E826 ; mov r2,r7
    c.r[7] += c.r[7];  // 0604E778 add r7,r7
    c.r[7] += c.r[2];  // 0604E77A add r2,r7
    c.r[7] <<= 2;  // 0604E77C shll2 r7
    c.r[9] = c.r[7];  // 0604E77E mov r7,r9
    c.r[9] += c.r[13];  // 0604E780 add r13,r9
    c.r[1] = c.r[9];  // 0604E782 mov r9,r1
    c.r[1] += 10;  // 0604E784 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E786 mov.b @r1,r2
    c.r[0] = ld32(0x0604E858u);  // 0604E788 mov.l 0x0604E858,r0
    c.r[3] = ld32(c.r[0]);  // 0604E78A mov.l @r0,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0604E78C extu.b r2,r2
    c.r[4] = c.r[3];  // 0604E78E mov r3,r4
    c.r[1] = ld32(0x0604E85Cu);  // 0604E790 mov.l 0x0604E85C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E796u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E796u) return; }  // 0604E792 jsr @r1 ; mov r2,r5
    c.r[1] = c.r[0];  // 0604E796 mov r0,r1
    c.macl = c.r[1] * c.r[2];  // 0604E798 mul.l r2,r1
    c.r[1] = c.macl;  // 0604E79A sts macl,r1
    c.r[3] -= c.r[1];  // 0604E79C sub r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0604E79E tst r3,r3
    if (c.t) { goto L_0604E7B2; }  // 0604E7A0 bt 0x0604E7B2
    c.r[0] = ld32(0x0604E860u);  // 0604E7A2 mov.l 0x0604E860,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604E7A4 mov.b @r0,r1
    c.r[1] >>= 2;  // 0604E7A6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604E7A8 shlr r1
    c.r[0] = 0x1u;  // 0604E7AA mov #1,r0
    c.r[1] &= c.r[0];  // 0604E7AC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E7AE tst r1,r1
    if (c.t) { goto L_0604E81E; }  // 0604E7B0 bt 0x0604E81E
L_0604E7B2:
    c.r[1] = ld32(0x0604E864u);  // 0604E7B2 mov.l 0x0604E864,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E7B4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604E7B6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E7B8 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0604E81E; } }  // 0604E7BA bf/s 0x0604E81E ; mov r9,r1
    c.r[1] += 4;  // 0604E7BE add #4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604E846u);  // 0604E7C0 mov.w 0x0604E846,r2
    c.r[0] = c.r[12];  // 0604E7C2 mov r12,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604E848u);  // 0604E7C4 mov.w 0x0604E848,r4
    c.r[8] = c.r[9];  // 0604E7C6 mov r9,r8
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604E7C8 mov.w @r1,r3
    c.r[8] += 8;  // 0604E7CA add #8,r8
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0604E7CC mov.l @(r0,r2),r5
    c.r[6] = c.r[3] & 0xFFFFu;  // 0604E7CE extu.w r3,r6
    c.r[6] <<= 2;  // 0604E7D0 shll2 r6
    c.r[6] += c.r[6];  // 0604E7D2 add r6,r6
    c.r[6] <<= 2;  // 0604E7D4 shll2 r6
    c.r[1] = c.r[9];  // 0604E7D6 mov r9,r1
    c.r[1] += 2;  // 0604E7D8 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604E7DA mov.w @r1,r1
    c.r[0] = c.r[13];  // 0604E7DC mov r13,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0604E7DE mov.w @(r0,r7),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604E7E0 extu.w r1,r1
    c.r[1] <<= 2;  // 0604E7E2 shll2 r1
    c.r[1] += c.r[1];  // 0604E7E4 add r1,r1
    c.r[1] <<= 2;  // 0604E7E6 shll2 r1
    c.r[5] += c.r[1];  // 0604E7E8 add r1,r5
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604E7EA extu.w r2,r2
    c.r[0] = c.r[12];  // 0604E7EC mov r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604E7EE mov.w @r8,r1
    c.r[7] = 0xEu;  // 0604E7F0 mov #14,r7
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[3] & 0xFFFFu);  // 0604E7F2 mulu.w r3,r1
    c.r[4] = ld32(c.r[0] + c.r[4]);  // 0604E7F4 mov.l @(r0,r4),r4
    c.r[1] = c.macl;  // 0604E7F6 sts macl,r1
    c.r[2] += c.r[1];  // 0604E7F8 add r1,r2
    c.r[2] <<= 2;  // 0604E7FA shll2 r2
    c.r[2] += c.r[2];  // 0604E7FC add r2,r2
    c.r[2] <<= 2;  // 0604E7FE shll2 r2
    c.r[1] = ld32(0x0604E868u);  // 0604E800 mov.l 0x0604E868,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E806u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E806u) return; }  // 0604E802 jsr @r1 ; add r2,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604E806 mov.w @r8,r2
    c.r[9] += 6;  // 0604E808 add #6,r9
    c.r[2] += 1;  // 0604E80A add #1,r2
    st16(c.r[8], c.r[2]);  // 0604E80C mov.w r2,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604E80E mov.w @r9,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604E810 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604E812 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0604E814 cmp/eq r1,r2
    { const bool k = !c.t; c.r[11] += 1; if (k) { goto L_0604E81E; } }  // 0604E816 bf/s 0x0604E81E ; add #1,r11
    c.r[1] = 0x0u;  // 0604E81A mov #0,r1
    st16(c.r[8], c.r[1]);  // 0604E81C mov.w r1,@r8
L_0604E81E:
    c.r[10] += 1;  // 0604E81E add #1,r10
    c.r[1] = 0xFu;  // 0604E820 mov #15,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0604E822 cmp/gt r1,r10
    if (!c.t) { SH2_POLL(c); goto L_0604E76A; }  // 0604E824 bf 0x0604E76A
L_0604E826:
    c.t = (c.r[11] & c.r[11]) == 0;  // 0604E826 tst r11,r11
    if (c.t) { goto L_0604E830; }  // 0604E828 bt 0x0604E830
    c.r[1] = ld32(0x0604E86Cu);  // 0604E82A mov.l 0x0604E86C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E830u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E830u) return; }  // 0604E82C jsr @r1 ; nop
L_0604E830:
    c.r[15] = c.r[14];  // 0604E830 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E832 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604E834 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604E836 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604E838 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604E83A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604E83C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604E83E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E840 rts ; mov.l @r15+,r8
}

void f_0604E870(SH2Context& c) {
    ran[1255] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E870 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E872 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604E874 mov r15,r14
    c.r[1] = ld32(0x0604E884u);  // 0604E876 mov.l 0x0604E884,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E87Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E87Cu) return; }  // 0604E878 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0604E87C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604E87E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604E880 rts ; mov.l @r15+,r14
}

void f_0604E888(SH2Context& c) {
    ran[1256] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604E888 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604E88A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604E88C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604E88E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604E890 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604E892 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604E894 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604E896 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604E9C0u);  // 0604E898 mov.w 0x0604E9C0,r3
    c.r[15] += c.r[3];  // 0604E89A add r3,r15
    c.r[14] = c.r[15];  // 0604E89C mov r15,r14
    c.r[11] = 0x0u;  // 0604E89E mov #0,r11
    c.r[13] = ld32(0x0604E9C8u);  // 0604E8A0 mov.l 0x0604E9C8,r13
    c.r[10] = ld32(0x0604E9CCu);  // 0604E8A2 mov.l 0x0604E9CC,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x0604E9C2u);  // 0604E8A4 mov.w 0x0604E9C2,r12
L_0604E8A6:
    c.r[0] = ld32(0x0604E9D0u);  // 0604E8A6 mov.l 0x0604E9D0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0604E8A8 mov.b @(r0,r11),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0604E8AA extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E9C4u);  // 0604E8AC mov.w 0x0604E9C4,r1
    c.t = c.r[8] == c.r[1];  // 0604E8AE cmp/eq r1,r8
    { const bool k = !c.t; c.r[7] = c.r[8]; if (k) { goto L_0604E8B8; } }  // 0604E8B0 bf/s 0x0604E8B8 ; mov r8,r7
    goto L_0604EA62;  // 0604E8B4 bra 0x0604EA62 ; nop
L_0604E8B8:
    c.r[7] += c.r[7];  // 0604E8B8 add r7,r7
    c.r[7] += c.r[8];  // 0604E8BA add r8,r7
    c.r[7] <<= 2;  // 0604E8BC shll2 r7
    c.r[9] = c.r[7];  // 0604E8BE mov r7,r9
    c.r[9] += c.r[10];  // 0604E8C0 add r10,r9
    c.r[1] = c.r[9];  // 0604E8C2 mov r9,r1
    c.r[1] += 10;  // 0604E8C4 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604E8C6 mov.b @r1,r2
    c.r[3] = ld32(c.r[13]);  // 0604E8C8 mov.l @r13,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0604E8CA extu.b r2,r2
    c.r[4] = c.r[3];  // 0604E8CC mov r3,r4
    c.r[1] = ld32(0x0604E9D4u);  // 0604E8CE mov.l 0x0604E9D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604E8D4u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604E8D4u) return; }  // 0604E8D0 jsr @r1 ; mov r2,r5
    c.macl = c.r[0] * c.r[2];  // 0604E8D4 mul.l r2,r0
    c.r[1] = c.macl;  // 0604E8D6 sts macl,r1
    c.r[3] -= c.r[1];  // 0604E8D8 sub r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0604E8DA tst r3,r3
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0604E8E4; } }  // 0604E8DC bt/s 0x0604E8E4 ; mov r10,r0
    goto L_0604EA56;  // 0604E8E0 bra 0x0604EA56 ; nop
L_0604E8E4:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0604E8E4 mov.w @(r0,r7),r2
    c.r[1] = ld32(0x0604E9D8u);  // 0604E8E6 mov.l 0x0604E9D8,r1
    c.r[1] &= c.r[2];  // 0604E8E8 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E8EA tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[8]; if (k) { goto L_0604E98E; } }  // 0604E8EC bt/s 0x0604E98E ; mov r8,r3
    c.r[6] = c.r[12];  // 0604E8F0 mov r12,r6
    c.r[6] &= c.r[2];  // 0604E8F2 and r2,r6
    c.r[6] += c.r[6];  // 0604E8F4 add r6,r6
    c.r[1] = ld32(0x0604E9DCu);  // 0604E8F6 mov.l 0x0604E9DC,r1
    c.r[6] += c.r[1];  // 0604E8F8 add r1,r6
    c.r[2] = c.r[9];  // 0604E8FA mov r9,r2
    c.r[2] += 4;  // 0604E8FC add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604E8FE mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0604E900 cmp/pz r1
    { const bool k = !c.t; c.r[7] = c.r[6]; if (k) { goto L_0604E90A; } }  // 0604E902 bf/s 0x0604E90A ; mov r6,r7
    goto L_0604EA56;  // 0604E906 bra 0x0604EA56 ; nop
L_0604E90A:
    c.r[3] = 0x0u;  // 0604E90A mov #0,r3
    c.r[4] = c.r[9];  // 0604E90C mov r9,r4
    c.r[5] = c.r[2];  // 0604E90E mov r2,r5
    c.r[9] = 0x0u;  // 0604E910 mov #0,r9
L_0604E912:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0604E912 mov.w @r5,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0604E914 cmp/pz r1
    if (c.t) { goto L_0604E91A; }  // 0604E916 bt 0x0604E91A
    c.r[1] = 0u - c.r[1];  // 0604E918 neg r1,r1
L_0604E91A:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0604E91A cmp/ge r1,r3
    if (c.t) { goto L_0604E92A; }  // 0604E91C bt 0x0604E92A
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 0604E91E mov.w @r7+,r1
    c.r[0] = c.r[9];  // 0604E920 mov r9,r0
    c.r[9] += 2;  // 0604E922 add #2,r9
    c.r[3] += 1;  // 0604E924 add #1,r3
    st16(c.r[0] + c.r[14], c.r[1]); SH2_POLL(c); goto L_0604E912;  // 0604E926 bra 0x0604E912 ; mov.w r1,@(r0,r14)
L_0604E92A:
    c.r[4] += 6;  // 0604E92A add #6,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604E92C mov.w @r4,r2
    c.r[3] = 0x0u;  // 0604E92E mov #0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0604E930 mov.w @r5,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604E932 extu.w r2,r2
    c.r[2] += c.r[1];  // 0604E934 add r1,r2
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[2];  // 0604E936 cmp/ge r2,r3
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0604E968; } }  // 0604E938 bt/s 0x0604E968 ; mov r8,r2
    c.r[1] = ld32(0x0604E9CCu);  // 0604E93C mov.l 0x0604E9CC,r1
    c.r[5] = c.r[8];  // 0604E93E mov r8,r5
    c.r[5] += c.r[5];  // 0604E940 add r5,r5
    c.r[5] += c.r[8];  // 0604E942 add r8,r5
    c.r[5] <<= 2;  // 0604E944 shll2 r5
    c.r[5] += c.r[1];  // 0604E946 add r1,r5
    c.r[4] = c.r[5];  // 0604E948 mov r5,r4
    c.r[4] += 4;  // 0604E94A add #4,r4
L_0604E94C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 0604E94C mov.w @r7+,r1
    c.r[3] += 1;  // 0604E94E add #1,r3
    st16(c.r[6], c.r[1]);  // 0604E950 mov.w r1,@r6
    c.r[1] = c.r[5];  // 0604E952 mov r5,r1
    c.r[1] += 6;  // 0604E954 add #6,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604E956 mov.w @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604E958 mov.w @r4,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604E95A extu.w r2,r2
    c.r[2] += c.r[1];  // 0604E95C add r1,r2
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[2];  // 0604E95E cmp/ge r2,r3
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_0604E94C; } }  // 0604E960 bf/s 0x0604E94C ; add #2,r6
    c.r[3] = 0x0u;  // 0604E964 mov #0,r3
    c.r[2] = c.r[8];  // 0604E966 mov r8,r2
L_0604E968:
    c.r[2] += c.r[2];  // 0604E968 add r2,r2
    c.r[2] += c.r[8];  // 0604E96A add r8,r2
    c.r[2] <<= 2;  // 0604E96C shll2 r2
    c.r[2] += c.r[10];  // 0604E96E add r10,r2
    c.r[2] += 4;  // 0604E970 add #4,r2
    c.r[7] = 0x0u;  // 0604E972 mov #0,r7
L_0604E974:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604E974 mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0604E976 cmp/pz r1
    if (c.t) { goto L_0604E97C; }  // 0604E978 bt 0x0604E97C
    c.r[1] = 0u - c.r[1];  // 0604E97A neg r1,r1
L_0604E97C:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0604E97C cmp/ge r1,r3
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_0604EA56; } }  // 0604E97E bt/s 0x0604EA56 ; mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0604E982 mov.w @(r0,r14),r1
    c.r[7] += 2;  // 0604E984 add #2,r7
    c.r[3] += 1;  // 0604E986 add #1,r3
    st16(c.r[6], c.r[1]);  // 0604E988 mov.w r1,@r6
    c.r[6] += 2; SH2_POLL(c); goto L_0604E974;  // 0604E98A bra 0x0604E974 ; add #2,r6
L_0604E98E:
    c.r[3] += c.r[3];  // 0604E98E add r3,r3
    c.r[3] += c.r[8];  // 0604E990 add r8,r3
    c.r[3] <<= 2;  // 0604E992 shll2 r3
    c.r[0] = c.r[10];  // 0604E994 mov r10,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0604E996 mov.w @(r0,r3),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604E9C6u);  // 0604E998 mov.w 0x0604E9C6,r1
    c.r[1] &= c.r[2];  // 0604E99A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604E99C tst r1,r1
    { const bool k = c.t; c.r[7] = c.r[12]; if (k) { goto L_0604E9E0; } }  // 0604E99E bt/s 0x0604E9E0 ; mov r12,r7
    c.r[7] &= c.r[2];  // 0604E9A2 and r2,r7
    c.r[2] = c.r[3];  // 0604E9A4 mov r3,r2
    c.r[2] += c.r[10];  // 0604E9A6 add r10,r2
    c.r[1] = c.r[2];  // 0604E9A8 mov r2,r1
    c.r[1] += 4;  // 0604E9AA add #4,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604E9AC mov.w @r1,r3
    c.r[2] += 8;  // 0604E9AE add #8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604E9B0 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604E9B2 extu.w r1,r1
    c.macl = c.r[3] * c.r[1];  // 0604E9B4 mul.l r1,r3
    c.r[7] += c.r[7];  // 0604E9B6 add r7,r7
    c.r[2] = c.macl;  // 0604E9B8 sts macl,r2
    c.r[1] = ld32(0x0604E9DCu);  // 0604E9BA mov.l 0x0604E9DC,r1
    c.r[2] += c.r[2]; goto L_0604E9FC;  // 0604E9BC bra 0x0604E9FC ; add r2,r2
L_0604E9E0:
    c.r[7] &= c.r[2];  // 0604E9E0 and r2,r7
    c.r[2] = c.r[3];  // 0604E9E2 mov r3,r2
    c.r[2] += c.r[10];  // 0604E9E4 add r10,r2
    c.r[1] = c.r[2];  // 0604E9E6 mov r2,r1
    c.r[1] += 4;  // 0604E9E8 add #4,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604E9EA mov.w @r1,r3
    c.r[2] += 8;  // 0604E9EC add #8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604E9EE mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604E9F0 extu.w r1,r1
    c.macl = c.r[3] * c.r[1];  // 0604E9F2 mul.l r1,r3
    c.r[7] += c.r[7];  // 0604E9F4 add r7,r7
    c.r[2] = c.macl;  // 0604E9F6 sts macl,r2
    c.r[2] += c.r[2];  // 0604E9F8 add r2,r2
    c.r[1] = ld32(0x0604EA7Cu);  // 0604E9FA mov.l 0x0604EA7C,r1
L_0604E9FC:
    c.r[2] += c.r[1];  // 0604E9FC add r1,r2
    c.r[7] += c.r[2];  // 0604E9FE add r2,r7
    c.r[2] = c.r[8];  // 0604EA00 mov r8,r2
    c.r[2] += c.r[2];  // 0604EA02 add r2,r2
    c.r[2] += c.r[8];  // 0604EA04 add r8,r2
    c.r[2] <<= 2;  // 0604EA06 shll2 r2
    c.r[2] += c.r[10];  // 0604EA08 add r10,r2
    c.r[1] = c.r[2];  // 0604EA0A mov r2,r1
    c.r[1] += 2;  // 0604EA0C add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604EA0E mov.w @r1,r1
    c.r[2] += 4;  // 0604EA10 add #4,r2
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604EA12 extu.w r1,r6
    c.r[6] += c.r[6];  // 0604EA14 add r6,r6
    c.r[1] = ld32(0x0604EA80u);  // 0604EA16 mov.l 0x0604EA80,r1
    c.r[6] += c.r[1];  // 0604EA18 add r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604EA1A mov.w @r2,r1
    c.r[3] = 0x0u;  // 0604EA1C mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0604EA1E cmp/ge r1,r3
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0604EA34; } }  // 0604EA20 bt/s 0x0604EA34 ; mov r8,r1
L_0604EA24:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 0604EA24 mov.w @r7+,r1
    c.r[3] += 1;  // 0604EA26 add #1,r3
    st16(c.r[6], c.r[1]);  // 0604EA28 mov.w r1,@r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604EA2A mov.w @r2,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0604EA2C cmp/ge r1,r3
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_0604EA24; } }  // 0604EA2E bf/s 0x0604EA24 ; add #2,r6
    c.r[1] = c.r[8];  // 0604EA32 mov r8,r1
L_0604EA34:
    c.r[1] += c.r[1];  // 0604EA34 add r1,r1
    c.r[1] += c.r[8];  // 0604EA36 add r8,r1
    c.r[1] <<= 2;  // 0604EA38 shll2 r1
    c.r[1] += c.r[10];  // 0604EA3A add r10,r1
    c.r[3] = c.r[1];  // 0604EA3C mov r1,r3
    c.r[3] += 8;  // 0604EA3E add #8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604EA40 mov.w @r3,r2
    c.r[1] += 6;  // 0604EA42 add #6,r1
    c.r[2] += 1;  // 0604EA44 add #1,r2
    st16(c.r[3], c.r[2]);  // 0604EA46 mov.w r2,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604EA48 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604EA4A extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604EA4C extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0604EA4E cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0604EA56; } }  // 0604EA50 bf/s 0x0604EA56 ; mov #0,r1
    st16(c.r[3], c.r[1]);  // 0604EA54 mov.w r1,@r3
L_0604EA56:
    c.r[11] += 1;  // 0604EA56 add #1,r11
    c.r[1] = 0xFu;  // 0604EA58 mov #15,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 0604EA5A cmp/gt r1,r11
    if (c.t) { goto L_0604EA62; }  // 0604EA5C bt 0x0604EA62
    SH2_POLL(c); goto L_0604E8A6;  // 0604EA5E bra 0x0604E8A6 ; nop
L_0604EA62:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604EA7Au);  // 0604EA62 mov.w 0x0604EA7A,r3
    c.r[14] += c.r[3];  // 0604EA64 add r3,r14
    c.r[15] = c.r[14];  // 0604EA66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604EA68 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604EA6A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604EA6C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604EA6E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604EA70 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604EA72 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604EA74 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604EA76 rts ; mov.l @r15+,r8
}

void f_0604EA84(SH2Context& c) {
    ran[1257] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604EA84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604EA86 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604EA88 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604EA8A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604EA8C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604EA8E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604EA90 mov r15,r14
    c.r[2] = ld32(0x0604EB30u);  // 0604EA92 mov.l 0x0604EB30,r2
    c.r[1] = c.r[2];  // 0604EA94 mov r2,r1
    c.r[1] += 88;  // 0604EA96 add #88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604EA98 mov.w @r1,r1
    c.r[8] = 0x0u;  // 0604EA9A mov #0,r8
    c.r[10] = c.r[2];  // 0604EA9C mov r2,r10
    c.r[11] = ld32(0x0604EB34u);  // 0604EA9E mov.l 0x0604EB34,r11
    c.r[1] += 1;  // 0604EAA0 add #1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0604EAA2 extu.w r1,r9
    c.r[6] = c.r[8];  // 0604EAA4 mov r8,r6
L_0604EAA6:
    c.r[6] += c.r[6];  // 0604EAA6 add r6,r6
    c.r[1] = ld32(0x0604EB38u);  // 0604EAA8 mov.l 0x0604EB38,r1
    c.r[6] += c.r[1];  // 0604EAAA add r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604EAAC mov.w @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604EB28u);  // 0604EAAE mov.w 0x0604EB28,r1
    c.r[1] &= c.r[2];  // 0604EAB0 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604EAB2 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0604EABA; } }  // 0604EAB4 bt/s 0x0604EABA ; mov #0,r0
    c.r[0] = 0x22u;  // 0604EAB8 mov #34,r0
L_0604EABA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604EB2Au);  // 0604EABA mov.w 0x0604EB2A,r1
    c.r[1] &= c.r[2];  // 0604EABC and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604EABE tst r1,r1
    if (c.t) { goto L_0604EAC4; }  // 0604EAC0 bt 0x0604EAC4
    c.r[0] |= 0x12u;  // 0604EAC2 or #18,r0
L_0604EAC4:
    c.r[3] = c.r[9];  // 0604EAC4 mov r9,r3
    c.r[3] += c.r[8];  // 0604EAC6 add r8,r3
    c.r[7] = c.r[3];  // 0604EAC8 mov r3,r7
    c.r[7] <<= 2;  // 0604EACA shll2 r7
    c.r[7] += c.r[3];  // 0604EACC add r3,r7
    c.r[7] += c.r[7];  // 0604EACE add r7,r7
    c.r[1] = ld32(c.r[10] + 8);  // 0604EAD0 mov.l @(8,r10),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604EB2Cu);  // 0604EAD2 mov.w 0x0604EB2C,r2
    c.r[7] += c.r[1];  // 0604EAD4 add r1,r7
    c.r[7] += 8;  // 0604EAD6 add #8,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604EAD8 mov.w @r7,r1
    c.r[5] = c.r[3] & 0xFFFFu;  // 0604EADA extu.w r3,r5
    c.r[1] &= c.r[2];  // 0604EADC and r2,r1
    c.r[0] |= c.r[1];  // 0604EADE or r1,r0
    st16(c.r[7], c.r[0]);  // 0604EAE0 mov.w r0,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604EAE2 mov.w @r6,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604EB2Eu);  // 0604EAE4 mov.w 0x0604EB2E,r7
    c.r[4] = ld32(c.r[10] + 4);  // 0604EAE6 mov.l @(4,r10),r4
    c.r[7] &= c.r[1];  // 0604EAE8 and r1,r7
    c.r[7] <<= 2;  // 0604EAEA shll2 r7
    c.r[7] += c.r[7];  // 0604EAEC add r7,r7
    c.r[7] <<= 2;  // 0604EAEE shll2 r7
    c.r[1] = ld32(0x0604EB3Cu);  // 0604EAF0 mov.l 0x0604EB3C,r1
    c.r[7] += c.r[1];  // 0604EAF2 add r1,r7
    c.r[3] <<= 2;  // 0604EAF4 shll2 r3
    c.r[3] += c.r[3];  // 0604EAF6 add r3,r3
    c.r[4] += c.r[3];  // 0604EAF8 add r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0604EAFEu; c.r[6] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EAFEu) return; }  // 0604EAFA jsr @r11 ; mov #3,r6
    c.r[8] += 1;  // 0604EAFE add #1,r8
    c.r[1] = 0x23u;  // 0604EB00 mov #35,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0604EB02 cmp/gt r1,r8
    { const bool k = !c.t; c.r[6] = c.r[8]; if (k) { SH2_POLL(c); goto L_0604EAA6; } }  // 0604EB04 bf/s 0x0604EAA6 ; mov r8,r6
    c.r[1] = ld32(0x0604EB30u);  // 0604EB08 mov.l 0x0604EB30,r1
    c.r[9] <<= 2;  // 0604EB0A shll2 r9
    c.r[9] += c.r[9];  // 0604EB0C add r9,r9
    c.r[4] = ld32(c.r[1] + 4);  // 0604EB0E mov.l @(4,r1),r4
    c.r[5] = 0x24u;  // 0604EB10 mov #36,r5
    c.r[1] = ld32(0x0604EB40u);  // 0604EB12 mov.l 0x0604EB40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604EB18u; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EB18u) return; }  // 0604EB14 jsr @r1 ; add r9,r4
    c.r[15] = c.r[14];  // 0604EB18 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604EB1A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB1C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB1E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB20 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB22 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604EB24 rts ; mov.l @r15+,r8
}

void f_0604EB44(SH2Context& c) {
    ran[1258] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604EB44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604EB46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604EB48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604EB4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604EB4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604EB4E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604EB50 mov r15,r14
    c.r[2] = ld32(0x0604EB9Cu);  // 0604EB52 mov.l 0x0604EB9C,r2
    c.r[1] = c.r[2];  // 0604EB54 mov r2,r1
    c.r[1] += 88;  // 0604EB56 add #88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604EB58 mov.w @r1,r1
    c.r[8] = 0x0u;  // 0604EB5A mov #0,r8
    c.r[9] = c.r[2];  // 0604EB5C mov r2,r9
    c.r[11] = ld32(0x0604EBA0u);  // 0604EB5E mov.l 0x0604EBA0,r11
    c.r[1] += 1;  // 0604EB60 add #1,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 0604EB62 extu.w r1,r10
    c.r[1] = c.r[10];  // 0604EB64 mov r10,r1
L_0604EB66:
    c.r[1] += c.r[8];  // 0604EB66 add r8,r1
    c.r[2] = c.r[1];  // 0604EB68 mov r1,r2
    c.r[2] <<= 2;  // 0604EB6A shll2 r2
    c.r[2] += c.r[1];  // 0604EB6C add r1,r2
    c.r[5] = ld32(c.r[9] + 8);  // 0604EB6E mov.l @(8,r9),r5
    c.r[2] += c.r[2];  // 0604EB70 add r2,r2
    c.r[4] = ld32(c.r[9] + 12);  // 0604EB72 mov.l @(12,r9),r4
    c.r[5] += c.r[2];  // 0604EB74 add r2,r5
    c.r[2] = c.r[1];  // 0604EB76 mov r1,r2
    c.r[2] += c.r[2];  // 0604EB78 add r2,r2
    c.r[2] += c.r[1];  // 0604EB7A add r1,r2
    c.r[2] <<= 2;  // 0604EB7C shll2 r2
    { const uint32_t x = c.r[11]; c.pr = 0x0604EB82u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EB82u) return; }  // 0604EB7E jsr @r11 ; add r2,r4
    c.r[8] += 1;  // 0604EB82 add #1,r8
    c.r[1] = 0x23u;  // 0604EB84 mov #35,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0604EB86 cmp/gt r1,r8
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { SH2_POLL(c); goto L_0604EB66; } }  // 0604EB88 bf/s 0x0604EB66 ; mov r10,r1
    c.r[15] = c.r[14];  // 0604EB8C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604EB8E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB90 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB92 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB94 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604EB96 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604EB98 rts ; mov.l @r15+,r8
}

void f_0604EBA4(SH2Context& c) {
    ran[1259] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604EBA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604EBA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604EBA8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604EBAA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604EBAC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604EBAE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604EBB0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604EBB2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604EC9Au);  // 0604EBB4 mov.w 0x0604EC9A,r3
    c.r[15] += c.r[3];  // 0604EBB6 add r3,r15
    c.r[14] = c.r[15];  // 0604EBB8 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0604EBBA extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0604EBBC extu.b r5,r5
    c.r[11] = c.r[6] & 0xFFu;  // 0604EBBE extu.b r6,r11
    c.r[1] = 0x3u;  // 0604EBC0 mov #3,r1
    c.r[4] -= 1;  // 0604EBC2 add #-1,r4
    c.t = c.r[4] > c.r[1];  // 0604EBC4 cmp/hi r1,r4
    { const bool k = !c.t; c.r[3] = c.r[14]; if (k) { goto L_0604EBCE; } }  // 0604EBC6 bf/s 0x0604EBCE ; mov r14,r3
    goto L_0604EEFC;  // 0604EBCA bra 0x0604EEFC ; nop
L_0604EBCE:
    c.r[1] = c.r[4];  // 0604EBCE mov r4,r1
    c.r[1] += c.r[1];  // 0604EBD0 add r1,r1
    c.r[0] = 0x0604EBDCu;  // 0604EBD2 mova 0x0604EBDC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604EBD4 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604EBD6 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604EBE4u: goto L_0604EBE4; case 0x0604ECB0u: goto L_0604ECB0; case 0x0604ED72u: goto L_0604ED72; case 0x0604EE1Eu: goto L_0604EE1E; default: sh2_call(c, x); return; } }  // 0604EBD8 jmp @r0 ; nop
L_0604EBE4:
    c.r[2] = ld32(0x0604EC9Cu);  // 0604EBE4 mov.l 0x0604EC9C,r2
    c.r[3] = c.r[2];  // 0604EBE6 mov r2,r3
    c.r[3] += 79;  // 0604EBE8 add #79,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604EBEA mov.b @r3,r1
    c.r[9] = c.r[1];  // 0604EBEC mov r1,r9
    c.r[9] -= 2;  // 0604EBEE add #-2,r9
    c.r[1] += 16;  // 0604EBF0 add #16,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604EBF2 cmp/ge r1,r9
    { const bool k = !c.t; c.r[10] = c.r[9]; if (k) { goto L_0604EBFC; } }  // 0604EBF4 bf/s 0x0604EBFC ; mov r9,r10
    goto L_0604F0FE;  // 0604EBF8 bra 0x0604F0FE ; nop
L_0604EBFC:
    c.r[13] = ld32(0x0604EC9Cu);  // 0604EBFC mov.l 0x0604EC9C,r13
    c.r[13] += 78;  // 0604EBFE add #78,r13
    c.r[12] = ld32(0x0604ECA0u);  // 0604EC00 mov.l 0x0604ECA0,r12
    c.r[10] <<= 2;  // 0604EC02 shll2 r10
    c.r[10] <<= 2;  // 0604EC04 shll2 r10
    c.r[10] <<= 2;  // 0604EC06 shll2 r10
    c.t = (int32_t)c.r[9] >= 0;  // 0604EC08 cmp/pz r9
L_0604EC0A:
    if (!c.t) { goto L_0604EC6E; }  // 0604EC0A bf 0x0604EC6E
    c.r[1] = ld32(0x0604EC9Cu);  // 0604EC0C mov.l 0x0604EC9C,r1
    c.r[1] += 77;  // 0604EC0E add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604EC10 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604EC12 extu.b r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604EC14 cmp/gt r1,r9
    if (c.t) { goto L_0604EC6E; }  // 0604EC16 bt 0x0604EC6E
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604EC18 mov.b @r13,r1
    c.r[8] = c.r[1];  // 0604EC1A mov r1,r8
    c.r[8] -= 2;  // 0604EC1C add #-2,r8
    c.t = (int32_t)c.r[8] >= 0;  // 0604EC1E cmp/pz r8
    { const bool k = !c.t; c.r[3] = c.r[10]; if (k) { goto L_0604EC6E; } }  // 0604EC20 bf/s 0x0604EC6E ; mov r10,r3
    c.r[3] += c.r[1];  // 0604EC24 add r1,r3
    c.r[2] = c.r[3];  // 0604EC26 mov r3,r2
    c.r[2] -= 2;  // 0604EC28 add #-2,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0604EC2A cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0604EC34; } }  // 0604EC2C bt/s 0x0604EC34 ; mov r2,r1
    c.r[1] = c.r[3];  // 0604EC30 mov r3,r1
    c.r[1] += 5;  // 0604EC32 add #5,r1
L_0604EC34:
    c.r[0] = c.r[1];  // 0604EC34 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EC36 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EC38 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EC3A shar r0
    c.r[1] = ld32(0x0604ECA4u);  // 0604EC3C mov.l 0x0604ECA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604EC3E mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 0604EC40 mov r2,r5
    c.t = (int32_t)c.r[2] >= 0;  // 0604EC42 cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0604EC4C; } }  // 0604EC44 bt/s 0x0604EC4C ; extu.b r1,r4
    c.r[5] = c.r[3];  // 0604EC48 mov r3,r5
    c.r[5] += 5;  // 0604EC4A add #5,r5
L_0604EC4C:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EC4C shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EC4E shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EC50 shar r5
    c.r[5] <<= 2;  // 0604EC52 shll2 r5
    c.r[5] += c.r[5];  // 0604EC54 add r5,r5
    c.r[5] -= c.r[2];  // 0604EC56 sub r2,r5
    c.r[0] = ld32(0x0604ECA8u);  // 0604EC58 mov.l 0x0604ECA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604EC5Eu; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EC5Eu) return; }  // 0604EC5A jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 0604EC5E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604EC60 tst r0,r0
    { const bool k = !c.t; c.r[7] = c.r[9]; if (k) { goto L_0604EC6E; } }  // 0604EC62 bf/s 0x0604EC6E ; mov r9,r7
    c.r[6] = c.r[8];  // 0604EC66 mov r8,r6
    c.r[5] = c.r[11];  // 0604EC68 mov r11,r5
    c.r[4] = 0x1u; goto L_0604EC78;  // 0604EC6A bra 0x0604EC78 ; mov #1,r4
L_0604EC6E:
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604EC6E mov.b @r13,r6
    c.r[7] = c.r[9];  // 0604EC70 mov r9,r7
    c.r[5] = c.r[11];  // 0604EC72 mov r11,r5
    c.r[4] = 0x0u;  // 0604EC74 mov #0,r4
    c.r[6] -= 2;  // 0604EC76 add #-2,r6
L_0604EC78:
    { const uint32_t x = c.r[12]; c.pr = 0x0604EC7Cu; c.r[10] += 64; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EC7Cu) return; }  // 0604EC78 jsr @r12 ; add #64,r10
    c.r[7] = c.r[9];  // 0604EC7C mov r9,r7
    c.r[5] = c.r[11];  // 0604EC7E mov r11,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604EC80 mov.b @r13,r6
    c.r[4] = 0x0u;  // 0604EC82 mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0604EC88u; c.r[6] += 21; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EC88u) return; }  // 0604EC84 jsr @r12 ; add #21,r6
    c.r[0] = ld32(0x0604ECACu);  // 0604EC88 mov.l 0x0604ECAC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604EC8A mov.b @r0,r1
    c.r[9] += 1;  // 0604EC8C add #1,r9
    c.r[1] += 16;  // 0604EC8E add #16,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604EC90 cmp/ge r1,r9
    { const bool k = !c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { SH2_POLL(c); goto L_0604EC0A; } }  // 0604EC92 bf/s 0x0604EC0A ; cmp/pz r9
    goto L_0604F0FE;  // 0604EC96 bra 0x0604F0FE ; nop
L_0604ECB0:
    c.r[2] = ld32(0x0604EEDCu);  // 0604ECB0 mov.l 0x0604EEDC,r2
    c.r[1] = c.r[2];  // 0604ECB2 mov r2,r1
    c.r[1] += 79;  // 0604ECB4 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604ECB6 mov.b @r1,r1
    c.r[9] = c.r[1];  // 0604ECB8 mov r1,r9
    c.r[9] -= 2;  // 0604ECBA add #-2,r9
    c.r[1] += 16;  // 0604ECBC add #16,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604ECBE cmp/ge r1,r9
    { const bool k = !c.t; c.r[10] = c.r[9]; if (k) { goto L_0604ECC8; } }  // 0604ECC0 bf/s 0x0604ECC8 ; mov r9,r10
    goto L_0604F0FE;  // 0604ECC4 bra 0x0604F0FE ; nop
L_0604ECC8:
    c.r[13] = ld32(0x0604EEDCu);  // 0604ECC8 mov.l 0x0604EEDC,r13
    c.r[13] += 78;  // 0604ECCA add #78,r13
    c.r[12] = ld32(0x0604EEE0u);  // 0604ECCC mov.l 0x0604EEE0,r12
    c.r[10] <<= 2;  // 0604ECCE shll2 r10
    c.r[10] <<= 2;  // 0604ECD0 shll2 r10
    c.r[10] <<= 2;  // 0604ECD2 shll2 r10
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604ECD4 mov.b @r13,r6
L_0604ECD6:
    c.r[7] = c.r[9];  // 0604ECD6 mov r9,r7
    c.r[5] = c.r[11];  // 0604ECD8 mov r11,r5
    c.r[4] = 0x0u;  // 0604ECDA mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0604ECE0u; c.r[6] -= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604ECE0u) return; }  // 0604ECDC jsr @r12 ; add #-2,r6
    c.t = (int32_t)c.r[9] >= 0;  // 0604ECE0 cmp/pz r9
    if (!c.t) { goto L_0604ED4E; }  // 0604ECE2 bf 0x0604ED4E
    c.r[1] = ld32(0x0604EEDCu);  // 0604ECE4 mov.l 0x0604EEDC,r1
    c.r[1] += 77;  // 0604ECE6 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604ECE8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604ECEA extu.b r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604ECEC cmp/gt r1,r9
    if (c.t) { goto L_0604ED4E; }  // 0604ECEE bt 0x0604ED4E
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604ECF0 mov.b @r13,r8
    c.r[0] = ld32(0x0604EEE4u);  // 0604ECF2 mov.l 0x0604EEE4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604ECF4 mov.b @r0,r1
    c.r[2] = c.r[8];  // 0604ECF6 mov r8,r2
    c.r[2] += 20;  // 0604ECF8 add #20,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604ECFA extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0604ECFC cmp/ge r1,r2
    { const bool k = c.t; c.r[3] = c.r[10]; if (k) { goto L_0604ED4E; } }  // 0604ECFE bt/s 0x0604ED4E ; mov r10,r3
    c.r[3] += c.r[8];  // 0604ED02 add r8,r3
    c.r[2] = c.r[3];  // 0604ED04 mov r3,r2
    c.r[2] += 21;  // 0604ED06 add #21,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0604ED08 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0604ED12; } }  // 0604ED0A bt/s 0x0604ED12 ; mov r2,r1
    c.r[1] = c.r[3];  // 0604ED0E mov r3,r1
    c.r[1] += 28;  // 0604ED10 add #28,r1
L_0604ED12:
    c.r[0] = c.r[1];  // 0604ED12 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604ED14 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604ED16 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604ED18 shar r0
    c.r[1] = ld32(0x0604EEE8u);  // 0604ED1A mov.l 0x0604EEE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604ED1C mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 0604ED1E mov r2,r5
    c.t = (int32_t)c.r[2] >= 0;  // 0604ED20 cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0604ED2A; } }  // 0604ED22 bt/s 0x0604ED2A ; extu.b r1,r4
    c.r[5] = c.r[3];  // 0604ED26 mov r3,r5
    c.r[5] += 28;  // 0604ED28 add #28,r5
L_0604ED2A:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604ED2A shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604ED2C shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604ED2E shar r5
    c.r[5] <<= 2;  // 0604ED30 shll2 r5
    c.r[5] += c.r[5];  // 0604ED32 add r5,r5
    c.r[5] -= c.r[2];  // 0604ED34 sub r2,r5
    c.r[0] = ld32(0x0604EEECu);  // 0604ED36 mov.l 0x0604EEEC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604ED3Cu; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604ED3Cu) return; }  // 0604ED38 jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 0604ED3C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604ED3E tst r0,r0
    { const bool k = !c.t; c.r[8] += 21; if (k) { goto L_0604ED4E; } }  // 0604ED40 bf/s 0x0604ED4E ; add #21,r8
    c.r[7] = c.r[9];  // 0604ED44 mov r9,r7
    c.r[6] = c.r[8];  // 0604ED46 mov r8,r6
    c.r[5] = c.r[11];  // 0604ED48 mov r11,r5
    c.r[4] = 0x1u; goto L_0604ED58;  // 0604ED4A bra 0x0604ED58 ; mov #1,r4
L_0604ED4E:
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604ED4E mov.b @r13,r6
    c.r[7] = c.r[9];  // 0604ED50 mov r9,r7
    c.r[5] = c.r[11];  // 0604ED52 mov r11,r5
    c.r[4] = 0x0u;  // 0604ED54 mov #0,r4
    c.r[6] += 21;  // 0604ED56 add #21,r6
L_0604ED58:
    { const uint32_t x = c.r[12]; c.pr = 0x0604ED5Cu; c.r[10] += 64; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604ED5Cu) return; }  // 0604ED58 jsr @r12 ; add #64,r10
    c.r[1] = ld32(0x0604EEF0u);  // 0604ED5C mov.l 0x0604EEF0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604ED5E mov.b @r1,r1
    c.r[9] += 1;  // 0604ED60 add #1,r9
    c.r[1] += 16;  // 0604ED62 add #16,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604ED64 cmp/ge r1,r9
    if (!c.t) { goto L_0604ED6C; }  // 0604ED66 bf 0x0604ED6C
    goto L_0604F0FE;  // 0604ED68 bra 0x0604F0FE ; nop
L_0604ED6C:
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604ED6C mov.b @r13,r6
    SH2_POLL(c); goto L_0604ECD6;  // 0604ED6E bra 0x0604ECD6 ; nop
L_0604ED72:
    c.r[2] = ld32(0x0604EEDCu);  // 0604ED72 mov.l 0x0604EEDC,r2
    c.r[3] = c.r[2];  // 0604ED74 mov r2,r3
    c.r[3] += 78;  // 0604ED76 add #78,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604ED78 mov.b @r3,r1
    c.r[9] = c.r[1];  // 0604ED7A mov r1,r9
    c.r[9] -= 2;  // 0604ED7C add #-2,r9
    c.r[1] += 22;  // 0604ED7E add #22,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604ED80 cmp/ge r1,r9
    { const bool k = !c.t; c.r[13] = c.r[2]; if (k) { goto L_0604ED8A; } }  // 0604ED82 bf/s 0x0604ED8A ; mov r2,r13
    goto L_0604F0FE;  // 0604ED86 bra 0x0604F0FE ; nop
L_0604ED8A:
    c.r[12] = c.r[13];  // 0604ED8A mov r13,r12
    c.r[12] += 79;  // 0604ED8C add #79,r12
    c.r[10] = ld32(0x0604EEE0u);  // 0604ED8E mov.l 0x0604EEE0,r10
    c.t = (int32_t)c.r[9] >= 0;  // 0604ED90 cmp/pz r9
L_0604ED92:
    { const bool k = !c.t; c.r[1] = c.r[13]; if (k) { goto L_0604EDF2; } }  // 0604ED92 bf/s 0x0604EDF2 ; mov r13,r1
    c.r[1] += 76;  // 0604ED96 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604ED98 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604ED9A extu.b r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604ED9C cmp/gt r1,r9
    if (c.t) { goto L_0604EDF2; }  // 0604ED9E bt 0x0604EDF2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EDA0 mov.b @r12,r8
    c.r[8] -= 2;  // 0604EDA2 add #-2,r8
    c.t = (int32_t)c.r[8] >= 0;  // 0604EDA4 cmp/pz r8
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0604EDF2; } }  // 0604EDA6 bf/s 0x0604EDF2 ; mov r8,r2
    c.r[2] <<= 2;  // 0604EDAA shll2 r2
    c.r[2] <<= 2;  // 0604EDAC shll2 r2
    c.r[2] <<= 2;  // 0604EDAE shll2 r2
    c.r[2] += c.r[9];  // 0604EDB0 add r9,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0604EDB2 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0604EDBA; } }  // 0604EDB4 bt/s 0x0604EDBA ; mov r2,r1
    c.r[1] += 7;  // 0604EDB8 add #7,r1
L_0604EDBA:
    c.r[0] = c.r[1];  // 0604EDBA mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EDBC shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EDBE shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EDC0 shar r0
    c.r[1] = ld32(0x0604EEE8u);  // 0604EDC2 mov.l 0x0604EEE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604EDC4 mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 0604EDC6 mov r2,r5
    c.t = (int32_t)c.r[2] >= 0;  // 0604EDC8 cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0604EDD0; } }  // 0604EDCA bt/s 0x0604EDD0 ; extu.b r1,r4
    c.r[5] += 7;  // 0604EDCE add #7,r5
L_0604EDD0:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EDD0 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EDD2 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EDD4 shar r5
    c.r[5] <<= 2;  // 0604EDD6 shll2 r5
    c.r[5] += c.r[5];  // 0604EDD8 add r5,r5
    c.r[5] -= c.r[2];  // 0604EDDA sub r2,r5
    c.r[0] = ld32(0x0604EEECu);  // 0604EDDC mov.l 0x0604EEEC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604EDE2u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EDE2u) return; }  // 0604EDDE jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 0604EDE2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604EDE4 tst r0,r0
    if (!c.t) { goto L_0604EDF2; }  // 0604EDE6 bf 0x0604EDF2
    c.r[7] = c.r[8];  // 0604EDE8 mov r8,r7
    c.r[6] = c.r[9];  // 0604EDEA mov r9,r6
    c.r[5] = c.r[11];  // 0604EDEC mov r11,r5
    c.r[4] = 0x1u; goto L_0604EDFC;  // 0604EDEE bra 0x0604EDFC ; mov #1,r4
L_0604EDF2:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EDF2 mov.b @r12,r7
    c.r[6] = c.r[9];  // 0604EDF4 mov r9,r6
    c.r[5] = c.r[11];  // 0604EDF6 mov r11,r5
    c.r[4] = 0x0u;  // 0604EDF8 mov #0,r4
    c.r[7] -= 2;  // 0604EDFA add #-2,r7
L_0604EDFC:
    { const uint32_t x = c.r[10]; c.pr = 0x0604EE00u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EE00u) return; }  // 0604EDFC jsr @r10 ; nop
    c.r[6] = c.r[9];  // 0604EE00 mov r9,r6
    c.r[5] = c.r[11];  // 0604EE02 mov r11,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EE04 mov.b @r12,r7
    c.r[4] = 0x0u;  // 0604EE06 mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604EE0Cu; c.r[7] += 15; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EE0Cu) return; }  // 0604EE08 jsr @r10 ; add #15,r7
    c.r[0] = ld32(0x0604EEF4u);  // 0604EE0C mov.l 0x0604EEF4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604EE0E mov.b @r0,r1
    c.r[9] += 1;  // 0604EE10 add #1,r9
    c.r[1] += 22;  // 0604EE12 add #22,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604EE14 cmp/ge r1,r9
    { const bool k = !c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { SH2_POLL(c); goto L_0604ED92; } }  // 0604EE16 bf/s 0x0604ED92 ; cmp/pz r9
    goto L_0604F0FE;  // 0604EE1A bra 0x0604F0FE ; nop
L_0604EE1E:
    c.r[2] = ld32(0x0604EEDCu);  // 0604EE1E mov.l 0x0604EEDC,r2
    c.r[1] = c.r[2];  // 0604EE20 mov r2,r1
    c.r[1] += 78;  // 0604EE22 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604EE24 mov.b @r1,r1
    c.r[9] = c.r[1];  // 0604EE26 mov r1,r9
    c.r[9] -= 2;  // 0604EE28 add #-2,r9
    c.r[1] += 22;  // 0604EE2A add #22,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604EE2C cmp/ge r1,r9
    { const bool k = !c.t; c.r[13] = c.r[2]; if (k) { goto L_0604EE36; } }  // 0604EE2E bf/s 0x0604EE36 ; mov r2,r13
    goto L_0604F0FE;  // 0604EE32 bra 0x0604F0FE ; nop
L_0604EE36:
    c.r[12] = c.r[13];  // 0604EE36 mov r13,r12
    c.r[12] += 79;  // 0604EE38 add #79,r12
    c.r[10] = ld32(0x0604EEE0u);  // 0604EE3A mov.l 0x0604EEE0,r10
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EE3C mov.b @r12,r7
L_0604EE3E:
    c.r[6] = c.r[9];  // 0604EE3E mov r9,r6
    c.r[5] = c.r[11];  // 0604EE40 mov r11,r5
    c.r[4] = 0x0u;  // 0604EE42 mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604EE48u; c.r[7] -= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EE48u) return; }  // 0604EE44 jsr @r10 ; add #-2,r7
    c.t = (int32_t)c.r[9] >= 0;  // 0604EE48 cmp/pz r9
    { const bool k = !c.t; c.r[1] = c.r[13]; if (k) { goto L_0604EEB8; } }  // 0604EE4A bf/s 0x0604EEB8 ; mov r13,r1
    c.r[1] += 76;  // 0604EE4E add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604EE50 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604EE52 extu.b r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604EE54 cmp/gt r1,r9
    if (c.t) { goto L_0604EEB8; }  // 0604EE56 bt 0x0604EEB8
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EE58 mov.b @r12,r7
    c.r[0] = ld32(0x0604EEF8u);  // 0604EE5A mov.l 0x0604EEF8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604EE5C mov.b @r0,r1
    c.r[2] = c.r[7];  // 0604EE5E mov r7,r2
    c.r[2] += 14;  // 0604EE60 add #14,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604EE62 extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0604EE64 cmp/ge r1,r2
    { const bool k = c.t; c.r[6] = c.r[9]; if (k) { goto L_0604EEBC; } }  // 0604EE66 bt/s 0x0604EEBC ; mov r9,r6
    c.r[8] = c.r[7];  // 0604EE6A mov r7,r8
    c.r[8] += 15;  // 0604EE6C add #15,r8
    c.r[2] = c.r[8];  // 0604EE6E mov r8,r2
    c.r[2] <<= 2;  // 0604EE70 shll2 r2
    c.r[2] <<= 2;  // 0604EE72 shll2 r2
    c.r[2] <<= 2;  // 0604EE74 shll2 r2
    c.r[2] += c.r[9];  // 0604EE76 add r9,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0604EE78 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0604EE80; } }  // 0604EE7A bt/s 0x0604EE80 ; mov r2,r1
    c.r[1] += 7;  // 0604EE7E add #7,r1
L_0604EE80:
    c.r[0] = c.r[1];  // 0604EE80 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EE82 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EE84 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604EE86 shar r0
    c.r[1] = ld32(0x0604EEE8u);  // 0604EE88 mov.l 0x0604EEE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604EE8A mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 0604EE8C mov r2,r5
    c.t = (int32_t)c.r[2] >= 0;  // 0604EE8E cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0604EE96; } }  // 0604EE90 bt/s 0x0604EE96 ; extu.b r1,r4
    c.r[5] += 7;  // 0604EE94 add #7,r5
L_0604EE96:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EE96 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EE98 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604EE9A shar r5
    c.r[5] <<= 2;  // 0604EE9C shll2 r5
    c.r[5] += c.r[5];  // 0604EE9E add r5,r5
    c.r[5] -= c.r[2];  // 0604EEA0 sub r2,r5
    c.r[0] = ld32(0x0604EEECu);  // 0604EEA2 mov.l 0x0604EEEC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604EEA8u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EEA8u) return; }  // 0604EEA4 jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 0604EEA8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604EEAA tst r0,r0
    { const bool k = !c.t; c.r[7] = c.r[8]; if (k) { goto L_0604EEB8; } }  // 0604EEAC bf/s 0x0604EEB8 ; mov r8,r7
    c.r[6] = c.r[9];  // 0604EEB0 mov r9,r6
    c.r[5] = c.r[11];  // 0604EEB2 mov r11,r5
    c.r[4] = 0x1u; goto L_0604EEC2;  // 0604EEB4 bra 0x0604EEC2 ; mov #1,r4
L_0604EEB8:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EEB8 mov.b @r12,r7
    c.r[6] = c.r[9];  // 0604EEBA mov r9,r6
L_0604EEBC:
    c.r[5] = c.r[11];  // 0604EEBC mov r11,r5
    c.r[4] = 0x0u;  // 0604EEBE mov #0,r4
    c.r[7] += 15;  // 0604EEC0 add #15,r7
L_0604EEC2:
    { const uint32_t x = c.r[10]; c.pr = 0x0604EEC6u; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EEC6u) return; }  // 0604EEC2 jsr @r10 ; add #1,r9
    c.r[1] = ld32(0x0604EEF4u);  // 0604EEC6 mov.l 0x0604EEF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604EEC8 mov.b @r1,r1
    c.r[1] += 22;  // 0604EECA add #22,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604EECC cmp/ge r1,r9
    if (!c.t) { goto L_0604EED4; }  // 0604EECE bf 0x0604EED4
    goto L_0604F0FE;  // 0604EED0 bra 0x0604F0FE ; nop
L_0604EED4:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604EED4 mov.b @r12,r7
    SH2_POLL(c); goto L_0604EE3E;  // 0604EED6 bra 0x0604EE3E ; nop
L_0604EEFC:
    c.t = (c.r[5] & c.r[5]) == 0;  // 0604EEFC tst r5,r5
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0604EF06; } }  // 0604EEFE bf/s 0x0604EF06 ; mov #0,r9
    goto L_0604F0BC;  // 0604EF02 bra 0x0604F0BC ; nop
L_0604EF06:
    c.r[9] = c.r[11];  // 0604EF06 mov r11,r9
    c.r[1] = ld32(0x0604F060u);  // 0604EF08 mov.l 0x0604F060,r1
    c.r[1] = ld32(c.r[1]);  // 0604EF0A mov.l @r1,r1
    c.r[1] += 8;  // 0604EF0C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604EF0E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604EF10 mov r1,r0
    c.r[0] >>= 2;  // 0604EF12 shlr2 r0
    c.r[0] &= 0x1u;  // 0604EF14 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604EF16 tst r0,r0
    { const bool k = c.t; c.r[9] += 3; if (k) { goto L_0604EF88; } }  // 0604EF18 bt/s 0x0604EF88 ; add #3,r9
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604F052u);  // 0604EF1C mov.w 0x0604F052,r2
    c.r[6] = c.r[14];  // 0604EF1E mov r14,r6
    c.r[6] += c.r[2];  // 0604EF20 add r2,r6
    c.r[3] = c.r[9];  // 0604EF22 mov r9,r3
    c.r[3] <<= 2;  // 0604EF24 shll2 r3
    c.r[3] <<= 2;  // 0604EF26 shll2 r3
    c.r[1] = c.r[3];  // 0604EF28 mov r3,r1
    c.r[1] |= c.r[9];  // 0604EF2A or r9,r1
    c.r[0] = c.r[14];  // 0604EF2C mov r14,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0604EF2E mov.b r1,@(r0,r2)
    c.r[7] = c.r[6];  // 0604EF30 mov r6,r7
    c.r[7] += 15;  // 0604EF32 add #15,r7
    c.r[2] = ld32(0x0604F064u);  // 0604EF34 mov.l 0x0604F064,r2
    c.r[0] = c.r[6];  // 0604EF36 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604EF38 mov.b @r2,r1
    c.r[5] = 0x7Fu;  // 0604EF3A mov #127,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604EF3C extu.b r1,r1
    c.r[1] >>= 2;  // 0604EF3E shlr2 r1
    c.r[1] >>= 2;  // 0604EF40 shlr2 r1
    c.r[3] |= c.r[1];  // 0604EF42 or r1,r3
    st8(c.r[7], c.r[3]);  // 0604EF44 mov.b r3,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F054u);  // 0604EF46 mov.w 0x0604F054,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604EF48 mov.b @r2,r3
    c.r[7] = ld32(0x0604F068u);  // 0604EF4A mov.l 0x0604F068,r7
    c.r[3] &= c.r[1];  // 0604EF4C and r1,r3
    c.r[3] |= c.r[9];  // 0604EF4E or r9,r3
    st8(c.r[0] + c.r[1], c.r[3]);  // 0604EF50 mov.b r3,@(r0,r1)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F056u);  // 0604EF52 mov.w 0x0604F056,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604EF54 mov.b @r2,r1
    c.r[9] = 0x0u;  // 0604EF56 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0604EF58 extu.b r1,r1
    c.r[1] >>= 2;  // 0604EF5A shlr2 r1
    c.r[1] >>= 2;  // 0604EF5C shlr2 r1
    c.r[2] = c.r[1];  // 0604EF5E mov r1,r2
    c.r[2] <<= 2;  // 0604EF60 shll2 r2
    c.r[2] <<= 2;  // 0604EF62 shll2 r2
    c.r[2] |= c.r[1];  // 0604EF64 or r1,r2
    st8(c.r[0] + c.r[3], c.r[2]);  // 0604EF66 mov.b r2,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F058u);  // 0604EF68 mov.w 0x0604F058,r3
    c.r[3] += c.r[14];  // 0604EF6A add r14,r3
    c.r[2] = c.r[6];  // 0604EF6C mov r6,r2
    c.r[0] = c.r[9];  // 0604EF6E mov r9,r0
L_0604EF70:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604EF70 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604EF72 extu.b r1,r1
    c.r[0] = c.r[2];  // 0604EF74 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604EF76 mov.b @(r0,r1),r1
    c.r[0] = c.r[3];  // 0604EF78 mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 0604EF7A mov.b r1,@(r0,r9)
    c.r[9] += 1;  // 0604EF7C add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[5];  // 0604EF7E cmp/gt r5,r9
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_0604EF70; } }  // 0604EF80 bf/s 0x0604EF70 ; mov r9,r0
    goto L_0604EF9A;  // 0604EF84 bra 0x0604EF9A ; nop
L_0604EF88:
    c.r[5] = c.r[9];  // 0604EF88 mov r9,r5
    c.r[5] <<= 2;  // 0604EF8A shll2 r5
    c.r[5] <<= 2;  // 0604EF8C shll2 r5
    c.r[5] |= c.r[9];  // 0604EF8E or r9,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604F05Au);  // 0604EF90 mov.w 0x0604F05A,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604F058u);  // 0604EF92 mov.w 0x0604F058,r4
    c.r[0] = ld32(0x0604F06Cu);  // 0604EF94 mov.l 0x0604F06C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604EF9Au; c.r[4] += c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EF9Au) return; }  // 0604EF96 jsr @r0 ; add r14,r4
L_0604EF9A:
    c.r[8] = ld32(0x0604F070u);  // 0604EF9A mov.l 0x0604F070,r8
    c.r[1] = 0x1u;  // 0604EF9C mov #1,r1
    st8(c.r[8], c.r[1]);  // 0604EF9E mov.b r1,@r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604F05Au);  // 0604EFA0 mov.w 0x0604F05A,r6
    c.r[10] = ld32(0x0604F074u);  // 0604EFA2 mov.l 0x0604F074,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F05Cu);  // 0604EFA4 mov.w 0x0604F05C,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604F058u);  // 0604EFA6 mov.w 0x0604F058,r4
    c.r[4] += c.r[14];  // 0604EFA8 add r14,r4
    c.r[1] = ld32(0x0604F078u);  // 0604EFAA mov.l 0x0604F078,r1
    c.r[5] = ld32(c.r[0] + c.r[10]);  // 0604EFAC mov.l @(r0,r10),r5
    c.r[7] = 0xEu;  // 0604EFAE mov #14,r7
    { const uint32_t x = c.r[1]; c.pr = 0x0604EFB4u; c.r[5] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EFB4u) return; }  // 0604EFB0 jsr @r1 ; add r6,r5
    c.r[1] = ld32(0x0604F07Cu);  // 0604EFB4 mov.l 0x0604F07C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604EFBAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604EFBAu) return; }  // 0604EFB6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0604EFBA mov #0,r1
    st8(c.r[8], c.r[1]);  // 0604EFBC mov.b r1,@r8
    c.r[2] = c.r[10];  // 0604EFBE mov r10,r2
    c.r[2] += 79;  // 0604EFC0 add #79,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604EFC2 mov.b @r2,r1
    c.r[9] = c.r[1];  // 0604EFC4 mov r1,r9
    c.r[9] -= 1;  // 0604EFC6 add #-1,r9
    c.r[1] += 15;  // 0604EFC8 add #15,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604EFCA cmp/ge r1,r9
    { const bool k = !c.t; c.r[10] = c.r[9]; if (k) { goto L_0604EFD4; } }  // 0604EFCC bf/s 0x0604EFD4 ; mov r9,r10
    goto L_0604F0FE;  // 0604EFD0 bra 0x0604F0FE ; nop
L_0604EFD4:
    c.r[12] = ld32(0x0604F080u);  // 0604EFD4 mov.l 0x0604F080,r12
    c.r[10] <<= 2;  // 0604EFD6 shll2 r10
    c.r[10] <<= 2;  // 0604EFD8 shll2 r10
    c.r[10] <<= 2;  // 0604EFDA shll2 r10
L_0604EFDC:
    c.r[0] = ld32(0x0604F084u);  // 0604EFDC mov.l 0x0604F084,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604EFDE mov.b @r0,r1
    c.r[8] = c.r[1];  // 0604EFE0 mov r1,r8
    c.r[8] -= 1;  // 0604EFE2 add #-1,r8
    c.r[1] += 21;  // 0604EFE4 add #21,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0604EFE6 cmp/ge r1,r8
    { const bool k = c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { goto L_0604F0AA; } }  // 0604EFE8 bt/s 0x0604F0AA ; cmp/pz r9
    c.r[13] = ld32(0x0604F084u);  // 0604EFEC mov.l 0x0604F084,r13
L_0604EFEE:
    { const bool k = !c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_0604F094; } }  // 0604EFEE bf/s 0x0604F094 ; cmp/pz r8
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0604F094; } }  // 0604EFF2 bf/s 0x0604F094 ; mov r10,r2
    c.r[2] += c.r[8];  // 0604EFF6 add r8,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0604EFF8 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0604F000; } }  // 0604EFFA bt/s 0x0604F000 ; mov r2,r1
    c.r[1] += 7;  // 0604EFFE add #7,r1
L_0604F000:
    c.r[0] = c.r[1];  // 0604F000 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604F002 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604F004 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604F006 shar r0
    c.r[1] = ld32(0x0604F088u);  // 0604F008 mov.l 0x0604F088,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604F00A mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 0604F00C mov r2,r5
    c.t = (int32_t)c.r[2] >= 0;  // 0604F00E cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0604F016; } }  // 0604F010 bt/s 0x0604F016 ; extu.b r1,r4
    c.r[5] += 7;  // 0604F014 add #7,r5
L_0604F016:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604F016 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604F018 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604F01A shar r5
    c.r[5] <<= 2;  // 0604F01C shll2 r5
    c.r[5] += c.r[5];  // 0604F01E add r5,r5
    c.r[5] -= c.r[2];  // 0604F020 sub r2,r5
    c.r[0] = ld32(0x0604F08Cu);  // 0604F022 mov.l 0x0604F08C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604F028u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F028u) return; }  // 0604F024 jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 0604F028 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F02A tst r0,r0
    { const bool k = !c.t; c.r[7] = c.r[9]; if (k) { goto L_0604F096; } }  // 0604F02C bf/s 0x0604F096 ; mov r9,r7
    c.r[1] = ld32(0x0604F074u);  // 0604F030 mov.l 0x0604F074,r1
    c.r[1] += 77;  // 0604F032 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F034 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F036 extu.b r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604F038 cmp/gt r1,r9
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_0604F098; } }  // 0604F03A bt/s 0x0604F098 ; mov r8,r6
    c.r[0] = ld32(0x0604F090u);  // 0604F03E mov.l 0x0604F090,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604F040 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F042 extu.b r1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0604F044 cmp/gt r1,r8
    { const bool k = c.t; c.r[5] = c.r[11]; if (k) { goto L_0604F09A; } }  // 0604F046 bt/s 0x0604F09A ; mov r11,r5
    c.r[7] = c.r[9];  // 0604F04A mov r9,r7
    c.r[6] = c.r[8];  // 0604F04C mov r8,r6
    c.r[4] = 0x1u; goto L_0604F09C;  // 0604F04E bra 0x0604F09C ; mov #1,r4
L_0604F094:
    c.r[7] = c.r[9];  // 0604F094 mov r9,r7
L_0604F096:
    c.r[6] = c.r[8];  // 0604F096 mov r8,r6
L_0604F098:
    c.r[5] = c.r[11];  // 0604F098 mov r11,r5
L_0604F09A:
    c.r[4] = 0x0u;  // 0604F09A mov #0,r4
L_0604F09C:
    { const uint32_t x = c.r[12]; c.pr = 0x0604F0A0u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F0A0u) return; }  // 0604F09C jsr @r12 ; add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604F0A0 mov.b @r13,r1
    c.r[1] += 21;  // 0604F0A2 add #21,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0604F0A4 cmp/ge r1,r8
    { const bool k = !c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { SH2_POLL(c); goto L_0604EFEE; } }  // 0604F0A6 bf/s 0x0604EFEE ; cmp/pz r9
L_0604F0AA:
    c.r[0] = ld32(0x0604F124u);  // 0604F0AA mov.l 0x0604F124,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604F0AC mov.b @r0,r1
    c.r[9] += 1;  // 0604F0AE add #1,r9
    c.r[1] += 15;  // 0604F0B0 add #15,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0604F0B2 cmp/ge r1,r9
    { const bool k = !c.t; c.r[10] += 64; if (k) { SH2_POLL(c); goto L_0604EFDC; } }  // 0604F0B4 bf/s 0x0604EFDC ; add #64,r10
    goto L_0604F0FE;  // 0604F0B8 bra 0x0604F0FE ; nop
L_0604F0BC:
    c.r[2] = ld32(0x0604F128u);  // 0604F0BC mov.l 0x0604F128,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F116u);  // 0604F0BE mov.w 0x0604F116,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0604F0C0 mov.w @(r0,r2),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0604F0C2 extu.w r1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F118u);  // 0604F0C4 mov.w 0x0604F118,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604F0C6 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F0C8 extu.b r1,r1
    c.r[1] <<= 8;  // 0604F0CA shll8 r1
    c.r[1] <<= 2;  // 0604F0CC shll2 r1
    c.r[1] <<= 2;  // 0604F0CE shll2 r1
    c.r[8] |= c.r[1];  // 0604F0D0 or r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F11Au);  // 0604F0D2 mov.w 0x0604F11A,r1
L_0604F0D4:
    st16(c.r[3], c.r[8]);  // 0604F0D4 mov.w r8,@r3
    c.r[9] += 1;  // 0604F0D6 add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604F0D8 cmp/gt r1,r9
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0604F0D4; } }  // 0604F0DA bf/s 0x0604F0D4 ; add #2,r3
    c.r[8] = ld32(0x0604F12Cu);  // 0604F0DE mov.l 0x0604F12C,r8
    c.r[1] = 0x1u;  // 0604F0E0 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0604F0E2 mov.b r1,@r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604F11Cu);  // 0604F0E4 mov.w 0x0604F11C,r6
    c.r[1] = ld32(0x0604F128u);  // 0604F0E6 mov.l 0x0604F128,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F11Eu);  // 0604F0E8 mov.w 0x0604F11E,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0604F0EA mov.l @(r0,r1),r5
    c.r[7] = 0xEu;  // 0604F0EC mov #14,r7
    c.r[1] = ld32(0x0604F130u);  // 0604F0EE mov.l 0x0604F130,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F0F4u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F0F4u) return; }  // 0604F0F0 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x0604F134u);  // 0604F0F4 mov.l 0x0604F134,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F0FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F0FAu) return; }  // 0604F0F6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0604F0FA mov #0,r1
    st8(c.r[8], c.r[1]);  // 0604F0FC mov.b r1,@r8
L_0604F0FE:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F120u);  // 0604F0FE mov.w 0x0604F120,r3
    c.r[14] += c.r[3];  // 0604F100 add r3,r14
    c.r[15] = c.r[14];  // 0604F102 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F104 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604F106 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604F108 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604F10A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604F10C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604F10E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604F110 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F112 rts ; mov.l @r15+,r8
}

void f_0604F138(SH2Context& c) {
    ran[1260] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F138 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604F13A mov r15,r14
    c.t = (int32_t)c.r[6] >= 0;  // 0604F13C cmp/pz r6
    { const bool k = c.t; c.r[4] = c.r[4] & 0xFFu; if (k) { goto L_0604F146; } }  // 0604F13E bt/s 0x0604F146 ; extu.b r4,r4
    c.r[6] += 32; goto L_0604F15A;  // 0604F142 bra 0x0604F15A ; add #32,r6
L_0604F146:
    c.r[1] = c.r[6];  // 0604F146 mov r6,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F148 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F14A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F14C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F14E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F150 shar r1
    c.r[1] <<= 2;  // 0604F152 shll2 r1
    c.r[1] += c.r[1];  // 0604F154 add r1,r1
    c.r[1] <<= 2;  // 0604F156 shll2 r1
    c.r[6] -= c.r[1];  // 0604F158 sub r1,r6
L_0604F15A:
    c.t = (int32_t)c.r[7] >= 0;  // 0604F15A cmp/pz r7
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0604F164; } }  // 0604F15C bt/s 0x0604F164 ; mov r7,r1
    c.r[7] += 32; goto L_0604F176;  // 0604F160 bra 0x0604F176 ; add #32,r7
L_0604F164:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F164 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F166 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F168 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F16A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604F16C shar r1
    c.r[1] <<= 2;  // 0604F16E shll2 r1
    c.r[1] += c.r[1];  // 0604F170 add r1,r1
    c.r[1] <<= 2;  // 0604F172 shll2 r1
    c.r[7] -= c.r[1];  // 0604F174 sub r1,r7
L_0604F176:
    c.r[2] = ld32(0x0604F1ACu);  // 0604F176 mov.l 0x0604F1AC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F1A6u);  // 0604F178 mov.w 0x0604F1A6,r1
    c.r[0] = c.r[2];  // 0604F17A mov r2,r0
    c.r[6] += c.r[6];  // 0604F17C add r6,r6
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0604F17E mov.l @(r0,r1),r1
    c.r[7] <<= 2;  // 0604F180 shll2 r7
    c.r[7] <<= 2;  // 0604F182 shll2 r7
    c.r[7] <<= 2;  // 0604F184 shll2 r7
    c.r[7] += c.r[1];  // 0604F186 add r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F1A8u);  // 0604F188 mov.w 0x0604F1A8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604F18A mov.w @(r0,r1),r1
    c.r[4] += c.r[1];  // 0604F18C add r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F1AAu);  // 0604F18E mov.w 0x0604F1AA,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604F190 mov.b @(r0,r1),r1
    c.r[15] = c.r[14];  // 0604F192 mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0604F194 extu.b r1,r1
    c.r[1] <<= 8;  // 0604F196 shll8 r1
    c.r[1] <<= 2;  // 0604F198 shll2 r1
    c.r[1] <<= 2;  // 0604F19A shll2 r1
    c.r[4] |= c.r[1];  // 0604F19C or r1,r4
    c.r[0] = c.r[6];  // 0604F19E mov r6,r0
    st16(c.r[0] + c.r[7], c.r[4]);  // 0604F1A0 mov.w r4,@(r0,r7)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F1A2 rts ; mov.l @r15+,r14
}

void f_0604F1B0(SH2Context& c) {
    ran[1261] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604F1B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604F1B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F1B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F1B6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F2BCu);  // 0604F1B8 mov.w 0x0604F2BC,r3
    c.r[15] += c.r[3];  // 0604F1BA add r3,r15
    c.r[14] = c.r[15];  // 0604F1BC mov r15,r14
    c.r[1] = c.r[4] & 0xFFu;  // 0604F1BE extu.b r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604F1C0 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_0604F272; } }  // 0604F1C2 bt/s 0x0604F272 ; extu.b r5,r5
    c.r[0] = c.r[1];  // 0604F1C6 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0604F1C8 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x44u; if (k) { goto L_0604F24C; } }  // 0604F1CA bf/s 0x0604F24C ; mov #68,r1
    st8(c.r[14], c.r[1]);  // 0604F1CE mov.b r1,@r14
    c.r[2] = c.r[14];  // 0604F1D0 mov r14,r2
    c.r[2] += 15;  // 0604F1D2 add #15,r2
    c.r[1] = 0x40u;  // 0604F1D4 mov #64,r1
    c.r[1] |= c.r[5];  // 0604F1D6 or r5,r1
    st8(c.r[2], c.r[1]);  // 0604F1D8 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F2BEu);  // 0604F1DA mov.w 0x0604F2BE,r0
    c.r[2] = c.r[5];  // 0604F1DC mov r5,r2
    c.r[2] <<= 2;  // 0604F1DE shll2 r2
    c.r[2] <<= 2;  // 0604F1E0 shll2 r2
    c.r[1] = 0x4u;  // 0604F1E2 mov #4,r1
    c.r[1] |= c.r[2];  // 0604F1E4 or r2,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 0604F1E6 mov.b r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F2C0u);  // 0604F1E8 mov.w 0x0604F2C0,r0
    c.r[2] |= c.r[5];  // 0604F1EA or r5,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 0604F1EC mov.b r2,@(r0,r14)
    c.r[2] = 0x0u;  // 0604F1EE mov #0,r2
    c.r[6] = 0x7Fu;  // 0604F1F0 mov #127,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F2C2u);  // 0604F1F2 mov.w 0x0604F2C2,r3
    c.r[3] += c.r[14];  // 0604F1F4 add r14,r3
    c.r[7] = ld32(0x0604F2CCu);  // 0604F1F6 mov.l 0x0604F2CC,r7
    c.r[0] = c.r[2];  // 0604F1F8 mov r2,r0
L_0604F1FA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604F1FA mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F1FC extu.b r1,r1
    c.r[0] = c.r[14];  // 0604F1FE mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604F200 mov.b @(r0,r1),r1
    c.r[0] = c.r[3];  // 0604F202 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0604F204 mov.b r1,@(r0,r2)
    c.r[2] += 1;  // 0604F206 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0604F208 cmp/gt r6,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0604F1FA; } }  // 0604F20A bf/s 0x0604F1FA ; mov r2,r0
    c.r[1] = 0x0u;  // 0604F20E mov #0,r1
    st8(c.r[14], c.r[1]);  // 0604F210 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0604F212 mov r14,r1
    c.r[1] += 15;  // 0604F214 add #15,r1
    st8(c.r[1], c.r[5]);  // 0604F216 mov.b r5,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F2BEu);  // 0604F218 mov.w 0x0604F2BE,r0
    c.r[1] = c.r[5];  // 0604F21A mov r5,r1
    c.r[1] <<= 2;  // 0604F21C shll2 r1
    c.r[1] <<= 2;  // 0604F21E shll2 r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 0604F220 mov.b r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F2C0u);  // 0604F222 mov.w 0x0604F2C0,r0
    c.r[5] |= c.r[1];  // 0604F224 or r1,r5
    st8(c.r[0] + c.r[14], c.r[5]);  // 0604F226 mov.b r5,@(r0,r14)
    c.r[2] = 0x0u;  // 0604F228 mov #0,r2
    c.r[6] = 0x7Fu;  // 0604F22A mov #127,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F2C4u);  // 0604F22C mov.w 0x0604F2C4,r3
    c.r[3] += c.r[14];  // 0604F22E add r14,r3
    c.r[7] = ld32(0x0604F2CCu);  // 0604F230 mov.l 0x0604F2CC,r7
    c.r[0] = c.r[2];  // 0604F232 mov r2,r0
L_0604F234:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604F234 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F236 extu.b r1,r1
    c.r[0] = c.r[14];  // 0604F238 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604F23A mov.b @(r0,r1),r1
    c.r[0] = c.r[3];  // 0604F23C mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0604F23E mov.b r1,@(r0,r2)
    c.r[2] += 1;  // 0604F240 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0604F242 cmp/gt r6,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0604F234; } }  // 0604F244 bf/s 0x0604F234 ; mov r2,r0
    goto L_0604F28A;  // 0604F248 bra 0x0604F28A ; nop
L_0604F24C:
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604F2C6u);  // 0604F24C mov.w 0x0604F2C6,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0604F2C4u);  // 0604F24E mov.w 0x0604F2C4,r9
    c.r[9] += c.r[14];  // 0604F250 add r14,r9
    c.r[0] = ld32(0x0604F2D0u);  // 0604F252 mov.l 0x0604F2D0,r0
    c.r[6] = c.r[8];  // 0604F254 mov r8,r6
    c.r[5] = 0x0u;  // 0604F256 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604F25Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F25Cu) return; }  // 0604F258 jsr @r0 ; mov r9,r4
    c.r[5] = 0x44u;  // 0604F25C mov #68,r5
    c.r[2] = c.r[8];  // 0604F25E mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F2C0u);  // 0604F260 mov.w 0x0604F2C0,r1
    c.r[3] = c.r[9];  // 0604F262 mov r9,r3
    c.r[0] = c.r[3];  // 0604F264 mov r3,r0
L_0604F266:
    st8(c.r[0] + c.r[2], c.r[5]);  // 0604F266 mov.b r5,@(r0,r2)
    c.r[2] += 1;  // 0604F268 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604F26A cmp/gt r1,r2
    if (!c.t) { SH2_POLL(c); goto L_0604F266; }  // 0604F26C bf 0x0604F266
    goto L_0604F28A;  // 0604F26E bra 0x0604F28A ; nop
L_0604F272:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604F2C4u);  // 0604F272 mov.w 0x0604F2C4,r2
    c.r[2] += c.r[14];  // 0604F274 add r14,r2
    c.r[5] = ld32(0x0604F2CCu);  // 0604F276 mov.l 0x0604F2CC,r5
    c.r[1] = ld32(0x0604F2D4u);  // 0604F278 mov.l 0x0604F2D4,r1
    c.r[4] = c.r[2];  // 0604F27A mov r2,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0604F280u; c.r[6] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F280u) return; }  // 0604F27C jsr @r1 ; mov #64,r6
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604F2C6u);  // 0604F280 mov.w 0x0604F2C6,r6
    c.r[0] = ld32(0x0604F2D0u);  // 0604F282 mov.l 0x0604F2D0,r0
    c.r[5] = 0x0u;  // 0604F284 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604F28Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F28Au) return; }  // 0604F286 jsr @r0 ; mov r2,r4
L_0604F28A:
    c.r[8] = ld32(0x0604F2D8u);  // 0604F28A mov.l 0x0604F2D8,r8
    c.r[1] = 0x1u;  // 0604F28C mov #1,r1
    st8(c.r[8], c.r[1]);  // 0604F28E mov.b r1,@r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604F2C4u);  // 0604F290 mov.w 0x0604F2C4,r6
    c.r[1] = ld32(0x0604F2DCu);  // 0604F292 mov.l 0x0604F2DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F2C8u);  // 0604F294 mov.w 0x0604F2C8,r0
    c.r[4] = c.r[14];  // 0604F296 mov r14,r4
    c.r[4] += c.r[6];  // 0604F298 add r6,r4
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0604F29A mov.l @(r0,r1),r5
    c.r[1] = ld32(0x0604F2E0u);  // 0604F29C mov.l 0x0604F2E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F2A2u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F2A2u) return; }  // 0604F29E jsr @r1 ; mov #14,r7
    c.r[1] = ld32(0x0604F2E4u);  // 0604F2A2 mov.l 0x0604F2E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F2A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F2A8u) return; }  // 0604F2A4 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0604F2A8 mov #0,r1
    st8(c.r[8], c.r[1]);  // 0604F2AA mov.b r1,@r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604F2CAu);  // 0604F2AC mov.w 0x0604F2CA,r3
    c.r[14] += c.r[3];  // 0604F2AE add r3,r14
    c.r[15] = c.r[14];  // 0604F2B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F2B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604F2B4 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604F2B6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F2B8 rts ; mov.l @r15+,r8
}

void f_0604F2F0(SH2Context& c) {
    ran[1262] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604F2F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604F2F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604F2F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604F2F6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604F2F8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604F2FA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F2FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F2FE sts.l pr,@-r15
    c.r[15] -= 12;  // 0604F300 add #-12,r15
    c.r[14] = c.r[15];  // 0604F302 mov r15,r14
    c.r[11] = c.r[5];  // 0604F304 mov r5,r11
    c.r[4] = c.r[4] & 0xFFu;  // 0604F306 extu.b r4,r4
    c.r[11] = c.r[11] & 0xFFu;  // 0604F308 extu.b r11,r11
    c.r[10] = ld32(0x0604F4ACu);  // 0604F30A mov.l 0x0604F4AC,r10
    c.r[2] = c.r[10];  // 0604F30C mov r10,r2
    c.r[2] += 116;  // 0604F30E add #116,r2
    c.r[0] = ld32(0x0604F4B0u);  // 0604F310 mov.l 0x0604F4B0,r0
    c.r[8] = 0x7u;  // 0604F312 mov #7,r8
    c.r[8] += c.r[14];  // 0604F314 add r14,r8
    c.r[3] = c.r[10];  // 0604F316 mov r10,r3
    c.r[3] += 108;  // 0604F318 add #108,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604F31A mov.b @r0,r1
    c.r[12] = ld32(0x0604F4B4u);  // 0604F31C mov.l 0x0604F4B4,r12
    c.r[0] = 0x7u;  // 0604F31E mov #7,r0
    st8(c.r[0] + c.r[14], c.r[1]);  // 0604F320 mov.b r1,@(r0,r14)
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604F322 mov.b @r8,r8
    c.r[0] = c.r[4];  // 0604F324 mov r4,r0
    c.r[0] -= c.r[8];  // 0604F326 sub r8,r0
    st32(c.r[14], c.r[0]);  // 0604F328 mov.l r0,@r14
    c.r[0] = 0x3u;  // 0604F32A mov #3,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0604F32C mov.b @(r0,r14),r0
    c.r[1] = ld32(0x0604F4B8u);  // 0604F32E mov.l 0x0604F4B8,r1
    st8(c.r[2], c.r[0]);  // 0604F330 mov.b r0,@r2
    c.r[2] = c.r[10];  // 0604F332 mov r10,r2
    c.r[2] += 117;  // 0604F334 add #117,r2
    c.r[0] = 0xBu;  // 0604F336 mov #11,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F338 mov.b @r1,r8
    c.r[0] += c.r[14];  // 0604F33A add r14,r0
    c.r[1] = 0xBu;  // 0604F33C mov #11,r1
    c.r[1] += c.r[14];  // 0604F33E add r14,r1
    st8(c.r[1], c.r[8]);  // 0604F340 mov.b r8,@r1
    c.r[1] = c.r[11];  // 0604F342 mov r11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604F344 mov.b @r0,r0
    c.r[8] = ld32(0x0604F4B0u);  // 0604F346 mov.l 0x0604F4B0,r8
    c.r[1] -= c.r[0];  // 0604F348 sub r0,r1
    st32(c.r[14], c.r[1]);  // 0604F34A mov.l r1,@r14
    c.r[1] = 0x3u;  // 0604F34C mov #3,r1
    c.r[1] += c.r[14];  // 0604F34E add r14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F350 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F4A4u);  // 0604F352 mov.w 0x0604F4A4,r0
    st8(c.r[2], c.r[1]);  // 0604F354 mov.b r1,@r2
    c.r[2] = c.r[4];  // 0604F356 mov r4,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604F358 mov.b @r8,r8
    c.r[1] = ld32(0x0604F4B8u);  // 0604F35A mov.l 0x0604F4B8,r1
    c.r[2] -= c.r[8];  // 0604F35C sub r8,r2
    c.r[2] <<= 2;  // 0604F35E shll2 r2
    c.r[2] <<= 2;  // 0604F360 shll2 r2
    c.r[2] += c.r[0];  // 0604F362 add r0,r2
    st16(c.r[3], c.r[2]);  // 0604F364 mov.w r2,@r3
    c.r[2] = c.r[10];  // 0604F366 mov r10,r2
    c.r[2] += 110;  // 0604F368 add #110,r2
    c.r[8] = c.r[11];  // 0604F36A mov r11,r8
    c.r[0] = 0x2u;  // 0604F36C mov #2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F36E mov.b @r1,r1
    c.r[0] += c.r[14];  // 0604F370 add r14,r0
    c.r[8] -= c.r[1];  // 0604F372 sub r1,r8
    c.r[8] <<= 2;  // 0604F374 shll2 r8
    c.r[8] <<= 2;  // 0604F376 shll2 r8
    c.r[8] -= 104;  // 0604F378 add #-104,r8
    st32(c.r[14], c.r[8]);  // 0604F37A mov.l r8,@r14
    c.r[1] = ld32(0x0604F4B0u);  // 0604F37C mov.l 0x0604F4B0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604F37E mov.w @r0,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604F4A4u);  // 0604F380 mov.w 0x0604F4A4,r8
    st16(c.r[2], c.r[0]);  // 0604F382 mov.w r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F384 mov.b @r1,r1
    c.r[0] = ld32(0x0604F4BCu);  // 0604F386 mov.l 0x0604F4BC,r0
    c.r[9] = ld32(c.r[12] + 12);  // 0604F388 mov.l @(12,r12),r9
    c.r[4] -= c.r[1];  // 0604F38A sub r1,r4
    c.r[4] <<= 2;  // 0604F38C shll2 r4
    c.r[4] <<= 2;  // 0604F38E shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0604F394u; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F394u) return; }  // 0604F390 jsr @r0 ; add r8,r4
    c.r[4] = c.r[0];  // 0604F394 mov r0,r4
    c.r[5] = c.r[1];  // 0604F396 mov r1,r5
    c.r[1] = ld32(0x0604F4C0u);  // 0604F398 mov.l 0x0604F4C0,r1
    c.r[6] = ld32(c.r[1]);  // 0604F39A mov.l @r1,r6
    c.r[8] = ld32(0x0604F4C4u);  // 0604F39C mov.l 0x0604F4C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604F3A2u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3A2u) return; }  // 0604F39E jsr @r8 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0604F3A2 mov r0,r4
    c.r[5] = c.r[1];  // 0604F3A4 mov r1,r5
    c.r[0] = ld32(0x0604F4C8u);  // 0604F3A6 mov.l 0x0604F4C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604F3ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3ACu) return; }  // 0604F3A8 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0604F3AC mov r0,r2
    st32(c.r[9], c.r[2]);  // 0604F3AE mov.l r2,@r9
    c.r[1] = ld32(0x0604F4B8u);  // 0604F3B0 mov.l 0x0604F4B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F3B2 mov.b @r1,r1
    c.r[8] = ld32(0x0604F4BCu);  // 0604F3B4 mov.l 0x0604F4BC,r8
    c.r[13] = ld32(c.r[12] + 12);  // 0604F3B6 mov.l @(12,r12),r13
    c.r[11] -= c.r[1];  // 0604F3B8 sub r1,r11
    c.r[11] <<= 2;  // 0604F3BA shll2 r11
    c.r[11] <<= 2;  // 0604F3BC shll2 r11
    c.r[11] -= 104;  // 0604F3BE add #-104,r11
    { const uint32_t x = c.r[8]; c.pr = 0x0604F3C4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3C4u) return; }  // 0604F3C0 jsr @r8 ; mov r11,r4
    c.r[4] = c.r[0];  // 0604F3C4 mov r0,r4
    c.r[5] = c.r[1];  // 0604F3C6 mov r1,r5
    c.r[0] = ld32(0x0604F4C0u);  // 0604F3C8 mov.l 0x0604F4C0,r0
    c.r[6] = ld32(c.r[0]);  // 0604F3CA mov.l @r0,r6
    c.r[1] = ld32(0x0604F4C4u);  // 0604F3CC mov.l 0x0604F4C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F3D2u; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3D2u) return; }  // 0604F3CE jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 0604F3D2 mov r0,r4
    c.r[8] = ld32(0x0604F4C8u);  // 0604F3D4 mov.l 0x0604F4C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604F3DAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3DAu) return; }  // 0604F3D6 jsr @r8 ; mov r1,r5
    c.r[2] = c.r[0];  // 0604F3DA mov r0,r2
    st32(c.r[13] + 4, c.r[2]);  // 0604F3DC mov.l r2,@(4,r13)
    c.r[11] = c.r[10];  // 0604F3DE mov r10,r11
    c.r[11] += 80;  // 0604F3E0 add #80,r11
    c.r[0] = ld32(0x0604F4B0u);  // 0604F3E2 mov.l 0x0604F4B0,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604F3E4 mov.b @r0,r4
    c.r[1] = ld32(0x0604F4BCu);  // 0604F3E6 mov.l 0x0604F4BC,r1
    c.r[4] <<= 2;  // 0604F3E8 shll2 r4
    { const uint32_t x = c.r[1]; c.pr = 0x0604F3EEu; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3EEu) return; }  // 0604F3EA jsr @r1 ; shll2 r4
    c.r[4] = c.r[0];  // 0604F3EE mov r0,r4
    c.r[5] = c.r[1];  // 0604F3F0 mov r1,r5
    c.r[8] = ld32(0x0604F4C0u);  // 0604F3F2 mov.l 0x0604F4C0,r8
    c.r[6] = ld32(c.r[8]);  // 0604F3F4 mov.l @r8,r6
    c.r[0] = ld32(0x0604F4C4u);  // 0604F3F6 mov.l 0x0604F4C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604F3FCu; c.r[7] = ld32(c.r[8] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F3FCu) return; }  // 0604F3F8 jsr @r0 ; mov.l @(4,r8),r7
    c.r[4] = c.r[0];  // 0604F3FC mov r0,r4
    c.r[5] = c.r[1];  // 0604F3FE mov r1,r5
    c.r[1] = ld32(0x0604F4C8u);  // 0604F400 mov.l 0x0604F4C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F406u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F406u) return; }  // 0604F402 jsr @r1 ; nop
    c.r[2] = c.r[0];  // 0604F406 mov r0,r2
    st32(c.r[11], c.r[2]);  // 0604F408 mov.l r2,@r11
    c.r[11] = c.r[10];  // 0604F40A mov r10,r11
    c.r[11] += 84;  // 0604F40C add #84,r11
    c.r[8] = ld32(0x0604F4B8u);  // 0604F40E mov.l 0x0604F4B8,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604F410 mov.b @r8,r4
    c.r[0] = ld32(0x0604F4BCu);  // 0604F412 mov.l 0x0604F4BC,r0
    c.r[4] <<= 2;  // 0604F414 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0604F41Au; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F41Au) return; }  // 0604F416 jsr @r0 ; shll2 r4
    c.r[4] = c.r[0];  // 0604F41A mov r0,r4
    c.r[5] = c.r[1];  // 0604F41C mov r1,r5
    c.r[1] = ld32(0x0604F4C0u);  // 0604F41E mov.l 0x0604F4C0,r1
    c.r[6] = ld32(c.r[1]);  // 0604F420 mov.l @r1,r6
    c.r[8] = ld32(0x0604F4C4u);  // 0604F422 mov.l 0x0604F4C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604F428u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F428u) return; }  // 0604F424 jsr @r8 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0604F428 mov r0,r4
    c.r[5] = c.r[1];  // 0604F42A mov r1,r5
    c.r[0] = ld32(0x0604F4C8u);  // 0604F42C mov.l 0x0604F4C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604F432u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F432u) return; }  // 0604F42E jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0604F432 mov r0,r2
    st32(c.r[11], c.r[2]);  // 0604F434 mov.l r2,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604F4A6u);  // 0604F436 mov.w 0x0604F4A6,r11
    c.r[1] = ld32(0x0604F4B0u);  // 0604F438 mov.l 0x0604F4B0,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F43A mov.b @r1,r4
    c.r[8] = ld32(0x0604F4BCu);  // 0604F43C mov.l 0x0604F4BC,r8
    c.r[4] <<= 2;  // 0604F43E shll2 r4
    c.r[4] <<= 2;  // 0604F440 shll2 r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604F446u; c.r[4] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F446u) return; }  // 0604F442 jsr @r8 ; add #-1,r4
    c.r[4] = c.r[0];  // 0604F446 mov r0,r4
    c.r[5] = c.r[1];  // 0604F448 mov r1,r5
    c.r[0] = ld32(0x0604F4C0u);  // 0604F44A mov.l 0x0604F4C0,r0
    c.r[6] = ld32(c.r[0]);  // 0604F44C mov.l @r0,r6
    c.r[1] = ld32(0x0604F4C4u);  // 0604F44E mov.l 0x0604F4C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F454u; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F454u) return; }  // 0604F450 jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 0604F454 mov r0,r4
    c.r[8] = ld32(0x0604F4C8u);  // 0604F456 mov.l 0x0604F4C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604F45Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F45Cu) return; }  // 0604F458 jsr @r8 ; mov r1,r5
    c.r[2] = c.r[0];  // 0604F45C mov r0,r2
    c.r[0] = c.r[10];  // 0604F45E mov r10,r0
    st32(c.r[0] + c.r[11], c.r[2]);  // 0604F460 mov.l r2,@(r0,r11)
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604F4A8u);  // 0604F462 mov.w 0x0604F4A8,r11
    c.r[1] = ld32(0x0604F4B8u);  // 0604F464 mov.l 0x0604F4B8,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F466 mov.b @r1,r4
    c.r[8] = ld32(0x0604F4BCu);  // 0604F468 mov.l 0x0604F4BC,r8
    c.r[4] <<= 2;  // 0604F46A shll2 r4
    c.r[4] <<= 2;  // 0604F46C shll2 r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604F472u; c.r[4] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F472u) return; }  // 0604F46E jsr @r8 ; add #-1,r4
    c.r[4] = c.r[0];  // 0604F472 mov r0,r4
    c.r[5] = c.r[1];  // 0604F474 mov r1,r5
    c.r[0] = ld32(0x0604F4C0u);  // 0604F476 mov.l 0x0604F4C0,r0
    c.r[6] = ld32(c.r[0]);  // 0604F478 mov.l @r0,r6
    c.r[1] = ld32(0x0604F4C4u);  // 0604F47A mov.l 0x0604F4C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F480u; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F480u) return; }  // 0604F47C jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 0604F480 mov r0,r4
    c.r[8] = ld32(0x0604F4C8u);  // 0604F482 mov.l 0x0604F4C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604F488u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F488u) return; }  // 0604F484 jsr @r8 ; mov r1,r5
    c.r[2] = c.r[0];  // 0604F488 mov r0,r2
    c.r[0] = c.r[10];  // 0604F48A mov r10,r0
    st32(c.r[0] + c.r[11], c.r[2]);  // 0604F48C mov.l r2,@(r0,r11)
    c.r[14] += 12;  // 0604F48E add #12,r14
    c.r[15] = c.r[14];  // 0604F490 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F492 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604F494 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604F496 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604F498 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604F49A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604F49C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604F49E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F4A0 rts ; mov.l @r15+,r8
}

void f_0604F4D4(SH2Context& c) {
    ran[1263] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604F4D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604F4D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604F4D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604F4DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604F4DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F4DE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F4E0 sts.l pr,@-r15
    c.r[9] = ld32(0x0604F5A8u);  // 0604F4E2 mov.l 0x0604F5A8,r9
    c.r[10] = c.r[9];  // 0604F4E4 mov r9,r10
    c.r[10] += 118;  // 0604F4E6 add #118,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0604F4E8 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0604F4EA mov r1,r0
    c.r[0] >>= 2;  // 0604F4EC shlr2 r0
    c.r[0] >>= 2;  // 0604F4EE shlr2 r0
    c.r[0] >>= 2;  // 0604F4F0 shlr2 r0
    c.r[0] &= 0x1u;  // 0604F4F2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F4F4 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604F4FE; } }  // 0604F4F6 bf/s 0x0604F4FE ; mov r15,r14
    goto L_0604F64A;  // 0604F4FA bra 0x0604F64A ; nop
L_0604F4FE:
    c.r[12] = c.r[9];  // 0604F4FE mov r9,r12
    c.r[12] += 126;  // 0604F500 add #126,r12
    c.r[1] = ld32(0x0604F5ACu);  // 0604F502 mov.l 0x0604F5AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F508u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F508u) return; }  // 0604F504 jsr @r1 ; mov.b @r12,r4
    c.r[4] = c.r[0];  // 0604F508 mov r0,r4
    c.r[5] = c.r[1];  // 0604F50A mov r1,r5
    c.r[1] = ld32(0x0604F5B0u);  // 0604F50C mov.l 0x0604F5B0,r1
    c.r[6] = ld32(c.r[1]);  // 0604F50E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0604F510 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0604F5B4u);  // 0604F512 mov.l 0x0604F5B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F518u; c.r[11] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F518u) return; }  // 0604F514 jsr @r1 ; mov r9,r11
    c.r[4] = c.r[0];  // 0604F518 mov r0,r4
    c.r[5] = c.r[1];  // 0604F51A mov r1,r5
    c.r[0] = ld32(0x0604F5B8u);  // 0604F51C mov.l 0x0604F5B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604F522u; c.r[11] += 120; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F522u) return; }  // 0604F51E jsr @r0 ; add #120,r11
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604F522 mov.w @r11,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0604F524 exts.w r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0604F526 cmp/pl r1
    { const bool k = !c.t; c.r[7] = c.r[0]; if (k) { goto L_0604F5C4; } }  // 0604F528 bf/s 0x0604F5C4 ; mov r0,r7
    c.r[1] = c.r[9];  // 0604F52C mov r9,r1
    c.r[1] += 80;  // 0604F52E add #80,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604F5A2u);  // 0604F530 mov.w 0x0604F5A2,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F5A4u);  // 0604F532 mov.w 0x0604F5A4,r0
    c.r[2] = ld32(c.r[1]);  // 0604F534 mov.l @r1,r2
    c.r[4] = 0u - c.r[7];  // 0604F536 neg r7,r4
    c.r[2] += c.r[7];  // 0604F538 add r7,r2
    st32(c.r[1], c.r[2]);  // 0604F53A mov.l r2,@r1
    c.r[1] = c.r[3];  // 0604F53C mov r3,r1
    c.r[1] -= 1;  // 0604F53E add #-1,r1
    st16(c.r[11], c.r[1]);  // 0604F540 mov.w r1,@r11
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F542 mov.w @r10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F5A6u);  // 0604F544 mov.w 0x0604F5A6,r1
    c.r[3] = c.r[2];  // 0604F546 mov r2,r3
    c.r[3] &= c.r[8];  // 0604F548 and r8,r3
    c.r[3] += 1;  // 0604F54A add #1,r3
    c.r[3] &= c.r[8];  // 0604F54C and r8,r3
    c.r[2] &= c.r[1];  // 0604F54E and r1,r2
    c.r[2] |= c.r[3];  // 0604F550 or r3,r2
    st16(c.r[10], c.r[2]);  // 0604F552 mov.w r2,@r10
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0604F554 mov.l @(r0,r9),r1
    c.r[1] += c.r[7];  // 0604F556 add r7,r1
    st32(c.r[0] + c.r[9], c.r[1]);  // 0604F558 mov.l r1,@(r0,r9)
    c.r[1] = ld32(0x0604F5BCu);  // 0604F55A mov.l 0x0604F5BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F560u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F560u) return; }  // 0604F55C jsr @r1 ; mov #0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F560 mov.w @r10,r1
    c.r[8] &= c.r[1];  // 0604F562 and r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604F564 mov.b @r12,r1
    c.macl = c.r[8] * c.r[1];  // 0604F566 mul.l r1,r8
    c.r[0] = c.macl;  // 0604F568 sts macl,r0
    c.r[0] &= 0xFu;  // 0604F56A and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F56C tst r0,r0
    if (!c.t) { goto L_0604F64A; }  // 0604F56E bf 0x0604F64A
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604F570 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0604F572 mov r1,r0
    c.r[0] >>= 2;  // 0604F574 shlr2 r0
    c.r[0] &= 0x1u;  // 0604F576 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F578 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604F59A; } }  // 0604F57A bt/s 0x0604F59A ; mov r9,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604F57E mov.w @r9,r1
    c.r[5] = 0x1u;  // 0604F580 mov #1,r5
    c.r[4] = 0x2u;  // 0604F582 mov #2,r4
    c.r[0] = c.r[1];  // 0604F584 mov r1,r0
    c.r[0] >>= 2;  // 0604F586 shlr2 r0
    c.r[0] >>= 2;  // 0604F588 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604F58A shlr r0
    c.r[0] >>= 2;  // 0604F58C shlr2 r0
    c.r[0] &= 0x7u;  // 0604F58E and #7,r0
    c.r[0] += 1;  // 0604F590 add #1,r0
    c.r[1] = ld32(0x0604F5C0u);  // 0604F592 mov.l 0x0604F5C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F598u; c.r[6] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F598u) return; }  // 0604F594 jsr @r1 ; extu.b r0,r6
    c.r[1] = c.r[9];  // 0604F598 mov r9,r1
L_0604F59A:
    c.r[1] += 78;  // 0604F59A add #78,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F59C mov.b @r1,r2
    c.r[2] += 1; goto L_0604F638;  // 0604F59E bra 0x0604F638 ; add #1,r2
L_0604F5C4:
    c.r[1] = c.r[9];  // 0604F5C4 mov r9,r1
    c.r[1] += 80;  // 0604F5C6 add #80,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604F708u);  // 0604F5C8 mov.w 0x0604F708,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F70Au);  // 0604F5CA mov.w 0x0604F70A,r0
    c.r[2] = ld32(c.r[1]);  // 0604F5CC mov.l @r1,r2
    c.r[5] = 0x0u;  // 0604F5CE mov #0,r5
    c.r[2] -= c.r[7];  // 0604F5D0 sub r7,r2
    st32(c.r[1], c.r[2]);  // 0604F5D2 mov.l r2,@r1
    c.r[1] = c.r[3];  // 0604F5D4 mov r3,r1
    c.r[1] += 1;  // 0604F5D6 add #1,r1
    st16(c.r[11], c.r[1]);  // 0604F5D8 mov.w r1,@r11
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F5DA mov.w @r10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F70Cu);  // 0604F5DC mov.w 0x0604F70C,r1
    c.r[3] = c.r[2];  // 0604F5DE mov r2,r3
    c.r[3] &= c.r[8];  // 0604F5E0 and r8,r3
    c.r[3] += 1;  // 0604F5E2 add #1,r3
    c.r[3] &= c.r[8];  // 0604F5E4 and r8,r3
    c.r[2] &= c.r[1];  // 0604F5E6 and r1,r2
    c.r[2] |= c.r[3];  // 0604F5E8 or r3,r2
    st16(c.r[10], c.r[2]);  // 0604F5EA mov.w r2,@r10
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0604F5EC mov.l @(r0,r9),r1
    c.r[1] -= c.r[7];  // 0604F5EE sub r7,r1
    st32(c.r[0] + c.r[9], c.r[1]);  // 0604F5F0 mov.l r1,@(r0,r9)
    c.r[1] = ld32(0x0604F710u);  // 0604F5F2 mov.l 0x0604F710,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F5F8u; c.r[4] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F5F8u) return; }  // 0604F5F4 jsr @r1 ; mov r7,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F5F8 mov.w @r10,r1
    c.r[8] &= c.r[1];  // 0604F5FA and r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604F5FC mov.b @r12,r1
    c.macl = c.r[8] * c.r[1];  // 0604F5FE mul.l r1,r8
    c.r[0] = c.macl;  // 0604F600 sts macl,r0
    c.r[0] &= 0xFu;  // 0604F602 and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F604 tst r0,r0
    if (!c.t) { goto L_0604F64A; }  // 0604F606 bf 0x0604F64A
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604F608 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0604F60A mov r1,r0
    c.r[0] >>= 2;  // 0604F60C shlr2 r0
    c.r[0] &= 0x1u;  // 0604F60E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F610 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604F632; } }  // 0604F612 bt/s 0x0604F632 ; mov r9,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604F616 mov.w @r9,r1
    c.r[5] = 0x1u;  // 0604F618 mov #1,r5
    c.r[4] = 0x1u;  // 0604F61A mov #1,r4
    c.r[0] = c.r[1];  // 0604F61C mov r1,r0
    c.r[0] >>= 2;  // 0604F61E shlr2 r0
    c.r[0] >>= 2;  // 0604F620 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604F622 shlr r0
    c.r[0] >>= 2;  // 0604F624 shlr2 r0
    c.r[0] &= 0x7u;  // 0604F626 and #7,r0
    c.r[0] += 1;  // 0604F628 add #1,r0
    c.r[1] = ld32(0x0604F714u);  // 0604F62A mov.l 0x0604F714,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F630u; c.r[6] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F630u) return; }  // 0604F62C jsr @r1 ; extu.b r0,r6
    c.r[1] = c.r[9];  // 0604F630 mov r9,r1
L_0604F632:
    c.r[1] += 78;  // 0604F632 add #78,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F634 mov.b @r1,r2
    c.r[2] -= 1;  // 0604F636 add #-1,r2
L_0604F638:
    st8(c.r[1], c.r[2]);  // 0604F638 mov.b r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604F63A mov.w @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604F63C tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0604F64A; } }  // 0604F63E bf/s 0x0604F64A ; mov #0,r1
    st16(c.r[11], c.r[1]);  // 0604F642 mov.w r1,@r11
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0604F644 mov.b @r10,r0
    c.r[0] &= 0xBFu;  // 0604F646 and #191,r0
    st8(c.r[10], c.r[0]);  // 0604F648 mov.b r0,@r10
L_0604F64A:
    c.r[9] = ld32(0x0604F718u);  // 0604F64A mov.l 0x0604F718,r9
    c.r[10] = c.r[9];  // 0604F64C mov r9,r10
    c.r[10] += 122;  // 0604F64E add #122,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0604F650 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0604F652 mov r1,r0
    c.r[0] >>= 2;  // 0604F654 shlr2 r0
    c.r[0] >>= 2;  // 0604F656 shlr2 r0
    c.r[0] >>= 2;  // 0604F658 shlr2 r0
    c.r[0] &= 0x1u;  // 0604F65A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F65C tst r0,r0
    { const bool k = !c.t; c.r[12] = c.r[9]; if (k) { goto L_0604F666; } }  // 0604F65E bf/s 0x0604F666 ; mov r9,r12
    goto L_0604F7B2;  // 0604F662 bra 0x0604F7B2 ; nop
L_0604F666:
    c.r[12] += 127;  // 0604F666 add #127,r12
    c.r[1] = ld32(0x0604F71Cu);  // 0604F668 mov.l 0x0604F71C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F66Eu; c.r[4] = (uint32_t)(int8_t)ld8(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F66Eu) return; }  // 0604F66A jsr @r1 ; mov.b @r12,r4
    c.r[4] = c.r[0];  // 0604F66E mov r0,r4
    c.r[5] = c.r[1];  // 0604F670 mov r1,r5
    c.r[1] = ld32(0x0604F720u);  // 0604F672 mov.l 0x0604F720,r1
    c.r[6] = ld32(c.r[1]);  // 0604F674 mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0604F676 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0604F724u);  // 0604F678 mov.l 0x0604F724,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F67Eu; c.r[11] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F67Eu) return; }  // 0604F67A jsr @r1 ; mov r9,r11
    c.r[4] = c.r[0];  // 0604F67E mov r0,r4
    c.r[5] = c.r[1];  // 0604F680 mov r1,r5
    c.r[0] = ld32(0x0604F728u);  // 0604F682 mov.l 0x0604F728,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604F688u; c.r[11] += 124; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F688u) return; }  // 0604F684 jsr @r0 ; add #124,r11
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604F688 mov.w @r11,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0604F68A exts.w r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0604F68C cmp/pl r1
    { const bool k = !c.t; c.r[7] = c.r[0]; if (k) { goto L_0604F72C; } }  // 0604F68E bf/s 0x0604F72C ; mov r0,r7
    c.r[1] = c.r[9];  // 0604F692 mov r9,r1
    c.r[1] += 84;  // 0604F694 add #84,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604F708u);  // 0604F696 mov.w 0x0604F708,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F70Eu);  // 0604F698 mov.w 0x0604F70E,r0
    c.r[2] = ld32(c.r[1]);  // 0604F69A mov.l @r1,r2
    c.r[5] = 0u - c.r[7];  // 0604F69C neg r7,r5
    c.r[2] += c.r[7];  // 0604F69E add r7,r2
    st32(c.r[1], c.r[2]);  // 0604F6A0 mov.l r2,@r1
    c.r[1] = c.r[3];  // 0604F6A2 mov r3,r1
    c.r[1] -= 1;  // 0604F6A4 add #-1,r1
    st16(c.r[11], c.r[1]);  // 0604F6A6 mov.w r1,@r11
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F6A8 mov.w @r10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F70Cu);  // 0604F6AA mov.w 0x0604F70C,r1
    c.r[3] = c.r[2];  // 0604F6AC mov r2,r3
    c.r[3] &= c.r[8];  // 0604F6AE and r8,r3
    c.r[3] += 1;  // 0604F6B0 add #1,r3
    c.r[3] &= c.r[8];  // 0604F6B2 and r8,r3
    c.r[2] &= c.r[1];  // 0604F6B4 and r1,r2
    c.r[2] |= c.r[3];  // 0604F6B6 or r3,r2
    st16(c.r[10], c.r[2]);  // 0604F6B8 mov.w r2,@r10
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0604F6BA mov.l @(r0,r9),r1
    c.r[1] += c.r[7];  // 0604F6BC add r7,r1
    st32(c.r[0] + c.r[9], c.r[1]);  // 0604F6BE mov.l r1,@(r0,r9)
    c.r[1] = ld32(0x0604F710u);  // 0604F6C0 mov.l 0x0604F710,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F6C6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F6C6u) return; }  // 0604F6C2 jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F6C6 mov.w @r10,r1
    c.r[8] &= c.r[1];  // 0604F6C8 and r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604F6CA mov.b @r12,r1
    c.macl = c.r[8] * c.r[1];  // 0604F6CC mul.l r1,r8
    c.r[0] = c.macl;  // 0604F6CE sts macl,r0
    c.r[0] &= 0xFu;  // 0604F6D0 and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F6D2 tst r0,r0
    if (!c.t) { goto L_0604F7B2; }  // 0604F6D4 bf 0x0604F7B2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604F6D6 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0604F6D8 mov r1,r0
    c.r[0] >>= 2;  // 0604F6DA shlr2 r0
    c.r[0] &= 0x1u;  // 0604F6DC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F6DE tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604F700; } }  // 0604F6E0 bt/s 0x0604F700 ; mov r9,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604F6E4 mov.w @r9,r1
    c.r[5] = 0x1u;  // 0604F6E6 mov #1,r5
    c.r[4] = 0x4u;  // 0604F6E8 mov #4,r4
    c.r[0] = c.r[1];  // 0604F6EA mov r1,r0
    c.r[0] >>= 2;  // 0604F6EC shlr2 r0
    c.r[0] >>= 2;  // 0604F6EE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604F6F0 shlr r0
    c.r[0] >>= 2;  // 0604F6F2 shlr2 r0
    c.r[0] &= 0x7u;  // 0604F6F4 and #7,r0
    c.r[0] += 1;  // 0604F6F6 add #1,r0
    c.r[1] = ld32(0x0604F714u);  // 0604F6F8 mov.l 0x0604F714,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F6FEu; c.r[6] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F6FEu) return; }  // 0604F6FA jsr @r1 ; extu.b r0,r6
    c.r[1] = c.r[9];  // 0604F6FE mov r9,r1
L_0604F700:
    c.r[1] += 79;  // 0604F700 add #79,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F702 mov.b @r1,r2
    c.r[2] += 1; goto L_0604F7A0;  // 0604F704 bra 0x0604F7A0 ; add #1,r2
L_0604F72C:
    c.r[1] = c.r[9];  // 0604F72C mov r9,r1
    c.r[1] += 84;  // 0604F72E add #84,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604F7C4u);  // 0604F730 mov.w 0x0604F7C4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F7C6u);  // 0604F732 mov.w 0x0604F7C6,r0
    c.r[2] = ld32(c.r[1]);  // 0604F734 mov.l @r1,r2
    c.r[5] = c.r[7];  // 0604F736 mov r7,r5
    c.r[2] -= c.r[7];  // 0604F738 sub r7,r2
    st32(c.r[1], c.r[2]);  // 0604F73A mov.l r2,@r1
    c.r[1] = c.r[3];  // 0604F73C mov r3,r1
    c.r[1] += 1;  // 0604F73E add #1,r1
    st16(c.r[11], c.r[1]);  // 0604F740 mov.w r1,@r11
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F742 mov.w @r10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604F7C8u);  // 0604F744 mov.w 0x0604F7C8,r1
    c.r[3] = c.r[2];  // 0604F746 mov r2,r3
    c.r[3] &= c.r[8];  // 0604F748 and r8,r3
    c.r[3] += 1;  // 0604F74A add #1,r3
    c.r[3] &= c.r[8];  // 0604F74C and r8,r3
    c.r[2] &= c.r[1];  // 0604F74E and r1,r2
    c.r[2] |= c.r[3];  // 0604F750 or r3,r2
    st16(c.r[10], c.r[2]);  // 0604F752 mov.w r2,@r10
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0604F754 mov.l @(r0,r9),r1
    c.r[1] -= c.r[7];  // 0604F756 sub r7,r1
    st32(c.r[0] + c.r[9], c.r[1]);  // 0604F758 mov.l r1,@(r0,r9)
    c.r[1] = ld32(0x0604F7CCu);  // 0604F75A mov.l 0x0604F7CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F760u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F760u) return; }  // 0604F75C jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604F760 mov.w @r10,r1
    c.r[8] &= c.r[1];  // 0604F762 and r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604F764 mov.b @r12,r1
    c.macl = c.r[8] * c.r[1];  // 0604F766 mul.l r1,r8
    c.r[0] = c.macl;  // 0604F768 sts macl,r0
    c.r[0] &= 0xFu;  // 0604F76A and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F76C tst r0,r0
    if (!c.t) { goto L_0604F7B2; }  // 0604F76E bf 0x0604F7B2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604F770 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0604F772 mov r1,r0
    c.r[0] >>= 2;  // 0604F774 shlr2 r0
    c.r[0] &= 0x1u;  // 0604F776 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F778 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604F79A; } }  // 0604F77A bt/s 0x0604F79A ; mov r9,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604F77E mov.w @r9,r1
    c.r[5] = 0x1u;  // 0604F780 mov #1,r5
    c.r[4] = 0x3u;  // 0604F782 mov #3,r4
    c.r[0] = c.r[1];  // 0604F784 mov r1,r0
    c.r[0] >>= 2;  // 0604F786 shlr2 r0
    c.r[0] >>= 2;  // 0604F788 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604F78A shlr r0
    c.r[0] >>= 2;  // 0604F78C shlr2 r0
    c.r[0] &= 0x7u;  // 0604F78E and #7,r0
    c.r[0] += 1;  // 0604F790 add #1,r0
    c.r[1] = ld32(0x0604F7D0u);  // 0604F792 mov.l 0x0604F7D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F798u; c.r[6] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F798u) return; }  // 0604F794 jsr @r1 ; extu.b r0,r6
    c.r[1] = c.r[9];  // 0604F798 mov r9,r1
L_0604F79A:
    c.r[1] += 79;  // 0604F79A add #79,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F79C mov.b @r1,r2
    c.r[2] -= 1;  // 0604F79E add #-1,r2
L_0604F7A0:
    st8(c.r[1], c.r[2]);  // 0604F7A0 mov.b r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604F7A2 mov.w @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604F7A4 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0604F7B2; } }  // 0604F7A6 bf/s 0x0604F7B2 ; mov #0,r1
    st16(c.r[11], c.r[1]);  // 0604F7AA mov.w r1,@r11
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0604F7AC mov.b @r10,r0
    c.r[0] &= 0xBFu;  // 0604F7AE and #191,r0
    st8(c.r[10], c.r[0]);  // 0604F7B0 mov.b r0,@r10
L_0604F7B2:
    c.r[15] = c.r[14];  // 0604F7B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F7B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604F7B6 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604F7B8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604F7BA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604F7BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604F7BE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F7C0 rts ; mov.l @r15+,r8
}

void f_0604F7D4(SH2Context& c) {
    ran[1264] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F7D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F7D6 sts.l pr,@-r15
    c.r[1] = ld32(0x0604F800u);  // 0604F7D8 mov.l 0x0604F800,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604F7DA mov.w @r1,r2
    c.r[3] = ld32(0x0604F804u);  // 0604F7DC mov.l 0x0604F804,r3
    c.r[1] = 0xAu;  // 0604F7DE mov #10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604F7E0 mulu.w r1,r2
    c.r[5] = ld32(c.r[3] + 8);  // 0604F7E2 mov.l @(8,r3),r5
    c.r[1] = c.macl;  // 0604F7E4 sts macl,r1
    c.r[5] += c.r[1];  // 0604F7E6 add r1,r5
    c.r[1] = 0xCu;  // 0604F7E8 mov #12,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604F7EA mulu.w r1,r2
    c.r[4] = ld32(c.r[3] + 12);  // 0604F7EC mov.l @(12,r3),r4
    c.r[1] = c.macl;  // 0604F7EE sts macl,r1
    c.r[4] += c.r[1];  // 0604F7F0 add r1,r4
    c.r[1] = ld32(0x0604F808u);  // 0604F7F2 mov.l 0x0604F808,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F7F8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F7F8u) return; }  // 0604F7F4 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0604F7F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F7FA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F7FC rts ; mov.l @r15+,r14
}

void f_0604F814(SH2Context& c) {
    ran[1265] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604F814 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604F816 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604F818 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604F81A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604F81C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604F81E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F820 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F822 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604F824 mov r15,r14
    c.r[10] = ld32(0x0604F894u);  // 0604F826 mov.l 0x0604F894,r10
    c.r[12] = ld32(0x0604F898u);  // 0604F828 mov.l 0x0604F898,r12
    c.r[1] = c.r[12];  // 0604F82A mov r12,r1
    c.r[11] = ld32(c.r[10] + 12);  // 0604F82C mov.l @(12,r10),r11
    c.r[1] += 112;  // 0604F82E add #112,r1
    c.r[2] = ld32(0x0604F89Cu);  // 0604F830 mov.l 0x0604F89C,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0604F836u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F836u) return; }  // 0604F832 jsr @r2 ; mov.w @r1,r4
    c.r[4] = c.r[0];  // 0604F836 mov r0,r4
    c.r[5] = c.r[1];  // 0604F838 mov r1,r5
    c.r[1] = ld32(0x0604F8A0u);  // 0604F83A mov.l 0x0604F8A0,r1
    c.r[8] = ld32(c.r[1]);  // 0604F83C mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0604F83E mov.l @(4,r1),r9
    c.r[2] = ld32(0x0604F8A4u);  // 0604F840 mov.l 0x0604F8A4,r2
    c.r[6] = c.r[8];  // 0604F842 mov r8,r6
    { const uint32_t x = c.r[2]; c.pr = 0x0604F848u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F848u) return; }  // 0604F844 jsr @r2 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604F848 mov r0,r4
    c.r[2] = ld32(0x0604F8A8u);  // 0604F84A mov.l 0x0604F8A8,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0604F850u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F850u) return; }  // 0604F84C jsr @r2 ; mov r1,r5
    st32(c.r[11] + 12, c.r[0]);  // 0604F850 mov.l r0,@(12,r11)
    c.r[12] += 114;  // 0604F852 add #114,r12
    c.r[13] = ld32(c.r[10] + 12);  // 0604F854 mov.l @(12,r10),r13
    c.r[2] = ld32(0x0604F89Cu);  // 0604F856 mov.l 0x0604F89C,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0604F858 mov.w @r12,r4
    { const uint32_t x = c.r[2]; c.pr = 0x0604F85Eu; c.r[13] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F85Eu) return; }  // 0604F85A jsr @r2 ; add #12,r13
    c.r[4] = c.r[0];  // 0604F85E mov r0,r4
    c.r[5] = c.r[1];  // 0604F860 mov r1,r5
    c.r[6] = c.r[8];  // 0604F862 mov r8,r6
    c.r[2] = ld32(0x0604F8A4u);  // 0604F864 mov.l 0x0604F8A4,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0604F86Au; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F86Au) return; }  // 0604F866 jsr @r2 ; mov r9,r7
    c.r[4] = c.r[0];  // 0604F86A mov r0,r4
    c.r[2] = ld32(0x0604F8A8u);  // 0604F86C mov.l 0x0604F8A8,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0604F872u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F872u) return; }  // 0604F86E jsr @r2 ; mov r1,r5
    st32(c.r[13] + 4, c.r[0]);  // 0604F872 mov.l r0,@(4,r13)
    c.r[5] = ld32(c.r[10] + 8);  // 0604F874 mov.l @(8,r10),r5
    c.r[1] = ld32(0x0604F8ACu);  // 0604F876 mov.l 0x0604F8AC,r1
    c.r[4] = ld32(c.r[10] + 12);  // 0604F878 mov.l @(12,r10),r4
    c.r[5] += 10;  // 0604F87A add #10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604F880u; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F880u) return; }  // 0604F87C jsr @r1 ; add #12,r4
    c.r[15] = c.r[14];  // 0604F880 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F882 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604F884 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604F886 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604F888 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604F88A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604F88C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604F88E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F890 rts ; mov.l @r15+,r8
}

void f_0604F8B0(SH2Context& c) {
    ran[1266] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0604F8B0 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0604F8B2 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F8B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F8B6 sts.l pr,@-r15
    c.r[7] = ld32(0x0604F968u);  // 0604F8B8 mov.l 0x0604F968,r7
    c.r[6] = c.r[7];  // 0604F8BA mov r7,r6
    c.r[6] += 17;  // 0604F8BC add #17,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604F8BE mov.b @r6,r2
    c.r[1] = ld32(0x0604F96Cu);  // 0604F8C0 mov.l 0x0604F96C,r1
    c.r[1] = ld32(c.r[1]);  // 0604F8C2 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604F8C4 extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0604F8C6 dmulu.l r1,r2
    c.r[1] = c.mach;  // 0604F8C8 sts mach,r1
    c.r[1] >>= 2;  // 0604F8CA shlr2 r1
    c.r[1] >>= 2;  // 0604F8CC shlr2 r1
    c.r[3] = c.r[1];  // 0604F8CE mov r1,r3
    c.r[3] <<= 2;  // 0604F8D0 shll2 r3
    c.r[3] += c.r[1];  // 0604F8D2 add r1,r3
    c.r[3] <<= 2;  // 0604F8D4 shll2 r3
    c.r[2] -= c.r[3];  // 0604F8D6 sub r3,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604F8D8 extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604F8DA tst r2,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604F906; } }  // 0604F8DC bf/s 0x0604F906 ; mov r15,r14
    c.r[1] = c.r[7];  // 0604F8E0 mov r7,r1
    c.r[1] += 16;  // 0604F8E2 add #16,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F8E4 mov.b @r1,r2
    c.r[0] = 0x1u;  // 0604F8E6 mov #1,r0
    c.r[3] = c.r[2];  // 0604F8E8 mov r2,r3
    c.r[3] >>= 2;  // 0604F8EA shlr2 r3
    c.r[3] >>= 2;  // 0604F8EC shlr2 r3
    c.r[3] >>= 2;  // 0604F8EE shlr2 r3
    c.r[3] &= c.r[0];  // 0604F8F0 and r0,r3
    c.r[3] ^= c.r[0];  // 0604F8F2 xor r0,r3
    c.r[3] <<= 2;  // 0604F8F4 shll2 r3
    c.r[3] <<= 2;  // 0604F8F6 shll2 r3
    c.r[3] <<= 2;  // 0604F8F8 shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F964u);  // 0604F8FA mov.w 0x0604F964,r0
    c.r[2] &= c.r[0];  // 0604F8FC and r0,r2
    c.r[2] |= c.r[3];  // 0604F8FE or r3,r2
    st8(c.r[1], c.r[2]);  // 0604F900 mov.b r2,@r1
    c.r[1] = 0x0u;  // 0604F902 mov #0,r1
    st8(c.r[6], c.r[1]);  // 0604F904 mov.b r1,@r6
L_0604F906:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604F906 mov.b @r6,r1
    c.r[7] += 16;  // 0604F908 add #16,r7
    c.r[1] += 1;  // 0604F90A add #1,r1
    st8(c.r[6], c.r[1]);  // 0604F90C mov.b r1,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604F90E mov.b @r7,r1
    c.r[0] = c.r[1];  // 0604F910 mov r1,r0
    c.r[0] >>= 2;  // 0604F912 shlr2 r0
    c.r[0] >>= 2;  // 0604F914 shlr2 r0
    c.r[0] >>= 2;  // 0604F916 shlr2 r0
    c.r[0] &= 0x1u;  // 0604F918 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F91A tst r0,r0
    if (c.t) { goto L_0604F95C; }  // 0604F91C bt 0x0604F95C
    c.r[1] = ld32(0x0604F970u);  // 0604F91E mov.l 0x0604F970,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604F920 mov.w @r1,r3
    c.r[2] = ld32(0x0604F974u);  // 0604F922 mov.l 0x0604F974,r2
    c.r[7] = ld32(c.r[2] + 12);  // 0604F924 mov.l @(12,r2),r7
    c.r[1] = c.r[3] & 0xFFFFu;  // 0604F926 extu.w r3,r1
    c.r[6] = c.r[1];  // 0604F928 mov r1,r6
    c.r[6] += c.r[6];  // 0604F92A add r6,r6
    c.r[6] += c.r[1];  // 0604F92C add r1,r6
    c.r[6] <<= 2;  // 0604F92E shll2 r6
    c.r[1] = ld32(0x0604F978u);  // 0604F930 mov.l 0x0604F978,r1
    c.r[1] = ld32(c.r[1]);  // 0604F932 mov.l @r1,r1
    c.r[0] = c.r[6];  // 0604F934 mov r6,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0604F936 mov.l r1,@(r0,r7)
    c.r[1] = ld32(c.r[2] + 12);  // 0604F938 mov.l @(12,r2),r1
    c.r[6] += c.r[1];  // 0604F93A add r1,r6
    c.r[1] = ld32(0x0604F97Cu);  // 0604F93C mov.l 0x0604F97C,r1
    c.r[1] = ld32(c.r[1]);  // 0604F93E mov.l @r1,r1
    st32(c.r[6] + 4, c.r[1]);  // 0604F940 mov.l r1,@(4,r6)
    c.r[1] = 0xAu;  // 0604F942 mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604F944 mulu.w r1,r3
    c.r[5] = ld32(c.r[2] + 8);  // 0604F946 mov.l @(8,r2),r5
    c.r[1] = c.macl;  // 0604F948 sts macl,r1
    c.r[5] += c.r[1];  // 0604F94A add r1,r5
    c.r[1] = 0xCu;  // 0604F94C mov #12,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604F94E mulu.w r1,r3
    c.r[4] = ld32(c.r[2] + 12);  // 0604F950 mov.l @(12,r2),r4
    c.r[1] = c.macl;  // 0604F952 sts macl,r1
    c.r[4] += c.r[1];  // 0604F954 add r1,r4
    c.r[1] = ld32(0x0604F980u);  // 0604F956 mov.l 0x0604F980,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F95Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F95Cu) return; }  // 0604F958 jsr @r1 ; nop
L_0604F95C:
    c.r[15] = c.r[14];  // 0604F95C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F95E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F960 rts ; mov.l @r15+,r14
}

void f_0604F8B4(SH2Context& c) {
    ran[1267] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F8B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F8B6 sts.l pr,@-r15
    c.r[7] = ld32(0x0604F968u);  // 0604F8B8 mov.l 0x0604F968,r7
    c.r[6] = c.r[7];  // 0604F8BA mov r7,r6
    c.r[6] += 17;  // 0604F8BC add #17,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604F8BE mov.b @r6,r2
    c.r[1] = ld32(0x0604F96Cu);  // 0604F8C0 mov.l 0x0604F96C,r1
    c.r[1] = ld32(c.r[1]);  // 0604F8C2 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604F8C4 extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0604F8C6 dmulu.l r1,r2
    c.r[1] = c.mach;  // 0604F8C8 sts mach,r1
    c.r[1] >>= 2;  // 0604F8CA shlr2 r1
    c.r[1] >>= 2;  // 0604F8CC shlr2 r1
    c.r[3] = c.r[1];  // 0604F8CE mov r1,r3
    c.r[3] <<= 2;  // 0604F8D0 shll2 r3
    c.r[3] += c.r[1];  // 0604F8D2 add r1,r3
    c.r[3] <<= 2;  // 0604F8D4 shll2 r3
    c.r[2] -= c.r[3];  // 0604F8D6 sub r3,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604F8D8 extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604F8DA tst r2,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604F906; } }  // 0604F8DC bf/s 0x0604F906 ; mov r15,r14
    c.r[1] = c.r[7];  // 0604F8E0 mov r7,r1
    c.r[1] += 16;  // 0604F8E2 add #16,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F8E4 mov.b @r1,r2
    c.r[0] = 0x1u;  // 0604F8E6 mov #1,r0
    c.r[3] = c.r[2];  // 0604F8E8 mov r2,r3
    c.r[3] >>= 2;  // 0604F8EA shlr2 r3
    c.r[3] >>= 2;  // 0604F8EC shlr2 r3
    c.r[3] >>= 2;  // 0604F8EE shlr2 r3
    c.r[3] &= c.r[0];  // 0604F8F0 and r0,r3
    c.r[3] ^= c.r[0];  // 0604F8F2 xor r0,r3
    c.r[3] <<= 2;  // 0604F8F4 shll2 r3
    c.r[3] <<= 2;  // 0604F8F6 shll2 r3
    c.r[3] <<= 2;  // 0604F8F8 shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604F964u);  // 0604F8FA mov.w 0x0604F964,r0
    c.r[2] &= c.r[0];  // 0604F8FC and r0,r2
    c.r[2] |= c.r[3];  // 0604F8FE or r3,r2
    st8(c.r[1], c.r[2]);  // 0604F900 mov.b r2,@r1
    c.r[1] = 0x0u;  // 0604F902 mov #0,r1
    st8(c.r[6], c.r[1]);  // 0604F904 mov.b r1,@r6
L_0604F906:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604F906 mov.b @r6,r1
    c.r[7] += 16;  // 0604F908 add #16,r7
    c.r[1] += 1;  // 0604F90A add #1,r1
    st8(c.r[6], c.r[1]);  // 0604F90C mov.b r1,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604F90E mov.b @r7,r1
    c.r[0] = c.r[1];  // 0604F910 mov r1,r0
    c.r[0] >>= 2;  // 0604F912 shlr2 r0
    c.r[0] >>= 2;  // 0604F914 shlr2 r0
    c.r[0] >>= 2;  // 0604F916 shlr2 r0
    c.r[0] &= 0x1u;  // 0604F918 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604F91A tst r0,r0
    if (c.t) { goto L_0604F95C; }  // 0604F91C bt 0x0604F95C
    c.r[1] = ld32(0x0604F970u);  // 0604F91E mov.l 0x0604F970,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604F920 mov.w @r1,r3
    c.r[2] = ld32(0x0604F974u);  // 0604F922 mov.l 0x0604F974,r2
    c.r[7] = ld32(c.r[2] + 12);  // 0604F924 mov.l @(12,r2),r7
    c.r[1] = c.r[3] & 0xFFFFu;  // 0604F926 extu.w r3,r1
    c.r[6] = c.r[1];  // 0604F928 mov r1,r6
    c.r[6] += c.r[6];  // 0604F92A add r6,r6
    c.r[6] += c.r[1];  // 0604F92C add r1,r6
    c.r[6] <<= 2;  // 0604F92E shll2 r6
    c.r[1] = ld32(0x0604F978u);  // 0604F930 mov.l 0x0604F978,r1
    c.r[1] = ld32(c.r[1]);  // 0604F932 mov.l @r1,r1
    c.r[0] = c.r[6];  // 0604F934 mov r6,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0604F936 mov.l r1,@(r0,r7)
    c.r[1] = ld32(c.r[2] + 12);  // 0604F938 mov.l @(12,r2),r1
    c.r[6] += c.r[1];  // 0604F93A add r1,r6
    c.r[1] = ld32(0x0604F97Cu);  // 0604F93C mov.l 0x0604F97C,r1
    c.r[1] = ld32(c.r[1]);  // 0604F93E mov.l @r1,r1
    st32(c.r[6] + 4, c.r[1]);  // 0604F940 mov.l r1,@(4,r6)
    c.r[1] = 0xAu;  // 0604F942 mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604F944 mulu.w r1,r3
    c.r[5] = ld32(c.r[2] + 8);  // 0604F946 mov.l @(8,r2),r5
    c.r[1] = c.macl;  // 0604F948 sts macl,r1
    c.r[5] += c.r[1];  // 0604F94A add r1,r5
    c.r[1] = 0xCu;  // 0604F94C mov #12,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604F94E mulu.w r1,r3
    c.r[4] = ld32(c.r[2] + 12);  // 0604F950 mov.l @(12,r2),r4
    c.r[1] = c.macl;  // 0604F952 sts macl,r1
    c.r[4] += c.r[1];  // 0604F954 add r1,r4
    c.r[1] = ld32(0x0604F980u);  // 0604F956 mov.l 0x0604F980,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F95Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F95Cu) return; }  // 0604F958 jsr @r1 ; nop
L_0604F95C:
    c.r[15] = c.r[14];  // 0604F95C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604F95E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604F960 rts ; mov.l @r15+,r14
}

void f_0604F984(SH2Context& c) {
    ran[1268] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604F984 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604F986 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604F988 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604F98A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604F98C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604F98E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604F990 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604F992 sts.l pr,@-r15
    c.r[2] = ld32(0x0604FA20u);  // 0604F994 mov.l 0x0604FA20,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604F996 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F998 extu.b r1,r1
    c.r[1] >>= 2;  // 0604F99A shlr2 r1
    c.r[1] >>= 2;  // 0604F99C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604F99E shlr r1
    c.r[1] >>= 2;  // 0604F9A0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604F9A2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604FA0A; } }  // 0604F9A4 bt/s 0x0604FA0A ; mov r15,r14
    c.r[1] = ld32(0x0604FA24u);  // 0604F9A8 mov.l 0x0604FA24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F9AA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604F9AC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604F9AE tst r1,r1
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0604FA0A; } }  // 0604F9B0 bf/s 0x0604FA0A ; mov #0,r10
    c.r[11] = c.r[2];  // 0604F9B4 mov r2,r11
    c.r[12] = 0x20u;  // 0604F9B6 mov #32,r12
    c.r[13] = ld32(0x0604FA28u);  // 0604F9B8 mov.l 0x0604FA28,r13
    c.r[8] = c.r[11];  // 0604F9BA mov r11,r8
    c.r[9] = 0x0u;  // 0604F9BC mov #0,r9
L_0604F9BE:
    c.r[4] = ld32(c.r[8] + 4);  // 0604F9BE mov.l @(4,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0604F9C0 tst r4,r4
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_0604F9F4; } }  // 0604F9C2 bt/s 0x0604F9F4 ; mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0604F9C6 mov.b @(r0,r11),r1
    c.r[0] = 0x7Fu;  // 0604F9C8 mov #127,r0
    c.r[1] &= c.r[0];  // 0604F9CA and r0,r1
    c.macl = c.r[1] * c.r[12];  // 0604F9CC mul.l r12,r1
    c.r[1] = c.r[8];  // 0604F9CE mov r8,r1
    c.r[1] += 8;  // 0604F9D0 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F9D2 mov.b @r1,r1
    c.r[6] = c.macl;  // 0604F9D4 sts macl,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604F9D6 extu.b r1,r1
    c.macl = c.r[1] * c.r[12];  // 0604F9D8 mul.l r12,r1
    c.r[7] = 0xEu;  // 0604F9DA mov #14,r7
    c.r[5] = c.macl;  // 0604F9DC sts macl,r5
    c.r[1] = ld32(0x0604FA2Cu);  // 0604F9DE mov.l 0x0604FA2C,r1
    { const uint32_t x = c.r[13]; c.pr = 0x0604F9E4u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F9E4u) return; }  // 0604F9E0 jsr @r13 ; add r1,r5
    c.r[1] = 0x0u;  // 0604F9E4 mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 0604F9E6 mov.l r1,@(4,r8)
    c.r[8] += 12;  // 0604F9E8 add #12,r8
    c.r[10] += 1;  // 0604F9EA add #1,r10
    c.r[1] = 0xFu;  // 0604F9EC mov #15,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0604F9EE cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 12; if (k) { SH2_POLL(c); goto L_0604F9BE; } }  // 0604F9F0 bf/s 0x0604F9BE ; add #12,r9
L_0604F9F4:
    c.r[1] = ld32(0x0604FA30u);  // 0604F9F4 mov.l 0x0604FA30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604F9FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604F9FAu) return; }  // 0604F9F6 jsr @r1 ; nop
    c.r[1] = c.r[11];  // 0604F9FA mov r11,r1
    c.r[1] += 12;  // 0604F9FC add #12,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604F9FE mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0604FA00 and #127,r0
    st8(c.r[1], c.r[0]);  // 0604FA02 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0604FA04 mov.b @r11,r0
    c.r[0] &= 0x7Fu;  // 0604FA06 and #127,r0
    st8(c.r[11], c.r[0]);  // 0604FA08 mov.b r0,@r11
L_0604FA0A:
    c.r[15] = c.r[14];  // 0604FA0A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604FA0C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA0E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA10 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA12 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA14 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA16 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA18 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604FA1A rts ; mov.l @r15+,r8
}

void f_0604FA34(SH2Context& c) {
    ran[1269] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604FA34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604FA36 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604FA38 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0604FA3A extu.b r4,r4
    c.r[6] = 0x0u;  // 0604FA3C mov #0,r6
    c.r[3] = 0x0u;  // 0604FA3E mov #0,r3
    c.r[8] = 0xFu;  // 0604FA40 mov #15,r8
    c.r[2] = ld32(0x0604FA84u);  // 0604FA42 mov.l 0x0604FA84,r2
    c.r[5] = c.r[2];  // 0604FA44 mov r2,r5
    c.r[7] = 0x0u;  // 0604FA46 mov #0,r7
L_0604FA48:
    c.r[1] = ld32(c.r[2] + 4);  // 0604FA48 mov.l @(4,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604FA4A tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_0604FA64; } }  // 0604FA4C bt/s 0x0604FA64 ; mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0604FA50 mov.b @(r0,r5),r1
    c.r[2] += 12;  // 0604FA52 add #12,r2
    c.r[7] += 12;  // 0604FA54 add #12,r7
    c.r[3] += 1;  // 0604FA56 add #1,r3
    c.t = c.r[3] > c.r[8];  // 0604FA58 cmp/hi r8,r3
    c.r[0] = 0x7Fu;  // 0604FA5A mov #127,r0
    c.r[1] &= c.r[0];  // 0604FA5C and r0,r1
    c.r[1] += c.r[6];  // 0604FA5E add r6,r1
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_0604FA48; } }  // 0604FA60 bf/s 0x0604FA48 ; extu.b r1,r6
L_0604FA64:
    c.t = (c.r[4] & c.r[4]) == 0;  // 0604FA64 tst r4,r4
    { const bool k = !c.t; c.r[2] = c.r[6]; if (k) { goto L_0604FA76; } }  // 0604FA66 bf/s 0x0604FA76 ; mov r6,r2
    c.r[2] <<= 2;  // 0604FA6A shll2 r2
    c.r[2] += c.r[2];  // 0604FA6C add r2,r2
    c.r[2] <<= 2;  // 0604FA6E shll2 r2
    c.r[1] = ld32(0x0604FA88u);  // 0604FA70 mov.l 0x0604FA88,r1
    c.r[2] += c.r[1]; goto L_0604FA78;  // 0604FA72 bra 0x0604FA78 ; add r1,r2
L_0604FA76:
    c.r[2] = c.r[3];  // 0604FA76 mov r3,r2
L_0604FA78:
    c.r[15] = c.r[14];  // 0604FA78 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA7A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0604FA7C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0604FA7E rts ; mov r2,r0
}

void f_0604FA8C(SH2Context& c) {
    ran[1270] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604FA8C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604FA8E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604FA90 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604FA92 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604FA94 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604FA96 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604FA98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604FA9A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604FA9C mov r15,r14
    c.r[9] = ld32(0x0604FB30u);  // 0604FA9E mov.l 0x0604FB30,r9
    c.r[10] = 0x4u;  // 0604FAA0 mov #4,r10
    c.r[1] = c.r[9];  // 0604FAA2 mov r9,r1
    c.r[3] = ld32(0x0604FB34u);  // 0604FAA4 mov.l 0x0604FB34,r3
    c.r[13] = ld32(0x0604FB38u);  // 0604FAA6 mov.l 0x0604FB38,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604FB2Au);  // 0604FAA8 mov.w 0x0604FB2A,r0
    c.r[11] = 0x20u;  // 0604FAAA mov #32,r11
    c.r[4] = c.r[9];  // 0604FAAC mov r9,r4
    c.r[4] += c.r[10];  // 0604FAAE add r10,r4
    c.r[12] = ld32(0x0604FB3Cu);  // 0604FAB0 mov.l 0x0604FB3C,r12
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604FAB2 mov.b @r1+,r8
    c.r[7] = 0xEu;  // 0604FAB4 mov #14,r7
    c.r[8] = c.r[8] & 0xFFu;  // 0604FAB6 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FAB8 mov.b @r1,r1
    c.r[8] <<= 8;  // 0604FABA shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604FABC extu.b r1,r1
    c.r[8] |= c.r[1];  // 0604FABE or r1,r8
    c.r[1] = 0x1u;  // 0604FAC0 mov #1,r1
    st8(c.r[3], c.r[1]);  // 0604FAC2 mov.b r1,@r3
    c.r[8] += c.r[8];  // 0604FAC4 add r8,r8
    c.r[1] = ld32(0x0604FB40u);  // 0604FAC6 mov.l 0x0604FB40,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0604FAC8 mov.w @(r0,r13),r5
    c.r[6] = c.r[8];  // 0604FACA mov r8,r6
    c.r[5] = c.r[5] & 0xFFFFu;  // 0604FACC extu.w r5,r5
    c.r[5] <<= 2;  // 0604FACE shll2 r5
    c.r[5] += c.r[5];  // 0604FAD0 add r5,r5
    c.r[5] <<= 2;  // 0604FAD2 shll2 r5
    { const uint32_t x = c.r[12]; c.pr = 0x0604FAD8u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FAD8u) return; }  // 0604FAD4 jsr @r12 ; add r1,r5
    c.r[10] += c.r[8];  // 0604FAD8 add r8,r10
    c.r[1] = c.r[9];  // 0604FADA mov r9,r1
    c.r[1] += 2;  // 0604FADC add #2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604FB2Cu);  // 0604FADE mov.w 0x0604FB2C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FAE0 mov.b @r1,r2
    c.r[7] = 0xEu;  // 0604FAE2 mov #14,r7
    c.r[5] = ld32(c.r[0] + c.r[13]);  // 0604FAE4 mov.l @(r0,r13),r5
    c.r[2] = c.r[2] & 0xFFu;  // 0604FAE6 extu.b r2,r2
    c.r[1] = c.r[9];  // 0604FAE8 mov r9,r1
    c.r[1] += 3;  // 0604FAEA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FAEC mov.b @r1,r1
    c.r[2] <<= 8;  // 0604FAEE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604FAF0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604FAF2 or r1,r2
    c.r[10] += c.r[2];  // 0604FAF4 add r2,r10
    c.macl = c.r[2] * c.r[11];  // 0604FAF6 mul.l r11,r2
    c.r[10] += c.r[9];  // 0604FAF8 add r9,r10
    c.r[4] = c.r[10];  // 0604FAFA mov r10,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0604FB00u; c.r[6] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FB00u) return; }  // 0604FAFC jsr @r12 ; sts macl,r6
    c.r[1] = ld32(0x0604FB44u);  // 0604FB00 mov.l 0x0604FB44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604FB06u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FB06u) return; }  // 0604FB02 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0604FB06 mov #0,r1
    c.r[3] = ld32(0x0604FB34u);  // 0604FB08 mov.l 0x0604FB34,r3
    st8(c.r[3], c.r[1]);  // 0604FB0A mov.b r1,@r3
    c.r[1] = ld32(0x0604FB48u);  // 0604FB0C mov.l 0x0604FB48,r1
    c.r[6] = 0x0u;  // 0604FB0E mov #0,r6
    c.r[5] = 0x0u;  // 0604FB10 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604FB16u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FB16u) return; }  // 0604FB12 jsr @r1 ; mov #1,r4
    c.r[15] = c.r[14];  // 0604FB16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604FB18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604FB1A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604FB1C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604FB1E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604FB20 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604FB22 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604FB24 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604FB26 rts ; mov.l @r15+,r8
}

void f_0604FB4C(SH2Context& c) {
    ran[1271] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604FB4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604FB4E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604FB50 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604FB52 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604FB54 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604FB56 mov r15,r14
    c.r[9] = 0x0u;  // 0604FB58 mov #0,r9
    c.r[10] = ld32(0x0604FBD8u);  // 0604FB5A mov.l 0x0604FBD8,r10
L_0604FB5C:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604FBD2u);  // 0604FB5C mov.w 0x0604FBD2,r2
    c.r[2] += c.r[9];  // 0604FB5E add r9,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0604FB60 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0604FB68; } }  // 0604FB62 bt/s 0x0604FB68 ; mov r2,r1
    c.r[1] += 7;  // 0604FB66 add #7,r1
L_0604FB68:
    c.r[0] = c.r[1];  // 0604FB68 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604FB6A shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604FB6C shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604FB6E shar r0
    c.r[1] = ld32(0x0604FBDCu);  // 0604FB70 mov.l 0x0604FBDC,r1
    c.r[1] = ld32(c.r[1]);  // 0604FB72 mov.l @r1,r1
    c.r[5] = c.r[2];  // 0604FB74 mov r2,r5
    c.r[0] += c.r[1];  // 0604FB76 add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604FBD4u);  // 0604FB78 mov.w 0x0604FBD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604FB7A mov.b @(r0,r1),r1
    c.t = (int32_t)c.r[2] >= 0;  // 0604FB7C cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0604FB84; } }  // 0604FB7E bt/s 0x0604FB84 ; extu.b r1,r4
    c.r[5] += 7;  // 0604FB82 add #7,r5
L_0604FB84:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604FB84 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604FB86 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0604FB88 shar r5
    c.r[5] <<= 2;  // 0604FB8A shll2 r5
    c.r[5] += c.r[5];  // 0604FB8C add r5,r5
    c.r[5] -= c.r[2];  // 0604FB8E sub r2,r5
    c.r[0] = ld32(0x0604FBE0u);  // 0604FB90 mov.l 0x0604FBE0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604FB96u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FB96u) return; }  // 0604FB92 jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 0604FB96 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604FB98 tst r0,r0
    if (c.t) { goto L_0604FBBC; }  // 0604FB9A bt 0x0604FBBC
    c.r[0] = ld32(0x0604FBE4u);  // 0604FB9C mov.l 0x0604FBE4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0604FB9E mov.b @(r0,r9),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604FBD6u);  // 0604FBA0 mov.w 0x0604FBD6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604FBA2 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0604FBA4 cmp/eq r2,r1
    if (c.t) { goto L_0604FBBC; }  // 0604FBA6 bt 0x0604FBBC
    c.r[8] = c.r[9] & 0xFFu;  // 0604FBA8 extu.b r9,r8
    c.r[5] = 0x2u;  // 0604FBAA mov #2,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604FBB0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FBB0u) return; }  // 0604FBAC jsr @r10 ; mov r8,r4
    c.r[5] = 0x0u;  // 0604FBB0 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604FBB6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FBB6u) return; }  // 0604FBB2 jsr @r10 ; mov r8,r4
    c.r[5] = 0x2u;  // 0604FBB6 mov #2,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604FBBCu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FBBCu) return; }  // 0604FBB8 jsr @r10 ; mov r8,r4
L_0604FBBC:
    c.r[9] += 1;  // 0604FBBC add #1,r9
    c.r[1] = 0x1Fu;  // 0604FBBE mov #31,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0604FBC0 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_0604FB5C; }  // 0604FBC2 bf 0x0604FB5C
    c.r[15] = c.r[14];  // 0604FBC4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604FBC6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604FBC8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604FBCA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604FBCC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604FBCE rts ; mov.l @r15+,r8
}

void f_0604FBE8(SH2Context& c) {
    ran[1272] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604FBE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604FBEA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604FBEC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604FBEE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604FBF0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604FBF2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604FBF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604FBF6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604FBF8 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 0604FBFA extu.b r4,r11
    c.r[1] = ld32(0x0604FD58u);  // 0604FBFC mov.l 0x0604FD58,r1
    c.r[0] = c.r[11];  // 0604FBFE mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604FC00 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0604FC02 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604FD50u);  // 0604FC04 mov.w 0x0604FD50,r1
    c.t = c.r[2] == c.r[1];  // 0604FC06 cmp/eq r1,r2
    { const bool k = !c.t; c.r[9] = c.r[5] & 0xFFu; if (k) { goto L_0604FC10; } }  // 0604FC08 bf/s 0x0604FC10 ; extu.b r5,r9
    goto L_0604FE1E;  // 0604FC0C bra 0x0604FE1E ; nop
L_0604FC10:
    c.r[12] = c.r[2];  // 0604FC10 mov r2,r12
    c.r[12] <<= 2;  // 0604FC12 shll2 r12
    c.r[12] += c.r[12];  // 0604FC14 add r12,r12
    c.r[8] = ld32(0x0604FD5Cu);  // 0604FC16 mov.l 0x0604FD5C,r8
    c.r[8] += c.r[12];  // 0604FC18 add r12,r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604FD52u);  // 0604FC1A mov.w 0x0604FD52,r2
    c.r[2] += c.r[11];  // 0604FC1C add r11,r2
    c.r[1] = c.r[2];  // 0604FC1E mov r2,r1
    c.r[10] = c.r[1];  // 0604FC20 mov r1,r10
    c.r[10] >>= 2;  // 0604FC22 shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0604FC24 shlr r10
    c.r[1] = ld32(0x0604FD60u);  // 0604FC26 mov.l 0x0604FD60,r1
    c.r[1] = ld32(c.r[1]);  // 0604FC28 mov.l @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0604FD54u);  // 0604FC2A mov.w 0x0604FD54,r13
    c.r[5] = c.r[2];  // 0604FC2C mov r2,r5
    c.r[10] += c.r[1];  // 0604FC2E add r1,r10
    c.r[5] >>= 2;  // 0604FC30 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0604FC32 shlr r5
    c.r[5] <<= 2;  // 0604FC34 shll2 r5
    c.r[5] += c.r[5];  // 0604FC36 add r5,r5
    c.r[5] -= c.r[2];  // 0604FC38 sub r2,r5
    c.r[5] += 7;  // 0604FC3A add #7,r5
    c.r[0] = ld32(0x0604FD64u);  // 0604FC3C mov.l 0x0604FD64,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604FC42u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FC42u) return; }  // 0604FC3E jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 0604FC42 mov r0,r2
    c.r[0] = c.r[10];  // 0604FC44 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0604FC46 mov.b @(r0,r13),r1
    c.r[2] &= c.r[1];  // 0604FC48 and r1,r2
    c.r[6] = c.r[2] & 0xFFu;  // 0604FC4A extu.b r2,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0604FC4C tst r6,r6
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0604FC86; } }  // 0604FC4E bt/s 0x0604FC86 ; mov r8,r1
    c.r[1] += 1;  // 0604FC52 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FC54 mov.b @r1,r0
    c.r[3] = 0x1Fu;  // 0604FC56 mov #31,r3
    c.r[0] &= 0x7u;  // 0604FC58 and #7,r0
    c.r[1] = c.r[8];  // 0604FC5A mov r8,r1
    c.r[1] += 2;  // 0604FC5C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FC5E mov.b @r1,r1
    c.r[0] <<= 2;  // 0604FC60 shll2 r0
    c.r[0] += c.r[0];  // 0604FC62 add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604FC64 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604FC66 mov r1,r2
    c.r[2] >>= 2;  // 0604FC68 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604FC6A shlr r2
    c.r[2] >>= 2;  // 0604FC6C shlr2 r2
    c.r[2] |= c.r[0];  // 0604FC6E or r0,r2
    c.r[3] &= c.r[1];  // 0604FC70 and r1,r3
    c.r[1] = c.r[8];  // 0604FC72 mov r8,r1
    c.r[1] += 3;  // 0604FC74 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FC76 mov.b @r1,r1
    c.r[3] += c.r[3];  // 0604FC78 add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604FC7A extu.b r1,r1
    c.r[1] >>= 2;  // 0604FC7C shlr2 r1
    c.r[1] >>= 2;  // 0604FC7E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FC80 shlr r1
    c.r[1] >>= 2; goto L_0604FCAA;  // 0604FC82 bra 0x0604FCAA ; shlr2 r1
L_0604FC86:
    c.r[0] = ld32(0x0604FD5Cu);  // 0604FC86 mov.l 0x0604FD5C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0604FC88 mov.b @(r0,r12),r1
    c.r[3] = 0x1u;  // 0604FC8A mov #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604FC8C extu.b r1,r1
    c.r[2] = c.r[1];  // 0604FC8E mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604FC90 shlr r2
    c.r[0] = 0x3Fu;  // 0604FC92 mov #63,r0
    c.r[3] &= c.r[1];  // 0604FC94 and r1,r3
    c.r[1] = c.r[8];  // 0604FC96 mov r8,r1
    c.r[1] += 1;  // 0604FC98 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FC9A mov.b @r1,r1
    c.r[2] &= c.r[0];  // 0604FC9C and r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604FC9E extu.b r1,r1
    c.r[1] >>= 2;  // 0604FCA0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FCA2 shlr r1
    c.r[3] <<= 2;  // 0604FCA4 shll2 r3
    c.r[3] += c.r[3];  // 0604FCA6 add r3,r3
    c.r[3] <<= 2;  // 0604FCA8 shll2 r3
L_0604FCAA:
    c.r[0] = c.r[9];  // 0604FCAA mov r9,r0
    c.t = c.r[0] == 0x1u;  // 0604FCAC cmp/eq #1,r0
    { const bool k = c.t; c.r[3] |= c.r[1]; if (k) { goto L_0604FCD8; } }  // 0604FCAE bt/s 0x0604FCD8 ; or r1,r3
    c.r[4] = 0x1u;  // 0604FCB2 mov #1,r4
    c.t = (int32_t)c.r[9] > (int32_t)c.r[4];  // 0604FCB4 cmp/gt r4,r9
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0604FCC4; } }  // 0604FCB6 bt/s 0x0604FCC4 ; cmp/eq #2,r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 0604FCBA tst r9,r9
    { const bool k = c.t; c.r[6] = c.r[3]; if (k) { goto L_0604FCCC; } }  // 0604FCBC bt/s 0x0604FCCC ; mov r3,r6
    goto L_0604FDE0;  // 0604FCC0 bra 0x0604FDE0 ; nop
L_0604FCC4:
    { const bool k = c.t; c.t = (c.r[6] & c.r[6]) == 0; if (k) { goto L_0604FD78; } }  // 0604FCC4 bt/s 0x0604FD78 ; tst r6,r6
    goto L_0604FDE0;  // 0604FCC8 bra 0x0604FDE0 ; nop
L_0604FCCC:
    c.r[1] = ld32(0x0604FD68u);  // 0604FCCC mov.l 0x0604FD68,r1
    c.r[5] = c.r[2];  // 0604FCCE mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604FCD4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FCD4u) return; }  // 0604FCD0 jsr @r1 ; mov r8,r4
    c.r[15] = c.r[14]; goto L_0604FE20;  // 0604FCD4 bra 0x0604FE20 ; mov r14,r15
L_0604FCD8:
    c.r[5] = c.r[8];  // 0604FCD8 mov r8,r5
    c.r[5] += 6;  // 0604FCDA add #6,r5
    c.r[7] = c.r[8];  // 0604FCDC mov r8,r7
    c.r[7] += 7;  // 0604FCDE add #7,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604FCE0 mov.b @r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604FD50u);  // 0604FCE2 mov.w 0x0604FD50,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604FCE4 mov.b @r7,r2
    c.r[0] &= 0x7Fu;  // 0604FCE6 and #127,r0
    c.r[0] += c.r[0];  // 0604FCE8 add r0,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604FCEA extu.b r2,r2
    c.r[2] >>= 2;  // 0604FCEC shlr2 r2
    c.r[2] >>= 2;  // 0604FCEE shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604FCF0 shlr r2
    c.r[2] >>= 2;  // 0604FCF2 shlr2 r2
    c.r[2] |= c.r[0];  // 0604FCF4 or r0,r2
    c.t = c.r[2] == c.r[1];  // 0604FCF6 cmp/eq r1,r2
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0604FD00; } }  // 0604FCF8 bf/s 0x0604FD00 ; mov r8,r2
    goto L_0604FE1E;  // 0604FCFC bra 0x0604FE1E ; nop
L_0604FD00:
    c.r[3] = ld32(0x0604FD6Cu);  // 0604FD00 mov.l 0x0604FD6C,r3
    c.r[2] += 3;  // 0604FD02 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604FD04 mov.b @r2,r1
    c.r[8] += 4;  // 0604FD06 add #4,r8
    c.r[0] = c.r[1];  // 0604FD08 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604FD0A shlr r0
    c.r[0] &= 0x3Fu;  // 0604FD0C and #63,r0
    st8(c.r[3], c.r[0]);  // 0604FD0E mov.b r0,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604FD10 mov.b @r2,r0
    c.r[3] = ld32(0x0604FD70u);  // 0604FD12 mov.l 0x0604FD70,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604FD14 mov.b @r8,r1
    c.r[0] &= 0x1u;  // 0604FD16 and #1,r0
    c.r[0] <<= 2;  // 0604FD18 shll2 r0
    c.r[0] += c.r[0];  // 0604FD1A add r0,r0
    c.r[0] <<= 2;  // 0604FD1C shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604FD1E extu.b r1,r1
    c.r[1] >>= 2;  // 0604FD20 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FD22 shlr r1
    c.r[1] |= c.r[0];  // 0604FD24 or r0,r1
    st8(c.r[3], c.r[1]);  // 0604FD26 mov.b r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604FD28 mov.b @r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604FD2A mov.b @r7,r1
    c.r[0] &= 0x7Fu;  // 0604FD2C and #127,r0
    c.r[0] += c.r[0];  // 0604FD2E add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604FD30 extu.b r1,r1
    c.r[1] >>= 2;  // 0604FD32 shlr2 r1
    c.r[1] >>= 2;  // 0604FD34 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FD36 shlr r1
    c.r[1] >>= 2;  // 0604FD38 shlr2 r1
    c.t = (c.r[6] & c.r[6]) == 0;  // 0604FD3A tst r6,r6
    { const bool k = c.t; c.r[1] |= c.r[0]; if (k) { goto L_0604FD42; } }  // 0604FD3C bt/s 0x0604FD42 ; or r0,r1
    c.r[1] += 1;  // 0604FD40 add #1,r1
L_0604FD42:
    c.r[5] = c.r[1] & 0xFFFFu;  // 0604FD42 extu.w r1,r5
    c.r[1] = ld32(0x0604FD74u);  // 0604FD44 mov.l 0x0604FD74,r1
    c.r[6] = 0x0u;  // 0604FD46 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0604FD4Cu; c.r[4] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FD4Cu) return; }  // 0604FD48 jsr @r1 ; mov #-1,r4
    c.r[15] = c.r[14]; goto L_0604FE20;  // 0604FD4C bra 0x0604FE20 ; mov r14,r15
L_0604FD78:
    if (c.t) { goto L_0604FDAE; }  // 0604FD78 bt 0x0604FDAE
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604FE32u);  // 0604FD7A mov.w 0x0604FE32,r2
    c.r[2] += c.r[11];  // 0604FD7C add r11,r2
    c.r[1] = c.r[2];  // 0604FD7E mov r2,r1
    c.r[8] = c.r[1];  // 0604FD80 mov r1,r8
    c.r[8] >>= 2;  // 0604FD82 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0604FD84 shlr r8
    c.r[1] = ld32(0x0604FE38u);  // 0604FD86 mov.l 0x0604FE38,r1
    c.r[1] = ld32(c.r[1]);  // 0604FD88 mov.l @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0604FE34u);  // 0604FD8A mov.w 0x0604FE34,r9
    c.r[5] = c.r[2];  // 0604FD8C mov r2,r5
    c.r[8] += c.r[1];  // 0604FD8E add r1,r8
    c.r[5] >>= 2;  // 0604FD90 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0604FD92 shlr r5
    c.r[5] <<= 2;  // 0604FD94 shll2 r5
    c.r[5] += c.r[5];  // 0604FD96 add r5,r5
    c.r[5] -= c.r[2];  // 0604FD98 sub r2,r5
    c.r[0] = ld32(0x0604FE3Cu);  // 0604FD9A mov.l 0x0604FE3C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604FDA0u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FDA0u) return; }  // 0604FD9C jsr @r0 ; add #7,r5
    c.r[1] = c.r[0];  // 0604FDA0 mov r0,r1
    c.r[2] = ~c.r[1];  // 0604FDA2 not r1,r2
    c.r[0] = c.r[8];  // 0604FDA4 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0604FDA6 mov.b @(r0,r9),r1
    c.r[2] &= c.r[1];  // 0604FDA8 and r1,r2
    st8(c.r[0] + c.r[9], c.r[2]); goto L_0604FE1E;  // 0604FDAA bra 0x0604FE1E ; mov.b r2,@(r0,r9)
L_0604FDAE:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604FE32u);  // 0604FDAE mov.w 0x0604FE32,r2
    c.r[2] += c.r[11];  // 0604FDB0 add r11,r2
    c.r[1] = c.r[2];  // 0604FDB2 mov r2,r1
    c.r[8] = c.r[1];  // 0604FDB4 mov r1,r8
    c.r[8] >>= 2;  // 0604FDB6 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0604FDB8 shlr r8
    c.r[1] = ld32(0x0604FE38u);  // 0604FDBA mov.l 0x0604FE38,r1
    c.r[1] = ld32(c.r[1]);  // 0604FDBC mov.l @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0604FE34u);  // 0604FDBE mov.w 0x0604FE34,r9
    c.r[5] = c.r[2];  // 0604FDC0 mov r2,r5
    c.r[8] += c.r[1];  // 0604FDC2 add r1,r8
    c.r[5] >>= 2;  // 0604FDC4 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0604FDC6 shlr r5
    c.r[5] <<= 2;  // 0604FDC8 shll2 r5
    c.r[5] += c.r[5];  // 0604FDCA add r5,r5
    c.r[5] -= c.r[2];  // 0604FDCC sub r2,r5
    c.r[0] = ld32(0x0604FE3Cu);  // 0604FDCE mov.l 0x0604FE3C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604FDD4u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FDD4u) return; }  // 0604FDD0 jsr @r0 ; add #7,r5
    c.r[2] = c.r[0];  // 0604FDD4 mov r0,r2
    c.r[0] = c.r[8];  // 0604FDD6 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0604FDD8 mov.b @(r0,r9),r1
    c.r[2] |= c.r[1];  // 0604FDDA or r1,r2
    st8(c.r[0] + c.r[9], c.r[2]); goto L_0604FE1E;  // 0604FDDC bra 0x0604FE1E ; mov.b r2,@(r0,r9)
L_0604FDE0:
    c.r[3] = ld32(0x0604FE40u);  // 0604FDE0 mov.l 0x0604FE40,r3
    c.r[2] = c.r[3];  // 0604FDE2 mov r3,r2
    c.r[2] += 78;  // 0604FDE4 add #78,r2
    c.r[7] = c.r[8];  // 0604FDE6 mov r8,r7
    c.r[7] += 3;  // 0604FDE8 add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604FDEA mov.b @r7,r1
    c.r[3] += 79;  // 0604FDEC add #79,r3
    c.r[0] = c.r[1];  // 0604FDEE mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604FDF0 shlr r0
    c.r[0] &= 0x3Fu;  // 0604FDF2 and #63,r0
    c.r[1] = 0xFFFFFFF7u;  // 0604FDF4 mov #-9,r1
    c.r[0] += c.r[1];  // 0604FDF6 add r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604FDF8 mov.b @r2,r1
    c.r[8] += 4;  // 0604FDFA add #4,r8
    c.r[0] += c.r[1];  // 0604FDFC add r1,r0
    st8(c.r[2], c.r[0]);  // 0604FDFE mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604FE00 mov.b @r7,r0
    c.r[1] = 0xFFFFFFFAu;  // 0604FE02 mov #-6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604FE04 mov.b @r8,r2
    c.r[0] &= 0x1u;  // 0604FE06 and #1,r0
    c.r[0] <<= 2;  // 0604FE08 shll2 r0
    c.r[0] += c.r[0];  // 0604FE0A add r0,r0
    c.r[0] <<= 2;  // 0604FE0C shll2 r0
    c.r[2] = c.r[2] & 0xFFu;  // 0604FE0E extu.b r2,r2
    c.r[2] >>= 2;  // 0604FE10 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604FE12 shlr r2
    c.r[2] |= c.r[0];  // 0604FE14 or r0,r2
    c.r[2] += c.r[1];  // 0604FE16 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604FE18 mov.b @r3,r1
    c.r[2] += c.r[1];  // 0604FE1A add r1,r2
    st8(c.r[3], c.r[2]);  // 0604FE1C mov.b r2,@r3
L_0604FE1E:
    c.r[15] = c.r[14];  // 0604FE1E mov r14,r15
L_0604FE20:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604FE20 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604FE22 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604FE24 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604FE26 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604FE28 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604FE2A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604FE2C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604FE2E rts ; mov.l @r15+,r8
}

void f_0604FE44(SH2Context& c) {
    ran[1273] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604FE44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604FE46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604FE48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604FE4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604FE4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604FE4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604FE50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604FE52 sts.l pr,@-r15
    c.r[15] -= 64;  // 0604FE54 add #-64,r15
    c.r[14] = c.r[15];  // 0604FE56 mov r15,r14
    c.r[7] = c.r[4];  // 0604FE58 mov r4,r7
    c.r[5] = c.r[5] & 0xFFu;  // 0604FE5A extu.b r5,r5
    st32(c.r[14] + 8, c.r[5]);  // 0604FE5C mov.l r5,@(8,r14)
    c.r[6] = c.r[6] & 0xFFu;  // 0604FE5E extu.b r6,r6
    st32(c.r[14] + 12, c.r[6]);  // 0604FE60 mov.l r6,@(12,r14)
    c.r[0] = 0x0u;  // 0604FE62 mov #0,r0
    st32(c.r[14] + 16, c.r[0]);  // 0604FE64 mov.l r0,@(16,r14)
    c.r[2] = c.r[7];  // 0604FE66 mov r7,r2
    c.r[2] += 5;  // 0604FE68 add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604FE6A mov.b @r2,r1
    c.r[3] = 0x1Fu;  // 0604FE6C mov #31,r3
    c.r[3] &= c.r[1];  // 0604FE6E and r1,r3
    c.r[1] = c.r[7];  // 0604FE70 mov r7,r1
    c.r[1] += 6;  // 0604FE72 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FE74 mov.b @r1,r1
    c.r[3] += c.r[3];  // 0604FE76 add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604FE78 extu.b r1,r1
    c.r[1] >>= 2;  // 0604FE7A shlr2 r1
    c.r[1] >>= 2;  // 0604FE7C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FE7E shlr r1
    c.r[1] >>= 2;  // 0604FE80 shlr2 r1
    c.r[1] |= c.r[3];  // 0604FE82 or r3,r1
    c.t = c.r[0] >= c.r[1];  // 0604FE84 cmp/hs r1,r0
    { const bool k = !c.t; c.r[10] = c.r[7]; if (k) { goto L_0604FE8E; } }  // 0604FE86 bf/s 0x0604FE8E ; mov r7,r10
    goto L_06050046;  // 0604FE8A bra 0x06050046 ; nop
L_0604FE8E:
    c.r[10] += 4;  // 0604FE8E add #4,r10
    st32(c.r[14] + 44, c.r[10]);  // 0604FE90 mov.l r10,@(44,r14)
    c.r[0] = ld32(c.r[14] + 44);  // 0604FE92 mov.l @(44,r14),r0
L_0604FE94:
    c.r[3] = 0x0u;  // 0604FE94 mov #0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604FE96 mov.b @r0,r1
    c.r[6] = 0x7u;  // 0604FE98 mov #7,r6
    c.r[6] &= c.r[1];  // 0604FE9A and r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604FE9C mov.b @r2,r1
    c.r[6] <<= 2;  // 0604FE9E shll2 r6
    c.r[6] += c.r[6];  // 0604FEA0 add r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604FEA2 extu.b r1,r1
    c.r[1] >>= 2;  // 0604FEA4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FEA6 shlr r1
    c.r[1] >>= 2;  // 0604FEA8 shlr2 r1
    c.r[1] |= c.r[6];  // 0604FEAA or r6,r1
    c.t = c.r[3] >= c.r[1];  // 0604FEAC cmp/hs r1,r3
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_0604FEB6; } }  // 0604FEAE bf/s 0x0604FEB6 ; mov r7,r2
    goto L_0605001A;  // 0604FEB2 bra 0x0605001A ; nop
L_0604FEB6:
    c.r[1] = ld32(c.r[14] + 12);  // 0604FEB6 mov.l @(12,r14),r1
    c.r[10] = ld32(c.r[14] + 16);  // 0604FEB8 mov.l @(16,r14),r10
    c.r[1] += c.r[10];  // 0604FEBA add r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604FEBC extu.b r1,r1
    st32(c.r[14] + 24, c.r[1]);  // 0604FEBE mov.l r1,@(24,r14)
    c.r[0] = 0x3Fu;  // 0604FEC0 mov #63,r0
L_0604FEC2:
    c.r[1] = ld32(c.r[14] + 8);  // 0604FEC2 mov.l @(8,r14),r1
    c.r[10] = 0x1u;  // 0604FEC4 mov #1,r10
    c.r[1] += c.r[3];  // 0604FEC6 add r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604FEC8 extu.b r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 0604FECA mov.l r1,@(20,r14)
    c.r[1] = c.r[7];  // 0604FECC mov r7,r1
    c.r[1] += 3;  // 0604FECE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FED0 mov.b @r1,r1
    c.r[4] = ld32(0x06050064u);  // 0604FED2 mov.l 0x06050064,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0604FED4 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604FED6 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604FED8 shlr r2
    c.r[2] &= c.r[0];  // 0604FEDA and r0,r2
    c.r[2] += c.r[3];  // 0604FEDC add r3,r2
    c.r[13] = c.r[2] & 0xFFu;  // 0604FEDE extu.b r2,r13
    c.r[1] &= c.r[10];  // 0604FEE0 and r10,r1
    c.r[0] = ld32(c.r[14] + 44);  // 0604FEE2 mov.l @(44,r14),r0
    c.r[1] <<= 2;  // 0604FEE4 shll2 r1
    c.r[1] += c.r[1];  // 0604FEE6 add r1,r1
    c.r[1] <<= 2;  // 0604FEE8 shll2 r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604FEEA mov.b @r0,r8
    c.r[5] = c.r[13];  // 0604FEEC mov r13,r5
    c.r[10] = ld32(c.r[14] + 16);  // 0604FEEE mov.l @(16,r14),r10
    c.r[8] = c.r[8] & 0xFFu;  // 0604FEF0 extu.b r8,r8
    c.r[8] >>= 2;  // 0604FEF2 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0604FEF4 shlr r8
    c.r[8] |= c.r[1];  // 0604FEF6 or r1,r8
    c.r[8] += c.r[10];  // 0604FEF8 add r10,r8
    c.r[8] = c.r[8] & 0xFFu;  // 0604FEFA extu.b r8,r8
    c.r[6] = c.r[8];  // 0604FEFC mov r8,r6
    st32(c.r[14] + 52, c.r[3]);  // 0604FEFE mov.l r3,@(52,r14)
    c.r[0] = ld32(0x06050068u);  // 0604FF00 mov.l 0x06050068,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604FF06u; st32(c.r[14] + 56, c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FF06u) return; }  // 0604FF02 jsr @r0 ; mov.l r7,@(56,r14)
    c.r[9] = c.r[0];  // 0604FF06 mov r0,r9
    c.r[10] = c.r[14];  // 0604FF08 mov r14,r10
    c.r[10] += 2;  // 0604FF0A add #2,r10
    c.r[0] = c.r[14];  // 0604FF0C mov r14,r0
    c.r[0] += 4;  // 0604FF0E add #4,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605005Cu);  // 0604FF10 mov.w 0x0605005C,r11
    c.r[6] = c.r[8];  // 0604FF12 mov r8,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]); c.r[9] += 2;  // 0604FF14 mov.w @r9+,r1
    c.r[5] = c.r[13];  // 0604FF16 mov r13,r5
    st16(c.r[14], c.r[1]);  // 0604FF18 mov.w r1,@r14
    st32(c.r[14] + 28, c.r[10]);  // 0604FF1A mov.l r10,@(28,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604FF1C mov.w @r9,r1
    c.r[4] = ld32(0x06050064u);  // 0604FF1E mov.l 0x06050064,r4
    st16(c.r[10], c.r[1]);  // 0604FF20 mov.w r1,@r10
    c.r[9] += 126;  // 0604FF22 add #126,r9
    st32(c.r[14] + 32, c.r[0]);  // 0604FF24 mov.l r0,@(32,r14)
    c.r[10] = c.r[14];  // 0604FF26 mov r14,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]); c.r[9] += 2;  // 0604FF28 mov.w @r9+,r1
    c.r[10] += 6;  // 0604FF2A add #6,r10
    st16(c.r[0], c.r[1]);  // 0604FF2C mov.w r1,@r0
    st32(c.r[14] + 36, c.r[10]);  // 0604FF2E mov.l r10,@(36,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604FF30 mov.w @r9,r1
    c.r[0] = ld32(0x0605006Cu);  // 0604FF32 mov.l 0x0605006C,r0
    st16(c.r[10], c.r[1]);  // 0604FF34 mov.w r1,@r10
    c.r[10] = c.r[8];  // 0604FF36 mov r8,r10
    c.r[10] <<= 2;  // 0604FF38 shll2 r10
    c.r[10] <<= 2;  // 0604FF3A shll2 r10
    c.r[10] <<= 2;  // 0604FF3C shll2 r10
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 0604FF3E mov.l @(r0,r11),r1
    st32(c.r[14] + 60, c.r[10]);  // 0604FF40 mov.l r10,@(60,r14)
    c.r[1] += c.r[10];  // 0604FF42 add r10,r1
    c.r[0] = c.r[1];  // 0604FF44 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0604FF46 mov.b @(r0,r13),r1
    c.r[10] = ld32(0x06050068u);  // 0604FF48 mov.l 0x06050068,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0604FF4A extu.b r1,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0604FF50u; st32(c.r[14] + 40, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FF50u) return; }  // 0604FF4C jsr @r10 ; mov.l r1,@(40,r14)
    c.r[9] = c.r[0];  // 0604FF50 mov r0,r9
    c.r[2] = ld32(0x06050070u);  // 0604FF52 mov.l 0x06050070,r2
    c.r[6] = ld32(c.r[14] + 24);  // 0604FF54 mov.l @(24,r14),r6
    c.r[4] = c.r[2];  // 0604FF56 mov r2,r4
    c.r[5] = ld32(c.r[14] + 20);  // 0604FF58 mov.l @(20,r14),r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604FF5Eu; st32(c.r[14] + 48, c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FF5Eu) return; }  // 0604FF5A jsr @r10 ; mov.l r2,@(48,r14)
    c.r[6] = c.r[0];  // 0604FF5E mov r0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); c.r[6] += 2;  // 0604FF60 mov.w @r6+,r1
    c.r[0] = ld32(0x0605006Cu);  // 0604FF62 mov.l 0x0605006C,r0
    st16(c.r[9], c.r[1]);  // 0604FF64 mov.w r1,@r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604FF66 mov.w @r6,r1
    c.r[9] += 2;  // 0604FF68 add #2,r9
    st16(c.r[9], c.r[1]);  // 0604FF6A mov.w r1,@r9
    c.r[6] += 126;  // 0604FF6C add #126,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); c.r[6] += 2;  // 0604FF6E mov.w @r6+,r1
    c.r[9] += 126;  // 0604FF70 add #126,r9
    st16(c.r[9], c.r[1]);  // 0604FF72 mov.w r1,@r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604FF74 mov.w @r6,r1
    c.r[9] += 2;  // 0604FF76 add #2,r9
    st16(c.r[9], c.r[1]);  // 0604FF78 mov.w r1,@r9
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 0604FF7A mov.l @(r0,r11),r1
    c.r[10] = ld32(c.r[14] + 60);  // 0604FF7C mov.l @(60,r14),r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x0605005Eu);  // 0604FF7E mov.w 0x0605005E,r9
    c.r[8] = ld32(c.r[14] + 24);  // 0604FF80 mov.l @(24,r14),r8
    c.r[10] += c.r[1];  // 0604FF82 add r1,r10
    st32(c.r[14] + 60, c.r[10]);  // 0604FF84 mov.l r10,@(60,r14)
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0604FF86 mov.l @(r0,r9),r1
    c.r[8] <<= 2;  // 0604FF88 shll2 r8
    c.r[8] <<= 2;  // 0604FF8A shll2 r8
    c.r[8] <<= 2;  // 0604FF8C shll2 r8
    c.r[0] = ld32(c.r[14] + 20);  // 0604FF8E mov.l @(20,r14),r0
    c.r[1] += c.r[8];  // 0604FF90 add r8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604FF92 mov.b @(r0,r1),r1
    c.r[0] = c.r[10];  // 0604FF94 mov r10,r0
    st8(c.r[0] + c.r[13], c.r[1]);  // 0604FF96 mov.b r1,@(r0,r13)
    c.r[7] = ld32(c.r[14] + 56);  // 0604FF98 mov.l @(56,r14),r7
    c.r[2] = ld32(c.r[14] + 48);  // 0604FF9A mov.l @(48,r14),r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604FF9C mov.b @r7,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06050060u);  // 0604FF9E mov.w 0x06050060,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0604FFA0 extu.b r1,r1
    c.r[1] >>= 2;  // 0604FFA2 shlr2 r1
    c.r[1] >>= 2;  // 0604FFA4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604FFA6 shlr r1
    c.r[1] >>= 2;  // 0604FFA8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604FFAA tst r1,r1
    { const bool k = c.t; c.r[3] = ld32(c.r[14] + 52); if (k) { goto L_0604FFF0; } }  // 0604FFAC bt/s 0x0604FFF0 ; mov.l @(52,r14),r3
    c.r[4] = c.r[2];  // 0604FFB0 mov r2,r4
    st32(c.r[14] + 52, c.r[3]);  // 0604FFB2 mov.l r3,@(52,r14)
    c.r[6] = ld32(c.r[14] + 24);  // 0604FFB4 mov.l @(24,r14),r6
    st32(c.r[14] + 56, c.r[7]);  // 0604FFB6 mov.l r7,@(56,r14)
    c.r[10] = ld32(0x06050068u);  // 0604FFB8 mov.l 0x06050068,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0604FFBEu; c.r[5] = ld32(c.r[14] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604FFBEu) return; }  // 0604FFBA jsr @r10 ; mov.l @(20,r14),r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0604FFBE mov.w @r14,r1
    c.r[6] = c.r[0];  // 0604FFC0 mov r0,r6
    st16(c.r[6], c.r[1]);  // 0604FFC2 mov.w r1,@r6
    c.r[0] = ld32(c.r[14] + 28);  // 0604FFC4 mov.l @(28,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604FFC6 mov.w @r0,r1
    c.r[6] += 2;  // 0604FFC8 add #2,r6
    st16(c.r[6], c.r[1]);  // 0604FFCA mov.w r1,@r6
    c.r[10] = ld32(c.r[14] + 32);  // 0604FFCC mov.l @(32,r14),r10
    c.r[6] -= 2;  // 0604FFCE add #-2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604FFD0 mov.w @r10,r1
    c.r[6] += c.r[12];  // 0604FFD2 add r12,r6
    st16(c.r[6], c.r[1]);  // 0604FFD4 mov.w r1,@r6
    c.r[0] = ld32(c.r[14] + 36);  // 0604FFD6 mov.l @(36,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604FFD8 mov.w @r0,r1
    c.r[6] += 2;  // 0604FFDA add #2,r6
    st16(c.r[6], c.r[1]);  // 0604FFDC mov.w r1,@r6
    c.r[0] = ld32(0x0605006Cu);  // 0604FFDE mov.l 0x0605006C,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0604FFE0 mov.l @(r0,r9),r1
    c.r[8] += c.r[1];  // 0604FFE2 add r1,r8
    c.r[0] = 0x2Bu;  // 0604FFE4 mov #43,r0
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0604FFE6 mov.b @(r0,r14),r10
    c.r[0] = ld32(c.r[14] + 20);  // 0604FFE8 mov.l @(20,r14),r0
    st8(c.r[0] + c.r[8], c.r[10]);  // 0604FFEA mov.b r10,@(r0,r8)
    c.r[7] = ld32(c.r[14] + 56);  // 0604FFEC mov.l @(56,r14),r7
    c.r[3] = ld32(c.r[14] + 52);  // 0604FFEE mov.l @(52,r14),r3
L_0604FFF0:
    c.r[0] = ld32(c.r[14] + 44);  // 0604FFF0 mov.l @(44,r14),r0
    c.r[3] += 1;  // 0604FFF2 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604FFF4 mov.b @r0,r1
    c.r[2] = 0x7u;  // 0604FFF6 mov #7,r2
    c.r[2] &= c.r[1];  // 0604FFF8 and r1,r2
    c.r[1] = c.r[7];  // 0604FFFA mov r7,r1
    c.r[1] += 5;  // 0604FFFC add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604FFFE mov.b @r1,r1
    c.r[2] <<= 2;  // 06050000 shll2 r2
    c.r[2] += c.r[2];  // 06050002 add r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06050004 extu.b r1,r1
    c.r[1] >>= 2;  // 06050006 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06050008 shlr r1
    c.r[1] >>= 2;  // 0605000A shlr2 r1
    c.r[1] |= c.r[2];  // 0605000C or r2,r1
    c.t = c.r[3] >= c.r[1];  // 0605000E cmp/hs r1,r3
    { const bool k = c.t; c.r[0] = 0x3Fu; if (k) { goto L_06050018; } }  // 06050010 bt/s 0x06050018 ; mov #63,r0
    SH2_POLL(c); goto L_0604FEC2;  // 06050014 bra 0x0604FEC2 ; nop
L_06050018:
    c.r[2] = c.r[7];  // 06050018 mov r7,r2
L_0605001A:
    c.r[10] = ld32(c.r[14] + 16);  // 0605001A mov.l @(16,r14),r10
    c.r[2] += 5;  // 0605001C add #5,r2
    c.r[10] += 1;  // 0605001E add #1,r10
    st32(c.r[14] + 16, c.r[10]);  // 06050020 mov.l r10,@(16,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06050022 mov.b @r2,r1
    c.r[3] = 0x1Fu;  // 06050024 mov #31,r3
    c.r[3] &= c.r[1];  // 06050026 and r1,r3
    c.r[1] = c.r[7];  // 06050028 mov r7,r1
    c.r[1] += 6;  // 0605002A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605002C mov.b @r1,r1
    c.r[3] += c.r[3];  // 0605002E add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06050030 extu.b r1,r1
    c.r[1] >>= 2;  // 06050032 shlr2 r1
    c.r[1] >>= 2;  // 06050034 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06050036 shlr r1
    c.r[1] >>= 2;  // 06050038 shlr2 r1
    c.r[1] |= c.r[3];  // 0605003A or r3,r1
    c.t = c.r[10] >= c.r[1];  // 0605003C cmp/hs r1,r10
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 44); if (k) { goto L_06050046; } }  // 0605003E bt/s 0x06050046 ; mov.l @(44,r14),r0
    SH2_POLL(c); goto L_0604FE94;  // 06050042 bra 0x0604FE94 ; nop
L_06050046:
    c.r[14] += 64;  // 06050046 add #64,r14
    c.r[15] = c.r[14];  // 06050048 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605004A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605004C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605004E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06050050 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06050052 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050054 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050056 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050058 rts ; mov.l @r15+,r8
}

void f_06050074(SH2Context& c) {
    ran[1274] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050074 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06050076 mov r15,r14
    c.r[0] = c.r[6] & 0xFFu;  // 06050078 extu.b r6,r0
    c.r[2] = 0x1Fu;  // 0605007A mov #31,r2
    c.t = c.r[0] > c.r[2];  // 0605007C cmp/hi r2,r0
    { const bool k = !c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_0605008C; } }  // 0605007E bf/s 0x0605008C ; extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060500B0u);  // 06050082 mov.w 0x060500B0,r1
    c.r[4] += c.r[1];  // 06050084 add r1,r4
    c.r[1] = c.r[0];  // 06050086 mov r0,r1
    c.r[1] -= 32;  // 06050088 add #-32,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605008A extu.b r1,r0
L_0605008C:
    c.t = c.r[5] > c.r[2];  // 0605008C cmp/hi r2,r5
    if (!c.t) { goto L_0605009A; }  // 0605008E bf 0x0605009A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060500B2u);  // 06050090 mov.w 0x060500B2,r1
    c.r[4] += c.r[1];  // 06050092 add r1,r4
    c.r[1] = c.r[5];  // 06050094 mov r5,r1
    c.r[1] -= 32;  // 06050096 add #-32,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06050098 extu.b r1,r5
L_0605009A:
    c.r[0] <<= 2;  // 0605009A shll2 r0
    c.r[0] <<= 2;  // 0605009C shll2 r0
    c.r[0] += c.r[0];  // 0605009E add r0,r0
    c.r[0] <<= 2;  // 060500A0 shll2 r0
    c.r[5] += c.r[5];  // 060500A2 add r5,r5
    c.r[0] += c.r[5];  // 060500A4 add r5,r0
    c.r[0] += c.r[0];  // 060500A6 add r0,r0
    c.r[15] = c.r[14];  // 060500A8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060500AA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += c.r[4]; c.pc = x; return; }  // 060500AC rts ; add r4,r0
}

void f_060500B4(SH2Context& c) {
    ran[1275] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060500B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060500B6 sts.l pr,@-r15
    c.r[1] = ld32(0x060500E0u);  // 060500B8 mov.l 0x060500E0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060500BA mov.w @r1,r2
    c.r[3] = ld32(0x060500E4u);  // 060500BC mov.l 0x060500E4,r3
    c.r[1] = 0xAu;  // 060500BE mov #10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060500C0 mulu.w r1,r2
    c.r[5] = ld32(c.r[3] + 8);  // 060500C2 mov.l @(8,r3),r5
    c.r[1] = c.macl;  // 060500C4 sts macl,r1
    c.r[5] += c.r[1];  // 060500C6 add r1,r5
    c.r[1] = 0xCu;  // 060500C8 mov #12,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060500CA mulu.w r1,r2
    c.r[4] = ld32(c.r[3] + 12);  // 060500CC mov.l @(12,r3),r4
    c.r[1] = c.macl;  // 060500CE sts macl,r1
    c.r[4] += c.r[1];  // 060500D0 add r1,r4
    c.r[1] = ld32(0x060500E8u);  // 060500D2 mov.l 0x060500E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060500D8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060500D8u) return; }  // 060500D4 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060500D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060500DA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060500DC rts ; mov.l @r15+,r14
}

void f_060500F4(SH2Context& c) {
    ran[1276] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060500F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060500F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060500F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060500FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060500FC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060500FE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050100 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06050102 sts.l pr,@-r15
    c.r[15] -= 108;  // 06050104 add #-108,r15
    c.r[6] = ld32(0x06050154u);  // 06050106 mov.l 0x06050154,r6
    c.r[1] = c.r[6];  // 06050108 mov r6,r1
    c.r[1] += 16;  // 0605010A add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605010C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605010E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06050110 shlr r0
    c.r[0] &= 0x1u;  // 06050112 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06050114 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605015C; } }  // 06050116 bt/s 0x0605015C ; mov r15,r14
    c.r[2] = ld32(0x06050158u);  // 0605011A mov.l 0x06050158,r2
    c.r[1] = c.r[2];  // 0605011C mov r2,r1
    c.r[1] += 117;  // 0605011E add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050120 mov.b @r1,r3
    c.r[13] = 0x60u;  // 06050122 mov #96,r13
    c.r[1] = c.r[2];  // 06050124 mov r2,r1
    c.r[1] += 79;  // 06050126 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050128 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605012A extu.b r3,r3
    c.r[3] += c.r[1];  // 0605012C add r1,r3
    c.r[1] = c.r[2];  // 0605012E mov r2,r1
    c.r[1] += 116;  // 06050130 add #116,r1
    c.r[2] += 78;  // 06050132 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050134 mov.b @r1,r1
    c.r[3] <<= 2;  // 06050136 shll2 r3
    c.r[3] <<= 2;  // 06050138 shll2 r3
    c.r[3] <<= 2;  // 0605013A shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605013C mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0605013E extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 06050140 mov.l @r6,r2
    c.r[1] += c.r[7];  // 06050142 add r7,r1
    c.r[3] += c.r[2];  // 06050144 add r2,r3
    c.r[0] = c.r[3];  // 06050146 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06050148 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 0605014A add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0605014C extu.b r1,r1
    st32(c.r[13], c.r[1]); goto L_06050162;  // 0605014E bra 0x06050162 ; mov.l r1,@r13
L_0605015C:
    c.r[13] = (uint32_t)(int16_t)ld16(0x060502B6u);  // 0605015C mov.w 0x060502B6,r13
    c.r[0] = 0x60u;  // 0605015E mov #96,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06050160 mov.l r13,@(r0,r14)
L_06050162:
    c.r[13] = ld32(0x060502BCu);  // 06050162 mov.l 0x060502BC,r13
    c.r[0] = 0x64u;  // 06050164 mov #100,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06050166 mov.l r13,@(r0,r14)
    c.r[0] = 0x64u;  // 06050168 mov #100,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0605016A mov.l @(r0,r14),r1
    c.r[1] += 20;  // 0605016C add #20,r1
    c.r[12] = ld32(0x060502C0u);  // 0605016E mov.l 0x060502C0,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06050174u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050174u) return; }  // 06050170 jsr @r12 ; mov.b @r1,r4
    c.r[4] = c.r[0];  // 06050174 mov r0,r4
    c.r[5] = c.r[1];  // 06050176 mov r1,r5
    c.r[1] = ld32(0x060502C4u);  // 06050178 mov.l 0x060502C4,r1
    c.r[8] = ld32(c.r[1]);  // 0605017A mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0605017C mov.l @(4,r1),r9
    c.r[11] = ld32(0x060502C8u);  // 0605017E mov.l 0x060502C8,r11
    c.r[6] = c.r[8];  // 06050180 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06050186u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050186u) return; }  // 06050182 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 06050186 mov r0,r4
    c.r[10] = ld32(0x060502CCu);  // 06050188 mov.l 0x060502CC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0605018Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605018Eu) return; }  // 0605018A jsr @r10 ; mov r1,r5
    c.r[13] = 0x58u;  // 0605018E mov #88,r13
    c.r[13] += c.r[14];  // 06050190 add r14,r13
    st32(c.r[13], c.r[0]);  // 06050192 mov.l r0,@r13
    c.r[0] = 0x64u;  // 06050194 mov #100,r0
    c.r[0] += c.r[14];  // 06050196 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 06050198 mov.l @r0,r13
    c.r[13] += 21;  // 0605019A add #21,r13
    st32(c.r[0], c.r[13]);  // 0605019C mov.l r13,@r0
    c.r[0] = 0x64u;  // 0605019E mov #100,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060501A0 mov.l @(r0,r14),r13
    { const uint32_t x = c.r[12]; c.pr = 0x060501A6u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060501A6u) return; }  // 060501A2 jsr @r12 ; mov.b @r13,r4
    c.r[4] = c.r[0];  // 060501A6 mov r0,r4
    c.r[5] = c.r[1];  // 060501A8 mov r1,r5
    c.r[6] = c.r[8];  // 060501AA mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x060501B0u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060501B0u) return; }  // 060501AC jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 060501B0 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060501B6u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060501B6u) return; }  // 060501B2 jsr @r10 ; mov r1,r5
    c.r[13] = 0x5Cu;  // 060501B6 mov #92,r13
    c.r[13] += c.r[14];  // 060501B8 add r14,r13
    st32(c.r[13], c.r[0]);  // 060501BA mov.l r0,@r13
    c.r[1] = ld32(0x060502D0u);  // 060501BC mov.l 0x060502D0,r1
    st32(c.r[14] + 8, c.r[1]);  // 060501BE mov.l r1,@(8,r14)
    c.r[12] = 0x0u;  // 060501C0 mov #0,r12
    c.r[8] = 0x0u;  // 060501C2 mov #0,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x060502B6u);  // 060501C4 mov.w 0x060502B6,r9
    c.r[4] = (uint32_t)(int16_t)ld16(0x060502B8u);  // 060501C6 mov.w 0x060502B8,r4
    c.r[6] = ld32(0x060502D4u);  // 060501C8 mov.l 0x060502D4,r6
    c.r[5] = c.r[6];  // 060501CA mov r6,r5
    c.r[5] += 77;  // 060501CC add #77,r5
    c.r[3] = 0x0u;  // 060501CE mov #0,r3
L_060501D0:
    c.r[1] = ld32(0x060502D8u);  // 060501D0 mov.l 0x060502D8,r1
    c.r[0] = ld32(c.r[1]);  // 060501D2 mov.l @r1,r0
    c.r[7] = c.r[3];  // 060501D4 mov r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060501D6 mov.b @(r0,r3),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060501D8 extu.b r1,r2
    c.t = c.r[2] == c.r[9];  // 060501DA cmp/eq r9,r2
    { const bool k = c.t; c.r[7] += c.r[0]; if (k) { goto L_06050238; } }  // 060501DC bt/s 0x06050238 ; add r0,r7
    c.r[1] = c.r[7];  // 060501E0 mov r7,r1
    c.r[1] += 3;  // 060501E2 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060501E4 mov.b @r1,r0
    c.r[0] &= 0xC0u;  // 060501E6 and #192,r0
    c.t = c.r[0] == c.r[4];  // 060501E8 cmp/eq r4,r0
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06050238; } }  // 060501EA bf/s 0x06050238 ; mov r6,r1
    c.r[1] += 74;  // 060501EE add #74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060501F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060501F2 extu.b r1,r1
    c.r[1] -= 1;  // 060501F4 add #-1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060501F6 cmp/ge r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06050238; } }  // 060501F8 bf/s 0x06050238 ; mov r6,r1
    c.r[1] += 76;  // 060501FC add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060501FE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06050200 extu.b r1,r1
    c.r[1] += 1;  // 06050202 add #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06050204 cmp/gt r1,r2
    { const bool k = c.t; c.r[7] += 1; if (k) { goto L_06050238; } }  // 06050206 bt/s 0x06050238 ; add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605020A mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605020C extu.b r1,r2
    c.r[1] = c.r[6];  // 0605020E mov r6,r1
    c.r[1] += 75;  // 06050210 add #75,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050212 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06050214 extu.b r1,r1
    c.r[1] -= 1;  // 06050216 add #-1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06050218 cmp/ge r1,r2
    if (!c.t) { goto L_06050238; }  // 0605021A bf 0x06050238
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605021C mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605021E extu.b r1,r1
    c.r[1] += 1;  // 06050220 add #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06050222 cmp/gt r1,r2
    if (c.t) { goto L_06050238; }  // 06050224 bt 0x06050238
    c.r[0] = 0x60u;  // 06050226 mov #96,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06050228 mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[8];  // 0605022A cmp/eq r8,r0
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06050238; } }  // 0605022C bt/s 0x06050238 ; mov r14,r1
    c.r[1] += 12;  // 06050230 add #12,r1
    c.r[0] = c.r[1];  // 06050232 mov r1,r0
    st8(c.r[0] + c.r[12], c.r[8]);  // 06050234 mov.b r8,@(r0,r12)
    c.r[12] += 1;  // 06050236 add #1,r12
L_06050238:
    c.r[8] += 1;  // 06050238 add #1,r8
    c.r[1] = 0x49u;  // 0605023A mov #73,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0605023C cmp/gt r1,r8
    { const bool k = !c.t; c.r[3] += 16; if (k) { SH2_POLL(c); goto L_060501D0; } }  // 0605023E bf/s 0x060501D0 ; add #16,r3
    c.r[8] = 0x0u;  // 06050242 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12];  // 06050244 cmp/ge r12,r8
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060502F0; } }  // 06050246 bt/s 0x060502F0 ; mov r14,r1
    c.r[11] = ld32(0x060502DCu);  // 0605024A mov.l 0x060502DC,r11
    c.r[9] = ld32(0x060502E0u);  // 0605024C mov.l 0x060502E0,r9
L_0605024E:
    c.r[1] += 12;  // 0605024E add #12,r1
    c.r[0] = c.r[1];  // 06050250 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06050252 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06050254 extu.b r1,r3
    c.r[1] = ld32(0x060502D8u);  // 06050256 mov.l 0x060502D8,r1
    c.r[2] = c.r[3];  // 06050258 mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 0605025A mov.l @r1,r1
    c.r[2] <<= 2;  // 0605025C shll2 r2
    c.r[2] <<= 2;  // 0605025E shll2 r2
    c.r[2] += c.r[1];  // 06050260 add r1,r2
    c.r[2] += 3;  // 06050262 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06050264 mov.b @r2,r1
    c.r[13] = 0x3u;  // 06050266 mov #3,r13
    c.r[1] >>= 2;  // 06050268 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605026A shlr r1
    c.r[1] &= c.r[13];  // 0605026C and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605026E tst r1,r1
    if (c.t) { goto L_060502B0; }  // 06050270 bt 0x060502B0
    c.r[13] = 0x58u;  // 06050272 mov #88,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06050274 mov.w @r11,r1
    c.r[13] += c.r[14];  // 06050276 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06050278 mov.l @r13,r13
    c.r[3] += c.r[1];  // 0605027A add r1,r3
    c.r[3] += 1;  // 0605027C add #1,r3
    c.r[10] = c.r[3] & 0xFFFFu;  // 0605027E extu.w r3,r10
    c.r[3] = c.r[10];  // 06050280 mov r10,r3
    c.r[3] += c.r[3];  // 06050282 add r3,r3
    c.r[3] += c.r[10];  // 06050284 add r10,r3
    c.r[3] <<= 2;  // 06050286 shll2 r3
    c.r[2] = c.r[3];  // 06050288 mov r3,r2
    c.r[1] = ld32(c.r[9] + 12);  // 0605028A mov.l @(12,r9),r1
    c.r[0] = c.r[3];  // 0605028C mov r3,r0
    c.r[2] += c.r[1];  // 0605028E add r1,r2
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06050290 mov.l @(r0,r1),r1
    c.r[1] += c.r[13];  // 06050292 add r13,r1
    st32(c.r[14], c.r[1]);  // 06050294 mov.l r1,@r14
    c.r[0] = 0x5Cu;  // 06050296 mov #92,r0
    c.r[1] = ld32(c.r[2] + 4);  // 06050298 mov.l @(4,r2),r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0605029A mov.l @(r0,r14),r0
    c.r[1] += c.r[0];  // 0605029C add r0,r1
    st32(c.r[14] + 4, c.r[1]);  // 0605029E mov.l r1,@(4,r14)
    c.r[1] = 0xAu;  // 060502A0 mov #10,r1
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060502A2 mulu.w r1,r10
    c.r[5] = ld32(c.r[9] + 8);  // 060502A4 mov.l @(8,r9),r5
    c.r[1] = c.macl;  // 060502A6 sts macl,r1
    c.r[5] += c.r[1];  // 060502A8 add r1,r5
    c.r[1] = ld32(0x060502E4u);  // 060502AA mov.l 0x060502E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060502B0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060502B0u) return; }  // 060502AC jsr @r1 ; mov r14,r4
L_060502B0:
    c.r[8] += 1;  // 060502B0 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12]; goto L_060502E8;  // 060502B2 bra 0x060502E8 ; cmp/ge r12,r8
L_060502E8:
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_0605024E; } }  // 060502E8 bf/s 0x0605024E ; mov r14,r1
    c.r[8] = 0x0u;  // 060502EC mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12];  // 060502EE cmp/ge r12,r8
L_060502F0:
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060503E2; } }  // 060502F0 bt/s 0x060503E2 ; mov r14,r1
    c.r[9] = ld32(0x06050510u);  // 060502F4 mov.l 0x06050510,r9
    c.r[6] = c.r[9];  // 060502F6 mov r9,r6
    c.r[6] += 22;  // 060502F8 add #22,r6
    c.r[11] = ld32(0x06050514u);  // 060502FA mov.l 0x06050514,r11
L_060502FC:
    c.r[1] += 12;  // 060502FC add #12,r1
    c.r[0] = c.r[1];  // 060502FE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06050300 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06050302 extu.b r1,r3
    c.r[1] = ld32(0x06050518u);  // 06050304 mov.l 0x06050518,r1
    c.r[2] = c.r[3];  // 06050306 mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 06050308 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605030A shll2 r2
    c.r[2] <<= 2;  // 0605030C shll2 r2
    c.r[2] += c.r[1];  // 0605030E add r1,r2
    c.r[2] += 3;  // 06050310 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06050312 mov.b @r2,r1
    c.r[13] = 0x3u;  // 06050314 mov #3,r13
    c.r[1] >>= 2;  // 06050316 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06050318 shlr r1
    c.r[1] &= c.r[13];  // 0605031A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605031C tst r1,r1
    if (!c.t) { goto L_060503DA; }  // 0605031E bf 0x060503DA
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06050320 mov.w @r6,r7
    c.r[13] = 0x58u;  // 06050322 mov #88,r13
    c.r[2] = ld32(c.r[11] + 12);  // 06050324 mov.l @(12,r11),r2
    c.r[13] += c.r[14];  // 06050326 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06050328 mov.l @r13,r13
    c.r[3] += c.r[7];  // 0605032A add r7,r3
    c.r[3] += 1;  // 0605032C add #1,r3
    c.r[10] = c.r[3] & 0xFFFFu;  // 0605032E extu.w r3,r10
    c.r[3] = c.r[10];  // 06050330 mov r10,r3
    c.r[3] += c.r[3];  // 06050332 add r3,r3
    c.r[3] += c.r[10];  // 06050334 add r10,r3
    c.r[3] <<= 2;  // 06050336 shll2 r3
    c.r[1] = c.r[3];  // 06050338 mov r3,r1
    c.r[0] = c.r[3];  // 0605033A mov r3,r0
    c.r[3] = ld32(c.r[0] + c.r[2]);  // 0605033C mov.l @(r0,r2),r3
    c.r[1] += c.r[2];  // 0605033E add r2,r1
    c.r[3] += c.r[13];  // 06050340 add r13,r3
    st32(c.r[14], c.r[3]);  // 06050342 mov.l r3,@r14
    c.r[0] = 0x5Cu;  // 06050344 mov #92,r0
    c.r[1] = ld32(c.r[1] + 4);  // 06050346 mov.l @(4,r1),r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06050348 mov.l @(r0,r14),r0
    c.r[1] += c.r[0];  // 0605034A add r0,r1
    st32(c.r[14] + 4, c.r[1]);  // 0605034C mov.l r1,@(4,r14)
    c.r[1] = c.r[9];  // 0605034E mov r9,r1
    c.r[1] += 16;  // 06050350 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050352 mov.b @r1,r1
    c.r[13] = 0x1u;  // 06050354 mov #1,r13
    c.r[1] >>= 2;  // 06050356 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06050358 shlr r1
    c.r[1] &= c.r[13];  // 0605035A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605035C tst r1,r1
    { const bool k = c.t; c.r[1] = 0xAu; if (k) { goto L_060503C2; } }  // 0605035E bt/s 0x060503C2 ; mov #10,r1
    c.r[1] = c.r[7] & 0xFFFFu;  // 06050362 extu.w r7,r1
    c.r[7] = c.r[1];  // 06050364 mov r1,r7
    c.r[7] += c.r[7];  // 06050366 add r7,r7
    c.r[7] += c.r[1];  // 06050368 add r1,r7
    c.r[7] <<= 2;  // 0605036A shll2 r7
    c.r[0] = c.r[7];  // 0605036C mov r7,r0
    st32(c.r[0] + c.r[2], c.r[3]);  // 0605036E mov.l r3,@(r0,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06050370 mov.w @r6,r1
    c.r[2] = ld32(c.r[11] + 12);  // 06050372 mov.l @(12,r11),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050374 extu.w r1,r1
    c.r[3] = c.r[1];  // 06050376 mov r1,r3
    c.r[3] += c.r[3];  // 06050378 add r3,r3
    c.r[3] += c.r[1];  // 0605037A add r1,r3
    c.r[3] <<= 2;  // 0605037C shll2 r3
    c.r[3] += c.r[2];  // 0605037E add r2,r3
    c.r[2] = ld32(c.r[14] + 4);  // 06050380 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[9] + 4);  // 06050382 mov.l @(4,r9),r1
    c.r[13] = 0x68u;  // 06050384 mov #104,r13
    c.r[2] -= c.r[1];  // 06050386 sub r1,r2
    st32(c.r[3] + 4, c.r[2]);  // 06050388 mov.l r2,@(4,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605038A mov.w @r6,r1
    c.r[13] += c.r[14];  // 0605038C add r14,r13
    c.r[2] = ld32(c.r[11] + 12);  // 0605038E mov.l @(12,r11),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050390 extu.w r1,r1
    c.r[3] = c.r[1];  // 06050392 mov r1,r3
    c.r[3] += c.r[3];  // 06050394 add r3,r3
    c.r[3] += c.r[1];  // 06050396 add r1,r3
    c.r[3] <<= 2;  // 06050398 shll2 r3
    c.r[1] = ld32(c.r[9] + 8);  // 0605039A mov.l @(8,r9),r1
    c.r[3] += c.r[2];  // 0605039C add r2,r3
    st32(c.r[3] + 8, c.r[1]);  // 0605039E mov.l r1,@(8,r3)
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 060503A0 mov.w @r6,r2
    c.r[1] = 0xAu;  // 060503A2 mov #10,r1
    c.r[5] = ld32(c.r[11] + 8);  // 060503A4 mov.l @(8,r11),r5
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060503A6 mulu.w r1,r2
    c.r[4] = ld32(c.r[11] + 12);  // 060503A8 mov.l @(12,r11),r4
    c.r[1] = c.macl;  // 060503AA sts macl,r1
    c.r[5] += c.r[1];  // 060503AC add r1,r5
    c.r[1] = 0xCu;  // 060503AE mov #12,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060503B0 mulu.w r1,r2
    c.r[1] = c.macl;  // 060503B2 sts macl,r1
    c.r[4] += c.r[1];  // 060503B4 add r1,r4
    c.r[1] = ld32(0x0605051Cu);  // 060503B6 mov.l 0x0605051C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060503BCu; st32(c.r[13], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060503BCu) return; }  // 060503B8 jsr @r1 ; mov.l r6,@r13
    c.r[0] = 0x68u;  // 060503BC mov #104,r0
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 060503BE mov.l @(r0,r14),r6
    c.r[1] = 0xAu;  // 060503C0 mov #10,r1
L_060503C2:
    c.r[5] = ld32(c.r[11] + 8);  // 060503C2 mov.l @(8,r11),r5
    c.r[4] = c.r[14];  // 060503C4 mov r14,r4
    c.r[13] = 0x68u;  // 060503C6 mov #104,r13
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060503C8 mulu.w r1,r10
    c.r[13] += c.r[14];  // 060503CA add r14,r13
    c.r[1] = c.macl;  // 060503CC sts macl,r1
    c.r[5] += c.r[1];  // 060503CE add r1,r5
    c.r[1] = ld32(0x0605051Cu);  // 060503D0 mov.l 0x0605051C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060503D6u; st32(c.r[13], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060503D6u) return; }  // 060503D2 jsr @r1 ; mov.l r6,@r13
    c.r[0] = 0x68u;  // 060503D6 mov #104,r0
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 060503D8 mov.l @(r0,r14),r6
L_060503DA:
    c.r[8] += 1;  // 060503DA add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12];  // 060503DC cmp/ge r12,r8
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_060502FC; } }  // 060503DE bf/s 0x060502FC ; mov r14,r1
L_060503E2:
    c.r[9] = ld32(0x06050510u);  // 060503E2 mov.l 0x06050510,r9
    c.r[1] = c.r[9];  // 060503E4 mov r9,r1
    c.r[1] += 16;  // 060503E6 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060503E8 mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 060503EA extu.b r1,r11
    c.r[0] = c.r[11];  // 060503EC mov r11,r0
    c.r[0] >>= 2;  // 060503EE shlr2 r0
    c.r[0] &= 0x1u;  // 060503F0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060503F2 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x60u; if (k) { goto L_06050404; } }  // 060503F4 bt/s 0x06050404 ; mov #96,r0
    c.r[1] = ld32(0x06050520u);  // 060503F8 mov.l 0x06050520,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060503FA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060503FC extu.b r1,r1
    c.r[13] = 0x60u;  // 060503FE mov #96,r13
    c.r[13] += c.r[14];  // 06050400 add r14,r13
    st32(c.r[13], c.r[1]);  // 06050402 mov.l r1,@r13
L_06050404:
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06050404 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605050Au);  // 06050406 mov.w 0x0605050A,r1
    c.t = c.r[0] == c.r[1];  // 06050408 cmp/eq r1,r0
    { const bool k = c.t; c.r[13] = 0x60u; if (k) { goto L_060504F4; } }  // 0605040A bt/s 0x060504F4 ; mov #96,r13
    c.r[13] += c.r[14];  // 0605040E add r14,r13
    c.r[6] = ld32(c.r[13]);  // 06050410 mov.l @r13,r6
    c.r[1] = ld32(0x06050518u);  // 06050412 mov.l 0x06050518,r1
    c.r[1] = ld32(c.r[1]);  // 06050414 mov.l @r1,r1
    c.r[6] <<= 2;  // 06050416 shll2 r6
    c.r[6] <<= 2;  // 06050418 shll2 r6
    c.r[6] += c.r[1];  // 0605041A add r1,r6
    c.r[6] += 3;  // 0605041C add #3,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605041E mov.b @r6,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605050Cu);  // 06050420 mov.w 0x0605050C,r2
    c.r[2] &= c.r[1];  // 06050422 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605050Cu);  // 06050424 mov.w 0x0605050C,r1
    c.t = c.r[2] == c.r[1];  // 06050426 cmp/eq r1,r2
    { const bool k = !c.t; c.r[8] = c.r[9]; if (k) { goto L_060504F4; } }  // 06050428 bf/s 0x060504F4 ; mov r9,r8
    c.r[8] += 22;  // 0605042C add #22,r8
    c.r[0] = 0x60u;  // 0605042E mov #96,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06050430 mov.w @r8,r5
    c.r[0] += c.r[14];  // 06050432 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 06050434 mov.l @r0,r13
    c.r[13] += c.r[5];  // 06050436 add r5,r13
    st32(c.r[0], c.r[13]);  // 06050438 mov.l r13,@r0
    c.r[0] = 0x60u;  // 0605043A mov #96,r0
    c.r[0] += c.r[14];  // 0605043C add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0605043E mov.l @r0,r13
    c.r[4] = ld32(0x06050514u);  // 06050440 mov.l 0x06050514,r4
    c.r[13] += 1;  // 06050442 add #1,r13
    st32(c.r[0], c.r[13]);  // 06050444 mov.l r13,@r0
    c.r[0] = 0x62u;  // 06050446 mov #98,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06050448 mov.w @(r0,r14),r0
    c.r[13] = 0x58u;  // 0605044A mov #88,r13
    c.r[3] = ld32(c.r[4] + 12);  // 0605044C mov.l @(12,r4),r3
    c.r[13] += c.r[14];  // 0605044E add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06050450 mov.l @r13,r13
    c.r[10] = c.r[0] & 0xFFFFu;  // 06050452 extu.w r0,r10
    c.r[1] = c.r[10];  // 06050454 mov r10,r1
    c.r[1] += c.r[1];  // 06050456 add r1,r1
    c.r[1] += c.r[10];  // 06050458 add r10,r1
    c.r[1] <<= 2;  // 0605045A shll2 r1
    c.r[2] = c.r[1];  // 0605045C mov r1,r2
    c.r[0] = c.r[1];  // 0605045E mov r1,r0
    c.r[7] = ld32(c.r[0] + c.r[3]);  // 06050460 mov.l @(r0,r3),r7
    c.r[2] += c.r[3];  // 06050462 add r3,r2
    c.r[7] += c.r[13];  // 06050464 add r13,r7
    st32(c.r[14], c.r[7]);  // 06050466 mov.l r7,@r14
    c.r[0] = 0x5Cu;  // 06050468 mov #92,r0
    c.r[1] = ld32(c.r[2] + 4);  // 0605046A mov.l @(4,r2),r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0605046C mov.l @(r0,r14),r0
    c.r[1] += c.r[0];  // 0605046E add r0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06050470 mov.l r1,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06050472 mov.b @r6,r1
    c.r[13] = 0x3u;  // 06050474 mov #3,r13
    c.r[1] >>= 2;  // 06050476 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06050478 shlr r1
    c.r[1] &= c.r[13];  // 0605047A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605047C tst r1,r1
    { const bool k = !c.t; c.r[11] >>= 2; if (k) { goto L_060504E2; } }  // 0605047E bf/s 0x060504E2 ; shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 06050482 shlr r11
    c.r[0] = 0x1u;  // 06050484 mov #1,r0
    c.r[11] &= c.r[0];  // 06050486 and r0,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 06050488 tst r11,r11
    { const bool k = c.t; c.r[1] = c.r[5] & 0xFFFFu; if (k) { goto L_060504E2; } }  // 0605048A bt/s 0x060504E2 ; extu.w r5,r1
    c.r[2] = c.r[1];  // 0605048E mov r1,r2
    c.r[2] += c.r[2];  // 06050490 add r2,r2
    c.r[2] += c.r[1];  // 06050492 add r1,r2
    c.r[2] <<= 2;  // 06050494 shll2 r2
    c.r[0] = c.r[2];  // 06050496 mov r2,r0
    st32(c.r[0] + c.r[3], c.r[7]);  // 06050498 mov.l r7,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605049A mov.w @r8,r1
    c.r[2] = ld32(c.r[4] + 12);  // 0605049C mov.l @(12,r4),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605049E extu.w r1,r1
    c.r[3] = c.r[1];  // 060504A0 mov r1,r3
    c.r[3] += c.r[3];  // 060504A2 add r3,r3
    c.r[3] += c.r[1];  // 060504A4 add r1,r3
    c.r[3] <<= 2;  // 060504A6 shll2 r3
    c.r[3] += c.r[2];  // 060504A8 add r2,r3
    c.r[2] = ld32(c.r[14] + 4);  // 060504AA mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[9] + 4);  // 060504AC mov.l @(4,r9),r1
    c.r[2] -= c.r[1];  // 060504AE sub r1,r2
    st32(c.r[3] + 4, c.r[2]);  // 060504B0 mov.l r2,@(4,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060504B2 mov.w @r8,r1
    c.r[2] = ld32(c.r[4] + 12);  // 060504B4 mov.l @(12,r4),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060504B6 extu.w r1,r1
    c.r[3] = c.r[1];  // 060504B8 mov r1,r3
    c.r[3] += c.r[3];  // 060504BA add r3,r3
    c.r[3] += c.r[1];  // 060504BC add r1,r3
    c.r[3] <<= 2;  // 060504BE shll2 r3
    c.r[1] = ld32(c.r[9] + 8);  // 060504C0 mov.l @(8,r9),r1
    c.r[3] += c.r[2];  // 060504C2 add r2,r3
    st32(c.r[3] + 8, c.r[1]);  // 060504C4 mov.l r1,@(8,r3)
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060504C6 mov.w @r8,r2
    c.r[1] = 0xAu;  // 060504C8 mov #10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060504CA mulu.w r1,r2
    c.r[5] = ld32(c.r[4] + 8);  // 060504CC mov.l @(8,r4),r5
    c.r[1] = c.macl;  // 060504CE sts macl,r1
    c.r[5] += c.r[1];  // 060504D0 add r1,r5
    c.r[1] = 0xCu;  // 060504D2 mov #12,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060504D4 mulu.w r1,r2
    c.r[4] = ld32(c.r[4] + 12);  // 060504D6 mov.l @(12,r4),r4
    c.r[1] = c.macl;  // 060504D8 sts macl,r1
    c.r[4] += c.r[1];  // 060504DA add r1,r4
    c.r[1] = ld32(0x0605051Cu);  // 060504DC mov.l 0x0605051C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060504E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060504E2u) return; }  // 060504DE jsr @r1 ; nop
L_060504E2:
    c.r[2] = ld32(0x06050514u);  // 060504E2 mov.l 0x06050514,r2
    c.r[1] = 0xAu;  // 060504E4 mov #10,r1
    c.r[5] = ld32(c.r[2] + 8);  // 060504E6 mov.l @(8,r2),r5
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060504E8 mulu.w r1,r10
    c.r[1] = c.macl;  // 060504EA sts macl,r1
    c.r[5] += c.r[1];  // 060504EC add r1,r5
    c.r[1] = ld32(0x0605051Cu);  // 060504EE mov.l 0x0605051C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060504F4u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060504F4u) return; }  // 060504F0 jsr @r1 ; mov r14,r4
L_060504F4:
    c.r[14] += 108;  // 060504F4 add #108,r14
    c.r[15] = c.r[14];  // 060504F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060504F8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060504FA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060504FC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060504FE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06050500 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050502 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050504 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050506 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
