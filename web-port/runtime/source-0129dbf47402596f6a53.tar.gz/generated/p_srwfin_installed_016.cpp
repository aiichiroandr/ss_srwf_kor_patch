#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0603D938(SH2Context& c) {
    ran[977] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D938 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D93A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D93C sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603D93E mov r5,r8
    c.r[1] = c.r[8];  // 0603D940 mov r8,r1
    c.r[1] += 1;  // 0603D942 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D944 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603D946 extu.b r5,r5
    c.r[1] = c.r[8];  // 0603D948 mov r8,r1
    c.r[1] += 2;  // 0603D94A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D94C mov.b @r1,r1
    c.r[5] <<= 8;  // 0603D94E shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603D950 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603D952 or r1,r5
    c.r[1] = ld32(0x0603D968u);  // 0603D954 mov.l 0x0603D968,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603D95Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D95Au) return; }  // 0603D956 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0603D95A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D95C lds.l @r15+,pr
    c.r[8] += 3;  // 0603D95E add #3,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D960 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603D962 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D964 rts ; mov.l @r15+,r8
}

void f_0603D96C(SH2Context& c) {
    ran[978] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D96C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D96E mov r15,r14
    c.r[1] = ld32(0x0603D9C0u);  // 0603D970 mov.l 0x0603D9C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D972 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D974 extu.b r1,r1
    c.r[1] >>= 2;  // 0603D976 shlr2 r1
    c.r[1] >>= 2;  // 0603D978 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603D97A shlr r1
    c.r[1] >>= 2;  // 0603D97C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D97E tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { goto L_0603D9B2; } }  // 0603D980 bf/s 0x0603D9B2 ; mov r5,r0
    c.r[2] = ld32(0x0603D9C4u);  // 0603D984 mov.l 0x0603D9C4,r2
    c.r[3] = c.r[2];  // 0603D986 mov r2,r3
    c.r[1] = c.r[0];  // 0603D988 mov r0,r1
    c.r[1] += 1;  // 0603D98A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D98C mov.b @r1,r1
    c.r[3] += 2;  // 0603D98E add #2,r3
    st8(c.r[3], c.r[1]);  // 0603D990 mov.b r1,@r3
    c.r[3] = c.r[2];  // 0603D992 mov r2,r3
    c.r[1] = c.r[0];  // 0603D994 mov r0,r1
    c.r[1] += 2;  // 0603D996 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D998 mov.b @r1,r1
    c.r[3] += 3;  // 0603D99A add #3,r3
    st8(c.r[3], c.r[1]);  // 0603D99C mov.b r1,@r3
    c.r[3] = c.r[2];  // 0603D99E mov r2,r3
    c.r[3] += 1;  // 0603D9A0 add #1,r3
    c.r[1] = c.r[0];  // 0603D9A2 mov r0,r1
    c.r[1] += 3;  // 0603D9A4 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D9A6 mov.b @r1,r1
    c.r[2] += 4;  // 0603D9A8 add #4,r2
    c.r[1] -= 1;  // 0603D9AA add #-1,r1
    st8(c.r[3], c.r[1]);  // 0603D9AC mov.b r1,@r3
    c.r[1] = 0x10u;  // 0603D9AE mov #16,r1
    st16(c.r[2], c.r[1]);  // 0603D9B0 mov.w r1,@r2
L_0603D9B2:
    c.r[2] = ld32(0x0603D9C8u);  // 0603D9B2 mov.l 0x0603D9C8,r2
    c.r[1] = 0x0u;  // 0603D9B4 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603D9B6 mov.b r1,@r2
    c.r[15] = c.r[14];  // 0603D9B8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D9BA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 4; c.pc = x; return; }  // 0603D9BC rts ; add #4,r0
}

void f_0603D9CC(SH2Context& c) {
    ran[979] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D9CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D9CE mov r15,r14
    c.r[1] = 0x0u;  // 0603D9D0 mov #0,r1
    st32(c.r[4] + 40, c.r[1]);  // 0603D9D2 mov.l r1,@(40,r4)
    c.r[7] = c.r[4];  // 0603D9D4 mov r4,r7
    c.r[7] += 66;  // 0603D9D6 add #66,r7
    c.r[3] = c.r[4];  // 0603D9D8 mov r4,r3
    c.r[3] += 69;  // 0603D9DA add #69,r3
    c.r[1] = c.r[4];  // 0603D9DC mov r4,r1
    c.r[1] += 70;  // 0603D9DE add #70,r1
    c.r[2] = 0x0u;  // 0603D9E0 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0603D9E2 mov.b r2,@r1
    st8(c.r[3], c.r[2]);  // 0603D9E4 mov.b r2,@r3
    st8(c.r[7], c.r[2]);  // 0603D9E6 mov.b r2,@r7
    c.r[7] = c.r[4];  // 0603D9E8 mov r4,r7
    c.r[7] += 16;  // 0603D9EA add #16,r7
    c.r[3] = c.r[4];  // 0603D9EC mov r4,r3
    c.r[3] += 18;  // 0603D9EE add #18,r3
    c.r[1] = 0x0u;  // 0603D9F0 mov #0,r1
    st16(c.r[3], c.r[1]);  // 0603D9F2 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0603D9F4 mov.w r1,@r7
    c.r[3] = c.r[4];  // 0603D9F6 mov r4,r3
    c.r[3] += 67;  // 0603D9F8 add #67,r3
    c.r[1] = c.r[4];  // 0603D9FA mov r4,r1
    c.r[1] += 68;  // 0603D9FC add #68,r1
    st8(c.r[1], c.r[2]);  // 0603D9FE mov.b r2,@r1
    st8(c.r[3], c.r[2]);  // 0603DA00 mov.b r2,@r3
    c.r[4] += 60;  // 0603DA02 add #60,r4
    c.r[2] = 0x1u;  // 0603DA04 mov #1,r2
    st8(c.r[4], c.r[2]);  // 0603DA06 mov.b r2,@r4
    c.r[1] = ld32(0x0603DA14u);  // 0603DA08 mov.l 0x0603DA14,r1
    st8(c.r[1], c.r[2]);  // 0603DA0A mov.b r2,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DA0C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0603DA0E rts ; mov #0,r0
}

void f_0603DA18(SH2Context& c) {
    ran[980] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603DA18 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DA1A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603DA1C sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0603DA1E mov r4,r8
    c.r[1] = ld32(0x0603DA54u);  // 0603DA20 mov.l 0x0603DA54,r1
    c.r[1] = ld32(c.r[1]);  // 0603DA22 mov.l @r1,r1
    c.r[2] = c.r[8];  // 0603DA24 mov r8,r2
    c.r[2] -= c.r[1];  // 0603DA26 sub r1,r2
    c.r[1] = ld32(0x0603DA58u);  // 0603DA28 mov.l 0x0603DA58,r1
    c.macl = c.r[2] * c.r[1];  // 0603DA2A mul.l r1,r2
    c.r[14] = c.r[15];  // 0603DA2C mov r15,r14
    c.r[4] = c.macl;  // 0603DA2E sts macl,r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 0603DA30 shar r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 0603DA32 shar r4
    c.r[4] = c.r[4] & 0xFFu;  // 0603DA34 extu.b r4,r4
    c.r[1] = ld32(0x0603DA5Cu);  // 0603DA36 mov.l 0x0603DA5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603DA3Cu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DA3Cu) return; }  // 0603DA38 jsr @r1 ; mov r4,r5
    c.r[8] += 60;  // 0603DA3C add #60,r8
    c.r[2] = 0x1u;  // 0603DA3E mov #1,r2
    st8(c.r[8], c.r[2]);  // 0603DA40 mov.b r2,@r8
    c.r[1] = ld32(0x0603DA60u);  // 0603DA42 mov.l 0x0603DA60,r1
    st8(c.r[1], c.r[2]);  // 0603DA44 mov.b r2,@r1
    c.r[15] = c.r[14];  // 0603DA46 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603DA48 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DA4A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0603DA4C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0603DA4E rts ; mov #0,r0
}

void f_0603DA64(SH2Context& c) {
    ran[981] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603DA64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603DA66 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DA68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603DA6A sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0603DA6C mov r5,r9
    c.r[1] = c.r[9];  // 0603DA6E mov r9,r1
    c.r[1] += 1;  // 0603DA70 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DA72 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603DA74 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603DA76 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603DA8C; } }  // 0603DA78 bt/s 0x0603DA8C ; mov r15,r14
    c.r[1] = 0x1u;  // 0603DA7C mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0603DA7E cmp/gt r1,r0
    { const bool k = !c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0603DA98; } }  // 0603DA80 bf/s 0x0603DA98 ; cmp/eq #2,r0
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0603DA92; } }  // 0603DA84 bt/s 0x0603DA92 ; mov #0,r8
    goto L_0603DA9A;  // 0603DA88 bra 0x0603DA9A ; nop
L_0603DA8C:
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603DAC4u);  // 0603DA8C mov.w 0x0603DAC4,r8
    goto L_0603DA9A;  // 0603DA8E bra 0x0603DA9A ; nop
L_0603DA92:
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603DAC6u);  // 0603DA92 mov.w 0x0603DAC6,r8
    goto L_0603DA9A;  // 0603DA94 bra 0x0603DA9A ; nop
L_0603DA98:
    c.r[8] = 0x0u;  // 0603DA98 mov #0,r8
L_0603DA9A:
    c.r[1] = ld32(0x0603DAC8u);  // 0603DA9A mov.l 0x0603DAC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603DAA0u; c.r[4] = 0x6Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DAA0u) return; }  // 0603DA9C jsr @r1 ; mov #111,r4
    c.r[1] = ld32(0x0603DACCu);  // 0603DAA0 mov.l 0x0603DACC,r1
    c.r[6] = c.r[8];  // 0603DAA2 mov r8,r6
    c.r[5] = c.r[8];  // 0603DAA4 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603DAAAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DAAAu) return; }  // 0603DAA6 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0603DAD0u);  // 0603DAAA mov.l 0x0603DAD0,r1
    c.r[6] = c.r[8];  // 0603DAAC mov r8,r6
    c.r[5] = c.r[8];  // 0603DAAE mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603DAB4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DAB4u) return; }  // 0603DAB0 jsr @r1 ; mov r8,r4
    c.r[15] = c.r[14];  // 0603DAB4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603DAB6 lds.l @r15+,pr
    c.r[9] += 2;  // 0603DAB8 add #2,r9
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DABA mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603DABC mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603DABE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603DAC0 rts ; mov.l @r15+,r8
}

void f_0603DAD4(SH2Context& c) {
    ran[982] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DAD4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603DAD6 mov r15,r14
    c.r[0] = c.r[5];  // 0603DAD8 mov r5,r0
    c.r[2] = ld32(0x0603DAF4u);  // 0603DADA mov.l 0x0603DAF4,r2
    c.r[3] = c.r[0];  // 0603DADC mov r0,r3
    c.r[3] += 1;  // 0603DADE add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603DAE0 mov.b @r3,r1
    c.r[1] = 0u - c.r[1];  // 0603DAE2 neg r1,r1
    st8(c.r[2], c.r[1]);  // 0603DAE4 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603DAE6 mov.b @r3,r1
    c.r[2] = ld32(0x0603DAF8u);  // 0603DAE8 mov.l 0x0603DAF8,r2
    st8(c.r[2], c.r[1]);  // 0603DAEA mov.b r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DAEC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603DAEE rts ; add #2,r0
}

void f_0603DAFC(SH2Context& c) {
    ran[983] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DAFC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603DAFE mov r15,r14
    c.r[0] = c.r[5];  // 0603DB00 mov r5,r0
    c.r[2] = ld32(0x0603DB24u);  // 0603DB02 mov.l 0x0603DB24,r2
    c.r[3] = c.r[2];  // 0603DB04 mov r2,r3
    c.r[3] += 4;  // 0603DB06 add #4,r3
    c.r[1] = 0x1u;  // 0603DB08 mov #1,r1
    st16(c.r[3], c.r[1]);  // 0603DB0A mov.w r1,@r3
    c.r[2] += 2;  // 0603DB0C add #2,r2
    c.r[1] = c.r[0];  // 0603DB0E mov r0,r1
    c.r[1] += 1;  // 0603DB10 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DB12 mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 0603DB14 mov.b r1,@r2
    c.r[2] = ld32(0x0603DB28u);  // 0603DB16 mov.l 0x0603DB28,r2
    c.r[1] = 0x0u;  // 0603DB18 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603DB1A mov.b r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DB1C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603DB1E rts ; add #2,r0
}

void f_0603DB34(SH2Context& c) {
    ran[984] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603DB34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603DB36 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603DB38 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603DB3A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603DB3C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603DB3E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DB40 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603DB42 sts.l pr,@-r15
    c.r[15] -= 20;  // 0603DB44 add #-20,r15
    c.r[14] = c.r[15];  // 0603DB46 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0603DB48 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0603DB4A mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603DB4C mov.b @r5,r1
    c.r[2] = 0x1u;  // 0603DB4E mov #1,r2
    c.r[5] = 0x7Fu;  // 0603DB50 mov #127,r5
    c.r[5] &= c.r[1];  // 0603DB52 and r1,r5
    c.r[1] = c.r[5];  // 0603DB54 mov r5,r1
    c.r[1] -= 2;  // 0603DB56 add #-2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603DB58 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0603DB5A cmp/hi r2,r1
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { goto L_0603DB64; } }  // 0603DB5C bf/s 0x0603DB64 ; mov r5,r0
    goto L_0603DC90;  // 0603DB60 bra 0x0603DC90 ; nop
L_0603DB64:
    c.t = c.r[0] == 0x2u;  // 0603DB64 cmp/eq #2,r0
    if (!c.t) { goto L_0603DBDA; }  // 0603DB66 bf 0x0603DBDA
    c.r[1] = ld32(0x0603DCCCu);  // 0603DB68 mov.l 0x0603DCCC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DB6A mov.b @r1,r1
    c.r[13] = ld32(0x0603DCD0u);  // 0603DB6C mov.l 0x0603DCD0,r13
    st32(c.r[14] + 12, c.r[1]);  // 0603DB6E mov.l r1,@(12,r14)
    c.r[1] = c.r[13];  // 0603DB70 mov r13,r1
    c.r[1] += 78;  // 0603DB72 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DB74 mov.b @r1,r1
    c.r[4] = ld32(c.r[14] + 12);  // 0603DB76 mov.l @(12,r14),r4
    c.r[0] = ld32(0x0603DCD4u);  // 0603DB78 mov.l 0x0603DCD4,r0
    c.r[4] -= c.r[1];  // 0603DB7A sub r1,r4
    c.r[4] <<= 2;  // 0603DB7C shll2 r4
    c.r[4] <<= 2;  // 0603DB7E shll2 r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DCC4u);  // 0603DB80 mov.w 0x0603DCC4,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0603DB86u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DB86u) return; }  // 0603DB82 jsr @r0 ; add r1,r4
    c.r[4] = c.r[0];  // 0603DB86 mov r0,r4
    c.r[5] = c.r[1];  // 0603DB88 mov r1,r5
    c.r[1] = ld32(0x0603DCD8u);  // 0603DB8A mov.l 0x0603DCD8,r1
    c.r[8] = ld32(c.r[1]);  // 0603DB8C mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603DB8E mov.l @(4,r1),r9
    c.r[0] = ld32(0x0603DCDCu);  // 0603DB90 mov.l 0x0603DCDC,r0
    c.r[6] = c.r[8];  // 0603DB92 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603DB98u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DB98u) return; }  // 0603DB94 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603DB98 mov r0,r4
    c.r[10] = ld32(0x0603DCE0u);  // 0603DB9A mov.l 0x0603DCE0,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0603DBA0u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DBA0u) return; }  // 0603DB9C jsr @r10 ; mov r1,r5
    st32(c.r[14] + 8, c.r[0]);  // 0603DBA0 mov.l r0,@(8,r14)
    c.r[1] = ld32(0x0603DCE4u);  // 0603DBA2 mov.l 0x0603DCE4,r1
    c.r[13] += 79;  // 0603DBA4 add #79,r13
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DBA6 mov.b @r1,r11
    c.r[0] = ld32(0x0603DCD4u);  // 0603DBA8 mov.l 0x0603DCD4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603DBAA mov.b @r13,r1
    c.r[4] = c.r[11];  // 0603DBAC mov r11,r4
    c.r[4] -= c.r[1];  // 0603DBAE sub r1,r4
    c.r[4] <<= 2;  // 0603DBB0 shll2 r4
    c.r[4] <<= 2;  // 0603DBB2 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0603DBB8u; c.r[4] -= 105; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DBB8u) return; }  // 0603DBB4 jsr @r0 ; add #-105,r4
    c.r[4] = c.r[0];  // 0603DBB8 mov r0,r4
    c.r[5] = c.r[1];  // 0603DBBA mov r1,r5
    c.r[6] = c.r[8];  // 0603DBBC mov r8,r6
    c.r[0] = ld32(0x0603DCDCu);  // 0603DBBE mov.l 0x0603DCDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603DBC4u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DBC4u) return; }  // 0603DBC0 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603DBC4 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0603DBCAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DBCAu) return; }  // 0603DBC6 jsr @r10 ; mov r1,r5
    c.r[3] = c.r[0];  // 0603DBCA mov r0,r3
    c.r[1] = ld32(0x0603DCE8u);  // 0603DBCC mov.l 0x0603DCE8,r1
    c.r[1] = ld32(c.r[1]);  // 0603DBCE mov.l @r1,r1
    c.r[11] <<= 2;  // 0603DBD0 shll2 r11
    c.r[11] <<= 2;  // 0603DBD2 shll2 r11
    c.r[11] <<= 2;  // 0603DBD4 shll2 r11
    c.r[0] = ld32(c.r[14] + 12); goto L_0603DC4A;  // 0603DBD6 bra 0x0603DC4A ; mov.l @(12,r14),r0
L_0603DBDA:
    c.r[1] = ld32(0x0603DCECu);  // 0603DBDA mov.l 0x0603DCEC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DBDC mov.b @r1,r1
    c.r[12] = ld32(0x0603DCD0u);  // 0603DBDE mov.l 0x0603DCD0,r12
    st32(c.r[14] + 16, c.r[1]);  // 0603DBE0 mov.l r1,@(16,r14)
    c.r[1] = c.r[12];  // 0603DBE2 mov r12,r1
    c.r[1] += 78;  // 0603DBE4 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DBE6 mov.b @r1,r1
    c.r[4] = ld32(c.r[14] + 16);  // 0603DBE8 mov.l @(16,r14),r4
    c.r[0] = ld32(0x0603DCD4u);  // 0603DBEA mov.l 0x0603DCD4,r0
    c.r[4] -= c.r[1];  // 0603DBEC sub r1,r4
    c.r[4] <<= 2;  // 0603DBEE shll2 r4
    c.r[4] <<= 2;  // 0603DBF0 shll2 r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DCC4u);  // 0603DBF2 mov.w 0x0603DCC4,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0603DBF8u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DBF8u) return; }  // 0603DBF4 jsr @r0 ; add r1,r4
    c.r[4] = c.r[0];  // 0603DBF8 mov r0,r4
    c.r[5] = c.r[1];  // 0603DBFA mov r1,r5
    c.r[1] = ld32(0x0603DCD8u);  // 0603DBFC mov.l 0x0603DCD8,r1
    c.r[8] = ld32(c.r[1]);  // 0603DBFE mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603DC00 mov.l @(4,r1),r9
    c.r[0] = ld32(0x0603DCDCu);  // 0603DC02 mov.l 0x0603DCDC,r0
    c.r[6] = c.r[8];  // 0603DC04 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603DC0Au; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DC0Au) return; }  // 0603DC06 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603DC0A mov r0,r4
    c.r[10] = ld32(0x0603DCE0u);  // 0603DC0C mov.l 0x0603DCE0,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0603DC12u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DC12u) return; }  // 0603DC0E jsr @r10 ; mov r1,r5
    st32(c.r[14] + 8, c.r[0]);  // 0603DC12 mov.l r0,@(8,r14)
    c.r[1] = ld32(0x0603DCF0u);  // 0603DC14 mov.l 0x0603DCF0,r1
    c.r[12] += 79;  // 0603DC16 add #79,r12
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DC18 mov.b @r1,r11
    c.r[0] = ld32(0x0603DCD4u);  // 0603DC1A mov.l 0x0603DCD4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0603DC1C mov.b @r12,r1
    c.r[4] = c.r[11];  // 0603DC1E mov r11,r4
    c.r[4] -= c.r[1];  // 0603DC20 sub r1,r4
    c.r[4] <<= 2;  // 0603DC22 shll2 r4
    c.r[4] <<= 2;  // 0603DC24 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0603DC2Au; c.r[4] -= 105; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DC2Au) return; }  // 0603DC26 jsr @r0 ; add #-105,r4
    c.r[4] = c.r[0];  // 0603DC2A mov r0,r4
    c.r[5] = c.r[1];  // 0603DC2C mov r1,r5
    c.r[6] = c.r[8];  // 0603DC2E mov r8,r6
    c.r[0] = ld32(0x0603DCDCu);  // 0603DC30 mov.l 0x0603DCDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603DC36u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DC36u) return; }  // 0603DC32 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603DC36 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0603DC3Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DC3Cu) return; }  // 0603DC38 jsr @r10 ; mov r1,r5
    c.r[3] = c.r[0];  // 0603DC3C mov r0,r3
    c.r[1] = ld32(0x0603DCE8u);  // 0603DC3E mov.l 0x0603DCE8,r1
    c.r[1] = ld32(c.r[1]);  // 0603DC40 mov.l @r1,r1
    c.r[11] <<= 2;  // 0603DC42 shll2 r11
    c.r[11] <<= 2;  // 0603DC44 shll2 r11
    c.r[11] <<= 2;  // 0603DC46 shll2 r11
    c.r[0] = ld32(c.r[14] + 16);  // 0603DC48 mov.l @(16,r14),r0
L_0603DC4A:
    c.r[11] += c.r[1];  // 0603DC4A add r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0603DC4C mov.b @(r0,r11),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0603DC4E extu.b r1,r7
    c.r[0] = ld32(c.r[14] + 4);  // 0603DC50 mov.l @(4,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603DC52 mov.b @r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603DCC6u);  // 0603DC54 mov.w 0x0603DCC6,r0
    c.r[1] &= c.r[0];  // 0603DC56 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603DC58 tst r1,r1
    if (c.t) { goto L_0603DC60; }  // 0603DC5A bt 0x0603DC60
    goto L_0603DDBC;  // 0603DC5C bra 0x0603DDBC ; nop
L_0603DC60:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DCC8u);  // 0603DC60 mov.w 0x0603DCC8,r1
    c.t = c.r[7] == c.r[1];  // 0603DC62 cmp/eq r1,r7
    { const bool k = !c.t; c.r[7] <<= 2; if (k) { goto L_0603DC6C; } }  // 0603DC64 bf/s 0x0603DC6C ; shll2 r7
    goto L_0603DDBC;  // 0603DC68 bra 0x0603DDBC ; nop
L_0603DC6C:
    c.r[1] = ld32(0x0603DCF4u);  // 0603DC6C mov.l 0x0603DCF4,r1
    c.r[1] = ld32(c.r[1]);  // 0603DC6E mov.l @r1,r1
    c.r[7] <<= 2;  // 0603DC70 shll2 r7
    c.r[7] += c.r[1];  // 0603DC72 add r1,r7
    c.r[7] += 3;  // 0603DC74 add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603DC76 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0603DC78 mov r1,r0
    c.r[0] >>= 2;  // 0603DC7A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603DC7C shlr r0
    c.r[0] &= 0x3u;  // 0603DC7E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603DC80 tst r0,r0
    if (c.t) { goto L_0603DC88; }  // 0603DC82 bt 0x0603DC88
    goto L_0603DDBC;  // 0603DC84 bra 0x0603DDBC ; nop
L_0603DC88:
    c.r[1] = ld32(0x0603DCE8u);  // 0603DC88 mov.l 0x0603DCE8,r1
    c.r[1] = ld32(c.r[1] + 4);  // 0603DC8A mov.l @(4,r1),r1
    c.r[3] += c.r[1]; goto L_0603DDBC;  // 0603DC8C bra 0x0603DDBC ; add r1,r3
L_0603DC90:
    c.t = c.r[0] == 0x1u;  // 0603DC90 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_0603DC9C; } }  // 0603DC92 bt/s 0x0603DC9C ; cmp/eq #4,r0
    if (!c.t) { goto L_0603DD08; }  // 0603DC96 bf 0x0603DD08
    goto L_0603DCA2;  // 0603DC98 bra 0x0603DCA2 ; nop
L_0603DC9C:
    c.r[1] = ld32(0x0603DCF8u);  // 0603DC9C mov.l 0x0603DCF8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0603DD0C;  // 0603DC9E bra 0x0603DD0C ; mov.b @r1,r1
L_0603DCA2:
    c.r[1] = ld32(0x0603DCFCu);  // 0603DCA2 mov.l 0x0603DCFC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DCA4 mov.b @r1,r2
    c.r[1] = ld32(0x0603DD00u);  // 0603DCA6 mov.l 0x0603DD00,r1
    c.r[3] = ld32(c.r[1]);  // 0603DCA8 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603DCAA extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DCCAu);  // 0603DCAC mov.w 0x0603DCCA,r1
    c.macl = c.r[2] * c.r[1];  // 0603DCAE mul.l r1,r2
    c.r[2] = c.macl;  // 0603DCB0 sts macl,r2
    c.r[1] = ld32(0x0603DD04u);  // 0603DCB2 mov.l 0x0603DD04,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603DCB4 mov.w @r1,r1
    c.r[2] += c.r[3];  // 0603DCB6 add r3,r2
    c.r[1] <<= 2;  // 0603DCB8 shll2 r1
    c.r[1] += c.r[1];  // 0603DCBA add r1,r1
    c.r[2] += c.r[1];  // 0603DCBC add r1,r2
    c.r[2] += 4;  // 0603DCBE add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_0603DD0C;  // 0603DCC0 bra 0x0603DD0C ; mov.b @r2,r1
L_0603DD08:
    c.r[1] = ld32(0x0603DE50u);  // 0603DD08 mov.l 0x0603DE50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DD0A mov.b @r1,r1
L_0603DD0C:
    c.r[7] = c.r[1] & 0xFFu;  // 0603DD0C extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DE48u);  // 0603DD0E mov.w 0x0603DE48,r1
    c.t = c.r[7] == c.r[1];  // 0603DD10 cmp/eq r1,r7
    if (c.t) { goto L_0603DD66; }  // 0603DD12 bt 0x0603DD66
    c.r[6] = ld32(0x0603DE54u);  // 0603DD14 mov.l 0x0603DE54,r6
    c.r[1] = c.r[6];  // 0603DD16 mov r6,r1
    c.r[1] += 22;  // 0603DD18 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603DD1A mov.w @r1,r1
    c.r[1] += c.r[7];  // 0603DD1C add r7,r1
    c.r[1] += 1;  // 0603DD1E add #1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0603DD20 extu.w r1,r5
    c.r[1] = ld32(0x0603DE58u);  // 0603DD22 mov.l 0x0603DE58,r1
    c.r[2] = c.r[5];  // 0603DD24 mov r5,r2
    c.r[2] += c.r[2];  // 0603DD26 add r2,r2
    c.r[2] += c.r[5];  // 0603DD28 add r5,r2
    c.r[2] <<= 2;  // 0603DD2A shll2 r2
    c.r[3] = ld32(c.r[1] + 12);  // 0603DD2C mov.l @(12,r1),r3
    c.r[0] = c.r[2];  // 0603DD2E mov r2,r0
    c.r[1] = c.r[2];  // 0603DD30 mov r2,r1
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 0603DD32 mov.l @(r0,r3),r2
    c.r[1] += c.r[3];  // 0603DD34 add r3,r1
    c.r[3] = ld32(c.r[1] + 4);  // 0603DD36 mov.l @(4,r1),r3
    c.r[0] = ld32(c.r[14] + 4);  // 0603DD38 mov.l @(4,r14),r0
    st32(c.r[14] + 8, c.r[2]);  // 0603DD3A mov.l r2,@(8,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603DD3C mov.b @r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603DE4Au);  // 0603DD3E mov.w 0x0603DE4A,r0
    c.r[1] &= c.r[0];  // 0603DD40 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603DD42 tst r1,r1
    { const bool k = c.t; c.r[7] <<= 2; if (k) { goto L_0603DDBC; } }  // 0603DD44 bt/s 0x0603DDBC ; shll2 r7
    c.r[1] = ld32(0x0603DE5Cu);  // 0603DD48 mov.l 0x0603DE5C,r1
    c.r[1] = ld32(c.r[1]);  // 0603DD4A mov.l @r1,r1
    c.r[7] <<= 2;  // 0603DD4C shll2 r7
    c.r[7] += c.r[1];  // 0603DD4E add r1,r7
    c.r[7] += 3;  // 0603DD50 add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603DD52 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0603DD54 mov r1,r0
    c.r[0] >>= 2;  // 0603DD56 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603DD58 shlr r0
    c.r[0] &= 0x3u;  // 0603DD5A and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603DD5C tst r0,r0
    if (!c.t) { goto L_0603DDBC; }  // 0603DD5E bf 0x0603DDBC
    c.r[1] = ld32(c.r[6] + 4);  // 0603DD60 mov.l @(4,r6),r1
    c.r[3] -= c.r[1]; goto L_0603DDBC;  // 0603DD62 bra 0x0603DDBC ; sub r1,r3
L_0603DD66:
    c.r[8] = ld32(0x0603DE60u);  // 0603DD66 mov.l 0x0603DE60,r8
    c.r[1] = c.r[8];  // 0603DD68 mov r8,r1
    c.r[1] += 116;  // 0603DD6A add #116,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DD6C mov.b @r1,r4
    c.r[0] = ld32(0x0603DE64u);  // 0603DD6E mov.l 0x0603DE64,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0603DD70 extu.b r4,r4
    c.r[4] <<= 2;  // 0603DD72 shll2 r4
    c.r[4] <<= 2;  // 0603DD74 shll2 r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DE4Cu);  // 0603DD76 mov.w 0x0603DE4C,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0603DD7Cu; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DD7Cu) return; }  // 0603DD78 jsr @r0 ; add r1,r4
    c.r[4] = c.r[0];  // 0603DD7C mov r0,r4
    c.r[5] = c.r[1];  // 0603DD7E mov r1,r5
    c.r[1] = ld32(0x0603DE68u);  // 0603DD80 mov.l 0x0603DE68,r1
    c.r[9] = ld32(c.r[1]);  // 0603DD82 mov.l @r1,r9
    c.r[10] = ld32(c.r[1] + 4);  // 0603DD84 mov.l @(4,r1),r10
    c.r[0] = ld32(0x0603DE6Cu);  // 0603DD86 mov.l 0x0603DE6C,r0
    c.r[6] = c.r[9];  // 0603DD88 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603DD8Eu; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DD8Eu) return; }  // 0603DD8A jsr @r0 ; mov r10,r7
    c.r[4] = c.r[0];  // 0603DD8E mov r0,r4
    c.r[11] = ld32(0x0603DE70u);  // 0603DD90 mov.l 0x0603DE70,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603DD96u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DD96u) return; }  // 0603DD92 jsr @r11 ; mov r1,r5
    st32(c.r[14] + 8, c.r[0]);  // 0603DD96 mov.l r0,@(8,r14)
    c.r[8] += 117;  // 0603DD98 add #117,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603DD9A mov.b @r8,r4
    c.r[0] = ld32(0x0603DE64u);  // 0603DD9C mov.l 0x0603DE64,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0603DD9E extu.b r4,r4
    c.r[4] <<= 2;  // 0603DDA0 shll2 r4
    c.r[4] <<= 2;  // 0603DDA2 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0603DDA8u; c.r[4] -= 105; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DDA8u) return; }  // 0603DDA4 jsr @r0 ; add #-105,r4
    c.r[4] = c.r[0];  // 0603DDA8 mov r0,r4
    c.r[5] = c.r[1];  // 0603DDAA mov r1,r5
    c.r[6] = c.r[9];  // 0603DDAC mov r9,r6
    c.r[0] = ld32(0x0603DE6Cu);  // 0603DDAE mov.l 0x0603DE6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603DDB4u; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DDB4u) return; }  // 0603DDB0 jsr @r0 ; mov r10,r7
    c.r[4] = c.r[0];  // 0603DDB4 mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0603DDBAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DDBAu) return; }  // 0603DDB6 jsr @r11 ; mov r1,r5
    c.r[3] = c.r[0];  // 0603DDBA mov r0,r3
L_0603DDBC:
    c.r[6] = ld32(0x0603DE74u);  // 0603DDBC mov.l 0x0603DE74,r6
    c.r[0] = ld32(c.r[14] + 8);  // 0603DDBE mov.l @(8,r14),r0
    c.r[2] = ld32(0x0603DE78u);  // 0603DDC0 mov.l 0x0603DE78,r2
    c.r[2] += c.r[0];  // 0603DDC2 add r0,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603DDC4 cmp/pz r2
    if (c.t) { goto L_0603DDCC; }  // 0603DDC6 bt 0x0603DDCC
    c.r[1] = ld32(0x0603DE7Cu);  // 0603DDC8 mov.l 0x0603DE7C,r1
    c.r[2] += c.r[1];  // 0603DDCA add r1,r2
L_0603DDCC:
    c.r[1] = c.r[2] << 16 | c.r[2] >> 16;  // 0603DDCC swap.w r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603DDCE exts.w r1,r1
    c.r[0] = ld32(c.r[14]);  // 0603DDD0 mov.l @r14,r0
    c.r[7] = ld32(0x0603DE80u);  // 0603DDD2 mov.l 0x0603DE80,r7
    c.r[2] = ld32(0x0603DE84u);  // 0603DDD4 mov.l 0x0603DE84,r2
    c.r[2] += c.r[3];  // 0603DDD6 add r3,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603DDD8 cmp/pz r2
    st32(c.r[0] + 4, c.r[1]);  // 0603DDDA mov.l r1,@(4,r0)
    { const bool k = c.t; st32(c.r[6], c.r[1]); if (k) { goto L_0603DDE4; } }  // 0603DDDC bt/s 0x0603DDE4 ; mov.l r1,@r6
    c.r[1] = ld32(0x0603DE7Cu);  // 0603DDE0 mov.l 0x0603DE7C,r1
    c.r[2] += c.r[1];  // 0603DDE2 add r1,r2
L_0603DDE4:
    c.r[0] = ld32(c.r[14]);  // 0603DDE4 mov.l @r14,r0
    c.r[1] = c.r[2] << 16 | c.r[2] >> 16;  // 0603DDE6 swap.w r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603DDE8 exts.w r1,r1
    st32(c.r[0] + 8, c.r[1]);  // 0603DDEA mov.l r1,@(8,r0)
    st32(c.r[7], c.r[1]);  // 0603DDEC mov.l r1,@r7
    c.r[1] = ld32(c.r[14]);  // 0603DDEE mov.l @r14,r1
    c.r[1] += 1;  // 0603DDF0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DDF2 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0603DDF4 mov #1,r0
    c.r[1] >>= 2;  // 0603DDF6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603DDF8 shlr r1
    c.r[1] &= c.r[0];  // 0603DDFA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603DDFC tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0603DE16; } }  // 0603DDFE bt/s 0x0603DE16 ; mov.l @r14,r0
    c.r[1] = ld32(c.r[0] + 4);  // 0603DE02 mov.l @(4,r0),r1
    c.r[1] <<= 2;  // 0603DE04 shll2 r1
    c.r[1] += c.r[1];  // 0603DE06 add r1,r1
    st32(c.r[0] + 4, c.r[1]);  // 0603DE08 mov.l r1,@(4,r0)
    st32(c.r[6], c.r[1]);  // 0603DE0A mov.l r1,@r6
    c.r[1] = ld32(c.r[0] + 8);  // 0603DE0C mov.l @(8,r0),r1
    c.r[1] <<= 2;  // 0603DE0E shll2 r1
    c.r[1] += c.r[1];  // 0603DE10 add r1,r1
    st32(c.r[0] + 8, c.r[1]);  // 0603DE12 mov.l r1,@(8,r0)
    st32(c.r[7], c.r[1]);  // 0603DE14 mov.l r1,@r7
L_0603DE16:
    c.r[2] = ld32(0x0603DE88u);  // 0603DE16 mov.l 0x0603DE88,r2
    c.r[3] = ld32(0x0603DE60u);  // 0603DE18 mov.l 0x0603DE60,r3
    c.r[1] = c.r[3];  // 0603DE1A mov r3,r1
    c.r[1] += 78;  // 0603DE1C add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DE1E mov.b @r1,r1
    c.r[3] += 79;  // 0603DE20 add #79,r3
    st8(c.r[2], c.r[1]);  // 0603DE22 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603DE24 mov.b @r3,r1
    c.r[2] = ld32(0x0603DE8Cu);  // 0603DE26 mov.l 0x0603DE8C,r2
    st8(c.r[2], c.r[1]);  // 0603DE28 mov.b r1,@r2
    c.r[0] = ld32(c.r[14] + 4);  // 0603DE2A mov.l @(4,r14),r0
    c.r[0] += 1;  // 0603DE2C add #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 0603DE2E mov.l r0,@(4,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 0603DE30 mov.l @(4,r14),r0
    c.r[14] += 20;  // 0603DE32 add #20,r14
    c.r[15] = c.r[14];  // 0603DE34 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603DE36 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DE38 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603DE3A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603DE3C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603DE3E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603DE40 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603DE42 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603DE44 rts ; mov.l @r15+,r8
}

void f_0603DE94(SH2Context& c) {
    ran[985] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603DE94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603DE96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DE98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603DE9A sts.l pr,@-r15
    c.r[15] -= 20;  // 0603DE9C add #-20,r15
    c.r[14] = c.r[15];  // 0603DE9E mov r15,r14
    c.r[9] = c.r[5];  // 0603DEA0 mov r5,r9
    c.r[2] = ld32(0x0603DF10u);  // 0603DEA2 mov.l 0x0603DF10,r2
    c.r[2] = ld32(c.r[2]);  // 0603DEA4 mov.l @r2,r2
    c.r[1] = ld32(0x0603DF14u);  // 0603DEA6 mov.l 0x0603DF14,r1
    c.t = (int32_t)c.r[2] >= 0;  // 0603DEA8 cmp/pz r2
    { const bool k = c.t; st32(c.r[1], c.r[2]); if (k) { goto L_0603DEB0; } }  // 0603DEAA bt/s 0x0603DEB0 ; mov.l r2,@r1
    c.r[2] = 0u - c.r[2];  // 0603DEAE neg r2,r2
L_0603DEB0:
    c.r[5] = ld32(0x0603DF18u);  // 0603DEB0 mov.l 0x0603DF18,r5
    c.r[0] = ld32(0x0603DF1Cu);  // 0603DEB2 mov.l 0x0603DF1C,r0
    c.r[6] = c.r[2];  // 0603DEB4 mov r2,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603DEBAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DEBAu) return; }  // 0603DEB6 jsr @r0 ; mov r14,r4
    c.r[8] = ld32(0x0603DF20u);  // 0603DEBA mov.l 0x0603DF20,r8
    c.r[0] = ld32(0x0603DF24u);  // 0603DEBC mov.l 0x0603DF24,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603DEC2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DEC2u) return; }  // 0603DEBE jsr @r0 ; mov r14,r4
    st8(c.r[8], c.r[0]);  // 0603DEC2 mov.b r0,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603DEC4 mov.b @r9,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0603DEC6 extu.b r1,r2
    c.r[2] += c.r[2];  // 0603DEC8 add r2,r2
    c.r[1] = ld32(0x0603DF28u);  // 0603DECA mov.l 0x0603DF28,r1
    c.r[2] += c.r[1];  // 0603DECC add r1,r2
    c.r[1] = ld32(0x0603DF2Cu);  // 0603DECE mov.l 0x0603DF2C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DED0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603DED2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603DED4 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[0] & 0xFFu; if (k) { goto L_0603DEDC; } }  // 0603DED6 bt/s 0x0603DEDC ; extu.b r0,r0
    c.r[0] += 1;  // 0603DEDA add #1,r0
L_0603DEDC:
    st16(c.r[2], c.r[0]);  // 0603DEDC mov.w r0,@r2
    c.r[2] = ld32(0x0603DF30u);  // 0603DEDE mov.l 0x0603DF30,r2
    c.r[1] = c.r[2];  // 0603DEE0 mov r2,r1
    c.r[1] += 1;  // 0603DEE2 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DEE4 mov.b @r1,r6
    c.r[7] = 0x1u;  // 0603DEE6 mov #1,r7
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 0603DEE8 mov.w @r2+,r5
    c.r[6] = c.r[6] & 0xFFu;  // 0603DEEA extu.b r6,r6
    c.r[5] >>= 8;  // 0603DEEC shlr8 r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603DEEE extu.b r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603DEF0 mov.w @r2,r4
    c.r[1] = ld32(0x0603DF34u);  // 0603DEF2 mov.l 0x0603DF34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603DEF8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DEF8u) return; }  // 0603DEF4 jsr @r1 ; extu.w r4,r4
    c.r[2] = ld32(0x0603DF38u);  // 0603DEF8 mov.l 0x0603DF38,r2
    c.r[1] = 0x1u;  // 0603DEFA mov #1,r1
    st16(c.r[2], c.r[1]);  // 0603DEFC mov.w r1,@r2
    c.r[14] += 20;  // 0603DEFE add #20,r14
    c.r[15] = c.r[14];  // 0603DF00 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603DF02 lds.l @r15+,pr
    c.r[9] += 1;  // 0603DF04 add #1,r9
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DF06 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603DF08 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603DF0A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603DF0C rts ; mov.l @r15+,r8
}

void f_0603DF3C(SH2Context& c) {
    ran[986] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603DF3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603DF3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603DF40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603DF42 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603DF44 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603DF46 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603DF48 sts.l pr,@-r15
    c.r[15] -= 20;  // 0603DF4A add #-20,r15
    c.r[14] = c.r[15];  // 0603DF4C mov r15,r14
    c.r[12] = c.r[4];  // 0603DF4E mov r4,r12
    c.r[8] = c.r[12];  // 0603DF50 mov r12,r8
    c.r[8] += 56;  // 0603DF52 add #56,r8
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603DF54 mov.w @r8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DFE4u);  // 0603DF56 mov.w 0x0603DFE4,r1
    c.r[1] &= c.r[3];  // 0603DF58 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603DF5A tst r1,r1
    { const bool k = !c.t; c.r[9] = c.r[5]; if (k) { goto L_0603DFC2; } }  // 0603DF5C bf/s 0x0603DFC2 ; mov r5,r9
    c.r[11] = ld32(0x0603DFE8u);  // 0603DF60 mov.l 0x0603DFE8,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603DF62 mov.b @r9,r2
    c.r[10] = ld32(0x0603DFECu);  // 0603DF64 mov.l 0x0603DFEC,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603DF66 mov.b @r11,r1
    c.r[0] = c.r[2] & 0xFFu;  // 0603DF68 extu.b r2,r0
    c.r[0] += c.r[0];  // 0603DF6A add r0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0603DF6C mov.w @(r0,r10),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603DF6E extu.b r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0603DF70 cmp/ge r2,r1
    if (c.t) { goto L_0603DF8E; }  // 0603DF72 bt 0x0603DF8E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DFE6u);  // 0603DF74 mov.w 0x0603DFE6,r1
    c.r[3] &= c.r[1];  // 0603DF76 and r1,r3
    c.r[1] = ld32(0x0603DFF0u);  // 0603DF78 mov.l 0x0603DFF0,r1
    c.r[1] = ld32(c.r[1]);  // 0603DF7A mov.l @r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603DF7C cmp/pz r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0603DF86; } }  // 0603DF7E bt/s 0x0603DF86 ; mov r8,r2
    c.r[1] = 0xAu; goto L_0603DF88;  // 0603DF82 bra 0x0603DF88 ; mov #10,r1
L_0603DF86:
    c.r[1] = 0x9u;  // 0603DF86 mov #9,r1
L_0603DF88:
    c.r[1] |= c.r[3];  // 0603DF88 or r3,r1
    st16(c.r[2], c.r[1]); goto L_0603DFC2;  // 0603DF8A bra 0x0603DFC2 ; mov.w r1,@r2
L_0603DF8E:
    c.r[1] = ld32(0x0603DFF0u);  // 0603DF8E mov.l 0x0603DFF0,r1
    c.r[6] = ld32(c.r[1]);  // 0603DF90 mov.l @r1,r6
    c.t = (int32_t)c.r[6] >= 0;  // 0603DF92 cmp/pz r6
    if (c.t) { goto L_0603DF98; }  // 0603DF94 bt 0x0603DF98
    c.r[6] = 0u - c.r[6];  // 0603DF96 neg r6,r6
L_0603DF98:
    c.r[5] = ld32(0x0603DFF4u);  // 0603DF98 mov.l 0x0603DFF4,r5
    c.r[0] = ld32(0x0603DFF8u);  // 0603DF9A mov.l 0x0603DFF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603DFA0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603DFA0u) return; }  // 0603DF9C jsr @r0 ; mov r14,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603DFA0 mov.w @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603DFE6u);  // 0603DFA2 mov.w 0x0603DFE6,r1
    c.r[2] &= c.r[1];  // 0603DFA4 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603DFA6 mov.b @r11,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603DFA8 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603DFAA mov.b @r9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603DFAC extu.b r1,r1
    c.r[1] += c.r[1];  // 0603DFAE add r1,r1
    c.r[0] = c.r[1];  // 0603DFB0 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0603DFB2 mov.w @(r0,r10),r1
    c.r[3] -= c.r[1];  // 0603DFB4 sub r1,r3
    c.r[0] = c.r[14];  // 0603DFB6 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0603DFB8 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603DFBA extu.b r1,r1
    c.r[1] -= 37;  // 0603DFBC add #-37,r1
    c.r[2] |= c.r[1];  // 0603DFBE or r1,r2
    st16(c.r[8], c.r[2]);  // 0603DFC0 mov.w r2,@r8
L_0603DFC2:
    c.r[12] += 60;  // 0603DFC2 add #60,r12
    c.r[1] = c.r[9];  // 0603DFC4 mov r9,r1
    c.r[1] += 1;  // 0603DFC6 add #1,r1
    c.r[14] += 20;  // 0603DFC8 add #20,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603DFCA mov.b @r1,r1
    c.r[15] = c.r[14];  // 0603DFCC mov r14,r15
    st8(c.r[12], c.r[1]);  // 0603DFCE mov.b r1,@r12
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603DFD0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603DFD2 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603DFD4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603DFD6 mov.l @r15+,r11
    c.r[9] += 2;  // 0603DFD8 add #2,r9
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603DFDA mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0603DFDC mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603DFDE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603DFE0 rts ; mov.l @r15+,r8
}

void f_0603E00C(SH2Context& c) {
    ran[987] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603E00C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603E00E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603E010 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603E012 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603E014 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603E016 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603E018 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603E01A mov r15,r14
    c.r[10] = c.r[4];  // 0603E01C mov r4,r10
    c.r[12] = c.r[5];  // 0603E01E mov r5,r12
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603E174u);  // 0603E020 mov.w 0x0603E174,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0603E022 mov.b @r12,r0
    c.r[2] = ld32(0x0603E17Cu);  // 0603E024 mov.l 0x0603E17C,r2
    c.r[1] = ld32(c.r[10]);  // 0603E026 mov.l @r10,r1
    c.r[3] &= c.r[0];  // 0603E028 and r0,r3
    c.r[11] = c.r[3];  // 0603E02A mov r3,r11
    c.r[1] &= c.r[2];  // 0603E02C and r2,r1
    c.r[2] = ld32(0x0603E180u);  // 0603E02E mov.l 0x0603E180,r2
    c.r[2] |= c.r[1];  // 0603E030 or r1,r2
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603E032 tst r3,r3
    { const bool k = !c.t; st32(c.r[10], c.r[2]); if (k) { goto L_0603E03C; } }  // 0603E034 bf/s 0x0603E03C ; mov.l r2,@r10
    goto L_0603E206;  // 0603E038 bra 0x0603E206 ; nop
L_0603E03C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E174u);  // 0603E03C mov.w 0x0603E174,r1
    c.t = c.r[3] == c.r[1];  // 0603E03E cmp/eq r1,r3
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0603E086; } }  // 0603E040 bf/s 0x0603E086 ; mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603E044 mov.b @r0+,r1
    c.r[2] = 0x3Fu;  // 0603E046 mov #63,r2
    c.r[2] &= c.r[1];  // 0603E048 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603E04A mov.b @r0,r1
    c.r[2] <<= 8;  // 0603E04C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603E04E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603E050 or r1,r2
    c.r[1] = ld32(0x0603E184u);  // 0603E052 mov.l 0x0603E184,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E058u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E058u) return; }  // 0603E054 jsr @r1 ; mov r2,r4
    c.r[4] = c.r[0];  // 0603E058 mov r0,r4
    c.r[5] = c.r[1];  // 0603E05A mov r1,r5
    c.r[1] = ld32(0x0603E188u);  // 0603E05C mov.l 0x0603E188,r1
    c.r[6] = ld32(c.r[1]);  // 0603E05E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0603E060 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0603E18Cu);  // 0603E062 mov.l 0x0603E18C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E068u; c.r[10] += 52; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E068u) return; }  // 0603E064 jsr @r1 ; add #52,r10
    c.r[4] = c.r[0];  // 0603E068 mov r0,r4
    c.r[5] = c.r[1];  // 0603E06A mov r1,r5
    c.r[1] = ld32(0x0603E190u);  // 0603E06C mov.l 0x0603E190,r1
    c.r[6] = ld32(c.r[1]);  // 0603E06E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0603E070 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0603E194u);  // 0603E072 mov.l 0x0603E194,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E078u; c.r[12] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E078u) return; }  // 0603E074 jsr @r1 ; add #2,r12
    c.r[4] = c.r[0];  // 0603E078 mov r0,r4
    c.r[5] = c.r[1];  // 0603E07A mov r1,r5
    c.r[0] = ld32(0x0603E198u);  // 0603E07C mov.l 0x0603E198,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603E082u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E082u) return; }  // 0603E07E jsr @r0 ; nop
    st16(c.r[10], c.r[0]); goto L_0603E246;  // 0603E082 bra 0x0603E246 ; mov.w r0,@r10
L_0603E086:
    c.r[8] = ld32(c.r[10] + 4);  // 0603E086 mov.l @(4,r10),r8
    c.r[1] = ld32(0x0603E19Cu);  // 0603E088 mov.l 0x0603E19C,r1
    c.r[9] = ld32(c.r[10] + 8);  // 0603E08A mov.l @(8,r10),r9
    { const uint32_t x = c.r[1]; c.pr = 0x0603E090u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E090u) return; }  // 0603E08C jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0603E1A0u);  // 0603E090 mov.l 0x0603E1A0,r1
    c.r[5] = c.r[10];  // 0603E092 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603E098u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E098u) return; }  // 0603E094 jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E176u);  // 0603E098 mov.w 0x0603E176,r1
    c.t = c.r[11] == c.r[1];  // 0603E09A cmp/eq r1,r11
    { const bool k = !c.t; c.r[0] = 0x3Fu; if (k) { goto L_0603E0AE; } }  // 0603E09C bf/s 0x0603E0AE ; mov #63,r0
    c.r[1] = ld32(0x0603E1A4u);  // 0603E0A0 mov.l 0x0603E1A4,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E0A2 mov.b @r1,r3
    c.r[1] = ld32(0x0603E1A8u);  // 0603E0A4 mov.l 0x0603E1A8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E0A6 mov.b @r1,r5
    c.r[3] <<= 2;  // 0603E0A8 shll2 r3
    c.r[3] <<= 2; goto L_0603E108;  // 0603E0AA bra 0x0603E108 ; shll2 r3
L_0603E0AE:
    c.r[5] = ld32(0x0603E1ACu);  // 0603E0AE mov.l 0x0603E1AC,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0603E0B0 mov.b @r12,r1
    c.r[1] &= c.r[0];  // 0603E0B2 and r0,r1
    c.r[6] = c.r[1];  // 0603E0B4 mov r1,r6
    c.r[6] += c.r[6];  // 0603E0B6 add r6,r6
    c.r[6] += c.r[1];  // 0603E0B8 add r1,r6
    c.r[6] <<= 2;  // 0603E0BA shll2 r6
    c.r[0] = c.r[5];  // 0603E0BC mov r5,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 0603E0BE mov.w @(r0,r6),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E178u);  // 0603E0C0 mov.w 0x0603E178,r1
    c.r[2] += c.r[1];  // 0603E0C2 add r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603E0C4 cmp/pz r2
    if (c.t) { goto L_0603E0CA; }  // 0603E0C6 bt 0x0603E0CA
    c.r[2] += 15;  // 0603E0C8 add #15,r2
L_0603E0CA:
    c.r[3] = c.r[2];  // 0603E0CA mov r2,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603E0CC shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603E0CE shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603E0D0 shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603E0D2 shar r3
    c.r[7] = ld32(0x0603E1B0u);  // 0603E0D4 mov.l 0x0603E1B0,r7
    c.r[1] = c.r[7];  // 0603E0D6 mov r7,r1
    c.r[1] += 78;  // 0603E0D8 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E0DA mov.b @r1,r1
    c.r[6] += c.r[5];  // 0603E0DC add r5,r6
    c.r[3] += c.r[1];  // 0603E0DE add r1,r3
    c.r[1] = ld32(c.r[6] + 4);  // 0603E0E0 mov.l @(4,r6),r1
    c.r[3] <<= 2;  // 0603E0E2 shll2 r3
    c.r[3] <<= 2;  // 0603E0E4 shll2 r3
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0603E0E6 swap.w r1,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603E0E8 exts.w r1,r1
    c.r[2] = c.r[1];  // 0603E0EA mov r1,r2
    c.r[2] += 105;  // 0603E0EC add #105,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603E0EE cmp/pz r2
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_0603E0FA; } }  // 0603E0F0 bt/s 0x0603E0FA ; mov r2,r5
    c.r[2] = c.r[1];  // 0603E0F4 mov r1,r2
    c.r[2] += 120;  // 0603E0F6 add #120,r2
    c.r[5] = c.r[2];  // 0603E0F8 mov r2,r5
L_0603E0FA:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0603E0FA shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0603E0FC shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0603E0FE shar r5
    c.r[7] += 79;  // 0603E100 add #79,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603E102 mov.b @r7,r1
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0603E104 shar r5
    c.r[5] += c.r[1];  // 0603E106 add r1,r5
L_0603E108:
    c.r[5] <<= 2;  // 0603E108 shll2 r5
    c.r[5] <<= 2;  // 0603E10A shll2 r5
    c.r[1] = ld32(c.r[10] + 4);  // 0603E10C mov.l @(4,r10),r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0603E10E swap.w r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603E110 exts.w r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E178u);  // 0603E112 mov.w 0x0603E178,r1
    c.r[2] += c.r[1];  // 0603E114 add r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603E116 cmp/pz r2
    if (c.t) { goto L_0603E11C; }  // 0603E118 bt 0x0603E11C
    c.r[2] += 15;  // 0603E11A add #15,r2
L_0603E11C:
    c.r[6] = c.r[2];  // 0603E11C mov r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0603E11E shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0603E120 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0603E122 shar r6
    c.r[7] = ld32(0x0603E1B0u);  // 0603E124 mov.l 0x0603E1B0,r7
    c.r[1] = c.r[7];  // 0603E126 mov r7,r1
    c.r[1] += 78;  // 0603E128 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E12A mov.b @r1,r1
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0603E12C shar r6
    c.r[6] += c.r[1];  // 0603E12E add r1,r6
    c.r[1] = ld32(c.r[10] + 8);  // 0603E130 mov.l @(8,r10),r1
    c.r[6] <<= 2;  // 0603E132 shll2 r6
    c.r[6] <<= 2;  // 0603E134 shll2 r6
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0603E136 swap.w r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603E138 exts.w r2,r2
    c.r[1] = c.r[2];  // 0603E13A mov r2,r1
    c.r[1] += 105;  // 0603E13C add #105,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603E13E cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_0603E14A; } }  // 0603E140 bt/s 0x0603E14A ; shar r1
    c.r[1] = c.r[2];  // 0603E144 mov r2,r1
    c.r[1] += 120;  // 0603E146 add #120,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E148 shar r1
L_0603E14A:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E14A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E14C shar r1
    c.r[7] += 79;  // 0603E14E add #79,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603E150 mov.b @r7,r2
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E152 shar r1
    c.r[1] += c.r[2];  // 0603E154 add r2,r1
    c.r[1] <<= 2;  // 0603E156 shll2 r1
    c.r[1] <<= 2;  // 0603E158 shll2 r1
    st32(c.r[10] + 4, c.r[8]);  // 0603E15A mov.l r8,@(4,r10)
    st32(c.r[10] + 8, c.r[9]);  // 0603E15C mov.l r9,@(8,r10)
    c.r[8] = c.r[3];  // 0603E15E mov r3,r8
    c.r[8] -= c.r[6];  // 0603E160 sub r6,r8
    c.r[9] = c.r[5];  // 0603E162 mov r5,r9
    c.t = (int32_t)c.r[8] > 0;  // 0603E164 cmp/pl r8
    { const bool k = !c.t; c.r[9] -= c.r[1]; if (k) { goto L_0603E1B4; } }  // 0603E166 bf/s 0x0603E1B4 ; sub r1,r9
    c.t = (int32_t)c.r[9] >= 0;  // 0603E16A cmp/pz r9
    { const bool k = c.t; c.r[6] = 0x5Au; if (k) { goto L_0603E1BA; } }  // 0603E16C bt/s 0x0603E1BA ; mov #90,r6
    c.r[6] = 0x0u; goto L_0603E1C4;  // 0603E170 bra 0x0603E1C4 ; mov #0,r6
L_0603E1B4:
    c.t = (int32_t)c.r[9] >= 0;  // 0603E1B4 cmp/pz r9
    if (c.t) { goto L_0603E1C2; }  // 0603E1B6 bt 0x0603E1C2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603E25Au);  // 0603E1B8 mov.w 0x0603E25A,r6
L_0603E1BA:
    c.r[3] = c.r[8];  // 0603E1BA mov r8,r3
    c.r[8] = c.r[9];  // 0603E1BC mov r9,r8
    c.r[9] = c.r[3]; goto L_0603E1C4;  // 0603E1BE bra 0x0603E1C4 ; mov r3,r9
L_0603E1C2:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603E25Cu);  // 0603E1C2 mov.w 0x0603E25C,r6
L_0603E1C4:
    c.t = (int32_t)c.r[8] >= 0;  // 0603E1C4 cmp/pz r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0603E1CC; } }  // 0603E1C6 bt/s 0x0603E1CC ; mov r8,r2
    c.r[2] = 0u - c.r[8];  // 0603E1CA neg r8,r2
L_0603E1CC:
    c.t = (int32_t)c.r[9] >= 0;  // 0603E1CC cmp/pz r9
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603E1D4; } }  // 0603E1CE bt/s 0x0603E1D4 ; mov r9,r1
    c.r[1] = 0u - c.r[9];  // 0603E1D2 neg r9,r1
L_0603E1D4:
    c.r[2] += c.r[1];  // 0603E1D4 add r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603E1D6 tst r2,r2
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_0603E244; } }  // 0603E1D8 bt/s 0x0603E244 ; cmp/pz r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0603E1E2; } }  // 0603E1DC bt/s 0x0603E1E2 ; mov r8,r2
    c.r[2] = 0u - c.r[8];  // 0603E1E0 neg r8,r2
L_0603E1E2:
    c.r[1] = 0x5Au;  // 0603E1E2 mov #90,r1
    c.macl = c.r[2] * c.r[1];  // 0603E1E4 mul.l r1,r2
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_0603E1EC; } }  // 0603E1E6 bt/s 0x0603E1EC ; mov r8,r5
    c.r[5] = 0u - c.r[5];  // 0603E1EA neg r5,r5
L_0603E1EC:
    c.r[1] = c.r[9];  // 0603E1EC mov r9,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603E1EE cmp/pz r1
    if (c.t) { goto L_0603E1F4; }  // 0603E1F0 bt 0x0603E1F4
    c.r[1] = 0u - c.r[1];  // 0603E1F2 neg r1,r1
L_0603E1F4:
    c.r[5] += c.r[1];  // 0603E1F4 add r1,r5
    c.r[7] = ld32(0x0603E260u);  // 0603E1F6 mov.l 0x0603E260,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603E1FCu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E1FCu) return; }  // 0603E1F8 jsr @r7 ; sts macl,r4
    c.r[0] += c.r[6];  // 0603E1FC add r6,r0
    c.r[6] = c.r[0] & 0xFFFFu;  // 0603E1FE extu.w r0,r6
    c.r[1] = ld32(0x0603E264u);  // 0603E200 mov.l 0x0603E264,r1
    c.r[4] = c.r[6]; goto L_0603E214;  // 0603E202 bra 0x0603E214 ; mov r6,r4
L_0603E206:
    c.r[1] = ld32(0x0603E268u);  // 0603E206 mov.l 0x0603E268,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E208 mov.b @r1,r1
    c.r[2] = 0x5Au;  // 0603E20A mov #90,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603E20C extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0603E20E mul.l r2,r1
    c.r[1] = ld32(0x0603E264u);  // 0603E210 mov.l 0x0603E264,r1
    c.r[4] = c.macl;  // 0603E212 sts macl,r4
L_0603E214:
    { const uint32_t x = c.r[1]; c.pr = 0x0603E218u; c.r[10] += 52; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E218u) return; }  // 0603E214 jsr @r1 ; add #52,r10
    c.r[4] = c.r[0];  // 0603E218 mov r0,r4
    c.r[5] = c.r[1];  // 0603E21A mov r1,r5
    c.r[1] = ld32(0x0603E26Cu);  // 0603E21C mov.l 0x0603E26C,r1
    c.r[6] = ld32(c.r[1]);  // 0603E21E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0603E220 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0603E270u);  // 0603E222 mov.l 0x0603E270,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E228u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E228u) return; }  // 0603E224 jsr @r1 ; nop
    c.r[4] = c.r[0];  // 0603E228 mov r0,r4
    c.r[5] = c.r[1];  // 0603E22A mov r1,r5
    c.r[1] = ld32(0x0603E274u);  // 0603E22C mov.l 0x0603E274,r1
    c.r[6] = ld32(c.r[1]);  // 0603E22E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0603E230 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0603E278u);  // 0603E232 mov.l 0x0603E278,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E238u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E238u) return; }  // 0603E234 jsr @r1 ; nop
    c.r[4] = c.r[0];  // 0603E238 mov r0,r4
    c.r[5] = c.r[1];  // 0603E23A mov r1,r5
    c.r[0] = ld32(0x0603E27Cu);  // 0603E23C mov.l 0x0603E27C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603E242u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E242u) return; }  // 0603E23E jsr @r0 ; nop
    st16(c.r[10], c.r[0]);  // 0603E242 mov.w r0,@r10
L_0603E244:
    c.r[12] += 1;  // 0603E244 add #1,r12
L_0603E246:
    c.r[0] = c.r[12];  // 0603E246 mov r12,r0
    c.r[15] = c.r[14];  // 0603E248 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603E24A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603E24C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603E24E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603E250 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603E252 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603E254 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603E256 rts ; mov.l @r15+,r8
}

void f_0603E288(SH2Context& c) {
    ran[988] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603E288 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603E28A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603E28C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603E28E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603E290 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603E292 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603E294 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603E296 sts.l pr,@-r15
    c.r[15] -= 12;  // 0603E298 add #-12,r15
    c.r[14] = c.r[15];  // 0603E29A mov r15,r14
    st32(c.r[14] + 8, c.r[5]);  // 0603E29C mov.l r5,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 0603E29E mov.l @(8,r14),r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603E2A0 mov.b @r0+,r3
    c.r[3] = c.r[3] & 0xFFu;  // 0603E2A2 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603E2A4 mov.b @r0,r1
    c.r[3] <<= 8;  // 0603E2A6 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603E2A8 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0603E2AA or r1,r3
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603E2AC exts.w r3,r3
    c.r[1] = ld32(c.r[14] + 8);  // 0603E2AE mov.l @(8,r14),r1
    st32(c.r[14], c.r[3]);  // 0603E2B0 mov.l r3,@r14
    c.r[1] += 2;  // 0603E2B2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E2B4 mov.b @r1,r2
    c.r[13] = c.r[4];  // 0603E2B6 mov r4,r13
    c.r[2] = c.r[2] & 0xFFu;  // 0603E2B8 extu.b r2,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0603E2BA mov.l @(8,r14),r1
    c.r[2] <<= 8;  // 0603E2BC shll8 r2
    c.r[1] += 3;  // 0603E2BE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E2C0 mov.b @r1,r1
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603E2C2 tst r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603E2C4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603E2C6 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603E2C8 exts.w r2,r2
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[2]); if (k) { goto L_0603E2F8; } }  // 0603E2CA bf/s 0x0603E2F8 ; mov.l r2,@(4,r14)
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603E2CE tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[13]; if (k) { goto L_0603E2F8; } }  // 0603E2D0 bf/s 0x0603E2F8 ; mov r13,r1
    c.r[1] += 1;  // 0603E2D4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E2D6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603E2D8 mov r1,r0
    c.r[0] >>= 2;  // 0603E2DA shlr2 r0
    c.r[0] >>= 2;  // 0603E2DC shlr2 r0
    c.r[0] &= 0x1u;  // 0603E2DE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E2E0 tst r0,r0
    if (c.t) { goto L_0603E2EA; }  // 0603E2E2 bt 0x0603E2EA
    st32(c.r[13] + 4, c.r[2]);  // 0603E2E4 mov.l r2,@(4,r13)
    st32(c.r[13] + 8, c.r[2]); goto L_0603E41A;  // 0603E2E6 bra 0x0603E41A ; mov.l r2,@(8,r13)
L_0603E2EA:
    c.r[1] = ld32(0x0603E43Cu);  // 0603E2EA mov.l 0x0603E43C,r1
    c.r[1] = ld32(c.r[1]);  // 0603E2EC mov.l @r1,r1
    st32(c.r[13] + 4, c.r[1]);  // 0603E2EE mov.l r1,@(4,r13)
    c.r[1] = ld32(0x0603E440u);  // 0603E2F0 mov.l 0x0603E440,r1
    c.r[1] = ld32(c.r[1]);  // 0603E2F2 mov.l @r1,r1
    st32(c.r[13] + 8, c.r[1]); goto L_0603E41A;  // 0603E2F4 bra 0x0603E41A ; mov.l r1,@(8,r13)
L_0603E2F8:
    c.r[5] = c.r[14];  // 0603E2F8 mov r14,r5
    c.r[5] += 4;  // 0603E2FA add #4,r5
    c.r[1] = ld32(0x0603E444u);  // 0603E2FC mov.l 0x0603E444,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E302u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E302u) return; }  // 0603E2FE jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x0603E448u);  // 0603E302 mov.l 0x0603E448,r1
    c.r[5] = c.r[13];  // 0603E304 mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603E30Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E30Au) return; }  // 0603E306 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0603E44Cu);  // 0603E30A mov.l 0x0603E44C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E30C mov.b @r1,r2
    c.r[3] = ld32(0x0603E450u);  // 0603E30E mov.l 0x0603E450,r3
    c.r[1] = c.r[3];  // 0603E310 mov r3,r1
    c.r[1] += 78;  // 0603E312 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E314 mov.b @r1,r1
    c.r[7] = ld32(c.r[14]);  // 0603E316 mov.l @r14,r7
    c.r[2] -= c.r[1];  // 0603E318 sub r1,r2
    c.r[2] <<= 2;  // 0603E31A shll2 r2
    c.r[2] <<= 2;  // 0603E31C shll2 r2
    c.r[7] += c.r[2];  // 0603E31E add r2,r7
    st32(c.r[14], c.r[7]);  // 0603E320 mov.l r7,@r14
    c.r[2] = c.r[3];  // 0603E322 mov r3,r2
    c.r[2] += 118;  // 0603E324 add #118,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E326 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0603E328 mov r1,r0
    c.r[0] >>= 2;  // 0603E32A shlr2 r0
    c.r[0] >>= 2;  // 0603E32C shlr2 r0
    c.r[0] >>= 2;  // 0603E32E shlr2 r0
    c.r[0] &= 0x1u;  // 0603E330 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E332 tst r0,r0
    if (c.t) { goto L_0603E36E; }  // 0603E334 bt 0x0603E36E
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603E336 mov.w @r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E438u);  // 0603E338 mov.w 0x0603E438,r1
    c.r[1] &= c.r[2];  // 0603E33A and r2,r1
    c.r[2] = c.r[3];  // 0603E33C mov r3,r2
    c.r[2] += 126;  // 0603E33E add #126,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E340 mov.b @r2,r2
    c.macl = c.r[1] * c.r[2];  // 0603E342 mul.l r2,r1
    c.r[1] = c.macl;  // 0603E344 sts macl,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603E346 cmp/pz r1
    { const bool k = c.t; c.r[2] = c.macl; if (k) { goto L_0603E34E; } }  // 0603E348 bt/s 0x0603E34E ; sts macl,r2
    c.r[1] += 15;  // 0603E34C add #15,r1
L_0603E34E:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E34E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E350 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E352 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E354 shar r1
    c.r[1] <<= 2;  // 0603E356 shll2 r1
    c.r[1] <<= 2;  // 0603E358 shll2 r1
    c.r[2] -= c.r[1];  // 0603E35A sub r1,r2
    c.r[3] += 120;  // 0603E35C add #120,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603E35E mov.w @r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0603E360 cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0603E36A; } }  // 0603E362 bf/s 0x0603E36A ; mov r7,r1
    c.r[1] -= c.r[2]; goto L_0603E36C;  // 0603E366 bra 0x0603E36C ; sub r2,r1
L_0603E36A:
    c.r[1] += c.r[2];  // 0603E36A add r2,r1
L_0603E36C:
    st32(c.r[14], c.r[1]);  // 0603E36C mov.l r1,@r14
L_0603E36E:
    c.r[1] = ld32(0x0603E454u);  // 0603E36E mov.l 0x0603E454,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E370 mov.b @r1,r2
    c.r[3] = ld32(0x0603E450u);  // 0603E372 mov.l 0x0603E450,r3
    c.r[1] = c.r[3];  // 0603E374 mov r3,r1
    c.r[1] += 79;  // 0603E376 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E378 mov.b @r1,r1
    c.r[7] = ld32(c.r[14] + 4);  // 0603E37A mov.l @(4,r14),r7
    c.r[2] -= c.r[1];  // 0603E37C sub r1,r2
    c.r[2] <<= 2;  // 0603E37E shll2 r2
    c.r[2] <<= 2;  // 0603E380 shll2 r2
    c.r[7] += c.r[2];  // 0603E382 add r2,r7
    st32(c.r[14] + 4, c.r[7]);  // 0603E384 mov.l r7,@(4,r14)
    c.r[2] = c.r[3];  // 0603E386 mov r3,r2
    c.r[2] += 122;  // 0603E388 add #122,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E38A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0603E38C mov r1,r0
    c.r[0] >>= 2;  // 0603E38E shlr2 r0
    c.r[0] >>= 2;  // 0603E390 shlr2 r0
    c.r[0] >>= 2;  // 0603E392 shlr2 r0
    c.r[0] &= 0x1u;  // 0603E394 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E396 tst r0,r0
    if (c.t) { goto L_0603E3D2; }  // 0603E398 bt 0x0603E3D2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603E39A mov.w @r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E438u);  // 0603E39C mov.w 0x0603E438,r1
    c.r[1] &= c.r[2];  // 0603E39E and r2,r1
    c.r[2] = c.r[3];  // 0603E3A0 mov r3,r2
    c.r[2] += 127;  // 0603E3A2 add #127,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E3A4 mov.b @r2,r2
    c.macl = c.r[1] * c.r[2];  // 0603E3A6 mul.l r2,r1
    c.r[1] = c.macl;  // 0603E3A8 sts macl,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603E3AA cmp/pz r1
    { const bool k = c.t; c.r[2] = c.macl; if (k) { goto L_0603E3B2; } }  // 0603E3AC bt/s 0x0603E3B2 ; sts macl,r2
    c.r[1] += 15;  // 0603E3B0 add #15,r1
L_0603E3B2:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E3B2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E3B4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E3B6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603E3B8 shar r1
    c.r[1] <<= 2;  // 0603E3BA shll2 r1
    c.r[1] <<= 2;  // 0603E3BC shll2 r1
    c.r[2] -= c.r[1];  // 0603E3BE sub r1,r2
    c.r[3] += 124;  // 0603E3C0 add #124,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603E3C2 mov.w @r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0603E3C4 cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0603E3CE; } }  // 0603E3C6 bf/s 0x0603E3CE ; mov r7,r1
    c.r[1] -= c.r[2]; goto L_0603E3D0;  // 0603E3CA bra 0x0603E3D0 ; sub r2,r1
L_0603E3CE:
    c.r[1] += c.r[2];  // 0603E3CE add r2,r1
L_0603E3D0:
    st32(c.r[14] + 4, c.r[1]);  // 0603E3D0 mov.l r1,@(4,r14)
L_0603E3D2:
    c.r[12] = ld32(0x0603E458u);  // 0603E3D2 mov.l 0x0603E458,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0603E3D8u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E3D8u) return; }  // 0603E3D4 jsr @r12 ; mov.l @r14,r4
    c.r[4] = c.r[0];  // 0603E3D8 mov r0,r4
    c.r[5] = c.r[1];  // 0603E3DA mov r1,r5
    c.r[1] = ld32(0x0603E45Cu);  // 0603E3DC mov.l 0x0603E45C,r1
    c.r[8] = ld32(c.r[1]);  // 0603E3DE mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603E3E0 mov.l @(4,r1),r9
    c.r[11] = ld32(0x0603E460u);  // 0603E3E2 mov.l 0x0603E460,r11
    c.r[6] = c.r[8];  // 0603E3E4 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0603E3EAu; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E3EAu) return; }  // 0603E3E6 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603E3EA mov r0,r4
    c.r[10] = ld32(0x0603E464u);  // 0603E3EC mov.l 0x0603E464,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0603E3F2u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E3F2u) return; }  // 0603E3EE jsr @r10 ; mov r1,r5
    c.r[1] = ld32(c.r[13] + 4);  // 0603E3F2 mov.l @(4,r13),r1
    c.r[4] = ld32(c.r[14] + 4);  // 0603E3F4 mov.l @(4,r14),r4
    c.r[1] += c.r[0];  // 0603E3F6 add r0,r1
    { const uint32_t x = c.r[12]; c.pr = 0x0603E3FCu; st32(c.r[13] + 4, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E3FCu) return; }  // 0603E3F8 jsr @r12 ; mov.l r1,@(4,r13)
    c.r[4] = c.r[0];  // 0603E3FC mov r0,r4
    c.r[5] = c.r[1];  // 0603E3FE mov r1,r5
    c.r[6] = c.r[8];  // 0603E400 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0603E406u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E406u) return; }  // 0603E402 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603E406 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0603E40Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E40Cu) return; }  // 0603E408 jsr @r10 ; mov r1,r5
    c.r[5] = c.r[13];  // 0603E40C mov r13,r5
    c.r[1] = ld32(c.r[13] + 8);  // 0603E40E mov.l @(8,r13),r1
    c.r[1] += c.r[0];  // 0603E410 add r0,r1
    st32(c.r[13] + 8, c.r[1]);  // 0603E412 mov.l r1,@(8,r13)
    c.r[1] = ld32(0x0603E448u);  // 0603E414 mov.l 0x0603E448,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E41Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E41Au) return; }  // 0603E416 jsr @r1 ; mov #1,r4
L_0603E41A:
    c.r[8] = ld32(c.r[14] + 8);  // 0603E41A mov.l @(8,r14),r8
    c.r[8] += 4;  // 0603E41C add #4,r8
    st32(c.r[14] + 8, c.r[8]);  // 0603E41E mov.l r8,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 0603E420 mov.l @(8,r14),r0
    c.r[14] += 12;  // 0603E422 add #12,r14
    c.r[15] = c.r[14];  // 0603E424 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603E426 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603E428 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603E42A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603E42C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603E42E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603E430 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603E432 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603E434 rts ; mov.l @r15+,r8
}

void f_0603E468(SH2Context& c) {
    ran[989] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603E468 mov.l r14,@-r15
    c.r[1] = ld32(0x0603E4B4u);  // 0603E46A mov.l 0x0603E4B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E46C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603E46E extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 0603E470 cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603E498; } }  // 0603E472 bt/s 0x0603E498 ; mov r15,r14
    c.r[1] = 0x2u;  // 0603E476 mov #2,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0603E478 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0603E488; } }  // 0603E47A bt/s 0x0603E488 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 0603E47E cmp/eq #1,r0
    if (c.t) { goto L_0603E490; }  // 0603E480 bt 0x0603E490
    c.r[2] = ld32(c.r[4]);  // 0603E482 mov.l @r4,r2
    c.r[1] = ld32(c.r[5]); goto L_0603E4A8;  // 0603E484 bra 0x0603E4A8 ; mov.l @r5,r1
L_0603E488:
    if (c.t) { goto L_0603E4A2; }  // 0603E488 bt 0x0603E4A2
    c.r[2] = ld32(c.r[4]);  // 0603E48A mov.l @r4,r2
    c.r[1] = ld32(c.r[5]); goto L_0603E4A8;  // 0603E48C bra 0x0603E4A8 ; mov.l @r5,r1
L_0603E490:
    c.r[1] = ld32(c.r[5]);  // 0603E490 mov.l @r5,r1
    c.r[2] = 0u - c.r[1];  // 0603E492 neg r1,r2
    c.r[1] = ld32(c.r[4]); goto L_0603E4A8;  // 0603E494 bra 0x0603E4A8 ; mov.l @r4,r1
L_0603E498:
    c.r[1] = ld32(c.r[4]);  // 0603E498 mov.l @r4,r1
    c.r[2] = 0u - c.r[1];  // 0603E49A neg r1,r2
    c.r[1] = ld32(c.r[5]);  // 0603E49C mov.l @r5,r1
    c.r[1] = 0u - c.r[1]; goto L_0603E4A8;  // 0603E49E bra 0x0603E4A8 ; neg r1,r1
L_0603E4A2:
    c.r[1] = ld32(c.r[4]);  // 0603E4A2 mov.l @r4,r1
    c.r[2] = ld32(c.r[5]);  // 0603E4A4 mov.l @r5,r2
    c.r[1] = 0u - c.r[1];  // 0603E4A6 neg r1,r1
L_0603E4A8:
    st32(c.r[4], c.r[2]);  // 0603E4A8 mov.l r2,@r4
    st32(c.r[5], c.r[1]);  // 0603E4AA mov.l r1,@r5
    c.r[15] = c.r[14];  // 0603E4AC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603E4AE rts ; mov.l @r15+,r14
}

void f_0603E4C0(SH2Context& c) {
    ran[990] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603E4C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603E4C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603E4C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603E4C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603E4C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603E4CA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603E4CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603E4CE sts.l pr,@-r15
    c.r[15] -= 8;  // 0603E4D0 add #-8,r15
    c.r[14] = c.r[15];  // 0603E4D2 mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603E4D4 mov.l r5,@r14
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603E4D6 mov.b @r5,r2
    c.r[12] = 0x1Fu;  // 0603E4D8 mov #31,r12
    c.r[1] = 0x5u;  // 0603E4DA mov #5,r1
    c.r[12] &= c.r[2];  // 0603E4DC and r2,r12
    c.t = c.r[12] > c.r[1];  // 0603E4DE cmp/hi r1,r12
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0603E4E8; } }  // 0603E4E0 bf/s 0x0603E4E8 ; mov.l @r14,r0
    goto L_0603E7B4;  // 0603E4E4 bra 0x0603E7B4 ; nop
L_0603E4E8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E622u);  // 0603E4E8 mov.w 0x0603E622,r1
    c.r[1] &= c.r[2];  // 0603E4EA and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603E4EC tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0603E4F6; } }  // 0603E4EE bf/s 0x0603E4F6 ; mov r2,r0
    goto L_0603E644;  // 0603E4F2 bra 0x0603E644 ; nop
L_0603E4F6:
    c.r[2] = ld32(0x0603E628u);  // 0603E4F6 mov.l 0x0603E628,r2
    c.r[0] = c.r[12];  // 0603E4F8 mov r12,r0
    c.r[0] += c.r[0];  // 0603E4FA add r0,r0
    c.r[0] += c.r[12];  // 0603E4FC add r12,r0
    c.r[0] <<= 2;  // 0603E4FE shll2 r0
    c.r[1] = 0x0u;  // 0603E500 mov #0,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0603E502 mov.l r1,@(r0,r2)
    c.r[0] += c.r[2];  // 0603E504 add r2,r0
    st32(c.r[0] + 4, c.r[1]);  // 0603E506 mov.l r1,@(4,r0)
    c.r[1] = ld32(0x0603E62Cu);  // 0603E508 mov.l 0x0603E62C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E50A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603E50C extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E624u);  // 0603E50E mov.w 0x0603E624,r1
    c.t = c.r[3] == c.r[1];  // 0603E510 cmp/eq r1,r3
    if (!c.t) { goto L_0603E534; }  // 0603E512 bf 0x0603E534
    c.r[3] = ld32(0x0603E630u);  // 0603E514 mov.l 0x0603E630,r3
    c.r[1] = c.r[3];  // 0603E516 mov r3,r1
    c.r[1] += 116;  // 0603E518 add #116,r1
    c.r[2] = c.r[3];  // 0603E51A mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E51C mov.b @r1,r1
    c.r[2] += 78;  // 0603E51E add #78,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E520 mov.b @r2,r2
    c.r[1] += c.r[2];  // 0603E522 add r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0603E524 extu.b r1,r6
    c.r[1] = c.r[3];  // 0603E526 mov r3,r1
    c.r[1] += 117;  // 0603E528 add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E52A mov.b @r1,r1
    c.r[3] += 79;  // 0603E52C add #79,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603E52E mov.b @r3,r2
    c.r[1] += c.r[2]; goto L_0603E54C;  // 0603E530 bra 0x0603E54C ; add r2,r1
L_0603E534:
    c.r[1] = ld32(0x0603E634u);  // 0603E534 mov.l 0x0603E634,r1
    c.r[2] = ld32(c.r[1]);  // 0603E536 mov.l @r1,r2
    c.r[1] = c.r[3];  // 0603E538 mov r3,r1
    c.r[1] <<= 2;  // 0603E53A shll2 r1
    c.r[1] <<= 2;  // 0603E53C shll2 r1
    c.r[3] = c.r[1];  // 0603E53E mov r1,r3
    c.r[3] += c.r[2];  // 0603E540 add r2,r3
    c.r[0] = c.r[1];  // 0603E542 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603E544 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0603E546 add #1,r3
    c.r[6] = c.r[1] & 0xFFu;  // 0603E548 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603E54A mov.b @r3,r1
L_0603E54C:
    c.r[5] = ld32(0x0603E638u);  // 0603E54C mov.l 0x0603E638,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603E54E mov.b @r5,r0
    c.r[0] &= 0x1u;  // 0603E550 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E552 tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { goto L_0603E5AE; } }  // 0603E554 bt/s 0x0603E5AE ; extu.b r1,r7
    c.r[7] = ld32(0x0603E628u);  // 0603E558 mov.l 0x0603E628,r7
    c.r[3] = c.r[12];  // 0603E55A mov r12,r3
    c.r[3] += c.r[3];  // 0603E55C add r3,r3
    c.r[3] += c.r[12];  // 0603E55E add r12,r3
    c.r[3] <<= 2;  // 0603E560 shll2 r3
    c.r[3] += c.r[7];  // 0603E562 add r7,r3
    c.r[1] = ld32(0x0603E63Cu);  // 0603E564 mov.l 0x0603E63C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E566 mov.b @r1,r2
    c.r[2] -= c.r[6];  // 0603E568 sub r6,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603E56A cmp/pz r2
    { const bool k = c.t; c.r[3] += 8; if (k) { goto L_0603E572; } }  // 0603E56C bt/s 0x0603E572 ; add #8,r3
    c.r[2] = 0u - c.r[2];  // 0603E570 neg r2,r2
L_0603E572:
    c.r[1] = ld32(c.r[14]);  // 0603E572 mov.l @r14,r1
    c.r[2] += c.r[2];  // 0603E574 add r2,r2
    c.r[1] += 1;  // 0603E576 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E578 mov.b @r1,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 0603E57A tst r12,r12
    c.r[2] += c.r[1];  // 0603E57C add r1,r2
    { const bool k = c.t; st8(c.r[3], c.r[2]); if (k) { goto L_0603E586; } }  // 0603E57E bt/s 0x0603E586 ; mov.b r2,@r3
    goto L_0603E7B2;  // 0603E582 bra 0x0603E7B2 ; nop
L_0603E586:
    c.r[2] = ld32(0x0603E630u);  // 0603E586 mov.l 0x0603E630,r2
    c.r[1] = c.r[2];  // 0603E588 mov r2,r1
    c.r[1] += 118;  // 0603E58A add #118,r1
    c.r[3] = c.r[2];  // 0603E58C mov r2,r3
    c.r[3] += 126;  // 0603E58E add #126,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E590 mov.b @r1,r0
    c.r[7] += 8;  // 0603E592 add #8,r7
    c.r[0] |= 0x40u;  // 0603E594 or #64,r0
    st8(c.r[1], c.r[0]);  // 0603E596 mov.b r0,@r1
    c.r[1] = 0x8u;  // 0603E598 mov #8,r1
    st8(c.r[3], c.r[1]);  // 0603E59A mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603E59C mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603E59E extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603E5A0 mov.b @r5,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603E5A2 extu.b r1,r0
    c.t = c.r[0] == 0x3u;  // 0603E5A4 cmp/eq #3,r0
    { const bool k = c.t; c.r[2] += 120; if (k) { goto L_0603E618; } }  // 0603E5A6 bt/s 0x0603E618 ; add #120,r2
    c.r[1] = c.r[3]; goto L_0603E61E;  // 0603E5AA bra 0x0603E61E ; mov r3,r1
L_0603E5AE:
    c.r[6] = ld32(0x0603E628u);  // 0603E5AE mov.l 0x0603E628,r6
    c.r[3] = c.r[12];  // 0603E5B0 mov r12,r3
    c.r[3] += c.r[3];  // 0603E5B2 add r3,r3
    c.r[3] += c.r[12];  // 0603E5B4 add r12,r3
    c.r[3] <<= 2;  // 0603E5B6 shll2 r3
    c.r[3] += c.r[6];  // 0603E5B8 add r6,r3
    c.r[1] = ld32(0x0603E640u);  // 0603E5BA mov.l 0x0603E640,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E5BC mov.b @r1,r2
    c.r[2] -= c.r[7];  // 0603E5BE sub r7,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603E5C0 cmp/pz r2
    { const bool k = c.t; c.r[3] += 8; if (k) { goto L_0603E5C8; } }  // 0603E5C2 bt/s 0x0603E5C8 ; add #8,r3
    c.r[2] = 0u - c.r[2];  // 0603E5C6 neg r2,r2
L_0603E5C8:
    c.r[1] = ld32(c.r[14]);  // 0603E5C8 mov.l @r14,r1
    c.r[1] += 1;  // 0603E5CA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E5CC mov.b @r1,r1
    c.r[2] += c.r[2];  // 0603E5CE add r2,r2
    c.r[2] += c.r[1];  // 0603E5D0 add r1,r2
    st8(c.r[3], c.r[2]);  // 0603E5D2 mov.b r2,@r3
    c.r[3] = ld32(0x0603E630u);  // 0603E5D4 mov.l 0x0603E630,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603E5D6 mov.b @r3,r1
    c.r[0] = c.r[1];  // 0603E5D8 mov r1,r0
    c.r[0] >>= 2;  // 0603E5DA shlr2 r0
    c.r[0] >>= 2;  // 0603E5DC shlr2 r0
    c.r[0] >>= 2;  // 0603E5DE shlr2 r0
    c.r[0] &= 0x1u;  // 0603E5E0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E5E2 tst r0,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0603E5EC; } }  // 0603E5E4 bf/s 0x0603E5EC ; mov.l @r14,r0
    goto L_0603E7B4;  // 0603E5E8 bra 0x0603E7B4 ; nop
L_0603E5EC:
    c.t = (c.r[12] & c.r[12]) == 0;  // 0603E5EC tst r12,r12
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0603E5F6; } }  // 0603E5EE bt/s 0x0603E5F6 ; mov r3,r1
    goto L_0603E7B4;  // 0603E5F2 bra 0x0603E7B4 ; nop
L_0603E5F6:
    c.r[1] += 122;  // 0603E5F6 add #122,r1
    c.r[2] = c.r[3];  // 0603E5F8 mov r3,r2
    c.r[2] += 127;  // 0603E5FA add #127,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E5FC mov.b @r1,r0
    c.r[6] += 8;  // 0603E5FE add #8,r6
    c.r[0] |= 0x40u;  // 0603E600 or #64,r0
    st8(c.r[1], c.r[0]);  // 0603E602 mov.b r0,@r1
    c.r[1] = 0x8u;  // 0603E604 mov #8,r1
    st8(c.r[2], c.r[1]);  // 0603E606 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0603E608 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0603E60A mov.b @r6,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603E60C extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603E60E mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603E610 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603E612 tst r1,r1
    { const bool k = !c.t; c.r[2] += 124; if (k) { goto L_0603E61C; } }  // 0603E614 bf/s 0x0603E61C ; add #124,r2
L_0603E618:
    c.r[1] = 0u - c.r[3]; goto L_0603E61E;  // 0603E618 bra 0x0603E61E ; neg r3,r1
L_0603E61C:
    c.r[1] = c.r[3];  // 0603E61C mov r3,r1
L_0603E61E:
    st16(c.r[2], c.r[1]); goto L_0603E7B2;  // 0603E61E bra 0x0603E7B2 ; mov.w r1,@r2
L_0603E644:
    c.r[0] &= 0x40u;  // 0603E644 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E646 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_0603E67C; } }  // 0603E648 bt/s 0x0603E67C ; mov r12,r2
    c.r[1] = ld32(0x0603E7D4u);  // 0603E64C mov.l 0x0603E7D4,r1
    c.r[1] = ld32(c.r[1]);  // 0603E64E mov.l @r1,r1
    c.r[2] += c.r[2];  // 0603E650 add r2,r2
    c.r[0] = c.r[1];  // 0603E652 mov r1,r0
    c.r[1] += c.r[2];  // 0603E654 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603E656 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0603E658 add #1,r1
    c.r[0] = 0x7Fu;  // 0603E65A mov #127,r0
    c.r[3] &= c.r[0];  // 0603E65C and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E65E mov.b @r1,r2
    c.r[3] <<= 8;  // 0603E660 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603E662 extu.b r2,r2
    c.r[2] |= c.r[3];  // 0603E664 or r3,r2
    c.r[1] = ld32(0x0603E7D8u);  // 0603E666 mov.l 0x0603E7D8,r1
    c.r[2] <<= 2;  // 0603E668 shll2 r2
    c.r[2] <<= 2;  // 0603E66A shll2 r2
    c.r[3] = c.r[2];  // 0603E66C mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0603E66E mov.l @r1,r1
    c.r[0] = c.r[2];  // 0603E670 mov r2,r0
    c.r[3] += c.r[1];  // 0603E672 add r1,r3
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603E674 mov.b @(r0,r1),r4
    c.r[3] += 1;  // 0603E676 add #1,r3
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_0603E684;  // 0603E678 bra 0x0603E684 ; mov.b @r3,r11
L_0603E67C:
    c.r[1] = ld32(0x0603E7DCu);  // 0603E67C mov.l 0x0603E7DC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E67E mov.b @r1,r4
    c.r[1] = ld32(0x0603E7E0u);  // 0603E680 mov.l 0x0603E7E0,r1
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E682 mov.b @r1,r11
L_0603E684:
    c.r[7] = ld32(0x0603E7E4u);  // 0603E684 mov.l 0x0603E7E4,r7
    c.r[1] = c.r[11];  // 0603E686 mov r11,r1
    c.r[2] = ld32(c.r[7]);  // 0603E688 mov.l @r7,r2
    c.r[1] <<= 2;  // 0603E68A shll2 r1
    c.r[1] <<= 2;  // 0603E68C shll2 r1
    c.r[1] <<= 2;  // 0603E68E shll2 r1
    c.r[1] += c.r[2];  // 0603E690 add r2,r1
    c.r[0] = c.r[1];  // 0603E692 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0603E694 mov.b @(r0,r4),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0603E696 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E7D0u);  // 0603E698 mov.w 0x0603E7D0,r1
    c.t = c.r[2] == c.r[1];  // 0603E69A cmp/eq r1,r2
    { const bool k = c.t; c.r[3] = 0x40u; if (k) { goto L_0603E6F2; } }  // 0603E69C bt/s 0x0603E6F2 ; mov #64,r3
    c.t = (int32_t)c.r[4] >= 0;  // 0603E6A0 cmp/pz r4
    { const bool k = !c.t; c.r[1] = c.r[11] & 0xFFu; if (k) { goto L_0603E6F2; } }  // 0603E6A2 bf/s 0x0603E6F2 ; extu.b r11,r1
    c.t = c.r[1] > c.r[3];  // 0603E6A6 cmp/hi r3,r1
    { const bool k = c.t; c.r[10] = c.r[12]; if (k) { goto L_0603E6F4; } }  // 0603E6A8 bt/s 0x0603E6F4 ; mov r12,r10
    c.t = (int32_t)c.r[11] > (int32_t)c.r[3];  // 0603E6AC cmp/gt r3,r11
    { const bool k = c.t; c.r[10] += c.r[10]; if (k) { goto L_0603E6F6; } }  // 0603E6AE bt/s 0x0603E6F6 ; add r10,r10
    c.r[7] += 22;  // 0603E6B2 add #22,r7
    c.r[5] = c.r[12];  // 0603E6B4 mov r12,r5
    c.r[5] += c.r[5];  // 0603E6B6 add r5,r5
    c.r[5] += c.r[12];  // 0603E6B8 add r12,r5
    c.r[5] <<= 2;  // 0603E6BA shll2 r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603E6BC mov.w @r7,r1
    c.r[3] = ld32(0x0603E7E8u);  // 0603E6BE mov.l 0x0603E7E8,r3
    c.r[2] += c.r[1];  // 0603E6C0 add r1,r2
    c.r[2] += 1;  // 0603E6C2 add #1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0603E6C4 extu.w r2,r2
    c.r[7] = c.r[2];  // 0603E6C6 mov r2,r7
    c.r[7] += c.r[7];  // 0603E6C8 add r7,r7
    c.r[7] += c.r[2];  // 0603E6CA add r2,r7
    c.r[7] <<= 2;  // 0603E6CC shll2 r7
    c.r[1] = ld32(c.r[3] + 12);  // 0603E6CE mov.l @(12,r3),r1
    c.r[0] = c.r[7];  // 0603E6D0 mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0603E6D2 mov.l @(r0,r1),r1
    c.r[6] = ld32(0x0603E7ECu);  // 0603E6D4 mov.l 0x0603E7EC,r6
    c.r[0] = c.r[6];  // 0603E6D6 mov r6,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 0603E6D8 mov.l r1,@(r0,r5)
    c.r[1] = ld32(c.r[3] + 12);  // 0603E6DA mov.l @(12,r3),r1
    c.r[2] = c.r[5];  // 0603E6DC mov r5,r2
    c.r[7] += c.r[1];  // 0603E6DE add r1,r7
    c.r[1] = ld32(c.r[7] + 4);  // 0603E6E0 mov.l @(4,r7),r1
    c.r[2] += c.r[6];  // 0603E6E2 add r6,r2
    st32(c.r[2] + 4, c.r[1]);  // 0603E6E4 mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[14]);  // 0603E6E6 mov.l @r14,r1
    c.r[1] += 1;  // 0603E6E8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E6EA mov.b @r1,r1
    c.r[2] += 8;  // 0603E6EC add #8,r2
    st8(c.r[2], c.r[1]); goto L_0603E7B2;  // 0603E6EE bra 0x0603E7B2 ; mov.b r1,@r2
L_0603E6F2:
    c.r[10] = c.r[12];  // 0603E6F2 mov r12,r10
L_0603E6F4:
    c.r[10] += c.r[10];  // 0603E6F4 add r10,r10
L_0603E6F6:
    c.r[10] += c.r[12];  // 0603E6F6 add r12,r10
    c.r[10] <<= 2;  // 0603E6F8 shll2 r10
    c.r[13] = ld32(0x0603E7F0u);  // 0603E6FA mov.l 0x0603E7F0,r13
    c.r[1] = c.r[13];  // 0603E6FC mov r13,r1
    c.r[1] += 78;  // 0603E6FE add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E700 mov.b @r1,r1
    c.r[0] = ld32(0x0603E7F4u);  // 0603E702 mov.l 0x0603E7F4,r0
    c.r[4] -= c.r[1];  // 0603E704 sub r1,r4
    c.r[4] <<= 2;  // 0603E706 shll2 r4
    c.r[4] <<= 2;  // 0603E708 shll2 r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E7D2u);  // 0603E70A mov.w 0x0603E7D2,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0603E710u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E710u) return; }  // 0603E70C jsr @r0 ; add r1,r4
    c.r[4] = c.r[0];  // 0603E710 mov r0,r4
    c.r[5] = c.r[1];  // 0603E712 mov r1,r5
    c.r[1] = ld32(0x0603E7F8u);  // 0603E714 mov.l 0x0603E7F8,r1
    c.r[8] = ld32(c.r[1]);  // 0603E716 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603E718 mov.l @(4,r1),r9
    c.r[0] = ld32(0x0603E7FCu);  // 0603E71A mov.l 0x0603E7FC,r0
    c.r[6] = c.r[8];  // 0603E71C mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603E722u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E722u) return; }  // 0603E71E jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603E722 mov r0,r4
    c.r[5] = c.r[1];  // 0603E724 mov r1,r5
    c.r[0] = ld32(0x0603E800u);  // 0603E726 mov.l 0x0603E800,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603E72Cu; c.r[13] += 79; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E72Cu) return; }  // 0603E728 jsr @r0 ; add #79,r13
    c.r[1] = c.r[0];  // 0603E72C mov r0,r1
    c.r[0] = ld32(0x0603E7ECu);  // 0603E72E mov.l 0x0603E7EC,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0603E730 mov.l r1,@(r0,r10)
    c.r[0] += c.r[10];  // 0603E732 add r10,r0
    st32(c.r[14] + 4, c.r[0]);  // 0603E734 mov.l r0,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603E736 mov.b @r13,r1
    c.r[0] = ld32(0x0603E7F4u);  // 0603E738 mov.l 0x0603E7F4,r0
    c.r[11] -= c.r[1];  // 0603E73A sub r1,r11
    c.r[11] <<= 2;  // 0603E73C shll2 r11
    c.r[11] <<= 2;  // 0603E73E shll2 r11
    c.r[11] -= 105;  // 0603E740 add #-105,r11
    { const uint32_t x = c.r[0]; c.pr = 0x0603E746u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E746u) return; }  // 0603E742 jsr @r0 ; mov r11,r4
    c.r[4] = c.r[0];  // 0603E746 mov r0,r4
    c.r[5] = c.r[1];  // 0603E748 mov r1,r5
    c.r[6] = c.r[8];  // 0603E74A mov r8,r6
    c.r[0] = ld32(0x0603E7FCu);  // 0603E74C mov.l 0x0603E7FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603E752u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E752u) return; }  // 0603E74E jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603E752 mov r0,r4
    c.r[5] = c.r[1];  // 0603E754 mov r1,r5
    c.r[0] = ld32(0x0603E800u);  // 0603E756 mov.l 0x0603E800,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603E75Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E75Cu) return; }  // 0603E758 jsr @r0 ; nop
    c.r[3] = c.r[0];  // 0603E75C mov r0,r3
    c.r[0] = ld32(c.r[14] + 4);  // 0603E75E mov.l @(4,r14),r0
    c.r[1] = ld32(0x0603E804u);  // 0603E760 mov.l 0x0603E804,r1
    st32(c.r[0] + 4, c.r[3]);  // 0603E762 mov.l r3,@(4,r0)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E764 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0603E766 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603E7D0u);  // 0603E768 mov.w 0x0603E7D0,r1
    c.t = c.r[2] == c.r[1];  // 0603E76A cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0603E79E; } }  // 0603E76C bt/s 0x0603E79E ; mov.l @r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603E770 mov.b @r0,r1
    c.r[0] = 0x20u;  // 0603E772 mov #32,r0
    c.r[1] &= c.r[0];  // 0603E774 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603E776 tst r1,r1
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0603E79E; } }  // 0603E778 bt/s 0x0603E79E ; shll2 r2
    c.r[1] = ld32(0x0603E7D8u);  // 0603E77C mov.l 0x0603E7D8,r1
    c.r[1] = ld32(c.r[1]);  // 0603E77E mov.l @r1,r1
    c.r[2] <<= 2;  // 0603E780 shll2 r2
    c.r[2] += c.r[1];  // 0603E782 add r1,r2
    c.r[2] += 3;  // 0603E784 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E786 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0603E788 mov r1,r0
    c.r[0] >>= 2;  // 0603E78A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603E78C shlr r0
    c.r[0] &= 0x3u;  // 0603E78E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603E790 tst r0,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_0603E79E; } }  // 0603E792 bf/s 0x0603E79E ; mov.l @(4,r14),r0
    c.r[1] = ld32(0x0603E7E4u);  // 0603E796 mov.l 0x0603E7E4,r1
    c.r[1] = ld32(c.r[1] + 4);  // 0603E798 mov.l @(4,r1),r1
    c.r[3] += c.r[1];  // 0603E79A add r1,r3
    st32(c.r[0] + 4, c.r[3]);  // 0603E79C mov.l r3,@(4,r0)
L_0603E79E:
    c.r[3] = c.r[12];  // 0603E79E mov r12,r3
    c.r[3] += c.r[3];  // 0603E7A0 add r3,r3
    c.r[3] += c.r[12];  // 0603E7A2 add r12,r3
    c.r[3] <<= 2;  // 0603E7A4 shll2 r3
    c.r[1] = ld32(c.r[14]);  // 0603E7A6 mov.l @r14,r1
    c.r[2] = ld32(0x0603E808u);  // 0603E7A8 mov.l 0x0603E808,r2
    c.r[1] += 1;  // 0603E7AA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E7AC mov.b @r1,r1
    c.r[0] = c.r[3];  // 0603E7AE mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0603E7B0 mov.b r1,@(r0,r2)
L_0603E7B2:
    c.r[0] = ld32(c.r[14]);  // 0603E7B2 mov.l @r14,r0
L_0603E7B4:
    c.r[0] += 2;  // 0603E7B4 add #2,r0
    st32(c.r[14], c.r[0]);  // 0603E7B6 mov.l r0,@r14
    c.r[0] = ld32(c.r[14]);  // 0603E7B8 mov.l @r14,r0
    c.r[14] += 8;  // 0603E7BA add #8,r14
    c.r[15] = c.r[14];  // 0603E7BC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603E7BE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603E7C0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603E7C2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603E7C4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603E7C6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603E7C8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603E7CA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603E7CC rts ; mov.l @r15+,r8
}

void f_0603E80C(SH2Context& c) {
    ran[991] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603E80C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603E80E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603E810 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603E812 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603E814 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603E816 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603E818 mov r15,r14
    c.r[10] = c.r[4];  // 0603E81A mov r4,r10
    c.r[8] = c.r[5];  // 0603E81C mov r5,r8
    c.r[1] = ld32(0x0603E8E8u);  // 0603E81E mov.l 0x0603E8E8,r1
    c.r[5] = c.r[10];  // 0603E820 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603E826u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E826u) return; }  // 0603E822 jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603E826 mov.b @r8,r1
    c.r[2] = ld32(0x0603E8ECu);  // 0603E828 mov.l 0x0603E8EC,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603E82A extu.b r1,r1
    c.r[0] = c.r[1];  // 0603E82C mov r1,r0
    c.r[0] += c.r[0];  // 0603E82E add r0,r0
    c.r[0] += c.r[1];  // 0603E830 add r1,r0
    c.r[0] <<= 2;  // 0603E832 shll2 r0
    c.r[1] = c.r[0];  // 0603E834 mov r0,r1
    c.r[1] += c.r[2];  // 0603E836 add r2,r1
    c.r[1] += 8;  // 0603E838 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E83A mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0603E83C extu.b r1,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 0603E83E tst r11,r11
    if (c.t) { goto L_0603E8AC; }  // 0603E840 bt 0x0603E8AC
    c.r[6] = ld32(c.r[10] + 4);  // 0603E842 mov.l @(4,r10),r6
    c.r[9] = ld32(c.r[0] + c.r[2]);  // 0603E844 mov.l @(r0,r2),r9
    c.r[4] = c.r[6];  // 0603E846 mov r6,r4
    c.r[4] -= c.r[9];  // 0603E848 sub r9,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0603E84A cmp/pz r4
    if (c.t) { goto L_0603E850; }  // 0603E84C bt 0x0603E850
    c.r[4] = 0u - c.r[4];  // 0603E84E neg r4,r4
L_0603E850:
    c.r[7] = ld32(0x0603E8F0u);  // 0603E850 mov.l 0x0603E8F0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603E856u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E856u) return; }  // 0603E852 jsr @r7 ; mov r11,r5
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[9];  // 0603E856 cmp/ge r9,r6
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0603E860; } }  // 0603E858 bf/s 0x0603E860 ; mov r6,r4
    c.r[4] -= c.r[0]; goto L_0603E862;  // 0603E85C bra 0x0603E862 ; sub r0,r4
L_0603E860:
    c.r[4] += c.r[0];  // 0603E860 add r0,r4
L_0603E862:
    st32(c.r[10] + 4, c.r[4]);  // 0603E862 mov.l r4,@(4,r10)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603E864 mov.b @r8,r2
    c.r[1] = ld32(0x0603E8ECu);  // 0603E866 mov.l 0x0603E8EC,r1
    c.r[6] = ld32(c.r[10] + 8);  // 0603E868 mov.l @(8,r10),r6
    c.r[2] = c.r[2] & 0xFFu;  // 0603E86A extu.b r2,r2
    c.r[3] = c.r[2];  // 0603E86C mov r2,r3
    c.r[3] += c.r[3];  // 0603E86E add r3,r3
    c.r[3] += c.r[2];  // 0603E870 add r2,r3
    c.r[3] <<= 2;  // 0603E872 shll2 r3
    c.r[3] += c.r[1];  // 0603E874 add r1,r3
    c.r[9] = ld32(c.r[3] + 4);  // 0603E876 mov.l @(4,r3),r9
    c.r[4] = c.r[6];  // 0603E878 mov r6,r4
    c.r[4] -= c.r[9];  // 0603E87A sub r9,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0603E87C cmp/pz r4
    if (c.t) { goto L_0603E882; }  // 0603E87E bt 0x0603E882
    c.r[4] = 0u - c.r[4];  // 0603E880 neg r4,r4
L_0603E882:
    c.r[7] = ld32(0x0603E8F0u);  // 0603E882 mov.l 0x0603E8F0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603E888u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E888u) return; }  // 0603E884 jsr @r7 ; mov r11,r5
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[9];  // 0603E888 cmp/ge r9,r6
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0603E892; } }  // 0603E88A bf/s 0x0603E892 ; mov r6,r4
    c.r[4] -= c.r[0]; goto L_0603E894;  // 0603E88E bra 0x0603E894 ; sub r0,r4
L_0603E892:
    c.r[4] += c.r[0];  // 0603E892 add r0,r4
L_0603E894:
    st32(c.r[10] + 8, c.r[4]);  // 0603E894 mov.l r4,@(8,r10)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603E896 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603E898 extu.b r1,r1
    c.r[2] = c.r[1];  // 0603E89A mov r1,r2
    c.r[2] += c.r[2];  // 0603E89C add r2,r2
    c.r[2] += c.r[1];  // 0603E89E add r1,r2
    c.r[2] <<= 2;  // 0603E8A0 shll2 r2
    c.r[1] = ld32(0x0603E8F4u);  // 0603E8A2 mov.l 0x0603E8F4,r1
    c.r[2] += c.r[1];  // 0603E8A4 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E8A6 mov.b @r2,r1
    c.r[1] -= 1;  // 0603E8A8 add #-1,r1
    st8(c.r[2], c.r[1]);  // 0603E8AA mov.b r1,@r2
L_0603E8AC:
    c.r[1] = ld32(0x0603E8E8u);  // 0603E8AC mov.l 0x0603E8E8,r1
    c.r[5] = c.r[10];  // 0603E8AE mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603E8B4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E8B4u) return; }  // 0603E8B0 jsr @r1 ; mov #1,r4
    c.t = (c.r[11] & c.r[11]) == 0;  // 0603E8B4 tst r11,r11
    if (!c.t) { goto L_0603E8BE; }  // 0603E8B6 bf 0x0603E8BE
    c.r[8] += 3;  // 0603E8B8 add #3,r8
    c.r[0] = c.r[8]; goto L_0603E8D8;  // 0603E8BA bra 0x0603E8D8 ; mov r8,r0
L_0603E8BE:
    c.r[1] = c.r[8];  // 0603E8BE mov r8,r1
    c.r[1] += 1;  // 0603E8C0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E8C2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603E8C4 extu.b r2,r2
    c.r[1] = c.r[8];  // 0603E8C6 mov r8,r1
    c.r[1] += 2;  // 0603E8C8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E8CA mov.b @r1,r1
    c.r[2] <<= 8;  // 0603E8CC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603E8CE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603E8D0 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603E8D2 exts.w r2,r0
    c.r[0] += 1;  // 0603E8D4 add #1,r0
    c.r[0] += c.r[8];  // 0603E8D6 add r8,r0
L_0603E8D8:
    c.r[15] = c.r[14];  // 0603E8D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603E8DA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603E8DC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603E8DE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603E8E0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603E8E2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603E8E4 rts ; mov.l @r15+,r8
}

void f_0603E8F8(SH2Context& c) {
    ran[992] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603E8F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603E8FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603E8FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603E8FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603E900 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603E902 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603E904 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603E906 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603EA18u);  // 0603E908 mov.w 0x0603EA18,r3
    c.r[15] += c.r[3];  // 0603E90A add r3,r15
    c.r[14] = c.r[15];  // 0603E90C mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603EA1Au);  // 0603E90E mov.w 0x0603EA1A,r0
    st32(c.r[0] + c.r[14], c.r[5]);  // 0603E910 mov.l r5,@(r0,r14)
    c.r[1] = ld32(0x0603EA20u);  // 0603E912 mov.l 0x0603EA20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E914 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0603E916 extu.b r1,r5
    c.r[1] = ld32(0x0603EA24u);  // 0603E918 mov.l 0x0603EA24,r1
    c.r[2] = c.r[5];  // 0603E91A mov r5,r2
    c.r[3] = ld32(c.r[1]);  // 0603E91C mov.l @r1,r3
    c.r[2] <<= 2;  // 0603E91E shll2 r2
    c.r[2] <<= 2;  // 0603E920 shll2 r2
    c.r[2] += c.r[3];  // 0603E922 add r3,r2
    c.r[1] = c.r[2];  // 0603E924 mov r2,r1
    c.r[1] += 4;  // 0603E926 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E928 mov.b @r1,r1
    c.r[13] = 0x1u;  // 0603E92A mov #1,r13
    c.r[1] >>= 2;  // 0603E92C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603E92E shlr r1
    c.r[1] >>= 2;  // 0603E930 shlr2 r1
    c.r[1] &= c.r[13];  // 0603E932 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603E934 tst r1,r1
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0603E93E; } }  // 0603E936 bt/s 0x0603E93E ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603E93A mov.b @r2,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0603E93C extu.b r1,r5
L_0603E93E:
    c.r[1] = ld32(0x0603EA28u);  // 0603E93E mov.l 0x0603EA28,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603EA1Cu);  // 0603E940 mov.w 0x0603EA1C,r8
    c.r[11] = 0x70u;  // 0603E942 mov #112,r11
    c.r[10] = 0xFu;  // 0603E944 mov #15,r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603EA1Eu);  // 0603E946 mov.w 0x0603EA1E,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603E948 mov.b @r1,r0
    c.r[4] = c.r[14];  // 0603E94A mov r14,r4
    c.r[8] &= c.r[0];  // 0603E94C and r0,r8
    c.r[11] &= c.r[0];  // 0603E94E and r0,r11
    c.r[11] >>= 2;  // 0603E950 shlr2 r11
    c.r[11] >>= 2;  // 0603E952 shlr2 r11
    c.r[10] &= c.r[0];  // 0603E954 and r0,r10
    c.r[5] <<= 2;  // 0603E956 shll2 r5
    c.r[5] <<= 2;  // 0603E958 shll2 r5
    c.r[5] += c.r[3];  // 0603E95A add r3,r5
    c.r[5] += 2;  // 0603E95C add #2,r5
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603E95E mov.b @r5,r5
    c.r[1] = ld32(0x0603EA2Cu);  // 0603E960 mov.l 0x0603EA2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603E966u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E966u) return; }  // 0603E962 jsr @r1 ; extu.b r5,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 0603E966 tst r8,r8
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_0603E978; } }  // 0603E968 bf/s 0x0603E978 ; mov r14,r1
    c.r[1] += 26;  // 0603E96C add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603E96E mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0603E970 extu.w r1,r6
    c.r[1] = c.r[14];  // 0603E972 mov r14,r1
    c.r[1] += 22; goto L_0603E982;  // 0603E974 bra 0x0603E982 ; add #22,r1
L_0603E978:
    c.r[1] += 28;  // 0603E978 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603E97A mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0603E97C extu.w r1,r6
    c.r[1] = c.r[14];  // 0603E97E mov r14,r1
    c.r[1] += 24;  // 0603E980 add #24,r1
L_0603E982:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603E982 mov.w @r1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0603E984 extu.w r1,r8
    c.r[7] = ld32(0x0603EA30u);  // 0603E986 mov.l 0x0603EA30,r7
    c.macl = c.r[8] * c.r[11];  // 0603E988 mul.l r11,r8
    c.r[5] = c.r[6];  // 0603E98A mov r6,r5
    c.r[0] = ld32(0x0603EA34u);  // 0603E98C mov.l 0x0603EA34,r0
    c.r[1] = c.macl;  // 0603E98E sts macl,r1
    c.macl = c.r[1] * c.r[10];  // 0603E990 mul.l r10,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603EA1Au);  // 0603E992 mov.w 0x0603EA1A,r13
    c.r[13] += c.r[14];  // 0603E994 add r14,r13
    { const uint32_t x = c.r[0]; c.pr = 0x0603E99Au; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E99Au) return; }  // 0603E996 jsr @r0 ; sts macl,r4
    c.r[9] = c.r[0];  // 0603E99A mov r0,r9
    st8(c.r[7], c.r[9]);  // 0603E99C mov.b r9,@r7
    c.r[0] = ld32(c.r[13]);  // 0603E99E mov.l @r13,r0
    c.r[12] = ld32(0x0603EA38u);  // 0603E9A0 mov.l 0x0603EA38,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603E9A2 mov.b @r0,r1
    c.r[13] = ld32(0x0603EA3Cu);  // 0603E9A4 mov.l 0x0603EA3C,r13
    c.r[7] = c.r[1] & 0xFFu;  // 0603E9A6 extu.b r1,r7
    c.r[1] = ld32(c.r[13]);  // 0603E9A8 mov.l @r13,r1
    c.r[7] += c.r[7];  // 0603E9AA add r7,r7
    c.t = (int32_t)c.r[1] >= 0;  // 0603E9AC cmp/pz r1
    if (c.t) { goto L_0603E9B2; }  // 0603E9AE bt 0x0603E9B2
    c.r[1] = 0u - c.r[1];  // 0603E9B0 neg r1,r1
L_0603E9B2:
    c.macl = c.r[1] * c.r[11];  // 0603E9B2 mul.l r11,r1
    c.r[5] = c.r[6];  // 0603E9B4 mov r6,r5
    c.r[1] = c.macl;  // 0603E9B6 sts macl,r1
    c.macl = c.r[1] * c.r[10];  // 0603E9B8 mul.l r10,r1
    c.r[0] = ld32(0x0603EA34u);  // 0603E9BA mov.l 0x0603EA34,r0
    c.r[13] = ld32(0x0603EA3Cu);  // 0603E9BC mov.l 0x0603EA3C,r13
    { const uint32_t x = c.r[0]; c.pr = 0x0603E9C2u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603E9C2u) return; }  // 0603E9BE jsr @r0 ; sts macl,r4
    c.r[5] = c.r[0];  // 0603E9C2 mov r0,r5
    c.r[0] = c.r[7];  // 0603E9C4 mov r7,r0
    st16(c.r[0] + c.r[12], c.r[5]);  // 0603E9C6 mov.w r5,@(r0,r12)
    c.r[1] = ld32(c.r[13]);  // 0603E9C8 mov.l @r13,r1
    c.r[1] += c.r[8];  // 0603E9CA add r8,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[6];  // 0603E9CC cmp/ge r6,r1
    { const bool k = !c.t; c.macl = (c.r[11] & 0xFFFFu) * (c.r[10] & 0xFFFFu); if (k) { goto L_0603E9E8; } }  // 0603E9CE bf/s 0x0603E9E8 ; mulu.w r10,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603EA1Au);  // 0603E9D2 mov.w 0x0603EA1A,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0603E9D4 mov.l @(r0,r14),r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603E9D6 mov.b @r13,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603E9D8 extu.b r1,r3
    c.r[3] += c.r[3];  // 0603E9DA add r3,r3
    c.r[2] = c.macl;  // 0603E9DC sts macl,r2
    c.r[1] = c.r[9] & 0xFFu;  // 0603E9DE extu.b r9,r1
    c.r[2] -= c.r[1];  // 0603E9E0 sub r1,r2
    c.r[0] = c.r[3];  // 0603E9E2 mov r3,r0
    st16(c.r[0] + c.r[12], c.r[2]); goto L_0603E9FE;  // 0603E9E4 bra 0x0603E9FE ; mov.w r2,@(r0,r12)
L_0603E9E8:
    c.t = (int32_t)c.r[1] > 0;  // 0603E9E8 cmp/pl r1
    if (c.t) { goto L_0603E9FE; }  // 0603E9EA bt 0x0603E9FE
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603EA1Au);  // 0603E9EC mov.w 0x0603EA1A,r13
    c.r[13] += c.r[14];  // 0603E9EE add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0603E9F0 mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603E9F2 mov.b @r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0603E9F4 extu.b r1,r2
    c.r[2] += c.r[2];  // 0603E9F6 add r2,r2
    c.r[1] = c.r[9] & 0xFFu;  // 0603E9F8 extu.b r9,r1
    c.r[0] = c.r[2];  // 0603E9FA mov r2,r0
    st16(c.r[0] + c.r[12], c.r[1]);  // 0603E9FC mov.w r1,@(r0,r12)
L_0603E9FE:
    c.r[7] = ld32(0x0603EA30u);  // 0603E9FE mov.l 0x0603EA30,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603EA00 mov.b @r7,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0603EA02 extu.b r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603EA04 tst r2,r2
    { const bool k = !c.t; c.macl = c.r[11] * c.r[10]; if (k) { goto L_0603EA40; } }  // 0603EA06 bf/s 0x0603EA40 ; mul.l r10,r11
    c.r[1] = ld32(0x0603EA3Cu);  // 0603EA0A mov.l 0x0603EA3C,r1
    c.r[1] = ld32(c.r[1]);  // 0603EA0C mov.l @r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603EA0E cmp/pz r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0603EA68; } }  // 0603EA10 bt/s 0x0603EA68 ; mov #1,r1
    st8(c.r[7], c.r[1]); goto L_0603EA54;  // 0603EA14 bra 0x0603EA54 ; mov.b r1,@r7
L_0603EA40:
    c.r[1] = c.macl;  // 0603EA40 sts macl,r1
    c.t = c.r[2] == c.r[1];  // 0603EA42 cmp/eq r1,r2
    if (!c.t) { goto L_0603EA68; }  // 0603EA44 bf 0x0603EA68
    c.r[1] = ld32(0x0603EA94u);  // 0603EA46 mov.l 0x0603EA94,r1
    c.r[1] = ld32(c.r[1]);  // 0603EA48 mov.l @r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 0603EA4A cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0603EA68; } }  // 0603EA4C bf/s 0x0603EA68 ; mov r3,r1
    c.r[1] -= 1;  // 0603EA50 add #-1,r1
    st8(c.r[7], c.r[1]);  // 0603EA52 mov.b r1,@r7
L_0603EA54:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603EA90u);  // 0603EA54 mov.w 0x0603EA90,r13
    c.r[13] += c.r[14];  // 0603EA56 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0603EA58 mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603EA5A mov.b @r0,r1
    c.r[2] = ld32(0x0603EA98u);  // 0603EA5C mov.l 0x0603EA98,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0603EA5E extu.b r1,r3
    c.r[3] += c.r[3];  // 0603EA60 add r3,r3
    c.r[1] = 0x1u;  // 0603EA62 mov #1,r1
    c.r[0] = c.r[3];  // 0603EA64 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0603EA66 mov.w r1,@(r0,r2)
L_0603EA68:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603EA90u);  // 0603EA68 mov.w 0x0603EA90,r13
    c.r[13] += c.r[14];  // 0603EA6A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0603EA6C mov.l @r13,r0
    c.r[0] += 1;  // 0603EA6E add #1,r0
    st32(c.r[13], c.r[0]);  // 0603EA70 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603EA90u);  // 0603EA72 mov.w 0x0603EA90,r13
    c.r[13] += c.r[14];  // 0603EA74 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0603EA76 mov.l @r13,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603EA92u);  // 0603EA78 mov.w 0x0603EA92,r3
    c.r[14] += c.r[3];  // 0603EA7A add r3,r14
    c.r[15] = c.r[14];  // 0603EA7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603EA7E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603EA80 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603EA82 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603EA84 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603EA86 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603EA88 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603EA8A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603EA8C rts ; mov.l @r15+,r8
}

void f_0603EA9C(SH2Context& c) {
    ran[993] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603EA9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603EA9E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603EAA0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603EAA2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603EAA4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603EAA6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603EAA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603EAAA sts.l pr,@-r15
    c.r[15] -= 8;  // 0603EAAC add #-8,r15
    c.r[14] = c.r[15];  // 0603EAAE mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603EAB0 mov.l r5,@r14
    c.r[1] = ld32(0x0603EB90u);  // 0603EAB2 mov.l 0x0603EB90,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EAB4 mov.b @r1,r0
    c.r[11] = 0x70u;  // 0603EAB6 mov #112,r11
    c.r[10] = 0xFu;  // 0603EAB8 mov #15,r10
    c.r[11] &= c.r[0];  // 0603EABA and r0,r11
    c.r[11] >>= 2;  // 0603EABC shlr2 r11
    c.r[11] >>= 2;  // 0603EABE shlr2 r11
    c.r[10] &= c.r[0];  // 0603EAC0 and r0,r10
    c.macl = c.r[11] * c.r[10];  // 0603EAC2 mul.l r10,r11
    c.r[8] = 0x0u;  // 0603EAC4 mov #0,r8
    c.r[1] = c.macl;  // 0603EAC6 sts macl,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0603EAC8 cmp/ge r1,r8
    if (c.t) { goto L_0603EB5A; }  // 0603EACA bt 0x0603EB5A
    c.r[12] = ld32(0x0603EB94u);  // 0603EACC mov.l 0x0603EB94,r12
    c.r[13] = ld32(0x0603EB98u);  // 0603EACE mov.l 0x0603EB98,r13
L_0603EAD0:
    c.r[1] = ld32(0x0603EB9Cu);  // 0603EAD0 mov.l 0x0603EB9C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EAD2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603EAD4 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0603EAD6 cmp/ge r1,r8
    { const bool k = c.t; c.r[4] = c.r[8]; if (k) { goto L_0603EB1C; } }  // 0603EAD8 bt/s 0x0603EB1C ; mov r8,r4
    c.r[1] = c.r[12];  // 0603EADC mov r12,r1
    c.r[1] += 1;  // 0603EADE add #1,r1
    c.r[5] = c.r[10];  // 0603EAE0 mov r10,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EAE2 mov.b @r1,r1
    c.r[7] = ld32(0x0603EBA0u);  // 0603EAE4 mov.l 0x0603EBA0,r7
    c.r[6] = c.r[1] & 0xFFu;  // 0603EAE6 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0603EAE8 mov.b @r12,r1
    c.r[9] = ld32(0x0603EBA4u);  // 0603EAEA mov.l 0x0603EBA4,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0603EAEC extu.b r1,r1
    { const uint32_t x = c.r[7]; c.pr = 0x0603EAF2u; st32(c.r[14] + 4, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EAF2u) return; }  // 0603EAEE jsr @r7 ; mov.l r1,@(4,r14)
    c.r[0] <<= 2;  // 0603EAF2 shll2 r0
    c.r[0] <<= 2;  // 0603EAF4 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0603EAF6 mov.w @r9,r1
    c.t = (int32_t)c.r[8] >= 0;  // 0603EAF8 cmp/pz r8
    c.r[0] += c.r[1];  // 0603EAFA add r1,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0603EB02; } }  // 0603EAFC bt/s 0x0603EB02 ; mov r8,r1
    c.r[1] += 7;  // 0603EB00 add #7,r1
L_0603EB02:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603EB02 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603EB04 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603EB06 shar r1
    c.r[1] <<= 2;  // 0603EB08 shll2 r1
    c.r[1] += c.r[1];  // 0603EB0A add r1,r1
    c.r[9] = c.r[8];  // 0603EB0C mov r8,r9
    c.r[9] -= c.r[1];  // 0603EB0E sub r1,r9
    c.r[1] = c.r[9];  // 0603EB10 mov r9,r1
    c.r[0] += c.r[1];  // 0603EB12 add r1,r0
    c.r[4] = c.r[0] & 0xFFFFu;  // 0603EB14 extu.w r0,r4
    c.r[5] = ld32(c.r[14] + 4);  // 0603EB16 mov.l @(4,r14),r5
    c.r[7] = 0x1u; goto L_0603EB4E;  // 0603EB18 bra 0x0603EB4E ; mov #1,r7
L_0603EB1C:
    c.r[7] = ld32(0x0603EBA0u);  // 0603EB1C mov.l 0x0603EBA0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603EB22u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EB22u) return; }  // 0603EB1E jsr @r7 ; mov r10,r5
    c.r[0] <<= 2;  // 0603EB22 shll2 r0
    c.r[0] <<= 2;  // 0603EB24 shll2 r0
    c.r[9] = ld32(0x0603EBA4u);  // 0603EB26 mov.l 0x0603EBA4,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0603EB28 mov.w @r9,r1
    c.t = (int32_t)c.r[8] >= 0;  // 0603EB2A cmp/pz r8
    c.r[0] += c.r[1];  // 0603EB2C add r1,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0603EB34; } }  // 0603EB2E bt/s 0x0603EB34 ; mov r8,r1
    c.r[1] += 7;  // 0603EB32 add #7,r1
L_0603EB34:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603EB34 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603EB36 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603EB38 shar r1
    c.r[1] <<= 2;  // 0603EB3A shll2 r1
    c.r[1] += c.r[1];  // 0603EB3C add r1,r1
    c.r[9] = c.r[8];  // 0603EB3E mov r8,r9
    c.r[9] -= c.r[1];  // 0603EB40 sub r1,r9
    c.r[1] = c.r[9];  // 0603EB42 mov r9,r1
    c.r[0] += c.r[1];  // 0603EB44 add r1,r0
    c.r[4] = c.r[0] & 0xFFFFu;  // 0603EB46 extu.w r0,r4
    c.r[7] = 0x1u;  // 0603EB48 mov #1,r7
    c.r[6] = 0x21u;  // 0603EB4A mov #33,r6
    c.r[5] = 0x1u;  // 0603EB4C mov #1,r5
L_0603EB4E:
    { const uint32_t x = c.r[13]; c.pr = 0x0603EB52u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EB52u) return; }  // 0603EB4E jsr @r13 ; add #1,r8
    c.macl = c.r[11] * c.r[10];  // 0603EB52 mul.l r10,r11
    c.r[1] = c.macl;  // 0603EB54 sts macl,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0603EB56 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0603EAD0; }  // 0603EB58 bf 0x0603EAD0
L_0603EB5A:
    c.r[3] = ld32(0x0603EB9Cu);  // 0603EB5A mov.l 0x0603EB9C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603EB5C mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0603EB5E extu.b r1,r2
    c.r[1] = ld32(0x0603EBA8u);  // 0603EB60 mov.l 0x0603EBA8,r1
    c.r[1] = ld32(c.r[1]);  // 0603EB62 mov.l @r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603EB64 cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0603EB6E; } }  // 0603EB66 bt/s 0x0603EB6E ; mov r2,r1
    c.r[1] -= 1; goto L_0603EB70;  // 0603EB6A bra 0x0603EB70 ; add #-1,r1
L_0603EB6E:
    c.r[1] += 1;  // 0603EB6E add #1,r1
L_0603EB70:
    st8(c.r[3], c.r[1]);  // 0603EB70 mov.b r1,@r3
    c.r[2] = ld32(0x0603EBACu);  // 0603EB72 mov.l 0x0603EBAC,r2
    c.r[1] = 0x1u;  // 0603EB74 mov #1,r1
    st16(c.r[2], c.r[1]);  // 0603EB76 mov.w r1,@r2
    c.r[0] = ld32(c.r[14]);  // 0603EB78 mov.l @r14,r0
    c.r[14] += 8;  // 0603EB7A add #8,r14
    c.r[15] = c.r[14];  // 0603EB7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603EB7E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603EB80 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603EB82 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603EB84 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603EB86 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603EB88 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603EB8A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603EB8C rts ; mov.l @r15+,r8
}

void f_0603EBB0(SH2Context& c) {
    ran[994] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603EBB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603EBB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603EBB4 sts.l pr,@-r15
    c.r[7] = c.r[5];  // 0603EBB6 mov r5,r7
    c.r[2] = c.r[7];  // 0603EBB8 mov r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0603EBBA mov.b @r2+,r1
    c.r[15] -= 16;  // 0603EBBC add #-16,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0603EBBE extu.b r1,r1
    c.r[3] = c.r[1];  // 0603EBC0 mov r1,r3
    c.r[3] <<= 8;  // 0603EBC2 shll8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603EBC4 mov.b @r2,r1
    c.r[14] = c.r[15];  // 0603EBC6 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0603EBC8 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0603EBCA or r1,r3
    c.r[1] = ld32(0x0603ECDCu);  // 0603EBCC mov.l 0x0603ECDC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EBCE mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603EBD0 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603EBD2 tst r0,r0
    { const bool k = c.t; c.r[8] = c.r[7]; if (k) { goto L_0603EBF6; } }  // 0603EBD4 bt/s 0x0603EBF6 ; mov r7,r8
    c.r[1] = ld32(0x0603ECE0u);  // 0603EBD8 mov.l 0x0603ECE0,r1
    c.t = c.r[0] == 0x2u;  // 0603EBDA cmp/eq #2,r0
    { const bool k = c.t; c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]); if (k) { goto L_0603EBF4; } }  // 0603EBDC bt/s 0x0603EBF4 ; mov.w @r1,r2
    c.t = c.r[0] == 0x1u;  // 0603EBE0 cmp/eq #1,r0
    if (!c.t) { goto L_0603EBEA; }  // 0603EBE2 bf 0x0603EBEA
    c.r[2] += c.r[2];  // 0603EBE4 add r2,r2
    c.r[3] += c.r[2]; goto L_0603EBF6;  // 0603EBE6 bra 0x0603EBF6 ; add r2,r3
L_0603EBEA:
    c.r[1] = c.r[2];  // 0603EBEA mov r2,r1
    c.r[1] += c.r[1];  // 0603EBEC add r1,r1
    c.r[1] += c.r[2];  // 0603EBEE add r2,r1
    c.r[3] += c.r[1]; goto L_0603EBF6;  // 0603EBF0 bra 0x0603EBF6 ; add r1,r3
L_0603EBF4:
    c.r[3] += c.r[2];  // 0603EBF4 add r2,r3
L_0603EBF6:
    c.r[1] = c.r[3] & 0xFFFFu;  // 0603EBF6 extu.w r3,r1
    c.r[3] = c.r[1];  // 0603EBF8 mov r1,r3
    c.r[1] >>= 8;  // 0603EBFA shlr8 r1
    st8(c.r[14], c.r[1]);  // 0603EBFC mov.b r1,@r14
    c.r[1] = c.r[14];  // 0603EBFE mov r14,r1
    c.r[1] += 1;  // 0603EC00 add #1,r1
    st8(c.r[1], c.r[3]);  // 0603EC02 mov.b r3,@r1
    c.r[1] = c.r[7];  // 0603EC04 mov r7,r1
    c.r[1] += 2;  // 0603EC06 add #2,r1
    c.r[2] = c.r[14];  // 0603EC08 mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EC0A mov.b @r1,r1
    c.r[2] += 4;  // 0603EC0C add #4,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0603EC0E extu.b r1,r6
    st32(c.r[14] + 8, c.r[6]);  // 0603EC10 mov.l r6,@(8,r14)
    c.r[1] = c.r[7];  // 0603EC12 mov r7,r1
    c.r[1] += 3;  // 0603EC14 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EC16 mov.b @r1,r1
    c.r[5] = c.r[7];  // 0603EC18 mov r7,r5
    c.r[3] = c.r[1] & 0xFFu;  // 0603EC1A extu.b r1,r3
    st32(c.r[14] + 12, c.r[3]);  // 0603EC1C mov.l r3,@(12,r14)
    c.r[1] = c.r[7];  // 0603EC1E mov r7,r1
    c.r[1] += 4;  // 0603EC20 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EC22 mov.b @r1,r1
    c.r[5] += 5;  // 0603EC24 add #5,r5
    st8(c.r[2], c.r[1]);  // 0603EC26 mov.b r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603EC28 mov.b @r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603ECDAu);  // 0603EC2A mov.w 0x0603ECDA,r1
    c.r[1] &= c.r[2];  // 0603EC2C and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603EC2E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2] & 0xFFu; if (k) { goto L_0603EC86; } }  // 0603EC30 bt/s 0x0603EC86 ; extu.b r2,r1
    c.r[1] = ld32(0x0603ECDCu);  // 0603EC34 mov.l 0x0603ECDC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EC36 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603EC38 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 0603EC3A cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0603EC5C; } }  // 0603EC3C bt/s 0x0603EC5C ; mov #2,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0603EC40 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0603EC50; } }  // 0603EC42 bt/s 0x0603EC50 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 0603EC46 cmp/eq #1,r0
    { const bool k = c.t; c.r[2] = 0u - c.r[3]; if (k) { goto L_0603EC58; } }  // 0603EC48 bt/s 0x0603EC58 ; neg r3,r2
    c.r[2] = ld32(c.r[14] + 8); goto L_0603EC66;  // 0603EC4C bra 0x0603EC66 ; mov.l @(8,r14),r2
L_0603EC50:
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0603EC62; } }  // 0603EC50 bt/s 0x0603EC62 ; mov r3,r2
    c.r[2] = ld32(c.r[14] + 8); goto L_0603EC66;  // 0603EC54 bra 0x0603EC66 ; mov.l @(8,r14),r2
L_0603EC58:
    c.r[1] = c.r[6]; goto L_0603EC68;  // 0603EC58 bra 0x0603EC68 ; mov r6,r1
L_0603EC5C:
    c.r[2] = 0u - c.r[6];  // 0603EC5C neg r6,r2
    c.r[1] = 0u - c.r[3]; goto L_0603EC68;  // 0603EC5E bra 0x0603EC68 ; neg r3,r1
L_0603EC62:
    c.r[1] = 0u - c.r[6]; goto L_0603EC68;  // 0603EC62 bra 0x0603EC68 ; neg r6,r1
L_0603EC66:
    c.r[1] = ld32(c.r[14] + 12);  // 0603EC66 mov.l @(12,r14),r1
L_0603EC68:
    st32(c.r[14] + 8, c.r[2]);  // 0603EC68 mov.l r2,@(8,r14)
    st32(c.r[14] + 12, c.r[1]);  // 0603EC6A mov.l r1,@(12,r14)
    c.r[2] = c.r[14];  // 0603EC6C mov r14,r2
    c.r[1] = c.r[14];  // 0603EC6E mov r14,r1
    c.r[1] += 11;  // 0603EC70 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EC72 mov.b @r1,r1
    c.r[2] += 2;  // 0603EC74 add #2,r2
    st8(c.r[2], c.r[1]);  // 0603EC76 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0603EC78 mov r14,r2
    c.r[1] = c.r[14];  // 0603EC7A mov r14,r1
    c.r[1] += 15;  // 0603EC7C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EC7E mov.b @r1,r1
    c.r[2] += 3;  // 0603EC80 add #3,r2
    st8(c.r[2], c.r[1]); goto L_0603ECC4;  // 0603EC82 bra 0x0603ECC4 ; mov.b r1,@r2
L_0603EC86:
    c.r[7] = c.r[14];  // 0603EC86 mov r14,r7
    c.r[6] = ld32(0x0603ECE4u);  // 0603EC88 mov.l 0x0603ECE4,r6
    c.r[3] = c.r[1];  // 0603EC8A mov r1,r3
    c.r[3] += c.r[3];  // 0603EC8C add r3,r3
    c.r[3] += c.r[1];  // 0603EC8E add r1,r3
    c.r[3] <<= 2;  // 0603EC90 shll2 r3
    c.r[3] += c.r[6];  // 0603EC92 add r6,r3
    c.r[3] += 3;  // 0603EC94 add #3,r3
    c.r[2] = c.r[14];  // 0603EC96 mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603EC98 mov.b @r3,r1
    c.r[2] += 11;  // 0603EC9A add #11,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603EC9C mov.b @r2,r2
    c.r[7] += 2;  // 0603EC9E add #2,r7
    c.r[1] += c.r[2];  // 0603ECA0 add r2,r1
    st8(c.r[7], c.r[1]);  // 0603ECA2 mov.b r1,@r7
    c.r[7] = c.r[14];  // 0603ECA4 mov r14,r7
    c.r[2] = c.r[14];  // 0603ECA6 mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603ECA8 mov.b @r5,r1
    c.r[2] += 15;  // 0603ECAA add #15,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603ECAC mov.b @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603ECAE extu.b r1,r1
    c.r[3] = c.r[1];  // 0603ECB0 mov r1,r3
    c.r[3] += c.r[3];  // 0603ECB2 add r3,r3
    c.r[3] += c.r[1];  // 0603ECB4 add r1,r3
    c.r[3] <<= 2;  // 0603ECB6 shll2 r3
    c.r[3] += c.r[6];  // 0603ECB8 add r6,r3
    c.r[3] += 7;  // 0603ECBA add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603ECBC mov.b @r3,r1
    c.r[7] += 3;  // 0603ECBE add #3,r7
    c.r[1] += c.r[2];  // 0603ECC0 add r2,r1
    st8(c.r[7], c.r[1]);  // 0603ECC2 mov.b r1,@r7
L_0603ECC4:
    c.r[0] = ld32(0x0603ECE8u);  // 0603ECC4 mov.l 0x0603ECE8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603ECCAu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603ECCAu) return; }  // 0603ECC6 jsr @r0 ; mov r14,r5
    c.r[14] += 16;  // 0603ECCA add #16,r14
    c.r[15] = c.r[14];  // 0603ECCC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603ECCE lds.l @r15+,pr
    c.r[8] += 6;  // 0603ECD0 add #6,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603ECD2 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603ECD4 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603ECD6 rts ; mov.l @r15+,r8
}

void f_0603ECF4(SH2Context& c) {
    ran[995] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603ECF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603ECF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603ECF8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603ECFA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603ECFC sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603ECFE mov r5,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603ED00 mov.b @r8,r1
    c.r[7] = ld32(0x0603EE7Cu);  // 0603ED02 mov.l 0x0603EE7C,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603ED04 extu.b r1,r1
    c.r[3] = c.r[1];  // 0603ED06 mov r1,r3
    c.r[3] += c.r[3];  // 0603ED08 add r3,r3
    c.r[3] += c.r[1];  // 0603ED0A add r1,r3
    c.r[3] <<= 2;  // 0603ED0C shll2 r3
    c.r[2] = c.r[3];  // 0603ED0E mov r3,r2
    c.r[2] += c.r[7];  // 0603ED10 add r7,r2
    c.r[1] = c.r[2];  // 0603ED12 mov r2,r1
    c.r[1] += 8;  // 0603ED14 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ED16 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603ED18 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603ED1A tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603ED24; } }  // 0603ED1C bf/s 0x0603ED24 ; mov r15,r14
    goto L_0603EE34;  // 0603ED20 bra 0x0603EE34 ; nop
L_0603ED24:
    c.r[1] = ld32(0x0603EE80u);  // 0603ED24 mov.l 0x0603EE80,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ED26 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0603ED28 extu.b r1,r6
    c.r[1] = 0x1u;  // 0603ED2A mov #1,r1
    c.r[1] &= c.r[6];  // 0603ED2C and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603ED2E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0603ED4E; } }  // 0603ED30 bt/s 0x0603ED4E ; mov r2,r1
    c.r[2] = c.r[3];  // 0603ED34 mov r3,r2
    c.r[0] = c.r[7];  // 0603ED36 mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0603ED38 mov.l @(r0,r2),r1
    c.r[0] = c.r[6];  // 0603ED3A mov r6,r0
    c.t = c.r[0] == 0x1u;  // 0603ED3C cmp/eq #1,r0
    if (!c.t) { goto L_0603ED46; }  // 0603ED3E bf 0x0603ED46
    c.r[1] += 1;  // 0603ED40 add #1,r1
    c.r[0] = c.r[7]; goto L_0603ED4A;  // 0603ED42 bra 0x0603ED4A ; mov r7,r0
L_0603ED46:
    c.r[1] -= 1;  // 0603ED46 add #-1,r1
    c.r[0] = c.r[7];  // 0603ED48 mov r7,r0
L_0603ED4A:
    st32(c.r[0] + c.r[2], c.r[1]); goto L_0603ED5E;  // 0603ED4A bra 0x0603ED5E ; mov.l r1,@(r0,r2)
L_0603ED4E:
    c.r[0] = c.r[6];  // 0603ED4E mov r6,r0
    c.t = c.r[0] == 0x2u;  // 0603ED50 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[1] + 4); if (k) { goto L_0603ED5A; } }  // 0603ED52 bf/s 0x0603ED5A ; mov.l @(4,r1),r2
    c.r[2] += 1; goto L_0603ED5C;  // 0603ED56 bra 0x0603ED5C ; add #1,r2
L_0603ED5A:
    c.r[2] -= 1;  // 0603ED5A add #-1,r2
L_0603ED5C:
    st32(c.r[1] + 4, c.r[2]);  // 0603ED5C mov.l r2,@(4,r1)
L_0603ED5E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603ED5E mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603ED60 extu.b r1,r1
    c.r[2] = c.r[1];  // 0603ED62 mov r1,r2
    c.r[2] += c.r[2];  // 0603ED64 add r2,r2
    c.r[2] += c.r[1];  // 0603ED66 add r1,r2
    c.r[2] <<= 2;  // 0603ED68 shll2 r2
    c.r[1] = ld32(0x0603EE84u);  // 0603ED6A mov.l 0x0603EE84,r1
    c.r[2] += c.r[1];  // 0603ED6C add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603ED6E mov.b @r2,r1
    c.r[4] = ld32(0x0603EE88u);  // 0603ED70 mov.l 0x0603EE88,r4
    c.r[1] -= 1;  // 0603ED72 add #-1,r1
    st8(c.r[2], c.r[1]);  // 0603ED74 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603ED76 mov.b @r4,r1
    c.r[0] = c.r[1];  // 0603ED78 mov r1,r0
    c.r[0] >>= 2;  // 0603ED7A shlr2 r0
    c.r[0] >>= 2;  // 0603ED7C shlr2 r0
    c.r[0] >>= 2;  // 0603ED7E shlr2 r0
    c.r[0] &= 0x1u;  // 0603ED80 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603ED82 tst r0,r0
    if (c.t) { goto L_0603EE34; }  // 0603ED84 bt 0x0603EE34
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603ED86 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603ED88 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603ED8A tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_0603EE34; } }  // 0603ED8C bf/s 0x0603EE34 ; mov r4,r1
    c.r[1] += 118;  // 0603ED90 add #118,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ED92 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603ED94 mov r1,r0
    c.r[0] >>= 2;  // 0603ED96 shlr2 r0
    c.r[0] >>= 2;  // 0603ED98 shlr2 r0
    c.r[0] >>= 2;  // 0603ED9A shlr2 r0
    c.r[0] &= 0x1u;  // 0603ED9C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603ED9E tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0603EDE2; } }  // 0603EDA0 bt/s 0x0603EDE2 ; mov r4,r1
    c.r[4] += 126;  // 0603EDA4 add #126,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603EDA6 mov.b @r4,r4
    c.r[1] = ld32(0x0603EE80u);  // 0603EDA8 mov.l 0x0603EE80,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EDAA mov.b @r1,r1
    c.r[10] = ld32(0x0603EE8Cu);  // 0603EDAC mov.l 0x0603EE8C,r10
    c.r[0] = c.r[1] & 0xFFu;  // 0603EDAE extu.b r1,r0
    c.t = c.r[0] == 0x3u;  // 0603EDB0 cmp/eq #3,r0
    { const bool k = !c.t; c.r[9] = ld32(c.r[10]); if (k) { goto L_0603EDB8; } }  // 0603EDB2 bf/s 0x0603EDB8 ; mov.l @r10,r9
    c.r[4] = 0u - c.r[4];  // 0603EDB6 neg r4,r4
L_0603EDB8:
    c.r[1] = ld32(0x0603EE90u);  // 0603EDB8 mov.l 0x0603EE90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603EDBEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EDBEu) return; }  // 0603EDBA jsr @r1 ; nop
    c.r[4] = c.r[0];  // 0603EDBE mov r0,r4
    c.r[5] = c.r[1];  // 0603EDC0 mov r1,r5
    c.r[1] = ld32(0x0603EE94u);  // 0603EDC2 mov.l 0x0603EE94,r1
    c.r[6] = ld32(c.r[1]);  // 0603EDC4 mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0603EDC6 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0603EE98u);  // 0603EDC8 mov.l 0x0603EE98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603EDCEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EDCEu) return; }  // 0603EDCA jsr @r1 ; nop
    c.r[4] = c.r[0];  // 0603EDCE mov r0,r4
    c.r[5] = c.r[1];  // 0603EDD0 mov r1,r5
    c.r[0] = ld32(0x0603EE9Cu);  // 0603EDD2 mov.l 0x0603EE9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603EDD8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EDD8u) return; }  // 0603EDD4 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0603EDD8 mov r0,r1
    c.r[1] += c.r[9];  // 0603EDDA add r9,r1
    st32(c.r[10], c.r[1]);  // 0603EDDC mov.l r1,@r10
    c.r[4] = ld32(0x0603EE88u);  // 0603EDDE mov.l 0x0603EE88,r4
    c.r[1] = c.r[4];  // 0603EDE0 mov r4,r1
L_0603EDE2:
    c.r[1] += 122;  // 0603EDE2 add #122,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EDE4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603EDE6 mov r1,r0
    c.r[0] >>= 2;  // 0603EDE8 shlr2 r0
    c.r[0] >>= 2;  // 0603EDEA shlr2 r0
    c.r[0] >>= 2;  // 0603EDEC shlr2 r0
    c.r[0] &= 0x1u;  // 0603EDEE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603EDF0 tst r0,r0
    { const bool k = c.t; c.r[4] += 127; if (k) { goto L_0603EE2E; } }  // 0603EDF2 bt/s 0x0603EE2E ; add #127,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603EDF6 mov.b @r4,r4
    c.r[1] = ld32(0x0603EE80u);  // 0603EDF8 mov.l 0x0603EE80,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EDFA mov.b @r1,r1
    c.r[10] = ld32(0x0603EEA0u);  // 0603EDFC mov.l 0x0603EEA0,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0603EDFE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603EE00 tst r1,r1
    { const bool k = !c.t; c.r[9] = ld32(c.r[10]); if (k) { goto L_0603EE08; } }  // 0603EE02 bf/s 0x0603EE08 ; mov.l @r10,r9
    c.r[4] = 0u - c.r[4];  // 0603EE06 neg r4,r4
L_0603EE08:
    c.r[1] = ld32(0x0603EE90u);  // 0603EE08 mov.l 0x0603EE90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603EE0Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EE0Eu) return; }  // 0603EE0A jsr @r1 ; nop
    c.r[4] = c.r[0];  // 0603EE0E mov r0,r4
    c.r[5] = c.r[1];  // 0603EE10 mov r1,r5
    c.r[1] = ld32(0x0603EE94u);  // 0603EE12 mov.l 0x0603EE94,r1
    c.r[6] = ld32(c.r[1]);  // 0603EE14 mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0603EE16 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0603EE98u);  // 0603EE18 mov.l 0x0603EE98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603EE1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EE1Eu) return; }  // 0603EE1A jsr @r1 ; nop
    c.r[4] = c.r[0];  // 0603EE1E mov r0,r4
    c.r[5] = c.r[1];  // 0603EE20 mov r1,r5
    c.r[0] = ld32(0x0603EE9Cu);  // 0603EE22 mov.l 0x0603EE9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603EE28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EE28u) return; }  // 0603EE24 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0603EE28 mov r0,r1
    c.r[1] += c.r[9];  // 0603EE2A add r9,r1
    st32(c.r[10], c.r[1]);  // 0603EE2C mov.l r1,@r10
L_0603EE2E:
    c.r[1] = ld32(0x0603EEA4u);  // 0603EE2E mov.l 0x0603EEA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603EE34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EE34u) return; }  // 0603EE30 jsr @r1 ; nop
L_0603EE34:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603EE34 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603EE36 extu.b r1,r1
    c.r[2] = c.r[1];  // 0603EE38 mov r1,r2
    c.r[2] += c.r[2];  // 0603EE3A add r2,r2
    c.r[2] += c.r[1];  // 0603EE3C add r1,r2
    c.r[2] <<= 2;  // 0603EE3E shll2 r2
    c.r[1] = ld32(0x0603EE84u);  // 0603EE40 mov.l 0x0603EE84,r1
    c.r[0] = c.r[2];  // 0603EE42 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603EE44 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603EE46 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603EE48 tst r1,r1
    if (!c.t) { goto L_0603EE52; }  // 0603EE4A bf 0x0603EE52
    c.r[8] += 3;  // 0603EE4C add #3,r8
    c.r[0] = c.r[8]; goto L_0603EE6C;  // 0603EE4E bra 0x0603EE6C ; mov r8,r0
L_0603EE52:
    c.r[1] = c.r[8];  // 0603EE52 mov r8,r1
    c.r[1] += 1;  // 0603EE54 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EE56 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603EE58 extu.b r2,r2
    c.r[1] = c.r[8];  // 0603EE5A mov r8,r1
    c.r[1] += 2;  // 0603EE5C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EE5E mov.b @r1,r1
    c.r[2] <<= 8;  // 0603EE60 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603EE62 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603EE64 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603EE66 exts.w r2,r0
    c.r[0] += 1;  // 0603EE68 add #1,r0
    c.r[0] += c.r[8];  // 0603EE6A add r8,r0
L_0603EE6C:
    c.r[15] = c.r[14];  // 0603EE6C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603EE6E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603EE70 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603EE72 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603EE74 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603EE76 rts ; mov.l @r15+,r8
}

void f_0603EEA8(SH2Context& c) {
    ran[996] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0603EEA8 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0603EEAA tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603EEAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603EEAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603EEB0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603EEB2 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0603EEB4 mov r5,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603EEB6 mov.b @r9,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603EEB8 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603EEBA tst r3,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603EF4C; } }  // 0603EEBC bt/s 0x0603EF4C ; mov r15,r14
    c.r[0] = c.r[3];  // 0603EEC0 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 0603EEC2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] = c.r[4]; if (k) { goto L_0603EF18; } }  // 0603EEC4 bf/s 0x0603EF18 ; mov r4,r6
    c.r[1] = ld32(0x0603EFA4u);  // 0603EEC8 mov.l 0x0603EFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0603EECA mov.l @r1,r1
    c.r[1] += 5;  // 0603EECC add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EECE mov.b @r1,r1
    c.r[2] = ld32(0x0603EFA8u);  // 0603EED0 mov.l 0x0603EFA8,r2
    c.r[2] = ld32(c.r[2]);  // 0603EED2 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603EED4 extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603EED6 dmulu.l r2,r1
    c.r[6] = c.mach;  // 0603EED8 sts mach,r6
    c.r[6] >>= 2;  // 0603EEDA shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0603EEDC shlr r6
    c.r[1] = c.r[6] & 0xFFu;  // 0603EEDE extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603EEE0 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603EEFE; } }  // 0603EEE2 bt/s 0x0603EEFE ; mov r9,r1
    c.r[7] = c.r[4];  // 0603EEE6 mov r4,r7
    c.r[7] += 56;  // 0603EEE8 add #56,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603EEEA mov.w @r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603EFA2u);  // 0603EEEC mov.w 0x0603EFA2,r1
    c.r[2] &= c.r[1];  // 0603EEEE and r1,r2
    c.r[1] = ld32(0x0603EFACu);  // 0603EEF0 mov.l 0x0603EFAC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603EEF2 mov.w @r1,r1
    c.r[3] = c.r[6] & 0xFFu;  // 0603EEF4 extu.b r6,r3
    c.r[1] += c.r[3];  // 0603EEF6 add r3,r1
    c.r[2] |= c.r[1];  // 0603EEF8 or r1,r2
    st16(c.r[7], c.r[2]); goto L_0603EF92;  // 0603EEFA bra 0x0603EF92 ; mov.w r2,@r7
L_0603EEFE:
    c.r[8] = ld32(0x0603EFB0u);  // 0603EEFE mov.l 0x0603EFB0,r8
    c.r[1] += 1;  // 0603EF00 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EF02 mov.b @r1,r0
    c.r[4] = c.r[3];  // 0603EF04 mov r3,r4
    c.r[1] = 0x1Fu;  // 0603EF06 mov #31,r1
    c.r[1] &= c.r[0];  // 0603EF08 and r0,r1
    c.r[0] = ld32(0x0603EFB4u);  // 0603EF0A mov.l 0x0603EFB4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603EF10u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EF10u) return; }  // 0603EF0C jsr @r0 ; mov r1,r5
    c.r[1] = ld32(c.r[8]);  // 0603EF10 mov.l @r8,r1
    c.r[1] |= c.r[0];  // 0603EF12 or r0,r1
    st32(c.r[8], c.r[1]); goto L_0603EF92;  // 0603EF14 bra 0x0603EF92 ; mov.l r1,@r8
L_0603EF18:
    c.r[6] += 56;  // 0603EF18 add #56,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603EF1A mov.w @r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603EFA2u);  // 0603EF1C mov.w 0x0603EFA2,r1
    c.r[7] &= c.r[1];  // 0603EF1E and r1,r7
    c.r[1] = ld32(0x0603EFA4u);  // 0603EF20 mov.l 0x0603EFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0603EF22 mov.l @r1,r1
    c.r[1] += 5;  // 0603EF24 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EF26 mov.b @r1,r2
    c.r[1] = ld32(0x0603EFA8u);  // 0603EF28 mov.l 0x0603EFA8,r1
    c.r[1] = ld32(c.r[1]);  // 0603EF2A mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603EF2C extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603EF2E dmulu.l r1,r2
    c.r[5] = ld32(0x0603EFACu);  // 0603EF30 mov.l 0x0603EFAC,r5
    c.r[1] = c.mach;  // 0603EF32 sts mach,r1
    c.r[1] >>= 2;  // 0603EF34 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603EF36 shlr r1
    c.r[3] = c.r[1];  // 0603EF38 mov r1,r3
    c.r[3] <<= 2;  // 0603EF3A shll2 r3
    c.r[3] += c.r[1];  // 0603EF3C add r1,r3
    c.r[3] += c.r[3];  // 0603EF3E add r3,r3
    c.r[2] -= c.r[3];  // 0603EF40 sub r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0603EF42 mov.w @r5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603EF44 extu.b r2,r2
    c.r[1] += c.r[2];  // 0603EF46 add r2,r1
    c.r[7] |= c.r[1]; goto L_0603EF90;  // 0603EF48 bra 0x0603EF90 ; or r1,r7
L_0603EF4C:
    c.r[6] = c.r[4];  // 0603EF4C mov r4,r6
    c.r[6] += 56;  // 0603EF4E add #56,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603EF50 mov.w @r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603EFA2u);  // 0603EF52 mov.w 0x0603EFA2,r1
    c.r[7] &= c.r[1];  // 0603EF54 and r1,r7
    c.r[1] = ld32(0x0603EFA4u);  // 0603EF56 mov.l 0x0603EFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0603EF58 mov.l @r1,r1
    c.r[1] += 6;  // 0603EF5A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EF5C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603EF5E extu.b r1,r0
    c.r[1] = ld32(0x0603EFB8u);  // 0603EF60 mov.l 0x0603EFB8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603EF62 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603EF64 extu.b r2,r2
    c.r[2] -= 1;  // 0603EF66 add #-1,r2
    c.r[1] = ld32(0x0603EFBCu);  // 0603EF68 mov.l 0x0603EFBC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603EF6A dmuls.l r1,r2
    c.r[5] = ld32(0x0603EFACu);  // 0603EF6C mov.l 0x0603EFAC,r5
    c.r[3] = c.mach;  // 0603EF6E sts mach,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603EF70 shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603EF72 shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603EF74 shar r3
    c.r[1] = c.r[2];  // 0603EF76 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0603EF78 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0603EF7A subc r1,r1
    c.r[3] -= c.r[1];  // 0603EF7C sub r1,r3
    c.r[1] = c.r[3];  // 0603EF7E mov r3,r1
    c.r[1] <<= 2;  // 0603EF80 shll2 r1
    c.r[1] += c.r[3];  // 0603EF82 add r3,r1
    c.r[1] <<= 2;  // 0603EF84 shll2 r1
    c.r[2] -= c.r[1];  // 0603EF86 sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0603EF88 mov.w @r5,r1
    c.r[2] += 12;  // 0603EF8A add #12,r2
    c.r[2] += c.r[1];  // 0603EF8C add r1,r2
    c.r[7] |= c.r[2];  // 0603EF8E or r2,r7
L_0603EF90:
    st16(c.r[6], c.r[7]);  // 0603EF90 mov.w r7,@r6
L_0603EF92:
    c.r[15] = c.r[14];  // 0603EF92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603EF94 lds.l @r15+,pr
    c.r[9] += 2;  // 0603EF96 add #2,r9
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603EF98 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603EF9A mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603EF9C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603EF9E rts ; mov.l @r15+,r8
}

void f_0603EEAC(SH2Context& c) {
    ran[997] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603EEAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603EEAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603EEB0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603EEB2 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0603EEB4 mov r5,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603EEB6 mov.b @r9,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603EEB8 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603EEBA tst r3,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603EF4C; } }  // 0603EEBC bt/s 0x0603EF4C ; mov r15,r14
    c.r[0] = c.r[3];  // 0603EEC0 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 0603EEC2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] = c.r[4]; if (k) { goto L_0603EF18; } }  // 0603EEC4 bf/s 0x0603EF18 ; mov r4,r6
    c.r[1] = ld32(0x0603EFA4u);  // 0603EEC8 mov.l 0x0603EFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0603EECA mov.l @r1,r1
    c.r[1] += 5;  // 0603EECC add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EECE mov.b @r1,r1
    c.r[2] = ld32(0x0603EFA8u);  // 0603EED0 mov.l 0x0603EFA8,r2
    c.r[2] = ld32(c.r[2]);  // 0603EED2 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603EED4 extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603EED6 dmulu.l r2,r1
    c.r[6] = c.mach;  // 0603EED8 sts mach,r6
    c.r[6] >>= 2;  // 0603EEDA shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0603EEDC shlr r6
    c.r[1] = c.r[6] & 0xFFu;  // 0603EEDE extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603EEE0 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603EEFE; } }  // 0603EEE2 bt/s 0x0603EEFE ; mov r9,r1
    c.r[7] = c.r[4];  // 0603EEE6 mov r4,r7
    c.r[7] += 56;  // 0603EEE8 add #56,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603EEEA mov.w @r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603EFA2u);  // 0603EEEC mov.w 0x0603EFA2,r1
    c.r[2] &= c.r[1];  // 0603EEEE and r1,r2
    c.r[1] = ld32(0x0603EFACu);  // 0603EEF0 mov.l 0x0603EFAC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603EEF2 mov.w @r1,r1
    c.r[3] = c.r[6] & 0xFFu;  // 0603EEF4 extu.b r6,r3
    c.r[1] += c.r[3];  // 0603EEF6 add r3,r1
    c.r[2] |= c.r[1];  // 0603EEF8 or r1,r2
    st16(c.r[7], c.r[2]); goto L_0603EF92;  // 0603EEFA bra 0x0603EF92 ; mov.w r2,@r7
L_0603EEFE:
    c.r[8] = ld32(0x0603EFB0u);  // 0603EEFE mov.l 0x0603EFB0,r8
    c.r[1] += 1;  // 0603EF00 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EF02 mov.b @r1,r0
    c.r[4] = c.r[3];  // 0603EF04 mov r3,r4
    c.r[1] = 0x1Fu;  // 0603EF06 mov #31,r1
    c.r[1] &= c.r[0];  // 0603EF08 and r0,r1
    c.r[0] = ld32(0x0603EFB4u);  // 0603EF0A mov.l 0x0603EFB4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603EF10u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EF10u) return; }  // 0603EF0C jsr @r0 ; mov r1,r5
    c.r[1] = ld32(c.r[8]);  // 0603EF10 mov.l @r8,r1
    c.r[1] |= c.r[0];  // 0603EF12 or r0,r1
    st32(c.r[8], c.r[1]); goto L_0603EF92;  // 0603EF14 bra 0x0603EF92 ; mov.l r1,@r8
L_0603EF18:
    c.r[6] += 56;  // 0603EF18 add #56,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603EF1A mov.w @r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603EFA2u);  // 0603EF1C mov.w 0x0603EFA2,r1
    c.r[7] &= c.r[1];  // 0603EF1E and r1,r7
    c.r[1] = ld32(0x0603EFA4u);  // 0603EF20 mov.l 0x0603EFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0603EF22 mov.l @r1,r1
    c.r[1] += 5;  // 0603EF24 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EF26 mov.b @r1,r2
    c.r[1] = ld32(0x0603EFA8u);  // 0603EF28 mov.l 0x0603EFA8,r1
    c.r[1] = ld32(c.r[1]);  // 0603EF2A mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603EF2C extu.b r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603EF2E dmulu.l r1,r2
    c.r[5] = ld32(0x0603EFACu);  // 0603EF30 mov.l 0x0603EFAC,r5
    c.r[1] = c.mach;  // 0603EF32 sts mach,r1
    c.r[1] >>= 2;  // 0603EF34 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603EF36 shlr r1
    c.r[3] = c.r[1];  // 0603EF38 mov r1,r3
    c.r[3] <<= 2;  // 0603EF3A shll2 r3
    c.r[3] += c.r[1];  // 0603EF3C add r1,r3
    c.r[3] += c.r[3];  // 0603EF3E add r3,r3
    c.r[2] -= c.r[3];  // 0603EF40 sub r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0603EF42 mov.w @r5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603EF44 extu.b r2,r2
    c.r[1] += c.r[2];  // 0603EF46 add r2,r1
    c.r[7] |= c.r[1]; goto L_0603EF90;  // 0603EF48 bra 0x0603EF90 ; or r1,r7
L_0603EF4C:
    c.r[6] = c.r[4];  // 0603EF4C mov r4,r6
    c.r[6] += 56;  // 0603EF4E add #56,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603EF50 mov.w @r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603EFA2u);  // 0603EF52 mov.w 0x0603EFA2,r1
    c.r[7] &= c.r[1];  // 0603EF54 and r1,r7
    c.r[1] = ld32(0x0603EFA4u);  // 0603EF56 mov.l 0x0603EFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0603EF58 mov.l @r1,r1
    c.r[1] += 6;  // 0603EF5A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603EF5C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603EF5E extu.b r1,r0
    c.r[1] = ld32(0x0603EFB8u);  // 0603EF60 mov.l 0x0603EFB8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603EF62 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603EF64 extu.b r2,r2
    c.r[2] -= 1;  // 0603EF66 add #-1,r2
    c.r[1] = ld32(0x0603EFBCu);  // 0603EF68 mov.l 0x0603EFBC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603EF6A dmuls.l r1,r2
    c.r[5] = ld32(0x0603EFACu);  // 0603EF6C mov.l 0x0603EFAC,r5
    c.r[3] = c.mach;  // 0603EF6E sts mach,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603EF70 shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603EF72 shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0603EF74 shar r3
    c.r[1] = c.r[2];  // 0603EF76 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0603EF78 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0603EF7A subc r1,r1
    c.r[3] -= c.r[1];  // 0603EF7C sub r1,r3
    c.r[1] = c.r[3];  // 0603EF7E mov r3,r1
    c.r[1] <<= 2;  // 0603EF80 shll2 r1
    c.r[1] += c.r[3];  // 0603EF82 add r3,r1
    c.r[1] <<= 2;  // 0603EF84 shll2 r1
    c.r[2] -= c.r[1];  // 0603EF86 sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0603EF88 mov.w @r5,r1
    c.r[2] += 12;  // 0603EF8A add #12,r2
    c.r[2] += c.r[1];  // 0603EF8C add r1,r2
    c.r[7] |= c.r[2];  // 0603EF8E or r2,r7
L_0603EF90:
    st16(c.r[6], c.r[7]);  // 0603EF90 mov.w r7,@r6
L_0603EF92:
    c.r[15] = c.r[14];  // 0603EF92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603EF94 lds.l @r15+,pr
    c.r[9] += 2;  // 0603EF96 add #2,r9
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603EF98 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603EF9A mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603EF9C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603EF9E rts ; mov.l @r15+,r8
}

void f_0603EFC8(SH2Context& c) {
    ran[998] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603EFC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603EFCA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603EFCC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603EFCE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603EFD0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603EFD2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603EFD4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603EFD6 sts.l pr,@-r15
    c.r[15] -= 4;  // 0603EFD8 add #-4,r15
    c.r[14] = c.r[15];  // 0603EFDA mov r15,r14
    c.r[13] = c.r[4];  // 0603EFDC mov r4,r13
    st32(c.r[14], c.r[5]);  // 0603EFDE mov.l r5,@r14
    c.r[1] = ld32(0x0603F08Cu);  // 0603EFE0 mov.l 0x0603F08C,r1
    c.r[5] = c.r[13];  // 0603EFE2 mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603EFE8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603EFE8u) return; }  // 0603EFE4 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(c.r[14]);  // 0603EFE8 mov.l @r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603EFEA mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603EFEC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603EFEE tst r1,r1
    { const bool k = c.t; c.r[2] = 0x9u; if (k) { goto L_0603F050; } }  // 0603EFF0 bt/s 0x0603F050 ; mov #9,r2
    c.r[1] = ld32(0x0603F090u);  // 0603EFF4 mov.l 0x0603F090,r1
    c.r[11] = ld32(c.r[1]);  // 0603EFF6 mov.l @r1,r11
    c.r[11] += 6;  // 0603EFF8 add #6,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603EFFA mov.b @r11,r1
    c.r[12] = ld32(0x0603F094u);  // 0603EFFC mov.l 0x0603F094,r12
    c.r[0] = c.r[1] & 0xFFu;  // 0603EFFE extu.b r1,r0
    c.r[0] += c.r[0];  // 0603F000 add r0,r0
    c.r[2] = ld32(0x0603F098u);  // 0603F002 mov.l 0x0603F098,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F008u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F008u) return; }  // 0603F004 jsr @r2 ; mov.b @(r0,r12),r4
    c.r[4] = c.r[0];  // 0603F008 mov r0,r4
    c.r[5] = c.r[1];  // 0603F00A mov r1,r5
    c.r[1] = ld32(0x0603F09Cu);  // 0603F00C mov.l 0x0603F09C,r1
    c.r[8] = ld32(c.r[1]);  // 0603F00E mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603F010 mov.l @(4,r1),r9
    c.r[2] = ld32(0x0603F0A0u);  // 0603F012 mov.l 0x0603F0A0,r2
    c.r[6] = c.r[8];  // 0603F014 mov r8,r6
    { const uint32_t x = c.r[2]; c.pr = 0x0603F01Au; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F01Au) return; }  // 0603F016 jsr @r2 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603F01A mov r0,r4
    c.r[10] = ld32(0x0603F0A4u);  // 0603F01C mov.l 0x0603F0A4,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0603F022u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F022u) return; }  // 0603F01E jsr @r10 ; mov r1,r5
    c.r[1] = ld32(c.r[13] + 4);  // 0603F022 mov.l @(4,r13),r1
    c.r[1] += c.r[0];  // 0603F024 add r0,r1
    st32(c.r[13] + 4, c.r[1]);  // 0603F026 mov.l r1,@(4,r13)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603F028 mov.b @r11,r1
    c.r[12] += 1;  // 0603F02A add #1,r12
    c.r[0] = c.r[1] & 0xFFu;  // 0603F02C extu.b r1,r0
    c.r[0] += c.r[0];  // 0603F02E add r0,r0
    c.r[2] = ld32(0x0603F098u);  // 0603F030 mov.l 0x0603F098,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F036u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F036u) return; }  // 0603F032 jsr @r2 ; mov.b @(r0,r12),r4
    c.r[4] = c.r[0];  // 0603F036 mov r0,r4
    c.r[5] = c.r[1];  // 0603F038 mov r1,r5
    c.r[6] = c.r[8];  // 0603F03A mov r8,r6
    c.r[2] = ld32(0x0603F0A0u);  // 0603F03C mov.l 0x0603F0A0,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F042u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F042u) return; }  // 0603F03E jsr @r2 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603F042 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0603F048u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F048u) return; }  // 0603F044 jsr @r10 ; mov r1,r5
    c.r[1] = ld32(c.r[13] + 8);  // 0603F048 mov.l @(8,r13),r1
    c.r[1] += c.r[0];  // 0603F04A add r0,r1
    st32(c.r[13] + 8, c.r[1]); goto L_0603F066;  // 0603F04C bra 0x0603F066 ; mov.l r1,@(8,r13)
L_0603F050:
    c.r[1] = ld32(0x0603F090u);  // 0603F050 mov.l 0x0603F090,r1
    c.r[1] = ld32(c.r[1]);  // 0603F052 mov.l @r1,r1
    c.r[1] += 5;  // 0603F054 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F056 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603F058 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0603F05A cmp/hi r2,r1
    { const bool k = c.t; c.r[3] = ld32(c.r[13] + 4); if (k) { goto L_0603F064; } }  // 0603F05C bt/s 0x0603F064 ; mov.l @(4,r13),r3
    c.r[1] = ld32(0x0603F0A8u);  // 0603F060 mov.l 0x0603F0A8,r1
    c.r[3] += c.r[1];  // 0603F062 add r1,r3
L_0603F064:
    st32(c.r[13] + 4, c.r[3]);  // 0603F064 mov.l r3,@(4,r13)
L_0603F066:
    c.r[1] = ld32(0x0603F08Cu);  // 0603F066 mov.l 0x0603F08C,r1
    c.r[5] = c.r[13];  // 0603F068 mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603F06Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F06Eu) return; }  // 0603F06A jsr @r1 ; mov #1,r4
    c.r[2] = ld32(c.r[14]);  // 0603F06E mov.l @r14,r2
    c.r[2] += 1;  // 0603F070 add #1,r2
    st32(c.r[14], c.r[2]);  // 0603F072 mov.l r2,@r14
    c.r[0] = ld32(c.r[14]); c.r[14] += 4;  // 0603F074 mov.l @r14+,r0
    c.r[15] = c.r[14];  // 0603F076 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F078 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F07A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603F07C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603F07E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603F080 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603F082 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603F084 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F086 rts ; mov.l @r15+,r8
}

void f_0603F0AC(SH2Context& c) {
    ran[999] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F0AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F0AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F0B0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603F0B2 mov r15,r14
    c.r[8] = c.r[5];  // 0603F0B4 mov r5,r8
    c.r[1] = ld32(0x0603F0D0u);  // 0603F0B6 mov.l 0x0603F0D0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0603F0B8 mov.b @r8+,r0
    c.r[4] = 0x0u;  // 0603F0BA mov #0,r4
    c.r[0] &= 0x7u;  // 0603F0BC and #7,r0
    { const uint32_t x = c.r[1]; c.pr = 0x0603F0C2u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F0C2u) return; }  // 0603F0BE jsr @r1 ; mov r0,r5
    c.r[15] = c.r[14];  // 0603F0C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F0C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F0C6 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603F0C8 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F0CA rts ; mov.l @r15+,r8
}

void f_0603F0DC(SH2Context& c) {
    ran[1000] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F0DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603F0DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603F0E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603F0E2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603F0E4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603F0E6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F0E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F0EA sts.l pr,@-r15
    c.r[15] -= 12;  // 0603F0EC add #-12,r15
    c.r[14] = c.r[15];  // 0603F0EE mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603F0F0 mov.l r5,@r14
    c.r[0] = 0x0u;  // 0603F0F2 mov #0,r0
    st32(c.r[14] + 4, c.r[0]);  // 0603F0F4 mov.l r0,@(4,r14)
    c.r[6] = ld32(0x0603F1E0u);  // 0603F0F6 mov.l 0x0603F1E0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0603F0F8 mov.b @r6,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603F1DAu);  // 0603F0FA mov.w 0x0603F1DA,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603F0FC extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 0603F0FE mul.l r7,r1
    c.r[13] = ld32(0x0603F1E4u);  // 0603F100 mov.l 0x0603F1E4,r13
    c.r[3] = ld32(c.r[13]);  // 0603F102 mov.l @r13,r3
    c.r[2] = c.macl;  // 0603F104 sts macl,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F1DCu);  // 0603F106 mov.w 0x0603F1DC,r1
    c.r[2] += c.r[3]; goto L_0603F1AE;  // 0603F108 bra 0x0603F1AE ; add r3,r2
L_0603F10C:
    c.r[0] = ld32(0x0603F1E0u);  // 0603F10C mov.l 0x0603F1E0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603F10E mov.b @r0,r1
    c.r[0] = ld32(0x0603F1E4u);  // 0603F110 mov.l 0x0603F1E4,r0
    c.r[0] = ld32(c.r[0]);  // 0603F112 mov.l @r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0603F114 extu.b r1,r1
    st32(c.r[14] + 8, c.r[0]);  // 0603F116 mov.l r0,@(8,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603F1DAu);  // 0603F118 mov.w 0x0603F1DA,r0
    c.macl = c.r[1] * c.r[0];  // 0603F11A mul.l r0,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]); c.r[13] += 1;  // 0603F11C mov.b @r13+,r4
    c.r[0] = ld32(c.r[14] + 8);  // 0603F11E mov.l @(8,r14),r0
    c.r[2] = c.macl;  // 0603F120 sts macl,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0603F122 mov.l @(4,r14),r1
    c.r[2] += c.r[0];  // 0603F124 add r0,r2
    c.r[1] <<= 2;  // 0603F126 shll2 r1
    c.r[1] += c.r[1];  // 0603F128 add r1,r1
    c.r[2] += c.r[1];  // 0603F12A add r1,r2
    c.r[2] += 4;  // 0603F12C add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603F12E mov.b @r2,r1
    c.r[0] = ld32(0x0603F1E8u);  // 0603F130 mov.l 0x0603F1E8,r0
    c.r[10] = ld32(c.r[0] + 12);  // 0603F132 mov.l @(12,r0),r10
    c.r[1] = c.r[1] & 0xFFu;  // 0603F134 extu.b r1,r1
    c.r[2] = ld32(0x0603F1ECu);  // 0603F136 mov.l 0x0603F1EC,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603F138 mov.w @r2,r2
    c.r[0] = ld32(0x0603F1F0u);  // 0603F13A mov.l 0x0603F1F0,r0
    c.r[1] += c.r[2];  // 0603F13C add r2,r1
    c.r[1] += 1;  // 0603F13E add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F140 extu.w r1,r1
    c.r[12] = c.r[1];  // 0603F142 mov r1,r12
    c.r[12] += c.r[12];  // 0603F144 add r12,r12
    c.r[12] += c.r[1];  // 0603F146 add r1,r12
    { const uint32_t x = c.r[0]; c.pr = 0x0603F14Cu; c.r[12] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F14Cu) return; }  // 0603F148 jsr @r0 ; shll2 r12
    c.r[4] = c.r[0];  // 0603F14C mov r0,r4
    c.r[5] = c.r[1];  // 0603F14E mov r1,r5
    c.r[1] = ld32(0x0603F1F4u);  // 0603F150 mov.l 0x0603F1F4,r1
    c.r[8] = ld32(c.r[1]);  // 0603F152 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603F154 mov.l @(4,r1),r9
    c.r[0] = ld32(0x0603F1F8u);  // 0603F156 mov.l 0x0603F1F8,r0
    c.r[6] = c.r[8];  // 0603F158 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603F15Eu; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F15Eu) return; }  // 0603F15A jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603F15E mov r0,r4
    c.r[11] = ld32(0x0603F1FCu);  // 0603F160 mov.l 0x0603F1FC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603F166u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F166u) return; }  // 0603F162 jsr @r11 ; mov r1,r5
    c.r[2] = c.r[0];  // 0603F166 mov r0,r2
    c.r[0] = c.r[12];  // 0603F168 mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0603F16A mov.l @(r0,r10),r1
    c.r[1] -= c.r[2];  // 0603F16C sub r2,r1
    st32(c.r[0] + c.r[10], c.r[1]);  // 0603F16E mov.l r1,@(r0,r10)
    c.r[0] = ld32(0x0603F1E8u);  // 0603F170 mov.l 0x0603F1E8,r0
    c.r[10] = ld32(c.r[0] + 12);  // 0603F172 mov.l @(12,r0),r10
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603F174 mov.b @r13,r4
    c.r[0] = ld32(0x0603F1F0u);  // 0603F176 mov.l 0x0603F1F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603F17Cu; c.r[10] += c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F17Cu) return; }  // 0603F178 jsr @r0 ; add r12,r10
    c.r[4] = c.r[0];  // 0603F17C mov r0,r4
    c.r[5] = c.r[1];  // 0603F17E mov r1,r5
    c.r[6] = c.r[8];  // 0603F180 mov r8,r6
    c.r[0] = ld32(0x0603F1F8u);  // 0603F182 mov.l 0x0603F1F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603F188u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F188u) return; }  // 0603F184 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603F188 mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0603F18Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F18Eu) return; }  // 0603F18A jsr @r11 ; mov r1,r5
    c.r[1] = ld32(c.r[10] + 4);  // 0603F18E mov.l @(4,r10),r1
    c.r[2] = c.r[0];  // 0603F190 mov r0,r2
    c.r[0] = ld32(c.r[14] + 4);  // 0603F192 mov.l @(4,r14),r0
    c.r[1] -= c.r[2];  // 0603F194 sub r2,r1
    st32(c.r[10] + 4, c.r[1]);  // 0603F196 mov.l r1,@(4,r10)
    c.r[0] += 1;  // 0603F198 add #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 0603F19A mov.l r0,@(4,r14)
    c.r[0] = ld32(0x0603F1E0u);  // 0603F19C mov.l 0x0603F1E0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603F19E mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603F1A0 extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603F1DAu);  // 0603F1A2 mov.w 0x0603F1DA,r0
    c.macl = c.r[1] * c.r[0];  // 0603F1A4 mul.l r0,r1
    c.r[2] = c.macl;  // 0603F1A6 sts macl,r2
    c.r[0] = ld32(c.r[14] + 8);  // 0603F1A8 mov.l @(8,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F1DCu);  // 0603F1AA mov.w 0x0603F1DC,r1
    c.r[2] += c.r[0];  // 0603F1AC add r0,r2
L_0603F1AE:
    c.r[0] = c.r[2];  // 0603F1AE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603F1B0 mov.b @(r0,r1),r1
    c.r[0] = ld32(c.r[14] + 4);  // 0603F1B2 mov.l @(4,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 0603F1B4 extu.b r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 0603F1B6 cmp/ge r1,r0
    { const bool k = !c.t; c.r[13] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_0603F10C; } }  // 0603F1B8 bf/s 0x0603F10C ; mov.l @r14,r13
    c.r[0] = ld32(c.r[14]);  // 0603F1BC mov.l @r14,r0
    c.r[0] += 2;  // 0603F1BE add #2,r0
    st32(c.r[14], c.r[0]);  // 0603F1C0 mov.l r0,@r14
    c.r[0] = ld32(c.r[14]);  // 0603F1C2 mov.l @r14,r0
    c.r[14] += 12;  // 0603F1C4 add #12,r14
    c.r[15] = c.r[14];  // 0603F1C6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F1C8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F1CA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603F1CC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603F1CE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603F1D0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603F1D2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603F1D4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F1D6 rts ; mov.l @r15+,r8
}

void f_0603F200(SH2Context& c) {
    ran[1001] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F200 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F202 sts.l pr,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0603F204 extu.b r4,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0603F206 tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603F250; } }  // 0603F208 bt/s 0x0603F250 ; mov r15,r14
    c.r[1] = c.r[5];  // 0603F20C mov r5,r1
    c.r[1] += 1;  // 0603F20E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F210 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603F212 mov r1,r0
    c.r[0] >>= 2;  // 0603F214 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603F216 shlr r0
    c.r[0] &= 0x1u;  // 0603F218 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F21A tst r0,r0
    if (c.t) { goto L_0603F236; }  // 0603F21C bt 0x0603F236
    c.r[4] = ld32(c.r[5] + 4);  // 0603F21E mov.l @(4,r5),r4
    c.r[1] = ld32(0x0603F29Cu);  // 0603F220 mov.l 0x0603F29C,r1
    c.r[2] = ld32(0x0603F2A0u);  // 0603F222 mov.l 0x0603F2A0,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F228u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F228u) return; }  // 0603F224 jsr @r2 ; add r1,r4
    st32(c.r[5] + 4, c.r[4]);  // 0603F228 mov.l r4,@(4,r5)
    c.r[4] = ld32(c.r[5] + 8);  // 0603F22A mov.l @(8,r5),r4
    c.r[1] = ld32(0x0603F2A4u);  // 0603F22C mov.l 0x0603F2A4,r1
    { const uint32_t x = c.r[2]; c.pr = 0x0603F232u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F232u) return; }  // 0603F22E jsr @r2 ; add r1,r4
    st32(c.r[5] + 8, c.r[4]); goto L_0603F292;  // 0603F232 bra 0x0603F292 ; mov.l r4,@(8,r5)
L_0603F236:
    c.r[1] = ld32(c.r[5] + 4);  // 0603F236 mov.l @(4,r5),r1
    c.r[2] = ld32(0x0603F29Cu);  // 0603F238 mov.l 0x0603F29C,r2
    c.r[1] += c.r[2];  // 0603F23A add r2,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0603F23C swap.w r1,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603F23E exts.w r1,r1
    st32(c.r[5] + 4, c.r[1]);  // 0603F240 mov.l r1,@(4,r5)
    c.r[1] = ld32(c.r[5] + 8);  // 0603F242 mov.l @(8,r5),r1
    c.r[2] = ld32(0x0603F2A4u);  // 0603F244 mov.l 0x0603F2A4,r2
    c.r[1] += c.r[2];  // 0603F246 add r2,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0603F248 swap.w r1,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603F24A exts.w r1,r1
    st32(c.r[5] + 8, c.r[1]); goto L_0603F292;  // 0603F24C bra 0x0603F292 ; mov.l r1,@(8,r5)
L_0603F250:
    c.r[1] = c.r[5];  // 0603F250 mov r5,r1
    c.r[1] += 1;  // 0603F252 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F254 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603F256 mov r1,r0
    c.r[0] >>= 2;  // 0603F258 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603F25A shlr r0
    c.r[0] &= 0x1u;  // 0603F25C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F25E tst r0,r0
    { const bool k = c.t; c.r[2] = ld32(c.r[5] + 4); if (k) { goto L_0603F280; } }  // 0603F260 bt/s 0x0603F280 ; mov.l @(4,r5),r2
    c.r[1] = ld32(0x0603F2A8u);  // 0603F264 mov.l 0x0603F2A8,r1
    c.r[2] <<= 8;  // 0603F266 shll8 r2
    c.r[2] <<= 2;  // 0603F268 shll2 r2
    c.r[2] += c.r[2];  // 0603F26A add r2,r2
    c.r[2] <<= 2;  // 0603F26C shll2 r2
    c.r[2] += c.r[1];  // 0603F26E add r1,r2
    st32(c.r[5] + 4, c.r[2]);  // 0603F270 mov.l r2,@(4,r5)
    c.r[2] = ld32(c.r[5] + 8);  // 0603F272 mov.l @(8,r5),r2
    c.r[1] = ld32(0x0603F2ACu);  // 0603F274 mov.l 0x0603F2AC,r1
    c.r[2] <<= 8;  // 0603F276 shll8 r2
    c.r[2] <<= 2;  // 0603F278 shll2 r2
    c.r[2] += c.r[2];  // 0603F27A add r2,r2
    c.r[2] <<= 2; goto L_0603F28E;  // 0603F27C bra 0x0603F28E ; shll2 r2
L_0603F280:
    c.r[1] = ld32(0x0603F2A8u);  // 0603F280 mov.l 0x0603F2A8,r1
    c.r[2] <<= 16;  // 0603F282 shll16 r2
    c.r[2] += c.r[1];  // 0603F284 add r1,r2
    st32(c.r[5] + 4, c.r[2]);  // 0603F286 mov.l r2,@(4,r5)
    c.r[2] = ld32(c.r[5] + 8);  // 0603F288 mov.l @(8,r5),r2
    c.r[1] = ld32(0x0603F2ACu);  // 0603F28A mov.l 0x0603F2AC,r1
    c.r[2] <<= 16;  // 0603F28C shll16 r2
L_0603F28E:
    c.r[2] += c.r[1];  // 0603F28E add r1,r2
    st32(c.r[5] + 8, c.r[2]);  // 0603F290 mov.l r2,@(8,r5)
L_0603F292:
    c.r[15] = c.r[14];  // 0603F292 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F294 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F296 rts ; mov.l @r15+,r14
}

void f_0603F2B0(SH2Context& c) {
    ran[1002] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F2B0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F2B2 mov r15,r14
    c.r[1] = c.r[4];  // 0603F2B4 mov r4,r1
    c.r[1] += 1;  // 0603F2B6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F2B8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603F2BA mov r1,r0
    c.r[0] >>= 2;  // 0603F2BC shlr2 r0
    c.r[0] >>= 2;  // 0603F2BE shlr2 r0
    c.r[0] &= 0x1u;  // 0603F2C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F2C2 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[4]; if (k) { goto L_0603F2FE; } }  // 0603F2C4 bt/s 0x0603F2FE ; mov r4,r3
    c.r[1] = ld32(0x0603F304u);  // 0603F2C8 mov.l 0x0603F304,r1
    c.r[6] = 0x4Cu;  // 0603F2CA mov #76,r6
    c.r[7] = ld32(c.r[1]);  // 0603F2CC mov.l @r1,r7
    c.r[4] += 65;  // 0603F2CE add #65,r4
L_0603F2D0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603F2D0 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603F2D2 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 0603F2D4 mul.l r6,r1
    c.r[2] = ld32(c.r[3] + 4);  // 0603F2D6 mov.l @(4,r3),r2
    c.r[4] = c.macl;  // 0603F2D8 sts macl,r4
    c.r[4] += c.r[7];  // 0603F2DA add r7,r4
    c.r[1] = ld32(c.r[4] + 4);  // 0603F2DC mov.l @(4,r4),r1
    c.r[2] += c.r[1];  // 0603F2DE add r1,r2
    st32(c.r[3] + 4, c.r[2]);  // 0603F2E0 mov.l r2,@(4,r3)
    c.r[2] = ld32(c.r[3] + 8);  // 0603F2E2 mov.l @(8,r3),r2
    c.r[1] = ld32(c.r[4] + 8);  // 0603F2E4 mov.l @(8,r4),r1
    c.r[2] += c.r[1];  // 0603F2E6 add r1,r2
    st32(c.r[3] + 8, c.r[2]);  // 0603F2E8 mov.l r2,@(8,r3)
    c.r[1] = c.r[4];  // 0603F2EA mov r4,r1
    c.r[1] += 1;  // 0603F2EC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F2EE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603F2F0 mov r1,r0
    c.r[0] >>= 2;  // 0603F2F2 shlr2 r0
    c.r[0] >>= 2;  // 0603F2F4 shlr2 r0
    c.r[0] &= 0x1u;  // 0603F2F6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F2F8 tst r0,r0
    { const bool k = !c.t; c.r[4] += 65; if (k) { SH2_POLL(c); goto L_0603F2D0; } }  // 0603F2FA bf/s 0x0603F2D0 ; add #65,r4
L_0603F2FE:
    c.r[15] = c.r[14];  // 0603F2FE mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F300 rts ; mov.l @r15+,r14
}

void f_0603F308(SH2Context& c) {
    ran[1003] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F308 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F30A mov r15,r14
    c.r[1] = ld32(0x0603F364u);  // 0603F30C mov.l 0x0603F364,r1
    c.r[2] = ld32(0x0603F368u);  // 0603F30E mov.l 0x0603F368,r2
    c.r[6] = c.r[4];  // 0603F310 mov r4,r6
    c.r[6] += 72;  // 0603F312 add #72,r6
    c.r[3] = ld32(0x0603F36Cu);  // 0603F314 mov.l 0x0603F36C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F316 mov.b @r1,r1
    c.r[4] += 56;  // 0603F318 add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603F31A mov.w @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603F31C extu.b r1,r1
    c.r[1] += c.r[2];  // 0603F31E add r2,r1
    c.r[1] += 1;  // 0603F320 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F322 extu.w r1,r1
    c.r[7] = c.r[1];  // 0603F324 mov r1,r7
    c.r[7] <<= 2;  // 0603F326 shll2 r7
    c.r[7] += c.r[1];  // 0603F328 add r1,r7
    c.r[2] = ld32(c.r[3] + 8);  // 0603F32A mov.l @(8,r3),r2
    c.r[7] += c.r[7];  // 0603F32C add r7,r7
    c.r[2] += c.r[7];  // 0603F32E add r7,r2
    c.r[2] += 4;  // 0603F330 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603F332 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F334 extu.w r1,r1
    c.r[1] >>= 2;  // 0603F336 shlr2 r1
    c.r[1] >>= 2;  // 0603F338 shlr2 r1
    st16(c.r[6], c.r[1]);  // 0603F33A mov.w r1,@r6
    c.r[1] = ld32(c.r[3] + 8);  // 0603F33C mov.l @(8,r3),r1
    c.r[0] = c.r[7];  // 0603F33E mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603F340 mov.w @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603F362u);  // 0603F342 mov.w 0x0603F362,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F344 extu.w r1,r1
    c.r[2] += c.r[1];  // 0603F346 add r1,r2
    st16(c.r[4], c.r[2]);  // 0603F348 mov.w r2,@r4
    c.r[1] <<= 2;  // 0603F34A shll2 r1
    c.r[2] = 0x8u;  // 0603F34C mov #8,r2
    c.r[7] = ld32(c.r[3] + 16);  // 0603F34E mov.l @(16,r3),r7
    c.r[0] = c.r[1];  // 0603F350 mov r1,r0
    c.r[3] = c.r[1];  // 0603F352 mov r1,r3
    c.r[3] += c.r[7];  // 0603F354 add r7,r3
    c.r[3] += 2;  // 0603F356 add #2,r3
    st16(c.r[3], c.r[2]);  // 0603F358 mov.w r2,@r3
    st16(c.r[0] + c.r[7], c.r[2]);  // 0603F35A mov.w r2,@(r0,r7)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F35C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603F35E rts ; mov r5,r0
}

void f_0603F370(SH2Context& c) {
    ran[1004] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F370 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F372 mov r15,r14
    c.r[3] = c.r[5];  // 0603F374 mov r5,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603F376 mov.b @r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F3CCu);  // 0603F378 mov.w 0x0603F3CC,r1
    c.r[6] = 0x7Fu;  // 0603F37A mov #127,r6
    c.r[1] &= c.r[0];  // 0603F37C and r0,r1
    c.r[2] = c.r[1];  // 0603F37E mov r1,r2
    c.r[6] &= c.r[0];  // 0603F380 and r0,r6
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603F382 tst r2,r2
    { const bool k = c.t; c.r[7] = c.r[6]; if (k) { goto L_0603F398; } }  // 0603F384 bt/s 0x0603F398 ; mov r6,r7
    c.r[6] += c.r[6];  // 0603F388 add r6,r6
    c.r[1] = ld32(0x0603F3D0u);  // 0603F38A mov.l 0x0603F3D0,r1
    c.r[0] = c.r[6];  // 0603F38C mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603F38E mov.w @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F390 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0603F3A8; } }  // 0603F392 bf/s 0x0603F3A8 ; mov r3,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603F396 tst r2,r2
L_0603F398:
    { const bool k = !c.t; c.r[7] += c.r[7]; if (k) { goto L_0603F3C2; } }  // 0603F398 bf/s 0x0603F3C2 ; add r7,r7
    c.r[1] = ld32(0x0603F3D0u);  // 0603F39C mov.l 0x0603F3D0,r1
    c.r[0] = c.r[7];  // 0603F39E mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603F3A0 mov.w @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F3A2 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0603F3C2; } }  // 0603F3A4 bf/s 0x0603F3C2 ; mov r3,r1
L_0603F3A8:
    c.r[1] += 1;  // 0603F3A8 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F3AA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603F3AC extu.b r2,r2
    c.r[1] = c.r[3];  // 0603F3AE mov r3,r1
    c.r[1] += 2;  // 0603F3B0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F3B2 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603F3B4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603F3B6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603F3B8 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603F3BA exts.w r2,r0
    c.r[0] += 1;  // 0603F3BC add #1,r0
    c.r[0] += c.r[3]; goto L_0603F3C6;  // 0603F3BE bra 0x0603F3C6 ; add r3,r0
L_0603F3C2:
    c.r[3] += 3;  // 0603F3C2 add #3,r3
    c.r[0] = c.r[3];  // 0603F3C4 mov r3,r0
L_0603F3C6:
    c.r[15] = c.r[14];  // 0603F3C6 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F3C8 rts ; mov.l @r15+,r14
}

void f_0603F3D4(SH2Context& c) {
    ran[1005] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F3D4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F3D6 mov r15,r14
    c.r[2] = c.r[5];  // 0603F3D8 mov r5,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603F3DA mov.b @r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F41Cu);  // 0603F3DC mov.w 0x0603F41C,r1
    c.r[6] = 0x7Fu;  // 0603F3DE mov #127,r6
    c.r[1] &= c.r[0];  // 0603F3E0 and r0,r1
    c.r[3] = c.r[1];  // 0603F3E2 mov r1,r3
    c.r[6] &= c.r[0];  // 0603F3E4 and r0,r6
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603F3E6 tst r3,r3
    { const bool k = c.t; c.r[7] = c.r[6]; if (k) { goto L_0603F3FA; } }  // 0603F3E8 bt/s 0x0603F3FA ; mov r6,r7
    c.r[6] += c.r[6];  // 0603F3EC add r6,r6
    c.r[1] = ld32(0x0603F420u);  // 0603F3EE mov.l 0x0603F420,r1
    c.r[0] = c.r[6];  // 0603F3F0 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603F3F2 mov.w @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F3F4 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0603F408; } }  // 0603F3F6 bf/s 0x0603F408 ; tst r3,r3
L_0603F3FA:
    { const bool k = !c.t; c.r[7] += c.r[7]; if (k) { goto L_0603F412; } }  // 0603F3FA bf/s 0x0603F412 ; add r7,r7
    c.r[1] = ld32(0x0603F420u);  // 0603F3FE mov.l 0x0603F420,r1
    c.r[0] = c.r[7];  // 0603F400 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603F402 mov.w @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F404 tst r1,r1
    if (!c.t) { goto L_0603F412; }  // 0603F406 bf 0x0603F412
L_0603F408:
    c.r[4] += 60;  // 0603F408 add #60,r4
    c.r[1] = 0x1u;  // 0603F40A mov #1,r1
    st8(c.r[4], c.r[1]);  // 0603F40C mov.b r1,@r4
    c.r[2] -= 2; goto L_0603F414;  // 0603F40E bra 0x0603F414 ; add #-2,r2
L_0603F412:
    c.r[2] += 1;  // 0603F412 add #1,r2
L_0603F414:
    c.r[0] = c.r[2];  // 0603F414 mov r2,r0
    c.r[15] = c.r[14];  // 0603F416 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F418 rts ; mov.l @r15+,r14
}

void f_0603F424(SH2Context& c) {
    ran[1006] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F424 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F426 mov r15,r14
    c.r[4] += 56;  // 0603F428 add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603F42A mov.w @r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F43Eu);  // 0603F42C mov.w 0x0603F43E,r1
    c.r[2] &= c.r[1];  // 0603F42E and r1,r2
    c.r[1] = ld32(0x0603F440u);  // 0603F430 mov.l 0x0603F440,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603F432 mov.w @r1,r1
    c.r[2] |= c.r[1];  // 0603F434 or r1,r2
    st16(c.r[4], c.r[2]);  // 0603F436 mov.w r2,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F438 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603F43A rts ; mov r5,r0
}

void f_0603F444(SH2Context& c) {
    ran[1007] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F444 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F446 mov r15,r14
    c.r[1] = ld32(0x0603F470u);  // 0603F448 mov.l 0x0603F470,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F44A mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F44C mov.l @r15+,r14
    c.r[3] = c.r[1] & 0xFFu;  // 0603F44E extu.b r1,r3
    c.r[3] += c.r[3];  // 0603F450 add r3,r3
    c.r[1] = c.r[3];  // 0603F452 mov r3,r1
    c.r[1] += c.r[5];  // 0603F454 add r5,r1
    c.r[0] = c.r[3];  // 0603F456 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0603F458 mov.b @(r0,r5),r2
    c.r[1] += 1;  // 0603F45A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F45C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603F45E extu.b r2,r2
    c.r[2] <<= 8;  // 0603F460 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603F462 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603F464 or r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603F466 exts.w r2,r1
    c.r[1] += c.r[5];  // 0603F468 add r5,r1
    c.r[1] += c.r[3];  // 0603F46A add r3,r1
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0603F46C rts ; mov r1,r0
}

void f_0603F474(SH2Context& c) {
    ran[1008] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F474 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F476 mov r15,r14
    c.r[0] = c.r[5];  // 0603F478 mov r5,r0
    c.r[3] = ld32(0x0603F494u);  // 0603F47A mov.l 0x0603F494,r3
    c.r[1] = c.r[0];  // 0603F47C mov r0,r1
    c.r[1] += 1;  // 0603F47E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603F480 mov.b @r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F482 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603F484 extu.b r2,r2
    c.r[2] <<= 8;  // 0603F486 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603F488 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603F48A or r1,r2
    st16(c.r[3], c.r[2]);  // 0603F48C mov.w r2,@r3
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F48E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603F490 rts ; add #2,r0
}

void f_0603F498(SH2Context& c) {
    ran[1009] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F498 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F49A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F49C sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603F49E mov r5,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603F4A0 mov.b @r8,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603F4A2 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F4A4 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603F4E6; } }  // 0603F4A6 bt/s 0x0603F4E6 ; mov r15,r14
    c.t = c.r[0] == 0x64u;  // 0603F4AA cmp/eq #100,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0603F4CC; } }  // 0603F4AC bt/s 0x0603F4CC ; mov r8,r1
    c.r[0] = ld32(0x0603F4F4u);  // 0603F4B0 mov.l 0x0603F4F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603F4B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F4B6u) return; }  // 0603F4B2 jsr @r0 ; nop
    c.r[2] = 0x64u;  // 0603F4B6 mov #100,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603F4B8 mov.b @r8,r1
    c.macl = c.r[0] * c.r[2];  // 0603F4BA mul.l r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0603F4BC extu.b r1,r1
    c.r[1] += 1;  // 0603F4BE add #1,r1
    c.r[3] = c.macl;  // 0603F4C0 sts macl,r3
    c.r[3] >>= 16;  // 0603F4C2 shlr16 r3
    c.r[3] += c.r[1];  // 0603F4C4 add r1,r3
    c.t = c.r[3] > c.r[2];  // 0603F4C6 cmp/hi r2,r3
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0603F4E6; } }  // 0603F4C8 bf/s 0x0603F4E6 ; mov r8,r1
L_0603F4CC:
    c.r[1] += 1;  // 0603F4CC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F4CE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603F4D0 extu.b r2,r2
    c.r[1] = c.r[8];  // 0603F4D2 mov r8,r1
    c.r[1] += 2;  // 0603F4D4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F4D6 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603F4D8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603F4DA extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603F4DC or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603F4DE exts.w r2,r0
    c.r[0] += 1;  // 0603F4E0 add #1,r0
    c.r[0] += c.r[8]; goto L_0603F4EA;  // 0603F4E2 bra 0x0603F4EA ; add r8,r0
L_0603F4E6:
    c.r[8] += 3;  // 0603F4E6 add #3,r8
    c.r[0] = c.r[8];  // 0603F4E8 mov r8,r0
L_0603F4EA:
    c.r[15] = c.r[14];  // 0603F4EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F4EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F4EE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F4F0 rts ; mov.l @r15+,r8
}

void f_0603F500(SH2Context& c) {
    ran[1010] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F500 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603F502 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603F504 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603F506 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603F508 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603F50A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F50C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F50E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603F510 mov r15,r14
    c.r[12] = c.r[5];  // 0603F512 mov r5,r12
    c.r[3] = ld32(0x0603F584u);  // 0603F514 mov.l 0x0603F584,r3
    c.r[13] = c.r[12];  // 0603F516 mov r12,r13
    c.r[2] = ld32(0x0603F588u);  // 0603F518 mov.l 0x0603F588,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]); c.r[13] += 1;  // 0603F51A mov.b @r13+,r1
    c.r[3] += 21;  // 0603F51C add #21,r3
    c.r[1] = 0u - c.r[1];  // 0603F51E neg r1,r1
    st8(c.r[2], c.r[1]);  // 0603F520 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603F522 mov.b @r13,r1
    c.r[11] = ld32(0x0603F58Cu);  // 0603F524 mov.l 0x0603F58C,r11
    c.r[1] = 0u - c.r[1];  // 0603F526 neg r1,r1
    st8(c.r[3], c.r[1]);  // 0603F528 mov.b r1,@r3
    c.r[2] = ld32(0x0603F590u);  // 0603F52A mov.l 0x0603F590,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F530u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F530u) return; }  // 0603F52C jsr @r2 ; mov.b @r12,r4
    c.r[4] = c.r[0];  // 0603F530 mov r0,r4
    c.r[5] = c.r[1];  // 0603F532 mov r1,r5
    c.r[1] = ld32(0x0603F594u);  // 0603F534 mov.l 0x0603F594,r1
    c.r[8] = ld32(c.r[1]);  // 0603F536 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603F538 mov.l @(4,r1),r9
    c.r[2] = ld32(0x0603F598u);  // 0603F53A mov.l 0x0603F598,r2
    c.r[6] = c.r[8];  // 0603F53C mov r8,r6
    { const uint32_t x = c.r[2]; c.pr = 0x0603F542u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F542u) return; }  // 0603F53E jsr @r2 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603F542 mov r0,r4
    c.r[10] = ld32(0x0603F59Cu);  // 0603F544 mov.l 0x0603F59C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0603F54Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F54Au) return; }  // 0603F546 jsr @r10 ; mov r1,r5
    c.r[2] = ld32(0x0603F5A0u);  // 0603F54A mov.l 0x0603F5A0,r2
    st32(c.r[2], c.r[0]);  // 0603F54C mov.l r0,@r2
    c.r[11] += 104;  // 0603F54E add #104,r11
    c.r[2] = ld32(0x0603F590u);  // 0603F550 mov.l 0x0603F590,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F556u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F556u) return; }  // 0603F552 jsr @r2 ; mov.b @r13,r4
    c.r[4] = c.r[0];  // 0603F556 mov r0,r4
    c.r[5] = c.r[1];  // 0603F558 mov r1,r5
    c.r[6] = c.r[8];  // 0603F55A mov r8,r6
    c.r[2] = ld32(0x0603F598u);  // 0603F55C mov.l 0x0603F598,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603F562u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F562u) return; }  // 0603F55E jsr @r2 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603F562 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0603F568u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F568u) return; }  // 0603F564 jsr @r10 ; mov r1,r5
    st32(c.r[11], c.r[0]);  // 0603F568 mov.l r0,@r11
    c.r[15] = c.r[14];  // 0603F56A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F56C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F56E mov.l @r15+,r14
    c.r[12] += 2;  // 0603F570 add #2,r12
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603F572 mov.l @r15+,r13
    c.r[0] = c.r[12];  // 0603F574 mov r12,r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603F576 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603F578 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603F57A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603F57C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F57E rts ; mov.l @r15+,r8
}

void f_0603F5A4(SH2Context& c) {
    ran[1011] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F5A4 mov.l r14,@-r15
    c.r[1] = ld32(0x0603F5F4u);  // 0603F5A6 mov.l 0x0603F5F4,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F5A8 mov.b @r1,r7
    c.r[14] = c.r[15];  // 0603F5AA mov r15,r14
    c.r[1] = ld32(0x0603F5F8u);  // 0603F5AC mov.l 0x0603F5F8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F5AE mov.b @r1,r2
    c.r[3] = ld32(0x0603F5FCu);  // 0603F5B0 mov.l 0x0603F5FC,r3
    c.r[1] = ld32(c.r[3]);  // 0603F5B2 mov.l @r3,r1
    c.r[7] <<= 2;  // 0603F5B4 shll2 r7
    c.r[7] <<= 2;  // 0603F5B6 shll2 r7
    c.r[7] <<= 2;  // 0603F5B8 shll2 r7
    c.r[7] += c.r[1];  // 0603F5BA add r1,r7
    c.r[0] = c.r[7];  // 0603F5BC mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603F5BE mov.b @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0603F5C0 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F5F2u);  // 0603F5C2 mov.w 0x0603F5F2,r1
    c.t = c.r[2] == c.r[1];  // 0603F5C4 cmp/eq r1,r2
    { const bool k = c.t; c.r[6] = c.r[5]; if (k) { goto L_0603F5E8; } }  // 0603F5C6 bt/s 0x0603F5E8 ; mov r5,r6
    c.r[1] = ld32(0x0603F600u);  // 0603F5CA mov.l 0x0603F600,r1
    c.r[1] = ld32(c.r[1]);  // 0603F5CC mov.l @r1,r1
    c.r[2] <<= 2;  // 0603F5CE shll2 r2
    c.r[2] <<= 2;  // 0603F5D0 shll2 r2
    c.r[2] += c.r[1];  // 0603F5D2 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0603F5D4 mov.b @r6,r1
    c.r[2] += 3;  // 0603F5D6 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603F5D8 mov.b @r2,r0
    c.r[1] <<= 2;  // 0603F5DA shll2 r1
    c.r[1] <<= 2;  // 0603F5DC shll2 r1
    c.r[1] += c.r[1];  // 0603F5DE add r1,r1
    c.r[1] <<= 2;  // 0603F5E0 shll2 r1
    c.r[0] &= 0x7Fu;  // 0603F5E2 and #127,r0
    c.r[0] |= c.r[1];  // 0603F5E4 or r1,r0
    st8(c.r[2], c.r[0]);  // 0603F5E6 mov.b r0,@r2
L_0603F5E8:
    c.r[6] += 1;  // 0603F5E8 add #1,r6
    c.r[15] = c.r[14];  // 0603F5EA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F5EC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0603F5EE rts ; mov r6,r0
}

void f_0603F604(SH2Context& c) {
    ran[1012] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F604 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F606 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F608 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603F60A mov r15,r14
    c.r[1] = ld32(0x0603F658u);  // 0603F60C mov.l 0x0603F658,r1
    c.r[1] = ld32(c.r[1]);  // 0603F60E mov.l @r1,r1
    c.r[8] = c.r[5];  // 0603F610 mov r5,r8
    c.r[1] += 18;  // 0603F612 add #18,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603F614 mov.w @r1,r4
    c.r[0] = ld32(0x0603F65Cu);  // 0603F616 mov.l 0x0603F65C,r0
    c.r[4] <<= 16;  // 0603F618 shll16 r4
    c.r[4] <<= 2;  // 0603F61A shll2 r4
    c.r[4] += c.r[4];  // 0603F61C add r4,r4
    c.r[4] <<= 2;  // 0603F61E shll2 r4
    c.r[4] >>= 16;  // 0603F620 shlr16 r4
    c.r[4] <<= 2;  // 0603F622 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0603F628u; c.r[4] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F628u) return; }  // 0603F624 jsr @r0 ; shlr8 r4
    c.r[1] = c.r[0];  // 0603F628 mov r0,r1
    c.r[1] -= 1;  // 0603F62A add #-1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603F62C extu.b r1,r3
    c.r[3] += c.r[3];  // 0603F62E add r3,r3
    c.r[1] = c.r[3];  // 0603F630 mov r3,r1
    c.r[1] += c.r[8];  // 0603F632 add r8,r1
    c.r[0] = c.r[3];  // 0603F634 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0603F636 mov.b @(r0,r8),r2
    c.r[1] += 1;  // 0603F638 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F63A mov.b @r1,r1
    c.r[15] = c.r[14];  // 0603F63C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F63E lds.l @r15+,pr
    c.r[2] = c.r[2] & 0xFFu;  // 0603F640 extu.b r2,r2
    c.r[2] <<= 8;  // 0603F642 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603F644 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603F646 or r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603F648 exts.w r2,r1
    c.r[1] += c.r[8];  // 0603F64A add r8,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F64C mov.l @r15+,r14
    c.r[1] += c.r[3];  // 0603F64E add r3,r1
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0603F650 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0603F652 rts ; mov r1,r0
}

void f_0603F660(SH2Context& c) {
    ran[1013] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F660 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603F662 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F664 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F666 sts.l pr,@-r15
    c.r[1] = ld32(0x0603F6D8u);  // 0603F668 mov.l 0x0603F6D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F66A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603F66C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F66E tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603F6CA; } }  // 0603F670 bf/s 0x0603F6CA ; mov r15,r14
    c.r[8] = ld32(0x0603F6DCu);  // 0603F674 mov.l 0x0603F6DC,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603F676 mov.w @r8,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F678 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F67A tst r1,r1
    if (c.t) { goto L_0603F692; }  // 0603F67C bt 0x0603F692
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603F6D6u);  // 0603F67E mov.w 0x0603F6D6,r6
    c.r[5] = ld32(0x0603F6E0u);  // 0603F680 mov.l 0x0603F6E0,r5
    c.r[4] = ld32(0x0603F6E4u);  // 0603F682 mov.l 0x0603F6E4,r4
    c.r[1] = ld32(0x0603F6E8u);  // 0603F684 mov.l 0x0603F6E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603F68Au; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F68Au) return; }  // 0603F686 jsr @r1 ; mov #14,r7
    c.r[1] = 0x0u;  // 0603F68A mov #0,r1
    st16(c.r[8], c.r[1]);  // 0603F68C mov.w r1,@r8
    c.r[15] = c.r[14]; goto L_0603F6CC;  // 0603F68E bra 0x0603F6CC ; mov r14,r15
L_0603F692:
    c.r[8] = ld32(0x0603F6ECu);  // 0603F692 mov.l 0x0603F6EC,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603F694 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603F696 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F698 tst r1,r1
    if (c.t) { goto L_0603F6AC; }  // 0603F69A bt 0x0603F6AC
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603F6D6u);  // 0603F69C mov.w 0x0603F6D6,r6
    c.r[5] = ld32(0x0603F6E4u);  // 0603F69E mov.l 0x0603F6E4,r5
    c.r[4] = ld32(0x0603F6F0u);  // 0603F6A0 mov.l 0x0603F6F0,r4
    c.r[1] = ld32(0x0603F6E8u);  // 0603F6A2 mov.l 0x0603F6E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603F6A8u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F6A8u) return; }  // 0603F6A4 jsr @r1 ; mov #14,r7
    c.r[1] = 0x0u;  // 0603F6A8 mov #0,r1
    st8(c.r[8], c.r[1]);  // 0603F6AA mov.b r1,@r8
L_0603F6AC:
    c.r[9] = ld32(0x0603F6F4u);  // 0603F6AC mov.l 0x0603F6F4,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0603F6AE mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F6B0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F6B2 tst r1,r1
    if (c.t) { goto L_0603F6CA; }  // 0603F6B4 bt 0x0603F6CA
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603F6D6u);  // 0603F6B6 mov.w 0x0603F6D6,r6
    c.r[5] = ld32(0x0603F6F0u);  // 0603F6B8 mov.l 0x0603F6F0,r5
    c.r[4] = ld32(0x0603F6E0u);  // 0603F6BA mov.l 0x0603F6E0,r4
    c.r[1] = ld32(0x0603F6E8u);  // 0603F6BC mov.l 0x0603F6E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603F6C2u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F6C2u) return; }  // 0603F6BE jsr @r1 ; mov #14,r7
    c.r[1] = 0x1u;  // 0603F6C2 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0603F6C4 mov.b r1,@r8
    c.r[1] = 0x0u;  // 0603F6C6 mov #0,r1
    st16(c.r[9], c.r[1]);  // 0603F6C8 mov.w r1,@r9
L_0603F6CA:
    c.r[15] = c.r[14];  // 0603F6CA mov r14,r15
L_0603F6CC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F6CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F6CE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603F6D0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F6D2 rts ; mov.l @r15+,r8
}

void f_0603F6F8(SH2Context& c) {
    ran[1014] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F6F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603F6FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F6FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F6FE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603F700 mov r15,r14
    c.r[1] = ld32(0x0603F79Cu);  // 0603F702 mov.l 0x0603F79C,r1
    c.r[3] = 0x0u;  // 0603F704 mov #0,r3
    st16(c.r[1], c.r[3]);  // 0603F706 mov.w r3,@r1
    c.r[2] = ld32(0x0603F7A0u);  // 0603F708 mov.l 0x0603F7A0,r2
    c.r[1] = 0x0u;  // 0603F70A mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603F70C mov.b r1,@r2
    c.r[1] = ld32(0x0603F7A4u);  // 0603F70E mov.l 0x0603F7A4,r1
    st16(c.r[1], c.r[3]);  // 0603F710 mov.w r3,@r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603F78Au);  // 0603F712 mov.w 0x0603F78A,r5
    c.r[0] = ld32(0x0603F7A8u);  // 0603F714 mov.l 0x0603F7A8,r0
    c.r[6] = c.r[5];  // 0603F716 mov r5,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603F71Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F71Cu) return; }  // 0603F718 jsr @r0 ; mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603F78Cu);  // 0603F71C mov.w 0x0603F78C,r5
    c.r[9] = ld32(0x0603F7ACu);  // 0603F71E mov.l 0x0603F7AC,r9
    c.r[8] = ld32(0x0603F7B0u);  // 0603F720 mov.l 0x0603F7B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0603F726u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F726u) return; }  // 0603F722 jsr @r8 ; mov.l @r9,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603F78Eu);  // 0603F726 mov.w 0x0603F78E,r5
    c.r[4] = ld32(0x0603F7B4u);  // 0603F728 mov.l 0x0603F7B4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0603F72Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F72Eu) return; }  // 0603F72A jsr @r8 ; nop
    c.r[8] = 0x0u;  // 0603F72E mov #0,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603F790u);  // 0603F730 mov.w 0x0603F790,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603F792u);  // 0603F732 mov.w 0x0603F792,r5
    c.r[7] = ld32(c.r[9]);  // 0603F734 mov.l @r9,r7
    c.r[3] = 0x0u;  // 0603F736 mov #0,r3
    c.r[9] = c.r[7];  // 0603F738 mov r7,r9
    c.r[6] = c.r[9];  // 0603F73A mov r9,r6
    c.r[6] += 30;  // 0603F73C add #30,r6
L_0603F73E:
    c.r[0] = c.r[3];  // 0603F73E mov r3,r0
    st16(c.r[0] + c.r[7], c.r[8]);  // 0603F740 mov.w r8,@(r0,r7)
    c.r[2] = c.r[9];  // 0603F742 mov r9,r2
    c.r[2] += 32;  // 0603F744 add #32,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F794u);  // 0603F746 mov.w 0x0603F794,r1
    st16(c.r[2], c.r[1]);  // 0603F748 mov.w r1,@r2
    c.r[2] = c.r[9];  // 0603F74A mov r9,r2
    c.r[2] += 64;  // 0603F74C add #64,r2
    c.r[1] = 0x1Fu;  // 0603F74E mov #31,r1
    st16(c.r[2], c.r[1]);  // 0603F750 mov.w r1,@r2
    c.r[2] = c.r[9];  // 0603F752 mov r9,r2
    c.r[2] += 96;  // 0603F754 add #96,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F796u);  // 0603F756 mov.w 0x0603F796,r1
    st16(c.r[2], c.r[1]);  // 0603F758 mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F798u);  // 0603F75A mov.w 0x0603F798,r1
    c.r[0] = c.r[9];  // 0603F75C mov r9,r0
    st16(c.r[0] + c.r[4], c.r[1]);  // 0603F75E mov.w r1,@(r0,r4)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F79Au);  // 0603F760 mov.w 0x0603F79A,r1
    st16(c.r[0] + c.r[5], c.r[1]);  // 0603F762 mov.w r1,@(r0,r5)
    c.r[9] += 2;  // 0603F764 add #2,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[6];  // 0603F766 cmp/gt r6,r9
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0603F73E; } }  // 0603F768 bf/s 0x0603F73E ; add #2,r3
    c.r[3] = ld32(0x0603F7B8u);  // 0603F76C mov.l 0x0603F7B8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603F790u);  // 0603F76E mov.w 0x0603F790,r2
    c.r[7] = 0x0u;  // 0603F770 mov #0,r7
    c.r[1] = 0x1Au;  // 0603F772 mov #26,r1
L_0603F774:
    c.r[0] = c.r[7];  // 0603F774 mov r7,r0
    c.r[7] += 2;  // 0603F776 add #2,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0603F778 cmp/gt r1,r7
    { const bool k = !c.t; st16(c.r[0] + c.r[3], c.r[2]); if (k) { SH2_POLL(c); goto L_0603F774; } }  // 0603F77A bf/s 0x0603F774 ; mov.w r2,@(r0,r3)
    c.r[15] = c.r[14];  // 0603F77E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F780 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F782 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603F784 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F786 rts ; mov.l @r15+,r8
}

void f_0603F7BC(SH2Context& c) {
    ran[1015] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F7BC mov.l r14,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603F7BE mov.w @r4,r3
    c.r[1] = ld32(0x0603F884u);  // 0603F7C0 mov.l 0x0603F884,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0603F7C2 extu.w r3,r2
    c.t = c.r[2] == c.r[1];  // 0603F7C4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603F7CE; } }  // 0603F7C6 bf/s 0x0603F7CE ; mov r15,r14
    goto L_0603F8E8;  // 0603F7CA bra 0x0603F8E8 ; nop
L_0603F7CE:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603F7CE cmp/gt r1,r2
    if (c.t) { goto L_0603F81A; }  // 0603F7D0 bt 0x0603F81A
    c.r[1] = ld32(0x0603F888u);  // 0603F7D2 mov.l 0x0603F888,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603F7D4 cmp/gt r1,r2
    if (c.t) { goto L_0603F7FC; }  // 0603F7D6 bt 0x0603F7FC
    c.r[1] = ld32(0x0603F88Cu);  // 0603F7D8 mov.l 0x0603F88C,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0603F7DA cmp/ge r1,r2
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0603F864; } }  // 0603F7DC bt/s 0x0603F864 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F87Cu);  // 0603F7E0 mov.w 0x0603F87C,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603F7E2 cmp/gt r1,r2
    { const bool k = !c.t; c.r[7] = 0xFu; if (k) { goto L_0603F7EC; } }  // 0603F7E4 bf/s 0x0603F7EC ; mov #15,r7
    goto L_0603F95C;  // 0603F7E8 bra 0x0603F95C ; nop
L_0603F7EC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F87Eu);  // 0603F7EC mov.w 0x0603F87E,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0603F7EE cmp/ge r1,r2
    if (c.t) { goto L_0603F7F6; }  // 0603F7F0 bt 0x0603F7F6
    goto L_0603F95C;  // 0603F7F2 bra 0x0603F95C ; nop
L_0603F7F6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603F7F6 mov.w @r4,r0
    c.r[7] = 0x0u; goto L_0603F85E;  // 0603F7F8 bra 0x0603F85E ; mov #0,r7
L_0603F7FC:
    c.r[1] = ld32(0x0603F890u);  // 0603F7FC mov.l 0x0603F890,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603F7FE cmp/gt r1,r2
    if (c.t) { goto L_0603F80E; }  // 0603F800 bt 0x0603F80E
    c.r[1] = ld32(0x0603F894u);  // 0603F802 mov.l 0x0603F894,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0603F804 cmp/ge r1,r2
    if (c.t) { goto L_0603F872; }  // 0603F806 bt 0x0603F872
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603F808 mov.w @r4,r0
    c.r[7] = 0x0u; goto L_0603F86A;  // 0603F80A bra 0x0603F86A ; mov #0,r7
L_0603F80E:
    c.r[1] = ld32(0x0603F898u);  // 0603F80E mov.l 0x0603F898,r1
    c.t = c.r[2] == c.r[1];  // 0603F810 cmp/eq r1,r2
    { const bool k = c.t; c.r[7] = 0xFu; if (k) { goto L_0603F8B8; } }  // 0603F812 bt/s 0x0603F8B8 ; mov #15,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_0603F95E;  // 0603F816 bra 0x0603F95E ; mov.w @r4,r1
L_0603F81A:
    c.r[1] = ld32(0x0603F89Cu);  // 0603F81A mov.l 0x0603F89C,r1
    c.t = c.r[2] == c.r[1];  // 0603F81C cmp/eq r1,r2
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_0603F8B8; } }  // 0603F81E bt/s 0x0603F8B8 ; cmp/gt r1,r2
    if (c.t) { goto L_0603F840; }  // 0603F822 bt 0x0603F840
    c.r[1] = ld32(0x0603F8A0u);  // 0603F824 mov.l 0x0603F8A0,r1
    c.t = c.r[2] == c.r[1];  // 0603F826 cmp/eq r1,r2
    { const bool k = c.t; c.t = (int32_t)c.r[2] >= (int32_t)c.r[1]; if (k) { goto L_0603F8E8; } }  // 0603F828 bt/s 0x0603F8E8 ; cmp/ge r1,r2
    if (!c.t) { goto L_0603F8B8; }  // 0603F82C bf 0x0603F8B8
    c.r[1] = ld32(0x0603F8A4u);  // 0603F82E mov.l 0x0603F8A4,r1
    c.t = c.r[2] == c.r[1];  // 0603F830 cmp/eq r1,r2
    if (c.t) { goto L_0603F8B8; }  // 0603F832 bt 0x0603F8B8
    c.r[1] = ld32(0x0603F8A8u);  // 0603F834 mov.l 0x0603F8A8,r1
    c.t = c.r[2] == c.r[1];  // 0603F836 cmp/eq r1,r2
    { const bool k = c.t; c.r[7] = 0xFu; if (k) { goto L_0603F8E8; } }  // 0603F838 bt/s 0x0603F8E8 ; mov #15,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_0603F95E;  // 0603F83C bra 0x0603F95E ; mov.w @r4,r1
L_0603F840:
    c.r[1] = ld32(0x0603F8ACu);  // 0603F840 mov.l 0x0603F8AC,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603F842 cmp/gt r1,r2
    if (c.t) { goto L_0603F852; }  // 0603F844 bt 0x0603F852
    c.r[1] = ld32(0x0603F8B0u);  // 0603F846 mov.l 0x0603F8B0,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0603F848 cmp/ge r1,r2
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0603F94A; } }  // 0603F84A bt/s 0x0603F94A ; mov r3,r0
    goto L_0603F8E8;  // 0603F84E bra 0x0603F8E8 ; nop
L_0603F852:
    c.r[1] = ld32(0x0603F8B4u);  // 0603F852 mov.l 0x0603F8B4,r1
    c.t = c.r[2] == c.r[1];  // 0603F854 cmp/eq r1,r2
    { const bool k = c.t; c.r[7] = 0xFu; if (k) { goto L_0603F950; } }  // 0603F856 bt/s 0x0603F950 ; mov #15,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_0603F95E;  // 0603F85A bra 0x0603F95E ; mov.w @r4,r1
L_0603F85E:
    c.r[0] &= 0x7u;  // 0603F85E and #7,r0
    st16(c.r[4], c.r[0]); goto L_0603F97C;  // 0603F860 bra 0x0603F97C ; mov.w r0,@r4
L_0603F864:
    c.r[0] &= 0x7u;  // 0603F864 and #7,r0
    c.r[0] += 74; goto L_0603F956;  // 0603F866 bra 0x0603F956 ; add #74,r0
L_0603F86A:
    c.r[0] &= 0x3u;  // 0603F86A and #3,r0
    c.r[0] += 92;  // 0603F86C add #92,r0
    st16(c.r[4], c.r[0]); goto L_0603F97C;  // 0603F86E bra 0x0603F97C ; mov.w r0,@r4
L_0603F872:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603F880u);  // 0603F872 mov.w 0x0603F880,r1
    c.r[1] += c.r[3];  // 0603F874 add r3,r1
    st16(c.r[4], c.r[1]);  // 0603F876 mov.w r1,@r4
    c.r[7] = 0x0u; goto L_0603F97C;  // 0603F878 bra 0x0603F97C ; mov #0,r7
L_0603F8B8:
    c.r[1] = ld32(0x0603F984u);  // 0603F8B8 mov.l 0x0603F984,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F8BA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603F8BC mov r1,r0
    c.r[0] >>= 2;  // 0603F8BE shlr2 r0
    c.r[0] >>= 2;  // 0603F8C0 shlr2 r0
    c.r[0] >>= 2;  // 0603F8C2 shlr2 r0
    c.r[0] &= 0x1u;  // 0603F8C4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F8C6 tst r0,r0
    { const bool k = c.t; c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { goto L_0603F8DA; } }  // 0603F8C8 bt/s 0x0603F8DA ; mov.w @r4,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603F8CC extu.w r1,r0
    c.r[1] = ld32(0x0603F988u);  // 0603F8CE mov.l 0x0603F988,r1
    c.r[0] += c.r[1];  // 0603F8D0 add r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603F8D2 shar r0
    c.r[0] &= 0x3u;  // 0603F8D4 and #3,r0
    c.r[0] += 62; goto L_0603F956;  // 0603F8D6 bra 0x0603F956 ; add #62,r0
L_0603F8DA:
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603F8DA extu.w r1,r0
    c.r[1] = ld32(0x0603F988u);  // 0603F8DC mov.l 0x0603F988,r1
    c.r[0] += c.r[1];  // 0603F8DE add r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603F8E0 shar r0
    c.r[0] &= 0x3u;  // 0603F8E2 and #3,r0
    c.r[0] += 58; goto L_0603F956;  // 0603F8E4 bra 0x0603F956 ; add #58,r0
L_0603F8E8:
    c.r[1] = ld32(0x0603F984u);  // 0603F8E8 mov.l 0x0603F984,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603F8EA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603F8EC mov r1,r0
    c.r[0] >>= 2;  // 0603F8EE shlr2 r0
    c.r[0] >>= 2;  // 0603F8F0 shlr2 r0
    c.r[0] >>= 2;  // 0603F8F2 shlr2 r0
    c.r[0] &= 0x1u;  // 0603F8F4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603F8F6 tst r0,r0
    if (c.t) { goto L_0603F922; }  // 0603F8F8 bt 0x0603F922
    c.r[1] = ld32(0x0603F98Cu);  // 0603F8FA mov.l 0x0603F98C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603F8FC mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F8FE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F900 tst r1,r1
    { const bool k = c.t; c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { goto L_0603F914; } }  // 0603F902 bt/s 0x0603F914 ; mov.w @r4,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603F906 extu.w r1,r0
    c.r[1] = ld32(0x0603F988u);  // 0603F908 mov.l 0x0603F988,r1
    c.r[0] += c.r[1];  // 0603F90A add r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603F90C shar r0
    c.r[0] &= 0x3u;  // 0603F90E and #3,r0
    c.r[0] += 66; goto L_0603F956;  // 0603F910 bra 0x0603F956 ; add #66,r0
L_0603F914:
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603F914 extu.w r1,r0
    c.r[1] = ld32(0x0603F988u);  // 0603F916 mov.l 0x0603F988,r1
    c.r[0] += c.r[1];  // 0603F918 add r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603F91A shar r0
    c.r[0] &= 0x3u;  // 0603F91C and #3,r0
    c.r[0] += 58; goto L_0603F956;  // 0603F91E bra 0x0603F956 ; add #58,r0
L_0603F922:
    c.r[1] = ld32(0x0603F990u);  // 0603F922 mov.l 0x0603F990,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603F924 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F926 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603F928 tst r1,r1
    { const bool k = c.t; c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { goto L_0603F93C; } }  // 0603F92A bt/s 0x0603F93C ; mov.w @r4,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603F92E extu.w r1,r0
    c.r[1] = ld32(0x0603F988u);  // 0603F930 mov.l 0x0603F988,r1
    c.r[0] += c.r[1];  // 0603F932 add r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603F934 shar r0
    c.r[0] &= 0x3u;  // 0603F936 and #3,r0
    c.r[0] += 70; goto L_0603F956;  // 0603F938 bra 0x0603F956 ; add #70,r0
L_0603F93C:
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603F93C extu.w r1,r0
    c.r[1] = ld32(0x0603F988u);  // 0603F93E mov.l 0x0603F988,r1
    c.r[0] += c.r[1];  // 0603F940 add r1,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603F942 shar r0
    c.r[0] &= 0x3u;  // 0603F944 and #3,r0
    c.r[0] += 62; goto L_0603F956;  // 0603F946 bra 0x0603F956 ; add #62,r0
L_0603F94A:
    c.r[0] &= 0x3u;  // 0603F94A and #3,r0
    c.r[0] += 38; goto L_0603F956;  // 0603F94C bra 0x0603F956 ; add #38,r0
L_0603F950:
    c.r[0] = c.r[3];  // 0603F950 mov r3,r0
    c.r[0] &= 0x3u;  // 0603F952 and #3,r0
    c.r[0] += 96;  // 0603F954 add #96,r0
L_0603F956:
    st16(c.r[4], c.r[0]);  // 0603F956 mov.w r0,@r4
    c.r[7] = 0x0u; goto L_0603F97C;  // 0603F958 bra 0x0603F97C ; mov #0,r7
L_0603F95C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603F95C mov.w @r4,r1
L_0603F95E:
    c.r[2] = ld32(0x0603F994u);  // 0603F95E mov.l 0x0603F994,r2
    c.r[7] &= c.r[1];  // 0603F960 and r1,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603F962 extu.w r1,r1
    c.r[3] = c.r[1];  // 0603F964 mov r1,r3
    c.r[3] >>= 8;  // 0603F966 shlr8 r3
    c.r[3] >>= 2;  // 0603F968 shlr2 r3
    c.r[3] >>= 2;  // 0603F96A shlr2 r3
    c.r[3] += c.r[3];  // 0603F96C add r3,r3
    c.r[0] = c.r[3];  // 0603F96E mov r3,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603F970 mov.w @(r0,r2),r2
    c.r[1] >>= 2;  // 0603F972 shlr2 r1
    c.r[1] >>= 2;  // 0603F974 shlr2 r1
    c.r[2] += c.r[1];  // 0603F976 add r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603F978 extu.b r2,r2
    st16(c.r[4], c.r[2]);  // 0603F97A mov.w r2,@r4
L_0603F97C:
    c.r[15] = c.r[14];  // 0603F97C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F97E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603F980 rts ; mov r7,r0
}

void f_0603F998(SH2Context& c) {
    ran[1016] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F998 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F99A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603F99C sts.l pr,@-r15
    c.r[5] = c.r[4];  // 0603F99E mov r4,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603F9A0 tst r5,r5
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603F9A8; } }  // 0603F9A2 bf/s 0x0603F9A8 ; mov r15,r14
    c.r[5] = ld32(0x0603F9D0u);  // 0603F9A6 mov.l 0x0603F9D0,r5
L_0603F9A8:
    c.r[8] = ld32(0x0603F9D4u);  // 0603F9A8 mov.l 0x0603F9D4,r8
    c.r[1] = 0x1u;  // 0603F9AA mov #1,r1
    st8(c.r[8], c.r[1]);  // 0603F9AC mov.b r1,@r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603F9CCu);  // 0603F9AE mov.w 0x0603F9CC,r6
    c.r[4] = ld32(0x0603F9D8u);  // 0603F9B0 mov.l 0x0603F9D8,r4
    c.r[1] = ld32(0x0603F9DCu);  // 0603F9B2 mov.l 0x0603F9DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603F9B8u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F9B8u) return; }  // 0603F9B4 jsr @r1 ; mov #14,r7
    c.r[1] = ld32(0x0603F9E0u);  // 0603F9B8 mov.l 0x0603F9E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603F9BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603F9BEu) return; }  // 0603F9BA jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0603F9BE mov #0,r1
    st8(c.r[8], c.r[1]);  // 0603F9C0 mov.b r1,@r8
    c.r[15] = c.r[14];  // 0603F9C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603F9C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603F9C6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603F9C8 rts ; mov.l @r15+,r8
}

void f_0603F9E4(SH2Context& c) {
    ran[1017] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603F9E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603F9E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603F9E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603F9EA mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603F9EC mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0603F9EE extu.w r4,r4
    c.r[10] = c.r[5] & 0xFFu;  // 0603F9F0 extu.b r5,r10
    c.r[6] = c.r[6] & 0xFFu;  // 0603F9F2 extu.b r6,r6
    c.r[5] = c.r[7] & 0xFFFFu;  // 0603F9F4 extu.w r7,r5
    c.r[9] = c.r[4];  // 0603F9F6 mov r4,r9
    c.r[9] >>= 8;  // 0603F9F8 shlr8 r9
    c.r[0] = 0x3u;  // 0603F9FA mov #3,r0
    c.r[9] &= c.r[0];  // 0603F9FC and r0,r9
    c.r[3] = c.r[9];  // 0603F9FE mov r9,r3
    c.r[8] = c.r[4] & 0xFFu;  // 0603FA00 extu.b r4,r8
    c.r[1] = ld32(0x0603FB7Cu);  // 0603FA02 mov.l 0x0603FB7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603FA04 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603FA06 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603FA08 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603FA0A cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = c.r[8]; if (k) { goto L_0603FA14; } }  // 0603FA0C bt/s 0x0603FA14 ; mov r8,r7
    goto L_0603FB42;  // 0603FA10 bra 0x0603FB42 ; nop
L_0603FA14:
    c.r[2] = c.r[8];  // 0603FA14 mov r8,r2
    c.r[2] >>= 2;  // 0603FA16 shlr2 r2
    c.r[2] >>= 2;  // 0603FA18 shlr2 r2
    c.r[2] <<= 2;  // 0603FA1A shll2 r2
    c.r[2] += c.r[2];  // 0603FA1C add r2,r2
    c.r[1] = ld32(0x0603FB80u);  // 0603FA1E mov.l 0x0603FB80,r1
    c.r[2] += c.r[1];  // 0603FA20 add r1,r2
    c.r[9] += c.r[9];  // 0603FA22 add r9,r9
    c.r[0] = c.r[9];  // 0603FA24 mov r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603FA26 mov.w @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0603FA28 extu.w r1,r3
    c.r[3] <<= 2;  // 0603FA2A shll2 r3
    c.r[3] <<= 2;  // 0603FA2C shll2 r3
    c.r[0] = 0xFu;  // 0603FA2E mov #15,r0
    c.r[8] &= c.r[0];  // 0603FA30 and r0,r8
    c.r[3] += c.r[8];  // 0603FA32 add r8,r3
    c.r[3] += c.r[3];  // 0603FA34 add r3,r3
    c.r[1] = ld32(0x0603FB84u);  // 0603FA36 mov.l 0x0603FB84,r1
    c.r[3] += c.r[1];  // 0603FA38 add r1,r3
    c.r[1] = ld32(0x0603FB88u);  // 0603FA3A mov.l 0x0603FB88,r1
    c.r[10] <<= 2;  // 0603FA3C shll2 r10
    c.r[10] <<= 2;  // 0603FA3E shll2 r10
    c.r[10] += c.r[6];  // 0603FA40 add r6,r10
    c.r[6] = ld32(c.r[1]);  // 0603FA42 mov.l @r1,r6
    c.r[10] += c.r[10];  // 0603FA44 add r10,r10
    c.r[6] += c.r[10]; goto L_0603FA5A;  // 0603FA46 bra 0x0603FA5A ; add r10,r6
L_0603FA4A:
    c.r[1] -= 1;  // 0603FA4A add #-1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0603FA4C extu.w r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); c.r[6] += 2;  // 0603FA4E mov.w @r6+,r1
    st16(c.r[3], c.r[1]);  // 0603FA50 mov.w r1,@r3
    c.r[3] += 2;  // 0603FA52 add #2,r3
    c.r[1] = c.r[4];  // 0603FA54 mov r4,r1
    c.r[1] += 1;  // 0603FA56 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 0603FA58 extu.w r1,r4
L_0603FA5A:
    c.r[1] = 0xFu;  // 0603FA5A mov #15,r1
    c.r[1] &= c.r[4];  // 0603FA5C and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FA5E tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { SH2_POLL(c); goto L_0603FA4A; } }  // 0603FA60 bf/s 0x0603FA4A ; mov r5,r1
    c.r[9] = 0x0u;  // 0603FA64 mov #0,r9
    c.r[1] >>= 2;  // 0603FA66 shlr2 r1
    c.r[1] >>= 2;  // 0603FA68 shlr2 r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0603FA6A cmp/ge r1,r9
    { const bool k = c.t; c.r[3] = c.r[4]; if (k) { goto L_0603FAE2; } }  // 0603FA6C bt/s 0x0603FAE2 ; mov r4,r3
    c.r[10] = ld32(0x0603FB84u);  // 0603FA70 mov.l 0x0603FB84,r10
    c.r[8] = 0x0u;  // 0603FA72 mov #0,r8
L_0603FA74:
    c.r[3] = c.r[4];  // 0603FA74 mov r4,r3
    c.r[3] >>= 8;  // 0603FA76 shlr8 r3
    c.r[0] = 0x3u;  // 0603FA78 mov #3,r0
    c.r[3] &= c.r[0];  // 0603FA7A and r0,r3
    c.r[1] = ld32(0x0603FB7Cu);  // 0603FA7C mov.l 0x0603FB7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603FA7E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603FA80 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603FA82 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603FA84 cmp/eq #1,r0
    { const bool k = !c.t; c.r[7] = c.r[4] & 0xFFu; if (k) { goto L_0603FAAC; } }  // 0603FA86 bf/s 0x0603FAAC ; extu.b r4,r7
    c.r[2] = c.r[7];  // 0603FA8A mov r7,r2
    c.r[2] += c.r[8];  // 0603FA8C add r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603FB78u);  // 0603FA8E mov.w 0x0603FB78,r7
    c.r[7] &= c.r[2];  // 0603FA90 and r2,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0603FA92 shlr r7
    c.r[1] = ld32(0x0603FB80u);  // 0603FA94 mov.l 0x0603FB80,r1
    c.r[7] += c.r[1];  // 0603FA96 add r1,r7
    c.r[3] += c.r[3];  // 0603FA98 add r3,r3
    c.r[0] = c.r[3];  // 0603FA9A mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0603FA9C mov.w @(r0,r7),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0603FA9E extu.w r1,r3
    c.r[3] <<= 2;  // 0603FAA0 shll2 r3
    c.r[3] <<= 2;  // 0603FAA2 shll2 r3
    c.r[0] = 0xFu;  // 0603FAA4 mov #15,r0
    c.r[2] &= c.r[0];  // 0603FAA6 and r0,r2
    c.r[3] += c.r[2]; goto L_0603FAB2;  // 0603FAA8 bra 0x0603FAB2 ; add r2,r3
L_0603FAAC:
    c.r[3] <<= 8;  // 0603FAAC shll8 r3
    c.r[3] += c.r[7];  // 0603FAAE add r7,r3
    c.r[3] += c.r[8];  // 0603FAB0 add r8,r3
L_0603FAB2:
    c.r[3] += c.r[3];  // 0603FAB2 add r3,r3
    c.r[3] += c.r[10];  // 0603FAB4 add r10,r3
    c.r[2] = 0x0u;  // 0603FAB6 mov #0,r2
    c.r[7] = 0xFu;  // 0603FAB8 mov #15,r7
L_0603FABA:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); c.r[6] += 2;  // 0603FABA mov.w @r6+,r1
    c.r[2] += 1;  // 0603FABC add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0603FABE cmp/gt r7,r2
    st16(c.r[3], c.r[1]);  // 0603FAC0 mov.w r1,@r3
    c.r[3] += 2;  // 0603FAC2 add #2,r3
    c.r[1] = c.r[5];  // 0603FAC4 mov r5,r1
    c.r[1] -= 1;  // 0603FAC6 add #-1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0603FAC8 extu.w r1,r5
    c.r[1] = c.r[4];  // 0603FACA mov r4,r1
    c.r[1] += 1;  // 0603FACC add #1,r1
    { const bool k = !c.t; c.r[4] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0603FABA; } }  // 0603FACE bf/s 0x0603FABA ; extu.w r1,r4
    c.r[9] += 1;  // 0603FAD2 add #1,r9
    c.r[1] = c.r[5];  // 0603FAD4 mov r5,r1
    c.r[1] >>= 2;  // 0603FAD6 shlr2 r1
    c.r[1] >>= 2;  // 0603FAD8 shlr2 r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0603FADA cmp/ge r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_0603FA74; } }  // 0603FADC bf/s 0x0603FA74 ; add #16,r8
    c.r[3] = c.r[4];  // 0603FAE0 mov r4,r3
L_0603FAE2:
    c.r[3] >>= 8;  // 0603FAE2 shlr8 r3
    c.r[0] = 0x3u;  // 0603FAE4 mov #3,r0
    c.r[3] &= c.r[0];  // 0603FAE6 and r0,r3
    c.r[1] = ld32(0x0603FB7Cu);  // 0603FAE8 mov.l 0x0603FB7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603FAEA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603FAEC extu.b r1,r1
    c.r[0] = c.r[1];  // 0603FAEE mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603FAF0 cmp/eq #1,r0
    { const bool k = !c.t; c.r[7] = c.r[4] & 0xFFu; if (k) { goto L_0603FB16; } }  // 0603FAF2 bf/s 0x0603FB16 ; extu.b r4,r7
    c.r[2] = c.r[7];  // 0603FAF6 mov r7,r2
    c.r[2] >>= 2;  // 0603FAF8 shlr2 r2
    c.r[2] >>= 2;  // 0603FAFA shlr2 r2
    c.r[2] <<= 2;  // 0603FAFC shll2 r2
    c.r[2] += c.r[2];  // 0603FAFE add r2,r2
    c.r[1] = ld32(0x0603FB80u);  // 0603FB00 mov.l 0x0603FB80,r1
    c.r[2] += c.r[1];  // 0603FB02 add r1,r2
    c.r[3] += c.r[3];  // 0603FB04 add r3,r3
    c.r[0] = c.r[3];  // 0603FB06 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603FB08 mov.w @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0603FB0A extu.w r1,r3
    c.r[3] <<= 2;  // 0603FB0C shll2 r3
    c.r[3] <<= 2;  // 0603FB0E shll2 r3
    c.r[0] = 0xFu;  // 0603FB10 mov #15,r0
    c.r[7] &= c.r[0]; goto L_0603FB18;  // 0603FB12 bra 0x0603FB18 ; and r0,r7
L_0603FB16:
    c.r[3] <<= 8;  // 0603FB16 shll8 r3
L_0603FB18:
    c.r[3] += c.r[7];  // 0603FB18 add r7,r3
    c.r[3] += c.r[3];  // 0603FB1A add r3,r3
    c.r[1] = ld32(0x0603FB84u);  // 0603FB1C mov.l 0x0603FB84,r1
    c.r[3] += c.r[1];  // 0603FB1E add r1,r3
    c.r[1] = 0xFu;  // 0603FB20 mov #15,r1
    c.r[1] &= c.r[5];  // 0603FB22 and r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FB24 tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0603FB6E; } }  // 0603FB26 bt/s 0x0603FB6E ; mov r14,r15
L_0603FB2A:
    c.r[1] = c.r[5];  // 0603FB2A mov r5,r1
    c.r[1] -= 1;  // 0603FB2C add #-1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0603FB2E extu.w r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); c.r[6] += 2;  // 0603FB30 mov.w @r6+,r1
    st16(c.r[3], c.r[1]);  // 0603FB32 mov.w r1,@r3
    c.r[1] = 0xFu;  // 0603FB34 mov #15,r1
    c.r[1] &= c.r[5];  // 0603FB36 and r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FB38 tst r1,r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0603FB2A; } }  // 0603FB3A bf/s 0x0603FB2A ; add #2,r3
    c.r[15] = c.r[14]; goto L_0603FB6E;  // 0603FB3E bra 0x0603FB6E ; mov r14,r15
L_0603FB42:
    c.r[3] <<= 8;  // 0603FB42 shll8 r3
    c.r[3] += c.r[7];  // 0603FB44 add r7,r3
    c.r[3] += c.r[3];  // 0603FB46 add r3,r3
    c.r[1] = ld32(0x0603FB84u);  // 0603FB48 mov.l 0x0603FB84,r1
    c.r[3] += c.r[1];  // 0603FB4A add r1,r3
    c.r[1] = ld32(0x0603FB88u);  // 0603FB4C mov.l 0x0603FB88,r1
    c.r[10] <<= 8;  // 0603FB4E shll8 r10
    c.r[10] += c.r[6];  // 0603FB50 add r6,r10
    c.r[10] += c.r[10];  // 0603FB52 add r10,r10
    c.r[6] = ld32(c.r[1]);  // 0603FB54 mov.l @r1,r6
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603FB56 tst r5,r5
    { const bool k = c.t; c.r[6] += c.r[10]; if (k) { goto L_0603FB6C; } }  // 0603FB58 bt/s 0x0603FB6C ; add r10,r6
L_0603FB5C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); c.r[6] += 2;  // 0603FB5C mov.w @r6+,r1
    st16(c.r[3], c.r[1]);  // 0603FB5E mov.w r1,@r3
    c.r[1] = c.r[5];  // 0603FB60 mov r5,r1
    c.r[1] -= 1;  // 0603FB62 add #-1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0603FB64 extu.w r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603FB66 tst r5,r5
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0603FB5C; } }  // 0603FB68 bf/s 0x0603FB5C ; add #2,r3
L_0603FB6C:
    c.r[15] = c.r[14];  // 0603FB6C mov r14,r15
L_0603FB6E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FB6E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603FB70 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603FB72 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FB74 rts ; mov.l @r15+,r8
}

void f_0603FB8C(SH2Context& c) {
    ran[1018] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FB8C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603FB8E mov r15,r14
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603FB90 tst r5,r5
    { const bool k = !c.t; c.r[6] = c.r[4] & 0xFFu; if (k) { goto L_0603FB9A; } }  // 0603FB92 bf/s 0x0603FB9A ; extu.b r4,r6
    c.r[0] = 0xFFFFFFFEu; goto L_0603FBDC;  // 0603FB96 bra 0x0603FBDC ; mov #-2,r0
L_0603FB9A:
    c.r[2] = ld32(0x0603FBE4u);  // 0603FB9A mov.l 0x0603FBE4,r2
    c.r[3] = c.r[6];  // 0603FB9C mov r6,r3
    c.r[3] <<= 2;  // 0603FB9E shll2 r3
    c.r[3] += c.r[3];  // 0603FBA0 add r3,r3
    c.r[3] <<= 2;  // 0603FBA2 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603FBE2u);  // 0603FBA4 mov.w 0x0603FBE2,r1
    c.r[3] &= c.r[1];  // 0603FBA6 and r1,r3
    c.r[7] = ld32(c.r[2]);  // 0603FBA8 mov.l @r2,r7
    c.r[1] = 0x1u;  // 0603FBAA mov #1,r1
    c.r[1] &= c.r[5];  // 0603FBAC and r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FBAE tst r1,r1
    { const bool k = c.t; c.r[7] += c.r[3]; if (k) { goto L_0603FBB8; } }  // 0603FBB0 bt/s 0x0603FBB8 ; add r3,r7
    c.r[0] = 0xFFFFFFFFu; goto L_0603FBDC;  // 0603FBB4 bra 0x0603FBDC ; mov #-1,r0
L_0603FBB8:
    c.r[2] = 0x0u;  // 0603FBB8 mov #0,r2
    c.r[3] = 0x7u;  // 0603FBBA mov #7,r3
    c.r[0] = c.r[2];  // 0603FBBC mov r2,r0
L_0603FBBE:
    c.r[0] <<= 2;  // 0603FBBE shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 0603FBC0 mov.l @(r0,r5),r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0603FBC2 mov.l r1,@(r0,r7)
    c.r[1] = c.r[2];  // 0603FBC4 mov r2,r1
    c.r[1] += 1;  // 0603FBC6 add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0603FBC8 extu.w r1,r2
    c.t = c.r[2] > c.r[3];  // 0603FBCA cmp/hi r3,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0603FBBE; } }  // 0603FBCC bf/s 0x0603FBBE ; mov r2,r0
    c.r[2] = ld32(0x0603FBE8u);  // 0603FBD0 mov.l 0x0603FBE8,r2
    c.r[6] += c.r[6];  // 0603FBD2 add r6,r6
    c.r[1] = 0x1u;  // 0603FBD4 mov #1,r1
    c.r[0] = c.r[2];  // 0603FBD6 mov r2,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 0603FBD8 mov.b r1,@(r0,r6)
    c.r[0] = 0x0u;  // 0603FBDA mov #0,r0
L_0603FBDC:
    c.r[15] = c.r[14];  // 0603FBDC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FBDE rts ; mov.l @r15+,r14
}

void f_0603FBEC(SH2Context& c) {
    ran[1019] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603FBEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603FBEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FBF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603FBF2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603FBF4 mov r15,r14
    c.r[9] = c.r[5];  // 0603FBF6 mov r5,r9
    c.r[2] = c.r[4] & 0xFFu;  // 0603FBF8 extu.b r4,r2
    c.r[1] = 0x3u;  // 0603FBFA mov #3,r1
    c.r[1] &= c.r[9];  // 0603FBFC and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FBFE tst r1,r1
    { const bool k = c.t; c.r[6] = c.r[6] & 0xFFFFu; if (k) { goto L_0603FC08; } }  // 0603FC00 bt/s 0x0603FC08 ; extu.w r6,r6
    c.r[0] = 0xFFFFFFFFu; goto L_0603FCA6;  // 0603FC04 bra 0x0603FCA6 ; mov #-1,r0
L_0603FC08:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0603FC08 tst r9,r9
    { const bool k = c.t; c.r[0] = 0xFFFFFFFEu; if (k) { goto L_0603FCA6; } }  // 0603FC0A bt/s 0x0603FCA6 ; mov #-2,r0
    c.t = (c.r[6] & c.r[6]) == 0;  // 0603FC0E tst r6,r6
    { const bool k = c.t; c.r[0] = 0xFFFFFFFDu; if (k) { goto L_0603FCA6; } }  // 0603FC10 bt/s 0x0603FCA6 ; mov #-3,r0
    c.r[0] = c.r[2];  // 0603FC14 mov r2,r0
    c.r[0] += c.r[6];  // 0603FC16 add r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603FCB2u);  // 0603FC18 mov.w 0x0603FCB2,r1
    c.t = c.r[0] > c.r[1];  // 0603FC1A cmp/hi r1,r0
    { const bool k = !c.t; c.r[0] -= c.r[1]; if (k) { goto L_0603FC28; } }  // 0603FC1C bf/s 0x0603FC28 ; sub r1,r0
    c.r[15] = c.r[14]; goto L_0603FCA8;  // 0603FC20 bra 0x0603FCA8 ; mov r14,r15
L_0603FC24:
    c.r[0] = c.r[3]; goto L_0603FCA6;  // 0603FC24 bra 0x0603FCA6 ; mov r3,r0
L_0603FC28:
    c.r[3] = 0x0u;  // 0603FC28 mov #0,r3
    c.t = c.r[3] >= c.r[6];  // 0603FC2A cmp/hs r6,r3
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0603FC60; } }  // 0603FC2C bt/s 0x0603FC60 ; mov #1,r1
    c.r[7] = ld32(0x0603FCB8u);  // 0603FC30 mov.l 0x0603FCB8,r7
    c.r[0] = c.r[2];  // 0603FC32 mov r2,r0
L_0603FC34:
    c.r[0] += c.r[3];  // 0603FC34 add r3,r0
    c.r[0] += c.r[0];  // 0603FC36 add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0603FC38 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603FC3A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FC3C tst r1,r1
    if (!c.t) { SH2_POLL(c); goto L_0603FC24; }  // 0603FC3E bf 0x0603FC24
    c.r[3] += 1;  // 0603FC40 add #1,r3
    c.t = c.r[3] >= c.r[6];  // 0603FC42 cmp/hs r6,r3
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0603FC34; } }  // 0603FC44 bf/s 0x0603FC34 ; mov r2,r0
    c.r[3] = 0x0u;  // 0603FC48 mov #0,r3
    c.t = c.r[3] >= c.r[6];  // 0603FC4A cmp/hs r6,r3
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0603FC60; } }  // 0603FC4C bt/s 0x0603FC60 ; mov #1,r1
    c.r[7] = ld32(0x0603FCB8u);  // 0603FC50 mov.l 0x0603FCB8,r7
L_0603FC52:
    c.r[0] = c.r[2];  // 0603FC52 mov r2,r0
    c.r[0] += c.r[3];  // 0603FC54 add r3,r0
    c.r[0] += c.r[0];  // 0603FC56 add r0,r0
    c.r[3] += 1;  // 0603FC58 add #1,r3
    c.t = c.r[3] >= c.r[6];  // 0603FC5A cmp/hs r6,r3
    { const bool k = !c.t; st8(c.r[0] + c.r[7], c.r[1]); if (k) { SH2_POLL(c); goto L_0603FC52; } }  // 0603FC5C bf/s 0x0603FC52 ; mov.b r1,@(r0,r7)
L_0603FC60:
    c.r[3] = ld32(0x0603FCBCu);  // 0603FC60 mov.l 0x0603FCBC,r3
    c.r[2] <<= 2;  // 0603FC62 shll2 r2
    c.r[2] += c.r[2];  // 0603FC64 add r2,r2
    c.r[2] <<= 2;  // 0603FC66 shll2 r2
    c.r[1] = ld32(0x0603FCC0u);  // 0603FC68 mov.l 0x0603FCC0,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603FC6A dmuls.l r1,r2
    c.r[5] = ld32(c.r[3]);  // 0603FC6C mov.l @r3,r5
    c.r[8] = ld32(0x0603FCC4u);  // 0603FC6E mov.l 0x0603FCC4,r8
    c.r[1] = ld32(0x0603FCC8u);  // 0603FC70 mov.l 0x0603FCC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FC76u; c.r[4] = c.mach; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FC76u) return; }  // 0603FC72 jsr @r1 ; sts mach,r4
    c.r[1] = c.r[2];  // 0603FC76 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0603FC78 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0603FC7A subc r1,r1
    c.r[4] -= c.r[1];  // 0603FC7C sub r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603FCB4u);  // 0603FC7E mov.w 0x0603FCB4,r1
    c.macl = c.r[4] * c.r[1];  // 0603FC80 mul.l r1,r4
    c.r[7] = 0xEu;  // 0603FC82 mov #14,r7
    c.r[6] <<= 2;  // 0603FC84 shll2 r6
    c.r[6] += c.r[6];  // 0603FC86 add r6,r6
    c.r[6] <<= 2;  // 0603FC88 shll2 r6
    c.r[1] = c.macl;  // 0603FC8A sts macl,r1
    c.r[2] -= c.r[1];  // 0603FC8C sub r1,r2
    c.r[5] += c.r[2];  // 0603FC8E add r2,r5
    c.r[1] = 0x1u;  // 0603FC90 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0603FC92 mov.b r1,@r8
    c.r[1] = ld32(0x0603FCCCu);  // 0603FC94 mov.l 0x0603FCCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FC9Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FC9Au) return; }  // 0603FC96 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x0603FCD0u);  // 0603FC9A mov.l 0x0603FCD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FCA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FCA0u) return; }  // 0603FC9C jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0603FCA0 mov #0,r1
    st8(c.r[8], c.r[1]);  // 0603FCA2 mov.b r1,@r8
    c.r[0] = 0x0u;  // 0603FCA4 mov #0,r0
L_0603FCA6:
    c.r[15] = c.r[14];  // 0603FCA6 mov r14,r15
L_0603FCA8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603FCA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FCAA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603FCAC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FCAE rts ; mov.l @r15+,r8
}

void f_0603FCD4(SH2Context& c) {
    ran[1020] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603FCD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FCD6 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603FCD8 mov r15,r14
    c.r[6] = c.r[6] & 0xFFu;  // 0603FCDA extu.b r6,r6
    c.r[7] = c.r[5] & 0xFFu;  // 0603FCDC extu.b r5,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[6];  // 0603FCDE cmp/ge r6,r7
    { const bool k = c.t; c.r[8] = 0xFFFFFFFFu; if (k) { goto L_0603FD40; } }  // 0603FCE0 bt/s 0x0603FD40 ; mov #-1,r8
    c.r[5] = ld32(0x0603FD4Cu);  // 0603FCE4 mov.l 0x0603FD4C,r5
    c.r[3] = ld32(0x0603FD50u);  // 0603FCE6 mov.l 0x0603FD50,r3
    c.r[2] = c.r[7];  // 0603FCE8 mov r7,r2
    c.r[2] += c.r[2];  // 0603FCEA add r2,r2
L_0603FCEC:
    c.r[0] = c.r[2];  // 0603FCEC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0603FCEE mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603FCF0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FCF2 tst r1,r1
    if (!c.t) { goto L_0603FD38; }  // 0603FCF4 bf 0x0603FD38
    c.r[8] = c.r[7];  // 0603FCF6 mov r7,r8
    c.t = (c.r[4] & c.r[4]) == 0;  // 0603FCF8 tst r4,r4
    { const bool k = c.t; c.r[6] = c.r[8] & 0xFFu; if (k) { goto L_0603FD40; } }  // 0603FCFA bt/s 0x0603FD40 ; extu.b r8,r6
    c.r[1] = c.r[6];  // 0603FCFE mov r6,r1
    c.r[1] <<= 2;  // 0603FD00 shll2 r1
    c.r[1] += c.r[1];  // 0603FD02 add r1,r1
    c.r[1] <<= 2;  // 0603FD04 shll2 r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603FD4Au);  // 0603FD06 mov.w 0x0603FD4A,r2
    c.r[3] = ld32(c.r[3]);  // 0603FD08 mov.l @r3,r3
    c.r[1] &= c.r[2];  // 0603FD0A and r2,r1
    c.r[3] += c.r[1];  // 0603FD0C add r1,r3
    c.r[1] = 0x1u;  // 0603FD0E mov #1,r1
    c.r[1] &= c.r[4];  // 0603FD10 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FD12 tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0603FD40; } }  // 0603FD14 bf/s 0x0603FD40 ; mov #0,r2
    c.r[7] = 0x7u;  // 0603FD18 mov #7,r7
    c.r[0] = c.r[2];  // 0603FD1A mov r2,r0
L_0603FD1C:
    c.r[0] <<= 2;  // 0603FD1C shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[4]);  // 0603FD1E mov.l @(r0,r4),r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0603FD20 mov.l r1,@(r0,r3)
    c.r[1] = c.r[2];  // 0603FD22 mov r2,r1
    c.r[1] += 1;  // 0603FD24 add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0603FD26 extu.w r1,r2
    c.t = c.r[2] > c.r[7];  // 0603FD28 cmp/hi r7,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0603FD1C; } }  // 0603FD2A bf/s 0x0603FD1C ; mov r2,r0
    c.r[6] += c.r[6];  // 0603FD2E add r6,r6
    c.r[1] = 0x1u;  // 0603FD30 mov #1,r1
    c.r[0] = c.r[5];  // 0603FD32 mov r5,r0
    st8(c.r[0] + c.r[6], c.r[1]); goto L_0603FD40;  // 0603FD34 bra 0x0603FD40 ; mov.b r1,@(r0,r6)
L_0603FD38:
    c.r[7] += 1;  // 0603FD38 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[6];  // 0603FD3A cmp/ge r6,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_0603FCEC; } }  // 0603FD3C bf/s 0x0603FCEC ; add #2,r2
L_0603FD40:
    c.r[15] = c.r[14];  // 0603FD40 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FD42 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603FD44 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FD46 rts ; mov.l @r15+,r8
}

void f_0603FD54(SH2Context& c) {
    ran[1021] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603FD54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603FD56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603FD58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603FD5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603FD5C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603FD5E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FD60 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603FD62 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603FD64 mov r15,r14
    c.r[10] = c.r[4];  // 0603FD66 mov r4,r10
    c.r[12] = c.r[6] & 0xFFu;  // 0603FD68 extu.b r6,r12
    c.r[11] = c.r[7] & 0xFFu;  // 0603FD6A extu.b r7,r11
    c.r[8] = c.r[5] & 0xFFu;  // 0603FD6C extu.b r5,r8
    c.r[1] = c.r[12] & 0xFFFFu;  // 0603FD6E extu.w r12,r1
    c.t = c.r[8] >= c.r[1];  // 0603FD70 cmp/hs r1,r8
    { const bool k = c.t; c.r[9] = 0xFFFFFFFFu; if (k) { goto L_0603FE00; } }  // 0603FD72 bt/s 0x0603FE00 ; mov #-1,r9
    c.r[13] = ld32(0x0603FE18u);  // 0603FD76 mov.l 0x0603FE18,r13
    c.r[0] = c.r[8];  // 0603FD78 mov r8,r0
L_0603FD7A:
    c.r[0] += c.r[0];  // 0603FD7A add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0603FD7C mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603FD7E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FD80 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0603FDF2; } }  // 0603FD82 bf/s 0x0603FDF2 ; mov r11,r0
    c.t = c.r[0] == 0x1u;  // 0603FD86 cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = c.r[8]; if (k) { goto L_0603FDD6; } }  // 0603FD88 bf/s 0x0603FDD6 ; mov r8,r9
    c.t = (c.r[10] & c.r[10]) == 0;  // 0603FD8C tst r10,r10
    { const bool k = !c.t; c.r[6] = c.r[9] & 0xFFu; if (k) { goto L_0603FD96; } }  // 0603FD8E bf/s 0x0603FD96 ; extu.b r9,r6
    c.r[1] = 0xFFFFFFFEu; goto L_0603FDE2;  // 0603FD92 bra 0x0603FDE2 ; mov #-2,r1
L_0603FD96:
    c.r[1] = ld32(0x0603FE1Cu);  // 0603FD96 mov.l 0x0603FE1C,r1
    c.r[3] = c.r[6];  // 0603FD98 mov r6,r3
    c.r[3] <<= 2;  // 0603FD9A shll2 r3
    c.r[3] += c.r[3];  // 0603FD9C add r3,r3
    c.r[3] <<= 2;  // 0603FD9E shll2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603FE16u);  // 0603FDA0 mov.w 0x0603FE16,r2
    c.r[3] &= c.r[2];  // 0603FDA2 and r2,r3
    c.r[7] = ld32(c.r[1]);  // 0603FDA4 mov.l @r1,r7
    c.r[0] = c.r[10];  // 0603FDA6 mov r10,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 0603FDA8 tst #1,r0
    { const bool k = c.t; c.r[7] += c.r[3]; if (k) { goto L_0603FDB2; } }  // 0603FDAA bt/s 0x0603FDB2 ; add r3,r7
    c.r[1] = 0xFFFFFFFFu; goto L_0603FDE2;  // 0603FDAE bra 0x0603FDE2 ; mov #-1,r1
L_0603FDB2:
    c.r[2] = 0x0u;  // 0603FDB2 mov #0,r2
    c.r[3] = 0x7u;  // 0603FDB4 mov #7,r3
    c.r[0] = c.r[2];  // 0603FDB6 mov r2,r0
L_0603FDB8:
    c.r[0] <<= 2;  // 0603FDB8 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0603FDBA mov.l @(r0,r10),r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0603FDBC mov.l r1,@(r0,r7)
    c.r[1] = c.r[2];  // 0603FDBE mov r2,r1
    c.r[1] += 1;  // 0603FDC0 add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0603FDC2 extu.w r1,r2
    c.t = c.r[2] > c.r[3];  // 0603FDC4 cmp/hi r3,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0603FDB8; } }  // 0603FDC6 bf/s 0x0603FDB8 ; mov r2,r0
    c.r[6] += c.r[6];  // 0603FDCA add r6,r6
    c.r[1] = 0x1u;  // 0603FDCC mov #1,r1
    c.r[0] = c.r[13];  // 0603FDCE mov r13,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 0603FDD0 mov.b r1,@(r0,r6)
    c.r[1] = 0x0u; goto L_0603FDE2;  // 0603FDD2 bra 0x0603FDE2 ; mov #0,r1
L_0603FDD6:
    c.r[4] = c.r[9] & 0xFFu;  // 0603FDD6 extu.b r9,r4
    c.r[0] = ld32(0x0603FE20u);  // 0603FDD8 mov.l 0x0603FE20,r0
    c.r[6] = c.r[11];  // 0603FDDA mov r11,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603FDE0u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FDE0u) return; }  // 0603FDDC jsr @r0 ; mov r10,r5
    c.r[1] = c.r[0];  // 0603FDE0 mov r0,r1
L_0603FDE2:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603FDE2 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0603FE00; } }  // 0603FDE4 bt/s 0x0603FE00 ; mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0603FDE8 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0603FDF4; } }  // 0603FDEA bf/s 0x0603FDF4 ; mov r8,r1
    c.r[9] = 0xFFFFFFFEu; goto L_0603FE00;  // 0603FDEE bra 0x0603FE00 ; mov #-2,r9
L_0603FDF2:
    c.r[1] = c.r[8];  // 0603FDF2 mov r8,r1
L_0603FDF4:
    c.r[1] += 1;  // 0603FDF4 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0603FDF6 extu.w r1,r8
    c.r[1] = c.r[12] & 0xFFFFu;  // 0603FDF8 extu.w r12,r1
    c.t = c.r[8] >= c.r[1];  // 0603FDFA cmp/hs r1,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_0603FD7A; } }  // 0603FDFC bf/s 0x0603FD7A ; mov r8,r0
L_0603FE00:
    c.r[15] = c.r[14];  // 0603FE00 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603FE02 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE04 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE06 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE08 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE0A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE0C mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0603FE0E mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE10 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FE12 rts ; mov.l @r15+,r8
}

void f_0603FE24(SH2Context& c) {
    ran[1022] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603FE24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FE26 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603FE28 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0603FE2A extu.w r4,r4
    c.r[1] = c.r[4];  // 0603FE2C mov r4,r1
    c.r[5] = c.r[5] & 0xFFFFu;  // 0603FE2E extu.w r5,r5
    c.r[6] = c.r[6] & 0xFFFFu;  // 0603FE30 extu.w r6,r6
    c.r[4] += c.r[5];  // 0603FE32 add r5,r4
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603FE34 extu.w r4,r2
    c.t = c.r[2] >= c.r[6];  // 0603FE36 cmp/hs r6,r2
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_0603FE44; } }  // 0603FE38 bf/s 0x0603FE44 ; mov #0,r8
    c.r[8] = c.r[2];  // 0603FE3C mov r2,r8
    c.r[8] -= c.r[6];  // 0603FE3E sub r6,r8
    c.r[8] -= 1;  // 0603FE40 add #-1,r8
    c.r[2] = c.r[6];  // 0603FE42 mov r6,r2
L_0603FE44:
    c.r[4] = c.r[1];  // 0603FE44 mov r1,r4
    c.t = c.r[4] >= c.r[2];  // 0603FE46 cmp/hs r2,r4
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0603FE62; } }  // 0603FE48 bt/s 0x0603FE62 ; mov r14,r15
    c.r[7] = ld32(0x0603FE6Cu);  // 0603FE4C mov.l 0x0603FE6C,r7
    c.r[3] = 0x0u;  // 0603FE4E mov #0,r3
L_0603FE50:
    c.r[0] = c.r[4];  // 0603FE50 mov r4,r0
    c.r[0] += c.r[0];  // 0603FE52 add r0,r0
    c.r[1] = c.r[4];  // 0603FE54 mov r4,r1
    c.r[1] += 1;  // 0603FE56 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 0603FE58 extu.w r1,r4
    c.t = c.r[4] >= c.r[2];  // 0603FE5A cmp/hs r2,r4
    { const bool k = !c.t; st8(c.r[0] + c.r[7], c.r[3]); if (k) { SH2_POLL(c); goto L_0603FE50; } }  // 0603FE5C bf/s 0x0603FE50 ; mov.b r3,@(r0,r7)
    c.r[15] = c.r[14];  // 0603FE60 mov r14,r15
L_0603FE62:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FE62 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603FE64 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FE66 rts ; mov.l @r15+,r8
}

void f_0603FE70(SH2Context& c) {
    ran[1023] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603FE70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FE72 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603FE74 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603FE76 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0603FE78 extu.w r4,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0603FE7A extu.w r5,r5
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603FE7C exts.w r6,r6
    c.r[8] = 0x1Fu;  // 0603FE7E mov #31,r8
    c.r[8] &= c.r[4];  // 0603FE80 and r4,r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603FF52u);  // 0603FE82 mov.w 0x0603FF52,r2
    c.r[0] = c.r[2];  // 0603FE84 mov r2,r0
    c.r[0] &= c.r[4];  // 0603FE86 and r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603FF54u);  // 0603FE88 mov.w 0x0603FF54,r1
    c.r[7] = c.r[1];  // 0603FE8A mov r1,r7
    c.r[7] &= c.r[4];  // 0603FE8C and r4,r7
    c.r[3] = 0x1Fu;  // 0603FE8E mov #31,r3
    c.r[3] &= c.r[5];  // 0603FE90 and r5,r3
    c.r[4] = c.r[3];  // 0603FE92 mov r3,r4
    c.r[2] &= c.r[5];  // 0603FE94 and r5,r2
    c.t = c.r[8] == c.r[3];  // 0603FE96 cmp/eq r3,r8
    { const bool k = c.t; c.r[5] &= c.r[1]; if (k) { goto L_0603FECE; } }  // 0603FE98 bt/s 0x0603FECE ; and r1,r5
    c.t = c.r[8] >= c.r[3];  // 0603FE9C cmp/hs r3,r8
    { const bool k = c.t; c.t = (int32_t)c.r[6] >= 0; if (k) { goto L_0603FEB6; } }  // 0603FE9E bt/s 0x0603FEB6 ; cmp/pz r6
    { const bool k = !c.t; c.r[3] -= c.r[8]; if (k) { goto L_0603FEB2; } }  // 0603FEA2 bf/s 0x0603FEB2 ; sub r8,r3
    c.macl = c.r[3] * c.r[6];  // 0603FEA6 mul.l r6,r3
    c.r[1] = ld32(0x0603FF58u);  // 0603FEA8 mov.l 0x0603FF58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FEAEu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FEAEu) return; }  // 0603FEAA jsr @r1 ; sts macl,r4
    c.r[8] += c.r[4]; goto L_0603FECA;  // 0603FEAE bra 0x0603FECA ; add r4,r8
L_0603FEB2:
    c.r[8] += 1; goto L_0603FECA;  // 0603FEB2 bra 0x0603FECA ; add #1,r8
L_0603FEB6:
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0603FEC8; } }  // 0603FEB6 bf/s 0x0603FEC8 ; mov r8,r1
    c.r[1] -= c.r[4];  // 0603FEBA sub r4,r1
    c.macl = c.r[1] * c.r[6];  // 0603FEBC mul.l r6,r1
    c.r[1] = ld32(0x0603FF58u);  // 0603FEBE mov.l 0x0603FF58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FEC4u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FEC4u) return; }  // 0603FEC0 jsr @r1 ; sts macl,r4
    c.r[8] -= c.r[4]; goto L_0603FECA;  // 0603FEC4 bra 0x0603FECA ; sub r4,r8
L_0603FEC8:
    c.r[8] -= 1;  // 0603FEC8 add #-1,r8
L_0603FECA:
    c.r[1] = c.r[8] & 0xFFFFu;  // 0603FECA extu.w r8,r1
    c.r[8] = c.r[1];  // 0603FECC mov r1,r8
L_0603FECE:
    c.t = c.r[0] == c.r[2];  // 0603FECE cmp/eq r2,r0
    { const bool k = c.t; c.t = c.r[7] == c.r[5]; if (k) { goto L_0603FF2A; } }  // 0603FED0 bt/s 0x0603FF2A ; cmp/eq r5,r7
    c.t = c.r[0] >= c.r[2];  // 0603FED4 cmp/hs r2,r0
    { const bool k = c.t; c.t = (int32_t)c.r[6] >= 0; if (k) { goto L_0603FF00; } }  // 0603FED6 bt/s 0x0603FF00 ; cmp/pz r6
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0603FEFC; } }  // 0603FEDA bf/s 0x0603FEFC ; mov r2,r1
    c.r[1] -= c.r[0];  // 0603FEDE sub r0,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FEE0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FEE2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FEE4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FEE6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FEE8 shar r1
    c.macl = c.r[1] * c.r[6];  // 0603FEEA mul.l r6,r1
    c.r[1] = ld32(0x0603FF58u);  // 0603FEEC mov.l 0x0603FF58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FEF2u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FEF2u) return; }  // 0603FEEE jsr @r1 ; sts macl,r4
    c.r[4] <<= 2;  // 0603FEF2 shll2 r4
    c.r[4] += c.r[4];  // 0603FEF4 add r4,r4
    c.r[4] <<= 2;  // 0603FEF6 shll2 r4
    c.r[0] += c.r[4]; goto L_0603FF24;  // 0603FEF8 bra 0x0603FF24 ; add r4,r0
L_0603FEFC:
    c.r[0] += 32; goto L_0603FF24;  // 0603FEFC bra 0x0603FF24 ; add #32,r0
L_0603FF00:
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0603FF22; } }  // 0603FF00 bf/s 0x0603FF22 ; mov r0,r1
    c.r[1] -= c.r[2];  // 0603FF04 sub r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FF06 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FF08 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FF0A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FF0C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603FF0E shar r1
    c.macl = c.r[1] * c.r[6];  // 0603FF10 mul.l r6,r1
    c.r[1] = ld32(0x0603FF58u);  // 0603FF12 mov.l 0x0603FF58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FF18u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FF18u) return; }  // 0603FF14 jsr @r1 ; sts macl,r4
    c.r[4] <<= 2;  // 0603FF18 shll2 r4
    c.r[4] += c.r[4];  // 0603FF1A add r4,r4
    c.r[4] <<= 2;  // 0603FF1C shll2 r4
    c.r[0] -= c.r[4]; goto L_0603FF24;  // 0603FF1E bra 0x0603FF24 ; sub r4,r0
L_0603FF22:
    c.r[0] -= 32;  // 0603FF22 add #-32,r0
L_0603FF24:
    c.r[1] = c.r[0] & 0xFFFFu;  // 0603FF24 extu.w r0,r1
    c.r[0] = c.r[1];  // 0603FF26 mov r1,r0
    c.t = c.r[7] == c.r[5];  // 0603FF28 cmp/eq r5,r7
L_0603FF2A:
    { const bool k = c.t; c.t = c.r[7] >= c.r[5]; if (k) { goto L_0603FF82; } }  // 0603FF2A bt/s 0x0603FF82 ; cmp/hs r5,r7
    { const bool k = c.t; c.t = (int32_t)c.r[6] >= 0; if (k) { goto L_0603FF60; } }  // 0603FF2E bt/s 0x0603FF60 ; cmp/pz r6
    { const bool k = !c.t; c.r[5] -= c.r[7]; if (k) { goto L_0603FF4C; } }  // 0603FF32 bf/s 0x0603FF4C ; sub r7,r5
    c.r[1] = ld32(0x0603FF5Cu);  // 0603FF36 mov.l 0x0603FF5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FF3Cu; c.r[4] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FF3Cu) return; }  // 0603FF38 jsr @r1 ; mov r5,r4
    c.macl = c.r[4] * c.r[6];  // 0603FF3C mul.l r6,r4
    c.r[1] = ld32(0x0603FF58u);  // 0603FF3E mov.l 0x0603FF58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FF44u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FF44u) return; }  // 0603FF40 jsr @r1 ; sts macl,r4
    c.r[4] <<= 8;  // 0603FF44 shll8 r4
    c.r[4] <<= 2;  // 0603FF46 shll2 r4
    c.r[7] += c.r[4]; goto L_0603FF7E;  // 0603FF48 bra 0x0603FF7E ; add r4,r7
L_0603FF4C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603FF56u);  // 0603FF4C mov.w 0x0603FF56,r1
    c.r[7] += c.r[1]; goto L_0603FF7E;  // 0603FF4E bra 0x0603FF7E ; add r1,r7
L_0603FF60:
    { const bool k = !c.t; c.r[4] = c.r[7]; if (k) { goto L_0603FF7A; } }  // 0603FF60 bf/s 0x0603FF7A ; mov r7,r4
    c.r[1] = ld32(0x0603FF94u);  // 0603FF64 mov.l 0x0603FF94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FF6Au; c.r[4] -= c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FF6Au) return; }  // 0603FF66 jsr @r1 ; sub r5,r4
    c.macl = c.r[4] * c.r[6];  // 0603FF6A mul.l r6,r4
    c.r[1] = ld32(0x0603FF98u);  // 0603FF6C mov.l 0x0603FF98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603FF72u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FF72u) return; }  // 0603FF6E jsr @r1 ; sts macl,r4
    c.r[4] <<= 8;  // 0603FF72 shll8 r4
    c.r[4] <<= 2;  // 0603FF74 shll2 r4
    c.r[7] -= c.r[4]; goto L_0603FF7E;  // 0603FF76 bra 0x0603FF7E ; sub r4,r7
L_0603FF7A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603FF92u);  // 0603FF7A mov.w 0x0603FF92,r1
    c.r[7] += c.r[1];  // 0603FF7C add r1,r7
L_0603FF7E:
    c.r[1] = c.r[7] & 0xFFFFu;  // 0603FF7E extu.w r7,r1
    c.r[7] = c.r[1];  // 0603FF80 mov r1,r7
L_0603FF82:
    c.r[7] |= c.r[0];  // 0603FF82 or r0,r7
    c.r[15] = c.r[14];  // 0603FF84 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603FF86 lds.l @r15+,pr
    c.r[8] |= c.r[7];  // 0603FF88 or r7,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FF8A mov.l @r15+,r14
    c.r[0] = c.r[8] & 0xFFFFu;  // 0603FF8C extu.w r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603FF8E rts ; mov.l @r15+,r8
}

void f_0603FF9C(SH2Context& c) {
    ran[1024] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603FF9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603FF9E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603FFA0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603FFA2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603FFA4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603FFA6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603FFA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603FFAA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603FFAC mov r15,r14
    c.r[10] = c.r[4] & 0xFFFFu;  // 0603FFAE extu.w r4,r10
    c.r[9] = c.r[5] & 0xFFFFu;  // 0603FFB0 extu.w r5,r9
    c.r[11] = c.r[7] & 0xFFFFu;  // 0603FFB2 extu.w r7,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604000Au);  // 0603FFB4 mov.w 0x0604000A,r1
    c.r[11] &= c.r[1];  // 0603FFB6 and r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604000Cu);  // 0603FFB8 mov.w 0x0604000C,r1
    c.r[10] &= c.r[1];  // 0603FFBA and r1,r10
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604000Cu);  // 0603FFBC mov.w 0x0604000C,r2
    c.r[1] = c.r[2];  // 0603FFBE mov r2,r1
    c.r[1] -= c.r[10];  // 0603FFC0 sub r10,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0603FFC2 cmp/gt r1,r9
    { const bool k = c.t; c.r[13] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_0603FFCA; } }  // 0603FFC4 bt/s 0x0603FFCA ; exts.w r6,r13
    c.r[2] = c.r[9];  // 0603FFC8 mov r9,r2
L_0603FFCA:
    c.r[9] = c.r[2];  // 0603FFCA mov r2,r9
    c.r[12] = ld32(0x06040010u);  // 0603FFCC mov.l 0x06040010,r12
L_0603FFCE:
    c.r[8] = c.r[10];  // 0603FFCE mov r10,r8
    c.r[8] += c.r[8];  // 0603FFD0 add r8,r8
    c.r[0] = c.r[8];  // 0603FFD2 mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 0603FFD4 mov.w @(r0,r12),r4
    c.r[6] = c.r[13];  // 0603FFD6 mov r13,r6
    c.r[5] = c.r[11];  // 0603FFD8 mov r11,r5
    c.r[0] = ld32(0x06040014u);  // 0603FFDA mov.l 0x06040014,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603FFE0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603FFE0u) return; }  // 0603FFDC jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 0603FFE0 mov r0,r1
    c.r[0] = c.r[8];  // 0603FFE2 mov r8,r0
    st16(c.r[0] + c.r[12], c.r[1]);  // 0603FFE4 mov.w r1,@(r0,r12)
    c.r[1] = c.r[9];  // 0603FFE6 mov r9,r1
    c.r[1] -= 1;  // 0603FFE8 add #-1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0603FFEA extu.w r1,r9
    c.r[1] = c.r[10];  // 0603FFEC mov r10,r1
    c.r[1] += 1;  // 0603FFEE add #1,r1
    c.t = (c.r[9] & c.r[9]) == 0;  // 0603FFF0 tst r9,r9
    { const bool k = !c.t; c.r[10] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0603FFCE; } }  // 0603FFF2 bf/s 0x0603FFCE ; extu.w r1,r10
    c.r[15] = c.r[14];  // 0603FFF6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603FFF8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603FFFA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603FFFC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603FFFE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06040000 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06040002 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06040004 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06040006 rts ; mov.l @r15+,r8
}

void f_06040018(SH2Context& c) {
    ran[1025] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06040018 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604001A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604001C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604001E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06040020 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06040022 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06040024 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06040026 sts.l pr,@-r15
    c.r[15] -= 4;  // 06040028 add #-4,r15
    c.r[14] = c.r[15];  // 0604002A mov r15,r14
    c.r[9] = c.r[4] & 0xFFFFu;  // 0604002C extu.w r4,r9
    c.r[11] = c.r[5] & 0xFFFFu;  // 0604002E extu.w r5,r11
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 06040030 exts.w r6,r6
    st32(c.r[14], c.r[6]);  // 06040032 mov.l r6,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060400E0u);  // 06040034 mov.w 0x060400E0,r1
    c.r[9] &= c.r[1];  // 06040036 and r1,r9
    c.r[2] = (uint32_t)(int16_t)ld16(0x060400E0u);  // 06040038 mov.w 0x060400E0,r2
    c.r[1] = c.r[2];  // 0604003A mov r2,r1
    c.r[1] -= c.r[9];  // 0604003C sub r9,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 0604003E cmp/gt r1,r11
    { const bool k = c.t; c.r[10] = c.r[7] & 0xFFFFu; if (k) { goto L_06040046; } }  // 06040040 bt/s 0x06040046 ; extu.w r7,r10
    c.r[2] = c.r[11];  // 06040044 mov r11,r2
L_06040046:
    c.r[11] = c.r[2];  // 06040046 mov r2,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x060400E2u);  // 06040048 mov.w 0x060400E2,r1
    c.r[10] &= c.r[1];  // 0604004A and r1,r10
    c.r[2] = c.r[10];  // 0604004C mov r10,r2
    c.r[2] += c.r[11];  // 0604004E add r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060400E4u);  // 06040050 mov.w 0x060400E4,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06040052 cmp/gt r1,r2
    c.r[1] = ld32(0x060400E8u);  // 06040054 mov.l 0x060400E8,r1
    if (c.t) { goto L_0604005A; }  // 06040056 bt 0x0604005A
    c.r[1] = c.r[10];  // 06040058 mov r10,r1
L_0604005A:
    c.r[10] = c.r[1];  // 0604005A mov r1,r10
    c.r[1] = ld32(0x060400ECu);  // 0604005C mov.l 0x060400EC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604005E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06040060 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06040062 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0x6u; if (k) { goto L_0604008E; } }  // 06040064 bf/s 0x0604008E ; mov #6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060400E6u);  // 06040068 mov.w 0x060400E6,r1
    c.r[1] &= c.r[9];  // 0604006A and r9,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604006C shlr r1
    c.r[2] = ld32(0x060400F0u);  // 0604006E mov.l 0x060400F0,r2
    c.r[1] += c.r[2];  // 06040070 add r2,r1
    c.r[2] = c.r[9];  // 06040072 mov r9,r2
    c.r[2] >>= 2;  // 06040074 shlr2 r2
    c.r[2] >>= 2;  // 06040076 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06040078 shlr r2
    c.r[2] >>= 2;  // 0604007A shlr2 r2
    c.r[2] &= c.r[0];  // 0604007C and r0,r2
    c.r[0] = c.r[2];  // 0604007E mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06040080 mov.w @(r0,r1),r1
    c.r[1] <<= 2;  // 06040082 shll2 r1
    c.r[1] <<= 2;  // 06040084 shll2 r1
    c.r[0] = 0xFu;  // 06040086 mov #15,r0
    c.r[9] &= c.r[0];  // 06040088 and r0,r9
    c.r[1] += c.r[9];  // 0604008A add r9,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0604008C extu.w r1,r9
L_0604008E:
    c.r[12] = ld32(0x060400F4u);  // 0604008E mov.l 0x060400F4,r12
    c.r[13] = ld32(0x060400F8u);  // 06040090 mov.l 0x060400F8,r13
L_06040092:
    c.r[8] = c.r[9];  // 06040092 mov r9,r8
    c.r[8] += c.r[8];  // 06040094 add r8,r8
    c.r[0] = c.r[8];  // 06040096 mov r8,r0
    c.r[1] = ld32(0x060400FCu);  // 06040098 mov.l 0x060400FC,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 0604009A mov.w @(r0,r12),r4
    c.r[2] = c.r[10];  // 0604009C mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 0604009E mov.l @r1,r1
    c.r[2] += c.r[2];  // 060400A0 add r2,r2
    c.r[6] = ld32(c.r[14]);  // 060400A2 mov.l @r14,r6
    c.r[0] = c.r[2];  // 060400A4 mov r2,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060400A6 mov.w @(r0,r1),r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 060400A8 extu.w r4,r4
    { const uint32_t x = c.r[13]; c.pr = 0x060400AEu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060400AEu) return; }  // 060400AA jsr @r13 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 060400AE mov r0,r1
    c.r[0] = c.r[8];  // 060400B0 mov r8,r0
    st16(c.r[0] + c.r[12], c.r[1]);  // 060400B2 mov.w r1,@(r0,r12)
    c.r[1] = c.r[11];  // 060400B4 mov r11,r1
    c.r[1] -= 1;  // 060400B6 add #-1,r1
    c.r[11] = c.r[1] & 0xFFFFu;  // 060400B8 extu.w r1,r11
    c.r[1] = c.r[9];  // 060400BA mov r9,r1
    c.r[1] += 1;  // 060400BC add #1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 060400BE extu.w r1,r9
    c.r[1] = c.r[10];  // 060400C0 mov r10,r1
    c.r[1] += 1;  // 060400C2 add #1,r1
    c.t = (c.r[11] & c.r[11]) == 0;  // 060400C4 tst r11,r11
    { const bool k = !c.t; c.r[10] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06040092; } }  // 060400C6 bf/s 0x06040092 ; extu.w r1,r10
    c.r[14] += 4;  // 060400CA add #4,r14
    c.r[15] = c.r[14];  // 060400CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060400CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060400D0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060400D2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060400D4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060400D6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060400D8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060400DA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060400DC rts ; mov.l @r15+,r8
}

void f_06040100(SH2Context& c) {
    ran[1026] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06040100 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06040102 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06040104 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06040106 extu.w r4,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06040108 extu.w r5,r5
    c.r[8] = c.r[6] & 0xFFFFu;  // 0604010A extu.w r6,r8
    c.r[6] = c.r[4];  // 0604010C mov r4,r6
    c.r[6] >>= 8;  // 0604010E shlr8 r6
    c.r[0] = 0x3u;  // 06040110 mov #3,r0
    c.r[6] &= c.r[0];  // 06040112 and r0,r6
    c.r[3] = c.r[6];  // 06040114 mov r6,r3
    c.r[7] = c.r[4] & 0xFFu;  // 06040116 extu.b r4,r7
    c.r[1] = ld32(0x060401C8u);  // 06040118 mov.l 0x060401C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604011A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604011C extu.b r1,r1
    c.r[0] = c.r[1];  // 0604011E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06040120 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_06040146; } }  // 06040122 bf/s 0x06040146 ; mov r7,r2
    c.r[2] >>= 2;  // 06040126 shlr2 r2
    c.r[2] >>= 2;  // 06040128 shlr2 r2
    c.r[2] <<= 2;  // 0604012A shll2 r2
    c.r[2] += c.r[2];  // 0604012C add r2,r2
    c.r[1] = ld32(0x060401CCu);  // 0604012E mov.l 0x060401CC,r1
    c.r[2] += c.r[1];  // 06040130 add r1,r2
    c.r[6] += c.r[6];  // 06040132 add r6,r6
    c.r[0] = c.r[6];  // 06040134 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06040136 mov.w @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06040138 extu.w r1,r3
    c.r[3] <<= 2;  // 0604013A shll2 r3
    c.r[3] <<= 2;  // 0604013C shll2 r3
    c.r[0] = 0xFu;  // 0604013E mov #15,r0
    c.r[7] &= c.r[0];  // 06040140 and r0,r7
    c.r[3] += c.r[7]; goto L_0604014A;  // 06040142 bra 0x0604014A ; add r7,r3
L_06040146:
    c.r[3] <<= 8;  // 06040146 shll8 r3
    c.r[3] += c.r[2];  // 06040148 add r2,r3
L_0604014A:
    c.r[3] += c.r[3];  // 0604014A add r3,r3
    c.r[1] = ld32(0x060401D0u);  // 0604014C mov.l 0x060401D0,r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604014E tst r8,r8
    { const bool k = c.t; c.r[3] += c.r[1]; if (k) { goto L_06040160; } }  // 06040150 bt/s 0x06040160 ; add r1,r3
    c.r[0] = c.r[8];  // 06040154 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 06040156 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0604018E; } }  // 06040158 bt/s 0x0604018E ; mov r5,r1
    goto L_060401BA;  // 0604015C bra 0x060401BA ; nop
L_06040160:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06040160 mov.w @r3,r1
    c.r[7] = c.r[5];  // 06040162 mov r5,r7
    c.r[7] -= 1;  // 06040164 add #-1,r7
    c.r[6] = c.r[1] & 0xFFFFu;  // 06040166 extu.w r1,r6
    c.r[1] = 0x0u;  // 06040168 mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[7];  // 0604016A cmp/ge r7,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06040184; } }  // 0604016C bt/s 0x06040184 ; mov r3,r2
    c.r[4] = 0x0u;  // 06040170 mov #0,r4
    c.r[7] += c.r[7];  // 06040172 add r7,r7
    c.r[7] += c.r[3];  // 06040174 add r3,r7
L_06040176:
    c.r[2] += 2;  // 06040176 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06040178 mov.w @r2,r1
    c.r[0] = c.r[4];  // 0604017A mov r4,r0
    c.r[4] += 2;  // 0604017C add #2,r4
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 0604017E cmp/ge r7,r2
    { const bool k = !c.t; st16(c.r[0] + c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_06040176; } }  // 06040180 bf/s 0x06040176 ; mov.w r1,@(r0,r3)
L_06040184:
    c.r[5] += c.r[5];  // 06040184 add r5,r5
    c.r[5] += c.r[3];  // 06040186 add r3,r5
    c.r[5] -= 2;  // 06040188 add #-2,r5
    st16(c.r[5], c.r[6]); goto L_060401BA;  // 0604018A bra 0x060401BA ; mov.w r6,@r5
L_0604018E:
    c.r[1] += c.r[1];  // 0604018E add r1,r1
    c.r[1] += c.r[3];  // 06040190 add r3,r1
    c.r[1] -= 2;  // 06040192 add #-2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06040194 mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06040196 extu.w r1,r6
    c.r[1] = c.r[5];  // 06040198 mov r5,r1
    c.r[1] -= 1;  // 0604019A add #-1,r1
    c.t = (int32_t)c.r[1] > 0;  // 0604019C cmp/pl r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_060401B8; } }  // 0604019E bf/s 0x060401B8 ; mov r1,r0
    c.r[0] += c.r[0];  // 060401A2 add r0,r0
    c.r[2] = c.r[0];  // 060401A4 mov r0,r2
    c.r[2] += c.r[3];  // 060401A6 add r3,r2
    c.r[7] = c.r[0];  // 060401A8 mov r0,r7
L_060401AA:
    c.r[2] -= 2;  // 060401AA add #-2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060401AC mov.w @r2,r1
    c.r[0] = c.r[7];  // 060401AE mov r7,r0
    c.r[7] -= 2;  // 060401B0 add #-2,r7
    c.t = (int32_t)c.r[7] > 0;  // 060401B2 cmp/pl r7
    { const bool k = c.t; st16(c.r[0] + c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_060401AA; } }  // 060401B4 bt/s 0x060401AA ; mov.w r1,@(r0,r3)
L_060401B8:
    st16(c.r[3], c.r[6]);  // 060401B8 mov.w r6,@r3
L_060401BA:
    c.r[2] = ld32(0x060401D4u);  // 060401BA mov.l 0x060401D4,r2
    c.r[1] = 0x1u;  // 060401BC mov #1,r1
    st16(c.r[2], c.r[1]);  // 060401BE mov.w r1,@r2
    c.r[15] = c.r[14];  // 060401C0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060401C2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060401C4 rts ; mov.l @r15+,r8
}

void f_060401D8(SH2Context& c) {
    ran[1027] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060401D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060401DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060401DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060401DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060401E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060401E2 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060401E4 mov r15,r14
    c.r[9] = c.r[6];  // 060401E6 mov r6,r9
    c.r[4] = c.r[4] & 0xFFFFu;  // 060401E8 extu.w r4,r4
    c.r[10] = c.r[5] & 0xFFFFu;  // 060401EA extu.w r5,r10
    c.r[5] = 0x0u;  // 060401EC mov #0,r5
    c.t = c.r[5] >= c.r[10];  // 060401EE cmp/hs r10,r5
    { const bool k = c.t; c.r[6] = c.r[7]; if (k) { goto L_0604023E; } }  // 060401F0 bt/s 0x0604023E ; mov r7,r6
    c.r[12] = 0x7u;  // 060401F4 mov #7,r12
    c.r[11] = 0x20u;  // 060401F6 mov #32,r11
    c.r[7] = 0x0u;  // 060401F8 mov #0,r7
L_060401FA:
    c.t = c.r[7] >= c.r[4];  // 060401FA cmp/hs r4,r7
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_06040234; } }  // 060401FC bt/s 0x06040234 ; mov r5,r1
L_06040200:
    c.r[2] = 0x0u;  // 06040200 mov #0,r2
    c.r[8] = c.r[7];  // 06040202 mov r7,r8
    c.r[8] <<= 2;  // 06040204 shll2 r8
L_06040206:
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[4] & 0xFFFFu);  // 06040206 mulu.w r4,r2
    c.r[3] = c.macl;  // 06040208 sts macl,r3
    c.macl = (c.r[5] & 0xFFFFu) * (c.r[4] & 0xFFFFu);  // 0604020A mulu.w r4,r5
    c.r[3] <<= 2;  // 0604020C shll2 r3
    c.r[1] = c.macl;  // 0604020E sts macl,r1
    c.macl = c.r[1] * c.r[11];  // 06040210 mul.l r11,r1
    c.r[3] += c.r[9];  // 06040212 add r9,r3
    c.r[3] += c.r[8];  // 06040214 add r8,r3
    c.r[0] = c.macl;  // 06040216 sts macl,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06040218 mov.l @(r0,r3),r1
    st32(c.r[6], c.r[1]);  // 0604021A mov.l r1,@r6
    c.r[1] = c.r[2];  // 0604021C mov r2,r1
    c.r[1] += 1;  // 0604021E add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06040220 extu.w r1,r2
    c.t = c.r[2] > c.r[12];  // 06040222 cmp/hi r12,r2
    { const bool k = !c.t; c.r[6] += 4; if (k) { SH2_POLL(c); goto L_06040206; } }  // 06040224 bf/s 0x06040206 ; add #4,r6
    c.r[1] = c.r[7];  // 06040228 mov r7,r1
    c.r[1] += 1;  // 0604022A add #1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 0604022C extu.w r1,r7
    c.t = c.r[7] >= c.r[4];  // 0604022E cmp/hs r4,r7
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { SH2_POLL(c); goto L_06040200; } }  // 06040230 bf/s 0x06040200 ; mov r5,r1
L_06040234:
    c.r[1] += 1;  // 06040234 add #1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 06040236 extu.w r1,r5
    c.t = c.r[5] >= c.r[10];  // 06040238 cmp/hs r10,r5
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { SH2_POLL(c); goto L_060401FA; } }  // 0604023A bf/s 0x060401FA ; mov #0,r7
L_0604023E:
    c.r[15] = c.r[14];  // 0604023E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06040240 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06040242 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06040244 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06040246 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06040248 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604024A rts ; mov.l @r15+,r8
}

void f_06040254(SH2Context& c) {
    ran[1028] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06040254 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06040256 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06040258 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604025A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604025C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604025E mov r15,r14
    c.r[8] = c.r[4];  // 06040260 mov r4,r8
    c.r[9] = c.r[5];  // 06040262 mov r5,r9
    c.r[10] = c.r[6];  // 06040264 mov r6,r10
    c.r[5] = ld32(0x060402B4u);  // 06040266 mov.l 0x060402B4,r5
    c.r[0] = ld32(0x060402B8u);  // 06040268 mov.l 0x060402B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604026Eu; c.r[6] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604026Eu) return; }  // 0604026A jsr @r0 ; mov #3,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604026E tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060402A2; } }  // 06040270 bf/s 0x060402A2 ; mov r8,r1
    c.r[1] += 3;  // 06040274 add #3,r1
    c.r[8] += 4;  // 06040276 add #4,r8
    c.r[0] = ld32(0x060402BCu);  // 06040278 mov.l 0x060402BC,r0
    c.r[5] = c.r[9];  // 0604027A mov r9,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604027C mov.b @r1,r1
    c.r[4] = c.r[8];  // 0604027E mov r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06040284u; st8(c.r[10], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040284u) return; }  // 06040280 jsr @r0 ; mov.b r1,@r10
    c.r[2] = c.r[10];  // 06040284 mov r10,r2
    c.r[1] = c.r[9];  // 06040286 mov r9,r1
    c.r[1] += 2;  // 06040288 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604028A mov.b @r1,r1
    c.r[2] += 1;  // 0604028C add #1,r2
    st8(c.r[2], c.r[1]);  // 0604028E mov.b r1,@r2
    c.r[2] = c.r[10];  // 06040290 mov r10,r2
    c.r[2] += 2;  // 06040292 add #2,r2
    c.r[1] = c.r[9];  // 06040294 mov r9,r1
    c.r[1] += 3;  // 06040296 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040298 mov.b @r1,r1
    c.r[9] += 4;  // 0604029A add #4,r9
    st8(c.r[2], c.r[1]);  // 0604029C mov.b r1,@r2
    st32(c.r[10] + 4, c.r[9]); goto L_060402A4;  // 0604029E bra 0x060402A4 ; mov.l r9,@(4,r10)
L_060402A2:
    c.r[0] = 0x0u;  // 060402A2 mov #0,r0
L_060402A4:
    c.r[15] = c.r[14];  // 060402A4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060402A6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060402A8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060402AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060402AC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060402AE rts ; mov.l @r15+,r8
}

void f_060402C0(SH2Context& c) {
    ran[1029] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060402C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060402C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060402C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060402C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060402C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060402CA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060402CC mov.l r14,@-r15
    c.r[15] -= 56;  // 060402CE add #-56,r15
    c.r[14] = c.r[15];  // 060402D0 mov r15,r14
    c.r[0] = 0x54u;  // 060402D2 mov #84,r0
    c.r[0] += c.r[14];  // 060402D4 add r14,r0
    c.r[13] = 0x58u;  // 060402D6 mov #88,r13
    c.r[13] += c.r[14];  // 060402D8 add r14,r13
    c.r[4] = c.r[4] & 0xFFFFu;  // 060402DA extu.w r4,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 060402DC extu.w r5,r5
    c.r[6] = c.r[6] & 0xFFu;  // 060402DE extu.b r6,r6
    c.r[1] = ld32(c.r[0]);  // 060402E0 mov.l @r0,r1
    c.r[4] <<= 2;  // 060402E2 shll2 r4
    c.r[4] += c.r[4];  // 060402E4 add r4,r4
    c.r[2] = ld32(c.r[13]);  // 060402E6 mov.l @r13,r2
    c.r[0] = 0x5Cu;  // 060402E8 mov #92,r0
    c.r[0] += c.r[14];  // 060402EA add r14,r0
    c.r[3] = c.r[1] & 0xFFu;  // 060402EC extu.b r1,r3
    c.r[8] = ld32(c.r[0]);  // 060402EE mov.l @r0,r8
    c.r[9] = c.r[2] & 0xFFu;  // 060402F0 extu.b r2,r9
    c.r[12] = ld32(c.r[8] + 4);  // 060402F2 mov.l @(4,r8),r12
    st32(c.r[14], c.r[5]);  // 060402F4 mov.l r5,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060402F6 mov.b @r8,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060402F8 extu.b r1,r2
    c.r[0] = c.r[2];  // 060402FA mov r2,r0
    c.t = c.r[0] == 0x31u;  // 060402FC cmp/eq #49,r0
    { const bool k = c.t; c.r[12] += c.r[4]; if (k) { goto L_0604031A; } }  // 060402FE bt/s 0x0604031A ; add r4,r12
    c.r[1] = 0x31u;  // 06040302 mov #49,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06040304 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x32u; if (k) { goto L_0604030E; } }  // 06040306 bt/s 0x0604030E ; cmp/eq #50,r0
    goto L_06040B1E;  // 0604030A bra 0x06040B1E ; nop
L_0604030E:
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { goto L_06040316; } }  // 0604030E bf/s 0x06040316 ; mov r6,r0
    goto L_06040726;  // 06040312 bra 0x06040726 ; nop
L_06040316:
    c.r[14] += 56; goto L_06040B20;  // 06040316 bra 0x06040B20 ; add #56,r14
L_0604031A:
    c.r[0] = c.r[6];  // 0604031A mov r6,r0
    c.r[0] &= 0x3u;  // 0604031C and #3,r0
    c.r[10] = c.r[0];  // 0604031E mov r0,r10
    c.r[10] <<= 8;  // 06040320 shll8 r10
    c.r[10] <<= 2;  // 06040322 shll2 r10
    c.r[11] = ld32(c.r[8] + 4);  // 06040324 mov.l @(4,r8),r11
    c.r[1] = ld32(c.r[12]);  // 06040326 mov.l @r12,r1
    c.r[11] -= 8;  // 06040328 add #-8,r11
    c.r[11] += c.r[1];  // 0604032A add r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040440u);  // 0604032C mov.w 0x06040440,r1
    c.r[1] &= c.r[6];  // 0604032E and r6,r1
    c.r[1] <<= 8;  // 06040330 shll8 r1
    st32(c.r[14] + 4, c.r[1]);  // 06040332 mov.l r1,@(4,r14)
    c.r[6] = c.r[0] & 0xFFu;  // 06040334 extu.b r0,r6
    c.r[1] = 0x3u;  // 06040336 mov #3,r1
    c.t = c.r[6] > c.r[1];  // 06040338 cmp/hi r1,r6
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06040342; } }  // 0604033A bf/s 0x06040342 ; mov #0,r4
    goto L_06040B1E;  // 0604033E bra 0x06040B1E ; nop
L_06040342:
    c.r[1] = c.r[6];  // 06040342 mov r6,r1
    c.r[1] += c.r[1];  // 06040344 add r1,r1
    c.r[0] = 0x06040350u;  // 06040346 mova 0x06040350,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06040348 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604034A add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06040358u: goto L_06040358; case 0x06040448u: goto L_06040448; case 0x0604053Au: goto L_0604053A; case 0x0604062Eu: goto L_0604062E; default: sh2_call(c, x); return; } }  // 0604034C jmp @r0 ; nop
L_06040358:
    c.r[13] = 0x3Fu;  // 06040358 mov #63,r13
    c.r[13] &= c.r[3];  // 0604035A and r3,r13
    st32(c.r[14] + 52, c.r[13]);  // 0604035C mov.l r13,@(52,r14)
    c.r[8] = 0x3Fu;  // 0604035E mov #63,r8
    c.r[1] = c.r[12];  // 06040360 mov r12,r1
    c.r[1] += 6;  // 06040362 add #6,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040364 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06040366 extu.b r3,r2
    c.r[1] = 0x3Fu;  // 06040368 mov #63,r1
    c.r[1] ^= c.r[13];  // 0604036A xor r13,r1
    c.r[1] += 1;  // 0604036C add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604036E cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] &= c.r[9]; if (k) { goto L_06040376; } }  // 06040370 bf/s 0x06040376 ; and r9,r8
    c.r[1] = c.r[2];  // 06040374 mov r2,r1
L_06040376:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06040376 extu.w r1,r9
    c.r[1] = c.r[3] & 0xFFu;  // 06040378 extu.b r3,r1
    c.r[1] -= c.r[9];  // 0604037A sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604037C extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604037E mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 06040380 mov r8,r5
    c.r[5] <<= 2;  // 06040382 shll2 r5
    c.r[5] <<= 2;  // 06040384 shll2 r5
    c.r[5] += c.r[5];  // 06040386 add r5,r5
    c.r[5] <<= 2;  // 06040388 shll2 r5
    c.r[1] = c.r[12];  // 0604038A mov r12,r1
    c.r[1] += 7;  // 0604038C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604038E mov.b @r1,r1
    c.r[8] = 0x0u;  // 06040390 mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06040392 extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040394 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_0604039E; } }  // 06040396 bf/s 0x0604039E ; add r7,r5
    goto L_06040B1E;  // 0604039A bra 0x06040B1E ; nop
L_0604039E:
    c.r[0] = ld32(c.r[14] + 4);  // 0604039E mov.l @(4,r14),r0
    c.r[13] = ld32(c.r[14]);  // 060403A0 mov.l @r14,r13
    c.r[0] += c.r[13];  // 060403A2 add r13,r0
    st32(c.r[14] + 16, c.r[0]);  // 060403A4 mov.l r0,@(16,r14)
L_060403A6:
    c.r[1] = c.r[9];  // 060403A6 mov r9,r1
    c.r[1] -= 1;  // 060403A8 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060403AA extu.w r1,r3
    c.r[0] = ld32(c.r[14] + 52);  // 060403AC mov.l @(52,r14),r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 060403AE tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 060403B0 mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[0]); if (k) { goto L_060403E6; } }  // 060403B2 bt/s 0x060403E6 ; mov.l r0,@(48,r14)
L_060403B6:
    c.r[2] = ld32(c.r[14] + 48);  // 060403B6 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060403B8 mov r4,r7
    c.r[13] = ld32(c.r[14] + 16);  // 060403BA mov.l @(16,r14),r13
    c.r[1] = c.r[2];  // 060403BC mov r2,r1
    c.r[1] += 1;  // 060403BE add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060403C0 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060403C2 mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060403C4 add r2,r2
    c.r[1] = c.r[4];  // 060403C6 mov r4,r1
    c.r[1] += 1;  // 060403C8 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060403CA extu.w r1,r4
    c.r[7] += c.r[7];  // 060403CC add r7,r7
    c.r[0] = c.r[7];  // 060403CE mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060403D0 mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 060403D2 add r13,r1
    c.r[1] ^= c.r[10];  // 060403D4 xor r10,r1
    c.r[0] = c.r[2];  // 060403D6 mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 060403D8 mov.w r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060403DA mov r3,r2
    c.r[1] = c.r[2];  // 060403DC mov r2,r1
    c.r[1] -= 1;  // 060403DE add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060403E0 tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060403B6; } }  // 060403E2 bf/s 0x060403B6 ; extu.w r1,r3
L_060403E6:
    c.r[13] = 0x0u;  // 060403E6 mov #0,r13
    st32(c.r[14] + 48, c.r[13]); goto L_06040410;  // 060403E8 bra 0x06040410 ; mov.l r13,@(48,r14)
L_060403EC:
    c.r[2] = ld32(c.r[14] + 48);  // 060403EC mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060403EE mov r4,r3
    c.r[13] = ld32(c.r[14] + 16);  // 060403F0 mov.l @(16,r14),r13
    c.r[1] = c.r[2];  // 060403F2 mov r2,r1
    c.r[1] += 1;  // 060403F4 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060403F6 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060403F8 mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060403FA add r2,r2
    c.r[1] = c.r[4];  // 060403FC mov r4,r1
    c.r[1] += 1;  // 060403FE add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06040400 extu.w r1,r4
    c.r[3] += c.r[3];  // 06040402 add r3,r3
    c.r[0] = c.r[3];  // 06040404 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 06040406 mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 06040408 add r13,r1
    c.r[1] ^= c.r[10];  // 0604040A xor r10,r1
    c.r[0] = c.r[2];  // 0604040C mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 0604040E mov.w r1,@(r0,r5)
L_06040410:
    c.r[2] = c.r[6];  // 06040410 mov r6,r2
    c.r[1] = c.r[2];  // 06040412 mov r2,r1
    c.r[1] -= 1;  // 06040414 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040416 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060403EC; } }  // 06040418 bf/s 0x060403EC ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06040442u);  // 0604041C mov.w 0x06040442,r2
    c.r[2] &= c.r[5];  // 0604041E and r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040444u);  // 06040420 mov.w 0x06040444,r1
    c.r[5] += c.r[1];  // 06040422 add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040446u);  // 06040424 mov.w 0x06040446,r1
    c.r[5] &= c.r[1];  // 06040426 and r1,r5
    c.r[1] = c.r[8];  // 06040428 mov r8,r1
    c.r[1] += 1;  // 0604042A add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0604042C extu.w r1,r8
    c.r[1] = c.r[12];  // 0604042E mov r12,r1
    c.r[1] += 7;  // 06040430 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040432 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06040434 extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040436 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_060403A6; } }  // 06040438 bf/s 0x060403A6 ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 0604043C bra 0x06040B20 ; add #56,r14
L_06040448:
    c.r[1] = c.r[12];  // 06040448 mov r12,r1
    c.r[1] += 6;  // 0604044A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604044C mov.b @r1,r1
    c.r[8] = 0x3Fu;  // 0604044E mov #63,r8
    c.r[8] &= c.r[9];  // 06040450 and r9,r8
    c.r[6] = c.r[1] & 0xFFu;  // 06040452 extu.b r1,r6
    c.r[3] += c.r[6];  // 06040454 add r6,r3
    st32(c.r[14] + 52, c.r[3]);  // 06040456 mov.l r3,@(52,r14)
    c.r[13] = c.r[3];  // 06040458 mov r3,r13
    c.r[13] -= 1;  // 0604045A add #-1,r13
    st32(c.r[14] + 52, c.r[13]);  // 0604045C mov.l r13,@(52,r14)
    c.r[0] = c.r[13];  // 0604045E mov r13,r0
    c.r[0] &= 0x3Fu;  // 06040460 and #63,r0
    c.r[2] = c.r[1] & 0xFFu;  // 06040462 extu.b r1,r2
    c.r[1] = c.r[0];  // 06040464 mov r0,r1
    c.r[1] += 1;  // 06040466 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06040468 cmp/gt r2,r1
    { const bool k = !c.t; st32(c.r[14] + 52, c.r[0]); if (k) { goto L_06040470; } }  // 0604046A bf/s 0x06040470 ; mov.l r0,@(52,r14)
    c.r[1] = c.r[2];  // 0604046E mov r2,r1
L_06040470:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06040470 extu.w r1,r9
    c.r[1] = c.r[6];  // 06040472 mov r6,r1
    c.r[1] -= c.r[9];  // 06040474 sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06040476 extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06040478 mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 0604047A mov r8,r5
    c.r[5] <<= 2;  // 0604047C shll2 r5
    c.r[5] <<= 2;  // 0604047E shll2 r5
    c.r[5] += c.r[5];  // 06040480 add r5,r5
    c.r[5] <<= 2;  // 06040482 shll2 r5
    c.r[1] = c.r[12];  // 06040484 mov r12,r1
    c.r[1] += 7;  // 06040486 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040488 mov.b @r1,r1
    c.r[8] = 0x0u;  // 0604048A mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604048C extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 0604048E cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_06040498; } }  // 06040490 bf/s 0x06040498 ; add r7,r5
    goto L_06040B1E;  // 06040494 bra 0x06040B1E ; nop
L_06040498:
    c.r[13] = ld32(c.r[14] + 4);  // 06040498 mov.l @(4,r14),r13
    c.r[0] = ld32(c.r[14]);  // 0604049A mov.l @r14,r0
    c.r[13] += c.r[0];  // 0604049C add r0,r13
    st32(c.r[14] + 20, c.r[13]);  // 0604049E mov.l r13,@(20,r14)
L_060404A0:
    c.r[1] = c.r[9];  // 060404A0 mov r9,r1
    c.r[1] -= 1;  // 060404A2 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060404A4 extu.w r1,r3
    c.r[13] = ld32(c.r[14] + 52);  // 060404A6 mov.l @(52,r14),r13
    c.t = (c.r[9] & c.r[9]) == 0;  // 060404A8 tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 060404AA mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[13]); if (k) { goto L_060404E0; } }  // 060404AC bt/s 0x060404E0 ; mov.l r13,@(48,r14)
L_060404B0:
    c.r[2] = ld32(c.r[14] + 48);  // 060404B0 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060404B2 mov r4,r7
    c.r[13] = ld32(c.r[14] + 20);  // 060404B4 mov.l @(20,r14),r13
    c.r[1] = c.r[2];  // 060404B6 mov r2,r1
    c.r[1] -= 1;  // 060404B8 add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060404BA extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060404BC mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060404BE add r2,r2
    c.r[1] = c.r[4];  // 060404C0 mov r4,r1
    c.r[1] += 1;  // 060404C2 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060404C4 extu.w r1,r4
    c.r[7] += c.r[7];  // 060404C6 add r7,r7
    c.r[0] = c.r[7];  // 060404C8 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060404CA mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 060404CC add r13,r1
    c.r[1] ^= c.r[10];  // 060404CE xor r10,r1
    c.r[0] = c.r[2];  // 060404D0 mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 060404D2 mov.w r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060404D4 mov r3,r2
    c.r[1] = c.r[2];  // 060404D6 mov r2,r1
    c.r[1] -= 1;  // 060404D8 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060404DA tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060404B0; } }  // 060404DC bf/s 0x060404B0 ; extu.w r1,r3
L_060404E0:
    c.r[13] = 0x0u;  // 060404E0 mov #0,r13
    st32(c.r[14] + 48, c.r[13]); goto L_0604050A;  // 060404E2 bra 0x0604050A ; mov.l r13,@(48,r14)
L_060404E6:
    c.r[2] = ld32(c.r[14] + 48);  // 060404E6 mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060404E8 mov r4,r3
    c.r[13] = ld32(c.r[14] + 20);  // 060404EA mov.l @(20,r14),r13
    c.r[1] = c.r[2];  // 060404EC mov r2,r1
    c.r[1] -= 1;  // 060404EE add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060404F0 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060404F2 mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060404F4 add r2,r2
    c.r[1] = c.r[4];  // 060404F6 mov r4,r1
    c.r[1] += 1;  // 060404F8 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060404FA extu.w r1,r4
    c.r[3] += c.r[3];  // 060404FC add r3,r3
    c.r[0] = c.r[3];  // 060404FE mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 06040500 mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 06040502 add r13,r1
    c.r[1] ^= c.r[10];  // 06040504 xor r10,r1
    c.r[0] = c.r[2];  // 06040506 mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 06040508 mov.w r1,@(r0,r5)
L_0604050A:
    c.r[2] = c.r[6];  // 0604050A mov r6,r2
    c.r[1] = c.r[2];  // 0604050C mov r2,r1
    c.r[1] -= 1;  // 0604050E add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040510 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060404E6; } }  // 06040512 bf/s 0x060404E6 ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06040628u);  // 06040516 mov.w 0x06040628,r2
    c.r[2] &= c.r[5];  // 06040518 and r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604062Au);  // 0604051A mov.w 0x0604062A,r1
    c.r[5] += c.r[1];  // 0604051C add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604062Cu);  // 0604051E mov.w 0x0604062C,r1
    c.r[5] &= c.r[1];  // 06040520 and r1,r5
    c.r[1] = c.r[8];  // 06040522 mov r8,r1
    c.r[1] += 1;  // 06040524 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06040526 extu.w r1,r8
    c.r[1] = c.r[12];  // 06040528 mov r12,r1
    c.r[1] += 7;  // 0604052A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604052C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604052E extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040530 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_060404A0; } }  // 06040532 bf/s 0x060404A0 ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 06040536 bra 0x06040B20 ; add #56,r14
L_0604053A:
    c.r[13] = 0x3Fu;  // 0604053A mov #63,r13
    c.r[13] &= c.r[3];  // 0604053C and r3,r13
    st32(c.r[14] + 52, c.r[13]);  // 0604053E mov.l r13,@(52,r14)
    c.r[1] = c.r[12];  // 06040540 mov r12,r1
    c.r[1] += 7;  // 06040542 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040544 mov.b @r1,r1
    c.r[0] = 0x3Fu;  // 06040546 mov #63,r0
    c.r[6] = c.r[1] & 0xFFu;  // 06040548 extu.b r1,r6
    c.r[8] = c.r[6];  // 0604054A mov r6,r8
    c.r[8] += c.r[9];  // 0604054C add r9,r8
    c.r[8] -= 1;  // 0604054E add #-1,r8
    c.r[1] = c.r[12];  // 06040550 mov r12,r1
    c.r[1] += 6;  // 06040552 add #6,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040554 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06040556 extu.b r3,r2
    c.r[1] = 0x3Fu;  // 06040558 mov #63,r1
    c.r[1] ^= c.r[13];  // 0604055A xor r13,r1
    c.r[1] += 1;  // 0604055C add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604055E cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] &= c.r[0]; if (k) { goto L_06040566; } }  // 06040560 bf/s 0x06040566 ; and r0,r8
    c.r[1] = c.r[2];  // 06040564 mov r2,r1
L_06040566:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06040566 extu.w r1,r9
    c.r[1] = c.r[3] & 0xFFu;  // 06040568 extu.b r3,r1
    c.r[1] -= c.r[9];  // 0604056A sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604056C extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604056E mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 06040570 mov r8,r5
    c.r[5] <<= 2;  // 06040572 shll2 r5
    c.r[5] <<= 2;  // 06040574 shll2 r5
    c.r[5] += c.r[5];  // 06040576 add r5,r5
    c.r[5] <<= 2;  // 06040578 shll2 r5
    c.r[8] = 0x0u;  // 0604057A mov #0,r8
    c.r[1] = c.r[6] & 0xFFFFu;  // 0604057C extu.w r6,r1
    c.t = c.r[8] >= c.r[1];  // 0604057E cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_06040588; } }  // 06040580 bf/s 0x06040588 ; add r7,r5
    goto L_06040B1E;  // 06040584 bra 0x06040B1E ; nop
L_06040588:
    c.r[13] = ld32(c.r[14] + 4);  // 06040588 mov.l @(4,r14),r13
    c.r[0] = ld32(c.r[14]);  // 0604058A mov.l @r14,r0
    c.r[13] += c.r[0];  // 0604058C add r0,r13
    st32(c.r[14] + 24, c.r[13]);  // 0604058E mov.l r13,@(24,r14)
L_06040590:
    c.r[1] = c.r[9];  // 06040590 mov r9,r1
    c.r[1] -= 1;  // 06040592 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06040594 extu.w r1,r3
    c.r[13] = ld32(c.r[14] + 52);  // 06040596 mov.l @(52,r14),r13
    c.t = (c.r[9] & c.r[9]) == 0;  // 06040598 tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 0604059A mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[13]); if (k) { goto L_060405D0; } }  // 0604059C bt/s 0x060405D0 ; mov.l r13,@(48,r14)
L_060405A0:
    c.r[2] = ld32(c.r[14] + 48);  // 060405A0 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060405A2 mov r4,r7
    c.r[13] = ld32(c.r[14] + 24);  // 060405A4 mov.l @(24,r14),r13
    c.r[1] = c.r[2];  // 060405A6 mov r2,r1
    c.r[1] += 1;  // 060405A8 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060405AA extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060405AC mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060405AE add r2,r2
    c.r[1] = c.r[4];  // 060405B0 mov r4,r1
    c.r[1] += 1;  // 060405B2 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060405B4 extu.w r1,r4
    c.r[7] += c.r[7];  // 060405B6 add r7,r7
    c.r[0] = c.r[7];  // 060405B8 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060405BA mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 060405BC add r13,r1
    c.r[1] ^= c.r[10];  // 060405BE xor r10,r1
    c.r[0] = c.r[2];  // 060405C0 mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 060405C2 mov.w r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060405C4 mov r3,r2
    c.r[1] = c.r[2];  // 060405C6 mov r2,r1
    c.r[1] -= 1;  // 060405C8 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060405CA tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060405A0; } }  // 060405CC bf/s 0x060405A0 ; extu.w r1,r3
L_060405D0:
    c.r[13] = 0x0u;  // 060405D0 mov #0,r13
    st32(c.r[14] + 48, c.r[13]); goto L_060405FA;  // 060405D2 bra 0x060405FA ; mov.l r13,@(48,r14)
L_060405D6:
    c.r[2] = ld32(c.r[14] + 48);  // 060405D6 mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060405D8 mov r4,r3
    c.r[13] = ld32(c.r[14] + 24);  // 060405DA mov.l @(24,r14),r13
    c.r[1] = c.r[2];  // 060405DC mov r2,r1
    c.r[1] += 1;  // 060405DE add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060405E0 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060405E2 mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060405E4 add r2,r2
    c.r[1] = c.r[4];  // 060405E6 mov r4,r1
    c.r[1] += 1;  // 060405E8 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060405EA extu.w r1,r4
    c.r[3] += c.r[3];  // 060405EC add r3,r3
    c.r[0] = c.r[3];  // 060405EE mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060405F0 mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 060405F2 add r13,r1
    c.r[1] ^= c.r[10];  // 060405F4 xor r10,r1
    c.r[0] = c.r[2];  // 060405F6 mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 060405F8 mov.w r1,@(r0,r5)
L_060405FA:
    c.r[2] = c.r[6];  // 060405FA mov r6,r2
    c.r[1] = c.r[2];  // 060405FC mov r2,r1
    c.r[1] -= 1;  // 060405FE add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040600 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060405D6; } }  // 06040602 bf/s 0x060405D6 ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06040628u);  // 06040606 mov.w 0x06040628,r2
    c.r[2] &= c.r[5];  // 06040608 and r5,r2
    c.r[5] -= 128;  // 0604060A add #-128,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604062Cu);  // 0604060C mov.w 0x0604062C,r1
    c.r[5] &= c.r[1];  // 0604060E and r1,r5
    c.r[1] = c.r[8];  // 06040610 mov r8,r1
    c.r[1] += 1;  // 06040612 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06040614 extu.w r1,r8
    c.r[1] = c.r[12];  // 06040616 mov r12,r1
    c.r[1] += 7;  // 06040618 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604061A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604061C extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 0604061E cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_06040590; } }  // 06040620 bf/s 0x06040590 ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 06040624 bra 0x06040B20 ; add #56,r14
L_0604062E:
    c.r[1] = c.r[12];  // 0604062E mov r12,r1
    c.r[1] += 6;  // 06040630 add #6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040632 mov.b @r1,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06040634 extu.b r2,r6
    c.r[3] += c.r[6];  // 06040636 add r6,r3
    st32(c.r[14] + 52, c.r[3]);  // 06040638 mov.l r3,@(52,r14)
    c.r[13] = c.r[3];  // 0604063A mov r3,r13
    c.r[13] -= 1;  // 0604063C add #-1,r13
    st32(c.r[14] + 52, c.r[13]);  // 0604063E mov.l r13,@(52,r14)
    c.r[0] = c.r[13];  // 06040640 mov r13,r0
    c.r[0] &= 0x3Fu;  // 06040642 and #63,r0
    st32(c.r[14] + 52, c.r[0]);  // 06040644 mov.l r0,@(52,r14)
    c.r[1] = c.r[12];  // 06040646 mov r12,r1
    c.r[1] += 7;  // 06040648 add #7,r1
    c.r[13] = 0x3Fu;  // 0604064A mov #63,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604064C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604064E extu.b r2,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06040650 extu.b r1,r3
    c.r[8] = c.r[3];  // 06040652 mov r3,r8
    c.r[8] += c.r[9];  // 06040654 add r9,r8
    c.r[8] -= 1;  // 06040656 add #-1,r8
    c.r[1] = c.r[0];  // 06040658 mov r0,r1
    c.r[1] += 1;  // 0604065A add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604065C cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] &= c.r[13]; if (k) { goto L_06040664; } }  // 0604065E bf/s 0x06040664 ; and r13,r8
    c.r[1] = c.r[2];  // 06040662 mov r2,r1
L_06040664:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06040664 extu.w r1,r9
    c.r[1] = c.r[6];  // 06040666 mov r6,r1
    c.r[1] -= c.r[9];  // 06040668 sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604066A extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604066C mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 0604066E mov r8,r5
    c.r[5] <<= 2;  // 06040670 shll2 r5
    c.r[5] <<= 2;  // 06040672 shll2 r5
    c.r[5] += c.r[5];  // 06040674 add r5,r5
    c.r[5] <<= 2;  // 06040676 shll2 r5
    c.r[8] = 0x0u;  // 06040678 mov #0,r8
    c.r[1] = c.r[3] & 0xFFFFu;  // 0604067A extu.w r3,r1
    c.t = c.r[8] >= c.r[1];  // 0604067C cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_06040686; } }  // 0604067E bf/s 0x06040686 ; add r7,r5
    goto L_06040B1E;  // 06040682 bra 0x06040B1E ; nop
L_06040686:
    c.r[0] = ld32(c.r[14] + 4);  // 06040686 mov.l @(4,r14),r0
    c.r[13] = ld32(c.r[14]);  // 06040688 mov.l @r14,r13
    c.r[0] += c.r[13];  // 0604068A add r13,r0
    st32(c.r[14] + 28, c.r[0]);  // 0604068C mov.l r0,@(28,r14)
L_0604068E:
    c.r[1] = c.r[9];  // 0604068E mov r9,r1
    c.r[1] -= 1;  // 06040690 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06040692 extu.w r1,r3
    c.r[0] = ld32(c.r[14] + 52);  // 06040694 mov.l @(52,r14),r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 06040696 tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 06040698 mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[0]); if (k) { goto L_060406CE; } }  // 0604069A bt/s 0x060406CE ; mov.l r0,@(48,r14)
L_0604069E:
    c.r[2] = ld32(c.r[14] + 48);  // 0604069E mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060406A0 mov r4,r7
    c.r[13] = ld32(c.r[14] + 28);  // 060406A2 mov.l @(28,r14),r13
    c.r[1] = c.r[2];  // 060406A4 mov r2,r1
    c.r[1] -= 1;  // 060406A6 add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060406A8 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060406AA mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060406AC add r2,r2
    c.r[1] = c.r[4];  // 060406AE mov r4,r1
    c.r[1] += 1;  // 060406B0 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060406B2 extu.w r1,r4
    c.r[7] += c.r[7];  // 060406B4 add r7,r7
    c.r[0] = c.r[7];  // 060406B6 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060406B8 mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 060406BA add r13,r1
    c.r[1] ^= c.r[10];  // 060406BC xor r10,r1
    c.r[0] = c.r[2];  // 060406BE mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 060406C0 mov.w r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060406C2 mov r3,r2
    c.r[1] = c.r[2];  // 060406C4 mov r2,r1
    c.r[1] -= 1;  // 060406C6 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060406C8 tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0604069E; } }  // 060406CA bf/s 0x0604069E ; extu.w r1,r3
L_060406CE:
    c.r[13] = 0x3Fu;  // 060406CE mov #63,r13
    st32(c.r[14] + 48, c.r[13]); goto L_060406F8;  // 060406D0 bra 0x060406F8 ; mov.l r13,@(48,r14)
L_060406D4:
    c.r[2] = ld32(c.r[14] + 48);  // 060406D4 mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060406D6 mov r4,r3
    c.r[13] = ld32(c.r[14] + 28);  // 060406D8 mov.l @(28,r14),r13
    c.r[1] = c.r[2];  // 060406DA mov r2,r1
    c.r[1] -= 1;  // 060406DC add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060406DE extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060406E0 mov.l r1,@(48,r14)
    c.r[2] += c.r[2];  // 060406E2 add r2,r2
    c.r[1] = c.r[4];  // 060406E4 mov r4,r1
    c.r[1] += 1;  // 060406E6 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060406E8 extu.w r1,r4
    c.r[3] += c.r[3];  // 060406EA add r3,r3
    c.r[0] = c.r[3];  // 060406EC mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060406EE mov.w @(r0,r11),r1
    c.r[1] += c.r[13];  // 060406F0 add r13,r1
    c.r[1] ^= c.r[10];  // 060406F2 xor r10,r1
    c.r[0] = c.r[2];  // 060406F4 mov r2,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 060406F6 mov.w r1,@(r0,r5)
L_060406F8:
    c.r[2] = c.r[6];  // 060406F8 mov r6,r2
    c.r[1] = c.r[2];  // 060406FA mov r2,r1
    c.r[1] -= 1;  // 060406FC add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060406FE tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060406D4; } }  // 06040700 bf/s 0x060406D4 ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604084Au);  // 06040704 mov.w 0x0604084A,r2
    c.r[2] &= c.r[5];  // 06040706 and r5,r2
    c.r[5] -= 128;  // 06040708 add #-128,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604084Cu);  // 0604070A mov.w 0x0604084C,r1
    c.r[5] &= c.r[1];  // 0604070C and r1,r5
    c.r[1] = c.r[8];  // 0604070E mov r8,r1
    c.r[1] += 1;  // 06040710 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06040712 extu.w r1,r8
    c.r[1] = c.r[12];  // 06040714 mov r12,r1
    c.r[1] += 7;  // 06040716 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040718 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604071A extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 0604071C cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_0604068E; } }  // 0604071E bf/s 0x0604068E ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 06040722 bra 0x06040B20 ; add #56,r14
L_06040726:
    c.r[0] &= 0xF0u;  // 06040726 and #240,r0
    c.r[0] <<= 8;  // 06040728 shll8 r0
    c.r[0] <<= 2;  // 0604072A shll2 r0
    c.r[0] <<= 2;  // 0604072C shll2 r0
    st32(c.r[14] + 8, c.r[0]);  // 0604072E mov.l r0,@(8,r14)
    c.r[2] = 0x3u;  // 06040730 mov #3,r2
    c.r[2] &= c.r[6];  // 06040732 and r6,r2
    c.r[10] = c.r[2];  // 06040734 mov r2,r10
    c.r[10] <<= 16;  // 06040736 shll16 r10
    c.r[10] >>= 2;  // 06040738 shlr2 r10
    c.r[10] <<= 16;  // 0604073A shll16 r10
    c.r[11] = ld32(c.r[8] + 4);  // 0604073C mov.l @(4,r8),r11
    c.r[1] = ld32(c.r[12]);  // 0604073E mov.l @r12,r1
    c.r[11] -= 8;  // 06040740 add #-8,r11
    c.r[11] += c.r[1];  // 06040742 add r1,r11
    c.r[1] = 0x3u;  // 06040744 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 06040746 cmp/hi r1,r2
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06040750; } }  // 06040748 bf/s 0x06040750 ; mov #0,r4
    goto L_06040B1E;  // 0604074C bra 0x06040B1E ; nop
L_06040750:
    c.r[1] = c.r[2];  // 06040750 mov r2,r1
    c.r[1] += c.r[1];  // 06040752 add r1,r1
    c.r[0] = 0x06040760u;  // 06040754 mova 0x06040760,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06040756 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06040758 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06040768u: goto L_06040768; case 0x06040854u: goto L_06040854; case 0x06040940u: goto L_06040940; case 0x06040A32u: goto L_06040A32; default: sh2_call(c, x); return; } }  // 0604075A jmp @r0 ; nop
L_06040768:
    c.r[13] = 0x3Fu;  // 06040768 mov #63,r13
    c.r[13] &= c.r[3];  // 0604076A and r3,r13
    st32(c.r[14] + 52, c.r[13]);  // 0604076C mov.l r13,@(52,r14)
    c.r[8] = 0x3Fu;  // 0604076E mov #63,r8
    c.r[1] = c.r[12];  // 06040770 mov r12,r1
    c.r[1] += 6;  // 06040772 add #6,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040774 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06040776 extu.b r3,r2
    c.r[1] = 0x3Fu;  // 06040778 mov #63,r1
    c.r[1] ^= c.r[13];  // 0604077A xor r13,r1
    c.r[1] += 1;  // 0604077C add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604077E cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] &= c.r[9]; if (k) { goto L_06040786; } }  // 06040780 bf/s 0x06040786 ; and r9,r8
    c.r[1] = c.r[2];  // 06040784 mov r2,r1
L_06040786:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06040786 extu.w r1,r9
    c.r[1] = c.r[3] & 0xFFu;  // 06040788 extu.b r3,r1
    c.r[1] -= c.r[9];  // 0604078A sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604078C extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0604078E mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 06040790 mov r8,r5
    c.r[5] <<= 8;  // 06040792 shll8 r5
    c.r[1] = c.r[12];  // 06040794 mov r12,r1
    c.r[1] += 7;  // 06040796 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040798 mov.b @r1,r1
    c.r[8] = 0x0u;  // 0604079A mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604079C extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 0604079E cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_060407A8; } }  // 060407A0 bf/s 0x060407A8 ; add r7,r5
    goto L_06040B1E;  // 060407A4 bra 0x06040B1E ; nop
L_060407A8:
    c.r[0] = ld32(c.r[14] + 8);  // 060407A8 mov.l @(8,r14),r0
    c.r[13] = ld32(c.r[14]);  // 060407AA mov.l @r14,r13
    c.r[0] += c.r[13];  // 060407AC add r13,r0
    st32(c.r[14] + 32, c.r[0]);  // 060407AE mov.l r0,@(32,r14)
L_060407B0:
    c.r[1] = c.r[9];  // 060407B0 mov r9,r1
    c.r[1] -= 1;  // 060407B2 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060407B4 extu.w r1,r3
    c.r[0] = ld32(c.r[14] + 52);  // 060407B6 mov.l @(52,r14),r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 060407B8 tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 060407BA mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[0]); if (k) { goto L_060407F0; } }  // 060407BC bt/s 0x060407F0 ; mov.l r0,@(48,r14)
L_060407C0:
    c.r[2] = ld32(c.r[14] + 48);  // 060407C0 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060407C2 mov r4,r7
    c.r[1] = c.r[2];  // 060407C4 mov r2,r1
    c.r[1] += 1;  // 060407C6 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060407C8 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060407CA mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 060407CC shll2 r2
    c.r[1] = c.r[4];  // 060407CE mov r4,r1
    c.r[1] += 1;  // 060407D0 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060407D2 extu.w r1,r4
    c.r[7] <<= 2;  // 060407D4 shll2 r7
    c.r[0] = c.r[7];  // 060407D6 mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 060407D8 mov.l @(r0,r11),r1
    c.r[13] = ld32(c.r[14] + 32);  // 060407DA mov.l @(32,r14),r13
    c.r[1] ^= c.r[10];  // 060407DC xor r10,r1
    c.r[1] += c.r[13];  // 060407DE add r13,r1
    c.r[0] = c.r[2];  // 060407E0 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 060407E2 mov.l r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060407E4 mov r3,r2
    c.r[1] = c.r[2];  // 060407E6 mov r2,r1
    c.r[1] -= 1;  // 060407E8 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060407EA tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060407C0; } }  // 060407EC bf/s 0x060407C0 ; extu.w r1,r3
L_060407F0:
    c.r[13] = 0x0u;  // 060407F0 mov #0,r13
    st32(c.r[14] + 48, c.r[13]); goto L_0604081A;  // 060407F2 bra 0x0604081A ; mov.l r13,@(48,r14)
L_060407F6:
    c.r[2] = ld32(c.r[14] + 48);  // 060407F6 mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060407F8 mov r4,r3
    c.r[1] = c.r[2];  // 060407FA mov r2,r1
    c.r[1] += 1;  // 060407FC add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060407FE extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 06040800 mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 06040802 shll2 r2
    c.r[1] = c.r[4];  // 06040804 mov r4,r1
    c.r[1] += 1;  // 06040806 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06040808 extu.w r1,r4
    c.r[3] <<= 2;  // 0604080A shll2 r3
    c.r[0] = c.r[3];  // 0604080C mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 0604080E mov.l @(r0,r11),r1
    c.r[13] = ld32(c.r[14] + 32);  // 06040810 mov.l @(32,r14),r13
    c.r[1] ^= c.r[10];  // 06040812 xor r10,r1
    c.r[1] += c.r[13];  // 06040814 add r13,r1
    c.r[0] = c.r[2];  // 06040816 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 06040818 mov.l r1,@(r0,r5)
L_0604081A:
    c.r[2] = c.r[6];  // 0604081A mov r6,r2
    c.r[1] = c.r[2];  // 0604081C mov r2,r1
    c.r[1] -= 1;  // 0604081E add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040820 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060407F6; } }  // 06040822 bf/s 0x060407F6 ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604084Eu);  // 06040826 mov.w 0x0604084E,r2
    c.r[2] &= c.r[5];  // 06040828 and r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040850u);  // 0604082A mov.w 0x06040850,r1
    c.r[5] += c.r[1];  // 0604082C add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040852u);  // 0604082E mov.w 0x06040852,r1
    c.r[5] &= c.r[1];  // 06040830 and r1,r5
    c.r[1] = c.r[8];  // 06040832 mov r8,r1
    c.r[1] += 1;  // 06040834 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06040836 extu.w r1,r8
    c.r[1] = c.r[12];  // 06040838 mov r12,r1
    c.r[1] += 7;  // 0604083A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604083C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604083E extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040840 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_060407B0; } }  // 06040842 bf/s 0x060407B0 ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 06040846 bra 0x06040B20 ; add #56,r14
L_06040854:
    c.r[1] = c.r[12];  // 06040854 mov r12,r1
    c.r[1] += 6;  // 06040856 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040858 mov.b @r1,r1
    c.r[8] = 0x3Fu;  // 0604085A mov #63,r8
    c.r[8] &= c.r[9];  // 0604085C and r9,r8
    c.r[6] = c.r[1] & 0xFFu;  // 0604085E extu.b r1,r6
    c.r[3] += c.r[6];  // 06040860 add r6,r3
    st32(c.r[14] + 52, c.r[3]);  // 06040862 mov.l r3,@(52,r14)
    c.r[13] = c.r[3];  // 06040864 mov r3,r13
    c.r[13] -= 1;  // 06040866 add #-1,r13
    st32(c.r[14] + 52, c.r[13]);  // 06040868 mov.l r13,@(52,r14)
    c.r[0] = c.r[13];  // 0604086A mov r13,r0
    c.r[0] &= 0x3Fu;  // 0604086C and #63,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0604086E extu.b r1,r2
    c.r[1] = c.r[0];  // 06040870 mov r0,r1
    c.r[1] += 1;  // 06040872 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06040874 cmp/gt r2,r1
    { const bool k = !c.t; st32(c.r[14] + 52, c.r[0]); if (k) { goto L_0604087C; } }  // 06040876 bf/s 0x0604087C ; mov.l r0,@(52,r14)
    c.r[1] = c.r[2];  // 0604087A mov r2,r1
L_0604087C:
    c.r[9] = c.r[1] & 0xFFFFu;  // 0604087C extu.w r1,r9
    c.r[1] = c.r[6];  // 0604087E mov r6,r1
    c.r[1] -= c.r[9];  // 06040880 sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06040882 extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06040884 mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 06040886 mov r8,r5
    c.r[5] <<= 8;  // 06040888 shll8 r5
    c.r[1] = c.r[12];  // 0604088A mov r12,r1
    c.r[1] += 7;  // 0604088C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604088E mov.b @r1,r1
    c.r[8] = 0x0u;  // 06040890 mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06040892 extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040894 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_0604089E; } }  // 06040896 bf/s 0x0604089E ; add r7,r5
    goto L_06040B1E;  // 0604089A bra 0x06040B1E ; nop
L_0604089E:
    c.r[13] = ld32(c.r[14] + 8);  // 0604089E mov.l @(8,r14),r13
    c.r[0] = ld32(c.r[14]);  // 060408A0 mov.l @r14,r0
    c.r[13] += c.r[0];  // 060408A2 add r0,r13
    st32(c.r[14] + 36, c.r[13]);  // 060408A4 mov.l r13,@(36,r14)
L_060408A6:
    c.r[1] = c.r[9];  // 060408A6 mov r9,r1
    c.r[1] -= 1;  // 060408A8 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060408AA extu.w r1,r3
    c.r[13] = ld32(c.r[14] + 52);  // 060408AC mov.l @(52,r14),r13
    c.t = (c.r[9] & c.r[9]) == 0;  // 060408AE tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 060408B0 mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[13]); if (k) { goto L_060408E6; } }  // 060408B2 bt/s 0x060408E6 ; mov.l r13,@(48,r14)
L_060408B6:
    c.r[2] = ld32(c.r[14] + 48);  // 060408B6 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060408B8 mov r4,r7
    c.r[13] = ld32(c.r[14] + 36);  // 060408BA mov.l @(36,r14),r13
    c.r[1] = c.r[2];  // 060408BC mov r2,r1
    c.r[1] -= 1;  // 060408BE add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060408C0 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060408C2 mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 060408C4 shll2 r2
    c.r[1] = c.r[4];  // 060408C6 mov r4,r1
    c.r[1] += 1;  // 060408C8 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060408CA extu.w r1,r4
    c.r[7] <<= 2;  // 060408CC shll2 r7
    c.r[0] = c.r[7];  // 060408CE mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 060408D0 mov.l @(r0,r11),r1
    c.r[1] += c.r[13];  // 060408D2 add r13,r1
    c.r[1] ^= c.r[10];  // 060408D4 xor r10,r1
    c.r[0] = c.r[2];  // 060408D6 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 060408D8 mov.l r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060408DA mov r3,r2
    c.r[1] = c.r[2];  // 060408DC mov r2,r1
    c.r[1] -= 1;  // 060408DE add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060408E0 tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060408B6; } }  // 060408E2 bf/s 0x060408B6 ; extu.w r1,r3
L_060408E6:
    c.r[13] = 0x3Fu;  // 060408E6 mov #63,r13
    st32(c.r[14] + 48, c.r[13]); goto L_06040910;  // 060408E8 bra 0x06040910 ; mov.l r13,@(48,r14)
L_060408EC:
    c.r[2] = ld32(c.r[14] + 48);  // 060408EC mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060408EE mov r4,r3
    c.r[13] = ld32(c.r[14] + 36);  // 060408F0 mov.l @(36,r14),r13
    c.r[1] = c.r[2];  // 060408F2 mov r2,r1
    c.r[1] -= 1;  // 060408F4 add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060408F6 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060408F8 mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 060408FA shll2 r2
    c.r[1] = c.r[4];  // 060408FC mov r4,r1
    c.r[1] += 1;  // 060408FE add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06040900 extu.w r1,r4
    c.r[3] <<= 2;  // 06040902 shll2 r3
    c.r[0] = c.r[3];  // 06040904 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 06040906 mov.l @(r0,r11),r1
    c.r[1] += c.r[13];  // 06040908 add r13,r1
    c.r[1] ^= c.r[10];  // 0604090A xor r10,r1
    c.r[0] = c.r[2];  // 0604090C mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 0604090E mov.l r1,@(r0,r5)
L_06040910:
    c.r[2] = c.r[6];  // 06040910 mov r6,r2
    c.r[1] = c.r[2];  // 06040912 mov r2,r1
    c.r[1] -= 1;  // 06040914 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040916 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060408EC; } }  // 06040918 bf/s 0x060408EC ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06040A2Au);  // 0604091C mov.w 0x06040A2A,r2
    c.r[2] &= c.r[5];  // 0604091E and r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040A2Cu);  // 06040920 mov.w 0x06040A2C,r1
    c.r[5] += c.r[1];  // 06040922 add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040A2Eu);  // 06040924 mov.w 0x06040A2E,r1
    c.r[5] &= c.r[1];  // 06040926 and r1,r5
    c.r[1] = c.r[8];  // 06040928 mov r8,r1
    c.r[1] += 1;  // 0604092A add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0604092C extu.w r1,r8
    c.r[1] = c.r[12];  // 0604092E mov r12,r1
    c.r[1] += 7;  // 06040930 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040932 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06040934 extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040936 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_060408A6; } }  // 06040938 bf/s 0x060408A6 ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 0604093C bra 0x06040B20 ; add #56,r14
L_06040940:
    c.r[13] = 0x3Fu;  // 06040940 mov #63,r13
    c.r[13] &= c.r[3];  // 06040942 and r3,r13
    st32(c.r[14] + 52, c.r[13]);  // 06040944 mov.l r13,@(52,r14)
    c.r[1] = c.r[12];  // 06040946 mov r12,r1
    c.r[1] += 7;  // 06040948 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604094A mov.b @r1,r1
    c.r[0] = 0x3Fu;  // 0604094C mov #63,r0
    c.r[6] = c.r[1] & 0xFFu;  // 0604094E extu.b r1,r6
    c.r[8] = c.r[6];  // 06040950 mov r6,r8
    c.r[8] += c.r[9];  // 06040952 add r9,r8
    c.r[8] -= 1;  // 06040954 add #-1,r8
    c.r[1] = c.r[12];  // 06040956 mov r12,r1
    c.r[1] += 6;  // 06040958 add #6,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604095A mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0604095C extu.b r3,r2
    c.r[1] = 0x3Fu;  // 0604095E mov #63,r1
    c.r[1] ^= c.r[13];  // 06040960 xor r13,r1
    c.r[1] += 1;  // 06040962 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06040964 cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] &= c.r[0]; if (k) { goto L_0604096C; } }  // 06040966 bf/s 0x0604096C ; and r0,r8
    c.r[1] = c.r[2];  // 0604096A mov r2,r1
L_0604096C:
    c.r[9] = c.r[1] & 0xFFFFu;  // 0604096C extu.w r1,r9
    c.r[1] = c.r[3] & 0xFFu;  // 0604096E extu.b r3,r1
    c.r[1] -= c.r[9];  // 06040970 sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06040972 extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06040974 mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 06040976 mov r8,r5
    c.r[5] <<= 8;  // 06040978 shll8 r5
    c.r[8] = 0x0u;  // 0604097A mov #0,r8
    c.r[1] = c.r[6] & 0xFFFFu;  // 0604097C extu.w r6,r1
    c.t = c.r[8] >= c.r[1];  // 0604097E cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] += c.r[7]; if (k) { goto L_06040988; } }  // 06040980 bf/s 0x06040988 ; add r7,r5
    goto L_06040B1E;  // 06040984 bra 0x06040B1E ; nop
L_06040988:
    c.r[13] = ld32(c.r[14] + 8);  // 06040988 mov.l @(8,r14),r13
    c.r[0] = ld32(c.r[14]);  // 0604098A mov.l @r14,r0
    c.r[13] += c.r[0];  // 0604098C add r0,r13
    st32(c.r[14] + 40, c.r[13]);  // 0604098E mov.l r13,@(40,r14)
L_06040990:
    c.r[1] = c.r[9];  // 06040990 mov r9,r1
    c.r[1] -= 1;  // 06040992 add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06040994 extu.w r1,r3
    c.r[13] = ld32(c.r[14] + 52);  // 06040996 mov.l @(52,r14),r13
    c.t = (c.r[9] & c.r[9]) == 0;  // 06040998 tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 0604099A mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[13]); if (k) { goto L_060409D0; } }  // 0604099C bt/s 0x060409D0 ; mov.l r13,@(48,r14)
L_060409A0:
    c.r[2] = ld32(c.r[14] + 48);  // 060409A0 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 060409A2 mov r4,r7
    c.r[13] = ld32(c.r[14] + 40);  // 060409A4 mov.l @(40,r14),r13
    c.r[1] = c.r[2];  // 060409A6 mov r2,r1
    c.r[1] += 1;  // 060409A8 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060409AA extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060409AC mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 060409AE shll2 r2
    c.r[1] = c.r[4];  // 060409B0 mov r4,r1
    c.r[1] += 1;  // 060409B2 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060409B4 extu.w r1,r4
    c.r[7] <<= 2;  // 060409B6 shll2 r7
    c.r[0] = c.r[7];  // 060409B8 mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 060409BA mov.l @(r0,r11),r1
    c.r[1] += c.r[13];  // 060409BC add r13,r1
    c.r[1] ^= c.r[10];  // 060409BE xor r10,r1
    c.r[0] = c.r[2];  // 060409C0 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 060409C2 mov.l r1,@(r0,r5)
    c.r[2] = c.r[3];  // 060409C4 mov r3,r2
    c.r[1] = c.r[2];  // 060409C6 mov r2,r1
    c.r[1] -= 1;  // 060409C8 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060409CA tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060409A0; } }  // 060409CC bf/s 0x060409A0 ; extu.w r1,r3
L_060409D0:
    c.r[13] = 0x0u;  // 060409D0 mov #0,r13
    st32(c.r[14] + 48, c.r[13]); goto L_060409FA;  // 060409D2 bra 0x060409FA ; mov.l r13,@(48,r14)
L_060409D6:
    c.r[2] = ld32(c.r[14] + 48);  // 060409D6 mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 060409D8 mov r4,r3
    c.r[13] = ld32(c.r[14] + 40);  // 060409DA mov.l @(40,r14),r13
    c.r[1] = c.r[2];  // 060409DC mov r2,r1
    c.r[1] += 1;  // 060409DE add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060409E0 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060409E2 mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 060409E4 shll2 r2
    c.r[1] = c.r[4];  // 060409E6 mov r4,r1
    c.r[1] += 1;  // 060409E8 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060409EA extu.w r1,r4
    c.r[3] <<= 2;  // 060409EC shll2 r3
    c.r[0] = c.r[3];  // 060409EE mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 060409F0 mov.l @(r0,r11),r1
    c.r[1] += c.r[13];  // 060409F2 add r13,r1
    c.r[1] ^= c.r[10];  // 060409F4 xor r10,r1
    c.r[0] = c.r[2];  // 060409F6 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 060409F8 mov.l r1,@(r0,r5)
L_060409FA:
    c.r[2] = c.r[6];  // 060409FA mov r6,r2
    c.r[1] = c.r[2];  // 060409FC mov r2,r1
    c.r[1] -= 1;  // 060409FE add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040A00 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060409D6; } }  // 06040A02 bf/s 0x060409D6 ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06040A2Au);  // 06040A06 mov.w 0x06040A2A,r2
    c.r[2] &= c.r[5];  // 06040A08 and r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040A30u);  // 06040A0A mov.w 0x06040A30,r1
    c.r[5] += c.r[1];  // 06040A0C add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040A2Eu);  // 06040A0E mov.w 0x06040A2E,r1
    c.r[5] &= c.r[1];  // 06040A10 and r1,r5
    c.r[1] = c.r[8];  // 06040A12 mov r8,r1
    c.r[1] += 1;  // 06040A14 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06040A16 extu.w r1,r8
    c.r[1] = c.r[12];  // 06040A18 mov r12,r1
    c.r[1] += 7;  // 06040A1A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040A1C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06040A1E extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040A20 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_06040990; } }  // 06040A22 bf/s 0x06040990 ; or r2,r5
    c.r[14] += 56; goto L_06040B20;  // 06040A26 bra 0x06040B20 ; add #56,r14
L_06040A32:
    c.r[1] = c.r[12];  // 06040A32 mov r12,r1
    c.r[1] += 6;  // 06040A34 add #6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040A36 mov.b @r1,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06040A38 extu.b r2,r6
    c.r[3] += c.r[6];  // 06040A3A add r6,r3
    st32(c.r[14] + 52, c.r[3]);  // 06040A3C mov.l r3,@(52,r14)
    c.r[13] = c.r[3];  // 06040A3E mov r3,r13
    c.r[13] -= 1;  // 06040A40 add #-1,r13
    st32(c.r[14] + 52, c.r[13]);  // 06040A42 mov.l r13,@(52,r14)
    c.r[0] = c.r[13];  // 06040A44 mov r13,r0
    c.r[0] &= 0x3Fu;  // 06040A46 and #63,r0
    st32(c.r[14] + 52, c.r[0]);  // 06040A48 mov.l r0,@(52,r14)
    c.r[1] = c.r[12];  // 06040A4A mov r12,r1
    c.r[1] += 7;  // 06040A4C add #7,r1
    c.r[13] = 0x3Fu;  // 06040A4E mov #63,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040A50 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06040A52 extu.b r2,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06040A54 extu.b r1,r3
    c.r[8] = c.r[3];  // 06040A56 mov r3,r8
    c.r[8] += c.r[9];  // 06040A58 add r9,r8
    c.r[8] -= 1;  // 06040A5A add #-1,r8
    c.r[1] = c.r[0];  // 06040A5C mov r0,r1
    c.r[1] += 1;  // 06040A5E add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06040A60 cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] &= c.r[13]; if (k) { goto L_06040A68; } }  // 06040A62 bf/s 0x06040A68 ; and r13,r8
    c.r[1] = c.r[2];  // 06040A66 mov r2,r1
L_06040A68:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06040A68 extu.w r1,r9
    c.r[1] = c.r[6];  // 06040A6A mov r6,r1
    c.r[1] -= c.r[9];  // 06040A6C sub r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06040A6E extu.w r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06040A70 mov.l r1,@(12,r14)
    c.r[5] = c.r[8];  // 06040A72 mov r8,r5
    c.r[5] <<= 8;  // 06040A74 shll8 r5
    c.r[8] = 0x0u;  // 06040A76 mov #0,r8
    c.r[1] = c.r[3] & 0xFFFFu;  // 06040A78 extu.w r3,r1
    c.t = c.r[8] >= c.r[1];  // 06040A7A cmp/hs r1,r8
    { const bool k = c.t; c.r[5] += c.r[7]; if (k) { goto L_06040B1E; } }  // 06040A7C bt/s 0x06040B1E ; add r7,r5
    c.r[0] = ld32(c.r[14] + 8);  // 06040A80 mov.l @(8,r14),r0
    c.r[13] = ld32(c.r[14]);  // 06040A82 mov.l @r14,r13
    c.r[0] += c.r[13];  // 06040A84 add r13,r0
    st32(c.r[14] + 44, c.r[0]);  // 06040A86 mov.l r0,@(44,r14)
L_06040A88:
    c.r[1] = c.r[9];  // 06040A88 mov r9,r1
    c.r[1] -= 1;  // 06040A8A add #-1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06040A8C extu.w r1,r3
    c.r[0] = ld32(c.r[14] + 52);  // 06040A8E mov.l @(52,r14),r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 06040A90 tst r9,r9
    c.r[6] = ld32(c.r[14] + 12);  // 06040A92 mov.l @(12,r14),r6
    { const bool k = c.t; st32(c.r[14] + 48, c.r[0]); if (k) { goto L_06040AC8; } }  // 06040A94 bt/s 0x06040AC8 ; mov.l r0,@(48,r14)
L_06040A98:
    c.r[2] = ld32(c.r[14] + 48);  // 06040A98 mov.l @(48,r14),r2
    c.r[7] = c.r[4];  // 06040A9A mov r4,r7
    c.r[13] = ld32(c.r[14] + 44);  // 06040A9C mov.l @(44,r14),r13
    c.r[1] = c.r[2];  // 06040A9E mov r2,r1
    c.r[1] -= 1;  // 06040AA0 add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06040AA2 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 06040AA4 mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 06040AA6 shll2 r2
    c.r[1] = c.r[4];  // 06040AA8 mov r4,r1
    c.r[1] += 1;  // 06040AAA add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06040AAC extu.w r1,r4
    c.r[7] <<= 2;  // 06040AAE shll2 r7
    c.r[0] = c.r[7];  // 06040AB0 mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 06040AB2 mov.l @(r0,r11),r1
    c.r[1] += c.r[13];  // 06040AB4 add r13,r1
    c.r[1] ^= c.r[10];  // 06040AB6 xor r10,r1
    c.r[0] = c.r[2];  // 06040AB8 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 06040ABA mov.l r1,@(r0,r5)
    c.r[2] = c.r[3];  // 06040ABC mov r3,r2
    c.r[1] = c.r[2];  // 06040ABE mov r2,r1
    c.r[1] -= 1;  // 06040AC0 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040AC2 tst r2,r2
    { const bool k = !c.t; c.r[3] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06040A98; } }  // 06040AC4 bf/s 0x06040A98 ; extu.w r1,r3
L_06040AC8:
    c.r[13] = 0x3Fu;  // 06040AC8 mov #63,r13
    st32(c.r[14] + 48, c.r[13]); goto L_06040AF2;  // 06040ACA bra 0x06040AF2 ; mov.l r13,@(48,r14)
L_06040ACE:
    c.r[2] = ld32(c.r[14] + 48);  // 06040ACE mov.l @(48,r14),r2
    c.r[3] = c.r[4];  // 06040AD0 mov r4,r3
    c.r[13] = ld32(c.r[14] + 44);  // 06040AD2 mov.l @(44,r14),r13
    c.r[1] = c.r[2];  // 06040AD4 mov r2,r1
    c.r[1] -= 1;  // 06040AD6 add #-1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06040AD8 extu.w r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 06040ADA mov.l r1,@(48,r14)
    c.r[2] <<= 2;  // 06040ADC shll2 r2
    c.r[1] = c.r[4];  // 06040ADE mov r4,r1
    c.r[1] += 1;  // 06040AE0 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06040AE2 extu.w r1,r4
    c.r[3] <<= 2;  // 06040AE4 shll2 r3
    c.r[0] = c.r[3];  // 06040AE6 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 06040AE8 mov.l @(r0,r11),r1
    c.r[1] += c.r[13];  // 06040AEA add r13,r1
    c.r[1] ^= c.r[10];  // 06040AEC xor r10,r1
    c.r[0] = c.r[2];  // 06040AEE mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 06040AF0 mov.l r1,@(r0,r5)
L_06040AF2:
    c.r[2] = c.r[6];  // 06040AF2 mov r6,r2
    c.r[1] = c.r[2];  // 06040AF4 mov r2,r1
    c.r[1] -= 1;  // 06040AF6 add #-1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06040AF8 tst r2,r2
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06040ACE; } }  // 06040AFA bf/s 0x06040ACE ; extu.w r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06040B32u);  // 06040AFE mov.w 0x06040B32,r2
    c.r[2] &= c.r[5];  // 06040B00 and r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040B34u);  // 06040B02 mov.w 0x06040B34,r1
    c.r[5] += c.r[1];  // 06040B04 add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040B36u);  // 06040B06 mov.w 0x06040B36,r1
    c.r[5] &= c.r[1];  // 06040B08 and r1,r5
    c.r[1] = c.r[8];  // 06040B0A mov r8,r1
    c.r[1] += 1;  // 06040B0C add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06040B0E extu.w r1,r8
    c.r[1] = c.r[12];  // 06040B10 mov r12,r1
    c.r[1] += 7;  // 06040B12 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040B14 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06040B16 extu.b r1,r1
    c.t = c.r[8] >= c.r[1];  // 06040B18 cmp/hs r1,r8
    { const bool k = !c.t; c.r[5] |= c.r[2]; if (k) { SH2_POLL(c); goto L_06040A88; } }  // 06040B1A bf/s 0x06040A88 ; or r2,r5
L_06040B1E:
    c.r[14] += 56;  // 06040B1E add #56,r14
L_06040B20:
    c.r[15] = c.r[14];  // 06040B20 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06040B22 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06040B24 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06040B26 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06040B28 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06040B2A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06040B2C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06040B2E rts ; mov.l @r15+,r8
}

void f_06040B3C(SH2Context& c) {
    ran[1030] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06040B3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06040B3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06040B40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06040B42 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06040B44 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06040B46 mov r15,r14
    c.r[10] = c.r[4];  // 06040B48 mov r4,r10
    c.r[8] = c.r[5];  // 06040B4A mov r5,r8
    c.r[9] = c.r[6];  // 06040B4C mov r6,r9
    c.r[5] = ld32(0x06040C54u);  // 06040B4E mov.l 0x06040C54,r5
    c.r[0] = ld32(0x06040C58u);  // 06040B50 mov.l 0x06040C58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06040B56u; c.r[6] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040B56u) return; }  // 06040B52 jsr @r0 ; mov #3,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 06040B56 tst r0,r0
    { const bool k = c.t; c.r[4] = c.r[10]; if (k) { goto L_06040B60; } }  // 06040B58 bt/s 0x06040B60 ; mov r10,r4
    c.r[0] = 0x0u; goto L_06040C3C;  // 06040B5C bra 0x06040C3C ; mov #0,r0
L_06040B60:
    c.r[4] += 4;  // 06040B60 add #4,r4
    c.r[0] = ld32(0x06040C5Cu);  // 06040B62 mov.l 0x06040C5C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06040B68u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040B68u) return; }  // 06040B64 jsr @r0 ; mov r8,r5
    c.r[10] += 3;  // 06040B68 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06040B6A mov.b @r10,r1
    c.r[6] = c.r[0];  // 06040B6C mov r0,r6
    c.r[0] = c.r[1] & 0xFFu;  // 06040B6E extu.b r1,r0
    c.t = c.r[0] == 0x31u;  // 06040B70 cmp/eq #49,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06040BAE; } }  // 06040B72 bt/s 0x06040BAE ; mov #1,r1
    c.r[1] = 0x31u;  // 06040B76 mov #49,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06040B78 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x32u; if (k) { goto L_06040B88; } }  // 06040B7A bt/s 0x06040B88 ; cmp/eq #50,r0
    c.t = c.r[0] == 0x30u;  // 06040B7E cmp/eq #48,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06040B90; } }  // 06040B80 bt/s 0x06040B90 ; mov #0,r1
    c.r[0] = 0x0u; goto L_06040C3C;  // 06040B84 bra 0x06040C3C ; mov #0,r0
L_06040B88:
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06040BF2; } }  // 06040B88 bt/s 0x06040BF2 ; mov #2,r1
    c.r[0] = 0x0u; goto L_06040C3C;  // 06040B8C bra 0x06040C3C ; mov #0,r0
L_06040B90:
    st8(c.r[9], c.r[1]);  // 06040B90 mov.b r1,@r9
    st32(c.r[9] + 4, c.r[8]);  // 06040B92 mov.l r8,@(4,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040C4Au);  // 06040B94 mov.w 0x06040C4A,r1
    c.r[1] += c.r[8];  // 06040B96 add r8,r1
    st32(c.r[9] + 8, c.r[1]);  // 06040B98 mov.l r1,@(8,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040C4Cu);  // 06040B9A mov.w 0x06040C4C,r1
    c.r[1] += c.r[8];  // 06040B9C add r8,r1
    st32(c.r[9] + 12, c.r[1]);  // 06040B9E mov.l r1,@(12,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040C4Eu);  // 06040BA0 mov.w 0x06040C4E,r1
    c.r[1] += c.r[8];  // 06040BA2 add r8,r1
    st32(c.r[9] + 16, c.r[1]);  // 06040BA4 mov.l r1,@(16,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06040C50u);  // 06040BA6 mov.w 0x06040C50,r1
    c.r[8] += c.r[1];  // 06040BA8 add r1,r8
    st32(c.r[9] + 20, c.r[8]); goto L_06040C3A;  // 06040BAA bra 0x06040C3A ; mov.l r8,@(20,r9)
L_06040BAE:
    st8(c.r[9], c.r[1]);  // 06040BAE mov.b r1,@r9
    c.r[2] = c.r[9];  // 06040BB0 mov r9,r2
    c.r[2] += 4;  // 06040BB2 add #4,r2
    c.r[1] = c.r[8];  // 06040BB4 mov r8,r1
    c.r[7] = c.r[9];  // 06040BB6 mov r9,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06040BB8 mov.b @r1+,r3
    c.r[7] += 6;  // 06040BBA add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040BBC mov.b @r1,r1
    c.r[3] <<= 8;  // 06040BBE shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06040BC0 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06040BC2 or r1,r3
    st16(c.r[2], c.r[3]);  // 06040BC4 mov.w r3,@r2
    c.r[3] = c.r[3] & 0xFFFFu;  // 06040BC6 extu.w r3,r3
    c.r[1] = c.r[8];  // 06040BC8 mov r8,r1
    c.r[1] += 2;  // 06040BCA add #2,r1
    c.r[3] += c.r[3];  // 06040BCC add r3,r3
    c.r[3] += 4;  // 06040BCE add #4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040BD0 mov.b @r1,r2
    c.r[3] += c.r[8];  // 06040BD2 add r8,r3
    c.r[1] = c.r[8];  // 06040BD4 mov r8,r1
    c.r[1] += 3;  // 06040BD6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040BD8 mov.b @r1,r1
    c.r[2] <<= 8;  // 06040BDA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06040BDC extu.b r1,r1
    c.r[2] |= c.r[1];  // 06040BDE or r1,r2
    st16(c.r[7], c.r[2]);  // 06040BE0 mov.w r2,@r7
    c.r[2] = c.r[2] & 0xFFFFu;  // 06040BE2 extu.w r2,r2
    c.r[1] = c.r[8];  // 06040BE4 mov r8,r1
    c.r[1] += 4;  // 06040BE6 add #4,r1
    st32(c.r[9] + 8, c.r[1]);  // 06040BE8 mov.l r1,@(8,r9)
    st32(c.r[9] + 12, c.r[3]);  // 06040BEA mov.l r3,@(12,r9)
    c.r[3] += c.r[2];  // 06040BEC add r2,r3
    st32(c.r[9] + 16, c.r[3]); goto L_06040C3A;  // 06040BEE bra 0x06040C3A ; mov.l r3,@(16,r9)
L_06040BF2:
    st8(c.r[9], c.r[1]);  // 06040BF2 mov.b r1,@r9
    c.r[2] = c.r[9];  // 06040BF4 mov r9,r2
    c.r[2] += 4;  // 06040BF6 add #4,r2
    c.r[1] = c.r[8];  // 06040BF8 mov r8,r1
    c.r[7] = c.r[9];  // 06040BFA mov r9,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06040BFC mov.b @r1+,r3
    c.r[7] += 6;  // 06040BFE add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040C00 mov.b @r1,r1
    c.r[3] <<= 8;  // 06040C02 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06040C04 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06040C06 or r1,r3
    st16(c.r[2], c.r[3]);  // 06040C08 mov.w r3,@r2
    c.r[3] = c.r[3] & 0xFFFFu;  // 06040C0A extu.w r3,r3
    c.r[1] = c.r[8];  // 06040C0C mov r8,r1
    c.r[1] += 2;  // 06040C0E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040C10 mov.b @r1,r2
    c.r[3] += c.r[3];  // 06040C12 add r3,r3
    c.r[1] = c.r[8];  // 06040C14 mov r8,r1
    c.r[1] += 3;  // 06040C16 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040C18 mov.b @r1,r1
    c.r[2] <<= 8;  // 06040C1A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06040C1C extu.b r1,r1
    c.r[2] |= c.r[1];  // 06040C1E or r1,r2
    st16(c.r[7], c.r[2]);  // 06040C20 mov.w r2,@r7
    c.r[2] = c.r[2] & 0xFFFFu;  // 06040C22 extu.w r2,r2
    c.r[1] = c.r[8];  // 06040C24 mov r8,r1
    c.r[1] += 4;  // 06040C26 add #4,r1
    st32(c.r[9] + 8, c.r[1]);  // 06040C28 mov.l r1,@(8,r9)
    c.r[1] = c.r[3];  // 06040C2A mov r3,r1
    c.r[1] += 4;  // 06040C2C add #4,r1
    c.r[1] += c.r[8];  // 06040C2E add r8,r1
    st32(c.r[9] + 12, c.r[1]);  // 06040C30 mov.l r1,@(12,r9)
    c.r[2] += 4;  // 06040C32 add #4,r2
    c.r[3] += c.r[2];  // 06040C34 add r2,r3
    c.r[8] += c.r[3];  // 06040C36 add r3,r8
    st32(c.r[9] + 16, c.r[8]);  // 06040C38 mov.l r8,@(16,r9)
L_06040C3A:
    c.r[0] = c.r[6];  // 06040C3A mov r6,r0
L_06040C3C:
    c.r[15] = c.r[14];  // 06040C3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06040C3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06040C40 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06040C42 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06040C44 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06040C46 rts ; mov.l @r15+,r8
}

void f_06040C68(SH2Context& c) {
    ran[1031] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06040C68 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06040C6A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06040C6C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06040C6E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06040C70 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06040C72 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06040C74 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06040C76 sts.l pr,@-r15
    c.r[15] -= 12;  // 06040C78 add #-12,r15
    c.r[14] = c.r[15];  // 06040C7A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06040C7C extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 06040C7E mov.l r4,@r14
    c.r[5] = c.r[5] & 0xFFu;  // 06040C80 extu.b r5,r5
    c.r[7] = 0x4Cu;  // 06040C82 mov #76,r7
    c.macl = c.r[5] * c.r[7];  // 06040C84 mul.l r7,r5
    c.r[1] = ld32(0x06040DD0u);  // 06040C86 mov.l 0x06040DD0,r1
    c.r[3] = ld32(c.r[1]);  // 06040C88 mov.l @r1,r3
    c.r[2] = c.macl;  // 06040C8A sts macl,r2
    c.r[2] += c.r[3];  // 06040C8C add r3,r2
    c.r[1] = c.r[2];  // 06040C8E mov r2,r1
    c.r[1] += 1;  // 06040C90 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040C92 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06040C94 mov r1,r0
    c.r[0] >>= 2;  // 06040C96 shlr2 r0
    c.r[0] >>= 2;  // 06040C98 shlr2 r0
    c.r[0] &= 0x1u;  // 06040C9A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06040C9C tst r0,r0
    if (c.t) { goto L_06040CAE; }  // 06040C9E bt 0x06040CAE
    c.r[2] += 65;  // 06040CA0 add #65,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06040CA2 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06040CA4 extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 06040CA6 mul.l r7,r1
    c.r[7] = c.macl;  // 06040CA8 sts macl,r7
    c.r[7] += c.r[3]; goto L_06040CB0;  // 06040CAA bra 0x06040CB0 ; add r3,r7
L_06040CAE:
    c.r[7] = c.r[2];  // 06040CAE mov r2,r7
L_06040CB0:
    c.r[2] = ld32(c.r[14]);  // 06040CB0 mov.l @r14,r2
    c.r[3] = ld32(0x06040DD4u);  // 06040CB2 mov.l 0x06040DD4,r3
    c.r[2] += c.r[2];  // 06040CB4 add r2,r2
    c.r[2] += c.r[3];  // 06040CB6 add r3,r2
    c.r[1] = c.r[2];  // 06040CB8 mov r2,r1
    c.r[1] += 47;  // 06040CBA add #47,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040CBC mov.b @r1,r1
    c.r[2] += 48;  // 06040CBE add #48,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06040CC0 extu.b r1,r1
    c.r[6] = c.r[1];  // 06040CC2 mov r1,r6
    c.r[6] <<= 2;  // 06040CC4 shll2 r6
    c.r[6] += c.r[6];  // 06040CC6 add r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06040CC8 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06040CCA extu.b r1,r1
    c.r[0] = c.r[1];  // 06040CCC mov r1,r0
    c.r[0] <<= 2;  // 06040CCE shll2 r0
    c.r[0] += c.r[0];  // 06040CD0 add r0,r0
    c.r[2] = ld32(c.r[14]);  // 06040CD2 mov.l @r14,r2
    st32(c.r[14] + 4, c.r[0]);  // 06040CD4 mov.l r0,@(4,r14)
    c.r[2] <<= 2;  // 06040CD6 shll2 r2
    c.r[2] += c.r[3];  // 06040CD8 add r3,r2
    c.r[1] = c.r[2];  // 06040CDA mov r2,r1
    c.r[2] += 56;  // 06040CDC add #56,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06040CDE mov.w @r2,r2
    c.r[1] += 54;  // 06040CE0 add #54,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06040CE2 mov.w @r1,r3
    st32(c.r[14] + 8, c.r[2]);  // 06040CE4 mov.l r2,@(8,r14)
    c.r[1] = c.r[7];  // 06040CE6 mov r7,r1
    c.r[1] += 1;  // 06040CE8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040CEA mov.b @r1,r1
    c.r[0] = 0x1u;  // 06040CEC mov #1,r0
    c.r[1] >>= 2;  // 06040CEE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06040CF0 shlr r1
    c.r[1] &= c.r[0];  // 06040CF2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06040CF4 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06040D06; } }  // 06040CF6 bt/s 0x06040D06 ; mov r7,r1
    c.r[1] = ld32(c.r[7] + 4);  // 06040CFA mov.l @(4,r7),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06040CFC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06040CFE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06040D00 shar r1
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_06040D0A;  // 06040D02 bra 0x06040D0A ; exts.w r1,r4
L_06040D06:
    c.r[1] += 6;  // 06040D06 add #6,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06040D08 mov.w @r1,r4
L_06040D0A:
    c.r[1] = c.r[7];  // 06040D0A mov r7,r1
    c.r[1] += 1;  // 06040D0C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040D0E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06040D10 mov r1,r0
    c.r[0] >>= 2;  // 06040D12 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06040D14 shlr r0
    c.r[0] &= 0x1u;  // 06040D16 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06040D18 tst r0,r0
    if (c.t) { goto L_06040D28; }  // 06040D1A bt 0x06040D28
    c.r[1] = ld32(c.r[7] + 8);  // 06040D1C mov.l @(8,r7),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06040D1E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06040D20 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06040D22 shar r1
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_06040D2C;  // 06040D24 bra 0x06040D2C ; exts.w r1,r12
L_06040D28:
    c.r[7] += 10;  // 06040D28 add #10,r7
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06040D2A mov.w @r7,r12
L_06040D2C:
    c.r[4] -= c.r[6];  // 06040D2C sub r6,r4
    c.r[0] = ld32(0x06040DD8u);  // 06040D2E mov.l 0x06040DD8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06040D34u; c.r[4] -= c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040D34u) return; }  // 06040D30 jsr @r0 ; sub r3,r4
    c.r[4] = c.r[0];  // 06040D34 mov r0,r4
    c.r[5] = c.r[1];  // 06040D36 mov r1,r5
    c.r[1] = ld32(0x06040DDCu);  // 06040D38 mov.l 0x06040DDC,r1
    c.r[8] = ld32(c.r[1]);  // 06040D3A mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 06040D3C mov.l @(4,r1),r9
    c.r[11] = ld32(0x06040DE0u);  // 06040D3E mov.l 0x06040DE0,r11
    c.r[6] = c.r[8];  // 06040D40 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06040D46u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040D46u) return; }  // 06040D42 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 06040D46 mov r0,r4
    c.r[10] = ld32(0x06040DE4u);  // 06040D48 mov.l 0x06040DE4,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06040D4Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040D4Eu) return; }  // 06040D4A jsr @r10 ; mov r1,r5
    c.r[13] = c.r[0];  // 06040D4E mov r0,r13
    c.r[0] = ld32(c.r[14] + 4);  // 06040D50 mov.l @(4,r14),r0
    c.r[12] -= c.r[0];  // 06040D52 sub r0,r12
    c.r[0] = ld32(c.r[14] + 8);  // 06040D54 mov.l @(8,r14),r0
    c.r[12] -= c.r[0];  // 06040D56 sub r0,r12
    c.r[0] = ld32(0x06040DD8u);  // 06040D58 mov.l 0x06040DD8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06040D5Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040D5Eu) return; }  // 06040D5A jsr @r0 ; mov r12,r4
    c.r[4] = c.r[0];  // 06040D5E mov r0,r4
    c.r[5] = c.r[1];  // 06040D60 mov r1,r5
    c.r[6] = c.r[8];  // 06040D62 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06040D68u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040D68u) return; }  // 06040D64 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 06040D68 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06040D6Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040D6Eu) return; }  // 06040D6A jsr @r10 ; mov r1,r5
    c.r[3] = c.r[0];  // 06040D6E mov r0,r3
    c.r[2] = ld32(c.r[14]);  // 06040D70 mov.l @r14,r2
    c.r[1] = ld32(0x06040DD4u);  // 06040D72 mov.l 0x06040DD4,r1
    c.r[0] = ld32(c.r[14]);  // 06040D74 mov.l @r14,r0
    c.r[2] <<= 2;  // 06040D76 shll2 r2
    c.r[2] += c.r[2];  // 06040D78 add r2,r2
    c.r[2] += c.r[1];  // 06040D7A add r1,r2
    c.r[1] = c.r[2];  // 06040D7C mov r2,r1
    c.r[1] += 108;  // 06040D7E add #108,r1
    st32(c.r[1], c.r[13]);  // 06040D80 mov.l r13,@r1
    c.r[2] += 112;  // 06040D82 add #112,r2
    c.t = c.r[0] == 0x1u;  // 06040D84 cmp/eq #1,r0
    { const bool k = c.t; st32(c.r[2], c.r[3]); if (k) { goto L_06040DAC; } }  // 06040D86 bt/s 0x06040DAC ; mov.l r3,@r2
    c.r[1] = 0x1u;  // 06040D8A mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06040D8C cmp/gt r1,r0
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06040D9A; } }  // 06040D8E bt/s 0x06040D9A ; tst r0,r0
    if (c.t) { goto L_06040DA6; }  // 06040D92 bt 0x06040DA6
    c.r[14] += 12;  // 06040D94 add #12,r14
    c.r[15] = c.r[14]; goto L_06040DBC;  // 06040D96 bra 0x06040DBC ; mov r14,r15
L_06040D9A:
    c.r[0] = ld32(c.r[14]);  // 06040D9A mov.l @r14,r0
    c.t = c.r[0] == 0x2u;  // 06040D9C cmp/eq #2,r0
    { const bool k = c.t; c.r[5] = c.r[3]; if (k) { goto L_06040DB2; } }  // 06040D9E bt/s 0x06040DB2 ; mov r3,r5
    c.r[14] += 12; goto L_06040DBA;  // 06040DA2 bra 0x06040DBA ; add #12,r14
L_06040DA6:
    c.r[1] = ld32(0x06040DE8u);  // 06040DA6 mov.l 0x06040DE8,r1
    c.r[5] = c.r[3]; goto L_06040DB4;  // 06040DA8 bra 0x06040DB4 ; mov r3,r5
L_06040DAC:
    c.r[1] = ld32(0x06040DECu);  // 06040DAC mov.l 0x06040DEC,r1
    c.r[5] = c.r[3]; goto L_06040DB4;  // 06040DAE bra 0x06040DB4 ; mov r3,r5
L_06040DB2:
    c.r[1] = ld32(0x06040DF0u);  // 06040DB2 mov.l 0x06040DF0,r1
L_06040DB4:
    { const uint32_t x = c.r[1]; c.pr = 0x06040DB8u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040DB8u) return; }  // 06040DB4 jsr @r1 ; mov r13,r4
    c.r[14] += 12;  // 06040DB8 add #12,r14
L_06040DBA:
    c.r[15] = c.r[14];  // 06040DBA mov r14,r15
L_06040DBC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06040DBC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06040DBE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06040DC0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06040DC2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06040DC4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06040DC6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06040DC8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06040DCA rts ; mov.l @r15+,r8
}

void f_06040DF4(SH2Context& c) {
    ran[1032] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06040DF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06040DF6 sts.l pr,@-r15
    c.r[1] = ld32(0x06040E10u);  // 06040DF8 mov.l 0x06040E10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040DFEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040DFEu) return; }  // 06040DFA jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06040E14u);  // 06040DFE mov.l 0x06040E14,r1
    c.r[5] = 0x7Fu;  // 06040E00 mov #127,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06040E06u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040E06u) return; }  // 06040E02 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 06040E06 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06040E08 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06040E0A rts ; mov.l @r15+,r14
}

void f_06040E88(SH2Context& c) {
    ran[1033] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06040E88 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06040E8A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06040E8C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06040E8E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06040E90 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06040E92 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06040E94 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06040E96 sts.l pr,@-r15
    c.r[15] -= 64;  // 06040E98 add #-64,r15
    c.r[1] = ld32(0x0604106Cu);  // 06040E9A mov.l 0x0604106C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06040E9C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06040E9E mov r1,r0
    c.r[0] >>= 2;  // 06040EA0 shlr2 r0
    c.r[0] >>= 2;  // 06040EA2 shlr2 r0
    c.r[0] &= 0x1u;  // 06040EA4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06040EA6 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06040EB0; } }  // 06040EA8 bf/s 0x06040EB0 ; mov r15,r14
    goto L_060410E4;  // 06040EAC bra 0x060410E4 ; nop
L_06040EB0:
    c.r[8] = (uint32_t)(int16_t)ld16(0x06041068u);  // 06040EB0 mov.w 0x06041068,r8
    c.r[9] = ld32(0x06041070u);  // 06040EB2 mov.l 0x06041070,r9
    c.r[5] = 0x4u;  // 06040EB4 mov #4,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06040EBAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040EBAu) return; }  // 06040EB6 jsr @r9 ; mov #0,r4
    c.r[1] = ld32(0x06041074u);  // 06040EBA mov.l 0x06041074,r1
    c.r[5] = c.r[8];  // 06040EBC mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06040EC2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040EC2u) return; }  // 06040EBE jsr @r1 ; mov r0,r4
    c.r[1] = ld32(0x06041078u);  // 06040EC2 mov.l 0x06041078,r1
    c.r[5] = ld32(0x0604107Cu);  // 06040EC4 mov.l 0x0604107C,r5
    c.r[10] = ld32(0x06041080u);  // 06040EC6 mov.l 0x06041080,r10
    c.r[6] = ld32(c.r[1]);  // 06040EC8 mov.l @r1,r6
    c.r[4] = c.r[14];  // 06040ECA mov r14,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06040ED0u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040ED0u) return; }  // 06040ECC jsr @r10 ; extu.w r6,r6
    c.r[5] = 0x4u;  // 06040ED0 mov #4,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06040ED6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040ED6u) return; }  // 06040ED2 jsr @r9 ; mov #0,r4
    c.r[8] = ld32(0x06041084u);  // 06040ED6 mov.l 0x06041084,r8
    c.r[5] = c.r[0];  // 06040ED8 mov r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06040EDEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040EDEu) return; }  // 06040EDA jsr @r8 ; mov r14,r4
    c.r[1] = ld32(0x06041088u);  // 06040EDE mov.l 0x06041088,r1
    c.r[7] = 0x1u;  // 06040EE0 mov #1,r7
    c.r[3] = ld32(c.r[1]);  // 06040EE2 mov.l @r1,r3
    c.r[6] = 0x0u;  // 06040EE4 mov #0,r6
    c.r[2] = c.r[3];  // 06040EE6 mov r3,r2
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 06040EE8 shar r3
    c.r[1] = 0x1u;  // 06040EEA mov #1,r1
    c.r[1] &= c.r[2];  // 06040EEC and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06040EEE tst r1,r1
    { const bool k = c.t; c.r[7] &= c.r[3]; if (k) { goto L_06040EF6; } }  // 06040EF0 bt/s 0x06040EF6 ; and r3,r7
    c.r[6] = 0x1u;  // 06040EF4 mov #1,r6
L_06040EF6:
    c.r[5] = ld32(0x0604108Cu);  // 06040EF6 mov.l 0x0604108C,r5
    c.r[1] = c.r[2];  // 06040EF8 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06040EFA rotl r1
    c.r[1] = c.t;  // 06040EFC movt r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06040EFE mov.l r1,@-r15
    c.r[1] = ld32(0x06041090u);  // 06040F00 mov.l 0x06041090,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F06u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F06u) return; }  // 06040F02 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F06 mov r4,r0
    c.r[0] &= 0x1u;  // 06040F08 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F0A mov.l r0,@-r15
    c.r[1] = ld32(0x06041094u);  // 06040F0C mov.l 0x06041094,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F12u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F12u) return; }  // 06040F0E jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F12 mov r4,r0
    c.r[0] &= 0x1u;  // 06040F14 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F16 mov.l r0,@-r15
    c.r[1] = ld32(0x06041098u);  // 06040F18 mov.l 0x06041098,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F1Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F1Eu) return; }  // 06040F1A jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F1E mov r4,r0
    c.r[0] &= 0x1u;  // 06040F20 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F22 mov.l r0,@-r15
    c.r[1] = ld32(0x0604109Cu);  // 06040F24 mov.l 0x0604109C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F2Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F2Au) return; }  // 06040F26 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F2A mov r4,r0
    c.r[0] &= 0x1u;  // 06040F2C and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F2E mov.l r0,@-r15
    c.r[1] = ld32(0x060410A0u);  // 06040F30 mov.l 0x060410A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F36u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F36u) return; }  // 06040F32 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F36 mov r4,r0
    c.r[0] &= 0x1u;  // 06040F38 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F3A mov.l r0,@-r15
    c.r[1] = ld32(0x060410A4u);  // 06040F3C mov.l 0x060410A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F42u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F42u) return; }  // 06040F3E jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F42 mov r4,r0
    c.r[0] &= 0x1u;  // 06040F44 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F46 mov.l r0,@-r15
    c.r[1] = ld32(0x060410A8u);  // 06040F48 mov.l 0x060410A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F4Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F4Eu) return; }  // 06040F4A jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F4E mov r4,r0
    c.r[0] &= 0x1u;  // 06040F50 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F52 mov.l r0,@-r15
    c.r[1] = ld32(0x060410ACu);  // 06040F54 mov.l 0x060410AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F5Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F5Au) return; }  // 06040F56 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F5A mov r4,r0
    c.r[0] &= 0x1u;  // 06040F5C and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F5E mov.l r0,@-r15
    c.r[1] = ld32(0x060410B0u);  // 06040F60 mov.l 0x060410B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F66u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F66u) return; }  // 06040F62 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F66 mov r4,r0
    c.r[0] &= 0x1u;  // 06040F68 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F6A mov.l r0,@-r15
    c.r[1] = ld32(0x060410B4u);  // 06040F6C mov.l 0x060410B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F72u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F72u) return; }  // 06040F6E jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F72 mov r4,r0
    c.r[0] &= 0x1u;  // 06040F74 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F76 mov.l r0,@-r15
    c.r[1] = ld32(0x060410B8u);  // 06040F78 mov.l 0x060410B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040F7Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040F7Eu) return; }  // 06040F7A jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040F7E mov r4,r0
    c.r[0] &= 0x1u;  // 06040F80 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F82 mov.l r0,@-r15
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 06040F84 swap.w r2,r0
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 06040F86 exts.w r0,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06040F88 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06040F8A shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06040F8C shar r0
    c.r[0] &= 0x1u;  // 06040F8E and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F90 mov.l r0,@-r15
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 06040F92 swap.w r2,r0
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 06040F94 exts.w r0,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06040F96 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06040F98 shar r0
    c.r[0] &= 0x1u;  // 06040F9A and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040F9C mov.l r0,@-r15
    c.r[0] = c.r[2];  // 06040F9E mov r2,r0
    c.r[0] >>= 16;  // 06040FA0 shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06040FA2 shlr r0
    c.r[0] &= 0x1u;  // 06040FA4 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FA6 mov.l r0,@-r15
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 06040FA8 swap.w r2,r0
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 06040FAA exts.w r0,r0
    c.r[0] &= 0x1u;  // 06040FAC and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FAE mov.l r0,@-r15
    c.r[1] = ld32(0x060410BCu);  // 06040FB0 mov.l 0x060410BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FB6u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FB6u) return; }  // 06040FB2 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FB6 mov r4,r0
    c.r[0] &= 0x1u;  // 06040FB8 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FBA mov.l r0,@-r15
    c.r[1] = ld32(0x060410C0u);  // 06040FBC mov.l 0x060410C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FC2u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FC2u) return; }  // 06040FBE jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FC2 mov r4,r0
    c.r[0] &= 0x1u;  // 06040FC4 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FC6 mov.l r0,@-r15
    c.r[1] = ld32(0x060410C4u);  // 06040FC8 mov.l 0x060410C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FCEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FCEu) return; }  // 06040FCA jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FCE mov r4,r0
    c.r[0] &= 0x1u;  // 06040FD0 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FD2 mov.l r0,@-r15
    c.r[1] = ld32(0x060410C8u);  // 06040FD4 mov.l 0x060410C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FDAu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FDAu) return; }  // 06040FD6 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FDA mov r4,r0
    c.r[0] &= 0x1u;  // 06040FDC and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FDE mov.l r0,@-r15
    c.r[1] = ld32(0x060410CCu);  // 06040FE0 mov.l 0x060410CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FE6u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FE6u) return; }  // 06040FE2 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FE6 mov r4,r0
    c.r[0] &= 0x1u;  // 06040FE8 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FEA mov.l r0,@-r15
    c.r[1] = ld32(0x060410D0u);  // 06040FEC mov.l 0x060410D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FF2u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FF2u) return; }  // 06040FEE jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FF2 mov r4,r0
    c.r[0] &= 0x1u;  // 06040FF4 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06040FF6 mov.l r0,@-r15
    c.r[1] = ld32(0x060410D4u);  // 06040FF8 mov.l 0x060410D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06040FFEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06040FFEu) return; }  // 06040FFA jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06040FFE mov r4,r0
    c.r[0] &= 0x1u;  // 06041000 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06041002 mov.l r0,@-r15
    c.r[1] = ld32(0x060410D8u);  // 06041004 mov.l 0x060410D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604100Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604100Au) return; }  // 06041006 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 0604100A mov r4,r0
    c.r[0] &= 0x1u;  // 0604100C and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0604100E mov.l r0,@-r15
    c.r[1] = ld32(0x060410DCu);  // 06041010 mov.l 0x060410DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041016u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041016u) return; }  // 06041012 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06041016 mov r4,r0
    c.r[0] &= 0x1u;  // 06041018 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0604101A mov.l r0,@-r15
    c.r[1] = ld32(0x060410E0u);  // 0604101C mov.l 0x060410E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041022u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041022u) return; }  // 0604101E jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06041022 mov r4,r0
    c.r[0] &= 0x1u;  // 06041024 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06041026 mov.l r0,@-r15
    c.r[0] = c.r[3];  // 06041028 mov r3,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604102A shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604102C shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604102E shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06041030 shar r0
    c.r[0] &= 0x1u;  // 06041032 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06041034 mov.l r0,@-r15
    c.r[0] = c.r[3];  // 06041036 mov r3,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 06041038 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604103A shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0604103C shar r0
    c.r[0] &= 0x1u;  // 0604103E and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06041040 mov.l r0,@-r15
    c.r[0] = c.r[3];  // 06041042 mov r3,r0
    c.r[0] >>= 2;  // 06041044 shlr2 r0
    c.r[0] &= 0x1u;  // 06041046 and #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06041048 mov.l r0,@-r15
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0604104A shar r3
    c.r[13] = 0x1u;  // 0604104C mov #1,r13
    c.r[3] &= c.r[13];  // 0604104E and r13,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06041050 mov.l r3,@-r15
    { const uint32_t x = c.r[10]; c.pr = 0x06041056u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041056u) return; }  // 06041052 jsr @r10 ; mov r14,r4
    c.r[15] += 120;  // 06041056 add #120,r15
    c.r[5] = 0x5u;  // 06041058 mov #5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604105Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604105Eu) return; }  // 0604105A jsr @r9 ; mov #0,r4
    c.r[5] = c.r[0];  // 0604105E mov r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06041064u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041064u) return; }  // 06041060 jsr @r8 ; mov r14,r4
    goto L_060410E4;  // 06041064 bra 0x060410E4 ; nop
L_060410E4:
    c.r[1] = ld32(0x06041154u);  // 060410E4 mov.l 0x06041154,r1
    c.r[8] = ld32(c.r[1]);  // 060410E6 mov.l @r1,r8
    c.r[11] = (uint32_t)(int16_t)ld16(0x06041150u);  // 060410E8 mov.w 0x06041150,r11
    c.r[10] = 0x6u;  // 060410EA mov #6,r10
    c.r[12] = ld32(0x06041158u);  // 060410EC mov.l 0x06041158,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041152u);  // 060410EE mov.w 0x06041152,r1
    c.r[8] += c.r[1];  // 060410F0 add r1,r8
    c.r[9] = c.r[8];  // 060410F2 mov r8,r9
    c.r[9] += 1;  // 060410F4 add #1,r9
L_060410F6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060410F6 mov.b @r9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060410F8 extu.b r1,r1
    c.r[0] = c.r[1];  // 060410FA mov r1,r0
    c.r[0] >>= 2;  // 060410FC shlr2 r0
    c.r[0] >>= 2;  // 060410FE shlr2 r0
    c.r[0] >>= 2;  // 06041100 shlr2 r0
    c.r[0] &= 0x1u;  // 06041102 and #1,r0
    c.r[1] >>= 2;  // 06041104 shlr2 r1
    c.r[1] >>= 2;  // 06041106 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06041108 shlr r1
    c.r[1] >>= 2;  // 0604110A shlr2 r1
    c.r[1] &= c.r[0];  // 0604110C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604110E tst r1,r1
    { const bool k = c.t; c.r[9] -= 76; if (k) { goto L_06041132; } }  // 06041110 bt/s 0x06041132 ; add #-76,r9
    c.r[1] = ld32(0x0604115Cu);  // 06041114 mov.l 0x0604115C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041116 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06041118 mov r1,r0
    c.r[0] >>= 2;  // 0604111A shlr2 r0
    c.r[0] >>= 2;  // 0604111C shlr2 r0
    c.r[0] &= 0x1u;  // 0604111E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041120 tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[10] & 0xFFFFu; if (k) { goto L_0604112C; } }  // 06041122 bt/s 0x0604112C ; extu.w r10,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0604112Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604112Au) return; }  // 06041126 jsr @r12 ; mov r8,r4
    c.r[10] += 1;  // 0604112A add #1,r10
L_0604112C:
    c.r[1] = ld32(0x06041160u);  // 0604112C mov.l 0x06041160,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041132u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041132u) return; }  // 0604112E jsr @r1 ; mov r8,r4
L_06041132:
    c.r[11] -= 1;  // 06041132 add #-1,r11
    c.t = (int32_t)c.r[11] >= 0;  // 06041134 cmp/pz r11
    { const bool k = c.t; c.r[8] -= 76; if (k) { SH2_POLL(c); goto L_060410F6; } }  // 06041136 bt/s 0x060410F6 ; add #-76,r8
    c.r[14] += 64;  // 0604113A add #64,r14
    c.r[15] = c.r[14];  // 0604113C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604113E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041140 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06041142 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06041144 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06041146 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06041148 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604114A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604114C rts ; mov.l @r15+,r8
}

void f_06041164(SH2Context& c) {
    ran[1034] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041164 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06041166 mov r15,r14
    c.r[1] = ld32(0x06041214u);  // 06041168 mov.l 0x06041214,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604116A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604116C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0604116E cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = c.r[4] & 0xFFFFu; if (k) { goto L_060411AE; } }  // 06041170 bt/s 0x060411AE ; extu.w r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041210u);  // 06041174 mov.w 0x06041210,r1
    c.r[1] &= c.r[4];  // 06041176 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06041178 tst r1,r1
    if (c.t) { goto L_060411E4; }  // 0604117A bt 0x060411E4
    c.r[4] = 0x0u;  // 0604117C mov #0,r4
    c.r[7] = 0x7Fu;  // 0604117E mov #127,r7
    c.r[1] = ld32(0x06041218u);  // 06041180 mov.l 0x06041218,r1
    c.r[2] = ld32(c.r[1]);  // 06041182 mov.l @r1,r2
    c.r[3] = 0x4Cu;  // 06041184 mov #76,r3
    c.macl = c.r[4] * c.r[3];  // 06041186 mul.l r3,r4
L_06041188:
    c.r[1] = c.macl;  // 06041188 sts macl,r1
    c.r[1] += c.r[2];  // 0604118A add r2,r1
    c.r[1] += 1;  // 0604118C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604118E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06041190 extu.b r1,r1
    c.r[1] >>= 2;  // 06041192 shlr2 r1
    c.r[1] >>= 2;  // 06041194 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06041196 shlr r1
    c.r[1] >>= 2;  // 06041198 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604119A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_060411E4; } }  // 0604119C bt/s 0x060411E4 ; mov r4,r1
    c.r[1] += 1;  // 060411A0 add #1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 060411A2 extu.w r1,r4
    c.t = c.r[4] > c.r[7];  // 060411A4 cmp/hi r7,r4
    { const bool k = !c.t; c.macl = c.r[4] * c.r[3]; if (k) { SH2_POLL(c); goto L_06041188; } }  // 060411A6 bf/s 0x06041188 ; mul.l r3,r4
    goto L_060411E4;  // 060411AA bra 0x060411E4 ; nop
L_060411AE:
    c.r[1] = 0x40u;  // 060411AE mov #64,r1
    c.r[1] &= c.r[4];  // 060411B0 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060411B2 tst r1,r1
    if (c.t) { goto L_060411EC; }  // 060411B4 bt 0x060411EC
    c.r[4] = 0x20u;  // 060411B6 mov #32,r4
    c.r[6] = 0x3Fu;  // 060411B8 mov #63,r6
    c.r[1] = ld32(0x06041218u);  // 060411BA mov.l 0x06041218,r1
    c.r[3] = ld32(c.r[1]);  // 060411BC mov.l @r1,r3
    c.r[7] = 0x4Cu;  // 060411BE mov #76,r7
L_060411C0:
    c.macl = c.r[4] * c.r[7];  // 060411C0 mul.l r7,r4
    c.r[1] = c.macl;  // 060411C2 sts macl,r1
    c.r[1] += c.r[3];  // 060411C4 add r3,r1
    c.r[1] += 1;  // 060411C6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060411C8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060411CA extu.b r1,r1
    c.r[1] >>= 2;  // 060411CC shlr2 r1
    c.r[1] >>= 2;  // 060411CE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060411D0 shlr r1
    c.r[1] >>= 2;  // 060411D2 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060411D4 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_060411E4; } }  // 060411D6 bt/s 0x060411E4 ; mov r4,r2
    c.r[1] = c.r[2];  // 060411DA mov r2,r1
    c.r[1] += 1;  // 060411DC add #1,r1
    c.t = c.r[2] > c.r[6];  // 060411DE cmp/hi r6,r2
    { const bool k = !c.t; c.r[4] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060411C0; } }  // 060411E0 bf/s 0x060411C0 ; extu.w r1,r4
L_060411E4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041210u);  // 060411E4 mov.w 0x06041210,r1
    c.t = c.r[4] == c.r[1];  // 060411E6 cmp/eq r1,r4
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0604120A; } }  // 060411E8 bt/s 0x0604120A ; mov #0,r0
L_060411EC:
    c.r[3] = ld32(0x06041218u);  // 060411EC mov.l 0x06041218,r3
    c.r[2] = 0x7Fu;  // 060411EE mov #127,r2
    c.r[2] &= c.r[4];  // 060411F0 and r4,r2
    c.r[1] = 0x4Cu;  // 060411F2 mov #76,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060411F4 mulu.w r1,r2
    c.r[0] = ld32(c.r[3]);  // 060411F6 mov.l @r3,r0
    c.r[1] = c.macl;  // 060411F8 sts macl,r1
    c.r[0] += c.r[1];  // 060411FA add r1,r0
    c.r[1] = c.r[0];  // 060411FC mov r0,r1
    c.r[1] += 1;  // 060411FE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041200 mov.b @r1,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06041210u);  // 06041202 mov.w 0x06041210,r5
    c.r[2] |= c.r[5];  // 06041204 or r5,r2
    st8(c.r[1], c.r[2]);  // 06041206 mov.b r2,@r1
    st8(c.r[0], c.r[4]);  // 06041208 mov.b r4,@r0
L_0604120A:
    c.r[15] = c.r[14];  // 0604120A mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604120C rts ; mov.l @r15+,r14
}

void f_0604121C(SH2Context& c) {
    ran[1035] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604121C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604121E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06041220 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06041222 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06041224 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06041226 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041228 mov.l r14,@-r15
    c.r[15] -= 64;  // 0604122A add #-64,r15
    c.r[14] = c.r[15];  // 0604122C mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0604122E extu.w r4,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06041230 extu.w r5,r5
    st32(c.r[14], c.r[5]);  // 06041232 mov.l r5,@r14
    c.r[2] = ld32(0x060413A0u);  // 06041234 mov.l 0x060413A0,r2
    c.r[1] = 0x4Cu;  // 06041236 mov #76,r1
    c.r[3] = ld32(c.r[2]);  // 06041238 mov.l @r2,r3
    c.r[8] = c.r[4];  // 0604123A mov r4,r8
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604123C mulu.w r1,r4
    c.t = (int32_t)c.r[8] > (int32_t)c.r[5];  // 0604123E cmp/gt r5,r8
    c.r[1] = c.macl;  // 06041240 sts macl,r1
    { const bool k = !c.t; c.r[3] += c.r[1]; if (k) { goto L_0604124A; } }  // 06041242 bf/s 0x0604124A ; add r1,r3
    goto L_06041388;  // 06041246 bra 0x06041388 ; nop
L_0604124A:
    c.r[6] = 0x0u;  // 0604124A mov #0,r6
    c.r[9] = c.r[3];  // 0604124C mov r3,r9
    c.r[9] += 61;  // 0604124E add #61,r9
    st32(c.r[14] + 4, c.r[9]);  // 06041250 mov.l r9,@(4,r14)
    c.r[10] = c.r[3];  // 06041252 mov r3,r10
    c.r[10] += 72;  // 06041254 add #72,r10
    st32(c.r[14] + 8, c.r[10]);  // 06041256 mov.l r10,@(8,r14)
    c.r[9] = c.r[3];  // 06041258 mov r3,r9
    c.r[9] += 70;  // 0604125A add #70,r9
    st32(c.r[14] + 12, c.r[9]);  // 0604125C mov.l r9,@(12,r14)
    c.r[10] = c.r[3];  // 0604125E mov r3,r10
    c.r[10] += 69;  // 06041260 add #69,r10
    st32(c.r[14] + 16, c.r[10]);  // 06041262 mov.l r10,@(16,r14)
    c.r[9] = c.r[3];  // 06041264 mov r3,r9
    c.r[9] += 68;  // 06041266 add #68,r9
    st32(c.r[14] + 20, c.r[9]);  // 06041268 mov.l r9,@(20,r14)
    c.r[10] = c.r[3];  // 0604126A mov r3,r10
    c.r[10] += 67;  // 0604126C add #67,r10
    st32(c.r[14] + 24, c.r[10]);  // 0604126E mov.l r10,@(24,r14)
    c.r[9] = c.r[3];  // 06041270 mov r3,r9
    c.r[9] += 66;  // 06041272 add #66,r9
    st32(c.r[14] + 28, c.r[9]);  // 06041274 mov.l r9,@(28,r14)
    c.r[10] = c.r[3];  // 06041276 mov r3,r10
    c.r[10] += 65;  // 06041278 add #65,r10
    st32(c.r[14] + 32, c.r[10]);  // 0604127A mov.l r10,@(32,r14)
    c.r[9] = c.r[3];  // 0604127C mov r3,r9
    c.r[9] += 64;  // 0604127E add #64,r9
    st32(c.r[14] + 36, c.r[9]);  // 06041280 mov.l r9,@(36,r14)
    c.r[10] = c.r[3];  // 06041282 mov r3,r10
    c.r[10] += 63;  // 06041284 add #63,r10
    st32(c.r[14] + 40, c.r[10]);  // 06041286 mov.l r10,@(40,r14)
    c.r[9] = c.r[3];  // 06041288 mov r3,r9
    c.r[9] += 62;  // 0604128A add #62,r9
    st32(c.r[14] + 44, c.r[9]);  // 0604128C mov.l r9,@(44,r14)
    c.r[10] = c.r[3];  // 0604128E mov r3,r10
    c.r[10] += 54;  // 06041290 add #54,r10
    st32(c.r[14] + 48, c.r[10]);  // 06041292 mov.l r10,@(48,r14)
    c.r[9] = c.r[3];  // 06041294 mov r3,r9
    c.r[9] += 58;  // 06041296 add #58,r9
    st32(c.r[14] + 52, c.r[9]);  // 06041298 mov.l r9,@(52,r14)
    c.r[13] = c.r[3];  // 0604129A mov r3,r13
    c.r[13] += 56;  // 0604129C add #56,r13
    c.r[12] = c.r[3];  // 0604129E mov r3,r12
    c.r[12] += 60;  // 060412A0 add #60,r12
    c.r[11] = c.r[3];  // 060412A2 mov r3,r11
    c.r[11] += 52;  // 060412A4 add #52,r11
    c.r[10] = c.r[3];  // 060412A6 mov r3,r10
    c.r[10] += 18;  // 060412A8 add #18,r10
    st32(c.r[14] + 60, c.r[10]);  // 060412AA mov.l r10,@(60,r14)
    c.r[9] = c.r[3];  // 060412AC mov r3,r9
    c.r[9] += 16;  // 060412AE add #16,r9
    st32(c.r[14] + 56, c.r[9]);  // 060412B0 mov.l r9,@(56,r14)
    c.r[7] = c.r[3];  // 060412B2 mov r3,r7
    c.r[7] += 4;  // 060412B4 add #4,r7
    c.r[4] = c.r[3];  // 060412B6 mov r3,r4
    c.r[4] += 2;  // 060412B8 add #2,r4
    c.r[5] = c.r[3];  // 060412BA mov r3,r5
    c.r[5] += 1;  // 060412BC add #1,r5
L_060412BE:
    st8(c.r[3], c.r[8]);  // 060412BE mov.b r8,@r3
    c.r[1] = ld32(0x060413A4u);  // 060412C0 mov.l 0x060413A4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060412C2 mov.b @r5,r0
    c.r[8] += 1;  // 060412C4 add #1,r8
    c.r[0] &= 0x1u;  // 060412C6 and #1,r0
    st8(c.r[5], c.r[0]);  // 060412C8 mov.b r0,@r5
    c.r[2] = ld32(c.r[3]);  // 060412CA mov.l @r3,r2
    c.r[5] += 76;  // 060412CC add #76,r5
    c.r[2] &= c.r[1];  // 060412CE and r1,r2
    st32(c.r[3], c.r[2]);  // 060412D0 mov.l r2,@r3
    c.r[1] = ld32(0x060413A8u);  // 060412D2 mov.l 0x060413A8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060412D4 mov.b @r4,r0
    c.r[3] += 76;  // 060412D6 add #76,r3
    c.r[0] &= 0x8Cu;  // 060412D8 and #140,r0
    st8(c.r[4], c.r[0]);  // 060412DA mov.b r0,@r4
    st32(c.r[7], c.r[6]);  // 060412DC mov.l r6,@r7
    st32(c.r[7] + 4, c.r[6]);  // 060412DE mov.l r6,@(4,r7)
    st32(c.r[7] + 8, c.r[1]);  // 060412E0 mov.l r1,@(8,r7)
    c.r[1] = 0x64u;  // 060412E2 mov #100,r1
    c.r[10] = ld32(c.r[14] + 56);  // 060412E4 mov.l @(56,r14),r10
    c.r[4] += 76;  // 060412E6 add #76,r4
    c.r[9] = ld32(c.r[14] + 60);  // 060412E8 mov.l @(60,r14),r9
    st16(c.r[10], c.r[6]);  // 060412EA mov.w r6,@r10
    c.r[10] += 76;  // 060412EC add #76,r10
    st32(c.r[14] + 56, c.r[10]);  // 060412EE mov.l r10,@(56,r14)
    st16(c.r[9], c.r[6]);  // 060412F0 mov.w r6,@r9
    c.r[9] += 76;  // 060412F2 add #76,r9
    st32(c.r[14] + 60, c.r[9]);  // 060412F4 mov.l r9,@(60,r14)
    st32(c.r[7] + 16, c.r[6]);  // 060412F6 mov.l r6,@(16,r7)
    st32(c.r[7] + 20, c.r[6]);  // 060412F8 mov.l r6,@(20,r7)
    st32(c.r[7] + 24, c.r[6]);  // 060412FA mov.l r6,@(24,r7)
    st32(c.r[7] + 28, c.r[6]);  // 060412FC mov.l r6,@(28,r7)
    st32(c.r[7] + 32, c.r[6]);  // 060412FE mov.l r6,@(32,r7)
    st32(c.r[7] + 36, c.r[6]);  // 06041300 mov.l r6,@(36,r7)
    st32(c.r[7] + 40, c.r[1]);  // 06041302 mov.l r1,@(40,r7)
    st32(c.r[7] + 44, c.r[1]);  // 06041304 mov.l r1,@(44,r7)
    st16(c.r[11], c.r[6]);  // 06041306 mov.w r6,@r11
    c.r[11] += 76;  // 06041308 add #76,r11
    st8(c.r[12], c.r[6]);  // 0604130A mov.b r6,@r12
    c.r[12] += 76;  // 0604130C add #76,r12
    st16(c.r[13], c.r[6]);  // 0604130E mov.w r6,@r13
    c.r[10] = ld32(c.r[14] + 52);  // 06041310 mov.l @(52,r14),r10
    c.r[13] += 76;  // 06041312 add #76,r13
    c.r[9] = ld32(c.r[14] + 48);  // 06041314 mov.l @(48,r14),r9
    st16(c.r[10], c.r[6]);  // 06041316 mov.w r6,@r10
    c.r[10] += 76;  // 06041318 add #76,r10
    st32(c.r[14] + 52, c.r[10]);  // 0604131A mov.l r10,@(52,r14)
    c.r[10] = (uint32_t)(int16_t)ld16(0x0604139Cu);  // 0604131C mov.w 0x0604139C,r10
    st16(c.r[9], c.r[10]);  // 0604131E mov.w r10,@r9
    c.r[9] += 76;  // 06041320 add #76,r9
    st32(c.r[14] + 48, c.r[9]);  // 06041322 mov.l r9,@(48,r14)
    c.r[9] = ld32(c.r[14] + 44);  // 06041324 mov.l @(44,r14),r9
    c.r[1] = 0xAu;  // 06041326 mov #10,r1
    st8(c.r[9], c.r[6]);  // 06041328 mov.b r6,@r9
    c.r[9] += 76;  // 0604132A add #76,r9
    c.r[10] = ld32(c.r[14] + 40);  // 0604132C mov.l @(40,r14),r10
    st32(c.r[14] + 44, c.r[9]);  // 0604132E mov.l r9,@(44,r14)
    st8(c.r[10], c.r[6]);  // 06041330 mov.b r6,@r10
    c.r[10] += 76;  // 06041332 add #76,r10
    c.r[9] = ld32(c.r[14] + 36);  // 06041334 mov.l @(36,r14),r9
    st32(c.r[14] + 40, c.r[10]);  // 06041336 mov.l r10,@(40,r14)
    st8(c.r[9], c.r[1]);  // 06041338 mov.b r1,@r9
    c.r[9] += 76;  // 0604133A add #76,r9
    st32(c.r[14] + 36, c.r[9]);  // 0604133C mov.l r9,@(36,r14)
    c.r[10] = ld32(c.r[14] + 32);  // 0604133E mov.l @(32,r14),r10
    c.r[9] = 0xFFFFFFFFu;  // 06041340 mov #-1,r9
    st8(c.r[10], c.r[9]);  // 06041342 mov.b r9,@r10
    c.r[10] += 76;  // 06041344 add #76,r10
    st32(c.r[14] + 32, c.r[10]);  // 06041346 mov.l r10,@(32,r14)
    c.r[10] = ld32(c.r[14] + 28);  // 06041348 mov.l @(28,r14),r10
    c.r[7] += 76;  // 0604134A add #76,r7
    st8(c.r[10], c.r[6]);  // 0604134C mov.b r6,@r10
    c.r[10] += 76;  // 0604134E add #76,r10
    c.r[9] = ld32(c.r[14] + 24);  // 06041350 mov.l @(24,r14),r9
    st32(c.r[14] + 28, c.r[10]);  // 06041352 mov.l r10,@(28,r14)
    st8(c.r[9], c.r[6]);  // 06041354 mov.b r6,@r9
    c.r[9] += 76;  // 06041356 add #76,r9
    c.r[10] = ld32(c.r[14] + 20);  // 06041358 mov.l @(20,r14),r10
    st32(c.r[14] + 24, c.r[9]);  // 0604135A mov.l r9,@(24,r14)
    st8(c.r[10], c.r[6]);  // 0604135C mov.b r6,@r10
    c.r[10] += 76;  // 0604135E add #76,r10
    c.r[9] = ld32(c.r[14] + 16);  // 06041360 mov.l @(16,r14),r9
    st32(c.r[14] + 20, c.r[10]);  // 06041362 mov.l r10,@(20,r14)
    st8(c.r[9], c.r[6]);  // 06041364 mov.b r6,@r9
    c.r[9] += 76;  // 06041366 add #76,r9
    c.r[10] = ld32(c.r[14] + 12);  // 06041368 mov.l @(12,r14),r10
    st32(c.r[14] + 16, c.r[9]);  // 0604136A mov.l r9,@(16,r14)
    st8(c.r[10], c.r[6]);  // 0604136C mov.b r6,@r10
    c.r[10] += 76;  // 0604136E add #76,r10
    c.r[9] = ld32(c.r[14] + 8);  // 06041370 mov.l @(8,r14),r9
    st32(c.r[14] + 12, c.r[10]);  // 06041372 mov.l r10,@(12,r14)
    c.r[10] = ld32(c.r[14] + 4);  // 06041374 mov.l @(4,r14),r10
    st16(c.r[9], c.r[6]);  // 06041376 mov.w r6,@r9
    c.r[9] += 76;  // 06041378 add #76,r9
    st32(c.r[14] + 8, c.r[9]);  // 0604137A mov.l r9,@(8,r14)
    st8(c.r[10], c.r[6]);  // 0604137C mov.b r6,@r10
    c.r[10] += 76;  // 0604137E add #76,r10
    c.r[9] = ld32(c.r[14]);  // 06041380 mov.l @r14,r9
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06041382 cmp/gt r9,r8
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[10]); if (k) { SH2_POLL(c); goto L_060412BE; } }  // 06041384 bf/s 0x060412BE ; mov.l r10,@(4,r14)
L_06041388:
    c.r[14] += 64;  // 06041388 add #64,r14
    c.r[15] = c.r[14];  // 0604138A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604138C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604138E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06041390 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06041392 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06041394 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041396 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06041398 rts ; mov.l @r15+,r8
}

void f_060413AC(SH2Context& c) {
    ran[1036] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060413AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060413AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060413B0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060413B2 mov r15,r14
    c.r[3] = c.r[4];  // 060413B4 mov r4,r3
    c.r[5] = c.r[5] & 0xFFFFu;  // 060413B6 extu.w r5,r5
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060413B8 exts.w r5,r2
    c.r[0] = c.r[2];  // 060413BA mov r2,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060413BC shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060413BE shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060413C0 shar r0
    c.r[0] <<= 2;  // 060413C2 shll2 r0
    c.r[0] <<= 2;  // 060413C4 shll2 r0
    c.r[0] <<= 2;  // 060413C6 shll2 r0
    c.r[7] = c.r[3];  // 060413C8 mov r3,r7
    c.r[7] += 1;  // 060413CA add #1,r7
    c.r[0] &= 0x80u;  // 060413CC and #128,r0
    c.r[6] = 0x7Fu;  // 060413CE mov #127,r6
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604147Eu);  // 060413D0 mov.w 0x0604147E,r8
    c.r[4] = c.r[2];  // 060413D2 mov r2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060413D4 mov.b @r7,r1
    c.r[6] &= c.r[1];  // 060413D6 and r1,r6
    c.r[6] |= c.r[0];  // 060413D8 or r0,r6
    c.r[1] = 0x1u;  // 060413DA mov #1,r1
    c.r[1] &= c.r[5];  // 060413DC and r5,r1
    c.r[1] <<= 2;  // 060413DE shll2 r1
    c.r[1] += c.r[1];  // 060413E0 add r1,r1
    c.r[6] &= c.r[8];  // 060413E2 and r8,r6
    c.r[6] |= c.r[1];  // 060413E4 or r1,r6
    c.r[0] = c.r[2];  // 060413E6 mov r2,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060413E8 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060413EA shar r0
    c.r[0] &= 0x2u;  // 060413EC and #2,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x06041480u);  // 060413EE mov.w 0x06041480,r8
    c.r[6] &= c.r[8];  // 060413F0 and r8,r6
    c.r[6] |= c.r[0];  // 060413F2 or r0,r6
    c.r[0] = c.r[2];  // 060413F4 mov r2,r0
    c.r[0] += c.r[0];  // 060413F6 add r0,r0
    c.r[0] &= 0x40u;  // 060413F8 and #64,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x06041482u);  // 060413FA mov.w 0x06041482,r8
    c.r[6] &= c.r[8];  // 060413FC and r8,r6
    c.r[1] = ld32(0x0604148Cu);  // 060413FE mov.l 0x0604148C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041404u; c.r[6] |= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041404u) return; }  // 06041400 jsr @r1 ; or r0,r6
    c.r[0] = c.r[4];  // 06041404 mov r4,r0
    c.r[0] &= 0x1u;  // 06041406 and #1,r0
    c.r[0] <<= 2;  // 06041408 shll2 r0
    c.r[0] <<= 2;  // 0604140A shll2 r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x06041484u);  // 0604140C mov.w 0x06041484,r8
    c.r[6] &= c.r[8];  // 0604140E and r8,r6
    c.r[6] |= c.r[0];  // 06041410 or r0,r6
    c.r[1] = ld32(0x06041490u);  // 06041412 mov.l 0x06041490,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041418u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041418u) return; }  // 06041414 jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 06041418 mov r4,r0
    c.r[0] &= 0x1u;  // 0604141A and #1,r0
    c.r[0] <<= 2;  // 0604141C shll2 r0
    c.r[0] += c.r[0];  // 0604141E add r0,r0
    c.r[0] <<= 2;  // 06041420 shll2 r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x06041486u);  // 06041422 mov.w 0x06041486,r8
    c.r[6] &= c.r[8];  // 06041424 and r8,r6
    c.r[6] |= c.r[0];  // 06041426 or r0,r6
    c.r[1] = ld32(0x06041494u);  // 06041428 mov.l 0x06041494,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604142Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604142Eu) return; }  // 0604142A jsr @r1 ; mov r2,r4
    c.r[0] = c.r[4];  // 0604142E mov r4,r0
    c.r[0] &= 0x1u;  // 06041430 and #1,r0
    c.r[0] <<= 2;  // 06041432 shll2 r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x06041488u);  // 06041434 mov.w 0x06041488,r8
    c.r[6] &= c.r[8];  // 06041436 and r8,r6
    c.r[6] |= c.r[0];  // 06041438 or r0,r6
    st8(c.r[7], c.r[6]);  // 0604143A mov.b r6,@r7
    c.r[1] = c.r[3];  // 0604143C mov r3,r1
    c.r[1] += 62;  // 0604143E add #62,r1
    c.r[0] = c.r[5];  // 06041440 mov r5,r0
    c.r[0] >>= 8;  // 06041442 shlr8 r0
    c.r[0] >>= 2;  // 06041444 shlr2 r0
    c.r[0] >>= 2;  // 06041446 shlr2 r0
    c.r[0] &= 0x3u;  // 06041448 and #3,r0
    st8(c.r[1], c.r[0]);  // 0604144A mov.b r0,@r1
    c.r[2] = c.r[3];  // 0604144C mov r3,r2
    c.r[2] += 63;  // 0604144E add #63,r2
    c.r[1] = c.r[5];  // 06041450 mov r5,r1
    c.r[1] >>= 8;  // 06041452 shlr8 r1
    c.r[1] <<= 2;  // 06041454 shll2 r1
    c.r[1] >>= 8;  // 06041456 shlr8 r1
    st8(c.r[2], c.r[1]);  // 06041458 mov.b r1,@r2
    c.r[3] += 72;  // 0604145A add #72,r3
    c.r[1] = 0x6u;  // 0604145C mov #6,r1
    c.r[1] &= c.r[5];  // 0604145E and r5,r1
    c.r[1] <<= 2;  // 06041460 shll2 r1
    c.r[1] <<= 2;  // 06041462 shll2 r1
    c.r[1] += c.r[1];  // 06041464 add r1,r1
    c.r[1] <<= 2;  // 06041466 shll2 r1
    c.r[5] >>= 2;  // 06041468 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0604146A shlr r5
    c.r[5] >>= 2;  // 0604146C shlr2 r5
    c.r[8] = 0x70u;  // 0604146E mov #112,r8
    c.r[5] &= c.r[8];  // 06041470 and r8,r5
    c.r[1] |= c.r[5];  // 06041472 or r5,r1
    st16(c.r[3], c.r[1]);  // 06041474 mov.w r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041476 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041478 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604147A rts ; mov.l @r15+,r8
}

void f_06041498(SH2Context& c) {
    ran[1037] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041498 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604149A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604149C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604149E mov r15,r14
    c.r[5] = c.r[5] & 0xFFFFu;  // 060414A0 extu.w r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041554u);  // 060414A2 mov.w 0x06041554,r1
    c.r[2] = c.r[1];  // 060414A4 mov r1,r2
    c.r[2] &= c.r[5];  // 060414A6 and r5,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060414A8 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 060414AA cmp/eq r1,r2
    { const bool k = !c.t; c.r[8] = c.r[4]; if (k) { goto L_060414CA; } }  // 060414AC bf/s 0x060414CA ; mov r4,r8
    c.r[1] = ld32(0x06041558u);  // 060414B0 mov.l 0x06041558,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060414B2 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060414B4 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060414B6 cmp/eq #1,r0
    if (!c.t) { goto L_060414CA; }  // 060414B8 bf 0x060414CA
    c.r[5] = c.r[5] & 0xFFu;  // 060414BA extu.b r5,r5
    c.r[1] = ld32(0x0604155Cu);  // 060414BC mov.l 0x0604155C,r1
    c.r[4] = ld32(c.r[1]);  // 060414BE mov.l @r1,r4
    c.r[0] = ld32(0x06041560u);  // 060414C0 mov.l 0x06041560,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060414C6u; c.r[6] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060414C6u) return; }  // 060414C2 jsr @r0 ; mov #2,r6
    st32(c.r[8] + 36, c.r[0]); goto L_06041518;  // 060414C6 bra 0x06041518 ; mov.l r0,@(36,r8)
L_060414CA:
    c.r[1] = ld32(0x06041564u);  // 060414CA mov.l 0x06041564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060414CC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060414CE mov r1,r0
    c.r[0] >>= 2;  // 060414D0 shlr2 r0
    c.r[0] >>= 2;  // 060414D2 shlr2 r0
    c.r[0] >>= 2;  // 060414D4 shlr2 r0
    c.r[0] &= 0x1u;  // 060414D6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060414D8 tst r0,r0
    if (c.t) { goto L_060414E2; }  // 060414DA bt 0x060414E2
    c.r[1] = ld32(0x06041568u);  // 060414DC mov.l 0x06041568,r1
    c.r[3] = ld32(c.r[1]); goto L_060414E6;  // 060414DE bra 0x060414E6 ; mov.l @r1,r3
L_060414E2:
    c.r[1] = ld32(0x0604156Cu);  // 060414E2 mov.l 0x0604156C,r1
    c.r[3] = ld32(c.r[1]);  // 060414E4 mov.l @r1,r3
L_060414E6:
    c.r[1] = c.r[3];  // 060414E6 mov r3,r1
    c.r[1] += 5;  // 060414E8 add #5,r1
    c.r[7] = c.r[3];  // 060414EA mov r3,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060414EC mov.b @r1,r2
    c.r[0] = c.r[3];  // 060414EE mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060414F0 extu.b r2,r2
    c.r[1] = c.r[3];  // 060414F2 mov r3,r1
    c.r[1] += 4;  // 060414F4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060414F6 mov.b @r1,r1
    c.r[2] <<= 8;  // 060414F8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060414FA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060414FC or r1,r2
    c.r[1] = c.r[5];  // 060414FE mov r5,r1
    c.r[1] += c.r[1];  // 06041500 add r1,r1
    c.r[1] += c.r[2];  // 06041502 add r2,r1
    c.r[7] += c.r[1];  // 06041504 add r1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06041506 mov.b @(r0,r1),r2
    c.r[7] += 1;  // 06041508 add #1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0604150A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604150C mov.b @r7,r1
    c.r[2] <<= 8;  // 0604150E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06041510 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06041512 or r1,r2
    c.r[3] += c.r[2];  // 06041514 add r2,r3
    st32(c.r[8] + 36, c.r[3]);  // 06041516 mov.l r3,@(36,r8)
L_06041518:
    c.r[2] = c.r[8];  // 06041518 mov r8,r2
    c.r[2] += 69;  // 0604151A add #69,r2
    c.r[1] = c.r[8];  // 0604151C mov r8,r1
    c.r[1] += 70;  // 0604151E add #70,r1
    c.r[3] = 0x0u;  // 06041520 mov #0,r3
    st8(c.r[1], c.r[3]);  // 06041522 mov.b r3,@r1
    st8(c.r[2], c.r[3]);  // 06041524 mov.b r3,@r2
    c.r[1] = c.r[8];  // 06041526 mov r8,r1
    c.r[1] += 16;  // 06041528 add #16,r1
    c.r[2] = 0x0u;  // 0604152A mov #0,r2
    st16(c.r[1], c.r[2]);  // 0604152C mov.w r2,@r1
    c.r[1] = c.r[8];  // 0604152E mov r8,r1
    c.r[1] += 18;  // 06041530 add #18,r1
    st16(c.r[1], c.r[2]);  // 06041532 mov.w r2,@r1
    c.r[1] = c.r[8];  // 06041534 mov r8,r1
    c.r[1] += 67;  // 06041536 add #67,r1
    st8(c.r[1], c.r[3]);  // 06041538 mov.b r3,@r1
    c.r[1] = c.r[8];  // 0604153A mov r8,r1
    c.r[1] += 68;  // 0604153C add #68,r1
    st8(c.r[1], c.r[3]);  // 0604153E mov.b r3,@r1
    c.r[1] = c.r[8];  // 06041540 mov r8,r1
    c.r[1] += 60;  // 06041542 add #60,r1
    st8(c.r[1], c.r[3]);  // 06041544 mov.b r3,@r1
    c.r[8] += 66;  // 06041546 add #66,r8
    st8(c.r[8], c.r[3]);  // 06041548 mov.b r3,@r8
    c.r[15] = c.r[14];  // 0604154A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604154C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604154E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06041550 rts ; mov.l @r15+,r8
}

void f_06041588(SH2Context& c) {
    ran[1038] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604158A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604158C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604158E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06041590 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06041592 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041594 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041596 sts.l pr,@-r15
    c.r[15] -= 76;  // 06041598 add #-76,r15
    c.r[14] = c.r[15];  // 0604159A mov r15,r14
    c.r[8] = c.r[4];  // 0604159C mov r4,r8
    c.r[5] = ld32(0x060416CCu);  // 0604159E mov.l 0x060416CC,r5
    c.r[1] = ld32(0x060416D0u);  // 060415A0 mov.l 0x060416D0,r1
    c.r[6] = 0x18u;  // 060415A2 mov #24,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060415A8u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060415A8u) return; }  // 060415A4 jsr @r1 ; mov r14,r4
    c.r[1] = c.r[8];  // 060415A8 mov r8,r1
    c.r[1] += 62;  // 060415AA add #62,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060415AC mov.b @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060416C4u);  // 060415AE mov.w 0x060416C4,r1
    c.r[1] &= c.r[2];  // 060415B0 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060415B2 tst r1,r1
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_060415D2; } }  // 060415B4 bt/s 0x060415D2 ; mov #0,r13
    c.r[1] = ld32(0x060416D4u);  // 060415B8 mov.l 0x060416D4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060415BA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060415BC extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060415BE cmp/eq #1,r0
    { const bool k = !c.t; c.r[12] = 0x3u; if (k) { goto L_060415C6; } }  // 060415C0 bf/s 0x060415C6 ; mov #3,r12
    c.r[12] = 0x6u;  // 060415C4 mov #6,r12
L_060415C6:
    c.r[13] = 0x60u;  // 060415C6 mov #96,r13
    c.r[13] &= c.r[2];  // 060415C8 and r2,r13
    c.r[13] >>= 2;  // 060415CA shlr2 r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 060415CC shlr r13
    c.r[13] >>= 2; goto L_060415DA;  // 060415CE bra 0x060415DA ; shlr2 r13
L_060415D2:
    c.r[0] = c.r[2] & 0xFFu;  // 060415D2 extu.b r2,r0
    c.r[1] = ld32(0x060416D8u);  // 060415D4 mov.l 0x060416D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060415D6 mov.b @(r0,r1),r1
    c.r[12] = c.r[1] & 0xFFu;  // 060415D8 extu.b r1,r12
L_060415DA:
    c.r[1] = c.r[8];  // 060415DA mov r8,r1
    c.r[1] += 1;  // 060415DC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060415DE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060415E0 extu.b r1,r1
    c.r[0] = c.r[1];  // 060415E2 mov r1,r0
    c.r[0] >>= 2;  // 060415E4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060415E6 shlr r0
    c.r[0] >>= 2;  // 060415E8 shlr2 r0
    c.r[0] &= 0x1u;  // 060415EA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060415EC tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_060415F6; } }  // 060415EE bt/s 0x060415F6 ; mov r8,r2
    goto L_06041920;  // 060415F2 bra 0x06041920 ; nop
L_060415F6:
    c.r[0] = c.r[1];  // 060415F6 mov r1,r0
    c.r[0] >>= 2;  // 060415F8 shlr2 r0
    c.r[0] >>= 2;  // 060415FA shlr2 r0
    c.r[9] = ld32(c.r[8] + 4);  // 060415FC mov.l @(4,r8),r9
    c.r[0] &= 0x1u;  // 060415FE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041600 tst r0,r0
    { const bool k = c.t; c.r[10] = ld32(c.r[8] + 8); if (k) { goto L_06041636; } }  // 06041602 bt/s 0x06041636 ; mov.l @(8,r8),r10
    c.r[1] = ld32(0x060416DCu);  // 06041606 mov.l 0x060416DC,r1
    c.r[7] = 0x4Cu;  // 06041608 mov #76,r7
    c.r[3] = ld32(c.r[1]);  // 0604160A mov.l @r1,r3
    c.r[2] += 65;  // 0604160C add #65,r2
L_0604160E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604160E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06041610 extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 06041612 mul.l r7,r1
    c.r[2] = c.macl;  // 06041614 sts macl,r2
    c.r[2] += c.r[3];  // 06041616 add r3,r2
    c.r[1] = ld32(c.r[2] + 4);  // 06041618 mov.l @(4,r2),r1
    c.r[9] += c.r[1];  // 0604161A add r1,r9
    c.r[1] = ld32(c.r[2] + 8);  // 0604161C mov.l @(8,r2),r1
    c.r[10] += c.r[1];  // 0604161E add r1,r10
    c.r[1] = c.r[2];  // 06041620 mov r2,r1
    c.r[1] += 1;  // 06041622 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041624 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06041626 mov r1,r0
    c.r[0] >>= 2;  // 06041628 shlr2 r0
    c.r[0] >>= 2;  // 0604162A shlr2 r0
    c.r[0] &= 0x1u;  // 0604162C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604162E tst r0,r0
    { const bool k = !c.t; c.r[2] += 65; if (k) { SH2_POLL(c); goto L_0604160E; } }  // 06041630 bf/s 0x0604160E ; add #65,r2
    c.r[2] -= 65;  // 06041634 add #-65,r2
L_06041636:
    c.r[1] = c.r[8];  // 06041636 mov r8,r1
    c.r[1] += 1;  // 06041638 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604163A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604163C mov r1,r0
    c.r[0] >>= 2;  // 0604163E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06041640 shlr r0
    c.r[0] &= 0x1u;  // 06041642 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041644 tst r0,r0
    { const bool k = c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { goto L_06041668; } }  // 06041646 bt/s 0x06041668 ; cmp/pz r9
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06041650; } }  // 0604164A bt/s 0x06041650 ; mov r9,r1
    c.r[1] += 7;  // 0604164E add #7,r1
L_06041650:
    c.r[9] = c.r[1];  // 06041650 mov r1,r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06041652 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06041654 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06041656 shar r9
    c.t = (int32_t)c.r[10] >= 0;  // 06041658 cmp/pz r10
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06041660; } }  // 0604165A bt/s 0x06041660 ; mov r10,r1
    c.r[1] += 7;  // 0604165E add #7,r1
L_06041660:
    c.r[10] = c.r[1];  // 06041660 mov r1,r10
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 06041662 shar r10
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 06041664 shar r10
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 06041666 shar r10
L_06041668:
    c.r[1] = ld32(0x060416E0u);  // 06041668 mov.l 0x060416E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604166A mov.b @r1,r1
    c.r[9] += c.r[1];  // 0604166C add r1,r9
    c.r[1] = ld32(0x060416E4u);  // 0604166E mov.l 0x060416E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041670 mov.b @r1,r1
    c.r[10] += c.r[1];  // 06041672 add r1,r10
    c.r[1] = c.r[8];  // 06041674 mov r8,r1
    c.r[1] += 56;  // 06041676 add #56,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06041678 mov.w @r1,r2
    c.r[1] = c.r[2];  // 0604167A mov r2,r1
    c.r[1] >>= 8;  // 0604167C shlr8 r1
    c.r[7] = c.r[1] & 0xFFu;  // 0604167E extu.b r1,r7
    c.r[1] = c.r[8];  // 06041680 mov r8,r1
    c.r[1] += 57;  // 06041682 add #57,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041684 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06041686 extu.b r1,r3
    c.r[1] = ld32(0x060416E8u);  // 06041688 mov.l 0x060416E8,r1
    c.r[1] &= c.r[2];  // 0604168A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604168C tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060416F0; } }  // 0604168E bt/s 0x060416F0 ; mov r8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x060416C6u);  // 06041692 mov.w 0x060416C6,r1
    c.r[11] = c.r[1];  // 06041694 mov r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x060416C8u);  // 06041696 mov.w 0x060416C8,r1
    c.r[1] &= c.r[2];  // 06041698 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604169A tst r1,r1
    { const bool k = c.t; c.r[11] &= c.r[2]; if (k) { goto L_060416AA; } }  // 0604169C bt/s 0x060416AA ; and r2,r11
    c.r[1] = c.r[8];  // 060416A0 mov r8,r1
    c.r[1] += 72;  // 060416A2 add #72,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060416A4 mov.w @r1,r1
    c.r[5] = c.r[1] & 0xFFFFu; goto L_0604170A;  // 060416A6 bra 0x0604170A ; extu.w r1,r5
L_060416AA:
    c.r[1] = ld32(0x060416ECu);  // 060416AA mov.l 0x060416EC,r1
    c.r[2] = c.r[11];  // 060416AC mov r11,r2
    c.r[2] <<= 2;  // 060416AE shll2 r2
    c.r[2] += c.r[11];  // 060416B0 add r11,r2
    c.r[1] = ld32(c.r[1] + 8);  // 060416B2 mov.l @(8,r1),r1
    c.r[2] += c.r[2];  // 060416B4 add r2,r2
    c.r[2] += c.r[1];  // 060416B6 add r1,r2
    c.r[2] += 4;  // 060416B8 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060416BA mov.w @r2,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 060416BC extu.w r1,r5
    c.r[5] >>= 2;  // 060416BE shlr2 r5
    c.r[5] >>= 2; goto L_0604170A;  // 060416C0 bra 0x0604170A ; shlr2 r5
L_060416F0:
    c.r[1] += 72;  // 060416F0 add #72,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06041830u);  // 060416F2 mov.w 0x06041830,r2
    c.r[0] = 0x1Fu;  // 060416F4 mov #31,r0
    c.r[7] &= c.r[0];  // 060416F6 and r0,r7
    c.r[7] += c.r[7];  // 060416F8 add r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060416FA mov.w @r1,r1
    c.r[0] = c.r[7];  // 060416FC mov r7,r0
    c.r[1] += c.r[2];  // 060416FE add r2,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 06041700 extu.w r1,r5
    c.r[1] = ld32(0x06041834u);  // 06041702 mov.l 0x06041834,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06041704 mov.w @(r0,r1),r1
    c.r[3] += c.r[1];  // 06041706 add r1,r3
    c.r[11] = c.r[3] & 0xFFFFu;  // 06041708 extu.w r3,r11
L_0604170A:
    c.r[1] = ld32(0x06041838u);  // 0604170A mov.l 0x06041838,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604170C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604170E extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06041710 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] = c.r[5]; if (k) { goto L_0604172C; } }  // 06041712 bf/s 0x0604172C ; mov r5,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06041832u);  // 06041716 mov.w 0x06041832,r2
    c.r[2] &= c.r[5];  // 06041718 and r5,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604171A shlr r2
    c.r[1] = ld32(0x0604183Cu);  // 0604171C mov.l 0x0604183C,r1
    c.r[2] += c.r[1];  // 0604171E add r1,r2
    c.r[5] >>= 8;  // 06041720 shlr8 r5
    c.r[1] = c.r[5] & 0xFFFFu;  // 06041722 extu.w r5,r1
    c.r[1] += c.r[1];  // 06041724 add r1,r1
    c.r[0] = c.r[1];  // 06041726 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06041728 mov.w @(r0,r2),r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0604172A extu.w r1,r6
L_0604172C:
    c.r[5] = c.r[6];  // 0604172C mov r6,r5
    c.r[7] = c.r[14];  // 0604172E mov r14,r7
    c.r[1] = ld32(0x06041840u);  // 06041730 mov.l 0x06041840,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06041732 mov.l @(16,r1),r2
    c.r[7] += 24;  // 06041734 add #24,r7
    c.r[1] = c.r[11];  // 06041736 mov r11,r1
    c.r[1] <<= 2;  // 06041738 shll2 r1
    c.r[3] = c.r[1];  // 0604173A mov r1,r3
    c.r[3] += c.r[2];  // 0604173C add r2,r3
    c.r[0] = c.r[1];  // 0604173E mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06041740 mov.w @(r0,r2),r6
    c.r[3] += 2;  // 06041742 add #2,r3
    st16(c.r[7], c.r[6]);  // 06041744 mov.w r6,@r7
    c.r[2] = c.r[14];  // 06041746 mov r14,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06041748 mov.w @r3,r1
    c.r[2] += 26;  // 0604174A add #26,r2
    st16(c.r[2], c.r[1]);  // 0604174C mov.w r1,@r2
    c.r[1] = ld32(0x06041844u);  // 0604174E mov.l 0x06041844,r1
    c.r[2] = c.r[11];  // 06041750 mov r11,r2
    c.r[1] = ld32(c.r[1]);  // 06041752 mov.l @r1,r1
    c.r[2] <<= 2;  // 06041754 shll2 r2
    c.r[2] += c.r[2];  // 06041756 add r2,r2
    c.r[7] = c.r[1];  // 06041758 mov r1,r7
    c.r[7] += c.r[2];  // 0604175A add r2,r7
    c.r[0] = c.r[1];  // 0604175C mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0604175E mov.w @(r0,r2),r2
    c.r[1] = c.r[8];  // 06041760 mov r8,r1
    c.r[1] += 64;  // 06041762 add #64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041764 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06041766 extu.w r2,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06041768 extu.b r1,r3
    c.r[1] = c.r[14];  // 0604176A mov r14,r1
    c.r[1] -= 5;  // 0604176C add #-5,r1
    c.r[0] = c.r[1];  // 0604176E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06041770 mov.b @(r0,r3),r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06041772 shlr r2
    c.macl = c.r[2] * c.r[1];  // 06041774 mul.l r1,r2
    c.r[0] = 0x1u;  // 06041776 mov #1,r0
    c.r[1] = c.macl;  // 06041778 sts macl,r1
    c.r[1] -= c.r[6];  // 0604177A sub r6,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0604177C exts.w r1,r2
    c.r[1] = c.r[8];  // 0604177E mov r8,r1
    c.r[1] += 2;  // 06041780 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041782 mov.b @r1,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06041784 shlr r1
    c.r[1] &= c.r[0];  // 06041786 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06041788 tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[2]; if (k) { goto L_06041792; } }  // 0604178A bt/s 0x06041792 ; mov r2,r3
    c.r[9] -= c.r[2]; goto L_06041794;  // 0604178E bra 0x06041794 ; sub r2,r9
L_06041792:
    c.r[9] += c.r[3];  // 06041792 add r3,r9
L_06041794:
    c.r[7] += 2;  // 06041794 add #2,r7
    c.r[1] = c.r[8];  // 06041796 mov r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06041798 mov.w @r7,r2
    c.r[1] += 64;  // 0604179A add #64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604179C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604179E extu.w r2,r2
    c.r[0] = c.r[1] & 0xFFu;  // 060417A0 extu.b r1,r0
    c.r[1] = c.r[14];  // 060417A2 mov r14,r1
    c.r[1] += 7;  // 060417A4 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060417A6 mov.b @(r0,r1),r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060417A8 shlr r2
    c.macl = c.r[2] * c.r[1];  // 060417AA mul.l r1,r2
    c.r[1] = c.r[14];  // 060417AC mov r14,r1
    c.r[1] += 26;  // 060417AE add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060417B0 mov.w @r1,r1
    c.r[2] = c.macl;  // 060417B2 sts macl,r2
    c.r[2] -= c.r[1];  // 060417B4 sub r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060417B6 exts.w r2,r2
    c.r[1] = c.r[8];  // 060417B8 mov r8,r1
    c.r[1] += 2;  // 060417BA add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060417BC mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060417BE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060417C0 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[2]; if (k) { goto L_060417CA; } }  // 060417C2 bt/s 0x060417CA ; mov r2,r3
    c.r[10] -= c.r[2]; goto L_060417CC;  // 060417C6 bra 0x060417CC ; sub r2,r10
L_060417CA:
    c.r[10] += c.r[3];  // 060417CA add r3,r10
L_060417CC:
    c.r[1] = c.r[8];  // 060417CC mov r8,r1
    c.r[1] += 2;  // 060417CE add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060417D0 mov.b @r1,r2
    c.r[0] = c.r[2];  // 060417D2 mov r2,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060417D4 shlr r0
    c.r[0] &= 0x1u;  // 060417D6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060417D8 tst r0,r0
    c.r[1] = ld32(0x06041848u);  // 060417DA mov.l 0x06041848,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_060417E2; } }  // 060417DC bt/s 0x060417E2 ; mov r2,r0
    c.r[1] = ld32(0x0604184Cu);  // 060417E0 mov.l 0x0604184C,r1
L_060417E2:
    c.r[0] &= 0x1u;  // 060417E2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060417E4 tst r0,r0
    { const bool k = c.t; c.r[2] = 0x12u; if (k) { goto L_060417F0; } }  // 060417E6 bt/s 0x060417F0 ; mov #18,r2
    c.r[2] &= c.r[1];  // 060417EA and r1,r2
    c.r[0] = 0x22u; goto L_060417F4;  // 060417EC bra 0x060417F4 ; mov #34,r0
L_060417F0:
    c.r[2] &= c.r[1];  // 060417F0 and r1,r2
    c.r[0] = 0x2u;  // 060417F2 mov #2,r0
L_060417F4:
    c.r[2] |= c.r[0];  // 060417F4 or r0,r2
    c.r[4] = c.r[14];  // 060417F6 mov r14,r4
    c.r[4] += 28;  // 060417F8 add #28,r4
    c.r[1] = c.r[8];  // 060417FA mov r8,r1
    c.r[1] += 64;  // 060417FC add #64,r1
    c.r[7] = c.r[12];  // 060417FE mov r12,r7
    c.r[6] = c.r[5];  // 06041800 mov r5,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041802 mov.b @r1,r1
    c.r[5] = c.r[11];  // 06041804 mov r11,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06041806 extu.b r1,r1
    c.r[1] <<= 8;  // 06041808 shll8 r1
    c.r[1] |= c.r[2];  // 0604180A or r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604180C mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041830u);  // 0604180E mov.w 0x06041830,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06041810 mov.l r1,@-r15
    c.r[1] = ld32(0x06041850u);  // 06041812 mov.l 0x06041850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041818u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041818u) return; }  // 06041814 jsr @r1 ; mov.l r13,@-r15
    c.r[1] = ld32(0x06041838u);  // 06041818 mov.l 0x06041838,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604181A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604181C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0604181E cmp/eq #1,r0
    { const bool k = !c.t; c.r[15] += 12; if (k) { goto L_06041858; } }  // 06041820 bf/s 0x06041858 ; add #12,r15
    c.r[1] = c.r[8];  // 06041824 mov r8,r1
    c.r[1] += 63;  // 06041826 add #63,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041828 mov.b @r1,r0
    c.r[1] = ld32(0x06041854u);  // 0604182A mov.l 0x06041854,r1
    c.r[0] <<= 2; goto L_06041862;  // 0604182C bra 0x06041862 ; shll2 r0
L_06041858:
    c.r[1] = c.r[8];  // 06041858 mov r8,r1
    c.r[1] += 63;  // 0604185A add #63,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604185C mov.b @r1,r0
    c.r[0] <<= 2;  // 0604185E shll2 r0
    c.r[1] = ld32(0x06041938u);  // 06041860 mov.l 0x06041938,r1
L_06041862:
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06041862 mov.l @(r0,r1),r2
    c.r[3] = ld32(c.r[8]);  // 06041864 mov.l @r8,r3
    c.r[0] = 0x3u;  // 06041866 mov #3,r0
    c.r[3] >>= 8;  // 06041868 shlr8 r3
    c.r[3] += c.r[3];  // 0604186A add r3,r3
    c.r[3] >>= 8;  // 0604186C shlr8 r3
    c.r[3] &= c.r[0];  // 0604186E and r0,r3
    c.r[0] = c.r[3];  // 06041870 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 06041872 cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = c.r[14]; if (k) { goto L_060418DE; } }  // 06041874 bt/s 0x060418DE ; mov r14,r4
    c.r[1] = 0x1u;  // 06041878 mov #1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0604187A cmp/gt r1,r3
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0604188A; } }  // 0604187C bt/s 0x0604188A ; cmp/eq #2,r0
    c.t = (c.r[3] & c.r[3]) == 0;  // 06041880 tst r3,r3
    { const bool k = c.t; c.r[4] += 60; if (k) { goto L_06041892; } }  // 06041882 bt/s 0x06041892 ; add #60,r4
    c.r[4] = c.r[14]; goto L_060418DE;  // 06041886 bra 0x060418DE ; mov r14,r4
L_0604188A:
    { const bool k = c.t; c.r[4] = c.r[14]; if (k) { goto L_060418B6; } }  // 0604188A bt/s 0x060418B6 ; mov r14,r4
    c.r[4] += 40; goto L_060418E0;  // 0604188E bra 0x060418E0 ; add #40,r4
L_06041892:
    c.r[9] <<= 16;  // 06041892 shll16 r9
    c.r[1] = ld32(0x0604193Cu);  // 06041894 mov.l 0x0604193C,r1
    c.r[9] += c.r[1];  // 06041896 add r1,r9
    st32(c.r[14] + 60, c.r[9]);  // 06041898 mov.l r9,@(60,r14)
    c.r[10] <<= 16;  // 0604189A shll16 r10
    c.r[1] = ld32(0x06041940u);  // 0604189C mov.l 0x06041940,r1
    c.r[10] += c.r[1];  // 0604189E add r1,r10
    st32(c.r[4] + 4, c.r[10]);  // 060418A0 mov.l r10,@(4,r4)
    c.r[1] = ld32(0x06041944u);  // 060418A2 mov.l 0x06041944,r1
    c.r[2] += c.r[1];  // 060418A4 add r1,r2
    st32(c.r[4] + 8, c.r[2]);  // 060418A6 mov.l r2,@(8,r4)
    c.r[1] = ld32(0x06041948u);  // 060418A8 mov.l 0x06041948,r1
    st32(c.r[4] + 12, c.r[1]);  // 060418AA mov.l r1,@(12,r4)
    c.r[5] = c.r[14];  // 060418AC mov r14,r5
    c.r[5] += 28;  // 060418AE add #28,r5
    c.r[0] = ld32(0x0604194Cu);  // 060418B0 mov.l 0x0604194C,r0
    c.r[6] = 0x0u; goto L_0604191C;  // 060418B2 bra 0x0604191C ; mov #0,r6
L_060418B6:
    c.r[4] += 60;  // 060418B6 add #60,r4
    c.r[9] <<= 16;  // 060418B8 shll16 r9
    c.r[1] = ld32(0x0604193Cu);  // 060418BA mov.l 0x0604193C,r1
    c.r[9] += c.r[1];  // 060418BC add r1,r9
    st32(c.r[14] + 60, c.r[9]);  // 060418BE mov.l r9,@(60,r14)
    c.r[10] <<= 16;  // 060418C0 shll16 r10
    c.r[1] = ld32(0x06041940u);  // 060418C2 mov.l 0x06041940,r1
    c.r[10] += c.r[1];  // 060418C4 add r1,r10
    st32(c.r[4] + 4, c.r[10]);  // 060418C6 mov.l r10,@(4,r4)
    c.r[1] = ld32(0x06041944u);  // 060418C8 mov.l 0x06041944,r1
    c.r[2] += c.r[1];  // 060418CA add r1,r2
    st32(c.r[4] + 8, c.r[2]);  // 060418CC mov.l r2,@(8,r4)
    c.r[1] = ld32(0x06041948u);  // 060418CE mov.l 0x06041948,r1
    st32(c.r[4] + 12, c.r[1]);  // 060418D0 mov.l r1,@(12,r4)
    c.r[8] += 52;  // 060418D2 add #52,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060418D4 mov.w @r8,r6
    c.r[5] = c.r[14];  // 060418D6 mov r14,r5
    c.r[0] = ld32(0x06041950u);  // 060418D8 mov.l 0x06041950,r0
    c.r[5] += 28; goto L_0604191C;  // 060418DA bra 0x0604191C ; add #28,r5
L_060418DE:
    c.r[4] += 40;  // 060418DE add #40,r4
L_060418E0:
    c.r[9] <<= 16;  // 060418E0 shll16 r9
    c.r[1] = ld32(0x0604193Cu);  // 060418E2 mov.l 0x0604193C,r1
    c.r[9] += c.r[1];  // 060418E4 add r1,r9
    st32(c.r[14] + 40, c.r[9]);  // 060418E6 mov.l r9,@(40,r14)
    c.r[10] <<= 16;  // 060418E8 shll16 r10
    c.r[1] = ld32(0x06041940u);  // 060418EA mov.l 0x06041940,r1
    c.r[10] += c.r[1];  // 060418EC add r1,r10
    st32(c.r[4] + 4, c.r[10]);  // 060418EE mov.l r10,@(4,r4)
    c.r[1] = ld32(0x06041944u);  // 060418F0 mov.l 0x06041944,r1
    c.r[2] += c.r[1];  // 060418F2 add r1,r2
    st32(c.r[4] + 8, c.r[2]);  // 060418F4 mov.l r2,@(8,r4)
    c.r[1] = ld32(c.r[8] + 44);  // 060418F6 mov.l @(44,r8),r1
    c.r[2] = ld32(0x06041948u);  // 060418F8 mov.l 0x06041948,r2
    c.r[0] = c.r[1];  // 060418FA mov r1,r0
    c.t = c.r[0] == 0x64u;  // 060418FC cmp/eq #100,r0
    if (c.t) { goto L_06041902; }  // 060418FE bt 0x06041902
    c.r[2] = c.r[1];  // 06041900 mov r1,r2
L_06041902:
    st32(c.r[4] + 12, c.r[2]);  // 06041902 mov.l r2,@(12,r4)
    c.r[1] = ld32(c.r[8] + 48);  // 06041904 mov.l @(48,r8),r1
    c.r[2] = ld32(0x06041948u);  // 06041906 mov.l 0x06041948,r2
    c.r[0] = c.r[1];  // 06041908 mov r1,r0
    c.t = c.r[0] == 0x64u;  // 0604190A cmp/eq #100,r0
    if (c.t) { goto L_06041910; }  // 0604190C bt 0x06041910
    c.r[2] = c.r[1];  // 0604190E mov r1,r2
L_06041910:
    st32(c.r[4] + 16, c.r[2]);  // 06041910 mov.l r2,@(16,r4)
    c.r[8] += 52;  // 06041912 add #52,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041914 mov.w @r8,r6
    c.r[5] = c.r[14];  // 06041916 mov r14,r5
    c.r[5] += 28;  // 06041918 add #28,r5
    c.r[0] = ld32(0x06041954u);  // 0604191A mov.l 0x06041954,r0
L_0604191C:
    { const uint32_t x = c.r[0]; c.pr = 0x06041920u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041920u) return; }  // 0604191C jsr @r0 ; nop
L_06041920:
    c.r[14] += 76;  // 06041920 add #76,r14
    c.r[15] = c.r[14];  // 06041922 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041924 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041926 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06041928 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604192A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604192C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604192E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041930 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06041932 rts ; mov.l @r15+,r8
}

void f_06041984(SH2Context& c) {
    ran[1039] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041984 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041986 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041988 sts.l pr,@-r15
    c.r[15] -= 64;  // 0604198A add #-64,r15
    c.r[14] = c.r[15];  // 0604198C mov r15,r14
    c.r[8] = c.r[5] & 0xFFFFu;  // 0604198E extu.w r5,r8
    c.r[1] = c.r[4];  // 06041990 mov r4,r1
    c.r[1] += 1;  // 06041992 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041994 mov.b @r1,r1
    c.r[2] = 0x1u;  // 06041996 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06041998 extu.b r1,r1
    c.r[0] = c.r[1];  // 0604199A mov r1,r0
    c.r[0] >>= 2;  // 0604199C shlr2 r0
    c.r[0] >>= 2;  // 0604199E shlr2 r0
    c.r[2] &= c.r[0];  // 060419A0 and r0,r2
    c.r[0] = c.r[1];  // 060419A2 mov r1,r0
    c.r[0] >>= 2;  // 060419A4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060419A6 shlr r0
    c.r[1] = 0x14u;  // 060419A8 mov #20,r1
    c.t = c.r[8] > c.r[1];  // 060419AA cmp/hi r1,r8
    { const bool k = c.t; c.r[0] &= 0x1u; if (k) { goto L_06041A02; } }  // 060419AC bt/s 0x06041A02 ; and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060419B0 tst r0,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[4] + 4); if (k) { goto L_060419BC; } }  // 060419B2 bt/s 0x060419BC ; mov.l @(4,r4),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060419B6 shar r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060419B8 shar r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060419BA shar r7
L_060419BC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060419BC mov.b @r4,r1
    c.r[6] = c.r[1] & 0xFFu;  // 060419BE extu.b r1,r6
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060419C0 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060419C2 mov.l r2,@-r15
    c.r[1] = c.r[4];  // 060419C4 mov r4,r1
    c.r[1] += 65;  // 060419C6 add #65,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060419C8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060419CA extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060419CC mov.l r1,@-r15
    c.r[1] = c.r[4];  // 060419CE mov r4,r1
    c.r[1] += 1;  // 060419D0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060419D2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060419D4 mov r1,r0
    c.r[0] >>= 2;  // 060419D6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060419D8 shlr r0
    c.r[0] &= 0x1u;  // 060419DA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060419DC tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 8); if (k) { goto L_060419E8; } }  // 060419DE bt/s 0x060419E8 ; mov.l @(8,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060419E2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060419E4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060419E6 shar r1
L_060419E8:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060419E8 mov.l r1,@-r15
    c.r[0] = ld32(0x06041A10u);  // 060419EA mov.l 0x06041A10,r0
    c.r[5] = ld32(0x06041A14u);  // 060419EC mov.l 0x06041A14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060419F2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060419F2u) return; }  // 060419EE jsr @r0 ; mov r14,r4
    c.r[0] = ld32(0x06041A18u);  // 060419F2 mov.l 0x06041A18,r0
    c.r[5] = c.r[8];  // 060419F4 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060419FAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060419FAu) return; }  // 060419F6 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x06041A1Cu);  // 060419FA mov.l 0x06041A1C,r1
    c.r[5] = c.r[0];  // 060419FC mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06041A02u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041A02u) return; }  // 060419FE jsr @r1 ; mov r14,r4
L_06041A02:
    c.r[14] += 64;  // 06041A02 add #64,r14
    c.r[15] = c.r[14];  // 06041A04 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041A06 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041A08 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06041A0A rts ; mov.l @r15+,r8
}

void f_06041A20(SH2Context& c) {
    ran[1040] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041A20 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06041A22 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06041A24 extu.b r4,r4
    c.r[1] = ld32(0x06041A68u);  // 06041A26 mov.l 0x06041A68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041A28 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06041A2A extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06041A2C cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_06041A4C; } }  // 06041A2E bf/s 0x06041A4C ; mov r4,r2
    c.t = (c.r[4] & c.r[4]) == 0;  // 06041A32 tst r4,r4
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06041A3C; } }  // 06041A34 bf/s 0x06041A3C ; mov #0,r1
    c.r[2] = ld32(0x06041A6Cu);  // 06041A38 mov.l 0x06041A6C,r2
    st8(c.r[2], c.r[1]);  // 06041A3A mov.b r1,@r2
L_06041A3C:
    c.r[2] = ld32(0x06041A6Cu);  // 06041A3C mov.l 0x06041A6C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06041A3E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06041A40 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06041A42 tst r1,r1
    if (!c.t) { goto L_06041A62; }  // 06041A44 bf 0x06041A62
    st8(c.r[2], c.r[4]);  // 06041A46 mov.b r4,@r2
    c.r[1] = c.r[2]; goto L_06041A50;  // 06041A48 bra 0x06041A50 ; mov r2,r1
L_06041A4C:
    c.r[1] = ld32(0x06041A6Cu);  // 06041A4C mov.l 0x06041A6C,r1
    st8(c.r[1], c.r[2]);  // 06041A4E mov.b r2,@r1
L_06041A50:
    c.r[1] += 1;  // 06041A50 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041A52 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06041A54 or #128,r0
    c.r[0] &= 0xBFu;  // 06041A56 and #191,r0
    st8(c.r[1], c.r[0]);  // 06041A58 mov.b r0,@r1
    c.r[1] = ld32(0x06041A70u);  // 06041A5A mov.l 0x06041A70,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06041A5C mov.w @r1,r0
    c.r[0] |= 0x8u;  // 06041A5E or #8,r0
    st16(c.r[1], c.r[0]);  // 06041A60 mov.w r0,@r1
L_06041A62:
    c.r[15] = c.r[14];  // 06041A62 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06041A64 rts ; mov.l @r15+,r14
}

void f_06041A74(SH2Context& c) {
    ran[1041] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041A74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041A76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041A78 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041A7A sts.l pr,@-r15
    c.r[1] = ld32(0x06041B6Cu);  // 06041A7C mov.l 0x06041B6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041A7E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06041A80 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06041A82 cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06041AB0; } }  // 06041A84 bf/s 0x06041AB0 ; mov r15,r14
    c.r[3] = ld32(0x06041B70u);  // 06041A88 mov.l 0x06041B70,r3
    c.r[1] = c.r[3];  // 06041A8A mov r3,r1
    c.r[1] += 6;  // 06041A8C add #6,r1
    c.r[2] = 0x0u;  // 06041A8E mov #0,r2
    st8(c.r[1], c.r[2]);  // 06041A90 mov.b r2,@r1
    c.r[3] += 7;  // 06041A92 add #7,r3
    st8(c.r[3], c.r[2]);  // 06041A94 mov.b r2,@r3
    c.r[8] = ld32(0x06041B74u);  // 06041A96 mov.l 0x06041B74,r8
    c.r[5] = 0x4u;  // 06041A98 mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06041A9Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041A9Eu) return; }  // 06041A9A jsr @r8 ; mov r0,r4
    c.r[5] = 0x4u;  // 06041A9E mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06041AA4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041AA4u) return; }  // 06041AA0 jsr @r8 ; mov #0,r4
    c.r[1] = ld32(0x06041B78u);  // 06041AA4 mov.l 0x06041B78,r1
    c.r[2] = 0x0u;  // 06041AA6 mov #0,r2
    st16(c.r[1], c.r[2]);  // 06041AA8 mov.w r2,@r1
    c.r[1] = ld32(0x06041B7Cu);  // 06041AAA mov.l 0x06041B7C,r1
    st16(c.r[1], c.r[2]); goto L_06041B04;  // 06041AAC bra 0x06041B04 ; mov.w r2,@r1
L_06041AB0:
    c.r[5] = 0x0u;  // 06041AB0 mov #0,r5
    c.r[8] = 0x2u;  // 06041AB2 mov #2,r8
    c.r[0] = ld32(0x06041B70u);  // 06041AB4 mov.l 0x06041B70,r0
    c.r[4] = 0x0u;  // 06041AB6 mov #0,r4
    c.r[3] = c.r[0];  // 06041AB8 mov r0,r3
    c.r[7] = c.r[3];  // 06041ABA mov r3,r7
    c.r[6] = c.r[7];  // 06041ABC mov r7,r6
L_06041ABE:
    c.r[1] = c.r[5];  // 06041ABE mov r5,r1
    c.r[1] += c.r[0];  // 06041AC0 add r0,r1
    c.r[1] += 44;  // 06041AC2 add #44,r1
    c.r[2] = 0x0u;  // 06041AC4 mov #0,r2
    st8(c.r[1], c.r[2]);  // 06041AC6 mov.b r2,@r1
    c.r[1] = c.r[7];  // 06041AC8 mov r7,r1
    c.r[1] += 47;  // 06041ACA add #47,r1
    st8(c.r[1], c.r[2]);  // 06041ACC mov.b r2,@r1
    c.r[1] = c.r[7];  // 06041ACE mov r7,r1
    c.r[1] += 48;  // 06041AD0 add #48,r1
    st8(c.r[1], c.r[2]);  // 06041AD2 mov.b r2,@r1
    c.r[1] = c.r[6];  // 06041AD4 mov r6,r1
    c.r[1] += 54;  // 06041AD6 add #54,r1
    st16(c.r[1], c.r[4]);  // 06041AD8 mov.w r4,@r1
    c.r[1] = c.r[6];  // 06041ADA mov r6,r1
    c.r[1] += 56;  // 06041ADC add #56,r1
    st16(c.r[1], c.r[4]);  // 06041ADE mov.w r4,@r1
    c.r[1] = c.r[3];  // 06041AE0 mov r3,r1
    c.r[1] += 108;  // 06041AE2 add #108,r1
    st32(c.r[1], c.r[4]);  // 06041AE4 mov.l r4,@r1
    c.r[1] = c.r[3];  // 06041AE6 mov r3,r1
    c.r[1] += 112;  // 06041AE8 add #112,r1
    st32(c.r[1], c.r[4]);  // 06041AEA mov.l r4,@r1
    c.r[1] = c.r[3];  // 06041AEC mov r3,r1
    c.r[1] += 68;  // 06041AEE add #68,r1
    st32(c.r[1], c.r[4]);  // 06041AF0 mov.l r4,@r1
    c.r[1] = c.r[3];  // 06041AF2 mov r3,r1
    c.r[1] += 72;  // 06041AF4 add #72,r1
    st32(c.r[1], c.r[4]);  // 06041AF6 mov.l r4,@r1
    c.r[3] += 8;  // 06041AF8 add #8,r3
    c.r[6] += 4;  // 06041AFA add #4,r6
    c.r[5] += 1;  // 06041AFC add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[8];  // 06041AFE cmp/gt r8,r5
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06041ABE; } }  // 06041B00 bf/s 0x06041ABE ; add #2,r7
L_06041B04:
    c.r[9] = ld32(0x06041B70u);  // 06041B04 mov.l 0x06041B70,r9
    c.r[2] = 0x0u;  // 06041B06 mov #0,r2
    st8(c.r[9], c.r[2]);  // 06041B08 mov.b r2,@r9
    c.r[1] = c.r[9];  // 06041B0A mov r9,r1
    c.r[1] += 1;  // 06041B0C add #1,r1
    c.r[8] = 0x0u;  // 06041B0E mov #0,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041B10 mov.b @r1,r0
    c.r[4] = 0x0u;  // 06041B12 mov #0,r4
    c.r[0] &= 0xF9u;  // 06041B14 and #249,r0
    st8(c.r[1], c.r[0]);  // 06041B16 mov.b r0,@r1
    c.r[1] = c.r[9];  // 06041B18 mov r9,r1
    c.r[1] += 8;  // 06041B1A add #8,r1
    st8(c.r[1], c.r[2]);  // 06041B1C mov.b r2,@r1
    c.r[1] = c.r[9];  // 06041B1E mov r9,r1
    c.r[1] += 9;  // 06041B20 add #9,r1
    st8(c.r[1], c.r[2]);  // 06041B22 mov.b r2,@r1
    c.r[1] = c.r[9];  // 06041B24 mov r9,r1
    c.r[1] += 2;  // 06041B26 add #2,r1
    st16(c.r[1], c.r[8]);  // 06041B28 mov.w r8,@r1
    c.r[1] = c.r[9];  // 06041B2A mov r9,r1
    c.r[1] += 4;  // 06041B2C add #4,r1
    st16(c.r[1], c.r[8]);  // 06041B2E mov.w r8,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06041B66u);  // 06041B30 mov.w 0x06041B66,r0
    st16(c.r[0] + c.r[9], c.r[8]);  // 06041B32 mov.w r8,@(r0,r9)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06041B68u);  // 06041B34 mov.w 0x06041B68,r0
    c.r[1] = 0x6u;  // 06041B36 mov #6,r1
    st16(c.r[0] + c.r[9], c.r[1]);  // 06041B38 mov.w r1,@(r0,r9)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06041B6Au);  // 06041B3A mov.w 0x06041B6A,r0
    c.r[1] = ld32(0x06041B80u);  // 06041B3C mov.l 0x06041B80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041B42u; st16(c.r[0] + c.r[9], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041B42u) return; }  // 06041B3E jsr @r1 ; mov.w r8,@(r0,r9)
    c.r[1] = c.r[9];  // 06041B42 mov r9,r1
    c.r[1] += 20;  // 06041B44 add #20,r1
    st16(c.r[1], c.r[8]);  // 06041B46 mov.w r8,@r1
    c.r[1] = c.r[9];  // 06041B48 mov r9,r1
    c.r[1] += 14;  // 06041B4A add #14,r1
    st16(c.r[1], c.r[8]);  // 06041B4C mov.w r8,@r1
    c.r[1] = c.r[9];  // 06041B4E mov r9,r1
    c.r[1] += 16;  // 06041B50 add #16,r1
    st16(c.r[1], c.r[8]);  // 06041B52 mov.w r8,@r1
    c.r[9] += 18;  // 06041B54 add #18,r9
    st16(c.r[9], c.r[8]);  // 06041B56 mov.w r8,@r9
    c.r[15] = c.r[14];  // 06041B58 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041B5A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041B5C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041B5E mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041B60 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06041B62 rts ; mov #0,r0
}

void f_06041B84(SH2Context& c) {
    ran[1042] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041B84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041B86 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06041B88 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041B8A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041B8C sts.l pr,@-r15
    c.r[9] = ld32(0x06041C10u);  // 06041B8E mov.l 0x06041C10,r9
    c.r[3] = c.r[9];  // 06041B90 mov r9,r3
    c.r[3] += 1;  // 06041B92 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06041B94 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06041B96 extu.b r2,r1
    c.r[0] = c.r[1];  // 06041B98 mov r1,r0
    c.r[0] >>= 2;  // 06041B9A shlr2 r0
    c.r[0] >>= 2;  // 06041B9C shlr2 r0
    c.r[0] >>= 2;  // 06041B9E shlr2 r0
    c.r[0] &= 0x1u;  // 06041BA0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041BA2 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041BBC; } }  // 06041BA4 bt/s 0x06041BBC ; mov r15,r14
    c.r[1] = c.r[9];  // 06041BA8 mov r9,r1
    c.r[1] += 12;  // 06041BAA add #12,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041BAC mov.b @r1,r5
    c.r[4] = 0x3u;  // 06041BAE mov #3,r4
    c.r[1] = ld32(0x06041C14u);  // 06041BB0 mov.l 0x06041C14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041BB6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041BB6u) return; }  // 06041BB2 jsr @r1 ; extu.b r5,r5
    c.r[9] += 2;  // 06041BB6 add #2,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); goto L_06041BF6;  // 06041BB8 bra 0x06041BF6 ; mov.w @r9,r4
L_06041BBC:
    c.r[1] >>= 2;  // 06041BBC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06041BBE shlr r1
    c.r[7] = 0x1u;  // 06041BC0 mov #1,r7
    c.r[1] &= c.r[7];  // 06041BC2 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06041BC4 tst r1,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06041C0Cu);  // 06041BC6 mov.w 0x06041C0C,r10
    if (c.t) { goto L_06041BCC; }  // 06041BC8 bt 0x06041BCC
    c.r[10] = 0x0u;  // 06041BCA mov #0,r10
L_06041BCC:
    c.r[0] = c.r[2];  // 06041BCC mov r2,r0
    c.r[0] |= 0x40u;  // 06041BCE or #64,r0
    st8(c.r[3], c.r[0]);  // 06041BD0 mov.b r0,@r3
    c.r[1] = c.r[9];  // 06041BD2 mov r9,r1
    c.r[1] += 12;  // 06041BD4 add #12,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041BD6 mov.b @r1,r5
    c.r[4] = 0x3u;  // 06041BD8 mov #3,r4
    c.r[1] = ld32(0x06041C14u);  // 06041BDA mov.l 0x06041C14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041BE0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041BE0u) return; }  // 06041BDC jsr @r1 ; extu.b r5,r5
    c.r[8] = c.r[9];  // 06041BE0 mov r9,r8
    c.r[8] += 2;  // 06041BE2 add #2,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041BE4 mov.w @r8,r1
    c.r[9] += 4;  // 06041BE6 add #4,r9
    c.r[10] |= c.r[1];  // 06041BE8 or r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041BEA mov.w @r9,r1
    c.r[10] |= c.r[1];  // 06041BEC or r1,r10
    c.r[1] = ld32(0x06041C18u);  // 06041BEE mov.l 0x06041C18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041BF4u; c.r[4] = c.r[10] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041BF4u) return; }  // 06041BF0 jsr @r1 ; extu.w r10,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041BF4 mov.w @r8,r4
L_06041BF6:
    c.r[1] = ld32(0x06041C1Cu);  // 06041BF6 mov.l 0x06041C1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041BFCu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041BFCu) return; }  // 06041BF8 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06041BFC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041BFE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041C00 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06041C02 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041C04 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041C06 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041C08 rts ; mov #1,r0
}

void f_06041C20(SH2Context& c) {
    ran[1043] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041C20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041C22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041C24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041C26 sts.l pr,@-r15
    c.r[9] = ld32(0x06041CB8u);  // 06041C28 mov.l 0x06041CB8,r9
    c.r[2] = c.r[9];  // 06041C2A mov r9,r2
    c.r[2] += 1;  // 06041C2C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06041C2E mov.b @r2,r1
    c.r[0] = c.r[1];  // 06041C30 mov r1,r0
    c.r[0] >>= 2;  // 06041C32 shlr2 r0
    c.r[0] >>= 2;  // 06041C34 shlr2 r0
    c.r[0] >>= 2;  // 06041C36 shlr2 r0
    c.r[0] &= 0x1u;  // 06041C38 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041C3A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041C4E; } }  // 06041C3C bt/s 0x06041C4E ; mov r15,r14
    c.r[9] += 2;  // 06041C40 add #2,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041C42 mov.w @r9,r4
    c.r[1] = ld32(0x06041CBCu);  // 06041C44 mov.l 0x06041CBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041C4Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041C4Au) return; }  // 06041C46 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14]; goto L_06041CAC;  // 06041C4A bra 0x06041CAC ; mov r14,r15
L_06041C4E:
    c.r[0] = c.r[1];  // 06041C4E mov r1,r0
    c.r[0] |= 0x40u;  // 06041C50 or #64,r0
    st8(c.r[2], c.r[0]);  // 06041C52 mov.b r0,@r2
    c.r[1] = ld32(0x06041CC0u);  // 06041C54 mov.l 0x06041CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041C5Au; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041C5Au) return; }  // 06041C56 jsr @r1 ; mov #6,r4
    c.r[1] = ld32(0x06041CC4u);  // 06041C5A mov.l 0x06041CC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041C60u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041C60u) return; }  // 06041C5C jsr @r1 ; mov #1,r4
    c.r[8] = c.r[9];  // 06041C60 mov r9,r8
    c.r[8] += 2;  // 06041C62 add #2,r8
    c.r[1] = c.r[9];  // 06041C64 mov r9,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041C66 mov.w @r8,r4
    c.r[1] += 4;  // 06041C68 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06041C6A mov.w @r1,r1
    c.r[4] |= c.r[1];  // 06041C6C or r1,r4
    c.r[1] = ld32(0x06041CC8u);  // 06041C6E mov.l 0x06041CC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041C74u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041C74u) return; }  // 06041C70 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041C74 mov.w @r8,r4
    c.r[1] = ld32(0x06041CBCu);  // 06041C76 mov.l 0x06041CBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041C7Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041C7Cu) return; }  // 06041C78 jsr @r1 ; extu.w r4,r4
    c.r[1] = c.r[9];  // 06041C7C mov r9,r1
    c.r[1] += 7;  // 06041C7E add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041C80 mov.b @r1,r2
    c.r[3] = ld32(0x06041CCCu);  // 06041C82 mov.l 0x06041CCC,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06041C84 extu.b r2,r2
    c.r[1] = c.r[9];  // 06041C86 mov r9,r1
    c.r[1] += 6;  // 06041C88 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041C8A mov.b @r1,r1
    c.r[2] <<= 8;  // 06041C8C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06041C8E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06041C90 or r1,r2
    st16(c.r[3], c.r[2]);  // 06041C92 mov.w r2,@r3
    c.r[3] = ld32(0x06041CD0u);  // 06041C94 mov.l 0x06041CD0,r3
    c.r[1] = c.r[9];  // 06041C96 mov r9,r1
    c.r[1] += 9;  // 06041C98 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041C9A mov.b @r1,r2
    c.r[9] += 8;  // 06041C9C add #8,r9
    c.r[2] = c.r[2] & 0xFFu;  // 06041C9E extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06041CA0 mov.b @r9,r1
    c.r[2] <<= 8;  // 06041CA2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06041CA4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06041CA6 or r1,r2
    st16(c.r[3], c.r[2]);  // 06041CA8 mov.w r2,@r3
    c.r[15] = c.r[14];  // 06041CAA mov r14,r15
L_06041CAC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041CAC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041CAE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041CB0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041CB2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041CB4 rts ; mov #1,r0
}

void f_06041CD4(SH2Context& c) {
    ran[1044] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041CD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041CD6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041CD8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041CDA sts.l pr,@-r15
    c.r[4] = ld32(0x06041D44u);  // 06041CDC mov.l 0x06041D44,r4
    c.r[3] = c.r[4];  // 06041CDE mov r4,r3
    c.r[3] += 1;  // 06041CE0 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06041CE2 mov.b @r3,r2
    c.r[0] = c.r[2];  // 06041CE4 mov r2,r0
    c.r[0] >>= 2;  // 06041CE6 shlr2 r0
    c.r[0] >>= 2;  // 06041CE8 shlr2 r0
    c.r[0] >>= 2;  // 06041CEA shlr2 r0
    c.r[0] &= 0x1u;  // 06041CEC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041CEE tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041CFA; } }  // 06041CF0 bt/s 0x06041CFA ; mov r15,r14
    c.r[4] += 2;  // 06041CF4 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_06041D2E;  // 06041CF6 bra 0x06041D2E ; mov.w @r4,r4
L_06041CFA:
    c.r[8] = c.r[4];  // 06041CFA mov r4,r8
    c.r[8] += 2;  // 06041CFC add #2,r8
    c.r[1] = 0x44u;  // 06041CFE mov #68,r1
    st16(c.r[8], c.r[1]);  // 06041D00 mov.w r1,@r8
    c.r[9] = c.r[4];  // 06041D02 mov r4,r9
    c.r[9] += 4;  // 06041D04 add #4,r9
    c.r[1] = 0x3u;  // 06041D06 mov #3,r1
    st16(c.r[9], c.r[1]);  // 06041D08 mov.w r1,@r9
    c.r[0] = c.r[2];  // 06041D0A mov r2,r0
    c.r[0] |= 0x40u;  // 06041D0C or #64,r0
    st8(c.r[3], c.r[0]);  // 06041D0E mov.b r0,@r3
    c.r[1] = ld32(0x06041D48u);  // 06041D10 mov.l 0x06041D48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041D16u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041D16u) return; }  // 06041D12 jsr @r1 ; mov #6,r4
    c.r[1] = ld32(0x06041D4Cu);  // 06041D16 mov.l 0x06041D4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041D1Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041D1Cu) return; }  // 06041D18 jsr @r1 ; mov #1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041D1C mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041D42u);  // 06041D1E mov.w 0x06041D42,r1
    c.r[4] |= c.r[1];  // 06041D20 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041D22 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06041D24 or r1,r4
    c.r[1] = ld32(0x06041D50u);  // 06041D26 mov.l 0x06041D50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041D2Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041D2Cu) return; }  // 06041D28 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041D2C mov.w @r8,r4
L_06041D2E:
    c.r[1] = ld32(0x06041D54u);  // 06041D2E mov.l 0x06041D54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041D34u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041D34u) return; }  // 06041D30 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06041D34 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041D36 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041D38 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041D3A mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041D3C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041D3E rts ; mov #1,r0
}

void f_06041D58(SH2Context& c) {
    ran[1045] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041D58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041D5A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06041D5C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041D5E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041D60 sts.l pr,@-r15
    c.r[10] = ld32(0x06041E14u);  // 06041D62 mov.l 0x06041E14,r10
    c.r[7] = c.r[10];  // 06041D64 mov r10,r7
    c.r[7] += 1;  // 06041D66 add #1,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06041D68 mov.b @r7,r3
    c.r[0] = c.r[3];  // 06041D6A mov r3,r0
    c.r[0] >>= 2;  // 06041D6C shlr2 r0
    c.r[0] >>= 2;  // 06041D6E shlr2 r0
    c.r[0] >>= 2;  // 06041D70 shlr2 r0
    c.r[0] &= 0x1u;  // 06041D72 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041D74 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041D96; } }  // 06041D76 bt/s 0x06041D96 ; mov r15,r14
    c.r[1] = c.r[10];  // 06041D7A mov r10,r1
    c.r[1] += 12;  // 06041D7C add #12,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041D7E mov.b @r1,r5
    c.r[4] = 0x3u;  // 06041D80 mov #3,r4
    c.r[1] = ld32(0x06041E18u);  // 06041D82 mov.l 0x06041E18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041D88u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041D88u) return; }  // 06041D84 jsr @r1 ; extu.b r5,r5
    c.r[10] += 2;  // 06041D88 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06041D8A mov.w @r10,r4
    c.r[1] = ld32(0x06041E1Cu);  // 06041D8C mov.l 0x06041E1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041D92u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041D92u) return; }  // 06041D8E jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14]; goto L_06041E02;  // 06041D92 bra 0x06041E02 ; mov r14,r15
L_06041D96:
    c.r[9] = c.r[10];  // 06041D96 mov r10,r9
    c.r[9] += 2;  // 06041D98 add #2,r9
    c.r[8] = c.r[10];  // 06041D9A mov r10,r8
    c.r[8] += 4;  // 06041D9C add #4,r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06041E10u);  // 06041D9E mov.w 0x06041E10,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041DA0 mov.w @r9,r0
    c.r[4] = 0x6u;  // 06041DA2 mov #6,r4
    c.r[0] |= 0x4u;  // 06041DA4 or #4,r0
    st16(c.r[9], c.r[0]);  // 06041DA6 mov.w r0,@r9
    c.r[0] = c.r[3];  // 06041DA8 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041DAA mov.w @r8,r1
    c.r[0] |= 0x40u;  // 06041DAC or #64,r0
    c.r[1] &= c.r[2];  // 06041DAE and r2,r1
    st16(c.r[8], c.r[1]);  // 06041DB0 mov.w r1,@r8
    c.r[1] = ld32(0x06041E20u);  // 06041DB2 mov.l 0x06041E20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041DB8u; st8(c.r[7], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041DB8u) return; }  // 06041DB4 jsr @r1 ; mov.b r0,@r7
    c.r[1] = ld32(0x06041E24u);  // 06041DB8 mov.l 0x06041E24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041DBEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041DBEu) return; }  // 06041DBA jsr @r1 ; mov #1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041DBE mov.w @r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041DC0 mov.w @r8,r1
    c.r[4] |= c.r[1];  // 06041DC2 or r1,r4
    c.r[1] = ld32(0x06041E28u);  // 06041DC4 mov.l 0x06041E28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041DCAu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041DCAu) return; }  // 06041DC6 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041DCA mov.w @r9,r4
    c.r[1] = ld32(0x06041E1Cu);  // 06041DCC mov.l 0x06041E1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041DD2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041DD2u) return; }  // 06041DCE jsr @r1 ; extu.w r4,r4
    c.r[1] = c.r[10];  // 06041DD2 mov r10,r1
    c.r[1] += 7;  // 06041DD4 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041DD6 mov.b @r1,r2
    c.r[3] = ld32(0x06041E2Cu);  // 06041DD8 mov.l 0x06041E2C,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06041DDA extu.b r2,r2
    c.r[1] = c.r[10];  // 06041DDC mov r10,r1
    c.r[1] += 6;  // 06041DDE add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041DE0 mov.b @r1,r1
    c.r[2] <<= 8;  // 06041DE2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06041DE4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06041DE6 or r1,r2
    st16(c.r[3], c.r[2]);  // 06041DE8 mov.w r2,@r3
    c.r[3] = ld32(0x06041E30u);  // 06041DEA mov.l 0x06041E30,r3
    c.r[1] = c.r[10];  // 06041DEC mov r10,r1
    c.r[1] += 9;  // 06041DEE add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06041DF0 mov.b @r1,r2
    c.r[10] += 8;  // 06041DF2 add #8,r10
    c.r[2] = c.r[2] & 0xFFu;  // 06041DF4 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06041DF6 mov.b @r10,r1
    c.r[2] <<= 8;  // 06041DF8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06041DFA extu.b r1,r1
    c.r[2] |= c.r[1];  // 06041DFC or r1,r2
    st16(c.r[3], c.r[2]);  // 06041DFE mov.w r2,@r3
    c.r[15] = c.r[14];  // 06041E00 mov r14,r15
L_06041E02:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041E02 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041E04 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06041E06 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041E08 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041E0A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041E0C rts ; mov #1,r0
}

void f_06041E34(SH2Context& c) {
    ran[1046] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041E34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041E36 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041E38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041E3A sts.l pr,@-r15
    c.r[4] = ld32(0x06041EB0u);  // 06041E3C mov.l 0x06041EB0,r4
    c.r[2] = c.r[4];  // 06041E3E mov r4,r2
    c.r[2] += 1;  // 06041E40 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06041E42 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06041E44 mov r1,r0
    c.r[0] >>= 2;  // 06041E46 shlr2 r0
    c.r[0] >>= 2;  // 06041E48 shlr2 r0
    c.r[0] >>= 2;  // 06041E4A shlr2 r0
    c.r[0] &= 0x1u;  // 06041E4C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041E4E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041E5E; } }  // 06041E50 bt/s 0x06041E5E ; mov r15,r14
    c.r[4] += 2;  // 06041E54 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06041E56 mov.w @r4,r4
    c.r[1] = ld32(0x06041EB4u);  // 06041E58 mov.l 0x06041EB4,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06041E98;  // 06041E5A bra 0x06041E98 ; extu.w r4,r4
L_06041E5E:
    c.r[0] = c.r[1];  // 06041E5E mov r1,r0
    c.r[0] |= 0x40u;  // 06041E60 or #64,r0
    st8(c.r[2], c.r[0]);  // 06041E62 mov.b r0,@r2
    c.r[9] = c.r[4];  // 06041E64 mov r4,r9
    c.r[9] += 2;  // 06041E66 add #2,r9
    c.r[1] = 0x3u;  // 06041E68 mov #3,r1
    st16(c.r[9], c.r[1]);  // 06041E6A mov.w r1,@r9
    c.r[8] = c.r[4];  // 06041E6C mov r4,r8
    c.r[8] += 4;  // 06041E6E add #4,r8
    c.r[1] = 0x20u;  // 06041E70 mov #32,r1
    st16(c.r[8], c.r[1]);  // 06041E72 mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06041EAAu);  // 06041E74 mov.w 0x06041EAA,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06041E76 mov.w @(r0,r4),r5
    c.r[1] = ld32(0x06041EB8u);  // 06041E78 mov.l 0x06041EB8,r1
    c.r[5] <<= 2;  // 06041E7A shll2 r5
    c.r[5] <<= 2;  // 06041E7C shll2 r5
    c.r[4] = ld32(0x06041EBCu);  // 06041E7E mov.l 0x06041EBC,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06041E84u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041E84u) return; }  // 06041E80 jsr @r1 ; extu.w r5,r5
    c.r[1] = ld32(0x06041EC0u);  // 06041E84 mov.l 0x06041EC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041E8Au; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041E8Au) return; }  // 06041E86 jsr @r1 ; mov #3,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041E8A mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041EACu);  // 06041E8C mov.w 0x06041EAC,r1
    c.r[4] |= c.r[1];  // 06041E8E or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041E90 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06041E92 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 06041E94 extu.w r4,r4
    c.r[1] = ld32(0x06041EC4u);  // 06041E96 mov.l 0x06041EC4,r1
L_06041E98:
    { const uint32_t x = c.r[1]; c.pr = 0x06041E9Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041E9Cu) return; }  // 06041E98 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06041E9C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041E9E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041EA0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041EA2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041EA4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041EA6 rts ; mov #1,r0
}

void f_06041EC8(SH2Context& c) {
    ran[1047] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041EC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041ECA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041ECC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041ECE sts.l pr,@-r15
    c.r[4] = ld32(0x06041F44u);  // 06041ED0 mov.l 0x06041F44,r4
    c.r[2] = c.r[4];  // 06041ED2 mov r4,r2
    c.r[2] += 1;  // 06041ED4 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06041ED6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06041ED8 mov r1,r0
    c.r[0] >>= 2;  // 06041EDA shlr2 r0
    c.r[0] >>= 2;  // 06041EDC shlr2 r0
    c.r[0] >>= 2;  // 06041EDE shlr2 r0
    c.r[0] &= 0x1u;  // 06041EE0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041EE2 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041EF2; } }  // 06041EE4 bt/s 0x06041EF2 ; mov r15,r14
    c.r[4] += 2;  // 06041EE8 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06041EEA mov.w @r4,r4
    c.r[1] = ld32(0x06041F48u);  // 06041EEC mov.l 0x06041F48,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06041F2E;  // 06041EEE bra 0x06041F2E ; extu.w r4,r4
L_06041EF2:
    c.r[0] = c.r[1];  // 06041EF2 mov r1,r0
    c.r[0] |= 0x40u;  // 06041EF4 or #64,r0
    st8(c.r[2], c.r[0]);  // 06041EF6 mov.b r0,@r2
    c.r[8] = c.r[4];  // 06041EF8 mov r4,r8
    c.r[8] += 2;  // 06041EFA add #2,r8
    c.r[1] = 0x8u;  // 06041EFC mov #8,r1
    st16(c.r[8], c.r[1]);  // 06041EFE mov.w r1,@r8
    c.r[9] = c.r[4];  // 06041F00 mov r4,r9
    c.r[9] += 4;  // 06041F02 add #4,r9
    c.r[1] = 0x20u;  // 06041F04 mov #32,r1
    st16(c.r[9], c.r[1]);  // 06041F06 mov.w r1,@r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06041F40u);  // 06041F08 mov.w 0x06041F40,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06041F0A mov.w @(r0,r4),r5
    c.r[1] = ld32(0x06041F4Cu);  // 06041F0C mov.l 0x06041F4C,r1
    c.r[5] <<= 2;  // 06041F0E shll2 r5
    c.r[5] <<= 2;  // 06041F10 shll2 r5
    c.r[4] = ld32(0x06041F50u);  // 06041F12 mov.l 0x06041F50,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06041F18u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041F18u) return; }  // 06041F14 jsr @r1 ; extu.w r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041F18 mov.w @r8,r4
    c.r[1] = ld32(0x06041F54u);  // 06041F1A mov.l 0x06041F54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041F20u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041F20u) return; }  // 06041F1C jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041F20 mov.w @r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06041F42u);  // 06041F22 mov.w 0x06041F42,r1
    c.r[4] |= c.r[1];  // 06041F24 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041F26 mov.w @r8,r1
    c.r[4] |= c.r[1];  // 06041F28 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 06041F2A extu.w r4,r4
    c.r[1] = ld32(0x06041F58u);  // 06041F2C mov.l 0x06041F58,r1
L_06041F2E:
    { const uint32_t x = c.r[1]; c.pr = 0x06041F32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041F32u) return; }  // 06041F2E jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06041F32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041F34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041F36 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041F38 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041F3A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041F3C rts ; mov #1,r0
}

void f_06041F5C(SH2Context& c) {
    ran[1048] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06041F5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06041F5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06041F60 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06041F62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06041F64 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06041F66 sts.l pr,@-r15
    c.r[10] = ld32(0x0604200Cu);  // 06041F68 mov.l 0x0604200C,r10
    c.r[2] = c.r[10];  // 06041F6A mov r10,r2
    c.r[2] += 1;  // 06041F6C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06041F6E mov.b @r2,r1
    c.r[0] = c.r[1];  // 06041F70 mov r1,r0
    c.r[0] >>= 2;  // 06041F72 shlr2 r0
    c.r[0] >>= 2;  // 06041F74 shlr2 r0
    c.r[0] >>= 2;  // 06041F76 shlr2 r0
    c.r[0] &= 0x1u;  // 06041F78 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06041F7A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06041F8A; } }  // 06041F7C bt/s 0x06041F8A ; mov r15,r14
    c.r[10] += 2;  // 06041F80 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06041F82 mov.w @r10,r4
    c.r[1] = ld32(0x06042010u);  // 06041F84 mov.l 0x06042010,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06041FE6;  // 06041F86 bra 0x06041FE6 ; extu.w r4,r4
L_06041F8A:
    c.r[3] = 0x40u;  // 06041F8A mov #64,r3
    c.r[3] |= c.r[1];  // 06041F8C or r1,r3
    st8(c.r[2], c.r[3]);  // 06041F8E mov.b r3,@r2
    c.r[9] = c.r[10];  // 06041F90 mov r10,r9
    c.r[9] += 2;  // 06041F92 add #2,r9
    c.r[1] = 0x3u;  // 06041F94 mov #3,r1
    st16(c.r[9], c.r[1]);  // 06041F96 mov.w r1,@r9
    c.r[8] = c.r[10];  // 06041F98 mov r10,r8
    c.r[8] += 4;  // 06041F9A add #4,r8
    c.r[1] = 0x20u;  // 06041F9C mov #32,r1
    st16(c.r[8], c.r[1]);  // 06041F9E mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06041FFCu);  // 06041FA0 mov.w 0x06041FFC,r0
    c.r[3] &= c.r[0];  // 06041FA2 and r0,r3
    st8(c.r[2], c.r[3]);  // 06041FA4 mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x06041FFEu);  // 06041FA6 mov.w 0x06041FFE,r2
    c.r[1] = 0x6u;  // 06041FA8 mov #6,r1
    c.r[0] = c.r[10];  // 06041FAA mov r10,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06041FAC mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042000u);  // 06041FAE mov.w 0x06042000,r2
    c.r[1] = 0x0u;  // 06041FB0 mov #0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06041FB2 mov.w r1,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06042002u);  // 06041FB4 mov.w 0x06042002,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042004u);  // 06041FB6 mov.w 0x06042004,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06042006u);  // 06041FB8 mov.w 0x06042006,r11
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06041FBA mov.w @(r0,r1),r5
    c.r[6] = 0x2u;  // 06041FBC mov #2,r6
    c.r[4] = ld32(c.r[0] + c.r[11]);  // 06041FBE mov.l @(r0,r11),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06041FC0 extu.w r5,r5
    c.r[5] <<= 2;  // 06041FC2 shll2 r5
    c.r[1] = ld32(0x06042014u);  // 06041FC4 mov.l 0x06042014,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041FCAu; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041FCAu) return; }  // 06041FC6 jsr @r1 ; shll2 r5
    c.r[0] = c.r[10];  // 06041FCA mov r10,r0
    c.r[1] = ld32(0x06042018u);  // 06041FCC mov.l 0x06042018,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041FD2u; c.r[4] = ld32(c.r[0] + c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041FD2u) return; }  // 06041FCE jsr @r1 ; mov.l @(r0,r11),r4
    c.r[1] = ld32(0x0604201Cu);  // 06041FD2 mov.l 0x0604201C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06041FD8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041FD8u) return; }  // 06041FD4 jsr @r1 ; mov #3,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06041FD8 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042008u);  // 06041FDA mov.w 0x06042008,r1
    c.r[4] |= c.r[1];  // 06041FDC or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06041FDE mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06041FE0 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 06041FE2 extu.w r4,r4
    c.r[1] = ld32(0x06042020u);  // 06041FE4 mov.l 0x06042020,r1
L_06041FE6:
    { const uint32_t x = c.r[1]; c.pr = 0x06041FEAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06041FEAu) return; }  // 06041FE6 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06041FEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06041FEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06041FEE mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06041FF0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06041FF2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06041FF4 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06041FF6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06041FF8 rts ; mov #1,r0
}

}  // namespace p_srwfin_installed
