#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_060724EC(SH2Context& c) {
    ran[1597] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060724EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060724EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060724F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060724F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060724F4 mov r15,r14
    c.r[1] = ld32(0x0607254Cu);  // 060724F6 mov.l 0x0607254C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060724FCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060724FCu) return; }  // 060724F8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06072550u);  // 060724FC mov.l 0x06072550,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072502u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072502u) return; }  // 060724FE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06072554u);  // 06072502 mov.l 0x06072554,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072508u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072508u) return; }  // 06072504 jsr @r1 ; nop
    c.r[1] = ld32(0x06072558u);  // 06072508 mov.l 0x06072558,r1
    c.r[4] = ld32(0x0607255Cu);  // 0607250A mov.l 0x0607255C,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607250C mov.b @r1,r1
    c.r[9] = ld32(0x06072560u);  // 0607250E mov.l 0x06072560,r9
    c.r[0] = c.r[1] & 0xFFu;  // 06072510 extu.b r1,r0
    c.r[1] = ld32(0x06072564u);  // 06072512 mov.l 0x06072564,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072514 mov.b @(r0,r1),r8
    c.r[5] = 0x17u;  // 06072516 mov #23,r5
    c.r[8] = c.r[8] & 0xFFu;  // 06072518 extu.b r8,r8
    c.r[8] += 4;  // 0607251A add #4,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06072520u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072520u) return; }  // 0607251C jsr @r9 ; extu.w r8,r8
    c.r[5] = 0xBu;  // 06072520 mov #11,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06072526u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072526u) return; }  // 06072522 jsr @r9 ; mov r0,r4
    c.r[5] = c.r[8];  // 06072526 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607252Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607252Cu) return; }  // 06072528 jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x06072568u);  // 0607252C mov.l 0x06072568,r1
    c.r[6] = 0x0u;  // 0607252E mov #0,r6
    c.r[5] = c.r[0];  // 06072530 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072536u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072536u) return; }  // 06072532 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607256Cu);  // 06072536 mov.l 0x0607256C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607253Cu; c.r[4] = 0x23u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607253Cu) return; }  // 06072538 jsr @r1 ; mov #35,r4
    c.r[15] = c.r[14];  // 0607253C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607253E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06072540 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06072542 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607254Au);  // 06072544 mov.w 0x0607254A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06072546 rts ; mov.l @r15+,r8
}

void f_06072570(SH2Context& c) {
    ran[1598] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 06072570 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 06072572 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072574 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072576 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072578 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607257A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607257C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607257E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06072580 mov r15,r14
    c.r[1] = ld32(0x0607269Cu);  // 06072582 mov.l 0x0607269C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072588u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072588u) return; }  // 06072584 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A0u);  // 06072588 mov.l 0x060726A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607258Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607258Eu) return; }  // 0607258A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A4u);  // 0607258E mov.l 0x060726A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072594u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072594u) return; }  // 06072590 jsr @r1 ; nop
    c.r[6] = ld32(0x060726A8u);  // 06072594 mov.l 0x060726A8,r6
    c.r[1] = ld32(0x060726ACu);  // 06072596 mov.l 0x060726AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072598 mov.b @r1,r1
    c.r[11] = ld32(0x060726B0u);  // 0607259A mov.l 0x060726B0,r11
    c.r[2] = c.r[1] & 0xFFu;  // 0607259C extu.b r1,r2
    c.r[1] = ld32(0x060726B4u);  // 0607259E mov.l 0x060726B4,r1
    c.r[0] = c.r[2];  // 060725A0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725A2 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060726B8u);  // 060725A4 mov.l 0x060726B8,r4
    c.r[2] = ld32(0x060726BCu);  // 060725A6 mov.l 0x060726BC,r2
    c.r[2] = ld32(c.r[2]);  // 060725A8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060725AA extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060725AC dmulu.l r2,r1
    c.r[9] = ld32(0x060726C0u);  // 060725AE mov.l 0x060726C0,r9
    c.r[7] = ld32(c.r[11]);  // 060725B0 mov.l @r11,r7
    c.r[2] = c.mach;  // 060725B2 sts mach,r2
    c.r[2] >>= 2;  // 060725B4 shlr2 r2
    c.r[3] = c.r[2];  // 060725B6 mov r2,r3
    c.r[3] <<= 2;  // 060725B8 shll2 r3
    c.r[3] += c.r[2];  // 060725BA add r2,r3
    c.r[1] -= c.r[3];  // 060725BC sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060725BE extu.b r1,r1
    c.r[3] = c.r[1];  // 060725C0 mov r1,r3
    c.r[3] += c.r[3];  // 060725C2 add r3,r3
    c.r[3] += c.r[1];  // 060725C4 add r1,r3
    c.r[3] += c.r[3];  // 060725C6 add r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060725C8 extu.b r2,r2
    c.r[3] += c.r[2];  // 060725CA add r2,r3
    c.r[3] += c.r[3];  // 060725CC add r3,r3
    c.r[7] += c.r[3];  // 060725CE add r3,r7
    c.r[7] += 1;  // 060725D0 add #1,r7
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060725D2 mov.b @r7,r8
    c.r[5] = 0x10u;  // 060725D4 mov #16,r5
    st8(c.r[6], c.r[8]);  // 060725D6 mov.b r8,@r6
    c.r[8] = c.r[8] & 0xFFu;  // 060725D8 extu.b r8,r8
    c.r[8] += 62;  // 060725DA add #62,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060725E0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E0u) return; }  // 060725DC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060725E0 mov r0,r1
    c.r[5] = c.r[8];  // 060725E2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060725E8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E8u) return; }  // 060725E4 jsr @r9 ; mov r1,r4
    c.r[2] = c.r[0];  // 060725E8 mov r0,r2
    c.r[1] = ld32(0x060726C4u);  // 060725EA mov.l 0x060726C4,r1
    c.r[6] = 0x0u;  // 060725EC mov #0,r6
    c.r[5] = c.r[2];  // 060725EE mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060725F4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725F4u) return; }  // 060725F0 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060725F4 mov.l @r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072692u);  // 060725F6 mov.w 0x06072692,r1
    c.r[0] = c.r[2];  // 060725F8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725FA mov.b @(r0,r1),r1
    c.r[8] = 0x0u;  // 060725FC mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060725FE extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072600 cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[11]; if (k) { goto L_0607267A; } }  // 06072602 bt/s 0x0607267A ; mov r11,r9
    c.r[10] = ld32(0x060726C8u);  // 06072606 mov.l 0x060726C8,r10
L_06072608:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06072694u);  // 06072608 mov.w 0x06072694,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607260Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607260Eu) return; }  // 0607260A jsr @r10 ; nop
    c.r[2] = c.r[8];  // 0607260E mov r8,r2
    c.r[3] = ld32(c.r[9]);  // 06072610 mov.l @r9,r3
    c.r[2] += c.r[2];  // 06072612 add r2,r2
    c.r[0] = c.r[3];  // 06072614 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072616 mov.b @(r0,r2),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06072618 extu.b r1,r7
    c.r[1] = c.r[7];  // 0607261A mov r7,r1
    c.r[1] >>= 2;  // 0607261C shlr2 r1
    c.r[1] >>= 2;  // 0607261E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072620 shlr r1
    c.r[1] >>= 2;  // 06072622 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072624 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06072640; } }  // 06072626 bt/s 0x06072640 ; mov #1,r4
    c.r[0] = 0x7Fu;  // 0607262A mov #127,r0
    c.r[7] &= c.r[0];  // 0607262C and r0,r7
    c.r[3] += c.r[2];  // 0607262E add r2,r3
    c.r[3] += 1;  // 06072630 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072632 mov.b @r3,r1
    c.r[7] <<= 8;  // 06072634 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06072636 extu.b r1,r1
    c.r[1] |= c.r[7];  // 06072638 or r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607263A tst r1,r1
    if (c.t) { goto L_06072640; }  // 0607263C bt 0x06072640
    c.r[4] = 0x2u;  // 0607263E mov #2,r4
L_06072640:
    { const uint32_t x = c.r[10]; c.pr = 0x06072644u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072644u) return; }  // 06072640 jsr @r10 ; nop
    c.r[2] = c.r[8];  // 06072644 mov r8,r2
    c.r[2] += c.r[2];  // 06072646 add r2,r2
    c.r[1] = ld32(c.r[9]);  // 06072648 mov.l @r9,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072696u);  // 0607264A mov.w 0x06072696,r5
    c.r[0] = c.r[1];  // 0607264C mov r1,r0
    c.r[1] += c.r[2];  // 0607264E add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072650 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06072652 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072654 mov.b @r1,r4
    c.r[0] = 0x7Fu;  // 06072656 mov #127,r0
    c.r[3] &= c.r[0];  // 06072658 and r0,r3
    c.r[3] <<= 8;  // 0607265A shll8 r3
    c.r[4] = c.r[4] & 0xFFu;  // 0607265C extu.b r4,r4
    c.r[4] |= c.r[3];  // 0607265E or r3,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072698u);  // 06072660 mov.w 0x06072698,r1
    c.r[4] += c.r[1];  // 06072662 add r1,r4
    c.r[1] = ld32(0x060726CCu);  // 06072664 mov.l 0x060726CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607266Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607266Au) return; }  // 06072666 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[9]);  // 0607266A mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06072692u);  // 0607266C mov.w 0x06072692,r2
    c.r[0] = c.r[1];  // 0607266E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072670 mov.b @(r0,r2),r1
    c.r[8] += 1;  // 06072672 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06072674 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072676 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06072608; }  // 06072678 bf 0x06072608
L_0607267A:
    c.r[1] = ld32(0x060726D0u);  // 0607267A mov.l 0x060726D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072680u; c.r[4] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072680u) return; }  // 0607267C jsr @r1 ; mov #36,r4
    c.r[15] = c.r[14];  // 06072680 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06072682 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06072684 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06072686 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06072688 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607268A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607269Au);  // 0607268C mov.w 0x0607269A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607268E rts ; mov.l @r15+,r8
}

void f_06072574(SH2Context& c) {
    ran[1599] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072574 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072576 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072578 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607257A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607257C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607257E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06072580 mov r15,r14
    c.r[1] = ld32(0x0607269Cu);  // 06072582 mov.l 0x0607269C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072588u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072588u) return; }  // 06072584 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A0u);  // 06072588 mov.l 0x060726A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607258Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607258Eu) return; }  // 0607258A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060726A4u);  // 0607258E mov.l 0x060726A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072594u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072594u) return; }  // 06072590 jsr @r1 ; nop
    c.r[6] = ld32(0x060726A8u);  // 06072594 mov.l 0x060726A8,r6
    c.r[1] = ld32(0x060726ACu);  // 06072596 mov.l 0x060726AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072598 mov.b @r1,r1
    c.r[11] = ld32(0x060726B0u);  // 0607259A mov.l 0x060726B0,r11
    c.r[2] = c.r[1] & 0xFFu;  // 0607259C extu.b r1,r2
    c.r[1] = ld32(0x060726B4u);  // 0607259E mov.l 0x060726B4,r1
    c.r[0] = c.r[2];  // 060725A0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725A2 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060726B8u);  // 060725A4 mov.l 0x060726B8,r4
    c.r[2] = ld32(0x060726BCu);  // 060725A6 mov.l 0x060726BC,r2
    c.r[2] = ld32(c.r[2]);  // 060725A8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060725AA extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060725AC dmulu.l r2,r1
    c.r[9] = ld32(0x060726C0u);  // 060725AE mov.l 0x060726C0,r9
    c.r[7] = ld32(c.r[11]);  // 060725B0 mov.l @r11,r7
    c.r[2] = c.mach;  // 060725B2 sts mach,r2
    c.r[2] >>= 2;  // 060725B4 shlr2 r2
    c.r[3] = c.r[2];  // 060725B6 mov r2,r3
    c.r[3] <<= 2;  // 060725B8 shll2 r3
    c.r[3] += c.r[2];  // 060725BA add r2,r3
    c.r[1] -= c.r[3];  // 060725BC sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060725BE extu.b r1,r1
    c.r[3] = c.r[1];  // 060725C0 mov r1,r3
    c.r[3] += c.r[3];  // 060725C2 add r3,r3
    c.r[3] += c.r[1];  // 060725C4 add r1,r3
    c.r[3] += c.r[3];  // 060725C6 add r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060725C8 extu.b r2,r2
    c.r[3] += c.r[2];  // 060725CA add r2,r3
    c.r[3] += c.r[3];  // 060725CC add r3,r3
    c.r[7] += c.r[3];  // 060725CE add r3,r7
    c.r[7] += 1;  // 060725D0 add #1,r7
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060725D2 mov.b @r7,r8
    c.r[5] = 0x10u;  // 060725D4 mov #16,r5
    st8(c.r[6], c.r[8]);  // 060725D6 mov.b r8,@r6
    c.r[8] = c.r[8] & 0xFFu;  // 060725D8 extu.b r8,r8
    c.r[8] += 62;  // 060725DA add #62,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060725E0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E0u) return; }  // 060725DC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060725E0 mov r0,r1
    c.r[5] = c.r[8];  // 060725E2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060725E8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725E8u) return; }  // 060725E4 jsr @r9 ; mov r1,r4
    c.r[2] = c.r[0];  // 060725E8 mov r0,r2
    c.r[1] = ld32(0x060726C4u);  // 060725EA mov.l 0x060726C4,r1
    c.r[6] = 0x0u;  // 060725EC mov #0,r6
    c.r[5] = c.r[2];  // 060725EE mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060725F4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060725F4u) return; }  // 060725F0 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060725F4 mov.l @r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072692u);  // 060725F6 mov.w 0x06072692,r1
    c.r[0] = c.r[2];  // 060725F8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060725FA mov.b @(r0,r1),r1
    c.r[8] = 0x0u;  // 060725FC mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060725FE extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072600 cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[11]; if (k) { goto L_0607267A; } }  // 06072602 bt/s 0x0607267A ; mov r11,r9
    c.r[10] = ld32(0x060726C8u);  // 06072606 mov.l 0x060726C8,r10
L_06072608:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06072694u);  // 06072608 mov.w 0x06072694,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607260Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607260Eu) return; }  // 0607260A jsr @r10 ; nop
    c.r[2] = c.r[8];  // 0607260E mov r8,r2
    c.r[3] = ld32(c.r[9]);  // 06072610 mov.l @r9,r3
    c.r[2] += c.r[2];  // 06072612 add r2,r2
    c.r[0] = c.r[3];  // 06072614 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072616 mov.b @(r0,r2),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06072618 extu.b r1,r7
    c.r[1] = c.r[7];  // 0607261A mov r7,r1
    c.r[1] >>= 2;  // 0607261C shlr2 r1
    c.r[1] >>= 2;  // 0607261E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072620 shlr r1
    c.r[1] >>= 2;  // 06072622 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072624 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06072640; } }  // 06072626 bt/s 0x06072640 ; mov #1,r4
    c.r[0] = 0x7Fu;  // 0607262A mov #127,r0
    c.r[7] &= c.r[0];  // 0607262C and r0,r7
    c.r[3] += c.r[2];  // 0607262E add r2,r3
    c.r[3] += 1;  // 06072630 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072632 mov.b @r3,r1
    c.r[7] <<= 8;  // 06072634 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06072636 extu.b r1,r1
    c.r[1] |= c.r[7];  // 06072638 or r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607263A tst r1,r1
    if (c.t) { goto L_06072640; }  // 0607263C bt 0x06072640
    c.r[4] = 0x2u;  // 0607263E mov #2,r4
L_06072640:
    { const uint32_t x = c.r[10]; c.pr = 0x06072644u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072644u) return; }  // 06072640 jsr @r10 ; nop
    c.r[2] = c.r[8];  // 06072644 mov r8,r2
    c.r[2] += c.r[2];  // 06072646 add r2,r2
    c.r[1] = ld32(c.r[9]);  // 06072648 mov.l @r9,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072696u);  // 0607264A mov.w 0x06072696,r5
    c.r[0] = c.r[1];  // 0607264C mov r1,r0
    c.r[1] += c.r[2];  // 0607264E add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072650 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06072652 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072654 mov.b @r1,r4
    c.r[0] = 0x7Fu;  // 06072656 mov #127,r0
    c.r[3] &= c.r[0];  // 06072658 and r0,r3
    c.r[3] <<= 8;  // 0607265A shll8 r3
    c.r[4] = c.r[4] & 0xFFu;  // 0607265C extu.b r4,r4
    c.r[4] |= c.r[3];  // 0607265E or r3,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072698u);  // 06072660 mov.w 0x06072698,r1
    c.r[4] += c.r[1];  // 06072662 add r1,r4
    c.r[1] = ld32(0x060726CCu);  // 06072664 mov.l 0x060726CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607266Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607266Au) return; }  // 06072666 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[9]);  // 0607266A mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06072692u);  // 0607266C mov.w 0x06072692,r2
    c.r[0] = c.r[1];  // 0607266E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072670 mov.b @(r0,r2),r1
    c.r[8] += 1;  // 06072672 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06072674 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06072676 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06072608; }  // 06072678 bf 0x06072608
L_0607267A:
    c.r[1] = ld32(0x060726D0u);  // 0607267A mov.l 0x060726D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072680u; c.r[4] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072680u) return; }  // 0607267C jsr @r1 ; mov #36,r4
    c.r[15] = c.r[14];  // 06072680 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06072682 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06072684 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06072686 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06072688 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607268A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607269Au);  // 0607268C mov.w 0x0607269A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607268E rts ; mov.l @r15+,r8
}

void f_060726D4(SH2Context& c) {
    ran[1600] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060726D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060726D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060726D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060726DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060726DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060726DE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060726E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060726E2 sts.l pr,@-r15
    c.r[15] -= 48;  // 060726E4 add #-48,r15
    c.r[14] = c.r[15];  // 060726E6 mov r15,r14
    c.r[1] = ld32(0x06072814u);  // 060726E8 mov.l 0x06072814,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060726EEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060726EEu) return; }  // 060726EA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072818u);  // 060726EE mov.l 0x06072818,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060726F4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060726F4u) return; }  // 060726F0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607281Cu);  // 060726F4 mov.l 0x0607281C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060726FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060726FAu) return; }  // 060726F6 jsr @r1 ; nop
    c.r[1] = ld32(0x06072820u);  // 060726FA mov.l 0x06072820,r1
    c.r[1] = ld32(c.r[1]);  // 060726FC mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607280Cu);  // 060726FE mov.w 0x0607280C,r2
    c.r[0] = c.r[1];  // 06072700 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06072702 mov.b @(r0,r2),r1
    c.r[10] = c.r[1] & 0xFFu;  // 06072704 extu.b r1,r10
    c.r[1] = ld32(0x06072824u);  // 06072706 mov.l 0x06072824,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072708 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607270A extu.b r1,r2
    c.r[1] = ld32(0x06072828u);  // 0607270C mov.l 0x06072828,r1
    c.r[0] = c.r[2];  // 0607270E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072710 mov.b @(r0,r1),r1
    c.r[10] += 1;  // 06072712 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06072714 extu.b r1,r1
    c.r[1] -= 1;  // 06072716 add #-1,r1
    c.r[2] = 0xBu;  // 06072718 mov #11,r2
    c.macl = c.r[1] * c.r[2];  // 0607271A mul.l r2,r1
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 0607271C shar r10
    c.r[0] = c.r[10];  // 0607271E mov r10,r0
    c.r[1] = c.macl;  // 06072720 sts macl,r1
    c.r[0] -= c.r[1];  // 06072722 sub r1,r0
    c.r[1] = c.r[0];  // 06072724 mov r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06072726 cmp/gt r2,r1
    { const bool k = !c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_0607272E; } }  // 06072728 bf/s 0x0607272E ; extu.b r1,r1
    c.r[1] = c.r[2];  // 0607272C mov r2,r1
L_0607272E:
    c.r[12] = c.r[1];  // 0607272E mov r1,r12
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607280Eu);  // 06072730 mov.w 0x0607280E,r9
    c.r[1] += c.r[1];  // 06072732 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06072734 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072736 mov.l r1,@-r15
    c.r[1] = ld32(0x0607282Cu);  // 06072738 mov.l 0x0607282C,r1
    c.r[7] = 0x24u;  // 0607273A mov #36,r7
    c.r[6] = 0x4u;  // 0607273C mov #4,r6
    c.r[5] = 0x1u;  // 0607273E mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072744u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072744u) return; }  // 06072740 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x06072830u);  // 06072744 mov.l 0x06072830,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607274Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607274Au) return; }  // 06072746 jsr @r1 ; mov #1,r4
    c.r[0] = ld32(0x06072824u);  // 0607274A mov.l 0x06072824,r0
    c.r[13] = ld32(0x06072828u);  // 0607274C mov.l 0x06072828,r13
    c.r[11] = ld32(0x06072834u);  // 0607274E mov.l 0x06072834,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06072750 mov.b @r0,r1
    c.r[5] = 0x0u;  // 06072752 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06072754 extu.b r1,r1
    c.r[0] = c.r[1];  // 06072756 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06072758 mov.b @(r0,r13),r6
    c.r[4] = 0x0u;  // 0607275A mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072760u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072760u) return; }  // 0607275C jsr @r11 ; extu.b r6,r6
    c.r[2] = c.r[10];  // 06072760 mov r10,r2
    c.r[2] += 10;  // 06072762 add #10,r2
    c.r[1] = ld32(0x06072838u);  // 06072764 mov.l 0x06072838,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06072766 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06072768 mov #0,r5
    c.r[4] = 0x0u;  // 0607276A mov #0,r4
    c.r[6] = c.mach;  // 0607276C sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0607276E shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06072770 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06072772 subc r2,r2
    { const uint32_t x = c.r[11]; c.pr = 0x06072778u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072778u) return; }  // 06072774 jsr @r11 ; sub r2,r6
    c.r[8] = ld32(0x0607283Cu);  // 06072778 mov.l 0x0607283C,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072810u);  // 0607277A mov.w 0x06072810,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607277C mov.b @r8,r4
    c.r[4] = c.r[4] & 0xFFu;  // 0607277E extu.b r4,r4
    c.r[4] |= c.r[1];  // 06072780 or r1,r4
    c.r[1] = ld32(0x06072840u);  // 06072782 mov.l 0x06072840,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072788u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072788u) return; }  // 06072784 jsr @r1 ; mov r9,r5
    c.r[0] = ld32(0x06072824u);  // 06072788 mov.l 0x06072824,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0607278A mov.b @r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607278C extu.b r1,r3
    c.r[0] = c.r[3];  // 0607278E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06072790 mov.b @(r0,r13),r1
    c.r[9] = 0x16u;  // 06072792 mov #22,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06072794 extu.b r1,r1
    c.r[1] -= 1;  // 06072796 add #-1,r1
    c.macl = c.r[1] * c.r[9];  // 06072798 mul.l r9,r1
    c.r[1] = ld32(0x06072844u);  // 0607279A mov.l 0x06072844,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607279C mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0607279E sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060727A0 extu.b r1,r1
    c.r[2] += c.r[1];  // 060727A2 add r1,r2
    c.r[0] = ld32(0x06072820u);  // 060727A4 mov.l 0x06072820,r0
    c.r[1] = ld32(c.r[0]);  // 060727A6 mov.l @r0,r1
    c.r[2] += c.r[2];  // 060727A8 add r2,r2
    c.r[1] += c.r[2];  // 060727AA add r2,r1
    c.r[1] += 1;  // 060727AC add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060727AE mov.b @r1,r5
    c.r[4] = c.r[14];  // 060727B0 mov r14,r4
    c.r[1] = ld32(0x06072848u);  // 060727B2 mov.l 0x06072848,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060727B8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727B8u) return; }  // 060727B4 jsr @r1 ; extu.b r5,r5
    c.r[6] = 0x0u;  // 060727B8 mov #0,r6
    c.r[5] = c.r[14];  // 060727BA mov r14,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060727BC mov.b @r8,r4
    c.r[0] = ld32(0x0607284Cu);  // 060727BE mov.l 0x0607284C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060727C4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727C4u) return; }  // 060727C0 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 060727C4 mov r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060727C6 extu.b r1,r10
    c.r[15] += 4;  // 060727C8 add #4,r15
    c.t = (c.r[10] & c.r[10]) == 0;  // 060727CA tst r10,r10
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_060727D2; } }  // 060727CC bt/s 0x060727D2 ; mov #-1,r6
    c.r[6] = c.r[10];  // 060727D0 mov r10,r6
L_060727D2:
    c.r[5] = 0x0u;  // 060727D2 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060727D8u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727D8u) return; }  // 060727D4 jsr @r11 ; mov #48,r4
    c.r[1] = ld32(0x06072850u);  // 060727D8 mov.l 0x06072850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060727DEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060727DEu) return; }  // 060727DA jsr @r1 ; mov r12,r4
    c.r[0] = ld32(0x06072820u);  // 060727DE mov.l 0x06072820,r0
    c.r[1] = ld32(c.r[0]);  // 060727E0 mov.l @r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607280Cu);  // 060727E2 mov.w 0x0607280C,r2
    c.r[0] = c.r[1];  // 060727E4 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060727E6 mov.b @(r0,r2),r3
    c.r[0] = ld32(0x06072824u);  // 060727E8 mov.l 0x06072824,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060727EA mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060727EC extu.b r1,r1
    c.r[0] = c.r[1];  // 060727EE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060727F0 mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060727F2 extu.b r1,r1
    c.r[1] -= 1;  // 060727F4 add #-1,r1
    c.macl = c.r[1] * c.r[9];  // 060727F6 mul.l r9,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060727F8 extu.b r3,r2
    c.r[1] = c.macl;  // 060727FA sts macl,r1
    c.r[2] -= c.r[1];  // 060727FC sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 060727FE cmp/gt r9,r2
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06072854; } }  // 06072800 bt/s 0x06072854 ; mov r3,r0
    c.r[0] -= c.r[1];  // 06072804 sub r1,r0
    c.r[1] = c.r[0];  // 06072806 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06072856;  // 06072808 bra 0x06072856 ; extu.b r1,r1
L_06072854:
    c.r[1] = c.r[9];  // 06072854 mov r9,r1
L_06072856:
    c.r[12] = c.r[1];  // 06072856 mov r1,r12
    c.r[13] = ld32(0x0607294Cu);  // 06072858 mov.l 0x0607294C,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072946u);  // 0607285A mov.w 0x06072946,r0
    c.r[11] = ld32(0x06072950u);  // 0607285C mov.l 0x06072950,r11
    c.r[9] = ld32(0x06072954u);  // 0607285E mov.l 0x06072954,r9
    c.r[1] = ld32(c.r[13]);  // 06072860 mov.l @r13,r1
    c.r[8] = 0x16u;  // 06072862 mov #22,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06072864 mov.b @(r0,r1),r2
    c.r[3] = 0x1u;  // 06072866 mov #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06072868 mov.b @r11,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607286A extu.b r2,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0607286C extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607286E mov.b @(r0,r9),r1
    c.r[10] = c.r[2];  // 06072870 mov r2,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06072872 extu.b r1,r1
    c.r[1] -= 1;  // 06072874 add #-1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06072876 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06072878 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607287A mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607287C mov.l r3,@-r15
    c.macl = c.r[1] * c.r[8];  // 0607287E mul.l r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06072880 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06072882 mov.l r3,@-r15
    c.r[1] = c.macl;  // 06072884 sts macl,r1
    c.r[10] -= c.r[1];  // 06072886 sub r1,r10
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[10];  // 06072888 cmp/ge r10,r3
    c.r[10] = c.t;  // 0607288A movt r10
    c.r[1] = 0x0u;  // 0607288C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607288E mov.l r1,@-r15
    c.r[1] = 0x7u;  // 06072890 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06072892 mov.l r1,@-r15
    c.t = (c.r[10] & c.r[10]) == 0;  // 06072894 tst r10,r10
    { const bool k = c.t; c.r[1] = 0xBu; if (k) { goto L_0607289C; } }  // 06072896 bt/s 0x0607289C ; mov #11,r1
    c.r[1] = c.r[3];  // 0607289A mov r3,r1
L_0607289C:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607289C mov.l r1,@-r15
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060728A4; } }  // 0607289E bt/s 0x060728A4 ; mov #2,r1
    c.r[1] = c.r[3];  // 060728A2 mov r3,r1
L_060728A4:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060728A4 mov.l r1,@-r15
    c.r[1] = ld32(0x06072958u);  // 060728A6 mov.l 0x06072958,r1
    c.r[7] = 0x2u;  // 060728A8 mov #2,r7
    c.r[6] = 0xDu;  // 060728AA mov #13,r6
    c.r[5] = 0x5u;  // 060728AC mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060728B2u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060728B2u) return; }  // 060728AE jsr @r1 ; mov #3,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060728B2 mov.b @r11,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060728B4 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060728B6 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060728B8 extu.b r1,r1
    c.r[1] -= 1;  // 060728BA add #-1,r1
    c.macl = c.r[1] * c.r[8];  // 060728BC mul.l r8,r1
    c.r[10] = c.macl;  // 060728BE sts macl,r10
    c.r[1] = c.macl;  // 060728C0 sts macl,r1
    c.r[1] += c.r[12];  // 060728C2 add r12,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060728C4 cmp/ge r1,r10
    { const bool k = c.t; c.r[15] += 40; if (k) { goto L_060729C6; } }  // 060728C6 bt/s 0x060729C6 ; add #40,r15
    c.r[11] = ld32(0x0607295Cu);  // 060728CA mov.l 0x0607295C,r11
    c.r[9] = c.macl;  // 060728CC sts macl,r9
    c.r[9] += c.r[9];  // 060728CE add r9,r9
L_060728D0:
    c.r[1] = ld32(c.r[13]);  // 060728D0 mov.l @r13,r1
    c.r[1] += c.r[9];  // 060728D2 add r9,r1
    c.r[1] += 1;  // 060728D4 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060728D6 mov.b @r1,r4
    c.r[0] = ld32(0x06072960u);  // 060728D8 mov.l 0x06072960,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060728DEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060728DEu) return; }  // 060728DA jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 060728DE extu.b r0,r2
    c.r[1] = ld32(0x06072964u);  // 060728E0 mov.l 0x06072964,r1
    c.r[3] = c.r[2];  // 060728E2 mov r2,r3
    c.r[7] = ld32(c.r[1]);  // 060728E4 mov.l @r1,r7
    c.r[3] <<= 2;  // 060728E6 shll2 r3
    c.r[3] <<= 2;  // 060728E8 shll2 r3
    c.r[3] += c.r[7];  // 060728EA add r7,r3
    c.r[1] = c.r[3];  // 060728EC mov r3,r1
    c.r[1] += 4;  // 060728EE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060728F0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060728F2 mov r1,r0
    c.r[0] >>= 2;  // 060728F4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060728F6 shlr r0
    c.r[0] >>= 2;  // 060728F8 shlr2 r0
    c.r[0] &= 0x1u;  // 060728FA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060728FC tst r0,r0
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0607290A; } }  // 060728FE bt/s 0x0607290A ; shll2 r2
    c.r[3] += 6;  // 06072902 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072904 mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06072906 extu.b r1,r2
    c.r[2] <<= 2;  // 06072908 shll2 r2
L_0607290A:
    c.r[2] <<= 2;  // 0607290A shll2 r2
    c.r[2] += c.r[7];  // 0607290C add r7,r2
    c.r[2] += 7;  // 0607290E add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06072910 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06072912 mov r1,r0
    c.r[0] >>= 2;  // 06072914 shlr2 r0
    c.r[0] >>= 2;  // 06072916 shlr2 r0
    c.r[0] &= 0x1u;  // 06072918 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607291A tst r0,r0
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_06072922; } }  // 0607291C bt/s 0x06072922 ; mov #0,r4
    c.r[4] = 0x2Du;  // 06072920 mov #45,r4
L_06072922:
    { const uint32_t x = c.r[11]; c.pr = 0x06072926u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072926u) return; }  // 06072922 jsr @r11 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x06072948u);  // 06072926 mov.w 0x06072948,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607292Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607292Cu) return; }  // 06072928 jsr @r11 ; nop
    c.r[1] = ld32(c.r[13]);  // 0607292C mov.l @r13,r1
    c.r[0] = c.r[1];  // 0607292E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06072930 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06072932 extu.b r1,r1
    c.r[1] >>= 2;  // 06072934 shlr2 r1
    c.r[1] >>= 2;  // 06072936 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072938 shlr r1
    c.r[1] >>= 2;  // 0607293A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607293C tst r1,r1
    if (c.t) { goto L_06072968; }  // 0607293E bt 0x06072968
    c.r[4] = 0x2u;  // 06072940 mov #2,r4
    goto L_0607296A;  // 06072942 bra 0x0607296A ; nop
L_06072968:
    c.r[4] = 0x1u;  // 06072968 mov #1,r4
L_0607296A:
    { const uint32_t x = c.r[11]; c.pr = 0x0607296Eu; c.r[10] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607296Eu) return; }  // 0607296A jsr @r11 ; add #1,r10
    c.r[1] = ld32(c.r[13]);  // 0607296E mov.l @r13,r1
    c.r[1] += c.r[9];  // 06072970 add r9,r1
    c.r[1] += 1;  // 06072972 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072974 mov.b @r1,r1
    c.r[0] = ld32(0x06072A18u);  // 06072976 mov.l 0x06072A18,r0
    c.r[2] = c.r[1] & 0xFFu;  // 06072978 extu.b r1,r2
    c.r[8] = c.r[2];  // 0607297A mov r2,r8
    c.r[8] += c.r[8];  // 0607297C add r8,r8
    c.r[8] += c.r[2];  // 0607297E add r2,r8
    c.r[1] = ld32(c.r[0]);  // 06072980 mov.l @r0,r1
    c.r[8] <<= 2;  // 06072982 shll2 r8
    c.r[0] = c.r[8];  // 06072984 mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06072986 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072A10u);  // 06072988 mov.w 0x06072A10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072A12u);  // 0607298A mov.w 0x06072A12,r1
    c.r[4] += c.r[1];  // 0607298C add r1,r4
    c.r[1] = ld32(0x06072A1Cu);  // 0607298E mov.l 0x06072A1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072994u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072994u) return; }  // 06072990 jsr @r1 ; extu.w r4,r4
    c.r[0] = ld32(0x06072A18u);  // 06072994 mov.l 0x06072A18,r0
    c.r[5] = 0x0u;  // 06072996 mov #0,r5
    c.r[1] = ld32(c.r[0]);  // 06072998 mov.l @r0,r1
    c.r[4] = 0x0u;  // 0607299A mov #0,r4
    c.r[8] += c.r[1];  // 0607299C add r1,r8
    c.r[8] += 10;  // 0607299E add #10,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060729A0 mov.w @r8,r6
    c.r[1] = ld32(0x06072A20u);  // 060729A2 mov.l 0x06072A20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060729A8u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729A8u) return; }  // 060729A4 jsr @r1 ; extu.w r6,r6
    c.r[1] = ld32(0x06072A24u);  // 060729A8 mov.l 0x06072A24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060729AA mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060729AC extu.b r1,r2
    c.r[1] = ld32(0x06072A28u);  // 060729AE mov.l 0x06072A28,r1
    c.r[0] = c.r[2];  // 060729B0 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060729B2 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 060729B4 extu.b r2,r2
    c.r[2] -= 1;  // 060729B6 add #-1,r2
    c.r[1] = 0x16u;  // 060729B8 mov #22,r1
    c.macl = c.r[2] * c.r[1];  // 060729BA mul.l r1,r2
    c.r[1] = c.macl;  // 060729BC sts macl,r1
    c.r[1] += c.r[12];  // 060729BE add r12,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060729C0 cmp/ge r1,r10
    { const bool k = !c.t; c.r[9] += 2; if (k) { SH2_POLL(c); goto L_060728D0; } }  // 060729C2 bf/s 0x060728D0 ; add #2,r9
L_060729C6:
    c.r[0] = 0x1u;  // 060729C6 mov #1,r0
    c.r[12] &= c.r[0];  // 060729C8 and r0,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 060729CA tst r12,r12
    if (c.t) { goto L_060729F2; }  // 060729CC bt 0x060729F2
    c.r[8] = ld32(0x06072A2Cu);  // 060729CE mov.l 0x06072A2C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060729D4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729D4u) return; }  // 060729D0 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729D8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729D8u) return; }  // 060729D4 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729DCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729DCu) return; }  // 060729D8 jsr @r8 ; mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072A10u);  // 060729DC mov.w 0x06072A10,r5
    c.r[4] = ld32(0x06072A30u);  // 060729DE mov.l 0x06072A30,r4
    c.r[1] = ld32(0x06072A1Cu);  // 060729E0 mov.l 0x06072A1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060729E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729E6u) return; }  // 060729E2 jsr @r1 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060729EAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729EAu) return; }  // 060729E6 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729EEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729EEu) return; }  // 060729EA jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060729F2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729F2u) return; }  // 060729EE jsr @r8 ; mov #0,r4
L_060729F2:
    c.r[1] = ld32(0x06072A34u);  // 060729F2 mov.l 0x06072A34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060729F8u; c.r[4] = 0x25u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060729F8u) return; }  // 060729F4 jsr @r1 ; mov #37,r4
    c.r[14] += 48;  // 060729F8 add #48,r14
    c.r[15] = c.r[14];  // 060729FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060729FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060729FE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06072A00 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06072A02 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06072A04 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06072A06 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06072A08 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072A14u);  // 06072A0A mov.w 0x06072A14,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06072A0C rts ; mov.l @r15+,r8
}

void f_06072A38(SH2Context& c) {
    ran[1601] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06072A38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06072A3A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06072A3C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06072A3E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06072A40 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06072A42 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06072A44 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06072A46 sts.l pr,@-r15
    c.r[15] -= 32;  // 06072A48 add #-32,r15
    c.r[14] = c.r[15];  // 06072A4A mov r15,r14
    c.r[1] = 0x0u;  // 06072A4C mov #0,r1
    c.r[2] = 0x0u;  // 06072A4E mov #0,r2
    st32(c.r[14] + 16, c.r[1]);  // 06072A50 mov.l r1,@(16,r14)
    st32(c.r[14] + 20, c.r[2]);  // 06072A52 mov.l r2,@(20,r14)
    c.r[1] = ld32(0x06072B6Cu);  // 06072A54 mov.l 0x06072B6C,r1
    st32(c.r[14] + 16, c.r[1]);  // 06072A56 mov.l r1,@(16,r14)
    c.r[1] = ld32(0x06072B70u);  // 06072A58 mov.l 0x06072B70,r1
    st32(c.r[14] + 20, c.r[1]);  // 06072A5A mov.l r1,@(20,r14)
    c.r[1] = ld32(0x06072B74u);  // 06072A5C mov.l 0x06072B74,r1
    st32(c.r[14], c.r[1]);  // 06072A5E mov.l r1,@r14
    c.r[1] = ld32(0x06072B78u);  // 06072A60 mov.l 0x06072B78,r1
    st32(c.r[14] + 4, c.r[1]);  // 06072A62 mov.l r1,@(4,r14)
    c.r[2] = c.r[14];  // 06072A64 mov r14,r2
    c.r[2] += 8;  // 06072A66 add #8,r2
    c.r[1] = ld32(0x06072B7Cu);  // 06072A68 mov.l 0x06072B7C,r1
    st32(c.r[14] + 8, c.r[1]);  // 06072A6A mov.l r1,@(8,r14)
    c.r[1] = ld32(0x06072B80u);  // 06072A6C mov.l 0x06072B80,r1
    st32(c.r[2] + 4, c.r[1]);  // 06072A6E mov.l r1,@(4,r2)
    c.r[1] = ld32(0x06072B84u);  // 06072A70 mov.l 0x06072B84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072A76u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072A76u) return; }  // 06072A72 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072B88u);  // 06072A76 mov.l 0x06072B88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072A7Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072A7Cu) return; }  // 06072A78 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06072B8Cu);  // 06072A7C mov.l 0x06072B8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072A82u; c.r[13] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072A82u) return; }  // 06072A7E jsr @r1 ; mov r14,r13
    c.r[0] = 0x0u;  // 06072A82 mov #0,r0
    st32(c.r[14] + 24, c.r[0]);  // 06072A84 mov.l r0,@(24,r14)
    c.r[11] = ld32(0x06072B90u);  // 06072A86 mov.l 0x06072B90,r11
    c.r[12] = 0x0u;  // 06072A88 mov #0,r12
    st32(c.r[14] + 28, c.r[14]);  // 06072A8A mov.l r14,@(28,r14)
L_06072A8C:
    c.r[0] = c.r[12];  // 06072A8C mov r12,r0
    c.r[5] = 0x0u;  // 06072A8E mov #0,r5
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072A90 mov.l @(r0,r14),r1
    c.r[4] = 0x8u;  // 06072A92 mov #8,r4
    c.r[1] += 30;  // 06072A94 add #30,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072A96 mov.b @r1,r6
    c.r[0] = ld32(0x06072B94u);  // 06072A98 mov.l 0x06072B94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072A9Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072A9Eu) return; }  // 06072A9A jsr @r0 ; extu.b r6,r6
    c.r[0] = c.r[12];  // 06072A9E mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072AA0 mov.l @(r0,r14),r1
    c.r[5] = 0x17u;  // 06072AA2 mov #23,r5
    c.r[1] += 30;  // 06072AA4 add #30,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072AA6 mov.b @r1,r8
    c.r[4] = ld32(0x06072B98u);  // 06072AA8 mov.l 0x06072B98,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072AAEu; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072AAEu) return; }  // 06072AAA jsr @r11 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06072AAE mov r0,r1
    c.r[5] = 0x14u;  // 06072AB0 mov #20,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072AB6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072AB6u) return; }  // 06072AB2 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072AB6 mov r0,r1
    c.r[5] = c.r[8];  // 06072AB8 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072ABEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072ABEu) return; }  // 06072ABA jsr @r11 ; mov r1,r4
    c.r[2] = c.r[0];  // 06072ABE mov r0,r2
    c.r[1] = ld32(0x06072B9Cu);  // 06072AC0 mov.l 0x06072B9C,r1
    c.r[6] = 0x0u;  // 06072AC2 mov #0,r6
    c.r[5] = c.r[2];  // 06072AC4 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06072ACAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072ACAu) return; }  // 06072AC6 jsr @r1 ; mov #0,r4
    c.r[0] = c.r[12];  // 06072ACA mov r12,r0
    c.r[5] = 0x0u;  // 06072ACC mov #0,r5
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072ACE mov.l @(r0,r14),r1
    c.r[4] = 0x8u;  // 06072AD0 mov #8,r4
    c.r[1] += 2;  // 06072AD2 add #2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072AD4 mov.w @r1,r6
    c.r[0] = ld32(0x06072B94u);  // 06072AD6 mov.l 0x06072B94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072ADCu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072ADCu) return; }  // 06072AD8 jsr @r0 ; extu.w r6,r6
    c.r[0] = c.r[12];  // 06072ADC mov r12,r0
    c.r[5] = 0x0u;  // 06072ADE mov #0,r5
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072AE0 mov.l @(r0,r14),r1
    c.r[4] = 0x8u;  // 06072AE2 mov #8,r4
    c.r[1] += 4;  // 06072AE4 add #4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072AE6 mov.w @r1,r6
    c.r[0] = ld32(0x06072B94u);  // 06072AE8 mov.l 0x06072B94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072AEEu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072AEEu) return; }  // 06072AEA jsr @r0 ; extu.w r6,r6
    c.r[0] = c.r[12];  // 06072AEE mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072AF0 mov.l @(r0,r14),r1
    c.r[1] += 2;  // 06072AF2 add #2,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072AF4 mov.w @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06072B68u);  // 06072AF6 mov.w 0x06072B68,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072B6Au);  // 06072AF8 mov.w 0x06072B6A,r1
    c.r[4] += c.r[1];  // 06072AFA add r1,r4
    c.r[1] = ld32(0x06072BA0u);  // 06072AFC mov.l 0x06072BA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06072B02u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072B02u) return; }  // 06072AFE jsr @r1 ; extu.w r4,r4
    c.r[0] = c.r[12];  // 06072B02 mov r12,r0
    c.r[5] = 0x0u;  // 06072B04 mov #0,r5
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072B06 mov.l @(r0,r14),r1
    c.r[4] = 0x8u;  // 06072B08 mov #8,r4
    c.r[1] += 10;  // 06072B0A add #10,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072B0C mov.w @r1,r6
    c.r[0] = ld32(0x06072B94u);  // 06072B0E mov.l 0x06072B94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072B14u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072B14u) return; }  // 06072B10 jsr @r0 ; extu.w r6,r6
    c.r[0] = c.r[12];  // 06072B14 mov r12,r0
    c.r[5] = 0x0u;  // 06072B16 mov #0,r5
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072B18 mov.l @(r0,r14),r1
    c.r[4] = 0x8u;  // 06072B1A mov #8,r4
    c.r[1] += 6;  // 06072B1C add #6,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072B1E mov.w @r1,r6
    c.r[0] = ld32(0x06072B94u);  // 06072B20 mov.l 0x06072B94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072B26u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072B26u) return; }  // 06072B22 jsr @r0 ; extu.w r6,r6
    c.r[0] = ld32(c.r[14] + 28);  // 06072B26 mov.l @(28,r14),r0
    c.r[1] = ld32(c.r[0] + 16);  // 06072B28 mov.l @(16,r0),r1
    c.r[1] += 1;  // 06072B2A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072B2C mov.b @r1,r1
    c.r[0] = 0x1u;  // 06072B2E mov #1,r0
    c.r[1] >>= 2;  // 06072B30 shlr2 r1
    c.r[1] >>= 2;  // 06072B32 shlr2 r1
    c.r[1] &= c.r[0];  // 06072B34 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072B36 tst r1,r1
    if (c.t) { goto L_06072BA8; }  // 06072B38 bt 0x06072BA8
    c.r[0] = ld32(0x06072BA4u);  // 06072B3A mov.l 0x06072BA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072B40u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072B40u) return; }  // 06072B3C jsr @r0 ; mov #4,r4
    c.r[0] = ld32(c.r[14] + 28);  // 06072B40 mov.l @(28,r14),r0
    c.r[5] = 0x17u;  // 06072B42 mov #23,r5
    c.r[1] = ld32(c.r[0] + 16);  // 06072B44 mov.l @(16,r0),r1
    c.r[4] = ld32(0x06072B98u);  // 06072B46 mov.l 0x06072B98,r4
    c.r[1] += 1;  // 06072B48 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072B4A mov.b @r1,r1
    c.r[0] = 0x1u;  // 06072B4C mov #1,r0
    c.r[1] >>= 2;  // 06072B4E shlr2 r1
    c.r[1] &= c.r[0];  // 06072B50 and r0,r1
    c.r[1] += 1;  // 06072B52 add #1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x06072B58u; c.r[8] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072B58u) return; }  // 06072B54 jsr @r11 ; extu.b r1,r8
    c.r[1] = c.r[0];  // 06072B58 mov r0,r1
    c.r[5] = 0x15u;  // 06072B5A mov #21,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072B60u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072B60u) return; }  // 06072B5C jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072B60 mov r0,r1
    c.r[6] = 0x0u;  // 06072B62 mov #0,r6
    c.r[5] = c.r[8]; goto L_06072BC2;  // 06072B64 bra 0x06072BC2 ; mov r8,r5
L_06072BA8:
    c.r[0] = ld32(0x06072D68u);  // 06072BA8 mov.l 0x06072D68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072BAEu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072BAEu) return; }  // 06072BAA jsr @r0 ; mov #2,r4
    c.r[4] = ld32(0x06072D6Cu);  // 06072BAE mov.l 0x06072D6C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072BB4u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072BB4u) return; }  // 06072BB0 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072BB4 mov r0,r1
    c.r[5] = 0x15u;  // 06072BB6 mov #21,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072BBCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072BBCu) return; }  // 06072BB8 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072BBC mov r0,r1
    c.r[6] = 0x0u;  // 06072BBE mov #0,r6
    c.r[5] = 0x0u;  // 06072BC0 mov #0,r5
L_06072BC2:
    c.r[0] = ld32(0x06072D70u);  // 06072BC2 mov.l 0x06072D70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072BC8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072BC8u) return; }  // 06072BC4 jsr @r0 ; mov r1,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x06072D5Cu);  // 06072BC8 mov.w 0x06072D5C,r9
    c.r[0] = c.r[12];  // 06072BCA mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072BCC mov.l @(r0,r14),r1
    c.r[8] = ld32(0x06072D74u);  // 06072BCE mov.l 0x06072D74,r8
    c.r[1] += 10;  // 06072BD0 add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072BD2 mov.w @r1,r4
    c.r[5] = c.r[9];  // 06072BD4 mov r9,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072D5Eu);  // 06072BD6 mov.w 0x06072D5E,r1
    c.r[4] += c.r[1];  // 06072BD8 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06072BDEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072BDEu) return; }  // 06072BDA jsr @r8 ; extu.w r4,r4
    c.r[0] = c.r[12];  // 06072BDE mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072BE0 mov.l @(r0,r14),r1
    c.r[1] += 6;  // 06072BE2 add #6,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072BE4 mov.w @r1,r4
    c.r[5] = c.r[9];  // 06072BE6 mov r9,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072D60u);  // 06072BE8 mov.w 0x06072D60,r1
    c.r[4] += c.r[1];  // 06072BEA add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06072BF0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072BF0u) return; }  // 06072BEC jsr @r8 ; extu.w r4,r4
    c.r[0] = c.r[12];  // 06072BF0 mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072BF2 mov.l @(r0,r14),r1
    c.r[5] = 0x1Cu;  // 06072BF4 mov #28,r5
    c.r[1] += 6;  // 06072BF6 add #6,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072BF8 mov.w @r1,r8
    c.r[4] = ld32(0x06072D6Cu);  // 06072BFA mov.l 0x06072D6C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072C00u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C00u) return; }  // 06072BFC jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06072C00 mov r0,r1
    c.r[5] = c.r[8];  // 06072C02 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072C08u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C08u) return; }  // 06072C04 jsr @r11 ; mov r1,r4
    c.r[9] = c.r[0];  // 06072C08 mov r0,r9
    c.r[0] = c.r[12];  // 06072C0A mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072C0C mov.l @(r0,r14),r1
    c.r[5] = 0x1Cu;  // 06072C0E mov #28,r5
    c.r[1] += 6;  // 06072C10 add #6,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072C12 mov.w @r1,r8
    c.r[4] = ld32(0x06072D6Cu);  // 06072C14 mov.l 0x06072D6C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072C1Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C1Au) return; }  // 06072C16 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06072C1A mov r0,r1
    c.r[5] = c.r[8];  // 06072C1C mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072C22u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C22u) return; }  // 06072C1E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072C22 mov r0,r1
    c.r[0] = c.r[12];  // 06072C24 mov r12,r0
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 06072C26 mov.l @(r0,r14),r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06072C28 mov.b @r9,r2
    c.r[1] += 1;  // 06072C2A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072C2C mov.b @r1,r1
    c.r[3] += 8;  // 06072C2E add #8,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06072C30 extu.b r2,r2
    c.r[2] <<= 8;  // 06072C32 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06072C34 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06072C36 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06072D62u);  // 06072C38 mov.w 0x06072D62,r1
    c.r[2] &= c.r[1];  // 06072C3A and r1,r2
    st16(c.r[3], c.r[2]);  // 06072C3C mov.w r2,@r3
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072C3E mov.l @(r0,r14),r1
    c.r[5] = 0x1Du;  // 06072C40 mov #29,r5
    c.r[1] += 2;  // 06072C42 add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072C44 mov.w @r1,r8
    c.r[4] = ld32(0x06072D6Cu);  // 06072C46 mov.l 0x06072D6C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072C4Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C4Cu) return; }  // 06072C48 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06072C4C mov r0,r1
    c.r[5] = c.r[8];  // 06072C4E mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072C54u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C54u) return; }  // 06072C50 jsr @r11 ; mov r1,r4
    c.r[6] = c.r[0];  // 06072C54 mov r0,r6
    c.r[0] = c.r[12];  // 06072C56 mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072C58 mov.l @(r0,r14),r1
    c.r[6] += 2;  // 06072C5A add #2,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06072C5C mov.b @r6,r2
    c.r[1] += 28;  // 06072C5E add #28,r1
    c.r[0] = 0x3Fu;  // 06072C60 mov #63,r0
    c.r[2] &= c.r[0];  // 06072C62 and r0,r2
    st8(c.r[1], c.r[2]);  // 06072C64 mov.b r2,@r1
    c.r[0] = c.r[12];  // 06072C66 mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072C68 mov.l @(r0,r14),r1
    c.r[5] = 0x1Bu;  // 06072C6A mov #27,r5
    c.r[1] += 10;  // 06072C6C add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072C6E mov.w @r1,r8
    c.r[4] = ld32(0x06072D6Cu);  // 06072C70 mov.l 0x06072D6C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072C76u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C76u) return; }  // 06072C72 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06072C76 mov r0,r1
    c.r[5] = c.r[8];  // 06072C78 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072C7Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072C7Eu) return; }  // 06072C7A jsr @r11 ; mov r1,r4
    c.r[6] = c.r[0];  // 06072C7E mov r0,r6
    c.r[0] = c.r[12];  // 06072C80 mov r12,r0
    c.r[1] = c.r[6];  // 06072C82 mov r6,r1
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 06072C84 mov.l @(r0,r14),r2
    c.r[1] += 6;  // 06072C86 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072C88 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072D64u);  // 06072C8A mov.w 0x06072D64,r0
    c.r[1] &= c.r[0];  // 06072C8C and r0,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06072C8E mov.b @r2,r3
    c.r[0] = 0x1Fu;  // 06072C90 mov #31,r0
    c.r[3] &= c.r[0];  // 06072C92 and r0,r3
    c.r[3] |= c.r[1];  // 06072C94 or r1,r3
    st8(c.r[2], c.r[3]);  // 06072C96 mov.b r3,@r2
    c.r[0] = c.r[12];  // 06072C98 mov r12,r0
    c.r[1] = c.r[6];  // 06072C9A mov r6,r1
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 06072C9C mov.l @(r0,r14),r3
    c.r[1] += 2;  // 06072C9E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072CA0 mov.b @r1,r2
    c.r[3] += 12;  // 06072CA2 add #12,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06072CA4 extu.b r2,r2
    c.r[1] = c.r[6];  // 06072CA6 mov r6,r1
    c.r[1] += 3;  // 06072CA8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072CAA mov.b @r1,r1
    c.r[2] <<= 8;  // 06072CAC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06072CAE extu.b r1,r1
    c.r[2] |= c.r[1];  // 06072CB0 or r1,r2
    st16(c.r[3], c.r[2]);  // 06072CB2 mov.w r2,@r3
    c.r[1] = c.r[6];  // 06072CB4 mov r6,r1
    c.r[1] += 10;  // 06072CB6 add #10,r1
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 06072CB8 mov.l @(r0,r14),r2
    c.r[3] = 0x3u;  // 06072CBA mov #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072CBC mov.b @r1,r1
    c.r[2] += 1;  // 06072CBE add #1,r2
    c.r[3] &= c.r[1];  // 06072CC0 and r1,r3
    c.r[3] <<= 2;  // 06072CC2 shll2 r3
    c.r[3] += c.r[3];  // 06072CC4 add r3,r3
    c.r[3] <<= 2;  // 06072CC6 shll2 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06072CC8 mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072D66u);  // 06072CCA mov.w 0x06072D66,r0
    c.r[1] &= c.r[0];  // 06072CCC and r0,r1
    c.r[1] |= c.r[3];  // 06072CCE or r3,r1
    st8(c.r[2], c.r[1]);  // 06072CD0 mov.b r1,@r2
    c.r[0] = c.r[12];  // 06072CD2 mov r12,r0
    c.r[1] = c.r[6];  // 06072CD4 mov r6,r1
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 06072CD6 mov.l @(r0,r14),r3
    c.r[1] += 36;  // 06072CD8 add #36,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072CDA mov.b @r1,r2
    c.r[7] = c.r[3];  // 06072CDC mov r3,r7
    c.r[7] += 14;  // 06072CDE add #14,r7
    c.r[3] += 16;  // 06072CE0 add #16,r3
    c.r[1] = c.r[6];  // 06072CE2 mov r6,r1
    c.r[1] += 37;  // 06072CE4 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072CE6 mov.b @r1,r1
    c.r[2] <<= 8;  // 06072CE8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06072CEA extu.b r1,r1
    c.r[2] |= c.r[1];  // 06072CEC or r1,r2
    st16(c.r[3], c.r[2]);  // 06072CEE mov.w r2,@r3
    st16(c.r[7], c.r[2]);  // 06072CF0 mov.w r2,@r7
    c.r[1] = c.r[6];  // 06072CF2 mov r6,r1
    c.r[1] += 34;  // 06072CF4 add #34,r1
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 06072CF6 mov.l @(r0,r14),r3
    c.r[6] += 35;  // 06072CF8 add #35,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072CFA mov.b @r1,r2
    c.r[7] = c.r[3];  // 06072CFC mov r3,r7
    c.r[7] += 18;  // 06072CFE add #18,r7
    c.r[3] += 20;  // 06072D00 add #20,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06072D02 mov.b @r6,r1
    c.r[2] <<= 8;  // 06072D04 shll8 r2
    c.r[0] = ld32(c.r[14] + 28);  // 06072D06 mov.l @(28,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06072D08 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06072D0A or r1,r2
    st16(c.r[3], c.r[2]);  // 06072D0C mov.w r2,@r3
    st16(c.r[7], c.r[2]);  // 06072D0E mov.w r2,@r7
    c.r[1] = ld32(c.r[0] + 16);  // 06072D10 mov.l @(16,r0),r1
    c.r[2] = c.r[1];  // 06072D12 mov r1,r2
    c.r[1] += 2;  // 06072D14 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072D16 mov.w @r1,r1
    c.r[2] += 4;  // 06072D18 add #4,r2
    st16(c.r[2], c.r[1]);  // 06072D1A mov.w r1,@r2
    c.r[1] = ld32(c.r[0] + 16);  // 06072D1C mov.l @(16,r0),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072D1E mov.b @r1,r1
    c.r[0] = 0x1u;  // 06072D20 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06072D22 extu.b r1,r1
    c.r[2] = c.r[1];  // 06072D24 mov r1,r2
    c.r[2] >>= 2;  // 06072D26 shlr2 r2
    c.r[2] >>= 2;  // 06072D28 shlr2 r2
    c.r[2] >>= 2;  // 06072D2A shlr2 r2
    c.r[2] &= c.r[0];  // 06072D2C and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06072D2E tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06072D94; } }  // 06072D30 bt/s 0x06072D94 ; mov r1,r0
    c.r[0] >>= 2;  // 06072D34 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06072D36 shlr r0
    c.r[0] >>= 2;  // 06072D38 shlr2 r0
    c.r[0] &= 0x1u;  // 06072D3A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06072D3C tst r0,r0
    if (c.t) { goto L_06072D78; }  // 06072D3E bt 0x06072D78
    c.r[0] = ld32(0x06072D68u);  // 06072D40 mov.l 0x06072D68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072D46u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D46u) return; }  // 06072D42 jsr @r0 ; mov #6,r4
    c.r[4] = ld32(0x06072D6Cu);  // 06072D46 mov.l 0x06072D6C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072D4Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D4Cu) return; }  // 06072D48 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072D4C mov r0,r1
    c.r[5] = 0xCu;  // 06072D4E mov #12,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072D54u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D54u) return; }  // 06072D50 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072D54 mov r0,r1
    c.r[6] = 0x0u;  // 06072D56 mov #0,r6
    c.r[5] = 0x2u; goto L_06072DAE;  // 06072D58 bra 0x06072DAE ; mov #2,r5
L_06072D78:
    c.r[0] = ld32(0x06072FDCu);  // 06072D78 mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072D7Eu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D7Eu) return; }  // 06072D7A jsr @r0 ; mov #4,r4
    c.r[4] = ld32(0x06072FE0u);  // 06072D7E mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072D84u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D84u) return; }  // 06072D80 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072D84 mov r0,r1
    c.r[5] = 0xCu;  // 06072D86 mov #12,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072D8Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D8Cu) return; }  // 06072D88 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072D8C mov r0,r1
    c.r[6] = 0x0u;  // 06072D8E mov #0,r6
    c.r[5] = 0x1u; goto L_06072DAE;  // 06072D90 bra 0x06072DAE ; mov #1,r5
L_06072D94:
    c.r[0] = ld32(0x06072FDCu);  // 06072D94 mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072D9Au; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072D9Au) return; }  // 06072D96 jsr @r0 ; mov #3,r4
    c.r[4] = ld32(0x06072FE0u);  // 06072D9A mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072DA0u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DA0u) return; }  // 06072D9C jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072DA0 mov r0,r1
    c.r[5] = 0xCu;  // 06072DA2 mov #12,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072DA8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DA8u) return; }  // 06072DA4 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072DA8 mov r0,r1
    c.r[6] = 0x0u;  // 06072DAA mov #0,r6
    c.r[5] = 0x0u;  // 06072DAC mov #0,r5
L_06072DAE:
    c.r[0] = ld32(0x06072FE4u);  // 06072DAE mov.l 0x06072FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072DB4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DB4u) return; }  // 06072DB0 jsr @r0 ; mov r1,r4
    c.r[0] = ld32(c.r[14] + 24);  // 06072DB4 mov.l @(24,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06072DB6 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06072DBE; } }  // 06072DB8 bf/s 0x06072DBE ; mov #0,r1
    c.r[1] = 0x8u;  // 06072DBC mov #8,r1
L_06072DBE:
    c.r[0] = c.r[14];  // 06072DBE mov r14,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06072DC0 mov.l @(r0,r1),r1
    c.r[5] = 0x1Bu;  // 06072DC2 mov #27,r5
    c.r[1] += 10;  // 06072DC4 add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072DC6 mov.w @r1,r8
    c.r[4] = ld32(0x06072FE0u);  // 06072DC8 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072DCEu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DCEu) return; }  // 06072DCA jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06072DCE mov r0,r1
    c.r[5] = c.r[8];  // 06072DD0 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072DD6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DD6u) return; }  // 06072DD2 jsr @r11 ; mov r1,r4
    c.r[9] = c.r[0];  // 06072DD6 mov r0,r9
    c.r[0] = ld32(c.r[14] + 24);  // 06072DD8 mov.l @(24,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06072DDA tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06072DE2; } }  // 06072DDC bf/s 0x06072DE2 ; mov #0,r1
    c.r[1] = 0x8u;  // 06072DE0 mov #8,r1
L_06072DE2:
    c.r[0] = c.r[14];  // 06072DE2 mov r14,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06072DE4 mov.l @(r0,r1),r1
    c.r[5] = 0x1Bu;  // 06072DE6 mov #27,r5
    c.r[1] += 10;  // 06072DE8 add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072DEA mov.w @r1,r8
    c.r[4] = ld32(0x06072FE0u);  // 06072DEC mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072DF2u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DF2u) return; }  // 06072DEE jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06072DF2 mov r0,r1
    c.r[5] = c.r[8];  // 06072DF4 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072DFAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072DFAu) return; }  // 06072DF6 jsr @r11 ; mov r1,r4
    c.r[3] = c.r[0];  // 06072DFA mov r0,r3
    c.r[9] += 36;  // 06072DFC add #36,r9
    c.r[0] = ld32(c.r[14] + 28);  // 06072DFE mov.l @(28,r14),r0
    c.r[3] += 37;  // 06072E00 add #37,r3
    c.r[6] = ld32(c.r[0] + 16);  // 06072E02 mov.l @(16,r0),r6
    c.r[7] = ld32(0x06072FE8u);  // 06072E04 mov.l 0x06072FE8,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06072E06 mov.b @r9,r5
    c.r[1] = c.r[6];  // 06072E08 mov r6,r1
    c.r[1] += 2;  // 06072E0A add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072E0C mov.w @r1,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06072E0E extu.b r5,r5
    c.r[1] = 0x64u;  // 06072E10 mov #100,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06072E12 mulu.w r1,r2
    c.r[5] <<= 8;  // 06072E14 shll8 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06072E16 mov.b @r3,r1
    c.r[4] = c.macl;  // 06072E18 sts macl,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06072E1A extu.b r1,r1
    { const uint32_t x = c.r[7]; c.pr = 0x06072E20u; c.r[5] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E20u) return; }  // 06072E1C jsr @r7 ; or r1,r5
    c.r[7] = c.r[0];  // 06072E20 mov r0,r7
    c.r[8] = c.r[7] & 0xFFu;  // 06072E22 extu.b r7,r8
    c.r[1] = 0x63u;  // 06072E24 mov #99,r1
    c.t = c.r[8] > c.r[1];  // 06072E26 cmp/hi r1,r8
    { const bool k = c.t; c.r[0] = 0x10u; if (k) { goto L_06072EAE; } }  // 06072E28 bt/s 0x06072EAE ; mov #16,r0
    c.r[0] = ld32(0x06072FDCu);  // 06072E2C mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072E32u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E32u) return; }  // 06072E2E jsr @r0 ; mov #3,r4
    c.r[1] = 0x59u;  // 06072E32 mov #89,r1
    c.t = c.r[8] > c.r[1];  // 06072E34 cmp/hi r1,r8
    { const bool k = c.t; c.r[1] = 0x31u; if (k) { goto L_06072E86; } }  // 06072E36 bt/s 0x06072E86 ; mov #49,r1
    c.t = c.r[8] > c.r[1];  // 06072E3A cmp/hi r1,r8
    { const bool k = c.t; c.r[1] = 0x9u; if (k) { goto L_06072E70; } }  // 06072E3C bt/s 0x06072E70 ; mov #9,r1
    c.t = c.r[8] > c.r[1];  // 06072E40 cmp/hi r1,r8
    if (c.t) { goto L_06072E5A; }  // 06072E42 bt 0x06072E5A
    c.r[4] = ld32(0x06072FE0u);  // 06072E44 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072E4Au; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E4Au) return; }  // 06072E46 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072E4A mov r0,r1
    c.r[5] = 0xDu;  // 06072E4C mov #13,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072E52u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E52u) return; }  // 06072E4E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072E52 mov r0,r1
    c.r[6] = 0x0u;  // 06072E54 mov #0,r6
    c.r[5] = 0x0u; goto L_06072E9A;  // 06072E56 bra 0x06072E9A ; mov #0,r5
L_06072E5A:
    c.r[4] = ld32(0x06072FE0u);  // 06072E5A mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072E60u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E60u) return; }  // 06072E5C jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072E60 mov r0,r1
    c.r[5] = 0xDu;  // 06072E62 mov #13,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072E68u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E68u) return; }  // 06072E64 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072E68 mov r0,r1
    c.r[6] = 0x0u;  // 06072E6A mov #0,r6
    c.r[5] = 0x1u; goto L_06072E9A;  // 06072E6C bra 0x06072E9A ; mov #1,r5
L_06072E70:
    c.r[4] = ld32(0x06072FE0u);  // 06072E70 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072E76u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E76u) return; }  // 06072E72 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072E76 mov r0,r1
    c.r[5] = 0xDu;  // 06072E78 mov #13,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072E7Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E7Eu) return; }  // 06072E7A jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072E7E mov r0,r1
    c.r[6] = 0x0u;  // 06072E80 mov #0,r6
    c.r[5] = 0x2u; goto L_06072E9A;  // 06072E82 bra 0x06072E9A ; mov #2,r5
L_06072E86:
    c.r[4] = ld32(0x06072FE0u);  // 06072E86 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072E8Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E8Cu) return; }  // 06072E88 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072E8C mov r0,r1
    c.r[5] = 0xDu;  // 06072E8E mov #13,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072E94u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072E94u) return; }  // 06072E90 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072E94 mov r0,r1
    c.r[6] = 0x0u;  // 06072E96 mov #0,r6
    c.r[5] = 0x3u;  // 06072E98 mov #3,r5
L_06072E9A:
    c.r[0] = ld32(0x06072FE4u);  // 06072E9A mov.l 0x06072FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072EA0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EA0u) return; }  // 06072E9C jsr @r0 ; mov r1,r4
    c.r[0] = ld32(c.r[14] + 28);  // 06072EA0 mov.l @(28,r14),r0
    c.r[1] = ld32(c.r[0] + 16);  // 06072EA2 mov.l @(16,r0),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072EA4 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06072FD8u);  // 06072EA6 mov.w 0x06072FD8,r0
    c.r[2] &= c.r[0];  // 06072EA8 and r0,r2
    st8(c.r[1], c.r[2]); goto L_06072ED4;  // 06072EAA bra 0x06072ED4 ; mov.b r2,@r1
L_06072EAE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06072EAE mov.b @r6,r1
    c.r[4] = 0x4u;  // 06072EB0 mov #4,r4
    c.r[1] |= c.r[0];  // 06072EB2 or r0,r1
    c.r[0] = ld32(0x06072FDCu);  // 06072EB4 mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072EBAu; st8(c.r[6], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EBAu) return; }  // 06072EB6 jsr @r0 ; mov.b r1,@r6
    c.r[4] = ld32(0x06072FE0u);  // 06072EBA mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072EC0u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EC0u) return; }  // 06072EBC jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072EC0 mov r0,r1
    c.r[5] = 0xDu;  // 06072EC2 mov #13,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072EC8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EC8u) return; }  // 06072EC4 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072EC8 mov r0,r1
    c.r[6] = 0x0u;  // 06072ECA mov #0,r6
    c.r[5] = 0x4u;  // 06072ECC mov #4,r5
    c.r[0] = ld32(0x06072FE4u);  // 06072ECE mov.l 0x06072FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072ED4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072ED4u) return; }  // 06072ED0 jsr @r0 ; mov r1,r4
L_06072ED4:
    c.r[1] = ld32(c.r[13] + 4);  // 06072ED4 mov.l @(4,r13),r1
    c.r[1] += 10;  // 06072ED6 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072ED8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06072EDA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072EDC tst r1,r1
    if (c.t) { goto L_06072EFC; }  // 06072EDE bt 0x06072EFC
    c.r[0] = ld32(0x06072FDCu);  // 06072EE0 mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072EE6u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EE6u) return; }  // 06072EE2 jsr @r0 ; mov #6,r4
    c.r[4] = ld32(0x06072FE0u);  // 06072EE6 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072EECu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EECu) return; }  // 06072EE8 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072EEC mov r0,r1
    c.r[5] = 0xEu;  // 06072EEE mov #14,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072EF4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072EF4u) return; }  // 06072EF0 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072EF4 mov r0,r1
    c.r[6] = 0x0u;  // 06072EF6 mov #0,r6
    c.r[5] = 0x1u; goto L_06072F16;  // 06072EF8 bra 0x06072F16 ; mov #1,r5
L_06072EFC:
    c.r[0] = ld32(0x06072FDCu);  // 06072EFC mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072F02u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F02u) return; }  // 06072EFE jsr @r0 ; mov #2,r4
    c.r[4] = ld32(0x06072FE0u);  // 06072F02 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072F08u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F08u) return; }  // 06072F04 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072F08 mov r0,r1
    c.r[5] = 0xEu;  // 06072F0A mov #14,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072F10u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F10u) return; }  // 06072F0C jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072F10 mov r0,r1
    c.r[6] = 0x0u;  // 06072F12 mov #0,r6
    c.r[5] = 0x0u;  // 06072F14 mov #0,r5
L_06072F16:
    c.r[0] = ld32(0x06072FE4u);  // 06072F16 mov.l 0x06072FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072F1Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F1Cu) return; }  // 06072F18 jsr @r0 ; mov r1,r4
    c.r[0] = ld32(0x06072FDCu);  // 06072F1C mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072F22u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F22u) return; }  // 06072F1E jsr @r0 ; mov #2,r4
    c.r[0] = ld32(c.r[14] + 28);  // 06072F22 mov.l @(28,r14),r0
    c.r[1] = ld32(c.r[0] + 16);  // 06072F24 mov.l @(16,r0),r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072F26 mov.w @r1,r1
    c.r[0] = 0x3u;  // 06072F28 mov #3,r0
    c.r[1] >>= 2;  // 06072F2A shlr2 r1
    c.r[1] >>= 2;  // 06072F2C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06072F2E shlr r1
    c.r[1] >>= 2;  // 06072F30 shlr2 r1
    c.r[1] &= c.r[0];  // 06072F32 and r0,r1
    c.r[0] = c.r[1];  // 06072F34 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06072F36 cmp/eq #3,r0
    if (!c.t) { goto L_06072F50; }  // 06072F38 bf 0x06072F50
    c.r[4] = ld32(0x06072FE0u);  // 06072F3A mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072F40u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F40u) return; }  // 06072F3C jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072F40 mov r0,r1
    c.r[5] = 0xFu;  // 06072F42 mov #15,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072F48u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F48u) return; }  // 06072F44 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072F48 mov r0,r1
    c.r[6] = 0x2u;  // 06072F4A mov #2,r6
    c.r[5] = 0x1u; goto L_06072F64;  // 06072F4C bra 0x06072F64 ; mov #1,r5
L_06072F50:
    c.r[4] = ld32(0x06072FE0u);  // 06072F50 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072F56u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F56u) return; }  // 06072F52 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072F56 mov r0,r1
    c.r[5] = 0xFu;  // 06072F58 mov #15,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072F5Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F5Eu) return; }  // 06072F5A jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072F5E mov r0,r1
    c.r[6] = 0x2u;  // 06072F60 mov #2,r6
    c.r[5] = 0x0u;  // 06072F62 mov #0,r5
L_06072F64:
    c.r[0] = ld32(0x06072FE4u);  // 06072F64 mov.l 0x06072FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072F6Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F6Au) return; }  // 06072F66 jsr @r0 ; mov r1,r4
    c.r[0] = ld32(0x06072FDCu);  // 06072F6A mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072F70u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F70u) return; }  // 06072F6C jsr @r0 ; mov #3,r4
    c.r[0] = c.r[12];  // 06072F70 mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072F72 mov.l @(r0,r14),r1
    c.r[1] += 22;  // 06072F74 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06072F76 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06072F78 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072F7A tst r1,r1
    if (c.t) { goto L_06072F94; }  // 06072F7C bt 0x06072F94
    c.r[4] = ld32(0x06072FE0u);  // 06072F7E mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072F84u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F84u) return; }  // 06072F80 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072F84 mov r0,r1
    c.r[5] = 0x10u;  // 06072F86 mov #16,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072F8Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F8Cu) return; }  // 06072F88 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072F8C mov r0,r1
    c.r[6] = 0x3u;  // 06072F8E mov #3,r6
    c.r[5] = 0x1u; goto L_06072FA8;  // 06072F90 bra 0x06072FA8 ; mov #1,r5
L_06072F94:
    c.r[4] = ld32(0x06072FE0u);  // 06072F94 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072F9Au; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072F9Au) return; }  // 06072F96 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072F9A mov r0,r1
    c.r[5] = 0x10u;  // 06072F9C mov #16,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072FA2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FA2u) return; }  // 06072F9E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072FA2 mov r0,r1
    c.r[6] = 0x3u;  // 06072FA4 mov #3,r6
    c.r[5] = 0x0u;  // 06072FA6 mov #0,r5
L_06072FA8:
    c.r[0] = ld32(0x06072FE4u);  // 06072FA8 mov.l 0x06072FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072FAEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FAEu) return; }  // 06072FAA jsr @r0 ; mov r1,r4
    c.r[0] = ld32(0x06072FDCu);  // 06072FAE mov.l 0x06072FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06072FB4u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FB4u) return; }  // 06072FB0 jsr @r0 ; mov #3,r4
    c.r[0] = c.r[12];  // 06072FB4 mov r12,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06072FB6 mov.l @(r0,r14),r1
    c.r[1] += 26;  // 06072FB8 add #26,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06072FBA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06072FBC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06072FBE tst r1,r1
    if (c.t) { goto L_06072FEC; }  // 06072FC0 bt 0x06072FEC
    c.r[4] = ld32(0x06072FE0u);  // 06072FC2 mov.l 0x06072FE0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072FC8u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FC8u) return; }  // 06072FC4 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072FC8 mov r0,r1
    c.r[5] = 0x11u;  // 06072FCA mov #17,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072FD0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FD0u) return; }  // 06072FCC jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072FD0 mov r0,r1
    c.r[6] = 0x3u;  // 06072FD2 mov #3,r6
    c.r[5] = 0x1u; goto L_06073000;  // 06072FD4 bra 0x06073000 ; mov #1,r5
L_06072FEC:
    c.r[4] = ld32(0x060732ACu);  // 06072FEC mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06072FF2u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FF2u) return; }  // 06072FEE jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06072FF2 mov r0,r1
    c.r[5] = 0x11u;  // 06072FF4 mov #17,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06072FFAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06072FFAu) return; }  // 06072FF6 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06072FFA mov r0,r1
    c.r[6] = 0x3u;  // 06072FFC mov #3,r6
    c.r[5] = 0x0u;  // 06072FFE mov #0,r5
L_06073000:
    c.r[0] = ld32(0x060732B0u);  // 06073000 mov.l 0x060732B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073006u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073006u) return; }  // 06073002 jsr @r0 ; mov r1,r4
    c.r[0] = ld32(c.r[14] + 28);  // 06073006 mov.l @(28,r14),r0
    c.r[2] = ld32(c.r[0] + 16);  // 06073008 mov.l @(16,r0),r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607300A mov.b @r2,r1
    c.r[0] = 0x3u;  // 0607300C mov #3,r0
    c.r[1] >>= 2;  // 0607300E shlr2 r1
    c.r[1] &= c.r[0];  // 06073010 and r0,r1
    c.r[0] = c.r[1];  // 06073012 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06073014 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06073036; } }  // 06073016 bf/s 0x06073036 ; mov #3,r0
    c.r[0] = ld32(0x060732B4u);  // 0607301A mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073020u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073020u) return; }  // 0607301C jsr @r0 ; mov #4,r4
    c.r[4] = ld32(0x060732ACu);  // 06073020 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073026u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073026u) return; }  // 06073022 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06073026 mov r0,r1
    c.r[5] = 0x12u;  // 06073028 mov #18,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0607302Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607302Eu) return; }  // 0607302A jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607302E mov r0,r1
    c.r[6] = 0x0u;  // 06073030 mov #0,r6
    c.r[5] = 0x3u; goto L_060730DA;  // 06073032 bra 0x060730DA ; mov #3,r5
L_06073036:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06073036 mov.w @r2,r1
    c.r[2] = c.r[1];  // 06073038 mov r1,r2
    c.r[2] >>= 2;  // 0607303A shlr2 r2
    c.r[2] >>= 2;  // 0607303C shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607303E shlr r2
    c.r[2] >>= 2;  // 06073040 shlr2 r2
    c.r[2] &= c.r[0];  // 06073042 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06073044 tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_0607306C; } }  // 06073046 bt/s 0x0607306C ; mov r12,r0
    c.r[1] = 0x2u;  // 0607304A mov #2,r1
    c.t = c.r[2] > c.r[1];  // 0607304C cmp/hi r1,r2
    if (c.t) { goto L_0607306C; }  // 0607304E bt 0x0607306C
    c.r[0] = ld32(0x060732B4u);  // 06073050 mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073056u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073056u) return; }  // 06073052 jsr @r0 ; mov #6,r4
    c.r[4] = ld32(0x060732ACu);  // 06073056 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607305Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607305Cu) return; }  // 06073058 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 0607305C mov r0,r1
    c.r[5] = 0x12u;  // 0607305E mov #18,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073064u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073064u) return; }  // 06073060 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073064 mov r0,r1
    c.r[6] = 0x0u;  // 06073066 mov #0,r6
    c.r[5] = 0x4u; goto L_060730DA;  // 06073068 bra 0x060730DA ; mov #4,r5
L_0607306C:
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0607306C mov.l @(r0,r14),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607306E mov.b @r1,r1
    c.r[0] = 0x1Fu;  // 06073070 mov #31,r0
    c.r[1] &= c.r[0];  // 06073072 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073074 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_060730C0; } }  // 06073076 bt/s 0x060730C0 ; mov.l @(28,r14),r0
    c.r[1] = ld32(c.r[0] + 16);  // 0607307A mov.l @(16,r0),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607307C mov.b @r1,r1
    c.r[0] = 0x1u;  // 0607307E mov #1,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06073080 shlr r1
    c.r[1] &= c.r[0];  // 06073082 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073084 tst r1,r1
    if (c.t) { goto L_060730A4; }  // 06073086 bt 0x060730A4
    c.r[0] = ld32(0x060732B4u);  // 06073088 mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607308Eu; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607308Eu) return; }  // 0607308A jsr @r0 ; mov #7,r4
    c.r[4] = ld32(0x060732ACu);  // 0607308E mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073094u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073094u) return; }  // 06073090 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06073094 mov r0,r1
    c.r[5] = 0x12u;  // 06073096 mov #18,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0607309Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607309Cu) return; }  // 06073098 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607309C mov r0,r1
    c.r[6] = 0x0u;  // 0607309E mov #0,r6
    c.r[5] = 0x2u; goto L_060730DA;  // 060730A0 bra 0x060730DA ; mov #2,r5
L_060730A4:
    c.r[0] = ld32(0x060732B4u);  // 060730A4 mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060730AAu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730AAu) return; }  // 060730A6 jsr @r0 ; mov #3,r4
    c.r[4] = ld32(0x060732ACu);  // 060730AA mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060730B0u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730B0u) return; }  // 060730AC jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 060730B0 mov r0,r1
    c.r[5] = 0x12u;  // 060730B2 mov #18,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060730B8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730B8u) return; }  // 060730B4 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 060730B8 mov r0,r1
    c.r[6] = 0x0u;  // 060730BA mov #0,r6
    c.r[5] = 0x1u; goto L_060730DA;  // 060730BC bra 0x060730DA ; mov #1,r5
L_060730C0:
    c.r[0] = ld32(0x060732B4u);  // 060730C0 mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060730C6u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730C6u) return; }  // 060730C2 jsr @r0 ; mov #2,r4
    c.r[4] = ld32(0x060732ACu);  // 060730C6 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060730CCu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730CCu) return; }  // 060730C8 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 060730CC mov r0,r1
    c.r[5] = 0x12u;  // 060730CE mov #18,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060730D4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730D4u) return; }  // 060730D0 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 060730D4 mov r0,r1
    c.r[6] = 0x0u;  // 060730D6 mov #0,r6
    c.r[5] = 0x0u;  // 060730D8 mov #0,r5
L_060730DA:
    c.r[0] = ld32(0x060732B0u);  // 060730DA mov.l 0x060732B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060730E0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730E0u) return; }  // 060730DC jsr @r0 ; mov r1,r4
    c.r[1] = ld32(c.r[13] + 4);  // 060730E0 mov.l @(4,r13),r1
    c.r[1] += 10;  // 060730E2 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060730E4 mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 060730E6 extu.w r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 060730E8 tst r6,r6
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_060730F2; } }  // 060730EA bf/s 0x060730F2 ; mov #0,r5
    goto L_060732C0;  // 060730EE bra 0x060732C0 ; nop
L_060730F2:
    c.r[0] = ld32(0x060732B8u);  // 060730F2 mov.l 0x060732B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060730F8u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060730F8u) return; }  // 060730F4 jsr @r0 ; mov #8,r4
    c.r[5] = 0x0u;  // 060730F8 mov #0,r5
    c.r[1] = ld32(c.r[13] + 4);  // 060730FA mov.l @(4,r13),r1
    c.r[4] = 0x8u;  // 060730FC mov #8,r4
    c.r[1] += 6;  // 060730FE add #6,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06073100 mov.w @r1,r6
    c.r[0] = ld32(0x060732B8u);  // 06073102 mov.l 0x060732B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073108u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073108u) return; }  // 06073104 jsr @r0 ; extu.w r6,r6
    c.r[0] = ld32(c.r[14] + 28);  // 06073108 mov.l @(28,r14),r0
    c.r[1] = ld32(c.r[0] + 16);  // 0607310A mov.l @(16,r0),r1
    c.r[1] += 1;  // 0607310C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607310E mov.b @r1,r1
    c.r[0] = 0x2u;  // 06073110 mov #2,r0
    c.r[1] >>= 2;  // 06073112 shlr2 r1
    c.r[1] >>= 2;  // 06073114 shlr2 r1
    c.r[1] &= c.r[0];  // 06073116 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073118 tst r1,r1
    if (c.t) { goto L_0607314C; }  // 0607311A bt 0x0607314C
    c.r[0] = ld32(0x060732B4u);  // 0607311C mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073122u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073122u) return; }  // 0607311E jsr @r0 ; mov #4,r4
    c.r[0] = ld32(c.r[14] + 28);  // 06073122 mov.l @(28,r14),r0
    c.r[5] = 0x17u;  // 06073124 mov #23,r5
    c.r[1] = ld32(c.r[0] + 16);  // 06073126 mov.l @(16,r0),r1
    c.r[4] = ld32(0x060732ACu);  // 06073128 mov.l 0x060732AC,r4
    c.r[1] += 1;  // 0607312A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607312C mov.b @r1,r1
    c.r[0] = 0x1u;  // 0607312E mov #1,r0
    c.r[1] >>= 2;  // 06073130 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06073132 shlr r1
    c.r[1] &= c.r[0];  // 06073134 and r0,r1
    c.r[1] += 1;  // 06073136 add #1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0607313Cu; c.r[8] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607313Cu) return; }  // 06073138 jsr @r11 ; extu.b r1,r8
    c.r[1] = c.r[0];  // 0607313C mov r0,r1
    c.r[5] = 0x15u;  // 0607313E mov #21,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073144u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073144u) return; }  // 06073140 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073144 mov r0,r1
    c.r[6] = 0x0u;  // 06073146 mov #0,r6
    c.r[5] = c.r[8]; goto L_06073166;  // 06073148 bra 0x06073166 ; mov r8,r5
L_0607314C:
    c.r[0] = ld32(0x060732B4u);  // 0607314C mov.l 0x060732B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073152u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073152u) return; }  // 0607314E jsr @r0 ; mov #2,r4
    c.r[4] = ld32(0x060732ACu);  // 06073152 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073158u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073158u) return; }  // 06073154 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06073158 mov r0,r1
    c.r[5] = 0x15u;  // 0607315A mov #21,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073160u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073160u) return; }  // 0607315C jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073160 mov r0,r1
    c.r[6] = 0x0u;  // 06073162 mov #0,r6
    c.r[5] = 0x0u;  // 06073164 mov #0,r5
L_06073166:
    c.r[0] = ld32(0x060732B0u);  // 06073166 mov.l 0x060732B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607316Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607316Cu) return; }  // 06073168 jsr @r0 ; mov r1,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x060732A0u);  // 0607316C mov.w 0x060732A0,r9
    c.r[1] = ld32(c.r[13] + 4);  // 0607316E mov.l @(4,r13),r1
    c.r[8] = ld32(0x060732BCu);  // 06073170 mov.l 0x060732BC,r8
    c.r[1] += 10;  // 06073172 add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06073174 mov.w @r1,r4
    c.r[5] = c.r[9];  // 06073176 mov r9,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060732A2u);  // 06073178 mov.w 0x060732A2,r1
    c.r[4] += c.r[1];  // 0607317A add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06073180u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073180u) return; }  // 0607317C jsr @r8 ; extu.w r4,r4
    c.r[1] = ld32(c.r[13] + 4);  // 06073180 mov.l @(4,r13),r1
    c.r[1] += 6;  // 06073182 add #6,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06073184 mov.w @r1,r4
    c.r[5] = c.r[9];  // 06073186 mov r9,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060732A4u);  // 06073188 mov.w 0x060732A4,r1
    c.r[4] += c.r[1];  // 0607318A add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06073190u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073190u) return; }  // 0607318C jsr @r8 ; extu.w r4,r4
    c.r[1] = ld32(c.r[13] + 4);  // 06073190 mov.l @(4,r13),r1
    c.r[5] = 0x1Cu;  // 06073192 mov #28,r5
    c.r[1] += 6;  // 06073194 add #6,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06073196 mov.w @r1,r8
    c.r[4] = ld32(0x060732ACu);  // 06073198 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607319Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607319Eu) return; }  // 0607319A jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0607319E mov r0,r1
    c.r[5] = c.r[8];  // 060731A0 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060731A6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060731A6u) return; }  // 060731A2 jsr @r11 ; mov r1,r4
    c.r[9] = c.r[0];  // 060731A6 mov r0,r9
    c.r[1] = ld32(c.r[13] + 4);  // 060731A8 mov.l @(4,r13),r1
    c.r[5] = 0x1Cu;  // 060731AA mov #28,r5
    c.r[1] += 6;  // 060731AC add #6,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060731AE mov.w @r1,r8
    c.r[4] = ld32(0x060732ACu);  // 060731B0 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060731B6u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060731B6u) return; }  // 060731B2 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060731B6 mov r0,r1
    c.r[5] = c.r[8];  // 060731B8 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060731BEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060731BEu) return; }  // 060731BA jsr @r11 ; mov r1,r4
    c.r[3] = ld32(c.r[13] + 4);  // 060731BE mov.l @(4,r13),r3
    c.r[1] = c.r[0];  // 060731C0 mov r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060731C2 mov.b @r9,r2
    c.r[1] += 1;  // 060731C4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060731C6 mov.b @r1,r1
    c.r[3] += 8;  // 060731C8 add #8,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060731CA extu.b r2,r2
    c.r[2] <<= 8;  // 060731CC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060731CE extu.b r1,r1
    c.r[2] |= c.r[1];  // 060731D0 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060732A6u);  // 060731D2 mov.w 0x060732A6,r1
    c.r[2] &= c.r[1];  // 060731D4 and r1,r2
    st16(c.r[3], c.r[2]);  // 060731D6 mov.w r2,@r3
    c.r[1] = ld32(c.r[13] + 4);  // 060731D8 mov.l @(4,r13),r1
    c.r[5] = 0x1Du;  // 060731DA mov #29,r5
    c.r[1] += 2;  // 060731DC add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060731DE mov.w @r1,r8
    c.r[4] = ld32(0x060732ACu);  // 060731E0 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060731E6u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060731E6u) return; }  // 060731E2 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060731E6 mov r0,r1
    c.r[5] = c.r[8];  // 060731E8 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060731EEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060731EEu) return; }  // 060731EA jsr @r11 ; mov r1,r4
    c.r[6] = c.r[0];  // 060731EE mov r0,r6
    c.r[6] += 2;  // 060731F0 add #2,r6
    c.r[1] = ld32(c.r[13] + 4);  // 060731F2 mov.l @(4,r13),r1
    c.r[0] = 0x3Fu;  // 060731F4 mov #63,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060731F6 mov.b @r6,r2
    c.r[1] += 28;  // 060731F8 add #28,r1
    c.r[2] &= c.r[0];  // 060731FA and r0,r2
    st8(c.r[1], c.r[2]);  // 060731FC mov.b r2,@r1
    c.r[1] = ld32(c.r[13] + 4);  // 060731FE mov.l @(4,r13),r1
    c.r[5] = 0x1Bu;  // 06073200 mov #27,r5
    c.r[1] += 10;  // 06073202 add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06073204 mov.w @r1,r8
    c.r[4] = ld32(0x060732ACu);  // 06073206 mov.l 0x060732AC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607320Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607320Cu) return; }  // 06073208 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0607320C mov r0,r1
    c.r[5] = c.r[8];  // 0607320E mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073214u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073214u) return; }  // 06073210 jsr @r11 ; mov r1,r4
    c.r[6] = c.r[0];  // 06073214 mov r0,r6
    c.r[1] = c.r[6];  // 06073216 mov r6,r1
    c.r[1] += 6;  // 06073218 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607321A mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060732A8u);  // 0607321C mov.w 0x060732A8,r0
    c.r[2] = ld32(c.r[13] + 4);  // 0607321E mov.l @(4,r13),r2
    c.r[1] &= c.r[0];  // 06073220 and r0,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06073222 mov.b @r2,r3
    c.r[0] = 0x1Fu;  // 06073224 mov #31,r0
    c.r[3] &= c.r[0];  // 06073226 and r0,r3
    c.r[3] |= c.r[1];  // 06073228 or r1,r3
    st8(c.r[2], c.r[3]);  // 0607322A mov.b r3,@r2
    c.r[1] = c.r[6];  // 0607322C mov r6,r1
    c.r[1] += 2;  // 0607322E add #2,r1
    c.r[3] = ld32(c.r[13] + 4);  // 06073230 mov.l @(4,r13),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060732AAu);  // 06073232 mov.w 0x060732AA,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073234 mov.b @r1,r2
    c.r[3] += 12;  // 06073236 add #12,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06073238 extu.b r2,r2
    c.r[1] = c.r[6];  // 0607323A mov r6,r1
    c.r[1] += 3;  // 0607323C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607323E mov.b @r1,r1
    c.r[2] <<= 8;  // 06073240 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06073242 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06073244 or r1,r2
    st16(c.r[3], c.r[2]);  // 06073246 mov.w r2,@r3
    c.r[1] = c.r[6];  // 06073248 mov r6,r1
    c.r[1] += 10;  // 0607324A add #10,r1
    c.r[2] = ld32(c.r[13] + 4);  // 0607324C mov.l @(4,r13),r2
    c.r[3] = 0x3u;  // 0607324E mov #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073250 mov.b @r1,r1
    c.r[2] += 1;  // 06073252 add #1,r2
    c.r[3] &= c.r[1];  // 06073254 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06073256 mov.b @r2,r1
    c.r[3] <<= 2;  // 06073258 shll2 r3
    c.r[3] += c.r[3];  // 0607325A add r3,r3
    c.r[3] <<= 2;  // 0607325C shll2 r3
    c.r[1] &= c.r[0];  // 0607325E and r0,r1
    c.r[1] |= c.r[3];  // 06073260 or r3,r1
    st8(c.r[2], c.r[1]);  // 06073262 mov.b r1,@r2
    c.r[1] = c.r[6];  // 06073264 mov r6,r1
    c.r[3] = ld32(c.r[13] + 4);  // 06073266 mov.l @(4,r13),r3
    c.r[1] += 36;  // 06073268 add #36,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607326A mov.b @r1,r2
    c.r[7] = c.r[3];  // 0607326C mov r3,r7
    c.r[7] += 14;  // 0607326E add #14,r7
    c.r[3] += 16;  // 06073270 add #16,r3
    c.r[1] = c.r[6];  // 06073272 mov r6,r1
    c.r[1] += 37;  // 06073274 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073276 mov.b @r1,r1
    c.r[2] <<= 8;  // 06073278 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607327A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607327C or r1,r2
    st16(c.r[3], c.r[2]);  // 0607327E mov.w r2,@r3
    st16(c.r[7], c.r[2]);  // 06073280 mov.w r2,@r7
    c.r[1] = c.r[6];  // 06073282 mov r6,r1
    c.r[1] += 34;  // 06073284 add #34,r1
    c.r[3] = ld32(c.r[13] + 4);  // 06073286 mov.l @(4,r13),r3
    c.r[6] += 35;  // 06073288 add #35,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607328A mov.b @r1,r2
    c.r[7] = c.r[3];  // 0607328C mov r3,r7
    c.r[7] += 18;  // 0607328E add #18,r7
    c.r[3] += 20;  // 06073290 add #20,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06073292 mov.b @r6,r1
    c.r[2] <<= 8;  // 06073294 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06073296 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06073298 or r1,r2
    st16(c.r[3], c.r[2]);  // 0607329A mov.w r2,@r3
    st16(c.r[7], c.r[2]); goto L_060732E4;  // 0607329C bra 0x060732E4 ; mov.w r2,@r7
L_060732C0:
    c.r[0] = ld32(0x060733C4u);  // 060732C0 mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060732C6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060732C6u) return; }  // 060732C2 jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x060733C4u);  // 060732C6 mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060732CCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060732CCu) return; }  // 060732C8 jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x060733C4u);  // 060732CC mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060732D2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060732D2u) return; }  // 060732CE jsr @r0 ; mov #0,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x060733C0u);  // 060732D2 mov.w 0x060733C0,r8
    c.r[9] = ld32(0x060733C8u);  // 060732D4 mov.l 0x060733C8,r9
    c.r[10] = ld32(0x060733CCu);  // 060732D6 mov.l 0x060733CC,r10
    c.r[5] = c.r[8];  // 060732D8 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060732DEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060732DEu) return; }  // 060732DA jsr @r10 ; mov r9,r4
    c.r[5] = c.r[8];  // 060732DE mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060732E4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060732E4u) return; }  // 060732E0 jsr @r10 ; mov r9,r4
L_060732E4:
    c.r[0] = ld32(c.r[14] + 24);  // 060732E4 mov.l @(24,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060732E6 tst r0,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 16); if (k) { goto L_060732F0; } }  // 060732E8 bf/s 0x060732F0 ; mov.l @(16,r14),r1
    goto L_060733F8;  // 060732EC bra 0x060733F8 ; nop
L_060732F0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060732F0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060732F2 mov r1,r0
    c.r[0] >>= 2;  // 060732F4 shlr2 r0
    c.r[0] &= 0x3u;  // 060732F6 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060732F8 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_06073340; } }  // 060732FA bt/s 0x06073340 ; mov #3,r0
    c.r[0] = ld32(0x060733C4u);  // 060732FE mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073304u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073304u) return; }  // 06073300 jsr @r0 ; mov #4,r4
    c.r[1] = ld32(c.r[14] + 16);  // 06073304 mov.l @(16,r14),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073306 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06073308 mov #3,r0
    c.r[1] >>= 2;  // 0607330A shlr2 r1
    c.r[1] &= c.r[0];  // 0607330C and r0,r1
    c.r[0] = c.r[1];  // 0607330E mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06073310 cmp/eq #2,r0
    if (!c.t) { goto L_0607332A; }  // 06073312 bf 0x0607332A
    c.r[4] = ld32(0x060733D0u);  // 06073314 mov.l 0x060733D0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607331Au; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607331Au) return; }  // 06073316 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 0607331A mov r0,r1
    c.r[5] = 0x13u;  // 0607331C mov #19,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073322u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073322u) return; }  // 0607331E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073322 mov r0,r1
    c.r[6] = 0x0u;  // 06073324 mov #0,r6
    c.r[5] = 0x1u; goto L_060733F2;  // 06073326 bra 0x060733F2 ; mov #1,r5
L_0607332A:
    c.r[4] = ld32(0x060733D0u);  // 0607332A mov.l 0x060733D0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073330u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073330u) return; }  // 0607332C jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06073330 mov r0,r1
    c.r[5] = 0x13u;  // 06073332 mov #19,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073338u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073338u) return; }  // 06073334 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073338 mov r0,r1
    c.r[6] = 0x0u;  // 0607333A mov #0,r6
    c.r[5] = 0x2u; goto L_060733F2;  // 0607333C bra 0x060733F2 ; mov #2,r5
L_06073340:
    c.r[1] = ld32(0x060733D4u);  // 06073340 mov.l 0x060733D4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06073342 mov.w @r1,r1
    c.r[2] = c.r[1];  // 06073344 mov r1,r2
    c.r[2] >>= 2;  // 06073346 shlr2 r2
    c.r[2] >>= 2;  // 06073348 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607334A shlr r2
    c.r[2] >>= 2;  // 0607334C shlr2 r2
    c.r[2] &= c.r[0];  // 0607334E and r0,r2
    c.r[0] = c.r[2];  // 06073350 mov r2,r0
    c.t = c.r[0] == 0x2u;  // 06073352 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06073388; } }  // 06073354 bt/s 0x06073388 ; mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06073358 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06073366; } }  // 0607335A bt/s 0x06073366 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 0607335E cmp/eq #1,r0
    if (!c.t) { goto L_060733D8; }  // 06073360 bf 0x060733D8
    goto L_0607336C;  // 06073362 bra 0x0607336C ; nop
L_06073366:
    if (!c.t) { goto L_060733D8; }  // 06073366 bf 0x060733D8
    goto L_060733A4;  // 06073368 bra 0x060733A4 ; nop
L_0607336C:
    c.r[0] = ld32(0x060733C4u);  // 0607336C mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073372u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073372u) return; }  // 0607336E jsr @r0 ; mov #6,r4
    c.r[4] = ld32(0x060733D0u);  // 06073372 mov.l 0x060733D0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073378u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073378u) return; }  // 06073374 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06073378 mov r0,r1
    c.r[5] = 0x13u;  // 0607337A mov #19,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073380u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073380u) return; }  // 0607337C jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073380 mov r0,r1
    c.r[6] = 0x0u;  // 06073382 mov #0,r6
    c.r[5] = 0x4u; goto L_060733F2;  // 06073384 bra 0x060733F2 ; mov #4,r5
L_06073388:
    c.r[0] = ld32(0x060733C4u);  // 06073388 mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607338Eu; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607338Eu) return; }  // 0607338A jsr @r0 ; mov #7,r4
    c.r[4] = ld32(0x060733D0u);  // 0607338E mov.l 0x060733D0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073394u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073394u) return; }  // 06073390 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 06073394 mov r0,r1
    c.r[5] = 0x13u;  // 06073396 mov #19,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0607339Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607339Cu) return; }  // 06073398 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607339C mov r0,r1
    c.r[6] = 0x0u;  // 0607339E mov #0,r6
    c.r[5] = 0x5u; goto L_060733F2;  // 060733A0 bra 0x060733F2 ; mov #5,r5
L_060733A4:
    c.r[0] = ld32(0x060733C4u);  // 060733A4 mov.l 0x060733C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060733AAu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733AAu) return; }  // 060733A6 jsr @r0 ; mov #6,r4
    c.r[4] = ld32(0x060733D0u);  // 060733AA mov.l 0x060733D0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060733B0u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733B0u) return; }  // 060733AC jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 060733B0 mov r0,r1
    c.r[5] = 0x13u;  // 060733B2 mov #19,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060733B8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733B8u) return; }  // 060733B4 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 060733B8 mov r0,r1
    c.r[6] = 0x0u;  // 060733BA mov #0,r6
    c.r[5] = 0x6u; goto L_060733F2;  // 060733BC bra 0x060733F2 ; mov #6,r5
L_060733D8:
    c.r[0] = ld32(0x06073434u);  // 060733D8 mov.l 0x06073434,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060733DEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733DEu) return; }  // 060733DA jsr @r0 ; mov #6,r4
    c.r[4] = ld32(0x06073438u);  // 060733DE mov.l 0x06073438,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060733E4u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733E4u) return; }  // 060733E0 jsr @r11 ; mov #23,r5
    c.r[1] = c.r[0];  // 060733E4 mov r0,r1
    c.r[5] = 0x13u;  // 060733E6 mov #19,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060733ECu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733ECu) return; }  // 060733E8 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 060733EC mov r0,r1
    c.r[6] = 0x0u;  // 060733EE mov #0,r6
    c.r[5] = 0x3u;  // 060733F0 mov #3,r5
L_060733F2:
    c.r[0] = ld32(0x0607343Cu);  // 060733F2 mov.l 0x0607343C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060733F8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060733F8u) return; }  // 060733F4 jsr @r0 ; mov r1,r4
L_060733F8:
    c.r[13] += 8;  // 060733F8 add #8,r13
    c.r[0] = ld32(c.r[14] + 28);  // 060733FA mov.l @(28,r14),r0
    c.r[12] += 8;  // 060733FC add #8,r12
    c.r[0] += 4;  // 060733FE add #4,r0
    st32(c.r[14] + 28, c.r[0]);  // 06073400 mov.l r0,@(28,r14)
    c.r[0] = ld32(c.r[14] + 24);  // 06073402 mov.l @(24,r14),r0
    c.r[1] = 0x1u;  // 06073404 mov #1,r1
    c.r[0] += 1;  // 06073406 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06073408 cmp/gt r1,r0
    { const bool k = c.t; st32(c.r[14] + 24, c.r[0]); if (k) { goto L_06073412; } }  // 0607340A bt/s 0x06073412 ; mov.l r0,@(24,r14)
    SH2_POLL(c); goto L_06072A8C;  // 0607340E bra 0x06072A8C ; nop
L_06073412:
    c.r[1] = ld32(0x06073440u);  // 06073412 mov.l 0x06073440,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073418u; c.r[4] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073418u) return; }  // 06073414 jsr @r1 ; mov #38,r4
    c.r[14] += 32;  // 06073418 add #32,r14
    c.r[15] = c.r[14];  // 0607341A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607341C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607341E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06073420 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06073422 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06073424 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06073426 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06073428 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073430u);  // 0607342A mov.w 0x06073430,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607342C rts ; mov.l @r15+,r8
}

void f_06073444(SH2Context& c) {
    ran[1602] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06073444 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06073446 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06073448 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607344A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607344C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607344E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06073450 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06073452 mov r15,r14
    c.r[1] = ld32(0x06073560u);  // 06073454 mov.l 0x06073560,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607345Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607345Au) return; }  // 06073456 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06073564u);  // 0607345A mov.l 0x06073564,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073460u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073460u) return; }  // 0607345C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06073568u);  // 06073460 mov.l 0x06073568,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073466u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073466u) return; }  // 06073462 jsr @r1 ; nop
    c.r[8] = ld32(0x0607356Cu);  // 06073466 mov.l 0x0607356C,r8
    c.r[2] = 0x1u;  // 06073468 mov #1,r2
    c.r[11] = ld32(0x06073570u);  // 0607346A mov.l 0x06073570,r11
    c.r[9] = ld32(0x06073574u);  // 0607346C mov.l 0x06073574,r9
    c.r[1] = ld32(c.r[8]);  // 0607346E mov.l @r8,r1
    c.r[5] = 0x17u;  // 06073470 mov #23,r5
    c.r[1] += 8;  // 06073472 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073474 mov.b @r1,r1
    c.r[4] = c.r[11];  // 06073476 mov r11,r4
    c.r[12] = c.r[1];  // 06073478 mov r1,r12
    c.r[12] >>= 2;  // 0607347A shlr2 r12
    { const uint32_t x = c.r[9]; c.pr = 0x06073480u; c.r[12] &= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073480u) return; }  // 0607347C jsr @r9 ; and r2,r12
    c.r[5] = 0x16u;  // 06073480 mov #22,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073486u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073486u) return; }  // 06073482 jsr @r9 ; mov r0,r4
    c.r[10] = ld32(0x06073578u);  // 06073486 mov.l 0x06073578,r10
    c.r[6] = 0x3u;  // 06073488 mov #3,r6
    c.r[5] = c.r[12];  // 0607348A mov r12,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06073490u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073490u) return; }  // 0607348C jsr @r10 ; mov r0,r4
    c.r[0] = ld32(0x0607357Cu);  // 06073490 mov.l 0x0607357C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073496u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073496u) return; }  // 06073492 jsr @r0 ; nop
    c.r[0] = c.r[0] & 0xFFu;  // 06073496 extu.b r0,r0
    c.t = c.r[0] == 0x1u;  // 06073498 cmp/eq #1,r0
    c.r[12] = c.t;  // 0607349A movt r12
    c.r[0] = ld32(0x060734A4u);  // 0607349C mov.l 0x060734A4,r0
    c.r[4] = c.r[0]; goto L_060734A8;  // 0607349E bra 0x060734A8 ; mov r0,r4
L_060734A8:
    c.r[6] = 0x8u;  // 060734A8 mov #8,r6
    c.r[5] = c.r[12];  // 060734AA mov r12,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060734B0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734B0u) return; }  // 060734AC jsr @r10 ; mov r0,r4
    c.r[12] = 0x1u;  // 060734B0 mov #1,r12
    c.r[1] = ld32(c.r[8]);  // 060734B2 mov.l @r8,r1
    c.r[5] = 0x17u;  // 060734B4 mov #23,r5
    c.r[1] += 8;  // 060734B6 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060734B8 mov.b @r1,r0
    c.r[4] = c.r[11];  // 060734BA mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060734C0u; c.r[12] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734C0u) return; }  // 060734BC jsr @r9 ; and r0,r12
    c.r[5] = 0x16u;  // 060734C0 mov #22,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060734C6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734C6u) return; }  // 060734C2 jsr @r9 ; mov r0,r4
    c.r[6] = 0x3u;  // 060734C6 mov #3,r6
    c.r[5] = c.r[12];  // 060734C8 mov r12,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060734CEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734CEu) return; }  // 060734CA jsr @r10 ; mov r0,r4
    c.r[1] = ld32(c.r[8]);  // 060734CE mov.l @r8,r1
    c.r[5] = 0x17u;  // 060734D0 mov #23,r5
    c.r[1] += 9;  // 060734D2 add #9,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060734D4 mov.b @r1,r8
    c.r[4] = c.r[11];  // 060734D6 mov r11,r4
    c.r[8] = c.r[8] & 0xFFu;  // 060734D8 extu.b r8,r8
    c.r[8] >>= 2;  // 060734DA shlr2 r8
    c.r[8] >>= 2;  // 060734DC shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060734DE shlr r8
    { const uint32_t x = c.r[9]; c.pr = 0x060734E4u; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734E4u) return; }  // 060734E0 jsr @r9 ; shlr2 r8
    c.r[5] = 0x18u;  // 060734E4 mov #24,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060734EAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734EAu) return; }  // 060734E6 jsr @r9 ; mov r0,r4
    c.r[6] = 0x6u;  // 060734EA mov #6,r6
    c.r[5] = c.r[8];  // 060734EC mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060734F2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060734F2u) return; }  // 060734EE jsr @r10 ; mov r0,r4
    c.r[8] = 0x0u;  // 060734F2 mov #0,r8
    c.r[0] = c.r[8];  // 060734F4 mov r8,r0
L_060734F6:
    c.t = c.r[0] >> 31; c.r[0] = c.r[0] << 1 | c.t;  // 060734F6 rotl r0
    c.r[0] = c.t;  // 060734F8 movt r0
    c.r[0] += c.r[8];  // 060734FA add r8,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060734FC shar r0
    c.r[1] = ld32(0x06073580u);  // 060734FE mov.l 0x06073580,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073500 mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 06073502 extu.b r1,r0
    c.r[1] = 0x1u;  // 06073504 mov #1,r1
    c.r[1] &= c.r[8];  // 06073506 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073508 tst r1,r1
    if (c.t) { goto L_06073512; }  // 0607350A bt 0x06073512
    c.r[0] &= 0xF0u;  // 0607350C and #240,r0
    c.r[1] = 0x1u; goto L_06073516;  // 0607350E bra 0x06073516 ; mov #1,r1
L_06073512:
    c.r[0] &= 0xFu;  // 06073512 and #15,r0
    c.r[1] = 0x1u;  // 06073514 mov #1,r1
L_06073516:
    c.r[1] &= c.r[8];  // 06073516 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073518 tst r1,r1
    { const bool k = c.t; c.r[11] = c.r[0]; if (k) { goto L_06073524; } }  // 0607351A bt/s 0x06073524 ; mov r0,r11
    c.r[11] >>= 2;  // 0607351E shlr2 r11
    c.r[11] >>= 2; goto L_06073526;  // 06073520 bra 0x06073526 ; shlr2 r11
L_06073524:
    c.r[11] = c.r[0] & 0xFFu;  // 06073524 extu.b r0,r11
L_06073526:
    c.r[4] = ld32(0x06073570u);  // 06073526 mov.l 0x06073570,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0607352Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607352Cu) return; }  // 06073528 jsr @r9 ; mov #23,r5
    c.r[5] = 0x19u;  // 0607352C mov #25,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073532u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073532u) return; }  // 0607352E jsr @r9 ; mov r0,r4
    c.r[6] = 0x6u;  // 06073532 mov #6,r6
    c.r[5] = c.r[11];  // 06073534 mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607353Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607353Au) return; }  // 06073536 jsr @r10 ; mov r0,r4
    c.r[8] += 1;  // 0607353A add #1,r8
    c.r[1] = 0x6u;  // 0607353C mov #6,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0607353E cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_060734F6; } }  // 06073540 bf/s 0x060734F6 ; mov r8,r0
    c.r[1] = ld32(0x06073584u);  // 06073544 mov.l 0x06073584,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607354Au; c.r[4] = 0x27u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607354Au) return; }  // 06073546 jsr @r1 ; mov #39,r4
    c.r[15] = c.r[14];  // 0607354A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607354C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607354E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06073550 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06073552 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06073554 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06073556 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607355Eu);  // 06073558 mov.w 0x0607355E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607355A rts ; mov.l @r15+,r8
}

void f_06073588(SH2Context& c) {
    ran[1603] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06073588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607358A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607358C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607358E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06073590 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06073592 mov r15,r14
    c.r[1] = ld32(0x060736B0u);  // 06073594 mov.l 0x060736B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607359Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607359Au) return; }  // 06073596 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060736B4u);  // 0607359A mov.l 0x060736B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060735A0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060735A0u) return; }  // 0607359C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060736B8u);  // 060735A0 mov.l 0x060736B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060735A6u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060735A6u) return; }  // 060735A2 jsr @r1 ; mov #0,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x060736A4u);  // 060735A6 mov.w 0x060736A4,r4
    c.r[10] = ld32(0x060736BCu);  // 060735A8 mov.l 0x060736BC,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x060736A6u);  // 060735AA mov.w 0x060736A6,r9
    c.r[7] = 0xAu;  // 060735AC mov #10,r7
    c.r[1] = ld32(c.r[10]);  // 060735AE mov.l @r10,r1
    c.r[6] = 0x8u;  // 060735B0 mov #8,r6
    c.r[0] = c.r[1];  // 060735B2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060735B4 mov.b @(r0,r9),r1
    c.r[1] += c.r[1];  // 060735B6 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060735B8 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060735BA mov.l r1,@-r15
    c.r[1] = ld32(0x060736C0u);  // 060735BC mov.l 0x060736C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060735C2u; c.r[5] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060735C2u) return; }  // 060735BE jsr @r1 ; mov #14,r5
    c.r[1] = ld32(c.r[10]);  // 060735C2 mov.l @r10,r1
    c.r[0] = c.r[1];  // 060735C4 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060735C6 mov.b @(r0,r9),r4
    c.r[1] = ld32(0x060736C4u);  // 060735C8 mov.l 0x060736C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060735CEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060735CEu) return; }  // 060735CA jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(c.r[10]);  // 060735CE mov.l @r10,r1
    c.r[0] = c.r[1];  // 060735D0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060735D2 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060735D4 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060735D6 cmp/ge r1,r8
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0607361E; } }  // 060735D8 bt/s 0x0607361E ; add #4,r15
    c.r[9] = c.r[10];  // 060735DC mov r10,r9
    c.r[10] = ld32(0x060736C8u);  // 060735DE mov.l 0x060736C8,r10
L_060735E0:
    c.r[1] = ld32(0x060736CCu);  // 060735E0 mov.l 0x060736CC,r1
    c.r[3] = c.r[8];  // 060735E2 mov r8,r3
    c.r[2] = ld32(c.r[1]);  // 060735E4 mov.l @r1,r2
    c.r[3] += c.r[3];  // 060735E6 add r3,r3
    c.r[1] = ld32(c.r[9]);  // 060735E8 mov.l @r9,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060736A4u);  // 060735EA mov.w 0x060736A4,r5
    c.r[0] = c.r[1];  // 060735EC mov r1,r0
    c.r[1] += c.r[3];  // 060735EE add r3,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060735F0 mov.b @(r0,r3),r7
    c.r[1] += 1;  // 060735F2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060735F4 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 060735F6 mov #127,r0
    c.r[7] &= c.r[0];  // 060735F8 and r0,r7
    c.r[7] <<= 8;  // 060735FA shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 060735FC extu.b r1,r1
    c.r[1] |= c.r[7];  // 060735FE or r7,r1
    c.r[2] += c.r[1];  // 06073600 add r1,r2
    c.r[2] += 16;  // 06073602 add #16,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06073604 mov.b @r2,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060736A8u);  // 06073606 mov.w 0x060736A8,r1
    c.r[4] = c.r[4] & 0xFFu;  // 06073608 extu.b r4,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607360Eu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607360Eu) return; }  // 0607360A jsr @r10 ; or r1,r4
    c.r[1] = ld32(c.r[9]);  // 0607360E mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060736A6u);  // 06073610 mov.w 0x060736A6,r2
    c.r[0] = c.r[1];  // 06073612 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06073614 mov.b @(r0,r2),r1
    c.r[8] += 1;  // 06073616 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06073618 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607361A cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_060735E0; }  // 0607361C bf 0x060735E0
L_0607361E:
    c.r[1] = ld32(0x060736CCu);  // 0607361E mov.l 0x060736CC,r1
    c.r[3] = ld32(c.r[1]);  // 06073620 mov.l @r1,r3
    c.r[1] = ld32(0x060736D0u);  // 06073622 mov.l 0x060736D0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073624 mov.b @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060736A4u);  // 06073626 mov.w 0x060736A4,r5
    c.r[7] = c.r[1] & 0xFFu;  // 06073628 extu.b r1,r7
    c.r[1] = ld32(0x060736D4u);  // 0607362A mov.l 0x060736D4,r1
    c.r[0] = c.r[7];  // 0607362C mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607362E mov.b @(r0,r1),r1
    c.r[8] = ld32(0x060736BCu);  // 06073630 mov.l 0x060736BC,r8
    c.r[2] = ld32(c.r[8]);  // 06073632 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06073634 extu.b r1,r1
    c.r[1] += c.r[1];  // 06073636 add r1,r1
    c.r[0] = c.r[2];  // 06073638 mov r2,r0
    c.r[2] += c.r[1];  // 0607363A add r1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607363C mov.b @(r0,r1),r7
    c.r[2] += 1;  // 0607363E add #1,r2
    c.r[0] = 0x7Fu;  // 06073640 mov #127,r0
    c.r[7] &= c.r[0];  // 06073642 and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06073644 mov.b @r2,r1
    c.r[7] <<= 8;  // 06073646 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06073648 extu.b r1,r1
    c.r[1] |= c.r[7];  // 0607364A or r7,r1
    c.r[3] += c.r[1];  // 0607364C add r1,r3
    c.r[3] += 16;  // 0607364E add #16,r3
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06073650 mov.b @r3,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060736AAu);  // 06073652 mov.w 0x060736AA,r1
    c.r[4] = c.r[4] & 0xFFu;  // 06073654 extu.b r4,r4
    c.r[4] += c.r[1];  // 06073656 add r1,r4
    c.r[1] = ld32(0x060736C8u);  // 06073658 mov.l 0x060736C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607365Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607365Eu) return; }  // 0607365A jsr @r1 ; extu.w r4,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x060736A6u);  // 0607365E mov.w 0x060736A6,r2
    c.r[7] = 0x2u;  // 06073660 mov #2,r7
    c.r[6] = 0xAu;  // 06073662 mov #10,r6
    c.r[1] = ld32(c.r[8]);  // 06073664 mov.l @r8,r1
    c.r[5] = 0x9u;  // 06073666 mov #9,r5
    c.r[0] = c.r[1];  // 06073668 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607366A mov.b @(r0,r2),r3
    c.r[4] = 0xFu;  // 0607366C mov #15,r4
    c.r[3] = c.r[3] & 0xFFu;  // 0607366E extu.b r3,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06073670 mov.l r3,@-r15
    c.r[2] = 0x1u;  // 06073672 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06073674 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06073676 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06073678 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607367A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607367C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607367E mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06073680 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06073682 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06073684 mov.l r3,@-r15
    c.r[1] = ld32(0x060736D8u);  // 06073686 mov.l 0x060736D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607368Cu; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607368Cu) return; }  // 06073688 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 0607368C add #40,r15
    c.r[1] = ld32(0x060736DCu);  // 0607368E mov.l 0x060736DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073694u; c.r[4] = 0x28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073694u) return; }  // 06073690 jsr @r1 ; mov #40,r4
    c.r[15] = c.r[14];  // 06073694 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06073696 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06073698 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607369A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607369C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060736ACu);  // 0607369E mov.w 0x060736AC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060736A0 rts ; mov.l @r15+,r8
}

void f_060736E0(SH2Context& c) {
    ran[1604] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060736E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060736E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060736E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060736E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060736E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060736EA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060736EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060736EE sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060737C4u);  // 060736F0 mov.w 0x060737C4,r3
    c.r[15] += c.r[3];  // 060736F2 add r3,r15
    c.r[14] = c.r[15];  // 060736F4 mov r15,r14
    c.r[1] = ld32(0x060737D4u);  // 060736F6 mov.l 0x060737D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060736FCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060736FCu) return; }  // 060736F8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060737D8u);  // 060736FC mov.l 0x060737D8,r1
    c.r[1] = ld32(c.r[1]);  // 060736FE mov.l @r1,r1
    c.r[1] += 1;  // 06073700 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073702 mov.b @r1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 06073704 extu.b r1,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06073706 tst r13,r13
    { const bool k = !c.t; c.r[11] = c.r[14]; if (k) { goto L_06073804; } }  // 06073708 bf/s 0x06073804 ; mov r14,r11
    c.r[8] = ld32(0x060737DCu);  // 0607370C mov.l 0x060737DC,r8
    c.r[2] = c.r[8];  // 0607370E mov r8,r2
    c.r[2] += 88;  // 06073710 add #88,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x060737C6u);  // 06073712 mov.w 0x060737C6,r12
    c.r[11] += c.r[12];  // 06073714 add r12,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x060737C8u);  // 06073716 mov.w 0x060737C8,r0
    c.r[0] += c.r[14];  // 06073718 add r14,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060737CAu);  // 0607371A mov.w 0x060737CA,r3
    c.r[10] = c.r[14];  // 0607371C mov r14,r10
    c.r[10] += c.r[3];  // 0607371E add r3,r10
    c.r[9] = ld32(0x060737E0u);  // 06073720 mov.l 0x060737E0,r9
    c.r[7] = ld32(0x060737E4u);  // 06073722 mov.l 0x060737E4,r7
    c.r[6] = 0x1u;  // 06073724 mov #1,r6
    c.r[5] = 0xFFFFFFFFu;  // 06073726 mov #-1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06073728 mov.w @r2,r1
    c.r[4] = 0x11u;  // 0607372A mov #17,r4
    st32(c.r[0], c.r[11]);  // 0607372C mov.l r11,@r0
    c.r[0] = c.r[14];  // 0607372E mov r14,r0
    st16(c.r[0] + c.r[12], c.r[1]);  // 06073730 mov.w r1,@(r0,r12)
    c.r[1] = 0x30u;  // 06073732 mov #48,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06073734 mov.b r1,@(r0,r3)
    c.r[11] = ld32(0x060737E8u);  // 06073736 mov.l 0x060737E8,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06073738 mov.w @r2,r1
    c.r[0] = ld32(0x060737ECu);  // 0607373A mov.l 0x060737EC,r0
    st16(c.r[9], c.r[1]);  // 0607373C mov.w r1,@r9
    { const uint32_t x = c.r[0]; c.pr = 0x06073742u; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073742u) return; }  // 0607373E jsr @r0 ; mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06073742 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06073744 mov.l r14,@-r15
    c.r[0] = c.r[14];  // 06073746 mov r14,r0
    c.r[1] = 0xAu;  // 06073748 mov #10,r1
    c.r[7] = c.r[10];  // 0607374A mov r10,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 0607374C mov.w @(r0,r12),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060737C8u);  // 0607374E mov.w 0x060737C8,r11
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06073750 mulu.w r1,r2
    c.r[11] += c.r[14];  // 06073752 add r14,r11
    c.r[2] = ld32(c.r[8] + 8);  // 06073754 mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 06073756 sts macl,r1
    c.r[2] += c.r[1];  // 06073758 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607375A mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0607375C mov.l @(4,r8),r1
    c.r[5] = ld32(0x060737E8u);  // 0607375E mov.l 0x060737E8,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06073760 mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 06073762 mov.l @r8,r1
    c.r[4] = ld32(0x060737E4u);  // 06073764 mov.l 0x060737E4,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06073766 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06073768 mov.l r13,@-r15
    c.r[1] = 0x1u;  // 0607376A mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607376C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607376E mov.l r13,@-r15
    c.r[0] = ld32(0x060737F0u);  // 06073770 mov.l 0x060737F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073776u; c.r[6] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073776u) return; }  // 06073772 jsr @r0 ; mov.l @r11,r6
    c.r[2] = ld32(0x060737F4u);  // 06073776 mov.l 0x060737F4,r2
    c.r[15] += 36;  // 06073778 add #36,r15
    c.r[6] = (uint32_t)(int16_t)ld16(0x060737CCu);  // 0607377A mov.w 0x060737CC,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0607377C mov.w @r9,r1
    c.r[5] = 0x3u;  // 0607377E mov #3,r5
    c.r[7] = ld32(c.r[8] + 12);  // 06073780 mov.l @(12,r8),r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 06073782 extu.w r1,r1
    c.r[3] = c.r[1];  // 06073784 mov r1,r3
    c.r[3] += c.r[3];  // 06073786 add r3,r3
    c.r[3] += c.r[1];  // 06073788 add r1,r3
    c.r[3] <<= 2;  // 0607378A shll2 r3
    c.r[0] = c.r[3];  // 0607378C mov r3,r0
    st32(c.r[0] + c.r[7], c.r[2]);  // 0607378E mov.l r2,@(r0,r7)
    c.r[1] = ld32(c.r[8] + 12);  // 06073790 mov.l @(12,r8),r1
    c.r[4] = 0x0u;  // 06073792 mov #0,r4
    c.r[3] += c.r[1];  // 06073794 add r1,r3
    st32(c.r[3] + 4, c.r[2]);  // 06073796 mov.l r2,@(4,r3)
    c.r[2] = ld32(0x060737F8u);  // 06073798 mov.l 0x060737F8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060737CEu);  // 0607379A mov.w 0x060737CE,r1
    c.r[0] = c.r[2];  // 0607379C mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607379E mov.w @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060737D0u);  // 060737A0 mov.w 0x060737D0,r3
    c.r[1] += 1;  // 060737A2 add #1,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 060737A4 mov.w r1,@(r0,r3)
    c.r[1] = ld32(0x060737FCu);  // 060737A6 mov.l 0x060737FC,r1
    c.r[1] = ld32(c.r[1]);  // 060737A8 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060737D2u);  // 060737AA mov.w 0x060737D2,r2
    c.r[0] = c.r[1];  // 060737AC mov r1,r0
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060737AE mov.w @(r0,r2),r7
    c.r[11] = ld32(0x06073800u);  // 060737B0 mov.l 0x06073800,r11
    c.r[7] = c.r[7] & 0xFFFFu;  // 060737B2 extu.w r7,r7
    c.r[7] >>= 2;  // 060737B4 shlr2 r7
    c.r[7] >>= 2;  // 060737B6 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060737B8 shlr r7
    c.r[7] >>= 2;  // 060737BA shlr2 r7
    { const uint32_t x = c.r[11]; c.pr = 0x060737C0u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060737C0u) return; }  // 060737BC jsr @r11 ; mov.l r13,@-r15
    c.r[15] += 4; goto L_06073816;  // 060737C0 bra 0x06073816 ; add #4,r15
L_06073804:
    c.r[1] = ld32(0x06073994u);  // 06073804 mov.l 0x06073994,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607397Eu);  // 06073806 mov.w 0x0607397E,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06073808 mov.w @(r0,r1),r2
    c.r[2] += 1;  // 0607380A add #1,r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 0607380C mov.w r2,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073980u);  // 0607380E mov.w 0x06073980,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06073810 mov.w @(r0,r1),r2
    c.r[2] += 1;  // 06073812 add #1,r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 06073814 mov.w r2,@(r0,r1)
L_06073816:
    c.r[1] = ld32(0x06073998u);  // 06073816 mov.l 0x06073998,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607381Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607381Cu) return; }  // 06073818 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607399Cu);  // 0607381C mov.l 0x0607399C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073822u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073822u) return; }  // 0607381E jsr @r1 ; nop
    c.r[8] = ld32(0x060739A0u);  // 06073822 mov.l 0x060739A0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073982u);  // 06073824 mov.w 0x06073982,r1
    c.r[12] = ld32(0x060739A4u);  // 06073826 mov.l 0x060739A4,r12
    c.r[6] = 0x0u;  // 06073828 mov #0,r6
    c.r[5] = ld32(c.r[8]);  // 0607382A mov.l @r8,r5
    c.r[4] = 0x0u;  // 0607382C mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06073832u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073832u) return; }  // 0607382E jsr @r12 ; add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073984u);  // 06073832 mov.w 0x06073984,r1
    c.r[6] = 0x0u;  // 06073834 mov #0,r6
    c.r[5] = ld32(c.r[8]);  // 06073836 mov.l @r8,r5
    c.r[4] = 0x0u;  // 06073838 mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0607383Eu; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607383Eu) return; }  // 0607383A jsr @r12 ; add r1,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x06073986u);  // 0607383E mov.w 0x06073986,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073988u);  // 06073840 mov.w 0x06073988,r0
    c.r[0] += c.r[14];  // 06073842 add r14,r0
    c.r[1] = ld32(c.r[8]);  // 06073844 mov.l @r8,r1
    c.r[9] = ld32(0x060739A8u);  // 06073846 mov.l 0x060739A8,r9
    st32(c.r[0], c.r[11]);  // 06073848 mov.l r11,@r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06073988u);  // 0607384A mov.w 0x06073988,r11
    c.r[11] += c.r[14];  // 0607384C add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0607384E mov.l @r11,r0
    c.r[5] = 0x17u;  // 06073850 mov #23,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073852 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060739ACu);  // 06073854 mov.l 0x060739AC,r4
    c.r[10] = c.r[1];  // 06073856 mov r1,r10
    c.r[10] >>= 2;  // 06073858 shlr2 r10
    c.r[10] >>= 2;  // 0607385A shlr2 r10
    c.r[10] >>= 2;  // 0607385C shlr2 r10
    c.r[0] = 0x1u;  // 0607385E mov #1,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06073864u; c.r[10] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073864u) return; }  // 06073860 jsr @r9 ; and r0,r10
    c.r[1] = c.r[0];  // 06073864 mov r0,r1
    c.r[5] = 0x1Bu;  // 06073866 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607386Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607386Cu) return; }  // 06073868 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607386C mov r0,r1
    c.r[6] = 0x2u;  // 0607386E mov #2,r6
    c.r[5] = c.r[10];  // 06073870 mov r10,r5
    c.r[11] = ld32(0x060739B0u);  // 06073872 mov.l 0x060739B0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06073878u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073878u) return; }  // 06073874 jsr @r11 ; mov r1,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x06073988u);  // 06073878 mov.w 0x06073988,r11
    c.r[11] += c.r[14];  // 0607387A add r14,r11
    c.r[1] = ld32(c.r[8]);  // 0607387C mov.l @r8,r1
    c.r[10] = ld32(0x060739B4u);  // 0607387E mov.l 0x060739B4,r10
    c.r[0] = ld32(c.r[11]);  // 06073880 mov.l @r11,r0
    c.r[5] = 0x0u;  // 06073882 mov #0,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073884 mov.b @(r0,r1),r1
    c.r[4] = 0x0u;  // 06073886 mov #0,r4
    c.r[1] >>= 2;  // 06073888 shlr2 r1
    c.r[0] = 0xFu;  // 0607388A mov #15,r0
    c.r[1] &= c.r[0];  // 0607388C and r0,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06073892u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073892u) return; }  // 0607388E jsr @r10 ; mov r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607398Au);  // 06073892 mov.w 0x0607398A,r2
    c.r[11] = 0x1Fu;  // 06073894 mov #31,r11
    c.r[1] = ld32(c.r[8]);  // 06073896 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06073898 mov #0,r5
    c.r[0] = c.r[1];  // 0607389A mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0607389C mov.l @(r0,r2),r1
    c.r[4] = 0x0u;  // 0607389E mov #0,r4
    c.r[1] >>= 8;  // 060738A0 shlr8 r1
    c.r[1] >>= 2;  // 060738A2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060738A4 shlr r1
    c.r[1] >>= 2;  // 060738A6 shlr2 r1
    c.r[1] &= c.r[11];  // 060738A8 and r11,r1
    { const uint32_t x = c.r[10]; c.pr = 0x060738AEu; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738AEu) return; }  // 060738AA jsr @r10 ; mov r1,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607398Cu);  // 060738AE mov.w 0x0607398C,r13
    c.r[11] = 0x3u;  // 060738B0 mov #3,r11
    c.r[1] = ld32(c.r[8]);  // 060738B2 mov.l @r8,r1
    c.r[5] = 0x17u;  // 060738B4 mov #23,r5
    c.r[0] = c.r[1];  // 060738B6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060738B8 mov.b @(r0,r13),r1
    c.r[4] = ld32(0x060739ACu);  // 060738BA mov.l 0x060739AC,r4
    c.r[10] = c.r[1];  // 060738BC mov r1,r10
    c.r[10] >>= 2;  // 060738BE shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060738C0 shlr r10
    { const uint32_t x = c.r[9]; c.pr = 0x060738C6u; c.r[10] &= c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738C6u) return; }  // 060738C2 jsr @r9 ; and r11,r10
    c.r[1] = c.r[0];  // 060738C6 mov r0,r1
    c.r[5] = 0x1Au;  // 060738C8 mov #26,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060738CEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738CEu) return; }  // 060738CA jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060738CE mov r0,r1
    c.r[6] = 0x2u;  // 060738D0 mov #2,r6
    c.r[5] = c.r[10];  // 060738D2 mov r10,r5
    c.r[0] = ld32(0x060739B0u);  // 060738D4 mov.l 0x060739B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060738DAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738DAu) return; }  // 060738D6 jsr @r0 ; mov r1,r4
    c.r[1] = ld32(c.r[8]);  // 060738DA mov.l @r8,r1
    c.r[5] = 0x17u;  // 060738DC mov #23,r5
    c.r[0] = c.r[1];  // 060738DE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060738E0 mov.b @(r0,r13),r1
    c.r[4] = ld32(0x060739ACu);  // 060738E2 mov.l 0x060739AC,r4
    c.r[10] = c.r[1];  // 060738E4 mov r1,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060738E6 shlr r10
    { const uint32_t x = c.r[9]; c.pr = 0x060738ECu; c.r[10] &= c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738ECu) return; }  // 060738E8 jsr @r9 ; and r11,r10
    c.r[1] = c.r[0];  // 060738EC mov r0,r1
    c.r[5] = 0x1Cu;  // 060738EE mov #28,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060738F4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738F4u) return; }  // 060738F0 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060738F4 mov r0,r1
    c.r[5] = c.r[10];  // 060738F6 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060738FCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060738FCu) return; }  // 060738F8 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060738FC mov r0,r1
    c.r[6] = 0x0u;  // 060738FE mov #0,r6
    c.r[5] = c.r[1];  // 06073900 mov r1,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06073906u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073906u) return; }  // 06073902 jsr @r12 ; mov #0,r4
    c.r[5] = 0x17u;  // 06073906 mov #23,r5
    c.r[1] = ld32(c.r[8]);  // 06073908 mov.l @r8,r1
    c.r[4] = ld32(0x060739ACu);  // 0607390A mov.l 0x060739AC,r4
    c.r[0] = c.r[1];  // 0607390C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0607390E mov.b @(r0,r13),r1
    c.r[8] = 0x1u;  // 06073910 mov #1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06073916u; c.r[8] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073916u) return; }  // 06073912 jsr @r9 ; and r1,r8
    c.r[1] = c.r[0];  // 06073916 mov r0,r1
    c.r[5] = 0x1Du;  // 06073918 mov #29,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607391Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607391Eu) return; }  // 0607391A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607391E mov r0,r1
    c.r[5] = c.r[8];  // 06073920 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073926u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073926u) return; }  // 06073922 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073926 mov r0,r1
    c.r[6] = 0x0u;  // 06073928 mov #0,r6
    c.r[5] = c.r[1];  // 0607392A mov r1,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06073930u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073930u) return; }  // 0607392C jsr @r12 ; mov #0,r4
    c.r[1] = ld32(0x060739B8u);  // 06073930 mov.l 0x060739B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073932 mov.b @r1,r1
    c.r[5] = 0x17u;  // 06073934 mov #23,r5
    c.r[2] = c.r[1] & 0xFFu;  // 06073936 extu.b r1,r2
    c.r[1] = ld32(0x060739BCu);  // 06073938 mov.l 0x060739BC,r1
    c.r[0] = c.r[2];  // 0607393A mov r2,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607393C mov.b @(r0,r1),r8
    c.r[4] = ld32(0x060739ACu);  // 0607393E mov.l 0x060739AC,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06073944u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073944u) return; }  // 06073940 jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06073944 mov r0,r1
    c.r[5] = 0x1Eu;  // 06073946 mov #30,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607394Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607394Cu) return; }  // 06073948 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0607394C mov r0,r1
    c.r[5] = c.r[8];  // 0607394E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073954u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073954u) return; }  // 06073950 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073954 mov r0,r1
    c.r[6] = 0x0u;  // 06073956 mov #0,r6
    c.r[5] = c.r[1];  // 06073958 mov r1,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0607395Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607395Eu) return; }  // 0607395A jsr @r12 ; mov #0,r4
    c.r[1] = ld32(0x060739C0u);  // 0607395E mov.l 0x060739C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073964u; c.r[4] = 0x29u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073964u) return; }  // 06073960 jsr @r1 ; mov #41,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607398Eu);  // 06073964 mov.w 0x0607398E,r3
    c.r[14] += c.r[3];  // 06073966 add r3,r14
    c.r[15] = c.r[14];  // 06073968 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607396A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607396C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607396E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06073970 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06073972 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06073974 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06073976 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073990u);  // 06073978 mov.w 0x06073990,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607397A rts ; mov.l @r15+,r8
}

void f_060739C4(SH2Context& c) {
    ran[1605] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060739C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060739C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060739C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060739CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060739CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060739CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060739D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060739D2 sts.l pr,@-r15
    c.r[15] -= 8;  // 060739D4 add #-8,r15
    c.r[14] = c.r[15];  // 060739D6 mov r15,r14
    c.r[1] = ld32(0x06073B84u);  // 060739D8 mov.l 0x06073B84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060739DEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060739DEu) return; }  // 060739DA jsr @r1 ; mov #0,r4
    c.r[9] = ld32(0x06073B88u);  // 060739DE mov.l 0x06073B88,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073B74u);  // 060739E0 mov.w 0x06073B74,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x06073B76u);  // 060739E2 mov.w 0x06073B76,r6
    c.r[5] = 0x3u;  // 060739E4 mov #3,r5
    c.r[1] = ld32(c.r[9]);  // 060739E6 mov.l @r9,r1
    c.r[4] = 0x0u;  // 060739E8 mov #0,r4
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060739EA mov.w @(r0,r1),r7
    st32(c.r[14], c.r[0]);  // 060739EC mov.l r0,@r14
    c.r[7] = c.r[7] & 0xFFFFu;  // 060739EE extu.w r7,r7
    c.r[7] >>= 2;  // 060739F0 shlr2 r7
    c.r[7] >>= 2;  // 060739F2 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060739F4 shlr r7
    c.r[7] >>= 2;  // 060739F6 shlr2 r7
    c.r[1] = 0x0u;  // 060739F8 mov #0,r1
    c.r[0] = ld32(0x06073B8Cu);  // 060739FA mov.l 0x06073B8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073A00u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A00u) return; }  // 060739FC jsr @r0 ; mov.l r1,@-r15
    c.r[1] = ld32(0x06073B90u);  // 06073A00 mov.l 0x06073B90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073A06u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A06u) return; }  // 06073A02 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06073B94u);  // 06073A06 mov.l 0x06073B94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073A0Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A0Cu) return; }  // 06073A08 jsr @r1 ; nop
    c.r[10] = (uint32_t)(int16_t)ld16(0x06073B78u);  // 06073A0C mov.w 0x06073B78,r10
    c.r[2] = ld32(c.r[9]);  // 06073A0E mov.l @r9,r2
    c.r[8] = ld32(0x06073B98u);  // 06073A10 mov.l 0x06073B98,r8
    c.r[0] = c.r[2];  // 06073A12 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06073A14 mov.b @(r0,r10),r1
    c.r[5] = 0x17u;  // 06073A16 mov #23,r5
    c.r[11] = c.r[1];  // 06073A18 mov r1,r11
    c.r[11] >>= 2;  // 06073A1A shlr2 r11
    c.r[11] >>= 2;  // 06073A1C shlr2 r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073B7Au);  // 06073A1E mov.w 0x06073B7A,r0
    st32(c.r[14] + 4, c.r[0]);  // 06073A20 mov.l r0,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06073A22 mov.b @(r0,r2),r1
    c.r[4] = ld32(0x06073B9Cu);  // 06073A24 mov.l 0x06073B9C,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06073A26 shlr r1
    c.r[0] = 0x3u;  // 06073A28 mov #3,r0
    c.r[1] &= c.r[0];  // 06073A2A and r0,r1
    c.r[0] = 0x4u;  // 06073A2C mov #4,r0
    c.r[11] &= c.r[0];  // 06073A2E and r0,r11
    { const uint32_t x = c.r[8]; c.pr = 0x06073A34u; c.r[11] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A34u) return; }  // 06073A30 jsr @r8 ; or r1,r11
    c.r[1] = c.r[0];  // 06073A34 mov r0,r1
    c.r[5] = 0x1Fu;  // 06073A36 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073A3Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A3Cu) return; }  // 06073A38 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073A3C mov r0,r1
    c.r[5] = c.r[11];  // 06073A3E mov r11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073A44u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A44u) return; }  // 06073A40 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073A44 mov r0,r1
    c.r[11] = ld32(0x06073BA0u);  // 06073A46 mov.l 0x06073BA0,r11
    c.r[6] = 0x0u;  // 06073A48 mov #0,r6
    c.r[5] = c.r[1];  // 06073A4A mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073A50u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A50u) return; }  // 06073A4C jsr @r11 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073B7Cu);  // 06073A50 mov.w 0x06073B7C,r1
    c.r[6] = 0x0u;  // 06073A52 mov #0,r6
    c.r[5] = ld32(c.r[9]);  // 06073A54 mov.l @r9,r5
    c.r[4] = 0x0u;  // 06073A56 mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073A5Cu; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A5Cu) return; }  // 06073A58 jsr @r11 ; add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073B7Eu);  // 06073A5C mov.w 0x06073B7E,r1
    c.r[6] = 0x0u;  // 06073A5E mov #0,r6
    c.r[5] = ld32(c.r[9]);  // 06073A60 mov.l @r9,r5
    c.r[4] = 0x0u;  // 06073A62 mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06073A68u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A68u) return; }  // 06073A64 jsr @r11 ; add r1,r5
    c.r[1] = ld32(c.r[9]);  // 06073A68 mov.l @r9,r1
    c.r[5] = 0x17u;  // 06073A6A mov #23,r5
    c.r[0] = c.r[1];  // 06073A6C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06073A6E mov.b @(r0,r10),r1
    c.r[4] = ld32(0x06073B9Cu);  // 06073A70 mov.l 0x06073B9C,r4
    c.r[12] = c.r[1];  // 06073A72 mov r1,r12
    c.r[12] >>= 2;  // 06073A74 shlr2 r12
    c.r[12] >>= 2;  // 06073A76 shlr2 r12
    c.r[12] >>= 2;  // 06073A78 shlr2 r12
    c.r[0] = 0x1u;  // 06073A7A mov #1,r0
    { const uint32_t x = c.r[8]; c.pr = 0x06073A80u; c.r[12] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A80u) return; }  // 06073A7C jsr @r8 ; and r0,r12
    c.r[1] = c.r[0];  // 06073A80 mov r0,r1
    c.r[5] = 0x1Bu;  // 06073A82 mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073A88u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A88u) return; }  // 06073A84 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073A88 mov r0,r1
    c.r[13] = ld32(0x06073BA4u);  // 06073A8A mov.l 0x06073BA4,r13
    c.r[6] = 0x2u;  // 06073A8C mov #2,r6
    c.r[5] = c.r[12];  // 06073A8E mov r12,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06073A94u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073A94u) return; }  // 06073A90 jsr @r13 ; mov r1,r4
    c.r[1] = ld32(c.r[9]);  // 06073A94 mov.l @r9,r1
    c.r[5] = 0x0u;  // 06073A96 mov #0,r5
    c.r[0] = c.r[1];  // 06073A98 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06073A9A mov.b @(r0,r10),r1
    c.r[4] = 0x0u;  // 06073A9C mov #0,r4
    c.r[1] >>= 2;  // 06073A9E shlr2 r1
    c.r[0] = 0xFu;  // 06073AA0 mov #15,r0
    c.r[1] &= c.r[0];  // 06073AA2 and r0,r1
    c.r[0] = ld32(0x06073BA8u);  // 06073AA4 mov.l 0x06073BA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073AAAu; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073AAAu) return; }  // 06073AA6 jsr @r0 ; mov r1,r6
    c.r[1] = ld32(c.r[9]);  // 06073AAA mov.l @r9,r1
    c.r[0] = ld32(c.r[14]);  // 06073AAC mov.l @r14,r0
    c.r[5] = 0x0u;  // 06073AAE mov #0,r5
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06073AB0 mov.l @(r0,r1),r1
    c.r[4] = 0x0u;  // 06073AB2 mov #0,r4
    c.r[1] >>= 8;  // 06073AB4 shlr8 r1
    c.r[1] >>= 2;  // 06073AB6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06073AB8 shlr r1
    c.r[1] >>= 2;  // 06073ABA shlr2 r1
    c.r[0] = 0x1Fu;  // 06073ABC mov #31,r0
    c.r[1] &= c.r[0];  // 06073ABE and r0,r1
    c.r[0] = ld32(0x06073BA8u);  // 06073AC0 mov.l 0x06073BA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073AC6u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073AC6u) return; }  // 06073AC2 jsr @r0 ; mov r1,r6
    c.r[1] = ld32(c.r[9]);  // 06073AC6 mov.l @r9,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06073AC8 mov.l @(4,r14),r0
    c.r[5] = 0x17u;  // 06073ACA mov #23,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073ACC mov.b @(r0,r1),r1
    c.r[4] = ld32(0x06073B9Cu);  // 06073ACE mov.l 0x06073B9C,r4
    c.r[12] = c.r[1];  // 06073AD0 mov r1,r12
    c.r[12] >>= 2;  // 06073AD2 shlr2 r12
    c.t = c.r[12] & 1; c.r[12] >>= 1;  // 06073AD4 shlr r12
    c.r[0] = 0x3u;  // 06073AD6 mov #3,r0
    { const uint32_t x = c.r[8]; c.pr = 0x06073ADCu; c.r[12] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073ADCu) return; }  // 06073AD8 jsr @r8 ; and r0,r12
    c.r[1] = c.r[0];  // 06073ADC mov r0,r1
    c.r[5] = 0x1Au;  // 06073ADE mov #26,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073AE4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073AE4u) return; }  // 06073AE0 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073AE4 mov r0,r1
    c.r[6] = 0x2u;  // 06073AE6 mov #2,r6
    c.r[5] = c.r[12];  // 06073AE8 mov r12,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06073AEEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073AEEu) return; }  // 06073AEA jsr @r13 ; mov r1,r4
    c.r[1] = ld32(c.r[9]);  // 06073AEE mov.l @r9,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06073AF0 mov.l @(4,r14),r0
    c.r[5] = 0x17u;  // 06073AF2 mov #23,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073AF4 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x06073B9Cu);  // 06073AF6 mov.l 0x06073B9C,r4
    c.r[13] = c.r[1];  // 06073AF8 mov r1,r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 06073AFA shlr r13
    c.r[0] = 0x3u;  // 06073AFC mov #3,r0
    { const uint32_t x = c.r[8]; c.pr = 0x06073B02u; c.r[13] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B02u) return; }  // 06073AFE jsr @r8 ; and r0,r13
    c.r[1] = c.r[0];  // 06073B02 mov r0,r1
    c.r[5] = 0x1Cu;  // 06073B04 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073B0Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B0Au) return; }  // 06073B06 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073B0A mov r0,r1
    c.r[5] = c.r[13];  // 06073B0C mov r13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073B12u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B12u) return; }  // 06073B0E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073B12 mov r0,r1
    c.r[6] = 0x0u;  // 06073B14 mov #0,r6
    c.r[5] = c.r[1];  // 06073B16 mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073B1Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B1Cu) return; }  // 06073B18 jsr @r11 ; mov #0,r4
    c.r[1] = ld32(c.r[9]);  // 06073B1C mov.l @r9,r1
    c.r[5] = 0x17u;  // 06073B1E mov #23,r5
    c.r[0] = ld32(c.r[14] + 4);  // 06073B20 mov.l @(4,r14),r0
    c.r[4] = ld32(0x06073B9Cu);  // 06073B22 mov.l 0x06073B9C,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073B24 mov.b @(r0,r1),r1
    c.r[9] = 0x1u;  // 06073B26 mov #1,r9
    { const uint32_t x = c.r[8]; c.pr = 0x06073B2Cu; c.r[9] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B2Cu) return; }  // 06073B28 jsr @r8 ; and r1,r9
    c.r[1] = c.r[0];  // 06073B2C mov r0,r1
    c.r[5] = 0x1Du;  // 06073B2E mov #29,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073B34u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B34u) return; }  // 06073B30 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073B34 mov r0,r1
    c.r[5] = c.r[9];  // 06073B36 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06073B3Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B3Cu) return; }  // 06073B38 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073B3C mov r0,r1
    c.r[6] = 0x0u;  // 06073B3E mov #0,r6
    c.r[5] = c.r[1];  // 06073B40 mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06073B46u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B46u) return; }  // 06073B42 jsr @r11 ; mov #0,r4
    c.r[1] = ld32(0x06073BACu);  // 06073B46 mov.l 0x06073BAC,r1
    c.r[5] = 0x0u;  // 06073B48 mov #0,r5
    c.r[4] = 0x0u;  // 06073B4A mov #0,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073B4C mov.b @r1,r6
    c.r[0] = ld32(0x06073BA8u);  // 06073B4E mov.l 0x06073BA8,r0
    c.r[6] = c.r[6] & 0xFFu;  // 06073B50 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06073B56u; c.r[6] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B56u) return; }  // 06073B52 jsr @r0 ; add #1,r6
    c.r[1] = ld32(0x06073BB0u);  // 06073B56 mov.l 0x06073BB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073B5Cu; c.r[4] = 0x2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073B5Cu) return; }  // 06073B58 jsr @r1 ; mov #42,r4
    c.r[14] += 8;  // 06073B5C add #8,r14
    c.r[15] = c.r[14];  // 06073B5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06073B60 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06073B62 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06073B64 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06073B66 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06073B68 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06073B6A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06073B6C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073B80u);  // 06073B6E mov.w 0x06073B80,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06073B70 rts ; mov.l @r15+,r8
}

void f_06073BB4(SH2Context& c) {
    ran[1606] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06073BB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06073BB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06073BB8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06073BBA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06073BBC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06073BBE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06073BC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06073BC2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06073BC4 mov r15,r14
    c.r[8] = ld32(0x06073C0Cu);  // 06073BC6 mov.l 0x06073C0C,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073C04u);  // 06073BC8 mov.w 0x06073C04,r0
    c.r[1] = 0x33u;  // 06073BCA mov #51,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 06073BCC mov.b r1,@(r0,r8)
    c.r[1] = ld32(0x06073C10u);  // 06073BCE mov.l 0x06073C10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073BD4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073BD4u) return; }  // 06073BD0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06073C14u);  // 06073BD4 mov.l 0x06073C14,r1
    c.r[1] = ld32(c.r[1]);  // 06073BD6 mov.l @r1,r1
    c.r[1] += 1;  // 06073BD8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073BDA mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06073BDC extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06073BDE tst r2,r2
    { const bool k = !c.t; c.r[5] = 0x3u; if (k) { goto L_06073C20; } }  // 06073BE0 bf/s 0x06073C20 ; mov #3,r5
    c.r[1] = ld32(0x06073C18u);  // 06073BE4 mov.l 0x06073C18,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073C06u);  // 06073BE6 mov.w 0x06073C06,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x06073C08u);  // 06073BE8 mov.w 0x06073C08,r6
    c.r[1] = ld32(c.r[1]);  // 06073BEA mov.l @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06073BEC mov.w @(r0,r1),r7
    c.r[4] = 0x0u;  // 06073BEE mov #0,r4
    c.r[7] = c.r[7] & 0xFFFFu;  // 06073BF0 extu.w r7,r7
    c.r[7] >>= 2;  // 06073BF2 shlr2 r7
    c.r[7] >>= 2;  // 06073BF4 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06073BF6 shlr r7
    c.r[7] >>= 2;  // 06073BF8 shlr2 r7
    c.r[0] = ld32(0x06073C1Cu);  // 06073BFA mov.l 0x06073C1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073C00u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C00u) return; }  // 06073BFC jsr @r0 ; mov.l r2,@-r15
    c.r[15] += 4; goto L_06073C30;  // 06073C00 bra 0x06073C30 ; add #4,r15
L_06073C20:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073D92u);  // 06073C20 mov.w 0x06073D92,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06073C22 mov.w @(r0,r8),r1
    c.r[1] += 1;  // 06073C24 add #1,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 06073C26 mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073D94u);  // 06073C28 mov.w 0x06073D94,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06073C2A mov.w @(r0,r8),r1
    c.r[1] += 1;  // 06073C2C add #1,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 06073C2E mov.w r1,@(r0,r8)
L_06073C30:
    c.r[1] = ld32(0x06073DA4u);  // 06073C30 mov.l 0x06073DA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073C36u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C36u) return; }  // 06073C32 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06073DA8u);  // 06073C36 mov.l 0x06073DA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073C3Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C3Cu) return; }  // 06073C38 jsr @r1 ; nop
    c.r[8] = ld32(0x06073DACu);  // 06073C3C mov.l 0x06073DAC,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073D96u);  // 06073C3E mov.w 0x06073D96,r1
    c.r[6] = 0x0u;  // 06073C40 mov #0,r6
    c.r[4] = 0x0u;  // 06073C42 mov #0,r4
    c.r[5] = ld32(c.r[8]);  // 06073C44 mov.l @r8,r5
    c.r[0] = ld32(0x06073DB0u);  // 06073C46 mov.l 0x06073DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073C4Cu; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C4Cu) return; }  // 06073C48 jsr @r0 ; add r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073D98u);  // 06073C4C mov.w 0x06073D98,r1
    c.r[6] = 0x0u;  // 06073C4E mov #0,r6
    c.r[4] = 0x0u;  // 06073C50 mov #0,r4
    c.r[5] = ld32(c.r[8]);  // 06073C52 mov.l @r8,r5
    c.r[0] = ld32(0x06073DB0u);  // 06073C54 mov.l 0x06073DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073C5Au; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C5Au) return; }  // 06073C56 jsr @r0 ; add r1,r5
    c.r[12] = (uint32_t)(int16_t)ld16(0x06073D9Au);  // 06073C5A mov.w 0x06073D9A,r12
    c.r[11] = ld32(0x06073DB4u);  // 06073C5C mov.l 0x06073DB4,r11
    c.r[9] = ld32(0x06073DB8u);  // 06073C5E mov.l 0x06073DB8,r9
    c.r[1] = ld32(c.r[8]);  // 06073C60 mov.l @r8,r1
    c.r[5] = 0x17u;  // 06073C62 mov #23,r5
    c.r[0] = c.r[1];  // 06073C64 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06073C66 mov.b @(r0,r12),r1
    c.r[4] = c.r[11];  // 06073C68 mov r11,r4
    c.r[10] = c.r[1];  // 06073C6A mov r1,r10
    c.r[10] >>= 2;  // 06073C6C shlr2 r10
    c.r[10] >>= 2;  // 06073C6E shlr2 r10
    c.r[10] >>= 2;  // 06073C70 shlr2 r10
    c.r[0] = 0x1u;  // 06073C72 mov #1,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06073C78u; c.r[10] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C78u) return; }  // 06073C74 jsr @r9 ; and r0,r10
    c.r[1] = c.r[0];  // 06073C78 mov r0,r1
    c.r[5] = 0x1Bu;  // 06073C7A mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073C80u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C80u) return; }  // 06073C7C jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073C80 mov r0,r1
    c.r[6] = 0x2u;  // 06073C82 mov #2,r6
    c.r[5] = c.r[10];  // 06073C84 mov r10,r5
    c.r[0] = ld32(0x06073DBCu);  // 06073C86 mov.l 0x06073DBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073C8Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073C8Cu) return; }  // 06073C88 jsr @r0 ; mov r1,r4
    c.r[10] = ld32(0x06073DC0u);  // 06073C8C mov.l 0x06073DC0,r10
    c.r[1] = ld32(c.r[8]);  // 06073C8E mov.l @r8,r1
    c.r[5] = 0x0u;  // 06073C90 mov #0,r5
    c.r[0] = c.r[1];  // 06073C92 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06073C94 mov.b @(r0,r12),r1
    c.r[4] = 0x0u;  // 06073C96 mov #0,r4
    c.r[1] >>= 2;  // 06073C98 shlr2 r1
    c.r[0] = 0xFu;  // 06073C9A mov #15,r0
    c.r[1] &= c.r[0];  // 06073C9C and r0,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06073CA2u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073CA2u) return; }  // 06073C9E jsr @r10 ; mov r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06073D9Cu);  // 06073CA2 mov.w 0x06073D9C,r2
    c.r[1] = ld32(c.r[8]);  // 06073CA4 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06073CA6 mov #0,r5
    c.r[0] = c.r[1];  // 06073CA8 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06073CAA mov.l @(r0,r2),r1
    c.r[4] = 0x0u;  // 06073CAC mov #0,r4
    c.r[1] >>= 8;  // 06073CAE shlr8 r1
    c.r[1] >>= 2;  // 06073CB0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06073CB2 shlr r1
    c.r[1] >>= 2;  // 06073CB4 shlr2 r1
    c.r[0] = 0x1Fu;  // 06073CB6 mov #31,r0
    c.r[1] &= c.r[0];  // 06073CB8 and r0,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06073CBEu; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073CBEu) return; }  // 06073CBA jsr @r10 ; mov r1,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x06073D9Eu);  // 06073CBE mov.w 0x06073D9E,r13
    c.r[1] = ld32(c.r[8]);  // 06073CC0 mov.l @r8,r1
    c.r[5] = 0x17u;  // 06073CC2 mov #23,r5
    c.r[0] = c.r[1];  // 06073CC4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06073CC6 mov.b @(r0,r13),r1
    c.r[4] = c.r[11];  // 06073CC8 mov r11,r4
    c.r[10] = c.r[1];  // 06073CCA mov r1,r10
    c.r[10] >>= 2;  // 06073CCC shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 06073CCE shlr r10
    c.r[0] = 0x3u;  // 06073CD0 mov #3,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06073CD6u; c.r[10] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073CD6u) return; }  // 06073CD2 jsr @r9 ; and r0,r10
    c.r[1] = c.r[0];  // 06073CD6 mov r0,r1
    c.r[5] = 0x1Au;  // 06073CD8 mov #26,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073CDEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073CDEu) return; }  // 06073CDA jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073CDE mov r0,r1
    c.r[6] = 0x2u;  // 06073CE0 mov #2,r6
    c.r[5] = c.r[10];  // 06073CE2 mov r10,r5
    c.r[0] = ld32(0x06073DBCu);  // 06073CE4 mov.l 0x06073DBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073CEAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073CEAu) return; }  // 06073CE6 jsr @r0 ; mov r1,r4
    c.r[1] = ld32(c.r[8]);  // 06073CEA mov.l @r8,r1
    c.r[5] = 0x17u;  // 06073CEC mov #23,r5
    c.r[0] = c.r[1];  // 06073CEE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06073CF0 mov.b @(r0,r13),r1
    c.r[4] = c.r[11];  // 06073CF2 mov r11,r4
    c.r[10] = c.r[1];  // 06073CF4 mov r1,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 06073CF6 shlr r10
    c.r[0] = 0x3u;  // 06073CF8 mov #3,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06073CFEu; c.r[10] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073CFEu) return; }  // 06073CFA jsr @r9 ; and r0,r10
    c.r[1] = c.r[0];  // 06073CFE mov r0,r1
    c.r[5] = 0x1Cu;  // 06073D00 mov #28,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073D06u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D06u) return; }  // 06073D02 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073D06 mov r0,r1
    c.r[5] = c.r[10];  // 06073D08 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073D0Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D0Eu) return; }  // 06073D0A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073D0E mov r0,r1
    c.r[6] = 0x0u;  // 06073D10 mov #0,r6
    c.r[5] = c.r[1];  // 06073D12 mov r1,r5
    c.r[0] = ld32(0x06073DB0u);  // 06073D14 mov.l 0x06073DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073D1Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D1Au) return; }  // 06073D16 jsr @r0 ; mov #0,r4
    c.r[5] = 0x17u;  // 06073D1A mov #23,r5
    c.r[1] = ld32(c.r[8]);  // 06073D1C mov.l @r8,r1
    c.r[4] = c.r[11];  // 06073D1E mov r11,r4
    c.r[0] = c.r[1];  // 06073D20 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06073D22 mov.b @(r0,r13),r1
    c.r[8] = 0x1u;  // 06073D24 mov #1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06073D2Au; c.r[8] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D2Au) return; }  // 06073D26 jsr @r9 ; and r1,r8
    c.r[1] = c.r[0];  // 06073D2A mov r0,r1
    c.r[5] = 0x1Du;  // 06073D2C mov #29,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073D32u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D32u) return; }  // 06073D2E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073D32 mov r0,r1
    c.r[5] = c.r[8];  // 06073D34 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073D3Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D3Au) return; }  // 06073D36 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073D3A mov r0,r1
    c.r[6] = 0x0u;  // 06073D3C mov #0,r6
    c.r[5] = c.r[1];  // 06073D3E mov r1,r5
    c.r[0] = ld32(0x06073DB0u);  // 06073D40 mov.l 0x06073DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073D46u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D46u) return; }  // 06073D42 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x06073DC4u);  // 06073D46 mov.l 0x06073DC4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073D48 mov.b @r1,r1
    c.r[5] = 0x17u;  // 06073D4A mov #23,r5
    c.r[2] = c.r[1] & 0xFFu;  // 06073D4C extu.b r1,r2
    c.r[1] = ld32(0x06073DC8u);  // 06073D4E mov.l 0x06073DC8,r1
    c.r[0] = c.r[2];  // 06073D50 mov r2,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073D52 mov.b @(r0,r1),r8
    c.r[4] = c.r[11];  // 06073D54 mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06073D5Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D5Au) return; }  // 06073D56 jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06073D5A mov r0,r1
    c.r[5] = 0x20u;  // 06073D5C mov #32,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073D62u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D62u) return; }  // 06073D5E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073D62 mov r0,r1
    c.r[5] = c.r[8];  // 06073D64 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06073D6Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D6Au) return; }  // 06073D66 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06073D6A mov r0,r1
    c.r[6] = 0x0u;  // 06073D6C mov #0,r6
    c.r[5] = c.r[1];  // 06073D6E mov r1,r5
    c.r[0] = ld32(0x06073DB0u);  // 06073D70 mov.l 0x06073DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06073D76u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D76u) return; }  // 06073D72 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x06073DCCu);  // 06073D76 mov.l 0x06073DCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073D7Cu; c.r[4] = 0x2Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073D7Cu) return; }  // 06073D78 jsr @r1 ; mov #43,r4
    c.r[15] = c.r[14];  // 06073D7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06073D7E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06073D80 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06073D82 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06073D84 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06073D86 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06073D88 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06073D8A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073DA0u);  // 06073D8C mov.w 0x06073DA0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06073D8E rts ; mov.l @r15+,r8
}

void f_06073DD0(SH2Context& c) {
    ran[1607] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06073DD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06073DD2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06073DD4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06073DD6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06073DD8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06073DDA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06073DDC sts.l pr,@-r15
    c.r[15] -= 32;  // 06073DDE add #-32,r15
    c.r[14] = c.r[15];  // 06073DE0 mov r15,r14
    c.r[8] = ld32(0x06073F84u);  // 06073DE2 mov.l 0x06073F84,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073F70u);  // 06073DE4 mov.w 0x06073F70,r0
    c.r[1] = 0x0u;  // 06073DE6 mov #0,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 06073DE8 mov.b r1,@(r0,r8)
    c.r[1] = ld32(0x06073F88u);  // 06073DEA mov.l 0x06073F88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073DF0u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073DF0u) return; }  // 06073DEC jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06073F8Cu);  // 06073DF0 mov.l 0x06073F8C,r1
    c.r[1] = ld32(c.r[1]);  // 06073DF2 mov.l @r1,r1
    c.r[1] += 1;  // 06073DF4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073DF6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06073DF8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073DFA tst r1,r1
    { const bool k = c.t; c.r[1] = 0x10u; if (k) { goto L_06073E04; } }  // 06073DFC bt/s 0x06073E04 ; mov #16,r1
    goto L_06073FC2;  // 06073E00 bra 0x06073FC2 ; nop
L_06073E04:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073F72u);  // 06073E04 mov.w 0x06073F72,r0
    st16(c.r[0] + c.r[8], c.r[1]);  // 06073E06 mov.w r1,@(r0,r8)
    c.r[12] = 0x0u;  // 06073E08 mov #0,r12
    c.r[2] = 0xAu;  // 06073E0A mov #10,r2
    c.r[8] = 0x7u;  // 06073E0C mov #7,r8
    c.r[6] = c.r[14];  // 06073E0E mov r14,r6
    c.r[6] += 16;  // 06073E10 add #16,r6
    c.r[4] = 0xFFFFFF88u;  // 06073E12 mov #-120,r4
    c.r[7] = c.r[14];  // 06073E14 mov r14,r7
    c.r[7] += 1;  // 06073E16 add #1,r7
    c.r[3] = c.r[14];  // 06073E18 mov r14,r3
    c.r[3] += 17;  // 06073E1A add #17,r3
    c.r[5] = 0xFFFFFF82u;  // 06073E1C mov #-126,r5
L_06073E1E:
    c.r[0] = c.r[14];  // 06073E1E mov r14,r0
    st8(c.r[0] + c.r[12], c.r[2]);  // 06073E20 mov.b r2,@(r0,r12)
    c.r[0] = c.r[6];  // 06073E22 mov r6,r0
    st8(c.r[0] + c.r[12], c.r[4]);  // 06073E24 mov.b r4,@(r0,r12)
    c.r[0] = c.r[7];  // 06073E26 mov r7,r0
    st8(c.r[0] + c.r[12], c.r[2]);  // 06073E28 mov.b r2,@(r0,r12)
    c.r[0] = c.r[3];  // 06073E2A mov r3,r0
    st8(c.r[0] + c.r[12], c.r[5]);  // 06073E2C mov.b r5,@(r0,r12)
    c.r[12] += 2;  // 06073E2E add #2,r12
    c.r[1] = c.r[2];  // 06073E30 mov r2,r1
    c.r[1] += 7;  // 06073E32 add #7,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[8];  // 06073E34 cmp/gt r8,r12
    { const bool k = !c.t; c.r[2] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06073E1E; } }  // 06073E36 bf/s 0x06073E1E ; extu.b r1,r2
    c.r[12] = 0x8u;  // 06073E3A mov #8,r12
    c.r[2] = 0xAu;  // 06073E3C mov #10,r2
    c.r[8] = 0xFu;  // 06073E3E mov #15,r8
    c.r[6] = c.r[14];  // 06073E40 mov r14,r6
    c.r[6] += 16;  // 06073E42 add #16,r6
    c.r[4] = 0xFFFFFF96u;  // 06073E44 mov #-106,r4
    c.r[7] = c.r[14];  // 06073E46 mov r14,r7
    c.r[7] += 1;  // 06073E48 add #1,r7
    c.r[3] = c.r[14];  // 06073E4A mov r14,r3
    c.r[3] += 17;  // 06073E4C add #17,r3
    c.r[5] = 0xFFFFFF8Fu;  // 06073E4E mov #-113,r5
L_06073E50:
    c.r[0] = c.r[14];  // 06073E50 mov r14,r0
    st8(c.r[0] + c.r[12], c.r[2]);  // 06073E52 mov.b r2,@(r0,r12)
    c.r[0] = c.r[6];  // 06073E54 mov r6,r0
    st8(c.r[0] + c.r[12], c.r[4]);  // 06073E56 mov.b r4,@(r0,r12)
    c.r[0] = c.r[7];  // 06073E58 mov r7,r0
    st8(c.r[0] + c.r[12], c.r[2]);  // 06073E5A mov.b r2,@(r0,r12)
    c.r[0] = c.r[3];  // 06073E5C mov r3,r0
    st8(c.r[0] + c.r[12], c.r[5]);  // 06073E5E mov.b r5,@(r0,r12)
    c.r[12] += 2;  // 06073E60 add #2,r12
    c.r[1] = c.r[2];  // 06073E62 mov r2,r1
    c.r[1] += 7;  // 06073E64 add #7,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[8];  // 06073E66 cmp/gt r8,r12
    { const bool k = !c.t; c.r[2] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06073E50; } }  // 06073E68 bf/s 0x06073E50 ; extu.b r1,r2
    c.r[6] = c.r[14];  // 06073E6C mov r14,r6
    c.r[6] += 16;  // 06073E6E add #16,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x06073F74u);  // 06073E70 mov.w 0x06073F74,r4
    c.r[1] = 0x10u;  // 06073E72 mov #16,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06073E74 mov.l r1,@-r15
    c.r[1] = 0x3u;  // 06073E76 mov #3,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06073E78 mov.l r1,@-r15
    c.r[0] = ld32(0x06073F90u);  // 06073E7A mov.l 0x06073F90,r0
    c.r[7] = 0x11u;  // 06073E7C mov #17,r7
    { const uint32_t x = c.r[0]; c.pr = 0x06073E82u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073E82u) return; }  // 06073E7E jsr @r0 ; mov r14,r5
    c.r[12] = ld32(0x06073F94u);  // 06073E82 mov.l 0x06073F94,r12
    c.r[1] = 0x1u;  // 06073E84 mov #1,r1
    st8(c.r[12], c.r[1]);  // 06073E86 mov.b r1,@r12
    c.r[8] = (uint32_t)(int16_t)ld16(0x06073F76u);  // 06073E88 mov.w 0x06073F76,r8
    c.r[5] = ld32(0x06073F98u);  // 06073E8A mov.l 0x06073F98,r5
    c.r[9] = ld32(0x06073F9Cu);  // 06073E8C mov.l 0x06073F9C,r9
    c.r[10] = ld32(0x06073FA0u);  // 06073E8E mov.l 0x06073FA0,r10
    c.r[7] = 0xEu;  // 06073E90 mov #14,r7
    c.r[6] = c.r[8];  // 06073E92 mov r8,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06073E98u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073E98u) return; }  // 06073E94 jsr @r10 ; mov r9,r4
    c.r[11] = ld32(0x06073FA4u);  // 06073E98 mov.l 0x06073FA4,r11
    c.r[7] = 0xEu;  // 06073E9A mov #14,r7
    c.r[6] = c.r[8];  // 06073E9C mov r8,r6
    c.r[5] = c.r[11];  // 06073E9E mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06073EA4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073EA4u) return; }  // 06073EA0 jsr @r10 ; mov r9,r4
    c.r[1] = ld32(0x06073FA8u);  // 06073EA4 mov.l 0x06073FA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073EAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073EAAu) return; }  // 06073EA6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06073EAA mov #0,r1
    st8(c.r[12], c.r[1]);  // 06073EAC mov.b r1,@r12
    c.r[12] = 0x0u;  // 06073EAE mov #0,r12
    c.r[15] += 8;  // 06073EB0 add #8,r15
    c.r[5] = c.r[11];  // 06073EB2 mov r11,r5
    c.r[5] += 1;  // 06073EB4 add #1,r5
L_06073EB6:
    c.r[7] = 0x1Fu;  // 06073EB6 mov #31,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06073EB8 mov.b @r5,r6
    c.r[1] = 0x3u;  // 06073EBA mov #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06073EBC mov.b @r11,r2
    c.r[7] &= c.r[6];  // 06073EBE and r6,r7
    c.r[7] += c.r[7];  // 06073EC0 add r7,r7
    c.r[2] = c.r[2] & 0xFFu;  // 06073EC2 extu.b r2,r2
    c.r[1] &= c.r[2];  // 06073EC4 and r2,r1
    c.r[1] <<= 2;  // 06073EC6 shll2 r1
    c.r[1] += c.r[1];  // 06073EC8 add r1,r1
    c.r[3] = c.r[6] & 0xFFu;  // 06073ECA extu.b r6,r3
    c.r[3] >>= 2;  // 06073ECC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06073ECE shlr r3
    c.r[3] >>= 2;  // 06073ED0 shlr2 r3
    c.r[3] |= c.r[1];  // 06073ED2 or r1,r3
    c.r[1] = 0x5u;  // 06073ED4 mov #5,r1
    c.r[0] = c.r[2];  // 06073ED6 mov r2,r0
    c.r[0] >>= 2;  // 06073ED8 shlr2 r0
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06073EDA mulu.w r1,r3
    c.r[0] &= 0x1Fu;  // 06073EDC and #31,r0
    c.r[1] = c.macl;  // 06073EDE sts macl,r1
    c.r[7] += c.r[1];  // 06073EE0 add r1,r7
    c.r[7] += c.r[0];  // 06073EE2 add r0,r7
    c.r[2] = c.r[7];  // 06073EE4 mov r7,r2
    c.r[2] >>= 2;  // 06073EE6 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06073EE8 shlr r2
    c.r[1] = 0x1Fu;  // 06073EEA mov #31,r1
    c.r[1] &= c.r[2];  // 06073EEC and r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06073F78u);  // 06073EEE mov.w 0x06073F78,r3
    c.r[3] &= c.r[6];  // 06073EF0 and r6,r3
    c.r[3] |= c.r[1];  // 06073EF2 or r1,r3
    st8(c.r[5], c.r[3]);  // 06073EF4 mov.b r3,@r5
    c.r[3] = c.r[2] & 0xFFFFu;  // 06073EF6 extu.w r2,r3
    c.r[7] = c.r[3];  // 06073EF8 mov r3,r7
    c.r[7] >>= 2;  // 06073EFA shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06073EFC shlr r7
    c.r[0] = 0x3u;  // 06073EFE mov #3,r0
    c.r[7] &= c.r[0];  // 06073F00 and r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073F7Au);  // 06073F02 mov.w 0x06073F7A,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06073F04 mov.b @r11,r2
    c.r[12] += 1;  // 06073F06 add #1,r12
    c.r[2] &= c.r[0];  // 06073F08 and r0,r2
    c.r[2] |= c.r[7];  // 06073F0A or r7,r2
    st8(c.r[11], c.r[2]);  // 06073F0C mov.b r2,@r11
    c.r[0] = 0x7u;  // 06073F0E mov #7,r0
    c.r[3] &= c.r[0];  // 06073F10 and r0,r3
    c.r[3] <<= 2;  // 06073F12 shll2 r3
    c.r[3] += c.r[3];  // 06073F14 add r3,r3
    c.r[3] <<= 2;  // 06073F16 shll2 r3
    c.r[0] = 0x1Fu;  // 06073F18 mov #31,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06073F1A mov.b @r5,r2
    c.r[1] <<= 2;  // 06073F1C shll2 r1
    c.r[2] &= c.r[0];  // 06073F1E and r0,r2
    c.r[2] |= c.r[3];  // 06073F20 or r3,r2
    st8(c.r[5], c.r[2]);  // 06073F22 mov.b r2,@r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06073F7Cu);  // 06073F24 mov.w 0x06073F7C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06073F26 mov.b @r11,r2
    c.r[5] += 2;  // 06073F28 add #2,r5
    c.r[2] &= c.r[0];  // 06073F2A and r0,r2
    c.r[2] |= c.r[1];  // 06073F2C or r1,r2
    st8(c.r[11], c.r[2]);  // 06073F2E mov.b r2,@r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06073F7Eu);  // 06073F30 mov.w 0x06073F7E,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06073F32 cmp/gt r1,r12
    { const bool k = !c.t; c.r[11] += 2; if (k) { SH2_POLL(c); goto L_06073EB6; } }  // 06073F34 bf/s 0x06073EB6 ; add #2,r11
    c.r[2] = ld32(0x06073FACu);  // 06073F38 mov.l 0x06073FAC,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06073F3A mov.b @r2,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06073F3C extu.b r1,r7
    c.r[1] = ld32(0x06073FB0u);  // 06073F3E mov.l 0x06073FB0,r1
    c.r[1] = ld32(c.r[1]);  // 06073F40 mov.l @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06073F80u);  // 06073F42 mov.w 0x06073F80,r6
    c.r[0] = c.r[1];  // 06073F44 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06073F46 mov.w @(r0,r6),r1
    c.r[3] = ld32(0x06073FB4u);  // 06073F48 mov.l 0x06073FB4,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 06073F4A extu.w r1,r1
    c.r[1] >>= 2;  // 06073F4C shlr2 r1
    c.r[1] >>= 2;  // 06073F4E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06073F50 shlr r1
    c.r[1] >>= 2;  // 06073F52 shlr2 r1
    c.r[1] -= 48;  // 06073F54 add #-48,r1
    c.r[0] = c.r[7];  // 06073F56 mov r7,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06073F58 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06073F5A mov.b @r2,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06073F5C extu.b r1,r7
    c.r[0] = c.r[7];  // 06073F5E mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06073F60 mov.b @(r0,r3),r2
    c.r[1] = 0x1u;  // 06073F62 mov #1,r1
    c.r[1] &= c.r[2];  // 06073F64 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073F66 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06073FB8; } }  // 06073F68 bt/s 0x06073FB8 ; mov r2,r1
    c.r[1] -= 1; goto L_06073FBA;  // 06073F6C bra 0x06073FBA ; add #-1,r1
L_06073FB8:
    c.r[1] += 1;  // 06073FB8 add #1,r1
L_06073FBA:
    st8(c.r[0] + c.r[3], c.r[1]);  // 06073FBA mov.b r1,@(r0,r3)
    c.r[1] = ld32(0x060740D4u);  // 06073FBC mov.l 0x060740D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073FC2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073FC2u) return; }  // 06073FBE jsr @r1 ; mov #1,r4
L_06073FC2:
    c.r[2] = ld32(0x060740D8u);  // 06073FC2 mov.l 0x060740D8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060740CAu);  // 06073FC4 mov.w 0x060740CA,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06073FC6 mov.w @(r0,r2),r1
    c.r[1] += 16;  // 06073FC8 add #16,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06073FCA mov.w r1,@(r0,r2)
    c.r[1] = ld32(0x060740DCu);  // 06073FCC mov.l 0x060740DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06073FD2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06073FD2u) return; }  // 06073FCE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060740E0u);  // 06073FD2 mov.l 0x060740E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073FD4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06073FD6 extu.b r1,r0
    c.r[1] = ld32(0x060740E4u);  // 06073FD8 mov.l 0x060740E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06073FDA mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06073FDC extu.b r1,r4
    c.r[1] = 0x1u;  // 06073FDE mov #1,r1
    c.r[1] &= c.r[4];  // 06073FE0 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073FE2 tst r1,r1
    { const bool k = c.t; c.r[12] = c.r[4]; if (k) { goto L_06073FEC; } }  // 06073FE4 bt/s 0x06073FEC ; mov r4,r12
    c.r[12] -= 1; goto L_06073FEE;  // 06073FE8 bra 0x06073FEE ; add #-1,r12
L_06073FEC:
    c.r[12] += 1;  // 06073FEC add #1,r12
L_06073FEE:
    c.r[1] = ld32(0x060740E8u);  // 06073FEE mov.l 0x060740E8,r1
    c.r[1] = ld32(c.r[1]);  // 06073FF0 mov.l @r1,r1
    c.r[1] += 1;  // 06073FF2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06073FF4 mov.b @r1,r1
    c.r[12] <<= 2;  // 06073FF6 shll2 r12
    c.r[12] += c.r[12];  // 06073FF8 add r12,r12
    c.r[12] <<= 2;  // 06073FFA shll2 r12
    c.r[1] = c.r[1] & 0xFFu;  // 06073FFC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06073FFE tst r1,r1
    { const bool k = !c.t; c.r[11] = 0x20u; if (k) { goto L_06074034; } }  // 06074000 bf/s 0x06074034 ; mov #32,r11
    c.r[10] = ld32(0x060740ECu);  // 06074004 mov.l 0x060740EC,r10
    c.r[1] = 0x1u;  // 06074006 mov #1,r1
    st8(c.r[10], c.r[1]);  // 06074008 mov.b r1,@r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x060740CCu);  // 0607400A mov.w 0x060740CC,r6
    c.r[8] = ld32(0x060740F0u);  // 0607400C mov.l 0x060740F0,r8
    c.r[4] = ld32(0x060740F4u);  // 0607400E mov.l 0x060740F4,r4
    c.r[9] = ld32(0x060740F8u);  // 06074010 mov.l 0x060740F8,r9
    c.r[7] = 0xEu;  // 06074012 mov #14,r7
    { const uint32_t x = c.r[9]; c.pr = 0x06074018u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074018u) return; }  // 06074014 jsr @r9 ; mov r8,r5
    c.r[8] += c.r[12];  // 06074018 add r12,r8
    c.r[1] = ld32(0x060740FCu);  // 0607401A mov.l 0x060740FC,r1
    c.r[12] += c.r[1];  // 0607401C add r1,r12
    c.r[7] = 0xEu;  // 0607401E mov #14,r7
    c.r[6] = c.r[11];  // 06074020 mov r11,r6
    c.r[5] = c.r[8];  // 06074022 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06074028u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074028u) return; }  // 06074024 jsr @r9 ; mov r12,r4
    c.r[1] = ld32(0x06074100u);  // 06074028 mov.l 0x06074100,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607402Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607402Eu) return; }  // 0607402A jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0607402E mov #0,r1
    st8(c.r[10], c.r[1]); goto L_060740A8;  // 06074030 bra 0x060740A8 ; mov.b r1,@r10
L_06074034:
    c.r[8] = ld32(0x06074104u);  // 06074034 mov.l 0x06074104,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607403Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607403Au) return; }  // 06074036 jsr @r8 ; mov #1,r4
    c.r[1] = c.r[0];  // 0607403A mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607403C extu.b r1,r2
    c.r[9] = ld32(0x06074108u);  // 0607403E mov.l 0x06074108,r9
    c.r[3] = c.r[2];  // 06074040 mov r2,r3
    c.r[3] += c.r[3];  // 06074042 add r3,r3
    c.r[3] += c.r[2];  // 06074044 add r2,r3
    c.r[3] <<= 2;  // 06074046 shll2 r3
    c.r[2] = c.r[3];  // 06074048 mov r3,r2
    c.r[2] += c.r[9];  // 0607404A add r9,r2
    c.r[1] = ld32(0x060740F4u);  // 0607404C mov.l 0x060740F4,r1
    st32(c.r[2] + 4, c.r[1]);  // 0607404E mov.l r1,@(4,r2)
    c.r[2] += 8;  // 06074050 add #8,r2
    c.r[1] = 0x10u;  // 06074052 mov #16,r1
    st8(c.r[2], c.r[1]);  // 06074054 mov.b r1,@r2
    c.r[0] = c.r[9];  // 06074056 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06074058 mov.b @(r0,r3),r1
    c.r[4] = 0x1u;  // 0607405A mov #1,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060740CEu);  // 0607405C mov.w 0x060740CE,r0
    c.r[1] &= c.r[0];  // 0607405E and r0,r1
    c.r[0] = 0x10u;  // 06074060 mov #16,r0
    c.r[1] |= c.r[0];  // 06074062 or r0,r1
    c.r[0] = c.r[9];  // 06074064 mov r9,r0
    { const uint32_t x = c.r[8]; c.pr = 0x0607406Au; st8(c.r[0] + c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607406Au) return; }  // 06074066 jsr @r8 ; mov.b r1,@(r0,r3)
    c.r[1] = c.r[0];  // 0607406A mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607406C extu.b r1,r2
    c.r[3] = c.r[2];  // 0607406E mov r2,r3
    c.r[3] += c.r[3];  // 06074070 add r3,r3
    c.r[3] += c.r[2];  // 06074072 add r2,r3
    c.r[3] <<= 2;  // 06074074 shll2 r3
    c.r[2] = c.r[3];  // 06074076 mov r3,r2
    c.r[2] += c.r[9];  // 06074078 add r9,r2
    c.r[1] = ld32(0x060740FCu);  // 0607407A mov.l 0x060740FC,r1
    c.r[1] += c.r[12];  // 0607407C add r12,r1
    st32(c.r[2] + 4, c.r[1]);  // 0607407E mov.l r1,@(4,r2)
    c.r[1] = c.r[12];  // 06074080 mov r12,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06074082 cmp/pz r1
    { const bool k = c.t; c.r[2] += 8; if (k) { goto L_0607408A; } }  // 06074084 bt/s 0x0607408A ; add #8,r2
    c.r[1] += 31;  // 06074088 add #31,r1
L_0607408A:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0607408A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0607408C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0607408E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06074090 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06074092 shar r1
    c.r[1] += 16;  // 06074094 add #16,r1
    st8(c.r[2], c.r[1]);  // 06074096 mov.b r1,@r2
    c.r[0] = c.r[9];  // 06074098 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607409A mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060740CEu);  // 0607409C mov.w 0x060740CE,r0
    c.r[1] &= c.r[0];  // 0607409E and r0,r1
    c.r[0] = 0x1u;  // 060740A0 mov #1,r0
    c.r[1] |= c.r[0];  // 060740A2 or r0,r1
    c.r[0] = c.r[9];  // 060740A4 mov r9,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060740A6 mov.b r1,@(r0,r3)
L_060740A8:
    c.r[1] = ld32(0x0607410Cu);  // 060740A8 mov.l 0x0607410C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060740AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060740AEu) return; }  // 060740AA jsr @r1 ; nop
    c.r[1] = ld32(0x06074110u);  // 060740AE mov.l 0x06074110,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060740B4u; c.r[4] = 0x2Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060740B4u) return; }  // 060740B0 jsr @r1 ; mov #44,r4
    c.r[14] += 32;  // 060740B4 add #32,r14
    c.r[15] = c.r[14];  // 060740B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060740B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060740BA mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060740BC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060740BE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060740C0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060740C2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060740D0u);  // 060740C4 mov.w 0x060740D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060740C6 rts ; mov.l @r15+,r8
}

void f_0607411C(SH2Context& c) {
    ran[1608] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607411C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607411E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074120 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074122 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074124 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074126 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074128 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607412A mov r15,r14
    c.r[1] = ld32(0x060741FCu);  // 0607412C mov.l 0x060741FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074132u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074132u) return; }  // 0607412E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074200u);  // 06074132 mov.l 0x06074200,r1
    c.r[1] = ld32(c.r[1]);  // 06074134 mov.l @r1,r1
    c.r[11] = ld32(0x06074204u);  // 06074136 mov.l 0x06074204,r11
    c.r[1] += 1;  // 06074138 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607413A mov.b @r1,r1
    c.r[12] = ld32(0x06074208u);  // 0607413C mov.l 0x06074208,r12
    c.r[2] = c.r[1] & 0xFFu;  // 0607413E extu.b r1,r2
    c.r[0] = c.r[2];  // 06074140 mov r2,r0
    c.t = c.r[0] == 0x1u;  // 06074142 cmp/eq #1,r0
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_060741DA; } }  // 06074144 bt/s 0x060741DA ; mov #1,r6
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 06074148 cmp/gt r6,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06074158; } }  // 0607414A bt/s 0x06074158 ; cmp/eq #3,r0
    c.t = (c.r[2] & c.r[2]) == 0;  // 0607414E tst r2,r2
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_0607415E; } }  // 06074150 bt/s 0x0607415E ; mov #0,r4
    goto L_06074228;  // 06074154 bra 0x06074228 ; nop
L_06074158:
    if (!c.t) { goto L_06074228; }  // 06074158 bf 0x06074228
    goto L_060741DA;  // 0607415A bra 0x060741DA ; nop
L_0607415E:
    c.r[8] = ld32(0x0607420Cu);  // 0607415E mov.l 0x0607420C,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x060741EEu);  // 06074160 mov.w 0x060741EE,r0
    c.r[1] = ld32(c.r[8]);  // 06074162 mov.l @r8,r1
    c.r[5] = 0x5u;  // 06074164 mov #5,r5
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06074166 mov.w @(r0,r1),r7
    c.r[7] = c.r[7] & 0xFFFFu;  // 06074168 extu.w r7,r7
    c.r[7] >>= 2;  // 0607416A shlr2 r7
    c.r[7] >>= 2;  // 0607416C shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0607416E shlr r7
    c.r[7] >>= 2;  // 06074170 shlr2 r7
    c.r[0] = ld32(0x06074210u);  // 06074172 mov.l 0x06074210,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06074178u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074178u) return; }  // 06074174 jsr @r0 ; mov.l r2,@-r15
    c.r[2] = ld32(0x06074214u);  // 06074178 mov.l 0x06074214,r2
    c.r[1] = 0x0u;  // 0607417A mov #0,r1
    st8(c.r[2], c.r[1]);  // 0607417C mov.b r1,@r2
    c.r[6] = ld32(0x06074218u);  // 0607417E mov.l 0x06074218,r6
    c.r[5] = c.r[6];  // 06074180 mov r6,r5
    c.r[4] = ld32(c.r[8]);  // 06074182 mov.l @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060741F0u);  // 06074184 mov.w 0x060741F0,r1
    c.r[4] += c.r[1];  // 06074186 add r1,r4
    c.r[1] = ld32(0x0607421Cu);  // 06074188 mov.l 0x0607421C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607418Eu; c.r[5] -= 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607418Eu) return; }  // 0607418A jsr @r1 ; add #-7,r5
    c.r[2] = 0x0u;  // 0607418E mov #0,r2
    c.r[15] += 4;  // 06074190 add #4,r15
    c.r[6] = 0x5u;  // 06074192 mov #5,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060741F2u);  // 06074194 mov.w 0x060741F2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060741F4u);  // 06074196 mov.w 0x060741F4,r7
    c.r[8] = ld32(c.r[8]);  // 06074198 mov.l @r8,r8
    c.r[0] = c.r[8];  // 0607419A mov r8,r0
L_0607419C:
    c.r[0] += c.r[2];  // 0607419C add r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607419E mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060741A0 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 060741A2 cmp/eq r7,r1
    if (c.t) { goto L_060741AE; }  // 060741A4 bt 0x060741AE
    c.r[2] += 1;  // 060741A6 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 060741A8 cmp/gt r6,r2
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_0607419C; } }  // 060741AA bf/s 0x0607419C ; mov r8,r0
L_060741AE:
    c.r[3] = 0x4u;  // 060741AE mov #4,r3
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 060741B0 cmp/gt r3,r2
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_060741C8; } }  // 060741B2 bt/s 0x060741C8 ; mov #0,r7
    c.r[6] = ld32(0x0607420Cu);  // 060741B6 mov.l 0x0607420C,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x060741F2u);  // 060741B8 mov.w 0x060741F2,r5
L_060741BA:
    c.r[1] = ld32(c.r[6]);  // 060741BA mov.l @r6,r1
    c.r[1] += c.r[2];  // 060741BC add r2,r1
    c.r[0] = c.r[1];  // 060741BE mov r1,r0
    c.r[2] += 1;  // 060741C0 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 060741C2 cmp/gt r3,r2
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[7]); if (k) { SH2_POLL(c); goto L_060741BA; } }  // 060741C4 bf/s 0x060741BA ; mov.b r7,@(r0,r5)
L_060741C8:
    c.r[1] = ld32(0x0607420Cu);  // 060741C8 mov.l 0x0607420C,r1
    c.r[2] = ld32(c.r[1]);  // 060741CA mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060741F6u);  // 060741CC mov.w 0x060741F6,r0
    c.r[1] = 0xFFFFFFFFu;  // 060741CE mov #-1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060741D0 mov.b r1,@(r0,r2)
    c.r[2] = ld32(0x06074220u);  // 060741D2 mov.l 0x06074220,r2
    c.r[1] = 0x4u;  // 060741D4 mov #4,r1
    st16(c.r[2], c.r[1]); goto L_0607430C;  // 060741D6 bra 0x0607430C ; mov.w r1,@r2
L_060741DA:
    c.r[1] = ld32(0x06074224u);  // 060741DA mov.l 0x06074224,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060741F8u);  // 060741DC mov.w 0x060741F8,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060741DE mov.w @(r0,r1),r2
    c.r[2] += 1;  // 060741E0 add #1,r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 060741E2 mov.w r2,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060741FAu);  // 060741E4 mov.w 0x060741FA,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060741E6 mov.w @(r0,r1),r2
    c.r[2] += 1;  // 060741E8 add #1,r2
    st16(c.r[0] + c.r[1], c.r[2]); goto L_0607430C;  // 060741EA bra 0x0607430C ; mov.w r2,@(r0,r1)
L_06074228:
    c.r[0] = ld32(0x060743E4u);  // 06074228 mov.l 0x060743E4,r0
    c.r[7] = 0xFFFFFFFFu;  // 0607422A mov #-1,r7
    c.r[6] = c.r[11];  // 0607422C mov r11,r6
    c.r[5] = 0x0u;  // 0607422E mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06074234u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074234u) return; }  // 06074230 jsr @r0 ; mov #15,r4
    c.r[0] = ld32(0x060743E8u);  // 06074234 mov.l 0x060743E8,r0
    c.r[5] = c.r[12];  // 06074236 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0607423Cu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607423Cu) return; }  // 06074238 jsr @r0 ; mov r11,r4
    c.r[2] = ld32(0x060743ECu);  // 0607423C mov.l 0x060743EC,r2
    c.r[8] = ld32(0x060743F0u);  // 0607423E mov.l 0x060743F0,r8
    c.r[9] = c.r[8];  // 06074240 mov r8,r9
    c.r[9] += 88;  // 06074242 add #88,r9
    c.r[10] = c.r[8];  // 06074244 mov r8,r10
    c.r[10] += 90;  // 06074246 add #90,r10
    c.r[0] = ld32(0x060743F4u);  // 06074248 mov.l 0x060743F4,r0
    c.r[5] = 0x0u;  // 0607424A mov #0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0607424C mov.w @r9,r1
    c.r[4] = c.r[12];  // 0607424E mov r12,r4
    st16(c.r[2], c.r[1]);  // 06074250 mov.w r1,@r2
    c.r[1] = 0x2u;  // 06074252 mov #2,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06074258u; st8(c.r[10], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074258u) return; }  // 06074254 jsr @r0 ; mov.b r1,@r10
    c.r[3] = c.r[0];  // 06074258 mov r0,r3
    c.r[1] = 0x0u;  // 0607425A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607425C mov.l r1,@-r15
    c.r[0] = ld32(0x060743F8u);  // 0607425E mov.l 0x060743F8,r0
    c.r[1] = ld32(c.r[8] + 16);  // 06074260 mov.l @(16,r8),r1
    c.r[7] = c.r[10];  // 06074262 mov r10,r7
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06074264 mov.l r1,@-r15
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06074266 mov.w @r9,r2
    c.r[1] = 0xAu;  // 06074268 mov #10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607426A mulu.w r1,r2
    c.r[6] = c.r[9];  // 0607426C mov r9,r6
    c.r[2] = ld32(c.r[8] + 8);  // 0607426E mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 06074270 sts macl,r1
    c.r[2] += c.r[1];  // 06074272 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06074274 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 06074276 mov.l @(4,r8),r1
    c.r[5] = c.r[11];  // 06074278 mov r11,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607427A mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 0607427C mov.l @r8,r1
    c.r[4] = c.r[3];  // 0607427E mov r3,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06074280 mov.l r1,@-r15
    c.r[1] = 0x2u;  // 06074282 mov #2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06074284 mov.l r1,@-r15
    c.r[8] = 0x1u;  // 06074286 mov #1,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074288 mov.l r8,@-r15
    c.r[1] = 0x4u;  // 0607428A mov #4,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06074290u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074290u) return; }  // 0607428C jsr @r0 ; mov.l r1,@-r15
    c.r[2] = ld32(0x060743FCu);  // 06074290 mov.l 0x060743FC,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060743CCu);  // 06074292 mov.w 0x060743CC,r0
    c.r[15] += 32;  // 06074294 add #32,r15
    c.r[7] = (uint32_t)(int16_t)ld16(0x060743CEu);  // 06074296 mov.w 0x060743CE,r7
    c.r[4] = (uint32_t)(int16_t)ld16(0x060743D0u);  // 06074298 mov.w 0x060743D0,r4
    c.r[6] = c.r[8];  // 0607429A mov r8,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0607429C mov.w @r9,r1
    c.r[5] = 0x5u;  // 0607429E mov #5,r5
    st16(c.r[0] + c.r[2], c.r[1]);  // 060742A0 mov.w r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060742A2 mov.b @r10,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060743D2u);  // 060742A4 mov.w 0x060743D2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060742A6 extu.b r1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 060742A8 mov.w r1,@(r0,r2)
    c.r[0] = ld32(0x06074400u);  // 060742AA mov.l 0x06074400,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060742B0u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060742B0u) return; }  // 060742AC jsr @r0 ; mov.l r8,@-r15
    c.r[2] = ld32(0x06074404u);  // 060742B0 mov.l 0x06074404,r2
    c.r[1] = 0x0u;  // 060742B2 mov #0,r1
    st8(c.r[2], c.r[1]);  // 060742B4 mov.b r1,@r2
    c.r[6] = ld32(0x06074408u);  // 060742B6 mov.l 0x06074408,r6
    c.r[5] = c.r[6];  // 060742B8 mov r6,r5
    c.r[8] = ld32(0x0607440Cu);  // 060742BA mov.l 0x0607440C,r8
    c.r[4] = ld32(c.r[8]);  // 060742BC mov.l @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060743D4u);  // 060742BE mov.w 0x060743D4,r1
    c.r[4] += c.r[1];  // 060742C0 add r1,r4
    c.r[1] = ld32(0x06074410u);  // 060742C2 mov.l 0x06074410,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060742C8u; c.r[5] -= 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060742C8u) return; }  // 060742C4 jsr @r1 ; add #-7,r5
    c.r[2] = 0x0u;  // 060742C8 mov #0,r2
    c.r[15] += 4;  // 060742CA add #4,r15
    c.r[6] = 0x5u;  // 060742CC mov #5,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060743D6u);  // 060742CE mov.w 0x060743D6,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060743D8u);  // 060742D0 mov.w 0x060743D8,r7
    c.r[8] = ld32(c.r[8]);  // 060742D2 mov.l @r8,r8
    c.r[0] = c.r[8];  // 060742D4 mov r8,r0
L_060742D6:
    c.r[0] += c.r[2];  // 060742D6 add r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060742D8 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060742DA extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 060742DC cmp/eq r7,r1
    if (c.t) { goto L_060742E8; }  // 060742DE bt 0x060742E8
    c.r[2] += 1;  // 060742E0 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 060742E2 cmp/gt r6,r2
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_060742D6; } }  // 060742E4 bf/s 0x060742D6 ; mov r8,r0
L_060742E8:
    c.r[3] = 0x4u;  // 060742E8 mov #4,r3
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 060742EA cmp/gt r3,r2
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06074302; } }  // 060742EC bt/s 0x06074302 ; mov #0,r7
    c.r[6] = ld32(0x0607440Cu);  // 060742F0 mov.l 0x0607440C,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x060743D6u);  // 060742F2 mov.w 0x060743D6,r5
L_060742F4:
    c.r[1] = ld32(c.r[6]);  // 060742F4 mov.l @r6,r1
    c.r[1] += c.r[2];  // 060742F6 add r2,r1
    c.r[0] = c.r[1];  // 060742F8 mov r1,r0
    c.r[2] += 1;  // 060742FA add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 060742FC cmp/gt r3,r2
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[7]); if (k) { SH2_POLL(c); goto L_060742F4; } }  // 060742FE bf/s 0x060742F4 ; mov.b r7,@(r0,r5)
L_06074302:
    c.r[1] = ld32(0x0607440Cu);  // 06074302 mov.l 0x0607440C,r1
    c.r[2] = ld32(c.r[1]);  // 06074304 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060743DAu);  // 06074306 mov.w 0x060743DA,r0
    c.r[1] = 0xFFFFFFFFu;  // 06074308 mov #-1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607430A mov.b r1,@(r0,r2)
L_0607430C:
    c.r[1] = ld32(0x06074414u);  // 0607430C mov.l 0x06074414,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074312u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074312u) return; }  // 0607430E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074418u);  // 06074312 mov.l 0x06074418,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074318u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074318u) return; }  // 06074314 jsr @r1 ; nop
    c.r[8] = ld32(0x0607441Cu);  // 06074318 mov.l 0x0607441C,r8
    c.r[9] = ld32(0x06074420u);  // 0607431A mov.l 0x06074420,r9
    c.r[6] = 0x0u;  // 0607431C mov #0,r6
    c.r[5] = c.r[8];  // 0607431E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06074324u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074324u) return; }  // 06074320 jsr @r9 ; mov #0,r4
    c.r[8] += 7;  // 06074324 add #7,r8
    c.r[6] = 0x0u;  // 06074326 mov #0,r6
    c.r[5] = c.r[8];  // 06074328 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607432Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607432Eu) return; }  // 0607432A jsr @r9 ; mov #0,r4
    c.r[1] = ld32(0x06074424u);  // 0607432E mov.l 0x06074424,r1
    c.r[1] = ld32(c.r[1]);  // 06074330 mov.l @r1,r1
    c.r[1] += 1;  // 06074332 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074334 mov.b @r1,r1
    c.r[2] = 0x1u;  // 06074336 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06074338 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0607433A cmp/hi r2,r1
    if (!c.t) { goto L_06074348; }  // 0607433C bf 0x06074348
    c.r[1] = ld32(0x0607440Cu);  // 0607433E mov.l 0x0607440C,r1
    c.r[5] = ld32(c.r[1]);  // 06074340 mov.l @r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060743D6u);  // 06074342 mov.w 0x060743D6,r1
    c.r[5] += c.r[1]; goto L_06074350;  // 06074344 bra 0x06074350 ; add r1,r5
L_06074348:
    c.r[1] = ld32(0x0607440Cu);  // 06074348 mov.l 0x0607440C,r1
    c.r[5] = ld32(c.r[1]);  // 0607434A mov.l @r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060743DCu);  // 0607434C mov.w 0x060743DC,r1
    c.r[5] += c.r[1];  // 0607434E add r1,r5
L_06074350:
    c.r[1] = ld32(0x06074420u);  // 06074350 mov.l 0x06074420,r1
    c.r[6] = 0x0u;  // 06074352 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06074358u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074358u) return; }  // 06074354 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074404u);  // 06074358 mov.l 0x06074404,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607435A mov.b @r1,r4
    c.r[4] += 47;  // 0607435C add #47,r4
    c.r[1] = ld32(0x06074428u);  // 0607435E mov.l 0x06074428,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074364u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074364u) return; }  // 06074360 jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0607442Cu);  // 06074364 mov.l 0x0607442C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074366 mov.b @r1,r2
    c.r[3] = c.r[2] & 0xFFu;  // 06074368 extu.b r2,r3
    c.r[1] = 0x5u;  // 0607436A mov #5,r1
    c.t = c.r[3] > c.r[1];  // 0607436C cmp/hi r1,r3
    { const bool k = !c.t; c.r[1] = 0xBu; if (k) { goto L_06074380; } }  // 0607436E bf/s 0x06074380 ; mov #11,r1
    c.t = c.r[3] > c.r[1];  // 06074372 cmp/hi r1,r3
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0607437C; } }  // 06074374 bf/s 0x0607437C ; mov r2,r1
    c.r[1] += 18; goto L_06074384;  // 06074378 bra 0x06074384 ; add #18,r1
L_0607437C:
    c.r[1] += 10; goto L_06074384;  // 0607437C bra 0x06074384 ; add #10,r1
L_06074380:
    c.r[1] = c.r[2];  // 06074380 mov r2,r1
    c.r[1] += 9;  // 06074382 add #9,r1
L_06074384:
    c.r[4] = c.r[1] & 0xFFu;  // 06074384 extu.b r1,r4
    c.r[4] <<= 2;  // 06074386 shll2 r4
    c.r[4] += c.r[4];  // 06074388 add r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060743DEu);  // 0607438A mov.w 0x060743DE,r1
    c.r[4] += c.r[1];  // 0607438C add r1,r4
    c.r[1] = ld32(0x06074430u);  // 0607438E mov.l 0x06074430,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074394u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074394u) return; }  // 06074390 jsr @r1 ; nop
    c.r[4] = c.r[0];  // 06074394 mov r0,r4
    c.r[5] = c.r[1];  // 06074396 mov r1,r5
    c.r[1] = ld32(0x06074434u);  // 06074398 mov.l 0x06074434,r1
    c.r[6] = ld32(c.r[1]);  // 0607439A mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0607439C mov.l @(4,r1),r7
    c.r[8] = ld32(0x06074438u);  // 0607439E mov.l 0x06074438,r8
    c.r[1] = ld32(0x0607443Cu);  // 060743A0 mov.l 0x0607443C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060743A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060743A6u) return; }  // 060743A2 jsr @r1 ; nop
    c.r[4] = c.r[0];  // 060743A6 mov r0,r4
    c.r[5] = c.r[1];  // 060743A8 mov r1,r5
    c.r[0] = ld32(0x06074440u);  // 060743AA mov.l 0x06074440,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060743B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060743B0u) return; }  // 060743AC jsr @r0 ; nop
    st32(c.r[8], c.r[0]);  // 060743B0 mov.l r0,@r8
    c.r[2] = ld32(0x06074444u);  // 060743B2 mov.l 0x06074444,r2
    c.r[1] = ld32(0x06074448u);  // 060743B4 mov.l 0x06074448,r1
    st32(c.r[2], c.r[1]);  // 060743B6 mov.l r1,@r2
    c.r[15] = c.r[14];  // 060743B8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060743BA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060743BC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060743BE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060743C0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060743C2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060743C4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060743E0u);  // 060743C6 mov.w 0x060743E0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060743C8 rts ; mov.l @r15+,r8
}

void f_0607444C(SH2Context& c) {
    ran[1609] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607444C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607444E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074450 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074452 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074454 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06074456 mov r15,r14
    c.r[10] = c.r[4];  // 06074458 mov r4,r10
    c.r[9] = c.r[6];  // 0607445A mov r6,r9
    c.r[6] = 0x0u;  // 0607445C mov #0,r6
    c.r[2] = 0x5u;  // 0607445E mov #5,r2
    c.r[1] = 0x0u;  // 06074460 mov #0,r1
    c.r[0] = c.r[9];  // 06074462 mov r9,r0
L_06074464:
    st8(c.r[0] + c.r[6], c.r[1]);  // 06074464 mov.b r1,@(r0,r6)
    c.r[0] = c.r[5];  // 06074466 mov r5,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06074468 mov.b r1,@(r0,r6)
    c.r[6] += 1;  // 0607446A add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[2];  // 0607446C cmp/gt r2,r6
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_06074464; } }  // 0607446E bf/s 0x06074464 ; mov r9,r0
    c.r[3] = c.r[5];  // 06074472 mov r5,r3
    c.r[3] += 6;  // 06074474 add #6,r3
    c.r[2] = c.r[9];  // 06074476 mov r9,r2
    c.r[2] += 6;  // 06074478 add #6,r2
    c.r[1] = 0xFFFFFFFFu;  // 0607447A mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0607447C mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0607447E mov.b r1,@r3
    c.r[6] = 0x0u;  // 06074480 mov #0,r6
    c.r[7] = 0x5u;  // 06074482 mov #5,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x060744D4u);  // 06074484 mov.w 0x060744D4,r3
    c.r[0] = c.r[10];  // 06074486 mov r10,r0
L_06074488:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06074488 mov.b @(r0,r6),r2
    c.r[1] = c.r[2] & 0xFFu;  // 0607448A extu.b r2,r1
    c.t = c.r[1] == c.r[3];  // 0607448C cmp/eq r3,r1
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0607449C; } }  // 0607448E bt/s 0x0607449C ; mov r5,r0
    st8(c.r[0] + c.r[6], c.r[2]);  // 06074492 mov.b r2,@(r0,r6)
    c.r[6] += 1;  // 06074494 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 06074496 cmp/gt r7,r6
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { SH2_POLL(c); goto L_06074488; } }  // 06074498 bf/s 0x06074488 ; mov r10,r0
L_0607449C:
    c.r[6] += 1;  // 0607449C add #1,r6
    c.r[8] = c.r[6] & 0xFFu;  // 0607449E extu.b r6,r8
    c.r[0] = ld32(0x060744D8u);  // 060744A0 mov.l 0x060744D8,r0
    c.r[5] = 0x1u;  // 060744A2 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060744A8u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060744A8u) return; }  // 060744A4 jsr @r0 ; mov r10,r4
    c.r[2] = c.r[0] & 0xFFu;  // 060744A8 extu.b r0,r2
    c.r[6] = 0x0u;  // 060744AA mov #0,r6
    c.r[3] = 0x5u;  // 060744AC mov #5,r3
L_060744AE:
    c.t = c.r[8] >= c.r[2];  // 060744AE cmp/hs r2,r8
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_060744C6; } }  // 060744B0 bt/s 0x060744C6 ; mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060744B4 mov.b @(r0,r8),r1
    c.r[0] = c.r[9];  // 060744B6 mov r9,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 060744B8 mov.b r1,@(r0,r6)
    c.r[6] += 1;  // 060744BA add #1,r6
    c.r[1] = c.r[8];  // 060744BC mov r8,r1
    c.r[1] += 1;  // 060744BE add #1,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[3];  // 060744C0 cmp/gt r3,r6
    { const bool k = !c.t; c.r[8] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_060744AE; } }  // 060744C2 bf/s 0x060744AE ; extu.b r1,r8
L_060744C6:
    c.r[15] = c.r[14];  // 060744C6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060744C8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060744CA mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060744CC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060744CE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060744D0 rts ; mov.l @r15+,r8
}

void f_060744DC(SH2Context& c) {
    ran[1610] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060744DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060744DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060744E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060744E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060744E4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060744E6 mov r15,r14
    c.r[1] = ld32(0x06074568u);  // 060744E8 mov.l 0x06074568,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060744EEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060744EEu) return; }  // 060744EA jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607456Cu);  // 060744EE mov.l 0x0607456C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060744F4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060744F4u) return; }  // 060744F0 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06074570u);  // 060744F4 mov.l 0x06074570,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060744FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060744FAu) return; }  // 060744F6 jsr @r1 ; nop
    c.r[8] = ld32(0x06074574u);  // 060744FA mov.l 0x06074574,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06074560u);  // 060744FC mov.w 0x06074560,r10
    c.r[9] = ld32(0x06074578u);  // 060744FE mov.l 0x06074578,r9
    c.r[1] = ld32(c.r[8]);  // 06074500 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06074502 mov #0,r5
    c.r[0] = c.r[1];  // 06074504 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06074506 mov.b @(r0,r10),r1
    c.r[4] = 0x0u;  // 06074508 mov #0,r4
    c.r[1] >>= 2;  // 0607450A shlr2 r1
    c.r[0] = 0xFu;  // 0607450C mov #15,r0
    c.r[1] &= c.r[0];  // 0607450E and r0,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06074514u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074514u) return; }  // 06074510 jsr @r9 ; mov r1,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06074562u);  // 06074514 mov.w 0x06074562,r2
    c.r[1] = ld32(c.r[8]);  // 06074516 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06074518 mov #0,r5
    c.r[0] = c.r[1];  // 0607451A mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0607451C mov.l @(r0,r2),r1
    c.r[4] = 0x0u;  // 0607451E mov #0,r4
    c.r[1] >>= 8;  // 06074520 shlr8 r1
    c.r[1] >>= 2;  // 06074522 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06074524 shlr r1
    c.r[1] >>= 2;  // 06074526 shlr2 r1
    c.r[0] = 0x1Fu;  // 06074528 mov #31,r0
    c.r[1] &= c.r[0];  // 0607452A and r0,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06074530u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074530u) return; }  // 0607452C jsr @r9 ; mov r1,r6
    c.r[1] = ld32(0x0607457Cu);  // 06074530 mov.l 0x0607457C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074536u; c.r[4] = 0x2Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074536u) return; }  // 06074532 jsr @r1 ; mov #45,r4
    c.r[1] = ld32(0x06074580u);  // 06074536 mov.l 0x06074580,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074538 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607453A extu.b r1,r3
    c.r[1] = ld32(c.r[8]);  // 0607453C mov.l @r8,r1
    c.r[2] = ld32(0x06074584u);  // 0607453E mov.l 0x06074584,r2
    c.r[0] = c.r[1];  // 06074540 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06074542 mov.b @(r0,r10),r1
    c.r[15] = c.r[14];  // 06074544 mov r14,r15
    c.r[1] >>= 2;  // 06074546 shlr2 r1
    c.r[0] = 0xFu;  // 06074548 mov #15,r0
    c.r[1] &= c.r[0];  // 0607454A and r0,r1
    c.r[1] -= 1;  // 0607454C add #-1,r1
    c.r[0] = c.r[3];  // 0607454E mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06074550 mov.b r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06074552 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06074554 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06074556 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06074558 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074564u);  // 0607455A mov.w 0x06074564,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607455C rts ; mov.l @r15+,r8
}

void f_06074588(SH2Context& c) {
    ran[1611] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607458A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607458C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607458E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074590 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074592 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06074594 mov r15,r14
    c.r[1] = ld32(0x060746C8u);  // 06074596 mov.l 0x060746C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607459Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607459Cu) return; }  // 06074598 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060746CCu);  // 0607459C mov.l 0x060746CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060745A2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060745A2u) return; }  // 0607459E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060746D0u);  // 060745A2 mov.l 0x060746D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060745A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060745A8u) return; }  // 060745A4 jsr @r1 ; nop
    c.r[10] = ld32(0x060746D4u);  // 060745A8 mov.l 0x060746D4,r10
    c.r[3] = ld32(c.r[10]);  // 060745AA mov.l @r10,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x060746C2u);  // 060745AC mov.w 0x060746C2,r6
    c.r[0] = c.r[3];  // 060745AE mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060745B0 mov.b @(r0,r6),r1
    c.r[2] = c.r[1];  // 060745B2 mov r1,r2
    c.r[2] >>= 2;  // 060745B4 shlr2 r2
    c.r[0] = 0xFu;  // 060745B6 mov #15,r0
    c.r[2] &= c.r[0];  // 060745B8 and r0,r2
    c.r[1] = ld32(0x060746D8u);  // 060745BA mov.l 0x060746D8,r1
    c.r[0] = c.r[2];  // 060745BC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060745BE mov.b @(r0,r1),r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x060746C4u);  // 060745C0 mov.w 0x060746C4,r8
    c.r[0] = c.r[3];  // 060745C2 mov r3,r0
    c.r[7] = ld32(c.r[0] + c.r[8]);  // 060745C4 mov.l @(r0,r8),r7
    c.r[11] = c.r[1] & 0xFFu;  // 060745C6 extu.b r1,r11
    c.r[1] = c.r[7];  // 060745C8 mov r7,r1
    c.r[1] >>= 8;  // 060745CA shlr8 r1
    c.r[1] >>= 2;  // 060745CC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060745CE shlr r1
    c.r[1] >>= 2;  // 060745D0 shlr2 r1
    c.r[0] = 0x1Fu;  // 060745D2 mov #31,r0
    c.r[1] &= c.r[0];  // 060745D4 and r0,r1
    c.t = c.r[1] > c.r[11];  // 060745D6 cmp/hi r11,r1
    { const bool k = !c.t; c.r[2] = 0x1Fu; if (k) { goto L_060745F0; } }  // 060745D8 bf/s 0x060745F0 ; mov #31,r2
    c.r[2] &= c.r[11];  // 060745DC and r11,r2
    c.r[2] <<= 8;  // 060745DE shll8 r2
    c.r[2] <<= 2;  // 060745E0 shll2 r2
    c.r[2] += c.r[2];  // 060745E2 add r2,r2
    c.r[2] <<= 2;  // 060745E4 shll2 r2
    c.r[1] = ld32(0x060746DCu);  // 060745E6 mov.l 0x060746DC,r1
    c.r[1] &= c.r[7];  // 060745E8 and r7,r1
    c.r[2] |= c.r[1];  // 060745EA or r1,r2
    c.r[0] = c.r[3];  // 060745EC mov r3,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 060745EE mov.l r2,@(r0,r8)
L_060745F0:
    c.r[9] = ld32(0x060746E0u);  // 060745F0 mov.l 0x060746E0,r9
    c.r[1] = ld32(c.r[10]);  // 060745F2 mov.l @r10,r1
    c.r[5] = 0x0u;  // 060745F4 mov #0,r5
    c.r[0] = c.r[1];  // 060745F6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060745F8 mov.b @(r0,r6),r1
    c.r[4] = 0x0u;  // 060745FA mov #0,r4
    c.r[1] >>= 2;  // 060745FC shlr2 r1
    c.r[0] = 0xFu;  // 060745FE mov #15,r0
    c.r[1] &= c.r[0];  // 06074600 and r0,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06074606u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074606u) return; }  // 06074602 jsr @r9 ; mov r1,r6
    c.r[1] = ld32(c.r[10]);  // 06074606 mov.l @r10,r1
    c.r[5] = 0x0u;  // 06074608 mov #0,r5
    c.r[0] = c.r[1];  // 0607460A mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0607460C mov.l @(r0,r8),r1
    c.r[4] = 0x0u;  // 0607460E mov #0,r4
    c.r[1] >>= 8;  // 06074610 shlr8 r1
    c.r[1] >>= 2;  // 06074612 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06074614 shlr r1
    c.r[1] >>= 2;  // 06074616 shlr2 r1
    c.r[0] = 0x1Fu;  // 06074618 mov #31,r0
    c.r[1] &= c.r[0];  // 0607461A and r0,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06074620u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074620u) return; }  // 0607461C jsr @r9 ; mov r1,r6
    c.r[1] = 0x1Du;  // 06074620 mov #29,r1
    c.t = c.r[11] > c.r[1];  // 06074622 cmp/hi r1,r11
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06074646; } }  // 06074624 bf/s 0x06074646 ; mov #0,r8
    c.r[1] = c.r[11];  // 06074628 mov r11,r1
    c.r[1] -= 29;  // 0607462A add #-29,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607462C cmp/ge r1,r8
    { const bool k = c.t; c.r[10] = c.r[9]; if (k) { goto L_06074648; } }  // 0607462E bt/s 0x06074648 ; mov r9,r10
    c.r[9] = c.r[1];  // 06074632 mov r1,r9
    c.r[6] = c.r[8];  // 06074634 mov r8,r6
L_06074636:
    c.r[6] += 30;  // 06074636 add #30,r6
    c.r[5] = 0x0u;  // 06074638 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607463Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607463Eu) return; }  // 0607463A jsr @r10 ; mov #0,r4
    c.r[8] += 1;  // 0607463E add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06074640 cmp/ge r9,r8
    { const bool k = !c.t; c.r[6] = c.r[8]; if (k) { SH2_POLL(c); goto L_06074636; } }  // 06074642 bf/s 0x06074636 ; mov r8,r6
L_06074646:
    c.r[8] = 0x0u;  // 06074646 mov #0,r8
L_06074648:
    c.r[1] = 0u - c.r[11];  // 06074648 neg r11,r1
    c.r[1] += 31;  // 0607464A add #31,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607464C cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[1]; if (k) { goto L_0607465E; } }  // 0607464E bt/s 0x0607465E ; mov r1,r9
    c.r[10] = ld32(0x060746E4u);  // 06074652 mov.l 0x060746E4,r10
L_06074654:
    { const uint32_t x = c.r[10]; c.pr = 0x06074658u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074658u) return; }  // 06074654 jsr @r10 ; mov #0,r4
    c.r[8] += 1;  // 06074658 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 0607465A cmp/ge r9,r8
    if (!c.t) { SH2_POLL(c); goto L_06074654; }  // 0607465C bf 0x06074654
L_0607465E:
    c.r[1] = ld32(0x060746E8u);  // 0607465E mov.l 0x060746E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074664u; c.r[4] = 0x2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074664u) return; }  // 06074660 jsr @r1 ; mov #46,r4
    c.r[1] = ld32(0x060746ECu);  // 06074664 mov.l 0x060746EC,r1
    c.r[2] = ld32(0x060746F0u);  // 06074666 mov.l 0x060746F0,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060746C4u);  // 06074668 mov.w 0x060746C4,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607466A mov.b @r1,r1
    c.r[6] = 0x2u;  // 0607466C mov #2,r6
    c.r[3] = c.r[1] & 0xFFu;  // 0607466E extu.b r1,r3
    c.r[1] = ld32(0x060746D4u);  // 06074670 mov.l 0x060746D4,r1
    c.r[1] = ld32(c.r[1]);  // 06074672 mov.l @r1,r1
    c.r[5] = 0x9u;  // 06074674 mov #9,r5
    c.r[0] = c.r[1];  // 06074676 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06074678 mov.l @(r0,r7),r1
    c.r[4] = 0xBu;  // 0607467A mov #11,r4
    c.r[1] >>= 8;  // 0607467C shlr8 r1
    c.r[1] >>= 2;  // 0607467E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06074680 shlr r1
    c.r[1] >>= 2;  // 06074682 shlr2 r1
    c.r[0] = 0x1Fu;  // 06074684 mov #31,r0
    c.r[1] &= c.r[0];  // 06074686 and r0,r1
    c.r[1] -= 1;  // 06074688 add #-1,r1
    c.r[0] = c.r[3];  // 0607468A mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607468C mov.b r1,@(r0,r2)
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607468E mov.l r11,@-r15
    c.r[2] = 0x1u;  // 06074690 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06074692 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06074694 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06074696 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06074698 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607469A mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0607469C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607469E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060746A0 mov.l r2,@-r15
    c.r[1] = 0x5u;  // 060746A2 mov #5,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060746A4 mov.l r1,@-r15
    c.r[1] = 0x7u;  // 060746A6 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060746A8 mov.l r1,@-r15
    c.r[1] = ld32(0x060746F4u);  // 060746AA mov.l 0x060746F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060746B0u; c.r[7] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060746B0u) return; }  // 060746AC jsr @r1 ; mov #2,r7
    c.r[15] = c.r[14];  // 060746B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060746B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060746B4 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060746B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060746B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060746BA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060746C6u);  // 060746BC mov.w 0x060746C6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060746BE rts ; mov.l @r15+,r8
}

void f_060746F8(SH2Context& c) {
    ran[1612] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060746F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060746FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060746FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060746FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074700 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074702 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06074704 mov r15,r14
    c.r[1] = ld32(0x06074778u);  // 06074706 mov.l 0x06074778,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607470Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607470Cu) return; }  // 06074708 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607477Cu);  // 0607470C mov.l 0x0607477C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074712u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074712u) return; }  // 0607470E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06074780u);  // 06074712 mov.l 0x06074780,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074718u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074718u) return; }  // 06074714 jsr @r1 ; mov #0,r9
    c.r[10] = ld32(0x06074784u);  // 06074718 mov.l 0x06074784,r10
    c.r[11] = ld32(0x06074788u);  // 0607471A mov.l 0x06074788,r11
    c.r[8] = c.r[9] & 0xFFu;  // 0607471C extu.b r9,r8
L_0607471E:
    c.r[4] = ld32(0x0607478Cu);  // 0607471E mov.l 0x0607478C,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06074724u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074724u) return; }  // 06074720 jsr @r10 ; mov #23,r5
    c.r[5] = 0x1Au;  // 06074724 mov #26,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607472Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607472Au) return; }  // 06074726 jsr @r10 ; mov r0,r4
    c.r[6] = 0x2u;  // 0607472A mov #2,r6
    c.r[5] = c.r[8];  // 0607472C mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06074732u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074732u) return; }  // 0607472E jsr @r11 ; mov r0,r4
    c.r[9] += 1;  // 06074732 add #1,r9
    c.r[1] = 0x3u;  // 06074734 mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06074736 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_0607471E; } }  // 06074738 bf/s 0x0607471E ; extu.b r9,r8
    c.r[1] = ld32(0x06074790u);  // 0607473C mov.l 0x06074790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074742u; c.r[4] = 0x31u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074742u) return; }  // 0607473E jsr @r1 ; mov #49,r4
    c.r[1] = ld32(0x06074794u);  // 06074742 mov.l 0x06074794,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074744 mov.b @r1,r1
    c.r[2] = ld32(0x06074798u);  // 06074746 mov.l 0x06074798,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06074748 extu.b r1,r3
    c.r[1] = ld32(0x0607479Cu);  // 0607474A mov.l 0x0607479C,r1
    c.r[1] = ld32(c.r[1]);  // 0607474C mov.l @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06074772u);  // 0607474E mov.w 0x06074772,r7
    c.r[0] = c.r[1];  // 06074750 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06074752 mov.b @(r0,r7),r1
    c.r[15] = c.r[14];  // 06074754 mov r14,r15
    c.r[1] >>= 2;  // 06074756 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06074758 shlr r1
    c.r[0] = 0x3u;  // 0607475A mov #3,r0
    c.r[1] &= c.r[0];  // 0607475C and r0,r1
    c.r[0] = c.r[3];  // 0607475E mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06074760 mov.b r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06074762 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06074764 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06074766 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06074768 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607476A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074774u);  // 0607476C mov.w 0x06074774,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607476E rts ; mov.l @r15+,r8
}

void f_060747A0(SH2Context& c) {
    ran[1613] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060747A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060747A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060747A4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060747A6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060747A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060747AA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060747AC mov r15,r14
    c.r[1] = ld32(0x06074824u);  // 060747AE mov.l 0x06074824,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060747B4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747B4u) return; }  // 060747B0 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06074828u);  // 060747B4 mov.l 0x06074828,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060747BAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747BAu) return; }  // 060747B6 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607482Cu);  // 060747BA mov.l 0x0607482C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060747C0u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747C0u) return; }  // 060747BC jsr @r1 ; mov #0,r9
    c.r[10] = ld32(0x06074830u);  // 060747C0 mov.l 0x06074830,r10
    c.r[11] = ld32(0x06074834u);  // 060747C2 mov.l 0x06074834,r11
    c.r[8] = c.r[9] & 0xFFFFu;  // 060747C4 extu.w r9,r8
L_060747C6:
    c.r[4] = ld32(0x06074838u);  // 060747C6 mov.l 0x06074838,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060747CCu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747CCu) return; }  // 060747C8 jsr @r10 ; mov #23,r5
    c.r[5] = 0x1Cu;  // 060747CC mov #28,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060747D2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747D2u) return; }  // 060747CE jsr @r10 ; mov r0,r4
    c.r[5] = c.r[8];  // 060747D2 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060747D8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747D8u) return; }  // 060747D4 jsr @r10 ; mov r0,r4
    c.r[6] = 0x0u;  // 060747D8 mov #0,r6
    c.r[5] = c.r[0];  // 060747DA mov r0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060747E0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747E0u) return; }  // 060747DC jsr @r11 ; mov #0,r4
    c.r[9] += 1;  // 060747E0 add #1,r9
    c.r[1] = 0x3u;  // 060747E2 mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060747E4 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060747C6; } }  // 060747E6 bf/s 0x060747C6 ; extu.w r9,r8
    c.r[1] = ld32(0x0607483Cu);  // 060747EA mov.l 0x0607483C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060747F0u; c.r[4] = 0x32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060747F0u) return; }  // 060747EC jsr @r1 ; mov #50,r4
    c.r[1] = ld32(0x06074840u);  // 060747F0 mov.l 0x06074840,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060747F2 mov.b @r1,r1
    c.r[2] = ld32(0x06074844u);  // 060747F4 mov.l 0x06074844,r2
    c.r[3] = c.r[1] & 0xFFu;  // 060747F6 extu.b r1,r3
    c.r[1] = ld32(0x06074848u);  // 060747F8 mov.l 0x06074848,r1
    c.r[1] = ld32(c.r[1]);  // 060747FA mov.l @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607481Eu);  // 060747FC mov.w 0x0607481E,r7
    c.r[0] = c.r[1];  // 060747FE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06074800 mov.b @(r0,r7),r1
    c.r[15] = c.r[14];  // 06074802 mov r14,r15
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06074804 shlr r1
    c.r[0] = 0x3u;  // 06074806 mov #3,r0
    c.r[1] &= c.r[0];  // 06074808 and r0,r1
    c.r[0] = c.r[3];  // 0607480A mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607480C mov.b r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607480E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06074810 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06074812 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06074814 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06074816 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074820u);  // 06074818 mov.w 0x06074820,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607481A rts ; mov.l @r15+,r8
}

void f_0607484C(SH2Context& c) {
    ran[1614] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607484C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607484E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074850 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074852 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074854 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074856 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06074858 mov r15,r14
    c.r[1] = ld32(0x060748CCu);  // 0607485A mov.l 0x060748CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074860u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074860u) return; }  // 0607485C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060748D0u);  // 06074860 mov.l 0x060748D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074866u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074866u) return; }  // 06074862 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060748D4u);  // 06074866 mov.l 0x060748D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607486Cu; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607486Cu) return; }  // 06074868 jsr @r1 ; mov #0,r9
    c.r[10] = ld32(0x060748D8u);  // 0607486C mov.l 0x060748D8,r10
    c.r[11] = ld32(0x060748DCu);  // 0607486E mov.l 0x060748DC,r11
    c.r[8] = c.r[9] & 0xFFFFu;  // 06074870 extu.w r9,r8
L_06074872:
    c.r[4] = ld32(0x060748E0u);  // 06074872 mov.l 0x060748E0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06074878u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074878u) return; }  // 06074874 jsr @r10 ; mov #23,r5
    c.r[5] = 0x1Du;  // 06074878 mov #29,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607487Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607487Eu) return; }  // 0607487A jsr @r10 ; mov r0,r4
    c.r[5] = c.r[8];  // 0607487E mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06074884u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074884u) return; }  // 06074880 jsr @r10 ; mov r0,r4
    c.r[6] = 0x0u;  // 06074884 mov #0,r6
    c.r[5] = c.r[0];  // 06074886 mov r0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0607488Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607488Cu) return; }  // 06074888 jsr @r11 ; mov #0,r4
    c.r[9] += 1;  // 0607488C add #1,r9
    c.r[1] = 0x1u;  // 0607488E mov #1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06074890 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06074872; } }  // 06074892 bf/s 0x06074872 ; extu.w r9,r8
    c.r[1] = ld32(0x060748E4u);  // 06074896 mov.l 0x060748E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607489Cu; c.r[4] = 0x33u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607489Cu) return; }  // 06074898 jsr @r1 ; mov #51,r4
    c.r[1] = ld32(0x060748E8u);  // 0607489C mov.l 0x060748E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607489E mov.b @r1,r1
    c.r[2] = ld32(0x060748ECu);  // 060748A0 mov.l 0x060748EC,r2
    c.r[3] = c.r[1] & 0xFFu;  // 060748A2 extu.b r1,r3
    c.r[1] = ld32(0x060748F0u);  // 060748A4 mov.l 0x060748F0,r1
    c.r[1] = ld32(c.r[1]);  // 060748A6 mov.l @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060748C8u);  // 060748A8 mov.w 0x060748C8,r7
    c.r[0] = c.r[1];  // 060748AA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060748AC mov.b @(r0,r7),r1
    c.r[15] = c.r[14];  // 060748AE mov r14,r15
    c.r[0] = 0x1u;  // 060748B0 mov #1,r0
    c.r[1] &= c.r[0];  // 060748B2 and r0,r1
    c.r[0] = c.r[3];  // 060748B4 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 060748B6 mov.b r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060748B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060748BA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060748BC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060748BE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060748C0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060748CAu);  // 060748C2 mov.w 0x060748CA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060748C4 rts ; mov.l @r15+,r8
}

void f_060748F4(SH2Context& c) {
    ran[1615] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060748F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060748F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060748F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060748FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060748FC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060748FE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074900 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074902 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074AB8u);  // 06074904 mov.w 0x06074AB8,r3
    c.r[15] += c.r[3];  // 06074906 add r3,r15
    c.r[14] = c.r[15];  // 06074908 mov r15,r14
    c.r[12] = ld32(0x06074AD0u);  // 0607490A mov.l 0x06074AD0,r12
    c.r[11] = ld32(0x06074AD4u);  // 0607490C mov.l 0x06074AD4,r11
    c.r[1] = ld32(0x06074AD8u);  // 0607490E mov.l 0x06074AD8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074ABAu);  // 06074910 mov.w 0x06074ABA,r3
    c.r[2] = ld32(c.r[1]);  // 06074912 mov.l @r1,r2
    c.r[3] += c.r[14];  // 06074914 add r14,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06074ABCu);  // 06074916 mov.w 0x06074ABC,r1
    c.r[0] = c.r[2];  // 06074918 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607491A mov.b @(r0,r1),r1
    c.r[4] = 0x0u;  // 0607491C mov #0,r4
    c.r[0] = c.r[1];  // 0607491E mov r1,r0
    c.r[0] &= 0x4u;  // 06074920 and #4,r0
    c.r[1] = ld32(0x06074ADCu);  // 06074922 mov.l 0x06074ADC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074928u; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074928u) return; }  // 06074924 jsr @r1 ; mov.l r0,@r3
    c.r[8] = ld32(0x06074AE0u);  // 06074928 mov.l 0x06074AE0,r8
    c.r[2] = c.r[8];  // 0607492A mov r8,r2
    c.r[2] += 88;  // 0607492C add #88,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06074ABEu);  // 0607492E mov.w 0x06074ABE,r13
    c.r[3] = c.r[14];  // 06074930 mov r14,r3
    c.r[3] += c.r[13];  // 06074932 add r13,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074AC0u);  // 06074934 mov.w 0x06074AC0,r0
    c.r[0] += c.r[14];  // 06074936 add r14,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x06074AC2u);  // 06074938 mov.w 0x06074AC2,r7
    c.r[10] = c.r[14];  // 0607493A mov r14,r10
    c.r[10] += c.r[7];  // 0607493C add r7,r10
    c.r[9] = ld32(0x06074AE4u);  // 0607493E mov.l 0x06074AE4,r9
    c.r[6] = 0x1u;  // 06074940 mov #1,r6
    c.r[5] = 0xFFFFFFFFu;  // 06074942 mov #-1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06074944 mov.w @r2,r1
    c.r[4] = 0x11u;  // 06074946 mov #17,r4
    st32(c.r[0], c.r[3]);  // 06074948 mov.l r3,@r0
    c.r[0] = c.r[14];  // 0607494A mov r14,r0
    st16(c.r[0] + c.r[13], c.r[1]);  // 0607494C mov.w r1,@(r0,r13)
    c.r[1] = 0x30u;  // 0607494E mov #48,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06074950 mov.b r1,@(r0,r7)
    c.r[7] = c.r[12];  // 06074952 mov r12,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06074954 mov.w @r2,r1
    c.r[3] = ld32(0x06074AE8u);  // 06074956 mov.l 0x06074AE8,r3
    st16(c.r[9], c.r[1]);  // 06074958 mov.w r1,@r9
    { const uint32_t x = c.r[3]; c.pr = 0x0607495Eu; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607495Eu) return; }  // 0607495A jsr @r3 ; mov.l r11,@-r15
    c.r[0] = 0x0u;  // 0607495E mov #0,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06074960 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074962 mov.l r14,@-r15
    c.r[0] = c.r[14];  // 06074964 mov r14,r0
    c.r[1] = 0xAu;  // 06074966 mov #10,r1
    c.r[3] = 0x0u;  // 06074968 mov #0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0607496A mov.w @(r0,r13),r2
    c.r[7] = c.r[10];  // 0607496C mov r10,r7
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607496E mulu.w r1,r2
    c.r[5] = c.r[11];  // 06074970 mov r11,r5
    c.r[2] = ld32(c.r[8] + 8);  // 06074972 mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 06074974 sts macl,r1
    c.r[2] += c.r[1];  // 06074976 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06074978 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0607497A mov.l @(4,r8),r1
    c.r[4] = c.r[12];  // 0607497C mov r12,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607497E mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 06074980 mov.l @r8,r1
    c.r[0] = 0x1u;  // 06074982 mov #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06074984 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06074986 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06074988 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607498A mov.l r3,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074AC0u);  // 0607498C mov.w 0x06074AC0,r3
    c.r[3] += c.r[14];  // 0607498E add r14,r3
    c.r[0] = ld32(0x06074AECu);  // 06074990 mov.l 0x06074AEC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06074996u; c.r[6] = ld32(c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074996u) return; }  // 06074992 jsr @r0 ; mov.l @r3,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074AC4u);  // 06074996 mov.w 0x06074AC4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06074998 mov.w @r9,r1
    c.r[3] += c.r[14];  // 0607499A add r14,r3
    c.r[7] = ld32(c.r[8] + 12);  // 0607499C mov.l @(12,r8),r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607499E extu.w r1,r1
    c.r[0] = c.r[1];  // 060749A0 mov r1,r0
    c.r[0] += c.r[0];  // 060749A2 add r0,r0
    st32(c.r[3], c.r[0]);  // 060749A4 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074AC4u);  // 060749A6 mov.w 0x06074AC4,r3
    c.r[3] += c.r[14];  // 060749A8 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 060749AA mov.l @r3,r0
    c.r[0] += c.r[1];  // 060749AC add r1,r0
    st32(c.r[3], c.r[0]);  // 060749AE mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074AC4u);  // 060749B0 mov.w 0x06074AC4,r3
    c.r[3] += c.r[14];  // 060749B2 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 060749B4 mov.l @r3,r0
    c.r[0] <<= 2;  // 060749B6 shll2 r0
    st32(c.r[3], c.r[0]);  // 060749B8 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074AC4u);  // 060749BA mov.w 0x06074AC4,r3
    c.r[3] += c.r[14];  // 060749BC add r14,r3
    c.r[0] = ld32(c.r[3]);  // 060749BE mov.l @r3,r0
    c.r[2] = ld32(0x06074AF0u);  // 060749C0 mov.l 0x06074AF0,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 060749C2 mov.l r2,@(r0,r7)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074AC4u);  // 060749C4 mov.w 0x06074AC4,r0
    c.r[1] = ld32(c.r[8] + 12);  // 060749C6 mov.l @(12,r8),r1
    c.r[0] += c.r[14];  // 060749C8 add r14,r0
    c.r[3] = ld32(c.r[0]);  // 060749CA mov.l @r0,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06074AC6u);  // 060749CC mov.w 0x06074AC6,r7
    c.r[3] += c.r[1];  // 060749CE add r1,r3
    st32(c.r[0], c.r[3]);  // 060749D0 mov.l r3,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074AC4u);  // 060749D2 mov.w 0x06074AC4,r0
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 060749D4 mov.l @(r0,r14),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06074AC8u);  // 060749D6 mov.w 0x06074AC8,r1
    st32(c.r[3] + 4, c.r[2]);  // 060749D8 mov.l r2,@(4,r3)
    c.r[2] = ld32(0x06074AF4u);  // 060749DA mov.l 0x06074AF4,r2
    c.r[0] = c.r[2];  // 060749DC mov r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074ABAu);  // 060749DE mov.w 0x06074ABA,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060749E0 mov.w @(r0,r1),r1
    c.r[3] += c.r[14];  // 060749E2 add r14,r3
    c.r[1] += 1;  // 060749E4 add #1,r1
    st16(c.r[0] + c.r[7], c.r[1]);  // 060749E6 mov.w r1,@(r0,r7)
    c.r[3] = ld32(c.r[3]);  // 060749E8 mov.l @r3,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060749EA tst r3,r3
    { const bool k = !c.t; c.r[15] += 36; if (k) { goto L_060749F4; } }  // 060749EC bf/s 0x060749F4 ; add #36,r15
    goto L_06074B04;  // 060749F0 bra 0x06074B04 ; nop
L_060749F4:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074ACAu);  // 060749F4 mov.w 0x06074ACA,r9
    c.r[10] = ld32(0x06074AF8u);  // 060749F6 mov.l 0x06074AF8,r10
    c.r[8] = ld32(0x06074AFCu);  // 060749F8 mov.l 0x06074AFC,r8
    c.r[5] = 0x1Bu;  // 060749FA mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A00u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A00u) return; }  // 060749FC jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06074A00 mov r0,r1
    c.r[5] = c.r[9];  // 06074A02 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A08u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A08u) return; }  // 06074A04 jsr @r8 ; mov r1,r4
    c.r[11] = c.r[0];  // 06074A08 mov r0,r11
    c.r[5] = 0x1Bu;  // 06074A0A mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A10u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A10u) return; }  // 06074A0C jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06074A10 mov r0,r1
    c.r[5] = c.r[9];  // 06074A12 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A18u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A18u) return; }  // 06074A14 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06074A18 mov r0,r1
    c.r[11] += 2;  // 06074A1A add #2,r11
    c.r[1] += 3;  // 06074A1C add #3,r1
    c.r[0] = 0x0u;  // 06074A1E mov #0,r0
    c.r[6] = 0x1u;  // 06074A20 mov #1,r6
    c.r[5] = 0xFFFFFFFFu;  // 06074A22 mov #-1,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06074A24 mov.b @r11,r7
    c.r[4] = 0x0u;  // 06074A26 mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074A28 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06074A2A extu.b r7,r7
    c.r[7] <<= 8;  // 06074A2C shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06074A2E extu.b r1,r1
    c.r[7] |= c.r[1];  // 06074A30 or r1,r7
    c.r[11] = ld32(0x06074B00u);  // 06074A32 mov.l 0x06074B00,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06074A38u; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A38u) return; }  // 06074A34 jsr @r11 ; mov.l r0,@-r15
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074ACCu);  // 06074A38 mov.w 0x06074ACC,r9
    c.r[5] = 0x1Bu;  // 06074A3A mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A40u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A40u) return; }  // 06074A3C jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06074A40 mov r0,r1
    c.r[5] = c.r[9];  // 06074A42 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A48u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A48u) return; }  // 06074A44 jsr @r8 ; mov r1,r4
    c.r[12] = c.r[0];  // 06074A48 mov r0,r12
    c.r[5] = 0x1Bu;  // 06074A4A mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A50u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A50u) return; }  // 06074A4C jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06074A50 mov r0,r1
    c.r[5] = c.r[9];  // 06074A52 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A58u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A58u) return; }  // 06074A54 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06074A58 mov r0,r1
    c.r[12] += 2;  // 06074A5A add #2,r12
    c.r[1] += 3;  // 06074A5C add #3,r1
    c.r[3] = 0x0u;  // 06074A5E mov #0,r3
    c.r[6] = 0x2u;  // 06074A60 mov #2,r6
    c.r[5] = 0xAu;  // 06074A62 mov #10,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06074A64 mov.b @r12,r7
    c.r[4] = 0x0u;  // 06074A66 mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074A68 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06074A6A extu.b r7,r7
    c.r[7] <<= 8;  // 06074A6C shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06074A6E extu.b r1,r1
    c.r[7] |= c.r[1];  // 06074A70 or r1,r7
    { const uint32_t x = c.r[11]; c.pr = 0x06074A76u; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A76u) return; }  // 06074A72 jsr @r11 ; mov.l r3,@-r15
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074ACEu);  // 06074A76 mov.w 0x06074ACE,r9
    c.r[5] = 0x1Bu;  // 06074A78 mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A7Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A7Eu) return; }  // 06074A7A jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06074A7E mov r0,r1
    c.r[5] = c.r[9];  // 06074A80 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A86u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A86u) return; }  // 06074A82 jsr @r8 ; mov r1,r4
    c.r[12] = c.r[0];  // 06074A86 mov r0,r12
    c.r[5] = 0x1Bu;  // 06074A88 mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A8Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A8Eu) return; }  // 06074A8A jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06074A8E mov r0,r1
    c.r[5] = c.r[9];  // 06074A90 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074A96u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074A96u) return; }  // 06074A92 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06074A96 mov r0,r1
    c.r[12] += 2;  // 06074A98 add #2,r12
    c.r[1] += 3;  // 06074A9A add #3,r1
    c.r[0] = 0x0u;  // 06074A9C mov #0,r0
    c.r[6] = 0x2u;  // 06074A9E mov #2,r6
    c.r[5] = 0x17u;  // 06074AA0 mov #23,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06074AA2 mov.b @r12,r7
    c.r[4] = 0x0u;  // 06074AA4 mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074AA6 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06074AA8 extu.b r7,r7
    c.r[7] <<= 8;  // 06074AAA shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06074AAC extu.b r1,r1
    c.r[7] |= c.r[1];  // 06074AAE or r1,r7
    { const uint32_t x = c.r[11]; c.pr = 0x06074AB4u; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074AB4u) return; }  // 06074AB0 jsr @r11 ; mov.l r0,@-r15
    c.r[15] += 12; goto L_06074B4E;  // 06074AB4 bra 0x06074B4E ; add #12,r15
L_06074B04:
    c.r[10] = (uint32_t)(int16_t)ld16(0x06074C72u);  // 06074B04 mov.w 0x06074C72,r10
    c.r[9] = ld32(0x06074C7Cu);  // 06074B06 mov.l 0x06074C7C,r9
    c.r[8] = ld32(0x06074C80u);  // 06074B08 mov.l 0x06074C80,r8
    c.r[5] = 0x1Bu;  // 06074B0A mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B10u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B10u) return; }  // 06074B0C jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 06074B10 mov r0,r1
    c.r[5] = c.r[10];  // 06074B12 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B18u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B18u) return; }  // 06074B14 jsr @r8 ; mov r1,r4
    c.r[11] = c.r[0];  // 06074B18 mov r0,r11
    c.r[5] = 0x1Bu;  // 06074B1A mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B20u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B20u) return; }  // 06074B1C jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 06074B20 mov r0,r1
    c.r[5] = c.r[10];  // 06074B22 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B28u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B28u) return; }  // 06074B24 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06074B28 mov r0,r1
    c.r[11] += 2;  // 06074B2A add #2,r11
    c.r[1] += 3;  // 06074B2C add #3,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074C74u);  // 06074B2E mov.w 0x06074C74,r3
    c.r[3] += c.r[14];  // 06074B30 add r14,r3
    c.r[6] = 0x2u;  // 06074B32 mov #2,r6
    c.r[5] = 0xAu;  // 06074B34 mov #10,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06074B36 mov.b @r11,r7
    c.r[4] = 0x0u;  // 06074B38 mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074B3A mov.b @r1,r1
    c.r[0] = ld32(0x06074C84u);  // 06074B3C mov.l 0x06074C84,r0
    c.r[3] = ld32(c.r[3]);  // 06074B3E mov.l @r3,r3
    c.r[7] = c.r[7] & 0xFFu;  // 06074B40 extu.b r7,r7
    c.r[7] <<= 8;  // 06074B42 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06074B44 extu.b r1,r1
    c.r[7] |= c.r[1];  // 06074B46 or r1,r7
    { const uint32_t x = c.r[0]; c.pr = 0x06074B4Cu; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B4Cu) return; }  // 06074B48 jsr @r0 ; mov.l r3,@-r15
    c.r[15] += 4;  // 06074B4C add #4,r15
L_06074B4E:
    c.r[1] = ld32(0x06074C88u);  // 06074B4E mov.l 0x06074C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074B54u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B54u) return; }  // 06074B50 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074C8Cu);  // 06074B54 mov.l 0x06074C8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074B5Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B5Au) return; }  // 06074B56 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074C74u);  // 06074B5A mov.w 0x06074C74,r3
    c.r[3] += c.r[14];  // 06074B5C add r14,r3
    c.r[3] = ld32(c.r[3]);  // 06074B5E mov.l @r3,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06074B60 tst r3,r3
    { const bool k = c.t; c.r[5] = 0xBu; if (k) { goto L_06074BB0; } }  // 06074B62 bt/s 0x06074BB0 ; mov #11,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074C76u);  // 06074B66 mov.w 0x06074C76,r9
    c.r[10] = ld32(0x06074C7Cu);  // 06074B68 mov.l 0x06074C7C,r10
    c.r[8] = ld32(0x06074C80u);  // 06074B6A mov.l 0x06074C80,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06074B70u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B70u) return; }  // 06074B6C jsr @r8 ; mov r10,r4
    c.r[5] = c.r[9];  // 06074B70 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B76u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B76u) return; }  // 06074B72 jsr @r8 ; mov r0,r4
    c.r[11] = ld32(0x06074C90u);  // 06074B76 mov.l 0x06074C90,r11
    c.r[6] = 0x0u;  // 06074B78 mov #0,r6
    c.r[5] = c.r[0];  // 06074B7A mov r0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06074B80u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B80u) return; }  // 06074B7C jsr @r11 ; mov #0,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074C78u);  // 06074B80 mov.w 0x06074C78,r9
    c.r[5] = 0xBu;  // 06074B82 mov #11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B88u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B88u) return; }  // 06074B84 jsr @r8 ; mov r10,r4
    c.r[5] = c.r[9];  // 06074B88 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B8Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B8Eu) return; }  // 06074B8A jsr @r8 ; mov r0,r4
    c.r[6] = 0x0u;  // 06074B8E mov #0,r6
    c.r[5] = c.r[0];  // 06074B90 mov r0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06074B96u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B96u) return; }  // 06074B92 jsr @r11 ; mov #0,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074C7Au);  // 06074B96 mov.w 0x06074C7A,r9
    c.r[5] = 0xBu;  // 06074B98 mov #11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074B9Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074B9Eu) return; }  // 06074B9A jsr @r8 ; mov r10,r4
    c.r[5] = c.r[9];  // 06074B9E mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074BA4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BA4u) return; }  // 06074BA0 jsr @r8 ; mov r0,r4
    c.r[6] = 0x0u;  // 06074BA4 mov #0,r6
    c.r[5] = c.r[0];  // 06074BA6 mov r0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06074BACu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BACu) return; }  // 06074BA8 jsr @r11 ; mov #0,r4
    c.r[11] = 0x0u; goto L_06074BD6;  // 06074BAC bra 0x06074BD6 ; mov #0,r11
L_06074BB0:
    c.r[10] = ld32(0x06074C94u);  // 06074BB0 mov.l 0x06074C94,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06074BB6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BB6u) return; }  // 06074BB2 jsr @r10 ; mov #0,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074C72u);  // 06074BB6 mov.w 0x06074C72,r9
    c.r[4] = ld32(0x06074C7Cu);  // 06074BB8 mov.l 0x06074C7C,r4
    c.r[8] = ld32(0x06074C80u);  // 06074BBA mov.l 0x06074C80,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06074BC0u; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BC0u) return; }  // 06074BBC jsr @r8 ; mov #11,r5
    c.r[5] = c.r[9];  // 06074BC0 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074BC6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BC6u) return; }  // 06074BC2 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06074C90u);  // 06074BC6 mov.l 0x06074C90,r1
    c.r[6] = 0x0u;  // 06074BC8 mov #0,r6
    c.r[5] = c.r[0];  // 06074BCA mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06074BD0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BD0u) return; }  // 06074BCC jsr @r1 ; mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06074BD4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BD4u) return; }  // 06074BD0 jsr @r10 ; mov #0,r4
    c.r[11] = 0x0u;  // 06074BD4 mov #0,r11
L_06074BD6:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BD6 mov.l r11,@-r15
    c.r[12] = 0x1u;  // 06074BD8 mov #1,r12
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074BDA mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BDC mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074BDE mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074BE0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BE2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BE4 mov.l r11,@-r15
    c.r[10] = 0x2u;  // 06074BE6 mov #2,r10
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074BE8 mov.l r10,@-r15
    c.r[13] = ld32(0x06074C98u);  // 06074BEA mov.l 0x06074C98,r13
    c.r[7] = 0xAu;  // 06074BEC mov #10,r7
    c.r[6] = 0x13u;  // 06074BEE mov #19,r6
    c.r[5] = 0xFu;  // 06074BF0 mov #15,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06074BF6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074BF6u) return; }  // 06074BF2 jsr @r13 ; mov #0,r4
    c.r[15] += 32;  // 06074BF6 add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BF8 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074BFA mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BFC mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074BFE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C00 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074C02 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074C04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C06 mov.l r10,@-r15
    c.r[7] = 0xAu;  // 06074C08 mov #10,r7
    c.r[6] = 0x15u;  // 06074C0A mov #21,r6
    c.r[5] = 0xFu;  // 06074C0C mov #15,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06074C12u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074C12u) return; }  // 06074C0E jsr @r13 ; mov r12,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074C74u);  // 06074C12 mov.w 0x06074C74,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06074C14 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06074C16 tst r0,r0
    { const bool k = c.t; c.r[15] += 32; if (k) { goto L_06074C9C; } }  // 06074C18 bt/s 0x06074C9C ; add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C1C mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C1E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074C20 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C22 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C24 mov.l r10,@-r15
    c.r[8] = 0x3u;  // 06074C26 mov #3,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074C28 mov.l r8,@-r15
    c.r[9] = 0x4u;  // 06074C2A mov #4,r9
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06074C2C mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C2E mov.l r10,@-r15
    c.r[7] = 0xCu;  // 06074C30 mov #12,r7
    c.r[6] = 0xEu;  // 06074C32 mov #14,r6
    c.r[5] = c.r[12];  // 06074C34 mov r12,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06074C3Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074C3Au) return; }  // 06074C36 jsr @r13 ; mov r10,r4
    c.r[15] += 32;  // 06074C3A add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C3C mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C3E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074C40 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074C42 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074C44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06074C46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C4A mov.l r10,@-r15
    c.r[7] = 0xCu;  // 06074C4C mov #12,r7
    c.r[6] = 0xEu;  // 06074C4E mov #14,r6
    c.r[5] = 0xEu;  // 06074C50 mov #14,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06074C56u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074C56u) return; }  // 06074C52 jsr @r13 ; mov r8,r4
    c.r[15] += 32;  // 06074C56 add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C58 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074C5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074C5C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06074C5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06074C60 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C62 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074C64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074C66 mov.l r10,@-r15
    c.r[7] = 0xCu;  // 06074C68 mov #12,r7
    c.r[6] = 0xEu;  // 06074C6A mov #14,r6
    c.r[5] = 0x1Bu;  // 06074C6C mov #27,r5
    c.r[4] = c.r[9]; goto L_06074CC6;  // 06074C6E bra 0x06074CC6 ; mov r9,r4
L_06074C9C:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074CF8u);  // 06074C9C mov.w 0x06074CF8,r3
    c.r[3] += c.r[14];  // 06074C9E add r14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074CF8u);  // 06074CA0 mov.w 0x06074CF8,r0
    c.r[0] += c.r[14];  // 06074CA2 add r14,r0
    c.r[7] = 0xCu;  // 06074CA4 mov #12,r7
    c.r[6] = 0xEu;  // 06074CA6 mov #14,r6
    c.r[3] = ld32(c.r[3]);  // 06074CA8 mov.l @r3,r3
    c.r[5] = 0xEu;  // 06074CAA mov #14,r5
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06074CAC mov.l r3,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074CF8u);  // 06074CAE mov.w 0x06074CF8,r3
    c.r[0] = ld32(c.r[0]);  // 06074CB0 mov.l @r0,r0
    c.r[3] += c.r[14];  // 06074CB2 add r14,r3
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06074CB4 mov.l r0,@-r15
    c.r[3] = ld32(c.r[3]);  // 06074CB6 mov.l @r3,r3
    c.r[4] = c.r[10];  // 06074CB8 mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06074CBA mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074CBC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074CBE mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074CC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074CC2 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074CC4 mov.l r10,@-r15
L_06074CC6:
    { const uint32_t x = c.r[13]; c.pr = 0x06074CCAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074CCAu) return; }  // 06074CC6 jsr @r13 ; nop
    c.r[15] += 32;  // 06074CCA add #32,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074CF8u);  // 06074CCC mov.w 0x06074CF8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06074CCE mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06074CD0 tst r0,r0
    { const bool k = c.t; c.r[4] = 0x6Au; if (k) { goto L_06074CD8; } }  // 06074CD2 bt/s 0x06074CD8 ; mov #106,r4
    c.r[4] = 0x34u;  // 06074CD6 mov #52,r4
L_06074CD8:
    c.r[1] = ld32(0x06074D00u);  // 06074CD8 mov.l 0x06074D00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074CDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074CDEu) return; }  // 06074CDA jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x06074CFAu);  // 06074CDE mov.w 0x06074CFA,r3
    c.r[14] += c.r[3];  // 06074CE0 add r3,r14
    c.r[15] = c.r[14];  // 06074CE2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06074CE4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06074CE6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06074CE8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06074CEA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06074CEC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06074CEE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06074CF0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074CFCu);  // 06074CF2 mov.w 0x06074CFC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06074CF4 rts ; mov.l @r15+,r8
}

void f_06074D0C(SH2Context& c) {
    ran[1616] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074D0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06074D0E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074D10 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074D12 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074D14 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06074D16 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074D18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074D1A sts.l pr,@-r15
    c.r[1] = ld32(0x06074E88u);  // 06074D1C mov.l 0x06074E88,r1
    c.r[2] = ld32(c.r[1]);  // 06074D1E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06074E7Cu);  // 06074D20 mov.w 0x06074E7C,r1
    c.r[0] = c.r[2];  // 06074D22 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06074D24 mov.b @(r0,r1),r1
    c.r[13] = 0x4u;  // 06074D26 mov #4,r13
    c.r[13] &= c.r[1];  // 06074D28 and r1,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06074D2A tst r13,r13
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06074D3A; } }  // 06074D2C bt/s 0x06074D3A ; mov r15,r14
    c.r[1] = ld32(0x06074E8Cu);  // 06074D30 mov.l 0x06074E8C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074D32 mov.b @r1,r1
    c.r[1] -= 1;  // 06074D34 add #-1,r1
    c.r[5] = c.r[1] & 0xFFu; goto L_06074D3C;  // 06074D36 bra 0x06074D3C ; extu.b r1,r5
L_06074D3A:
    c.r[5] = 0x0u;  // 06074D3A mov #0,r5
L_06074D3C:
    c.r[12] = c.r[5];  // 06074D3C mov r5,r12
    c.r[1] = ld32(0x06074E90u);  // 06074D3E mov.l 0x06074E90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074D44u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074D44u) return; }  // 06074D40 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074E94u);  // 06074D44 mov.l 0x06074E94,r1
    c.r[1] = ld32(c.r[1]);  // 06074D46 mov.l @r1,r1
    c.r[1] += 1;  // 06074D48 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074D4A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06074D4C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06074D4E tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_06074D6E; } }  // 06074D50 bf/s 0x06074D6E ; mov #0,r2
    c.r[1] = ld32(0x06074E98u);  // 06074D54 mov.l 0x06074E98,r1
    c.r[3] = ld32(0x06074E9Cu);  // 06074D56 mov.l 0x06074E9C,r3
    c.t = (c.r[13] & c.r[13]) == 0;  // 06074D58 tst r13,r13
    { const bool k = c.t; st8(c.r[1], c.r[2]); if (k) { goto L_06074D66; } }  // 06074D5A bt/s 0x06074D66 ; mov.b r2,@r1
    c.r[1] = c.r[12];  // 06074D5E mov r12,r1
    c.r[1] -= 1;  // 06074D60 add #-1,r1
    st8(c.r[3], c.r[1]); goto L_06074D68;  // 06074D62 bra 0x06074D68 ; mov.b r1,@r3
L_06074D66:
    st8(c.r[3], c.r[2]);  // 06074D66 mov.b r2,@r3
L_06074D68:
    c.r[2] = ld32(0x06074EA0u);  // 06074D68 mov.l 0x06074EA0,r2
    c.r[1] = 0x4u;  // 06074D6A mov #4,r1
    st16(c.r[2], c.r[1]);  // 06074D6C mov.w r1,@r2
L_06074D6E:
    c.r[1] = ld32(0x06074E94u);  // 06074D6E mov.l 0x06074E94,r1
    c.r[1] = ld32(c.r[1]);  // 06074D70 mov.l @r1,r1
    c.r[1] += 1;  // 06074D72 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074D74 mov.b @r1,r1
    c.r[2] = 0x1u;  // 06074D76 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06074D78 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06074D7A cmp/hi r2,r1
    { const bool k = c.t; c.r[5] = 0x1Bu; if (k) { goto L_06074DC8; } }  // 06074D7C bt/s 0x06074DC8 ; mov #27,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x06074E7Eu);  // 06074D80 mov.w 0x06074E7E,r9
    c.r[9] += c.r[12];  // 06074D82 add r12,r9
    c.r[10] = ld32(0x06074EA4u);  // 06074D84 mov.l 0x06074EA4,r10
    c.r[8] = ld32(0x06074EA8u);  // 06074D86 mov.l 0x06074EA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06074D8Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074D8Cu) return; }  // 06074D88 jsr @r8 ; mov r10,r4
    c.r[5] = c.r[9];  // 06074D8C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074D92u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074D92u) return; }  // 06074D8E jsr @r8 ; mov r0,r4
    c.r[11] = c.r[0];  // 06074D92 mov r0,r11
    c.r[5] = 0x1Bu;  // 06074D94 mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074D9Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074D9Au) return; }  // 06074D96 jsr @r8 ; mov r10,r4
    c.r[5] = c.r[9];  // 06074D9A mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074DA0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074DA0u) return; }  // 06074D9C jsr @r8 ; mov r0,r4
    c.r[11] += 2;  // 06074DA0 add #2,r11
    c.r[0] += 3;  // 06074DA2 add #3,r0
    c.r[6] = 0x0u;  // 06074DA4 mov #0,r6
    c.r[5] = 0x14u;  // 06074DA6 mov #20,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06074DA8 mov.b @r11,r7
    c.r[4] = 0x0u;  // 06074DAA mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06074DAC mov.b @r0,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06074DAE extu.b r7,r7
    c.r[7] <<= 8;  // 06074DB0 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06074DB2 extu.b r1,r1
    c.r[7] |= c.r[1];  // 06074DB4 or r1,r7
    c.r[1] = 0x0u;  // 06074DB6 mov #0,r1
    c.r[0] = ld32(0x06074EACu);  // 06074DB8 mov.l 0x06074EAC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06074DBEu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074DBEu) return; }  // 06074DBA jsr @r0 ; mov.l r1,@-r15
    c.r[2] = ld32(0x06074EB0u);  // 06074DBE mov.l 0x06074EB0,r2
    c.r[1] = ld32(0x06074EB4u);  // 06074DC0 mov.l 0x06074EB4,r1
    st32(c.r[2], c.r[1]);  // 06074DC2 mov.l r1,@r2
    c.r[15] += 4; goto L_06074DDA;  // 06074DC4 bra 0x06074DDA ; add #4,r15
L_06074DC8:
    c.r[1] = ld32(0x06074EB8u);  // 06074DC8 mov.l 0x06074EB8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074E80u);  // 06074DCA mov.w 0x06074E80,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06074DCC mov.w @(r0,r1),r2
    c.r[2] += 1;  // 06074DCE add #1,r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 06074DD0 mov.w r2,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074E82u);  // 06074DD2 mov.w 0x06074E82,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06074DD4 mov.w @(r0,r1),r2
    c.r[2] += 1;  // 06074DD6 add #1,r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 06074DD8 mov.w r2,@(r0,r1)
L_06074DDA:
    c.r[1] = ld32(0x06074EBCu);  // 06074DDA mov.l 0x06074EBC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074DDC mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06074DDE extu.b r4,r4
    c.r[4] += 11;  // 06074DE0 add #11,r4
    c.r[4] <<= 2;  // 06074DE2 shll2 r4
    c.r[4] += c.r[4];  // 06074DE4 add r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06074E84u);  // 06074DE6 mov.w 0x06074E84,r1
    c.r[4] += c.r[1];  // 06074DE8 add r1,r4
    c.r[1] = ld32(0x06074EC0u);  // 06074DEA mov.l 0x06074EC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074DF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074DF0u) return; }  // 06074DEC jsr @r1 ; nop
    c.r[4] = c.r[0];  // 06074DF0 mov r0,r4
    c.r[5] = c.r[1];  // 06074DF2 mov r1,r5
    c.r[1] = ld32(0x06074EC4u);  // 06074DF4 mov.l 0x06074EC4,r1
    c.r[6] = ld32(c.r[1]);  // 06074DF6 mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 06074DF8 mov.l @(4,r1),r7
    c.r[8] = ld32(0x06074EC8u);  // 06074DFA mov.l 0x06074EC8,r8
    c.r[1] = ld32(0x06074ECCu);  // 06074DFC mov.l 0x06074ECC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074E02u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E02u) return; }  // 06074DFE jsr @r1 ; nop
    c.r[4] = c.r[0];  // 06074E02 mov r0,r4
    c.r[5] = c.r[1];  // 06074E04 mov r1,r5
    c.r[0] = ld32(0x06074ED0u);  // 06074E06 mov.l 0x06074ED0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06074E0Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E0Cu) return; }  // 06074E08 jsr @r0 ; nop
    st32(c.r[8], c.r[0]);  // 06074E0C mov.l r0,@r8
    c.r[1] = ld32(0x06074ED4u);  // 06074E0E mov.l 0x06074ED4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074E14u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E14u) return; }  // 06074E10 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074ED8u);  // 06074E14 mov.l 0x06074ED8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074E1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E1Au) return; }  // 06074E16 jsr @r1 ; nop
    c.t = (c.r[13] & c.r[13]) == 0;  // 06074E1A tst r13,r13
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06074E26; } }  // 06074E1C bt/s 0x06074E26 ; mov #0,r10
    c.r[1] = c.r[12];  // 06074E20 mov r12,r1
    c.r[1] -= 1;  // 06074E22 add #-1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06074E24 extu.b r1,r10
L_06074E26:
    c.r[9] = ld32(0x06074EA4u);  // 06074E26 mov.l 0x06074EA4,r9
    c.r[8] = ld32(0x06074EA8u);  // 06074E28 mov.l 0x06074EA8,r8
    c.r[5] = 0x17u;  // 06074E2A mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074E30u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E30u) return; }  // 06074E2C jsr @r8 ; mov r9,r4
    c.r[5] = 0x25u;  // 06074E30 mov #37,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074E36u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E36u) return; }  // 06074E32 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06074EDCu);  // 06074E36 mov.l 0x06074EDC,r1
    c.r[6] = 0x6u;  // 06074E38 mov #6,r6
    c.r[5] = c.r[10];  // 06074E3A mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06074E40u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E40u) return; }  // 06074E3C jsr @r1 ; mov r0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06074E7Eu);  // 06074E40 mov.w 0x06074E7E,r1
    c.r[12] += c.r[1];  // 06074E42 add r1,r12
    c.r[5] = 0xBu;  // 06074E44 mov #11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074E4Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E4Au) return; }  // 06074E46 jsr @r8 ; mov r9,r4
    c.r[5] = c.r[12];  // 06074E4A mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06074E50u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E50u) return; }  // 06074E4C jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06074EE0u);  // 06074E50 mov.l 0x06074EE0,r1
    c.r[6] = 0x0u;  // 06074E52 mov #0,r6
    c.r[5] = c.r[0];  // 06074E54 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06074E5Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E5Au) return; }  // 06074E56 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06074E98u);  // 06074E5A mov.l 0x06074E98,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074E5C mov.b @r1,r4
    c.r[4] += 53;  // 06074E5E add #53,r4
    c.r[1] = ld32(0x06074EE4u);  // 06074E60 mov.l 0x06074EE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074E66u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074E66u) return; }  // 06074E62 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 06074E66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06074E68 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06074E6A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06074E6C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06074E6E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06074E70 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06074E72 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06074E74 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06074E86u);  // 06074E76 mov.w 0x06074E86,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06074E78 rts ; mov.l @r15+,r8
}

void f_06074EE8(SH2Context& c) {
    ran[1617] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06074EE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06074EEA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06074EEC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06074EEE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06074EF0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06074EF2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06074EF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06074EF6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06074EF8 mov r15,r14
    c.r[8] = ld32(0x06075094u);  // 06074EFA mov.l 0x06075094,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607507Cu);  // 06074EFC mov.w 0x0607507C,r0
    c.r[1] = 0x0u;  // 06074EFE mov #0,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 06074F00 mov.b r1,@(r0,r8)
    c.r[1] = ld32(0x06075098u);  // 06074F02 mov.l 0x06075098,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074F08u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074F08u) return; }  // 06074F04 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607509Cu);  // 06074F08 mov.l 0x0607509C,r1
    c.r[1] = ld32(c.r[1]);  // 06074F0A mov.l @r1,r1
    c.r[1] += 1;  // 06074F0C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06074F0E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06074F10 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06074F12 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x30u; if (k) { goto L_06074F1C; } }  // 06074F14 bt/s 0x06074F1C ; mov #48,r1
    goto L_060750D2;  // 06074F18 bra 0x060750D2 ; nop
L_06074F1C:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607507Eu);  // 06074F1C mov.w 0x0607507E,r2
    c.r[0] = c.r[8];  // 06074F1E mov r8,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06074F20 mov.w r1,@(r0,r2)
    c.r[12] = 0x0u;  // 06074F22 mov #0,r12
    c.r[9] = 0x7u;  // 06074F24 mov #7,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x06075080u);  // 06074F26 mov.w 0x06075080,r10
    c.r[13] = 0x0u;  // 06074F28 mov #0,r13
    c.r[11] = ld32(0x060750A0u);  // 06074F2A mov.l 0x060750A0,r11
L_06074F2C:
    c.r[0] = ld32(0x060750A4u);  // 06074F2C mov.l 0x060750A4,r0
    c.r[8] = c.r[12];  // 06074F2E mov r12,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x06075082u);  // 06074F30 mov.w 0x06075082,r6
    c.r[1] = ld32(c.r[0]);  // 06074F32 mov.l @r0,r1
    c.r[5] = c.r[9];  // 06074F34 mov r9,r5
    c.r[0] = c.r[1];  // 06074F36 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06074F38 mov.b @(r0,r10),r1
    c.r[4] = 0x0u;  // 06074F3A mov #0,r4
    c.r[2] = c.r[1];  // 06074F3C mov r1,r2
    c.r[2] >>= 2;  // 06074F3E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06074F40 shlr r2
    c.r[0] = 0x8u;  // 06074F42 mov #8,r0
    c.r[2] &= c.r[0];  // 06074F44 and r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075084u);  // 06074F46 mov.w 0x06075084,r1
    c.r[8] += c.r[1];  // 06074F48 add r1,r8
    c.r[2] += c.r[8];  // 06074F4A add r8,r2
    c.r[7] = c.r[2] & 0xFFFFu;  // 06074F4C extu.w r2,r7
    { const uint32_t x = c.r[11]; c.pr = 0x06074F52u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074F52u) return; }  // 06074F4E jsr @r11 ; mov.l r13,@-r15
    c.r[0] = ld32(0x060750A4u);  // 06074F52 mov.l 0x060750A4,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x06075086u);  // 06074F54 mov.w 0x06075086,r6
    c.r[1] = ld32(c.r[0]);  // 06074F56 mov.l @r0,r1
    c.r[5] = c.r[9];  // 06074F58 mov r9,r5
    c.r[0] = c.r[1];  // 06074F5A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06074F5C mov.b @(r0,r10),r1
    c.r[4] = 0x0u;  // 06074F5E mov #0,r4
    c.r[1] >>= 2;  // 06074F60 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06074F62 shlr r1
    c.r[0] = 0x8u;  // 06074F64 mov #8,r0
    c.r[1] &= c.r[0];  // 06074F66 and r0,r1
    c.r[1] += c.r[8];  // 06074F68 add r8,r1
    c.r[1] += 1;  // 06074F6A add #1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 06074F6C extu.w r1,r7
    { const uint32_t x = c.r[11]; c.pr = 0x06074F72u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074F72u) return; }  // 06074F6E jsr @r11 ; mov.l r13,@-r15
    c.r[12] += 2;  // 06074F72 add #2,r12
    c.r[1] = c.r[9];  // 06074F74 mov r9,r1
    c.r[1] += 7;  // 06074F76 add #7,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06074F78 extu.b r1,r9
    c.r[1] = 0x7u;  // 06074F7A mov #7,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06074F7C cmp/gt r1,r12
    { const bool k = !c.t; c.r[15] += 8; if (k) { SH2_POLL(c); goto L_06074F2C; } }  // 06074F7E bf/s 0x06074F2C ; add #8,r15
    c.r[12] = ld32(0x060750A8u);  // 06074F82 mov.l 0x060750A8,r12
    c.r[1] = 0x1u;  // 06074F84 mov #1,r1
    st8(c.r[12], c.r[1]);  // 06074F86 mov.b r1,@r12
    c.r[8] = (uint32_t)(int16_t)ld16(0x06075088u);  // 06074F88 mov.w 0x06075088,r8
    c.r[5] = ld32(0x060750ACu);  // 06074F8A mov.l 0x060750AC,r5
    c.r[9] = ld32(0x060750B0u);  // 06074F8C mov.l 0x060750B0,r9
    c.r[10] = ld32(0x060750B4u);  // 06074F8E mov.l 0x060750B4,r10
    c.r[7] = 0xEu;  // 06074F90 mov #14,r7
    c.r[6] = c.r[8];  // 06074F92 mov r8,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06074F98u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074F98u) return; }  // 06074F94 jsr @r10 ; mov r9,r4
    c.r[11] = ld32(0x060750B8u);  // 06074F98 mov.l 0x060750B8,r11
    c.r[7] = 0xEu;  // 06074F9A mov #14,r7
    c.r[6] = c.r[8];  // 06074F9C mov r8,r6
    c.r[5] = c.r[11];  // 06074F9E mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06074FA4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074FA4u) return; }  // 06074FA0 jsr @r10 ; mov r9,r4
    c.r[1] = ld32(0x060750BCu);  // 06074FA4 mov.l 0x060750BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06074FAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06074FAAu) return; }  // 06074FA6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06074FAA mov #0,r1
    st8(c.r[12], c.r[1]);  // 06074FAC mov.b r1,@r12
    c.r[12] = 0x0u;  // 06074FAE mov #0,r12
    c.r[6] = c.r[11];  // 06074FB0 mov r11,r6
    c.r[6] += 1;  // 06074FB2 add #1,r6
L_06074FB4:
    c.r[5] = 0x1Fu;  // 06074FB4 mov #31,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06074FB6 mov.b @r6,r7
    c.r[1] = 0x3u;  // 06074FB8 mov #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06074FBA mov.b @r11,r2
    c.r[5] &= c.r[7];  // 06074FBC and r7,r5
    c.r[5] += c.r[5];  // 06074FBE add r5,r5
    c.r[2] = c.r[2] & 0xFFu;  // 06074FC0 extu.b r2,r2
    c.r[1] &= c.r[2];  // 06074FC2 and r2,r1
    c.r[1] <<= 2;  // 06074FC4 shll2 r1
    c.r[1] += c.r[1];  // 06074FC6 add r1,r1
    c.r[3] = c.r[7] & 0xFFu;  // 06074FC8 extu.b r7,r3
    c.r[3] >>= 2;  // 06074FCA shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06074FCC shlr r3
    c.r[3] >>= 2;  // 06074FCE shlr2 r3
    c.r[3] |= c.r[1];  // 06074FD0 or r1,r3
    c.r[1] = 0x5u;  // 06074FD2 mov #5,r1
    c.r[0] = c.r[2];  // 06074FD4 mov r2,r0
    c.r[0] >>= 2;  // 06074FD6 shlr2 r0
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06074FD8 mulu.w r1,r3
    c.r[0] &= 0x1Fu;  // 06074FDA and #31,r0
    c.r[1] = c.macl;  // 06074FDC sts macl,r1
    c.r[5] += c.r[1];  // 06074FDE add r1,r5
    c.r[5] += c.r[0];  // 06074FE0 add r0,r5
    c.r[9] = c.r[5];  // 06074FE2 mov r5,r9
    c.r[9] >>= 2;  // 06074FE4 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06074FE6 shlr r9
    c.r[1] = 0x1Fu;  // 06074FE8 mov #31,r1
    c.r[1] &= c.r[9];  // 06074FEA and r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607508Au);  // 06074FEC mov.w 0x0607508A,r2
    c.r[2] &= c.r[7];  // 06074FEE and r7,r2
    c.r[2] |= c.r[1];  // 06074FF0 or r1,r2
    st8(c.r[6], c.r[2]);  // 06074FF2 mov.b r2,@r6
    c.r[3] = c.r[9] & 0xFFFFu;  // 06074FF4 extu.w r9,r3
    c.r[7] = c.r[3];  // 06074FF6 mov r3,r7
    c.r[7] >>= 2;  // 06074FF8 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06074FFA shlr r7
    c.r[0] = 0x3u;  // 06074FFC mov #3,r0
    c.r[7] &= c.r[0];  // 06074FFE and r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607508Cu);  // 06075000 mov.w 0x0607508C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06075002 mov.b @r11,r2
    c.r[12] += 1;  // 06075004 add #1,r12
    c.r[2] &= c.r[0];  // 06075006 and r0,r2
    c.r[2] |= c.r[7];  // 06075008 or r7,r2
    st8(c.r[11], c.r[2]);  // 0607500A mov.b r2,@r11
    c.r[0] = 0x7u;  // 0607500C mov #7,r0
    c.r[3] &= c.r[0];  // 0607500E and r0,r3
    c.r[3] <<= 2;  // 06075010 shll2 r3
    c.r[3] += c.r[3];  // 06075012 add r3,r3
    c.r[3] <<= 2;  // 06075014 shll2 r3
    c.r[0] = 0x1Fu;  // 06075016 mov #31,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06075018 mov.b @r6,r2
    c.r[1] <<= 2;  // 0607501A shll2 r1
    c.r[2] &= c.r[0];  // 0607501C and r0,r2
    c.r[2] |= c.r[3];  // 0607501E or r3,r2
    st8(c.r[6], c.r[2]);  // 06075020 mov.b r2,@r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607508Eu);  // 06075022 mov.w 0x0607508E,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06075024 mov.b @r11,r2
    c.r[6] += 2;  // 06075026 add #2,r6
    c.r[2] &= c.r[0];  // 06075028 and r0,r2
    c.r[2] |= c.r[1];  // 0607502A or r1,r2
    st8(c.r[11], c.r[2]);  // 0607502C mov.b r2,@r11
    c.r[1] = 0x7Fu;  // 0607502E mov #127,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06075030 cmp/gt r1,r12
    { const bool k = !c.t; c.r[11] += 2; if (k) { SH2_POLL(c); goto L_06074FB4; } }  // 06075032 bf/s 0x06074FB4 ; add #2,r11
    c.r[3] = ld32(0x060750C0u);  // 06075036 mov.l 0x060750C0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075038 mov.b @r3,r1
    c.r[7] = ld32(0x060750C4u);  // 0607503A mov.l 0x060750C4,r7
    c.r[6] = c.r[1] & 0xFFu;  // 0607503C extu.b r1,r6
    c.r[1] = ld32(0x060750A4u);  // 0607503E mov.l 0x060750A4,r1
    c.r[1] = ld32(c.r[1]);  // 06075040 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06075090u);  // 06075042 mov.w 0x06075090,r2
    c.r[0] = c.r[1];  // 06075044 mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06075046 mov.w @(r0,r2),r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06075080u);  // 06075048 mov.w 0x06075080,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607504A mov.b @(r0,r5),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607504C extu.w r2,r2
    c.r[2] >>= 2;  // 0607504E shlr2 r2
    c.r[2] >>= 2;  // 06075050 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06075052 shlr r2
    c.r[2] >>= 2;  // 06075054 shlr2 r2
    c.r[1] >>= 2;  // 06075056 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06075058 shlr r1
    c.r[0] = 0x8u;  // 0607505A mov #8,r0
    c.r[1] &= c.r[0];  // 0607505C and r0,r1
    c.r[1] += 48;  // 0607505E add #48,r1
    c.r[2] -= c.r[1];  // 06075060 sub r1,r2
    c.r[0] = c.r[6];  // 06075062 mov r6,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06075064 mov.b r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075066 mov.b @r3,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06075068 extu.b r1,r3
    c.r[0] = c.r[3];  // 0607506A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607506C mov.b @(r0,r7),r2
    c.r[1] = 0x1u;  // 0607506E mov #1,r1
    c.r[1] &= c.r[2];  // 06075070 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06075072 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060750C8; } }  // 06075074 bt/s 0x060750C8 ; mov r2,r1
    c.r[1] -= 1; goto L_060750CA;  // 06075078 bra 0x060750CA ; add #-1,r1
L_060750C8:
    c.r[1] += 1;  // 060750C8 add #1,r1
L_060750CA:
    st8(c.r[0] + c.r[7], c.r[1]);  // 060750CA mov.b r1,@(r0,r7)
    c.r[1] = ld32(0x060751E4u);  // 060750CC mov.l 0x060751E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060750D2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060750D2u) return; }  // 060750CE jsr @r1 ; mov #0,r4
L_060750D2:
    c.r[2] = ld32(0x060751E8u);  // 060750D2 mov.l 0x060751E8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060751DCu);  // 060750D4 mov.w 0x060751DC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060750D6 mov.w @(r0,r2),r1
    c.r[1] += 8;  // 060750D8 add #8,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 060750DA mov.w r1,@(r0,r2)
    c.r[1] = ld32(0x060751ECu);  // 060750DC mov.l 0x060751EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060750E2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060750E2u) return; }  // 060750DE jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060751F0u);  // 060750E2 mov.l 0x060751F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060750E4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060750E6 extu.b r1,r0
    c.r[1] = ld32(0x060751F4u);  // 060750E8 mov.l 0x060751F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060750EA mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 060750EC extu.b r1,r4
    c.r[1] = 0x1u;  // 060750EE mov #1,r1
    c.r[1] &= c.r[4];  // 060750F0 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060750F2 tst r1,r1
    { const bool k = c.t; c.r[12] = c.r[4]; if (k) { goto L_060750FC; } }  // 060750F4 bt/s 0x060750FC ; mov r4,r12
    c.r[12] -= 1; goto L_060750FE;  // 060750F8 bra 0x060750FE ; add #-1,r12
L_060750FC:
    c.r[12] += 1;  // 060750FC add #1,r12
L_060750FE:
    c.r[1] = ld32(0x060751F8u);  // 060750FE mov.l 0x060751F8,r1
    c.r[1] = ld32(c.r[1]);  // 06075100 mov.l @r1,r1
    c.r[1] += 1;  // 06075102 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075104 mov.b @r1,r1
    c.r[12] <<= 2;  // 06075106 shll2 r12
    c.r[12] += c.r[12];  // 06075108 add r12,r12
    c.r[12] <<= 2;  // 0607510A shll2 r12
    c.r[1] = c.r[1] & 0xFFu;  // 0607510C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607510E tst r1,r1
    { const bool k = !c.t; c.r[11] = 0x20u; if (k) { goto L_06075144; } }  // 06075110 bf/s 0x06075144 ; mov #32,r11
    c.r[10] = ld32(0x060751FCu);  // 06075114 mov.l 0x060751FC,r10
    c.r[1] = 0x1u;  // 06075116 mov #1,r1
    st8(c.r[10], c.r[1]);  // 06075118 mov.b r1,@r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x060751DEu);  // 0607511A mov.w 0x060751DE,r6
    c.r[8] = ld32(0x06075200u);  // 0607511C mov.l 0x06075200,r8
    c.r[4] = ld32(0x06075204u);  // 0607511E mov.l 0x06075204,r4
    c.r[9] = ld32(0x06075208u);  // 06075120 mov.l 0x06075208,r9
    c.r[7] = 0xEu;  // 06075122 mov #14,r7
    { const uint32_t x = c.r[9]; c.pr = 0x06075128u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075128u) return; }  // 06075124 jsr @r9 ; mov r8,r5
    c.r[8] += c.r[12];  // 06075128 add r12,r8
    c.r[1] = ld32(0x0607520Cu);  // 0607512A mov.l 0x0607520C,r1
    c.r[12] += c.r[1];  // 0607512C add r1,r12
    c.r[7] = 0xEu;  // 0607512E mov #14,r7
    c.r[6] = c.r[11];  // 06075130 mov r11,r6
    c.r[5] = c.r[8];  // 06075132 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06075138u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075138u) return; }  // 06075134 jsr @r9 ; mov r12,r4
    c.r[1] = ld32(0x06075210u);  // 06075138 mov.l 0x06075210,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607513Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607513Eu) return; }  // 0607513A jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0607513E mov #0,r1
    st8(c.r[10], c.r[1]); goto L_060751BA;  // 06075140 bra 0x060751BA ; mov.b r1,@r10
L_06075144:
    c.r[8] = ld32(0x06075214u);  // 06075144 mov.l 0x06075214,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607514Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607514Au) return; }  // 06075146 jsr @r8 ; mov #1,r4
    c.r[1] = c.r[0];  // 0607514A mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0607514C extu.b r1,r9
    c.r[10] = ld32(0x06075218u);  // 0607514E mov.l 0x06075218,r10
    c.r[3] = c.r[9];  // 06075150 mov r9,r3
    c.r[3] += c.r[3];  // 06075152 add r3,r3
    c.r[3] += c.r[9];  // 06075154 add r9,r3
    c.r[3] <<= 2;  // 06075156 shll2 r3
    c.r[2] = c.r[3];  // 06075158 mov r3,r2
    c.r[2] += c.r[10];  // 0607515A add r10,r2
    c.r[1] = ld32(0x06075204u);  // 0607515C mov.l 0x06075204,r1
    st32(c.r[2] + 4, c.r[1]);  // 0607515E mov.l r1,@(4,r2)
    c.r[2] += 8;  // 06075160 add #8,r2
    c.r[1] = 0x30u;  // 06075162 mov #48,r1
    st8(c.r[2], c.r[1]);  // 06075164 mov.b r1,@r2
    c.r[0] = c.r[10];  // 06075166 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075168 mov.b @(r0,r3),r1
    c.r[4] = 0x1u;  // 0607516A mov #1,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060751E0u);  // 0607516C mov.w 0x060751E0,r0
    c.r[1] &= c.r[0];  // 0607516E and r0,r1
    c.r[0] = 0x8u;  // 06075170 mov #8,r0
    c.r[1] |= c.r[0];  // 06075172 or r0,r1
    c.r[0] = c.r[10];  // 06075174 mov r10,r0
    { const uint32_t x = c.r[8]; c.pr = 0x0607517Au; st8(c.r[0] + c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607517Au) return; }  // 06075176 jsr @r8 ; mov.b r1,@(r0,r3)
    c.r[1] = c.r[0];  // 0607517A mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0607517C extu.b r1,r9
    c.r[3] = c.r[9];  // 0607517E mov r9,r3
    c.r[3] += c.r[3];  // 06075180 add r3,r3
    c.r[3] += c.r[9];  // 06075182 add r9,r3
    c.r[3] <<= 2;  // 06075184 shll2 r3
    c.r[2] = c.r[3];  // 06075186 mov r3,r2
    c.r[2] += c.r[10];  // 06075188 add r10,r2
    c.r[1] = ld32(0x0607520Cu);  // 0607518A mov.l 0x0607520C,r1
    c.r[1] += c.r[12];  // 0607518C add r12,r1
    st32(c.r[2] + 4, c.r[1]);  // 0607518E mov.l r1,@(4,r2)
    c.r[4] = c.r[12];  // 06075190 mov r12,r4
    c.t = (int32_t)c.r[4] >= 0;  // 06075192 cmp/pz r4
    { const bool k = c.t; c.r[2] += 8; if (k) { goto L_0607519A; } }  // 06075194 bt/s 0x0607519A ; add #8,r2
    c.r[4] += 31;  // 06075198 add #31,r4
L_0607519A:
    c.r[1] = c.r[4];  // 0607519A mov r4,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0607519C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0607519E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060751A0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060751A2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060751A4 shar r1
    c.r[1] += 48;  // 060751A6 add #48,r1
    st8(c.r[2], c.r[1]);  // 060751A8 mov.b r1,@r2
    c.r[0] = c.r[10];  // 060751AA mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060751AC mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060751E0u);  // 060751AE mov.w 0x060751E0,r0
    c.r[1] &= c.r[0];  // 060751B0 and r0,r1
    c.r[0] = 0x1u;  // 060751B2 mov #1,r0
    c.r[1] |= c.r[0];  // 060751B4 or r0,r1
    c.r[0] = c.r[10];  // 060751B6 mov r10,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060751B8 mov.b r1,@(r0,r3)
L_060751BA:
    c.r[1] = ld32(0x0607521Cu);  // 060751BA mov.l 0x0607521C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060751C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060751C0u) return; }  // 060751BC jsr @r1 ; nop
    c.r[1] = ld32(0x06075220u);  // 060751C0 mov.l 0x06075220,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060751C6u; c.r[4] = 0x38u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060751C6u) return; }  // 060751C2 jsr @r1 ; mov #56,r4
    c.r[15] = c.r[14];  // 060751C6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060751C8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060751CA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060751CC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060751CE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060751D0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060751D2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060751D4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060751E2u);  // 060751D6 mov.w 0x060751E2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060751D8 rts ; mov.l @r15+,r8
}

void f_06075224(SH2Context& c) {
    ran[1618] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06075224 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06075226 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06075228 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607522A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607522C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607522E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075230 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06075232 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06075234 mov r15,r14
    c.r[1] = ld32(0x06075378u);  // 06075236 mov.l 0x06075378,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607523Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607523Cu) return; }  // 06075238 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607537Cu);  // 0607523C mov.l 0x0607537C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075242u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075242u) return; }  // 0607523E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06075380u);  // 06075242 mov.l 0x06075380,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075248u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075248u) return; }  // 06075244 jsr @r1 ; nop
    c.r[1] = ld32(0x06075384u);  // 06075248 mov.l 0x06075384,r1
    c.r[1] = ld32(c.r[1]);  // 0607524A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607536Eu);  // 0607524C mov.w 0x0607536E,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607524E mov.b @(r0,r1),r7
    c.r[1] = ld32(0x06075388u);  // 06075250 mov.l 0x06075388,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075252 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06075254 extu.b r1,r0
    c.r[1] = ld32(0x0607538Cu);  // 06075256 mov.l 0x0607538C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075258 mov.b @(r0,r1),r1
    c.r[2] = c.r[7] & 0xFFu;  // 0607525A extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607525C extu.b r1,r1
    c.r[1] -= 1;  // 0607525E add #-1,r1
    c.r[3] = c.r[1];  // 06075260 mov r1,r3
    c.r[3] <<= 2;  // 06075262 shll2 r3
    c.r[3] += c.r[1];  // 06075264 add r1,r3
    c.r[3] += c.r[3];  // 06075266 add r3,r3
    c.r[2] -= c.r[3];  // 06075268 sub r3,r2
    c.r[1] = 0xAu;  // 0607526A mov #10,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607526C cmp/gt r1,r2
    if (c.t) { goto L_06075278; }  // 0607526E bt 0x06075278
    c.r[1] = c.r[7];  // 06075270 mov r7,r1
    c.r[1] -= c.r[3];  // 06075272 sub r3,r1
    c.r[4] = c.r[1] & 0xFFu; goto L_0607527A;  // 06075274 bra 0x0607527A ; extu.b r1,r4
L_06075278:
    c.r[4] = c.r[1];  // 06075278 mov r1,r4
L_0607527A:
    c.r[13] = c.r[4];  // 0607527A mov r4,r13
    c.r[4] = (uint32_t)(int16_t)ld16(0x06075370u);  // 0607527C mov.w 0x06075370,r4
    c.r[1] = c.r[13];  // 0607527E mov r13,r1
    c.r[1] += c.r[1];  // 06075280 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075282 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06075284 mov.l r1,@-r15
    c.r[1] = ld32(0x06075390u);  // 06075286 mov.l 0x06075390,r1
    c.r[7] = 0x24u;  // 06075288 mov #36,r7
    c.r[6] = 0x5u;  // 0607528A mov #5,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06075290u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075290u) return; }  // 0607528C jsr @r1 ; mov #1,r5
    c.r[1] = ld32(0x06075394u);  // 06075290 mov.l 0x06075394,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075296u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075296u) return; }  // 06075292 jsr @r1 ; mov r13,r4
    c.r[1] = ld32(0x06075388u);  // 06075296 mov.l 0x06075388,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075298 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607529A extu.b r1,r0
    c.r[1] = ld32(0x0607538Cu);  // 0607529C mov.l 0x0607538C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607529E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060752A0 extu.b r1,r1
    c.r[1] -= 1;  // 060752A2 add #-1,r1
    c.r[11] = c.r[1];  // 060752A4 mov r1,r11
    c.r[11] <<= 2;  // 060752A6 shll2 r11
    c.r[11] += c.r[1];  // 060752A8 add r1,r11
    c.r[11] += c.r[11];  // 060752AA add r11,r11
    c.r[1] = c.r[11];  // 060752AC mov r11,r1
    c.r[1] += c.r[13];  // 060752AE add r13,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 060752B0 cmp/ge r1,r11
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_060752BA; } }  // 060752B2 bf/s 0x060752BA ; add #4,r15
    goto L_060753DC;  // 060752B6 bra 0x060753DC ; nop
L_060752BA:
    c.r[12] = ld32(0x06075398u);  // 060752BA mov.l 0x06075398,r12
L_060752BC:
    c.r[0] = ld32(0x06075384u);  // 060752BC mov.l 0x06075384,r0
    c.r[10] = c.r[11];  // 060752BE mov r11,r10
    c.r[1] = ld32(c.r[0]);  // 060752C0 mov.l @r0,r1
    c.r[10] += c.r[10];  // 060752C2 add r10,r10
    c.r[1] += c.r[10];  // 060752C4 add r10,r1
    c.r[1] += 1;  // 060752C6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060752C8 mov.b @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06075370u);  // 060752CA mov.w 0x06075370,r5
    c.r[2] = ld32(c.r[12]);  // 060752CC mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060752CE extu.b r1,r1
    c.r[8] = c.r[1];  // 060752D0 mov r1,r8
    c.r[8] += c.r[8];  // 060752D2 add r8,r8
    c.r[8] += c.r[1];  // 060752D4 add r1,r8
    c.r[8] <<= 2;  // 060752D6 shll2 r8
    c.r[0] = c.r[8];  // 060752D8 mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060752DA mov.w @(r0,r2),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075372u);  // 060752DC mov.w 0x06075372,r1
    c.r[4] += c.r[1];  // 060752DE add r1,r4
    c.r[1] = ld32(0x0607539Cu);  // 060752E0 mov.l 0x0607539C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060752E6u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060752E6u) return; }  // 060752E2 jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x0u;  // 060752E6 mov #0,r5
    c.r[1] = ld32(c.r[12]);  // 060752E8 mov.l @r12,r1
    c.r[4] = 0x0u;  // 060752EA mov #0,r4
    c.r[1] += c.r[8];  // 060752EC add r8,r1
    c.r[1] += 2;  // 060752EE add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060752F0 mov.b @r1,r6
    c.r[0] = ld32(0x060753A0u);  // 060752F2 mov.l 0x060753A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060752F8u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060752F8u) return; }  // 060752F4 jsr @r0 ; extu.b r6,r6
    c.r[5] = 0x0u;  // 060752F8 mov #0,r5
    c.r[1] = ld32(c.r[12]);  // 060752FA mov.l @r12,r1
    c.r[4] = 0x0u;  // 060752FC mov #0,r4
    c.r[1] += c.r[8];  // 060752FE add r8,r1
    c.r[1] += 10;  // 06075300 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06075302 mov.w @r1,r1
    c.r[0] = ld32(0x060753A0u);  // 06075304 mov.l 0x060753A0,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06075306 extu.w r1,r1
    c.r[1] += c.r[1];  // 06075308 add r1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0607530A extu.w r1,r9
    { const uint32_t x = c.r[0]; c.pr = 0x06075310u; c.r[6] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075310u) return; }  // 0607530C jsr @r0 ; mov r9,r6
    c.r[2] = ld32(c.r[12]);  // 06075310 mov.l @r12,r2
    c.r[2] += c.r[8];  // 06075312 add r8,r2
    c.r[1] = c.r[2];  // 06075314 mov r2,r1
    c.r[1] += 2;  // 06075316 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075318 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607531A extu.b r1,r1
    c.r[0] = c.r[1];  // 0607531C mov r1,r0
    c.t = c.r[0] == 0x63u;  // 0607531E cmp/eq #99,r0
    { const bool k = c.t; c.r[2] += 4; if (k) { goto L_060753B4; } }  // 06075320 bt/s 0x060753B4 ; add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06075324 mov.w @r2,r1
    c.r[1] -= c.r[9];  // 06075326 sub r9,r1
    st16(c.r[2], c.r[1]);  // 06075328 mov.w r1,@r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0607532A exts.w r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 0607532C cmp/pl r1
    if (c.t) { goto L_060753B4; }  // 0607532E bt 0x060753B4
    c.r[8] = ld32(0x060753A4u);  // 06075330 mov.l 0x060753A4,r8
    c.r[4] = ld32(0x060753A8u);  // 06075332 mov.l 0x060753A8,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06075338u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075338u) return; }  // 06075334 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06075338 mov r0,r1
    c.r[5] = 0xAu;  // 0607533A mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06075340u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075340u) return; }  // 0607533C jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06075340 mov r0,r1
    c.r[5] = 0xEu;  // 06075342 mov #14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06075348u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075348u) return; }  // 06075344 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06075348 mov r0,r2
    c.r[1] = ld32(0x060753ACu);  // 0607534A mov.l 0x060753AC,r1
    c.r[6] = 0x0u;  // 0607534C mov #0,r6
    c.r[5] = c.r[2];  // 0607534E mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06075354u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075354u) return; }  // 06075350 jsr @r1 ; mov #0,r4
    c.r[0] = ld32(0x06075384u);  // 06075354 mov.l 0x06075384,r0
    c.r[1] = ld32(c.r[0]);  // 06075356 mov.l @r0,r1
    c.r[0] = c.r[1];  // 06075358 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607535A mov.b @(r0,r10),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075374u);  // 0607535C mov.w 0x06075374,r0
    c.r[2] |= c.r[0];  // 0607535E or r0,r2
    c.r[0] = c.r[1];  // 06075360 mov r1,r0
    st8(c.r[0] + c.r[10], c.r[2]);  // 06075362 mov.b r2,@(r0,r10)
    c.r[2] = ld32(0x060753B0u);  // 06075364 mov.l 0x060753B0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075366 mov.b @r2,r1
    c.r[1] += 1;  // 06075368 add #1,r1
    st8(c.r[2], c.r[1]); goto L_060753BA;  // 0607536A bra 0x060753BA ; mov.b r1,@r2
L_060753B4:
    c.r[1] = ld32(0x06075448u);  // 060753B4 mov.l 0x06075448,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060753BAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060753BAu) return; }  // 060753B6 jsr @r1 ; mov #0,r4
L_060753BA:
    c.r[1] = ld32(0x0607544Cu);  // 060753BA mov.l 0x0607544C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060753BC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060753BE extu.b r1,r0
    c.r[1] = ld32(0x06075450u);  // 060753C0 mov.l 0x06075450,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060753C2 mov.b @(r0,r1),r1
    c.r[11] += 1;  // 060753C4 add #1,r11
    c.r[1] = c.r[1] & 0xFFu;  // 060753C6 extu.b r1,r1
    c.r[1] -= 1;  // 060753C8 add #-1,r1
    c.r[2] = c.r[1];  // 060753CA mov r1,r2
    c.r[2] <<= 2;  // 060753CC shll2 r2
    c.r[2] += c.r[1];  // 060753CE add r1,r2
    c.r[2] += c.r[2];  // 060753D0 add r2,r2
    c.r[2] += c.r[13];  // 060753D2 add r13,r2
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[2];  // 060753D4 cmp/ge r2,r11
    if (c.t) { goto L_060753DC; }  // 060753D6 bt 0x060753DC
    SH2_POLL(c); goto L_060752BC;  // 060753D8 bra 0x060752BC ; nop
L_060753DC:
    c.r[1] = ld32(0x06075454u);  // 060753DC mov.l 0x06075454,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060753E2u; c.r[4] = 0x39u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060753E2u) return; }  // 060753DE jsr @r1 ; mov #57,r4
    c.r[1] = ld32(0x0607544Cu);  // 060753E2 mov.l 0x0607544C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060753E4 mov.b @r1,r1
    c.r[7] = ld32(0x06075450u);  // 060753E6 mov.l 0x06075450,r7
    c.r[3] = c.r[1] & 0xFFu;  // 060753E8 extu.b r1,r3
    c.r[0] = c.r[3];  // 060753EA mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060753EC mov.b @(r0,r7),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06075444u);  // 060753EE mov.w 0x06075444,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060753F0 extu.b r1,r1
    c.r[1] -= 1;  // 060753F2 add #-1,r1
    c.r[2] = c.r[1];  // 060753F4 mov r1,r2
    c.r[2] <<= 2;  // 060753F6 shll2 r2
    c.r[2] += c.r[1];  // 060753F8 add r1,r2
    c.r[1] = ld32(0x06075458u);  // 060753FA mov.l 0x06075458,r1
    c.r[1] = ld32(c.r[1]);  // 060753FC mov.l @r1,r1
    c.r[2] += c.r[2];  // 060753FE add r2,r2
    c.r[0] = c.r[1];  // 06075400 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06075402 mov.b @(r0,r6),r1
    c.r[2] += c.r[13];  // 06075404 add r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075406 extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06075408 cmp/ge r1,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06075422; } }  // 0607540A bf/s 0x06075422 ; mov r3,r0
    c.r[1] = ld32(0x0607545Cu);  // 0607540E mov.l 0x0607545C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075410 mov.b @r1,r1
    c.r[2] = ld32(0x06075460u);  // 06075412 mov.l 0x06075460,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075414 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06075416 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0607541E; } }  // 06075418 bt/s 0x0607541E ; mov #1,r1
    c.r[1] = 0x2u;  // 0607541C mov #2,r1
L_0607541E:
    st8(c.r[2], c.r[1]); goto L_0607542E;  // 0607541E bra 0x0607542E ; mov.b r1,@r2
L_06075422:
    c.r[2] = ld32(0x06075460u);  // 06075422 mov.l 0x06075460,r2
    c.r[1] = 0x0u;  // 06075424 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06075426 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06075428 mov.b @(r0,r7),r1
    c.r[1] += 1;  // 0607542A add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607542C mov.b r1,@(r0,r7)
L_0607542E:
    c.r[15] = c.r[14];  // 0607542E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06075430 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06075432 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06075434 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06075436 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06075438 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607543A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607543C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075446u);  // 0607543E mov.w 0x06075446,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075440 rts ; mov.l @r15+,r8
}

void f_06075464(SH2Context& c) {
    ran[1619] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06075464 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06075466 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06075468 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607546A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607546C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607546E sts.l pr,@-r15
    c.r[15] -= 100;  // 06075470 add #-100,r15
    c.r[14] = c.r[15];  // 06075472 mov r15,r14
    c.r[1] = ld32(0x06075564u);  // 06075474 mov.l 0x06075564,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607547Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607547Au) return; }  // 06075476 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06075568u);  // 0607547A mov.l 0x06075568,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075480u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075480u) return; }  // 0607547C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607556Cu);  // 06075480 mov.l 0x0607556C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075486u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075486u) return; }  // 06075482 jsr @r1 ; nop
    c.r[1] = ld32(0x06075570u);  // 06075486 mov.l 0x06075570,r1
    c.r[7] = ld32(c.r[1]);  // 06075488 mov.l @r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607555Cu);  // 0607548A mov.w 0x0607555C,r1
    c.r[0] = c.r[7];  // 0607548C mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607548E mov.b @(r0,r1),r1
    c.r[2] = 0x0u;  // 06075490 mov #0,r2
    c.r[6] = c.r[1] & 0xFFu;  // 06075492 extu.b r1,r6
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 06075494 cmp/ge r6,r2
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_060754C4; } }  // 06075496 bt/s 0x060754C4 ; mov #0,r3
    c.r[4] = c.r[7];  // 0607549A mov r7,r4
    c.r[1] = ld32(0x06075574u);  // 0607549C mov.l 0x06075574,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607549E mov.b @r1,r1
    c.r[7] = c.r[6];  // 060754A0 mov r6,r7
    c.r[6] = 0x0u;  // 060754A2 mov #0,r6
    c.r[5] = c.r[1] & 0xFFu;  // 060754A4 extu.b r1,r5
    c.r[5] += 1;  // 060754A6 add #1,r5
L_060754A8:
    c.r[0] = c.r[6];  // 060754A8 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060754AA mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060754AC extu.b r1,r1
    c.r[1] >>= 2;  // 060754AE shlr2 r1
    c.r[1] >>= 2;  // 060754B0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060754B2 shlr r1
    c.r[1] >>= 2;  // 060754B4 shlr2 r1
    c.r[3] += c.r[1];  // 060754B6 add r1,r3
    c.t = c.r[3] == c.r[5];  // 060754B8 cmp/eq r5,r3
    if (c.t) { goto L_060754C4; }  // 060754BA bt 0x060754C4
    c.r[2] += 1;  // 060754BC add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 060754BE cmp/ge r7,r2
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_060754A8; } }  // 060754C0 bf/s 0x060754A8 ; add #2,r6
L_060754C4:
    c.r[1] = ld32(0x06075570u);  // 060754C4 mov.l 0x06075570,r1
    c.r[2] += c.r[2];  // 060754C6 add r2,r2
    c.r[8] = c.r[14];  // 060754C8 mov r14,r8
    c.r[8] += 96;  // 060754CA add #96,r8
    c.r[1] = ld32(c.r[1]);  // 060754CC mov.l @r1,r1
    c.r[9] = ld32(0x06075578u);  // 060754CE mov.l 0x06075578,r9
    c.r[1] += c.r[2];  // 060754D0 add r2,r1
    c.r[1] += 1;  // 060754D2 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060754D4 mov.b @r1,r5
    c.r[4] = c.r[14];  // 060754D6 mov r14,r4
    c.r[5] = c.r[5] & 0xFFu;  // 060754D8 extu.b r5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060754DEu; st8(c.r[8], c.r[5]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060754DEu) return; }  // 060754DA jsr @r9 ; mov.b r5,@r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0607555Eu);  // 060754DE mov.w 0x0607555E,r10
    c.r[5] = c.r[10];  // 060754E0 mov r10,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060754E2 mov.b @r8,r4
    c.r[0] = ld32(0x0607557Cu);  // 060754E4 mov.l 0x0607557C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060754EAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060754EAu) return; }  // 060754E6 jsr @r0 ; extu.b r4,r4
    c.r[11] = c.r[14];  // 060754EA mov r14,r11
    c.r[11] += 48;  // 060754EC add #48,r11
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060754EE mov.b @r8,r5
    c.r[4] = c.r[11];  // 060754F0 mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060754F6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060754F6u) return; }  // 060754F2 jsr @r9 ; extu.b r5,r5
    c.r[9] = ld32(0x06075580u);  // 060754F6 mov.l 0x06075580,r9
    c.r[5] = 0x0u;  // 060754F8 mov #0,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060754FA mov.b @r8,r1
    c.r[4] = 0x0u;  // 060754FC mov #0,r4
    c.r[3] = ld32(c.r[9]);  // 060754FE mov.l @r9,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06075500 extu.b r1,r1
    c.r[2] = c.r[1];  // 06075502 mov r1,r2
    c.r[2] += c.r[2];  // 06075504 add r2,r2
    c.r[2] += c.r[1];  // 06075506 add r1,r2
    c.r[2] <<= 2;  // 06075508 shll2 r2
    c.r[2] += c.r[3];  // 0607550A add r3,r2
    c.r[2] += 2;  // 0607550C add #2,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607550E mov.b @r2,r6
    c.r[1] = ld32(0x06075584u);  // 06075510 mov.l 0x06075584,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075516u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075516u) return; }  // 06075512 jsr @r1 ; extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06075516 mov.b @r8,r1
    c.r[5] = c.r[10];  // 06075518 mov r10,r5
    c.r[3] = ld32(c.r[9]);  // 0607551A mov.l @r9,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607551C extu.b r1,r1
    c.r[2] = c.r[1];  // 0607551E mov r1,r2
    c.r[2] += c.r[2];  // 06075520 add r2,r2
    c.r[2] += c.r[1];  // 06075522 add r1,r2
    c.r[2] <<= 2;  // 06075524 shll2 r2
    c.r[0] = c.r[2];  // 06075526 mov r2,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06075528 mov.w @(r0,r3),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075560u);  // 0607552A mov.w 0x06075560,r1
    c.r[4] += c.r[1];  // 0607552C add r1,r4
    c.r[1] = ld32(0x06075588u);  // 0607552E mov.l 0x06075588,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075534u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075534u) return; }  // 06075530 jsr @r1 ; extu.w r4,r4
    c.r[1] = 0xDu;  // 06075534 mov #13,r1
    st8(c.r[8], c.r[1]);  // 06075536 mov.b r1,@r8
    c.r[6] = c.r[8];  // 06075538 mov r8,r6
    c.r[5] = c.r[11];  // 0607553A mov r11,r5
    c.r[0] = ld32(0x0607558Cu);  // 0607553C mov.l 0x0607558C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075542u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075542u) return; }  // 0607553E jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x06075590u);  // 06075542 mov.l 0x06075590,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075548u; c.r[4] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075548u) return; }  // 06075544 jsr @r1 ; mov #58,r4
    c.r[14] += 100;  // 06075548 add #100,r14
    c.r[15] = c.r[14];  // 0607554A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607554C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607554E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06075550 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06075552 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06075554 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075562u);  // 06075556 mov.w 0x06075562,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075558 rts ; mov.l @r15+,r8
}

void f_06075594(SH2Context& c) {
    ran[1620] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06075594 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06075596 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06075598 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607559A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607559C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607559E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060756B6u);  // 060755A0 mov.w 0x060756B6,r3
    c.r[15] += c.r[3];  // 060755A2 add r3,r15
    c.r[14] = c.r[15];  // 060755A4 mov r15,r14
    c.r[1] = ld32(0x060756C4u);  // 060755A6 mov.l 0x060756C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060755ACu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060755ACu) return; }  // 060755A8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060756C8u);  // 060755AC mov.l 0x060756C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060755B2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060755B2u) return; }  // 060755AE jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060756CCu);  // 060755B2 mov.l 0x060756CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060755B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060755B8u) return; }  // 060755B4 jsr @r1 ; nop
    c.r[1] = ld32(0x060756D0u);  // 060755B8 mov.l 0x060756D0,r1
    c.r[1] = ld32(c.r[1]);  // 060755BA mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060756B8u);  // 060755BC mov.w 0x060756B8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060755BE mov.b @(r0,r1),r1
    c.r[9] = ld32(0x060756D4u);  // 060755C0 mov.l 0x060756D4,r9
    c.r[8] = c.r[1] & 0xFFu;  // 060755C2 extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060755C4 mov.b @r9,r1
    c.r[2] = 0xBu;  // 060755C6 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060755C8 extu.b r1,r1
    c.r[8] -= c.r[1];  // 060755CA sub r1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[2];  // 060755CC cmp/gt r2,r8
    if (!c.t) { goto L_060755D2; }  // 060755CE bf 0x060755D2
    c.r[8] = c.r[2];  // 060755D0 mov r2,r8
L_060755D2:
    c.t = (c.r[1] & c.r[1]) == 0;  // 060755D2 tst r1,r1
    if (!c.t) { goto L_060755F0; }  // 060755D4 bf 0x060755F0
    c.r[1] = ld32(0x060756D8u);  // 060755D6 mov.l 0x060756D8,r1
    c.r[3] = ld32(c.r[1]);  // 060755D8 mov.l @r1,r3
    c.r[7] = ld32(0x060756DCu);  // 060755DA mov.l 0x060756DC,r7
    c.r[1] = c.r[3];  // 060755DC mov r3,r1
    c.r[1] += 10;  // 060755DE add #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060755E0 mov.w @r1,r2
    c.r[3] += 12;  // 060755E2 add #12,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 060755E4 extu.w r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060755E6 mov.b @r3,r1
    c.r[2] <<= 8;  // 060755E8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060755EA extu.b r1,r1
    c.r[1] |= c.r[2];  // 060755EC or r2,r1
    st32(c.r[7], c.r[1]);  // 060755EE mov.l r1,@r7
L_060755F0:
    c.r[10] = ld32(0x060756DCu);  // 060755F0 mov.l 0x060756DC,r10
    c.r[1] = ld32(0x060756E0u);  // 060755F2 mov.l 0x060756E0,r1
    c.r[5] = 0x0u;  // 060755F4 mov #0,r5
    c.r[6] = ld32(c.r[10]);  // 060755F6 mov.l @r10,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060755FCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060755FCu) return; }  // 060755F8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060756E4u);  // 060755FC mov.l 0x060756E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075602u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075602u) return; }  // 060755FE jsr @r1 ; extu.b r8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075602 mov.b @r9,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06075604 extu.b r1,r8
    c.r[1] = c.r[8];  // 06075606 mov r8,r1
    c.r[1] += 11;  // 06075608 add #11,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607560A cmp/ge r1,r8
    if (c.t) { goto L_0607569A; }  // 0607560C bt 0x0607569A
    c.r[11] = (uint32_t)(int16_t)ld16(0x060756BAu);  // 0607560E mov.w 0x060756BA,r11
    c.r[9] = (uint32_t)(int16_t)ld16(0x060756BCu);  // 06075610 mov.w 0x060756BC,r9
L_06075612:
    c.r[1] = ld32(0x060756D0u);  // 06075612 mov.l 0x060756D0,r1
    c.r[2] = ld32(c.r[1]);  // 06075614 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060756B8u);  // 06075616 mov.w 0x060756B8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06075618 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607561A extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607561C cmp/ge r1,r8
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0607569A; } }  // 0607561E bt/s 0x0607569A ; mov r8,r1
    c.r[1] += c.r[1];  // 06075622 add r1,r1
    c.r[0] = c.r[2];  // 06075624 mov r2,r0
    c.r[2] += c.r[1];  // 06075626 add r1,r2
    c.r[2] += 1;  // 06075628 add #1,r2
    c.r[6] = c.r[11];  // 0607562A mov r11,r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607562C mov.b @(r0,r1),r3
    c.r[4] = c.r[14];  // 0607562E mov r14,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075630 mov.b @r2,r2
    c.r[0] = 0x7Fu;  // 06075632 mov #127,r0
    c.r[3] &= c.r[0];  // 06075634 and r0,r3
    c.r[3] <<= 8;  // 06075636 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06075638 extu.b r2,r2
    c.r[2] |= c.r[3];  // 0607563A or r3,r2
    c.r[1] = ld32(0x060756E8u);  // 0607563C mov.l 0x060756E8,r1
    c.r[1] = ld32(c.r[1]);  // 0607563E mov.l @r1,r1
    c.r[2] <<= 2;  // 06075640 shll2 r2
    c.r[2] <<= 2;  // 06075642 shll2 r2
    c.r[2] += c.r[1];  // 06075644 add r1,r2
    c.r[2] += 2;  // 06075646 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075648 mov.b @r2,r5
    c.r[1] = ld32(0x060756ECu);  // 0607564A mov.l 0x060756EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075650u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075650u) return; }  // 0607564C jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060756BEu);  // 06075650 mov.w 0x060756BE,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 06075652 mov.w @r14,r4
    c.r[5] = c.r[11];  // 06075654 mov r11,r5
    c.r[4] += c.r[1];  // 06075656 add r1,r4
    c.r[1] = ld32(0x060756F0u);  // 06075658 mov.l 0x060756F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607565Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607565Eu) return; }  // 0607565A jsr @r1 ; extu.w r4,r4
    c.r[0] = c.r[14];  // 0607565E mov r14,r0
    c.r[1] = ld32(0x060756E0u);  // 06075660 mov.l 0x060756E0,r1
    c.r[5] = 0x0u;  // 06075662 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06075664 mov.w @(r0,r9),r6
    c.r[4] = 0x0u;  // 06075666 mov #0,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0607566Cu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607566Cu) return; }  // 06075668 jsr @r1 ; extu.w r6,r6
    c.r[1] = ld32(0x060756D4u);  // 0607566C mov.l 0x060756D4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607566E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075670 extu.b r1,r1
    c.t = c.r[8] == c.r[1];  // 06075672 cmp/eq r1,r8
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_0607568C; } }  // 06075674 bf/s 0x0607568C ; mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06075678 mov.w @(r0,r9),r1
    c.r[2] = ld32(c.r[10]);  // 0607567A mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607567C extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 0607567E cmp/hs r1,r2
    { const bool k = !c.t; c.r[2] -= c.r[1]; if (k) { goto L_06075688; } }  // 06075680 bf/s 0x06075688 ; sub r1,r2
    st32(c.r[10], c.r[2]); goto L_0607568C;  // 06075684 bra 0x0607568C ; mov.l r2,@r10
L_06075688:
    c.r[1] = 0x0u;  // 06075688 mov #0,r1
    st32(c.r[10], c.r[1]);  // 0607568A mov.l r1,@r10
L_0607568C:
    c.r[1] = ld32(0x060756D4u);  // 0607568C mov.l 0x060756D4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607568E mov.b @r1,r1
    c.r[8] += 1;  // 06075690 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06075692 extu.b r1,r1
    c.r[1] += 11;  // 06075694 add #11,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06075696 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06075612; }  // 06075698 bf 0x06075612
L_0607569A:
    c.r[1] = ld32(0x060756F4u);  // 0607569A mov.l 0x060756F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060756A0u; c.r[4] = 0x3Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060756A0u) return; }  // 0607569C jsr @r1 ; mov #59,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060756C0u);  // 060756A0 mov.w 0x060756C0,r3
    c.r[14] += c.r[3];  // 060756A2 add r3,r14
    c.r[15] = c.r[14];  // 060756A4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060756A6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060756A8 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060756AA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060756AC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060756AE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060756C2u);  // 060756B0 mov.w 0x060756C2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060756B2 rts ; mov.l @r15+,r8
}

void f_060756F8(SH2Context& c) {
    ran[1621] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060756F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060756FA sts.l pr,@-r15
    c.r[1] = ld32(0x06075718u);  // 060756FC mov.l 0x06075718,r1
    c.r[1] = ld32(c.r[1]);  // 060756FE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075700 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06075702 extu.b r1,r0
    c.r[0] <<= 2;  // 06075704 shll2 r0
    c.r[1] = ld32(0x0607571Cu);  // 06075706 mov.l 0x0607571C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06075708 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607570Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607570Eu) return; }  // 0607570A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0607570E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06075710 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06075712 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06075714 rts ; extu.w r0,r0
}

void f_06075720(SH2Context& c) {
    ran[1622] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075720 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06075722 mov r15,r14
    c.r[1] = ld32(0x060757D0u);  // 06075724 mov.l 0x060757D0,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075726 mov.b @r1,r3
    c.r[5] = ld32(0x060757D4u);  // 06075728 mov.l 0x060757D4,r5
    c.r[1] = c.r[5];  // 0607572A mov r5,r1
    c.r[1] += 22;  // 0607572C add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607572E mov.w @r1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06075730 extu.b r3,r2
    c.r[2] += c.r[1];  // 06075732 add r1,r2
    c.r[2] += 1;  // 06075734 add #1,r2
    c.r[1] = ld32(0x060757D8u);  // 06075736 mov.l 0x060757D8,r1
    c.r[1] = ld32(c.r[1]);  // 06075738 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607573A extu.w r2,r2
    c.r[1] += 1;  // 0607573C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607573E mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06075740 extu.b r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06075742 tst r7,r7
    { const bool k = !c.t; c.r[6] = c.r[2]; if (k) { goto L_0607575E; } }  // 06075744 bf/s 0x0607575E ; mov r2,r6
    c.r[1] = ld32(0x060757DCu);  // 06075748 mov.l 0x060757DC,r1
    c.r[3] = c.r[2];  // 0607574A mov r2,r3
    c.r[3] += c.r[3];  // 0607574C add r3,r3
    c.r[3] += c.r[2];  // 0607574E add r2,r3
    c.r[1] = ld32(c.r[1] + 12);  // 06075750 mov.l @(12,r1),r1
    c.r[3] <<= 2;  // 06075752 shll2 r3
    c.r[3] += c.r[1];  // 06075754 add r1,r3
    c.r[2] = ld32(c.r[3] + 4);  // 06075756 mov.l @(4,r3),r2
    c.r[1] = ld32(c.r[5] + 4);  // 06075758 mov.l @(4,r5),r1
    c.r[2] += c.r[1]; goto L_06075794;  // 0607575A bra 0x06075794 ; add r1,r2
L_0607575E:
    c.r[2] = c.r[3] & 0xFFu;  // 0607575E extu.b r3,r2
    c.r[1] = ld32(0x060757E0u);  // 06075760 mov.l 0x060757E0,r1
    c.r[1] = ld32(c.r[1]);  // 06075762 mov.l @r1,r1
    c.r[2] <<= 2;  // 06075764 shll2 r2
    c.r[2] <<= 2;  // 06075766 shll2 r2
    c.r[2] += c.r[1];  // 06075768 add r1,r2
    c.r[2] += 3;  // 0607576A add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607576C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0607576E mov r1,r0
    c.r[0] >>= 2;  // 06075770 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06075772 shlr r0
    c.r[0] &= 0x3u;  // 06075774 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06075776 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06075796; } }  // 06075778 bf/s 0x06075796 ; mov r7,r0
    c.t = c.r[0] == 0x1u;  // 0607577C cmp/eq #1,r0
    { const bool k = !c.t; c.r[3] = c.r[6]; if (k) { goto L_06075796; } }  // 0607577E bf/s 0x06075796 ; mov r6,r3
    c.r[1] = ld32(0x060757DCu);  // 06075782 mov.l 0x060757DC,r1
    c.r[3] += c.r[3];  // 06075784 add r3,r3
    c.r[3] += c.r[6];  // 06075786 add r6,r3
    c.r[1] = ld32(c.r[1] + 12);  // 06075788 mov.l @(12,r1),r1
    c.r[3] <<= 2;  // 0607578A shll2 r3
    c.r[3] += c.r[1];  // 0607578C add r1,r3
    c.r[2] = ld32(c.r[3] + 4);  // 0607578E mov.l @(4,r3),r2
    c.r[1] = ld32(c.r[5] + 4);  // 06075790 mov.l @(4,r5),r1
    c.r[2] -= c.r[1];  // 06075792 sub r1,r2
L_06075794:
    st32(c.r[3] + 4, c.r[2]);  // 06075794 mov.l r2,@(4,r3)
L_06075796:
    c.r[1] = ld32(0x060757D0u);  // 06075796 mov.l 0x060757D0,r1
    c.r[3] = 0x3u;  // 06075798 mov #3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607579A mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060757CAu);  // 0607579C mov.w 0x060757CA,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0607579E extu.b r2,r2
    c.r[1] = ld32(0x060757E0u);  // 060757A0 mov.l 0x060757E0,r1
    c.r[1] = ld32(c.r[1]);  // 060757A2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060757A4 shll2 r2
    c.r[2] <<= 2;  // 060757A6 shll2 r2
    c.r[2] += c.r[1];  // 060757A8 add r1,r2
    c.r[1] = ld32(0x060757D8u);  // 060757AA mov.l 0x060757D8,r1
    c.r[1] = ld32(c.r[1]);  // 060757AC mov.l @r1,r1
    c.r[15] = c.r[14];  // 060757AE mov r14,r15
    c.r[1] += 1;  // 060757B0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060757B2 mov.b @r1,r1
    c.r[2] += 3;  // 060757B4 add #3,r2
    c.r[3] &= c.r[1];  // 060757B6 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060757B8 mov.b @r2,r1
    c.r[3] <<= 2;  // 060757BA shll2 r3
    c.r[3] += c.r[3];  // 060757BC add r3,r3
    c.r[1] &= c.r[0];  // 060757BE and r0,r1
    c.r[1] |= c.r[3];  // 060757C0 or r3,r1
    st8(c.r[2], c.r[1]);  // 060757C2 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060757CCu);  // 060757C4 mov.w 0x060757CC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060757C6 rts ; mov.l @r15+,r14
}

void f_060757E4(SH2Context& c) {
    ran[1623] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060757E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060757E6 sts.l pr,@-r15
    c.r[1] = ld32(0x06075818u);  // 060757E8 mov.l 0x06075818,r1
    c.r[1] = ld32(c.r[1]);  // 060757EA mov.l @r1,r1
    c.r[1] += 1;  // 060757EC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060757EE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060757F0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060757F2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06075806; } }  // 060757F4 bt/s 0x06075806 ; mov r15,r14
    c.r[1] = ld32(0x0607581Cu);  // 060757F8 mov.l 0x0607581C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060757FA mov.b @r1,r4
    c.r[1] = ld32(0x06075820u);  // 060757FC mov.l 0x06075820,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075802u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075802u) return; }  // 060757FE jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14]; goto L_0607580E;  // 06075802 bra 0x0607580E ; mov r14,r15
L_06075806:
    c.r[1] = ld32(0x06075824u);  // 06075806 mov.l 0x06075824,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607580Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607580Cu) return; }  // 06075808 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607580C mov r14,r15
L_0607580E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607580E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075816u);  // 06075810 mov.w 0x06075816,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075812 rts ; mov.l @r15+,r14
}

void f_06075828(SH2Context& c) {
    ran[1624] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075828 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607582A sts.l pr,@-r15
    c.r[1] = ld32(0x0607585Cu);  // 0607582C mov.l 0x0607585C,r1
    c.r[1] = ld32(c.r[1]);  // 0607582E mov.l @r1,r1
    c.r[1] += 1;  // 06075830 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075832 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075834 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06075836 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06075844; } }  // 06075838 bt/s 0x06075844 ; mov r15,r14
    c.r[1] = ld32(0x06075860u);  // 0607583C mov.l 0x06075860,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607583E mov.b @r1,r5
    c.r[4] = 0x1u; goto L_0607584A;  // 06075840 bra 0x0607584A ; mov #1,r4
L_06075844:
    c.r[1] = ld32(0x06075860u);  // 06075844 mov.l 0x06075860,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075846 mov.b @r1,r5
    c.r[4] = 0x0u;  // 06075848 mov #0,r4
L_0607584A:
    c.r[1] = ld32(0x06075864u);  // 0607584A mov.l 0x06075864,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075850u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075850u) return; }  // 0607584C jsr @r1 ; extu.b r5,r5
    c.r[15] = c.r[14];  // 06075850 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06075852 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607585Au);  // 06075854 mov.w 0x0607585A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075856 rts ; mov.l @r15+,r14
}

void f_06075868(SH2Context& c) {
    ran[1625] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075868 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607586A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607586C mov r15,r14
    c.r[0] = ld32(0x060758B0u);  // 0607586E mov.l 0x060758B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075874u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075874u) return; }  // 06075870 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(0x060758B4u);  // 06075874 mov.l 0x060758B4,r1
    c.r[1] = ld32(c.r[1]);  // 06075876 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060758AAu);  // 06075878 mov.w 0x060758AA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607587A mov.b @(r0,r1),r1
    c.r[2] = 0x1u;  // 0607587C mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607587E extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06075880 cmp/hi r2,r1
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06075892; } }  // 06075882 bf/s 0x06075892 ; mov #0,r4
    c.r[1] = ld32(0x060758B8u);  // 06075886 mov.l 0x060758B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075888 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607588A extu.b r1,r0
    c.r[1] = ld32(0x060758BCu);  // 0607588C mov.l 0x060758BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607588E mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06075890 extu.b r1,r4
L_06075892:
    c.r[0] = ld32(0x060758C0u);  // 06075892 mov.l 0x060758C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075898u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075898u) return; }  // 06075894 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06075898 extu.b r0,r1
    c.r[0] = c.r[1];  // 0607589A mov r1,r0
    c.r[0] += c.r[0];  // 0607589C add r0,r0
    c.r[15] = c.r[14];  // 0607589E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060758A0 lds.l @r15+,pr
    c.r[1] = (uint32_t)(int16_t)ld16(0x060758ACu);  // 060758A2 mov.w 0x060758AC,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060758A4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 060758A6 rts ; or r1,r0
}

void f_060758C4(SH2Context& c) {
    ran[1626] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060758C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060758C6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060758C8 mov r15,r14
    c.r[0] = ld32(0x0607591Cu);  // 060758CA mov.l 0x0607591C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060758D0u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060758D0u) return; }  // 060758CC jsr @r0 ; mov #1,r4
    c.r[0] = ld32(0x06075920u);  // 060758D0 mov.l 0x06075920,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060758D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060758D6u) return; }  // 060758D2 jsr @r0 ; nop
    c.r[7] = c.r[0] & 0xFFu;  // 060758D6 extu.b r0,r7
    c.r[1] = ld32(0x06075924u);  // 060758D8 mov.l 0x06075924,r1
    c.r[1] = ld32(c.r[1]);  // 060758DA mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075914u);  // 060758DC mov.w 0x06075914,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060758DE mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 060758E0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060758E2 shlr r0
    c.r[0] &= 0xFu;  // 060758E4 and #15,r0
    c.t = c.r[0] == 0x2u;  // 060758E6 cmp/eq #2,r0
    { const bool k = c.t; c.r[3] = 0x1u; if (k) { goto L_06075904; } }  // 060758E8 bt/s 0x06075904 ; mov #1,r3
    c.r[1] = ld32(0x06075928u);  // 060758EC mov.l 0x06075928,r1
    c.r[2] = ld32(c.r[1]);  // 060758EE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075916u);  // 060758F0 mov.w 0x06075916,r1
    c.r[0] = c.r[2];  // 060758F2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060758F4 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060758F6 extu.b r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060758F8 cmp/ge r1,r3
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_06075904; } }  // 060758FA bt/s 0x06075904 ; add #1,r3
L_060758FE:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060758FE cmp/ge r1,r3
    { const bool k = !c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_060758FE; } }  // 06075900 bf/s 0x060758FE ; add #1,r3
L_06075904:
    c.r[7] += c.r[7];  // 06075904 add r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075918u);  // 06075906 mov.w 0x06075918,r1
    c.r[15] = c.r[14];  // 06075908 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607590A lds.l @r15+,pr
    c.r[7] |= c.r[1];  // 0607590C or r1,r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607590E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06075910 rts ; mov r7,r0
}

void f_0607592C(SH2Context& c) {
    ran[1627] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607592C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607592E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075930 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06075932 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06075A30u);  // 06075934 mov.w 0x06075A30,r3
    c.r[15] += c.r[3];  // 06075936 add r3,r15
    c.r[1] = ld32(0x06075A3Cu);  // 06075938 mov.l 0x06075A3C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607593A mov.b @r1,r4
    c.r[14] = c.r[15];  // 0607593C mov r15,r14
    c.r[1] = ld32(0x06075A40u);  // 0607593E mov.l 0x06075A40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075944u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075944u) return; }  // 06075940 jsr @r1 ; extu.b r4,r4
    c.r[9] = 0x0u;  // 06075944 mov #0,r9
    c.r[8] = 0x0u;  // 06075946 mov #0,r8
L_06075948:
    c.r[1] = ld32(0x06075A44u);  // 06075948 mov.l 0x06075A44,r1
    c.r[3] = c.r[8];  // 0607594A mov r8,r3
    c.r[0] = ld32(c.r[1]);  // 0607594C mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06075A32u);  // 0607594E mov.w 0x06075A32,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06075950 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075952 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06075954 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06075996; } }  // 06075956 bt/s 0x06075996 ; add r0,r3
    c.r[1] = c.r[3];  // 0607595A mov r3,r1
    c.r[1] += 7;  // 0607595C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607595E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06075960 mov r1,r0
    c.r[0] >>= 2;  // 06075962 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06075964 shlr r0
    c.r[0] &= 0x1u;  // 06075966 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06075968 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06075996; } }  // 0607596A bf/s 0x06075996 ; mov r3,r1
    c.r[1] += 4;  // 0607596E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075970 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06075972 mov r1,r0
    c.r[0] >>= 2;  // 06075974 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06075976 shlr r0
    c.r[0] >>= 2;  // 06075978 shlr2 r0
    c.r[0] &= 0x1u;  // 0607597A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607597C tst r0,r0
    { const bool k = c.t; c.r[3] += 6; if (k) { goto L_06075996; } }  // 0607597E bt/s 0x06075996 ; add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075982 mov.b @r3,r2
    c.r[1] = ld32(0x06075A3Cu);  // 06075984 mov.l 0x06075A3C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075986 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06075988 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607598A extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0607598C cmp/eq r1,r2
    if (!c.t) { goto L_06075996; }  // 0607598E bf 0x06075996
    c.r[1] = ld32(0x06075A40u);  // 06075990 mov.l 0x06075A40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075996u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075996u) return; }  // 06075992 jsr @r1 ; extu.b r9,r4
L_06075996:
    c.r[9] += 1;  // 06075996 add #1,r9
    c.r[1] = 0x49u;  // 06075998 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0607599A cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_06075948; } }  // 0607599C bf/s 0x06075948 ; add #16,r8
    c.r[6] = ld32(0x06075A48u);  // 060759A0 mov.l 0x06075A48,r6
    c.r[1] = ld32(0x06075A3Cu);  // 060759A2 mov.l 0x06075A3C,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060759A4 mov.b @r1,r3
    c.r[3] = c.r[3] & 0xFFu;  // 060759A6 extu.b r3,r3
    c.r[1] = ld32(0x06075A44u);  // 060759A8 mov.l 0x06075A44,r1
    c.r[3] <<= 2;  // 060759AA shll2 r3
    c.r[3] <<= 2;  // 060759AC shll2 r3
    c.r[7] = ld32(c.r[1]);  // 060759AE mov.l @r1,r7
    c.r[5] = c.r[3];  // 060759B0 mov r3,r5
    c.r[5] += c.r[7];  // 060759B2 add r7,r5
    c.r[1] = c.r[5];  // 060759B4 mov r5,r1
    c.r[1] += 1;  // 060759B6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060759B8 mov.b @r1,r2
    c.r[0] = c.r[3];  // 060759BA mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060759BC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060759BE mov.b @(r0,r7),r1
    c.r[2] <<= 2;  // 060759C0 shll2 r2
    c.r[2] <<= 2;  // 060759C2 shll2 r2
    c.r[2] <<= 2;  // 060759C4 shll2 r2
    c.r[3] = ld32(c.r[6]);  // 060759C6 mov.l @r6,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060759C8 extu.b r1,r1
    c.r[2] += c.r[3];  // 060759CA add r3,r2
    c.r[0] = c.r[2];  // 060759CC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060759CE mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060759D0 extu.b r1,r1
    c.r[1] <<= 2;  // 060759D2 shll2 r1
    c.r[1] <<= 2;  // 060759D4 shll2 r1
    c.r[1] += c.r[7];  // 060759D6 add r7,r1
    c.r[1] += 2;  // 060759D8 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060759DA mov.b @r1,r2
    c.r[1] = ld32(0x06075A4Cu);  // 060759DC mov.l 0x06075A4C,r1
    c.r[3] = ld32(c.r[1]);  // 060759DE mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060759E0 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060759E2 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060759E4 mul.l r1,r2
    c.r[1] = c.macl;  // 060759E6 sts macl,r1
    c.r[0] = c.r[1];  // 060759E8 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060759EA mov.w @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06075A34u);  // 060759EC mov.w 0x06075A34,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060759EE extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 060759F0 cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] += 2; if (k) { goto L_06075A64; } }  // 060759F2 bf/s 0x06075A64 ; add #2,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06075A32u);  // 060759F6 mov.w 0x06075A32,r6
    c.r[1] = ld32(0x06075A50u);  // 060759F8 mov.l 0x06075A50,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060759FA mov.b @r5,r5
    c.r[4] = c.r[14];  // 060759FC mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06075A02u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075A02u) return; }  // 060759FE jsr @r1 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075A36u);  // 06075A02 mov.w 0x06075A36,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06075A04 mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 06075A06 mov r1,r0
    c.r[0] >>= 2;  // 06075A08 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06075A0A shlr r0
    c.r[0] &= 0x1u;  // 06075A0C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06075A0E tst r0,r0
    if (c.t) { goto L_06075A64; }  // 06075A10 bt 0x06075A64
    c.r[1] = ld32(0x06075A54u);  // 06075A12 mov.l 0x06075A54,r1
    c.r[7] = ld32(c.r[1]);  // 06075A14 mov.l @r1,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06075A38u);  // 06075A16 mov.w 0x06075A38,r6
    c.r[7] += 18;  // 06075A18 add #18,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06075A1A mov.w @r7,r3
    c.r[1] = 0x9u;  // 06075A1C mov #9,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06075A1E extu.w r3,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06075A20 shlr r2
    c.r[2] &= c.r[6];  // 06075A22 and r6,r2
    c.t = c.r[2] > c.r[1];  // 06075A24 cmp/hi r1,r2
    { const bool k = c.t; c.r[2] -= 10; if (k) { goto L_06075A58; } }  // 06075A26 bt/s 0x06075A58 ; add #-10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075A3Au);  // 06075A2A mov.w 0x06075A3A,r1
    c.r[1] &= c.r[3]; goto L_06075A62;  // 06075A2C bra 0x06075A62 ; and r3,r1
L_06075A58:
    c.r[2] &= c.r[6];  // 06075A58 and r6,r2
    c.r[2] += c.r[2];  // 06075A5A add r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075AF4u);  // 06075A5C mov.w 0x06075AF4,r1
    c.r[1] &= c.r[3];  // 06075A5E and r3,r1
    c.r[1] |= c.r[2];  // 06075A60 or r2,r1
L_06075A62:
    st16(c.r[7], c.r[1]);  // 06075A62 mov.w r1,@r7
L_06075A64:
    c.r[9] = ld32(0x06075AF8u);  // 06075A64 mov.l 0x06075AF8,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075A66 mov.b @r9,r1
    c.r[8] = ld32(0x06075AFCu);  // 06075A68 mov.l 0x06075AFC,r8
    c.r[2] = ld32(c.r[8]);  // 06075A6A mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075A6C extu.b r1,r1
    c.r[1] <<= 2;  // 06075A6E shll2 r1
    c.r[1] <<= 2;  // 06075A70 shll2 r1
    c.r[1] += c.r[2];  // 06075A72 add r2,r1
    c.r[1] += 2;  // 06075A74 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075A76 mov.b @r1,r2
    c.r[1] = ld32(0x06075B00u);  // 06075A78 mov.l 0x06075B00,r1
    c.r[3] = ld32(c.r[1]);  // 06075A7A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06075A7C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06075A7E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06075A80 mul.l r1,r2
    c.r[1] = c.macl;  // 06075A82 sts macl,r1
    c.r[0] = c.r[1];  // 06075A84 mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06075A86 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 06075A88 mov #0,r4
    c.r[0] = ld32(0x06075B04u);  // 06075A8A mov.l 0x06075B04,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075A90u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075A90u) return; }  // 06075A8C jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06075A90 mov r0,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06075A92 extu.w r1,r6
    c.r[1] = ld32(0x06075B08u);  // 06075A94 mov.l 0x06075B08,r1
    c.t = c.r[6] == c.r[1];  // 06075A96 cmp/eq r1,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06075AE2; } }  // 06075A98 bt/s 0x06075AE2 ; shll2 r6
    c.r[5] = ld32(0x06075B0Cu);  // 06075A9C mov.l 0x06075B0C,r5
    c.r[4] = ld32(c.r[5]);  // 06075A9E mov.l @r5,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075AA0 mov.b @r9,r1
    c.r[7] = ld32(0x06075B10u);  // 06075AA2 mov.l 0x06075B10,r7
    c.r[3] = ld32(c.r[8]);  // 06075AA4 mov.l @r8,r3
    c.r[4] += c.r[6];  // 06075AA6 add r6,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06075AA8 extu.b r1,r1
    c.r[1] <<= 2;  // 06075AAA shll2 r1
    c.r[1] <<= 2;  // 06075AAC shll2 r1
    c.r[2] = c.r[1];  // 06075AAE mov r1,r2
    c.r[2] += c.r[3];  // 06075AB0 add r3,r2
    c.r[2] += 1;  // 06075AB2 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075AB4 mov.b @r2,r2
    c.r[0] = c.r[1];  // 06075AB6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075AB8 mov.b @(r0,r3),r1
    c.r[2] = c.r[2] & 0xFFu;  // 06075ABA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075ABC extu.b r1,r1
    c.r[3] = ld32(c.r[7]);  // 06075ABE mov.l @r7,r3
    c.r[2] <<= 2;  // 06075AC0 shll2 r2
    c.r[2] <<= 2;  // 06075AC2 shll2 r2
    c.r[2] <<= 2;  // 06075AC4 shll2 r2
    c.r[2] += c.r[3];  // 06075AC6 add r3,r2
    c.r[0] = c.r[2];  // 06075AC8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075ACA mov.b @(r0,r1),r1
    c.r[4] += 20;  // 06075ACC add #20,r4
    st8(c.r[4], c.r[1]);  // 06075ACE mov.b r1,@r4
    c.r[1] = ld32(c.r[5]);  // 06075AD0 mov.l @r5,r1
    c.r[1] += c.r[6];  // 06075AD2 add r6,r1
    c.r[1] += 22;  // 06075AD4 add #22,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075AD6 mov.b @r1,r2
    c.r[0] = 0x3Fu;  // 06075AD8 mov #63,r0
    c.r[2] &= c.r[0];  // 06075ADA and r0,r2
    c.r[0] = 0x40u;  // 06075ADC mov #64,r0
    c.r[2] |= c.r[0];  // 06075ADE or r0,r2
    st8(c.r[1], c.r[2]);  // 06075AE0 mov.b r2,@r1
L_06075AE2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06075AF6u);  // 06075AE2 mov.w 0x06075AF6,r3
    c.r[14] += c.r[3];  // 06075AE4 add r3,r14
    c.r[15] = c.r[14];  // 06075AE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06075AE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06075AEA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06075AEC mov.l @r15+,r9
    c.r[0] = ld32(0x06075B14u);  // 06075AEE mov.l 0x06075B14,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075AF0 rts ; mov.l @r15+,r8
}

void f_06075B18(SH2Context& c) {
    ran[1628] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075B18 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 06075B1A extu.b r4,r4
    c.r[1] = ld32(0x06075B84u);  // 06075B1C mov.l 0x06075B84,r1
    c.r[1] = ld32(c.r[1]);  // 06075B1E mov.l @r1,r1
    c.r[4] <<= 2;  // 06075B20 shll2 r4
    c.r[4] <<= 2;  // 06075B22 shll2 r4
    c.r[4] += c.r[1];  // 06075B24 add r1,r4
    c.r[4] += 2;  // 06075B26 add #2,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06075B28 mov.b @r4,r2
    c.r[1] = ld32(0x06075B88u);  // 06075B2A mov.l 0x06075B88,r1
    c.r[3] = ld32(c.r[1]);  // 06075B2C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06075B2E extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06075B30 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06075B32 mul.l r1,r2
    c.r[1] = c.macl;  // 06075B34 sts macl,r1
    c.r[1] += c.r[3];  // 06075B36 add r3,r1
    c.r[1] += 15;  // 06075B38 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075B3A mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06075B3C extu.b r1,r7
    c.r[1] = ld32(0x06075B8Cu);  // 06075B3E mov.l 0x06075B8C,r1
    c.r[2] = c.r[7];  // 06075B40 mov r7,r2
    c.r[2] += c.r[2];  // 06075B42 add r2,r2
    c.r[2] += c.r[7];  // 06075B44 add r7,r2
    c.r[1] = ld32(c.r[1]);  // 06075B46 mov.l @r1,r1
    c.r[2] <<= 2;  // 06075B48 shll2 r2
    c.r[2] += c.r[1];  // 06075B4A add r1,r2
    c.r[2] += 9;  // 06075B4C add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075B4E mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06075B50 extu.b r1,r3
    c.r[3] -= 10;  // 06075B52 add #-10,r3
    c.r[1] = 0x31u;  // 06075B54 mov #49,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06075B56 cmp/gt r1,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06075B60; } }  // 06075B58 bt/s 0x06075B60 ; mov r15,r14
    c.r[3] = 0x32u; goto L_06075B68;  // 06075B5C bra 0x06075B68 ; mov #50,r3
L_06075B60:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075B80u);  // 06075B60 mov.w 0x06075B80,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06075B62 cmp/gt r1,r3
    if (!c.t) { goto L_06075B68; }  // 06075B64 bf 0x06075B68
    c.r[3] = c.r[1];  // 06075B66 mov r1,r3
L_06075B68:
    c.r[1] = ld32(0x06075B8Cu);  // 06075B68 mov.l 0x06075B8C,r1
    c.r[2] = c.r[7];  // 06075B6A mov r7,r2
    c.r[2] += c.r[2];  // 06075B6C add r2,r2
    c.r[2] += c.r[7];  // 06075B6E add r7,r2
    c.r[2] <<= 2;  // 06075B70 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06075B72 mov.l @r1,r1
    c.r[15] = c.r[14];  // 06075B74 mov r14,r15
    c.r[2] += c.r[1];  // 06075B76 add r1,r2
    c.r[2] += 9;  // 06075B78 add #9,r2
    st8(c.r[2], c.r[3]);  // 06075B7A mov.b r3,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075B7C rts ; mov.l @r15+,r14
}

void f_06075B90(SH2Context& c) {
    ran[1629] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06075B90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06075B92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075B94 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06075B96 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06075C98u);  // 06075B98 mov.w 0x06075C98,r3
    c.r[1] = ld32(0x06075C9Cu);  // 06075B9A mov.l 0x06075C9C,r1
    c.r[1] = ld32(c.r[1]);  // 06075B9C mov.l @r1,r1
    c.r[15] += c.r[3];  // 06075B9E add r3,r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075BA0 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06075BA2 extu.b r1,r2
    c.r[1] = 0x4u;  // 06075BA4 mov #4,r1
    c.r[2] -= 1;  // 06075BA6 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06075BA8 cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06075BB2; } }  // 06075BAA bf/s 0x06075BB2 ; mov r15,r14
    goto L_06075CB4;  // 06075BAE bra 0x06075CB4 ; nop
L_06075BB2:
    c.r[1] = c.r[2];  // 06075BB2 mov r2,r1
    c.r[1] += c.r[1];  // 06075BB4 add r1,r1
    c.r[0] = 0x06075BC0u;  // 06075BB6 mova 0x06075BC0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06075BB8 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06075BBA add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06075BCAu: goto L_06075BCA; case 0x06075BE4u: goto L_06075BE4; case 0x06075C1Au: goto L_06075C1A; case 0x06075C92u: goto L_06075C92; case 0x06075BEAu: goto L_06075BEA; default: sh2_call(c, x); return; } }  // 06075BBC jmp @r0 ; nop
L_06075BCA:
    c.r[1] = ld32(0x06075CA0u);  // 06075BCA mov.l 0x06075CA0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075BCC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06075BCE extu.b r2,r2
    c.r[1] = ld32(0x06075CA4u);  // 06075BD0 mov.l 0x06075CA4,r1
    c.r[1] = ld32(c.r[1]);  // 06075BD2 mov.l @r1,r1
    c.r[2] <<= 2;  // 06075BD4 shll2 r2
    c.r[2] <<= 2;  // 06075BD6 shll2 r2
    c.r[2] += c.r[1];  // 06075BD8 add r1,r2
    c.r[2] += 3;  // 06075BDA add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075BDC mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06075BDE or #128,r0
    st8(c.r[2], c.r[0]); goto L_06075DD8;  // 06075BE0 bra 0x06075DD8 ; mov.b r0,@r2
L_06075BE4:
    c.r[2] = ld32(0x06075CA8u);  // 06075BE4 mov.l 0x06075CA8,r2
    c.r[1] = 0x0u;  // 06075BE6 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06075BE8 mov.b r1,@r2
L_06075BEA:
    c.r[1] = ld32(0x06075CACu);  // 06075BEA mov.l 0x06075CAC,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075BEC mov.b @r1,r6
    c.r[5] = ld32(0x06075CB0u);  // 06075BEE mov.l 0x06075CB0,r5
    c.r[7] = c.r[6] & 0xFFu;  // 06075BF0 extu.b r6,r7
    c.r[1] = ld32(0x06075CA4u);  // 06075BF2 mov.l 0x06075CA4,r1
    c.r[3] = ld32(c.r[1]);  // 06075BF4 mov.l @r1,r3
    c.r[7] <<= 2;  // 06075BF6 shll2 r7
    c.r[7] <<= 2;  // 06075BF8 shll2 r7
    c.r[1] = c.r[7];  // 06075BFA mov r7,r1
    c.r[1] += c.r[3];  // 06075BFC add r3,r1
    c.r[1] += 1;  // 06075BFE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075C00 mov.b @r1,r2
    c.r[0] = c.r[7];  // 06075C02 mov r7,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06075C04 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075C06 mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06075C08 shll2 r2
    c.r[2] <<= 2;  // 06075C0A shll2 r2
    c.r[2] <<= 2;  // 06075C0C shll2 r2
    c.r[3] = ld32(c.r[5]);  // 06075C0E mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06075C10 extu.b r1,r1
    c.r[2] += c.r[3];  // 06075C12 add r3,r2
    c.r[0] = c.r[2];  // 06075C14 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]); goto L_06075DD8;  // 06075C16 bra 0x06075DD8 ; mov.b r6,@(r0,r1)
L_06075C1A:
    c.r[4] = ld32(0x06075CACu);  // 06075C1A mov.l 0x06075CAC,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06075C1C mov.b @r4,r5
    c.r[6] = ld32(0x06075CA4u);  // 06075C1E mov.l 0x06075CA4,r6
    c.r[3] = ld32(c.r[6]);  // 06075C20 mov.l @r6,r3
    c.r[7] = c.r[5] & 0xFFu;  // 06075C22 extu.b r5,r7
    c.r[7] <<= 2;  // 06075C24 shll2 r7
    c.r[7] <<= 2;  // 06075C26 shll2 r7
    c.r[1] = c.r[7];  // 06075C28 mov r7,r1
    c.r[1] += c.r[3];  // 06075C2A add r3,r1
    c.r[1] += 1;  // 06075C2C add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075C2E mov.b @r1,r2
    c.r[0] = c.r[7];  // 06075C30 mov r7,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06075C32 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075C34 mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06075C36 shll2 r2
    c.r[2] <<= 2;  // 06075C38 shll2 r2
    c.r[2] <<= 2;  // 06075C3A shll2 r2
    c.r[0] = ld32(0x06075CB0u);  // 06075C3C mov.l 0x06075CB0,r0
    c.r[3] = ld32(c.r[0]);  // 06075C3E mov.l @r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06075C40 extu.b r1,r1
    c.r[2] += c.r[3];  // 06075C42 add r3,r2
    c.r[0] = c.r[2];  // 06075C44 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[5]);  // 06075C46 mov.b r5,@(r0,r1)
    c.r[3] = ld32(0x06075CA0u);  // 06075C48 mov.l 0x06075CA0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075C4A mov.b @r3,r1
    c.r[2] = ld32(c.r[6]);  // 06075C4C mov.l @r6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075C4E extu.b r1,r1
    c.r[1] <<= 2;  // 06075C50 shll2 r1
    c.r[1] <<= 2;  // 06075C52 shll2 r1
    c.r[1] += c.r[2];  // 06075C54 add r2,r1
    c.r[1] += 3;  // 06075C56 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075C58 mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 06075C5A mov #127,r0
    c.r[2] &= c.r[0];  // 06075C5C and r0,r2
    st8(c.r[1], c.r[2]);  // 06075C5E mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075C60 mov.b @r3,r1
    c.r[2] = ld32(c.r[6]);  // 06075C62 mov.l @r6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075C64 extu.b r1,r1
    c.r[1] <<= 2;  // 06075C66 shll2 r1
    c.r[1] <<= 2;  // 06075C68 shll2 r1
    c.r[1] += c.r[2];  // 06075C6A add r2,r1
    c.r[1] += 4;  // 06075C6C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075C6E mov.b @r1,r2
    c.r[0] = 0x40u;  // 06075C70 mov #64,r0
    c.r[2] |= c.r[0];  // 06075C72 or r0,r2
    st8(c.r[1], c.r[2]);  // 06075C74 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075C76 mov.b @r3,r2
    c.r[1] = ld32(c.r[6]);  // 06075C78 mov.l @r6,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06075C7A extu.b r2,r2
    c.r[2] <<= 2;  // 06075C7C shll2 r2
    c.r[2] <<= 2;  // 06075C7E shll2 r2
    c.r[2] += c.r[1];  // 06075C80 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06075C82 mov.b @r4,r1
    c.r[2] += 5;  // 06075C84 add #5,r2
    st8(c.r[2], c.r[1]);  // 06075C86 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06075C88 mov.b @r4,r1
    c.r[2] = ld32(0x06075CA8u);  // 06075C8A mov.l 0x06075CA8,r2
    st8(c.r[3], c.r[1]);  // 06075C8C mov.b r1,@r3
    c.r[1] = 0x0u; goto L_06075DD6;  // 06075C8E bra 0x06075DD6 ; mov #0,r1
L_06075C92:
    c.r[2] = ld32(0x06075CA8u);  // 06075C92 mov.l 0x06075CA8,r2
    c.r[1] = 0x0u; goto L_06075DD6;  // 06075C94 bra 0x06075DD6 ; mov #0,r1
L_06075CB4:
    c.r[6] = ld32(0x06075DF4u);  // 06075CB4 mov.l 0x06075DF4,r6
    c.r[9] = ld32(0x06075DF8u);  // 06075CB6 mov.l 0x06075DF8,r9
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075CB8 mov.b @r9,r7
    c.r[1] = ld32(0x06075DFCu);  // 06075CBA mov.l 0x06075DFC,r1
    st8(c.r[6], c.r[7]);  // 06075CBC mov.b r7,@r6
    c.r[3] = ld32(c.r[1]);  // 06075CBE mov.l @r1,r3
    c.r[1] = ld32(0x06075E00u);  // 06075CC0 mov.l 0x06075E00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075CC2 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06075CC4 extu.b r1,r5
    c.r[1] = ld32(0x06075E04u);  // 06075CC6 mov.l 0x06075E04,r1
    c.r[0] = c.r[5];  // 06075CC8 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075CCA mov.b @(r0,r1),r1
    c.r[2] = 0xBu;  // 06075CCC mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075CCE extu.b r1,r1
    c.r[1] -= 1;  // 06075CD0 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06075CD2 mul.l r2,r1
    c.r[1] = ld32(0x06075E08u);  // 06075CD4 mov.l 0x06075E08,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075CD6 mov.b @(r0,r1),r1
    c.r[8] = ld32(0x06075E0Cu);  // 06075CD8 mov.l 0x06075E0C,r8
    c.r[5] = c.r[1] & 0xFFu;  // 06075CDA extu.b r1,r5
    c.r[1] = ld32(0x06075E10u);  // 06075CDC mov.l 0x06075E10,r1
    c.r[0] = c.r[5];  // 06075CDE mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075CE0 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06075CE2 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075CE4 extu.b r1,r1
    c.r[2] += c.r[1];  // 06075CE6 add r1,r2
    c.r[2] += c.r[2];  // 06075CE8 add r2,r2
    c.r[3] += c.r[2];  // 06075CEA add r2,r3
    c.r[3] += 1;  // 06075CEC add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06075CEE mov.b @r3,r2
    c.r[7] = c.r[7] & 0xFFu;  // 06075CF0 extu.b r7,r7
    st8(c.r[9], c.r[2]);  // 06075CF2 mov.b r2,@r9
    c.r[2] = c.r[2] & 0xFFu;  // 06075CF4 extu.b r2,r2
    c.r[2] <<= 2;  // 06075CF6 shll2 r2
    c.r[2] <<= 2;  // 06075CF8 shll2 r2
    c.r[7] <<= 2;  // 06075CFA shll2 r7
    c.r[7] <<= 2;  // 06075CFC shll2 r7
    c.r[3] = ld32(c.r[8]);  // 06075CFE mov.l @r8,r3
    c.r[0] = c.r[7];  // 06075D00 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075D02 mov.b @(r0,r3),r1
    c.r[0] = c.r[2];  // 06075D04 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06075D06 mov.b r1,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075D08 mov.b @r9,r2
    c.r[3] = ld32(c.r[8]);  // 06075D0A mov.l @r8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06075D0C mov.b @r6,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06075D0E extu.b r2,r2
    c.r[2] <<= 2;  // 06075D10 shll2 r2
    c.r[2] <<= 2;  // 06075D12 shll2 r2
    c.r[2] += c.r[3];  // 06075D14 add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075D16 extu.b r1,r1
    c.r[1] <<= 2;  // 06075D18 shll2 r1
    c.r[1] <<= 2;  // 06075D1A shll2 r1
    c.r[1] += c.r[3];  // 06075D1C add r3,r1
    c.r[1] += 1;  // 06075D1E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075D20 mov.b @r1,r1
    c.r[2] += 1;  // 06075D22 add #1,r2
    st8(c.r[2], c.r[1]);  // 06075D24 mov.b r1,@r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075D26 mov.b @r9,r6
    c.r[5] = ld32(0x06075E14u);  // 06075D28 mov.l 0x06075E14,r5
    c.r[3] = ld32(c.r[8]);  // 06075D2A mov.l @r8,r3
    c.r[7] = c.r[6] & 0xFFu;  // 06075D2C extu.b r6,r7
    c.r[7] <<= 2;  // 06075D2E shll2 r7
    c.r[7] <<= 2;  // 06075D30 shll2 r7
    c.r[1] = c.r[7];  // 06075D32 mov r7,r1
    c.r[1] += c.r[3];  // 06075D34 add r3,r1
    c.r[1] += 1;  // 06075D36 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075D38 mov.b @r1,r2
    c.r[0] = c.r[7];  // 06075D3A mov r7,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06075D3C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075D3E mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06075D40 shll2 r2
    c.r[2] <<= 2;  // 06075D42 shll2 r2
    c.r[2] <<= 2;  // 06075D44 shll2 r2
    c.r[3] = ld32(c.r[5]);  // 06075D46 mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06075D48 extu.b r1,r1
    c.r[2] += c.r[3];  // 06075D4A add r3,r2
    c.r[0] = c.r[2];  // 06075D4C mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06075D4E mov.b r6,@(r0,r1)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075D50 mov.b @r9,r1
    c.r[2] = ld32(c.r[8]);  // 06075D52 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075D54 extu.b r1,r1
    c.r[1] <<= 2;  // 06075D56 shll2 r1
    c.r[1] <<= 2;  // 06075D58 shll2 r1
    c.r[1] += c.r[2];  // 06075D5A add r2,r1
    c.r[1] += 4;  // 06075D5C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075D5E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075DEAu);  // 06075D60 mov.w 0x06075DEA,r0
    c.r[2] &= c.r[0];  // 06075D62 and r0,r2
    st8(c.r[1], c.r[2]);  // 06075D64 mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075D66 mov.b @r9,r1
    c.r[4] = c.r[14];  // 06075D68 mov r14,r4
    c.r[2] = ld32(c.r[8]);  // 06075D6A mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075D6C extu.b r1,r1
    c.r[1] <<= 2;  // 06075D6E shll2 r1
    c.r[1] <<= 2;  // 06075D70 shll2 r1
    c.r[1] += c.r[2];  // 06075D72 add r2,r1
    c.r[1] += 2;  // 06075D74 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075D76 mov.b @r1,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06075DECu);  // 06075D78 mov.w 0x06075DEC,r6
    c.r[1] = ld32(0x06075E18u);  // 06075D7A mov.l 0x06075E18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075D80u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075D80u) return; }  // 06075D7C jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 06075D80 mov r14,r1
    c.r[1] += 37;  // 06075D82 add #37,r1
    c.r[0] = 0x10u;  // 06075D84 mov #16,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075D86 mov.b @r1,r1
    c.r[7] = 0xFFFFFFFFu;  // 06075D88 mov #-1,r7
    c.r[3] = ld32(c.r[8]);  // 06075D8A mov.l @r8,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06075D8C extu.b r1,r6
    c.r[6] >>= 2;  // 06075D8E shlr2 r6
    c.r[6] >>= 2;  // 06075D90 shlr2 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075D92 mov.b @r9,r1
    c.r[6] |= c.r[0];  // 06075D94 or r0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06075D96 extu.b r1,r1
    c.r[1] <<= 2;  // 06075D98 shll2 r1
    c.r[1] <<= 2;  // 06075D9A shll2 r1
    c.r[2] = c.r[1];  // 06075D9C mov r1,r2
    c.r[2] += c.r[3];  // 06075D9E add r3,r2
    c.r[2] += 1;  // 06075DA0 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075DA2 mov.b @r2,r5
    c.r[0] = c.r[1];  // 06075DA4 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06075DA6 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06075DA8 extu.b r5,r5
    c.r[0] = ld32(0x06075E1Cu);  // 06075DAA mov.l 0x06075E1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075DB0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075DB0u) return; }  // 06075DAC jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06075DB0 mov r0,r1
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06075DB2 exts.b r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06075DB4 cmp/pz r3
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06075DD8; } }  // 06075DB6 bf/s 0x06075DD8 ; mov #3,r0
    c.r[3] &= c.r[0];  // 06075DBA and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06075DBC mov.b @r9,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075DEEu);  // 06075DBE mov.w 0x06075DEE,r0
    c.r[1] = ld32(c.r[8]);  // 06075DC0 mov.l @r8,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06075DC2 extu.b r2,r2
    c.r[2] <<= 2;  // 06075DC4 shll2 r2
    c.r[2] <<= 2;  // 06075DC6 shll2 r2
    c.r[2] += c.r[1];  // 06075DC8 add r1,r2
    c.r[2] += 3;  // 06075DCA add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075DCC mov.b @r2,r1
    c.r[3] <<= 2;  // 06075DCE shll2 r3
    c.r[3] += c.r[3];  // 06075DD0 add r3,r3
    c.r[1] &= c.r[0];  // 06075DD2 and r0,r1
    c.r[1] |= c.r[3];  // 06075DD4 or r3,r1
L_06075DD6:
    st8(c.r[2], c.r[1]);  // 06075DD6 mov.b r1,@r2
L_06075DD8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06075DF0u);  // 06075DD8 mov.w 0x06075DF0,r3
    c.r[14] += c.r[3];  // 06075DDA add r3,r14
    c.r[15] = c.r[14];  // 06075DDC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06075DDE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06075DE0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06075DE2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075DF2u);  // 06075DE4 mov.w 0x06075DF2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06075DE6 rts ; mov.l @r15+,r8
}

void f_06075E20(SH2Context& c) {
    ran[1630] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075E20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06075E22 sts.l pr,@-r15
    c.r[1] = ld32(0x06075E40u);  // 06075E24 mov.l 0x06075E40,r1
    c.r[1] = ld32(c.r[1]);  // 06075E26 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075E28 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06075E2A extu.b r1,r0
    c.r[0] <<= 2;  // 06075E2C shll2 r0
    c.r[1] = ld32(0x06075E44u);  // 06075E2E mov.l 0x06075E44,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06075E30 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075E36u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075E36u) return; }  // 06075E32 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06075E36 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06075E38 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06075E3A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06075E3C rts ; extu.w r0,r0
}

void f_06075E48(SH2Context& c) {
    ran[1631] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06075E48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06075E4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06075E4C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06075E4E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06075E50 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06075E52 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06075E54 sts.l pr,@-r15
    c.r[1] = ld32(0x06075FA4u);  // 06075E56 mov.l 0x06075FA4,r1
    c.r[1] = ld32(c.r[1]);  // 06075E58 mov.l @r1,r1
    c.r[15] -= 48;  // 06075E5A add #-48,r15
    c.r[1] += 1;  // 06075E5C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075E5E mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06075E60 extu.b r1,r2
    c.r[0] = c.r[2];  // 06075E62 mov r2,r0
    c.t = c.r[0] == 0x1u;  // 06075E64 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06075F3A; } }  // 06075E66 bt/s 0x06075F3A ; mov r15,r14
    c.r[1] = 0x1u;  // 06075E6A mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06075E6C cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06075E7E; } }  // 06075E6E bt/s 0x06075E7E ; cmp/eq #3,r0
    c.t = (c.r[2] & c.r[2]) == 0;  // 06075E72 tst r2,r2
    if (c.t) { goto L_06075E7A; }  // 06075E74 bt 0x06075E7A
    goto L_0607608A;  // 06075E76 bra 0x0607608A ; nop
L_06075E7A:
    goto L_06075E88;  // 06075E7A bra 0x06075E88 ; nop
L_06075E7E:
    if (c.t) { goto L_06075E84; }  // 06075E7E bt 0x06075E84
    goto L_0607608A;  // 06075E80 bra 0x0607608A ; nop
L_06075E84:
    goto L_06075F60;  // 06075E84 bra 0x06075F60 ; nop
L_06075E88:
    c.r[1] = ld32(0x06075FA8u);  // 06075E88 mov.l 0x06075FA8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075E8A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075E8C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06075E8E tst r1,r1
    if (c.t) { goto L_06075EAA; }  // 06075E90 bt 0x06075EAA
    c.r[1] = ld32(0x06075FACu);  // 06075E92 mov.l 0x06075FAC,r1
    c.r[2] = ld32(c.r[1]);  // 06075E94 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075F9Cu);  // 06075E96 mov.w 0x06075F9C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075F9Eu);  // 06075E98 mov.w 0x06075F9E,r1
    c.r[2] += c.r[1];  // 06075E9A add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06075E9C mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075E9E extu.b r1,r1
    c.r[1] <<= 2;  // 06075EA0 shll2 r1
    c.r[1] += c.r[1];  // 06075EA2 add r1,r1
    c.r[2] += c.r[1];  // 06075EA4 add r1,r2
    c.r[2] += 4; goto L_06075EBA;  // 06075EA6 bra 0x06075EBA ; add #4,r2
L_06075EAA:
    c.r[1] = ld32(0x06075FB0u);  // 06075EAA mov.l 0x06075FB0,r1
    c.r[2] = ld32(c.r[1]);  // 06075EAC mov.l @r1,r2
    c.r[1] = ld32(0x06075FB4u);  // 06075EAE mov.l 0x06075FB4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075EB0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075EB2 extu.b r1,r1
    c.r[1] += c.r[1];  // 06075EB4 add r1,r1
    c.r[2] += c.r[1];  // 06075EB6 add r1,r2
    c.r[2] += 1;  // 06075EB8 add #1,r2
L_06075EBA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075EBA mov.b @r2,r1
    c.r[0] = ld32(0x06075FB8u);  // 06075EBC mov.l 0x06075FB8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075EC2u; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075EC2u) return; }  // 06075EBE jsr @r0 ; extu.b r1,r4
    c.r[1] = c.r[0];  // 06075EC2 mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06075EC4 extu.b r1,r11
    c.r[2] = ld32(0x06075FBCu);  // 06075EC6 mov.l 0x06075FBC,r2
    c.r[1] = c.r[2];  // 06075EC8 mov r2,r1
    c.r[1] += 117;  // 06075ECA add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075ECC mov.b @r1,r3
    c.r[6] = ld32(0x06075FC0u);  // 06075ECE mov.l 0x06075FC0,r6
    c.r[1] = c.r[2];  // 06075ED0 mov r2,r1
    c.r[1] += 79;  // 06075ED2 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075ED4 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06075ED6 extu.b r3,r3
    c.r[3] += c.r[1];  // 06075ED8 add r1,r3
    c.r[1] = c.r[2];  // 06075EDA mov r2,r1
    c.r[1] += 116;  // 06075EDC add #116,r1
    c.r[2] += 78;  // 06075EDE add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075EE0 mov.b @r1,r1
    c.r[3] <<= 2;  // 06075EE2 shll2 r3
    c.r[3] <<= 2;  // 06075EE4 shll2 r3
    c.r[3] <<= 2;  // 06075EE6 shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075EE8 mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06075EEA extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 06075EEC mov.l @r6,r2
    c.r[1] += c.r[7];  // 06075EEE add r7,r1
    c.r[3] += c.r[2];  // 06075EF0 add r2,r3
    c.r[0] = c.r[3];  // 06075EF2 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075EF4 mov.b @(r0,r1),r1
    c.r[10] = c.r[1] & 0xFFu;  // 06075EF6 extu.b r1,r10
    c.r[1] = ld32(0x06075FB0u);  // 06075EF8 mov.l 0x06075FB0,r1
    c.r[2] = ld32(c.r[1]);  // 06075EFA mov.l @r1,r2
    c.r[1] = ld32(0x06075FB4u);  // 06075EFC mov.l 0x06075FB4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075EFE mov.b @r1,r1
    c.r[4] = c.r[14];  // 06075F00 mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06075F02 extu.b r1,r1
    c.r[1] += c.r[1];  // 06075F04 add r1,r1
    c.r[2] += c.r[1];  // 06075F06 add r1,r2
    c.r[2] += 1;  // 06075F08 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075F0A mov.b @r2,r5
    c.r[1] = ld32(0x06075FC4u);  // 06075F0C mov.l 0x06075FC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06075F12u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075F12u) return; }  // 06075F0E jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06075FC8u);  // 06075F12 mov.l 0x06075FC8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075F14 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06075F16 extu.b r1,r2
    c.r[1] = ld32(0x06075FCCu);  // 06075F18 mov.l 0x06075FCC,r1
    c.r[0] = c.r[2];  // 06075F1A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075F1C mov.b @(r0,r1),r1
    c.r[7] = 0x1u;  // 06075F1E mov #1,r7
    c.r[2] = c.r[1] & 0xFFu;  // 06075F20 extu.b r1,r2
    c.r[1] = c.r[14];  // 06075F22 mov r14,r1
    c.r[1] += 24;  // 06075F24 add #24,r1
    c.r[0] = c.r[1];  // 06075F26 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06075F28 mov.b @(r0,r2),r1
    c.r[5] = c.r[10];  // 06075F2A mov r10,r5
    c.r[4] = c.r[1] & 0xFFu;  // 06075F2C extu.b r1,r4
    c.r[6] = c.r[4];  // 06075F2E mov r4,r6
    c.r[0] = ld32(0x06075FD0u);  // 06075F30 mov.l 0x06075FD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075F36u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075F36u) return; }  // 06075F32 jsr @r0 ; mov r11,r4
    c.r[14] += 48; goto L_060760D8;  // 06075F36 bra 0x060760D8 ; add #48,r14
L_06075F3A:
    c.r[1] = ld32(0x06075FACu);  // 06075F3A mov.l 0x06075FAC,r1
    c.r[0] = ld32(c.r[1]);  // 06075F3C mov.l @r1,r0
    c.r[2] = ld32(0x06075FD4u);  // 06075F3E mov.l 0x06075FD4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075FA0u);  // 06075F40 mov.w 0x06075FA0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075F42 mov.b @(r0,r1),r1
    c.r[7] = 0x2u;  // 06075F44 mov #2,r7
    c.r[11] = c.r[1] & 0xFFu;  // 06075F46 extu.b r1,r11
    c.r[1] = c.r[2];  // 06075F48 mov r2,r1
    c.r[1] += 5;  // 06075F4A add #5,r1
    c.r[2] += 7;  // 06075F4C add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075F4E mov.b @r1,r1
    c.r[0] = ld32(0x06075FD0u);  // 06075F50 mov.l 0x06075FD0,r0
    c.r[10] = c.r[1] & 0xFFu;  // 06075F52 extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075F54 mov.b @r2,r1
    c.r[5] = c.r[10];  // 06075F56 mov r10,r5
    c.r[1] -= 16;  // 06075F58 add #-16,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06075F5A extu.b r1,r4
    c.r[6] = c.r[4]; goto L_06076082;  // 06075F5C bra 0x06076082 ; mov r4,r6
L_06075F60:
    c.r[1] = ld32(0x06075FACu);  // 06075F60 mov.l 0x06075FAC,r1
    c.r[3] = ld32(c.r[1]);  // 06075F62 mov.l @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06075FA2u);  // 06075F64 mov.w 0x06075FA2,r2
    c.r[1] = ld32(0x06075FB4u);  // 06075F66 mov.l 0x06075FB4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075F68 mov.b @r1,r1
    c.r[2] += c.r[3];  // 06075F6A add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075F6C extu.b r1,r1
    c.r[1] <<= 2;  // 06075F6E shll2 r1
    c.r[1] += c.r[1];  // 06075F70 add r1,r1
    c.r[2] += c.r[1];  // 06075F72 add r1,r2
    c.r[2] += 4;  // 06075F74 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06075F76 mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06075F78 extu.b r1,r9
    c.r[1] = ld32(0x06075FA8u);  // 06075F7A mov.l 0x06075FA8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075F7C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06075F7E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06075F80 tst r1,r1
    if (c.t) { goto L_06075FD8; }  // 06075F82 bt 0x06075FD8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06075F9Eu);  // 06075F84 mov.w 0x06075F9E,r1
    c.r[1] += c.r[3];  // 06075F86 add r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06075F9Cu);  // 06075F88 mov.w 0x06075F9C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075F8A mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06075F8C extu.b r2,r2
    c.r[2] <<= 2;  // 06075F8E shll2 r2
    c.r[2] += c.r[2];  // 06075F90 add r2,r2
    c.r[1] += c.r[2];  // 06075F92 add r2,r1
    c.r[1] += 4;  // 06075F94 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075F96 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu; goto L_06075FDA;  // 06075F98 bra 0x06075FDA ; extu.b r1,r4
L_06075FD8:
    c.r[4] = c.r[9] & 0xFFu;  // 06075FD8 extu.b r9,r4
L_06075FDA:
    c.r[0] = ld32(0x060760F8u);  // 06075FDA mov.l 0x060760F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06075FE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06075FE0u) return; }  // 06075FDC jsr @r0 ; nop
    c.r[1] = c.r[0];  // 06075FE0 mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06075FE2 extu.b r1,r11
    c.r[1] = ld32(0x060760FCu);  // 06075FE4 mov.l 0x060760FC,r1
    c.r[3] = ld32(c.r[1]);  // 06075FE6 mov.l @r1,r3
    c.r[1] = ld32(0x06076100u);  // 06075FE8 mov.l 0x06076100,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06075FEA mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06075FEC extu.b r1,r7
    c.r[1] = ld32(0x06076104u);  // 06075FEE mov.l 0x06076104,r1
    c.r[0] = c.r[7];  // 06075FF0 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06075FF2 mov.b @(r0,r1),r1
    c.r[2] = 0xBu;  // 06075FF4 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06075FF6 extu.b r1,r1
    c.r[1] -= 1;  // 06075FF8 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06075FFA mul.l r2,r1
    c.r[8] = ld32(0x06076108u);  // 06075FFC mov.l 0x06076108,r8
    c.r[5] = c.r[9] & 0xFFu;  // 06075FFE extu.b r9,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06076000 mov.b @(r0,r8),r1
    c.r[2] = c.macl;  // 06076002 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06076004 extu.b r1,r1
    c.r[2] += c.r[1];  // 06076006 add r1,r2
    c.r[2] += c.r[2];  // 06076008 add r2,r2
    c.r[3] += c.r[2];  // 0607600A add r2,r3
    c.r[3] += 1;  // 0607600C add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607600E mov.b @r3,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06076010 extu.b r1,r10
    c.r[1] = ld32(0x0607610Cu);  // 06076012 mov.l 0x0607610C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06076018u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076018u) return; }  // 06076014 jsr @r1 ; mov r14,r4
    c.r[8] += 23;  // 06076018 add #23,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607601A mov.b @r8,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607601C extu.b r1,r2
    c.r[1] = c.r[14];  // 0607601E mov r14,r1
    c.r[1] += 24;  // 06076020 add #24,r1
    c.r[0] = c.r[1];  // 06076022 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06076024 mov.b @(r0,r2),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060760ECu);  // 06076026 mov.w 0x060760EC,r3
    c.r[4] = c.r[1] & 0xFFu;  // 06076028 extu.b r1,r4
    c.r[2] = ld32(0x06076110u);  // 0607602A mov.l 0x06076110,r2
    c.r[1] = ld32(c.r[2]);  // 0607602C mov.l @r2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060760EEu);  // 0607602E mov.w 0x060760EE,r6
    c.r[1] += c.r[3];  // 06076030 add r3,r1
    c.r[0] = c.r[1];  // 06076032 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06076034 mov.b @(r0,r6),r1
    c.r[9] = 0x0u;  // 06076036 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06076038 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0607603A cmp/ge r1,r9
    { const bool k = c.t; c.r[8] = c.r[2]; if (k) { goto L_0607607A; } }  // 0607603C bt/s 0x0607607A ; mov r2,r8
    c.r[5] = c.r[3];  // 06076040 mov r3,r5
    c.r[7] = 0x0u;  // 06076042 mov #0,r7
L_06076044:
    c.r[1] = ld32(0x060760FCu);  // 06076044 mov.l 0x060760FC,r1
    c.r[3] = c.r[9];  // 06076046 mov r9,r3
    c.r[2] = ld32(c.r[8]);  // 06076048 mov.l @r8,r2
    c.r[3] += c.r[3];  // 0607604A add r3,r3
    c.r[1] = ld32(c.r[1]);  // 0607604C mov.l @r1,r1
    c.r[2] += c.r[5];  // 0607604E add r5,r2
    c.r[2] += c.r[7];  // 06076050 add r7,r2
    c.r[0] = c.r[1];  // 06076052 mov r1,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06076054 mov.b @(r0,r3),r12
    c.r[2] += 4;  // 06076056 add #4,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076058 mov.b @r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060760F0u);  // 0607605A mov.w 0x060760F0,r0
    c.r[12] &= c.r[0];  // 0607605C and r0,r12
    c.r[0] = c.r[1];  // 0607605E mov r1,r0
    st8(c.r[0] + c.r[3], c.r[12]);  // 06076060 mov.b r12,@(r0,r3)
    c.r[1] += c.r[3];  // 06076062 add r3,r1
    c.r[1] += 1;  // 06076064 add #1,r1
    st8(c.r[1], c.r[2]);  // 06076066 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06076068 mov.l @r8,r1
    c.r[9] += 1;  // 0607606A add #1,r9
    c.r[1] += c.r[5];  // 0607606C add r5,r1
    c.r[0] = c.r[1];  // 0607606E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06076070 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06076072 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06076074 cmp/ge r1,r9
    { const bool k = !c.t; c.r[7] += 8; if (k) { SH2_POLL(c); goto L_06076044; } }  // 06076076 bf/s 0x06076044 ; add #8,r7
L_0607607A:
    c.r[0] = ld32(0x06076114u);  // 0607607A mov.l 0x06076114,r0
    c.r[7] = 0x1u;  // 0607607C mov #1,r7
    c.r[6] = c.r[4];  // 0607607E mov r4,r6
    c.r[5] = c.r[10];  // 06076080 mov r10,r5
L_06076082:
    { const uint32_t x = c.r[0]; c.pr = 0x06076086u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076086u) return; }  // 06076082 jsr @r0 ; mov r11,r4
    c.r[14] += 48; goto L_060760D8;  // 06076086 bra 0x060760D8 ; add #48,r14
L_0607608A:
    c.r[1] = ld32(0x06076118u);  // 0607608A mov.l 0x06076118,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607608C mov.w @r1,r1
    c.r[9] = 0x1u;  // 0607608E mov #1,r9
    c.r[1] = c.r[1] & 0xFFFFu;  // 06076090 extu.w r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06076092 cmp/gt r1,r9
    { const bool k = c.t; c.r[8] = 0x8u; if (k) { goto L_060760D6; } }  // 06076094 bt/s 0x060760D6 ; mov #8,r8
    c.r[12] = ld32(0x06076114u);  // 06076098 mov.l 0x06076114,r12
L_0607609A:
    c.r[1] = ld32(0x06076110u);  // 0607609A mov.l 0x06076110,r1
    c.r[2] = ld32(c.r[1]);  // 0607609C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060760F2u);  // 0607609E mov.w 0x060760F2,r1
    c.r[2] += c.r[1];  // 060760A0 add r1,r2
    c.r[2] += c.r[8];  // 060760A2 add r8,r2
    c.r[2] += 4;  // 060760A4 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060760A6 mov.b @r2,r1
    c.r[7] = 0x2u;  // 060760A8 mov #2,r7
    c.r[11] = c.r[1] & 0xFFu;  // 060760AA extu.b r1,r11
    c.r[2] = ld32(0x0607611Cu);  // 060760AC mov.l 0x0607611C,r2
    c.r[2] += c.r[8];  // 060760AE add r8,r2
    c.r[1] = c.r[2];  // 060760B0 mov r2,r1
    c.r[1] += 5;  // 060760B2 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060760B4 mov.b @r1,r1
    c.r[2] += 7;  // 060760B6 add #7,r2
    c.r[10] = c.r[1] & 0xFFu;  // 060760B8 extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060760BA mov.b @r2,r1
    c.r[5] = c.r[10];  // 060760BC mov r10,r5
    c.r[1] -= 16;  // 060760BE add #-16,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060760C0 extu.b r1,r4
    c.r[6] = c.r[4];  // 060760C2 mov r4,r6
    { const uint32_t x = c.r[12]; c.pr = 0x060760C8u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060760C8u) return; }  // 060760C4 jsr @r12 ; mov r11,r4
    c.r[1] = ld32(0x06076118u);  // 060760C8 mov.l 0x06076118,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060760CA mov.w @r1,r1
    c.r[9] += 1;  // 060760CC add #1,r9
    c.r[1] = c.r[1] & 0xFFFFu;  // 060760CE extu.w r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060760D0 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 8; if (k) { SH2_POLL(c); goto L_0607609A; } }  // 060760D2 bf/s 0x0607609A ; add #8,r8
L_060760D6:
    c.r[14] += 48;  // 060760D6 add #48,r14
L_060760D8:
    c.r[15] = c.r[14];  // 060760D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060760DA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060760DC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060760DE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060760E0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060760E2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060760E4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060760F4u);  // 060760E6 mov.w 0x060760F4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060760E8 rts ; mov.l @r15+,r8
}

void f_06076120(SH2Context& c) {
    ran[1632] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076120 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076122 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06076124 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076126 mov.l r14,@-r15
    c.r[1] = ld32(0x06076220u);  // 06076128 mov.l 0x06076220,r1
    c.r[1] = ld32(c.r[1]);  // 0607612A mov.l @r1,r1
    c.r[1] += 1;  // 0607612C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607612E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06076130 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076132 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060761A6; } }  // 06076134 bt/s 0x060761A6 ; mov r15,r14
    c.r[3] = ld32(0x06076224u);  // 06076138 mov.l 0x06076224,r3
    c.r[1] = ld32(0x06076228u);  // 0607613A mov.l 0x06076228,r1
    c.r[7] = 0x0u;  // 0607613C mov #0,r7
    c.r[9] = 0x49u;  // 0607613E mov #73,r9
    c.r[8] = ld32(0x0607622Cu);  // 06076140 mov.l 0x0607622C,r8
    c.r[4] = ld32(0x06076230u);  // 06076142 mov.l 0x06076230,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06076144 mov.b @r1+,r2
    c.r[6] = 0x0u;  // 06076146 mov #0,r6
    st8(c.r[3], c.r[2]);  // 06076148 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607614A mov.b @r1,r1
    c.r[3] += 1;  // 0607614C add #1,r3
    st8(c.r[3], c.r[1]);  // 0607614E mov.b r1,@r3
    c.r[1] = ld32(0x06076234u);  // 06076150 mov.l 0x06076234,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076152 mov.b @r1,r1
    c.r[2] = ld32(0x06076238u);  // 06076154 mov.l 0x06076238,r2
    st8(c.r[2], c.r[1]);  // 06076156 mov.b r1,@r2
    c.r[1] = ld32(0x0607623Cu);  // 06076158 mov.l 0x0607623C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607615A mov.b @r1,r1
    c.r[2] = ld32(0x06076240u);  // 0607615C mov.l 0x06076240,r2
    st8(c.r[2], c.r[1]);  // 0607615E mov.b r1,@r2
    c.r[1] = ld32(0x06076244u);  // 06076160 mov.l 0x06076244,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076162 mov.b @r1,r1
    c.r[2] = ld32(0x06076248u);  // 06076164 mov.l 0x06076248,r2
    st8(c.r[2], c.r[1]);  // 06076166 mov.b r1,@r2
L_06076168:
    c.r[3] = c.r[7];  // 06076168 mov r7,r3
    c.r[3] += c.r[3];  // 0607616A add r3,r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x06076218u);  // 0607616C mov.w 0x06076218,r5
    c.r[7] += 1;  // 0607616E add #1,r7
    c.r[2] = ld32(c.r[4]);  // 06076170 mov.l @r4,r2
    c.t = (int32_t)c.r[7] > (int32_t)c.r[9];  // 06076172 cmp/gt r9,r7
    c.r[1] = ld32(c.r[8]);  // 06076174 mov.l @r8,r1
    c.r[2] += c.r[5];  // 06076176 add r5,r2
    c.r[2] += c.r[6];  // 06076178 add r6,r2
    c.r[2] += 4;  // 0607617A add #4,r2
    c.r[0] = c.r[1];  // 0607617C mov r1,r0
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607617E mov.b @(r0,r3),r10
    c.r[6] += 8;  // 06076180 add #8,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076182 mov.b @r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607621Au);  // 06076184 mov.w 0x0607621A,r0
    c.r[10] &= c.r[0];  // 06076186 and r0,r10
    c.r[0] = c.r[1];  // 06076188 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[10]);  // 0607618A mov.b r10,@(r0,r3)
    c.r[1] += c.r[3];  // 0607618C add r3,r1
    c.r[1] += 1;  // 0607618E add #1,r1
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_06076168; } }  // 06076190 bf/s 0x06076168 ; mov.b r2,@r1
    c.r[1] = ld32(0x06076230u);  // 06076194 mov.l 0x06076230,r1
    c.r[2] = ld32(c.r[1]);  // 06076196 mov.l @r1,r2
    c.r[2] += c.r[5];  // 06076198 add r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607621Cu);  // 0607619A mov.w 0x0607621C,r1
    c.r[0] = c.r[2];  // 0607619C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607619E mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607624Cu);  // 060761A0 mov.l 0x0607624C,r3
    st8(c.r[3], c.r[1]); goto L_0607620A;  // 060761A2 bra 0x0607620A ; mov.b r1,@r3
L_060761A6:
    c.r[3] = ld32(0x06076228u);  // 060761A6 mov.l 0x06076228,r3
    c.r[1] = ld32(0x06076224u);  // 060761A8 mov.l 0x06076224,r1
    c.r[7] = 0x0u;  // 060761AA mov #0,r7
    c.r[8] = 0x49u;  // 060761AC mov #73,r8
    c.r[9] = ld32(0x06076230u);  // 060761AE mov.l 0x06076230,r9
    c.r[4] = (uint32_t)(int16_t)ld16(0x06076218u);  // 060761B0 mov.w 0x06076218,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060761B2 mov.b @r1+,r2
    c.r[5] = ld32(0x0607622Cu);  // 060761B4 mov.l 0x0607622C,r5
    st8(c.r[3], c.r[2]);  // 060761B6 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060761B8 mov.b @r1,r1
    c.r[3] += 1;  // 060761BA add #1,r3
    st8(c.r[3], c.r[1]);  // 060761BC mov.b r1,@r3
    c.r[1] = ld32(0x06076238u);  // 060761BE mov.l 0x06076238,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060761C0 mov.b @r1,r1
    c.r[2] = ld32(0x06076234u);  // 060761C2 mov.l 0x06076234,r2
    st8(c.r[2], c.r[1]);  // 060761C4 mov.b r1,@r2
    c.r[1] = ld32(0x06076248u);  // 060761C6 mov.l 0x06076248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060761C8 mov.b @r1,r2
    c.r[6] = 0x0u;  // 060761CA mov #0,r6
    c.r[0] = c.r[2] & 0xFFu;  // 060761CC extu.b r2,r0
    c.r[1] = ld32(0x06076250u);  // 060761CE mov.l 0x06076250,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060761D0 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607623Cu);  // 060761D2 mov.l 0x0607623C,r3
    st8(c.r[3], c.r[1]);  // 060761D4 mov.b r1,@r3
    c.r[1] = ld32(0x06076244u);  // 060761D6 mov.l 0x06076244,r1
    st8(c.r[1], c.r[2]);  // 060761D8 mov.b r2,@r1
L_060761DA:
    c.r[1] = c.r[7];  // 060761DA mov r7,r1
    c.r[1] += c.r[1];  // 060761DC add r1,r1
    c.r[7] += 1;  // 060761DE add #1,r7
    c.r[3] = ld32(c.r[9]);  // 060761E0 mov.l @r9,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[8];  // 060761E2 cmp/gt r8,r7
    c.r[2] = ld32(c.r[5]);  // 060761E4 mov.l @r5,r2
    c.r[3] += c.r[4];  // 060761E6 add r4,r3
    c.r[3] += c.r[6];  // 060761E8 add r6,r3
    c.r[3] += 4;  // 060761EA add #4,r3
    c.r[2] += c.r[1];  // 060761EC add r1,r2
    c.r[2] += 1;  // 060761EE add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060761F0 mov.b @r2,r1
    c.r[6] += 8;  // 060761F2 add #8,r6
    { const bool k = !c.t; st8(c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_060761DA; } }  // 060761F4 bf/s 0x060761DA ; mov.b r1,@r3
    c.r[1] = ld32(0x06076230u);  // 060761F8 mov.l 0x06076230,r1
    c.r[3] = ld32(c.r[1]);  // 060761FA mov.l @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607621Cu);  // 060761FC mov.w 0x0607621C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06076218u);  // 060761FE mov.w 0x06076218,r1
    c.r[3] += c.r[1];  // 06076200 add r1,r3
    c.r[1] = ld32(0x0607624Cu);  // 06076202 mov.l 0x0607624C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076204 mov.b @r1,r1
    c.r[0] = c.r[3];  // 06076206 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06076208 mov.b r1,@(r0,r2)
L_0607620A:
    c.r[15] = c.r[14];  // 0607620A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607620C mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607620E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06076210 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607621Eu);  // 06076212 mov.w 0x0607621E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076214 rts ; mov.l @r15+,r8
}

void f_06076254(SH2Context& c) {
    ran[1633] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076254 mov.l r14,@-r15
    c.r[1] = ld32(0x0607627Cu);  // 06076256 mov.l 0x0607627C,r1
    c.r[1] = ld32(c.r[1]);  // 06076258 mov.l @r1,r1
    c.r[1] += 1;  // 0607625A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607625C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607625E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076260 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607626C; } }  // 06076262 bt/s 0x0607626C ; mov r15,r14
    c.r[2] = ld32(0x06076280u);  // 06076266 mov.l 0x06076280,r2
    c.r[1] = 0xFFFFFFFFu; goto L_06076270;  // 06076268 bra 0x06076270 ; mov #-1,r1
L_0607626C:
    c.r[2] = ld32(0x06076280u);  // 0607626C mov.l 0x06076280,r2
    c.r[1] = 0x0u;  // 0607626E mov #0,r1
L_06076270:
    st8(c.r[2], c.r[1]);  // 06076270 mov.b r1,@r2
    c.r[15] = c.r[14];  // 06076272 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607627Au);  // 06076274 mov.w 0x0607627A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076276 rts ; mov.l @r15+,r14
}

void f_06076284(SH2Context& c) {
    ran[1634] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076284 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076286 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06076288 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607628A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607628C sts.l pr,@-r15
    c.r[15] -= 48;  // 0607628E add #-48,r15
    c.r[14] = c.r[15];  // 06076290 mov r15,r14
    c.r[3] = ld32(0x06076324u);  // 06076292 mov.l 0x06076324,r3
    c.r[10] = ld32(0x06076328u);  // 06076294 mov.l 0x06076328,r10
    c.r[1] = c.r[10];  // 06076296 mov r10,r1
    c.r[1] += 5;  // 06076298 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607629A mov.b @r1,r2
    c.r[9] = ld32(0x0607632Cu);  // 0607629C mov.l 0x0607632C,r9
    st8(c.r[3], c.r[2]);  // 0607629E mov.b r2,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 060762A0 extu.b r2,r2
    c.r[1] = ld32(0x06076330u);  // 060762A2 mov.l 0x06076330,r1
    c.r[1] = ld32(c.r[1]);  // 060762A4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060762A6 shll2 r2
    c.r[2] <<= 2;  // 060762A8 shll2 r2
    c.r[2] += c.r[1];  // 060762AA add r1,r2
    c.r[2] += 2;  // 060762AC add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060762AE mov.b @r2,r2
    c.r[1] = 0x1Eu;  // 060762B0 mov #30,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060762B2 extu.b r2,r2
    c.macl = c.r[2] * c.r[1];  // 060762B4 mul.l r1,r2
    c.r[4] = c.r[14];  // 060762B6 mov r14,r4
    c.r[3] = ld32(c.r[9]);  // 060762B8 mov.l @r9,r3
    c.r[8] = c.macl;  // 060762BA sts macl,r8
    c.r[3] += c.r[8];  // 060762BC add r8,r3
    c.r[3] += 15;  // 060762BE add #15,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060762C0 mov.b @r3,r5
    c.r[1] = ld32(0x06076334u);  // 060762C2 mov.l 0x06076334,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060762C8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060762C8u) return; }  // 060762C4 jsr @r1 ; extu.b r5,r5
    c.r[3] = ld32(0x06076338u);  // 060762C8 mov.l 0x06076338,r3
    c.r[2] = c.r[3];  // 060762CA mov r3,r2
    c.r[1] = c.r[14];  // 060762CC mov r14,r1
    c.r[1] += 42;  // 060762CE add #42,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060762D0 mov.w @r1,r1
    c.r[2] += 8;  // 060762D2 add #8,r2
    c.r[1] <<= 16;  // 060762D4 shll16 r1
    c.r[1] += c.r[1];  // 060762D6 add r1,r1
    c.r[1] >>= 16;  // 060762D8 shlr16 r1
    c.r[1] += c.r[1];  // 060762DA add r1,r1
    c.r[1] >>= 8;  // 060762DC shlr8 r1
    st16(c.r[2], c.r[1]);  // 060762DE mov.w r1,@r2
    c.r[2] = c.r[3];  // 060762E0 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 060762E2 mov.w @r14,r1
    c.r[2] += 6;  // 060762E4 add #6,r2
    st16(c.r[2], c.r[1]);  // 060762E6 mov.w r1,@r2
    c.r[9] = ld32(c.r[9]);  // 060762E8 mov.l @r9,r9
    c.r[3] += 10;  // 060762EA add #10,r3
    c.r[9] += c.r[8];  // 060762EC add r8,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060762EE mov.w @r9,r1
    c.r[2] = ld32(0x0607633Cu);  // 060762F0 mov.l 0x0607633C,r2
    st16(c.r[3], c.r[1]);  // 060762F2 mov.w r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060762F4 mov.b @r2,r0
    c.r[0] &= 0xEFu;  // 060762F6 and #239,r0
    st8(c.r[2], c.r[0]);  // 060762F8 mov.b r0,@r2
    c.r[10] = ld32(c.r[10]);  // 060762FA mov.l @r10,r10
    c.t = (int32_t)c.r[10] >= 0;  // 060762FC cmp/pz r10
    if (c.t) { goto L_06076302; }  // 060762FE bt 0x06076302
    c.r[10] = 0u - c.r[10];  // 06076300 neg r10,r10
L_06076302:
    c.r[9] += 22;  // 06076302 add #22,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06076304 mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06076306 extu.w r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06076308 cmp/ge r1,r10
    { const bool k = !c.t; c.r[0] |= 0x10u; if (k) { goto L_06076310; } }  // 0607630A bf/s 0x06076310 ; or #16,r0
    st8(c.r[2], c.r[0]);  // 0607630E mov.b r0,@r2
L_06076310:
    c.r[14] += 48;  // 06076310 add #48,r14
    c.r[15] = c.r[14];  // 06076312 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076314 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06076316 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06076318 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607631A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076322u);  // 0607631C mov.w 0x06076322,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607631E rts ; mov.l @r15+,r8
}

void f_06076340(SH2Context& c) {
    ran[1635] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076340 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076342 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06076344 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06076346 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076348 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607634A sts.l pr,@-r15
    c.r[11] = ld32(0x06076424u);  // 0607634C mov.l 0x06076424,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0607634E mov.b @r11,r1
    c.r[10] = ld32(0x06076428u);  // 06076350 mov.l 0x06076428,r10
    c.r[2] = ld32(c.r[10]);  // 06076352 mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06076354 extu.b r1,r1
    c.r[1] <<= 2;  // 06076356 shll2 r1
    c.r[1] <<= 2;  // 06076358 shll2 r1
    c.r[1] += c.r[2];  // 0607635A add r2,r1
    c.r[1] += 2;  // 0607635C add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607635E mov.b @r1,r2
    c.r[1] = ld32(0x0607642Cu);  // 06076360 mov.l 0x0607642C,r1
    c.r[3] = ld32(c.r[1]);  // 06076362 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06076364 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06076366 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06076368 mul.l r1,r2
    c.r[14] = c.r[15];  // 0607636A mov r15,r14
    c.r[1] = c.macl;  // 0607636C sts macl,r1
    c.r[0] = c.r[1];  // 0607636E mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06076370 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 06076372 mov #0,r4
    c.r[0] = ld32(0x06076430u);  // 06076374 mov.l 0x06076430,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607637Au; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607637Au) return; }  // 06076376 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0607637A mov r0,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0607637C extu.w r1,r9
    c.r[1] = ld32(0x06076434u);  // 0607637E mov.l 0x06076434,r1
    c.t = c.r[9] == c.r[1];  // 06076380 cmp/eq r1,r9
    if (c.t) { goto L_0607640A; }  // 06076382 bt 0x0607640A
    c.r[4] = ld32(0x06076438u);  // 06076384 mov.l 0x06076438,r4
    c.r[8] = ld32(0x0607643Cu);  // 06076386 mov.l 0x0607643C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607638Cu; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607638Cu) return; }  // 06076388 jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 0607638C mov r0,r1
    c.r[5] = 0x4u;  // 0607638E mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06076394u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076394u) return; }  // 06076390 jsr @r8 ; mov r1,r4
    c.r[5] = c.r[0];  // 06076394 mov r0,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06076396 mov.b @r11,r1
    c.r[7] = ld32(0x06076440u);  // 06076398 mov.l 0x06076440,r7
    c.r[3] = ld32(c.r[10]);  // 0607639A mov.l @r10,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607639C extu.b r1,r1
    c.r[1] <<= 2;  // 0607639E shll2 r1
    c.r[1] <<= 2;  // 060763A0 shll2 r1
    c.r[2] = c.r[1];  // 060763A2 mov r1,r2
    c.r[2] += c.r[3];  // 060763A4 add r3,r2
    c.r[2] += 1;  // 060763A6 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060763A8 mov.b @r2,r2
    c.r[0] = c.r[1];  // 060763AA mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060763AC mov.b @(r0,r3),r6
    c.r[2] = c.r[2] & 0xFFu;  // 060763AE extu.b r2,r2
    c.r[3] = c.r[6] & 0xFFu;  // 060763B0 extu.b r6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607641Cu);  // 060763B2 mov.w 0x0607641C,r1
    c.r[0] = c.r[7];  // 060763B4 mov r7,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060763B6 mov.l @(r0,r1),r1
    c.r[2] <<= 2;  // 060763B8 shll2 r2
    c.r[2] <<= 2;  // 060763BA shll2 r2
    c.r[2] <<= 2;  // 060763BC shll2 r2
    c.r[2] += c.r[1];  // 060763BE add r1,r2
    c.r[0] = c.r[2];  // 060763C0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060763C2 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060763C4 extu.b r1,r1
    c.r[1] += c.r[1];  // 060763C6 add r1,r1
    c.r[1] += c.r[5];  // 060763C8 add r5,r1
    c.r[1] += 1;  // 060763CA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060763CC mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607641Eu);  // 060763CE mov.w 0x0607641E,r0
    c.r[1] &= c.r[0];  // 060763D0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060763D2 tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[9]; if (k) { goto L_0607640A; } }  // 060763D4 bt/s 0x0607640A ; mov r9,r3
    c.r[7] = ld32(0x06076444u);  // 060763D8 mov.l 0x06076444,r7
    c.r[1] = ld32(c.r[7]);  // 060763DA mov.l @r7,r1
    c.r[3] <<= 2;  // 060763DC shll2 r3
    c.r[1] += c.r[3];  // 060763DE add r3,r1
    c.r[1] += 20;  // 060763E0 add #20,r1
    st8(c.r[1], c.r[6]);  // 060763E2 mov.b r6,@r1
    c.r[6] = ld32(c.r[7]);  // 060763E4 mov.l @r7,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060763E6 mov.b @r11,r1
    c.r[2] = ld32(c.r[10]);  // 060763E8 mov.l @r10,r2
    c.r[6] += c.r[3];  // 060763EA add r3,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060763EC extu.b r1,r1
    c.r[1] <<= 2;  // 060763EE shll2 r1
    c.r[1] <<= 2;  // 060763F0 shll2 r1
    c.r[1] += c.r[2];  // 060763F2 add r2,r1
    c.r[1] += 1;  // 060763F4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060763F6 mov.b @r1,r1
    c.r[6] += 21;  // 060763F8 add #21,r6
    st8(c.r[6], c.r[1]);  // 060763FA mov.b r1,@r6
    c.r[1] = ld32(c.r[7]);  // 060763FC mov.l @r7,r1
    c.r[1] += c.r[3];  // 060763FE add r3,r1
    c.r[1] += 22;  // 06076400 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076402 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06076404 and #63,r0
    c.r[0] |= 0x80u;  // 06076406 or #128,r0
    st8(c.r[1], c.r[0]);  // 06076408 mov.b r0,@r1
L_0607640A:
    c.r[15] = c.r[14];  // 0607640A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607640C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607640E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06076410 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06076412 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06076414 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076420u);  // 06076416 mov.w 0x06076420,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076418 rts ; mov.l @r15+,r8
}

void f_06076448(SH2Context& c) {
    ran[1636] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076448 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607644A sts.l pr,@-r15
    c.r[1] = ld32(0x060764A0u);  // 0607644C mov.l 0x060764A0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607644E mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06076450 extu.b r2,r2
    c.r[1] = ld32(0x060764A4u);  // 06076452 mov.l 0x060764A4,r1
    c.r[1] = ld32(c.r[1]);  // 06076454 mov.l @r1,r1
    c.r[2] <<= 2;  // 06076456 shll2 r2
    c.r[2] <<= 2;  // 06076458 shll2 r2
    c.r[2] += c.r[1];  // 0607645A add r1,r2
    c.r[2] += 2;  // 0607645C add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607645E mov.b @r2,r2
    c.r[1] = ld32(0x060764A8u);  // 06076460 mov.l 0x060764A8,r1
    c.r[3] = ld32(c.r[1]);  // 06076462 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06076464 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06076466 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06076468 mul.l r1,r2
    c.r[14] = c.r[15];  // 0607646A mov r15,r14
    c.r[1] = c.macl;  // 0607646C sts macl,r1
    c.r[0] = c.r[1];  // 0607646E mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06076470 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 06076472 mov #0,r4
    c.r[0] = ld32(0x060764ACu);  // 06076474 mov.l 0x060764AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607647Au; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607647Au) return; }  // 06076476 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0607647A mov r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0607647C extu.w r1,r2
    c.r[1] = ld32(0x060764B0u);  // 0607647E mov.l 0x060764B0,r1
    c.t = c.r[2] == c.r[1];  // 06076480 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_06076494; } }  // 06076482 bt/s 0x06076494 ; shll2 r2
    c.r[1] = ld32(0x060764B4u);  // 06076486 mov.l 0x060764B4,r1
    c.r[1] = ld32(c.r[1]);  // 06076488 mov.l @r1,r1
    c.r[1] += c.r[2];  // 0607648A add r2,r1
    c.r[1] += 22;  // 0607648C add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607648E mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06076490 and #63,r0
    st8(c.r[1], c.r[0]);  // 06076492 mov.b r0,@r1
L_06076494:
    c.r[15] = c.r[14];  // 06076494 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076496 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607649Eu);  // 06076498 mov.w 0x0607649E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607649A rts ; mov.l @r15+,r14
}

void f_060764B8(SH2Context& c) {
    ran[1637] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060764B8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060764BA sts.l pr,@-r15
    c.r[1] = ld32(0x060764D8u);  // 060764BC mov.l 0x060764D8,r1
    c.r[1] = ld32(c.r[1]);  // 060764BE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060764C0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060764C2 extu.b r1,r0
    c.r[0] <<= 2;  // 060764C4 shll2 r0
    c.r[1] = ld32(0x060764DCu);  // 060764C6 mov.l 0x060764DC,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060764C8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060764CEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060764CEu) return; }  // 060764CA jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060764CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060764D0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060764D2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060764D4 rts ; extu.w r0,r0
}

void f_060764E0(SH2Context& c) {
    ran[1638] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060764E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060764E2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060764E4 mov r15,r14
    c.r[0] = ld32(0x060764F8u);  // 060764E6 mov.l 0x060764F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060764ECu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060764ECu) return; }  // 060764E8 jsr @r0 ; mov #1,r4
    c.r[15] = c.r[14];  // 060764EC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060764EE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060764F6u);  // 060764F0 mov.w 0x060764F6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060764F2 rts ; mov.l @r15+,r14
}

void f_060764FC(SH2Context& c) {
    ran[1639] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060764FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060764FE sts.l pr,@-r15
    c.r[0] = ld32(0x06076518u);  // 06076500 mov.l 0x06076518,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06076506u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076506u) return; }  // 06076502 jsr @r0 ; mov r15,r14
    c.r[1] = ld32(0x0607651Cu);  // 06076506 mov.l 0x0607651C,r1
    st8(c.r[1], c.r[0]);  // 06076508 mov.b r0,@r1
    c.r[15] = c.r[14];  // 0607650A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607650C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076514u);  // 0607650E mov.w 0x06076514,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076510 rts ; mov.l @r15+,r14
}

void f_06076520(SH2Context& c) {
    ran[1640] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076520 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076522 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076524 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06076526 sts.l pr,@-r15
    c.r[1] = ld32(0x0607666Cu);  // 06076528 mov.l 0x0607666C,r1
    c.r[2] = ld32(c.r[1]);  // 0607652A mov.l @r1,r2
    c.r[1] = ld32(0x06076670u);  // 0607652C mov.l 0x06076670,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607652E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06076530 extu.b r1,r0
    c.r[1] = ld32(0x06076674u);  // 06076532 mov.l 0x06076674,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06076534 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06076536 extu.b r1,r1
    c.r[1] += c.r[1];  // 06076538 add r1,r1
    c.r[2] += c.r[1];  // 0607653A add r1,r2
    c.r[2] += 1;  // 0607653C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607653E mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06076540 extu.b r1,r9
    c.r[1] = ld32(0x06076678u);  // 06076542 mov.l 0x06076678,r1
    c.r[1] = ld32(c.r[1]);  // 06076544 mov.l @r1,r1
    c.r[1] += c.r[9];  // 06076546 add r9,r1
    c.r[1] += 16;  // 06076548 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607654A mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0607654C extu.b r1,r5
    c.r[1] = 0xDu;  // 0607654E mov #13,r1
    c.r[2] = c.r[5];  // 06076550 mov r5,r2
    c.r[2] -= 8;  // 06076552 add #-8,r2
    c.t = c.r[2] > c.r[1];  // 06076554 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607662E; } }  // 06076556 bt/s 0x0607662E ; mov r15,r14
    c.r[1] = c.r[2];  // 0607655A mov r2,r1
    c.r[1] += c.r[1];  // 0607655C add r1,r1
    c.r[0] = 0x06076568u;  // 0607655E mova 0x06076568,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06076560 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06076562 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060765BAu: goto L_060765BA; case 0x060765E6u: goto L_060765E6; case 0x0607662Eu: goto L_0607662E; case 0x06076584u: goto L_06076584; case 0x06076616u: goto L_06076616; default: sh2_call(c, x); return; } }  // 06076564 jmp @r0 ; nop
L_06076584:
    c.r[1] = ld32(0x06076678u);  // 06076584 mov.l 0x06076678,r1
    c.r[3] = ld32(c.r[1]);  // 06076586 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06076662u);  // 06076588 mov.w 0x06076662,r7
    c.r[1] = c.r[3];  // 0607658A mov r3,r1
    c.r[1] += 22;  // 0607658C add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607658E mov.w @r1,r1
    c.r[3] += 26;  // 06076590 add #26,r3
    c.r[6] = c.r[1] & 0xFFFFu;  // 06076592 extu.w r1,r6
    c.r[2] = c.r[6];  // 06076594 mov r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06076596 mov.w @r3,r1
    c.r[2] += c.r[7];  // 06076598 add r7,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607659A extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607659C cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060765A6; } }  // 0607659E bt/s 0x060765A6 ; mov r5,r0
    c.t = c.r[0] == 0x15u;  // 060765A2 cmp/eq #21,r0
    if (!c.t) { goto L_060765AC; }  // 060765A4 bf 0x060765AC
L_060765A6:
    c.r[1] -= c.r[6];  // 060765A6 sub r6,r1
    c.r[6] = c.r[1]; goto L_060765AE;  // 060765A8 bra 0x060765AE ; mov r1,r6
L_060765AC:
    c.r[6] = c.r[7];  // 060765AC mov r7,r6
L_060765AE:
    c.r[1] = ld32(0x0607667Cu);  // 060765AE mov.l 0x0607667C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060765B0 mov.b @r1,r4
    c.r[5] = 0x11u;  // 060765B2 mov #17,r5
    c.r[1] = ld32(0x06076680u);  // 060765B4 mov.l 0x06076680,r1
    c.r[4] = c.r[4] & 0xFFu; goto L_0607662A;  // 060765B6 bra 0x0607662A ; extu.b r4,r4
L_060765BA:
    c.r[1] = ld32(0x06076678u);  // 060765BA mov.l 0x06076678,r1
    c.r[2] = ld32(c.r[1]);  // 060765BC mov.l @r1,r2
    c.r[1] = c.r[2];  // 060765BE mov r2,r1
    c.r[1] += 24;  // 060765C0 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060765C2 mov.w @r1,r1
    c.r[2] += 28;  // 060765C4 add #28,r2
    c.r[7] = c.r[1] & 0xFFFFu;  // 060765C6 extu.w r1,r7
    c.r[3] = c.r[7];  // 060765C8 mov r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060765CA mov.w @r2,r1
    c.r[3] += 50;  // 060765CC add #50,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 060765CE extu.w r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060765D0 cmp/gt r1,r3
    { const bool k = !c.t; c.r[6] = 0x32u; if (k) { goto L_060765DA; } }  // 060765D2 bf/s 0x060765DA ; mov #50,r6
    c.r[6] = c.r[1];  // 060765D6 mov r1,r6
    c.r[6] -= c.r[7];  // 060765D8 sub r7,r6
L_060765DA:
    c.r[1] = ld32(0x0607667Cu);  // 060765DA mov.l 0x0607667C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060765DC mov.b @r1,r4
    c.r[5] = 0x12u;  // 060765DE mov #18,r5
    c.r[1] = ld32(0x06076680u);  // 060765E0 mov.l 0x06076680,r1
    c.r[4] = c.r[4] & 0xFFu; goto L_0607662A;  // 060765E2 bra 0x0607662A ; extu.b r4,r4
L_060765E6:
    c.r[1] = ld32(0x06076678u);  // 060765E6 mov.l 0x06076678,r1
    c.r[3] = ld32(c.r[1]);  // 060765E8 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06076664u);  // 060765EA mov.w 0x06076664,r7
    c.r[1] = c.r[3];  // 060765EC mov r3,r1
    c.r[1] += 24;  // 060765EE add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060765F0 mov.w @r1,r1
    c.r[3] += 28;  // 060765F2 add #28,r3
    c.r[6] = c.r[1] & 0xFFFFu;  // 060765F4 extu.w r1,r6
    c.r[2] = c.r[6];  // 060765F6 mov r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060765F8 mov.w @r3,r1
    c.r[2] += c.r[7];  // 060765FA add r7,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060765FC extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060765FE cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] -= c.r[6]; if (k) { goto L_06076608; } }  // 06076600 bf/s 0x06076608 ; sub r6,r1
    c.r[6] = c.r[1]; goto L_0607660A;  // 06076604 bra 0x0607660A ; mov r1,r6
L_06076608:
    c.r[6] = c.r[7];  // 06076608 mov r7,r6
L_0607660A:
    c.r[1] = ld32(0x0607667Cu);  // 0607660A mov.l 0x0607667C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607660C mov.b @r1,r4
    c.r[5] = 0x12u;  // 0607660E mov #18,r5
    c.r[1] = ld32(0x06076680u);  // 06076610 mov.l 0x06076680,r1
    c.r[4] = c.r[4] & 0xFFu; goto L_0607662A;  // 06076612 bra 0x0607662A ; extu.b r4,r4
L_06076616:
    c.r[8] = ld32(0x0607667Cu);  // 06076616 mov.l 0x0607667C,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06076618 mov.b @r8,r4
    c.r[1] = ld32(0x06076684u);  // 0607661A mov.l 0x06076684,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06076620u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076620u) return; }  // 0607661C jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x06076680u);  // 06076620 mov.l 0x06076680,r1
    c.r[6] = 0x0u;  // 06076622 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06076624 mov.b @r8,r4
    c.r[5] = 0x12u;  // 06076626 mov #18,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06076628 extu.b r4,r4
L_0607662A:
    { const uint32_t x = c.r[1]; c.pr = 0x0607662Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607662Eu) return; }  // 0607662A jsr @r1 ; nop
L_0607662E:
    c.r[1] = ld32(0x06076688u);  // 0607662E mov.l 0x06076688,r1
    c.r[2] = ld32(c.r[1]);  // 06076630 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06076666u);  // 06076632 mov.w 0x06076666,r1
    c.r[2] += c.r[1];  // 06076634 add r1,r2
    c.r[1] = ld32(0x0607668Cu);  // 06076636 mov.l 0x0607668C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076638 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607663A extu.w r1,r1
    c.r[1] <<= 2;  // 0607663C shll2 r1
    c.r[1] += c.r[1];  // 0607663E add r1,r1
    c.r[2] += c.r[1];  // 06076640 add r1,r2
    c.r[2] += 4;  // 06076642 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 06076644 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06076646 mov.b r1,@r2
    c.r[1] = ld32(0x0607667Cu);  // 06076648 mov.l 0x0607667C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607664A mov.b @r1,r4
    c.r[5] = c.r[9];  // 0607664C mov r9,r5
    c.r[1] = ld32(0x06076690u);  // 0607664E mov.l 0x06076690,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06076654u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076654u) return; }  // 06076650 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 06076654 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076656 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06076658 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607665A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076668u);  // 0607665C mov.w 0x06076668,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607665E rts ; mov.l @r15+,r8
}

void f_06076694(SH2Context& c) {
    ran[1641] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076694 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06076696 sts.l pr,@-r15
    c.r[1] = ld32(0x060766B4u);  // 06076698 mov.l 0x060766B4,r1
    c.r[1] = ld32(c.r[1]);  // 0607669A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607669C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607669E extu.b r1,r0
    c.r[0] <<= 2;  // 060766A0 shll2 r0
    c.r[1] = ld32(0x060766B8u);  // 060766A2 mov.l 0x060766B8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060766A4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060766AAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060766AAu) return; }  // 060766A6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060766AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060766AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060766AE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060766B0 rts ; extu.w r0,r0
}

void f_060766BC(SH2Context& c) {
    ran[1642] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060766BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060766BE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060766C0 mov r15,r14
    c.r[0] = ld32(0x060766E8u);  // 060766C2 mov.l 0x060766E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060766C8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060766C8u) return; }  // 060766C4 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x060766ECu);  // 060766C8 mov.l 0x060766EC,r1
    c.r[2] = ld32(c.r[1]);  // 060766CA mov.l @r1,r2
    c.r[3] = ld32(0x060766F0u);  // 060766CC mov.l 0x060766F0,r3
    c.r[1] = c.r[0] & 0xFFu;  // 060766CE extu.b r0,r1
    c.r[1] += c.r[1];  // 060766D0 add r1,r1
    c.r[2] += c.r[1];  // 060766D2 add r1,r2
    c.r[2] += 1;  // 060766D4 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060766D6 mov.b @r2,r1
    c.r[15] = c.r[14];  // 060766D8 mov r14,r15
    st8(c.r[3], c.r[1]);  // 060766DA mov.b r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060766DC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060766E4u);  // 060766DE mov.w 0x060766E4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060766E0 rts ; mov.l @r15+,r14
}

void f_060766F4(SH2Context& c) {
    ran[1643] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060766F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060766F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060766F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060766FA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060767C6u);  // 060766FC mov.w 0x060767C6,r3
    c.r[15] += c.r[3];  // 060766FE add r3,r15
    c.r[14] = c.r[15];  // 06076700 mov r15,r14
    c.r[6] = ld32(0x060767D4u);  // 06076702 mov.l 0x060767D4,r6
    c.r[2] = ld32(0x060767D8u);  // 06076704 mov.l 0x060767D8,r2
    c.r[1] = c.r[2];  // 06076706 mov r2,r1
    c.r[1] += 117;  // 06076708 add #117,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x060767C8u);  // 0607670A mov.w 0x060767C8,r9
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607670C mov.b @r1,r3
    c.r[4] = c.r[14];  // 0607670E mov r14,r4
    c.r[1] = c.r[2];  // 06076710 mov r2,r1
    c.r[1] += 79;  // 06076712 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076714 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06076716 extu.b r3,r3
    c.r[3] += c.r[1];  // 06076718 add r1,r3
    c.r[1] = c.r[2];  // 0607671A mov r2,r1
    c.r[1] += 116;  // 0607671C add #116,r1
    c.r[2] += 78;  // 0607671E add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076720 mov.b @r1,r1
    c.r[3] <<= 2;  // 06076722 shll2 r3
    c.r[3] <<= 2;  // 06076724 shll2 r3
    c.r[3] <<= 2;  // 06076726 shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076728 mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607672A extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 0607672C mov.l @r6,r2
    c.r[1] += c.r[7];  // 0607672E add r7,r1
    c.r[3] += c.r[2];  // 06076730 add r2,r3
    c.r[0] = c.r[3];  // 06076732 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06076734 mov.b @(r0,r1),r2
    c.r[6] = c.r[9];  // 06076736 mov r9,r6
    c.r[2] = c.r[2] & 0xFFu;  // 06076738 extu.b r2,r2
    c.r[8] = c.r[2];  // 0607673A mov r2,r8
    c.r[1] = ld32(0x060767DCu);  // 0607673C mov.l 0x060767DC,r1
    c.r[1] = ld32(c.r[1]);  // 0607673E mov.l @r1,r1
    c.r[2] <<= 2;  // 06076740 shll2 r2
    c.r[2] <<= 2;  // 06076742 shll2 r2
    c.r[2] += c.r[1];  // 06076744 add r1,r2
    c.r[2] += 2;  // 06076746 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076748 mov.b @r2,r5
    c.r[1] = ld32(0x060767E0u);  // 0607674A mov.l 0x060767E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06076750u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076750u) return; }  // 0607674C jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x060767E4u);  // 06076750 mov.l 0x060767E4,r1
    c.r[1] = ld32(c.r[1]);  // 06076752 mov.l @r1,r1
    c.r[1] += 2;  // 06076754 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076756 mov.b @r1,r1
    c.r[2] = 0x3Cu;  // 06076758 mov #60,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607675A extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0607675C mul.l r2,r1
    c.r[6] = ld32(0x060767E8u);  // 0607675E mov.l 0x060767E8,r6
    c.r[2] = c.macl;  // 06076760 sts macl,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060767CAu);  // 06076762 mov.w 0x060767CA,r1
    c.r[2] += c.r[1];  // 06076764 add r1,r2
    st32(c.r[6], c.r[2]);  // 06076766 mov.l r2,@r6
    c.r[1] = c.r[14];  // 06076768 mov r14,r1
    c.r[1] += 22;  // 0607676A add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607676C mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0607676E extu.w r1,r3
    c.r[1] = c.r[14];  // 06076770 mov r14,r1
    c.r[1] += 26;  // 06076772 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076774 mov.w @r1,r1
    c.r[2] += c.r[3];  // 06076776 add r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06076778 extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607677A cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] -= c.r[3]; if (k) { goto L_06076782; } }  // 0607677C bf/s 0x06076782 ; sub r3,r1
    st32(c.r[6], c.r[1]);  // 06076780 mov.l r1,@r6
L_06076782:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06076782 exts.w r8,r4
    c.r[1] = ld32(0x060767ECu);  // 06076784 mov.l 0x060767EC,r1
    c.r[6] = ld32(c.r[6]);  // 06076786 mov.l @r6,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607678Cu; c.r[5] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607678Cu) return; }  // 06076788 jsr @r1 ; mov #66,r5
    c.r[1] = ld32(0x060767F0u);  // 0607678C mov.l 0x060767F0,r1
    c.r[2] = ld32(c.r[1]);  // 0607678E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060767CCu);  // 06076790 mov.w 0x060767CC,r1
    c.r[2] += c.r[1];  // 06076792 add r1,r2
    c.r[1] = ld32(0x060767F4u);  // 06076794 mov.l 0x060767F4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076796 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06076798 extu.w r1,r1
    c.r[1] <<= 2;  // 0607679A shll2 r1
    c.r[1] += c.r[1];  // 0607679C add r1,r1
    c.r[2] += c.r[1];  // 0607679E add r1,r2
    c.r[2] += 4;  // 060767A0 add #4,r2
    st8(c.r[2], c.r[9]);  // 060767A2 mov.b r9,@r2
    c.r[1] = ld32(0x060767F8u);  // 060767A4 mov.l 0x060767F8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060767A6 mov.b @r1,r5
    c.r[1] = ld32(0x060767FCu);  // 060767A8 mov.l 0x060767FC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060767AA mov.b @r1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 060767AC extu.b r5,r5
    c.r[1] = ld32(0x06076800u);  // 060767AE mov.l 0x06076800,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060767B4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060767B4u) return; }  // 060767B0 jsr @r1 ; extu.b r4,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060767CEu);  // 060767B4 mov.w 0x060767CE,r3
    c.r[14] += c.r[3];  // 060767B6 add r3,r14
    c.r[15] = c.r[14];  // 060767B8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060767BA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060767BC mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060767BE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060767D0u);  // 060767C0 mov.w 0x060767D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060767C2 rts ; mov.l @r15+,r8
}

void f_06076804(SH2Context& c) {
    ran[1644] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076804 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06076806 sts.l pr,@-r15
    c.r[1] = ld32(0x06076824u);  // 06076808 mov.l 0x06076824,r1
    c.r[1] = ld32(c.r[1]);  // 0607680A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607680C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607680E extu.b r1,r0
    c.r[0] <<= 2;  // 06076810 shll2 r0
    c.r[1] = ld32(0x06076828u);  // 06076812 mov.l 0x06076828,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06076814 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607681Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607681Au) return; }  // 06076816 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0607681A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607681C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607681E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06076820 rts ; extu.w r0,r0
}

void f_0607682C(SH2Context& c) {
    ran[1645] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607682C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607682E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06076830 mov r15,r14
    c.r[0] = ld32(0x06076858u);  // 06076832 mov.l 0x06076858,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06076838u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076838u) return; }  // 06076834 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(0x0607685Cu);  // 06076838 mov.l 0x0607685C,r1
    c.r[2] = ld32(c.r[1]);  // 0607683A mov.l @r1,r2
    c.r[3] = ld32(0x06076860u);  // 0607683C mov.l 0x06076860,r3
    c.r[1] = c.r[0] & 0xFFu;  // 0607683E extu.b r0,r1
    c.r[1] += c.r[1];  // 06076840 add r1,r1
    c.r[2] += c.r[1];  // 06076842 add r1,r2
    c.r[2] += 1;  // 06076844 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076846 mov.b @r2,r1
    c.r[15] = c.r[14];  // 06076848 mov r14,r15
    st8(c.r[3], c.r[1]);  // 0607684A mov.b r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607684C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076854u);  // 0607684E mov.w 0x06076854,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076850 rts ; mov.l @r15+,r14
}

void f_06076864(SH2Context& c) {
    ran[1646] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076864 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076866 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06076868 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607686A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607686C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607686E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06076966u);  // 06076870 mov.w 0x06076966,r3
    c.r[15] += c.r[3];  // 06076872 add r3,r15
    c.r[14] = c.r[15];  // 06076874 mov r15,r14
    c.r[6] = ld32(0x06076970u);  // 06076876 mov.l 0x06076970,r6
    c.r[2] = ld32(0x06076974u);  // 06076878 mov.l 0x06076974,r2
    c.r[1] = c.r[2];  // 0607687A mov r2,r1
    c.r[1] += 117;  // 0607687C add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607687E mov.b @r1,r3
    c.r[8] = ld32(0x06076978u);  // 06076880 mov.l 0x06076978,r8
    c.r[1] = c.r[2];  // 06076882 mov r2,r1
    c.r[1] += 79;  // 06076884 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076886 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06076888 extu.b r3,r3
    c.r[3] += c.r[1];  // 0607688A add r1,r3
    c.r[1] = c.r[2];  // 0607688C mov r2,r1
    c.r[1] += 116;  // 0607688E add #116,r1
    c.r[2] += 78;  // 06076890 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076892 mov.b @r1,r1
    c.r[3] <<= 2;  // 06076894 shll2 r3
    c.r[3] <<= 2;  // 06076896 shll2 r3
    c.r[3] <<= 2;  // 06076898 shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607689A mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607689C extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 0607689E mov.l @r6,r2
    c.r[1] += c.r[7];  // 060768A0 add r7,r1
    c.r[3] += c.r[2];  // 060768A2 add r2,r3
    c.r[0] = c.r[3];  // 060768A4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060768A6 mov.b @(r0,r1),r1
    c.r[4] = c.r[14];  // 060768A8 mov r14,r4
    c.r[10] = c.r[1] & 0xFFu;  // 060768AA extu.b r1,r10
    c.r[9] = c.r[10];  // 060768AC mov r10,r9
    c.r[1] = ld32(c.r[8]);  // 060768AE mov.l @r8,r1
    c.r[9] <<= 2;  // 060768B0 shll2 r9
    c.r[9] <<= 2;  // 060768B2 shll2 r9
    c.r[1] += c.r[9];  // 060768B4 add r9,r1
    c.r[1] += 2;  // 060768B6 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060768B8 mov.b @r1,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06076968u);  // 060768BA mov.w 0x06076968,r6
    c.r[1] = ld32(0x0607697Cu);  // 060768BC mov.l 0x0607697C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060768C2u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060768C2u) return; }  // 060768BE jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 060768C2 mov r14,r1
    c.r[1] += 28;  // 060768C4 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060768C6 mov.w @r1,r1
    c.r[11] = c.r[1] & 0xFFFFu;  // 060768C8 extu.w r1,r11
    c.r[1] = c.r[14];  // 060768CA mov r14,r1
    c.r[1] += 24;  // 060768CC add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060768CE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060768D0 extu.w r1,r1
    c.r[11] -= c.r[1];  // 060768D2 sub r1,r11
    c.r[1] = ld32(0x06076980u);  // 060768D4 mov.l 0x06076980,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060768DAu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060768DAu) return; }  // 060768D6 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(c.r[8]);  // 060768DA mov.l @r8,r1
    c.r[9] += c.r[1];  // 060768DC add r1,r9
    c.r[9] += 2;  // 060768DE add #2,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060768E0 mov.b @r9,r2
    c.r[1] = ld32(0x06076984u);  // 060768E2 mov.l 0x06076984,r1
    c.r[3] = ld32(c.r[1]);  // 060768E4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060768E6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060768E8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060768EA mul.l r1,r2
    c.r[1] = c.macl;  // 060768EC sts macl,r1
    c.r[1] += c.r[3];  // 060768EE add r3,r1
    c.r[1] += 15;  // 060768F0 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060768F2 mov.b @r1,r1
    c.r[2] = ld32(0x06076988u);  // 060768F4 mov.l 0x06076988,r2
    c.r[2] = ld32(c.r[2]);  // 060768F6 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060768F8 extu.b r1,r1
    c.r[3] = c.r[1];  // 060768FA mov r1,r3
    c.r[3] += c.r[3];  // 060768FC add r3,r3
    c.r[3] += c.r[1];  // 060768FE add r1,r3
    c.r[3] <<= 2;  // 06076900 shll2 r3
    c.r[3] += c.r[2];  // 06076902 add r2,r3
    c.r[3] += 9;  // 06076904 add #9,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06076906 mov.b @r3,r7
    c.r[1] = 0x31u;  // 06076908 mov #49,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0607690A extu.b r7,r2
    c.r[2] -= 10;  // 0607690C add #-10,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607690E cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06076918; } }  // 06076910 bt/s 0x06076918 ; mov r7,r1
    c.r[1] = 0x32u; goto L_0607691A;  // 06076914 bra 0x0607691A ; mov #50,r1
L_06076918:
    c.r[1] -= 10;  // 06076918 add #-10,r1
L_0607691A:
    st8(c.r[3], c.r[1]);  // 0607691A mov.b r1,@r3
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[10];  // 0607691C exts.w r10,r4
    c.r[1] = ld32(0x0607698Cu);  // 0607691E mov.l 0x0607698C,r1
    c.r[6] = c.r[11];  // 06076920 mov r11,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06076926u; c.r[5] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076926u) return; }  // 06076922 jsr @r1 ; mov #5,r5
    c.r[1] = ld32(0x06076990u);  // 06076926 mov.l 0x06076990,r1
    c.r[2] = ld32(c.r[1]);  // 06076928 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607696Au);  // 0607692A mov.w 0x0607696A,r1
    c.r[2] += c.r[1];  // 0607692C add r1,r2
    c.r[1] = ld32(0x06076994u);  // 0607692E mov.l 0x06076994,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076930 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06076932 extu.w r1,r1
    c.r[1] <<= 2;  // 06076934 shll2 r1
    c.r[1] += c.r[1];  // 06076936 add r1,r1
    c.r[2] += c.r[1];  // 06076938 add r1,r2
    c.r[2] += 4;  // 0607693A add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0607693C mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0607693E mov.b r1,@r2
    c.r[1] = ld32(0x06076998u);  // 06076940 mov.l 0x06076998,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076942 mov.b @r1,r5
    c.r[1] = ld32(0x0607699Cu);  // 06076944 mov.l 0x0607699C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076946 mov.b @r1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06076948 extu.b r5,r5
    c.r[1] = ld32(0x060769A0u);  // 0607694A mov.l 0x060769A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06076950u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076950u) return; }  // 0607694C jsr @r1 ; extu.b r4,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607696Cu);  // 06076950 mov.w 0x0607696C,r3
    c.r[14] += c.r[3];  // 06076952 add r3,r14
    c.r[15] = c.r[14];  // 06076954 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076956 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06076958 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607695A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607695C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607695E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607696Eu);  // 06076960 mov.w 0x0607696E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076962 rts ; mov.l @r15+,r8
}

void f_060769A4(SH2Context& c) {
    ran[1647] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060769A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060769A6 sts.l pr,@-r15
    c.r[1] = ld32(0x060769C4u);  // 060769A8 mov.l 0x060769C4,r1
    c.r[1] = ld32(c.r[1]);  // 060769AA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060769AC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060769AE extu.b r1,r0
    c.r[0] <<= 2;  // 060769B0 shll2 r0
    c.r[1] = ld32(0x060769C8u);  // 060769B2 mov.l 0x060769C8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060769B4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060769BAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060769BAu) return; }  // 060769B6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060769BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060769BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060769BE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060769C0 rts ; extu.w r0,r0
}

void f_060769CC(SH2Context& c) {
    ran[1648] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060769CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060769CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060769D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060769D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060769D4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060769D6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060769D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060769DA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06076AC6u);  // 060769DC mov.w 0x06076AC6,r3
    c.r[15] += c.r[3];  // 060769DE add r3,r15
    c.r[14] = c.r[15];  // 060769E0 mov r15,r14
    c.r[9] = 0x0u;  // 060769E2 mov #0,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076AC8u);  // 060769E4 mov.w 0x06076AC8,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 060769E6 mov.l r9,@(r0,r14)
    c.r[13] = 0x0u;  // 060769E8 mov #0,r13
L_060769EA:
    c.r[0] = ld32(0x06076ADCu);  // 060769EA mov.l 0x06076ADC,r0
    c.r[2] = ld32(c.r[0]);  // 060769EC mov.l @r0,r2
    c.r[3] = c.r[13];  // 060769EE mov r13,r3
    c.r[3] += c.r[2];  // 060769F0 add r2,r3
    c.r[1] = c.r[3];  // 060769F2 mov r3,r1
    c.r[1] += 4;  // 060769F4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060769F6 mov.b @r1,r1
    c.r[9] = 0x1u;  // 060769F8 mov #1,r9
    c.r[1] >>= 2;  // 060769FA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060769FC shlr r1
    c.r[1] >>= 2;  // 060769FE shlr2 r1
    c.r[1] &= c.r[9];  // 06076A00 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076A02 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_06076A0C; } }  // 06076A04 bt/s 0x06076A0C ; mov r13,r0
    goto L_06076CEE;  // 06076A08 bra 0x06076CEE ; nop
L_06076A0C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06076A0C mov.b @(r0,r2),r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076ACAu);  // 06076A0E mov.w 0x06076ACA,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06076A10 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 06076A12 cmp/eq r9,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06076A1C; } }  // 06076A14 bf/s 0x06076A1C ; mov r3,r1
    goto L_06076CEE;  // 06076A18 bra 0x06076CEE ; nop
L_06076A1C:
    c.r[1] += 7;  // 06076A1C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076A1E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06076A20 mov r1,r0
    c.r[0] >>= 2;  // 06076A22 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06076A24 shlr r0
    c.r[0] &= 0x1u;  // 06076A26 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06076A28 tst r0,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06076A32; } }  // 06076A2A bt/s 0x06076A32 ; mov #0,r9
    goto L_06076CEE;  // 06076A2E bra 0x06076CEE ; nop
L_06076A32:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076ACCu);  // 06076A32 mov.w 0x06076ACC,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 06076A34 mov.l r9,@(r0,r14)
    c.r[11] = 0x0u;  // 06076A36 mov #0,r11
    c.r[3] += 2;  // 06076A38 add #2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076ACEu);  // 06076A3A mov.w 0x06076ACE,r0
    c.r[0] += c.r[14];  // 06076A3C add r14,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076AD0u);  // 06076A3E mov.w 0x06076AD0,r9
    c.r[9] += c.r[14];  // 06076A40 add r14,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06076A42 mov.b @r3,r1
    c.r[4] = c.r[14];  // 06076A44 mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06076A46 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06076A48 mov.l r1,@r0
    c.r[1] = ld32(0x06076AE0u);  // 06076A4A mov.l 0x06076AE0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076ACEu);  // 06076A4C mov.w 0x06076ACE,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06076A4E mov.b @r9,r9
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 06076A50 mov.l @(r0,r14),r5
    c.r[8] = c.r[9] & 0xFFu;  // 06076A52 extu.b r9,r8
    { const uint32_t x = c.r[1]; c.pr = 0x06076A58u; c.r[6] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076A58u) return; }  // 06076A54 jsr @r1 ; mov r8,r6
    c.r[1] = ld32(0x06076AE4u);  // 06076A58 mov.l 0x06076AE4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06076AD2u);  // 06076A5A mov.w 0x06076AD2,r5
    c.r[5] += c.r[14];  // 06076A5C add r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06076A62u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076A62u) return; }  // 06076A5E jsr @r1 ; mov r8,r4
    c.r[2] = ld32(0x06076AE8u);  // 06076A62 mov.l 0x06076AE8,r2
    c.r[9] = ld32(0x06076ADCu);  // 06076A64 mov.l 0x06076ADC,r9
    c.r[1] = c.r[13];  // 06076A66 mov r13,r1
    c.r[0] = c.r[13];  // 06076A68 mov r13,r0
    c.r[12] = ld32(0x06076AECu);  // 06076A6A mov.l 0x06076AEC,r12
    c.r[6] = 0x4u;  // 06076A6C mov #4,r6
    c.r[7] = ld32(c.r[9]);  // 06076A6E mov.l @r9,r7
    c.r[5] = 0xAu;  // 06076A70 mov #10,r5
    c.r[1] += c.r[7];  // 06076A72 add r7,r1
    c.r[1] += 1;  // 06076A74 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076A76 mov.b @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076AD4u);  // 06076A78 mov.w 0x06076AD4,r9
    c.r[3] = c.r[1] & 0xFFu;  // 06076A7A extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06076A7C mov.b @(r0,r7),r1
    c.r[9] += c.r[14];  // 06076A7E add r14,r9
    c.r[7] = c.r[1] & 0xFFu;  // 06076A80 extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06076AD6u);  // 06076A82 mov.w 0x06076AD6,r1
    c.r[0] = c.r[2];  // 06076A84 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06076A86 mov.l @(r0,r1),r1
    c.r[3] <<= 2;  // 06076A88 shll2 r3
    c.r[3] <<= 2;  // 06076A8A shll2 r3
    c.r[3] <<= 2;  // 06076A8C shll2 r3
    c.r[3] += c.r[1];  // 06076A8E add r1,r3
    c.r[0] = c.r[3];  // 06076A90 mov r3,r0
    c.r[2] = c.r[14];  // 06076A92 mov r14,r2
    c.r[2] += 39;  // 06076A94 add #39,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06076A96 mov.b @(r0,r7),r1
    c.r[4] = c.r[2];  // 06076A98 mov r2,r4
    c.r[10] = c.r[1] & 0xFFu;  // 06076A9A extu.b r1,r10
    { const uint32_t x = c.r[12]; c.pr = 0x06076AA0u; st32(c.r[9], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076AA0u) return; }  // 06076A9C jsr @r12 ; mov.l r2,@r9
    c.r[1] = c.r[0];  // 06076AA0 mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06076AA2 exts.b r1,r1
    c.r[0] = c.r[1];  // 06076AA4 mov r1,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076AD4u);  // 06076AA6 mov.w 0x06076AD4,r9
    c.r[9] += c.r[14];  // 06076AA8 add r14,r9
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06076AAA cmp/eq #-1,r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[9]); if (k) { goto L_06076AC2; } }  // 06076AAC bf/s 0x06076AC2 ; mov.l @r9,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x06076AD8u);  // 06076AB0 mov.w 0x06076AD8,r8
    c.r[0] = c.r[14];  // 06076AB2 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06076AB4 mov.b @(r0,r8),r1
    c.r[9] = 0x3u;  // 06076AB6 mov #3,r9
    c.r[1] &= c.r[9];  // 06076AB8 and r9,r1
    c.r[0] = c.r[1];  // 06076ABA mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06076ABC cmp/eq #2,r0
    { const bool k = !c.t; c.r[6] = 0x4u; if (k) { goto L_06076AF0; } }  // 06076ABE bf/s 0x06076AF0 ; mov #4,r6
L_06076AC2:
    c.r[11] = 0x1Eu; goto L_06076B10;  // 06076AC2 bra 0x06076B10 ; mov #30,r11
L_06076AF0:
    c.r[5] = 0x9u;  // 06076AF0 mov #9,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06076AF6u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076AF6u) return; }  // 06076AF2 jsr @r12 ; mov r2,r4
    c.r[1] = c.r[0];  // 06076AF6 mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06076AF8 exts.b r1,r1
    c.r[0] = c.r[1];  // 06076AFA mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06076AFC cmp/eq #-1,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06076B0E; } }  // 06076AFE bf/s 0x06076B0E ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06076B02 mov.b @(r0,r8),r1
    c.r[9] = 0x3u;  // 06076B04 mov #3,r9
    c.r[1] &= c.r[9];  // 06076B06 and r9,r1
    c.r[0] = c.r[1];  // 06076B08 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06076B0A cmp/eq #1,r0
    if (!c.t) { goto L_06076B10; }  // 06076B0C bf 0x06076B10
L_06076B0E:
    c.r[11] = 0xAu;  // 06076B0E mov #10,r11
L_06076B10:
    c.r[9] = ld32(0x06076C30u);  // 06076B10 mov.l 0x06076C30,r9
    c.r[1] = ld32(c.r[9]);  // 06076B12 mov.l @r9,r1
    c.r[1] += c.r[13];  // 06076B14 add r13,r1
    c.r[1] += 4;  // 06076B16 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076B18 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06076B1A mov #1,r0
    c.r[1] >>= 2;  // 06076B1C shlr2 r1
    c.r[1] >>= 2;  // 06076B1E shlr2 r1
    c.r[1] >>= 2;  // 06076B20 shlr2 r1
    c.r[1] &= c.r[0];  // 06076B22 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076B24 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06076B76; } }  // 06076B26 bt/s 0x06076B76 ; mov r11,r1
    c.r[1] += 25;  // 06076B2A add #25,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06076B2C extu.b r1,r11
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076C28u);  // 06076B2E mov.w 0x06076C28,r9
    c.r[9] += c.r[14];  // 06076B30 add r14,r9
    c.r[1] = ld32(c.r[9]);  // 06076B32 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076C28u);  // 06076B34 mov.w 0x06076C28,r0
    c.r[0] += c.r[14];  // 06076B36 add r14,r0
    c.r[6] = 0x0u;  // 06076B38 mov #0,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x06076C2Au);  // 06076B3A mov.w 0x06076C2A,r7
    c.r[7] += c.r[14];  // 06076B3C add r14,r7
    c.r[3] = 0x0u;  // 06076B3E mov #0,r3
    c.r[1] += 25;  // 06076B40 add #25,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06076B42 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06076B44 mov.l r1,@r0
L_06076B46:
    c.r[0] = c.r[7];  // 06076B46 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06076B48 mov.b @(r0,r6),r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076C2Cu);  // 06076B4A mov.w 0x06076C2C,r9
    c.r[5] = c.r[1] & 0xFFu;  // 06076B4C extu.b r1,r5
    c.t = c.r[5] == c.r[9];  // 06076B4E cmp/eq r9,r5
    if (c.t) { goto L_06076B68; }  // 06076B50 bt 0x06076B68
    c.r[1] = ld32(0x06076C34u);  // 06076B52 mov.l 0x06076C34,r1
    c.r[2] = ld32(c.r[1]);  // 06076B54 mov.l @r1,r2
    c.r[2] += c.r[13];  // 06076B56 add r13,r2
    c.r[1] = c.r[14];  // 06076B58 mov r14,r1
    c.r[1] += 52;  // 06076B5A add #52,r1
    c.r[0] = c.r[1];  // 06076B5C mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06076B5E mov.w @(r0,r3),r1
    c.r[2] += 40;  // 06076B60 add #40,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06076B62 shlr r1
    c.r[0] = c.r[2];  // 06076B64 mov r2,r0
    st8(c.r[0] + c.r[5], c.r[1]);  // 06076B66 mov.b r1,@(r0,r5)
L_06076B68:
    c.r[6] += 1;  // 06076B68 add #1,r6
    c.r[1] = 0xFu;  // 06076B6A mov #15,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06076B6C cmp/gt r1,r6
    { const bool k = !c.t; c.r[3] += 20; if (k) { SH2_POLL(c); goto L_06076B46; } }  // 06076B6E bf/s 0x06076B46 ; add #20,r3
    goto L_06076BAC;  // 06076B72 bra 0x06076BAC ; nop
L_06076B76:
    c.r[8] = ld32(0x06076C38u);  // 06076B76 mov.l 0x06076C38,r8
    c.r[4] = ld32(0x06076C3Cu);  // 06076B78 mov.l 0x06076C3C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06076B7Eu; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076B7Eu) return; }  // 06076B7A jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 06076B7E mov r0,r1
    c.r[5] = 0x4u;  // 06076B80 mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06076B86u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076B86u) return; }  // 06076B82 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06076B86 mov r0,r1
    c.r[3] = c.r[10];  // 06076B88 mov r10,r3
    c.r[3] += c.r[3];  // 06076B8A add r3,r3
    c.r[2] = c.r[1];  // 06076B8C mov r1,r2
    c.r[2] += c.r[3];  // 06076B8E add r3,r2
    c.r[2] += 1;  // 06076B90 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06076B92 mov.b @(r0,r3),r1
    c.r[9] = 0x7Fu;  // 06076B94 mov #127,r9
    c.r[1] += c.r[11];  // 06076B96 add r11,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06076B98 extu.b r1,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076C28u);  // 06076B9A mov.w 0x06076C28,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076B9C mov.b @r2,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06076B9E mov.l @(r0,r14),r0
    c.r[1] &= c.r[9];  // 06076BA0 and r9,r1
    c.r[1] += c.r[0];  // 06076BA2 add r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06076BA4 extu.b r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076C28u);  // 06076BA6 mov.w 0x06076C28,r9
    c.r[9] += c.r[14];  // 06076BA8 add r14,r9
    st32(c.r[9], c.r[1]);  // 06076BAA mov.l r1,@r9
L_06076BAC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06076C2Eu);  // 06076BAC mov.w 0x06076C2E,r1
    c.r[0] = c.r[14];  // 06076BAE mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06076BB0 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06076BB2 extu.b r1,r2
    c.r[2] >>= 2;  // 06076BB4 shlr2 r2
    c.r[2] >>= 2;  // 06076BB6 shlr2 r2
    c.r[2] >>= 2;  // 06076BB8 shlr2 r2
    c.r[0] = c.r[2];  // 06076BBA mov r2,r0
    c.t = c.r[0] == 0x2u;  // 06076BBC cmp/eq #2,r0
    { const bool k = c.t; c.r[10] = 0xAu; if (k) { goto L_06076BDA; } }  // 06076BBE bt/s 0x06076BDA ; mov #10,r10
    c.r[1] = 0x2u;  // 06076BC2 mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06076BC4 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06076BD4; } }  // 06076BC6 bt/s 0x06076BD4 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 06076BCA cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0x5u; if (k) { goto L_06076BDA; } }  // 06076BCC bt/s 0x06076BDA ; mov #5,r10
    c.r[10] = 0x0u; goto L_06076BDA;  // 06076BD0 bra 0x06076BDA ; mov #0,r10
L_06076BD4:
    { const bool k = c.t; c.r[10] = 0x14u; if (k) { goto L_06076BDA; } }  // 06076BD4 bt/s 0x06076BDA ; mov #20,r10
    c.r[10] = 0x0u;  // 06076BD8 mov #0,r10
L_06076BDA:
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[14]);  // 06076BDA mov.w @r14,r5
    c.r[4] = 0x0u;  // 06076BDC mov #0,r4
    c.r[9] = ld32(0x06076C40u);  // 06076BDE mov.l 0x06076C40,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06076BE4u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076BE4u) return; }  // 06076BE0 jsr @r9 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06076BE4 mov r0,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06076BE6 extu.w r1,r6
    c.r[1] = ld32(0x06076C44u);  // 06076BE8 mov.l 0x06076C44,r1
    c.t = c.r[6] == c.r[1];  // 06076BEA cmp/eq r1,r6
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06076C4C; } }  // 06076BEC bt/s 0x06076C4C ; mov r14,r1
    c.r[1] = ld32(0x06076C34u);  // 06076BF0 mov.l 0x06076C34,r1
    c.r[2] = ld32(c.r[1]);  // 06076BF2 mov.l @r1,r2
    c.r[1] = c.r[6];  // 06076BF4 mov r6,r1
    c.r[1] <<= 2;  // 06076BF6 shll2 r1
    c.r[2] += c.r[1];  // 06076BF8 add r1,r2
    c.r[2] += 22;  // 06076BFA add #22,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076BFC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06076BFE extu.b r1,r1
    c.r[0] = c.r[1];  // 06076C00 mov r1,r0
    c.r[0] >>= 2;  // 06076C02 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06076C04 shlr r0
    c.r[0] >>= 2;  // 06076C06 shlr2 r0
    c.r[0] &= 0x1u;  // 06076C08 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06076C0A tst r0,r0
    { const bool k = !c.t; c.r[1] >>= 2; if (k) { goto L_06076C1E; } }  // 06076C0C bf/s 0x06076C1E ; shlr2 r1
    c.r[1] >>= 2;  // 06076C10 shlr2 r1
    c.r[1] >>= 2;  // 06076C12 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076C14 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { goto L_06076C1E; } }  // 06076C16 bf/s 0x06076C1E ; mov r6,r0
    c.t = c.r[0] == 0x4u;  // 06076C1A cmp/eq #4,r0
    if (!c.t) { goto L_06076C48; }  // 06076C1C bf 0x06076C48
L_06076C1E:
    c.r[0] = 0x64u;  // 06076C1E mov #100,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076C28u);  // 06076C20 mov.w 0x06076C28,r9
    c.r[9] += c.r[14];  // 06076C22 add r14,r9
    st32(c.r[9], c.r[0]); goto L_06076C4A;  // 06076C24 bra 0x06076C4A ; mov.l r0,@r9
L_06076C48:
    c.r[10] = 0xFFFFFFCEu;  // 06076C48 mov #-50,r10
L_06076C4A:
    c.r[1] = c.r[14];  // 06076C4A mov r14,r1
L_06076C4C:
    c.r[1] += 26;  // 06076C4C add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076C4E mov.w @r1,r5
    c.r[3] = c.r[5] & 0xFFFFu;  // 06076C50 extu.w r5,r3
    c.macl = c.r[3] * c.r[11];  // 06076C52 mul.l r11,r3
    c.r[1] = ld32(0x06076D2Cu);  // 06076C54 mov.l 0x06076D2C,r1
    c.r[2] = c.macl;  // 06076C56 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06076C58 dmuls.l r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076D22u);  // 06076C5A mov.w 0x06076D22,r9
    c.r[6] = c.mach;  // 06076C5C sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076C5E shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076C60 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076C62 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076C64 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076C66 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06076C68 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06076C6A subc r2,r2
    c.r[6] -= c.r[2];  // 06076C6C sub r2,r6
    c.r[1] = ld32(0x06076D30u);  // 06076C6E mov.l 0x06076D30,r1
    c.r[2] = ld32(c.r[1]);  // 06076C70 mov.l @r1,r2
    c.r[9] += c.r[14];  // 06076C72 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06076C74 mov.l @r9,r9
    c.r[1] = 0x1Eu;  // 06076C76 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 06076C78 mul.l r1,r9
    c.r[7] = c.macl;  // 06076C7A sts macl,r7
    c.r[7] += c.r[2];  // 06076C7C add r2,r7
    c.r[7] += 22;  // 06076C7E add #22,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06076C80 mov.w @r7,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06076C82 extu.w r2,r1
    c.r[1] += c.r[6];  // 06076C84 add r6,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06076C86 cmp/gt r3,r1
    if (!c.t) { goto L_06076C90; }  // 06076C88 bf 0x06076C90
    st16(c.r[7], c.r[5]);  // 06076C8A mov.w r5,@r7
    c.r[1] = c.r[14]; goto L_06076C96;  // 06076C8C bra 0x06076C96 ; mov r14,r1
L_06076C90:
    c.r[6] += c.r[2];  // 06076C90 add r2,r6
    st16(c.r[7], c.r[6]);  // 06076C92 mov.w r6,@r7
    c.r[1] = c.r[14];  // 06076C94 mov r14,r1
L_06076C96:
    c.r[1] += 28;  // 06076C96 add #28,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076D24u);  // 06076C98 mov.w 0x06076D24,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076C9A mov.w @r1,r5
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06076C9C mov.l @(r0,r14),r0
    c.r[7] = c.r[5] & 0xFFFFu;  // 06076C9E extu.w r5,r7
    c.macl = c.r[7] * c.r[0];  // 06076CA0 mul.l r0,r7
    c.r[1] = ld32(0x06076D2Cu);  // 06076CA2 mov.l 0x06076D2C,r1
    c.r[2] = c.macl;  // 06076CA4 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06076CA6 dmuls.l r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06076D22u);  // 06076CA8 mov.w 0x06076D22,r9
    c.r[6] = c.mach;  // 06076CAA sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076CAC shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076CAE shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076CB0 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076CB2 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06076CB4 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06076CB6 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06076CB8 subc r2,r2
    c.r[6] -= c.r[2];  // 06076CBA sub r2,r6
    c.r[1] = ld32(0x06076D30u);  // 06076CBC mov.l 0x06076D30,r1
    c.r[2] = ld32(c.r[1]);  // 06076CBE mov.l @r1,r2
    c.r[9] += c.r[14];  // 06076CC0 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06076CC2 mov.l @r9,r9
    c.r[1] = 0x1Eu;  // 06076CC4 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 06076CC6 mul.l r1,r9
    c.r[3] = c.macl;  // 06076CC8 sts macl,r3
    c.r[3] += c.r[2];  // 06076CCA add r2,r3
    c.r[3] += 24;  // 06076CCC add #24,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06076CCE mov.w @r3,r2
    c.r[6] += c.r[10];  // 06076CD0 add r10,r6
    c.r[1] = c.r[2] & 0xFFFFu;  // 06076CD2 extu.w r2,r1
    c.r[1] += c.r[6];  // 06076CD4 add r6,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06076CD6 cmp/pz r1
    { const bool k = c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[7]; if (k) { goto L_06076CE2; } }  // 06076CD8 bt/s 0x06076CE2 ; cmp/gt r7,r1
    c.r[1] = 0x0u;  // 06076CDC mov #0,r1
    st16(c.r[3], c.r[1]); goto L_06076CEE;  // 06076CDE bra 0x06076CEE ; mov.w r1,@r3
L_06076CE2:
    if (!c.t) { goto L_06076CEA; }  // 06076CE2 bf 0x06076CEA
    st16(c.r[3], c.r[5]);  // 06076CE4 mov.w r5,@r3
    goto L_06076CEE;  // 06076CE6 bra 0x06076CEE ; nop
L_06076CEA:
    c.r[6] += c.r[2];  // 06076CEA add r2,r6
    st16(c.r[3], c.r[6]);  // 06076CEC mov.w r6,@r3
L_06076CEE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076D26u);  // 06076CEE mov.w 0x06076D26,r0
    c.r[0] += c.r[14];  // 06076CF0 add r14,r0
    c.r[9] = ld32(c.r[0]);  // 06076CF2 mov.l @r0,r9
    c.r[9] += 1;  // 06076CF4 add #1,r9
    st32(c.r[0], c.r[9]);  // 06076CF6 mov.l r9,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076D26u);  // 06076CF8 mov.w 0x06076D26,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06076CFA mov.l @(r0,r14),r0
    c.r[1] = 0x49u;  // 06076CFC mov #73,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06076CFE cmp/gt r1,r0
    { const bool k = c.t; c.r[13] += 16; if (k) { goto L_06076D08; } }  // 06076D00 bt/s 0x06076D08 ; add #16,r13
    SH2_POLL(c); goto L_060769EA;  // 06076D04 bra 0x060769EA ; nop
L_06076D08:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06076D28u);  // 06076D08 mov.w 0x06076D28,r3
    c.r[14] += c.r[3];  // 06076D0A add r3,r14
    c.r[15] = c.r[14];  // 06076D0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076D0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06076D10 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06076D12 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06076D14 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06076D16 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06076D18 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06076D1A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076D2Au);  // 06076D1C mov.w 0x06076D2A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076D1E rts ; mov.l @r15+,r8
}

void f_06076D34(SH2Context& c) {
    ran[1649] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076D34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076D36 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076D38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06076D3A sts.l pr,@-r15
    c.r[9] = ld32(0x06076DA0u);  // 06076D3C mov.l 0x06076DA0,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06076D3E mov.b @r9,r1
    c.r[14] = c.r[15];  // 06076D40 mov r15,r14
    c.r[4] = c.r[1] & 0xFFu;  // 06076D42 extu.b r1,r4
    c.r[1] = ld32(0x06076DA4u);  // 06076D44 mov.l 0x06076DA4,r1
    c.r[2] = ld32(c.r[1]);  // 06076D46 mov.l @r1,r2
    c.r[1] = c.r[4];  // 06076D48 mov r4,r1
    c.r[1] <<= 2;  // 06076D4A shll2 r1
    c.r[1] <<= 2;  // 06076D4C shll2 r1
    c.r[3] = c.r[1];  // 06076D4E mov r1,r3
    c.r[0] = c.r[1];  // 06076D50 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06076D52 mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 06076D54 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06076D56 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06076D9Au);  // 06076D58 mov.w 0x06076D9A,r2
    c.t = c.r[1] == c.r[2];  // 06076D5A cmp/eq r2,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06076D84; } }  // 06076D5C bt/s 0x06076D84 ; mov #0,r8
    c.r[3] += 7;  // 06076D60 add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06076D62 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06076D64 mov r1,r0
    c.r[0] >>= 2;  // 06076D66 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06076D68 shlr r0
    c.r[0] &= 0x1u;  // 06076D6A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06076D6C tst r0,r0
    if (!c.t) { goto L_06076D84; }  // 06076D6E bf 0x06076D84
    c.r[0] = ld32(0x06076DA8u);  // 06076D70 mov.l 0x06076DA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06076D76u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076D76u) return; }  // 06076D72 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 06076D76 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076D78 tst r1,r1
    if (!c.t) { goto L_06076D84; }  // 06076D7A bf 0x06076D84
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06076D7C mov.b @r9,r1
    c.r[2] = ld32(0x06076DACu);  // 06076D7E mov.l 0x06076DAC,r2
    c.r[8] = 0x1u;  // 06076D80 mov #1,r8
    st8(c.r[2], c.r[1]);  // 06076D82 mov.b r1,@r2
L_06076D84:
    c.r[8] += c.r[8];  // 06076D84 add r8,r8
    c.r[8] += 1;  // 06076D86 add #1,r8
    c.r[15] = c.r[14];  // 06076D88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076D8A lds.l @r15+,pr
    c.r[1] = (uint32_t)(int16_t)ld16(0x06076D9Cu);  // 06076D8C mov.w 0x06076D9C,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06076D8E mov.l @r15+,r14
    c.r[8] |= c.r[1];  // 06076D90 or r1,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06076D92 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06076D94 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076D96 rts ; mov.l @r15+,r8
}

void f_06076DB0(SH2Context& c) {
    ran[1650] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076DB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076DB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06076DB4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06076DB6 mov r15,r14
    c.r[8] = ld32(0x06076E0Cu);  // 06076DB8 mov.l 0x06076E0C,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06076DBA mov.b @r8,r4
    c.r[1] = ld32(0x06076E10u);  // 06076DBC mov.l 0x06076E10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06076DC2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076DC2u) return; }  // 06076DBE jsr @r1 ; extu.b r4,r4
    c.r[6] = ld32(0x06076E14u);  // 06076DC2 mov.l 0x06076E14,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06076DC4 mov.b @r8,r1
    c.r[7] = ld32(0x06076E18u);  // 06076DC6 mov.l 0x06076E18,r7
    c.r[3] = ld32(c.r[7]);  // 06076DC8 mov.l @r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06076DCA extu.b r1,r1
    c.r[1] <<= 2;  // 06076DCC shll2 r1
    c.r[1] <<= 2;  // 06076DCE shll2 r1
    c.r[2] = c.r[1];  // 06076DD0 mov r1,r2
    c.r[2] += c.r[3];  // 06076DD2 add r3,r2
    c.r[2] += 1;  // 06076DD4 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076DD6 mov.b @r2,r2
    c.r[0] = c.r[1];  // 06076DD8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06076DDA mov.b @(r0,r3),r1
    c.r[2] = c.r[2] & 0xFFu;  // 06076DDC extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06076DDE extu.b r1,r1
    c.r[3] = ld32(c.r[6]);  // 06076DE0 mov.l @r6,r3
    c.r[2] <<= 2;  // 06076DE2 shll2 r2
    c.r[2] <<= 2;  // 06076DE4 shll2 r2
    c.r[2] <<= 2;  // 06076DE6 shll2 r2
    c.r[2] += c.r[3];  // 06076DE8 add r3,r2
    c.r[3] = 0xFFFFFFFFu;  // 06076DEA mov #-1,r3
    c.r[0] = c.r[2];  // 06076DEC mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 06076DEE mov.b r3,@(r0,r1)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06076DF0 mov.b @r8,r1
    c.r[15] = c.r[14];  // 06076DF2 mov r14,r15
    c.r[2] = ld32(c.r[7]);  // 06076DF4 mov.l @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06076DF6 extu.b r1,r1
    c.r[1] <<= 2;  // 06076DF8 shll2 r1
    c.r[1] <<= 2;  // 06076DFA shll2 r1
    c.r[0] = c.r[1];  // 06076DFC mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06076DFE mov.b r3,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06076E00 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06076E02 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076E0Au);  // 06076E04 mov.w 0x06076E0A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06076E06 rts ; mov.l @r15+,r8
}

void f_06076E1C(SH2Context& c) {
    ran[1651] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06076E1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06076E1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06076E20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06076E22 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06076E24 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06076E26 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06076E28 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06076E2A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06076F50u);  // 06076E2C mov.w 0x06076F50,r3
    c.r[15] += c.r[3];  // 06076E2E add r3,r15
    c.r[14] = c.r[15];  // 06076E30 mov r15,r14
    c.r[7] = ld32(0x06076F5Cu);  // 06076E32 mov.l 0x06076F5C,r7
    c.r[13] = 0x0u;  // 06076E34 mov #0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076F52u);  // 06076E36 mov.w 0x06076F52,r0
    c.r[0] += c.r[14];  // 06076E38 add r14,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x06076F54u);  // 06076E3A mov.w 0x06076F54,r6
    c.r[3] = c.r[14];  // 06076E3C mov r14,r3
    c.r[3] += c.r[6];  // 06076E3E add r6,r3
    c.r[2] = 0x0u;  // 06076E40 mov #0,r2
    c.r[11] = 0x0u;  // 06076E42 mov #0,r11
    c.r[1] = ld32(c.r[7]);  // 06076E44 mov.l @r7,r1
    c.r[9] = c.r[6];  // 06076E46 mov r6,r9
    c.r[1] += 18;  // 06076E48 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076E4A mov.w @r1,r1
    c.r[12] = 0x0u;  // 06076E4C mov #0,r12
    c.r[8] = c.r[1];  // 06076E4E mov r1,r8
    c.r[8] <<= 16;  // 06076E50 shll16 r8
    c.r[8] <<= 2;  // 06076E52 shll2 r8
    c.r[8] += c.r[8];  // 06076E54 add r8,r8
    c.r[8] <<= 2;  // 06076E56 shll2 r8
    c.r[8] >>= 16;  // 06076E58 shlr16 r8
    c.r[8] <<= 2;  // 06076E5A shll2 r8
    c.r[8] >>= 8;  // 06076E5C shlr8 r8
    st32(c.r[0], c.r[13]);  // 06076E5E mov.l r13,@r0
    c.r[1] = 0xFFFFFFFDu;  // 06076E60 mov #-3,r1
    c.r[0] = c.r[14];  // 06076E62 mov r14,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06076E64 mov.b r1,@(r0,r6)
    c.r[1] = c.r[3];  // 06076E66 mov r3,r1
    c.r[1] += 1;  // 06076E68 add #1,r1
    st8(c.r[1], c.r[2]);  // 06076E6A mov.b r2,@r1
    c.r[1] = c.r[3];  // 06076E6C mov r3,r1
    c.r[1] += 2;  // 06076E6E add #2,r1
    st8(c.r[1], c.r[2]);  // 06076E70 mov.b r2,@r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06076F56u);  // 06076E72 mov.w 0x06076F56,r13
    c.r[13] += c.r[14];  // 06076E74 add r14,r13
    st32(c.r[13], c.r[3]);  // 06076E76 mov.l r3,@r13
    c.r[10] = c.r[1];  // 06076E78 mov r1,r10
L_06076E7A:
    c.r[0] = ld32(0x06076F60u);  // 06076E7A mov.l 0x06076F60,r0
    c.r[1] = ld32(c.r[0]);  // 06076E7C mov.l @r0,r1
    c.r[5] = c.r[12];  // 06076E7E mov r12,r5
    c.r[5] += c.r[1];  // 06076E80 add r1,r5
    c.r[0] = c.r[12];  // 06076E82 mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06076E84 mov.b @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06076F58u);  // 06076E86 mov.w 0x06076F58,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06076E88 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06076E8A cmp/eq r6,r1
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_06076E94; } }  // 06076E8C bf/s 0x06076E94 ; mov r5,r1
    goto L_060770D8;  // 06076E90 bra 0x060770D8 ; nop
L_06076E94:
    c.r[1] += 7;  // 06076E94 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076E96 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06076E98 mov r1,r0
    c.r[0] >>= 2;  // 06076E9A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06076E9C shlr r0
    c.r[0] &= 0x1u;  // 06076E9E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06076EA0 tst r0,r0
    { const bool k = c.t; c.r[5] += 2; if (k) { goto L_06076EAA; } }  // 06076EA2 bt/s 0x06076EAA ; add #2,r5
    goto L_060770D8;  // 06076EA6 bra 0x060770D8 ; nop
L_06076EAA:
    c.r[1] = ld32(0x06076F64u);  // 06076EAA mov.l 0x06076F64,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06076EAC mov.b @r5,r5
    c.r[4] = c.r[14];  // 06076EAE mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06076EB4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076EB4u) return; }  // 06076EB0 jsr @r1 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06076F5Au);  // 06076EB4 mov.w 0x06076F5A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06076EB6 mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 06076EB8 mov r1,r0
    c.r[0] >>= 2;  // 06076EBA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06076EBC shlr r0
    c.r[0] &= 0x1u;  // 06076EBE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06076EC0 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06076ECA; } }  // 06076EC2 bf/s 0x06076ECA ; mov r14,r1
    goto L_060770D8;  // 06076EC6 bra 0x060770D8 ; nop
L_06076ECA:
    c.r[1] += 22;  // 06076ECA add #22,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076ECC mov.w @r1,r2
    c.r[1] = 0x64u;  // 06076ECE mov #100,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06076ED0 mulu.w r1,r2
    c.r[7] = ld32(0x06076F68u);  // 06076ED2 mov.l 0x06076F68,r7
    c.r[1] = c.r[14];  // 06076ED4 mov r14,r1
    c.r[1] += 26;  // 06076ED6 add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076ED8 mov.w @r1,r5
    c.r[4] = c.macl;  // 06076EDA sts macl,r4
    { const uint32_t x = c.r[7]; c.pr = 0x06076EE0u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06076EE0u) return; }  // 06076EDC jsr @r7 ; extu.w r5,r5
    c.r[4] = c.r[0] & 0xFFu;  // 06076EE0 extu.b r0,r4
    c.r[1] = 0x4Bu;  // 06076EE2 mov #75,r1
    c.t = c.r[4] > c.r[1];  // 06076EE4 cmp/hi r1,r4
    { const bool k = c.t; c.r[1] = 0x63u; if (k) { goto L_06076F2C; } }  // 06076EE6 bt/s 0x06076F2C ; mov #99,r1
    c.r[1] = 0x32u;  // 06076EEA mov #50,r1
    c.t = c.r[4] > c.r[1];  // 06076EEC cmp/hi r1,r4
    { const bool k = c.t; c.r[1] = 0xFFFFFFFEu; if (k) { goto L_06076F22; } }  // 06076EEE bt/s 0x06076F22 ; mov #-2,r1
    c.r[1] = 0x19u;  // 06076EF2 mov #25,r1
    c.t = c.r[4] > c.r[1];  // 06076EF4 cmp/hi r1,r4
    { const bool k = c.t; c.r[1] = 0x5u; if (k) { goto L_06076F0E; } }  // 06076EF6 bt/s 0x06076F0E ; mov #5,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06076F56u);  // 06076EFA mov.w 0x06076F56,r13
    c.r[13] += c.r[14];  // 06076EFC add r14,r13
    c.r[2] = ld32(c.r[13]);  // 06076EFE mov.l @r13,r2
    c.r[2] += 1;  // 06076F00 add #1,r2
    c.r[1] = 0xAu;  // 06076F02 mov #10,r1
    st8(c.r[10], c.r[1]);  // 06076F04 mov.b r1,@r10
    st8(c.r[2], c.r[1]);  // 06076F06 mov.b r1,@r2
    c.r[0] = c.r[14];  // 06076F08 mov r14,r0
    st8(c.r[0] + c.r[9], c.r[1]); goto L_06076F2A;  // 06076F0A bra 0x06076F2A ; mov.b r1,@(r0,r9)
L_06076F0E:
    c.r[0] = c.r[14];  // 06076F0E mov r14,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06076F10 mov.b r1,@(r0,r9)
    c.r[13] = (uint32_t)(int16_t)ld16(0x06076F56u);  // 06076F12 mov.w 0x06076F56,r13
    c.r[13] += c.r[14];  // 06076F14 add r14,r13
    c.r[2] = ld32(c.r[13]);  // 06076F16 mov.l @r13,r2
    c.r[1] = 0xAu;  // 06076F18 mov #10,r1
    c.r[2] += 1;  // 06076F1A add #1,r2
    st8(c.r[10], c.r[1]);  // 06076F1C mov.b r1,@r10
    st8(c.r[2], c.r[1]); goto L_06076F2A;  // 06076F1E bra 0x06076F2A ; mov.b r1,@r2
L_06076F22:
    c.r[0] = c.r[14];  // 06076F22 mov r14,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06076F24 mov.b r1,@(r0,r9)
    c.r[1] = 0x3u;  // 06076F26 mov #3,r1
    st8(c.r[10], c.r[1]);  // 06076F28 mov.b r1,@r10
L_06076F2A:
    c.r[1] = 0x63u;  // 06076F2A mov #99,r1
L_06076F2C:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06076F2C cmp/gt r1,r8
    { const bool k = c.t; c.r[1] = 0x31u; if (k) { goto L_06076F6C; } }  // 06076F2E bt/s 0x06076F6C ; mov #49,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06076F32 cmp/gt r1,r8
    if (c.t) { goto L_06076F3C; }  // 06076F34 bt 0x06076F3C
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06076F36 mov.b @r10,r1
    c.r[1] += c.r[8]; goto L_06076F72;  // 06076F38 bra 0x06076F72 ; add r8,r1
L_06076F3C:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06076F56u);  // 06076F3C mov.w 0x06076F56,r13
    c.r[13] += c.r[14];  // 06076F3E add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06076F40 mov.l @r13,r0
    c.r[0] += 1;  // 06076F42 add #1,r0
    st32(c.r[13], c.r[0]);  // 06076F44 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06076F56u);  // 06076F46 mov.w 0x06076F56,r13
    c.r[13] += c.r[14];  // 06076F48 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06076F4A mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); goto L_06076F70;  // 06076F4C bra 0x06076F70 ; mov.b @r0,r1
L_06076F6C:
    c.r[0] = c.r[14];  // 06076F6C mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06076F6E mov.b @(r0,r9),r1
L_06076F70:
    c.r[1] += c.r[8];  // 06076F70 add r8,r1
L_06076F72:
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06076F72 exts.w r1,r8
    c.r[13] = ld32(0x060770C4u);  // 06076F74 mov.l 0x060770C4,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x060770B6u);  // 06076F76 mov.w 0x060770B6,r1
    c.r[2] = c.r[8];  // 06076F78 mov r8,r2
    c.r[2] &= c.r[1];  // 06076F7A and r1,r2
    c.r[2] += c.r[2];  // 06076F7C add r2,r2
    c.r[3] = ld32(c.r[13]);  // 06076F7E mov.l @r13,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060770B8u);  // 06076F80 mov.w 0x060770B8,r7
    c.r[3] += 18;  // 06076F82 add #18,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06076F84 mov.w @r3,r1
    c.t = (int32_t)c.r[8] >= 0;  // 06076F86 cmp/pz r8
    c.r[1] &= c.r[7];  // 06076F88 and r7,r1
    c.r[1] |= c.r[2];  // 06076F8A or r2,r1
    { const bool k = c.t; st16(c.r[3], c.r[1]); if (k) { goto L_06076F94; } }  // 06076F8C bt/s 0x06076F94 ; mov.w r1,@r3
    c.r[1] &= c.r[7];  // 06076F90 and r7,r1
    st16(c.r[3], c.r[1]);  // 06076F92 mov.w r1,@r3
L_06076F94:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060770BAu);  // 06076F94 mov.w 0x060770BA,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06076F96 cmp/gt r1,r8
    if (!c.t) { goto L_06076FAA; }  // 06076F98 bf 0x06076FAA
    c.r[0] = ld32(0x060770C4u);  // 06076F9A mov.l 0x060770C4,r0
    c.r[3] = ld32(c.r[0]);  // 06076F9C mov.l @r0,r3
    c.r[3] += 18;  // 06076F9E add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06076FA0 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060770BCu);  // 06076FA2 mov.w 0x060770BC,r1
    c.r[2] &= c.r[7];  // 06076FA4 and r7,r2
    c.r[2] |= c.r[1];  // 06076FA6 or r1,r2
    st16(c.r[3], c.r[2]);  // 06076FA8 mov.w r2,@r3
L_06076FAA:
    c.r[13] = ld32(0x060770C8u);  // 06076FAA mov.l 0x060770C8,r13
    c.r[2] = ld32(c.r[13]);  // 06076FAC mov.l @r13,r2
    c.r[2] += c.r[12];  // 06076FAE add r12,r2
    c.r[1] = c.r[2];  // 06076FB0 mov r2,r1
    c.r[1] += 4;  // 06076FB2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076FB4 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06076FB6 mov #1,r0
    c.r[1] >>= 2;  // 06076FB8 shlr2 r1
    c.r[1] >>= 2;  // 06076FBA shlr2 r1
    c.r[1] >>= 2;  // 06076FBC shlr2 r1
    c.r[1] &= c.r[0];  // 06076FBE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06076FC0 tst r1,r1
    { const bool k = c.t; c.r[2] += 2; if (k) { goto L_06076FCA; } }  // 06076FC2 bt/s 0x06076FCA ; add #2,r2
    goto L_060770E6;  // 06076FC6 bra 0x060770E6 ; nop
L_06076FCA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06076FCA mov.b @r2,r1
    c.r[9] = 0x1Eu;  // 06076FCC mov #30,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06076FCE extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 06076FD0 mul.l r9,r1
    c.r[10] = ld32(0x060770CCu);  // 06076FD2 mov.l 0x060770CC,r10
    c.r[2] = ld32(c.r[10]);  // 06076FD4 mov.l @r10,r2
    c.r[1] = c.macl;  // 06076FD6 sts macl,r1
    c.r[1] += c.r[2];  // 06076FD8 add r2,r1
    c.r[1] += 15;  // 06076FDA add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06076FDC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06076FDE extu.b r2,r2
    c.r[1] = ld32(0x060770D0u);  // 06076FE0 mov.l 0x060770D0,r1
    c.r[0] = c.r[2];  // 06076FE2 mov r2,r0
    c.r[0] += c.r[0];  // 06076FE4 add r0,r0
    c.r[0] += c.r[2];  // 06076FE6 add r2,r0
    c.r[1] = ld32(c.r[1]);  // 06076FE8 mov.l @r1,r1
    c.r[0] <<= 2;  // 06076FEA shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06076FEC mov.w @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060770BEu);  // 06076FEE mov.w 0x060770BE,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06076FF0 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06076FF2 cmp/eq r2,r1
    if (!c.t) { goto L_0607704A; }  // 06076FF4 bf 0x0607704A
    c.r[13] = ld32(0x060770C4u);  // 06076FF6 mov.l 0x060770C4,r13
    c.r[1] = ld32(c.r[13]);  // 06076FF8 mov.l @r13,r1
    c.r[1] += 18;  // 06076FFA add #18,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06076FFC mov.w @r1,r8
    c.r[11] = ld32(0x060770D4u);  // 06076FFE mov.l 0x060770D4,r11
    c.r[8] = c.r[8] & 0xFFFFu;  // 06077000 extu.w r8,r8
    { const uint32_t x = c.r[11]; c.pr = 0x06077006u; c.t = c.r[8] & 1; c.r[8] >>= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077006u) return; }  // 06077002 jsr @r11 ; shlr r8
    c.r[1] = c.r[0];  // 06077006 mov r0,r1
    c.r[10] = 0x15u;  // 06077008 mov #21,r10
    c.macl = c.r[1] * c.r[10];  // 0607700A mul.l r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x060770B6u);  // 0607700C mov.w 0x060770B6,r9
    c.r[8] &= c.r[9];  // 0607700E and r9,r8
    c.r[1] = c.macl;  // 06077010 sts macl,r1
    c.r[1] >>= 16;  // 06077012 shlr16 r1
    c.r[1] += 90;  // 06077014 add #90,r1
    c.t = c.r[8] > c.r[1];  // 06077016 cmp/hi r1,r8
    { const bool k = c.t; c.r[13] = 0x2u; if (k) { goto L_06077020; } }  // 06077018 bt/s 0x06077020 ; mov #2,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060770C0u);  // 0607701C mov.w 0x060770C0,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0607701E mov.l r13,@(r0,r14)
L_06077020:
    c.r[0] = ld32(0x060770C4u);  // 06077020 mov.l 0x060770C4,r0
    c.r[1] = ld32(c.r[0]);  // 06077022 mov.l @r0,r1
    c.r[1] += 18;  // 06077024 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06077026 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06077028 extu.w r1,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607702A shlr r1
    { const uint32_t x = c.r[11]; c.pr = 0x06077030u; c.r[9] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077030u) return; }  // 0607702C jsr @r11 ; and r1,r9
    c.r[1] = c.r[0];  // 06077030 mov r0,r1
    c.macl = c.r[1] * c.r[10];  // 06077032 mul.l r10,r1
    c.r[2] = c.macl;  // 06077034 sts macl,r2
    c.r[2] >>= 16;  // 06077036 shlr16 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060770C2u);  // 06077038 mov.w 0x060770C2,r1
    c.r[2] += c.r[1];  // 0607703A add r1,r2
    c.t = c.r[9] >= c.r[2];  // 0607703C cmp/hs r2,r9
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_060770E6; } }  // 0607703E bf/s 0x060770E6 ; mov #3,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060770C0u);  // 06077042 mov.w 0x060770C0,r13
    c.r[13] += c.r[14];  // 06077044 add r14,r13
    st32(c.r[13], c.r[0]); goto L_060770E6;  // 06077046 bra 0x060770E6 ; mov.l r0,@r13
L_0607704A:
    c.r[13] = ld32(0x060770C4u);  // 0607704A mov.l 0x060770C4,r13
    c.r[1] = ld32(c.r[13]);  // 0607704C mov.l @r13,r1
    c.r[1] += 18;  // 0607704E add #18,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06077050 mov.w @r1,r8
    c.r[0] = ld32(0x060770D4u);  // 06077052 mov.l 0x060770D4,r0
    c.r[8] <<= 16;  // 06077054 shll16 r8
    c.r[8] <<= 2;  // 06077056 shll2 r8
    c.r[8] += c.r[8];  // 06077058 add r8,r8
    c.r[8] <<= 2;  // 0607705A shll2 r8
    c.r[8] >>= 16;  // 0607705C shlr16 r8
    c.r[8] <<= 2;  // 0607705E shll2 r8
    { const uint32_t x = c.r[0]; c.pr = 0x06077064u; c.r[8] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077064u) return; }  // 06077060 jsr @r0 ; shlr8 r8
    c.r[2] = c.r[0];  // 06077064 mov r0,r2
    c.r[1] = 0x15u;  // 06077066 mov #21,r1
    c.macl = c.r[2] * c.r[1];  // 06077068 mul.l r1,r2
    c.r[1] = c.macl;  // 0607706A sts macl,r1
    c.r[1] >>= 16;  // 0607706C shlr16 r1
    c.r[1] += 110;  // 0607706E add #110,r1
    c.t = c.r[8] >= c.r[1];  // 06077070 cmp/hs r1,r8
    if (!c.t) { goto L_060770E6; }  // 06077072 bf 0x060770E6
    c.r[13] = ld32(0x060770C8u);  // 06077074 mov.l 0x060770C8,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060770C0u);  // 06077076 mov.w 0x060770C0,r0
    c.r[1] = ld32(c.r[13]);  // 06077078 mov.l @r13,r1
    c.r[0] += c.r[14];  // 0607707A add r14,r0
    c.r[12] += c.r[1];  // 0607707C add r1,r12
    c.r[12] += 2;  // 0607707E add #2,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x060770C0u);  // 06077080 mov.w 0x060770C0,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06077082 mov.b @r12,r1
    c.r[13] += c.r[14];  // 06077084 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06077086 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06077088 mov.l r1,@r0
    c.r[13] = ld32(c.r[13]);  // 0607708A mov.l @r13,r13
    c.macl = c.r[13] * c.r[9];  // 0607708C mul.l r9,r13
    c.r[1] = ld32(c.r[10]);  // 0607708E mov.l @r10,r1
    c.r[7] = c.macl;  // 06077090 sts macl,r7
    c.r[7] += c.r[1];  // 06077092 add r1,r7
    c.r[1] = c.r[14];  // 06077094 mov r14,r1
    c.r[1] += 26;  // 06077096 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06077098 mov.w @r1,r1
    c.r[7] += 22;  // 0607709A add #22,r7
    c.r[3] = c.r[1] & 0xFFFFu;  // 0607709C extu.w r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0607709E shlr r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060770A0 mov.w @r7,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 060770A2 extu.w r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060770A4 extu.w r1,r1
    c.t = c.r[1] >= c.r[2];  // 060770A6 cmp/hs r2,r1
    if (c.t) { goto L_060770AC; }  // 060770A8 bt 0x060770AC
    st16(c.r[7], c.r[3]);  // 060770AA mov.w r3,@r7
L_060770AC:
    c.r[13] = 0x1u;  // 060770AC mov #1,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060770C0u);  // 060770AE mov.w 0x060770C0,r0
    c.r[0] += c.r[14];  // 060770B0 add r14,r0
    st32(c.r[0], c.r[13]); goto L_060770E6;  // 060770B2 bra 0x060770E6 ; mov.l r13,@r0
L_060770D8:
    c.r[11] += 1;  // 060770D8 add #1,r11
    c.r[1] = 0x49u;  // 060770DA mov #73,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 060770DC cmp/gt r1,r11
    { const bool k = c.t; c.r[12] += 16; if (k) { goto L_060770E6; } }  // 060770DE bt/s 0x060770E6 ; add #16,r12
    SH2_POLL(c); goto L_06076E7A;  // 060770E2 bra 0x06076E7A ; nop
L_060770E6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077118u);  // 060770E6 mov.w 0x06077118,r0
    c.r[0] += c.r[14];  // 060770E8 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 060770EA mov.l @r0,r13
    c.r[13] += c.r[13];  // 060770EC add r13,r13
    st32(c.r[0], c.r[13]);  // 060770EE mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077118u);  // 060770F0 mov.w 0x06077118,r0
    c.r[0] += c.r[14];  // 060770F2 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 060770F4 mov.l @r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607711Au);  // 060770F6 mov.w 0x0607711A,r1
    c.r[13] |= c.r[1];  // 060770F8 or r1,r13
    st32(c.r[0], c.r[13]);  // 060770FA mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077118u);  // 060770FC mov.w 0x06077118,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060770FE mov.l @(r0,r14),r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607711Cu);  // 06077100 mov.w 0x0607711C,r3
    c.r[14] += c.r[3];  // 06077102 add r3,r14
    c.r[15] = c.r[14];  // 06077104 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06077106 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06077108 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607710A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607710C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607710E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06077110 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06077112 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06077114 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
