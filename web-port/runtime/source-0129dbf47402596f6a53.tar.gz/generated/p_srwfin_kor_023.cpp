#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_06058F18(SH2Context& c) {
    ran[1369] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058F18 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058F1A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058F1C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06058F1E mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06058F20 extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 06058F22 extu.b r5,r2
    c.r[4] = c.r[2];  // 06058F24 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 06058F26 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058F28 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06058F50; } }  // 06058F2A bf/s 0x06058F50 ; mov r0,r1
    c.r[1] = ld32(0x06058F9Cu);  // 06058F2E mov.l 0x06058F9C,r1
    c.r[1] = ld32(c.r[1]);  // 06058F30 mov.l @r1,r1
    c.r[2] <<= 2;  // 06058F32 shll2 r2
    c.r[2] <<= 2;  // 06058F34 shll2 r2
    c.r[2] += c.r[1];  // 06058F36 add r1,r2
    c.r[2] += 11;  // 06058F38 add #11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058F3A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058F3C extu.b r1,r1
    c.r[1] >>= 2;  // 06058F3E shlr2 r1
    c.r[1] >>= 2;  // 06058F40 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06058F42 shlr r1
    c.r[1] >>= 2;  // 06058F44 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058F46 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06058F8C; } }  // 06058F48 bf/s 0x06058F8C ; mov #1,r0
    c.r[15] = c.r[14]; goto L_06058F90;  // 06058F4C bra 0x06058F90 ; mov r14,r15
L_06058F50:
    c.r[0] = c.r[1];  // 06058F50 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06058F52 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_06058F6A; } }  // 06058F54 bf/s 0x06058F6A ; shll2 r2
    c.r[1] = ld32(0x06058F9Cu);  // 06058F58 mov.l 0x06058F9C,r1
    c.r[1] = ld32(c.r[1]);  // 06058F5A mov.l @r1,r1
    c.r[2] <<= 2;  // 06058F5C shll2 r2
    c.r[2] += c.r[1];  // 06058F5E add r1,r2
    c.r[2] += 11;  // 06058F60 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058F62 mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06058F64 or #128,r0
    st8(c.r[2], c.r[0]); goto L_06058F8C;  // 06058F66 bra 0x06058F8C ; mov.b r0,@r2
L_06058F6A:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06058F6A exts.w r4,r4
    c.r[1] = ld32(0x06058FA0u);  // 06058F6C mov.l 0x06058FA0,r1
    c.r[6] = 0x0u;  // 06058F6E mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06058F74u; c.r[5] = 0x23u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058F74u) return; }  // 06058F70 jsr @r1 ; mov #35,r5
    c.r[1] = ld32(0x06058FA4u);  // 06058F74 mov.l 0x06058FA4,r1
    c.r[2] = ld32(c.r[1]);  // 06058F76 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058F98u);  // 06058F78 mov.w 0x06058F98,r1
    c.r[2] += c.r[1];  // 06058F7A add r1,r2
    c.r[1] = ld32(0x06058FA8u);  // 06058F7C mov.l 0x06058FA8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058F7E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058F80 extu.w r1,r1
    c.r[1] <<= 2;  // 06058F82 shll2 r1
    c.r[1] += c.r[1];  // 06058F84 add r1,r1
    c.r[2] += c.r[1];  // 06058F86 add r1,r2
    c.r[2] += 4;  // 06058F88 add #4,r2
    st8(c.r[2], c.r[8]);  // 06058F8A mov.b r8,@r2
L_06058F8C:
    c.r[0] = 0x0u;  // 06058F8C mov #0,r0
    c.r[15] = c.r[14];  // 06058F8E mov r14,r15
L_06058F90:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06058F90 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06058F92 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058F94 rts ; mov.l @r15+,r8
}

void f_06058FAC(SH2Context& c) {
    ran[1370] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058FAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06058FAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06058FB0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06058FB2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058FB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058FB6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06058FB8 mov r15,r14
    c.r[10] = c.r[4] & 0xFFu;  // 06058FBA extu.b r4,r10
    c.r[0] = c.r[6] & 0xFFu;  // 06058FBC extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058FBE tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[5] & 0xFFu; if (k) { goto L_06059092; } }  // 06058FC0 bf/s 0x06059092 ; extu.b r5,r4
    c.r[9] = 0x0u;  // 06058FC4 mov #0,r9
L_06058FC6:
    c.r[1] = ld32(0x0605911Cu);  // 06058FC6 mov.l 0x0605911C,r1
    c.r[0] = c.r[9];  // 06058FC8 mov r9,r0
    c.r[0] <<= 2;  // 06058FCA shll2 r0
    c.r[0] <<= 2;  // 06058FCC shll2 r0
    c.r[8] = c.r[0];  // 06058FCE mov r0,r8
    c.r[7] = ld32(c.r[1]);  // 06058FD0 mov.l @r1,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x06059116u);  // 06058FD2 mov.w 0x06059116,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06058FD4 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058FD6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06058FD8 cmp/eq r2,r1
    { const bool k = c.t; c.r[8] += c.r[7]; if (k) { goto L_06059076; } }  // 06058FDA bt/s 0x06059076 ; add r7,r8
    c.r[1] = c.r[8];  // 06058FDE mov r8,r1
    c.r[1] += 7;  // 06058FE0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058FE2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06058FE4 mov r1,r0
    c.r[0] >>= 2;  // 06058FE6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06058FE8 shlr r0
    c.r[0] &= 0x1u;  // 06058FEA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058FEC tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06059076; } }  // 06058FEE bf/s 0x06059076 ; mov r8,r1
    c.r[1] += 2;  // 06058FF2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058FF4 mov.b @r1,r2
    c.r[1] = ld32(0x06059120u);  // 06058FF6 mov.l 0x06059120,r1
    c.r[3] = ld32(c.r[1]);  // 06058FF8 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06058FFA extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06058FFC mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06058FFE mul.l r1,r2
    c.r[1] = c.macl;  // 06059000 sts macl,r1
    c.r[1] += c.r[3];  // 06059002 add r3,r1
    c.r[1] += 15;  // 06059004 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059006 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06059008 extu.b r2,r2
    c.r[1] = ld32(0x06059124u);  // 0605900A mov.l 0x06059124,r1
    c.r[3] = c.r[2];  // 0605900C mov r2,r3
    c.r[3] += c.r[3];  // 0605900E add r3,r3
    c.r[3] += c.r[2];  // 06059010 add r2,r3
    c.r[1] = ld32(c.r[1]);  // 06059012 mov.l @r1,r1
    c.r[3] <<= 2;  // 06059014 shll2 r3
    c.r[3] += c.r[1];  // 06059016 add r1,r3
    c.r[3] += 9;  // 06059018 add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605901A mov.b @r3,r1
    c.r[2] = 0x32u;  // 0605901C mov #50,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605901E extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06059020 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06059076; } }  // 06059022 bf/s 0x06059076 ; mov r10,r1
    c.r[1] <<= 2;  // 06059026 shll2 r1
    c.r[1] <<= 2;  // 06059028 shll2 r1
    c.r[1] += c.r[7];  // 0605902A add r7,r1
    c.r[1] += 4;  // 0605902C add #4,r1
    c.r[11] = 0xFu;  // 0605902E mov #15,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059030 mov.b @r1,r1
    c.r[0] = ld32(0x06059128u);  // 06059032 mov.l 0x06059128,r0
    c.r[2] = c.r[1];  // 06059034 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06059036 shlr r2
    c.r[2] &= c.r[11];  // 06059038 and r11,r2
    c.r[1] = c.r[8];  // 0605903A mov r8,r1
    c.r[1] += 3;  // 0605903C add #3,r1
    c.r[11] = 0x3u;  // 0605903E mov #3,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059040 mov.b @r1,r1
    c.r[4] = c.r[2];  // 06059042 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06059044 shlr r1
    c.r[1] &= c.r[11];  // 06059046 and r11,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0605904Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605904Cu) return; }  // 06059048 jsr @r0 ; mov r1,r5
    c.r[0] &= 0x1u;  // 0605904C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605904E tst r0,r0
    { const bool k = c.t; c.r[8] += 4; if (k) { goto L_06059076; } }  // 06059050 bt/s 0x06059076 ; add #4,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06059054 mov.b @r8,r0
    c.r[0] &= 0x60u;  // 06059056 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059058 tst r0,r0
    if (!c.t) { goto L_06059076; }  // 0605905A bf 0x06059076
    c.r[1] = ld32(0x0605912Cu);  // 0605905C mov.l 0x0605912C,r1
    c.r[3] = ld32(c.r[1]);  // 0605905E mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059118u);  // 06059060 mov.w 0x06059118,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06059062 mov.b @(r0,r3),r2
    c.r[1] = c.r[2];  // 06059064 mov r2,r1
    c.r[1] += 1;  // 06059066 add #1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06059068 mov.b r1,@(r0,r3)
    c.r[2] = c.r[2] & 0xFFu;  // 0605906A extu.b r2,r2
    c.r[2] <<= 2;  // 0605906C shll2 r2
    c.r[2] += c.r[2];  // 0605906E add r2,r2
    c.r[3] += c.r[2];  // 06059070 add r2,r3
    c.r[3] += 4;  // 06059072 add #4,r3
    st8(c.r[3], c.r[9]);  // 06059074 mov.b r9,@r3
L_06059076:
    c.r[9] += 1;  // 06059076 add #1,r9
    c.r[1] = 0x49u;  // 06059078 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605907A cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06058FC6; }  // 0605907C bf 0x06058FC6
    c.r[1] = ld32(0x0605912Cu);  // 0605907E mov.l 0x0605912C,r1
    c.r[1] = ld32(c.r[1]);  // 06059080 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059118u);  // 06059082 mov.w 0x06059118,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06059084 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059086 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06059088 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06059106; } }  // 0605908A bt/s 0x06059106 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06059106;  // 0605908E bra 0x06059106 ; mov #1,r0
L_06059092:
    c.t = c.r[0] == 0x1u;  // 06059092 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_06059104; } }  // 06059094 bf/s 0x06059104 ; mov r4,r2
    c.r[1] = ld32(0x0605911Cu);  // 06059098 mov.l 0x0605911C,r1
    c.r[1] = ld32(c.r[1]);  // 0605909A mov.l @r1,r1
    c.r[2] <<= 2;  // 0605909C shll2 r2
    c.r[2] <<= 2;  // 0605909E shll2 r2
    c.r[2] += c.r[1];  // 060590A0 add r1,r2
    c.r[2] += 2;  // 060590A2 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060590A4 mov.b @r2,r2
    c.r[1] = ld32(0x06059120u);  // 060590A6 mov.l 0x06059120,r1
    c.r[3] = ld32(c.r[1]);  // 060590A8 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060590AA extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060590AC mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060590AE mul.l r1,r2
    c.r[1] = c.macl;  // 060590B0 sts macl,r1
    c.r[1] += c.r[3];  // 060590B2 add r3,r1
    c.r[1] += 15;  // 060590B4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060590B6 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060590B8 extu.b r1,r9
    c.r[1] = ld32(0x06059124u);  // 060590BA mov.l 0x06059124,r1
    c.r[2] = c.r[9];  // 060590BC mov r9,r2
    c.r[2] += c.r[2];  // 060590BE add r2,r2
    c.r[2] += c.r[9];  // 060590C0 add r9,r2
    c.r[1] = ld32(c.r[1]);  // 060590C2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060590C4 shll2 r2
    c.r[2] += c.r[1];  // 060590C6 add r1,r2
    c.r[2] += 9;  // 060590C8 add #9,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060590CA mov.b @r2,r3
    c.r[1] = 0x31u;  // 060590CC mov #49,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060590CE extu.b r3,r2
    c.r[2] -= 10;  // 060590D0 add #-10,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060590D2 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060590DE; } }  // 060590D4 bt/s 0x060590DE ; mov r3,r1
    c.r[1] -= 50;  // 060590D8 add #-50,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_060590E0;  // 060590DA bra 0x060590E0 ; extu.b r1,r1
L_060590DE:
    c.r[1] = 0xAu;  // 060590DE mov #10,r1
L_060590E0:
    c.r[6] = 0u - c.r[1];  // 060590E0 neg r1,r6
    c.r[4] += 74;  // 060590E2 add #74,r4
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060590E4 exts.w r4,r4
    c.r[1] = ld32(0x06059130u);  // 060590E6 mov.l 0x06059130,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060590ECu; c.r[5] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060590ECu) return; }  // 060590E8 jsr @r1 ; mov #36,r5
    c.r[1] = ld32(0x0605912Cu);  // 060590EC mov.l 0x0605912C,r1
    c.r[2] = ld32(c.r[1]);  // 060590EE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605911Au);  // 060590F0 mov.w 0x0605911A,r1
    c.r[2] += c.r[1];  // 060590F2 add r1,r2
    c.r[1] = ld32(0x06059134u);  // 060590F4 mov.l 0x06059134,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060590F6 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060590F8 extu.w r1,r1
    c.r[1] <<= 2;  // 060590FA shll2 r1
    c.r[1] += c.r[1];  // 060590FC add r1,r1
    c.r[2] += c.r[1];  // 060590FE add r1,r2
    c.r[2] += 4;  // 06059100 add #4,r2
    st8(c.r[2], c.r[10]);  // 06059102 mov.b r10,@r2
L_06059104:
    c.r[0] = 0x0u;  // 06059104 mov #0,r0
L_06059106:
    c.r[15] = c.r[14];  // 06059106 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06059108 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605910A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605910C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605910E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06059110 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06059112 rts ; mov.l @r15+,r8
}

void f_06059138(SH2Context& c) {
    ran[1371] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059138 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605913A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605913C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605913E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06059140 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06059142 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06059144 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06059146 sts.l pr,@-r15
    c.r[15] -= 56;  // 06059148 add #-56,r15
    c.r[14] = c.r[15];  // 0605914A mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 0605914C extu.b r4,r11
    c.r[2] = c.r[6] & 0xFFu;  // 0605914E extu.b r6,r2
    c.r[6] = c.r[2];  // 06059150 mov r2,r6
    c.r[1] = ld32(0x060592D0u);  // 06059152 mov.l 0x060592D0,r1
    c.r[3] = c.r[11];  // 06059154 mov r11,r3
    c.r[7] = ld32(c.r[1]);  // 06059156 mov.l @r1,r7
    c.r[3] <<= 2;  // 06059158 shll2 r3
    c.r[3] <<= 2;  // 0605915A shll2 r3
    c.r[3] += c.r[7];  // 0605915C add r7,r3
    c.r[1] = c.r[3];  // 0605915E mov r3,r1
    c.r[1] += 4;  // 06059160 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059162 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06059164 mov r1,r0
    c.r[0] >>= 2;  // 06059166 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06059168 shlr r0
    c.r[0] >>= 2;  // 0605916A shlr2 r0
    c.r[0] &= 0x1u;  // 0605916C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605916E tst r0,r0
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_0605917A; } }  // 06059170 bt/s 0x0605917A ; mov #0,r12
    c.r[3] += 6;  // 06059174 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06059176 mov.b @r3,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06059178 extu.b r1,r11
L_0605917A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605917A tst r2,r2
    { const bool k = !c.t; c.r[13] = c.r[11]; if (k) { goto L_06059184; } }  // 0605917C bf/s 0x06059184 ; mov r11,r13
    c.r[0] = 0x1u; goto L_0605944C;  // 06059180 bra 0x0605944C ; mov #1,r0
L_06059184:
    c.r[0] = c.r[2];  // 06059184 mov r2,r0
    c.t = c.r[0] == 0x1u;  // 06059186 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06059190; } }  // 06059188 bt/s 0x06059190 ; mov #0,r0
    goto L_0605944C;  // 0605918C bra 0x0605944C ; nop
L_06059190:
    c.r[1] = ld32(0x060592D4u);  // 06059190 mov.l 0x060592D4,r1
    c.r[2] = ld32(c.r[1]);  // 06059192 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060592C6u);  // 06059194 mov.w 0x060592C6,r1
    c.r[0] = c.r[2];  // 06059196 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06059198 mov.b @(r0,r1),r1
    c.r[0] = 0x2u;  // 0605919A mov #2,r0
    c.r[1] &= c.r[0];  // 0605919C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605919E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060591BA; } }  // 060591A0 bt/s 0x060591BA ; mov r11,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x060592C8u);  // 060591A4 mov.w 0x060592C8,r1
    c.r[0] = c.r[2];  // 060591A6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060591A8 mov.b @(r0,r1),r1
    c.r[0] = 0x1u;  // 060591AA mov #1,r0
    c.r[1] &= c.r[0];  // 060591AC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060591AE tst r1,r1
    { const bool k = !c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_060591B8; } }  // 060591B0 bf/s 0x060591B8 ; tst r12,r12
    goto L_0605932A;  // 060591B4 bra 0x0605932A ; nop
L_060591B8:
    c.r[1] = c.r[11];  // 060591B8 mov r11,r1
L_060591BA:
    c.r[1] <<= 2;  // 060591BA shll2 r1
    c.r[1] <<= 2;  // 060591BC shll2 r1
    c.r[2] = c.r[1];  // 060591BE mov r1,r2
    c.r[2] += c.r[7];  // 060591C0 add r7,r2
    c.r[0] = c.r[1];  // 060591C2 mov r1,r0
    c.r[2] += 1;  // 060591C4 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060591C6 mov.b @(r0,r7),r1
    c.r[8] = c.r[6];  // 060591C8 mov r6,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060591CA extu.b r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060591CC mov.l r1,@(48,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060591CE mov.b @r2,r1
    c.r[10] = ld32(0x060592D8u);  // 060591D0 mov.l 0x060592D8,r10
    c.r[1] = c.r[1] & 0xFFu;  // 060591D2 extu.b r1,r1
    st32(c.r[14] + 52, c.r[1]);  // 060591D4 mov.l r1,@(52,r14)
    c.r[2] = c.r[8];  // 060591D6 mov r8,r2
L_060591D8:
    c.r[2] >>= 2;  // 060591D8 shlr2 r2
    c.r[0] = 0x1u;  // 060591DA mov #1,r0
    c.r[2] &= c.r[0];  // 060591DC and r0,r2
    c.r[1] = c.r[8];  // 060591DE mov r8,r1
    c.r[0] = ld32(c.r[14] + 48);  // 060591E0 mov.l @(48,r14),r0
    c.r[1] >>= 2;  // 060591E2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060591E4 shlr r1
    c.r[2] += c.r[0];  // 060591E6 add r0,r2
    c.r[0] = 0x1u;  // 060591E8 mov #1,r0
    c.r[1] &= c.r[0];  // 060591EA and r0,r1
    c.r[2] -= c.r[1];  // 060591EC sub r1,r2
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 060591EE exts.b r2,r3
    c.r[2] = 0x1u;  // 060591F0 mov #1,r2
    c.r[2] &= c.r[8];  // 060591F2 and r8,r2
    c.r[1] = 0x2u;  // 060591F4 mov #2,r1
    c.r[1] &= c.r[8];  // 060591F6 and r8,r1
    c.r[0] = ld32(c.r[14] + 52);  // 060591F8 mov.l @(52,r14),r0
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060591FA shar r1
    c.r[2] += c.r[0];  // 060591FC add r0,r2
    c.r[2] -= c.r[1];  // 060591FE sub r1,r2
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06059200 exts.b r2,r2
    c.r[1] = ld32(0x060592DCu);  // 06059202 mov.l 0x060592DC,r1
    c.r[7] = c.r[2];  // 06059204 mov r2,r7
    c.r[1] = ld32(c.r[1]);  // 06059206 mov.l @r1,r1
    c.r[7] <<= 2;  // 06059208 shll2 r7
    c.r[7] <<= 2;  // 0605920A shll2 r7
    c.r[7] <<= 2;  // 0605920C shll2 r7
    c.r[7] += c.r[1];  // 0605920E add r1,r7
    c.r[0] = c.r[7];  // 06059210 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06059212 mov.b @(r0,r3),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06059214 extu.b r1,r4
    c.r[1] = c.r[10];  // 06059216 mov r10,r1
    c.r[1] += 74;  // 06059218 add #74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605921A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605921C extu.b r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0605921E cmp/ge r1,r3
    { const bool k = !c.t; c.r[9] = c.r[4]; if (k) { goto L_0605931A; } }  // 06059220 bf/s 0x0605931A ; mov r4,r9
    c.r[1] = c.r[10];  // 06059224 mov r10,r1
    c.r[1] += 75;  // 06059226 add #75,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059228 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605922A extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0605922C cmp/ge r1,r2
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0605931A; } }  // 0605922E bf/s 0x0605931A ; mov r10,r1
    c.r[1] += 76;  // 06059232 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059234 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059236 extu.b r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06059238 cmp/gt r1,r3
    if (c.t) { goto L_0605931A; }  // 0605923A bt 0x0605931A
    c.r[0] = ld32(0x060592E0u);  // 0605923C mov.l 0x060592E0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605923E mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059240 extu.b r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06059242 cmp/gt r1,r2
    if (c.t) { goto L_0605931A; }  // 06059244 bt 0x0605931A
    c.r[0] = (uint32_t)(int16_t)ld16(0x060592CAu);  // 06059246 mov.w 0x060592CA,r0
    c.t = c.r[4] == c.r[0];  // 06059248 cmp/eq r0,r4
    if (c.t) { goto L_0605931A; }  // 0605924A bt 0x0605931A
    c.r[5] = c.r[4];  // 0605924C mov r4,r5
    c.r[1] = ld32(0x060592D0u);  // 0605924E mov.l 0x060592D0,r1
    c.r[2] = ld32(c.r[1]);  // 06059250 mov.l @r1,r2
    c.r[5] <<= 2;  // 06059252 shll2 r5
    c.r[5] <<= 2;  // 06059254 shll2 r5
    c.r[5] += c.r[2];  // 06059256 add r2,r5
    c.r[1] = c.r[5];  // 06059258 mov r5,r1
    c.r[1] += 4;  // 0605925A add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605925C mov.b @r1,r0
    c.r[0] &= 0x60u;  // 0605925E and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059260 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0605931A; } }  // 06059262 bf/s 0x0605931A ; mov r11,r1
    c.r[1] <<= 2;  // 06059266 shll2 r1
    c.r[1] <<= 2;  // 06059268 shll2 r1
    c.r[1] += c.r[2];  // 0605926A add r2,r1
    c.r[1] += 2;  // 0605926C add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605926E mov.b @r1,r2
    c.r[3] = 0x1Eu;  // 06059270 mov #30,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06059272 extu.b r2,r2
    c.r[1] = ld32(0x060592E4u);  // 06059274 mov.l 0x060592E4,r1
    c.macl = c.r[2] * c.r[3];  // 06059276 mul.l r3,r2
    c.r[7] = ld32(c.r[1]);  // 06059278 mov.l @r1,r7
    c.r[1] = c.macl;  // 0605927A sts macl,r1
    c.r[1] += c.r[7];  // 0605927C add r7,r1
    c.r[1] += 22;  // 0605927E add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059280 mov.w @r1,r1
    c.r[5] += 2;  // 06059282 add #2,r5
    c.r[6] = c.r[1] & 0xFFFFu;  // 06059284 extu.w r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06059286 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059288 extu.b r1,r1
    c.macl = c.r[1] * c.r[3];  // 0605928A mul.l r3,r1
    c.r[1] = c.macl;  // 0605928C sts macl,r1
    c.r[1] += c.r[7];  // 0605928E add r7,r1
    c.r[1] += 22;  // 06059290 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059292 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059294 extu.w r1,r1
    c.t = c.r[1] >= c.r[6];  // 06059296 cmp/hs r6,r1
    if (c.t) { goto L_0605929C; }  // 06059298 bt 0x0605929C
    c.r[6] = c.r[1];  // 0605929A mov r1,r6
L_0605929C:
    c.t = (c.r[12] & c.r[12]) == 0;  // 0605929C tst r12,r12
    { const bool k = !c.t; c.r[6] = 0u - c.r[6]; if (k) { goto L_060592F8; } }  // 0605929E bf/s 0x060592F8 ; neg r6,r6
    c.r[1] = ld32(0x060592E8u);  // 060592A2 mov.l 0x060592E8,r1
    c.r[5] = ld32(0x060592ECu);  // 060592A4 mov.l 0x060592EC,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060592AAu; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060592AAu) return; }  // 060592A6 jsr @r1 ; exts.w r4,r4
    c.r[1] = ld32(0x060592F0u);  // 060592AA mov.l 0x060592F0,r1
    c.r[2] = ld32(c.r[1]);  // 060592AC mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060592CCu);  // 060592AE mov.w 0x060592CC,r1
    c.r[2] += c.r[1];  // 060592B0 add r1,r2
    c.r[1] = ld32(0x060592F4u);  // 060592B2 mov.l 0x060592F4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060592B4 mov.w @r1,r1
    c.r[12] = 0x1u;  // 060592B6 mov #1,r12
    c.r[1] = c.r[1] & 0xFFFFu;  // 060592B8 extu.w r1,r1
    c.r[1] <<= 2;  // 060592BA shll2 r1
    c.r[1] += c.r[1];  // 060592BC add r1,r1
    c.r[2] += c.r[1];  // 060592BE add r1,r2
    c.r[2] += 4;  // 060592C0 add #4,r2
    st8(c.r[2], c.r[13]); goto L_0605931A;  // 060592C2 bra 0x0605931A ; mov.b r13,@r2
L_060592F8:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060592F8 exts.w r9,r4
    c.r[1] = ld32(0x06059468u);  // 060592FA mov.l 0x06059468,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06059300u; c.r[5] = 0x25u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059300u) return; }  // 060592FC jsr @r1 ; mov #37,r5
    c.r[1] = ld32(0x0605946Cu);  // 06059300 mov.l 0x0605946C,r1
    c.r[2] = ld32(c.r[1]);  // 06059302 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059462u);  // 06059304 mov.w 0x06059462,r1
    c.r[2] += c.r[1];  // 06059306 add r1,r2
    c.r[1] = ld32(0x06059470u);  // 06059308 mov.l 0x06059470,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605930A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605930C extu.w r1,r1
    c.r[1] <<= 2;  // 0605930E shll2 r1
    c.r[1] += c.r[1];  // 06059310 add r1,r1
    c.r[2] += c.r[1];  // 06059312 add r1,r2
    c.r[2] += 4;  // 06059314 add #4,r2
    c.r[0] = 0xFFFFFFFFu;  // 06059316 mov #-1,r0
    st8(c.r[2], c.r[0]);  // 06059318 mov.b r0,@r2
L_0605931A:
    c.r[8] += c.r[8];  // 0605931A add r8,r8
    c.r[1] = 0xFu;  // 0605931C mov #15,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0605931E cmp/gt r1,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_06059328; } }  // 06059320 bt/s 0x06059328 ; mov r8,r2
    SH2_POLL(c); goto L_060591D8;  // 06059324 bra 0x060591D8 ; nop
L_06059328:
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059328 tst r12,r12
L_0605932A:
    { const bool k = !c.t; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[11]; if (k) { goto L_06059354; } }  // 0605932A bf/s 0x06059354 ; exts.w r11,r4
    c.r[1] = ld32(0x06059468u);  // 0605932E mov.l 0x06059468,r1
    c.r[6] = 0x0u;  // 06059330 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059336u; c.r[5] = 0x25u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059336u) return; }  // 06059332 jsr @r1 ; mov #37,r5
    c.r[1] = ld32(0x0605946Cu);  // 06059336 mov.l 0x0605946C,r1
    c.r[2] = ld32(c.r[1]);  // 06059338 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059462u);  // 0605933A mov.w 0x06059462,r1
    c.r[2] += c.r[1];  // 0605933C add r1,r2
    c.r[1] = ld32(0x06059470u);  // 0605933E mov.l 0x06059470,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059340 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059342 extu.w r1,r1
    c.r[1] <<= 2;  // 06059344 shll2 r1
    c.r[1] += c.r[1];  // 06059346 add r1,r1
    c.r[2] += c.r[1];  // 06059348 add r1,r2
    c.r[2] += 4;  // 0605934A add #4,r2
    st8(c.r[2], c.r[11]); goto L_060593D6;  // 0605934C bra 0x060593D6 ; mov.b r11,@r2
L_06059350:
    c.r[13] = c.r[8] & 0xFFu; goto L_060593A2;  // 06059350 bra 0x060593A2 ; extu.b r8,r13
L_06059354:
    c.r[1] = ld32(0x06059470u);  // 06059354 mov.l 0x06059470,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059356 mov.w @r1,r1
    c.r[2] = 0x1u;  // 06059358 mov #1,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605935A extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0605935C cmp/hi r2,r1
    if (!c.t) { goto L_060593D6; }  // 0605935E bf 0x060593D6
    c.r[8] = c.r[2];  // 06059360 mov r2,r8
    c.r[2] = c.r[1];  // 06059362 mov r1,r2
    c.r[2] += 1;  // 06059364 add #1,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 06059366 cmp/ge r2,r8
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_060593A2; } }  // 06059368 bt/s 0x060593A2 ; mov #0,r13
    c.r[1] = ld32(0x06059474u);  // 0605936C mov.l 0x06059474,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06059464u);  // 0605936E mov.w 0x06059464,r4
    c.r[7] = c.r[2];  // 06059370 mov r2,r7
    c.r[5] = ld32(c.r[1]);  // 06059372 mov.l @r1,r5
    c.r[3] = ld32(0x06059478u);  // 06059374 mov.l 0x06059478,r3
    c.r[1] = ld32(0x0605947Cu);  // 06059376 mov.l 0x0605947C,r1
    c.r[6] = ld32(c.r[1]);  // 06059378 mov.l @r1,r6
L_0605937A:
    c.r[1] = c.r[3];  // 0605937A mov r3,r1
    c.r[1] += 4;  // 0605937C add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605937E mov.w @r1,r1
    c.r[1] <<= 2;  // 06059380 shll2 r1
    c.r[1] <<= 2;  // 06059382 shll2 r1
    c.r[1] += c.r[5];  // 06059384 add r5,r1
    c.r[1] += 2;  // 06059386 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059388 mov.b @r1,r1
    c.r[2] = 0x1Eu;  // 0605938A mov #30,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605938C extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0605938E mul.l r2,r1
    c.r[0] = c.macl;  // 06059390 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06059392 mov.w @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059394 extu.w r1,r1
    c.t = c.r[1] == c.r[4];  // 06059396 cmp/eq r4,r1
    if (c.t) { SH2_POLL(c); goto L_06059350; }  // 06059398 bt 0x06059350
    c.r[8] += 1;  // 0605939A add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 0605939C cmp/ge r7,r8
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_0605937A; } }  // 0605939E bf/s 0x0605937A ; add #8,r3
L_060593A2:
    c.t = (c.r[13] & c.r[13]) == 0;  // 060593A2 tst r13,r13
    { const bool k = c.t; c.r[6] = c.r[13]; if (k) { goto L_060593D6; } }  // 060593A4 bt/s 0x060593D6 ; mov r13,r6
    c.r[2] = ld32(0x06059480u);  // 060593A8 mov.l 0x06059480,r2
    c.r[6] <<= 2;  // 060593AA shll2 r6
    c.r[6] += c.r[6];  // 060593AC add r6,r6
    c.r[7] = c.r[6];  // 060593AE mov r6,r7
    c.r[7] += c.r[2];  // 060593B0 add r2,r7
    c.r[1] = ld32(0x06059470u);  // 060593B2 mov.l 0x06059470,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060593B4 mov.w @r1,r1
    c.r[7] += 4;  // 060593B6 add #4,r7
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060593B8 mov.w @r7,r8
    c.r[5] = c.r[1] & 0xFFFFu;  // 060593BA extu.w r1,r5
    c.r[5] <<= 2;  // 060593BC shll2 r5
    c.r[5] += c.r[5];  // 060593BE add r5,r5
    c.r[3] = c.r[5];  // 060593C0 mov r5,r3
    c.r[3] += c.r[2];  // 060593C2 add r2,r3
    c.r[3] += 4;  // 060593C4 add #4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060593C6 mov.w @r3,r1
    c.r[0] = c.r[2];  // 060593C8 mov r2,r0
    st16(c.r[7], c.r[1]);  // 060593CA mov.w r1,@r7
    st16(c.r[3], c.r[8]);  // 060593CC mov.w r8,@r3
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 060593CE mov.l @(r0,r5),r1
    c.r[8] = ld32(c.r[0] + c.r[6]);  // 060593D0 mov.l @(r0,r6),r8
    st32(c.r[0] + c.r[6], c.r[1]);  // 060593D2 mov.l r1,@(r0,r6)
    st32(c.r[0] + c.r[5], c.r[8]);  // 060593D4 mov.l r8,@(r0,r5)
L_060593D6:
    c.r[10] = ld32(0x06059474u);  // 060593D6 mov.l 0x06059474,r10
    c.r[1] = ld32(c.r[10]);  // 060593D8 mov.l @r10,r1
    c.r[11] <<= 2;  // 060593DA shll2 r11
    c.r[11] <<= 2;  // 060593DC shll2 r11
    c.r[1] += c.r[11];  // 060593DE add r11,r1
    c.r[1] += 2;  // 060593E0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060593E2 mov.b @r1,r1
    c.r[8] = 0x1Eu;  // 060593E4 mov #30,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060593E6 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 060593E8 mul.l r8,r1
    c.r[9] = ld32(0x0605947Cu);  // 060593EA mov.l 0x0605947C,r9
    c.r[2] = ld32(c.r[9]);  // 060593EC mov.l @r9,r2
    c.r[1] = c.macl;  // 060593EE sts macl,r1
    c.r[1] += c.r[2];  // 060593F0 add r2,r1
    c.r[1] += 15;  // 060593F2 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060593F4 mov.b @r1,r5
    c.r[4] = c.r[14];  // 060593F6 mov r14,r4
    c.r[1] = ld32(0x06059484u);  // 060593F8 mov.l 0x06059484,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060593FEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060593FEu) return; }  // 060593FA jsr @r1 ; extu.b r5,r5
    c.r[3] = ld32(0x06059488u);  // 060593FE mov.l 0x06059488,r3
    c.r[2] = c.r[3];  // 06059400 mov r3,r2
    c.r[1] = c.r[14];  // 06059402 mov r14,r1
    c.r[1] += 42;  // 06059404 add #42,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059406 mov.w @r1,r1
    c.r[2] += 8;  // 06059408 add #8,r2
    c.r[1] <<= 16;  // 0605940A shll16 r1
    c.r[1] += c.r[1];  // 0605940C add r1,r1
    c.r[1] >>= 16;  // 0605940E shlr16 r1
    c.r[1] += c.r[1];  // 06059410 add r1,r1
    c.r[1] >>= 8;  // 06059412 shlr8 r1
    st16(c.r[2], c.r[1]);  // 06059414 mov.w r1,@r2
    c.r[2] = c.r[3];  // 06059416 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 06059418 mov.w @r14,r1
    c.r[2] += 6;  // 0605941A add #6,r2
    st16(c.r[2], c.r[1]);  // 0605941C mov.w r1,@r2
    c.r[1] = ld32(c.r[10]);  // 0605941E mov.l @r10,r1
    c.r[11] += c.r[1];  // 06059420 add r1,r11
    c.r[11] += 2;  // 06059422 add #2,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06059424 mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059426 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 06059428 mul.l r8,r1
    c.r[2] = ld32(c.r[9]);  // 0605942A mov.l @r9,r2
    c.r[1] = c.macl;  // 0605942C sts macl,r1
    c.r[0] = c.r[1];  // 0605942E mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06059430 mov.w @(r0,r2),r1
    c.r[3] += 10;  // 06059432 add #10,r3
    st16(c.r[3], c.r[1]);  // 06059434 mov.w r1,@r3
    c.r[3] = ld32(0x0605948Cu);  // 06059436 mov.l 0x0605948C,r3
    c.r[2] = ld32(0x06059490u);  // 06059438 mov.l 0x06059490,r2
    c.r[1] = ld32(0x06059494u);  // 0605943A mov.l 0x06059494,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605943C mov.b @r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059466u);  // 0605943E mov.w 0x06059466,r0
    c.r[7] &= c.r[0];  // 06059440 and r0,r7
    st8(c.r[1], c.r[7]);  // 06059442 mov.b r7,@r1
    c.r[1] = 0x0u;  // 06059444 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06059446 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 06059448 mov.w r1,@r3
    c.r[0] = 0x0u;  // 0605944A mov #0,r0
L_0605944C:
    c.r[14] += 56;  // 0605944C add #56,r14
    c.r[15] = c.r[14];  // 0605944E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06059450 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06059452 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06059454 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06059456 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06059458 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605945A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605945C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605945E rts ; mov.l @r15+,r8
}

void f_06059498(SH2Context& c) {
    ran[1372] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059498 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605949A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605949C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605949E mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060594A0 extu.b r4,r8
    c.r[1] = c.r[6] & 0xFFu;  // 060594A2 extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060594A4 tst r1,r1
    { const bool k = !c.t; c.r[4] = c.r[5] & 0xFFu; if (k) { goto L_0605954A; } }  // 060594A6 bf/s 0x0605954A ; extu.b r5,r4
    c.r[7] = 0x0u;  // 060594AA mov #0,r7
    c.r[4] = (uint32_t)(int16_t)ld16(0x06059590u);  // 060594AC mov.w 0x06059590,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06059592u);  // 060594AE mov.w 0x06059592,r5
    c.r[6] = 0x0u;  // 060594B0 mov #0,r6
L_060594B2:
    c.r[1] = ld32(0x06059598u);  // 060594B2 mov.l 0x06059598,r1
    c.r[3] = c.r[6];  // 060594B4 mov r6,r3
    c.r[2] = ld32(c.r[1]);  // 060594B6 mov.l @r1,r2
    c.r[0] = c.r[6];  // 060594B8 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060594BA mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060594BC extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 060594BE cmp/eq r4,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_0605952C; } }  // 060594C0 bt/s 0x0605952C ; add r2,r3
    c.r[1] = c.r[3];  // 060594C4 mov r3,r1
    c.r[1] += 7;  // 060594C6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060594C8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060594CA mov r1,r0
    c.r[0] >>= 2;  // 060594CC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060594CE shlr r0
    c.r[0] &= 0x1u;  // 060594D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060594D2 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0605952C; } }  // 060594D4 bf/s 0x0605952C ; mov r8,r1
    c.r[1] <<= 2;  // 060594D8 shll2 r1
    c.r[1] <<= 2;  // 060594DA shll2 r1
    c.r[1] += c.r[2];  // 060594DC add r2,r1
    c.r[1] += 3;  // 060594DE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060594E0 mov.b @r1,r1
    c.r[0] = 0x3u;  // 060594E2 mov #3,r0
    c.r[2] = c.r[1];  // 060594E4 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060594E6 shlr r2
    c.r[1] = c.r[3];  // 060594E8 mov r3,r1
    c.r[1] += 3;  // 060594EA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060594EC mov.b @r1,r1
    c.r[2] &= c.r[0];  // 060594EE and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060594F0 shlr r1
    c.r[1] &= c.r[0];  // 060594F2 and r0,r1
    c.t = c.r[2] == c.r[1];  // 060594F4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0605952C; } }  // 060594F6 bf/s 0x0605952C ; mov r3,r1
    c.r[1] += 8;  // 060594FA add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060594FC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060594FE extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06059500 cmp/eq r4,r1
    { const bool k = !c.t; c.r[3] += 4; if (k) { goto L_0605952C; } }  // 06059502 bf/s 0x0605952C ; add #4,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06059506 mov.b @r3,r0
    c.r[0] &= 0x60u;  // 06059508 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605950A tst r0,r0
    { const bool k = !c.t; c.t = c.r[7] == c.r[8]; if (k) { goto L_0605952C; } }  // 0605950C bf/s 0x0605952C ; cmp/eq r8,r7
    if (c.t) { goto L_0605952C; }  // 06059510 bt 0x0605952C
    c.r[1] = ld32(0x0605959Cu);  // 06059512 mov.l 0x0605959C,r1
    c.r[3] = ld32(c.r[1]);  // 06059514 mov.l @r1,r3
    c.r[0] = c.r[3];  // 06059516 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06059518 mov.b @(r0,r5),r2
    c.r[1] = c.r[2];  // 0605951A mov r2,r1
    c.r[1] += 1;  // 0605951C add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 0605951E mov.b r1,@(r0,r5)
    c.r[2] = c.r[2] & 0xFFu;  // 06059520 extu.b r2,r2
    c.r[2] <<= 2;  // 06059522 shll2 r2
    c.r[2] += c.r[2];  // 06059524 add r2,r2
    c.r[3] += c.r[2];  // 06059526 add r2,r3
    c.r[3] += 4;  // 06059528 add #4,r3
    st8(c.r[3], c.r[7]);  // 0605952A mov.b r7,@r3
L_0605952C:
    c.r[7] += 1;  // 0605952C add #1,r7
    c.r[1] = 0x49u;  // 0605952E mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06059530 cmp/gt r1,r7
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_060594B2; } }  // 06059532 bf/s 0x060594B2 ; add #16,r6
    c.r[1] = ld32(0x0605959Cu);  // 06059536 mov.l 0x0605959C,r1
    c.r[1] = ld32(c.r[1]);  // 06059538 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059592u);  // 0605953A mov.w 0x06059592,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605953C mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605953E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06059540 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06059586; } }  // 06059542 bt/s 0x06059586 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06059586;  // 06059546 bra 0x06059586 ; mov #1,r0
L_0605954A:
    c.r[0] = c.r[1];  // 0605954A mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0605954C cmp/eq #2,r0
    if (!c.t) { goto L_06059560; }  // 0605954E bf 0x06059560
    c.r[4] <<= 2;  // 06059550 shll2 r4
    c.r[1] = ld32(0x06059598u);  // 06059552 mov.l 0x06059598,r1
    c.r[1] = ld32(c.r[1]);  // 06059554 mov.l @r1,r1
    c.r[4] <<= 2;  // 06059556 shll2 r4
    c.r[4] += c.r[1];  // 06059558 add r1,r4
    c.r[4] += 8;  // 0605955A add #8,r4
    st8(c.r[4], c.r[8]); goto L_06059584;  // 0605955C bra 0x06059584 ; mov.b r8,@r4
L_06059560:
    c.r[4] += 74;  // 06059560 add #74,r4
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06059562 exts.w r4,r4
    c.r[1] = ld32(0x060595A0u);  // 06059564 mov.l 0x060595A0,r1
    c.r[6] = 0x0u;  // 06059566 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605956Cu; c.r[5] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605956Cu) return; }  // 06059568 jsr @r1 ; mov #38,r5
    c.r[1] = ld32(0x0605959Cu);  // 0605956C mov.l 0x0605959C,r1
    c.r[2] = ld32(c.r[1]);  // 0605956E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059594u);  // 06059570 mov.w 0x06059594,r1
    c.r[2] += c.r[1];  // 06059572 add r1,r2
    c.r[1] = ld32(0x060595A4u);  // 06059574 mov.l 0x060595A4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059576 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059578 extu.w r1,r1
    c.r[1] <<= 2;  // 0605957A shll2 r1
    c.r[1] += c.r[1];  // 0605957C add r1,r1
    c.r[2] += c.r[1];  // 0605957E add r1,r2
    c.r[2] += 4;  // 06059580 add #4,r2
    st8(c.r[2], c.r[8]);  // 06059582 mov.b r8,@r2
L_06059584:
    c.r[0] = 0x0u;  // 06059584 mov #0,r0
L_06059586:
    c.r[15] = c.r[14];  // 06059586 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06059588 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605958A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605958C rts ; mov.l @r15+,r8
}

void f_060595A8(SH2Context& c) {
    ran[1373] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060595A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060595AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060595AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060595AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060595B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060595B2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060595B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060595B6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060595B8 mov r15,r14
    c.r[12] = c.r[6] & 0xFFu;  // 060595BA extu.b r6,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 060595BC tst r12,r12
    { const bool k = !c.t; c.r[11] = c.r[4] & 0xFFu; if (k) { goto L_0605964C; } }  // 060595BE bf/s 0x0605964C ; extu.b r4,r11
    c.r[9] = 0x0u;  // 060595C2 mov #0,r9
    c.r[10] = 0x0u;  // 060595C4 mov #0,r10
L_060595C6:
    c.r[1] = ld32(0x060596DCu);  // 060595C6 mov.l 0x060596DC,r1
    c.r[8] = c.r[10];  // 060595C8 mov r10,r8
    c.r[0] = c.r[10];  // 060595CA mov r10,r0
    c.r[3] = ld32(c.r[1]);  // 060595CC mov.l @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x060596D8u);  // 060595CE mov.w 0x060596D8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060595D0 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060595D2 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060595D4 cmp/eq r2,r1
    { const bool k = c.t; c.r[8] += c.r[3]; if (k) { goto L_0605963E; } }  // 060595D6 bt/s 0x0605963E ; add r3,r8
    c.r[1] = c.r[8];  // 060595DA mov r8,r1
    c.r[1] += 7;  // 060595DC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060595DE mov.b @r1,r1
    c.r[0] = c.r[1];  // 060595E0 mov r1,r0
    c.r[0] >>= 2;  // 060595E2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060595E4 shlr r0
    c.r[0] &= 0x1u;  // 060595E6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060595E8 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0605963E; } }  // 060595EA bf/s 0x0605963E ; mov r11,r1
    c.r[1] <<= 2;  // 060595EE shll2 r1
    c.r[1] <<= 2;  // 060595F0 shll2 r1
    c.r[1] += c.r[3];  // 060595F2 add r3,r1
    c.r[1] += 4;  // 060595F4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060595F6 mov.b @r1,r1
    c.r[0] = 0xFu;  // 060595F8 mov #15,r0
    c.r[2] = c.r[1];  // 060595FA mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060595FC shlr r2
    c.r[2] &= c.r[0];  // 060595FE and r0,r2
    c.r[1] = c.r[8];  // 06059600 mov r8,r1
    c.r[1] += 3;  // 06059602 add #3,r1
    c.r[0] = 0x3u;  // 06059604 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059606 mov.b @r1,r1
    c.r[4] = c.r[2];  // 06059608 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605960A shlr r1
    c.r[1] &= c.r[0];  // 0605960C and r0,r1
    c.r[0] = ld32(0x060596E0u);  // 0605960E mov.l 0x060596E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06059614u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059614u) return; }  // 06059610 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06059614 mov r0,r1
    c.r[0] = 0x1u;  // 06059616 mov #1,r0
    c.r[1] &= c.r[0];  // 06059618 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605961A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0605963E; } }  // 0605961C bt/s 0x0605963E ; mov r8,r1
    c.r[1] += 4;  // 06059620 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059622 mov.b @r1,r0
    c.r[0] &= 0x60u;  // 06059624 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059626 tst r0,r0
    { const bool k = !c.t; c.r[8] += 11; if (k) { goto L_0605963E; } }  // 06059628 bf/s 0x0605963E ; add #11,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605962C mov.b @r8,r1
    c.r[0] = c.r[1];  // 0605962E mov r1,r0
    c.r[0] >>= 2;  // 06059630 shlr2 r0
    c.r[0] >>= 2;  // 06059632 shlr2 r0
    c.r[0] >>= 2;  // 06059634 shlr2 r0
    c.r[0] &= 0x1u;  // 06059636 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059638 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06059730; } }  // 0605963A bt/s 0x06059730 ; mov #1,r0
L_0605963E:
    c.r[9] += 1;  // 0605963E add #1,r9
    c.r[1] = 0x49u;  // 06059640 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06059642 cmp/gt r1,r9
    { const bool k = !c.t; c.r[10] += 16; if (k) { SH2_POLL(c); goto L_060595C6; } }  // 06059644 bf/s 0x060595C6 ; add #16,r10
    c.r[0] = 0x0u; goto L_06059730;  // 06059648 bra 0x06059730 ; mov #0,r0
L_0605964C:
    c.r[10] = 0x0u;  // 0605964C mov #0,r10
    c.r[9] = 0x0u;  // 0605964E mov #0,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x060596D8u);  // 06059650 mov.w 0x060596D8,r13
L_06059652:
    c.r[1] = ld32(0x060596DCu);  // 06059652 mov.l 0x060596DC,r1
    c.r[0] = c.r[9];  // 06059654 mov r9,r0
    c.r[0] <<= 2;  // 06059656 shll2 r0
    c.r[0] <<= 2;  // 06059658 shll2 r0
    c.r[2] = ld32(c.r[1]);  // 0605965A mov.l @r1,r2
    c.r[8] = c.r[0];  // 0605965C mov r0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605965E mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059660 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06059662 cmp/eq r13,r1
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_06059726; } }  // 06059664 bt/s 0x06059726 ; add r2,r8
    c.r[1] = c.r[8];  // 06059668 mov r8,r1
    c.r[1] += 7;  // 0605966A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605966C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605966E mov r1,r0
    c.r[0] >>= 2;  // 06059670 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06059672 shlr r0
    c.r[0] &= 0x1u;  // 06059674 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059676 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06059726; } }  // 06059678 bf/s 0x06059726 ; mov r11,r1
    c.r[1] <<= 2;  // 0605967C shll2 r1
    c.r[1] <<= 2;  // 0605967E shll2 r1
    c.r[1] += c.r[2];  // 06059680 add r2,r1
    c.r[1] += 4;  // 06059682 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059684 mov.b @r1,r1
    c.r[0] = 0xFu;  // 06059686 mov #15,r0
    c.r[2] = c.r[1];  // 06059688 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605968A shlr r2
    c.r[2] &= c.r[0];  // 0605968C and r0,r2
    c.r[1] = c.r[8];  // 0605968E mov r8,r1
    c.r[1] += 3;  // 06059690 add #3,r1
    c.r[0] = 0x3u;  // 06059692 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059694 mov.b @r1,r1
    c.r[4] = c.r[2];  // 06059696 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06059698 shlr r1
    c.r[1] &= c.r[0];  // 0605969A and r0,r1
    c.r[0] = ld32(0x060596E0u);  // 0605969C mov.l 0x060596E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060596A2u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060596A2u) return; }  // 0605969E jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 060596A2 mov r0,r1
    c.r[0] = 0x1u;  // 060596A4 mov #1,r0
    c.r[1] &= c.r[0];  // 060596A6 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060596A8 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_06059726; } }  // 060596AA bt/s 0x06059726 ; mov r8,r2
    c.r[2] += 11;  // 060596AE add #11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060596B0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060596B2 mov r1,r0
    c.r[0] >>= 2;  // 060596B4 shlr2 r0
    c.r[0] >>= 2;  // 060596B6 shlr2 r0
    c.r[0] >>= 2;  // 060596B8 shlr2 r0
    c.r[0] &= 0x1u;  // 060596BA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060596BC tst r0,r0
    { const bool k = !c.t; c.r[8] += 4; if (k) { goto L_06059726; } }  // 060596BE bf/s 0x06059726 ; add #4,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060596C2 mov.b @r8,r0
    c.r[0] &= 0x60u;  // 060596C4 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060596C6 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_06059726; } }  // 060596C8 bf/s 0x06059726 ; mov r12,r0
    c.t = c.r[0] == 0x2u;  // 060596CC cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_060596E4; } }  // 060596CE bf/s 0x060596E4 ; mov r1,r0
    c.r[0] |= 0x40u;  // 060596D2 or #64,r0
    st8(c.r[2], c.r[0]); goto L_06059726;  // 060596D4 bra 0x06059726 ; mov.b r0,@r2
L_060596E4:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060596E4 exts.w r9,r4
    c.r[1] = ld32(0x06059748u);  // 060596E6 mov.l 0x06059748,r1
    c.r[6] = 0x0u;  // 060596E8 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060596EEu; c.r[5] = 0x27u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060596EEu) return; }  // 060596EA jsr @r1 ; mov #39,r5
    c.t = (c.r[10] & c.r[10]) == 0;  // 060596EE tst r10,r10
    if (!c.t) { goto L_0605970E; }  // 060596F0 bf 0x0605970E
    c.r[10] = 0x1u;  // 060596F2 mov #1,r10
    c.r[1] = ld32(0x0605974Cu);  // 060596F4 mov.l 0x0605974C,r1
    c.r[2] = ld32(c.r[1]);  // 060596F6 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059744u);  // 060596F8 mov.w 0x06059744,r1
    c.r[2] += c.r[1];  // 060596FA add r1,r2
    c.r[1] = ld32(0x06059750u);  // 060596FC mov.l 0x06059750,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060596FE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059700 extu.w r1,r1
    c.r[1] <<= 2;  // 06059702 shll2 r1
    c.r[1] += c.r[1];  // 06059704 add r1,r1
    c.r[2] += c.r[1];  // 06059706 add r1,r2
    c.r[2] += 4;  // 06059708 add #4,r2
    st8(c.r[2], c.r[11]); goto L_06059726;  // 0605970A bra 0x06059726 ; mov.b r11,@r2
L_0605970E:
    c.r[1] = ld32(0x0605974Cu);  // 0605970E mov.l 0x0605974C,r1
    c.r[2] = ld32(c.r[1]);  // 06059710 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059744u);  // 06059712 mov.w 0x06059744,r1
    c.r[2] += c.r[1];  // 06059714 add r1,r2
    c.r[1] = ld32(0x06059750u);  // 06059716 mov.l 0x06059750,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059718 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605971A extu.w r1,r1
    c.r[1] <<= 2;  // 0605971C shll2 r1
    c.r[1] += c.r[1];  // 0605971E add r1,r1
    c.r[2] += c.r[1];  // 06059720 add r1,r2
    c.r[2] += 4;  // 06059722 add #4,r2
    st8(c.r[2], c.r[13]);  // 06059724 mov.b r13,@r2
L_06059726:
    c.r[9] += 1;  // 06059726 add #1,r9
    c.r[1] = 0x49u;  // 06059728 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605972A cmp/gt r1,r9
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { SH2_POLL(c); goto L_06059652; } }  // 0605972C bf/s 0x06059652 ; mov #0,r0
L_06059730:
    c.r[15] = c.r[14];  // 06059730 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06059732 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06059734 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06059736 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06059738 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605973A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605973C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605973E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06059740 rts ; mov.l @r15+,r8
}

void f_06059754(SH2Context& c) {
    ran[1374] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059754 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06059756 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06059758 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605975A mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 0605975C extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 0605975E extu.b r5,r2
    c.r[4] = c.r[2];  // 06059760 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 06059762 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059764 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0605978C; } }  // 06059766 bf/s 0x0605978C ; mov r0,r1
    c.r[1] = ld32(0x060597D8u);  // 0605976A mov.l 0x060597D8,r1
    c.r[1] = ld32(c.r[1]);  // 0605976C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605976E shll2 r2
    c.r[2] <<= 2;  // 06059770 shll2 r2
    c.r[2] += c.r[1];  // 06059772 add r1,r2
    c.r[2] += 11;  // 06059774 add #11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059776 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06059778 mov r1,r0
    c.r[0] >>= 2;  // 0605977A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605977C shlr r0
    c.r[0] >>= 2;  // 0605977E shlr2 r0
    c.r[0] &= 0x1u;  // 06059780 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059782 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_060597C8; } }  // 06059784 bf/s 0x060597C8 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_060597CC;  // 06059788 bra 0x060597CC ; mov r14,r15
L_0605978C:
    c.r[0] = c.r[1];  // 0605978C mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0605978E cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_060597A6; } }  // 06059790 bf/s 0x060597A6 ; shll2 r2
    c.r[1] = ld32(0x060597D8u);  // 06059794 mov.l 0x060597D8,r1
    c.r[1] = ld32(c.r[1]);  // 06059796 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059798 shll2 r2
    c.r[2] += c.r[1];  // 0605979A add r1,r2
    c.r[2] += 11;  // 0605979C add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605979E mov.b @r2,r0
    c.r[0] |= 0x20u;  // 060597A0 or #32,r0
    st8(c.r[2], c.r[0]); goto L_060597C8;  // 060597A2 bra 0x060597C8 ; mov.b r0,@r2
L_060597A6:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060597A6 exts.w r4,r4
    c.r[1] = ld32(0x060597DCu);  // 060597A8 mov.l 0x060597DC,r1
    c.r[6] = 0x0u;  // 060597AA mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060597B0u; c.r[5] = 0x28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060597B0u) return; }  // 060597AC jsr @r1 ; mov #40,r5
    c.r[1] = ld32(0x060597E0u);  // 060597B0 mov.l 0x060597E0,r1
    c.r[2] = ld32(c.r[1]);  // 060597B2 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060597D4u);  // 060597B4 mov.w 0x060597D4,r1
    c.r[2] += c.r[1];  // 060597B6 add r1,r2
    c.r[1] = ld32(0x060597E4u);  // 060597B8 mov.l 0x060597E4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060597BA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060597BC extu.w r1,r1
    c.r[1] <<= 2;  // 060597BE shll2 r1
    c.r[1] += c.r[1];  // 060597C0 add r1,r1
    c.r[2] += c.r[1];  // 060597C2 add r1,r2
    c.r[2] += 4;  // 060597C4 add #4,r2
    st8(c.r[2], c.r[8]);  // 060597C6 mov.b r8,@r2
L_060597C8:
    c.r[0] = 0x0u;  // 060597C8 mov #0,r0
    c.r[15] = c.r[14];  // 060597CA mov r14,r15
L_060597CC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060597CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060597CE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060597D0 rts ; mov.l @r15+,r8
}

void f_060597E8(SH2Context& c) {
    ran[1375] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060597E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060597EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060597EC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060597EE mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060597F0 extu.b r4,r8
    c.r[3] = c.r[5] & 0xFFu;  // 060597F2 extu.b r5,r3
    c.r[4] = c.r[3];  // 060597F4 mov r3,r4
    c.r[0] = c.r[6] & 0xFFu;  // 060597F6 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060597F8 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0605981E; } }  // 060597FA bf/s 0x0605981E ; mov r0,r1
    c.r[1] = ld32(0x06059888u);  // 060597FE mov.l 0x06059888,r1
    c.r[1] = ld32(c.r[1]);  // 06059800 mov.l @r1,r1
    c.r[3] <<= 2;  // 06059802 shll2 r3
    c.r[3] <<= 2;  // 06059804 shll2 r3
    c.r[3] += c.r[1];  // 06059806 add r1,r3
    c.r[3] += 11;  // 06059808 add #11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605980A mov.b @r3,r1
    c.r[0] = c.r[1];  // 0605980C mov r1,r0
    c.r[0] >>= 2;  // 0605980E shlr2 r0
    c.r[0] >>= 2;  // 06059810 shlr2 r0
    c.r[0] &= 0x1u;  // 06059812 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059814 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06059878; } }  // 06059816 bf/s 0x06059878 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_0605987C;  // 0605981A bra 0x0605987C ; mov r14,r15
L_0605981E:
    c.r[0] = c.r[1];  // 0605981E mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06059820 cmp/eq #2,r0
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_06059856; } }  // 06059822 bf/s 0x06059856 ; shll2 r3
    c.r[1] = ld32(0x06059888u);  // 06059826 mov.l 0x06059888,r1
    c.r[2] = ld32(c.r[1]);  // 06059828 mov.l @r1,r2
    c.r[3] <<= 2;  // 0605982A shll2 r3
    c.r[2] += c.r[3];  // 0605982C add r3,r2
    c.r[2] += 11;  // 0605982E add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059830 mov.b @r2,r0
    c.r[0] |= 0x10u;  // 06059832 or #16,r0
    st8(c.r[2], c.r[0]);  // 06059834 mov.b r0,@r2
    c.r[1] = ld32(c.r[1]);  // 06059836 mov.l @r1,r1
    c.r[1] += c.r[3];  // 06059838 add r3,r1
    c.r[1] += 10;  // 0605983A add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605983C mov.b @r1,r2
    c.r[0] = c.r[2];  // 0605983E mov r2,r0
    c.r[0] >>= 2;  // 06059840 shlr2 r0
    c.r[0] >>= 2;  // 06059842 shlr2 r0
    c.r[0] >>= 2;  // 06059844 shlr2 r0
    c.r[0] &= 0x1u;  // 06059846 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059848 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0605987A; } }  // 0605984A bt/s 0x0605987A ; mov #0,r0
    c.r[0] = c.r[2];  // 0605984E mov r2,r0
    c.r[0] &= 0xBFu;  // 06059850 and #191,r0
    st8(c.r[1], c.r[0]); goto L_06059878;  // 06059852 bra 0x06059878 ; mov.b r0,@r1
L_06059856:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06059856 exts.w r4,r4
    c.r[1] = ld32(0x0605988Cu);  // 06059858 mov.l 0x0605988C,r1
    c.r[6] = 0x0u;  // 0605985A mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059860u; c.r[5] = 0x29u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059860u) return; }  // 0605985C jsr @r1 ; mov #41,r5
    c.r[1] = ld32(0x06059890u);  // 06059860 mov.l 0x06059890,r1
    c.r[2] = ld32(c.r[1]);  // 06059862 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059884u);  // 06059864 mov.w 0x06059884,r1
    c.r[2] += c.r[1];  // 06059866 add r1,r2
    c.r[1] = ld32(0x06059894u);  // 06059868 mov.l 0x06059894,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605986A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605986C extu.w r1,r1
    c.r[1] <<= 2;  // 0605986E shll2 r1
    c.r[1] += c.r[1];  // 06059870 add r1,r1
    c.r[2] += c.r[1];  // 06059872 add r1,r2
    c.r[2] += 4;  // 06059874 add #4,r2
    st8(c.r[2], c.r[8]);  // 06059876 mov.b r8,@r2
L_06059878:
    c.r[0] = 0x0u;  // 06059878 mov #0,r0
L_0605987A:
    c.r[15] = c.r[14];  // 0605987A mov r14,r15
L_0605987C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605987C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605987E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06059880 rts ; mov.l @r15+,r8
}

void f_06059898(SH2Context& c) {
    ran[1376] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059898 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605989A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605989C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605989E mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060598A0 extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 060598A2 extu.b r5,r2
    c.r[4] = c.r[2];  // 060598A4 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 060598A6 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060598A8 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_060598CE; } }  // 060598AA bf/s 0x060598CE ; mov r0,r1
    c.r[1] = ld32(0x06059918u);  // 060598AE mov.l 0x06059918,r1
    c.r[1] = ld32(c.r[1]);  // 060598B0 mov.l @r1,r1
    c.r[2] <<= 2;  // 060598B2 shll2 r2
    c.r[2] <<= 2;  // 060598B4 shll2 r2
    c.r[2] += c.r[1];  // 060598B6 add r1,r2
    c.r[2] += 11;  // 060598B8 add #11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060598BA mov.b @r2,r1
    c.r[0] = c.r[1];  // 060598BC mov r1,r0
    c.r[0] >>= 2;  // 060598BE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060598C0 shlr r0
    c.r[0] &= 0x1u;  // 060598C2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060598C4 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0605990A; } }  // 060598C6 bf/s 0x0605990A ; mov #1,r0
    c.r[15] = c.r[14]; goto L_0605990E;  // 060598CA bra 0x0605990E ; mov r14,r15
L_060598CE:
    c.r[0] = c.r[1];  // 060598CE mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060598D0 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_060598E8; } }  // 060598D2 bf/s 0x060598E8 ; shll2 r2
    c.r[1] = ld32(0x06059918u);  // 060598D6 mov.l 0x06059918,r1
    c.r[1] = ld32(c.r[1]);  // 060598D8 mov.l @r1,r1
    c.r[2] <<= 2;  // 060598DA shll2 r2
    c.r[2] += c.r[1];  // 060598DC add r1,r2
    c.r[2] += 11;  // 060598DE add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060598E0 mov.b @r2,r0
    c.r[0] |= 0x8u;  // 060598E2 or #8,r0
    st8(c.r[2], c.r[0]); goto L_0605990A;  // 060598E4 bra 0x0605990A ; mov.b r0,@r2
L_060598E8:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060598E8 exts.w r4,r4
    c.r[1] = ld32(0x0605991Cu);  // 060598EA mov.l 0x0605991C,r1
    c.r[6] = 0x0u;  // 060598EC mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060598F2u; c.r[5] = 0x2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060598F2u) return; }  // 060598EE jsr @r1 ; mov #42,r5
    c.r[1] = ld32(0x06059920u);  // 060598F2 mov.l 0x06059920,r1
    c.r[2] = ld32(c.r[1]);  // 060598F4 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059916u);  // 060598F6 mov.w 0x06059916,r1
    c.r[2] += c.r[1];  // 060598F8 add r1,r2
    c.r[1] = ld32(0x06059924u);  // 060598FA mov.l 0x06059924,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060598FC mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060598FE extu.w r1,r1
    c.r[1] <<= 2;  // 06059900 shll2 r1
    c.r[1] += c.r[1];  // 06059902 add r1,r1
    c.r[2] += c.r[1];  // 06059904 add r1,r2
    c.r[2] += 4;  // 06059906 add #4,r2
    st8(c.r[2], c.r[8]);  // 06059908 mov.b r8,@r2
L_0605990A:
    c.r[0] = 0x0u;  // 0605990A mov #0,r0
    c.r[15] = c.r[14];  // 0605990C mov r14,r15
L_0605990E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605990E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06059910 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06059912 rts ; mov.l @r15+,r8
}

void f_06059928(SH2Context& c) {
    ran[1377] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059928 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605992A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605992C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605992E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06059930 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06059932 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06059934 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06059936 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 06059938 extu.b r4,r11
    c.r[1] = c.r[6] & 0xFFu;  // 0605993A extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605993C tst r1,r1
    { const bool k = !c.t; c.r[4] = c.r[5] & 0xFFu; if (k) { goto L_060599EA; } }  // 0605993E bf/s 0x060599EA ; extu.b r5,r4
    c.r[10] = 0x0u;  // 06059942 mov #0,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06059A36u);  // 06059944 mov.w 0x06059A36,r12
    c.r[9] = 0x0u;  // 06059946 mov #0,r9
L_06059948:
    c.r[1] = ld32(0x06059A3Cu);  // 06059948 mov.l 0x06059A3C,r1
    c.r[8] = c.r[9];  // 0605994A mov r9,r8
    c.r[2] = ld32(c.r[1]);  // 0605994C mov.l @r1,r2
    c.r[0] = c.r[9];  // 0605994E mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06059950 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059952 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 06059954 cmp/eq r12,r1
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_060599CC; } }  // 06059956 bt/s 0x060599CC ; add r2,r8
    c.r[1] = c.r[8];  // 0605995A mov r8,r1
    c.r[1] += 7;  // 0605995C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605995E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06059960 mov r1,r0
    c.r[0] >>= 2;  // 06059962 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06059964 shlr r0
    c.r[0] &= 0x1u;  // 06059966 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059968 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_060599CC; } }  // 0605996A bf/s 0x060599CC ; mov r11,r1
    c.r[1] <<= 2;  // 0605996E shll2 r1
    c.r[1] <<= 2;  // 06059970 shll2 r1
    c.r[1] += c.r[2];  // 06059972 add r2,r1
    c.r[1] += 4;  // 06059974 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059976 mov.b @r1,r1
    c.r[0] = 0xFu;  // 06059978 mov #15,r0
    c.r[2] = c.r[1];  // 0605997A mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605997C shlr r2
    c.r[2] &= c.r[0];  // 0605997E and r0,r2
    c.r[1] = c.r[8];  // 06059980 mov r8,r1
    c.r[1] += 3;  // 06059982 add #3,r1
    c.r[0] = 0x3u;  // 06059984 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059986 mov.b @r1,r1
    c.r[4] = c.r[2];  // 06059988 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605998A shlr r1
    c.r[1] &= c.r[0];  // 0605998C and r0,r1
    c.r[0] = ld32(0x06059A40u);  // 0605998E mov.l 0x06059A40,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06059994u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059994u) return; }  // 06059990 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06059994 mov r0,r1
    c.r[0] = 0x1u;  // 06059996 mov #1,r0
    c.r[1] &= c.r[0];  // 06059998 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605999A tst r1,r1
    if (c.t) { goto L_060599CC; }  // 0605999C bt 0x060599CC
    c.r[2] = ld32(c.r[8] + 4);  // 0605999E mov.l @(4,r8),r2
    c.r[1] = ld32(0x06059A44u);  // 060599A0 mov.l 0x06059A44,r1
    c.r[2] &= c.r[1];  // 060599A2 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060599A4 tst r2,r2
    { const bool k = !c.t; c.r[8] += 9; if (k) { goto L_060599CC; } }  // 060599A6 bf/s 0x060599CC ; add #9,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060599AA mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060599AC extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 060599AE cmp/eq r12,r1
    if (!c.t) { goto L_060599CC; }  // 060599B0 bf 0x060599CC
    c.r[1] = ld32(0x06059A48u);  // 060599B2 mov.l 0x06059A48,r1
    c.r[3] = ld32(c.r[1]);  // 060599B4 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059A38u);  // 060599B6 mov.w 0x06059A38,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060599B8 mov.b @(r0,r3),r2
    c.r[1] = c.r[2];  // 060599BA mov r2,r1
    c.r[1] += 1;  // 060599BC add #1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 060599BE mov.b r1,@(r0,r3)
    c.r[2] = c.r[2] & 0xFFu;  // 060599C0 extu.b r2,r2
    c.r[2] <<= 2;  // 060599C2 shll2 r2
    c.r[2] += c.r[2];  // 060599C4 add r2,r2
    c.r[3] += c.r[2];  // 060599C6 add r2,r3
    c.r[3] += 4;  // 060599C8 add #4,r3
    st8(c.r[3], c.r[10]);  // 060599CA mov.b r10,@r3
L_060599CC:
    c.r[10] += 1;  // 060599CC add #1,r10
    c.r[1] = 0x49u;  // 060599CE mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060599D0 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_06059948; } }  // 060599D2 bf/s 0x06059948 ; add #16,r9
    c.r[1] = ld32(0x06059A48u);  // 060599D6 mov.l 0x06059A48,r1
    c.r[1] = ld32(c.r[1]);  // 060599D8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059A38u);  // 060599DA mov.w 0x06059A38,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060599DC mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060599DE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060599E0 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06059A24; } }  // 060599E2 bt/s 0x06059A24 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06059A24;  // 060599E6 bra 0x06059A24 ; mov #1,r0
L_060599EA:
    c.r[0] = c.r[1];  // 060599EA mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060599EC cmp/eq #2,r0
    if (!c.t) { goto L_06059A00; }  // 060599EE bf 0x06059A00
    c.r[4] <<= 2;  // 060599F0 shll2 r4
    c.r[1] = ld32(0x06059A3Cu);  // 060599F2 mov.l 0x06059A3C,r1
    c.r[1] = ld32(c.r[1]);  // 060599F4 mov.l @r1,r1
    c.r[4] <<= 2;  // 060599F6 shll2 r4
    c.r[4] += c.r[1];  // 060599F8 add r1,r4
    c.r[4] += 9;  // 060599FA add #9,r4
    st8(c.r[4], c.r[11]); goto L_06059A22;  // 060599FC bra 0x06059A22 ; mov.b r11,@r4
L_06059A00:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06059A00 exts.w r4,r4
    c.r[1] = ld32(0x06059A4Cu);  // 06059A02 mov.l 0x06059A4C,r1
    c.r[6] = 0x0u;  // 06059A04 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059A0Au; c.r[5] = 0x2Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059A0Au) return; }  // 06059A06 jsr @r1 ; mov #43,r5
    c.r[1] = ld32(0x06059A48u);  // 06059A0A mov.l 0x06059A48,r1
    c.r[2] = ld32(c.r[1]);  // 06059A0C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059A3Au);  // 06059A0E mov.w 0x06059A3A,r1
    c.r[2] += c.r[1];  // 06059A10 add r1,r2
    c.r[1] = ld32(0x06059A50u);  // 06059A12 mov.l 0x06059A50,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059A14 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059A16 extu.w r1,r1
    c.r[1] <<= 2;  // 06059A18 shll2 r1
    c.r[1] += c.r[1];  // 06059A1A add r1,r1
    c.r[2] += c.r[1];  // 06059A1C add r1,r2
    c.r[2] += 4;  // 06059A1E add #4,r2
    st8(c.r[2], c.r[11]);  // 06059A20 mov.b r11,@r2
L_06059A22:
    c.r[0] = 0x0u;  // 06059A22 mov #0,r0
L_06059A24:
    c.r[15] = c.r[14];  // 06059A24 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06059A26 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06059A28 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06059A2A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06059A2C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06059A2E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06059A30 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06059A32 rts ; mov.l @r15+,r8
}

void f_06059A54(SH2Context& c) {
    ran[1378] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059A54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06059A56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06059A58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06059A5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06059A5C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06059A5E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06059A60 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06059A62 sts.l pr,@-r15
    c.r[15] -= 56;  // 06059A64 add #-56,r15
    c.r[14] = c.r[15];  // 06059A66 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06059A68 extu.b r4,r4
    st32(c.r[14] + 48, c.r[4]);  // 06059A6A mov.l r4,@(48,r14)
    c.r[1] = ld32(0x06059C00u);  // 06059A6C mov.l 0x06059C00,r1
    c.r[2] = c.r[4];  // 06059A6E mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 06059A70 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059A72 shll2 r2
    c.r[2] <<= 2;  // 06059A74 shll2 r2
    c.r[2] += c.r[1];  // 06059A76 add r1,r2
    c.r[2] += 2;  // 06059A78 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059A7A mov.b @r2,r2
    c.r[1] = ld32(0x06059C04u);  // 06059A7C mov.l 0x06059C04,r1
    c.r[3] = ld32(c.r[1]);  // 06059A7E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06059A80 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06059A82 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06059A84 mul.l r1,r2
    c.r[6] = c.r[6] & 0xFFu;  // 06059A86 extu.b r6,r6
    c.r[1] = c.macl;  // 06059A88 sts macl,r1
    c.r[1] += c.r[3];  // 06059A8A add r3,r1
    c.r[1] += 15;  // 06059A8C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059A8E mov.b @r1,r1
    c.t = (c.r[6] & c.r[6]) == 0;  // 06059A90 tst r6,r6
    { const bool k = c.t; c.r[13] = c.r[1] & 0xFFu; if (k) { goto L_06059A9A; } }  // 06059A92 bt/s 0x06059A9A ; extu.b r1,r13
    goto L_06059C26;  // 06059A96 bra 0x06059C26 ; nop
L_06059A9A:
    c.r[12] = 0x0u;  // 06059A9A mov #0,r12
    c.r[0] = c.r[13];  // 06059A9C mov r13,r0
    c.r[0] += c.r[0];  // 06059A9E add r0,r0
    st32(c.r[14] + 52, c.r[0]);  // 06059AA0 mov.l r0,@(52,r14)
L_06059AA2:
    c.r[1] = ld32(0x06059C08u);  // 06059AA2 mov.l 0x06059C08,r1
    c.r[0] = c.r[12];  // 06059AA4 mov r12,r0
    c.r[0] += c.r[0];  // 06059AA6 add r0,r0
    c.r[0] += c.r[12];  // 06059AA8 add r12,r0
    c.r[1] = ld32(c.r[1]);  // 06059AAA mov.l @r1,r1
    c.r[0] <<= 2;  // 06059AAC shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06059AAE mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059AB0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06059AB2 tst r1,r1
    { const bool k = !c.t; c.r[8] = c.r[12] & 0xFFu; if (k) { goto L_06059ABC; } }  // 06059AB4 bf/s 0x06059ABC ; extu.b r12,r8
    goto L_06059BE2;  // 06059AB8 bra 0x06059BE2 ; nop
L_06059ABC:
    c.r[0] = ld32(0x06059C0Cu);  // 06059ABC mov.l 0x06059C0C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06059AC2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059AC2u) return; }  // 06059ABE jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0] & 0xFFu;  // 06059AC2 extu.b r0,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059BFAu);  // 06059AC4 mov.w 0x06059BFA,r1
    c.t = c.r[10] == c.r[1];  // 06059AC6 cmp/eq r1,r10
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06059AD0; } }  // 06059AC8 bf/s 0x06059AD0 ; mov #3,r0
    goto L_06059BE2;  // 06059ACC bra 0x06059BE2 ; nop
L_06059AD0:
    c.r[1] = ld32(0x06059C00u);  // 06059AD0 mov.l 0x06059C00,r1
    c.r[2] = ld32(c.r[1]);  // 06059AD2 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 48);  // 06059AD4 mov.l @(48,r14),r1
    c.r[1] <<= 2;  // 06059AD6 shll2 r1
    c.r[1] <<= 2;  // 06059AD8 shll2 r1
    c.r[1] += c.r[2];  // 06059ADA add r2,r1
    c.r[1] += 3;  // 06059ADC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059ADE mov.b @r1,r1
    c.r[3] = c.r[1];  // 06059AE0 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06059AE2 shlr r3
    c.r[1] = c.r[10];  // 06059AE4 mov r10,r1
    c.r[1] <<= 2;  // 06059AE6 shll2 r1
    c.r[1] <<= 2;  // 06059AE8 shll2 r1
    c.r[1] += c.r[2];  // 06059AEA add r2,r1
    c.r[1] += 3;  // 06059AEC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059AEE mov.b @r1,r1
    c.r[3] &= c.r[0];  // 06059AF0 and r0,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06059AF2 shlr r1
    c.r[1] &= c.r[0];  // 06059AF4 and r0,r1
    c.t = c.r[3] == c.r[1];  // 06059AF6 cmp/eq r1,r3
    { const bool k = !c.t; c.r[5] = c.r[8]; if (k) { goto L_06059BE2; } }  // 06059AF8 bf/s 0x06059BE2 ; mov r8,r5
    c.r[1] = ld32(0x06059C10u);  // 06059AFC mov.l 0x06059C10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06059B02u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059B02u) return; }  // 06059AFE jsr @r1 ; mov r14,r4
    c.r[11] = ld32(c.r[14] + 52);  // 06059B02 mov.l @(52,r14),r11
    c.r[9] = 0x0u;  // 06059B04 mov #0,r9
    c.r[11] += c.r[13];  // 06059B06 add r13,r11
    c.r[11] <<= 2;  // 06059B08 shll2 r11
    c.r[1] = c.r[14];  // 06059B0A mov r14,r1
L_06059B0C:
    c.r[1] += 24;  // 06059B0C add #24,r1
    c.r[0] = c.r[1];  // 06059B0E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06059B10 mov.b @(r0,r9),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06059B12 extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06059B14 tst r2,r2
    if (c.t) { goto L_06059B42; }  // 06059B16 bt 0x06059B42
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059BFAu);  // 06059B18 mov.w 0x06059BFA,r1
    c.t = c.r[2] == c.r[1];  // 06059B1A cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06059B42; } }  // 06059B1C bt/s 0x06059B42 ; mov r2,r0
    c.t = c.r[0] == 0x1Cu;  // 06059B20 cmp/eq #28,r0
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_06059B42; } }  // 06059B22 bt/s 0x06059B42 ; mov #1,r6
    c.r[1] = ld32(0x06059C08u);  // 06059B26 mov.l 0x06059C08,r1
    c.r[0] = ld32(0x06059C14u);  // 06059B28 mov.l 0x06059C14,r0
    c.r[5] = c.r[14];  // 06059B2A mov r14,r5
    c.r[8] = ld32(c.r[1]);  // 06059B2C mov.l @r1,r8
    c.r[4] = c.r[2];  // 06059B2E mov r2,r4
    c.r[8] += c.r[11];  // 06059B30 add r11,r8
    { const uint32_t x = c.r[0]; c.pr = 0x06059B36u; c.r[8] += 10; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059B36u) return; }  // 06059B32 jsr @r0 ; add #10,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06059B36 mov.w @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 06059B38 extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059B3A extu.w r1,r1
    c.t = c.r[1] >= c.r[2];  // 06059B3C cmp/hs r2,r1
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_06059B4E; } }  // 06059B3E bt/s 0x06059B4E ; mov r9,r0
L_06059B42:
    c.r[9] += 1;  // 06059B42 add #1,r9
    c.r[1] = 0x5u;  // 06059B44 mov #5,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06059B46 cmp/gt r1,r9
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_06059B0C; } }  // 06059B48 bf/s 0x06059B0C ; mov r14,r1
    c.r[0] = c.r[9];  // 06059B4C mov r9,r0
L_06059B4E:
    c.t = c.r[0] == 0x6u;  // 06059B4E cmp/eq #6,r0
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_06059BE2; } }  // 06059B50 bt/s 0x06059BE2 ; mov r10,r2
    c.r[1] = ld32(0x06059C00u);  // 06059B54 mov.l 0x06059C00,r1
    c.r[3] = ld32(c.r[1]);  // 06059B56 mov.l @r1,r3
    c.r[2] <<= 2;  // 06059B58 shll2 r2
    c.r[2] <<= 2;  // 06059B5A shll2 r2
    c.r[2] += c.r[3];  // 06059B5C add r3,r2
    c.r[1] = c.r[2];  // 06059B5E mov r2,r1
    c.r[1] += 4;  // 06059B60 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059B62 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06059B64 mov r1,r0
    c.r[0] >>= 2;  // 06059B66 shlr2 r0
    c.r[0] >>= 2;  // 06059B68 shlr2 r0
    c.r[0] >>= 2;  // 06059B6A shlr2 r0
    c.r[0] &= 0x1u;  // 06059B6C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059B6E tst r0,r0
    { const bool k = c.t; c.r[2] += 5; if (k) { goto L_06059B78; } }  // 06059B70 bt/s 0x06059B78 ; add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059B74 mov.b @r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06059B76 extu.b r1,r10
L_06059B78:
    c.r[2] = c.r[10];  // 06059B78 mov r10,r2
    c.r[2] <<= 2;  // 06059B7A shll2 r2
    c.r[2] <<= 2;  // 06059B7C shll2 r2
    c.r[2] += c.r[3];  // 06059B7E add r3,r2
    c.r[1] = c.r[2];  // 06059B80 mov r2,r1
    c.r[1] += 4;  // 06059B82 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059B84 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06059B86 mov r1,r0
    c.r[0] >>= 2;  // 06059B88 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06059B8A shlr r0
    c.r[0] >>= 2;  // 06059B8C shlr2 r0
    c.r[0] &= 0x1u;  // 06059B8E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059B90 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06059B9A; } }  // 06059B92 bt/s 0x06059B9A ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059B96 mov.b @r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06059B98 extu.b r1,r10
L_06059B9A:
    c.r[0] = ld32(0x06059C18u);  // 06059B9A mov.l 0x06059C18,r0
    c.r[2] = ld32(c.r[0]);  // 06059B9C mov.l @r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059BFCu);  // 06059B9E mov.w 0x06059BFC,r1
    c.r[0] = c.r[2];  // 06059BA0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06059BA2 mov.b @(r0,r1),r1
    c.r[9] = 0x0u;  // 06059BA4 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06059BA6 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06059BA8 cmp/ge r1,r9
    { const bool k = c.t; c.r[3] = c.r[1]; if (k) { goto L_06059BC2; } }  // 06059BAA bt/s 0x06059BC2 ; mov r1,r3
L_06059BAE:
    c.r[1] = c.r[2];  // 06059BAE mov r2,r1
    c.r[1] += 4;  // 06059BB0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059BB2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059BB4 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06059BB6 cmp/eq r10,r1
    if (c.t) { goto L_06059BC2; }  // 06059BB8 bt 0x06059BC2
    c.r[9] += 1;  // 06059BBA add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[3];  // 06059BBC cmp/ge r3,r9
    { const bool k = !c.t; c.r[2] += 8; if (k) { SH2_POLL(c); goto L_06059BAE; } }  // 06059BBE bf/s 0x06059BAE ; add #8,r2
L_06059BC2:
    c.r[0] = ld32(0x06059C18u);  // 06059BC2 mov.l 0x06059C18,r0
    c.r[2] = ld32(c.r[0]);  // 06059BC4 mov.l @r0,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06059BFCu);  // 06059BC6 mov.w 0x06059BFC,r7
    c.r[0] = c.r[2];  // 06059BC8 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06059BCA mov.b @(r0,r7),r3
    c.r[1] = c.r[3] & 0xFFu;  // 06059BCC extu.b r3,r1
    c.t = c.r[9] == c.r[1];  // 06059BCE cmp/eq r1,r9
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06059BE2; } }  // 06059BD0 bf/s 0x06059BE2 ; mov r3,r1
    c.r[1] += 1;  // 06059BD4 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06059BD6 mov.b r1,@(r0,r7)
    c.r[9] <<= 2;  // 06059BD8 shll2 r9
    c.r[9] += c.r[9];  // 06059BDA add r9,r9
    c.r[2] += c.r[9];  // 06059BDC add r9,r2
    c.r[2] += 4;  // 06059BDE add #4,r2
    st8(c.r[2], c.r[10]);  // 06059BE0 mov.b r10,@r2
L_06059BE2:
    c.r[12] += 1;  // 06059BE2 add #1,r12
    c.r[1] = 0x7Fu;  // 06059BE4 mov #127,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06059BE6 cmp/gt r1,r12
    if (c.t) { goto L_06059BEE; }  // 06059BE8 bt 0x06059BEE
    SH2_POLL(c); goto L_06059AA2;  // 06059BEA bra 0x06059AA2 ; nop
L_06059BEE:
    c.r[1] = ld32(0x06059C18u);  // 06059BEE mov.l 0x06059C18,r1
    c.r[1] = ld32(c.r[1]);  // 06059BF0 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059BFCu);  // 06059BF2 mov.w 0x06059BFC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06059BF4 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06059C1C;  // 06059BF6 bra 0x06059C1C ; extu.b r1,r1
L_06059C1C:
    c.t = (c.r[1] & c.r[1]) == 0;  // 06059C1C tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06059C28; } }  // 06059C1E bt/s 0x06059C28 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06059C28;  // 06059C22 bra 0x06059C28 ; mov #1,r0
L_06059C26:
    c.r[0] = 0x0u;  // 06059C26 mov #0,r0
L_06059C28:
    c.r[14] += 56;  // 06059C28 add #56,r14
    c.r[15] = c.r[14];  // 06059C2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06059C2C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06059C2E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06059C30 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06059C32 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06059C34 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06059C36 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06059C38 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06059C3A rts ; mov.l @r15+,r8
}

void f_06059C40(SH2Context& c) {
    ran[1379] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06059C40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06059C42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06059C44 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06059C46 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06059C48 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06059C4A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06059C4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06059C4E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06059D6Cu);  // 06059C50 mov.w 0x06059D6C,r3
    c.r[15] += c.r[3];  // 06059C52 add r3,r15
    c.r[14] = c.r[15];  // 06059C54 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06059C56 extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059D6Eu);  // 06059C58 mov.w 0x06059D6E,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06059C5A mov.l r4,@(r0,r14)
    c.r[9] = c.r[5] & 0xFFu;  // 06059C5C extu.b r5,r9
    c.r[12] = c.r[6] & 0xFFu;  // 06059C5E extu.b r6,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059C60 tst r12,r12
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_06059C6A; } }  // 06059C62 bt/s 0x06059C6A ; mov #0,r11
    goto L_06059F36;  // 06059C66 bra 0x06059F36 ; nop
L_06059C6A:
    c.r[1] = ld32(0x06059D78u);  // 06059C6A mov.l 0x06059D78,r1
    c.r[2] = c.r[9];  // 06059C6C mov r9,r2
    c.r[2] <<= 2;  // 06059C6E shll2 r2
    c.r[2] <<= 2;  // 06059C70 shll2 r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06059D70u);  // 06059C72 mov.w 0x06059D70,r6
    c.r[1] = ld32(c.r[1]);  // 06059C74 mov.l @r1,r1
    c.r[4] = c.r[14];  // 06059C76 mov r14,r4
    c.r[2] += c.r[1];  // 06059C78 add r1,r2
    c.r[2] += 2;  // 06059C7A add #2,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059C7C mov.b @r2,r8
    c.r[1] = ld32(0x06059D7Cu);  // 06059C7E mov.l 0x06059D7C,r1
    c.r[8] = c.r[8] & 0xFFu;  // 06059C80 extu.b r8,r8
    { const uint32_t x = c.r[1]; c.pr = 0x06059C86u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059C86u) return; }  // 06059C82 jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06059D80u);  // 06059C86 mov.l 0x06059D80,r1
    c.r[2] = ld32(c.r[1]);  // 06059C88 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06059C8A mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06059C8C mul.l r1,r8
    c.r[3] = c.macl;  // 06059C8E sts macl,r3
    c.r[3] += c.r[2];  // 06059C90 add r2,r3
    c.r[3] += 22;  // 06059C92 add #22,r3
    c.r[1] = c.r[14];  // 06059C94 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06059C96 mov.w @r3,r2
    c.r[1] += 26;  // 06059C98 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059C9A mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06059C9C extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059C9E extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06059CA0 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06059CA8; } }  // 06059CA2 bt/s 0x06059CA8 ; mov #0,r1
    c.r[1] = 0x1u;  // 06059CA6 mov #1,r1
L_06059CA8:
    c.r[11] += c.r[1];  // 06059CA8 add r1,r11
    c.r[6] = c.r[12];  // 06059CAA mov r12,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059D6Eu);  // 06059CAC mov.w 0x06059D6E,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06059CAE mov.l @(r0,r14),r4
    c.r[0] = ld32(0x06059D84u);  // 06059CB0 mov.l 0x06059D84,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06059CB6u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059CB6u) return; }  // 06059CB2 jsr @r0 ; mov r9,r5
    c.r[1] = c.r[0];  // 06059CB6 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059CB8 extu.b r1,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059CBA tst r12,r12
    { const bool k = !c.t; c.r[11] += c.r[1]; if (k) { goto L_06059CE4; } }  // 06059CBC bf/s 0x06059CE4 ; add r1,r11
    c.r[1] = ld32(0x06059D78u);  // 06059CC0 mov.l 0x06059D78,r1
    c.r[2] = c.r[9];  // 06059CC2 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06059CC4 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059CC6 shll2 r2
    c.r[2] <<= 2;  // 06059CC8 shll2 r2
    c.r[2] += c.r[1];  // 06059CCA add r1,r2
    c.r[2] += 10;  // 06059CCC add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059CCE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06059CD0 extu.b r1,r1
    c.r[1] >>= 2;  // 06059CD2 shlr2 r1
    c.r[1] >>= 2;  // 06059CD4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06059CD6 shlr r1
    c.r[1] >>= 2;  // 06059CD8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06059CDA tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06059D26; } }  // 06059CDC bf/s 0x06059D26 ; mov #1,r1
    c.t = (c.r[12] & c.r[12]) == 0; goto L_06059D2A;  // 06059CE0 bra 0x06059D2A ; tst r12,r12
L_06059CE4:
    c.r[0] = c.r[12];  // 06059CE4 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 06059CE6 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_06059CFE; } }  // 06059CE8 bf/s 0x06059CFE ; mov r9,r2
    c.r[1] = ld32(0x06059D78u);  // 06059CEC mov.l 0x06059D78,r1
    c.r[1] = ld32(c.r[1]);  // 06059CEE mov.l @r1,r1
    c.r[2] <<= 2;  // 06059CF0 shll2 r2
    c.r[2] <<= 2;  // 06059CF2 shll2 r2
    c.r[2] += c.r[1];  // 06059CF4 add r1,r2
    c.r[2] += 10;  // 06059CF6 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059CF8 mov.b @r2,r0
    c.r[0] |= 0x80u; goto L_06059D24;  // 06059CFA bra 0x06059D24 ; or #128,r0
L_06059CFE:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06059CFE exts.w r9,r4
    c.r[1] = ld32(0x06059D88u);  // 06059D00 mov.l 0x06059D88,r1
    c.r[6] = 0x0u;  // 06059D02 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059D08u; c.r[5] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059D08u) return; }  // 06059D04 jsr @r1 ; mov #29,r5
    c.r[1] = ld32(0x06059D8Cu);  // 06059D08 mov.l 0x06059D8C,r1
    c.r[2] = ld32(c.r[1]);  // 06059D0A mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059D72u);  // 06059D0C mov.w 0x06059D72,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059D74u);  // 06059D0E mov.w 0x06059D74,r1
    c.r[2] += c.r[1];  // 06059D10 add r1,r2
    c.r[1] = ld32(0x06059D90u);  // 06059D12 mov.l 0x06059D90,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059D14 mov.w @r1,r1
    c.r[0] += c.r[14];  // 06059D16 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059D18 extu.w r1,r1
    c.r[1] <<= 2;  // 06059D1A shll2 r1
    c.r[1] += c.r[1];  // 06059D1C add r1,r1
    c.r[2] += c.r[1];  // 06059D1E add r1,r2
    c.r[2] += 4;  // 06059D20 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06059D22 mov.b @r0,r0
L_06059D24:
    st8(c.r[2], c.r[0]);  // 06059D24 mov.b r0,@r2
L_06059D26:
    c.r[1] = 0x0u;  // 06059D26 mov #0,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059D28 tst r12,r12
L_06059D2A:
    { const bool k = !c.t; c.r[11] += c.r[1]; if (k) { goto L_06059D52; } }  // 06059D2A bf/s 0x06059D52 ; add r1,r11
    c.r[1] = ld32(0x06059D78u);  // 06059D2E mov.l 0x06059D78,r1
    c.r[2] = c.r[9];  // 06059D30 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06059D32 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059D34 shll2 r2
    c.r[2] <<= 2;  // 06059D36 shll2 r2
    c.r[2] += c.r[1];  // 06059D38 add r1,r2
    c.r[2] += 10;  // 06059D3A add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059D3C mov.b @r2,r1
    c.r[0] = c.r[1];  // 06059D3E mov r1,r0
    c.r[0] >>= 2;  // 06059D40 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06059D42 shlr r0
    c.r[0] >>= 2;  // 06059D44 shlr2 r0
    c.r[0] &= 0x1u;  // 06059D46 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059D48 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06059DBC; } }  // 06059D4A bf/s 0x06059DBC ; mov #1,r1
    c.t = (c.r[12] & c.r[12]) == 0; goto L_06059DC0;  // 06059D4E bra 0x06059DC0 ; tst r12,r12
L_06059D52:
    c.r[0] = c.r[12];  // 06059D52 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 06059D54 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_06059D94; } }  // 06059D56 bf/s 0x06059D94 ; mov r9,r2
    c.r[1] = ld32(0x06059D78u);  // 06059D5A mov.l 0x06059D78,r1
    c.r[1] = ld32(c.r[1]);  // 06059D5C mov.l @r1,r1
    c.r[2] <<= 2;  // 06059D5E shll2 r2
    c.r[2] <<= 2;  // 06059D60 shll2 r2
    c.r[2] += c.r[1];  // 06059D62 add r1,r2
    c.r[2] += 10;  // 06059D64 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059D66 mov.b @r2,r0
    c.r[0] |= 0x20u; goto L_06059DBA;  // 06059D68 bra 0x06059DBA ; or #32,r0
L_06059D94:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06059D94 exts.w r9,r4
    c.r[1] = ld32(0x06059EC0u);  // 06059D96 mov.l 0x06059EC0,r1
    c.r[6] = 0x0u;  // 06059D98 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059D9Eu; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059D9Eu) return; }  // 06059D9A jsr @r1 ; mov #27,r5
    c.r[1] = ld32(0x06059EC4u);  // 06059D9E mov.l 0x06059EC4,r1
    c.r[2] = ld32(c.r[1]);  // 06059DA0 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059EBCu);  // 06059DA2 mov.w 0x06059EBC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059EBEu);  // 06059DA4 mov.w 0x06059EBE,r1
    c.r[2] += c.r[1];  // 06059DA6 add r1,r2
    c.r[1] = ld32(0x06059EC8u);  // 06059DA8 mov.l 0x06059EC8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059DAA mov.w @r1,r1
    c.r[0] += c.r[14];  // 06059DAC add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059DAE extu.w r1,r1
    c.r[1] <<= 2;  // 06059DB0 shll2 r1
    c.r[1] += c.r[1];  // 06059DB2 add r1,r1
    c.r[2] += c.r[1];  // 06059DB4 add r1,r2
    c.r[2] += 4;  // 06059DB6 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06059DB8 mov.b @r0,r0
L_06059DBA:
    st8(c.r[2], c.r[0]);  // 06059DBA mov.b r0,@r2
L_06059DBC:
    c.r[1] = 0x0u;  // 06059DBC mov #0,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059DBE tst r12,r12
L_06059DC0:
    { const bool k = !c.t; c.r[11] += c.r[1]; if (k) { goto L_06059DE6; } }  // 06059DC0 bf/s 0x06059DE6 ; add r1,r11
    c.r[1] = ld32(0x06059ECCu);  // 06059DC4 mov.l 0x06059ECC,r1
    c.r[2] = c.r[9];  // 06059DC6 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06059DC8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059DCA shll2 r2
    c.r[2] <<= 2;  // 06059DCC shll2 r2
    c.r[2] += c.r[1];  // 06059DCE add r1,r2
    c.r[2] += 10;  // 06059DD0 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059DD2 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06059DD4 mov r1,r0
    c.r[0] >>= 2;  // 06059DD6 shlr2 r0
    c.r[0] >>= 2;  // 06059DD8 shlr2 r0
    c.r[0] &= 0x1u;  // 06059DDA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059DDC tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06059E28; } }  // 06059DDE bf/s 0x06059E28 ; mov #1,r1
    c.t = (c.r[12] & c.r[12]) == 0; goto L_06059E2C;  // 06059DE2 bra 0x06059E2C ; tst r12,r12
L_06059DE6:
    c.r[0] = c.r[12];  // 06059DE6 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 06059DE8 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_06059E00; } }  // 06059DEA bf/s 0x06059E00 ; mov r9,r2
    c.r[1] = ld32(0x06059ECCu);  // 06059DEE mov.l 0x06059ECC,r1
    c.r[1] = ld32(c.r[1]);  // 06059DF0 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059DF2 shll2 r2
    c.r[2] <<= 2;  // 06059DF4 shll2 r2
    c.r[2] += c.r[1];  // 06059DF6 add r1,r2
    c.r[2] += 10;  // 06059DF8 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059DFA mov.b @r2,r0
    c.r[0] |= 0x10u; goto L_06059E26;  // 06059DFC bra 0x06059E26 ; or #16,r0
L_06059E00:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06059E00 exts.w r9,r4
    c.r[1] = ld32(0x06059EC0u);  // 06059E02 mov.l 0x06059EC0,r1
    c.r[6] = 0x0u;  // 06059E04 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059E0Au; c.r[5] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059E0Au) return; }  // 06059E06 jsr @r1 ; mov #22,r5
    c.r[1] = ld32(0x06059EC4u);  // 06059E0A mov.l 0x06059EC4,r1
    c.r[2] = ld32(c.r[1]);  // 06059E0C mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059EBCu);  // 06059E0E mov.w 0x06059EBC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059EBEu);  // 06059E10 mov.w 0x06059EBE,r1
    c.r[2] += c.r[1];  // 06059E12 add r1,r2
    c.r[1] = ld32(0x06059EC8u);  // 06059E14 mov.l 0x06059EC8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059E16 mov.w @r1,r1
    c.r[0] += c.r[14];  // 06059E18 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059E1A extu.w r1,r1
    c.r[1] <<= 2;  // 06059E1C shll2 r1
    c.r[1] += c.r[1];  // 06059E1E add r1,r1
    c.r[2] += c.r[1];  // 06059E20 add r1,r2
    c.r[2] += 4;  // 06059E22 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06059E24 mov.b @r0,r0
L_06059E26:
    st8(c.r[2], c.r[0]);  // 06059E26 mov.b r0,@r2
L_06059E28:
    c.r[1] = 0x0u;  // 06059E28 mov #0,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059E2A tst r12,r12
L_06059E2C:
    { const bool k = !c.t; c.r[11] += c.r[1]; if (k) { goto L_06059E52; } }  // 06059E2C bf/s 0x06059E52 ; add r1,r11
    c.r[1] = ld32(0x06059ECCu);  // 06059E30 mov.l 0x06059ECC,r1
    c.r[2] = c.r[9];  // 06059E32 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06059E34 mov.l @r1,r1
    c.r[2] <<= 2;  // 06059E36 shll2 r2
    c.r[2] <<= 2;  // 06059E38 shll2 r2
    c.r[2] += c.r[1];  // 06059E3A add r1,r2
    c.r[2] += 10;  // 06059E3C add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059E3E mov.b @r2,r1
    c.r[0] = c.r[1];  // 06059E40 mov r1,r0
    c.r[0] >>= 2;  // 06059E42 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06059E44 shlr r0
    c.r[0] &= 0x1u;  // 06059E46 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059E48 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06059E94; } }  // 06059E4A bf/s 0x06059E94 ; mov #1,r1
    c.t = (c.r[12] & c.r[12]) == 0; goto L_06059E98;  // 06059E4E bra 0x06059E98 ; tst r12,r12
L_06059E52:
    c.r[0] = c.r[12];  // 06059E52 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 06059E54 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_06059E6C; } }  // 06059E56 bf/s 0x06059E6C ; mov r9,r2
    c.r[1] = ld32(0x06059ECCu);  // 06059E5A mov.l 0x06059ECC,r1
    c.r[1] = ld32(c.r[1]);  // 06059E5C mov.l @r1,r1
    c.r[2] <<= 2;  // 06059E5E shll2 r2
    c.r[2] <<= 2;  // 06059E60 shll2 r2
    c.r[2] += c.r[1];  // 06059E62 add r1,r2
    c.r[2] += 10;  // 06059E64 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059E66 mov.b @r2,r0
    c.r[0] |= 0x8u; goto L_06059E92;  // 06059E68 bra 0x06059E92 ; or #8,r0
L_06059E6C:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06059E6C exts.w r9,r4
    c.r[1] = ld32(0x06059EC0u);  // 06059E6E mov.l 0x06059EC0,r1
    c.r[6] = 0x0u;  // 06059E70 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059E76u; c.r[5] = 0x18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059E76u) return; }  // 06059E72 jsr @r1 ; mov #24,r5
    c.r[1] = ld32(0x06059EC4u);  // 06059E76 mov.l 0x06059EC4,r1
    c.r[2] = ld32(c.r[1]);  // 06059E78 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059EBCu);  // 06059E7A mov.w 0x06059EBC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059EBEu);  // 06059E7C mov.w 0x06059EBE,r1
    c.r[2] += c.r[1];  // 06059E7E add r1,r2
    c.r[1] = ld32(0x06059EC8u);  // 06059E80 mov.l 0x06059EC8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059E82 mov.w @r1,r1
    c.r[0] += c.r[14];  // 06059E84 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059E86 extu.w r1,r1
    c.r[1] <<= 2;  // 06059E88 shll2 r1
    c.r[1] += c.r[1];  // 06059E8A add r1,r1
    c.r[2] += c.r[1];  // 06059E8C add r1,r2
    c.r[2] += 4;  // 06059E8E add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06059E90 mov.b @r0,r0
L_06059E92:
    st8(c.r[2], c.r[0]);  // 06059E92 mov.b r0,@r2
L_06059E94:
    c.r[1] = 0x0u;  // 06059E94 mov #0,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059E96 tst r12,r12
L_06059E98:
    { const bool k = !c.t; c.r[11] += c.r[1]; if (k) { goto L_06059ED0; } }  // 06059E98 bf/s 0x06059ED0 ; add r1,r11
    c.r[1] = ld32(0x06059ECCu);  // 06059E9C mov.l 0x06059ECC,r1
    c.r[1] = ld32(c.r[1]);  // 06059E9E mov.l @r1,r1
    c.r[9] <<= 2;  // 06059EA0 shll2 r9
    c.r[9] <<= 2;  // 06059EA2 shll2 r9
    c.r[9] += c.r[1];  // 06059EA4 add r1,r9
    c.r[9] += 11;  // 06059EA6 add #11,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06059EA8 mov.b @r9,r1
    c.r[0] = c.r[1];  // 06059EAA mov r1,r0
    c.r[0] >>= 2;  // 06059EAC shlr2 r0
    c.r[0] >>= 2;  // 06059EAE shlr2 r0
    c.r[0] &= 0x1u;  // 06059EB0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059EB2 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06059F30; } }  // 06059EB4 bf/s 0x06059F30 ; mov #1,r1
    c.r[11] += c.r[1]; goto L_0605A44E;  // 06059EB8 bra 0x0605A44E ; add r1,r11
L_06059ED0:
    c.r[0] = c.r[12];  // 06059ED0 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 06059ED2 cmp/eq #2,r0
    { const bool k = !c.t; c.r[3] = c.r[9]; if (k) { goto L_06059F08; } }  // 06059ED4 bf/s 0x06059F08 ; mov r9,r3
    c.r[1] = ld32(0x06059F7Cu);  // 06059ED8 mov.l 0x06059F7C,r1
    c.r[2] = ld32(c.r[1]);  // 06059EDA mov.l @r1,r2
    c.r[3] <<= 2;  // 06059EDC shll2 r3
    c.r[3] <<= 2;  // 06059EDE shll2 r3
    c.r[2] += c.r[3];  // 06059EE0 add r3,r2
    c.r[2] += 11;  // 06059EE2 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059EE4 mov.b @r2,r0
    c.r[0] |= 0x10u;  // 06059EE6 or #16,r0
    st8(c.r[2], c.r[0]);  // 06059EE8 mov.b r0,@r2
    c.r[1] = ld32(c.r[1]);  // 06059EEA mov.l @r1,r1
    c.r[1] += c.r[3];  // 06059EEC add r3,r1
    c.r[1] += 10;  // 06059EEE add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06059EF0 mov.b @r1,r2
    c.r[0] = c.r[2];  // 06059EF2 mov r2,r0
    c.r[0] >>= 2;  // 06059EF4 shlr2 r0
    c.r[0] >>= 2;  // 06059EF6 shlr2 r0
    c.r[0] >>= 2;  // 06059EF8 shlr2 r0
    c.r[0] &= 0x1u;  // 06059EFA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06059EFC tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06059F30; } }  // 06059EFE bt/s 0x06059F30 ; mov r2,r0
    c.r[0] &= 0xBFu;  // 06059F02 and #191,r0
    st8(c.r[1], c.r[0]); goto L_06059F30;  // 06059F04 bra 0x06059F30 ; mov.b r0,@r1
L_06059F08:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06059F08 exts.w r9,r4
    c.r[1] = ld32(0x06059F80u);  // 06059F0A mov.l 0x06059F80,r1
    c.r[6] = 0x0u;  // 06059F0C mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06059F12u; c.r[5] = 0x29u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059F12u) return; }  // 06059F0E jsr @r1 ; mov #41,r5
    c.r[1] = ld32(0x06059F84u);  // 06059F12 mov.l 0x06059F84,r1
    c.r[2] = ld32(c.r[1]);  // 06059F14 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06059F76u);  // 06059F16 mov.w 0x06059F76,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06059F78u);  // 06059F18 mov.w 0x06059F78,r1
    c.r[2] += c.r[1];  // 06059F1A add r1,r2
    c.r[1] = ld32(0x06059F88u);  // 06059F1C mov.l 0x06059F88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059F1E mov.w @r1,r1
    c.r[0] += c.r[14];  // 06059F20 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059F22 extu.w r1,r1
    c.r[1] <<= 2;  // 06059F24 shll2 r1
    c.r[1] += c.r[1];  // 06059F26 add r1,r1
    c.r[2] += c.r[1];  // 06059F28 add r1,r2
    c.r[2] += 4;  // 06059F2A add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06059F2C mov.b @r0,r0
    st8(c.r[2], c.r[0]);  // 06059F2E mov.b r0,@r2
L_06059F30:
    c.r[1] = 0x0u;  // 06059F30 mov #0,r1
    c.r[11] += c.r[1]; goto L_0605A44E;  // 06059F32 bra 0x0605A44E ; add r1,r11
L_06059F36:
    c.r[1] = ld32(0x06059F7Cu);  // 06059F36 mov.l 0x06059F7C,r1
    c.r[2] = c.r[9];  // 06059F38 mov r9,r2
    c.r[2] <<= 2;  // 06059F3A shll2 r2
    c.r[2] <<= 2;  // 06059F3C shll2 r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06059F7Au);  // 06059F3E mov.w 0x06059F7A,r6
    c.r[1] = ld32(c.r[1]);  // 06059F40 mov.l @r1,r1
    c.r[4] = c.r[14];  // 06059F42 mov r14,r4
    c.r[2] += c.r[1];  // 06059F44 add r1,r2
    c.r[2] += 2;  // 06059F46 add #2,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059F48 mov.b @r2,r8
    c.r[1] = ld32(0x06059F8Cu);  // 06059F4A mov.l 0x06059F8C,r1
    c.r[8] = c.r[8] & 0xFFu;  // 06059F4C extu.b r8,r8
    { const uint32_t x = c.r[1]; c.pr = 0x06059F52u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059F52u) return; }  // 06059F4E jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06059F90u);  // 06059F52 mov.l 0x06059F90,r1
    c.r[2] = ld32(c.r[1]);  // 06059F54 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06059F56 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06059F58 mul.l r1,r8
    c.r[3] = c.macl;  // 06059F5A sts macl,r3
    c.r[3] += c.r[2];  // 06059F5C add r2,r3
    c.r[3] += 22;  // 06059F5E add #22,r3
    c.r[1] = c.r[14];  // 06059F60 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06059F62 mov.w @r3,r2
    c.r[1] += 26;  // 06059F64 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059F66 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06059F68 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059F6A extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06059F6C cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06059F94; } }  // 06059F6E bt/s 0x06059F94 ; mov #0,r1
    c.r[1] = 0x1u; goto L_06059F94;  // 06059F72 bra 0x06059F94 ; mov #1,r1
L_06059F94:
    c.r[1] = c.r[1] & 0xFFu;  // 06059F94 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06059F96 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0605A026; } }  // 06059F98 bt/s 0x0605A026 ; mov r9,r2
    c.r[10] = ld32(0x0605A108u);  // 06059F9C mov.l 0x0605A108,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06059F9E mov.w @r10,r1
    c.r[2] <<= 2;  // 06059FA0 shll2 r2
    c.r[2] <<= 2;  // 06059FA2 shll2 r2
    c.r[11] = c.r[1] & 0xFFFFu;  // 06059FA4 extu.w r1,r11
    c.r[1] = ld32(0x0605A10Cu);  // 06059FA6 mov.l 0x0605A10C,r1
    c.r[1] = ld32(c.r[1]);  // 06059FA8 mov.l @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605A0FAu);  // 06059FAA mov.w 0x0605A0FA,r6
    c.r[2] += c.r[1];  // 06059FAC add r1,r2
    c.r[2] += 2;  // 06059FAE add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06059FB0 mov.b @r2,r1
    c.r[4] = c.r[14];  // 06059FB2 mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06059FB4 extu.b r1,r1
    c.r[8] = c.r[1];  // 06059FB6 mov r1,r8
    c.r[1] = ld32(0x0605A110u);  // 06059FB8 mov.l 0x0605A110,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06059FBEu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059FBEu) return; }  // 06059FBA jsr @r1 ; mov r8,r5
    c.t = (c.r[12] & c.r[12]) == 0;  // 06059FBE tst r12,r12
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_0605A008; } }  // 06059FC0 bt/s 0x0605A008 ; mov r12,r0
    c.t = c.r[0] == 0x1u;  // 06059FC4 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_0605A008; } }  // 06059FC6 bf/s 0x0605A008 ; mov r14,r1
    c.r[1] += 26;  // 06059FCA add #26,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059FCC mov.w @r1,r6
    c.r[1] = ld32(0x0605A114u);  // 06059FCE mov.l 0x0605A114,r1
    c.r[2] = ld32(c.r[1]);  // 06059FD0 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06059FD2 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06059FD4 mul.l r1,r8
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06059FD6 exts.w r9,r4
    c.r[1] = c.macl;  // 06059FD8 sts macl,r1
    c.r[1] += c.r[2];  // 06059FDA add r2,r1
    c.r[1] += 22;  // 06059FDC add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06059FDE mov.w @r1,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 06059FE0 extu.w r6,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059FE2 extu.w r1,r1
    c.r[6] -= c.r[1];  // 06059FE4 sub r1,r6
    c.r[1] = ld32(0x0605A118u);  // 06059FE6 mov.l 0x0605A118,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06059FECu; c.r[5] = 0x13u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06059FECu) return; }  // 06059FE8 jsr @r1 ; mov #19,r5
    c.r[1] = ld32(0x0605A11Cu);  // 06059FEC mov.l 0x0605A11C,r1
    c.r[2] = ld32(c.r[1]);  // 06059FEE mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A0FCu);  // 06059FF0 mov.w 0x0605A0FC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A0FEu);  // 06059FF2 mov.w 0x0605A0FE,r1
    c.r[2] += c.r[1];  // 06059FF4 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06059FF6 mov.w @r10,r1
    c.r[0] += c.r[14];  // 06059FF8 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06059FFA extu.w r1,r1
    c.r[1] <<= 2;  // 06059FFC shll2 r1
    c.r[1] += c.r[1];  // 06059FFE add r1,r1
    c.r[2] += c.r[1];  // 0605A000 add r1,r2
    c.r[2] += 4;  // 0605A002 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A004 mov.b @r0,r0
    st8(c.r[2], c.r[0]);  // 0605A006 mov.b r0,@r2
L_0605A008:
    c.r[1] = ld32(0x0605A108u);  // 0605A008 mov.l 0x0605A108,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A00A mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A00C extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A00E cmp/eq r3,r11
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0605A026; } }  // 0605A010 bt/s 0x0605A026 ; shll2 r3
    c.r[1] = ld32(0x0605A11Cu);  // 0605A014 mov.l 0x0605A11C,r1
    c.r[2] = ld32(c.r[1]);  // 0605A016 mov.l @r1,r2
    c.r[3] += c.r[3];  // 0605A018 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A0FEu);  // 0605A01A mov.w 0x0605A0FE,r1
    c.r[2] += c.r[1];  // 0605A01C add r1,r2
    c.r[2] += c.r[3];  // 0605A01E add r3,r2
    c.r[2] += 4;  // 0605A020 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A022 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A024 mov.b r1,@r2
L_0605A026:
    c.r[1] = ld32(0x0605A10Cu);  // 0605A026 mov.l 0x0605A10C,r1
    c.r[2] = c.r[9];  // 0605A028 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 0605A02A mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A02C shll2 r2
    c.r[2] <<= 2;  // 0605A02E shll2 r2
    c.r[2] += c.r[1];  // 0605A030 add r1,r2
    c.r[2] += 2;  // 0605A032 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A034 mov.b @r2,r2
    c.r[1] = ld32(0x0605A114u);  // 0605A036 mov.l 0x0605A114,r1
    c.r[3] = ld32(c.r[1]);  // 0605A038 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605A03A extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605A03C mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605A03E mul.l r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A100u);  // 0605A040 mov.w 0x0605A100,r0
    c.r[0] += c.r[14];  // 0605A042 add r14,r0
    c.r[1] = c.macl;  // 0605A044 sts macl,r1
    c.r[1] += c.r[3];  // 0605A046 add r3,r1
    c.r[1] += 15;  // 0605A048 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A04A mov.b @r1,r1
    c.r[8] = 0x0u;  // 0605A04C mov #0,r8
    c.r[10] = c.r[1] & 0xFFu;  // 0605A04E extu.b r1,r10
    c.r[1] = ld32(0x0605A120u);  // 0605A050 mov.l 0x0605A120,r1
    c.r[2] = c.r[10];  // 0605A052 mov r10,r2
    c.r[2] += c.r[2];  // 0605A054 add r2,r2
    c.r[2] += c.r[10];  // 0605A056 add r10,r2
    c.r[1] = ld32(c.r[1]);  // 0605A058 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A05A shll2 r2
    c.r[2] += c.r[1];  // 0605A05C add r1,r2
    c.r[2] += 9;  // 0605A05E add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A060 mov.b @r2,r1
    c.r[13] = ld32(0x0605A108u);  // 0605A062 mov.l 0x0605A108,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0605A064 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0605A066 mov.l r1,@r0
    c.r[6] = 0x0u;  // 0605A068 mov #0,r6
L_0605A06A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A102u);  // 0605A06A mov.w 0x0605A102,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 0605A06C mov.l @(r0,r14),r4
    c.r[0] = ld32(0x0605A124u);  // 0605A06E mov.l 0x0605A124,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605A074u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A074u) return; }  // 0605A070 jsr @r0 ; mov r9,r5
    c.r[1] = c.r[0];  // 0605A074 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A076 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A078 tst r1,r1
    { const bool k = c.t; c.r[6] = c.r[12]; if (k) { goto L_0605A0A8; } }  // 0605A07A bt/s 0x0605A0A8 ; mov r12,r6
    c.r[5] = c.r[9];  // 0605A07E mov r9,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A102u);  // 0605A080 mov.w 0x0605A102,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0605A082 mov.w @r13,r1
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 0605A084 mov.l @(r0,r14),r4
    c.r[0] = ld32(0x0605A124u);  // 0605A086 mov.l 0x0605A124,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605A08Cu; c.r[11] = c.r[1] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A08Cu) return; }  // 0605A088 jsr @r0 ; extu.w r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0605A08C mov.w @r13,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A08E extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A090 cmp/eq r3,r11
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0605A0A8; } }  // 0605A092 bt/s 0x0605A0A8 ; shll2 r3
    c.r[1] = ld32(0x0605A11Cu);  // 0605A096 mov.l 0x0605A11C,r1
    c.r[2] = ld32(c.r[1]);  // 0605A098 mov.l @r1,r2
    c.r[3] += c.r[3];  // 0605A09A add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A0FEu);  // 0605A09C mov.w 0x0605A0FE,r1
    c.r[2] += c.r[1];  // 0605A09E add r1,r2
    c.r[2] += c.r[3];  // 0605A0A0 add r3,r2
    c.r[2] += 4;  // 0605A0A2 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A0A4 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A0A6 mov.b r1,@r2
L_0605A0A8:
    c.r[7] = ld32(0x0605A120u);  // 0605A0A8 mov.l 0x0605A120,r7
    c.r[3] = c.r[10];  // 0605A0AA mov r10,r3
    c.r[3] += c.r[3];  // 0605A0AC add r3,r3
    c.r[3] += c.r[10];  // 0605A0AE add r10,r3
    c.r[1] = ld32(c.r[7]);  // 0605A0B0 mov.l @r7,r1
    c.r[3] <<= 2;  // 0605A0B2 shll2 r3
    c.r[1] += c.r[3];  // 0605A0B4 add r3,r1
    c.r[1] += 9;  // 0605A0B6 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A0B8 mov.b @r1,r2
    c.r[8] += 1;  // 0605A0BA add #1,r8
    c.r[2] += 10;  // 0605A0BC add #10,r2
    st8(c.r[1], c.r[2]);  // 0605A0BE mov.b r2,@r1
    c.r[1] = 0x2u;  // 0605A0C0 mov #2,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0605A0C2 cmp/gt r1,r8
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { SH2_POLL(c); goto L_0605A06A; } }  // 0605A0C4 bf/s 0x0605A06A ; mov #0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A104u);  // 0605A0C8 mov.w 0x0605A104,r0
    c.r[0] += c.r[14];  // 0605A0CA add r14,r0
    c.r[1] = ld32(c.r[7]);  // 0605A0CC mov.l @r7,r1
    c.r[2] = c.r[9];  // 0605A0CE mov r9,r2
    c.r[3] += c.r[1];  // 0605A0D0 add r1,r3
    c.r[3] += 9;  // 0605A0D2 add #9,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A0D4 mov.b @r0,r0
    c.r[1] = ld32(0x0605A10Cu);  // 0605A0D6 mov.l 0x0605A10C,r1
    st8(c.r[3], c.r[0]);  // 0605A0D8 mov.b r0,@r3
    c.r[1] = ld32(c.r[1]);  // 0605A0DA mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A0DC shll2 r2
    c.r[2] <<= 2;  // 0605A0DE shll2 r2
    c.r[2] += c.r[1];  // 0605A0E0 add r1,r2
    c.r[2] += 10;  // 0605A0E2 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A0E4 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A0E6 extu.b r1,r1
    c.r[1] >>= 2;  // 0605A0E8 shlr2 r1
    c.r[1] >>= 2;  // 0605A0EA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605A0EC shlr r1
    c.r[1] >>= 2;  // 0605A0EE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A0F0 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0605A128; } }  // 0605A0F2 bf/s 0x0605A128 ; mov #1,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_0605A12C;  // 0605A0F6 bra 0x0605A12C ; extu.b r1,r1
L_0605A128:
    c.r[1] = 0x0u;  // 0605A128 mov #0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A12A extu.b r1,r1
L_0605A12C:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A12C tst r1,r1
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0605A198; } }  // 0605A12E bt/s 0x0605A198 ; tst r12,r12
    c.r[8] = ld32(0x0605A278u);  // 0605A132 mov.l 0x0605A278,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A134 mov.w @r8,r1
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFFFu; if (k) { goto L_0605A17A; } }  // 0605A136 bt/s 0x0605A17A ; extu.w r1,r11
    c.r[0] = c.r[12];  // 0605A13A mov r12,r0
    c.t = c.r[0] == 0x2u;  // 0605A13C cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_0605A154; } }  // 0605A13E bf/s 0x0605A154 ; mov r9,r2
    c.r[1] = ld32(0x0605A27Cu);  // 0605A142 mov.l 0x0605A27C,r1
    c.r[1] = ld32(c.r[1]);  // 0605A144 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A146 shll2 r2
    c.r[2] <<= 2;  // 0605A148 shll2 r2
    c.r[2] += c.r[1];  // 0605A14A add r1,r2
    c.r[2] += 10;  // 0605A14C add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A14E mov.b @r2,r0
    c.r[0] |= 0x80u; goto L_0605A178;  // 0605A150 bra 0x0605A178 ; or #128,r0
L_0605A154:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0605A154 exts.w r9,r4
    c.r[1] = ld32(0x0605A280u);  // 0605A156 mov.l 0x0605A280,r1
    c.r[6] = 0x0u;  // 0605A158 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A15Eu; c.r[5] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A15Eu) return; }  // 0605A15A jsr @r1 ; mov #29,r5
    c.r[1] = ld32(0x0605A284u);  // 0605A15E mov.l 0x0605A284,r1
    c.r[2] = ld32(c.r[1]);  // 0605A160 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A272u);  // 0605A162 mov.w 0x0605A272,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A274u);  // 0605A164 mov.w 0x0605A274,r1
    c.r[2] += c.r[1];  // 0605A166 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A168 mov.w @r8,r1
    c.r[0] += c.r[14];  // 0605A16A add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A16C extu.w r1,r1
    c.r[1] <<= 2;  // 0605A16E shll2 r1
    c.r[1] += c.r[1];  // 0605A170 add r1,r1
    c.r[2] += c.r[1];  // 0605A172 add r1,r2
    c.r[2] += 4;  // 0605A174 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A176 mov.b @r0,r0
L_0605A178:
    st8(c.r[2], c.r[0]);  // 0605A178 mov.b r0,@r2
L_0605A17A:
    c.r[1] = ld32(0x0605A278u);  // 0605A17A mov.l 0x0605A278,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A17C mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A17E extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A180 cmp/eq r3,r11
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0605A198; } }  // 0605A182 bt/s 0x0605A198 ; shll2 r3
    c.r[1] = ld32(0x0605A284u);  // 0605A186 mov.l 0x0605A284,r1
    c.r[2] = ld32(c.r[1]);  // 0605A188 mov.l @r1,r2
    c.r[3] += c.r[3];  // 0605A18A add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A274u);  // 0605A18C mov.w 0x0605A274,r1
    c.r[2] += c.r[1];  // 0605A18E add r1,r2
    c.r[2] += c.r[3];  // 0605A190 add r3,r2
    c.r[2] += 4;  // 0605A192 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A194 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A196 mov.b r1,@r2
L_0605A198:
    c.r[1] = ld32(0x0605A27Cu);  // 0605A198 mov.l 0x0605A27C,r1
    c.r[2] = c.r[9];  // 0605A19A mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 0605A19C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A19E shll2 r2
    c.r[2] <<= 2;  // 0605A1A0 shll2 r2
    c.r[2] += c.r[1];  // 0605A1A2 add r1,r2
    c.r[2] += 10;  // 0605A1A4 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A1A6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605A1A8 mov r1,r0
    c.r[0] >>= 2;  // 0605A1AA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605A1AC shlr r0
    c.r[0] >>= 2;  // 0605A1AE shlr2 r0
    c.r[0] &= 0x1u;  // 0605A1B0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605A1B2 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0605A1BA; } }  // 0605A1B4 bt/s 0x0605A1BA ; mov #1,r1
    c.r[1] = 0x0u;  // 0605A1B8 mov #0,r1
L_0605A1BA:
    c.r[1] = c.r[1] & 0xFFu;  // 0605A1BA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A1BC tst r1,r1
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0605A228; } }  // 0605A1BE bt/s 0x0605A228 ; tst r12,r12
    c.r[8] = ld32(0x0605A278u);  // 0605A1C2 mov.l 0x0605A278,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A1C4 mov.w @r8,r1
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFFFu; if (k) { goto L_0605A20A; } }  // 0605A1C6 bt/s 0x0605A20A ; extu.w r1,r11
    c.r[0] = c.r[12];  // 0605A1CA mov r12,r0
    c.t = c.r[0] == 0x2u;  // 0605A1CC cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_0605A1E4; } }  // 0605A1CE bf/s 0x0605A1E4 ; mov r9,r2
    c.r[1] = ld32(0x0605A27Cu);  // 0605A1D2 mov.l 0x0605A27C,r1
    c.r[1] = ld32(c.r[1]);  // 0605A1D4 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A1D6 shll2 r2
    c.r[2] <<= 2;  // 0605A1D8 shll2 r2
    c.r[2] += c.r[1];  // 0605A1DA add r1,r2
    c.r[2] += 10;  // 0605A1DC add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A1DE mov.b @r2,r0
    c.r[0] |= 0x20u; goto L_0605A208;  // 0605A1E0 bra 0x0605A208 ; or #32,r0
L_0605A1E4:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0605A1E4 exts.w r9,r4
    c.r[1] = ld32(0x0605A280u);  // 0605A1E6 mov.l 0x0605A280,r1
    c.r[6] = 0x0u;  // 0605A1E8 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A1EEu; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A1EEu) return; }  // 0605A1EA jsr @r1 ; mov #27,r5
    c.r[1] = ld32(0x0605A284u);  // 0605A1EE mov.l 0x0605A284,r1
    c.r[2] = ld32(c.r[1]);  // 0605A1F0 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A272u);  // 0605A1F2 mov.w 0x0605A272,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A274u);  // 0605A1F4 mov.w 0x0605A274,r1
    c.r[2] += c.r[1];  // 0605A1F6 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A1F8 mov.w @r8,r1
    c.r[0] += c.r[14];  // 0605A1FA add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A1FC extu.w r1,r1
    c.r[1] <<= 2;  // 0605A1FE shll2 r1
    c.r[1] += c.r[1];  // 0605A200 add r1,r1
    c.r[2] += c.r[1];  // 0605A202 add r1,r2
    c.r[2] += 4;  // 0605A204 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A206 mov.b @r0,r0
L_0605A208:
    st8(c.r[2], c.r[0]);  // 0605A208 mov.b r0,@r2
L_0605A20A:
    c.r[1] = ld32(0x0605A278u);  // 0605A20A mov.l 0x0605A278,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A20C mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A20E extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A210 cmp/eq r3,r11
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0605A228; } }  // 0605A212 bt/s 0x0605A228 ; shll2 r3
    c.r[1] = ld32(0x0605A284u);  // 0605A216 mov.l 0x0605A284,r1
    c.r[2] = ld32(c.r[1]);  // 0605A218 mov.l @r1,r2
    c.r[3] += c.r[3];  // 0605A21A add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A274u);  // 0605A21C mov.w 0x0605A274,r1
    c.r[2] += c.r[1];  // 0605A21E add r1,r2
    c.r[2] += c.r[3];  // 0605A220 add r3,r2
    c.r[2] += 4;  // 0605A222 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A224 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A226 mov.b r1,@r2
L_0605A228:
    c.r[1] = ld32(0x0605A27Cu);  // 0605A228 mov.l 0x0605A27C,r1
    c.r[2] = c.r[9];  // 0605A22A mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 0605A22C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A22E shll2 r2
    c.r[2] <<= 2;  // 0605A230 shll2 r2
    c.r[2] += c.r[1];  // 0605A232 add r1,r2
    c.r[2] += 10;  // 0605A234 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A236 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605A238 mov r1,r0
    c.r[0] >>= 2;  // 0605A23A shlr2 r0
    c.r[0] >>= 2;  // 0605A23C shlr2 r0
    c.r[0] &= 0x1u;  // 0605A23E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605A240 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0605A248; } }  // 0605A242 bt/s 0x0605A248 ; mov #1,r1
    c.r[1] = 0x0u;  // 0605A246 mov #0,r1
L_0605A248:
    c.r[1] = c.r[1] & 0xFFu;  // 0605A248 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A24A tst r1,r1
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0605A2CC; } }  // 0605A24C bt/s 0x0605A2CC ; tst r12,r12
    c.r[8] = ld32(0x0605A278u);  // 0605A250 mov.l 0x0605A278,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A252 mov.w @r8,r1
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFFFu; if (k) { goto L_0605A2AE; } }  // 0605A254 bt/s 0x0605A2AE ; extu.w r1,r11
    c.r[0] = c.r[12];  // 0605A258 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 0605A25A cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_0605A288; } }  // 0605A25C bf/s 0x0605A288 ; mov r9,r2
    c.r[1] = ld32(0x0605A27Cu);  // 0605A260 mov.l 0x0605A27C,r1
    c.r[1] = ld32(c.r[1]);  // 0605A262 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A264 shll2 r2
    c.r[2] <<= 2;  // 0605A266 shll2 r2
    c.r[2] += c.r[1];  // 0605A268 add r1,r2
    c.r[2] += 10;  // 0605A26A add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A26C mov.b @r2,r0
    c.r[0] |= 0x10u; goto L_0605A2AC;  // 0605A26E bra 0x0605A2AC ; or #16,r0
L_0605A288:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0605A288 exts.w r9,r4
    c.r[1] = ld32(0x0605A380u);  // 0605A28A mov.l 0x0605A380,r1
    c.r[6] = 0x0u;  // 0605A28C mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A292u; c.r[5] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A292u) return; }  // 0605A28E jsr @r1 ; mov #22,r5
    c.r[1] = ld32(0x0605A384u);  // 0605A292 mov.l 0x0605A384,r1
    c.r[2] = ld32(c.r[1]);  // 0605A294 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A37Cu);  // 0605A296 mov.w 0x0605A37C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A37Eu);  // 0605A298 mov.w 0x0605A37E,r1
    c.r[2] += c.r[1];  // 0605A29A add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A29C mov.w @r8,r1
    c.r[0] += c.r[14];  // 0605A29E add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A2A0 extu.w r1,r1
    c.r[1] <<= 2;  // 0605A2A2 shll2 r1
    c.r[1] += c.r[1];  // 0605A2A4 add r1,r1
    c.r[2] += c.r[1];  // 0605A2A6 add r1,r2
    c.r[2] += 4;  // 0605A2A8 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A2AA mov.b @r0,r0
L_0605A2AC:
    st8(c.r[2], c.r[0]);  // 0605A2AC mov.b r0,@r2
L_0605A2AE:
    c.r[1] = ld32(0x0605A388u);  // 0605A2AE mov.l 0x0605A388,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A2B0 mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A2B2 extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A2B4 cmp/eq r3,r11
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0605A2CC; } }  // 0605A2B6 bt/s 0x0605A2CC ; shll2 r3
    c.r[1] = ld32(0x0605A384u);  // 0605A2BA mov.l 0x0605A384,r1
    c.r[2] = ld32(c.r[1]);  // 0605A2BC mov.l @r1,r2
    c.r[3] += c.r[3];  // 0605A2BE add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A37Eu);  // 0605A2C0 mov.w 0x0605A37E,r1
    c.r[2] += c.r[1];  // 0605A2C2 add r1,r2
    c.r[2] += c.r[3];  // 0605A2C4 add r3,r2
    c.r[2] += 4;  // 0605A2C6 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A2C8 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A2CA mov.b r1,@r2
L_0605A2CC:
    c.r[1] = ld32(0x0605A38Cu);  // 0605A2CC mov.l 0x0605A38C,r1
    c.r[2] = c.r[9];  // 0605A2CE mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 0605A2D0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A2D2 shll2 r2
    c.r[2] <<= 2;  // 0605A2D4 shll2 r2
    c.r[2] += c.r[1];  // 0605A2D6 add r1,r2
    c.r[2] += 10;  // 0605A2D8 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A2DA mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605A2DC mov r1,r0
    c.r[0] >>= 2;  // 0605A2DE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605A2E0 shlr r0
    c.r[0] &= 0x1u;  // 0605A2E2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605A2E4 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0605A2EC; } }  // 0605A2E6 bt/s 0x0605A2EC ; mov #1,r1
    c.r[1] = 0x0u;  // 0605A2EA mov #0,r1
L_0605A2EC:
    c.r[1] = c.r[1] & 0xFFu;  // 0605A2EC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A2EE tst r1,r1
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0605A35A; } }  // 0605A2F0 bt/s 0x0605A35A ; tst r12,r12
    c.r[8] = ld32(0x0605A388u);  // 0605A2F4 mov.l 0x0605A388,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A2F6 mov.w @r8,r1
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFFFu; if (k) { goto L_0605A33C; } }  // 0605A2F8 bt/s 0x0605A33C ; extu.w r1,r11
    c.r[0] = c.r[12];  // 0605A2FC mov r12,r0
    c.t = c.r[0] == 0x2u;  // 0605A2FE cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_0605A316; } }  // 0605A300 bf/s 0x0605A316 ; mov r9,r2
    c.r[1] = ld32(0x0605A38Cu);  // 0605A304 mov.l 0x0605A38C,r1
    c.r[1] = ld32(c.r[1]);  // 0605A306 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A308 shll2 r2
    c.r[2] <<= 2;  // 0605A30A shll2 r2
    c.r[2] += c.r[1];  // 0605A30C add r1,r2
    c.r[2] += 10;  // 0605A30E add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A310 mov.b @r2,r0
    c.r[0] |= 0x8u; goto L_0605A33A;  // 0605A312 bra 0x0605A33A ; or #8,r0
L_0605A316:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0605A316 exts.w r9,r4
    c.r[1] = ld32(0x0605A380u);  // 0605A318 mov.l 0x0605A380,r1
    c.r[6] = 0x0u;  // 0605A31A mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A320u; c.r[5] = 0x18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A320u) return; }  // 0605A31C jsr @r1 ; mov #24,r5
    c.r[1] = ld32(0x0605A384u);  // 0605A320 mov.l 0x0605A384,r1
    c.r[2] = ld32(c.r[1]);  // 0605A322 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A37Cu);  // 0605A324 mov.w 0x0605A37C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A37Eu);  // 0605A326 mov.w 0x0605A37E,r1
    c.r[2] += c.r[1];  // 0605A328 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A32A mov.w @r8,r1
    c.r[0] += c.r[14];  // 0605A32C add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A32E extu.w r1,r1
    c.r[1] <<= 2;  // 0605A330 shll2 r1
    c.r[1] += c.r[1];  // 0605A332 add r1,r1
    c.r[2] += c.r[1];  // 0605A334 add r1,r2
    c.r[2] += 4;  // 0605A336 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A338 mov.b @r0,r0
L_0605A33A:
    st8(c.r[2], c.r[0]);  // 0605A33A mov.b r0,@r2
L_0605A33C:
    c.r[1] = ld32(0x0605A388u);  // 0605A33C mov.l 0x0605A388,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A33E mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A340 extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A342 cmp/eq r3,r11
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0605A35A; } }  // 0605A344 bt/s 0x0605A35A ; shll2 r3
    c.r[1] = ld32(0x0605A384u);  // 0605A348 mov.l 0x0605A384,r1
    c.r[2] = ld32(c.r[1]);  // 0605A34A mov.l @r1,r2
    c.r[3] += c.r[3];  // 0605A34C add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A37Eu);  // 0605A34E mov.w 0x0605A37E,r1
    c.r[2] += c.r[1];  // 0605A350 add r1,r2
    c.r[2] += c.r[3];  // 0605A352 add r3,r2
    c.r[2] += 4;  // 0605A354 add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A356 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A358 mov.b r1,@r2
L_0605A35A:
    c.r[1] = ld32(0x0605A38Cu);  // 0605A35A mov.l 0x0605A38C,r1
    c.r[2] = c.r[9];  // 0605A35C mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 0605A35E mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A360 shll2 r2
    c.r[2] <<= 2;  // 0605A362 shll2 r2
    c.r[2] += c.r[1];  // 0605A364 add r1,r2
    c.r[2] += 11;  // 0605A366 add #11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A368 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605A36A mov r1,r0
    c.r[0] >>= 2;  // 0605A36C shlr2 r0
    c.r[0] >>= 2;  // 0605A36E shlr2 r0
    c.r[0] &= 0x1u;  // 0605A370 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605A372 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0605A390; } }  // 0605A374 bf/s 0x0605A390 ; mov #1,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_0605A394;  // 0605A378 bra 0x0605A394 ; extu.b r1,r1
L_0605A390:
    c.r[1] = 0x0u;  // 0605A390 mov #0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A392 extu.b r1,r1
L_0605A394:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A394 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_0605A422; } }  // 0605A396 bt/s 0x0605A422 ; mov r12,r0
    c.r[8] = ld32(0x0605A470u);  // 0605A39A mov.l 0x0605A470,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A39C mov.w @r8,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 0605A39E tst r12,r12
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFFFu; if (k) { goto L_0605A402; } }  // 0605A3A0 bt/s 0x0605A402 ; extu.w r1,r11
    c.r[0] = c.r[12];  // 0605A3A4 mov r12,r0
    c.t = c.r[0] == 0x2u;  // 0605A3A6 cmp/eq #2,r0
    { const bool k = !c.t; c.r[3] = c.r[9]; if (k) { goto L_0605A3DC; } }  // 0605A3A8 bf/s 0x0605A3DC ; mov r9,r3
    c.r[1] = ld32(0x0605A474u);  // 0605A3AC mov.l 0x0605A474,r1
    c.r[2] = ld32(c.r[1]);  // 0605A3AE mov.l @r1,r2
    c.r[3] <<= 2;  // 0605A3B0 shll2 r3
    c.r[3] <<= 2;  // 0605A3B2 shll2 r3
    c.r[2] += c.r[3];  // 0605A3B4 add r3,r2
    c.r[2] += 11;  // 0605A3B6 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A3B8 mov.b @r2,r0
    c.r[0] |= 0x10u;  // 0605A3BA or #16,r0
    st8(c.r[2], c.r[0]);  // 0605A3BC mov.b r0,@r2
    c.r[1] = ld32(c.r[1]);  // 0605A3BE mov.l @r1,r1
    c.r[1] += c.r[3];  // 0605A3C0 add r3,r1
    c.r[1] += 10;  // 0605A3C2 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A3C4 mov.b @r1,r2
    c.r[0] = c.r[2];  // 0605A3C6 mov r2,r0
    c.r[0] >>= 2;  // 0605A3C8 shlr2 r0
    c.r[0] >>= 2;  // 0605A3CA shlr2 r0
    c.r[0] >>= 2;  // 0605A3CC shlr2 r0
    c.r[0] &= 0x1u;  // 0605A3CE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605A3D0 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0605A402; } }  // 0605A3D2 bt/s 0x0605A402 ; mov r2,r0
    c.r[0] &= 0xBFu;  // 0605A3D6 and #191,r0
    st8(c.r[1], c.r[0]); goto L_0605A402;  // 0605A3D8 bra 0x0605A402 ; mov.b r0,@r1
L_0605A3DC:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0605A3DC exts.w r9,r4
    c.r[1] = ld32(0x0605A478u);  // 0605A3DE mov.l 0x0605A478,r1
    c.r[6] = 0x0u;  // 0605A3E0 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A3E6u; c.r[5] = 0x29u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A3E6u) return; }  // 0605A3E2 jsr @r1 ; mov #41,r5
    c.r[1] = ld32(0x0605A47Cu);  // 0605A3E6 mov.l 0x0605A47C,r1
    c.r[2] = ld32(c.r[1]);  // 0605A3E8 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A468u);  // 0605A3EA mov.w 0x0605A468,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A46Au);  // 0605A3EC mov.w 0x0605A46A,r1
    c.r[2] += c.r[1];  // 0605A3EE add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605A3F0 mov.w @r8,r1
    c.r[0] += c.r[14];  // 0605A3F2 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A3F4 extu.w r1,r1
    c.r[1] <<= 2;  // 0605A3F6 shll2 r1
    c.r[1] += c.r[1];  // 0605A3F8 add r1,r1
    c.r[2] += c.r[1];  // 0605A3FA add r1,r2
    c.r[2] += 4;  // 0605A3FC add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A3FE mov.b @r0,r0
    st8(c.r[2], c.r[0]);  // 0605A400 mov.b r0,@r2
L_0605A402:
    c.r[1] = ld32(0x0605A470u);  // 0605A402 mov.l 0x0605A470,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A404 mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0605A406 extu.w r1,r3
    c.t = c.r[11] == c.r[3];  // 0605A408 cmp/eq r3,r11
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_0605A422; } }  // 0605A40A bt/s 0x0605A422 ; mov r12,r0
    c.r[1] = ld32(0x0605A47Cu);  // 0605A40E mov.l 0x0605A47C,r1
    c.r[2] = ld32(c.r[1]);  // 0605A410 mov.l @r1,r2
    c.r[3] <<= 2;  // 0605A412 shll2 r3
    c.r[3] += c.r[3];  // 0605A414 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A46Au);  // 0605A416 mov.w 0x0605A46A,r1
    c.r[2] += c.r[1];  // 0605A418 add r1,r2
    c.r[2] += c.r[3];  // 0605A41A add r3,r2
    c.r[2] += 4;  // 0605A41C add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0605A41E mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0605A420 mov.b r1,@r2
L_0605A422:
    c.t = c.r[0] == 0x1u;  // 0605A422 cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_0605A44E; } }  // 0605A424 bf/s 0x0605A44E ; exts.w r9,r4
    c.r[1] = ld32(0x0605A478u);  // 0605A428 mov.l 0x0605A478,r1
    c.r[6] = 0x0u;  // 0605A42A mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A430u; c.r[5] = 0x2Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A430u) return; }  // 0605A42C jsr @r1 ; mov #45,r5
    c.r[1] = ld32(0x0605A47Cu);  // 0605A430 mov.l 0x0605A47C,r1
    c.r[2] = ld32(c.r[1]);  // 0605A432 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A468u);  // 0605A434 mov.w 0x0605A468,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A46Au);  // 0605A436 mov.w 0x0605A46A,r1
    c.r[2] += c.r[1];  // 0605A438 add r1,r2
    c.r[1] = ld32(0x0605A470u);  // 0605A43A mov.l 0x0605A470,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A43C mov.w @r1,r1
    c.r[0] += c.r[14];  // 0605A43E add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A440 extu.w r1,r1
    c.r[1] <<= 2;  // 0605A442 shll2 r1
    c.r[1] += c.r[1];  // 0605A444 add r1,r1
    c.r[2] += c.r[1];  // 0605A446 add r1,r2
    c.r[2] += 4;  // 0605A448 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605A44A mov.b @r0,r0
    st8(c.r[2], c.r[0]);  // 0605A44C mov.b r0,@r2
L_0605A44E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A46Cu);  // 0605A44E mov.w 0x0605A46C,r3
    c.r[14] += c.r[3];  // 0605A450 add r3,r14
    c.r[15] = c.r[14];  // 0605A452 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605A454 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605A456 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605A458 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605A45A mov.l @r15+,r12
    c.r[0] = c.r[11] & 0xFFu;  // 0605A45C extu.b r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605A45E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605A460 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605A462 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605A464 rts ; mov.l @r15+,r8
}

void f_0605A480(SH2Context& c) {
    ran[1380] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605A480 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605A482 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605A484 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605A486 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 0605A488 extu.b r4,r8
    c.r[1] = c.r[6] & 0xFFu;  // 0605A48A extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A48C tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[5] & 0xFFu; if (k) { goto L_0605A4FE; } }  // 0605A48E bf/s 0x0605A4FE ; extu.b r5,r2
    c.r[6] = 0x0u;  // 0605A492 mov #0,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605A546u);  // 0605A494 mov.w 0x0605A546,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605A548u);  // 0605A496 mov.w 0x0605A548,r5
    c.r[7] = 0x0u;  // 0605A498 mov #0,r7
L_0605A49A:
    c.r[1] = ld32(0x0605A54Cu);  // 0605A49A mov.l 0x0605A54C,r1
    c.r[0] = ld32(c.r[1]);  // 0605A49C mov.l @r1,r0
    c.r[2] = c.r[7];  // 0605A49E mov r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605A4A0 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A4A2 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0605A4A4 cmp/eq r4,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_0605A4E0; } }  // 0605A4A6 bt/s 0x0605A4E0 ; add r0,r2
    c.r[1] = c.r[2];  // 0605A4AA mov r2,r1
    c.r[1] += 7;  // 0605A4AC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A4AE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605A4B0 mov r1,r0
    c.r[0] >>= 2;  // 0605A4B2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605A4B4 shlr r0
    c.r[0] &= 0x1u;  // 0605A4B6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605A4B8 tst r0,r0
    if (!c.t) { goto L_0605A4E0; }  // 0605A4BA bf 0x0605A4E0
    c.r[2] = ld32(c.r[2] + 4);  // 0605A4BC mov.l @(4,r2),r2
    c.r[1] = ld32(0x0605A550u);  // 0605A4BE mov.l 0x0605A550,r1
    c.r[2] &= c.r[1];  // 0605A4C0 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605A4C2 tst r2,r2
    if (!c.t) { goto L_0605A4E0; }  // 0605A4C4 bf 0x0605A4E0
    c.r[1] = ld32(0x0605A554u);  // 0605A4C6 mov.l 0x0605A554,r1
    c.r[3] = ld32(c.r[1]);  // 0605A4C8 mov.l @r1,r3
    c.r[0] = c.r[3];  // 0605A4CA mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0605A4CC mov.b @(r0,r5),r2
    c.r[1] = c.r[2];  // 0605A4CE mov r2,r1
    c.r[1] += 1;  // 0605A4D0 add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 0605A4D2 mov.b r1,@(r0,r5)
    c.r[2] = c.r[2] & 0xFFu;  // 0605A4D4 extu.b r2,r2
    c.r[2] <<= 2;  // 0605A4D6 shll2 r2
    c.r[2] += c.r[2];  // 0605A4D8 add r2,r2
    c.r[3] += c.r[2];  // 0605A4DA add r2,r3
    c.r[3] += 4;  // 0605A4DC add #4,r3
    st8(c.r[3], c.r[6]);  // 0605A4DE mov.b r6,@r3
L_0605A4E0:
    c.r[6] += 1;  // 0605A4E0 add #1,r6
    c.r[1] = 0x49u;  // 0605A4E2 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0605A4E4 cmp/gt r1,r6
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_0605A49A; } }  // 0605A4E6 bf/s 0x0605A49A ; add #16,r7
    c.r[1] = ld32(0x0605A554u);  // 0605A4EA mov.l 0x0605A554,r1
    c.r[1] = ld32(c.r[1]);  // 0605A4EC mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A548u);  // 0605A4EE mov.w 0x0605A548,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605A4F0 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A4F2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A4F4 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0605A53C; } }  // 0605A4F6 bt/s 0x0605A53C ; mov #0,r0
    c.r[0] = 0x1u; goto L_0605A53C;  // 0605A4FA bra 0x0605A53C ; mov #1,r0
L_0605A4FE:
    c.r[0] = c.r[1];  // 0605A4FE mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0605A500 cmp/eq #2,r0
    if (!c.t) { goto L_0605A518; }  // 0605A502 bf 0x0605A518
    c.r[2] <<= 2;  // 0605A504 shll2 r2
    c.r[1] = ld32(0x0605A54Cu);  // 0605A506 mov.l 0x0605A54C,r1
    c.r[1] = ld32(c.r[1]);  // 0605A508 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605A50A shll2 r2
    c.r[2] += c.r[1];  // 0605A50C add r1,r2
    c.r[2] += 7;  // 0605A50E add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605A510 mov.b @r2,r0
    c.r[0] |= 0x4u;  // 0605A512 or #4,r0
    st8(c.r[2], c.r[0]); goto L_0605A53A;  // 0605A514 bra 0x0605A53A ; mov.b r0,@r2
L_0605A518:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0605A518 exts.w r2,r4
    c.r[1] = ld32(0x0605A558u);  // 0605A51A mov.l 0x0605A558,r1
    c.r[6] = 0x0u;  // 0605A51C mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A522u; c.r[5] = 0x2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A522u) return; }  // 0605A51E jsr @r1 ; mov #46,r5
    c.r[1] = ld32(0x0605A554u);  // 0605A522 mov.l 0x0605A554,r1
    c.r[2] = ld32(c.r[1]);  // 0605A524 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A54Au);  // 0605A526 mov.w 0x0605A54A,r1
    c.r[2] += c.r[1];  // 0605A528 add r1,r2
    c.r[1] = ld32(0x0605A55Cu);  // 0605A52A mov.l 0x0605A55C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605A52C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605A52E extu.w r1,r1
    c.r[1] <<= 2;  // 0605A530 shll2 r1
    c.r[1] += c.r[1];  // 0605A532 add r1,r1
    c.r[2] += c.r[1];  // 0605A534 add r1,r2
    c.r[2] += 4;  // 0605A536 add #4,r2
    st8(c.r[2], c.r[8]);  // 0605A538 mov.b r8,@r2
L_0605A53A:
    c.r[0] = 0x0u;  // 0605A53A mov #0,r0
L_0605A53C:
    c.r[15] = c.r[14];  // 0605A53C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605A53E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605A540 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605A542 rts ; mov.l @r15+,r8
}

void f_0605A560(SH2Context& c) {
    ran[1381] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605A560 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605A562 sts.l pr,@-r15
    c.r[1] = ld32(0x0605A580u);  // 0605A564 mov.l 0x0605A580,r1
    c.r[1] = ld32(c.r[1]);  // 0605A566 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A568 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605A56A extu.b r1,r0
    c.r[0] <<= 2;  // 0605A56C shll2 r0
    c.r[1] = ld32(0x0605A584u);  // 0605A56E mov.l 0x0605A584,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605A570 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605A576u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A576u) return; }  // 0605A572 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605A576 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605A578 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605A57A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605A57C rts ; extu.w r0,r0
}

void f_0605A588(SH2Context& c) {
    ran[1382] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605A588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605A58A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605A58C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605A58E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605A590 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605A592 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605A594 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605A596 sts.l pr,@-r15
    c.r[15] -= 16;  // 0605A598 add #-16,r15
    c.r[14] = c.r[15];  // 0605A59A mov r15,r14
    c.r[1] = 0xFFFFFFBCu;  // 0605A59C mov #-68,r1
    st8(c.r[14], c.r[1]);  // 0605A59E mov.b r1,@r14
    c.r[2] = c.r[14];  // 0605A5A0 mov r14,r2
    c.r[2] += 1;  // 0605A5A2 add #1,r2
    st8(c.r[2], c.r[1]);  // 0605A5A4 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5A6 mov r14,r2
    c.r[2] += 2;  // 0605A5A8 add #2,r2
    st8(c.r[2], c.r[1]);  // 0605A5AA mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5AC mov r14,r2
    c.r[2] += 3;  // 0605A5AE add #3,r2
    st8(c.r[2], c.r[1]);  // 0605A5B0 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5B2 mov r14,r2
    c.r[2] += 4;  // 0605A5B4 add #4,r2
    st8(c.r[2], c.r[1]);  // 0605A5B6 mov.b r1,@r2
    c.r[3] = c.r[14];  // 0605A5B8 mov r14,r3
    c.r[3] += 5;  // 0605A5BA add #5,r3
    c.r[2] = 0xFFFFFF80u;  // 0605A5BC mov #-128,r2
    st8(c.r[3], c.r[2]);  // 0605A5BE mov.b r2,@r3
    c.r[2] = c.r[14];  // 0605A5C0 mov r14,r2
    c.r[2] += 6;  // 0605A5C2 add #6,r2
    st8(c.r[2], c.r[1]);  // 0605A5C4 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5C6 mov r14,r2
    c.r[2] += 7;  // 0605A5C8 add #7,r2
    st8(c.r[2], c.r[1]);  // 0605A5CA mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5CC mov r14,r2
    c.r[2] += 8;  // 0605A5CE add #8,r2
    st8(c.r[2], c.r[1]);  // 0605A5D0 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5D2 mov r14,r2
    c.r[2] += 9;  // 0605A5D4 add #9,r2
    st8(c.r[2], c.r[1]);  // 0605A5D6 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5D8 mov r14,r2
    c.r[2] += 10;  // 0605A5DA add #10,r2
    st8(c.r[2], c.r[1]);  // 0605A5DC mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5DE mov r14,r2
    c.r[2] += 11;  // 0605A5E0 add #11,r2
    st8(c.r[2], c.r[1]);  // 0605A5E2 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5E4 mov r14,r2
    c.r[2] += 12;  // 0605A5E6 add #12,r2
    st8(c.r[2], c.r[1]);  // 0605A5E8 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5EA mov r14,r2
    c.r[2] += 13;  // 0605A5EC add #13,r2
    st8(c.r[2], c.r[1]);  // 0605A5EE mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5F0 mov r14,r2
    c.r[2] += 14;  // 0605A5F2 add #14,r2
    st8(c.r[2], c.r[1]);  // 0605A5F4 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0605A5F6 mov r14,r2
    c.r[2] += 15;  // 0605A5F8 add #15,r2
    st8(c.r[2], c.r[1]);  // 0605A5FA mov.b r1,@r2
    c.r[1] = ld32(0x0605A734u);  // 0605A5FC mov.l 0x0605A734,r1
    c.r[1] = ld32(c.r[1]);  // 0605A5FE mov.l @r1,r1
    c.r[1] += 1;  // 0605A600 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A602 mov.b @r1,r3
    c.r[2] = 0x1u;  // 0605A604 mov #1,r2
    c.r[1] = c.r[3];  // 0605A606 mov r3,r1
    c.r[1] -= 2;  // 0605A608 add #-2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A60A extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0605A60C cmp/hi r2,r1
    { const bool k = !c.t; c.r[0] = c.r[3] & 0xFFu; if (k) { goto L_0605A64C; } }  // 0605A60E bf/s 0x0605A64C ; extu.b r3,r0
    c.t = c.r[0] == 0x6u;  // 0605A612 cmp/eq #6,r0
    if (c.t) { goto L_0605A64C; }  // 0605A614 bt 0x0605A64C
    c.r[3] = ld32(0x0605A738u);  // 0605A616 mov.l 0x0605A738,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605A72Cu);  // 0605A618 mov.w 0x0605A72C,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605A61A mov.b @r3,r0
    c.r[7] = c.r[3];  // 0605A61C mov r3,r7
    c.r[0] &= 0x3u;  // 0605A61E and #3,r0
    st8(c.r[3], c.r[0]);  // 0605A620 mov.b r0,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605A622 mov.w @r3,r1
    c.r[7] += 74;  // 0605A624 add #74,r7
    c.r[1] &= c.r[2];  // 0605A626 and r2,r1
    st16(c.r[3], c.r[1]);  // 0605A628 mov.w r1,@r3
    c.r[1] = c.r[3];  // 0605A62A mov r3,r1
    c.r[1] += 1;  // 0605A62C add #1,r1
    c.r[2] = c.r[3];  // 0605A62E mov r3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A630 mov.b @r1,r0
    c.r[2] += 75;  // 0605A632 add #75,r2
    c.r[0] &= 0x9Fu;  // 0605A634 and #159,r0
    c.r[0] |= 0x10u;  // 0605A636 or #16,r0
    st8(c.r[1], c.r[0]);  // 0605A638 mov.b r0,@r1
    c.r[1] = 0x0u;  // 0605A63A mov #0,r1
    st8(c.r[2], c.r[1]);  // 0605A63C mov.b r1,@r2
    st8(c.r[7], c.r[1]);  // 0605A63E mov.b r1,@r7
    c.r[1] = c.r[3];  // 0605A640 mov r3,r1
    c.r[1] += 76;  // 0605A642 add #76,r1
    c.r[2] = 0x40u;  // 0605A644 mov #64,r2
    st8(c.r[1], c.r[2]);  // 0605A646 mov.b r2,@r1
    c.r[3] += 77;  // 0605A648 add #77,r3
    st8(c.r[3], c.r[2]);  // 0605A64A mov.b r2,@r3
L_0605A64C:
    c.r[1] = ld32(0x0605A73Cu);  // 0605A64C mov.l 0x0605A73C,r1
    c.r[5] = 0x0u;  // 0605A64E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A654u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A654u) return; }  // 0605A650 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605A740u);  // 0605A654 mov.l 0x0605A740,r1
    c.r[5] = 0x0u;  // 0605A656 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A65Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A65Cu) return; }  // 0605A658 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605A744u);  // 0605A65C mov.l 0x0605A744,r1
    c.r[5] = 0x0u;  // 0605A65E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A664u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A664u) return; }  // 0605A660 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0605A734u);  // 0605A664 mov.l 0x0605A734,r8
    c.r[1] = ld32(c.r[8]);  // 0605A666 mov.l @r8,r1
    c.r[1] += 1;  // 0605A668 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A66A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A66C extu.b r1,r1
    c.r[0] = c.r[1];  // 0605A66E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0605A670 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0605A758; } }  // 0605A672 bt/s 0x0605A758 ; cmp/eq #3,r0
    { const bool k = c.t; c.t = c.r[0] == 0x6u; if (k) { goto L_0605A758; } }  // 0605A676 bt/s 0x0605A758 ; cmp/eq #6,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0605A758; } }  // 0605A67A bt/s 0x0605A758 ; mov #0,r5
    c.r[1] = ld32(0x0605A748u);  // 0605A67E mov.l 0x0605A748,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A684u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A684u) return; }  // 0605A680 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(c.r[8]);  // 0605A684 mov.l @r8,r1
    c.r[1] += 1;  // 0605A686 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A688 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A68A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605A68C tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0605A696; } }  // 0605A68E bt/s 0x0605A696 ; mov r1,r0
    c.t = c.r[0] == 0x5u;  // 0605A692 cmp/eq #5,r0
    if (!c.t) { goto L_0605A6CA; }  // 0605A694 bf 0x0605A6CA
L_0605A696:
    c.r[1] = ld32(0x0605A74Cu);  // 0605A696 mov.l 0x0605A74C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A698 mov.b @r1,r0
    c.r[2] = 0x0u;  // 0605A69A mov #0,r2
    c.r[6] = 0xFu;  // 0605A69C mov #15,r6
    c.r[7] = ld32(0x0605A750u);  // 0605A69E mov.l 0x0605A750,r7
    c.r[3] = 0xFFFFFFFFu;  // 0605A6A0 mov #-1,r3
    c.r[0] &= 0xF7u;  // 0605A6A2 and #247,r0
    st8(c.r[1], c.r[0]);  // 0605A6A4 mov.b r0,@r1
L_0605A6A6:
    c.r[1] = c.r[2];  // 0605A6A6 mov r2,r1
    c.r[1] += c.r[7];  // 0605A6A8 add r7,r1
    c.r[1] += 2;  // 0605A6AA add #2,r1
    c.r[2] += 1;  // 0605A6AC add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0605A6AE cmp/gt r6,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_0605A6A6; } }  // 0605A6B0 bf/s 0x0605A6A6 ; mov.b r3,@r1
    c.r[2] = 0x0u;  // 0605A6B4 mov #0,r2
    c.r[6] = 0xFu;  // 0605A6B6 mov #15,r6
    c.r[7] = ld32(0x0605A750u);  // 0605A6B8 mov.l 0x0605A750,r7
    c.r[3] = 0xFFFFFFFFu;  // 0605A6BA mov #-1,r3
L_0605A6BC:
    c.r[1] = c.r[2];  // 0605A6BC mov r2,r1
    c.r[1] += c.r[7];  // 0605A6BE add r7,r1
    c.r[1] += 18;  // 0605A6C0 add #18,r1
    c.r[2] += 1;  // 0605A6C2 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0605A6C4 cmp/gt r6,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_0605A6BC; } }  // 0605A6C6 bf/s 0x0605A6BC ; mov.b r3,@r1
L_0605A6CA:
    c.r[2] = ld32(0x0605A738u);  // 0605A6CA mov.l 0x0605A738,r2
    c.r[3] = c.r[2];  // 0605A6CC mov r2,r3
    c.r[3] += 78;  // 0605A6CE add #78,r3
    c.r[1] = c.r[2];  // 0605A6D0 mov r2,r1
    c.r[1] += 79;  // 0605A6D2 add #79,r1
    c.r[6] = 0x0u;  // 0605A6D4 mov #0,r6
    st8(c.r[1], c.r[6]);  // 0605A6D6 mov.b r6,@r1
    st8(c.r[3], c.r[6]);  // 0605A6D8 mov.b r6,@r3
    c.r[3] = c.r[2];  // 0605A6DA mov r2,r3
    c.r[3] += 116;  // 0605A6DC add #116,r3
    c.r[1] = 0x9u;  // 0605A6DE mov #9,r1
    st8(c.r[3], c.r[1]);  // 0605A6E0 mov.b r1,@r3
    c.r[3] = c.r[2];  // 0605A6E2 mov r2,r3
    c.r[3] += 117;  // 0605A6E4 add #117,r3
    c.r[1] = 0x6u;  // 0605A6E6 mov #6,r1
    st8(c.r[3], c.r[1]);  // 0605A6E8 mov.b r1,@r3
    c.r[1] = c.r[2];  // 0605A6EA mov r2,r1
    c.r[1] += 108;  // 0605A6EC add #108,r1
    c.r[7] = 0x0u;  // 0605A6EE mov #0,r7
    c.r[3] = 0xFFFFFFF8u;  // 0605A6F0 mov #-8,r3
    st16(c.r[1], c.r[3]);  // 0605A6F2 mov.w r3,@r1
    c.r[1] = c.r[2];  // 0605A6F4 mov r2,r1
    c.r[1] += 110;  // 0605A6F6 add #110,r1
    st16(c.r[1], c.r[3]);  // 0605A6F8 mov.w r3,@r1
    c.r[3] = c.r[2];  // 0605A6FA mov r2,r3
    c.r[3] += 80;  // 0605A6FC add #80,r3
    c.r[1] = c.r[2];  // 0605A6FE mov r2,r1
    c.r[1] += 84;  // 0605A700 add #84,r1
    st32(c.r[1], c.r[7]);  // 0605A702 mov.l r7,@r1
    st32(c.r[3], c.r[7]);  // 0605A704 mov.l r7,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A72Eu);  // 0605A706 mov.w 0x0605A72E,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605A730u);  // 0605A708 mov.w 0x0605A730,r7
    c.r[1] = ld32(0x0605A754u);  // 0605A70A mov.l 0x0605A754,r1
    c.r[0] = c.r[2];  // 0605A70C mov r2,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0605A70E mov.l r1,@(r0,r7)
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A710 mov.l r1,@(r0,r3)
    c.r[7] = c.r[2];  // 0605A712 mov r2,r7
    c.r[7] += 120;  // 0605A714 add #120,r7
    c.r[3] = c.r[2];  // 0605A716 mov r2,r3
    c.r[3] += 124;  // 0605A718 add #124,r3
    c.r[1] = 0x0u;  // 0605A71A mov #0,r1
    st16(c.r[3], c.r[1]);  // 0605A71C mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0605A71E mov.w r1,@r7
    c.r[1] = c.r[2];  // 0605A720 mov r2,r1
    c.r[1] += 126;  // 0605A722 add #126,r1
    c.r[2] += 127;  // 0605A724 add #127,r2
    st8(c.r[2], c.r[6]);  // 0605A726 mov.b r6,@r2
    st8(c.r[1], c.r[6]); goto L_0605A768;  // 0605A728 bra 0x0605A768 ; mov.b r6,@r1
L_0605A758:
    c.r[1] = ld32(0x0605A8F4u);  // 0605A758 mov.l 0x0605A8F4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A8B8u);  // 0605A75A mov.w 0x0605A8B8,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0605A75C mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A8BAu);  // 0605A75E mov.w 0x0605A8BA,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0605A760 mov.l @(r0,r1),r4
    c.r[1] = ld32(0x0605A8F8u);  // 0605A762 mov.l 0x0605A8F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A768u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A768u) return; }  // 0605A764 jsr @r1 ; nop
L_0605A768:
    c.r[2] = ld32(0x0605A8F4u);  // 0605A768 mov.l 0x0605A8F4,r2
    c.r[7] = c.r[2];  // 0605A76A mov r2,r7
    c.r[7] += 88;  // 0605A76C add #88,r7
    c.r[3] = c.r[2];  // 0605A76E mov r2,r3
    c.r[3] += 92;  // 0605A770 add #92,r3
    c.r[1] = ld32(0x0605A8FCu);  // 0605A772 mov.l 0x0605A8FC,r1
    st32(c.r[3], c.r[1]);  // 0605A774 mov.l r1,@r3
    st32(c.r[7], c.r[1]);  // 0605A776 mov.l r1,@r7
    c.r[3] = c.r[2];  // 0605A778 mov r2,r3
    c.r[3] += 96;  // 0605A77A add #96,r3
    c.r[1] = 0x0u;  // 0605A77C mov #0,r1
    st16(c.r[3], c.r[1]);  // 0605A77E mov.w r1,@r3
    c.r[7] = c.r[2];  // 0605A780 mov r2,r7
    c.r[7] += 100;  // 0605A782 add #100,r7
    c.r[3] = c.r[2];  // 0605A784 mov r2,r3
    c.r[3] += 104;  // 0605A786 add #104,r3
    c.r[1] = 0x0u;  // 0605A788 mov #0,r1
    st32(c.r[3], c.r[1]);  // 0605A78A mov.l r1,@r3
    st32(c.r[7], c.r[1]);  // 0605A78C mov.l r1,@r7
    c.r[3] = c.r[2];  // 0605A78E mov r2,r3
    c.r[3] += 112;  // 0605A790 add #112,r3
    c.r[1] = 0x3Fu;  // 0605A792 mov #63,r1
    st16(c.r[3], c.r[1]);  // 0605A794 mov.w r1,@r3
    c.r[3] = c.r[2];  // 0605A796 mov r2,r3
    c.r[3] += 114;  // 0605A798 add #114,r3
    c.r[1] = 0xFFFFFFDFu;  // 0605A79A mov #-33,r1
    st16(c.r[3], c.r[1]);  // 0605A79C mov.w r1,@r3
    c.r[7] = c.r[2];  // 0605A79E mov r2,r7
    c.r[7] += 122;  // 0605A7A0 add #122,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605A8BCu);  // 0605A7A2 mov.w 0x0605A8BC,r0
    c.r[3] = c.r[2];  // 0605A7A4 mov r2,r3
    c.r[3] += 118;  // 0605A7A6 add #118,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605A7A8 mov.b @r7,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605A8BEu);  // 0605A7AA mov.w 0x0605A8BE,r6
    c.r[1] &= c.r[0];  // 0605A7AC and r0,r1
    st8(c.r[7], c.r[1]);  // 0605A7AE mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605A7B0 mov.b @r3,r1
    c.r[5] = 0xFu;  // 0605A7B2 mov #15,r5
    c.r[1] &= c.r[0];  // 0605A7B4 and r0,r1
    st8(c.r[3], c.r[1]);  // 0605A7B6 mov.b r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0605A7B8 mov.w @r7,r1
    c.r[0] = c.r[2];  // 0605A7BA mov r2,r0
    c.r[1] &= c.r[6];  // 0605A7BC and r6,r1
    st16(c.r[7], c.r[1]);  // 0605A7BE mov.w r1,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605A7C0 mov.w @r3,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605A8C0u);  // 0605A7C2 mov.w 0x0605A8C0,r7
    c.r[1] &= c.r[6];  // 0605A7C4 and r6,r1
    st16(c.r[3], c.r[1]);  // 0605A7C6 mov.w r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8C2u);  // 0605A7C8 mov.w 0x0605A8C2,r3
    c.r[1] = 0x11u;  // 0605A7CA mov #17,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605A7CC mov.b r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8C4u);  // 0605A7CE mov.w 0x0605A8C4,r3
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605A7D0 mov.b r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8C6u);  // 0605A7D2 mov.w 0x0605A8C6,r3
    c.r[1] = 0x22u;  // 0605A7D4 mov #34,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605A7D6 mov.b r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8C8u);  // 0605A7D8 mov.w 0x0605A8C8,r3
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605A7DA mov.b r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8CAu);  // 0605A7DC mov.w 0x0605A8CA,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A8CCu);  // 0605A7DE mov.w 0x0605A8CC,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605A7E0 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8CEu);  // 0605A7E2 mov.w 0x0605A8CE,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A8D0u);  // 0605A7E4 mov.w 0x0605A8D0,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605A7E6 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8D2u);  // 0605A7E8 mov.w 0x0605A8D2,r3
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605A7EA mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8D4u);  // 0605A7EC mov.w 0x0605A8D4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605A8D6u);  // 0605A7EE mov.w 0x0605A8D6,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605A7F0 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8D8u);  // 0605A7F2 mov.w 0x0605A8D8,r3
    c.r[1] = ld32(0x0605A900u);  // 0605A7F4 mov.l 0x0605A900,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A7F6 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8DAu);  // 0605A7F8 mov.w 0x0605A8DA,r3
    c.r[1] = ld32(0x0605A904u);  // 0605A7FA mov.l 0x0605A904,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A7FC mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8DCu);  // 0605A7FE mov.w 0x0605A8DC,r3
    c.r[1] = ld32(0x0605A908u);  // 0605A800 mov.l 0x0605A908,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A802 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8DEu);  // 0605A804 mov.w 0x0605A8DE,r3
    c.r[1] = ld32(0x0605A90Cu);  // 0605A806 mov.l 0x0605A90C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A808 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8E0u);  // 0605A80A mov.w 0x0605A8E0,r3
    c.r[1] = ld32(0x0605A910u);  // 0605A80C mov.l 0x0605A910,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A80E mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8E2u);  // 0605A810 mov.w 0x0605A8E2,r3
    c.r[1] = ld32(0x0605A914u);  // 0605A812 mov.l 0x0605A914,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A814 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8E4u);  // 0605A816 mov.w 0x0605A8E4,r3
    c.r[1] = ld32(0x0605A918u);  // 0605A818 mov.l 0x0605A918,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A81A mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8E6u);  // 0605A81C mov.w 0x0605A8E6,r3
    c.r[1] = ld32(0x0605A91Cu);  // 0605A81E mov.l 0x0605A91C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A820 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8E8u);  // 0605A822 mov.w 0x0605A8E8,r3
    c.r[1] = ld32(0x0605A920u);  // 0605A824 mov.l 0x0605A920,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A826 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8EAu);  // 0605A828 mov.w 0x0605A8EA,r3
    c.r[1] = ld32(0x0605A924u);  // 0605A82A mov.l 0x0605A924,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A82C mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8ECu);  // 0605A82E mov.w 0x0605A8EC,r3
    c.r[1] = ld32(0x0605A928u);  // 0605A830 mov.l 0x0605A928,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605A832 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8EEu);  // 0605A834 mov.w 0x0605A8EE,r3
    c.r[1] = 0x40u;  // 0605A836 mov #64,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605A838 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8F0u);  // 0605A83A mov.w 0x0605A8F0,r3
    c.r[1] = 0x1u;  // 0605A83C mov #1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605A83E mov.b r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605A8F2u);  // 0605A840 mov.w 0x0605A8F2,r3
    c.r[1] = 0x0u;  // 0605A842 mov #0,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0605A844 mov.b r1,@(r0,r7)
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605A846 mov.b r1,@(r0,r3)
    c.r[2] = 0x0u;  // 0605A848 mov #0,r2
    c.r[7] = ld32(0x0605A92Cu);  // 0605A84A mov.l 0x0605A92C,r7
    c.r[6] = 0x0u;  // 0605A84C mov #0,r6
    c.r[3] = c.r[7];  // 0605A84E mov r7,r3
    c.r[1] = 0x0u;  // 0605A850 mov #0,r1
L_0605A852:
    st32(c.r[3] + 4, c.r[6]);  // 0605A852 mov.l r6,@(4,r3)
    c.r[0] = c.r[1];  // 0605A854 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605A856 mov.b @(r0,r7),r4
    c.r[3] += 12;  // 0605A858 add #12,r3
    c.r[2] += 1;  // 0605A85A add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[5];  // 0605A85C cmp/gt r5,r2
    c.r[0] = 0x7Fu;  // 0605A85E mov #127,r0
    c.r[4] &= c.r[0];  // 0605A860 and r0,r4
    c.r[0] = c.r[1];  // 0605A862 mov r1,r0
    st8(c.r[0] + c.r[7], c.r[4]);  // 0605A864 mov.b r4,@(r0,r7)
    { const bool k = !c.t; c.r[1] += 12; if (k) { SH2_POLL(c); goto L_0605A852; } }  // 0605A866 bf/s 0x0605A852 ; add #12,r1
    c.r[1] = ld32(0x0605A930u);  // 0605A86A mov.l 0x0605A930,r1
    c.r[2] = 0x0u;  // 0605A86C mov #0,r2
    st16(c.r[1], c.r[2]);  // 0605A86E mov.w r2,@r1
    c.r[1] = ld32(0x0605A934u);  // 0605A870 mov.l 0x0605A934,r1
    st16(c.r[1], c.r[2]);  // 0605A872 mov.w r2,@r1
    c.r[1] = ld32(0x0605A938u);  // 0605A874 mov.l 0x0605A938,r1
    st16(c.r[1], c.r[2]);  // 0605A876 mov.w r2,@r1
    c.r[1] = ld32(0x0605A93Cu);  // 0605A878 mov.l 0x0605A93C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A87Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A87Eu) return; }  // 0605A87A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605A940u);  // 0605A87E mov.l 0x0605A940,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A884u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A884u) return; }  // 0605A880 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605A944u);  // 0605A884 mov.l 0x0605A944,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A88Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A88Au) return; }  // 0605A886 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0605A948u);  // 0605A88A mov.l 0x0605A948,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A890u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A890u) return; }  // 0605A88C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605A94Cu);  // 0605A890 mov.l 0x0605A94C,r1
    c.r[1] = ld32(c.r[1]);  // 0605A892 mov.l @r1,r1
    c.r[1] += 1;  // 0605A894 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A896 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A898 extu.b r1,r1
    c.r[0] = c.r[1];  // 0605A89A mov r1,r0
    c.t = c.r[0] == 0x5u;  // 0605A89C cmp/eq #5,r0
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0605A8A8; } }  // 0605A89E bf/s 0x0605A8A8 ; mov #0,r4
    c.r[1] = ld32(0x0605A950u);  // 0605A8A2 mov.l 0x0605A950,r1
    goto L_0605A962;  // 0605A8A4 bra 0x0605A962 ; nop
L_0605A8A8:
    c.t = c.r[0] == 0x6u;  // 0605A8A8 cmp/eq #6,r0
    if (!c.t) { goto L_0605A958; }  // 0605A8AA bf 0x0605A958
    c.r[1] = ld32(0x0605A954u);  // 0605A8AC mov.l 0x0605A954,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A8B2u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A8B2u) return; }  // 0605A8AE jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x0605A950u);  // 0605A8B2 mov.l 0x0605A950,r1
    c.r[4] = 0x3u; goto L_0605A962;  // 0605A8B4 bra 0x0605A962 ; mov #3,r4
L_0605A958:
    c.r[1] = ld32(0x0605ABA0u);  // 0605A958 mov.l 0x0605ABA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A95Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A95Eu) return; }  // 0605A95A jsr @r1 ; mov #2,r4
    c.r[1] = ld32(0x0605ABA4u);  // 0605A95E mov.l 0x0605ABA4,r1
    c.r[4] = 0x2u;  // 0605A960 mov #2,r4
L_0605A962:
    { const uint32_t x = c.r[1]; c.pr = 0x0605A966u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A966u) return; }  // 0605A962 jsr @r1 ; nop
    c.r[1] = ld32(0x0605ABA8u);  // 0605A966 mov.l 0x0605ABA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A96Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A96Cu) return; }  // 0605A968 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605ABACu);  // 0605A96C mov.l 0x0605ABAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A972u; c.r[4] = 0x5Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A972u) return; }  // 0605A96E jsr @r1 ; mov #95,r4
    c.r[1] = ld32(0x0605ABB0u);  // 0605A972 mov.l 0x0605ABB0,r1
    c.r[6] = 0x0u;  // 0605A974 mov #0,r6
    c.r[5] = 0x0u;  // 0605A976 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A97Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A97Cu) return; }  // 0605A978 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605ABB4u);  // 0605A97C mov.l 0x0605ABB4,r1
    c.r[5] = 0x0u;  // 0605A97E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A984u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A984u) return; }  // 0605A980 jsr @r1 ; mov #0,r4
    c.r[9] = ld32(0x0605ABB8u);  // 0605A984 mov.l 0x0605ABB8,r9
    c.r[10] = ld32(0x0605ABBCu);  // 0605A986 mov.l 0x0605ABBC,r10
    c.r[1] = ld32(0x0605ABC0u);  // 0605A988 mov.l 0x0605ABC0,r1
    c.r[6] = c.r[9];  // 0605A98A mov r9,r6
    c.r[5] = 0x0u;  // 0605A98C mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A992u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A992u) return; }  // 0605A98E jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0605ABC4u);  // 0605A992 mov.l 0x0605ABC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A998u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A998u) return; }  // 0605A994 jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x0605ABC8u);  // 0605A998 mov.l 0x0605ABC8,r4
    c.r[1] = ld32(0x0605ABCCu);  // 0605A99A mov.l 0x0605ABCC,r1
    c.r[7] = c.r[4];  // 0605A99C mov r4,r7
    c.r[6] = c.r[4];  // 0605A99E mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9A4u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9A4u) return; }  // 0605A9A0 jsr @r1 ; mov r4,r5
    c.r[8] = ld32(0x0605ABD0u);  // 0605A9A4 mov.l 0x0605ABD0,r8
    c.r[1] = ld32(c.r[8]);  // 0605A9A6 mov.l @r8,r1
    c.r[1] += 1;  // 0605A9A8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A9AA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605A9AC extu.b r1,r0
    c.t = c.r[0] == 0x5u;  // 0605A9AE cmp/eq #5,r0
    if (c.t) { goto L_0605A9D6; }  // 0605A9B0 bt 0x0605A9D6
    c.r[5] = 0x0u;  // 0605A9B2 mov #0,r5
    c.r[1] = ld32(0x0605ABD4u);  // 0605A9B4 mov.l 0x0605ABD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9BAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9BAu) return; }  // 0605A9B6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605ABD8u);  // 0605A9BA mov.l 0x0605ABD8,r1
    c.r[6] = c.r[9];  // 0605A9BC mov r9,r6
    c.r[5] = 0x0u;  // 0605A9BE mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9C4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9C4u) return; }  // 0605A9C0 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0605ABDCu);  // 0605A9C4 mov.l 0x0605ABDC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9CAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9CAu) return; }  // 0605A9C6 jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x0605ABE0u);  // 0605A9CA mov.l 0x0605ABE0,r4
    c.r[1] = ld32(0x0605ABE4u);  // 0605A9CC mov.l 0x0605ABE4,r1
    c.r[7] = c.r[4];  // 0605A9CE mov r4,r7
    c.r[6] = c.r[4];  // 0605A9D0 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9D6u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9D6u) return; }  // 0605A9D2 jsr @r1 ; mov r4,r5
L_0605A9D6:
    c.r[1] = ld32(c.r[8]);  // 0605A9D6 mov.l @r8,r1
    c.r[1] += 1;  // 0605A9D8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605A9DA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605A9DC extu.b r1,r0
    c.t = c.r[0] == 0x3u;  // 0605A9DE cmp/eq #3,r0
    { const bool k = c.t; c.r[1] -= 5; if (k) { goto L_0605AA24; } }  // 0605A9E0 bt/s 0x0605AA24 ; add #-5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605A9E4 extu.b r1,r1
    c.r[2] = 0x1u;  // 0605A9E6 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 0605A9E8 cmp/hi r2,r1
    if (!c.t) { goto L_0605AA24; }  // 0605A9EA bf 0x0605AA24
    c.r[8] = ld32(0x0605ABE8u);  // 0605A9EC mov.l 0x0605ABE8,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605AB8Eu);  // 0605A9EE mov.w 0x0605AB8E,r0
    c.r[1] = ld32(0x0605ABECu);  // 0605A9F0 mov.l 0x0605ABEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9F6u; c.r[4] = ld32(c.r[0] + c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9F6u) return; }  // 0605A9F2 jsr @r1 ; mov.l @(r0,r8),r4
    c.r[1] = ld32(0x0605ABF0u);  // 0605A9F6 mov.l 0x0605ABF0,r1
    c.r[5] = 0x0u;  // 0605A9F8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605A9FEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605A9FEu) return; }  // 0605A9FA jsr @r1 ; mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605AB90u);  // 0605A9FE mov.w 0x0605AB90,r0
    c.r[1] = ld32(0x0605ABF4u);  // 0605AA00 mov.l 0x0605ABF4,r1
    c.r[6] = c.r[9];  // 0605AA02 mov r9,r6
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 0605AA04 mov.l @(r0,r8),r4
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA0Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA0Au) return; }  // 0605AA06 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x0605ABF8u);  // 0605AA0A mov.l 0x0605ABF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA10u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA10u) return; }  // 0605AA0C jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x0605ABFCu);  // 0605AA10 mov.l 0x0605ABFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA16u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA16u) return; }  // 0605AA12 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x0605AC00u);  // 0605AA16 mov.l 0x0605AC00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA1Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA1Cu) return; }  // 0605AA18 jsr @r1 ; mov #2,r4
    c.r[4] = ld32(0x0605AC04u);  // 0605AA1C mov.l 0x0605AC04,r4
    c.r[1] = ld32(0x0605AC08u);  // 0605AA1E mov.l 0x0605AC08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA24u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA24u) return; }  // 0605AA20 jsr @r1 ; mov r4,r5
L_0605AA24:
    c.r[1] = ld32(0x0605AC0Cu);  // 0605AA24 mov.l 0x0605AC0C,r1
    c.r[5] = 0x0u;  // 0605AA26 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA2Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA2Cu) return; }  // 0605AA28 jsr @r1 ; mov #0,r4
    c.r[10] = ld32(0x0605ABB8u);  // 0605AA2C mov.l 0x0605ABB8,r10
    c.r[9] = ld32(0x0605AC10u);  // 0605AA2E mov.l 0x0605AC10,r9
    c.r[1] = ld32(0x0605AC14u);  // 0605AA30 mov.l 0x0605AC14,r1
    c.r[6] = c.r[10];  // 0605AA32 mov r10,r6
    c.r[5] = 0x0u;  // 0605AA34 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA3Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA3Au) return; }  // 0605AA36 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x0605AC18u);  // 0605AA3A mov.l 0x0605AC18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA40u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA40u) return; }  // 0605AA3C jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0605AC1Cu);  // 0605AA40 mov.l 0x0605AC1C,r8
    c.r[1] = ld32(0x0605AC20u);  // 0605AA42 mov.l 0x0605AC20,r1
    c.r[7] = c.r[8];  // 0605AA44 mov r8,r7
    c.r[6] = c.r[8];  // 0605AA46 mov r8,r6
    c.r[5] = c.r[8];  // 0605AA48 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA4Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA4Eu) return; }  // 0605AA4A jsr @r1 ; mov r8,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605AB92u);  // 0605AA4E mov.w 0x0605AB92,r6
    c.r[4] = ld32(0x0605AC24u);  // 0605AA50 mov.l 0x0605AC24,r4
    c.r[1] = 0x20u;  // 0605AA52 mov #32,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605AA54 mov.l r1,@-r15
    c.r[1] = ld32(0x0605AC28u);  // 0605AA56 mov.l 0x0605AC28,r1
    c.r[7] = 0x0u;  // 0605AA58 mov #0,r7
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA5Eu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA5Eu) return; }  // 0605AA5A jsr @r1 ; mov r9,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605AB94u);  // 0605AA5E mov.w 0x0605AB94,r6
    c.r[0] = ld32(0x0605AC2Cu);  // 0605AA60 mov.l 0x0605AC2C,r0
    c.r[5] = 0x0u;  // 0605AA62 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0605AA68u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA68u) return; }  // 0605AA64 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x0605AC30u);  // 0605AA68 mov.l 0x0605AC30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA6Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA6Eu) return; }  // 0605AA6A jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x0605AC34u);  // 0605AA6E mov.l 0x0605AC34,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605AB96u);  // 0605AA70 mov.w 0x0605AB96,r1
    st16(c.r[2], c.r[1]);  // 0605AA72 mov.w r1,@r2
    c.r[1] = ld32(0x0605AC38u);  // 0605AA74 mov.l 0x0605AC38,r1
    c.r[5] = 0x1u;  // 0605AA76 mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA7Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA7Cu) return; }  // 0605AA78 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0605ABE8u);  // 0605AA7C mov.l 0x0605ABE8,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605AB98u);  // 0605AA7E mov.w 0x0605AB98,r0
    c.r[1] = ld32(0x0605AC3Cu);  // 0605AA80 mov.l 0x0605AC3C,r1
    c.r[6] = c.r[10];  // 0605AA82 mov r10,r6
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 0605AA84 mov.l @(r0,r8),r4
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA8Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA8Au) return; }  // 0605AA86 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x0605AC40u);  // 0605AA8A mov.l 0x0605AC40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA90u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA90u) return; }  // 0605AA8C jsr @r1 ; mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605AB9Au);  // 0605AA90 mov.w 0x0605AB9A,r0
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 0605AA92 mov.l @(r0,r8),r4
    c.r[1] = ld32(0x0605AC44u);  // 0605AA94 mov.l 0x0605AC44,r1
    c.r[7] = c.r[4];  // 0605AA96 mov r4,r7
    c.r[6] = c.r[4];  // 0605AA98 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605AA9Eu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AA9Eu) return; }  // 0605AA9A jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x0605ABD0u);  // 0605AA9E mov.l 0x0605ABD0,r1
    c.r[1] = ld32(c.r[1]);  // 0605AAA0 mov.l @r1,r1
    c.r[1] += 1;  // 0605AAA2 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AAA4 mov.b @r1,r2
    c.r[3] = 0x1u;  // 0605AAA6 mov #1,r3
    c.r[1] = c.r[2];  // 0605AAA8 mov r2,r1
    c.r[1] -= 2;  // 0605AAAA add #-2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605AAAC extu.b r1,r1
    c.t = c.r[1] > c.r[3];  // 0605AAAE cmp/hi r3,r1
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0605AAFA; } }  // 0605AAB0 bf/s 0x0605AAFA ; add #4,r15
    c.r[1] = c.r[2];  // 0605AAB4 mov r2,r1
    c.r[1] -= 5;  // 0605AAB6 add #-5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605AAB8 extu.b r1,r1
    c.t = c.r[1] > c.r[3];  // 0605AABA cmp/hi r3,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0605AAFA; } }  // 0605AABC bf/s 0x0605AAFA ; mov #0,r1
    c.r[3] = ld32(0x0605AC48u);  // 0605AAC0 mov.l 0x0605AC48,r3
    c.r[2] = c.r[3];  // 0605AAC2 mov r3,r2
    c.r[2] += 88;  // 0605AAC4 add #88,r2
    st16(c.r[2], c.r[1]);  // 0605AAC6 mov.w r1,@r2
    c.r[2] = c.r[3];  // 0605AAC8 mov r3,r2
    c.r[2] += 90;  // 0605AACA add #90,r2
    c.r[1] = 0x2u;  // 0605AACC mov #2,r1
    st8(c.r[2], c.r[1]);  // 0605AACE mov.b r1,@r2
    c.r[2] = ld32(0x0605AC4Cu);  // 0605AAD0 mov.l 0x0605AC4C,r2
    c.r[1] = ld32(c.r[3]);  // 0605AAD2 mov.l @r3,r1
    c.r[8] = ld32(0x0605AC50u);  // 0605AAD4 mov.l 0x0605AC50,r8
    c.r[4] = ld32(0x0605AC54u);  // 0605AAD6 mov.l 0x0605AC54,r4
    c.r[5] = ld32(0x0605AC58u);  // 0605AAD8 mov.l 0x0605AC58,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605AB9Cu);  // 0605AADA mov.w 0x0605AB9C,r6
    c.r[7] = 0x0u;  // 0605AADC mov #0,r7
    st32(c.r[2], c.r[1]);  // 0605AADE mov.l r1,@r2
    c.r[2] = 0x0u;  // 0605AAE0 mov #0,r2
L_0605AAE2:
    c.r[0] = ld32(c.r[3] + 12);  // 0605AAE2 mov.l @(12,r3),r0
    st32(c.r[0] + c.r[7], c.r[8]);  // 0605AAE4 mov.l r8,@(r0,r7)
    c.r[1] = ld32(c.r[3] + 12);  // 0605AAE6 mov.l @(12,r3),r1
    c.r[2] += 1;  // 0605AAE8 add #1,r2
    c.r[1] += c.r[7];  // 0605AAEA add r7,r1
    st32(c.r[1] + 4, c.r[4]);  // 0605AAEC mov.l r4,@(4,r1)
    c.r[1] = ld32(c.r[3] + 12);  // 0605AAEE mov.l @(12,r3),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0605AAF0 cmp/gt r6,r2
    c.r[1] += c.r[7];  // 0605AAF2 add r7,r1
    st32(c.r[1] + 8, c.r[5]);  // 0605AAF4 mov.l r5,@(8,r1)
    { const bool k = !c.t; c.r[7] += 12; if (k) { SH2_POLL(c); goto L_0605AAE2; } }  // 0605AAF6 bf/s 0x0605AAE2 ; add #12,r7
L_0605AAFA:
    c.r[0] = ld32(0x0605ABD0u);  // 0605AAFA mov.l 0x0605ABD0,r0
    c.r[1] = ld32(c.r[0]);  // 0605AAFC mov.l @r0,r1
    c.r[1] += 1;  // 0605AAFE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AB00 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0605AB02 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0605AB04 extu.b r1,r1
    c.t = c.r[1] > c.r[0];  // 0605AB06 cmp/hi r0,r1
    { const bool k = !c.t; c.r[7] = 0xFFFFFFFFu; if (k) { goto L_0605AB10; } }  // 0605AB08 bf/s 0x0605AB10 ; mov #-1,r7
    goto L_0605ADAC;  // 0605AB0C bra 0x0605ADAC ; nop
L_0605AB10:
    c.r[6] = ld32(0x0605AC5Cu);  // 0605AB10 mov.l 0x0605AC5C,r6
    c.r[5] = 0x0u;  // 0605AB12 mov #0,r5
    c.r[0] = ld32(0x0605AC60u);  // 0605AB14 mov.l 0x0605AC60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AB1Au; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AB1Au) return; }  // 0605AB16 jsr @r0 ; mov #15,r4
    c.r[5] = ld32(0x0605AC64u);  // 0605AB1A mov.l 0x0605AC64,r5
    c.r[4] = ld32(0x0605AC5Cu);  // 0605AB1C mov.l 0x0605AC5C,r4
    c.r[0] = ld32(0x0605AC68u);  // 0605AB1E mov.l 0x0605AC68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AB24u; c.r[11] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AB24u) return; }  // 0605AB20 jsr @r0 ; mov #0,r11
    c.r[8] = ld32(0x0605AC48u);  // 0605AB24 mov.l 0x0605AC48,r8
    c.r[13] = c.r[8];  // 0605AB26 mov r8,r13
    c.r[13] += 90;  // 0605AB28 add #90,r13
    c.r[1] = 0x2u;  // 0605AB2A mov #2,r1
    st8(c.r[13], c.r[1]);  // 0605AB2C mov.b r1,@r13
    c.r[12] = c.r[8];  // 0605AB2E mov r8,r12
    c.r[12] += 88;  // 0605AB30 add #88,r12
    c.r[4] = ld32(0x0605AC64u);  // 0605AB32 mov.l 0x0605AC64,r4
    c.r[0] = ld32(0x0605AC6Cu);  // 0605AB34 mov.l 0x0605AC6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AB3Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AB3Au) return; }  // 0605AB36 jsr @r0 ; mov #0,r5
    c.r[3] = c.r[0];  // 0605AB3A mov r0,r3
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605AB3C mov.l r11,@-r15
    c.r[0] = 0xAu;  // 0605AB3E mov #10,r0
    c.r[7] = c.r[13];  // 0605AB40 mov r13,r7
    c.r[1] = ld32(c.r[8] + 16);  // 0605AB42 mov.l @(16,r8),r1
    c.r[6] = c.r[12];  // 0605AB44 mov r12,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605AB46 mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0605AB48 mov.w @r12,r1
    c.r[5] = ld32(0x0605AC5Cu);  // 0605AB4A mov.l 0x0605AC5C,r5
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[0] & 0xFFFFu);  // 0605AB4C mulu.w r0,r1
    c.r[2] = ld32(c.r[8] + 8);  // 0605AB4E mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 0605AB50 sts macl,r1
    c.r[2] += c.r[1];  // 0605AB52 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0605AB54 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0605AB56 mov.l @(4,r8),r1
    c.r[4] = c.r[3];  // 0605AB58 mov r3,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605AB5A mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 0605AB5C mov.l @r8,r1
    c.r[0] = ld32(0x0605AC70u);  // 0605AB5E mov.l 0x0605AC70,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605AB60 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605AB62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605AB64 mov.l r0,@-r15
    c.r[0] = ld32(0x0605AC74u);  // 0605AB66 mov.l 0x0605AC74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AB6Cu; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AB6Cu) return; }  // 0605AB68 jsr @r0 ; mov.l r11,@-r15
    c.r[10] = ld32(0x0605AC78u);  // 0605AB6C mov.l 0x0605AC78,r10
    c.r[0] = 0x1u;  // 0605AB6E mov #1,r0
    c.r[15] += 32;  // 0605AB70 add #32,r15
    c.r[1] = 0x20u;  // 0605AB72 mov #32,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0605AB74 mov.b @r13,r9
    c.r[4] = ld32(0x0605AC7Cu);  // 0605AB76 mov.l 0x0605AC7C,r4
    c.r[9] = c.r[9] & 0xFFu;  // 0605AB78 extu.b r9,r9
    c.r[2] = c.r[9];  // 0605AB7A mov r9,r2
    c.r[2] -= 2;  // 0605AB7C add #-2,r2
    st8(c.r[10], c.r[0]);  // 0605AB7E mov.b r0,@r10
    c.r[0] = ld32(0x0605AC80u);  // 0605AB80 mov.l 0x0605AC80,r0
    c.macl = c.r[2] * c.r[1];  // 0605AB82 mul.l r1,r2
    c.r[5] = ld32(c.r[0]);  // 0605AB84 mov.l @r0,r5
    c.r[0] = ld32(0x0605AC84u);  // 0605AB86 mov.l 0x0605AC84,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605AB9Eu);  // 0605AB88 mov.w 0x0605AB9E,r1
    c.r[7] = 0x0u; goto L_0605AC88;  // 0605AB8A bra 0x0605AC88 ; mov #0,r7
L_0605AC88:
    c.r[5] += c.r[1];  // 0605AC88 add r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0605AC8Eu; c.r[6] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AC8Eu) return; }  // 0605AC8A jsr @r0 ; sts macl,r6
    c.r[0] = ld32(0x0605AE58u);  // 0605AC8E mov.l 0x0605AE58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AC94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AC94u) return; }  // 0605AC90 jsr @r0 ; nop
    c.r[0] = 0x0u;  // 0605AC94 mov #0,r0
    st8(c.r[10], c.r[0]);  // 0605AC96 mov.b r0,@r10
    c.r[1] = 0x20u;  // 0605AC98 mov #32,r1
    st8(c.r[13], c.r[1]);  // 0605AC9A mov.b r1,@r13
    c.r[4] = ld32(0x0605AE5Cu);  // 0605AC9C mov.l 0x0605AE5C,r4
    c.r[0] = ld32(0x0605AE60u);  // 0605AC9E mov.l 0x0605AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605ACA4u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ACA4u) return; }  // 0605ACA0 jsr @r0 ; mov #1,r5
    c.r[4] = c.r[0];  // 0605ACA4 mov r0,r4
    c.r[0] = ld32(0x0605AE64u);  // 0605ACA6 mov.l 0x0605AE64,r0
    c.r[7] = c.r[13];  // 0605ACA8 mov r13,r7
    c.r[1] = ld32(c.r[0]);  // 0605ACAA mov.l @r0,r1
    c.r[6] = c.r[12];  // 0605ACAC mov r12,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605ACAE mov.l r1,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0605ACB0 mov.w @r12,r3
    c.r[0] = 0xAu;  // 0605ACB2 mov #10,r0
    c.r[1] = ld32(c.r[8] + 16);  // 0605ACB4 mov.l @(16,r8),r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0605ACB6 extu.w r3,r2
    c.r[2] <<= 2;  // 0605ACB8 shll2 r2
    c.r[1] += c.r[2];  // 0605ACBA add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605ACBC mov.l r1,@-r15
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[0] & 0xFFFFu);  // 0605ACBE mulu.w r0,r3
    c.r[2] = ld32(c.r[8] + 8);  // 0605ACC0 mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 0605ACC2 sts macl,r1
    c.r[2] += c.r[1];  // 0605ACC4 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0605ACC6 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0605ACC8 mov.l @(4,r8),r1
    c.r[5] = ld32(0x0605AE68u);  // 0605ACCA mov.l 0x0605AE68,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605ACCC mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 0605ACCE mov.l @r8,r1
    c.r[0] = ld32(0x0605AE6Cu);  // 0605ACD0 mov.l 0x0605AE6C,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605ACD2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605ACD4 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605ACD6 mov.l r0,@-r15
    c.r[0] = ld32(0x0605AE70u);  // 0605ACD8 mov.l 0x0605AE70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605ACDEu; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ACDEu) return; }  // 0605ACDA jsr @r0 ; mov.l r11,@-r15
    st8(c.r[13], c.r[9]);  // 0605ACDE mov.b r9,@r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605AE48u);  // 0605ACE0 mov.w 0x0605AE48,r1
    c.r[0] = 0x1u;  // 0605ACE2 mov #1,r0
    c.r[15] += 32;  // 0605ACE4 add #32,r15
    c.r[9] = ld32(0x0605AE74u);  // 0605ACE6 mov.l 0x0605AE74,r9
    c.r[3] = ld32(c.r[8] + 8);  // 0605ACE8 mov.l @(8,r8),r3
    c.r[4] = ld32(0x0605AE5Cu);  // 0605ACEA mov.l 0x0605AE5C,r4
    c.r[3] += 44;  // 0605ACEC add #44,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605ACEE mov.w @r3,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605AE4Au);  // 0605ACF0 mov.w 0x0605AE4A,r8
    c.r[2] &= c.r[1];  // 0605ACF2 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605AE4Cu);  // 0605ACF4 mov.w 0x0605AE4C,r1
    c.r[2] |= c.r[1];  // 0605ACF6 or r1,r2
    st16(c.r[3], c.r[2]);  // 0605ACF8 mov.w r2,@r3
    st8(c.r[10], c.r[0]);  // 0605ACFA mov.b r0,@r10
    c.r[0] = ld32(0x0605AE60u);  // 0605ACFC mov.l 0x0605AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD02u; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD02u) return; }  // 0605ACFE jsr @r0 ; mov #2,r5
    c.r[1] = c.r[0];  // 0605AD02 mov r0,r1
    c.r[7] = 0x0u;  // 0605AD04 mov #0,r7
    c.r[6] = c.r[8];  // 0605AD06 mov r8,r6
    c.r[5] = c.r[9];  // 0605AD08 mov r9,r5
    c.r[0] = ld32(0x0605AE78u);  // 0605AD0A mov.l 0x0605AE78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD10u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD10u) return; }  // 0605AD0C jsr @r0 ; mov r1,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605AE4Eu);  // 0605AD10 mov.w 0x0605AE4E,r8
    c.r[9] = ld32(0x0605AE7Cu);  // 0605AD12 mov.l 0x0605AE7C,r9
    c.r[4] = ld32(0x0605AE5Cu);  // 0605AD14 mov.l 0x0605AE5C,r4
    c.r[0] = ld32(0x0605AE60u);  // 0605AD16 mov.l 0x0605AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD1Cu; c.r[5] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD1Cu) return; }  // 0605AD18 jsr @r0 ; mov #3,r5
    c.r[1] = c.r[0];  // 0605AD1C mov r0,r1
    c.r[7] = 0x0u;  // 0605AD1E mov #0,r7
    c.r[6] = c.r[8];  // 0605AD20 mov r8,r6
    c.r[5] = c.r[9];  // 0605AD22 mov r9,r5
    c.r[0] = ld32(0x0605AE78u);  // 0605AD24 mov.l 0x0605AE78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD2Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD2Au) return; }  // 0605AD26 jsr @r0 ; mov r1,r4
    c.r[0] = ld32(0x0605AE58u);  // 0605AD2A mov.l 0x0605AE58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD30u) return; }  // 0605AD2C jsr @r0 ; nop
    c.r[0] = 0x0u;  // 0605AD30 mov #0,r0
    st8(c.r[10], c.r[0]);  // 0605AD32 mov.b r0,@r10
    c.r[0] = ld32(0x0605AE64u);  // 0605AD34 mov.l 0x0605AE64,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605AE50u);  // 0605AD36 mov.w 0x0605AE50,r1
    c.r[5] = 0x4u;  // 0605AD38 mov #4,r5
    c.r[8] = ld32(c.r[0]);  // 0605AD3A mov.l @r0,r8
    c.r[4] = ld32(0x0605AE5Cu);  // 0605AD3C mov.l 0x0605AE5C,r4
    c.r[0] = ld32(0x0605AE60u);  // 0605AD3E mov.l 0x0605AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD44u; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD44u) return; }  // 0605AD40 jsr @r0 ; add r1,r8
    c.r[2] = c.r[0];  // 0605AD44 mov r0,r2
    c.r[1] = ld32(0x0605AE80u);  // 0605AD46 mov.l 0x0605AE80,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605AE52u);  // 0605AD48 mov.w 0x0605AE52,r6
    c.r[5] = c.r[2];  // 0605AD4A mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605AD50u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD50u) return; }  // 0605AD4C jsr @r1 ; mov r8,r4
    c.r[8] = ld32(0x0605AE84u);  // 0605AD50 mov.l 0x0605AE84,r8
    c.r[5] = 0x15u;  // 0605AD52 mov #21,r5
    c.r[0] = ld32(0x0605AE60u);  // 0605AD54 mov.l 0x0605AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD5Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD5Au) return; }  // 0605AD56 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 0605AD5A mov r0,r1
    c.r[5] = ld32(0x0605AE5Cu);  // 0605AD5C mov.l 0x0605AE5C,r5
    c.r[0] = ld32(0x0605AE88u);  // 0605AD5E mov.l 0x0605AE88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD64u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD64u) return; }  // 0605AD60 jsr @r0 ; mov r1,r4
    c.r[0] = 0x1u;  // 0605AD64 mov #1,r0
    st8(c.r[10], c.r[0]);  // 0605AD66 mov.b r0,@r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605AE54u);  // 0605AD68 mov.w 0x0605AE54,r6
    c.r[5] = ld32(0x0605AE8Cu);  // 0605AD6A mov.l 0x0605AE8C,r5
    c.r[4] = ld32(0x0605AE5Cu);  // 0605AD6C mov.l 0x0605AE5C,r4
    c.r[0] = ld32(0x0605AE78u);  // 0605AD6E mov.l 0x0605AE78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD74u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD74u) return; }  // 0605AD70 jsr @r0 ; mov #0,r7
    c.r[0] = ld32(0x0605AE58u);  // 0605AD74 mov.l 0x0605AE58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD7Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD7Au) return; }  // 0605AD76 jsr @r0 ; nop
    c.r[0] = 0x0u;  // 0605AD7A mov #0,r0
    st8(c.r[10], c.r[0]);  // 0605AD7C mov.b r0,@r10
    c.r[5] = 0x25u;  // 0605AD7E mov #37,r5
    c.r[0] = ld32(0x0605AE60u);  // 0605AD80 mov.l 0x0605AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD86u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD86u) return; }  // 0605AD82 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 0605AD86 mov r0,r1
    c.r[1] += 4;  // 0605AD88 add #4,r1
    c.r[5] = ld32(0x0605AE5Cu);  // 0605AD8A mov.l 0x0605AE5C,r5
    c.r[0] = ld32(0x0605AE88u);  // 0605AD8C mov.l 0x0605AE88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605AD92u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AD92u) return; }  // 0605AD8E jsr @r0 ; mov r1,r4
    c.r[0] = 0x1u;  // 0605AD92 mov #1,r0
    st8(c.r[10], c.r[0]);  // 0605AD94 mov.b r0,@r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605AE56u);  // 0605AD96 mov.w 0x0605AE56,r6
    c.r[5] = ld32(0x0605AE90u);  // 0605AD98 mov.l 0x0605AE90,r5
    c.r[4] = ld32(0x0605AE5Cu);  // 0605AD9A mov.l 0x0605AE5C,r4
    c.r[0] = ld32(0x0605AE78u);  // 0605AD9C mov.l 0x0605AE78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605ADA2u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADA2u) return; }  // 0605AD9E jsr @r0 ; mov #14,r7
    c.r[0] = ld32(0x0605AE58u);  // 0605ADA2 mov.l 0x0605AE58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605ADA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADA8u) return; }  // 0605ADA4 jsr @r0 ; nop
    c.r[0] = 0x0u;  // 0605ADA8 mov #0,r0
    st8(c.r[10], c.r[0]);  // 0605ADAA mov.b r0,@r10
L_0605ADAC:
    c.r[1] = ld32(0x0605AE94u);  // 0605ADAC mov.l 0x0605AE94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605ADB2u; c.r[4] = 0x58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADB2u) return; }  // 0605ADAE jsr @r1 ; mov #88,r4
    c.r[1] = ld32(0x0605AE98u);  // 0605ADB2 mov.l 0x0605AE98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605ADB8u; c.r[4] = 0x48u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADB8u) return; }  // 0605ADB4 jsr @r1 ; mov #72,r4
    c.r[1] = ld32(0x0605AE9Cu);  // 0605ADB8 mov.l 0x0605AE9C,r1
    c.r[5] = 0xAu;  // 0605ADBA mov #10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605ADC0u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADC0u) return; }  // 0605ADBC jsr @r1 ; mov #2,r4
    c.r[1] = ld32(0x0605AEA0u);  // 0605ADC0 mov.l 0x0605AEA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605ADC6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADC6u) return; }  // 0605ADC2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0605AEA4u);  // 0605ADC6 mov.l 0x0605AEA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605ADCCu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADCCu) return; }  // 0605ADC8 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x0605AEA8u);  // 0605ADCC mov.l 0x0605AEA8,r1
    c.r[5] = 0x14u;  // 0605ADCE mov #20,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605ADD4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADD4u) return; }  // 0605ADD0 jsr @r1 ; mov #1,r4
    c.r[8] = ld32(0x0605AEACu);  // 0605ADD4 mov.l 0x0605AEAC,r8
    c.r[5] = 0x1u;  // 0605ADD6 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605ADDCu; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADDCu) return; }  // 0605ADD8 jsr @r8 ; mov #5,r4
    c.r[5] = 0x2u;  // 0605ADDC mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605ADE2u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADE2u) return; }  // 0605ADDE jsr @r8 ; mov #2,r4
    c.r[5] = 0x4u;  // 0605ADE2 mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605ADE8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADE8u) return; }  // 0605ADE4 jsr @r8 ; mov #3,r4
    c.r[5] = 0x5u;  // 0605ADE8 mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605ADEEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADEEu) return; }  // 0605ADEA jsr @r8 ; mov #0,r4
    c.r[5] = 0x2u;  // 0605ADEE mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605ADF4u; c.r[4] = 0xFFFFFFFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADF4u) return; }  // 0605ADF0 jsr @r8 ; mov #-6,r4
    c.r[5] = 0x3u;  // 0605ADF4 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605ADFAu; c.r[4] = 0xFFFFFFF9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605ADFAu) return; }  // 0605ADF6 jsr @r8 ; mov #-7,r4
    c.r[5] = 0x4u;  // 0605ADFA mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE00u; c.r[4] = 0xFFFFFFF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE00u) return; }  // 0605ADFC jsr @r8 ; mov #-8,r4
    c.r[5] = 0x5u;  // 0605AE00 mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE06u; c.r[4] = 0xFFFFFFFBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE06u) return; }  // 0605AE02 jsr @r8 ; mov #-5,r4
    c.r[5] = 0x6u;  // 0605AE06 mov #6,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE0Cu; c.r[4] = 0xFFFFFFFDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE0Cu) return; }  // 0605AE08 jsr @r8 ; mov #-3,r4
    c.r[5] = 0x7u;  // 0605AE0C mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE12u; c.r[4] = 0xFFFFFFFCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE12u) return; }  // 0605AE0E jsr @r8 ; mov #-4,r4
    c.r[5] = 0x7u;  // 0605AE12 mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE18u; c.r[4] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE18u) return; }  // 0605AE14 jsr @r8 ; mov #-1,r4
    c.r[5] = 0x7u;  // 0605AE18 mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE1Eu; c.r[4] = 0xFFFFFFFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE1Eu) return; }  // 0605AE1A jsr @r8 ; mov #-2,r4
    c.r[5] = 0x7u;  // 0605AE1E mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE24u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE24u) return; }  // 0605AE20 jsr @r8 ; mov #1,r4
    c.r[0] = ld32(0x0605AEB0u);  // 0605AE24 mov.l 0x0605AEB0,r0
    c.r[1] = ld32(c.r[0]);  // 0605AE26 mov.l @r0,r1
    c.r[1] += 1;  // 0605AE28 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AE2A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605AE2C extu.b r1,r1
    c.r[0] = c.r[1];  // 0605AE2E mov r1,r0
    c.t = c.r[0] == 0x5u;  // 0605AE30 cmp/eq #5,r0
    { const bool k = !c.t; c.r[5] = 0x7u; if (k) { goto L_0605AEBC; } }  // 0605AE32 bf/s 0x0605AEBC ; mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE3Au; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE3Au) return; }  // 0605AE36 jsr @r8 ; mov #3,r4
    c.r[5] = 0x7u;  // 0605AE3A mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605AE40u; c.r[4] = 0xFFFFFFF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AE40u) return; }  // 0605AE3C jsr @r8 ; mov #-8,r4
    c.r[4] = ld32(0x0605AEB4u);  // 0605AE40 mov.l 0x0605AEB4,r4
    c.r[0] = ld32(0x0605AEB8u);  // 0605AE42 mov.l 0x0605AEB8,r0
    goto L_0605AEC0;  // 0605AE44 bra 0x0605AEC0 ; nop
L_0605AEBC:
    c.r[0] = ld32(0x0605AF44u);  // 0605AEBC mov.l 0x0605AF44,r0
    c.r[4] = 0x1Fu;  // 0605AEBE mov #31,r4
L_0605AEC0:
    { const uint32_t x = c.r[0]; c.pr = 0x0605AEC4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AEC4u) return; }  // 0605AEC0 jsr @r0 ; nop
    c.r[1] = ld32(0x0605AF48u);  // 0605AEC4 mov.l 0x0605AF48,r1
    c.r[1] = ld32(c.r[1]);  // 0605AEC6 mov.l @r1,r1
    c.r[1] += 1;  // 0605AEC8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AECA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605AECC extu.b r1,r1
    c.r[0] = c.r[1];  // 0605AECE mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0605AED0 cmp/eq #3,r0
    { const bool k = c.t; c.t = c.r[0] == 0x6u; if (k) { goto L_0605AEDE; } }  // 0605AED2 bt/s 0x0605AEDE ; cmp/eq #6,r0
    if (c.t) { goto L_0605AEDE; }  // 0605AED6 bt 0x0605AEDE
    c.r[4] = ld32(0x0605AF4Cu);  // 0605AED8 mov.l 0x0605AF4C,r4
    goto L_0605AEF2;  // 0605AEDA bra 0x0605AEF2 ; nop
L_0605AEDE:
    c.r[1] = ld32(0x0605AF50u);  // 0605AEDE mov.l 0x0605AF50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AEE0 mov.b @r1,r1
    c.r[4] = ld32(0x0605AF54u);  // 0605AEE2 mov.l 0x0605AF54,r4
    c.r[0] = c.r[1];  // 0605AEE4 mov r1,r0
    c.r[0] >>= 2;  // 0605AEE6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605AEE8 shlr r0
    c.r[0] &= 0x1u;  // 0605AEEA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605AEEC tst r0,r0
    if (c.t) { goto L_0605AEF2; }  // 0605AEEE bt 0x0605AEF2
    c.r[4] = ld32(0x0605AF58u);  // 0605AEF0 mov.l 0x0605AF58,r4
L_0605AEF2:
    c.r[1] = ld32(0x0605AF5Cu);  // 0605AEF2 mov.l 0x0605AF5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605AEF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AEF8u) return; }  // 0605AEF4 jsr @r1 ; nop
    c.r[1] = ld32(0x0605AF48u);  // 0605AEF8 mov.l 0x0605AF48,r1
    c.r[1] = ld32(c.r[1]);  // 0605AEFA mov.l @r1,r1
    c.r[1] += 1;  // 0605AEFC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AEFE mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605AF00 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 0605AF02 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0605AF28; } }  // 0605AF04 bf/s 0x0605AF28 ; mov #0,r2
    c.r[5] = 0x3Fu;  // 0605AF08 mov #63,r5
    c.r[6] = ld32(0x0605AF60u);  // 0605AF0A mov.l 0x0605AF60,r6
    c.r[7] = 0xFFFFFFFFu;  // 0605AF0C mov #-1,r7
    c.r[3] = 0x0u;  // 0605AF0E mov #0,r3
L_0605AF10:
    c.r[1] = 0x0u;  // 0605AF10 mov #0,r1
L_0605AF12:
    c.r[0] = ld32(c.r[6]);  // 0605AF12 mov.l @r6,r0
    c.r[0] += c.r[3];  // 0605AF14 add r3,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0605AF16 mov.b r7,@(r0,r1)
    c.r[1] += 1;  // 0605AF18 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5];  // 0605AF1A cmp/gt r5,r1
    if (!c.t) { SH2_POLL(c); goto L_0605AF12; }  // 0605AF1C bf 0x0605AF12
    c.r[2] += 1;  // 0605AF1E add #1,r2
    c.r[1] = 0x3Fu;  // 0605AF20 mov #63,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0605AF22 cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] += 64; if (k) { SH2_POLL(c); goto L_0605AF10; } }  // 0605AF24 bf/s 0x0605AF10 ; add #64,r3
L_0605AF28:
    c.r[14] += 16;  // 0605AF28 add #16,r14
    c.r[15] = c.r[14];  // 0605AF2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605AF2C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605AF2E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605AF30 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605AF32 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605AF34 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605AF36 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605AF38 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605AF40u);  // 0605AF3A mov.w 0x0605AF40,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605AF3C rts ; mov.l @r15+,r8
}

void f_0605AF64(SH2Context& c) {
    ran[1383] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605AF64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605AF66 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605AF68 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605AF6A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605AF6C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605AF6E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605AF70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605AF72 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B0AAu);  // 0605AF74 mov.w 0x0605B0AA,r3
    c.r[15] += c.r[3];  // 0605AF76 add r3,r15
    c.r[14] = c.r[15];  // 0605AF78 mov r15,r14
    c.r[13] = ld32(0x0605B0BCu);  // 0605AF7A mov.l 0x0605B0BC,r13
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605B0ACu);  // 0605AF7C mov.w 0x0605B0AC,r8
    c.r[0] = ld32(0x0605B0C0u);  // 0605AF7E mov.l 0x0605B0C0,r0
    c.r[12] = ld32(0x0605B0C4u);  // 0605AF80 mov.l 0x0605B0C4,r12
    c.r[7] = ld32(0x0605B0C8u);  // 0605AF82 mov.l 0x0605B0C8,r7
    c.r[1] = ld32(c.r[0]);  // 0605AF84 mov.l @r0,r1
    c.r[5] = 0xFFFFFFFFu;  // 0605AF86 mov #-1,r5
    c.r[1] += 4;  // 0605AF88 add #4,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AF8A mov.b @r1,r6
    c.r[4] = 0x1u;  // 0605AF8C mov #1,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0605AF8E extu.b r6,r6
    c.r[6] -= 1;  // 0605AF90 add #-1,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0605AF96u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AF96u) return; }  // 0605AF92 jsr @r12 ; mov.l r13,@-r15
    c.r[4] = ld32(0x0605B0C8u);  // 0605AF96 mov.l 0x0605B0C8,r4
    c.r[4] += 72;  // 0605AF98 add #72,r4
    c.r[10] = ld32(0x0605B0CCu);  // 0605AF9A mov.l 0x0605B0CC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0605AFA0u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AFA0u) return; }  // 0605AF9C jsr @r10 ; mov r13,r5
    c.r[3] = c.r[13];  // 0605AFA0 mov r13,r3
    c.r[3] += 10;  // 0605AFA2 add #10,r3
    c.r[2] = ld32(0x0605B0D0u);  // 0605AFA4 mov.l 0x0605B0D0,r2
    c.r[2] += 76;  // 0605AFA6 add #76,r2
    c.r[11] = c.r[13];  // 0605AFA8 mov r13,r11
    c.r[11] += 11;  // 0605AFAA add #11,r11
    c.r[9] = ld32(0x0605B0D4u);  // 0605AFAC mov.l 0x0605B0D4,r9
    c.r[6] = c.r[8];  // 0605AFAE mov r8,r6
    c.r[5] = ld32(c.r[13] + 4);  // 0605AFB0 mov.l @(4,r13),r5
    c.r[4] = ld32(0x0605B0D8u);  // 0605AFB2 mov.l 0x0605B0D8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605AFB4 mov.b @r3,r1
    c.r[5] -= 4;  // 0605AFB6 add #-4,r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0605AFB8 shlr r5
    st8(c.r[2], c.r[1]);  // 0605AFBA mov.b r1,@r2
    c.r[2] = ld32(0x0605B0D0u);  // 0605AFBC mov.l 0x0605B0D0,r2
    c.r[2] += 77;  // 0605AFBE add #77,r2
    c.r[5] += c.r[5];  // 0605AFC0 add r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605AFC2 mov.b @r11,r1
    c.r[5] += c.r[13];  // 0605AFC4 add r13,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605AFCAu; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AFCAu) return; }  // 0605AFC6 jsr @r9 ; mov.b r1,@r2
    c.r[2] = ld32(0x0605B0C8u);  // 0605AFCA mov.l 0x0605B0C8,r2
    c.r[2] += 66;  // 0605AFCC add #66,r2
    c.r[1] = ld32(0x0605B0C8u);  // 0605AFCE mov.l 0x0605B0C8,r1
    c.r[1] += 67;  // 0605AFD0 add #67,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605AFD2 mov.b @r2,r4
    c.r[5] = c.r[13];  // 0605AFD4 mov r13,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605AFD6 mov.b @r1,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0605AFD8 extu.b r4,r4
    c.r[4] <<= 8;  // 0605AFDA shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0605AFDC extu.b r1,r1
    c.r[4] |= c.r[1];  // 0605AFDE or r1,r4
    c.r[4] += 1;  // 0605AFE0 add #1,r4
    c.r[4] += c.r[2];  // 0605AFE2 add r2,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605AFE8u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605AFE8u) return; }  // 0605AFE4 jsr @r10 ; add #4,r4
    c.r[3] = c.r[13];  // 0605AFE8 mov r13,r3
    c.r[3] += 10;  // 0605AFEA add #10,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B0AEu);  // 0605AFEC mov.w 0x0605B0AE,r0
    c.r[0] += c.r[14];  // 0605AFEE add r14,r0
    c.r[6] = c.r[8];  // 0605AFF0 mov r8,r6
    c.r[5] = ld32(c.r[13] + 4);  // 0605AFF2 mov.l @(4,r13),r5
    c.r[4] = ld32(0x0605B0DCu);  // 0605AFF4 mov.l 0x0605B0DC,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605AFF6 mov.b @r3,r1
    c.r[5] -= 4;  // 0605AFF8 add #-4,r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0605AFFA shlr r5
    c.r[1] = c.r[1] & 0xFFu;  // 0605AFFC extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0605AFFE mov.l r1,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B0B0u);  // 0605B000 mov.w 0x0605B0B0,r0
    c.r[0] += c.r[14];  // 0605B002 add r14,r0
    c.r[5] += c.r[5];  // 0605B004 add r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605B006 mov.b @r11,r1
    c.r[5] += c.r[13];  // 0605B008 add r13,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0605B00A extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0605B010u; st32(c.r[0], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B010u) return; }  // 0605B00C jsr @r9 ; mov.l r1,@r0
    c.r[8] = ld32(0x0605B0E0u);  // 0605B010 mov.l 0x0605B0E0,r8
    c.r[6] = 0x42u;  // 0605B012 mov #66,r6
    c.r[5] = ld32(0x0605B0C8u);  // 0605B014 mov.l 0x0605B0C8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605B01Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B01Au) return; }  // 0605B016 jsr @r9 ; mov r8,r4
    c.r[0] = 0x3Fu;  // 0605B01A mov #63,r0
    c.r[7] = ld32(0x0605B0C8u);  // 0605B01C mov.l 0x0605B0C8,r7
    c.r[5] = 0xFFFFFFFFu;  // 0605B01E mov #-1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605B020 mov.b @r8,r1
    c.r[4] = 0x0u;  // 0605B022 mov #0,r4
    c.r[1] &= c.r[0];  // 0605B024 and r0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605B026 mov.l r13,@-r15
    { const uint32_t x = c.r[12]; c.pr = 0x0605B02Cu; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B02Cu) return; }  // 0605B028 jsr @r12 ; mov r1,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605B0B0u);  // 0605B02C mov.w 0x0605B0B0,r4
    c.r[0] = ld32(0x0605B0C8u);  // 0605B02E mov.l 0x0605B0C8,r0
    c.r[4] += c.r[0];  // 0605B030 add r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605B036u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B036u) return; }  // 0605B032 jsr @r10 ; mov r13,r5
    c.r[2] = ld32(0x0605B0E4u);  // 0605B036 mov.l 0x0605B0E4,r2
    c.r[1] = 0x1u;  // 0605B038 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0605B03A mov.b r1,@r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0605B0B2u);  // 0605B03C mov.w 0x0605B0B2,r10
    c.r[5] = ld32(0x0605B0E8u);  // 0605B03E mov.l 0x0605B0E8,r5
    c.r[9] = ld32(0x0605B0ECu);  // 0605B040 mov.l 0x0605B0EC,r9
    c.r[7] = 0xEu;  // 0605B042 mov #14,r7
    c.r[6] = c.r[10];  // 0605B044 mov r10,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0605B04Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B04Au) return; }  // 0605B046 jsr @r9 ; mov r13,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605B0AEu);  // 0605B04A mov.w 0x0605B0AE,r6
    c.r[5] = ld32(0x0605B0F0u);  // 0605B04C mov.l 0x0605B0F0,r5
    c.r[4] = ld32(0x0605B0C8u);  // 0605B04E mov.l 0x0605B0C8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605B054u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B054u) return; }  // 0605B050 jsr @r9 ; mov #14,r7
    c.r[0] = ld32(0x0605B0C0u);  // 0605B054 mov.l 0x0605B0C0,r0
    c.r[1] = ld32(c.r[0]);  // 0605B056 mov.l @r0,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605B0B4u);  // 0605B058 mov.w 0x0605B0B4,r8
    c.r[0] = c.r[1];  // 0605B05A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605B05C mov.b @(r0,r8),r1
    c.r[4] = c.r[1] & 0xFFu;  // 0605B05E extu.b r1,r4
    c.r[4] >>= 2;  // 0605B060 shlr2 r4
    c.r[4] >>= 2;  // 0605B062 shlr2 r4
    c.r[4] >>= 2;  // 0605B064 shlr2 r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0605B066 tst r4,r4
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_0605B0F8; } }  // 0605B068 bt/s 0x0605B0F8 ; add #8,r15
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605B0B6u);  // 0605B06C mov.w 0x0605B0B6,r2
    c.r[0] = ld32(0x0605B0D0u);  // 0605B06E mov.l 0x0605B0D0,r0
    c.r[4] -= 1;  // 0605B070 add #-1,r4
    c.r[4] <<= 8;  // 0605B072 shll8 r4
    c.r[4] += c.r[4];  // 0605B074 add r4,r4
    c.r[7] = 0xEu;  // 0605B076 mov #14,r7
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0605B078 mov.l @(r0,r2),r5
    c.r[6] = c.r[10];  // 0605B07A mov r10,r6
    c.r[0] = ld32(0x0605B0C8u);  // 0605B07C mov.l 0x0605B0C8,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0605B082u; c.r[4] += c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B082u) return; }  // 0605B07E jsr @r9 ; add r0,r4
    c.r[1] = ld32(0x0605B0F4u);  // 0605B082 mov.l 0x0605B0F4,r1
    c.r[5] = ld32(c.r[1]);  // 0605B084 mov.l @r1,r5
    c.r[0] = ld32(0x0605B0C0u);  // 0605B086 mov.l 0x0605B0C0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B0B8u);  // 0605B088 mov.w 0x0605B0B8,r1
    c.r[5] += c.r[1];  // 0605B08A add r1,r5
    c.r[1] = ld32(c.r[0]);  // 0605B08C mov.l @r0,r1
    c.r[7] = 0xEu;  // 0605B08E mov #14,r7
    c.r[0] = c.r[1];  // 0605B090 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605B092 mov.b @(r0,r8),r4
    c.r[6] = c.r[10];  // 0605B094 mov r10,r6
    c.r[4] = c.r[4] & 0xFFu;  // 0605B096 extu.b r4,r4
    c.r[4] >>= 2;  // 0605B098 shlr2 r4
    c.r[4] >>= 2;  // 0605B09A shlr2 r4
    c.r[4] >>= 2;  // 0605B09C shlr2 r4
    c.r[4] -= 1;  // 0605B09E add #-1,r4
    c.r[4] <<= 8;  // 0605B0A0 shll8 r4
    c.r[4] += c.r[4];  // 0605B0A2 add r4,r4
    c.r[0] = ld32(0x0605B0C8u);  // 0605B0A4 mov.l 0x0605B0C8,r0
    c.r[4] += c.r[0]; goto L_0605B114;  // 0605B0A6 bra 0x0605B114 ; add r0,r4
L_0605B0F8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B29Au);  // 0605B0F8 mov.w 0x0605B29A,r1
    c.r[0] = ld32(0x0605B2C0u);  // 0605B0FA mov.l 0x0605B2C0,r0
    c.r[7] = 0xEu;  // 0605B0FC mov #14,r7
    c.r[6] = c.r[10];  // 0605B0FE mov r10,r6
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0605B100 mov.l @(r0,r1),r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605B106u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B106u) return; }  // 0605B102 jsr @r9 ; mov r13,r4
    c.r[1] = ld32(0x0605B2C4u);  // 0605B106 mov.l 0x0605B2C4,r1
    c.r[7] = 0xEu;  // 0605B108 mov #14,r7
    c.r[6] = c.r[10];  // 0605B10A mov r10,r6
    c.r[5] = ld32(c.r[1]);  // 0605B10C mov.l @r1,r5
    c.r[4] = c.r[13];  // 0605B10E mov r13,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B29Cu);  // 0605B110 mov.w 0x0605B29C,r1
    c.r[5] += c.r[1];  // 0605B112 add r1,r5
L_0605B114:
    { const uint32_t x = c.r[9]; c.pr = 0x0605B118u; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B118u) return; }  // 0605B114 jsr @r9 ; mov #0,r10
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605B29Eu);  // 0605B118 mov.w 0x0605B29E,r5
    c.r[5] += c.r[13];  // 0605B11A add r13,r5
    c.r[8] = ld32(0x0605B2C8u);  // 0605B11C mov.l 0x0605B2C8,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605B2A0u);  // 0605B11E mov.w 0x0605B2A0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0605B124u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B124u) return; }  // 0605B120 jsr @r8 ; mov r14,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605B2A2u);  // 0605B124 mov.w 0x0605B2A2,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605B2A4u);  // 0605B126 mov.w 0x0605B2A4,r6
    c.r[4] = ld32(0x0605B2CCu);  // 0605B128 mov.l 0x0605B2CC,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0605B12Eu; c.r[5] += c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B12Eu) return; }  // 0605B12A jsr @r8 ; add r13,r5
    c.r[6] = ld32(0x0605B2D0u);  // 0605B12E mov.l 0x0605B2D0,r6
    c.r[8] = ld32(0x0605B2C0u);  // 0605B130 mov.l 0x0605B2C0,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B2A6u);  // 0605B132 mov.w 0x0605B2A6,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605B2A8u);  // 0605B134 mov.w 0x0605B2A8,r4
    c.r[4] += c.r[13];  // 0605B136 add r13,r4
    c.r[9] = ld32(0x0605B2D4u);  // 0605B138 mov.l 0x0605B2D4,r9
    c.r[5] = ld32(c.r[0] + c.r[8]);  // 0605B13A mov.l @(r0,r8),r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605B140u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B140u) return; }  // 0605B13C jsr @r9 ; mov #14,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605B2AAu);  // 0605B140 mov.w 0x0605B2AA,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B2ACu);  // 0605B142 mov.w 0x0605B2AC,r0
    c.r[4] = ld32(0x0605B2D8u);  // 0605B144 mov.l 0x0605B2D8,r4
    c.r[4] += c.r[13];  // 0605B146 add r13,r4
    c.r[5] = ld32(c.r[0] + c.r[8]);  // 0605B148 mov.l @(r0,r8),r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605B14Eu; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B14Eu) return; }  // 0605B14A jsr @r9 ; mov #14,r7
    c.r[1] = ld32(0x0605B2DCu);  // 0605B14E mov.l 0x0605B2DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605B154u; c.r[9] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B154u) return; }  // 0605B150 jsr @r1 ; mov #31,r9
    c.r[2] = ld32(0x0605B2E0u);  // 0605B154 mov.l 0x0605B2E0,r2
    c.r[1] = 0x0u;  // 0605B156 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0605B158 mov.b r1,@r2
    c.r[7] = 0x0u;  // 0605B15A mov #0,r7
    c.r[3] = c.r[13];  // 0605B15C mov r13,r3
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605B2AEu);  // 0605B15E mov.w 0x0605B2AE,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605B2B0u);  // 0605B160 mov.w 0x0605B2B0,r5
L_0605B162:
    c.r[0] = c.r[8];  // 0605B162 mov r8,r0
L_0605B164:
    c.r[10] += 1;  // 0605B164 add #1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0605B166 mov.w @(r0,r4),r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[9];  // 0605B168 cmp/gt r9,r10
    st16(c.r[3], c.r[1]);  // 0605B16A mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 0605B16C mov.w @(r0,r5),r1
    c.r[3] += 2;  // 0605B16E add #2,r3
    st16(c.r[3], c.r[1]);  // 0605B170 mov.w r1,@r3
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0605B162; } }  // 0605B172 bf/s 0x0605B162 ; add #2,r3
    c.r[10] = 0x0u;  // 0605B176 mov #0,r10
    c.r[6] = c.r[9];  // 0605B178 mov r9,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605B2B2u);  // 0605B17A mov.w 0x0605B2B2,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605B2B4u);  // 0605B17C mov.w 0x0605B2B4,r11
    c.r[0] = c.r[8];  // 0605B17E mov r8,r0
L_0605B180:
    c.r[10] += 1;  // 0605B180 add #1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0605B182 mov.w @(r0,r2),r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[6];  // 0605B184 cmp/gt r6,r10
    st16(c.r[3], c.r[1]);  // 0605B186 mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0605B188 mov.w @(r0,r11),r1
    c.r[3] += 2;  // 0605B18A add #2,r3
    st16(c.r[3], c.r[1]);  // 0605B18C mov.w r1,@r3
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0605B180; } }  // 0605B18E bf/s 0x0605B180 ; add #2,r3
    c.r[7] += 1;  // 0605B192 add #1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B2B6u);  // 0605B194 mov.w 0x0605B2B6,r1
    c.t = c.r[7] > c.r[1];  // 0605B196 cmp/hi r1,r7
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { SH2_POLL(c); goto L_0605B164; } }  // 0605B198 bf/s 0x0605B164 ; mov #0,r10
    c.r[11] = ld32(0x0605B2E0u);  // 0605B19C mov.l 0x0605B2E0,r11
    c.r[1] = 0x1u;  // 0605B19E mov #1,r1
    st8(c.r[11], c.r[1]);  // 0605B1A0 mov.b r1,@r11
    c.r[8] = ld32(0x0605B2E4u);  // 0605B1A2 mov.l 0x0605B2E4,r8
    c.r[9] = ld32(0x0605B2C0u);  // 0605B1A4 mov.l 0x0605B2C0,r9
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605B2B8u);  // 0605B1A6 mov.w 0x0605B2B8,r12
    c.r[0] = c.r[9];  // 0605B1A8 mov r9,r0
    c.r[10] = ld32(0x0605B2D4u);  // 0605B1AA mov.l 0x0605B2D4,r10
    c.r[7] = 0xEu;  // 0605B1AC mov #14,r7
    c.r[6] = c.r[8];  // 0605B1AE mov r8,r6
    c.r[5] = ld32(c.r[0] + c.r[12]);  // 0605B1B0 mov.l @(r0,r12),r5
    { const uint32_t x = c.r[10]; c.pr = 0x0605B1B6u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B1B6u) return; }  // 0605B1B2 jsr @r10 ; mov r13,r4
    c.r[0] = c.r[9];  // 0605B1B6 mov r9,r0
    c.r[7] = 0xEu;  // 0605B1B8 mov #14,r7
    c.r[6] = c.r[8];  // 0605B1BA mov r8,r6
    c.r[5] = ld32(c.r[0] + c.r[12]);  // 0605B1BC mov.l @(r0,r12),r5
    c.r[4] = c.r[13];  // 0605B1BE mov r13,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605B1C4u; c.r[5] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B1C4u) return; }  // 0605B1C0 jsr @r10 ; add r8,r5
    c.r[1] = ld32(0x0605B2DCu);  // 0605B1C4 mov.l 0x0605B2DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605B1CAu; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B1CAu) return; }  // 0605B1C6 jsr @r1 ; mov #0,r10
    c.r[1] = 0x0u;  // 0605B1CA mov #0,r1
    st8(c.r[11], c.r[1]);  // 0605B1CC mov.b r1,@r11
    c.r[4] = 0x3Fu;  // 0605B1CE mov #63,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605B2BAu);  // 0605B1D0 mov.w 0x0605B2BA,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605B2BCu);  // 0605B1D2 mov.w 0x0605B2BC,r6
    c.r[2] = 0x0u;  // 0605B1D4 mov #0,r2
L_0605B1D6:
    c.r[7] = 0x0u;  // 0605B1D6 mov #0,r7
    c.r[3] = 0x0u;  // 0605B1D8 mov #0,r3
    c.r[0] = c.r[9];  // 0605B1DA mov r9,r0
L_0605B1DC:
    c.r[8] = ld32(c.r[0] + c.r[5]);  // 0605B1DC mov.l @(r0,r5),r8
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0605B1DE mov.l @(r0,r6),r1
    c.r[8] += c.r[2];  // 0605B1E0 add r2,r8
    c.r[1] += c.r[2];  // 0605B1E2 add r2,r1
    c.r[0] = c.r[1];  // 0605B1E4 mov r1,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0605B1E6 mov.b r3,@(r0,r7)
    c.r[0] = c.r[8];  // 0605B1E8 mov r8,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0605B1EA mov.b r3,@(r0,r7)
    c.r[7] += 1;  // 0605B1EC add #1,r7
    c.t = c.r[7] > c.r[4];  // 0605B1EE cmp/hi r4,r7
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_0605B1DC; } }  // 0605B1F0 bf/s 0x0605B1DC ; mov r9,r0
    c.r[10] += 1;  // 0605B1F4 add #1,r10
    c.r[1] = 0x3Fu;  // 0605B1F6 mov #63,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0605B1F8 cmp/gt r1,r10
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_0605B1D6; } }  // 0605B1FA bf/s 0x0605B1D6 ; add #64,r2
    c.r[8] = ld32(0x0605B2C0u);  // 0605B1FE mov.l 0x0605B2C0,r8
    c.r[11] = c.r[8];  // 0605B200 mov r8,r11
    c.r[11] += 77;  // 0605B202 add #77,r11
    c.r[10] = c.r[8];  // 0605B204 mov r8,r10
    c.r[10] += 76;  // 0605B206 add #76,r10
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605B2B8u);  // 0605B208 mov.w 0x0605B2B8,r13
    c.r[0] = c.r[8];  // 0605B20A mov r8,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605B2BAu);  // 0605B20C mov.w 0x0605B2BA,r12
    c.r[9] = ld32(0x0605B2E8u);  // 0605B20E mov.l 0x0605B2E8,r9
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605B210 mov.b @r11,r7
    c.r[5] = 0x0u;  // 0605B212 mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605B214 mov.b @r10,r6
    c.r[4] = ld32(0x0605B2ECu);  // 0605B216 mov.l 0x0605B2EC,r4
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B218 mov.l @(r0,r13),r1
    c.r[7] = c.r[7] & 0xFFu;  // 0605B21A extu.b r7,r7
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B21C mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B21E mov.l @(r0,r12),r1
    c.r[6] = c.r[6] & 0xFFu;  // 0605B220 extu.b r6,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B222 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B224 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B2CCu);  // 0605B226 mov.l 0x0605B2CC,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0605B22Cu; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B22Cu) return; }  // 0605B228 jsr @r9 ; mov.l r0,@-r15
    c.r[0] = c.r[8];  // 0605B22C mov r8,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605B22E mov.b @r11,r7
    c.r[5] = 0x1u;  // 0605B230 mov #1,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605B232 mov.b @r10,r6
    c.r[4] = ld32(0x0605B2ECu);  // 0605B234 mov.l 0x0605B2EC,r4
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B236 mov.l @(r0,r13),r1
    c.r[7] = c.r[7] & 0xFFu;  // 0605B238 extu.b r7,r7
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B23A mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B23C mov.l @(r0,r12),r1
    c.r[6] = c.r[6] & 0xFFu;  // 0605B23E extu.b r6,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B240 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B242 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B2CCu);  // 0605B244 mov.l 0x0605B2CC,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0605B24Au; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B24Au) return; }  // 0605B246 jsr @r9 ; mov.l r0,@-r15
    c.r[15] += 32;  // 0605B24A add #32,r15
    c.r[0] = c.r[8];  // 0605B24C mov r8,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605B24E mov.b @r11,r7
    c.r[5] = 0x2u;  // 0605B250 mov #2,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605B252 mov.b @r10,r6
    c.r[4] = ld32(0x0605B2ECu);  // 0605B254 mov.l 0x0605B2EC,r4
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B256 mov.l @(r0,r13),r1
    c.r[7] = c.r[7] & 0xFFu;  // 0605B258 extu.b r7,r7
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B25A mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B25C mov.l @(r0,r12),r1
    c.r[6] = c.r[6] & 0xFFu;  // 0605B25E extu.b r6,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B260 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B262 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B2CCu);  // 0605B264 mov.l 0x0605B2CC,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0605B26Au; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B26Au) return; }  // 0605B266 jsr @r9 ; mov.l r0,@-r15
    c.r[0] = c.r[8];  // 0605B26A mov r8,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605B26C mov.b @r11,r7
    c.r[5] = 0x3u;  // 0605B26E mov #3,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605B270 mov.b @r10,r6
    c.r[4] = ld32(0x0605B2ECu);  // 0605B272 mov.l 0x0605B2EC,r4
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B274 mov.l @(r0,r13),r1
    c.r[7] = c.r[7] & 0xFFu;  // 0605B276 extu.b r7,r7
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B278 mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B27A mov.l @(r0,r12),r1
    c.r[6] = c.r[6] & 0xFFu;  // 0605B27C extu.b r6,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B27E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B280 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B2CCu);  // 0605B282 mov.l 0x0605B2CC,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0605B288u; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B288u) return; }  // 0605B284 jsr @r9 ; mov.l r0,@-r15
    c.r[15] += 32;  // 0605B288 add #32,r15
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605B2BEu);  // 0605B28A mov.w 0x0605B2BE,r13
    c.r[0] = c.r[8];  // 0605B28C mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B28E mov.l @(r0,r13),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605B2BCu);  // 0605B290 mov.w 0x0605B2BC,r12
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B292 mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B294 mov.l @(r0,r12),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]); goto L_0605B2F0;  // 0605B296 bra 0x0605B2F0 ; mov.l r1,@-r15
L_0605B2F0:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B2F0 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B434u);  // 0605B2F2 mov.l 0x0605B434,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605B2F4 mov.l r0,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B420u);  // 0605B2F6 mov.w 0x0605B420,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0605B2F8 mov.l @(r0,r14),r7
    c.r[5] = 0x0u;  // 0605B2FA mov #0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B422u);  // 0605B2FC mov.w 0x0605B422,r0
    c.r[0] += c.r[14];  // 0605B2FE add r14,r0
    c.r[4] = ld32(0x0605B438u);  // 0605B300 mov.l 0x0605B438,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605B306u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B306u) return; }  // 0605B302 jsr @r9 ; mov.l @r0,r6
    c.r[0] = c.r[8];  // 0605B306 mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B308 mov.l @(r0,r13),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B30A mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B30C mov.l @(r0,r12),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B30E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B310 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B434u);  // 0605B312 mov.l 0x0605B434,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605B314 mov.l r0,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B420u);  // 0605B316 mov.w 0x0605B420,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0605B318 mov.l @(r0,r14),r7
    c.r[5] = 0x1u;  // 0605B31A mov #1,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B422u);  // 0605B31C mov.w 0x0605B422,r0
    c.r[0] += c.r[14];  // 0605B31E add r14,r0
    c.r[4] = ld32(0x0605B438u);  // 0605B320 mov.l 0x0605B438,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605B326u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B326u) return; }  // 0605B322 jsr @r9 ; mov.l @r0,r6
    c.r[0] = c.r[8];  // 0605B326 mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B328 mov.l @(r0,r13),r1
    c.r[15] += 32;  // 0605B32A add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B32C mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B32E mov.l @(r0,r12),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B330 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B332 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B434u);  // 0605B334 mov.l 0x0605B434,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605B336 mov.l r0,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B420u);  // 0605B338 mov.w 0x0605B420,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0605B33A mov.l @(r0,r14),r7
    c.r[5] = 0x2u;  // 0605B33C mov #2,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B422u);  // 0605B33E mov.w 0x0605B422,r0
    c.r[0] += c.r[14];  // 0605B340 add r14,r0
    c.r[4] = ld32(0x0605B438u);  // 0605B342 mov.l 0x0605B438,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605B348u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B348u) return; }  // 0605B344 jsr @r9 ; mov.l @r0,r6
    c.r[0] = c.r[8];  // 0605B348 mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0605B34A mov.l @(r0,r13),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B34C mov.l r1,@-r15
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0605B34E mov.l @(r0,r12),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B350 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B352 mov.l r14,@-r15
    c.r[0] = ld32(0x0605B434u);  // 0605B354 mov.l 0x0605B434,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605B356 mov.l r0,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B420u);  // 0605B358 mov.w 0x0605B420,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0605B35A mov.l @(r0,r14),r7
    c.r[5] = 0x3u;  // 0605B35C mov #3,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B422u);  // 0605B35E mov.w 0x0605B422,r0
    c.r[0] += c.r[14];  // 0605B360 add r14,r0
    c.r[4] = ld32(0x0605B438u);  // 0605B362 mov.l 0x0605B438,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605B368u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B368u) return; }  // 0605B364 jsr @r9 ; mov.l @r0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605B368 mov.b @r10,r1
    c.r[1] -= 1;  // 0605B36A add #-1,r1
    st8(c.r[10], c.r[1]);  // 0605B36C mov.b r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0605B36E mov.b @r11,r1
    c.r[15] += 32;  // 0605B370 add #32,r15
    c.r[1] -= 1;  // 0605B372 add #-1,r1
    st8(c.r[11], c.r[1]);  // 0605B374 mov.b r1,@r11
    c.r[1] = ld32(0x0605B43Cu);  // 0605B376 mov.l 0x0605B43C,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B378 mov.b @r1,r5
    c.r[4] = 0x0u;  // 0605B37A mov #0,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605B37C extu.b r5,r5
    c.r[5] >>= 2;  // 0605B37E shlr2 r5
    c.r[1] = ld32(0x0605B440u);  // 0605B380 mov.l 0x0605B440,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605B386u; c.r[5] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B386u) return; }  // 0605B382 jsr @r1 ; shlr2 r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B424u);  // 0605B386 mov.w 0x0605B424,r1
    c.r[0] = c.r[8];  // 0605B388 mov r8,r0
    c.r[3] = 0x0u;  // 0605B38A mov #0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605B38C mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605B426u);  // 0605B38E mov.w 0x0605B426,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605B390 extu.b r1,r1
    c.r[1] <<= 8;  // 0605B392 shll8 r1
    c.r[1] <<= 2;  // 0605B394 shll2 r1
    c.r[1] <<= 2;  // 0605B396 shll2 r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605B398 extu.w r1,r1
    c.r[0] = ld32(0x0605B444u);  // 0605B39A mov.l 0x0605B444,r0
L_0605B39C:
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605B39C mov.w r1,@(r0,r3)
    c.r[3] += 2;  // 0605B39E add #2,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0605B3A0 cmp/gt r2,r3
    if (!c.t) { SH2_POLL(c); goto L_0605B39C; }  // 0605B3A2 bf 0x0605B39C
    c.r[7] = 0x20u;  // 0605B3A4 mov #32,r7
    c.r[8] = ld32(0x0605B448u);  // 0605B3A6 mov.l 0x0605B448,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B428u);  // 0605B3A8 mov.w 0x0605B428,r0
    c.r[5] = ld32(c.r[0] + c.r[8]);  // 0605B3AA mov.l @(r0,r8),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B42Au);  // 0605B3AC mov.w 0x0605B42A,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0605B3AE mov.w @(r0,r8),r1
    c.r[4] = ld32(0x0605B444u);  // 0605B3B0 mov.l 0x0605B444,r4
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605B3B2 extu.w r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B3B4 mov.l r1,@-r15
    c.r[1] = ld32(0x0605B44Cu);  // 0605B3B6 mov.l 0x0605B44C,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605B3B8 mov.l r1,@-r15
    c.r[1] = ld32(0x0605B450u);  // 0605B3BA mov.l 0x0605B450,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605B3C0u; c.r[6] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B3C0u) return; }  // 0605B3BC jsr @r1 ; mov #32,r6
    c.r[10] = 0x0u;  // 0605B3C0 mov #0,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B42Cu);  // 0605B3C2 mov.w 0x0605B42C,r0
    c.r[15] += 8;  // 0605B3C4 add #8,r15
    c.r[7] = 0xFu;  // 0605B3C6 mov #15,r7
    c.r[2] = ld32(0x0605B454u);  // 0605B3C8 mov.l 0x0605B454,r2
    c.r[6] = 0x0u;  // 0605B3CA mov #0,r6
    c.r[3] = ld32(c.r[0] + c.r[8]);  // 0605B3CC mov.l @(r0,r8),r3
L_0605B3CE:
    c.r[0] = c.r[6];  // 0605B3CE mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0605B3D0 mov.w @(r0,r2),r1
    c.r[6] += 2;  // 0605B3D2 add #2,r6
    c.r[10] += 1;  // 0605B3D4 add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[7];  // 0605B3D6 cmp/gt r7,r10
    st16(c.r[3], c.r[1]);  // 0605B3D8 mov.w r1,@r3
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0605B3CE; } }  // 0605B3DA bf/s 0x0605B3CE ; add #2,r3
    c.r[1] = ld32(0x0605B458u);  // 0605B3DE mov.l 0x0605B458,r1
    c.r[1] = ld32(c.r[1]);  // 0605B3E0 mov.l @r1,r1
    c.r[1] += 8;  // 0605B3E2 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B3E4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605B3E6 mov r1,r0
    c.r[0] >>= 2;  // 0605B3E8 shlr2 r0
    c.r[0] &= 0x1u;  // 0605B3EA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605B3EC tst r0,r0
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_0605B400; } }  // 0605B3EE bt/s 0x0605B400 ; mov #2,r4
    c.r[1] = ld32(0x0605B43Cu);  // 0605B3F2 mov.l 0x0605B43C,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B3F4 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0605B3F6 extu.b r5,r5
    c.r[5] >>= 2;  // 0605B3F8 shlr2 r5
    c.r[1] = ld32(0x0605B440u);  // 0605B3FA mov.l 0x0605B440,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605B400u; c.r[5] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B400u) return; }  // 0605B3FC jsr @r1 ; shlr2 r5
L_0605B400:
    c.r[1] = ld32(0x0605B45Cu);  // 0605B400 mov.l 0x0605B45C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605B406u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B406u) return; }  // 0605B402 jsr @r1 ; mov #1,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B42Eu);  // 0605B406 mov.w 0x0605B42E,r3
    c.r[14] += c.r[3];  // 0605B408 add r3,r14
    c.r[15] = c.r[14];  // 0605B40A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605B40C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605B40E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605B410 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605B412 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605B414 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605B416 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605B418 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B430u);  // 0605B41A mov.w 0x0605B430,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605B41C rts ; mov.l @r15+,r8
}

void f_0605B460(SH2Context& c) {
    ran[1384] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B460 mov.l r14,@-r15
    c.r[1] = ld32(0x0605B4B4u);  // 0605B462 mov.l 0x0605B4B4,r1
    c.r[2] = ld32(c.r[1]);  // 0605B464 mov.l @r1,r2
    c.r[2] += 1;  // 0605B466 add #1,r2
    st32(c.r[1], c.r[2]);  // 0605B468 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605B46A mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605B46C extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605B46E tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605B47E; } }  // 0605B470 bf/s 0x0605B47E ; mov r15,r14
    c.r[1] = ld32(0x0605B4B8u);  // 0605B474 mov.l 0x0605B4B8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B476 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 0605B478 and #239,r0
    st8(c.r[1], c.r[0]); goto L_0605B4A6;  // 0605B47A bra 0x0605B4A6 ; mov.b r0,@r1
L_0605B47E:
    c.t = c.r[0] == 0x1u;  // 0605B47E cmp/eq #1,r0
    if (!c.t) { goto L_0605B48C; }  // 0605B480 bf 0x0605B48C
    c.r[1] = ld32(0x0605B4B8u);  // 0605B482 mov.l 0x0605B4B8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B484 mov.b @r1,r0
    c.r[0] |= 0x10u;  // 0605B486 or #16,r0
    st8(c.r[1], c.r[0]); goto L_0605B4A6;  // 0605B488 bra 0x0605B4A6 ; mov.b r0,@r1
L_0605B48C:
    c.r[1] = ld32(0x0605B4B8u);  // 0605B48C mov.l 0x0605B4B8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B48E mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B4AEu);  // 0605B490 mov.w 0x0605B4AE,r3
    c.r[0] = c.r[2];  // 0605B492 mov r2,r0
    c.r[0] >>= 2;  // 0605B494 shlr2 r0
    c.r[0] >>= 2;  // 0605B496 shlr2 r0
    c.r[0] &= 0x1u;  // 0605B498 and #1,r0
    c.r[0] ^= 0x1u;  // 0605B49A xor #1,r0
    c.r[0] <<= 2;  // 0605B49C shll2 r0
    c.r[0] <<= 2;  // 0605B49E shll2 r0
    c.r[2] &= c.r[3];  // 0605B4A0 and r3,r2
    c.r[2] |= c.r[0];  // 0605B4A2 or r0,r2
    st8(c.r[1], c.r[2]);  // 0605B4A4 mov.b r2,@r1
L_0605B4A6:
    c.r[15] = c.r[14];  // 0605B4A6 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B4B0u);  // 0605B4A8 mov.w 0x0605B4B0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605B4AA rts ; mov.l @r15+,r14
}

void f_0605B4BC(SH2Context& c) {
    ran[1385] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B4BC mov.l r14,@-r15
    c.r[1] = ld32(0x0605B510u);  // 0605B4BE mov.l 0x0605B510,r1
    c.r[2] = ld32(c.r[1]);  // 0605B4C0 mov.l @r1,r2
    c.r[2] += 1;  // 0605B4C2 add #1,r2
    st32(c.r[1], c.r[2]);  // 0605B4C4 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605B4C6 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605B4C8 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605B4CA tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605B4DA; } }  // 0605B4CC bf/s 0x0605B4DA ; mov r15,r14
    c.r[1] = ld32(0x0605B514u);  // 0605B4D0 mov.l 0x0605B514,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B4D2 mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0605B4D4 and #247,r0
    st8(c.r[1], c.r[0]); goto L_0605B502;  // 0605B4D6 bra 0x0605B502 ; mov.b r0,@r1
L_0605B4DA:
    c.t = c.r[0] == 0x1u;  // 0605B4DA cmp/eq #1,r0
    if (!c.t) { goto L_0605B4E8; }  // 0605B4DC bf 0x0605B4E8
    c.r[1] = ld32(0x0605B514u);  // 0605B4DE mov.l 0x0605B514,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B4E0 mov.b @r1,r0
    c.r[0] |= 0x8u;  // 0605B4E2 or #8,r0
    st8(c.r[1], c.r[0]); goto L_0605B502;  // 0605B4E4 bra 0x0605B502 ; mov.b r0,@r1
L_0605B4E8:
    c.r[1] = ld32(0x0605B514u);  // 0605B4E8 mov.l 0x0605B514,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B4EA mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B50Au);  // 0605B4EC mov.w 0x0605B50A,r3
    c.r[0] = c.r[2];  // 0605B4EE mov r2,r0
    c.r[0] >>= 2;  // 0605B4F0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605B4F2 shlr r0
    c.r[0] &= 0x1u;  // 0605B4F4 and #1,r0
    c.r[0] ^= 0x1u;  // 0605B4F6 xor #1,r0
    c.r[0] <<= 2;  // 0605B4F8 shll2 r0
    c.r[0] += c.r[0];  // 0605B4FA add r0,r0
    c.r[2] &= c.r[3];  // 0605B4FC and r3,r2
    c.r[2] |= c.r[0];  // 0605B4FE or r0,r2
    st8(c.r[1], c.r[2]);  // 0605B500 mov.b r2,@r1
L_0605B502:
    c.r[15] = c.r[14];  // 0605B502 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B50Cu);  // 0605B504 mov.w 0x0605B50C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605B506 rts ; mov.l @r15+,r14
}

void f_0605B518(SH2Context& c) {
    ran[1386] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605B518 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605B51A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B51C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605B51E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605B520 mov r15,r14
    c.r[8] = ld32(0x0605B760u);  // 0605B522 mov.l 0x0605B760,r8
    c.r[2] = c.r[8];  // 0605B524 mov r8,r2
    c.r[2] += 56;  // 0605B526 add #56,r2
    c.r[1] = 0x0u;  // 0605B528 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0605B52A mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B71Cu);  // 0605B52C mov.w 0x0605B71C,r0
    c.r[9] = ld32(0x0605B764u);  // 0605B52E mov.l 0x0605B764,r9
    c.r[4] = ld32(0x0605B768u);  // 0605B530 mov.l 0x0605B768,r4
    c.r[1] = ld32(c.r[9]);  // 0605B532 mov.l @r9,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B534 mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 4);  // 0605B536 mov.l @(4,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B71Eu);  // 0605B538 mov.w 0x0605B71E,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B53A mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 8);  // 0605B53C mov.l @(8,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B720u);  // 0605B53E mov.w 0x0605B720,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B540 mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 12);  // 0605B542 mov.l @(12,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B722u);  // 0605B544 mov.w 0x0605B722,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B546 mov.l r1,@(r0,r8)
    c.r[0] = ld32(0x0605B76Cu);  // 0605B548 mov.l 0x0605B76C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605B54Eu; c.r[5] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B54Eu) return; }  // 0605B54A jsr @r0 ; mov #36,r5
    c.r[1] = c.r[0];  // 0605B54E mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B724u);  // 0605B550 mov.w 0x0605B724,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B552 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B726u);  // 0605B554 mov.w 0x0605B726,r0
    c.r[1] = ld32(0x0605B770u);  // 0605B556 mov.l 0x0605B770,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B558 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B728u);  // 0605B55A mov.w 0x0605B728,r0
    c.r[1] = ld32(0x0605B774u);  // 0605B55C mov.l 0x0605B774,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B55E mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B72Au);  // 0605B560 mov.w 0x0605B72A,r0
    c.r[1] = c.r[9];  // 0605B562 mov r9,r1
    c.r[1] += 88;  // 0605B564 add #88,r1
    c.r[9] += 90;  // 0605B566 add #90,r9
    c.r[2] = c.r[8];  // 0605B568 mov r8,r2
    c.r[6] = 0x0u;  // 0605B56A mov #0,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605B72Cu);  // 0605B56C mov.w 0x0605B72C,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605B72Eu);  // 0605B56E mov.w 0x0605B72E,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605B570 mov.w @r1,r1
    c.r[7] = 0x0u;  // 0605B572 mov #0,r7
    st16(c.r[0] + c.r[8], c.r[1]);  // 0605B574 mov.w r1,@(r0,r8)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605B576 mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B730u);  // 0605B578 mov.w 0x0605B730,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0605B57A extu.b r1,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 0605B57C mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B732u);  // 0605B57E mov.w 0x0605B732,r0
    c.r[2] += c.r[0];  // 0605B580 add r0,r2
    c.r[1] = 0x20u;  // 0605B582 mov #32,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 0605B584 mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B734u);  // 0605B586 mov.w 0x0605B734,r0
    c.r[2] += 1;  // 0605B588 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605B58A mov.b @r2,r1
    c.r[9] = 0x3u;  // 0605B58C mov #3,r9
    c.r[1] += 3;  // 0605B58E add #3,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0605B590 mov.b r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B736u);  // 0605B592 mov.w 0x0605B736,r0
    c.r[1] = ld32(0x0605B778u);  // 0605B594 mov.l 0x0605B778,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0605B596 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B738u);  // 0605B598 mov.w 0x0605B738,r0
    c.r[1] = 0x33u;  // 0605B59A mov #51,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0605B59C mov.b r1,@(r0,r8)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B73Au);  // 0605B59E mov.w 0x0605B73A,r3
L_0605B5A0:
    c.r[1] = c.r[8];  // 0605B5A0 mov r8,r1
    c.r[1] += 64;  // 0605B5A2 add #64,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B5A4 mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 0605B5A6 mov #127,r0
    c.r[6] += 1;  // 0605B5A8 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[9];  // 0605B5AA cmp/gt r9,r6
    c.r[2] &= c.r[0];  // 0605B5AC and r0,r2
    st8(c.r[1], c.r[2]);  // 0605B5AE mov.b r2,@r1
    c.r[2] = c.r[8];  // 0605B5B0 mov r8,r2
    c.r[2] += 65;  // 0605B5B2 add #65,r2
    c.r[1] = 0x28u;  // 0605B5B4 mov #40,r1
    st8(c.r[2], c.r[1]);  // 0605B5B6 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0605B5B8 mov r8,r2
    c.r[2] += 66;  // 0605B5BA add #66,r2
    c.r[1] = 0x1Cu;  // 0605B5BC mov #28,r1
    st8(c.r[2], c.r[1]);  // 0605B5BE mov.b r1,@r2
    c.r[1] = c.r[8];  // 0605B5C0 mov r8,r1
    c.r[1] += 67;  // 0605B5C2 add #67,r1
    st8(c.r[1], c.r[7]);  // 0605B5C4 mov.b r7,@r1
    c.r[1] = c.r[8];  // 0605B5C6 mov r8,r1
    c.r[1] += 68;  // 0605B5C8 add #68,r1
    st8(c.r[1], c.r[7]);  // 0605B5CA mov.b r7,@r1
    c.r[1] = c.r[8];  // 0605B5CC mov r8,r1
    c.r[1] += 70;  // 0605B5CE add #70,r1
    st16(c.r[1], c.r[5]);  // 0605B5D0 mov.w r5,@r1
    c.r[1] = c.r[8];  // 0605B5D2 mov r8,r1
    c.r[1] += 72;  // 0605B5D4 add #72,r1
    st16(c.r[1], c.r[5]);  // 0605B5D6 mov.w r5,@r1
    c.r[0] = c.r[8];  // 0605B5D8 mov r8,r0
    st16(c.r[0] + c.r[4], c.r[7]);  // 0605B5DA mov.w r7,@(r0,r4)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B73Cu);  // 0605B5DC mov.w 0x0605B73C,r1
    st16(c.r[0] + c.r[1], c.r[7]);  // 0605B5DE mov.w r7,@(r0,r1)
    { const bool k = !c.t; c.r[8] += c.r[3]; if (k) { SH2_POLL(c); goto L_0605B5A0; } }  // 0605B5E0 bf/s 0x0605B5A0 ; add r3,r8
    c.r[2] = ld32(0x0605B760u);  // 0605B5E4 mov.l 0x0605B760,r2
    c.r[1] = c.r[2];  // 0605B5E6 mov r2,r1
    c.r[1] += 64;  // 0605B5E8 add #64,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B5EA mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B73Eu);  // 0605B5EC mov.w 0x0605B73E,r0
    c.r[3] &= c.r[0];  // 0605B5EE and r0,r3
    c.r[0] = 0x44u;  // 0605B5F0 mov #68,r0
    c.r[3] |= c.r[0];  // 0605B5F2 or r0,r3
    st8(c.r[1], c.r[3]);  // 0605B5F4 mov.b r3,@r1
    c.r[1] = c.r[2];  // 0605B5F6 mov r2,r1
    c.r[1] += 74;  // 0605B5F8 add #74,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B740u);  // 0605B5FA mov.w 0x0605B740,r3
    st16(c.r[1], c.r[3]);  // 0605B5FC mov.w r3,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B72Au);  // 0605B5FE mov.w 0x0605B72A,r1
    c.r[0] = c.r[2];  // 0605B600 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605B602 mov.w @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605B742u);  // 0605B604 mov.w 0x0605B742,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 0605B606 mov.w r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B730u);  // 0605B608 mov.w 0x0605B730,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605B60A mov.w @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605B744u);  // 0605B60C mov.w 0x0605B744,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 0605B60E mov.w r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605B746u);  // 0605B610 mov.w 0x0605B746,r7
    c.r[1] = ld32(0x0605B77Cu);  // 0605B612 mov.l 0x0605B77C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0605B614 mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B748u);  // 0605B616 mov.w 0x0605B748,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605B618 mov.b @(r0,r1),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B74Au);  // 0605B61A mov.w 0x0605B74A,r0
    c.r[7] &= c.r[0];  // 0605B61C and r0,r7
    c.r[0] = 0x28u;  // 0605B61E mov #40,r0
    c.r[7] |= c.r[0];  // 0605B620 or r0,r7
    c.r[0] = c.r[2];  // 0605B622 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0605B624 mov.b r7,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605B74Cu);  // 0605B626 mov.w 0x0605B74C,r1
    st16(c.r[0] + c.r[1], c.r[3]);  // 0605B628 mov.w r3,@(r0,r1)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B74Eu);  // 0605B62A mov.w 0x0605B74E,r3
    c.r[1] = 0x0u;  // 0605B62C mov #0,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605B62E mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B750u);  // 0605B630 mov.w 0x0605B750,r3
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605B632 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B752u);  // 0605B634 mov.w 0x0605B752,r3
    c.r[1] = ld32(0x0605B780u);  // 0605B636 mov.l 0x0605B780,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B638 mov.l r1,@(r0,r3)
    c.r[2] = ld32(0x0605B784u);  // 0605B63A mov.l 0x0605B784,r2
    c.r[1] = ld32(0x0605B788u);  // 0605B63C mov.l 0x0605B788,r1
    st32(c.r[2], c.r[1]);  // 0605B63E mov.l r1,@r2
    c.r[1] = ld32(0x0605B78Cu);  // 0605B640 mov.l 0x0605B78C,r1
    st32(c.r[2] + 4, c.r[1]);  // 0605B642 mov.l r1,@(4,r2)
    c.r[1] = ld32(0x0605B790u);  // 0605B644 mov.l 0x0605B790,r1
    st32(c.r[2] + 8, c.r[1]);  // 0605B646 mov.l r1,@(8,r2)
    c.r[1] = ld32(0x0605B794u);  // 0605B648 mov.l 0x0605B794,r1
    st32(c.r[2] + 12, c.r[1]);  // 0605B64A mov.l r1,@(12,r2)
    c.r[1] = ld32(0x0605B798u);  // 0605B64C mov.l 0x0605B798,r1
    st32(c.r[2] + 16, c.r[1]);  // 0605B64E mov.l r1,@(16,r2)
    c.r[1] = ld32(0x0605B79Cu);  // 0605B650 mov.l 0x0605B79C,r1
    st32(c.r[2] + 20, c.r[1]);  // 0605B652 mov.l r1,@(20,r2)
    c.r[1] = ld32(0x0605B7A0u);  // 0605B654 mov.l 0x0605B7A0,r1
    st32(c.r[2] + 24, c.r[1]);  // 0605B656 mov.l r1,@(24,r2)
    c.r[1] = ld32(0x0605B7A4u);  // 0605B658 mov.l 0x0605B7A4,r1
    st32(c.r[2] + 28, c.r[1]);  // 0605B65A mov.l r1,@(28,r2)
    c.r[1] = ld32(0x0605B7A8u);  // 0605B65C mov.l 0x0605B7A8,r1
    st32(c.r[2] + 32, c.r[1]);  // 0605B65E mov.l r1,@(32,r2)
    c.r[1] = ld32(0x0605B7ACu);  // 0605B660 mov.l 0x0605B7AC,r1
    st32(c.r[2] + 36, c.r[1]);  // 0605B662 mov.l r1,@(36,r2)
    c.r[1] = ld32(0x0605B7B0u);  // 0605B664 mov.l 0x0605B7B0,r1
    st32(c.r[2] + 40, c.r[1]);  // 0605B666 mov.l r1,@(40,r2)
    c.r[1] = ld32(0x0605B7B4u);  // 0605B668 mov.l 0x0605B7B4,r1
    st32(c.r[2] + 44, c.r[1]);  // 0605B66A mov.l r1,@(44,r2)
    c.r[1] = ld32(0x0605B7B8u);  // 0605B66C mov.l 0x0605B7B8,r1
    st32(c.r[2] + 48, c.r[1]);  // 0605B66E mov.l r1,@(48,r2)
    c.r[1] = ld32(0x0605B7BCu);  // 0605B670 mov.l 0x0605B7BC,r1
    st32(c.r[2] + 52, c.r[1]);  // 0605B672 mov.l r1,@(52,r2)
    c.r[1] = ld32(0x0605B7C0u);  // 0605B674 mov.l 0x0605B7C0,r1
    st32(c.r[2] + 56, c.r[1]);  // 0605B676 mov.l r1,@(56,r2)
    c.r[1] = ld32(0x0605B7C4u);  // 0605B678 mov.l 0x0605B7C4,r1
    st32(c.r[2] + 60, c.r[1]);  // 0605B67A mov.l r1,@(60,r2)
    c.r[3] = c.r[2];  // 0605B67C mov r2,r3
    c.r[3] += 64;  // 0605B67E add #64,r3
    c.r[1] = ld32(0x0605B7C8u);  // 0605B680 mov.l 0x0605B7C8,r1
    st32(c.r[3], c.r[1]);  // 0605B682 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B684 mov r2,r3
    c.r[3] += 68;  // 0605B686 add #68,r3
    c.r[1] = ld32(0x0605B7CCu);  // 0605B688 mov.l 0x0605B7CC,r1
    st32(c.r[3], c.r[1]);  // 0605B68A mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B68C mov r2,r3
    c.r[3] += 72;  // 0605B68E add #72,r3
    c.r[1] = ld32(0x0605B7D0u);  // 0605B690 mov.l 0x0605B7D0,r1
    st32(c.r[3], c.r[1]);  // 0605B692 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B694 mov r2,r3
    c.r[3] += 76;  // 0605B696 add #76,r3
    c.r[1] = ld32(0x0605B7D4u);  // 0605B698 mov.l 0x0605B7D4,r1
    st32(c.r[3], c.r[1]);  // 0605B69A mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B69C mov r2,r3
    c.r[3] += 80;  // 0605B69E add #80,r3
    c.r[1] = ld32(0x0605B7D8u);  // 0605B6A0 mov.l 0x0605B7D8,r1
    st32(c.r[3], c.r[1]);  // 0605B6A2 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6A4 mov r2,r3
    c.r[3] += 84;  // 0605B6A6 add #84,r3
    c.r[1] = ld32(0x0605B7DCu);  // 0605B6A8 mov.l 0x0605B7DC,r1
    st32(c.r[3], c.r[1]);  // 0605B6AA mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6AC mov r2,r3
    c.r[3] += 88;  // 0605B6AE add #88,r3
    c.r[1] = ld32(0x0605B7E0u);  // 0605B6B0 mov.l 0x0605B7E0,r1
    st32(c.r[3], c.r[1]);  // 0605B6B2 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6B4 mov r2,r3
    c.r[3] += 92;  // 0605B6B6 add #92,r3
    c.r[1] = ld32(0x0605B7E4u);  // 0605B6B8 mov.l 0x0605B7E4,r1
    st32(c.r[3], c.r[1]);  // 0605B6BA mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6BC mov r2,r3
    c.r[3] += 96;  // 0605B6BE add #96,r3
    c.r[1] = ld32(0x0605B7E8u);  // 0605B6C0 mov.l 0x0605B7E8,r1
    st32(c.r[3], c.r[1]);  // 0605B6C2 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6C4 mov r2,r3
    c.r[3] += 100;  // 0605B6C6 add #100,r3
    c.r[1] = ld32(0x0605B7ECu);  // 0605B6C8 mov.l 0x0605B7EC,r1
    st32(c.r[3], c.r[1]);  // 0605B6CA mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6CC mov r2,r3
    c.r[3] += 104;  // 0605B6CE add #104,r3
    c.r[1] = ld32(0x0605B7F0u);  // 0605B6D0 mov.l 0x0605B7F0,r1
    st32(c.r[3], c.r[1]);  // 0605B6D2 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6D4 mov r2,r3
    c.r[3] += 108;  // 0605B6D6 add #108,r3
    c.r[1] = ld32(0x0605B7F4u);  // 0605B6D8 mov.l 0x0605B7F4,r1
    st32(c.r[3], c.r[1]);  // 0605B6DA mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6DC mov r2,r3
    c.r[3] += 112;  // 0605B6DE add #112,r3
    c.r[1] = ld32(0x0605B7F8u);  // 0605B6E0 mov.l 0x0605B7F8,r1
    st32(c.r[3], c.r[1]);  // 0605B6E2 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6E4 mov r2,r3
    c.r[3] += 116;  // 0605B6E6 add #116,r3
    c.r[1] = ld32(0x0605B7FCu);  // 0605B6E8 mov.l 0x0605B7FC,r1
    st32(c.r[3], c.r[1]);  // 0605B6EA mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6EC mov r2,r3
    c.r[3] += 120;  // 0605B6EE add #120,r3
    c.r[1] = ld32(0x0605B800u);  // 0605B6F0 mov.l 0x0605B800,r1
    st32(c.r[3], c.r[1]);  // 0605B6F2 mov.l r1,@r3
    c.r[3] = c.r[2];  // 0605B6F4 mov r2,r3
    c.r[3] += 124;  // 0605B6F6 add #124,r3
    c.r[1] = ld32(0x0605B804u);  // 0605B6F8 mov.l 0x0605B804,r1
    st32(c.r[3], c.r[1]);  // 0605B6FA mov.l r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B754u);  // 0605B6FC mov.w 0x0605B754,r3
    c.r[1] = ld32(0x0605B808u);  // 0605B6FE mov.l 0x0605B808,r1
    c.r[0] = c.r[2];  // 0605B700 mov r2,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B702 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B756u);  // 0605B704 mov.w 0x0605B756,r3
    c.r[1] = ld32(0x0605B80Cu);  // 0605B706 mov.l 0x0605B80C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B708 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B758u);  // 0605B70A mov.w 0x0605B758,r3
    c.r[1] = ld32(0x0605B810u);  // 0605B70C mov.l 0x0605B810,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B70E mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B75Au);  // 0605B710 mov.w 0x0605B75A,r3
    c.r[1] = ld32(0x0605B814u);  // 0605B712 mov.l 0x0605B814,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B714 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B75Cu);  // 0605B716 mov.w 0x0605B75C,r3
    c.r[15] = c.r[14]; goto L_0605B818;  // 0605B718 bra 0x0605B818 ; mov r14,r15
L_0605B818:
    c.r[1] = ld32(0x0605B88Cu);  // 0605B818 mov.l 0x0605B88C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B81A mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B870u);  // 0605B81C mov.w 0x0605B870,r3
    c.r[1] = ld32(0x0605B890u);  // 0605B81E mov.l 0x0605B890,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B820 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B872u);  // 0605B822 mov.w 0x0605B872,r3
    c.r[1] = ld32(0x0605B894u);  // 0605B824 mov.l 0x0605B894,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B826 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B874u);  // 0605B828 mov.w 0x0605B874,r3
    c.r[1] = ld32(0x0605B898u);  // 0605B82A mov.l 0x0605B898,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B82C mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B876u);  // 0605B82E mov.w 0x0605B876,r3
    c.r[1] = ld32(0x0605B89Cu);  // 0605B830 mov.l 0x0605B89C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B832 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B878u);  // 0605B834 mov.w 0x0605B878,r3
    c.r[1] = ld32(0x0605B8A0u);  // 0605B836 mov.l 0x0605B8A0,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B838 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B87Au);  // 0605B83A mov.w 0x0605B87A,r3
    c.r[1] = ld32(0x0605B8A4u);  // 0605B83C mov.l 0x0605B8A4,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B83E mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B87Cu);  // 0605B840 mov.w 0x0605B87C,r3
    c.r[1] = ld32(0x0605B8A8u);  // 0605B842 mov.l 0x0605B8A8,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B844 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B87Eu);  // 0605B846 mov.w 0x0605B87E,r3
    c.r[1] = ld32(0x0605B8ACu);  // 0605B848 mov.l 0x0605B8AC,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B84A mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B880u);  // 0605B84C mov.w 0x0605B880,r3
    c.r[1] = ld32(0x0605B8B0u);  // 0605B84E mov.l 0x0605B8B0,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B850 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B882u);  // 0605B852 mov.w 0x0605B882,r3
    c.r[1] = ld32(0x0605B8B4u);  // 0605B854 mov.l 0x0605B8B4,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B856 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B884u);  // 0605B858 mov.w 0x0605B884,r3
    c.r[1] = ld32(0x0605B8B8u);  // 0605B85A mov.l 0x0605B8B8,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B85C mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B886u);  // 0605B85E mov.w 0x0605B886,r3
    c.r[1] = ld32(0x0605B8BCu);  // 0605B860 mov.l 0x0605B8BC,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0605B862 mov.l r1,@(r0,r3)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605B864 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605B866 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605B868 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B888u);  // 0605B86A mov.w 0x0605B888,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605B86C rts ; mov.l @r15+,r8
}

void f_0605B8C0(SH2Context& c) {
    ran[1387] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B8C0 mov.l r14,@-r15
    c.r[1] = ld32(0x0605B95Cu);  // 0605B8C2 mov.l 0x0605B95C,r1
    c.r[1] = ld32(c.r[1]);  // 0605B8C4 mov.l @r1,r1
    c.r[1] += 1;  // 0605B8C6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B8C8 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605B8CA extu.b r1,r2
    c.r[1] = 0x3u;  // 0605B8CC mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0605B8CE cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605B938; } }  // 0605B8D0 bt/s 0x0605B938 ; mov r15,r14
    c.r[1] = c.r[2];  // 0605B8D4 mov r2,r1
    c.r[1] += c.r[1];  // 0605B8D6 add r1,r1
    c.r[0] = 0x0605B8E4u;  // 0605B8D8 mova 0x0605B8E4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605B8DA mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0605B8DC add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0605B8ECu: goto L_0605B8EC; case 0x0605B8FAu: goto L_0605B8FA; case 0x0605B908u: goto L_0605B908; case 0x0605B924u: goto L_0605B924; default: sh2_call(c, x); return; } }  // 0605B8DE jmp @r0 ; nop
L_0605B8EC:
    c.r[1] = ld32(0x0605B960u);  // 0605B8EC mov.l 0x0605B960,r1
    c.r[1] = ld32(c.r[1]);  // 0605B8EE mov.l @r1,r1
    c.r[1] += 8;  // 0605B8F0 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B8F2 mov.b @r1,r0
    c.r[0] &= 0xFBu;  // 0605B8F4 and #251,r0
    st8(c.r[1], c.r[0]); goto L_0605B950;  // 0605B8F6 bra 0x0605B950 ; mov.b r0,@r1
L_0605B8FA:
    c.r[1] = ld32(0x0605B960u);  // 0605B8FA mov.l 0x0605B960,r1
    c.r[1] = ld32(c.r[1]);  // 0605B8FC mov.l @r1,r1
    c.r[1] += 8;  // 0605B8FE add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B900 mov.b @r1,r0
    c.r[0] |= 0x4u;  // 0605B902 or #4,r0
    st8(c.r[1], c.r[0]); goto L_0605B950;  // 0605B904 bra 0x0605B950 ; mov.b r0,@r1
L_0605B908:
    c.r[1] = ld32(0x0605B960u);  // 0605B908 mov.l 0x0605B960,r1
    c.r[1] = ld32(c.r[1]);  // 0605B90A mov.l @r1,r1
    c.r[1] += 8;  // 0605B90C add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B90E mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B958u);  // 0605B910 mov.w 0x0605B958,r3
    c.r[0] = c.r[2];  // 0605B912 mov r2,r0
    c.r[0] >>= 2;  // 0605B914 shlr2 r0
    c.r[0] &= 0x1u;  // 0605B916 and #1,r0
    c.r[0] ^= 0x1u;  // 0605B918 xor #1,r0
    c.r[0] <<= 2;  // 0605B91A shll2 r0
    c.r[2] &= c.r[3];  // 0605B91C and r3,r2
    c.r[2] |= c.r[0];  // 0605B91E or r0,r2
    st8(c.r[1], c.r[2]); goto L_0605B950;  // 0605B920 bra 0x0605B950 ; mov.b r2,@r1
L_0605B924:
    c.r[1] = ld32(0x0605B960u);  // 0605B924 mov.l 0x0605B960,r1
    c.r[1] = ld32(c.r[1]);  // 0605B926 mov.l @r1,r1
    c.r[1] += 8;  // 0605B928 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B92A mov.b @r1,r1
    c.r[2] = ld32(0x0605B964u);  // 0605B92C mov.l 0x0605B964,r2
    c.r[0] = c.r[1];  // 0605B92E mov r1,r0
    c.r[0] >>= 2;  // 0605B930 shlr2 r0
    c.r[0] &= 0x1u;  // 0605B932 and #1,r0
    st8(c.r[2], c.r[0]); goto L_0605B950;  // 0605B934 bra 0x0605B950 ; mov.b r0,@r2
L_0605B938:
    c.r[1] = ld32(0x0605B960u);  // 0605B938 mov.l 0x0605B960,r1
    c.r[2] = ld32(c.r[1]);  // 0605B93A mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605B958u);  // 0605B93C mov.w 0x0605B958,r3
    c.r[1] = ld32(0x0605B964u);  // 0605B93E mov.l 0x0605B964,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605B940 mov.b @r1,r0
    c.r[2] += 8;  // 0605B942 add #8,r2
    c.r[0] &= 0x1u;  // 0605B944 and #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605B946 mov.b @r2,r1
    c.r[0] <<= 2;  // 0605B948 shll2 r0
    c.r[1] &= c.r[3];  // 0605B94A and r3,r1
    c.r[1] |= c.r[0];  // 0605B94C or r0,r1
    st8(c.r[2], c.r[1]);  // 0605B94E mov.b r1,@r2
L_0605B950:
    c.r[15] = c.r[14];  // 0605B950 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B95Au);  // 0605B952 mov.w 0x0605B95A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605B954 rts ; mov.l @r15+,r14
}

void f_0605B968(SH2Context& c) {
    ran[1388] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B968 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605B96A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605B96C mov r15,r14
    c.r[1] = ld32(0x0605B9D0u);  // 0605B96E mov.l 0x0605B9D0,r1
    c.r[2] = ld32(c.r[1]);  // 0605B970 mov.l @r1,r2
    c.r[0] = 0x1u;  // 0605B972 mov #1,r0
    c.r[2] += 1;  // 0605B974 add #1,r2
    st32(c.r[1], c.r[2]);  // 0605B976 mov.l r2,@r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605B978 mov.b @r2,r3
    c.r[1] = 0x40u;  // 0605B97A mov #64,r1
    c.r[2] = c.r[3];  // 0605B97C mov r3,r2
    c.r[2] >>= 2;  // 0605B97E shlr2 r2
    c.r[2] >>= 2;  // 0605B980 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605B982 shlr r2
    c.r[2] >>= 2;  // 0605B984 shlr2 r2
    c.r[2] &= c.r[0];  // 0605B986 and r0,r2
    c.r[1] &= c.r[3];  // 0605B988 and r3,r1
    c.r[0] = 0xFu;  // 0605B98A mov #15,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605B98C tst r1,r1
    { const bool k = c.t; c.r[3] &= c.r[0]; if (k) { goto L_0605B9B8; } }  // 0605B98E bt/s 0x0605B9B8 ; and r0,r3
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605B992 tst r2,r2
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0605B9A8; } }  // 0605B994 bf/s 0x0605B9A8 ; mov r3,r2
    c.r[2] <<= 2;  // 0605B998 shll2 r2
    c.r[1] = ld32(0x0605B9D4u);  // 0605B99A mov.l 0x0605B9D4,r1
    c.r[0] = c.r[2];  // 0605B99C mov r2,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0605B99E mov.l @(r0,r1),r6
    c.r[5] = c.r[3] & 0xFFu;  // 0605B9A0 extu.b r3,r5
    c.r[1] = ld32(0x0605B9D8u);  // 0605B9A2 mov.l 0x0605B9D8,r1
    c.r[4] = 0x0u; goto L_0605B9C0;  // 0605B9A4 bra 0x0605B9C0 ; mov #0,r4
L_0605B9A8:
    c.r[2] <<= 2;  // 0605B9A8 shll2 r2
    c.r[1] = ld32(0x0605B9DCu);  // 0605B9AA mov.l 0x0605B9DC,r1
    c.r[0] = c.r[2];  // 0605B9AC mov r2,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0605B9AE mov.l @(r0,r1),r6
    c.r[5] = c.r[3] & 0xFFu;  // 0605B9B0 extu.b r3,r5
    c.r[1] = ld32(0x0605B9D8u);  // 0605B9B2 mov.l 0x0605B9D8,r1
    c.r[4] = 0x1u; goto L_0605B9C0;  // 0605B9B4 bra 0x0605B9C0 ; mov #1,r4
L_0605B9B8:
    c.r[5] = c.r[3] & 0xFFu;  // 0605B9B8 extu.b r3,r5
    c.r[4] = c.r[2] & 0xFFu;  // 0605B9BA extu.b r2,r4
    c.r[1] = ld32(0x0605B9D8u);  // 0605B9BC mov.l 0x0605B9D8,r1
    c.r[6] = 0x0u;  // 0605B9BE mov #0,r6
L_0605B9C0:
    { const uint32_t x = c.r[1]; c.pr = 0x0605B9C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605B9C4u) return; }  // 0605B9C0 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0605B9C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605B9C6 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605B9CEu);  // 0605B9C8 mov.w 0x0605B9CE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605B9CA rts ; mov.l @r15+,r14
}

void f_0605B9E0(SH2Context& c) {
    ran[1389] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605B9E0 mov.l r14,@-r15
    c.r[1] = ld32(0x0605BA5Cu);  // 0605B9E2 mov.l 0x0605BA5C,r1
    c.r[2] = ld32(c.r[1]);  // 0605B9E4 mov.l @r1,r2
    c.r[2] += 1;  // 0605B9E6 add #1,r2
    st32(c.r[1], c.r[2]);  // 0605B9E8 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605B9EA mov.b @r2,r1
    c.r[3] = 0x7Fu;  // 0605B9EC mov #127,r3
    c.r[0] = c.r[1] & 0xFFu;  // 0605B9EE extu.b r1,r0
    c.r[3] &= c.r[0];  // 0605B9F0 and r0,r3
    c.r[0] &= 0x80u;  // 0605B9F2 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605B9F4 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BA26; } }  // 0605B9F6 bt/s 0x0605BA26 ; mov r15,r14
    c.r[0] = 0x0u;  // 0605B9FA mov #0,r0
    c.r[6] = 0xFu;  // 0605B9FC mov #15,r6
    c.r[2] = ld32(0x0605BA60u);  // 0605B9FE mov.l 0x0605BA60,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605BA56u);  // 0605BA00 mov.w 0x0605BA56,r7
    c.r[1] = c.r[0];  // 0605BA02 mov r0,r1
L_0605BA04:
    c.r[1] += c.r[2];  // 0605BA04 add r2,r1
    c.r[1] += 2;  // 0605BA06 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BA08 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605BA0A extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0605BA0C cmp/eq r7,r1
    if (c.t) { goto L_0605BA18; }  // 0605BA0E bt 0x0605BA18
    c.r[0] += 1;  // 0605BA10 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[6];  // 0605BA12 cmp/gt r6,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0605BA04; } }  // 0605BA14 bf/s 0x0605BA04 ; mov r0,r1
L_0605BA18:
    c.t = c.r[0] == 0x10u;  // 0605BA18 cmp/eq #16,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0605BA50; } }  // 0605BA1A bt/s 0x0605BA50 ; mov r14,r15
    c.r[0] += c.r[2];  // 0605BA1E add r2,r0
    c.r[0] += 2;  // 0605BA20 add #2,r0
    st8(c.r[0], c.r[3]); goto L_0605BA50;  // 0605BA22 bra 0x0605BA50 ; mov.b r3,@r0
L_0605BA26:
    c.r[0] = 0x0u;  // 0605BA26 mov #0,r0
    c.r[7] = 0xFu;  // 0605BA28 mov #15,r7
    c.r[2] = ld32(0x0605BA60u);  // 0605BA2A mov.l 0x0605BA60,r2
    c.r[1] = c.r[0];  // 0605BA2C mov r0,r1
L_0605BA2E:
    c.r[1] += c.r[2];  // 0605BA2E add r2,r1
    c.r[1] += 2;  // 0605BA30 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BA32 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605BA34 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 0605BA36 cmp/eq r3,r1
    if (c.t) { goto L_0605BA42; }  // 0605BA38 bt 0x0605BA42
    c.r[0] += 1;  // 0605BA3A add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[7];  // 0605BA3C cmp/gt r7,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0605BA2E; } }  // 0605BA3E bf/s 0x0605BA2E ; mov r0,r1
L_0605BA42:
    c.t = c.r[0] == 0x10u;  // 0605BA42 cmp/eq #16,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0605BA50; } }  // 0605BA44 bt/s 0x0605BA50 ; mov r14,r15
    c.r[0] += c.r[2];  // 0605BA48 add r2,r0
    c.r[0] += 2;  // 0605BA4A add #2,r0
    c.r[1] = 0xFFFFFFFFu;  // 0605BA4C mov #-1,r1
    st8(c.r[0], c.r[1]);  // 0605BA4E mov.b r1,@r0
L_0605BA50:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BA58u);  // 0605BA50 mov.w 0x0605BA58,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BA52 rts ; mov.l @r15+,r14
}

void f_0605BA64(SH2Context& c) {
    ran[1390] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BA64 mov.l r14,@-r15
    c.r[1] = ld32(0x0605BAE0u);  // 0605BA66 mov.l 0x0605BAE0,r1
    c.r[2] = ld32(c.r[1]);  // 0605BA68 mov.l @r1,r2
    c.r[2] += 1;  // 0605BA6A add #1,r2
    st32(c.r[1], c.r[2]);  // 0605BA6C mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BA6E mov.b @r2,r1
    c.r[3] = 0x7Fu;  // 0605BA70 mov #127,r3
    c.r[0] = c.r[1] & 0xFFu;  // 0605BA72 extu.b r1,r0
    c.r[3] &= c.r[0];  // 0605BA74 and r0,r3
    c.r[0] &= 0x80u;  // 0605BA76 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605BA78 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BAAA; } }  // 0605BA7A bt/s 0x0605BAAA ; mov r15,r14
    c.r[0] = 0x0u;  // 0605BA7E mov #0,r0
    c.r[6] = 0xFu;  // 0605BA80 mov #15,r6
    c.r[2] = ld32(0x0605BAE4u);  // 0605BA82 mov.l 0x0605BAE4,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605BADAu);  // 0605BA84 mov.w 0x0605BADA,r7
    c.r[1] = c.r[0];  // 0605BA86 mov r0,r1
L_0605BA88:
    c.r[1] += c.r[2];  // 0605BA88 add r2,r1
    c.r[1] += 18;  // 0605BA8A add #18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BA8C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605BA8E extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0605BA90 cmp/eq r7,r1
    if (c.t) { goto L_0605BA9C; }  // 0605BA92 bt 0x0605BA9C
    c.r[0] += 1;  // 0605BA94 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[6];  // 0605BA96 cmp/gt r6,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0605BA88; } }  // 0605BA98 bf/s 0x0605BA88 ; mov r0,r1
L_0605BA9C:
    c.t = c.r[0] == 0x10u;  // 0605BA9C cmp/eq #16,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0605BAD4; } }  // 0605BA9E bt/s 0x0605BAD4 ; mov r14,r15
    c.r[0] += c.r[2];  // 0605BAA2 add r2,r0
    c.r[0] += 18;  // 0605BAA4 add #18,r0
    st8(c.r[0], c.r[3]); goto L_0605BAD4;  // 0605BAA6 bra 0x0605BAD4 ; mov.b r3,@r0
L_0605BAAA:
    c.r[0] = 0x0u;  // 0605BAAA mov #0,r0
    c.r[7] = 0xFu;  // 0605BAAC mov #15,r7
    c.r[2] = ld32(0x0605BAE4u);  // 0605BAAE mov.l 0x0605BAE4,r2
    c.r[1] = c.r[0];  // 0605BAB0 mov r0,r1
L_0605BAB2:
    c.r[1] += c.r[2];  // 0605BAB2 add r2,r1
    c.r[1] += 18;  // 0605BAB4 add #18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BAB6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605BAB8 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 0605BABA cmp/eq r3,r1
    if (c.t) { goto L_0605BAC6; }  // 0605BABC bt 0x0605BAC6
    c.r[0] += 1;  // 0605BABE add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[7];  // 0605BAC0 cmp/gt r7,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0605BAB2; } }  // 0605BAC2 bf/s 0x0605BAB2 ; mov r0,r1
L_0605BAC6:
    c.t = c.r[0] == 0x10u;  // 0605BAC6 cmp/eq #16,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0605BAD4; } }  // 0605BAC8 bt/s 0x0605BAD4 ; mov r14,r15
    c.r[0] += c.r[2];  // 0605BACC add r2,r0
    c.r[0] += 18;  // 0605BACE add #18,r0
    c.r[1] = 0xFFFFFFFFu;  // 0605BAD0 mov #-1,r1
    st8(c.r[0], c.r[1]);  // 0605BAD2 mov.b r1,@r0
L_0605BAD4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BADCu);  // 0605BAD4 mov.w 0x0605BADC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BAD6 rts ; mov.l @r15+,r14
}

void f_0605BAE8(SH2Context& c) {
    ran[1391] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BAE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605BAEA sts.l pr,@-r15
    c.r[1] = ld32(0x0605BB60u);  // 0605BAEC mov.l 0x0605BB60,r1
    c.r[1] = ld32(c.r[1]);  // 0605BAEE mov.l @r1,r1
    c.r[1] += 1;  // 0605BAF0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BAF2 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BAF4 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605BAF6 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BB06; } }  // 0605BAF8 bf/s 0x0605BB06 ; mov r15,r14
    c.r[1] = ld32(0x0605BB64u);  // 0605BAFC mov.l 0x0605BB64,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BAFE mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0605BB00 and #127,r0
    st8(c.r[1], c.r[0]); goto L_0605BB34;  // 0605BB02 bra 0x0605BB34 ; mov.b r0,@r1
L_0605BB06:
    c.t = c.r[0] == 0x1u;  // 0605BB06 cmp/eq #1,r0
    if (!c.t) { goto L_0605BB14; }  // 0605BB08 bf 0x0605BB14
    c.r[1] = ld32(0x0605BB64u);  // 0605BB0A mov.l 0x0605BB64,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BB0C mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0605BB0E or #128,r0
    st8(c.r[1], c.r[0]); goto L_0605BB34;  // 0605BB10 bra 0x0605BB34 ; mov.b r0,@r1
L_0605BB14:
    c.r[2] = ld32(0x0605BB64u);  // 0605BB14 mov.l 0x0605BB64,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BB16 mov.b @r2,r0
    c.r[1] = c.r[0] & 0xFFu;  // 0605BB18 extu.b r0,r1
    c.r[1] >>= 2;  // 0605BB1A shlr2 r1
    c.r[1] >>= 2;  // 0605BB1C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605BB1E shlr r1
    c.r[1] >>= 2;  // 0605BB20 shlr2 r1
    c.r[1] += 1;  // 0605BB22 add #1,r1
    c.r[1] <<= 2;  // 0605BB24 shll2 r1
    c.r[1] <<= 2;  // 0605BB26 shll2 r1
    c.r[1] += c.r[1];  // 0605BB28 add r1,r1
    c.r[1] <<= 2;  // 0605BB2A shll2 r1
    c.r[0] &= 0x7Fu;  // 0605BB2C and #127,r0
    c.r[0] |= c.r[1];  // 0605BB2E or r1,r0
    st8(c.r[2], c.r[0]);  // 0605BB30 mov.b r0,@r2
    c.r[1] = ld32(0x0605BB64u);  // 0605BB32 mov.l 0x0605BB64,r1
L_0605BB34:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BB34 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605BB36 extu.b r1,r1
    c.r[1] >>= 2;  // 0605BB38 shlr2 r1
    c.r[1] >>= 2;  // 0605BB3A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605BB3C shlr r1
    c.r[1] >>= 2;  // 0605BB3E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605BB40 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x18u; if (k) { goto L_0605BB4C; } }  // 0605BB42 bt/s 0x0605BB4C ; mov #24,r4
    c.r[1] = ld32(0x0605BB68u);  // 0605BB46 mov.l 0x0605BB68,r1
    goto L_0605BB50;  // 0605BB48 bra 0x0605BB50 ; nop
L_0605BB4C:
    c.r[4] = ld32(0x0605BB6Cu);  // 0605BB4C mov.l 0x0605BB6C,r4
    c.r[1] = ld32(0x0605BB68u);  // 0605BB4E mov.l 0x0605BB68,r1
L_0605BB50:
    { const uint32_t x = c.r[1]; c.pr = 0x0605BB54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BB54u) return; }  // 0605BB50 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0605BB54 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605BB56 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BB5Eu);  // 0605BB58 mov.w 0x0605BB5E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BB5A rts ; mov.l @r15+,r14
}

void f_0605BB70(SH2Context& c) {
    ran[1392] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605BB70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605BB72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605BB74 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605BB76 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605BB78 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605BB7A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BB7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605BB7E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605BB80 mov r15,r14
    c.r[8] = ld32(0x0605BC20u);  // 0605BB82 mov.l 0x0605BC20,r8
    c.r[1] = ld32(0x0605BC24u);  // 0605BB84 mov.l 0x0605BC24,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605BC14u);  // 0605BB86 mov.w 0x0605BC14,r13
    c.r[12] = ld32(0x0605BC28u);  // 0605BB88 mov.l 0x0605BC28,r12
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605BC16u);  // 0605BB8A mov.w 0x0605BC16,r11
    c.r[1] = ld32(c.r[1]);  // 0605BB8C mov.l @r1,r1
    c.r[9] = ld32(0x0605BC2Cu);  // 0605BB8E mov.l 0x0605BC2C,r9
    c.r[2] = ld32(c.r[8]);  // 0605BB90 mov.l @r8,r2
    c.r[1] += 1;  // 0605BB92 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BB94 mov.b @r1,r1
    c.r[0] = c.r[2];  // 0605BB96 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0605BB98 mov.b @(r0,r13),r3
    c.r[1] <<= 2;  // 0605BB9A shll2 r1
    c.r[1] <<= 2;  // 0605BB9C shll2 r1
    c.r[1] <<= 2;  // 0605BB9E shll2 r1
    c.r[0] = 0x3Fu;  // 0605BBA0 mov #63,r0
    c.r[3] &= c.r[0];  // 0605BBA2 and r0,r3
    c.r[3] |= c.r[1];  // 0605BBA4 or r1,r3
    c.r[0] = c.r[2];  // 0605BBA6 mov r2,r0
    st8(c.r[0] + c.r[13], c.r[3]);  // 0605BBA8 mov.b r3,@(r0,r13)
    c.r[1] = 0x1u;  // 0605BBAA mov #1,r1
    st8(c.r[12], c.r[1]);  // 0605BBAC mov.b r1,@r12
    c.r[1] = ld32(0x0605BC30u);  // 0605BBAE mov.l 0x0605BC30,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605BC18u);  // 0605BBB0 mov.w 0x0605BC18,r2
    c.r[0] = c.r[1];  // 0605BBB2 mov r1,r0
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0605BBB4 mov.l @(r0,r2),r5
    c.r[10] = ld32(0x0605BC34u);  // 0605BBB6 mov.l 0x0605BC34,r10
    c.r[1] = ld32(c.r[8]);  // 0605BBB8 mov.l @r8,r1
    c.r[7] = 0xEu;  // 0605BBBA mov #14,r7
    c.r[0] = c.r[1];  // 0605BBBC mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0605BBBE mov.b @(r0,r13),r4
    c.r[6] = c.r[11];  // 0605BBC0 mov r11,r6
    c.r[4] = c.r[4] & 0xFFu;  // 0605BBC2 extu.b r4,r4
    c.r[4] >>= 2;  // 0605BBC4 shlr2 r4
    c.r[4] >>= 2;  // 0605BBC6 shlr2 r4
    c.r[4] >>= 2;  // 0605BBC8 shlr2 r4
    c.r[4] <<= 8;  // 0605BBCA shll8 r4
    c.r[4] += c.r[4];  // 0605BBCC add r4,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605BBD2u; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BBD2u) return; }  // 0605BBCE jsr @r10 ; add r9,r4
    c.r[1] = ld32(0x0605BC38u);  // 0605BBD2 mov.l 0x0605BC38,r1
    c.r[5] = ld32(c.r[1]);  // 0605BBD4 mov.l @r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605BC1Au);  // 0605BBD6 mov.w 0x0605BC1A,r1
    c.r[5] += c.r[1];  // 0605BBD8 add r1,r5
    c.r[1] = ld32(c.r[8]);  // 0605BBDA mov.l @r8,r1
    c.r[7] = 0xEu;  // 0605BBDC mov #14,r7
    c.r[0] = c.r[1];  // 0605BBDE mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0605BBE0 mov.b @(r0,r13),r4
    c.r[6] = c.r[11];  // 0605BBE2 mov r11,r6
    c.r[4] = c.r[4] & 0xFFu;  // 0605BBE4 extu.b r4,r4
    c.r[4] >>= 2;  // 0605BBE6 shlr2 r4
    c.r[4] >>= 2;  // 0605BBE8 shlr2 r4
    c.r[4] >>= 2;  // 0605BBEA shlr2 r4
    c.r[4] <<= 8;  // 0605BBEC shll8 r4
    c.r[4] += c.r[4];  // 0605BBEE add r4,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605BBF4u; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BBF4u) return; }  // 0605BBF0 jsr @r10 ; add r9,r4
    c.r[1] = ld32(0x0605BC3Cu);  // 0605BBF4 mov.l 0x0605BC3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605BBFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BBFAu) return; }  // 0605BBF6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0605BBFA mov #0,r1
    st8(c.r[12], c.r[1]);  // 0605BBFC mov.b r1,@r12
    c.r[15] = c.r[14];  // 0605BBFE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605BC00 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605BC02 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605BC04 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605BC06 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605BC08 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605BC0A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605BC0C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BC1Cu);  // 0605BC0E mov.w 0x0605BC1C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BC10 rts ; mov.l @r15+,r8
}

void f_0605BC40(SH2Context& c) {
    ran[1393] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BC40 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605BC42 sts.l pr,@-r15
    c.r[1] = ld32(0x0605BC80u);  // 0605BC44 mov.l 0x0605BC80,r1
    c.r[1] = ld32(c.r[1]);  // 0605BC46 mov.l @r1,r1
    c.r[1] += 1;  // 0605BC48 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BC4A mov.b @r1,r0
    c.r[1] = 0x3Fu;  // 0605BC4C mov #63,r1
    c.r[1] &= c.r[0];  // 0605BC4E and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605BC50 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BC60; } }  // 0605BC52 bf/s 0x0605BC60 ; mov r15,r14
    c.r[1] = ld32(0x0605BC84u);  // 0605BC56 mov.l 0x0605BC84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605BC5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BC5Cu) return; }  // 0605BC58 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_0605BC74;  // 0605BC5C bra 0x0605BC74 ; mov r14,r15
L_0605BC60:
    c.r[0] &= 0xC0u;  // 0605BC60 and #192,r0
    c.r[0] >>= 2;  // 0605BC62 shlr2 r0
    c.r[0] >>= 2;  // 0605BC64 shlr2 r0
    c.r[0] >>= 2;  // 0605BC66 shlr2 r0
    c.r[1] -= 1;  // 0605BC68 add #-1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0605BC6A extu.b r1,r4
    c.r[1] = ld32(0x0605BC88u);  // 0605BC6C mov.l 0x0605BC88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605BC72u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BC72u) return; }  // 0605BC6E jsr @r1 ; mov r0,r5
    c.r[15] = c.r[14];  // 0605BC72 mov r14,r15
L_0605BC74:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605BC74 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BC7Cu);  // 0605BC76 mov.w 0x0605BC7C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BC78 rts ; mov.l @r15+,r14
}

void f_0605BC8C(SH2Context& c) {
    ran[1394] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BC8C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605BC8E sts.l pr,@-r15
    c.r[1] = ld32(0x0605BCACu);  // 0605BC90 mov.l 0x0605BCAC,r1
    c.r[1] = ld32(c.r[1]);  // 0605BC92 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BC94 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BC96 extu.b r1,r0
    c.r[0] <<= 2;  // 0605BC98 shll2 r0
    c.r[1] = ld32(0x0605BCB0u);  // 0605BC9A mov.l 0x0605BCB0,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605BC9C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605BCA2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BCA2u) return; }  // 0605BC9E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605BCA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605BCA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605BCA6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605BCA8 rts ; extu.w r0,r0
}

void f_0605BCB4(SH2Context& c) {
    ran[1395] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605BCB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605BCB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BCB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605BCBA sts.l pr,@-r15
    c.r[1] = ld32(0x0605BDF0u);  // 0605BCBC mov.l 0x0605BDF0,r1
    c.r[6] = ld32(c.r[1]);  // 0605BCBE mov.l @r1,r6
    c.r[6] += 1;  // 0605BCC0 add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605BCC2 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605BCC4 extu.b r1,r1
    c.r[0] = c.r[1];  // 0605BCC6 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 0605BCC8 cmp/eq #4,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BD48; } }  // 0605BCCA bf/s 0x0605BD48 ; mov r15,r14
    c.r[1] = ld32(0x0605BDF4u);  // 0605BCCE mov.l 0x0605BDF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BCD0 mov.b @r1,r1
    c.r[2] = ld32(0x0605BDF8u);  // 0605BCD2 mov.l 0x0605BDF8,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0605BCD4 extu.b r1,r9
    c.r[1] = ld32(0x0605BDFCu);  // 0605BCD6 mov.l 0x0605BDFC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BCD8 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BDE8u);  // 0605BCDA mov.w 0x0605BDE8,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605BCDC mov.b @(r0,r2),r7
    c.r[8] = c.r[1] & 0xFFu;  // 0605BCDE extu.b r1,r8
    c.r[1] = c.r[2];  // 0605BCE0 mov r2,r1
    c.r[1] += 78;  // 0605BCE2 add #78,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BCE4 mov.b @r1,r3
    c.r[1] = c.r[7] & 0xFFu;  // 0605BCE6 extu.b r7,r1
    c.r[1] >>= 2;  // 0605BCE8 shlr2 r1
    c.r[1] >>= 2;  // 0605BCEA shlr2 r1
    c.r[1] += c.r[3];  // 0605BCEC add r3,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0605BCEE cmp/ge r1,r9
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_0605BD20; } }  // 0605BCF0 bf/s 0x0605BD20 ; mov r7,r0
    c.r[0] &= 0xFu;  // 0605BCF4 and #15,r0
    c.r[0] -= 20;  // 0605BCF6 add #-20,r0
    c.r[3] -= c.r[0];  // 0605BCF8 sub r0,r3
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[3];  // 0605BCFA cmp/ge r3,r9
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0605BD20; } }  // 0605BCFC bt/s 0x0605BD20 ; mov r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BDEAu);  // 0605BD00 mov.w 0x0605BDEA,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605BD02 mov.b @(r0,r2),r2
    c.r[1] += 79;  // 0605BD04 add #79,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BD06 mov.b @r1,r3
    c.r[1] = c.r[2] & 0xFFu;  // 0605BD08 extu.b r2,r1
    c.r[1] >>= 2;  // 0605BD0A shlr2 r1
    c.r[1] >>= 2;  // 0605BD0C shlr2 r1
    c.r[1] += c.r[3];  // 0605BD0E add r3,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0605BD10 cmp/ge r1,r8
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0605BD20; } }  // 0605BD12 bf/s 0x0605BD20 ; mov r2,r0
    c.r[0] &= 0xFu;  // 0605BD16 and #15,r0
    c.r[0] -= 14;  // 0605BD18 add #-14,r0
    c.r[3] -= c.r[0];  // 0605BD1A sub r0,r3
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[3];  // 0605BD1C cmp/ge r3,r8
    if (!c.t) { goto L_0605BD40; }  // 0605BD1E bf 0x0605BD40
L_0605BD20:
    c.r[3] = ld32(0x0605BDF8u);  // 0605BD20 mov.l 0x0605BDF8,r3
    c.r[2] = c.r[3];  // 0605BD22 mov r3,r2
    c.r[2] += 78;  // 0605BD24 add #78,r2
    c.r[1] = c.r[9];  // 0605BD26 mov r9,r1
    c.r[1] -= 9;  // 0605BD28 add #-9,r1
    st8(c.r[2], c.r[1]);  // 0605BD2A mov.b r1,@r2
    c.r[3] += 79;  // 0605BD2C add #79,r3
    c.r[1] = c.r[8];  // 0605BD2E mov r8,r1
    c.r[1] -= 6;  // 0605BD30 add #-6,r1
    st8(c.r[3], c.r[1]);  // 0605BD32 mov.b r1,@r3
    c.r[9] = c.r[9] & 0xFFu;  // 0605BD34 extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 0605BD36 extu.b r8,r8
    c.r[1] = ld32(0x0605BE00u);  // 0605BD38 mov.l 0x0605BE00,r1
    c.r[5] = 0x0u;  // 0605BD3A mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605BD40u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BD40u) return; }  // 0605BD3C jsr @r1 ; mov #0,r4
L_0605BD40:
    c.r[1] = ld32(0x0605BE04u);  // 0605BD40 mov.l 0x0605BE04,r1
    c.r[5] = c.r[8];  // 0605BD42 mov r8,r5
    c.r[4] = c.r[9]; goto L_0605BE6E;  // 0605BD44 bra 0x0605BE6E ; mov r9,r4
L_0605BD48:
    c.t = c.r[0] == 0x1u;  // 0605BD48 cmp/eq #1,r0
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_0605BE10; } }  // 0605BD4A bf/s 0x0605BE10 ; tst r1,r1
    c.r[1] = ld32(0x0605BE08u);  // 0605BD4E mov.l 0x0605BE08,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BD50 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605BD52 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605BDECu);  // 0605BD54 mov.w 0x0605BDEC,r1
    c.t = c.r[3] == c.r[1];  // 0605BD56 cmp/eq r1,r3
    if (!c.t) { goto L_0605BD5E; }  // 0605BD58 bf 0x0605BD5E
    goto L_0605BE72;  // 0605BD5A bra 0x0605BE72 ; nop
L_0605BD5E:
    c.r[1] = ld32(0x0605BE0Cu);  // 0605BD5E mov.l 0x0605BE0C,r1
    c.r[2] = ld32(c.r[1]);  // 0605BD60 mov.l @r1,r2
    c.r[1] = c.r[3];  // 0605BD62 mov r3,r1
    c.r[1] <<= 2;  // 0605BD64 shll2 r1
    c.r[1] <<= 2;  // 0605BD66 shll2 r1
    c.r[3] = c.r[1];  // 0605BD68 mov r1,r3
    c.r[3] += c.r[2];  // 0605BD6A add r2,r3
    c.r[0] = c.r[1];  // 0605BD6C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605BD6E mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0605BD70 add #1,r3
    c.r[9] = c.r[1] & 0xFFu;  // 0605BD72 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605BD74 mov.b @r3,r1
    c.r[2] = ld32(0x0605BDF8u);  // 0605BD76 mov.l 0x0605BDF8,r2
    c.r[8] = c.r[1] & 0xFFu;  // 0605BD78 extu.b r1,r8
    c.r[1] = c.r[2];  // 0605BD7A mov r2,r1
    c.r[1] += 78;  // 0605BD7C add #78,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BD7E mov.b @r1,r3
    c.r[0] = c.r[2];  // 0605BD80 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605BDE8u);  // 0605BD82 mov.w 0x0605BDE8,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605BD84 mov.b @(r0,r1),r7
    c.r[1] = c.r[7] & 0xFFu;  // 0605BD86 extu.b r7,r1
    c.r[1] >>= 2;  // 0605BD88 shlr2 r1
    c.r[1] >>= 2;  // 0605BD8A shlr2 r1
    c.r[1] += c.r[3];  // 0605BD8C add r3,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0605BD8E cmp/ge r1,r9
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_0605BDC0; } }  // 0605BD90 bf/s 0x0605BDC0 ; mov r7,r0
    c.r[0] &= 0xFu;  // 0605BD94 and #15,r0
    c.r[0] -= 20;  // 0605BD96 add #-20,r0
    c.r[3] -= c.r[0];  // 0605BD98 sub r0,r3
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[3];  // 0605BD9A cmp/ge r3,r9
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0605BDC0; } }  // 0605BD9C bt/s 0x0605BDC0 ; mov r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BDEAu);  // 0605BDA0 mov.w 0x0605BDEA,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605BDA2 mov.b @(r0,r2),r2
    c.r[1] += 79;  // 0605BDA4 add #79,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BDA6 mov.b @r1,r3
    c.r[1] = c.r[2] & 0xFFu;  // 0605BDA8 extu.b r2,r1
    c.r[1] >>= 2;  // 0605BDAA shlr2 r1
    c.r[1] >>= 2;  // 0605BDAC shlr2 r1
    c.r[1] += c.r[3];  // 0605BDAE add r3,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0605BDB0 cmp/ge r1,r8
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0605BDC0; } }  // 0605BDB2 bf/s 0x0605BDC0 ; mov r2,r0
    c.r[0] &= 0xFu;  // 0605BDB6 and #15,r0
    c.r[0] -= 14;  // 0605BDB8 add #-14,r0
    c.r[3] -= c.r[0];  // 0605BDBA sub r0,r3
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[3];  // 0605BDBC cmp/ge r3,r8
    if (!c.t) { goto L_0605BDE0; }  // 0605BDBE bf 0x0605BDE0
L_0605BDC0:
    c.r[3] = ld32(0x0605BDF8u);  // 0605BDC0 mov.l 0x0605BDF8,r3
    c.r[2] = c.r[3];  // 0605BDC2 mov r3,r2
    c.r[2] += 78;  // 0605BDC4 add #78,r2
    c.r[1] = c.r[9];  // 0605BDC6 mov r9,r1
    c.r[1] -= 9;  // 0605BDC8 add #-9,r1
    st8(c.r[2], c.r[1]);  // 0605BDCA mov.b r1,@r2
    c.r[3] += 79;  // 0605BDCC add #79,r3
    c.r[1] = c.r[8];  // 0605BDCE mov r8,r1
    c.r[1] -= 6;  // 0605BDD0 add #-6,r1
    st8(c.r[3], c.r[1]);  // 0605BDD2 mov.b r1,@r3
    c.r[9] = c.r[9] & 0xFFu;  // 0605BDD4 extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 0605BDD6 extu.b r8,r8
    c.r[1] = ld32(0x0605BE00u);  // 0605BDD8 mov.l 0x0605BE00,r1
    c.r[5] = 0x0u;  // 0605BDDA mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605BDE0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BDE0u) return; }  // 0605BDDC jsr @r1 ; mov #0,r4
L_0605BDE0:
    c.r[1] = ld32(0x0605BE04u);  // 0605BDE0 mov.l 0x0605BE04,r1
    c.r[5] = c.r[8];  // 0605BDE2 mov r8,r5
    c.r[4] = c.r[9]; goto L_0605BE6E;  // 0605BDE4 bra 0x0605BE6E ; mov r9,r4
L_0605BE10:
    if (c.t) { goto L_0605BE54; }  // 0605BE10 bt 0x0605BE54
    c.r[7] = ld32(0x0605BE88u);  // 0605BE12 mov.l 0x0605BE88,r7
    c.r[3] = c.r[7];  // 0605BE14 mov r7,r3
    c.r[3] += 78;  // 0605BE16 add #78,r3
    c.r[1] = c.r[7];  // 0605BE18 mov r7,r1
    c.r[1] += 116;  // 0605BE1A add #116,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BE1C mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605BE80u);  // 0605BE1E mov.w 0x0605BE80,r2
    c.r[2] += c.r[1];  // 0605BE20 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605BE22 mov.b @r3,r1
    c.r[2] += c.r[1];  // 0605BE24 add r1,r2
    st8(c.r[3], c.r[2]);  // 0605BE26 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605BE28 mov.b @r6,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BE2A extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 0605BE2C cmp/eq #2,r0
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_0605BE3C; } }  // 0605BE2E bf/s 0x0605BE3C ; mov r7,r3
    c.r[3] += 79;  // 0605BE32 add #79,r3
    c.r[7] += 117;  // 0605BE34 add #117,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605BE82u);  // 0605BE36 mov.w 0x0605BE82,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); goto L_0605BE44;  // 0605BE38 bra 0x0605BE44 ; mov.b @r7,r1
L_0605BE3C:
    c.r[3] += 79;  // 0605BE3C add #79,r3
    c.r[7] += 117;  // 0605BE3E add #117,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605BE40 mov.b @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605BE84u);  // 0605BE42 mov.w 0x0605BE84,r2
L_0605BE44:
    c.r[2] += c.r[1];  // 0605BE44 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605BE46 mov.b @r3,r1
    c.r[2] += c.r[1];  // 0605BE48 add r1,r2
    st8(c.r[3], c.r[2]);  // 0605BE4A mov.b r2,@r3
    c.r[1] = ld32(0x0605BE8Cu);  // 0605BE4C mov.l 0x0605BE8C,r1
    c.r[5] = 0x0u;  // 0605BE4E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605BE54u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BE54u) return; }  // 0605BE50 jsr @r1 ; mov #0,r4
L_0605BE54:
    c.r[2] = ld32(0x0605BE88u);  // 0605BE54 mov.l 0x0605BE88,r2
    c.r[1] = c.r[2];  // 0605BE56 mov r2,r1
    c.r[1] += 78;  // 0605BE58 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BE5A mov.b @r1,r1
    c.r[2] += 79;  // 0605BE5C add #79,r2
    c.r[1] += 9;  // 0605BE5E add #9,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0605BE60 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BE62 mov.b @r2,r1
    c.r[4] = c.r[9];  // 0605BE64 mov r9,r4
    c.r[1] += 6;  // 0605BE66 add #6,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0605BE68 extu.b r1,r8
    c.r[1] = ld32(0x0605BE90u);  // 0605BE6A mov.l 0x0605BE90,r1
    c.r[5] = c.r[8];  // 0605BE6C mov r8,r5
L_0605BE6E:
    { const uint32_t x = c.r[1]; c.pr = 0x0605BE72u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605BE72u) return; }  // 0605BE6E jsr @r1 ; nop
L_0605BE72:
    c.r[15] = c.r[14];  // 0605BE72 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605BE74 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605BE76 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605BE78 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BE86u);  // 0605BE7A mov.w 0x0605BE86,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BE7C rts ; mov.l @r15+,r8
}

void f_0605BE94(SH2Context& c) {
    ran[1396] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BE94 mov.l r14,@-r15
    c.r[1] = ld32(0x0605BEECu);  // 0605BE96 mov.l 0x0605BEEC,r1
    c.r[2] = ld32(c.r[1]);  // 0605BE98 mov.l @r1,r2
    c.r[2] += 1;  // 0605BE9A add #1,r2
    st32(c.r[1], c.r[2]);  // 0605BE9C mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BE9E mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BEA0 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605BEA2 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BEB2; } }  // 0605BEA4 bf/s 0x0605BEB2 ; mov r15,r14
    c.r[1] = ld32(0x0605BEF0u);  // 0605BEA8 mov.l 0x0605BEF0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BEAA mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 0605BEAC and #223,r0
    st8(c.r[1], c.r[0]); goto L_0605BEDE;  // 0605BEAE bra 0x0605BEDE ; mov.b r0,@r1
L_0605BEB2:
    c.t = c.r[0] == 0x1u;  // 0605BEB2 cmp/eq #1,r0
    if (!c.t) { goto L_0605BEC0; }  // 0605BEB4 bf 0x0605BEC0
    c.r[1] = ld32(0x0605BEF0u);  // 0605BEB6 mov.l 0x0605BEF0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BEB8 mov.b @r1,r0
    c.r[0] |= 0x20u;  // 0605BEBA or #32,r0
    st8(c.r[1], c.r[0]); goto L_0605BEDE;  // 0605BEBC bra 0x0605BEDE ; mov.b r0,@r1
L_0605BEC0:
    c.r[1] = ld32(0x0605BEF0u);  // 0605BEC0 mov.l 0x0605BEF0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BEC2 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605BEE6u);  // 0605BEC4 mov.w 0x0605BEE6,r3
    c.r[0] = c.r[2];  // 0605BEC6 mov r2,r0
    c.r[0] >>= 2;  // 0605BEC8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605BECA shlr r0
    c.r[0] >>= 2;  // 0605BECC shlr2 r0
    c.r[0] &= 0x1u;  // 0605BECE and #1,r0
    c.r[0] ^= 0x1u;  // 0605BED0 xor #1,r0
    c.r[0] <<= 2;  // 0605BED2 shll2 r0
    c.r[0] += c.r[0];  // 0605BED4 add r0,r0
    c.r[0] <<= 2;  // 0605BED6 shll2 r0
    c.r[2] &= c.r[3];  // 0605BED8 and r3,r2
    c.r[2] |= c.r[0];  // 0605BEDA or r0,r2
    st8(c.r[1], c.r[2]);  // 0605BEDC mov.b r2,@r1
L_0605BEDE:
    c.r[15] = c.r[14];  // 0605BEDE mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BEE8u);  // 0605BEE0 mov.w 0x0605BEE8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BEE2 rts ; mov.l @r15+,r14
}

void f_0605BEF4(SH2Context& c) {
    ran[1397] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BEF4 mov.l r14,@-r15
    c.r[1] = ld32(0x0605BF4Cu);  // 0605BEF6 mov.l 0x0605BF4C,r1
    c.r[2] = ld32(c.r[1]);  // 0605BEF8 mov.l @r1,r2
    c.r[2] += 1;  // 0605BEFA add #1,r2
    st32(c.r[1], c.r[2]);  // 0605BEFC mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BEFE mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BF00 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605BF02 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BF12; } }  // 0605BF04 bf/s 0x0605BF12 ; mov r15,r14
    c.r[1] = ld32(0x0605BF50u);  // 0605BF08 mov.l 0x0605BF50,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BF0A mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 0605BF0C and #223,r0
    st8(c.r[1], c.r[0]); goto L_0605BF3E;  // 0605BF0E bra 0x0605BF3E ; mov.b r0,@r1
L_0605BF12:
    c.t = c.r[0] == 0x1u;  // 0605BF12 cmp/eq #1,r0
    if (!c.t) { goto L_0605BF20; }  // 0605BF14 bf 0x0605BF20
    c.r[1] = ld32(0x0605BF50u);  // 0605BF16 mov.l 0x0605BF50,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BF18 mov.b @r1,r0
    c.r[0] |= 0x20u;  // 0605BF1A or #32,r0
    st8(c.r[1], c.r[0]); goto L_0605BF3E;  // 0605BF1C bra 0x0605BF3E ; mov.b r0,@r1
L_0605BF20:
    c.r[1] = ld32(0x0605BF50u);  // 0605BF20 mov.l 0x0605BF50,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BF22 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605BF46u);  // 0605BF24 mov.w 0x0605BF46,r3
    c.r[0] = c.r[2];  // 0605BF26 mov r2,r0
    c.r[0] >>= 2;  // 0605BF28 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605BF2A shlr r0
    c.r[0] >>= 2;  // 0605BF2C shlr2 r0
    c.r[0] &= 0x1u;  // 0605BF2E and #1,r0
    c.r[0] ^= 0x1u;  // 0605BF30 xor #1,r0
    c.r[0] <<= 2;  // 0605BF32 shll2 r0
    c.r[0] += c.r[0];  // 0605BF34 add r0,r0
    c.r[0] <<= 2;  // 0605BF36 shll2 r0
    c.r[2] &= c.r[3];  // 0605BF38 and r3,r2
    c.r[2] |= c.r[0];  // 0605BF3A or r0,r2
    st8(c.r[1], c.r[2]);  // 0605BF3C mov.b r2,@r1
L_0605BF3E:
    c.r[15] = c.r[14];  // 0605BF3E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605BF48u);  // 0605BF40 mov.w 0x0605BF48,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605BF42 rts ; mov.l @r15+,r14
}

void f_0605BF54(SH2Context& c) {
    ran[1398] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605BF54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605BF56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605BF58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605BF5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605BF5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605BF5E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605C0A4u);  // 0605BF60 mov.w 0x0605C0A4,r3
    c.r[1] = ld32(0x0605C0ACu);  // 0605BF62 mov.l 0x0605C0AC,r1
    c.r[1] = ld32(c.r[1]);  // 0605BF64 mov.l @r1,r1
    c.r[15] += c.r[3];  // 0605BF66 add r3,r15
    c.r[1] += 1;  // 0605BF68 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BF6A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605BF6C extu.b r1,r2
    c.r[1] = 0x6u;  // 0605BF6E mov #6,r1
    c.r[2] -= 1;  // 0605BF70 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0605BF72 cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605BF7C; } }  // 0605BF74 bf/s 0x0605BF7C ; mov r15,r14
    goto L_0605C13A;  // 0605BF78 bra 0x0605C13A ; nop
L_0605BF7C:
    c.r[1] = c.r[2];  // 0605BF7C mov r2,r1
    c.r[1] += c.r[1];  // 0605BF7E add r1,r1
    c.r[0] = 0x0605BF8Cu;  // 0605BF80 mova 0x0605BF8C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605BF82 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0605BF84 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0605BF9Au: goto L_0605BF9A; case 0x0605BFA0u: goto L_0605BFA0; case 0x0605BFAAu: goto L_0605BFAA; case 0x0605C02Cu: goto L_0605C02C; case 0x0605C04Au: goto L_0605C04A; case 0x0605C052u: goto L_0605C052; case 0x0605C0E0u: goto L_0605C0E0; default: sh2_call(c, x); return; } }  // 0605BF86 jmp @r0 ; nop
L_0605BF9A:
    c.r[2] = ld32(0x0605C0B0u);  // 0605BF9A mov.l 0x0605C0B0,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_0605BFA4;  // 0605BF9C bra 0x0605BFA4 ; mov.b @r2,r2
L_0605BFA0:
    c.r[2] = ld32(0x0605C0B4u);  // 0605BFA0 mov.l 0x0605C0B4,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BFA2 mov.b @r2,r2
L_0605BFA4:
    c.r[1] = ld32(0x0605C0B8u);  // 0605BFA4 mov.l 0x0605C0B8,r1
    st8(c.r[1], c.r[2]); goto L_0605C174;  // 0605BFA6 bra 0x0605C174 ; mov.b r2,@r1
L_0605BFAA:
    c.r[1] = ld32(0x0605C0BCu);  // 0605BFAA mov.l 0x0605C0BC,r1
    c.r[3] = ld32(c.r[1]);  // 0605BFAC mov.l @r1,r3
    c.r[1] = ld32(0x0605C0C0u);  // 0605BFAE mov.l 0x0605C0C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BFB0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BFB2 extu.b r1,r0
    c.r[1] = ld32(0x0605C0C4u);  // 0605BFB4 mov.l 0x0605C0C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605BFB6 mov.b @(r0,r1),r1
    c.r[2] = 0xBu;  // 0605BFB8 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605BFBA extu.b r1,r1
    c.r[1] -= 1;  // 0605BFBC add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0605BFBE mul.l r2,r1
    c.r[1] = ld32(0x0605C0C8u);  // 0605BFC0 mov.l 0x0605C0C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605BFC2 mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605BFC4 extu.b r1,r0
    c.r[1] = ld32(0x0605C0CCu);  // 0605BFC6 mov.l 0x0605C0CC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605BFC8 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0605BFCA sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605BFCC extu.b r1,r1
    c.r[2] += c.r[1];  // 0605BFCE add r1,r2
    c.r[2] += c.r[2];  // 0605BFD0 add r2,r2
    c.r[3] += c.r[2];  // 0605BFD2 add r2,r3
    c.r[3] += 1;  // 0605BFD4 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605BFD6 mov.b @r3,r1
    c.r[7] = ld32(0x0605C0B8u);  // 0605BFD8 mov.l 0x0605C0B8,r7
    st8(c.r[7], c.r[1]);  // 0605BFDA mov.b r1,@r7
    c.r[2] = c.r[1] & 0xFFu;  // 0605BFDC extu.b r1,r2
    c.r[1] = ld32(0x0605C0D0u);  // 0605BFDE mov.l 0x0605C0D0,r1
    c.r[3] = ld32(c.r[1]);  // 0605BFE0 mov.l @r1,r3
    c.r[2] <<= 2;  // 0605BFE2 shll2 r2
    c.r[2] <<= 2;  // 0605BFE4 shll2 r2
    c.r[2] += c.r[3];  // 0605BFE6 add r3,r2
    c.r[1] = c.r[2];  // 0605BFE8 mov r2,r1
    c.r[1] += 4;  // 0605BFEA add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605BFEC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605BFEE mov r1,r0
    c.r[0] >>= 2;  // 0605BFF0 shlr2 r0
    c.r[0] >>= 2;  // 0605BFF2 shlr2 r0
    c.r[0] >>= 2;  // 0605BFF4 shlr2 r0
    c.r[0] &= 0x1u;  // 0605BFF6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605BFF8 tst r0,r0
    { const bool k = c.t; c.r[2] += 5; if (k) { goto L_0605C002; } }  // 0605BFFA bt/s 0x0605C002 ; add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605BFFE mov.b @r2,r1
    st8(c.r[7], c.r[1]);  // 0605C000 mov.b r1,@r7
L_0605C002:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605C002 mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605C004 extu.b r1,r2
    c.r[2] <<= 2;  // 0605C006 shll2 r2
    c.r[2] <<= 2;  // 0605C008 shll2 r2
    c.r[2] += c.r[3];  // 0605C00A add r3,r2
    c.r[1] = c.r[2];  // 0605C00C mov r2,r1
    c.r[1] += 4;  // 0605C00E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C010 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605C012 mov r1,r0
    c.r[0] >>= 2;  // 0605C014 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605C016 shlr r0
    c.r[0] >>= 2;  // 0605C018 shlr2 r0
    c.r[0] &= 0x1u;  // 0605C01A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C01C tst r0,r0
    { const bool k = !c.t; c.r[2] += 6; if (k) { goto L_0605C026; } }  // 0605C01E bf/s 0x0605C026 ; add #6,r2
    goto L_0605C174;  // 0605C022 bra 0x0605C174 ; nop
L_0605C026:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C026 mov.b @r2,r1
    st8(c.r[7], c.r[1]); goto L_0605C174;  // 0605C028 bra 0x0605C174 ; mov.b r1,@r7
L_0605C02C:
    c.r[1] = ld32(0x0605C0D4u);  // 0605C02C mov.l 0x0605C0D4,r1
    c.r[2] = ld32(c.r[1]);  // 0605C02E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C0A6u);  // 0605C030 mov.w 0x0605C0A6,r1
    c.r[2] += c.r[1];  // 0605C032 add r1,r2
    c.r[1] = ld32(0x0605C0D8u);  // 0605C034 mov.l 0x0605C0D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C036 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C038 extu.b r1,r1
    c.r[1] <<= 2;  // 0605C03A shll2 r1
    c.r[1] += c.r[1];  // 0605C03C add r1,r1
    c.r[2] += c.r[1];  // 0605C03E add r1,r2
    c.r[2] += 4;  // 0605C040 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C042 mov.b @r2,r1
    c.r[3] = ld32(0x0605C0B8u);  // 0605C044 mov.l 0x0605C0B8,r3
    st8(c.r[3], c.r[1]); goto L_0605C174;  // 0605C046 bra 0x0605C174 ; mov.b r1,@r3
L_0605C04A:
    c.r[8] = ld32(0x0605C0B8u);  // 0605C04A mov.l 0x0605C0B8,r8
    c.r[1] = ld32(0x0605C0B0u);  // 0605C04C mov.l 0x0605C0B0,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0605C058;  // 0605C04E bra 0x0605C058 ; mov.b @r1,r4
L_0605C052:
    c.r[8] = ld32(0x0605C0B8u);  // 0605C052 mov.l 0x0605C0B8,r8
    c.r[1] = ld32(0x0605C0B4u);  // 0605C054 mov.l 0x0605C0B4,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C056 mov.b @r1,r4
L_0605C058:
    c.r[0] = ld32(0x0605C0DCu);  // 0605C058 mov.l 0x0605C0DC,r0
    st8(c.r[8], c.r[4]);  // 0605C05A mov.b r4,@r8
    { const uint32_t x = c.r[0]; c.pr = 0x0605C060u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C060u) return; }  // 0605C05C jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0605C060 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C0A8u);  // 0605C062 mov.w 0x0605C0A8,r1
    c.t = c.r[2] == c.r[1];  // 0605C064 cmp/eq r1,r2
    if (!c.t) { goto L_0605C06C; }  // 0605C066 bf 0x0605C06C
    goto L_0605C174;  // 0605C068 bra 0x0605C174 ; nop
L_0605C06C:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C06C mov.b @r8,r2
    c.r[1] = ld32(0x0605C0D0u);  // 0605C06E mov.l 0x0605C0D0,r1
    c.r[3] = ld32(c.r[1]);  // 0605C070 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605C072 extu.b r2,r2
    c.r[2] <<= 2;  // 0605C074 shll2 r2
    c.r[2] <<= 2;  // 0605C076 shll2 r2
    c.r[2] += c.r[3];  // 0605C078 add r3,r2
    c.r[2] += 8;  // 0605C07A add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C07C mov.b @r2,r1
    st8(c.r[8], c.r[1]);  // 0605C07E mov.b r1,@r8
    c.r[2] = c.r[1] & 0xFFu;  // 0605C080 extu.b r1,r2
    c.r[2] <<= 2;  // 0605C082 shll2 r2
    c.r[2] <<= 2;  // 0605C084 shll2 r2
    c.r[2] += c.r[3];  // 0605C086 add r3,r2
    c.r[1] = c.r[2];  // 0605C088 mov r2,r1
    c.r[1] += 4;  // 0605C08A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C08C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605C08E mov r1,r0
    c.r[0] >>= 2;  // 0605C090 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605C092 shlr r0
    c.r[0] >>= 2;  // 0605C094 shlr2 r0
    c.r[0] &= 0x1u;  // 0605C096 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C098 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0605C174; } }  // 0605C09A bt/s 0x0605C174 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C09E mov.b @r2,r1
    st8(c.r[8], c.r[1]); goto L_0605C174;  // 0605C0A0 bra 0x0605C174 ; mov.b r1,@r8
L_0605C0E0:
    c.r[9] = 0x0u;  // 0605C0E0 mov #0,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x0605C18Au);  // 0605C0E2 mov.w 0x0605C18A,r10
    c.r[11] = ld32(0x0605C194u);  // 0605C0E4 mov.l 0x0605C194,r11
    c.r[8] = 0x0u;  // 0605C0E6 mov #0,r8
L_0605C0E8:
    c.r[1] = ld32(0x0605C198u);  // 0605C0E8 mov.l 0x0605C198,r1
    c.r[0] = ld32(c.r[1]);  // 0605C0EA mov.l @r1,r0
    c.r[5] = c.r[8];  // 0605C0EC mov r8,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605C0EE mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C0F0 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0605C0F2 cmp/eq r10,r1
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_0605C126; } }  // 0605C0F4 bt/s 0x0605C126 ; add r0,r5
    c.r[1] = c.r[5];  // 0605C0F8 mov r5,r1
    c.r[1] += 7;  // 0605C0FA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C0FC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605C0FE mov r1,r0
    c.r[0] >>= 2;  // 0605C100 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605C102 shlr r0
    c.r[0] &= 0x1u;  // 0605C104 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C106 tst r0,r0
    if (!c.t) { goto L_0605C126; }  // 0605C108 bf 0x0605C126
    c.r[5] += 2;  // 0605C10A add #2,r5
    c.r[6] = c.r[10];  // 0605C10C mov r10,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605C10E mov.b @r5,r5
    c.r[4] = c.r[14];  // 0605C110 mov r14,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0605C116u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C116u) return; }  // 0605C112 jsr @r11 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C18Cu);  // 0605C116 mov.w 0x0605C18C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0605C118 mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0605C11A mov r1,r0
    c.r[0] >>= 2;  // 0605C11C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605C11E shlr r0
    c.r[0] &= 0x1u;  // 0605C120 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C122 tst r0,r0
    if (!c.t) { goto L_0605C134; }  // 0605C124 bf 0x0605C134
L_0605C126:
    c.r[9] += 1;  // 0605C126 add #1,r9
    c.r[1] = 0x49u;  // 0605C128 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605C12A cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_0605C0E8; } }  // 0605C12C bf/s 0x0605C0E8 ; add #16,r8
    goto L_0605C174;  // 0605C130 bra 0x0605C174 ; nop
L_0605C134:
    c.r[1] = ld32(0x0605C19Cu);  // 0605C134 mov.l 0x0605C19C,r1
    st8(c.r[1], c.r[9]); goto L_0605C174;  // 0605C136 bra 0x0605C174 ; mov.b r9,@r1
L_0605C13A:
    c.r[5] = ld32(0x0605C19Cu);  // 0605C13A mov.l 0x0605C19C,r5
    c.r[2] = ld32(0x0605C1A0u);  // 0605C13C mov.l 0x0605C1A0,r2
    c.r[1] = c.r[2];  // 0605C13E mov r2,r1
    c.r[1] += 117;  // 0605C140 add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C142 mov.b @r1,r3
    c.r[6] = ld32(0x0605C1A4u);  // 0605C144 mov.l 0x0605C1A4,r6
    c.r[1] = c.r[2];  // 0605C146 mov r2,r1
    c.r[1] += 79;  // 0605C148 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C14A mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605C14C extu.b r3,r3
    c.r[3] += c.r[1];  // 0605C14E add r1,r3
    c.r[1] = c.r[2];  // 0605C150 mov r2,r1
    c.r[1] += 116;  // 0605C152 add #116,r1
    c.r[2] += 78;  // 0605C154 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C156 mov.b @r1,r1
    c.r[3] <<= 2;  // 0605C158 shll2 r3
    c.r[3] <<= 2;  // 0605C15A shll2 r3
    c.r[3] <<= 2;  // 0605C15C shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C15E mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0605C160 extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 0605C162 mov.l @r6,r2
    c.r[1] += c.r[7];  // 0605C164 add r7,r1
    c.r[3] += c.r[2];  // 0605C166 add r2,r3
    c.r[0] = c.r[3];  // 0605C168 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605C16A mov.b @(r0,r1),r1
    c.r[6] += 19;  // 0605C16C add #19,r6
    st8(c.r[5], c.r[1]);  // 0605C16E mov.b r1,@r5
    c.r[1] = 0xFFFFFFFFu;  // 0605C170 mov #-1,r1
    st8(c.r[6], c.r[1]);  // 0605C172 mov.b r1,@r6
L_0605C174:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605C18Eu);  // 0605C174 mov.w 0x0605C18E,r3
    c.r[14] += c.r[3];  // 0605C176 add r3,r14
    c.r[15] = c.r[14];  // 0605C178 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605C17A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605C17C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605C17E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605C180 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605C182 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C190u);  // 0605C184 mov.w 0x0605C190,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605C186 rts ; mov.l @r15+,r8
}

void f_0605C1A8(SH2Context& c) {
    ran[1399] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C1A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605C1AA sts.l pr,@-r15
    c.r[1] = ld32(0x0605C1C8u);  // 0605C1AC mov.l 0x0605C1C8,r1
    c.r[1] = ld32(c.r[1]);  // 0605C1AE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C1B0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605C1B2 extu.b r1,r0
    c.r[0] <<= 2;  // 0605C1B4 shll2 r0
    c.r[1] = ld32(0x0605C1CCu);  // 0605C1B6 mov.l 0x0605C1CC,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605C1B8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605C1BEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C1BEu) return; }  // 0605C1BA jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605C1BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605C1C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605C1C2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605C1C4 rts ; extu.w r0,r0
}

void f_0605C1D0(SH2Context& c) {
    ran[1400] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605C1D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605C1D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605C1D4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605C1D6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605C1D8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605C1DA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C1DC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605C1DE sts.l pr,@-r15
    c.r[15] -= 12;  // 0605C1E0 add #-12,r15
    c.r[14] = c.r[15];  // 0605C1E2 mov r15,r14
    c.r[1] = 0xFFFFFFFFu;  // 0605C1E4 mov #-1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0605C1E6 mov.l r1,@(8,r14)
    c.r[8] = ld32(0x0605C340u);  // 0605C1E8 mov.l 0x0605C340,r8
    c.r[1] = 0x1u;  // 0605C1EA mov #1,r1
    st8(c.r[8], c.r[1]);  // 0605C1EC mov.b r1,@r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605C33Au);  // 0605C1EE mov.w 0x0605C33A,r6
    c.r[12] = ld32(0x0605C344u);  // 0605C1F0 mov.l 0x0605C344,r12
    c.r[4] = c.r[14];  // 0605C1F2 mov r14,r4
    c.r[4] += 8;  // 0605C1F4 add #8,r4
    c.r[1] = ld32(0x0605C348u);  // 0605C1F6 mov.l 0x0605C348,r1
    c.r[7] = 0x11u;  // 0605C1F8 mov #17,r7
    { const uint32_t x = c.r[1]; c.pr = 0x0605C1FEu; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C1FEu) return; }  // 0605C1FA jsr @r1 ; mov r12,r5
    c.r[1] = ld32(0x0605C34Cu);  // 0605C1FE mov.l 0x0605C34C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605C204u; c.r[13] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C204u) return; }  // 0605C200 jsr @r1 ; mov #0,r13
    c.r[1] = 0x0u;  // 0605C204 mov #0,r1
    st8(c.r[8], c.r[1]);  // 0605C206 mov.b r1,@r8
    c.r[10] = ld32(0x0605C350u);  // 0605C208 mov.l 0x0605C350,r10
    c.r[1] = ld32(0x0605C354u);  // 0605C20A mov.l 0x0605C354,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605C20C mov.b @r10,r4
    c.r[5] = c.r[14];  // 0605C20E mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605C214u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C214u) return; }  // 0605C210 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0605C214 mov.b @r14,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605C216 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C33Cu);  // 0605C218 mov.w 0x0605C33C,r1
    c.t = c.r[2] == c.r[1];  // 0605C21A cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0605C2B6; } }  // 0605C21C bf/s 0x0605C2B6 ; mov.b @r10,r1
    c.r[7] = ld32(0x0605C358u);  // 0605C220 mov.l 0x0605C358,r7
    c.r[6] = ld32(0x0605C35Cu);  // 0605C222 mov.l 0x0605C35C,r6
    c.r[8] = ld32(0x0605C360u);  // 0605C224 mov.l 0x0605C360,r8
    c.r[3] = ld32(c.r[8]);  // 0605C226 mov.l @r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605C228 extu.b r1,r1
    c.r[1] <<= 2;  // 0605C22A shll2 r1
    c.r[1] <<= 2;  // 0605C22C shll2 r1
    c.r[2] = c.r[1];  // 0605C22E mov r1,r2
    c.r[2] += c.r[3];  // 0605C230 add r3,r2
    c.r[2] += 1;  // 0605C232 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C234 mov.b @r2,r5
    c.r[0] = c.r[1];  // 0605C236 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605C238 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605C23A extu.b r5,r5
    c.r[1] = ld32(0x0605C364u);  // 0605C23C mov.l 0x0605C364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605C242u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C242u) return; }  // 0605C23E jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605C242 mov.b @r10,r1
    c.r[3] = c.r[14];  // 0605C244 mov r14,r3
    c.r[2] = ld32(c.r[8]);  // 0605C246 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C248 extu.b r1,r1
    c.r[1] <<= 2;  // 0605C24A shll2 r1
    c.r[1] <<= 2;  // 0605C24C shll2 r1
    c.r[7] = c.r[1];  // 0605C24E mov r1,r7
    c.r[7] += c.r[2];  // 0605C250 add r2,r7
    c.r[0] = c.r[1];  // 0605C252 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605C254 mov.b @(r0,r2),r2
    c.r[3] += 1;  // 0605C256 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605C258 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605C25A extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C25C extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0605C25E cmp/eq r1,r2
    { const bool k = !c.t; c.r[7] += 1; if (k) { goto L_0605C27A; } }  // 0605C260 bf/s 0x0605C27A ; add #1,r7
    c.r[1] = c.r[14];  // 0605C264 mov r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605C266 mov.b @r7,r2
    c.r[1] += 2;  // 0605C268 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C26A mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605C26C extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C26E extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0605C270 cmp/eq r1,r2
    if (!c.t) { goto L_0605C27A; }  // 0605C272 bf 0x0605C27A
    c.r[13] = 0x1u;  // 0605C274 mov #1,r13
    goto L_0605C3F6;  // 0605C276 bra 0x0605C3F6 ; nop
L_0605C27A:
    c.r[1] = c.r[14];  // 0605C27A mov r14,r1
    c.r[1] += 2;  // 0605C27C add #2,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C27E mov.b @r1,r7
    c.r[1] = c.r[14];  // 0605C280 mov r14,r1
    c.r[1] += 1;  // 0605C282 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C284 mov.b @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0605C286 extu.b r7,r7
    c.r[1] = ld32(0x0605C350u);  // 0605C288 mov.l 0x0605C350,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C28A mov.b @r1,r2
    c.r[6] = c.r[6] & 0xFFu;  // 0605C28C extu.b r6,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0605C28E extu.b r2,r2
    c.r[1] = ld32(0x0605C360u);  // 0605C290 mov.l 0x0605C360,r1
    c.r[3] = ld32(c.r[1]);  // 0605C292 mov.l @r1,r3
    c.r[2] <<= 2;  // 0605C294 shll2 r2
    c.r[2] <<= 2;  // 0605C296 shll2 r2
    c.r[1] = c.r[2];  // 0605C298 mov r2,r1
    c.r[1] += c.r[3];  // 0605C29A add r3,r1
    c.r[1] += 1;  // 0605C29C add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C29E mov.b @r1,r5
    c.r[0] = c.r[2];  // 0605C2A0 mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605C2A2 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605C2A4 extu.b r5,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0605C2A6 extu.b r4,r4
    c.r[1] = ld32(0x0605C358u);  // 0605C2A8 mov.l 0x0605C358,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605C2AA mov.l r1,@-r15
    c.r[1] = ld32(0x0605C344u);  // 0605C2AC mov.l 0x0605C344,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605C2AE mov.l r1,@-r15
    c.r[1] = ld32(0x0605C35Cu);  // 0605C2B0 mov.l 0x0605C35C,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]); goto L_0605C330;  // 0605C2B2 bra 0x0605C330 ; mov.l r1,@-r15
L_0605C2B6:
    c.r[11] = ld32(0x0605C360u);  // 0605C2B6 mov.l 0x0605C360,r11
    c.r[3] = ld32(c.r[11]);  // 0605C2B8 mov.l @r11,r3
    c.r[4] = c.r[1] & 0xFFu;  // 0605C2BA extu.b r1,r4
    c.r[4] <<= 2;  // 0605C2BC shll2 r4
    c.r[4] <<= 2;  // 0605C2BE shll2 r4
    c.r[5] = c.r[4];  // 0605C2C0 mov r4,r5
    c.r[5] += c.r[3];  // 0605C2C2 add r3,r5
    c.r[1] = c.r[5];  // 0605C2C4 mov r5,r1
    c.r[1] += 7;  // 0605C2C6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C2C8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C2CA extu.b r1,r1
    c.r[1] >>= 2;  // 0605C2CC shlr2 r1
    c.r[1] >>= 2;  // 0605C2CE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605C2D0 shlr r1
    c.r[1] >>= 2;  // 0605C2D2 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C2D4 tst r1,r1
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_0605C36C; } }  // 0605C2D6 bf/s 0x0605C36C ; shll2 r2
    c.r[8] = ld32(0x0605C358u);  // 0605C2DA mov.l 0x0605C358,r8
    c.r[9] = ld32(0x0605C35Cu);  // 0605C2DC mov.l 0x0605C35C,r9
    c.r[2] <<= 2;  // 0605C2DE shll2 r2
    c.r[1] = c.r[2];  // 0605C2E0 mov r2,r1
    c.r[1] += c.r[3];  // 0605C2E2 add r3,r1
    c.r[1] += 1;  // 0605C2E4 add #1,r1
    c.r[0] = c.r[2];  // 0605C2E6 mov r2,r0
    c.r[7] = c.r[8];  // 0605C2E8 mov r8,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C2EA mov.b @r1,r5
    c.r[6] = c.r[9];  // 0605C2EC mov r9,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605C2EE mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605C2F0 extu.b r5,r5
    c.r[1] = ld32(0x0605C364u);  // 0605C2F2 mov.l 0x0605C364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605C2F8u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C2F8u) return; }  // 0605C2F4 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605C2F8 mov.b @r10,r1
    c.r[3] = ld32(c.r[11]);  // 0605C2FA mov.l @r11,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605C2FC extu.b r1,r1
    c.r[1] <<= 2;  // 0605C2FE shll2 r1
    c.r[1] <<= 2;  // 0605C300 shll2 r1
    c.r[2] = c.r[1];  // 0605C302 mov r1,r2
    c.r[2] += c.r[3];  // 0605C304 add r3,r2
    c.r[2] += 1;  // 0605C306 add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C308 mov.b @r2,r7
    c.r[0] = c.r[1];  // 0605C30A mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605C30C mov.b @(r0,r3),r6
    c.r[7] = c.r[7] & 0xFFu;  // 0605C30E extu.b r7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0605C310 mov.b @r14,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0605C312 extu.b r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0605C314 extu.b r1,r1
    c.r[1] <<= 2;  // 0605C316 shll2 r1
    c.r[1] <<= 2;  // 0605C318 shll2 r1
    c.r[2] = c.r[1];  // 0605C31A mov r1,r2
    c.r[2] += c.r[3];  // 0605C31C add r3,r2
    c.r[2] += 1;  // 0605C31E add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C320 mov.b @r2,r5
    c.r[0] = c.r[1];  // 0605C322 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605C324 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605C326 extu.b r5,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0605C328 extu.b r4,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605C32A mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605C32C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605C32E mov.l r9,@-r15
L_0605C330:
    c.r[1] = ld32(0x0605C368u);  // 0605C330 mov.l 0x0605C368,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605C336u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C336u) return; }  // 0605C332 jsr @r1 ; nop
    goto L_0605C3F6;  // 0605C336 bra 0x0605C3F6 ; nop
L_0605C36C:
    c.r[7] = ld32(0x0605C424u);  // 0605C36C mov.l 0x0605C424,r7
    c.r[6] = ld32(0x0605C428u);  // 0605C36E mov.l 0x0605C428,r6
    c.r[5] += 1;  // 0605C370 add #1,r5
    c.r[0] = c.r[4];  // 0605C372 mov r4,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605C374 mov.b @r5,r5
    c.r[1] = ld32(0x0605C42Cu);  // 0605C376 mov.l 0x0605C42C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605C378 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605C37A extu.b r5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605C380u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C380u) return; }  // 0605C37C jsr @r1 ; extu.b r4,r4
    c.r[9] = c.r[12];  // 0605C380 mov r12,r9
    c.r[10] = 0x0u;  // 0605C382 mov #0,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605C41Eu);  // 0605C384 mov.w 0x0605C41E,r11
    c.r[12] = ld32(0x0605C430u);  // 0605C386 mov.l 0x0605C430,r12
    c.r[0] = c.r[14];  // 0605C388 mov r14,r0
L_0605C38A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0605C38A mov.b @(r0,r10),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605C38C extu.b r1,r3
    c.t = c.r[3] == c.r[11];  // 0605C38E cmp/eq r11,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0605C3EC; } }  // 0605C390 bt/s 0x0605C3EC ; mov r3,r0
    c.r[1] = ld32(0x0605C434u);  // 0605C394 mov.l 0x0605C434,r1
    c.r[2] = ld32(c.r[1]);  // 0605C396 mov.l @r1,r2
    c.r[0] <<= 2;  // 0605C398 shll2 r0
    c.r[0] <<= 2;  // 0605C39A shll2 r0
    c.r[1] = c.r[0];  // 0605C39C mov r0,r1
    c.r[1] += c.r[2];  // 0605C39E add r2,r1
    c.r[1] += 1;  // 0605C3A0 add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C3A2 mov.b @r1,r7
    c.r[8] = ld32(0x0605C438u);  // 0605C3A4 mov.l 0x0605C438,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605C3A6 mov.b @(r0,r2),r6
    c.r[1] = ld32(0x0605C43Cu);  // 0605C3A8 mov.l 0x0605C43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C3AA mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 0605C3AC extu.b r7,r7
    c.r[0] = c.r[1] & 0xFFu;  // 0605C3AE extu.b r1,r0
    c.r[0] <<= 2;  // 0605C3B0 shll2 r0
    c.r[0] <<= 2;  // 0605C3B2 shll2 r0
    c.r[1] = c.r[0];  // 0605C3B4 mov r0,r1
    c.r[1] += c.r[2];  // 0605C3B6 add r2,r1
    c.r[1] += 1;  // 0605C3B8 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C3BA mov.b @r1,r5
    c.r[6] = c.r[6] & 0xFFu;  // 0605C3BC extu.b r6,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605C3BE mov.b @(r0,r2),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605C3C0 extu.b r5,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0605C3C2 extu.b r4,r4
    c.r[1] = ld32(0x0605C424u);  // 0605C3C4 mov.l 0x0605C424,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605C3C6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605C3C8 mov.l r8,@-r15
    c.r[1] = ld32(0x0605C428u);  // 0605C3CA mov.l 0x0605C428,r1
    { const uint32_t x = c.r[12]; c.pr = 0x0605C3D0u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C3D0u) return; }  // 0605C3CC jsr @r12 ; mov.l r1,@-r15
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C3D0 mov.b @r8,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0605C3D2 extu.b r2,r1
    c.t = c.r[1] == c.r[11];  // 0605C3D4 cmp/eq r11,r1
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_0605C3EA; } }  // 0605C3D6 bt/s 0x0605C3EA ; add #12,r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605C41Eu);  // 0605C3DA mov.w 0x0605C41E,r3
L_0605C3DC:
    st8(c.r[9], c.r[2]);  // 0605C3DC mov.b r2,@r9
    c.r[8] += 1;  // 0605C3DE add #1,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C3E0 mov.b @r8,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0605C3E2 extu.b r2,r1
    c.t = c.r[1] == c.r[3];  // 0605C3E4 cmp/eq r3,r1
    { const bool k = !c.t; c.r[9] += 1; if (k) { SH2_POLL(c); goto L_0605C3DC; } }  // 0605C3E6 bf/s 0x0605C3DC ; add #1,r9
L_0605C3EA:
    c.r[9] += 1;  // 0605C3EA add #1,r9
L_0605C3EC:
    c.r[10] += 1;  // 0605C3EC add #1,r10
    c.r[1] = 0x4u;  // 0605C3EE mov #4,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0605C3F0 cmp/gt r1,r10
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_0605C38A; } }  // 0605C3F2 bf/s 0x0605C38A ; mov r14,r0
L_0605C3F6:
    c.r[2] = ld32(0x0605C440u);  // 0605C3F6 mov.l 0x0605C440,r2
    c.r[1] = ld32(0x0605C43Cu);  // 0605C3F8 mov.l 0x0605C43C,r1
    c.r[13] += c.r[13];  // 0605C3FA add r13,r13
    c.r[13] += 1;  // 0605C3FC add #1,r13
    c.r[14] += 12;  // 0605C3FE add #12,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C400 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0605C402 mov r14,r15
    st8(c.r[2], c.r[1]);  // 0605C404 mov.b r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C420u);  // 0605C406 mov.w 0x0605C420,r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605C408 lds.l @r15+,pr
    c.r[13] |= c.r[1];  // 0605C40A or r1,r13
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605C40C mov.l @r15+,r14
    c.r[0] = c.r[13];  // 0605C40E mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605C410 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605C412 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605C414 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605C416 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605C418 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605C41A rts ; mov.l @r15+,r8
}

void f_0605C444(SH2Context& c) {
    ran[1401] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605C444 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605C446 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605C448 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605C44A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605C44C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605C44E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C450 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605C452 sts.l pr,@-r15
    c.r[15] -= 28;  // 0605C454 add #-28,r15
    c.r[14] = c.r[15];  // 0605C456 mov r15,r14
    c.r[9] = c.r[14];  // 0605C458 mov r14,r9
    c.r[9] += 16;  // 0605C45A add #16,r9
    c.r[8] = ld32(0x0605C550u);  // 0605C45C mov.l 0x0605C550,r8
    c.r[1] = ld32(0x0605C554u);  // 0605C45E mov.l 0x0605C554,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C460 mov.b @r8,r4
    c.r[5] = c.r[9];  // 0605C462 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605C468u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C468u) return; }  // 0605C464 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C468 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C46A extu.b r1,r1
    st32(c.r[14] + 24, c.r[1]);  // 0605C46C mov.l r1,@(24,r14)
    c.r[2] = ld32(c.r[14] + 24);  // 0605C46E mov.l @(24,r14),r2
    c.r[1] = ld32(0x0605C558u);  // 0605C470 mov.l 0x0605C558,r1
    c.r[1] = ld32(c.r[1]);  // 0605C472 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605C474 shll2 r2
    c.r[2] <<= 2;  // 0605C476 shll2 r2
    c.r[2] += c.r[1];  // 0605C478 add r1,r2
    c.r[2] += 7;  // 0605C47A add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C47C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C47E extu.b r1,r1
    c.r[1] >>= 2;  // 0605C480 shlr2 r1
    c.r[1] >>= 2;  // 0605C482 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605C484 shlr r1
    c.r[1] >>= 2;  // 0605C486 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C488 tst r1,r1
    if (!c.t) { goto L_0605C498; }  // 0605C48A bf 0x0605C498
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605C48C mov.b @r9,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C54Cu);  // 0605C48E mov.w 0x0605C54C,r1
    c.r[2] = c.r[5] & 0xFFu;  // 0605C490 extu.b r5,r2
    c.t = c.r[2] == c.r[1];  // 0605C492 cmp/eq r1,r2
    if (c.t) { goto L_0605C498; }  // 0605C494 bt 0x0605C498
    st8(c.r[8], c.r[5]);  // 0605C496 mov.b r5,@r8
L_0605C498:
    c.r[1] = ld32(0x0605C55Cu);  // 0605C498 mov.l 0x0605C55C,r1
    st32(c.r[14] + 8, c.r[1]);  // 0605C49A mov.l r1,@(8,r14)
    c.r[1] = ld32(0x0605C560u);  // 0605C49C mov.l 0x0605C560,r1
    c.r[8] = ld32(0x0605C564u);  // 0605C49E mov.l 0x0605C564,r8
    st32(c.r[14] + 12, c.r[1]); goto L_0605C636;  // 0605C4A0 bra 0x0605C636 ; mov.l r1,@(12,r14)
L_0605C4A4:
    c.r[1] = ld32(0x0605C550u);  // 0605C4A4 mov.l 0x0605C550,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C4A6 mov.b @r1,r1
    c.r[7] = c.r[8];  // 0605C4A8 mov r8,r7
    c.r[0] = c.r[1] & 0xFFu;  // 0605C4AA extu.b r1,r0
    c.r[1] = ld32(0x0605C558u);  // 0605C4AC mov.l 0x0605C558,r1
    c.r[0] <<= 2;  // 0605C4AE shll2 r0
    c.r[0] <<= 2;  // 0605C4B0 shll2 r0
    c.r[1] = ld32(c.r[1]);  // 0605C4B2 mov.l @r1,r1
    c.r[2] = c.r[0];  // 0605C4B4 mov r0,r2
    c.r[2] += c.r[1];  // 0605C4B6 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605C4B8 mov.b @(r0,r1),r1
    c.r[2] += 1;  // 0605C4BA add #1,r2
    c.r[11] = c.r[1] & 0xFFu;  // 0605C4BC extu.b r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C4BE mov.b @r2,r1
    c.r[7] += 1;  // 0605C4C0 add #1,r7
    c.r[10] = c.r[1] & 0xFFu;  // 0605C4C2 extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605C4C4 mov.b @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605C54Eu);  // 0605C4C6 mov.w 0x0605C54E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C4C8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605C4CA cmp/eq r2,r1
    if (!c.t) { goto L_0605C4D2; }  // 0605C4CC bf 0x0605C4D2
    goto L_0605C634;  // 0605C4CE bra 0x0605C634 ; nop
L_0605C4D2:
    c.r[9] = c.r[7];  // 0605C4D2 mov r7,r9
    c.r[12] = ld32(0x0605C568u);  // 0605C4D4 mov.l 0x0605C568,r12
L_0605C4D6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C4D6 mov.b @r8,r0
    c.r[3] = 0x8u;  // 0605C4D8 mov #8,r3
    c.r[1] = 0x4u;  // 0605C4DA mov #4,r1
    c.r[6] = 0x2u;  // 0605C4DC mov #2,r6
    c.r[5] = 0x0u;  // 0605C4DE mov #0,r5
    c.r[3] &= c.r[0];  // 0605C4E0 and r0,r3
    c.r[2] = c.r[3];  // 0605C4E2 mov r3,r2
    c.r[2] >>= 2;  // 0605C4E4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605C4E6 shlr r2
    c.r[1] &= c.r[0];  // 0605C4E8 and r0,r1
    c.r[1] >>= 2;  // 0605C4EA shlr2 r1
    c.r[2] -= c.r[1];  // 0605C4EC sub r1,r2
    c.r[2] += c.r[11];  // 0605C4EE add r11,r2
    c.r[11] = c.r[2] & 0xFFu;  // 0605C4F0 extu.b r2,r11
    c.r[1] = 0x2u;  // 0605C4F2 mov #2,r1
    c.r[1] &= c.r[0];  // 0605C4F4 and r0,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605C4F6 shlr r1
    c.r[0] &= 0x1u;  // 0605C4F8 and #1,r0
    c.r[1] -= c.r[0];  // 0605C4FA sub r0,r1
    c.r[1] += c.r[10];  // 0605C4FC add r10,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0605C4FE extu.b r1,r10
    c.t = (c.r[3] & c.r[3]) == 0;  // 0605C500 tst r3,r3
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_0605C520; } }  // 0605C502 bt/s 0x0605C520 ; mov r7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605C506 mov.b @r7,r0
    c.r[1] = 0x2u;  // 0605C508 mov #2,r1
    c.r[1] &= c.r[0];  // 0605C50A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C50C tst r1,r1
    { const bool k = c.t; c.r[0] &= 0x1u; if (k) { goto L_0605C516; } }  // 0605C50E bt/s 0x0605C516 ; and #1,r0
    c.r[6] = 0x3u; goto L_0605C520;  // 0605C512 bra 0x0605C520 ; mov #3,r6
L_0605C516:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C516 tst r0,r0
    { const bool k = c.t; c.r[6] = 0x5u; if (k) { goto L_0605C520; } }  // 0605C518 bt/s 0x0605C520 ; mov #5,r6
    c.r[5] = 0x22u;  // 0605C51C mov #34,r5
    c.r[6] = 0x3u;  // 0605C51E mov #3,r6
L_0605C520:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C520 mov.b @r8,r0
    c.r[0] &= 0x4u;  // 0605C522 and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C524 tst r0,r0
    if (c.t) { goto L_0605C572; }  // 0605C526 bt 0x0605C572
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C528 mov.b @r2,r0
    c.r[1] = 0x2u;  // 0605C52A mov #2,r1
    c.r[1] &= c.r[0];  // 0605C52C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C52E tst r1,r1
    { const bool k = c.t; c.r[0] &= 0x1u; if (k) { goto L_0605C53E; } }  // 0605C530 bt/s 0x0605C53E ; and #1,r0
    c.r[13] = 0x12u;  // 0605C534 mov #18,r13
    c.r[5] |= c.r[13];  // 0605C536 or r13,r5
    c.r[1] = c.r[6];  // 0605C538 mov r6,r1
    c.r[1] += 1; goto L_0605C570;  // 0605C53A bra 0x0605C570 ; add #1,r1
L_0605C53E:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C53E tst r0,r0
    { const bool k = c.t; c.r[13] = 0x32u; if (k) { goto L_0605C56C; } }  // 0605C540 bt/s 0x0605C56C ; mov #50,r13
    c.r[5] |= c.r[13];  // 0605C544 or r13,r5
    c.r[1] = c.r[6];  // 0605C546 mov r6,r1
    c.r[1] += 1; goto L_0605C570;  // 0605C548 bra 0x0605C570 ; add #1,r1
L_0605C56C:
    c.r[1] = c.r[6];  // 0605C56C mov r6,r1
    c.r[1] += 3;  // 0605C56E add #3,r1
L_0605C570:
    c.r[6] = c.r[1] & 0xFFFFu;  // 0605C570 extu.w r1,r6
L_0605C572:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C572 mov.b @r8,r0
    c.r[0] &= 0x2u;  // 0605C574 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C576 tst r0,r0
    if (c.t) { goto L_0605C59E; }  // 0605C578 bt 0x0605C59E
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C57A mov.b @r2,r0
    c.r[1] = 0x8u;  // 0605C57C mov #8,r1
    c.r[1] &= c.r[0];  // 0605C57E and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C580 tst r1,r1
    { const bool k = c.t; c.r[13] = 0x32u; if (k) { goto L_0605C58E; } }  // 0605C582 bt/s 0x0605C58E ; mov #50,r13
    c.r[5] |= c.r[13];  // 0605C586 or r13,r5
    c.r[1] = c.r[6];  // 0605C588 mov r6,r1
    c.r[1] += 1;  // 0605C58A add #1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0605C58C extu.w r1,r6
L_0605C58E:
    c.r[0] &= 0x4u;  // 0605C58E and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C590 tst r0,r0
    if (c.t) { goto L_0605C59E; }  // 0605C592 bt 0x0605C59E
    c.r[13] = 0x22u;  // 0605C594 mov #34,r13
    c.r[5] |= c.r[13];  // 0605C596 or r13,r5
    c.r[1] = c.r[6];  // 0605C598 mov r6,r1
    c.r[1] += 1;  // 0605C59A add #1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0605C59C extu.w r1,r6
L_0605C59E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C59E mov.b @r8,r0
    c.r[0] &= 0x1u;  // 0605C5A0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C5A2 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0605C5CC; } }  // 0605C5A4 bt/s 0x0605C5CC ; mov r12,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C5A8 mov.b @r2,r0
    c.r[1] = 0x8u;  // 0605C5AA mov #8,r1
    c.r[1] &= c.r[0];  // 0605C5AC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C5AE tst r1,r1
    { const bool k = c.t; c.r[13] = 0x12u; if (k) { goto L_0605C5BC; } }  // 0605C5B0 bt/s 0x0605C5BC ; mov #18,r13
    c.r[5] |= c.r[13];  // 0605C5B4 or r13,r5
    c.r[1] = c.r[6];  // 0605C5B6 mov r6,r1
    c.r[1] += 1;  // 0605C5B8 add #1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0605C5BA extu.w r1,r6
L_0605C5BC:
    c.r[0] &= 0x4u;  // 0605C5BC and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C5BE tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0605C5CC; } }  // 0605C5C0 bt/s 0x0605C5CC ; mov r12,r1
    c.r[1] = c.r[6];  // 0605C5C4 mov r6,r1
    c.r[1] += 1;  // 0605C5C6 add #1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0605C5C8 extu.w r1,r6
    c.r[1] = c.r[12];  // 0605C5CA mov r12,r1
L_0605C5CC:
    c.r[1] += 78;  // 0605C5CC add #78,r1
    c.r[2] = c.r[11];  // 0605C5CE mov r11,r2
    c.r[13] = ld32(0x0605C680u);  // 0605C5D0 mov.l 0x0605C680,r13
    c.r[7] = ld32(0x0605C684u);  // 0605C5D2 mov.l 0x0605C684,r7
    c.r[3] = c.r[6];  // 0605C5D4 mov r6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C5D6 mov.b @r1,r1
    c.r[0] = ld32(0x0605C688u);  // 0605C5D8 mov.l 0x0605C688,r0
    c.r[2] -= c.r[1];  // 0605C5DA sub r1,r2
    c.r[2] <<= 2;  // 0605C5DC shll2 r2
    c.r[2] <<= 2;  // 0605C5DE shll2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C676u);  // 0605C5E0 mov.w 0x0605C676,r1
    c.r[2] += c.r[1];  // 0605C5E2 add r1,r2
    c.r[2] <<= 16;  // 0605C5E4 shll16 r2
    st32(c.r[14], c.r[2]);  // 0605C5E6 mov.l r2,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0605C5E8 mov.b @r13,r1
    c.r[4] = c.r[14];  // 0605C5EA mov r14,r4
    c.r[13] = c.r[10];  // 0605C5EC mov r10,r13
    c.r[13] -= c.r[1];  // 0605C5EE sub r1,r13
    c.r[1] = c.r[13];  // 0605C5F0 mov r13,r1
    c.r[1] <<= 2;  // 0605C5F2 shll2 r1
    c.r[1] <<= 2;  // 0605C5F4 shll2 r1
    c.r[1] -= 105;  // 0605C5F6 add #-105,r1
    c.r[1] <<= 16;  // 0605C5F8 shll16 r1
    st32(c.r[14] + 4, c.r[1]);  // 0605C5FA mov.l r1,@(4,r14)
    c.r[3] <<= 2;  // 0605C5FC shll2 r3
    c.r[3] += c.r[6];  // 0605C5FE add r6,r3
    c.r[1] = ld32(c.r[7] + 8);  // 0605C600 mov.l @(8,r7),r1
    c.r[3] += c.r[3];  // 0605C602 add r3,r3
    c.r[3] += c.r[1];  // 0605C604 add r1,r3
    c.r[3] += 8;  // 0605C606 add #8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605C608 mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605C678u);  // 0605C60A mov.w 0x0605C678,r2
    c.r[1] &= c.r[2];  // 0605C60C and r2,r1
    c.r[5] |= c.r[1];  // 0605C60E or r1,r5
    st16(c.r[3], c.r[5]);  // 0605C610 mov.w r5,@r3
    c.r[1] = 0xAu;  // 0605C612 mov #10,r1
    c.macl = (c.r[6] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0605C614 mulu.w r1,r6
    c.r[5] = ld32(c.r[7] + 8);  // 0605C616 mov.l @(8,r7),r5
    c.r[1] = c.macl;  // 0605C618 sts macl,r1
    c.r[5] += c.r[1];  // 0605C61A add r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0605C620u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C620u) return; }  // 0605C61C jsr @r0 ; mov #0,r6
    c.r[9] += 1;  // 0605C620 add #1,r9
    c.r[8] += 1;  // 0605C622 add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605C624 mov.b @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605C67Au);  // 0605C626 mov.w 0x0605C67A,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C628 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605C62A cmp/eq r2,r1
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_0605C634; } }  // 0605C62C bt/s 0x0605C634 ; mov r9,r7
    SH2_POLL(c); goto L_0605C4D6;  // 0605C630 bra 0x0605C4D6 ; nop
L_0605C634:
    c.r[8] += 2;  // 0605C634 add #2,r8
L_0605C636:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C636 mov.b @r8,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605C638 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C67Au);  // 0605C63A mov.w 0x0605C67A,r1
    c.t = c.r[2] == c.r[1];  // 0605C63C cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0605C646; } }  // 0605C63E bt/s 0x0605C646 ; mov r8,r1
    SH2_POLL(c); goto L_0605C4A4;  // 0605C642 bra 0x0605C4A4 ; nop
L_0605C646:
    c.r[1] += 1;  // 0605C646 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C648 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C64A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605C64C cmp/eq r2,r1
    { const bool k = c.t; c.r[13] = 0x1Bu; if (k) { goto L_0605C656; } }  // 0605C64E bt/s 0x0605C656 ; mov #27,r13
    SH2_POLL(c); goto L_0605C4A4;  // 0605C652 bra 0x0605C4A4 ; nop
L_0605C656:
    c.r[1] = ld32(0x0605C68Cu);  // 0605C656 mov.l 0x0605C68C,r1
    c.r[13] += c.r[14];  // 0605C658 add r14,r13
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0605C65A mov.b @r13,r13
    st8(c.r[1], c.r[13]);  // 0605C65C mov.b r13,@r1
    c.r[14] += 28;  // 0605C65E add #28,r14
    c.r[15] = c.r[14];  // 0605C660 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605C662 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605C664 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605C666 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605C668 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605C66A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605C66C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605C66E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C67Cu);  // 0605C670 mov.w 0x0605C67C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605C672 rts ; mov.l @r15+,r8
}

void f_0605C690(SH2Context& c) {
    ran[1402] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C690 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605C692 sts.l pr,@-r15
    c.r[1] = ld32(0x0605C6B0u);  // 0605C694 mov.l 0x0605C6B0,r1
    c.r[1] = ld32(c.r[1]);  // 0605C696 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C698 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605C69A extu.b r1,r0
    c.r[0] <<= 2;  // 0605C69C shll2 r0
    c.r[1] = ld32(0x0605C6B4u);  // 0605C69E mov.l 0x0605C6B4,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605C6A0 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605C6A6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C6A6u) return; }  // 0605C6A2 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605C6A6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605C6A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605C6AA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605C6AC rts ; extu.w r0,r0
}

void f_0605C6B8(SH2Context& c) {
    ran[1403] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C6B8 mov.l r14,@-r15
    c.r[6] = ld32(0x0605C6F8u);  // 0605C6BA mov.l 0x0605C6F8,r6
    c.r[3] = c.r[6];  // 0605C6BC mov r6,r3
    c.r[3] += 122;  // 0605C6BE add #122,r3
    c.r[2] = c.r[6];  // 0605C6C0 mov r6,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605C6C2 mov.b @r3,r0
    c.r[2] += 118;  // 0605C6C4 add #118,r2
    c.r[0] &= 0x7Fu;  // 0605C6C6 and #127,r0
    st8(c.r[3], c.r[0]);  // 0605C6C8 mov.b r0,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C6CA mov.b @r2,r0
    c.r[14] = c.r[15];  // 0605C6CC mov r15,r14
    c.r[0] &= 0x7Fu;  // 0605C6CE and #127,r0
    st8(c.r[2], c.r[0]);  // 0605C6D0 mov.b r0,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605C6D2 mov.w @r3,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605C6F2u);  // 0605C6D4 mov.w 0x0605C6F2,r7
    c.r[1] &= c.r[7];  // 0605C6D6 and r7,r1
    st16(c.r[3], c.r[1]);  // 0605C6D8 mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0605C6DA mov.w @r2,r1
    c.r[1] &= c.r[7];  // 0605C6DC and r7,r1
    st16(c.r[2], c.r[1]);  // 0605C6DE mov.w r1,@r2
    c.r[2] = c.r[6];  // 0605C6E0 mov r6,r2
    c.r[2] += 126;  // 0605C6E2 add #126,r2
    c.r[6] += 127;  // 0605C6E4 add #127,r6
    c.r[1] = 0x2u;  // 0605C6E6 mov #2,r1
    st8(c.r[6], c.r[1]);  // 0605C6E8 mov.b r1,@r6
    st8(c.r[2], c.r[1]);  // 0605C6EA mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C6F4u);  // 0605C6EC mov.w 0x0605C6F4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605C6EE rts ; mov.l @r15+,r14
}

void f_0605C6FC(SH2Context& c) {
    ran[1404] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605C6FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605C6FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605C700 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605C702 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605C704 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C706 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605C708 sts.l pr,@-r15
    c.r[1] = ld32(0x0605C7E4u);  // 0605C70A mov.l 0x0605C7E4,r1
    c.r[1] = ld32(c.r[1]);  // 0605C70C mov.l @r1,r1
    c.r[4] = c.r[1];  // 0605C70E mov r1,r4
    c.r[4] += 1;  // 0605C710 add #1,r4
    c.r[3] = c.r[1];  // 0605C712 mov r1,r3
    c.r[3] += 2;  // 0605C714 add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0605C716 mov.b @r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605C718 mov.b @r3,r2
    c.r[1] |= c.r[2];  // 0605C71A or r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C71C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C71E tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605C72A; } }  // 0605C720 bt/s 0x0605C72A ; mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0605C724 mov.b @r4,r4
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_0605C756;  // 0605C726 bra 0x0605C756 ; mov.b @r3,r11
L_0605C72A:
    c.r[7] = ld32(0x0605C7E8u);  // 0605C72A mov.l 0x0605C7E8,r7
    c.r[1] = c.r[7];  // 0605C72C mov r7,r1
    c.r[1] += 116;  // 0605C72E add #116,r1
    c.r[3] = c.r[7];  // 0605C730 mov r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C732 mov.b @r1,r2
    c.r[3] += 78;  // 0605C734 add #78,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605C736 mov.b @r3,r1
    c.r[6] = ld32(0x0605C7ECu);  // 0605C738 mov.l 0x0605C7EC,r6
    c.r[2] += c.r[1];  // 0605C73A add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605C73C mov.b @r6,r1
    c.r[1] -= c.r[2];  // 0605C73E sub r2,r1
    c.r[4] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0605C740 exts.b r1,r4
    c.r[1] = c.r[7];  // 0605C742 mov r7,r1
    c.r[1] += 117;  // 0605C744 add #117,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C746 mov.b @r1,r2
    c.r[7] += 79;  // 0605C748 add #79,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605C74A mov.b @r7,r1
    c.r[3] = ld32(0x0605C7F0u);  // 0605C74C mov.l 0x0605C7F0,r3
    c.r[2] += c.r[1];  // 0605C74E add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605C750 mov.b @r3,r1
    c.r[1] -= c.r[2];  // 0605C752 sub r2,r1
    c.r[11] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0605C754 exts.b r1,r11
L_0605C756:
    c.r[7] = ld32(0x0605C7E8u);  // 0605C756 mov.l 0x0605C7E8,r7
    c.r[8] = c.r[7];  // 0605C758 mov r7,r8
    c.r[8] += 122;  // 0605C75A add #122,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C7E0u);  // 0605C75C mov.w 0x0605C7E0,r1
    c.r[6] = c.r[7];  // 0605C75E mov r7,r6
    c.r[6] += 118;  // 0605C760 add #118,r6
    c.r[4] <<= 2;  // 0605C762 shll2 r4
    c.r[4] <<= 2;  // 0605C764 shll2 r4
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605C766 mov.b @r8,r12
    c.r[9] = ld32(0x0605C7F4u);  // 0605C768 mov.l 0x0605C7F4,r9
    c.r[1] &= c.r[12];  // 0605C76A and r12,r1
    st8(c.r[8], c.r[1]);  // 0605C76C mov.b r1,@r8
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605C76E mov.b @r6,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C7E0u);  // 0605C770 mov.w 0x0605C7E0,r1
    c.r[1] &= c.r[10];  // 0605C772 and r10,r1
    st8(c.r[6], c.r[1]);  // 0605C774 mov.b r1,@r6
    c.r[1] = c.r[7];  // 0605C776 mov r7,r1
    c.r[1] += 126;  // 0605C778 add #126,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C77A mov.b @r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605C780u; c.r[15] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C780u) return; }  // 0605C77C jsr @r9 ; mov r14,r15
    c.r[5] = c.r[0];  // 0605C780 mov r0,r5
    c.r[0] = ld32(0x0605C7F8u);  // 0605C782 mov.l 0x0605C7F8,r0
    st16(c.r[0], c.r[5]);  // 0605C784 mov.w r5,@r0
    c.r[1] = c.r[5];  // 0605C786 mov r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C788 tst r1,r1
    c.r[1] = c.t;  // 0605C78A movt r1
    c.r[0] = 0x1u;  // 0605C78C mov #1,r0
    c.r[1] ^= c.r[0];  // 0605C78E xor r0,r1
    c.r[1] <<= 2;  // 0605C790 shll2 r1
    c.r[1] <<= 2;  // 0605C792 shll2 r1
    c.r[1] += c.r[1];  // 0605C794 add r1,r1
    c.r[1] <<= 2;  // 0605C796 shll2 r1
    c.r[2] = 0x3Fu;  // 0605C798 mov #63,r2
    c.r[2] &= c.r[10];  // 0605C79A and r10,r2
    c.r[2] |= c.r[1];  // 0605C79C or r1,r2
    st8(c.r[6], c.r[2]);  // 0605C79E mov.b r2,@r6
    c.r[6] = c.r[7];  // 0605C7A0 mov r7,r6
    c.r[6] += 124;  // 0605C7A2 add #124,r6
    c.r[11] <<= 2;  // 0605C7A4 shll2 r11
    c.r[11] <<= 2;  // 0605C7A6 shll2 r11
    c.r[7] += 127;  // 0605C7A8 add #127,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605C7AA mov.b @r7,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605C7B0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605C7B0u) return; }  // 0605C7AC jsr @r9 ; mov r11,r4
    c.r[7] = c.r[0];  // 0605C7B0 mov r0,r7
    st16(c.r[6], c.r[7]);  // 0605C7B2 mov.w r7,@r6
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0605C7B4 exts.w r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605C7B6 tst r1,r1
    c.r[1] = c.t;  // 0605C7B8 movt r1
    c.r[0] = 0x1u;  // 0605C7BA mov #1,r0
    c.r[1] ^= c.r[0];  // 0605C7BC xor r0,r1
    c.r[1] <<= 2;  // 0605C7BE shll2 r1
    c.r[1] <<= 2;  // 0605C7C0 shll2 r1
    c.r[1] += c.r[1];  // 0605C7C2 add r1,r1
    c.r[1] <<= 2;  // 0605C7C4 shll2 r1
    c.r[2] = 0x3Fu;  // 0605C7C6 mov #63,r2
    c.r[2] &= c.r[12];  // 0605C7C8 and r12,r2
    c.r[2] |= c.r[1];  // 0605C7CA or r1,r2
    st8(c.r[8], c.r[2]);  // 0605C7CC mov.b r2,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605C7CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605C7D0 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605C7D2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605C7D4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605C7D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605C7D8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C7E2u);  // 0605C7DA mov.w 0x0605C7E2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605C7DC rts ; mov.l @r15+,r8
}

void f_0605C7FC(SH2Context& c) {
    ran[1405] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C7FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605C7FE mov r15,r14
    c.r[1] = ld32(0x0605C820u);  // 0605C800 mov.l 0x0605C820,r1
    c.r[7] = ld32(0x0605C824u);  // 0605C802 mov.l 0x0605C824,r7
    c.r[3] = c.r[7];  // 0605C804 mov r7,r3
    c.r[2] = ld32(c.r[1]);  // 0605C806 mov.l @r1,r2
    c.r[3] += 126;  // 0605C808 add #126,r3
    c.r[2] += 1;  // 0605C80A add #1,r2
    st32(c.r[1], c.r[2]);  // 0605C80C mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0605C80E mov.b @r2+,r1
    c.r[7] += 127;  // 0605C810 add #127,r7
    st8(c.r[3], c.r[1]);  // 0605C812 mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605C814 mov.b @r2,r1
    st8(c.r[7], c.r[1]);  // 0605C816 mov.b r1,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C81Eu);  // 0605C818 mov.w 0x0605C81E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605C81A rts ; mov.l @r15+,r14
}

void f_0605C828(SH2Context& c) {
    ran[1406] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605C828 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605C82A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605C82C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605C82E sts.l pr,@-r15
    c.r[6] = ld32(0x0605C94Cu);  // 0605C830 mov.l 0x0605C94C,r6
    c.r[8] = c.r[6];  // 0605C832 mov r6,r8
    c.r[8] += 120;  // 0605C834 add #120,r8
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605C836 mov.w @r8,r7
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0605C838 exts.w r7,r1
    c.t = (int32_t)c.r[1] > 0;  // 0605C83A cmp/pl r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605C8EC; } }  // 0605C83C bf/s 0x0605C8EC ; mov r15,r14
    c.r[9] = c.r[6];  // 0605C840 mov r6,r9
    c.r[9] += 116;  // 0605C842 add #116,r9
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605C844 mov.b @r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C944u);  // 0605C846 mov.w 0x0605C944,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0605C848 mov.b @(r0,r6),r0
    c.r[3] = c.r[4] & 0xFFu;  // 0605C84A extu.b r4,r3
    c.r[0] &= 0xFu;  // 0605C84C and #15,r0
    c.r[1] = 0u - c.r[0];  // 0605C84E neg r0,r1
    c.r[1] += 19;  // 0605C850 add #19,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0605C852 cmp/ge r1,r3
    if (!c.t) { goto L_0605C890; }  // 0605C854 bf 0x0605C890
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605C856 mov.b @r6,r1
    c.r[0] = c.r[1];  // 0605C858 mov r1,r0
    c.r[0] >>= 2;  // 0605C85A shlr2 r0
    c.r[0] >>= 2;  // 0605C85C shlr2 r0
    c.r[0] >>= 2;  // 0605C85E shlr2 r0
    c.r[0] &= 0x1u;  // 0605C860 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C862 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605C884; } }  // 0605C864 bt/s 0x0605C884 ; mov r6,r1
    c.r[1] += 78;  // 0605C868 add #78,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C86A mov.b @r1,r2
    c.r[1] = c.r[6];  // 0605C86C mov r6,r1
    c.r[1] += 76;  // 0605C86E add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C870 mov.b @r1,r1
    c.r[2] += c.r[3];  // 0605C872 add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C874 extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0605C876 cmp/ge r1,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605C884; } }  // 0605C878 bt/s 0x0605C884 ; mov r6,r1
    c.r[1] += 118;  // 0605C87C add #118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C87E mov.b @r1,r0
    c.r[0] |= 0x40u; goto L_0605C9B2;  // 0605C880 bra 0x0605C9B2 ; or #64,r0
L_0605C884:
    c.r[1] = ld32(0x0605C94Cu);  // 0605C884 mov.l 0x0605C94C,r1
    c.r[3] = c.r[1];  // 0605C886 mov r1,r3
    c.r[3] += 120;  // 0605C888 add #120,r3
    c.r[2] = 0x0u;  // 0605C88A mov #0,r2
    st16(c.r[3], c.r[2]); goto L_0605C9AC;  // 0605C88C bra 0x0605C9AC ; mov.w r2,@r3
L_0605C890:
    c.r[1] = c.r[6];  // 0605C890 mov r6,r1
    c.r[1] += 78;  // 0605C892 add #78,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C894 mov.b @r1,r2
    c.r[1] = c.r[6];  // 0605C896 mov r6,r1
    c.r[1] += 76;  // 0605C898 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C89A mov.b @r1,r1
    c.r[2] += c.r[3];  // 0605C89C add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C89E extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0605C8A0 cmp/ge r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0605C8AA; } }  // 0605C8A2 bf/s 0x0605C8AA ; mov #0,r1
    goto L_0605C9A8;  // 0605C8A6 bra 0x0605C9A8 ; nop
L_0605C8AA:
    c.r[3] = c.r[6];  // 0605C8AA mov r6,r3
    c.r[5] = c.r[6];  // 0605C8AC mov r6,r5
    c.r[5] += 126;  // 0605C8AE add #126,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605C8B0 mov.b @r5,r2
    c.r[3] += 108;  // 0605C8B2 add #108,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605C8B4 mov.w @r3,r1
    c.r[6] += 118;  // 0605C8B6 add #118,r6
    c.r[1] += c.r[2];  // 0605C8B8 add r2,r1
    st16(c.r[3], c.r[1]);  // 0605C8BA mov.w r1,@r3
    c.r[1] = c.r[7];  // 0605C8BC mov r7,r1
    c.r[1] -= 1;  // 0605C8BE add #-1,r1
    st16(c.r[8], c.r[1]);  // 0605C8C0 mov.w r1,@r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605C946u);  // 0605C8C2 mov.w 0x0605C946,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605C8C4 mov.w @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605C948u);  // 0605C8C6 mov.w 0x0605C948,r1
    c.r[7] = c.r[2];  // 0605C8C8 mov r2,r7
    c.r[7] &= c.r[3];  // 0605C8CA and r3,r7
    c.r[7] += 1;  // 0605C8CC add #1,r7
    c.r[7] &= c.r[3];  // 0605C8CE and r3,r7
    c.r[2] &= c.r[1];  // 0605C8D0 and r1,r2
    c.r[2] |= c.r[7];  // 0605C8D2 or r7,r2
    st16(c.r[6], c.r[2]);  // 0605C8D4 mov.w r2,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605C8D6 mov.b @r5,r1
    c.r[2] &= c.r[3];  // 0605C8D8 and r3,r2
    c.macl = c.r[2] * c.r[1];  // 0605C8DA mul.l r1,r2
    c.r[0] = c.macl;  // 0605C8DC sts macl,r0
    c.r[0] &= 0xFu;  // 0605C8DE and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C8E0 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_0605C9B4; } }  // 0605C8E2 bf/s 0x0605C9B4 ; mov r4,r1
    c.r[1] += 1;  // 0605C8E6 add #1,r1
    st8(c.r[9], c.r[1]); goto L_0605C9B4;  // 0605C8E8 bra 0x0605C9B4 ; mov.b r1,@r9
L_0605C8EC:
    c.t = (int32_t)c.r[1] >= 0;  // 0605C8EC cmp/pz r1
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_0605C9B4; } }  // 0605C8EE bt/s 0x0605C9B4 ; mov r6,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605C944u);  // 0605C8F2 mov.w 0x0605C944,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0605C8F4 mov.b @(r0,r6),r1
    c.r[9] += 116;  // 0605C8F6 add #116,r9
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605C8F8 mov.b @r9,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0605C8FA extu.b r1,r1
    c.r[2] = c.r[4] & 0xFFu;  // 0605C8FC extu.b r4,r2
    c.r[1] >>= 2;  // 0605C8FE shlr2 r1
    c.r[1] >>= 2;  // 0605C900 shlr2 r1
    c.t = c.r[2] > c.r[1];  // 0605C902 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605C950; } }  // 0605C904 bt/s 0x0605C950 ; mov r6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605C908 mov.b @r6,r1
    c.r[0] = c.r[1];  // 0605C90A mov r1,r0
    c.r[0] >>= 2;  // 0605C90C shlr2 r0
    c.r[0] >>= 2;  // 0605C90E shlr2 r0
    c.r[0] >>= 2;  // 0605C910 shlr2 r0
    c.r[0] &= 0x1u;  // 0605C912 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C914 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605C938; } }  // 0605C916 bt/s 0x0605C938 ; mov r6,r1
    c.r[1] += 78;  // 0605C91A add #78,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C91C mov.b @r1,r2
    c.r[1] = c.r[4] & 0xFFu;  // 0605C91E extu.b r4,r1
    c.r[2] += c.r[1];  // 0605C920 add r1,r2
    c.r[1] = c.r[6];  // 0605C922 mov r6,r1
    c.r[1] += 74;  // 0605C924 add #74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C926 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C928 extu.b r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0605C92A cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0605C938; } }  // 0605C92C bf/s 0x0605C938 ; mov r6,r1
    c.r[1] += 118;  // 0605C930 add #118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C932 mov.b @r1,r0
    c.r[0] |= 0x40u; goto L_0605C9B2;  // 0605C934 bra 0x0605C9B2 ; or #64,r0
L_0605C938:
    c.r[1] = ld32(0x0605C94Cu);  // 0605C938 mov.l 0x0605C94C,r1
    c.r[3] = c.r[1];  // 0605C93A mov r1,r3
    c.r[3] += 120;  // 0605C93C add #120,r3
    c.r[2] = 0x0u;  // 0605C93E mov #0,r2
    st16(c.r[3], c.r[2]); goto L_0605C9AC;  // 0605C940 bra 0x0605C9AC ; mov.w r2,@r3
L_0605C950:
    c.r[1] += 78;  // 0605C950 add #78,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C952 mov.b @r1,r2
    c.r[1] = c.r[4] & 0xFFu;  // 0605C954 extu.b r4,r1
    c.r[2] += c.r[1];  // 0605C956 add r1,r2
    c.r[1] = c.r[6];  // 0605C958 mov r6,r1
    c.r[1] += 74;  // 0605C95A add #74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C95C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605C95E extu.b r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0605C960 cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] = c.r[6]; if (k) { goto L_0605C9A6; } }  // 0605C962 bf/s 0x0605C9A6 ; mov r6,r3
    c.r[5] = c.r[6];  // 0605C966 mov r6,r5
    c.r[5] += 126;  // 0605C968 add #126,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605C96A mov.b @r5,r2
    c.r[3] += 108;  // 0605C96C add #108,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605C96E mov.w @r3,r1
    c.r[6] += 118;  // 0605C970 add #118,r6
    c.r[1] -= c.r[2];  // 0605C972 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0605C974 mov.w r1,@r3
    c.r[1] = c.r[7];  // 0605C976 mov r7,r1
    c.r[1] += 1;  // 0605C978 add #1,r1
    st16(c.r[8], c.r[1]);  // 0605C97A mov.w r1,@r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CA6Au);  // 0605C97C mov.w 0x0605CA6A,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605C97E mov.w @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CA6Cu);  // 0605C980 mov.w 0x0605CA6C,r1
    c.r[7] = c.r[2];  // 0605C982 mov r2,r7
    c.r[7] &= c.r[3];  // 0605C984 and r3,r7
    c.r[7] += 1;  // 0605C986 add #1,r7
    c.r[7] &= c.r[3];  // 0605C988 and r3,r7
    c.r[2] &= c.r[1];  // 0605C98A and r1,r2
    c.r[2] |= c.r[7];  // 0605C98C or r7,r2
    st16(c.r[6], c.r[2]);  // 0605C98E mov.w r2,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605C990 mov.b @r5,r1
    c.r[2] &= c.r[3];  // 0605C992 and r3,r2
    c.macl = c.r[2] * c.r[1];  // 0605C994 mul.l r1,r2
    c.r[0] = c.macl;  // 0605C996 sts macl,r0
    c.r[0] &= 0xFu;  // 0605C998 and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C99A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_0605C9B4; } }  // 0605C99C bf/s 0x0605C9B4 ; mov r4,r1
    c.r[1] -= 1;  // 0605C9A0 add #-1,r1
    st8(c.r[9], c.r[1]); goto L_0605C9B4;  // 0605C9A2 bra 0x0605C9B4 ; mov.b r1,@r9
L_0605C9A6:
    c.r[1] = 0x0u;  // 0605C9A6 mov #0,r1
L_0605C9A8:
    st16(c.r[8], c.r[1]);  // 0605C9A8 mov.w r1,@r8
    c.r[1] = c.r[6];  // 0605C9AA mov r6,r1
L_0605C9AC:
    c.r[1] += 118;  // 0605C9AC add #118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C9AE mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 0605C9B0 and #191,r0
L_0605C9B2:
    st8(c.r[1], c.r[0]);  // 0605C9B2 mov.b r0,@r1
L_0605C9B4:
    c.r[6] = ld32(0x0605CA70u);  // 0605C9B4 mov.l 0x0605CA70,r6
    c.r[8] = c.r[6];  // 0605C9B6 mov r6,r8
    c.r[8] += 124;  // 0605C9B8 add #124,r8
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0605C9BA mov.w @r8,r7
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0605C9BC exts.w r7,r1
    c.t = (int32_t)c.r[1] > 0;  // 0605C9BE cmp/pl r1
    { const bool k = !c.t; c.r[9] = c.r[6]; if (k) { goto L_0605CA74; } }  // 0605C9C0 bf/s 0x0605CA74 ; mov r6,r9
    c.r[9] += 117;  // 0605C9C4 add #117,r9
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605C9C6 mov.b @r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CA6Eu);  // 0605C9C8 mov.w 0x0605CA6E,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0605C9CA mov.b @(r0,r6),r0
    c.r[3] = c.r[4] & 0xFFu;  // 0605C9CC extu.b r4,r3
    c.r[0] &= 0xFu;  // 0605C9CE and #15,r0
    c.r[1] = 0u - c.r[0];  // 0605C9D0 neg r0,r1
    c.r[1] += 13;  // 0605C9D2 add #13,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0605C9D4 cmp/ge r1,r3
    if (!c.t) { goto L_0605CA12; }  // 0605C9D6 bf 0x0605CA12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605C9D8 mov.b @r6,r1
    c.r[0] = c.r[1];  // 0605C9DA mov r1,r0
    c.r[0] >>= 2;  // 0605C9DC shlr2 r0
    c.r[0] >>= 2;  // 0605C9DE shlr2 r0
    c.r[0] >>= 2;  // 0605C9E0 shlr2 r0
    c.r[0] &= 0x1u;  // 0605C9E2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605C9E4 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605CA06; } }  // 0605C9E6 bt/s 0x0605CA06 ; mov r6,r1
    c.r[1] += 79;  // 0605C9EA add #79,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C9EC mov.b @r1,r2
    c.r[1] = c.r[6];  // 0605C9EE mov r6,r1
    c.r[1] += 77;  // 0605C9F0 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605C9F2 mov.b @r1,r1
    c.r[2] += c.r[3];  // 0605C9F4 add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605C9F6 extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0605C9F8 cmp/ge r1,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605CA06; } }  // 0605C9FA bt/s 0x0605CA06 ; mov r6,r1
    c.r[1] += 122;  // 0605C9FE add #122,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CA00 mov.b @r1,r0
    c.r[0] |= 0x40u; goto L_0605CB2C;  // 0605CA02 bra 0x0605CB2C ; or #64,r0
L_0605CA06:
    c.r[1] = ld32(0x0605CA70u);  // 0605CA06 mov.l 0x0605CA70,r1
    c.r[3] = c.r[1];  // 0605CA08 mov r1,r3
    c.r[3] += 124;  // 0605CA0A add #124,r3
    c.r[2] = 0x0u;  // 0605CA0C mov #0,r2
    st16(c.r[3], c.r[2]); goto L_0605CB26;  // 0605CA0E bra 0x0605CB26 ; mov.w r2,@r3
L_0605CA12:
    c.r[1] = c.r[6];  // 0605CA12 mov r6,r1
    c.r[1] += 79;  // 0605CA14 add #79,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CA16 mov.b @r1,r2
    c.r[1] = c.r[6];  // 0605CA18 mov r6,r1
    c.r[1] += 77;  // 0605CA1A add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CA1C mov.b @r1,r1
    c.r[2] += c.r[3];  // 0605CA1E add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605CA20 extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0605CA22 cmp/ge r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0605CB22; } }  // 0605CA24 bt/s 0x0605CB22 ; mov #0,r1
    c.r[3] = c.r[6];  // 0605CA28 mov r6,r3
    c.r[5] = c.r[6];  // 0605CA2A mov r6,r5
    c.r[5] += 127;  // 0605CA2C add #127,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605CA2E mov.b @r5,r2
    c.r[3] += 110;  // 0605CA30 add #110,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605CA32 mov.w @r3,r1
    c.r[6] += 122;  // 0605CA34 add #122,r6
    c.r[1] += c.r[2];  // 0605CA36 add r2,r1
    st16(c.r[3], c.r[1]);  // 0605CA38 mov.w r1,@r3
    c.r[1] = c.r[7];  // 0605CA3A mov r7,r1
    c.r[1] -= 1;  // 0605CA3C add #-1,r1
    st16(c.r[8], c.r[1]);  // 0605CA3E mov.w r1,@r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CA6Au);  // 0605CA40 mov.w 0x0605CA6A,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605CA42 mov.w @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CA6Cu);  // 0605CA44 mov.w 0x0605CA6C,r1
    c.r[7] = c.r[2];  // 0605CA46 mov r2,r7
    c.r[7] &= c.r[3];  // 0605CA48 and r3,r7
    c.r[7] += 1;  // 0605CA4A add #1,r7
    c.r[7] &= c.r[3];  // 0605CA4C and r3,r7
    c.r[2] &= c.r[1];  // 0605CA4E and r1,r2
    c.r[2] |= c.r[7];  // 0605CA50 or r7,r2
    st16(c.r[6], c.r[2]);  // 0605CA52 mov.w r2,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605CA54 mov.b @r5,r1
    c.r[2] &= c.r[3];  // 0605CA56 and r3,r2
    c.macl = c.r[2] * c.r[1];  // 0605CA58 mul.l r1,r2
    c.r[0] = c.macl;  // 0605CA5A sts macl,r0
    c.r[0] &= 0xFu;  // 0605CA5C and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CA5E tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_0605CB2E; } }  // 0605CA60 bf/s 0x0605CB2E ; mov r4,r1
    c.r[1] += 1;  // 0605CA64 add #1,r1
    st8(c.r[9], c.r[1]); goto L_0605CB2E;  // 0605CA66 bra 0x0605CB2E ; mov.b r1,@r9
L_0605CA74:
    c.t = (int32_t)c.r[1] >= 0;  // 0605CA74 cmp/pz r1
    { const bool k = c.t; c.r[9] += 117; if (k) { goto L_0605CB2E; } }  // 0605CA76 bt/s 0x0605CB2E ; add #117,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CB82u);  // 0605CA7A mov.w 0x0605CB82,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0605CA7C mov.b @(r0,r6),r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605CA7E mov.b @r9,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0605CA80 extu.b r1,r1
    c.r[2] = c.r[4] & 0xFFu;  // 0605CA82 extu.b r4,r2
    c.r[1] >>= 2;  // 0605CA84 shlr2 r1
    c.r[1] >>= 2;  // 0605CA86 shlr2 r1
    c.t = c.r[2] > c.r[1];  // 0605CA88 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605CACA; } }  // 0605CA8A bt/s 0x0605CACA ; mov r6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605CA8E mov.b @r6,r1
    c.r[0] = c.r[1];  // 0605CA90 mov r1,r0
    c.r[0] >>= 2;  // 0605CA92 shlr2 r0
    c.r[0] >>= 2;  // 0605CA94 shlr2 r0
    c.r[0] >>= 2;  // 0605CA96 shlr2 r0
    c.r[0] &= 0x1u;  // 0605CA98 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CA9A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605CABE; } }  // 0605CA9C bt/s 0x0605CABE ; mov r6,r1
    c.r[1] += 79;  // 0605CAA0 add #79,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CAA2 mov.b @r1,r2
    c.r[1] = c.r[4] & 0xFFu;  // 0605CAA4 extu.b r4,r1
    c.r[2] += c.r[1];  // 0605CAA6 add r1,r2
    c.r[1] = c.r[6];  // 0605CAA8 mov r6,r1
    c.r[1] += 75;  // 0605CAAA add #75,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CAAC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605CAAE extu.b r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0605CAB0 cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0605CABE; } }  // 0605CAB2 bf/s 0x0605CABE ; mov r6,r1
    c.r[1] += 122;  // 0605CAB6 add #122,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CAB8 mov.b @r1,r0
    c.r[0] |= 0x40u; goto L_0605CB2C;  // 0605CABA bra 0x0605CB2C ; or #64,r0
L_0605CABE:
    c.r[1] = ld32(0x0605CB8Cu);  // 0605CABE mov.l 0x0605CB8C,r1
    c.r[3] = c.r[1];  // 0605CAC0 mov r1,r3
    c.r[3] += 124;  // 0605CAC2 add #124,r3
    c.r[2] = 0x0u;  // 0605CAC4 mov #0,r2
    st16(c.r[3], c.r[2]); goto L_0605CB26;  // 0605CAC6 bra 0x0605CB26 ; mov.w r2,@r3
L_0605CACA:
    c.r[1] += 79;  // 0605CACA add #79,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CACC mov.b @r1,r2
    c.r[1] = c.r[4] & 0xFFu;  // 0605CACE extu.b r4,r1
    c.r[2] += c.r[1];  // 0605CAD0 add r1,r2
    c.r[1] = c.r[6];  // 0605CAD2 mov r6,r1
    c.r[1] += 75;  // 0605CAD4 add #75,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CAD6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605CAD8 extu.b r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0605CADA cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] = c.r[6]; if (k) { goto L_0605CB20; } }  // 0605CADC bf/s 0x0605CB20 ; mov r6,r3
    c.r[5] = c.r[6];  // 0605CAE0 mov r6,r5
    c.r[5] += 127;  // 0605CAE2 add #127,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605CAE4 mov.b @r5,r2
    c.r[3] += 110;  // 0605CAE6 add #110,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605CAE8 mov.w @r3,r1
    c.r[6] += 122;  // 0605CAEA add #122,r6
    c.r[1] -= c.r[2];  // 0605CAEC sub r2,r1
    st16(c.r[3], c.r[1]);  // 0605CAEE mov.w r1,@r3
    c.r[1] = c.r[7];  // 0605CAF0 mov r7,r1
    c.r[1] += 1;  // 0605CAF2 add #1,r1
    st16(c.r[8], c.r[1]);  // 0605CAF4 mov.w r1,@r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CB84u);  // 0605CAF6 mov.w 0x0605CB84,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605CAF8 mov.w @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CB86u);  // 0605CAFA mov.w 0x0605CB86,r1
    c.r[7] = c.r[2];  // 0605CAFC mov r2,r7
    c.r[7] &= c.r[3];  // 0605CAFE and r3,r7
    c.r[7] += 1;  // 0605CB00 add #1,r7
    c.r[7] &= c.r[3];  // 0605CB02 and r3,r7
    c.r[2] &= c.r[1];  // 0605CB04 and r1,r2
    c.r[2] |= c.r[7];  // 0605CB06 or r7,r2
    st16(c.r[6], c.r[2]);  // 0605CB08 mov.w r2,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605CB0A mov.b @r5,r1
    c.r[2] &= c.r[3];  // 0605CB0C and r3,r2
    c.macl = c.r[2] * c.r[1];  // 0605CB0E mul.l r1,r2
    c.r[0] = c.macl;  // 0605CB10 sts macl,r0
    c.r[0] &= 0xFu;  // 0605CB12 and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CB14 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_0605CB2E; } }  // 0605CB16 bf/s 0x0605CB2E ; mov r4,r1
    c.r[1] -= 1;  // 0605CB1A add #-1,r1
    st8(c.r[9], c.r[1]); goto L_0605CB2E;  // 0605CB1C bra 0x0605CB2E ; mov.b r1,@r9
L_0605CB20:
    c.r[1] = 0x0u;  // 0605CB20 mov #0,r1
L_0605CB22:
    st16(c.r[8], c.r[1]);  // 0605CB22 mov.w r1,@r8
    c.r[1] = c.r[6];  // 0605CB24 mov r6,r1
L_0605CB26:
    c.r[1] += 122;  // 0605CB26 add #122,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CB28 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 0605CB2A and #191,r0
L_0605CB2C:
    st8(c.r[1], c.r[0]);  // 0605CB2C mov.b r0,@r1
L_0605CB2E:
    c.r[2] = ld32(0x0605CB8Cu);  // 0605CB2E mov.l 0x0605CB8C,r2
    c.r[1] = c.r[2];  // 0605CB30 mov r2,r1
    c.r[1] += 118;  // 0605CB32 add #118,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CB34 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605CB36 mov r1,r0
    c.r[0] >>= 2;  // 0605CB38 shlr2 r0
    c.r[0] >>= 2;  // 0605CB3A shlr2 r0
    c.r[0] >>= 2;  // 0605CB3C shlr2 r0
    c.r[0] &= 0x1u;  // 0605CB3E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CB40 tst r0,r0
    { const bool k = !c.t; c.r[2] += 122; if (k) { goto L_0605CB56; } }  // 0605CB42 bf/s 0x0605CB56 ; add #122,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CB46 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605CB48 mov r1,r0
    c.r[0] >>= 2;  // 0605CB4A shlr2 r0
    c.r[0] >>= 2;  // 0605CB4C shlr2 r0
    c.r[0] >>= 2;  // 0605CB4E shlr2 r0
    c.r[0] &= 0x1u;  // 0605CB50 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CB52 tst r0,r0
    if (c.t) { goto L_0605CB5C; }  // 0605CB54 bt 0x0605CB5C
L_0605CB56:
    c.r[1] = ld32(0x0605CB90u);  // 0605CB56 mov.l 0x0605CB90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605CB5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CB5Cu) return; }  // 0605CB58 jsr @r1 ; nop
L_0605CB5C:
    c.r[2] = ld32(0x0605CB8Cu);  // 0605CB5C mov.l 0x0605CB8C,r2
    c.r[1] = c.r[2];  // 0605CB5E mov r2,r1
    c.r[1] += 120;  // 0605CB60 add #120,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605CB62 mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CB64 tst r1,r1
    { const bool k = !c.t; c.r[2] += 124; if (k) { goto L_0605CB70; } }  // 0605CB66 bf/s 0x0605CB70 ; add #124,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0605CB6A mov.w @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CB6C tst r1,r1
    if (c.t) { goto L_0605CB74; }  // 0605CB6E bt 0x0605CB74
L_0605CB70:
    c.r[0] = 0x0u; goto L_0605CB76;  // 0605CB70 bra 0x0605CB76 ; mov #0,r0
L_0605CB74:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CB88u);  // 0605CB74 mov.w 0x0605CB88,r0
L_0605CB76:
    c.r[15] = c.r[14];  // 0605CB76 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605CB78 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605CB7A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605CB7C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605CB7E rts ; mov.l @r15+,r8
}

void f_0605CB94(SH2Context& c) {
    ran[1407] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CB94 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605CB96 sts.l pr,@-r15
    c.r[1] = ld32(0x0605CBC4u);  // 0605CB98 mov.l 0x0605CBC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605CB9Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CB9Eu) return; }  // 0605CB9A jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x0605CBC8u);  // 0605CB9E mov.l 0x0605CBC8,r2
    c.r[1] = c.r[2];  // 0605CBA0 mov r2,r1
    c.r[1] += 120;  // 0605CBA2 add #120,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605CBA4 mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CBA6 tst r1,r1
    { const bool k = !c.t; c.r[2] += 124; if (k) { goto L_0605CBB2; } }  // 0605CBA8 bf/s 0x0605CBB2 ; add #124,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0605CBAC mov.w @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CBAE tst r1,r1
    if (c.t) { goto L_0605CBB6; }  // 0605CBB0 bt 0x0605CBB6
L_0605CBB2:
    c.r[0] = 0x0u; goto L_0605CBB8;  // 0605CBB2 bra 0x0605CBB8 ; mov #0,r0
L_0605CBB6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CBC0u);  // 0605CBB6 mov.w 0x0605CBC0,r0
L_0605CBB8:
    c.r[15] = c.r[14];  // 0605CBB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605CBBA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605CBBC rts ; mov.l @r15+,r14
}

void f_0605CBCC(SH2Context& c) {
    ran[1408] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CBCC mov.l r14,@-r15
    c.r[1] = ld32(0x0605CC24u);  // 0605CBCE mov.l 0x0605CC24,r1
    c.r[2] = ld32(c.r[1]);  // 0605CBD0 mov.l @r1,r2
    c.r[2] += 1;  // 0605CBD2 add #1,r2
    st32(c.r[1], c.r[2]);  // 0605CBD4 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CBD6 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605CBD8 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CBDA tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605CBEA; } }  // 0605CBDC bf/s 0x0605CBEA ; mov r15,r14
    c.r[1] = ld32(0x0605CC28u);  // 0605CBE0 mov.l 0x0605CC28,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CBE2 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 0605CBE4 and #191,r0
    st8(c.r[1], c.r[0]); goto L_0605CC16;  // 0605CBE6 bra 0x0605CC16 ; mov.b r0,@r1
L_0605CBEA:
    c.t = c.r[0] == 0x1u;  // 0605CBEA cmp/eq #1,r0
    if (!c.t) { goto L_0605CBF8; }  // 0605CBEC bf 0x0605CBF8
    c.r[1] = ld32(0x0605CC28u);  // 0605CBEE mov.l 0x0605CC28,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CBF0 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 0605CBF2 or #64,r0
    st8(c.r[1], c.r[0]); goto L_0605CC16;  // 0605CBF4 bra 0x0605CC16 ; mov.b r0,@r1
L_0605CBF8:
    c.r[1] = ld32(0x0605CC28u);  // 0605CBF8 mov.l 0x0605CC28,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CBFA mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CC1Eu);  // 0605CBFC mov.w 0x0605CC1E,r3
    c.r[0] = c.r[2];  // 0605CBFE mov r2,r0
    c.r[0] >>= 2;  // 0605CC00 shlr2 r0
    c.r[0] >>= 2;  // 0605CC02 shlr2 r0
    c.r[0] >>= 2;  // 0605CC04 shlr2 r0
    c.r[0] &= 0x1u;  // 0605CC06 and #1,r0
    c.r[0] ^= 0x1u;  // 0605CC08 xor #1,r0
    c.r[0] <<= 2;  // 0605CC0A shll2 r0
    c.r[0] <<= 2;  // 0605CC0C shll2 r0
    c.r[0] <<= 2;  // 0605CC0E shll2 r0
    c.r[2] &= c.r[3];  // 0605CC10 and r3,r2
    c.r[2] |= c.r[0];  // 0605CC12 or r0,r2
    st8(c.r[1], c.r[2]);  // 0605CC14 mov.b r2,@r1
L_0605CC16:
    c.r[15] = c.r[14];  // 0605CC16 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CC20u);  // 0605CC18 mov.w 0x0605CC20,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605CC1A rts ; mov.l @r15+,r14
}

void f_0605CC2C(SH2Context& c) {
    ran[1409] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CC2C mov.l r14,@-r15
    c.r[1] = ld32(0x0605CCE0u);  // 0605CC2E mov.l 0x0605CCE0,r1
    c.r[5] = ld32(c.r[1]);  // 0605CC30 mov.l @r1,r5
    c.r[1] = c.r[5];  // 0605CC32 mov r5,r1
    c.r[1] += 1;  // 0605CC34 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CC36 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605CC38 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CC3A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605CC74; } }  // 0605CC3C bt/s 0x0605CC74 ; mov r15,r14
    c.r[1] = ld32(0x0605CCE4u);  // 0605CC40 mov.l 0x0605CCE4,r1
    c.r[2] = c.r[5];  // 0605CC42 mov r5,r2
    c.r[2] += 2;  // 0605CC44 add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CCD2u);  // 0605CC46 mov.w 0x0605CCD2,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CC48 mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCD4u);  // 0605CC4A mov.w 0x0605CCD4,r0
    c.r[7] &= c.r[0];  // 0605CC4C and r0,r7
    c.r[0] = c.r[1];  // 0605CC4E mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605CC50 mov.b @(r0,r3),r6
    c.r[0] = 0xFu;  // 0605CC52 mov #15,r0
    c.r[6] &= c.r[0];  // 0605CC54 and r0,r6
    c.r[6] |= c.r[7];  // 0605CC56 or r7,r6
    c.r[0] = c.r[1];  // 0605CC58 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 0605CC5A mov.b r6,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CC5C mov.b @r2,r2
    c.r[0] = 0xFu;  // 0605CC5E mov #15,r0
    c.r[2] &= c.r[0];  // 0605CC60 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCD4u);  // 0605CC62 mov.w 0x0605CCD4,r0
    c.r[6] &= c.r[0];  // 0605CC64 and r0,r6
    c.r[6] |= c.r[2];  // 0605CC66 or r2,r6
    c.r[0] = c.r[1];  // 0605CC68 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 0605CC6A mov.b r6,@(r0,r3)
    c.r[2] = c.r[5];  // 0605CC6C mov r5,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CCD6u);  // 0605CC6E mov.w 0x0605CCD6,r3
    c.r[2] += 3; goto L_0605CCA6;  // 0605CC70 bra 0x0605CCA6 ; add #3,r2
L_0605CC74:
    c.r[1] = ld32(0x0605CCE4u);  // 0605CC74 mov.l 0x0605CCE4,r1
    c.r[2] = c.r[5];  // 0605CC76 mov r5,r2
    c.r[2] += 2;  // 0605CC78 add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CCD8u);  // 0605CC7A mov.w 0x0605CCD8,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CC7C mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCD4u);  // 0605CC7E mov.w 0x0605CCD4,r0
    c.r[7] &= c.r[0];  // 0605CC80 and r0,r7
    c.r[0] = c.r[1];  // 0605CC82 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605CC84 mov.b @(r0,r3),r6
    c.r[0] = 0xFu;  // 0605CC86 mov #15,r0
    c.r[6] &= c.r[0];  // 0605CC88 and r0,r6
    c.r[6] |= c.r[7];  // 0605CC8A or r7,r6
    c.r[0] = c.r[1];  // 0605CC8C mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 0605CC8E mov.b r6,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CC90 mov.b @r2,r2
    c.r[0] = 0xFu;  // 0605CC92 mov #15,r0
    c.r[2] &= c.r[0];  // 0605CC94 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCD4u);  // 0605CC96 mov.w 0x0605CCD4,r0
    c.r[6] &= c.r[0];  // 0605CC98 and r0,r6
    c.r[6] |= c.r[2];  // 0605CC9A or r2,r6
    c.r[0] = c.r[1];  // 0605CC9C mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 0605CC9E mov.b r6,@(r0,r3)
    c.r[2] = c.r[5];  // 0605CCA0 mov r5,r2
    c.r[2] += 3;  // 0605CCA2 add #3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605CCDAu);  // 0605CCA4 mov.w 0x0605CCDA,r3
L_0605CCA6:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CCA6 mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCD4u);  // 0605CCA8 mov.w 0x0605CCD4,r0
    c.r[7] &= c.r[0];  // 0605CCAA and r0,r7
    c.r[0] = c.r[1];  // 0605CCAC mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605CCAE mov.b @(r0,r3),r6
    c.r[0] = 0xFu;  // 0605CCB0 mov #15,r0
    c.r[6] &= c.r[0];  // 0605CCB2 and r0,r6
    c.r[6] |= c.r[7];  // 0605CCB4 or r7,r6
    c.r[0] = c.r[1];  // 0605CCB6 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 0605CCB8 mov.b r6,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CCBA mov.b @r2,r2
    c.r[0] = 0xFu;  // 0605CCBC mov #15,r0
    c.r[2] &= c.r[0];  // 0605CCBE and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCD4u);  // 0605CCC0 mov.w 0x0605CCD4,r0
    c.r[6] &= c.r[0];  // 0605CCC2 and r0,r6
    c.r[6] |= c.r[2];  // 0605CCC4 or r2,r6
    c.r[0] = c.r[1];  // 0605CCC6 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 0605CCC8 mov.b r6,@(r0,r3)
    c.r[15] = c.r[14];  // 0605CCCA mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CCDCu);  // 0605CCCC mov.w 0x0605CCDC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605CCCE rts ; mov.l @r15+,r14
}

void f_0605CCE8(SH2Context& c) {
    ran[1410] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CCE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605CCEA sts.l pr,@-r15
    c.r[1] = ld32(0x0605CD08u);  // 0605CCEC mov.l 0x0605CD08,r1
    c.r[1] = ld32(c.r[1]);  // 0605CCEE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CCF0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605CCF2 extu.b r1,r0
    c.r[0] <<= 2;  // 0605CCF4 shll2 r0
    c.r[1] = ld32(0x0605CD0Cu);  // 0605CCF6 mov.l 0x0605CD0C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605CCF8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605CCFEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CCFEu) return; }  // 0605CCFA jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605CCFE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605CD00 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605CD02 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605CD04 rts ; extu.w r0,r0
}

void f_0605CD10(SH2Context& c) {
    ran[1411] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605CD10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605CD12 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605CD14 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605CD16 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605CD18 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605CD1A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CD1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605CD1E sts.l pr,@-r15
    c.r[2] = ld32(0x0605CE4Cu);  // 0605CD20 mov.l 0x0605CE4C,r2
    c.r[1] = c.r[2];  // 0605CD22 mov r2,r1
    c.r[1] += 117;  // 0605CD24 add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CD26 mov.b @r1,r3
    c.r[6] = ld32(0x0605CE50u);  // 0605CD28 mov.l 0x0605CE50,r6
    c.r[1] = c.r[2];  // 0605CD2A mov r2,r1
    c.r[1] += 79;  // 0605CD2C add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CD2E mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605CD30 extu.b r3,r3
    c.r[3] += c.r[1];  // 0605CD32 add r1,r3
    c.r[1] = c.r[2];  // 0605CD34 mov r2,r1
    c.r[1] += 116;  // 0605CD36 add #116,r1
    c.r[2] += 78;  // 0605CD38 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CD3A mov.b @r1,r1
    c.r[3] <<= 2;  // 0605CD3C shll2 r3
    c.r[3] <<= 2;  // 0605CD3E shll2 r3
    c.r[3] <<= 2;  // 0605CD40 shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CD42 mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0605CD44 extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 0605CD46 mov.l @r6,r2
    c.r[1] += c.r[7];  // 0605CD48 add r7,r1
    c.r[3] += c.r[2];  // 0605CD4A add r2,r3
    c.r[0] = c.r[3];  // 0605CD4C mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605CD4E mov.b @(r0,r1),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605CD50 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CE40u);  // 0605CD52 mov.w 0x0605CE40,r1
    c.t = c.r[3] == c.r[1];  // 0605CD54 cmp/eq r1,r3
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605CD60; } }  // 0605CD56 bf/s 0x0605CD60 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CE42u);  // 0605CD5A mov.w 0x0605CE42,r0
    c.r[15] = c.r[14]; goto L_0605CE2E;  // 0605CD5C bra 0x0605CE2E ; mov r14,r15
L_0605CD60:
    c.r[1] = ld32(0x0605CE54u);  // 0605CD60 mov.l 0x0605CE54,r1
    c.r[2] = ld32(c.r[1]);  // 0605CD62 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CE44u);  // 0605CD64 mov.w 0x0605CE44,r1
    c.r[0] = c.r[2];  // 0605CD66 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605CD68 mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 0605CD6A mov #16,r0
    c.r[1] &= c.r[0];  // 0605CD6C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CD6E tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0605CE2A; } }  // 0605CD70 bf/s 0x0605CE2A ; mov r3,r2
    c.r[1] = ld32(0x0605CE58u);  // 0605CD74 mov.l 0x0605CE58,r1
    c.r[1] = ld32(c.r[1]);  // 0605CD76 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605CD78 shll2 r2
    c.r[2] <<= 2;  // 0605CD7A shll2 r2
    c.r[2] += c.r[1];  // 0605CD7C add r1,r2
    c.r[2] += 3;  // 0605CD7E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CD80 mov.b @r2,r1
    c.r[0] = 0x3u;  // 0605CD82 mov #3,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605CD84 shlr r1
    c.r[1] &= c.r[0];  // 0605CD86 and r0,r1
    c.r[0] = c.r[1];  // 0605CD88 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0605CD8A cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0605CE24; } }  // 0605CD8C bt/s 0x0605CE24 ; cmp/eq #2,r0
    if (!c.t) { goto L_0605CD9A; }  // 0605CD90 bf 0x0605CD9A
    c.r[15] = c.r[14];  // 0605CD92 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CE46u);  // 0605CD94 mov.w 0x0605CE46,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0605CE30;  // 0605CD96 bra 0x0605CE30 ; lds.l @r15+,pr
L_0605CD9A:
    c.r[0] = ld32(0x0605CE58u);  // 0605CD9A mov.l 0x0605CE58,r0
    c.r[12] = c.r[3];  // 0605CD9C mov r3,r12
    c.r[2] = ld32(c.r[0]);  // 0605CD9E mov.l @r0,r2
    c.r[12] <<= 2;  // 0605CDA0 shll2 r12
    c.r[12] <<= 2;  // 0605CDA2 shll2 r12
    c.r[2] += c.r[12];  // 0605CDA4 add r12,r2
    c.r[1] = c.r[2];  // 0605CDA6 mov r2,r1
    c.r[1] += 3;  // 0605CDA8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CDAA mov.b @r1,r1
    c.r[0] = 0x3u;  // 0605CDAC mov #3,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605CDAE shlr r1
    c.r[1] &= c.r[0];  // 0605CDB0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CDB2 tst r1,r1
    if (!c.t) { goto L_0605CDBC; }  // 0605CDB4 bf 0x0605CDBC
    c.r[1] = ld32(c.r[2] + 12);  // 0605CDB6 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CDB8 tst r1,r1
    if (!c.t) { goto L_0605CE24; }  // 0605CDBA bf 0x0605CE24
L_0605CDBC:
    c.r[2] += 2;  // 0605CDBC add #2,r2
    c.r[0] = ld32(0x0605CE5Cu);  // 0605CDBE mov.l 0x0605CE5C,r0
    c.r[10] = 0x1Eu;  // 0605CDC0 mov #30,r10
    c.r[11] = ld32(0x0605CE60u);  // 0605CDC2 mov.l 0x0605CE60,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605CDC4 mov.b @r2,r1
    c.r[9] = ld32(0x0605CE64u);  // 0605CDC6 mov.l 0x0605CE64,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0605CDC8 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0605CDCA mul.l r10,r1
    c.r[5] = 0x1Bu;  // 0605CDCC mov #27,r5
    c.r[2] = ld32(c.r[0]);  // 0605CDCE mov.l @r0,r2
    c.r[1] = c.macl;  // 0605CDD0 sts macl,r1
    c.r[0] = c.r[1];  // 0605CDD2 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0605CDD4 mov.w @(r0,r2),r8
    c.r[4] = c.r[11];  // 0605CDD6 mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605CDDCu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CDDCu) return; }  // 0605CDD8 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0605CDDC mov r0,r1
    c.r[5] = c.r[8];  // 0605CDDE mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605CDE4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CDE4u) return; }  // 0605CDE0 jsr @r9 ; mov r1,r4
    c.r[13] = c.r[0];  // 0605CDE4 mov r0,r13
    c.r[0] = ld32(0x0605CE58u);  // 0605CDE6 mov.l 0x0605CE58,r0
    c.r[1] = ld32(c.r[0]);  // 0605CDE8 mov.l @r0,r1
    c.r[12] += c.r[1];  // 0605CDEA add r1,r12
    c.r[12] += 2;  // 0605CDEC add #2,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0605CDEE mov.b @r12,r1
    c.r[5] = 0x1Bu;  // 0605CDF0 mov #27,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0605CDF2 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0605CDF4 mul.l r10,r1
    c.r[0] = ld32(0x0605CE5Cu);  // 0605CDF6 mov.l 0x0605CE5C,r0
    c.r[2] = ld32(c.r[0]);  // 0605CDF8 mov.l @r0,r2
    c.r[1] = c.macl;  // 0605CDFA sts macl,r1
    c.r[0] = c.r[1];  // 0605CDFC mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0605CDFE mov.w @(r0,r2),r8
    c.r[4] = c.r[11];  // 0605CE00 mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605CE06u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CE06u) return; }  // 0605CE02 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0605CE06 mov r0,r1
    c.r[5] = c.r[8];  // 0605CE08 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605CE0Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605CE0Eu) return; }  // 0605CE0A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0605CE0E mov r0,r1
    c.r[13] += 2;  // 0605CE10 add #2,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0605CE12 mov.b @r13,r2
    c.r[1] += 3;  // 0605CE14 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CE16 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605CE18 extu.b r2,r2
    c.r[2] <<= 8;  // 0605CE1A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605CE1C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0605CE1E or r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605CE20 tst r2,r2
    if (!c.t) { goto L_0605CE2A; }  // 0605CE22 bf 0x0605CE2A
L_0605CE24:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CE48u);  // 0605CE24 mov.w 0x0605CE48,r0
    c.r[15] = c.r[14]; goto L_0605CE2E;  // 0605CE26 bra 0x0605CE2E ; mov r14,r15
L_0605CE2A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CE4Au);  // 0605CE2A mov.w 0x0605CE4A,r0
    c.r[15] = c.r[14];  // 0605CE2C mov r14,r15
L_0605CE2E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605CE2E lds.l @r15+,pr
L_0605CE30:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605CE30 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605CE32 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605CE34 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605CE36 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605CE38 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605CE3A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605CE3C rts ; mov.l @r15+,r8
}

void f_0605CE68(SH2Context& c) {
    ran[1412] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CE68 mov.l r14,@-r15
    c.r[1] = ld32(0x0605CF10u);  // 0605CE6A mov.l 0x0605CF10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CE6C mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605CE6E extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CF00u);  // 0605CE70 mov.w 0x0605CF00,r1
    c.t = c.r[3] == c.r[1];  // 0605CE72 cmp/eq r1,r3
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605CE7E; } }  // 0605CE74 bf/s 0x0605CE7E ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CF02u);  // 0605CE78 mov.w 0x0605CF02,r0
    c.r[15] = c.r[14]; goto L_0605CEFC;  // 0605CE7A bra 0x0605CEFC ; mov r14,r15
L_0605CE7E:
    c.r[1] = ld32(0x0605CF14u);  // 0605CE7E mov.l 0x0605CF14,r1
    c.r[2] = ld32(c.r[1]);  // 0605CE80 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CF04u);  // 0605CE82 mov.w 0x0605CF04,r1
    c.r[0] = c.r[2];  // 0605CE84 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605CE86 mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 0605CE88 mov #16,r0
    c.r[1] &= c.r[0];  // 0605CE8A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CE8C tst r1,r1
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_0605CEF8; } }  // 0605CE8E bf/s 0x0605CEF8 ; shll2 r3
    c.r[1] = ld32(0x0605CF18u);  // 0605CE92 mov.l 0x0605CF18,r1
    c.r[1] = ld32(c.r[1]);  // 0605CE94 mov.l @r1,r1
    c.r[3] <<= 2;  // 0605CE96 shll2 r3
    c.r[3] += c.r[1];  // 0605CE98 add r1,r3
    c.r[3] += 3;  // 0605CE9A add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605CE9C mov.b @r3,r1
    c.r[0] = 0x3u;  // 0605CE9E mov #3,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605CEA0 shlr r1
    c.r[1] &= c.r[0];  // 0605CEA2 and r0,r1
    c.r[0] = c.r[1];  // 0605CEA4 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0605CEA6 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0605CEF2; } }  // 0605CEA8 bt/s 0x0605CEF2 ; cmp/eq #2,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0605CEB6; } }  // 0605CEAC bf/s 0x0605CEB6 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CF06u);  // 0605CEB0 mov.w 0x0605CF06,r0
    goto L_0605CEFC;  // 0605CEB2 bra 0x0605CEFC ; nop
L_0605CEB6:
    c.r[1] = ld32(0x0605CF10u);  // 0605CEB6 mov.l 0x0605CF10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CEB8 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605CEBA extu.b r1,r2
    c.r[1] = ld32(0x0605CF18u);  // 0605CEBC mov.l 0x0605CF18,r1
    c.r[1] = ld32(c.r[1]);  // 0605CEBE mov.l @r1,r1
    c.r[2] <<= 2;  // 0605CEC0 shll2 r2
    c.r[2] <<= 2;  // 0605CEC2 shll2 r2
    c.r[2] += c.r[1];  // 0605CEC4 add r1,r2
    c.r[1] = c.r[2];  // 0605CEC6 mov r2,r1
    c.r[1] += 3;  // 0605CEC8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CECA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605CECC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605CECE shlr r0
    c.r[0] &= 0x3u;  // 0605CED0 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CED2 tst r0,r0
    if (!c.t) { goto L_0605CEDC; }  // 0605CED4 bf 0x0605CEDC
    c.r[1] = ld32(c.r[2] + 12);  // 0605CED6 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CED8 tst r1,r1
    if (!c.t) { goto L_0605CEF2; }  // 0605CEDA bf 0x0605CEF2
L_0605CEDC:
    c.r[1] = ld32(0x0605CF1Cu);  // 0605CEDC mov.l 0x0605CF1C,r1
    c.r[1] = ld32(c.r[1]);  // 0605CEDE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CF08u);  // 0605CEE0 mov.w 0x0605CF08,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0605CEE2 mov.l @(r0,r1),r1
    c.r[1] <<= 8;  // 0605CEE4 shll8 r1
    c.r[1] += c.r[1];  // 0605CEE6 add r1,r1
    c.r[1] >>= 16;  // 0605CEE8 shlr16 r1
    c.r[1] += c.r[1];  // 0605CEEA add r1,r1
    c.r[1] >>= 8;  // 0605CEEC shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CEEE tst r1,r1
    if (!c.t) { goto L_0605CEF8; }  // 0605CEF0 bf 0x0605CEF8
L_0605CEF2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CF0Au);  // 0605CEF2 mov.w 0x0605CF0A,r0
    c.r[15] = c.r[14]; goto L_0605CEFC;  // 0605CEF4 bra 0x0605CEFC ; mov r14,r15
L_0605CEF8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CF0Cu);  // 0605CEF8 mov.w 0x0605CF0C,r0
    c.r[15] = c.r[14];  // 0605CEFA mov r14,r15
L_0605CEFC:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605CEFC rts ; mov.l @r15+,r14
}

void f_0605CF20(SH2Context& c) {
    ran[1413] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CF20 mov.l r14,@-r15
    c.r[1] = ld32(0x0605CFA4u);  // 0605CF22 mov.l 0x0605CFA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CF24 mov.b @r1,r1
    c.r[14] = c.r[15];  // 0605CF26 mov r15,r14
    c.r[3] = c.r[1] & 0xFFu;  // 0605CF28 extu.b r1,r3
    c.r[1] = ld32(0x0605CFA8u);  // 0605CF2A mov.l 0x0605CFA8,r1
    c.r[1] = ld32(c.r[1]);  // 0605CF2C mov.l @r1,r1
    c.r[3] <<= 2;  // 0605CF2E shll2 r3
    c.r[3] <<= 2;  // 0605CF30 shll2 r3
    c.r[3] += c.r[1];  // 0605CF32 add r1,r3
    c.r[1] = c.r[3];  // 0605CF34 mov r3,r1
    c.r[1] += 3;  // 0605CF36 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CF38 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605CF3A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605CF3C shlr r0
    c.r[0] &= 0x3u;  // 0605CF3E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CF40 tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0605CF58; } }  // 0605CF42 bt/s 0x0605CF58 ; mov #0,r7
    c.r[1] = ld32(0x0605CFACu);  // 0605CF46 mov.l 0x0605CFAC,r1
    c.r[2] = ld32(c.r[1]);  // 0605CF48 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CF9Eu);  // 0605CF4A mov.w 0x0605CF9E,r1
    c.r[0] = c.r[2];  // 0605CF4C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605CF4E mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 0605CF50 mov #16,r0
    c.r[1] &= c.r[0];  // 0605CF52 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CF54 tst r1,r1
    if (c.t) { goto L_0605CF68; }  // 0605CF56 bt 0x0605CF68
L_0605CF58:
    c.r[3] += 7;  // 0605CF58 add #7,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605CF5A mov.b @r3,r0
    c.r[0] &= 0x90u;  // 0605CF5C and #144,r0
    c.t = c.r[0] == 0x10u;  // 0605CF5E cmp/eq #16,r0
    if (!c.t) { goto L_0605CF8E; }  // 0605CF60 bf 0x0605CF8E
    c.r[7] = 0x1u;  // 0605CF62 mov #1,r7
    c.r[7] += c.r[7]; goto L_0605CF90;  // 0605CF64 bra 0x0605CF90 ; add r7,r7
L_0605CF68:
    c.r[3] += 7;  // 0605CF68 add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605CF6A mov.b @r3,r1
    c.r[0] = c.r[1];  // 0605CF6C mov r1,r0
    c.r[0] >>= 2;  // 0605CF6E shlr2 r0
    c.r[0] &= 0x1u;  // 0605CF70 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CF72 tst r0,r0
    if (c.t) { goto L_0605CF8E; }  // 0605CF74 bt 0x0605CF8E
    c.r[1] = ld32(0x0605CFB0u);  // 0605CF76 mov.l 0x0605CFB0,r1
    c.r[1] = ld32(c.r[1]);  // 0605CF78 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605CFA0u);  // 0605CF7A mov.w 0x0605CFA0,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0605CF7C mov.l @(r0,r1),r1
    c.r[1] <<= 8;  // 0605CF7E shll8 r1
    c.r[1] += c.r[1];  // 0605CF80 add r1,r1
    c.r[1] >>= 16;  // 0605CF82 shlr16 r1
    c.r[1] += c.r[1];  // 0605CF84 add r1,r1
    c.r[1] >>= 8;  // 0605CF86 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605CF88 tst r1,r1
    if (c.t) { goto L_0605CF8E; }  // 0605CF8A bt 0x0605CF8E
    c.r[7] = 0x1u;  // 0605CF8C mov #1,r7
L_0605CF8E:
    c.r[7] += c.r[7];  // 0605CF8E add r7,r7
L_0605CF90:
    c.r[7] += 1;  // 0605CF90 add #1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605CFA2u);  // 0605CF92 mov.w 0x0605CFA2,r1
    c.r[7] |= c.r[1];  // 0605CF94 or r1,r7
    c.r[15] = c.r[14];  // 0605CF96 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605CF98 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0605CF9A rts ; mov r7,r0
}

void f_0605CFB4(SH2Context& c) {
    ran[1414] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605CFB4 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D058u);  // 0605CFB6 mov.l 0x0605D058,r1
    c.r[1] = ld32(c.r[1]);  // 0605CFB8 mov.l @r1,r1
    c.r[14] = c.r[15];  // 0605CFBA mov r15,r14
    c.r[1] += 1;  // 0605CFBC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CFBE mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0605CFC0 extu.b r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0605CFC2 tst r7,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0605CFF6; } }  // 0605CFC4 bf/s 0x0605CFF6 ; mov #0,r6
    c.r[1] = ld32(0x0605D05Cu);  // 0605CFC8 mov.l 0x0605D05C,r1
    c.r[3] = ld32(c.r[1]);  // 0605CFCA mov.l @r1,r3
    c.r[1] = ld32(0x0605D060u);  // 0605CFCC mov.l 0x0605D060,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605CFCE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605CFD0 extu.b r1,r1
    c.r[2] = c.r[1];  // 0605CFD2 mov r1,r2
    c.r[2] <<= 2;  // 0605CFD4 shll2 r2
    c.r[2] += c.r[1];  // 0605CFD6 add r1,r2
    c.r[2] <<= 2;  // 0605CFD8 shll2 r2
    c.r[3] += c.r[2];  // 0605CFDA add r2,r3
    c.r[3] += 51;  // 0605CFDC add #51,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605CFDE mov.b @r3,r1
    c.r[0] = c.r[1];  // 0605CFE0 mov r1,r0
    c.r[0] >>= 2;  // 0605CFE2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605CFE4 shlr r0
    c.r[0] &= 0x1u;  // 0605CFE6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605CFE8 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0605D046; } }  // 0605CFEA bf/s 0x0605D046 ; mov #0,r1
    c.r[2] = ld32(0x0605D064u);  // 0605CFEE mov.l 0x0605D064,r2
    st8(c.r[2], c.r[1]);  // 0605CFF0 mov.b r1,@r2
    c.r[6] = 0x1u; goto L_0605D046;  // 0605CFF2 bra 0x0605D046 ; mov #1,r6
L_0605CFF6:
    c.r[0] = c.r[7];  // 0605CFF6 mov r7,r0
    c.t = c.r[0] == 0x1u;  // 0605CFF8 cmp/eq #1,r0
    if (!c.t) { goto L_0605D01E; }  // 0605CFFA bf 0x0605D01E
    c.r[1] = ld32(0x0605D05Cu);  // 0605CFFC mov.l 0x0605D05C,r1
    c.r[3] = ld32(c.r[1]);  // 0605CFFE mov.l @r1,r3
    c.r[1] = ld32(0x0605D060u);  // 0605D000 mov.l 0x0605D060,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D002 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D004 extu.b r1,r1
    c.r[2] = c.r[1];  // 0605D006 mov r1,r2
    c.r[2] <<= 2;  // 0605D008 shll2 r2
    c.r[2] += c.r[1];  // 0605D00A add r1,r2
    c.r[2] <<= 2;  // 0605D00C shll2 r2
    c.r[3] += c.r[2];  // 0605D00E add r2,r3
    c.r[3] += 50;  // 0605D010 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D012 mov.b @r3,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0605D014 extu.b r1,r6
    c.r[6] >>= 2;  // 0605D016 shlr2 r6
    c.r[6] >>= 2;  // 0605D018 shlr2 r6
    c.r[6] >>= 2; goto L_0605D046;  // 0605D01A bra 0x0605D046 ; shlr2 r6
L_0605D01E:
    c.r[1] = ld32(0x0605D05Cu);  // 0605D01E mov.l 0x0605D05C,r1
    c.r[3] = ld32(c.r[1]);  // 0605D020 mov.l @r1,r3
    c.r[6] = 0x3Fu;  // 0605D022 mov #63,r6
    c.r[1] = ld32(0x0605D060u);  // 0605D024 mov.l 0x0605D060,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D026 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D028 extu.b r1,r1
    c.r[2] = c.r[1];  // 0605D02A mov r1,r2
    c.r[2] <<= 2;  // 0605D02C shll2 r2
    c.r[2] += c.r[1];  // 0605D02E add r1,r2
    c.r[2] <<= 2;  // 0605D030 shll2 r2
    c.r[3] += c.r[2];  // 0605D032 add r2,r3
    c.r[3] += 50;  // 0605D034 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D036 mov.b @r3,r1
    c.t = c.r[0] == 0x3u;  // 0605D038 cmp/eq #3,r0
    { const bool k = !c.t; c.r[6] &= c.r[1]; if (k) { goto L_0605D046; } }  // 0605D03A bf/s 0x0605D046 ; and r1,r6
    c.r[1] = ld32(0x0605D068u);  // 0605D03E mov.l 0x0605D068,r1
    c.r[0] = c.r[6];  // 0605D040 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D042 mov.b @(r0,r1),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0605D044 extu.b r1,r6
L_0605D046:
    c.r[6] += c.r[6];  // 0605D046 add r6,r6
    c.r[6] += 2;  // 0605D048 add #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D056u);  // 0605D04A mov.w 0x0605D056,r1
    c.r[6] |= c.r[1];  // 0605D04C or r1,r6
    c.r[15] = c.r[14];  // 0605D04E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D050 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6] & 0xFFFFu; c.pc = x; return; }  // 0605D052 rts ; extu.w r6,r0
}

void f_0605D06C(SH2Context& c) {
    ran[1415] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D06C mov.l r14,@-r15
    c.r[1] = ld32(0x0605D098u);  // 0605D06E mov.l 0x0605D098,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D070 mov.b @r1,r2
    c.r[14] = c.r[15];  // 0605D072 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0605D074 extu.b r2,r2
    c.r[1] = ld32(0x0605D09Cu);  // 0605D076 mov.l 0x0605D09C,r1
    c.r[1] = ld32(c.r[1]);  // 0605D078 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605D07A shll2 r2
    c.r[2] <<= 2;  // 0605D07C shll2 r2
    c.r[2] += c.r[1];  // 0605D07E add r1,r2
    c.r[2] += 3;  // 0605D080 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D082 mov.b @r2,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D084 mov.l @r15+,r14
    c.r[0] = c.r[1];  // 0605D086 mov r1,r0
    c.r[0] >>= 2;  // 0605D088 shlr2 r0
    c.r[0] &= 0x6u;  // 0605D08A and #6,r0
    c.r[0] += 1;  // 0605D08C add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D094u);  // 0605D08E mov.w 0x0605D094,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605D090 rts ; or r1,r0
}

void f_0605D0A0(SH2Context& c) {
    ran[1416] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605D0A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D0A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D0A4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605D0A6 mov r15,r14
    c.r[4] = ld32(0x0605D11Cu);  // 0605D0A8 mov.l 0x0605D11C,r4
    c.r[8] = ld32(0x0605D120u);  // 0605D0AA mov.l 0x0605D120,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0605D0B0u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D0B0u) return; }  // 0605D0AC jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 0605D0B0 mov r0,r1
    c.r[5] = 0x1u;  // 0605D0B2 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605D0B8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D0B8u) return; }  // 0605D0B4 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0605D0B8 mov r0,r1
    c.r[5] = 0x3u;  // 0605D0BA mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605D0C0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D0C0u) return; }  // 0605D0BC jsr @r8 ; mov r1,r4
    c.r[5] = c.r[0];  // 0605D0C0 mov r0,r5
    c.r[1] = ld32(0x0605D124u);  // 0605D0C2 mov.l 0x0605D124,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D0C4 mov.b @r1,r2
    c.r[6] = ld32(0x0605D128u);  // 0605D0C6 mov.l 0x0605D128,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0605D0C8 extu.b r2,r2
    c.r[1] = ld32(0x0605D12Cu);  // 0605D0CA mov.l 0x0605D12C,r1
    c.r[7] = ld32(c.r[1]);  // 0605D0CC mov.l @r1,r7
    c.r[2] <<= 2;  // 0605D0CE shll2 r2
    c.r[2] <<= 2;  // 0605D0D0 shll2 r2
    c.r[1] = c.r[2];  // 0605D0D2 mov r2,r1
    c.r[1] += c.r[7];  // 0605D0D4 add r7,r1
    c.r[1] += 1;  // 0605D0D6 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D0D8 mov.b @r1,r3
    c.r[0] = c.r[2];  // 0605D0DA mov r2,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0605D0DC extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605D0DE mov.b @(r0,r7),r1
    c.r[3] <<= 2;  // 0605D0E0 shll2 r3
    c.r[3] <<= 2;  // 0605D0E2 shll2 r3
    c.r[3] <<= 2;  // 0605D0E4 shll2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605D114u);  // 0605D0E6 mov.w 0x0605D114,r2
    c.r[0] = c.r[6];  // 0605D0E8 mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0605D0EA mov.l @(r0,r2),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D0EC extu.b r1,r1
    c.r[3] += c.r[2];  // 0605D0EE add r2,r3
    c.r[0] = c.r[3];  // 0605D0F0 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D0F2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D0F4 extu.b r1,r1
    c.r[0] = c.r[5];  // 0605D0F6 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D0F8 mov.b @(r0,r1),r1
    c.r[0] = 0x40u;  // 0605D0FA mov #64,r0
    c.r[1] &= c.r[0];  // 0605D0FC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D0FE tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0605D10A; } }  // 0605D100 bf/s 0x0605D10A ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D116u);  // 0605D104 mov.w 0x0605D116,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0605D10E;  // 0605D106 bra 0x0605D10E ; lds.l @r15+,pr
L_0605D10A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D118u);  // 0605D10A mov.w 0x0605D118,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D10C lds.l @r15+,pr
L_0605D10E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D10E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D110 rts ; mov.l @r15+,r8
}

void f_0605D130(SH2Context& c) {
    ran[1417] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D130 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D1B0u);  // 0605D132 mov.l 0x0605D1B0,r1
    c.r[1] = ld32(c.r[1]);  // 0605D134 mov.l @r1,r1
    c.r[14] = c.r[15];  // 0605D136 mov r15,r14
    c.r[1] += 1;  // 0605D138 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D13A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D13C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D13E tst r1,r1
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_0605D15E; } }  // 0605D140 bf/s 0x0605D15E ; mov #0,r7
    c.r[1] = ld32(0x0605D1B4u);  // 0605D144 mov.l 0x0605D1B4,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D146 mov.b @r1,r3
    c.r[2] = ld32(0x0605D1B8u);  // 0605D148 mov.l 0x0605D1B8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D14A mov.b @r2,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605D14C extu.b r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605D14E extu.b r1,r1
    c.t = c.r[3] == c.r[1];  // 0605D150 cmp/eq r1,r3
    if (!c.t) { goto L_0605D15A; }  // 0605D152 bf 0x0605D15A
    c.r[7] = 0x2u;  // 0605D154 mov #2,r7
    c.r[7] += c.r[7]; goto L_0605D1A0;  // 0605D156 bra 0x0605D1A0 ; add r7,r7
L_0605D15A:
    c.t = (c.r[3] & c.r[3]) == 0; goto L_0605D19A;  // 0605D15A bra 0x0605D19A ; tst r3,r3
L_0605D15E:
    c.r[1] = ld32(0x0605D1BCu);  // 0605D15E mov.l 0x0605D1BC,r1
    c.r[3] = ld32(c.r[1]);  // 0605D160 mov.l @r1,r3
    c.r[1] = ld32(0x0605D1C0u);  // 0605D162 mov.l 0x0605D1C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D164 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0605D166 extu.b r1,r6
    c.r[1] = ld32(0x0605D1C4u);  // 0605D168 mov.l 0x0605D1C4,r1
    c.r[0] = c.r[6];  // 0605D16A mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D16C mov.b @(r0,r1),r1
    c.r[2] = 0xBu;  // 0605D16E mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D170 extu.b r1,r1
    c.r[1] -= 1;  // 0605D172 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0605D174 mul.l r2,r1
    c.r[1] = ld32(0x0605D1C8u);  // 0605D176 mov.l 0x0605D1C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D178 mov.b @(r0,r1),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0605D17A extu.b r1,r6
    c.r[1] = ld32(0x0605D1CCu);  // 0605D17C mov.l 0x0605D1CC,r1
    c.r[0] = c.r[6];  // 0605D17E mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D180 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0605D182 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D184 extu.b r1,r1
    c.r[2] += c.r[1];  // 0605D186 add r1,r2
    c.r[2] += c.r[2];  // 0605D188 add r2,r2
    c.r[0] = c.r[3];  // 0605D18A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605D18C mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D18E extu.b r1,r1
    c.r[1] >>= 2;  // 0605D190 shlr2 r1
    c.r[1] >>= 2;  // 0605D192 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605D194 shlr r1
    c.r[1] >>= 2;  // 0605D196 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D198 tst r1,r1
L_0605D19A:
    if (c.t) { goto L_0605D19E; }  // 0605D19A bt 0x0605D19E
    c.r[7] = 0x1u;  // 0605D19C mov #1,r7
L_0605D19E:
    c.r[7] += c.r[7];  // 0605D19E add r7,r7
L_0605D1A0:
    c.r[7] += 2;  // 0605D1A0 add #2,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D1AEu);  // 0605D1A2 mov.w 0x0605D1AE,r1
    c.r[7] |= c.r[1];  // 0605D1A4 or r1,r7
    c.r[15] = c.r[14];  // 0605D1A6 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D1A8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0605D1AA rts ; mov r7,r0
}

void f_0605D1D0(SH2Context& c) {
    ran[1418] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D1D0 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D1F8u);  // 0605D1D2 mov.l 0x0605D1F8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D1D4 mov.b @r1,r2
    c.r[3] = ld32(0x0605D1FCu);  // 0605D1D6 mov.l 0x0605D1FC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D1D8 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605D1DA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D1DC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0605D1DE cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605D1EA; } }  // 0605D1E0 bt/s 0x0605D1EA ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D1F2u);  // 0605D1E4 mov.w 0x0605D1F2,r0
    c.r[15] = c.r[14]; goto L_0605D1EE;  // 0605D1E6 bra 0x0605D1EE ; mov r14,r15
L_0605D1EA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D1F4u);  // 0605D1EA mov.w 0x0605D1F4,r0
    c.r[15] = c.r[14];  // 0605D1EC mov r14,r15
L_0605D1EE:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D1EE rts ; mov.l @r15+,r14
}

void f_0605D200(SH2Context& c) {
    ran[1419] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D200 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605D202 mov r15,r14
    c.r[1] = ld32(0x0605D21Cu);  // 0605D204 mov.l 0x0605D21C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D206 mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D208 mov.l @r15+,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0605D20A extu.b r1,r1
    c.r[0] = c.r[1];  // 0605D20C mov r1,r0
    c.r[0] += c.r[0];  // 0605D20E add r0,r0
    c.r[0] += 1;  // 0605D210 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D218u);  // 0605D212 mov.w 0x0605D218,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605D214 rts ; or r1,r0
}

void f_0605D220(SH2Context& c) {
    ran[1420] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D220 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D222 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605D284u);  // 0605D224 mov.w 0x0605D284,r3
    c.r[15] += c.r[3];  // 0605D226 add r3,r15
    c.r[1] = ld32(0x0605D28Cu);  // 0605D228 mov.l 0x0605D28C,r1
    c.r[3] = ld32(c.r[1]);  // 0605D22A mov.l @r1,r3
    c.r[1] = ld32(0x0605D290u);  // 0605D22C mov.l 0x0605D290,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D22E mov.b @r1,r1
    c.r[14] = c.r[15];  // 0605D230 mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0605D232 extu.b r1,r0
    c.r[1] = ld32(0x0605D294u);  // 0605D234 mov.l 0x0605D294,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D236 mov.b @(r0,r1),r1
    c.r[2] = 0xBu;  // 0605D238 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D23A extu.b r1,r1
    c.r[1] -= 1;  // 0605D23C add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0605D23E mul.l r2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605D286u);  // 0605D240 mov.w 0x0605D286,r6
    c.r[4] = c.r[14];  // 0605D242 mov r14,r4
    c.r[1] = ld32(0x0605D298u);  // 0605D244 mov.l 0x0605D298,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D246 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0605D248 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D24A extu.b r1,r1
    c.r[2] += c.r[1];  // 0605D24C add r1,r2
    c.r[2] += c.r[2];  // 0605D24E add r2,r2
    c.r[3] += c.r[2];  // 0605D250 add r2,r3
    c.r[3] += 1;  // 0605D252 add #1,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D254 mov.b @r3,r5
    c.r[1] = ld32(0x0605D29Cu);  // 0605D256 mov.l 0x0605D29C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D25Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D25Cu) return; }  // 0605D258 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0605D25C mov r14,r1
    c.r[1] += 37;  // 0605D25E add #37,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D260 mov.b @r1,r4
    c.r[0] = ld32(0x0605D2A0u);  // 0605D262 mov.l 0x0605D2A0,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0605D264 extu.b r4,r4
    c.r[4] >>= 2;  // 0605D266 shlr2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0605D26Cu; c.r[4] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D26Cu) return; }  // 0605D268 jsr @r0 ; shlr2 r4
    c.r[1] = c.r[0] & 0xFFu;  // 0605D26C extu.b r0,r1
    c.r[0] = c.r[1];  // 0605D26E mov r1,r0
    c.r[0] += c.r[0];  // 0605D270 add r0,r0
    c.r[0] += 1;  // 0605D272 add #1,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605D288u);  // 0605D274 mov.w 0x0605D288,r3
    c.r[14] += c.r[3];  // 0605D276 add r3,r14
    c.r[15] = c.r[14];  // 0605D278 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D27A lds.l @r15+,pr
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D28Au);  // 0605D27C mov.w 0x0605D28A,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D27E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605D280 rts ; or r1,r0
}

void f_0605D2A4(SH2Context& c) {
    ran[1421] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D2A4 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D314u);  // 0605D2A6 mov.l 0x0605D314,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D2A8 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605D2AA extu.b r1,r0
    c.r[1] = ld32(0x0605D318u);  // 0605D2AC mov.l 0x0605D318,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D2AE mov.b @(r0,r1),r1
    c.r[5] = c.r[1] & 0xFFu;  // 0605D2B0 extu.b r1,r5
    c.r[1] = ld32(0x0605D31Cu);  // 0605D2B2 mov.l 0x0605D31C,r1
    c.r[7] = ld32(c.r[1]);  // 0605D2B4 mov.l @r1,r7
    c.r[14] = c.r[15];  // 0605D2B6 mov r15,r14
    c.r[1] = c.r[7];  // 0605D2B8 mov r7,r1
    c.r[1] += 5;  // 0605D2BA add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D2BC mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605D2BE extu.b r1,r2
    c.r[1] = c.r[2];  // 0605D2C0 mov r2,r1
    c.r[1] -= 1;  // 0605D2C2 add #-1,r1
    c.t = c.r[5] == c.r[1];  // 0605D2C4 cmp/eq r1,r5
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0605D2CC; } }  // 0605D2C6 bf/s 0x0605D2CC ; mov #0,r6
    c.r[6] = 0x1u;  // 0605D2CA mov #1,r6
L_0605D2CC:
    c.r[1] = ld32(0x0605D320u);  // 0605D2CC mov.l 0x0605D320,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D2CE mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D2D0 extu.b r1,r1
    c.r[1] -= 1;  // 0605D2D2 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0605D2D4 mul.l r2,r1
    c.r[1] = c.r[7];  // 0605D2D6 mov r7,r1
    c.r[1] += 4;  // 0605D2D8 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D2DA mov.b @r1,r1
    c.r[2] = c.macl;  // 0605D2DC sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D2DE extu.b r1,r1
    c.macl = c.r[2] * c.r[1];  // 0605D2E0 mul.l r1,r2
    c.r[3] = c.macl;  // 0605D2E2 sts macl,r3
    c.r[3] += c.r[5];  // 0605D2E4 add r5,r3
    c.r[1] = c.r[7];  // 0605D2E6 mov r7,r1
    c.r[1] += 8;  // 0605D2E8 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D2EA mov.b @r1,r2
    c.r[7] += 9;  // 0605D2EC add #9,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0605D2EE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605D2F0 mov.b @r7,r1
    c.r[2] <<= 8;  // 0605D2F2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D2F4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0605D2F6 or r1,r2
    c.r[2] -= 1;  // 0605D2F8 add #-1,r2
    c.t = c.r[3] == c.r[2];  // 0605D2FA cmp/eq r2,r3
    if (!c.t) { goto L_0605D300; }  // 0605D2FC bf 0x0605D300
    c.r[6] = 0x2u;  // 0605D2FE mov #2,r6
L_0605D300:
    c.r[6] += c.r[6];  // 0605D300 add r6,r6
    c.r[6] += 1;  // 0605D302 add #1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D310u);  // 0605D304 mov.w 0x0605D310,r1
    c.r[6] |= c.r[1];  // 0605D306 or r1,r6
    c.r[15] = c.r[14];  // 0605D308 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D30A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0605D30C rts ; mov r6,r0
}

void f_0605D324(SH2Context& c) {
    ran[1422] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D324 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D364u);  // 0605D326 mov.l 0x0605D364,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D328 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605D32A extu.b r2,r2
    c.r[1] = ld32(0x0605D368u);  // 0605D32C mov.l 0x0605D368,r1
    c.r[1] = ld32(c.r[1]);  // 0605D32E mov.l @r1,r1
    c.r[2] <<= 2;  // 0605D330 shll2 r2
    c.r[2] <<= 2;  // 0605D332 shll2 r2
    c.r[2] += c.r[1];  // 0605D334 add r1,r2
    c.r[2] += 2;  // 0605D336 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D338 mov.b @r2,r2
    c.r[1] = ld32(0x0605D36Cu);  // 0605D33A mov.l 0x0605D36C,r1
    c.r[3] = ld32(c.r[1]);  // 0605D33C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605D33E extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605D340 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605D342 mul.l r1,r2
    c.r[1] = c.macl;  // 0605D344 sts macl,r1
    c.r[1] += c.r[3];  // 0605D346 add r3,r1
    c.r[1] += 22;  // 0605D348 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605D34A mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D35Eu);  // 0605D34C mov.w 0x0605D35E,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605D34E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D350 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605D358; } }  // 0605D352 bf/s 0x0605D358 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D360u);  // 0605D356 mov.w 0x0605D360,r0
L_0605D358:
    c.r[15] = c.r[14];  // 0605D358 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D35A rts ; mov.l @r15+,r14
}

void f_0605D370(SH2Context& c) {
    ran[1423] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D370 mov.l r14,@-r15
    c.r[15] -= 8;  // 0605D372 add #-8,r15
    c.r[14] = c.r[15];  // 0605D374 mov r15,r14
    c.r[1] = 0x0u;  // 0605D376 mov #0,r1
    c.r[2] = 0x0u;  // 0605D378 mov #0,r2
    st32(c.r[14], c.r[1]);  // 0605D37A mov.l r1,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0605D37C mov.l r2,@(4,r14)
    c.r[3] = ld32(0x0605D4C8u);  // 0605D37E mov.l 0x0605D4C8,r3
    st32(c.r[14], c.r[3]);  // 0605D380 mov.l r3,@r14
    c.r[1] = ld32(0x0605D4CCu);  // 0605D382 mov.l 0x0605D4CC,r1
    st32(c.r[14] + 4, c.r[1]);  // 0605D384 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0605D4D0u);  // 0605D386 mov.l 0x0605D4D0,r1
    c.r[1] = ld32(c.r[1]);  // 0605D388 mov.l @r1,r1
    c.r[6] = 0x0u;  // 0605D38A mov #0,r6
    c.r[1] += 1;  // 0605D38C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D38E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D390 extu.b r1,r1
    c.r[0] = c.r[1];  // 0605D392 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0605D394 cmp/eq #1,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0605D3A2; } }  // 0605D396 bt/s 0x0605D3A2 ; mov #0,r5
    c.t = c.r[0] == 0x2u;  // 0605D39A cmp/eq #2,r0
    if (!c.t) { goto L_0605D41A; }  // 0605D39C bf 0x0605D41A
    goto L_0605D412;  // 0605D39E bra 0x0605D412 ; nop
L_0605D3A2:
    c.r[1] = ld32(0x0605D4D4u);  // 0605D3A2 mov.l 0x0605D4D4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D3A4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D3A6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D3A8 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0605D3B2; } }  // 0605D3AA bf/s 0x0605D3B2 ; mov #0,r1
    c.r[2] = ld32(0x0605D4D8u);  // 0605D3AE mov.l 0x0605D4D8,r2
    st8(c.r[2], c.r[1]);  // 0605D3B0 mov.b r1,@r2
L_0605D3B2:
    c.r[7] = ld32(0x0605D4DCu);  // 0605D3B2 mov.l 0x0605D4DC,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605D3B4 mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605D3B6 extu.b r1,r2
    c.r[1] = ld32(0x0605D4E0u);  // 0605D3B8 mov.l 0x0605D4E0,r1
    c.r[6] = ld32(c.r[1]);  // 0605D3BA mov.l @r1,r6
    c.r[2] <<= 2;  // 0605D3BC shll2 r2
    c.r[2] <<= 2;  // 0605D3BE shll2 r2
    c.r[2] += c.r[6];  // 0605D3C0 add r6,r2
    c.r[1] = c.r[2];  // 0605D3C2 mov r2,r1
    c.r[1] += 3;  // 0605D3C4 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D3C6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605D3C8 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605D3CA shlr r0
    c.r[0] &= 0x3u;  // 0605D3CC and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605D3CE tst r0,r0
    if (!c.t) { goto L_0605D412; }  // 0605D3D0 bf 0x0605D412
    c.r[1] = ld32(c.r[2] + 12);  // 0605D3D2 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D3D4 tst r1,r1
    if (!c.t) { goto L_0605D412; }  // 0605D3D6 bf 0x0605D412
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D3D8 mov.b @r3,r1
    c.r[0] = c.r[1];  // 0605D3DA mov r1,r0
    c.r[0] >>= 2;  // 0605D3DC shlr2 r0
    c.r[0] >>= 2;  // 0605D3DE shlr2 r0
    c.r[0] >>= 2;  // 0605D3E0 shlr2 r0
    c.r[0] &= 0x1u;  // 0605D3E2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605D3E4 tst r0,r0
    { const bool k = c.t; c.r[3] += 4; if (k) { goto L_0605D412; } }  // 0605D3E6 bt/s 0x0605D412 ; add #4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605D3EA mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605D3EC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D3EE tst r1,r1
    { const bool k = c.t; c.r[7] += 1; if (k) { goto L_0605D412; } }  // 0605D3F0 bt/s 0x0605D412 ; add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605D3F4 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D3F6 extu.b r1,r1
    c.r[1] <<= 2;  // 0605D3F8 shll2 r1
    c.r[1] <<= 2;  // 0605D3FA shll2 r1
    c.r[1] += c.r[6];  // 0605D3FC add r6,r1
    c.r[1] += 3;  // 0605D3FE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D400 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605D402 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605D404 shlr r0
    c.r[0] &= 0x3u;  // 0605D406 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605D408 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0605D412; } }  // 0605D40A bt/s 0x0605D412 ; mov #1,r1
    c.r[2] = ld32(0x0605D4D8u);  // 0605D40E mov.l 0x0605D4D8,r2
    st8(c.r[2], c.r[1]);  // 0605D410 mov.b r1,@r2
L_0605D412:
    c.r[1] = ld32(0x0605D4D8u);  // 0605D412 mov.l 0x0605D4D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D414 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu; goto L_0605D4B4;  // 0605D416 bra 0x0605D4B4 ; extu.b r1,r5
L_0605D41A:
    c.r[3] = ld32(0x0605D4DCu);  // 0605D41A mov.l 0x0605D4DC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D41C mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605D41E extu.b r1,r2
    c.r[1] = ld32(0x0605D4E0u);  // 0605D420 mov.l 0x0605D4E0,r1
    c.r[7] = ld32(c.r[1]);  // 0605D422 mov.l @r1,r7
    c.r[2] <<= 2;  // 0605D424 shll2 r2
    c.r[2] <<= 2;  // 0605D426 shll2 r2
    c.r[2] += c.r[7];  // 0605D428 add r7,r2
    c.r[1] = c.r[2];  // 0605D42A mov r2,r1
    c.r[1] += 3;  // 0605D42C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D42E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605D430 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605D432 shlr r0
    c.r[0] &= 0x3u;  // 0605D434 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605D436 tst r0,r0
    if (!c.t) { goto L_0605D440; }  // 0605D438 bf 0x0605D440
    c.r[1] = ld32(c.r[2] + 12);  // 0605D43A mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D43C tst r1,r1
    if (c.t) { goto L_0605D462; }  // 0605D43E bt 0x0605D462
L_0605D440:
    c.r[3] += 1;  // 0605D440 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D442 mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605D444 extu.b r1,r2
    c.r[2] <<= 2;  // 0605D446 shll2 r2
    c.r[2] <<= 2;  // 0605D448 shll2 r2
    c.r[2] += c.r[7];  // 0605D44A add r7,r2
    c.r[1] = c.r[2];  // 0605D44C mov r2,r1
    c.r[1] += 3;  // 0605D44E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D450 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605D452 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605D454 shlr r0
    c.r[0] &= 0x3u;  // 0605D456 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605D458 tst r0,r0
    if (!c.t) { goto L_0605D4B4; }  // 0605D45A bf 0x0605D4B4
    c.r[1] = ld32(c.r[2] + 12);  // 0605D45C mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D45E tst r1,r1
    if (!c.t) { goto L_0605D4B4; }  // 0605D460 bf 0x0605D4B4
L_0605D462:
    c.r[7] = ld32(0x0605D4DCu);  // 0605D462 mov.l 0x0605D4DC,r7
    c.r[1] = c.r[7];  // 0605D464 mov r7,r1
    c.r[1] += 1;  // 0605D466 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D468 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605D46A extu.b r2,r2
    c.r[1] = ld32(0x0605D4E0u);  // 0605D46C mov.l 0x0605D4E0,r1
    c.r[3] = ld32(c.r[1]);  // 0605D46E mov.l @r1,r3
    c.r[2] <<= 2;  // 0605D470 shll2 r2
    c.r[2] <<= 2;  // 0605D472 shll2 r2
    c.r[2] += c.r[3];  // 0605D474 add r3,r2
    c.r[2] += 3;  // 0605D476 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D478 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605D47A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605D47C shlr r0
    c.r[0] &= 0x3u;  // 0605D47E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605D480 tst r0,r0
    if (!c.t) { goto L_0605D486; }  // 0605D482 bf 0x0605D486
    c.r[6] = 0x1u;  // 0605D484 mov #1,r6
L_0605D486:
    c.r[0] = c.r[6];  // 0605D486 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605D488 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D48A extu.b r1,r1
    c.r[1] <<= 2;  // 0605D48C shll2 r1
    c.r[1] <<= 2;  // 0605D48E shll2 r1
    c.r[1] += c.r[3];  // 0605D490 add r3,r1
    c.r[1] += 7;  // 0605D492 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D494 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0605D496 mov #1,r0
    c.r[1] >>= 2;  // 0605D498 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605D49A shlr r1
    c.r[1] &= c.r[0];  // 0605D49C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D49E tst r1,r1
    { const bool k = !c.t; c.r[6] <<= 2; if (k) { goto L_0605D4B4; } }  // 0605D4A0 bf/s 0x0605D4B4 ; shll2 r6
    c.r[0] = c.r[6];  // 0605D4A4 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0605D4A6 mov.l @(r0,r14),r1
    c.r[1] += 2;  // 0605D4A8 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605D4AA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605D4AC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D4AE tst r1,r1
    if (c.t) { goto L_0605D4B4; }  // 0605D4B0 bt 0x0605D4B4
    c.r[5] = 0x1u;  // 0605D4B2 mov #1,r5
L_0605D4B4:
    c.r[5] += c.r[5];  // 0605D4B4 add r5,r5
    c.r[5] += 2;  // 0605D4B6 add #2,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D4C6u);  // 0605D4B8 mov.w 0x0605D4C6,r1
    c.r[5] |= c.r[1];  // 0605D4BA or r1,r5
    c.r[14] += 8;  // 0605D4BC add #8,r14
    c.r[15] = c.r[14];  // 0605D4BE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D4C0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0605D4C2 rts ; mov r5,r0
}

void f_0605D4E4(SH2Context& c) {
    ran[1424] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605D4E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D4E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D4E8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605D4EA mov r15,r14
    c.r[8] = ld32(0x0605D540u);  // 0605D4EC mov.l 0x0605D540,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605D4EE mov.b @r8,r4
    c.r[0] = ld32(0x0605D544u);  // 0605D4F0 mov.l 0x0605D544,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605D4F6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D4F6u) return; }  // 0605D4F2 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0605D4F6 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D4F8 tst r1,r1
    if (c.t) { goto L_0605D530; }  // 0605D4FA bt 0x0605D530
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605D4FC mov.b @r8,r2
    c.r[1] = ld32(0x0605D548u);  // 0605D4FE mov.l 0x0605D548,r1
    c.r[1] = ld32(c.r[1]);  // 0605D500 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605D502 extu.b r2,r2
    c.r[2] <<= 2;  // 0605D504 shll2 r2
    c.r[2] <<= 2;  // 0605D506 shll2 r2
    c.r[2] += c.r[1];  // 0605D508 add r1,r2
    c.r[1] = c.r[2];  // 0605D50A mov r2,r1
    c.r[1] += 3;  // 0605D50C add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D50E mov.b @r1,r0
    c.r[2] += 4;  // 0605D510 add #4,r2
    c.r[0] &= 0x1u;  // 0605D512 and #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D514 mov.b @r2,r1
    c.r[0] += c.r[0];  // 0605D516 add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0605D518 extu.b r1,r1
    c.r[1] >>= 2;  // 0605D51A shlr2 r1
    c.r[1] >>= 2;  // 0605D51C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605D51E shlr r1
    c.r[1] >>= 2;  // 0605D520 shlr2 r1
    c.r[1] |= c.r[0];  // 0605D522 or r0,r1
    c.r[0] = c.r[1];  // 0605D524 mov r1,r0
    c.r[0] += c.r[0];  // 0605D526 add r0,r0
    c.r[0] += 1;  // 0605D528 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D53Cu);  // 0605D52A mov.w 0x0605D53C,r1
    c.r[0] |= c.r[1]; goto L_0605D532;  // 0605D52C bra 0x0605D532 ; or r1,r0
L_0605D530:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D53Eu);  // 0605D530 mov.w 0x0605D53E,r0
L_0605D532:
    c.r[15] = c.r[14];  // 0605D532 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D534 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D536 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D538 rts ; mov.l @r15+,r8
}

void f_0605D54C(SH2Context& c) {
    ran[1425] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D54C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D54E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605D550 mov r15,r14
    c.r[0] = ld32(0x0605D57Cu);  // 0605D552 mov.l 0x0605D57C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605D558u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D558u) return; }  // 0605D554 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(0x0605D580u);  // 0605D558 mov.l 0x0605D580,r1
    c.r[1] = ld32(c.r[1]);  // 0605D55A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D574u);  // 0605D55C mov.w 0x0605D574,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D55E mov.b @(r0,r1),r1
    c.r[2] = 0x1u;  // 0605D560 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D562 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0605D564 cmp/hi r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D576u);  // 0605D566 mov.w 0x0605D576,r0
    if (!c.t) { goto L_0605D56C; }  // 0605D568 bf 0x0605D56C
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D578u);  // 0605D56A mov.w 0x0605D578,r0
L_0605D56C:
    c.r[15] = c.r[14];  // 0605D56C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D56E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D570 rts ; mov.l @r15+,r14
}

void f_0605D584(SH2Context& c) {
    ran[1426] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D584 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605D586 mov r15,r14
    c.r[1] = ld32(0x0605D5A0u);  // 0605D588 mov.l 0x0605D5A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D58A mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D58C mov.l @r15+,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0605D58E extu.b r1,r1
    c.r[0] = c.r[1];  // 0605D590 mov r1,r0
    c.r[0] += c.r[0];  // 0605D592 add r0,r0
    c.r[0] += 1;  // 0605D594 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D59Cu);  // 0605D596 mov.w 0x0605D59C,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605D598 rts ; or r1,r0
}

void f_0605D5A4(SH2Context& c) {
    ran[1427] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D5A4 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D5D4u);  // 0605D5A6 mov.l 0x0605D5D4,r1
    c.r[1] = ld32(c.r[1]);  // 0605D5A8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D5CEu);  // 0605D5AA mov.w 0x0605D5CE,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D5AC mov.b @(r0,r1),r3
    c.r[2] = c.r[3] & 0xFFu;  // 0605D5AE extu.b r3,r2
    c.r[1] = 0x1u;  // 0605D5B0 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0605D5B2 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605D5C6; } }  // 0605D5B4 bt/s 0x0605D5C6 ; mov r15,r14
    c.r[1] = c.r[3] & 0xFFu;  // 0605D5B8 extu.b r3,r1
    c.r[0] = c.r[1];  // 0605D5BA mov r1,r0
    c.r[0] += c.r[0];  // 0605D5BC add r0,r0
    c.r[0] += 1;  // 0605D5BE add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D5D0u);  // 0605D5C0 mov.w 0x0605D5D0,r1
    c.r[0] |= c.r[1]; goto L_0605D5C8;  // 0605D5C2 bra 0x0605D5C8 ; or r1,r0
L_0605D5C6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D5D2u);  // 0605D5C6 mov.w 0x0605D5D2,r0
L_0605D5C8:
    c.r[15] = c.r[14];  // 0605D5C8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D5CA rts ; mov.l @r15+,r14
}

void f_0605D5D8(SH2Context& c) {
    ran[1428] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605D5D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605D5DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605D5DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605D5DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D5E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D5E2 sts.l pr,@-r15
    c.r[15] -= 48;  // 0605D5E4 add #-48,r15
    c.r[14] = c.r[15];  // 0605D5E6 mov r15,r14
    c.r[11] = ld32(0x0605D714u);  // 0605D5E8 mov.l 0x0605D714,r11
    c.r[9] = ld32(0x0605D718u);  // 0605D5EA mov.l 0x0605D718,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605D5EC mov.b @r9,r1
    c.r[4] = c.r[14];  // 0605D5EE mov r14,r4
    c.r[2] = ld32(c.r[11]);  // 0605D5F0 mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D5F2 extu.b r1,r1
    c.r[1] += c.r[1];  // 0605D5F4 add r1,r1
    c.r[2] += c.r[1];  // 0605D5F6 add r1,r2
    c.r[2] += 1;  // 0605D5F8 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D5FA mov.b @r2,r5
    c.r[1] = ld32(0x0605D71Cu);  // 0605D5FC mov.l 0x0605D71C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D602u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D602u) return; }  // 0605D5FE jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0605D720u);  // 0605D602 mov.l 0x0605D720,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D604 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605D606 extu.b r1,r0
    c.r[1] = ld32(0x0605D724u);  // 0605D608 mov.l 0x0605D724,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D60A mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605D60C extu.b r1,r0
    c.r[1] = c.r[14];  // 0605D60E mov r14,r1
    c.r[1] += 24;  // 0605D610 add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D612 mov.b @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0605D614 extu.b r1,r8
    c.r[1] = ld32(0x0605D728u);  // 0605D616 mov.l 0x0605D728,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D618 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D61A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D61C tst r1,r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0605D63C; } }  // 0605D61E bt/s 0x0605D63C ; mov #0,r10
    c.r[1] = ld32(0x0605D72Cu);  // 0605D622 mov.l 0x0605D72C,r1
    c.r[2] = ld32(c.r[1]);  // 0605D624 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D70Au);  // 0605D626 mov.w 0x0605D70A,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D70Cu);  // 0605D628 mov.w 0x0605D70C,r1
    c.r[2] += c.r[1];  // 0605D62A add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605D62C mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D62E extu.b r1,r1
    c.r[1] <<= 2;  // 0605D630 shll2 r1
    c.r[1] += c.r[1];  // 0605D632 add r1,r1
    c.r[2] += c.r[1];  // 0605D634 add r1,r2
    c.r[2] += 4;  // 0605D636 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_0605D64A;  // 0605D638 bra 0x0605D64A ; mov.b @r2,r1
L_0605D63C:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605D63C mov.b @r9,r2
    c.r[1] = ld32(c.r[11]);  // 0605D63E mov.l @r11,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605D640 extu.b r2,r2
    c.r[2] += c.r[2];  // 0605D642 add r2,r2
    c.r[1] += c.r[2];  // 0605D644 add r2,r1
    c.r[1] += 1;  // 0605D646 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D648 mov.b @r1,r1
L_0605D64A:
    c.r[5] = c.r[1] & 0xFFu;  // 0605D64A extu.b r1,r5
    c.r[1] = ld32(0x0605D71Cu);  // 0605D64C mov.l 0x0605D71C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D652u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D652u) return; }  // 0605D64E jsr @r1 ; mov r14,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 0605D652 tst r8,r8
    if (c.t) { goto L_0605D6EE; }  // 0605D654 bt 0x0605D6EE
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605D70Eu);  // 0605D656 mov.w 0x0605D70E,r11
    c.t = c.r[8] == c.r[11];  // 0605D658 cmp/eq r11,r8
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_0605D6EE; } }  // 0605D65A bt/s 0x0605D6EE ; mov r14,r5
    c.r[9] = ld32(0x0605D728u);  // 0605D65E mov.l 0x0605D728,r9
    c.r[0] = ld32(0x0605D730u);  // 0605D660 mov.l 0x0605D730,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605D662 mov.b @r9,r6
    c.r[4] = c.r[8];  // 0605D664 mov r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0605D66Au; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D66Au) return; }  // 0605D666 jsr @r0 ; extu.b r6,r6
    c.r[1] = c.r[14];  // 0605D66A mov r14,r1
    c.r[1] += 10;  // 0605D66C add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605D66E mov.w @r1,r1
    c.r[2] = c.r[0] & 0xFFu;  // 0605D670 extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605D672 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 0605D674 cmp/hi r1,r2
    if (c.t) { goto L_0605D6EE; }  // 0605D676 bt 0x0605D6EE
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605D678 mov.b @r9,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0605D67A extu.b r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0605D67C tst r4,r4
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0605D686; } }  // 0605D67E bt/s 0x0605D686 ; mov r8,r0
    c.t = c.r[0] == 0x1Cu;  // 0605D682 cmp/eq #28,r0
    if (c.t) { goto L_0605D6EE; }  // 0605D684 bt 0x0605D6EE
L_0605D686:
    c.r[2] = ld32(0x0605D734u);  // 0605D686 mov.l 0x0605D734,r2
    c.r[1] = c.r[2];  // 0605D688 mov r2,r1
    c.r[1] += 117;  // 0605D68A add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D68C mov.b @r1,r3
    c.r[6] = ld32(0x0605D738u);  // 0605D68E mov.l 0x0605D738,r6
    c.r[1] = c.r[2];  // 0605D690 mov r2,r1
    c.r[1] += 79;  // 0605D692 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D694 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605D696 extu.b r3,r3
    c.r[3] += c.r[1];  // 0605D698 add r1,r3
    c.r[1] = c.r[2];  // 0605D69A mov r2,r1
    c.r[1] += 116;  // 0605D69C add #116,r1
    c.r[2] += 78;  // 0605D69E add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D6A0 mov.b @r1,r1
    c.r[3] <<= 2;  // 0605D6A2 shll2 r3
    c.r[3] <<= 2;  // 0605D6A4 shll2 r3
    c.r[3] <<= 2;  // 0605D6A6 shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D6A8 mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0605D6AA extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 0605D6AC mov.l @r6,r2
    c.r[1] += c.r[7];  // 0605D6AE add r7,r1
    c.r[3] += c.r[2];  // 0605D6B0 add r2,r3
    c.r[0] = c.r[3];  // 0605D6B2 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D6B4 mov.b @(r0,r1),r1
    c.r[5] = c.r[1] & 0xFFu;  // 0605D6B6 extu.b r1,r5
    c.t = c.r[5] == c.r[11];  // 0605D6B8 cmp/eq r11,r5
    { const bool k = c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_0605D6EE; } }  // 0605D6BA bt/s 0x0605D6EE ; tst r4,r4
    if (c.t) { goto L_0605D6C6; }  // 0605D6BE bt 0x0605D6C6
    c.r[1] = ld32(0x0605D73Cu);  // 0605D6C0 mov.l 0x0605D73C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D6C2 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0605D6C4 extu.b r1,r5
L_0605D6C6:
    c.r[1] = ld32(0x0605D728u);  // 0605D6C6 mov.l 0x0605D728,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D6C8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D6CA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D6CC tst r1,r1
    if (c.t) { goto L_0605D6D6; }  // 0605D6CE bt 0x0605D6D6
    c.r[1] = ld32(0x0605D73Cu);  // 0605D6D0 mov.l 0x0605D73C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0605D6DA;  // 0605D6D2 bra 0x0605D6DA ; mov.b @r1,r1
L_0605D6D6:
    c.r[1] = ld32(0x0605D740u);  // 0605D6D6 mov.l 0x0605D740,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D6D8 mov.b @r1,r1
L_0605D6DA:
    c.r[4] = c.r[1] & 0xFFu;  // 0605D6DA extu.b r1,r4
    c.r[0] = ld32(0x0605D744u);  // 0605D6DC mov.l 0x0605D744,r0
    c.r[7] = 0x0u;  // 0605D6DE mov #0,r7
    { const uint32_t x = c.r[0]; c.pr = 0x0605D6E4u; c.r[6] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D6E4u) return; }  // 0605D6E0 jsr @r0 ; mov r8,r6
    c.r[1] = c.r[0] & 0xFFu;  // 0605D6E4 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D6E6 tst r1,r1
    { const bool k = c.t; c.r[10] = 0x2u; if (k) { goto L_0605D6EE; } }  // 0605D6E8 bt/s 0x0605D6EE ; mov #2,r10
    c.r[10] = 0x1u;  // 0605D6EC mov #1,r10
L_0605D6EE:
    c.r[10] += c.r[10];  // 0605D6EE add r10,r10
    c.r[10] += 1;  // 0605D6F0 add #1,r10
    c.r[14] += 48;  // 0605D6F2 add #48,r14
    c.r[15] = c.r[14];  // 0605D6F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D6F6 lds.l @r15+,pr
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D710u);  // 0605D6F8 mov.w 0x0605D710,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D6FA mov.l @r15+,r14
    c.r[10] |= c.r[1];  // 0605D6FC or r1,r10
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605D6FE mov.l @r15+,r11
    c.r[0] = c.r[10];  // 0605D700 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605D702 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605D704 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D706 rts ; mov.l @r15+,r8
}

void f_0605D748(SH2Context& c) {
    ran[1429] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D748 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D74A sts.l pr,@-r15
    c.r[15] -= 48;  // 0605D74C add #-48,r15
    c.r[1] = ld32(0x0605D79Cu);  // 0605D74E mov.l 0x0605D79C,r1
    c.r[2] = ld32(c.r[1]);  // 0605D750 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0605D752 mov r15,r14
    c.r[1] = ld32(0x0605D7A0u);  // 0605D754 mov.l 0x0605D7A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D756 mov.b @r1,r1
    c.r[4] = c.r[14];  // 0605D758 mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0605D75A extu.b r1,r1
    c.r[1] += c.r[1];  // 0605D75C add r1,r1
    c.r[2] += c.r[1];  // 0605D75E add r1,r2
    c.r[2] += 1;  // 0605D760 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D762 mov.b @r2,r5
    c.r[1] = ld32(0x0605D7A4u);  // 0605D764 mov.l 0x0605D7A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D76Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D76Au) return; }  // 0605D766 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0605D7A8u);  // 0605D76A mov.l 0x0605D7A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D76C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605D76E extu.b r1,r0
    c.r[1] = ld32(0x0605D7ACu);  // 0605D770 mov.l 0x0605D7AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D772 mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605D774 extu.b r1,r0
    c.r[1] = c.r[14];  // 0605D776 mov r14,r1
    c.r[1] += 24;  // 0605D778 add #24,r1
    c.r[14] += 48;  // 0605D77A add #48,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D77C mov.b @(r0,r1),r1
    c.r[15] = c.r[14];  // 0605D77E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D780 lds.l @r15+,pr
    c.r[0] = c.r[1] & 0xFFu;  // 0605D782 extu.b r1,r0
    c.r[1] = ld32(0x0605D7B0u);  // 0605D784 mov.l 0x0605D7B0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D786 mov.b @(r0,r1),r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D788 mov.l @r15+,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0605D78A extu.b r1,r1
    c.r[0] = c.r[1];  // 0605D78C mov r1,r0
    c.r[0] += c.r[0];  // 0605D78E add r0,r0
    c.r[0] += 1;  // 0605D790 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D798u);  // 0605D792 mov.w 0x0605D798,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605D794 rts ; or r1,r0
}

void f_0605D7B4(SH2Context& c) {
    ran[1430] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D7B4 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D7F4u);  // 0605D7B6 mov.l 0x0605D7F4,r1
    c.r[1] = ld32(c.r[1]);  // 0605D7B8 mov.l @r1,r1
    c.r[1] += 1;  // 0605D7BA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D7BC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605D7BE extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0605D7C0 cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605D7D6; } }  // 0605D7C2 bf/s 0x0605D7D6 ; mov r15,r14
    c.r[1] = ld32(0x0605D7F8u);  // 0605D7C6 mov.l 0x0605D7F8,r1
    c.r[1] = ld32(c.r[1]);  // 0605D7C8 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D7CA tst r1,r1
    if (c.t) { goto L_0605D7E8; }  // 0605D7CC bt 0x0605D7E8
    c.r[15] = c.r[14];  // 0605D7CE mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D7F0u);  // 0605D7D0 mov.w 0x0605D7F0,r0
    goto L_0605D7EC;  // 0605D7D2 bra 0x0605D7EC ; nop
L_0605D7D6:
    c.r[1] = ld32(0x0605D7FCu);  // 0605D7D6 mov.l 0x0605D7FC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605D7D8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605D7DA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D7DC tst r1,r1
    if (c.t) { goto L_0605D7E8; }  // 0605D7DE bt 0x0605D7E8
    c.r[15] = c.r[14];  // 0605D7E0 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D7F0u);  // 0605D7E2 mov.w 0x0605D7F0,r0
    goto L_0605D7EC;  // 0605D7E4 bra 0x0605D7EC ; nop
L_0605D7E8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D7F2u);  // 0605D7E8 mov.w 0x0605D7F2,r0
    c.r[15] = c.r[14];  // 0605D7EA mov r14,r15
L_0605D7EC:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D7EC rts ; mov.l @r15+,r14
}

void f_0605D800(SH2Context& c) {
    ran[1431] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D800 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605D802 mov r15,r14
    c.r[1] = ld32(0x0605D890u);  // 0605D804 mov.l 0x0605D890,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D806 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605D808 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D888u);  // 0605D80A mov.w 0x0605D888,r1
    c.t = c.r[3] == c.r[1];  // 0605D80C cmp/eq r1,r3
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_0605D878; } }  // 0605D80E bt/s 0x0605D878 ; mov #1,r5
    c.r[1] = ld32(0x0605D894u);  // 0605D812 mov.l 0x0605D894,r1
    c.r[2] = ld32(c.r[1]);  // 0605D814 mov.l @r1,r2
    c.r[1] = c.r[3];  // 0605D816 mov r3,r1
    c.r[1] <<= 2;  // 0605D818 shll2 r1
    c.r[1] <<= 2;  // 0605D81A shll2 r1
    c.r[3] = c.r[1];  // 0605D81C mov r1,r3
    c.r[3] += c.r[2];  // 0605D81E add r2,r3
    c.r[0] = c.r[1];  // 0605D820 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605D822 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0605D824 add #1,r3
    c.r[7] = c.r[1] & 0xFFu;  // 0605D826 extu.b r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605D828 mov.b @r3,r1
    c.r[2] = ld32(0x0605D898u);  // 0605D82A mov.l 0x0605D898,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0605D82C extu.b r1,r6
    c.r[1] = c.r[2];  // 0605D82E mov r2,r1
    c.r[1] += 78;  // 0605D830 add #78,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D832 mov.b @r1,r3
    c.r[0] = c.r[2];  // 0605D834 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D88Au);  // 0605D836 mov.w 0x0605D88A,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D838 mov.b @(r0,r1),r4
    c.r[1] = c.r[4] & 0xFFu;  // 0605D83A extu.b r4,r1
    c.r[1] >>= 2;  // 0605D83C shlr2 r1
    c.r[1] >>= 2;  // 0605D83E shlr2 r1
    c.r[1] += c.r[3];  // 0605D840 add r3,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 0605D842 cmp/ge r1,r7
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_0605D876; } }  // 0605D844 bf/s 0x0605D876 ; mov r4,r0
    c.r[0] &= 0xFu;  // 0605D848 and #15,r0
    c.r[0] -= 20;  // 0605D84A add #-20,r0
    c.r[3] -= c.r[0];  // 0605D84C sub r0,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 0605D84E cmp/ge r3,r7
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0605D876; } }  // 0605D850 bt/s 0x0605D876 ; mov r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605D88Cu);  // 0605D854 mov.w 0x0605D88C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605D856 mov.b @(r0,r2),r2
    c.r[1] += 79;  // 0605D858 add #79,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D85A mov.b @r1,r3
    c.r[1] = c.r[2] & 0xFFu;  // 0605D85C extu.b r2,r1
    c.r[1] >>= 2;  // 0605D85E shlr2 r1
    c.r[1] >>= 2;  // 0605D860 shlr2 r1
    c.r[1] += c.r[3];  // 0605D862 add r3,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0605D864 cmp/ge r1,r6
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0605D876; } }  // 0605D866 bf/s 0x0605D876 ; mov r2,r0
    c.r[0] &= 0xFu;  // 0605D86A and #15,r0
    c.r[0] -= 14;  // 0605D86C add #-14,r0
    c.r[3] -= c.r[0];  // 0605D86E sub r0,r3
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[3];  // 0605D870 cmp/ge r3,r6
    { const bool k = !c.t; c.r[5] += c.r[5]; if (k) { goto L_0605D87A; } }  // 0605D872 bf/s 0x0605D87A ; add r5,r5
L_0605D876:
    c.r[5] = 0x0u;  // 0605D876 mov #0,r5
L_0605D878:
    c.r[5] += c.r[5];  // 0605D878 add r5,r5
L_0605D87A:
    c.r[5] += 1;  // 0605D87A add #1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D88Eu);  // 0605D87C mov.w 0x0605D88E,r1
    c.r[5] |= c.r[1];  // 0605D87E or r1,r5
    c.r[15] = c.r[14];  // 0605D880 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D882 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0605D884 rts ; mov r5,r0
}

void f_0605D89C(SH2Context& c) {
    ran[1432] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D89C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605D89E mov r15,r14
    c.r[1] = ld32(0x0605D8BCu);  // 0605D8A0 mov.l 0x0605D8BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D8A2 mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D8A4 mov.l @r15+,r14
    c.r[0] = c.r[1];  // 0605D8A6 mov r1,r0
    c.r[0] >>= 2;  // 0605D8A8 shlr2 r0
    c.r[0] >>= 2;  // 0605D8AA shlr2 r0
    c.r[0] >>= 2;  // 0605D8AC shlr2 r0
    c.r[0] &= 0x2u;  // 0605D8AE and #2,r0
    c.r[0] += 1;  // 0605D8B0 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D8B8u);  // 0605D8B2 mov.w 0x0605D8B8,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605D8B4 rts ; or r1,r0
}

void f_0605D8C0(SH2Context& c) {
    ran[1433] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605D8C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605D8C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D8C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605D8C6 sts.l pr,@-r15
    c.r[1] = ld32(0x0605D968u);  // 0605D8C8 mov.l 0x0605D968,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D8CA mov.b @r1,r2
    c.r[14] = c.r[15];  // 0605D8CC mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0605D8CE extu.b r2,r2
    c.r[1] = ld32(0x0605D96Cu);  // 0605D8D0 mov.l 0x0605D96C,r1
    c.r[1] = ld32(c.r[1]);  // 0605D8D2 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605D8D4 shll2 r2
    c.r[2] <<= 2;  // 0605D8D6 shll2 r2
    c.r[2] += c.r[1];  // 0605D8D8 add r1,r2
    c.r[2] += 2;  // 0605D8DA add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605D8DC mov.b @r2,r2
    c.r[1] = ld32(0x0605D970u);  // 0605D8DE mov.l 0x0605D970,r1
    c.r[3] = ld32(c.r[1]);  // 0605D8E0 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605D8E2 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605D8E4 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605D8E6 mul.l r1,r2
    c.r[4] = ld32(0x0605D974u);  // 0605D8E8 mov.l 0x0605D974,r4
    c.r[9] = ld32(0x0605D978u);  // 0605D8EA mov.l 0x0605D978,r9
    c.r[1] = c.macl;  // 0605D8EC sts macl,r1
    c.r[0] = c.r[1];  // 0605D8EE mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605D8F0 mov.w @(r0,r3),r8
    c.r[5] = 0x1Bu;  // 0605D8F2 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605D8F8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D8F8u) return; }  // 0605D8F4 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0605D8F8 mov r0,r1
    c.r[5] = c.r[8];  // 0605D8FA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605D900u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D900u) return; }  // 0605D8FC jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0605D900 mov r0,r1
    c.r[1] += 25;  // 0605D902 add #25,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605D960u);  // 0605D904 mov.w 0x0605D960,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D906 mov.b @r1,r1
    c.r[4] = 0x1u;  // 0605D908 mov #1,r4
    c.r[8] &= c.r[1];  // 0605D90A and r1,r8
    c.r[8] >>= 2;  // 0605D90C shlr2 r8
    c.r[8] >>= 2;  // 0605D90E shlr2 r8
    c.r[8] >>= 2;  // 0605D910 shlr2 r8
    c.t = c.r[8] > c.r[4];  // 0605D912 cmp/hi r4,r8
    if (c.t) { goto L_0605D94A; }  // 0605D914 bt 0x0605D94A
    c.r[1] = ld32(0x0605D97Cu);  // 0605D916 mov.l 0x0605D97C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D918 mov.b @r1,r0
    c.r[1] = 0xFu;  // 0605D91A mov #15,r1
    c.r[1] &= c.r[0];  // 0605D91C and r0,r1
    c.r[0] = ld32(0x0605D980u);  // 0605D91E mov.l 0x0605D980,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605D924u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D924u) return; }  // 0605D920 jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605D962u);  // 0605D924 mov.w 0x0605D962,r4
    c.r[1] = ld32(0x0605D984u);  // 0605D926 mov.l 0x0605D984,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D92Cu; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D92Cu) return; }  // 0605D928 jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 0605D92C mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605D964u);  // 0605D92E mov.w 0x0605D964,r4
    c.r[1] = ld32(0x0605D988u);  // 0605D930 mov.l 0x0605D988,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D936u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D936u) return; }  // 0605D932 jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 0605D936 or r4,r2
    c.r[0] &= 0x80u;  // 0605D938 and #128,r0
    c.r[1] = ld32(0x0605D98Cu);  // 0605D93A mov.l 0x0605D98C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605D940u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605D940u) return; }  // 0605D93C jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 0605D940 or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605D942 tst r2,r2
    { const bool k = !c.t; c.r[0] = 0x4u; if (k) { goto L_0605D94A; } }  // 0605D944 bf/s 0x0605D94A ; mov #4,r0
    c.r[8] |= c.r[0];  // 0605D948 or r0,r8
L_0605D94A:
    c.r[8] += c.r[8];  // 0605D94A add r8,r8
    c.r[8] += 1;  // 0605D94C add #1,r8
    c.r[15] = c.r[14];  // 0605D94E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605D950 lds.l @r15+,pr
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D966u);  // 0605D952 mov.w 0x0605D966,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D954 mov.l @r15+,r14
    c.r[8] |= c.r[1];  // 0605D956 or r1,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605D958 mov.l @r15+,r9
    c.r[0] = c.r[8] & 0xFFFFu;  // 0605D95A extu.w r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605D95C rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
