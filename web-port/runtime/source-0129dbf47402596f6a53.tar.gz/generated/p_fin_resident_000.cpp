#include "p_fin_resident_funcs.h"

namespace p_fin_resident {

void f_060D9EF0(SH2Context& c) {
    ran[0] = 1;
L_060D9EF0:
    c.r[1] = ld32(0x060DA040u);  // 060D9EF0 mov.l 0x060DA040,r1
L_060D9EF2:
    c.r[1] = ld32(c.r[1]);  // 060D9EF2 mov.l @r1,r1
L_060D9EF4:
    c.r[2] = ld32(0x060DA044u);  // 060D9EF4 mov.l 0x060DA044,r2
L_060D9EF6:
    c.t = c.r[1] == c.r[2];  // 060D9EF6 cmp/eq r2,r1
L_060D9EF8:
    if (!c.t) { goto L_060D9FE0; }  // 060D9EF8 bf 0x060D9FE0
L_060D9EFA:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060D9EFA sts.l pr,@-r15
L_060D9EFC:
    c.r[1] = ld32(0x060DA048u);  // 060D9EFC mov.l 0x060DA048,r1
L_060D9EFE:
    c.r[0] = 0x1u;  // 060D9EFE mov #1,r0
L_060D9F00:
    st8(c.r[1], c.r[0]);  // 060D9F00 mov.b r0,@r1
L_060D9F02:
    c.r[1] = ld32(0x060DA04Cu);  // 060D9F02 mov.l 0x060DA04C,r1
L_060D9F04:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F04 mov.b @r1,r0
L_060D9F06:
    c.r[2] = ld32(0x060DA050u);  // 060D9F06 mov.l 0x060DA050,r2
L_060D9F08:
    st8(c.r[2], c.r[0]);  // 060D9F08 mov.b r0,@r2
L_060D9F0A:
    c.r[0] &= 0x3Fu;  // 060D9F0A and #63,r0
L_060D9F0C:
    st8(c.r[1], c.r[0]);  // 060D9F0C mov.b r0,@r1
L_060D9F0E:
    c.r[1] = ld32(0x060DA054u);  // 060D9F0E mov.l 0x060DA054,r1
L_060D9F10:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F10 mov.b @r1,r0
L_060D9F12:
    c.r[0] = c.r[0] & 0xFFu;  // 060D9F12 extu.b r0,r0
L_060D9F14:
    c.t = c.r[0] == 0xFFFFFFFBu;  // 060D9F14 cmp/eq #-5,r0
L_060D9F16:
    if (c.t) { goto L_060D9F6E; }  // 060D9F16 bt 0x060D9F6E
L_060D9F18:
    c.t = c.r[0] == 0xFFFFFFFCu;  // 060D9F18 cmp/eq #-4,r0
L_060D9F1A:
    if (c.t) { goto L_060D9F6E; }  // 060D9F1A bt 0x060D9F6E
L_060D9F1C:
    c.t = c.r[0] == 0xFFFFFFFDu;  // 060D9F1C cmp/eq #-3,r0
L_060D9F1E:
    if (c.t) { goto L_060D9F6E; }  // 060D9F1E bt 0x060D9F6E
L_060D9F20:
    c.r[1] = ld32(0x060DA058u);  // 060D9F20 mov.l 0x060DA058,r1
L_060D9F22:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F22 mov.b @r1,r2
L_060D9F24:
    c.r[0] = c.r[2];  // 060D9F24 mov r2,r0
L_060D9F26:
    c.r[0] &= 0x40u;  // 060D9F26 and #64,r0
L_060D9F28:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F28 tst r0,r0
L_060D9F2A:
    if (c.t) { goto L_060D9F6E; }  // 060D9F2A bt 0x060D9F6E
L_060D9F2C:
    c.r[0] = c.r[2];  // 060D9F2C mov r2,r0
L_060D9F2E:
    c.r[0] &= 0x20u;  // 060D9F2E and #32,r0
L_060D9F30:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F30 tst r0,r0
L_060D9F32:
    if (c.t) { goto L_060D9F3A; }  // 060D9F32 bt 0x060D9F3A
L_060D9F34:
    c.r[5] = 0x38u;  // 060D9F34 mov #56,r5
L_060D9F36:
    goto L_060D9F4C;  // 060D9F36 bra 0x060D9F4C ; nop
L_060D9F3A:
    c.r[0] = c.r[2];  // 060D9F3A mov r2,r0
L_060D9F3C:
    c.r[0] >>= 2;  // 060D9F3C shlr2 r0
L_060D9F3E:
    c.r[0] &= 0x3u;  // 060D9F3E and #3,r0
L_060D9F40:
    c.t = c.r[0] == 0x2u;  // 060D9F40 cmp/eq #2,r0
L_060D9F42:
    if (!c.t) { goto L_060D9F4A; }  // 060D9F42 bf 0x060D9F4A
L_060D9F44:
    c.r[5] = 0xFu;  // 060D9F44 mov #15,r5
L_060D9F46:
    goto L_060D9F4C;  // 060D9F46 bra 0x060D9F4C ; nop
L_060D9F4A:
    c.r[5] = 0x37u;  // 060D9F4A mov #55,r5
L_060D9F4C:
    c.r[1] += 2;  // 060D9F4C add #2,r1
L_060D9F4E:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060D9F4E mov.w @r1,r6
L_060D9F50:
    c.r[6] = c.r[6] & 0xFFFFu;  // 060D9F50 extu.w r6,r6
L_060D9F52:
    c.r[6] = 0u - c.r[6];  // 060D9F52 neg r6,r6
L_060D9F54:
    c.r[1] = ld32(0x060DA05Cu);  // 060D9F54 mov.l 0x060DA05C,r1
L_060D9F56:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F56 mov.b @r1,r4
L_060D9F58:
    c.r[4] = c.r[4] & 0xFFu;  // 060D9F58 extu.b r4,r4
L_060D9F5A:
    c.r[1] = ld32(0x060DA060u);  // 060D9F5A mov.l 0x060DA060,r1
L_060D9F5C:
    { const uint32_t x = c.r[1]; c.pr = 0x060D9F60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060D9F60u) return; }  // 060D9F5C jsr @r1 ; nop
L_060D9F60:
    c.r[0] = c.r[5];  // 060D9F60 mov r5,r0
L_060D9F62:
    c.t = c.r[0] == 0xFu;  // 060D9F62 cmp/eq #15,r0
L_060D9F64:
    if (!c.t) { goto L_060D9F6E; }  // 060D9F64 bf 0x060D9F6E
L_060D9F66:
    c.r[5] = 0x37u;  // 060D9F66 mov #55,r5
L_060D9F68:
    c.r[1] = ld32(0x060DA060u);  // 060D9F68 mov.l 0x060DA060,r1
L_060D9F6A:
    ;  // 060D9F6A nop
L_060D9F6C:
    ;  // 060D9F6C nop
L_060D9F6E:
    c.r[1] = ld32(0x060DA064u);  // 060D9F6E mov.l 0x060DA064,r1
L_060D9F70:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F70 mov.b @r1,r0
L_060D9F72:
    c.r[0] &= 0x10u;  // 060D9F72 and #16,r0
L_060D9F74:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F74 tst r0,r0
L_060D9F76:
    if (!c.t) { goto L_060D9FD8; }  // 060D9F76 bf 0x060D9FD8
L_060D9F78:
    c.r[1] = ld32(0x060DA068u);  // 060D9F78 mov.l 0x060DA068,r1
L_060D9F7A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F7A mov.b @r1,r0
L_060D9F7C:
    c.r[0] = c.r[0] & 0xFFu;  // 060D9F7C extu.b r0,r0
L_060D9F7E:
    c.t = c.r[0] == 0xFFFFFFFBu;  // 060D9F7E cmp/eq #-5,r0
L_060D9F80:
    if (c.t) { goto L_060D9FD8; }  // 060D9F80 bt 0x060D9FD8
L_060D9F82:
    c.t = c.r[0] == 0xFFFFFFFCu;  // 060D9F82 cmp/eq #-4,r0
L_060D9F84:
    if (c.t) { goto L_060D9FD8; }  // 060D9F84 bt 0x060D9FD8
L_060D9F86:
    c.t = c.r[0] == 0xFFFFFFFDu;  // 060D9F86 cmp/eq #-3,r0
L_060D9F88:
    if (c.t) { goto L_060D9FD8; }  // 060D9F88 bt 0x060D9FD8
L_060D9F8A:
    c.r[1] = ld32(0x060DA06Cu);  // 060D9F8A mov.l 0x060DA06C,r1
L_060D9F8C:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F8C mov.b @r1,r2
L_060D9F8E:
    c.r[0] = c.r[2];  // 060D9F8E mov r2,r0
L_060D9F90:
    c.r[0] &= 0x40u;  // 060D9F90 and #64,r0
L_060D9F92:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F92 tst r0,r0
L_060D9F94:
    if (c.t) { goto L_060D9FD8; }  // 060D9F94 bt 0x060D9FD8
L_060D9F96:
    c.r[0] = c.r[2];  // 060D9F96 mov r2,r0
L_060D9F98:
    c.r[0] &= 0x20u;  // 060D9F98 and #32,r0
L_060D9F9A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F9A tst r0,r0
L_060D9F9C:
    if (c.t) { goto L_060D9FA4; }  // 060D9F9C bt 0x060D9FA4
L_060D9F9E:
    c.r[5] = 0x38u;  // 060D9F9E mov #56,r5
L_060D9FA0:
    goto L_060D9FB6;  // 060D9FA0 bra 0x060D9FB6 ; nop
L_060D9FA4:
    c.r[0] = c.r[2];  // 060D9FA4 mov r2,r0
L_060D9FA6:
    c.r[0] >>= 2;  // 060D9FA6 shlr2 r0
L_060D9FA8:
    c.r[0] &= 0x3u;  // 060D9FA8 and #3,r0
L_060D9FAA:
    c.t = c.r[0] == 0x2u;  // 060D9FAA cmp/eq #2,r0
L_060D9FAC:
    if (!c.t) { goto L_060D9FB4; }  // 060D9FAC bf 0x060D9FB4
L_060D9FAE:
    c.r[5] = 0xFu;  // 060D9FAE mov #15,r5
L_060D9FB0:
    goto L_060D9FB6;  // 060D9FB0 bra 0x060D9FB6 ; nop
L_060D9FB4:
    c.r[5] = 0x37u;  // 060D9FB4 mov #55,r5
L_060D9FB6:
    c.r[1] += 2;  // 060D9FB6 add #2,r1
L_060D9FB8:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060D9FB8 mov.w @r1,r6
L_060D9FBA:
    c.r[6] = c.r[6] & 0xFFFFu;  // 060D9FBA extu.w r6,r6
L_060D9FBC:
    c.r[6] = 0u - c.r[6];  // 060D9FBC neg r6,r6
L_060D9FBE:
    c.r[1] = ld32(0x060DA070u);  // 060D9FBE mov.l 0x060DA070,r1
L_060D9FC0:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9FC0 mov.b @r1,r4
L_060D9FC2:
    c.r[4] = c.r[4] & 0xFFu;  // 060D9FC2 extu.b r4,r4
L_060D9FC4:
    c.r[1] = ld32(0x060DA060u);  // 060D9FC4 mov.l 0x060DA060,r1
L_060D9FC6:
    { const uint32_t x = c.r[1]; c.pr = 0x060D9FCAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060D9FCAu) return; }  // 060D9FC6 jsr @r1 ; nop
L_060D9FCA:
    c.r[0] = c.r[5];  // 060D9FCA mov r5,r0
L_060D9FCC:
    c.t = c.r[0] == 0xFu;  // 060D9FCC cmp/eq #15,r0
L_060D9FCE:
    if (!c.t) { goto L_060D9FD8; }  // 060D9FCE bf 0x060D9FD8
L_060D9FD0:
    c.r[5] = 0x37u;  // 060D9FD0 mov #55,r5
L_060D9FD2:
    c.r[1] = ld32(0x060DA060u);  // 060D9FD2 mov.l 0x060DA060,r1
L_060D9FD4:
    ;  // 060D9FD4 nop
L_060D9FD6:
    ;  // 060D9FD6 nop
L_060D9FD8:
    c.r[0] = ld32(0x060DA074u);  // 060D9FD8 mov.l 0x060DA074,r0
L_060D9FDA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060D9FDA lds.l @r15+,pr
L_060D9FDC:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060D9FDC rts ; nop
L_060D9FE0:
    c.r[0] = ld32(0x060DA078u);  // 060D9FE0 mov.l 0x060DA078,r0
L_060D9FE2:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060D9EF0u: goto L_060D9EF0; case 0x060D9EF2u: goto L_060D9EF2; case 0x060D9EF4u: goto L_060D9EF4; case 0x060D9EF6u: goto L_060D9EF6; case 0x060D9EF8u: goto L_060D9EF8; case 0x060D9EFAu: goto L_060D9EFA; case 0x060D9EFCu: goto L_060D9EFC; case 0x060D9EFEu: goto L_060D9EFE; case 0x060D9F00u: goto L_060D9F00; case 0x060D9F02u: goto L_060D9F02; case 0x060D9F04u: goto L_060D9F04; case 0x060D9F06u: goto L_060D9F06; case 0x060D9F08u: goto L_060D9F08; case 0x060D9F0Au: goto L_060D9F0A; case 0x060D9F0Cu: goto L_060D9F0C; case 0x060D9F0Eu: goto L_060D9F0E; case 0x060D9F10u: goto L_060D9F10; case 0x060D9F12u: goto L_060D9F12; case 0x060D9F14u: goto L_060D9F14; case 0x060D9F16u: goto L_060D9F16; case 0x060D9F18u: goto L_060D9F18; case 0x060D9F1Au: goto L_060D9F1A; case 0x060D9F1Cu: goto L_060D9F1C; case 0x060D9F1Eu: goto L_060D9F1E; case 0x060D9F20u: goto L_060D9F20; case 0x060D9F22u: goto L_060D9F22; case 0x060D9F24u: goto L_060D9F24; case 0x060D9F26u: goto L_060D9F26; case 0x060D9F28u: goto L_060D9F28; case 0x060D9F2Au: goto L_060D9F2A; case 0x060D9F2Cu: goto L_060D9F2C; case 0x060D9F2Eu: goto L_060D9F2E; case 0x060D9F30u: goto L_060D9F30; case 0x060D9F32u: goto L_060D9F32; case 0x060D9F34u: goto L_060D9F34; case 0x060D9F36u: goto L_060D9F36; case 0x060D9F3Au: goto L_060D9F3A; case 0x060D9F3Cu: goto L_060D9F3C; case 0x060D9F3Eu: goto L_060D9F3E; case 0x060D9F40u: goto L_060D9F40; case 0x060D9F42u: goto L_060D9F42; case 0x060D9F44u: goto L_060D9F44; case 0x060D9F46u: goto L_060D9F46; case 0x060D9F4Au: goto L_060D9F4A; case 0x060D9F4Cu: goto L_060D9F4C; case 0x060D9F4Eu: goto L_060D9F4E; case 0x060D9F50u: goto L_060D9F50; case 0x060D9F52u: goto L_060D9F52; case 0x060D9F54u: goto L_060D9F54; case 0x060D9F56u: goto L_060D9F56; case 0x060D9F58u: goto L_060D9F58; case 0x060D9F5Au: goto L_060D9F5A; case 0x060D9F5Cu: goto L_060D9F5C; case 0x060D9F60u: goto L_060D9F60; case 0x060D9F62u: goto L_060D9F62; case 0x060D9F64u: goto L_060D9F64; case 0x060D9F66u: goto L_060D9F66; case 0x060D9F68u: goto L_060D9F68; case 0x060D9F6Au: goto L_060D9F6A; case 0x060D9F6Cu: goto L_060D9F6C; case 0x060D9F6Eu: goto L_060D9F6E; case 0x060D9F70u: goto L_060D9F70; case 0x060D9F72u: goto L_060D9F72; case 0x060D9F74u: goto L_060D9F74; case 0x060D9F76u: goto L_060D9F76; case 0x060D9F78u: goto L_060D9F78; case 0x060D9F7Au: goto L_060D9F7A; case 0x060D9F7Cu: goto L_060D9F7C; case 0x060D9F7Eu: goto L_060D9F7E; case 0x060D9F80u: goto L_060D9F80; case 0x060D9F82u: goto L_060D9F82; case 0x060D9F84u: goto L_060D9F84; case 0x060D9F86u: goto L_060D9F86; case 0x060D9F88u: goto L_060D9F88; case 0x060D9F8Au: goto L_060D9F8A; case 0x060D9F8Cu: goto L_060D9F8C; case 0x060D9F8Eu: goto L_060D9F8E; case 0x060D9F90u: goto L_060D9F90; case 0x060D9F92u: goto L_060D9F92; case 0x060D9F94u: goto L_060D9F94; case 0x060D9F96u: goto L_060D9F96; case 0x060D9F98u: goto L_060D9F98; case 0x060D9F9Au: goto L_060D9F9A; case 0x060D9F9Cu: goto L_060D9F9C; case 0x060D9F9Eu: goto L_060D9F9E; case 0x060D9FA0u: goto L_060D9FA0; case 0x060D9FA4u: goto L_060D9FA4; case 0x060D9FA6u: goto L_060D9FA6; case 0x060D9FA8u: goto L_060D9FA8; case 0x060D9FAAu: goto L_060D9FAA; case 0x060D9FACu: goto L_060D9FAC; case 0x060D9FAEu: goto L_060D9FAE; case 0x060D9FB0u: goto L_060D9FB0; case 0x060D9FB4u: goto L_060D9FB4; case 0x060D9FB6u: goto L_060D9FB6; case 0x060D9FB8u: goto L_060D9FB8; case 0x060D9FBAu: goto L_060D9FBA; case 0x060D9FBCu: goto L_060D9FBC; case 0x060D9FBEu: goto L_060D9FBE; case 0x060D9FC0u: goto L_060D9FC0; case 0x060D9FC2u: goto L_060D9FC2; case 0x060D9FC4u: goto L_060D9FC4; case 0x060D9FC6u: goto L_060D9FC6; case 0x060D9FCAu: goto L_060D9FCA; case 0x060D9FCCu: goto L_060D9FCC; case 0x060D9FCEu: goto L_060D9FCE; case 0x060D9FD0u: goto L_060D9FD0; case 0x060D9FD2u: goto L_060D9FD2; case 0x060D9FD4u: goto L_060D9FD4; case 0x060D9FD6u: goto L_060D9FD6; case 0x060D9FD8u: goto L_060D9FD8; case 0x060D9FDAu: goto L_060D9FDA; case 0x060D9FDCu: goto L_060D9FDC; case 0x060D9FE0u: goto L_060D9FE0; case 0x060D9FE2u: goto L_060D9FE2; default: sh2_call(c, x); return; } }  // 060D9FE2 jmp @r0 ; nop
}

void f_060D9EFA(SH2Context& c) {
    ran[1] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060D9EFA sts.l pr,@-r15
    c.r[1] = ld32(0x060DA048u);  // 060D9EFC mov.l 0x060DA048,r1
    c.r[0] = 0x1u;  // 060D9EFE mov #1,r0
    st8(c.r[1], c.r[0]);  // 060D9F00 mov.b r0,@r1
    c.r[1] = ld32(0x060DA04Cu);  // 060D9F02 mov.l 0x060DA04C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F04 mov.b @r1,r0
    c.r[2] = ld32(0x060DA050u);  // 060D9F06 mov.l 0x060DA050,r2
    st8(c.r[2], c.r[0]);  // 060D9F08 mov.b r0,@r2
    c.r[0] &= 0x3Fu;  // 060D9F0A and #63,r0
    st8(c.r[1], c.r[0]);  // 060D9F0C mov.b r0,@r1
    c.r[1] = ld32(0x060DA054u);  // 060D9F0E mov.l 0x060DA054,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F10 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060D9F12 extu.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFBu;  // 060D9F14 cmp/eq #-5,r0
    if (c.t) { goto L_060D9F6E; }  // 060D9F16 bt 0x060D9F6E
    c.t = c.r[0] == 0xFFFFFFFCu;  // 060D9F18 cmp/eq #-4,r0
    if (c.t) { goto L_060D9F6E; }  // 060D9F1A bt 0x060D9F6E
    c.t = c.r[0] == 0xFFFFFFFDu;  // 060D9F1C cmp/eq #-3,r0
    if (c.t) { goto L_060D9F6E; }  // 060D9F1E bt 0x060D9F6E
    c.r[1] = ld32(0x060DA058u);  // 060D9F20 mov.l 0x060DA058,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F22 mov.b @r1,r2
    c.r[0] = c.r[2];  // 060D9F24 mov r2,r0
    c.r[0] &= 0x40u;  // 060D9F26 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F28 tst r0,r0
    if (c.t) { goto L_060D9F6E; }  // 060D9F2A bt 0x060D9F6E
    c.r[0] = c.r[2];  // 060D9F2C mov r2,r0
    c.r[0] &= 0x20u;  // 060D9F2E and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F30 tst r0,r0
    if (c.t) { goto L_060D9F3A; }  // 060D9F32 bt 0x060D9F3A
    c.r[5] = 0x38u;  // 060D9F34 mov #56,r5
    goto L_060D9F4C;  // 060D9F36 bra 0x060D9F4C ; nop
L_060D9F3A:
    c.r[0] = c.r[2];  // 060D9F3A mov r2,r0
    c.r[0] >>= 2;  // 060D9F3C shlr2 r0
    c.r[0] &= 0x3u;  // 060D9F3E and #3,r0
    c.t = c.r[0] == 0x2u;  // 060D9F40 cmp/eq #2,r0
    if (!c.t) { goto L_060D9F4A; }  // 060D9F42 bf 0x060D9F4A
    c.r[5] = 0xFu;  // 060D9F44 mov #15,r5
    goto L_060D9F4C;  // 060D9F46 bra 0x060D9F4C ; nop
L_060D9F4A:
    c.r[5] = 0x37u;  // 060D9F4A mov #55,r5
L_060D9F4C:
    c.r[1] += 2;  // 060D9F4C add #2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060D9F4E mov.w @r1,r6
    c.r[6] = c.r[6] & 0xFFFFu;  // 060D9F50 extu.w r6,r6
    c.r[6] = 0u - c.r[6];  // 060D9F52 neg r6,r6
    c.r[1] = ld32(0x060DA05Cu);  // 060D9F54 mov.l 0x060DA05C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F56 mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060D9F58 extu.b r4,r4
    c.r[1] = ld32(0x060DA060u);  // 060D9F5A mov.l 0x060DA060,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060D9F60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060D9F60u) return; }  // 060D9F5C jsr @r1 ; nop
    c.r[0] = c.r[5];  // 060D9F60 mov r5,r0
    c.t = c.r[0] == 0xFu;  // 060D9F62 cmp/eq #15,r0
    if (!c.t) { goto L_060D9F6E; }  // 060D9F64 bf 0x060D9F6E
    c.r[5] = 0x37u;  // 060D9F66 mov #55,r5
    c.r[1] = ld32(0x060DA060u);  // 060D9F68 mov.l 0x060DA060,r1
    ;  // 060D9F6A nop
    ;  // 060D9F6C nop
L_060D9F6E:
    c.r[1] = ld32(0x060DA064u);  // 060D9F6E mov.l 0x060DA064,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F70 mov.b @r1,r0
    c.r[0] &= 0x10u;  // 060D9F72 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F74 tst r0,r0
    if (!c.t) { goto L_060D9FD8; }  // 060D9F76 bf 0x060D9FD8
    c.r[1] = ld32(0x060DA068u);  // 060D9F78 mov.l 0x060DA068,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F7A mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060D9F7C extu.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFBu;  // 060D9F7E cmp/eq #-5,r0
    if (c.t) { goto L_060D9FD8; }  // 060D9F80 bt 0x060D9FD8
    c.t = c.r[0] == 0xFFFFFFFCu;  // 060D9F82 cmp/eq #-4,r0
    if (c.t) { goto L_060D9FD8; }  // 060D9F84 bt 0x060D9FD8
    c.t = c.r[0] == 0xFFFFFFFDu;  // 060D9F86 cmp/eq #-3,r0
    if (c.t) { goto L_060D9FD8; }  // 060D9F88 bt 0x060D9FD8
    c.r[1] = ld32(0x060DA06Cu);  // 060D9F8A mov.l 0x060DA06C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9F8C mov.b @r1,r2
    c.r[0] = c.r[2];  // 060D9F8E mov r2,r0
    c.r[0] &= 0x40u;  // 060D9F90 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F92 tst r0,r0
    if (c.t) { goto L_060D9FD8; }  // 060D9F94 bt 0x060D9FD8
    c.r[0] = c.r[2];  // 060D9F96 mov r2,r0
    c.r[0] &= 0x20u;  // 060D9F98 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9F9A tst r0,r0
    if (c.t) { goto L_060D9FA4; }  // 060D9F9C bt 0x060D9FA4
    c.r[5] = 0x38u;  // 060D9F9E mov #56,r5
    goto L_060D9FB6;  // 060D9FA0 bra 0x060D9FB6 ; nop
L_060D9FA4:
    c.r[0] = c.r[2];  // 060D9FA4 mov r2,r0
    c.r[0] >>= 2;  // 060D9FA6 shlr2 r0
    c.r[0] &= 0x3u;  // 060D9FA8 and #3,r0
    c.t = c.r[0] == 0x2u;  // 060D9FAA cmp/eq #2,r0
    if (!c.t) { goto L_060D9FB4; }  // 060D9FAC bf 0x060D9FB4
    c.r[5] = 0xFu;  // 060D9FAE mov #15,r5
    goto L_060D9FB6;  // 060D9FB0 bra 0x060D9FB6 ; nop
L_060D9FB4:
    c.r[5] = 0x37u;  // 060D9FB4 mov #55,r5
L_060D9FB6:
    c.r[1] += 2;  // 060D9FB6 add #2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060D9FB8 mov.w @r1,r6
    c.r[6] = c.r[6] & 0xFFFFu;  // 060D9FBA extu.w r6,r6
    c.r[6] = 0u - c.r[6];  // 060D9FBC neg r6,r6
    c.r[1] = ld32(0x060DA070u);  // 060D9FBE mov.l 0x060DA070,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9FC0 mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060D9FC2 extu.b r4,r4
    c.r[1] = ld32(0x060DA060u);  // 060D9FC4 mov.l 0x060DA060,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060D9FCAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060D9FCAu) return; }  // 060D9FC6 jsr @r1 ; nop
    c.r[0] = c.r[5];  // 060D9FCA mov r5,r0
    c.t = c.r[0] == 0xFu;  // 060D9FCC cmp/eq #15,r0
    if (!c.t) { goto L_060D9FD8; }  // 060D9FCE bf 0x060D9FD8
    c.r[5] = 0x37u;  // 060D9FD0 mov #55,r5
    c.r[1] = ld32(0x060DA060u);  // 060D9FD2 mov.l 0x060DA060,r1
    ;  // 060D9FD4 nop
    ;  // 060D9FD6 nop
L_060D9FD8:
    c.r[0] = ld32(0x060DA074u);  // 060D9FD8 mov.l 0x060DA074,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060D9FDA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060D9FDC rts ; nop
}

void f_060D9FE6(SH2Context& c) {
    ran[2] = 1;
L_060D9FE6:
    c.r[1] = ld32(0x060DA048u);  // 060D9FE6 mov.l 0x060DA048,r1
L_060D9FE8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9FE8 mov.b @r1,r0
L_060D9FEA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9FEA tst r0,r0
L_060D9FEC:
    if (c.t) { goto L_060DA000; }  // 060D9FEC bt 0x060DA000
L_060D9FEE:
    c.r[1] = ld32(0x060DA040u);  // 060D9FEE mov.l 0x060DA040,r1
L_060D9FF0:
    c.r[1] = ld32(c.r[1]);  // 060D9FF0 mov.l @r1,r1
L_060D9FF2:
    c.r[1] += 1;  // 060D9FF2 add #1,r1
L_060D9FF4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060D9FF4 mov.b @r1,r0
L_060D9FF6:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060D9FF6 tst r0,r0
L_060D9FF8:
    if (!c.t) { goto L_060DA000; }  // 060D9FF8 bf 0x060DA000
L_060D9FFA:
    c.r[0] = ld32(0x060DA07Cu);  // 060D9FFA mov.l 0x060DA07C,r0
L_060D9FFC:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060D9FFC rts ; nop
L_060DA000:
    c.r[0] = ld32(0x060DA080u);  // 060DA000 mov.l 0x060DA080,r0
L_060DA002:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060D9FE6u: goto L_060D9FE6; case 0x060D9FE8u: goto L_060D9FE8; case 0x060D9FEAu: goto L_060D9FEA; case 0x060D9FECu: goto L_060D9FEC; case 0x060D9FEEu: goto L_060D9FEE; case 0x060D9FF0u: goto L_060D9FF0; case 0x060D9FF2u: goto L_060D9FF2; case 0x060D9FF4u: goto L_060D9FF4; case 0x060D9FF6u: goto L_060D9FF6; case 0x060D9FF8u: goto L_060D9FF8; case 0x060D9FFAu: goto L_060D9FFA; case 0x060D9FFCu: goto L_060D9FFC; case 0x060DA000u: goto L_060DA000; case 0x060DA002u: goto L_060DA002; default: sh2_call(c, x); return; } }  // 060DA002 jmp @r0 ; nop
}

void f_060DA006(SH2Context& c) {
    ran[3] = 1;
L_060DA006:
    c.r[1] = ld32(0x060DA048u);  // 060DA006 mov.l 0x060DA048,r1
L_060DA008:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA008 mov.b @r1,r0
L_060DA00A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA00A tst r0,r0
L_060DA00C:
    if (c.t) { goto L_060DA016; }  // 060DA00C bt 0x060DA016
L_060DA00E:
    goto L_060DA02C;  // 060DA00E bra 0x060DA02C ; nop
L_060DA016:
    c.r[1] = ld32(0x060DA048u);  // 060DA016 mov.l 0x060DA048,r1
L_060DA018:
    c.r[0] = 0x0u;  // 060DA018 mov #0,r0
L_060DA01A:
    st8(c.r[1], c.r[0]);  // 060DA01A mov.b r0,@r1
L_060DA01C:
    c.r[0] = ld32(0x060DA084u);  // 060DA01C mov.l 0x060DA084,r0
L_060DA01E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA006u: goto L_060DA006; case 0x060DA008u: goto L_060DA008; case 0x060DA00Au: goto L_060DA00A; case 0x060DA00Cu: goto L_060DA00C; case 0x060DA00Eu: goto L_060DA00E; case 0x060DA016u: goto L_060DA016; case 0x060DA018u: goto L_060DA018; case 0x060DA01Au: goto L_060DA01A; case 0x060DA01Cu: goto L_060DA01C; case 0x060DA01Eu: goto L_060DA01E; case 0x060DA02Cu: goto L_060DA02C; case 0x060DA02Eu: goto L_060DA02E; case 0x060DA030u: goto L_060DA030; case 0x060DA032u: goto L_060DA032; case 0x060DA034u: goto L_060DA034; case 0x060DA036u: goto L_060DA036; case 0x060DA038u: goto L_060DA038; case 0x060DA03Au: goto L_060DA03A; case 0x060DA03Cu: goto L_060DA03C; default: sh2_call(c, x); return; } }  // 060DA01E jmp @r0 ; nop
L_060DA02C:
    c.r[1] = ld32(0x060DA050u);  // 060DA02C mov.l 0x060DA050,r1
L_060DA02E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA02E mov.b @r1,r0
L_060DA030:
    c.r[1] = ld32(0x060DA04Cu);  // 060DA030 mov.l 0x060DA04C,r1
L_060DA032:
    st8(c.r[1], c.r[0]);  // 060DA032 mov.b r0,@r1
L_060DA034:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DA034 mov.w @r1,r0
L_060DA036:
    c.r[2] = ld32(0x060DA088u);  // 060DA036 mov.l 0x060DA088,r2
L_060DA038:
    c.r[0] &= c.r[2];  // 060DA038 and r2,r0
L_060DA03A:
    st16(c.r[1], c.r[0]);  // 060DA03A mov.w r0,@r1
L_060DA03C:
    SH2_POLL(c); goto L_060DA016;  // 060DA03C bra 0x060DA016 ; nop
}

void f_060DA1F0(SH2Context& c) {
    ran[4] = 1;
    goto L_060DA1F0;
L_060DA08C:
    c.r[1] = ld32(0x060DA0C4u);  // 060DA08C mov.l 0x060DA0C4,r1
L_060DA08E:
    c.r[1] = ld32(c.r[1]);  // 060DA08E mov.l @r1,r1
L_060DA090:
    c.r[2] = ld32(0x060DA0C8u);  // 060DA090 mov.l 0x060DA0C8,r2
L_060DA092:
    c.r[1] += c.r[2];  // 060DA092 add r2,r1
L_060DA094:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA094 mov.b @r1,r2
L_060DA096:
    c.r[2] = c.r[2] & 0xFFu;  // 060DA096 extu.b r2,r2
L_060DA098:
    c.r[1] = 0xFu;  // 060DA098 mov #15,r1
L_060DA09A:
    c.r[2] &= c.r[1];  // 060DA09A and r1,r2
L_060DA09C:
    c.r[1] = 0x4u;  // 060DA09C mov #4,r1
L_060DA09E:
    c.t = c.r[2] == c.r[1];  // 060DA09E cmp/eq r1,r2
L_060DA0A0:
    if (c.t) { goto L_060DA0B2; }  // 060DA0A0 bt 0x060DA0B2
L_060DA0A2:
    c.r[1] = 0x5u;  // 060DA0A2 mov #5,r1
L_060DA0A4:
    c.t = c.r[2] == c.r[1];  // 060DA0A4 cmp/eq r1,r2
L_060DA0A6:
    if (c.t) { goto L_060DA0B8; }  // 060DA0A6 bt 0x060DA0B8
L_060DA0A8:
    c.r[1] = 0x6u;  // 060DA0A8 mov #6,r1
L_060DA0AA:
    c.t = c.r[2] == c.r[1];  // 060DA0AA cmp/eq r1,r2
L_060DA0AC:
    if (c.t) { goto L_060DA0BE; }  // 060DA0AC bt 0x060DA0BE
L_060DA0AE:
    goto L_060DA202;  // 060DA0AE bra 0x060DA202 ; nop
L_060DA0B2:
    c.r[2] = ld32(0x060DA0CCu);  // 060DA0B2 mov.l 0x060DA0CC,r2
L_060DA0B4:
    c.t = c.r[0] == c.r[2]; goto L_060DA200;  // 060DA0B4 bra 0x060DA200 ; cmp/eq r2,r0
L_060DA0B8:
    c.r[2] = ld32(0x060DA0D0u);  // 060DA0B8 mov.l 0x060DA0D0,r2
L_060DA0BA:
    c.t = c.r[0] == c.r[2]; goto L_060DA200;  // 060DA0BA bra 0x060DA200 ; cmp/eq r2,r0
L_060DA0BE:
    c.r[2] = ld32(0x060DA0D4u);  // 060DA0BE mov.l 0x060DA0D4,r2
L_060DA0C0:
    c.t = c.r[0] == c.r[2]; goto L_060DA200;  // 060DA0C0 bra 0x060DA200 ; cmp/eq r2,r0
L_060DA1F0:
    c.r[1] = ld32(0x060DA2F4u);  // 060DA1F0 mov.l 0x060DA2F4,r1
L_060DA1F2:
    c.r[1] = ld32(c.r[1]);  // 060DA1F2 mov.l @r1,r1
L_060DA1F4:
    c.r[1] += 2;  // 060DA1F4 add #2,r1
L_060DA1F6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DA1F6 mov.w @r1,r0
L_060DA1F8:
    c.r[0] = ~c.r[0];  // 060DA1F8 not r0,r0
L_060DA1FA:
    c.r[0] = c.r[0] & 0xFFFFu;  // 060DA1FA extu.w r0,r0
L_060DA1FC:
    SH2_POLL(c); goto L_060DA08C;  // 060DA1FC bra 0x060DA08C ; nop
L_060DA200:
    if (c.t) { goto L_060DA20C; }  // 060DA200 bt 0x060DA20C
L_060DA202:
    c.r[1] = ld32(0x060DA2FCu);  // 060DA202 mov.l 0x060DA2FC,r1
L_060DA204:
    c.r[0] = 0x0u;  // 060DA204 mov #0,r0
L_060DA206:
    st8(c.r[1], c.r[0]);  // 060DA206 mov.b r0,@r1
L_060DA208:
    goto L_060DA2D2;  // 060DA208 bra 0x060DA2D2 ; nop
L_060DA20C:
    c.r[1] = ld32(0x060DA300u);  // 060DA20C mov.l 0x060DA300,r1
L_060DA20E:
    c.r[1] = ld32(c.r[1]);  // 060DA20E mov.l @r1,r1
L_060DA210:
    c.r[2] = ld32(0x060DA304u);  // 060DA210 mov.l 0x060DA304,r2
L_060DA212:
    c.t = c.r[1] == c.r[2];  // 060DA212 cmp/eq r2,r1
L_060DA214:
    if (c.t) { goto L_060DA22C; }  // 060DA214 bt 0x060DA22C
L_060DA216:
    c.r[2] = ld32(0x060DA308u);  // 060DA216 mov.l 0x060DA308,r2
L_060DA218:
    c.t = c.r[1] == c.r[2];  // 060DA218 cmp/eq r2,r1
L_060DA21A:
    if (c.t) { goto L_060DA22C; }  // 060DA21A bt 0x060DA22C
L_060DA21C:
    c.r[2] = ld32(0x060DA30Cu);  // 060DA21C mov.l 0x060DA30C,r2
L_060DA21E:
    c.t = c.r[1] == c.r[2];  // 060DA21E cmp/eq r2,r1
L_060DA220:
    if (c.t) { goto L_060DA22C; }  // 060DA220 bt 0x060DA22C
L_060DA222:
    c.r[1] = ld32(0x060DA2FCu);  // 060DA222 mov.l 0x060DA2FC,r1
L_060DA224:
    c.r[0] = 0x1u;  // 060DA224 mov #1,r0
L_060DA226:
    st8(c.r[1], c.r[0]);  // 060DA226 mov.b r0,@r1
L_060DA228:
    goto L_060DA2D2;  // 060DA228 bra 0x060DA2D2 ; nop
L_060DA22C:
    c.r[1] = ld32(0x060DA310u);  // 060DA22C mov.l 0x060DA310,r1
L_060DA22E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA22E mov.b @r1,r0
L_060DA230:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA230 tst r0,r0
L_060DA232:
    if (c.t) { goto L_060DA238; }  // 060DA232 bt 0x060DA238
L_060DA234:
    goto L_060DA2D2;  // 060DA234 bra 0x060DA2D2 ; nop
L_060DA238:
    c.r[1] = ld32(0x060DA2FCu);  // 060DA238 mov.l 0x060DA2FC,r1
L_060DA23A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA23A mov.b @r1,r0
L_060DA23C:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA23C tst r0,r0
L_060DA23E:
    if (c.t) { goto L_060DA244; }  // 060DA23E bt 0x060DA244
L_060DA240:
    goto L_060DA2C0;  // 060DA240 bra 0x060DA2C0 ; nop
L_060DA244:
    c.r[0] = 0x1u;  // 060DA244 mov #1,r0
L_060DA246:
    st8(c.r[1], c.r[0]);  // 060DA246 mov.b r0,@r1
L_060DA248:
    c.r[1] = ld32(0x060DA314u);  // 060DA248 mov.l 0x060DA314,r1
L_060DA24A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA24A mov.b @r1,r0
L_060DA24C:
    c.r[0] ^= 0x1u;  // 060DA24C xor #1,r0
L_060DA24E:
    st8(c.r[1], c.r[0]);  // 060DA24E mov.b r0,@r1
L_060DA250:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA250 tst r0,r0
L_060DA252:
    if (c.t) { goto L_060DA25A; }  // 060DA252 bt 0x060DA25A
L_060DA254:
    c.r[2] = ld32(0x060DA318u);  // 060DA254 mov.l 0x060DA318,r2
L_060DA256:
    goto L_060DA25C;  // 060DA256 bra 0x060DA25C ; nop
L_060DA25A:
    c.r[2] = ld32(0x060DA31Cu);  // 060DA25A mov.l 0x060DA31C,r2
L_060DA25C:
    c.r[1] = ld32(0x060DA320u);  // 060DA25C mov.l 0x060DA320,r1
L_060DA25E:
    c.r[3] = 0x4u;  // 060DA25E mov #4,r3
L_060DA260:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 060DA260 mov.w @r2+,r0
L_060DA262:
    st16(c.r[1], c.r[0]);  // 060DA262 mov.w r0,@r1
L_060DA264:
    c.r[1] += 2;  // 060DA264 add #2,r1
L_060DA266:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DA266 dt r3
L_060DA268:
    if (!c.t) { SH2_POLL(c); goto L_060DA260; }  // 060DA268 bf 0x060DA260
L_060DA26A:
    c.r[1] = ld32(0x060DA324u);  // 060DA26A mov.l 0x060DA324,r1
L_060DA26C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA26C mov.b @r1,r0
L_060DA26E:
    c.r[0] += 1;  // 060DA26E add #1,r0
L_060DA270:
    st8(c.r[1], c.r[0]);  // 060DA270 mov.b r0,@r1
L_060DA272:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA272 mov.l r4,@-r15
L_060DA274:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA274 mov.l r5,@-r15
L_060DA276:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA276 mov.l r6,@-r15
L_060DA278:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA278 mov.l r7,@-r15
L_060DA27A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA27A sts.l pr,@-r15
L_060DA27C:
    c.r[4] = 0x1u;  // 060DA27C mov #1,r4
L_060DA27E:
    c.r[6] = 0x0u;  // 060DA27E mov #0,r6
L_060DA280:
    c.r[1] = ld32(0x060DA314u);  // 060DA280 mov.l 0x060DA314,r1
L_060DA282:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA282 mov.b @r1,r0
L_060DA284:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA284 tst r0,r0
L_060DA286:
    c.r[5] = 0x7Au;  // 060DA286 mov #122,r5
L_060DA288:
    if (c.t) { goto L_060DA28C; }  // 060DA288 bt 0x060DA28C
L_060DA28A:
    c.r[5] = ld32(0x060DA328u);  // 060DA28A mov.l 0x060DA328,r5
L_060DA28C:
    c.r[1] = ld32(0x060DA32Cu);  // 060DA28C mov.l 0x060DA32C,r1
L_060DA28E:
    { const uint32_t x = c.r[1]; c.pr = 0x060DA292u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DA292u) return; }  // 060DA28E jsr @r1 ; nop
L_060DA292:
    c.r[4] = 0x1u;  // 060DA292 mov #1,r4
L_060DA294:
    c.r[6] = 0x0u;  // 060DA294 mov #0,r6
L_060DA296:
    c.r[5] = ld32(0x060DA330u);  // 060DA296 mov.l 0x060DA330,r5
L_060DA298:
    c.r[1] = ld32(0x060DA334u);  // 060DA298 mov.l 0x060DA334,r1
L_060DA29A:
    { const uint32_t x = c.r[1]; c.pr = 0x060DA29Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DA29Eu) return; }  // 060DA29A jsr @r1 ; nop
L_060DA29E:
    c.r[1] = ld32(0x060DA314u);  // 060DA29E mov.l 0x060DA314,r1
L_060DA2A0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA2A0 mov.b @r1,r0
L_060DA2A2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA2A2 tst r0,r0
L_060DA2A4:
    c.r[6] = 0x20u;  // 060DA2A4 mov #32,r6
L_060DA2A6:
    if (c.t) { goto L_060DA2AA; }  // 060DA2A6 bt 0x060DA2AA
L_060DA2A8:
    c.r[6] = 0x1Cu;  // 060DA2A8 mov #28,r6
L_060DA2AA:
    c.r[4] = 0x1u;  // 060DA2AA mov #1,r4
L_060DA2AC:
    c.r[5] = 0x0u;  // 060DA2AC mov #0,r5
L_060DA2AE:
    c.r[7] = 0x1u;  // 060DA2AE mov #1,r7
L_060DA2B0:
    c.r[1] = ld32(0x060DA338u);  // 060DA2B0 mov.l 0x060DA338,r1
L_060DA2B2:
    { const uint32_t x = c.r[1]; c.pr = 0x060DA2B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DA2B6u) return; }  // 060DA2B2 jsr @r1 ; nop
L_060DA2B6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA2B6 lds.l @r15+,pr
L_060DA2B8:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA2B8 mov.l @r15+,r7
L_060DA2BA:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA2BA mov.l @r15+,r6
L_060DA2BC:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA2BC mov.l @r15+,r5
L_060DA2BE:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA2BE mov.l @r15+,r4
L_060DA2C0:
    c.r[1] = ld32(0x060DA33Cu);  // 060DA2C0 mov.l 0x060DA33C,r1
L_060DA2C2:
    c.r[2] = ld32(0x060DA340u);  // 060DA2C2 mov.l 0x060DA340,r2
L_060DA2C4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DA2C4 mov.w @r1,r0
L_060DA2C6:
    c.r[0] &= c.r[2];  // 060DA2C6 and r2,r0
L_060DA2C8:
    st16(c.r[1], c.r[0]);  // 060DA2C8 mov.w r0,@r1
L_060DA2CA:
    c.r[1] += 2;  // 060DA2CA add #2,r1
L_060DA2CC:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DA2CC mov.w @r1,r0
L_060DA2CE:
    c.r[0] &= c.r[2];  // 060DA2CE and r2,r0
L_060DA2D0:
    st16(c.r[1], c.r[0]);  // 060DA2D0 mov.w r0,@r1
L_060DA2D2:
    c.r[0] = ld32(0x060DA344u);  // 060DA2D2 mov.l 0x060DA344,r0
L_060DA2D4:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA08Cu: goto L_060DA08C; case 0x060DA08Eu: goto L_060DA08E; case 0x060DA090u: goto L_060DA090; case 0x060DA092u: goto L_060DA092; case 0x060DA094u: goto L_060DA094; case 0x060DA096u: goto L_060DA096; case 0x060DA098u: goto L_060DA098; case 0x060DA09Au: goto L_060DA09A; case 0x060DA09Cu: goto L_060DA09C; case 0x060DA09Eu: goto L_060DA09E; case 0x060DA0A0u: goto L_060DA0A0; case 0x060DA0A2u: goto L_060DA0A2; case 0x060DA0A4u: goto L_060DA0A4; case 0x060DA0A6u: goto L_060DA0A6; case 0x060DA0A8u: goto L_060DA0A8; case 0x060DA0AAu: goto L_060DA0AA; case 0x060DA0ACu: goto L_060DA0AC; case 0x060DA0AEu: goto L_060DA0AE; case 0x060DA0B2u: goto L_060DA0B2; case 0x060DA0B4u: goto L_060DA0B4; case 0x060DA0B8u: goto L_060DA0B8; case 0x060DA0BAu: goto L_060DA0BA; case 0x060DA0BEu: goto L_060DA0BE; case 0x060DA0C0u: goto L_060DA0C0; case 0x060DA1F0u: goto L_060DA1F0; case 0x060DA1F2u: goto L_060DA1F2; case 0x060DA1F4u: goto L_060DA1F4; case 0x060DA1F6u: goto L_060DA1F6; case 0x060DA1F8u: goto L_060DA1F8; case 0x060DA1FAu: goto L_060DA1FA; case 0x060DA1FCu: goto L_060DA1FC; case 0x060DA200u: goto L_060DA200; case 0x060DA202u: goto L_060DA202; case 0x060DA204u: goto L_060DA204; case 0x060DA206u: goto L_060DA206; case 0x060DA208u: goto L_060DA208; case 0x060DA20Cu: goto L_060DA20C; case 0x060DA20Eu: goto L_060DA20E; case 0x060DA210u: goto L_060DA210; case 0x060DA212u: goto L_060DA212; case 0x060DA214u: goto L_060DA214; case 0x060DA216u: goto L_060DA216; case 0x060DA218u: goto L_060DA218; case 0x060DA21Au: goto L_060DA21A; case 0x060DA21Cu: goto L_060DA21C; case 0x060DA21Eu: goto L_060DA21E; case 0x060DA220u: goto L_060DA220; case 0x060DA222u: goto L_060DA222; case 0x060DA224u: goto L_060DA224; case 0x060DA226u: goto L_060DA226; case 0x060DA228u: goto L_060DA228; case 0x060DA22Cu: goto L_060DA22C; case 0x060DA22Eu: goto L_060DA22E; case 0x060DA230u: goto L_060DA230; case 0x060DA232u: goto L_060DA232; case 0x060DA234u: goto L_060DA234; case 0x060DA238u: goto L_060DA238; case 0x060DA23Au: goto L_060DA23A; case 0x060DA23Cu: goto L_060DA23C; case 0x060DA23Eu: goto L_060DA23E; case 0x060DA240u: goto L_060DA240; case 0x060DA244u: goto L_060DA244; case 0x060DA246u: goto L_060DA246; case 0x060DA248u: goto L_060DA248; case 0x060DA24Au: goto L_060DA24A; case 0x060DA24Cu: goto L_060DA24C; case 0x060DA24Eu: goto L_060DA24E; case 0x060DA250u: goto L_060DA250; case 0x060DA252u: goto L_060DA252; case 0x060DA254u: goto L_060DA254; case 0x060DA256u: goto L_060DA256; case 0x060DA25Au: goto L_060DA25A; case 0x060DA25Cu: goto L_060DA25C; case 0x060DA25Eu: goto L_060DA25E; case 0x060DA260u: goto L_060DA260; case 0x060DA262u: goto L_060DA262; case 0x060DA264u: goto L_060DA264; case 0x060DA266u: goto L_060DA266; case 0x060DA268u: goto L_060DA268; case 0x060DA26Au: goto L_060DA26A; case 0x060DA26Cu: goto L_060DA26C; case 0x060DA26Eu: goto L_060DA26E; case 0x060DA270u: goto L_060DA270; case 0x060DA272u: goto L_060DA272; case 0x060DA274u: goto L_060DA274; case 0x060DA276u: goto L_060DA276; case 0x060DA278u: goto L_060DA278; case 0x060DA27Au: goto L_060DA27A; case 0x060DA27Cu: goto L_060DA27C; case 0x060DA27Eu: goto L_060DA27E; case 0x060DA280u: goto L_060DA280; case 0x060DA282u: goto L_060DA282; case 0x060DA284u: goto L_060DA284; case 0x060DA286u: goto L_060DA286; case 0x060DA288u: goto L_060DA288; case 0x060DA28Au: goto L_060DA28A; case 0x060DA28Cu: goto L_060DA28C; case 0x060DA28Eu: goto L_060DA28E; case 0x060DA292u: goto L_060DA292; case 0x060DA294u: goto L_060DA294; case 0x060DA296u: goto L_060DA296; case 0x060DA298u: goto L_060DA298; case 0x060DA29Au: goto L_060DA29A; case 0x060DA29Eu: goto L_060DA29E; case 0x060DA2A0u: goto L_060DA2A0; case 0x060DA2A2u: goto L_060DA2A2; case 0x060DA2A4u: goto L_060DA2A4; case 0x060DA2A6u: goto L_060DA2A6; case 0x060DA2A8u: goto L_060DA2A8; case 0x060DA2AAu: goto L_060DA2AA; case 0x060DA2ACu: goto L_060DA2AC; case 0x060DA2AEu: goto L_060DA2AE; case 0x060DA2B0u: goto L_060DA2B0; case 0x060DA2B2u: goto L_060DA2B2; case 0x060DA2B6u: goto L_060DA2B6; case 0x060DA2B8u: goto L_060DA2B8; case 0x060DA2BAu: goto L_060DA2BA; case 0x060DA2BCu: goto L_060DA2BC; case 0x060DA2BEu: goto L_060DA2BE; case 0x060DA2C0u: goto L_060DA2C0; case 0x060DA2C2u: goto L_060DA2C2; case 0x060DA2C4u: goto L_060DA2C4; case 0x060DA2C6u: goto L_060DA2C6; case 0x060DA2C8u: goto L_060DA2C8; case 0x060DA2CAu: goto L_060DA2CA; case 0x060DA2CCu: goto L_060DA2CC; case 0x060DA2CEu: goto L_060DA2CE; case 0x060DA2D0u: goto L_060DA2D0; case 0x060DA2D2u: goto L_060DA2D2; case 0x060DA2D4u: goto L_060DA2D4; default: sh2_call(c, x); return; } }  // 060DA2D4 jmp @r0 ; nop
}

void f_060DA800(SH2Context& c) {
    ran[5] = 1;
L_060DA800:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DA800 mov.l r1,@-r15
L_060DA802:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DA802 mov.l r2,@-r15
L_060DA804:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DA804 mov.l r3,@-r15
L_060DA806:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA806 mov.l r4,@-r15
L_060DA808:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA808 mov.l r5,@-r15
L_060DA80A:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA80A mov.l r6,@-r15
L_060DA80C:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA80C mov.l r7,@-r15
L_060DA80E:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA80E sts.l pr,@-r15
L_060DA810:
    c.pr = 0x060DA814u; SH2_POLL(c); sh2_call(c, 0x060DA88Au); if (c.pc != 0x060DA814u) return;  // 060DA810 bsr 0x060DA88A ; nop
L_060DA814:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA814 lds.l @r15+,pr
L_060DA816:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA816 mov.l @r15+,r7
L_060DA818:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA818 mov.l @r15+,r6
L_060DA81A:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA81A mov.l @r15+,r5
L_060DA81C:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA81C mov.l @r15+,r4
L_060DA81E:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DA81E mov.l @r15+,r3
L_060DA820:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DA820 mov.l @r15+,r2
L_060DA822:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DA822 mov.l @r15+,r1
L_060DA824:
    c.r[0] = ld32(0x060DA9ACu);  // 060DA824 mov.l 0x060DA9AC,r0
L_060DA826:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA800u: goto L_060DA800; case 0x060DA802u: goto L_060DA802; case 0x060DA804u: goto L_060DA804; case 0x060DA806u: goto L_060DA806; case 0x060DA808u: goto L_060DA808; case 0x060DA80Au: goto L_060DA80A; case 0x060DA80Cu: goto L_060DA80C; case 0x060DA80Eu: goto L_060DA80E; case 0x060DA810u: goto L_060DA810; case 0x060DA814u: goto L_060DA814; case 0x060DA816u: goto L_060DA816; case 0x060DA818u: goto L_060DA818; case 0x060DA81Au: goto L_060DA81A; case 0x060DA81Cu: goto L_060DA81C; case 0x060DA81Eu: goto L_060DA81E; case 0x060DA820u: goto L_060DA820; case 0x060DA822u: goto L_060DA822; case 0x060DA824u: goto L_060DA824; case 0x060DA826u: goto L_060DA826; case 0x060DAE00u: goto L_060DAE00; case 0x060DAE02u: goto L_060DAE02; case 0x060DAE04u: goto L_060DAE04; case 0x060DAE06u: goto L_060DAE06; case 0x060DAE08u: goto L_060DAE08; case 0x060DAE0Au: goto L_060DAE0A; case 0x060DAE0Cu: goto L_060DAE0C; case 0x060DAE0Eu: goto L_060DAE0E; case 0x060DAE10u: goto L_060DAE10; case 0x060DAE12u: goto L_060DAE12; case 0x060DAE14u: goto L_060DAE14; case 0x060DAE16u: goto L_060DAE16; case 0x060DAE18u: goto L_060DAE18; case 0x060DAE1Au: goto L_060DAE1A; case 0x060DAE1Cu: goto L_060DAE1C; case 0x060DAE1Eu: goto L_060DAE1E; case 0x060DAE20u: goto L_060DAE20; case 0x060DAE22u: goto L_060DAE22; case 0x060DAE24u: goto L_060DAE24; case 0x060DAE26u: goto L_060DAE26; case 0x060DAE28u: goto L_060DAE28; case 0x060DAE2Au: goto L_060DAE2A; case 0x060DAE2Cu: goto L_060DAE2C; case 0x060DAE2Eu: goto L_060DAE2E; case 0x060DAE30u: goto L_060DAE30; case 0x060DAE32u: goto L_060DAE32; case 0x060DAE34u: goto L_060DAE34; case 0x060DAE36u: goto L_060DAE36; case 0x060DAE38u: goto L_060DAE38; case 0x060DAE3Au: goto L_060DAE3A; case 0x060DAE3Cu: goto L_060DAE3C; case 0x060DAE3Eu: goto L_060DAE3E; case 0x060DAE40u: goto L_060DAE40; case 0x060DAE44u: goto L_060DAE44; case 0x060DAE46u: goto L_060DAE46; case 0x060DAE48u: goto L_060DAE48; case 0x060DAE4Au: goto L_060DAE4A; case 0x060DAE4Cu: goto L_060DAE4C; case 0x060DAE4Eu: goto L_060DAE4E; case 0x060DAE50u: goto L_060DAE50; case 0x060DAE52u: goto L_060DAE52; case 0x060DAE54u: goto L_060DAE54; case 0x060DAE56u: goto L_060DAE56; case 0x060DAE58u: goto L_060DAE58; case 0x060DAE5Cu: goto L_060DAE5C; case 0x060DAE5Eu: goto L_060DAE5E; case 0x060DAE62u: goto L_060DAE62; case 0x060DAE64u: goto L_060DAE64; case 0x060DAE66u: goto L_060DAE66; case 0x060DAE68u: goto L_060DAE68; case 0x060DAE6Au: goto L_060DAE6A; case 0x060DAE6Cu: goto L_060DAE6C; case 0x060DAE6Eu: goto L_060DAE6E; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DA826 jmp @r0 ; nop
L_060DAE00:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DAE00 mov.l r0,@-r15
L_060DAE02:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DAE02 mov.l r1,@-r15
L_060DAE04:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DAE04 mov.l r2,@-r15
L_060DAE06:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DAE06 mov.l r3,@-r15
L_060DAE08:
    c.r[3] = ld32(0x060DAE8Cu);  // 060DAE08 mov.l 0x060DAE8C,r3
L_060DAE0A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060DAE0A mov.w @r3,r0
L_060DAE0C:
    c.r[0] = ~c.r[0];  // 060DAE0C not r0,r0
L_060DAE0E:
    c.r[3] = ld32(0x060DAE90u);  // 060DAE0E mov.l 0x060DAE90,r3
L_060DAE10:
    c.r[0] &= c.r[3];  // 060DAE10 and r3,r0
L_060DAE12:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAE12 tst r0,r0
L_060DAE14:
    if (c.t) { goto L_060DAE62; }  // 060DAE14 bt 0x060DAE62
L_060DAE16:
    c.r[3] = ld32(0x060DAE94u);  // 060DAE16 mov.l 0x060DAE94,r3
L_060DAE18:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060DAE18 mov.b @r3,r0
L_060DAE1A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAE1A tst r0,r0
L_060DAE1C:
    if (!c.t) { goto L_060DAE68; }  // 060DAE1C bf 0x060DAE68
L_060DAE1E:
    c.r[0] = 0x1u;  // 060DAE1E mov #1,r0
L_060DAE20:
    st8(c.r[3], c.r[0]);  // 060DAE20 mov.b r0,@r3
L_060DAE22:
    c.r[3] = ld32(0x060DAE98u);  // 060DAE22 mov.l 0x060DAE98,r3
L_060DAE24:
    c.r[0] = ld32(c.r[3]);  // 060DAE24 mov.l @r3,r0
L_060DAE26:
    c.r[3] = ld32(0x060DAE9Cu);  // 060DAE26 mov.l 0x060DAE9C,r3
L_060DAE28:
    c.t = c.r[0] == c.r[3];  // 060DAE28 cmp/eq r3,r0
L_060DAE2A:
    if (c.t) { goto L_060DAE32; }  // 060DAE2A bt 0x060DAE32
L_060DAE2C:
    c.r[3] = ld32(0x060DAEA0u);  // 060DAE2C mov.l 0x060DAEA0,r3
L_060DAE2E:
    c.t = c.r[0] == c.r[3];  // 060DAE2E cmp/eq r3,r0
L_060DAE30:
    if (!c.t) { goto L_060DAE68; }  // 060DAE30 bf 0x060DAE68
L_060DAE32:
    c.r[1] = ld32(0x060DAEA4u);  // 060DAE32 mov.l 0x060DAEA4,r1
L_060DAE34:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DAE34 mov.b @r1,r0
L_060DAE36:
    c.r[0] ^= 0x1u;  // 060DAE36 xor #1,r0
L_060DAE38:
    st8(c.r[1], c.r[0]);  // 060DAE38 mov.b r0,@r1
L_060DAE3A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAE3A tst r0,r0
L_060DAE3C:
    if (c.t) { goto L_060DAE44; }  // 060DAE3C bt 0x060DAE44
L_060DAE3E:
    c.r[2] = ld32(0x060DAEA8u);  // 060DAE3E mov.l 0x060DAEA8,r2
L_060DAE40:
    goto L_060DAE46;  // 060DAE40 bra 0x060DAE46 ; nop
L_060DAE44:
    c.r[2] = ld32(0x060DAEACu);  // 060DAE44 mov.l 0x060DAEAC,r2
L_060DAE46:
    c.r[1] = ld32(0x060DAEB0u);  // 060DAE46 mov.l 0x060DAEB0,r1
L_060DAE48:
    c.r[3] = 0x4u;  // 060DAE48 mov #4,r3
L_060DAE4A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 060DAE4A mov.w @r2+,r0
L_060DAE4C:
    st16(c.r[1], c.r[0]);  // 060DAE4C mov.w r0,@r1
L_060DAE4E:
    c.r[1] += 2;  // 060DAE4E add #2,r1
L_060DAE50:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DAE50 dt r3
L_060DAE52:
    if (!c.t) { SH2_POLL(c); goto L_060DAE4A; }  // 060DAE52 bf 0x060DAE4A
L_060DAE54:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DAE54 sts.l pr,@-r15
L_060DAE56:
    c.r[0] = ld32(0x060DAEC0u);  // 060DAE56 mov.l 0x060DAEC0,r0
L_060DAE58:
    { const uint32_t x = c.r[0]; c.pr = 0x060DAE5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAE5Cu) return; }  // 060DAE58 jsr @r0 ; nop
L_060DAE5C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DAE5C lds.l @r15+,pr
L_060DAE5E:
    goto L_060DAE68;  // 060DAE5E bra 0x060DAE68 ; nop
L_060DAE62:
    c.r[3] = ld32(0x060DAE94u);  // 060DAE62 mov.l 0x060DAE94,r3
L_060DAE64:
    c.r[0] = 0x0u;  // 060DAE64 mov #0,r0
L_060DAE66:
    st8(c.r[3], c.r[0]);  // 060DAE66 mov.b r0,@r3
L_060DAE68:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE68 mov.l @r15+,r3
L_060DAE6A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE6A mov.l @r15+,r2
L_060DAE6C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE6C mov.l @r15+,r1
L_060DAE6E:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE6E mov.l @r15+,r0
L_060DAE70:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAE70 mov.w @r1,r1
L_060DAE72:
    c.r[2] = c.r[1] & 0xFFFFu;  // 060DAE72 extu.w r1,r2
L_060DAE74:
    c.r[1] = 0xFu;  // 060DAE74 mov #15,r1
L_060DAE76:
    c.r[1] <<= 8;  // 060DAE76 shll8 r1
L_060DAE78:
    c.r[2] &= c.r[1];  // 060DAE78 and r1,r2
L_060DAE7A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 060DAE7A tst r2,r2
L_060DAE7C:
    c.r[14] = c.r[15];  // 060DAE7C mov r15,r14
L_060DAE7E:
    if (c.t) { goto L_060DAE86; }  // 060DAE7E bt 0x060DAE86
L_060DAE80:
    c.r[0] = ld32(0x060DAEB4u);  // 060DAE80 mov.l 0x060DAEB4,r0
L_060DAE82:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA800u: goto L_060DA800; case 0x060DA802u: goto L_060DA802; case 0x060DA804u: goto L_060DA804; case 0x060DA806u: goto L_060DA806; case 0x060DA808u: goto L_060DA808; case 0x060DA80Au: goto L_060DA80A; case 0x060DA80Cu: goto L_060DA80C; case 0x060DA80Eu: goto L_060DA80E; case 0x060DA810u: goto L_060DA810; case 0x060DA814u: goto L_060DA814; case 0x060DA816u: goto L_060DA816; case 0x060DA818u: goto L_060DA818; case 0x060DA81Au: goto L_060DA81A; case 0x060DA81Cu: goto L_060DA81C; case 0x060DA81Eu: goto L_060DA81E; case 0x060DA820u: goto L_060DA820; case 0x060DA822u: goto L_060DA822; case 0x060DA824u: goto L_060DA824; case 0x060DA826u: goto L_060DA826; case 0x060DAE00u: goto L_060DAE00; case 0x060DAE02u: goto L_060DAE02; case 0x060DAE04u: goto L_060DAE04; case 0x060DAE06u: goto L_060DAE06; case 0x060DAE08u: goto L_060DAE08; case 0x060DAE0Au: goto L_060DAE0A; case 0x060DAE0Cu: goto L_060DAE0C; case 0x060DAE0Eu: goto L_060DAE0E; case 0x060DAE10u: goto L_060DAE10; case 0x060DAE12u: goto L_060DAE12; case 0x060DAE14u: goto L_060DAE14; case 0x060DAE16u: goto L_060DAE16; case 0x060DAE18u: goto L_060DAE18; case 0x060DAE1Au: goto L_060DAE1A; case 0x060DAE1Cu: goto L_060DAE1C; case 0x060DAE1Eu: goto L_060DAE1E; case 0x060DAE20u: goto L_060DAE20; case 0x060DAE22u: goto L_060DAE22; case 0x060DAE24u: goto L_060DAE24; case 0x060DAE26u: goto L_060DAE26; case 0x060DAE28u: goto L_060DAE28; case 0x060DAE2Au: goto L_060DAE2A; case 0x060DAE2Cu: goto L_060DAE2C; case 0x060DAE2Eu: goto L_060DAE2E; case 0x060DAE30u: goto L_060DAE30; case 0x060DAE32u: goto L_060DAE32; case 0x060DAE34u: goto L_060DAE34; case 0x060DAE36u: goto L_060DAE36; case 0x060DAE38u: goto L_060DAE38; case 0x060DAE3Au: goto L_060DAE3A; case 0x060DAE3Cu: goto L_060DAE3C; case 0x060DAE3Eu: goto L_060DAE3E; case 0x060DAE40u: goto L_060DAE40; case 0x060DAE44u: goto L_060DAE44; case 0x060DAE46u: goto L_060DAE46; case 0x060DAE48u: goto L_060DAE48; case 0x060DAE4Au: goto L_060DAE4A; case 0x060DAE4Cu: goto L_060DAE4C; case 0x060DAE4Eu: goto L_060DAE4E; case 0x060DAE50u: goto L_060DAE50; case 0x060DAE52u: goto L_060DAE52; case 0x060DAE54u: goto L_060DAE54; case 0x060DAE56u: goto L_060DAE56; case 0x060DAE58u: goto L_060DAE58; case 0x060DAE5Cu: goto L_060DAE5C; case 0x060DAE5Eu: goto L_060DAE5E; case 0x060DAE62u: goto L_060DAE62; case 0x060DAE64u: goto L_060DAE64; case 0x060DAE66u: goto L_060DAE66; case 0x060DAE68u: goto L_060DAE68; case 0x060DAE6Au: goto L_060DAE6A; case 0x060DAE6Cu: goto L_060DAE6C; case 0x060DAE6Eu: goto L_060DAE6E; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE82 jmp @r0 ; nop
L_060DAE86:
    c.r[0] = ld32(0x060DAEB8u);  // 060DAE86 mov.l 0x060DAEB8,r0
L_060DAE88:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA800u: goto L_060DA800; case 0x060DA802u: goto L_060DA802; case 0x060DA804u: goto L_060DA804; case 0x060DA806u: goto L_060DA806; case 0x060DA808u: goto L_060DA808; case 0x060DA80Au: goto L_060DA80A; case 0x060DA80Cu: goto L_060DA80C; case 0x060DA80Eu: goto L_060DA80E; case 0x060DA810u: goto L_060DA810; case 0x060DA814u: goto L_060DA814; case 0x060DA816u: goto L_060DA816; case 0x060DA818u: goto L_060DA818; case 0x060DA81Au: goto L_060DA81A; case 0x060DA81Cu: goto L_060DA81C; case 0x060DA81Eu: goto L_060DA81E; case 0x060DA820u: goto L_060DA820; case 0x060DA822u: goto L_060DA822; case 0x060DA824u: goto L_060DA824; case 0x060DA826u: goto L_060DA826; case 0x060DAE00u: goto L_060DAE00; case 0x060DAE02u: goto L_060DAE02; case 0x060DAE04u: goto L_060DAE04; case 0x060DAE06u: goto L_060DAE06; case 0x060DAE08u: goto L_060DAE08; case 0x060DAE0Au: goto L_060DAE0A; case 0x060DAE0Cu: goto L_060DAE0C; case 0x060DAE0Eu: goto L_060DAE0E; case 0x060DAE10u: goto L_060DAE10; case 0x060DAE12u: goto L_060DAE12; case 0x060DAE14u: goto L_060DAE14; case 0x060DAE16u: goto L_060DAE16; case 0x060DAE18u: goto L_060DAE18; case 0x060DAE1Au: goto L_060DAE1A; case 0x060DAE1Cu: goto L_060DAE1C; case 0x060DAE1Eu: goto L_060DAE1E; case 0x060DAE20u: goto L_060DAE20; case 0x060DAE22u: goto L_060DAE22; case 0x060DAE24u: goto L_060DAE24; case 0x060DAE26u: goto L_060DAE26; case 0x060DAE28u: goto L_060DAE28; case 0x060DAE2Au: goto L_060DAE2A; case 0x060DAE2Cu: goto L_060DAE2C; case 0x060DAE2Eu: goto L_060DAE2E; case 0x060DAE30u: goto L_060DAE30; case 0x060DAE32u: goto L_060DAE32; case 0x060DAE34u: goto L_060DAE34; case 0x060DAE36u: goto L_060DAE36; case 0x060DAE38u: goto L_060DAE38; case 0x060DAE3Au: goto L_060DAE3A; case 0x060DAE3Cu: goto L_060DAE3C; case 0x060DAE3Eu: goto L_060DAE3E; case 0x060DAE40u: goto L_060DAE40; case 0x060DAE44u: goto L_060DAE44; case 0x060DAE46u: goto L_060DAE46; case 0x060DAE48u: goto L_060DAE48; case 0x060DAE4Au: goto L_060DAE4A; case 0x060DAE4Cu: goto L_060DAE4C; case 0x060DAE4Eu: goto L_060DAE4E; case 0x060DAE50u: goto L_060DAE50; case 0x060DAE52u: goto L_060DAE52; case 0x060DAE54u: goto L_060DAE54; case 0x060DAE56u: goto L_060DAE56; case 0x060DAE58u: goto L_060DAE58; case 0x060DAE5Cu: goto L_060DAE5C; case 0x060DAE5Eu: goto L_060DAE5E; case 0x060DAE62u: goto L_060DAE62; case 0x060DAE64u: goto L_060DAE64; case 0x060DAE66u: goto L_060DAE66; case 0x060DAE68u: goto L_060DAE68; case 0x060DAE6Au: goto L_060DAE6A; case 0x060DAE6Cu: goto L_060DAE6C; case 0x060DAE6Eu: goto L_060DAE6E; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE88 jmp @r0 ; nop
}

void f_060DA82A(SH2Context& c) {
    ran[6] = 1;
L_060DA82A:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DA82A mov.l r1,@-r15
L_060DA82C:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DA82C mov.l r2,@-r15
L_060DA82E:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DA82E mov.l r3,@-r15
L_060DA830:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA830 mov.l r4,@-r15
L_060DA832:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA832 mov.l r5,@-r15
L_060DA834:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA834 mov.l r6,@-r15
L_060DA836:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA836 mov.l r7,@-r15
L_060DA838:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA838 sts.l pr,@-r15
L_060DA83A:
    c.pr = 0x060DA83Eu; SH2_POLL(c); sh2_call(c, 0x060DA88Au); if (c.pc != 0x060DA83Eu) return;  // 060DA83A bsr 0x060DA88A ; nop
L_060DA83E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA83E lds.l @r15+,pr
L_060DA840:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA840 mov.l @r15+,r7
L_060DA842:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA842 mov.l @r15+,r6
L_060DA844:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA844 mov.l @r15+,r5
L_060DA846:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA846 mov.l @r15+,r4
L_060DA848:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DA848 mov.l @r15+,r3
L_060DA84A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DA84A mov.l @r15+,r2
L_060DA84C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DA84C mov.l @r15+,r1
L_060DA84E:
    c.r[0] = ld32(0x060DA9B0u);  // 060DA84E mov.l 0x060DA9B0,r0
L_060DA850:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; default: sh2_call(c, x); return; } }  // 060DA850 jmp @r0 ; nop
}

void f_060DA854(SH2Context& c) {
    ran[7] = 1;
L_060DA854:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA854 sts.l pr,@-r15
L_060DA856:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DA856 mov.l r1,@-r15
L_060DA858:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DA858 mov.l r2,@-r15
L_060DA85A:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DA85A mov.l r3,@-r15
L_060DA85C:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA85C mov.l r4,@-r15
L_060DA85E:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA85E mov.l r5,@-r15
L_060DA860:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA860 mov.l r6,@-r15
L_060DA862:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA862 mov.l r7,@-r15
L_060DA864:
    c.pr = 0x060DA868u; SH2_POLL(c); sh2_call(c, 0x060DA8BEu); if (c.pc != 0x060DA868u) return;  // 060DA864 bsr 0x060DA8BE ; nop
L_060DA868:
    c.r[0] = c.r[4];  // 060DA868 mov r4,r0
L_060DA86A:
    c.r[0] += 1;  // 060DA86A add #1,r0
L_060DA86C:
    c.r[1] = ld32(0x060DA9B4u);  // 060DA86C mov.l 0x060DA9B4,r1
L_060DA86E:
    st8(c.r[1], c.r[0]);  // 060DA86E mov.b r0,@r1
L_060DA870:
    c.pr = 0x060DA874u; SH2_POLL(c); sh2_call(c, 0x060DA92Au); if (c.pc != 0x060DA874u) return;  // 060DA870 bsr 0x060DA92A ; nop
L_060DA874:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA874 mov.l @r15+,r7
L_060DA876:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA876 mov.l @r15+,r6
L_060DA878:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA878 mov.l @r15+,r5
L_060DA87A:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA87A mov.l @r15+,r4
L_060DA87C:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DA87C mov.l @r15+,r3
L_060DA87E:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DA87E mov.l @r15+,r2
L_060DA880:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DA880 mov.l @r15+,r1
L_060DA882:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA882 lds.l @r15+,pr
L_060DA884:
    c.r[0] = ld32(0x060DA9B8u);  // 060DA884 mov.l 0x060DA9B8,r0
L_060DA886:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA854u: goto L_060DA854; case 0x060DA856u: goto L_060DA856; case 0x060DA858u: goto L_060DA858; case 0x060DA85Au: goto L_060DA85A; case 0x060DA85Cu: goto L_060DA85C; case 0x060DA85Eu: goto L_060DA85E; case 0x060DA860u: goto L_060DA860; case 0x060DA862u: goto L_060DA862; case 0x060DA864u: goto L_060DA864; case 0x060DA868u: goto L_060DA868; case 0x060DA86Au: goto L_060DA86A; case 0x060DA86Cu: goto L_060DA86C; case 0x060DA86Eu: goto L_060DA86E; case 0x060DA870u: goto L_060DA870; case 0x060DA874u: goto L_060DA874; case 0x060DA876u: goto L_060DA876; case 0x060DA878u: goto L_060DA878; case 0x060DA87Au: goto L_060DA87A; case 0x060DA87Cu: goto L_060DA87C; case 0x060DA87Eu: goto L_060DA87E; case 0x060DA880u: goto L_060DA880; case 0x060DA882u: goto L_060DA882; case 0x060DA884u: goto L_060DA884; case 0x060DA886u: goto L_060DA886; default: sh2_call(c, x); return; } }  // 060DA886 jmp @r0 ; nop
}

void f_060DA88A(SH2Context& c) {
    ran[8] = 1;
    c.r[1] = ld32(0x060DA9BCu);  // 060DA88A mov.l 0x060DA9BC,r1
    c.r[0] = ld32(c.r[1]);  // 060DA88C mov.l @r1,r0
    c.r[1] = ld32(0x060DA9C0u);  // 060DA88E mov.l 0x060DA9C0,r1
    c.t = c.r[0] == c.r[1];  // 060DA890 cmp/eq r1,r0
    if (c.t) { goto L_060DA89A; }  // 060DA892 bt 0x060DA89A
    c.r[1] = ld32(0x060DA9C4u);  // 060DA894 mov.l 0x060DA9C4,r1
    c.t = c.r[0] == c.r[1];  // 060DA896 cmp/eq r1,r0
    if (!c.t) { goto L_060DA8BA; }  // 060DA898 bf 0x060DA8BA
L_060DA89A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA89A sts.l pr,@-r15
    c.pr = 0x060DA8A0u; SH2_POLL(c); sh2_call(c, 0x060DA8BEu); if (c.pc != 0x060DA8A0u) return;  // 060DA89C bsr 0x060DA8BE ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA8A0 lds.l @r15+,pr
    c.r[4] += 1;  // 060DA8A2 add #1,r4
    c.r[1] = ld32(0x060DA9B4u);  // 060DA8A4 mov.l 0x060DA9B4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA8A6 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DA8A8 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 060DA8AA cmp/eq r4,r0
    if (c.t) { goto L_060DA8BA; }  // 060DA8AC bt 0x060DA8BA
    st8(c.r[1], c.r[4]);  // 060DA8AE mov.b r4,@r1
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA8B0 sts.l pr,@-r15
    c.r[0] = ld32(0x060DA9C8u);  // 060DA8B2 mov.l 0x060DA9C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DA8B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DA8B8u) return; }  // 060DA8B4 jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA8B8 lds.l @r15+,pr
L_060DA8BA:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DA8BA rts ; nop
}

void f_060DA8BE(SH2Context& c) {
    ran[9] = 1;
    c.r[1] = ld32(0x060DA9CCu);  // 060DA8BE mov.l 0x060DA9CC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 7);  // 060DA8C0 mov.b @(7,r1),r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DA8C2 extu.b r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA8C4 tst r0,r0
    if (c.t) { goto L_060DA8E6; }  // 060DA8C6 bt 0x060DA8E6
    c.r[0] -= 1;  // 060DA8C8 add #-1,r0
    c.r[4] = c.r[0];  // 060DA8CA mov r0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DA8CC mov.w @(0,r1),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DA8CE tst r0,r0
    if (!c.t) { goto L_060DA8F6; }  // 060DA8D0 bf 0x060DA8F6
    c.r[1] = ld32(0x060DA9D0u);  // 060DA8D2 mov.l 0x060DA9D0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA8D4 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DA8D6 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 060DA8D8 cmp/eq r4,r0
    if (c.t) { goto L_060DA8F6; }  // 060DA8DA bt 0x060DA8F6
    c.r[1] = ld32(0x060DA9D4u);  // 060DA8DC mov.l 0x060DA9D4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA8DE mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DA8E0 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 060DA8E2 cmp/eq r4,r0
    if (c.t) { goto L_060DA8F6; }  // 060DA8E4 bt 0x060DA8F6
L_060DA8E6:
    c.r[1] = ld32(0x060DA9D8u);  // 060DA8E6 mov.l 0x060DA9D8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DA8E8 mov.w @r1,r0
    c.t = (c.r[0] & 0x98u) == 0;  // 060DA8EA tst #152,r0
    c.r[1] = ld32(0x060DA9D0u);  // 060DA8EC mov.l 0x060DA9D0,r1
    if (c.t) { goto L_060DA8F2; }  // 060DA8EE bt 0x060DA8F2
    c.r[1] += 1;  // 060DA8F0 add #1,r1
L_060DA8F2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA8F2 mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060DA8F4 extu.b r4,r4
L_060DA8F6:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DA8F6 rts ; nop
}

void f_060DA8FA(SH2Context& c) {
    ran[10] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA8FA sts.l pr,@-r15
    c.r[2] = ld32(0x060DA9DCu);  // 060DA8FC mov.l 0x060DA9DC,r2
    c.pr = 0x060DA902u; SH2_POLL(c); sh2_call(c, 0x060DA914u); if (c.pc != 0x060DA902u) return;  // 060DA8FE bsr 0x060DA914 ; nop
    c.r[0] = 0x24u;  // 060DA902 mov #36,r0
    c.r[0] <<= 2;  // 060DA904 shll2 r0
    c.pr = 0x060DA90Au; c.r[2] += c.r[0]; SH2_POLL(c); sh2_call(c, 0x060DA914u); if (c.pc != 0x060DA90Au) return;  // 060DA906 bsr 0x060DA914 ; add r0,r2
    c.pr = 0x060DA90Eu; c.r[2] += c.r[1]; SH2_POLL(c); sh2_call(c, 0x060DA914u); if (c.pc != 0x060DA90Eu) return;  // 060DA90A bsr 0x060DA914 ; add r1,r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA90E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DA910 rts ; nop
}

void f_060DA914(SH2Context& c) {
    ran[11] = 1;
    c.r[3] = c.r[2];  // 060DA914 mov r2,r3
    c.r[7] = 0x4u;  // 060DA916 mov #4,r7
    c.r[0] = 0x0u;  // 060DA918 mov #0,r0
L_060DA91A:
    c.r[0] <<= 8;  // 060DA91A shll8 r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060DA91C mov.b @r3+,r6
    c.r[6] = c.r[6] & 0xFFu;  // 060DA91E extu.b r6,r6
    c.r[0] |= c.r[6];  // 060DA920 or r6,r0
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 060DA922 dt r7
    if (!c.t) { SH2_POLL(c); goto L_060DA91A; }  // 060DA924 bf 0x060DA91A
    { const uint32_t x = c.pr; c.r[2] += c.r[0]; c.pc = x; return; }  // 060DA926 rts ; add r0,r2
}

void f_060DA92A(SH2Context& c) {
    ran[12] = 1;
    c.r[1] = ld32(0x060DA9E4u);  // 060DA92A mov.l 0x060DA9E4,r1
    c.r[3] = 0x3Cu;  // 060DA92C mov #60,r3
L_060DA92E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060DA92E mov.b @r1+,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DA930 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 060DA932 cmp/eq r4,r0
    if (c.t) { goto L_060DA996; }  // 060DA934 bt 0x060DA996
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DA936 dt r3
    if (!c.t) { SH2_POLL(c); goto L_060DA92E; }  // 060DA938 bf 0x060DA92E
    c.r[0] = 0x060DA9E0u;  // 060DA93A mova 0x060DA9E0,r0
    c.r[1] = c.r[0];  // 060DA93C mov r0,r1
L_060DA93E:
    c.r[5] = ld32(0x060DA9E8u);  // 060DA93E mov.l 0x060DA9E8,r5
    c.r[6] = 0x1Eu;  // 060DA940 mov #30,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DA942 mov.b @r1,r0
    c.t = c.r[0] == 0x3Eu;  // 060DA944 cmp/eq #62,r0
    if (!c.t) { goto L_060DA94A; }  // 060DA946 bf 0x060DA94A
    c.r[1] += 1;  // 060DA948 add #1,r1
L_060DA94A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060DA94A mov.b @r1+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060DA94C cmp/eq #-1,r0
    if (c.t) { goto L_060DA95C; }  // 060DA94E bt 0x060DA95C
    st8(c.r[5], c.r[0]);  // 060DA950 mov.b r0,@r5
    c.r[5] += 1;  // 060DA952 add #1,r5
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 060DA954 dt r6
    if (!c.t) { SH2_POLL(c); goto L_060DA94A; }  // 060DA956 bf 0x060DA94A
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DA958 rts ; nop
L_060DA95C:
    c.r[7] = c.r[5];  // 060DA95C mov r5,r7
    c.r[7] -= 1;  // 060DA95E add #-1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060DA960 mov.b @r7,r0
    c.t = c.r[0] == 0x3Fu;  // 060DA962 cmp/eq #63,r0
    if (!c.t) { goto L_060DA96A; }  // 060DA964 bf 0x060DA96A
    c.r[5] = c.r[7];  // 060DA966 mov r7,r5
    c.r[6] += 1;  // 060DA968 add #1,r6
L_060DA96A:
    c.r[7] = 0x3u;  // 060DA96A mov #3,r7
L_060DA96C:
    c.t = c.r[6] >= c.r[7];  // 060DA96C cmp/hs r7,r6
    if (!c.t) { goto L_060DA984; }  // 060DA96E bf 0x060DA984
    c.r[0] = 0xFFFFFFF7u;  // 060DA970 mov #-9,r0
    st8(c.r[5], c.r[0]);  // 060DA972 mov.b r0,@r5
    c.r[0] = 0x0u;  // 060DA974 mov #0,r0
    st8(c.r[5] + 1, c.r[0]);  // 060DA976 mov.b r0,@(1,r5)
    c.r[0] = 0x40u;  // 060DA978 mov #64,r0
    st8(c.r[5] + 2, c.r[0]);  // 060DA97A mov.b r0,@(2,r5)
    c.r[5] += 3;  // 060DA97C add #3,r5
    c.r[6] -= 3;  // 060DA97E add #-3,r6
    SH2_POLL(c); goto L_060DA96C;  // 060DA980 bra 0x060DA96C ; nop
L_060DA984:
    c.t = (c.r[6] & c.r[6]) == 0;  // 060DA984 tst r6,r6
    if (c.t) { goto L_060DA992; }  // 060DA986 bt 0x060DA992
    c.r[0] = 0x0u;  // 060DA988 mov #0,r0
L_060DA98A:
    st8(c.r[5], c.r[0]);  // 060DA98A mov.b r0,@r5
    c.r[5] += 1;  // 060DA98C add #1,r5
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 060DA98E dt r6
    if (!c.t) { SH2_POLL(c); goto L_060DA98A; }  // 060DA990 bf 0x060DA98A
L_060DA992:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DA992 rts ; nop
L_060DA996:
    c.r[2] = ld32(0x060DA9ECu);  // 060DA996 mov.l 0x060DA9EC,r2
    c.r[1] -= c.r[2];  // 060DA998 sub r2,r1
    c.r[1] <<= 2;  // 060DA99A shll2 r1
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA99C sts.l pr,@-r15
    c.pr = 0x060DA9A2u; SH2_POLL(c); sh2_call(c, 0x060DA8FAu); if (c.pc != 0x060DA9A2u) return;  // 060DA99E bsr 0x060DA8FA ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA9A2 lds.l @r15+,pr
    c.r[1] = c.r[2];  // 060DA9A4 mov r2,r1
    SH2_POLL(c); goto L_060DA93E;  // 060DA9A6 bra 0x060DA93E ; nop
}

void f_060DA9F0(SH2Context& c) {
    ran[13] = 1;
L_060DA9F0:
    c.r[1] = ld32(0x060DAD60u);  // 060DA9F0 mov.l 0x060DAD60,r1
L_060DA9F2:
    c.r[5] = c.r[0];  // 060DA9F2 mov r0,r5
L_060DA9F4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 6);  // 060DA9F4 mov.b @(6,r1),r0
L_060DA9F6:
    c.t = c.r[0] == 0x0u;  // 060DA9F6 cmp/eq #0,r0
L_060DA9F8:
    if (c.t) { goto L_060DAA2A; }  // 060DA9F8 bt 0x060DAA2A
L_060DA9FA:
    c.r[0] = 0x0u;  // 060DA9FA mov #0,r0
L_060DA9FC:
    st8(c.r[1] + 6, c.r[0]);  // 060DA9FC mov.b r0,@(6,r1)
L_060DA9FE:
    c.r[0] = c.r[5];  // 060DA9FE mov r5,r0
L_060DAA00:
    st8(c.r[1] + 15, c.r[0]);  // 060DAA00 mov.b r0,@(15,r1)
L_060DAA02:
    c.r[0] = c.r[3];  // 060DAA02 mov r3,r0
L_060DAA04:
    st8(c.r[1] + 8, c.r[0]);  // 060DAA04 mov.b r0,@(8,r1)
L_060DAA06:
    c.r[2] = ld32(0x060DAD64u);  // 060DAA06 mov.l 0x060DAD64,r2
L_060DAA08:
    c.r[2] += c.r[5];  // 060DAA08 add r5,r2
L_060DAA0A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060DAA0A mov.b @r2,r0
L_060DAA0C:
    c.r[0] += 1;  // 060DAA0C add #1,r0
L_060DAA0E:
    c.r[2] = ld32(0x060DAD68u);  // 060DAA0E mov.l 0x060DAD68,r2
L_060DAA10:
    st8(c.r[2], c.r[0]);  // 060DAA10 mov.b r0,@r2
L_060DAA12:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 4);  // 060DAA12 mov.b @(4,r1),r0
L_060DAA14:
    c.r[2] = c.r[0] & 0xFFu;  // 060DAA14 extu.b r0,r2
L_060DAA16:
    c.r[6] = c.r[1];  // 060DAA16 mov r1,r6
L_060DAA18:
    c.r[6] += c.r[2];  // 060DAA18 add r2,r6
L_060DAA1A:
    c.r[6] -= 17;  // 060DAA1A add #-17,r6
L_060DAA1C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060DAA1C mov.b @r6,r0
L_060DAA1E:
    c.t = c.r[0] == 0x0u;  // 060DAA1E cmp/eq #0,r0
L_060DAA20:
    if (!c.t) { goto L_060DAA48; }  // 060DAA20 bf 0x060DAA48
L_060DAA22:
    c.r[5] = c.r[2];  // 060DAA22 mov r2,r5
L_060DAA24:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 5);  // 060DAA24 mov.b @(5,r1),r0
L_060DAA26:
    c.r[3] = c.r[0] & 0xFFu; goto L_060DAA48;  // 060DAA26 bra 0x060DAA48 ; extu.b r0,r3
L_060DAA2A:
    c.r[0] = 0x0u;  // 060DAA2A mov #0,r0
L_060DAA2C:
    st8(c.r[1] + 4, c.r[0]);  // 060DAA2C mov.b r0,@(4,r1)
L_060DAA2E:
    c.r[0] = c.r[5];  // 060DAA2E mov r5,r0
L_060DAA30:
    c.r[0] -= 27;  // 060DAA30 add #-27,r0
L_060DAA32:
    c.r[7] = 0x4u;  // 060DAA32 mov #4,r7
L_060DAA34:
    c.t = c.r[0] > c.r[7];  // 060DAA34 cmp/hi r7,r0
L_060DAA36:
    if (c.t) { goto L_060DAA48; }  // 060DAA36 bt 0x060DAA48
L_060DAA38:
    c.r[0] = c.r[3];  // 060DAA38 mov r3,r0
L_060DAA3A:
    st8(c.r[1] + 5, c.r[0]);  // 060DAA3A mov.b r0,@(5,r1)
L_060DAA3C:
    c.r[0] = c.r[5];  // 060DAA3C mov r5,r0
L_060DAA3E:
    st8(c.r[1] + 4, c.r[0]);  // 060DAA3E mov.b r0,@(4,r1)
L_060DAA40:
    st8(c.r[1] + 6, c.r[0]);  // 060DAA40 mov.b r0,@(6,r1)
L_060DAA42:
    c.r[1] = ld32(0x060DAD6Cu);  // 060DAA42 mov.l 0x060DAD6C,r1
L_060DAA44:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x060DA9F0u: goto L_060DA9F0; case 0x060DA9F2u: goto L_060DA9F2; case 0x060DA9F4u: goto L_060DA9F4; case 0x060DA9F6u: goto L_060DA9F6; case 0x060DA9F8u: goto L_060DA9F8; case 0x060DA9FAu: goto L_060DA9FA; case 0x060DA9FCu: goto L_060DA9FC; case 0x060DA9FEu: goto L_060DA9FE; case 0x060DAA00u: goto L_060DAA00; case 0x060DAA02u: goto L_060DAA02; case 0x060DAA04u: goto L_060DAA04; case 0x060DAA06u: goto L_060DAA06; case 0x060DAA08u: goto L_060DAA08; case 0x060DAA0Au: goto L_060DAA0A; case 0x060DAA0Cu: goto L_060DAA0C; case 0x060DAA0Eu: goto L_060DAA0E; case 0x060DAA10u: goto L_060DAA10; case 0x060DAA12u: goto L_060DAA12; case 0x060DAA14u: goto L_060DAA14; case 0x060DAA16u: goto L_060DAA16; case 0x060DAA18u: goto L_060DAA18; case 0x060DAA1Au: goto L_060DAA1A; case 0x060DAA1Cu: goto L_060DAA1C; case 0x060DAA1Eu: goto L_060DAA1E; case 0x060DAA20u: goto L_060DAA20; case 0x060DAA22u: goto L_060DAA22; case 0x060DAA24u: goto L_060DAA24; case 0x060DAA26u: goto L_060DAA26; case 0x060DAA2Au: goto L_060DAA2A; case 0x060DAA2Cu: goto L_060DAA2C; case 0x060DAA2Eu: goto L_060DAA2E; case 0x060DAA30u: goto L_060DAA30; case 0x060DAA32u: goto L_060DAA32; case 0x060DAA34u: goto L_060DAA34; case 0x060DAA36u: goto L_060DAA36; case 0x060DAA38u: goto L_060DAA38; case 0x060DAA3Au: goto L_060DAA3A; case 0x060DAA3Cu: goto L_060DAA3C; case 0x060DAA3Eu: goto L_060DAA3E; case 0x060DAA40u: goto L_060DAA40; case 0x060DAA42u: goto L_060DAA42; case 0x060DAA44u: goto L_060DAA44; case 0x060DAA48u: goto L_060DAA48; case 0x060DAA4Au: goto L_060DAA4A; case 0x060DAA4Cu: goto L_060DAA4C; case 0x060DAA4Eu: goto L_060DAA4E; case 0x060DAA50u: goto L_060DAA50; case 0x060DAA52u: goto L_060DAA52; case 0x060DAA54u: goto L_060DAA54; case 0x060DAA56u: goto L_060DAA56; case 0x060DAA58u: goto L_060DAA58; case 0x060DAA5Au: goto L_060DAA5A; case 0x060DAA5Cu: goto L_060DAA5C; case 0x060DAA5Eu: goto L_060DAA5E; case 0x060DAA60u: goto L_060DAA60; case 0x060DAA64u: goto L_060DAA64; case 0x060DAA66u: goto L_060DAA66; default: sh2_call(c, x); return; } }  // 060DAA44 jmp @r1 ; nop
L_060DAA48:
    c.r[0] = c.r[5];  // 060DAA48 mov r5,r0
L_060DAA4A:
    st8(c.r[1] + 2, c.r[0]);  // 060DAA4A mov.b r0,@(2,r1)
L_060DAA4C:
    c.r[0] = c.r[3];  // 060DAA4C mov r3,r0
L_060DAA4E:
    c.r[0] += 1;  // 060DAA4E add #1,r0
L_060DAA50:
    st8(c.r[1] + 7, c.r[0]);  // 060DAA50 mov.b r0,@(7,r1)
L_060DAA52:
    c.r[2] = ld32(0x060DAD70u);  // 060DAA52 mov.l 0x060DAD70,r2
L_060DAA54:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060DAA54 mov.b @r2,r1
L_060DAA56:
    c.r[1] = c.r[1] & 0xFFu;  // 060DAA56 extu.b r1,r1
L_060DAA58:
    c.t = c.r[1] == c.r[3];  // 060DAA58 cmp/eq r3,r1
L_060DAA5A:
    c.r[0] = ld32(0x060DAD74u);  // 060DAA5A mov.l 0x060DAD74,r0
L_060DAA5C:
    if (!c.t) { goto L_060DAA64; }  // 060DAA5C bf 0x060DAA64
L_060DAA5E:
    c.r[14] += 64;  // 060DAA5E add #64,r14
L_060DAA60:
    { const uint32_t x = c.r[0]; sh2_call(c, x); return; }  // 060DAA60 jmp @r0 ; nop
L_060DAA64:
    c.r[0] += 6;  // 060DAA64 add #6,r0
L_060DAA66:
    { const uint32_t x = c.r[0]; sh2_call(c, x); return; }  // 060DAA66 jmp @r0 ; nop
}

void f_060DAA6A(SH2Context& c) {
    ran[14] = 1;
L_060DAA6A:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DAA6A mov.l r1,@-r15
L_060DAA6C:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DAA6C mov.l r2,@-r15
L_060DAA6E:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DAA6E mov.l r3,@-r15
L_060DAA70:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DAA70 mov.l r4,@-r15
L_060DAA72:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DAA72 mov.l r5,@-r15
L_060DAA74:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DAA74 mov.l r6,@-r15
L_060DAA76:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DAA76 mov.l r7,@-r15
L_060DAA78:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DAA78 sts.l pr,@-r15
L_060DAA7A:
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 060DAA7A sts.l mach,@-r15
L_060DAA7C:
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 060DAA7C sts.l macl,@-r15
L_060DAA7E:
    c.r[5] = ld32(0x060DAD60u);  // 060DAA7E mov.l 0x060DAD60,r5
L_060DAA80:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060DAA80 mov.b @(0,r5),r0
L_060DAA82:
    c.t = c.r[0] == 0x0u;  // 060DAA82 cmp/eq #0,r0
L_060DAA84:
    if (c.t) { goto L_060DAA8E; }  // 060DAA84 bt 0x060DAA8E
L_060DAA86:
    c.pr = 0x060DAA8Au; SH2_POLL(c); sh2_call(c, 0x060DABECu); if (c.pc != 0x060DAA8Au) return;  // 060DAA86 bsr 0x060DABEC ; nop
L_060DAA8A:
    goto L_060DAB22;  // 060DAA8A bra 0x060DAB22 ; nop
L_060DAA8E:
    c.r[1] = ld32(0x060DAD78u);  // 060DAA8E mov.l 0x060DAD78,r1
L_060DAA90:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAA90 mov.w @r1,r0
L_060DAA92:
    c.t = (c.r[0] & 0x8u) == 0;  // 060DAA92 tst #8,r0
L_060DAA94:
    if (!c.t) { goto L_060DAAA6; }  // 060DAA94 bf 0x060DAAA6
L_060DAA96:
    c.r[1] = ld32(0x060DAD7Cu);  // 060DAA96 mov.l 0x060DAD7C,r1
L_060DAA98:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAA98 mov.w @r1,r0
L_060DAA9A:
    c.r[0] = ~c.r[0];  // 060DAA9A not r0,r0
L_060DAA9C:
    c.t = (c.r[0] & 0x8u) == 0;  // 060DAA9C tst #8,r0
L_060DAA9E:
    if (c.t) { goto L_060DAB1E; }  // 060DAA9E bt 0x060DAB1E
L_060DAAA0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 1);  // 060DAAA0 mov.b @(1,r5),r0
L_060DAAA2:
    c.t = c.r[0] == 0x0u;  // 060DAAA2 cmp/eq #0,r0
L_060DAAA4:
    if (!c.t) { goto L_060DAB22; }  // 060DAAA4 bf 0x060DAB22
L_060DAAA6:
    c.r[1] = ld32(0x060DAD80u);  // 060DAAA6 mov.l 0x060DAD80,r1
L_060DAAA8:
    c.r[0] = ld32(c.r[1]);  // 060DAAA8 mov.l @r1,r0
L_060DAAAA:
    c.r[1] = ld32(0x060DAD84u);  // 060DAAAA mov.l 0x060DAD84,r1
L_060DAAAC:
    c.t = c.r[0] == c.r[1];  // 060DAAAC cmp/eq r1,r0
L_060DAAAE:
    if (c.t) { goto L_060DAABC; }  // 060DAAAE bt 0x060DAABC
L_060DAAB0:
    c.r[1] = ld32(0x060DAD88u);  // 060DAAB0 mov.l 0x060DAD88,r1
L_060DAAB2:
    c.t = c.r[0] == c.r[1];  // 060DAAB2 cmp/eq r1,r0
L_060DAAB4:
    if (c.t) { goto L_060DAABC; }  // 060DAAB4 bt 0x060DAABC
L_060DAAB6:
    c.r[1] = ld32(0x060DAD8Cu);  // 060DAAB6 mov.l 0x060DAD8C,r1
L_060DAAB8:
    c.t = c.r[0] == c.r[1];  // 060DAAB8 cmp/eq r1,r0
L_060DAABA:
    if (!c.t) { goto L_060DAB22; }  // 060DAABA bf 0x060DAB22
L_060DAABC:
    c.r[1] = ld32(0x060DAD90u);  // 060DAABC mov.l 0x060DAD90,r1
L_060DAABE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAABE mov.w @r1,r0
L_060DAAC0:
    c.t = c.r[0] == 0x20u;  // 060DAAC0 cmp/eq #32,r0
L_060DAAC2:
    if (!c.t) { goto L_060DAB22; }  // 060DAAC2 bf 0x060DAB22
L_060DAAC4:
    c.pr = 0x060DAAC8u; SH2_POLL(c); sh2_call(c, 0x060DA8BEu); if (c.pc != 0x060DAAC8u) return;  // 060DAAC4 bsr 0x060DA8BE ; nop
L_060DAAC8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 7);  // 060DAAC8 mov.b @(7,r5),r0
L_060DAACA:
    c.r[0] = c.r[0] & 0xFFu;  // 060DAACA extu.b r0,r0
L_060DAACC:
    c.r[0] -= 1;  // 060DAACC add #-1,r0
L_060DAACE:
    c.r[0] = c.r[0] & 0xFFu;  // 060DAACE extu.b r0,r0
L_060DAAD0:
    c.t = c.r[0] == c.r[4];  // 060DAAD0 cmp/eq r4,r0
L_060DAAD2:
    if (!c.t) { goto L_060DAB22; }  // 060DAAD2 bf 0x060DAB22
L_060DAAD4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 4);  // 060DAAD4 mov.b @(4,r5),r0
L_060DAAD6:
    c.r[2] = c.r[0] & 0xFFu;  // 060DAAD6 extu.b r0,r2
L_060DAAD8:
    c.t = (c.r[2] & c.r[2]) == 0;  // 060DAAD8 tst r2,r2
L_060DAADA:
    if (!c.t) { goto L_060DAAF6; }  // 060DAADA bf 0x060DAAF6
L_060DAADC:
    c.r[0] = c.r[4];  // 060DAADC mov r4,r0
L_060DAADE:
    c.pr = 0x060DAAE2u; SH2_POLL(c); sh2_call(c, 0x060DABDCu); if (c.pc != 0x060DAAE2u) return;  // 060DAADE bsr 0x060DABDC ; nop
L_060DAAE2:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060DAAE2 cmp/eq #-1,r0
L_060DAAE4:
    if (c.t) { goto L_060DAB22; }  // 060DAAE4 bt 0x060DAB22
L_060DAAE6:
    c.r[4] = c.r[0];  // 060DAAE6 mov r0,r4
L_060DAAE8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 2);  // 060DAAE8 mov.b @(2,r5),r0
L_060DAAEA:
    c.r[0] = c.r[0] & 0xFFu;  // 060DAAEA extu.b r0,r0
L_060DAAEC:
    c.r[1] = ld32(0x060DAD64u);  // 060DAAEC mov.l 0x060DAD64,r1
L_060DAAEE:
    c.r[1] += c.r[0];  // 060DAAEE add r0,r1
L_060DAAF0:
    st8(c.r[1], c.r[4]);  // 060DAAF0 mov.b r4,@r1
L_060DAAF2:
    goto L_060DAB00;  // 060DAAF2 bra 0x060DAB00 ; nop
L_060DAAF6:
    c.pr = 0x060DAAFAu; SH2_POLL(c); sh2_call(c, 0x060DAB4Eu); if (c.pc != 0x060DAAFAu) return;  // 060DAAF6 bsr 0x060DAB4E ; nop
L_060DAAFA:
    c.r[0] = c.r[4];  // 060DAAFA mov r4,r0
L_060DAAFC:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060DAAFC cmp/eq #-1,r0
L_060DAAFE:
    if (c.t) { goto L_060DAB22; }  // 060DAAFE bt 0x060DAB22
L_060DAB00:
    c.r[0] = 0x1u;  // 060DAB00 mov #1,r0
L_060DAB02:
    st8(c.r[5] + 1, c.r[0]);  // 060DAB02 mov.b r0,@(1,r5)
L_060DAB04:
    c.r[0] = c.r[4];  // 060DAB04 mov r4,r0
L_060DAB06:
    st8(c.r[5] + 3, c.r[0]);  // 060DAB06 mov.b r0,@(3,r5)
L_060DAB08:
    c.r[0] += 1;  // 060DAB08 add #1,r0
L_060DAB0A:
    st8(c.r[5] + 7, c.r[0]);  // 060DAB0A mov.b r0,@(7,r5)
L_060DAB0C:
    c.r[0] = ld32(0x060DAD94u);  // 060DAB0C mov.l 0x060DAD94,r0
L_060DAB0E:
    { const uint32_t x = c.r[0]; c.pr = 0x060DAB12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAB12u) return; }  // 060DAB0E jsr @r0 ; nop
L_060DAB12:
    c.r[0] = 0x0u;  // 060DAB12 mov #0,r0
L_060DAB14:
    st8(c.r[5] + 9, c.r[0]);  // 060DAB14 mov.b r0,@(9,r5)
L_060DAB16:
    c.r[0] = 0x1u;  // 060DAB16 mov #1,r0
L_060DAB18:
    st8(c.r[5], c.r[0]);  // 060DAB18 mov.b r0,@(0,r5)
L_060DAB1A:
    goto L_060DAB22;  // 060DAB1A bra 0x060DAB22 ; nop
L_060DAB1E:
    c.r[0] = 0x0u;  // 060DAB1E mov #0,r0
L_060DAB20:
    st8(c.r[5] + 1, c.r[0]);  // 060DAB20 mov.b r0,@(1,r5)
L_060DAB22:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 060DAB22 lds.l @r15+,macl
L_060DAB24:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 060DAB24 lds.l @r15+,mach
L_060DAB26:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DAB26 lds.l @r15+,pr
L_060DAB28:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB28 mov.l @r15+,r7
L_060DAB2A:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB2A mov.l @r15+,r6
L_060DAB2C:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB2C mov.l @r15+,r5
L_060DAB2E:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB2E mov.l @r15+,r4
L_060DAB30:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB30 mov.l @r15+,r3
L_060DAB32:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB32 mov.l @r15+,r2
L_060DAB34:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DAB34 mov.l @r15+,r1
L_060DAB36:
    c.r[0] = ld32(0x060DAD60u);  // 060DAB36 mov.l 0x060DAD60,r0
L_060DAB38:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060DAB38 mov.b @r0,r0
L_060DAB3A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAB3A tst r0,r0
L_060DAB3C:
    if (c.t) { goto L_060DAB48; }  // 060DAB3C bt 0x060DAB48
L_060DAB3E:
    c.t = c.r[0] == 0x5u;  // 060DAB3E cmp/eq #5,r0
L_060DAB40:
    if (c.t) { goto L_060DAB48; }  // 060DAB40 bt 0x060DAB48
L_060DAB42:
    c.r[0] = ld32(0x060DAD98u);  // 060DAB42 mov.l 0x060DAD98,r0
L_060DAB44:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAA6Au: goto L_060DAA6A; case 0x060DAA6Cu: goto L_060DAA6C; case 0x060DAA6Eu: goto L_060DAA6E; case 0x060DAA70u: goto L_060DAA70; case 0x060DAA72u: goto L_060DAA72; case 0x060DAA74u: goto L_060DAA74; case 0x060DAA76u: goto L_060DAA76; case 0x060DAA78u: goto L_060DAA78; case 0x060DAA7Au: goto L_060DAA7A; case 0x060DAA7Cu: goto L_060DAA7C; case 0x060DAA7Eu: goto L_060DAA7E; case 0x060DAA80u: goto L_060DAA80; case 0x060DAA82u: goto L_060DAA82; case 0x060DAA84u: goto L_060DAA84; case 0x060DAA86u: goto L_060DAA86; case 0x060DAA8Au: goto L_060DAA8A; case 0x060DAA8Eu: goto L_060DAA8E; case 0x060DAA90u: goto L_060DAA90; case 0x060DAA92u: goto L_060DAA92; case 0x060DAA94u: goto L_060DAA94; case 0x060DAA96u: goto L_060DAA96; case 0x060DAA98u: goto L_060DAA98; case 0x060DAA9Au: goto L_060DAA9A; case 0x060DAA9Cu: goto L_060DAA9C; case 0x060DAA9Eu: goto L_060DAA9E; case 0x060DAAA0u: goto L_060DAAA0; case 0x060DAAA2u: goto L_060DAAA2; case 0x060DAAA4u: goto L_060DAAA4; case 0x060DAAA6u: goto L_060DAAA6; case 0x060DAAA8u: goto L_060DAAA8; case 0x060DAAAAu: goto L_060DAAAA; case 0x060DAAACu: goto L_060DAAAC; case 0x060DAAAEu: goto L_060DAAAE; case 0x060DAAB0u: goto L_060DAAB0; case 0x060DAAB2u: goto L_060DAAB2; case 0x060DAAB4u: goto L_060DAAB4; case 0x060DAAB6u: goto L_060DAAB6; case 0x060DAAB8u: goto L_060DAAB8; case 0x060DAABAu: goto L_060DAABA; case 0x060DAABCu: goto L_060DAABC; case 0x060DAABEu: goto L_060DAABE; case 0x060DAAC0u: goto L_060DAAC0; case 0x060DAAC2u: goto L_060DAAC2; case 0x060DAAC4u: goto L_060DAAC4; case 0x060DAAC8u: goto L_060DAAC8; case 0x060DAACAu: goto L_060DAACA; case 0x060DAACCu: goto L_060DAACC; case 0x060DAACEu: goto L_060DAACE; case 0x060DAAD0u: goto L_060DAAD0; case 0x060DAAD2u: goto L_060DAAD2; case 0x060DAAD4u: goto L_060DAAD4; case 0x060DAAD6u: goto L_060DAAD6; case 0x060DAAD8u: goto L_060DAAD8; case 0x060DAADAu: goto L_060DAADA; case 0x060DAADCu: goto L_060DAADC; case 0x060DAADEu: goto L_060DAADE; case 0x060DAAE2u: goto L_060DAAE2; case 0x060DAAE4u: goto L_060DAAE4; case 0x060DAAE6u: goto L_060DAAE6; case 0x060DAAE8u: goto L_060DAAE8; case 0x060DAAEAu: goto L_060DAAEA; case 0x060DAAECu: goto L_060DAAEC; case 0x060DAAEEu: goto L_060DAAEE; case 0x060DAAF0u: goto L_060DAAF0; case 0x060DAAF2u: goto L_060DAAF2; case 0x060DAAF6u: goto L_060DAAF6; case 0x060DAAFAu: goto L_060DAAFA; case 0x060DAAFCu: goto L_060DAAFC; case 0x060DAAFEu: goto L_060DAAFE; case 0x060DAB00u: goto L_060DAB00; case 0x060DAB02u: goto L_060DAB02; case 0x060DAB04u: goto L_060DAB04; case 0x060DAB06u: goto L_060DAB06; case 0x060DAB08u: goto L_060DAB08; case 0x060DAB0Au: goto L_060DAB0A; case 0x060DAB0Cu: goto L_060DAB0C; case 0x060DAB0Eu: goto L_060DAB0E; case 0x060DAB12u: goto L_060DAB12; case 0x060DAB14u: goto L_060DAB14; case 0x060DAB16u: goto L_060DAB16; case 0x060DAB18u: goto L_060DAB18; case 0x060DAB1Au: goto L_060DAB1A; case 0x060DAB1Eu: goto L_060DAB1E; case 0x060DAB20u: goto L_060DAB20; case 0x060DAB22u: goto L_060DAB22; case 0x060DAB24u: goto L_060DAB24; case 0x060DAB26u: goto L_060DAB26; case 0x060DAB28u: goto L_060DAB28; case 0x060DAB2Au: goto L_060DAB2A; case 0x060DAB2Cu: goto L_060DAB2C; case 0x060DAB2Eu: goto L_060DAB2E; case 0x060DAB30u: goto L_060DAB30; case 0x060DAB32u: goto L_060DAB32; case 0x060DAB34u: goto L_060DAB34; case 0x060DAB36u: goto L_060DAB36; case 0x060DAB38u: goto L_060DAB38; case 0x060DAB3Au: goto L_060DAB3A; case 0x060DAB3Cu: goto L_060DAB3C; case 0x060DAB3Eu: goto L_060DAB3E; case 0x060DAB40u: goto L_060DAB40; case 0x060DAB42u: goto L_060DAB42; case 0x060DAB44u: goto L_060DAB44; case 0x060DAB48u: goto L_060DAB48; case 0x060DAB4Au: goto L_060DAB4A; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAB44 jmp @r0 ; nop
L_060DAB48:
    c.r[0] = ld32(0x060DAD9Cu);  // 060DAB48 mov.l 0x060DAD9C,r0
L_060DAB4A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAA6Au: goto L_060DAA6A; case 0x060DAA6Cu: goto L_060DAA6C; case 0x060DAA6Eu: goto L_060DAA6E; case 0x060DAA70u: goto L_060DAA70; case 0x060DAA72u: goto L_060DAA72; case 0x060DAA74u: goto L_060DAA74; case 0x060DAA76u: goto L_060DAA76; case 0x060DAA78u: goto L_060DAA78; case 0x060DAA7Au: goto L_060DAA7A; case 0x060DAA7Cu: goto L_060DAA7C; case 0x060DAA7Eu: goto L_060DAA7E; case 0x060DAA80u: goto L_060DAA80; case 0x060DAA82u: goto L_060DAA82; case 0x060DAA84u: goto L_060DAA84; case 0x060DAA86u: goto L_060DAA86; case 0x060DAA8Au: goto L_060DAA8A; case 0x060DAA8Eu: goto L_060DAA8E; case 0x060DAA90u: goto L_060DAA90; case 0x060DAA92u: goto L_060DAA92; case 0x060DAA94u: goto L_060DAA94; case 0x060DAA96u: goto L_060DAA96; case 0x060DAA98u: goto L_060DAA98; case 0x060DAA9Au: goto L_060DAA9A; case 0x060DAA9Cu: goto L_060DAA9C; case 0x060DAA9Eu: goto L_060DAA9E; case 0x060DAAA0u: goto L_060DAAA0; case 0x060DAAA2u: goto L_060DAAA2; case 0x060DAAA4u: goto L_060DAAA4; case 0x060DAAA6u: goto L_060DAAA6; case 0x060DAAA8u: goto L_060DAAA8; case 0x060DAAAAu: goto L_060DAAAA; case 0x060DAAACu: goto L_060DAAAC; case 0x060DAAAEu: goto L_060DAAAE; case 0x060DAAB0u: goto L_060DAAB0; case 0x060DAAB2u: goto L_060DAAB2; case 0x060DAAB4u: goto L_060DAAB4; case 0x060DAAB6u: goto L_060DAAB6; case 0x060DAAB8u: goto L_060DAAB8; case 0x060DAABAu: goto L_060DAABA; case 0x060DAABCu: goto L_060DAABC; case 0x060DAABEu: goto L_060DAABE; case 0x060DAAC0u: goto L_060DAAC0; case 0x060DAAC2u: goto L_060DAAC2; case 0x060DAAC4u: goto L_060DAAC4; case 0x060DAAC8u: goto L_060DAAC8; case 0x060DAACAu: goto L_060DAACA; case 0x060DAACCu: goto L_060DAACC; case 0x060DAACEu: goto L_060DAACE; case 0x060DAAD0u: goto L_060DAAD0; case 0x060DAAD2u: goto L_060DAAD2; case 0x060DAAD4u: goto L_060DAAD4; case 0x060DAAD6u: goto L_060DAAD6; case 0x060DAAD8u: goto L_060DAAD8; case 0x060DAADAu: goto L_060DAADA; case 0x060DAADCu: goto L_060DAADC; case 0x060DAADEu: goto L_060DAADE; case 0x060DAAE2u: goto L_060DAAE2; case 0x060DAAE4u: goto L_060DAAE4; case 0x060DAAE6u: goto L_060DAAE6; case 0x060DAAE8u: goto L_060DAAE8; case 0x060DAAEAu: goto L_060DAAEA; case 0x060DAAECu: goto L_060DAAEC; case 0x060DAAEEu: goto L_060DAAEE; case 0x060DAAF0u: goto L_060DAAF0; case 0x060DAAF2u: goto L_060DAAF2; case 0x060DAAF6u: goto L_060DAAF6; case 0x060DAAFAu: goto L_060DAAFA; case 0x060DAAFCu: goto L_060DAAFC; case 0x060DAAFEu: goto L_060DAAFE; case 0x060DAB00u: goto L_060DAB00; case 0x060DAB02u: goto L_060DAB02; case 0x060DAB04u: goto L_060DAB04; case 0x060DAB06u: goto L_060DAB06; case 0x060DAB08u: goto L_060DAB08; case 0x060DAB0Au: goto L_060DAB0A; case 0x060DAB0Cu: goto L_060DAB0C; case 0x060DAB0Eu: goto L_060DAB0E; case 0x060DAB12u: goto L_060DAB12; case 0x060DAB14u: goto L_060DAB14; case 0x060DAB16u: goto L_060DAB16; case 0x060DAB18u: goto L_060DAB18; case 0x060DAB1Au: goto L_060DAB1A; case 0x060DAB1Eu: goto L_060DAB1E; case 0x060DAB20u: goto L_060DAB20; case 0x060DAB22u: goto L_060DAB22; case 0x060DAB24u: goto L_060DAB24; case 0x060DAB26u: goto L_060DAB26; case 0x060DAB28u: goto L_060DAB28; case 0x060DAB2Au: goto L_060DAB2A; case 0x060DAB2Cu: goto L_060DAB2C; case 0x060DAB2Eu: goto L_060DAB2E; case 0x060DAB30u: goto L_060DAB30; case 0x060DAB32u: goto L_060DAB32; case 0x060DAB34u: goto L_060DAB34; case 0x060DAB36u: goto L_060DAB36; case 0x060DAB38u: goto L_060DAB38; case 0x060DAB3Au: goto L_060DAB3A; case 0x060DAB3Cu: goto L_060DAB3C; case 0x060DAB3Eu: goto L_060DAB3E; case 0x060DAB40u: goto L_060DAB40; case 0x060DAB42u: goto L_060DAB42; case 0x060DAB44u: goto L_060DAB44; case 0x060DAB48u: goto L_060DAB48; case 0x060DAB4Au: goto L_060DAB4A; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAB4A jmp @r0 ; nop
L_060DAE70:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAE70 mov.w @r1,r1
L_060DAE72:
    c.r[2] = c.r[1] & 0xFFFFu;  // 060DAE72 extu.w r1,r2
L_060DAE74:
    c.r[1] = 0xFu;  // 060DAE74 mov #15,r1
L_060DAE76:
    c.r[1] <<= 8;  // 060DAE76 shll8 r1
L_060DAE78:
    c.r[2] &= c.r[1];  // 060DAE78 and r1,r2
L_060DAE7A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 060DAE7A tst r2,r2
L_060DAE7C:
    c.r[14] = c.r[15];  // 060DAE7C mov r15,r14
L_060DAE7E:
    if (c.t) { goto L_060DAE86; }  // 060DAE7E bt 0x060DAE86
L_060DAE80:
    c.r[0] = ld32(0x060DAEB4u);  // 060DAE80 mov.l 0x060DAEB4,r0
L_060DAE82:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAA6Au: goto L_060DAA6A; case 0x060DAA6Cu: goto L_060DAA6C; case 0x060DAA6Eu: goto L_060DAA6E; case 0x060DAA70u: goto L_060DAA70; case 0x060DAA72u: goto L_060DAA72; case 0x060DAA74u: goto L_060DAA74; case 0x060DAA76u: goto L_060DAA76; case 0x060DAA78u: goto L_060DAA78; case 0x060DAA7Au: goto L_060DAA7A; case 0x060DAA7Cu: goto L_060DAA7C; case 0x060DAA7Eu: goto L_060DAA7E; case 0x060DAA80u: goto L_060DAA80; case 0x060DAA82u: goto L_060DAA82; case 0x060DAA84u: goto L_060DAA84; case 0x060DAA86u: goto L_060DAA86; case 0x060DAA8Au: goto L_060DAA8A; case 0x060DAA8Eu: goto L_060DAA8E; case 0x060DAA90u: goto L_060DAA90; case 0x060DAA92u: goto L_060DAA92; case 0x060DAA94u: goto L_060DAA94; case 0x060DAA96u: goto L_060DAA96; case 0x060DAA98u: goto L_060DAA98; case 0x060DAA9Au: goto L_060DAA9A; case 0x060DAA9Cu: goto L_060DAA9C; case 0x060DAA9Eu: goto L_060DAA9E; case 0x060DAAA0u: goto L_060DAAA0; case 0x060DAAA2u: goto L_060DAAA2; case 0x060DAAA4u: goto L_060DAAA4; case 0x060DAAA6u: goto L_060DAAA6; case 0x060DAAA8u: goto L_060DAAA8; case 0x060DAAAAu: goto L_060DAAAA; case 0x060DAAACu: goto L_060DAAAC; case 0x060DAAAEu: goto L_060DAAAE; case 0x060DAAB0u: goto L_060DAAB0; case 0x060DAAB2u: goto L_060DAAB2; case 0x060DAAB4u: goto L_060DAAB4; case 0x060DAAB6u: goto L_060DAAB6; case 0x060DAAB8u: goto L_060DAAB8; case 0x060DAABAu: goto L_060DAABA; case 0x060DAABCu: goto L_060DAABC; case 0x060DAABEu: goto L_060DAABE; case 0x060DAAC0u: goto L_060DAAC0; case 0x060DAAC2u: goto L_060DAAC2; case 0x060DAAC4u: goto L_060DAAC4; case 0x060DAAC8u: goto L_060DAAC8; case 0x060DAACAu: goto L_060DAACA; case 0x060DAACCu: goto L_060DAACC; case 0x060DAACEu: goto L_060DAACE; case 0x060DAAD0u: goto L_060DAAD0; case 0x060DAAD2u: goto L_060DAAD2; case 0x060DAAD4u: goto L_060DAAD4; case 0x060DAAD6u: goto L_060DAAD6; case 0x060DAAD8u: goto L_060DAAD8; case 0x060DAADAu: goto L_060DAADA; case 0x060DAADCu: goto L_060DAADC; case 0x060DAADEu: goto L_060DAADE; case 0x060DAAE2u: goto L_060DAAE2; case 0x060DAAE4u: goto L_060DAAE4; case 0x060DAAE6u: goto L_060DAAE6; case 0x060DAAE8u: goto L_060DAAE8; case 0x060DAAEAu: goto L_060DAAEA; case 0x060DAAECu: goto L_060DAAEC; case 0x060DAAEEu: goto L_060DAAEE; case 0x060DAAF0u: goto L_060DAAF0; case 0x060DAAF2u: goto L_060DAAF2; case 0x060DAAF6u: goto L_060DAAF6; case 0x060DAAFAu: goto L_060DAAFA; case 0x060DAAFCu: goto L_060DAAFC; case 0x060DAAFEu: goto L_060DAAFE; case 0x060DAB00u: goto L_060DAB00; case 0x060DAB02u: goto L_060DAB02; case 0x060DAB04u: goto L_060DAB04; case 0x060DAB06u: goto L_060DAB06; case 0x060DAB08u: goto L_060DAB08; case 0x060DAB0Au: goto L_060DAB0A; case 0x060DAB0Cu: goto L_060DAB0C; case 0x060DAB0Eu: goto L_060DAB0E; case 0x060DAB12u: goto L_060DAB12; case 0x060DAB14u: goto L_060DAB14; case 0x060DAB16u: goto L_060DAB16; case 0x060DAB18u: goto L_060DAB18; case 0x060DAB1Au: goto L_060DAB1A; case 0x060DAB1Eu: goto L_060DAB1E; case 0x060DAB20u: goto L_060DAB20; case 0x060DAB22u: goto L_060DAB22; case 0x060DAB24u: goto L_060DAB24; case 0x060DAB26u: goto L_060DAB26; case 0x060DAB28u: goto L_060DAB28; case 0x060DAB2Au: goto L_060DAB2A; case 0x060DAB2Cu: goto L_060DAB2C; case 0x060DAB2Eu: goto L_060DAB2E; case 0x060DAB30u: goto L_060DAB30; case 0x060DAB32u: goto L_060DAB32; case 0x060DAB34u: goto L_060DAB34; case 0x060DAB36u: goto L_060DAB36; case 0x060DAB38u: goto L_060DAB38; case 0x060DAB3Au: goto L_060DAB3A; case 0x060DAB3Cu: goto L_060DAB3C; case 0x060DAB3Eu: goto L_060DAB3E; case 0x060DAB40u: goto L_060DAB40; case 0x060DAB42u: goto L_060DAB42; case 0x060DAB44u: goto L_060DAB44; case 0x060DAB48u: goto L_060DAB48; case 0x060DAB4Au: goto L_060DAB4A; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE82 jmp @r0 ; nop
L_060DAE86:
    c.r[0] = ld32(0x060DAEB8u);  // 060DAE86 mov.l 0x060DAEB8,r0
L_060DAE88:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAA6Au: goto L_060DAA6A; case 0x060DAA6Cu: goto L_060DAA6C; case 0x060DAA6Eu: goto L_060DAA6E; case 0x060DAA70u: goto L_060DAA70; case 0x060DAA72u: goto L_060DAA72; case 0x060DAA74u: goto L_060DAA74; case 0x060DAA76u: goto L_060DAA76; case 0x060DAA78u: goto L_060DAA78; case 0x060DAA7Au: goto L_060DAA7A; case 0x060DAA7Cu: goto L_060DAA7C; case 0x060DAA7Eu: goto L_060DAA7E; case 0x060DAA80u: goto L_060DAA80; case 0x060DAA82u: goto L_060DAA82; case 0x060DAA84u: goto L_060DAA84; case 0x060DAA86u: goto L_060DAA86; case 0x060DAA8Au: goto L_060DAA8A; case 0x060DAA8Eu: goto L_060DAA8E; case 0x060DAA90u: goto L_060DAA90; case 0x060DAA92u: goto L_060DAA92; case 0x060DAA94u: goto L_060DAA94; case 0x060DAA96u: goto L_060DAA96; case 0x060DAA98u: goto L_060DAA98; case 0x060DAA9Au: goto L_060DAA9A; case 0x060DAA9Cu: goto L_060DAA9C; case 0x060DAA9Eu: goto L_060DAA9E; case 0x060DAAA0u: goto L_060DAAA0; case 0x060DAAA2u: goto L_060DAAA2; case 0x060DAAA4u: goto L_060DAAA4; case 0x060DAAA6u: goto L_060DAAA6; case 0x060DAAA8u: goto L_060DAAA8; case 0x060DAAAAu: goto L_060DAAAA; case 0x060DAAACu: goto L_060DAAAC; case 0x060DAAAEu: goto L_060DAAAE; case 0x060DAAB0u: goto L_060DAAB0; case 0x060DAAB2u: goto L_060DAAB2; case 0x060DAAB4u: goto L_060DAAB4; case 0x060DAAB6u: goto L_060DAAB6; case 0x060DAAB8u: goto L_060DAAB8; case 0x060DAABAu: goto L_060DAABA; case 0x060DAABCu: goto L_060DAABC; case 0x060DAABEu: goto L_060DAABE; case 0x060DAAC0u: goto L_060DAAC0; case 0x060DAAC2u: goto L_060DAAC2; case 0x060DAAC4u: goto L_060DAAC4; case 0x060DAAC8u: goto L_060DAAC8; case 0x060DAACAu: goto L_060DAACA; case 0x060DAACCu: goto L_060DAACC; case 0x060DAACEu: goto L_060DAACE; case 0x060DAAD0u: goto L_060DAAD0; case 0x060DAAD2u: goto L_060DAAD2; case 0x060DAAD4u: goto L_060DAAD4; case 0x060DAAD6u: goto L_060DAAD6; case 0x060DAAD8u: goto L_060DAAD8; case 0x060DAADAu: goto L_060DAADA; case 0x060DAADCu: goto L_060DAADC; case 0x060DAADEu: goto L_060DAADE; case 0x060DAAE2u: goto L_060DAAE2; case 0x060DAAE4u: goto L_060DAAE4; case 0x060DAAE6u: goto L_060DAAE6; case 0x060DAAE8u: goto L_060DAAE8; case 0x060DAAEAu: goto L_060DAAEA; case 0x060DAAECu: goto L_060DAAEC; case 0x060DAAEEu: goto L_060DAAEE; case 0x060DAAF0u: goto L_060DAAF0; case 0x060DAAF2u: goto L_060DAAF2; case 0x060DAAF6u: goto L_060DAAF6; case 0x060DAAFAu: goto L_060DAAFA; case 0x060DAAFCu: goto L_060DAAFC; case 0x060DAAFEu: goto L_060DAAFE; case 0x060DAB00u: goto L_060DAB00; case 0x060DAB02u: goto L_060DAB02; case 0x060DAB04u: goto L_060DAB04; case 0x060DAB06u: goto L_060DAB06; case 0x060DAB08u: goto L_060DAB08; case 0x060DAB0Au: goto L_060DAB0A; case 0x060DAB0Cu: goto L_060DAB0C; case 0x060DAB0Eu: goto L_060DAB0E; case 0x060DAB12u: goto L_060DAB12; case 0x060DAB14u: goto L_060DAB14; case 0x060DAB16u: goto L_060DAB16; case 0x060DAB18u: goto L_060DAB18; case 0x060DAB1Au: goto L_060DAB1A; case 0x060DAB1Eu: goto L_060DAB1E; case 0x060DAB20u: goto L_060DAB20; case 0x060DAB22u: goto L_060DAB22; case 0x060DAB24u: goto L_060DAB24; case 0x060DAB26u: goto L_060DAB26; case 0x060DAB28u: goto L_060DAB28; case 0x060DAB2Au: goto L_060DAB2A; case 0x060DAB2Cu: goto L_060DAB2C; case 0x060DAB2Eu: goto L_060DAB2E; case 0x060DAB30u: goto L_060DAB30; case 0x060DAB32u: goto L_060DAB32; case 0x060DAB34u: goto L_060DAB34; case 0x060DAB36u: goto L_060DAB36; case 0x060DAB38u: goto L_060DAB38; case 0x060DAB3Au: goto L_060DAB3A; case 0x060DAB3Cu: goto L_060DAB3C; case 0x060DAB3Eu: goto L_060DAB3E; case 0x060DAB40u: goto L_060DAB40; case 0x060DAB42u: goto L_060DAB42; case 0x060DAB44u: goto L_060DAB44; case 0x060DAB48u: goto L_060DAB48; case 0x060DAB4Au: goto L_060DAB4A; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE88 jmp @r0 ; nop
}

void f_060DAB4E(SH2Context& c) {
    ran[15] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DAB4E sts.l pr,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 15);  // 060DAB50 mov.b @(15,r5),r0
    c.r[7] = c.r[0] & 0xFFu;  // 060DAB52 extu.b r0,r7
    c.r[0] = c.r[7];  // 060DAB54 mov r7,r0
    c.r[0] -= 27;  // 060DAB56 add #-27,r0
    c.r[1] = 0x4u;  // 060DAB58 mov #4,r1
    c.t = c.r[0] > c.r[1];  // 060DAB5A cmp/hi r1,r0
    if (!c.t) { goto L_060DABD6; }  // 060DAB5C bf 0x060DABD6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 4);  // 060DAB5E mov.b @(4,r5),r0
    c.r[6] = c.r[5];  // 060DAB60 mov r5,r6
    c.r[6] += c.r[0];  // 060DAB62 add r0,r6
    c.r[6] -= 17;  // 060DAB64 add #-17,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 5);  // 060DAB66 mov.b @(5,r5),r0
    c.r[3] = c.r[0] & 0xFFu;  // 060DAB68 extu.b r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 7);  // 060DAB6A mov.b @(7,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DAB6C extu.b r0,r0
    c.r[0] -= 1;  // 060DAB6E add #-1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DAB70 extu.b r0,r0
    c.t = c.r[0] == c.r[3];  // 060DAB72 cmp/eq r3,r0
    if (c.t) { goto L_060DABB6; }  // 060DAB74 bt 0x060DABB6
    c.pr = 0x060DAB7Au; SH2_POLL(c); sh2_call(c, 0x060DABDCu); if (c.pc != 0x060DAB7Au) return;  // 060DAB76 bsr 0x060DABDC ; nop
    c.t = c.r[0] == c.r[3];  // 060DAB7A cmp/eq r3,r0
    if (!c.t) { goto L_060DAB84; }  // 060DAB7C bf 0x060DAB84
    c.r[0] = c.r[0] & 0xFFu;  // 060DAB7E extu.b r0,r0
    c.pr = 0x060DAB84u; SH2_POLL(c); sh2_call(c, 0x060DABDCu); if (c.pc != 0x060DAB84u) return;  // 060DAB80 bsr 0x060DABDC ; nop
L_060DAB84:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060DAB84 cmp/eq #-1,r0
    if (c.t) { goto L_060DAB9C; }  // 060DAB86 bt 0x060DAB9C
    c.r[4] = c.r[0];  // 060DAB88 mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 8);  // 060DAB8A mov.b @(8,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DAB8C extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 060DAB8E cmp/eq r4,r0
    if (c.t) { goto L_060DAB9C; }  // 060DAB90 bt 0x060DAB9C
    c.r[1] = ld32(0x060DAD64u);  // 060DAB92 mov.l 0x060DAD64,r1
    c.r[1] += c.r[7];  // 060DAB94 add r7,r1
    st8(c.r[1], c.r[4]);  // 060DAB96 mov.b r4,@r1
    goto L_060DABD0;  // 060DAB98 bra 0x060DABD0 ; nop
L_060DAB9C:
    c.r[0] = 0x0u;  // 060DAB9C mov #0,r0
    st8(c.r[6], c.r[0]);  // 060DAB9E mov.b r0,@r6
    c.r[1] = ld32(0x060DAD68u);  // 060DABA0 mov.l 0x060DAD68,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DABA2 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DABA4 extu.b r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DABA6 tst r0,r0
    if (c.t) { goto L_060DABB2; }  // 060DABA8 bt 0x060DABB2
    c.r[0] -= 1;  // 060DABAA add #-1,r0
    c.r[1] = ld32(0x060DAD64u);  // 060DABAC mov.l 0x060DAD64,r1
    c.r[1] += c.r[7];  // 060DABAE add r7,r1
    st8(c.r[1], c.r[0]);  // 060DABB0 mov.b r0,@r1
L_060DABB2:
    c.r[4] = c.r[3]; goto L_060DABD0;  // 060DABB2 bra 0x060DABD0 ; mov r3,r4
L_060DABB6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 8);  // 060DABB6 mov.b @(8,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 060DABB8 extu.b r0,r0
    c.t = c.r[0] == c.r[3];  // 060DABBA cmp/eq r3,r0
    if (!c.t) { goto L_060DABCA; }  // 060DABBC bf 0x060DABCA
    c.pr = 0x060DABC2u; SH2_POLL(c); sh2_call(c, 0x060DABDCu); if (c.pc != 0x060DABC2u) return;  // 060DABBE bsr 0x060DABDC ; nop
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060DABC2 cmp/eq #-1,r0
    if (c.t) { goto L_060DABD6; }  // 060DABC4 bt 0x060DABD6
    st8(c.r[5] + 8, c.r[0]);  // 060DABC6 mov.b r0,@(8,r5)
    c.r[0] = c.r[0] & 0xFFu;  // 060DABC8 extu.b r0,r0
L_060DABCA:
    c.r[4] = c.r[0];  // 060DABCA mov r0,r4
    c.r[0] = 0x1u;  // 060DABCC mov #1,r0
    st8(c.r[6], c.r[0]);  // 060DABCE mov.b r0,@r6
L_060DABD0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DABD0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DABD2 rts ; nop
L_060DABD6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DABD6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] = 0xFFFFFFFFu; c.pc = x; return; }  // 060DABD8 rts ; mov #-1,r4
}

void f_060DABDC(SH2Context& c) {
    ran[16] = 1;
    c.r[1] = 0x26u;  // 060DABDC mov #38,r1
    c.t = c.r[0] >= c.r[1];  // 060DABDE cmp/hs r1,r0
    if (c.t) { goto L_060DABE8; }  // 060DABE0 bt 0x060DABE8
    c.r[1] = ld32(0x060DADA0u);  // 060DABE2 mov.l 0x060DADA0,r1
    { const uint32_t x = c.pr; c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]); c.pc = x; return; }  // 060DABE4 rts ; mov.b @(r0,r1),r0
L_060DABE8:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 060DABE8 rts ; mov #-1,r0
}

void f_060DABEC(SH2Context& c) {
    ran[17] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DABEC sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060DABEE mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060DABF0 mov.l r9,@-r15
    c.r[9] = ld32(0x060DAD60u);  // 060DABF2 mov.l 0x060DAD60,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9] + 9);  // 060DABF4 mov.b @(9,r9),r0
    c.r[0] += 1;  // 060DABF6 add #1,r0
    st8(c.r[9] + 9, c.r[0]);  // 060DABF8 mov.b r0,@(9,r9)
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060DABFA cmp/eq #-1,r0
    if (c.t) { goto L_060DACC0; }  // 060DABFC bt 0x060DACC0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060DABFE mov.b @(0,r9),r0
    c.t = c.r[0] == 0x1u;  // 060DAC00 cmp/eq #1,r0
    if (c.t) { goto L_060DAC28; }  // 060DAC02 bt 0x060DAC28
    c.t = c.r[0] == 0x2u;  // 060DAC04 cmp/eq #2,r0
    if (c.t) { goto L_060DAC4A; }  // 060DAC06 bt 0x060DAC4A
    c.t = c.r[0] == 0x3u;  // 060DAC08 cmp/eq #3,r0
    if (c.t) { goto L_060DAC78; }  // 060DAC0A bt 0x060DAC78
    c.t = c.r[0] == 0x6u;  // 060DAC0C cmp/eq #6,r0
    if (c.t) { goto L_060DAC94; }  // 060DAC0E bt 0x060DAC94
    c.t = c.r[0] == 0x4u;  // 060DAC10 cmp/eq #4,r0
    if (c.t) { goto L_060DACAE; }  // 060DAC12 bt 0x060DACAE
    c.r[0] = ld32(0x060DADA4u);  // 060DAC14 mov.l 0x060DADA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DAC1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAC1Au) return; }  // 060DAC16 jsr @r0 ; nop
    c.r[1] = ld32(0x060DAD90u);  // 060DAC1A mov.l 0x060DAD90,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAC1C mov.w @r1,r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 060DAC1E extu.w r0,r0
    c.t = c.r[0] == 0x20u;  // 060DAC20 cmp/eq #32,r0
    if (!c.t) { goto L_060DACC8; }  // 060DAC22 bf 0x060DACC8
    c.r[0] = 0x0u; goto L_060DACC6;  // 060DAC24 bra 0x060DACC6 ; mov #0,r0
L_060DAC28:
    c.r[1] = ld32(0x060DAD80u);  // 060DAC28 mov.l 0x060DAD80,r1
    c.r[0] = ld32(c.r[1]);  // 060DAC2A mov.l @r1,r0
    c.r[1] = ld32(0x060DAD84u);  // 060DAC2C mov.l 0x060DAD84,r1
    c.t = c.r[0] == c.r[1];  // 060DAC2E cmp/eq r1,r0
    if (c.t) { goto L_060DAC38; }  // 060DAC30 bt 0x060DAC38
    c.r[1] = ld32(0x060DAD88u);  // 060DAC32 mov.l 0x060DAD88,r1
    c.t = c.r[0] == c.r[1];  // 060DAC34 cmp/eq r1,r0
    if (!c.t) { goto L_060DACC8; }  // 060DAC36 bf 0x060DACC8
L_060DAC38:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9] + 3);  // 060DAC38 mov.b @(3,r9),r0
    c.r[4] = c.r[0] & 0xFFu;  // 060DAC3A extu.b r0,r4
    c.r[0] = ld32(0x060DADA8u);  // 060DAC3C mov.l 0x060DADA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DAC42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAC42u) return; }  // 060DAC3E jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAC42 tst r0,r0
    if (!c.t) { goto L_060DACC8; }  // 060DAC44 bf 0x060DACC8
    c.r[0] = 0x2u; goto L_060DACC6;  // 060DAC46 bra 0x060DACC6 ; mov #2,r0
L_060DAC4A:
    c.r[0] = ld32(0x060DADACu);  // 060DAC4A mov.l 0x060DADAC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DAC50u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAC50u) return; }  // 060DAC4C jsr @r0 ; nop
    c.r[1] = ld32(0x060DADB0u);  // 060DAC50 mov.l 0x060DADB0,r1
    c.t = c.r[0] == c.r[1];  // 060DAC52 cmp/eq r1,r0
    if (!c.t) { goto L_060DAC5A; }  // 060DAC54 bf 0x060DAC5A
    c.r[0] = 0x3u; goto L_060DACC6;  // 060DAC56 bra 0x060DACC6 ; mov #3,r0
L_060DAC5A:
    c.r[1] = ld32(0x060DAD90u);  // 060DAC5A mov.l 0x060DAD90,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAC5C mov.w @r1,r0
    c.t = c.r[0] == 0x40u;  // 060DAC5E cmp/eq #64,r0
    if (!c.t) { goto L_060DACC8; }  // 060DAC60 bf 0x060DACC8
    c.r[1] -= 8;  // 060DAC62 add #-8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAC64 mov.w @r1,r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 060DAC66 extu.w r0,r0
    c.r[0] -= 57;  // 060DAC68 add #-57,r0
    c.r[2] = 0x3Fu;  // 060DAC6A mov #63,r2
    c.t = c.r[0] > c.r[2];  // 060DAC6C cmp/hi r2,r0
    if (c.t) { goto L_060DACC8; }  // 060DAC6E bt 0x060DACC8
    c.r[2] = 0x79u;  // 060DAC70 mov #121,r2
    st16(c.r[1], c.r[2]);  // 060DAC72 mov.w r2,@r1
    goto L_060DACC8;  // 060DAC74 bra 0x060DACC8 ; nop
L_060DAC78:
    c.r[1] = ld32(0x060DADB4u);  // 060DAC78 mov.l 0x060DADB4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAC7A mov.w @r1,r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 060DAC7C extu.w r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAC7E tst r0,r0
    if (!c.t) { goto L_060DACC8; }  // 060DAC80 bf 0x060DACC8
    c.r[1] = ld32(0x060DAD90u);  // 060DAC82 mov.l 0x060DAD90,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAC84 mov.w @r1,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060DAC86 tst #1,r0
    if (c.t) { goto L_060DACC8; }  // 060DAC88 bt 0x060DACC8
    c.r[1] = ld32(0x060DADB8u);  // 060DAC8A mov.l 0x060DADB8,r1
    c.r[0] = 0x0u;  // 060DAC8C mov #0,r0
    st8(c.r[1], c.r[0]);  // 060DAC8E mov.b r0,@r1
    c.r[0] = 0x6u; goto L_060DACC6;  // 060DAC90 bra 0x060DACC6 ; mov #6,r0
L_060DAC94:
    c.r[1] = ld32(0x060DADB8u);  // 060DAC94 mov.l 0x060DADB8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DAC96 mov.b @r1,r0
    c.r[0] += 1;  // 060DAC98 add #1,r0
    st8(c.r[1], c.r[0]);  // 060DAC9A mov.b r0,@r1
    c.r[0] = c.r[0] & 0xFFu;  // 060DAC9C extu.b r0,r0
    c.r[1] = 0x8u;  // 060DAC9E mov #8,r1
    c.t = c.r[0] >= c.r[1];  // 060DACA0 cmp/hs r1,r0
    if (!c.t) { goto L_060DACC8; }  // 060DACA2 bf 0x060DACC8
    c.r[0] = ld32(0x060DADBCu);  // 060DACA4 mov.l 0x060DADBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DACAAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DACAAu) return; }  // 060DACA6 jsr @r0 ; mov #0,r4
    c.r[0] = 0x4u; goto L_060DACC6;  // 060DACAA bra 0x060DACC6 ; mov #4,r0
L_060DACAE:
    c.r[0] = ld32(0x060DADBCu);  // 060DACAE mov.l 0x060DADBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DACB4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DACB4u) return; }  // 060DACB0 jsr @r0 ; mov #1,r4
    c.pr = 0x060DACB8u; SH2_POLL(c); sh2_call(c, 0x060DACD2u); if (c.pc != 0x060DACB8u) return;  // 060DACB4 bsr 0x060DACD2 ; nop
    c.r[0] = 0x0u;  // 060DACB8 mov #0,r0
    st8(c.r[9] + 9, c.r[0]);  // 060DACBA mov.b r0,@(9,r9)
    c.r[0] = 0x5u; goto L_060DACC6;  // 060DACBC bra 0x060DACC6 ; mov #5,r0
L_060DACC0:
    c.pr = 0x060DACC4u; SH2_POLL(c); sh2_call(c, 0x060DACD2u); if (c.pc != 0x060DACC4u) return;  // 060DACC0 bsr 0x060DACD2 ; nop
    c.r[0] = 0x0u;  // 060DACC4 mov #0,r0
L_060DACC6:
    st8(c.r[9], c.r[0]);  // 060DACC6 mov.b r0,@(0,r9)
L_060DACC8:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060DACC8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060DACCA mov.l @r15+,r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DACCC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DACCE rts ; nop
}

void f_060DACD2(SH2Context& c) {
    ran[18] = 1;
    c.r[1] = ld32(0x060DAD80u);  // 060DACD2 mov.l 0x060DAD80,r1
    c.r[0] = ld32(c.r[1]);  // 060DACD4 mov.l @r1,r0
    c.r[1] = ld32(0x060DAD84u);  // 060DACD6 mov.l 0x060DAD84,r1
    c.t = c.r[0] == c.r[1];  // 060DACD8 cmp/eq r1,r0
    if (c.t) { goto L_060DACE8; }  // 060DACDA bt 0x060DACE8
    c.r[1] = ld32(0x060DAD88u);  // 060DACDC mov.l 0x060DAD88,r1
    c.t = c.r[0] == c.r[1];  // 060DACDE cmp/eq r1,r0
    if (c.t) { goto L_060DACE8; }  // 060DACE0 bt 0x060DACE8
    c.r[1] = ld32(0x060DAD8Cu);  // 060DACE2 mov.l 0x060DAD8C,r1
    c.t = c.r[0] == c.r[1];  // 060DACE4 cmp/eq r1,r0
    if (!c.t) { goto L_060DAD0E; }  // 060DACE6 bf 0x060DAD0E
L_060DACE8:
    c.r[1] = ld32(0x060DADC0u);  // 060DACE8 mov.l 0x060DADC0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DACEA mov.b @r1,r0
    c.r[0] &= 0xFu;  // 060DACEC and #15,r0
    c.r[2] = c.r[0];  // 060DACEE mov r0,r2
    c.r[2] <<= 2;  // 060DACF0 shll2 r2
    c.r[2] <<= 2;  // 060DACF2 shll2 r2
    c.r[2] |= c.r[0];  // 060DACF4 or r0,r2
    c.r[0] = c.r[2];  // 060DACF6 mov r2,r0
    c.r[0] <<= 8;  // 060DACF8 shll8 r0
    c.r[2] |= c.r[0];  // 060DACFA or r0,r2
    c.r[0] = c.r[2];  // 060DACFC mov r2,r0
    c.r[0] <<= 16;  // 060DACFE shll16 r0
    c.r[2] |= c.r[0];  // 060DAD00 or r0,r2
    c.r[1] = ld32(0x060DADC4u);  // 060DAD02 mov.l 0x060DADC4,r1
    c.r[3] = ld32(0x060DADC8u);  // 060DAD04 mov.l 0x060DADC8,r3
L_060DAD06:
    st32(c.r[1], c.r[2]);  // 060DAD06 mov.l r2,@r1
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DAD08 dt r3
    { const bool k = !c.t; c.r[1] += 4; if (k) { SH2_POLL(c); goto L_060DAD06; } }  // 060DAD0A bf/s 0x060DAD06 ; add #4,r1
L_060DAD0E:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DAD0E rts ; nop
}

void f_060DAD12(SH2Context& c) {
    ran[19] = 1;
    goto L_060DAD12;
L_060DA82A:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DA82A mov.l r1,@-r15
L_060DA82C:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DA82C mov.l r2,@-r15
L_060DA82E:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DA82E mov.l r3,@-r15
L_060DA830:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA830 mov.l r4,@-r15
L_060DA832:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA832 mov.l r5,@-r15
L_060DA834:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA834 mov.l r6,@-r15
L_060DA836:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA836 mov.l r7,@-r15
L_060DA838:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA838 sts.l pr,@-r15
L_060DA83A:
    c.pr = 0x060DA83Eu; SH2_POLL(c); sh2_call(c, 0x060DA88Au); if (c.pc != 0x060DA83Eu) return;  // 060DA83A bsr 0x060DA88A ; nop
L_060DA83E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA83E lds.l @r15+,pr
L_060DA840:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA840 mov.l @r15+,r7
L_060DA842:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA842 mov.l @r15+,r6
L_060DA844:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA844 mov.l @r15+,r5
L_060DA846:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA846 mov.l @r15+,r4
L_060DA848:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DA848 mov.l @r15+,r3
L_060DA84A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DA84A mov.l @r15+,r2
L_060DA84C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DA84C mov.l @r15+,r1
L_060DA84E:
    c.r[0] = ld32(0x060DA9B0u);  // 060DA84E mov.l 0x060DA9B0,r0
L_060DA850:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; case 0x060DAD12u: goto L_060DAD12; case 0x060DAD14u: goto L_060DAD14; case 0x060DAD16u: goto L_060DAD16; case 0x060DAD18u: goto L_060DAD18; case 0x060DAD1Au: goto L_060DAD1A; case 0x060DAD1Cu: goto L_060DAD1C; case 0x060DAD1Eu: goto L_060DAD1E; case 0x060DAD20u: goto L_060DAD20; case 0x060DAD22u: goto L_060DAD22; case 0x060DAD24u: goto L_060DAD24; case 0x060DAD26u: goto L_060DAD26; case 0x060DAD28u: goto L_060DAD28; case 0x060DAD2Au: goto L_060DAD2A; case 0x060DAD2Eu: goto L_060DAD2E; case 0x060DAD30u: goto L_060DAD30; case 0x060DAF00u: goto L_060DAF00; case 0x060DAF02u: goto L_060DAF02; case 0x060DAF04u: goto L_060DAF04; case 0x060DAF06u: goto L_060DAF06; case 0x060DAF08u: goto L_060DAF08; case 0x060DAF0Au: goto L_060DAF0A; case 0x060DAF0Cu: goto L_060DAF0C; case 0x060DAF0Eu: goto L_060DAF0E; case 0x060DAF10u: goto L_060DAF10; case 0x060DAF12u: goto L_060DAF12; case 0x060DAF14u: goto L_060DAF14; case 0x060DAF16u: goto L_060DAF16; case 0x060DAF18u: goto L_060DAF18; case 0x060DAF1Au: goto L_060DAF1A; case 0x060DAF1Cu: goto L_060DAF1C; case 0x060DAF1Eu: goto L_060DAF1E; case 0x060DAF20u: goto L_060DAF20; case 0x060DAF22u: goto L_060DAF22; case 0x060DAF24u: goto L_060DAF24; case 0x060DAF26u: goto L_060DAF26; case 0x060DAF28u: goto L_060DAF28; case 0x060DAF2Au: goto L_060DAF2A; case 0x060DAF2Cu: goto L_060DAF2C; case 0x060DAF2Eu: goto L_060DAF2E; case 0x060DAF30u: goto L_060DAF30; case 0x060DAF32u: goto L_060DAF32; case 0x060DAF34u: goto L_060DAF34; case 0x060DAF36u: goto L_060DAF36; case 0x060DAF38u: goto L_060DAF38; case 0x060DAF3Au: goto L_060DAF3A; case 0x060DAF3Cu: goto L_060DAF3C; case 0x060DAF3Eu: goto L_060DAF3E; case 0x060DAF40u: goto L_060DAF40; case 0x060DAF44u: goto L_060DAF44; case 0x060DAF46u: goto L_060DAF46; case 0x060DAF48u: goto L_060DAF48; case 0x060DAF4Au: goto L_060DAF4A; case 0x060DAF4Cu: goto L_060DAF4C; case 0x060DAF4Eu: goto L_060DAF4E; case 0x060DAF50u: goto L_060DAF50; case 0x060DAF52u: goto L_060DAF52; case 0x060DAF54u: goto L_060DAF54; case 0x060DAF56u: goto L_060DAF56; case 0x060DAF58u: goto L_060DAF58; case 0x060DAF5Cu: goto L_060DAF5C; case 0x060DAF5Eu: goto L_060DAF5E; case 0x060DAF62u: goto L_060DAF62; case 0x060DAF64u: goto L_060DAF64; case 0x060DAF66u: goto L_060DAF66; case 0x060DAF68u: goto L_060DAF68; case 0x060DAF6Au: goto L_060DAF6A; case 0x060DAF6Cu: goto L_060DAF6C; case 0x060DAF6Eu: goto L_060DAF6E; case 0x060DAF70u: goto L_060DAF70; case 0x060DAF72u: goto L_060DAF72; default: sh2_call(c, x); return; } }  // 060DA850 jmp @r0 ; nop
L_060DAD12:
    c.r[0] = ld32(0x060DAD60u);  // 060DAD12 mov.l 0x060DAD60,r0
L_060DAD14:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060DAD14 mov.b @r0,r0
L_060DAD16:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAD16 tst r0,r0
L_060DAD18:
    if (c.t) { goto L_060DAD2E; }  // 060DAD18 bt 0x060DAD2E
L_060DAD1A:
    c.t = c.r[0] == 0x5u;  // 060DAD1A cmp/eq #5,r0
L_060DAD1C:
    if (c.t) { goto L_060DAD2E; }  // 060DAD1C bt 0x060DAD2E
L_060DAD1E:
    c.r[1] = ld32(0x060DAD78u);  // 060DAD1E mov.l 0x060DAD78,r1
L_060DAD20:
    c.r[0] = 0x0u;  // 060DAD20 mov #0,r0
L_060DAD22:
    st16(c.r[1], c.r[0]);  // 060DAD22 mov.w r0,@r1
L_060DAD24:
    c.r[1] = ld32(0x060DADCCu);  // 060DAD24 mov.l 0x060DADCC,r1
L_060DAD26:
    st16(c.r[1], c.r[0]);  // 060DAD26 mov.w r0,@r1
L_060DAD28:
    c.r[0] = ld32(0x060DADD0u);  // 060DAD28 mov.l 0x060DADD0,r0
L_060DAD2A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; case 0x060DAD12u: goto L_060DAD12; case 0x060DAD14u: goto L_060DAD14; case 0x060DAD16u: goto L_060DAD16; case 0x060DAD18u: goto L_060DAD18; case 0x060DAD1Au: goto L_060DAD1A; case 0x060DAD1Cu: goto L_060DAD1C; case 0x060DAD1Eu: goto L_060DAD1E; case 0x060DAD20u: goto L_060DAD20; case 0x060DAD22u: goto L_060DAD22; case 0x060DAD24u: goto L_060DAD24; case 0x060DAD26u: goto L_060DAD26; case 0x060DAD28u: goto L_060DAD28; case 0x060DAD2Au: goto L_060DAD2A; case 0x060DAD2Eu: goto L_060DAD2E; case 0x060DAD30u: goto L_060DAD30; case 0x060DAF00u: goto L_060DAF00; case 0x060DAF02u: goto L_060DAF02; case 0x060DAF04u: goto L_060DAF04; case 0x060DAF06u: goto L_060DAF06; case 0x060DAF08u: goto L_060DAF08; case 0x060DAF0Au: goto L_060DAF0A; case 0x060DAF0Cu: goto L_060DAF0C; case 0x060DAF0Eu: goto L_060DAF0E; case 0x060DAF10u: goto L_060DAF10; case 0x060DAF12u: goto L_060DAF12; case 0x060DAF14u: goto L_060DAF14; case 0x060DAF16u: goto L_060DAF16; case 0x060DAF18u: goto L_060DAF18; case 0x060DAF1Au: goto L_060DAF1A; case 0x060DAF1Cu: goto L_060DAF1C; case 0x060DAF1Eu: goto L_060DAF1E; case 0x060DAF20u: goto L_060DAF20; case 0x060DAF22u: goto L_060DAF22; case 0x060DAF24u: goto L_060DAF24; case 0x060DAF26u: goto L_060DAF26; case 0x060DAF28u: goto L_060DAF28; case 0x060DAF2Au: goto L_060DAF2A; case 0x060DAF2Cu: goto L_060DAF2C; case 0x060DAF2Eu: goto L_060DAF2E; case 0x060DAF30u: goto L_060DAF30; case 0x060DAF32u: goto L_060DAF32; case 0x060DAF34u: goto L_060DAF34; case 0x060DAF36u: goto L_060DAF36; case 0x060DAF38u: goto L_060DAF38; case 0x060DAF3Au: goto L_060DAF3A; case 0x060DAF3Cu: goto L_060DAF3C; case 0x060DAF3Eu: goto L_060DAF3E; case 0x060DAF40u: goto L_060DAF40; case 0x060DAF44u: goto L_060DAF44; case 0x060DAF46u: goto L_060DAF46; case 0x060DAF48u: goto L_060DAF48; case 0x060DAF4Au: goto L_060DAF4A; case 0x060DAF4Cu: goto L_060DAF4C; case 0x060DAF4Eu: goto L_060DAF4E; case 0x060DAF50u: goto L_060DAF50; case 0x060DAF52u: goto L_060DAF52; case 0x060DAF54u: goto L_060DAF54; case 0x060DAF56u: goto L_060DAF56; case 0x060DAF58u: goto L_060DAF58; case 0x060DAF5Cu: goto L_060DAF5C; case 0x060DAF5Eu: goto L_060DAF5E; case 0x060DAF62u: goto L_060DAF62; case 0x060DAF64u: goto L_060DAF64; case 0x060DAF66u: goto L_060DAF66; case 0x060DAF68u: goto L_060DAF68; case 0x060DAF6Au: goto L_060DAF6A; case 0x060DAF6Cu: goto L_060DAF6C; case 0x060DAF6Eu: goto L_060DAF6E; case 0x060DAF70u: goto L_060DAF70; case 0x060DAF72u: goto L_060DAF72; default: sh2_call(c, x); return; } }  // 060DAD2A jmp @r0 ; nop
L_060DAD2E:
    c.r[0] = ld32(0x060DADD4u);  // 060DAD2E mov.l 0x060DADD4,r0
L_060DAD30:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; case 0x060DAD12u: goto L_060DAD12; case 0x060DAD14u: goto L_060DAD14; case 0x060DAD16u: goto L_060DAD16; case 0x060DAD18u: goto L_060DAD18; case 0x060DAD1Au: goto L_060DAD1A; case 0x060DAD1Cu: goto L_060DAD1C; case 0x060DAD1Eu: goto L_060DAD1E; case 0x060DAD20u: goto L_060DAD20; case 0x060DAD22u: goto L_060DAD22; case 0x060DAD24u: goto L_060DAD24; case 0x060DAD26u: goto L_060DAD26; case 0x060DAD28u: goto L_060DAD28; case 0x060DAD2Au: goto L_060DAD2A; case 0x060DAD2Eu: goto L_060DAD2E; case 0x060DAD30u: goto L_060DAD30; case 0x060DAF00u: goto L_060DAF00; case 0x060DAF02u: goto L_060DAF02; case 0x060DAF04u: goto L_060DAF04; case 0x060DAF06u: goto L_060DAF06; case 0x060DAF08u: goto L_060DAF08; case 0x060DAF0Au: goto L_060DAF0A; case 0x060DAF0Cu: goto L_060DAF0C; case 0x060DAF0Eu: goto L_060DAF0E; case 0x060DAF10u: goto L_060DAF10; case 0x060DAF12u: goto L_060DAF12; case 0x060DAF14u: goto L_060DAF14; case 0x060DAF16u: goto L_060DAF16; case 0x060DAF18u: goto L_060DAF18; case 0x060DAF1Au: goto L_060DAF1A; case 0x060DAF1Cu: goto L_060DAF1C; case 0x060DAF1Eu: goto L_060DAF1E; case 0x060DAF20u: goto L_060DAF20; case 0x060DAF22u: goto L_060DAF22; case 0x060DAF24u: goto L_060DAF24; case 0x060DAF26u: goto L_060DAF26; case 0x060DAF28u: goto L_060DAF28; case 0x060DAF2Au: goto L_060DAF2A; case 0x060DAF2Cu: goto L_060DAF2C; case 0x060DAF2Eu: goto L_060DAF2E; case 0x060DAF30u: goto L_060DAF30; case 0x060DAF32u: goto L_060DAF32; case 0x060DAF34u: goto L_060DAF34; case 0x060DAF36u: goto L_060DAF36; case 0x060DAF38u: goto L_060DAF38; case 0x060DAF3Au: goto L_060DAF3A; case 0x060DAF3Cu: goto L_060DAF3C; case 0x060DAF3Eu: goto L_060DAF3E; case 0x060DAF40u: goto L_060DAF40; case 0x060DAF44u: goto L_060DAF44; case 0x060DAF46u: goto L_060DAF46; case 0x060DAF48u: goto L_060DAF48; case 0x060DAF4Au: goto L_060DAF4A; case 0x060DAF4Cu: goto L_060DAF4C; case 0x060DAF4Eu: goto L_060DAF4E; case 0x060DAF50u: goto L_060DAF50; case 0x060DAF52u: goto L_060DAF52; case 0x060DAF54u: goto L_060DAF54; case 0x060DAF56u: goto L_060DAF56; case 0x060DAF58u: goto L_060DAF58; case 0x060DAF5Cu: goto L_060DAF5C; case 0x060DAF5Eu: goto L_060DAF5E; case 0x060DAF62u: goto L_060DAF62; case 0x060DAF64u: goto L_060DAF64; case 0x060DAF66u: goto L_060DAF66; case 0x060DAF68u: goto L_060DAF68; case 0x060DAF6Au: goto L_060DAF6A; case 0x060DAF6Cu: goto L_060DAF6C; case 0x060DAF6Eu: goto L_060DAF6E; case 0x060DAF70u: goto L_060DAF70; case 0x060DAF72u: goto L_060DAF72; default: sh2_call(c, x); return; } }  // 060DAD30 jmp @r0 ; nop
L_060DAF00:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DAF00 mov.l r0,@-r15
L_060DAF02:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DAF02 mov.l r1,@-r15
L_060DAF04:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DAF04 mov.l r2,@-r15
L_060DAF06:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DAF06 mov.l r3,@-r15
L_060DAF08:
    c.r[3] = ld32(0x060DAF78u);  // 060DAF08 mov.l 0x060DAF78,r3
L_060DAF0A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060DAF0A mov.w @r3,r0
L_060DAF0C:
    c.r[0] = ~c.r[0];  // 060DAF0C not r0,r0
L_060DAF0E:
    c.r[3] = ld32(0x060DAF7Cu);  // 060DAF0E mov.l 0x060DAF7C,r3
L_060DAF10:
    c.r[0] &= c.r[3];  // 060DAF10 and r3,r0
L_060DAF12:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAF12 tst r0,r0
L_060DAF14:
    if (c.t) { goto L_060DAF62; }  // 060DAF14 bt 0x060DAF62
L_060DAF16:
    c.r[3] = ld32(0x060DAF80u);  // 060DAF16 mov.l 0x060DAF80,r3
L_060DAF18:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060DAF18 mov.b @r3,r0
L_060DAF1A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAF1A tst r0,r0
L_060DAF1C:
    if (!c.t) { goto L_060DAF68; }  // 060DAF1C bf 0x060DAF68
L_060DAF1E:
    c.r[0] = 0x1u;  // 060DAF1E mov #1,r0
L_060DAF20:
    st8(c.r[3], c.r[0]);  // 060DAF20 mov.b r0,@r3
L_060DAF22:
    c.r[3] = ld32(0x060DAF84u);  // 060DAF22 mov.l 0x060DAF84,r3
L_060DAF24:
    c.r[0] = ld32(c.r[3]);  // 060DAF24 mov.l @r3,r0
L_060DAF26:
    c.r[3] = ld32(0x060DAF88u);  // 060DAF26 mov.l 0x060DAF88,r3
L_060DAF28:
    c.t = c.r[0] == c.r[3];  // 060DAF28 cmp/eq r3,r0
L_060DAF2A:
    if (c.t) { goto L_060DAF32; }  // 060DAF2A bt 0x060DAF32
L_060DAF2C:
    c.r[3] = ld32(0x060DAF8Cu);  // 060DAF2C mov.l 0x060DAF8C,r3
L_060DAF2E:
    c.t = c.r[0] == c.r[3];  // 060DAF2E cmp/eq r3,r0
L_060DAF30:
    if (!c.t) { goto L_060DAF68; }  // 060DAF30 bf 0x060DAF68
L_060DAF32:
    c.r[1] = ld32(0x060DAF90u);  // 060DAF32 mov.l 0x060DAF90,r1
L_060DAF34:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DAF34 mov.b @r1,r0
L_060DAF36:
    c.r[0] ^= 0x1u;  // 060DAF36 xor #1,r0
L_060DAF38:
    st8(c.r[1], c.r[0]);  // 060DAF38 mov.b r0,@r1
L_060DAF3A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAF3A tst r0,r0
L_060DAF3C:
    if (c.t) { goto L_060DAF44; }  // 060DAF3C bt 0x060DAF44
L_060DAF3E:
    c.r[2] = ld32(0x060DAF94u);  // 060DAF3E mov.l 0x060DAF94,r2
L_060DAF40:
    goto L_060DAF46;  // 060DAF40 bra 0x060DAF46 ; nop
L_060DAF44:
    c.r[2] = ld32(0x060DAF98u);  // 060DAF44 mov.l 0x060DAF98,r2
L_060DAF46:
    c.r[1] = ld32(0x060DAF9Cu);  // 060DAF46 mov.l 0x060DAF9C,r1
L_060DAF48:
    c.r[3] = 0x4u;  // 060DAF48 mov #4,r3
L_060DAF4A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 060DAF4A mov.w @r2+,r0
L_060DAF4C:
    st16(c.r[1], c.r[0]);  // 060DAF4C mov.w r0,@r1
L_060DAF4E:
    c.r[1] += 2;  // 060DAF4E add #2,r1
L_060DAF50:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DAF50 dt r3
L_060DAF52:
    if (!c.t) { SH2_POLL(c); goto L_060DAF4A; }  // 060DAF52 bf 0x060DAF4A
L_060DAF54:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DAF54 sts.l pr,@-r15
L_060DAF56:
    c.r[0] = ld32(0x060DAFACu);  // 060DAF56 mov.l 0x060DAFAC,r0
L_060DAF58:
    { const uint32_t x = c.r[0]; c.pr = 0x060DAF5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAF5Cu) return; }  // 060DAF58 jsr @r0 ; nop
L_060DAF5C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DAF5C lds.l @r15+,pr
L_060DAF5E:
    goto L_060DAF68;  // 060DAF5E bra 0x060DAF68 ; nop
L_060DAF62:
    c.r[3] = ld32(0x060DAF80u);  // 060DAF62 mov.l 0x060DAF80,r3
L_060DAF64:
    c.r[0] = 0x0u;  // 060DAF64 mov #0,r0
L_060DAF66:
    st8(c.r[3], c.r[0]);  // 060DAF66 mov.b r0,@r3
L_060DAF68:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF68 mov.l @r15+,r3
L_060DAF6A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF6A mov.l @r15+,r2
L_060DAF6C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF6C mov.l @r15+,r1
L_060DAF6E:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF6E mov.l @r15+,r0
L_060DAF70:
    c.r[0] = ld32(0x060DAFA8u);  // 060DAF70 mov.l 0x060DAFA8,r0
L_060DAF72:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; case 0x060DAD12u: goto L_060DAD12; case 0x060DAD14u: goto L_060DAD14; case 0x060DAD16u: goto L_060DAD16; case 0x060DAD18u: goto L_060DAD18; case 0x060DAD1Au: goto L_060DAD1A; case 0x060DAD1Cu: goto L_060DAD1C; case 0x060DAD1Eu: goto L_060DAD1E; case 0x060DAD20u: goto L_060DAD20; case 0x060DAD22u: goto L_060DAD22; case 0x060DAD24u: goto L_060DAD24; case 0x060DAD26u: goto L_060DAD26; case 0x060DAD28u: goto L_060DAD28; case 0x060DAD2Au: goto L_060DAD2A; case 0x060DAD2Eu: goto L_060DAD2E; case 0x060DAD30u: goto L_060DAD30; case 0x060DAF00u: goto L_060DAF00; case 0x060DAF02u: goto L_060DAF02; case 0x060DAF04u: goto L_060DAF04; case 0x060DAF06u: goto L_060DAF06; case 0x060DAF08u: goto L_060DAF08; case 0x060DAF0Au: goto L_060DAF0A; case 0x060DAF0Cu: goto L_060DAF0C; case 0x060DAF0Eu: goto L_060DAF0E; case 0x060DAF10u: goto L_060DAF10; case 0x060DAF12u: goto L_060DAF12; case 0x060DAF14u: goto L_060DAF14; case 0x060DAF16u: goto L_060DAF16; case 0x060DAF18u: goto L_060DAF18; case 0x060DAF1Au: goto L_060DAF1A; case 0x060DAF1Cu: goto L_060DAF1C; case 0x060DAF1Eu: goto L_060DAF1E; case 0x060DAF20u: goto L_060DAF20; case 0x060DAF22u: goto L_060DAF22; case 0x060DAF24u: goto L_060DAF24; case 0x060DAF26u: goto L_060DAF26; case 0x060DAF28u: goto L_060DAF28; case 0x060DAF2Au: goto L_060DAF2A; case 0x060DAF2Cu: goto L_060DAF2C; case 0x060DAF2Eu: goto L_060DAF2E; case 0x060DAF30u: goto L_060DAF30; case 0x060DAF32u: goto L_060DAF32; case 0x060DAF34u: goto L_060DAF34; case 0x060DAF36u: goto L_060DAF36; case 0x060DAF38u: goto L_060DAF38; case 0x060DAF3Au: goto L_060DAF3A; case 0x060DAF3Cu: goto L_060DAF3C; case 0x060DAF3Eu: goto L_060DAF3E; case 0x060DAF40u: goto L_060DAF40; case 0x060DAF44u: goto L_060DAF44; case 0x060DAF46u: goto L_060DAF46; case 0x060DAF48u: goto L_060DAF48; case 0x060DAF4Au: goto L_060DAF4A; case 0x060DAF4Cu: goto L_060DAF4C; case 0x060DAF4Eu: goto L_060DAF4E; case 0x060DAF50u: goto L_060DAF50; case 0x060DAF52u: goto L_060DAF52; case 0x060DAF54u: goto L_060DAF54; case 0x060DAF56u: goto L_060DAF56; case 0x060DAF58u: goto L_060DAF58; case 0x060DAF5Cu: goto L_060DAF5C; case 0x060DAF5Eu: goto L_060DAF5E; case 0x060DAF62u: goto L_060DAF62; case 0x060DAF64u: goto L_060DAF64; case 0x060DAF66u: goto L_060DAF66; case 0x060DAF68u: goto L_060DAF68; case 0x060DAF6Au: goto L_060DAF6A; case 0x060DAF6Cu: goto L_060DAF6C; case 0x060DAF6Eu: goto L_060DAF6E; case 0x060DAF70u: goto L_060DAF70; case 0x060DAF72u: goto L_060DAF72; default: sh2_call(c, x); return; } }  // 060DAF72 jmp @r0 ; nop
}

void f_060DAD34(SH2Context& c) {
    ran[20] = 1;
L_060DAD34:
    c.r[0] = ld32(0x060DAD60u);  // 060DAD34 mov.l 0x060DAD60,r0
L_060DAD36:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060DAD36 mov.b @r0,r0
L_060DAD38:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAD38 tst r0,r0
L_060DAD3A:
    if (c.t) { goto L_060DAD44; }  // 060DAD3A bt 0x060DAD44
L_060DAD3C:
    c.t = c.r[0] == 0x5u;  // 060DAD3C cmp/eq #5,r0
L_060DAD3E:
    if (c.t) { goto L_060DAD44; }  // 060DAD3E bt 0x060DAD44
L_060DAD40:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060DAD40 rts ; mov #0,r0
L_060DAD44:
    c.r[0] = ld32(0x060DADD8u);  // 060DAD44 mov.l 0x060DADD8,r0
L_060DAD46:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAD34u: goto L_060DAD34; case 0x060DAD36u: goto L_060DAD36; case 0x060DAD38u: goto L_060DAD38; case 0x060DAD3Au: goto L_060DAD3A; case 0x060DAD3Cu: goto L_060DAD3C; case 0x060DAD3Eu: goto L_060DAD3E; case 0x060DAD40u: goto L_060DAD40; case 0x060DAD44u: goto L_060DAD44; case 0x060DAD46u: goto L_060DAD46; default: sh2_call(c, x); return; } }  // 060DAD46 jmp @r0 ; nop
}

void f_060DAD4A(SH2Context& c) {
    ran[21] = 1;
L_060DAD4A:
    c.r[0] = ld32(0x060DAD60u);  // 060DAD4A mov.l 0x060DAD60,r0
L_060DAD4C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060DAD4C mov.b @r0,r0
L_060DAD4E:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAD4E tst r0,r0
L_060DAD50:
    if (c.t) { goto L_060DAD5A; }  // 060DAD50 bt 0x060DAD5A
L_060DAD52:
    c.t = c.r[0] == 0x5u;  // 060DAD52 cmp/eq #5,r0
L_060DAD54:
    if (c.t) { goto L_060DAD5A; }  // 060DAD54 bt 0x060DAD5A
L_060DAD56:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DAD56 rts ; nop
L_060DAD5A:
    c.r[1] = ld32(0x060DADDCu);  // 060DAD5A mov.l 0x060DADDC,r1
L_060DAD5C:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x060DAD4Au: goto L_060DAD4A; case 0x060DAD4Cu: goto L_060DAD4C; case 0x060DAD4Eu: goto L_060DAD4E; case 0x060DAD50u: goto L_060DAD50; case 0x060DAD52u: goto L_060DAD52; case 0x060DAD54u: goto L_060DAD54; case 0x060DAD56u: goto L_060DAD56; case 0x060DAD5Au: goto L_060DAD5A; case 0x060DAD5Cu: goto L_060DAD5C; default: sh2_call(c, x); return; } }  // 060DAD5C jmp @r1 ; nop
}

void f_060DAE00(SH2Context& c) {
    ran[22] = 1;
L_060DAE00:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DAE00 mov.l r0,@-r15
L_060DAE02:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DAE02 mov.l r1,@-r15
L_060DAE04:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DAE04 mov.l r2,@-r15
L_060DAE06:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DAE06 mov.l r3,@-r15
L_060DAE08:
    c.r[3] = ld32(0x060DAE8Cu);  // 060DAE08 mov.l 0x060DAE8C,r3
L_060DAE0A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060DAE0A mov.w @r3,r0
L_060DAE0C:
    c.r[0] = ~c.r[0];  // 060DAE0C not r0,r0
L_060DAE0E:
    c.r[3] = ld32(0x060DAE90u);  // 060DAE0E mov.l 0x060DAE90,r3
L_060DAE10:
    c.r[0] &= c.r[3];  // 060DAE10 and r3,r0
L_060DAE12:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAE12 tst r0,r0
L_060DAE14:
    if (c.t) { goto L_060DAE62; }  // 060DAE14 bt 0x060DAE62
L_060DAE16:
    c.r[3] = ld32(0x060DAE94u);  // 060DAE16 mov.l 0x060DAE94,r3
L_060DAE18:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060DAE18 mov.b @r3,r0
L_060DAE1A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAE1A tst r0,r0
L_060DAE1C:
    if (!c.t) { goto L_060DAE68; }  // 060DAE1C bf 0x060DAE68
L_060DAE1E:
    c.r[0] = 0x1u;  // 060DAE1E mov #1,r0
L_060DAE20:
    st8(c.r[3], c.r[0]);  // 060DAE20 mov.b r0,@r3
L_060DAE22:
    c.r[3] = ld32(0x060DAE98u);  // 060DAE22 mov.l 0x060DAE98,r3
L_060DAE24:
    c.r[0] = ld32(c.r[3]);  // 060DAE24 mov.l @r3,r0
L_060DAE26:
    c.r[3] = ld32(0x060DAE9Cu);  // 060DAE26 mov.l 0x060DAE9C,r3
L_060DAE28:
    c.t = c.r[0] == c.r[3];  // 060DAE28 cmp/eq r3,r0
L_060DAE2A:
    if (c.t) { goto L_060DAE32; }  // 060DAE2A bt 0x060DAE32
L_060DAE2C:
    c.r[3] = ld32(0x060DAEA0u);  // 060DAE2C mov.l 0x060DAEA0,r3
L_060DAE2E:
    c.t = c.r[0] == c.r[3];  // 060DAE2E cmp/eq r3,r0
L_060DAE30:
    if (!c.t) { goto L_060DAE68; }  // 060DAE30 bf 0x060DAE68
L_060DAE32:
    c.r[1] = ld32(0x060DAEA4u);  // 060DAE32 mov.l 0x060DAEA4,r1
L_060DAE34:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DAE34 mov.b @r1,r0
L_060DAE36:
    c.r[0] ^= 0x1u;  // 060DAE36 xor #1,r0
L_060DAE38:
    st8(c.r[1], c.r[0]);  // 060DAE38 mov.b r0,@r1
L_060DAE3A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAE3A tst r0,r0
L_060DAE3C:
    if (c.t) { goto L_060DAE44; }  // 060DAE3C bt 0x060DAE44
L_060DAE3E:
    c.r[2] = ld32(0x060DAEA8u);  // 060DAE3E mov.l 0x060DAEA8,r2
L_060DAE40:
    goto L_060DAE46;  // 060DAE40 bra 0x060DAE46 ; nop
L_060DAE44:
    c.r[2] = ld32(0x060DAEACu);  // 060DAE44 mov.l 0x060DAEAC,r2
L_060DAE46:
    c.r[1] = ld32(0x060DAEB0u);  // 060DAE46 mov.l 0x060DAEB0,r1
L_060DAE48:
    c.r[3] = 0x4u;  // 060DAE48 mov #4,r3
L_060DAE4A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 060DAE4A mov.w @r2+,r0
L_060DAE4C:
    st16(c.r[1], c.r[0]);  // 060DAE4C mov.w r0,@r1
L_060DAE4E:
    c.r[1] += 2;  // 060DAE4E add #2,r1
L_060DAE50:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DAE50 dt r3
L_060DAE52:
    if (!c.t) { SH2_POLL(c); goto L_060DAE4A; }  // 060DAE52 bf 0x060DAE4A
L_060DAE54:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DAE54 sts.l pr,@-r15
L_060DAE56:
    c.r[0] = ld32(0x060DAEC0u);  // 060DAE56 mov.l 0x060DAEC0,r0
L_060DAE58:
    { const uint32_t x = c.r[0]; c.pr = 0x060DAE5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAE5Cu) return; }  // 060DAE58 jsr @r0 ; nop
L_060DAE5C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DAE5C lds.l @r15+,pr
L_060DAE5E:
    goto L_060DAE68;  // 060DAE5E bra 0x060DAE68 ; nop
L_060DAE62:
    c.r[3] = ld32(0x060DAE94u);  // 060DAE62 mov.l 0x060DAE94,r3
L_060DAE64:
    c.r[0] = 0x0u;  // 060DAE64 mov #0,r0
L_060DAE66:
    st8(c.r[3], c.r[0]);  // 060DAE66 mov.b r0,@r3
L_060DAE68:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE68 mov.l @r15+,r3
L_060DAE6A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE6A mov.l @r15+,r2
L_060DAE6C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE6C mov.l @r15+,r1
L_060DAE6E:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DAE6E mov.l @r15+,r0
L_060DAE70:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAE70 mov.w @r1,r1
L_060DAE72:
    c.r[2] = c.r[1] & 0xFFFFu;  // 060DAE72 extu.w r1,r2
L_060DAE74:
    c.r[1] = 0xFu;  // 060DAE74 mov #15,r1
L_060DAE76:
    c.r[1] <<= 8;  // 060DAE76 shll8 r1
L_060DAE78:
    c.r[2] &= c.r[1];  // 060DAE78 and r1,r2
L_060DAE7A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 060DAE7A tst r2,r2
L_060DAE7C:
    c.r[14] = c.r[15];  // 060DAE7C mov r15,r14
L_060DAE7E:
    if (c.t) { goto L_060DAE86; }  // 060DAE7E bt 0x060DAE86
L_060DAE80:
    c.r[0] = ld32(0x060DAEB4u);  // 060DAE80 mov.l 0x060DAEB4,r0
L_060DAE82:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAE00u: goto L_060DAE00; case 0x060DAE02u: goto L_060DAE02; case 0x060DAE04u: goto L_060DAE04; case 0x060DAE06u: goto L_060DAE06; case 0x060DAE08u: goto L_060DAE08; case 0x060DAE0Au: goto L_060DAE0A; case 0x060DAE0Cu: goto L_060DAE0C; case 0x060DAE0Eu: goto L_060DAE0E; case 0x060DAE10u: goto L_060DAE10; case 0x060DAE12u: goto L_060DAE12; case 0x060DAE14u: goto L_060DAE14; case 0x060DAE16u: goto L_060DAE16; case 0x060DAE18u: goto L_060DAE18; case 0x060DAE1Au: goto L_060DAE1A; case 0x060DAE1Cu: goto L_060DAE1C; case 0x060DAE1Eu: goto L_060DAE1E; case 0x060DAE20u: goto L_060DAE20; case 0x060DAE22u: goto L_060DAE22; case 0x060DAE24u: goto L_060DAE24; case 0x060DAE26u: goto L_060DAE26; case 0x060DAE28u: goto L_060DAE28; case 0x060DAE2Au: goto L_060DAE2A; case 0x060DAE2Cu: goto L_060DAE2C; case 0x060DAE2Eu: goto L_060DAE2E; case 0x060DAE30u: goto L_060DAE30; case 0x060DAE32u: goto L_060DAE32; case 0x060DAE34u: goto L_060DAE34; case 0x060DAE36u: goto L_060DAE36; case 0x060DAE38u: goto L_060DAE38; case 0x060DAE3Au: goto L_060DAE3A; case 0x060DAE3Cu: goto L_060DAE3C; case 0x060DAE3Eu: goto L_060DAE3E; case 0x060DAE40u: goto L_060DAE40; case 0x060DAE44u: goto L_060DAE44; case 0x060DAE46u: goto L_060DAE46; case 0x060DAE48u: goto L_060DAE48; case 0x060DAE4Au: goto L_060DAE4A; case 0x060DAE4Cu: goto L_060DAE4C; case 0x060DAE4Eu: goto L_060DAE4E; case 0x060DAE50u: goto L_060DAE50; case 0x060DAE52u: goto L_060DAE52; case 0x060DAE54u: goto L_060DAE54; case 0x060DAE56u: goto L_060DAE56; case 0x060DAE58u: goto L_060DAE58; case 0x060DAE5Cu: goto L_060DAE5C; case 0x060DAE5Eu: goto L_060DAE5E; case 0x060DAE62u: goto L_060DAE62; case 0x060DAE64u: goto L_060DAE64; case 0x060DAE66u: goto L_060DAE66; case 0x060DAE68u: goto L_060DAE68; case 0x060DAE6Au: goto L_060DAE6A; case 0x060DAE6Cu: goto L_060DAE6C; case 0x060DAE6Eu: goto L_060DAE6E; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE82 jmp @r0 ; nop
L_060DAE86:
    c.r[0] = ld32(0x060DAEB8u);  // 060DAE86 mov.l 0x060DAEB8,r0
L_060DAE88:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAE00u: goto L_060DAE00; case 0x060DAE02u: goto L_060DAE02; case 0x060DAE04u: goto L_060DAE04; case 0x060DAE06u: goto L_060DAE06; case 0x060DAE08u: goto L_060DAE08; case 0x060DAE0Au: goto L_060DAE0A; case 0x060DAE0Cu: goto L_060DAE0C; case 0x060DAE0Eu: goto L_060DAE0E; case 0x060DAE10u: goto L_060DAE10; case 0x060DAE12u: goto L_060DAE12; case 0x060DAE14u: goto L_060DAE14; case 0x060DAE16u: goto L_060DAE16; case 0x060DAE18u: goto L_060DAE18; case 0x060DAE1Au: goto L_060DAE1A; case 0x060DAE1Cu: goto L_060DAE1C; case 0x060DAE1Eu: goto L_060DAE1E; case 0x060DAE20u: goto L_060DAE20; case 0x060DAE22u: goto L_060DAE22; case 0x060DAE24u: goto L_060DAE24; case 0x060DAE26u: goto L_060DAE26; case 0x060DAE28u: goto L_060DAE28; case 0x060DAE2Au: goto L_060DAE2A; case 0x060DAE2Cu: goto L_060DAE2C; case 0x060DAE2Eu: goto L_060DAE2E; case 0x060DAE30u: goto L_060DAE30; case 0x060DAE32u: goto L_060DAE32; case 0x060DAE34u: goto L_060DAE34; case 0x060DAE36u: goto L_060DAE36; case 0x060DAE38u: goto L_060DAE38; case 0x060DAE3Au: goto L_060DAE3A; case 0x060DAE3Cu: goto L_060DAE3C; case 0x060DAE3Eu: goto L_060DAE3E; case 0x060DAE40u: goto L_060DAE40; case 0x060DAE44u: goto L_060DAE44; case 0x060DAE46u: goto L_060DAE46; case 0x060DAE48u: goto L_060DAE48; case 0x060DAE4Au: goto L_060DAE4A; case 0x060DAE4Cu: goto L_060DAE4C; case 0x060DAE4Eu: goto L_060DAE4E; case 0x060DAE50u: goto L_060DAE50; case 0x060DAE52u: goto L_060DAE52; case 0x060DAE54u: goto L_060DAE54; case 0x060DAE56u: goto L_060DAE56; case 0x060DAE58u: goto L_060DAE58; case 0x060DAE5Cu: goto L_060DAE5C; case 0x060DAE5Eu: goto L_060DAE5E; case 0x060DAE62u: goto L_060DAE62; case 0x060DAE64u: goto L_060DAE64; case 0x060DAE66u: goto L_060DAE66; case 0x060DAE68u: goto L_060DAE68; case 0x060DAE6Au: goto L_060DAE6A; case 0x060DAE6Cu: goto L_060DAE6C; case 0x060DAE6Eu: goto L_060DAE6E; case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE88 jmp @r0 ; nop
}

void f_060DAE70(SH2Context& c) {
    ran[23] = 1;
L_060DAE70:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DAE70 mov.w @r1,r1
L_060DAE72:
    c.r[2] = c.r[1] & 0xFFFFu;  // 060DAE72 extu.w r1,r2
L_060DAE74:
    c.r[1] = 0xFu;  // 060DAE74 mov #15,r1
L_060DAE76:
    c.r[1] <<= 8;  // 060DAE76 shll8 r1
L_060DAE78:
    c.r[2] &= c.r[1];  // 060DAE78 and r1,r2
L_060DAE7A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 060DAE7A tst r2,r2
L_060DAE7C:
    c.r[14] = c.r[15];  // 060DAE7C mov r15,r14
L_060DAE7E:
    if (c.t) { goto L_060DAE86; }  // 060DAE7E bt 0x060DAE86
L_060DAE80:
    c.r[0] = ld32(0x060DAEB4u);  // 060DAE80 mov.l 0x060DAEB4,r0
L_060DAE82:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE82 jmp @r0 ; nop
L_060DAE86:
    c.r[0] = ld32(0x060DAEB8u);  // 060DAE86 mov.l 0x060DAEB8,r0
L_060DAE88:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DAE70u: goto L_060DAE70; case 0x060DAE72u: goto L_060DAE72; case 0x060DAE74u: goto L_060DAE74; case 0x060DAE76u: goto L_060DAE76; case 0x060DAE78u: goto L_060DAE78; case 0x060DAE7Au: goto L_060DAE7A; case 0x060DAE7Cu: goto L_060DAE7C; case 0x060DAE7Eu: goto L_060DAE7E; case 0x060DAE80u: goto L_060DAE80; case 0x060DAE82u: goto L_060DAE82; case 0x060DAE86u: goto L_060DAE86; case 0x060DAE88u: goto L_060DAE88; default: sh2_call(c, x); return; } }  // 060DAE88 jmp @r0 ; nop
}

void f_060DAF00(SH2Context& c) {
    ran[24] = 1;
    goto L_060DAF00;
L_060DA82A:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DA82A mov.l r1,@-r15
L_060DA82C:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DA82C mov.l r2,@-r15
L_060DA82E:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DA82E mov.l r3,@-r15
L_060DA830:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA830 mov.l r4,@-r15
L_060DA832:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA832 mov.l r5,@-r15
L_060DA834:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA834 mov.l r6,@-r15
L_060DA836:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA836 mov.l r7,@-r15
L_060DA838:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA838 sts.l pr,@-r15
L_060DA83A:
    c.pr = 0x060DA83Eu; SH2_POLL(c); sh2_call(c, 0x060DA88Au); if (c.pc != 0x060DA83Eu) return;  // 060DA83A bsr 0x060DA88A ; nop
L_060DA83E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA83E lds.l @r15+,pr
L_060DA840:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA840 mov.l @r15+,r7
L_060DA842:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA842 mov.l @r15+,r6
L_060DA844:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA844 mov.l @r15+,r5
L_060DA846:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA846 mov.l @r15+,r4
L_060DA848:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DA848 mov.l @r15+,r3
L_060DA84A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DA84A mov.l @r15+,r2
L_060DA84C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DA84C mov.l @r15+,r1
L_060DA84E:
    c.r[0] = ld32(0x060DA9B0u);  // 060DA84E mov.l 0x060DA9B0,r0
L_060DA850:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; case 0x060DAF00u: goto L_060DAF00; case 0x060DAF02u: goto L_060DAF02; case 0x060DAF04u: goto L_060DAF04; case 0x060DAF06u: goto L_060DAF06; case 0x060DAF08u: goto L_060DAF08; case 0x060DAF0Au: goto L_060DAF0A; case 0x060DAF0Cu: goto L_060DAF0C; case 0x060DAF0Eu: goto L_060DAF0E; case 0x060DAF10u: goto L_060DAF10; case 0x060DAF12u: goto L_060DAF12; case 0x060DAF14u: goto L_060DAF14; case 0x060DAF16u: goto L_060DAF16; case 0x060DAF18u: goto L_060DAF18; case 0x060DAF1Au: goto L_060DAF1A; case 0x060DAF1Cu: goto L_060DAF1C; case 0x060DAF1Eu: goto L_060DAF1E; case 0x060DAF20u: goto L_060DAF20; case 0x060DAF22u: goto L_060DAF22; case 0x060DAF24u: goto L_060DAF24; case 0x060DAF26u: goto L_060DAF26; case 0x060DAF28u: goto L_060DAF28; case 0x060DAF2Au: goto L_060DAF2A; case 0x060DAF2Cu: goto L_060DAF2C; case 0x060DAF2Eu: goto L_060DAF2E; case 0x060DAF30u: goto L_060DAF30; case 0x060DAF32u: goto L_060DAF32; case 0x060DAF34u: goto L_060DAF34; case 0x060DAF36u: goto L_060DAF36; case 0x060DAF38u: goto L_060DAF38; case 0x060DAF3Au: goto L_060DAF3A; case 0x060DAF3Cu: goto L_060DAF3C; case 0x060DAF3Eu: goto L_060DAF3E; case 0x060DAF40u: goto L_060DAF40; case 0x060DAF44u: goto L_060DAF44; case 0x060DAF46u: goto L_060DAF46; case 0x060DAF48u: goto L_060DAF48; case 0x060DAF4Au: goto L_060DAF4A; case 0x060DAF4Cu: goto L_060DAF4C; case 0x060DAF4Eu: goto L_060DAF4E; case 0x060DAF50u: goto L_060DAF50; case 0x060DAF52u: goto L_060DAF52; case 0x060DAF54u: goto L_060DAF54; case 0x060DAF56u: goto L_060DAF56; case 0x060DAF58u: goto L_060DAF58; case 0x060DAF5Cu: goto L_060DAF5C; case 0x060DAF5Eu: goto L_060DAF5E; case 0x060DAF62u: goto L_060DAF62; case 0x060DAF64u: goto L_060DAF64; case 0x060DAF66u: goto L_060DAF66; case 0x060DAF68u: goto L_060DAF68; case 0x060DAF6Au: goto L_060DAF6A; case 0x060DAF6Cu: goto L_060DAF6C; case 0x060DAF6Eu: goto L_060DAF6E; case 0x060DAF70u: goto L_060DAF70; case 0x060DAF72u: goto L_060DAF72; default: sh2_call(c, x); return; } }  // 060DA850 jmp @r0 ; nop
L_060DAF00:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DAF00 mov.l r0,@-r15
L_060DAF02:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DAF02 mov.l r1,@-r15
L_060DAF04:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DAF04 mov.l r2,@-r15
L_060DAF06:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DAF06 mov.l r3,@-r15
L_060DAF08:
    c.r[3] = ld32(0x060DAF78u);  // 060DAF08 mov.l 0x060DAF78,r3
L_060DAF0A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060DAF0A mov.w @r3,r0
L_060DAF0C:
    c.r[0] = ~c.r[0];  // 060DAF0C not r0,r0
L_060DAF0E:
    c.r[3] = ld32(0x060DAF7Cu);  // 060DAF0E mov.l 0x060DAF7C,r3
L_060DAF10:
    c.r[0] &= c.r[3];  // 060DAF10 and r3,r0
L_060DAF12:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAF12 tst r0,r0
L_060DAF14:
    if (c.t) { goto L_060DAF62; }  // 060DAF14 bt 0x060DAF62
L_060DAF16:
    c.r[3] = ld32(0x060DAF80u);  // 060DAF16 mov.l 0x060DAF80,r3
L_060DAF18:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060DAF18 mov.b @r3,r0
L_060DAF1A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAF1A tst r0,r0
L_060DAF1C:
    if (!c.t) { goto L_060DAF68; }  // 060DAF1C bf 0x060DAF68
L_060DAF1E:
    c.r[0] = 0x1u;  // 060DAF1E mov #1,r0
L_060DAF20:
    st8(c.r[3], c.r[0]);  // 060DAF20 mov.b r0,@r3
L_060DAF22:
    c.r[3] = ld32(0x060DAF84u);  // 060DAF22 mov.l 0x060DAF84,r3
L_060DAF24:
    c.r[0] = ld32(c.r[3]);  // 060DAF24 mov.l @r3,r0
L_060DAF26:
    c.r[3] = ld32(0x060DAF88u);  // 060DAF26 mov.l 0x060DAF88,r3
L_060DAF28:
    c.t = c.r[0] == c.r[3];  // 060DAF28 cmp/eq r3,r0
L_060DAF2A:
    if (c.t) { goto L_060DAF32; }  // 060DAF2A bt 0x060DAF32
L_060DAF2C:
    c.r[3] = ld32(0x060DAF8Cu);  // 060DAF2C mov.l 0x060DAF8C,r3
L_060DAF2E:
    c.t = c.r[0] == c.r[3];  // 060DAF2E cmp/eq r3,r0
L_060DAF30:
    if (!c.t) { goto L_060DAF68; }  // 060DAF30 bf 0x060DAF68
L_060DAF32:
    c.r[1] = ld32(0x060DAF90u);  // 060DAF32 mov.l 0x060DAF90,r1
L_060DAF34:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DAF34 mov.b @r1,r0
L_060DAF36:
    c.r[0] ^= 0x1u;  // 060DAF36 xor #1,r0
L_060DAF38:
    st8(c.r[1], c.r[0]);  // 060DAF38 mov.b r0,@r1
L_060DAF3A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DAF3A tst r0,r0
L_060DAF3C:
    if (c.t) { goto L_060DAF44; }  // 060DAF3C bt 0x060DAF44
L_060DAF3E:
    c.r[2] = ld32(0x060DAF94u);  // 060DAF3E mov.l 0x060DAF94,r2
L_060DAF40:
    goto L_060DAF46;  // 060DAF40 bra 0x060DAF46 ; nop
L_060DAF44:
    c.r[2] = ld32(0x060DAF98u);  // 060DAF44 mov.l 0x060DAF98,r2
L_060DAF46:
    c.r[1] = ld32(0x060DAF9Cu);  // 060DAF46 mov.l 0x060DAF9C,r1
L_060DAF48:
    c.r[3] = 0x4u;  // 060DAF48 mov #4,r3
L_060DAF4A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 060DAF4A mov.w @r2+,r0
L_060DAF4C:
    st16(c.r[1], c.r[0]);  // 060DAF4C mov.w r0,@r1
L_060DAF4E:
    c.r[1] += 2;  // 060DAF4E add #2,r1
L_060DAF50:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060DAF50 dt r3
L_060DAF52:
    if (!c.t) { SH2_POLL(c); goto L_060DAF4A; }  // 060DAF52 bf 0x060DAF4A
L_060DAF54:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DAF54 sts.l pr,@-r15
L_060DAF56:
    c.r[0] = ld32(0x060DAFACu);  // 060DAF56 mov.l 0x060DAFAC,r0
L_060DAF58:
    { const uint32_t x = c.r[0]; c.pr = 0x060DAF5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DAF5Cu) return; }  // 060DAF58 jsr @r0 ; nop
L_060DAF5C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DAF5C lds.l @r15+,pr
L_060DAF5E:
    goto L_060DAF68;  // 060DAF5E bra 0x060DAF68 ; nop
L_060DAF62:
    c.r[3] = ld32(0x060DAF80u);  // 060DAF62 mov.l 0x060DAF80,r3
L_060DAF64:
    c.r[0] = 0x0u;  // 060DAF64 mov #0,r0
L_060DAF66:
    st8(c.r[3], c.r[0]);  // 060DAF66 mov.b r0,@r3
L_060DAF68:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF68 mov.l @r15+,r3
L_060DAF6A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF6A mov.l @r15+,r2
L_060DAF6C:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF6C mov.l @r15+,r1
L_060DAF6E:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DAF6E mov.l @r15+,r0
L_060DAF70:
    c.r[0] = ld32(0x060DAFA8u);  // 060DAF70 mov.l 0x060DAFA8,r0
L_060DAF72:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA82Au: goto L_060DA82A; case 0x060DA82Cu: goto L_060DA82C; case 0x060DA82Eu: goto L_060DA82E; case 0x060DA830u: goto L_060DA830; case 0x060DA832u: goto L_060DA832; case 0x060DA834u: goto L_060DA834; case 0x060DA836u: goto L_060DA836; case 0x060DA838u: goto L_060DA838; case 0x060DA83Au: goto L_060DA83A; case 0x060DA83Eu: goto L_060DA83E; case 0x060DA840u: goto L_060DA840; case 0x060DA842u: goto L_060DA842; case 0x060DA844u: goto L_060DA844; case 0x060DA846u: goto L_060DA846; case 0x060DA848u: goto L_060DA848; case 0x060DA84Au: goto L_060DA84A; case 0x060DA84Cu: goto L_060DA84C; case 0x060DA84Eu: goto L_060DA84E; case 0x060DA850u: goto L_060DA850; case 0x060DAF00u: goto L_060DAF00; case 0x060DAF02u: goto L_060DAF02; case 0x060DAF04u: goto L_060DAF04; case 0x060DAF06u: goto L_060DAF06; case 0x060DAF08u: goto L_060DAF08; case 0x060DAF0Au: goto L_060DAF0A; case 0x060DAF0Cu: goto L_060DAF0C; case 0x060DAF0Eu: goto L_060DAF0E; case 0x060DAF10u: goto L_060DAF10; case 0x060DAF12u: goto L_060DAF12; case 0x060DAF14u: goto L_060DAF14; case 0x060DAF16u: goto L_060DAF16; case 0x060DAF18u: goto L_060DAF18; case 0x060DAF1Au: goto L_060DAF1A; case 0x060DAF1Cu: goto L_060DAF1C; case 0x060DAF1Eu: goto L_060DAF1E; case 0x060DAF20u: goto L_060DAF20; case 0x060DAF22u: goto L_060DAF22; case 0x060DAF24u: goto L_060DAF24; case 0x060DAF26u: goto L_060DAF26; case 0x060DAF28u: goto L_060DAF28; case 0x060DAF2Au: goto L_060DAF2A; case 0x060DAF2Cu: goto L_060DAF2C; case 0x060DAF2Eu: goto L_060DAF2E; case 0x060DAF30u: goto L_060DAF30; case 0x060DAF32u: goto L_060DAF32; case 0x060DAF34u: goto L_060DAF34; case 0x060DAF36u: goto L_060DAF36; case 0x060DAF38u: goto L_060DAF38; case 0x060DAF3Au: goto L_060DAF3A; case 0x060DAF3Cu: goto L_060DAF3C; case 0x060DAF3Eu: goto L_060DAF3E; case 0x060DAF40u: goto L_060DAF40; case 0x060DAF44u: goto L_060DAF44; case 0x060DAF46u: goto L_060DAF46; case 0x060DAF48u: goto L_060DAF48; case 0x060DAF4Au: goto L_060DAF4A; case 0x060DAF4Cu: goto L_060DAF4C; case 0x060DAF4Eu: goto L_060DAF4E; case 0x060DAF50u: goto L_060DAF50; case 0x060DAF52u: goto L_060DAF52; case 0x060DAF54u: goto L_060DAF54; case 0x060DAF56u: goto L_060DAF56; case 0x060DAF58u: goto L_060DAF58; case 0x060DAF5Cu: goto L_060DAF5C; case 0x060DAF5Eu: goto L_060DAF5E; case 0x060DAF62u: goto L_060DAF62; case 0x060DAF64u: goto L_060DAF64; case 0x060DAF66u: goto L_060DAF66; case 0x060DAF68u: goto L_060DAF68; case 0x060DAF6Au: goto L_060DAF6A; case 0x060DAF6Cu: goto L_060DAF6C; case 0x060DAF6Eu: goto L_060DAF6E; case 0x060DAF70u: goto L_060DAF70; case 0x060DAF72u: goto L_060DAF72; default: sh2_call(c, x); return; } }  // 060DAF72 jmp @r0 ; nop
}

void f_060DB000(SH2Context& c) {
    ran[25] = 1;
    goto L_060DB000;
L_060DA854:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DA854 sts.l pr,@-r15
L_060DA856:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DA856 mov.l r1,@-r15
L_060DA858:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DA858 mov.l r2,@-r15
L_060DA85A:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DA85A mov.l r3,@-r15
L_060DA85C:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DA85C mov.l r4,@-r15
L_060DA85E:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DA85E mov.l r5,@-r15
L_060DA860:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DA860 mov.l r6,@-r15
L_060DA862:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DA862 mov.l r7,@-r15
L_060DA864:
    c.pr = 0x060DA868u; SH2_POLL(c); sh2_call(c, 0x060DA8BEu); if (c.pc != 0x060DA868u) return;  // 060DA864 bsr 0x060DA8BE ; nop
L_060DA868:
    c.r[0] = c.r[4];  // 060DA868 mov r4,r0
L_060DA86A:
    c.r[0] += 1;  // 060DA86A add #1,r0
L_060DA86C:
    c.r[1] = ld32(0x060DA9B4u);  // 060DA86C mov.l 0x060DA9B4,r1
L_060DA86E:
    st8(c.r[1], c.r[0]);  // 060DA86E mov.b r0,@r1
L_060DA870:
    c.pr = 0x060DA874u; SH2_POLL(c); sh2_call(c, 0x060DA92Au); if (c.pc != 0x060DA874u) return;  // 060DA870 bsr 0x060DA92A ; nop
L_060DA874:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DA874 mov.l @r15+,r7
L_060DA876:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DA876 mov.l @r15+,r6
L_060DA878:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DA878 mov.l @r15+,r5
L_060DA87A:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DA87A mov.l @r15+,r4
L_060DA87C:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DA87C mov.l @r15+,r3
L_060DA87E:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DA87E mov.l @r15+,r2
L_060DA880:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DA880 mov.l @r15+,r1
L_060DA882:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DA882 lds.l @r15+,pr
L_060DA884:
    c.r[0] = ld32(0x060DA9B8u);  // 060DA884 mov.l 0x060DA9B8,r0
L_060DA886:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA854u: goto L_060DA854; case 0x060DA856u: goto L_060DA856; case 0x060DA858u: goto L_060DA858; case 0x060DA85Au: goto L_060DA85A; case 0x060DA85Cu: goto L_060DA85C; case 0x060DA85Eu: goto L_060DA85E; case 0x060DA860u: goto L_060DA860; case 0x060DA862u: goto L_060DA862; case 0x060DA864u: goto L_060DA864; case 0x060DA868u: goto L_060DA868; case 0x060DA86Au: goto L_060DA86A; case 0x060DA86Cu: goto L_060DA86C; case 0x060DA86Eu: goto L_060DA86E; case 0x060DA870u: goto L_060DA870; case 0x060DA874u: goto L_060DA874; case 0x060DA876u: goto L_060DA876; case 0x060DA878u: goto L_060DA878; case 0x060DA87Au: goto L_060DA87A; case 0x060DA87Cu: goto L_060DA87C; case 0x060DA87Eu: goto L_060DA87E; case 0x060DA880u: goto L_060DA880; case 0x060DA882u: goto L_060DA882; case 0x060DA884u: goto L_060DA884; case 0x060DA886u: goto L_060DA886; case 0x060DB000u: goto L_060DB000; case 0x060DB002u: goto L_060DB002; case 0x060DB004u: goto L_060DB004; case 0x060DB006u: goto L_060DB006; case 0x060DB008u: goto L_060DB008; case 0x060DB00Au: goto L_060DB00A; case 0x060DB00Cu: goto L_060DB00C; case 0x060DB00Eu: goto L_060DB00E; case 0x060DB010u: goto L_060DB010; case 0x060DB014u: goto L_060DB014; case 0x060DB016u: goto L_060DB016; case 0x060DB018u: goto L_060DB018; case 0x060DB01Au: goto L_060DB01A; case 0x060DB01Cu: goto L_060DB01C; case 0x060DB01Eu: goto L_060DB01E; case 0x060DB020u: goto L_060DB020; case 0x060DB022u: goto L_060DB022; case 0x060DB024u: goto L_060DB024; case 0x060DB026u: goto L_060DB026; case 0x060DB028u: goto L_060DB028; case 0x060DB02Au: goto L_060DB02A; case 0x060DB02Cu: goto L_060DB02C; case 0x060DB02Eu: goto L_060DB02E; case 0x060DB030u: goto L_060DB030; case 0x060DB032u: goto L_060DB032; case 0x060DB034u: goto L_060DB034; case 0x060DB036u: goto L_060DB036; case 0x060DB038u: goto L_060DB038; case 0x060DB03Au: goto L_060DB03A; case 0x060DB03Cu: goto L_060DB03C; case 0x060DB03Eu: goto L_060DB03E; case 0x060DB040u: goto L_060DB040; case 0x060DB042u: goto L_060DB042; case 0x060DB044u: goto L_060DB044; default: sh2_call(c, x); return; } }  // 060DA886 jmp @r0 ; nop
L_060DB000:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB000 mov.l r0,@-r15
L_060DB002:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DB002 mov.l r1,@-r15
L_060DB004:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB004 mov.l r2,@-r15
L_060DB006:
    c.r[1] = ld32(0x060DB048u);  // 060DB006 mov.l 0x060DB048,r1
L_060DB008:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB008 mov.b @r1,r0
L_060DB00A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DB00A tst r0,r0
L_060DB00C:
    if (!c.t) { goto L_060DB014; }  // 060DB00C bf 0x060DB014
L_060DB00E:
    c.r[2] = ld32(0x060DB04Cu);  // 060DB00E mov.l 0x060DB04C,r2
L_060DB010:
    goto L_060DB016;  // 060DB010 bra 0x060DB016 ; nop
L_060DB014:
    c.r[2] = ld32(0x060DB050u);  // 060DB014 mov.l 0x060DB050,r2
L_060DB016:
    c.r[1] = ld32(0x060DB054u);  // 060DB016 mov.l 0x060DB054,r1
L_060DB018:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060DB018 mov.b @r2+,r0
L_060DB01A:
    st8(c.r[1], c.r[0]);  // 060DB01A mov.b r0,@r1
L_060DB01C:
    c.r[1] += 1;  // 060DB01C add #1,r1
L_060DB01E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060DB01E mov.b @r2+,r0
L_060DB020:
    st8(c.r[1], c.r[0]);  // 060DB020 mov.b r0,@r1
L_060DB022:
    c.r[1] += 1;  // 060DB022 add #1,r1
L_060DB024:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060DB024 mov.b @r2+,r0
L_060DB026:
    st8(c.r[1], c.r[0]);  // 060DB026 mov.b r0,@r1
L_060DB028:
    c.r[1] += 1;  // 060DB028 add #1,r1
L_060DB02A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060DB02A mov.b @r2+,r0
L_060DB02C:
    st8(c.r[1], c.r[0]);  // 060DB02C mov.b r0,@r1
L_060DB02E:
    c.r[1] += 1;  // 060DB02E add #1,r1
L_060DB030:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DB030 mov.l @r15+,r2
L_060DB032:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DB032 mov.l @r15+,r1
L_060DB034:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB034 mov.l @r15+,r0
L_060DB036:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060DB036 mov.l r8,@-r15
L_060DB038:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060DB038 mov.l r9,@-r15
L_060DB03A:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060DB03A mov.l r10,@-r15
L_060DB03C:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060DB03C mov.l r11,@-r15
L_060DB03E:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060DB03E mov.l r12,@-r15
L_060DB040:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060DB040 mov.l r13,@-r15
L_060DB042:
    c.r[0] = ld32(0x060DB058u);  // 060DB042 mov.l 0x060DB058,r0
L_060DB044:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DA854u: goto L_060DA854; case 0x060DA856u: goto L_060DA856; case 0x060DA858u: goto L_060DA858; case 0x060DA85Au: goto L_060DA85A; case 0x060DA85Cu: goto L_060DA85C; case 0x060DA85Eu: goto L_060DA85E; case 0x060DA860u: goto L_060DA860; case 0x060DA862u: goto L_060DA862; case 0x060DA864u: goto L_060DA864; case 0x060DA868u: goto L_060DA868; case 0x060DA86Au: goto L_060DA86A; case 0x060DA86Cu: goto L_060DA86C; case 0x060DA86Eu: goto L_060DA86E; case 0x060DA870u: goto L_060DA870; case 0x060DA874u: goto L_060DA874; case 0x060DA876u: goto L_060DA876; case 0x060DA878u: goto L_060DA878; case 0x060DA87Au: goto L_060DA87A; case 0x060DA87Cu: goto L_060DA87C; case 0x060DA87Eu: goto L_060DA87E; case 0x060DA880u: goto L_060DA880; case 0x060DA882u: goto L_060DA882; case 0x060DA884u: goto L_060DA884; case 0x060DA886u: goto L_060DA886; case 0x060DB000u: goto L_060DB000; case 0x060DB002u: goto L_060DB002; case 0x060DB004u: goto L_060DB004; case 0x060DB006u: goto L_060DB006; case 0x060DB008u: goto L_060DB008; case 0x060DB00Au: goto L_060DB00A; case 0x060DB00Cu: goto L_060DB00C; case 0x060DB00Eu: goto L_060DB00E; case 0x060DB010u: goto L_060DB010; case 0x060DB014u: goto L_060DB014; case 0x060DB016u: goto L_060DB016; case 0x060DB018u: goto L_060DB018; case 0x060DB01Au: goto L_060DB01A; case 0x060DB01Cu: goto L_060DB01C; case 0x060DB01Eu: goto L_060DB01E; case 0x060DB020u: goto L_060DB020; case 0x060DB022u: goto L_060DB022; case 0x060DB024u: goto L_060DB024; case 0x060DB026u: goto L_060DB026; case 0x060DB028u: goto L_060DB028; case 0x060DB02Au: goto L_060DB02A; case 0x060DB02Cu: goto L_060DB02C; case 0x060DB02Eu: goto L_060DB02E; case 0x060DB030u: goto L_060DB030; case 0x060DB032u: goto L_060DB032; case 0x060DB034u: goto L_060DB034; case 0x060DB036u: goto L_060DB036; case 0x060DB038u: goto L_060DB038; case 0x060DB03Au: goto L_060DB03A; case 0x060DB03Cu: goto L_060DB03C; case 0x060DB03Eu: goto L_060DB03E; case 0x060DB040u: goto L_060DB040; case 0x060DB042u: goto L_060DB042; case 0x060DB044u: goto L_060DB044; default: sh2_call(c, x); return; } }  // 060DB044 jmp @r0 ; nop
}

void f_060DB100(SH2Context& c) {
    ran[26] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB100 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DB102 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB104 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DB106 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DB108 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DB10A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DB10C mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DB10E mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060DB110 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060DB112 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060DB114 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060DB116 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060DB118 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060DB11A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060DB11C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DB11E sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 060DB120 sts.l mach,@-r15
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 060DB122 sts.l macl,@-r15
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 060DB124 stc.l sr,@-r15
    c.r[1] = ld32(0x060DB174u);  // 060DB126 mov.l 0x060DB174,r1
    c.r[2] = 0x10u;  // 060DB128 mov #16,r2
L_060DB12A:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 060DB12A mov.l @r1+,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB12C mov.l r0,@-r15
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060DB12E dt r2
    if (!c.t) { SH2_POLL(c); goto L_060DB12A; }  // 060DB130 bf 0x060DB12A
    c.r[0] = ld32(0x060DB170u);  // 060DB132 mov.l 0x060DB170,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DB138u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DB138u) return; }  // 060DB134 jsr @r0 ; nop
    c.r[1] = ld32(0x060DB178u);  // 060DB138 mov.l 0x060DB178,r1
    c.r[2] = 0x10u;  // 060DB13A mov #16,r2
L_060DB13C:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB13C mov.l @r15+,r0
    c.r[1] -= 4; st32(c.r[1], c.r[0]);  // 060DB13E mov.l r0,@-r1
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060DB140 dt r2
    if (!c.t) { SH2_POLL(c); goto L_060DB13C; }  // 060DB142 bf 0x060DB13C
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 060DB144 ldc.l @r15+,sr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 060DB146 lds.l @r15+,macl
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 060DB148 lds.l @r15+,mach
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DB14A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060DB14C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060DB14E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060DB150 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060DB152 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060DB154 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060DB156 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060DB158 mov.l @r15+,r8
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DB15A mov.l @r15+,r7
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DB15C mov.l @r15+,r6
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DB15E mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DB160 mov.l @r15+,r4
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DB162 mov.l @r15+,r3
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DB164 mov.l @r15+,r2
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DB166 mov.l @r15+,r1
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB168 mov.l @r15+,r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DB16A rts ; nop
}

void f_060DB200(SH2Context& c) {
    ran[27] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB200 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DB202 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB204 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DB206 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DB208 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DB20A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DB20C mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DB20E mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060DB210 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060DB212 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060DB214 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060DB216 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060DB218 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060DB21A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060DB21C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DB21E sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 060DB220 sts.l mach,@-r15
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 060DB222 sts.l macl,@-r15
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 060DB224 stc.l sr,@-r15
    c.r[1] = ld32(0x060DB274u);  // 060DB226 mov.l 0x060DB274,r1
    c.r[2] = 0x10u;  // 060DB228 mov #16,r2
L_060DB22A:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 060DB22A mov.l @r1+,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB22C mov.l r0,@-r15
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060DB22E dt r2
    if (!c.t) { SH2_POLL(c); goto L_060DB22A; }  // 060DB230 bf 0x060DB22A
    c.r[0] = ld32(0x060DB270u);  // 060DB232 mov.l 0x060DB270,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DB238u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DB238u) return; }  // 060DB234 jsr @r0 ; nop
    c.r[1] = ld32(0x060DB278u);  // 060DB238 mov.l 0x060DB278,r1
    c.r[2] = 0x10u;  // 060DB23A mov #16,r2
L_060DB23C:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB23C mov.l @r15+,r0
    c.r[1] -= 4; st32(c.r[1], c.r[0]);  // 060DB23E mov.l r0,@-r1
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060DB240 dt r2
    if (!c.t) { SH2_POLL(c); goto L_060DB23C; }  // 060DB242 bf 0x060DB23C
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 060DB244 ldc.l @r15+,sr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 060DB246 lds.l @r15+,macl
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 060DB248 lds.l @r15+,mach
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DB24A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060DB24C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060DB24E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060DB250 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060DB252 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060DB254 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060DB256 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060DB258 mov.l @r15+,r8
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DB25A mov.l @r15+,r7
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DB25C mov.l @r15+,r6
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DB25E mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DB260 mov.l @r15+,r4
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DB262 mov.l @r15+,r3
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DB264 mov.l @r15+,r2
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DB266 mov.l @r15+,r1
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB268 mov.l @r15+,r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060DB26A rts ; nop
}

void f_060DB300(SH2Context& c) {
    ran[28] = 1;
L_060DB300:
    c.r[9] += c.r[1];  // 060DB300 add r1,r9
L_060DB302:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB302 mov.l r0,@-r15
L_060DB304:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB304 mov.l r2,@-r15
L_060DB306:
    c.r[0] = ld32(c.r[8]);  // 060DB306 mov.l @r8,r0
L_060DB308:
    c.r[2] = ld32(0x060DB328u);  // 060DB308 mov.l 0x060DB328,r2
L_060DB30A:
    c.t = c.r[0] >= c.r[2];  // 060DB30A cmp/hs r2,r0
L_060DB30C:
    if (!c.t) { goto L_060DB31A; }  // 060DB30C bf 0x060DB31A
L_060DB30E:
    c.r[2] = ld32(0x060DB32Cu);  // 060DB30E mov.l 0x060DB32C,r2
L_060DB310:
    c.t = c.r[2] >= c.r[0];  // 060DB310 cmp/hs r0,r2
L_060DB312:
    if (!c.t) { goto L_060DB31A; }  // 060DB312 bf 0x060DB31A
L_060DB314:
    c.r[0] = ld32(c.r[14] + 4);  // 060DB314 mov.l @(4,r14),r0
L_060DB316:
    c.r[0] <<= 2;  // 060DB316 shll2 r0
L_060DB318:
    c.r[9] -= c.r[0];  // 060DB318 sub r0,r9
L_060DB31A:
    c.r[1] = c.r[8];  // 060DB31A mov r8,r1
L_060DB31C:
    c.r[1] += 63;  // 060DB31C add #63,r1
L_060DB31E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB31E mov.b @r1,r0
L_060DB320:
    c.r[3] = ld32(0x060DB330u);  // 060DB320 mov.l 0x060DB330,r3
L_060DB322:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x060DB300u: goto L_060DB300; case 0x060DB302u: goto L_060DB302; case 0x060DB304u: goto L_060DB304; case 0x060DB306u: goto L_060DB306; case 0x060DB308u: goto L_060DB308; case 0x060DB30Au: goto L_060DB30A; case 0x060DB30Cu: goto L_060DB30C; case 0x060DB30Eu: goto L_060DB30E; case 0x060DB310u: goto L_060DB310; case 0x060DB312u: goto L_060DB312; case 0x060DB314u: goto L_060DB314; case 0x060DB316u: goto L_060DB316; case 0x060DB318u: goto L_060DB318; case 0x060DB31Au: goto L_060DB31A; case 0x060DB31Cu: goto L_060DB31C; case 0x060DB31Eu: goto L_060DB31E; case 0x060DB320u: goto L_060DB320; case 0x060DB322u: goto L_060DB322; default: sh2_call(c, x); return; } }  // 060DB322 jmp @r3 ; nop
}

void f_060DB400(SH2Context& c) {
    ran[29] = 1;
L_060DB400:
    c.r[1] = ld32(0x060DB428u);  // 060DB400 mov.l 0x060DB428,r1
L_060DB402:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB402 mov.b @r1,r0
L_060DB404:
    c.t = c.r[0] == 0x3u;  // 060DB404 cmp/eq #3,r0
L_060DB406:
    if (!c.t) { goto L_060DB416; }  // 060DB406 bf 0x060DB416
L_060DB408:
    c.r[0] = 0x0u;  // 060DB408 mov #0,r0
L_060DB40A:
    st8(c.r[1], c.r[0]);  // 060DB40A mov.b r0,@r1
L_060DB40C:
    c.r[2] = ld32(0x060DB42Cu);  // 060DB40C mov.l 0x060DB42C,r2
L_060DB40E:
    c.r[7] = 0x0u;  // 060DB40E mov #0,r7
L_060DB410:
    c.r[0] = ld32(0x060DB430u);  // 060DB410 mov.l 0x060DB430,r0
L_060DB412:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DB400u: goto L_060DB400; case 0x060DB402u: goto L_060DB402; case 0x060DB404u: goto L_060DB404; case 0x060DB406u: goto L_060DB406; case 0x060DB408u: goto L_060DB408; case 0x060DB40Au: goto L_060DB40A; case 0x060DB40Cu: goto L_060DB40C; case 0x060DB40Eu: goto L_060DB40E; case 0x060DB410u: goto L_060DB410; case 0x060DB412u: goto L_060DB412; case 0x060DB416u: goto L_060DB416; case 0x060DB418u: goto L_060DB418; case 0x060DB41Au: goto L_060DB41A; case 0x060DB41Cu: goto L_060DB41C; case 0x060DB41Eu: goto L_060DB41E; case 0x060DB420u: goto L_060DB420; case 0x060DB422u: goto L_060DB422; case 0x060DB424u: goto L_060DB424; default: sh2_call(c, x); return; } }  // 060DB412 jmp @r0 ; nop
L_060DB416:
    c.r[1] = ld32(0x060DB434u);  // 060DB416 mov.l 0x060DB434,r1
L_060DB418:
    c.r[1] = ld32(c.r[1]);  // 060DB418 mov.l @r1,r1
L_060DB41A:
    c.r[1] += 4;  // 060DB41A add #4,r1
L_060DB41C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DB41C mov.w @r1,r1
L_060DB41E:
    c.r[0] = ~c.r[1];  // 060DB41E not r1,r0
L_060DB420:
    c.r[0] >>= 8;  // 060DB420 shlr8 r0
L_060DB422:
    c.r[1] = ld32(0x060DB438u);  // 060DB422 mov.l 0x060DB438,r1
L_060DB424:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x060DB400u: goto L_060DB400; case 0x060DB402u: goto L_060DB402; case 0x060DB404u: goto L_060DB404; case 0x060DB406u: goto L_060DB406; case 0x060DB408u: goto L_060DB408; case 0x060DB40Au: goto L_060DB40A; case 0x060DB40Cu: goto L_060DB40C; case 0x060DB40Eu: goto L_060DB40E; case 0x060DB410u: goto L_060DB410; case 0x060DB412u: goto L_060DB412; case 0x060DB416u: goto L_060DB416; case 0x060DB418u: goto L_060DB418; case 0x060DB41Au: goto L_060DB41A; case 0x060DB41Cu: goto L_060DB41C; case 0x060DB41Eu: goto L_060DB41E; case 0x060DB420u: goto L_060DB420; case 0x060DB422u: goto L_060DB422; case 0x060DB424u: goto L_060DB424; default: sh2_call(c, x); return; } }  // 060DB424 jmp @r1 ; nop
}

void f_060DB600(SH2Context& c) {
    ran[30] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB600 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DB602 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB604 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DB606 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DB608 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DB60A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DB60C mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DB60E mov.l r7,@-r15
    c.r[1] = ld32(0x060DB700u);  // 060DB610 mov.l 0x060DB700,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DB612 mov.w @r1,r0
    c.r[0] = ~c.r[0];  // 060DB614 not r0,r0
    c.r[3] = ld32(0x060DB704u);  // 060DB616 mov.l 0x060DB704,r3
    c.r[0] &= c.r[3];  // 060DB618 and r3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DB61A tst r0,r0
    if (!c.t) { goto L_060DB626; }  // 060DB61C bf 0x060DB626
    c.r[1] = ld32(0x060DB708u);  // 060DB61E mov.l 0x060DB708,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB620 mov.b @r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DB622 tst r0,r0
    if (c.t) { goto L_060DB6E8; }  // 060DB624 bt 0x060DB6E8
L_060DB626:
    c.r[1] = ld32(0x060DB70Cu);  // 060DB626 mov.l 0x060DB70C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB628 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060DB62A extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060DB62C tst r2,r2
    if (c.t) { goto L_060DB6E2; }  // 060DB62E bt 0x060DB6E2
    c.r[3] = 0x10u;  // 060DB630 mov #16,r3
    c.t = c.r[2] > c.r[3];  // 060DB632 cmp/hi r3,r2
    if (c.t) { goto L_060DB6E2; }  // 060DB634 bt 0x060DB6E2
    c.r[1] = ld32(0x060DB710u);  // 060DB636 mov.l 0x060DB710,r1
    c.r[3] = ld32(0x060DB714u);  // 060DB638 mov.l 0x060DB714,r3
    c.r[4] = 0x0u;  // 060DB63A mov #0,r4
    c.r[5] = 0x0u;  // 060DB63C mov #0,r5
L_060DB63E:
    c.r[0] = ld32(c.r[1]);  // 060DB63E mov.l @r1,r0
    c.t = c.r[0] == c.r[3];  // 060DB640 cmp/eq r3,r0
    if (!c.t) { goto L_060DB64E; }  // 060DB642 bf 0x060DB64E
    c.t = (c.r[5] & c.r[5]) == 0;  // 060DB644 tst r5,r5
    if (!c.t) { goto L_060DB6E2; }  // 060DB646 bf 0x060DB6E2
    c.r[5] = c.r[1];  // 060DB648 mov r1,r5
    c.r[6] = c.r[4];  // 060DB64A mov r4,r6
    c.r[6] += 1;  // 060DB64C add #1,r6
L_060DB64E:
    c.r[1] += 4;  // 060DB64E add #4,r1
    c.r[4] += 1;  // 060DB650 add #1,r4
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060DB652 dt r2
    if (!c.t) { SH2_POLL(c); goto L_060DB63E; }  // 060DB654 bf 0x060DB63E
    c.t = (c.r[5] & c.r[5]) == 0;  // 060DB656 tst r5,r5
    if (c.t) { goto L_060DB6E2; }  // 060DB658 bt 0x060DB6E2
    c.r[1] = ld32(0x060DB70Cu);  // 060DB65A mov.l 0x060DB70C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB65C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060DB65E extu.b r2,r2
    c.r[1] = ld32(0x060DB710u);  // 060DB660 mov.l 0x060DB710,r1
    c.r[3] = ld32(0x060DB718u);  // 060DB662 mov.l 0x060DB718,r3
    c.r[4] = 0x0u;  // 060DB664 mov #0,r4
L_060DB666:
    c.r[0] = ld32(c.r[1]);  // 060DB666 mov.l @r1,r0
    c.t = c.r[0] == c.r[3];  // 060DB668 cmp/eq r3,r0
    if (!c.t) { goto L_060DB66E; }  // 060DB66A bf 0x060DB66E
    c.r[4] += 1;  // 060DB66C add #1,r4
L_060DB66E:
    c.r[1] += 4;  // 060DB66E add #4,r1
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060DB670 dt r2
    if (!c.t) { SH2_POLL(c); goto L_060DB666; }  // 060DB672 bf 0x060DB666
    c.t = (c.r[4] & c.r[4]) == 0;  // 060DB674 tst r4,r4
    if (!c.t) { goto L_060DB682; }  // 060DB676 bf 0x060DB682
    c.r[1] = ld32(0x060DB708u);  // 060DB678 mov.l 0x060DB708,r1
    c.r[0] = 0x1u;  // 060DB67A mov #1,r0
    st8(c.r[1], c.r[0]);  // 060DB67C mov.b r0,@r1
    goto L_060DB6E8;  // 060DB67E bra 0x060DB6E8 ; nop
L_060DB682:
    c.r[0] = 0x1u;  // 060DB682 mov #1,r0
    c.t = c.r[4] == c.r[0];  // 060DB684 cmp/eq r0,r4
    if (!c.t) { goto L_060DB6E2; }  // 060DB686 bf 0x060DB6E2
    c.r[1] = ld32(0x060DB71Cu);  // 060DB688 mov.l 0x060DB71C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060DB68A mov.w @r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060DB68C tst r0,r0
    if (c.t) { goto L_060DB6AE; }  // 060DB68E bt 0x060DB6AE
    c.r[2] = ld32(0x060DB708u);  // 060DB690 mov.l 0x060DB708,r2
    c.r[3] = 0x1u;  // 060DB692 mov #1,r3
    st8(c.r[2], c.r[3]);  // 060DB694 mov.b r3,@r2
    c.t = c.r[0] == 0x20u;  // 060DB696 cmp/eq #32,r0
    if (!c.t) { goto L_060DB6E8; }  // 060DB698 bf 0x060DB6E8
    st16(c.r[1], c.r[3]);  // 060DB69A mov.w r3,@r1
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060DB69C sts.l pr,@-r15
    c.r[4] = ld32(0x060DB720u);  // 060DB69E mov.l 0x060DB720,r4
    c.r[4] = ld32(c.r[4]);  // 060DB6A0 mov.l @r4,r4
    c.r[0] = ld32(0x060DB724u);  // 060DB6A2 mov.l 0x060DB724,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060DB6A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060DB6A8u) return; }  // 060DB6A4 jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060DB6A8 lds.l @r15+,pr
    goto L_060DB6E8;  // 060DB6AA bra 0x060DB6E8 ; nop
L_060DB6AE:
    c.r[1] = ld32(0x060DB708u);  // 060DB6AE mov.l 0x060DB708,r1
    c.r[0] = 0x0u;  // 060DB6B0 mov #0,r0
    st8(c.r[1], c.r[0]);  // 060DB6B2 mov.b r0,@r1
    c.r[0] = ld32(0x060DB728u);  // 060DB6B4 mov.l 0x060DB728,r0
    st32(c.r[5], c.r[0]);  // 060DB6B6 mov.l r0,@r5
    c.r[1] = ld32(0x060DB72Cu);  // 060DB6B8 mov.l 0x060DB72C,r1
    c.r[0] = ld32(0x060DB730u);  // 060DB6BA mov.l 0x060DB730,r0
    st32(c.r[1], c.r[0]);  // 060DB6BC mov.l r0,@r1
    c.r[1] = ld32(0x060DB70Cu);  // 060DB6BE mov.l 0x060DB70C,r1
    st8(c.r[1], c.r[6]);  // 060DB6C0 mov.b r6,@r1
    c.r[1] += 1;  // 060DB6C2 add #1,r1
    c.r[0] = 0x0u;  // 060DB6C4 mov #0,r0
    st8(c.r[1], c.r[0]);  // 060DB6C6 mov.b r0,@r1
    c.r[1] += 1;  // 060DB6C8 add #1,r1
    c.r[0] = 0x13u;  // 060DB6CA mov #19,r0
    st8(c.r[1], c.r[0]);  // 060DB6CC mov.b r0,@r1
    c.r[1] += 1;  // 060DB6CE add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060DB6D0 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 060DB6D2 or #128,r0
    c.r[0] &= 0xBFu;  // 060DB6D4 and #191,r0
    st8(c.r[1], c.r[0]);  // 060DB6D6 mov.b r0,@r1
    c.r[1] += 1;  // 060DB6D8 add #1,r1
    c.r[0] = 0x0u;  // 060DB6DA mov #0,r0
    st32(c.r[1], c.r[0]);  // 060DB6DC mov.l r0,@r1
    goto L_060DB6E8;  // 060DB6DE bra 0x060DB6E8 ; nop
L_060DB6E2:
    c.r[1] = ld32(0x060DB708u);  // 060DB6E2 mov.l 0x060DB708,r1
    c.r[0] = 0x0u;  // 060DB6E4 mov #0,r0
    st8(c.r[1], c.r[0]);  // 060DB6E6 mov.b r0,@r1
L_060DB6E8:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6E8 mov.l @r15+,r7
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6EA mov.l @r15+,r6
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6EC mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6EE mov.l @r15+,r4
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6F0 mov.l @r15+,r3
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6F2 mov.l @r15+,r2
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6F4 mov.l @r15+,r1
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB6F6 mov.l @r15+,r0
    c.r[0] = ld32(0x060DB734u);  // 060DB6F8 mov.l 0x060DB734,r0
    c.r[0] = ld32(c.r[0]);  // 060DB6FA mov.l @r0,r0
    { const uint32_t x = c.r[0]; sh2_call(c, x); return; }  // 060DB6FC jmp @r0 ; nop
}

void f_060DB800(SH2Context& c) {
    ran[31] = 1;
L_060DB800:
    c.r[1] = ld32(0x060DB818u);  // 060DB800 mov.l 0x060DB818,r1
L_060DB802:
    c.r[1] = ld32(c.r[1]);  // 060DB802 mov.l @r1,r1
L_060DB804:
    c.r[2] = ld32(0x060DB81Cu);  // 060DB804 mov.l 0x060DB81C,r2
L_060DB806:
    c.t = c.r[1] == c.r[2];  // 060DB806 cmp/eq r2,r1
L_060DB808:
    if (!c.t) { goto L_060DB810; }  // 060DB808 bf 0x060DB810
L_060DB80A:
    c.r[0] = ld32(0x060DB820u);  // 060DB80A mov.l 0x060DB820,r0
L_060DB80C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DB800u: goto L_060DB800; case 0x060DB802u: goto L_060DB802; case 0x060DB804u: goto L_060DB804; case 0x060DB806u: goto L_060DB806; case 0x060DB808u: goto L_060DB808; case 0x060DB80Au: goto L_060DB80A; case 0x060DB80Cu: goto L_060DB80C; case 0x060DB810u: goto L_060DB810; case 0x060DB812u: goto L_060DB812; case 0x060DB900u: goto L_060DB900; case 0x060DB902u: goto L_060DB902; case 0x060DB904u: goto L_060DB904; case 0x060DB906u: goto L_060DB906; case 0x060DB908u: goto L_060DB908; case 0x060DB90Au: goto L_060DB90A; case 0x060DB90Cu: goto L_060DB90C; case 0x060DB90Eu: goto L_060DB90E; case 0x060DB910u: goto L_060DB910; case 0x060DB912u: goto L_060DB912; case 0x060DB914u: goto L_060DB914; case 0x060DB916u: goto L_060DB916; case 0x060DB918u: goto L_060DB918; case 0x060DB91Au: goto L_060DB91A; case 0x060DB91Cu: goto L_060DB91C; case 0x060DB91Eu: goto L_060DB91E; case 0x060DB920u: goto L_060DB920; case 0x060DB922u: goto L_060DB922; case 0x060DB924u: goto L_060DB924; case 0x060DB926u: goto L_060DB926; case 0x060DB928u: goto L_060DB928; case 0x060DB92Au: goto L_060DB92A; case 0x060DB92Cu: goto L_060DB92C; case 0x060DB92Eu: goto L_060DB92E; case 0x060DB930u: goto L_060DB930; case 0x060DB932u: goto L_060DB932; case 0x060DB934u: goto L_060DB934; case 0x060DB936u: goto L_060DB936; case 0x060DB938u: goto L_060DB938; case 0x060DB93Au: goto L_060DB93A; case 0x060DB93Cu: goto L_060DB93C; case 0x060DB93Eu: goto L_060DB93E; case 0x060DB940u: goto L_060DB940; case 0x060DB942u: goto L_060DB942; case 0x060DB944u: goto L_060DB944; case 0x060DB946u: goto L_060DB946; case 0x060DB948u: goto L_060DB948; case 0x060DB94Au: goto L_060DB94A; case 0x060DB94Cu: goto L_060DB94C; case 0x060DB94Eu: goto L_060DB94E; case 0x060DB950u: goto L_060DB950; case 0x060DB952u: goto L_060DB952; case 0x060DB954u: goto L_060DB954; case 0x060DB956u: goto L_060DB956; case 0x060DB958u: goto L_060DB958; case 0x060DB95Au: goto L_060DB95A; case 0x060DB95Cu: goto L_060DB95C; default: sh2_call(c, x); return; } }  // 060DB80C jmp @r0 ; nop
L_060DB810:
    c.r[0] = ld32(0x060DB824u);  // 060DB810 mov.l 0x060DB824,r0
L_060DB812:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DB800u: goto L_060DB800; case 0x060DB802u: goto L_060DB802; case 0x060DB804u: goto L_060DB804; case 0x060DB806u: goto L_060DB806; case 0x060DB808u: goto L_060DB808; case 0x060DB80Au: goto L_060DB80A; case 0x060DB80Cu: goto L_060DB80C; case 0x060DB810u: goto L_060DB810; case 0x060DB812u: goto L_060DB812; case 0x060DB900u: goto L_060DB900; case 0x060DB902u: goto L_060DB902; case 0x060DB904u: goto L_060DB904; case 0x060DB906u: goto L_060DB906; case 0x060DB908u: goto L_060DB908; case 0x060DB90Au: goto L_060DB90A; case 0x060DB90Cu: goto L_060DB90C; case 0x060DB90Eu: goto L_060DB90E; case 0x060DB910u: goto L_060DB910; case 0x060DB912u: goto L_060DB912; case 0x060DB914u: goto L_060DB914; case 0x060DB916u: goto L_060DB916; case 0x060DB918u: goto L_060DB918; case 0x060DB91Au: goto L_060DB91A; case 0x060DB91Cu: goto L_060DB91C; case 0x060DB91Eu: goto L_060DB91E; case 0x060DB920u: goto L_060DB920; case 0x060DB922u: goto L_060DB922; case 0x060DB924u: goto L_060DB924; case 0x060DB926u: goto L_060DB926; case 0x060DB928u: goto L_060DB928; case 0x060DB92Au: goto L_060DB92A; case 0x060DB92Cu: goto L_060DB92C; case 0x060DB92Eu: goto L_060DB92E; case 0x060DB930u: goto L_060DB930; case 0x060DB932u: goto L_060DB932; case 0x060DB934u: goto L_060DB934; case 0x060DB936u: goto L_060DB936; case 0x060DB938u: goto L_060DB938; case 0x060DB93Au: goto L_060DB93A; case 0x060DB93Cu: goto L_060DB93C; case 0x060DB93Eu: goto L_060DB93E; case 0x060DB940u: goto L_060DB940; case 0x060DB942u: goto L_060DB942; case 0x060DB944u: goto L_060DB944; case 0x060DB946u: goto L_060DB946; case 0x060DB948u: goto L_060DB948; case 0x060DB94Au: goto L_060DB94A; case 0x060DB94Cu: goto L_060DB94C; case 0x060DB94Eu: goto L_060DB94E; case 0x060DB950u: goto L_060DB950; case 0x060DB952u: goto L_060DB952; case 0x060DB954u: goto L_060DB954; case 0x060DB956u: goto L_060DB956; case 0x060DB958u: goto L_060DB958; case 0x060DB95Au: goto L_060DB95A; case 0x060DB95Cu: goto L_060DB95C; default: sh2_call(c, x); return; } }  // 060DB812 jmp @r0 ; nop
L_060DB900:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB900 mov.l r0,@-r15
L_060DB902:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DB902 mov.l r1,@-r15
L_060DB904:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB904 mov.l r2,@-r15
L_060DB906:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DB906 mov.l r3,@-r15
L_060DB908:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DB908 mov.l r4,@-r15
L_060DB90A:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DB90A mov.l r5,@-r15
L_060DB90C:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DB90C mov.l r6,@-r15
L_060DB90E:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DB90E mov.l r7,@-r15
L_060DB910:
    c.r[1] = ld32(0x060DB960u);  // 060DB910 mov.l 0x060DB960,r1
L_060DB912:
    c.r[2] = ld32(0x060DB964u);  // 060DB912 mov.l 0x060DB964,r2
L_060DB914:
    c.r[3] = ld32(0x060DB968u);  // 060DB914 mov.l 0x060DB968,r3
L_060DB916:
    c.r[4] = ld32(0x060DB96Cu);  // 060DB916 mov.l 0x060DB96C,r4
L_060DB918:
    c.r[5] = 0x8u;  // 060DB918 mov #8,r5
L_060DB91A:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 060DB91A mov.l @r1+,r0
L_060DB91C:
    st32(c.r[2], c.r[0]);  // 060DB91C mov.l r0,@r2
L_060DB91E:
    c.r[2] += 4;  // 060DB91E add #4,r2
L_060DB920:
    st32(c.r[3], c.r[0]);  // 060DB920 mov.l r0,@r3
L_060DB922:
    c.r[3] += 4;  // 060DB922 add #4,r3
L_060DB924:
    st32(c.r[4], c.r[0]);  // 060DB924 mov.l r0,@r4
L_060DB926:
    c.r[4] += 4;  // 060DB926 add #4,r4
L_060DB928:
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 060DB928 dt r5
L_060DB92A:
    if (!c.t) { SH2_POLL(c); goto L_060DB91A; }  // 060DB92A bf 0x060DB91A
L_060DB92C:
    c.r[1] = ld32(0x060DB970u);  // 060DB92C mov.l 0x060DB970,r1
L_060DB92E:
    c.r[1] = ld32(c.r[1]);  // 060DB92E mov.l @r1,r1
L_060DB930:
    c.r[6] = 0x2u;  // 060DB930 mov #2,r6
L_060DB932:
    c.r[6] <<= 8;  // 060DB932 shll8 r6
L_060DB934:
    c.r[1] += c.r[6];  // 060DB934 add r6,r1
L_060DB936:
    c.r[5] = 0x30u;  // 060DB936 mov #48,r5
L_060DB938:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 060DB938 mov.l @r1+,r0
L_060DB93A:
    st32(c.r[2], c.r[0]);  // 060DB93A mov.l r0,@r2
L_060DB93C:
    c.r[2] += 4;  // 060DB93C add #4,r2
L_060DB93E:
    st32(c.r[3], c.r[0]);  // 060DB93E mov.l r0,@r3
L_060DB940:
    c.r[3] += 4;  // 060DB940 add #4,r3
L_060DB942:
    st32(c.r[4], c.r[0]);  // 060DB942 mov.l r0,@r4
L_060DB944:
    c.r[4] += 4;  // 060DB944 add #4,r4
L_060DB946:
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 060DB946 dt r5
L_060DB948:
    if (!c.t) { SH2_POLL(c); goto L_060DB938; }  // 060DB948 bf 0x060DB938
L_060DB94A:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DB94A mov.l @r15+,r7
L_060DB94C:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DB94C mov.l @r15+,r6
L_060DB94E:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DB94E mov.l @r15+,r5
L_060DB950:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DB950 mov.l @r15+,r4
L_060DB952:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DB952 mov.l @r15+,r3
L_060DB954:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DB954 mov.l @r15+,r2
L_060DB956:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DB956 mov.l @r15+,r1
L_060DB958:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB958 mov.l @r15+,r0
L_060DB95A:
    c.r[0] = ld32(0x060DB974u);  // 060DB95A mov.l 0x060DB974,r0
L_060DB95C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DB800u: goto L_060DB800; case 0x060DB802u: goto L_060DB802; case 0x060DB804u: goto L_060DB804; case 0x060DB806u: goto L_060DB806; case 0x060DB808u: goto L_060DB808; case 0x060DB80Au: goto L_060DB80A; case 0x060DB80Cu: goto L_060DB80C; case 0x060DB810u: goto L_060DB810; case 0x060DB812u: goto L_060DB812; case 0x060DB900u: goto L_060DB900; case 0x060DB902u: goto L_060DB902; case 0x060DB904u: goto L_060DB904; case 0x060DB906u: goto L_060DB906; case 0x060DB908u: goto L_060DB908; case 0x060DB90Au: goto L_060DB90A; case 0x060DB90Cu: goto L_060DB90C; case 0x060DB90Eu: goto L_060DB90E; case 0x060DB910u: goto L_060DB910; case 0x060DB912u: goto L_060DB912; case 0x060DB914u: goto L_060DB914; case 0x060DB916u: goto L_060DB916; case 0x060DB918u: goto L_060DB918; case 0x060DB91Au: goto L_060DB91A; case 0x060DB91Cu: goto L_060DB91C; case 0x060DB91Eu: goto L_060DB91E; case 0x060DB920u: goto L_060DB920; case 0x060DB922u: goto L_060DB922; case 0x060DB924u: goto L_060DB924; case 0x060DB926u: goto L_060DB926; case 0x060DB928u: goto L_060DB928; case 0x060DB92Au: goto L_060DB92A; case 0x060DB92Cu: goto L_060DB92C; case 0x060DB92Eu: goto L_060DB92E; case 0x060DB930u: goto L_060DB930; case 0x060DB932u: goto L_060DB932; case 0x060DB934u: goto L_060DB934; case 0x060DB936u: goto L_060DB936; case 0x060DB938u: goto L_060DB938; case 0x060DB93Au: goto L_060DB93A; case 0x060DB93Cu: goto L_060DB93C; case 0x060DB93Eu: goto L_060DB93E; case 0x060DB940u: goto L_060DB940; case 0x060DB942u: goto L_060DB942; case 0x060DB944u: goto L_060DB944; case 0x060DB946u: goto L_060DB946; case 0x060DB948u: goto L_060DB948; case 0x060DB94Au: goto L_060DB94A; case 0x060DB94Cu: goto L_060DB94C; case 0x060DB94Eu: goto L_060DB94E; case 0x060DB950u: goto L_060DB950; case 0x060DB952u: goto L_060DB952; case 0x060DB954u: goto L_060DB954; case 0x060DB956u: goto L_060DB956; case 0x060DB958u: goto L_060DB958; case 0x060DB95Au: goto L_060DB95A; case 0x060DB95Cu: goto L_060DB95C; default: sh2_call(c, x); return; } }  // 060DB95C jmp @r0 ; nop
}

void f_060DB900(SH2Context& c) {
    ran[32] = 1;
L_060DB900:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060DB900 mov.l r0,@-r15
L_060DB902:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060DB902 mov.l r1,@-r15
L_060DB904:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060DB904 mov.l r2,@-r15
L_060DB906:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060DB906 mov.l r3,@-r15
L_060DB908:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060DB908 mov.l r4,@-r15
L_060DB90A:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060DB90A mov.l r5,@-r15
L_060DB90C:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060DB90C mov.l r6,@-r15
L_060DB90E:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060DB90E mov.l r7,@-r15
L_060DB910:
    c.r[1] = ld32(0x060DB960u);  // 060DB910 mov.l 0x060DB960,r1
L_060DB912:
    c.r[2] = ld32(0x060DB964u);  // 060DB912 mov.l 0x060DB964,r2
L_060DB914:
    c.r[3] = ld32(0x060DB968u);  // 060DB914 mov.l 0x060DB968,r3
L_060DB916:
    c.r[4] = ld32(0x060DB96Cu);  // 060DB916 mov.l 0x060DB96C,r4
L_060DB918:
    c.r[5] = 0x8u;  // 060DB918 mov #8,r5
L_060DB91A:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 060DB91A mov.l @r1+,r0
L_060DB91C:
    st32(c.r[2], c.r[0]);  // 060DB91C mov.l r0,@r2
L_060DB91E:
    c.r[2] += 4;  // 060DB91E add #4,r2
L_060DB920:
    st32(c.r[3], c.r[0]);  // 060DB920 mov.l r0,@r3
L_060DB922:
    c.r[3] += 4;  // 060DB922 add #4,r3
L_060DB924:
    st32(c.r[4], c.r[0]);  // 060DB924 mov.l r0,@r4
L_060DB926:
    c.r[4] += 4;  // 060DB926 add #4,r4
L_060DB928:
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 060DB928 dt r5
L_060DB92A:
    if (!c.t) { SH2_POLL(c); goto L_060DB91A; }  // 060DB92A bf 0x060DB91A
L_060DB92C:
    c.r[1] = ld32(0x060DB970u);  // 060DB92C mov.l 0x060DB970,r1
L_060DB92E:
    c.r[1] = ld32(c.r[1]);  // 060DB92E mov.l @r1,r1
L_060DB930:
    c.r[6] = 0x2u;  // 060DB930 mov #2,r6
L_060DB932:
    c.r[6] <<= 8;  // 060DB932 shll8 r6
L_060DB934:
    c.r[1] += c.r[6];  // 060DB934 add r6,r1
L_060DB936:
    c.r[5] = 0x30u;  // 060DB936 mov #48,r5
L_060DB938:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 060DB938 mov.l @r1+,r0
L_060DB93A:
    st32(c.r[2], c.r[0]);  // 060DB93A mov.l r0,@r2
L_060DB93C:
    c.r[2] += 4;  // 060DB93C add #4,r2
L_060DB93E:
    st32(c.r[3], c.r[0]);  // 060DB93E mov.l r0,@r3
L_060DB940:
    c.r[3] += 4;  // 060DB940 add #4,r3
L_060DB942:
    st32(c.r[4], c.r[0]);  // 060DB942 mov.l r0,@r4
L_060DB944:
    c.r[4] += 4;  // 060DB944 add #4,r4
L_060DB946:
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 060DB946 dt r5
L_060DB948:
    if (!c.t) { SH2_POLL(c); goto L_060DB938; }  // 060DB948 bf 0x060DB938
L_060DB94A:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060DB94A mov.l @r15+,r7
L_060DB94C:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060DB94C mov.l @r15+,r6
L_060DB94E:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060DB94E mov.l @r15+,r5
L_060DB950:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060DB950 mov.l @r15+,r4
L_060DB952:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060DB952 mov.l @r15+,r3
L_060DB954:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060DB954 mov.l @r15+,r2
L_060DB956:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060DB956 mov.l @r15+,r1
L_060DB958:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060DB958 mov.l @r15+,r0
L_060DB95A:
    c.r[0] = ld32(0x060DB974u);  // 060DB95A mov.l 0x060DB974,r0
L_060DB95C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060DB900u: goto L_060DB900; case 0x060DB902u: goto L_060DB902; case 0x060DB904u: goto L_060DB904; case 0x060DB906u: goto L_060DB906; case 0x060DB908u: goto L_060DB908; case 0x060DB90Au: goto L_060DB90A; case 0x060DB90Cu: goto L_060DB90C; case 0x060DB90Eu: goto L_060DB90E; case 0x060DB910u: goto L_060DB910; case 0x060DB912u: goto L_060DB912; case 0x060DB914u: goto L_060DB914; case 0x060DB916u: goto L_060DB916; case 0x060DB918u: goto L_060DB918; case 0x060DB91Au: goto L_060DB91A; case 0x060DB91Cu: goto L_060DB91C; case 0x060DB91Eu: goto L_060DB91E; case 0x060DB920u: goto L_060DB920; case 0x060DB922u: goto L_060DB922; case 0x060DB924u: goto L_060DB924; case 0x060DB926u: goto L_060DB926; case 0x060DB928u: goto L_060DB928; case 0x060DB92Au: goto L_060DB92A; case 0x060DB92Cu: goto L_060DB92C; case 0x060DB92Eu: goto L_060DB92E; case 0x060DB930u: goto L_060DB930; case 0x060DB932u: goto L_060DB932; case 0x060DB934u: goto L_060DB934; case 0x060DB936u: goto L_060DB936; case 0x060DB938u: goto L_060DB938; case 0x060DB93Au: goto L_060DB93A; case 0x060DB93Cu: goto L_060DB93C; case 0x060DB93Eu: goto L_060DB93E; case 0x060DB940u: goto L_060DB940; case 0x060DB942u: goto L_060DB942; case 0x060DB944u: goto L_060DB944; case 0x060DB946u: goto L_060DB946; case 0x060DB948u: goto L_060DB948; case 0x060DB94Au: goto L_060DB94A; case 0x060DB94Cu: goto L_060DB94C; case 0x060DB94Eu: goto L_060DB94E; case 0x060DB950u: goto L_060DB950; case 0x060DB952u: goto L_060DB952; case 0x060DB954u: goto L_060DB954; case 0x060DB956u: goto L_060DB956; case 0x060DB958u: goto L_060DB958; case 0x060DB95Au: goto L_060DB95A; case 0x060DB95Cu: goto L_060DB95C; default: sh2_call(c, x); return; } }  // 060DB95C jmp @r0 ; nop
}

}  // namespace p_fin_resident
