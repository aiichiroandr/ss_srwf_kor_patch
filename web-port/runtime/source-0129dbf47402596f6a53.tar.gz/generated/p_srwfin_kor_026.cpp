#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_06069C98(SH2Context& c) {
    ran[1523] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06069C98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06069C9A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06069C9C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06069C9E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06069CA0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06069CA2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06069CA4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06069CA6 sts.l pr,@-r15
    c.r[15] -= 12;  // 06069CA8 add #-12,r15
    c.r[14] = c.r[15];  // 06069CAA mov r15,r14
    c.r[9] = c.r[6];  // 06069CAC mov r6,r9
    c.r[8] = c.r[7];  // 06069CAE mov r7,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069D9Eu);  // 06069CB0 mov.w 0x06069D9E,r1
    c.r[12] = 0x2Cu;  // 06069CB2 mov #44,r12
    c.r[12] += c.r[14];  // 06069CB4 add r14,r12
    c.r[0] = c.r[1];  // 06069CB6 mov r1,r0
    c.r[11] = ld32(c.r[0] + c.r[12]);  // 06069CB8 mov.l @(r0,r12),r11
    c.r[4] = c.r[4] & 0xFFu;  // 06069CBA extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069DA0u);  // 06069CBC mov.w 0x06069DA0,r1
    c.r[12] = 0x2Cu;  // 06069CBE mov #44,r12
    c.r[12] += c.r[14];  // 06069CC0 add r14,r12
    c.r[0] = c.r[1];  // 06069CC2 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[12]);  // 06069CC4 mov.l @(r0,r12),r2
    c.r[10] = c.r[5] & 0xFFu;  // 06069CC6 extu.b r5,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069DA2u);  // 06069CC8 mov.w 0x06069DA2,r1
    c.r[12] = 0x2Cu;  // 06069CCA mov #44,r12
    c.r[12] += c.r[14];  // 06069CCC add r14,r12
    c.r[0] = c.r[1];  // 06069CCE mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06069CD0 mov.l @(r0,r12),r1
    c.r[2] = c.r[2] & 0xFFu;  // 06069CD2 extu.b r2,r2
    st32(c.r[14], c.r[4]);  // 06069CD4 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06069CD6 mov.l r2,@(4,r14)
    c.r[6] = c.r[1] & 0xFFu;  // 06069CD8 extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069DA4u);  // 06069CDA mov.w 0x06069DA4,r1
    c.r[0] = c.r[9];  // 06069CDC mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06069CDE mov.b @(r0,r1),r1
    c.r[12] = 0x7u;  // 06069CE0 mov #7,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06069CE2 mov.b @r11,r2
    c.r[1] &= c.r[12];  // 06069CE4 and r12,r1
    c.r[1] <<= 2;  // 06069CE6 shll2 r1
    c.r[1] += c.r[1];  // 06069CE8 add r1,r1
    c.r[1] <<= 2;  // 06069CEA shll2 r1
    c.r[0] = 0x1Fu;  // 06069CEC mov #31,r0
    c.r[2] &= c.r[0];  // 06069CEE and r0,r2
    c.r[2] |= c.r[1];  // 06069CF0 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069DA6u);  // 06069CF2 mov.w 0x06069DA6,r1
    c.t = c.r[6] == c.r[1];  // 06069CF4 cmp/eq r1,r6
    { const bool k = c.t; st8(c.r[11], c.r[2]); if (k) { goto L_06069D14; } }  // 06069CF6 bt/s 0x06069D14 ; mov.b r2,@r11
    c.r[1] = ld32(0x06069DB0u);  // 06069CFA mov.l 0x06069DB0,r1
    c.r[2] = c.r[6];  // 06069CFC mov r6,r2
    c.r[2] <<= 2;  // 06069CFE shll2 r2
    c.r[2] <<= 2;  // 06069D00 shll2 r2
    c.r[4] = c.r[14];  // 06069D02 mov r14,r4
    c.r[1] = ld32(c.r[1]);  // 06069D04 mov.l @r1,r1
    c.r[4] += 44;  // 06069D06 add #44,r4
    c.r[2] += c.r[1];  // 06069D08 add r1,r2
    c.r[2] += 2;  // 06069D0A add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069D0C mov.b @r2,r5
    c.r[1] = ld32(0x06069DB4u);  // 06069D0E mov.l 0x06069DB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06069D14u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069D14u) return; }  // 06069D10 jsr @r1 ; extu.b r5,r5
L_06069D14:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06069D14 mov.b @r11,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069DA8u);  // 06069D16 mov.w 0x06069DA8,r12
    c.r[1] &= c.r[12];  // 06069D18 and r12,r1
    st8(c.r[11], c.r[1]);  // 06069D1A mov.b r1,@r11
    c.r[0] = ld32(c.r[14]);  // 06069D1C mov.l @r14,r0
    c.r[3] = ld32(0x06069DB8u);  // 06069D1E mov.l 0x06069DB8,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06069D20 mov.b @(r0,r3),r5
    c.r[2] = 0x1u;  // 06069D22 mov #1,r2
    c.r[1] = c.r[5];  // 06069D24 mov r5,r1
    c.r[1] += 4;  // 06069D26 add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069D28 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06069D2A cmp/hi r2,r1
    { const bool k = !c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_06069DCE; } }  // 06069D2C bf/s 0x06069DCE ; extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069DAAu);  // 06069D30 mov.w 0x06069DAA,r1
    c.t = c.r[5] == c.r[1];  // 06069D32 cmp/eq r1,r5
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_06069DD0; } }  // 06069D34 bt/s 0x06069DD0 ; mov r11,r2
    c.r[0] = c.r[10];  // 06069D38 mov r10,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06069D3A mov.b @(r0,r3),r7
    c.r[1] = 0x0u;  // 06069D3C mov #0,r1
    c.r[6] = c.r[14];  // 06069D3E mov r14,r6
    c.r[6] += 44;  // 06069D40 add #44,r6
    c.r[4] = c.r[9];  // 06069D42 mov r9,r4
    c.r[12] = ld32(0x06069DBCu);  // 06069D44 mov.l 0x06069DBC,r12
    c.r[7] = c.r[7] & 0xFFu;  // 06069D46 extu.b r7,r7
    { const uint32_t x = c.r[12]; c.pr = 0x06069D4Cu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069D4Cu) return; }  // 06069D48 jsr @r12 ; mov.l r1,@-r15
    c.r[10] = c.r[0];  // 06069D4C mov r0,r10
    c.r[0] = 0xFu;  // 06069D4E mov #15,r0
    c.r[10] &= c.r[0];  // 06069D50 and r0,r10
    c.r[1] = 0x4u;  // 06069D52 mov #4,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06069D54 cmp/gt r1,r10
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_06069D72; } }  // 06069D56 bf/s 0x06069D72 ; add #4,r15
    c.r[1] = 0x6u;  // 06069D5A mov #6,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06069D5C cmp/gt r1,r10
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06069D6E; } }  // 06069D5E bf/s 0x06069D6E ; mov r10,r1
    c.r[1] -= 9;  // 06069D62 add #-9,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06069D64 cmp/pz r1
    if (c.t) { goto L_06069D74; }  // 06069D66 bt 0x06069D74
    c.r[1] = 0u - c.r[1];  // 06069D68 neg r1,r1
    c.r[2] = 0x7u; goto L_06069D76;  // 06069D6A bra 0x06069D76 ; mov #7,r2
L_06069D6E:
    c.r[1] = 0x0u; goto L_06069D74;  // 06069D6E bra 0x06069D74 ; mov #0,r1
L_06069D72:
    c.r[1] = c.r[10];  // 06069D72 mov r10,r1
L_06069D74:
    c.r[2] = 0x7u;  // 06069D74 mov #7,r2
L_06069D76:
    c.r[2] &= c.r[1];  // 06069D76 and r1,r2
    c.r[2] <<= 2;  // 06069D78 shll2 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06069D7A mov.b @r11,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069DACu);  // 06069D7C mov.w 0x06069DAC,r12
    c.r[1] &= c.r[12];  // 06069D7E and r12,r1
    c.r[1] |= c.r[2];  // 06069D80 or r2,r1
    st8(c.r[11], c.r[1]);  // 06069D82 mov.b r1,@r11
    c.r[2] = c.r[10];  // 06069D84 mov r10,r2
    c.r[2] -= 5;  // 06069D86 add #-5,r2
    c.r[1] = 0x1u;  // 06069D88 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 06069D8A cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06069DC0; } }  // 06069D8C bt/s 0x06069DC0 ; mov #0,r1
    c.r[1] = c.r[10];  // 06069D90 mov r10,r1
    c.r[1] -= 7;  // 06069D92 add #-7,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06069D94 cmp/pz r1
    if (c.t) { goto L_06069DC0; }  // 06069D96 bt 0x06069DC0
    c.r[1] = 0u - c.r[1];  // 06069D98 neg r1,r1
    c.r[0] = 0x3u; goto L_06069DC2;  // 06069D9A bra 0x06069DC2 ; mov #3,r0
L_06069DC0:
    c.r[0] = 0x3u;  // 06069DC0 mov #3,r0
L_06069DC2:
    c.r[1] &= c.r[0];  // 06069DC2 and r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06069DC4 mov.b @r11,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069F50u);  // 06069DC6 mov.w 0x06069F50,r12
    c.r[2] &= c.r[12];  // 06069DC8 and r12,r2
    c.r[2] |= c.r[1];  // 06069DCA or r1,r2
    st8(c.r[11], c.r[2]);  // 06069DCC mov.b r2,@r11
L_06069DCE:
    c.r[2] = c.r[11];  // 06069DCE mov r11,r2
L_06069DD0:
    c.r[2] += 6;  // 06069DD0 add #6,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06069F52u);  // 06069DD2 mov.w 0x06069F52,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069F54u);  // 06069DD4 mov.w 0x06069F54,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06069DD6 mov.w @r8,r1
    c.r[10] = 0x0u;  // 06069DD8 mov #0,r10
    st16(c.r[2], c.r[1]);  // 06069DDA mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069DDC mov r11,r2
    c.r[1] = c.r[8];  // 06069DDE mov r8,r1
    c.r[1] += 42;  // 06069DE0 add #42,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069DE2 mov.w @r1,r1
    c.r[2] += 8;  // 06069DE4 add #8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06069DE6 extu.w r1,r1
    c.r[1] >>= 2;  // 06069DE8 shlr2 r1
    c.r[1] >>= 2;  // 06069DEA shlr2 r1
    c.r[1] >>= 2;  // 06069DEC shlr2 r1
    c.r[1] &= c.r[3];  // 06069DEE and r3,r1
    st16(c.r[2], c.r[1]);  // 06069DF0 mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069DF2 mov r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06069DF4 mov.w @r9,r1
    c.r[2] += 10;  // 06069DF6 add #10,r2
    st16(c.r[2], c.r[1]);  // 06069DF8 mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069DFA mov r11,r2
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 06069DFC mov.l @(r0,r9),r1
    c.r[2] += 12;  // 06069DFE add #12,r2
    c.r[1] >>= 8;  // 06069E00 shlr8 r1
    c.r[1] <<= 2;  // 06069E02 shll2 r1
    c.r[1] >>= 8;  // 06069E04 shlr8 r1
    c.r[1] &= c.r[3];  // 06069E06 and r3,r1
    st16(c.r[2], c.r[1]);  // 06069E08 mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069E0A mov r11,r2
    c.r[2] += 14;  // 06069E0C add #14,r2
    c.r[1] = c.r[9];  // 06069E0E mov r9,r1
    c.r[1] += 22;  // 06069E10 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069E12 mov.w @r1,r1
    st16(c.r[2], c.r[1]);  // 06069E14 mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069E16 mov r11,r2
    c.r[1] = c.r[9];  // 06069E18 mov r9,r1
    c.r[1] += 26;  // 06069E1A add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069E1C mov.w @r1,r1
    c.r[2] += 16;  // 06069E1E add #16,r2
    st16(c.r[2], c.r[1]);  // 06069E20 mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069E22 mov r11,r2
    c.r[1] = c.r[9];  // 06069E24 mov r9,r1
    c.r[1] += 24;  // 06069E26 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069E28 mov.w @r1,r1
    c.r[2] += 18;  // 06069E2A add #18,r2
    st16(c.r[2], c.r[1]);  // 06069E2C mov.w r1,@r2
    c.r[2] = c.r[11];  // 06069E2E mov r11,r2
    c.r[1] = c.r[9];  // 06069E30 mov r9,r1
    c.r[1] += 28;  // 06069E32 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069E34 mov.w @r1,r1
    c.r[2] += 20;  // 06069E36 add #20,r2
    st16(c.r[2], c.r[1]);  // 06069E38 mov.w r1,@r2
    c.r[1] = c.r[8];  // 06069E3A mov r8,r1
    c.r[1] += 30;  // 06069E3C add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069E3E mov.b @r1,r1
    c.r[2] = 0x8u;  // 06069E40 mov #8,r2
    c.r[1] -= 33;  // 06069E42 add #-33,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069E44 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06069E46 cmp/hi r2,r1
    { const bool k = !c.t; c.r[3] = 0x3u; if (k) { goto L_06069E74; } }  // 06069E48 bf/s 0x06069E74 ; mov #3,r3
    c.r[7] = c.r[8];  // 06069E4C mov r8,r7
    c.r[1] = c.r[7];  // 06069E4E mov r7,r1
L_06069E50:
    c.r[1] += 30;  // 06069E50 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069E52 mov.b @r1,r1
    c.r[1] -= 42;  // 06069E54 add #-42,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069E56 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06069E58 cmp/hi r2,r1
    if (!c.t) { goto L_06069E74; }  // 06069E5A bf 0x06069E74
    c.r[10] += 1;  // 06069E5C add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[3];  // 06069E5E cmp/gt r3,r10
    { const bool k = c.t; c.r[7] += 1; if (k) { goto L_06069E74; } }  // 06069E60 bt/s 0x06069E74 ; add #1,r7
    c.r[1] = c.r[7];  // 06069E64 mov r7,r1
    c.r[1] += 30;  // 06069E66 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069E68 mov.b @r1,r1
    c.r[1] -= 33;  // 06069E6A add #-33,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069E6C extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06069E6E cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { SH2_POLL(c); goto L_06069E50; } }  // 06069E70 bt/s 0x06069E50 ; mov r7,r1
L_06069E74:
    c.r[0] = c.r[10];  // 06069E74 mov r10,r0
    c.t = c.r[0] == 0x4u;  // 06069E76 cmp/eq #4,r0
    c.r[1] = c.t;  // 06069E78 movt r1
    c.r[2] = c.r[11];  // 06069E7A mov r11,r2
    c.r[2] += 1;  // 06069E7C add #1,r2
    c.r[12] = 0x1u;  // 06069E7E mov #1,r12
    c.r[1] ^= c.r[12];  // 06069E80 xor r12,r1
    c.r[1] <<= 2;  // 06069E82 shll2 r1
    c.r[1] <<= 2;  // 06069E84 shll2 r1
    c.r[1] += c.r[1];  // 06069E86 add r1,r1
    c.r[1] <<= 2;  // 06069E88 shll2 r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069E8A mov.b @r2,r3
    c.r[0] = 0x7Fu;  // 06069E8C mov #127,r0
    c.r[3] &= c.r[0];  // 06069E8E and r0,r3
    c.r[3] |= c.r[1];  // 06069E90 or r1,r3
    st8(c.r[2], c.r[3]);  // 06069E92 mov.b r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069F56u);  // 06069E94 mov.w 0x06069F56,r1
    c.r[0] = c.r[9];  // 06069E96 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06069E98 mov.b @(r0,r1),r1
    c.r[12] = 0x60u;  // 06069E9A mov #96,r12
    c.r[1] <<= 2;  // 06069E9C shll2 r1
    c.r[1] <<= 2;  // 06069E9E shll2 r1
    c.r[1] &= c.r[12];  // 06069EA0 and r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069F58u);  // 06069EA2 mov.w 0x06069F58,r0
    c.r[3] &= c.r[0];  // 06069EA4 and r0,r3
    c.r[3] |= c.r[1];  // 06069EA6 or r1,r3
    st8(c.r[2], c.r[3]);  // 06069EA8 mov.b r3,@r2
    c.r[0] = ld32(c.r[14] + 4);  // 06069EAA mov.l @(4,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069F5Au);  // 06069EAC mov.w 0x06069F5A,r1
    c.t = c.r[0] == c.r[1];  // 06069EAE cmp/eq r1,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06069EB8; } }  // 06069EB0 bt/s 0x06069EB8 ; mov.l @r14,r0
    goto L_06069FB8;  // 06069EB4 bra 0x06069FB8 ; nop
L_06069EB8:
    c.r[12] = ld32(0x06069F64u);  // 06069EB8 mov.l 0x06069F64,r12
    c.r[7] = ld32(0x06069F68u);  // 06069EBA mov.l 0x06069F68,r7
    c.r[8] = ld32(0x06069F6Cu);  // 06069EBC mov.l 0x06069F6C,r8
    c.r[13] = ld32(0x06069F70u);  // 06069EBE mov.l 0x06069F70,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06069EC0 mov.b @(r0,r12),r1
    c.r[5] = 0x22u;  // 06069EC2 mov #34,r5
    c.r[3] = ld32(c.r[8]);  // 06069EC4 mov.l @r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06069EC6 extu.b r1,r1
    c.r[1] <<= 2;  // 06069EC8 shll2 r1
    c.r[1] <<= 2;  // 06069ECA shll2 r1
    c.r[2] = c.r[1];  // 06069ECC mov r1,r2
    c.r[2] += c.r[3];  // 06069ECE add r3,r2
    c.r[2] += 1;  // 06069ED0 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069ED2 mov.b @r2,r2
    c.r[0] = c.r[1];  // 06069ED4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06069ED6 mov.b @(r0,r3),r1
    c.r[2] = c.r[2] & 0xFFu;  // 06069ED8 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06069EDA extu.b r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06069F5Cu);  // 06069EDC mov.w 0x06069F5C,r3
    c.r[0] = c.r[7];  // 06069EDE mov r7,r0
    c.r[3] = ld32(c.r[0] + c.r[3]);  // 06069EE0 mov.l @(r0,r3),r3
    c.r[2] <<= 2;  // 06069EE2 shll2 r2
    c.r[2] <<= 2;  // 06069EE4 shll2 r2
    c.r[2] <<= 2;  // 06069EE6 shll2 r2
    c.r[2] += c.r[3];  // 06069EE8 add r3,r2
    c.r[0] = c.r[2];  // 06069EEA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06069EEC mov.b @(r0,r1),r1
    c.r[4] = ld32(0x06069F74u);  // 06069EEE mov.l 0x06069F74,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06069EF4u; c.r[10] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069EF4u) return; }  // 06069EF0 jsr @r13 ; extu.b r1,r10
    c.r[1] = c.r[0];  // 06069EF4 mov r0,r1
    c.r[5] = 0x2u;  // 06069EF6 mov #2,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06069EFCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069EFCu) return; }  // 06069EF8 jsr @r13 ; mov r1,r4
    c.r[7] = c.r[0];  // 06069EFC mov r0,r7
    c.r[1] = ld32(0x06069F78u);  // 06069EFE mov.l 0x06069F78,r1
    c.r[1] = ld32(c.r[1]);  // 06069F00 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069F5Eu);  // 06069F02 mov.w 0x06069F5E,r2
    c.r[0] = c.r[1];  // 06069F04 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06069F06 mov.b @(r0,r2),r1
    c.r[3] = c.r[10];  // 06069F08 mov r10,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06069F0A extu.b r1,r1
    c.r[1] >>= 2;  // 06069F0C shlr2 r1
    c.r[1] >>= 2;  // 06069F0E shlr2 r1
    c.r[1] >>= 2;  // 06069F10 shlr2 r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069F60u);  // 06069F12 mov.w 0x06069F60,r2
    c.r[3] <<= 2;  // 06069F14 shll2 r3
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[2] & 0xFFFFu);  // 06069F16 mulu.w r2,r1
    c.r[0] = ld32(c.r[14]);  // 06069F18 mov.l @r14,r0
    c.r[1] = c.macl;  // 06069F1A sts macl,r1
    c.r[7] += c.r[1];  // 06069F1C add r1,r7
    c.r[12] = c.r[7];  // 06069F1E mov r7,r12
    c.r[12] += c.r[3];  // 06069F20 add r3,r12
    st32(c.r[14] + 8, c.r[12]);  // 06069F22 mov.l r12,@(8,r14)
    c.r[12] = ld32(0x06069F64u);  // 06069F24 mov.l 0x06069F64,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06069F26 mov.b @(r0,r12),r1
    c.r[2] = ld32(c.r[8]);  // 06069F28 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06069F2A extu.b r1,r1
    c.r[1] <<= 2;  // 06069F2C shll2 r1
    c.r[1] <<= 2;  // 06069F2E shll2 r1
    c.r[1] += c.r[2];  // 06069F30 add r2,r1
    c.r[1] += 3;  // 06069F32 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069F34 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06069F36 mov #3,r0
    c.r[8] = c.r[1];  // 06069F38 mov r1,r8
    c.r[8] >>= 2;  // 06069F3A shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06069F3C shlr r8
    c.r[8] &= c.r[0];  // 06069F3E and r0,r8
    c.r[0] = c.r[8];  // 06069F40 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 06069F42 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_06069F7C; } }  // 06069F44 bt/s 0x06069F7C ; cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_06069FA6; } }  // 06069F48 bt/s 0x06069FA6 ; mov r7,r0
    c.r[12] = ld32(c.r[14] + 8); goto L_06069FAA;  // 06069F4C bra 0x06069FAA ; mov.l @(8,r14),r12
L_06069F7C:
    c.r[4] = ld32(0x0606A08Cu);  // 06069F7C mov.l 0x0606A08C,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06069F82u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069F82u) return; }  // 06069F7E jsr @r13 ; mov #34,r5
    c.r[5] = c.r[8];  // 06069F82 mov r8,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06069F88u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069F88u) return; }  // 06069F84 jsr @r13 ; mov r0,r4
    c.r[5] = 0x3u;  // 06069F88 mov #3,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06069F8Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069F8Eu) return; }  // 06069F8A jsr @r13 ; mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06069F8E mov.b @(r0,r10),r0
    c.r[0] &= 0x40u;  // 06069F90 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06069F92 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06069F9E; } }  // 06069F94 bt/s 0x06069F9E ; mov.l @(8,r14),r0
    c.r[12] = ld32(c.r[14] + 8);  // 06069F98 mov.l @(8,r14),r12
    c.r[12] += 1; goto L_06069FAC;  // 06069F9A bra 0x06069FAC ; add #1,r12
L_06069F9E:
    c.r[0] += 2;  // 06069F9E add #2,r0
    st32(c.r[14] + 8, c.r[0]);  // 06069FA0 mov.l r0,@(8,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); goto L_06069FB0;  // 06069FA2 bra 0x06069FB0 ; mov.b @r0,r1
L_06069FA6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_06069FB0;  // 06069FA6 bra 0x06069FB0 ; mov.b @(r0,r3),r1
L_06069FAA:
    c.r[12] += 3;  // 06069FAA add #3,r12
L_06069FAC:
    st32(c.r[14] + 8, c.r[12]);  // 06069FAC mov.l r12,@(8,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06069FAE mov.b @r12,r1
L_06069FB0:
    c.r[10] = c.r[1] & 0xFFu;  // 06069FB0 extu.b r1,r10
    c.r[1] = c.r[11];  // 06069FB2 mov r11,r1
    c.r[1] += 30;  // 06069FB4 add #30,r1
    st8(c.r[1], c.r[10]);  // 06069FB6 mov.b r10,@r1
L_06069FB8:
    c.r[6] = c.r[11];  // 06069FB8 mov r11,r6
    c.r[6] += 2;  // 06069FBA add #2,r6
    c.r[1] = 0x0u;  // 06069FBC mov #0,r1
    st16(c.r[6], c.r[1]);  // 06069FBE mov.w r1,@r6
    c.r[5] = c.r[11];  // 06069FC0 mov r11,r5
    c.r[5] += 29;  // 06069FC2 add #29,r5
    c.r[1] = 0x0u;  // 06069FC4 mov #0,r1
    st8(c.r[5], c.r[1]);  // 06069FC6 mov.b r1,@r5
    c.r[0] = ld32(c.r[14] + 4);  // 06069FC8 mov.l @(4,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A088u);  // 06069FCA mov.w 0x0606A088,r1
    c.t = c.r[0] == c.r[1];  // 06069FCC cmp/eq r1,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0606A072; } }  // 06069FCE bf/s 0x0606A072 ; mov.l @r14,r0
    c.r[7] = ld32(0x0606A090u);  // 06069FD2 mov.l 0x0606A090,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06069FD4 mov.b @(r0,r7),r3
    c.r[2] = 0x1u;  // 06069FD6 mov #1,r2
    c.r[1] = c.r[3];  // 06069FD8 mov r3,r1
    c.r[1] += 4;  // 06069FDA add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069FDC extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06069FDE cmp/hi r2,r1
    { const bool k = !c.t; c.r[2] = c.r[3] & 0xFFu; if (k) { goto L_0606A072; } }  // 06069FE0 bf/s 0x0606A072 ; extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A08Au);  // 06069FE4 mov.w 0x0606A08A,r1
    c.t = c.r[2] == c.r[1];  // 06069FE6 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606A072; } }  // 06069FE8 bt/s 0x0606A072 ; mov r2,r1
    c.r[1] <<= 2;  // 06069FEC shll2 r1
    c.r[1] += c.r[2];  // 06069FEE add r2,r1
    c.r[1] <<= 2;  // 06069FF0 shll2 r1
    c.r[1] += c.r[9];  // 06069FF2 add r9,r1
    c.r[1] += 44;  // 06069FF4 add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069FF6 mov.w @r1,r1
    st16(c.r[6], c.r[1]);  // 06069FF8 mov.w r1,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06069FFA mov.b @(r0,r7),r1
    c.r[3] = c.r[11];  // 06069FFC mov r11,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06069FFE extu.b r1,r1
    c.r[2] = c.r[1];  // 0606A000 mov r1,r2
    c.r[2] <<= 2;  // 0606A002 shll2 r2
    c.r[2] += c.r[1];  // 0606A004 add r1,r2
    c.r[2] <<= 2;  // 0606A006 shll2 r2
    c.r[2] += c.r[9];  // 0606A008 add r9,r2
    c.r[2] += 46;  // 0606A00A add #46,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606A00C mov.w @r2,r1
    c.r[3] += 4;  // 0606A00E add #4,r3
    st16(c.r[3], c.r[1]);  // 0606A010 mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606A012 mov.b @(r0,r7),r1
    c.r[3] = c.r[11];  // 0606A014 mov r11,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606A016 extu.b r1,r1
    c.r[2] = c.r[1];  // 0606A018 mov r1,r2
    c.r[2] <<= 2;  // 0606A01A shll2 r2
    c.r[2] += c.r[1];  // 0606A01C add r1,r2
    c.r[2] <<= 2;  // 0606A01E shll2 r2
    c.r[2] += c.r[9];  // 0606A020 add r9,r2
    c.r[2] += 57;  // 0606A022 add #57,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A024 mov.b @r2,r1
    c.r[3] += 28;  // 0606A026 add #28,r3
    st8(c.r[3], c.r[1]);  // 0606A028 mov.b r1,@r3
    c.r[3] = c.r[11];  // 0606A02A mov r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606A02C mov.b @(r0,r7),r1
    c.r[3] += 22;  // 0606A02E add #22,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606A030 extu.b r1,r1
    c.r[2] = c.r[1];  // 0606A032 mov r1,r2
    c.r[2] <<= 2;  // 0606A034 shll2 r2
    c.r[2] += c.r[1];  // 0606A036 add r1,r2
    c.r[2] <<= 2;  // 0606A038 shll2 r2
    c.r[2] += c.r[9];  // 0606A03A add r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606A03C mov.w @r3,r1
    c.r[2] += 54;  // 0606A03E add #54,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606A040 mov.w @r2,r2
    c.r[11] += 24;  // 0606A042 add #24,r11
    c.r[1] += c.r[2];  // 0606A044 add r2,r1
    st16(c.r[3], c.r[1]);  // 0606A046 mov.w r1,@r3
    st16(c.r[11], c.r[1]);  // 0606A048 mov.w r1,@r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606A04A mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606A04C extu.b r1,r1
    c.r[2] = c.r[1];  // 0606A04E mov r1,r2
    c.r[2] <<= 2;  // 0606A050 shll2 r2
    c.r[2] += c.r[1];  // 0606A052 add r1,r2
    c.r[2] <<= 2;  // 0606A054 shll2 r2
    c.r[9] += c.r[2];  // 0606A056 add r2,r9
    c.r[9] += 52;  // 0606A058 add #52,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0606A05A mov.w @r9,r1
    c.r[1] <<= 16;  // 0606A05C shll16 r1
    c.r[1] <<= 2;  // 0606A05E shll2 r1
    c.r[1] += c.r[1];  // 0606A060 add r1,r1
    c.r[1] <<= 2;  // 0606A062 shll2 r1
    c.r[1] >>= 16;  // 0606A064 shlr16 r1
    c.r[1] <<= 2;  // 0606A066 shll2 r1
    c.r[1] >>= 8;  // 0606A068 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A06A tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0606A072; } }  // 0606A06C bt/s 0x0606A072 ; mov #1,r1
    st8(c.r[5], c.r[1]);  // 0606A070 mov.b r1,@r5
L_0606A072:
    c.r[14] += 12;  // 0606A072 add #12,r14
    c.r[15] = c.r[14];  // 0606A074 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606A076 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606A078 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606A07A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606A07C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606A07E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606A080 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606A082 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606A084 rts ; mov.l @r15+,r8
}

void f_0606A094(SH2Context& c) {
    ran[1524] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0606A094 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0606A096 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606A098 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606A09A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606A09C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606A09E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606A0A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606A0A2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606A0A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606A0A6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606A1D2u);  // 0606A0A8 mov.w 0x0606A1D2,r3
    c.r[15] += c.r[3];  // 0606A0AA add r3,r15
    c.r[14] = c.r[15];  // 0606A0AC mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D4u);  // 0606A0AE mov.w 0x0606A1D4,r0
    st32(c.r[0] + c.r[14], c.r[5]);  // 0606A0B0 mov.l r5,@(r0,r14)
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1D6u);  // 0606A0B2 mov.w 0x0606A1D6,r13
    c.r[13] += c.r[14];  // 0606A0B4 add r14,r13
    c.r[11] = c.r[6] & 0xFFu;  // 0606A0B6 extu.b r6,r11
    c.r[12] = c.r[7] & 0xFFu;  // 0606A0B8 extu.b r7,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D8u);  // 0606A0BA mov.w 0x0606A1D8,r0
    c.r[0] += c.r[14];  // 0606A0BC add r14,r0
    c.r[1] = ld32(c.r[13]);  // 0606A0BE mov.l @r13,r1
    c.r[3] = ld32(0x0606A1E8u);  // 0606A0C0 mov.l 0x0606A1E8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606A0C2 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0606A0C4 mov.l r1,@r0
    c.r[0] = c.r[11];  // 0606A0C6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A0C8 mov.b @(r0,r3),r1
    c.r[2] = ld32(0x0606A1ECu);  // 0606A0CA mov.l 0x0606A1EC,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0606A0CC extu.b r1,r6
    c.r[0] = c.r[12];  // 0606A0CE mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606A0D0 mov.b @(r0,r2),r1
    c.r[10] = c.r[4];  // 0606A0D2 mov r4,r10
    c.r[5] = c.r[1] & 0xFFu;  // 0606A0D4 extu.b r1,r5
    c.r[0] = c.r[11];  // 0606A0D6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606A0D8 mov.b @(r0,r2),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606A0DA extu.b r1,r7
    c.r[0] = c.r[12];  // 0606A0DC mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A0DE mov.b @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A1DAu);  // 0606A0E0 mov.w 0x0606A1DA,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A0E2 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606A0E4 cmp/eq r2,r1
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0606A0F0; } }  // 0606A0E6 bf/s 0x0606A0F0 ; mov #0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DCu);  // 0606A0EA mov.w 0x0606A1DC,r1
    c.r[1] |= c.r[7]; goto L_0606A0F2;  // 0606A0EC bra 0x0606A0F2 ; or r7,r1
L_0606A0F0:
    c.r[1] = c.r[7] & 0xFFu;  // 0606A0F0 extu.b r7,r1
L_0606A0F2:
    c.r[13] = ld32(0x0606A1F0u);  // 0606A0F2 mov.l 0x0606A1F0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A0F8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A0F8u) return; }  // 0606A0F4 jsr @r13 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606A0F8 mov r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0606A0FA extu.b r1,r5
    c.r[0] = ld32(0x0606A1ECu);  // 0606A0FC mov.l 0x0606A1EC,r0
    c.r[1] = ld32(0x0606A1F4u);  // 0606A0FE mov.l 0x0606A1F4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606A100 mov.b @(r0,r11),r2
    c.r[13] = 0x3u;  // 0606A102 mov #3,r13
    c.r[1] = ld32(c.r[1]);  // 0606A104 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606A106 extu.b r2,r2
    c.r[2] <<= 2;  // 0606A108 shll2 r2
    c.r[2] <<= 2;  // 0606A10A shll2 r2
    c.r[2] += c.r[1];  // 0606A10C add r1,r2
    c.r[2] += 3;  // 0606A10E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A110 mov.b @r2,r1
    c.r[0] = ld32(0x0606A1F8u);  // 0606A112 mov.l 0x0606A1F8,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606A114 shlr r1
    c.r[1] &= c.r[13];  // 0606A116 and r13,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0606A11Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A11Cu) return; }  // 0606A118 jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606A11C mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A11E tst r1,r1
    { const bool k = !c.t; c.r[13] = 0x40u; if (k) { goto L_0606A136; } }  // 0606A120 bf/s 0x0606A136 ; mov #64,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D8u);  // 0606A124 mov.w 0x0606A1D8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A126 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DEu);  // 0606A128 mov.w 0x0606A1DE,r1
    c.t = c.r[0] == c.r[1];  // 0606A12A cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0606A134; } }  // 0606A12C bf/s 0x0606A134 ; mov r10,r2
    goto L_0606A53E;  // 0606A130 bra 0x0606A53E ; nop
L_0606A134:
    c.r[13] = 0x40u;  // 0606A134 mov #64,r13
L_0606A136:
    c.r[8] = ld32(0x0606A1E8u);  // 0606A136 mov.l 0x0606A1E8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A138 mov.b @r10,r1
    c.r[0] = c.r[11];  // 0606A13A mov r11,r0
    c.r[1] |= c.r[13];  // 0606A13C or r13,r1
    st8(c.r[10], c.r[1]);  // 0606A13E mov.b r1,@r10
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1E0u);  // 0606A140 mov.w 0x0606A1E0,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A142 mov.b @(r0,r8),r7
    c.r[13] += c.r[14];  // 0606A144 add r14,r13
    c.r[0] = ld32(0x0606A1ECu);  // 0606A146 mov.l 0x0606A1EC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606A148 mov.b @(r0,r11),r1
    c.r[7] = c.r[7] & 0xFFu;  // 0606A14A extu.b r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606A14C extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606A14E mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1E2u);  // 0606A150 mov.w 0x0606A1E2,r0
    c.r[6] = ld32(c.r[13]);  // 0606A152 mov.l @r13,r6
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 0606A154 mov.l @(r0,r14),r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1E4u);  // 0606A156 mov.w 0x0606A1E4,r13
    c.r[13] += c.r[14];  // 0606A158 add r14,r13
    c.r[0] = ld32(0x0606A1FCu);  // 0606A15A mov.l 0x0606A1FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606A160u; c.r[4] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A160u) return; }  // 0606A15C jsr @r0 ; mov.l @r13,r4
    c.r[1] = c.r[0];  // 0606A160 mov r0,r1
    c.r[2] = 0x1u;  // 0606A162 mov #1,r2
    c.r[2] &= c.r[1];  // 0606A164 and r1,r2
    c.r[2] <<= 2;  // 0606A166 shll2 r2
    c.r[2] += c.r[2];  // 0606A168 add r2,r2
    c.r[2] <<= 2;  // 0606A16A shll2 r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1E6u);  // 0606A16C mov.w 0x0606A1E6,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A16E mov.b @r10,r1
    c.r[0] = c.r[11];  // 0606A170 mov r11,r0
    c.r[1] &= c.r[13];  // 0606A172 and r13,r1
    c.r[1] |= c.r[2];  // 0606A174 or r2,r1
    st8(c.r[10], c.r[1]);  // 0606A176 mov.b r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A178 mov.b @(r0,r8),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0606A17A extu.b r1,r6
    c.r[0] = ld32(0x0606A1ECu);  // 0606A17C mov.l 0x0606A1EC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606A17E mov.b @(r0,r12),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606A180 extu.b r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D8u);  // 0606A182 mov.w 0x0606A1D8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A184 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DEu);  // 0606A186 mov.w 0x0606A1DE,r1
    c.t = c.r[0] == c.r[1];  // 0606A188 cmp/eq r1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0606A194; } }  // 0606A18A bt/s 0x0606A194 ; add #4,r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DCu);  // 0606A18E mov.w 0x0606A1DC,r1
    c.r[1] |= c.r[2]; goto L_0606A196;  // 0606A190 bra 0x0606A196 ; or r2,r1
L_0606A194:
    c.r[1] = c.r[2] & 0xFFu;  // 0606A194 extu.b r2,r1
L_0606A196:
    c.r[8] = ld32(0x0606A1ECu);  // 0606A196 mov.l 0x0606A1EC,r8
    c.r[0] = c.r[11];  // 0606A198 mov r11,r0
    c.r[5] = c.r[1];  // 0606A19A mov r1,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A19C mov.b @(r0,r8),r4
    c.r[13] = ld32(0x0606A200u);  // 0606A19E mov.l 0x0606A200,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A1A4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A1A4u) return; }  // 0606A1A0 jsr @r13 ; extu.b r4,r4
    c.r[9] = c.r[0];  // 0606A1A4 mov r0,r9
    c.r[0] = c.r[11];  // 0606A1A6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A1A8 mov.b @(r0,r8),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606A1AA extu.b r1,r2
    c.r[1] = ld32(0x0606A1F4u);  // 0606A1AC mov.l 0x0606A1F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606A1AE mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A1B0 shll2 r2
    c.r[2] <<= 2;  // 0606A1B2 shll2 r2
    c.r[2] += c.r[1];  // 0606A1B4 add r1,r2
    c.r[1] = c.r[2];  // 0606A1B6 mov r2,r1
    c.r[1] += 11;  // 0606A1B8 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A1BA mov.b @r1,r1
    c.r[13] = 0x1u;  // 0606A1BC mov #1,r13
    c.r[1] >>= 2;  // 0606A1BE shlr2 r1
    c.r[1] >>= 2;  // 0606A1C0 shlr2 r1
    c.r[1] &= c.r[13];  // 0606A1C2 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A1C4 tst r1,r1
    { const bool k = c.t; c.r[2] += 10; if (k) { goto L_0606A204; } }  // 0606A1C6 bt/s 0x0606A204 ; add #10,r2
    c.r[1] = c.r[9];  // 0606A1CA mov r9,r1
    c.r[1] += c.r[1];  // 0606A1CC add r1,r1
    c.r[9] += c.r[1]; goto L_0606A216;  // 0606A1CE bra 0x0606A216 ; add r1,r9
L_0606A204:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A204 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606A206 mov r1,r0
    c.r[0] >>= 2;  // 0606A208 shlr2 r0
    c.r[0] >>= 2;  // 0606A20A shlr2 r0
    c.r[0] >>= 2;  // 0606A20C shlr2 r0
    c.r[0] &= 0x1u;  // 0606A20E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A210 tst r0,r0
    if (c.t) { goto L_0606A216; }  // 0606A212 bt 0x0606A216
    c.r[9] += c.r[9];  // 0606A214 add r9,r9
L_0606A216:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A216 mov.b @r10,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606A218 extu.b r1,r3
    c.r[0] = c.r[3];  // 0606A21A mov r3,r0
    c.r[0] >>= 2;  // 0606A21C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A21E shlr r0
    c.r[0] >>= 2;  // 0606A220 shlr2 r0
    c.r[0] &= 0x1u;  // 0606A222 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A224 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606A23C; } }  // 0606A226 bt/s 0x0606A23C ; mov r3,r0
    c.r[1] = 0xFu;  // 0606A22A mov #15,r1
    c.macl = c.r[9] * c.r[1];  // 0606A22C mul.l r1,r9
    c.r[1] = ld32(0x0606A358u);  // 0606A22E mov.l 0x0606A358,r1
    c.r[1] = ld32(c.r[1]);  // 0606A230 mov.l @r1,r1
    c.r[2] = c.macl;  // 0606A232 sts macl,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0606A234 dmulu.l r1,r2
    c.r[9] = c.mach;  // 0606A236 sts mach,r9
    c.r[9] >>= 2;  // 0606A238 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0606A23A shlr r9
L_0606A23C:
    c.r[0] >>= 2;  // 0606A23C shlr2 r0
    c.r[0] &= 0x3u;  // 0606A23E and #3,r0
    c.t = c.r[0] == 0x2u;  // 0606A240 cmp/eq #2,r0
    if (!c.t) { goto L_0606A246; }  // 0606A242 bf 0x0606A246
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0606A244 shlr r9
L_0606A246:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A34Au);  // 0606A246 mov.w 0x0606A34A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A248 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A34Cu);  // 0606A24A mov.w 0x0606A34C,r1
    c.t = c.r[0] == c.r[1];  // 0606A24C cmp/eq r1,r0
    { const bool k = c.t; c.r[4] = c.r[14]; if (k) { goto L_0606A274; } }  // 0606A24E bt/s 0x0606A274 ; mov r14,r4
    c.r[1] = ld32(0x0606A35Cu);  // 0606A252 mov.l 0x0606A35C,r1
    c.r[0] = c.r[12];  // 0606A254 mov r12,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A256 mov.b @(r0,r1),r6
    c.r[6] = c.r[6] & 0xFFu;  // 0606A258 extu.b r6,r6
    c.r[1] = ld32(0x0606A360u);  // 0606A25A mov.l 0x0606A360,r1
    c.r[2] = c.r[6];  // 0606A25C mov r6,r2
    c.r[1] = ld32(c.r[1]);  // 0606A25E mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A260 shll2 r2
    c.r[2] <<= 2;  // 0606A262 shll2 r2
    c.r[2] += c.r[1];  // 0606A264 add r1,r2
    c.r[2] += 2;  // 0606A266 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A268 mov.b @r2,r5
    c.r[1] = ld32(0x0606A364u);  // 0606A26A mov.l 0x0606A364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A270u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A270u) return; }  // 0606A26C jsr @r1 ; extu.b r5,r5
    goto L_0606A280;  // 0606A270 bra 0x0606A280 ; nop
L_0606A274:
    c.r[1] = ld32(0x0606A368u);  // 0606A274 mov.l 0x0606A368,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A34Eu);  // 0606A276 mov.w 0x0606A34E,r13
    c.r[13] += c.r[14];  // 0606A278 add r14,r13
    c.r[5] = ld32(c.r[13]);  // 0606A27A mov.l @r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606A280u; c.r[6] = 0x5Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A280u) return; }  // 0606A27C jsr @r1 ; mov #93,r6
L_0606A280:
    c.r[1] = ld32(0x0606A36Cu);  // 0606A280 mov.l 0x0606A36C,r1
    c.r[0] = c.r[12];  // 0606A282 mov r12,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A34Eu);  // 0606A284 mov.w 0x0606A34E,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A286 mov.b @(r0,r1),r7
    c.r[13] += c.r[14];  // 0606A288 add r14,r13
    c.r[0] = c.r[11];  // 0606A28A mov r11,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A28C mov.b @(r0,r1),r5
    c.r[7] = c.r[7] & 0xFFu;  // 0606A28E extu.b r7,r7
    c.r[5] = c.r[5] & 0xFFu;  // 0606A290 extu.b r5,r5
    c.r[1] = 0x0u;  // 0606A292 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606A294 mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A350u);  // 0606A296 mov.w 0x0606A350,r0
    c.r[6] = ld32(c.r[13]);  // 0606A298 mov.l @r13,r6
    c.r[0] += c.r[14];  // 0606A29A add r14,r0
    c.r[13] = ld32(0x0606A370u);  // 0606A29C mov.l 0x0606A370,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A2A2u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A2A2u) return; }  // 0606A29E jsr @r13 ; mov.l @r0,r4
    c.r[3] = c.r[0];  // 0606A2A2 mov r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606A2A4 tst r3,r3
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0606A378; } }  // 0606A2A6 bt/s 0x0606A378 ; add #4,r15
    c.t = (c.r[11] & c.r[11]) == 0;  // 0606A2AA tst r11,r11
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606A2C2; } }  // 0606A2AC bt/s 0x0606A2C2 ; mov r3,r1
    c.r[1] = ld32(0x0606A374u);  // 0606A2B0 mov.l 0x0606A374,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A2B2 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606A2B4 mov #1,r0
    c.r[1] >>= 2;  // 0606A2B6 shlr2 r1
    c.r[1] >>= 2;  // 0606A2B8 shlr2 r1
    c.r[1] &= c.r[0];  // 0606A2BA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A2BC tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606A378; } }  // 0606A2BE bf/s 0x0606A378 ; mov r3,r1
L_0606A2C2:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C8 shar r1
    c.t = c.r[9] > c.r[1];  // 0606A2CA cmp/hi r1,r9
    { const bool k = !c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0606A2F4; } }  // 0606A2CC bf/s 0x0606A2F4 ; mov.b @r10,r1
    c.r[13] = 0x2u;  // 0606A2D0 mov #2,r13
    c.r[1] |= c.r[13];  // 0606A2D2 or r13,r1
    st8(c.r[10], c.r[1]);  // 0606A2D4 mov.b r1,@r10
    c.r[1] = 0xFu;  // 0606A2D6 mov #15,r1
    c.r[1] &= c.r[3];  // 0606A2D8 and r3,r1
    c.r[0] = c.r[1];  // 0606A2DA mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0606A2DC cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606A2E8; } }  // 0606A2DE bt/s 0x0606A2E8 ; mov r3,r1
    c.t = c.r[0] == 0x8u;  // 0606A2E2 cmp/eq #8,r0
    { const bool k = !c.t; c.r[0] = 0xFu; if (k) { goto L_0606A2FE; } }  // 0606A2E4 bf/s 0x0606A2FE ; mov #15,r0
L_0606A2E8:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2E8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2EA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2EC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2EE shar r1
    c.r[9] -= c.r[1]; goto L_0606A2FC;  // 0606A2F0 bra 0x0606A2FC ; sub r1,r9
L_0606A2F4:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A352u);  // 0606A2F4 mov.w 0x0606A352,r13
    c.r[9] = 0x0u;  // 0606A2F6 mov #0,r9
    c.r[1] &= c.r[13];  // 0606A2F8 and r13,r1
    st8(c.r[10], c.r[1]);  // 0606A2FA mov.b r1,@r10
L_0606A2FC:
    c.r[0] = 0xFu;  // 0606A2FC mov #15,r0
L_0606A2FE:
    c.r[3] &= c.r[0];  // 0606A2FE and r0,r3
    c.r[1] = 0x7u;  // 0606A300 mov #7,r1
    c.r[2] = c.r[3];  // 0606A302 mov r3,r2
    c.r[2] -= 1;  // 0606A304 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0606A306 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606A32E; } }  // 0606A308 bt/s 0x0606A32E ; mov r2,r1
    c.r[1] += c.r[1];  // 0606A30C add r1,r1
    c.r[0] = 0x0606A318u;  // 0606A30E mova 0x0606A318,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606A310 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0606A312 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0606A32Cu: goto L_0606A32C; case 0x0606A328u: goto L_0606A328; default: sh2_call(c, x); return; } }  // 0606A314 jmp @r0 ; nop
L_0606A328:
    c.r[3] = 0x0u; goto L_0606A32E;  // 0606A328 bra 0x0606A32E ; mov #0,r3
L_0606A32C:
    c.r[3] = 0x5u;  // 0606A32C mov #5,r3
L_0606A32E:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A354u);  // 0606A32E mov.w 0x0606A354,r13
    c.r[13] += c.r[14];  // 0606A330 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A354u);  // 0606A332 mov.w 0x0606A354,r0
    c.r[1] = ld32(c.r[13]);  // 0606A334 mov.l @r13,r1
    c.r[0] += c.r[14];  // 0606A336 add r14,r0
    c.r[1] += 27;  // 0606A338 add #27,r1
    st8(c.r[1], c.r[3]);  // 0606A33A mov.b r3,@r1
    c.r[13] = ld32(c.r[0]);  // 0606A33C mov.l @r0,r13
    c.r[13] += 26;  // 0606A33E add #26,r13
    st32(c.r[0], c.r[13]);  // 0606A340 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A354u);  // 0606A342 mov.w 0x0606A354,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0606A344 mov.l @(r0,r14),r13
    st8(c.r[13], c.r[3]); goto L_0606A3C4;  // 0606A346 bra 0x0606A3C4 ; mov.b r3,@r13
L_0606A378:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A378 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0606A37A mov r1,r0
    c.r[0] >>= 2;  // 0606A37C shlr2 r0
    c.r[0] &= 0x3u;  // 0606A37E and #3,r0
    c.t = c.r[0] == 0x2u;  // 0606A380 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_0606A3C4; } }  // 0606A382 bt/s 0x0606A3C4 ; mov r12,r0
    c.r[1] = ld32(0x0606A4E4u);  // 0606A386 mov.l 0x0606A4E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A388 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D2u);  // 0606A38A mov.w 0x0606A4D2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A38C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606A38E cmp/eq r2,r1
    if (c.t) { goto L_0606A3C4; }  // 0606A390 bt 0x0606A3C4
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A392 mov.w 0x0606A4D4,r13
    c.r[13] += c.r[14];  // 0606A394 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D6u);  // 0606A396 mov.w 0x0606A4D6,r0
    c.r[5] = ld32(c.r[13]);  // 0606A398 mov.l @r13,r5
    c.r[0] += c.r[14];  // 0606A39A add r14,r0
    c.r[13] = ld32(0x0606A4E8u);  // 0606A39C mov.l 0x0606A4E8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A3A2u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A3A2u) return; }  // 0606A39E jsr @r13 ; mov.l @r0,r4
    c.r[1] = c.r[0];  // 0606A3A2 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606A3A4 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606A3A6 tst r3,r3
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_0606A3C4; } }  // 0606A3A8 bt/s 0x0606A3C4 ; add #2,r3
    c.r[0] = 0x3u;  // 0606A3AC mov #3,r0
    c.r[3] &= c.r[0];  // 0606A3AE and r0,r3
    c.r[3] <<= 2;  // 0606A3B0 shll2 r3
    c.r[3] <<= 2;  // 0606A3B2 shll2 r3
    c.r[3] += c.r[3];  // 0606A3B4 add r3,r3
    c.r[3] <<= 2;  // 0606A3B6 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0606A3B8 mov.w @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D8u);  // 0606A3BA mov.w 0x0606A4D8,r2
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0606A3BC shlr r9
    c.r[1] &= c.r[2];  // 0606A3BE and r2,r1
    c.r[1] |= c.r[3];  // 0606A3C0 or r3,r1
    st16(c.r[10], c.r[1]);  // 0606A3C2 mov.w r1,@r10
L_0606A3C4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4DAu);  // 0606A3C4 mov.w 0x0606A4DA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A3C6 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A4DCu);  // 0606A3C8 mov.w 0x0606A4DC,r1
    c.t = c.r[0] == c.r[1];  // 0606A3CA cmp/eq r1,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0606A476; } }  // 0606A3CC bf/s 0x0606A476 ; mov r12,r0
    c.r[3] = ld32(0x0606A4E4u);  // 0606A3D0 mov.l 0x0606A4E4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A3D2 mov.b @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D2u);  // 0606A3D4 mov.w 0x0606A4D2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A3D6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606A3D8 cmp/eq r2,r1
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0606A478; } }  // 0606A3DA bt/s 0x0606A478 ; tst r9,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A3DE mov.b @r10,r1
    c.r[0] = c.r[1];  // 0606A3E0 mov r1,r0
    c.r[0] >>= 2;  // 0606A3E2 shlr2 r0
    c.r[0] &= 0x3u;  // 0606A3E4 and #3,r0
    c.t = c.r[0] == 0x1u;  // 0606A3E6 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A446; } }  // 0606A3E8 bt/s 0x0606A446 ; mov r11,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A3EC mov.w 0x0606A4D4,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A3EE mov.b @(r0,r3),r7
    c.r[13] += c.r[14];  // 0606A3F0 add r14,r13
    c.r[6] = ld32(c.r[13]);  // 0606A3F2 mov.l @r13,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0606A3F4 extu.b r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D6u);  // 0606A3F6 mov.w 0x0606A4D6,r0
    c.r[0] += c.r[14];  // 0606A3F8 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A4DEu);  // 0606A3FA mov.w 0x0606A4DE,r13
    c.r[5] = ld32(c.r[0]);  // 0606A3FC mov.l @r0,r5
    c.r[13] += c.r[14];  // 0606A3FE add r14,r13
    c.r[0] = ld32(0x0606A4ECu);  // 0606A400 mov.l 0x0606A4EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606A406u; c.r[4] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A406u) return; }  // 0606A402 jsr @r0 ; mov.l @r13,r4
    c.r[1] = c.r[0];  // 0606A406 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606A408 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606A40A tst r3,r3
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A446; } }  // 0606A40C bt/s 0x0606A446 ; mov r11,r0
    c.r[1] = ld32(0x0606A4F0u);  // 0606A410 mov.l 0x0606A4F0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A412 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606A414 extu.b r2,r2
    c.r[1] = ld32(0x0606A4F4u);  // 0606A416 mov.l 0x0606A4F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606A418 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A41A shll2 r2
    c.r[2] <<= 2;  // 0606A41C shll2 r2
    c.r[2] += c.r[1];  // 0606A41E add r1,r2
    c.r[2] += 10;  // 0606A420 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A422 mov.b @r2,r1
    c.r[13] = 0x1u;  // 0606A424 mov #1,r13
    c.r[1] >>= 2;  // 0606A426 shlr2 r1
    c.r[1] >>= 2;  // 0606A428 shlr2 r1
    c.r[1] &= c.r[13];  // 0606A42A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A42C tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_0606A446; } }  // 0606A42E bf/s 0x0606A446 ; mov #3,r0
    c.r[3] &= c.r[0];  // 0606A432 and r0,r3
    c.r[3] <<= 2;  // 0606A434 shll2 r3
    c.r[3] <<= 2;  // 0606A436 shll2 r3
    c.r[3] += c.r[3];  // 0606A438 add r3,r3
    c.r[3] <<= 2;  // 0606A43A shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0606A43C mov.w @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D8u);  // 0606A43E mov.w 0x0606A4D8,r2
    c.r[1] &= c.r[2];  // 0606A440 and r2,r1
    c.r[1] |= c.r[3];  // 0606A442 or r3,r1
    st16(c.r[10], c.r[1]);  // 0606A444 mov.w r1,@r10
L_0606A446:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A446 mov.b @r10,r3
    c.r[0] = c.r[3];  // 0606A448 mov r3,r0
    c.r[0] >>= 2;  // 0606A44A shlr2 r0
    c.r[0] &= 0x3u;  // 0606A44C and #3,r0
    c.t = c.r[0] == 0x1u;  // 0606A44E cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606A470; } }  // 0606A450 bt/s 0x0606A470 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0606A454 mov.w @r10,r1
    c.r[0] = c.r[1];  // 0606A456 mov r1,r0
    c.r[0] >>= 2;  // 0606A458 shlr2 r0
    c.r[0] >>= 2;  // 0606A45A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A45C shlr r0
    c.r[0] >>= 2;  // 0606A45E shlr2 r0
    c.r[0] &= 0x3u;  // 0606A460 and #3,r0
    c.r[0] -= 1;  // 0606A462 add #-1,r0
    c.r[2] = c.r[0] & 0xFFFFu;  // 0606A464 extu.w r0,r2
    c.r[1] = 0x1u;  // 0606A466 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0606A468 cmp/hi r1,r2
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0606A478; } }  // 0606A46A bt/s 0x0606A478 ; tst r9,r9
    c.r[0] = c.r[3];  // 0606A46E mov r3,r0
L_0606A470:
    c.r[0] &= 0xBFu;  // 0606A470 and #191,r0
    st8(c.r[10], c.r[0]);  // 0606A472 mov.b r0,@r10
    c.r[9] = 0x0u;  // 0606A474 mov #0,r9
L_0606A476:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0606A476 tst r9,r9
L_0606A478:
    { const bool k = c.t; c.r[1] = 0x9u; if (k) { goto L_0606A482; } }  // 0606A478 bt/s 0x0606A482 ; mov #9,r1
    c.t = c.r[9] > c.r[1];  // 0606A47C cmp/hi r1,r9
    if (c.t) { goto L_0606A482; }  // 0606A47E bt 0x0606A482
    c.r[9] = 0xAu;  // 0606A480 mov #10,r9
L_0606A482:
    c.r[1] = ld32(0x0606A4F0u);  // 0606A482 mov.l 0x0606A4F0,r1
    c.r[0] = c.r[11];  // 0606A484 mov r11,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A486 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606A488 extu.b r2,r2
    c.r[1] = ld32(0x0606A4F4u);  // 0606A48A mov.l 0x0606A4F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606A48C mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A48E shll2 r2
    c.r[2] <<= 2;  // 0606A490 shll2 r2
    c.r[2] += c.r[1];  // 0606A492 add r1,r2
    c.r[2] += 10;  // 0606A494 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A496 mov.b @r2,r1
    c.r[13] = 0x1u;  // 0606A498 mov #1,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606A49A shlr r1
    c.r[1] &= c.r[13];  // 0606A49C and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A49E tst r1,r1
    if (c.t) { goto L_0606A518; }  // 0606A4A0 bt 0x0606A518
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4E0u);  // 0606A4A2 mov.w 0x0606A4E0,r0
    c.r[0] += c.r[14];  // 0606A4A4 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606A4A6 mov.l @r0,r13
    c.r[13] += 18;  // 0606A4A8 add #18,r13
    st32(c.r[0], c.r[13]);  // 0606A4AA mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A4AC mov.w 0x0606A4D4,r0
    c.r[0] += c.r[14];  // 0606A4AE add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606A4B0 mov.l @r0,r13
    c.r[13] += 18;  // 0606A4B2 add #18,r13
    st32(c.r[0], c.r[13]);  // 0606A4B4 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4E0u);  // 0606A4B6 mov.w 0x0606A4E0,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0606A4B8 mov.l @(r0,r14),r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A4BA mov.w 0x0606A4D4,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0606A4BC mov.w @r13,r2
    c.r[0] += c.r[14];  // 0606A4BE add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606A4C0 mov.l @r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0606A4C2 mov.w @r13,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606A4C4 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A4C6 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 0606A4C8 cmp/hi r1,r2
    if (!c.t) { goto L_0606A518; }  // 0606A4CA bf 0x0606A518
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D6u);  // 0606A4CC mov.w 0x0606A4D6,r0
    c.r[0] += c.r[14]; goto L_0606A4F8;  // 0606A4CE bra 0x0606A4F8 ; add r14,r0
L_0606A4F8:
    c.r[1] = ld32(c.r[0]);  // 0606A4F8 mov.l @r0,r1
    c.r[1] += 22;  // 0606A4FA add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A4FC mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0606A4FE extu.w r1,r3
    c.r[2] = c.r[3];  // 0606A500 mov r3,r2
    c.r[2] -= c.r[9];  // 0606A502 sub r9,r2
    c.r[1] = 0x9u;  // 0606A504 mov #9,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606A506 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0xAu; if (k) { goto L_0606A518; } }  // 0606A508 bt/s 0x0606A518 ; mov #10,r1
    c.t = c.r[3] > c.r[1];  // 0606A50C cmp/hi r1,r3
    { const bool k = c.t; c.r[9] = c.r[3]; if (k) { goto L_0606A516; } }  // 0606A50E bt/s 0x0606A516 ; mov r3,r9
    c.r[9] = 0x0u; goto L_0606A518;  // 0606A512 bra 0x0606A518 ; mov #0,r9
L_0606A516:
    c.r[9] -= 10;  // 0606A516 add #-10,r9
L_0606A518:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A560u);  // 0606A518 mov.w 0x0606A560,r13
    c.r[13] += c.r[14];  // 0606A51A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0606A51C mov.l @r13,r0
    c.r[0] += 22;  // 0606A51E add #22,r0
    st32(c.r[13], c.r[0]);  // 0606A520 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A560u);  // 0606A522 mov.w 0x0606A560,r13
    c.r[13] += c.r[14];  // 0606A524 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0606A526 mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0606A528 mov.w @r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A52A extu.w r1,r1
    c.t = c.r[9] > c.r[1];  // 0606A52C cmp/hi r1,r9
    if (!c.t) { goto L_0606A532; }  // 0606A52E bf 0x0606A532
    c.r[9] = c.r[1];  // 0606A530 mov r1,r9
L_0606A532:
    c.t = c.r[1] > c.r[9];  // 0606A532 cmp/hi r9,r1
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_0606A53E; } }  // 0606A534 bt/s 0x0606A53E ; mov r10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A538 mov.b @r10,r0
    c.r[0] |= 0x10u;  // 0606A53A or #16,r0
    st8(c.r[10], c.r[0]);  // 0606A53C mov.b r0,@r10
L_0606A53E:
    c.r[2] += 2;  // 0606A53E add #2,r2
    c.r[10] += 4;  // 0606A540 add #4,r10
    c.r[1] = c.r[9];  // 0606A542 mov r9,r1
    st16(c.r[10], c.r[1]);  // 0606A544 mov.w r1,@r10
    st16(c.r[2], c.r[1]);  // 0606A546 mov.w r1,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606A562u);  // 0606A548 mov.w 0x0606A562,r3
    c.r[14] += c.r[3];  // 0606A54A add r3,r14
    c.r[15] = c.r[14];  // 0606A54C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606A54E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606A550 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606A552 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606A554 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606A556 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606A558 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606A55A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606A55C rts ; mov.l @r15+,r8
}

void f_0606A098(SH2Context& c) {
    ran[1525] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606A098 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606A09A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606A09C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606A09E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606A0A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606A0A2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606A0A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606A0A6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606A1D2u);  // 0606A0A8 mov.w 0x0606A1D2,r3
    c.r[15] += c.r[3];  // 0606A0AA add r3,r15
    c.r[14] = c.r[15];  // 0606A0AC mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D4u);  // 0606A0AE mov.w 0x0606A1D4,r0
    st32(c.r[0] + c.r[14], c.r[5]);  // 0606A0B0 mov.l r5,@(r0,r14)
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1D6u);  // 0606A0B2 mov.w 0x0606A1D6,r13
    c.r[13] += c.r[14];  // 0606A0B4 add r14,r13
    c.r[11] = c.r[6] & 0xFFu;  // 0606A0B6 extu.b r6,r11
    c.r[12] = c.r[7] & 0xFFu;  // 0606A0B8 extu.b r7,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D8u);  // 0606A0BA mov.w 0x0606A1D8,r0
    c.r[0] += c.r[14];  // 0606A0BC add r14,r0
    c.r[1] = ld32(c.r[13]);  // 0606A0BE mov.l @r13,r1
    c.r[3] = ld32(0x0606A1E8u);  // 0606A0C0 mov.l 0x0606A1E8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606A0C2 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0606A0C4 mov.l r1,@r0
    c.r[0] = c.r[11];  // 0606A0C6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A0C8 mov.b @(r0,r3),r1
    c.r[2] = ld32(0x0606A1ECu);  // 0606A0CA mov.l 0x0606A1EC,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0606A0CC extu.b r1,r6
    c.r[0] = c.r[12];  // 0606A0CE mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606A0D0 mov.b @(r0,r2),r1
    c.r[10] = c.r[4];  // 0606A0D2 mov r4,r10
    c.r[5] = c.r[1] & 0xFFu;  // 0606A0D4 extu.b r1,r5
    c.r[0] = c.r[11];  // 0606A0D6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606A0D8 mov.b @(r0,r2),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606A0DA extu.b r1,r7
    c.r[0] = c.r[12];  // 0606A0DC mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A0DE mov.b @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A1DAu);  // 0606A0E0 mov.w 0x0606A1DA,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A0E2 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606A0E4 cmp/eq r2,r1
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0606A0F0; } }  // 0606A0E6 bf/s 0x0606A0F0 ; mov #0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DCu);  // 0606A0EA mov.w 0x0606A1DC,r1
    c.r[1] |= c.r[7]; goto L_0606A0F2;  // 0606A0EC bra 0x0606A0F2 ; or r7,r1
L_0606A0F0:
    c.r[1] = c.r[7] & 0xFFu;  // 0606A0F0 extu.b r7,r1
L_0606A0F2:
    c.r[13] = ld32(0x0606A1F0u);  // 0606A0F2 mov.l 0x0606A1F0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A0F8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A0F8u) return; }  // 0606A0F4 jsr @r13 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606A0F8 mov r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0606A0FA extu.b r1,r5
    c.r[0] = ld32(0x0606A1ECu);  // 0606A0FC mov.l 0x0606A1EC,r0
    c.r[1] = ld32(0x0606A1F4u);  // 0606A0FE mov.l 0x0606A1F4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606A100 mov.b @(r0,r11),r2
    c.r[13] = 0x3u;  // 0606A102 mov #3,r13
    c.r[1] = ld32(c.r[1]);  // 0606A104 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606A106 extu.b r2,r2
    c.r[2] <<= 2;  // 0606A108 shll2 r2
    c.r[2] <<= 2;  // 0606A10A shll2 r2
    c.r[2] += c.r[1];  // 0606A10C add r1,r2
    c.r[2] += 3;  // 0606A10E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A110 mov.b @r2,r1
    c.r[0] = ld32(0x0606A1F8u);  // 0606A112 mov.l 0x0606A1F8,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606A114 shlr r1
    c.r[1] &= c.r[13];  // 0606A116 and r13,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0606A11Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A11Cu) return; }  // 0606A118 jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606A11C mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A11E tst r1,r1
    { const bool k = !c.t; c.r[13] = 0x40u; if (k) { goto L_0606A136; } }  // 0606A120 bf/s 0x0606A136 ; mov #64,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D8u);  // 0606A124 mov.w 0x0606A1D8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A126 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DEu);  // 0606A128 mov.w 0x0606A1DE,r1
    c.t = c.r[0] == c.r[1];  // 0606A12A cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0606A134; } }  // 0606A12C bf/s 0x0606A134 ; mov r10,r2
    goto L_0606A53E;  // 0606A130 bra 0x0606A53E ; nop
L_0606A134:
    c.r[13] = 0x40u;  // 0606A134 mov #64,r13
L_0606A136:
    c.r[8] = ld32(0x0606A1E8u);  // 0606A136 mov.l 0x0606A1E8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A138 mov.b @r10,r1
    c.r[0] = c.r[11];  // 0606A13A mov r11,r0
    c.r[1] |= c.r[13];  // 0606A13C or r13,r1
    st8(c.r[10], c.r[1]);  // 0606A13E mov.b r1,@r10
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1E0u);  // 0606A140 mov.w 0x0606A1E0,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A142 mov.b @(r0,r8),r7
    c.r[13] += c.r[14];  // 0606A144 add r14,r13
    c.r[0] = ld32(0x0606A1ECu);  // 0606A146 mov.l 0x0606A1EC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606A148 mov.b @(r0,r11),r1
    c.r[7] = c.r[7] & 0xFFu;  // 0606A14A extu.b r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606A14C extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606A14E mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1E2u);  // 0606A150 mov.w 0x0606A1E2,r0
    c.r[6] = ld32(c.r[13]);  // 0606A152 mov.l @r13,r6
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 0606A154 mov.l @(r0,r14),r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1E4u);  // 0606A156 mov.w 0x0606A1E4,r13
    c.r[13] += c.r[14];  // 0606A158 add r14,r13
    c.r[0] = ld32(0x0606A1FCu);  // 0606A15A mov.l 0x0606A1FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606A160u; c.r[4] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A160u) return; }  // 0606A15C jsr @r0 ; mov.l @r13,r4
    c.r[1] = c.r[0];  // 0606A160 mov r0,r1
    c.r[2] = 0x1u;  // 0606A162 mov #1,r2
    c.r[2] &= c.r[1];  // 0606A164 and r1,r2
    c.r[2] <<= 2;  // 0606A166 shll2 r2
    c.r[2] += c.r[2];  // 0606A168 add r2,r2
    c.r[2] <<= 2;  // 0606A16A shll2 r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A1E6u);  // 0606A16C mov.w 0x0606A1E6,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A16E mov.b @r10,r1
    c.r[0] = c.r[11];  // 0606A170 mov r11,r0
    c.r[1] &= c.r[13];  // 0606A172 and r13,r1
    c.r[1] |= c.r[2];  // 0606A174 or r2,r1
    st8(c.r[10], c.r[1]);  // 0606A176 mov.b r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A178 mov.b @(r0,r8),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0606A17A extu.b r1,r6
    c.r[0] = ld32(0x0606A1ECu);  // 0606A17C mov.l 0x0606A1EC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606A17E mov.b @(r0,r12),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606A180 extu.b r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A1D8u);  // 0606A182 mov.w 0x0606A1D8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A184 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DEu);  // 0606A186 mov.w 0x0606A1DE,r1
    c.t = c.r[0] == c.r[1];  // 0606A188 cmp/eq r1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0606A194; } }  // 0606A18A bt/s 0x0606A194 ; add #4,r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A1DCu);  // 0606A18E mov.w 0x0606A1DC,r1
    c.r[1] |= c.r[2]; goto L_0606A196;  // 0606A190 bra 0x0606A196 ; or r2,r1
L_0606A194:
    c.r[1] = c.r[2] & 0xFFu;  // 0606A194 extu.b r2,r1
L_0606A196:
    c.r[8] = ld32(0x0606A1ECu);  // 0606A196 mov.l 0x0606A1EC,r8
    c.r[0] = c.r[11];  // 0606A198 mov r11,r0
    c.r[5] = c.r[1];  // 0606A19A mov r1,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A19C mov.b @(r0,r8),r4
    c.r[13] = ld32(0x0606A200u);  // 0606A19E mov.l 0x0606A200,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A1A4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A1A4u) return; }  // 0606A1A0 jsr @r13 ; extu.b r4,r4
    c.r[9] = c.r[0];  // 0606A1A4 mov r0,r9
    c.r[0] = c.r[11];  // 0606A1A6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A1A8 mov.b @(r0,r8),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606A1AA extu.b r1,r2
    c.r[1] = ld32(0x0606A1F4u);  // 0606A1AC mov.l 0x0606A1F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606A1AE mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A1B0 shll2 r2
    c.r[2] <<= 2;  // 0606A1B2 shll2 r2
    c.r[2] += c.r[1];  // 0606A1B4 add r1,r2
    c.r[1] = c.r[2];  // 0606A1B6 mov r2,r1
    c.r[1] += 11;  // 0606A1B8 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A1BA mov.b @r1,r1
    c.r[13] = 0x1u;  // 0606A1BC mov #1,r13
    c.r[1] >>= 2;  // 0606A1BE shlr2 r1
    c.r[1] >>= 2;  // 0606A1C0 shlr2 r1
    c.r[1] &= c.r[13];  // 0606A1C2 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A1C4 tst r1,r1
    { const bool k = c.t; c.r[2] += 10; if (k) { goto L_0606A204; } }  // 0606A1C6 bt/s 0x0606A204 ; add #10,r2
    c.r[1] = c.r[9];  // 0606A1CA mov r9,r1
    c.r[1] += c.r[1];  // 0606A1CC add r1,r1
    c.r[9] += c.r[1]; goto L_0606A216;  // 0606A1CE bra 0x0606A216 ; add r1,r9
L_0606A204:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A204 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606A206 mov r1,r0
    c.r[0] >>= 2;  // 0606A208 shlr2 r0
    c.r[0] >>= 2;  // 0606A20A shlr2 r0
    c.r[0] >>= 2;  // 0606A20C shlr2 r0
    c.r[0] &= 0x1u;  // 0606A20E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A210 tst r0,r0
    if (c.t) { goto L_0606A216; }  // 0606A212 bt 0x0606A216
    c.r[9] += c.r[9];  // 0606A214 add r9,r9
L_0606A216:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A216 mov.b @r10,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606A218 extu.b r1,r3
    c.r[0] = c.r[3];  // 0606A21A mov r3,r0
    c.r[0] >>= 2;  // 0606A21C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A21E shlr r0
    c.r[0] >>= 2;  // 0606A220 shlr2 r0
    c.r[0] &= 0x1u;  // 0606A222 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A224 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606A23C; } }  // 0606A226 bt/s 0x0606A23C ; mov r3,r0
    c.r[1] = 0xFu;  // 0606A22A mov #15,r1
    c.macl = c.r[9] * c.r[1];  // 0606A22C mul.l r1,r9
    c.r[1] = ld32(0x0606A358u);  // 0606A22E mov.l 0x0606A358,r1
    c.r[1] = ld32(c.r[1]);  // 0606A230 mov.l @r1,r1
    c.r[2] = c.macl;  // 0606A232 sts macl,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0606A234 dmulu.l r1,r2
    c.r[9] = c.mach;  // 0606A236 sts mach,r9
    c.r[9] >>= 2;  // 0606A238 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0606A23A shlr r9
L_0606A23C:
    c.r[0] >>= 2;  // 0606A23C shlr2 r0
    c.r[0] &= 0x3u;  // 0606A23E and #3,r0
    c.t = c.r[0] == 0x2u;  // 0606A240 cmp/eq #2,r0
    if (!c.t) { goto L_0606A246; }  // 0606A242 bf 0x0606A246
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0606A244 shlr r9
L_0606A246:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A34Au);  // 0606A246 mov.w 0x0606A34A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A248 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A34Cu);  // 0606A24A mov.w 0x0606A34C,r1
    c.t = c.r[0] == c.r[1];  // 0606A24C cmp/eq r1,r0
    { const bool k = c.t; c.r[4] = c.r[14]; if (k) { goto L_0606A274; } }  // 0606A24E bt/s 0x0606A274 ; mov r14,r4
    c.r[1] = ld32(0x0606A35Cu);  // 0606A252 mov.l 0x0606A35C,r1
    c.r[0] = c.r[12];  // 0606A254 mov r12,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A256 mov.b @(r0,r1),r6
    c.r[6] = c.r[6] & 0xFFu;  // 0606A258 extu.b r6,r6
    c.r[1] = ld32(0x0606A360u);  // 0606A25A mov.l 0x0606A360,r1
    c.r[2] = c.r[6];  // 0606A25C mov r6,r2
    c.r[1] = ld32(c.r[1]);  // 0606A25E mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A260 shll2 r2
    c.r[2] <<= 2;  // 0606A262 shll2 r2
    c.r[2] += c.r[1];  // 0606A264 add r1,r2
    c.r[2] += 2;  // 0606A266 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A268 mov.b @r2,r5
    c.r[1] = ld32(0x0606A364u);  // 0606A26A mov.l 0x0606A364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A270u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A270u) return; }  // 0606A26C jsr @r1 ; extu.b r5,r5
    goto L_0606A280;  // 0606A270 bra 0x0606A280 ; nop
L_0606A274:
    c.r[1] = ld32(0x0606A368u);  // 0606A274 mov.l 0x0606A368,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A34Eu);  // 0606A276 mov.w 0x0606A34E,r13
    c.r[13] += c.r[14];  // 0606A278 add r14,r13
    c.r[5] = ld32(c.r[13]);  // 0606A27A mov.l @r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606A280u; c.r[6] = 0x5Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A280u) return; }  // 0606A27C jsr @r1 ; mov #93,r6
L_0606A280:
    c.r[1] = ld32(0x0606A36Cu);  // 0606A280 mov.l 0x0606A36C,r1
    c.r[0] = c.r[12];  // 0606A282 mov r12,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A34Eu);  // 0606A284 mov.w 0x0606A34E,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A286 mov.b @(r0,r1),r7
    c.r[13] += c.r[14];  // 0606A288 add r14,r13
    c.r[0] = c.r[11];  // 0606A28A mov r11,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A28C mov.b @(r0,r1),r5
    c.r[7] = c.r[7] & 0xFFu;  // 0606A28E extu.b r7,r7
    c.r[5] = c.r[5] & 0xFFu;  // 0606A290 extu.b r5,r5
    c.r[1] = 0x0u;  // 0606A292 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606A294 mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A350u);  // 0606A296 mov.w 0x0606A350,r0
    c.r[6] = ld32(c.r[13]);  // 0606A298 mov.l @r13,r6
    c.r[0] += c.r[14];  // 0606A29A add r14,r0
    c.r[13] = ld32(0x0606A370u);  // 0606A29C mov.l 0x0606A370,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A2A2u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A2A2u) return; }  // 0606A29E jsr @r13 ; mov.l @r0,r4
    c.r[3] = c.r[0];  // 0606A2A2 mov r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606A2A4 tst r3,r3
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0606A378; } }  // 0606A2A6 bt/s 0x0606A378 ; add #4,r15
    c.t = (c.r[11] & c.r[11]) == 0;  // 0606A2AA tst r11,r11
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606A2C2; } }  // 0606A2AC bt/s 0x0606A2C2 ; mov r3,r1
    c.r[1] = ld32(0x0606A374u);  // 0606A2B0 mov.l 0x0606A374,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A2B2 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606A2B4 mov #1,r0
    c.r[1] >>= 2;  // 0606A2B6 shlr2 r1
    c.r[1] >>= 2;  // 0606A2B8 shlr2 r1
    c.r[1] &= c.r[0];  // 0606A2BA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A2BC tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606A378; } }  // 0606A2BE bf/s 0x0606A378 ; mov r3,r1
L_0606A2C2:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2C8 shar r1
    c.t = c.r[9] > c.r[1];  // 0606A2CA cmp/hi r1,r9
    { const bool k = !c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0606A2F4; } }  // 0606A2CC bf/s 0x0606A2F4 ; mov.b @r10,r1
    c.r[13] = 0x2u;  // 0606A2D0 mov #2,r13
    c.r[1] |= c.r[13];  // 0606A2D2 or r13,r1
    st8(c.r[10], c.r[1]);  // 0606A2D4 mov.b r1,@r10
    c.r[1] = 0xFu;  // 0606A2D6 mov #15,r1
    c.r[1] &= c.r[3];  // 0606A2D8 and r3,r1
    c.r[0] = c.r[1];  // 0606A2DA mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0606A2DC cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606A2E8; } }  // 0606A2DE bt/s 0x0606A2E8 ; mov r3,r1
    c.t = c.r[0] == 0x8u;  // 0606A2E2 cmp/eq #8,r0
    { const bool k = !c.t; c.r[0] = 0xFu; if (k) { goto L_0606A2FE; } }  // 0606A2E4 bf/s 0x0606A2FE ; mov #15,r0
L_0606A2E8:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2E8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2EA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2EC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606A2EE shar r1
    c.r[9] -= c.r[1]; goto L_0606A2FC;  // 0606A2F0 bra 0x0606A2FC ; sub r1,r9
L_0606A2F4:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A352u);  // 0606A2F4 mov.w 0x0606A352,r13
    c.r[9] = 0x0u;  // 0606A2F6 mov #0,r9
    c.r[1] &= c.r[13];  // 0606A2F8 and r13,r1
    st8(c.r[10], c.r[1]);  // 0606A2FA mov.b r1,@r10
L_0606A2FC:
    c.r[0] = 0xFu;  // 0606A2FC mov #15,r0
L_0606A2FE:
    c.r[3] &= c.r[0];  // 0606A2FE and r0,r3
    c.r[1] = 0x7u;  // 0606A300 mov #7,r1
    c.r[2] = c.r[3];  // 0606A302 mov r3,r2
    c.r[2] -= 1;  // 0606A304 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0606A306 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606A32E; } }  // 0606A308 bt/s 0x0606A32E ; mov r2,r1
    c.r[1] += c.r[1];  // 0606A30C add r1,r1
    c.r[0] = 0x0606A318u;  // 0606A30E mova 0x0606A318,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606A310 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0606A312 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0606A32Cu: goto L_0606A32C; case 0x0606A328u: goto L_0606A328; default: sh2_call(c, x); return; } }  // 0606A314 jmp @r0 ; nop
L_0606A328:
    c.r[3] = 0x0u; goto L_0606A32E;  // 0606A328 bra 0x0606A32E ; mov #0,r3
L_0606A32C:
    c.r[3] = 0x5u;  // 0606A32C mov #5,r3
L_0606A32E:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A354u);  // 0606A32E mov.w 0x0606A354,r13
    c.r[13] += c.r[14];  // 0606A330 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A354u);  // 0606A332 mov.w 0x0606A354,r0
    c.r[1] = ld32(c.r[13]);  // 0606A334 mov.l @r13,r1
    c.r[0] += c.r[14];  // 0606A336 add r14,r0
    c.r[1] += 27;  // 0606A338 add #27,r1
    st8(c.r[1], c.r[3]);  // 0606A33A mov.b r3,@r1
    c.r[13] = ld32(c.r[0]);  // 0606A33C mov.l @r0,r13
    c.r[13] += 26;  // 0606A33E add #26,r13
    st32(c.r[0], c.r[13]);  // 0606A340 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A354u);  // 0606A342 mov.w 0x0606A354,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0606A344 mov.l @(r0,r14),r13
    st8(c.r[13], c.r[3]); goto L_0606A3C4;  // 0606A346 bra 0x0606A3C4 ; mov.b r3,@r13
L_0606A378:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A378 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0606A37A mov r1,r0
    c.r[0] >>= 2;  // 0606A37C shlr2 r0
    c.r[0] &= 0x3u;  // 0606A37E and #3,r0
    c.t = c.r[0] == 0x2u;  // 0606A380 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_0606A3C4; } }  // 0606A382 bt/s 0x0606A3C4 ; mov r12,r0
    c.r[1] = ld32(0x0606A4E4u);  // 0606A386 mov.l 0x0606A4E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A388 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D2u);  // 0606A38A mov.w 0x0606A4D2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A38C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606A38E cmp/eq r2,r1
    if (c.t) { goto L_0606A3C4; }  // 0606A390 bt 0x0606A3C4
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A392 mov.w 0x0606A4D4,r13
    c.r[13] += c.r[14];  // 0606A394 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D6u);  // 0606A396 mov.w 0x0606A4D6,r0
    c.r[5] = ld32(c.r[13]);  // 0606A398 mov.l @r13,r5
    c.r[0] += c.r[14];  // 0606A39A add r14,r0
    c.r[13] = ld32(0x0606A4E8u);  // 0606A39C mov.l 0x0606A4E8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606A3A2u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A3A2u) return; }  // 0606A39E jsr @r13 ; mov.l @r0,r4
    c.r[1] = c.r[0];  // 0606A3A2 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606A3A4 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606A3A6 tst r3,r3
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_0606A3C4; } }  // 0606A3A8 bt/s 0x0606A3C4 ; add #2,r3
    c.r[0] = 0x3u;  // 0606A3AC mov #3,r0
    c.r[3] &= c.r[0];  // 0606A3AE and r0,r3
    c.r[3] <<= 2;  // 0606A3B0 shll2 r3
    c.r[3] <<= 2;  // 0606A3B2 shll2 r3
    c.r[3] += c.r[3];  // 0606A3B4 add r3,r3
    c.r[3] <<= 2;  // 0606A3B6 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0606A3B8 mov.w @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D8u);  // 0606A3BA mov.w 0x0606A4D8,r2
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0606A3BC shlr r9
    c.r[1] &= c.r[2];  // 0606A3BE and r2,r1
    c.r[1] |= c.r[3];  // 0606A3C0 or r3,r1
    st16(c.r[10], c.r[1]);  // 0606A3C2 mov.w r1,@r10
L_0606A3C4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4DAu);  // 0606A3C4 mov.w 0x0606A4DA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606A3C6 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A4DCu);  // 0606A3C8 mov.w 0x0606A4DC,r1
    c.t = c.r[0] == c.r[1];  // 0606A3CA cmp/eq r1,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0606A476; } }  // 0606A3CC bf/s 0x0606A476 ; mov r12,r0
    c.r[3] = ld32(0x0606A4E4u);  // 0606A3D0 mov.l 0x0606A4E4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A3D2 mov.b @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D2u);  // 0606A3D4 mov.w 0x0606A4D2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A3D6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606A3D8 cmp/eq r2,r1
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0606A478; } }  // 0606A3DA bt/s 0x0606A478 ; tst r9,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A3DE mov.b @r10,r1
    c.r[0] = c.r[1];  // 0606A3E0 mov r1,r0
    c.r[0] >>= 2;  // 0606A3E2 shlr2 r0
    c.r[0] &= 0x3u;  // 0606A3E4 and #3,r0
    c.t = c.r[0] == 0x1u;  // 0606A3E6 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A446; } }  // 0606A3E8 bt/s 0x0606A446 ; mov r11,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A3EC mov.w 0x0606A4D4,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A3EE mov.b @(r0,r3),r7
    c.r[13] += c.r[14];  // 0606A3F0 add r14,r13
    c.r[6] = ld32(c.r[13]);  // 0606A3F2 mov.l @r13,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0606A3F4 extu.b r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D6u);  // 0606A3F6 mov.w 0x0606A4D6,r0
    c.r[0] += c.r[14];  // 0606A3F8 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A4DEu);  // 0606A3FA mov.w 0x0606A4DE,r13
    c.r[5] = ld32(c.r[0]);  // 0606A3FC mov.l @r0,r5
    c.r[13] += c.r[14];  // 0606A3FE add r14,r13
    c.r[0] = ld32(0x0606A4ECu);  // 0606A400 mov.l 0x0606A4EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606A406u; c.r[4] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A406u) return; }  // 0606A402 jsr @r0 ; mov.l @r13,r4
    c.r[1] = c.r[0];  // 0606A406 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606A408 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606A40A tst r3,r3
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A446; } }  // 0606A40C bt/s 0x0606A446 ; mov r11,r0
    c.r[1] = ld32(0x0606A4F0u);  // 0606A410 mov.l 0x0606A4F0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A412 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606A414 extu.b r2,r2
    c.r[1] = ld32(0x0606A4F4u);  // 0606A416 mov.l 0x0606A4F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606A418 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A41A shll2 r2
    c.r[2] <<= 2;  // 0606A41C shll2 r2
    c.r[2] += c.r[1];  // 0606A41E add r1,r2
    c.r[2] += 10;  // 0606A420 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A422 mov.b @r2,r1
    c.r[13] = 0x1u;  // 0606A424 mov #1,r13
    c.r[1] >>= 2;  // 0606A426 shlr2 r1
    c.r[1] >>= 2;  // 0606A428 shlr2 r1
    c.r[1] &= c.r[13];  // 0606A42A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A42C tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_0606A446; } }  // 0606A42E bf/s 0x0606A446 ; mov #3,r0
    c.r[3] &= c.r[0];  // 0606A432 and r0,r3
    c.r[3] <<= 2;  // 0606A434 shll2 r3
    c.r[3] <<= 2;  // 0606A436 shll2 r3
    c.r[3] += c.r[3];  // 0606A438 add r3,r3
    c.r[3] <<= 2;  // 0606A43A shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0606A43C mov.w @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606A4D8u);  // 0606A43E mov.w 0x0606A4D8,r2
    c.r[1] &= c.r[2];  // 0606A440 and r2,r1
    c.r[1] |= c.r[3];  // 0606A442 or r3,r1
    st16(c.r[10], c.r[1]);  // 0606A444 mov.w r1,@r10
L_0606A446:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A446 mov.b @r10,r3
    c.r[0] = c.r[3];  // 0606A448 mov r3,r0
    c.r[0] >>= 2;  // 0606A44A shlr2 r0
    c.r[0] &= 0x3u;  // 0606A44C and #3,r0
    c.t = c.r[0] == 0x1u;  // 0606A44E cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606A470; } }  // 0606A450 bt/s 0x0606A470 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0606A454 mov.w @r10,r1
    c.r[0] = c.r[1];  // 0606A456 mov r1,r0
    c.r[0] >>= 2;  // 0606A458 shlr2 r0
    c.r[0] >>= 2;  // 0606A45A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A45C shlr r0
    c.r[0] >>= 2;  // 0606A45E shlr2 r0
    c.r[0] &= 0x3u;  // 0606A460 and #3,r0
    c.r[0] -= 1;  // 0606A462 add #-1,r0
    c.r[2] = c.r[0] & 0xFFFFu;  // 0606A464 extu.w r0,r2
    c.r[1] = 0x1u;  // 0606A466 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0606A468 cmp/hi r1,r2
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0606A478; } }  // 0606A46A bt/s 0x0606A478 ; tst r9,r9
    c.r[0] = c.r[3];  // 0606A46E mov r3,r0
L_0606A470:
    c.r[0] &= 0xBFu;  // 0606A470 and #191,r0
    st8(c.r[10], c.r[0]);  // 0606A472 mov.b r0,@r10
    c.r[9] = 0x0u;  // 0606A474 mov #0,r9
L_0606A476:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0606A476 tst r9,r9
L_0606A478:
    { const bool k = c.t; c.r[1] = 0x9u; if (k) { goto L_0606A482; } }  // 0606A478 bt/s 0x0606A482 ; mov #9,r1
    c.t = c.r[9] > c.r[1];  // 0606A47C cmp/hi r1,r9
    if (c.t) { goto L_0606A482; }  // 0606A47E bt 0x0606A482
    c.r[9] = 0xAu;  // 0606A480 mov #10,r9
L_0606A482:
    c.r[1] = ld32(0x0606A4F0u);  // 0606A482 mov.l 0x0606A4F0,r1
    c.r[0] = c.r[11];  // 0606A484 mov r11,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A486 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606A488 extu.b r2,r2
    c.r[1] = ld32(0x0606A4F4u);  // 0606A48A mov.l 0x0606A4F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606A48C mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A48E shll2 r2
    c.r[2] <<= 2;  // 0606A490 shll2 r2
    c.r[2] += c.r[1];  // 0606A492 add r1,r2
    c.r[2] += 10;  // 0606A494 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A496 mov.b @r2,r1
    c.r[13] = 0x1u;  // 0606A498 mov #1,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606A49A shlr r1
    c.r[1] &= c.r[13];  // 0606A49C and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A49E tst r1,r1
    if (c.t) { goto L_0606A518; }  // 0606A4A0 bt 0x0606A518
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4E0u);  // 0606A4A2 mov.w 0x0606A4E0,r0
    c.r[0] += c.r[14];  // 0606A4A4 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606A4A6 mov.l @r0,r13
    c.r[13] += 18;  // 0606A4A8 add #18,r13
    st32(c.r[0], c.r[13]);  // 0606A4AA mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A4AC mov.w 0x0606A4D4,r0
    c.r[0] += c.r[14];  // 0606A4AE add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606A4B0 mov.l @r0,r13
    c.r[13] += 18;  // 0606A4B2 add #18,r13
    st32(c.r[0], c.r[13]);  // 0606A4B4 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4E0u);  // 0606A4B6 mov.w 0x0606A4E0,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0606A4B8 mov.l @(r0,r14),r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D4u);  // 0606A4BA mov.w 0x0606A4D4,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0606A4BC mov.w @r13,r2
    c.r[0] += c.r[14];  // 0606A4BE add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606A4C0 mov.l @r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0606A4C2 mov.w @r13,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606A4C4 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A4C6 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 0606A4C8 cmp/hi r1,r2
    if (!c.t) { goto L_0606A518; }  // 0606A4CA bf 0x0606A518
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A4D6u);  // 0606A4CC mov.w 0x0606A4D6,r0
    c.r[0] += c.r[14]; goto L_0606A4F8;  // 0606A4CE bra 0x0606A4F8 ; add r14,r0
L_0606A4F8:
    c.r[1] = ld32(c.r[0]);  // 0606A4F8 mov.l @r0,r1
    c.r[1] += 22;  // 0606A4FA add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A4FC mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0606A4FE extu.w r1,r3
    c.r[2] = c.r[3];  // 0606A500 mov r3,r2
    c.r[2] -= c.r[9];  // 0606A502 sub r9,r2
    c.r[1] = 0x9u;  // 0606A504 mov #9,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606A506 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0xAu; if (k) { goto L_0606A518; } }  // 0606A508 bt/s 0x0606A518 ; mov #10,r1
    c.t = c.r[3] > c.r[1];  // 0606A50C cmp/hi r1,r3
    { const bool k = c.t; c.r[9] = c.r[3]; if (k) { goto L_0606A516; } }  // 0606A50E bt/s 0x0606A516 ; mov r3,r9
    c.r[9] = 0x0u; goto L_0606A518;  // 0606A512 bra 0x0606A518 ; mov #0,r9
L_0606A516:
    c.r[9] -= 10;  // 0606A516 add #-10,r9
L_0606A518:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A560u);  // 0606A518 mov.w 0x0606A560,r13
    c.r[13] += c.r[14];  // 0606A51A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0606A51C mov.l @r13,r0
    c.r[0] += 22;  // 0606A51E add #22,r0
    st32(c.r[13], c.r[0]);  // 0606A520 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606A560u);  // 0606A522 mov.w 0x0606A560,r13
    c.r[13] += c.r[14];  // 0606A524 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0606A526 mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0606A528 mov.w @r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A52A extu.w r1,r1
    c.t = c.r[9] > c.r[1];  // 0606A52C cmp/hi r1,r9
    if (!c.t) { goto L_0606A532; }  // 0606A52E bf 0x0606A532
    c.r[9] = c.r[1];  // 0606A530 mov r1,r9
L_0606A532:
    c.t = c.r[1] > c.r[9];  // 0606A532 cmp/hi r9,r1
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_0606A53E; } }  // 0606A534 bt/s 0x0606A53E ; mov r10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606A538 mov.b @r10,r0
    c.r[0] |= 0x10u;  // 0606A53A or #16,r0
    st8(c.r[10], c.r[0]);  // 0606A53C mov.b r0,@r10
L_0606A53E:
    c.r[2] += 2;  // 0606A53E add #2,r2
    c.r[10] += 4;  // 0606A540 add #4,r10
    c.r[1] = c.r[9];  // 0606A542 mov r9,r1
    st16(c.r[10], c.r[1]);  // 0606A544 mov.w r1,@r10
    st16(c.r[2], c.r[1]);  // 0606A546 mov.w r1,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606A562u);  // 0606A548 mov.w 0x0606A562,r3
    c.r[14] += c.r[3];  // 0606A54A add r3,r14
    c.r[15] = c.r[14];  // 0606A54C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606A54E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606A550 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606A552 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606A554 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606A556 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606A558 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606A55A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606A55C rts ; mov.l @r15+,r8
}

void f_0606A564(SH2Context& c) {
    ran[1526] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606A564 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606A566 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606A568 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606A56A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606A56C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606A56E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606A570 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606A572 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0606A574 mov r4,r8
    c.r[10] = ld32(0x0606A65Cu);  // 0606A576 mov.l 0x0606A65C,r10
    c.r[1] = 0xFFFFFFFFu;  // 0606A578 mov #-1,r1
    st32(c.r[10], c.r[1]);  // 0606A57A mov.l r1,@r10
    c.r[1] = ld32(c.r[8]);  // 0606A57C mov.l @r8,r1
    c.r[14] = c.r[15];  // 0606A57E mov r15,r14
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A580 mov.b @r1,r0
    c.r[0] &= 0x30u;  // 0606A582 and #48,r0
    c.t = c.r[0] == 0x20u;  // 0606A584 cmp/eq #32,r0
    { const bool k = !c.t; c.r[9] = c.r[5]; if (k) { goto L_0606A5D6; } }  // 0606A586 bf/s 0x0606A5D6 ; mov r5,r9
    c.r[12] = ld32(0x0606A660u);  // 0606A58A mov.l 0x0606A660,r12
    c.r[11] = 0x0u;  // 0606A58C mov #0,r11
    c.r[13] = ld32(0x0606A664u);  // 0606A58E mov.l 0x0606A664,r13
    c.r[7] = 0x0u;  // 0606A590 mov #0,r7
    c.r[1] = ld32(c.r[9] + 8);  // 0606A592 mov.l @(8,r9),r1
    c.r[6] = 0x3u;  // 0606A594 mov #3,r6
    c.r[5] = ld32(c.r[12]);  // 0606A596 mov.l @r12,r5
    c.r[1] += 10;  // 0606A598 add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A59A mov.w @r1,r4
    c.r[5] += 20;  // 0606A59C add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606A59E extu.w r4,r4
    { const uint32_t x = c.r[13]; c.pr = 0x0606A5A4u; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A5A4u) return; }  // 0606A5A0 jsr @r13 ; mov.l r11,@-r15
    c.r[0] = c.r[0] & 0xFFu;  // 0606A5A4 extu.b r0,r0
    c.r[1] = 0x1u;  // 0606A5A6 mov #1,r1
    c.t = c.r[0] > c.r[1];  // 0606A5A8 cmp/hi r1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0606A5D6; } }  // 0606A5AA bf/s 0x0606A5D6 ; add #4,r15
    c.r[2] = ld32(c.r[10]);  // 0606A5AE mov.l @r10,r2
    c.r[1] = ld32(0x0606A668u);  // 0606A5B0 mov.l 0x0606A668,r1
    c.r[2] &= c.r[1];  // 0606A5B2 and r1,r2
    c.r[1] = ld32(c.r[9] + 8);  // 0606A5B4 mov.l @(8,r9),r1
    c.r[1] += 6;  // 0606A5B6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A5B8 mov.w @r1,r1
    c.r[7] = 0x0u;  // 0606A5BA mov #0,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A5BC extu.w r1,r1
    c.r[2] |= c.r[1];  // 0606A5BE or r1,r2
    st32(c.r[10], c.r[2]);  // 0606A5C0 mov.l r2,@r10
    c.r[1] = ld32(c.r[9] + 8);  // 0606A5C2 mov.l @(8,r9),r1
    c.r[6] = 0x0u;  // 0606A5C4 mov #0,r6
    c.r[5] = ld32(c.r[12]);  // 0606A5C6 mov.l @r12,r5
    c.r[1] += 10;  // 0606A5C8 add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A5CA mov.w @r1,r4
    c.r[5] += 20;  // 0606A5CC add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606A5CE extu.w r4,r4
    { const uint32_t x = c.r[13]; c.pr = 0x0606A5D4u; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A5D4u) return; }  // 0606A5D0 jsr @r13 ; mov.l r11,@-r15
    c.r[15] += 4;  // 0606A5D4 add #4,r15
L_0606A5D6:
    c.r[1] = ld32(c.r[8] + 4);  // 0606A5D6 mov.l @(4,r8),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A5D8 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606A5DA extu.b r1,r2
    c.r[0] = c.r[2];  // 0606A5DC mov r2,r0
    c.r[0] >>= 2;  // 0606A5DE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A5E0 shlr r0
    c.r[0] >>= 2;  // 0606A5E2 shlr2 r0
    c.r[0] &= 0x1u;  // 0606A5E4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A5E6 tst r0,r0
    if (c.t) { goto L_0606A648; }  // 0606A5E8 bt 0x0606A648
    c.r[1] = ld32(c.r[8]);  // 0606A5EA mov.l @r8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A5EC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606A5EE mov r1,r0
    c.r[0] >>= 2;  // 0606A5F0 shlr2 r0
    c.r[0] >>= 2;  // 0606A5F2 shlr2 r0
    c.r[0] &= 0x1u;  // 0606A5F4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A5F6 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0606A648; } }  // 0606A5F8 bf/s 0x0606A648 ; mov r2,r0
    c.r[0] >>= 2;  // 0606A5FC shlr2 r0
    c.r[0] >>= 2;  // 0606A5FE shlr2 r0
    c.r[8] = 0x1u;  // 0606A600 mov #1,r8
    c.r[8] &= c.r[0];  // 0606A602 and r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606A604 tst r8,r8
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_0606A648; } }  // 0606A606 bf/s 0x0606A648 ; mov #0,r7
    c.r[10] = ld32(0x0606A660u);  // 0606A60A mov.l 0x0606A660,r10
    c.r[11] = ld32(0x0606A664u);  // 0606A60C mov.l 0x0606A664,r11
    c.r[1] = ld32(c.r[9]);  // 0606A60E mov.l @r9,r1
    c.r[6] = 0x3u;  // 0606A610 mov #3,r6
    c.r[5] = ld32(c.r[10]);  // 0606A612 mov.l @r10,r5
    c.r[1] += 10;  // 0606A614 add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A616 mov.w @r1,r4
    c.r[5] += 20;  // 0606A618 add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606A61A extu.w r4,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606A620u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A620u) return; }  // 0606A61C jsr @r11 ; mov.l r8,@-r15
    c.r[0] = c.r[0] & 0xFFu;  // 0606A620 extu.b r0,r0
    c.r[1] = 0x1u;  // 0606A622 mov #1,r1
    c.t = c.r[0] > c.r[1];  // 0606A624 cmp/hi r1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0606A648; } }  // 0606A626 bf/s 0x0606A648 ; add #4,r15
    c.r[1] = ld32(c.r[9]);  // 0606A62A mov.l @r9,r1
    c.r[2] = ld32(0x0606A65Cu);  // 0606A62C mov.l 0x0606A65C,r2
    c.r[1] += 6;  // 0606A62E add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A630 mov.w @r1,r1
    c.r[7] = 0x0u;  // 0606A632 mov #0,r7
    st16(c.r[2], c.r[1]);  // 0606A634 mov.w r1,@r2
    c.r[1] = ld32(c.r[9]);  // 0606A636 mov.l @r9,r1
    c.r[6] = 0x0u;  // 0606A638 mov #0,r6
    c.r[5] = ld32(c.r[10]);  // 0606A63A mov.l @r10,r5
    c.r[1] += 10;  // 0606A63C add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A63E mov.w @r1,r4
    c.r[5] += 20;  // 0606A640 add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606A642 extu.w r4,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606A648u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A648u) return; }  // 0606A644 jsr @r11 ; mov.l r8,@-r15
L_0606A648:
    c.r[15] = c.r[14];  // 0606A648 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606A64A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606A64C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606A64E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606A650 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606A652 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606A654 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606A656 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606A658 rts ; mov.l @r15+,r8
}

void f_0606A66C(SH2Context& c) {
    ran[1527] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606A66C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606A66E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606A670 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606A672 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606A674 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606A676 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606A678 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606A67A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606A802u);  // 0606A67C mov.w 0x0606A802,r3
    c.r[15] += c.r[3];  // 0606A67E add r3,r15
    c.r[14] = c.r[15];  // 0606A680 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A804u);  // 0606A682 mov.w 0x0606A804,r0
    c.r[1] = c.r[14];  // 0606A684 mov r14,r1
    c.r[1] += c.r[0];  // 0606A686 add r0,r1
    c.r[2] = 0x0u;  // 0606A688 mov #0,r2
    c.r[3] = 0x0u;  // 0606A68A mov #0,r3
    st32(c.r[1], c.r[2]);  // 0606A68C mov.l r2,@r1
    st32(c.r[1] + 4, c.r[3]);  // 0606A68E mov.l r3,@(4,r1)
    c.r[1] = ld32(0x0606A818u);  // 0606A690 mov.l 0x0606A818,r1
    st32(c.r[0] + c.r[14], c.r[1]);  // 0606A692 mov.l r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A806u);  // 0606A694 mov.w 0x0606A806,r0
    c.r[1] = ld32(0x0606A81Cu);  // 0606A696 mov.l 0x0606A81C,r1
    st32(c.r[0] + c.r[14], c.r[1]);  // 0606A698 mov.l r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A808u);  // 0606A69A mov.w 0x0606A808,r0
    c.r[1] = c.r[14];  // 0606A69C mov r14,r1
    c.r[1] += c.r[0];  // 0606A69E add r0,r1
    st32(c.r[1], c.r[2]);  // 0606A6A0 mov.l r2,@r1
    st32(c.r[1] + 4, c.r[3]);  // 0606A6A2 mov.l r3,@(4,r1)
    c.r[1] = ld32(0x0606A820u);  // 0606A6A4 mov.l 0x0606A820,r1
    st32(c.r[0] + c.r[14], c.r[1]);  // 0606A6A6 mov.l r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A80Au);  // 0606A6A8 mov.w 0x0606A80A,r0
    c.r[1] = ld32(0x0606A824u);  // 0606A6AA mov.l 0x0606A824,r1
    st32(c.r[0] + c.r[14], c.r[1]);  // 0606A6AC mov.l r1,@(r0,r14)
    c.r[10] = 0x0u;  // 0606A6AE mov #0,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606A80Cu);  // 0606A6B0 mov.w 0x0606A80C,r8
    c.r[8] += c.r[14];  // 0606A6B2 add r14,r8
    c.r[9] = ld32(0x0606A828u);  // 0606A6B4 mov.l 0x0606A828,r9
L_0606A6B6:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606A6B6 mov.b @r9,r4
    c.r[0] = ld32(0x0606A82Cu);  // 0606A6B8 mov.l 0x0606A82C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606A6BEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A6BEu) return; }  // 0606A6BA jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0606A6BE extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A80Eu);  // 0606A6C0 mov.w 0x0606A80E,r1
    c.t = c.r[2] == c.r[1];  // 0606A6C2 cmp/eq r1,r2
    { const bool k = !c.t; st8(c.r[8], c.r[0]); if (k) { goto L_0606A6F2; } }  // 0606A6C4 bf/s 0x0606A6F2 ; mov.b r0,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606A6C8 mov.b @r9,r1
    st8(c.r[8], c.r[1]);  // 0606A6CA mov.b r1,@r8
    c.r[2] = c.r[1] & 0xFFu;  // 0606A6CC extu.b r1,r2
    c.r[1] = ld32(0x0606A830u);  // 0606A6CE mov.l 0x0606A830,r1
    c.r[1] = ld32(c.r[1]);  // 0606A6D0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606A6D2 shll2 r2
    c.r[2] <<= 2;  // 0606A6D4 shll2 r2
    c.r[2] += c.r[1];  // 0606A6D6 add r1,r2
    c.r[1] = c.r[2];  // 0606A6D8 mov r2,r1
    c.r[1] += 4;  // 0606A6DA add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A6DC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606A6DE mov r1,r0
    c.r[0] >>= 2;  // 0606A6E0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A6E2 shlr r0
    c.r[0] >>= 2;  // 0606A6E4 shlr2 r0
    c.r[0] &= 0x1u;  // 0606A6E6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A6E8 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0606A6F2; } }  // 0606A6EA bt/s 0x0606A6F2 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A6EE mov.b @r2,r1
    st8(c.r[8], c.r[1]);  // 0606A6F0 mov.b r1,@r8
L_0606A6F2:
    c.r[8] += 1;  // 0606A6F2 add #1,r8
    c.r[10] += 1;  // 0606A6F4 add #1,r10
    c.r[1] = 0x1u;  // 0606A6F6 mov #1,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606A6F8 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 1; if (k) { SH2_POLL(c); goto L_0606A6B6; } }  // 0606A6FA bf/s 0x0606A6B6 ; add #1,r9
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606A810u);  // 0606A6FE mov.w 0x0606A810,r6
    c.r[7] = c.r[14];  // 0606A700 mov r14,r7
    c.r[7] += c.r[6];  // 0606A702 add r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A80Cu);  // 0606A704 mov.w 0x0606A80C,r1
    c.r[5] = c.r[14];  // 0606A706 mov r14,r5
    c.r[5] += c.r[1];  // 0606A708 add r1,r5
    c.r[0] = c.r[14];  // 0606A70A mov r14,r0
    c.r[3] = ld32(0x0606A830u);  // 0606A70C mov.l 0x0606A830,r3
    c.r[7] += 1;  // 0606A70E add #1,r7
    c.r[10] = 0x0u;  // 0606A710 mov #0,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A712 mov.b @(r0,r1),r1
    c.r[11] = c.r[5];  // 0606A714 mov r5,r11
    c.r[2] = ld32(c.r[3]);  // 0606A716 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A718 extu.b r1,r1
    c.r[1] <<= 2;  // 0606A71A shll2 r1
    c.r[1] <<= 2;  // 0606A71C shll2 r1
    c.r[1] += c.r[2];  // 0606A71E add r2,r1
    c.r[1] += 2;  // 0606A720 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A722 mov.b @r1,r1
    c.r[13] = 0x1Eu;  // 0606A724 mov #30,r13
    st8(c.r[0] + c.r[6], c.r[1]);  // 0606A726 mov.b r1,@(r0,r6)
    c.r[1] = c.r[5];  // 0606A728 mov r5,r1
    c.r[1] += 1;  // 0606A72A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A72C mov.b @r1,r1
    c.r[12] = c.r[14];  // 0606A72E mov r14,r12
    c.r[2] = ld32(c.r[3]);  // 0606A730 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A732 extu.b r1,r1
    c.r[1] <<= 2;  // 0606A734 shll2 r1
    c.r[1] <<= 2;  // 0606A736 shll2 r1
    c.r[1] += c.r[2];  // 0606A738 add r2,r1
    c.r[1] += 2;  // 0606A73A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A73C mov.b @r1,r1
    c.r[9] = ld32(0x0606A828u);  // 0606A73E mov.l 0x0606A828,r9
    st8(c.r[7], c.r[1]);  // 0606A740 mov.b r1,@r7
L_0606A742:
    c.r[8] = c.r[10];  // 0606A742 mov r10,r8
    c.r[8] -= 1;  // 0606A744 add #-1,r8
    c.t = (int32_t)c.r[8] >= 0;  // 0606A746 cmp/pz r8
    if (c.t) { goto L_0606A74C; }  // 0606A748 bt 0x0606A74C
    c.r[8] = 0u - c.r[8];  // 0606A74A neg r8,r8
L_0606A74C:
    c.r[0] = c.r[11];  // 0606A74C mov r11,r0
    c.r[1] = ld32(0x0606A830u);  // 0606A74E mov.l 0x0606A830,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A750 mov.b @(r0,r8),r6
    c.r[4] = c.r[14];  // 0606A752 mov r14,r4
    c.r[1] = ld32(c.r[1]);  // 0606A754 mov.l @r1,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606A756 extu.b r6,r6
    c.r[2] = c.r[6];  // 0606A758 mov r6,r2
    c.r[2] <<= 2;  // 0606A75A shll2 r2
    c.r[2] <<= 2;  // 0606A75C shll2 r2
    c.r[2] += c.r[1];  // 0606A75E add r1,r2
    c.r[2] += 2;  // 0606A760 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A762 mov.b @r2,r5
    c.r[1] = ld32(0x0606A834u);  // 0606A764 mov.l 0x0606A834,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A76Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A76Au) return; }  // 0606A766 jsr @r1 ; extu.b r5,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606A76A tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A7A2; } }  // 0606A76C bt/s 0x0606A7A2 ; mov r11,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A812u);  // 0606A770 mov.w 0x0606A812,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0606A772 mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0606A774 mov r1,r0
    c.r[0] >>= 2;  // 0606A776 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606A778 shlr r0
    c.r[0] &= 0x1u;  // 0606A77A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A77C tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A7A2; } }  // 0606A77E bt/s 0x0606A7A2 ; mov r11,r0
    c.r[1] = ld32(0x0606A838u);  // 0606A782 mov.l 0x0606A838,r1
    c.r[3] = ld32(c.r[1]);  // 0606A784 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A814u);  // 0606A786 mov.w 0x0606A814,r0
    c.r[3] += 18;  // 0606A788 add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606A78A mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A816u);  // 0606A78C mov.w 0x0606A816,r1
    c.r[7] = c.r[2] & 0xFFFFu;  // 0606A78E extu.w r2,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0606A790 shlr r7
    c.r[7] &= c.r[0];  // 0606A792 and r0,r7
    c.r[7] += 3;  // 0606A794 add #3,r7
    c.r[7] &= c.r[0];  // 0606A796 and r0,r7
    c.r[7] += c.r[7];  // 0606A798 add r7,r7
    c.r[2] &= c.r[1];  // 0606A79A and r1,r2
    c.r[2] |= c.r[7];  // 0606A79C or r7,r2
    st16(c.r[3], c.r[2]);  // 0606A79E mov.w r2,@r3
    c.r[0] = c.r[11];  // 0606A7A0 mov r11,r0
L_0606A7A2:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606A7A2 mov.b @(r0,r10),r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606A7A4 mov.b @r9,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606A7A6 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606A7A8 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0606A7AA cmp/eq r1,r2
    if (!c.t) { goto L_0606A7CE; }  // 0606A7AC bf 0x0606A7CE
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A810u);  // 0606A7AE mov.w 0x0606A810,r0
    c.r[0] += c.r[14];  // 0606A7B0 add r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606A7B2 mov.b @(r0,r10),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606A7B4 extu.b r2,r2
    c.macl = c.r[2] * c.r[13];  // 0606A7B6 mul.l r13,r2
    c.r[1] = ld32(0x0606A83Cu);  // 0606A7B8 mov.l 0x0606A83C,r1
    c.r[1] = ld32(c.r[1]);  // 0606A7BA mov.l @r1,r1
    c.r[2] = c.macl;  // 0606A7BC sts macl,r2
    c.r[2] += c.r[1];  // 0606A7BE add r1,r2
    c.r[2] += 22;  // 0606A7C0 add #22,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606A7C2 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A7C4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A7C6 tst r1,r1
    if (!c.t) { goto L_0606A7CE; }  // 0606A7C8 bf 0x0606A7CE
    goto L_0606A8E0;  // 0606A7CA bra 0x0606A8E0 ; nop
L_0606A7CE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A804u);  // 0606A7CE mov.w 0x0606A804,r0
    c.r[7] = ld32(c.r[0] + c.r[12]);  // 0606A7D0 mov.l @(r0,r12),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606A7D2 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0606A7D4 mov r1,r0
    c.r[0] >>= 2;  // 0606A7D6 shlr2 r0
    c.r[0] >>= 2;  // 0606A7D8 shlr2 r0
    c.r[0] &= 0x1u;  // 0606A7DA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606A7DC tst r0,r0
    { const bool k = c.t; c.r[7] += 2; if (k) { goto L_0606A89C; } }  // 0606A7DE bt/s 0x0606A89C ; add #2,r7
    c.r[0] = c.r[11];  // 0606A7E2 mov r11,r0
    c.r[4] = c.r[10] & 0xFFu;  // 0606A7E4 extu.b r10,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A7E6 mov.b @(r0,r8),r5
    c.r[1] = ld32(0x0606A840u);  // 0606A7E8 mov.l 0x0606A840,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A7EEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A7EEu) return; }  // 0606A7EA jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0606A830u);  // 0606A7EE mov.l 0x0606A830,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606A80Eu);  // 0606A7F0 mov.w 0x0606A80E,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606A7F2 mov.b @r9,r2
    c.r[4] = c.r[14];  // 0606A7F4 mov r14,r4
    c.r[1] = ld32(c.r[1]);  // 0606A7F6 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606A7F8 extu.b r2,r2
    c.r[2] <<= 2;  // 0606A7FA shll2 r2
    c.r[2] <<= 2;  // 0606A7FC shll2 r2
    c.r[2] += c.r[1]; goto L_0606A844;  // 0606A7FE bra 0x0606A844 ; add r1,r2
L_0606A844:
    c.r[2] += 2;  // 0606A844 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A846 mov.b @r2,r5
    c.r[1] = ld32(0x0606A894u);  // 0606A848 mov.l 0x0606A894,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A84Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A84Eu) return; }  // 0606A84A jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A88Eu);  // 0606A84E mov.w 0x0606A88E,r1
    c.r[0] = c.r[14];  // 0606A850 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A852 mov.b @(r0,r1),r1
    c.r[1] >>= 2;  // 0606A854 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606A856 shlr r1
    c.r[0] = 0x1u;  // 0606A858 mov #1,r0
    c.r[1] &= c.r[0];  // 0606A85A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A85C tst r1,r1
    if (c.t) { goto L_0606A8B8; }  // 0606A85E bt 0x0606A8B8
    c.r[1] = ld32(0x0606A898u);  // 0606A860 mov.l 0x0606A898,r1
    c.r[7] = ld32(c.r[1]);  // 0606A862 mov.l @r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606A890u);  // 0606A864 mov.w 0x0606A890,r0
    c.r[7] += 18;  // 0606A866 add #18,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0606A868 mov.w @r7,r3
    c.r[1] = 0x4u;  // 0606A86A mov #4,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0606A86C extu.w r3,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606A86E shlr r2
    c.r[2] &= c.r[0];  // 0606A870 and r0,r2
    c.t = c.r[2] > c.r[1];  // 0606A872 cmp/hi r1,r2
    { const bool k = c.t; c.r[2] -= 5; if (k) { goto L_0606A880; } }  // 0606A874 bt/s 0x0606A880 ; add #-5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A892u);  // 0606A878 mov.w 0x0606A892,r1
    c.r[1] &= c.r[3];  // 0606A87A and r3,r1
    st16(c.r[7], c.r[1]); goto L_0606A8B8;  // 0606A87C bra 0x0606A8B8 ; mov.w r1,@r7
L_0606A880:
    c.r[2] &= c.r[0];  // 0606A880 and r0,r2
    c.r[2] += c.r[2];  // 0606A882 add r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606A892u);  // 0606A884 mov.w 0x0606A892,r1
    c.r[1] &= c.r[3];  // 0606A886 and r3,r1
    c.r[1] |= c.r[2];  // 0606A888 or r2,r1
    st16(c.r[7], c.r[1]); goto L_0606A8B8;  // 0606A88A bra 0x0606A8B8 ; mov.w r1,@r7
L_0606A89C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AA2Cu);  // 0606A89C mov.w 0x0606AA2C,r0
    c.r[0] += c.r[14];  // 0606A89E add r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A8A0 mov.b @(r0,r8),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606A8A2 extu.b r2,r2
    c.macl = c.r[2] * c.r[13];  // 0606A8A4 mul.l r13,r2
    c.r[1] = ld32(0x0606AA3Cu);  // 0606A8A6 mov.l 0x0606AA3C,r1
    c.r[1] = ld32(c.r[1]);  // 0606A8A8 mov.l @r1,r1
    c.r[3] = c.macl;  // 0606A8AA sts macl,r3
    c.r[3] += c.r[1];  // 0606A8AC add r1,r3
    c.r[3] += 22;  // 0606A8AE add #22,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606A8B0 mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0606A8B2 mov.w @r7,r2
    c.r[1] -= c.r[2];  // 0606A8B4 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0606A8B6 mov.w r1,@r3
L_0606A8B8:
    c.r[1] = ld32(0x0606AA40u);  // 0606A8B8 mov.l 0x0606AA40,r1
    c.r[0] = c.r[10];  // 0606A8BA mov r10,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A8BC mov.b @(r0,r1),r3
    c.r[2] = 0x1u;  // 0606A8BE mov #1,r2
    c.r[1] = c.r[3];  // 0606A8C0 mov r3,r1
    c.r[1] += 4;  // 0606A8C2 add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606A8C4 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606A8C6 cmp/hi r2,r1
    { const bool k = !c.t; c.r[2] = c.r[3] & 0xFFu; if (k) { goto L_0606A8E0; } }  // 0606A8C8 bf/s 0x0606A8E0 ; extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606AA2Eu);  // 0606A8CC mov.w 0x0606AA2E,r1
    c.t = c.r[2] == c.r[1];  // 0606A8CE cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606A8E0; } }  // 0606A8D0 bt/s 0x0606A8E0 ; mov r3,r0
    c.r[0] |= 0x80u;  // 0606A8D4 or #128,r0
    c.r[5] = c.r[0] & 0xFFu;  // 0606A8D6 extu.b r0,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606A8D8 mov.b @r9,r4
    c.r[1] = ld32(0x0606AA44u);  // 0606A8DA mov.l 0x0606AA44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A8E0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A8E0u) return; }  // 0606A8DC jsr @r1 ; extu.b r4,r4
L_0606A8E0:
    c.r[0] = ld32(0x0606AA48u);  // 0606A8E0 mov.l 0x0606AA48,r0
    c.r[1] = ld32(0x0606AA4Cu);  // 0606A8E2 mov.l 0x0606AA4C,r1
    c.r[6] = c.r[8];  // 0606A8E4 mov r8,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A8E6 mov.b @(r0,r8),r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606AA30u);  // 0606A8E8 mov.w 0x0606AA30,r4
    c.r[7] = ld32(c.r[1]);  // 0606A8EA mov.l @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0606A8EC extu.b r2,r2
    c.r[2] <<= 2;  // 0606A8EE shll2 r2
    c.r[2] <<= 2;  // 0606A8F0 shll2 r2
    c.r[2] += c.r[7];  // 0606A8F2 add r7,r2
    c.r[2] += 2;  // 0606A8F4 add #2,r2
    c.r[1] = ld32(0x0606AA3Cu);  // 0606A8F6 mov.l 0x0606AA3C,r1
    c.r[6] <<= 2;  // 0606A8F8 shll2 r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A8FA mov.b @r2,r2
    c.r[6] += c.r[14];  // 0606A8FC add r14,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0606A8FE extu.b r2,r2
    c.macl = c.r[2] * c.r[13];  // 0606A900 mul.l r13,r2
    c.r[0] = c.r[6];  // 0606A902 mov r6,r0
    c.r[5] = ld32(c.r[1]);  // 0606A904 mov.l @r1,r5
    c.r[3] = c.macl;  // 0606A906 sts macl,r3
    c.r[3] += c.r[5];  // 0606A908 add r5,r3
    c.r[2] = ld32(c.r[0] + c.r[4]);  // 0606A90A mov.l @(r0,r4),r2
    c.r[3] += 24;  // 0606A90C add #24,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606A90E mov.w @r3,r1
    c.r[2] += 22;  // 0606A910 add #22,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606A912 mov.w @r2,r2
    c.r[0] = c.r[11];  // 0606A914 mov r11,r0
    c.r[1] -= c.r[2];  // 0606A916 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0606A918 mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A91A mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606A91C extu.b r1,r1
    c.r[1] <<= 2;  // 0606A91E shll2 r1
    c.r[1] <<= 2;  // 0606A920 shll2 r1
    c.r[1] += c.r[7];  // 0606A922 add r7,r1
    c.r[1] += 2;  // 0606A924 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A926 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606A928 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 0606A92A mul.l r13,r1
    c.r[0] = c.r[6];  // 0606A92C mov r6,r0
    c.r[3] = c.macl;  // 0606A92E sts macl,r3
    c.r[3] += c.r[5];  // 0606A930 add r5,r3
    c.r[1] = ld32(c.r[0] + c.r[4]);  // 0606A932 mov.l @(r0,r4),r1
    c.r[3] += 24;  // 0606A934 add #24,r3
    c.r[1] += 26;  // 0606A936 add #26,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A938 mov.b @r1,r2
    c.r[0] = c.r[12];  // 0606A93A mov r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606A93C mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606A93E extu.b r2,r2
    c.r[1] -= c.r[2];  // 0606A940 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0606A942 mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606AA32u);  // 0606A944 mov.w 0x0606AA32,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0606A946 mov.l @(r0,r1),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A948 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606A94A mov #1,r0
    c.r[1] >>= 2;  // 0606A94C shlr2 r1
    c.r[1] >>= 2;  // 0606A94E shlr2 r1
    c.r[1] >>= 2;  // 0606A950 shlr2 r1
    c.r[1] &= c.r[0];  // 0606A952 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A954 tst r1,r1
    if (c.t) { goto L_0606A9D8; }  // 0606A956 bt 0x0606A9D8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AA2Cu);  // 0606A958 mov.w 0x0606AA2C,r0
    c.r[0] += c.r[14];  // 0606A95A add r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606A95C mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606A95E extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 0606A960 mul.l r13,r1
    c.r[1] = c.macl;  // 0606A962 sts macl,r1
    c.r[1] += c.r[5];  // 0606A964 add r5,r1
    c.r[1] += 22;  // 0606A966 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606A968 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606A96A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606A96C tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606A9D8; } }  // 0606A96E bt/s 0x0606A9D8 ; mov r11,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606A972 mov.b @(r0,r8),r4
    c.r[1] = ld32(0x0606AA50u);  // 0606A974 mov.l 0x0606AA50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606A97Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606A97Au) return; }  // 0606A976 jsr @r1 ; extu.b r4,r4
    c.r[2] = ld32(0x0606AA54u);  // 0606A97A mov.l 0x0606AA54,r2
    c.r[1] = ld32(c.r[2]);  // 0606A97C mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606AA34u);  // 0606A97E mov.w 0x0606AA34,r3
    c.r[0] = c.r[1];  // 0606A980 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606A982 mov.b @(r0,r3),r1
    c.r[7] = 0x0u;  // 0606A984 mov #0,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606A986 extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 0606A988 cmp/ge r1,r7
    if (c.t) { goto L_0606A9D8; }  // 0606A98A bt 0x0606A9D8
    c.r[6] = c.r[2];  // 0606A98C mov r2,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606AA36u);  // 0606A98E mov.w 0x0606AA36,r5
    c.r[2] = c.r[7];  // 0606A990 mov r7,r2
L_0606A992:
    c.r[1] = ld32(c.r[6]);  // 0606A992 mov.l @r6,r1
    c.r[2] += c.r[2];  // 0606A994 add r2,r2
    c.r[0] = c.r[1];  // 0606A996 mov r1,r0
    c.r[1] += c.r[2];  // 0606A998 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606A99A mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0606A99C add #1,r1
    c.r[0] = 0x7Fu;  // 0606A99E mov #127,r0
    c.r[3] &= c.r[0];  // 0606A9A0 and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606A9A2 mov.b @r1,r2
    c.r[3] <<= 8;  // 0606A9A4 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606A9A6 extu.b r2,r2
    c.r[2] |= c.r[3];  // 0606A9A8 or r3,r2
    c.r[1] = ld32(0x0606AA58u);  // 0606A9AA mov.l 0x0606AA58,r1
    c.r[3] = c.r[2];  // 0606A9AC mov r2,r3
    c.r[3] += c.r[3];  // 0606A9AE add r3,r3
    c.r[3] += c.r[2];  // 0606A9B0 add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0606A9B2 mov.l @r1,r1
    c.r[3] <<= 2;  // 0606A9B4 shll2 r3
    c.r[3] += c.r[1];  // 0606A9B6 add r1,r3
    c.r[3] += 9;  // 0606A9B8 add #9,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606A9BA mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0606A9BC extu.b r2,r1
    c.t = c.r[1] > c.r[5];  // 0606A9BE cmp/hi r5,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606A9C8; } }  // 0606A9C0 bt/s 0x0606A9C8 ; mov r2,r1
    c.r[1] += 1;  // 0606A9C4 add #1,r1
    st8(c.r[3], c.r[1]);  // 0606A9C6 mov.b r1,@r3
L_0606A9C8:
    c.r[1] = ld32(c.r[6]);  // 0606A9C8 mov.l @r6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AA34u);  // 0606A9CA mov.w 0x0606AA34,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606A9CC mov.b @(r0,r1),r1
    c.r[7] += 1;  // 0606A9CE add #1,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606A9D0 extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 0606A9D2 cmp/ge r1,r7
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { SH2_POLL(c); goto L_0606A992; } }  // 0606A9D4 bf/s 0x0606A992 ; mov r7,r2
L_0606A9D8:
    c.r[12] += 4;  // 0606A9D8 add #4,r12
    c.r[10] += 1;  // 0606A9DA add #1,r10
    c.r[1] = 0x1u;  // 0606A9DC mov #1,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606A9DE cmp/gt r1,r10
    { const bool k = c.t; c.r[9] += 1; if (k) { goto L_0606A9E8; } }  // 0606A9E0 bt/s 0x0606A9E8 ; add #1,r9
    SH2_POLL(c); goto L_0606A742;  // 0606A9E4 bra 0x0606A742 ; nop
L_0606A9E8:
    c.r[2] = ld32(0x0606AA48u);  // 0606A9E8 mov.l 0x0606AA48,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0606A9EA mov.b @r2+,r3
    c.r[1] = ld32(0x0606AA4Cu);  // 0606A9EC mov.l 0x0606AA4C,r1
    c.r[7] = ld32(c.r[1]);  // 0606A9EE mov.l @r1,r7
    c.r[3] = c.r[3] & 0xFFu;  // 0606A9F0 extu.b r3,r3
    c.r[3] <<= 2;  // 0606A9F2 shll2 r3
    c.r[3] <<= 2;  // 0606A9F4 shll2 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606A9F6 mov.b @r2,r1
    c.r[3] += c.r[7];  // 0606A9F8 add r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606A9FA extu.b r1,r1
    c.r[1] <<= 2;  // 0606A9FC shll2 r1
    c.r[1] <<= 2;  // 0606A9FE shll2 r1
    c.r[1] += c.r[7];  // 0606AA00 add r7,r1
    c.r[1] += 7;  // 0606AA02 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AA04 mov.b @r1,r0
    c.r[3] += 7;  // 0606AA06 add #7,r3
    c.r[0] |= 0x4u;  // 0606AA08 or #4,r0
    st8(c.r[1], c.r[0]);  // 0606AA0A mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606AA0C mov.b @r3,r0
    c.r[0] |= 0x4u;  // 0606AA0E or #4,r0
    st8(c.r[3], c.r[0]);  // 0606AA10 mov.b r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606AA38u);  // 0606AA12 mov.w 0x0606AA38,r3
    c.r[14] += c.r[3];  // 0606AA14 add r3,r14
    c.r[15] = c.r[14];  // 0606AA16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606AA18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606AA1A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606AA1C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606AA1E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606AA20 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606AA22 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606AA24 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AA3Au);  // 0606AA26 mov.w 0x0606AA3A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606AA28 rts ; mov.l @r15+,r8
}

void f_0606AA5C(SH2Context& c) {
    ran[1528] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606AA5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606AA5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606AA60 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606AA62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606AA64 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606AA66 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606AA68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606AA6A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606ABCCu);  // 0606AA6C mov.w 0x0606ABCC,r3
    c.r[15] += c.r[3];  // 0606AA6E add r3,r15
    c.r[14] = c.r[15];  // 0606AA70 mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 0606AA72 extu.b r4,r13
    c.r[5] = c.r[5] & 0xFFu;  // 0606AA74 extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606ABCEu);  // 0606AA76 mov.w 0x0606ABCE,r0
    st32(c.r[0] + c.r[14], c.r[5]);  // 0606AA78 mov.l r5,@(r0,r14)
    c.r[10] = ld32(0x0606ABD8u);  // 0606AA7A mov.l 0x0606ABD8,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606ABCEu);  // 0606AA7C mov.w 0x0606ABCE,r0
    c.r[0] += c.r[14];  // 0606AA7E add r14,r0
    c.r[9] = ld32(0x0606ABDCu);  // 0606AA80 mov.l 0x0606ABDC,r9
    c.r[8] = 0x1Eu;  // 0606AA82 mov #30,r8
    c.r[7] = ld32(c.r[0]);  // 0606AA84 mov.l @r0,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606ABD0u);  // 0606AA86 mov.w 0x0606ABD0,r11
    c.r[1] = ld32(c.r[10]);  // 0606AA88 mov.l @r10,r1
    c.r[7] <<= 2;  // 0606AA8A shll2 r7
    c.r[7] <<= 2;  // 0606AA8C shll2 r7
    c.r[7] += c.r[1];  // 0606AA8E add r1,r7
    c.r[7] += 2;  // 0606AA90 add #2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606AA92 mov.b @r7,r1
    c.r[6] = c.r[11];  // 0606AA94 mov r11,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0606AA96 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 0606AA98 mul.l r8,r1
    c.r[4] = c.r[14];  // 0606AA9A mov r14,r4
    c.r[2] = ld32(c.r[9]);  // 0606AA9C mov.l @r9,r2
    c.r[3] = c.macl;  // 0606AA9E sts macl,r3
    c.r[3] += c.r[2];  // 0606AAA0 add r2,r3
    c.r[3] += 22;  // 0606AAA2 add #22,r3
    c.r[1] = 0x0u;  // 0606AAA4 mov #0,r1
    st16(c.r[3], c.r[1]);  // 0606AAA6 mov.w r1,@r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606AAA8 mov.b @r7,r5
    c.r[1] = ld32(0x0606ABE0u);  // 0606AAAA mov.l 0x0606ABE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606AAB0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AAB0u) return; }  // 0606AAAC jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0606ABE4u);  // 0606AAB0 mov.l 0x0606ABE4,r1
    c.r[0] = c.r[13];  // 0606AAB2 mov r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606AAB4 mov.b @(r0,r1),r1
    c.r[2] = ld32(c.r[10]);  // 0606AAB6 mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AAB8 extu.b r1,r1
    c.r[1] <<= 2;  // 0606AABA shll2 r1
    c.r[1] <<= 2;  // 0606AABC shll2 r1
    c.r[1] += c.r[2];  // 0606AABE add r2,r1
    c.r[1] += 2;  // 0606AAC0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AAC2 mov.b @r1,r1
    c.r[12] = 0x0u;  // 0606AAC4 mov #0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0606AAC6 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 0606AAC8 mul.l r8,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606ABD2u);  // 0606AACA mov.w 0x0606ABD2,r6
    c.r[2] = ld32(c.r[9]);  // 0606AACC mov.l @r9,r2
    c.r[1] = c.macl;  // 0606AACE sts macl,r1
    c.r[1] += c.r[2];  // 0606AAD0 add r2,r1
    c.r[1] += 15;  // 0606AAD2 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AAD4 mov.b @r1,r1
    c.r[2] = ld32(0x0606ABE8u);  // 0606AAD6 mov.l 0x0606ABE8,r2
    c.r[2] = ld32(c.r[2]);  // 0606AAD8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AADA extu.b r1,r1
    c.r[3] = c.r[1];  // 0606AADC mov r1,r3
    c.r[3] += c.r[3];  // 0606AADE add r3,r3
    c.r[3] += c.r[1];  // 0606AAE0 add r1,r3
    c.r[3] <<= 2;  // 0606AAE2 shll2 r3
    c.r[3] += c.r[2];  // 0606AAE4 add r2,r3
    c.r[3] += 6;  // 0606AAE6 add #6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606AAE8 mov.w @r3,r1
    c.r[7] = 0x0u;  // 0606AAEA mov #0,r7
    c.r[1] += 1;  // 0606AAEC add #1,r1
    st16(c.r[3], c.r[1]);  // 0606AAEE mov.w r1,@r3
L_0606AAF0:
    c.r[1] = ld32(0x0606ABD8u);  // 0606AAF0 mov.l 0x0606ABD8,r1
    c.r[2] = c.r[7];  // 0606AAF2 mov r7,r2
    c.r[3] = ld32(c.r[1]);  // 0606AAF4 mov.l @r1,r3
    c.r[0] = c.r[7];  // 0606AAF6 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606AAF8 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606AAFA extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 0606AAFC cmp/eq r11,r1
    { const bool k = c.t; c.r[2] += c.r[3]; if (k) { goto L_0606AB72; } }  // 0606AAFE bt/s 0x0606AB72 ; add r3,r2
    c.r[1] = c.r[2];  // 0606AB02 mov r2,r1
    c.r[1] += 7;  // 0606AB04 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AB06 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606AB08 mov r1,r0
    c.r[0] >>= 2;  // 0606AB0A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606AB0C shlr r0
    c.r[0] &= 0x1u;  // 0606AB0E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AB10 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0606AB72; } }  // 0606AB12 bf/s 0x0606AB72 ; mov r2,r1
    c.r[1] += 3;  // 0606AB16 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AB18 mov.b @r1,r1
    c.r[0] = c.r[13];  // 0606AB1A mov r13,r0
    c.r[5] = c.r[1];  // 0606AB1C mov r1,r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0606AB1E shlr r5
    c.r[1] = ld32(0x0606ABE4u);  // 0606AB20 mov.l 0x0606ABE4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606AB22 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606AB24 extu.b r1,r1
    c.r[1] <<= 2;  // 0606AB26 shll2 r1
    c.r[1] <<= 2;  // 0606AB28 shll2 r1
    c.r[1] += c.r[3];  // 0606AB2A add r3,r1
    c.r[1] += 3;  // 0606AB2C add #3,r1
    c.r[0] = 0x3u;  // 0606AB2E mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AB30 mov.b @r1,r1
    c.r[5] &= c.r[0];  // 0606AB32 and r0,r5
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606AB34 shlr r1
    c.r[1] &= c.r[0];  // 0606AB36 and r0,r1
    c.t = c.r[5] == c.r[1];  // 0606AB38 cmp/eq r1,r5
    { const bool k = !c.t; c.r[2] += 2; if (k) { goto L_0606AB72; } }  // 0606AB3A bf/s 0x0606AB72 ; add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606AB3E mov.b @r2,r2
    c.r[1] = ld32(0x0606ABDCu);  // 0606AB40 mov.l 0x0606ABDC,r1
    c.r[3] = ld32(c.r[1]);  // 0606AB42 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606AB44 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606AB46 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606AB48 mul.l r1,r2
    c.r[1] = c.macl;  // 0606AB4A sts macl,r1
    c.r[1] += c.r[3];  // 0606AB4C add r3,r1
    c.r[1] += 15;  // 0606AB4E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AB50 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606AB52 extu.b r1,r2
    c.r[1] = ld32(0x0606ABE8u);  // 0606AB54 mov.l 0x0606ABE8,r1
    c.r[3] = c.r[2];  // 0606AB56 mov r2,r3
    c.r[3] += c.r[3];  // 0606AB58 add r3,r3
    c.r[3] += c.r[2];  // 0606AB5A add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0606AB5C mov.l @r1,r1
    c.r[3] <<= 2;  // 0606AB5E shll2 r3
    c.r[3] += c.r[1];  // 0606AB60 add r1,r3
    c.r[3] += 9;  // 0606AB62 add #9,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606AB64 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0606AB66 extu.b r2,r1
    c.t = c.r[1] > c.r[6];  // 0606AB68 cmp/hi r6,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606AB72; } }  // 0606AB6A bt/s 0x0606AB72 ; mov r2,r1
    c.r[1] += 1;  // 0606AB6E add #1,r1
    st8(c.r[3], c.r[1]);  // 0606AB70 mov.b r1,@r3
L_0606AB72:
    c.r[12] += 1;  // 0606AB72 add #1,r12
    c.r[1] = 0x49u;  // 0606AB74 mov #73,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 0606AB76 cmp/gt r1,r12
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_0606AAF0; } }  // 0606AB78 bf/s 0x0606AAF0 ; add #16,r7
    c.r[1] = ld32(0x0606ABE4u);  // 0606AB7C mov.l 0x0606ABE4,r1
    c.r[0] = c.r[13];  // 0606AB7E mov r13,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606AB80 mov.b @(r0,r1),r4
    c.r[1] = ld32(0x0606ABECu);  // 0606AB82 mov.l 0x0606ABEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606AB88u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AB88u) return; }  // 0606AB84 jsr @r1 ; extu.b r4,r4
    c.r[3] = ld32(0x0606ABF0u);  // 0606AB88 mov.l 0x0606ABF0,r3
    c.r[2] = ld32(c.r[3]);  // 0606AB8A mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606ABD4u);  // 0606AB8C mov.w 0x0606ABD4,r1
    c.r[0] = c.r[2];  // 0606AB8E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606AB90 mov.b @(r0,r1),r1
    c.r[12] = 0x0u;  // 0606AB92 mov #0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0606AB94 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0606AB96 cmp/ge r1,r12
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0606AC0A; } }  // 0606AB98 bt/s 0x0606AC0A ; mov r12,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606ABD6u);  // 0606AB9C mov.w 0x0606ABD6,r7
L_0606AB9E:
    c.r[2] = ld32(c.r[3]);  // 0606AB9E mov.l @r3,r2
    c.r[1] += c.r[1];  // 0606ABA0 add r1,r1
    c.r[2] += c.r[1];  // 0606ABA2 add r1,r2
    c.r[2] += 1;  // 0606ABA4 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606ABA6 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606ABA8 extu.b r1,r2
    c.r[1] = ld32(0x0606ABE8u);  // 0606ABAA mov.l 0x0606ABE8,r1
    c.r[3] = c.r[2];  // 0606ABAC mov r2,r3
    c.r[3] += c.r[3];  // 0606ABAE add r3,r3
    c.r[3] += c.r[2];  // 0606ABB0 add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0606ABB2 mov.l @r1,r1
    c.r[3] <<= 2;  // 0606ABB4 shll2 r3
    c.r[3] += c.r[1];  // 0606ABB6 add r1,r3
    c.r[3] += 9;  // 0606ABB8 add #9,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606ABBA mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0606ABBC extu.b r2,r1
    c.r[1] += 3;  // 0606ABBE add #3,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0606ABC0 cmp/gt r7,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606ABF4; } }  // 0606ABC2 bt/s 0x0606ABF4 ; mov r2,r1
    c.r[1] += 3;  // 0606ABC6 add #3,r1
    st8(c.r[3], c.r[1]); goto L_0606ABF6;  // 0606ABC8 bra 0x0606ABF6 ; mov.b r1,@r3
L_0606ABF4:
    st8(c.r[3], c.r[7]);  // 0606ABF4 mov.b r7,@r3
L_0606ABF6:
    c.r[3] = ld32(0x0606AD18u);  // 0606ABF6 mov.l 0x0606AD18,r3
    c.r[1] = ld32(c.r[3]);  // 0606ABF8 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AD0Eu);  // 0606ABFA mov.w 0x0606AD0E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606ABFC mov.b @(r0,r1),r1
    c.r[12] += 1;  // 0606ABFE add #1,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0606AC00 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0606AC02 cmp/ge r1,r12
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { SH2_POLL(c); goto L_0606AB9E; } }  // 0606AC04 bf/s 0x0606AB9E ; mov r12,r1
    c.r[12] = 0x0u;  // 0606AC08 mov #0,r12
L_0606AC0A:
    c.r[11] = ld32(0x0606AD1Cu);  // 0606AC0A mov.l 0x0606AD1C,r11
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606AD10u);  // 0606AC0C mov.w 0x0606AD10,r13
L_0606AC0E:
    c.r[1] = ld32(0x0606AD20u);  // 0606AC0E mov.l 0x0606AD20,r1
    c.r[0] = c.r[12];  // 0606AC10 mov r12,r0
    c.r[0] <<= 2;  // 0606AC12 shll2 r0
    c.r[0] <<= 2;  // 0606AC14 shll2 r0
    c.r[7] = c.r[0];  // 0606AC16 mov r0,r7
    c.r[3] = ld32(c.r[1]);  // 0606AC18 mov.l @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606AD12u);  // 0606AC1A mov.w 0x0606AD12,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606AC1C mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606AC1E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606AC20 cmp/eq r2,r1
    { const bool k = !c.t; c.r[7] += c.r[3]; if (k) { goto L_0606AC2A; } }  // 0606AC22 bf/s 0x0606AC2A ; add r3,r7
    goto L_0606AD32;  // 0606AC26 bra 0x0606AD32 ; nop
L_0606AC2A:
    c.r[1] = c.r[7];  // 0606AC2A mov r7,r1
    c.r[1] += 7;  // 0606AC2C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AC2E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606AC30 mov r1,r0
    c.r[0] >>= 2;  // 0606AC32 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606AC34 shlr r0
    c.r[0] &= 0x1u;  // 0606AC36 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AC38 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0606AD32; } }  // 0606AC3A bf/s 0x0606AD32 ; mov r7,r1
    c.r[1] += 3;  // 0606AC3E add #3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AD14u);  // 0606AC40 mov.w 0x0606AD14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AC42 mov.b @r1,r1
    c.r[0] += c.r[14];  // 0606AC44 add r14,r0
    c.r[2] = c.r[1];  // 0606AC46 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606AC48 shlr r2
    c.r[1] = ld32(c.r[0]);  // 0606AC4A mov.l @r0,r1
    c.r[1] <<= 2;  // 0606AC4C shll2 r1
    c.r[1] <<= 2;  // 0606AC4E shll2 r1
    c.r[1] += c.r[3];  // 0606AC50 add r3,r1
    c.r[1] += 3;  // 0606AC52 add #3,r1
    c.r[0] = 0x3u;  // 0606AC54 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AC56 mov.b @r1,r1
    c.r[2] &= c.r[0];  // 0606AC58 and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606AC5A shlr r1
    c.r[1] &= c.r[0];  // 0606AC5C and r0,r1
    c.t = c.r[2] == c.r[1];  // 0606AC5E cmp/eq r1,r2
    { const bool k = !c.t; c.r[7] += 2; if (k) { goto L_0606AD32; } }  // 0606AC60 bf/s 0x0606AD32 ; add #2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606AC64 mov.b @r7,r2
    c.r[1] = ld32(0x0606AD24u);  // 0606AC66 mov.l 0x0606AD24,r1
    c.r[3] = ld32(c.r[1]);  // 0606AC68 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606AC6A extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606AC6C mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606AC6E mul.l r1,r2
    c.r[9] = ld32(0x0606AD28u);  // 0606AC70 mov.l 0x0606AD28,r9
    c.r[1] = c.macl;  // 0606AC72 sts macl,r1
    c.r[1] += c.r[3];  // 0606AC74 add r3,r1
    c.r[1] += 15;  // 0606AC76 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AC78 mov.b @r1,r1
    c.r[5] = 0x1Cu;  // 0606AC7A mov #28,r5
    c.r[2] = c.r[1] & 0xFFu;  // 0606AC7C extu.b r1,r2
    c.r[10] = c.r[2];  // 0606AC7E mov r2,r10
    c.r[10] += c.r[10];  // 0606AC80 add r10,r10
    c.r[10] += c.r[2];  // 0606AC82 add r2,r10
    c.r[10] <<= 2;  // 0606AC84 shll2 r10
    c.r[1] = ld32(c.r[11]);  // 0606AC86 mov.l @r11,r1
    c.r[0] = c.r[10];  // 0606AC88 mov r10,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606AC8A mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0606AD2Cu);  // 0606AC8C mov.l 0x0606AD2C,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606AC92u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AC92u) return; }  // 0606AC8E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0606AC92 mov r0,r1
    c.r[5] = c.r[8];  // 0606AC94 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606AC9Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AC9Au) return; }  // 0606AC96 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606AC9A mov r0,r1
    c.r[1] += 3;  // 0606AC9C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AC9E mov.b @r1,r1
    c.r[2] = 0x30u;  // 0606ACA0 mov #48,r2
    c.r[2] &= c.r[1];  // 0606ACA2 and r1,r2
    c.r[2] >>= 2;  // 0606ACA4 shlr2 r2
    c.r[2] >>= 2;  // 0606ACA6 shlr2 r2
    c.r[0] = c.r[2];  // 0606ACA8 mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0606ACAA cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0606ACDE; } }  // 0606ACAC bt/s 0x0606ACDE ; mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606ACB0 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0606ACC0; } }  // 0606ACB2 bt/s 0x0606ACC0 ; cmp/eq #3,r0
    c.t = (c.r[2] & c.r[2]) == 0;  // 0606ACB6 tst r2,r2
    { const bool k = c.t; c.r[1] = 0x32u; if (k) { goto L_0606ACC8; } }  // 0606ACB8 bt/s 0x0606ACC8 ; mov #50,r1
    c.r[12] += 1; goto L_0606AD34;  // 0606ACBC bra 0x0606AD34 ; add #1,r12
L_0606ACC0:
    if (c.t) { goto L_0606ACF6; }  // 0606ACC0 bt 0x0606ACF6
    c.r[12] += 1;  // 0606ACC2 add #1,r12
    c.r[1] = 0x49u; goto L_0606AD36;  // 0606ACC4 bra 0x0606AD36 ; mov #73,r1
L_0606ACC8:
    c.r[7] = ld32(c.r[11]);  // 0606ACC8 mov.l @r11,r7
    c.r[7] += c.r[10];  // 0606ACCA add r10,r7
    c.r[7] += 9;  // 0606ACCC add #9,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606ACCE mov.b @r7,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0606ACD0 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 0606ACD2 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606AD32; } }  // 0606ACD4 bf/s 0x0606AD32 ; mov r3,r1
    c.r[1] -= 1;  // 0606ACD8 add #-1,r1
    st8(c.r[7], c.r[1]); goto L_0606AD32;  // 0606ACDA bra 0x0606AD32 ; mov.b r1,@r7
L_0606ACDE:
    c.r[7] = ld32(c.r[11]);  // 0606ACDE mov.l @r11,r7
    c.r[7] += c.r[10];  // 0606ACE0 add r10,r7
    c.r[7] += 9;  // 0606ACE2 add #9,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606ACE4 mov.b @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606AD16u);  // 0606ACE6 mov.w 0x0606AD16,r1
    c.r[2] = c.r[3] & 0xFFu;  // 0606ACE8 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 0606ACEA cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606AD32; } }  // 0606ACEC bt/s 0x0606AD32 ; mov r3,r1
    c.r[1] += 1;  // 0606ACF0 add #1,r1
    st8(c.r[7], c.r[1]); goto L_0606AD32;  // 0606ACF2 bra 0x0606AD32 ; mov.b r1,@r7
L_0606ACF6:
    c.r[2] = ld32(c.r[11]);  // 0606ACF6 mov.l @r11,r2
    c.r[2] += c.r[10];  // 0606ACF8 add r10,r2
    c.r[2] += 9;  // 0606ACFA add #9,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606ACFC mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0606ACFE extu.b r3,r1
    c.r[1] += 2;  // 0606AD00 add #2,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[13];  // 0606AD02 cmp/gt r13,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606AD30; } }  // 0606AD04 bt/s 0x0606AD30 ; mov r3,r1
    c.r[1] += 2;  // 0606AD08 add #2,r1
    st8(c.r[2], c.r[1]); goto L_0606AD32;  // 0606AD0A bra 0x0606AD32 ; mov.b r1,@r2
L_0606AD30:
    st8(c.r[2], c.r[13]);  // 0606AD30 mov.b r13,@r2
L_0606AD32:
    c.r[12] += 1;  // 0606AD32 add #1,r12
L_0606AD34:
    c.r[1] = 0x49u;  // 0606AD34 mov #73,r1
L_0606AD36:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 0606AD36 cmp/gt r1,r12
    if (c.t) { goto L_0606AD3E; }  // 0606AD38 bt 0x0606AD3E
    SH2_POLL(c); goto L_0606AC0E;  // 0606AD3A bra 0x0606AC0E ; nop
L_0606AD3E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606AD56u);  // 0606AD3E mov.w 0x0606AD56,r3
    c.r[14] += c.r[3];  // 0606AD40 add r3,r14
    c.r[15] = c.r[14];  // 0606AD42 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606AD44 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606AD46 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606AD48 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606AD4A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606AD4C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606AD4E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606AD50 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606AD52 rts ; mov.l @r15+,r8
}

void f_0606AD58(SH2Context& c) {
    ran[1529] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606AD58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606AD5A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606AD5C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606AD5E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606AD60 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606AD62 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606AD64 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606AD66 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606AE48u);  // 0606AD68 mov.w 0x0606AE48,r3
    c.r[15] += c.r[3];  // 0606AD6A add r3,r15
    c.r[14] = c.r[15];  // 0606AD6C mov r15,r14
    c.r[11] = 0x1u;  // 0606AD6E mov #1,r11
    c.r[8] = ld32(0x0606AE50u);  // 0606AD70 mov.l 0x0606AE50,r8
    c.r[1] = ld32(0x0606AE54u);  // 0606AD72 mov.l 0x0606AE54,r1
    c.r[6] = 0x0u;  // 0606AD74 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606AD76 mov.b @r8,r4
    c.r[5] = 0x0u;  // 0606AD78 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606AD7Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AD7Eu) return; }  // 0606AD7A jsr @r1 ; extu.b r4,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606AD7E mov.b @r8,r2
    c.r[1] = ld32(0x0606AE58u);  // 0606AD80 mov.l 0x0606AE58,r1
    c.r[1] = ld32(c.r[1]);  // 0606AD82 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606AD84 extu.b r2,r2
    c.r[2] <<= 2;  // 0606AD86 shll2 r2
    c.r[2] <<= 2;  // 0606AD88 shll2 r2
    c.r[2] += c.r[1];  // 0606AD8A add r1,r2
    c.r[2] += 2;  // 0606AD8C add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606AD8E mov.b @r2,r2
    c.r[1] = ld32(0x0606AE5Cu);  // 0606AD90 mov.l 0x0606AE5C,r1
    c.r[3] = ld32(c.r[1]);  // 0606AD92 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606AD94 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606AD96 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606AD98 mul.l r1,r2
    c.r[4] = ld32(0x0606AE60u);  // 0606AD9A mov.l 0x0606AE60,r4
    c.r[9] = ld32(0x0606AE64u);  // 0606AD9C mov.l 0x0606AE64,r9
    c.r[1] = c.macl;  // 0606AD9E sts macl,r1
    c.r[0] = c.r[1];  // 0606ADA0 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606ADA2 mov.w @(r0,r3),r8
    c.r[5] = 0x1Bu;  // 0606ADA4 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606ADAAu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ADAAu) return; }  // 0606ADA6 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0606ADAA mov r0,r1
    c.r[5] = c.r[8];  // 0606ADAC mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606ADB2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606ADB2u) return; }  // 0606ADAE jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 0606ADB2 mov r0,r7
    c.r[1] = c.r[7];  // 0606ADB4 mov r7,r1
    c.r[1] += 7;  // 0606ADB6 add #7,r1
    c.r[2] = 0x78u;  // 0606ADB8 mov #120,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606ADBA mov.b @r1,r3
    c.r[7] += 9;  // 0606ADBC add #9,r7
    c.r[2] &= c.r[3];  // 0606ADBE and r3,r2
    c.r[2] >>= 2;  // 0606ADC0 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606ADC2 shlr r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606ADC4 mov.b @r7,r1
    c.r[0] = c.r[2];  // 0606ADC6 mov r2,r0
    c.r[10] = c.r[1];  // 0606ADC8 mov r1,r10
    c.r[10] >>= 2;  // 0606ADCA shlr2 r10
    c.r[10] >>= 2;  // 0606ADCC shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0606ADCE shlr r10
    c.r[10] >>= 2;  // 0606ADD0 shlr2 r10
    c.t = c.r[0] == 0x2u;  // 0606ADD2 cmp/eq #2,r0
    { const bool k = !c.t; c.r[10] &= c.r[11]; if (k) { goto L_0606ADE0; } }  // 0606ADD4 bf/s 0x0606ADE0 ; and r11,r10
    c.r[0] = c.r[3];  // 0606ADD8 mov r3,r0
    c.r[0] &= 0x7u;  // 0606ADDA and #7,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606ADDC tst r0,r0
    if (c.t) { goto L_0606ADE4; }  // 0606ADDE bt 0x0606ADE4
L_0606ADE0:
    c.t = (c.r[10] & c.r[10]) == 0;  // 0606ADE0 tst r10,r10
    if (c.t) { goto L_0606AE7C; }  // 0606ADE2 bt 0x0606AE7C
L_0606ADE4:
    c.r[1] = ld32(0x0606AE50u);  // 0606ADE4 mov.l 0x0606AE50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606ADE6 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606ADE8 extu.b r1,r2
    c.r[1] = ld32(0x0606AE58u);  // 0606ADEA mov.l 0x0606AE58,r1
    c.r[1] = ld32(c.r[1]);  // 0606ADEC mov.l @r1,r1
    c.r[2] <<= 2;  // 0606ADEE shll2 r2
    c.r[2] <<= 2;  // 0606ADF0 shll2 r2
    c.r[2] += c.r[1];  // 0606ADF2 add r1,r2
    c.r[1] = c.r[2];  // 0606ADF4 mov r2,r1
    c.r[1] += 4;  // 0606ADF6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606ADF8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606ADFA mov r1,r0
    c.r[0] >>= 2;  // 0606ADFC shlr2 r0
    c.r[0] >>= 2;  // 0606ADFE shlr2 r0
    c.r[0] >>= 2;  // 0606AE00 shlr2 r0
    c.r[0] &= 0x1u;  // 0606AE02 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AE04 tst r0,r0
    { const bool k = c.t; c.r[2] += 2; if (k) { goto L_0606AE6C; } }  // 0606AE06 bt/s 0x0606AE6C ; add #2,r2
    c.r[6] = ld32(0x0606AE68u);  // 0606AE0A mov.l 0x0606AE68,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606AE0C mov.b @r2,r2
    c.r[1] = ld32(0x0606AE5Cu);  // 0606AE0E mov.l 0x0606AE5C,r1
    c.r[3] = ld32(c.r[1]);  // 0606AE10 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606AE12 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606AE14 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606AE16 mul.l r1,r2
    c.r[13] = 0x7Fu;  // 0606AE18 mov #127,r13
    c.r[7] = ld32(c.r[6]);  // 0606AE1A mov.l @r6,r7
    c.r[1] = c.macl;  // 0606AE1C sts macl,r1
    c.r[0] = c.r[1];  // 0606AE1E mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606AE20 mov.w @(r0,r3),r1
    c.r[11] = 0x0u;  // 0606AE22 mov #0,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606AE24 mov.b @r7,r2
    c.r[1] += 1;  // 0606AE26 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606AE28 extu.w r1,r1
    c.r[3] = c.r[1];  // 0606AE2A mov r1,r3
    c.r[3] >>= 8;  // 0606AE2C shlr8 r3
    c.r[3] &= c.r[13];  // 0606AE2E and r13,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606AE4Au);  // 0606AE30 mov.w 0x0606AE4A,r0
    c.r[2] &= c.r[0];  // 0606AE32 and r0,r2
    c.r[2] |= c.r[3];  // 0606AE34 or r3,r2
    st8(c.r[7], c.r[2]);  // 0606AE36 mov.b r2,@r7
    c.r[7] += 1;  // 0606AE38 add #1,r7
    st8(c.r[7], c.r[1]);  // 0606AE3A mov.b r1,@r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606AE4Cu);  // 0606AE3C mov.w 0x0606AE4C,r3
    c.r[2] = ld32(c.r[6]);  // 0606AE3E mov.l @r6,r2
    c.r[1] = 0x1u;  // 0606AE40 mov #1,r1
    c.r[0] = c.r[2];  // 0606AE42 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0606AE7C;  // 0606AE44 bra 0x0606AE7C ; mov.b r1,@(r0,r3)
L_0606AE6C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606B008u);  // 0606AE6C mov.w 0x0606B008,r4
    c.r[0] = ld32(0x0606B010u);  // 0606AE6E mov.l 0x0606B010,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606AE74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AE74u) return; }  // 0606AE70 jsr @r0 ; nop
    c.r[0] &= 0xF0u;  // 0606AE74 and #240,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AE76 tst r0,r0
    if (c.t) { goto L_0606AE7C; }  // 0606AE78 bt 0x0606AE7C
    c.r[11] = 0x0u;  // 0606AE7A mov #0,r11
L_0606AE7C:
    c.r[10] = ld32(0x0606B014u);  // 0606AE7C mov.l 0x0606B014,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AE7E mov.b @r10,r1
    c.r[12] = ld32(0x0606B018u);  // 0606AE80 mov.l 0x0606B018,r12
    c.r[2] = ld32(c.r[12]);  // 0606AE82 mov.l @r12,r2
    c.r[7] = c.r[1] & 0xFFu;  // 0606AE84 extu.b r1,r7
    c.r[7] <<= 2;  // 0606AE86 shll2 r7
    c.r[7] <<= 2;  // 0606AE88 shll2 r7
    c.r[3] = c.r[7];  // 0606AE8A mov r7,r3
    c.r[3] += c.r[2];  // 0606AE8C add r2,r3
    c.r[1] = c.r[3];  // 0606AE8E mov r3,r1
    c.r[1] += 4;  // 0606AE90 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AE92 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606AE94 mov r1,r0
    c.r[0] >>= 2;  // 0606AE96 shlr2 r0
    c.r[0] >>= 2;  // 0606AE98 shlr2 r0
    c.r[0] >>= 2;  // 0606AE9A shlr2 r0
    c.r[0] &= 0x1u;  // 0606AE9C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AE9E tst r0,r0
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_0606AEDA; } }  // 0606AEA0 bt/s 0x0606AEDA ; tst r11,r11
    c.r[3] += 5;  // 0606AEA4 add #5,r3
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606AEA6 mov.b @r3,r3
    c.r[3] = c.r[3] & 0xFFu;  // 0606AEA8 extu.b r3,r3
    c.r[3] <<= 2;  // 0606AEAA shll2 r3
    c.r[3] <<= 2;  // 0606AEAC shll2 r3
    c.r[0] = c.r[3];  // 0606AEAE mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606AEB0 mov.b @(r0,r2),r1
    c.r[6] = 0x0u;  // 0606AEB2 mov #0,r6
    c.r[0] = c.r[7];  // 0606AEB4 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606AEB6 mov.b r1,@(r0,r2)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AEB8 mov.b @r10,r2
    c.r[5] = 0x0u;  // 0606AEBA mov #0,r5
    c.r[1] = ld32(c.r[12]);  // 0606AEBC mov.l @r12,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606AEBE extu.b r2,r2
    c.r[2] <<= 2;  // 0606AEC0 shll2 r2
    c.r[2] <<= 2;  // 0606AEC2 shll2 r2
    c.r[2] += c.r[1];  // 0606AEC4 add r1,r2
    c.r[3] += c.r[1];  // 0606AEC6 add r1,r3
    c.r[3] += 1;  // 0606AEC8 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606AECA mov.b @r3,r1
    c.r[2] += 1;  // 0606AECC add #1,r2
    st8(c.r[2], c.r[1]);  // 0606AECE mov.b r1,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AED0 mov.b @r10,r4
    c.r[1] = ld32(0x0606B01Cu);  // 0606AED2 mov.l 0x0606B01C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606AED8u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AED8u) return; }  // 0606AED4 jsr @r1 ; extu.b r4,r4
    c.t = (c.r[11] & c.r[11]) == 0;  // 0606AED8 tst r11,r11
L_0606AEDA:
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_0606AEE2; } }  // 0606AEDA bf/s 0x0606AEE2 ; mov r14,r0
    goto L_0606B2B0;  // 0606AEDE bra 0x0606B2B0 ; nop
L_0606AEE2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AEE2 mov.b @r10,r1
    c.r[2] = ld32(c.r[12]);  // 0606AEE4 mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AEE6 extu.b r1,r1
    c.r[1] <<= 2;  // 0606AEE8 shll2 r1
    c.r[1] <<= 2;  // 0606AEEA shll2 r1
    c.r[1] += c.r[2];  // 0606AEEC add r2,r1
    c.r[1] += 3;  // 0606AEEE add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AEF0 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0606AEF2 and #127,r0
    st8(c.r[1], c.r[0]);  // 0606AEF4 mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AEF6 mov.b @r10,r1
    c.r[2] = ld32(c.r[12]);  // 0606AEF8 mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AEFA extu.b r1,r1
    c.r[1] <<= 2;  // 0606AEFC shll2 r1
    c.r[1] <<= 2;  // 0606AEFE shll2 r1
    c.r[1] += c.r[2];  // 0606AF00 add r2,r1
    c.r[1] += 7;  // 0606AF02 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AF04 mov.b @r1,r0
    c.r[0] |= 0x8u;  // 0606AF06 or #8,r0
    st8(c.r[1], c.r[0]);  // 0606AF08 mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AF0A mov.b @r10,r1
    c.r[2] = ld32(c.r[12]);  // 0606AF0C mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AF0E extu.b r1,r1
    c.r[1] <<= 2;  // 0606AF10 shll2 r1
    c.r[1] <<= 2;  // 0606AF12 shll2 r1
    c.r[1] += c.r[2];  // 0606AF14 add r2,r1
    c.r[1] += 2;  // 0606AF16 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AF18 mov.b @r1,r1
    c.r[9] = 0x1Eu;  // 0606AF1A mov #30,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606AF1C extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 0606AF1E mul.l r9,r1
    c.r[8] = ld32(0x0606B020u);  // 0606AF20 mov.l 0x0606B020,r8
    c.r[2] = ld32(c.r[8]);  // 0606AF22 mov.l @r8,r2
    c.r[1] = c.macl;  // 0606AF24 sts macl,r1
    c.r[1] += c.r[2];  // 0606AF26 add r2,r1
    c.r[1] += 2;  // 0606AF28 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AF2A mov.b @r1,r0
    c.r[0] |= 0x20u;  // 0606AF2C or #32,r0
    st8(c.r[1], c.r[0]);  // 0606AF2E mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AF30 mov.b @r10,r1
    c.r[7] = ld32(c.r[12]);  // 0606AF32 mov.l @r12,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0606AF34 extu.b r1,r2
    c.r[2] <<= 2;  // 0606AF36 shll2 r2
    c.r[2] <<= 2;  // 0606AF38 shll2 r2
    c.r[3] = c.r[2];  // 0606AF3A mov r2,r3
    c.r[3] += c.r[7];  // 0606AF3C add r7,r3
    c.r[1] = c.r[3];  // 0606AF3E mov r3,r1
    c.r[1] += 4;  // 0606AF40 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AF42 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606AF44 mov r1,r0
    c.r[0] >>= 2;  // 0606AF46 shlr2 r0
    c.r[0] >>= 2;  // 0606AF48 shlr2 r0
    c.r[0] >>= 2;  // 0606AF4A shlr2 r0
    c.r[0] &= 0x1u;  // 0606AF4C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AF4E tst r0,r0
    { const bool k = !c.t; c.r[3] += 1; if (k) { goto L_0606AF70; } }  // 0606AF50 bf/s 0x0606AF70 ; add #1,r3
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606AF54 mov.b @r3,r3
    c.r[0] = c.r[2];  // 0606AF56 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606AF58 mov.b @(r0,r7),r2
    c.r[1] = ld32(0x0606B024u);  // 0606AF5A mov.l 0x0606B024,r1
    c.r[1] = ld32(c.r[1]);  // 0606AF5C mov.l @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0606AF5E extu.b r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606AF60 extu.b r2,r2
    c.r[3] <<= 2;  // 0606AF62 shll2 r3
    c.r[3] <<= 2;  // 0606AF64 shll2 r3
    c.r[3] <<= 2;  // 0606AF66 shll2 r3
    c.r[3] += c.r[1];  // 0606AF68 add r1,r3
    c.r[1] = 0xFFFFFFFFu;  // 0606AF6A mov #-1,r1
    c.r[0] = c.r[3];  // 0606AF6C mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606AF6E mov.b r1,@(r0,r2)
L_0606AF70:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AF70 mov.b @r10,r1
    c.r[2] = ld32(c.r[12]);  // 0606AF72 mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AF74 extu.b r1,r1
    c.r[1] <<= 2;  // 0606AF76 shll2 r1
    c.r[1] <<= 2;  // 0606AF78 shll2 r1
    c.r[1] += c.r[2];  // 0606AF7A add r2,r1
    c.r[1] += 4;  // 0606AF7C add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AF7E mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 0606AF80 and #191,r0
    st8(c.r[1], c.r[0]);  // 0606AF82 mov.b r0,@r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AF84 mov.b @r10,r4
    c.r[1] = ld32(0x0606B028u);  // 0606AF86 mov.l 0x0606B028,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606AF8Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606AF8Cu) return; }  // 0606AF88 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606AF8C mov.b @r10,r1
    c.r[2] = ld32(c.r[12]);  // 0606AF8E mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606AF90 extu.b r1,r1
    c.r[1] <<= 2;  // 0606AF92 shll2 r1
    c.r[1] <<= 2;  // 0606AF94 shll2 r1
    c.r[1] += c.r[2];  // 0606AF96 add r2,r1
    c.r[1] += 2;  // 0606AF98 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AF9A mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0606AF9C extu.b r1,r10
    c.macl = c.r[10] * c.r[9];  // 0606AF9E mul.l r9,r10
    c.r[1] = ld32(c.r[8]);  // 0606AFA0 mov.l @r8,r1
    c.r[7] = c.macl;  // 0606AFA2 sts macl,r7
    c.r[7] += c.r[1];  // 0606AFA4 add r1,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0606AFA6 mov.w @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B00Au);  // 0606AFA8 mov.w 0x0606B00A,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0606AFAA extu.w r3,r2
    c.t = c.r[2] == c.r[1];  // 0606AFAC cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606AFB6; } }  // 0606AFAE bf/s 0x0606AFB6 ; mov r3,r1
    c.r[1] -= 1;  // 0606AFB2 add #-1,r1
    st16(c.r[7], c.r[1]);  // 0606AFB4 mov.w r1,@r7
L_0606AFB6:
    c.r[10] = 0x0u;  // 0606AFB6 mov #0,r10
    c.r[9] = 0x0u;  // 0606AFB8 mov #0,r9
L_0606AFBA:
    c.r[7] = c.r[9];  // 0606AFBA mov r9,r7
    c.r[0] = ld32(c.r[12]);  // 0606AFBC mov.l @r12,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606B00Cu);  // 0606AFBE mov.w 0x0606B00C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0606AFC0 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606AFC2 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606AFC4 cmp/eq r2,r1
    { const bool k = !c.t; c.r[7] += c.r[0]; if (k) { goto L_0606AFCE; } }  // 0606AFC6 bf/s 0x0606AFCE ; add r0,r7
    goto L_0606B11E;  // 0606AFCA bra 0x0606B11E ; nop
L_0606AFCE:
    c.r[1] = c.r[7];  // 0606AFCE mov r7,r1
    c.r[1] += 7;  // 0606AFD0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AFD2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606AFD4 mov r1,r0
    c.r[0] >>= 2;  // 0606AFD6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606AFD8 shlr r0
    c.r[0] &= 0x1u;  // 0606AFDA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AFDC tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0606AFE6; } }  // 0606AFDE bt/s 0x0606AFE6 ; mov r7,r1
    goto L_0606B11E;  // 0606AFE2 bra 0x0606B11E ; nop
L_0606AFE6:
    c.r[1] += 4;  // 0606AFE6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AFE8 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0606AFEA extu.b r1,r6
    c.r[0] = c.r[6];  // 0606AFEC mov r6,r0
    c.r[0] >>= 2;  // 0606AFEE shlr2 r0
    c.r[0] >>= 2;  // 0606AFF0 shlr2 r0
    c.r[0] >>= 2;  // 0606AFF2 shlr2 r0
    c.r[0] &= 0x1u;  // 0606AFF4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606AFF6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0606B032; } }  // 0606AFF8 bt/s 0x0606B032 ; mov r7,r1
    c.r[1] += 5;  // 0606AFFC add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606AFFE mov.b @r1,r2
    c.r[3] = ld32(0x0606B014u);  // 0606B000 mov.l 0x0606B014,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606B002 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu; goto L_0606B02C;  // 0606B004 bra 0x0606B02C ; extu.b r2,r2
L_0606B02C:
    c.r[1] = c.r[1] & 0xFFu;  // 0606B02C extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0606B02E cmp/eq r1,r2
    if (c.t) { goto L_0606B050; }  // 0606B030 bt 0x0606B050
L_0606B032:
    c.r[6] >>= 2;  // 0606B032 shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0606B034 shlr r6
    c.r[6] >>= 2;  // 0606B036 shlr2 r6
    c.r[13] = 0x1u;  // 0606B038 mov #1,r13
    c.r[6] &= c.r[13];  // 0606B03A and r13,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0606B03C tst r6,r6
    { const bool k = c.t; c.r[7] += 6; if (k) { goto L_0606B11E; } }  // 0606B03E bt/s 0x0606B11E ; add #6,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606B042 mov.b @r7,r2
    c.r[1] = ld32(0x0606B1E0u);  // 0606B044 mov.l 0x0606B1E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B046 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606B048 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B04A extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0606B04C cmp/eq r1,r2
    if (!c.t) { goto L_0606B11E; }  // 0606B04E bf 0x0606B11E
L_0606B050:
    c.r[1] = ld32(c.r[12]);  // 0606B050 mov.l @r12,r1
    c.r[1] += c.r[9];  // 0606B052 add r9,r1
    c.r[1] += 4;  // 0606B054 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B056 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B1D6u);  // 0606B058 mov.w 0x0606B1D6,r0
    c.r[2] &= c.r[0];  // 0606B05A and r0,r2
    st8(c.r[1], c.r[2]);  // 0606B05C mov.b r2,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B05E mov.l @r12,r1
    c.r[1] += c.r[9];  // 0606B060 add r9,r1
    c.r[1] += 7;  // 0606B062 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B064 mov.b @r1,r2
    c.r[13] = 0x8u;  // 0606B066 mov #8,r13
    c.r[2] |= c.r[13];  // 0606B068 or r13,r2
    st8(c.r[1], c.r[2]);  // 0606B06A mov.b r2,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B06C mov.l @r12,r1
    c.r[1] += c.r[9];  // 0606B06E add r9,r1
    c.r[1] += 2;  // 0606B070 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B072 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0606B074 extu.b r1,r8
    c.r[1] = 0x1Eu;  // 0606B076 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0606B078 mul.l r1,r8
    c.r[0] = ld32(0x0606B1E4u);  // 0606B07A mov.l 0x0606B1E4,r0
    c.r[2] = ld32(c.r[0]);  // 0606B07C mov.l @r0,r2
    c.r[8] = c.macl;  // 0606B07E sts macl,r8
    c.r[2] += c.r[8];  // 0606B080 add r8,r2
    c.r[2] += 2;  // 0606B082 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B084 mov.b @r2,r1
    c.r[13] = 0x20u;  // 0606B086 mov #32,r13
    c.r[1] |= c.r[13];  // 0606B088 or r13,r1
    st8(c.r[2], c.r[1]);  // 0606B08A mov.b r1,@r2
    c.r[1] = ld32(0x0606B1E8u);  // 0606B08C mov.l 0x0606B1E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B092u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B092u) return; }  // 0606B08E jsr @r1 ; extu.b r10,r4
    c.r[0] = ld32(0x0606B1E4u);  // 0606B092 mov.l 0x0606B1E4,r0
    c.r[7] = ld32(c.r[0]);  // 0606B094 mov.l @r0,r7
    c.r[7] += c.r[8];  // 0606B096 add r8,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0606B098 mov.w @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B1D8u);  // 0606B09A mov.w 0x0606B1D8,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0606B09C extu.w r3,r2
    c.t = c.r[2] == c.r[1];  // 0606B09E cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606B0A8; } }  // 0606B0A0 bf/s 0x0606B0A8 ; mov r3,r1
    c.r[1] -= 1;  // 0606B0A4 add #-1,r1
    st16(c.r[7], c.r[1]);  // 0606B0A6 mov.w r1,@r7
L_0606B0A8:
    c.r[11] = 0x0u;  // 0606B0A8 mov #0,r11
    c.r[8] = 0x0u;  // 0606B0AA mov #0,r8
L_0606B0AC:
    c.r[3] = c.r[8];  // 0606B0AC mov r8,r3
    c.r[0] = ld32(c.r[12]);  // 0606B0AE mov.l @r12,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606B1DAu);  // 0606B0B0 mov.w 0x0606B1DA,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606B0B2 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B0B4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606B0B6 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0606B114; } }  // 0606B0B8 bt/s 0x0606B114 ; add r0,r3
    c.r[1] = ld32(c.r[3] + 4);  // 0606B0BC mov.l @(4,r3),r1
    c.r[2] = ld32(0x0606B1ECu);  // 0606B0BE mov.l 0x0606B1EC,r2
    c.r[1] &= c.r[2];  // 0606B0C0 and r2,r1
    c.r[2] = ld32(0x0606B1F0u);  // 0606B0C2 mov.l 0x0606B1F0,r2
    c.t = c.r[1] == c.r[2];  // 0606B0C4 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606B114; } }  // 0606B0C6 bf/s 0x0606B114 ; mov r3,r1
    c.r[1] += 6;  // 0606B0CA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B0CC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B0CE extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0606B0D0 cmp/eq r10,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606B114; } }  // 0606B0D2 bf/s 0x0606B114 ; mov r3,r1
    c.r[1] += 4;  // 0606B0D6 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B0D8 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606B1D6u);  // 0606B0DA mov.w 0x0606B1D6,r13
    c.r[2] &= c.r[13];  // 0606B0DC and r13,r2
    st8(c.r[1], c.r[2]);  // 0606B0DE mov.b r2,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B0E0 mov.l @r12,r1
    c.r[1] += c.r[8];  // 0606B0E2 add r8,r1
    c.r[1] += 7;  // 0606B0E4 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B0E6 mov.b @r1,r2
    c.r[0] = 0x8u;  // 0606B0E8 mov #8,r0
    c.r[2] |= c.r[0];  // 0606B0EA or r0,r2
    st8(c.r[1], c.r[2]);  // 0606B0EC mov.b r2,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B0EE mov.l @r12,r1
    c.r[1] += c.r[8];  // 0606B0F0 add r8,r1
    c.r[1] += 2;  // 0606B0F2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B0F4 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606B0F6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606B0F8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606B0FA mul.l r1,r2
    c.r[13] = ld32(0x0606B1E4u);  // 0606B0FC mov.l 0x0606B1E4,r13
    c.r[3] = ld32(c.r[13]);  // 0606B0FE mov.l @r13,r3
    c.r[1] = c.macl;  // 0606B100 sts macl,r1
    c.r[1] += c.r[3];  // 0606B102 add r3,r1
    c.r[1] += 2;  // 0606B104 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B106 mov.b @r1,r2
    c.r[0] = 0x20u;  // 0606B108 mov #32,r0
    c.r[2] |= c.r[0];  // 0606B10A or r0,r2
    st8(c.r[1], c.r[2]);  // 0606B10C mov.b r2,@r1
    c.r[1] = ld32(0x0606B1E8u);  // 0606B10E mov.l 0x0606B1E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B114u; c.r[4] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B114u) return; }  // 0606B110 jsr @r1 ; extu.b r11,r4
L_0606B114:
    c.r[11] += 1;  // 0606B114 add #1,r11
    c.r[1] = 0x49u;  // 0606B116 mov #73,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 0606B118 cmp/gt r1,r11
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_0606B0AC; } }  // 0606B11A bf/s 0x0606B0AC ; add #16,r8
L_0606B11E:
    c.r[10] += 1;  // 0606B11E add #1,r10
    c.r[1] = 0x49u;  // 0606B120 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606B122 cmp/gt r1,r10
    { const bool k = c.t; c.r[9] += 16; if (k) { goto L_0606B12C; } }  // 0606B124 bt/s 0x0606B12C ; add #16,r9
    SH2_POLL(c); goto L_0606AFBA;  // 0606B128 bra 0x0606AFBA ; nop
L_0606B12C:
    c.r[10] = ld32(0x0606B1E0u);  // 0606B12C mov.l 0x0606B1E0,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606B12E mov.b @r10,r2
    c.r[1] = ld32(0x0606B1F4u);  // 0606B130 mov.l 0x0606B1F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606B132 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606B134 extu.b r2,r2
    c.r[2] <<= 2;  // 0606B136 shll2 r2
    c.r[2] <<= 2;  // 0606B138 shll2 r2
    c.r[2] += c.r[1];  // 0606B13A add r1,r2
    c.r[2] += 2;  // 0606B13C add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B13E mov.b @r2,r2
    c.r[1] = ld32(0x0606B1E4u);  // 0606B140 mov.l 0x0606B1E4,r1
    c.r[3] = ld32(c.r[1]);  // 0606B142 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606B144 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606B146 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606B148 mul.l r1,r2
    c.r[4] = 0x0u;  // 0606B14A mov #0,r4
    c.r[1] = c.macl;  // 0606B14C sts macl,r1
    c.r[0] = c.r[1];  // 0606B14E mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606B150 mov.w @(r0,r3),r5
    c.r[13] = ld32(0x0606B1F8u);  // 0606B152 mov.l 0x0606B1F8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606B158u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B158u) return; }  // 0606B154 jsr @r13 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0606B158 mov r0,r1
    c.r[11] = c.r[1] & 0xFFFFu;  // 0606B15A extu.w r1,r11
    c.r[1] = ld32(0x0606B1FCu);  // 0606B15C mov.l 0x0606B1FC,r1
    c.t = c.r[11] == c.r[1];  // 0606B15E cmp/eq r1,r11
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_0606B17E; } }  // 0606B160 bt/s 0x0606B17E ; mov r11,r2
    c.r[3] = ld32(0x0606B200u);  // 0606B164 mov.l 0x0606B200,r3
    c.r[2] <<= 2;  // 0606B166 shll2 r2
    c.r[7] = ld32(c.r[3]);  // 0606B168 mov.l @r3,r7
    c.r[1] = 0x0u;  // 0606B16A mov #0,r1
    c.r[7] += c.r[2];  // 0606B16C add r2,r7
    c.r[7] += 20;  // 0606B16E add #20,r7
    st8(c.r[7], c.r[1]);  // 0606B170 mov.b r1,@r7
    c.r[1] = ld32(c.r[3]);  // 0606B172 mov.l @r3,r1
    c.r[1] += c.r[2];  // 0606B174 add r2,r1
    c.r[1] += 22;  // 0606B176 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B178 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 0606B17A and #63,r0
    st8(c.r[1], c.r[0]);  // 0606B17C mov.b r0,@r1
L_0606B17E:
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606B1DCu);  // 0606B17E mov.w 0x0606B1DC,r8
    c.r[9] = c.r[14];  // 0606B180 mov r14,r9
    c.r[9] += c.r[8];  // 0606B182 add r8,r9
    c.r[1] = ld32(0x0606B204u);  // 0606B184 mov.l 0x0606B204,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606B186 mov.b @r10,r4
    c.r[5] = c.r[9];  // 0606B188 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606B18Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B18Eu) return; }  // 0606B18A jsr @r1 ; extu.b r4,r4
    c.r[0] = c.r[14];  // 0606B18E mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606B190 mov.b @(r0,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606B1D8u);  // 0606B192 mov.w 0x0606B1D8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B194 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606B196 cmp/hi r2,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606B232; } }  // 0606B198 bt/s 0x0606B232 ; mov #0,r0
    c.r[10] = 0x0u;  // 0606B19C mov #0,r10
    c.r[8] = ld32(0x0606B200u);  // 0606B19E mov.l 0x0606B200,r8
    c.r[0] = c.r[9];  // 0606B1A0 mov r9,r0
L_0606B1A2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0606B1A2 mov.b @(r0,r10),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606B1A4 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B1DAu);  // 0606B1A6 mov.w 0x0606B1DA,r1
    c.t = c.r[2] == c.r[1];  // 0606B1A8 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0606B230; } }  // 0606B1AA bt/s 0x0606B230 ; shll2 r2
    c.r[1] = ld32(0x0606B1F4u);  // 0606B1AE mov.l 0x0606B1F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606B1B0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606B1B2 shll2 r2
    c.r[2] += c.r[1];  // 0606B1B4 add r1,r2
    c.r[2] += 2;  // 0606B1B6 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B1B8 mov.b @r2,r2
    c.r[1] = ld32(0x0606B1E4u);  // 0606B1BA mov.l 0x0606B1E4,r1
    c.r[3] = ld32(c.r[1]);  // 0606B1BC mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606B1BE extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606B1C0 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606B1C2 mul.l r1,r2
    c.r[0] = c.macl;  // 0606B1C4 sts macl,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606B1C6 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 0606B1C8 mov #0,r4
    c.r[0] = ld32(0x0606B1F8u);  // 0606B1CA mov.l 0x0606B1F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606B1D0u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B1D0u) return; }  // 0606B1CC jsr @r0 ; extu.w r5,r5
    c.r[1] = ld32(0x0606B1FCu);  // 0606B1D0 mov.l 0x0606B1FC,r1
    c.r[11] = c.r[0] & 0xFFFFu; goto L_0606B208;  // 0606B1D2 bra 0x0606B208 ; extu.w r0,r11
L_0606B208:
    c.t = c.r[11] == c.r[1];  // 0606B208 cmp/eq r1,r11
    if (c.t) { goto L_0606B226; }  // 0606B20A bt 0x0606B226
    c.r[2] = c.r[11];  // 0606B20C mov r11,r2
    c.r[2] <<= 2;  // 0606B20E shll2 r2
    c.r[3] = ld32(c.r[8]);  // 0606B210 mov.l @r8,r3
    c.r[1] = 0x0u;  // 0606B212 mov #0,r1
    c.r[3] += c.r[2];  // 0606B214 add r2,r3
    c.r[3] += 20;  // 0606B216 add #20,r3
    st8(c.r[3], c.r[1]);  // 0606B218 mov.b r1,@r3
    c.r[1] = ld32(c.r[8]);  // 0606B21A mov.l @r8,r1
    c.r[1] += c.r[2];  // 0606B21C add r2,r1
    c.r[1] += 22;  // 0606B21E add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B220 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 0606B222 and #63,r0
    st8(c.r[1], c.r[0]);  // 0606B224 mov.b r0,@r1
L_0606B226:
    c.r[10] += 1;  // 0606B226 add #1,r10
    c.r[1] = 0x4u;  // 0606B228 mov #4,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606B22A cmp/gt r1,r10
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_0606B1A2; } }  // 0606B22C bf/s 0x0606B1A2 ; mov r9,r0
L_0606B230:
    c.r[0] = 0x0u;  // 0606B230 mov #0,r0
L_0606B232:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606B2A8u);  // 0606B232 mov.w 0x0606B2A8,r13
    c.r[13] += c.r[14];  // 0606B234 add r14,r13
    st32(c.r[13], c.r[0]); goto L_0606B5AC;  // 0606B236 bra 0x0606B5AC ; mov.l r0,@r13
L_0606B23A:
    c.r[13] = ld32(0x0606B2ACu);  // 0606B23A mov.l 0x0606B2AC,r13
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606B2AAu);  // 0606B23C mov.w 0x0606B2AA,r2
    c.r[1] += c.r[2];  // 0606B23E add r2,r1
    c.r[0] = c.r[14];  // 0606B240 mov r14,r0
    c.r[7] = ld32(c.r[13]);  // 0606B242 mov.l @r13,r7
    c.r[1] += 2;  // 0606B244 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0606B246 mov.w @(r0,r2),r2
    c.r[7] += c.r[9];  // 0606B248 add r9,r7
    st16(c.r[7], c.r[2]);  // 0606B24A mov.w r2,@r7
    c.r[2] = c.r[7];  // 0606B24C mov r7,r2
    c.r[2] += 2;  // 0606B24E add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B250 mov.w @r1+,r3
    c.r[7] += 16;  // 0606B252 add #16,r7
    st16(c.r[2], c.r[3]);  // 0606B254 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B256 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B258 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B25A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B25C mov.w @r1+,r3
    c.r[2] += 2;  // 0606B25E add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B260 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B262 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B264 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B266 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B268 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B26A add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B26C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B26E mov.w @r1+,r3
    c.r[2] += 2;  // 0606B270 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B272 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B274 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B276 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B278 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B27A mov.w @r1+,r3
    c.r[2] += 2;  // 0606B27C add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B27E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B280 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B282 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B284 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B286 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B288 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B28A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B28C mov.w @r1+,r3
    c.r[2] += 2;  // 0606B28E add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B290 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B292 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B294 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B296 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B298 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B29A add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B29C mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606B29E mov.w @r1,r1
    c.r[2] += 2;  // 0606B2A0 add #2,r2
    st16(c.r[2], c.r[1]);  // 0606B2A2 mov.w r1,@r2
    st8(c.r[7], c.r[11]); goto L_0606B3DC;  // 0606B2A4 bra 0x0606B3DC ; mov.b r11,@r7
L_0606B2B0:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606B42Cu);  // 0606B2B0 mov.w 0x0606B42C,r7
    c.r[13] = ld32(0x0606B438u);  // 0606B2B2 mov.l 0x0606B438,r13
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606B42Eu);  // 0606B2B4 mov.w 0x0606B42E,r8
    c.r[8] += c.r[14];  // 0606B2B6 add r14,r8
    c.r[9] = ld32(0x0606B43Cu);  // 0606B2B8 mov.l 0x0606B43C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606B2BA mov.b @r10,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606B430u);  // 0606B2BC mov.w 0x0606B430,r6
    c.r[2] = ld32(c.r[12]);  // 0606B2BE mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B2C0 extu.b r1,r1
    c.r[1] <<= 2;  // 0606B2C2 shll2 r1
    c.r[1] <<= 2;  // 0606B2C4 shll2 r1
    c.r[1] += c.r[2];  // 0606B2C6 add r2,r1
    c.r[1] += 2;  // 0606B2C8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B2CA mov.b @r1,r1
    c.r[4] = c.r[8];  // 0606B2CC mov r8,r4
    c.r[11] = c.r[1] & 0xFFu;  // 0606B2CE extu.b r1,r11
    c.r[1] = 0x1Eu;  // 0606B2D0 mov #30,r1
    c.macl = c.r[11] * c.r[1];  // 0606B2D2 mul.l r1,r11
    c.r[3] = ld32(c.r[13]);  // 0606B2D4 mov.l @r13,r3
    c.r[2] = c.r[14];  // 0606B2D6 mov r14,r2
    c.r[1] = c.macl;  // 0606B2D8 sts macl,r1
    c.r[1] += c.r[3];  // 0606B2DA add r3,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B2DC mov.w @r1+,r3
    c.r[2] += c.r[7];  // 0606B2DE add r7,r2
    st16(c.r[0] + c.r[7], c.r[3]);  // 0606B2E0 mov.w r3,@(r0,r7)
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B2E2 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B2E4 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B2E6 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B2E8 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B2EA add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B2EC mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B2EE mov.w @r1+,r3
    c.r[2] += 2;  // 0606B2F0 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B2F2 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B2F4 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B2F6 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B2F8 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B2FA mov.w @r1+,r3
    c.r[2] += 2;  // 0606B2FC add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B2FE mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B300 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B302 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B304 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B306 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B308 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B30A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B30C mov.w @r1+,r3
    c.r[2] += 2;  // 0606B30E add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B310 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B312 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B314 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B316 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B318 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B31A add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B31C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B31E mov.w @r1+,r3
    c.r[2] += 2;  // 0606B320 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B322 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B324 mov.w @r1+,r3
    c.r[2] += 2;  // 0606B326 add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B328 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0606B32A mov.w @r1+,r3
    c.r[2] += 2;  // 0606B32C add #2,r2
    st16(c.r[2], c.r[3]);  // 0606B32E mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606B330 mov.w @r1,r1
    c.r[2] += 2;  // 0606B332 add #2,r2
    st16(c.r[2], c.r[1]);  // 0606B334 mov.w r1,@r2
    c.r[13] = ld32(0x0606B440u);  // 0606B336 mov.l 0x0606B440,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606B33Cu; c.r[5] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B33Cu) return; }  // 0606B338 jsr @r13 ; mov.l @r9,r5
    c.r[0] = ld32(0x0606B444u);  // 0606B33C mov.l 0x0606B444,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606B342u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B342u) return; }  // 0606B33E jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 0606B342 mov r0,r1
    c.r[1] += 1;  // 0606B344 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B346 extu.b r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606B432u);  // 0606B348 mov.w 0x0606B432,r13
    c.r[13] += c.r[14];  // 0606B34A add r14,r13
    st32(c.r[13], c.r[1]);  // 0606B34C mov.l r1,@r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606B34E mov.b @r10,r1
    c.r[2] = ld32(c.r[12]);  // 0606B350 mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B352 extu.b r1,r1
    c.r[1] <<= 2;  // 0606B354 shll2 r1
    c.r[1] <<= 2;  // 0606B356 shll2 r1
    c.r[1] += c.r[2];  // 0606B358 add r2,r1
    c.r[1] += 4;  // 0606B35A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B35C mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606B35E mov #1,r0
    c.r[1] >>= 2;  // 0606B360 shlr2 r1
    c.r[1] >>= 2;  // 0606B362 shlr2 r1
    c.r[1] >>= 2;  // 0606B364 shlr2 r1
    c.r[1] &= c.r[0];  // 0606B366 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606B368 tst r1,r1
    if (c.t) { goto L_0606B37C; }  // 0606B36A bt 0x0606B37C
    c.r[4] = ld32(c.r[9]);  // 0606B36C mov.l @r9,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606B430u);  // 0606B36E mov.w 0x0606B430,r6
    c.r[13] = ld32(0x0606B440u);  // 0606B370 mov.l 0x0606B440,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0606B376u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B376u) return; }  // 0606B372 jsr @r13 ; mov r8,r5
    c.r[13] = 0x0u;  // 0606B376 mov #0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B432u);  // 0606B378 mov.w 0x0606B432,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0606B37A mov.l r13,@(r0,r14)
L_0606B37C:
    c.r[9] = ld32(0x0606B448u);  // 0606B37C mov.l 0x0606B448,r9
    c.r[4] = ld32(c.r[9]);  // 0606B37E mov.l @r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B434u);  // 0606B380 mov.w 0x0606B434,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0606B382 mov.b @(r0,r4),r0
    c.r[0] &= 0xFEu;  // 0606B384 and #254,r0
    c.t = c.r[0] == 0x52u;  // 0606B386 cmp/eq #82,r0
    if (c.t) { goto L_0606B38E; }  // 0606B388 bt 0x0606B38E
    goto L_0606B52C;  // 0606B38A bra 0x0606B52C ; nop
L_0606B38E:
    c.r[10] = 0x0u;  // 0606B38E mov #0,r10
    c.r[12] = ld32(0x0606B44Cu);  // 0606B390 mov.l 0x0606B44C,r12
    c.r[9] = 0x0u;  // 0606B392 mov #0,r9
L_0606B394:
    c.r[0] = ld32(0x0606B438u);  // 0606B394 mov.l 0x0606B438,r0
    c.r[1] = ld32(c.r[0]);  // 0606B396 mov.l @r0,r1
    c.r[0] = c.r[9];  // 0606B398 mov r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606B39A mov.w @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0606B39C extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606B39E tst r8,r8
    if (c.t) { goto L_0606B3D2; }  // 0606B3A0 bt 0x0606B3D2
    c.r[4] = ld32(0x0606B450u);  // 0606B3A2 mov.l 0x0606B450,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0606B3A8u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B3A8u) return; }  // 0606B3A4 jsr @r12 ; mov #27,r5
    c.r[5] = c.r[8];  // 0606B3A8 mov r8,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0606B3AEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B3AEu) return; }  // 0606B3AA jsr @r12 ; mov r0,r4
    c.r[7] = c.r[0];  // 0606B3AE mov r0,r7
    c.r[7] += 7;  // 0606B3B0 add #7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606B3B2 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0606B3B4 mov r1,r0
    c.r[0] &= 0x78u;  // 0606B3B6 and #120,r0
    c.r[0] >>= 2;  // 0606B3B8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606B3BA shlr r0
    c.t = c.r[0] == 0x9u;  // 0606B3BC cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0606B3D2; } }  // 0606B3BE bf/s 0x0606B3D2 ; mov r1,r0
    c.r[0] &= 0x7u;  // 0606B3C2 and #7,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606B3C4 tst r0,r0
    { const bool k = !c.t; c.t = c.r[10] == c.r[11]; if (k) { goto L_0606B3D2; } }  // 0606B3C6 bf/s 0x0606B3D2 ; cmp/eq r11,r10
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0606B3D2; } }  // 0606B3CA bt/s 0x0606B3D2 ; mov r14,r1
    SH2_POLL(c); goto L_0606B23A;  // 0606B3CE bra 0x0606B23A ; nop
L_0606B3D2:
    c.r[10] += 1;  // 0606B3D2 add #1,r10
    c.r[1] = 0x7Fu;  // 0606B3D4 mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606B3D6 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0606B394; } }  // 0606B3D8 bf/s 0x0606B394 ; add #30,r9
L_0606B3DC:
    c.r[10] = 0x0u;  // 0606B3DC mov #0,r10
    c.r[12] = ld32(0x0606B454u);  // 0606B3DE mov.l 0x0606B454,r12
    c.r[11] = 0x0u;  // 0606B3E0 mov #0,r11
L_0606B3E2:
    c.r[3] = c.r[11];  // 0606B3E2 mov r11,r3
    c.r[2] = c.r[3];  // 0606B3E4 mov r3,r2
    c.r[1] = ld32(c.r[12]);  // 0606B3E6 mov.l @r12,r1
    c.r[0] = c.r[3];  // 0606B3E8 mov r3,r0
    c.r[2] += c.r[1];  // 0606B3EA add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606B3EC mov.b @(r0,r1),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606B436u);  // 0606B3EE mov.w 0x0606B436,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0606B3F0 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 0606B3F2 cmp/eq r13,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606B478; } }  // 0606B3F4 bt/s 0x0606B478 ; mov r2,r1
    c.r[1] += 7;  // 0606B3F8 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B3FA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606B3FC mov r1,r0
    c.r[0] >>= 2;  // 0606B3FE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606B400 shlr r0
    c.r[0] &= 0x1u;  // 0606B402 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606B404 tst r0,r0
    if (!c.t) { goto L_0606B478; }  // 0606B406 bf 0x0606B478
    c.r[2] += 2;  // 0606B408 add #2,r2
    c.r[0] = ld32(0x0606B438u);  // 0606B40A mov.l 0x0606B438,r0
    c.r[13] = 0x1Eu;  // 0606B40C mov #30,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B40E mov.b @r2,r1
    c.r[9] = ld32(0x0606B44Cu);  // 0606B410 mov.l 0x0606B44C,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606B412 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 0606B414 mul.l r13,r1
    c.r[5] = 0x1Bu;  // 0606B416 mov #27,r5
    c.r[2] = ld32(c.r[0]);  // 0606B418 mov.l @r0,r2
    c.r[1] = c.macl;  // 0606B41A sts macl,r1
    c.r[0] = c.r[1];  // 0606B41C mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0606B41E mov.w @(r0,r2),r8
    c.r[4] = ld32(0x0606B450u);  // 0606B420 mov.l 0x0606B450,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606B426u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B426u) return; }  // 0606B422 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0606B426 mov r0,r1
    c.r[5] = c.r[8]; goto L_0606B458;  // 0606B428 bra 0x0606B458 ; mov r8,r5
L_0606B458:
    { const uint32_t x = c.r[9]; c.pr = 0x0606B45Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B45Cu) return; }  // 0606B458 jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 0606B45C mov r0,r7
    c.r[7] += 7;  // 0606B45E add #7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606B460 mov.b @r7,r1
    c.r[2] = 0x78u;  // 0606B462 mov #120,r2
    c.r[2] &= c.r[1];  // 0606B464 and r1,r2
    c.r[2] >>= 2;  // 0606B466 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606B468 shlr r2
    c.r[0] = c.r[2];  // 0606B46A mov r2,r0
    c.t = c.r[0] == 0x9u;  // 0606B46C cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0606B478; } }  // 0606B46E bf/s 0x0606B478 ; mov r1,r0
    c.r[0] &= 0x7u;  // 0606B472 and #7,r0
    c.t = c.r[0] == 0x1u;  // 0606B474 cmp/eq #1,r0
    if (c.t) { goto L_0606B486; }  // 0606B476 bt 0x0606B486
L_0606B478:
    c.r[10] += 1;  // 0606B478 add #1,r10
    c.r[1] = 0x49u;  // 0606B47A mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606B47C cmp/gt r1,r10
    { const bool k = !c.t; c.r[11] += 16; if (k) { SH2_POLL(c); goto L_0606B3E2; } }  // 0606B47E bf/s 0x0606B3E2 ; add #16,r11
    goto L_0606B5AC;  // 0606B482 bra 0x0606B5AC ; nop
L_0606B486:
    c.r[4] = c.r[14];  // 0606B486 mov r14,r4
    c.r[1] = ld32(c.r[12]);  // 0606B488 mov.l @r12,r1
    c.r[4] += 48;  // 0606B48A add #48,r4
    c.r[1] += c.r[11];  // 0606B48C add r11,r1
    c.r[1] += 2;  // 0606B48E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B490 mov.b @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606B5E8u);  // 0606B492 mov.w 0x0606B5E8,r6
    c.r[8] = c.r[1] & 0xFFu;  // 0606B494 extu.b r1,r8
    c.r[1] = ld32(0x0606B5F4u);  // 0606B496 mov.l 0x0606B5F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B49Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B49Cu) return; }  // 0606B498 jsr @r1 ; mov r8,r5
    c.r[0] = 0x1Eu;  // 0606B49C mov #30,r0
    c.macl = c.r[8] * c.r[0];  // 0606B49E mul.l r0,r8
    c.r[13] = ld32(0x0606B5F8u);  // 0606B4A0 mov.l 0x0606B5F8,r13
    c.r[1] = ld32(c.r[13]);  // 0606B4A2 mov.l @r13,r1
    c.r[2] = c.macl;  // 0606B4A4 sts macl,r2
    c.r[2] += c.r[1];  // 0606B4A6 add r1,r2
    c.r[1] = c.r[14];  // 0606B4A8 mov r14,r1
    c.r[1] += 74;  // 0606B4AA add #74,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606B4AC mov.w @r1,r1
    c.r[2] += 22;  // 0606B4AE add #22,r2
    st16(c.r[2], c.r[1]);  // 0606B4B0 mov.w r1,@r2
    c.r[1] = c.r[14];  // 0606B4B2 mov r14,r1
    c.r[1] += 62;  // 0606B4B4 add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B4B6 mov.b @r1,r1
    c.r[2] = ld32(0x0606B5FCu);  // 0606B4B8 mov.l 0x0606B5FC,r2
    c.r[2] = ld32(c.r[2]);  // 0606B4BA mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B4BC extu.b r1,r1
    c.r[3] = c.r[1];  // 0606B4BE mov r1,r3
    c.r[3] += c.r[3];  // 0606B4C0 add r3,r3
    c.r[3] += c.r[1];  // 0606B4C2 add r1,r3
    c.r[3] <<= 2;  // 0606B4C4 shll2 r3
    c.r[3] += c.r[2];  // 0606B4C6 add r2,r3
    c.r[3] += 9;  // 0606B4C8 add #9,r3
    c.r[1] = 0x64u;  // 0606B4CA mov #100,r1
    st8(c.r[3], c.r[1]);  // 0606B4CC mov.b r1,@r3
    c.r[1] = ld32(c.r[12]);  // 0606B4CE mov.l @r12,r1
    c.r[1] += c.r[11];  // 0606B4D0 add r11,r1
    c.r[1] += 2;  // 0606B4D2 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B4D4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B4D6 extu.b r1,r1
    c.macl = c.r[1] * c.r[0];  // 0606B4D8 mul.l r0,r1
    c.r[2] = ld32(c.r[13]);  // 0606B4DA mov.l @r13,r2
    c.r[1] = c.macl;  // 0606B4DC sts macl,r1
    c.r[1] += c.r[2];  // 0606B4DE add r2,r1
    c.r[1] += 16;  // 0606B4E0 add #16,r1
    c.r[13] = 0xFFFFFFFFu;  // 0606B4E2 mov #-1,r13
    st8(c.r[1], c.r[13]);  // 0606B4E4 mov.b r13,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B4E6 mov.l @r12,r1
    c.r[1] += c.r[11];  // 0606B4E8 add r11,r1
    c.r[1] += 4;  // 0606B4EA add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B4EC mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B5EAu);  // 0606B4EE mov.w 0x0606B5EA,r0
    c.r[2] &= c.r[0];  // 0606B4F0 and r0,r2
    st8(c.r[1], c.r[2]);  // 0606B4F2 mov.b r2,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B4F4 mov.l @r12,r1
    c.r[1] += c.r[11];  // 0606B4F6 add r11,r1
    c.r[1] += 7;  // 0606B4F8 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B4FA mov.b @r1,r2
    c.r[13] = 0x8u;  // 0606B4FC mov #8,r13
    c.r[2] |= c.r[13];  // 0606B4FE or r13,r2
    st8(c.r[1], c.r[2]);  // 0606B500 mov.b r2,@r1
    c.r[1] = ld32(c.r[12]);  // 0606B502 mov.l @r12,r1
    c.r[11] += c.r[1];  // 0606B504 add r1,r11
    c.r[11] += 2;  // 0606B506 add #2,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0606B508 mov.b @r11,r1
    c.r[13] = 0x1Eu;  // 0606B50A mov #30,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0606B50C extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 0606B50E mul.l r13,r1
    c.r[0] = ld32(0x0606B5F8u);  // 0606B510 mov.l 0x0606B5F8,r0
    c.r[2] = ld32(c.r[0]);  // 0606B512 mov.l @r0,r2
    c.r[1] = c.macl;  // 0606B514 sts macl,r1
    c.r[1] += c.r[2];  // 0606B516 add r2,r1
    c.r[1] += 2;  // 0606B518 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B51A mov.b @r1,r2
    c.r[0] = 0x20u;  // 0606B51C mov #32,r0
    c.r[2] |= c.r[0];  // 0606B51E or r0,r2
    st8(c.r[1], c.r[2]);  // 0606B520 mov.b r2,@r1
    c.r[1] = ld32(0x0606B600u);  // 0606B522 mov.l 0x0606B600,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B528u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B528u) return; }  // 0606B524 jsr @r1 ; extu.b r10,r4
    goto L_0606B5AC;  // 0606B528 bra 0x0606B5AC ; nop
L_0606B52C:
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606B52C mov.b @r10,r6
    c.r[1] = ld32(c.r[12]);  // 0606B52E mov.l @r12,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606B530 extu.b r6,r6
    c.r[2] = c.r[6];  // 0606B532 mov r6,r2
    c.r[2] <<= 2;  // 0606B534 shll2 r2
    c.r[2] <<= 2;  // 0606B536 shll2 r2
    c.r[2] += c.r[1];  // 0606B538 add r1,r2
    c.r[2] += 2;  // 0606B53A add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B53C mov.b @r2,r5
    c.r[1] = ld32(0x0606B5F4u);  // 0606B53E mov.l 0x0606B5F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B544u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B544u) return; }  // 0606B540 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[9]);  // 0606B544 mov.l @r9,r1
    c.r[1] += 14;  // 0606B546 add #14,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B548 mov.b @r1,r5
    c.r[1] = ld32(0x0606B604u);  // 0606B54A mov.l 0x0606B604,r1
    c.r[4] = ld32(c.r[1]);  // 0606B54C mov.l @r1,r4
    c.r[1] = ld32(0x0606B608u);  // 0606B54E mov.l 0x0606B608,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B554u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B554u) return; }  // 0606B550 jsr @r1 ; extu.b r5,r5
    c.r[8] = ld32(0x0606B5FCu);  // 0606B554 mov.l 0x0606B5FC,r8
    c.r[6] = 0x2Eu;  // 0606B556 mov #46,r6
    c.r[1] = ld32(c.r[9]);  // 0606B558 mov.l @r9,r1
    c.r[4] = c.r[14];  // 0606B55A mov r14,r4
    c.r[1] += 14;  // 0606B55C add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B55E mov.b @r1,r1
    c.r[13] = ld32(0x0606B60Cu);  // 0606B560 mov.l 0x0606B60C,r13
    c.r[2] = ld32(c.r[8]);  // 0606B562 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B564 extu.b r1,r1
    c.r[5] = c.r[1];  // 0606B566 mov r1,r5
    c.r[5] += c.r[5];  // 0606B568 add r5,r5
    c.r[5] += c.r[1];  // 0606B56A add r1,r5
    c.r[5] <<= 2;  // 0606B56C shll2 r5
    { const uint32_t x = c.r[13]; c.pr = 0x0606B572u; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B572u) return; }  // 0606B56E jsr @r13 ; add r2,r5
    c.r[1] = ld32(c.r[9]);  // 0606B572 mov.l @r9,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606B574 mov.b @r10,r4
    c.r[1] += 14;  // 0606B576 add #14,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0606B578 extu.b r4,r4
    c.r[2] = c.r[4];  // 0606B57A mov r4,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B57C mov.b @r1,r6
    c.r[2] <<= 2;  // 0606B57E shll2 r2
    c.r[2] <<= 2;  // 0606B580 shll2 r2
    c.r[1] = ld32(c.r[12]);  // 0606B582 mov.l @r12,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606B584 extu.b r6,r6
    c.r[2] += c.r[1];  // 0606B586 add r1,r2
    c.r[2] += 2;  // 0606B588 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B58A mov.b @r2,r5
    c.r[1] = ld32(0x0606B610u);  // 0606B58C mov.l 0x0606B610,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606B592u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B592u) return; }  // 0606B58E jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[9]);  // 0606B592 mov.l @r9,r1
    c.r[6] = 0x2Eu;  // 0606B594 mov #46,r6
    c.r[1] += 14;  // 0606B596 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B598 mov.b @r1,r1
    c.r[5] = c.r[14];  // 0606B59A mov r14,r5
    c.r[2] = ld32(c.r[8]);  // 0606B59C mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B59E extu.b r1,r1
    c.r[4] = c.r[1];  // 0606B5A0 mov r1,r4
    c.r[4] += c.r[4];  // 0606B5A2 add r4,r4
    c.r[4] += c.r[1];  // 0606B5A4 add r1,r4
    c.r[4] <<= 2;  // 0606B5A6 shll2 r4
    { const uint32_t x = c.r[13]; c.pr = 0x0606B5ACu; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B5ACu) return; }  // 0606B5A8 jsr @r13 ; add r2,r4
L_0606B5AC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B5ECu);  // 0606B5AC mov.w 0x0606B5EC,r0
    c.r[0] += c.r[14];  // 0606B5AE add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606B5B0 mov.l @r0,r13
    c.r[13] += c.r[13];  // 0606B5B2 add r13,r13
    st32(c.r[0], c.r[13]);  // 0606B5B4 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B5ECu);  // 0606B5B6 mov.w 0x0606B5EC,r0
    c.r[0] += c.r[14];  // 0606B5B8 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606B5BA mov.l @r0,r13
    c.r[13] += 1;  // 0606B5BC add #1,r13
    st32(c.r[0], c.r[13]);  // 0606B5BE mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B5ECu);  // 0606B5C0 mov.w 0x0606B5EC,r0
    c.r[0] += c.r[14];  // 0606B5C2 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606B5C4 mov.l @r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B5EEu);  // 0606B5C6 mov.w 0x0606B5EE,r1
    c.r[13] |= c.r[1];  // 0606B5C8 or r1,r13
    st32(c.r[0], c.r[13]);  // 0606B5CA mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B5ECu);  // 0606B5CC mov.w 0x0606B5EC,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606B5CE mov.l @(r0,r14),r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606B5F0u);  // 0606B5D0 mov.w 0x0606B5F0,r3
    c.r[14] += c.r[3];  // 0606B5D2 add r3,r14
    c.r[15] = c.r[14];  // 0606B5D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606B5D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606B5D8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606B5DA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606B5DC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606B5DE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606B5E0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606B5E2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606B5E4 rts ; mov.l @r15+,r8
}

void f_0606B614(SH2Context& c) {
    ran[1530] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606B614 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606B616 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606B618 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0606B61A mov r15,r14
    c.r[5] = 0x0u;  // 0606B61C mov #0,r5
    c.r[9] = ld32(0x0606B6C0u);  // 0606B61E mov.l 0x0606B6C0,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606B6BCu);  // 0606B620 mov.w 0x0606B6BC,r8
    c.r[4] = 0x3Fu;  // 0606B622 mov #63,r4
    c.r[6] = 0x0u;  // 0606B624 mov #0,r6
L_0606B626:
    c.r[3] = 0x0u;  // 0606B626 mov #0,r3
L_0606B628:
    c.r[7] = ld32(c.r[9]);  // 0606B628 mov.l @r9,r7
    c.r[7] += c.r[6];  // 0606B62A add r6,r7
    c.r[0] = c.r[7];  // 0606B62C mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606B62E mov.b @(r0,r3),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606B630 extu.b r1,r2
    c.t = c.r[2] == c.r[8];  // 0606B632 cmp/eq r8,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0606B654; } }  // 0606B634 bt/s 0x0606B654 ; shll2 r2
    c.r[1] = ld32(0x0606B6C4u);  // 0606B638 mov.l 0x0606B6C4,r1
    c.r[1] = ld32(c.r[1]);  // 0606B63A mov.l @r1,r1
    c.r[2] <<= 2;  // 0606B63C shll2 r2
    c.r[2] += c.r[1];  // 0606B63E add r1,r2
    c.r[2] += 7;  // 0606B640 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B642 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606B644 mov r1,r0
    c.r[0] >>= 2;  // 0606B646 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606B648 shlr r0
    c.r[0] &= 0x1u;  // 0606B64A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606B64C tst r0,r0
    if (c.t) { goto L_0606B654; }  // 0606B64E bt 0x0606B654
    c.r[0] = c.r[7];  // 0606B650 mov r7,r0
    st8(c.r[0] + c.r[3], c.r[8]);  // 0606B652 mov.b r8,@(r0,r3)
L_0606B654:
    c.r[3] += 1;  // 0606B654 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[4];  // 0606B656 cmp/gt r4,r3
    if (!c.t) { SH2_POLL(c); goto L_0606B628; }  // 0606B658 bf 0x0606B628
    c.r[5] += 1;  // 0606B65A add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[4];  // 0606B65C cmp/gt r4,r5
    { const bool k = !c.t; c.r[6] += 64; if (k) { SH2_POLL(c); goto L_0606B626; } }  // 0606B65E bf/s 0x0606B626 ; add #64,r6
    c.r[6] = 0x0u;  // 0606B662 mov #0,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606B6BCu);  // 0606B664 mov.w 0x0606B6BC,r5
    c.r[3] = 0x0u;  // 0606B666 mov #0,r3
L_0606B668:
    c.r[1] = ld32(0x0606B6C4u);  // 0606B668 mov.l 0x0606B6C4,r1
    c.r[2] = c.r[3];  // 0606B66A mov r3,r2
    c.r[7] = ld32(c.r[1]);  // 0606B66C mov.l @r1,r7
    c.r[0] = c.r[3];  // 0606B66E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606B670 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B672 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 0606B674 cmp/eq r5,r1
    { const bool k = c.t; c.r[2] += c.r[7]; if (k) { goto L_0606B6A6; } }  // 0606B676 bt/s 0x0606B6A6 ; add r7,r2
    c.r[1] = c.r[2];  // 0606B67A mov r2,r1
    c.r[1] += 7;  // 0606B67C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B67E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606B680 mov r1,r0
    c.r[0] >>= 2;  // 0606B682 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606B684 shlr r0
    c.r[0] &= 0x1u;  // 0606B686 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606B688 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606B6A6; } }  // 0606B68A bt/s 0x0606B6A6 ; mov r2,r1
    c.r[1] += 3;  // 0606B68E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B690 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606B692 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606B694 shlr r0
    c.r[0] &= 0x3u;  // 0606B696 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606B698 tst r0,r0
    if (!c.t) { goto L_0606B6A2; }  // 0606B69A bf 0x0606B6A2
    c.r[1] = ld32(c.r[2] + 12);  // 0606B69C mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606B69E tst r1,r1
    if (c.t) { goto L_0606B6A6; }  // 0606B6A0 bt 0x0606B6A6
L_0606B6A2:
    c.r[0] = c.r[3];  // 0606B6A2 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[5]);  // 0606B6A4 mov.b r5,@(r0,r7)
L_0606B6A6:
    c.r[6] += 1;  // 0606B6A6 add #1,r6
    c.r[1] = 0x49u;  // 0606B6A8 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0606B6AA cmp/gt r1,r6
    { const bool k = !c.t; c.r[3] += 16; if (k) { SH2_POLL(c); goto L_0606B668; } }  // 0606B6AC bf/s 0x0606B668 ; add #16,r3
    c.r[15] = c.r[14];  // 0606B6B0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606B6B2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606B6B4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B6BEu);  // 0606B6B6 mov.w 0x0606B6BE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606B6B8 rts ; mov.l @r15+,r8
}

void f_0606B6C8(SH2Context& c) {
    ran[1531] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606B6C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606B6CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606B6CC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606B6CE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606B6D0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606B6D2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606B6D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606B6D6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606B86Cu);  // 0606B6D8 mov.w 0x0606B86C,r3
    c.r[15] += c.r[3];  // 0606B6DA add r3,r15
    c.r[14] = c.r[15];  // 0606B6DC mov r15,r14
    c.r[1] = ld32(0x0606B884u);  // 0606B6DE mov.l 0x0606B884,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B86Eu);  // 0606B6E0 mov.w 0x0606B86E,r0
    c.r[0] += c.r[14];  // 0606B6E2 add r14,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606B870u);  // 0606B6E4 mov.w 0x0606B870,r7
    c.r[3] = c.r[14];  // 0606B6E6 mov r14,r3
    c.r[3] += c.r[7];  // 0606B6E8 add r7,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606B872u);  // 0606B6EA mov.w 0x0606B872,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B6EC mov.b @r1,r1
    c.r[11] = 0x0u;  // 0606B6EE mov #0,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0606B6F0 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0606B6F2 mov.l r1,@r0
    c.r[1] = 0x0u;  // 0606B6F4 mov #0,r1
    c.r[2] = 0x0u;  // 0606B6F6 mov #0,r2
    st32(c.r[3], c.r[1]);  // 0606B6F8 mov.l r1,@r3
    st32(c.r[3] + 4, c.r[2]);  // 0606B6FA mov.l r2,@(4,r3)
    c.r[1] = ld32(0x0606B888u);  // 0606B6FC mov.l 0x0606B888,r1
    c.r[0] = c.r[14];  // 0606B6FE mov r14,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0606B700 mov.l r1,@(r0,r7)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606B874u);  // 0606B702 mov.w 0x0606B874,r2
    c.r[1] = ld32(0x0606B88Cu);  // 0606B704 mov.l 0x0606B88C,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0606B706 mov.l r1,@(r0,r2)
    c.r[2] = c.r[14];  // 0606B708 mov r14,r2
    c.r[2] += c.r[6];  // 0606B70A add r6,r2
    c.r[1] = ld32(0x0606B890u);  // 0606B70C mov.l 0x0606B890,r1
    st32(c.r[0] + c.r[6], c.r[1]);  // 0606B70E mov.l r1,@(r0,r6)
    c.r[1] = ld32(0x0606B894u);  // 0606B710 mov.l 0x0606B894,r1
    st32(c.r[2] + 4, c.r[1]);  // 0606B712 mov.l r1,@(4,r2)
    c.r[3] = c.r[2];  // 0606B714 mov r2,r3
    c.r[3] += 8;  // 0606B716 add #8,r3
    c.r[1] = ld32(0x0606B898u);  // 0606B718 mov.l 0x0606B898,r1
    st32(c.r[2] + 8, c.r[1]);  // 0606B71A mov.l r1,@(8,r2)
    c.r[1] = ld32(0x0606B89Cu);  // 0606B71C mov.l 0x0606B89C,r1
    st32(c.r[3] + 4, c.r[1]);  // 0606B71E mov.l r1,@(4,r3)
    c.r[2] = ld32(0x0606B8A0u);  // 0606B720 mov.l 0x0606B8A0,r2
    c.r[1] = ld32(0x0606B8A4u);  // 0606B722 mov.l 0x0606B8A4,r1
    c.r[7] = 0x1u;  // 0606B724 mov #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B726 mov.b @r1,r1
    c.r[3] = 0x0u;  // 0606B728 mov #0,r3
    st8(c.r[2], c.r[1]);  // 0606B72A mov.b r1,@r2
    c.r[0] = 0x0u;  // 0606B72C mov #0,r0
L_0606B72E:
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606B876u);  // 0606B72E mov.w 0x0606B876,r9
    c.r[9] += c.r[14];  // 0606B730 add r14,r9
    st32(c.r[9], c.r[0]);  // 0606B732 mov.l r0,@r9
    c.r[2] = c.r[11];  // 0606B734 mov r11,r2
    c.r[2] <<= 2;  // 0606B736 shll2 r2
    c.r[2] += c.r[2];  // 0606B738 add r2,r2
    c.r[2] += c.r[14];  // 0606B73A add r14,r2
    c.r[2] += c.r[6];  // 0606B73C add r6,r2
L_0606B73E:
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606B876u);  // 0606B73E mov.w 0x0606B876,r9
    c.r[9] += c.r[14];  // 0606B740 add r14,r9
    c.r[5] = ld32(c.r[9]);  // 0606B742 mov.l @r9,r5
    c.r[5] <<= 2;  // 0606B744 shll2 r5
    c.r[0] = c.r[5];  // 0606B746 mov r5,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606B748 mov.l @(r0,r2),r1
    c.r[1] += 22;  // 0606B74A add #22,r1
    st16(c.r[1], c.r[3]);  // 0606B74C mov.w r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606B74E mov.l @(r0,r2),r1
    c.r[1] += 24;  // 0606B750 add #24,r1
    st16(c.r[1], c.r[3]);  // 0606B752 mov.w r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606B754 mov.l @(r0,r2),r1
    c.r[1] += 26;  // 0606B756 add #26,r1
    st8(c.r[1], c.r[3]);  // 0606B758 mov.b r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606B75A mov.l @(r0,r2),r1
    c.r[1] += 27;  // 0606B75C add #27,r1
    st8(c.r[1], c.r[3]);  // 0606B75E mov.b r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606B760 mov.l @(r0,r2),r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606B876u);  // 0606B762 mov.w 0x0606B876,r9
    c.r[1] += 10;  // 0606B764 add #10,r1
    st16(c.r[1], c.r[3]);  // 0606B766 mov.w r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606B768 mov.l @(r0,r2),r1
    c.r[9] += c.r[14];  // 0606B76A add r14,r9
    c.r[1] += 6;  // 0606B76C add #6,r1
    st16(c.r[1], c.r[3]);  // 0606B76E mov.w r3,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B876u);  // 0606B770 mov.w 0x0606B876,r0
    c.r[1] = ld32(c.r[9]);  // 0606B772 mov.l @r9,r1
    c.r[0] += c.r[14];  // 0606B774 add r14,r0
    c.r[1] += 1;  // 0606B776 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B778 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0606B77A mov.l r1,@r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606B876u);  // 0606B77C mov.w 0x0606B876,r9
    c.r[9] += c.r[14];  // 0606B77E add r14,r9
    c.r[9] = ld32(c.r[9]);  // 0606B780 mov.l @r9,r9
    c.t = c.r[9] > c.r[7];  // 0606B782 cmp/hi r7,r9
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { SH2_POLL(c); goto L_0606B73E; } }  // 0606B784 bf/s 0x0606B73E ; mov r11,r1
    c.r[1] += 1;  // 0606B788 add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606B78A extu.b r1,r11
    c.r[1] = 0x1u;  // 0606B78C mov #1,r1
    c.t = c.r[11] > c.r[1];  // 0606B78E cmp/hi r1,r11
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { SH2_POLL(c); goto L_0606B72E; } }  // 0606B790 bf/s 0x0606B72E ; mov #0,r0
    c.r[11] = 0x0u;  // 0606B794 mov #0,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606B870u);  // 0606B796 mov.w 0x0606B870,r12
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606B878u);  // 0606B798 mov.w 0x0606B878,r9
    c.r[9] += c.r[14];  // 0606B79A add r14,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B87Au);  // 0606B79C mov.w 0x0606B87A,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 0606B79E mov.l r9,@(r0,r14)
    c.t = (c.r[11] & c.r[11]) == 0;  // 0606B7A0 tst r11,r11
L_0606B7A2:
    c.r[13] = c.t;  // 0606B7A2 movt r13
    c.r[9] = c.t;  // 0606B7A4 movt r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606B876u);  // 0606B7A6 mov.w 0x0606B876,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 0606B7A8 mov.l r9,@(r0,r14)
    c.r[0] = ld32(0x0606B8A8u);  // 0606B7AA mov.l 0x0606B8A8,r0
    c.r[9] = ld32(0x0606B8ACu);  // 0606B7AC mov.l 0x0606B8AC,r9
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606B7AE mov.b @(r0,r11),r6
    c.r[8] = ld32(0x0606B8B0u);  // 0606B7B0 mov.l 0x0606B8B0,r8
    c.r[1] = ld32(c.r[9]);  // 0606B7B2 mov.l @r9,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606B7B4 extu.b r6,r6
    c.r[2] = c.r[6];  // 0606B7B6 mov r6,r2
    c.r[2] <<= 2;  // 0606B7B8 shll2 r2
    c.r[2] <<= 2;  // 0606B7BA shll2 r2
    c.r[2] += c.r[1];  // 0606B7BC add r1,r2
    c.r[2] += 2;  // 0606B7BE add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B7C0 mov.b @r2,r5
    c.r[4] = c.r[14];  // 0606B7C2 mov r14,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606B7C8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B7C8u) return; }  // 0606B7C4 jsr @r8 ; extu.b r5,r5
    c.r[0] = ld32(0x0606B8A8u);  // 0606B7C8 mov.l 0x0606B8A8,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0606B7CA mov.b @(r0,r13),r6
    c.r[4] = c.r[14];  // 0606B7CC mov r14,r4
    c.r[1] = ld32(c.r[9]);  // 0606B7CE mov.l @r9,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606B7D0 extu.b r6,r6
    c.r[2] = c.r[6];  // 0606B7D2 mov r6,r2
    c.r[2] <<= 2;  // 0606B7D4 shll2 r2
    c.r[2] <<= 2;  // 0606B7D6 shll2 r2
    c.r[2] += c.r[1];  // 0606B7D8 add r1,r2
    c.r[2] += 2;  // 0606B7DA add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B87Cu);  // 0606B7DC mov.w 0x0606B87C,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B7DE mov.b @r2,r5
    c.r[4] += c.r[1];  // 0606B7E0 add r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606B7E6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B7E6u) return; }  // 0606B7E2 jsr @r8 ; extu.b r5,r5
    c.r[0] = ld32(0x0606B8A8u);  // 0606B7E6 mov.l 0x0606B8A8,r0
    c.r[8] = 0x1Eu;  // 0606B7E8 mov #30,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606B7EA mov.b @(r0,r11),r1
    c.r[10] = ld32(0x0606B8B4u);  // 0606B7EC mov.l 0x0606B8B4,r10
    c.r[2] = ld32(c.r[9]);  // 0606B7EE mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B7F0 extu.b r1,r1
    c.r[1] <<= 2;  // 0606B7F2 shll2 r1
    c.r[1] <<= 2;  // 0606B7F4 shll2 r1
    c.r[1] += c.r[2];  // 0606B7F6 add r2,r1
    c.r[1] += 2;  // 0606B7F8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B7FA mov.b @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606B878u);  // 0606B7FC mov.w 0x0606B878,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0606B7FE extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 0606B800 mul.l r8,r1
    c.r[9] = ld32(0x0606B8B8u);  // 0606B802 mov.l 0x0606B8B8,r9
    c.r[2] = ld32(c.r[9]);  // 0606B804 mov.l @r9,r2
    c.r[1] = c.macl;  // 0606B806 sts macl,r1
    c.r[1] += c.r[2];  // 0606B808 add r2,r1
    c.r[1] += 15;  // 0606B80A add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B80C mov.b @r1,r5
    c.r[4] += c.r[14];  // 0606B80E add r14,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606B814u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B814u) return; }  // 0606B810 jsr @r10 ; extu.b r5,r5
    c.r[0] = ld32(0x0606B8A8u);  // 0606B814 mov.l 0x0606B8A8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0606B816 mov.b @(r0,r13),r1
    c.r[9] = ld32(0x0606B8ACu);  // 0606B818 mov.l 0x0606B8AC,r9
    c.r[2] = ld32(c.r[9]);  // 0606B81A mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B81C extu.b r1,r1
    c.r[1] <<= 2;  // 0606B81E shll2 r1
    c.r[1] <<= 2;  // 0606B820 shll2 r1
    c.r[1] += c.r[2];  // 0606B822 add r2,r1
    c.r[1] += 2;  // 0606B824 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B826 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606B828 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 0606B82A mul.l r8,r1
    c.r[0] = ld32(0x0606B8B8u);  // 0606B82C mov.l 0x0606B8B8,r0
    c.r[2] = ld32(c.r[0]);  // 0606B82E mov.l @r0,r2
    c.r[1] = c.macl;  // 0606B830 sts macl,r1
    c.r[1] += c.r[2];  // 0606B832 add r2,r1
    c.r[1] += 15;  // 0606B834 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B836 mov.b @r1,r5
    c.r[4] = c.r[14];  // 0606B838 mov r14,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0606B83A extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B87Eu);  // 0606B83C mov.w 0x0606B87E,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0606B842u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B842u) return; }  // 0606B83E jsr @r10 ; add r1,r4
    c.r[1] = ld32(0x0606B884u);  // 0606B842 mov.l 0x0606B884,r1
    c.r[0] = c.r[13];  // 0606B844 mov r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606B846 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606B848 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B880u);  // 0606B84A mov.w 0x0606B880,r1
    c.t = c.r[2] == c.r[1];  // 0606B84C cmp/eq r1,r2
    if (c.t) { goto L_0606B85C; }  // 0606B84E bt 0x0606B85C
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B882u);  // 0606B850 mov.w 0x0606B882,r1
    c.t = c.r[2] == c.r[1];  // 0606B852 cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606B8BC; } }  // 0606B854 bt/s 0x0606B8BC ; mov r11,r0
    goto L_0606B8C8;  // 0606B858 bra 0x0606B8C8 ; nop
L_0606B85C:
    c.r[0] = c.r[11];  // 0606B85C mov r11,r0
    c.r[0] <<= 2;  // 0606B85E shll2 r0
    c.r[0] += c.r[14];  // 0606B860 add r14,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B862 mov.l @(r0,r12),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B864 mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 0606B866 and #243,r0
    c.r[0] |= 0x8u; goto L_0606B92C;  // 0606B868 bra 0x0606B92C ; or #8,r0
L_0606B8BC:
    c.r[0] <<= 2;  // 0606B8BC shll2 r0
    c.r[0] += c.r[14];  // 0606B8BE add r14,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B8C0 mov.l @(r0,r12),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B8C2 mov.b @r1,r0
    c.r[0] |= 0xCu; goto L_0606B92C;  // 0606B8C4 bra 0x0606B92C ; or #12,r0
L_0606B8C8:
    c.r[0] = ld32(0x0606B914u);  // 0606B8C8 mov.l 0x0606B914,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606B8CA mov.b @(r0,r11),r1
    c.r[9] = ld32(0x0606B918u);  // 0606B8CC mov.l 0x0606B918,r9
    c.r[2] = ld32(c.r[9]);  // 0606B8CE mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606B8D0 extu.b r1,r1
    c.r[1] <<= 2;  // 0606B8D2 shll2 r1
    c.r[1] <<= 2;  // 0606B8D4 shll2 r1
    c.r[1] += c.r[2];  // 0606B8D6 add r2,r1
    c.r[1] += 10;  // 0606B8D8 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B8DA mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606B8DC mov #1,r0
    c.r[1] >>= 2;  // 0606B8DE shlr2 r1
    c.r[1] >>= 2;  // 0606B8E0 shlr2 r1
    c.r[1] &= c.r[0];  // 0606B8E2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606B8E4 tst r1,r1
    if (!c.t) { goto L_0606B920; }  // 0606B8E6 bf 0x0606B920
    c.r[5] = c.r[14];  // 0606B8E8 mov r14,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606B90Eu);  // 0606B8EA mov.w 0x0606B90E,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606B910u);  // 0606B8EC mov.w 0x0606B910,r2
    c.r[0] = ld32(0x0606B91Cu);  // 0606B8EE mov.l 0x0606B91C,r0
    c.r[5] += c.r[1];  // 0606B8F0 add r1,r5
    c.r[4] = c.r[14];  // 0606B8F2 mov r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0606B8F8u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B8F8u) return; }  // 0606B8F4 jsr @r0 ; add r2,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0606B8F8 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606B8FA tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0606B920; } }  // 0606B8FC bt/s 0x0606B920 ; mov r11,r0
    c.r[0] <<= 2;  // 0606B900 shll2 r0
    c.r[0] += c.r[14];  // 0606B902 add r14,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B904 mov.l @(r0,r12),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B906 mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 0606B908 and #243,r0
    c.r[0] |= 0x4u; goto L_0606B92C;  // 0606B90A bra 0x0606B92C ; or #4,r0
L_0606B920:
    c.r[0] = c.r[11];  // 0606B920 mov r11,r0
    c.r[0] <<= 2;  // 0606B922 shll2 r0
    c.r[0] += c.r[14];  // 0606B924 add r14,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B926 mov.l @(r0,r12),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B928 mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 0606B92A and #243,r0
L_0606B92C:
    st8(c.r[1], c.r[0]);  // 0606B92C mov.b r0,@r1
    c.r[8] = c.r[11];  // 0606B92E mov r11,r8
    c.r[8] <<= 2;  // 0606B930 shll2 r8
    c.r[8] += c.r[14];  // 0606B932 add r14,r8
    c.r[0] = c.r[8];  // 0606B934 mov r8,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB00u);  // 0606B936 mov.w 0x0606BB00,r9
    c.r[9] += c.r[14];  // 0606B938 add r14,r9
    c.r[1] = c.r[14];  // 0606B93A mov r14,r1
    c.r[2] = ld32(c.r[0] + c.r[12]);  // 0606B93C mov.l @(r0,r12),r2
    c.r[1] += 50;  // 0606B93E add #50,r1
    c.r[3] = ld32(c.r[9]);  // 0606B940 mov.l @r9,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB00u);  // 0606B942 mov.w 0x0606BB00,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606B944 mov.l @(r0,r14),r0
    c.r[3] <<= 2;  // 0606B946 shll2 r3
    c.r[3] += c.r[0];  // 0606B948 add r0,r3
    c.r[3] <<= 2;  // 0606B94A shll2 r3
    c.r[0] = c.r[1];  // 0606B94C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606B94E mov.b @(r0,r3),r1
    c.r[9] = 0x7Fu;  // 0606B950 mov #127,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606B952 extu.b r1,r1
    c.r[1] >>= 2;  // 0606B954 shlr2 r1
    c.r[1] >>= 2;  // 0606B956 shlr2 r1
    c.r[1] >>= 2;  // 0606B958 shlr2 r1
    c.r[1] <<= 2;  // 0606B95A shll2 r1
    c.r[1] <<= 2;  // 0606B95C shll2 r1
    c.r[1] += c.r[1];  // 0606B95E add r1,r1
    c.r[1] <<= 2;  // 0606B960 shll2 r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B962 mov.b @r2,r3
    c.r[0] = c.r[8];  // 0606B964 mov r8,r0
    c.r[3] &= c.r[9];  // 0606B966 and r9,r3
    c.r[3] |= c.r[1];  // 0606B968 or r1,r3
    st8(c.r[2], c.r[3]);  // 0606B96A mov.b r3,@r2
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B96C mov.l @(r0,r12),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B96E mov.b @r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB02u);  // 0606B970 mov.w 0x0606BB02,r9
    c.r[2] &= c.r[9];  // 0606B972 and r9,r2
    st8(c.r[1], c.r[2]);  // 0606B974 mov.b r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B976 mov.l @(r0,r12),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B978 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB04u);  // 0606B97A mov.w 0x0606BB04,r0
    c.r[2] &= c.r[0];  // 0606B97C and r0,r2
    st8(c.r[1], c.r[2]);  // 0606B97E mov.b r2,@r1
    c.r[0] = c.r[8];  // 0606B980 mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B982 mov.l @(r0,r12),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B984 mov.b @r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB06u);  // 0606B986 mov.w 0x0606BB06,r9
    c.r[2] &= c.r[9];  // 0606B988 and r9,r2
    st8(c.r[1], c.r[2]);  // 0606B98A mov.b r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B98C mov.l @(r0,r12),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B98E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB08u);  // 0606B990 mov.w 0x0606BB08,r0
    c.r[2] &= c.r[0];  // 0606B992 and r0,r2
    st8(c.r[1], c.r[2]);  // 0606B994 mov.b r2,@r1
    c.r[0] = c.r[8];  // 0606B996 mov r8,r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 0606B998 mov.l @(r0,r12),r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606B99A mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606BB0Au);  // 0606B99C mov.w 0x0606BB0A,r2
    c.r[1] &= c.r[2];  // 0606B99E and r2,r1
    st16(c.r[3], c.r[1]);  // 0606B9A0 mov.w r1,@r3
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B9A2 mov.l @(r0,r12),r1
    c.r[2] = 0x0u;  // 0606B9A4 mov #0,r2
    c.r[1] += 2;  // 0606B9A6 add #2,r1
    st16(c.r[1], c.r[2]);  // 0606B9A8 mov.w r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B9AA mov.l @(r0,r12),r1
    c.r[7] = 0x0u;  // 0606B9AC mov #0,r7
    c.r[1] += 4;  // 0606B9AE add #4,r1
    st16(c.r[1], c.r[2]);  // 0606B9B0 mov.w r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0606B9B2 mov.l @(r0,r12),r1
    c.r[6] = 0x3u;  // 0606B9B4 mov #3,r6
    c.r[1] += 1;  // 0606B9B6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606B9B8 mov.b @r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB02u);  // 0606B9BA mov.w 0x0606BB02,r9
    c.r[2] &= c.r[9];  // 0606B9BC and r9,r2
    st8(c.r[1], c.r[2]);  // 0606B9BE mov.b r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BB0Cu);  // 0606B9C0 mov.w 0x0606BB0C,r1
    c.r[2] = ld32(c.r[0] + c.r[12]);  // 0606B9C2 mov.l @(r0,r12),r2
    c.r[9] = 0x10u;  // 0606B9C4 mov #16,r9
    c.r[0] = c.r[14];  // 0606B9C6 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606B9C8 mov.b @(r0,r1),r1
    c.r[2] += 1;  // 0606B9CA add #1,r2
    c.r[3] = c.r[1];  // 0606B9CC mov r1,r3
    c.r[3] <<= 2;  // 0606B9CE shll2 r3
    c.r[3] &= c.r[9];  // 0606B9D0 and r9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606B9D2 mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB0Eu);  // 0606B9D4 mov.w 0x0606BB0E,r0
    c.r[1] &= c.r[0];  // 0606B9D6 and r0,r1
    c.r[1] |= c.r[3];  // 0606B9D8 or r3,r1
    st8(c.r[2], c.r[1]);  // 0606B9DA mov.b r1,@r2
    c.r[1] = ld32(0x0606BB2Cu);  // 0606B9DC mov.l 0x0606BB2C,r1
    c.r[5] = ld32(c.r[1]);  // 0606B9DE mov.l @r1,r5
    c.r[9] = ld32(0x0606BB30u);  // 0606B9E0 mov.l 0x0606BB30,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0606B9E2 mov.w @r14,r4
    c.r[5] += 20;  // 0606B9E4 add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606B9E6 extu.w r4,r4
    c.r[1] = 0x0u;  // 0606B9E8 mov #0,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0606B9EEu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606B9EEu) return; }  // 0606B9EA jsr @r9 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 0606B9EE mov r0,r1
    c.r[0] = c.r[8];  // 0606B9F0 mov r8,r0
    c.r[15] += 4;  // 0606B9F2 add #4,r15
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606B9F4 extu.w r1,r1
    c.r[9] = 0x1u;  // 0606B9F6 mov #1,r9
    c.t = c.r[9] >= c.r[1];  // 0606B9F8 cmp/hs r1,r9
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB10u);  // 0606B9FA mov.w 0x0606BB10,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606BB12u);  // 0606B9FC mov.w 0x0606BB12,r13
    c.r[10] = c.r[14];  // 0606B9FE mov r14,r10
    c.r[2] = ld32(c.r[0] + c.r[12]);  // 0606BA00 mov.l @(r0,r12),r2
    c.r[6] = 0x5Du;  // 0606BA02 mov #93,r6
    c.r[0] = c.t;  // 0606BA04 movt r0
    c.r[1] = c.r[0];  // 0606BA06 mov r0,r1
    c.r[2] += 1;  // 0606BA08 add #1,r2
    c.r[1] <<= 2;  // 0606BA0A shll2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB14u);  // 0606BA0C mov.w 0x0606BB14,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606BA0E mov.b @r2,r3
    c.r[0] += c.r[14];  // 0606BA10 add r14,r0
    c.r[3] &= c.r[9];  // 0606BA12 and r9,r3
    c.r[3] |= c.r[1];  // 0606BA14 or r1,r3
    st8(c.r[2], c.r[3]);  // 0606BA16 mov.b r3,@r2
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606BA18 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606BA1A mov.l r13,@-r15
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB16u);  // 0606BA1C mov.w 0x0606BB16,r9
    st32(c.r[0], c.r[9]);  // 0606BA1E mov.l r9,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB14u);  // 0606BA20 mov.w 0x0606BB14,r0
    c.r[0] += c.r[14];  // 0606BA22 add r14,r0
    c.r[9] = ld32(c.r[0]);  // 0606BA24 mov.l @r0,r9
    c.r[1] = c.r[11];  // 0606BA26 mov r11,r1
    c.r[9] += c.r[14];  // 0606BA28 add r14,r9
    st32(c.r[0], c.r[9]);  // 0606BA2A mov.l r9,@r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB14u);  // 0606BA2C mov.w 0x0606BB14,r9
    c.r[9] += c.r[14];  // 0606BA2E add r14,r9
    c.r[0] = ld32(c.r[9]);  // 0606BA30 mov.l @r9,r0
    c.r[1] <<= 2;  // 0606BA32 shll2 r1
    c.r[1] += c.r[1];  // 0606BA34 add r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB18u);  // 0606BA36 mov.w 0x0606BB18,r9
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0606BA38 mov.l @(r0,r1),r1
    c.r[9] += c.r[14];  // 0606BA3A add r14,r9
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606BA3C mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BB1Au);  // 0606BA3E mov.w 0x0606BB1A,r1
    c.r[10] += c.r[1];  // 0606BA40 add r1,r10
    c.r[15] -= c.r[1];  // 0606BA42 sub r1,r15
    c.r[1] = ld32(0x0606BB34u);  // 0606BA44 mov.l 0x0606BB34,r1
    c.r[4] = c.r[15];  // 0606BA46 mov r15,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0606BA4Cu; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BA4Cu) return; }  // 0606BA48 jsr @r1 ; mov r10,r5
    c.r[1] = ld32(0x0606BB38u);  // 0606BA4C mov.l 0x0606BB38,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB1Cu);  // 0606BA4E mov.w 0x0606BB1C,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 0606BA50 mov.l @(r0,r14),r7
    c.r[6] = c.r[14];  // 0606BA52 mov r14,r6
    c.r[5] = ld32(c.r[9]);  // 0606BA54 mov.l @r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606BA5Au; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BA5Au) return; }  // 0606BA56 jsr @r1 ; mov r11,r4
    c.r[1] = ld32(0x0606BB3Cu);  // 0606BA5A mov.l 0x0606BB3C,r1
    c.r[0] = c.r[11];  // 0606BA5C mov r11,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606BA5E mov.b @(r0,r1),r3
    c.r[9] = 0x1u;  // 0606BA60 mov #1,r9
    c.r[2] = c.r[3];  // 0606BA62 mov r3,r2
    c.r[2] += 4;  // 0606BA64 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BB1Eu);  // 0606BA66 mov.w 0x0606BB1E,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606BA68 extu.b r2,r2
    c.t = c.r[2] > c.r[9];  // 0606BA6A cmp/hi r9,r2
    { const bool k = !c.t; c.r[15] += c.r[1]; if (k) { goto L_0606BAB0; } }  // 0606BA6C bf/s 0x0606BAB0 ; add r1,r15
    c.r[2] = c.r[3] & 0xFFu;  // 0606BA70 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BB20u);  // 0606BA72 mov.w 0x0606BB20,r1
    c.t = c.r[2] == c.r[1];  // 0606BA74 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0606BAB2; } }  // 0606BA76 bt/s 0x0606BAB2 ; mov r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB18u);  // 0606BA7A mov.w 0x0606BB18,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0606BA7C mov.l @(r0,r14),r1
    c.r[1] <<= 2;  // 0606BA7E shll2 r1
    c.r[1] += c.r[1];  // 0606BA80 add r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB14u);  // 0606BA82 mov.w 0x0606BB14,r9
    c.r[9] += c.r[14];  // 0606BA84 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 0606BA86 mov.l @r9,r0
    c.r[6] = c.r[11];  // 0606BA88 mov r11,r6
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606BB1Cu);  // 0606BA8A mov.w 0x0606BB1C,r9
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0606BA8C mov.l @(r0,r1),r5
    c.r[9] += c.r[14];  // 0606BA8E add r14,r9
    c.r[0] = c.r[8];  // 0606BA90 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BB22u);  // 0606BA92 mov.w 0x0606BB22,r1
    c.r[4] = ld32(c.r[0] + c.r[12]);  // 0606BA94 mov.l @(r0,r12),r4
    c.r[1] += c.r[14];  // 0606BA96 add r14,r1
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606BA98 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606BA9A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606BA9C mov.l r10,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB18u);  // 0606BA9E mov.w 0x0606BB18,r0
    c.r[9] = ld32(c.r[9]);  // 0606BAA0 mov.l @r9,r9
    c.r[0] += c.r[14];  // 0606BAA2 add r14,r0
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606BAA4 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606BAA6 mov.l r14,@-r15
    c.r[1] = ld32(0x0606BB40u);  // 0606BAA8 mov.l 0x0606BB40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606BAAEu; c.r[7] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BAAEu) return; }  // 0606BAAA jsr @r1 ; mov.l @r0,r7
    c.r[15] += 20;  // 0606BAAE add #20,r15
L_0606BAB0:
    c.r[1] = c.r[11];  // 0606BAB0 mov r11,r1
L_0606BAB2:
    c.r[1] += 1;  // 0606BAB2 add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606BAB4 extu.b r1,r11
    c.r[9] = 0x1u;  // 0606BAB6 mov #1,r9
    c.t = c.r[11] > c.r[9];  // 0606BAB8 cmp/hi r9,r11
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_0606BAC2; } }  // 0606BABA bt/s 0x0606BAC2 ; tst r11,r11
    SH2_POLL(c); goto L_0606B7A2;  // 0606BABE bra 0x0606B7A2 ; nop
L_0606BAC2:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606BB16u);  // 0606BAC2 mov.w 0x0606BB16,r5
    c.r[5] += c.r[14];  // 0606BAC4 add r14,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606BB24u);  // 0606BAC6 mov.w 0x0606BB24,r8
    c.r[8] += c.r[14];  // 0606BAC8 add r14,r8
    c.r[1] = ld32(0x0606BB44u);  // 0606BACA mov.l 0x0606BB44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606BAD0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BAD0u) return; }  // 0606BACC jsr @r1 ; mov r8,r4
    c.r[1] = ld32(c.r[8] + 4);  // 0606BAD0 mov.l @(4,r8),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BAD2 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 0606BAD4 and #239,r0
    st8(c.r[1], c.r[0]);  // 0606BAD6 mov.b r0,@r1
    c.r[2] = ld32(c.r[8] + 4);  // 0606BAD8 mov.l @(4,r8),r2
    c.r[1] = 0x0u;  // 0606BADA mov #0,r1
    c.r[3] = c.r[2];  // 0606BADC mov r2,r3
    c.r[3] += 4;  // 0606BADE add #4,r3
    c.r[2] += 2;  // 0606BAE0 add #2,r2
    st16(c.r[2], c.r[1]);  // 0606BAE2 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0606BAE4 mov.w r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606BB26u);  // 0606BAE6 mov.w 0x0606BB26,r3
    c.r[14] += c.r[3];  // 0606BAE8 add r3,r14
    c.r[15] = c.r[14];  // 0606BAEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606BAEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606BAEE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606BAF0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606BAF2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606BAF4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606BAF6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606BAF8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BB28u);  // 0606BAFA mov.w 0x0606BB28,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606BAFC rts ; mov.l @r15+,r8
}

void f_0606BB48(SH2Context& c) {
    ran[1532] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606BB48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606BB4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606BB4C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606BB4E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606BB50 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606BB52 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606BB54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606BB56 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606BCA2u);  // 0606BB58 mov.w 0x0606BCA2,r3
    c.r[15] += c.r[3];  // 0606BB5A add r3,r15
    c.r[14] = c.r[15];  // 0606BB5C mov r15,r14
    c.r[13] = ld32(0x0606BCB0u);  // 0606BB5E mov.l 0x0606BCB0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BCA4u);  // 0606BB60 mov.w 0x0606BCA4,r0
    c.r[0] += c.r[14];  // 0606BB62 add r14,r0
    st32(c.r[0], c.r[13]);  // 0606BB64 mov.l r13,@r0
    c.r[1] = ld32(0x0606BCB4u);  // 0606BB66 mov.l 0x0606BCB4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BB68 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0606BB6A extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606BB6C tst r3,r3
    if (!c.t) { goto L_0606BB92; }  // 0606BB6E bf 0x0606BB92
    c.r[2] = ld32(0x0606BCB8u);  // 0606BB70 mov.l 0x0606BCB8,r2
    c.r[1] = ld32(0x0606BCBCu);  // 0606BB72 mov.l 0x0606BCBC,r1
    st32(c.r[1], c.r[3]);  // 0606BB74 mov.l r3,@r1
    st32(c.r[2], c.r[3]);  // 0606BB76 mov.l r3,@r2
    c.r[7] = ld32(0x0606BCC0u);  // 0606BB78 mov.l 0x0606BCC0,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606BCA6u);  // 0606BB7A mov.w 0x0606BCA6,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606BCA8u);  // 0606BB7C mov.w 0x0606BCA8,r2
    c.r[6] = ld32(c.r[7]);  // 0606BB7E mov.l @r7,r6
    c.r[1] = 0x0u;  // 0606BB80 mov #0,r1
    c.r[6] += c.r[3];  // 0606BB82 add r3,r6
    c.r[0] = c.r[6];  // 0606BB84 mov r6,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606BB86 mov.b r1,@(r0,r2)
    c.r[2] = ld32(c.r[7]);  // 0606BB88 mov.l @r7,r2
    c.r[1] = 0xFFFFFFFFu;  // 0606BB8A mov #-1,r1
    c.r[2] += c.r[3];  // 0606BB8C add r3,r2
    c.r[2] += 4;  // 0606BB8E add #4,r2
    st8(c.r[2], c.r[1]);  // 0606BB90 mov.b r1,@r2
L_0606BB92:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606BCAAu);  // 0606BB92 mov.w 0x0606BCAA,r3
    c.r[11] = c.r[14];  // 0606BB94 mov r14,r11
    c.r[11] += c.r[3];  // 0606BB96 add r3,r11
    c.r[12] = ld32(0x0606BCC4u);  // 0606BB98 mov.l 0x0606BCC4,r12
    c.r[8] = c.r[12];  // 0606BB9A mov r12,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0606BB9C mov.b @r8+,r1
    c.r[13] = ld32(0x0606BCC8u);  // 0606BB9E mov.l 0x0606BCC8,r13
    c.r[2] = ld32(c.r[13]);  // 0606BBA0 mov.l @r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BBA2 extu.b r1,r1
    c.r[1] <<= 2;  // 0606BBA4 shll2 r1
    c.r[1] <<= 2;  // 0606BBA6 shll2 r1
    c.r[1] += c.r[2];  // 0606BBA8 add r2,r1
    c.r[1] += 2;  // 0606BBAA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BBAC mov.b @r1,r1
    c.r[0] = c.r[14];  // 0606BBAE mov r14,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0606BBB0 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606BBB2 mov.b @r8,r1
    c.r[11] += 1;  // 0606BBB4 add #1,r11
    c.r[2] = ld32(c.r[13]);  // 0606BBB6 mov.l @r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BBB8 extu.b r1,r1
    c.r[1] <<= 2;  // 0606BBBA shll2 r1
    c.r[1] <<= 2;  // 0606BBBC shll2 r1
    c.r[1] += c.r[2];  // 0606BBBE add r2,r1
    c.r[1] += 2;  // 0606BBC0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BBC2 mov.b @r1,r1
    c.r[9] = ld32(0x0606BCCCu);  // 0606BBC4 mov.l 0x0606BCCC,r9
    st8(c.r[11], c.r[1]);  // 0606BBC6 mov.b r1,@r11
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606BBC8 mov.b @r12,r6
    c.r[4] = c.r[14];  // 0606BBCA mov r14,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606BBCC mov.b @(r0,r3),r5
    c.r[6] = c.r[6] & 0xFFu;  // 0606BBCE extu.b r6,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0606BBD4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BBD4u) return; }  // 0606BBD0 jsr @r9 ; extu.b r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606BCACu);  // 0606BBD4 mov.w 0x0606BCAC,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606BBD6 mov.b @r8,r1
    c.r[4] += c.r[14];  // 0606BBD8 add r14,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0606BBDA mov.b @r11,r5
    c.r[10] = c.r[1] & 0xFFu;  // 0606BBDC extu.b r1,r10
    c.r[5] = c.r[5] & 0xFFu;  // 0606BBDE extu.b r5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606BBE4u; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BBE4u) return; }  // 0606BBE0 jsr @r9 ; mov r10,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606BCA4u);  // 0606BBE4 mov.w 0x0606BCA4,r13
    c.r[13] += c.r[14];  // 0606BBE6 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0606BBE8 mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606BBEA mov.b @r0,r1
    c.r[13] = 0x1u;  // 0606BBEC mov #1,r13
    c.r[3] = c.r[1] & 0xFFu;  // 0606BBEE extu.b r1,r3
    c.r[1] = c.r[3];  // 0606BBF0 mov r3,r1
    c.r[1] >>= 2;  // 0606BBF2 shlr2 r1
    c.r[1] >>= 2;  // 0606BBF4 shlr2 r1
    c.r[1] >>= 2;  // 0606BBF6 shlr2 r1
    c.r[1] &= c.r[13];  // 0606BBF8 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BBFA tst r1,r1
    if (!c.t) { goto L_0606BC02; }  // 0606BBFC bf 0x0606BC02
    goto L_0606C078;  // 0606BBFE bra 0x0606C078 ; nop
L_0606BC02:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BCA4u);  // 0606BC02 mov.w 0x0606BCA4,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 0606BC04 mov.l @(r0,r14),r5
    c.r[5] += 2;  // 0606BC06 add #2,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0606BC08 mov.w @r5,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606BC0A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BC0C tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0606BC16; } }  // 0606BC0E bf/s 0x0606BC16 ; mov r10,r1
    goto L_0606BF54;  // 0606BC12 bra 0x0606BF54 ; nop
L_0606BC16:
    c.r[13] = ld32(0x0606BCC8u);  // 0606BC16 mov.l 0x0606BCC8,r13
    c.r[2] = ld32(c.r[13]);  // 0606BC18 mov.l @r13,r2
    c.r[1] <<= 2;  // 0606BC1A shll2 r1
    c.r[1] <<= 2;  // 0606BC1C shll2 r1
    c.r[1] += c.r[2];  // 0606BC1E add r2,r1
    c.r[1] += 3;  // 0606BC20 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BC22 mov.b @r1,r1
    c.r[7] = c.r[1];  // 0606BC24 mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0606BC26 shlr r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606BC28 mov.b @r12,r1
    c.r[0] = 0x3u;  // 0606BC2A mov #3,r0
    c.r[6] = c.r[1] & 0xFFu;  // 0606BC2C extu.b r1,r6
    c.r[6] <<= 2;  // 0606BC2E shll2 r6
    c.r[6] <<= 2;  // 0606BC30 shll2 r6
    c.r[6] += c.r[2];  // 0606BC32 add r2,r6
    c.r[1] = c.r[6];  // 0606BC34 mov r6,r1
    c.r[1] += 3;  // 0606BC36 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BC38 mov.b @r1,r1
    c.r[7] &= c.r[0];  // 0606BC3A and r0,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606BC3C shlr r1
    c.r[1] &= c.r[0];  // 0606BC3E and r0,r1
    c.t = c.r[7] == c.r[1];  // 0606BC40 cmp/eq r1,r7
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_0606BC4A; } }  // 0606BC42 bf/s 0x0606BC4A ; tst r1,r1
    goto L_0606BDE6;  // 0606BC46 bra 0x0606BDE6 ; nop
L_0606BC4A:
    if (!c.t) { goto L_0606BCD8; }  // 0606BC4A bf 0x0606BCD8
    c.r[1] = ld32(c.r[6] + 12);  // 0606BC4C mov.l @(12,r6),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BC4E tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606BCD8; } }  // 0606BC50 bt/s 0x0606BCD8 ; mov r3,r0
    c.r[0] >>= 2;  // 0606BC54 shlr2 r0
    c.r[0] >>= 2;  // 0606BC56 shlr2 r0
    c.r[0] &= 0x1u;  // 0606BC58 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606BC5A tst r0,r0
    if (!c.t) { goto L_0606BC62; }  // 0606BC5C bf 0x0606BC62
    goto L_0606BDE6;  // 0606BC5E bra 0x0606BDE6 ; nop
L_0606BC62:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0606BC62 mov.b @r11,r2
    c.r[1] = ld32(0x0606BCD0u);  // 0606BC64 mov.l 0x0606BCD0,r1
    c.r[3] = 0x1Eu;  // 0606BC66 mov #30,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606BC68 extu.b r2,r2
    c.macl = c.r[2] * c.r[3];  // 0606BC6A mul.l r3,r2
    c.r[7] = ld32(c.r[1]);  // 0606BC6C mov.l @r1,r7
    c.r[1] = c.macl;  // 0606BC6E sts macl,r1
    c.r[1] += c.r[7];  // 0606BC70 add r7,r1
    c.r[1] += 22;  // 0606BC72 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606BC74 mov.w @r1,r1
    c.r[6] += 2;  // 0606BC76 add #2,r6
    st16(c.r[5], c.r[1]);  // 0606BC78 mov.w r1,@r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606BC7A mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606BC7C extu.b r1,r1
    c.macl = c.r[1] * c.r[3];  // 0606BC7E mul.l r3,r1
    c.r[1] = c.macl;  // 0606BC80 sts macl,r1
    c.r[1] += c.r[7];  // 0606BC82 add r7,r1
    c.r[1] += 15;  // 0606BC84 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BC86 mov.b @r1,r1
    c.r[2] = ld32(0x0606BCD4u);  // 0606BC88 mov.l 0x0606BCD4,r2
    c.r[2] = ld32(c.r[2]);  // 0606BC8A mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BC8C extu.b r1,r1
    c.r[3] = c.r[1];  // 0606BC8E mov r1,r3
    c.r[3] += c.r[3];  // 0606BC90 add r3,r3
    c.r[3] += c.r[1];  // 0606BC92 add r1,r3
    c.r[3] <<= 2;  // 0606BC94 shll2 r3
    c.r[3] += c.r[2];  // 0606BC96 add r2,r3
    c.r[3] += 6;  // 0606BC98 add #6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606BC9A mov.w @r3,r1
    c.r[1] += 1;  // 0606BC9C add #1,r1
    st16(c.r[3], c.r[1]); goto L_0606BDE6;  // 0606BC9E bra 0x0606BDE6 ; mov.w r1,@r3
L_0606BCD8:
    c.r[8] = ld32(0x0606BE74u);  // 0606BCD8 mov.l 0x0606BE74,r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606BE64u);  // 0606BCDA mov.w 0x0606BE64,r13
    c.r[13] += c.r[14];  // 0606BCDC add r14,r13
    c.r[9] = ld32(0x0606BE78u);  // 0606BCDE mov.l 0x0606BE78,r9
    c.r[0] = ld32(c.r[13]);  // 0606BCE0 mov.l @r13,r0
    c.r[5] = c.r[10];  // 0606BCE2 mov r10,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606BCE4 mov.b @r9,r4
    c.r[13] = 0x1u;  // 0606BCE6 mov #1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606BCE8 mov.b @r0,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0606BCEA extu.b r4,r4
    c.r[1] >>= 2;  // 0606BCEC shlr2 r1
    c.r[1] >>= 2;  // 0606BCEE shlr2 r1
    c.r[1] &= c.r[13];  // 0606BCF0 and r13,r1
    c.r[0] = ld32(0x0606BE7Cu);  // 0606BCF2 mov.l 0x0606BE7C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606BCF8u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BCF8u) return; }  // 0606BCF4 jsr @r0 ; mov r1,r6
    c.r[2] = c.r[0];  // 0606BCF8 mov r0,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606BE64u);  // 0606BCFA mov.w 0x0606BE64,r13
    c.r[13] += c.r[14];  // 0606BCFC add r14,r13
    c.r[1] = ld32(c.r[8]);  // 0606BCFE mov.l @r8,r1
    c.r[5] = c.r[10];  // 0606BD00 mov r10,r5
    c.r[1] += c.r[2];  // 0606BD02 add r2,r1
    st32(c.r[8], c.r[1]);  // 0606BD04 mov.l r1,@r8
    c.r[0] = ld32(c.r[13]);  // 0606BD06 mov.l @r13,r0
    c.r[8] = ld32(0x0606BE80u);  // 0606BD08 mov.l 0x0606BE80,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606BD0A mov.b @r9,r4
    c.r[13] = 0x1u;  // 0606BD0C mov #1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606BD0E mov.b @r0,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0606BD10 extu.b r4,r4
    c.r[1] >>= 2;  // 0606BD12 shlr2 r1
    c.r[1] >>= 2;  // 0606BD14 shlr2 r1
    c.r[1] &= c.r[13];  // 0606BD16 and r13,r1
    c.r[0] = ld32(0x0606BE84u);  // 0606BD18 mov.l 0x0606BE84,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606BD1Eu; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BD1Eu) return; }  // 0606BD1A jsr @r0 ; mov r1,r6
    c.r[2] = c.r[0];  // 0606BD1E mov r0,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606BE64u);  // 0606BD20 mov.w 0x0606BE64,r13
    c.r[1] = ld32(c.r[8]);  // 0606BD22 mov.l @r8,r1
    c.r[13] += c.r[14];  // 0606BD24 add r14,r13
    c.r[1] += c.r[2];  // 0606BD26 add r2,r1
    st32(c.r[8], c.r[1]);  // 0606BD28 mov.l r1,@r8
    c.r[0] = ld32(c.r[13]);  // 0606BD2A mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606BD2C mov.b @r0,r1
    c.r[13] = 0x1u;  // 0606BD2E mov #1,r13
    c.r[1] >>= 2;  // 0606BD30 shlr2 r1
    c.r[1] >>= 2;  // 0606BD32 shlr2 r1
    c.r[1] &= c.r[13];  // 0606BD34 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BD36 tst r1,r1
    { const bool k = c.t; c.r[7] = 0x1Eu; if (k) { goto L_0606BDE6; } }  // 0606BD38 bt/s 0x0606BDE6 ; mov #30,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BE64u);  // 0606BD3C mov.w 0x0606BE64,r0
    c.r[0] += c.r[14];  // 0606BD3E add r14,r0
    c.r[3] = ld32(c.r[0]);  // 0606BD40 mov.l @r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BE66u);  // 0606BD42 mov.w 0x0606BE66,r1
    c.r[1] += c.r[14];  // 0606BD44 add r14,r1
    c.r[1] += 1;  // 0606BD46 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BD48 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606BD4A extu.b r2,r2
    c.r[1] = ld32(0x0606BE88u);  // 0606BD4C mov.l 0x0606BE88,r1
    c.macl = c.r[2] * c.r[7];  // 0606BD4E mul.l r7,r2
    c.r[6] = ld32(c.r[1]);  // 0606BD50 mov.l @r1,r6
    c.r[1] = c.macl;  // 0606BD52 sts macl,r1
    c.r[1] += c.r[6];  // 0606BD54 add r6,r1
    c.r[1] += 22;  // 0606BD56 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606BD58 mov.w @r1,r1
    c.r[3] += 2;  // 0606BD5A add #2,r3
    st16(c.r[3], c.r[1]);  // 0606BD5C mov.w r1,@r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606BD5E mov.b @r9,r2
    c.r[1] = ld32(0x0606BE8Cu);  // 0606BD60 mov.l 0x0606BE8C,r1
    c.r[5] = ld32(c.r[1]);  // 0606BD62 mov.l @r1,r5
    c.r[2] = c.r[2] & 0xFFu;  // 0606BD64 extu.b r2,r2
    c.r[2] <<= 2;  // 0606BD66 shll2 r2
    c.r[2] <<= 2;  // 0606BD68 shll2 r2
    c.r[2] += c.r[5];  // 0606BD6A add r5,r2
    c.r[2] += 2;  // 0606BD6C add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606BD6E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606BD70 extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 0606BD72 mul.l r7,r1
    c.r[1] = c.macl;  // 0606BD74 sts macl,r1
    c.r[1] += c.r[6];  // 0606BD76 add r6,r1
    c.r[1] += 15;  // 0606BD78 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BD7A mov.b @r1,r1
    c.r[2] = ld32(0x0606BE90u);  // 0606BD7C mov.l 0x0606BE90,r2
    c.r[2] = ld32(c.r[2]);  // 0606BD7E mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BD80 extu.b r1,r1
    c.r[3] = c.r[1];  // 0606BD82 mov r1,r3
    c.r[3] += c.r[3];  // 0606BD84 add r3,r3
    c.r[3] += c.r[1];  // 0606BD86 add r1,r3
    c.r[3] <<= 2;  // 0606BD88 shll2 r3
    c.r[3] += c.r[2];  // 0606BD8A add r2,r3
    c.r[3] += 6;  // 0606BD8C add #6,r3
    c.r[10] <<= 2;  // 0606BD8E shll2 r10
    c.r[10] <<= 2;  // 0606BD90 shll2 r10
    c.r[10] += c.r[5];  // 0606BD92 add r5,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606BD94 mov.w @r3,r1
    c.r[10] += 2;  // 0606BD96 add #2,r10
    c.r[1] += 1;  // 0606BD98 add #1,r1
    st16(c.r[3], c.r[1]);  // 0606BD9A mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606BD9C mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606BD9E extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 0606BDA0 mul.l r7,r1
    c.r[1] = c.macl;  // 0606BDA2 sts macl,r1
    c.r[1] += c.r[6];  // 0606BDA4 add r6,r1
    c.r[1] += 26;  // 0606BDA6 add #26,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BDA8 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0606BDAA extu.b r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BE68u);  // 0606BDAC mov.w 0x0606BE68,r1
    c.t = c.r[10] == c.r[1];  // 0606BDAE cmp/eq r1,r10
    if (c.t) { goto L_0606BDE6; }  // 0606BDB0 bt 0x0606BDE6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BE6Au);  // 0606BDB2 mov.w 0x0606BE6A,r1
    c.r[1] += c.r[14];  // 0606BDB4 add r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606BE6Cu);  // 0606BDB6 mov.w 0x0606BE6C,r2
    c.r[0] = c.r[1];  // 0606BDB8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606BDBA mov.b @(r0,r2),r1
    c.r[1] >>= 2;  // 0606BDBC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606BDBE shlr r1
    c.r[1] >>= 2;  // 0606BDC0 shlr2 r1
    c.r[1] &= c.r[13];  // 0606BDC2 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BDC4 tst r1,r1
    if (!c.t) { goto L_0606BDE6; }  // 0606BDC6 bf 0x0606BDE6
    c.r[1] = ld32(0x0606BE94u);  // 0606BDC8 mov.l 0x0606BE94,r1
    c.r[3] = ld32(c.r[1]);  // 0606BDCA mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BE6Eu);  // 0606BDCC mov.w 0x0606BE6E,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BE70u);  // 0606BDCE mov.w 0x0606BE70,r1
    c.r[3] += c.r[1];  // 0606BDD0 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606BDD2 mov.b @(r0,r3),r1
    c.r[2] = c.r[1];  // 0606BDD4 mov r1,r2
    c.r[2] += 1;  // 0606BDD6 add #1,r2
    st8(c.r[0] + c.r[3], c.r[2]);  // 0606BDD8 mov.b r2,@(r0,r3)
    c.r[1] = c.r[1] & 0xFFu;  // 0606BDDA extu.b r1,r1
    c.r[1] <<= 2;  // 0606BDDC shll2 r1
    c.r[1] += c.r[1];  // 0606BDDE add r1,r1
    c.r[3] += c.r[1];  // 0606BDE0 add r1,r3
    c.r[3] += 4;  // 0606BDE2 add #4,r3
    st8(c.r[3], c.r[10]);  // 0606BDE4 mov.b r10,@r3
L_0606BDE6:
    c.r[1] = ld32(0x0606BE98u);  // 0606BDE6 mov.l 0x0606BE98,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BDE8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606BDEA extu.b r1,r1
    c.r[0] = c.r[1];  // 0606BDEC mov r1,r0
    c.r[0] <<= 2;  // 0606BDEE shll2 r0
    c.r[0] += c.r[1];  // 0606BDF0 add r1,r0
    c.r[0] <<= 2;  // 0606BDF2 shll2 r0
    c.r[1] = c.r[14];  // 0606BDF4 mov r14,r1
    c.r[1] += 50;  // 0606BDF6 add #50,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606BDF8 mov.b @(r0,r1),r0
    c.r[0] &= 0x3Fu;  // 0606BDFA and #63,r0
    c.t = c.r[0] == 0x23u;  // 0606BDFC cmp/eq #35,r0
    if (c.t) { goto L_0606BE04; }  // 0606BDFE bt 0x0606BE04
    goto L_0606BF08;  // 0606BE00 bra 0x0606BF08 ; nop
L_0606BE04:
    c.r[8] = ld32(0x0606BE9Cu);  // 0606BE04 mov.l 0x0606BE9C,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606BE06 mov.b @r8,r4
    c.r[9] = ld32(0x0606BEA0u);  // 0606BE08 mov.l 0x0606BEA0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0606BE0Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BE0Eu) return; }  // 0606BE0A jsr @r9 ; extu.b r4,r4
    c.r[10] = 0x0u;  // 0606BE0E mov #0,r10
    c.r[12] = c.r[8];  // 0606BE10 mov r8,r12
    c.r[11] = c.r[9];  // 0606BE12 mov r9,r11
L_0606BE14:
    c.r[1] = ld32(0x0606BE8Cu);  // 0606BE14 mov.l 0x0606BE8C,r1
    c.r[0] = c.r[10];  // 0606BE16 mov r10,r0
    c.r[0] <<= 2;  // 0606BE18 shll2 r0
    c.r[0] <<= 2;  // 0606BE1A shll2 r0
    c.r[1] = ld32(c.r[1]);  // 0606BE1C mov.l @r1,r1
    c.r[3] = c.r[0];  // 0606BE1E mov r0,r3
    c.r[3] += c.r[1];  // 0606BE20 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606BE22 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606BE68u);  // 0606BE24 mov.w 0x0606BE68,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BE26 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606BE28 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606BF00; } }  // 0606BE2A bt/s 0x0606BF00 ; mov r3,r1
    c.r[1] += 7;  // 0606BE2E add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BE30 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606BE32 mov r1,r0
    c.r[0] >>= 2;  // 0606BE34 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606BE36 shlr r0
    c.r[0] &= 0x1u;  // 0606BE38 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606BE3A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606BF00; } }  // 0606BE3C bf/s 0x0606BF00 ; mov r3,r1
    c.r[1] += 4;  // 0606BE40 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BE42 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606BE44 extu.b r1,r7
    c.r[0] = c.r[7];  // 0606BE46 mov r7,r0
    c.r[0] >>= 2;  // 0606BE48 shlr2 r0
    c.r[0] >>= 2;  // 0606BE4A shlr2 r0
    c.r[0] >>= 2;  // 0606BE4C shlr2 r0
    c.r[0] &= 0x1u;  // 0606BE4E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606BE50 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606BEA6; } }  // 0606BE52 bt/s 0x0606BEA6 ; mov r3,r1
    c.r[1] += 5;  // 0606BE56 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BE58 mov.b @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606BE5A mov.b @r12,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606BE5C extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BE5E extu.b r1,r1
    c.t = c.r[2] == c.r[1]; goto L_0606BEA4;  // 0606BE60 bra 0x0606BEA4 ; cmp/eq r1,r2
L_0606BEA4:
    if (c.t) { goto L_0606BEC2; }  // 0606BEA4 bt 0x0606BEC2
L_0606BEA6:
    c.r[7] >>= 2;  // 0606BEA6 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0606BEA8 shlr r7
    c.r[7] >>= 2;  // 0606BEAA shlr2 r7
    c.r[13] = 0x1u;  // 0606BEAC mov #1,r13
    c.r[7] &= c.r[13];  // 0606BEAE and r13,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0606BEB0 tst r7,r7
    if (c.t) { goto L_0606BF00; }  // 0606BEB2 bt 0x0606BF00
    c.r[3] += 6;  // 0606BEB4 add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606BEB6 mov.b @r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606BEB8 mov.b @r12,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606BEBA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606BEBC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0606BEBE cmp/eq r1,r2
    if (!c.t) { goto L_0606BF00; }  // 0606BEC0 bf 0x0606BF00
L_0606BEC2:
    { const uint32_t x = c.r[11]; c.pr = 0x0606BEC6u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BEC6u) return; }  // 0606BEC2 jsr @r11 ; extu.b r10,r4
    c.r[9] = 0x0u;  // 0606BEC6 mov #0,r9
    c.r[8] = 0x0u;  // 0606BEC8 mov #0,r8
L_0606BECA:
    c.r[1] = ld32(0x0606BFFCu);  // 0606BECA mov.l 0x0606BFFC,r1
    c.r[3] = c.r[8];  // 0606BECC mov r8,r3
    c.r[0] = ld32(c.r[1]);  // 0606BECE mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606BFEEu);  // 0606BED0 mov.w 0x0606BFEE,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606BED2 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606BED4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606BED6 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0606BEF6; } }  // 0606BED8 bt/s 0x0606BEF6 ; add r0,r3
    c.r[1] = ld32(c.r[3] + 4);  // 0606BEDC mov.l @(4,r3),r1
    c.r[2] = ld32(0x0606C000u);  // 0606BEDE mov.l 0x0606C000,r2
    c.r[1] &= c.r[2];  // 0606BEE0 and r2,r1
    c.r[2] = ld32(0x0606C004u);  // 0606BEE2 mov.l 0x0606C004,r2
    c.t = c.r[1] == c.r[2];  // 0606BEE4 cmp/eq r2,r1
    if (!c.t) { goto L_0606BEF6; }  // 0606BEE6 bf 0x0606BEF6
    c.r[3] += 6;  // 0606BEE8 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606BEEA mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606BEEC extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0606BEEE cmp/eq r10,r1
    if (!c.t) { goto L_0606BEF6; }  // 0606BEF0 bf 0x0606BEF6
    { const uint32_t x = c.r[11]; c.pr = 0x0606BEF6u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BEF6u) return; }  // 0606BEF2 jsr @r11 ; extu.b r9,r4
L_0606BEF6:
    c.r[9] += 1;  // 0606BEF6 add #1,r9
    c.r[1] = 0x49u;  // 0606BEF8 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0606BEFA cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_0606BECA; } }  // 0606BEFC bf/s 0x0606BECA ; add #16,r8
L_0606BF00:
    c.r[10] += 1;  // 0606BF00 add #1,r10
    c.r[1] = 0x49u;  // 0606BF02 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606BF04 cmp/gt r1,r10
    if (!c.t) { SH2_POLL(c); goto L_0606BE14; }  // 0606BF06 bf 0x0606BE14
L_0606BF08:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BFF0u);  // 0606BF08 mov.w 0x0606BFF0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0606BF0A mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0606BF0C mov r1,r0
    c.r[0] >>= 2;  // 0606BF0E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606BF10 shlr r0
    c.r[0] &= 0x1u;  // 0606BF12 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606BF14 tst r0,r0
    if (c.t) { goto L_0606BF54; }  // 0606BF16 bt 0x0606BF54
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606BFF2u);  // 0606BF18 mov.w 0x0606BFF2,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0606BF1A mov.l @(r0,r14),r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606BF1C mov.b @r13,r1
    c.r[0] = 0x1u;  // 0606BF1E mov #1,r0
    c.r[1] >>= 2;  // 0606BF20 shlr2 r1
    c.r[1] >>= 2;  // 0606BF22 shlr2 r1
    c.r[1] &= c.r[0];  // 0606BF24 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BF26 tst r1,r1
    if (c.t) { goto L_0606BF54; }  // 0606BF28 bt 0x0606BF54
    c.r[1] = ld32(0x0606C008u);  // 0606BF2A mov.l 0x0606C008,r1
    c.r[7] = ld32(c.r[1]);  // 0606BF2C mov.l @r1,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606BFF4u);  // 0606BF2E mov.w 0x0606BFF4,r6
    c.r[7] += 18;  // 0606BF30 add #18,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0606BF32 mov.w @r7,r3
    c.r[1] = 0x4u;  // 0606BF34 mov #4,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0606BF36 extu.w r3,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606BF38 shlr r2
    c.r[2] &= c.r[6];  // 0606BF3A and r6,r2
    c.t = c.r[2] > c.r[1];  // 0606BF3C cmp/hi r1,r2
    { const bool k = c.t; c.r[2] -= 5; if (k) { goto L_0606BF48; } }  // 0606BF3E bt/s 0x0606BF48 ; add #-5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BFF6u);  // 0606BF42 mov.w 0x0606BFF6,r1
    c.r[1] &= c.r[3]; goto L_0606BF52;  // 0606BF44 bra 0x0606BF52 ; and r3,r1
L_0606BF48:
    c.r[2] &= c.r[6];  // 0606BF48 and r6,r2
    c.r[2] += c.r[2];  // 0606BF4A add r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BFF6u);  // 0606BF4C mov.w 0x0606BFF6,r1
    c.r[1] &= c.r[3];  // 0606BF4E and r3,r1
    c.r[1] |= c.r[2];  // 0606BF50 or r2,r1
L_0606BF52:
    st16(c.r[7], c.r[1]);  // 0606BF52 mov.w r1,@r7
L_0606BF54:
    c.r[13] = ld32(0x0606C00Cu);  // 0606BF54 mov.l 0x0606C00C,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606BF56 mov.b @r13,r1
    c.r[0] = 0x1Fu;  // 0606BF58 mov #31,r0
    c.r[1] &= c.r[0];  // 0606BF5A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BF5C tst r1,r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0606C026; } }  // 0606BF5E bt/s 0x0606C026 ; mov #0,r10
    c.r[2] = ld32(0x0606C010u);  // 0606BF62 mov.l 0x0606C010,r2
    c.r[1] = c.r[2];  // 0606BF64 mov r2,r1
    c.r[1] += 1;  // 0606BF66 add #1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0606BFF8u);  // 0606BF68 mov.w 0x0606BFF8,r6
    c.r[6] += c.r[14];  // 0606BF6A add r14,r6
    c.r[4] = c.r[14];  // 0606BF6C mov r14,r4
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BF6E mov.b @r1,r7
    c.r[13] = ld32(0x0606C014u);  // 0606BF70 mov.l 0x0606C014,r13
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606BF72 mov.b @r2,r5
    c.r[7] = c.r[7] & 0xFFu;  // 0606BF74 extu.b r7,r7
    c.r[5] = c.r[5] & 0xFFu;  // 0606BF76 extu.b r5,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0606BF7Cu; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606BF7Cu) return; }  // 0606BF78 jsr @r13 ; mov.l r10,@-r15
    c.r[6] = c.r[0];  // 0606BF7C mov r0,r6
    c.r[0] = 0xFu;  // 0606BF7E mov #15,r0
    c.r[6] &= c.r[0];  // 0606BF80 and r0,r6
    c.r[1] = 0x7u;  // 0606BF82 mov #7,r1
    c.r[2] = c.r[6];  // 0606BF84 mov r6,r2
    c.r[2] -= 1;  // 0606BF86 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0606BF88 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0606BFB0; } }  // 0606BF8A bt/s 0x0606BFB0 ; add #4,r15
    c.r[1] = c.r[2];  // 0606BF8E mov r2,r1
    c.r[1] += c.r[1];  // 0606BF90 add r1,r1
    c.r[0] = 0x0606BF9Cu;  // 0606BF92 mova 0x0606BF9C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606BF94 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0606BF96 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0606BFACu: goto L_0606BFAC; case 0x0606BFB0u: goto L_0606BFB0; default: sh2_call(c, x); return; } }  // 0606BF98 jmp @r0 ; nop
L_0606BFAC:
    c.r[7] = 0x5u; goto L_0606BFB2;  // 0606BFAC bra 0x0606BFB2 ; mov #5,r7
L_0606BFB0:
    c.r[7] = 0x0u;  // 0606BFB0 mov #0,r7
L_0606BFB2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606BFFAu);  // 0606BFB2 mov.w 0x0606BFFA,r1
    c.r[1] += c.r[14];  // 0606BFB4 add r14,r1
    c.r[1] += 1;  // 0606BFB6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606BFB8 mov.b @r1,r2
    c.r[1] = ld32(0x0606C018u);  // 0606BFBA mov.l 0x0606C018,r1
    c.r[3] = ld32(c.r[1]);  // 0606BFBC mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606BFBE extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606BFC0 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606BFC2 mul.l r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606BFF2u);  // 0606BFC4 mov.w 0x0606BFF2,r13
    c.r[2] = c.macl;  // 0606BFC6 sts macl,r2
    c.r[2] += c.r[3];  // 0606BFC8 add r3,r2
    c.r[2] += 24;  // 0606BFCA add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606BFCC mov.w @r2,r1
    c.r[13] += c.r[14];  // 0606BFCE add r14,r13
    c.r[1] -= c.r[7];  // 0606BFD0 sub r7,r1
    st16(c.r[2], c.r[1]);  // 0606BFD2 mov.w r1,@r2
    c.r[0] = ld32(c.r[13]);  // 0606BFD4 mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606BFD6 mov.b @r0,r1
    c.r[13] = 0x1u;  // 0606BFD8 mov #1,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606BFDA shlr r1
    c.r[1] &= c.r[13];  // 0606BFDC and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606BFDE tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_0606C01C; } }  // 0606BFE0 bt/s 0x0606C01C ; mov r6,r0
    c.t = c.r[0] == 0x6u;  // 0606BFE4 cmp/eq #6,r0
    { const bool k = !c.t; c.r[10] = 0x3Au; if (k) { goto L_0606C052; } }  // 0606BFE6 bf/s 0x0606C052 ; mov #58,r10
    c.r[10] = 0x37u; goto L_0606C052;  // 0606BFEA bra 0x0606C052 ; mov #55,r10
L_0606C01C:
    c.t = c.r[0] == 0x6u;  // 0606C01C cmp/eq #6,r0
    { const bool k = !c.t; c.r[10] = 0x39u; if (k) { goto L_0606C052; } }  // 0606C01E bf/s 0x0606C052 ; mov #57,r10
    c.r[10] = 0x40u; goto L_0606C052;  // 0606C022 bra 0x0606C052 ; mov #64,r10
L_0606C026:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606C120u);  // 0606C026 mov.w 0x0606C120,r13
    c.r[13] += c.r[14];  // 0606C028 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0606C02A mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606C02C mov.b @r0,r1
    c.r[13] = 0x1u;  // 0606C02E mov #1,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0606C030 extu.b r1,r1
    c.r[2] = c.r[1];  // 0606C032 mov r1,r2
    c.r[2] >>= 2;  // 0606C034 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606C036 shlr r2
    c.r[2] >>= 2;  // 0606C038 shlr2 r2
    c.r[2] &= c.r[13];  // 0606C03A and r13,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0606C03C tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0606C046; } }  // 0606C03E bt/s 0x0606C046 ; mov r1,r0
    c.r[10] = 0x38u; goto L_0606C052;  // 0606C042 bra 0x0606C052 ; mov #56,r10
L_0606C046:
    c.r[0] >>= 2;  // 0606C046 shlr2 r0
    c.r[0] &= 0x3u;  // 0606C048 and #3,r0
    c.t = c.r[0] == 0x2u;  // 0606C04A cmp/eq #2,r0
    { const bool k = !c.t; c.r[10] = 0x37u; if (k) { goto L_0606C052; } }  // 0606C04C bf/s 0x0606C052 ; mov #55,r10
    c.r[10] = 0xFu;  // 0606C050 mov #15,r10
L_0606C052:
    c.t = (c.r[10] & c.r[10]) == 0;  // 0606C052 tst r10,r10
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_0606C078; } }  // 0606C054 bt/s 0x0606C078 ; mov r10,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C120u);  // 0606C058 mov.w 0x0606C120,r0
    c.r[0] += c.r[14];  // 0606C05A add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0606C05C mov.l @r0,r13
    c.r[13] += 2;  // 0606C05E add #2,r13
    st32(c.r[0], c.r[13]);  // 0606C060 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C120u);  // 0606C062 mov.w 0x0606C120,r0
    c.r[0] += c.r[14];  // 0606C064 add r14,r0
    c.r[1] = ld32(0x0606C130u);  // 0606C066 mov.l 0x0606C130,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C068 mov.b @r1,r4
    c.r[13] = ld32(c.r[0]);  // 0606C06A mov.l @r0,r13
    c.r[4] = c.r[4] & 0xFFu;  // 0606C06C extu.b r4,r4
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0606C06E mov.w @r13,r6
    c.r[1] = ld32(0x0606C134u);  // 0606C070 mov.l 0x0606C134,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 0606C072 extu.w r6,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0606C078u; c.r[6] = 0u - c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C078u) return; }  // 0606C074 jsr @r1 ; neg r6,r6
L_0606C078:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C122u);  // 0606C078 mov.w 0x0606C122,r1
    c.r[1] += c.r[14];  // 0606C07A add r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606C124u);  // 0606C07C mov.w 0x0606C124,r2
    c.r[0] = c.r[1];  // 0606C07E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606C080 mov.b @(r0,r2),r1
    c.r[13] = 0x1u;  // 0606C082 mov #1,r13
    c.r[1] >>= 2;  // 0606C084 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606C086 shlr r1
    c.r[1] &= c.r[13];  // 0606C088 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606C08A tst r1,r1
    if (c.t) { goto L_0606C0AC; }  // 0606C08C bt 0x0606C0AC
    c.r[1] = ld32(0x0606C138u);  // 0606C08E mov.l 0x0606C138,r1
    c.r[3] = ld32(c.r[1]);  // 0606C090 mov.l @r1,r3
    c.r[3] += 18;  // 0606C092 add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606C094 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C126u);  // 0606C096 mov.w 0x0606C126,r1
    c.r[7] = c.r[2] & 0xFFFFu;  // 0606C098 extu.w r2,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0606C09A shlr r7
    c.r[7] &= c.r[1];  // 0606C09C and r1,r7
    c.r[7] += 3;  // 0606C09E add #3,r7
    c.r[7] &= c.r[1];  // 0606C0A0 and r1,r7
    c.r[7] += c.r[7];  // 0606C0A2 add r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C128u);  // 0606C0A4 mov.w 0x0606C128,r1
    c.r[2] &= c.r[1];  // 0606C0A6 and r1,r2
    c.r[2] |= c.r[7];  // 0606C0A8 or r7,r2
    st16(c.r[3], c.r[2]);  // 0606C0AA mov.w r2,@r3
L_0606C0AC:
    c.r[2] = ld32(0x0606C13Cu);  // 0606C0AC mov.l 0x0606C13C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C0AE mov.b @r2,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606C0B0 extu.b r1,r7
    c.r[1] = ld32(0x0606C140u);  // 0606C0B2 mov.l 0x0606C140,r1
    c.r[3] = ld32(c.r[1]);  // 0606C0B4 mov.l @r1,r3
    c.r[7] <<= 2;  // 0606C0B6 shll2 r7
    c.r[7] <<= 2;  // 0606C0B8 shll2 r7
    c.r[7] += c.r[3];  // 0606C0BA add r3,r7
    c.r[1] = c.r[7];  // 0606C0BC mov r7,r1
    c.r[1] += 3;  // 0606C0BE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C0C0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606C0C2 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606C0C4 shlr r0
    c.r[0] &= 0x3u;  // 0606C0C6 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C0C8 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606C0E8; } }  // 0606C0CA bt/s 0x0606C0E8 ; mov r2,r1
    c.r[1] += 1;  // 0606C0CE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C0D0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C0D2 extu.b r1,r1
    c.r[1] <<= 2;  // 0606C0D4 shll2 r1
    c.r[1] <<= 2;  // 0606C0D6 shll2 r1
    c.r[1] += c.r[3];  // 0606C0D8 add r3,r1
    c.r[1] += 3;  // 0606C0DA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C0DC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606C0DE mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606C0E0 shlr r0
    c.r[0] &= 0x3u;  // 0606C0E2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C0E4 tst r0,r0
    if (!c.t) { goto L_0606C106; }  // 0606C0E6 bf 0x0606C106
L_0606C0E8:
    c.r[2] += 1;  // 0606C0E8 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C0EA mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C0EC extu.b r1,r1
    c.r[1] <<= 2;  // 0606C0EE shll2 r1
    c.r[1] <<= 2;  // 0606C0F0 shll2 r1
    c.r[1] += c.r[3];  // 0606C0F2 add r3,r1
    c.r[1] += 7;  // 0606C0F4 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C0F6 mov.b @r1,r0
    c.r[0] |= 0x4u;  // 0606C0F8 or #4,r0
    st8(c.r[1], c.r[0]);  // 0606C0FA mov.b r0,@r1
    c.r[1] = c.r[7];  // 0606C0FC mov r7,r1
    c.r[1] += 7;  // 0606C0FE add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C100 mov.b @r1,r0
    c.r[0] |= 0x4u;  // 0606C102 or #4,r0
    st8(c.r[1], c.r[0]);  // 0606C104 mov.b r0,@r1
L_0606C106:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606C12Au);  // 0606C106 mov.w 0x0606C12A,r3
    c.r[14] += c.r[3];  // 0606C108 add r3,r14
    c.r[15] = c.r[14];  // 0606C10A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C10C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C10E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606C110 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606C112 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606C114 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606C116 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606C118 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C12Cu);  // 0606C11A mov.w 0x0606C12C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C11C rts ; mov.l @r15+,r8
}

void f_0606C144(SH2Context& c) {
    ran[1533] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C144 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0606C146 extu.b r4,r4
    c.r[1] = ld32(0x0606C1DCu);  // 0606C148 mov.l 0x0606C1DC,r1
    c.r[1] = ld32(c.r[1]);  // 0606C14A mov.l @r1,r1
    c.r[4] <<= 2;  // 0606C14C shll2 r4
    c.r[4] <<= 2;  // 0606C14E shll2 r4
    c.r[4] += c.r[1];  // 0606C150 add r1,r4
    c.r[4] += 2;  // 0606C152 add #2,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0606C154 mov.b @r4,r2
    c.r[1] = ld32(0x0606C1E0u);  // 0606C156 mov.l 0x0606C1E0,r1
    c.r[3] = ld32(c.r[1]);  // 0606C158 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606C15A extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606C15C mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606C15E mul.l r1,r2
    c.r[1] = c.macl;  // 0606C160 sts macl,r1
    c.r[1] += c.r[3];  // 0606C162 add r3,r1
    c.r[1] += 15;  // 0606C164 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C166 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606C168 extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C1DAu);  // 0606C16A mov.w 0x0606C1DA,r1
    c.t = c.r[7] == c.r[1];  // 0606C16C cmp/eq r1,r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606C1D4; } }  // 0606C16E bt/s 0x0606C1D4 ; mov r15,r14
    c.r[5] = ld32(0x0606C1E4u);  // 0606C172 mov.l 0x0606C1E4,r5
    c.r[4] = c.r[1];  // 0606C174 mov r1,r4
    c.r[3] = c.r[7];  // 0606C176 mov r7,r3
L_0606C178:
    c.r[3] += c.r[3];  // 0606C178 add r3,r3
    c.r[3] += c.r[7];  // 0606C17A add r7,r3
    c.r[1] = ld32(c.r[5]);  // 0606C17C mov.l @r5,r1
    c.r[3] <<= 2;  // 0606C17E shll2 r3
    c.r[3] += c.r[1];  // 0606C180 add r1,r3
    c.r[3] += 9;  // 0606C182 add #9,r3
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606C184 mov.b @r3,r6
    c.r[1] = 0x31u;  // 0606C186 mov #49,r1
    c.r[2] = c.r[6] & 0xFFu;  // 0606C188 extu.b r6,r2
    c.r[2] -= 10;  // 0606C18A add #-10,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606C18C cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0606C196; } }  // 0606C18E bf/s 0x0606C196 ; mov r6,r1
    c.r[1] -= 10; goto L_0606C198;  // 0606C192 bra 0x0606C198 ; add #-10,r1
L_0606C196:
    c.r[1] = 0x32u;  // 0606C196 mov #50,r1
L_0606C198:
    st8(c.r[3], c.r[1]);  // 0606C198 mov.b r1,@r3
    c.r[2] = c.r[7];  // 0606C19A mov r7,r2
    c.r[2] += c.r[2];  // 0606C19C add r2,r2
    c.r[2] += c.r[7];  // 0606C19E add r7,r2
    c.r[1] = ld32(c.r[5]);  // 0606C1A0 mov.l @r5,r1
    c.r[2] <<= 2;  // 0606C1A2 shll2 r2
    c.r[2] += c.r[1];  // 0606C1A4 add r1,r2
    c.r[2] += 10;  // 0606C1A6 add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606C1A8 mov.w @r2,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0606C1AA extu.w r3,r1
    c.r[1] -= 10;  // 0606C1AC add #-10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606C1AE cmp/pz r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606C1B8; } }  // 0606C1B0 bf/s 0x0606C1B8 ; mov r3,r1
    c.r[1] -= 10; goto L_0606C1BA;  // 0606C1B4 bra 0x0606C1BA ; add #-10,r1
L_0606C1B8:
    c.r[1] = 0x0u;  // 0606C1B8 mov #0,r1
L_0606C1BA:
    st16(c.r[2], c.r[1]);  // 0606C1BA mov.w r1,@r2
    c.r[2] = c.r[7];  // 0606C1BC mov r7,r2
    c.r[2] += c.r[2];  // 0606C1BE add r2,r2
    c.r[2] += c.r[7];  // 0606C1C0 add r7,r2
    c.r[1] = ld32(c.r[5]);  // 0606C1C2 mov.l @r5,r1
    c.r[2] <<= 2;  // 0606C1C4 shll2 r2
    c.r[2] += c.r[1];  // 0606C1C6 add r1,r2
    c.r[2] += 8;  // 0606C1C8 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C1CA mov.b @r2,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606C1CC extu.b r1,r7
    c.t = c.r[7] == c.r[4];  // 0606C1CE cmp/eq r4,r7
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { SH2_POLL(c); goto L_0606C178; } }  // 0606C1D0 bf/s 0x0606C178 ; mov r7,r3
L_0606C1D4:
    c.r[15] = c.r[14];  // 0606C1D4 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C1D6 rts ; mov.l @r15+,r14
}

void f_0606C1E8(SH2Context& c) {
    ran[1534] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C1E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606C1EA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C1EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C1EE sts.l pr,@-r15
    c.r[1] = ld32(0x0606C2C4u);  // 0606C1F0 mov.l 0x0606C2C4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C1F2 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0606C1F4 and #127,r0
    st8(c.r[1], c.r[0]);  // 0606C1F6 mov.b r0,@r1
    c.r[1] = ld32(0x0606C2C8u);  // 0606C1F8 mov.l 0x0606C2C8,r1
    c.r[3] = ld32(c.r[1]);  // 0606C1FA mov.l @r1,r3
    c.r[1] = ld32(0x0606C2CCu);  // 0606C1FC mov.l 0x0606C2CC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C1FE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C200 extu.b r1,r1
    c.r[2] = c.r[1];  // 0606C202 mov r1,r2
    c.r[2] <<= 2;  // 0606C204 shll2 r2
    c.r[2] += c.r[1];  // 0606C206 add r1,r2
    c.r[2] <<= 2;  // 0606C208 shll2 r2
    c.r[3] += c.r[2];  // 0606C20A add r2,r3
    c.r[3] += 50;  // 0606C20C add #50,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606C20E mov.b @r3,r0
    c.r[1] = ld32(0x0606C2D0u);  // 0606C210 mov.l 0x0606C2D0,r1
    c.r[0] &= 0x3Fu;  // 0606C212 and #63,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606C214 mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606C216 extu.b r1,r0
    c.t = c.r[0] == 0x7u;  // 0606C218 cmp/eq #7,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606C2B2; } }  // 0606C21A bf/s 0x0606C2B2 ; mov r15,r14
    c.r[5] = ld32(0x0606C2D4u);  // 0606C21E mov.l 0x0606C2D4,r5
    c.r[8] = ld32(0x0606C2D8u);  // 0606C220 mov.l 0x0606C2D8,r8
    c.r[9] = ld32(0x0606C2DCu);  // 0606C222 mov.l 0x0606C2DC,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C224 mov.b @r8,r1
    c.r[6] = ld32(0x0606C2E0u);  // 0606C226 mov.l 0x0606C2E0,r6
    c.r[7] = ld32(c.r[9]);  // 0606C228 mov.l @r9,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606C22A extu.b r1,r1
    c.r[1] <<= 2;  // 0606C22C shll2 r1
    c.r[1] <<= 2;  // 0606C22E shll2 r1
    c.r[2] = c.r[1];  // 0606C230 mov r1,r2
    c.r[2] += c.r[7];  // 0606C232 add r7,r2
    c.r[2] += 1;  // 0606C234 add #1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C236 mov.b @r2,r3
    c.r[0] = c.r[1];  // 0606C238 mov r1,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0606C23A extu.b r3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606C23C mov.b @(r0,r7),r2
    c.r[3] <<= 2;  // 0606C23E shll2 r3
    c.r[3] <<= 2;  // 0606C240 shll2 r3
    c.r[3] <<= 2;  // 0606C242 shll2 r3
    c.r[1] = ld32(c.r[5]);  // 0606C244 mov.l @r5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606C246 extu.b r2,r2
    c.r[3] += c.r[1];  // 0606C248 add r1,r3
    c.r[1] = 0xFFFFFFFFu;  // 0606C24A mov #-1,r1
    c.r[0] = c.r[3];  // 0606C24C mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606C24E mov.b r1,@(r0,r2)
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606C250 mov.b @r6,r3
    c.r[7] = ld32(0x0606C2E4u);  // 0606C252 mov.l 0x0606C2E4,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606C254 mov.b @r7,r2
    c.r[1] = ld32(c.r[5]);  // 0606C256 mov.l @r5,r1
    c.r[3] <<= 2;  // 0606C258 shll2 r3
    c.r[3] <<= 2;  // 0606C25A shll2 r3
    c.r[3] <<= 2;  // 0606C25C shll2 r3
    c.r[3] += c.r[1];  // 0606C25E add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C260 mov.b @r8,r1
    c.r[0] = c.r[3];  // 0606C262 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606C264 mov.b r1,@(r0,r2)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C266 mov.b @r8,r2
    c.r[3] = ld32(c.r[9]);  // 0606C268 mov.l @r9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606C26A mov.b @r7,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606C26C extu.b r2,r2
    c.r[2] <<= 2;  // 0606C26E shll2 r2
    c.r[2] <<= 2;  // 0606C270 shll2 r2
    c.r[0] = c.r[2];  // 0606C272 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0606C274 mov.b r1,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C276 mov.b @r8,r2
    c.r[5] = 0x0u;  // 0606C278 mov #0,r5
    c.r[1] = ld32(c.r[9]);  // 0606C27A mov.l @r9,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606C27C extu.b r2,r2
    c.r[2] <<= 2;  // 0606C27E shll2 r2
    c.r[2] <<= 2;  // 0606C280 shll2 r2
    c.r[2] += c.r[1];  // 0606C282 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606C284 mov.b @r6,r1
    c.r[2] += 1;  // 0606C286 add #1,r2
    st8(c.r[2], c.r[1]);  // 0606C288 mov.b r1,@r2
    c.r[1] = ld32(0x0606C2E8u);  // 0606C28A mov.l 0x0606C2E8,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C28C mov.b @r8,r4
    c.r[6] = 0x0u;  // 0606C28E mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0606C294u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C294u) return; }  // 0606C290 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C294 mov.b @r8,r1
    c.r[2] = ld32(c.r[9]);  // 0606C296 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606C298 extu.b r1,r1
    c.r[1] <<= 2;  // 0606C29A shll2 r1
    c.r[1] <<= 2;  // 0606C29C shll2 r1
    c.r[1] += c.r[2];  // 0606C29E add r2,r1
    c.r[1] += 3;  // 0606C2A0 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C2A2 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C2C0u);  // 0606C2A4 mov.w 0x0606C2C0,r0
    c.r[2] |= c.r[0];  // 0606C2A6 or r0,r2
    st8(c.r[1], c.r[2]);  // 0606C2A8 mov.b r2,@r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606C2AA mov.b @r8,r4
    c.r[1] = ld32(0x0606C2ECu);  // 0606C2AC mov.l 0x0606C2EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606C2B2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C2B2u) return; }  // 0606C2AE jsr @r1 ; extu.b r4,r4
L_0606C2B2:
    c.r[15] = c.r[14];  // 0606C2B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C2B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C2B6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606C2B8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C2C2u);  // 0606C2BA mov.w 0x0606C2C2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C2BC rts ; mov.l @r15+,r8
}

void f_0606C2F0(SH2Context& c) {
    ran[1535] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C2F0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0606C2F2 mov r15,r14
    c.r[4] = 0x0u;  // 0606C2F4 mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606C360u);  // 0606C2F6 mov.w 0x0606C360,r5
    c.r[7] = 0x0u;  // 0606C2F8 mov #0,r7
L_0606C2FA:
    c.r[1] = ld32(0x0606C364u);  // 0606C2FA mov.l 0x0606C364,r1
    c.r[3] = c.r[7];  // 0606C2FC mov r7,r3
    c.r[2] = ld32(c.r[1]);  // 0606C2FE mov.l @r1,r2
    c.r[0] = c.r[7];  // 0606C300 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606C302 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C304 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 0606C306 cmp/eq r5,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_0606C34E; } }  // 0606C308 bt/s 0x0606C34E ; add r2,r3
    c.r[1] = c.r[3];  // 0606C30C mov r3,r1
    c.r[1] += 7;  // 0606C30E add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C310 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606C312 mov r1,r0
    c.r[0] >>= 2;  // 0606C314 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606C316 shlr r0
    c.r[0] &= 0x1u;  // 0606C318 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C31A tst r0,r0
    { const bool k = !c.t; c.r[6] = c.r[3]; if (k) { goto L_0606C34E; } }  // 0606C31C bf/s 0x0606C34E ; mov r3,r6
    c.r[6] += 8;  // 0606C320 add #8,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606C322 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C324 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 0606C326 cmp/eq r5,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0606C34E; } }  // 0606C328 bt/s 0x0606C34E ; mov r1,r0
    c.r[0] <<= 2;  // 0606C32C shll2 r0
    c.r[0] <<= 2;  // 0606C32E shll2 r0
    c.r[3] = c.r[0];  // 0606C330 mov r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606C332 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C334 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 0606C336 cmp/eq r5,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_0606C34C; } }  // 0606C338 bt/s 0x0606C34C ; add r2,r3
    c.r[3] += 7;  // 0606C33C add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606C33E mov.b @r3,r1
    c.r[0] = c.r[1];  // 0606C340 mov r1,r0
    c.r[0] >>= 2;  // 0606C342 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606C344 shlr r0
    c.r[0] &= 0x1u;  // 0606C346 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C348 tst r0,r0
    if (c.t) { goto L_0606C34E; }  // 0606C34A bt 0x0606C34E
L_0606C34C:
    st8(c.r[6], c.r[5]);  // 0606C34C mov.b r5,@r6
L_0606C34E:
    c.r[4] += 1;  // 0606C34E add #1,r4
    c.r[1] = 0x49u;  // 0606C350 mov #73,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0606C352 cmp/gt r1,r4
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_0606C2FA; } }  // 0606C354 bf/s 0x0606C2FA ; add #16,r7
    c.r[15] = c.r[14];  // 0606C358 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C362u);  // 0606C35A mov.w 0x0606C362,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C35C rts ; mov.l @r15+,r14
}

void f_0606C368(SH2Context& c) {
    ran[1536] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C368 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606C36A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C36C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C36E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606C412u);  // 0606C370 mov.w 0x0606C412,r3
    c.r[15] += c.r[3];  // 0606C372 add r3,r15
    c.r[14] = c.r[15];  // 0606C374 mov r15,r14
    c.r[9] = ld32(0x0606C418u);  // 0606C376 mov.l 0x0606C418,r9
    c.r[8] = ld32(0x0606C41Cu);  // 0606C378 mov.l 0x0606C41C,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606C37A mov.b @r9,r6
    c.r[4] = c.r[14];  // 0606C37C mov r14,r4
    c.r[1] = ld32(c.r[8]);  // 0606C37E mov.l @r8,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0606C380 extu.b r6,r6
    c.r[2] = c.r[6];  // 0606C382 mov r6,r2
    c.r[2] <<= 2;  // 0606C384 shll2 r2
    c.r[2] <<= 2;  // 0606C386 shll2 r2
    c.r[2] += c.r[1];  // 0606C388 add r1,r2
    c.r[2] += 2;  // 0606C38A add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C38C mov.b @r2,r5
    c.r[1] = ld32(0x0606C420u);  // 0606C38E mov.l 0x0606C420,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606C394u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C394u) return; }  // 0606C390 jsr @r1 ; extu.b r5,r5
    c.r[7] = ld32(0x0606C424u);  // 0606C394 mov.l 0x0606C424,r7
    c.r[2] = c.r[7];  // 0606C396 mov r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0606C398 mov.w @r14,r1
    c.r[2] += 10;  // 0606C39A add #10,r2
    st16(c.r[2], c.r[1]);  // 0606C39C mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606C39E mov.b @r9,r1
    c.r[2] = ld32(c.r[8]);  // 0606C3A0 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606C3A2 extu.b r1,r1
    c.r[1] <<= 2;  // 0606C3A4 shll2 r1
    c.r[1] <<= 2;  // 0606C3A6 shll2 r1
    c.r[1] += c.r[2];  // 0606C3A8 add r2,r1
    c.r[1] += 2;  // 0606C3AA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C3AC mov.b @r1,r2
    c.r[1] = ld32(0x0606C428u);  // 0606C3AE mov.l 0x0606C428,r1
    c.r[3] = ld32(c.r[1]);  // 0606C3B0 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606C3B2 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606C3B4 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606C3B6 mul.l r1,r2
    c.r[6] = c.r[7];  // 0606C3B8 mov r7,r6
    c.r[1] = c.macl;  // 0606C3BA sts macl,r1
    c.r[1] += c.r[3];  // 0606C3BC add r3,r1
    c.r[1] += 15;  // 0606C3BE add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C3C0 mov.b @r1,r1
    c.r[2] = ld32(0x0606C42Cu);  // 0606C3C2 mov.l 0x0606C42C,r2
    c.r[3] = ld32(c.r[2]);  // 0606C3C4 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606C3C6 extu.b r1,r1
    c.r[2] = c.r[1];  // 0606C3C8 mov r1,r2
    c.r[2] += c.r[2];  // 0606C3CA add r2,r2
    c.r[2] += c.r[1];  // 0606C3CC add r1,r2
    c.r[2] <<= 2;  // 0606C3CE shll2 r2
    c.r[0] = c.r[2];  // 0606C3D0 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606C3D2 mov.w @(r0,r3),r1
    c.r[6] += 6;  // 0606C3D4 add #6,r6
    st16(c.r[6], c.r[1]);  // 0606C3D6 mov.w r1,@r6
    c.r[1] = ld32(0x0606C430u);  // 0606C3D8 mov.l 0x0606C430,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C3DA mov.b @r1,r1
    c.r[2] = c.r[7];  // 0606C3DC mov r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606C3DE extu.b r1,r1
    c.r[3] = c.r[1];  // 0606C3E0 mov r1,r3
    c.r[3] <<= 2;  // 0606C3E2 shll2 r3
    c.r[3] += c.r[1];  // 0606C3E4 add r1,r3
    c.r[3] <<= 2;  // 0606C3E6 shll2 r3
    c.r[1] = c.r[14];  // 0606C3E8 mov r14,r1
    c.r[1] += 44;  // 0606C3EA add #44,r1
    c.r[0] = c.r[1];  // 0606C3EC mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606C3EE mov.w @(r0,r3),r1
    c.r[2] += 2;  // 0606C3F0 add #2,r2
    st16(c.r[2], c.r[1]);  // 0606C3F2 mov.w r1,@r2
    c.r[1] = c.r[14];  // 0606C3F4 mov r14,r1
    c.r[1] += 57;  // 0606C3F6 add #57,r1
    c.r[0] = c.r[1];  // 0606C3F8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606C3FA mov.b @(r0,r3),r1
    c.r[7] += 28;  // 0606C3FC add #28,r7
    st8(c.r[7], c.r[1]);  // 0606C3FE mov.b r1,@r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606C414u);  // 0606C400 mov.w 0x0606C414,r3
    c.r[14] += c.r[3];  // 0606C402 add r3,r14
    c.r[15] = c.r[14];  // 0606C404 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C406 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C408 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606C40A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C416u);  // 0606C40C mov.w 0x0606C416,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C40E rts ; mov.l @r15+,r8
}

void f_0606C434(SH2Context& c) {
    ran[1537] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C434 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C436 sts.l pr,@-r15
    c.r[1] = ld32(0x0606C458u);  // 0606C438 mov.l 0x0606C458,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C43A mov.b @r1,r5
    c.r[14] = c.r[15];  // 0606C43C mov r15,r14
    c.r[1] = ld32(0x0606C45Cu);  // 0606C43E mov.l 0x0606C45C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C440 mov.b @r1,r0
    c.r[5] = c.r[5] & 0xFFu;  // 0606C442 extu.b r5,r5
    c.r[0] |= 0x80u;  // 0606C444 or #128,r0
    c.r[1] = ld32(0x0606C460u);  // 0606C446 mov.l 0x0606C460,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606C44Cu; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C44Cu) return; }  // 0606C448 jsr @r1 ; extu.b r0,r4
    c.r[15] = c.r[14];  // 0606C44C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C44E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C456u);  // 0606C450 mov.w 0x0606C456,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C452 rts ; mov.l @r15+,r14
}

void f_0606C464(SH2Context& c) {
    ran[1538] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C464 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606C466 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606C468 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C46A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C46C sts.l pr,@-r15
    c.r[15] -= 8;  // 0606C46E add #-8,r15
    c.r[14] = c.r[15];  // 0606C470 mov r15,r14
    c.r[1] = 0x0u;  // 0606C472 mov #0,r1
    c.r[2] = 0x0u;  // 0606C474 mov #0,r2
    st32(c.r[14], c.r[1]);  // 0606C476 mov.l r1,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0606C478 mov.l r2,@(4,r14)
    c.r[1] = ld32(0x0606C56Cu);  // 0606C47A mov.l 0x0606C56C,r1
    st32(c.r[14], c.r[1]);  // 0606C47C mov.l r1,@r14
    c.r[1] = ld32(0x0606C570u);  // 0606C47E mov.l 0x0606C570,r1
    st32(c.r[14] + 4, c.r[1]);  // 0606C480 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0606C574u);  // 0606C482 mov.l 0x0606C574,r1
    c.r[1] = ld32(c.r[1]);  // 0606C484 mov.l @r1,r1
    c.r[1] += 1;  // 0606C486 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C488 mov.b @r1,r1
    c.r[8] = ld32(0x0606C578u);  // 0606C48A mov.l 0x0606C578,r8
    c.r[9] = c.r[1] & 0xFFu;  // 0606C48C extu.b r1,r9
    c.r[0] = c.r[9];  // 0606C48E mov r9,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606C490 mov.b @(r0,r8),r4
    c.r[0] = ld32(0x0606C57Cu);  // 0606C492 mov.l 0x0606C57C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C498u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C498u) return; }  // 0606C494 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0606C498 mov r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0606C49A extu.b r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C566u);  // 0606C49C mov.w 0x0606C566,r1
    c.t = c.r[10] == c.r[1];  // 0606C49E cmp/eq r1,r10
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0606C4CE; } }  // 0606C4A0 bf/s 0x0606C4CE ; mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606C4A4 mov.b @(r0,r8),r1
    c.r[10] = c.r[1] & 0xFFu;  // 0606C4A6 extu.b r1,r10
    c.r[1] = ld32(0x0606C580u);  // 0606C4A8 mov.l 0x0606C580,r1
    c.r[2] = c.r[10];  // 0606C4AA mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 0606C4AC mov.l @r1,r1
    c.r[2] <<= 2;  // 0606C4AE shll2 r2
    c.r[2] <<= 2;  // 0606C4B0 shll2 r2
    c.r[2] += c.r[1];  // 0606C4B2 add r1,r2
    c.r[1] = c.r[2];  // 0606C4B4 mov r2,r1
    c.r[1] += 4;  // 0606C4B6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C4B8 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606C4BA mov #1,r0
    c.r[1] >>= 2;  // 0606C4BC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606C4BE shlr r1
    c.r[1] >>= 2;  // 0606C4C0 shlr2 r1
    c.r[1] &= c.r[0];  // 0606C4C2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606C4C4 tst r1,r1
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0606C4CE; } }  // 0606C4C6 bt/s 0x0606C4CE ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C4CA mov.b @r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0606C4CC extu.b r1,r10
L_0606C4CE:
    c.r[1] = ld32(0x0606C584u);  // 0606C4CE mov.l 0x0606C584,r1
    c.r[0] = c.r[9];  // 0606C4D0 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606C4D2 mov.b @(r0,r1),r1
    c.r[8] = ld32(0x0606C578u);  // 0606C4D4 mov.l 0x0606C578,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C568u);  // 0606C4D6 mov.w 0x0606C568,r0
    c.r[1] |= c.r[0];  // 0606C4D8 or r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0606C4DA extu.b r1,r5
    c.r[0] = c.r[9];  // 0606C4DC mov r9,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606C4DE mov.b @(r0,r8),r4
    c.r[1] = ld32(0x0606C588u);  // 0606C4E0 mov.l 0x0606C588,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606C4E6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C4E6u) return; }  // 0606C4E2 jsr @r1 ; extu.b r4,r4
    c.r[0] = c.r[9];  // 0606C4E6 mov r9,r0
    c.r[1] = ld32(0x0606C580u);  // 0606C4E8 mov.l 0x0606C580,r1
    c.r[6] = 0x1Eu;  // 0606C4EA mov #30,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606C4EC mov.b @(r0,r8),r2
    c.r[4] = c.r[9];  // 0606C4EE mov r9,r4
    c.r[7] = ld32(c.r[1]);  // 0606C4F0 mov.l @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0606C4F2 extu.b r2,r2
    c.r[2] <<= 2;  // 0606C4F4 shll2 r2
    c.r[2] <<= 2;  // 0606C4F6 shll2 r2
    c.r[2] += c.r[7];  // 0606C4F8 add r7,r2
    c.r[2] += 2;  // 0606C4FA add #2,r2
    c.r[1] = ld32(0x0606C58Cu);  // 0606C4FC mov.l 0x0606C58C,r1
    c.r[4] <<= 2;  // 0606C4FE shll2 r4
    c.r[0] = c.r[4];  // 0606C500 mov r4,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C502 mov.b @r2,r2
    c.r[10] <<= 2;  // 0606C504 shll2 r10
    c.r[10] <<= 2;  // 0606C506 shll2 r10
    c.r[2] = c.r[2] & 0xFFu;  // 0606C508 extu.b r2,r2
    c.macl = c.r[2] * c.r[6];  // 0606C50A mul.l r6,r2
    c.r[10] += c.r[7];  // 0606C50C add r7,r10
    c.r[5] = ld32(c.r[1]);  // 0606C50E mov.l @r1,r5
    c.r[3] = c.macl;  // 0606C510 sts macl,r3
    c.r[3] += c.r[5];  // 0606C512 add r5,r3
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 0606C514 mov.l @(r0,r14),r2
    c.r[3] += 24;  // 0606C516 add #24,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606C518 mov.w @r3,r1
    c.r[2] += 22;  // 0606C51A add #22,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606C51C mov.w @r2,r2
    c.r[10] += 2;  // 0606C51E add #2,r10
    c.r[1] -= c.r[2];  // 0606C520 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0606C522 mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606C524 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C526 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 0606C528 mul.l r6,r1
    c.r[3] = c.macl;  // 0606C52A sts macl,r3
    c.r[3] += c.r[5];  // 0606C52C add r5,r3
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0606C52E mov.l @(r0,r14),r1
    c.r[3] += 24;  // 0606C530 add #24,r3
    c.r[1] += 26;  // 0606C532 add #26,r1
    c.r[0] = c.r[9];  // 0606C534 mov r9,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C536 mov.b @r1,r2
    c.r[14] += 8;  // 0606C538 add #8,r14
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606C53A mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606C53C extu.b r2,r2
    c.r[1] -= c.r[2];  // 0606C53E sub r2,r1
    st16(c.r[3], c.r[1]);  // 0606C540 mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606C542 mov.b @(r0,r8),r1
    c.r[15] = c.r[14];  // 0606C544 mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0606C546 extu.b r1,r1
    c.r[1] <<= 2;  // 0606C548 shll2 r1
    c.r[1] <<= 2;  // 0606C54A shll2 r1
    c.r[1] += c.r[7];  // 0606C54C add r7,r1
    c.r[1] += 7;  // 0606C54E add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C550 mov.b @r1,r2
    c.r[0] = 0x4u;  // 0606C552 mov #4,r0
    c.r[2] |= c.r[0];  // 0606C554 or r0,r2
    st8(c.r[1], c.r[2]);  // 0606C556 mov.b r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C558 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C55A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606C55C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606C55E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C56Au);  // 0606C560 mov.w 0x0606C56A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C562 rts ; mov.l @r15+,r8
}

void f_0606C590(SH2Context& c) {
    ran[1539] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C590 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606C592 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606C594 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606C596 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606C598 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606C59A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C59C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C59E sts.l pr,@-r15
    c.r[15] -= 12;  // 0606C5A0 add #-12,r15
    c.r[14] = c.r[15];  // 0606C5A2 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0606C5A4 mov.l r4,@r14
    c.r[11] = c.r[6];  // 0606C5A6 mov r6,r11
    c.r[13] = c.r[5] & 0xFFu;  // 0606C5A8 extu.b r5,r13
    c.r[7] = c.r[7] & 0xFFu;  // 0606C5AA extu.b r7,r7
    st32(c.r[14] + 4, c.r[7]);  // 0606C5AC mov.l r7,@(4,r14)
    c.r[12] = 0x0u;  // 0606C5AE mov #0,r12
    c.r[1] = ld32(c.r[14] + 44);  // 0606C5B0 mov.l @(44,r14),r1
    c.r[9] = 0x0u;  // 0606C5B2 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606C5B4 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0606C5B6 mov.l r1,@(8,r14)
    c.r[1] = c.r[13];  // 0606C5B8 mov r13,r1
    c.r[1] <<= 2;  // 0606C5BA shll2 r1
    c.r[1] += c.r[13];  // 0606C5BC add r13,r1
    c.r[1] <<= 2;  // 0606C5BE shll2 r1
    c.r[1] += c.r[4];  // 0606C5C0 add r4,r1
    c.r[1] += 51;  // 0606C5C2 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C5C4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606C5C6 mov r1,r0
    c.r[0] >>= 2;  // 0606C5C8 shlr2 r0
    c.r[0] >>= 2;  // 0606C5CA shlr2 r0
    c.r[0] >>= 2;  // 0606C5CC shlr2 r0
    c.r[0] &= 0x1u;  // 0606C5CE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C5D0 tst r0,r0
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0606C630; } }  // 0606C5D2 bt/s 0x0606C630 ; mov #0,r8
    c.r[10] = c.r[11];  // 0606C5D6 mov r11,r10
    c.r[10] += 39;  // 0606C5D8 add #39,r10
    c.r[6] = 0x4u;  // 0606C5DA mov #4,r6
    c.r[5] = 0x1u;  // 0606C5DC mov #1,r5
    c.r[3] = ld32(0x0606C724u);  // 0606C5DE mov.l 0x0606C724,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606C5E4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C5E4u) return; }  // 0606C5E0 jsr @r3 ; mov r10,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C5E4 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C5E6 cmp/eq #-1,r0
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_0606C5F2; } }  // 0606C5E8 bt/s 0x0606C5F2 ; mov #4,r6
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606C70Cu);  // 0606C5EC mov.w 0x0606C70C,r8
    c.r[9] = 0x1u;  // 0606C5EE mov #1,r9
    c.r[12] = 0x5u;  // 0606C5F0 mov #5,r12
L_0606C5F2:
    c.r[5] = 0x2u;  // 0606C5F2 mov #2,r5
    c.r[3] = ld32(0x0606C724u);  // 0606C5F4 mov.l 0x0606C724,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0606C5FAu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C5FAu) return; }  // 0606C5F6 jsr @r3 ; mov r10,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C5FA exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C5FC cmp/eq #-1,r0
    { const bool k = c.t; c.r[4] = c.r[11]; if (k) { goto L_0606C612; } }  // 0606C5FE bt/s 0x0606C612 ; mov r11,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C70Eu);  // 0606C602 mov.w 0x0606C70E,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606C604 cmp/gt r1,r8
    { const bool k = c.t; c.r[4] += 39; if (k) { goto L_0606C614; } }  // 0606C606 bt/s 0x0606C614 ; add #39,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606C710u);  // 0606C60A mov.w 0x0606C710,r8
    c.r[9] = 0x2u;  // 0606C60C mov #2,r9
    c.r[12] = 0x5u;  // 0606C60E mov #5,r12
    c.r[4] = c.r[11];  // 0606C610 mov r11,r4
L_0606C612:
    c.r[4] += 39;  // 0606C612 add #39,r4
L_0606C614:
    c.r[0] = ld32(0x0606C724u);  // 0606C614 mov.l 0x0606C724,r0
    c.r[6] = 0x4u;  // 0606C616 mov #4,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0606C61Cu; c.r[5] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C61Cu) return; }  // 0606C618 jsr @r0 ; mov #3,r5
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C61C exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C61E cmp/eq #-1,r0
    { const bool k = c.t; c.r[4] = ld32(c.r[14]); if (k) { goto L_0606C632; } }  // 0606C620 bt/s 0x0606C632 ; mov.l @r14,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C712u);  // 0606C624 mov.w 0x0606C712,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606C626 cmp/gt r1,r8
    if (c.t) { goto L_0606C632; }  // 0606C628 bt 0x0606C632
    c.r[9] = 0x3u;  // 0606C62A mov #3,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606C714u);  // 0606C62C mov.w 0x0606C714,r8
    c.r[12] = 0x5u;  // 0606C62E mov #5,r12
L_0606C630:
    c.r[4] = ld32(c.r[14]);  // 0606C630 mov.l @r14,r4
L_0606C632:
    c.r[10] = ld32(0x0606C724u);  // 0606C632 mov.l 0x0606C724,r10
    c.r[6] = 0x4u;  // 0606C634 mov #4,r6
    c.r[5] = 0xEu;  // 0606C636 mov #14,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606C63Cu; c.r[4] += 39; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C63Cu) return; }  // 0606C638 jsr @r10 ; add #39,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C63C exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C63E cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0606C660; } }  // 0606C640 bt/s 0x0606C660 ; mov r13,r1
    c.r[1] <<= 2;  // 0606C644 shll2 r1
    c.r[1] += c.r[13];  // 0606C646 add r13,r1
    c.r[3] = ld32(c.r[14]);  // 0606C648 mov.l @r14,r3
    c.r[1] <<= 2;  // 0606C64A shll2 r1
    c.r[1] += c.r[3];  // 0606C64C add r3,r1
    c.r[1] += 50;  // 0606C64E add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C650 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606C652 extu.b r1,r0
    c.r[0] >>= 2;  // 0606C654 shlr2 r0
    c.r[0] >>= 2;  // 0606C656 shlr2 r0
    c.r[0] >>= 2;  // 0606C658 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0606C65A cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0606C680; } }  // 0606C65C bt/s 0x0606C680 ; mov r13,r1
L_0606C660:
    c.r[4] = c.r[11];  // 0606C660 mov r11,r4
    c.r[4] += 39;  // 0606C662 add #39,r4
    c.r[6] = 0x4u;  // 0606C664 mov #4,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0606C66Au; c.r[5] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C66Au) return; }  // 0606C666 jsr @r10 ; mov #14,r5
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C66A exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C66C cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0606C680; } }  // 0606C66E bt/s 0x0606C680 ; mov r13,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C716u);  // 0606C672 mov.w 0x0606C716,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606C674 cmp/gt r1,r8
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0606C680; } }  // 0606C676 bt/s 0x0606C680 ; mov r13,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606C718u);  // 0606C67A mov.w 0x0606C718,r8
    c.r[9] = 0x6u;  // 0606C67C mov #6,r9
    c.r[12] = 0x0u;  // 0606C67E mov #0,r12
L_0606C680:
    c.r[1] <<= 2;  // 0606C680 shll2 r1
    c.r[1] += c.r[13];  // 0606C682 add r13,r1
    c.r[3] = ld32(c.r[14]);  // 0606C684 mov.l @r14,r3
    c.r[1] <<= 2;  // 0606C686 shll2 r1
    c.r[3] += c.r[1];  // 0606C688 add r1,r3
    c.r[3] += 51;  // 0606C68A add #51,r3
    st32(c.r[14], c.r[3]);  // 0606C68C mov.l r3,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606C68E mov.b @r3,r1
    c.r[0] = c.r[1];  // 0606C690 mov r1,r0
    c.r[0] >>= 2;  // 0606C692 shlr2 r0
    c.r[0] >>= 2;  // 0606C694 shlr2 r0
    c.r[0] >>= 2;  // 0606C696 shlr2 r0
    c.r[0] &= 0x1u;  // 0606C698 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C69A tst r0,r0
    { const bool k = c.t; c.r[3] = ld32(c.r[14] + 4); if (k) { goto L_0606C6F8; } }  // 0606C69C bt/s 0x0606C6F8 ; mov.l @(4,r14),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C71Au);  // 0606C6A0 mov.w 0x0606C71A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606C6A2 mov.b @(r0,r11),r1
    c.r[3] = 0x7u;  // 0606C6A4 mov #7,r3
    c.r[4] = c.r[11];  // 0606C6A6 mov r11,r4
    c.r[4] += 16;  // 0606C6A8 add #16,r4
    c.r[5] = 0x10u;  // 0606C6AA mov #16,r5
    c.r[1] >>= 2;  // 0606C6AC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606C6AE shlr r1
    c.r[1] &= c.r[3];  // 0606C6B0 and r3,r1
    c.r[0] = ld32(0x0606C724u);  // 0606C6B2 mov.l 0x0606C724,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C6B8u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C6B8u) return; }  // 0606C6B4 jsr @r0 ; mov r1,r6
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C6B8 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C6BA cmp/eq #-1,r0
    if (c.t) { goto L_0606C6CA; }  // 0606C6BC bt 0x0606C6CA
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C71Cu);  // 0606C6BE mov.w 0x0606C71C,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606C6C0 cmp/gt r1,r8
    if (c.t) { goto L_0606C6CA; }  // 0606C6C2 bt 0x0606C6CA
    c.r[9] = 0x8u;  // 0606C6C4 mov #8,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606C70Cu);  // 0606C6C6 mov.w 0x0606C70C,r8
    c.r[12] = 0x5u;  // 0606C6C8 mov #5,r12
L_0606C6CA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C71Au);  // 0606C6CA mov.w 0x0606C71A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606C6CC mov.b @(r0,r11),r1
    c.r[3] = 0x7u;  // 0606C6CE mov #7,r3
    c.r[4] = c.r[11];  // 0606C6D0 mov r11,r4
    c.r[4] += 16;  // 0606C6D2 add #16,r4
    c.r[5] = 0x7u;  // 0606C6D4 mov #7,r5
    c.r[1] >>= 2;  // 0606C6D6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606C6D8 shlr r1
    c.r[1] &= c.r[3];  // 0606C6DA and r3,r1
    c.r[0] = ld32(0x0606C724u);  // 0606C6DC mov.l 0x0606C724,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C6E2u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C6E2u) return; }  // 0606C6DE jsr @r0 ; mov r1,r6
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C6E2 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C6E4 cmp/eq #-1,r0
    { const bool k = c.t; c.r[3] = ld32(c.r[14] + 4); if (k) { goto L_0606C6F8; } }  // 0606C6E6 bt/s 0x0606C6F8 ; mov.l @(4,r14),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C70Eu);  // 0606C6EA mov.w 0x0606C70E,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606C6EC cmp/gt r1,r8
    if (c.t) { goto L_0606C6F8; }  // 0606C6EE bt 0x0606C6F8
    c.r[9] = 0x7u;  // 0606C6F0 mov #7,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606C710u);  // 0606C6F2 mov.w 0x0606C710,r8
    c.r[12] = 0x5u;  // 0606C6F4 mov #5,r12
    c.r[3] = ld32(c.r[14] + 4);  // 0606C6F6 mov.l @(4,r14),r3
L_0606C6F8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C71Eu);  // 0606C6F8 mov.w 0x0606C71E,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0606C6FA cmp/gt r1,r3
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 4); if (k) { goto L_0606C72A; } }  // 0606C6FC bt/s 0x0606C72A ; mov.l @(4,r14),r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606C720u);  // 0606C700 mov.w 0x0606C720,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0606C702 cmp/ge r1,r3
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0606C728; } }  // 0606C704 bf/s 0x0606C728 ; mov #0,r2
    c.r[11] += 24; goto L_0606C73C;  // 0606C708 bra 0x0606C73C ; add #24,r11
L_0606C728:
    c.r[1] = ld32(c.r[14] + 4);  // 0606C728 mov.l @(4,r14),r1
L_0606C72A:
    c.r[3] = ld32(c.r[14] + 4);  // 0606C72A mov.l @(4,r14),r3
    c.r[1] <<= 2;  // 0606C72C shll2 r1
    c.r[1] += c.r[3];  // 0606C72E add r3,r1
    c.r[1] <<= 2;  // 0606C730 shll2 r1
    c.r[1] += c.r[11];  // 0606C732 add r11,r1
    c.r[1] += 55;  // 0606C734 add #55,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C736 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606C738 extu.b r1,r2
    c.r[11] += 24;  // 0606C73A add #24,r11
L_0606C73C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0606C73C mov.w @r11,r1
    c.r[2] += c.r[12];  // 0606C73E add r12,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606C740 extu.w r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0606C742 cmp/ge r2,r1
    { const bool k = c.t; c.r[3] = ld32(c.r[14] + 8); if (k) { goto L_0606C74C; } }  // 0606C744 bt/s 0x0606C74C ; mov.l @(8,r14),r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606C748 tst r3,r3
    if (c.t) { goto L_0606C754; }  // 0606C74A bt 0x0606C754
L_0606C74C:
    c.r[8] <<= 2;  // 0606C74C shll2 r8
    c.r[8] <<= 2;  // 0606C74E shll2 r8
    c.r[9] += c.r[8]; goto L_0606C756;  // 0606C750 bra 0x0606C756 ; add r8,r9
L_0606C754:
    c.r[9] = 0x0u;  // 0606C754 mov #0,r9
L_0606C756:
    c.r[14] += 12;  // 0606C756 add #12,r14
    c.r[15] = c.r[14];  // 0606C758 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C75A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C75C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606C75E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606C760 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606C762 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606C764 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0606C766 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606C768 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C76A rts ; mov.l @r15+,r8
}

void f_0606C770(SH2Context& c) {
    ran[1540] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C770 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C772 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606C774 mov r15,r14
    c.r[0] = 0x0u;  // 0606C776 mov #0,r0
    c.r[3] = 0x3u;  // 0606C778 mov #3,r3
    c.r[1] = c.r[4];  // 0606C77A mov r4,r1
    c.r[1] += 39;  // 0606C77C add #39,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C77E mov.b @r1,r1
    c.r[2] = 0x1u; goto L_0606C79E;  // 0606C780 bra 0x0606C79E ; mov #1,r2
L_0606C784:
    c.r[1] += 39;  // 0606C784 add #39,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C786 mov.b @r1,r1
    c.r[1] -= 7;  // 0606C788 add #-7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C78A extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606C78C cmp/hi r2,r1
    if (!c.t) { goto L_0606C7A8; }  // 0606C78E bf 0x0606C7A8
    c.r[0] += 1;  // 0606C790 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[3];  // 0606C792 cmp/gt r3,r0
    { const bool k = c.t; c.r[4] += 1; if (k) { goto L_0606C7A8; } }  // 0606C794 bt/s 0x0606C7A8 ; add #1,r4
    c.r[1] = c.r[4];  // 0606C798 mov r4,r1
    c.r[1] += 39;  // 0606C79A add #39,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C79C mov.b @r1,r1
L_0606C79E:
    c.r[1] -= 5;  // 0606C79E add #-5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C7A0 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606C7A2 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { SH2_POLL(c); goto L_0606C784; } }  // 0606C7A4 bt/s 0x0606C784 ; mov r4,r1
L_0606C7A8:
    c.t = c.r[0] == 0x4u;  // 0606C7A8 cmp/eq #4,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606C7D2; } }  // 0606C7AA bt/s 0x0606C7D2 ; mov #0,r0
    c.r[5] += 9;  // 0606C7AE add #9,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0606C7B0 mov.b @r5,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606C7DAu);  // 0606C7B2 mov.w 0x0606C7DA,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606C7B4 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606C7B6 cmp/hi r2,r1
    if (!c.t) { goto L_0606C7D2; }  // 0606C7B8 bf 0x0606C7D2
    c.r[0] = ld32(0x0606C7DCu);  // 0606C7BA mov.l 0x0606C7DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C7C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C7C0u) return; }  // 0606C7BC jsr @r0 ; nop
    c.r[0] >>= 8;  // 0606C7C0 shlr8 r0
    c.r[0] += c.r[0];  // 0606C7C2 add r0,r0
    c.r[0] >>= 8;  // 0606C7C4 shlr8 r0
    c.r[0] += 2;  // 0606C7C6 add #2,r0
    c.r[1] = 0x2u;  // 0606C7C8 mov #2,r1
    c.t = c.r[0] > c.r[1];  // 0606C7CA cmp/hi r1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C7D2; } }  // 0606C7CC bt/s 0x0606C7D2 ; mov #1,r0
    c.r[0] = 0x0u;  // 0606C7D0 mov #0,r0
L_0606C7D2:
    c.r[15] = c.r[14];  // 0606C7D2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C7D4 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C7D6 rts ; mov.l @r15+,r14
}

void f_0606C7E0(SH2Context& c) {
    ran[1541] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C7E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C7E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C7E4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606C7E6 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C87Cu);  // 0606C7E8 mov.w 0x0606C87C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0606C7EA mov.b @(r0,r5),r1
    c.r[0] = c.r[1];  // 0606C7EC mov r1,r0
    c.r[0] >>= 2;  // 0606C7EE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606C7F0 shlr r0
    c.r[0] >>= 2;  // 0606C7F2 shlr2 r0
    c.r[0] &= 0x1u;  // 0606C7F4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C7F6 tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[7] & 0xFFu; if (k) { goto L_0606C870; } }  // 0606C7F8 bt/s 0x0606C870 ; extu.b r7,r7
    c.r[1] = c.r[7];  // 0606C7FC mov r7,r1
    c.r[1] <<= 2;  // 0606C7FE shll2 r1
    c.r[1] += c.r[7];  // 0606C800 add r7,r1
    c.r[1] <<= 2;  // 0606C802 shll2 r1
    c.r[4] += c.r[1];  // 0606C804 add r1,r4
    c.r[4] += 51;  // 0606C806 add #51,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0606C808 mov.b @r4,r1
    c.r[0] = c.r[1];  // 0606C80A mov r1,r0
    c.r[0] >>= 2;  // 0606C80C shlr2 r0
    c.r[0] >>= 2;  // 0606C80E shlr2 r0
    c.r[0] &= 0x1u;  // 0606C810 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C812 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606C872; } }  // 0606C814 bt/s 0x0606C872 ; mov #0,r0
    c.r[7] = 0x0u;  // 0606C818 mov #0,r7
    c.r[3] = 0x3u;  // 0606C81A mov #3,r3
    c.r[2] = 0x8u;  // 0606C81C mov #8,r2
    c.r[1] = c.r[6];  // 0606C81E mov r6,r1
L_0606C820:
    c.r[1] += c.r[7];  // 0606C820 add r7,r1
    c.r[1] += 30;  // 0606C822 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C824 mov.b @r1,r1
    c.r[1] -= 69;  // 0606C826 add #-69,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C828 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606C82A cmp/hi r2,r1
    if (!c.t) { goto L_0606C836; }  // 0606C82C bf 0x0606C836
    c.r[7] += 1;  // 0606C82E add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0606C830 cmp/gt r3,r7
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { SH2_POLL(c); goto L_0606C820; } }  // 0606C832 bf/s 0x0606C820 ; mov r6,r1
L_0606C836:
    c.r[6] += c.r[7];  // 0606C836 add r7,r6
    c.r[6] += 30;  // 0606C838 add #30,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606C83A mov.b @r6,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606C83C extu.b r1,r2
    c.r[1] = ld32(0x0606C880u);  // 0606C83E mov.l 0x0606C880,r1
    c.r[0] = c.r[2];  // 0606C840 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606C842 mov.b @(r0,r1),r1
    c.r[0] = c.r[7];  // 0606C844 mov r7,r0
    c.t = c.r[0] == 0x4u;  // 0606C846 cmp/eq #4,r0
    { const bool k = c.t; c.r[8] = c.r[1] & 0xFFu; if (k) { goto L_0606C870; } }  // 0606C848 bt/s 0x0606C870 ; extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606C84C tst r8,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606C872; } }  // 0606C84E bt/s 0x0606C872 ; mov #0,r0
    c.r[0] = c.r[8];  // 0606C852 mov r8,r0
    c.t = c.r[0] == 0x10u;  // 0606C854 cmp/eq #16,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C872; } }  // 0606C856 bt/s 0x0606C872 ; mov #1,r0
    c.r[0] = ld32(0x0606C884u);  // 0606C85A mov.l 0x0606C884,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C860u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C860u) return; }  // 0606C85C jsr @r0 ; add #1,r8
    c.r[0] >>= 8;  // 0606C860 shlr8 r0
    c.r[0] >>= 2;  // 0606C862 shlr2 r0
    c.r[0] >>= 2;  // 0606C864 shlr2 r0
    c.r[0] += c.r[8];  // 0606C866 add r8,r0
    c.r[1] = 0x10u;  // 0606C868 mov #16,r1
    c.t = c.r[0] > c.r[1];  // 0606C86A cmp/hi r1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C872; } }  // 0606C86C bt/s 0x0606C872 ; mov #1,r0
L_0606C870:
    c.r[0] = 0x0u;  // 0606C870 mov #0,r0
L_0606C872:
    c.r[15] = c.r[14];  // 0606C872 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C874 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C876 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C878 rts ; mov.l @r15+,r8
}

void f_0606C888(SH2Context& c) {
    ran[1542] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C888 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C88A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C88C sts.l pr,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606C904u);  // 0606C88E mov.w 0x0606C904,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0606C890 mov.b @(r0,r4),r1
    c.r[0] = c.r[1];  // 0606C892 mov r1,r0
    c.r[0] >>= 2;  // 0606C894 shlr2 r0
    c.r[0] >>= 2;  // 0606C896 shlr2 r0
    c.r[0] &= 0x1u;  // 0606C898 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C89A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606C8F8; } }  // 0606C89C bt/s 0x0606C8F8 ; mov r15,r14
    c.r[7] = 0x0u;  // 0606C8A0 mov #0,r7
    c.r[3] = 0x3u;  // 0606C8A2 mov #3,r3
    c.r[2] = 0x8u;  // 0606C8A4 mov #8,r2
    c.r[1] = c.r[5];  // 0606C8A6 mov r5,r1
L_0606C8A8:
    c.r[1] += c.r[7];  // 0606C8A8 add r7,r1
    c.r[1] += 30;  // 0606C8AA add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C8AC mov.b @r1,r1
    c.r[1] -= 60;  // 0606C8AE add #-60,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606C8B0 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606C8B2 cmp/hi r2,r1
    if (!c.t) { goto L_0606C8BE; }  // 0606C8B4 bf 0x0606C8BE
    c.r[7] += 1;  // 0606C8B6 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0606C8B8 cmp/gt r3,r7
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { SH2_POLL(c); goto L_0606C8A8; } }  // 0606C8BA bf/s 0x0606C8A8 ; mov r5,r1
L_0606C8BE:
    c.r[5] += c.r[7];  // 0606C8BE add r7,r5
    c.r[5] += 30;  // 0606C8C0 add #30,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0606C8C2 mov.b @r5,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606C8C4 extu.b r1,r2
    c.r[1] = ld32(0x0606C908u);  // 0606C8C6 mov.l 0x0606C908,r1
    c.r[0] = c.r[2];  // 0606C8C8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606C8CA mov.b @(r0,r1),r1
    c.r[0] = c.r[7];  // 0606C8CC mov r7,r0
    c.t = c.r[0] == 0x4u;  // 0606C8CE cmp/eq #4,r0
    { const bool k = c.t; c.r[8] = c.r[1] & 0xFFu; if (k) { goto L_0606C8F8; } }  // 0606C8D0 bt/s 0x0606C8F8 ; extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606C8D4 tst r8,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606C8FA; } }  // 0606C8D6 bt/s 0x0606C8FA ; mov #0,r0
    c.r[0] = c.r[8];  // 0606C8DA mov r8,r0
    c.t = c.r[0] == 0x10u;  // 0606C8DC cmp/eq #16,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C8FA; } }  // 0606C8DE bt/s 0x0606C8FA ; mov #1,r0
    c.r[0] = ld32(0x0606C90Cu);  // 0606C8E2 mov.l 0x0606C90C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C8E8u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C8E8u) return; }  // 0606C8E4 jsr @r0 ; add #1,r8
    c.r[0] >>= 8;  // 0606C8E8 shlr8 r0
    c.r[0] >>= 2;  // 0606C8EA shlr2 r0
    c.r[0] >>= 2;  // 0606C8EC shlr2 r0
    c.r[0] += c.r[8];  // 0606C8EE add r8,r0
    c.r[1] = 0x10u;  // 0606C8F0 mov #16,r1
    c.t = c.r[0] > c.r[1];  // 0606C8F2 cmp/hi r1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C8FA; } }  // 0606C8F4 bt/s 0x0606C8FA ; mov #1,r0
L_0606C8F8:
    c.r[0] = 0x0u;  // 0606C8F8 mov #0,r0
L_0606C8FA:
    c.r[15] = c.r[14];  // 0606C8FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C8FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C8FE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C900 rts ; mov.l @r15+,r8
}

void f_0606C910(SH2Context& c) {
    ran[1543] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606C910 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606C912 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606C914 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C916 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C918 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606C91A mov r15,r14
    c.r[9] = c.r[4];  // 0606C91C mov r4,r9
    c.r[4] = c.r[5];  // 0606C91E mov r5,r4
    c.r[7] = c.r[7] & 0xFFu;  // 0606C920 extu.b r7,r7
    c.r[6] += 18;  // 0606C922 add #18,r6
    c.r[2] = c.r[7];  // 0606C924 mov r7,r2
    c.r[2] <<= 2;  // 0606C926 shll2 r2
    c.r[2] += c.r[7];  // 0606C928 add r7,r2
    c.r[2] <<= 2;  // 0606C92A shll2 r2
    c.r[1] = ld32(c.r[14] + 20);  // 0606C92C mov.l @(20,r14),r1
    c.r[2] += c.r[9];  // 0606C92E add r9,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0606C930 extu.b r1,r10
    c.r[1] = c.r[4];  // 0606C932 mov r4,r1
    c.r[1] += 18;  // 0606C934 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606C936 mov.w @r1,r1
    c.r[5] = 0x4Eu;  // 0606C938 mov #78,r5
    c.r[8] = c.r[1] & 0xFFFFu;  // 0606C93A extu.w r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0606C93C mov.w @r6,r1
    c.r[4] += 30;  // 0606C93E add #30,r4
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606C940 extu.w r1,r1
    c.r[8] -= c.r[1];  // 0606C942 sub r1,r8
    c.r[1] = c.r[2];  // 0606C944 mov r2,r1
    c.r[1] += 51;  // 0606C946 add #51,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606C948 mov.b @r1,r0
    c.r[2] += 52;  // 0606C94A add #52,r2
    c.r[0] &= 0x1u;  // 0606C94C and #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606C94E mov.b @r2,r1
    c.r[0] <<= 2;  // 0606C950 shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0606C952 extu.b r1,r1
    c.r[1] >>= 2;  // 0606C954 shlr2 r1
    c.r[1] >>= 2;  // 0606C956 shlr2 r1
    c.r[1] >>= 2;  // 0606C958 shlr2 r1
    c.r[0] |= c.r[1];  // 0606C95A or r1,r0
    c.r[1] = ld32(0x0606C9E4u);  // 0606C95C mov.l 0x0606C9E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606C95E mov.b @(r0,r1),r1
    c.r[6] = 0x4u;  // 0606C960 mov #4,r6
    c.r[0] = ld32(0x0606C9E8u);  // 0606C962 mov.l 0x0606C9E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C968u; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C968u) return; }  // 0606C964 jsr @r0 ; add r1,r8
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606C968 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606C96A cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0606C986; } }  // 0606C96C bt/s 0x0606C986 ; mov r9,r1
    c.r[9] += 26;  // 0606C970 add #26,r9
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0606C972 mov.w @r9,r2
    c.r[1] += 22;  // 0606C974 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606C976 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606C978 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606C97A extu.w r1,r1
    c.r[2] >>= 2;  // 0606C97C shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606C97E shlr r2
    c.t = c.r[1] > c.r[2];  // 0606C980 cmp/hi r2,r1
    if (c.t) { goto L_0606C986; }  // 0606C982 bt 0x0606C986
    c.r[8] += 50;  // 0606C984 add #50,r8
L_0606C986:
    c.r[1] = ld32(0x0606C9ECu);  // 0606C986 mov.l 0x0606C9EC,r1
    c.r[1] = ld32(c.r[1]);  // 0606C988 mov.l @r1,r1
    c.r[10] <<= 2;  // 0606C98A shll2 r10
    c.r[10] <<= 2;  // 0606C98C shll2 r10
    c.r[10] += c.r[1];  // 0606C98E add r1,r10
    c.r[10] += 3;  // 0606C990 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606C992 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0606C994 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606C996 shlr r0
    c.r[0] &= 0x3u;  // 0606C998 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606C99A tst r0,r0
    { const bool k = c.t; c.r[9] = 0x64u; if (k) { goto L_0606C9A4; } }  // 0606C99C bt/s 0x0606C9A4 ; mov #100,r9
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0606C9A0 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0606C9A2 shar r8
L_0606C9A4:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 0606C9A4 cmp/gt r9,r8
    if (!c.t) { goto L_0606C9AA; }  // 0606C9A6 bf 0x0606C9AA
    c.r[8] = c.r[9];  // 0606C9A8 mov r9,r8
L_0606C9AA:
    c.t = (int32_t)c.r[8] > 0;  // 0606C9AA cmp/pl r8
    if (c.t) { goto L_0606C9B0; }  // 0606C9AC bt 0x0606C9B0
    c.r[8] = 0x1u;  // 0606C9AE mov #1,r8
L_0606C9B0:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606C9B0 tst r8,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606C9D4; } }  // 0606C9B2 bt/s 0x0606C9D4 ; mov #0,r0
    c.r[0] = c.r[8];  // 0606C9B6 mov r8,r0
    c.t = c.r[0] == 0x64u;  // 0606C9B8 cmp/eq #100,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C9D4; } }  // 0606C9BA bt/s 0x0606C9D4 ; mov #1,r0
    c.r[0] = ld32(0x0606C9F0u);  // 0606C9BE mov.l 0x0606C9F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606C9C4u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606C9C4u) return; }  // 0606C9C0 jsr @r0 ; add #1,r8
    c.macl = c.r[0] * c.r[9];  // 0606C9C4 mul.l r9,r0
    c.r[1] = c.macl;  // 0606C9C6 sts macl,r1
    c.r[1] >>= 16;  // 0606C9C8 shlr16 r1
    c.r[1] += c.r[8];  // 0606C9CA add r8,r1
    c.t = c.r[1] > c.r[9];  // 0606C9CC cmp/hi r9,r1
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606C9D4; } }  // 0606C9CE bt/s 0x0606C9D4 ; mov #1,r0
    c.r[0] = 0x0u;  // 0606C9D2 mov #0,r0
L_0606C9D4:
    c.r[15] = c.r[14];  // 0606C9D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606C9D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606C9D8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606C9DA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606C9DC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606C9DE rts ; mov.l @r15+,r8
}

void f_0606C9F4(SH2Context& c) {
    ran[1544] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606C9F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606C9F6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606C9F8 mov r15,r14
    c.r[0] = c.r[4];  // 0606C9FA mov r4,r0
    c.r[0] <<= 2;  // 0606C9FC shll2 r0
    c.r[1] = ld32(0x0606CA10u);  // 0606C9FE mov.l 0x0606CA10,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0606CA00 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CA06u; c.r[4] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CA06u) return; }  // 0606CA02 jsr @r0 ; mov r5,r4
    c.r[15] = c.r[14];  // 0606CA06 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CA08 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CA0A rts ; mov.l @r15+,r14
}

void f_0606CA14(SH2Context& c) {
    ran[1545] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CA14 mov.l r14,@-r15
    c.r[1] = ld32(0x0606CA94u);  // 0606CA16 mov.l 0x0606CA94,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CA18 mov.b @r1,r7
    c.r[5] = ld32(0x0606CA98u);  // 0606CA1A mov.l 0x0606CA98,r5
    c.r[7] = c.r[7] & 0xFFu;  // 0606CA1C extu.b r7,r7
    c.r[1] = ld32(0x0606CA9Cu);  // 0606CA1E mov.l 0x0606CA9C,r1
    c.r[3] = c.r[7];  // 0606CA20 mov r7,r3
    c.r[3] <<= 2;  // 0606CA22 shll2 r3
    c.r[3] <<= 2;  // 0606CA24 shll2 r3
    c.r[6] = ld32(c.r[1]);  // 0606CA26 mov.l @r1,r6
    c.r[4] = c.r[3];  // 0606CA28 mov r3,r4
    c.r[4] += c.r[6];  // 0606CA2A add r6,r4
    c.r[1] = c.r[4];  // 0606CA2C mov r4,r1
    c.r[1] += 1;  // 0606CA2E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CA30 mov.b @r1,r2
    c.r[0] = c.r[3];  // 0606CA32 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0606CA34 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606CA36 mov.b @(r0,r6),r1
    c.r[2] <<= 2;  // 0606CA38 shll2 r2
    c.r[2] <<= 2;  // 0606CA3A shll2 r2
    c.r[2] <<= 2;  // 0606CA3C shll2 r2
    c.r[3] = ld32(c.r[5]);  // 0606CA3E mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606CA40 extu.b r1,r1
    c.r[2] += c.r[3];  // 0606CA42 add r3,r2
    c.r[0] = c.r[2];  // 0606CA44 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CA46 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CA48 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0606CA4A cmp/eq r7,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CA8C; } }  // 0606CA4C bf/s 0x0606CA8C ; mov r15,r14
    c.r[1] = c.r[4];  // 0606CA50 mov r4,r1
    c.r[1] += 7;  // 0606CA52 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CA54 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606CA56 mov #1,r0
    c.r[3] = c.r[1];  // 0606CA58 mov r1,r3
    c.r[3] >>= 2;  // 0606CA5A shlr2 r3
    c.r[3] >>= 2;  // 0606CA5C shlr2 r3
    c.r[3] >>= 2;  // 0606CA5E shlr2 r3
    c.r[3] &= c.r[0];  // 0606CA60 and r0,r3
    c.r[3] ^= c.r[0];  // 0606CA62 xor r0,r3
    c.r[0] = 0x30u;  // 0606CA64 mov #48,r0
    c.r[1] &= c.r[0];  // 0606CA66 and r0,r1
    c.r[0] = c.r[1];  // 0606CA68 mov r1,r0
    c.t = c.r[0] == 0x10u;  // 0606CA6A cmp/eq #16,r0
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0606CA7E; } }  // 0606CA6C bf/s 0x0606CA7E ; mov #0,r2
    c.r[4] += 10;  // 0606CA70 add #10,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0606CA72 mov.b @r4,r1
    c.r[0] = c.r[1];  // 0606CA74 mov r1,r0
    c.r[0] >>= 2;  // 0606CA76 shlr2 r0
    c.r[0] &= 0x1u;  // 0606CA78 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CA7A tst r0,r0
    if (c.t) { goto L_0606CA80; }  // 0606CA7C bt 0x0606CA80
L_0606CA7E:
    c.r[2] = 0x1u;  // 0606CA7E mov #1,r2
L_0606CA80:
    c.r[3] &= c.r[2];  // 0606CA80 and r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606CA82 tst r3,r3
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606CA8E; } }  // 0606CA84 bt/s 0x0606CA8E ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606CA8E;  // 0606CA88 bra 0x0606CA8E ; mov #1,r0
L_0606CA8C:
    c.r[0] = 0x0u;  // 0606CA8C mov #0,r0
L_0606CA8E:
    c.r[15] = c.r[14];  // 0606CA8E mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CA90 rts ; mov.l @r15+,r14
}

void f_0606CAA0(SH2Context& c) {
    ran[1546] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606CAA0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CAA2 mov.l r14,@-r15
    c.r[1] = ld32(0x0606CB6Cu);  // 0606CAA4 mov.l 0x0606CB6C,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CAA6 mov.b @r1,r7
    c.r[5] = ld32(0x0606CB70u);  // 0606CAA8 mov.l 0x0606CB70,r5
    c.r[7] = c.r[7] & 0xFFu;  // 0606CAAA extu.b r7,r7
    c.r[1] = ld32(0x0606CB74u);  // 0606CAAC mov.l 0x0606CB74,r1
    c.r[3] = c.r[7];  // 0606CAAE mov r7,r3
    c.r[3] <<= 2;  // 0606CAB0 shll2 r3
    c.r[3] <<= 2;  // 0606CAB2 shll2 r3
    c.r[6] = ld32(c.r[1]);  // 0606CAB4 mov.l @r1,r6
    c.r[8] = c.r[3];  // 0606CAB6 mov r3,r8
    c.r[8] += c.r[6];  // 0606CAB8 add r6,r8
    c.r[1] = c.r[8];  // 0606CABA mov r8,r1
    c.r[1] += 1;  // 0606CABC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CABE mov.b @r1,r2
    c.r[0] = c.r[3];  // 0606CAC0 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0606CAC2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606CAC4 mov.b @(r0,r6),r1
    c.r[2] <<= 2;  // 0606CAC6 shll2 r2
    c.r[2] <<= 2;  // 0606CAC8 shll2 r2
    c.r[2] <<= 2;  // 0606CACA shll2 r2
    c.r[3] = ld32(c.r[5]);  // 0606CACC mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606CACE extu.b r1,r1
    c.r[2] += c.r[3];  // 0606CAD0 add r3,r2
    c.r[0] = c.r[2];  // 0606CAD2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CAD4 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CAD6 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0606CAD8 cmp/eq r7,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CB60; } }  // 0606CADA bf/s 0x0606CB60 ; mov r15,r14
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606CADE tst r4,r4
    { const bool k = !c.t; c.r[8] += 7; if (k) { goto L_0606CAF4; } }  // 0606CAE0 bf/s 0x0606CAF4 ; add #7,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606CAE4 mov.b @r8,r1
    c.r[0] = c.r[1];  // 0606CAE6 mov r1,r0
    c.r[0] >>= 2;  // 0606CAE8 shlr2 r0
    c.r[0] >>= 2;  // 0606CAEA shlr2 r0
    c.r[0] &= 0x1u;  // 0606CAEC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CAEE tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606CB62; } }  // 0606CAF0 bf/s 0x0606CB62 ; mov #0,r0
L_0606CAF4:
    c.r[1] = ld32(0x0606CB78u);  // 0606CAF4 mov.l 0x0606CB78,r1
    c.r[2] = ld32(c.r[1]);  // 0606CAF6 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606CB6Au);  // 0606CAF8 mov.w 0x0606CB6A,r1
    c.r[0] = c.r[2];  // 0606CAFA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CAFC mov.b @(r0,r1),r1
    c.r[3] = 0x0u;  // 0606CAFE mov #0,r3
    c.r[7] = c.r[1] & 0xFFu;  // 0606CB00 extu.b r1,r7
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 0606CB02 cmp/ge r7,r3
    if (c.t) { goto L_0606CB50; }  // 0606CB04 bt 0x0606CB50
    c.r[5] = c.r[2];  // 0606CB06 mov r2,r5
    c.r[1] = ld32(0x0606CB7Cu);  // 0606CB08 mov.l 0x0606CB7C,r1
    c.r[8] = ld32(c.r[1]);  // 0606CB0A mov.l @r1,r8
    c.r[4] = c.r[7];  // 0606CB0C mov r7,r4
    c.r[6] = c.r[5];  // 0606CB0E mov r5,r6
    c.r[7] = 0x0u;  // 0606CB10 mov #0,r7
L_0606CB12:
    c.r[1] = c.r[6];  // 0606CB12 mov r6,r1
    c.r[1] += 1;  // 0606CB14 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CB16 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CB18 extu.b r1,r1
    c.r[2] = c.r[1];  // 0606CB1A mov r1,r2
    c.r[2] <<= 2;  // 0606CB1C shll2 r2
    c.r[2] += c.r[1];  // 0606CB1E add r1,r2
    c.r[2] <<= 2;  // 0606CB20 shll2 r2
    c.r[2] += c.r[8];  // 0606CB22 add r8,r2
    c.r[1] = c.r[2];  // 0606CB24 mov r2,r1
    c.r[1] += 51;  // 0606CB26 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CB28 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606CB2A mov r1,r0
    c.r[0] >>= 2;  // 0606CB2C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606CB2E shlr r0
    c.r[0] &= 0x1u;  // 0606CB30 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CB32 tst r0,r0
    { const bool k = !c.t; c.r[2] += 50; if (k) { goto L_0606CB46; } }  // 0606CB34 bf/s 0x0606CB46 ; add #50,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CB38 mov.b @r2,r0
    c.r[1] = 0x1u;  // 0606CB3A mov #1,r1
    c.r[0] &= 0x3Fu;  // 0606CB3C and #63,r0
    c.r[0] -= 62;  // 0606CB3E add #-62,r0
    c.r[2] = c.r[0] & 0xFFFFu;  // 0606CB40 extu.w r0,r2
    c.t = c.r[2] > c.r[1];  // 0606CB42 cmp/hi r1,r2
    if (c.t) { goto L_0606CB50; }  // 0606CB44 bt 0x0606CB50
L_0606CB46:
    c.r[6] += 2;  // 0606CB46 add #2,r6
    c.r[3] += 1;  // 0606CB48 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 0606CB4A cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_0606CB12; } }  // 0606CB4C bf/s 0x0606CB12 ; add #2,r7
L_0606CB50:
    c.r[1] = ld32(0x0606CB78u);  // 0606CB50 mov.l 0x0606CB78,r1
    c.r[1] = ld32(c.r[1]);  // 0606CB52 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606CB6Au);  // 0606CB54 mov.w 0x0606CB6A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CB56 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CB58 extu.b r1,r1
    c.t = c.r[3] == c.r[1];  // 0606CB5A cmp/eq r1,r3
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0606CB62; } }  // 0606CB5C bf/s 0x0606CB62 ; mov #1,r0
L_0606CB60:
    c.r[0] = 0x0u;  // 0606CB60 mov #0,r0
L_0606CB62:
    c.r[15] = c.r[14];  // 0606CB62 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606CB64 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CB66 rts ; mov.l @r15+,r8
}

void f_0606CB80(SH2Context& c) {
    ran[1547] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606CB80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606CB82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CB84 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0606CB86 mov r15,r14
    c.r[7] = 0x0u;  // 0606CB88 mov #0,r7
    c.r[1] = ld32(0x0606CC28u);  // 0606CB8A mov.l 0x0606CC28,r1
    c.r[5] = ld32(c.r[1]);  // 0606CB8C mov.l @r1,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606CC24u);  // 0606CB8E mov.w 0x0606CC24,r9
    c.r[8] = ld32(0x0606CC2Cu);  // 0606CB90 mov.l 0x0606CC2C,r8
    c.r[6] = 0x0u;  // 0606CB92 mov #0,r6
    c.r[3] = c.r[5];  // 0606CB94 mov r5,r3
L_0606CB96:
    c.r[0] = c.r[6];  // 0606CB96 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0606CB98 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CB9A extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0606CB9C cmp/eq r9,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606CBD8; } }  // 0606CB9E bt/s 0x0606CBD8 ; mov r3,r1
    c.r[1] += 7;  // 0606CBA2 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CBA4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606CBA6 mov r1,r0
    c.r[0] >>= 2;  // 0606CBA8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606CBAA shlr r0
    c.r[0] &= 0x1u;  // 0606CBAC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CBAE tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606CBD8; } }  // 0606CBB0 bf/s 0x0606CBD8 ; mov r3,r1
    c.r[1] += 5;  // 0606CBB4 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CBB6 mov.b @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606CBB8 mov.b @r8,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606CBBA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606CBBC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0606CBBE cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606CBD8; } }  // 0606CBC0 bf/s 0x0606CBD8 ; mov r3,r1
    c.r[1] += 4;  // 0606CBC4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CBC6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606CBC8 mov r1,r0
    c.r[0] >>= 2;  // 0606CBCA shlr2 r0
    c.r[0] >>= 2;  // 0606CBCC shlr2 r0
    c.r[0] >>= 2;  // 0606CBCE shlr2 r0
    c.r[0] &= 0x1u;  // 0606CBD0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CBD2 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_0606CBE6; } }  // 0606CBD4 bf/s 0x0606CBE6 ; tst r4,r4
L_0606CBD8:
    c.r[3] += 16;  // 0606CBD8 add #16,r3
    c.r[7] += 1;  // 0606CBDA add #1,r7
    c.r[1] = 0x49u;  // 0606CBDC mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0606CBDE cmp/gt r1,r7
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_0606CB96; } }  // 0606CBE0 bf/s 0x0606CB96 ; add #16,r6
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606CBE4 tst r4,r4
L_0606CBE6:
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606CC1A; } }  // 0606CBE6 bf/s 0x0606CC1A ; mov #0,r0
    c.r[1] = ld32(0x0606CC2Cu);  // 0606CBEA mov.l 0x0606CC2C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CBEC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CBEE extu.b r2,r2
    c.r[1] = ld32(0x0606CC28u);  // 0606CBF0 mov.l 0x0606CC28,r1
    c.r[1] = ld32(c.r[1]);  // 0606CBF2 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CBF4 shll2 r2
    c.r[2] <<= 2;  // 0606CBF6 shll2 r2
    c.r[2] += c.r[1];  // 0606CBF8 add r1,r2
    c.r[2] += 7;  // 0606CBFA add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CBFC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CBFE extu.b r1,r1
    c.r[1] >>= 2;  // 0606CC00 shlr2 r1
    c.r[1] >>= 2;  // 0606CC02 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606CC04 shlr r1
    c.r[1] >>= 2;  // 0606CC06 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606CC08 tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0606CC1C; } }  // 0606CC0A bt/s 0x0606CC1C ; mov r14,r15
    c.r[0] = c.r[7];  // 0606CC0E mov r7,r0
    c.t = c.r[0] == 0x4Au;  // 0606CC10 cmp/eq #74,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606CC1C; } }  // 0606CC12 bt/s 0x0606CC1C ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606CC1C;  // 0606CC16 bra 0x0606CC1C ; mov #1,r0
L_0606CC1A:
    c.r[15] = c.r[14];  // 0606CC1A mov r14,r15
L_0606CC1C:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606CC1C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606CC1E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CC20 rts ; mov.l @r15+,r8
}

void f_0606CC30(SH2Context& c) {
    ran[1548] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CC30 mov.l r14,@-r15
    c.r[1] = ld32(0x0606CC64u);  // 0606CC32 mov.l 0x0606CC64,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CC34 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CC36 extu.b r2,r2
    c.r[1] = ld32(0x0606CC68u);  // 0606CC38 mov.l 0x0606CC68,r1
    c.r[1] = ld32(c.r[1]);  // 0606CC3A mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CC3C shll2 r2
    c.r[2] <<= 2;  // 0606CC3E shll2 r2
    c.r[2] += c.r[1];  // 0606CC40 add r1,r2
    c.r[2] += 4;  // 0606CC42 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CC44 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606CC46 mov r1,r0
    c.r[0] >>= 2;  // 0606CC48 shlr2 r0
    c.r[0] >>= 2;  // 0606CC4A shlr2 r0
    c.r[0] >>= 2;  // 0606CC4C shlr2 r0
    c.r[0] &= 0x1u;  // 0606CC4E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CC50 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CC5A; } }  // 0606CC52 bf/s 0x0606CC5A ; mov r15,r14
    c.r[0] = 0x0u; goto L_0606CC5C;  // 0606CC56 bra 0x0606CC5C ; mov #0,r0
L_0606CC5A:
    c.r[0] = 0x1u;  // 0606CC5A mov #1,r0
L_0606CC5C:
    c.r[15] = c.r[14];  // 0606CC5C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CC5E rts ; mov.l @r15+,r14
}

void f_0606CC6C(SH2Context& c) {
    ran[1549] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CC6C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CC6E sts.l pr,@-r15
    c.r[1] = ld32(0x0606CCA8u);  // 0606CC70 mov.l 0x0606CCA8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CC72 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CC74 extu.b r2,r2
    c.r[1] = ld32(0x0606CCACu);  // 0606CC76 mov.l 0x0606CCAC,r1
    c.r[1] = ld32(c.r[1]);  // 0606CC78 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CC7A shll2 r2
    c.r[2] <<= 2;  // 0606CC7C shll2 r2
    c.r[2] += c.r[1];  // 0606CC7E add r1,r2
    c.r[2] += 4;  // 0606CC80 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CC82 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606CC84 mov r1,r0
    c.r[0] >>= 2;  // 0606CC86 shlr2 r0
    c.r[0] >>= 2;  // 0606CC88 shlr2 r0
    c.r[0] >>= 2;  // 0606CC8A shlr2 r0
    c.r[0] &= 0x1u;  // 0606CC8C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CC8E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CC98; } }  // 0606CC90 bt/s 0x0606CC98 ; mov r15,r14
    c.r[0] = 0x0u; goto L_0606CC9E;  // 0606CC94 bra 0x0606CC9E ; mov #0,r0
L_0606CC98:
    c.r[0] = ld32(0x0606CCB0u);  // 0606CC98 mov.l 0x0606CCB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CC9Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CC9Eu) return; }  // 0606CC9A jsr @r0 ; mov #0,r4
L_0606CC9E:
    c.r[15] = c.r[14];  // 0606CC9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CCA0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CCA2 rts ; mov.l @r15+,r14
}

void f_0606CCB4(SH2Context& c) {
    ran[1550] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CCB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CCB6 sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606CCB8 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CCEA; } }  // 0606CCBA bf/s 0x0606CCEA ; mov r15,r14
    c.r[1] = ld32(0x0606CCF4u);  // 0606CCBE mov.l 0x0606CCF4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CCC0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CCC2 extu.b r2,r2
    c.r[1] = ld32(0x0606CCF8u);  // 0606CCC4 mov.l 0x0606CCF8,r1
    c.r[1] = ld32(c.r[1]);  // 0606CCC6 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CCC8 shll2 r2
    c.r[2] <<= 2;  // 0606CCCA shll2 r2
    c.r[2] += c.r[1];  // 0606CCCC add r1,r2
    c.r[2] += 7;  // 0606CCCE add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CCD0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606CCD2 mov r1,r0
    c.r[0] >>= 2;  // 0606CCD4 shlr2 r0
    c.r[0] >>= 2;  // 0606CCD6 shlr2 r0
    c.r[0] &= 0x1u;  // 0606CCD8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CCDA tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606CCEC; } }  // 0606CCDC bf/s 0x0606CCEC ; mov #0,r0
    c.r[0] = ld32(0x0606CCFCu);  // 0606CCE0 mov.l 0x0606CCFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CCE6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CCE6u) return; }  // 0606CCE2 jsr @r0 ; mov #0,r4
    c.r[15] = c.r[14]; goto L_0606CCEE;  // 0606CCE6 bra 0x0606CCEE ; mov r14,r15
L_0606CCEA:
    c.r[0] = 0x0u;  // 0606CCEA mov #0,r0
L_0606CCEC:
    c.r[15] = c.r[14];  // 0606CCEC mov r14,r15
L_0606CCEE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CCEE lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CCF0 rts ; mov.l @r15+,r14
}

void f_0606CD00(SH2Context& c) {
    ran[1551] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CD00 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CD02 sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606CD04 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CD52; } }  // 0606CD06 bf/s 0x0606CD52 ; mov r15,r14
    c.r[1] = ld32(0x0606CD60u);  // 0606CD0A mov.l 0x0606CD60,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CD0C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CD0E extu.b r2,r2
    c.r[1] = ld32(0x0606CD64u);  // 0606CD10 mov.l 0x0606CD64,r1
    c.r[1] = ld32(c.r[1]);  // 0606CD12 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CD14 shll2 r2
    c.r[2] <<= 2;  // 0606CD16 shll2 r2
    c.r[2] += c.r[1];  // 0606CD18 add r1,r2
    c.r[2] += 7;  // 0606CD1A add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CD1C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606CD1E mov r1,r0
    c.r[0] >>= 2;  // 0606CD20 shlr2 r0
    c.r[0] >>= 2;  // 0606CD22 shlr2 r0
    c.r[0] &= 0x1u;  // 0606CD24 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CD26 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606CD54; } }  // 0606CD28 bf/s 0x0606CD54 ; mov #0,r0
    c.r[1] = ld32(0x0606CD68u);  // 0606CD2C mov.l 0x0606CD68,r1
    c.r[1] = ld32(c.r[1]);  // 0606CD2E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606CD5Cu);  // 0606CD30 mov.w 0x0606CD5C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CD32 mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 0606CD34 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606CD36 shlr r0
    c.r[0] &= 0xFu;  // 0606CD38 and #15,r0
    c.t = c.r[0] == 0x2u;  // 0606CD3A cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606CD54; } }  // 0606CD3C bt/s 0x0606CD54 ; mov #0,r0
    c.r[0] = ld32(0x0606CD6Cu);  // 0606CD40 mov.l 0x0606CD6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CD46u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CD46u) return; }  // 0606CD42 jsr @r0 ; mov #0,r4
    c.r[0] &= 0xF0u;  // 0606CD46 and #240,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CD48 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606CD54; } }  // 0606CD4A bt/s 0x0606CD54 ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606CD54;  // 0606CD4E bra 0x0606CD54 ; mov #1,r0
L_0606CD52:
    c.r[0] = 0x0u;  // 0606CD52 mov #0,r0
L_0606CD54:
    c.r[15] = c.r[14];  // 0606CD54 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CD56 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CD58 rts ; mov.l @r15+,r14
}

void f_0606CD70(SH2Context& c) {
    ran[1552] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CD70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CD72 sts.l pr,@-r15
    c.r[7] = c.r[4];  // 0606CD74 mov r4,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0606CD76 tst r7,r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CD80; } }  // 0606CD78 bt/s 0x0606CD80 ; mov r15,r14
    c.r[0] = 0x0u; goto L_0606CDC0;  // 0606CD7C bra 0x0606CDC0 ; mov #0,r0
L_0606CD80:
    c.r[1] = ld32(0x0606CDC8u);  // 0606CD80 mov.l 0x0606CDC8,r1
    c.r[5] = ld32(c.r[1]);  // 0606CD82 mov.l @r1,r5
    c.r[1] = ld32(0x0606CDCCu);  // 0606CD84 mov.l 0x0606CDCC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CD86 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CD88 extu.b r2,r2
    c.r[1] = ld32(0x0606CDD0u);  // 0606CD8A mov.l 0x0606CDD0,r1
    c.r[1] = ld32(c.r[1]);  // 0606CD8C mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CD8E shll2 r2
    c.r[2] <<= 2;  // 0606CD90 shll2 r2
    c.r[2] += c.r[1];  // 0606CD92 add r1,r2
    c.r[2] += 2;  // 0606CD94 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CD96 mov.b @r2,r2
    c.r[1] = ld32(0x0606CDD4u);  // 0606CD98 mov.l 0x0606CDD4,r1
    c.r[3] = ld32(c.r[1]);  // 0606CD9A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606CD9C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606CD9E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606CDA0 mul.l r1,r2
    c.r[6] = 0x3u;  // 0606CDA2 mov #3,r6
    c.r[1] = c.macl;  // 0606CDA4 sts macl,r1
    c.r[0] = c.r[1];  // 0606CDA6 mov r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0606CDA8 mov.w @(r0,r3),r4
    c.r[5] += 20;  // 0606CDAA add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 0606CDAC extu.w r4,r4
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0606CDAE mov.l r7,@-r15
    c.r[0] = ld32(0x0606CDD8u);  // 0606CDB0 mov.l 0x0606CDD8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CDB6u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CDB6u) return; }  // 0606CDB2 jsr @r0 ; mov #0,r7
    c.r[1] = c.r[0];  // 0606CDB6 mov r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0606CDB8 extu.w r1,r2
    c.r[1] = 0x1u;  // 0606CDBA mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0606CDBC cmp/hi r1,r2
    c.r[0] = c.t;  // 0606CDBE movt r0
L_0606CDC0:
    c.r[15] = c.r[14];  // 0606CDC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CDC2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CDC4 rts ; mov.l @r15+,r14
}

void f_0606CDDC(SH2Context& c) {
    ran[1553] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CDDC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CDDE sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606CDE0 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606CE16; } }  // 0606CDE2 bf/s 0x0606CE16 ; mov r15,r14
    c.r[1] = ld32(0x0606CE20u);  // 0606CDE6 mov.l 0x0606CE20,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CDE8 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606CDEA extu.b r2,r2
    c.r[1] = ld32(0x0606CE24u);  // 0606CDEC mov.l 0x0606CE24,r1
    c.r[1] = ld32(c.r[1]);  // 0606CDEE mov.l @r1,r1
    c.r[2] <<= 2;  // 0606CDF0 shll2 r2
    c.r[2] <<= 2;  // 0606CDF2 shll2 r2
    c.r[2] += c.r[1];  // 0606CDF4 add r1,r2
    c.r[2] += 7;  // 0606CDF6 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CDF8 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606CDFA mov r1,r0
    c.r[0] >>= 2;  // 0606CDFC shlr2 r0
    c.r[0] >>= 2;  // 0606CDFE shlr2 r0
    c.r[0] &= 0x1u;  // 0606CE00 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CE02 tst r0,r0
    if (!c.t) { goto L_0606CE16; }  // 0606CE04 bf 0x0606CE16
    c.r[0] = ld32(0x0606CE28u);  // 0606CE06 mov.l 0x0606CE28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CE0Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CE0Cu) return; }  // 0606CE08 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0606CE0C extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606CE0E tst r1,r1
    c.r[0] = c.t;  // 0606CE10 movt r0
    c.r[0] ^= 0x1u; goto L_0606CE18;  // 0606CE12 bra 0x0606CE18 ; xor #1,r0
L_0606CE16:
    c.r[0] = 0x0u;  // 0606CE16 mov #0,r0
L_0606CE18:
    c.r[15] = c.r[14];  // 0606CE18 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CE1A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CE1C rts ; mov.l @r15+,r14
}

void f_0606CE2C(SH2Context& c) {
    ran[1554] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606CE2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606CE2E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606CE30 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606CE32 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606CE34 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606CE36 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CE38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CE3A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606CE3C mov r15,r14
    c.r[8] = c.r[4];  // 0606CE3E mov r4,r8
    c.r[13] = ld32(0x0606CF4Cu);  // 0606CE40 mov.l 0x0606CF4C,r13
    c.r[10] = ld32(0x0606CF50u);  // 0606CE42 mov.l 0x0606CF50,r10
    c.r[5] = 0x22u;  // 0606CE44 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CE4Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CE4Au) return; }  // 0606CE46 jsr @r10 ; mov r13,r4
    c.r[1] = c.r[0];  // 0606CE4A mov r0,r1
    c.r[5] = 0x0u;  // 0606CE4C mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CE52u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CE52u) return; }  // 0606CE4E jsr @r10 ; mov r1,r4
    c.r[1] = ld32(0x0606CF54u);  // 0606CE52 mov.l 0x0606CF54,r1
    c.r[1] = ld32(c.r[1]);  // 0606CE54 mov.l @r1,r1
    c.r[1] += 37;  // 0606CE56 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CE58 mov.b @r1,r1
    c.r[3] = c.r[0];  // 0606CE5A mov r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606CE5C extu.b r1,r1
    c.r[1] >>= 2;  // 0606CE5E shlr2 r1
    c.r[1] >>= 2;  // 0606CE60 shlr2 r1
    c.r[2] = c.r[1];  // 0606CE62 mov r1,r2
    c.r[2] <<= 2;  // 0606CE64 shll2 r2
    c.r[2] += c.r[1];  // 0606CE66 add r1,r2
    c.r[2] += c.r[3];  // 0606CE68 add r3,r2
    c.r[2] += 3;  // 0606CE6A add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CE6C mov.b @r2,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606CE6E extu.b r1,r12
    c.r[1] = ld32(0x0606CF58u);  // 0606CE70 mov.l 0x0606CF58,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CE72 mov.b @r1,r2
    c.r[6] = ld32(0x0606CF5Cu);  // 0606CE74 mov.l 0x0606CF5C,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0606CE76 extu.b r2,r2
    c.r[1] = ld32(0x0606CF60u);  // 0606CE78 mov.l 0x0606CF60,r1
    c.r[2] <<= 2;  // 0606CE7A shll2 r2
    c.r[2] <<= 2;  // 0606CE7C shll2 r2
    c.r[7] = ld32(c.r[1]);  // 0606CE7E mov.l @r1,r7
    c.r[9] = c.r[2];  // 0606CE80 mov r2,r9
    c.r[9] += c.r[7];  // 0606CE82 add r7,r9
    c.r[1] = c.r[9];  // 0606CE84 mov r9,r1
    c.r[1] += 1;  // 0606CE86 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CE88 mov.b @r1,r3
    c.r[0] = c.r[2];  // 0606CE8A mov r2,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0606CE8C extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606CE8E mov.b @(r0,r7),r1
    c.r[3] <<= 2;  // 0606CE90 shll2 r3
    c.r[3] <<= 2;  // 0606CE92 shll2 r3
    c.r[3] <<= 2;  // 0606CE94 shll2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606CF46u);  // 0606CE96 mov.w 0x0606CF46,r2
    c.r[0] = c.r[6];  // 0606CE98 mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0606CE9A mov.l @(r0,r2),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606CE9C extu.b r1,r1
    c.r[3] += c.r[2];  // 0606CE9E add r2,r3
    c.r[0] = c.r[3];  // 0606CEA0 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CEA2 mov.b @(r0,r1),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606CEA4 tst r8,r8
    { const bool k = !c.t; c.r[11] = c.r[1] & 0xFFu; if (k) { goto L_0606CF30; } }  // 0606CEA6 bf/s 0x0606CF30 ; extu.b r1,r11
    c.r[1] = c.r[9];  // 0606CEAA mov r9,r1
    c.r[1] += 7;  // 0606CEAC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CEAE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606CEB0 mov r1,r0
    c.r[0] >>= 2;  // 0606CEB2 shlr2 r0
    c.r[0] >>= 2;  // 0606CEB4 shlr2 r0
    c.r[0] &= 0x1u;  // 0606CEB6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CEB8 tst r0,r0
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_0606CF30; } }  // 0606CEBA bf/s 0x0606CF30 ; mov #1,r4
    c.r[1] = ld32(0x0606CF64u);  // 0606CEBE mov.l 0x0606CF64,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CEC0 mov.b @r1,r0
    c.r[1] = 0xFu;  // 0606CEC2 mov #15,r1
    c.r[1] &= c.r[0];  // 0606CEC4 and r0,r1
    c.r[0] = ld32(0x0606CF68u);  // 0606CEC6 mov.l 0x0606CF68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606CECCu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CECCu) return; }  // 0606CEC8 jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606CF48u);  // 0606CECC mov.w 0x0606CF48,r1
    c.r[0] &= c.r[1];  // 0606CECE and r1,r0
    c.r[1] = ld32(0x0606CF6Cu);  // 0606CED0 mov.l 0x0606CF6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606CED6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CED6u) return; }  // 0606CED2 jsr @r1 ; mov r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606CED6 tst r4,r4
    { const bool k = !c.t; c.r[9] += 3; if (k) { goto L_0606CF30; } }  // 0606CED8 bf/s 0x0606CF30 ; add #3,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606CEDC mov.b @r9,r1
    c.r[0] = 0x3u;  // 0606CEDE mov #3,r0
    c.r[1] >>= 2;  // 0606CEE0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606CEE2 shlr r1
    c.r[1] &= c.r[0];  // 0606CEE4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606CEE6 tst r1,r1
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0606CEF4; } }  // 0606CEE8 bt/s 0x0606CEF4 ; tst r12,r12
    c.r[0] = c.r[1];  // 0606CEEC mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0606CEEE cmp/eq #2,r0
    { const bool k = !c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0606CF30; } }  // 0606CEF0 bf/s 0x0606CF30 ; tst r12,r12
L_0606CEF4:
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606CF32; } }  // 0606CEF4 bt/s 0x0606CF32 ; mov #0,r0
    c.r[5] = 0x22u;  // 0606CEF8 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CEFEu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CEFEu) return; }  // 0606CEFA jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606CEFE mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF04u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF04u) return; }  // 0606CF00 jsr @r10 ; mov r0,r4
    c.r[5] = c.r[12];  // 0606CF04 mov r12,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF0Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF0Au) return; }  // 0606CF06 jsr @r10 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606CF0A mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606CF0C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606CF0E tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606CF32; } }  // 0606CF10 bt/s 0x0606CF32 ; mov #0,r0
    c.r[5] = 0x22u;  // 0606CF14 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF1Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF1Au) return; }  // 0606CF16 jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606CF1A mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF20u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF20u) return; }  // 0606CF1C jsr @r10 ; mov r0,r4
    c.r[5] = 0x3u;  // 0606CF20 mov #3,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF26u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF26u) return; }  // 0606CF22 jsr @r10 ; mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606CF26 mov.b @(r0,r11),r0
    c.r[0] &= 0x40u;  // 0606CF28 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CF2A tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606CF32; } }  // 0606CF2C bt/s 0x0606CF32 ; mov #1,r0
L_0606CF30:
    c.r[0] = 0x0u;  // 0606CF30 mov #0,r0
L_0606CF32:
    c.r[15] = c.r[14];  // 0606CF32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606CF34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606CF36 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606CF38 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606CF3A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606CF3C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606CF3E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606CF40 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606CF42 rts ; mov.l @r15+,r8
}

void f_0606CF70(SH2Context& c) {
    ran[1555] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606CF70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606CF72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606CF74 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606CF76 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606CF78 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606CF7A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606CF7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606CF7E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606CF80 mov r15,r14
    c.r[8] = c.r[4];  // 0606CF82 mov r4,r8
    c.r[13] = ld32(0x0606D070u);  // 0606CF84 mov.l 0x0606D070,r13
    c.r[10] = ld32(0x0606D074u);  // 0606CF86 mov.l 0x0606D074,r10
    c.r[5] = 0x22u;  // 0606CF88 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF8Eu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF8Eu) return; }  // 0606CF8A jsr @r10 ; mov r13,r4
    c.r[1] = c.r[0];  // 0606CF8E mov r0,r1
    c.r[5] = 0x0u;  // 0606CF90 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606CF96u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606CF96u) return; }  // 0606CF92 jsr @r10 ; mov r1,r4
    c.r[1] = ld32(0x0606D078u);  // 0606CF96 mov.l 0x0606D078,r1
    c.r[1] = ld32(c.r[1]);  // 0606CF98 mov.l @r1,r1
    c.r[1] += 37;  // 0606CF9A add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CF9C mov.b @r1,r1
    c.r[3] = c.r[0];  // 0606CF9E mov r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606CFA0 extu.b r1,r1
    c.r[1] >>= 2;  // 0606CFA2 shlr2 r1
    c.r[1] >>= 2;  // 0606CFA4 shlr2 r1
    c.r[2] = c.r[1];  // 0606CFA6 mov r1,r2
    c.r[2] <<= 2;  // 0606CFA8 shll2 r2
    c.r[2] += c.r[1];  // 0606CFAA add r1,r2
    c.r[2] += c.r[3];  // 0606CFAC add r3,r2
    c.r[2] += 2;  // 0606CFAE add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606CFB0 mov.b @r2,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606CFB2 extu.b r1,r11
    c.r[1] = ld32(0x0606D07Cu);  // 0606CFB4 mov.l 0x0606D07C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CFB6 mov.b @r1,r2
    c.r[6] = ld32(0x0606D080u);  // 0606CFB8 mov.l 0x0606D080,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0606CFBA extu.b r2,r2
    c.r[1] = ld32(0x0606D084u);  // 0606CFBC mov.l 0x0606D084,r1
    c.r[2] <<= 2;  // 0606CFBE shll2 r2
    c.r[2] <<= 2;  // 0606CFC0 shll2 r2
    c.r[7] = ld32(c.r[1]);  // 0606CFC2 mov.l @r1,r7
    c.r[9] = c.r[2];  // 0606CFC4 mov r2,r9
    c.r[9] += c.r[7];  // 0606CFC6 add r7,r9
    c.r[1] = c.r[9];  // 0606CFC8 mov r9,r1
    c.r[1] += 1;  // 0606CFCA add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CFCC mov.b @r1,r3
    c.r[0] = c.r[2];  // 0606CFCE mov r2,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0606CFD0 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606CFD2 mov.b @(r0,r7),r1
    c.r[3] <<= 2;  // 0606CFD4 shll2 r3
    c.r[3] <<= 2;  // 0606CFD6 shll2 r3
    c.r[3] <<= 2;  // 0606CFD8 shll2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606D06Au);  // 0606CFDA mov.w 0x0606D06A,r2
    c.r[0] = c.r[6];  // 0606CFDC mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0606CFDE mov.l @(r0,r2),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606CFE0 extu.b r1,r1
    c.r[3] += c.r[2];  // 0606CFE2 add r2,r3
    c.r[0] = c.r[3];  // 0606CFE4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606CFE6 mov.b @(r0,r1),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606CFE8 tst r8,r8
    { const bool k = !c.t; c.r[12] = c.r[1] & 0xFFu; if (k) { goto L_0606D054; } }  // 0606CFEA bf/s 0x0606D054 ; extu.b r1,r12
    c.r[1] = c.r[9];  // 0606CFEE mov r9,r1
    c.r[1] += 7;  // 0606CFF0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606CFF2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606CFF4 mov r1,r0
    c.r[0] >>= 2;  // 0606CFF6 shlr2 r0
    c.r[0] >>= 2;  // 0606CFF8 shlr2 r0
    c.r[0] &= 0x1u;  // 0606CFFA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606CFFC tst r0,r0
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_0606D054; } }  // 0606CFFE bf/s 0x0606D054 ; mov #1,r4
    c.r[1] = ld32(0x0606D088u);  // 0606D002 mov.l 0x0606D088,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D004 mov.b @r1,r0
    c.r[1] = 0xFu;  // 0606D006 mov #15,r1
    c.r[1] &= c.r[0];  // 0606D008 and r0,r1
    c.r[0] = ld32(0x0606D08Cu);  // 0606D00A mov.l 0x0606D08C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606D010u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D010u) return; }  // 0606D00C jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D06Cu);  // 0606D010 mov.w 0x0606D06C,r1
    c.r[0] &= c.r[1];  // 0606D012 and r1,r0
    c.r[1] = ld32(0x0606D090u);  // 0606D014 mov.l 0x0606D090,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D01Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D01Au) return; }  // 0606D016 jsr @r1 ; mov r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D01A tst r4,r4
    { const bool k = !c.t; c.r[9] += 3; if (k) { goto L_0606D054; } }  // 0606D01C bf/s 0x0606D054 ; add #3,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606D020 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0606D022 mov r1,r0
    c.r[0] >>= 2;  // 0606D024 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606D026 shlr r0
    c.r[0] &= 0x3u;  // 0606D028 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D02A tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D056; } }  // 0606D02C bt/s 0x0606D056 ; mov #0,r0
    c.t = (c.r[11] & c.r[11]) == 0;  // 0606D030 tst r11,r11
    { const bool k = c.t; c.r[5] = 0x22u; if (k) { goto L_0606D056; } }  // 0606D032 bt/s 0x0606D056 ; mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D03Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D03Au) return; }  // 0606D036 jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606D03A mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D040u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D040u) return; }  // 0606D03C jsr @r10 ; mov r0,r4
    c.r[5] = c.r[11];  // 0606D040 mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D046u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D046u) return; }  // 0606D042 jsr @r10 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606D046 mov.b @(r0,r12),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606D048 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D04A tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D056; } }  // 0606D04C bt/s 0x0606D056 ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606D056;  // 0606D050 bra 0x0606D056 ; mov #1,r0
L_0606D054:
    c.r[0] = 0x0u;  // 0606D054 mov #0,r0
L_0606D056:
    c.r[15] = c.r[14];  // 0606D056 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D058 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606D05A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606D05C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606D05E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606D060 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606D062 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606D064 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D066 rts ; mov.l @r15+,r8
}

void f_0606D094(SH2Context& c) {
    ran[1556] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606D094 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606D096 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606D098 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606D09A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606D09C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606D09E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D0A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D0A2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606D0A4 mov r15,r14
    c.r[8] = c.r[4];  // 0606D0A6 mov r4,r8
    c.r[13] = ld32(0x0606D1B0u);  // 0606D0A8 mov.l 0x0606D1B0,r13
    c.r[10] = ld32(0x0606D1B4u);  // 0606D0AA mov.l 0x0606D1B4,r10
    c.r[5] = 0x22u;  // 0606D0AC mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D0B2u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D0B2u) return; }  // 0606D0AE jsr @r10 ; mov r13,r4
    c.r[1] = c.r[0];  // 0606D0B2 mov r0,r1
    c.r[5] = 0x0u;  // 0606D0B4 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D0BAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D0BAu) return; }  // 0606D0B6 jsr @r10 ; mov r1,r4
    c.r[1] = ld32(0x0606D1B8u);  // 0606D0BA mov.l 0x0606D1B8,r1
    c.r[1] = ld32(c.r[1]);  // 0606D0BC mov.l @r1,r1
    c.r[1] += 37;  // 0606D0BE add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D0C0 mov.b @r1,r1
    c.r[3] = c.r[0];  // 0606D0C2 mov r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606D0C4 extu.b r1,r1
    c.r[1] >>= 2;  // 0606D0C6 shlr2 r1
    c.r[1] >>= 2;  // 0606D0C8 shlr2 r1
    c.r[2] = c.r[1];  // 0606D0CA mov r1,r2
    c.r[2] <<= 2;  // 0606D0CC shll2 r2
    c.r[2] += c.r[1];  // 0606D0CE add r1,r2
    c.r[2] += c.r[3];  // 0606D0D0 add r3,r2
    c.r[2] += 3;  // 0606D0D2 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D0D4 mov.b @r2,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606D0D6 extu.b r1,r12
    c.r[1] = ld32(0x0606D1BCu);  // 0606D0D8 mov.l 0x0606D1BC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D0DA mov.b @r1,r2
    c.r[6] = ld32(0x0606D1C0u);  // 0606D0DC mov.l 0x0606D1C0,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0606D0DE extu.b r2,r2
    c.r[1] = ld32(0x0606D1C4u);  // 0606D0E0 mov.l 0x0606D1C4,r1
    c.r[2] <<= 2;  // 0606D0E2 shll2 r2
    c.r[2] <<= 2;  // 0606D0E4 shll2 r2
    c.r[7] = ld32(c.r[1]);  // 0606D0E6 mov.l @r1,r7
    c.r[9] = c.r[2];  // 0606D0E8 mov r2,r9
    c.r[9] += c.r[7];  // 0606D0EA add r7,r9
    c.r[1] = c.r[9];  // 0606D0EC mov r9,r1
    c.r[1] += 1;  // 0606D0EE add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D0F0 mov.b @r1,r3
    c.r[0] = c.r[2];  // 0606D0F2 mov r2,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0606D0F4 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606D0F6 mov.b @(r0,r7),r1
    c.r[3] <<= 2;  // 0606D0F8 shll2 r3
    c.r[3] <<= 2;  // 0606D0FA shll2 r3
    c.r[3] <<= 2;  // 0606D0FC shll2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606D1AAu);  // 0606D0FE mov.w 0x0606D1AA,r2
    c.r[0] = c.r[6];  // 0606D100 mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0606D102 mov.l @(r0,r2),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606D104 extu.b r1,r1
    c.r[3] += c.r[2];  // 0606D106 add r2,r3
    c.r[0] = c.r[3];  // 0606D108 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606D10A mov.b @(r0,r1),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606D10C tst r8,r8
    { const bool k = !c.t; c.r[11] = c.r[1] & 0xFFu; if (k) { goto L_0606D194; } }  // 0606D10E bf/s 0x0606D194 ; extu.b r1,r11
    c.r[1] = c.r[9];  // 0606D112 mov r9,r1
    c.r[1] += 7;  // 0606D114 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D116 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606D118 mov r1,r0
    c.r[0] >>= 2;  // 0606D11A shlr2 r0
    c.r[0] >>= 2;  // 0606D11C shlr2 r0
    c.r[0] &= 0x1u;  // 0606D11E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D120 tst r0,r0
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_0606D194; } }  // 0606D122 bf/s 0x0606D194 ; mov #1,r4
    c.r[1] = ld32(0x0606D1C8u);  // 0606D126 mov.l 0x0606D1C8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D128 mov.b @r1,r0
    c.r[1] = 0xFu;  // 0606D12A mov #15,r1
    c.r[1] &= c.r[0];  // 0606D12C and r0,r1
    c.r[0] = ld32(0x0606D1CCu);  // 0606D12E mov.l 0x0606D1CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606D134u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D134u) return; }  // 0606D130 jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D1ACu);  // 0606D134 mov.w 0x0606D1AC,r1
    c.r[0] &= c.r[1];  // 0606D136 and r1,r0
    c.r[1] = ld32(0x0606D1D0u);  // 0606D138 mov.l 0x0606D1D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D13Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D13Eu) return; }  // 0606D13A jsr @r1 ; mov r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D13E tst r4,r4
    { const bool k = !c.t; c.r[9] += 3; if (k) { goto L_0606D194; } }  // 0606D140 bf/s 0x0606D194 ; add #3,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606D144 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0606D146 mov r1,r0
    c.r[0] >>= 2;  // 0606D148 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606D14A shlr r0
    c.r[0] &= 0x3u;  // 0606D14C and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D14E tst r0,r0
    { const bool k = !c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0606D194; } }  // 0606D150 bf/s 0x0606D194 ; tst r12,r12
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D196; } }  // 0606D154 bt/s 0x0606D196 ; mov #0,r0
    c.r[5] = 0x22u;  // 0606D158 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D15Eu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D15Eu) return; }  // 0606D15A jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606D15E mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D164u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D164u) return; }  // 0606D160 jsr @r10 ; mov r0,r4
    c.r[5] = c.r[12];  // 0606D164 mov r12,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D16Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D16Au) return; }  // 0606D166 jsr @r10 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606D16A mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606D16C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D16E tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D196; } }  // 0606D170 bt/s 0x0606D196 ; mov #0,r0
    c.r[5] = 0x22u;  // 0606D174 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D17Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D17Au) return; }  // 0606D176 jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606D17A mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D180u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D180u) return; }  // 0606D17C jsr @r10 ; mov r0,r4
    c.r[5] = 0x3u;  // 0606D180 mov #3,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D186u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D186u) return; }  // 0606D182 jsr @r10 ; mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606D186 mov.b @(r0,r11),r0
    c.r[0] &= 0x40u;  // 0606D188 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D18A tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D196; } }  // 0606D18C bt/s 0x0606D196 ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606D196;  // 0606D190 bra 0x0606D196 ; mov #1,r0
L_0606D194:
    c.r[0] = 0x0u;  // 0606D194 mov #0,r0
L_0606D196:
    c.r[15] = c.r[14];  // 0606D196 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D198 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606D19A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606D19C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606D19E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606D1A0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606D1A2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606D1A4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D1A6 rts ; mov.l @r15+,r8
}

void f_0606D1D4(SH2Context& c) {
    ran[1557] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606D1D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606D1D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606D1D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606D1DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606D1DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606D1DE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D1E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D1E2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606D1E4 mov r15,r14
    c.r[8] = c.r[4];  // 0606D1E6 mov r4,r8
    c.r[13] = ld32(0x0606D2ECu);  // 0606D1E8 mov.l 0x0606D2EC,r13
    c.r[10] = ld32(0x0606D2F0u);  // 0606D1EA mov.l 0x0606D2F0,r10
    c.r[5] = 0x22u;  // 0606D1EC mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D1F2u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D1F2u) return; }  // 0606D1EE jsr @r10 ; mov r13,r4
    c.r[1] = c.r[0];  // 0606D1F2 mov r0,r1
    c.r[5] = 0x0u;  // 0606D1F4 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D1FAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D1FAu) return; }  // 0606D1F6 jsr @r10 ; mov r1,r4
    c.r[1] = ld32(0x0606D2F4u);  // 0606D1FA mov.l 0x0606D2F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606D1FC mov.l @r1,r1
    c.r[1] += 37;  // 0606D1FE add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D200 mov.b @r1,r1
    c.r[3] = c.r[0];  // 0606D202 mov r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606D204 extu.b r1,r1
    c.r[1] >>= 2;  // 0606D206 shlr2 r1
    c.r[1] >>= 2;  // 0606D208 shlr2 r1
    c.r[2] = c.r[1];  // 0606D20A mov r1,r2
    c.r[2] <<= 2;  // 0606D20C shll2 r2
    c.r[2] += c.r[1];  // 0606D20E add r1,r2
    c.r[2] += c.r[3];  // 0606D210 add r3,r2
    c.r[2] += 4;  // 0606D212 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D214 mov.b @r2,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606D216 extu.b r1,r12
    c.r[1] = ld32(0x0606D2F8u);  // 0606D218 mov.l 0x0606D2F8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D21A mov.b @r1,r2
    c.r[6] = ld32(0x0606D2FCu);  // 0606D21C mov.l 0x0606D2FC,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0606D21E extu.b r2,r2
    c.r[1] = ld32(0x0606D300u);  // 0606D220 mov.l 0x0606D300,r1
    c.r[2] <<= 2;  // 0606D222 shll2 r2
    c.r[2] <<= 2;  // 0606D224 shll2 r2
    c.r[7] = ld32(c.r[1]);  // 0606D226 mov.l @r1,r7
    c.r[9] = c.r[2];  // 0606D228 mov r2,r9
    c.r[9] += c.r[7];  // 0606D22A add r7,r9
    c.r[1] = c.r[9];  // 0606D22C mov r9,r1
    c.r[1] += 1;  // 0606D22E add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D230 mov.b @r1,r3
    c.r[0] = c.r[2];  // 0606D232 mov r2,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0606D234 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606D236 mov.b @(r0,r7),r1
    c.r[3] <<= 2;  // 0606D238 shll2 r3
    c.r[3] <<= 2;  // 0606D23A shll2 r3
    c.r[3] <<= 2;  // 0606D23C shll2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606D2E6u);  // 0606D23E mov.w 0x0606D2E6,r2
    c.r[0] = c.r[6];  // 0606D240 mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0606D242 mov.l @(r0,r2),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606D244 extu.b r1,r1
    c.r[3] += c.r[2];  // 0606D246 add r2,r3
    c.r[0] = c.r[3];  // 0606D248 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606D24A mov.b @(r0,r1),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606D24C tst r8,r8
    { const bool k = !c.t; c.r[11] = c.r[1] & 0xFFu; if (k) { goto L_0606D2D0; } }  // 0606D24E bf/s 0x0606D2D0 ; extu.b r1,r11
    c.r[1] = c.r[9];  // 0606D252 mov r9,r1
    c.r[1] += 7;  // 0606D254 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D256 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606D258 mov r1,r0
    c.r[0] >>= 2;  // 0606D25A shlr2 r0
    c.r[0] >>= 2;  // 0606D25C shlr2 r0
    c.r[0] &= 0x1u;  // 0606D25E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D260 tst r0,r0
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_0606D2D0; } }  // 0606D262 bf/s 0x0606D2D0 ; mov #1,r4
    c.r[1] = ld32(0x0606D304u);  // 0606D266 mov.l 0x0606D304,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D268 mov.b @r1,r0
    c.r[1] = 0xFu;  // 0606D26A mov #15,r1
    c.r[1] &= c.r[0];  // 0606D26C and r0,r1
    c.r[0] = ld32(0x0606D308u);  // 0606D26E mov.l 0x0606D308,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606D274u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D274u) return; }  // 0606D270 jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D2E8u);  // 0606D274 mov.w 0x0606D2E8,r1
    c.r[0] &= c.r[1];  // 0606D276 and r1,r0
    c.r[1] = ld32(0x0606D30Cu);  // 0606D278 mov.l 0x0606D30C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D27Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D27Eu) return; }  // 0606D27A jsr @r1 ; mov r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D27E tst r4,r4
    { const bool k = !c.t; c.r[9] += 3; if (k) { goto L_0606D2D0; } }  // 0606D280 bf/s 0x0606D2D0 ; add #3,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606D284 mov.b @r9,r1
    c.r[0] = c.r[1];  // 0606D286 mov r1,r0
    c.r[0] >>= 2;  // 0606D288 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606D28A shlr r0
    c.r[0] &= 0x3u;  // 0606D28C and #3,r0
    c.t = c.r[0] == 0x2u;  // 0606D28E cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D2D2; } }  // 0606D290 bt/s 0x0606D2D2 ; mov #0,r0
    c.t = (c.r[12] & c.r[12]) == 0;  // 0606D294 tst r12,r12
    { const bool k = c.t; c.r[5] = 0x22u; if (k) { goto L_0606D2D2; } }  // 0606D296 bt/s 0x0606D2D2 ; mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D29Eu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D29Eu) return; }  // 0606D29A jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606D29E mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D2A4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D2A4u) return; }  // 0606D2A0 jsr @r10 ; mov r0,r4
    c.r[5] = c.r[12];  // 0606D2A4 mov r12,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D2AAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D2AAu) return; }  // 0606D2A6 jsr @r10 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606D2AA mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606D2AC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D2AE tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D2D2; } }  // 0606D2B0 bt/s 0x0606D2D2 ; mov #0,r0
    c.r[5] = 0x22u;  // 0606D2B4 mov #34,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D2BAu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D2BAu) return; }  // 0606D2B6 jsr @r10 ; mov r13,r4
    c.r[5] = 0x1u;  // 0606D2BA mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D2C0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D2C0u) return; }  // 0606D2BC jsr @r10 ; mov r0,r4
    c.r[5] = 0x3u;  // 0606D2C0 mov #3,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0606D2C6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D2C6u) return; }  // 0606D2C2 jsr @r10 ; mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0606D2C6 mov.b @(r0,r11),r0
    c.r[0] &= 0x40u;  // 0606D2C8 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D2CA tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606D2D2; } }  // 0606D2CC bt/s 0x0606D2D2 ; mov #1,r0
L_0606D2D0:
    c.r[0] = 0x0u;  // 0606D2D0 mov #0,r0
L_0606D2D2:
    c.r[15] = c.r[14];  // 0606D2D2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D2D4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606D2D6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606D2D8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606D2DA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606D2DC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606D2DE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606D2E0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D2E2 rts ; mov.l @r15+,r8
}

void f_0606D310(SH2Context& c) {
    ran[1558] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D310 mov.l r14,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D312 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606D33A; } }  // 0606D314 bf/s 0x0606D33A ; mov r15,r14
    c.r[1] = ld32(0x0606D344u);  // 0606D318 mov.l 0x0606D344,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D31A mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D31C extu.b r2,r2
    c.r[1] = ld32(0x0606D348u);  // 0606D31E mov.l 0x0606D348,r1
    c.r[1] = ld32(c.r[1]);  // 0606D320 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D322 shll2 r2
    c.r[2] <<= 2;  // 0606D324 shll2 r2
    c.r[2] += c.r[1];  // 0606D326 add r1,r2
    c.r[2] += 7;  // 0606D328 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D32A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D32C mov r1,r0
    c.r[0] >>= 2;  // 0606D32E shlr2 r0
    c.r[0] >>= 2;  // 0606D330 shlr2 r0
    c.r[0] &= 0x1u;  // 0606D332 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D334 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606D33C; } }  // 0606D336 bt/s 0x0606D33C ; mov #1,r0
L_0606D33A:
    c.r[0] = 0x0u;  // 0606D33A mov #0,r0
L_0606D33C:
    c.r[15] = c.r[14];  // 0606D33C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D33E rts ; mov.l @r15+,r14
}

void f_0606D34C(SH2Context& c) {
    ran[1559] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D34C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D34E sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D350 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606D378; } }  // 0606D352 bf/s 0x0606D378 ; mov r15,r14
    c.r[1] = ld32(0x0606D3B8u);  // 0606D356 mov.l 0x0606D3B8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D358 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D35A extu.b r2,r2
    c.r[1] = ld32(0x0606D3BCu);  // 0606D35C mov.l 0x0606D3BC,r1
    c.r[1] = ld32(c.r[1]);  // 0606D35E mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D360 shll2 r2
    c.r[2] <<= 2;  // 0606D362 shll2 r2
    c.r[2] += c.r[1];  // 0606D364 add r1,r2
    c.r[2] += 7;  // 0606D366 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D368 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D36A mov r1,r0
    c.r[0] >>= 2;  // 0606D36C shlr2 r0
    c.r[0] >>= 2;  // 0606D36E shlr2 r0
    c.r[0] &= 0x1u;  // 0606D370 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D372 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606D3AE; } }  // 0606D374 bf/s 0x0606D3AE ; mov #0,r0
L_0606D378:
    c.r[1] = ld32(0x0606D3B8u);  // 0606D378 mov.l 0x0606D3B8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D37A mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D37C extu.b r2,r2
    c.r[1] = ld32(0x0606D3BCu);  // 0606D37E mov.l 0x0606D3BC,r1
    c.r[1] = ld32(c.r[1]);  // 0606D380 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D382 shll2 r2
    c.r[2] <<= 2;  // 0606D384 shll2 r2
    c.r[2] += c.r[1];  // 0606D386 add r1,r2
    c.r[2] += 4;  // 0606D388 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D38A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D38C mov r1,r0
    c.r[0] >>= 2;  // 0606D38E shlr2 r0
    c.r[0] >>= 2;  // 0606D390 shlr2 r0
    c.r[0] >>= 2;  // 0606D392 shlr2 r0
    c.r[0] &= 0x1u;  // 0606D394 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D396 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606D3AE; } }  // 0606D398 bf/s 0x0606D3AE ; mov #0,r0
    c.r[0] = ld32(0x0606D3C0u);  // 0606D39C mov.l 0x0606D3C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606D3A2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D3A2u) return; }  // 0606D39E jsr @r0 ; mov #0,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0606D3A2 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D3B6u);  // 0606D3A4 mov.w 0x0606D3B6,r1
    c.t = c.r[2] == c.r[1];  // 0606D3A6 cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D3AE; } }  // 0606D3A8 bt/s 0x0606D3AE ; mov #0,r0
    c.r[0] = 0x1u;  // 0606D3AC mov #1,r0
L_0606D3AE:
    c.r[15] = c.r[14];  // 0606D3AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D3B0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D3B2 rts ; mov.l @r15+,r14
}

void f_0606D3C4(SH2Context& c) {
    ran[1560] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D3C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D3C6 sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D3C8 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606D3F0; } }  // 0606D3CA bf/s 0x0606D3F0 ; mov r15,r14
    c.r[1] = ld32(0x0606D430u);  // 0606D3CE mov.l 0x0606D430,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D3D0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D3D2 extu.b r2,r2
    c.r[1] = ld32(0x0606D434u);  // 0606D3D4 mov.l 0x0606D434,r1
    c.r[1] = ld32(c.r[1]);  // 0606D3D6 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D3D8 shll2 r2
    c.r[2] <<= 2;  // 0606D3DA shll2 r2
    c.r[2] += c.r[1];  // 0606D3DC add r1,r2
    c.r[2] += 7;  // 0606D3DE add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D3E0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D3E2 mov r1,r0
    c.r[0] >>= 2;  // 0606D3E4 shlr2 r0
    c.r[0] >>= 2;  // 0606D3E6 shlr2 r0
    c.r[0] &= 0x1u;  // 0606D3E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D3EA tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606D426; } }  // 0606D3EC bf/s 0x0606D426 ; mov #0,r0
L_0606D3F0:
    c.r[1] = ld32(0x0606D430u);  // 0606D3F0 mov.l 0x0606D430,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D3F2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D3F4 extu.b r2,r2
    c.r[1] = ld32(0x0606D434u);  // 0606D3F6 mov.l 0x0606D434,r1
    c.r[1] = ld32(c.r[1]);  // 0606D3F8 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D3FA shll2 r2
    c.r[2] <<= 2;  // 0606D3FC shll2 r2
    c.r[2] += c.r[1];  // 0606D3FE add r1,r2
    c.r[2] += 4;  // 0606D400 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D402 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D404 mov r1,r0
    c.r[0] >>= 2;  // 0606D406 shlr2 r0
    c.r[0] >>= 2;  // 0606D408 shlr2 r0
    c.r[0] >>= 2;  // 0606D40A shlr2 r0
    c.r[0] &= 0x1u;  // 0606D40C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D40E tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0606D426; } }  // 0606D410 bf/s 0x0606D426 ; mov #0,r0
    c.r[0] = ld32(0x0606D438u);  // 0606D414 mov.l 0x0606D438,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606D41Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D41Au) return; }  // 0606D416 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0606D41A extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D42Eu);  // 0606D41C mov.w 0x0606D42E,r1
    c.t = c.r[2] == c.r[1];  // 0606D41E cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D426; } }  // 0606D420 bt/s 0x0606D426 ; mov #0,r0
    c.r[0] = 0x1u;  // 0606D424 mov #1,r0
L_0606D426:
    c.r[15] = c.r[14];  // 0606D426 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D428 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D42A rts ; mov.l @r15+,r14
}

void f_0606D43C(SH2Context& c) {
    ran[1561] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D43C mov.l r14,@-r15
    c.r[1] = ld32(0x0606D4A4u);  // 0606D43E mov.l 0x0606D4A4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D440 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D442 extu.b r2,r2
    c.r[1] = ld32(0x0606D4A8u);  // 0606D444 mov.l 0x0606D4A8,r1
    c.r[1] = ld32(c.r[1]);  // 0606D446 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D448 shll2 r2
    c.r[2] <<= 2;  // 0606D44A shll2 r2
    c.r[2] += c.r[1];  // 0606D44C add r1,r2
    c.r[2] += 4;  // 0606D44E add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D450 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D452 mov r1,r0
    c.r[0] >>= 2;  // 0606D454 shlr2 r0
    c.r[0] >>= 2;  // 0606D456 shlr2 r0
    c.r[0] >>= 2;  // 0606D458 shlr2 r0
    c.r[0] &= 0x1u;  // 0606D45A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D45C tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606D49A; } }  // 0606D45E bf/s 0x0606D49A ; mov r15,r14
    c.r[3] = ld32(0x0606D4ACu);  // 0606D462 mov.l 0x0606D4AC,r3
    c.r[1] = ld32(c.r[3]);  // 0606D464 mov.l @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D466 tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0606D48E; } }  // 0606D468 bf/s 0x0606D48E ; mov #0,r2
    c.r[6] = 0x4u;  // 0606D46C mov #4,r6
    c.r[0] = c.r[3];  // 0606D46E mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0606D470 mov.l @(r0,r6),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D472 tst r1,r1
    { const bool k = !c.t; c.r[2] = 0x1u; if (k) { goto L_0606D48E; } }  // 0606D474 bf/s 0x0606D48E ; mov #1,r2
    c.r[7] = 0x3u;  // 0606D478 mov #3,r7
    c.r[2] += 1;  // 0606D47A add #1,r2
L_0606D47C:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0606D47C cmp/gt r7,r2
    { const bool k = c.t; c.r[6] += 4; if (k) { goto L_0606D48E; } }  // 0606D47E bt/s 0x0606D48E ; add #4,r6
    c.r[0] = c.r[6];  // 0606D482 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0606D484 mov.l @(r0,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D486 tst r1,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { SH2_POLL(c); goto L_0606D47C; } }  // 0606D488 bt/s 0x0606D47C ; add #1,r2
    c.r[2] -= 1;  // 0606D48C add #-1,r2
L_0606D48E:
    c.r[0] = c.r[2];  // 0606D48E mov r2,r0
    c.t = c.r[0] == 0x4u;  // 0606D490 cmp/eq #4,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D49C; } }  // 0606D492 bt/s 0x0606D49C ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606D49C;  // 0606D496 bra 0x0606D49C ; mov #1,r0
L_0606D49A:
    c.r[0] = 0x0u;  // 0606D49A mov #0,r0
L_0606D49C:
    c.r[15] = c.r[14];  // 0606D49C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D49E rts ; mov.l @r15+,r14
}

void f_0606D4B0(SH2Context& c) {
    ran[1562] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D4B0 mov.l r14,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D4B2 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606D4F0; } }  // 0606D4B4 bf/s 0x0606D4F0 ; mov r15,r14
    c.r[1] = ld32(0x0606D4FCu);  // 0606D4B8 mov.l 0x0606D4FC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D4BA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D4BC extu.b r2,r2
    c.r[1] = ld32(0x0606D500u);  // 0606D4BE mov.l 0x0606D500,r1
    c.r[1] = ld32(c.r[1]);  // 0606D4C0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D4C2 shll2 r2
    c.r[2] <<= 2;  // 0606D4C4 shll2 r2
    c.r[2] += c.r[1];  // 0606D4C6 add r1,r2
    c.r[2] += 7;  // 0606D4C8 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D4CA mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D4CC mov r1,r0
    c.r[0] >>= 2;  // 0606D4CE shlr2 r0
    c.r[0] &= 0x1u;  // 0606D4D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D4D2 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0606D4F2; } }  // 0606D4D4 bf/s 0x0606D4F2 ; mov #1,r0
    c.r[1] = ld32(0x0606D504u);  // 0606D4D8 mov.l 0x0606D504,r1
    c.r[2] = ld32(c.r[1]);  // 0606D4DA mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D4F8u);  // 0606D4DC mov.w 0x0606D4F8,r1
    c.r[0] = c.r[2];  // 0606D4DE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606D4E0 mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 0606D4E2 mov #16,r0
    c.r[1] &= c.r[0];  // 0606D4E4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D4E6 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0606D4F2; } }  // 0606D4E8 bt/s 0x0606D4F2 ; mov #0,r0
    c.r[0] = 0x1u; goto L_0606D4F2;  // 0606D4EC bra 0x0606D4F2 ; mov #1,r0
L_0606D4F0:
    c.r[0] = 0x0u;  // 0606D4F0 mov #0,r0
L_0606D4F2:
    c.r[15] = c.r[14];  // 0606D4F2 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D4F4 rts ; mov.l @r15+,r14
}

void f_0606D508(SH2Context& c) {
    ran[1563] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D508 mov.l r14,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606D50A tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606D548; } }  // 0606D50C bt/s 0x0606D548 ; mov r15,r14
    c.r[1] = ld32(0x0606D550u);  // 0606D510 mov.l 0x0606D550,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D512 mov.b @r1,r7
    c.r[5] = ld32(0x0606D554u);  // 0606D514 mov.l 0x0606D554,r5
    c.r[7] = c.r[7] & 0xFFu;  // 0606D516 extu.b r7,r7
    c.r[1] = ld32(0x0606D558u);  // 0606D518 mov.l 0x0606D558,r1
    c.r[3] = c.r[7];  // 0606D51A mov r7,r3
    c.r[6] = ld32(c.r[1]);  // 0606D51C mov.l @r1,r6
    c.r[3] <<= 2;  // 0606D51E shll2 r3
    c.r[3] <<= 2;  // 0606D520 shll2 r3
    c.r[1] = c.r[3];  // 0606D522 mov r3,r1
    c.r[1] += c.r[6];  // 0606D524 add r6,r1
    c.r[1] += 1;  // 0606D526 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D528 mov.b @r1,r2
    c.r[0] = c.r[3];  // 0606D52A mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0606D52C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606D52E mov.b @(r0,r6),r1
    c.r[2] <<= 2;  // 0606D530 shll2 r2
    c.r[2] <<= 2;  // 0606D532 shll2 r2
    c.r[2] <<= 2;  // 0606D534 shll2 r2
    c.r[3] = ld32(c.r[5]);  // 0606D536 mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0606D538 extu.b r1,r1
    c.r[2] += c.r[3];  // 0606D53A add r3,r2
    c.r[0] = c.r[2];  // 0606D53C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606D53E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606D540 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0606D542 cmp/eq r7,r1
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0606D54A; } }  // 0606D544 bt/s 0x0606D54A ; mov #1,r0
L_0606D548:
    c.r[0] = 0x0u;  // 0606D548 mov #0,r0
L_0606D54A:
    c.r[15] = c.r[14];  // 0606D54A mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D54C rts ; mov.l @r15+,r14
}

void f_0606D55C(SH2Context& c) {
    ran[1564] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D55C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D55E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606D560 mov r15,r14
    c.r[1] = ld32(0x0606D598u);  // 0606D562 mov.l 0x0606D598,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D568u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D568u) return; }  // 0606D564 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606D59Cu);  // 0606D568 mov.l 0x0606D59C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D56Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D56Eu) return; }  // 0606D56A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606D5A0u);  // 0606D56E mov.l 0x0606D5A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D574u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D574u) return; }  // 0606D570 jsr @r1 ; nop
    c.r[1] = 0x6u;  // 0606D574 mov #6,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606D576 mov.l r1,@-r15
    c.r[1] = ld32(0x0606D5A4u);  // 0606D578 mov.l 0x0606D5A4,r1
    c.r[7] = 0x3u;  // 0606D57A mov #3,r7
    c.r[6] = 0x5u;  // 0606D57C mov #5,r6
    c.r[5] = 0xAu;  // 0606D57E mov #10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606D584u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D584u) return; }  // 0606D580 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606D5A8u);  // 0606D584 mov.l 0x0606D5A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D58Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D58Au) return; }  // 0606D586 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0606D58A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D58C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606D594u);  // 0606D58E mov.w 0x0606D594,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D590 rts ; mov.l @r15+,r14
}

void f_0606D5AC(SH2Context& c) {
    ran[1565] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606D5AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606D5AE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606D5B0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D5B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D5B4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606D5B6 mov r15,r14
    c.r[1] = ld32(0x0606D6ECu);  // 0606D5B8 mov.l 0x0606D6EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D5BEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D5BEu) return; }  // 0606D5BA jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0606D6F0u);  // 0606D5BE mov.l 0x0606D6F0,r8
    c.r[2] = ld32(c.r[8]);  // 0606D5C0 mov.l @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D6E2u);  // 0606D5C2 mov.w 0x0606D6E2,r1
    c.r[0] = c.r[2];  // 0606D5C4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606D5C6 mov.b @(r0,r1),r1
    c.r[1] >>= 2;  // 0606D5C8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606D5CA shlr r1
    c.r[0] = 0x1u;  // 0606D5CC mov #1,r0
    c.r[1] &= c.r[0];  // 0606D5CE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D5D0 tst r1,r1
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_0606D60E; } }  // 0606D5D2 bt/s 0x0606D60E ; mov #4,r6
    c.r[1] = ld32(0x0606D6F4u);  // 0606D5D6 mov.l 0x0606D6F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606D5D8 mov.l @r1,r1
    c.r[1] += 18;  // 0606D5DA add #18,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D5DC mov.w @r1,r4
    c.r[0] = ld32(0x0606D6F8u);  // 0606D5DE mov.l 0x0606D6F8,r0
    c.r[4] <<= 16;  // 0606D5E0 shll16 r4
    c.r[4] <<= 2;  // 0606D5E2 shll2 r4
    c.r[4] += c.r[4];  // 0606D5E4 add r4,r4
    c.r[4] <<= 2;  // 0606D5E6 shll2 r4
    c.r[4] >>= 16;  // 0606D5E8 shlr16 r4
    c.r[4] <<= 2;  // 0606D5EA shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0606D5F0u; c.r[4] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D5F0u) return; }  // 0606D5EC jsr @r0 ; shlr8 r4
    c.r[3] = c.r[0];  // 0606D5F0 mov r0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606D6E4u);  // 0606D5F2 mov.w 0x0606D6E4,r2
    c.r[6] = 0x4u;  // 0606D5F4 mov #4,r6
    c.r[1] = ld32(c.r[8]);  // 0606D5F6 mov.l @r8,r1
    c.r[5] = 0x13u;  // 0606D5F8 mov #19,r5
    c.r[0] = c.r[1];  // 0606D5FA mov r1,r0
    c.r[7] = ld32(c.r[0] + c.r[2]);  // 0606D5FC mov.l @(r0,r2),r7
    c.r[4] = 0x0u;  // 0606D5FE mov #0,r4
    c.r[7] <<= 8;  // 0606D600 shll8 r7
    c.r[7] += c.r[7];  // 0606D602 add r7,r7
    c.r[7] >>= 16;  // 0606D604 shlr16 r7
    c.r[7] += c.r[7];  // 0606D606 add r7,r7
    c.r[7] >>= 8;  // 0606D608 shlr8 r7
    c.r[1] = c.r[3] & 0xFFu; goto L_0606D620;  // 0606D60A bra 0x0606D620 ; extu.b r3,r1
L_0606D60E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606D6E4u);  // 0606D60E mov.w 0x0606D6E4,r0
    c.r[7] = ld32(c.r[0] + c.r[2]);  // 0606D610 mov.l @(r0,r2),r7
    c.r[5] = 0x13u;  // 0606D612 mov #19,r5
    c.r[4] = 0x0u;  // 0606D614 mov #0,r4
    c.r[7] <<= 8;  // 0606D616 shll8 r7
    c.r[7] += c.r[7];  // 0606D618 add r7,r7
    c.r[7] >>= 16;  // 0606D61A shlr16 r7
    c.r[7] += c.r[7];  // 0606D61C add r7,r7
    c.r[7] >>= 8;  // 0606D61E shlr8 r7
L_0606D620:
    c.r[0] = ld32(0x0606D6FCu);  // 0606D620 mov.l 0x0606D6FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606D626u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D626u) return; }  // 0606D622 jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4;  // 0606D626 add #4,r15
    c.r[1] = ld32(0x0606D700u);  // 0606D628 mov.l 0x0606D700,r1
    c.r[6] = 0x7u;  // 0606D62A mov #7,r6
    c.r[5] = 0x3u;  // 0606D62C mov #3,r5
    c.r[1] = ld32(c.r[1]);  // 0606D62E mov.l @r1,r1
    c.r[4] = 0x0u;  // 0606D630 mov #0,r4
    c.r[1] += 42;  // 0606D632 add #42,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D634 mov.w @r1,r7
    c.r[0] = ld32(0x0606D704u);  // 0606D636 mov.l 0x0606D704,r0
    c.r[7] <<= 16;  // 0606D638 shll16 r7
    c.r[7] += c.r[7];  // 0606D63A add r7,r7
    c.r[1] = ld32(0x0606D708u);  // 0606D63C mov.l 0x0606D708,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D63E mov.b @r1,r1
    c.r[7] >>= 16;  // 0606D640 shlr16 r7
    c.r[7] += c.r[7];  // 0606D642 add r7,r7
    c.r[7] >>= 8;  // 0606D644 shlr8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 0606D646 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0606D64Cu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D64Cu) return; }  // 0606D648 jsr @r0 ; mov.l r1,@-r15
    c.r[1] = ld32(0x0606D70Cu);  // 0606D64C mov.l 0x0606D70C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D652u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D652u) return; }  // 0606D64E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606D710u);  // 0606D652 mov.l 0x0606D710,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D658u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D658u) return; }  // 0606D654 jsr @r1 ; nop
    c.r[1] = ld32(0x0606D714u);  // 0606D658 mov.l 0x0606D714,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D65Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D65Eu) return; }  // 0606D65A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606D6F4u);  // 0606D65E mov.l 0x0606D6F4,r1
    c.r[2] = ld32(c.r[1]);  // 0606D660 mov.l @r1,r2
    c.r[3] = 0x0u;  // 0606D662 mov #0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D6E6u);  // 0606D664 mov.w 0x0606D6E6,r1
    c.r[0] = c.r[2];  // 0606D666 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606D668 mov.b @(r0,r1),r1
    c.r[0] = 0x10u;  // 0606D66A mov #16,r0
    c.r[1] &= c.r[0];  // 0606D66C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D66E tst r1,r1
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0606D6B6; } }  // 0606D670 bf/s 0x0606D6B6 ; add #4,r15
    c.r[1] = ld32(0x0606D718u);  // 0606D674 mov.l 0x0606D718,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D676 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606D678 extu.b r1,r2
    c.r[1] = ld32(0x0606D71Cu);  // 0606D67A mov.l 0x0606D71C,r1
    c.r[1] = ld32(c.r[1]);  // 0606D67C mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D67E shll2 r2
    c.r[2] <<= 2;  // 0606D680 shll2 r2
    c.r[2] += c.r[1];  // 0606D682 add r1,r2
    c.r[1] = c.r[2];  // 0606D684 mov r2,r1
    c.r[1] += 7;  // 0606D686 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D688 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606D68A mov r1,r0
    c.r[0] >>= 2;  // 0606D68C shlr2 r0
    c.r[0] &= 0x1u;  // 0606D68E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D690 tst r0,r0
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0606D6BA; } }  // 0606D692 bt/s 0x0606D6BA ; tst r3,r3
    c.r[2] += 3;  // 0606D696 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D698 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D69A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606D69C shlr r0
    c.r[0] &= 0x3u;  // 0606D69E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D6A0 tst r0,r0
    if (c.t) { goto L_0606D6B6; }  // 0606D6A2 bt 0x0606D6B6
    c.r[1] = ld32(0x0606D6F0u);  // 0606D6A4 mov.l 0x0606D6F0,r1
    c.r[1] = ld32(c.r[1]);  // 0606D6A6 mov.l @r1,r1
    c.r[1] += 22;  // 0606D6A8 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D6AA mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606D6E8u);  // 0606D6AC mov.w 0x0606D6E8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606D6AE extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0606D6B0 cmp/hi r2,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0606D6BA; } }  // 0606D6B2 bt/s 0x0606D6BA ; tst r3,r3
L_0606D6B6:
    c.r[3] = 0x1u;  // 0606D6B6 mov #1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606D6B8 tst r3,r3
L_0606D6BA:
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_0606D724; } }  // 0606D6BA bt/s 0x0606D724 ; mov #-1,r6
    c.r[8] = ld32(0x0606D6F0u);  // 0606D6BE mov.l 0x0606D6F0,r8
    c.r[9] = ld32(0x0606D720u);  // 0606D6C0 mov.l 0x0606D720,r9
    c.r[1] = ld32(c.r[8]);  // 0606D6C2 mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606D6C4 mov #0,r5
    c.r[1] += 22;  // 0606D6C6 add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D6C8 mov.w @r1,r6
    c.r[4] = 0x1u;  // 0606D6CA mov #1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606D6D0u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D6D0u) return; }  // 0606D6CC jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 0606D6D0 mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606D6D2 mov #0,r5
    c.r[1] += 26;  // 0606D6D4 add #26,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D6D6 mov.w @r1,r6
    c.r[4] = 0x1u;  // 0606D6D8 mov #1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606D6DEu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D6DEu) return; }  // 0606D6DA jsr @r9 ; extu.w r6,r6
    goto L_0606D734;  // 0606D6DE bra 0x0606D734 ; nop
L_0606D724:
    c.r[8] = ld32(0x0606D8D4u);  // 0606D724 mov.l 0x0606D8D4,r8
    c.r[5] = 0x0u;  // 0606D726 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D72Cu; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D72Cu) return; }  // 0606D728 jsr @r8 ; mov #81,r4
    c.r[6] = 0xFFFFFFFFu;  // 0606D72C mov #-1,r6
    c.r[5] = 0x0u;  // 0606D72E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D734u; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D734u) return; }  // 0606D730 jsr @r8 ; mov #81,r4
L_0606D734:
    c.r[9] = ld32(0x0606D8D8u);  // 0606D734 mov.l 0x0606D8D8,r9
    c.r[2] = ld32(c.r[9]);  // 0606D736 mov.l @r9,r2
    c.r[6] = 0xBu;  // 0606D738 mov #11,r6
    c.r[1] = c.r[2];  // 0606D73A mov r2,r1
    c.r[1] += 26;  // 0606D73C add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D73E mov.w @r1,r5
    c.r[2] += 22;  // 0606D740 add #22,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606D742 mov.w @r2,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0606D744 extu.w r5,r5
    c.r[1] = ld32(0x0606D8DCu);  // 0606D746 mov.l 0x0606D8DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D74Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D74Cu) return; }  // 0606D748 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[9]);  // 0606D74C mov.l @r9,r1
    c.r[1] += 24;  // 0606D74E add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D750 mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0606D752 extu.w r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D8C4u);  // 0606D754 mov.w 0x0606D8C4,r1
    c.t = c.r[6] == c.r[1];  // 0606D756 cmp/eq r1,r6
    if (!c.t) { goto L_0606D76C; }  // 0606D758 bf 0x0606D76C
    c.r[6] = 0xFFFFFFFEu;  // 0606D75A mov #-2,r6
    c.r[8] = ld32(0x0606D8D4u);  // 0606D75C mov.l 0x0606D8D4,r8
    c.r[5] = 0x0u;  // 0606D75E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D764u; c.r[4] = 0x31u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D764u) return; }  // 0606D760 jsr @r8 ; mov #49,r4
    c.r[6] = 0xFFFFFFFEu;  // 0606D764 mov #-2,r6
    c.r[5] = 0x0u;  // 0606D766 mov #0,r5
    c.r[4] = 0x31u; goto L_0606D780;  // 0606D768 bra 0x0606D780 ; mov #49,r4
L_0606D76C:
    c.r[8] = ld32(0x0606D8D4u);  // 0606D76C mov.l 0x0606D8D4,r8
    c.r[5] = 0x0u;  // 0606D76E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D774u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D774u) return; }  // 0606D770 jsr @r8 ; mov #1,r4
    c.r[1] = ld32(c.r[9]);  // 0606D774 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D776 mov #0,r5
    c.r[1] += 28;  // 0606D778 add #28,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D77A mov.w @r1,r6
    c.r[4] = 0x1u;  // 0606D77C mov #1,r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 0606D77E extu.w r6,r6
L_0606D780:
    { const uint32_t x = c.r[8]; c.pr = 0x0606D784u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D784u) return; }  // 0606D780 jsr @r8 ; nop
    c.r[8] = ld32(0x0606D8D8u);  // 0606D784 mov.l 0x0606D8D8,r8
    c.r[2] = ld32(c.r[8]);  // 0606D786 mov.l @r8,r2
    c.r[6] = 0x4u;  // 0606D788 mov #4,r6
    c.r[1] = c.r[2];  // 0606D78A mov r2,r1
    c.r[1] += 28;  // 0606D78C add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D78E mov.w @r1,r5
    c.r[2] += 24;  // 0606D790 add #24,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606D792 mov.w @r2,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0606D794 extu.w r5,r5
    c.r[1] = ld32(0x0606D8DCu);  // 0606D796 mov.l 0x0606D8DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D79Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D79Cu) return; }  // 0606D798 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[8]);  // 0606D79C mov.l @r8,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D79E mov.w @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606D8C6u);  // 0606D7A0 mov.w 0x0606D8C6,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D8C8u);  // 0606D7A2 mov.w 0x0606D8C8,r1
    c.r[4] += c.r[1];  // 0606D7A4 add r1,r4
    c.r[1] = ld32(0x0606D8E0u);  // 0606D7A6 mov.l 0x0606D8E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D7ACu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D7ACu) return; }  // 0606D7A8 jsr @r1 ; extu.w r4,r4
    c.r[9] = ld32(0x0606D8E4u);  // 0606D7AC mov.l 0x0606D8E4,r9
    c.r[8] = ld32(0x0606D8D4u);  // 0606D7AE mov.l 0x0606D8D4,r8
    c.r[1] = ld32(c.r[9]);  // 0606D7B0 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D7B2 mov #0,r5
    c.r[1] += 2;  // 0606D7B4 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D7B6 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606D7B8 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606D7BEu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D7BEu) return; }  // 0606D7BA jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(c.r[9]);  // 0606D7BE mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D7C0 mov #0,r5
    c.r[1] += 9;  // 0606D7C2 add #9,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D7C4 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606D7C6 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606D7CCu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D7CCu) return; }  // 0606D7C8 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(0x0606D8E8u);  // 0606D7CC mov.l 0x0606D8E8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D7CE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606D7D0 extu.b r2,r2
    c.r[1] = ld32(0x0606D8ECu);  // 0606D7D2 mov.l 0x0606D8EC,r1
    c.r[1] = ld32(c.r[1]);  // 0606D7D4 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D7D6 shll2 r2
    c.r[2] <<= 2;  // 0606D7D8 shll2 r2
    c.r[2] += c.r[1];  // 0606D7DA add r1,r2
    c.r[2] += 3;  // 0606D7DC add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D7DE mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606D7E0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606D7E2 shlr r0
    c.r[0] &= 0x3u;  // 0606D7E4 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606D7E6 tst r0,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606D7F0; } }  // 0606D7E8 bt/s 0x0606D7F0 ; mov #0,r5
    c.r[6] = 0x0u; goto L_0606D7F6;  // 0606D7EC bra 0x0606D7F6 ; mov #0,r6
L_0606D7F0:
    c.r[1] = ld32(c.r[9]);  // 0606D7F0 mov.l @r9,r1
    c.r[1] += 4;  // 0606D7F2 add #4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D7F4 mov.w @r1,r6
L_0606D7F6:
    { const uint32_t x = c.r[8]; c.pr = 0x0606D7FAu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D7FAu) return; }  // 0606D7F6 jsr @r8 ; mov #64,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0606D8C6u);  // 0606D7FA mov.w 0x0606D8C6,r8
    c.r[1] = ld32(0x0606D8E4u);  // 0606D7FC mov.l 0x0606D8E4,r1
    c.r[1] = ld32(c.r[1]);  // 0606D7FE mov.l @r1,r1
    c.r[10] = ld32(0x0606D8E0u);  // 0606D800 mov.l 0x0606D8E0,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D802 mov.w @r1,r4
    c.r[5] = c.r[8];  // 0606D804 mov r8,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D8CAu);  // 0606D806 mov.w 0x0606D8CA,r1
    c.r[4] += c.r[1];  // 0606D808 add r1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606D80Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D80Eu) return; }  // 0606D80A jsr @r10 ; extu.w r4,r4
    c.r[9] = ld32(0x0606D8D8u);  // 0606D80E mov.l 0x0606D8D8,r9
    c.r[1] = ld32(c.r[9]);  // 0606D810 mov.l @r9,r1
    c.r[1] += 37;  // 0606D812 add #37,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D814 mov.b @r1,r4
    c.r[5] = c.r[8];  // 0606D816 mov r8,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0606D818 extu.b r4,r4
    c.r[4] >>= 2;  // 0606D81A shlr2 r4
    c.r[4] >>= 2;  // 0606D81C shlr2 r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D8CCu);  // 0606D81E mov.w 0x0606D8CC,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0606D824u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D824u) return; }  // 0606D820 jsr @r10 ; or r1,r4
    c.r[8] = ld32(0x0606D8D4u);  // 0606D824 mov.l 0x0606D8D4,r8
    c.r[1] = ld32(c.r[9]);  // 0606D826 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D828 mov #0,r5
    c.r[1] += 36;  // 0606D82A add #36,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D82C mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606D82E mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606D834u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D834u) return; }  // 0606D830 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(c.r[9]);  // 0606D834 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D836 mov #0,r5
    c.r[1] += 34;  // 0606D838 add #34,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D83A mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606D83C mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606D842u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D842u) return; }  // 0606D83E jsr @r8 ; extu.w r6,r6
    c.r[1] = ld32(c.r[9]);  // 0606D842 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D844 mov #0,r5
    c.r[1] += 30;  // 0606D846 add #30,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D848 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606D84A mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606D850u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D850u) return; }  // 0606D84C jsr @r8 ; extu.w r6,r6
    c.r[1] = ld32(c.r[9]);  // 0606D850 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606D852 mov #0,r5
    c.r[1] += 32;  // 0606D854 add #32,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606D856 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606D858 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606D85Eu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D85Eu) return; }  // 0606D85A jsr @r8 ; extu.w r6,r6
    c.r[8] = ld32(0x0606D8F0u);  // 0606D85E mov.l 0x0606D8F0,r8
    c.r[5] = 0x2u;  // 0606D860 mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D866u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D866u) return; }  // 0606D862 jsr @r8 ; mov #3,r4
    c.r[5] = 0x0u;  // 0606D866 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D86Cu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D86Cu) return; }  // 0606D868 jsr @r8 ; mov #3,r4
    c.r[5] = 0x1u;  // 0606D86C mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D872u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D872u) return; }  // 0606D86E jsr @r8 ; mov #3,r4
    c.r[5] = 0x3u;  // 0606D872 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D878u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D878u) return; }  // 0606D874 jsr @r8 ; mov #3,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606D8CEu);  // 0606D878 mov.w 0x0606D8CE,r2
    c.r[4] = ld32(0x0606D8F4u);  // 0606D87A mov.l 0x0606D8F4,r4
    c.r[1] = ld32(c.r[9]);  // 0606D87C mov.l @r9,r1
    c.r[8] = ld32(0x0606D8F8u);  // 0606D87E mov.l 0x0606D8F8,r8
    c.r[0] = c.r[1];  // 0606D880 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606D882 mov.b @(r0,r2),r1
    c.r[5] = 0x17u;  // 0606D884 mov #23,r5
    c.r[9] = c.r[1];  // 0606D886 mov r1,r9
    c.r[9] >>= 2;  // 0606D888 shlr2 r9
    c.r[9] >>= 2;  // 0606D88A shlr2 r9
    c.r[0] = 0x1u;  // 0606D88C mov #1,r0
    { const uint32_t x = c.r[8]; c.pr = 0x0606D892u; c.r[9] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D892u) return; }  // 0606D88E jsr @r8 ; and r0,r9
    c.r[1] = c.r[0];  // 0606D892 mov r0,r1
    c.r[5] = 0x0u;  // 0606D894 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D89Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D89Au) return; }  // 0606D896 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0606D89A mov r0,r2
    c.r[1] = ld32(0x0606D8FCu);  // 0606D89C mov.l 0x0606D8FC,r1
    c.r[6] = 0x2u;  // 0606D89E mov #2,r6
    c.r[5] = c.r[9];  // 0606D8A0 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606D8A6u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D8A6u) return; }  // 0606D8A2 jsr @r1 ; mov r2,r4
    c.r[8] = 0x0u;  // 0606D8A6 mov #0,r8
L_0606D8A8:
    c.r[1] = ld32(0x0606D8D8u);  // 0606D8A8 mov.l 0x0606D8D8,r1
    c.r[1] = ld32(c.r[1]);  // 0606D8AA mov.l @r1,r1
    c.r[1] += c.r[8];  // 0606D8AC add r8,r1
    c.r[1] += 39;  // 0606D8AE add #39,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D8B0 mov.b @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D8D0u);  // 0606D8B2 mov.w 0x0606D8D0,r1
    c.r[1] &= c.r[2];  // 0606D8B4 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606D8B6 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0606D904; } }  // 0606D8B8 bt/s 0x0606D904 ; mov r2,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606D8C6u);  // 0606D8BC mov.w 0x0606D8C6,r5
    c.r[4] = ld32(0x0606D900u);  // 0606D8BE mov.l 0x0606D900,r4
    goto L_0606D90E;  // 0606D8C0 bra 0x0606D90E ; nop
L_0606D904:
    c.r[0] &= 0x7Fu;  // 0606D904 and #127,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606D92Eu);  // 0606D906 mov.w 0x0606D92E,r1
    c.r[0] |= c.r[1];  // 0606D908 or r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606D930u);  // 0606D90A mov.w 0x0606D930,r5
    c.r[4] = c.r[0];  // 0606D90C mov r0,r4
L_0606D90E:
    { const uint32_t x = c.r[10]; c.pr = 0x0606D912u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D912u) return; }  // 0606D90E jsr @r10 ; add #1,r8
    c.r[1] = 0x3u;  // 0606D912 mov #3,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606D914 cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0606D8A8; }  // 0606D916 bf 0x0606D8A8
    c.r[1] = ld32(0x0606D934u);  // 0606D918 mov.l 0x0606D934,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D91Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D91Eu) return; }  // 0606D91A jsr @r1 ; mov #1,r4
    c.r[15] = c.r[14];  // 0606D91E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606D920 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606D922 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606D924 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606D926 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606D932u);  // 0606D928 mov.w 0x0606D932,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606D92A rts ; mov.l @r15+,r8
}

void f_0606D938(SH2Context& c) {
    ran[1566] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606D938 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606D93A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606D93C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606D93E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606D940 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606D942 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606D944 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606D946 sts.l pr,@-r15
    c.r[15] -= 4;  // 0606D948 add #-4,r15
    c.r[14] = c.r[15];  // 0606D94A mov r15,r14
    c.r[4] = ld32(0x0606DAF4u);  // 0606D94C mov.l 0x0606DAF4,r4
    c.r[8] = ld32(0x0606DAF8u);  // 0606D94E mov.l 0x0606DAF8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606D954u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D954u) return; }  // 0606D950 jsr @r8 ; mov #23,r5
    c.r[5] = 0x2u;  // 0606D954 mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606D95Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D95Au) return; }  // 0606D956 jsr @r8 ; mov r0,r4
    c.r[13] = c.r[0];  // 0606D95A mov r0,r13
    c.r[1] = ld32(0x0606DAFCu);  // 0606D95C mov.l 0x0606DAFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D962u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D962u) return; }  // 0606D95E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606DB00u);  // 0606D962 mov.l 0x0606DB00,r1
    c.r[2] = ld32(c.r[1]);  // 0606D964 mov.l @r1,r2
    c.r[2] += 1;  // 0606D966 add #1,r2
    st32(c.r[1], c.r[2]);  // 0606D968 mov.l r2,@r1
    c.r[1] = ld32(0x0606DB04u);  // 0606D96A mov.l 0x0606DB04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D970u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D970u) return; }  // 0606D96C jsr @r1 ; mov #0,r4
    c.r[8] = 0x0u;  // 0606D970 mov #0,r8
    c.r[9] = 0x0u;  // 0606D972 mov #0,r9
    c.r[11] = ld32(0x0606DB08u);  // 0606D974 mov.l 0x0606DB08,r11
    c.r[10] = ld32(0x0606DB0Cu);  // 0606D976 mov.l 0x0606DB0C,r10
    c.r[1] = c.r[8];  // 0606D978 mov r8,r1
L_0606D97A:
    c.r[0] = c.r[9];  // 0606D97A mov r9,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 0606D97C mov.b r1,@(r0,r10)
    st8(c.r[0] + c.r[11], c.r[1]);  // 0606D97E mov.b r1,@(r0,r11)
    c.r[1] = ld32(0x0606DB00u);  // 0606D980 mov.l 0x0606DB00,r1
    c.r[2] = c.r[8];  // 0606D982 mov r8,r2
    c.r[1] = ld32(c.r[1]);  // 0606D984 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606D986 shll2 r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D988 mov.b @r1,r4
    c.r[0] = c.r[2];  // 0606D98A mov r2,r0
    c.r[1] = ld32(0x0606DB10u);  // 0606D98C mov.l 0x0606DB10,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0606D98E mov.l @(r0,r1),r2
    c.r[4] = c.r[4] & 0xFFu;  // 0606D990 extu.b r4,r4
    { const uint32_t x = c.r[2]; c.pr = 0x0606D996u; st32(c.r[14], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D996u) return; }  // 0606D992 jsr @r2 ; mov.l r2,@r14
    c.r[1] = c.r[0];  // 0606D996 mov r0,r1
    c.r[9] += c.r[1];  // 0606D998 add r1,r9
    c.r[8] += 1;  // 0606D99A add #1,r8
    c.r[1] = 0x12u;  // 0606D99C mov #18,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606D99E cmp/gt r1,r8
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_0606D97A; } }  // 0606D9A0 bf/s 0x0606D97A ; mov r8,r1
    c.r[3] = ld32(0x0606DB08u);  // 0606D9A4 mov.l 0x0606DB08,r3
    c.r[2] = ld32(0x0606DB0Cu);  // 0606D9A6 mov.l 0x0606DB0C,r2
    c.r[1] = 0xFFFFFFFFu;  // 0606D9A8 mov #-1,r1
    c.r[0] = c.r[9];  // 0606D9AA mov r9,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606D9AC mov.b r1,@(r0,r2)
    st8(c.r[0] + c.r[3], c.r[1]);  // 0606D9AE mov.b r1,@(r0,r3)
    c.r[1] = ld32(0x0606DB14u);  // 0606D9B0 mov.l 0x0606DB14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606D9B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D9B6u) return; }  // 0606D9B2 jsr @r1 ; nop
    c.r[2] = ld32(0x0606DB18u);  // 0606D9B6 mov.l 0x0606DB18,r2
    c.r[1] = c.r[2];  // 0606D9B8 mov r2,r1
    c.r[1] += 116;  // 0606D9BA add #116,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606D9BC mov.b @r1,r1
    c.r[2] += 117;  // 0606D9BE add #117,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606D9C0 extu.b r1,r1
    c.r[1] += c.r[1];  // 0606D9C2 add r1,r1
    c.r[1] -= 1;  // 0606D9C4 add #-1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0606D9C6 extu.b r1,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606D9C8 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606D9CA extu.b r1,r1
    c.r[1] += c.r[1];  // 0606D9CC add r1,r1
    c.r[1] -= 3;  // 0606D9CE add #-3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606D9D0 cmp/pz r1
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFu; if (k) { goto L_0606D9D8; } }  // 0606D9D2 bt/s 0x0606D9D8 ; extu.b r1,r11
    c.r[11] = 0x0u;  // 0606D9D6 mov #0,r11
L_0606D9D8:
    c.r[3] = c.r[9];  // 0606D9D8 mov r9,r3
    c.r[3] += c.r[3];  // 0606D9DA add r3,r3
    c.r[2] = c.r[11];  // 0606D9DC mov r11,r2
    c.r[2] += c.r[3];  // 0606D9DE add r3,r2
    c.r[1] = 0x1Au;  // 0606D9E0 mov #26,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606D9E2 cmp/gt r1,r2
    { const bool k = !c.t; c.r[2] -= 26; if (k) { goto L_0606D9EE; } }  // 0606D9E4 bf/s 0x0606D9EE ; add #-26,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[11];  // 0606D9E8 exts.b r11,r1
    c.r[1] -= c.r[2];  // 0606D9EA sub r2,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606D9EC extu.b r1,r11
L_0606D9EE:
    c.r[1] = c.r[3] & 0xFFu;  // 0606D9EE extu.b r3,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606D9F0 mov.l r1,@-r15
    c.r[1] = ld32(0x0606DB1Cu);  // 0606D9F2 mov.l 0x0606DB1C,r1
    c.r[7] = 0x3u;  // 0606D9F4 mov #3,r7
    c.r[6] = c.r[11];  // 0606D9F6 mov r11,r6
    c.r[5] = c.r[12];  // 0606D9F8 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606D9FEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606D9FEu) return; }  // 0606D9FA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0606DB20u);  // 0606D9FE mov.l 0x0606DB20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DA04u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DA04u) return; }  // 0606DA00 jsr @r1 ; mov #0,r4
    c.r[5] = c.r[11];  // 0606DA04 mov r11,r5
    c.r[5] += 1;  // 0606DA06 add #1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0606DA08 extu.b r5,r5
    c.r[4] = c.r[12];  // 0606DA0A mov r12,r4
    c.r[4] += 1;  // 0606DA0C add #1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 0606DA0E extu.b r4,r4
    c.r[1] = c.r[9] & 0xFFFFu;  // 0606DA10 extu.w r9,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606DA12 mov.l r1,@-r15
    c.r[2] = 0x1u;  // 0606DA14 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606DA16 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606DA18 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0606DA1A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606DA1C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606DA1E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606DA20 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606DA22 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606DA24 mov.l r1,@-r15
    c.r[1] = c.r[9] & 0xFFu;  // 0606DA26 extu.b r9,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606DA28 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0606DA2A mov.l r2,@-r15
    c.r[1] = ld32(0x0606DB24u);  // 0606DA2C mov.l 0x0606DB24,r1
    c.r[7] = 0x2u;  // 0606DA2E mov #2,r7
    { const uint32_t x = c.r[1]; c.pr = 0x0606DA34u; c.r[6] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DA34u) return; }  // 0606DA30 jsr @r1 ; mov #3,r6
    c.r[8] = ld32(0x0606DB00u);  // 0606DA34 mov.l 0x0606DB00,r8
    c.r[2] = ld32(c.r[8]);  // 0606DA36 mov.l @r8,r2
    c.r[3] = ld32(0x0606DB28u);  // 0606DA38 mov.l 0x0606DB28,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606DA3A mov.b @r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606DA3C mov.b @r2,r2
    c.r[1] += c.r[2];  // 0606DA3E add r2,r1
    st8(c.r[3], c.r[1]);  // 0606DA40 mov.b r1,@r3
    c.r[1] = ld32(0x0606DB14u);  // 0606DA42 mov.l 0x0606DB14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DA48u; c.r[15] += 44; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DA48u) return; }  // 0606DA44 jsr @r1 ; add #44,r15
    c.r[1] = ld32(c.r[8]);  // 0606DA48 mov.l @r8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DA4A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606DA4C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606DA4E tst r1,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0606DA8E; } }  // 0606DA50 bt/s 0x0606DA8E ; mov #0,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606DAEAu);  // 0606DA54 mov.w 0x0606DAEA,r3
    c.r[7] = ld32(0x0606DB08u);  // 0606DA56 mov.l 0x0606DB08,r7
    c.r[2] = 0x12u;  // 0606DA58 mov #18,r2
    c.r[0] = c.r[8];  // 0606DA5A mov r8,r0
L_0606DA5C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606DA5C mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606DA5E extu.b r1,r1
    c.r[0] = c.r[1];  // 0606DA60 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0606DA62 cmp/eq #1,r0
    { const bool k = c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_0606DA74; } }  // 0606DA64 bt/s 0x0606DA74 ; tst r1,r1
    if (!c.t) { goto L_0606DA6C; }  // 0606DA68 bf 0x0606DA6C
    c.r[3] = c.r[8];  // 0606DA6A mov r8,r3
L_0606DA6C:
    c.r[8] += 1;  // 0606DA6C add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[2];  // 0606DA6E cmp/gt r2,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_0606DA5C; } }  // 0606DA70 bf/s 0x0606DA5C ; mov r8,r0
L_0606DA74:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606DAEAu);  // 0606DA74 mov.w 0x0606DAEA,r1
    c.t = c.r[3] == c.r[1];  // 0606DA76 cmp/eq r1,r3
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0606DA8E; } }  // 0606DA78 bt/s 0x0606DA8E ; mov r8,r0
    c.t = c.r[0] == 0x13u;  // 0606DA7C cmp/eq #19,r0
    { const bool k = c.t; c.r[2] = 0x1u; if (k) { goto L_0606DA8E; } }  // 0606DA7E bt/s 0x0606DA8E ; mov #1,r2
    c.r[1] = ld32(0x0606DB08u);  // 0606DA82 mov.l 0x0606DB08,r1
    c.r[0] = c.r[3];  // 0606DA84 mov r3,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0606DA86 mov.b r2,@(r0,r1)
    c.r[2] = 0x0u;  // 0606DA88 mov #0,r2
    c.r[0] = c.r[8];  // 0606DA8A mov r8,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0606DA8C mov.b r2,@(r0,r1)
L_0606DA8E:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606DAECu);  // 0606DA8E mov.w 0x0606DAEC,r4
    c.r[10] = ld32(0x0606DB2Cu);  // 0606DA90 mov.l 0x0606DB2C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0606DA96u; c.r[12] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DA96u) return; }  // 0606DA92 jsr @r10 ; add #1,r12
    { const uint32_t x = c.r[10]; c.pr = 0x0606DA9Au; c.r[4] = c.r[12] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DA9Au) return; }  // 0606DA96 jsr @r10 ; extu.b r12,r4
    c.r[11] += 1;  // 0606DA9A add #1,r11
    { const uint32_t x = c.r[10]; c.pr = 0x0606DAA0u; c.r[4] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DAA0u) return; }  // 0606DA9C jsr @r10 ; extu.b r11,r4
    c.r[4] = c.r[9];  // 0606DAA0 mov r9,r4
    c.r[4] <<= 2;  // 0606DAA2 shll2 r4
    c.r[4] += c.r[9];  // 0606DAA4 add r9,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606DAAAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DAAAu) return; }  // 0606DAA6 jsr @r10 ; extu.b r4,r4
    c.r[8] = 0x0u;  // 0606DAAA mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 0606DAAC cmp/ge r9,r8
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0606DACC; } }  // 0606DAAE bt/s 0x0606DACC ; mov r8,r0
    c.r[12] = ld32(0x0606DB08u);  // 0606DAB2 mov.l 0x0606DB08,r12
    c.r[11] = ld32(0x0606DB30u);  // 0606DAB4 mov.l 0x0606DB30,r11
L_0606DAB6:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606DAB6 mov.b @(r0,r12),r5
    c.r[6] = 0x4u;  // 0606DAB8 mov #4,r6
    c.r[4] = c.r[13];  // 0606DABA mov r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0606DAC0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DAC0u) return; }  // 0606DABC jsr @r11 ; extu.b r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606DAEEu);  // 0606DAC0 mov.w 0x0606DAEE,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0606DAC6u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DAC6u) return; }  // 0606DAC2 jsr @r10 ; add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 0606DAC6 cmp/ge r9,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_0606DAB6; } }  // 0606DAC8 bf/s 0x0606DAB6 ; mov r8,r0
L_0606DACC:
    c.r[1] = ld32(0x0606DB20u);  // 0606DACC mov.l 0x0606DB20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DAD2u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DAD2u) return; }  // 0606DACE jsr @r1 ; mov #6,r4
    c.r[14] += 4;  // 0606DAD2 add #4,r14
    c.r[15] = c.r[14];  // 0606DAD4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606DAD6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606DAD8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606DADA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606DADC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606DADE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606DAE0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606DAE2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606DAF0u);  // 0606DAE4 mov.w 0x0606DAF0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606DAE6 rts ; mov.l @r15+,r8
}

void f_0606DB34(SH2Context& c) {
    ran[1567] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606DB34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606DB36 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606DB38 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606DB3A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606DB3C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0606DB3E mov r15,r14
    c.r[1] = ld32(0x0606DC20u);  // 0606DB40 mov.l 0x0606DC20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DB46u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB46u) return; }  // 0606DB42 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606DC24u);  // 0606DB46 mov.l 0x0606DC24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DB4Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB4Cu) return; }  // 0606DB48 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606DC28u);  // 0606DB4C mov.l 0x0606DC28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DB52u; c.r[9] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB52u) return; }  // 0606DB4E jsr @r1 ; mov #7,r9
    c.r[10] = ld32(0x0606DC2Cu);  // 0606DB52 mov.l 0x0606DC2C,r10
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606DC12u);  // 0606DB54 mov.w 0x0606DC12,r2
    c.r[4] = ld32(0x0606DC30u);  // 0606DB56 mov.l 0x0606DC30,r4
    c.r[1] = ld32(c.r[10]);  // 0606DB58 mov.l @r10,r1
    c.r[8] = ld32(0x0606DC34u);  // 0606DB5A mov.l 0x0606DC34,r8
    c.r[0] = c.r[1];  // 0606DB5C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606DB5E mov.b @(r0,r2),r1
    c.r[5] = 0x17u;  // 0606DB60 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DB66u; c.r[9] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB66u) return; }  // 0606DB62 jsr @r8 ; and r1,r9
    c.r[1] = c.r[0];  // 0606DB66 mov r0,r1
    c.r[5] = 0x3u;  // 0606DB68 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DB6Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB6Eu) return; }  // 0606DB6A jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0606DB6E mov r0,r2
    c.r[1] = ld32(0x0606DC38u);  // 0606DB70 mov.l 0x0606DC38,r1
    c.r[6] = 0x2u;  // 0606DB72 mov #2,r6
    c.r[5] = c.r[9];  // 0606DB74 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606DB7Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB7Au) return; }  // 0606DB76 jsr @r1 ; mov r2,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606DC14u);  // 0606DB7A mov.w 0x0606DC14,r2
    c.r[1] = ld32(c.r[10]);  // 0606DB7C mov.l @r10,r1
    c.r[5] = 0x0u;  // 0606DB7E mov #0,r5
    c.r[0] = c.r[1];  // 0606DB80 mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0606DB82 mov.w @(r0,r2),r6
    c.r[4] = 0x0u;  // 0606DB84 mov #0,r4
    c.r[1] = ld32(0x0606DC3Cu);  // 0606DB86 mov.l 0x0606DC3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DB8Cu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB8Cu) return; }  // 0606DB88 jsr @r1 ; extu.w r6,r6
    c.r[8] = ld32(0x0606DC40u);  // 0606DB8C mov.l 0x0606DC40,r8
    c.r[5] = 0x2u;  // 0606DB8E mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DB94u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB94u) return; }  // 0606DB90 jsr @r8 ; mov #0,r4
    c.r[5] = 0x0u;  // 0606DB94 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DB9Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DB9Au) return; }  // 0606DB96 jsr @r8 ; mov #0,r4
    c.r[5] = 0x1u;  // 0606DB9A mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DBA0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DBA0u) return; }  // 0606DB9C jsr @r8 ; mov #0,r4
    c.r[5] = 0x3u;  // 0606DBA0 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DBA6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DBA6u) return; }  // 0606DBA2 jsr @r8 ; mov #0,r4
    c.r[1] = ld32(c.r[10]);  // 0606DBA6 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606DC16u);  // 0606DBA8 mov.w 0x0606DC16,r9
    c.r[0] = c.r[1];  // 0606DBAA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0606DBAC mov.b @(r0,r9),r1
    c.r[2] = c.r[1];  // 0606DBAE mov r1,r2
    c.r[2] >>= 2;  // 0606DBB0 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606DBB2 shlr r2
    c.r[0] = 0x7u;  // 0606DBB4 mov #7,r0
    c.r[2] &= c.r[0];  // 0606DBB6 and r0,r2
    c.r[1] = ld32(0x0606DC44u);  // 0606DBB8 mov.l 0x0606DC44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DBBEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DBBEu) return; }  // 0606DBBA jsr @r1 ; mov r2,r4
    c.r[1] = ld32(c.r[10]);  // 0606DBBE mov.l @r10,r1
    c.r[0] = c.r[1];  // 0606DBC0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0606DBC2 mov.b @(r0,r9),r1
    c.r[8] = 0x0u;  // 0606DBC4 mov #0,r8
    c.r[1] >>= 2;  // 0606DBC6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606DBC8 shlr r1
    c.r[0] = 0x7u;  // 0606DBCA mov #7,r0
    c.r[1] &= c.r[0];  // 0606DBCC and r0,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0606DBCE cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[10]; if (k) { goto L_0606DBFC; } }  // 0606DBD0 bt/s 0x0606DBFC ; mov r10,r9
    c.r[10] = ld32(0x0606DC48u);  // 0606DBD4 mov.l 0x0606DC48,r10
L_0606DBD6:
    c.r[1] = ld32(c.r[9]);  // 0606DBD6 mov.l @r9,r1
    c.r[1] += c.r[8];  // 0606DBD8 add r8,r1
    c.r[1] += 16;  // 0606DBDA add #16,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DBDC mov.b @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606DC18u);  // 0606DBDE mov.w 0x0606DC18,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0606DBE0 extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606DC1Au);  // 0606DBE2 mov.w 0x0606DC1A,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0606DBE8u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DBE8u) return; }  // 0606DBE4 jsr @r10 ; or r1,r4
    c.r[1] = ld32(c.r[9]);  // 0606DBE8 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606DC16u);  // 0606DBEA mov.w 0x0606DC16,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606DBEC mov.b @(r0,r1),r1
    c.r[8] += 1;  // 0606DBEE add #1,r8
    c.r[0] = c.r[1];  // 0606DBF0 mov r1,r0
    c.r[0] >>= 2;  // 0606DBF2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606DBF4 shlr r0
    c.r[0] &= 0x7u;  // 0606DBF6 and #7,r0
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 0606DBF8 cmp/ge r0,r8
    if (!c.t) { SH2_POLL(c); goto L_0606DBD6; }  // 0606DBFA bf 0x0606DBD6
L_0606DBFC:
    c.r[1] = ld32(0x0606DC4Cu);  // 0606DBFC mov.l 0x0606DC4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DC02u; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DC02u) return; }  // 0606DBFE jsr @r1 ; mov #7,r4
    c.r[15] = c.r[14];  // 0606DC02 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606DC04 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606DC06 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606DC08 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606DC0A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606DC1Cu);  // 0606DC0C mov.w 0x0606DC1C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606DC0E rts ; mov.l @r15+,r8
}

void f_0606DC50(SH2Context& c) {
    ran[1568] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606DC50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606DC52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606DC54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606DC56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606DC58 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606DC5A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606DC5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606DC5E sts.l pr,@-r15
    c.r[15] -= 48;  // 0606DC60 add #-48,r15
    c.r[1] = ld32(0x0606DDFCu);  // 0606DC62 mov.l 0x0606DDFC,r1
    c.r[1] = ld32(c.r[1]);  // 0606DC64 mov.l @r1,r1
    c.r[14] = c.r[15];  // 0606DC66 mov r15,r14
    c.r[1] += 1;  // 0606DC68 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DC6A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606DC6C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606DC6E tst r1,r1
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_0606DCEC; } }  // 0606DC70 bf/s 0x0606DCEC ; mov #0,r13
    c.r[1] = ld32(0x0606DE00u);  // 0606DC74 mov.l 0x0606DE00,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DC76 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606DC78 extu.b r2,r2
    c.r[1] = ld32(0x0606DE04u);  // 0606DC7A mov.l 0x0606DE04,r1
    c.r[1] = ld32(c.r[1]);  // 0606DC7C mov.l @r1,r1
    c.r[2] <<= 2;  // 0606DC7E shll2 r2
    c.r[2] <<= 2;  // 0606DC80 shll2 r2
    c.r[2] += c.r[1];  // 0606DC82 add r1,r2
    c.r[2] += 2;  // 0606DC84 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606DC86 mov.b @r2,r2
    c.r[1] = ld32(0x0606DE08u);  // 0606DC88 mov.l 0x0606DE08,r1
    c.r[3] = ld32(c.r[1]);  // 0606DC8A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606DC8C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0606DC8E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606DC90 mul.l r1,r2
    c.r[1] = c.macl;  // 0606DC92 sts macl,r1
    c.r[1] += c.r[3];  // 0606DC94 add r3,r1
    c.r[1] += 15;  // 0606DC96 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DC98 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0606DC9A extu.b r1,r9
    c.r[1] = ld32(0x0606DE0Cu);  // 0606DC9C mov.l 0x0606DE0C,r1
    c.r[2] = ld32(c.r[1]);  // 0606DC9E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606DDFAu);  // 0606DCA0 mov.w 0x0606DDFA,r1
    c.r[0] = c.r[2];  // 0606DCA2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606DCA4 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606DCA6 extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 0606DCA8 cmp/ge r1,r13
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0606DCDA; } }  // 0606DCAA bt/s 0x0606DCDA ; mov #0,r10
    c.r[7] = c.r[2];  // 0606DCAE mov r2,r7
    c.r[4] = c.r[9] & 0xFFFFu;  // 0606DCB0 extu.w r9,r4
    c.r[6] = c.r[1];  // 0606DCB2 mov r1,r6
    c.r[3] = c.r[7];  // 0606DCB4 mov r7,r3
    c.r[2] = 0x0u;  // 0606DCB6 mov #0,r2
L_0606DCB8:
    c.r[0] = c.r[2];  // 0606DCB8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606DCBA mov.b @(r0,r7),r1
    c.r[8] = 0x7Fu;  // 0606DCBC mov #127,r8
    c.r[8] &= c.r[1];  // 0606DCBE and r1,r8
    c.r[1] = c.r[3];  // 0606DCC0 mov r3,r1
    c.r[1] += 1;  // 0606DCC2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DCC4 mov.b @r1,r1
    c.r[8] <<= 8;  // 0606DCC6 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0606DCC8 extu.b r1,r1
    c.r[1] |= c.r[8];  // 0606DCCA or r8,r1
    c.t = c.r[1] == c.r[4];  // 0606DCCC cmp/eq r4,r1
    if (c.t) { goto L_0606DCDA; }  // 0606DCCE bt 0x0606DCDA
    c.r[3] += 2;  // 0606DCD0 add #2,r3
    c.r[10] += 1;  // 0606DCD2 add #1,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[6];  // 0606DCD4 cmp/ge r6,r10
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_0606DCB8; } }  // 0606DCD6 bf/s 0x0606DCB8 ; add #2,r2
L_0606DCDA:
    c.r[1] = ld32(0x0606DE0Cu);  // 0606DCDA mov.l 0x0606DE0C,r1
    c.r[1] = ld32(c.r[1]);  // 0606DCDC mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606DDFAu);  // 0606DCDE mov.w 0x0606DDFA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606DCE0 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606DCE2 extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 0606DCE4 cmp/eq r1,r10
    if (c.t) { goto L_0606DCEC; }  // 0606DCE6 bt 0x0606DCEC
    c.r[1] = ld32(0x0606DE10u);  // 0606DCE8 mov.l 0x0606DE10,r1
    st8(c.r[1], c.r[10]);  // 0606DCEA mov.b r10,@r1
L_0606DCEC:
    c.r[10] = 0x0u;  // 0606DCEC mov #0,r10
    c.r[1] = ld32(0x0606DE14u);  // 0606DCEE mov.l 0x0606DE14,r1
    c.r[7] = ld32(c.r[1]);  // 0606DCF0 mov.l @r1,r7
    c.r[6] = 0x0u;  // 0606DCF2 mov #0,r6
    c.r[5] = c.r[7];  // 0606DCF4 mov r7,r5
L_0606DCF6:
    c.r[0] = c.r[6];  // 0606DCF6 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 0606DCF8 mov.w @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606DCFA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606DCFC tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0606DD2C; } }  // 0606DCFE bt/s 0x0606DD2C ; mov r7,r1
    c.r[1] += 8;  // 0606DD02 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DD04 mov.b @r1,r2
    c.r[1] = ld32(0x0606DE0Cu);  // 0606DD06 mov.l 0x0606DE0C,r1
    c.r[3] = ld32(c.r[1]);  // 0606DD08 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606DD0A extu.b r2,r2
    c.r[1] = ld32(0x0606DE10u);  // 0606DD0C mov.l 0x0606DE10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DD0E mov.b @r1,r1
    c.r[0] = c.r[3];  // 0606DD10 mov r3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0606DD12 extu.b r1,r1
    c.r[1] += c.r[1];  // 0606DD14 add r1,r1
    c.r[3] += c.r[1];  // 0606DD16 add r1,r3
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606DD18 mov.b @(r0,r1),r4
    c.r[3] += 1;  // 0606DD1A add #1,r3
    c.r[0] = 0x7Fu;  // 0606DD1C mov #127,r0
    c.r[4] &= c.r[0];  // 0606DD1E and r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606DD20 mov.b @r3,r1
    c.r[4] <<= 8;  // 0606DD22 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0606DD24 extu.b r1,r1
    c.r[1] |= c.r[4];  // 0606DD26 or r4,r1
    c.t = c.r[2] == c.r[1];  // 0606DD28 cmp/eq r1,r2
    if (c.t) { goto L_0606DDF6; }  // 0606DD2A bt 0x0606DDF6
L_0606DD2C:
    c.r[7] += 12;  // 0606DD2C add #12,r7
    c.r[10] += 1;  // 0606DD2E add #1,r10
    c.r[1] = 0x7Fu;  // 0606DD30 mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606DD32 cmp/gt r1,r10
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_0606DCF6; } }  // 0606DD34 bf/s 0x0606DCF6 ; add #12,r6
L_0606DD38:
    c.r[1] = ld32(0x0606DE18u);  // 0606DD38 mov.l 0x0606DE18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DD3Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD3Eu) return; }  // 0606DD3A jsr @r1 ; mov #1,r4
    c.r[8] = ld32(0x0606DE1Cu);  // 0606DD3E mov.l 0x0606DE1C,r8
    c.r[1] = ld32(0x0606DE20u);  // 0606DD40 mov.l 0x0606DE20,r1
    c.r[6] = 0x2Eu;  // 0606DD42 mov #46,r6
    c.r[5] = ld32(c.r[8]);  // 0606DD44 mov.l @r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606DD4Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD4Au) return; }  // 0606DD46 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x0606DE0Cu);  // 0606DD4A mov.l 0x0606DE0C,r1
    c.r[2] = ld32(c.r[1]);  // 0606DD4C mov.l @r1,r2
    c.r[1] = ld32(0x0606DE10u);  // 0606DD4E mov.l 0x0606DE10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DD50 mov.b @r1,r1
    c.r[4] = ld32(c.r[8]);  // 0606DD52 mov.l @r8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0606DD54 extu.b r1,r1
    c.r[1] += c.r[1];  // 0606DD56 add r1,r1
    c.r[2] += c.r[1];  // 0606DD58 add r1,r2
    c.r[2] += 1;  // 0606DD5A add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606DD5C mov.b @r2,r5
    c.r[1] = ld32(0x0606DE24u);  // 0606DD5E mov.l 0x0606DE24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DD64u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD64u) return; }  // 0606DD60 jsr @r1 ; extu.b r5,r5
    c.r[0] = ld32(0x0606DE28u);  // 0606DD64 mov.l 0x0606DE28,r0
    c.r[6] = 0x4u;  // 0606DD66 mov #4,r6
    c.r[1] = ld32(c.r[8]);  // 0606DD68 mov.l @r8,r1
    c.r[5] = 0x3u;  // 0606DD6A mov #3,r5
    c.r[1] += 42;  // 0606DD6C add #42,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DD6E mov.w @r1,r7
    c.r[4] = 0x1u;  // 0606DD70 mov #1,r4
    c.r[7] <<= 16;  // 0606DD72 shll16 r7
    c.r[7] += c.r[7];  // 0606DD74 add r7,r7
    c.r[7] >>= 16;  // 0606DD76 shlr16 r7
    c.r[7] += c.r[7];  // 0606DD78 add r7,r7
    c.r[7] >>= 8;  // 0606DD7A shlr8 r7
    c.r[1] = 0x0u;  // 0606DD7C mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0606DD82u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD82u) return; }  // 0606DD7E jsr @r0 ; mov.l r1,@-r15
    c.r[1] = ld32(0x0606DE2Cu);  // 0606DD82 mov.l 0x0606DE2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DD88u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD88u) return; }  // 0606DD84 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0606DE30u);  // 0606DD88 mov.l 0x0606DE30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DD8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD8Eu) return; }  // 0606DD8A jsr @r1 ; nop
    c.r[1] = ld32(0x0606DE34u);  // 0606DD8E mov.l 0x0606DE34,r1
    c.r[1] = ld32(c.r[1]);  // 0606DD90 mov.l @r1,r1
    c.r[0] = ld32(0x0606DE38u);  // 0606DD92 mov.l 0x0606DE38,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DD94 mov.w @r1,r5
    c.r[4] = 0x0u;  // 0606DD96 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0606DD9Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DD9Cu) return; }  // 0606DD98 jsr @r0 ; extu.w r5,r5
    c.r[10] = c.r[0] & 0xFFFFu;  // 0606DD9C extu.w r0,r10
    c.r[1] = ld32(0x0606DE3Cu);  // 0606DD9E mov.l 0x0606DE3C,r1
    c.t = c.r[10] == c.r[1];  // 0606DDA0 cmp/eq r1,r10
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0606DE58; } }  // 0606DDA2 bt/s 0x0606DE58 ; add #4,r15
    c.r[9] = ld32(0x0606DE40u);  // 0606DDA6 mov.l 0x0606DE40,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0606DDACu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DDACu) return; }  // 0606DDA8 jsr @r9 ; mov #8,r4
    c.r[4] = ld32(0x0606DE44u);  // 0606DDAC mov.l 0x0606DE44,r4
    c.r[8] = ld32(0x0606DE48u);  // 0606DDAE mov.l 0x0606DE48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606DDB4u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DDB4u) return; }  // 0606DDB0 jsr @r8 ; mov #23,r5
    c.r[5] = 0x15u;  // 0606DDB4 mov #21,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DDBAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DDBAu) return; }  // 0606DDB6 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606DE4Cu);  // 0606DDBA mov.l 0x0606DE4C,r1
    c.r[6] = 0x0u;  // 0606DDBC mov #0,r6
    c.r[5] = 0x3u;  // 0606DDBE mov #3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606DDC4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DDC4u) return; }  // 0606DDC0 jsr @r1 ; mov r0,r4
    c.r[1] = ld32(0x0606DE50u);  // 0606DDC4 mov.l 0x0606DE50,r1
    c.r[10] <<= 2;  // 0606DDC6 shll2 r10
    c.r[5] = 0x0u;  // 0606DDC8 mov #0,r5
    c.r[2] = ld32(c.r[1]);  // 0606DDCA mov.l @r1,r2
    c.r[4] = 0x0u;  // 0606DDCC mov #0,r4
    c.r[2] += c.r[10];  // 0606DDCE add r10,r2
    c.r[1] = c.r[2];  // 0606DDD0 mov r2,r1
    c.r[1] += 22;  // 0606DDD2 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DDD4 mov.b @r1,r0
    c.r[2] += 23;  // 0606DDD6 add #23,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606DDD8 mov.b @r2,r6
    c.r[0] &= 0x1Fu;  // 0606DDDA and #31,r0
    c.r[0] <<= 2;  // 0606DDDC shll2 r0
    c.r[0] += c.r[0];  // 0606DDDE add r0,r0
    c.r[0] <<= 2;  // 0606DDE0 shll2 r0
    c.r[6] = c.r[6] & 0xFFu;  // 0606DDE2 extu.b r6,r6
    c.r[6] >>= 2;  // 0606DDE4 shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0606DDE6 shlr r6
    c.r[1] = ld32(0x0606DE54u);  // 0606DDE8 mov.l 0x0606DE54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DDEEu; c.r[6] |= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DDEEu) return; }  // 0606DDEA jsr @r1 ; or r0,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0606DDF2u; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DDF2u) return; }  // 0606DDEE jsr @r9 ; mov #14,r4
    goto L_0606DE66;  // 0606DDF2 bra 0x0606DE66 ; nop
L_0606DDF6:
    c.r[13] = 0x1u; SH2_POLL(c); goto L_0606DD38;  // 0606DDF6 bra 0x0606DD38 ; mov #1,r13
L_0606DE58:
    c.r[8] = ld32(0x0606DFA0u);  // 0606DE58 mov.l 0x0606DFA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606DE5Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DE5Eu) return; }  // 0606DE5A jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606DE62u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DE62u) return; }  // 0606DE5E jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606DE66u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DE66u) return; }  // 0606DE62 jsr @r8 ; mov #0,r4
L_0606DE66:
    c.r[1] = ld32(0x0606DFA4u);  // 0606DE66 mov.l 0x0606DFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0606DE68 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606DF96u);  // 0606DE6A mov.w 0x0606DF96,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606DE6C mov.b @(r0,r1),r1
    c.r[2] = 0x1u;  // 0606DE6E mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606DE70 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606DE72 cmp/hi r2,r1
    if (!c.t) { goto L_0606DEAA; }  // 0606DE74 bf 0x0606DEAA
    c.r[1] = ld32(0x0606DFA8u);  // 0606DE76 mov.l 0x0606DFA8,r1
    c.r[1] = ld32(c.r[1]);  // 0606DE78 mov.l @r1,r1
    c.r[1] += 1;  // 0606DE7A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DE7C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606DE7E extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606DE80 cmp/hi r2,r1
    { const bool k = !c.t; c.r[9] = 0xCu; if (k) { goto L_0606DE88; } }  // 0606DE82 bf/s 0x0606DE88 ; mov #12,r9
    c.r[9] = 0xDu;  // 0606DE86 mov #13,r9
L_0606DE88:
    c.r[4] = ld32(0x0606DFACu);  // 0606DE88 mov.l 0x0606DFAC,r4
    c.r[8] = ld32(0x0606DFB0u);  // 0606DE8A mov.l 0x0606DFB0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606DE90u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DE90u) return; }  // 0606DE8C jsr @r8 ; mov #23,r5
    c.r[5] = 0xAu;  // 0606DE90 mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DE96u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DE96u) return; }  // 0606DE92 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 0606DE96 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DE9Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DE9Cu) return; }  // 0606DE98 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606DFB4u);  // 0606DE9C mov.l 0x0606DFB4,r1
    c.r[6] = 0x0u;  // 0606DE9E mov #0,r6
    c.r[5] = c.r[0];  // 0606DEA0 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0606DEA6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DEA6u) return; }  // 0606DEA2 jsr @r1 ; mov #0,r4
    goto L_0606DEB0;  // 0606DEA6 bra 0x0606DEB0 ; nop
L_0606DEAA:
    c.r[1] = ld32(0x0606DFA0u);  // 0606DEAA mov.l 0x0606DFA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DEB0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DEB0u) return; }  // 0606DEAC jsr @r1 ; mov #0,r4
L_0606DEB0:
    c.r[9] = ld32(0x0606DFB8u);  // 0606DEB0 mov.l 0x0606DFB8,r9
    c.r[1] = ld32(c.r[9]);  // 0606DEB2 mov.l @r9,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DEB4 mov.w @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606DF98u);  // 0606DEB6 mov.w 0x0606DF98,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606DF9Au);  // 0606DEB8 mov.w 0x0606DF9A,r1
    c.r[4] += c.r[1];  // 0606DEBA add r1,r4
    c.r[1] = ld32(0x0606DFBCu);  // 0606DEBC mov.l 0x0606DFBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DEC2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DEC2u) return; }  // 0606DEBE jsr @r1 ; extu.w r4,r4
    c.r[8] = ld32(0x0606DFC0u);  // 0606DEC2 mov.l 0x0606DFC0,r8
    c.r[1] = ld32(c.r[9]);  // 0606DEC4 mov.l @r9,r1
    c.r[5] = 0x0u;  // 0606DEC6 mov #0,r5
    c.r[1] += 2;  // 0606DEC8 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DECA mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606DECC mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606DED2u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DED2u) return; }  // 0606DECE jsr @r8 ; extu.b r6,r6
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606DED2 tst r13,r13
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606DEDE; } }  // 0606DED4 bt/s 0x0606DEDE ; mov #0,r5
    c.r[6] = 0x0u;  // 0606DED8 mov #0,r6
    c.r[4] = 0x30u; goto L_0606DEE8;  // 0606DEDA bra 0x0606DEE8 ; mov #48,r4
L_0606DEDE:
    c.r[1] = ld32(c.r[9]);  // 0606DEDE mov.l @r9,r1
    c.r[1] += 9;  // 0606DEE0 add #9,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DEE2 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606DEE4 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0606DEE6 extu.b r6,r6
L_0606DEE8:
    { const uint32_t x = c.r[8]; c.pr = 0x0606DEECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DEECu) return; }  // 0606DEE8 jsr @r8 ; nop
    c.r[1] = ld32(0x0606DFC4u);  // 0606DEEC mov.l 0x0606DFC4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DEEE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0606DEF0 extu.b r2,r2
    c.r[1] = ld32(0x0606DFC8u);  // 0606DEF2 mov.l 0x0606DFC8,r1
    c.r[1] = ld32(c.r[1]);  // 0606DEF4 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606DEF6 shll2 r2
    c.r[2] <<= 2;  // 0606DEF8 shll2 r2
    c.r[2] += c.r[1];  // 0606DEFA add r1,r2
    c.r[2] += 3;  // 0606DEFC add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606DEFE mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606DF00 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606DF02 shlr r0
    c.r[0] &= 0x3u;  // 0606DF04 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606DF06 tst r0,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606DF14; } }  // 0606DF08 bt/s 0x0606DF14 ; mov #0,r5
    c.r[1] = ld32(0x0606DFC0u);  // 0606DF0C mov.l 0x0606DFC0,r1
    c.r[6] = 0x0u;  // 0606DF0E mov #0,r6
    c.r[4] = 0x40u; goto L_0606DF20;  // 0606DF10 bra 0x0606DF20 ; mov #64,r4
L_0606DF14:
    c.r[1] = ld32(0x0606DFB8u);  // 0606DF14 mov.l 0x0606DFB8,r1
    c.r[1] = ld32(c.r[1]);  // 0606DF16 mov.l @r1,r1
    c.r[1] += 4;  // 0606DF18 add #4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DF1A mov.w @r1,r6
    c.r[4] = 0x40u;  // 0606DF1C mov #64,r4
    c.r[1] = ld32(0x0606DFC0u);  // 0606DF1E mov.l 0x0606DFC0,r1
L_0606DF20:
    { const uint32_t x = c.r[1]; c.pr = 0x0606DF24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF24u) return; }  // 0606DF20 jsr @r1 ; nop
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606DF24 tst r13,r13
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606DF3E; } }  // 0606DF26 bt/s 0x0606DF3E ; mov #0,r5
    c.r[8] = ld32(0x0606DFC0u);  // 0606DF2A mov.l 0x0606DFC0,r8
    c.r[6] = 0x0u;  // 0606DF2C mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0606DF32u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF32u) return; }  // 0606DF2E jsr @r8 ; mov #48,r4
    c.r[6] = 0x0u;  // 0606DF32 mov #0,r6
    c.r[5] = 0x0u;  // 0606DF34 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606DF3Au; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF3Au) return; }  // 0606DF36 jsr @r8 ; mov #48,r4
    goto L_0606DF5C;  // 0606DF3A bra 0x0606DF5C ; nop
L_0606DF3E:
    c.r[8] = ld32(0x0606DFB8u);  // 0606DF3E mov.l 0x0606DFB8,r8
    c.r[9] = ld32(0x0606DFC0u);  // 0606DF40 mov.l 0x0606DFC0,r9
    c.r[1] = ld32(c.r[8]);  // 0606DF42 mov.l @r8,r1
    c.r[1] += 14;  // 0606DF44 add #14,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DF46 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606DF48 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606DF4Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF4Eu) return; }  // 0606DF4A jsr @r9 ; extu.b r6,r6
    c.r[1] = ld32(c.r[8]);  // 0606DF4E mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606DF50 mov #0,r5
    c.r[1] += 15;  // 0606DF52 add #15,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606DF54 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0606DF56 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606DF5Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF5Cu) return; }  // 0606DF58 jsr @r9 ; extu.b r6,r6
L_0606DF5C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606DF9Cu);  // 0606DF5C mov.w 0x0606DF9C,r4
    c.r[8] = ld32(0x0606DFA0u);  // 0606DF5E mov.l 0x0606DFA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606DF64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF64u) return; }  // 0606DF60 jsr @r8 ; nop
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606DF64 tst r13,r13
    if (!c.t) { goto L_0606DFD0; }  // 0606DF66 bf 0x0606DFD0
    c.r[1] = ld32(0x0606DFB8u);  // 0606DF68 mov.l 0x0606DFB8,r1
    c.r[1] = ld32(c.r[1]);  // 0606DF6A mov.l @r1,r1
    c.r[1] += 20;  // 0606DF6C add #20,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DF6E mov.w @r1,r2
    c.r[1] = ld32(0x0606DFCCu);  // 0606DF70 mov.l 0x0606DFCC,r1
    c.r[3] = ld32(c.r[1]);  // 0606DF72 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606DF74 extu.w r2,r2
    c.r[1] = c.r[3];  // 0606DF76 mov r3,r1
    c.r[1] += 34;  // 0606DF78 add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DF7A mov.w @r1,r1
    c.r[3] += 32;  // 0606DF7C add #32,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606DF7E extu.w r1,r1
    c.r[2] += c.r[1];  // 0606DF80 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606DF82 mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606DF84 extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606DF86 cmp/gt r1,r2
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_0606DFD0; } }  // 0606DF88 bf/s 0x0606DFD0 ; tst r1,r1
    if (c.t) { goto L_0606DFD0; }  // 0606DF8C bt 0x0606DFD0
    { const uint32_t x = c.r[8]; c.pr = 0x0606DF92u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DF92u) return; }  // 0606DF8E jsr @r8 ; mov #2,r4
    c.t = (c.r[13] & c.r[13]) == 0; goto L_0606DFD8;  // 0606DF92 bra 0x0606DFD8 ; tst r13,r13
L_0606DFD0:
    c.r[1] = ld32(0x0606E0E8u);  // 0606DFD0 mov.l 0x0606E0E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606DFD6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DFD6u) return; }  // 0606DFD2 jsr @r1 ; mov #1,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606DFD6 tst r13,r13
L_0606DFD8:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606DFE8; } }  // 0606DFD8 bt/s 0x0606DFE8 ; mov #0,r5
    c.r[8] = ld32(0x0606E0ECu);  // 0606DFDC mov.l 0x0606E0EC,r8
    c.r[6] = 0x0u;  // 0606DFDE mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0606DFE4u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DFE4u) return; }  // 0606DFE0 jsr @r8 ; mov #48,r4
    c.r[6] = 0x0u; goto L_0606E00E;  // 0606DFE4 bra 0x0606E00E ; mov #0,r6
L_0606DFE8:
    c.r[1] = ld32(0x0606E0F0u);  // 0606DFE8 mov.l 0x0606E0F0,r1
    c.r[8] = ld32(0x0606E0ECu);  // 0606DFEA mov.l 0x0606E0EC,r8
    c.r[1] = ld32(c.r[1]);  // 0606DFEC mov.l @r1,r1
    c.r[1] += 20;  // 0606DFEE add #20,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DFF0 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606DFF2 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606DFF8u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606DFF8u) return; }  // 0606DFF4 jsr @r8 ; extu.w r6,r6
    c.r[1] = ld32(0x0606E0F4u);  // 0606DFF8 mov.l 0x0606E0F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606DFFA mov.l @r1,r1
    c.r[1] += 34;  // 0606DFFC add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606DFFE mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0606E000 extu.w r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0606E002 tst r6,r6
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606E00C; } }  // 0606E004 bt/s 0x0606E00C ; mov #0,r5
    c.r[4] = 0x0u; goto L_0606E012;  // 0606E008 bra 0x0606E012 ; mov #0,r4
L_0606E00C:
    c.r[6] = 0x0u;  // 0606E00C mov #0,r6
L_0606E00E:
    c.r[5] = 0x0u;  // 0606E00E mov #0,r5
    c.r[4] = 0x30u;  // 0606E010 mov #48,r4
L_0606E012:
    { const uint32_t x = c.r[8]; c.pr = 0x0606E016u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E016u) return; }  // 0606E012 jsr @r8 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606E0E6u);  // 0606E016 mov.w 0x0606E0E6,r4
    c.r[8] = ld32(0x0606E0E8u);  // 0606E018 mov.l 0x0606E0E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E01Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E01Eu) return; }  // 0606E01A jsr @r8 ; nop
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606E01E tst r13,r13
    if (!c.t) { goto L_0606E050; }  // 0606E020 bf 0x0606E050
    c.r[1] = ld32(0x0606E0F0u);  // 0606E022 mov.l 0x0606E0F0,r1
    c.r[1] = ld32(c.r[1]);  // 0606E024 mov.l @r1,r1
    c.r[1] += 16;  // 0606E026 add #16,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E028 mov.w @r1,r2
    c.r[1] = ld32(0x0606E0F4u);  // 0606E02A mov.l 0x0606E0F4,r1
    c.r[3] = ld32(c.r[1]);  // 0606E02C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606E02E extu.w r2,r2
    c.r[1] = c.r[3];  // 0606E030 mov r3,r1
    c.r[1] += 34;  // 0606E032 add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E034 mov.w @r1,r1
    c.r[3] += 32;  // 0606E036 add #32,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606E038 extu.w r1,r1
    c.r[2] += c.r[1];  // 0606E03A add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606E03C mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606E03E extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606E040 cmp/gt r1,r2
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_0606E050; } }  // 0606E042 bf/s 0x0606E050 ; tst r1,r1
    if (c.t) { goto L_0606E050; }  // 0606E046 bt 0x0606E050
    { const uint32_t x = c.r[8]; c.pr = 0x0606E04Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E04Cu) return; }  // 0606E048 jsr @r8 ; mov #2,r4
    c.t = (c.r[13] & c.r[13]) == 0; goto L_0606E058;  // 0606E04C bra 0x0606E058 ; tst r13,r13
L_0606E050:
    c.r[1] = ld32(0x0606E0E8u);  // 0606E050 mov.l 0x0606E0E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E056u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E056u) return; }  // 0606E052 jsr @r1 ; mov #1,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606E056 tst r13,r13
L_0606E058:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606E068; } }  // 0606E058 bt/s 0x0606E068 ; mov #0,r5
    c.r[8] = ld32(0x0606E0ECu);  // 0606E05C mov.l 0x0606E0EC,r8
    c.r[6] = 0x0u;  // 0606E05E mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0606E064u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E064u) return; }  // 0606E060 jsr @r8 ; mov #48,r4
    c.r[6] = 0x0u; goto L_0606E08E;  // 0606E064 bra 0x0606E08E ; mov #0,r6
L_0606E068:
    c.r[1] = ld32(0x0606E0F0u);  // 0606E068 mov.l 0x0606E0F0,r1
    c.r[8] = ld32(0x0606E0ECu);  // 0606E06A mov.l 0x0606E0EC,r8
    c.r[1] = ld32(c.r[1]);  // 0606E06C mov.l @r1,r1
    c.r[1] += 16;  // 0606E06E add #16,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E070 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606E072 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E078u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E078u) return; }  // 0606E074 jsr @r8 ; extu.w r6,r6
    c.r[1] = ld32(0x0606E0F4u);  // 0606E078 mov.l 0x0606E0F4,r1
    c.r[1] = ld32(c.r[1]);  // 0606E07A mov.l @r1,r1
    c.r[1] += 34;  // 0606E07C add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E07E mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0606E080 extu.w r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0606E082 tst r6,r6
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606E08C; } }  // 0606E084 bt/s 0x0606E08C ; mov #0,r5
    c.r[4] = 0x0u; goto L_0606E092;  // 0606E088 bra 0x0606E092 ; mov #0,r4
L_0606E08C:
    c.r[6] = 0x0u;  // 0606E08C mov #0,r6
L_0606E08E:
    c.r[5] = 0x0u;  // 0606E08E mov #0,r5
    c.r[4] = 0x30u;  // 0606E090 mov #48,r4
L_0606E092:
    { const uint32_t x = c.r[8]; c.pr = 0x0606E096u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E096u) return; }  // 0606E092 jsr @r8 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606E0E6u);  // 0606E096 mov.w 0x0606E0E6,r4
    c.r[8] = ld32(0x0606E0E8u);  // 0606E098 mov.l 0x0606E0E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E09Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E09Eu) return; }  // 0606E09A jsr @r8 ; nop
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606E09E tst r13,r13
    if (!c.t) { goto L_0606E0C6; }  // 0606E0A0 bf 0x0606E0C6
    c.r[1] = ld32(0x0606E0F0u);  // 0606E0A2 mov.l 0x0606E0F0,r1
    c.r[3] = ld32(c.r[1]);  // 0606E0A4 mov.l @r1,r3
    c.r[1] = ld32(0x0606E0F4u);  // 0606E0A6 mov.l 0x0606E0F4,r1
    c.r[2] = ld32(c.r[1]);  // 0606E0A8 mov.l @r1,r2
    c.r[3] += 22;  // 0606E0AA add #22,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606E0AC mov.w @r3,r1
    c.r[2] += 32;  // 0606E0AE add #32,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0606E0B0 mov.w @r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606E0B2 extu.w r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606E0B4 extu.w r2,r2
    c.t = c.r[1] > c.r[2];  // 0606E0B6 cmp/hi r2,r1
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0606E0C6; } }  // 0606E0B8 bf/s 0x0606E0C6 ; tst r2,r2
    if (c.t) { goto L_0606E0C6; }  // 0606E0BC bt 0x0606E0C6
    { const uint32_t x = c.r[8]; c.pr = 0x0606E0C2u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E0C2u) return; }  // 0606E0BE jsr @r8 ; mov #2,r4
    c.t = (c.r[13] & c.r[13]) == 0; goto L_0606E0CE;  // 0606E0C2 bra 0x0606E0CE ; tst r13,r13
L_0606E0C6:
    c.r[1] = ld32(0x0606E0E8u);  // 0606E0C6 mov.l 0x0606E0E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E0CCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E0CCu) return; }  // 0606E0C8 jsr @r1 ; mov #1,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606E0CC tst r13,r13
L_0606E0CE:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0606E0F8; } }  // 0606E0CE bt/s 0x0606E0F8 ; mov #0,r5
    c.r[8] = ld32(0x0606E0ECu);  // 0606E0D2 mov.l 0x0606E0EC,r8
    c.r[6] = 0x0u;  // 0606E0D4 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0606E0DAu; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E0DAu) return; }  // 0606E0D6 jsr @r8 ; mov #48,r4
    c.r[6] = 0x0u;  // 0606E0DA mov #0,r6
    c.r[5] = 0x0u;  // 0606E0DC mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606E0E2u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E0E2u) return; }  // 0606E0DE jsr @r8 ; mov #48,r4
    goto L_0606E116;  // 0606E0E2 bra 0x0606E116 ; nop
L_0606E0F8:
    c.r[8] = ld32(0x0606E22Cu);  // 0606E0F8 mov.l 0x0606E22C,r8
    c.r[9] = ld32(0x0606E230u);  // 0606E0FA mov.l 0x0606E230,r9
    c.r[1] = ld32(c.r[8]);  // 0606E0FC mov.l @r8,r1
    c.r[1] += 22;  // 0606E0FE add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E100 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606E102 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E108u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E108u) return; }  // 0606E104 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 0606E108 mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606E10A mov #0,r5
    c.r[1] += 18;  // 0606E10C add #18,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E10E mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606E110 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E116u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E116u) return; }  // 0606E112 jsr @r9 ; extu.w r6,r6
L_0606E116:
    c.r[8] = ld32(0x0606E22Cu);  // 0606E116 mov.l 0x0606E22C,r8
    c.r[9] = ld32(0x0606E230u);  // 0606E118 mov.l 0x0606E230,r9
    c.r[1] = ld32(c.r[8]);  // 0606E11A mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606E11C mov #0,r5
    c.r[1] += 10;  // 0606E11E add #10,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E120 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606E122 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E128u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E128u) return; }  // 0606E124 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 0606E128 mov.l @r8,r1
    c.r[5] = 0x0u;  // 0606E12A mov #0,r5
    c.r[1] += 12;  // 0606E12C add #12,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E12E mov.w @r1,r6
    c.r[4] = 0x0u;  // 0606E130 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606E136u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E136u) return; }  // 0606E132 jsr @r9 ; extu.w r6,r6
    c.r[10] = 0x0u;  // 0606E136 mov #0,r10
    c.r[11] = c.r[8];  // 0606E138 mov r8,r11
    c.r[8] = ld32(0x0606E234u);  // 0606E13A mov.l 0x0606E234,r8
    c.r[12] = ld32(0x0606E238u);  // 0606E13C mov.l 0x0606E238,r12
L_0606E13E:
    c.r[1] = ld32(c.r[11]);  // 0606E13E mov.l @r11,r1
    c.r[1] += c.r[10];  // 0606E140 add r10,r1
    c.r[1] += 24;  // 0606E142 add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E144 mov.b @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606E222u);  // 0606E146 mov.w 0x0606E222,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E14Cu; c.r[9] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E14Cu) return; }  // 0606E148 jsr @r8 ; extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E224u);  // 0606E14C mov.w 0x0606E224,r1
    c.t = c.r[9] == c.r[1];  // 0606E14E cmp/eq r1,r9
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0606E15E; } }  // 0606E150 bf/s 0x0606E15E ; mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0606E158u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E158u) return; }  // 0606E154 jsr @r8 ; mov #1,r4
    c.r[4] = ld32(0x0606E23Cu);  // 0606E158 mov.l 0x0606E23C,r4
    c.r[5] = c.r[9]; goto L_0606E184;  // 0606E15A bra 0x0606E184 ; mov r9,r5
L_0606E15E:
    c.r[0] = ld32(0x0606E240u);  // 0606E15E mov.l 0x0606E240,r0
    c.r[5] = ld32(c.r[11]);  // 0606E160 mov.l @r11,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0606E166u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E166u) return; }  // 0606E162 jsr @r0 ; mov r9,r4
    c.r[1] = ld32(c.r[11]);  // 0606E166 mov.l @r11,r1
    c.r[1] += 10;  // 0606E168 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606E16A mov.w @r1,r1
    c.r[2] = c.r[0] & 0xFFu;  // 0606E16C extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606E16E extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 0606E170 cmp/hi r1,r2
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_0606E178; } }  // 0606E172 bt/s 0x0606E178 ; mov #2,r4
    c.r[4] = 0x1u;  // 0606E176 mov #1,r4
L_0606E178:
    { const uint32_t x = c.r[8]; c.pr = 0x0606E17Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E17Cu) return; }  // 0606E178 jsr @r8 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606E226u);  // 0606E17C mov.w 0x0606E226,r1
    c.r[9] |= c.r[1];  // 0606E17E or r1,r9
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606E224u);  // 0606E180 mov.w 0x0606E224,r5
    c.r[4] = c.r[9];  // 0606E182 mov r9,r4
L_0606E184:
    { const uint32_t x = c.r[12]; c.pr = 0x0606E188u; c.r[10] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E188u) return; }  // 0606E184 jsr @r12 ; add #1,r10
    c.r[1] = 0x5u;  // 0606E188 mov #5,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606E18A cmp/gt r1,r10
    if (!c.t) { SH2_POLL(c); goto L_0606E13E; }  // 0606E18C bf 0x0606E13E
    c.r[1] = ld32(0x0606E234u);  // 0606E18E mov.l 0x0606E234,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E194u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E194u) return; }  // 0606E190 jsr @r1 ; mov #4,r4
    c.r[10] = 0x0u;  // 0606E194 mov #0,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606E224u);  // 0606E196 mov.w 0x0606E224,r11
    c.r[8] = ld32(0x0606E238u);  // 0606E198 mov.l 0x0606E238,r8
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606E19A tst r13,r13
L_0606E19C:
    if (!c.t) { goto L_0606E1B6; }  // 0606E19C bf 0x0606E1B6
    c.r[1] = ld32(0x0606E22Cu);  // 0606E19E mov.l 0x0606E22C,r1
    c.r[1] = ld32(c.r[1]);  // 0606E1A0 mov.l @r1,r1
    c.r[1] += c.r[10];  // 0606E1A2 add r10,r1
    c.r[1] += 30;  // 0606E1A4 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606E1A6 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0606E1A8 extu.b r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0606E1AA tst r4,r4
    if (c.t) { goto L_0606E1B6; }  // 0606E1AC bt 0x0606E1B6
    c.r[1] = ld32(0x0606E244u);  // 0606E1AE mov.l 0x0606E244,r1
    c.r[4] += c.r[1];  // 0606E1B0 add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_0606E1B8;  // 0606E1B2 bra 0x0606E1B8 ; extu.w r4,r4
L_0606E1B6:
    c.r[4] = ld32(0x0606E248u);  // 0606E1B6 mov.l 0x0606E248,r4
L_0606E1B8:
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1BCu; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1BCu) return; }  // 0606E1B8 jsr @r8 ; mov r11,r5
    c.r[10] += 1;  // 0606E1BC add #1,r10
    c.r[9] = 0x3u;  // 0606E1BE mov #3,r9
    c.t = (int32_t)c.r[10] > (int32_t)c.r[9];  // 0606E1C0 cmp/gt r9,r10
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { SH2_POLL(c); goto L_0606E19C; } }  // 0606E1C2 bf/s 0x0606E19C ; tst r13,r13
    { const bool k = c.t; c.r[5] = 0x2u; if (k) { goto L_0606E1E0; } }  // 0606E1C6 bt/s 0x0606E1E0 ; mov #2,r5
    c.r[8] = ld32(0x0606E234u);  // 0606E1CA mov.l 0x0606E234,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1D0u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1D0u) return; }  // 0606E1CC jsr @r8 ; mov #17,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1D4u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1D4u) return; }  // 0606E1D0 jsr @r8 ; mov #17,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1D8u; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1D8u) return; }  // 0606E1D4 jsr @r8 ; mov #17,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1DCu; c.r[4] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1DCu) return; }  // 0606E1D8 jsr @r8 ; mov #17,r4
    goto L_0606E1F8;  // 0606E1DC bra 0x0606E1F8 ; nop
L_0606E1E0:
    c.r[8] = ld32(0x0606E24Cu);  // 0606E1E0 mov.l 0x0606E24C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1E6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1E6u) return; }  // 0606E1E2 jsr @r8 ; mov #1,r4
    c.r[5] = 0x0u;  // 0606E1E6 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1ECu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1ECu) return; }  // 0606E1E8 jsr @r8 ; mov #1,r4
    c.r[5] = 0x1u;  // 0606E1EC mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1F2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1F2u) return; }  // 0606E1EE jsr @r8 ; mov #1,r4
    c.r[5] = c.r[9];  // 0606E1F2 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606E1F8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1F8u) return; }  // 0606E1F4 jsr @r8 ; mov #1,r4
L_0606E1F8:
    c.r[1] = ld32(0x0606E250u);  // 0606E1F8 mov.l 0x0606E250,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E1FEu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E1FEu) return; }  // 0606E1FA jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x0606E22Cu);  // 0606E1FE mov.l 0x0606E22C,r1
    c.r[6] = 0x2Eu;  // 0606E200 mov #46,r6
    c.r[4] = ld32(c.r[1]);  // 0606E202 mov.l @r1,r4
    c.r[1] = ld32(0x0606E254u);  // 0606E204 mov.l 0x0606E254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606E20Au; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606E20Au) return; }  // 0606E206 jsr @r1 ; mov r14,r5
    c.r[14] += 48;  // 0606E20A add #48,r14
    c.r[15] = c.r[14];  // 0606E20C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606E20E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606E210 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606E212 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606E214 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606E216 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606E218 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606E21A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606E228u);  // 0606E21C mov.w 0x0606E228,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606E21E rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
