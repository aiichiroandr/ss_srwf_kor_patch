#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06050524(SH2Context& c) {
    ran[1277] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050524 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050526 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050528 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605052A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605058Au);  // 0605052C mov.w 0x0605058A,r3
    c.r[15] += c.r[3];  // 0605052E add r3,r15
    c.r[14] = c.r[15];  // 06050530 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06050532 extu.b r4,r4
    c.r[9] = ld32(0x06050594u);  // 06050534 mov.l 0x06050594,r9
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605058Cu);  // 06050536 mov.w 0x0605058C,r6
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06050538 mov.w @r9,r8
    c.r[1] = ld32(0x06050598u);  // 0605053A mov.l 0x06050598,r1
    c.r[1] = ld32(c.r[1]);  // 0605053C mov.l @r1,r1
    c.r[8] += c.r[4];  // 0605053E add r4,r8
    c.r[8] += 1;  // 06050540 add #1,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06050542 extu.w r8,r8
    c.r[4] <<= 2;  // 06050544 shll2 r4
    c.r[4] <<= 2;  // 06050546 shll2 r4
    c.r[4] += c.r[1];  // 06050548 add r1,r4
    c.r[4] += 2;  // 0605054A add #2,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0605054C mov.b @r4,r5
    c.r[1] = ld32(0x0605059Cu);  // 0605054E mov.l 0x0605059C,r1
    c.r[5] = c.r[5] & 0xFFu;  // 06050550 extu.b r5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06050556u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050556u) return; }  // 06050552 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x060505A0u);  // 06050556 mov.l 0x060505A0,r1
    c.r[3] = c.r[8];  // 06050558 mov r8,r3
    c.r[3] <<= 2;  // 0605055A shll2 r3
    c.r[3] += c.r[8];  // 0605055C add r8,r3
    c.r[7] = ld32(c.r[1] + 8);  // 0605055E mov.l @(8,r1),r7
    c.r[0] = c.r[14];  // 06050560 mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605058Eu);  // 06050562 mov.w 0x0605058E,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06050564 mov.w @(r0,r1),r2
    c.r[3] += c.r[3];  // 06050566 add r3,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 06050568 extu.w r2,r2
    c.r[2] >>= 2;  // 0605056A shlr2 r2
    c.r[2] >>= 2;  // 0605056C shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605056E shlr r2
    c.r[2] >>= 2;  // 06050570 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06050572 mov.w @r9,r1
    c.r[0] = c.r[3];  // 06050574 mov r3,r0
    c.r[2] += c.r[1];  // 06050576 add r1,r2
    st16(c.r[0] + c.r[7], c.r[2]);  // 06050578 mov.w r2,@(r0,r7)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050590u);  // 0605057A mov.w 0x06050590,r3
    c.r[14] += c.r[3];  // 0605057C add r3,r14
    c.r[15] = c.r[14];  // 0605057E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06050580 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050582 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050584 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050586 rts ; mov.l @r15+,r8
}

void f_060505A4(SH2Context& c) {
    ran[1278] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060505A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060505A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060505A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060505AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060505AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060505AE sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605062Cu);  // 060505B0 mov.w 0x0605062C,r3
    c.r[15] += c.r[3];  // 060505B2 add r3,r15
    c.r[14] = c.r[15];  // 060505B4 mov r15,r14
    c.r[9] = 0x0u;  // 060505B6 mov #0,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605062Eu);  // 060505B8 mov.w 0x0605062E,r11
    c.r[10] = ld32(0x06050634u);  // 060505BA mov.l 0x06050634,r10
L_060505BC:
    c.r[1] = ld32(0x06050638u);  // 060505BC mov.l 0x06050638,r1
    c.r[0] = c.r[9];  // 060505BE mov r9,r0
    c.r[2] = ld32(c.r[1]);  // 060505C0 mov.l @r1,r2
    c.r[0] <<= 2;  // 060505C2 shll2 r0
    c.r[0] <<= 2;  // 060505C4 shll2 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060505C6 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060505C8 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 060505CA cmp/eq r11,r1
    { const bool k = c.t; c.r[1] = c.r[9] & 0xFFu; if (k) { goto L_06050610; } }  // 060505CC bt/s 0x06050610 ; extu.b r9,r1
    c.r[6] = c.r[11];  // 060505D0 mov r11,r6
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060505D2 mov.w @r10,r8
    c.r[4] = c.r[14];  // 060505D4 mov r14,r4
    c.r[8] += c.r[1];  // 060505D6 add r1,r8
    c.r[8] += 1;  // 060505D8 add #1,r8
    c.r[1] <<= 2;  // 060505DA shll2 r1
    c.r[1] <<= 2;  // 060505DC shll2 r1
    c.r[1] += c.r[2];  // 060505DE add r2,r1
    c.r[1] += 2;  // 060505E0 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060505E2 mov.b @r1,r5
    c.r[8] = c.r[8] & 0xFFFFu;  // 060505E4 extu.w r8,r8
    c.r[1] = ld32(0x0605063Cu);  // 060505E6 mov.l 0x0605063C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060505ECu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060505ECu) return; }  // 060505E8 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06050640u);  // 060505EC mov.l 0x06050640,r1
    c.r[7] = c.r[8];  // 060505EE mov r8,r7
    c.r[7] <<= 2;  // 060505F0 shll2 r7
    c.r[7] += c.r[8];  // 060505F2 add r8,r7
    c.r[3] = ld32(c.r[1] + 8);  // 060505F4 mov.l @(8,r1),r3
    c.r[0] = c.r[14];  // 060505F6 mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06050630u);  // 060505F8 mov.w 0x06050630,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060505FA mov.w @(r0,r1),r2
    c.r[7] += c.r[7];  // 060505FC add r7,r7
    c.r[2] = c.r[2] & 0xFFFFu;  // 060505FE extu.w r2,r2
    c.r[2] >>= 2;  // 06050600 shlr2 r2
    c.r[2] >>= 2;  // 06050602 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06050604 shlr r2
    c.r[2] >>= 2;  // 06050606 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06050608 mov.w @r10,r1
    c.r[0] = c.r[7];  // 0605060A mov r7,r0
    c.r[2] += c.r[1];  // 0605060C add r1,r2
    st16(c.r[0] + c.r[3], c.r[2]);  // 0605060E mov.w r2,@(r0,r3)
L_06050610:
    c.r[9] += 1;  // 06050610 add #1,r9
    c.r[1] = 0x49u;  // 06050612 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06050614 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_060505BC; }  // 06050616 bf 0x060505BC
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050632u);  // 06050618 mov.w 0x06050632,r3
    c.r[14] += c.r[3];  // 0605061A add r3,r14
    c.r[15] = c.r[14];  // 0605061C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605061E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050620 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06050622 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050624 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050626 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050628 rts ; mov.l @r15+,r8
}

void f_06050644(SH2Context& c) {
    ran[1279] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050644 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050646 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06050648 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605064A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605064C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605064E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06050650 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06050652 extu.b r4,r8
    c.r[3] = ld32(0x060506C8u);  // 06050654 mov.l 0x060506C8,r3
    c.r[1] = c.r[3];  // 06050656 mov r3,r1
    c.r[1] += 22;  // 06050658 add #22,r1
    c.r[2] = ld32(0x060506CCu);  // 0605065A mov.l 0x060506CC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605065C mov.w @r1,r1
    c.r[3] += 24;  // 0605065E add #24,r3
    c.r[2] = ld32(c.r[2] + 8);  // 06050660 mov.l @(8,r2),r2
    c.r[1] += c.r[8];  // 06050662 add r8,r1
    c.r[1] += 1;  // 06050664 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050666 extu.w r1,r1
    c.r[11] = c.r[1];  // 06050668 mov r1,r11
    c.r[11] <<= 2;  // 0605066A shll2 r11
    c.r[11] += c.r[1];  // 0605066C add r1,r11
    c.r[11] += c.r[11];  // 0605066E add r11,r11
    c.r[11] += c.r[2];  // 06050670 add r2,r11
    c.r[11] += 4;  // 06050672 add #4,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06050674 mov.b @r3,r1
    c.t = (c.r[5] & c.r[5]) == 0;  // 06050676 tst r5,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06050678 mov.w @r11,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0605067A extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060506C4u);  // 0605067C mov.w 0x060506C4,r1
    c.r[10] = c.r[1];  // 0605067E mov r1,r10
    { const bool k = c.t; c.r[10] &= c.r[2]; if (k) { goto L_060506A8; } }  // 06050680 bt/s 0x060506A8 ; and r2,r10
    c.r[0] = ld32(0x060506D0u);  // 06050684 mov.l 0x060506D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605068Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605068Au) return; }  // 06050686 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0605068A extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605068C tst r1,r1
    { const bool k = c.t; c.r[8] <<= 2; if (k) { goto L_060506A8; } }  // 0605068E bt/s 0x060506A8 ; shll2 r8
    c.r[1] = ld32(0x060506D4u);  // 06050692 mov.l 0x060506D4,r1
    c.r[1] = ld32(c.r[1]);  // 06050694 mov.l @r1,r1
    c.r[8] <<= 2;  // 06050696 shll2 r8
    c.r[8] += c.r[1];  // 06050698 add r1,r8
    c.r[8] += 3;  // 0605069A add #3,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605069C mov.b @r8,r1
    c.r[0] = c.r[1];  // 0605069E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060506A0 shlr r0
    c.r[0] &= 0x3u;  // 060506A2 and #3,r0
    c.r[9] += c.r[0]; goto L_060506AA;  // 060506A4 bra 0x060506AA ; add r0,r9
L_060506A8:
    c.r[9] += 3;  // 060506A8 add #3,r9
L_060506AA:
    c.r[9] <<= 2;  // 060506AA shll2 r9
    c.r[9] <<= 2;  // 060506AC shll2 r9
    c.r[1] = c.r[10];  // 060506AE mov r10,r1
    c.r[1] |= c.r[9];  // 060506B0 or r9,r1
    st16(c.r[11], c.r[1]);  // 060506B2 mov.w r1,@r11
    c.r[15] = c.r[14];  // 060506B4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060506B6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060506B8 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060506BA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060506BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060506BE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060506C0 rts ; mov.l @r15+,r8
}

void f_060506D8(SH2Context& c) {
    ran[1280] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060506D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060506DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060506DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060506DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060506E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060506E2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060506E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060506E6 sts.l pr,@-r15
    c.r[15] -= 4;  // 060506E8 add #-4,r15
    c.r[14] = c.r[15];  // 060506EA mov r15,r14
    c.r[12] = 0x0u;  // 060506EC mov #0,r12
    c.r[7] = ld32(0x06050794u);  // 060506EE mov.l 0x06050794,r7
    c.r[11] = 0x0u;  // 060506F0 mov #0,r11
L_060506F2:
    c.r[3] = c.r[11];  // 060506F2 mov r11,r3
    c.r[0] = ld32(c.r[7]);  // 060506F4 mov.l @r7,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06050790u);  // 060506F6 mov.w 0x06050790,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060506F8 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060506FA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060506FC cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06050770; } }  // 060506FE bt/s 0x06050770 ; add r0,r3
    c.r[8] = c.r[12] & 0xFFu;  // 06050702 extu.b r12,r8
    c.r[3] += 3;  // 06050704 add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06050706 mov.b @r3,r1
    c.r[6] = ld32(0x06050798u);  // 06050708 mov.l 0x06050798,r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605070A mov.w @r6,r2
    c.r[0] = c.r[1];  // 0605070C mov r1,r0
    c.r[0] >>= 2;  // 0605070E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06050710 shlr r0
    c.r[0] >>= 2;  // 06050712 shlr2 r0
    c.r[0] &= 0x1u;  // 06050714 and #1,r0
    c.r[2] += c.r[8];  // 06050716 add r8,r2
    c.r[2] += 1;  // 06050718 add #1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605071A extu.w r2,r2
    c.r[1] = ld32(0x0605079Cu);  // 0605071C mov.l 0x0605079C,r1
    c.r[13] = c.r[2];  // 0605071E mov r2,r13
    c.r[13] <<= 2;  // 06050720 shll2 r13
    c.r[13] += c.r[2];  // 06050722 add r2,r13
    c.r[13] += c.r[13];  // 06050724 add r13,r13
    c.r[6] = ld32(0x060507A0u);  // 06050726 mov.l 0x060507A0,r6
    c.r[1] = ld32(c.r[1] + 8);  // 06050728 mov.l @(8,r1),r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605072A tst r0,r0
    c.r[13] += c.r[1];  // 0605072C add r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605072E mov.b @r6,r1
    c.r[13] += 4;  // 06050730 add #4,r13
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[13]);  // 06050732 mov.w @r13,r2
    c.r[9] = c.r[1] & 0xFFu;  // 06050734 extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06050792u);  // 06050736 mov.w 0x06050792,r1
    c.r[10] = c.r[1];  // 06050738 mov r1,r10
    { const bool k = c.t; c.r[10] &= c.r[2]; if (k) { goto L_06050764; } }  // 0605073A bt/s 0x06050764 ; and r2,r10
    c.r[0] = ld32(0x060507A4u);  // 0605073E mov.l 0x060507A4,r0
    c.r[4] = c.r[8];  // 06050740 mov r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06050746u; st32(c.r[14], c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050746u) return; }  // 06050742 jsr @r0 ; mov.l r7,@r14
    c.r[1] = c.r[0] & 0xFFFFu;  // 06050746 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06050748 tst r1,r1
    { const bool k = c.t; c.r[7] = ld32(c.r[14]); if (k) { goto L_06050764; } }  // 0605074A bt/s 0x06050764 ; mov.l @r14,r7
    c.r[1] = ld32(c.r[7]);  // 0605074E mov.l @r7,r1
    c.r[8] <<= 2;  // 06050750 shll2 r8
    c.r[8] <<= 2;  // 06050752 shll2 r8
    c.r[8] += c.r[1];  // 06050754 add r1,r8
    c.r[8] += 3;  // 06050756 add #3,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06050758 mov.b @r8,r1
    c.r[0] = c.r[1];  // 0605075A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605075C shlr r0
    c.r[0] &= 0x3u;  // 0605075E and #3,r0
    c.r[9] += c.r[0]; goto L_06050766;  // 06050760 bra 0x06050766 ; add r0,r9
L_06050764:
    c.r[9] += 3;  // 06050764 add #3,r9
L_06050766:
    c.r[9] <<= 2;  // 06050766 shll2 r9
    c.r[9] <<= 2;  // 06050768 shll2 r9
    c.r[1] = c.r[10];  // 0605076A mov r10,r1
    c.r[1] |= c.r[9];  // 0605076C or r9,r1
    st16(c.r[13], c.r[1]);  // 0605076E mov.w r1,@r13
L_06050770:
    c.r[12] += 1;  // 06050770 add #1,r12
    c.r[1] = 0x49u;  // 06050772 mov #73,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06050774 cmp/gt r1,r12
    { const bool k = !c.t; c.r[11] += 16; if (k) { SH2_POLL(c); goto L_060506F2; } }  // 06050776 bf/s 0x060506F2 ; add #16,r11
    c.r[14] += 4;  // 0605077A add #4,r14
    c.r[15] = c.r[14];  // 0605077C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605077E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050780 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06050782 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06050784 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06050786 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050788 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605078A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605078C rts ; mov.l @r15+,r8
}

void f_060507B0(SH2Context& c) {
    ran[1281] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060507B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060507B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060507B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060507B6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060507B8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060507BA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060507BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060507BE sts.l pr,@-r15
    c.r[15] -= 4;  // 060507C0 add #-4,r15
    c.r[14] = c.r[15];  // 060507C2 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060507C4 extu.b r4,r4
    c.r[1] = ld32(0x060508B8u);  // 060507C6 mov.l 0x060508B8,r1
    c.r[1] += 22;  // 060507C8 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060507CA mov.w @r1,r1
    c.t = (c.r[5] & c.r[5]) == 0;  // 060507CC tst r5,r5
    c.r[1] += c.r[4];  // 060507CE add r4,r1
    c.r[1] += 1;  // 060507D0 add #1,r1
    { const bool k = !c.t; c.r[2] = c.r[1] & 0xFFFFu; if (k) { goto L_06050880; } }  // 060507D2 bf/s 0x06050880 ; extu.w r1,r2
    c.t = (c.r[6] & c.r[6]) == 0;  // 060507D6 tst r6,r6
    { const bool k = !c.t; c.r[12] = c.r[2]; if (k) { goto L_06050880; } }  // 060507D8 bf/s 0x06050880 ; mov r2,r12
    c.r[0] = ld32(0x060508BCu);  // 060507DC mov.l 0x060508BC,r0
    c.r[12] += c.r[12];  // 060507DE add r12,r12
    c.r[12] += c.r[2];  // 060507E0 add r2,r12
    c.r[12] <<= 2;  // 060507E2 shll2 r12
    c.r[0] = ld32(c.r[0] + 12);  // 060507E4 mov.l @(12,r0),r0
    c.r[1] = ld32(0x060508C0u);  // 060507E6 mov.l 0x060508C0,r1
    st32(c.r[14], c.r[0]);  // 060507E8 mov.l r0,@r14
    c.r[2] = ld32(c.r[1]);  // 060507EA mov.l @r1,r2
    c.r[13] = ld32(0x060508C4u);  // 060507EC mov.l 0x060508C4,r13
    c.r[1] = c.r[4];  // 060507EE mov r4,r1
    c.r[1] <<= 2;  // 060507F0 shll2 r1
    c.r[1] <<= 2;  // 060507F2 shll2 r1
    c.r[10] = c.r[1];  // 060507F4 mov r1,r10
    c.r[0] = c.r[1];  // 060507F6 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060507F8 mov.b @(r0,r2),r4
    c.r[10] += c.r[2];  // 060507FA add r2,r10
    c.r[4] = c.r[4] & 0xFFu;  // 060507FC extu.b r4,r4
    c.r[1] = c.r[13];  // 060507FE mov r13,r1
    c.r[1] += 78;  // 06050800 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050802 mov.b @r1,r1
    c.r[0] = ld32(0x060508C8u);  // 06050804 mov.l 0x060508C8,r0
    c.r[4] -= c.r[1];  // 06050806 sub r1,r4
    c.r[4] <<= 2;  // 06050808 shll2 r4
    c.r[4] <<= 2;  // 0605080A shll2 r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060508B4u);  // 0605080C mov.w 0x060508B4,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06050812u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050812u) return; }  // 0605080E jsr @r0 ; add r1,r4
    c.r[4] = c.r[0];  // 06050812 mov r0,r4
    c.r[5] = c.r[1];  // 06050814 mov r1,r5
    c.r[1] = ld32(0x060508CCu);  // 06050816 mov.l 0x060508CC,r1
    c.r[8] = ld32(c.r[1]);  // 06050818 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0605081A mov.l @(4,r1),r9
    c.r[0] = ld32(0x060508D0u);  // 0605081C mov.l 0x060508D0,r0
    c.r[6] = c.r[8];  // 0605081E mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06050824u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050824u) return; }  // 06050820 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 06050824 mov r0,r4
    c.r[5] = c.r[1];  // 06050826 mov r1,r5
    c.r[0] = ld32(0x060508D4u);  // 06050828 mov.l 0x060508D4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605082Eu; c.r[13] += 79; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605082Eu) return; }  // 0605082A jsr @r0 ; add #79,r13
    c.r[1] = c.r[0];  // 0605082E mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 06050830 mov.l @r14,r0
    st32(c.r[0] + c.r[12], c.r[1]);  // 06050832 mov.l r1,@(r0,r12)
    c.r[0] = ld32(0x060508BCu);  // 06050834 mov.l 0x060508BC,r0
    c.r[1] = c.r[10];  // 06050836 mov r10,r1
    c.r[11] = ld32(c.r[0] + 12);  // 06050838 mov.l @(12,r0),r11
    c.r[1] += 1;  // 0605083A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605083C mov.b @r1,r4
    c.r[11] += c.r[12];  // 0605083E add r12,r11
    c.r[4] = c.r[4] & 0xFFu;  // 06050840 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06050842 mov.b @r13,r1
    c.r[0] = ld32(0x060508C8u);  // 06050844 mov.l 0x060508C8,r0
    c.r[4] -= c.r[1];  // 06050846 sub r1,r4
    c.r[4] <<= 2;  // 06050848 shll2 r4
    c.r[4] <<= 2;  // 0605084A shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x06050850u; c.r[4] -= 105; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050850u) return; }  // 0605084C jsr @r0 ; add #-105,r4
    c.r[4] = c.r[0];  // 06050850 mov r0,r4
    c.r[5] = c.r[1];  // 06050852 mov r1,r5
    c.r[6] = c.r[8];  // 06050854 mov r8,r6
    c.r[0] = ld32(0x060508D0u);  // 06050856 mov.l 0x060508D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605085Cu; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605085Cu) return; }  // 06050858 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0605085C mov r0,r4
    c.r[5] = c.r[1];  // 0605085E mov r1,r5
    c.r[0] = ld32(0x060508D4u);  // 06050860 mov.l 0x060508D4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06050866u; c.r[10] += 3; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050866u) return; }  // 06050862 jsr @r0 ; add #3,r10
    c.r[2] = c.r[0];  // 06050866 mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06050868 mov.b @r10,r1
    c.r[0] = 0x3u;  // 0605086A mov #3,r0
    c.r[1] >>= 2;  // 0605086C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605086E shlr r1
    c.r[1] &= c.r[0];  // 06050870 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06050872 tst r1,r1
    if (!c.t) { goto L_0605087C; }  // 06050874 bf 0x0605087C
    c.r[0] = ld32(0x060508B8u);  // 06050876 mov.l 0x060508B8,r0
    c.r[1] = ld32(c.r[0] + 4);  // 06050878 mov.l @(4,r0),r1
    c.r[2] += c.r[1];  // 0605087A add r1,r2
L_0605087C:
    st32(c.r[11] + 4, c.r[2]); goto L_0605089E;  // 0605087C bra 0x0605089E ; mov.l r2,@(4,r11)
L_06050880:
    c.r[7] = ld32(0x060508BCu);  // 06050880 mov.l 0x060508BC,r7
    c.r[1] = c.r[2];  // 06050882 mov r2,r1
    c.r[1] += c.r[1];  // 06050884 add r1,r1
    c.r[1] += c.r[2];  // 06050886 add r2,r1
    c.r[1] <<= 2;  // 06050888 shll2 r1
    c.r[3] = ld32(c.r[7] + 12);  // 0605088A mov.l @(12,r7),r3
    c.r[0] = c.r[1];  // 0605088C mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 0605088E mov.l @(r0,r3),r2
    c.r[2] += c.r[5];  // 06050890 add r5,r2
    st32(c.r[0] + c.r[3], c.r[2]);  // 06050892 mov.l r2,@(r0,r3)
    c.r[2] = ld32(c.r[7] + 12);  // 06050894 mov.l @(12,r7),r2
    c.r[2] += c.r[1];  // 06050896 add r1,r2
    c.r[1] = ld32(c.r[2] + 4);  // 06050898 mov.l @(4,r2),r1
    c.r[1] += c.r[6];  // 0605089A add r6,r1
    st32(c.r[2] + 4, c.r[1]);  // 0605089C mov.l r1,@(4,r2)
L_0605089E:
    c.r[14] += 4;  // 0605089E add #4,r14
    c.r[15] = c.r[14];  // 060508A0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060508A2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060508A4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060508A6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060508A8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060508AA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060508AC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060508AE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060508B0 rts ; mov.l @r15+,r8
}

void f_060508D8(SH2Context& c) {
    ran[1282] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060508D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060508DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060508DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060508DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060508E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060508E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060508E4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060508E6 mov r15,r14
    c.r[11] = c.r[4];  // 060508E8 mov r4,r11
    c.r[10] = c.r[5];  // 060508EA mov r5,r10
    c.r[8] = 0x0u;  // 060508EC mov #0,r8
    c.r[12] = ld32(0x06050928u);  // 060508EE mov.l 0x06050928,r12
    c.r[9] = 0x0u;  // 060508F0 mov #0,r9
L_060508F2:
    c.r[1] = ld32(0x0605092Cu);  // 060508F2 mov.l 0x0605092C,r1
    c.r[0] = ld32(c.r[1]);  // 060508F4 mov.l @r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060508F6 mov.b @(r0,r9),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06050924u);  // 060508F8 mov.w 0x06050924,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060508FA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060508FC cmp/eq r2,r1
    { const bool k = c.t; c.r[4] = c.r[8] & 0xFFu; if (k) { goto L_06050908; } }  // 060508FE bt/s 0x06050908 ; extu.b r8,r4
    c.r[6] = c.r[10];  // 06050902 mov r10,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06050908u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050908u) return; }  // 06050904 jsr @r12 ; mov r11,r5
L_06050908:
    c.r[8] += 1;  // 06050908 add #1,r8
    c.r[1] = 0x49u;  // 0605090A mov #73,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0605090C cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_060508F2; } }  // 0605090E bf/s 0x060508F2 ; add #16,r9
    c.r[15] = c.r[14];  // 06050912 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06050914 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050916 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06050918 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605091A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605091C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605091E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050920 rts ; mov.l @r15+,r8
}

void f_06050930(SH2Context& c) {
    ran[1283] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050930 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06050932 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06050934 extu.b r4,r4
    c.r[6] = ld32(0x06050964u);  // 06050936 mov.l 0x06050964,r6
    c.r[1] = ld32(0x06050968u);  // 06050938 mov.l 0x06050968,r1
    c.r[3] = c.r[4];  // 0605093A mov r4,r3
    c.r[3] <<= 2;  // 0605093C shll2 r3
    c.r[3] <<= 2;  // 0605093E shll2 r3
    c.r[7] = ld32(c.r[1]);  // 06050940 mov.l @r1,r7
    c.r[0] = c.r[3];  // 06050942 mov r3,r0
    c.r[1] = c.r[3];  // 06050944 mov r3,r1
    c.r[1] += c.r[7];  // 06050946 add r7,r1
    c.r[1] += 1;  // 06050948 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605094A mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605094C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605094E mov.b @(r0,r7),r1
    c.r[2] <<= 2;  // 06050950 shll2 r2
    c.r[2] <<= 2;  // 06050952 shll2 r2
    c.r[2] <<= 2;  // 06050954 shll2 r2
    c.r[3] = ld32(c.r[6]);  // 06050956 mov.l @r6,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06050958 extu.b r1,r1
    c.r[2] += c.r[3];  // 0605095A add r3,r2
    c.r[0] = c.r[2];  // 0605095C mov r2,r0
    st8(c.r[0] + c.r[1], c.r[4]);  // 0605095E mov.b r4,@(r0,r1)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050960 rts ; mov.l @r15+,r14
}

void f_0605096C(SH2Context& c) {
    ran[1284] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605096C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605096E mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06050970 mov r15,r14
    c.r[6] = 0x0u;  // 06050972 mov #0,r6
    c.r[5] = 0x3Fu;  // 06050974 mov #63,r5
    c.r[7] = ld32(0x060509F0u);  // 06050976 mov.l 0x060509F0,r7
    c.r[3] = 0xFFFFFFFFu;  // 06050978 mov #-1,r3
    c.r[2] = 0x0u;  // 0605097A mov #0,r2
L_0605097C:
    c.r[1] = 0x0u;  // 0605097C mov #0,r1
L_0605097E:
    c.r[0] = ld32(c.r[7]);  // 0605097E mov.l @r7,r0
    c.r[0] += c.r[2];  // 06050980 add r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 06050982 mov.b r3,@(r0,r1)
    c.r[1] += 1;  // 06050984 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5];  // 06050986 cmp/gt r5,r1
    if (!c.t) { SH2_POLL(c); goto L_0605097E; }  // 06050988 bf 0x0605097E
    c.r[6] += 1;  // 0605098A add #1,r6
    c.r[1] = 0x3Fu;  // 0605098C mov #63,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0605098E cmp/gt r1,r6
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_0605097C; } }  // 06050990 bf/s 0x0605097C ; add #64,r2
    c.r[6] = 0x0u;  // 06050994 mov #0,r6
    c.r[8] = (uint32_t)(int16_t)ld16(0x060509ECu);  // 06050996 mov.w 0x060509EC,r8
    c.r[4] = ld32(0x060509F0u);  // 06050998 mov.l 0x060509F0,r4
    c.r[5] = 0x0u;  // 0605099A mov #0,r5
L_0605099C:
    c.r[1] = ld32(0x060509F4u);  // 0605099C mov.l 0x060509F4,r1
    c.r[2] = c.r[5];  // 0605099E mov r5,r2
    c.r[3] = ld32(c.r[1]);  // 060509A0 mov.l @r1,r3
    c.r[0] = c.r[5];  // 060509A2 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060509A4 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060509A6 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 060509A8 cmp/eq r8,r1
    { const bool k = c.t; c.r[2] += c.r[3]; if (k) { goto L_060509DA; } }  // 060509AA bt/s 0x060509DA ; add r3,r2
    c.r[2] = ld32(c.r[2] + 4);  // 060509AE mov.l @(4,r2),r2
    c.r[1] = ld32(0x060509F8u);  // 060509B0 mov.l 0x060509F8,r1
    c.r[2] &= c.r[1];  // 060509B2 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060509B4 tst r2,r2
    { const bool k = !c.t; c.r[2] = c.r[6] & 0xFFu; if (k) { goto L_060509DA; } }  // 060509B6 bf/s 0x060509DA ; extu.b r6,r2
    c.r[0] = c.r[2];  // 060509BA mov r2,r0
    c.r[0] <<= 2;  // 060509BC shll2 r0
    c.r[0] <<= 2;  // 060509BE shll2 r0
    c.r[1] = c.r[0];  // 060509C0 mov r0,r1
    c.r[1] += c.r[3];  // 060509C2 add r3,r1
    c.r[1] += 1;  // 060509C4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060509C6 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 060509C8 extu.b r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060509CA mov.b @(r0,r3),r1
    c.r[0] = c.r[1] & 0xFFu;  // 060509CC extu.b r1,r0
    c.r[1] = ld32(c.r[4]);  // 060509CE mov.l @r4,r1
    c.r[7] <<= 2;  // 060509D0 shll2 r7
    c.r[7] <<= 2;  // 060509D2 shll2 r7
    c.r[7] <<= 2;  // 060509D4 shll2 r7
    c.r[7] += c.r[1];  // 060509D6 add r1,r7
    st8(c.r[0] + c.r[7], c.r[2]);  // 060509D8 mov.b r2,@(r0,r7)
L_060509DA:
    c.r[6] += 1;  // 060509DA add #1,r6
    c.r[1] = 0x49u;  // 060509DC mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 060509DE cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_0605099C; } }  // 060509E0 bf/s 0x0605099C ; add #16,r5
    c.r[15] = c.r[14];  // 060509E4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060509E6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060509E8 rts ; mov.l @r15+,r8
}

void f_060509FC(SH2Context& c) {
    ran[1285] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060509FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060509FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06050A00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06050A02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050A04 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06050A06 mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06050A08 extu.b r4,r9
    c.r[5] = 0x0u;  // 06050A0A mov #0,r5
    c.r[1] = ld32(0x06050AA0u);  // 06050A0C mov.l 0x06050AA0,r1
    c.r[8] = ld32(c.r[1]);  // 06050A0E mov.l @r1,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06050A9Au);  // 06050A10 mov.w 0x06050A9A,r10
    c.r[4] = 0x0u;  // 06050A12 mov #0,r4
    c.r[6] = c.r[8];  // 06050A14 mov r8,r6
L_06050A16:
    c.r[0] = c.r[4];  // 06050A16 mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06050A18 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06050A1A extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06050A1C cmp/eq r10,r1
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06050A76; } }  // 06050A1E bt/s 0x06050A76 ; mov r6,r1
    c.r[1] += 7;  // 06050A22 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050A24 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06050A26 mov r1,r0
    c.r[0] >>= 2;  // 06050A28 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06050A2A shlr r0
    c.r[0] &= 0x1u;  // 06050A2C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06050A2E tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06050A76; } }  // 06050A30 bf/s 0x06050A76 ; mov r6,r1
    c.r[1] += 2;  // 06050A34 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050A36 mov.b @r1,r2
    c.r[1] = ld32(0x06050AA4u);  // 06050A38 mov.l 0x06050AA4,r1
    c.r[3] = ld32(c.r[1]);  // 06050A3A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06050A3C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06050A3E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06050A40 mul.l r1,r2
    c.r[1] = c.macl;  // 06050A42 sts macl,r1
    c.r[1] += c.r[3];  // 06050A44 add r3,r1
    c.r[1] += 15;  // 06050A46 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050A48 mov.b @r1,r2
    c.r[3] = c.r[9];  // 06050A4A mov r9,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06050A4C extu.b r2,r2
    c.r[1] = ld32(0x06050AA8u);  // 06050A4E mov.l 0x06050AA8,r1
    c.r[11] = c.r[2];  // 06050A50 mov r2,r11
    c.r[11] += c.r[11];  // 06050A52 add r11,r11
    c.r[11] += c.r[2];  // 06050A54 add r2,r11
    c.r[11] <<= 2;  // 06050A56 shll2 r11
    c.r[7] = ld32(c.r[1]);  // 06050A58 mov.l @r1,r7
    c.r[3] += c.r[3];  // 06050A5A add r3,r3
    c.r[1] = ld32(0x06050AACu);  // 06050A5C mov.l 0x06050AAC,r1
    c.r[1] = ld32(c.r[1]);  // 06050A5E mov.l @r1,r1
    c.r[0] = c.r[11];  // 06050A60 mov r11,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06050A62 mov.w @(r0,r7),r2
    c.r[3] += c.r[1];  // 06050A64 add r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06050A9Cu);  // 06050A66 mov.w 0x06050A9C,r1
    c.r[0] = c.r[3];  // 06050A68 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06050A6A mov.w @(r0,r1),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06050A6C extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050A6E extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06050A70 cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_06050A84; } }  // 06050A72 bt/s 0x06050A84 ; mov r5,r0
L_06050A76:
    c.r[6] += 16;  // 06050A76 add #16,r6
    c.r[5] += 1;  // 06050A78 add #1,r5
    c.r[1] = 0x49u;  // 06050A7A mov #73,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 06050A7C cmp/gt r1,r5
    { const bool k = !c.t; c.r[4] += 16; if (k) { SH2_POLL(c); goto L_06050A16; } }  // 06050A7E bf/s 0x06050A16 ; add #16,r4
    c.r[0] = c.r[5];  // 06050A82 mov r5,r0
L_06050A84:
    c.t = c.r[0] == 0x4Au;  // 06050A84 cmp/eq #74,r0
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06050A8C; } }  // 06050A86 bt/s 0x06050A8C ; mov #-1,r0
    c.r[0] = c.r[5];  // 06050A8A mov r5,r0
L_06050A8C:
    c.r[15] = c.r[14];  // 06050A8C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050A8E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06050A90 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050A92 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050A94 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050A96 rts ; mov.l @r15+,r8
}

void f_06050AB0(SH2Context& c) {
    ran[1286] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050AB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050AB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050AB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06050AB6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050B1Au);  // 06050AB8 mov.w 0x06050B1A,r3
    c.r[15] += c.r[3];  // 06050ABA add r3,r15
    c.r[14] = c.r[15];  // 06050ABC mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06050ABE extu.b r4,r4
    c.r[9] = c.r[4];  // 06050AC0 mov r4,r9
    c.r[1] = ld32(0x06050B20u);  // 06050AC2 mov.l 0x06050B20,r1
    c.r[1] = ld32(c.r[1]);  // 06050AC4 mov.l @r1,r1
    c.r[4] <<= 2;  // 06050AC6 shll2 r4
    c.r[4] <<= 2;  // 06050AC8 shll2 r4
    c.r[4] += c.r[1];  // 06050ACA add r1,r4
    c.r[4] += 2;  // 06050ACC add #2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06050ACE mov.b @r4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06050B1Cu);  // 06050AD0 mov.w 0x06050B1C,r6
    c.r[8] = c.r[1] & 0xFFu;  // 06050AD2 extu.b r1,r8
    c.r[5] = c.r[8] & 0xFFu;  // 06050AD4 extu.b r8,r5
    c.r[1] = ld32(0x06050B24u);  // 06050AD6 mov.l 0x06050B24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06050ADCu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050ADCu) return; }  // 06050AD8 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x06050B28u);  // 06050ADC mov.l 0x06050B28,r1
    c.r[2] = ld32(c.r[1]);  // 06050ADE mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06050AE0 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06050AE2 mul.l r1,r8
    c.r[3] = c.macl;  // 06050AE4 sts macl,r3
    c.r[3] += c.r[2];  // 06050AE6 add r2,r3
    c.r[3] += 24;  // 06050AE8 add #24,r3
    c.r[1] = c.r[14];  // 06050AEA mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06050AEC mov.w @r3,r2
    c.r[1] += 28;  // 06050AEE add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06050AF0 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06050AF2 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050AF4 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06050AF6 cmp/eq r1,r2
    if (c.t) { goto L_06050B00; }  // 06050AF8 bt 0x06050B00
    c.r[8] = 0xFFFFFFFEu;  // 06050AFA mov #-2,r8
    goto L_06050B08;  // 06050AFC bra 0x06050B08 ; nop
L_06050B00:
    c.r[0] = ld32(0x06050B2Cu);  // 06050B00 mov.l 0x06050B2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06050B06u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050B06u) return; }  // 06050B02 jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0];  // 06050B06 mov r0,r8
L_06050B08:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050B1Eu);  // 06050B08 mov.w 0x06050B1E,r3
    c.r[14] += c.r[3];  // 06050B0A add r3,r14
    c.r[15] = c.r[14];  // 06050B0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06050B0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050B10 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050B12 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06050B14 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050B16 rts ; mov.l @r15+,r8
}

void f_06050B30(SH2Context& c) {
    ran[1287] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050B30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050B32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06050B34 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050B36 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06050B38 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050BD6u);  // 06050B3A mov.w 0x06050BD6,r3
    c.r[15] += c.r[3];  // 06050B3C add r3,r15
    c.r[14] = c.r[15];  // 06050B3E mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06050B40 extu.b r4,r9
    c.r[10] = 0xFFFFFFFFu;  // 06050B42 mov #-1,r10
    c.r[1] = ld32(0x06050BDCu);  // 06050B44 mov.l 0x06050BDC,r1
    c.r[5] = c.r[14];  // 06050B46 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06050B4Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050B4Cu) return; }  // 06050B48 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x06050BE0u);  // 06050B4C mov.l 0x06050BE0,r1
    c.r[2] = c.r[9];  // 06050B4E mov r9,r2
    c.r[2] <<= 2;  // 06050B50 shll2 r2
    c.r[2] <<= 2;  // 06050B52 shll2 r2
    c.r[8] = c.r[14];  // 06050B54 mov r14,r8
    c.r[8] += 16;  // 06050B56 add #16,r8
    c.r[6] = c.r[9];  // 06050B58 mov r9,r6
    c.r[1] = ld32(c.r[1]);  // 06050B5A mov.l @r1,r1
    c.r[4] = c.r[8];  // 06050B5C mov r8,r4
    c.r[2] += c.r[1];  // 06050B5E add r1,r2
    c.r[2] += 2;  // 06050B60 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06050B62 mov.b @r2,r5
    c.r[1] = ld32(0x06050BE4u);  // 06050B64 mov.l 0x06050BE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06050B6Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050B6Au) return; }  // 06050B66 jsr @r1 ; extu.b r5,r5
    c.r[3] = 0x0u;  // 06050B6A mov #0,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06050BD8u);  // 06050B6C mov.w 0x06050BD8,r6
L_06050B6E:
    c.r[1] = c.r[8];  // 06050B6E mov r8,r1
    c.r[1] += 44;  // 06050B70 add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06050B72 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050B74 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06050B76 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06050BB0; } }  // 06050B78 bt/s 0x06050BB0 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06050B7C mov.b @(r0,r3),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06050B7E extu.b r1,r7
    c.t = c.r[7] == c.r[6];  // 06050B80 cmp/eq r6,r7
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06050BB0; } }  // 06050B82 bt/s 0x06050BB0 ; mov r8,r1
    c.r[1] += 52;  // 06050B86 add #52,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06050B88 mov.w @r1,r2
    c.r[0] = c.r[9];  // 06050B8A mov r9,r0
    c.r[2] <<= 16;  // 06050B8C shll16 r2
    c.r[2] <<= 2;  // 06050B8E shll2 r2
    c.r[2] += c.r[2];  // 06050B90 add r2,r2
    c.r[2] <<= 2;  // 06050B92 shll2 r2
    c.r[1] = ld32(0x06050BE8u);  // 06050B94 mov.l 0x06050BE8,r1
    c.r[1] = ld32(c.r[1]);  // 06050B96 mov.l @r1,r1
    c.r[0] <<= 2;  // 06050B98 shll2 r0
    c.r[0] <<= 2;  // 06050B9A shll2 r0
    c.r[0] += c.r[1];  // 06050B9C add r1,r0
    c.r[0] += 40;  // 06050B9E add #40,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06050BA0 mov.b @(r0,r7),r1
    c.r[2] >>= 16;  // 06050BA2 shlr16 r2
    c.r[2] <<= 2;  // 06050BA4 shll2 r2
    c.r[2] >>= 8;  // 06050BA6 shlr8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06050BA8 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06050BAA cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06050BBC; } }  // 06050BAC bf/s 0x06050BBC ; mov r3,r0
L_06050BB0:
    c.r[3] += 1;  // 06050BB0 add #1,r3
    c.r[1] = 0xFu;  // 06050BB2 mov #15,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06050BB4 cmp/gt r1,r3
    { const bool k = !c.t; c.r[8] += 20; if (k) { SH2_POLL(c); goto L_06050B6E; } }  // 06050BB6 bf/s 0x06050B6E ; add #20,r8
    c.r[0] = c.r[3];  // 06050BBA mov r3,r0
L_06050BBC:
    c.t = c.r[0] == 0x10u;  // 06050BBC cmp/eq #16,r0
    if (c.t) { goto L_06050BC2; }  // 06050BBE bt 0x06050BC2
    c.r[10] = c.r[3];  // 06050BC0 mov r3,r10
L_06050BC2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050BDAu);  // 06050BC2 mov.w 0x06050BDA,r3
    c.r[14] += c.r[3];  // 06050BC4 add r3,r14
    c.r[15] = c.r[14];  // 06050BC6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06050BC8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050BCA mov.l @r15+,r14
    c.r[0] = c.r[10];  // 06050BCC mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050BCE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050BD0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050BD2 rts ; mov.l @r15+,r8
}

void f_06050BEC(SH2Context& c) {
    ran[1288] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050BEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050BEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050BF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06050BF2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050C62u);  // 06050BF4 mov.w 0x06050C62,r3
    c.r[15] += c.r[3];  // 06050BF6 add r3,r15
    c.r[14] = c.r[15];  // 06050BF8 mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06050BFA extu.b r4,r9
    c.r[1] = ld32(0x06050C68u);  // 06050BFC mov.l 0x06050C68,r1
    c.r[5] = c.r[14];  // 06050BFE mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06050C04u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050C04u) return; }  // 06050C00 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x06050C6Cu);  // 06050C04 mov.l 0x06050C6C,r1
    c.r[2] = c.r[9];  // 06050C06 mov r9,r2
    c.r[2] <<= 2;  // 06050C08 shll2 r2
    c.r[2] <<= 2;  // 06050C0A shll2 r2
    c.r[8] = c.r[14];  // 06050C0C mov r14,r8
    c.r[8] += 16;  // 06050C0E add #16,r8
    c.r[6] = c.r[9];  // 06050C10 mov r9,r6
    c.r[1] = ld32(c.r[1]);  // 06050C12 mov.l @r1,r1
    c.r[4] = c.r[8];  // 06050C14 mov r8,r4
    c.r[2] += c.r[1];  // 06050C16 add r1,r2
    c.r[2] += 2;  // 06050C18 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06050C1A mov.b @r2,r5
    c.r[1] = ld32(0x06050C70u);  // 06050C1C mov.l 0x06050C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06050C22u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050C22u) return; }  // 06050C1E jsr @r1 ; extu.b r5,r5
    c.r[2] = 0x0u;  // 06050C22 mov #0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06050C64u);  // 06050C24 mov.w 0x06050C64,r6
    c.r[7] = ld32(0x06050C74u);  // 06050C26 mov.l 0x06050C74,r7
L_06050C28:
    c.r[0] = c.r[14];  // 06050C28 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06050C2A mov.b @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06050C2C extu.b r1,r3
    c.t = c.r[3] == c.r[6];  // 06050C2E cmp/eq r6,r3
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_06050C48; } }  // 06050C30 bt/s 0x06050C48 ; mov r9,r0
    c.r[1] = ld32(c.r[7]);  // 06050C34 mov.l @r7,r1
    c.r[0] <<= 2;  // 06050C36 shll2 r0
    c.r[0] <<= 2;  // 06050C38 shll2 r0
    c.r[0] += c.r[1];  // 06050C3A add r1,r0
    c.r[1] = c.r[8];  // 06050C3C mov r8,r1
    c.r[1] += 52;  // 06050C3E add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06050C40 mov.w @r1,r1
    c.r[0] += 40;  // 06050C42 add #40,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06050C44 shlr r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06050C46 mov.b r1,@(r0,r3)
L_06050C48:
    c.r[2] += 1;  // 06050C48 add #1,r2
    c.r[1] = 0xFu;  // 06050C4A mov #15,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06050C4C cmp/gt r1,r2
    { const bool k = !c.t; c.r[8] += 20; if (k) { SH2_POLL(c); goto L_06050C28; } }  // 06050C4E bf/s 0x06050C28 ; add #20,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050C66u);  // 06050C52 mov.w 0x06050C66,r3
    c.r[14] += c.r[3];  // 06050C54 add r3,r14
    c.r[15] = c.r[14];  // 06050C56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06050C58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050C5A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050C5C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050C5E rts ; mov.l @r15+,r8
}

void f_06050C78(SH2Context& c) {
    ran[1289] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050C78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050C7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06050C7C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06050C7E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06050C80 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06050C82 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050C84 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06050C86 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050D76u);  // 06050C88 mov.w 0x06050D76,r3
    c.r[15] += c.r[3];  // 06050C8A add r3,r15
    c.r[14] = c.r[15];  // 06050C8C mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06050C8E extu.b r4,r9
    c.r[10] = c.r[5] & 0xFFu;  // 06050C90 extu.b r5,r10
    c.r[0] = c.r[10];  // 06050C92 mov r10,r0
    c.r[0] &= 0x80u;  // 06050C94 and #128,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x06050D78u);  // 06050C96 mov.w 0x06050D78,r7
    c.r[7] += c.r[14];  // 06050C98 add r14,r7
    st32(c.r[7], c.r[0]);  // 06050C9A mov.l r0,@r7
    c.r[0] = 0x7Fu;  // 06050C9C mov #127,r0
    c.r[10] &= c.r[0];  // 06050C9E and r0,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06050D7Au);  // 06050CA0 mov.w 0x06050D7A,r8
    c.r[8] &= c.r[9];  // 06050CA2 and r9,r8
    c.r[9] &= c.r[0];  // 06050CA4 and r0,r9
    c.r[1] = ld32(0x06050D84u);  // 06050CA6 mov.l 0x06050D84,r1
    c.r[12] = c.r[9];  // 06050CA8 mov r9,r12
    c.r[12] <<= 2;  // 06050CAA shll2 r12
    c.r[12] <<= 2;  // 06050CAC shll2 r12
    c.r[1] = ld32(c.r[1]);  // 06050CAE mov.l @r1,r1
    c.r[6] = c.r[9];  // 06050CB0 mov r9,r6
    c.r[1] += c.r[12];  // 06050CB2 add r12,r1
    c.r[1] += 2;  // 06050CB4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050CB6 mov.b @r1,r1
    c.r[4] = c.r[14];  // 06050CB8 mov r14,r4
    c.r[13] = c.r[1] & 0xFFu;  // 06050CBA extu.b r1,r13
    c.r[1] = ld32(0x06050D88u);  // 06050CBC mov.l 0x06050D88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06050CC2u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050CC2u) return; }  // 06050CBE jsr @r1 ; mov r13,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x06050D7Cu);  // 06050CC2 mov.w 0x06050D7C,r11
    c.r[11] += c.r[14];  // 06050CC4 add r14,r11
    c.r[1] = ld32(0x06050D8Cu);  // 06050CC6 mov.l 0x06050D8C,r1
    c.r[5] = c.r[11];  // 06050CC8 mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06050CCEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050CCEu) return; }  // 06050CCA jsr @r1 ; mov r9,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 06050CCE tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_06050D18; } }  // 06050CD0 bt/s 0x06050D18 ; mov r11,r0
    c.r[0] = c.r[10];  // 06050CD4 mov r10,r0
    c.r[0] <<= 2;  // 06050CD6 shll2 r0
    c.r[0] += c.r[10];  // 06050CD8 add r10,r0
    c.r[0] <<= 2;  // 06050CDA shll2 r0
    c.r[1] = c.r[14];  // 06050CDC mov r14,r1
    c.r[1] += 44;  // 06050CDE add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06050CE0 mov.w @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06050D7Eu);  // 06050CE2 mov.w 0x06050D7E,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06050CE4 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06050CE6 cmp/eq r2,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06050D5E; } }  // 06050CE8 bf/s 0x06050D5E ; mov #0,r3
    c.r[6] = c.r[11];  // 06050CEC mov r11,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x06050D80u);  // 06050CEE mov.w 0x06050D80,r4
    c.r[5] = ld32(0x06050D90u);  // 06050CF0 mov.l 0x06050D90,r5
    c.r[9] = c.r[12];  // 06050CF2 mov r12,r9
    c.r[0] = c.r[6];  // 06050CF4 mov r6,r0
L_06050CF6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06050CF6 mov.b @(r0,r3),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06050CF8 extu.b r1,r8
    c.t = c.r[8] == c.r[4];  // 06050CFA cmp/eq r4,r8
    if (c.t) { goto L_06050D0A; }  // 06050CFC bt 0x06050D0A
    c.r[2] = ld32(c.r[5]);  // 06050CFE mov.l @r5,r2
    c.r[1] = 0x0u;  // 06050D00 mov #0,r1
    c.r[2] += c.r[9];  // 06050D02 add r9,r2
    c.r[2] += 40;  // 06050D04 add #40,r2
    c.r[0] = c.r[2];  // 06050D06 mov r2,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 06050D08 mov.b r1,@(r0,r8)
L_06050D0A:
    c.r[3] += 1;  // 06050D0A add #1,r3
    c.r[1] = 0xFu;  // 06050D0C mov #15,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06050D0E cmp/gt r1,r3
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { SH2_POLL(c); goto L_06050CF6; } }  // 06050D10 bf/s 0x06050CF6 ; mov r6,r0
    goto L_06050D5E;  // 06050D14 bra 0x06050D5E ; nop
L_06050D18:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06050D18 mov.b @(r0,r10),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06050D1A extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06050D80u);  // 06050D1C mov.w 0x06050D80,r1
    c.t = c.r[3] == c.r[1];  // 06050D1E cmp/eq r1,r3
    if (c.t) { goto L_06050D32; }  // 06050D20 bt 0x06050D32
    c.r[1] = ld32(0x06050D90u);  // 06050D22 mov.l 0x06050D90,r1
    c.r[2] = ld32(c.r[1]);  // 06050D24 mov.l @r1,r2
    c.r[2] += c.r[12];  // 06050D26 add r12,r2
    c.r[2] += 40;  // 06050D28 add #40,r2
    c.r[0] = c.r[2];  // 06050D2A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06050D2C mov.b @(r0,r3),r1
    c.r[1] -= 1;  // 06050D2E add #-1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06050D30 mov.b r1,@(r0,r3)
L_06050D32:
    c.r[7] = (uint32_t)(int16_t)ld16(0x06050D78u);  // 06050D32 mov.w 0x06050D78,r7
    c.r[7] += c.r[14];  // 06050D34 add r14,r7
    c.r[7] = ld32(c.r[7]);  // 06050D36 mov.l @r7,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06050D38 tst r7,r7
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_06050D5E; } }  // 06050D3A bf/s 0x06050D5E ; mov r10,r0
    c.r[1] = ld32(0x06050D94u);  // 06050D3E mov.l 0x06050D94,r1
    c.r[2] = ld32(c.r[1]);  // 06050D40 mov.l @r1,r2
    c.r[0] <<= 2;  // 06050D42 shll2 r0
    c.r[1] = 0x1Eu;  // 06050D44 mov #30,r1
    c.macl = c.r[13] * c.r[1];  // 06050D46 mul.l r1,r13
    c.r[0] += c.r[10];  // 06050D48 add r10,r0
    c.r[0] <<= 2;  // 06050D4A shll2 r0
    c.r[3] = c.macl;  // 06050D4C sts macl,r3
    c.r[3] += c.r[2];  // 06050D4E add r2,r3
    c.r[3] += 24;  // 06050D50 add #24,r3
    c.r[2] = c.r[14];  // 06050D52 mov r14,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06050D54 mov.w @r3,r1
    c.r[2] += 54;  // 06050D56 add #54,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06050D58 mov.w @(r0,r2),r2
    c.r[1] -= c.r[2];  // 06050D5A sub r2,r1
    st16(c.r[3], c.r[1]);  // 06050D5C mov.w r1,@r3
L_06050D5E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06050D82u);  // 06050D5E mov.w 0x06050D82,r3
    c.r[14] += c.r[3];  // 06050D60 add r3,r14
    c.r[15] = c.r[14];  // 06050D62 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06050D64 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06050D66 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06050D68 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06050D6A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06050D6C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06050D6E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06050D70 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06050D72 rts ; mov.l @r15+,r8
}

void f_06050D98(SH2Context& c) {
    ran[1290] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06050D98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06050D9A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06050D9C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06050D9E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06050DA0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06050DA2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06050DA4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06050DA6 sts.l pr,@-r15
    c.r[15] -= 24;  // 06050DA8 add #-24,r15
    c.r[14] = c.r[15];  // 06050DAA mov r15,r14
    st32(c.r[14] + 8, c.r[5]);  // 06050DAC mov.l r5,@(8,r14)
    c.r[0] = 0x40u;  // 06050DAE mov #64,r0
    c.r[0] += c.r[14];  // 06050DB0 add r14,r0
    c.r[4] = c.r[4] & 0xFFu;  // 06050DB2 extu.b r4,r4
    c.r[2] = ld32(c.r[14] + 56);  // 06050DB4 mov.l @(56,r14),r2
    c.r[6] = c.r[6] & 0xFFu;  // 06050DB6 extu.b r6,r6
    c.r[3] = ld32(c.r[14] + 60);  // 06050DB8 mov.l @(60,r14),r3
    c.r[11] = c.r[7] & 0xFFu;  // 06050DBA extu.b r7,r11
    c.r[1] = ld32(c.r[0]);  // 06050DBC mov.l @r0,r1
    c.r[10] = c.r[2] & 0xFFu;  // 06050DBE extu.b r2,r10
    c.r[13] = c.r[1] & 0xFFu;  // 06050DC0 extu.b r1,r13
    c.r[2] = c.r[11];  // 06050DC2 mov r11,r2
    c.r[2] += c.r[2];  // 06050DC4 add r2,r2
    c.r[1] = c.r[10];  // 06050DC6 mov r10,r1
    c.r[1] <<= 2;  // 06050DC8 shll2 r1
    c.r[1] <<= 2;  // 06050DCA shll2 r1
    c.r[1] += c.r[1];  // 06050DCC add r1,r1
    c.r[1] <<= 2;  // 06050DCE shll2 r1
    c.r[1] += c.r[3];  // 06050DD0 add r3,r1
    c.r[0] = c.r[2];  // 06050DD2 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06050DD4 mov.w @(r0,r1),r1
    st32(c.r[14] + 4, c.r[4]);  // 06050DD6 mov.l r4,@(4,r14)
    c.r[3] = c.r[1] & 0xFFFFu;  // 06050DD8 extu.w r1,r3
    c.r[0] = c.r[13];  // 06050DDA mov r13,r0
    c.r[0] &= 0x80u;  // 06050DDC and #128,r0
    st32(c.r[14] + 12, c.r[0]);  // 06050DDE mov.l r0,@(12,r14)
    c.r[0] = c.r[13];  // 06050DE0 mov r13,r0
    c.r[0] &= 0x40u;  // 06050DE2 and #64,r0
    st32(c.r[14] + 16, c.r[0]);  // 06050DE4 mov.l r0,@(16,r14)
    c.r[0] = 0xFu;  // 06050DE6 mov #15,r0
    c.r[2] = c.r[6];  // 06050DE8 mov r6,r2
    c.r[2] <<= 2;  // 06050DEA shll2 r2
    c.r[2] += c.r[6];  // 06050DEC add r6,r2
    c.r[2] <<= 2;  // 06050DEE shll2 r2
    c.r[2] += c.r[5];  // 06050DF0 add r5,r2
    c.r[1] = c.r[2];  // 06050DF2 mov r2,r1
    c.r[1] += 61;  // 06050DF4 add #61,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050DF6 mov.b @r1,r1
    c.r[13] &= c.r[0];  // 06050DF8 and r0,r13
    c.r[5] = c.r[1] & 0xFFu;  // 06050DFA extu.b r1,r5
    c.r[1] = c.r[2];  // 06050DFC mov r2,r1
    c.r[1] += 62;  // 06050DFE add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050E00 mov.b @r1,r1
    c.r[2] += 50;  // 06050E02 add #50,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06050E04 mov.b @r2,r2
    c.r[4] = c.r[1] & 0xFFu;  // 06050E06 extu.b r1,r4
    c.r[0] = c.r[2];  // 06050E08 mov r2,r0
    c.r[0] &= 0x3Fu;  // 06050E0A and #63,r0
    st32(c.r[14] + 20, c.r[0]);  // 06050E0C mov.l r0,@(20,r14)
    c.r[1] = ld32(0x06051014u);  // 06050E0E mov.l 0x06051014,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06050E10 mov.b @(r0,r1),r1
    c.r[12] = c.r[1] & 0xFFu;  // 06050E12 extu.b r1,r12
    c.r[1] = c.r[5] & 0xFFFFu;  // 06050E14 extu.w r5,r1
    c.t = c.r[1] > c.r[3];  // 06050E16 cmp/hi r3,r1
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06050E24; } }  // 06050E18 bt/s 0x06050E24 ; mov #0,r7
    c.r[1] = c.r[4] & 0xFFFFu;  // 06050E1C extu.w r4,r1
    c.t = c.r[1] >= c.r[3];  // 06050E1E cmp/hs r3,r1
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06050E66; } }  // 06050E20 bt/s 0x06050E66 ; mov r6,r1
L_06050E24:
    c.r[0] = c.r[13];  // 06050E24 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 06050E26 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_06050E38; } }  // 06050E28 bf/s 0x06050E38 ; mov r12,r0
    c.t = c.r[0] == 0x3u;  // 06050E2C cmp/eq #3,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06050E66; } }  // 06050E2E bt/s 0x06050E66 ; mov r6,r1
    c.t = c.r[0] == 0xCu;  // 06050E32 cmp/eq #12,r0
    { const bool k = c.t; c.r[1] <<= 2; if (k) { goto L_06050E68; } }  // 06050E34 bt/s 0x06050E68 ; shll2 r1
L_06050E38:
    c.r[0] = c.r[2] & 0xFFu;  // 06050E38 extu.b r2,r0
    c.r[0] >>= 2;  // 06050E3A shlr2 r0
    c.r[0] >>= 2;  // 06050E3C shlr2 r0
    c.r[0] >>= 2;  // 06050E3E shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06050E40 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_06050E4A; } }  // 06050E42 bt/s 0x06050E4A ; mov r12,r0
    goto L_06051658;  // 06050E46 bra 0x06051658 ; nop
L_06050E4A:
    c.t = c.r[0] == 0x8u;  // 06050E4A cmp/eq #8,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06050E66; } }  // 06050E4C bt/s 0x06050E66 ; mov r6,r1
    c.r[1] = c.r[12];  // 06050E50 mov r12,r1
    c.r[1] -= 10;  // 06050E52 add #-10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06050E54 extu.b r1,r1
    c.r[2] = 0x1u;  // 06050E56 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 06050E58 cmp/hi r2,r1
    { const bool k = !c.t; c.t = c.r[0] == 0xDu; if (k) { goto L_06050E64; } }  // 06050E5A bf/s 0x06050E64 ; cmp/eq #13,r0
    if (c.t) { goto L_06050E64; }  // 06050E5E bt 0x06050E64
    goto L_06051658;  // 06050E60 bra 0x06051658 ; nop
L_06050E64:
    c.r[1] = c.r[6];  // 06050E64 mov r6,r1
L_06050E66:
    c.r[1] <<= 2;  // 06050E66 shll2 r1
L_06050E68:
    c.r[1] += c.r[6];  // 06050E68 add r6,r1
    c.r[0] = ld32(c.r[14] + 8);  // 06050E6A mov.l @(8,r14),r0
    c.r[1] <<= 2;  // 06050E6C shll2 r1
    c.r[1] += c.r[0];  // 06050E6E add r0,r1
    c.r[1] += 50;  // 06050E70 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050E72 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06050E74 extu.b r1,r1
    c.r[1] >>= 2;  // 06050E76 shlr2 r1
    c.r[1] >>= 2;  // 06050E78 shlr2 r1
    c.r[1] >>= 2;  // 06050E7A shlr2 r1
    c.r[0] = c.r[1];  // 06050E7C mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06050E7E cmp/eq #2,r0
    if (c.t) { goto L_06050E86; }  // 06050E80 bt 0x06050E86
    goto L_06051656;  // 06050E82 bra 0x06051656 ; nop
L_06050E86:
    c.r[1] = ld32(0x06051018u);  // 06050E86 mov.l 0x06051018,r1
    c.r[2] = ld32(c.r[1]);  // 06050E88 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 06050E8A mov.l @(4,r14),r1
    c.r[1] <<= 2;  // 06050E8C shll2 r1
    c.r[1] <<= 2;  // 06050E8E shll2 r1
    c.r[3] = c.r[1];  // 06050E90 mov r1,r3
    c.r[3] += c.r[2];  // 06050E92 add r2,r3
    c.r[0] = c.r[1];  // 06050E94 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06050E96 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 06050E98 add #1,r3
    c.r[9] = c.r[1] & 0xFFu;  // 06050E9A extu.b r1,r9
    c.r[2] = c.r[12];  // 06050E9C mov r12,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06050E9E mov.b @r3,r1
    c.r[2] -= 2;  // 06050EA0 add #-2,r2
    c.r[8] = c.r[1] & 0xFFu;  // 06050EA2 extu.b r1,r8
    c.r[1] = 0xBu;  // 06050EA4 mov #11,r1
    c.t = c.r[2] > c.r[1];  // 06050EA6 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06050EB0; } }  // 06050EA8 bf/s 0x06050EB0 ; mov r2,r1
    goto L_060511CE;  // 06050EAC bra 0x060511CE ; nop
L_06050EB0:
    c.r[1] += c.r[1];  // 06050EB0 add r1,r1
    c.r[0] = 0x06050EBCu;  // 06050EB2 mova 0x06050EBC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06050EB4 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06050EB6 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06050ED4u: goto L_06050ED4; case 0x06050EE0u: goto L_06050EE0; case 0x06050F0Eu: goto L_06050F0E; case 0x06050F38u: goto L_06050F38; case 0x06050F4Eu: goto L_06050F4E; case 0x06050F84u: goto L_06050F84; case 0x06050FB6u: goto L_06050FB6; case 0x06051028u: goto L_06051028; case 0x06051064u: goto L_06051064; case 0x060510CCu: goto L_060510CC; case 0x06051182u: goto L_06051182; case 0x060511AEu: goto L_060511AE; default: sh2_call(c, x); return; } }  // 06050EB8 jmp @r0 ; nop
L_06050ED4:
    c.r[0] = c.r[13];  // 06050ED4 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 06050ED6 cmp/eq #2,r0
    { const bool k = c.t; c.r[7] = 0x1u; if (k) { goto L_06050F90; } }  // 06050ED8 bt/s 0x06050F90 ; mov #1,r7
    c.r[0] = c.r[7]; goto L_060511D2;  // 06050EDC bra 0x060511D2 ; mov r7,r0
L_06050EE0:
    c.r[0] = c.r[13];  // 06050EE0 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 06050EE2 cmp/eq #2,r0
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_06050EEC; } }  // 06050EE4 bt/s 0x06050EEC ; mov r11,r2
    goto L_060511CE;  // 06050EE8 bra 0x060511CE ; nop
L_06050EEC:
    c.r[1] = ld32(0x0605101Cu);  // 06050EEC mov.l 0x0605101C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050EEE mov.b @r1,r1
    c.r[2] -= c.r[1];  // 06050EF0 sub r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06050EF2 cmp/pz r2
    if (c.t) { goto L_06050EF8; }  // 06050EF4 bt 0x06050EF8
    c.r[2] = 0u - c.r[2];  // 06050EF6 neg r2,r2
L_06050EF8:
    c.r[1] = ld32(0x06051020u);  // 06050EF8 mov.l 0x06051020,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050EFA mov.b @r1,r1
    c.r[0] = c.r[10];  // 06050EFC mov r10,r0
    c.r[0] -= c.r[1];  // 06050EFE sub r1,r0
    c.r[1] = c.r[0];  // 06050F00 mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06050F02 cmp/pz r1
    if (c.t) { goto L_06050F08; }  // 06050F04 bt 0x06050F08
    c.r[1] = 0u - c.r[1];  // 06050F06 neg r1,r1
L_06050F08:
    c.r[2] += c.r[1];  // 06050F08 add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[13]; goto L_060511CA;  // 06050F0A bra 0x060511CA ; cmp/gt r13,r2
L_06050F0E:
    c.r[1] = c.r[11];  // 06050F0E mov r11,r1
    c.r[1] += 2;  // 06050F10 add #2,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06050F12 cmp/gt r1,r9
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06050F26; } }  // 06050F14 bt/s 0x06050F26 ; mov r10,r1
    c.r[1] = c.r[11];  // 06050F18 mov r11,r1
    c.r[1] -= 2;  // 06050F1A add #-2,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06050F1C cmp/ge r1,r9
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06050F26; } }  // 06050F1E bf/s 0x06050F26 ; mov r10,r1
    goto L_060511CE;  // 06050F22 bra 0x060511CE ; nop
L_06050F26:
    c.r[1] += 2;  // 06050F26 add #2,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06050F28 cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06050F32; } }  // 06050F2A bf/s 0x06050F32 ; mov r7,r0
    goto L_060511D2;  // 06050F2E bra 0x060511D2 ; nop
L_06050F32:
    c.r[1] = c.r[10];  // 06050F32 mov r10,r1
    c.r[1] -= 2; goto L_06050F76;  // 06050F34 bra 0x06050F76 ; add #-2,r1
L_06050F38:
    c.t = c.r[9] == c.r[11];  // 06050F38 cmp/eq r11,r9
    { const bool k = !c.t; c.t = c.r[8] == c.r[10]; if (k) { goto L_06050F42; } }  // 06050F3A bf/s 0x06050F42 ; cmp/eq r10,r8
    goto L_060511CE;  // 06050F3E bra 0x060511CE ; nop
L_06050F42:
    if (c.t) { goto L_06050F48; }  // 06050F42 bt 0x06050F48
    goto L_060511D0;  // 06050F44 bra 0x060511D0 ; nop
L_06050F48:
    c.r[7] = 0x1u;  // 06050F48 mov #1,r7
    c.r[0] = c.r[7]; goto L_060511D2;  // 06050F4A bra 0x060511D2 ; mov r7,r0
L_06050F4E:
    c.r[1] = c.r[11];  // 06050F4E mov r11,r1
    c.r[1] += 1;  // 06050F50 add #1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06050F52 cmp/gt r1,r9
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06050F66; } }  // 06050F54 bt/s 0x06050F66 ; mov r10,r1
    c.r[1] = c.r[11];  // 06050F58 mov r11,r1
    c.r[1] -= 1;  // 06050F5A add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06050F5C cmp/ge r1,r9
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06050F66; } }  // 06050F5E bf/s 0x06050F66 ; mov r10,r1
    goto L_060511CE;  // 06050F62 bra 0x060511CE ; nop
L_06050F66:
    c.r[1] += 1;  // 06050F66 add #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06050F68 cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06050F72; } }  // 06050F6A bf/s 0x06050F72 ; mov r7,r0
    goto L_060511D2;  // 06050F6E bra 0x060511D2 ; nop
L_06050F72:
    c.r[1] = c.r[10];  // 06050F72 mov r10,r1
    c.r[1] -= 1;  // 06050F74 add #-1,r1
L_06050F76:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06050F76 cmp/ge r1,r8
    if (c.t) { goto L_06050F7E; }  // 06050F78 bt 0x06050F7E
    goto L_060511D0;  // 06050F7A bra 0x060511D0 ; nop
L_06050F7E:
    c.r[7] = 0x1u;  // 06050F7E mov #1,r7
    c.r[0] = c.r[7]; goto L_060511D2;  // 06050F80 bra 0x060511D2 ; mov r7,r0
L_06050F84:
    c.r[0] = c.r[13];  // 06050F84 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 06050F86 cmp/eq #2,r0
    { const bool k = c.t; c.r[7] = 0x1u; if (k) { goto L_06050F90; } }  // 06050F88 bt/s 0x06050F90 ; mov #1,r7
    goto L_060511D0;  // 06050F8C bra 0x060511D0 ; nop
L_06050F90:
    st8(c.r[14], c.r[11]);  // 06050F90 mov.b r11,@r14
    c.r[2] = c.r[14];  // 06050F92 mov r14,r2
    c.r[2] += 1;  // 06050F94 add #1,r2
    st8(c.r[2], c.r[10]);  // 06050F96 mov.b r10,@r2
    c.r[1] = ld32(0x06051020u);  // 06050F98 mov.l 0x06051020,r1
    c.r[5] = c.r[8] & 0xFFu;  // 06050F9A extu.b r8,r5
    c.r[4] = c.r[9] & 0xFFu;  // 06050F9C extu.b r9,r4
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050F9E mov.b @r1,r7
    c.r[0] = ld32(0x06051024u);  // 06050FA0 mov.l 0x06051024,r0
    c.r[1] = ld32(0x0605101Cu);  // 06050FA2 mov.l 0x0605101C,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050FA4 mov.b @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06050FA6 extu.b r7,r7
    c.r[6] = c.r[6] & 0xFFu;  // 06050FA8 extu.b r6,r6
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06050FAA mov.l r2,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x06050FB0u; c.r[15] -= 4; st32(c.r[15], c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06050FB0u) return; }  // 06050FAC jsr @r0 ; mov.l r14,@-r15
    c.r[7] = c.r[0] & 0xFFu;  // 06050FB0 extu.b r0,r7
    c.r[15] += 8; goto L_060511D0;  // 06050FB2 bra 0x060511D0 ; add #8,r15
L_06050FB6:
    c.r[2] = c.r[9];  // 06050FB6 mov r9,r2
    c.r[2] -= c.r[11];  // 06050FB8 sub r11,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06050FBA cmp/pz r2
    if (c.t) { goto L_06050FC0; }  // 06050FBC bt 0x06050FC0
    c.r[2] = 0u - c.r[2];  // 06050FBE neg r2,r2
L_06050FC0:
    st8(c.r[14], c.r[2]);  // 06050FC0 mov.b r2,@r14
    c.r[3] = c.r[14];  // 06050FC2 mov r14,r3
    c.r[1] = c.r[8];  // 06050FC4 mov r8,r1
    c.r[1] -= c.r[10];  // 06050FC6 sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06050FC8 cmp/pz r1
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_06050FD0; } }  // 06050FCA bt/s 0x06050FD0 ; add #1,r3
    c.r[1] = 0u - c.r[1];  // 06050FCE neg r1,r1
L_06050FD0:
    st8(c.r[3], c.r[1]);  // 06050FD0 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 06050FD2 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06050FD4 extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 06050FD6 cmp/hs r1,r2
    { const bool k = !c.t; c.t = c.r[5] > c.r[2]; if (k) { goto L_06050FE8; } }  // 06050FD8 bf/s 0x06050FE8 ; cmp/hi r2,r5
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06050FEA; } }  // 06050FDC bt/s 0x06050FEA ; mov r14,r1
    c.t = c.r[4] >= c.r[2];  // 06050FE0 cmp/hs r2,r4
    if (!c.t) { goto L_06050FE8; }  // 06050FE2 bf 0x06050FE8
    goto L_060511CE;  // 06050FE4 bra 0x060511CE ; nop
L_06050FE8:
    c.r[1] = c.r[14];  // 06050FE8 mov r14,r1
L_06050FEA:
    c.r[1] += 1;  // 06050FEA add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06050FEC mov.b @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06050FEE mov.b @r14,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06050FF0 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06050FF2 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06050FF4 cmp/hi r1,r2
    { const bool k = c.t; c.t = c.r[5] > c.r[2]; if (k) { goto L_06050FFE; } }  // 06050FF6 bt/s 0x06050FFE ; cmp/hi r2,r5
    goto L_060511D0;  // 06050FFA bra 0x060511D0 ; nop
L_06050FFE:
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06051006; } }  // 06050FFE bf/s 0x06051006 ; mov r7,r0
    goto L_060511D2;  // 06051002 bra 0x060511D2 ; nop
L_06051006:
    c.t = c.r[4] >= c.r[2];  // 06051006 cmp/hs r2,r4
    if (c.t) { goto L_0605100E; }  // 06051008 bt 0x0605100E
    goto L_060511D0;  // 0605100A bra 0x060511D0 ; nop
L_0605100E:
    c.r[7] = 0x1u;  // 0605100E mov #1,r7
    c.r[0] = c.r[7]; goto L_060511D2;  // 06051010 bra 0x060511D2 ; mov r7,r0
L_06051028:
    c.r[1] = c.r[11];  // 06051028 mov r11,r1
    c.r[1] += 1;  // 0605102A add #1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605102C cmp/gt r1,r9
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_0605103E; } }  // 0605102E bt/s 0x0605103E ; mov r10,r1
    c.r[1] = c.r[11];  // 06051032 mov r11,r1
    c.r[1] -= 1;  // 06051034 add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06051036 cmp/ge r1,r9
    { const bool k = c.t; c.t = c.r[9] == c.r[11]; if (k) { goto L_06051058; } }  // 06051038 bt/s 0x06051058 ; cmp/eq r11,r9
    c.r[1] = c.r[10];  // 0605103C mov r10,r1
L_0605103E:
    c.r[1] += 1;  // 0605103E add #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06051040 cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_0605104A; } }  // 06051042 bf/s 0x0605104A ; mov r7,r0
    goto L_060511D2;  // 06051046 bra 0x060511D2 ; nop
L_0605104A:
    c.r[1] = c.r[10];  // 0605104A mov r10,r1
    c.r[1] -= 1;  // 0605104C add #-1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0605104E cmp/ge r1,r8
    { const bool k = c.t; c.t = c.r[9] == c.r[11]; if (k) { goto L_06051058; } }  // 06051050 bt/s 0x06051058 ; cmp/eq r11,r9
    goto L_060511D2;  // 06051054 bra 0x060511D2 ; nop
L_06051058:
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06051060; } }  // 06051058 bf/s 0x06051060 ; mov r7,r0
    goto L_060511D2;  // 0605105C bra 0x060511D2 ; nop
L_06051060:
    c.t = c.r[8] == c.r[10]; goto L_060511CA;  // 06051060 bra 0x060511CA ; cmp/eq r10,r8
L_06051064:
    c.r[1] = c.r[9];  // 06051064 mov r9,r1
    c.r[1] -= c.r[11];  // 06051066 sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051068 cmp/pz r1
    if (c.t) { goto L_0605106E; }  // 0605106A bt 0x0605106E
    c.r[1] = 0u - c.r[1];  // 0605106C neg r1,r1
L_0605106E:
    st8(c.r[14], c.r[1]);  // 0605106E mov.b r1,@r14
    c.r[3] = c.r[14];  // 06051070 mov r14,r3
    c.r[2] = c.r[8];  // 06051072 mov r8,r2
    c.r[2] -= c.r[10];  // 06051074 sub r10,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06051076 cmp/pz r2
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_0605107E; } }  // 06051078 bt/s 0x0605107E ; add #1,r3
    c.r[2] = 0u - c.r[2];  // 0605107C neg r2,r2
L_0605107E:
    st8(c.r[3], c.r[2]);  // 0605107E mov.b r2,@r3
    c.r[3] = c.r[1] & 0xFFu;  // 06051080 extu.b r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06051082 extu.b r2,r2
    c.t = c.r[3] >= c.r[2];  // 06051084 cmp/hs r2,r3
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0605109C; } }  // 06051086 bf/s 0x0605109C ; mov r3,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605108A shlr r1
    c.t = c.r[2] > c.r[1];  // 0605108C cmp/hi r1,r2
    { const bool k = c.t; c.t = c.r[3] >= c.r[5]; if (k) { goto L_0605109C; } }  // 0605108E bt/s 0x0605109C ; cmp/hs r5,r3
    { const bool k = !c.t; c.t = c.r[3] > c.r[4]; if (k) { goto L_0605109C; } }  // 06051092 bf/s 0x0605109C ; cmp/hi r4,r3
    if (c.t) { goto L_0605109C; }  // 06051096 bt 0x0605109C
    goto L_060511CE;  // 06051098 bra 0x060511CE ; nop
L_0605109C:
    c.r[1] = c.r[14];  // 0605109C mov r14,r1
    c.r[1] += 1;  // 0605109E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060510A0 mov.b @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060510A2 mov.b @r14,r2
    c.r[3] = c.r[1] & 0xFFu;  // 060510A4 extu.b r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060510A6 extu.b r2,r2
    c.t = c.r[3] > c.r[2];  // 060510A8 cmp/hi r2,r3
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060510B2; } }  // 060510AA bt/s 0x060510B2 ; mov r3,r1
    goto L_060511D0;  // 060510AE bra 0x060511D0 ; nop
L_060510B2:
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060510B2 shlr r1
    c.t = c.r[2] > c.r[1];  // 060510B4 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_060510BE; } }  // 060510B6 bf/s 0x060510BE ; mov r7,r0
    goto L_060511D2;  // 060510BA bra 0x060511D2 ; nop
L_060510BE:
    c.t = c.r[3] >= c.r[5];  // 060510BE cmp/hs r5,r3
    { const bool k = c.t; c.t = c.r[3] > c.r[4]; if (k) { goto L_060510C8; } }  // 060510C0 bt/s 0x060510C8 ; cmp/hi r4,r3
    goto L_060511D2;  // 060510C4 bra 0x060511D2 ; nop
L_060510C8:
    goto L_060511CA;  // 060510C8 bra 0x060511CA ; nop
L_060510CC:
    c.r[2] = c.r[9];  // 060510CC mov r9,r2
    c.r[2] -= c.r[11];  // 060510CE sub r11,r2
    c.t = (int32_t)c.r[2] >= 0;  // 060510D0 cmp/pz r2
    if (c.t) { goto L_060510D6; }  // 060510D2 bt 0x060510D6
    c.r[2] = 0u - c.r[2];  // 060510D4 neg r2,r2
L_060510D6:
    st8(c.r[14], c.r[2]);  // 060510D6 mov.b r2,@r14
    c.r[3] = c.r[14];  // 060510D8 mov r14,r3
    c.r[1] = c.r[8];  // 060510DA mov r8,r1
    c.r[1] -= c.r[10];  // 060510DC sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060510DE cmp/pz r1
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_060510E6; } }  // 060510E0 bt/s 0x060510E6 ; add #1,r3
    c.r[1] = 0u - c.r[1];  // 060510E4 neg r1,r1
L_060510E6:
    st8(c.r[3], c.r[1]);  // 060510E6 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 060510E8 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060510EA extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 060510EC cmp/hs r1,r2
    { const bool k = !c.t; c.t = c.r[5] > c.r[2]; if (k) { goto L_060510FC; } }  // 060510EE bf/s 0x060510FC ; cmp/hi r2,r5
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060510FE; } }  // 060510F2 bt/s 0x060510FE ; mov r14,r1
    c.t = c.r[4] >= c.r[2];  // 060510F6 cmp/hs r2,r4
    { const bool k = c.t; c.r[3] = c.r[14]; if (k) { goto L_06051118; } }  // 060510F8 bt/s 0x06051118 ; mov r14,r3
L_060510FC:
    c.r[1] = c.r[14];  // 060510FC mov r14,r1
L_060510FE:
    c.r[1] += 1;  // 060510FE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051100 mov.b @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06051102 mov.b @r14,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06051104 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06051106 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06051108 cmp/hi r1,r2
    { const bool k = !c.t; c.t = c.r[5] > c.r[2]; if (k) { goto L_060511D0; } }  // 0605110A bf/s 0x060511D0 ; cmp/hi r2,r5
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_060511D2; } }  // 0605110E bt/s 0x060511D2 ; mov r7,r0
    c.t = c.r[4] >= c.r[2];  // 06051112 cmp/hs r2,r4
    { const bool k = !c.t; c.r[3] = c.r[14]; if (k) { goto L_060511D2; } }  // 06051114 bf/s 0x060511D2 ; mov r14,r3
L_06051118:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06051118 mov.b @r14,r2
    c.r[3] += 1;  // 0605111A add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605111C mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605111E extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06051120 extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 06051122 cmp/hs r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[11] >= (int32_t)c.r[9]; if (k) { goto L_0605115A; } }  // 06051124 bf/s 0x0605115A ; cmp/ge r9,r11
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_06051134; } }  // 06051128 bt/s 0x06051134 ; mov r9,r2
    c.r[2] -= c.r[5];  // 0605112C sub r5,r2
    c.r[1] = c.r[11];  // 0605112E mov r11,r1
    c.r[1] -= 1; goto L_0605113A;  // 06051130 bra 0x0605113A ; add #-1,r1
L_06051134:
    c.r[2] += c.r[5];  // 06051134 add r5,r2
    c.r[1] = c.r[11];  // 06051136 mov r11,r1
    c.r[1] += 1;  // 06051138 add #1,r1
L_0605113A:
    c.r[2] -= c.r[1];  // 0605113A sub r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0605113C cmp/pz r2
    if (c.t) { goto L_06051142; }  // 0605113E bt 0x06051142
    c.r[2] = 0u - c.r[2];  // 06051140 neg r2,r2
L_06051142:
    st8(c.r[14], c.r[2]);  // 06051142 mov.b r2,@r14
    c.r[1] = c.r[14];  // 06051144 mov r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06051146 mov.b @r14,r2
    c.r[1] += 1;  // 06051148 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605114A mov.b @r1,r1
L_0605114C:
    c.r[2] = c.r[2] & 0xFFu;  // 0605114C extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605114E extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06051150 cmp/hi r1,r2
    if (!c.t) { goto L_060511D0; }  // 06051152 bf 0x060511D0
    c.r[7] = 0x1u;  // 06051154 mov #1,r7
    c.r[0] = c.r[7]; goto L_060511D2;  // 06051156 bra 0x060511D2 ; mov r7,r0
L_0605115A:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 0605115A cmp/ge r8,r10
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_06051168; } }  // 0605115C bt/s 0x06051168 ; mov r8,r2
    c.r[2] -= c.r[5];  // 06051160 sub r5,r2
    c.r[1] = c.r[10];  // 06051162 mov r10,r1
    c.r[1] -= 1; goto L_0605116E;  // 06051164 bra 0x0605116E ; add #-1,r1
L_06051168:
    c.r[2] += c.r[5];  // 06051168 add r5,r2
    c.r[1] = c.r[10];  // 0605116A mov r10,r1
    c.r[1] += 1;  // 0605116C add #1,r1
L_0605116E:
    c.r[2] -= c.r[1];  // 0605116E sub r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06051170 cmp/pz r2
    if (c.t) { goto L_06051176; }  // 06051172 bt 0x06051176
    c.r[2] = 0u - c.r[2];  // 06051174 neg r2,r2
L_06051176:
    st8(c.r[3], c.r[2]);  // 06051176 mov.b r2,@r3
    c.r[1] = c.r[14];  // 06051178 mov r14,r1
    c.r[1] += 1;  // 0605117A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605117C mov.b @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]); SH2_POLL(c); goto L_0605114C;  // 0605117E bra 0x0605114C ; mov.b @r14,r1
L_06051182:
    c.r[0] = c.r[13];  // 06051182 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 06051184 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[11]; if (k) { goto L_060511CE; } }  // 06051186 bf/s 0x060511CE ; mov r11,r2
    c.r[1] = ld32(0x060512F0u);  // 0605118A mov.l 0x060512F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605118C mov.b @r1,r1
    c.r[2] -= c.r[1];  // 0605118E sub r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06051190 cmp/pz r2
    if (c.t) { goto L_06051196; }  // 06051192 bt 0x06051196
    c.r[2] = 0u - c.r[2];  // 06051194 neg r2,r2
L_06051196:
    c.r[1] = ld32(0x060512F4u);  // 06051196 mov.l 0x060512F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051198 mov.b @r1,r1
    c.r[0] = c.r[10];  // 0605119A mov r10,r0
    c.r[0] -= c.r[1];  // 0605119C sub r1,r0
    c.r[1] = c.r[0];  // 0605119E mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060511A0 cmp/pz r1
    if (c.t) { goto L_060511A6; }  // 060511A2 bt 0x060511A6
    c.r[1] = 0u - c.r[1];  // 060511A4 neg r1,r1
L_060511A6:
    c.r[2] += c.r[1];  // 060511A6 add r1,r2
    c.r[1] = 0x3u;  // 060511A8 mov #3,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; goto L_060511CA;  // 060511AA bra 0x060511CA ; cmp/gt r1,r2
L_060511AE:
    c.r[1] = c.r[9];  // 060511AE mov r9,r1
    c.r[1] -= c.r[11];  // 060511B0 sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060511B2 cmp/pz r1
    if (c.t) { goto L_060511B8; }  // 060511B4 bt 0x060511B8
    c.r[1] = 0u - c.r[1];  // 060511B6 neg r1,r1
L_060511B8:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 060511B8 cmp/gt r4,r1
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_060511D2; } }  // 060511BA bt/s 0x060511D2 ; mov r7,r0
    c.r[1] = c.r[8];  // 060511BE mov r8,r1
    c.r[1] -= c.r[10];  // 060511C0 sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060511C2 cmp/pz r1
    if (c.t) { goto L_060511C8; }  // 060511C4 bt 0x060511C8
    c.r[1] = 0u - c.r[1];  // 060511C6 neg r1,r1
L_060511C8:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 060511C8 cmp/gt r4,r1
L_060511CA:
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_060511D2; } }  // 060511CA bt/s 0x060511D2 ; mov r7,r0
L_060511CE:
    c.r[7] = 0x1u;  // 060511CE mov #1,r7
L_060511D0:
    c.r[0] = c.r[7];  // 060511D0 mov r7,r0
L_060511D2:
    c.t = c.r[0] == 0x1u;  // 060511D2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0605122C; } }  // 060511D4 bf/s 0x0605122C ; mov r12,r0
    c.t = c.r[0] == 0x7u;  // 060511D8 cmp/eq #7,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 16); if (k) { goto L_0605122C; } }  // 060511DA bf/s 0x0605122C ; mov.l @(16,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060511DE tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_06051204; } }  // 060511E0 bt/s 0x06051204 ; mov r12,r0
    c.r[1] = ld32(0x060512F8u);  // 060511E4 mov.l 0x060512F8,r1
    c.r[2] = c.r[10];  // 060511E6 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 060511E8 mov.l @r1,r1
    c.r[2] <<= 2;  // 060511EA shll2 r2
    c.r[2] <<= 2;  // 060511EC shll2 r2
    c.r[2] <<= 2;  // 060511EE shll2 r2
    c.r[2] += c.r[1];  // 060511F0 add r1,r2
    c.r[0] = c.r[2];  // 060511F2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060511F4 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060511F6 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060512ECu);  // 060511F8 mov.w 0x060512EC,r2
    c.t = c.r[1] == c.r[2];  // 060511FA cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_06051204; } }  // 060511FC bt/s 0x06051204 ; mov r12,r0
    c.r[7] = 0x0u; goto L_0605122C;  // 06051200 bra 0x0605122C ; mov #0,r7
L_06051204:
    c.t = c.r[0] == 0x7u;  // 06051204 cmp/eq #7,r0
    { const bool k = !c.t; c.r[0] = c.r[13]; if (k) { goto L_0605122C; } }  // 06051206 bf/s 0x0605122C ; mov r13,r0
    c.t = c.r[0] == 0x2u;  // 0605120A cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 16); if (k) { goto L_0605122C; } }  // 0605120C bf/s 0x0605122C ; mov.l @(16,r14),r0
    c.r[6] = c.r[8] & 0xFFu;  // 06051210 extu.b r8,r6
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06051212 mov.l r0,@-r15
    c.r[0] = ld32(c.r[14] + 20);  // 06051214 mov.l @(20,r14),r0
    c.r[5] = c.r[9] & 0xFFu;  // 06051216 extu.b r9,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06051218 mov.l r0,@-r15
    c.r[0] = ld32(c.r[14] + 8);  // 0605121A mov.l @(8,r14),r0
    c.r[7] = c.r[11];  // 0605121C mov r11,r7
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0605121E mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06051220 mov.l r10,@-r15
    c.r[0] = ld32(0x060512FCu);  // 06051222 mov.l 0x060512FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06051228u; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051228u) return; }  // 06051224 jsr @r0 ; mov.l @(4,r14),r4
    c.r[1] = c.r[0];  // 06051228 mov r0,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0605122A extu.b r1,r7
L_0605122C:
    c.t = (c.r[7] & c.r[7]) == 0;  // 0605122C tst r7,r7
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06051236; } }  // 0605122E bf/s 0x06051236 ; mov.l @(12,r14),r0
    goto L_06051658;  // 06051232 bra 0x06051658 ; nop
L_06051236:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06051236 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_06051240; } }  // 06051238 bf/s 0x06051240 ; mov r12,r1
    goto L_06051658;  // 0605123C bra 0x06051658 ; nop
L_06051240:
    c.r[1] -= 4;  // 06051240 add #-4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051242 extu.b r1,r1
    c.r[2] = 0x1u;  // 06051244 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 06051246 cmp/hi r2,r1
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_06051268; } }  // 06051248 bf/s 0x06051268 ; mov r12,r0
    c.t = c.r[0] == 0x6u;  // 0605124C cmp/eq #6,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_06051268; } }  // 0605124E bt/s 0x06051268 ; mov r12,r1
    c.r[1] -= 8;  // 06051252 add #-8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051254 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06051256 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_06051268; } }  // 06051258 bf/s 0x06051268 ; mov r12,r1
    c.r[1] -= 10;  // 0605125C add #-10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605125E extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06051260 cmp/hi r2,r1
    if (!c.t) { goto L_06051268; }  // 06051262 bf 0x06051268
    goto L_06051658;  // 06051264 bra 0x06051658 ; nop
L_06051268:
    c.r[1] = ld32(0x06051300u);  // 06051268 mov.l 0x06051300,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605126A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605126C extu.b r1,r2
    c.r[0] = c.r[2];  // 0605126E mov r2,r0
    c.t = c.r[0] == 0x2u;  // 06051270 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x7u; if (k) { goto L_0605127A; } }  // 06051272 bf/s 0x0605127A ; mov #7,r1
    goto L_060513BE;  // 06051276 bra 0x060513BE ; nop
L_0605127A:
    c.r[1] = 0x2u;  // 0605127A mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0605127C cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0605128C; } }  // 0605127E bt/s 0x0605128C ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 06051282 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x7u; if (k) { goto L_06051298; } }  // 06051284 bt/s 0x06051298 ; mov #7,r1
    c.r[2] = c.r[12]; goto L_060515A2;  // 06051288 bra 0x060515A2 ; mov r12,r2
L_0605128C:
    { const bool k = !c.t; c.r[1] = 0x7u; if (k) { goto L_06051294; } }  // 0605128C bf/s 0x06051294 ; mov #7,r1
    goto L_060514A6;  // 06051290 bra 0x060514A6 ; nop
L_06051294:
    c.r[2] = c.r[12]; goto L_060515A2;  // 06051294 bra 0x060515A2 ; mov r12,r2
L_06051298:
    c.r[2] = c.r[12];  // 06051298 mov r12,r2
    c.r[2] -= 4;  // 0605129A add #-4,r2
    c.t = c.r[2] > c.r[1];  // 0605129C cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060512A6; } }  // 0605129E bf/s 0x060512A6 ; mov r2,r1
    goto L_06051658;  // 060512A2 bra 0x06051658 ; nop
L_060512A6:
    c.r[1] += c.r[1];  // 060512A6 add r1,r1
    c.r[0] = 0x060512B4u;  // 060512A8 mova 0x060512B4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060512AA mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060512AC add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060512C4u: goto L_060512C4; case 0x060512DEu: goto L_060512DE; case 0x06051304u: goto L_06051304; case 0x06051658u: goto L_06051658; case 0x0605131Eu: goto L_0605131E; case 0x06051346u: goto L_06051346; case 0x0605136Cu: goto L_0605136C; case 0x06051396u: goto L_06051396; default: sh2_call(c, x); return; } }  // 060512AE jmp @r0 ; nop
L_060512C4:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 060512C4 cmp/gt r9,r11
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_060512CE; } }  // 060512C6 bt/s 0x060512CE ; mov r10,r1
    goto L_06051652;  // 060512CA bra 0x06051652 ; nop
L_060512CE:
    c.r[1] -= 2;  // 060512CE add #-2,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060512D0 cmp/ge r1,r8
    { const bool k = c.t; c.r[10] += 2; if (k) { goto L_060512DA; } }  // 060512D2 bt/s 0x060512DA ; add #2,r10
    goto L_06051652;  // 060512D6 bra 0x06051652 ; nop
L_060512DA:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[10]; goto L_06051650;  // 060512DA bra 0x06051650 ; cmp/gt r10,r8
L_060512DE:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 060512DE cmp/gt r9,r11
    { const bool k = c.t; c.t = c.r[8] == c.r[10]; if (k) { goto L_060512E8; } }  // 060512E0 bt/s 0x060512E8 ; cmp/eq r10,r8
    goto L_06051652;  // 060512E4 bra 0x06051652 ; nop
L_060512E8:
    goto L_060514F4;  // 060512E8 bra 0x060514F4 ; nop
L_06051304:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 06051304 cmp/gt r9,r11
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_0605130E; } }  // 06051306 bt/s 0x0605130E ; mov r10,r1
    goto L_06051652;  // 0605130A bra 0x06051652 ; nop
L_0605130E:
    c.r[1] -= 1;  // 0605130E add #-1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06051310 cmp/ge r1,r8
    { const bool k = c.t; c.r[10] += 1; if (k) { goto L_0605131A; } }  // 06051312 bt/s 0x0605131A ; add #1,r10
    goto L_06051652;  // 06051316 bra 0x06051652 ; nop
L_0605131A:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[10]; goto L_06051650;  // 0605131A bra 0x06051650 ; cmp/gt r10,r8
L_0605131E:
    c.r[1] = c.r[9];  // 0605131E mov r9,r1
    c.r[1] -= c.r[11];  // 06051320 sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051322 cmp/pz r1
    if (c.t) { goto L_06051328; }  // 06051324 bt 0x06051328
    c.r[1] = 0u - c.r[1];  // 06051326 neg r1,r1
L_06051328:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 06051328 cmp/gt r9,r11
    { const bool k = c.t; st8(c.r[14], c.r[1]); if (k) { goto L_06051332; } }  // 0605132A bt/s 0x06051332 ; mov.b r1,@r14
    goto L_06051652;  // 0605132E bra 0x06051652 ; nop
L_06051332:
    c.r[2] = c.r[1] & 0xFFu;  // 06051332 extu.b r1,r2
    c.r[1] = c.r[8];  // 06051334 mov r8,r1
    c.r[1] -= c.r[2];  // 06051336 sub r2,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06051338 cmp/ge r1,r10
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_06051342; } }  // 0605133A bt/s 0x06051342 ; add r2,r8
    goto L_06051652;  // 0605133E bra 0x06051652 ; nop
L_06051342:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8]; goto L_06051650;  // 06051342 bra 0x06051650 ; cmp/gt r8,r10
L_06051346:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 06051346 cmp/gt r9,r11
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06051350; } }  // 06051348 bt/s 0x06051350 ; mov r10,r1
    goto L_06051652;  // 0605134C bra 0x06051652 ; nop
L_06051350:
    c.r[1] -= 1;  // 06051350 add #-1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06051352 cmp/ge r1,r8
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_0605135C; } }  // 06051354 bt/s 0x0605135C ; mov r10,r1
    goto L_06051652;  // 06051358 bra 0x06051652 ; nop
L_0605135C:
    c.r[1] += 1;  // 0605135C add #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0605135E cmp/gt r1,r8
    { const bool k = !c.t; c.t = c.r[8] == c.r[10]; if (k) { goto L_06051368; } }  // 06051360 bf/s 0x06051368 ; cmp/eq r10,r8
    goto L_06051652;  // 06051364 bra 0x06051652 ; nop
L_06051368:
    goto L_06051650;  // 06051368 bra 0x06051650 ; nop
L_0605136C:
    c.r[1] = c.r[9];  // 0605136C mov r9,r1
    c.r[1] -= c.r[11];  // 0605136E sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051370 cmp/pz r1
    if (c.t) { goto L_06051376; }  // 06051372 bt 0x06051376
    c.r[1] = 0u - c.r[1];  // 06051374 neg r1,r1
L_06051376:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 06051376 cmp/gt r9,r11
    { const bool k = c.t; st8(c.r[14], c.r[1]); if (k) { goto L_06051380; } }  // 06051378 bt/s 0x06051380 ; mov.b r1,@r14
    goto L_06051652;  // 0605137C bra 0x06051652 ; nop
L_06051380:
    c.r[2] = c.r[1] & 0xFFu;  // 06051380 extu.b r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06051382 shlr r2
    c.r[1] = c.r[8];  // 06051384 mov r8,r1
    c.r[1] -= c.r[2];  // 06051386 sub r2,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06051388 cmp/ge r1,r10
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_06051392; } }  // 0605138A bt/s 0x06051392 ; add r2,r8
    goto L_06051652;  // 0605138E bra 0x06051652 ; nop
L_06051392:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8]; goto L_06051650;  // 06051392 bra 0x06051650 ; cmp/gt r8,r10
L_06051396:
    c.r[1] = c.r[9];  // 06051396 mov r9,r1
    c.r[1] -= c.r[11];  // 06051398 sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605139A cmp/pz r1
    if (c.t) { goto L_060513A0; }  // 0605139C bt 0x060513A0
    c.r[1] = 0u - c.r[1];  // 0605139E neg r1,r1
L_060513A0:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 060513A0 cmp/gt r9,r11
    { const bool k = c.t; st8(c.r[14], c.r[1]); if (k) { goto L_060513AA; } }  // 060513A2 bt/s 0x060513AA ; mov.b r1,@r14
    goto L_06051652;  // 060513A6 bra 0x06051652 ; nop
L_060513AA:
    c.r[2] = c.r[1] & 0xFFu;  // 060513AA extu.b r1,r2
    c.r[1] = c.r[8];  // 060513AC mov r8,r1
    c.r[1] -= c.r[2];  // 060513AE sub r2,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060513B0 cmp/ge r1,r10
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_060513BA; } }  // 060513B2 bt/s 0x060513BA ; add r2,r8
    goto L_06051652;  // 060513B6 bra 0x06051652 ; nop
L_060513BA:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8]; goto L_06051650;  // 060513BA bra 0x06051650 ; cmp/gt r8,r10
L_060513BE:
    c.r[2] = c.r[12];  // 060513BE mov r12,r2
    c.r[2] -= 4;  // 060513C0 add #-4,r2
    c.t = c.r[2] > c.r[1];  // 060513C2 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060513CC; } }  // 060513C4 bf/s 0x060513CC ; mov r2,r1
    goto L_06051658;  // 060513C8 bra 0x06051658 ; nop
L_060513CC:
    c.r[1] += c.r[1];  // 060513CC add r1,r1
    c.r[0] = 0x060513D8u;  // 060513CE mova 0x060513D8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060513D0 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060513D2 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060513E8u: goto L_060513E8; case 0x06051402u: goto L_06051402; case 0x06051410u: goto L_06051410; case 0x06051658u: goto L_06051658; case 0x0605142Au: goto L_0605142A; case 0x06051446u: goto L_06051446; case 0x0605146Cu: goto L_0605146C; case 0x0605148Au: goto L_0605148A; default: sh2_call(c, x); return; } }  // 060513D4 jmp @r0 ; nop
L_060513E8:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 060513E8 cmp/gt r8,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060513F2; } }  // 060513EA bt/s 0x060513F2 ; mov r11,r1
    goto L_06051652;  // 060513EE bra 0x06051652 ; nop
L_060513F2:
    c.r[1] -= 2;  // 060513F2 add #-2,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060513F4 cmp/ge r1,r9
    { const bool k = c.t; c.r[11] += 2; if (k) { goto L_060513FE; } }  // 060513F6 bt/s 0x060513FE ; add #2,r11
    goto L_06051652;  // 060513FA bra 0x06051652 ; nop
L_060513FE:
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11]; goto L_06051650;  // 060513FE bra 0x06051650 ; cmp/gt r11,r9
L_06051402:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 06051402 cmp/gt r8,r10
    { const bool k = c.t; c.t = c.r[9] == c.r[11]; if (k) { goto L_0605140C; } }  // 06051404 bt/s 0x0605140C ; cmp/eq r11,r9
    goto L_06051652;  // 06051408 bra 0x06051652 ; nop
L_0605140C:
    goto L_060515E0;  // 0605140C bra 0x060515E0 ; nop
L_06051410:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 06051410 cmp/gt r8,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0605141A; } }  // 06051412 bt/s 0x0605141A ; mov r11,r1
    goto L_06051652;  // 06051416 bra 0x06051652 ; nop
L_0605141A:
    c.r[1] -= 1;  // 0605141A add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0605141C cmp/ge r1,r9
    { const bool k = c.t; c.r[11] += 1; if (k) { goto L_06051426; } }  // 0605141E bt/s 0x06051426 ; add #1,r11
    goto L_06051652;  // 06051422 bra 0x06051652 ; nop
L_06051426:
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11]; goto L_06051650;  // 06051426 bra 0x06051650 ; cmp/gt r11,r9
L_0605142A:
    c.r[2] = c.r[14];  // 0605142A mov r14,r2
    c.r[1] = c.r[8];  // 0605142C mov r8,r1
    c.r[1] -= c.r[10];  // 0605142E sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051430 cmp/pz r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06051438; } }  // 06051432 bt/s 0x06051438 ; add #1,r2
    c.r[1] = 0u - c.r[1];  // 06051436 neg r1,r1
L_06051438:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 06051438 cmp/gt r8,r10
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06051442; } }  // 0605143A bt/s 0x06051442 ; mov.b r1,@r2
    goto L_06051652;  // 0605143E bra 0x06051652 ; nop
L_06051442:
    c.r[2] = c.r[1] & 0xFFu; goto L_06051644;  // 06051442 bra 0x06051644 ; extu.b r1,r2
L_06051446:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 06051446 cmp/gt r8,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06051450; } }  // 06051448 bt/s 0x06051450 ; mov r11,r1
    goto L_06051652;  // 0605144C bra 0x06051652 ; nop
L_06051450:
    c.r[1] -= 1;  // 06051450 add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06051452 cmp/ge r1,r9
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0605145C; } }  // 06051454 bt/s 0x0605145C ; mov r11,r1
    goto L_06051652;  // 06051458 bra 0x06051652 ; nop
L_0605145C:
    c.r[1] += 1;  // 0605145C add #1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605145E cmp/gt r1,r9
    { const bool k = !c.t; c.t = c.r[9] == c.r[11]; if (k) { goto L_06051468; } }  // 06051460 bf/s 0x06051468 ; cmp/eq r11,r9
    goto L_06051652;  // 06051464 bra 0x06051652 ; nop
L_06051468:
    goto L_06051650;  // 06051468 bra 0x06051650 ; nop
L_0605146C:
    c.r[2] = c.r[14];  // 0605146C mov r14,r2
    c.r[1] = c.r[8];  // 0605146E mov r8,r1
    c.r[1] -= c.r[10];  // 06051470 sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051472 cmp/pz r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_0605147A; } }  // 06051474 bt/s 0x0605147A ; add #1,r2
    c.r[1] = 0u - c.r[1];  // 06051478 neg r1,r1
L_0605147A:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 0605147A cmp/gt r8,r10
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06051484; } }  // 0605147C bt/s 0x06051484 ; mov.b r1,@r2
    goto L_06051652;  // 06051480 bra 0x06051652 ; nop
L_06051484:
    c.r[2] = c.r[1] & 0xFFu;  // 06051484 extu.b r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1; goto L_06051644;  // 06051486 bra 0x06051644 ; shlr r2
L_0605148A:
    c.r[2] = c.r[14];  // 0605148A mov r14,r2
    c.r[1] = c.r[8];  // 0605148C mov r8,r1
    c.r[1] -= c.r[10];  // 0605148E sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051490 cmp/pz r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06051498; } }  // 06051492 bt/s 0x06051498 ; add #1,r2
    c.r[1] = 0u - c.r[1];  // 06051496 neg r1,r1
L_06051498:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8];  // 06051498 cmp/gt r8,r10
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_060514A2; } }  // 0605149A bt/s 0x060514A2 ; mov.b r1,@r2
    goto L_06051652;  // 0605149E bra 0x06051652 ; nop
L_060514A2:
    c.r[2] = c.r[1] & 0xFFu; goto L_06051644;  // 060514A2 bra 0x06051644 ; extu.b r1,r2
L_060514A6:
    c.r[2] = c.r[12];  // 060514A6 mov r12,r2
    c.r[2] -= 4;  // 060514A8 add #-4,r2
    c.t = c.r[2] > c.r[1];  // 060514AA cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060514B4; } }  // 060514AC bf/s 0x060514B4 ; mov r2,r1
    goto L_06051658;  // 060514B0 bra 0x06051658 ; nop
L_060514B4:
    c.r[1] += c.r[1];  // 060514B4 add r1,r1
    c.r[0] = 0x060514C0u;  // 060514B6 mova 0x060514C0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060514B8 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060514BA add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060514D0u: goto L_060514D0; case 0x060514EAu: goto L_060514EA; case 0x06051500u: goto L_06051500; case 0x06051658u: goto L_06051658; case 0x0605151Au: goto L_0605151A; case 0x06051542u: goto L_06051542; case 0x06051560u: goto L_06051560; case 0x06051582u: goto L_06051582; default: sh2_call(c, x); return; } }  // 060514BC jmp @r0 ; nop
L_060514D0:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 060514D0 cmp/ge r9,r11
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_060514DA; } }  // 060514D2 bf/s 0x060514DA ; mov r10,r1
    goto L_06051652;  // 060514D6 bra 0x06051652 ; nop
L_060514DA:
    c.r[1] -= 2;  // 060514DA add #-2,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060514DC cmp/ge r1,r8
    { const bool k = c.t; c.r[10] += 2; if (k) { goto L_060514E6; } }  // 060514DE bt/s 0x060514E6 ; add #2,r10
    goto L_06051652;  // 060514E2 bra 0x06051652 ; nop
L_060514E6:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[10]; goto L_06051650;  // 060514E6 bra 0x06051650 ; cmp/gt r10,r8
L_060514EA:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 060514EA cmp/ge r9,r11
    { const bool k = !c.t; c.t = c.r[8] == c.r[10]; if (k) { goto L_060514F4; } }  // 060514EC bf/s 0x060514F4 ; cmp/eq r10,r8
    goto L_06051652;  // 060514F0 bra 0x06051652 ; nop
L_060514F4:
    if (!c.t) { goto L_060514FA; }  // 060514F4 bf 0x060514FA
    goto L_06051658;  // 060514F6 bra 0x06051658 ; nop
L_060514FA:
    c.r[7] = 0x0u;  // 060514FA mov #0,r7
    c.r[14] += 24; goto L_0605165A;  // 060514FC bra 0x0605165A ; add #24,r14
L_06051500:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 06051500 cmp/ge r9,r11
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0605150A; } }  // 06051502 bf/s 0x0605150A ; mov r10,r1
    goto L_06051652;  // 06051506 bra 0x06051652 ; nop
L_0605150A:
    c.r[1] -= 1;  // 0605150A add #-1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0605150C cmp/ge r1,r8
    { const bool k = c.t; c.r[10] += 1; if (k) { goto L_06051516; } }  // 0605150E bt/s 0x06051516 ; add #1,r10
    goto L_06051652;  // 06051512 bra 0x06051652 ; nop
L_06051516:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[10]; goto L_06051650;  // 06051516 bra 0x06051650 ; cmp/gt r10,r8
L_0605151A:
    c.r[1] = c.r[9];  // 0605151A mov r9,r1
    c.r[1] -= c.r[11];  // 0605151C sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605151E cmp/pz r1
    if (c.t) { goto L_06051524; }  // 06051520 bt 0x06051524
    c.r[1] = 0u - c.r[1];  // 06051522 neg r1,r1
L_06051524:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 06051524 cmp/ge r9,r11
    { const bool k = !c.t; st8(c.r[14], c.r[1]); if (k) { goto L_0605152E; } }  // 06051526 bf/s 0x0605152E ; mov.b r1,@r14
    goto L_06051652;  // 0605152A bra 0x06051652 ; nop
L_0605152E:
    c.r[2] = c.r[1] & 0xFFu;  // 0605152E extu.b r1,r2
    c.r[1] = c.r[8];  // 06051530 mov r8,r1
    c.r[1] -= c.r[2];  // 06051532 sub r2,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06051534 cmp/ge r1,r10
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_0605153E; } }  // 06051536 bt/s 0x0605153E ; add r2,r8
    goto L_06051652;  // 0605153A bra 0x06051652 ; nop
L_0605153E:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8]; goto L_06051650;  // 0605153E bra 0x06051650 ; cmp/gt r8,r10
L_06051542:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 06051542 cmp/ge r9,r11
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0605154C; } }  // 06051544 bf/s 0x0605154C ; mov r10,r1
    goto L_06051652;  // 06051548 bra 0x06051652 ; nop
L_0605154C:
    c.r[1] -= 1;  // 0605154C add #-1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0605154E cmp/ge r1,r8
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06051652; } }  // 06051550 bf/s 0x06051652 ; mov r10,r1
    c.r[1] += 1;  // 06051554 add #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06051556 cmp/gt r1,r8
    { const bool k = c.t; c.t = c.r[8] == c.r[10]; if (k) { goto L_06051652; } }  // 06051558 bt/s 0x06051652 ; cmp/eq r10,r8
    goto L_06051650;  // 0605155C bra 0x06051650 ; nop
L_06051560:
    c.r[1] = c.r[9];  // 06051560 mov r9,r1
    c.r[1] -= c.r[11];  // 06051562 sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051564 cmp/pz r1
    if (c.t) { goto L_0605156A; }  // 06051566 bt 0x0605156A
    c.r[1] = 0u - c.r[1];  // 06051568 neg r1,r1
L_0605156A:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 0605156A cmp/ge r9,r11
    { const bool k = c.t; st8(c.r[14], c.r[1]); if (k) { goto L_06051652; } }  // 0605156C bt/s 0x06051652 ; mov.b r1,@r14
    c.r[2] = c.r[1] & 0xFFu;  // 06051570 extu.b r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06051572 shlr r2
    c.r[1] = c.r[8];  // 06051574 mov r8,r1
    c.r[1] -= c.r[2];  // 06051576 sub r2,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06051578 cmp/ge r1,r10
    { const bool k = !c.t; c.r[8] += c.r[2]; if (k) { goto L_06051652; } }  // 0605157A bf/s 0x06051652 ; add r2,r8
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8]; goto L_06051650;  // 0605157E bra 0x06051650 ; cmp/gt r8,r10
L_06051582:
    c.r[1] = c.r[9];  // 06051582 mov r9,r1
    c.r[1] -= c.r[11];  // 06051584 sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051586 cmp/pz r1
    if (c.t) { goto L_0605158C; }  // 06051588 bt 0x0605158C
    c.r[1] = 0u - c.r[1];  // 0605158A neg r1,r1
L_0605158C:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[9];  // 0605158C cmp/ge r9,r11
    { const bool k = c.t; st8(c.r[14], c.r[1]); if (k) { goto L_06051652; } }  // 0605158E bt/s 0x06051652 ; mov.b r1,@r14
    c.r[2] = c.r[1] & 0xFFu;  // 06051592 extu.b r1,r2
    c.r[1] = c.r[8];  // 06051594 mov r8,r1
    c.r[1] -= c.r[2];  // 06051596 sub r2,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06051598 cmp/ge r1,r10
    { const bool k = !c.t; c.r[8] += c.r[2]; if (k) { goto L_06051652; } }  // 0605159A bf/s 0x06051652 ; add r2,r8
    c.t = (int32_t)c.r[10] > (int32_t)c.r[8]; goto L_06051650;  // 0605159E bra 0x06051650 ; cmp/gt r8,r10
L_060515A2:
    c.r[2] -= 4;  // 060515A2 add #-4,r2
    c.t = c.r[2] > c.r[1];  // 060515A4 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06051658; } }  // 060515A6 bt/s 0x06051658 ; mov r2,r1
    c.r[1] += c.r[1];  // 060515AA add r1,r1
    c.r[0] = 0x060515B8u;  // 060515AC mova 0x060515B8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060515AE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060515B0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060515C8u: goto L_060515C8; case 0x060515DAu: goto L_060515DA; case 0x060515E8u: goto L_060515E8; case 0x06051658u: goto L_06051658; case 0x0605162Eu: goto L_0605162E; case 0x060515FAu: goto L_060515FA; case 0x06051614u: goto L_06051614; default: sh2_call(c, x); return; } }  // 060515B2 jmp @r0 ; nop
L_060515C8:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 060515C8 cmp/ge r8,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06051652; } }  // 060515CA bt/s 0x06051652 ; mov r11,r1
    c.r[1] -= 2;  // 060515CE add #-2,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060515D0 cmp/ge r1,r9
    { const bool k = !c.t; c.r[11] += 2; if (k) { goto L_06051652; } }  // 060515D2 bf/s 0x06051652 ; add #2,r11
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11]; goto L_06051650;  // 060515D6 bra 0x06051650 ; cmp/gt r11,r9
L_060515DA:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 060515DA cmp/ge r8,r10
    { const bool k = c.t; c.t = c.r[9] == c.r[11]; if (k) { goto L_06051652; } }  // 060515DC bt/s 0x06051652 ; cmp/eq r11,r9
L_060515E0:
    if (c.t) { goto L_06051658; }  // 060515E0 bt 0x06051658
    c.r[7] = 0x0u;  // 060515E2 mov #0,r7
    c.r[14] += 24; goto L_0605165A;  // 060515E4 bra 0x0605165A ; add #24,r14
L_060515E8:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 060515E8 cmp/ge r8,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06051652; } }  // 060515EA bt/s 0x06051652 ; mov r11,r1
    c.r[1] -= 1;  // 060515EE add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060515F0 cmp/ge r1,r9
    { const bool k = !c.t; c.r[11] += 1; if (k) { goto L_06051652; } }  // 060515F2 bf/s 0x06051652 ; add #1,r11
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11]; goto L_06051650;  // 060515F6 bra 0x06051650 ; cmp/gt r11,r9
L_060515FA:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 060515FA cmp/ge r8,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06051652; } }  // 060515FC bt/s 0x06051652 ; mov r11,r1
    c.r[1] -= 1;  // 06051600 add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06051602 cmp/ge r1,r9
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06051652; } }  // 06051604 bf/s 0x06051652 ; mov r11,r1
    c.r[1] += 1;  // 06051608 add #1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605160A cmp/gt r1,r9
    { const bool k = c.t; c.t = c.r[9] == c.r[11]; if (k) { goto L_06051652; } }  // 0605160C bt/s 0x06051652 ; cmp/eq r11,r9
    goto L_06051650;  // 06051610 bra 0x06051650 ; nop
L_06051614:
    c.r[2] = c.r[14];  // 06051614 mov r14,r2
    c.r[1] = c.r[8];  // 06051616 mov r8,r1
    c.r[1] -= c.r[10];  // 06051618 sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605161A cmp/pz r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06051622; } }  // 0605161C bt/s 0x06051622 ; add #1,r2
    c.r[1] = 0u - c.r[1];  // 06051620 neg r1,r1
L_06051622:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 06051622 cmp/ge r8,r10
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06051652; } }  // 06051624 bt/s 0x06051652 ; mov.b r1,@r2
    c.r[2] = c.r[1] & 0xFFu;  // 06051628 extu.b r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1; goto L_06051644;  // 0605162A bra 0x06051644 ; shlr r2
L_0605162E:
    c.r[2] = c.r[14];  // 0605162E mov r14,r2
    c.r[1] = c.r[8];  // 06051630 mov r8,r1
    c.r[1] -= c.r[10];  // 06051632 sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051634 cmp/pz r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_0605163C; } }  // 06051636 bt/s 0x0605163C ; add #1,r2
    c.r[1] = 0u - c.r[1];  // 0605163A neg r1,r1
L_0605163C:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[8];  // 0605163C cmp/ge r8,r10
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06051652; } }  // 0605163E bt/s 0x06051652 ; mov.b r1,@r2
    c.r[2] = c.r[1] & 0xFFu;  // 06051642 extu.b r1,r2
L_06051644:
    c.r[1] = c.r[9];  // 06051644 mov r9,r1
    c.r[1] -= c.r[2];  // 06051646 sub r2,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06051648 cmp/ge r1,r11
    { const bool k = !c.t; c.r[9] += c.r[2]; if (k) { goto L_06051652; } }  // 0605164A bf/s 0x06051652 ; add r2,r9
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 0605164E cmp/gt r9,r11
L_06051650:
    if (!c.t) { goto L_06051658; }  // 06051650 bf 0x06051658
L_06051652:
    c.r[7] = 0x0u; goto L_06051658;  // 06051652 bra 0x06051658 ; mov #0,r7
L_06051656:
    c.r[7] = 0x1u;  // 06051656 mov #1,r7
L_06051658:
    c.r[14] += 24;  // 06051658 add #24,r14
L_0605165A:
    c.r[15] = c.r[14];  // 0605165A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605165C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605165E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06051660 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06051662 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06051664 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06051666 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06051668 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0605166A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0605166C rts ; mov r7,r0
}

void f_06051670(SH2Context& c) {
    ran[1291] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06051670 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06051672 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06051674 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06051676 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06051678 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605167A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605167C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605167E sts.l pr,@-r15
    c.r[15] -= 12;  // 06051680 add #-12,r15
    c.r[14] = c.r[15];  // 06051682 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06051684 extu.b r4,r4
    st32(c.r[14] + 4, c.r[4]);  // 06051686 mov.l r4,@(4,r14)
    c.r[13] = c.r[5] & 0xFFu;  // 06051688 extu.b r5,r13
    c.r[10] = c.r[6] & 0xFFu;  // 0605168A extu.b r6,r10
    c.r[11] = c.r[7] & 0xFFu;  // 0605168C extu.b r7,r11
    c.r[2] = ld32(c.r[14] + 44);  // 0605168E mov.l @(44,r14),r2
    c.r[0] = 0x1u;  // 06051690 mov #1,r0
    c.r[8] = ld32(c.r[14] + 48);  // 06051692 mov.l @(48,r14),r8
    st32(c.r[14] + 8, c.r[0]);  // 06051694 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 56);  // 06051696 mov.l @(56,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051698 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605169A tst r1,r1
    { const bool k = c.t; c.r[12] = c.r[2] & 0xFFu; if (k) { goto L_060516BC; } }  // 0605169C bt/s 0x060516BC ; extu.b r2,r12
    c.r[1] = ld32(0x0605179Cu);  // 060516A0 mov.l 0x0605179C,r1
    c.r[2] = c.r[12];  // 060516A2 mov r12,r2
    c.r[1] = ld32(c.r[1]);  // 060516A4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060516A6 shll2 r2
    c.r[2] <<= 2;  // 060516A8 shll2 r2
    c.r[2] <<= 2;  // 060516AA shll2 r2
    c.r[2] += c.r[1];  // 060516AC add r1,r2
    c.r[0] = c.r[2];  // 060516AE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060516B0 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060516B2 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06051796u);  // 060516B4 mov.w 0x06051796,r2
    c.t = c.r[1] == c.r[2];  // 060516B6 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0605177C; } }  // 060516B8 bf/s 0x0605177C ; mov #0,r0
L_060516BC:
    c.r[9] = ld32(0x060517A0u);  // 060516BC mov.l 0x060517A0,r9
    c.r[4] = ld32(0x060517A4u);  // 060516BE mov.l 0x060517A4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060516C4u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060516C4u) return; }  // 060516C0 jsr @r9 ; mov #34,r5
    c.r[1] = c.r[0];  // 060516C4 mov r0,r1
    c.r[5] = 0x0u;  // 060516C6 mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060516CCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060516CCu) return; }  // 060516C8 jsr @r9 ; mov r1,r4
    c.r[8] += 37;  // 060516CC add #37,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060516CE mov.b @r8,r2
    c.r[1] = ld32(0x060517A8u);  // 060516D0 mov.l 0x060517A8,r1
    c.r[1] = ld32(c.r[1]);  // 060516D2 mov.l @r1,r1
    c.r[3] = c.r[0];  // 060516D4 mov r0,r3
    c.r[0] = ld32(c.r[14] + 4);  // 060516D6 mov.l @(4,r14),r0
    c.r[2] = c.r[2] & 0xFFu;  // 060516D8 extu.b r2,r2
    c.r[2] >>= 2;  // 060516DA shlr2 r2
    c.r[2] >>= 2;  // 060516DC shlr2 r2
    c.r[0] <<= 2;  // 060516DE shll2 r0
    c.r[0] <<= 2;  // 060516E0 shll2 r0
    c.r[0] += c.r[1];  // 060516E2 add r1,r0
    c.r[0] += 3;  // 060516E4 add #3,r0
    st32(c.r[14] + 4, c.r[0]);  // 060516E6 mov.l r0,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060516E8 mov.b @r0,r1
    c.r[5] = 0x22u;  // 060516EA mov #34,r5
    c.r[7] = c.r[1];  // 060516EC mov r1,r7
    c.r[7] >>= 2;  // 060516EE shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060516F0 shlr r7
    c.r[0] = 0x3u;  // 060516F2 mov #3,r0
    c.r[7] &= c.r[0];  // 060516F4 and r0,r7
    c.r[1] = c.r[2];  // 060516F6 mov r2,r1
    c.r[1] <<= 2;  // 060516F8 shll2 r1
    c.r[1] += c.r[2];  // 060516FA add r2,r1
    c.r[1] += c.r[3];  // 060516FC add r3,r1
    c.r[1] += c.r[7];  // 060516FE add r7,r1
    c.r[1] += 2;  // 06051700 add #2,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051702 mov.b @r1,r8
    c.r[4] = ld32(0x060517A4u);  // 06051704 mov.l 0x060517A4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605170Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605170Au) return; }  // 06051706 jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 0605170A mov r0,r1
    c.r[5] = 0x1u;  // 0605170C mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06051712u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051712u) return; }  // 0605170E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06051712 mov r0,r1
    c.r[5] = c.r[8];  // 06051714 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605171Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605171Au) return; }  // 06051716 jsr @r9 ; mov r1,r4
    c.r[9] = c.r[0];  // 0605171A mov r0,r9
    st8(c.r[14], c.r[11]);  // 0605171C mov.b r11,@r14
    c.r[1] = c.r[14];  // 0605171E mov r14,r1
    c.r[1] += 1;  // 06051720 add #1,r1
    st8(c.r[1], c.r[12]);  // 06051722 mov.b r12,@r1
    c.r[8] = c.r[1];  // 06051724 mov r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06051726 mov.b @r14,r1
L_06051728:
    c.r[5] = c.r[10];  // 06051728 mov r10,r5
    c.r[11] = c.r[1] & 0xFFu;  // 0605172A extu.b r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605172C mov.b @r8,r1
    c.r[4] = c.r[13];  // 0605172E mov r13,r4
    c.r[12] = c.r[1] & 0xFFu;  // 06051730 extu.b r1,r12
    c.r[1] = ld32(0x060517ACu);  // 06051732 mov.l 0x060517AC,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051734 mov.b @r1,r7
    c.r[0] = ld32(0x060517B0u);  // 06051736 mov.l 0x060517B0,r0
    c.r[1] = ld32(0x060517B4u);  // 06051738 mov.l 0x060517B4,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605173A mov.b @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0605173C extu.b r7,r7
    c.r[6] = c.r[6] & 0xFFu;  // 0605173E extu.b r6,r6
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06051740 mov.l r8,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x06051746u; c.r[15] -= 4; st32(c.r[15], c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051746u) return; }  // 06051742 jsr @r0 ; mov.l r14,@-r15
    c.t = c.r[11] == c.r[13];  // 06051746 cmp/eq r13,r11
    { const bool k = !c.t; c.r[15] += 8; if (k) { goto L_06051752; } }  // 06051748 bf/s 0x06051752 ; add #8,r15
    c.t = c.r[12] == c.r[10];  // 0605174C cmp/eq r10,r12
    { const bool k = c.t; c.t = c.r[11] == c.r[13]; if (k) { goto L_06051772; } }  // 0605174E bt/s 0x06051772 ; cmp/eq r13,r11
L_06051752:
    c.r[1] = ld32(0x060517B8u);  // 06051752 mov.l 0x060517B8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051798u);  // 06051754 mov.w 0x06051798,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06051756 mov.l @(r0,r1),r1
    c.r[0] = c.r[12];  // 06051758 mov r12,r0
    c.r[0] <<= 2;  // 0605175A shll2 r0
    c.r[0] <<= 2;  // 0605175C shll2 r0
    c.r[0] <<= 2;  // 0605175E shll2 r0
    c.r[0] += c.r[1];  // 06051760 add r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06051762 mov.b @(r0,r11),r1
    c.r[0] = c.r[1] & 0xFFu;  // 06051764 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06051766 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051768 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605176A tst r1,r1
    { const bool k = !c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { SH2_POLL(c); goto L_06051728; } }  // 0605176C bf/s 0x06051728 ; mov.b @r14,r1
    c.t = c.r[11] == c.r[13];  // 06051770 cmp/eq r13,r11
L_06051772:
    { const bool k = !c.t; c.t = c.r[12] == c.r[10]; if (k) { goto L_0605177A; } }  // 06051772 bf/s 0x0605177A ; cmp/eq r10,r12
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06051780; } }  // 06051776 bt/s 0x06051780 ; mov.l @(8,r14),r0
L_0605177A:
    c.r[0] = 0x0u;  // 0605177A mov #0,r0
L_0605177C:
    st32(c.r[14] + 8, c.r[0]);  // 0605177C mov.l r0,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 0605177E mov.l @(8,r14),r0
L_06051780:
    c.r[14] += 12;  // 06051780 add #12,r14
    c.r[15] = c.r[14];  // 06051782 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06051784 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06051786 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06051788 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605178A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605178C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605178E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06051790 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06051792 rts ; mov.l @r15+,r8
}

void f_060517BC(SH2Context& c) {
    ran[1292] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060517BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060517BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060517C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060517C2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060517C4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060517C6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060517C8 mov.l r14,@-r15
    c.r[15] -= 8;  // 060517CA add #-8,r15
    c.r[14] = c.r[15];  // 060517CC mov r15,r14
    c.r[13] = ld32(c.r[14] + 36);  // 060517CE mov.l @(36,r14),r13
    c.r[0] = c.r[4] & 0xFFu;  // 060517D0 extu.b r4,r0
    c.r[8] = c.r[5] & 0xFFu;  // 060517D2 extu.b r5,r8
    c.r[6] = c.r[6] & 0xFFu;  // 060517D4 extu.b r6,r6
    c.r[7] = c.r[7] & 0xFFu;  // 060517D6 extu.b r7,r7
    c.r[2] = c.r[7];  // 060517D8 mov r7,r2
    c.r[12] = 0x0u;  // 060517DA mov #0,r12
    st32(c.r[14], c.r[12]);  // 060517DC mov.l r12,@r14
    c.r[11] = (uint32_t)(int16_t)ld16(0x060518D2u);  // 060517DE mov.w 0x060518D2,r11
    c.r[1] = c.r[6];  // 060517E0 mov r6,r1
    c.r[1] -= c.r[0];  // 060517E2 sub r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060517E4 cmp/pz r1
    { const bool k = c.t; st32(c.r[14] + 4, c.r[11]); if (k) { goto L_060517EC; } }  // 060517E6 bt/s 0x060517EC ; mov.l r11,@(4,r14)
    c.r[1] = 0u - c.r[1];  // 060517EA neg r1,r1
L_060517EC:
    c.r[7] -= c.r[8];  // 060517EC sub r8,r7
    c.t = (int32_t)c.r[7] >= 0;  // 060517EE cmp/pz r7
    { const bool k = c.t; c.r[5] = c.r[1] & 0xFFu; if (k) { goto L_060517F6; } }  // 060517F0 bt/s 0x060517F6 ; extu.b r1,r5
    c.r[7] = 0u - c.r[7];  // 060517F4 neg r7,r7
L_060517F6:
    c.r[4] = c.r[7] & 0xFFu;  // 060517F6 extu.b r7,r4
    c.t = c.r[6] >= c.r[0];  // 060517F8 cmp/hs r0,r6
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06051800; } }  // 060517FA bt/s 0x06051800 ; mov #1,r1
    c.r[1] = 0xFFFFFFFFu;  // 060517FE mov #-1,r1
L_06051800:
    c.r[9] = c.r[1];  // 06051800 mov r1,r9
    c.t = c.r[2] >= c.r[8];  // 06051802 cmp/hs r8,r2
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0605180A; } }  // 06051804 bt/s 0x0605180A ; mov #1,r1
    c.r[1] = 0xFFFFFFFFu;  // 06051808 mov #-1,r1
L_0605180A:
    c.r[10] = c.r[1];  // 0605180A mov r1,r10
    c.r[7] = 0x0u;  // 0605180C mov #0,r7
    c.r[6] = 0x0u;  // 0605180E mov #0,r6
    c.r[3] = 0x0u;  // 06051810 mov #0,r3
L_06051812:
    c.macl = c.r[5] * c.r[7];  // 06051812 mul.l r7,r5
    c.r[1] = c.macl;  // 06051814 sts macl,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051816 cmp/pz r1
    if (c.t) { goto L_0605181C; }  // 06051818 bt 0x0605181C
    c.r[1] += 15;  // 0605181A add #15,r1
L_0605181C:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605181C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605181E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051820 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051822 shar r1
    c.t = c.r[1] == c.r[5];  // 06051824 cmp/eq r5,r1
    { const bool k = !c.t; c.macl = c.r[4] * c.r[7]; if (k) { goto L_06051840; } }  // 06051826 bf/s 0x06051840 ; mul.l r7,r4
    c.r[1] = c.macl;  // 0605182A sts macl,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605182C cmp/pz r1
    if (c.t) { goto L_06051832; }  // 0605182E bt 0x06051832
    c.r[1] += 15;  // 06051830 add #15,r1
L_06051832:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051832 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051834 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051836 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051838 shar r1
    c.t = c.r[1] == c.r[4];  // 0605183A cmp/eq r4,r1
    { const bool k = c.t; c.macl = c.r[5] * c.r[7]; if (k) { goto L_060518D4; } }  // 0605183C bt/s 0x060518D4 ; mul.l r7,r5
L_06051840:
    c.r[1] = c.r[3];  // 06051840 mov r3,r1
    c.r[1] += 8;  // 06051842 add #8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051844 cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_06051850; } }  // 06051846 bt/s 0x06051850 ; shar r1
    c.r[1] = c.r[3];  // 0605184A mov r3,r1
    c.r[1] += 23;  // 0605184C add #23,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605184E shar r1
L_06051850:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051850 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051852 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051854 shar r1
    c.macl = c.r[1] * c.r[9];  // 06051856 mul.l r9,r1
    c.r[2] = c.macl;  // 06051858 sts macl,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0605185A mov.b @r13,r1
    c.r[2] += c.r[0];  // 0605185C add r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605185E extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06051860 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0605188C; } }  // 06051862 bf/s 0x0605188C ; mov r6,r1
    c.r[1] += 8;  // 06051866 add #8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051868 cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_06051874; } }  // 0605186A bt/s 0x06051874 ; shar r1
    c.r[1] = c.r[6];  // 0605186E mov r6,r1
    c.r[1] += 23;  // 06051870 add #23,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051872 shar r1
L_06051874:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051874 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051876 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051878 shar r1
    c.macl = c.r[1] * c.r[10];  // 0605187A mul.l r10,r1
    c.r[12] = ld32(c.r[14] + 40);  // 0605187C mov.l @(40,r14),r12
    c.r[2] = c.macl;  // 0605187E sts macl,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06051880 mov.b @r12,r1
    c.r[2] += c.r[8];  // 06051882 add r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06051884 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06051886 cmp/eq r1,r2
    { const bool k = c.t; c.macl = c.r[5] * c.r[7]; if (k) { goto L_060518D4; } }  // 06051888 bt/s 0x060518D4 ; mul.l r7,r5
L_0605188C:
    c.r[1] = c.r[3];  // 0605188C mov r3,r1
    c.r[1] += 8;  // 0605188E add #8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051890 cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_0605189C; } }  // 06051892 bt/s 0x0605189C ; shar r1
    c.r[1] = c.r[3];  // 06051896 mov r3,r1
    c.r[1] += 23;  // 06051898 add #23,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605189A shar r1
L_0605189C:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605189C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605189E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518A0 shar r1
    c.macl = c.r[1] * c.r[9];  // 060518A2 mul.l r9,r1
    c.r[1] = c.macl;  // 060518A4 sts macl,r1
    c.r[1] += c.r[0];  // 060518A6 add r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060518A8 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 060518AA mov.l r1,@(4,r14)
    c.r[1] = c.r[6];  // 060518AC mov r6,r1
    c.r[1] += 8;  // 060518AE add #8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060518B0 cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_060518BC; } }  // 060518B2 bt/s 0x060518BC ; shar r1
    c.r[1] = c.r[6];  // 060518B6 mov r6,r1
    c.r[1] += 23;  // 060518B8 add #23,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518BA shar r1
L_060518BC:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518BC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518BE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518C0 shar r1
    c.r[6] += c.r[4];  // 060518C2 add r4,r6
    c.macl = c.r[1] * c.r[10];  // 060518C4 mul.l r10,r1
    c.r[3] += c.r[5];  // 060518C6 add r5,r3
    c.r[7] += 1;  // 060518C8 add #1,r7
    c.r[1] = c.macl;  // 060518CA sts macl,r1
    c.r[1] += c.r[8];  // 060518CC add r8,r1
    c.r[11] = c.r[1] & 0xFFu; SH2_POLL(c); goto L_06051812;  // 060518CE bra 0x06051812 ; extu.b r1,r11
L_060518D4:
    c.r[2] = c.macl;  // 060518D4 sts macl,r2
    c.r[1] = c.r[2];  // 060518D6 mov r2,r1
    c.r[1] += 8;  // 060518D8 add #8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060518DA cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_060518E6; } }  // 060518DC bt/s 0x060518E6 ; shar r1
    c.r[1] = c.r[2];  // 060518E0 mov r2,r1
    c.r[1] += 23;  // 060518E2 add #23,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518E4 shar r1
L_060518E6:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518E6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518E8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060518EA shar r1
    c.macl = c.r[1] * c.r[9];  // 060518EC mul.l r9,r1
    c.r[1] = c.macl;  // 060518EE sts macl,r1
    c.r[0] += c.r[1];  // 060518F0 add r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060518F2 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060518F4 extu.b r1,r1
    c.t = c.r[0] == c.r[1];  // 060518F6 cmp/eq r1,r0
    { const bool k = !c.t; c.macl = c.r[4] * c.r[7]; if (k) { goto L_06051934; } }  // 060518F8 bf/s 0x06051934 ; mul.l r7,r4
    c.r[2] = c.macl;  // 060518FC sts macl,r2
    c.r[1] = c.r[2];  // 060518FE mov r2,r1
    c.r[1] += 8;  // 06051900 add #8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06051902 cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_0605190E; } }  // 06051904 bt/s 0x0605190E ; shar r1
    c.r[1] = c.r[2];  // 06051908 mov r2,r1
    c.r[1] += 23;  // 0605190A add #23,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605190C shar r1
L_0605190E:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605190E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051910 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051912 shar r1
    c.macl = c.r[1] * c.r[10];  // 06051914 mul.l r10,r1
    c.r[12] = ld32(c.r[14] + 40);  // 06051916 mov.l @(40,r14),r12
    c.r[1] = c.macl;  // 06051918 sts macl,r1
    c.r[8] += c.r[1];  // 0605191A add r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0605191C mov.b @r12,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605191E extu.b r1,r1
    c.t = c.r[8] == c.r[1];  // 06051920 cmp/eq r1,r8
    { const bool k = !c.t; c.r[12] = 0x1u; if (k) { goto L_06051934; } }  // 06051922 bf/s 0x06051934 ; mov #1,r12
    st32(c.r[14], c.r[12]);  // 06051926 mov.l r12,@r14
    c.r[12] = 0x7u;  // 06051928 mov #7,r12
    c.r[12] += c.r[14];  // 0605192A add r14,r12
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0605192C mov.b @r12,r12
    st8(c.r[13], c.r[12]);  // 0605192E mov.b r12,@r13
    c.r[12] = ld32(c.r[14] + 40);  // 06051930 mov.l @(40,r14),r12
    st8(c.r[12], c.r[11]);  // 06051932 mov.b r11,@r12
L_06051934:
    c.r[0] = ld32(c.r[14]);  // 06051934 mov.l @r14,r0
    c.r[14] += 8;  // 06051936 add #8,r14
    c.r[15] = c.r[14];  // 06051938 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605193A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605193C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605193E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06051940 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06051942 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06051944 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06051946 rts ; mov.l @r15+,r8
}

void f_0605194C(SH2Context& c) {
    ran[1293] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605194C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605194E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06051950 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06051952 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06051954 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06051956 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06051958 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605195A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06051A58u);  // 0605195C mov.w 0x06051A58,r3
    c.r[15] += c.r[3];  // 0605195E add r3,r15
    c.r[14] = c.r[15];  // 06051960 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06051962 extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051A5Au);  // 06051964 mov.w 0x06051A5A,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06051966 mov.l r4,@(r0,r14)
    c.r[5] = c.r[5] & 0xFFu;  // 06051968 extu.b r5,r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A5Cu);  // 0605196A mov.w 0x06051A5C,r13
    c.r[13] += c.r[14];  // 0605196C add r14,r13
    st32(c.r[13], c.r[5]);  // 0605196E mov.l r5,@r13
    c.r[6] = c.r[6] & 0xFFu;  // 06051970 extu.b r6,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051A5Eu);  // 06051972 mov.w 0x06051A5E,r0
    st32(c.r[0] + c.r[14], c.r[6]);  // 06051974 mov.l r6,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051A5Au);  // 06051976 mov.w 0x06051A5A,r0
    c.r[0] += c.r[14];  // 06051978 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A60u);  // 0605197A mov.w 0x06051A60,r13
    c.r[0] = ld32(c.r[0]);  // 0605197C mov.l @r0,r0
    c.r[13] += c.r[14];  // 0605197E add r14,r13
    c.r[0] &= 0x80u;  // 06051980 and #128,r0
    st32(c.r[13], c.r[0]);  // 06051982 mov.l r0,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051A5Au);  // 06051984 mov.w 0x06051A5A,r0
    c.r[0] += c.r[14];  // 06051986 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A5Au);  // 06051988 mov.w 0x06051A5A,r13
    c.r[0] = ld32(c.r[0]);  // 0605198A mov.l @r0,r0
    c.r[13] += c.r[14];  // 0605198C add r14,r13
    c.r[0] &= 0x7Fu;  // 0605198E and #127,r0
    st32(c.r[13], c.r[0]);  // 06051990 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A5Cu);  // 06051992 mov.w 0x06051A5C,r13
    c.r[13] += c.r[14];  // 06051994 add r14,r13
    c.r[6] = ld32(c.r[13]);  // 06051996 mov.l @r13,r6
    c.r[1] = ld32(0x06051A68u);  // 06051998 mov.l 0x06051A68,r1
    c.r[5] = ld32(c.r[1]);  // 0605199A mov.l @r1,r5
    c.r[6] <<= 2;  // 0605199C shll2 r6
    c.r[6] <<= 2;  // 0605199E shll2 r6
    c.r[7] = c.r[6];  // 060519A0 mov r6,r7
    c.r[7] += c.r[5];  // 060519A2 add r5,r7
    c.r[1] = c.r[7];  // 060519A4 mov r7,r1
    c.r[1] += 10;  // 060519A6 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060519A8 mov.b @r1,r1
    c.r[0] = 0x1u;  // 060519AA mov #1,r0
    c.r[1] >>= 2;  // 060519AC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060519AE shlr r1
    c.r[1] &= c.r[0];  // 060519B0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060519B2 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_060519BC; } }  // 060519B4 bt/s 0x060519BC ; mov r7,r1
    goto L_06051E4C;  // 060519B8 bra 0x06051E4C ; nop
L_060519BC:
    c.r[3] = ld32(0x06051A6Cu);  // 060519BC mov.l 0x06051A6C,r3
    c.r[1] += 1;  // 060519BE add #1,r1
    c.r[0] = c.r[6];  // 060519C0 mov r6,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A62u);  // 060519C2 mov.w 0x06051A62,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060519C4 mov.b @r1,r2
    c.r[13] += c.r[14];  // 060519C6 add r14,r13
    c.r[2] = c.r[2] & 0xFFu;  // 060519C8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060519CA mov.b @(r0,r5),r1
    c.r[2] <<= 2;  // 060519CC shll2 r2
    c.r[2] <<= 2;  // 060519CE shll2 r2
    c.r[2] <<= 2;  // 060519D0 shll2 r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06051A64u);  // 060519D2 mov.w 0x06051A64,r6
    c.r[0] = c.r[3];  // 060519D4 mov r3,r0
    c.r[3] = ld32(c.r[0] + c.r[6]);  // 060519D6 mov.l @(r0,r6),r3
    c.r[1] = c.r[1] & 0xFFu;  // 060519D8 extu.b r1,r1
    c.r[2] += c.r[3];  // 060519DA add r3,r2
    c.r[0] = c.r[2];  // 060519DC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060519DE mov.b @(r0,r1),r1
    c.r[7] += 3;  // 060519E0 add #3,r7
    c.r[1] = c.r[1] & 0xFFu;  // 060519E2 extu.b r1,r1
    st32(c.r[13], c.r[1]);  // 060519E4 mov.l r1,@r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060519E6 mov.b @r7,r1
    c.r[0] = 0x3u;  // 060519E8 mov #3,r0
    c.r[1] >>= 2;  // 060519EA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060519EC shlr r1
    c.r[1] &= c.r[0];  // 060519EE and r0,r1
    c.r[0] = c.r[1];  // 060519F0 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060519F2 cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06051A16; } }  // 060519F4 bt/s 0x06051A16 ; mov #1,r4
    c.r[1] = ld32(0x06051A70u);  // 060519F8 mov.l 0x06051A70,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060519FA mov.b @r1,r0
    c.r[1] = 0xFu;  // 060519FC mov #15,r1
    c.r[1] &= c.r[0];  // 060519FE and r0,r1
    c.r[0] = ld32(0x06051A74u);  // 06051A00 mov.l 0x06051A74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06051A06u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051A06u) return; }  // 06051A02 jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06051A66u);  // 06051A06 mov.w 0x06051A66,r1
    c.r[0] &= c.r[1];  // 06051A08 and r1,r0
    c.r[1] = ld32(0x06051A78u);  // 06051A0A mov.l 0x06051A78,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06051A10u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051A10u) return; }  // 06051A0C jsr @r1 ; mov r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06051A10 tst r4,r4
    { const bool k = c.t; c.r[13] = 0x64u; if (k) { goto L_06051A84; } }  // 06051A12 bt/s 0x06051A84 ; mov #100,r13
L_06051A16:
    c.r[4] = ld32(0x06051A7Cu);  // 06051A16 mov.l 0x06051A7C,r4
    c.r[8] = ld32(0x06051A80u);  // 06051A18 mov.l 0x06051A80,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06051A1Eu; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051A1Eu) return; }  // 06051A1A jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 06051A1E mov r0,r1
    c.r[5] = 0x3u;  // 06051A20 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06051A26u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051A26u) return; }  // 06051A22 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06051A26 mov r0,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A62u);  // 06051A28 mov.w 0x06051A62,r13
    c.r[13] += c.r[14];  // 06051A2A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051A2C mov.l @r13,r0
    c.r[0] += c.r[0];  // 06051A2E add r0,r0
    st32(c.r[13], c.r[0]);  // 06051A30 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A62u);  // 06051A32 mov.w 0x06051A62,r13
    c.r[13] += c.r[14];  // 06051A34 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051A36 mov.l @r13,r0
    c.r[0] += c.r[1];  // 06051A38 add r1,r0
    st32(c.r[13], c.r[0]);  // 06051A3A mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A62u);  // 06051A3C mov.w 0x06051A62,r13
    c.r[13] += c.r[14];  // 06051A3E add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051A40 mov.l @r13,r0
    c.r[0] += 1;  // 06051A42 add #1,r0
    st32(c.r[13], c.r[0]);  // 06051A44 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A62u);  // 06051A46 mov.w 0x06051A62,r13
    c.r[13] += c.r[14];  // 06051A48 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051A4A mov.l @r13,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051A62u);  // 06051A4C mov.w 0x06051A62,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06051A4E mov.b @r0,r1
    c.r[13] += c.r[14];  // 06051A50 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06051A52 extu.b r1,r1
    st32(c.r[13], c.r[1]); goto L_06051A88;  // 06051A54 bra 0x06051A88 ; mov.l r1,@r13
L_06051A84:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051C04u);  // 06051A84 mov.w 0x06051C04,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06051A86 mov.l r13,@(r0,r14)
L_06051A88:
    c.r[8] = ld32(0x06051C18u);  // 06051A88 mov.l 0x06051C18,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051C06u);  // 06051A8A mov.w 0x06051C06,r0
    c.r[0] += c.r[14];  // 06051A8C add r14,r0
    c.r[9] = ld32(0x06051C1Cu);  // 06051A8E mov.l 0x06051C1C,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C06u);  // 06051A90 mov.w 0x06051C06,r13
    c.r[10] = ld32(c.r[0]);  // 06051A92 mov.l @r0,r10
    c.r[13] += c.r[14];  // 06051A94 add r14,r13
    c.r[1] = ld32(c.r[8]);  // 06051A96 mov.l @r8,r1
    c.r[10] <<= 2;  // 06051A98 shll2 r10
    c.r[10] <<= 2;  // 06051A9A shll2 r10
    c.r[1] += c.r[10];  // 06051A9C add r10,r1
    c.r[1] += 2;  // 06051A9E add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051AA0 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06051AA2 mov r14,r4
    c.r[6] = ld32(c.r[13]);  // 06051AA4 mov.l @r13,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06051AAAu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051AAAu) return; }  // 06051AA6 jsr @r9 ; extu.b r5,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06051C08u);  // 06051AAA mov.w 0x06051C08,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051C0Au);  // 06051AAC mov.w 0x06051C0A,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06051AAE mov.l @(r0,r14),r12
    c.r[4] = (uint32_t)(int16_t)ld16(0x06051C0Cu);  // 06051AB0 mov.w 0x06051C0C,r4
    c.r[1] = ld32(c.r[8]);  // 06051AB2 mov.l @r8,r1
    c.r[12] <<= 2;  // 06051AB4 shll2 r12
    c.r[12] <<= 2;  // 06051AB6 shll2 r12
    c.r[1] += c.r[12];  // 06051AB8 add r12,r1
    c.r[1] += 2;  // 06051ABA add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051ABC mov.b @r1,r5
    c.r[4] += c.r[14];  // 06051ABE add r14,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06051AC4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051AC4u) return; }  // 06051AC0 jsr @r9 ; extu.b r5,r5
    c.r[9] = 0x1Eu;  // 06051AC4 mov #30,r9
    c.r[1] = ld32(c.r[8]);  // 06051AC6 mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051C0Eu);  // 06051AC8 mov.w 0x06051C0E,r0
    c.r[10] += c.r[1];  // 06051ACA add r1,r10
    c.r[10] += 2;  // 06051ACC add #2,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06051ACE mov.b @r10,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C10u);  // 06051AD0 mov.w 0x06051C10,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06051AD2 extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 06051AD4 mul.l r9,r1
    c.r[10] = ld32(0x06051C20u);  // 06051AD6 mov.l 0x06051C20,r10
    c.r[2] = ld32(c.r[10]);  // 06051AD8 mov.l @r10,r2
    c.r[1] = c.macl;  // 06051ADA sts macl,r1
    c.r[1] += c.r[2];  // 06051ADC add r2,r1
    c.r[1] += 15;  // 06051ADE add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051AE0 mov.b @r1,r5
    c.r[13] += c.r[14];  // 06051AE2 add r14,r13
    st32(c.r[13], c.r[0]);  // 06051AE4 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C10u);  // 06051AE6 mov.w 0x06051C10,r13
    c.r[13] += c.r[14];  // 06051AE8 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051AEA mov.l @r13,r0
    c.r[11] = ld32(0x06051C24u);  // 06051AEC mov.l 0x06051C24,r11
    c.r[0] += c.r[14];  // 06051AEE add r14,r0
    st32(c.r[13], c.r[0]);  // 06051AF0 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C10u);  // 06051AF2 mov.w 0x06051C10,r13
    c.r[13] += c.r[14];  // 06051AF4 add r14,r13
    c.r[4] = ld32(c.r[13]);  // 06051AF6 mov.l @r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06051AFCu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051AFCu) return; }  // 06051AF8 jsr @r11 ; extu.b r5,r5
    c.r[1] = ld32(c.r[8]);  // 06051AFC mov.l @r8,r1
    c.r[12] += c.r[1];  // 06051AFE add r1,r12
    c.r[12] += 2;  // 06051B00 add #2,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06051B02 mov.b @r12,r1
    c.r[2] = ld32(c.r[10]);  // 06051B04 mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06051B06 extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 06051B08 mul.l r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06051C12u);  // 06051B0A mov.w 0x06051C12,r8
    c.r[8] += c.r[14];  // 06051B0C add r14,r8
    c.r[1] = c.macl;  // 06051B0E sts macl,r1
    c.r[1] += c.r[2];  // 06051B10 add r2,r1
    c.r[1] += 15;  // 06051B12 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051B14 mov.b @r1,r5
    c.r[4] = c.r[8];  // 06051B16 mov r8,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06051B1Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051B1Cu) return; }  // 06051B18 jsr @r11 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051C10u);  // 06051B1C mov.w 0x06051C10,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06051B1E mov.l @(r0,r14),r1
    c.r[1] += 16;  // 06051B20 add #16,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06051B22 mov.w @r1,r2
    c.r[8] += 20;  // 06051B24 add #20,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06051B26 mov.w @r8,r1
    c.r[10] = c.r[14];  // 06051B28 mov r14,r10
    c.r[9] = c.r[1] & 0xFFFFu;  // 06051B2A extu.w r1,r9
    c.r[1] = c.r[14];  // 06051B2C mov r14,r1
    c.r[1] += 34;  // 06051B2E add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06051B30 mov.w @r1,r1
    c.r[10] += 32;  // 06051B32 add #32,r10
    c.r[2] += c.r[1];  // 06051B34 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06051B36 mov.w @r10,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06051B38 exts.w r2,r8
    c.r[1] = c.r[1] & 0xFFFFu;  // 06051B3A extu.w r1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06051B3C cmp/gt r1,r8
    if (!c.t) { goto L_06051B42; }  // 06051B3E bf 0x06051B42
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06051B40 mov.w @r10,r8
L_06051B42:
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[14]);  // 06051B42 mov.w @r14,r5
    c.r[0] = ld32(0x06051C28u);  // 06051B44 mov.l 0x06051C28,r0
    c.r[4] = 0x0u;  // 06051B46 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06051B4Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051B4Cu) return; }  // 06051B48 jsr @r0 ; extu.w r5,r5
    c.r[3] = c.r[0] & 0xFFFFu;  // 06051B4C extu.w r0,r3
    c.r[1] = ld32(0x06051C2Cu);  // 06051B4E mov.l 0x06051C2C,r1
    c.t = c.r[3] == c.r[1];  // 06051B50 cmp/eq r1,r3
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_06051BA0; } }  // 06051B52 bt/s 0x06051BA0 ; shll2 r3
    c.r[1] = ld32(0x06051C30u);  // 06051B56 mov.l 0x06051C30,r1
    c.r[2] = ld32(c.r[1]);  // 06051B58 mov.l @r1,r2
    c.r[2] += c.r[3];  // 06051B5A add r3,r2
    c.r[1] = c.r[2];  // 06051B5C mov r2,r1
    c.r[1] += 22;  // 06051B5E add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051B60 mov.b @r1,r0
    c.r[2] += 23;  // 06051B62 add #23,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06051B64 mov.b @r2,r2
    c.r[0] &= 0x1Fu;  // 06051B66 and #31,r0
    c.r[0] <<= 2;  // 06051B68 shll2 r0
    c.r[0] += c.r[0];  // 06051B6A add r0,r0
    c.r[0] <<= 2;  // 06051B6C shll2 r0
    c.r[2] = c.r[2] & 0xFFu;  // 06051B6E extu.b r2,r2
    c.r[2] >>= 2;  // 06051B70 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06051B72 shlr r2
    c.r[2] |= c.r[0];  // 06051B74 or r0,r2
    c.r[2] -= 50;  // 06051B76 add #-50,r2
    c.r[1] = c.r[2];  // 06051B78 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06051B7A rotl r1
    c.r[1] = c.t;  // 06051B7C movt r1
    c.r[2] += c.r[1];  // 06051B7E add r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051B80 shar r2
    c.r[2] += 100;  // 06051B82 add #100,r2
    c.macl = c.r[8] * c.r[2];  // 06051B84 mul.l r2,r8
    c.r[1] = ld32(0x06051C34u);  // 06051B86 mov.l 0x06051C34,r1
    c.r[2] = c.macl;  // 06051B88 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06051B8A dmuls.l r1,r2
    c.r[1] = c.mach;  // 06051B8C sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051B8E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051B90 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051B92 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051B94 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051B96 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06051B98 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06051B9A subc r2,r2
    c.r[1] -= c.r[2];  // 06051B9C sub r2,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051B9E exts.w r1,r8
L_06051BA0:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C10u);  // 06051BA0 mov.w 0x06051C10,r13
    c.r[13] += c.r[14];  // 06051BA2 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051BA4 mov.l @r13,r0
    c.r[0] += 22;  // 06051BA6 add #22,r0
    st32(c.r[13], c.r[0]);  // 06051BA8 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C10u);  // 06051BAA mov.w 0x06051C10,r13
    c.r[13] += c.r[14];  // 06051BAC add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051BAE mov.l @r13,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06051BB0 mov.w @r10,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06051BB2 mov.w @r0,r4
    c.r[1] = c.r[3] & 0xFFFFu;  // 06051BB4 extu.w r3,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 06051BB6 extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 06051BB8 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06051BC0; } }  // 06051BBA bt/s 0x06051BC0 ; mov r3,r1
    c.r[1] = c.r[4];  // 06051BBE mov r4,r1
L_06051BC0:
    c.r[1] += c.r[8];  // 06051BC0 add r8,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051BC2 exts.w r1,r8
    c.r[2] = c.r[8];  // 06051BC4 mov r8,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051C14u);  // 06051BC6 mov.w 0x06051C14,r13
    c.r[13] += c.r[14];  // 06051BC8 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051C14u);  // 06051BCA mov.w 0x06051C14,r0
    c.r[0] += c.r[14];  // 06051BCC add r14,r0
    c.r[1] = c.r[14];  // 06051BCE mov r14,r1
    c.r[3] = ld32(c.r[13]);  // 06051BD0 mov.l @r13,r3
    c.r[1] += 58;  // 06051BD2 add #58,r1
    c.r[0] = ld32(c.r[0]);  // 06051BD4 mov.l @r0,r0
    c.r[3] <<= 2;  // 06051BD6 shll2 r3
    c.r[3] += c.r[0];  // 06051BD8 add r0,r3
    c.r[3] <<= 2;  // 06051BDA shll2 r3
    c.r[0] = c.r[1];  // 06051BDC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06051BDE mov.b @(r0,r3),r1
    c.r[2] += 100;  // 06051BE0 add #100,r2
    c.r[2] += c.r[1];  // 06051BE2 add r1,r2
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06051BE4 exts.w r2,r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06051C0Cu);  // 06051BE6 mov.w 0x06051C0C,r2
    c.r[2] += c.r[14];  // 06051BE8 add r14,r2
    c.r[1] = c.r[2];  // 06051BEA mov r2,r1
    c.r[1] += 34;  // 06051BEC add #34,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06051BEE mov.w @r1,r7
    c.r[2] += 32;  // 06051BF0 add #32,r2
    c.r[3] = c.r[7] & 0xFFFFu;  // 06051BF2 extu.w r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06051BF4 mov.w @r2,r1
    c.r[3] += c.r[9];  // 06051BF6 add r9,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 06051BF8 extu.w r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06051BFA cmp/gt r1,r3
    if (!c.t) { goto L_06051C38; }  // 06051BFC bf 0x06051C38
    c.r[9] = c.r[1];  // 06051BFE mov r1,r9
    goto L_06051C3E;  // 06051C00 bra 0x06051C3E ; nop
L_06051C38:
    c.r[1] = c.r[9];  // 06051C38 mov r9,r1
    c.r[1] += c.r[7];  // 06051C3A add r7,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06051C3C extu.w r1,r9
L_06051C3E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051CB8u);  // 06051C3E mov.w 0x06051CB8,r0
    c.r[10] = c.r[14];  // 06051C40 mov r14,r10
    c.r[10] += c.r[0];  // 06051C42 add r0,r10
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06051C44 mov.w @(r0,r14),r5
    c.r[4] = 0x0u;  // 06051C46 mov #0,r4
    c.r[0] = ld32(0x06051CBCu);  // 06051C48 mov.l 0x06051CBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06051C4Eu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051C4Eu) return; }  // 06051C4A jsr @r0 ; extu.w r5,r5
    c.r[3] = c.r[0] & 0xFFFFu;  // 06051C4E extu.w r0,r3
    c.r[1] = ld32(0x06051CC0u);  // 06051C50 mov.l 0x06051CC0,r1
    c.t = c.r[3] == c.r[1];  // 06051C52 cmp/eq r1,r3
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_06051CA2; } }  // 06051C54 bt/s 0x06051CA2 ; shll2 r3
    c.r[1] = ld32(0x06051CC4u);  // 06051C58 mov.l 0x06051CC4,r1
    c.r[2] = ld32(c.r[1]);  // 06051C5A mov.l @r1,r2
    c.r[2] += c.r[3];  // 06051C5C add r3,r2
    c.r[1] = c.r[2];  // 06051C5E mov r2,r1
    c.r[1] += 22;  // 06051C60 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051C62 mov.b @r1,r0
    c.r[2] += 23;  // 06051C64 add #23,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06051C66 mov.b @r2,r2
    c.r[0] &= 0x1Fu;  // 06051C68 and #31,r0
    c.r[0] <<= 2;  // 06051C6A shll2 r0
    c.r[0] += c.r[0];  // 06051C6C add r0,r0
    c.r[0] <<= 2;  // 06051C6E shll2 r0
    c.r[2] = c.r[2] & 0xFFu;  // 06051C70 extu.b r2,r2
    c.r[2] >>= 2;  // 06051C72 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06051C74 shlr r2
    c.r[2] |= c.r[0];  // 06051C76 or r0,r2
    c.r[2] -= 50;  // 06051C78 add #-50,r2
    c.r[1] = c.r[2];  // 06051C7A mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06051C7C rotl r1
    c.r[1] = c.t;  // 06051C7E movt r1
    c.r[2] += c.r[1];  // 06051C80 add r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051C82 shar r2
    c.r[2] += 100;  // 06051C84 add #100,r2
    c.macl = c.r[9] * c.r[2];  // 06051C86 mul.l r2,r9
    c.r[1] = ld32(0x06051CC8u);  // 06051C88 mov.l 0x06051CC8,r1
    c.r[2] = c.macl;  // 06051C8A sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06051C8C dmuls.l r1,r2
    c.r[1] = c.mach;  // 06051C8E sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051C90 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051C92 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051C94 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051C96 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051C98 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06051C9A shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06051C9C subc r2,r2
    c.r[1] -= c.r[2];  // 06051C9E sub r2,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06051CA0 extu.w r1,r9
L_06051CA2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051CBAu);  // 06051CA2 mov.w 0x06051CBA,r0
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06051CA4 mov.w @(r0,r14),r7
    c.r[10] += 32;  // 06051CA6 add #32,r10
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06051CA8 mov.w @r10,r3
    c.r[2] = c.r[7] & 0xFFFFu;  // 06051CAA extu.w r7,r2
    c.r[1] = c.r[3] & 0xFFFFu;  // 06051CAC extu.w r3,r1
    c.t = c.r[2] > c.r[1];  // 06051CAE cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_06051CCC; } }  // 06051CB0 bf/s 0x06051CCC ; mov r9,r1
    c.r[1] += c.r[3]; goto L_06051CCE;  // 06051CB4 bra 0x06051CCE ; add r3,r1
L_06051CCC:
    c.r[1] += c.r[7];  // 06051CCC add r7,r1
L_06051CCE:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06051CCE extu.w r1,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051E2Cu);  // 06051CD0 mov.w 0x06051E2C,r13
    c.r[13] += c.r[14];  // 06051CD2 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06051CD4 mov.l @r13,r13
    c.r[8] -= c.r[9];  // 06051CD6 sub r9,r8
    c.macl = c.r[8] * c.r[13];  // 06051CD8 mul.l r13,r8
    c.r[3] = ld32(0x06051E3Cu);  // 06051CDA mov.l 0x06051E3C,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x06051E2Eu);  // 06051CDC mov.w 0x06051E2E,r9
    c.r[1] = c.macl;  // 06051CDE sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06051CE0 dmuls.l r3,r1
    c.r[9] += c.r[14];  // 06051CE2 add r14,r9
    c.r[0] = c.r[9];  // 06051CE4 mov r9,r0
    c.r[2] = c.mach;  // 06051CE6 sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051CE8 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051CEA shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051CEC shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051CEE shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06051CF0 shar r2
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06051CF2 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06051CF4 subc r1,r1
    c.r[2] -= c.r[1];  // 06051CF6 sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06051E30u);  // 06051CF8 mov.w 0x06051E30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06051CFA mov.b @(r0,r1),r1
    c.r[7] = 0x7u;  // 06051CFC mov #7,r7
    c.r[7] &= c.r[1];  // 06051CFE and r1,r7
    c.r[1] = ld32(0x06051E40u);  // 06051D00 mov.l 0x06051E40,r1
    c.r[0] = c.r[7];  // 06051D02 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06051D04 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051D06 extu.b r1,r1
    c.macl = c.r[2] * c.r[1];  // 06051D08 mul.l r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051E32u);  // 06051D0A mov.w 0x06051E32,r13
    c.r[2] = c.macl;  // 06051D0C sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06051D0E dmuls.l r3,r2
    c.r[13] += c.r[14];  // 06051D10 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051D12 mov.l @r13,r0
    c.r[1] = c.mach;  // 06051D14 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051D16 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051D18 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051D1A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051D1C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06051D1E shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06051D20 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06051D22 subc r2,r2
    c.r[1] -= c.r[2];  // 06051D24 sub r2,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051D26 exts.w r1,r8
    c.r[1] = ld32(0x06051E44u);  // 06051D28 mov.l 0x06051E44,r1
    c.r[2] = ld32(c.r[1]);  // 06051D2A mov.l @r1,r2
    c.r[0] <<= 2;  // 06051D2C shll2 r0
    c.r[0] <<= 2;  // 06051D2E shll2 r0
    st32(c.r[13], c.r[0]);  // 06051D30 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051E32u);  // 06051D32 mov.w 0x06051E32,r13
    c.r[13] += c.r[14];  // 06051D34 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051D36 mov.l @r13,r0
    c.r[0] += c.r[2];  // 06051D38 add r2,r0
    st32(c.r[13], c.r[0]);  // 06051D3A mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051E32u);  // 06051D3C mov.w 0x06051E32,r13
    c.r[13] += c.r[14];  // 06051D3E add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051D40 mov.l @r13,r0
    c.r[0] += 10;  // 06051D42 add #10,r0
    st32(c.r[13], c.r[0]);  // 06051D44 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06051E32u);  // 06051D46 mov.w 0x06051E32,r13
    c.r[13] += c.r[14];  // 06051D48 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06051D4A mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06051D4C mov.b @r0,r1
    c.r[13] = 0x1u;  // 06051D4E mov #1,r13
    c.r[1] &= c.r[13];  // 06051D50 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06051D52 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06051D5C; } }  // 06051D54 bt/s 0x06051D5C ; mov r8,r1
    c.r[1] -= 30;  // 06051D58 add #-30,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051D5A exts.w r1,r8
L_06051D5C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051E34u);  // 06051D5C mov.w 0x06051E34,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06051D5E mov.l @(r0,r14),r1
    c.r[1] <<= 2;  // 06051D60 shll2 r1
    c.r[1] <<= 2;  // 06051D62 shll2 r1
    c.r[1] += c.r[2];  // 06051D64 add r2,r1
    c.r[1] += 10;  // 06051D66 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051D68 mov.b @r1,r1
    c.r[13] = 0x1u;  // 06051D6A mov #1,r13
    c.r[1] &= c.r[13];  // 06051D6C and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06051D6E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06051D78; } }  // 06051D70 bt/s 0x06051D78 ; mov r8,r1
    c.r[1] += 30;  // 06051D74 add #30,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051D76 exts.w r1,r8
L_06051D78:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06051E36u);  // 06051D78 mov.w 0x06051E36,r4
    c.r[4] += c.r[14];  // 06051D7A add r14,r4
    c.r[0] = ld32(0x06051E48u);  // 06051D7C mov.l 0x06051E48,r0
    c.r[6] = 0x4u;  // 06051D7E mov #4,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06051D84u; c.r[5] = 0x4Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051D84u) return; }  // 06051D80 jsr @r0 ; mov #78,r5
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06051D84 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06051D86 cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06051DA6; } }  // 06051D88 bt/s 0x06051DA6 ; mov r9,r1
    c.r[9] += 26;  // 06051D8C add #26,r9
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06051D8E mov.w @r9,r2
    c.r[1] += 22;  // 06051D90 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06051D92 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06051D94 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06051D96 extu.w r1,r1
    c.r[2] >>= 2;  // 06051D98 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06051D9A shlr r2
    c.t = c.r[1] > c.r[2];  // 06051D9C cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06051DA6; } }  // 06051D9E bt/s 0x06051DA6 ; mov r8,r1
    c.r[1] -= 10;  // 06051DA2 add #-10,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051DA4 exts.w r1,r8
L_06051DA6:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06051E38u);  // 06051DA6 mov.w 0x06051E38,r4
    c.r[4] += c.r[14];  // 06051DA8 add r14,r4
    c.r[0] = ld32(0x06051E48u);  // 06051DAA mov.l 0x06051E48,r0
    c.r[6] = 0x4u;  // 06051DAC mov #4,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06051DB2u; c.r[5] = 0x4Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051DB2u) return; }  // 06051DAE jsr @r0 ; mov #78,r5
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06051DB2 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06051DB4 cmp/eq #-1,r0
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_06051DDC; } }  // 06051DB6 bt/s 0x06051DDC ; cmp/pz r8
    c.r[3] = c.r[14];  // 06051DBA mov r14,r3
    c.r[1] = c.r[14];  // 06051DBC mov r14,r1
    c.r[1] += 26;  // 06051DBE add #26,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06051DC0 mov.w @r1,r2
    c.r[3] += 22;  // 06051DC2 add #22,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 06051DC4 extu.w r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06051DC6 mov.w @r3,r1
    c.r[2] >>= 2;  // 06051DC8 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06051DCA shlr r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06051DCC extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06051DCE cmp/hi r2,r1
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_06051DDC; } }  // 06051DD0 bt/s 0x06051DDC ; cmp/pz r8
    c.r[1] = c.r[8];  // 06051DD4 mov r8,r1
    c.r[1] += 10;  // 06051DD6 add #10,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06051DD8 exts.w r1,r8
    c.t = (int32_t)c.r[8] >= 0;  // 06051DDA cmp/pz r8
L_06051DDC:
    if (c.t) { goto L_06051DE0; }  // 06051DDC bt 0x06051DE0
    c.r[8] = 0x0u;  // 06051DDE mov #0,r8
L_06051DE0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051E34u);  // 06051DE0 mov.w 0x06051E34,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06051DE2 mov.l @(r0,r14),r4
    c.r[1] = ld32(0x06051E44u);  // 06051DE4 mov.l 0x06051E44,r1
    c.r[1] = ld32(c.r[1]);  // 06051DE6 mov.l @r1,r1
    c.r[4] <<= 2;  // 06051DE8 shll2 r4
    c.r[4] <<= 2;  // 06051DEA shll2 r4
    c.r[4] += c.r[1];  // 06051DEC add r1,r4
    c.r[1] = c.r[4];  // 06051DEE mov r4,r1
    c.r[1] += 11;  // 06051DF0 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051DF2 mov.b @r1,r1
    c.r[13] = 0x1u;  // 06051DF4 mov #1,r13
    c.r[1] >>= 2;  // 06051DF6 shlr2 r1
    c.r[1] >>= 2;  // 06051DF8 shlr2 r1
    c.r[1] >>= 2;  // 06051DFA shlr2 r1
    c.r[1] &= c.r[13];  // 06051DFC and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06051DFE tst r1,r1
    if (c.t) { goto L_06051E04; }  // 06051E00 bt 0x06051E04
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06051E02 shar r8
L_06051E04:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051E3Au);  // 06051E04 mov.w 0x06051E3A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06051E06 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06051E08 tst r0,r0
    if (c.t) { goto L_06051E0E; }  // 06051E0A bt 0x06051E0E
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06051E0C shar r8
L_06051E0E:
    c.r[2] = 0x64u;  // 06051E0E mov #100,r2
    c.t = (int32_t)c.r[8] > (int32_t)c.r[2];  // 06051E10 cmp/gt r2,r8
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06051E4E; } }  // 06051E12 bt/s 0x06051E4E ; mov r2,r0
    c.r[4] += 10;  // 06051E16 add #10,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06051E18 mov.b @r4,r1
    c.r[0] = c.r[1];  // 06051E1A mov r1,r0
    c.r[0] >>= 2;  // 06051E1C shlr2 r0
    c.r[0] >>= 2;  // 06051E1E shlr2 r0
    c.r[0] &= 0x1u;  // 06051E20 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06051E22 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[8] & 0xFFu; if (k) { goto L_06051E4E; } }  // 06051E24 bt/s 0x06051E4E ; extu.b r8,r0
    c.r[0] = c.r[2]; goto L_06051E4E;  // 06051E28 bra 0x06051E4E ; mov r2,r0
L_06051E4C:
    c.r[0] = 0x0u;  // 06051E4C mov #0,r0
L_06051E4E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06051E66u);  // 06051E4E mov.w 0x06051E66,r3
    c.r[14] += c.r[3];  // 06051E50 add r3,r14
    c.r[15] = c.r[14];  // 06051E52 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06051E54 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06051E56 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06051E58 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06051E5A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06051E5C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06051E5E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06051E60 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06051E62 rts ; mov.l @r15+,r8
}

void f_06051E68(SH2Context& c) {
    ran[1294] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06051E68 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06051E6A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06051E6C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06051E6E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06051E70 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06051E72 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06051E74 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06051E76 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06051FE6u);  // 06051E78 mov.w 0x06051FE6,r3
    c.r[15] += c.r[3];  // 06051E7A add r3,r15
    c.r[14] = c.r[15];  // 06051E7C mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06051E7E extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FE8u);  // 06051E80 mov.w 0x06051FE8,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06051E82 mov.l r4,@(r0,r14)
    c.r[5] = c.r[5] & 0xFFu;  // 06051E84 extu.b r5,r5
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051E86 mov.w 0x06051FEA,r12
    c.r[12] += c.r[14];  // 06051E88 add r14,r12
    st32(c.r[12], c.r[5]);  // 06051E8A mov.l r5,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FE8u);  // 06051E8C mov.w 0x06051FE8,r0
    c.r[0] += c.r[14];  // 06051E8E add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FECu);  // 06051E90 mov.w 0x06051FEC,r12
    c.r[0] = ld32(c.r[0]);  // 06051E92 mov.l @r0,r0
    c.r[12] += c.r[14];  // 06051E94 add r14,r12
    c.r[0] &= 0x80u;  // 06051E96 and #128,r0
    st32(c.r[12], c.r[0]);  // 06051E98 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FE8u);  // 06051E9A mov.w 0x06051FE8,r0
    c.r[0] += c.r[14];  // 06051E9C add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FE8u);  // 06051E9E mov.w 0x06051FE8,r12
    c.r[0] = ld32(c.r[0]);  // 06051EA0 mov.l @r0,r0
    c.r[12] += c.r[14];  // 06051EA2 add r14,r12
    c.r[0] &= 0x7Fu;  // 06051EA4 and #127,r0
    st32(c.r[12], c.r[0]);  // 06051EA6 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051EA8 mov.w 0x06051FEA,r0
    c.r[0] += c.r[14];  // 06051EAA add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FEEu);  // 06051EAC mov.w 0x06051FEE,r12
    c.r[0] = ld32(c.r[0]);  // 06051EAE mov.l @r0,r0
    c.r[12] += c.r[14];  // 06051EB0 add r14,r12
    c.r[0] &= 0x7Fu;  // 06051EB2 and #127,r0
    st32(c.r[12], c.r[0]);  // 06051EB4 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051EB6 mov.w 0x06051FEA,r0
    c.r[0] += c.r[14];  // 06051EB8 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051EBA mov.w 0x06051FEA,r12
    c.r[0] = ld32(c.r[0]);  // 06051EBC mov.l @r0,r0
    c.r[12] += c.r[14];  // 06051EBE add r14,r12
    c.r[0] &= 0x80u;  // 06051EC0 and #128,r0
    st32(c.r[12], c.r[0]);  // 06051EC2 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051EC4 mov.w 0x06051FEA,r12
    c.r[12] += c.r[14];  // 06051EC6 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06051EC8 mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06051ECA tst r12,r12
    { const bool k = c.t; c.r[13] = c.r[6] & 0xFFu; if (k) { goto L_06051EEC; } }  // 06051ECC bt/s 0x06051EEC ; extu.b r6,r13
    c.r[1] = ld32(0x06051FFCu);  // 06051ED0 mov.l 0x06051FFC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEEu);  // 06051ED2 mov.w 0x06051FEE,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 06051ED4 mov.l @(r0,r14),r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051ED6 mov.w 0x06051FEA,r12
    c.r[1] = ld32(c.r[1]);  // 06051ED8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06051EDA shll2 r2
    c.r[2] <<= 2;  // 06051EDC shll2 r2
    c.r[2] += c.r[1];  // 06051EDE add r1,r2
    c.r[2] += 8;  // 06051EE0 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06051EE2 mov.b @r2,r1
    c.r[12] += c.r[14];  // 06051EE4 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06051EE6 extu.b r1,r1
    st32(c.r[12], c.r[1]); goto L_06051EF4;  // 06051EE8 bra 0x06051EF4 ; mov.l r1,@r12
L_06051EEC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEEu);  // 06051EEC mov.w 0x06051FEE,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06051EEE mov.l @(r0,r14),r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051EF0 mov.w 0x06051FEA,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06051EF2 mov.l r12,@(r0,r14)
L_06051EF4:
    c.r[0] = ld32(0x06051FFCu);  // 06051EF4 mov.l 0x06051FFC,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FE8u);  // 06051EF6 mov.w 0x06051FE8,r12
    c.r[12] += c.r[14];  // 06051EF8 add r14,r12
    c.r[1] = ld32(c.r[0]);  // 06051EFA mov.l @r0,r1
    c.r[8] = ld32(0x06052000u);  // 06051EFC mov.l 0x06052000,r8
    c.r[0] = ld32(c.r[12]);  // 06051EFE mov.l @r12,r0
    c.r[4] = c.r[14];  // 06051F00 mov r14,r4
    c.r[0] <<= 2;  // 06051F02 shll2 r0
    c.r[0] <<= 2;  // 06051F04 shll2 r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FF0u);  // 06051F06 mov.w 0x06051FF0,r12
    c.r[12] += c.r[14];  // 06051F08 add r14,r12
    st32(c.r[12], c.r[0]);  // 06051F0A mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FF0u);  // 06051F0C mov.w 0x06051FF0,r12
    c.r[12] += c.r[14];  // 06051F0E add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06051F10 mov.l @r12,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FE8u);  // 06051F12 mov.w 0x06051FE8,r0
    c.r[1] += c.r[12];  // 06051F14 add r12,r1
    c.r[1] += 2;  // 06051F16 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051F18 mov.b @r1,r5
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 06051F1A mov.l @(r0,r14),r6
    { const uint32_t x = c.r[8]; c.pr = 0x06051F20u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051F20u) return; }  // 06051F1C jsr @r8 ; extu.b r5,r5
    c.r[12] = ld32(0x06051FFCu);  // 06051F20 mov.l 0x06051FFC,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051F22 mov.w 0x06051FEA,r0
    c.r[0] += c.r[14];  // 06051F24 add r14,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x06051FF2u);  // 06051F26 mov.w 0x06051FF2,r4
    c.r[11] = ld32(c.r[0]);  // 06051F28 mov.l @r0,r11
    c.r[4] += c.r[14];  // 06051F2A add r14,r4
    c.r[1] = ld32(c.r[12]);  // 06051F2C mov.l @r12,r1
    c.r[11] <<= 2;  // 06051F2E shll2 r11
    c.r[11] <<= 2;  // 06051F30 shll2 r11
    c.r[1] += c.r[11];  // 06051F32 add r11,r1
    c.r[1] += 2;  // 06051F34 add #2,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FEAu);  // 06051F36 mov.w 0x06051FEA,r12
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051F38 mov.b @r1,r5
    c.r[12] += c.r[14];  // 06051F3A add r14,r12
    c.r[6] = ld32(c.r[12]);  // 06051F3C mov.l @r12,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06051F42u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051F42u) return; }  // 06051F3E jsr @r8 ; extu.b r5,r5
    c.r[0] = ld32(0x06051FFCu);  // 06051F42 mov.l 0x06051FFC,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06051FF0u);  // 06051F44 mov.w 0x06051FF0,r12
    c.r[12] += c.r[14];  // 06051F46 add r14,r12
    c.r[1] = ld32(c.r[0]);  // 06051F48 mov.l @r0,r1
    c.r[9] = ld32(0x06052004u);  // 06051F4A mov.l 0x06052004,r9
    c.r[12] = ld32(c.r[12]);  // 06051F4C mov.l @r12,r12
    c.r[8] = 0x1Eu;  // 06051F4E mov #30,r8
    c.r[1] += c.r[12];  // 06051F50 add r12,r1
    c.r[1] += 2;  // 06051F52 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051F54 mov.b @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06051FF4u);  // 06051F56 mov.w 0x06051FF4,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06051F58 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 06051F5A mul.l r8,r1
    c.r[4] += c.r[14];  // 06051F5C add r14,r4
    c.r[2] = ld32(c.r[9]);  // 06051F5E mov.l @r9,r2
    c.r[1] = c.macl;  // 06051F60 sts macl,r1
    c.r[1] += c.r[2];  // 06051F62 add r2,r1
    c.r[1] += 15;  // 06051F64 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051F66 mov.b @r1,r5
    c.r[10] = ld32(0x06052008u);  // 06051F68 mov.l 0x06052008,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06051F6Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051F6Eu) return; }  // 06051F6A jsr @r10 ; extu.b r5,r5
    c.r[0] = ld32(0x06051FFCu);  // 06051F6E mov.l 0x06051FFC,r0
    c.r[1] = ld32(c.r[0]);  // 06051F70 mov.l @r0,r1
    c.r[11] += c.r[1];  // 06051F72 add r1,r11
    c.r[11] += 2;  // 06051F74 add #2,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06051F76 mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051F78 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 06051F7A mul.l r8,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06051FF6u);  // 06051F7C mov.w 0x06051FF6,r4
    c.r[2] = ld32(c.r[9]);  // 06051F7E mov.l @r9,r2
    c.r[1] = c.macl;  // 06051F80 sts macl,r1
    c.r[1] += c.r[2];  // 06051F82 add r2,r1
    c.r[1] += 15;  // 06051F84 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051F86 mov.b @r1,r5
    c.r[4] += c.r[14];  // 06051F88 add r14,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06051F8Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06051F8Eu) return; }  // 06051F8A jsr @r10 ; extu.b r5,r5
    c.r[2] = c.r[13];  // 06051F8E mov r13,r2
    c.r[2] <<= 2;  // 06051F90 shll2 r2
    c.r[2] += c.r[13];  // 06051F92 add r13,r2
    c.r[2] <<= 2;  // 06051F94 shll2 r2
    c.r[1] = c.r[14];  // 06051F96 mov r14,r1
    c.r[1] += 50;  // 06051F98 add #50,r1
    c.r[0] = c.r[1];  // 06051F9A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06051F9C mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06051F9E extu.b r1,r1
    c.r[1] >>= 2;  // 06051FA0 shlr2 r1
    c.r[1] >>= 2;  // 06051FA2 shlr2 r1
    c.r[1] >>= 2;  // 06051FA4 shlr2 r1
    c.r[0] = c.r[1];  // 06051FA6 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06051FA8 cmp/eq #1,r0
    if (!c.t) { goto L_06052010; }  // 06051FAA bf 0x06052010
    c.r[5] = ld32(0x0605200Cu);  // 06051FAC mov.l 0x0605200C,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06051FEEu);  // 06051FAE mov.w 0x06051FEE,r0
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 06051FB0 mov.l @(r0,r14),r3
    c.r[12] = ld32(0x06051FFCu);  // 06051FB2 mov.l 0x06051FFC,r12
    c.r[7] = ld32(c.r[12]);  // 06051FB4 mov.l @r12,r7
    c.r[3] <<= 2;  // 06051FB6 shll2 r3
    c.r[3] <<= 2;  // 06051FB8 shll2 r3
    c.r[6] = c.r[3];  // 06051FBA mov r3,r6
    c.r[6] += c.r[7];  // 06051FBC add r7,r6
    c.r[1] = c.r[6];  // 06051FBE mov r6,r1
    c.r[1] += 1;  // 06051FC0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06051FC2 mov.b @r1,r2
    c.r[0] = c.r[3];  // 06051FC4 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06051FC6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06051FC8 mov.b @(r0,r7),r1
    c.r[2] <<= 2;  // 06051FCA shll2 r2
    c.r[2] <<= 2;  // 06051FCC shll2 r2
    c.r[2] <<= 2;  // 06051FCE shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06051FF8u);  // 06051FD0 mov.w 0x06051FF8,r3
    c.r[0] = c.r[5];  // 06051FD2 mov r5,r0
    c.r[3] = ld32(c.r[0] + c.r[3]);  // 06051FD4 mov.l @(r0,r3),r3
    c.r[1] = c.r[1] & 0xFFu;  // 06051FD6 extu.b r1,r1
    c.r[2] += c.r[3];  // 06051FD8 add r3,r2
    c.r[0] = c.r[2];  // 06051FDA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06051FDC mov.b @(r0,r1),r1
    c.r[6] += 3;  // 06051FDE add #3,r6
    c.r[11] = c.r[1] & 0xFFu;  // 06051FE0 extu.b r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]); goto L_06052048;  // 06051FE2 bra 0x06052048 ; mov.b @r6,r1
L_06052010:
    c.r[0] = ld32(0x0605217Cu);  // 06052010 mov.l 0x0605217C,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605216Eu);  // 06052012 mov.w 0x0605216E,r12
    c.r[3] = ld32(c.r[0]);  // 06052014 mov.l @r0,r3
    c.r[12] += c.r[14];  // 06052016 add r14,r12
    c.r[7] = ld32(c.r[12]);  // 06052018 mov.l @r12,r7
    c.r[6] = ld32(0x06052180u);  // 0605201A mov.l 0x06052180,r6
    c.r[7] += c.r[3];  // 0605201C add r3,r7
    c.r[1] = c.r[7];  // 0605201E mov r7,r1
    c.r[1] += 1;  // 06052020 add #1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605216Eu);  // 06052022 mov.w 0x0605216E,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052024 mov.b @r1,r2
    c.r[12] += c.r[14];  // 06052026 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06052028 mov.l @r12,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0605202A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605202C mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 0605202E shll2 r2
    c.r[2] <<= 2;  // 06052030 shll2 r2
    c.r[2] <<= 2;  // 06052032 shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06052170u);  // 06052034 mov.w 0x06052170,r3
    c.r[0] = c.r[6];  // 06052036 mov r6,r0
    c.r[3] = ld32(c.r[0] + c.r[3]);  // 06052038 mov.l @(r0,r3),r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605203A extu.b r1,r1
    c.r[2] += c.r[3];  // 0605203C add r3,r2
    c.r[0] = c.r[2];  // 0605203E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052040 mov.b @(r0,r1),r1
    c.r[7] += 3;  // 06052042 add #3,r7
    c.r[11] = c.r[1] & 0xFFu;  // 06052044 extu.b r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06052046 mov.b @r7,r1
L_06052048:
    c.r[12] = 0x3u;  // 06052048 mov #3,r12
    c.r[9] = c.r[1];  // 0605204A mov r1,r9
    c.r[9] >>= 2;  // 0605204C shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0605204E shlr r9
    c.r[9] &= c.r[12];  // 06052050 and r12,r9
    c.r[5] = ld32(0x06052180u);  // 06052052 mov.l 0x06052180,r5
    c.r[1] = ld32(0x0605217Cu);  // 06052054 mov.l 0x0605217C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052172u);  // 06052056 mov.w 0x06052172,r0
    c.r[0] += c.r[14];  // 06052058 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052174u);  // 0605205A mov.w 0x06052174,r12
    c.r[3] = ld32(c.r[0]);  // 0605205C mov.l @r0,r3
    c.r[12] += c.r[14];  // 0605205E add r14,r12
    c.r[7] = ld32(c.r[1]);  // 06052060 mov.l @r1,r7
    c.r[3] <<= 2;  // 06052062 shll2 r3
    c.r[3] <<= 2;  // 06052064 shll2 r3
    c.r[6] = c.r[3];  // 06052066 mov r3,r6
    c.r[6] += c.r[7];  // 06052068 add r7,r6
    c.r[1] = c.r[6];  // 0605206A mov r6,r1
    c.r[1] += 1;  // 0605206C add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605206E mov.b @r1,r2
    c.r[0] = c.r[3];  // 06052070 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06052072 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06052074 mov.b @(r0,r7),r1
    c.r[2] <<= 2;  // 06052076 shll2 r2
    c.r[2] <<= 2;  // 06052078 shll2 r2
    c.r[2] <<= 2;  // 0605207A shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06052170u);  // 0605207C mov.w 0x06052170,r3
    c.r[0] = c.r[5];  // 0605207E mov r5,r0
    c.r[3] = ld32(c.r[0] + c.r[3]);  // 06052080 mov.l @(r0,r3),r3
    c.r[1] = c.r[1] & 0xFFu;  // 06052082 extu.b r1,r1
    c.r[2] += c.r[3];  // 06052084 add r3,r2
    c.r[0] = c.r[2];  // 06052086 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052088 mov.b @(r0,r1),r1
    c.r[6] += 3;  // 0605208A add #3,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0605208C extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 0605208E mov.l r1,@r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06052090 mov.b @r6,r1
    c.r[0] = 0x3u;  // 06052092 mov #3,r0
    c.r[1] >>= 2;  // 06052094 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06052096 shlr r1
    c.r[1] &= c.r[0];  // 06052098 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605209A tst r1,r1
    { const bool k = c.t; c.r[12] = 0x64u; if (k) { goto L_060520C8; } }  // 0605209C bt/s 0x060520C8 ; mov #100,r12
    c.r[4] = ld32(0x06052184u);  // 060520A0 mov.l 0x06052184,r4
    c.r[8] = ld32(0x06052188u);  // 060520A2 mov.l 0x06052188,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060520A8u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060520A8u) return; }  // 060520A4 jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 060520A8 mov r0,r1
    c.r[5] = 0x3u;  // 060520AA mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060520B0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060520B0u) return; }  // 060520AC jsr @r8 ; mov r1,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052174u);  // 060520B0 mov.w 0x06052174,r12
    c.r[12] += c.r[14];  // 060520B2 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 060520B4 mov.l @r12,r1
    c.r[2] = c.r[0];  // 060520B6 mov r0,r2
    c.r[1] += c.r[1];  // 060520B8 add r1,r1
    c.r[0] = c.r[1];  // 060520BA mov r1,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052176u);  // 060520BC mov.w 0x06052176,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060520BE mov.b @(r0,r2),r1
    c.r[12] += c.r[14];  // 060520C0 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060520C2 extu.b r1,r1
    st32(c.r[12], c.r[1]); goto L_060520CC;  // 060520C4 bra 0x060520CC ; mov.l r1,@r12
L_060520C8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052176u);  // 060520C8 mov.w 0x06052176,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 060520CA mov.l r12,@(r0,r14)
L_060520CC:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060520CC tst r9,r9
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_060520DE; } }  // 060520CE bt/s 0x060520DE ; mov #1,r4
    c.r[0] = c.r[9];  // 060520D2 mov r9,r0
    c.t = c.r[0] == 0x1u;  // 060520D4 cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06052128; } }  // 060520D6 bt/s 0x06052128 ; mov #0,r10
    c.r[0] = c.r[10]; goto L_060521F0;  // 060520DA bra 0x060521F0 ; mov r10,r0
L_060520DE:
    c.r[1] = ld32(0x0605218Cu);  // 060520DE mov.l 0x0605218C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060520E0 mov.b @r1,r0
    c.r[1] = 0xFu;  // 060520E2 mov #15,r1
    c.r[1] &= c.r[0];  // 060520E4 and r0,r1
    c.r[0] = ld32(0x06052190u);  // 060520E6 mov.l 0x06052190,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060520ECu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060520ECu) return; }  // 060520E8 jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06052178u);  // 060520EC mov.w 0x06052178,r4
    c.r[1] = ld32(0x06052194u);  // 060520EE mov.l 0x06052194,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060520F4u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060520F4u) return; }  // 060520F0 jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 060520F4 mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605217Au);  // 060520F6 mov.w 0x0605217A,r4
    c.r[1] = ld32(0x06052198u);  // 060520F8 mov.l 0x06052198,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060520FEu; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060520FEu) return; }  // 060520FA jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 060520FE or r4,r2
    c.r[0] &= 0x80u;  // 06052100 and #128,r0
    c.r[1] = ld32(0x0605219Cu);  // 06052102 mov.l 0x0605219C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052108u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052108u) return; }  // 06052104 jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 06052108 or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605210A tst r2,r2
    { const bool k = !c.t; c.r[2] = c.r[13]; if (k) { goto L_06052128; } }  // 0605210C bf/s 0x06052128 ; mov r13,r2
    c.r[2] <<= 2;  // 06052110 shll2 r2
    c.r[2] += c.r[13];  // 06052112 add r13,r2
    c.r[2] <<= 2;  // 06052114 shll2 r2
    c.r[1] = c.r[14];  // 06052116 mov r14,r1
    c.r[1] += 56;  // 06052118 add #56,r1
    c.r[0] = c.r[1];  // 0605211A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605211C mov.b @(r0,r2),r1
    c.r[12] = 0x3u;  // 0605211E mov #3,r12
    c.r[10] = c.r[1];  // 06052120 mov r1,r10
    c.r[10] >>= 2;  // 06052122 shlr2 r10
    c.r[10] &= c.r[12]; goto L_060521EE;  // 06052124 bra 0x060521EE ; and r12,r10
L_06052128:
    c.r[1] = ld32(0x0605218Cu);  // 06052128 mov.l 0x0605218C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605212A mov.b @r1,r0
    c.r[4] = 0x1u;  // 0605212C mov #1,r4
    c.r[1] = 0xFu;  // 0605212E mov #15,r1
    c.r[1] &= c.r[0];  // 06052130 and r0,r1
    c.r[0] = ld32(0x06052190u);  // 06052132 mov.l 0x06052190,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06052138u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052138u) return; }  // 06052134 jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06052178u);  // 06052138 mov.w 0x06052178,r4
    c.r[1] = ld32(0x06052194u);  // 0605213A mov.l 0x06052194,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052140u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052140u) return; }  // 0605213C jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 06052140 mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605217Au);  // 06052142 mov.w 0x0605217A,r4
    c.r[1] = ld32(0x06052198u);  // 06052144 mov.l 0x06052198,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605214Au; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605214Au) return; }  // 06052146 jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 0605214A or r4,r2
    c.r[0] &= 0x80u;  // 0605214C and #128,r0
    c.r[1] = ld32(0x0605219Cu);  // 0605214E mov.l 0x0605219C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052154u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052154u) return; }  // 06052150 jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 06052154 or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06052156 tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_060521A0; } }  // 06052158 bt/s 0x060521A0 ; mov r13,r0
    c.r[0] <<= 2;  // 0605215C shll2 r0
    c.r[0] += c.r[13];  // 0605215E add r13,r0
    c.r[0] <<= 2;  // 06052160 shll2 r0
    c.r[1] = c.r[14];  // 06052162 mov r14,r1
    c.r[1] += 56;  // 06052164 add #56,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052166 mov.b @(r0,r1),r0
    c.r[10] = 0x3u;  // 06052168 mov #3,r10
    c.r[10] &= c.r[0]; goto L_060521EE;  // 0605216A bra 0x060521EE ; and r0,r10
L_060521A0:
    c.r[4] = ld32(0x06052214u);  // 060521A0 mov.l 0x06052214,r4
    c.r[8] = ld32(0x06052218u);  // 060521A2 mov.l 0x06052218,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060521A8u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060521A8u) return; }  // 060521A4 jsr @r8 ; mov #34,r5
    c.r[5] = 0x1u;  // 060521A8 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060521AEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060521AEu) return; }  // 060521AA jsr @r8 ; mov r0,r4
    c.r[5] = 0x3u;  // 060521AE mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060521B4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060521B4u) return; }  // 060521B0 jsr @r8 ; mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060521B4 mov.b @(r0,r11),r0
    c.r[0] &= 0x40u;  // 060521B6 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060521B8 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_060521DA; } }  // 060521BA bt/s 0x060521DA ; mov r13,r0
    c.r[2] = c.r[13];  // 060521BE mov r13,r2
    c.r[2] <<= 2;  // 060521C0 shll2 r2
    c.r[2] += c.r[13];  // 060521C2 add r13,r2
    c.r[2] <<= 2;  // 060521C4 shll2 r2
    c.r[1] = c.r[14];  // 060521C6 mov r14,r1
    c.r[1] += 56;  // 060521C8 add #56,r1
    c.r[0] = c.r[1];  // 060521CA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060521CC mov.b @(r0,r2),r1
    c.r[12] = 0x3u;  // 060521CE mov #3,r12
    c.r[10] = c.r[1];  // 060521D0 mov r1,r10
    c.r[10] >>= 2;  // 060521D2 shlr2 r10
    c.r[10] >>= 2;  // 060521D4 shlr2 r10
    c.r[10] &= c.r[12]; goto L_060521EE;  // 060521D6 bra 0x060521EE ; and r12,r10
L_060521DA:
    c.r[0] <<= 2;  // 060521DA shll2 r0
    c.r[0] += c.r[13];  // 060521DC add r13,r0
    c.r[0] <<= 2;  // 060521DE shll2 r0
    c.r[1] = c.r[14];  // 060521E0 mov r14,r1
    c.r[1] += 56;  // 060521E2 add #56,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060521E4 mov.b @(r0,r1),r1
    c.r[10] = c.r[1] & 0xFFu;  // 060521E6 extu.b r1,r10
    c.r[10] >>= 2;  // 060521E8 shlr2 r10
    c.r[10] >>= 2;  // 060521EA shlr2 r10
    c.r[10] >>= 2;  // 060521EC shlr2 r10
L_060521EE:
    c.r[0] = c.r[10];  // 060521EE mov r10,r0
L_060521F0:
    c.t = c.r[0] == 0x2u;  // 060521F0 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0605220E; } }  // 060521F2 bt/s 0x0605220E ; mov #2,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060521F6 cmp/gt r1,r10
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06052206; } }  // 060521F8 bt/s 0x06052206 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060521FC cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0x28u; if (k) { goto L_0605221E; } }  // 060521FE bt/s 0x0605221E ; mov #40,r10
    c.r[10] = 0x0u; goto L_0605221E;  // 06052202 bra 0x0605221E ; mov #0,r10
L_06052206:
    { const bool k = !c.t; c.r[10] = 0x64u; if (k) { goto L_0605221C; } }  // 06052206 bf/s 0x0605221C ; mov #100,r10
    goto L_0605221E;  // 0605220A bra 0x0605221E ; nop
L_0605220E:
    c.r[10] = 0x46u; goto L_0605221E;  // 0605220E bra 0x0605221E ; mov #70,r10
L_0605221C:
    c.r[10] = 0x0u;  // 0605221C mov #0,r10
L_0605221E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060523F8u);  // 0605221E mov.w 0x060523F8,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FAu);  // 06052220 mov.w 0x060523FA,r12
    c.r[12] += c.r[14];  // 06052222 add r14,r12
    st32(c.r[12], c.r[0]);  // 06052224 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FAu);  // 06052226 mov.w 0x060523FA,r12
    c.r[12] += c.r[14];  // 06052228 add r14,r12
    c.r[8] = ld32(0x06052410u);  // 0605222A mov.l 0x06052410,r8
    c.r[7] = c.r[11];  // 0605222C mov r11,r7
    c.r[0] = ld32(c.r[12]);  // 0605222E mov.l @r12,r0
    c.r[6] = c.r[9];  // 06052230 mov r9,r6
    c.r[0] += c.r[14];  // 06052232 add r14,r0
    st32(c.r[12], c.r[0]);  // 06052234 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FAu);  // 06052236 mov.w 0x060523FA,r12
    c.r[12] += c.r[14];  // 06052238 add r14,r12
    c.r[5] = ld32(c.r[12]);  // 0605223A mov.l @r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06052240u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052240u) return; }  // 0605223C jsr @r8 ; mov r14,r4
    c.r[1] = c.r[0];  // 06052240 mov r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FCu);  // 06052242 mov.w 0x060523FC,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x060523FEu);  // 06052244 mov.w 0x060523FE,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06052246 mov.l r12,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060523FEu);  // 06052248 mov.w 0x060523FE,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 0605224A mov.l @(r0,r14),r12
    c.r[12] += c.r[14];  // 0605224C add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052400u);  // 0605224E mov.w 0x06052400,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06052250 mov.l r12,@(r0,r14)
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FEu);  // 06052252 mov.w 0x060523FE,r12
    c.r[12] += c.r[14];  // 06052254 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06052256 mov.l @r12,r0
    st8(c.r[0] + c.r[14], c.r[1]);  // 06052258 mov.b r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052402u);  // 0605225A mov.w 0x06052402,r0
    c.r[0] += c.r[14];  // 0605225C add r14,r0
    c.r[12] = ld32(c.r[0]);  // 0605225E mov.l @r0,r12
    c.r[1] = ld32(0x06052414u);  // 06052260 mov.l 0x06052414,r1
    c.r[1] = ld32(c.r[1]);  // 06052262 mov.l @r1,r1
    c.r[12] <<= 2;  // 06052264 shll2 r12
    c.r[12] <<= 2;  // 06052266 shll2 r12
    st32(c.r[0], c.r[12]);  // 06052268 mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052402u);  // 0605226A mov.w 0x06052402,r0
    c.r[0] += c.r[14];  // 0605226C add r14,r0
    c.r[12] = ld32(c.r[0]);  // 0605226E mov.l @r0,r12
    c.r[12] += c.r[1];  // 06052270 add r1,r12
    st32(c.r[0], c.r[12]);  // 06052272 mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052402u);  // 06052274 mov.w 0x06052402,r0
    c.r[0] += c.r[14];  // 06052276 add r14,r0
    c.r[12] = ld32(c.r[0]);  // 06052278 mov.l @r0,r12
    c.r[12] += 3;  // 0605227A add #3,r12
    st32(c.r[0], c.r[12]);  // 0605227C mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052402u);  // 0605227E mov.w 0x06052402,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06052280 mov.l @(r0,r14),r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06052282 mov.b @r12,r1
    c.r[0] = 0x3u;  // 06052284 mov #3,r0
    c.r[1] >>= 2;  // 06052286 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06052288 shlr r1
    c.r[1] &= c.r[0];  // 0605228A and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052404u);  // 0605228C mov.w 0x06052404,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052406u);  // 0605228E mov.w 0x06052406,r12
    c.r[12] += c.r[14];  // 06052290 add r14,r12
    st32(c.r[12], c.r[0]);  // 06052292 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052406u);  // 06052294 mov.w 0x06052406,r12
    c.r[12] += c.r[14];  // 06052296 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06052298 mov.l @r12,r0
    c.r[0] += c.r[14];  // 0605229A add r14,r0
    st32(c.r[12], c.r[0]);  // 0605229C mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052408u);  // 0605229E mov.w 0x06052408,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605240Au);  // 060522A0 mov.w 0x0605240A,r12
    c.r[12] += c.r[14];  // 060522A2 add r14,r12
    st32(c.r[12], c.r[0]);  // 060522A4 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605240Au);  // 060522A6 mov.w 0x0605240A,r12
    c.r[12] += c.r[14];  // 060522A8 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060522AA mov.l @r12,r0
    c.r[0] += c.r[14];  // 060522AC add r14,r0
    st32(c.r[12], c.r[0]);  // 060522AE mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605240Cu);  // 060522B0 mov.w 0x0605240C,r12
    c.r[12] += c.r[14];  // 060522B2 add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052406u);  // 060522B4 mov.w 0x06052406,r0
    c.r[7] = ld32(c.r[12]);  // 060522B6 mov.l @r12,r7
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 060522B8 mov.l @(r0,r14),r5
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605240Au);  // 060522BA mov.w 0x0605240A,r12
    c.r[12] += c.r[14];  // 060522BC add r14,r12
    c.r[4] = ld32(c.r[12]);  // 060522BE mov.l @r12,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060522C4u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060522C4u) return; }  // 060522C0 jsr @r8 ; mov r1,r6
    c.r[1] = c.r[0];  // 060522C4 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052400u);  // 060522C6 mov.w 0x06052400,r0
    c.r[0] += c.r[14];  // 060522C8 add r14,r0
    c.r[8] = c.r[13];  // 060522CA mov r13,r8
    c.r[8] <<= 2;  // 060522CC shll2 r8
    c.r[8] += c.r[13];  // 060522CE add r13,r8
    c.r[12] = ld32(c.r[0]);  // 060522D0 mov.l @r0,r12
    c.r[8] <<= 2;  // 060522D2 shll2 r8
    c.r[12] += 1;  // 060522D4 add #1,r12
    st32(c.r[0], c.r[12]);  // 060522D6 mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052400u);  // 060522D8 mov.w 0x06052400,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 060522DA mov.l @(r0,r14),r12
    c.r[4] = 0x0u;  // 060522DC mov #0,r4
    st8(c.r[12], c.r[1]);  // 060522DE mov.b r1,@r12
    c.r[1] = c.r[14];  // 060522E0 mov r14,r1
    c.r[1] += 48;  // 060522E2 add #48,r1
    c.r[0] = c.r[1];  // 060522E4 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 060522E6 mov.w @(r0,r8),r1
    c.r[12] = ld32(0x06052418u);  // 060522E8 mov.l 0x06052418,r12
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[14]);  // 060522EA mov.w @r14,r5
    c.r[9] = c.r[1] & 0xFFFFu;  // 060522EC extu.w r1,r9
    { const uint32_t x = c.r[12]; c.pr = 0x060522F2u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060522F2u) return; }  // 060522EE jsr @r12 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 060522F2 mov r0,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060522F4 extu.w r1,r3
    c.r[1] = ld32(0x0605241Cu);  // 060522F6 mov.l 0x0605241C,r1
    c.t = c.r[3] == c.r[1];  // 060522F8 cmp/eq r1,r3
    { const bool k = c.t; c.macl = c.r[9] * c.r[10]; if (k) { goto L_0605234A; } }  // 060522FA bt/s 0x0605234A ; mul.l r10,r9
    c.r[1] = ld32(0x06052420u);  // 060522FE mov.l 0x06052420,r1
    c.r[2] = ld32(c.r[1]);  // 06052300 mov.l @r1,r2
    c.r[3] <<= 2;  // 06052302 shll2 r3
    c.r[2] += c.r[3];  // 06052304 add r3,r2
    c.r[1] = c.r[2];  // 06052306 mov r2,r1
    c.r[1] += 22;  // 06052308 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605230A mov.b @r1,r0
    c.r[2] += 23;  // 0605230C add #23,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605230E mov.b @r2,r2
    c.r[0] &= 0x1Fu;  // 06052310 and #31,r0
    c.r[0] <<= 2;  // 06052312 shll2 r0
    c.r[0] += c.r[0];  // 06052314 add r0,r0
    c.r[0] <<= 2;  // 06052316 shll2 r0
    c.r[2] = c.r[2] & 0xFFu;  // 06052318 extu.b r2,r2
    c.r[2] >>= 2;  // 0605231A shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605231C shlr r2
    c.r[2] |= c.r[0];  // 0605231E or r0,r2
    c.r[2] -= 50;  // 06052320 add #-50,r2
    c.r[1] = c.r[2];  // 06052322 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06052324 rotl r1
    c.r[1] = c.t;  // 06052326 movt r1
    c.r[2] += c.r[1];  // 06052328 add r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605232A shar r2
    c.r[2] += 100;  // 0605232C add #100,r2
    c.macl = c.r[9] * c.r[2];  // 0605232E mul.l r2,r9
    c.r[1] = ld32(0x06052424u);  // 06052330 mov.l 0x06052424,r1
    c.r[2] = c.macl;  // 06052332 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06052334 dmuls.l r1,r2
    c.r[9] = c.mach;  // 06052336 sts mach,r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06052338 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 0605233A shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 0605233C shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 0605233E shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06052340 shar r9
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06052342 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06052344 subc r2,r2
    c.r[9] -= c.r[2];  // 06052346 sub r2,r9
    c.macl = c.r[9] * c.r[10];  // 06052348 mul.l r10,r9
L_0605234A:
    c.r[11] = ld32(0x06052424u);  // 0605234A mov.l 0x06052424,r11
    c.r[1] = c.macl;  // 0605234C sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0605234E dmuls.l r11,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FAu);  // 06052350 mov.w 0x060523FA,r12
    c.r[2] = c.mach;  // 06052352 sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06052354 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06052356 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06052358 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605235A shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605235C shar r2
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0605235E shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06052360 subc r1,r1
    c.r[2] -= c.r[1];  // 06052362 sub r1,r2
    c.r[1] = c.r[14];  // 06052364 mov r14,r1
    c.r[1] += 51;  // 06052366 add #51,r1
    c.r[0] = c.r[1];  // 06052368 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605236A mov.b @(r0,r8),r1
    c.r[12] += c.r[14];  // 0605236C add r14,r12
    c.r[12] = ld32(c.r[12]);  // 0605236E mov.l @r12,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06052370 extu.b r1,r1
    c.r[1] >>= 2;  // 06052372 shlr2 r1
    c.r[1] >>= 2;  // 06052374 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06052376 shlr r1
    c.r[1] >>= 2;  // 06052378 shlr2 r1
    c.r[1] += c.r[12];  // 0605237A add r12,r1
    c.r[1] += 14;  // 0605237C add #14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060523FAu);  // 0605237E mov.w 0x060523FA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052380 mov.b @r1,r1
    c.r[0] += c.r[14];  // 06052382 add r14,r0
    c.r[12] = ld32(c.r[0]);  // 06052384 mov.l @r0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06052386 extu.b r1,r1
    c.r[12] += 9;  // 06052388 add #9,r12
    st32(c.r[0], c.r[12]);  // 0605238A mov.l r12,@r0
    c.macl = c.r[2] * c.r[1];  // 0605238C mul.l r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060523FAu);  // 0605238E mov.w 0x060523FA,r0
    c.r[1] = c.macl;  // 06052390 sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06052392 dmuls.l r11,r1
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06052394 mov.l @(r0,r14),r12
    c.r[2] = c.mach;  // 06052396 sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06052398 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605239A shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605239C shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605239E shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060523A0 shar r2
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060523A2 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060523A4 subc r1,r1
    c.r[2] -= c.r[1];  // 060523A6 sub r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060523A8 mov.b @r12,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060523AA extu.b r1,r1
    c.macl = c.r[2] * c.r[1];  // 060523AC mul.l r1,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x060523FEu);  // 060523AE mov.w 0x060523FE,r12
    c.r[1] = c.macl;  // 060523B0 sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060523B2 dmuls.l r11,r1
    c.r[12] += c.r[14];  // 060523B4 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060523B6 mov.l @r12,r0
    c.r[2] = c.mach;  // 060523B8 sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060523BA shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060523BC shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060523BE shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060523C0 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060523C2 shar r2
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060523C4 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060523C6 subc r1,r1
    c.r[2] -= c.r[1];  // 060523C8 sub r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060523CA mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060523CC extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605240Au);  // 060523CE mov.w 0x0605240A,r0
    c.r[0] += c.r[14];  // 060523D0 add r14,r0
    c.r[12] = ld32(c.r[0]);  // 060523D2 mov.l @r0,r12
    c.macl = c.r[2] * c.r[1];  // 060523D4 mul.l r1,r2
    c.r[12] += 30;  // 060523D6 add #30,r12
    st32(c.r[0], c.r[12]);  // 060523D8 mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605240Au);  // 060523DA mov.w 0x0605240A,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 060523DC mov.l @(r0,r14),r12
    c.r[1] = c.macl;  // 060523DE sts macl,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052406u);  // 060523E0 mov.w 0x06052406,r0
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060523E2 dmuls.l r11,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[12]);  // 060523E4 mov.w @r12,r2
    c.r[0] += c.r[14];  // 060523E6 add r14,r0
    c.r[12] = ld32(c.r[0]);  // 060523E8 mov.l @r0,r12
    c.r[9] = c.mach;  // 060523EA sts mach,r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 060523EC shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 060523EE shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 060523F0 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 060523F2 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1); goto L_06052428;  // 060523F4 bra 0x06052428 ; shar r9
L_06052428:
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06052428 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0605242A subc r1,r1
    c.r[12] += 9;  // 0605242C add #9,r12
    st32(c.r[0], c.r[12]);  // 0605242E mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605250Au);  // 06052430 mov.w 0x0605250A,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06052432 mov.l @(r0,r14),r12
    c.r[9] -= c.r[1];  // 06052434 sub r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06052436 mov.b @r12,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06052438 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605243A extu.b r1,r1
    c.macl = c.r[2] * c.r[1];  // 0605243C mul.l r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605250Cu);  // 0605243E mov.w 0x0605250C,r0
    c.r[1] = c.macl;  // 06052440 sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06052442 dmuls.l r11,r1
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06052444 mov.l @(r0,r14),r12
    c.r[2] = c.mach;  // 06052446 sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06052448 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605244A shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605244C shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0605244E shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06052450 shar r2
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06052452 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06052454 subc r1,r1
    c.r[2] -= c.r[1];  // 06052456 sub r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06052458 mov.b @r12,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605245A extu.b r1,r1
    c.macl = c.r[2] * c.r[1];  // 0605245C mul.l r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605250Eu);  // 0605245E mov.w 0x0605250E,r0
    c.r[2] = c.macl;  // 06052460 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06052462 dmuls.l r11,r2
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06052464 mov.l @(r0,r14),r0
    c.r[1] = c.mach;  // 06052466 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06052468 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605246A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605246C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605246E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06052470 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06052472 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06052474 subc r2,r2
    c.r[1] -= c.r[2];  // 06052476 sub r2,r1
    c.r[9] -= c.r[1];  // 06052478 sub r1,r9
    c.macl = c.r[9] * c.r[0];  // 0605247A mul.l r0,r9
    c.r[1] = c.macl;  // 0605247C sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0605247E dmuls.l r11,r1
    c.r[9] = c.mach;  // 06052480 sts mach,r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06052482 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06052484 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06052486 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06052488 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 0605248A shar r9
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0605248C shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0605248E subc r1,r1
    c.r[9] -= c.r[1];  // 06052490 sub r1,r9
    c.t = (int32_t)c.r[9] >= 0;  // 06052492 cmp/pz r9
    if (c.t) { goto L_06052498; }  // 06052494 bt 0x06052498
    c.r[9] = 0x0u;  // 06052496 mov #0,r9
L_06052498:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052510u);  // 06052498 mov.w 0x06052510,r12
    c.r[12] += c.r[14];  // 0605249A add r14,r12
    c.r[12] = ld32(c.r[12]);  // 0605249C mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 0605249E tst r12,r12
    if (c.t) { goto L_060524A4; }  // 060524A0 bt 0x060524A4
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 060524A2 shar r9
L_060524A4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052512u);  // 060524A4 mov.w 0x06052512,r0
    c.r[0] += c.r[14];  // 060524A6 add r14,r0
    c.r[8] = ld32(0x06052518u);  // 060524A8 mov.l 0x06052518,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060524AEu; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060524AEu) return; }  // 060524AA jsr @r8 ; mov.l @r0,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06052514u);  // 060524AE mov.w 0x06052514,r12
    c.r[12] += c.r[14];  // 060524B0 add r14,r12
    c.r[4] = ld32(c.r[12]);  // 060524B2 mov.l @r12,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060524B8u; c.r[10] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060524B8u) return; }  // 060524B4 jsr @r8 ; mov r0,r10
    c.r[1] = c.r[0];  // 060524B8 mov r0,r1
    c.r[2] = c.r[10] & 0xFFu;  // 060524BA extu.b r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060524BC extu.b r1,r1
    c.r[2] -= c.r[1];  // 060524BE sub r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060524C0 tst r2,r2
    { const bool k = c.t; c.r[1] = 0x9u; if (k) { goto L_060524E2; } }  // 060524C2 bt/s 0x060524E2 ; mov #9,r1
    c.macl = c.r[9] * c.r[2];  // 060524C6 mul.l r2,r9
    c.r[2] = c.macl;  // 060524C8 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060524CA dmuls.l r11,r2
    c.r[1] = c.mach;  // 060524CC sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060524CE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060524D0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060524D2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060524D4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060524D6 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060524D8 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060524DA subc r2,r2
    c.r[1] -= c.r[2];  // 060524DC sub r2,r1
    c.r[9] += c.r[1];  // 060524DE add r1,r9
    c.r[1] = 0x9u;  // 060524E0 mov #9,r1
L_060524E2:
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060524E2 cmp/gt r1,r9
    { const bool k = !c.t; c.r[0] = 0xAu; if (k) { goto L_060524F2; } }  // 060524E4 bf/s 0x060524F2 ; mov #10,r0
    c.r[1] = ld32(0x0605251Cu);  // 060524E8 mov.l 0x0605251C,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060524EA cmp/gt r1,r9
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_060524F2; } }  // 060524EC bt/s 0x060524F2 ; mov r1,r0
    c.r[0] = c.r[9];  // 060524F0 mov r9,r0
L_060524F2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06052516u);  // 060524F2 mov.w 0x06052516,r3
    c.r[14] += c.r[3];  // 060524F4 add r3,r14
    c.r[15] = c.r[14];  // 060524F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060524F8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060524FA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060524FC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060524FE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06052500 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06052502 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06052504 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052506 rts ; mov.l @r15+,r8
}

void f_06052520(SH2Context& c) {
    ran[1295] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06052520 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06052522 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06052524 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06052526 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052528 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605252A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605252C mov r15,r14
    c.r[9] = c.r[4];  // 0605252E mov r4,r9
    c.r[10] = c.r[5];  // 06052530 mov r5,r10
    c.r[0] = c.r[6] & 0xFFu;  // 06052532 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06052534 tst r0,r0
    { const bool k = c.t; c.r[11] = c.r[7] & 0xFFu; if (k) { goto L_06052544; } }  // 06052536 bt/s 0x06052544 ; extu.b r7,r11
    c.t = c.r[0] == 0x1u;  // 0605253A cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060525A4; } }  // 0605253C bt/s 0x060525A4 ; mov #0,r0
    c.r[1] = 0x3u; goto L_06052678;  // 06052540 bra 0x06052678 ; mov #3,r1
L_06052544:
    c.r[1] = ld32(0x06052658u);  // 06052544 mov.l 0x06052658,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052546 mov.b @r1,r0
    c.r[4] = 0x1u;  // 06052548 mov #1,r4
    c.r[1] = 0xFu;  // 0605254A mov #15,r1
    c.r[1] &= c.r[0];  // 0605254C and r0,r1
    c.r[0] = ld32(0x0605265Cu);  // 0605254E mov.l 0x0605265C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06052554u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052554u) return; }  // 06052550 jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06052654u);  // 06052554 mov.w 0x06052654,r4
    c.r[1] = ld32(0x06052660u);  // 06052556 mov.l 0x06052660,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605255Cu; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605255Cu) return; }  // 06052558 jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 0605255C mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06052656u);  // 0605255E mov.w 0x06052656,r4
    c.r[1] = ld32(0x06052664u);  // 06052560 mov.l 0x06052664,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052566u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052566u) return; }  // 06052562 jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 06052566 or r4,r2
    c.r[0] &= 0x80u;  // 06052568 and #128,r0
    c.r[1] = ld32(0x06052668u);  // 0605256A mov.l 0x06052668,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052570u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052570u) return; }  // 0605256C jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 06052570 or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06052572 tst r2,r2
    if (!c.t) { goto L_060525A4; }  // 06052574 bf 0x060525A4
    c.r[9] += 38;  // 06052576 add #38,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06052578 mov.b @r9,r1
    c.r[3] = 0x7u;  // 0605257A mov #7,r3
    c.r[2] = c.r[1];  // 0605257C mov r1,r2
    c.r[2] >>= 2;  // 0605257E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06052580 shlr r2
    c.r[2] &= c.r[3];  // 06052582 and r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06052584 tst r2,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06052676; } }  // 06052586 bt/s 0x06052676 ; mov #0,r0
    c.r[10] += 40;  // 0605258A add #40,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0605258C mov.w @r10,r1
    c.r[0] = c.r[1];  // 0605258E mov r1,r0
    c.r[0] >>= 2;  // 06052590 shlr2 r0
    c.r[0] >>= 2;  // 06052592 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06052594 shlr r0
    c.r[0] >>= 2;  // 06052596 shlr2 r0
    c.r[0] &= 0x7u;  // 06052598 and #7,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605259A tst r0,r0
    if (c.t) { goto L_06052674; }  // 0605259C bt 0x06052674
L_0605259E:
    c.r[0] += c.r[2];  // 0605259E add r2,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1; goto L_06052676;  // 060525A0 bra 0x06052676 ; shlr r0
L_060525A4:
    c.r[1] = ld32(0x06052658u);  // 060525A4 mov.l 0x06052658,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060525A6 mov.b @r1,r0
    c.r[4] = 0x1u;  // 060525A8 mov #1,r4
    c.r[1] = 0xFu;  // 060525AA mov #15,r1
    c.r[1] &= c.r[0];  // 060525AC and r0,r1
    c.r[0] = ld32(0x0605265Cu);  // 060525AE mov.l 0x0605265C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060525B4u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060525B4u) return; }  // 060525B0 jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06052654u);  // 060525B4 mov.w 0x06052654,r4
    c.r[1] = ld32(0x06052660u);  // 060525B6 mov.l 0x06052660,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060525BCu; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060525BCu) return; }  // 060525B8 jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 060525BC mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06052656u);  // 060525BE mov.w 0x06052656,r4
    c.r[1] = ld32(0x06052664u);  // 060525C0 mov.l 0x06052664,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060525C6u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060525C6u) return; }  // 060525C2 jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 060525C6 or r4,r2
    c.r[0] &= 0x80u;  // 060525C8 and #128,r0
    c.r[1] = ld32(0x06052668u);  // 060525CA mov.l 0x06052668,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060525D0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060525D0u) return; }  // 060525CC jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 060525D0 or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060525D2 tst r2,r2
    if (c.t) { goto L_060525FA; }  // 060525D4 bt 0x060525FA
    c.r[9] += 38;  // 060525D6 add #38,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060525D8 mov.b @r9,r0
    c.r[2] = 0x7u;  // 060525DA mov #7,r2
    c.r[2] &= c.r[0];  // 060525DC and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060525DE tst r2,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06052676; } }  // 060525E0 bt/s 0x06052676 ; mov #0,r0
    c.r[10] += 41;  // 060525E4 add #41,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060525E6 mov.b @r10,r1
    c.r[0] = c.r[1];  // 060525E8 mov r1,r0
    c.r[0] >>= 2;  // 060525EA shlr2 r0
    c.r[0] >>= 2;  // 060525EC shlr2 r0
L_060525EE:
    c.r[0] &= 0x7u;  // 060525EE and #7,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060525F0 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_0605259E; }  // 060525F2 bf 0x0605259E
    c.r[0] = 0x0u;  // 060525F4 mov #0,r0
    c.r[1] = 0x3u; goto L_06052678;  // 060525F6 bra 0x06052678 ; mov #3,r1
L_060525FA:
    c.r[4] = ld32(0x0605266Cu);  // 060525FA mov.l 0x0605266C,r4
    c.r[8] = ld32(0x06052670u);  // 060525FC mov.l 0x06052670,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06052602u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052602u) return; }  // 060525FE jsr @r8 ; mov #34,r5
    c.r[5] = 0x1u;  // 06052602 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06052608u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052608u) return; }  // 06052604 jsr @r8 ; mov r0,r4
    c.r[5] = 0x3u;  // 06052608 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605260Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605260Eu) return; }  // 0605260A jsr @r8 ; mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0605260E mov.b @(r0,r11),r0
    c.r[0] &= 0x40u;  // 06052610 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06052612 tst r0,r0
    if (c.t) { goto L_06052630; }  // 06052614 bt 0x06052630
    c.r[2] = ld32(c.r[9] + 36);  // 06052616 mov.l @(36,r9),r2
    c.r[3] = 0x7u;  // 06052618 mov #7,r3
    c.r[2] >>= 8;  // 0605261A shlr8 r2
    c.r[2] <<= 2;  // 0605261C shll2 r2
    c.r[2] >>= 8;  // 0605261E shlr8 r2
    c.r[2] &= c.r[3];  // 06052620 and r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06052622 tst r2,r2
    { const bool k = c.t; c.r[10] += 40; if (k) { goto L_06052674; } }  // 06052624 bt/s 0x06052674 ; add #40,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06052628 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0605262A mov r1,r0
    c.r[0] >>= 2; SH2_POLL(c); goto L_060525EE;  // 0605262C bra 0x060525EE ; shlr2 r0
L_06052630:
    c.r[9] += 37;  // 06052630 add #37,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06052632 mov.b @r9,r1
    c.r[0] = c.r[1];  // 06052634 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06052636 shlr r0
    c.r[0] &= 0x7u;  // 06052638 and #7,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605263A tst r0,r0
    { const bool k = c.t; c.r[10] += 40; if (k) { goto L_06052674; } }  // 0605263C bt/s 0x06052674 ; add #40,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06052640 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052642 extu.b r1,r1
    c.r[1] >>= 2;  // 06052644 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06052646 shlr r1
    c.r[1] >>= 2;  // 06052648 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605264A tst r1,r1
    { const bool k = c.t; c.r[0] += c.r[1]; if (k) { goto L_06052674; } }  // 0605264C bt/s 0x06052674 ; add r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1; goto L_06052676;  // 06052650 bra 0x06052676 ; shlr r0
L_06052674:
    c.r[0] = 0x0u;  // 06052674 mov #0,r0
L_06052676:
    c.r[1] = 0x3u;  // 06052676 mov #3,r1
L_06052678:
    c.r[0] -= 1;  // 06052678 add #-1,r0
    c.t = c.r[0] > c.r[1];  // 0605267A cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_060526A4; } }  // 0605267C bt/s 0x060526A4 ; mov r0,r1
    c.r[1] += c.r[1];  // 06052680 add r1,r1
    c.r[0] = 0x0605268Cu;  // 06052682 mova 0x0605268C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06052684 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06052686 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060526A0u: goto L_060526A0; case 0x0605269Cu: goto L_0605269C; case 0x06052698u: goto L_06052698; case 0x06052694u: goto L_06052694; default: sh2_call(c, x); return; } }  // 06052688 jmp @r0 ; nop
L_06052694:
    c.r[0] = 0x78u; goto L_060526A6;  // 06052694 bra 0x060526A6 ; mov #120,r0
L_06052698:
    c.r[0] = 0x64u; goto L_060526A6;  // 06052698 bra 0x060526A6 ; mov #100,r0
L_0605269C:
    c.r[0] = 0x50u; goto L_060526A6;  // 0605269C bra 0x060526A6 ; mov #80,r0
L_060526A0:
    c.r[0] = 0x3Cu; goto L_060526A6;  // 060526A0 bra 0x060526A6 ; mov #60,r0
L_060526A4:
    c.r[0] = 0x0u;  // 060526A4 mov #0,r0
L_060526A6:
    c.r[15] = c.r[14];  // 060526A6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060526A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060526AA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060526AC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060526AE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060526B0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060526B2 rts ; mov.l @r15+,r8
}

void f_060526B8(SH2Context& c) {
    ran[1296] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060526B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060526BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060526BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060526BE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060526C0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060526C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060526C4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060526C6 mov r15,r14
    c.r[12] = c.r[4] & 0xFFu;  // 060526C8 extu.b r4,r12
    c.r[10] = 0x0u;  // 060526CA mov #0,r10
    c.r[11] = ld32(0x06052730u);  // 060526CC mov.l 0x06052730,r11
    c.r[9] = 0x0u;  // 060526CE mov #0,r9
L_060526D0:
    c.r[1] = ld32(c.r[11]);  // 060526D0 mov.l @r11,r1
    c.r[1] += c.r[9];  // 060526D2 add r9,r1
    c.r[1] += 7;  // 060526D4 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060526D6 mov.b @r1,r0
    c.r[3] = c.r[9];  // 060526D8 mov r9,r3
    c.r[0] &= 0xDFu;  // 060526DA and #223,r0
    st8(c.r[1], c.r[0]);  // 060526DC mov.b r0,@r1
    c.r[0] = ld32(c.r[11]);  // 060526DE mov.l @r11,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605272Eu);  // 060526E0 mov.w 0x0605272E,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060526E2 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060526E4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060526E6 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06052712; } }  // 060526E8 bt/s 0x06052712 ; add r0,r3
    c.r[3] += 7;  // 060526EC add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060526EE mov.b @r3,r1
    c.r[0] = c.r[1];  // 060526F0 mov r1,r0
    c.r[0] >>= 2;  // 060526F2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060526F4 shlr r0
    c.r[0] &= 0x1u;  // 060526F6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060526F8 tst r0,r0
    { const bool k = !c.t; c.r[8] = c.r[10] & 0xFFu; if (k) { goto L_06052712; } }  // 060526FA bf/s 0x06052712 ; extu.b r10,r8
    c.r[0] = ld32(0x06052734u);  // 060526FE mov.l 0x06052734,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06052704u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052704u) return; }  // 06052700 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06052704 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052706 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_06052712; } }  // 06052708 bt/s 0x06052712 ; mov r8,r5
    c.r[1] = ld32(0x06052738u);  // 0605270C mov.l 0x06052738,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052712u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052712u) return; }  // 0605270E jsr @r1 ; mov r12,r4
L_06052712:
    c.r[10] += 1;  // 06052712 add #1,r10
    c.r[1] = 0x49u;  // 06052714 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06052716 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_060526D0; } }  // 06052718 bf/s 0x060526D0 ; add #16,r9
    c.r[15] = c.r[14];  // 0605271C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605271E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06052720 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06052722 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06052724 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06052726 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06052728 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605272A rts ; mov.l @r15+,r8
}

void f_0605273C(SH2Context& c) {
    ran[1297] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605273C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605273E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06052740 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06052742 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06052744 extu.b r4,r4
    c.r[1] = c.r[5] & 0xFFu;  // 06052746 extu.b r5,r1
    c.t = (c.r[4] & c.r[4]) == 0;  // 06052748 tst r4,r4
    { const bool k = c.t; c.r[8] = c.r[1]; if (k) { goto L_060527A4; } }  // 0605274A bt/s 0x060527A4 ; mov r1,r8
    c.r[7] = ld32(0x060527D0u);  // 0605274E mov.l 0x060527D0,r7
    c.r[5] = c.r[1];  // 06052750 mov r1,r5
    c.r[2] = ld32(c.r[7]);  // 06052752 mov.l @r7,r2
    c.r[5] <<= 2;  // 06052754 shll2 r5
    c.r[5] <<= 2;  // 06052756 shll2 r5
    c.r[2] += c.r[5];  // 06052758 add r5,r2
    c.r[3] = c.r[2];  // 0605275A mov r2,r3
    c.r[3] += 10;  // 0605275C add #10,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605275E mov.b @r3,r1
    c.r[0] = c.r[1];  // 06052760 mov r1,r0
    c.r[0] >>= 2;  // 06052762 shlr2 r0
    c.r[0] &= 0x1u;  // 06052764 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06052766 tst r0,r0
    { const bool k = c.t; c.r[2] += 7; if (k) { goto L_06052774; } }  // 06052768 bt/s 0x06052774 ; add #7,r2
    c.r[0] = c.r[1];  // 0605276C mov r1,r0
    c.r[0] &= 0xFBu;  // 0605276E and #251,r0
    st8(c.r[3], c.r[0]); goto L_0605278A;  // 06052770 bra 0x0605278A ; mov.b r0,@r3
L_06052774:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06052774 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06052776 mov r1,r0
    c.r[0] >>= 2;  // 06052778 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605277A shlr r0
    c.r[0] >>= 2;  // 0605277C shlr2 r0
    c.r[0] &= 0x1u;  // 0605277E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06052780 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_060527C4; } }  // 06052782 bt/s 0x060527C4 ; mov r1,r0
    c.r[0] &= 0xDFu;  // 06052786 and #223,r0
    st8(c.r[2], c.r[0]);  // 06052788 mov.b r0,@r2
L_0605278A:
    c.r[1] = ld32(c.r[7]);  // 0605278A mov.l @r7,r1
    c.r[1] += c.r[5];  // 0605278C add r5,r1
    c.r[1] += 7;  // 0605278E add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052790 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06052792 and #239,r0
    st8(c.r[1], c.r[0]);  // 06052794 mov.b r0,@r1
    c.r[1] = ld32(c.r[7]);  // 06052796 mov.l @r7,r1
    c.r[1] += c.r[5];  // 06052798 add r5,r1
    c.r[1] += 3;  // 0605279A add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605279C mov.b @r1,r0
    c.r[0] |= 0x20u;  // 0605279E or #32,r0
    st8(c.r[1], c.r[0]); goto L_060527C4;  // 060527A0 bra 0x060527C4 ; mov.b r0,@r1
L_060527A4:
    c.r[0] = ld32(0x060527D4u);  // 060527A4 mov.l 0x060527D4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060527AAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060527AAu) return; }  // 060527A6 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0] & 0xFFu;  // 060527AA extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060527AC tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_060527C4; } }  // 060527AE bt/s 0x060527C4 ; mov r8,r2
    c.r[1] = ld32(0x060527D0u);  // 060527B2 mov.l 0x060527D0,r1
    c.r[1] = ld32(c.r[1]);  // 060527B4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060527B6 shll2 r2
    c.r[2] <<= 2;  // 060527B8 shll2 r2
    c.r[2] += c.r[1];  // 060527BA add r1,r2
    c.r[2] += 7;  // 060527BC add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060527BE mov.b @r2,r0
    c.r[0] |= 0x20u;  // 060527C0 or #32,r0
    st8(c.r[2], c.r[0]);  // 060527C2 mov.b r0,@r2
L_060527C4:
    c.r[15] = c.r[14];  // 060527C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060527C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060527C8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060527CA rts ; mov.l @r15+,r8
}

void f_060527D8(SH2Context& c) {
    ran[1298] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060527D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060527DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060527DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060527DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060527E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060527E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060527E4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060527E6 mov r15,r14
    c.r[12] = c.r[4] & 0xFFu;  // 060527E8 extu.b r4,r12
    c.r[10] = 0x0u;  // 060527EA mov #0,r10
    c.r[11] = ld32(0x06052858u);  // 060527EC mov.l 0x06052858,r11
    c.r[9] = 0x0u;  // 060527EE mov #0,r9
    c.r[3] = c.r[9];  // 060527F0 mov r9,r3
L_060527F2:
    c.r[0] = ld32(c.r[11]);  // 060527F2 mov.l @r11,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052854u);  // 060527F4 mov.w 0x06052854,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060527F6 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060527F8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060527FA cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06052836; } }  // 060527FC bt/s 0x06052836 ; add r0,r3
    c.r[3] += 7;  // 06052800 add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06052802 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06052804 mov r1,r0
    c.r[0] >>= 2;  // 06052806 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06052808 shlr r0
    c.r[0] &= 0x1u;  // 0605280A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605280C tst r0,r0
    { const bool k = !c.t; c.r[8] = c.r[10] & 0xFFu; if (k) { goto L_06052836; } }  // 0605280E bf/s 0x06052836 ; extu.b r10,r8
    c.r[0] = ld32(0x0605285Cu);  // 06052812 mov.l 0x0605285C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06052818u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052818u) return; }  // 06052814 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06052818 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605281A tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_0605282A; } }  // 0605281C bt/s 0x0605282A ; mov r8,r5
    c.r[1] = ld32(0x06052860u);  // 06052820 mov.l 0x06052860,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052826u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052826u) return; }  // 06052822 jsr @r1 ; mov r12,r4
    c.r[9] += 16; goto L_06052838;  // 06052826 bra 0x06052838 ; add #16,r9
L_0605282A:
    c.r[1] = ld32(c.r[11]);  // 0605282A mov.l @r11,r1
    c.r[1] += c.r[9];  // 0605282C add r9,r1
    c.r[1] += 7;  // 0605282E add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052830 mov.b @r1,r0
    c.r[0] |= 0x10u;  // 06052832 or #16,r0
    st8(c.r[1], c.r[0]);  // 06052834 mov.b r0,@r1
L_06052836:
    c.r[9] += 16;  // 06052836 add #16,r9
L_06052838:
    c.r[10] += 1;  // 06052838 add #1,r10
    c.r[1] = 0x49u;  // 0605283A mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0605283C cmp/gt r1,r10
    { const bool k = !c.t; c.r[3] = c.r[9]; if (k) { SH2_POLL(c); goto L_060527F2; } }  // 0605283E bf/s 0x060527F2 ; mov r9,r3
    c.r[15] = c.r[14];  // 06052842 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06052844 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06052846 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06052848 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605284A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605284C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605284E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052850 rts ; mov.l @r15+,r8
}

void f_06052864(SH2Context& c) {
    ran[1299] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052864 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06052866 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06052868 extu.b r4,r4
    c.r[1] = ld32(0x060528D0u);  // 0605286A mov.l 0x060528D0,r1
    c.r[2] = ld32(c.r[1]);  // 0605286C mov.l @r1,r2
    c.r[6] = c.r[4];  // 0605286E mov r4,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060528CCu);  // 06052870 mov.w 0x060528CC,r1
    c.r[0] = c.r[2];  // 06052872 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052874 mov.b @(r0,r1),r1
    c.r[0] = 0x8u;  // 06052876 mov #8,r0
    c.r[1] &= c.r[0];  // 06052878 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605287A tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[5] & 0xFFu; if (k) { goto L_06052886; } }  // 0605287C bt/s 0x06052886 ; extu.b r5,r3
    c.t = (c.r[4] & c.r[4]) == 0;  // 06052880 tst r4,r4
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_060528C8; } }  // 06052882 bf/s 0x060528C8 ; mov r14,r15
L_06052886:
    c.r[7] = ld32(0x060528D4u);  // 06052886 mov.l 0x060528D4,r7
    c.r[3] <<= 2;  // 06052888 shll2 r3
    c.r[3] <<= 2;  // 0605288A shll2 r3
    c.r[1] = 0x1u;  // 0605288C mov #1,r1
    c.r[2] = ld32(c.r[7]);  // 0605288E mov.l @r7,r2
    c.r[1] &= c.r[6];  // 06052890 and r6,r1
    c.r[2] += c.r[3];  // 06052892 add r3,r2
    c.r[2] += 7;  // 06052894 add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06052896 mov.b @r2,r0
    c.r[1] <<= 2;  // 06052898 shll2 r1
    c.r[1] <<= 2;  // 0605289A shll2 r1
    c.r[0] &= 0xEFu;  // 0605289C and #239,r0
    c.r[0] |= c.r[1];  // 0605289E or r1,r0
    st8(c.r[2], c.r[0]);  // 060528A0 mov.b r0,@r2
    c.r[1] = ld32(c.r[7]);  // 060528A2 mov.l @r7,r1
    c.r[1] += c.r[3];  // 060528A4 add r3,r1
    c.r[3] = c.r[6];  // 060528A6 mov r6,r3
    c.r[3] -= 1;  // 060528A8 add #-1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 060528AA cmp/pz r3
    if (c.t) { goto L_060528B0; }  // 060528AC bt 0x060528B0
    c.r[3] = 0u - c.r[3];  // 060528AE neg r3,r3
L_060528B0:
    c.r[1] += 3;  // 060528B0 add #3,r1
    c.r[0] = 0x1u;  // 060528B2 mov #1,r0
    c.r[3] &= c.r[0];  // 060528B4 and r0,r3
    c.r[3] <<= 2;  // 060528B6 shll2 r3
    c.r[3] += c.r[3];  // 060528B8 add r3,r3
    c.r[3] <<= 2;  // 060528BA shll2 r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060528BC mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060528CEu);  // 060528BE mov.w 0x060528CE,r0
    c.r[2] &= c.r[0];  // 060528C0 and r0,r2
    c.r[2] |= c.r[3];  // 060528C2 or r3,r2
    st8(c.r[1], c.r[2]);  // 060528C4 mov.b r2,@r1
    c.r[15] = c.r[14];  // 060528C6 mov r14,r15
L_060528C8:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060528C8 rts ; mov.l @r15+,r14
}

void f_060528D8(SH2Context& c) {
    ran[1300] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060528D8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060528DA mov r15,r14
    c.r[6] = c.r[6] & 0xFFu;  // 060528DC extu.b r6,r6
    c.r[0] = 0x0u;  // 060528DE mov #0,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[6];  // 060528E0 cmp/ge r6,r0
    { const bool k = c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_060528F4; } }  // 060528E2 bt/s 0x060528F4 ; extu.b r5,r5
L_060528E6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060528E6 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060528E8 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 060528EA cmp/eq r5,r1
    if (c.t) { goto L_060528F4; }  // 060528EC bt 0x060528F4
    c.r[0] += 1;  // 060528EE add #1,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[6];  // 060528F0 cmp/ge r6,r0
    if (!c.t) { SH2_POLL(c); goto L_060528E6; }  // 060528F2 bf 0x060528E6
L_060528F4:
    c.t = c.r[0] == c.r[6];  // 060528F4 cmp/eq r6,r0
    if (!c.t) { goto L_060528FE; }  // 060528F6 bf 0x060528FE
    c.r[0] = 0xFFFFFFFFu;  // 060528F8 mov #-1,r0
    c.r[15] = c.r[14]; goto L_06052902;  // 060528FA bra 0x06052902 ; mov r14,r15
L_060528FE:
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 060528FE exts.b r0,r0
    c.r[15] = c.r[14];  // 06052900 mov r14,r15
L_06052902:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052902 rts ; mov.l @r15+,r14
}

void f_06052908(SH2Context& c) {
    ran[1301] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06052908 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605290A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605290C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605290E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06052910 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06052912 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052914 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06052916 sts.l pr,@-r15
    c.r[15] -= 20;  // 06052918 add #-20,r15
    c.r[14] = c.r[15];  // 0605291A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0605291C extu.b r4,r4
    st32(c.r[14] + 4, c.r[4]);  // 0605291E mov.l r4,@(4,r14)
    c.r[5] = c.r[5] & 0xFFu;  // 06052920 extu.b r5,r5
    st32(c.r[14] + 8, c.r[5]);  // 06052922 mov.l r5,@(8,r14)
    c.r[1] = c.r[6] & 0xFFu;  // 06052924 extu.b r6,r1
    c.r[13] = (uint32_t)(int32_t)(int8_t)c.r[7];  // 06052926 exts.b r7,r13
    c.r[0] = 0xFFFFFFFEu;  // 06052928 mov #-2,r0
    st32(c.r[14] + 12, c.r[0]);  // 0605292A mov.l r0,@(12,r14)
    c.r[9] = 0x10u;  // 0605292C mov #16,r9
    c.r[9] &= c.r[1];  // 0605292E and r1,r9
    c.r[8] = 0xFu;  // 06052930 mov #15,r8
    c.r[8] &= c.r[1];  // 06052932 and r1,r8
    c.r[12] = ld32(0x06052ABCu);  // 06052934 mov.l 0x06052ABC,r12
    c.r[11] = ld32(0x06052AC0u);  // 06052936 mov.l 0x06052AC0,r11
    c.r[5] = 0x22u;  // 06052938 mov #34,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605293Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605293Eu) return; }  // 0605293A jsr @r11 ; mov r12,r4
    c.r[1] = c.r[0];  // 0605293E mov r0,r1
    c.r[5] = 0x0u;  // 06052940 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06052946u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052946u) return; }  // 06052942 jsr @r11 ; mov r1,r4
    st32(c.r[14] + 16, c.r[0]);  // 06052946 mov.l r0,@(16,r14)
    c.r[10] = c.r[8];  // 06052948 mov r8,r10
    c.r[10] <<= 2;  // 0605294A shll2 r10
    c.r[10] += c.r[8];  // 0605294C add r8,r10
    c.r[3] = c.r[0];  // 0605294E mov r0,r3
    c.r[3] += c.r[10];  // 06052950 add r10,r3
    st32(c.r[14] + 16, c.r[3]);  // 06052952 mov.l r3,@(16,r14)
    c.r[5] = 0x22u;  // 06052954 mov #34,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605295Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605295Au) return; }  // 06052956 jsr @r11 ; mov r12,r4
    c.r[1] = c.r[0];  // 0605295A mov r0,r1
    c.r[5] = 0x0u;  // 0605295C mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06052962u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052962u) return; }  // 0605295E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06052962 mov r0,r1
    c.r[0] = c.r[10];  // 06052964 mov r10,r0
    c.r[3] = ld32(0x06052AC4u);  // 06052966 mov.l 0x06052AC4,r3
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052968 mov.b @(r0,r1),r8
    c.r[4] = 0x1u;  // 0605296A mov #1,r4
    c.r[8] = c.r[8] & 0xFFu;  // 0605296C extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605296E mov.b @r3,r1
    c.r[0] = 0xFu;  // 06052970 mov #15,r0
    c.r[1] &= c.r[0];  // 06052972 and r0,r1
    c.r[3] = ld32(0x06052AC8u);  // 06052974 mov.l 0x06052AC8,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0605297Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605297Au) return; }  // 06052976 jsr @r3 ; mov r1,r5
    c.r[1] = c.r[0];  // 0605297A mov r0,r1
    c.r[4] = c.r[1];  // 0605297C mov r1,r4
    c.r[1] = ld32(0x06052ACCu);  // 0605297E mov.l 0x06052ACC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052984u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052984u) return; }  // 06052980 jsr @r1 ; nop
    c.r[8] &= c.r[4];  // 06052984 and r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06052986 tst r8,r8
    if (!c.t) { goto L_060529BC; }  // 06052988 bf 0x060529BC
    c.r[5] = 0x22u;  // 0605298A mov #34,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06052990u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052990u) return; }  // 0605298C jsr @r11 ; mov r12,r4
    c.r[1] = c.r[0];  // 06052990 mov r0,r1
    c.r[5] = 0x0u;  // 06052992 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06052998u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052998u) return; }  // 06052994 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06052998 mov r0,r1
    c.r[10] += c.r[1];  // 0605299A add r1,r10
    c.r[10] += 1;  // 0605299C add #1,r10
    c.r[0] = ld32(0x06052AC4u);  // 0605299E mov.l 0x06052AC4,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060529A0 mov.b @r10,r4
    c.r[3] = 0xFu;  // 060529A2 mov #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060529A4 mov.b @r0,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060529A6 extu.b r4,r4
    c.r[1] &= c.r[3];  // 060529A8 and r3,r1
    c.r[0] = ld32(0x06052AD0u);  // 060529AA mov.l 0x06052AD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060529B0u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060529B0u) return; }  // 060529AC jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 060529B0 mov r0,r1
    c.r[3] = 0x1u;  // 060529B2 mov #1,r3
    c.r[1] &= c.r[3];  // 060529B4 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060529B6 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06052AA2; } }  // 060529B8 bt/s 0x06052AA2 ; mov.l @(12,r14),r0
L_060529BC:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060529BC tst r9,r9
    { const bool k = !c.t; c.r[2] = ld32(c.r[14] + 8); if (k) { goto L_060529E0; } }  // 060529BE bf/s 0x060529E0 ; mov.l @(8,r14),r2
    c.r[1] = ld32(0x06052AD4u);  // 060529C2 mov.l 0x06052AD4,r1
    c.r[1] = ld32(c.r[1]);  // 060529C4 mov.l @r1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 060529C6 mov.l @(4,r14),r0
    c.r[2] <<= 2;  // 060529C8 shll2 r2
    c.r[2] <<= 2;  // 060529CA shll2 r2
    c.r[2] <<= 2;  // 060529CC shll2 r2
    c.r[2] += c.r[1];  // 060529CE add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060529D0 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060529D2 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052AB8u);  // 060529D4 mov.w 0x06052AB8,r2
    c.t = c.r[1] == c.r[2];  // 060529D6 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] = 0xFFFFFFFFu; if (k) { goto L_060529E0; } }  // 060529D8 bt/s 0x060529E0 ; mov #-1,r3
    st32(c.r[14] + 12, c.r[3]); goto L_06052AA0;  // 060529DC bra 0x06052AA0 ; mov.l r3,@(12,r14)
L_060529E0:
    c.r[1] = ld32(0x06052AD8u);  // 060529E0 mov.l 0x06052AD8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052ABAu);  // 060529E2 mov.w 0x06052ABA,r2
    c.r[3] = ld32(c.r[14] + 8);  // 060529E4 mov.l @(8,r14),r3
    c.r[0] = c.r[1];  // 060529E6 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 060529E8 mov.l @(r0,r2),r1
    c.r[3] <<= 2;  // 060529EA shll2 r3
    c.r[3] <<= 2;  // 060529EC shll2 r3
    c.r[3] <<= 2;  // 060529EE shll2 r3
    c.r[3] += c.r[1];  // 060529F0 add r1,r3
    st32(c.r[14] + 8, c.r[3]);  // 060529F2 mov.l r3,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 060529F4 mov.l @(8,r14),r0
    c.r[3] = ld32(c.r[14] + 4);  // 060529F6 mov.l @(4,r14),r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060529F8 mov.b @(r0,r3),r1
    c.r[0] = c.r[13];  // 060529FA mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060529FC cmp/eq #-1,r0
    { const bool k = !c.t; c.r[11] = c.r[1] & 0xFFu; if (k) { goto L_06052A66; } }  // 060529FE bf/s 0x06052A66 ; extu.b r1,r11
    c.r[1] = 0x0u;  // 06052A02 mov #0,r1
    st8(c.r[14], c.r[1]);  // 06052A04 mov.b r1,@r14
    c.r[2] = c.r[14];  // 06052A06 mov r14,r2
    c.r[2] += 1;  // 06052A08 add #1,r2
    c.r[1] = 0x1u;  // 06052A0A mov #1,r1
    st8(c.r[2], c.r[1]);  // 06052A0C mov.b r1,@r2
    c.r[2] = c.r[14];  // 06052A0E mov r14,r2
    c.r[2] += 2;  // 06052A10 add #2,r2
    c.r[1] = 0x2u;  // 06052A12 mov #2,r1
    st8(c.r[2], c.r[1]);  // 06052A14 mov.b r1,@r2
    c.r[9] = 0x0u;  // 06052A16 mov #0,r9
    c.r[10] = ld32(0x06052AC0u);  // 06052A18 mov.l 0x06052AC0,r10
    c.r[0] = c.r[14];  // 06052A1A mov r14,r0
L_06052A1C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06052A1C mov.b @(r0,r9),r1
    c.r[3] = ld32(c.r[14] + 16);  // 06052A1E mov.l @(16,r14),r3
    c.r[1] = c.r[1] & 0xFFu;  // 06052A20 extu.b r1,r1
    c.r[1] += c.r[3];  // 06052A22 add r3,r1
    c.r[1] += 2;  // 06052A24 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052A26 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06052A28 extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06052A2A tst r8,r8
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06052A4E; } }  // 06052A2C bt/s 0x06052A4E ; tst r11,r11
    if (c.t) { goto L_06052A4E; }  // 06052A30 bt 0x06052A4E
    c.r[4] = ld32(0x06052ABCu);  // 06052A32 mov.l 0x06052ABC,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06052A38u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052A38u) return; }  // 06052A34 jsr @r10 ; mov #34,r5
    c.r[5] = 0x1u;  // 06052A38 mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06052A3Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052A3Eu) return; }  // 06052A3A jsr @r10 ; mov r0,r4
    c.r[5] = c.r[8];  // 06052A3E mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06052A44u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052A44u) return; }  // 06052A40 jsr @r10 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06052A44 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052A46 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052A48 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_06052A5A; } }  // 06052A4A bf/s 0x06052A5A ; mov #2,r1
L_06052A4E:
    c.r[9] += 1;  // 06052A4E add #1,r9
    c.r[1] = 0x2u;  // 06052A50 mov #2,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06052A52 cmp/gt r1,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06052A1C; } }  // 06052A54 bf/s 0x06052A1C ; mov r14,r0
    c.r[1] = 0x2u;  // 06052A58 mov #2,r1
L_06052A5A:
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06052A5A cmp/gt r1,r9
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06052AA0; } }  // 06052A5C bt/s 0x06052AA0 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06052A60 mov.b @(r0,r9),r1
    c.r[0] = c.r[1]; goto L_06052AA2;  // 06052A62 bra 0x06052AA2 ; mov r1,r0
L_06052A66:
    c.r[1] = ld32(c.r[14] + 16);  // 06052A66 mov.l @(16,r14),r1
    c.t = (c.r[13] & c.r[13]) == 0;  // 06052A68 tst r13,r13
    c.r[1] += c.r[13];  // 06052A6A add r13,r1
    { const bool k = c.t; c.r[1] += 2; if (k) { goto L_06052AA0; } }  // 06052A6C bt/s 0x06052AA0 ; add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052A70 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06052A72 extu.b r1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06052A74 tst r9,r9
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06052AA2; } }  // 06052A76 bt/s 0x06052AA2 ; mov.l @(12,r14),r0
    c.t = (c.r[11] & c.r[11]) == 0;  // 06052A7A tst r11,r11
    if (c.t) { goto L_06052AA2; }  // 06052A7C bt 0x06052AA2
    c.r[4] = ld32(0x06052ABCu);  // 06052A7E mov.l 0x06052ABC,r4
    c.r[8] = ld32(0x06052AC0u);  // 06052A80 mov.l 0x06052AC0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06052A86u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052A86u) return; }  // 06052A82 jsr @r8 ; mov #34,r5
    c.r[5] = 0x1u;  // 06052A86 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06052A8Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052A8Cu) return; }  // 06052A88 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 06052A8C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06052A92u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052A92u) return; }  // 06052A8E jsr @r8 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06052A92 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052A94 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052A96 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06052AA2; } }  // 06052A98 bt/s 0x06052AA2 ; mov.l @(12,r14),r0
    c.r[0] = c.r[13]; goto L_06052AA2;  // 06052A9C bra 0x06052AA2 ; mov r13,r0
L_06052AA0:
    c.r[0] = ld32(c.r[14] + 12);  // 06052AA0 mov.l @(12,r14),r0
L_06052AA2:
    c.r[14] += 20;  // 06052AA2 add #20,r14
    c.r[15] = c.r[14];  // 06052AA4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06052AA6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06052AA8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06052AAA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06052AAC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06052AAE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06052AB0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06052AB2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052AB4 rts ; mov.l @r15+,r8
}

void f_06052ADC(SH2Context& c) {
    ran[1302] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06052ADC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06052ADE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06052AE0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06052AE2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06052AE4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06052AE6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052AE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06052AEA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06052C6Eu);  // 06052AEC mov.w 0x06052C6E,r3
    c.r[15] += c.r[3];  // 06052AEE add r3,r15
    c.r[14] = c.r[15];  // 06052AF0 mov r15,r14
    c.r[8] = c.r[5];  // 06052AF2 mov r5,r8
    c.r[12] = c.r[4] & 0xFFu;  // 06052AF4 extu.b r4,r12
    c.r[8] = c.r[8] & 0xFFu;  // 06052AF6 extu.b r8,r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C70u);  // 06052AF8 mov.w 0x06052C70,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C72u);  // 06052AFA mov.w 0x06052C72,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06052AFC mov.l r13,@(r0,r14)
    c.r[11] = ld32(0x06052C88u);  // 06052AFE mov.l 0x06052C88,r11
    c.r[8] <<= 2;  // 06052B00 shll2 r8
    c.r[8] <<= 2;  // 06052B02 shll2 r8
    c.r[1] = ld32(c.r[11]);  // 06052B04 mov.l @r11,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06052C74u);  // 06052B06 mov.w 0x06052C74,r6
    c.r[1] += c.r[8];  // 06052B08 add r8,r1
    c.r[1] += 2;  // 06052B0A add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052B0C mov.b @r1,r5
    c.r[4] = c.r[14];  // 06052B0E mov r14,r4
    c.r[1] = ld32(0x06052C8Cu);  // 06052B10 mov.l 0x06052C8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052B16u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052B16u) return; }  // 06052B12 jsr @r1 ; extu.b r5,r5
    c.r[3] = ld32(0x06052C90u);  // 06052B16 mov.l 0x06052C90,r3
    c.r[1] = c.r[8];  // 06052B18 mov r8,r1
    c.r[0] = c.r[8];  // 06052B1A mov r8,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C76u);  // 06052B1C mov.w 0x06052C76,r13
    c.r[13] += c.r[14];  // 06052B1E add r14,r13
    c.r[2] = ld32(c.r[11]);  // 06052B20 mov.l @r11,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06052C78u);  // 06052B22 mov.w 0x06052C78,r5
    c.r[1] += c.r[2];  // 06052B24 add r2,r1
    c.r[1] += 1;  // 06052B26 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052B28 mov.b @r1,r1
    c.r[5] += c.r[14];  // 06052B2A add r14,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06052B2C mov.b @(r0,r2),r2
    c.r[1] = c.r[1] & 0xFFu;  // 06052B2E extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06052B30 extu.b r2,r2
    c.r[2] += c.r[2];  // 06052B32 add r2,r2
    c.r[1] <<= 2;  // 06052B34 shll2 r1
    c.r[1] <<= 2;  // 06052B36 shll2 r1
    c.r[1] += c.r[1];  // 06052B38 add r1,r1
    c.r[1] <<= 2;  // 06052B3A shll2 r1
    c.r[1] += c.r[3];  // 06052B3C add r3,r1
    c.r[2] += c.r[1];  // 06052B3E add r1,r2
    c.r[2] += 1;  // 06052B40 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06052B42 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052B44 extu.b r1,r1
    st32(c.r[13], c.r[1]);  // 06052B46 mov.l r1,@r13
    c.r[1] = ld32(0x06052C94u);  // 06052B48 mov.l 0x06052C94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052B4Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052B4Eu) return; }  // 06052B4A jsr @r1 ; mov r12,r4
    c.r[10] = 0x0u;  // 06052B4E mov #0,r10
    c.r[13] = 0x0u;  // 06052B50 mov #0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C7Au);  // 06052B52 mov.w 0x06052C7A,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06052B54 mov.l r13,@(r0,r14)
    c.r[1] = ld32(0x06052C98u);  // 06052B56 mov.l 0x06052C98,r1
    c.r[2] = ld32(c.r[1]);  // 06052B58 mov.l @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C7Au);  // 06052B5A mov.w 0x06052C7A,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06052C7Cu);  // 06052B5C mov.w 0x06052C7C,r1
    c.r[0] = c.r[2];  // 06052B5E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052B60 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06052B62 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06052B64 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06052B66 extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 06052B68 cmp/ge r1,r13
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_06052B72; } }  // 06052B6A bf/s 0x06052B72 ; mov #0,r9
    goto L_06052DC4;  // 06052B6E bra 0x06052DC4 ; nop
L_06052B72:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C7Eu);  // 06052B72 mov.w 0x06052C7E,r0
    st32(c.r[0] + c.r[14], c.r[2]);  // 06052B74 mov.l r2,@(r0,r14)
    c.r[13] = ld32(0x06052C9Cu);  // 06052B76 mov.l 0x06052C9C,r13
    c.r[0] = ld32(c.r[13]);  // 06052B78 mov.l @r13,r0
    c.r[12] <<= 2;  // 06052B7A shll2 r12
    c.r[12] <<= 2;  // 06052B7C shll2 r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C80u);  // 06052B7E mov.w 0x06052C80,r13
    c.r[13] += c.r[14];  // 06052B80 add r14,r13
    st32(c.r[13], c.r[0]);  // 06052B82 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C82u);  // 06052B84 mov.w 0x06052C82,r13
    c.r[13] += c.r[14];  // 06052B86 add r14,r13
    st32(c.r[13], c.r[12]);  // 06052B88 mov.l r12,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C80u);  // 06052B8A mov.w 0x06052C80,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 06052B8C mov.l @(r0,r14),r13
    c.r[12] = 0x0u;  // 06052B8E mov #0,r12
    c.r[13] += 24;  // 06052B90 add #24,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C84u);  // 06052B92 mov.w 0x06052C84,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06052B94 mov.l r13,@(r0,r14)
L_06052B96:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C7Eu);  // 06052B96 mov.w 0x06052C7E,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06052B98 mov.l @(r0,r14),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C80u);  // 06052B9A mov.w 0x06052C80,r13
    c.r[1] += c.r[12];  // 06052B9C add r12,r1
    c.r[1] += 1;  // 06052B9E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052BA0 mov.b @r1,r1
    c.r[13] += c.r[14];  // 06052BA2 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06052BA4 mov.l @r13,r13
    c.r[4] = c.r[1] & 0xFFu;  // 06052BA6 extu.b r1,r4
    c.r[3] = c.r[4];  // 06052BA8 mov r4,r3
    c.r[3] <<= 2;  // 06052BAA shll2 r3
    c.r[3] += c.r[4];  // 06052BAC add r4,r3
    c.r[3] <<= 2;  // 06052BAE shll2 r3
    c.r[3] += c.r[13];  // 06052BB0 add r13,r3
    c.r[1] = c.r[3];  // 06052BB2 mov r3,r1
    c.r[1] += 54;  // 06052BB4 add #54,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06052BB6 mov.w @r1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06052BB8 extu.w r1,r8
    c.r[1] = c.r[3];  // 06052BBA mov r3,r1
    c.r[1] += 51;  // 06052BBC add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052BBE mov.b @r1,r1
    c.r[0] = 0x1u;  // 06052BC0 mov #1,r0
    c.r[1] >>= 2;  // 06052BC2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06052BC4 shlr r1
    c.r[1] &= c.r[0];  // 06052BC6 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052BC8 tst r1,r1
    if (c.t) { goto L_06052BD0; }  // 06052BCA bt 0x06052BD0
    goto L_06052D9E;  // 06052BCC bra 0x06052D9E ; nop
L_06052BD0:
    c.r[13] = ld32(0x06052C88u);  // 06052BD0 mov.l 0x06052C88,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C82u);  // 06052BD2 mov.w 0x06052C82,r0
    c.r[1] = ld32(c.r[13]);  // 06052BD4 mov.l @r13,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06052BD6 mov.l @(r0,r14),r0
    c.r[1] += c.r[0];  // 06052BD8 add r0,r1
    c.r[1] += 3;  // 06052BDA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052BDC mov.b @r1,r1
    c.r[13] = 0x3u;  // 06052BDE mov #3,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06052BE0 shlr r1
    c.r[1] &= c.r[13];  // 06052BE2 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052BE4 tst r1,r1
    if (!c.t) { goto L_06052C50; }  // 06052BE6 bf 0x06052C50
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C80u);  // 06052BE8 mov.w 0x06052C80,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06052BEA mov.l @(r0,r14),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C84u);  // 06052BEC mov.w 0x06052C84,r13
    c.r[1] += 28;  // 06052BEE add #28,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06052BF0 mov.w @r1,r2
    c.r[13] += c.r[14];  // 06052BF2 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06052BF4 mov.l @r13,r0
    c.r[2] = c.r[2] & 0xFFFFu;  // 06052BF6 extu.w r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06052BF8 mov.w @r0,r1
    c.r[2] >>= 2;  // 06052BFA shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06052BFC shlr r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06052BFE extu.w r1,r1
    c.r[1] -= c.r[8];  // 06052C00 sub r8,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06052C02 cmp/ge r1,r2
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06052C0E; } }  // 06052C04 bf/s 0x06052C0E ; tst r8,r8
    if (c.t) { goto L_06052C0E; }  // 06052C08 bt 0x06052C0E
    goto L_06052D9E;  // 06052C0A bra 0x06052D9E ; nop
L_06052C0E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06052C78u);  // 06052C0E mov.w 0x06052C78,r1
    c.r[1] += c.r[14];  // 06052C10 add r14,r1
    c.r[0] = c.r[1];  // 06052C12 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06052C14 mov.b @(r0,r4),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052C74u);  // 06052C16 mov.w 0x06052C74,r13
    c.r[2] = c.r[1] & 0xFFu;  // 06052C18 extu.b r1,r2
    c.t = c.r[2] == c.r[13];  // 06052C1A cmp/eq r13,r2
    if (c.t) { goto L_06052C36; }  // 06052C1C bt 0x06052C36
    c.r[1] = ld32(0x06052CA0u);  // 06052C1E mov.l 0x06052CA0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C82u);  // 06052C20 mov.w 0x06052C82,r0
    c.r[1] = ld32(c.r[1]);  // 06052C22 mov.l @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06052C24 mov.l @(r0,r14),r0
    c.r[1] += c.r[0];  // 06052C26 add r0,r1
    c.r[1] += 40;  // 06052C28 add #40,r1
    c.r[0] = c.r[1];  // 06052C2A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06052C2C mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052C2E extu.b r1,r1
    c.r[2] = 0x1u;  // 06052C30 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 06052C32 cmp/hi r2,r1
    if (c.t) { goto L_06052C50; }  // 06052C34 bt 0x06052C50
L_06052C36:
    c.r[3] += 52;  // 06052C36 add #52,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06052C38 mov.w @r3,r1
    c.r[1] <<= 16;  // 06052C3A shll16 r1
    c.r[1] <<= 2;  // 06052C3C shll2 r1
    c.r[1] += c.r[1];  // 06052C3E add r1,r1
    c.r[1] <<= 2;  // 06052C40 shll2 r1
    c.r[1] >>= 16;  // 06052C42 shlr16 r1
    c.r[1] <<= 2;  // 06052C44 shll2 r1
    c.r[1] >>= 8;  // 06052C46 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052C48 tst r1,r1
    if (c.t) { goto L_06052C50; }  // 06052C4A bt 0x06052C50
    goto L_06052D9E;  // 06052C4C bra 0x06052D9E ; nop
L_06052C50:
    c.r[13] = ld32(0x06052C9Cu);  // 06052C50 mov.l 0x06052C9C,r13
    c.r[1] = c.r[4];  // 06052C52 mov r4,r1
    c.r[1] <<= 2;  // 06052C54 shll2 r1
    c.r[1] += c.r[4];  // 06052C56 add r4,r1
    c.r[1] <<= 2;  // 06052C58 shll2 r1
    c.r[2] = ld32(c.r[13]);  // 06052C5A mov.l @r13,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052C76u);  // 06052C5C mov.w 0x06052C76,r0
    c.r[2] += c.r[1];  // 06052C5E add r1,r2
    c.r[1] = c.r[2];  // 06052C60 mov r2,r1
    c.r[1] += 61;  // 06052C62 add #61,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052C64 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06052C66 mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06052C68 extu.b r1,r1
    c.t = c.r[0] >= c.r[1]; goto L_06052CA4;  // 06052C6A bra 0x06052CA4 ; cmp/hs r1,r0
L_06052CA4:
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06052D9E; } }  // 06052CA4 bf/s 0x06052D9E ; mov r2,r1
    c.r[1] += 62;  // 06052CA8 add #62,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052DE0u);  // 06052CAA mov.w 0x06052DE0,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052CAC mov.b @r1,r1
    c.r[13] += c.r[14];  // 06052CAE add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06052CB0 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06052CB2 extu.b r1,r1
    c.t = c.r[13] > c.r[1];  // 06052CB4 cmp/hi r1,r13
    { const bool k = c.t; c.r[2] += 50; if (k) { goto L_06052D9E; } }  // 06052CB6 bt/s 0x06052D9E ; add #50,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06052CBA mov.b @r2,r2
    c.r[1] = 0x1u;  // 06052CBC mov #1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06052CBE extu.b r2,r2
    c.r[2] >>= 2;  // 06052CC0 shlr2 r2
    c.r[2] >>= 2;  // 06052CC2 shlr2 r2
    c.r[2] >>= 2;  // 06052CC4 shlr2 r2
    c.t = c.r[2] > c.r[1];  // 06052CC6 cmp/hi r1,r2
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06052D9E; } }  // 06052CC8 bt/s 0x06052D9E ; mov #0,r8
    c.r[0] = ld32(0x06052DF4u);  // 06052CCC mov.l 0x06052DF4,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052DE2u);  // 06052CCE mov.w 0x06052DE2,r2
    c.macl = c.r[4] * c.r[2];  // 06052CD0 mul.l r2,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06052DE4u);  // 06052CD2 mov.w 0x06052DE4,r1
    c.r[3] = ld32(c.r[0]);  // 06052CD4 mov.l @r0,r3
    c.r[7] = c.macl;  // 06052CD6 sts macl,r7
    c.r[7] += c.r[3];  // 06052CD8 add r3,r7
    c.r[0] = c.r[7];  // 06052CDA mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052CDC mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052CDE extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06052CE0 cmp/ge r1,r8
    if (c.t) { goto L_06052D9E; }  // 06052CE2 bt 0x06052D9E
    c.r[6] = 0x0u;  // 06052CE4 mov #0,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052DE6u);  // 06052CE6 mov.w 0x06052DE6,r13
    c.r[13] += c.r[14];  // 06052CE8 add r14,r13
    st32(c.r[13], c.r[3]);  // 06052CEA mov.l r3,@r13
    c.r[0] = ld32(0x06052DF8u);  // 06052CEC mov.l 0x06052DF8,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052DE8u);  // 06052CEE mov.w 0x06052DE8,r13
    c.r[1] = ld32(c.r[0]);  // 06052CF0 mov.l @r0,r1
    c.r[13] += c.r[14];  // 06052CF2 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06052CF4 mov.l @r13,r13
    c.r[1] += c.r[13];  // 06052CF6 add r13,r1
    c.r[1] += 3;  // 06052CF8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052CFA mov.b @r1,r1
    c.r[0] = 0x3u;  // 06052CFC mov #3,r0
    c.r[11] = c.r[1];  // 06052CFE mov r1,r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 06052D00 shlr r11
    c.r[11] &= c.r[0];  // 06052D02 and r0,r11
L_06052D04:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052DE6u);  // 06052D04 mov.w 0x06052DE6,r13
    c.macl = c.r[4] * c.r[2];  // 06052D06 mul.l r2,r4
    c.r[13] += c.r[14];  // 06052D08 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06052D0A mov.l @r13,r13
    c.r[2] = c.macl;  // 06052D0C sts macl,r2
    c.r[2] += c.r[13];  // 06052D0E add r13,r2
    c.r[7] = c.r[2];  // 06052D10 mov r2,r7
    c.r[7] += c.r[6];  // 06052D12 add r6,r7
    c.r[1] = c.r[7];  // 06052D14 mov r7,r1
    c.r[1] += 7;  // 06052D16 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052D18 mov.b @r1,r1
    c.r[0] = c.r[2];  // 06052D1A mov r2,r0
    c.r[5] = c.r[1] & 0xFFu;  // 06052D1C extu.b r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06052D1E mov.b @(r0,r6),r1
    c.r[2] = 0x7Fu;  // 06052D20 mov #127,r2
    c.r[2] &= c.r[1];  // 06052D22 and r1,r2
    c.r[1] = c.r[7];  // 06052D24 mov r7,r1
    c.r[1] += 1;  // 06052D26 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052D28 mov.b @r1,r3
    c.r[2] <<= 16;  // 06052D2A shll16 r2
    c.r[2] <<= 8;  // 06052D2C shll8 r2
    c.r[3] = c.r[3] & 0xFFu;  // 06052D2E extu.b r3,r3
    c.r[3] <<= 16;  // 06052D30 shll16 r3
    c.r[3] |= c.r[2];  // 06052D32 or r2,r3
    c.r[1] = c.r[7];  // 06052D34 mov r7,r1
    c.r[1] += 2;  // 06052D36 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052D38 mov.b @r1,r2
    c.r[7] += 3;  // 06052D3A add #3,r7
    c.r[2] = c.r[2] & 0xFFu;  // 06052D3C extu.b r2,r2
    c.r[2] <<= 8;  // 06052D3E shll8 r2
    c.r[2] |= c.r[3];  // 06052D40 or r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06052D42 mov.b @r7,r1
    c.t = (c.r[11] & c.r[11]) == 0;  // 06052D44 tst r11,r11
    c.r[3] = c.r[1] & 0xFFu;  // 06052D46 extu.b r1,r3
    { const bool k = !c.t; c.r[3] |= c.r[2]; if (k) { goto L_06052D5E; } }  // 06052D48 bf/s 0x06052D5E ; or r2,r3
    c.r[1] = c.r[14];  // 06052D4C mov r14,r1
    c.r[1] += 22;  // 06052D4E add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06052D50 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06052D52 extu.w r1,r1
    c.t = c.r[10] >= c.r[1];  // 06052D54 cmp/hs r1,r10
    if (!c.t) { goto L_06052D5E; }  // 06052D56 bf 0x06052D5E
    c.r[1] = 0x45u;  // 06052D58 mov #69,r1
    c.t = c.r[9] > c.r[1];  // 06052D5A cmp/hi r1,r9
    if (c.t) { goto L_06052D84; }  // 06052D5C bt 0x06052D84
L_06052D5E:
    c.t = c.r[5] >= c.r[9];  // 06052D5E cmp/hs r9,r5
    { const bool k = !c.t; c.t = c.r[3] >= c.r[10]; if (k) { goto L_06052D66; } }  // 06052D60 bf/s 0x06052D66 ; cmp/hs r10,r3
    if (c.t) { goto L_06052D7A; }  // 06052D64 bt 0x06052D7A
L_06052D66:
    c.t = c.r[3] >= c.r[10];  // 06052D66 cmp/hs r10,r3
    { const bool k = !c.t; c.r[1] = 0x31u; if (k) { goto L_06052D70; } }  // 06052D68 bf/s 0x06052D70 ; mov #49,r1
    c.t = c.r[5] > c.r[1];  // 06052D6C cmp/hi r1,r5
    if (c.t) { goto L_06052D7A; }  // 06052D6E bt 0x06052D7A
L_06052D70:
    c.t = c.r[5] >= c.r[9];  // 06052D70 cmp/hs r9,r5
    { const bool k = !c.t; c.r[1] = 0x31u; if (k) { goto L_06052D84; } }  // 06052D72 bf/s 0x06052D84 ; mov #49,r1
    c.t = c.r[5] > c.r[1];  // 06052D76 cmp/hi r1,r5
    if (!c.t) { goto L_06052D84; }  // 06052D78 bf 0x06052D84
L_06052D7A:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052DEAu);  // 06052D7A mov.w 0x06052DEA,r13
    c.r[13] += c.r[14];  // 06052D7C add r14,r13
    st32(c.r[13], c.r[4]);  // 06052D7E mov.l r4,@r13
    c.r[9] = c.r[5];  // 06052D80 mov r5,r9
    c.r[10] = c.r[3];  // 06052D82 mov r3,r10
L_06052D84:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052DE2u);  // 06052D84 mov.w 0x06052DE2,r2
    c.macl = c.r[4] * c.r[2];  // 06052D86 mul.l r2,r4
    c.r[1] = ld32(0x06052DF4u);  // 06052D88 mov.l 0x06052DF4,r1
    c.r[1] = ld32(c.r[1]);  // 06052D8A mov.l @r1,r1
    c.r[0] = c.macl;  // 06052D8C sts macl,r0
    c.r[0] += c.r[1];  // 06052D8E add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06052DE4u);  // 06052D90 mov.w 0x06052DE4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06052D92 mov.b @(r0,r1),r1
    c.r[8] += 1;  // 06052D94 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06052D96 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06052D98 cmp/ge r1,r8
    { const bool k = !c.t; c.r[6] += 8; if (k) { SH2_POLL(c); goto L_06052D04; } }  // 06052D9A bf/s 0x06052D04 ; add #8,r6
L_06052D9E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052DECu);  // 06052D9E mov.w 0x06052DEC,r0
    c.r[0] += c.r[14];  // 06052DA0 add r14,r0
    c.r[1] = ld32(0x06052DFCu);  // 06052DA2 mov.l 0x06052DFC,r1
    c.r[13] = ld32(c.r[0]);  // 06052DA4 mov.l @r0,r13
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052DEEu);  // 06052DA6 mov.w 0x06052DEE,r2
    c.r[13] += 1;  // 06052DA8 add #1,r13
    st32(c.r[0], c.r[13]);  // 06052DAA mov.l r13,@r0
    c.r[1] = ld32(c.r[1]);  // 06052DAC mov.l @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06052DECu);  // 06052DAE mov.w 0x06052DEC,r13
    c.r[0] = c.r[1];  // 06052DB0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06052DB2 mov.b @(r0,r2),r1
    c.r[13] += c.r[14];  // 06052DB4 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06052DB6 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06052DB8 extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 06052DBA cmp/ge r1,r13
    { const bool k = c.t; c.r[12] += 2; if (k) { goto L_06052DC4; } }  // 06052DBC bt/s 0x06052DC4 ; add #2,r12
    SH2_POLL(c); goto L_06052B96;  // 06052DC0 bra 0x06052B96 ; nop
L_06052DC4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052DEAu);  // 06052DC4 mov.w 0x06052DEA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06052DC6 mov.l @(r0,r14),r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06052DF0u);  // 06052DC8 mov.w 0x06052DF0,r3
    c.r[14] += c.r[3];  // 06052DCA add r3,r14
    c.r[15] = c.r[14];  // 06052DCC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06052DCE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06052DD0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06052DD2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06052DD4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06052DD6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06052DD8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06052DDA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052DDC rts ; mov.l @r15+,r8
}

void f_06052E00(SH2Context& c) {
    ran[1303] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06052E00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06052E02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06052E04 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06052E06 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06052E08 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052E0A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06052E0C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06052E0E mov r15,r14
    c.r[9] = c.r[5];  // 06052E10 mov r5,r9
    c.r[8] = c.r[6];  // 06052E12 mov r6,r8
    c.r[10] = c.r[4] & 0xFFu;  // 06052E14 extu.b r4,r10
    c.r[9] = c.r[9] & 0xFFu;  // 06052E16 extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 06052E18 extu.b r8,r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06052E7Eu);  // 06052E1A mov.w 0x06052E7E,r2
    c.r[10] |= c.r[2];  // 06052E1C or r2,r10
    c.r[0] = ld32(0x06052E84u);  // 06052E1E mov.l 0x06052E84,r0
    c.r[6] = c.r[8];  // 06052E20 mov r8,r6
    c.r[5] = c.r[9];  // 06052E22 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06052E28u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052E28u) return; }  // 06052E24 jsr @r0 ; mov r10,r4
    c.r[11] = c.r[0] & 0xFFu;  // 06052E28 extu.b r0,r11
    c.r[0] = ld32(0x06052E88u);  // 06052E2A mov.l 0x06052E88,r0
    c.r[6] = c.r[8];  // 06052E2C mov r8,r6
    c.r[5] = c.r[9];  // 06052E2E mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06052E34u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052E34u) return; }  // 06052E30 jsr @r0 ; mov r10,r4
    c.r[1] = ld32(0x06052E8Cu);  // 06052E34 mov.l 0x06052E8C,r1
    c.r[1] = ld32(c.r[1]);  // 06052E36 mov.l @r1,r1
    c.r[1] += 22;  // 06052E38 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06052E3A mov.w @r1,r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 06052E3C extu.w r1,r5
    c.t = c.r[0] >= c.r[5];  // 06052E3E cmp/hs r5,r0
    { const bool k = c.t; c.r[12] = c.r[11]; if (k) { goto L_06052E6A; } }  // 06052E40 bt/s 0x06052E6A ; mov r11,r12
    c.r[1] = 0x4Bu;  // 06052E44 mov #75,r1
    c.t = c.r[11] > c.r[1];  // 06052E46 cmp/hi r1,r11
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06052E52; } }  // 06052E48 bf/s 0x06052E52 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052E80u);  // 06052E4C mov.w 0x06052E80,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06052E70;  // 06052E4E bra 0x06052E70 ; lds.l @r15+,pr
L_06052E52:
    c.r[1] = 0x40u;  // 06052E52 mov #64,r1
    c.t = c.r[12] > c.r[1];  // 06052E54 cmp/hi r1,r12
    { const bool k = !c.t; c.r[1] = 0x64u; if (k) { goto L_06052E6A; } }  // 06052E56 bf/s 0x06052E6A ; mov #100,r1
    c.macl = c.r[0] * c.r[1];  // 06052E5A mul.l r1,r0
    c.r[1] = ld32(0x06052E90u);  // 06052E5C mov.l 0x06052E90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06052E62u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052E62u) return; }  // 06052E5E jsr @r1 ; sts macl,r4
    c.r[1] = 0x46u;  // 06052E62 mov #70,r1
    c.t = c.r[0] > c.r[1];  // 06052E64 cmp/hi r1,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052E80u);  // 06052E66 mov.w 0x06052E80,r0
    if (!c.t) { goto L_06052E6C; }  // 06052E68 bf 0x06052E6C
L_06052E6A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06052E82u);  // 06052E6A mov.w 0x06052E82,r0
L_06052E6C:
    c.r[15] = c.r[14];  // 06052E6C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06052E6E lds.l @r15+,pr
L_06052E70:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06052E70 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06052E72 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06052E74 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06052E76 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06052E78 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052E7A rts ; mov.l @r15+,r8
}

void f_06052E94(SH2Context& c) {
    ran[1304] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06052E94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06052E96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052E98 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06052E9A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06052E9C extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06052E9E extu.b r5,r5
    c.r[2] = ld32(0x06052EE8u);  // 06052EA0 mov.l 0x06052EE8,r2
    c.r[7] = 0xBu;  // 06052EA2 mov #11,r7
    c.macl = c.r[5] * c.r[7];  // 06052EA4 mul.l r7,r5
    c.r[3] = 0x63u;  // 06052EA6 mov #99,r3
    c.r[6] = 0x1u;  // 06052EA8 mov #1,r6
    c.r[0] = c.macl;  // 06052EAA sts macl,r0
    c.macl = c.r[4] * c.r[3];  // 06052EAC mul.l r3,r4
    c.r[9] = 0x9u;  // 06052EAE mov #9,r9
    c.r[8] = c.r[2];  // 06052EB0 mov r2,r8
    c.r[1] = c.macl;  // 06052EB2 sts macl,r1
    c.r[0] += c.r[1];  // 06052EB4 add r1,r0
    c.r[1] = 0x0u;  // 06052EB6 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06052EB8 mov.b r1,@(r0,r2)
    c.r[0] += c.r[2];  // 06052EBA add r2,r0
    c.r[0] += 1;  // 06052EBC add #1,r0
    c.r[1] = 0x2u;  // 06052EBE mov #2,r1
    st8(c.r[0], c.r[1]);  // 06052EC0 mov.b r1,@r0
    c.r[0] = 0x0u;  // 06052EC2 mov #0,r0
L_06052EC4:
    c.macl = c.r[5] * c.r[7];  // 06052EC4 mul.l r7,r5
    c.r[2] = c.macl;  // 06052EC6 sts macl,r2
    c.macl = c.r[4] * c.r[3];  // 06052EC8 mul.l r3,r4
    c.r[1] = c.macl;  // 06052ECA sts macl,r1
    c.r[2] += c.r[1];  // 06052ECC add r1,r2
    c.r[2] += c.r[8];  // 06052ECE add r8,r2
    c.r[2] += c.r[6];  // 06052ED0 add r6,r2
    c.r[2] += 1;  // 06052ED2 add #1,r2
    c.r[6] += 1;  // 06052ED4 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[9];  // 06052ED6 cmp/gt r9,r6
    { const bool k = !c.t; st8(c.r[2], c.r[0]); if (k) { SH2_POLL(c); goto L_06052EC4; } }  // 06052ED8 bf/s 0x06052EC4 ; mov.b r0,@r2
    c.r[15] = c.r[14];  // 06052EDC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06052EDE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06052EE0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06052EE2 rts ; mov.l @r15+,r8
}

void f_06052EEC(SH2Context& c) {
    ran[1305] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06052EEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06052EEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06052EF0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06052EF2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06052EF4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06052EF6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06052EF8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06052EFA mov r15,r14
    c.r[10] = c.r[4] & 0xFFu;  // 06052EFC extu.b r4,r10
    c.r[0] = c.r[5] & 0xFFu;  // 06052EFE extu.b r5,r0
    c.r[8] = c.r[0];  // 06052F00 mov r0,r8
    c.r[5] = c.r[0];  // 06052F02 mov r0,r5
    c.r[5] -= 6;  // 06052F04 add #-6,r5
    c.r[2] = c.r[5] & 0xFFu;  // 06052F06 extu.b r5,r2
    c.r[1] = 0x59u;  // 06052F08 mov #89,r1
    c.t = c.r[2] > c.r[1];  // 06052F0A cmp/hi r1,r2
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_06052F14; } }  // 06052F0C bf/s 0x06052F14 ; mov #0,r12
    goto L_0605308C;  // 06052F10 bra 0x0605308C ; nop
L_06052F14:
    c.r[1] = ld32(0x060530C0u);  // 06052F14 mov.l 0x060530C0,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[5] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06052F16 dmuls.l r1,r5
    c.r[1] = c.mach;  // 06052F18 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06052F1A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06052F1C shar r1
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 06052F1E shll r5
    { uint32_t a = c.r[5], b = c.r[5], t = c.t; c.r[5] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06052F20 subc r5,r5
    c.r[1] -= c.r[5];  // 06052F22 sub r5,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06052F24 extu.b r1,r9
    c.r[5] = 0xBu;  // 06052F26 mov #11,r5
    c.macl = c.r[9] * c.r[5];  // 06052F28 mul.l r5,r9
    c.r[6] = 0x63u;  // 06052F2A mov #99,r6
    c.r[2] = c.macl;  // 06052F2C sts macl,r2
    c.macl = c.r[10] * c.r[6];  // 06052F2E mul.l r6,r10
    c.r[7] = ld32(0x060530C4u);  // 06052F30 mov.l 0x060530C4,r7
    c.r[0] = c.r[7];  // 06052F32 mov r7,r0
    c.r[1] = c.macl;  // 06052F34 sts macl,r1
    c.r[2] += c.r[1];  // 06052F36 add r1,r2
    c.r[3] = c.r[2];  // 06052F38 mov r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06052F3A mov.b @(r0,r2),r1
    c.r[3] += c.r[7];  // 06052F3C add r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06052F3E extu.b r1,r1
    c.r[1] += c.r[3];  // 06052F40 add r3,r1
    c.r[1] += 1;  // 06052F42 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06052F44 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06052F46 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06052F48 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06052F52; } }  // 06052F4A bf/s 0x06052F52 ; mov r1,r0
    goto L_06053074;  // 06052F4E bra 0x06053074 ; nop
L_06052F52:
    c.t = c.r[0] == 0x1u;  // 06052F52 cmp/eq #1,r0
    if (!c.t) { goto L_06052F5C; }  // 06052F54 bf 0x06052F5C
    c.r[12] = c.r[1];  // 06052F56 mov r1,r12
    c.r[1] = 0xBu; goto L_06053076;  // 06052F58 bra 0x06053076 ; mov #11,r1
L_06052F5C:
    c.r[1] = 0x0u;  // 06052F5C mov #0,r1
    c.r[0] = c.r[7];  // 06052F5E mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06052F60 mov.b r1,@(r0,r2)
    c.r[3] += 1;  // 06052F62 add #1,r3
    c.r[1] = 0x2u;  // 06052F64 mov #2,r1
    st8(c.r[3], c.r[1]);  // 06052F66 mov.b r1,@r3
    c.r[3] = 0x1u;  // 06052F68 mov #1,r3
    c.r[11] = 0x9u;  // 06052F6A mov #9,r11
    c.r[4] = c.r[7];  // 06052F6C mov r7,r4
    c.r[7] = 0x0u;  // 06052F6E mov #0,r7
L_06052F70:
    c.macl = c.r[9] * c.r[5];  // 06052F70 mul.l r5,r9
    c.r[2] = c.macl;  // 06052F72 sts macl,r2
    c.macl = c.r[10] * c.r[6];  // 06052F74 mul.l r6,r10
    c.r[1] = c.macl;  // 06052F76 sts macl,r1
    c.r[2] += c.r[1];  // 06052F78 add r1,r2
    c.r[2] += c.r[4];  // 06052F7A add r4,r2
    c.r[2] += c.r[3];  // 06052F7C add r3,r2
    c.r[2] += 1;  // 06052F7E add #1,r2
    c.r[3] += 1;  // 06052F80 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[11];  // 06052F82 cmp/gt r11,r3
    { const bool k = !c.t; st8(c.r[2], c.r[7]); if (k) { SH2_POLL(c); goto L_06052F70; } }  // 06052F84 bf/s 0x06052F70 ; mov.b r7,@r2
    c.t = (c.r[8] & c.r[8]) == 0;  // 06052F88 tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06052FEE; } }  // 06052F8A bt/s 0x06052FEE ; mov r8,r0
    c.t = c.r[0] == 0x64u;  // 06052F8E cmp/eq #100,r0
    if (c.t) { goto L_06052FA8; }  // 06052F90 bt 0x06052FA8
    c.r[0] = ld32(0x060530C8u);  // 06052F92 mov.l 0x060530C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06052F98u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052F98u) return; }  // 06052F94 jsr @r0 ; add #1,r8
    c.r[1] = 0x64u;  // 06052F98 mov #100,r1
    c.macl = c.r[0] * c.r[1];  // 06052F9A mul.l r1,r0
    c.r[2] = c.macl;  // 06052F9C sts macl,r2
    c.r[2] >>= 16;  // 06052F9E shlr16 r2
    c.r[2] += c.r[8];  // 06052FA0 add r8,r2
    c.t = c.r[2] > c.r[1];  // 06052FA2 cmp/hi r1,r2
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06052FF0; } }  // 06052FA4 bf/s 0x06052FF0 ; mov #0,r8
L_06052FA8:
    c.r[8] = 0x0u;  // 06052FA8 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06052FAA cmp/ge r9,r8
    { const bool k = c.t; c.r[12] = 0x1u; if (k) { goto L_06053038; } }  // 06052FAC bt/s 0x06053038 ; mov #1,r12
    c.r[11] = ld32(0x060530C4u);  // 06052FB0 mov.l 0x060530C4,r11
L_06052FB2:
    c.r[0] = ld32(0x060530C8u);  // 06052FB2 mov.l 0x060530C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06052FB8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06052FB8u) return; }  // 06052FB4 jsr @r0 ; nop
    c.r[1] = 0x9u;  // 06052FB8 mov #9,r1
    c.macl = c.r[0] * c.r[1];  // 06052FBA mul.l r1,r0
    c.r[1] = c.macl;  // 06052FBC sts macl,r1
    c.r[1] >>= 16;  // 06052FBE shlr16 r1
    c.r[1] += 1;  // 06052FC0 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06052FC2 extu.b r1,r3
    c.r[1] = 0xBu;  // 06052FC4 mov #11,r1
    c.macl = c.r[9] * c.r[1];  // 06052FC6 mul.l r1,r9
    c.r[2] = c.macl;  // 06052FC8 sts macl,r2
    c.r[1] = 0x63u;  // 06052FCA mov #99,r1
    c.macl = c.r[10] * c.r[1];  // 06052FCC mul.l r1,r10
    c.r[1] = c.macl;  // 06052FCE sts macl,r1
    c.r[2] += c.r[1];  // 06052FD0 add r1,r2
    c.r[2] += c.r[11];  // 06052FD2 add r11,r2
    c.r[2] += c.r[3];  // 06052FD4 add r3,r2
    c.r[2] += 1;  // 06052FD6 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06052FD8 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06052FDA extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06052FDC cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { SH2_POLL(c); goto L_06052FB2; } }  // 06052FDE bt/s 0x06052FB2 ; mov #1,r1
    c.r[8] += 1;  // 06052FE2 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06052FE4 cmp/ge r9,r8
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06052FB2; } }  // 06052FE6 bf/s 0x06052FB2 ; mov.b r1,@r2
    c.r[8] = 0x0u; goto L_06053038;  // 06052FEA bra 0x06053038 ; mov #0,r8
L_06052FEE:
    c.r[8] = 0x0u;  // 06052FEE mov #0,r8
L_06052FF0:
    c.r[1] = c.r[9];  // 06052FF0 mov r9,r1
    c.r[1] += 1;  // 06052FF2 add #1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06052FF4 cmp/ge r1,r8
    if (c.t) { goto L_06053036; }  // 06052FF6 bt 0x06053036
    c.r[11] = ld32(0x060530C4u);  // 06052FF8 mov.l 0x060530C4,r11
L_06052FFA:
    c.r[0] = ld32(0x060530C8u);  // 06052FFA mov.l 0x060530C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053000u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053000u) return; }  // 06052FFC jsr @r0 ; nop
    c.r[1] = 0x9u;  // 06053000 mov #9,r1
    c.macl = c.r[0] * c.r[1];  // 06053002 mul.l r1,r0
    c.r[1] = c.macl;  // 06053004 sts macl,r1
    c.r[1] >>= 16;  // 06053006 shlr16 r1
    c.r[1] += 1;  // 06053008 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605300A extu.b r1,r3
    c.r[1] = 0xBu;  // 0605300C mov #11,r1
    c.macl = c.r[9] * c.r[1];  // 0605300E mul.l r1,r9
    c.r[2] = c.macl;  // 06053010 sts macl,r2
    c.r[1] = 0x63u;  // 06053012 mov #99,r1
    c.macl = c.r[10] * c.r[1];  // 06053014 mul.l r1,r10
    c.r[1] = c.macl;  // 06053016 sts macl,r1
    c.r[2] += c.r[1];  // 06053018 add r1,r2
    c.r[2] += c.r[11];  // 0605301A add r11,r2
    c.r[2] += c.r[3];  // 0605301C add r3,r2
    c.r[2] += 1;  // 0605301E add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053020 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06053022 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06053024 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { SH2_POLL(c); goto L_06052FFA; } }  // 06053026 bt/s 0x06052FFA ; mov #1,r1
    st8(c.r[2], c.r[1]);  // 0605302A mov.b r1,@r2
    c.r[8] += 1;  // 0605302C add #1,r8
    c.r[1] = c.r[9];  // 0605302E mov r9,r1
    c.r[1] += 1;  // 06053030 add #1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06053032 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06052FFA; }  // 06053034 bf 0x06052FFA
L_06053036:
    c.r[8] = 0x0u;  // 06053036 mov #0,r8
L_06053038:
    c.r[11] = ld32(0x060530C4u);  // 06053038 mov.l 0x060530C4,r11
L_0605303A:
    c.r[0] = ld32(0x060530C8u);  // 0605303A mov.l 0x060530C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053040u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053040u) return; }  // 0605303C jsr @r0 ; nop
    c.r[1] = 0x9u;  // 06053040 mov #9,r1
    c.macl = c.r[0] * c.r[1];  // 06053042 mul.l r1,r0
    c.r[1] = c.macl;  // 06053044 sts macl,r1
    c.r[1] >>= 16;  // 06053046 shlr16 r1
    c.r[1] += 1;  // 06053048 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605304A extu.b r1,r3
    c.r[1] = 0xBu;  // 0605304C mov #11,r1
    c.macl = c.r[9] * c.r[1];  // 0605304E mul.l r1,r9
    c.r[2] = c.macl;  // 06053050 sts macl,r2
    c.r[1] = 0x63u;  // 06053052 mov #99,r1
    c.macl = c.r[10] * c.r[1];  // 06053054 mul.l r1,r10
    c.r[1] = c.macl;  // 06053056 sts macl,r1
    c.r[2] += c.r[1];  // 06053058 add r1,r2
    c.r[2] += c.r[11];  // 0605305A add r11,r2
    c.r[2] += c.r[3];  // 0605305C add r3,r2
    c.r[2] += 1;  // 0605305E add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053060 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06053062 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 06053064 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { SH2_POLL(c); goto L_0605303A; } }  // 06053066 bt/s 0x0605303A ; mov #2,r1
    st8(c.r[2], c.r[1]);  // 0605306A mov.b r1,@r2
    c.r[8] += 1;  // 0605306C add #1,r8
    c.r[1] = 0x2u;  // 0605306E mov #2,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06053070 cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0605303A; }  // 06053072 bf 0x0605303A
L_06053074:
    c.r[1] = 0xBu;  // 06053074 mov #11,r1
L_06053076:
    c.macl = c.r[9] * c.r[1];  // 06053076 mul.l r1,r9
    c.r[0] = c.macl;  // 06053078 sts macl,r0
    c.r[1] = 0x63u;  // 0605307A mov #99,r1
    c.macl = c.r[10] * c.r[1];  // 0605307C mul.l r1,r10
    c.r[2] = ld32(0x060530C4u);  // 0605307E mov.l 0x060530C4,r2
    c.r[1] = c.macl;  // 06053080 sts macl,r1
    c.r[0] += c.r[1];  // 06053082 add r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06053084 mov.b @(r0,r2),r1
    c.r[1] += 1;  // 06053086 add #1,r1
    st8(c.r[0] + c.r[2], c.r[1]); goto L_060530AC;  // 06053088 bra 0x060530AC ; mov.b r1,@(r0,r2)
L_0605308C:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0605308C tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060530AC; } }  // 0605308E bt/s 0x060530AC ; mov r8,r0
    c.t = c.r[0] == 0x64u;  // 06053092 cmp/eq #100,r0
    if (c.t) { goto L_060530AA; }  // 06053094 bt 0x060530AA
    c.r[0] = ld32(0x060530C8u);  // 06053096 mov.l 0x060530C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605309Cu; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605309Cu) return; }  // 06053098 jsr @r0 ; add #1,r8
    c.r[1] = 0x64u;  // 0605309C mov #100,r1
    c.macl = c.r[0] * c.r[1];  // 0605309E mul.l r1,r0
    c.r[2] = c.macl;  // 060530A0 sts macl,r2
    c.r[2] >>= 16;  // 060530A2 shlr16 r2
    c.r[2] += c.r[8];  // 060530A4 add r8,r2
    c.t = c.r[2] > c.r[1];  // 060530A6 cmp/hi r1,r2
    if (!c.t) { goto L_060530AC; }  // 060530A8 bf 0x060530AC
L_060530AA:
    c.r[12] = 0x1u;  // 060530AA mov #1,r12
L_060530AC:
    c.r[15] = c.r[14];  // 060530AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060530AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060530B0 mov.l @r15+,r14
    c.r[0] = c.r[12];  // 060530B2 mov r12,r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060530B4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060530B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060530B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060530BA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060530BC rts ; mov.l @r15+,r8
}

void f_060530CC(SH2Context& c) {
    ran[1306] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060530CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060530CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060530D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060530D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060530D4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060530D6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060530D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060530DA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060531B6u);  // 060530DC mov.w 0x060531B6,r3
    c.r[15] += c.r[3];  // 060530DE add r3,r15
    c.r[14] = c.r[15];  // 060530E0 mov r15,r14
    c.r[11] = c.r[4];  // 060530E2 mov r4,r11
    c.r[13] = c.r[5];  // 060530E4 mov r5,r13
    c.r[11] = c.r[11] & 0xFFu;  // 060530E6 extu.b r11,r11
    c.r[1] = ld32(0x060531BCu);  // 060530E8 mov.l 0x060531BC,r1
    c.r[2] = c.r[11];  // 060530EA mov r11,r2
    c.r[2] <<= 2;  // 060530EC shll2 r2
    c.r[2] <<= 2;  // 060530EE shll2 r2
    c.r[12] = ld32(0x060531C0u);  // 060530F0 mov.l 0x060531C0,r12
    c.r[1] = ld32(c.r[1]);  // 060530F2 mov.l @r1,r1
    c.r[4] = ld32(0x060531C4u);  // 060530F4 mov.l 0x060531C4,r4
    c.r[2] += c.r[1];  // 060530F6 add r1,r2
    c.r[2] += 2;  // 060530F8 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060530FA mov.b @r2,r2
    c.r[1] = 0x1Eu;  // 060530FC mov #30,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060530FE extu.b r2,r2
    c.macl = c.r[2] * c.r[1];  // 06053100 mul.l r1,r2
    c.r[9] = ld32(0x060531C8u);  // 06053102 mov.l 0x060531C8,r9
    c.r[3] = ld32(c.r[12]);  // 06053104 mov.l @r12,r3
    c.r[10] = c.macl;  // 06053106 sts macl,r10
    c.r[0] = c.r[10];  // 06053108 mov r10,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605310A mov.w @(r0,r3),r8
    c.r[5] = 0x1Bu;  // 0605310C mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06053112u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053112u) return; }  // 0605310E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06053112 mov r0,r1
    c.r[5] = c.r[8];  // 06053114 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605311Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605311Au) return; }  // 06053116 jsr @r9 ; mov r1,r4
    c.r[5] = c.r[0];  // 0605311A mov r0,r5
    c.r[5] += 38;  // 0605311C add #38,r5
    c.r[0] = ld32(0x060531CCu);  // 0605311E mov.l 0x060531CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053124u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053124u) return; }  // 06053120 jsr @r0 ; mov r14,r4
    c.r[5] = c.r[0];  // 06053124 mov r0,r5
    c.r[3] = c.r[14];  // 06053126 mov r14,r3
    c.r[3] += 14;  // 06053128 add #14,r3
    c.r[7] = c.r[13];  // 0605312A mov r13,r7
    c.r[6] = c.r[11];  // 0605312C mov r11,r6
    c.r[2] = ld32(c.r[12]);  // 0605312E mov.l @r12,r2
    c.r[4] = c.r[14];  // 06053130 mov r14,r4
    c.r[2] += c.r[10];  // 06053132 add r10,r2
    c.r[1] = c.r[2];  // 06053134 mov r2,r1
    c.r[1] += 15;  // 06053136 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053138 mov.b @r1,r1
    c.r[0] = ld32(0x060531D0u);  // 0605313A mov.l 0x060531D0,r0
    st8(c.r[3], c.r[1]);  // 0605313C mov.b r1,@r3
    c.r[3] = c.r[14];  // 0605313E mov r14,r3
    c.r[1] = c.r[2];  // 06053140 mov r2,r1
    c.r[1] += 7;  // 06053142 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053144 mov.b @r1,r1
    c.r[3] += 6;  // 06053146 add #6,r3
    st8(c.r[3], c.r[1]);  // 06053148 mov.b r1,@r3
    c.r[3] = c.r[14];  // 0605314A mov r14,r3
    c.r[1] = c.r[2];  // 0605314C mov r2,r1
    c.r[1] += 8;  // 0605314E add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053150 mov.b @r1,r1
    c.r[3] += 7;  // 06053152 add #7,r3
    st8(c.r[3], c.r[1]);  // 06053154 mov.b r1,@r3
    c.r[3] = c.r[14];  // 06053156 mov r14,r3
    c.r[1] = c.r[2];  // 06053158 mov r2,r1
    c.r[1] += 9;  // 0605315A add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605315C mov.b @r1,r1
    c.r[3] += 8;  // 0605315E add #8,r3
    st8(c.r[3], c.r[1]);  // 06053160 mov.b r1,@r3
    c.r[3] = c.r[14];  // 06053162 mov r14,r3
    c.r[1] = c.r[2];  // 06053164 mov r2,r1
    c.r[1] += 10;  // 06053166 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053168 mov.b @r1,r1
    c.r[3] += 9;  // 0605316A add #9,r3
    st8(c.r[3], c.r[1]);  // 0605316C mov.b r1,@r3
    c.r[3] = c.r[14];  // 0605316E mov r14,r3
    c.r[1] = c.r[2];  // 06053170 mov r2,r1
    c.r[1] += 11;  // 06053172 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053174 mov.b @r1,r1
    c.r[3] += 10;  // 06053176 add #10,r3
    st8(c.r[3], c.r[1]);  // 06053178 mov.b r1,@r3
    c.r[3] = c.r[14];  // 0605317A mov r14,r3
    c.r[1] = c.r[2];  // 0605317C mov r2,r1
    c.r[1] += 12;  // 0605317E add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053180 mov.b @r1,r1
    c.r[3] += 11;  // 06053182 add #11,r3
    st8(c.r[3], c.r[1]);  // 06053184 mov.b r1,@r3
    c.r[3] = c.r[14];  // 06053186 mov r14,r3
    c.r[3] += 12;  // 06053188 add #12,r3
    c.r[1] = c.r[2];  // 0605318A mov r2,r1
    c.r[1] += 13;  // 0605318C add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605318E mov.b @r1,r1
    c.r[2] += 14;  // 06053190 add #14,r2
    st8(c.r[3], c.r[1]);  // 06053192 mov.b r1,@r3
    c.r[3] = c.r[14];  // 06053194 mov r14,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053196 mov.b @r2,r1
    c.r[3] += 13;  // 06053198 add #13,r3
    { const uint32_t x = c.r[0]; c.pr = 0x0605319Eu; st8(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605319Eu) return; }  // 0605319A jsr @r0 ; mov.b r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x060531B8u);  // 0605319E mov.w 0x060531B8,r3
    c.r[14] += c.r[3];  // 060531A0 add r3,r14
    c.r[15] = c.r[14];  // 060531A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060531A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060531A6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060531A8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060531AA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060531AC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060531AE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060531B0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060531B2 rts ; mov.l @r15+,r8
}

void f_060531D4(SH2Context& c) {
    ran[1307] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060531D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060531D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060531D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060531DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060531DC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060531DE sts.l pr,@-r15
    c.r[15] -= 128;  // 060531E0 add #-128,r15
    c.r[14] = c.r[15];  // 060531E2 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 060531E4 extu.b r4,r11
    c.r[9] = 0x0u;  // 060531E6 mov #0,r9
    c.r[8] = 0x0u;  // 060531E8 mov #0,r8
    c.r[10] = ld32(0x060532CCu);  // 060531EA mov.l 0x060532CC,r10
L_060531EC:
    c.r[1] = ld32(0x060532D0u);  // 060531EC mov.l 0x060532D0,r1
    c.r[0] = c.r[8];  // 060531EE mov r8,r0
    c.r[0] <<= 2;  // 060531F0 shll2 r0
    c.r[0] <<= 2;  // 060531F2 shll2 r0
    c.r[1] = ld32(c.r[1]);  // 060531F4 mov.l @r1,r1
    c.r[3] = c.r[0];  // 060531F6 mov r0,r3
    c.r[3] += c.r[1];  // 060531F8 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060531FA mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060532C6u);  // 060531FC mov.w 0x060532C6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060531FE extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06053200 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06053278; } }  // 06053202 bt/s 0x06053278 ; mov r3,r1
    c.r[1] += 7;  // 06053206 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053208 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605320A mov r1,r0
    c.r[0] >>= 2;  // 0605320C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605320E shlr r0
    c.r[0] &= 0x1u;  // 06053210 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053212 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06053278; } }  // 06053214 bf/s 0x06053278 ; mov r3,r1
    c.r[1] += 3;  // 06053218 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605321A mov.b @r1,r1
    c.r[0] = 0x3u;  // 0605321C mov #3,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605321E shlr r1
    c.r[1] &= c.r[0];  // 06053220 and r0,r1
    c.t = c.r[1] == c.r[11];  // 06053222 cmp/eq r11,r1
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06053278; } }  // 06053224 bf/s 0x06053278 ; tst r1,r1
    if (!c.t) { goto L_06053230; }  // 06053228 bf 0x06053230
    c.r[1] = ld32(c.r[3] + 12);  // 0605322A mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605322C tst r1,r1
    if (!c.t) { goto L_06053278; }  // 0605322E bf 0x06053278
L_06053230:
    c.r[3] += 4;  // 06053230 add #4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053232 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06053234 mov r1,r0
    c.r[0] >>= 2;  // 06053236 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06053238 shlr r0
    c.r[0] >>= 2;  // 0605323A shlr2 r0
    c.r[0] &= 0x1u;  // 0605323C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605323E tst r0,r0
    if (!c.t) { goto L_06053278; }  // 06053240 bf 0x06053278
    c.r[1] = ld32(0x060532D4u);  // 06053242 mov.l 0x060532D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053248u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053248u) return; }  // 06053244 jsr @r1 ; extu.b r8,r4
    c.r[0] = ld32(c.r[10]);  // 06053248 mov.l @r10,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x060532C8u);  // 0605324A mov.w 0x060532C8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605324C mov.b @(r0,r7),r1
    c.r[3] = 0x0u; goto L_06053270;  // 0605324E bra 0x06053270 ; mov #0,r3
L_06053252:
    c.r[1] = c.r[9];  // 06053252 mov r9,r1
    c.r[1] += 1;  // 06053254 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06053256 extu.b r1,r9
    c.r[1] = c.r[3];  // 06053258 mov r3,r1
    c.r[2] = ld32(c.r[10]);  // 0605325A mov.l @r10,r2
    c.r[1] += c.r[1];  // 0605325C add r1,r1
    c.r[2] += c.r[1];  // 0605325E add r1,r2
    c.r[2] += 1;  // 06053260 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053262 mov.b @r2,r1
    c.r[0] = c.r[14];  // 06053264 mov r14,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06053266 mov.b r1,@(r0,r6)
    c.r[1] = ld32(c.r[10]);  // 06053268 mov.l @r10,r1
    c.r[0] = c.r[1];  // 0605326A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605326C mov.b @(r0,r7),r1
    c.r[3] += 1;  // 0605326E add #1,r3
L_06053270:
    c.r[1] = c.r[1] & 0xFFu;  // 06053270 extu.b r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06053272 cmp/ge r1,r3
    { const bool k = !c.t; c.r[6] = c.r[9]; if (k) { SH2_POLL(c); goto L_06053252; } }  // 06053274 bf/s 0x06053252 ; mov r9,r6
L_06053278:
    c.r[8] += 1;  // 06053278 add #1,r8
    c.r[1] = 0x49u;  // 0605327A mov #73,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0605327C cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_060531EC; }  // 0605327E bf 0x060531EC
    c.r[8] = 0x0u;  // 06053280 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06053282 cmp/ge r9,r8
    if (c.t) { goto L_060532AA; }  // 06053284 bt 0x060532AA
    c.r[7] = ld32(0x060532CCu);  // 06053286 mov.l 0x060532CC,r7
L_06053288:
    c.r[3] = c.r[8];  // 06053288 mov r8,r3
    c.r[1] = ld32(c.r[7]);  // 0605328A mov.l @r7,r1
    c.r[0] = c.r[14];  // 0605328C mov r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605328E mov.b @(r0,r8),r2
    c.r[3] += c.r[3];  // 06053290 add r3,r3
    c.r[0] = c.r[1];  // 06053292 mov r1,r0
    c.r[8] += 1;  // 06053294 add #1,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06053296 mov.b @(r0,r3),r6
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06053298 cmp/ge r9,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x060532CAu);  // 0605329A mov.w 0x060532CA,r0
    c.r[6] &= c.r[0];  // 0605329C and r0,r6
    c.r[0] = c.r[1];  // 0605329E mov r1,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 060532A0 mov.b r6,@(r0,r3)
    c.r[1] += c.r[3];  // 060532A2 add r3,r1
    c.r[1] += 1;  // 060532A4 add #1,r1
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_06053288; } }  // 060532A6 bf/s 0x06053288 ; mov.b r2,@r1
L_060532AA:
    c.r[1] = ld32(0x060532CCu);  // 060532AA mov.l 0x060532CC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060532C8u);  // 060532AC mov.w 0x060532C8,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060532CAu);  // 060532AE mov.w 0x060532CA,r3
    c.r[14] += c.r[3];  // 060532B0 add r3,r14
    c.r[1] = ld32(c.r[1]);  // 060532B2 mov.l @r1,r1
    c.r[15] = c.r[14];  // 060532B4 mov r14,r15
    st8(c.r[0] + c.r[1], c.r[9]);  // 060532B6 mov.b r9,@(r0,r1)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060532B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060532BA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060532BC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060532BE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060532C0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060532C2 rts ; mov.l @r15+,r8
}

void f_060532D8(SH2Context& c) {
    ran[1308] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060532D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060532DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060532DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060532DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060532E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060532E2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060532E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060532E6 sts.l pr,@-r15
    c.r[15] -= 12;  // 060532E8 add #-12,r15
    c.r[14] = c.r[15];  // 060532EA mov r15,r14
    c.r[12] = c.r[4] & 0xFFu;  // 060532EC extu.b r4,r12
    c.r[10] = 0x0u;  // 060532EE mov #0,r10
    c.r[7] = 0x49u;  // 060532F0 mov #73,r7
    c.r[3] = ld32(0x0605347Cu);  // 060532F2 mov.l 0x0605347C,r3
L_060532F4:
    c.r[2] = c.r[10];  // 060532F4 mov r10,r2
    c.r[2] += c.r[2];  // 060532F6 add r2,r2
    c.r[1] = ld32(c.r[3]);  // 060532F8 mov.l @r3,r1
    c.r[10] += 1;  // 060532FA add #1,r10
    c.r[0] = c.r[1];  // 060532FC mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060532FE mov.b @(r0,r2),r6
    c.t = (int32_t)c.r[10] > (int32_t)c.r[7];  // 06053300 cmp/gt r7,r10
    c.r[0] = 0x7Fu;  // 06053302 mov #127,r0
    c.r[6] &= c.r[0];  // 06053304 and r0,r6
    c.r[0] = c.r[1];  // 06053306 mov r1,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[6]); if (k) { SH2_POLL(c); goto L_060532F4; } }  // 06053308 bf/s 0x060532F4 ; mov.b r6,@(r0,r2)
    c.r[1] = ld32(0x0605347Cu);  // 0605330C mov.l 0x0605347C,r1
    c.r[2] = ld32(c.r[1]);  // 0605330E mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053478u);  // 06053310 mov.w 0x06053478,r3
    c.r[5] = c.r[14];  // 06053312 mov r14,r5
    c.r[1] = 0x0u;  // 06053314 mov #0,r1
    c.r[0] = c.r[2];  // 06053316 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06053318 mov.b r1,@(r0,r3)
    c.r[1] = ld32(0x06053480u);  // 0605331A mov.l 0x06053480,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053320u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053320u) return; }  // 0605331C jsr @r1 ; mov r12,r4
    c.r[10] = 0x0u;  // 06053320 mov #0,r10
    c.r[13] = 0x1Eu;  // 06053322 mov #30,r13
    c.r[11] = ld32(0x06053484u);  // 06053324 mov.l 0x06053484,r11
    c.r[9] = ld32(0x06053488u);  // 06053326 mov.l 0x06053488,r9
L_06053328:
    c.r[0] = ld32(0x0605348Cu);  // 06053328 mov.l 0x0605348C,r0
    c.r[2] = c.r[10];  // 0605332A mov r10,r2
    c.r[2] <<= 2;  // 0605332C shll2 r2
    c.r[2] <<= 2;  // 0605332E shll2 r2
    c.r[1] = ld32(c.r[0]);  // 06053330 mov.l @r0,r1
    c.r[3] = c.r[2];  // 06053332 mov r2,r3
    c.r[3] += c.r[1];  // 06053334 add r1,r3
    c.r[0] = c.r[2];  // 06053336 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053338 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605333A extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605347Au);  // 0605333C mov.w 0x0605347A,r2
    c.t = c.r[1] == c.r[2];  // 0605333E cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060533F8; } }  // 06053340 bt/s 0x060533F8 ; mov r3,r1
    c.r[1] += 7;  // 06053344 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053346 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06053348 mov r1,r0
    c.r[0] >>= 2;  // 0605334A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605334C shlr r0
    c.r[0] &= 0x1u;  // 0605334E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053350 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_060533F8; } }  // 06053352 bf/s 0x060533F8 ; mov r3,r1
    c.r[1] += 4;  // 06053356 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053358 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605335A mov r1,r0
    c.r[0] >>= 2;  // 0605335C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605335E shlr r0
    c.r[0] >>= 2;  // 06053360 shlr2 r0
    c.r[0] &= 0x1u;  // 06053362 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053364 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060533F8; } }  // 06053366 bt/s 0x060533F8 ; mov r3,r1
    c.r[1] += 6;  // 0605336A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605336C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605336E extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 06053370 cmp/eq r12,r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_060533F8; } }  // 06053372 bf/s 0x060533F8 ; add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053376 mov.b @r3,r1
    c.r[0] = ld32(0x06053490u);  // 06053378 mov.l 0x06053490,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0605337A extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 0605337C mul.l r13,r1
    c.r[5] = 0x1Bu;  // 0605337E mov #27,r5
    c.r[2] = ld32(c.r[0]);  // 06053380 mov.l @r0,r2
    c.r[1] = c.macl;  // 06053382 sts macl,r1
    c.r[0] = c.r[1];  // 06053384 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06053386 mov.w @(r0,r2),r8
    c.r[4] = c.r[11];  // 06053388 mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0605338Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605338Eu) return; }  // 0605338A jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0605338E mov r0,r1
    c.r[5] = c.r[8];  // 06053390 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06053396u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053396u) return; }  // 06053392 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06053396 mov r0,r1
    c.r[1] += 7;  // 06053398 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605339A mov.b @r1,r1
    c.r[2] = 0x78u;  // 0605339C mov #120,r2
    c.r[2] &= c.r[1];  // 0605339E and r1,r2
    c.r[2] >>= 2;  // 060533A0 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060533A2 shlr r2
    c.r[0] = c.r[2];  // 060533A4 mov r2,r0
    c.t = c.r[0] == 0x9u;  // 060533A6 cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_060533F0; } }  // 060533A8 bf/s 0x060533F0 ; mov r1,r0
    c.r[0] &= 0x7u;  // 060533AC and #7,r0
    c.t = c.r[0] == 0x1u;  // 060533AE cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { goto L_060533F0; } }  // 060533B0 bf/s 0x060533F0 ; mov r12,r2
    c.r[0] = ld32(0x0605348Cu);  // 060533B4 mov.l 0x0605348C,r0
    c.r[1] = ld32(c.r[0]);  // 060533B6 mov.l @r0,r1
    c.r[2] <<= 2;  // 060533B8 shll2 r2
    c.r[2] <<= 2;  // 060533BA shll2 r2
    c.r[2] += c.r[1];  // 060533BC add r1,r2
    c.r[2] += 2;  // 060533BE add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060533C0 mov.b @r2,r1
    c.r[5] = 0x1Bu;  // 060533C2 mov #27,r5
    c.r[1] = c.r[1] & 0xFFu;  // 060533C4 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 060533C6 mul.l r13,r1
    c.r[0] = ld32(0x06053490u);  // 060533C8 mov.l 0x06053490,r0
    c.r[2] = ld32(c.r[0]);  // 060533CA mov.l @r0,r2
    c.r[1] = c.macl;  // 060533CC sts macl,r1
    c.r[0] = c.r[1];  // 060533CE mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060533D0 mov.w @(r0,r2),r8
    c.r[4] = c.r[11];  // 060533D2 mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060533D8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060533D8u) return; }  // 060533D4 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060533D8 mov r0,r1
    c.r[5] = c.r[8];  // 060533DA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060533E0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060533E0u) return; }  // 060533DC jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060533E0 mov r0,r1
    c.r[1] += 7;  // 060533E2 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060533E4 mov.b @r1,r1
    c.r[0] = 0x7u;  // 060533E6 mov #7,r0
    c.r[1] &= c.r[0];  // 060533E8 and r0,r1
    c.r[0] = c.r[1];  // 060533EA mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060533EC cmp/eq #2,r0
    if (!c.t) { goto L_060533F8; }  // 060533EE bf 0x060533F8
L_060533F0:
    c.r[4] = c.r[10] & 0xFFu;  // 060533F0 extu.b r10,r4
    c.r[1] = ld32(0x06053480u);  // 060533F2 mov.l 0x06053480,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060533F8u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060533F8u) return; }  // 060533F4 jsr @r1 ; mov r14,r5
L_060533F8:
    c.r[10] += 1;  // 060533F8 add #1,r10
    c.r[1] = 0x49u;  // 060533FA mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060533FC cmp/gt r1,r10
    { const bool k = !c.t; c.r[2] = 0x1u; if (k) { SH2_POLL(c); goto L_06053328; } }  // 060533FE bf/s 0x06053328 ; mov #1,r2
    c.r[13] = ld32(0x0605347Cu);  // 06053402 mov.l 0x0605347C,r13
    c.r[1] = ld32(c.r[13]);  // 06053404 mov.l @r13,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06053478u);  // 06053406 mov.w 0x06053478,r11
    c.r[0] = c.r[1];  // 06053408 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0605340A mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605340C extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0605340E cmp/hi r2,r1
    { const bool k = c.t; c.r[12] <<= 2; if (k) { goto L_06053418; } }  // 06053410 bt/s 0x06053418 ; shll2 r12
    goto L_06053542;  // 06053414 bra 0x06053542 ; nop
L_06053418:
    c.r[1] = ld32(0x0605348Cu);  // 06053418 mov.l 0x0605348C,r1
    c.r[1] = ld32(c.r[1]);  // 0605341A mov.l @r1,r1
    c.r[12] <<= 2;  // 0605341C shll2 r12
    c.r[12] += c.r[1];  // 0605341E add r1,r12
    c.r[12] += 2;  // 06053420 add #2,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06053422 mov.b @r12,r2
    c.r[1] = ld32(0x06053490u);  // 06053424 mov.l 0x06053490,r1
    c.r[3] = ld32(c.r[1]);  // 06053426 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06053428 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605342A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605342C mul.l r1,r2
    c.r[4] = ld32(0x06053484u);  // 0605342E mov.l 0x06053484,r4
    c.r[9] = ld32(0x06053488u);  // 06053430 mov.l 0x06053488,r9
    c.r[1] = c.macl;  // 06053432 sts macl,r1
    c.r[0] = c.r[1];  // 06053434 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06053436 mov.w @(r0,r3),r8
    c.r[5] = 0x1Bu;  // 06053438 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0605343Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605343Eu) return; }  // 0605343A jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0605343E mov r0,r1
    c.r[5] = c.r[8];  // 06053440 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06053446u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053446u) return; }  // 06053442 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06053446 mov r0,r1
    c.r[1] += 7;  // 06053448 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605344A mov.b @r1,r1
    c.r[0] = 0x78u;  // 0605344C mov #120,r0
    c.r[1] &= c.r[0];  // 0605344E and r0,r1
    c.r[1] >>= 2;  // 06053450 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06053452 shlr r1
    c.r[0] = c.r[1];  // 06053454 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 06053456 cmp/eq #4,r0
    c.r[10] = c.t;  // 06053458 movt r10
    c.r[0] = 0x1u;  // 0605345A mov #1,r0
    c.r[1] = ld32(c.r[13]);  // 0605345C mov.l @r13,r1
    c.r[10] ^= c.r[0];  // 0605345E xor r0,r10
    c.r[0] = c.r[1];  // 06053460 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06053462 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06053464 extu.b r1,r1
    c.r[1] -= 1;  // 06053466 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06053468 cmp/ge r1,r10
    { const bool k = c.t; c.r[13] = c.r[11]; if (k) { goto L_06053542; } }  // 0605346A bt/s 0x06053542 ; mov r11,r13
    c.r[11] = c.r[10];  // 0605346E mov r10,r11
    c.r[11] += c.r[14];  // 06053470 add r14,r11
L_06053472:
    c.r[0] = ld32(0x0605347Cu);  // 06053472 mov.l 0x0605347C,r0
    c.r[1] = ld32(c.r[0]); goto L_06053494;  // 06053474 bra 0x06053494 ; mov.l @r0,r1
L_06053494:
    c.r[9] = c.r[10];  // 06053494 mov r10,r9
    c.r[0] = c.r[1];  // 06053496 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06053498 mov.b @(r0,r13),r1
    c.r[9] += 1;  // 0605349A add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0605349C extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0605349E cmp/ge r1,r9
    if (c.t) { goto L_0605352E; }  // 060534A0 bt 0x0605352E
    c.r[12] = c.r[10];  // 060534A2 mov r10,r12
    c.r[12] += c.r[12];  // 060534A4 add r12,r12
    c.r[8] = c.r[9];  // 060534A6 mov r9,r8
    c.r[8] += c.r[14];  // 060534A8 add r14,r8
L_060534AA:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060534AA mov.b @r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060534AC mov.b @r8,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060534AE extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060534B0 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 060534B2 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = 0x7Fu; if (k) { goto L_0605351C; } }  // 060534B4 bf/s 0x0605351C ; mov #127,r1
    c.r[0] = ld32(0x0605355Cu);  // 060534B8 mov.l 0x0605355C,r0
    c.r[3] = ld32(c.r[0]);  // 060534BA mov.l @r0,r3
    c.r[5] = c.r[9];  // 060534BC mov r9,r5
    c.r[0] = c.r[3];  // 060534BE mov r3,r0
    c.r[6] = c.r[3];  // 060534C0 mov r3,r6
    c.r[6] += c.r[12];  // 060534C2 add r12,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060534C4 mov.b @(r0,r12),r4
    c.r[6] += 1;  // 060534C6 add #1,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060534C8 mov.b @r6,r7
    c.r[1] &= c.r[4];  // 060534CA and r4,r1
    c.r[1] <<= 8;  // 060534CC shll8 r1
    c.r[7] = c.r[7] & 0xFFu;  // 060534CE extu.b r7,r7
    c.r[7] |= c.r[1];  // 060534D0 or r1,r7
    c.r[5] += c.r[5];  // 060534D2 add r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060534D4 mov.b @(r0,r5),r1
    c.r[2] = 0x7Fu;  // 060534D6 mov #127,r2
    c.r[2] &= c.r[1];  // 060534D8 and r1,r2
    c.r[2] <<= 8;  // 060534DA shll8 r2
    c.r[1] = c.r[3];  // 060534DC mov r3,r1
    c.r[1] += c.r[5];  // 060534DE add r5,r1
    c.r[1] += 1;  // 060534E0 add #1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053558u);  // 060534E2 mov.w 0x06053558,r0
    c.r[4] &= c.r[0];  // 060534E4 and r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060534E6 mov.b @r1,r1
    c.r[0] = c.r[3];  // 060534E8 mov r3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060534EA extu.b r1,r1
    c.r[1] |= c.r[2];  // 060534EC or r2,r1
    c.r[2] = c.r[1];  // 060534EE mov r1,r2
    c.r[2] >>= 8;  // 060534F0 shlr8 r2
    c.r[4] |= c.r[2];  // 060534F2 or r2,r4
    st8(c.r[0] + c.r[12], c.r[4]);  // 060534F4 mov.b r4,@(r0,r12)
    st8(c.r[6], c.r[1]);  // 060534F6 mov.b r1,@r6
    c.r[0] = ld32(0x0605355Cu);  // 060534F8 mov.l 0x0605355C,r0
    c.r[1] = ld32(c.r[0]);  // 060534FA mov.l @r0,r1
    c.r[2] = c.r[7];  // 060534FC mov r7,r2
    c.r[0] = c.r[1];  // 060534FE mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06053500 mov.b @(r0,r5),r3
    c.r[2] >>= 8;  // 06053502 shlr8 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053558u);  // 06053504 mov.w 0x06053558,r0
    c.r[3] &= c.r[0];  // 06053506 and r0,r3
    c.r[3] |= c.r[2];  // 06053508 or r2,r3
    c.r[0] = c.r[1];  // 0605350A mov r1,r0
    st8(c.r[0] + c.r[5], c.r[3]);  // 0605350C mov.b r3,@(r0,r5)
    c.r[1] += c.r[5];  // 0605350E add r5,r1
    c.r[1] += 1;  // 06053510 add #1,r1
    st8(c.r[1], c.r[7]);  // 06053512 mov.b r7,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06053514 mov.b @r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06053516 mov.b @r11,r2
    st8(c.r[11], c.r[1]);  // 06053518 mov.b r1,@r11
    st8(c.r[8], c.r[2]);  // 0605351A mov.b r2,@r8
L_0605351C:
    c.r[1] = ld32(0x0605355Cu);  // 0605351C mov.l 0x0605355C,r1
    c.r[1] = ld32(c.r[1]);  // 0605351E mov.l @r1,r1
    c.r[0] = c.r[1];  // 06053520 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06053522 mov.b @(r0,r13),r1
    c.r[9] += 1;  // 06053524 add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06053526 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06053528 cmp/ge r1,r9
    { const bool k = !c.t; c.r[8] += 1; if (k) { SH2_POLL(c); goto L_060534AA; } }  // 0605352A bf/s 0x060534AA ; add #1,r8
L_0605352E:
    c.r[0] = ld32(0x0605355Cu);  // 0605352E mov.l 0x0605355C,r0
    c.r[1] = ld32(c.r[0]);  // 06053530 mov.l @r0,r1
    c.r[0] = c.r[1];  // 06053532 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06053534 mov.b @(r0,r13),r1
    c.r[10] += 1;  // 06053536 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06053538 extu.b r1,r1
    c.r[1] -= 1;  // 0605353A add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0605353C cmp/ge r1,r10
    { const bool k = !c.t; c.r[11] += 1; if (k) { SH2_POLL(c); goto L_06053472; } }  // 0605353E bf/s 0x06053472 ; add #1,r11
L_06053542:
    c.r[14] += 12;  // 06053542 add #12,r14
    c.r[15] = c.r[14];  // 06053544 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053546 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053548 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605354A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605354C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605354E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053550 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053552 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053554 rts ; mov.l @r15+,r8
}

void f_06053560(SH2Context& c) {
    ran[1309] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053560 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053562 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053564 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053566 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06053568 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605356A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605356C sts.l pr,@-r15
    c.r[11] = c.r[5];  // 0605356E mov r5,r11
    c.r[4] = c.r[4] & 0xFFu;  // 06053570 extu.b r4,r4
    c.r[12] = ld32(0x060536A8u);  // 06053572 mov.l 0x060536A8,r12
    c.r[3] = ld32(c.r[12]);  // 06053574 mov.l @r12,r3
    c.r[10] = (uint32_t)(int16_t)ld16(0x060536A4u);  // 06053576 mov.w 0x060536A4,r10
    c.r[0] = c.r[3];  // 06053578 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0605357A mov.b @(r0,r10),r1
    c.r[5] = ld32(0x060536ACu);  // 0605357C mov.l 0x060536AC,r5
    c.r[8] = c.r[1] & 0xFFu;  // 0605357E extu.b r1,r8
    c.r[8] += c.r[8];  // 06053580 add r8,r8
    c.r[1] = ld32(c.r[5]);  // 06053582 mov.l @r5,r1
    c.r[4] <<= 2;  // 06053584 shll2 r4
    c.r[4] <<= 2;  // 06053586 shll2 r4
    c.r[1] += c.r[4];  // 06053588 add r4,r1
    c.r[1] += 2;  // 0605358A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605358C mov.b @r1,r1
    c.r[7] = 0x1Eu;  // 0605358E mov #30,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06053590 extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 06053592 mul.l r7,r1
    c.r[6] = ld32(0x060536B0u);  // 06053594 mov.l 0x060536B0,r6
    c.r[2] = ld32(c.r[6]);  // 06053596 mov.l @r6,r2
    c.r[1] = c.macl;  // 06053598 sts macl,r1
    c.r[1] += c.r[2];  // 0605359A add r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605359C mov.b @(r0,r8),r2
    c.r[1] += 15;  // 0605359E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060535A0 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060536A6u);  // 060535A2 mov.w 0x060536A6,r0
    c.r[2] &= c.r[0];  // 060535A4 and r0,r2
    c.r[0] = c.r[3];  // 060535A6 mov r3,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 060535A8 mov.b r2,@(r0,r8)
    c.r[3] += c.r[8];  // 060535AA add r8,r3
    c.r[3] += 1;  // 060535AC add #1,r3
    st8(c.r[3], c.r[1]);  // 060535AE mov.b r1,@r3
    c.r[1] = ld32(c.r[5]);  // 060535B0 mov.l @r5,r1
    c.r[14] = c.r[15];  // 060535B2 mov r15,r14
    c.r[4] += c.r[1];  // 060535B4 add r1,r4
    c.r[4] += 2;  // 060535B6 add #2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060535B8 mov.b @r4,r1
    c.r[9] = ld32(0x060536B4u);  // 060535BA mov.l 0x060536B4,r9
    c.r[1] = c.r[1] & 0xFFu;  // 060535BC extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 060535BE mul.l r7,r1
    c.r[2] = ld32(c.r[6]);  // 060535C0 mov.l @r6,r2
    c.r[5] = 0x1Bu;  // 060535C2 mov #27,r5
    c.r[1] = c.macl;  // 060535C4 sts macl,r1
    c.r[0] = c.r[1];  // 060535C6 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060535C8 mov.w @(r0,r2),r8
    c.r[4] = ld32(0x060536B8u);  // 060535CA mov.l 0x060536B8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060535D0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060535D0u) return; }  // 060535CC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060535D0 mov r0,r1
    c.r[5] = c.r[8];  // 060535D2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060535D8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060535D8u) return; }  // 060535D4 jsr @r9 ; mov r1,r4
    c.r[1] = ld32(c.r[12]);  // 060535D8 mov.l @r12,r1
    c.r[2] = c.r[0];  // 060535DA mov r0,r2
    c.r[0] = c.r[1];  // 060535DC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060535DE mov.b @(r0,r10),r1
    c.r[2] += 7;  // 060535E0 add #7,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060535E2 mov.b @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060535E4 extu.b r1,r1
    c.r[0] = 0x7u;  // 060535E6 mov #7,r0
    c.r[2] &= c.r[0];  // 060535E8 and r0,r2
    c.r[0] = c.r[11];  // 060535EA mov r11,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 060535EC mov.b r2,@(r0,r1)
    c.r[2] = ld32(c.r[12]);  // 060535EE mov.l @r12,r2
    c.r[0] = c.r[2];  // 060535F0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060535F2 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060535F4 extu.b r1,r1
    c.r[1] += c.r[1];  // 060535F6 add r1,r1
    c.r[2] += c.r[1];  // 060535F8 add r1,r2
    c.r[2] += 1;  // 060535FA add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060535FC mov.b @r2,r1
    c.r[3] = ld32(0x060536BCu);  // 060535FE mov.l 0x060536BC,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06053600 extu.b r1,r6
    c.r[7] = c.r[6];  // 06053602 mov r6,r7
    c.r[7] += c.r[7];  // 06053604 add r7,r7
    c.r[2] = c.r[7];  // 06053606 mov r7,r2
    c.r[2] += c.r[6];  // 06053608 add r6,r2
    c.r[1] = ld32(c.r[3]);  // 0605360A mov.l @r3,r1
    c.r[2] <<= 2;  // 0605360C shll2 r2
    c.r[2] += c.r[1];  // 0605360E add r1,r2
    c.r[2] += 8;  // 06053610 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053612 mov.b @r2,r1
    c.r[8] = 0xFFFFFFFFu;  // 06053614 mov #-1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06053616 extu.b r1,r1
    c.r[2] = c.r[8] & 0xFFu;  // 06053618 extu.b r8,r2
    c.t = c.r[1] == c.r[2];  // 0605361A cmp/eq r2,r1
    { const bool k = c.t; c.r[4] = c.r[3]; if (k) { goto L_06053686; } }  // 0605361C bt/s 0x06053686 ; mov r3,r4
    c.r[3] = c.r[12];  // 06053620 mov r12,r3
    c.r[5] = c.r[10];  // 06053622 mov r10,r5
    c.r[7] += c.r[6];  // 06053624 add r6,r7
L_06053626:
    c.r[1] = ld32(c.r[4]);  // 06053626 mov.l @r4,r1
    c.r[7] <<= 2;  // 06053628 shll2 r7
    c.r[2] = ld32(c.r[3]);  // 0605362A mov.l @r3,r2
    c.r[7] += c.r[1];  // 0605362C add r1,r7
    c.r[7] += 8;  // 0605362E add #8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06053630 mov.b @r7,r1
    c.r[0] = c.r[2];  // 06053632 mov r2,r0
    c.r[6] = c.r[1] & 0xFFu;  // 06053634 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06053636 mov.b @(r0,r5),r1
    c.r[1] += 1;  // 06053638 add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 0605363A mov.b r1,@(r0,r5)
    c.r[2] = ld32(c.r[3]);  // 0605363C mov.l @r3,r2
    c.r[0] = c.r[2];  // 0605363E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06053640 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06053642 extu.b r1,r1
    c.r[1] += c.r[1];  // 06053644 add r1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053646 mov.b @(r0,r1),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060536A6u);  // 06053648 mov.w 0x060536A6,r0
    c.r[7] &= c.r[0];  // 0605364A and r0,r7
    c.r[0] = c.r[2];  // 0605364C mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0605364E mov.b r7,@(r0,r1)
    c.r[2] += c.r[1];  // 06053650 add r1,r2
    c.r[2] += 1;  // 06053652 add #1,r2
    st8(c.r[2], c.r[6]);  // 06053654 mov.b r6,@r2
    c.r[1] = ld32(c.r[3]);  // 06053656 mov.l @r3,r1
    c.r[7] = c.r[6];  // 06053658 mov r6,r7
    c.r[0] = c.r[1];  // 0605365A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0605365C mov.b @(r0,r5),r1
    c.r[7] += c.r[7];  // 0605365E add r7,r7
    c.r[2] = c.r[1] & 0xFFu;  // 06053660 extu.b r1,r2
    c.r[1] = c.r[2];  // 06053662 mov r2,r1
    c.r[1] += c.r[11];  // 06053664 add r11,r1
    c.r[1] -= 1;  // 06053666 add #-1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053668 mov.b @r1,r1
    c.r[0] = c.r[11];  // 0605366A mov r11,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0605366C mov.b r1,@(r0,r2)
    c.r[2] = c.r[7];  // 0605366E mov r7,r2
    c.r[2] += c.r[6];  // 06053670 add r6,r2
    c.r[1] = ld32(c.r[4]);  // 06053672 mov.l @r4,r1
    c.r[2] <<= 2;  // 06053674 shll2 r2
    c.r[2] += c.r[1];  // 06053676 add r1,r2
    c.r[2] += 8;  // 06053678 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605367A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605367C extu.b r1,r1
    c.r[2] = c.r[8] & 0xFFu;  // 0605367E extu.b r8,r2
    c.t = c.r[1] == c.r[2];  // 06053680 cmp/eq r2,r1
    { const bool k = !c.t; c.r[7] += c.r[6]; if (k) { SH2_POLL(c); goto L_06053626; } }  // 06053682 bf/s 0x06053626 ; add r6,r7
L_06053686:
    c.r[1] = ld32(0x060536A8u);  // 06053686 mov.l 0x060536A8,r1
    c.r[2] = ld32(c.r[1]);  // 06053688 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060536A4u);  // 0605368A mov.w 0x060536A4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605368C mov.b @(r0,r2),r1
    c.r[15] = c.r[14];  // 0605368E mov r14,r15
    c.r[1] += 1;  // 06053690 add #1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06053692 mov.b r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053694 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053696 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06053698 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605369A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605369C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605369E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060536A0 rts ; mov.l @r15+,r8
}

void f_060536C0(SH2Context& c) {
    ran[1310] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060536C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060536C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060536C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060536C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060536C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060536CA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060536CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060536CE sts.l pr,@-r15
    c.r[15] -= 76;  // 060536D0 add #-76,r15
    c.r[14] = c.r[15];  // 060536D2 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060536D4 extu.b r4,r4
    st32(c.r[14] + 52, c.r[4]);  // 060536D6 mov.l r4,@(52,r14)
    c.r[0] = 0x0u;  // 060536D8 mov #0,r0
    st32(c.r[14] + 60, c.r[0]);  // 060536DA mov.l r0,@(60,r14)
    c.r[11] = 0x40u;  // 060536DC mov #64,r11
    c.r[11] += c.r[14];  // 060536DE add r14,r11
    st32(c.r[11], c.r[0]);  // 060536E0 mov.l r0,@r11
    c.r[11] = 0x0u;  // 060536E2 mov #0,r11
    st32(c.r[14] + 56, c.r[11]);  // 060536E4 mov.l r11,@(56,r14)
    c.r[13] = c.r[14];  // 060536E6 mov r14,r13
    c.r[13] += 48;  // 060536E8 add #48,r13
    c.r[0] = 0x44u;  // 060536EA mov #68,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 060536EC mov.l r11,@(r0,r14)
L_060536EE:
    c.r[11] = 0x44u;  // 060536EE mov #68,r11
    c.r[11] += c.r[14];  // 060536F0 add r14,r11
    c.r[3] = ld32(c.r[11]);  // 060536F2 mov.l @r11,r3
    c.r[0] = ld32(0x06053884u);  // 060536F4 mov.l 0x06053884,r0
    c.r[1] = ld32(c.r[0]);  // 060536F6 mov.l @r0,r1
    c.r[11] = 0x44u;  // 060536F8 mov #68,r11
    c.r[11] += c.r[14];  // 060536FA add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060536FC mov.l @r11,r0
    c.r[3] += c.r[1];  // 060536FE add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053700 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605387Eu);  // 06053702 mov.w 0x0605387E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06053704 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06053706 cmp/eq r2,r1
    { const bool k = !c.t; c.r[11] = 0x44u; if (k) { goto L_06053710; } }  // 06053708 bf/s 0x06053710 ; mov #68,r11
    goto L_06053912;  // 0605370C bra 0x06053912 ; nop
L_06053710:
    c.r[1] = c.r[3];  // 06053710 mov r3,r1
    c.r[1] += 7;  // 06053712 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053714 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06053716 mov r1,r0
    c.r[0] >>= 2;  // 06053718 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605371A shlr r0
    c.r[0] &= 0x1u;  // 0605371C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605371E tst r0,r0
    { const bool k = c.t; c.r[11] += c.r[14]; if (k) { goto L_06053728; } }  // 06053720 bt/s 0x06053728 ; add r14,r11
    goto L_06053914;  // 06053724 bra 0x06053914 ; nop
L_06053728:
    c.r[0] = ld32(c.r[14] + 56);  // 06053728 mov.l @(56,r14),r0
    c.r[11] = ld32(c.r[14] + 52);  // 0605372A mov.l @(52,r14),r11
    c.t = c.r[0] == c.r[11];  // 0605372C cmp/eq r11,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0605375A; } }  // 0605372E bt/s 0x0605375A ; mov r3,r1
    c.r[1] += 4;  // 06053732 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053734 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06053736 mov r1,r0
    c.r[0] >>= 2;  // 06053738 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605373A shlr r0
    c.r[0] >>= 2;  // 0605373C shlr2 r0
    c.r[0] &= 0x1u;  // 0605373E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053740 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0605374A; } }  // 06053742 bf/s 0x0605374A ; mov r3,r1
    goto L_06053910;  // 06053746 bra 0x06053910 ; nop
L_0605374A:
    c.r[1] += 6;  // 0605374A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605374C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605374E extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06053750 cmp/eq r11,r1
    { const bool k = c.t; c.r[11] = 0x44u; if (k) { goto L_0605375A; } }  // 06053752 bt/s 0x0605375A ; mov #68,r11
    goto L_06053912;  // 06053756 bra 0x06053912 ; nop
L_0605375A:
    c.r[3] += 2;  // 0605375A add #2,r3
    c.r[0] = ld32(0x06053888u);  // 0605375C mov.l 0x06053888,r0
    c.r[9] = 0x1Eu;  // 0605375E mov #30,r9
    c.r[8] = c.r[14];  // 06053760 mov r14,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053762 mov.b @r3,r1
    c.r[8] += 49;  // 06053764 add #49,r8
    c.r[2] = ld32(c.r[0]);  // 06053766 mov.l @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06053768 extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 0605376A mul.l r9,r1
    c.r[11] = ld32(0x0605388Cu);  // 0605376C mov.l 0x0605388C,r11
    c.r[0] = 0x3Bu;  // 0605376E mov #59,r0
    c.r[1] = c.macl;  // 06053770 sts macl,r1
    c.r[1] += c.r[2];  // 06053772 add r2,r1
    c.r[1] += 15;  // 06053774 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053776 mov.b @r1,r2
    c.r[0] += c.r[14];  // 06053778 add r14,r0
    st8(c.r[13], c.r[2]);  // 0605377A mov.b r2,@r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605377C mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605377E extu.b r2,r2
    st8(c.r[8], c.r[1]);  // 06053780 mov.b r1,@r8
    c.r[3] = c.r[2];  // 06053782 mov r2,r3
    c.r[3] += c.r[3];  // 06053784 add r3,r3
    c.r[3] += c.r[2];  // 06053786 add r2,r3
    c.r[1] = ld32(c.r[11]);  // 06053788 mov.l @r11,r1
    c.r[3] <<= 2;  // 0605378A shll2 r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605378C mov.b @r0,r0
    c.r[3] += c.r[1];  // 0605378E add r1,r3
    c.r[3] += 2;  // 06053790 add #2,r3
    c.r[10] = c.r[0] & 0xFFu;  // 06053792 extu.b r0,r10
    c.r[4] = c.r[10];  // 06053794 mov r10,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053796 mov.b @r3,r1
    c.r[11] = ld32(0x06053890u);  // 06053798 mov.l 0x06053890,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0605379Eu; c.r[12] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605379Eu) return; }  // 0605379A jsr @r11 ; extu.b r1,r12
    c.r[1] = c.r[0];  // 0605379E mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060537A0 extu.b r1,r1
    c.r[0] = 0x48u;  // 060537A2 mov #72,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 060537A4 mov.l r1,@(r0,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060537A6 mov.b @r8,r1
    c.r[11] = ld32(0x06053888u);  // 060537A8 mov.l 0x06053888,r11
    c.r[1] = c.r[1] & 0xFFu;  // 060537AA extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 060537AC mul.l r9,r1
    c.r[4] = 0x0u;  // 060537AE mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060537B0 mov.l @r11,r2
    c.r[1] = c.macl;  // 060537B2 sts macl,r1
    c.r[0] = c.r[1];  // 060537B4 mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060537B6 mov.w @(r0,r2),r5
    c.r[11] = ld32(0x06053894u);  // 060537B8 mov.l 0x06053894,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060537BEu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060537BEu) return; }  // 060537BA jsr @r11 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 060537BE mov r0,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060537C0 extu.w r1,r8
    c.r[1] = ld32(0x06053898u);  // 060537C2 mov.l 0x06053898,r1
    c.t = c.r[8] == c.r[1];  // 060537C4 cmp/eq r1,r8
    if (c.t) { goto L_060537DA; }  // 060537C6 bt 0x060537DA
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060537C8 mov.b @r13,r4
    c.r[0] = ld32(0x0605389Cu);  // 060537CA mov.l 0x0605389C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060537D0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060537D0u) return; }  // 060537CC jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 060537D0 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060537D2 extu.b r1,r1
    c.r[11] = 0x40u;  // 060537D4 mov #64,r11
    c.r[11] += c.r[14];  // 060537D6 add r14,r11
    st32(c.r[11], c.r[1]);  // 060537D8 mov.l r1,@r11
L_060537DA:
    c.r[0] = ld32(0x060538A0u);  // 060537DA mov.l 0x060538A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060537E0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060537E0u) return; }  // 060537DC jsr @r0 ; mov r10,r4
    c.r[1] = c.r[0];  // 060537E0 mov r0,r1
    c.r[0] = ld32(c.r[14] + 56);  // 060537E2 mov.l @(56,r14),r0
    c.r[11] = ld32(c.r[14] + 52);  // 060537E4 mov.l @(52,r14),r11
    c.t = c.r[0] == c.r[11];  // 060537E6 cmp/eq r11,r0
    { const bool k = !c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_060538B0; } }  // 060537E8 bf/s 0x060538B0 ; extu.b r1,r1
    st32(c.r[14] + 60, c.r[1]);  // 060537EC mov.l r1,@(60,r14)
    c.r[0] = 0x48u;  // 060537EE mov #72,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060537F0 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060537F2 tst r0,r0
    if (!c.t) { goto L_0605381A; }  // 060537F4 bf 0x0605381A
    c.r[11] = ld32(0x06053890u);  // 060537F6 mov.l 0x06053890,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060537FCu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060537FCu) return; }  // 060537F8 jsr @r11 ; mov r10,r4
    c.r[1] = c.r[0];  // 060537FC mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060537FE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06053800 tst r1,r1
    { const bool k = c.t; c.r[11] = 0x44u; if (k) { goto L_0605381A; } }  // 06053802 bt/s 0x0605381A ; mov #68,r11
    c.r[0] = ld32(0x06053884u);  // 06053806 mov.l 0x06053884,r0
    c.r[1] = ld32(c.r[0]);  // 06053808 mov.l @r0,r1
    c.r[11] += c.r[14];  // 0605380A add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0605380C mov.l @r11,r11
    c.r[1] += c.r[11];  // 0605380E add r11,r1
    c.r[1] += 7;  // 06053810 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053812 mov.b @r1,r2
    c.r[0] = 0x20u;  // 06053814 mov #32,r0
    c.r[2] |= c.r[0];  // 06053816 or r0,r2
    st8(c.r[1], c.r[2]);  // 06053818 mov.b r2,@r1
L_0605381A:
    c.r[1] = ld32(0x06053898u);  // 0605381A mov.l 0x06053898,r1
    c.t = c.r[8] == c.r[1];  // 0605381C cmp/eq r1,r8
    { const bool k = c.t; c.r[11] = 0x44u; if (k) { goto L_06053912; } }  // 0605381E bt/s 0x06053912 ; mov #68,r11
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06053822 mov.b @r13,r4
    c.r[11] = ld32(0x0605389Cu);  // 06053824 mov.l 0x0605389C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0605382Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605382Au) return; }  // 06053826 jsr @r11 ; extu.b r4,r4
    c.r[5] = c.r[0];  // 0605382A mov r0,r5
    c.r[1] = ld32(0x060538A4u);  // 0605382C mov.l 0x060538A4,r1
    c.r[8] <<= 2;  // 0605382E shll2 r8
    c.r[0] = 0x40u;  // 06053830 mov #64,r0
    c.r[0] += c.r[14];  // 06053832 add r14,r0
    c.r[3] = ld32(c.r[1]);  // 06053834 mov.l @r1,r3
    c.r[11] = 0x1Fu;  // 06053836 mov #31,r11
    c.r[0] = ld32(c.r[0]);  // 06053838 mov.l @r0,r0
    c.r[3] += c.r[8];  // 0605383A add r8,r3
    c.r[7] = c.r[3];  // 0605383C mov r3,r7
    c.r[7] += 22;  // 0605383E add #22,r7
    c.r[1] = 0x1Fu;  // 06053840 mov #31,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06053842 mov.b @r7,r6
    c.r[3] += 23;  // 06053844 add #23,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053846 mov.b @r3,r2
    c.r[1] &= c.r[6];  // 06053848 and r6,r1
    c.r[1] <<= 2;  // 0605384A shll2 r1
    c.r[1] += c.r[1];  // 0605384C add r1,r1
    c.r[1] <<= 2;  // 0605384E shll2 r1
    c.r[2] = c.r[2] & 0xFFu;  // 06053850 extu.b r2,r2
    c.r[2] >>= 2;  // 06053852 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06053854 shlr r2
    c.r[2] |= c.r[1];  // 06053856 or r1,r2
    c.r[1] = c.r[5] & 0xFFu;  // 06053858 extu.b r5,r1
    c.r[1] -= c.r[0];  // 0605385A sub r0,r1
    c.r[2] += c.r[1];  // 0605385C add r1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605385E extu.w r2,r2
    c.r[5] = c.r[2];  // 06053860 mov r2,r5
    c.r[5] >>= 2;  // 06053862 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06053864 shlr r5
    c.r[5] >>= 2;  // 06053866 shlr2 r5
    c.r[5] &= c.r[11];  // 06053868 and r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053880u);  // 0605386A mov.w 0x06053880,r1
    c.r[1] &= c.r[6];  // 0605386C and r6,r1
    c.r[1] |= c.r[5];  // 0605386E or r5,r1
    st8(c.r[7], c.r[1]);  // 06053870 mov.b r1,@r7
    c.r[2] &= c.r[11];  // 06053872 and r11,r2
    c.r[2] <<= 2;  // 06053874 shll2 r2
    c.r[2] += c.r[2];  // 06053876 add r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053878 mov.b @r3,r1
    c.r[0] = 0x7u; goto L_060538A8;  // 0605387A bra 0x060538A8 ; mov #7,r0
L_060538A8:
    c.r[1] &= c.r[0];  // 060538A8 and r0,r1
    c.r[1] |= c.r[2];  // 060538AA or r2,r1
    st8(c.r[3], c.r[1]); goto L_06053910;  // 060538AC bra 0x06053910 ; mov.b r1,@r3
L_060538B0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060538B0 mov.b @r13,r1
    c.r[11] = ld32(0x06053944u);  // 060538B2 mov.l 0x06053944,r11
    c.r[2] = ld32(c.r[11]);  // 060538B4 mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060538B6 extu.b r1,r1
    c.r[3] = c.r[1];  // 060538B8 mov r1,r3
    c.r[3] += c.r[3];  // 060538BA add r3,r3
    c.r[3] += c.r[1];  // 060538BC add r1,r3
    c.r[3] <<= 2;  // 060538BE shll2 r3
    c.r[3] += c.r[2];  // 060538C0 add r2,r3
    c.r[3] += 2;  // 060538C2 add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060538C4 mov.b @r3,r2
    c.r[1] = 0x5u;  // 060538C6 mov #5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060538C8 extu.b r2,r2
    c.r[2] -= c.r[12];  // 060538CA sub r12,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060538CC cmp/gt r1,r2
    { const bool k = !c.t; c.r[12] += 5; if (k) { goto L_06053910; } }  // 060538CE bf/s 0x06053910 ; add #5,r12
    st8(c.r[3], c.r[12]);  // 060538D2 mov.b r12,@r3
    c.r[1] = ld32(0x06053948u);  // 060538D4 mov.l 0x06053948,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060538D6 mov.b @r13,r5
    c.r[4] = c.r[14];  // 060538D8 mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060538DEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060538DEu) return; }  // 060538DA jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060538DE mov.b @r13,r1
    c.r[4] = c.r[14];  // 060538E0 mov r14,r4
    c.r[2] = ld32(c.r[11]);  // 060538E2 mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060538E4 extu.b r1,r1
    c.r[3] = c.r[1];  // 060538E6 mov r1,r3
    c.r[3] += c.r[3];  // 060538E8 add r3,r3
    c.r[3] += c.r[1];  // 060538EA add r1,r3
    c.r[3] <<= 2;  // 060538EC shll2 r3
    c.r[3] += c.r[2];  // 060538EE add r2,r3
    c.r[3] += 2;  // 060538F0 add #2,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060538F2 mov.b @r3,r5
    c.r[0] = ld32(0x0605394Cu);  // 060538F4 mov.l 0x0605394C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060538FAu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060538FAu) return; }  // 060538F6 jsr @r0 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060538FA mov.b @r13,r1
    c.r[7] = c.r[0];  // 060538FC mov r0,r7
    c.r[2] = ld32(c.r[11]);  // 060538FE mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06053900 extu.b r1,r1
    c.r[3] = c.r[1];  // 06053902 mov r1,r3
    c.r[3] += c.r[3];  // 06053904 add r3,r3
    c.r[3] += c.r[1];  // 06053906 add r1,r3
    c.r[3] <<= 2;  // 06053908 shll2 r3
    c.r[3] += c.r[2];  // 0605390A add r2,r3
    c.r[3] += 4;  // 0605390C add #4,r3
    st16(c.r[3], c.r[7]);  // 0605390E mov.w r7,@r3
L_06053910:
    c.r[11] = 0x44u;  // 06053910 mov #68,r11
L_06053912:
    c.r[11] += c.r[14];  // 06053912 add r14,r11
L_06053914:
    c.r[0] = ld32(c.r[11]);  // 06053914 mov.l @r11,r0
    c.r[1] = 0x49u;  // 06053916 mov #73,r1
    c.r[0] += 16;  // 06053918 add #16,r0
    st32(c.r[11], c.r[0]);  // 0605391A mov.l r0,@r11
    c.r[11] = ld32(c.r[14] + 56);  // 0605391C mov.l @(56,r14),r11
    c.r[11] += 1;  // 0605391E add #1,r11
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06053920 cmp/gt r1,r11
    { const bool k = c.t; st32(c.r[14] + 56, c.r[11]); if (k) { goto L_0605392A; } }  // 06053922 bt/s 0x0605392A ; mov.l r11,@(56,r14)
    SH2_POLL(c); goto L_060536EE;  // 06053926 bra 0x060536EE ; nop
L_0605392A:
    c.r[0] = ld32(c.r[14] + 60);  // 0605392A mov.l @(60,r14),r0
    c.r[14] += 76;  // 0605392C add #76,r14
    c.r[15] = c.r[14];  // 0605392E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053930 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053932 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06053934 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06053936 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06053938 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605393A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605393C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605393E rts ; mov.l @r15+,r8
}

void f_06053950(SH2Context& c) {
    ran[1311] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053950 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053952 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053954 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053956 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06053958 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605395A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605395C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605395E sts.l pr,@-r15
    c.r[15] -= 48;  // 06053960 add #-48,r15
    c.r[4] = c.r[4] & 0xFFu;  // 06053962 extu.b r4,r4
    c.r[1] = ld32(0x06053A3Cu);  // 06053964 mov.l 0x06053A3C,r1
    c.r[1] = ld32(c.r[1]);  // 06053966 mov.l @r1,r1
    c.r[4] <<= 2;  // 06053968 shll2 r4
    c.r[4] <<= 2;  // 0605396A shll2 r4
    c.r[4] += c.r[1];  // 0605396C add r1,r4
    c.r[4] += 2;  // 0605396E add #2,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06053970 mov.b @r4,r2
    c.r[1] = ld32(0x06053A40u);  // 06053972 mov.l 0x06053A40,r1
    c.r[3] = ld32(c.r[1]);  // 06053974 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06053976 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06053978 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605397A mul.l r1,r2
    c.r[14] = c.r[15];  // 0605397C mov r15,r14
    c.r[0] = ld32(0x06053A44u);  // 0605397E mov.l 0x06053A44,r0
    c.r[1] = c.macl;  // 06053980 sts macl,r1
    c.r[1] += c.r[3];  // 06053982 add r3,r1
    c.r[1] += 15;  // 06053984 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053986 mov.b @r1,r1
    c.r[5] = 0x1u;  // 06053988 mov #1,r5
    c.r[9] = c.r[1] & 0xFFu;  // 0605398A extu.b r1,r9
    { const uint32_t x = c.r[0]; c.pr = 0x06053990u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053990u) return; }  // 0605398C jsr @r0 ; mov r9,r4
    c.r[7] = ld32(0x06053A48u);  // 06053990 mov.l 0x06053A48,r7
    c.r[3] = c.r[9];  // 06053992 mov r9,r3
    c.r[3] += c.r[3];  // 06053994 add r3,r3
    c.r[2] = c.r[3];  // 06053996 mov r3,r2
    c.r[2] += c.r[9];  // 06053998 add r9,r2
    c.r[1] = ld32(c.r[7]);  // 0605399A mov.l @r7,r1
    c.r[2] <<= 2;  // 0605399C shll2 r2
    c.r[2] += c.r[1];  // 0605399E add r1,r2
    c.r[2] += 8;  // 060539A0 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060539A2 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060539A4 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06053A38u);  // 060539A6 mov.w 0x06053A38,r2
    c.t = c.r[1] == c.r[2];  // 060539A8 cmp/eq r2,r1
    { const bool k = c.t; c.r[13] = c.r[0] & 0xFFu; if (k) { goto L_06053A20; } }  // 060539AA bt/s 0x06053A20 ; extu.b r0,r13
    c.r[11] = c.r[7];  // 060539AE mov r7,r11
L_060539B0:
    c.r[3] += c.r[9];  // 060539B0 add r9,r3
    c.r[3] <<= 2;  // 060539B2 shll2 r3
    c.r[2] = ld32(c.r[11]);  // 060539B4 mov.l @r11,r2
    c.r[0] = ld32(0x06053A44u);  // 060539B6 mov.l 0x06053A44,r0
    c.r[3] += c.r[2];  // 060539B8 add r2,r3
    c.r[3] += 8;  // 060539BA add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060539BC mov.b @r3,r1
    c.r[5] = 0x0u;  // 060539BE mov #0,r5
    c.r[9] = c.r[1] & 0xFFu;  // 060539C0 extu.b r1,r9
    c.r[12] = c.r[9];  // 060539C2 mov r9,r12
    c.r[12] += c.r[12];  // 060539C4 add r12,r12
    c.r[8] = c.r[12];  // 060539C6 mov r12,r8
    c.r[8] += c.r[9];  // 060539C8 add r9,r8
    c.r[8] <<= 2;  // 060539CA shll2 r8
    c.r[2] += c.r[8];  // 060539CC add r8,r2
    c.r[2] += 2;  // 060539CE add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060539D0 mov.b @r2,r1
    c.r[4] = c.r[9];  // 060539D2 mov r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060539D8u; c.r[10] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060539D8u) return; }  // 060539D4 jsr @r0 ; extu.b r1,r10
    c.r[3] = ld32(c.r[11]);  // 060539D8 mov.l @r11,r3
    c.r[3] += c.r[8];  // 060539DA add r8,r3
    c.r[3] += 2;  // 060539DC add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060539DE mov.b @r3,r2
    c.r[1] = 0x5u;  // 060539E0 mov #5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060539E2 extu.b r2,r2
    c.r[2] -= c.r[10];  // 060539E4 sub r10,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060539E6 cmp/gt r1,r2
    { const bool k = !c.t; c.r[10] += 5; if (k) { goto L_06053A0E; } }  // 060539E8 bf/s 0x06053A0E ; add #5,r10
    st8(c.r[3], c.r[10]);  // 060539EC mov.b r10,@r3
    c.r[1] = ld32(0x06053A4Cu);  // 060539EE mov.l 0x06053A4C,r1
    c.r[5] = c.r[9];  // 060539F0 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060539F6u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060539F6u) return; }  // 060539F2 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(c.r[11]);  // 060539F6 mov.l @r11,r1
    c.r[0] = ld32(0x06053A50u);  // 060539F8 mov.l 0x06053A50,r0
    c.r[1] += c.r[8];  // 060539FA add r8,r1
    c.r[1] += 2;  // 060539FC add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060539FE mov.b @r1,r5
    c.r[4] = c.r[14];  // 06053A00 mov r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06053A06u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053A06u) return; }  // 06053A02 jsr @r0 ; extu.b r5,r5
    c.r[1] = ld32(c.r[11]);  // 06053A06 mov.l @r11,r1
    c.r[1] += c.r[8];  // 06053A08 add r8,r1
    c.r[1] += 4;  // 06053A0A add #4,r1
    st16(c.r[1], c.r[0]);  // 06053A0C mov.w r0,@r1
L_06053A0E:
    c.r[1] = ld32(c.r[11]);  // 06053A0E mov.l @r11,r1
    c.r[8] += c.r[1];  // 06053A10 add r1,r8
    c.r[8] += 8;  // 06053A12 add #8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06053A14 mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06053A38u);  // 06053A16 mov.w 0x06053A38,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06053A18 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06053A1A cmp/eq r2,r1
    { const bool k = !c.t; c.r[3] = c.r[12]; if (k) { SH2_POLL(c); goto L_060539B0; } }  // 06053A1C bf/s 0x060539B0 ; mov r12,r3
L_06053A20:
    c.r[14] += 48;  // 06053A20 add #48,r14
    c.r[15] = c.r[14];  // 06053A22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053A24 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053A26 mov.l @r15+,r14
    c.r[0] = c.r[13];  // 06053A28 mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06053A2A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06053A2C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06053A2E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053A30 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053A32 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053A34 rts ; mov.l @r15+,r8
}

void f_06053A54(SH2Context& c) {
    ran[1312] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053A54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053A56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053A58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053A5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06053A5C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053A5E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053A60 sts.l pr,@-r15
    c.r[15] -= 48;  // 06053A62 add #-48,r15
    c.r[14] = c.r[15];  // 06053A64 mov r15,r14
    c.r[10] = c.r[4] & 0xFFu;  // 06053A66 extu.b r4,r10
    c.r[11] = c.r[5] & 0xFFu;  // 06053A68 extu.b r5,r11
    c.r[1] = ld32(0x06053B50u);  // 06053A6A mov.l 0x06053B50,r1
    c.r[5] = c.r[10];  // 06053A6C mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06053A72u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053A72u) return; }  // 06053A6E jsr @r1 ; mov r14,r4
    c.r[9] = ld32(0x06053B54u);  // 06053A72 mov.l 0x06053B54,r9
    c.r[8] = c.r[10];  // 06053A74 mov r10,r8
    c.r[8] += c.r[8];  // 06053A76 add r8,r8
    c.r[8] += c.r[10];  // 06053A78 add r10,r8
    c.r[2] = ld32(c.r[9]);  // 06053A7A mov.l @r9,r2
    c.r[8] <<= 2;  // 06053A7C shll2 r8
    c.r[2] += c.r[8];  // 06053A7E add r8,r2
    c.r[1] = c.r[2];  // 06053A80 mov r2,r1
    c.r[1] += 4;  // 06053A82 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06053A84 mov.w @r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 06053A86 cmp/pl r1
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_06053B36; } }  // 06053A88 bt/s 0x06053B36 ; mov #0,r12
    c.r[2] += 2;  // 06053A8C add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053A8E mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06053A90 extu.b r1,r0
    c.t = c.r[0] == 0x63u;  // 06053A92 cmp/eq #99,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06053B38; } }  // 06053A94 bt/s 0x06053B38 ; mov #0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053B4Cu);  // 06053A98 mov.w 0x06053B4C,r1
    c.t = c.r[11] == c.r[1];  // 06053A9A cmp/eq r1,r11
    if (c.t) { goto L_06053AA6; }  // 06053A9C bt 0x06053AA6
    c.r[0] = ld32(0x06053B58u);  // 06053A9E mov.l 0x06053B58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053AA4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053AA4u) return; }  // 06053AA0 jsr @r0 ; mov r11,r4
    c.r[12] = c.r[0] & 0xFFu;  // 06053AA4 extu.b r0,r12
L_06053AA6:
    c.r[1] = ld32(c.r[9]);  // 06053AA6 mov.l @r9,r1
    c.r[1] += c.r[8];  // 06053AA8 add r8,r1
    c.r[1] += 4;  // 06053AAA add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06053AAC mov.w @r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 06053AAE cmp/pl r1
    if (c.t) { goto L_06053AE6; }  // 06053AB0 bt 0x06053AE6
L_06053AB2:
    c.r[2] = ld32(c.r[9]);  // 06053AB2 mov.l @r9,r2
    c.r[2] += c.r[8];  // 06053AB4 add r8,r2
    c.r[2] += 2;  // 06053AB6 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053AB8 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06053ABA extu.b r1,r0
    c.t = c.r[0] == 0x63u;  // 06053ABC cmp/eq #99,r0
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_06053AE6; } }  // 06053ABE bt/s 0x06053AE6 ; add #1,r1
    st8(c.r[2], c.r[1]);  // 06053AC2 mov.b r1,@r2
    c.r[1] = ld32(c.r[9]);  // 06053AC4 mov.l @r9,r1
    c.r[0] = ld32(0x06053B5Cu);  // 06053AC6 mov.l 0x06053B5C,r0
    c.r[1] += c.r[8];  // 06053AC8 add r8,r1
    c.r[1] += 2;  // 06053ACA add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053ACC mov.b @r1,r5
    c.r[4] = c.r[14];  // 06053ACE mov r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06053AD4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053AD4u) return; }  // 06053AD0 jsr @r0 ; extu.b r5,r5
    c.r[2] = ld32(c.r[9]);  // 06053AD4 mov.l @r9,r2
    c.r[2] += c.r[8];  // 06053AD6 add r8,r2
    c.r[2] += 4;  // 06053AD8 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06053ADA mov.w @r2,r1
    c.r[1] += c.r[0];  // 06053ADC add r0,r1
    st16(c.r[2], c.r[1]);  // 06053ADE mov.w r1,@r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06053AE0 exts.w r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 06053AE2 cmp/pl r1
    if (!c.t) { SH2_POLL(c); goto L_06053AB2; }  // 06053AE4 bf 0x06053AB2
L_06053AE6:
    c.r[1] = ld32(0x06053B54u);  // 06053AE6 mov.l 0x06053B54,r1
    c.r[2] = c.r[10];  // 06053AE8 mov r10,r2
    c.r[2] += c.r[2];  // 06053AEA add r2,r2
    c.r[2] += c.r[10];  // 06053AEC add r10,r2
    c.r[1] = ld32(c.r[1]);  // 06053AEE mov.l @r1,r1
    c.r[2] <<= 2;  // 06053AF0 shll2 r2
    c.r[2] += c.r[1];  // 06053AF2 add r1,r2
    c.r[1] = c.r[2];  // 06053AF4 mov r2,r1
    c.r[1] += 2;  // 06053AF6 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053AF8 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06053AFA extu.b r1,r0
    c.t = c.r[0] == 0x63u;  // 06053AFC cmp/eq #99,r0
    { const bool k = !c.t; c.r[2] += 4; if (k) { goto L_06053B06; } }  // 06053AFE bf/s 0x06053B06 ; add #4,r2
    c.r[1] = 0x0u;  // 06053B02 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06053B04 mov.w r1,@r2
L_06053B06:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053B4Cu);  // 06053B06 mov.w 0x06053B4C,r1
    c.t = c.r[11] == c.r[1];  // 06053B08 cmp/eq r1,r11
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06053B38; } }  // 06053B0A bt/s 0x06053B38 ; mov #1,r0
    c.t = (c.r[12] & c.r[12]) == 0;  // 06053B0E tst r12,r12
    if (!c.t) { goto L_06053B38; }  // 06053B10 bf 0x06053B38
    c.r[0] = ld32(0x06053B58u);  // 06053B12 mov.l 0x06053B58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053B18u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053B18u) return; }  // 06053B14 jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0] & 0xFFu;  // 06053B18 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06053B1A tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_06053B32; } }  // 06053B1C bt/s 0x06053B32 ; mov r11,r2
    c.r[1] = ld32(0x06053B60u);  // 06053B20 mov.l 0x06053B60,r1
    c.r[1] = ld32(c.r[1]);  // 06053B22 mov.l @r1,r1
    c.r[2] <<= 2;  // 06053B24 shll2 r2
    c.r[2] <<= 2;  // 06053B26 shll2 r2
    c.r[2] += c.r[1];  // 06053B28 add r1,r2
    c.r[2] += 7;  // 06053B2A add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053B2C mov.b @r2,r0
    c.r[0] &= 0xEFu;  // 06053B2E and #239,r0
    st8(c.r[2], c.r[0]);  // 06053B30 mov.b r0,@r2
L_06053B32:
    c.r[0] = 0x1u; goto L_06053B38;  // 06053B32 bra 0x06053B38 ; mov #1,r0
L_06053B36:
    c.r[0] = 0x0u;  // 06053B36 mov #0,r0
L_06053B38:
    c.r[14] += 48;  // 06053B38 add #48,r14
    c.r[15] = c.r[14];  // 06053B3A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053B3C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053B3E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06053B40 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06053B42 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053B44 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053B46 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053B48 rts ; mov.l @r15+,r8
}

void f_06053B64(SH2Context& c) {
    ran[1313] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053B64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053B66 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053B68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053B6A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053BE0u);  // 06053B6C mov.w 0x06053BE0,r3
    c.r[15] += c.r[3];  // 06053B6E add r3,r15
    c.r[14] = c.r[15];  // 06053B70 mov r15,r14
    c.r[8] = c.r[4];  // 06053B72 mov r4,r8
    c.r[8] = c.r[8] & 0xFFu;  // 06053B74 extu.b r8,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x06053BE2u);  // 06053B76 mov.w 0x06053BE2,r6
    c.r[9] = ld32(0x06053BECu);  // 06053B78 mov.l 0x06053BEC,r9
    c.r[1] = ld32(c.r[9]);  // 06053B7A mov.l @r9,r1
    c.r[8] <<= 2;  // 06053B7C shll2 r8
    c.r[8] <<= 2;  // 06053B7E shll2 r8
    c.r[1] += c.r[8];  // 06053B80 add r8,r1
    c.r[1] += 2;  // 06053B82 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053B84 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06053B86 mov r14,r4
    c.r[1] = ld32(0x06053BF0u);  // 06053B88 mov.l 0x06053BF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053B8Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053B8Eu) return; }  // 06053B8A jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[9]);  // 06053B8E mov.l @r9,r1
    c.r[8] += c.r[1];  // 06053B90 add r1,r8
    c.r[8] += 2;  // 06053B92 add #2,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06053B94 mov.b @r8,r2
    c.r[1] = ld32(0x06053BF4u);  // 06053B96 mov.l 0x06053BF4,r1
    c.r[3] = ld32(c.r[1]);  // 06053B98 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06053B9A extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06053B9C mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06053B9E mul.l r1,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x06053BE4u);  // 06053BA0 mov.w 0x06053BE4,r8
    c.r[8] += c.r[14];  // 06053BA2 add r14,r8
    c.r[1] = c.macl;  // 06053BA4 sts macl,r1
    c.r[1] += c.r[3];  // 06053BA6 add r3,r1
    c.r[1] += 15;  // 06053BA8 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053BAA mov.b @r1,r5
    c.r[4] = c.r[8];  // 06053BAC mov r8,r4
    c.r[1] = ld32(0x06053BF8u);  // 06053BAE mov.l 0x06053BF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053BB4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053BB4u) return; }  // 06053BB0 jsr @r1 ; extu.b r5,r5
    c.r[8] += 22;  // 06053BB4 add #22,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06053BB6 mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06053BE6u);  // 06053BB8 mov.w 0x06053BE6,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06053BBA extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06053BBC cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06053BCE; } }  // 06053BBE bf/s 0x06053BCE ; mov r14,r1
    c.r[1] += 32;  // 06053BC2 add #32,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06053BC4 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06053BC6 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06053BC8 cmp/hi r2,r1
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06053BD0; } }  // 06053BCA bt/s 0x06053BD0 ; mov #1,r0
L_06053BCE:
    c.r[0] = 0x0u;  // 06053BCE mov #0,r0
L_06053BD0:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053BE8u);  // 06053BD0 mov.w 0x06053BE8,r3
    c.r[14] += c.r[3];  // 06053BD2 add r3,r14
    c.r[15] = c.r[14];  // 06053BD4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053BD6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053BD8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053BDA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053BDC rts ; mov.l @r15+,r8
}

void f_06053C00(SH2Context& c) {
    ran[1314] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053C00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053C02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053C04 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053C06 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053C08 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06053C0A mov r15,r14
    c.r[10] = c.r[4];  // 06053C0C mov r4,r10
    c.r[8] = c.r[5];  // 06053C0E mov r5,r8
    c.r[8] = c.r[8] & 0xFFu;  // 06053C10 extu.b r8,r8
    c.r[4] = ld32(0x06053C84u);  // 06053C12 mov.l 0x06053C84,r4
    c.r[9] = ld32(0x06053C88u);  // 06053C14 mov.l 0x06053C88,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06053C1Au; c.r[5] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053C1Au) return; }  // 06053C16 jsr @r9 ; mov #30,r5
    c.r[5] = 0x0u;  // 06053C1A mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06053C20u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053C20u) return; }  // 06053C1C jsr @r9 ; mov r0,r4
    c.r[8] += c.r[8];  // 06053C20 add r8,r8
    c.r[2] = c.r[0];  // 06053C22 mov r0,r2
    c.r[2] += c.r[8];  // 06053C24 add r8,r2
    c.r[2] += 1;  // 06053C26 add #1,r2
    c.r[7] = c.r[10];  // 06053C28 mov r10,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06053C2A mov.b @(r0,r8),r1
    c.r[7] += 30;  // 06053C2C add #30,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06053C2E extu.b r1,r1
    c.r[3] = c.r[1];  // 06053C30 mov r1,r3
    c.r[3] <<= 8;  // 06053C32 shll8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053C34 mov.b @r2,r1
    c.r[6] = 0x4u;  // 06053C36 mov #4,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06053C38 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06053C3A or r1,r3
    c.r[2] = 0x0u;  // 06053C3C mov #0,r2
    c.r[0] = c.r[7];  // 06053C3E mov r7,r0
L_06053C40:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06053C40 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06053C42 extu.b r1,r1
    c.r[0] = c.r[1];  // 06053C44 mov r1,r0
    c.t = c.r[0] == 0x51u;  // 06053C46 cmp/eq #81,r0
    if (c.t) { goto L_06053C52; }  // 06053C48 bt 0x06053C52
    c.r[2] += 1;  // 06053C4A add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 06053C4C cmp/ge r6,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_06053C40; } }  // 06053C4E bf/s 0x06053C40 ; mov r7,r0
L_06053C52:
    c.r[0] = c.r[2];  // 06053C52 mov r2,r0
    c.t = c.r[0] == 0x4u;  // 06053C54 cmp/eq #4,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06053C5C; } }  // 06053C56 bt/s 0x06053C5C ; mov #-1,r1
    c.r[1] = c.r[2];  // 06053C5A mov r2,r1
L_06053C5C:
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06053C5C exts.b r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06053C5E cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06053C76; } }  // 06053C60 bt/s 0x06053C76 ; mov r14,r15
    c.r[1] = ld32(0x06053C8Cu);  // 06053C64 mov.l 0x06053C8C,r1
    c.r[1] = ld32(c.r[1]);  // 06053C66 mov.l @r1,r1
    { uint64_t p = (uint64_t)c.r[3] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06053C68 dmulu.l r1,r3
    c.r[1] = c.mach;  // 06053C6A sts mach,r1
    c.r[1] >>= 2;  // 06053C6C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06053C6E shlr r1
    c.r[3] -= c.r[1];  // 06053C70 sub r1,r3
    c.r[1] = c.r[3];  // 06053C72 mov r3,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06053C74 extu.w r1,r3
L_06053C76:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053C76 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053C78 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053C7A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053C7C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06053C7E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06053C80 rts ; mov r3,r0
}

void f_06053C90(SH2Context& c) {
    ran[1315] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 06053C90 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 06053C92 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053C94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053C96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053C98 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053C9A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053C9C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053C9E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06053CA0 mov r15,r14
    c.r[10] = c.r[6];  // 06053CA2 mov r6,r10
    c.r[4] = c.r[4] & 0xFFu;  // 06053CA4 extu.b r4,r4
    c.r[11] = c.r[7] & 0xFFu;  // 06053CA6 extu.b r7,r11
    c.r[3] = c.r[10];  // 06053CA8 mov r10,r3
    c.r[3] += 2;  // 06053CAA add #2,r3
    c.r[2] = c.r[4];  // 06053CAC mov r4,r2
    c.r[2] += c.r[2];  // 06053CAE add r2,r2
    c.r[1] = ld32(c.r[14] + 24);  // 06053CB0 mov.l @(24,r14),r1
    c.r[2] += c.r[4];  // 06053CB2 add r4,r2
    c.r[9] = c.r[1] & 0xFFu;  // 06053CB4 extu.b r1,r9
    c.r[1] = ld32(0x06053DB4u);  // 06053CB6 mov.l 0x06053DB4,r1
    c.r[1] = ld32(c.r[1]);  // 06053CB8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06053CBA shll2 r2
    c.r[2] += c.r[1];  // 06053CBC add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053CBE mov.b @r3,r1
    c.r[2] += 2;  // 06053CC0 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053CC2 mov.b @r2,r2
    c.r[1] -= c.r[2];  // 06053CC4 sub r2,r1
    c.r[7] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06053CC6 exts.b r1,r7
    c.r[1] = 0xFFFFFFFAu;  // 06053CC8 mov #-6,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06053CCA cmp/ge r1,r7
    { const bool k = c.t; c.r[6] = c.r[9]; if (k) { goto L_06053CD2; } }  // 06053CCC bt/s 0x06053CD2 ; mov r9,r6
    c.r[7] = c.r[1];  // 06053CD0 mov r1,r7
L_06053CD2:
    c.r[1] = 0x8u;  // 06053CD2 mov #8,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06053CD4 cmp/gt r1,r7
    if (!c.t) { goto L_06053CDA; }  // 06053CD6 bf 0x06053CDA
    c.r[7] = c.r[1];  // 06053CD8 mov r1,r7
L_06053CDA:
    c.r[1] = c.r[7];  // 06053CDA mov r7,r1
    c.r[1] += 6;  // 06053CDC add #6,r1
    c.r[7] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06053CDE exts.b r1,r7
    c.r[1] = 0x3Fu;  // 06053CE0 mov #63,r1
    c.t = c.r[9] > c.r[1];  // 06053CE2 cmp/hi r1,r9
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_06053D4C; } }  // 06053CE4 bt/s 0x06053D4C ; mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053DACu);  // 06053CE8 mov.w 0x06053DAC,r1
    c.r[2] = ld32(0x06053DB8u);  // 06053CEA mov.l 0x06053DB8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053CEC mov.b @(r0,r1),r1
    c.r[10] += 44;  // 06053CEE add #44,r10
    c.r[0] = c.r[2];  // 06053CF0 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06053CF2 mov.b @(r0,r7),r6
    c.r[1] = c.r[1] & 0xFFu;  // 06053CF4 extu.b r1,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06053CF6 extu.b r6,r6
    c.r[7] += c.r[2];  // 06053CF8 add r2,r7
    c.r[7] += 15;  // 06053CFA add #15,r7
    c.r[0] = ld32(0x06053DBCu);  // 06053CFC mov.l 0x06053DBC,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06053CFE mov.b @r7,r7
    c.macl = c.r[1] * c.r[6];  // 06053D00 mul.l r6,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06053D02 extu.b r7,r7
    c.r[5] = c.r[7];  // 06053D04 mov r7,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06053D0Au; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053D0Au) return; }  // 06053D06 jsr @r0 ; sts macl,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06053D0A mov.b @r10,r1
    c.r[8] = c.r[0];  // 06053D0C mov r0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06053D0E extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 06053D10 mul.l r6,r1
    c.r[0] = ld32(0x06053DBCu);  // 06053D12 mov.l 0x06053DBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053D18u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053D18u) return; }  // 06053D14 jsr @r0 ; sts macl,r4
    c.r[7] = c.r[0];  // 06053D18 mov r0,r7
    c.t = (c.r[9] & c.r[9]) == 0;  // 06053D1A tst r9,r9
    { const bool k = !c.t; c.r[8] += c.r[7]; if (k) { goto L_06053D2C; } }  // 06053D1C bf/s 0x06053D2C ; add r7,r8
    c.r[1] = ld32(0x06053DC0u);  // 06053D20 mov.l 0x06053DC0,r1
    c.r[1] = ld32(c.r[1]);  // 06053D22 mov.l @r1,r1
    { uint64_t p = (uint64_t)c.r[8] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06053D24 dmulu.l r1,r8
    c.r[8] = c.mach;  // 06053D26 sts mach,r8
    c.r[8] >>= 2;  // 06053D28 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06053D2A shlr r8
L_06053D2C:
    c.r[1] = ld32(0x06053DC4u);  // 06053D2C mov.l 0x06053DC4,r1
    c.r[1] = ld32(c.r[1]);  // 06053D2E mov.l @r1,r1
    c.r[11] <<= 2;  // 06053D30 shll2 r11
    c.r[11] <<= 2;  // 06053D32 shll2 r11
    c.r[11] += c.r[1];  // 06053D34 add r1,r11
    c.r[11] += 11;  // 06053D36 add #11,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06053D38 mov.b @r11,r1
    c.r[0] = c.r[1];  // 06053D3A mov r1,r0
    c.r[0] >>= 2;  // 06053D3C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06053D3E shlr r0
    c.r[0] &= 0x1u;  // 06053D40 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053D42 tst r0,r0
    if (c.t) { goto L_06053D8C; }  // 06053D44 bt 0x06053D8C
    c.r[8] += c.r[8];  // 06053D46 add r8,r8
    c.t = (c.r[8] & c.r[8]) == 0; goto L_06053D8E;  // 06053D48 bra 0x06053D8E ; tst r8,r8
L_06053D4C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053DAEu);  // 06053D4C mov.w 0x06053DAE,r0
    c.r[6] &= c.r[0];  // 06053D4E and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06053D50 tst r6,r6
    if (c.t) { goto L_06053D70; }  // 06053D52 bt 0x06053D70
    c.r[1] = ld32(0x06053DC8u);  // 06053D54 mov.l 0x06053DC8,r1
    c.r[3] = ld32(c.r[1]);  // 06053D56 mov.l @r1,r3
    c.r[1] = ld32(0x06053DCCu);  // 06053D58 mov.l 0x06053DCC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06053D5A dmuls.l r1,r3
    c.r[2] = c.mach;  // 06053D5C sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06053D5E shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06053D60 shar r2
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 06053D62 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06053D64 subc r3,r3
    c.r[2] -= c.r[3];  // 06053D66 sub r3,r2
    c.r[3] = ld32(0x06053DB8u);  // 06053D68 mov.l 0x06053DB8,r3
    c.r[0] = c.r[3];  // 06053D6A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]); goto L_06053D78;  // 06053D6C bra 0x06053D78 ; mov.b @(r0,r7),r1
L_06053D70:
    c.r[3] = ld32(0x06053DB8u);  // 06053D70 mov.l 0x06053DB8,r3
    c.r[0] = c.r[3];  // 06053D72 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06053D74 mov.b @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06053DB0u);  // 06053D76 mov.w 0x06053DB0,r2
L_06053D78:
    c.r[1] = c.r[1] & 0xFFu;  // 06053D78 extu.b r1,r1
    c.r[7] += c.r[3];  // 06053D7A add r3,r7
    c.r[7] += 15;  // 06053D7C add #15,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06053D7E mov.b @r7,r5
    c.macl = c.r[1] * c.r[2];  // 06053D80 mul.l r2,r1
    c.r[5] = c.r[5] & 0xFFu;  // 06053D82 extu.b r5,r5
    c.r[7] = ld32(0x06053DBCu);  // 06053D84 mov.l 0x06053DBC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06053D8Au; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053D8Au) return; }  // 06053D86 jsr @r7 ; sts macl,r4
    c.r[8] = c.r[0];  // 06053D8A mov r0,r8
L_06053D8C:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06053D8C tst r8,r8
L_06053D8E:
    if (!c.t) { goto L_06053D92; }  // 06053D8E bf 0x06053D92
    c.r[8] = 0x1u;  // 06053D90 mov #1,r8
L_06053D92:
    c.r[1] = ld32(0x06053DD0u);  // 06053D92 mov.l 0x06053DD0,r1
    c.t = c.r[8] > c.r[1];  // 06053D94 cmp/hi r1,r8
    if (!c.t) { goto L_06053D9A; }  // 06053D96 bf 0x06053D9A
    c.r[8] = c.r[1];  // 06053D98 mov r1,r8
L_06053D9A:
    c.r[15] = c.r[14];  // 06053D9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053D9C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053D9E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06053DA0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053DA2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053DA4 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06053DA6 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053DA8 rts ; mov.l @r15+,r8
}

void f_06053C94(SH2Context& c) {
    ran[1316] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053C94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053C96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053C98 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053C9A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053C9C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053C9E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06053CA0 mov r15,r14
    c.r[10] = c.r[6];  // 06053CA2 mov r6,r10
    c.r[4] = c.r[4] & 0xFFu;  // 06053CA4 extu.b r4,r4
    c.r[11] = c.r[7] & 0xFFu;  // 06053CA6 extu.b r7,r11
    c.r[3] = c.r[10];  // 06053CA8 mov r10,r3
    c.r[3] += 2;  // 06053CAA add #2,r3
    c.r[2] = c.r[4];  // 06053CAC mov r4,r2
    c.r[2] += c.r[2];  // 06053CAE add r2,r2
    c.r[1] = ld32(c.r[14] + 24);  // 06053CB0 mov.l @(24,r14),r1
    c.r[2] += c.r[4];  // 06053CB2 add r4,r2
    c.r[9] = c.r[1] & 0xFFu;  // 06053CB4 extu.b r1,r9
    c.r[1] = ld32(0x06053DB4u);  // 06053CB6 mov.l 0x06053DB4,r1
    c.r[1] = ld32(c.r[1]);  // 06053CB8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06053CBA shll2 r2
    c.r[2] += c.r[1];  // 06053CBC add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053CBE mov.b @r3,r1
    c.r[2] += 2;  // 06053CC0 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053CC2 mov.b @r2,r2
    c.r[1] -= c.r[2];  // 06053CC4 sub r2,r1
    c.r[7] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06053CC6 exts.b r1,r7
    c.r[1] = 0xFFFFFFFAu;  // 06053CC8 mov #-6,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06053CCA cmp/ge r1,r7
    { const bool k = c.t; c.r[6] = c.r[9]; if (k) { goto L_06053CD2; } }  // 06053CCC bt/s 0x06053CD2 ; mov r9,r6
    c.r[7] = c.r[1];  // 06053CD0 mov r1,r7
L_06053CD2:
    c.r[1] = 0x8u;  // 06053CD2 mov #8,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06053CD4 cmp/gt r1,r7
    if (!c.t) { goto L_06053CDA; }  // 06053CD6 bf 0x06053CDA
    c.r[7] = c.r[1];  // 06053CD8 mov r1,r7
L_06053CDA:
    c.r[1] = c.r[7];  // 06053CDA mov r7,r1
    c.r[1] += 6;  // 06053CDC add #6,r1
    c.r[7] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06053CDE exts.b r1,r7
    c.r[1] = 0x3Fu;  // 06053CE0 mov #63,r1
    c.t = c.r[9] > c.r[1];  // 06053CE2 cmp/hi r1,r9
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_06053D4C; } }  // 06053CE4 bt/s 0x06053D4C ; mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053DACu);  // 06053CE8 mov.w 0x06053DAC,r1
    c.r[2] = ld32(0x06053DB8u);  // 06053CEA mov.l 0x06053DB8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053CEC mov.b @(r0,r1),r1
    c.r[10] += 44;  // 06053CEE add #44,r10
    c.r[0] = c.r[2];  // 06053CF0 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06053CF2 mov.b @(r0,r7),r6
    c.r[1] = c.r[1] & 0xFFu;  // 06053CF4 extu.b r1,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06053CF6 extu.b r6,r6
    c.r[7] += c.r[2];  // 06053CF8 add r2,r7
    c.r[7] += 15;  // 06053CFA add #15,r7
    c.r[0] = ld32(0x06053DBCu);  // 06053CFC mov.l 0x06053DBC,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06053CFE mov.b @r7,r7
    c.macl = c.r[1] * c.r[6];  // 06053D00 mul.l r6,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06053D02 extu.b r7,r7
    c.r[5] = c.r[7];  // 06053D04 mov r7,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06053D0Au; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053D0Au) return; }  // 06053D06 jsr @r0 ; sts macl,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06053D0A mov.b @r10,r1
    c.r[8] = c.r[0];  // 06053D0C mov r0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06053D0E extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 06053D10 mul.l r6,r1
    c.r[0] = ld32(0x06053DBCu);  // 06053D12 mov.l 0x06053DBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06053D18u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053D18u) return; }  // 06053D14 jsr @r0 ; sts macl,r4
    c.r[7] = c.r[0];  // 06053D18 mov r0,r7
    c.t = (c.r[9] & c.r[9]) == 0;  // 06053D1A tst r9,r9
    { const bool k = !c.t; c.r[8] += c.r[7]; if (k) { goto L_06053D2C; } }  // 06053D1C bf/s 0x06053D2C ; add r7,r8
    c.r[1] = ld32(0x06053DC0u);  // 06053D20 mov.l 0x06053DC0,r1
    c.r[1] = ld32(c.r[1]);  // 06053D22 mov.l @r1,r1
    { uint64_t p = (uint64_t)c.r[8] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06053D24 dmulu.l r1,r8
    c.r[8] = c.mach;  // 06053D26 sts mach,r8
    c.r[8] >>= 2;  // 06053D28 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06053D2A shlr r8
L_06053D2C:
    c.r[1] = ld32(0x06053DC4u);  // 06053D2C mov.l 0x06053DC4,r1
    c.r[1] = ld32(c.r[1]);  // 06053D2E mov.l @r1,r1
    c.r[11] <<= 2;  // 06053D30 shll2 r11
    c.r[11] <<= 2;  // 06053D32 shll2 r11
    c.r[11] += c.r[1];  // 06053D34 add r1,r11
    c.r[11] += 11;  // 06053D36 add #11,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06053D38 mov.b @r11,r1
    c.r[0] = c.r[1];  // 06053D3A mov r1,r0
    c.r[0] >>= 2;  // 06053D3C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06053D3E shlr r0
    c.r[0] &= 0x1u;  // 06053D40 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053D42 tst r0,r0
    if (c.t) { goto L_06053D8C; }  // 06053D44 bt 0x06053D8C
    c.r[8] += c.r[8];  // 06053D46 add r8,r8
    c.t = (c.r[8] & c.r[8]) == 0; goto L_06053D8E;  // 06053D48 bra 0x06053D8E ; tst r8,r8
L_06053D4C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053DAEu);  // 06053D4C mov.w 0x06053DAE,r0
    c.r[6] &= c.r[0];  // 06053D4E and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06053D50 tst r6,r6
    if (c.t) { goto L_06053D70; }  // 06053D52 bt 0x06053D70
    c.r[1] = ld32(0x06053DC8u);  // 06053D54 mov.l 0x06053DC8,r1
    c.r[3] = ld32(c.r[1]);  // 06053D56 mov.l @r1,r3
    c.r[1] = ld32(0x06053DCCu);  // 06053D58 mov.l 0x06053DCC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06053D5A dmuls.l r1,r3
    c.r[2] = c.mach;  // 06053D5C sts mach,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06053D5E shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06053D60 shar r2
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 06053D62 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06053D64 subc r3,r3
    c.r[2] -= c.r[3];  // 06053D66 sub r3,r2
    c.r[3] = ld32(0x06053DB8u);  // 06053D68 mov.l 0x06053DB8,r3
    c.r[0] = c.r[3];  // 06053D6A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]); goto L_06053D78;  // 06053D6C bra 0x06053D78 ; mov.b @(r0,r7),r1
L_06053D70:
    c.r[3] = ld32(0x06053DB8u);  // 06053D70 mov.l 0x06053DB8,r3
    c.r[0] = c.r[3];  // 06053D72 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06053D74 mov.b @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06053DB0u);  // 06053D76 mov.w 0x06053DB0,r2
L_06053D78:
    c.r[1] = c.r[1] & 0xFFu;  // 06053D78 extu.b r1,r1
    c.r[7] += c.r[3];  // 06053D7A add r3,r7
    c.r[7] += 15;  // 06053D7C add #15,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06053D7E mov.b @r7,r5
    c.macl = c.r[1] * c.r[2];  // 06053D80 mul.l r2,r1
    c.r[5] = c.r[5] & 0xFFu;  // 06053D82 extu.b r5,r5
    c.r[7] = ld32(0x06053DBCu);  // 06053D84 mov.l 0x06053DBC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06053D8Au; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053D8Au) return; }  // 06053D86 jsr @r7 ; sts macl,r4
    c.r[8] = c.r[0];  // 06053D8A mov r0,r8
L_06053D8C:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06053D8C tst r8,r8
L_06053D8E:
    if (!c.t) { goto L_06053D92; }  // 06053D8E bf 0x06053D92
    c.r[8] = 0x1u;  // 06053D90 mov #1,r8
L_06053D92:
    c.r[1] = ld32(0x06053DD0u);  // 06053D92 mov.l 0x06053DD0,r1
    c.t = c.r[8] > c.r[1];  // 06053D94 cmp/hi r1,r8
    if (!c.t) { goto L_06053D9A; }  // 06053D96 bf 0x06053D9A
    c.r[8] = c.r[1];  // 06053D98 mov r1,r8
L_06053D9A:
    c.r[15] = c.r[14];  // 06053D9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053D9C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053D9E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06053DA0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053DA2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053DA4 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06053DA6 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053DA8 rts ; mov.l @r15+,r8
}

void f_06053DD4(SH2Context& c) {
    ran[1317] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053DD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053DD6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053DD8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053DDA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053E9Cu);  // 06053DDC mov.w 0x06053E9C,r3
    c.r[15] += c.r[3];  // 06053DDE add r3,r15
    c.r[14] = c.r[15];  // 06053DE0 mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06053DE2 extu.b r4,r9
    c.r[5] = c.r[5] & 0xFFu;  // 06053DE4 extu.b r5,r5
    c.r[6] = c.r[6] & 0xFFu;  // 06053DE6 extu.b r6,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06053DE8 tst r6,r6
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_06053E8A; } }  // 06053DEA bt/s 0x06053E8A ; mov #0,r4
    c.r[1] = 0x3Fu;  // 06053DEE mov #63,r1
    c.t = c.r[6] > c.r[1];  // 06053DF0 cmp/hi r1,r6
    { const bool k = c.t; c.r[5] <<= 2; if (k) { goto L_06053E8A; } }  // 06053DF2 bt/s 0x06053E8A ; shll2 r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06053E9Eu);  // 06053DF6 mov.w 0x06053E9E,r6
    c.r[8] = ld32(0x06053EA8u);  // 06053DF8 mov.l 0x06053EA8,r8
    c.r[5] <<= 2;  // 06053DFA shll2 r5
    c.r[1] = ld32(c.r[8]);  // 06053DFC mov.l @r8,r1
    c.r[4] = c.r[14];  // 06053DFE mov r14,r4
    c.r[5] += c.r[1];  // 06053E00 add r1,r5
    c.r[5] += 2;  // 06053E02 add #2,r5
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06053E04 mov.b @r5,r5
    c.r[1] = ld32(0x06053EACu);  // 06053E06 mov.l 0x06053EAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053E0Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053E0Cu) return; }  // 06053E08 jsr @r1 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053EA0u);  // 06053E0C mov.w 0x06053EA0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06053E0E mov.w @(r0,r14),r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06053E10 extu.w r1,r4
    c.r[1] = ld32(c.r[8]);  // 06053E12 mov.l @r8,r1
    c.r[9] <<= 2;  // 06053E14 shll2 r9
    c.r[9] <<= 2;  // 06053E16 shll2 r9
    c.r[9] += c.r[1];  // 06053E18 add r1,r9
    c.r[9] += 10;  // 06053E1A add #10,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06053E1C mov.b @r9,r1
    c.r[0] = c.r[1];  // 06053E1E mov r1,r0
    c.r[0] >>= 2;  // 06053E20 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06053E22 shlr r0
    c.r[0] >>= 2;  // 06053E24 shlr2 r0
    c.r[0] &= 0x1u;  // 06053E26 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06053E28 tst r0,r0
    if (c.t) { goto L_06053E2E; }  // 06053E2A bt 0x06053E2E
    c.r[4] += c.r[4];  // 06053E2C add r4,r4
L_06053E2E:
    c.r[0] = ld32(0x06053EB0u);  // 06053E2E mov.l 0x06053EB0,r0
    c.t = c.r[4] > c.r[0];  // 06053E30 cmp/hi r0,r4
    if (!c.t) { goto L_06053E36; }  // 06053E32 bf 0x06053E36
    c.r[4] = c.r[0];  // 06053E34 mov r0,r4
L_06053E36:
    c.r[6] = ld32(0x06053EB4u);  // 06053E36 mov.l 0x06053EB4,r6
    c.r[3] = ld32(c.r[6]);  // 06053E38 mov.l @r6,r3
    c.r[7] = c.r[3];  // 06053E3A mov r3,r7
    c.r[7] += 10;  // 06053E3C add #10,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06053E3E mov.w @r7,r1
    c.r[3] += 12;  // 06053E40 add #12,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053E42 mov.b @r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06053E44 extu.w r1,r1
    c.r[1] <<= 8;  // 06053E46 shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 06053E48 extu.b r2,r2
    c.r[2] |= c.r[1];  // 06053E4A or r1,r2
    c.r[2] += c.r[4];  // 06053E4C add r4,r2
    c.r[1] = c.r[2];  // 06053E4E mov r2,r1
    c.r[1] >>= 8;  // 06053E50 shlr8 r1
    st16(c.r[7], c.r[1]);  // 06053E52 mov.w r1,@r7
    st8(c.r[3], c.r[2]);  // 06053E54 mov.b r2,@r3
    c.r[1] = ld32(c.r[6]);  // 06053E56 mov.l @r6,r1
    c.r[7] = c.r[1];  // 06053E58 mov r1,r7
    c.r[7] += 10;  // 06053E5A add #10,r7
    c.r[3] = c.r[1];  // 06053E5C mov r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06053E5E mov.w @r7,r2
    c.r[3] += 12;  // 06053E60 add #12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06053E62 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06053E64 extu.w r2,r2
    c.r[2] <<= 8;  // 06053E66 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06053E68 extu.b r1,r1
    c.r[1] |= c.r[2];  // 06053E6A or r2,r1
    c.r[2] = ld32(0x06053EB8u);  // 06053E6C mov.l 0x06053EB8,r2
    c.t = c.r[1] > c.r[2];  // 06053E6E cmp/hi r2,r1
    if (!c.t) { goto L_06053E7A; }  // 06053E70 bf 0x06053E7A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053EA2u);  // 06053E72 mov.w 0x06053EA2,r1
    st16(c.r[7], c.r[1]);  // 06053E74 mov.w r1,@r7
    c.r[1] = 0x7Fu;  // 06053E76 mov #127,r1
    st8(c.r[3], c.r[1]);  // 06053E78 mov.b r1,@r3
L_06053E7A:
    c.r[3] = ld32(c.r[6]);  // 06053E7A mov.l @r6,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053EA4u);  // 06053E7C mov.w 0x06053EA4,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06053E7E mov.l @(r0,r3),r1
    c.r[1] += c.r[4];  // 06053E80 add r4,r1
    c.t = c.r[1] > c.r[2];  // 06053E82 cmp/hi r2,r1
    { const bool k = !c.t; st32(c.r[0] + c.r[3], c.r[1]); if (k) { goto L_06053E8A; } }  // 06053E84 bf/s 0x06053E8A ; mov.l r1,@(r0,r3)
    st32(c.r[0] + c.r[3], c.r[2]);  // 06053E88 mov.l r2,@(r0,r3)
L_06053E8A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053EA6u);  // 06053E8A mov.w 0x06053EA6,r3
    c.r[14] += c.r[3];  // 06053E8C add r3,r14
    c.r[15] = c.r[14];  // 06053E8E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053E90 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053E92 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053E94 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06053E96 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 06053E98 rts ; mov r4,r0
}

void f_06053EBC(SH2Context& c) {
    ran[1318] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053EBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053EBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053EC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053EC2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06053EC4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06053EC6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053EC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053ECA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053FBCu);  // 06053ECC mov.w 0x06053FBC,r3
    c.r[15] += c.r[3];  // 06053ECE add r3,r15
    c.r[14] = c.r[15];  // 06053ED0 mov r15,r14
    c.r[8] = c.r[5];  // 06053ED2 mov r5,r8
    c.r[11] = c.r[4] & 0xFFu;  // 06053ED4 extu.b r4,r11
    c.r[8] = c.r[8] & 0xFFu;  // 06053ED6 extu.b r8,r8
    c.r[12] = c.r[6] & 0xFFu;  // 06053ED8 extu.b r6,r12
    c.r[6] = (uint32_t)(int16_t)ld16(0x06053FBEu);  // 06053EDA mov.w 0x06053FBE,r6
    c.r[9] = ld32(0x06053FCCu);  // 06053EDC mov.l 0x06053FCC,r9
    c.r[1] = ld32(c.r[9]);  // 06053EDE mov.l @r9,r1
    c.r[8] <<= 2;  // 06053EE0 shll2 r8
    c.r[8] <<= 2;  // 06053EE2 shll2 r8
    c.r[1] += c.r[8];  // 06053EE4 add r8,r1
    c.r[1] += 2;  // 06053EE6 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053EE8 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06053EEA mov r14,r4
    c.r[1] = ld32(0x06053FD0u);  // 06053EEC mov.l 0x06053FD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053EF2u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053EF2u) return; }  // 06053EEE jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[9]);  // 06053EF2 mov.l @r9,r1
    c.r[8] += c.r[1];  // 06053EF4 add r1,r8
    c.r[8] += 2;  // 06053EF6 add #2,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06053EF8 mov.b @r8,r2
    c.r[1] = ld32(0x06053FD4u);  // 06053EFA mov.l 0x06053FD4,r1
    c.r[3] = ld32(c.r[1]);  // 06053EFC mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06053EFE extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06053F00 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06053F02 mul.l r1,r2
    c.r[10] = 0x0u;  // 06053F04 mov #0,r10
    c.r[4] = (uint32_t)(int16_t)ld16(0x06053FC0u);  // 06053F06 mov.w 0x06053FC0,r4
    c.r[1] = c.macl;  // 06053F08 sts macl,r1
    c.r[1] += c.r[3];  // 06053F0A add r3,r1
    c.r[1] += 15;  // 06053F0C add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053F0E mov.b @r1,r5
    c.r[4] += c.r[14];  // 06053F10 add r14,r4
    c.r[1] = ld32(0x06053FD8u);  // 06053F12 mov.l 0x06053FD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053F18u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053F18u) return; }  // 06053F14 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06053FDCu);  // 06053F18 mov.l 0x06053FDC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06053F1Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053F1Eu) return; }  // 06053F1A jsr @r1 ; mov r11,r4
    c.r[3] = ld32(0x06053FE0u);  // 06053F1E mov.l 0x06053FE0,r3
    c.r[2] = ld32(c.r[3]);  // 06053F20 mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053FC2u);  // 06053F22 mov.w 0x06053FC2,r1
    c.r[0] = c.r[2];  // 06053F24 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053F26 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06053F28 extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06053F2A cmp/ge r1,r10
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06053FA2; } }  // 06053F2C bt/s 0x06053FA2 ; mov #0,r9
    c.r[13] = ld32(0x06053FE4u);  // 06053F30 mov.l 0x06053FE4,r13
    c.r[1] = c.r[9];  // 06053F32 mov r9,r1
L_06053F34:
    c.r[1] += c.r[1];  // 06053F34 add r1,r1
    c.r[7] = c.r[11];  // 06053F36 mov r11,r7
    c.r[6] = c.r[14];  // 06053F38 mov r14,r6
    c.r[2] = ld32(c.r[3]);  // 06053F3A mov.l @r3,r2
    c.r[5] = c.r[14];  // 06053F3C mov r14,r5
    c.r[2] += c.r[1];  // 06053F3E add r1,r2
    c.r[2] += 1;  // 06053F40 add #1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053FC0u);  // 06053F42 mov.w 0x06053FC0,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06053F44 mov.b @r2,r8
    c.r[6] += c.r[1];  // 06053F46 add r1,r6
    c.r[8] = c.r[8] & 0xFFu;  // 06053F48 extu.b r8,r8
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06053F4A mov.l r12,@-r15
    { const uint32_t x = c.r[13]; c.pr = 0x06053F50u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06053F50u) return; }  // 06053F4C jsr @r13 ; mov r8,r4
    c.r[3] = c.r[0];  // 06053F50 mov r0,r3
    c.r[1] = ld32(0x06053FE8u);  // 06053F52 mov.l 0x06053FE8,r1
    c.r[2] = c.r[8];  // 06053F54 mov r8,r2
    c.r[2] += c.r[2];  // 06053F56 add r2,r2
    c.r[2] += c.r[8];  // 06053F58 add r8,r2
    c.r[1] = ld32(c.r[1]);  // 06053F5A mov.l @r1,r1
    c.r[2] <<= 2;  // 06053F5C shll2 r2
    c.r[2] += c.r[1];  // 06053F5E add r1,r2
    c.r[1] = c.r[2];  // 06053F60 mov r2,r1
    c.r[1] += 2;  // 06053F62 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06053F64 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06053F66 extu.b r1,r0
    c.t = c.r[0] == 0x63u;  // 06053F68 cmp/eq #99,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06053F90; } }  // 06053F6A bt/s 0x06053F90 ; add #4,r15
    c.r[8] = c.r[2];  // 06053F6E mov r2,r8
    c.r[8] += 4;  // 06053F70 add #4,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06053F72 mov.w @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06053FC4u);  // 06053F74 mov.w 0x06053FC4,r1
    c.r[2] -= c.r[3];  // 06053F76 sub r3,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06053F78 cmp/gt r1,r2
    if (!c.t) { goto L_06053F90; }  // 06053F7A bf 0x06053F90
    st16(c.r[8], c.r[2]);  // 06053F7C mov.w r2,@r8
    c.r[1] = ld32(0x06053FECu);  // 06053F7E mov.l 0x06053FEC,r1
    c.r[2] = ld32(c.r[1]);  // 06053F80 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053FC6u);  // 06053F82 mov.w 0x06053FC6,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06053F84 mov.l @(r0,r2),r1
    c.t = (c.r[9] & c.r[9]) == 0;  // 06053F86 tst r9,r9
    c.r[1] += c.r[3];  // 06053F88 add r3,r1
    { const bool k = !c.t; st32(c.r[0] + c.r[2], c.r[1]); if (k) { goto L_06053F90; } }  // 06053F8A bf/s 0x06053F90 ; mov.l r1,@(r0,r2)
    c.r[10] = c.r[3];  // 06053F8E mov r3,r10
L_06053F90:
    c.r[3] = ld32(0x06053FE0u);  // 06053F90 mov.l 0x06053FE0,r3
    c.r[1] = ld32(c.r[3]);  // 06053F92 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06053FC2u);  // 06053F94 mov.w 0x06053FC2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06053F96 mov.b @(r0,r1),r1
    c.r[9] += 1;  // 06053F98 add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06053F9A extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06053F9C cmp/ge r1,r9
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_06053F34; } }  // 06053F9E bf/s 0x06053F34 ; mov r9,r1
L_06053FA2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06053FC8u);  // 06053FA2 mov.w 0x06053FC8,r3
    c.r[14] += c.r[3];  // 06053FA4 add r3,r14
    c.r[15] = c.r[14];  // 06053FA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06053FA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06053FAA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06053FAC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06053FAE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06053FB0 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 06053FB2 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06053FB4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06053FB6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06053FB8 rts ; mov.l @r15+,r8
}

void f_06053FF0(SH2Context& c) {
    ran[1319] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06053FF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06053FF2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06053FF4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06053FF6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06053FF8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06053FFA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06053FFC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06053FFE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06054000 mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 06054002 extu.b r4,r13
    c.r[11] = ld32(0x06054104u);  // 06054004 mov.l 0x06054104,r11
    c.t = (c.r[13] & c.r[13]) == 0;  // 06054006 tst r13,r13
    { const bool k = c.t; c.r[10] = c.r[5] & 0xFFFFu; if (k) { goto L_06054090; } }  // 06054008 bt/s 0x06054090 ; extu.w r5,r10
    c.r[1] = c.r[10];  // 0605400C mov r10,r1
    c.r[1] += 1;  // 0605400E add #1,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 06054010 extu.w r1,r10
    c.r[9] = 0x0u;  // 06054012 mov #0,r9
    c.r[12] = ld32(0x06054108u);  // 06054014 mov.l 0x06054108,r12
    c.t = (c.r[10] & c.r[10]) == 0;  // 06054016 tst r10,r10
L_06054018:
    { const bool k = c.t; c.r[8] = c.r[9] & 0xFFFFu; if (k) { goto L_0605404A; } }  // 06054018 bt/s 0x0605404A ; extu.w r9,r8
    c.r[4] = ld32(0x0605410Cu);  // 0605401C mov.l 0x0605410C,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06054022u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054022u) return; }  // 0605401E jsr @r12 ; mov #27,r5
    c.r[5] = c.r[8];  // 06054022 mov r8,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06054028u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054028u) return; }  // 06054024 jsr @r12 ; mov r0,r4
    c.r[1] = c.r[0];  // 06054028 mov r0,r1
    c.r[1] += 8;  // 0605402A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605402C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605402E mov r1,r0
    c.r[0] >>= 2;  // 06054030 shlr2 r0
    c.r[0] >>= 2;  // 06054032 shlr2 r0
    c.r[0] &= 0x1u;  // 06054034 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054036 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06054040; } }  // 06054038 bt/s 0x06054040 ; mov r10,r1
    c.r[1] -= 1;  // 0605403C add #-1,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 0605403E extu.w r1,r10
L_06054040:
    c.r[9] += 1;  // 06054040 add #1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060540FEu);  // 06054042 mov.w 0x060540FE,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06054044 cmp/gt r1,r9
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { SH2_POLL(c); goto L_06054018; } }  // 06054046 bf/s 0x06054018 ; tst r10,r10
L_0605404A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06054100u);  // 0605404A mov.w 0x06054100,r1
    c.t = c.r[9] == c.r[1];  // 0605404C cmp/eq r1,r9
    { const bool k = c.t; c.r[9] -= 1; if (k) { goto L_060540E8; } }  // 0605404E bt/s 0x060540E8 ; add #-1,r9
    c.r[0] = c.r[13];  // 06054052 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 06054054 cmp/eq #2,r0
    { const bool k = !c.t; c.r[11] = c.r[9] & 0xFFFFu; if (k) { goto L_060540E8; } }  // 06054056 bf/s 0x060540E8 ; extu.w r9,r11
    c.r[9] = 0x0u;  // 0605405A mov #0,r9
    c.r[6] = 0x49u;  // 0605405C mov #73,r6
    c.r[2] = ld32(0x06054110u);  // 0605405E mov.l 0x06054110,r2
    c.r[1] = ld32(0x06054114u);  // 06054060 mov.l 0x06054114,r1
    c.r[3] = ld32(c.r[1]);  // 06054062 mov.l @r1,r3
    c.r[7] = 0x1Eu;  // 06054064 mov #30,r7
    c.r[2] = ld32(c.r[2]);  // 06054066 mov.l @r2,r2
L_06054068:
    c.r[1] = c.r[2];  // 06054068 mov r2,r1
    c.r[1] += 2;  // 0605406A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605406C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605406E extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 06054070 mul.l r7,r1
    c.r[0] = c.macl;  // 06054072 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06054074 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054076 extu.w r1,r1
    c.t = c.r[1] == c.r[11];  // 06054078 cmp/eq r11,r1
    if (c.t) { goto L_06054084; }  // 0605407A bt 0x06054084
    c.r[9] += 1;  // 0605407C add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[6];  // 0605407E cmp/gt r6,r9
    { const bool k = !c.t; c.r[2] += 16; if (k) { SH2_POLL(c); goto L_06054068; } }  // 06054080 bf/s 0x06054068 ; add #16,r2
L_06054084:
    c.r[0] = c.r[9];  // 06054084 mov r9,r0
    c.t = c.r[0] == 0x4Au;  // 06054086 cmp/eq #74,r0
    if (c.t) { goto L_060540E8; }  // 06054088 bt 0x060540E8
    c.r[11] = c.r[9] & 0xFFFFu;  // 0605408A extu.w r9,r11
    c.r[15] = c.r[14]; goto L_060540EA;  // 0605408C bra 0x060540EA ; mov r14,r15
L_06054090:
    c.r[4] = ld32(0x0605410Cu);  // 06054090 mov.l 0x0605410C,r4
    c.r[8] = ld32(0x06054108u);  // 06054092 mov.l 0x06054108,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06054098u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054098u) return; }  // 06054094 jsr @r8 ; mov #27,r5
    c.r[5] = c.r[10];  // 06054098 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605409Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605409Eu) return; }  // 0605409A jsr @r8 ; mov r0,r4
    c.r[1] = c.r[0];  // 0605409E mov r0,r1
    c.r[1] += 8;  // 060540A0 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060540A2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060540A4 mov r1,r0
    c.r[0] >>= 2;  // 060540A6 shlr2 r0
    c.r[0] >>= 2;  // 060540A8 shlr2 r0
    c.r[0] &= 0x1u;  // 060540AA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060540AC tst r0,r0
    if (c.t) { goto L_060540E8; }  // 060540AE bt 0x060540E8
    c.r[11] = 0x0u;  // 060540B0 mov #0,r11
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[10];  // 060540B2 cmp/ge r10,r11
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_060540E8; } }  // 060540B4 bt/s 0x060540E8 ; mov #0,r9
    c.r[12] = c.r[8];  // 060540B8 mov r8,r12
    c.r[8] = c.r[9] & 0xFFFFu;  // 060540BA extu.w r9,r8
L_060540BC:
    c.r[4] = ld32(0x0605410Cu);  // 060540BC mov.l 0x0605410C,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060540C2u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060540C2u) return; }  // 060540BE jsr @r12 ; mov #27,r5
    c.r[5] = c.r[8];  // 060540C2 mov r8,r5
    { const uint32_t x = c.r[12]; c.pr = 0x060540C8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060540C8u) return; }  // 060540C4 jsr @r12 ; mov r0,r4
    c.r[1] = c.r[0];  // 060540C8 mov r0,r1
    c.r[1] += 8;  // 060540CA add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060540CC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060540CE mov r1,r0
    c.r[0] >>= 2;  // 060540D0 shlr2 r0
    c.r[0] >>= 2;  // 060540D2 shlr2 r0
    c.r[0] &= 0x1u;  // 060540D4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060540D6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060540E0; } }  // 060540D8 bt/s 0x060540E0 ; mov r11,r1
    c.r[1] += 1;  // 060540DC add #1,r1
    c.r[11] = c.r[1] & 0xFFFFu;  // 060540DE extu.w r1,r11
L_060540E0:
    c.r[9] += 1;  // 060540E0 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 060540E2 cmp/ge r10,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_060540BC; } }  // 060540E4 bf/s 0x060540BC ; extu.w r9,r8
L_060540E8:
    c.r[15] = c.r[14];  // 060540E8 mov r14,r15
L_060540EA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060540EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060540EC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060540EE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060540F0 mov.l @r15+,r12
    c.r[0] = c.r[11];  // 060540F2 mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060540F4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060540F6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060540F8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060540FA rts ; mov.l @r15+,r8
}

void f_06054118(SH2Context& c) {
    ran[1320] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06054118 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605411A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605411C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605411E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06054120 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06054122 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06054124 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06054126 mov r15,r14
    c.r[10] = c.r[5];  // 06054128 mov r5,r10
    c.r[12] = c.r[4] & 0xFFu;  // 0605412A extu.b r4,r12
    c.r[8] = 0x0u;  // 0605412C mov #0,r8
    c.r[2] = 0x4u;  // 0605412E mov #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 06054130 mov #-1,r1
    c.r[0] = c.r[10];  // 06054132 mov r10,r0
L_06054134:
    st8(c.r[0] + c.r[8], c.r[1]);  // 06054134 mov.b r1,@(r0,r8)
    c.r[8] += 1;  // 06054136 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[2];  // 06054138 cmp/gt r2,r8
    if (!c.t) { SH2_POLL(c); goto L_06054134; }  // 0605413A bf 0x06054134
    c.r[2] = c.r[12];  // 0605413C mov r12,r2
    c.r[1] = ld32(0x06054248u);  // 0605413E mov.l 0x06054248,r1
    c.r[1] = ld32(c.r[1]);  // 06054140 mov.l @r1,r1
    c.r[2] <<= 2;  // 06054142 shll2 r2
    c.r[2] <<= 2;  // 06054144 shll2 r2
    c.r[2] += c.r[1];  // 06054146 add r1,r2
    c.r[2] += 2;  // 06054148 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605414A mov.b @r2,r2
    c.r[1] = ld32(0x0605424Cu);  // 0605414C mov.l 0x0605424C,r1
    c.r[3] = ld32(c.r[1]);  // 0605414E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06054150 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06054152 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06054154 mul.l r1,r2
    c.r[11] = ld32(0x06054250u);  // 06054156 mov.l 0x06054250,r11
    c.r[1] = c.macl;  // 06054158 sts macl,r1
    c.r[0] = c.r[1];  // 0605415A mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605415C mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 0605415E mov #0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06054164u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054164u) return; }  // 06054160 jsr @r11 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06054164 mov r0,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06054166 extu.w r1,r8
    c.r[1] = ld32(0x06054254u);  // 06054168 mov.l 0x06054254,r1
    c.t = c.r[8] == c.r[1];  // 0605416A cmp/eq r1,r8
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_060541CA; } }  // 0605416C bt/s 0x060541CA ; mov #0,r9
    c.r[7] = ld32(0x06054258u);  // 06054170 mov.l 0x06054258,r7
    c.r[5] = c.r[8];  // 06054172 mov r8,r5
    c.r[3] = ld32(c.r[7]);  // 06054174 mov.l @r7,r3
    c.r[5] <<= 2;  // 06054176 shll2 r5
    c.r[3] += c.r[5];  // 06054178 add r5,r3
    c.r[1] = c.r[3];  // 0605417A mov r3,r1
    c.r[1] += 22;  // 0605417C add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605417E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054180 extu.b r1,r1
    c.r[2] = c.r[1];  // 06054182 mov r1,r2
    c.r[2] >>= 2;  // 06054184 shlr2 r2
    c.r[2] >>= 2;  // 06054186 shlr2 r2
    c.r[2] >>= 2;  // 06054188 shlr2 r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605418A tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06054236; } }  // 0605418C bt/s 0x06054236 ; mov r1,r0
    c.r[0] >>= 2;  // 06054190 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054192 shlr r0
    c.r[0] >>= 2;  // 06054194 shlr2 r0
    c.r[0] &= 0x1u;  // 06054196 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054198 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06054236; } }  // 0605419A bf/s 0x06054236 ; mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0605419E cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFEu; if (k) { goto L_060541C2; } }  // 060541A0 bf/s 0x060541C2 ; mov #-2,r1
    st8(c.r[10], c.r[1]);  // 060541A4 mov.b r1,@r10
    c.r[1] = ld32(c.r[7]);  // 060541A6 mov.l @r7,r1
    c.r[2] = c.r[10];  // 060541A8 mov r10,r2
    c.r[1] += c.r[5];  // 060541AA add r5,r1
    c.r[1] += 20;  // 060541AC add #20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060541AE mov.b @r1,r1
    c.r[2] += 1;  // 060541B0 add #1,r2
    st8(c.r[2], c.r[1]);  // 060541B2 mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 060541B4 mov.l @r7,r1
    c.r[1] += c.r[5];  // 060541B6 add r5,r1
    c.r[1] += 21;  // 060541B8 add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060541BA mov.b @r1,r1
    c.r[10] += 2;  // 060541BC add #2,r10
    st8(c.r[10], c.r[1]); goto L_06054236;  // 060541BE bra 0x06054236 ; mov.b r1,@r10
L_060541C2:
    c.r[3] += 20;  // 060541C2 add #20,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060541C4 mov.b @r3,r1
    st8(c.r[10], c.r[1]); goto L_06054236;  // 060541C6 bra 0x06054236 ; mov.b r1,@r10
L_060541CA:
    c.r[8] = 0x0u;  // 060541CA mov #0,r8
L_060541CC:
    c.r[1] = ld32(0x06054258u);  // 060541CC mov.l 0x06054258,r1
    c.r[2] = ld32(c.r[1]);  // 060541CE mov.l @r1,r2
    c.r[1] = c.r[8];  // 060541D0 mov r8,r1
    c.r[1] <<= 2;  // 060541D2 shll2 r1
    c.r[2] += c.r[1];  // 060541D4 add r1,r2
    c.r[1] = c.r[2];  // 060541D6 mov r2,r1
    c.r[1] += 22;  // 060541D8 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060541DA mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060541DC extu.b r1,r3
    c.r[0] = c.r[3];  // 060541DE mov r3,r0
    c.r[0] >>= 2;  // 060541E0 shlr2 r0
    c.r[0] >>= 2;  // 060541E2 shlr2 r0
    c.r[0] >>= 2;  // 060541E4 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 060541E6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] += 20; if (k) { goto L_0605422E; } }  // 060541E8 bf/s 0x0605422E ; add #20,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060541EC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060541EE extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 060541F0 cmp/eq r12,r1
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0605422E; } }  // 060541F2 bf/s 0x0605422E ; mov r3,r0
    c.r[0] >>= 2;  // 060541F6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060541F8 shlr r0
    c.r[0] >>= 2;  // 060541FA shlr2 r0
    c.r[0] &= 0x1u;  // 060541FC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060541FE tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFFFu; if (k) { goto L_0605422E; } }  // 06054200 bf/s 0x0605422E ; extu.w r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06054208u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054208u) return; }  // 06054204 jsr @r11 ; mov #2,r4
    c.r[3] = c.r[0] & 0xFFFFu;  // 06054208 extu.w r0,r3
    c.r[1] = ld32(0x06054248u);  // 0605420A mov.l 0x06054248,r1
    c.r[2] = c.r[3];  // 0605420C mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 0605420E mov.l @r1,r1
    c.r[2] <<= 2;  // 06054210 shll2 r2
    c.r[2] <<= 2;  // 06054212 shll2 r2
    c.r[2] += c.r[1];  // 06054214 add r1,r2
    c.r[2] += 4;  // 06054216 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054218 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605421A mov r1,r0
    c.r[0] >>= 2;  // 0605421C shlr2 r0
    c.r[0] >>= 2;  // 0605421E shlr2 r0
    c.r[0] >>= 2;  // 06054220 shlr2 r0
    c.r[0] &= 0x1u;  // 06054222 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054224 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_0605422E; } }  // 06054226 bf/s 0x0605422E ; mov r10,r0
    st8(c.r[0] + c.r[9], c.r[3]);  // 0605422A mov.b r3,@(r0,r9)
    c.r[9] += 1;  // 0605422C add #1,r9
L_0605422E:
    c.r[8] += 1;  // 0605422E add #1,r8
    c.r[1] = 0x4u;  // 06054230 mov #4,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06054232 cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_060541CC; }  // 06054234 bf 0x060541CC
L_06054236:
    c.r[15] = c.r[14];  // 06054236 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06054238 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605423A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605423C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605423E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06054240 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06054242 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06054244 rts ; mov.l @r15+,r8
}

void f_0605425C(SH2Context& c) {
    ran[1321] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605425C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605425E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06054260 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06054262 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06054264 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06054266 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06054268 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605426A sts.l pr,@-r15
    c.r[15] -= 4;  // 0605426C add #-4,r15
    c.r[14] = c.r[15];  // 0605426E mov r15,r14
    st32(c.r[14], c.r[6]);  // 06054270 mov.l r6,@r14
    c.r[11] = c.r[4] & 0xFFu;  // 06054272 extu.b r4,r11
    c.r[10] = c.r[5] & 0xFFu;  // 06054274 extu.b r5,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06054276 mov.b @r6,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060542F4u);  // 06054278 mov.w 0x060542F4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605427A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605427C cmp/eq r2,r1
    { const bool k = !c.t; c.r[12] = 0x1u; if (k) { goto L_0605430C; } }  // 0605427E bf/s 0x0605430C ; mov #1,r12
    c.r[3] = ld32(0x060542F8u);  // 06054282 mov.l 0x060542F8,r3
    c.r[2] = c.r[11];  // 06054284 mov r11,r2
    c.r[2] += c.r[2];  // 06054286 add r2,r2
    c.r[1] = c.r[10];  // 06054288 mov r10,r1
    c.r[1] <<= 2;  // 0605428A shll2 r1
    c.r[1] <<= 2;  // 0605428C shll2 r1
    c.r[1] += c.r[1];  // 0605428E add r1,r1
    c.r[1] <<= 2;  // 06054290 shll2 r1
    c.r[1] += c.r[3];  // 06054292 add r3,r1
    c.r[0] = c.r[2];  // 06054294 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06054296 mov.w @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06054298 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605429A tst r2,r2
    if (c.t) { goto L_060542F0; }  // 0605429C bt 0x060542F0
    c.r[1] = ld32(0x060542FCu);  // 0605429E mov.l 0x060542FC,r1
    c.t = c.r[2] == c.r[1];  // 060542A0 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_060542F0; } }  // 060542A2 bt/s 0x060542F0 ; mov r6,r1
    c.r[8] = ld32(0x06054300u);  // 060542A6 mov.l 0x06054300,r8
    c.r[1] += 2;  // 060542A8 add #2,r1
    c.r[0] = c.r[6];  // 060542AA mov r6,r0
    c.r[0] += 1;  // 060542AC add #1,r0
    c.r[7] = c.r[10];  // 060542AE mov r10,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060542B0 mov.b @r1,r5
    c.r[6] = c.r[11];  // 060542B2 mov r11,r6
    c.r[5] = c.r[5] & 0xFFu;  // 060542B4 extu.b r5,r5
    st32(c.r[14], c.r[0]);  // 060542B6 mov.l r0,@r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060542B8 mov.b @r0,r4
    c.r[1] = ld32(0x06054304u);  // 060542BA mov.l 0x06054304,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060542BC extu.b r4,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060542BE mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060542C0 mov.l r8,@-r15
    c.r[1] = ld32(0x06054308u);  // 060542C2 mov.l 0x06054308,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060542C8u; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060542C8u) return; }  // 060542C4 jsr @r1 ; mov.l r3,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060542C8 mov.b @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060542F6u);  // 060542CA mov.w 0x060542F6,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060542CC extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060542CE cmp/eq r3,r1
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_060542E6; } }  // 060542D0 bt/s 0x060542E6 ; mov #0,r2
    c.r[7] = 0x9u;  // 060542D4 mov #9,r7
L_060542D6:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060542D6 cmp/gt r7,r2
    if (c.t) { goto L_060542E6; }  // 060542D8 bt 0x060542E6
    c.r[8] += 1;  // 060542DA add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060542DC mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060542DE extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060542E0 cmp/eq r3,r1
    { const bool k = !c.t; c.r[2] += 1; if (k) { SH2_POLL(c); goto L_060542D6; } }  // 060542E2 bf/s 0x060542D6 ; add #1,r2
L_060542E6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060542E6 mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060542F6u);  // 060542E8 mov.w 0x060542F6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060542EA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060542EC cmp/eq r2,r1
    if (c.t) { goto L_060543BC; }  // 060542EE bt 0x060543BC
L_060542F0:
    c.r[12] = 0x0u; goto L_060543BC;  // 060542F0 bra 0x060543BC ; mov #0,r12
L_0605430C:
    c.r[9] = 0x0u;  // 0605430C mov #0,r9
    c.r[13] = 0x0u;  // 0605430E mov #0,r13
    c.t = (c.r[12] & c.r[12]) == 0;  // 06054310 tst r12,r12
L_06054312:
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_060543BC; } }  // 06054312 bt/s 0x060543BC ; mov.l @r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06054316 mov.b @(r0,r9),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06054318 extu.b r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060543D4u);  // 0605431A mov.w 0x060543D4,r0
    c.t = c.r[2] == c.r[0];  // 0605431C cmp/eq r0,r2
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_060543AE; } }  // 0605431E bt/s 0x060543AE ; mov r2,r0
    c.r[1] = ld32(0x060543D8u);  // 06054322 mov.l 0x060543D8,r1
    c.r[0] <<= 2;  // 06054324 shll2 r0
    c.r[0] <<= 2;  // 06054326 shll2 r0
    c.r[1] = ld32(c.r[1]);  // 06054328 mov.l @r1,r1
    c.r[5] = c.r[0];  // 0605432A mov r0,r5
    c.r[5] += c.r[1];  // 0605432C add r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605432E mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06054330 extu.b r1,r4
    c.t = c.r[4] == c.r[11];  // 06054332 cmp/eq r11,r4
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_06054342; } }  // 06054334 bf/s 0x06054342 ; mov r5,r1
    c.r[1] += 1;  // 06054338 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605433A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605433C extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0605433E cmp/eq r10,r1
    if (c.t) { goto L_060543AE; }  // 06054340 bt 0x060543AE
L_06054342:
    c.r[3] = ld32(0x060543DCu);  // 06054342 mov.l 0x060543DC,r3
    c.r[3] += c.r[13];  // 06054344 add r13,r3
    c.r[1] = c.r[11];  // 06054346 mov r11,r1
    c.r[1] += c.r[1];  // 06054348 add r1,r1
    c.r[0] = c.r[10];  // 0605434A mov r10,r0
    c.r[0] <<= 2;  // 0605434C shll2 r0
    c.r[0] <<= 2;  // 0605434E shll2 r0
    c.r[0] += c.r[0];  // 06054350 add r0,r0
    c.r[0] <<= 2;  // 06054352 shll2 r0
    c.r[0] += c.r[3];  // 06054354 add r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06054356 mov.w @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06054358 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605435A tst r2,r2
    if (c.t) { goto L_060543AC; }  // 0605435C bt 0x060543AC
    c.r[1] = ld32(0x060543E0u);  // 0605435E mov.l 0x060543E0,r1
    c.t = c.r[2] == c.r[1];  // 06054360 cmp/eq r1,r2
    { const bool k = c.t; c.r[5] += 1; if (k) { goto L_060543AC; } }  // 06054362 bt/s 0x060543AC ; add #1,r5
    c.r[8] = ld32(0x060543E4u);  // 06054366 mov.l 0x060543E4,r8
    c.r[1] = ld32(0x060543E8u);  // 06054368 mov.l 0x060543E8,r1
    c.r[7] = c.r[10];  // 0605436A mov r10,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605436C mov.b @r5,r5
    c.r[6] = c.r[11];  // 0605436E mov r11,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06054370 extu.b r5,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06054372 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06054374 mov.l r8,@-r15
    c.r[1] = ld32(0x060543ECu);  // 06054376 mov.l 0x060543EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605437Cu; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605437Cu) return; }  // 06054378 jsr @r1 ; mov.l r3,@-r15
    c.r[2] = 0x0u;  // 0605437C mov #0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605437E mov.b @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060543D4u);  // 06054380 mov.w 0x060543D4,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06054382 extu.b r1,r1
    c.t = c.r[1] == c.r[0];  // 06054384 cmp/eq r0,r1
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_0605439E; } }  // 06054386 bt/s 0x0605439E ; add #12,r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060543D4u);  // 0605438A mov.w 0x060543D4,r3
    c.r[0] = 0x9u;  // 0605438C mov #9,r0
L_0605438E:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[0];  // 0605438E cmp/gt r0,r2
    if (c.t) { goto L_0605439E; }  // 06054390 bt 0x0605439E
    c.r[8] += 1;  // 06054392 add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06054394 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054396 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06054398 cmp/eq r3,r1
    { const bool k = !c.t; c.r[2] += 1; if (k) { SH2_POLL(c); goto L_0605438E; } }  // 0605439A bf/s 0x0605438E ; add #1,r2
L_0605439E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605439E mov.b @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060543D4u);  // 060543A0 mov.w 0x060543D4,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060543A2 extu.b r1,r1
    c.t = c.r[1] == c.r[0];  // 060543A4 cmp/eq r0,r1
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_060543AC; } }  // 060543A6 bf/s 0x060543AC ; tst r2,r2
    if (!c.t) { goto L_060543AE; }  // 060543AA bf 0x060543AE
L_060543AC:
    c.r[12] = 0x0u;  // 060543AC mov #0,r12
L_060543AE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060543D6u);  // 060543AE mov.w 0x060543D6,r1
    c.r[13] += c.r[1];  // 060543B0 add r1,r13
    c.r[9] += 1;  // 060543B2 add #1,r9
    c.r[1] = 0x4u;  // 060543B4 mov #4,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060543B6 cmp/gt r1,r9
    { const bool k = !c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { SH2_POLL(c); goto L_06054312; } }  // 060543B8 bf/s 0x06054312 ; tst r12,r12
L_060543BC:
    c.r[14] += 4;  // 060543BC add #4,r14
    c.r[15] = c.r[14];  // 060543BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060543C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060543C2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060543C4 mov.l @r15+,r13
    c.r[0] = c.r[12];  // 060543C6 mov r12,r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060543C8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060543CA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060543CC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060543CE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060543D0 rts ; mov.l @r15+,r8
}

void f_060543F0(SH2Context& c) {
    ran[1322] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060543F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060543F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060543F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060543F6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060543F8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060543FA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060543FC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060543FE mov r15,r14
    c.r[8] = c.r[5];  // 06054400 mov r5,r8
    c.r[1] = ld32(c.r[14] + 28);  // 06054402 mov.l @(28,r14),r1
    c.r[4] = c.r[4] & 0xFFFFu;  // 06054404 extu.w r4,r4
    c.r[10] = c.r[6] & 0xFFu;  // 06054406 extu.b r6,r10
    c.r[11] = c.r[7] & 0xFFu;  // 06054408 extu.b r7,r11
    c.r[9] = 0x0u;  // 0605440A mov #0,r9
    c.r[0] = ld32(0x060544C4u);  // 0605440C mov.l 0x060544C4,r0
    c.r[5] = c.r[4];  // 0605440E mov r4,r5
    c.r[4] = 0x0u;  // 06054410 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06054416u; c.r[12] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054416u) return; }  // 06054412 jsr @r0 ; extu.b r1,r12
    c.r[2] = c.r[0] & 0xFFFFu;  // 06054416 extu.w r0,r2
    c.r[1] = ld32(0x060544C8u);  // 06054418 mov.l 0x060544C8,r1
    c.t = c.r[2] == c.r[1];  // 0605441A cmp/eq r1,r2
    { const bool k = c.t; c.r[3] = c.r[2]; if (k) { goto L_060544AE; } }  // 0605441C bt/s 0x060544AE ; mov r2,r3
    c.r[1] = 0x2u;  // 06054420 mov #2,r1
    c.t = c.r[10] > c.r[1];  // 06054422 cmp/hi r1,r10
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06054480; } }  // 06054424 bt/s 0x06054480 ; mov r3,r0
    c.r[0] = c.r[10];  // 06054428 mov r10,r0
    c.t = c.r[0] == 0x1u;  // 0605442A cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0605443A; } }  // 0605442C bt/s 0x0605443A ; mov #0,r1
    c.t = c.r[0] == 0x2u;  // 06054430 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0605444A; } }  // 06054432 bt/s 0x0605444A ; mov r3,r0
    c.r[0] <<= 2; goto L_0605445A;  // 06054436 bra 0x0605445A ; shll2 r0
L_0605443A:
    c.r[0] = c.r[2];  // 0605443A mov r2,r0
    c.r[0] <<= 2;  // 0605443C shll2 r0
    c.r[2] = c.r[0];  // 0605443E mov r0,r2
    c.r[2] += c.r[8];  // 06054440 add r8,r2
    st8(c.r[0] + c.r[8], c.r[11]);  // 06054442 mov.b r11,@(r0,r8)
    c.r[2] += 1;  // 06054444 add #1,r2
    st8(c.r[2], c.r[1]); goto L_06054466;  // 06054446 bra 0x06054466 ; mov.b r1,@r2
L_0605444A:
    c.r[0] = c.r[2];  // 0605444A mov r2,r0
    c.r[0] <<= 2;  // 0605444C shll2 r0
    c.r[1] = c.r[0];  // 0605444E mov r0,r1
    c.r[1] += c.r[8];  // 06054450 add r8,r1
    st8(c.r[0] + c.r[8], c.r[11]);  // 06054452 mov.b r11,@(r0,r8)
    c.r[1] += 1;  // 06054454 add #1,r1
    st8(c.r[1], c.r[12]); goto L_06054466;  // 06054456 bra 0x06054466 ; mov.b r12,@r1
L_0605445A:
    c.r[2] = c.r[0];  // 0605445A mov r0,r2
    c.r[2] += c.r[8];  // 0605445C add r8,r2
    c.r[2] += 1;  // 0605445E add #1,r2
    c.r[1] = 0x0u;  // 06054460 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06054462 mov.b r1,@r2
    st8(c.r[0] + c.r[8], c.r[1]);  // 06054464 mov.b r1,@(r0,r8)
L_06054466:
    c.r[1] = c.r[3];  // 06054466 mov r3,r1
    c.r[1] <<= 2;  // 06054468 shll2 r1
    c.r[1] += c.r[8];  // 0605446A add r8,r1
    c.r[1] += 2;  // 0605446C add #2,r1
    c.r[10] <<= 2;  // 0605446E shll2 r10
    c.r[10] <<= 2;  // 06054470 shll2 r10
    c.r[10] <<= 2;  // 06054472 shll2 r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054474 mov.b @r1,r0
    c.r[9] = 0x1u;  // 06054476 mov #1,r9
    c.r[0] &= 0x3Fu;  // 06054478 and #63,r0
    c.r[0] |= c.r[10];  // 0605447A or r10,r0
    st8(c.r[1], c.r[0]); goto L_060544AE;  // 0605447C bra 0x060544AE ; mov.b r0,@r1
L_06054480:
    c.r[0] <<= 2;  // 06054480 shll2 r0
    c.r[3] = c.r[0];  // 06054482 mov r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06054484 mov.b @(r0,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060544C2u);  // 06054486 mov.w 0x060544C2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06054488 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605448A cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[8]; if (k) { goto L_060544AE; } }  // 0605448C bt/s 0x060544AE ; add r8,r3
    c.r[3] += 2;  // 06054490 add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06054492 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054494 extu.b r1,r1
    c.r[0] = c.r[1];  // 06054496 mov r1,r0
    c.r[0] >>= 2;  // 06054498 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605449A shlr r0
    c.r[0] >>= 2;  // 0605449C shlr2 r0
    c.r[0] &= 0x1u;  // 0605449E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060544A0 tst r0,r0
    { const bool k = !c.t; c.r[1] >>= 2; if (k) { goto L_060544AE; } }  // 060544A2 bf/s 0x060544AE ; shlr2 r1
    c.r[1] >>= 2;  // 060544A6 shlr2 r1
    c.r[1] >>= 2;  // 060544A8 shlr2 r1
    c.r[1] += 1;  // 060544AA add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060544AC extu.b r1,r9
L_060544AE:
    c.r[15] = c.r[14];  // 060544AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060544B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060544B2 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060544B4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060544B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060544B8 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 060544BA mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060544BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060544BE rts ; mov.l @r15+,r8
}

void f_060544CC(SH2Context& c) {
    ran[1323] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060544CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060544CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060544D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060544D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060544D4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060544D6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060544D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060544DA sts.l pr,@-r15
    c.r[15] -= 28;  // 060544DC add #-28,r15
    c.r[14] = c.r[15];  // 060544DE mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060544E0 extu.b r4,r4
    st32(c.r[14] + 8, c.r[4]);  // 060544E2 mov.l r4,@(8,r14)
    c.r[13] = 0x0u;  // 060544E4 mov #0,r13
    c.r[0] = 0x0u;  // 060544E6 mov #0,r0
    st32(c.r[14] + 20, c.r[0]);  // 060544E8 mov.l r0,@(20,r14)
    c.r[1] = ld32(0x060545D8u);  // 060544EA mov.l 0x060545D8,r1
    c.r[2] = ld32(c.r[1]);  // 060544EC mov.l @r1,r2
    c.r[11] = 0x7u;  // 060544EE mov #7,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x060545CEu);  // 060544F0 mov.w 0x060545CE,r1
    c.r[0] = c.r[2];  // 060544F2 mov r2,r0
    c.r[7] = c.r[2];  // 060544F4 mov r2,r7
    c.r[7] += 16;  // 060544F6 add #16,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060544F8 mov.b @(r0,r1),r1
    c.r[3] = c.r[1];  // 060544FA mov r1,r3
    c.r[3] >>= 2;  // 060544FC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060544FE shlr r3
    c.r[3] &= c.r[11];  // 06054500 and r11,r3
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[3];  // 06054502 cmp/ge r3,r13
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0605451C; } }  // 06054504 bt/s 0x0605451C ; mov #0,r2
    c.r[0] = c.r[7];  // 06054508 mov r7,r0
L_0605450A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605450A mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605450C extu.b r1,r1
    c.r[0] = c.r[1];  // 0605450E mov r1,r0
    c.t = c.r[0] == 0xAu;  // 06054510 cmp/eq #10,r0
    if (c.t) { goto L_0605451C; }  // 06054512 bt 0x0605451C
    c.r[2] += 1;  // 06054514 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06054516 cmp/ge r3,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_0605450A; } }  // 06054518 bf/s 0x0605450A ; mov r7,r0
L_0605451C:
    c.t = c.r[2] == c.r[3];  // 0605451C cmp/eq r3,r2
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06054524; } }  // 0605451E bt/s 0x06054524 ; mov #-1,r1
    c.r[1] = c.r[2];  // 06054522 mov r2,r1
L_06054524:
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06054524 exts.b r1,r1
    c.r[0] = c.r[1];  // 06054526 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06054528 cmp/eq #-1,r0
    c.r[11] = c.t;  // 0605452A movt r11
    st32(c.r[14] + 12, c.r[11]);  // 0605452C mov.l r11,@(12,r14)
    c.r[0] = c.r[11];  // 0605452E mov r11,r0
    c.r[0] ^= 0x1u;  // 06054530 xor #1,r0
    st32(c.r[14] + 12, c.r[0]);  // 06054532 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06054534 mov.l @(8,r14),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060545D0u);  // 06054536 mov.w 0x060545D0,r11
    c.r[1] &= c.r[11];  // 06054538 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605453A tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06054546; } }  // 0605453C bt/s 0x06054546 ; mov.l @(8,r14),r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x060545D2u);  // 06054540 mov.w 0x060545D2,r12
    c.r[0] &= 0x7Fu; goto L_0605455C;  // 06054542 bra 0x0605455C ; and #127,r0
L_06054546:
    c.r[1] = ld32(0x060545D8u);  // 06054546 mov.l 0x060545D8,r1
    c.r[1] = ld32(c.r[1]);  // 06054548 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060545D4u);  // 0605454A mov.w 0x060545D4,r2
    c.r[0] = c.r[1];  // 0605454C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605454E mov.b @(r0,r2),r1
    c.r[11] = 0xFu;  // 06054550 mov #15,r11
    c.r[12] = c.r[1];  // 06054552 mov r1,r12
    c.t = c.r[12] & 1; c.r[12] >>= 1;  // 06054554 shlr r12
    c.r[12] &= c.r[11];  // 06054556 and r11,r12
    c.r[0] = ld32(c.r[14] + 8);  // 06054558 mov.l @(8,r14),r0
    c.r[0] &= 0x7Fu;  // 0605455A and #127,r0
L_0605455C:
    st32(c.r[14] + 8, c.r[0]);  // 0605455C mov.l r0,@(8,r14)
    c.r[0] = c.r[12];  // 0605455E mov r12,r0
    c.t = c.r[0] == 0x3u;  // 06054560 cmp/eq #3,r0
    if (!c.t) { goto L_06054568; }  // 06054562 bf 0x06054568
    goto L_060546AA;  // 06054564 bra 0x060546AA ; nop
L_06054568:
    c.r[1] = 0x3u;  // 06054568 mov #3,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 0605456A cmp/gt r1,r12
    { const bool k = c.t; c.t = c.r[0] == 0x5u; if (k) { goto L_06054580; } }  // 0605456C bt/s 0x06054580 ; cmp/eq #5,r0
    c.r[1] = 0x1u;  // 06054570 mov #1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 06054572 cmp/ge r1,r12
    { const bool k = c.t; c.r[11] = 0x1u; if (k) { goto L_0605457C; } }  // 06054574 bt/s 0x0605457C ; mov #1,r11
    goto L_060548A4;  // 06054578 bra 0x060548A4 ; nop
L_0605457C:
    st32(c.r[14] + 20, c.r[11]); goto L_060545A0;  // 0605457C bra 0x060545A0 ; mov.l r11,@(20,r14)
L_06054580:
    if (!c.t) { goto L_06054586; }  // 06054580 bf 0x06054586
    goto L_060546AA;  // 06054582 bra 0x060546AA ; nop
L_06054586:
    c.r[1] = 0x5u;  // 06054586 mov #5,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 06054588 cmp/ge r1,r12
    { const bool k = c.t; c.r[11] = 0x20u; if (k) { goto L_06054592; } }  // 0605458A bt/s 0x06054592 ; mov #32,r11
    goto L_06054694;  // 0605458E bra 0x06054694 ; nop
L_06054592:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060545D2u);  // 06054592 mov.w 0x060545D2,r1
    c.t = c.r[12] == c.r[1];  // 06054594 cmp/eq r1,r12
    { const bool k = c.t; c.r[11] = 0x1u; if (k) { goto L_0605459E; } }  // 06054596 bt/s 0x0605459E ; mov #1,r11
    goto L_060548A4;  // 0605459A bra 0x060548A4 ; nop
L_0605459E:
    st32(c.r[14] + 20, c.r[11]);  // 0605459E mov.l r11,@(20,r14)
L_060545A0:
    c.r[1] = ld32(0x060545D8u);  // 060545A0 mov.l 0x060545D8,r1
    c.r[2] = ld32(c.r[1]);  // 060545A2 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060545D4u);  // 060545A4 mov.w 0x060545D4,r1
    c.r[0] = c.r[2];  // 060545A6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060545A8 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060545AA extu.b r1,r1
    c.r[1] >>= 2;  // 060545AC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060545AE shlr r1
    c.r[1] >>= 2;  // 060545B0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060545B2 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_060545DC; } }  // 060545B4 bt/s 0x060545DC ; mov r12,r0
    c.t = c.r[0] == 0x1u;  // 060545B8 cmp/eq #1,r0
    { const bool k = !c.t; c.r[11] = 0x7Fu; if (k) { goto L_060545DC; } }  // 060545BA bf/s 0x060545DC ; mov #127,r11
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060545BE mov.w @r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060545D0u);  // 060545C0 mov.w 0x060545D0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060545C2 mov.b @r14,r1
    c.r[2] -= 1;  // 060545C4 add #-1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 060545C6 extu.w r2,r2
    c.r[3] = c.r[2];  // 060545C8 mov r2,r3
    c.r[3] >>= 8; goto L_060545F0;  // 060545CA bra 0x060545F0 ; shlr8 r3
L_060545DC:
    c.r[1] = ld32(0x060546D8u);  // 060545DC mov.l 0x060546D8,r1
    c.r[1] = ld32(c.r[1]);  // 060545DE mov.l @r1,r1
    c.r[11] = 0x7Fu;  // 060545E0 mov #127,r11
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060545E2 mov.w @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060546D2u);  // 060545E4 mov.w 0x060546D2,r0
    c.r[2] += 1;  // 060545E6 add #1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 060545E8 extu.w r2,r2
    c.r[3] = c.r[2];  // 060545EA mov r2,r3
    c.r[3] >>= 8;  // 060545EC shlr8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060545EE mov.b @r14,r1
L_060545F0:
    c.r[3] &= c.r[11];  // 060545F0 and r11,r3
    c.r[1] &= c.r[0];  // 060545F2 and r0,r1
    c.r[1] |= c.r[3];  // 060545F4 or r3,r1
    st8(c.r[14], c.r[1]);  // 060545F6 mov.b r1,@r14
    c.r[1] = c.r[14];  // 060545F8 mov r14,r1
    c.r[1] += 1;  // 060545FA add #1,r1
    st8(c.r[1], c.r[2]);  // 060545FC mov.b r2,@r1
    c.r[11] = ld32(c.r[14] + 12);  // 060545FE mov.l @(12,r14),r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 06054600 tst r11,r11
    { const bool k = !c.t; c.r[2] = 0x7Fu; if (k) { goto L_06054636; } }  // 06054602 bf/s 0x06054636 ; mov #127,r2
    c.r[4] = ld32(0x060546DCu);  // 06054606 mov.l 0x060546DC,r4
    c.r[9] = ld32(0x060546E0u);  // 06054608 mov.l 0x060546E0,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0605460A mov.b @r14,r1
    c.r[5] = 0x1Bu;  // 0605460C mov #27,r5
    c.r[2] &= c.r[1];  // 0605460E and r1,r2
    c.r[1] = c.r[14];  // 06054610 mov r14,r1
    c.r[1] += 1;  // 06054612 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054614 mov.b @r1,r8
    c.r[2] <<= 8;  // 06054616 shll8 r2
    c.r[8] = c.r[8] & 0xFFu;  // 06054618 extu.b r8,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0605461Eu; c.r[8] |= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605461Eu) return; }  // 0605461A jsr @r9 ; or r2,r8
    c.r[1] = c.r[0];  // 0605461E mov r0,r1
    c.r[5] = c.r[8];  // 06054620 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06054626u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054626u) return; }  // 06054622 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06054626 mov r0,r1
    c.r[1] += 25;  // 06054628 add #25,r1
    c.r[6] = 0xFu;  // 0605462A mov #15,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605462C mov.b @r1,r1
    c.r[0] = 0x10u;  // 0605462E mov #16,r0
    c.r[6] &= c.r[1];  // 06054630 and r1,r6
    c.r[6] |= c.r[0]; goto L_06054638;  // 06054632 bra 0x06054638 ; or r0,r6
L_06054636:
    c.r[6] = 0x16u;  // 06054636 mov #22,r6
L_06054638:
    c.r[1] = ld32(0x060546E4u);  // 06054638 mov.l 0x060546E4,r1
    c.r[7] = 0xFFFFFFFFu;  // 0605463A mov #-1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605463C mov.b @r1,r2
    c.r[11] = ld32(0x060546E8u);  // 0605463E mov.l 0x060546E8,r11
    c.r[2] = c.r[2] & 0xFFu;  // 06054640 extu.b r2,r2
    c.r[1] = ld32(0x060546ECu);  // 06054642 mov.l 0x060546EC,r1
    c.r[3] = ld32(c.r[1]);  // 06054644 mov.l @r1,r3
    c.r[2] <<= 2;  // 06054646 shll2 r2
    c.r[2] <<= 2;  // 06054648 shll2 r2
    c.r[1] = c.r[2];  // 0605464A mov r2,r1
    c.r[1] += c.r[3];  // 0605464C add r3,r1
    c.r[1] += 1;  // 0605464E add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054650 mov.b @r1,r5
    c.r[0] = c.r[2];  // 06054652 mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06054654 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06054656 extu.b r5,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605465Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605465Cu) return; }  // 06054658 jsr @r11 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0605465C mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0605465E exts.b r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06054660 cmp/pz r1
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0605468A; } }  // 06054662 bf/s 0x0605468A ; mov r12,r0
    c.t = c.r[0] == 0x2u;  // 06054666 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_06054682; } }  // 06054668 bf/s 0x06054682 ; mov.b @r14,r0
    c.r[1] = ld32(0x060546D8u);  // 0605466C mov.l 0x060546D8,r1
    c.r[1] = ld32(c.r[1]);  // 0605466E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060546D4u);  // 06054670 mov.w 0x060546D4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06054672 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054674 extu.b r1,r1
    c.r[1] >>= 2;  // 06054676 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06054678 shlr r1
    c.r[1] >>= 2;  // 0605467A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605467C tst r1,r1
    { const bool k = !c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_0605468A; } }  // 0605467E bf/s 0x0605468A ; mov.b @r14,r0
L_06054682:
    c.r[13] = 0x11u;  // 06054682 mov #17,r13
    c.r[0] &= 0x7Fu;  // 06054684 and #127,r0
    st8(c.r[14], c.r[0]); goto L_060548A4;  // 06054686 bra 0x060548A4 ; mov.b r0,@r14
L_0605468A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0605468A mov.b @r14,r0
    c.r[13] = 0x1u;  // 0605468C mov #1,r13
    c.r[0] |= 0x80u;  // 0605468E or #128,r0
    st8(c.r[14], c.r[0]); goto L_060548A4;  // 06054690 bra 0x060548A4 ; mov.b r0,@r14
L_06054694:
    c.r[1] = ld32(0x060546F0u);  // 06054694 mov.l 0x060546F0,r1
    c.r[2] = ld32(c.r[1]);  // 06054696 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060546D6u);  // 06054698 mov.w 0x060546D6,r1
    c.r[0] = c.r[2];  // 0605469A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605469C mov.b @(r0,r1),r1
    c.r[1] &= c.r[11];  // 0605469E and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060546A0 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_060546AA; } }  // 060546A2 bt/s 0x060546AA ; mov.l @(8,r14),r0
    goto L_060548A6;  // 060546A6 bra 0x060548A6 ; nop
L_060546AA:
    c.r[13] = 0x0u;  // 060546AA mov #0,r13
    c.r[0] = 0x0u;  // 060546AC mov #0,r0
    st32(c.r[14] + 20, c.r[0]);  // 060546AE mov.l r0,@(20,r14)
    c.r[1] = ld32(0x060546D8u);  // 060546B0 mov.l 0x060546D8,r1
    c.r[1] = ld32(c.r[1]);  // 060546B2 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060546D4u);  // 060546B4 mov.w 0x060546D4,r2
    c.r[3] = c.r[1];  // 060546B6 mov r1,r3
    c.r[0] = c.r[1];  // 060546B8 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060546BA mov.b @(r0,r2),r2
    c.r[3] += 1;  // 060546BC add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060546BE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060546C0 mov.b @r3,r1
    c.r[2] >>= 2;  // 060546C2 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060546C4 shlr r2
    c.r[2] >>= 2;  // 060546C6 shlr2 r2
    c.r[1] -= c.r[2];  // 060546C8 sub r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060546CA extu.b r1,r10
    st32(c.r[14] + 16, c.r[10]);  // 060546CC mov.l r10,@(16,r14)
    c.r[1] = c.r[10]; goto L_0605488E;  // 060546CE bra 0x0605488E ; mov r10,r1
L_060546F4:
    c.r[1] = ld32(0x06054830u);  // 060546F4 mov.l 0x06054830,r1
    c.r[1] = ld32(c.r[1]);  // 060546F6 mov.l @r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060546F8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060546FA extu.w r1,r1
    c.t = c.r[10] == c.r[1];  // 060546FC cmp/eq r1,r10
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 16); if (k) { goto L_06054706; } }  // 060546FE bf/s 0x06054706 ; mov.l @(16,r14),r1
    goto L_0605488C;  // 06054702 bra 0x0605488C ; nop
L_06054706:
    c.r[11] = 0x1u;  // 06054706 mov #1,r11
    c.r[0] = c.r[12];  // 06054708 mov r12,r0
    c.t = c.r[0] == 0x5u;  // 0605470A cmp/eq #5,r0
    { const bool k = !c.t; st32(c.r[14] + 24, c.r[11]); if (k) { goto L_06054730; } }  // 0605470C bf/s 0x06054730 ; mov.l r11,@(24,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 06054710 mov.l @(16,r14),r1
    c.r[1] += 1;  // 06054712 add #1,r1
    c.t = c.r[10] == c.r[1];  // 06054714 cmp/eq r1,r10
    { const bool k = !c.t; c.r[2] = 0x6Du; if (k) { goto L_06054730; } }  // 06054716 bf/s 0x06054730 ; mov #109,r2
    c.r[1] = ld32(0x06054834u);  // 0605471A mov.l 0x06054834,r1
    c.r[1] = ld32(c.r[1]);  // 0605471C mov.l @r1,r1
    c.r[1] += 9;  // 0605471E add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054720 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054722 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06054724 cmp/hi r2,r1
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_06054732; } }  // 06054726 bt/s 0x06054732 ; cmp/eq #4,r0
    c.r[11] = 0x0u;  // 0605472A mov #0,r11
    st32(c.r[14] + 24, c.r[11]);  // 0605472C mov.l r11,@(24,r14)
    c.r[0] = c.r[12];  // 0605472E mov r12,r0
L_06054730:
    c.t = c.r[0] == 0x4u;  // 06054730 cmp/eq #4,r0
L_06054732:
    { const bool k = !c.t; c.r[9] = c.r[10] & 0xFFFFu; if (k) { goto L_060547BA; } }  // 06054732 bf/s 0x060547BA ; extu.w r10,r9
    c.r[11] = ld32(0x06054838u);  // 06054736 mov.l 0x06054838,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0605473Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605473Cu) return; }  // 06054738 jsr @r11 ; mov r9,r4
    c.r[1] = c.r[0];  // 0605473C mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0605473E extu.b r1,r8
    c.r[0] = 0x0u;  // 06054740 mov #0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605482Cu);  // 06054742 mov.w 0x0605482C,r1
    c.t = c.r[8] == c.r[1];  // 06054744 cmp/eq r1,r8
    { const bool k = c.t; st32(c.r[14] + 12, c.r[0]); if (k) { goto L_060547BA; } }  // 06054746 bt/s 0x060547BA ; mov.l r0,@(12,r14)
    c.r[1] = ld32(0x0605483Cu);  // 0605474A mov.l 0x0605483C,r1
    c.r[8] <<= 2;  // 0605474C shll2 r8
    c.r[8] <<= 2;  // 0605474E shll2 r8
    c.r[5] = 0x1Bu;  // 06054750 mov #27,r5
    c.r[1] = ld32(c.r[1]);  // 06054752 mov.l @r1,r1
    c.r[4] = ld32(0x06054840u);  // 06054754 mov.l 0x06054840,r4
    c.r[8] += c.r[1];  // 06054756 add r1,r8
    c.r[8] += 2;  // 06054758 add #2,r8
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605475A mov.b @r8,r8
    c.r[11] = ld32(0x06054844u);  // 0605475C mov.l 0x06054844,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06054762u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054762u) return; }  // 0605475E jsr @r11 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06054762 mov r0,r1
    c.r[5] = c.r[9];  // 06054764 mov r9,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605476Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605476Au) return; }  // 06054766 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0605476A mov r0,r1
    c.r[1] += 25;  // 0605476C add #25,r1
    c.r[3] = 0x30u;  // 0605476E mov #48,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054770 mov.b @r1,r1
    c.r[2] = 0x0u;  // 06054772 mov #0,r2
    c.r[0] = ld32(c.r[14] + 12);  // 06054774 mov.l @(12,r14),r0
    c.r[3] &= c.r[1];  // 06054776 and r1,r3
    c.r[1] = 0x1Eu;  // 06054778 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0605477A mul.l r1,r8
    c.r[3] >>= 2;  // 0605477C shlr2 r3
    c.r[3] >>= 2;  // 0605477E shlr2 r3
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06054780 cmp/ge r3,r0
    c.r[1] = ld32(0x06054848u);  // 06054782 mov.l 0x06054848,r1
    c.r[1] = ld32(c.r[1]);  // 06054784 mov.l @r1,r1
    c.r[7] = c.macl;  // 06054786 sts macl,r7
    c.r[7] += c.r[1];  // 06054788 add r1,r7
    { const bool k = c.t; c.r[7] += 17; if (k) { goto L_060547A2; } }  // 0605478A bt/s 0x060547A2 ; add #17,r7
    c.r[0] = c.r[7];  // 0605478E mov r7,r0
L_06054790:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06054790 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054792 extu.b r1,r1
    c.r[0] = c.r[1];  // 06054794 mov r1,r0
    c.t = c.r[0] == 0xAu;  // 06054796 cmp/eq #10,r0
    if (c.t) { goto L_060547A2; }  // 06054798 bt 0x060547A2
    c.r[2] += 1;  // 0605479A add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 0605479C cmp/ge r3,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_06054790; } }  // 0605479E bf/s 0x06054790 ; mov r7,r0
L_060547A2:
    c.t = c.r[2] == c.r[3];  // 060547A2 cmp/eq r3,r2
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_060547AA; } }  // 060547A4 bt/s 0x060547AA ; mov #-1,r1
    c.r[1] = c.r[2];  // 060547A8 mov r2,r1
L_060547AA:
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 060547AA exts.b r1,r1
    c.r[0] = c.r[1];  // 060547AC mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060547AE cmp/eq #-1,r0
    c.r[11] = c.t;  // 060547B0 movt r11
    st32(c.r[14] + 12, c.r[11]);  // 060547B2 mov.l r11,@(12,r14)
    c.r[0] = c.r[11];  // 060547B4 mov r11,r0
    c.r[0] ^= 0x1u;  // 060547B6 xor #1,r0
    st32(c.r[14] + 12, c.r[0]);  // 060547B8 mov.l r0,@(12,r14)
L_060547BA:
    c.r[11] = ld32(c.r[14] + 24);  // 060547BA mov.l @(24,r14),r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060547BC tst r11,r11
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 16); if (k) { goto L_0605488C; } }  // 060547BE bt/s 0x0605488C ; mov.l @(16,r14),r1
    c.r[0] = ld32(c.r[14] + 12);  // 060547C2 mov.l @(12,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060547C4 tst r0,r0
    { const bool k = !c.t; c.r[8] = c.r[10] & 0xFFFFu; if (k) { goto L_060547EA; } }  // 060547C6 bf/s 0x060547EA ; extu.w r10,r8
    c.r[4] = ld32(0x06054840u);  // 060547CA mov.l 0x06054840,r4
    c.r[11] = ld32(0x06054844u);  // 060547CC mov.l 0x06054844,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060547D2u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060547D2u) return; }  // 060547CE jsr @r11 ; mov #27,r5
    c.r[1] = c.r[0];  // 060547D2 mov r0,r1
    c.r[5] = c.r[8];  // 060547D4 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060547DAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060547DAu) return; }  // 060547D6 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 060547DA mov r0,r1
    c.r[1] += 25;  // 060547DC add #25,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060547DE mov.b @r1,r1
    c.r[3] = 0xFu;  // 060547E0 mov #15,r3
    c.r[0] = 0x10u;  // 060547E2 mov #16,r0
    c.r[3] &= c.r[1];  // 060547E4 and r1,r3
    c.r[3] |= c.r[0]; goto L_060547EC;  // 060547E6 bra 0x060547EC ; or r0,r3
L_060547EA:
    c.r[3] = 0x16u;  // 060547EA mov #22,r3
L_060547EC:
    c.r[1] = ld32(0x0605484Cu);  // 060547EC mov.l 0x0605484C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060547EE mov.b @r1,r1
    c.r[7] = 0xFFFFFFFFu;  // 060547F0 mov #-1,r7
    c.r[0] = c.r[1] & 0xFFu;  // 060547F2 extu.b r1,r0
    c.r[1] = ld32(0x0605483Cu);  // 060547F4 mov.l 0x0605483C,r1
    c.r[2] = ld32(c.r[1]);  // 060547F6 mov.l @r1,r2
    c.r[0] <<= 2;  // 060547F8 shll2 r0
    c.r[0] <<= 2;  // 060547FA shll2 r0
    c.r[1] = c.r[0];  // 060547FC mov r0,r1
    c.r[1] += c.r[2];  // 060547FE add r2,r1
    c.r[1] += 1;  // 06054800 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054802 mov.b @r1,r5
    c.r[6] = c.r[3];  // 06054804 mov r3,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06054806 mov.b @(r0,r2),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06054808 extu.b r5,r5
    c.r[0] = ld32(0x06054850u);  // 0605480A mov.l 0x06054850,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06054810u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054810u) return; }  // 0605480C jsr @r0 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06054810 exts.b r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06054812 cmp/pz r1
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 20); if (k) { goto L_06054854; } }  // 06054814 bf/s 0x06054854 ; mov.l @(20,r14),r1
    c.r[1] += c.r[1];  // 06054818 add r1,r1
    c.r[0] = c.r[14];  // 0605481A mov r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605481C mov.b @(r0,r1),r2
    c.r[11] = 0x7Fu;  // 0605481E mov #127,r11
    c.r[2] &= c.r[11];  // 06054820 and r11,r2
    st8(c.r[0] + c.r[1], c.r[2]);  // 06054822 mov.b r2,@(r0,r1)
    c.r[1] = c.r[13];  // 06054824 mov r13,r1
    c.r[1] += 1;  // 06054826 add #1,r1
    c.r[13] = c.r[1] & 0xFFu; goto L_06054860;  // 06054828 bra 0x06054860 ; extu.b r1,r13
L_06054854:
    c.r[0] = c.r[14];  // 06054854 mov r14,r0
    c.r[1] += c.r[1];  // 06054856 add r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06054858 mov.b @(r0,r1),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060548FAu);  // 0605485A mov.w 0x060548FA,r11
    c.r[2] |= c.r[11];  // 0605485C or r11,r2
    st8(c.r[0] + c.r[1], c.r[2]);  // 0605485E mov.b r2,@(r0,r1)
L_06054860:
    c.r[2] = c.r[10] & 0xFFFFu;  // 06054860 extu.w r10,r2
    c.r[7] = c.r[2];  // 06054862 mov r2,r7
    c.r[7] >>= 8;  // 06054864 shlr8 r7
    c.r[0] = 0x7Fu;  // 06054866 mov #127,r0
    c.r[7] &= c.r[0];  // 06054868 and r0,r7
    c.r[3] = ld32(c.r[14] + 20);  // 0605486A mov.l @(20,r14),r3
    c.r[0] = c.r[14];  // 0605486C mov r14,r0
    c.r[1] = c.r[3];  // 0605486E mov r3,r1
    c.r[1] += 1;  // 06054870 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054872 extu.b r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 06054874 mov.l r1,@(20,r14)
    c.r[3] += c.r[3];  // 06054876 add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06054878 mov.b @(r0,r3),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060548FAu);  // 0605487A mov.w 0x060548FA,r11
    c.r[1] &= c.r[11];  // 0605487C and r11,r1
    c.r[1] |= c.r[7];  // 0605487E or r7,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06054880 mov.b r1,@(r0,r3)
    c.r[1] = c.r[14];  // 06054882 mov r14,r1
    c.r[1] += 1;  // 06054884 add #1,r1
    c.r[0] = c.r[1];  // 06054886 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06054888 mov.b r2,@(r0,r3)
    c.r[1] = ld32(c.r[14] + 16);  // 0605488A mov.l @(16,r14),r1
L_0605488C:
    c.r[10] += 1;  // 0605488C add #1,r10
L_0605488E:
    c.r[1] += 3;  // 0605488E add #3,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06054890 cmp/ge r1,r10
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_0605489A; } }  // 06054892 bt/s 0x0605489A ; mov r13,r1
    SH2_POLL(c); goto L_060546F4;  // 06054896 bra 0x060546F4 ; nop
L_0605489A:
    c.r[11] = ld32(c.r[14] + 20);  // 0605489A mov.l @(20,r14),r11
    c.r[1] <<= 2;  // 0605489C shll2 r1
    c.r[1] <<= 2;  // 0605489E shll2 r1
    c.r[1] |= c.r[11];  // 060548A0 or r11,r1
    c.r[13] = c.r[1] & 0xFFu;  // 060548A2 extu.b r1,r13
L_060548A4:
    c.r[0] = ld32(c.r[14] + 8);  // 060548A4 mov.l @(8,r14),r0
L_060548A6:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060548A6 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x17u; if (k) { goto L_060548E2; } }  // 060548A8 bt/s 0x060548E2 ; mov #23,r0
    c.r[7] = ld32(0x06054900u);  // 060548AC mov.l 0x06054900,r7
    c.r[2] = ld32(c.r[7]);  // 060548AE mov.l @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060548B0 mov.b @r14,r1
    c.r[0] += c.r[14];  // 060548B2 add r14,r0
    st8(c.r[2], c.r[1]);  // 060548B4 mov.b r1,@r2
    c.r[1] = c.r[14];  // 060548B6 mov r14,r1
    c.r[1] += 1;  // 060548B8 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060548BA mov.b @r1+,r3
    c.r[2] += 1;  // 060548BC add #1,r2
    st8(c.r[2], c.r[3]);  // 060548BE mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060548C0 mov.b @r1+,r3
    c.r[2] += 1;  // 060548C2 add #1,r2
    st8(c.r[2], c.r[3]);  // 060548C4 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060548C6 mov.b @r1+,r3
    c.r[2] += 1;  // 060548C8 add #1,r2
    st8(c.r[2], c.r[3]);  // 060548CA mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060548CC mov.b @r1+,r3
    c.r[2] += 1;  // 060548CE add #1,r2
    st8(c.r[2], c.r[3]);  // 060548D0 mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060548D2 mov.b @r1,r1
    c.r[2] += 1;  // 060548D4 add #1,r2
    st8(c.r[2], c.r[1]);  // 060548D6 mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 060548D8 mov.l @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060548FCu);  // 060548DA mov.w 0x060548FC,r2
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060548DC mov.b @r0,r11
    c.r[0] = c.r[1];  // 060548DE mov r1,r0
    st8(c.r[0] + c.r[2], c.r[11]);  // 060548E0 mov.b r11,@(r0,r2)
L_060548E2:
    c.r[14] += 28;  // 060548E2 add #28,r14
    c.r[15] = c.r[14];  // 060548E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060548E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060548E8 mov.l @r15+,r14
    c.r[0] = c.r[13];  // 060548EA mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060548EC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060548EE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060548F0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060548F2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060548F4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060548F6 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
