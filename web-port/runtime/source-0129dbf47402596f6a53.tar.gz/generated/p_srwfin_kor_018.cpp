#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_06042024(SH2Context& c) {
    ran[1049] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042024 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042026 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06042028 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604202A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604202C sts.l pr,@-r15
    c.r[4] = ld32(0x060420C4u);  // 0604202E mov.l 0x060420C4,r4
    c.r[2] = c.r[4];  // 06042030 mov r4,r2
    c.r[2] += 1;  // 06042032 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06042034 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06042036 mov r1,r0
    c.r[0] >>= 2;  // 06042038 shlr2 r0
    c.r[0] >>= 2;  // 0604203A shlr2 r0
    c.r[0] >>= 2;  // 0604203C shlr2 r0
    c.r[0] &= 0x1u;  // 0604203E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042040 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042050; } }  // 06042042 bt/s 0x06042050 ; mov r15,r14
    c.r[4] += 2;  // 06042046 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06042048 mov.w @r4,r4
    c.r[1] = ld32(0x060420C8u);  // 0604204A mov.l 0x060420C8,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_060420A6;  // 0604204C bra 0x060420A6 ; extu.w r4,r4
L_06042050:
    c.r[0] = c.r[1];  // 06042050 mov r1,r0
    c.r[0] |= 0x40u;  // 06042052 or #64,r0
    st8(c.r[2], c.r[0]);  // 06042054 mov.b r0,@r2
    c.r[10] = c.r[4];  // 06042056 mov r4,r10
    c.r[10] += 2;  // 06042058 add #2,r10
    c.r[1] = 0x3u;  // 0604205A mov #3,r1
    st16(c.r[10], c.r[1]);  // 0604205C mov.w r1,@r10
    c.r[9] = c.r[4];  // 0604205E mov r4,r9
    c.r[9] += 4;  // 06042060 add #4,r9
    c.r[1] = 0x20u;  // 06042062 mov #32,r1
    st16(c.r[9], c.r[1]);  // 06042064 mov.w r1,@r9
    c.r[0] &= 0xCFu;  // 06042066 and #207,r0
    st8(c.r[2], c.r[0]);  // 06042068 mov.b r0,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060420BAu);  // 0604206A mov.w 0x060420BA,r0
    c.r[1] = 0x6u;  // 0604206C mov #6,r1
    st16(c.r[0] + c.r[4], c.r[1]);  // 0604206E mov.w r1,@(r0,r4)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060420BCu);  // 06042070 mov.w 0x060420BC,r0
    c.r[1] = 0x0u;  // 06042072 mov #0,r1
    st16(c.r[0] + c.r[4], c.r[1]);  // 06042074 mov.w r1,@(r0,r4)
    c.r[7] = (uint32_t)(int16_t)ld16(0x060420BEu);  // 06042076 mov.w 0x060420BE,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060420C0u);  // 06042078 mov.w 0x060420C0,r0
    c.r[8] = ld32(0x060420CCu);  // 0604207A mov.l 0x060420CC,r8
    c.r[1] = ld32(0x060420D0u);  // 0604207C mov.l 0x060420D0,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0604207E mov.w @(r0,r4),r5
    c.r[6] = 0x2u;  // 06042080 mov #2,r6
    c.r[5] = c.r[5] & 0xFFFFu;  // 06042082 extu.w r5,r5
    c.r[5] <<= 2;  // 06042084 shll2 r5
    c.r[5] <<= 2;  // 06042086 shll2 r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604208Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604208Cu) return; }  // 06042088 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060420D4u);  // 0604208C mov.l 0x060420D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042092u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042092u) return; }  // 0604208E jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060420D8u);  // 06042092 mov.l 0x060420D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042098u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042098u) return; }  // 06042094 jsr @r1 ; mov #3,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06042098 mov.w @r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060420C2u);  // 0604209A mov.w 0x060420C2,r1
    c.r[4] |= c.r[1];  // 0604209C or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604209E mov.w @r10,r1
    c.r[4] |= c.r[1];  // 060420A0 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 060420A2 extu.w r4,r4
    c.r[1] = ld32(0x060420DCu);  // 060420A4 mov.l 0x060420DC,r1
L_060420A6:
    { const uint32_t x = c.r[1]; c.pr = 0x060420AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060420AAu) return; }  // 060420A6 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060420AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060420AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060420AE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060420B0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060420B2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060420B4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060420B6 rts ; mov #1,r0
}

void f_060420E0(SH2Context& c) {
    ran[1050] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060420E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060420E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060420E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060420E6 sts.l pr,@-r15
    c.r[4] = ld32(0x06042150u);  // 060420E8 mov.l 0x06042150,r4
    c.r[3] = c.r[4];  // 060420EA mov r4,r3
    c.r[3] += 1;  // 060420EC add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060420EE mov.b @r3,r2
    c.r[0] = c.r[2];  // 060420F0 mov r2,r0
    c.r[0] >>= 2;  // 060420F2 shlr2 r0
    c.r[0] >>= 2;  // 060420F4 shlr2 r0
    c.r[0] >>= 2;  // 060420F6 shlr2 r0
    c.r[0] &= 0x1u;  // 060420F8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060420FA tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042106; } }  // 060420FC bt/s 0x06042106 ; mov r15,r14
    c.r[4] += 2;  // 06042100 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_0604213A;  // 06042102 bra 0x0604213A ; mov.w @r4,r4
L_06042106:
    c.r[8] = c.r[4];  // 06042106 mov r4,r8
    c.r[8] += 2;  // 06042108 add #2,r8
    c.r[1] = 0x4u;  // 0604210A mov #4,r1
    st16(c.r[8], c.r[1]);  // 0604210C mov.w r1,@r8
    c.r[9] = c.r[4];  // 0604210E mov r4,r9
    c.r[9] += 4;  // 06042110 add #4,r9
    c.r[1] = 0x3u;  // 06042112 mov #3,r1
    st16(c.r[9], c.r[1]);  // 06042114 mov.w r1,@r9
    c.r[0] = c.r[2];  // 06042116 mov r2,r0
    c.r[0] |= 0x40u;  // 06042118 or #64,r0
    st8(c.r[3], c.r[0]);  // 0604211A mov.b r0,@r3
    c.r[1] = ld32(0x06042154u);  // 0604211C mov.l 0x06042154,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042122u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042122u) return; }  // 0604211E jsr @r1 ; mov #6,r4
    c.r[1] = ld32(0x06042158u);  // 06042122 mov.l 0x06042158,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042128u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042128u) return; }  // 06042124 jsr @r1 ; mov #1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042128 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604214Eu);  // 0604212A mov.w 0x0604214E,r1
    c.r[4] |= c.r[1];  // 0604212C or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604212E mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06042130 or r1,r4
    c.r[1] = ld32(0x0604215Cu);  // 06042132 mov.l 0x0604215C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042138u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042138u) return; }  // 06042134 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042138 mov.w @r8,r4
L_0604213A:
    c.r[1] = ld32(0x06042160u);  // 0604213A mov.l 0x06042160,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042140u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042140u) return; }  // 0604213C jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06042140 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042142 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042144 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042146 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042148 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604214A rts ; mov #1,r0
}

void f_06042164(SH2Context& c) {
    ran[1051] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042164 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042166 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042168 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604216A sts.l pr,@-r15
    c.r[4] = ld32(0x060421DCu);  // 0604216C mov.l 0x060421DC,r4
    c.r[3] = c.r[4];  // 0604216E mov r4,r3
    c.r[3] += 1;  // 06042170 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06042172 mov.b @r3,r2
    c.r[0] = c.r[2];  // 06042174 mov r2,r0
    c.r[0] >>= 2;  // 06042176 shlr2 r0
    c.r[0] >>= 2;  // 06042178 shlr2 r0
    c.r[0] >>= 2;  // 0604217A shlr2 r0
    c.r[0] &= 0x1u;  // 0604217C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604217E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604218A; } }  // 06042180 bt/s 0x0604218A ; mov r15,r14
    c.r[4] += 2;  // 06042184 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_060421C6;  // 06042186 bra 0x060421C6 ; mov.w @r4,r4
L_0604218A:
    c.r[8] = c.r[4];  // 0604218A mov r4,r8
    c.r[8] += 2;  // 0604218C add #2,r8
    c.r[1] = 0x1u;  // 0604218E mov #1,r1
    st16(c.r[8], c.r[1]);  // 06042190 mov.w r1,@r8
    c.r[9] = c.r[4];  // 06042192 mov r4,r9
    c.r[9] += 4;  // 06042194 add #4,r9
    c.r[1] = 0x46u;  // 06042196 mov #70,r1
    st16(c.r[9], c.r[1]);  // 06042198 mov.w r1,@r9
    c.r[0] = c.r[2];  // 0604219A mov r2,r0
    c.r[0] |= 0x40u;  // 0604219C or #64,r0
    st8(c.r[3], c.r[0]);  // 0604219E mov.b r0,@r3
    c.r[1] = ld32(0x060421E0u);  // 060421A0 mov.l 0x060421E0,r1
    c.r[5] = 0x6u;  // 060421A2 mov #6,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060421A8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060421A8u) return; }  // 060421A4 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060421E4u);  // 060421A8 mov.l 0x060421E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060421AEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060421AEu) return; }  // 060421AA jsr @r1 ; mov #6,r4
    c.r[1] = ld32(0x060421E8u);  // 060421AE mov.l 0x060421E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060421B4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060421B4u) return; }  // 060421B0 jsr @r1 ; mov #1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060421B4 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060421DAu);  // 060421B6 mov.w 0x060421DA,r1
    c.r[4] |= c.r[1];  // 060421B8 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060421BA mov.w @r9,r1
    c.r[4] |= c.r[1];  // 060421BC or r1,r4
    c.r[1] = ld32(0x060421ECu);  // 060421BE mov.l 0x060421EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060421C4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060421C4u) return; }  // 060421C0 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060421C4 mov.w @r8,r4
L_060421C6:
    c.r[1] = ld32(0x060421F0u);  // 060421C6 mov.l 0x060421F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060421CCu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060421CCu) return; }  // 060421C8 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 060421CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060421CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060421D0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060421D2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060421D4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060421D6 rts ; mov #1,r0
}

void f_060421F4(SH2Context& c) {
    ran[1052] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060421F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060421F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060421F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060421FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060421FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060421FE sts.l pr,@-r15
    c.r[10] = ld32(0x0604227Cu);  // 06042200 mov.l 0x0604227C,r10
    c.r[11] = c.r[10];  // 06042202 mov r10,r11
    c.r[11] += 1;  // 06042204 add #1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06042206 mov.b @r11,r1
    c.r[0] = c.r[1];  // 06042208 mov r1,r0
    c.r[0] >>= 2;  // 0604220A shlr2 r0
    c.r[0] >>= 2;  // 0604220C shlr2 r0
    c.r[0] >>= 2;  // 0604220E shlr2 r0
    c.r[0] &= 0x1u;  // 06042210 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042212 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604222C; } }  // 06042214 bt/s 0x0604222C ; mov r15,r14
    c.r[1] = c.r[10];  // 06042218 mov r10,r1
    c.r[1] += 10;  // 0604221A add #10,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604221C mov.b @r1,r5
    c.r[4] = 0x1u;  // 0604221E mov #1,r4
    c.r[1] = ld32(0x06042280u);  // 06042220 mov.l 0x06042280,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042226u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042226u) return; }  // 06042222 jsr @r1 ; extu.b r5,r5
    c.r[10] += 2;  // 06042226 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]); goto L_06042264;  // 06042228 bra 0x06042264 ; mov.w @r10,r4
L_0604222C:
    c.r[1] = ld32(0x06042284u);  // 0604222C mov.l 0x06042284,r1
    c.r[5] = 0x6u;  // 0604222E mov #6,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06042234u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042234u) return; }  // 06042230 jsr @r1 ; mov #1,r4
    c.r[8] = c.r[10];  // 06042234 mov r10,r8
    c.r[8] += 2;  // 06042236 add #2,r8
    c.r[1] = 0x1u;  // 06042238 mov #1,r1
    st16(c.r[8], c.r[1]);  // 0604223A mov.w r1,@r8
    c.r[9] = c.r[10];  // 0604223C mov r10,r9
    c.r[9] += 4;  // 0604223E add #4,r9
    c.r[1] = 0x46u;  // 06042240 mov #70,r1
    st16(c.r[9], c.r[1]);  // 06042242 mov.w r1,@r9
    c.r[10] += 10;  // 06042244 add #10,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06042246 mov.b @r11,r0
    c.r[1] = ld32(0x06042280u);  // 06042248 mov.l 0x06042280,r1
    c.r[0] |= 0x40u;  // 0604224A or #64,r0
    st8(c.r[11], c.r[0]);  // 0604224C mov.b r0,@r11
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0604224E mov.b @r10,r5
    c.r[4] = 0x1u;  // 06042250 mov #1,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06042256u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042256u) return; }  // 06042252 jsr @r1 ; extu.b r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042256 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06042258 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 0604225A or r1,r4
    c.r[1] = ld32(0x06042288u);  // 0604225C mov.l 0x06042288,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042262u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042262u) return; }  // 0604225E jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042262 mov.w @r8,r4
L_06042264:
    c.r[1] = ld32(0x0604228Cu);  // 06042264 mov.l 0x0604228C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604226Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604226Au) return; }  // 06042266 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 0604226A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604226C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604226E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06042270 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06042272 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042274 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042276 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042278 rts ; mov #1,r0
}

void f_06042290(SH2Context& c) {
    ran[1053] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042290 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042292 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042294 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042296 sts.l pr,@-r15
    c.r[4] = ld32(0x06042300u);  // 06042298 mov.l 0x06042300,r4
    c.r[3] = c.r[4];  // 0604229A mov r4,r3
    c.r[3] += 1;  // 0604229C add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604229E mov.b @r3,r2
    c.r[0] = c.r[2];  // 060422A0 mov r2,r0
    c.r[0] >>= 2;  // 060422A2 shlr2 r0
    c.r[0] >>= 2;  // 060422A4 shlr2 r0
    c.r[0] >>= 2;  // 060422A6 shlr2 r0
    c.r[0] &= 0x1u;  // 060422A8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060422AA tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060422B6; } }  // 060422AC bt/s 0x060422B6 ; mov r15,r14
    c.r[4] += 2;  // 060422B0 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_060422EA;  // 060422B2 bra 0x060422EA ; mov.w @r4,r4
L_060422B6:
    c.r[8] = c.r[4];  // 060422B6 mov r4,r8
    c.r[8] += 2;  // 060422B8 add #2,r8
    c.r[1] = 0x4u;  // 060422BA mov #4,r1
    st16(c.r[8], c.r[1]);  // 060422BC mov.w r1,@r8
    c.r[9] = c.r[4];  // 060422BE mov r4,r9
    c.r[9] += 4;  // 060422C0 add #4,r9
    c.r[1] = 0x43u;  // 060422C2 mov #67,r1
    st16(c.r[9], c.r[1]);  // 060422C4 mov.w r1,@r9
    c.r[0] = c.r[2];  // 060422C6 mov r2,r0
    c.r[0] |= 0x40u;  // 060422C8 or #64,r0
    st8(c.r[3], c.r[0]);  // 060422CA mov.b r0,@r3
    c.r[1] = ld32(0x06042304u);  // 060422CC mov.l 0x06042304,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060422D2u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060422D2u) return; }  // 060422CE jsr @r1 ; mov #6,r4
    c.r[1] = ld32(0x06042308u);  // 060422D2 mov.l 0x06042308,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060422D8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060422D8u) return; }  // 060422D4 jsr @r1 ; mov #1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060422D8 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060422FEu);  // 060422DA mov.w 0x060422FE,r1
    c.r[4] |= c.r[1];  // 060422DC or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060422DE mov.w @r9,r1
    c.r[4] |= c.r[1];  // 060422E0 or r1,r4
    c.r[1] = ld32(0x0604230Cu);  // 060422E2 mov.l 0x0604230C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060422E8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060422E8u) return; }  // 060422E4 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060422E8 mov.w @r8,r4
L_060422EA:
    c.r[1] = ld32(0x06042310u);  // 060422EA mov.l 0x06042310,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060422F0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060422F0u) return; }  // 060422EC jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 060422F0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060422F2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060422F4 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060422F6 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060422F8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060422FA rts ; mov #1,r0
}

void f_06042314(SH2Context& c) {
    ran[1054] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042314 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042316 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042318 sts.l pr,@-r15
    c.r[4] = ld32(0x06042368u);  // 0604231A mov.l 0x06042368,r4
    c.r[3] = c.r[4];  // 0604231C mov r4,r3
    c.r[3] += 1;  // 0604231E add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06042320 mov.b @r3,r2
    c.r[0] = c.r[2];  // 06042322 mov r2,r0
    c.r[0] >>= 2;  // 06042324 shlr2 r0
    c.r[0] >>= 2;  // 06042326 shlr2 r0
    c.r[0] >>= 2;  // 06042328 shlr2 r0
    c.r[0] &= 0x1u;  // 0604232A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604232C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042338; } }  // 0604232E bt/s 0x06042338 ; mov r15,r14
    c.r[4] += 2;  // 06042332 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_06042354;  // 06042334 bra 0x06042354 ; mov.w @r4,r4
L_06042338:
    c.r[8] = c.r[4];  // 06042338 mov r4,r8
    c.r[8] += 2;  // 0604233A add #2,r8
    c.r[1] = 0x4u;  // 0604233C mov #4,r1
    st16(c.r[8], c.r[1]);  // 0604233E mov.w r1,@r8
    c.r[4] += 4;  // 06042340 add #4,r4
    c.r[1] = 0x3u;  // 06042342 mov #3,r1
    st16(c.r[4], c.r[1]);  // 06042344 mov.w r1,@r4
    c.r[0] = c.r[2];  // 06042346 mov r2,r0
    c.r[0] |= 0x40u;  // 06042348 or #64,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x06042366u);  // 0604234A mov.w 0x06042366,r4
    c.r[1] = ld32(0x0604236Cu);  // 0604234C mov.l 0x0604236C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042352u; st8(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042352u) return; }  // 0604234E jsr @r1 ; mov.b r0,@r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042352 mov.w @r8,r4
L_06042354:
    c.r[1] = ld32(0x06042370u);  // 06042354 mov.l 0x06042370,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604235Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604235Au) return; }  // 06042356 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 0604235A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604235C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604235E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042360 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042362 rts ; mov #1,r0
}

void f_06042374(SH2Context& c) {
    ran[1055] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042374 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042376 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042378 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604237A sts.l pr,@-r15
    c.r[4] = ld32(0x060423E4u);  // 0604237C mov.l 0x060423E4,r4
    c.r[3] = c.r[4];  // 0604237E mov r4,r3
    c.r[3] += 1;  // 06042380 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06042382 mov.b @r3,r2
    c.r[0] = c.r[2];  // 06042384 mov r2,r0
    c.r[0] >>= 2;  // 06042386 shlr2 r0
    c.r[0] >>= 2;  // 06042388 shlr2 r0
    c.r[0] >>= 2;  // 0604238A shlr2 r0
    c.r[0] &= 0x1u;  // 0604238C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604238E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604239A; } }  // 06042390 bt/s 0x0604239A ; mov r15,r14
    c.r[4] += 2;  // 06042394 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_060423CE;  // 06042396 bra 0x060423CE ; mov.w @r4,r4
L_0604239A:
    c.r[8] = c.r[4];  // 0604239A mov r4,r8
    c.r[8] += 2;  // 0604239C add #2,r8
    c.r[1] = 0x2u;  // 0604239E mov #2,r1
    st16(c.r[8], c.r[1]);  // 060423A0 mov.w r1,@r8
    c.r[9] = c.r[4];  // 060423A2 mov r4,r9
    c.r[9] += 4;  // 060423A4 add #4,r9
    c.r[1] = 0x50u;  // 060423A6 mov #80,r1
    st16(c.r[9], c.r[1]);  // 060423A8 mov.w r1,@r9
    c.r[0] = c.r[2];  // 060423AA mov r2,r0
    c.r[0] |= 0x40u;  // 060423AC or #64,r0
    st8(c.r[3], c.r[0]);  // 060423AE mov.b r0,@r3
    c.r[1] = ld32(0x060423E8u);  // 060423B0 mov.l 0x060423E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060423B6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060423B6u) return; }  // 060423B2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060423ECu);  // 060423B6 mov.l 0x060423EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060423BCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060423BCu) return; }  // 060423B8 jsr @r1 ; mov #1,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060423BC mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060423E2u);  // 060423BE mov.w 0x060423E2,r1
    c.r[4] |= c.r[1];  // 060423C0 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060423C2 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 060423C4 or r1,r4
    c.r[1] = ld32(0x060423F0u);  // 060423C6 mov.l 0x060423F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060423CCu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060423CCu) return; }  // 060423C8 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060423CC mov.w @r8,r4
L_060423CE:
    c.r[1] = ld32(0x060423F4u);  // 060423CE mov.l 0x060423F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060423D4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060423D4u) return; }  // 060423D0 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 060423D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060423D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060423D8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060423DA mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060423DC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060423DE rts ; mov #1,r0
}

void f_060423F8(SH2Context& c) {
    ran[1056] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060423F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060423FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060423FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060423FE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042400 sts.l pr,@-r15
    c.r[9] = ld32(0x06042480u);  // 06042402 mov.l 0x06042480,r9
    c.r[3] = c.r[9];  // 06042404 mov r9,r3
    c.r[3] += 1;  // 06042406 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06042408 mov.b @r3,r2
    c.r[0] = c.r[2];  // 0604240A mov r2,r0
    c.r[0] >>= 2;  // 0604240C shlr2 r0
    c.r[0] >>= 2;  // 0604240E shlr2 r0
    c.r[0] >>= 2;  // 06042410 shlr2 r0
    c.r[0] &= 0x1u;  // 06042412 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042414 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604242E; } }  // 06042416 bt/s 0x0604242E ; mov r15,r14
    c.r[1] = c.r[9];  // 0604241A mov r9,r1
    c.r[1] += 11;  // 0604241C add #11,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604241E mov.b @r1,r5
    c.r[4] = 0x0u;  // 06042420 mov #0,r4
    c.r[1] = ld32(0x06042484u);  // 06042422 mov.l 0x06042484,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042428u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042428u) return; }  // 06042424 jsr @r1 ; extu.b r5,r5
    c.r[9] += 2;  // 06042428 add #2,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); goto L_0604246A;  // 0604242A bra 0x0604246A ; mov.w @r9,r4
L_0604242E:
    c.r[8] = c.r[9];  // 0604242E mov r9,r8
    c.r[8] += 2;  // 06042430 add #2,r8
    c.r[1] = 0x2u;  // 06042432 mov #2,r1
    st16(c.r[8], c.r[1]);  // 06042434 mov.w r1,@r8
    c.r[10] = c.r[9];  // 06042436 mov r9,r10
    c.r[10] += 4;  // 06042438 add #4,r10
    c.r[1] = 0x50u;  // 0604243A mov #80,r1
    st16(c.r[10], c.r[1]);  // 0604243C mov.w r1,@r10
    c.r[0] = c.r[2];  // 0604243E mov r2,r0
    c.r[0] |= 0x40u;  // 06042440 or #64,r0
    st8(c.r[3], c.r[0]);  // 06042442 mov.b r0,@r3
    c.r[9] += 11;  // 06042444 add #11,r9
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06042446 mov.b @r9,r5
    c.r[4] = 0x0u;  // 06042448 mov #0,r4
    c.r[9] = ld32(0x06042484u);  // 0604244A mov.l 0x06042484,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06042450u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042450u) return; }  // 0604244C jsr @r9 ; extu.b r5,r5
    c.r[5] = 0xAu;  // 06042450 mov #10,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042452 mov.w @r8,r0
    c.r[4] = 0x2u;  // 06042454 mov #2,r4
    c.r[0] |= 0x8u;  // 06042456 or #8,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0604245Cu; st16(c.r[8], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604245Cu) return; }  // 06042458 jsr @r9 ; mov.w r0,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604245C mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604245E mov.w @r10,r1
    c.r[4] |= c.r[1];  // 06042460 or r1,r4
    c.r[1] = ld32(0x06042488u);  // 06042462 mov.l 0x06042488,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042468u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042468u) return; }  // 06042464 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042468 mov.w @r8,r4
L_0604246A:
    c.r[1] = ld32(0x0604248Cu);  // 0604246A mov.l 0x0604248C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042470u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042470u) return; }  // 0604246C jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06042470 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042472 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042474 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06042476 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042478 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0604247A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604247C rts ; mov #1,r0
}

void f_06042490(SH2Context& c) {
    ran[1057] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042490 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042492 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042494 sts.l pr,@-r15
    c.r[8] = ld32(0x060424F8u);  // 06042496 mov.l 0x060424F8,r8
    c.r[2] = c.r[8];  // 06042498 mov r8,r2
    c.r[2] += 1;  // 0604249A add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604249C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0604249E mov r1,r0
    c.r[0] >>= 2;  // 060424A0 shlr2 r0
    c.r[0] >>= 2;  // 060424A2 shlr2 r0
    c.r[0] >>= 2;  // 060424A4 shlr2 r0
    c.r[0] &= 0x1u;  // 060424A6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060424A8 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060424B2; } }  // 060424AA bt/s 0x060424B2 ; mov r15,r14
    c.r[8] += 2; goto L_060424E0;  // 060424AE bra 0x060424E0 ; add #2,r8
L_060424B2:
    c.r[0] = c.r[1];  // 060424B2 mov r1,r0
    c.r[0] |= 0x40u;  // 060424B4 or #64,r0
    st8(c.r[2], c.r[0]);  // 060424B6 mov.b r0,@r2
    c.r[1] = ld32(0x060424FCu);  // 060424B8 mov.l 0x060424FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060424BEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060424BEu) return; }  // 060424BA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06042500u);  // 060424BE mov.l 0x06042500,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060424C4u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060424C4u) return; }  // 060424C0 jsr @r1 ; mov #2,r4
    c.r[8] += 2;  // 060424C4 add #2,r8
    c.r[1] = ld32(0x06042504u);  // 060424C6 mov.l 0x06042504,r1
    c.r[5] = 0xAu;  // 060424C8 mov #10,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060424CA mov.w @r8,r0
    c.r[4] = 0x2u;  // 060424CC mov #2,r4
    c.r[0] |= 0x8u;  // 060424CE or #8,r0
    { const uint32_t x = c.r[1]; c.pr = 0x060424D4u; st16(c.r[8], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060424D4u) return; }  // 060424D0 jsr @r1 ; mov.w r0,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060424D4 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060424F4u);  // 060424D6 mov.w 0x060424F4,r1
    c.r[4] |= c.r[1];  // 060424D8 or r1,r4
    c.r[1] = ld32(0x06042508u);  // 060424DA mov.l 0x06042508,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060424E0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060424E0u) return; }  // 060424DC jsr @r1 ; extu.w r4,r4
L_060424E0:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060424E0 mov.w @r8,r4
    c.r[1] = ld32(0x0604250Cu);  // 060424E2 mov.l 0x0604250C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060424E8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060424E8u) return; }  // 060424E4 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 060424E8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060424EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060424EC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060424EE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060424F0 rts ; mov #1,r0
}

void f_06042510(SH2Context& c) {
    ran[1058] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042510 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042512 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042514 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042516 sts.l pr,@-r15
    c.r[9] = ld32(0x060425B0u);  // 06042518 mov.l 0x060425B0,r9
    c.r[2] = c.r[9];  // 0604251A mov r9,r2
    c.r[2] += 1;  // 0604251C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604251E mov.b @r2,r1
    c.r[0] = c.r[1];  // 06042520 mov r1,r0
    c.r[0] >>= 2;  // 06042522 shlr2 r0
    c.r[0] >>= 2;  // 06042524 shlr2 r0
    c.r[0] >>= 2;  // 06042526 shlr2 r0
    c.r[0] &= 0x1u;  // 06042528 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604252A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042556; } }  // 0604252C bt/s 0x06042556 ; mov r15,r14
    c.r[1] = c.r[9];  // 06042530 mov r9,r1
    c.r[1] += 9;  // 06042532 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042534 mov.b @r1,r2
    c.r[3] = ld32(0x060425B4u);  // 06042536 mov.l 0x060425B4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06042538 extu.b r2,r2
    c.r[2] <<= 8;  // 0604253A shll8 r2
    c.r[1] = c.r[9];  // 0604253C mov r9,r1
    c.r[1] += 8;  // 0604253E add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042540 mov.b @r1,r1
    c.r[9] += 2;  // 06042542 add #2,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06042544 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06042546 or r1,r2
    st16(c.r[3], c.r[2]);  // 06042548 mov.w r2,@r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604254A mov.w @r9,r4
    c.r[1] = ld32(0x060425B8u);  // 0604254C mov.l 0x060425B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042552u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042552u) return; }  // 0604254E jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14]; goto L_060425A4;  // 06042552 bra 0x060425A4 ; mov r14,r15
L_06042556:
    c.r[0] = c.r[1];  // 06042556 mov r1,r0
    c.r[0] |= 0x40u;  // 06042558 or #64,r0
    st8(c.r[2], c.r[0]);  // 0604255A mov.b r0,@r2
    c.r[1] = ld32(0x060425BCu);  // 0604255C mov.l 0x060425BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042562u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042562u) return; }  // 0604255E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060425C0u);  // 06042562 mov.l 0x060425C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042568u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042568u) return; }  // 06042564 jsr @r1 ; mov #3,r4
    c.r[8] = c.r[9];  // 06042568 mov r9,r8
    c.r[8] += 2;  // 0604256A add #2,r8
    c.r[1] = ld32(0x060425C4u);  // 0604256C mov.l 0x060425C4,r1
    c.r[5] = 0xAu;  // 0604256E mov #10,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042570 mov.w @r8,r0
    c.r[4] = 0x2u;  // 06042572 mov #2,r4
    c.r[0] |= 0x8u;  // 06042574 or #8,r0
    { const uint32_t x = c.r[1]; c.pr = 0x0604257Au; st16(c.r[8], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604257Au) return; }  // 06042576 jsr @r1 ; mov.w r0,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604257A mov.w @r8,r0
    c.r[1] = ld32(0x060425C8u);  // 0604257C mov.l 0x060425C8,r1
    c.r[0] |= 0x10u;  // 0604257E or #16,r0
    { const uint32_t x = c.r[1]; c.pr = 0x06042584u; c.r[4] = c.r[0] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042584u) return; }  // 06042580 jsr @r1 ; extu.w r0,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042584 mov.w @r8,r4
    c.r[1] = ld32(0x060425B8u);  // 06042586 mov.l 0x060425B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604258Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604258Cu) return; }  // 06042588 jsr @r1 ; extu.w r4,r4
    c.r[3] = ld32(0x060425B4u);  // 0604258C mov.l 0x060425B4,r3
    c.r[1] = c.r[9];  // 0604258E mov r9,r1
    c.r[1] += 9;  // 06042590 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042592 mov.b @r1,r2
    c.r[9] += 8;  // 06042594 add #8,r9
    c.r[2] = c.r[2] & 0xFFu;  // 06042596 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06042598 mov.b @r9,r1
    c.r[2] <<= 8;  // 0604259A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604259C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604259E or r1,r2
    st16(c.r[3], c.r[2]);  // 060425A0 mov.w r2,@r3
    c.r[15] = c.r[14];  // 060425A2 mov r14,r15
L_060425A4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060425A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060425A6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060425A8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060425AA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060425AC rts ; mov #1,r0
}

void f_060425CC(SH2Context& c) {
    ran[1059] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060425CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060425CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060425D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060425D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060425D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060425D6 sts.l pr,@-r15
    c.r[10] = ld32(0x0604267Cu);  // 060425D8 mov.l 0x0604267C,r10
    c.r[2] = c.r[10];  // 060425DA mov r10,r2
    c.r[2] += 1;  // 060425DC add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060425DE mov.b @r2,r1
    c.r[0] = c.r[1];  // 060425E0 mov r1,r0
    c.r[0] >>= 2;  // 060425E2 shlr2 r0
    c.r[0] >>= 2;  // 060425E4 shlr2 r0
    c.r[0] >>= 2;  // 060425E6 shlr2 r0
    c.r[0] &= 0x1u;  // 060425E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060425EA tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060425FA; } }  // 060425EC bt/s 0x060425FA ; mov r15,r14
    c.r[10] += 2;  // 060425F0 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060425F2 mov.w @r10,r4
    c.r[1] = ld32(0x06042680u);  // 060425F4 mov.l 0x06042680,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06042656;  // 060425F6 bra 0x06042656 ; extu.w r4,r4
L_060425FA:
    c.r[3] = 0x40u;  // 060425FA mov #64,r3
    c.r[3] |= c.r[1];  // 060425FC or r1,r3
    st8(c.r[2], c.r[3]);  // 060425FE mov.b r3,@r2
    c.r[9] = c.r[10];  // 06042600 mov r10,r9
    c.r[9] += 2;  // 06042602 add #2,r9
    c.r[1] = 0x10u;  // 06042604 mov #16,r1
    st16(c.r[9], c.r[1]);  // 06042606 mov.w r1,@r9
    c.r[8] = c.r[10];  // 06042608 mov r10,r8
    c.r[8] += 4;  // 0604260A add #4,r8
    c.r[1] = 0x20u;  // 0604260C mov #32,r1
    st16(c.r[8], c.r[1]);  // 0604260E mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604266Cu);  // 06042610 mov.w 0x0604266C,r0
    c.r[3] &= c.r[0];  // 06042612 and r0,r3
    st8(c.r[2], c.r[3]);  // 06042614 mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604266Eu);  // 06042616 mov.w 0x0604266E,r2
    c.r[1] = 0x6u;  // 06042618 mov #6,r1
    c.r[0] = c.r[10];  // 0604261A mov r10,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604261C mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042670u);  // 0604261E mov.w 0x06042670,r2
    c.r[1] = 0x0u;  // 06042620 mov #0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06042622 mov.w r1,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06042672u);  // 06042624 mov.w 0x06042672,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042674u);  // 06042626 mov.w 0x06042674,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06042676u);  // 06042628 mov.w 0x06042676,r11
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604262A mov.w @(r0,r1),r5
    c.r[6] = 0x2u;  // 0604262C mov #2,r6
    c.r[4] = ld32(c.r[0] + c.r[11]);  // 0604262E mov.l @(r0,r11),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06042630 extu.w r5,r5
    c.r[5] <<= 2;  // 06042632 shll2 r5
    c.r[1] = ld32(0x06042684u);  // 06042634 mov.l 0x06042684,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604263Au; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604263Au) return; }  // 06042636 jsr @r1 ; shll2 r5
    c.r[0] = c.r[10];  // 0604263A mov r10,r0
    c.r[1] = ld32(0x06042688u);  // 0604263C mov.l 0x06042688,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042642u; c.r[4] = ld32(c.r[0] + c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042642u) return; }  // 0604263E jsr @r1 ; mov.l @(r0,r11),r4
    c.r[1] = ld32(0x0604268Cu);  // 06042642 mov.l 0x0604268C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042648u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042648u) return; }  // 06042644 jsr @r1 ; mov #16,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042648 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042678u);  // 0604264A mov.w 0x06042678,r1
    c.r[4] |= c.r[1];  // 0604264C or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604264E mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06042650 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 06042652 extu.w r4,r4
    c.r[1] = ld32(0x06042690u);  // 06042654 mov.l 0x06042690,r1
L_06042656:
    { const uint32_t x = c.r[1]; c.pr = 0x0604265Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604265Au) return; }  // 06042656 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0604265A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604265C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604265E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06042660 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06042662 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042664 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042666 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042668 rts ; mov #1,r0
}

void f_06042694(SH2Context& c) {
    ran[1060] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042694 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042696 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06042698 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604269A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604269C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604269E sts.l pr,@-r15
    c.r[10] = ld32(0x06042748u);  // 060426A0 mov.l 0x06042748,r10
    c.r[2] = c.r[10];  // 060426A2 mov r10,r2
    c.r[2] += 1;  // 060426A4 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060426A6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060426A8 mov r1,r0
    c.r[0] >>= 2;  // 060426AA shlr2 r0
    c.r[0] >>= 2;  // 060426AC shlr2 r0
    c.r[0] >>= 2;  // 060426AE shlr2 r0
    c.r[0] &= 0x1u;  // 060426B0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060426B2 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060426C2; } }  // 060426B4 bt/s 0x060426C2 ; mov r15,r14
    c.r[10] += 2;  // 060426B8 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060426BA mov.w @r10,r4
    c.r[1] = ld32(0x0604274Cu);  // 060426BC mov.l 0x0604274C,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06042722;  // 060426BE bra 0x06042722 ; extu.w r4,r4
L_060426C2:
    c.r[3] = 0x40u;  // 060426C2 mov #64,r3
    c.r[3] |= c.r[1];  // 060426C4 or r1,r3
    st8(c.r[2], c.r[3]);  // 060426C6 mov.b r3,@r2
    c.r[9] = c.r[10];  // 060426C8 mov r10,r9
    c.r[9] += 2;  // 060426CA add #2,r9
    c.r[1] = 0x10u;  // 060426CC mov #16,r1
    st16(c.r[9], c.r[1]);  // 060426CE mov.w r1,@r9
    c.r[8] = c.r[10];  // 060426D0 mov r10,r8
    c.r[8] += 4;  // 060426D2 add #4,r8
    c.r[1] = 0x20u;  // 060426D4 mov #32,r1
    st16(c.r[8], c.r[1]);  // 060426D6 mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042738u);  // 060426D8 mov.w 0x06042738,r0
    c.r[3] &= c.r[0];  // 060426DA and r0,r3
    c.r[0] = 0x20u;  // 060426DC mov #32,r0
    c.r[3] |= c.r[0];  // 060426DE or r0,r3
    st8(c.r[2], c.r[3]);  // 060426E0 mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604273Au);  // 060426E2 mov.w 0x0604273A,r2
    c.r[1] = 0x6u;  // 060426E4 mov #6,r1
    c.r[0] = c.r[10];  // 060426E6 mov r10,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 060426E8 mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604273Cu);  // 060426EA mov.w 0x0604273C,r2
    c.r[1] = 0x0u;  // 060426EC mov #0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 060426EE mov.w r1,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604273Eu);  // 060426F0 mov.w 0x0604273E,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042740u);  // 060426F2 mov.w 0x06042740,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06042742u);  // 060426F4 mov.w 0x06042742,r11
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060426F6 mov.w @(r0,r1),r5
    c.r[6] = 0x2u;  // 060426F8 mov #2,r6
    c.r[4] = ld32(c.r[0] + c.r[11]);  // 060426FA mov.l @(r0,r11),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 060426FC extu.w r5,r5
    c.r[5] <<= 2;  // 060426FE shll2 r5
    c.r[1] = ld32(0x06042750u);  // 06042700 mov.l 0x06042750,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042706u; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042706u) return; }  // 06042702 jsr @r1 ; shll2 r5
    c.r[0] = c.r[10];  // 06042706 mov r10,r0
    c.r[1] = ld32(0x06042754u);  // 06042708 mov.l 0x06042754,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604270Eu; c.r[4] = ld32(c.r[0] + c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604270Eu) return; }  // 0604270A jsr @r1 ; mov.l @(r0,r11),r4
    c.r[1] = ld32(0x06042758u);  // 0604270E mov.l 0x06042758,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042714u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042714u) return; }  // 06042710 jsr @r1 ; mov #16,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042714 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042744u);  // 06042716 mov.w 0x06042744,r1
    c.r[4] |= c.r[1];  // 06042718 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604271A mov.w @r9,r1
    c.r[4] |= c.r[1];  // 0604271C or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 0604271E extu.w r4,r4
    c.r[1] = ld32(0x0604275Cu);  // 06042720 mov.l 0x0604275C,r1
L_06042722:
    { const uint32_t x = c.r[1]; c.pr = 0x06042726u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042726u) return; }  // 06042722 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06042726 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042728 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604272A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604272C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604272E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042730 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042732 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042734 rts ; mov #1,r0
}

void f_06042760(SH2Context& c) {
    ran[1061] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042760 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042762 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06042764 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06042766 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042768 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604276A sts.l pr,@-r15
    c.r[10] = ld32(0x06042810u);  // 0604276C mov.l 0x06042810,r10
    c.r[2] = c.r[10];  // 0604276E mov r10,r2
    c.r[2] += 1;  // 06042770 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06042772 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06042774 mov r1,r0
    c.r[0] >>= 2;  // 06042776 shlr2 r0
    c.r[0] >>= 2;  // 06042778 shlr2 r0
    c.r[0] >>= 2;  // 0604277A shlr2 r0
    c.r[0] &= 0x1u;  // 0604277C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604277E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604278E; } }  // 06042780 bt/s 0x0604278E ; mov r15,r14
    c.r[10] += 2;  // 06042784 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042786 mov.w @r10,r4
    c.r[1] = ld32(0x06042814u);  // 06042788 mov.l 0x06042814,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_060427EA;  // 0604278A bra 0x060427EA ; extu.w r4,r4
L_0604278E:
    c.r[3] = 0x40u;  // 0604278E mov #64,r3
    c.r[3] |= c.r[1];  // 06042790 or r1,r3
    st8(c.r[2], c.r[3]);  // 06042792 mov.b r3,@r2
    c.r[9] = c.r[10];  // 06042794 mov r10,r9
    c.r[9] += 2;  // 06042796 add #2,r9
    c.r[1] = 0x2u;  // 06042798 mov #2,r1
    st16(c.r[9], c.r[1]);  // 0604279A mov.w r1,@r9
    c.r[8] = c.r[10];  // 0604279C mov r10,r8
    c.r[8] += 4;  // 0604279E add #4,r8
    c.r[1] = 0x20u;  // 060427A0 mov #32,r1
    st16(c.r[8], c.r[1]);  // 060427A2 mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042800u);  // 060427A4 mov.w 0x06042800,r0
    c.r[3] &= c.r[0];  // 060427A6 and r0,r3
    st8(c.r[2], c.r[3]);  // 060427A8 mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042802u);  // 060427AA mov.w 0x06042802,r2
    c.r[1] = 0x6u;  // 060427AC mov #6,r1
    c.r[0] = c.r[10];  // 060427AE mov r10,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 060427B0 mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042804u);  // 060427B2 mov.w 0x06042804,r2
    c.r[1] = 0x0u;  // 060427B4 mov #0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 060427B6 mov.w r1,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06042806u);  // 060427B8 mov.w 0x06042806,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042808u);  // 060427BA mov.w 0x06042808,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604280Au);  // 060427BC mov.w 0x0604280A,r11
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060427BE mov.w @(r0,r1),r5
    c.r[6] = 0x2u;  // 060427C0 mov #2,r6
    c.r[4] = ld32(c.r[0] + c.r[11]);  // 060427C2 mov.l @(r0,r11),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 060427C4 extu.w r5,r5
    c.r[5] <<= 2;  // 060427C6 shll2 r5
    c.r[1] = ld32(0x06042818u);  // 060427C8 mov.l 0x06042818,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060427CEu; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060427CEu) return; }  // 060427CA jsr @r1 ; shll2 r5
    c.r[0] = c.r[10];  // 060427CE mov r10,r0
    c.r[1] = ld32(0x0604281Cu);  // 060427D0 mov.l 0x0604281C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060427D6u; c.r[4] = ld32(c.r[0] + c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060427D6u) return; }  // 060427D2 jsr @r1 ; mov.l @(r0,r11),r4
    c.r[1] = ld32(0x06042820u);  // 060427D6 mov.l 0x06042820,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060427DCu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060427DCu) return; }  // 060427D8 jsr @r1 ; mov #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060427DC mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604280Cu);  // 060427DE mov.w 0x0604280C,r1
    c.r[4] |= c.r[1];  // 060427E0 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060427E2 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 060427E4 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 060427E6 extu.w r4,r4
    c.r[1] = ld32(0x06042824u);  // 060427E8 mov.l 0x06042824,r1
L_060427EA:
    { const uint32_t x = c.r[1]; c.pr = 0x060427EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060427EEu) return; }  // 060427EA jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060427EE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060427F0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060427F2 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060427F4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060427F6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060427F8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060427FA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060427FC rts ; mov #1,r0
}

void f_06042828(SH2Context& c) {
    ran[1062] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042828 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604282A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604282C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604282E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042830 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042832 sts.l pr,@-r15
    c.r[10] = ld32(0x060428DCu);  // 06042834 mov.l 0x060428DC,r10
    c.r[2] = c.r[10];  // 06042836 mov r10,r2
    c.r[2] += 1;  // 06042838 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604283A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0604283C mov r1,r0
    c.r[0] >>= 2;  // 0604283E shlr2 r0
    c.r[0] >>= 2;  // 06042840 shlr2 r0
    c.r[0] >>= 2;  // 06042842 shlr2 r0
    c.r[0] &= 0x1u;  // 06042844 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042846 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042856; } }  // 06042848 bt/s 0x06042856 ; mov r15,r14
    c.r[10] += 2;  // 0604284C add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604284E mov.w @r10,r4
    c.r[1] = ld32(0x060428E0u);  // 06042850 mov.l 0x060428E0,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_060428B6;  // 06042852 bra 0x060428B6 ; extu.w r4,r4
L_06042856:
    c.r[3] = 0x40u;  // 06042856 mov #64,r3
    c.r[3] |= c.r[1];  // 06042858 or r1,r3
    st8(c.r[2], c.r[3]);  // 0604285A mov.b r3,@r2
    c.r[9] = c.r[10];  // 0604285C mov r10,r9
    c.r[9] += 2;  // 0604285E add #2,r9
    c.r[1] = 0x2u;  // 06042860 mov #2,r1
    st16(c.r[9], c.r[1]);  // 06042862 mov.w r1,@r9
    c.r[8] = c.r[10];  // 06042864 mov r10,r8
    c.r[8] += 4;  // 06042866 add #4,r8
    c.r[1] = 0x20u;  // 06042868 mov #32,r1
    st16(c.r[8], c.r[1]);  // 0604286A mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x060428CCu);  // 0604286C mov.w 0x060428CC,r0
    c.r[3] &= c.r[0];  // 0604286E and r0,r3
    c.r[0] = 0x20u;  // 06042870 mov #32,r0
    c.r[3] |= c.r[0];  // 06042872 or r0,r3
    st8(c.r[2], c.r[3]);  // 06042874 mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x060428CEu);  // 06042876 mov.w 0x060428CE,r2
    c.r[1] = 0x6u;  // 06042878 mov #6,r1
    c.r[0] = c.r[10];  // 0604287A mov r10,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0604287C mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x060428D0u);  // 0604287E mov.w 0x060428D0,r2
    c.r[1] = 0x0u;  // 06042880 mov #0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06042882 mov.w r1,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x060428D2u);  // 06042884 mov.w 0x060428D2,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x060428D4u);  // 06042886 mov.w 0x060428D4,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060428D6u);  // 06042888 mov.w 0x060428D6,r11
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604288A mov.w @(r0,r1),r5
    c.r[6] = 0x2u;  // 0604288C mov #2,r6
    c.r[4] = ld32(c.r[0] + c.r[11]);  // 0604288E mov.l @(r0,r11),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06042890 extu.w r5,r5
    c.r[5] <<= 2;  // 06042892 shll2 r5
    c.r[1] = ld32(0x060428E4u);  // 06042894 mov.l 0x060428E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604289Au; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604289Au) return; }  // 06042896 jsr @r1 ; shll2 r5
    c.r[0] = c.r[10];  // 0604289A mov r10,r0
    c.r[1] = ld32(0x060428E8u);  // 0604289C mov.l 0x060428E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060428A2u; c.r[4] = ld32(c.r[0] + c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060428A2u) return; }  // 0604289E jsr @r1 ; mov.l @(r0,r11),r4
    c.r[1] = ld32(0x060428ECu);  // 060428A2 mov.l 0x060428EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060428A8u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060428A8u) return; }  // 060428A4 jsr @r1 ; mov #16,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060428A8 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060428D8u);  // 060428AA mov.w 0x060428D8,r1
    c.r[4] |= c.r[1];  // 060428AC or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060428AE mov.w @r9,r1
    c.r[4] |= c.r[1];  // 060428B0 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 060428B2 extu.w r4,r4
    c.r[1] = ld32(0x060428F0u);  // 060428B4 mov.l 0x060428F0,r1
L_060428B6:
    { const uint32_t x = c.r[1]; c.pr = 0x060428BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060428BAu) return; }  // 060428B6 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060428BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060428BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060428BE mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060428C0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060428C2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060428C4 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060428C6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060428C8 rts ; mov #1,r0
}

void f_060428F4(SH2Context& c) {
    ran[1063] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060428F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060428F6 sts.l pr,@-r15
    c.r[4] = ld32(0x06042958u);  // 060428F8 mov.l 0x06042958,r4
    c.r[3] = c.r[4];  // 060428FA mov r4,r3
    c.r[3] += 1;  // 060428FC add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060428FE mov.b @r3,r1
    c.r[0] = c.r[1];  // 06042900 mov r1,r0
    c.r[0] >>= 2;  // 06042902 shlr2 r0
    c.r[0] >>= 2;  // 06042904 shlr2 r0
    c.r[0] >>= 2;  // 06042906 shlr2 r0
    c.r[0] &= 0x1u;  // 06042908 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604290A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604291A; } }  // 0604290C bt/s 0x0604291A ; mov r15,r14
    c.r[4] += 2;  // 06042910 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06042912 mov.w @r4,r4
    c.r[1] = ld32(0x0604295Cu);  // 06042914 mov.l 0x0604295C,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06042942;  // 06042916 bra 0x06042942 ; extu.w r4,r4
L_0604291A:
    c.r[0] = c.r[1];  // 0604291A mov r1,r0
    c.r[0] |= 0x40u;  // 0604291C or #64,r0
    st8(c.r[3], c.r[0]);  // 0604291E mov.b r0,@r3
    c.r[2] = c.r[4];  // 06042920 mov r4,r2
    c.r[2] += 2;  // 06042922 add #2,r2
    c.r[1] = 0x2u;  // 06042924 mov #2,r1
    st16(c.r[2], c.r[1]);  // 06042926 mov.w r1,@r2
    c.r[2] = c.r[4];  // 06042928 mov r4,r2
    c.r[2] += 4;  // 0604292A add #4,r2
    c.r[1] = 0x10u;  // 0604292C mov #16,r1
    st16(c.r[2], c.r[1]);  // 0604292E mov.w r1,@r2
    c.r[0] &= 0xCFu;  // 06042930 and #207,r0
    st8(c.r[3], c.r[0]);  // 06042932 mov.b r0,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042950u);  // 06042934 mov.w 0x06042950,r0
    c.r[1] = 0x0u;  // 06042936 mov #0,r1
    st16(c.r[0] + c.r[4], c.r[1]);  // 06042938 mov.w r1,@(r0,r4)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042952u);  // 0604293A mov.w 0x06042952,r0
    st16(c.r[0] + c.r[4], c.r[1]);  // 0604293C mov.w r1,@(r0,r4)
    c.r[4] = (uint32_t)(int16_t)ld16(0x06042954u);  // 0604293E mov.w 0x06042954,r4
    c.r[1] = ld32(0x06042960u);  // 06042940 mov.l 0x06042960,r1
L_06042942:
    { const uint32_t x = c.r[1]; c.pr = 0x06042946u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042946u) return; }  // 06042942 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06042946 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042948 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604294A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604294C rts ; mov #1,r0
}

void f_06042964(SH2Context& c) {
    ran[1064] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042964 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042966 sts.l pr,@-r15
    c.r[4] = ld32(0x060429C8u);  // 06042968 mov.l 0x060429C8,r4
    c.r[3] = c.r[4];  // 0604296A mov r4,r3
    c.r[3] += 1;  // 0604296C add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604296E mov.b @r3,r1
    c.r[0] = c.r[1];  // 06042970 mov r1,r0
    c.r[0] >>= 2;  // 06042972 shlr2 r0
    c.r[0] >>= 2;  // 06042974 shlr2 r0
    c.r[0] >>= 2;  // 06042976 shlr2 r0
    c.r[0] &= 0x1u;  // 06042978 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604297A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604298A; } }  // 0604297C bt/s 0x0604298A ; mov r15,r14
    c.r[4] += 2;  // 06042980 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06042982 mov.w @r4,r4
    c.r[1] = ld32(0x060429CCu);  // 06042984 mov.l 0x060429CC,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_060429B4;  // 06042986 bra 0x060429B4 ; extu.w r4,r4
L_0604298A:
    c.r[0] = c.r[1];  // 0604298A mov r1,r0
    c.r[0] |= 0x40u;  // 0604298C or #64,r0
    st8(c.r[3], c.r[0]);  // 0604298E mov.b r0,@r3
    c.r[2] = c.r[4];  // 06042990 mov r4,r2
    c.r[2] += 2;  // 06042992 add #2,r2
    c.r[1] = 0x2u;  // 06042994 mov #2,r1
    st16(c.r[2], c.r[1]);  // 06042996 mov.w r1,@r2
    c.r[2] = c.r[4];  // 06042998 mov r4,r2
    c.r[2] += 4;  // 0604299A add #4,r2
    c.r[1] = 0x10u;  // 0604299C mov #16,r1
    st16(c.r[2], c.r[1]);  // 0604299E mov.w r1,@r2
    c.r[0] &= 0xCFu;  // 060429A0 and #207,r0
    c.r[0] |= 0x20u;  // 060429A2 or #32,r0
    st8(c.r[3], c.r[0]);  // 060429A4 mov.b r0,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060429C2u);  // 060429A6 mov.w 0x060429C2,r0
    c.r[1] = 0x0u;  // 060429A8 mov #0,r1
    st16(c.r[0] + c.r[4], c.r[1]);  // 060429AA mov.w r1,@(r0,r4)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060429C4u);  // 060429AC mov.w 0x060429C4,r0
    st16(c.r[0] + c.r[4], c.r[1]);  // 060429AE mov.w r1,@(r0,r4)
    c.r[4] = (uint32_t)(int16_t)ld16(0x060429C6u);  // 060429B0 mov.w 0x060429C6,r4
    c.r[1] = ld32(0x060429D0u);  // 060429B2 mov.l 0x060429D0,r1
L_060429B4:
    { const uint32_t x = c.r[1]; c.pr = 0x060429B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060429B8u) return; }  // 060429B4 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060429B8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060429BA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060429BC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060429BE rts ; mov #1,r0
}

void f_060429D4(SH2Context& c) {
    ran[1065] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060429D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060429D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060429D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060429DA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060429DC sts.l pr,@-r15
    c.r[9] = ld32(0x06042A68u);  // 060429DE mov.l 0x06042A68,r9
    c.r[2] = c.r[9];  // 060429E0 mov r9,r2
    c.r[2] += 1;  // 060429E2 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060429E4 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060429E6 mov r1,r0
    c.r[0] >>= 2;  // 060429E8 shlr2 r0
    c.r[0] >>= 2;  // 060429EA shlr2 r0
    c.r[0] >>= 2;  // 060429EC shlr2 r0
    c.r[0] &= 0x1u;  // 060429EE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060429F0 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042A0A; } }  // 060429F2 bt/s 0x06042A0A ; mov r15,r14
    c.r[1] = c.r[9];  // 060429F6 mov r9,r1
    c.r[1] += 11;  // 060429F8 add #11,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060429FA mov.b @r1,r5
    c.r[4] = 0x0u;  // 060429FC mov #0,r4
    c.r[1] = ld32(0x06042A6Cu);  // 060429FE mov.l 0x06042A6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042A04u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042A04u) return; }  // 06042A00 jsr @r1 ; extu.b r5,r5
    c.r[9] += 2;  // 06042A04 add #2,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); goto L_06042A50;  // 06042A06 bra 0x06042A50 ; mov.w @r9,r4
L_06042A0A:
    c.r[0] = c.r[1];  // 06042A0A mov r1,r0
    c.r[0] |= 0x40u;  // 06042A0C or #64,r0
    st8(c.r[2], c.r[0]);  // 06042A0E mov.b r0,@r2
    c.r[8] = c.r[9];  // 06042A10 mov r9,r8
    c.r[8] += 2;  // 06042A12 add #2,r8
    c.r[1] = 0x2u;  // 06042A14 mov #2,r1
    st16(c.r[8], c.r[1]);  // 06042A16 mov.w r1,@r8
    c.r[10] = c.r[9];  // 06042A18 mov r9,r10
    c.r[10] += 4;  // 06042A1A add #4,r10
    c.r[1] = 0x10u;  // 06042A1C mov #16,r1
    st16(c.r[10], c.r[1]);  // 06042A1E mov.w r1,@r10
    c.r[0] &= 0xCFu;  // 06042A20 and #207,r0
    st8(c.r[2], c.r[0]);  // 06042A22 mov.b r0,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042A66u);  // 06042A24 mov.w 0x06042A66,r0
    c.r[1] = 0x0u;  // 06042A26 mov #0,r1
    st16(c.r[0] + c.r[9], c.r[1]);  // 06042A28 mov.w r1,@(r0,r9)
    c.r[9] += 11;  // 06042A2A add #11,r9
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06042A2C mov.b @r9,r5
    c.r[4] = 0x0u;  // 06042A2E mov #0,r4
    c.r[9] = ld32(0x06042A6Cu);  // 06042A30 mov.l 0x06042A6C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06042A36u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042A36u) return; }  // 06042A32 jsr @r9 ; extu.b r5,r5
    c.r[5] = 0xAu;  // 06042A36 mov #10,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042A38 mov.w @r8,r0
    c.r[4] = 0x2u;  // 06042A3A mov #2,r4
    c.r[0] |= 0x8u;  // 06042A3C or #8,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06042A42u; st16(c.r[8], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042A42u) return; }  // 06042A3E jsr @r9 ; mov.w r0,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042A42 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042A44 mov.w @r10,r1
    c.r[4] |= c.r[1];  // 06042A46 or r1,r4
    c.r[1] = ld32(0x06042A70u);  // 06042A48 mov.l 0x06042A70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042A4Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042A4Eu) return; }  // 06042A4A jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042A4E mov.w @r8,r4
L_06042A50:
    c.r[1] = ld32(0x06042A74u);  // 06042A50 mov.l 0x06042A74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042A56u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042A56u) return; }  // 06042A52 jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06042A56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042A58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042A5A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06042A5C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042A5E mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042A60 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042A62 rts ; mov #1,r0
}

void f_06042A78(SH2Context& c) {
    ran[1066] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042A78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042A7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06042A7C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042A7E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042A80 sts.l pr,@-r15
    c.r[9] = ld32(0x06042B14u);  // 06042A82 mov.l 0x06042B14,r9
    c.r[2] = c.r[9];  // 06042A84 mov r9,r2
    c.r[2] += 1;  // 06042A86 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06042A88 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06042A8A mov r1,r0
    c.r[0] >>= 2;  // 06042A8C shlr2 r0
    c.r[0] >>= 2;  // 06042A8E shlr2 r0
    c.r[0] >>= 2;  // 06042A90 shlr2 r0
    c.r[0] &= 0x1u;  // 06042A92 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042A94 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042AAE; } }  // 06042A96 bt/s 0x06042AAE ; mov r15,r14
    c.r[1] = c.r[9];  // 06042A9A mov r9,r1
    c.r[1] += 11;  // 06042A9C add #11,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042A9E mov.b @r1,r5
    c.r[4] = 0x0u;  // 06042AA0 mov #0,r4
    c.r[1] = ld32(0x06042B18u);  // 06042AA2 mov.l 0x06042B18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042AA8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042AA8u) return; }  // 06042AA4 jsr @r1 ; extu.b r5,r5
    c.r[9] += 2;  // 06042AA8 add #2,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); goto L_06042AFA;  // 06042AAA bra 0x06042AFA ; mov.w @r9,r4
L_06042AAE:
    c.r[0] = c.r[1];  // 06042AAE mov r1,r0
    c.r[0] |= 0x40u;  // 06042AB0 or #64,r0
    st8(c.r[2], c.r[0]);  // 06042AB2 mov.b r0,@r2
    c.r[8] = c.r[9];  // 06042AB4 mov r9,r8
    c.r[8] += 2;  // 06042AB6 add #2,r8
    c.r[1] = 0x2u;  // 06042AB8 mov #2,r1
    st16(c.r[8], c.r[1]);  // 06042ABA mov.w r1,@r8
    c.r[10] = c.r[9];  // 06042ABC mov r9,r10
    c.r[10] += 4;  // 06042ABE add #4,r10
    c.r[1] = 0x10u;  // 06042AC0 mov #16,r1
    st16(c.r[10], c.r[1]);  // 06042AC2 mov.w r1,@r10
    c.r[0] &= 0xCFu;  // 06042AC4 and #207,r0
    c.r[0] |= 0x20u;  // 06042AC6 or #32,r0
    st8(c.r[2], c.r[0]);  // 06042AC8 mov.b r0,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042B10u);  // 06042ACA mov.w 0x06042B10,r0
    c.r[1] = 0x0u;  // 06042ACC mov #0,r1
    st16(c.r[0] + c.r[9], c.r[1]);  // 06042ACE mov.w r1,@(r0,r9)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042B12u);  // 06042AD0 mov.w 0x06042B12,r0
    st16(c.r[0] + c.r[9], c.r[1]);  // 06042AD2 mov.w r1,@(r0,r9)
    c.r[9] += 11;  // 06042AD4 add #11,r9
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06042AD6 mov.b @r9,r5
    c.r[4] = 0x0u;  // 06042AD8 mov #0,r4
    c.r[9] = ld32(0x06042B18u);  // 06042ADA mov.l 0x06042B18,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06042AE0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042AE0u) return; }  // 06042ADC jsr @r9 ; extu.b r5,r5
    c.r[5] = 0xAu;  // 06042AE0 mov #10,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042AE2 mov.w @r8,r0
    c.r[4] = 0x2u;  // 06042AE4 mov #2,r4
    c.r[0] |= 0x8u;  // 06042AE6 or #8,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06042AECu; st16(c.r[8], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042AECu) return; }  // 06042AE8 jsr @r9 ; mov.w r0,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042AEC mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042AEE mov.w @r10,r1
    c.r[4] |= c.r[1];  // 06042AF0 or r1,r4
    c.r[1] = ld32(0x06042B1Cu);  // 06042AF2 mov.l 0x06042B1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042AF8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042AF8u) return; }  // 06042AF4 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042AF8 mov.w @r8,r4
L_06042AFA:
    c.r[1] = ld32(0x06042B20u);  // 06042AFA mov.l 0x06042B20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042B00u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042B00u) return; }  // 06042AFC jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06042B00 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042B02 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042B04 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06042B06 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042B08 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042B0A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042B0C rts ; mov #1,r0
}

void f_06042B24(SH2Context& c) {
    ran[1067] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042B24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042B26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06042B28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06042B2A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042B2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042B2E sts.l pr,@-r15
    c.r[10] = ld32(0x06042BD4u);  // 06042B30 mov.l 0x06042BD4,r10
    c.r[2] = c.r[10];  // 06042B32 mov r10,r2
    c.r[2] += 1;  // 06042B34 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06042B36 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06042B38 mov r1,r0
    c.r[0] >>= 2;  // 06042B3A shlr2 r0
    c.r[0] >>= 2;  // 06042B3C shlr2 r0
    c.r[0] >>= 2;  // 06042B3E shlr2 r0
    c.r[0] &= 0x1u;  // 06042B40 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042B42 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042B52; } }  // 06042B44 bt/s 0x06042B52 ; mov r15,r14
    c.r[10] += 2;  // 06042B48 add #2,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042B4A mov.w @r10,r4
    c.r[1] = ld32(0x06042BD8u);  // 06042B4C mov.l 0x06042BD8,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06042BAE;  // 06042B4E bra 0x06042BAE ; extu.w r4,r4
L_06042B52:
    c.r[3] = 0x40u;  // 06042B52 mov #64,r3
    c.r[3] |= c.r[1];  // 06042B54 or r1,r3
    st8(c.r[2], c.r[3]);  // 06042B56 mov.b r3,@r2
    c.r[9] = c.r[10];  // 06042B58 mov r10,r9
    c.r[9] += 2;  // 06042B5A add #2,r9
    c.r[1] = 0x12u;  // 06042B5C mov #18,r1
    st16(c.r[9], c.r[1]);  // 06042B5E mov.w r1,@r9
    c.r[8] = c.r[10];  // 06042B60 mov r10,r8
    c.r[8] += 4;  // 06042B62 add #4,r8
    c.r[1] = 0x20u;  // 06042B64 mov #32,r1
    st16(c.r[8], c.r[1]);  // 06042B66 mov.w r1,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042BC4u);  // 06042B68 mov.w 0x06042BC4,r0
    c.r[3] &= c.r[0];  // 06042B6A and r0,r3
    st8(c.r[2], c.r[3]);  // 06042B6C mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042BC6u);  // 06042B6E mov.w 0x06042BC6,r2
    c.r[1] = 0x0u;  // 06042B70 mov #0,r1
    c.r[0] = c.r[10];  // 06042B72 mov r10,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06042B74 mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042BC8u);  // 06042B76 mov.w 0x06042BC8,r2
    c.r[1] = 0x6u;  // 06042B78 mov #6,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06042B7A mov.w r1,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06042BCAu);  // 06042B7C mov.w 0x06042BCA,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042BCCu);  // 06042B7E mov.w 0x06042BCC,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06042BCEu);  // 06042B80 mov.w 0x06042BCE,r11
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06042B82 mov.w @(r0,r1),r5
    c.r[6] = 0x2u;  // 06042B84 mov #2,r6
    c.r[4] = ld32(c.r[0] + c.r[11]);  // 06042B86 mov.l @(r0,r11),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06042B88 extu.w r5,r5
    c.r[5] <<= 2;  // 06042B8A shll2 r5
    c.r[1] = ld32(0x06042BDCu);  // 06042B8C mov.l 0x06042BDC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042B92u; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042B92u) return; }  // 06042B8E jsr @r1 ; shll2 r5
    c.r[0] = c.r[10];  // 06042B92 mov r10,r0
    c.r[1] = ld32(0x06042BE0u);  // 06042B94 mov.l 0x06042BE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042B9Au; c.r[4] = ld32(c.r[0] + c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042B9Au) return; }  // 06042B96 jsr @r1 ; mov.l @(r0,r11),r4
    c.r[1] = ld32(0x06042BE4u);  // 06042B9A mov.l 0x06042BE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042BA0u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042BA0u) return; }  // 06042B9C jsr @r1 ; mov #16,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042BA0 mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06042BD0u);  // 06042BA2 mov.w 0x06042BD0,r1
    c.r[4] |= c.r[1];  // 06042BA4 or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06042BA6 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06042BA8 or r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 06042BAA extu.w r4,r4
    c.r[1] = ld32(0x06042BE8u);  // 06042BAC mov.l 0x06042BE8,r1
L_06042BAE:
    { const uint32_t x = c.r[1]; c.pr = 0x06042BB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042BB2u) return; }  // 06042BAE jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06042BB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042BB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042BB6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06042BB8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06042BBA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042BBC mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042BBE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042BC0 rts ; mov #1,r0
}

void f_06042BEC(SH2Context& c) {
    ran[1068] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042BEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042BEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042BF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042BF2 sts.l pr,@-r15
    c.r[4] = ld32(0x06042C64u);  // 06042BF4 mov.l 0x06042C64,r4
    c.r[2] = c.r[4];  // 06042BF6 mov r4,r2
    c.r[2] += 1;  // 06042BF8 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06042BFA mov.b @r2,r1
    c.r[0] = c.r[1];  // 06042BFC mov r1,r0
    c.r[0] >>= 2;  // 06042BFE shlr2 r0
    c.r[0] >>= 2;  // 06042C00 shlr2 r0
    c.r[0] >>= 2;  // 06042C02 shlr2 r0
    c.r[0] &= 0x1u;  // 06042C04 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042C06 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042C12; } }  // 06042C08 bt/s 0x06042C12 ; mov r15,r14
    c.r[4] += 2;  // 06042C0C add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]); goto L_06042C4C;  // 06042C0E bra 0x06042C4C ; mov.w @r4,r4
L_06042C12:
    c.r[0] = c.r[1];  // 06042C12 mov r1,r0
    c.r[0] |= 0x40u;  // 06042C14 or #64,r0
    st8(c.r[2], c.r[0]);  // 06042C16 mov.b r0,@r2
    c.r[8] = c.r[4];  // 06042C18 mov r4,r8
    c.r[8] += 2;  // 06042C1A add #2,r8
    c.r[1] = 0x0u;  // 06042C1C mov #0,r1
    st16(c.r[8], c.r[1]);  // 06042C1E mov.w r1,@r8
    c.r[9] = c.r[4];  // 06042C20 mov r4,r9
    c.r[9] += 4;  // 06042C22 add #4,r9
    st16(c.r[9], c.r[1]);  // 06042C24 mov.w r1,@r9
    c.r[0] &= 0xCFu;  // 06042C26 and #207,r0
    st8(c.r[2], c.r[0]);  // 06042C28 mov.b r0,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042C60u);  // 06042C2A mov.w 0x06042C60,r0
    st16(c.r[0] + c.r[4], c.r[1]);  // 06042C2C mov.w r1,@(r0,r4)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042C62u);  // 06042C2E mov.w 0x06042C62,r0
    st16(c.r[0] + c.r[4], c.r[1]);  // 06042C30 mov.w r1,@(r0,r4)
    c.r[1] = 0x8u;  // 06042C32 mov #8,r1
    st16(c.r[8], c.r[1]);  // 06042C34 mov.w r1,@r8
    c.r[1] = ld32(0x06042C68u);  // 06042C36 mov.l 0x06042C68,r1
    c.r[5] = 0xAu;  // 06042C38 mov #10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06042C3Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042C3Eu) return; }  // 06042C3A jsr @r1 ; mov #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042C3E mov.w @r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06042C40 mov.w @r9,r1
    c.r[4] |= c.r[1];  // 06042C42 or r1,r4
    c.r[1] = ld32(0x06042C6Cu);  // 06042C44 mov.l 0x06042C6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042C4Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042C4Au) return; }  // 06042C46 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06042C4A mov.w @r8,r4
L_06042C4C:
    c.r[1] = ld32(0x06042C70u);  // 06042C4C mov.l 0x06042C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042C52u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042C52u) return; }  // 06042C4E jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 06042C52 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042C54 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042C56 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06042C58 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06042C5A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06042C5C rts ; mov #1,r0
}

void f_06042C74(SH2Context& c) {
    ran[1069] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042C74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042C76 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042C78 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06042C7A mov r15,r14
    c.r[8] = ld32(0x06042D40u);  // 06042C7C mov.l 0x06042D40,r8
    c.r[1] = 0x0u;  // 06042C7E mov #0,r1
    c.r[0] = ld32(0x06042D44u);  // 06042C80 mov.l 0x06042D44,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042C86u; st8(c.r[8], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042C86u) return; }  // 06042C82 jsr @r0 ; mov.b r1,@r8
    c.r[1] = ld32(0x06042D48u);  // 06042C86 mov.l 0x06042D48,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042C88 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06042C8A extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06042C8C cmp/eq #1,r0
    if (!c.t) { goto L_06042CAA; }  // 06042C8E bf 0x06042CAA
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D36u);  // 06042C90 mov.w 0x06042D36,r0
    c.r[1] = ld32(0x06042D4Cu);  // 06042C92 mov.l 0x06042D4C,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 06042C94 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D38u);  // 06042C96 mov.w 0x06042D38,r0
    c.r[1] = 0x3Bu;  // 06042C98 mov #59,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 06042C9A mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D3Au);  // 06042C9C mov.w 0x06042D3A,r0
    c.r[1] = ld32(0x06042D50u);  // 06042C9E mov.l 0x06042D50,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 06042CA0 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D3Cu);  // 06042CA2 mov.w 0x06042D3C,r0
    c.r[1] = ld32(0x06042D54u);  // 06042CA4 mov.l 0x06042D54,r1
    st32(c.r[0] + c.r[8], c.r[1]); goto L_06042CC2;  // 06042CA6 bra 0x06042CC2 ; mov.l r1,@(r0,r8)
L_06042CAA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D36u);  // 06042CAA mov.w 0x06042D36,r0
    c.r[1] = ld32(0x06042D58u);  // 06042CAC mov.l 0x06042D58,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 06042CAE mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D38u);  // 06042CB0 mov.w 0x06042D38,r0
    c.r[1] = 0x3Fu;  // 06042CB2 mov #63,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 06042CB4 mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D3Au);  // 06042CB6 mov.w 0x06042D3A,r0
    c.r[1] = ld32(0x06042D5Cu);  // 06042CB8 mov.l 0x06042D5C,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 06042CBA mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042D3Cu);  // 06042CBC mov.w 0x06042D3C,r0
    c.r[1] = ld32(0x06042D60u);  // 06042CBE mov.l 0x06042D60,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 06042CC0 mov.l r1,@(r0,r8)
L_06042CC2:
    c.r[6] = 0x0u;  // 06042CC2 mov #0,r6
    c.r[8] = 0x2u;  // 06042CC4 mov #2,r8
    c.r[0] = ld32(0x06042D40u);  // 06042CC6 mov.l 0x06042D40,r0
    c.r[5] = 0x0u;  // 06042CC8 mov #0,r5
    c.r[2] = c.r[0];  // 06042CCA mov r0,r2
    c.r[3] = c.r[2];  // 06042CCC mov r2,r3
    c.r[7] = c.r[3];  // 06042CCE mov r3,r7
L_06042CD0:
    c.r[1] = c.r[6];  // 06042CD0 mov r6,r1
    c.r[1] += c.r[0];  // 06042CD2 add r0,r1
    c.r[1] += 44;  // 06042CD4 add #44,r1
    c.r[4] = 0x0u;  // 06042CD6 mov #0,r4
    st8(c.r[1], c.r[4]);  // 06042CD8 mov.b r4,@r1
    c.r[1] = c.r[3];  // 06042CDA mov r3,r1
    c.r[1] += 47;  // 06042CDC add #47,r1
    st8(c.r[1], c.r[4]);  // 06042CDE mov.b r4,@r1
    c.r[1] = c.r[3];  // 06042CE0 mov r3,r1
    c.r[1] += 48;  // 06042CE2 add #48,r1
    st8(c.r[1], c.r[4]);  // 06042CE4 mov.b r4,@r1
    c.r[1] = c.r[7];  // 06042CE6 mov r7,r1
    c.r[1] += 54;  // 06042CE8 add #54,r1
    st16(c.r[1], c.r[5]);  // 06042CEA mov.w r5,@r1
    c.r[1] = c.r[7];  // 06042CEC mov r7,r1
    c.r[1] += 56;  // 06042CEE add #56,r1
    st16(c.r[1], c.r[5]);  // 06042CF0 mov.w r5,@r1
    c.r[1] = c.r[2];  // 06042CF2 mov r2,r1
    c.r[1] += 108;  // 06042CF4 add #108,r1
    st32(c.r[1], c.r[5]);  // 06042CF6 mov.l r5,@r1
    c.r[1] = c.r[2];  // 06042CF8 mov r2,r1
    c.r[1] += 112;  // 06042CFA add #112,r1
    st32(c.r[1], c.r[5]);  // 06042CFC mov.l r5,@r1
    c.r[1] = c.r[2];  // 06042CFE mov r2,r1
    c.r[1] += 68;  // 06042D00 add #68,r1
    st32(c.r[1], c.r[5]);  // 06042D02 mov.l r5,@r1
    c.r[1] = c.r[2];  // 06042D04 mov r2,r1
    c.r[1] += 72;  // 06042D06 add #72,r1
    st32(c.r[1], c.r[5]);  // 06042D08 mov.l r5,@r1
    c.r[2] += 8;  // 06042D0A add #8,r2
    c.r[7] += 4;  // 06042D0C add #4,r7
    c.r[6] += 1;  // 06042D0E add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[8];  // 06042D10 cmp/gt r8,r6
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06042CD0; } }  // 06042D12 bf/s 0x06042CD0 ; add #2,r3
    c.r[1] = ld32(0x06042D64u);  // 06042D16 mov.l 0x06042D64,r1
    c.r[2] = 0x0u;  // 06042D18 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06042D1A mov.l r2,@r1
    c.r[1] = ld32(0x06042D68u);  // 06042D1C mov.l 0x06042D68,r1
    st32(c.r[1], c.r[2]);  // 06042D1E mov.l r2,@r1
    c.r[1] = ld32(0x06042D6Cu);  // 06042D20 mov.l 0x06042D6C,r1
    st32(c.r[1], c.r[2]);  // 06042D22 mov.l r2,@r1
    c.r[1] = ld32(0x06042D70u);  // 06042D24 mov.l 0x06042D70,r1
    st8(c.r[1], c.r[4]);  // 06042D26 mov.b r4,@r1
    c.r[1] = ld32(0x06042D74u);  // 06042D28 mov.l 0x06042D74,r1
    st8(c.r[1], c.r[4]);  // 06042D2A mov.b r4,@r1
    c.r[15] = c.r[14];  // 06042D2C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06042D2E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06042D30 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06042D32 rts ; mov.l @r15+,r8
}

void f_06042D80(SH2Context& c) {
    ran[1070] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06042D80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06042D82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06042D84 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06042D86 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06042D88 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06042D8A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06042D8C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06042D8E sts.l pr,@-r15
    c.r[15] -= 8;  // 06042D90 add #-8,r15
    c.r[10] = ld32(0x06042DDCu);  // 06042D92 mov.l 0x06042DDC,r10
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042D94 mov.w @r10,r0
    c.r[0] &= 0x8u;  // 06042D96 and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06042D98 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06042DC0; } }  // 06042D9A bt/s 0x06042DC0 ; mov r15,r14
    c.r[8] = ld32(0x06042DE0u);  // 06042D9E mov.l 0x06042DE0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 06042DA0 mov.b @r8+,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06042DA2 extu.b r1,r0
    c.r[0] <<= 2;  // 06042DA4 shll2 r0
    c.r[1] = ld32(0x06042DE4u);  // 06042DA6 mov.l 0x06042DE4,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06042DA8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042DAEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042DAEu) return; }  // 06042DAA jsr @r0 ; nop
    c.r[1] = c.r[0];  // 06042DAE mov r0,r1
    c.r[1] <<= 2;  // 06042DB0 shll2 r1
    c.r[1] <<= 2;  // 06042DB2 shll2 r1
    c.r[1] += c.r[1];  // 06042DB4 add r1,r1
    c.r[1] <<= 2;  // 06042DB6 shll2 r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06042DB8 mov.b @r8,r0
    c.r[0] &= 0x7Fu;  // 06042DBA and #127,r0
    c.r[0] |= c.r[1];  // 06042DBC or r1,r0
    st8(c.r[8], c.r[0]);  // 06042DBE mov.b r0,@r8
L_06042DC0:
    c.r[1] = ld32(0x06042DE8u);  // 06042DC0 mov.l 0x06042DE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042DC2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06042DC4 extu.b r1,r1
    c.r[1] >>= 2;  // 06042DC6 shlr2 r1
    c.r[1] >>= 2;  // 06042DC8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06042DCA shlr r1
    c.r[1] >>= 2;  // 06042DCC shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06042DCE tst r1,r1
    if (c.t) { goto L_06042DEC; }  // 06042DD0 bt 0x06042DEC
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042DD2 mov.w @r10,r0
    c.r[0] |= 0x8u;  // 06042DD4 or #8,r0
    st16(c.r[10], c.r[0]); goto L_06042DF4;  // 06042DD6 bra 0x06042DF4 ; mov.w r0,@r10
L_06042DEC:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06042DEC mov.w @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06042FB0u);  // 06042DEE mov.w 0x06042FB0,r2
    c.r[1] &= c.r[2];  // 06042DF0 and r2,r1
    st16(c.r[10], c.r[1]);  // 06042DF2 mov.w r1,@r10
L_06042DF4:
    c.r[1] = ld32(0x06042FB8u);  // 06042DF4 mov.l 0x06042FB8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06042DF6 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06042DF8 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06042DFA cmp/eq #1,r0
    if (c.t) { goto L_06042E02; }  // 06042DFC bt 0x06042E02
    goto L_0604307E;  // 06042DFE bra 0x0604307E ; nop
L_06042E02:
    c.r[10] = ld32(0x06042FBCu);  // 06042E02 mov.l 0x06042FBC,r10
    c.r[0] = ld32(0x06042FC0u);  // 06042E04 mov.l 0x06042FC0,r0
    c.r[5] = ld32(c.r[0]);  // 06042E06 mov.l @r0,r5
    c.r[1] = ld32(0x06042FC4u);  // 06042E08 mov.l 0x06042FC4,r1
    c.r[11] = ld32(0x06042FC8u);  // 06042E0A mov.l 0x06042FC8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042E10u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E10u) return; }  // 06042E0C jsr @r11 ; mov.l @r1,r4
    c.r[0] = ld32(0x06042FCCu);  // 06042E10 mov.l 0x06042FCC,r0
    c.r[5] = ld32(c.r[0]);  // 06042E12 mov.l @r0,r5
    c.r[1] = ld32(0x06042FD0u);  // 06042E14 mov.l 0x06042FD0,r1
    c.r[11] = ld32(0x06042FD4u);  // 06042E16 mov.l 0x06042FD4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042E1Cu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E1Cu) return; }  // 06042E18 jsr @r11 ; mov.l @r1,r4
    c.r[0] = ld32(0x06042FD8u);  // 06042E1C mov.l 0x06042FD8,r0
    c.r[5] = ld32(c.r[0]);  // 06042E1E mov.l @r0,r5
    c.r[1] = ld32(0x06042FDCu);  // 06042E20 mov.l 0x06042FDC,r1
    c.r[11] = ld32(0x06042FE0u);  // 06042E22 mov.l 0x06042FE0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042E28u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E28u) return; }  // 06042E24 jsr @r11 ; mov.l @r1,r4
    c.r[0] = ld32(0x06042FE4u);  // 06042E28 mov.l 0x06042FE4,r0
    c.r[5] = ld32(c.r[0]);  // 06042E2A mov.l @r0,r5
    c.r[1] = ld32(0x06042FE8u);  // 06042E2C mov.l 0x06042FE8,r1
    c.r[11] = ld32(0x06042FECu);  // 06042E2E mov.l 0x06042FEC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042E34u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E34u) return; }  // 06042E30 jsr @r11 ; mov.l @r1,r4
    c.r[0] = ld32(0x06042FF0u);  // 06042E34 mov.l 0x06042FF0,r0
    c.r[1] = ld32(0x06042FF4u);  // 06042E36 mov.l 0x06042FF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042E3Cu; c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E3Cu) return; }  // 06042E38 jsr @r1 ; mov.b @r0,r4
    c.r[4] = c.r[0];  // 06042E3C mov r0,r4
    c.r[5] = c.r[1];  // 06042E3E mov r1,r5
    c.r[11] = ld32(0x06042FF8u);  // 06042E40 mov.l 0x06042FF8,r11
    c.r[6] = ld32(c.r[11]);  // 06042E42 mov.l @r11,r6
    c.r[0] = ld32(0x06042FFCu);  // 06042E44 mov.l 0x06042FFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042E4Au; c.r[7] = ld32(c.r[11] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E4Au) return; }  // 06042E46 jsr @r0 ; mov.l @(4,r11),r7
    c.r[4] = c.r[0];  // 06042E4A mov r0,r4
    c.r[5] = c.r[1];  // 06042E4C mov r1,r5
    c.r[1] = ld32(0x06043000u);  // 06042E4E mov.l 0x06043000,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042E54u; c.r[9] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E54u) return; }  // 06042E50 jsr @r1 ; mov r10,r9
    c.r[2] = c.r[0];  // 06042E54 mov r0,r2
    c.r[11] = ld32(0x06043004u);  // 06042E56 mov.l 0x06043004,r11
    c.r[0] = ld32(0x06042FC4u);  // 06042E58 mov.l 0x06042FC4,r0
    c.r[11] = ld32(c.r[11]);  // 06042E5A mov.l @r11,r11
    c.r[1] = ld32(0x06043008u);  // 06042E5C mov.l 0x06043008,r1
    c.r[11] -= c.r[2];  // 06042E5E sub r2,r11
    st32(c.r[0], c.r[11]);  // 06042E60 mov.l r11,@r0
    c.r[11] = ld32(0x06042FF4u);  // 06042E62 mov.l 0x06042FF4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042E68u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E68u) return; }  // 06042E64 jsr @r11 ; mov.b @r1,r4
    c.r[4] = c.r[0];  // 06042E68 mov r0,r4
    c.r[5] = c.r[1];  // 06042E6A mov r1,r5
    c.r[0] = ld32(0x06042FF8u);  // 06042E6C mov.l 0x06042FF8,r0
    c.r[6] = ld32(c.r[0]);  // 06042E6E mov.l @r0,r6
    c.r[1] = ld32(0x06042FFCu);  // 06042E70 mov.l 0x06042FFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042E76u; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E76u) return; }  // 06042E72 jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 06042E76 mov r0,r4
    c.r[11] = ld32(0x06043000u);  // 06042E78 mov.l 0x06043000,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042E7Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E7Eu) return; }  // 06042E7A jsr @r11 ; mov r1,r5
    c.r[2] = c.r[0];  // 06042E7E mov r0,r2
    c.r[0] = ld32(0x0604300Cu);  // 06042E80 mov.l 0x0604300C,r0
    c.r[1] = ld32(0x06042FC0u);  // 06042E82 mov.l 0x06042FC0,r1
    c.r[9] += 116;  // 06042E84 add #116,r9
    c.r[0] = ld32(c.r[0]);  // 06042E86 mov.l @r0,r0
    c.r[11] = ld32(0x06042FF0u);  // 06042E88 mov.l 0x06042FF0,r11
    c.r[0] -= c.r[2];  // 06042E8A sub r2,r0
    st32(c.r[1], c.r[0]);  // 06042E8C mov.l r0,@r1
    c.r[0] = ld32(0x06042FF4u);  // 06042E8E mov.l 0x06042FF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042E94u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042E94u) return; }  // 06042E90 jsr @r0 ; mov.b @r11,r4
    c.r[4] = c.r[0];  // 06042E94 mov r0,r4
    c.r[5] = c.r[1];  // 06042E96 mov r1,r5
    c.r[1] = ld32(0x06042FF8u);  // 06042E98 mov.l 0x06042FF8,r1
    c.r[6] = ld32(c.r[1]);  // 06042E9A mov.l @r1,r6
    c.r[11] = ld32(0x06042FFCu);  // 06042E9C mov.l 0x06042FFC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042EA2u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042EA2u) return; }  // 06042E9E jsr @r11 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 06042EA2 mov r0,r4
    c.r[5] = c.r[1];  // 06042EA4 mov r1,r5
    c.r[0] = ld32(0x06043000u);  // 06042EA6 mov.l 0x06043000,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042EACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042EACu) return; }  // 06042EA8 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 06042EAC mov r0,r2
    c.r[11] = ld32(0x06042FD0u);  // 06042EAE mov.l 0x06042FD0,r11
    c.r[9] = ld32(c.r[9]);  // 06042EB0 mov.l @r9,r9
    c.r[0] = ld32(0x06043008u);  // 06042EB2 mov.l 0x06043008,r0
    c.r[1] = c.r[9];  // 06042EB4 mov r9,r1
    c.r[1] -= c.r[2];  // 06042EB6 sub r2,r1
    st32(c.r[11], c.r[1]);  // 06042EB8 mov.l r1,@r11
    c.r[1] = ld32(0x06042FF4u);  // 06042EBA mov.l 0x06042FF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042EC0u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042EC0u) return; }  // 06042EBC jsr @r1 ; mov.b @r0,r4
    c.r[4] = c.r[0];  // 06042EC0 mov r0,r4
    c.r[5] = c.r[1];  // 06042EC2 mov r1,r5
    c.r[11] = ld32(0x06042FF8u);  // 06042EC4 mov.l 0x06042FF8,r11
    c.r[6] = ld32(c.r[11]);  // 06042EC6 mov.l @r11,r6
    c.r[0] = ld32(0x06042FFCu);  // 06042EC8 mov.l 0x06042FFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042ECEu; c.r[7] = ld32(c.r[11] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042ECEu) return; }  // 06042ECA jsr @r0 ; mov.l @(4,r11),r7
    c.r[4] = c.r[0];  // 06042ECE mov r0,r4
    c.r[5] = c.r[1];  // 06042ED0 mov r1,r5
    c.r[1] = ld32(0x06043000u);  // 06042ED2 mov.l 0x06043000,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042ED8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042ED8u) return; }  // 06042ED4 jsr @r1 ; nop
    c.r[2] = c.r[0];  // 06042ED8 mov r0,r2
    c.r[11] = ld32(0x06043010u);  // 06042EDA mov.l 0x06043010,r11
    c.r[0] = ld32(0x06042FCCu);  // 06042EDC mov.l 0x06042FCC,r0
    c.r[11] = ld32(c.r[11]);  // 06042EDE mov.l @r11,r11
    c.r[1] = ld32(0x06042FF0u);  // 06042EE0 mov.l 0x06042FF0,r1
    c.r[11] -= c.r[2];  // 06042EE2 sub r2,r11
    st32(c.r[0], c.r[11]);  // 06042EE4 mov.l r11,@r0
    c.r[11] = ld32(0x06042FF4u);  // 06042EE6 mov.l 0x06042FF4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042EECu; c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042EECu) return; }  // 06042EE8 jsr @r11 ; mov.b @r1,r4
    c.r[4] = c.r[0];  // 06042EEC mov r0,r4
    c.r[5] = c.r[1];  // 06042EEE mov r1,r5
    c.r[0] = ld32(0x06042FF8u);  // 06042EF0 mov.l 0x06042FF8,r0
    c.r[6] = ld32(c.r[0]);  // 06042EF2 mov.l @r0,r6
    c.r[1] = ld32(0x06042FFCu);  // 06042EF4 mov.l 0x06042FFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042EFAu; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042EFAu) return; }  // 06042EF6 jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 06042EFA mov r0,r4
    c.r[11] = ld32(0x06043000u);  // 06042EFC mov.l 0x06043000,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042F02u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F02u) return; }  // 06042EFE jsr @r11 ; mov r1,r5
    c.r[2] = c.r[0];  // 06042F02 mov r0,r2
    c.r[0] = ld32(0x06043014u);  // 06042F04 mov.l 0x06043014,r0
    c.r[1] = ld32(0x06042FDCu);  // 06042F06 mov.l 0x06042FDC,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06042FB2u);  // 06042F08 mov.w 0x06042FB2,r13
    c.r[0] = ld32(c.r[0]);  // 06042F0A mov.l @r0,r0
    c.r[11] = ld32(0x06043008u);  // 06042F0C mov.l 0x06043008,r11
    c.r[0] -= c.r[2];  // 06042F0E sub r2,r0
    st32(c.r[1], c.r[0]);  // 06042F10 mov.l r0,@r1
    c.r[0] = ld32(0x06042FF4u);  // 06042F12 mov.l 0x06042FF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042F18u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F18u) return; }  // 06042F14 jsr @r0 ; mov.b @r11,r4
    c.r[4] = c.r[0];  // 06042F18 mov r0,r4
    c.r[5] = c.r[1];  // 06042F1A mov r1,r5
    c.r[1] = ld32(0x06042FF8u);  // 06042F1C mov.l 0x06042FF8,r1
    c.r[6] = ld32(c.r[1]);  // 06042F1E mov.l @r1,r6
    c.r[11] = ld32(0x06042FFCu);  // 06042F20 mov.l 0x06042FFC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042F26u; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F26u) return; }  // 06042F22 jsr @r11 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 06042F26 mov r0,r4
    c.r[5] = c.r[1];  // 06042F28 mov r1,r5
    c.r[0] = ld32(0x06043000u);  // 06042F2A mov.l 0x06043000,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042F30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F30u) return; }  // 06042F2C jsr @r0 ; nop
    c.r[2] = c.r[0];  // 06042F30 mov r0,r2
    c.r[0] = c.r[10];  // 06042F32 mov r10,r0
    c.r[11] = ld32(0x06042FD8u);  // 06042F34 mov.l 0x06042FD8,r11
    c.r[13] = ld32(c.r[0] + c.r[13]);  // 06042F36 mov.l @(r0,r13),r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06042FB4u);  // 06042F38 mov.w 0x06042FB4,r12
    c.r[1] = c.r[13];  // 06042F3A mov r13,r1
    c.r[1] -= c.r[2];  // 06042F3C sub r2,r1
    st32(c.r[11], c.r[1]);  // 06042F3E mov.l r1,@r11
    c.r[0] = ld32(0x06042FF0u);  // 06042F40 mov.l 0x06042FF0,r0
    c.r[1] = ld32(0x06042FF4u);  // 06042F42 mov.l 0x06042FF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042F48u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F48u) return; }  // 06042F44 jsr @r1 ; mov.b @r0,r4
    c.r[4] = c.r[0];  // 06042F48 mov r0,r4
    c.r[5] = c.r[1];  // 06042F4A mov r1,r5
    c.r[11] = ld32(0x06042FF8u);  // 06042F4C mov.l 0x06042FF8,r11
    c.r[6] = ld32(c.r[11]);  // 06042F4E mov.l @r11,r6
    c.r[0] = ld32(0x06042FFCu);  // 06042F50 mov.l 0x06042FFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06042F56u; c.r[7] = ld32(c.r[11] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F56u) return; }  // 06042F52 jsr @r0 ; mov.l @(4,r11),r7
    c.r[4] = c.r[0];  // 06042F56 mov r0,r4
    c.r[5] = c.r[1];  // 06042F58 mov r1,r5
    c.r[1] = ld32(0x06043000u);  // 06042F5A mov.l 0x06043000,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042F60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F60u) return; }  // 06042F5C jsr @r1 ; nop
    c.r[2] = c.r[0];  // 06042F60 mov r0,r2
    c.r[0] = c.r[10];  // 06042F62 mov r10,r0
    c.r[12] = ld32(c.r[0] + c.r[12]);  // 06042F64 mov.l @(r0,r12),r12
    c.r[11] = ld32(0x06042FE8u);  // 06042F66 mov.l 0x06042FE8,r11
    c.r[1] = c.r[12];  // 06042F68 mov r12,r1
    c.r[1] -= c.r[2];  // 06042F6A sub r2,r1
    st32(c.r[11], c.r[1]);  // 06042F6C mov.l r1,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06042FB6u);  // 06042F6E mov.w 0x06042FB6,r0
    st32(c.r[14] + 4, c.r[0]);  // 06042F70 mov.l r0,@(4,r14)
    c.r[1] = ld32(0x06043008u);  // 06042F72 mov.l 0x06043008,r1
    c.r[11] = ld32(0x06042FF4u);  // 06042F74 mov.l 0x06042FF4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042F7Au; c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F7Au) return; }  // 06042F76 jsr @r11 ; mov.b @r1,r4
    c.r[4] = c.r[0];  // 06042F7A mov r0,r4
    c.r[5] = c.r[1];  // 06042F7C mov r1,r5
    c.r[0] = ld32(0x06042FF8u);  // 06042F7E mov.l 0x06042FF8,r0
    c.r[6] = ld32(c.r[0]);  // 06042F80 mov.l @r0,r6
    c.r[1] = ld32(0x06042FFCu);  // 06042F82 mov.l 0x06042FFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06042F88u; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F88u) return; }  // 06042F84 jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 06042F88 mov r0,r4
    c.r[11] = ld32(0x06043000u);  // 06042F8A mov.l 0x06043000,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06042F90u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06042F90u) return; }  // 06042F8C jsr @r11 ; mov r1,r5
    c.r[2] = c.r[0];  // 06042F90 mov r0,r2
    c.r[0] = ld32(c.r[14] + 4);  // 06042F92 mov.l @(4,r14),r0
    c.r[10] = ld32(c.r[0] + c.r[10]);  // 06042F94 mov.l @(r0,r10),r10
    c.r[11] = ld32(0x06042FE4u);  // 06042F96 mov.l 0x06042FE4,r11
    c.r[1] = c.r[10];  // 06042F98 mov r10,r1
    c.r[1] -= c.r[2];  // 06042F9A sub r2,r1
    st32(c.r[11], c.r[1]);  // 06042F9C mov.l r1,@r11
    c.r[0] = ld32(0x06043018u);  // 06042F9E mov.l 0x06043018,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06042FA0 mov.b @r0,r0
    c.r[2] = ld32(0x0604301Cu);  // 06042FA2 mov.l 0x0604301C,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06042FA4 mov.b @r2,r2
    c.r[1] = c.r[0] & 0xFFu;  // 06042FA6 extu.b r0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06042FA8 extu.b r2,r2
    c.r[0] = c.r[1];  // 06042FAA mov r1,r0
    c.t = c.r[0] == c.r[2]; goto L_06043020;  // 06042FAC bra 0x06043020 ; cmp/eq r2,r0
L_06043020:
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0604303C; } }  // 06043020 bt/s 0x0604303C ; tst r2,r2
    { const bool k = c.t; c.r[5] = 0x3u; if (k) { goto L_0604302E; } }  // 06043024 bt/s 0x0604302E ; mov #3,r5
    c.r[1] = ld32(0x0604313Cu);  // 06043028 mov.l 0x0604313C,r1
    c.r[5] = 0x6u; goto L_06043030;  // 0604302A bra 0x06043030 ; mov #6,r5
L_0604302E:
    c.r[1] = ld32(0x0604313Cu);  // 0604302E mov.l 0x0604313C,r1
L_06043030:
    { const uint32_t x = c.r[1]; c.pr = 0x06043034u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043034u) return; }  // 06043030 jsr @r1 ; mov #3,r4
    c.r[2] = ld32(0x06043140u);  // 06043034 mov.l 0x06043140,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06043036 mov.b @r2,r2
    c.r[1] = ld32(0x06043144u);  // 06043038 mov.l 0x06043144,r1
    st8(c.r[1], c.r[2]);  // 0604303A mov.b r2,@r1
L_0604303C:
    c.r[2] = ld32(0x06043148u);  // 0604303C mov.l 0x06043148,r2
    c.r[1] = c.r[2];  // 0604303E mov r2,r1
    c.r[1] += 1;  // 06043040 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06043042 mov.b @r1,r1
    c.r[3] = ld32(0x06043140u);  // 06043044 mov.l 0x06043140,r3
    c.r[0] = c.r[1];  // 06043046 mov r1,r0
    c.r[0] >>= 2;  // 06043048 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604304A shlr r0
    c.r[0] &= 0x1u;  // 0604304C and #1,r0
    st8(c.r[3], c.r[0]);  // 0604304E mov.b r0,@r3
    c.r[3] = ld32(c.r[2] + 24);  // 06043050 mov.l @(24,r2),r3
    c.r[1] = ld32(c.r[2] + 28);  // 06043052 mov.l @(28,r2),r1
    c.r[3] |= c.r[1];  // 06043054 or r1,r3
    c.r[1] = ld32(c.r[2] + 32);  // 06043056 mov.l @(32,r2),r1
    c.r[9] = ld32(0x0604314Cu);  // 06043058 mov.l 0x0604314C,r9
    c.r[3] |= c.r[1];  // 0604305A or r1,r3
    c.r[1] = ld32(c.r[2] + 36);  // 0604305C mov.l @(36,r2),r1
    c.r[10] = ld32(0x06043150u);  // 0604305E mov.l 0x06043150,r10
    c.r[3] |= c.r[1];  // 06043060 or r1,r3
    st32(c.r[9], c.r[3]);  // 06043062 mov.l r3,@r9
    c.r[1] = ld32(c.r[10]);  // 06043064 mov.l @r10,r1
    c.r[8] = ld32(0x06043154u);  // 06043066 mov.l 0x06043154,r8
    c.r[4] = ld32(c.r[8]);  // 06043068 mov.l @r8,r4
    c.t = c.r[1] == c.r[4];  // 0604306A cmp/eq r4,r1
    if (c.t) { goto L_06043078; }  // 0604306C bt 0x06043078
    c.r[0] = ld32(0x06043158u);  // 0604306E mov.l 0x06043158,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06043074u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043074u) return; }  // 06043070 jsr @r0 ; nop
    c.r[1] = ld32(c.r[8]);  // 06043074 mov.l @r8,r1
    st32(c.r[10], c.r[1]);  // 06043076 mov.l r1,@r10
L_06043078:
    c.r[1] = ld32(c.r[9]);  // 06043078 mov.l @r9,r1
    st32(c.r[8], c.r[1]); goto L_06043124;  // 0604307A bra 0x06043124 ; mov.l r1,@r8
L_0604307E:
    c.r[8] = ld32(0x06043148u);  // 0604307E mov.l 0x06043148,r8
    c.r[1] = c.r[8];  // 06043080 mov r8,r1
    c.r[1] += 80;  // 06043082 add #80,r1
    c.r[5] = ld32(c.r[1]);  // 06043084 mov.l @r1,r5
    c.r[1] = c.r[8];  // 06043086 mov r8,r1
    c.r[1] += 76;  // 06043088 add #76,r1
    c.r[4] = ld32(c.r[1]);  // 0604308A mov.l @r1,r4
    c.r[1] = ld32(0x0604315Cu);  // 0604308C mov.l 0x0604315C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043092u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043092u) return; }  // 0604308E jsr @r1 ; nop
    c.r[4] = ld32(c.r[8] + 24);  // 06043092 mov.l @(24,r8),r4
    c.r[1] = ld32(c.r[8] + 28);  // 06043094 mov.l @(28,r8),r1
    c.r[4] |= c.r[1];  // 06043096 or r1,r4
    c.r[1] = ld32(c.r[8] + 32);  // 06043098 mov.l @(32,r8),r1
    c.r[4] |= c.r[1];  // 0604309A or r1,r4
    c.r[1] = ld32(c.r[8] + 36);  // 0604309C mov.l @(36,r8),r1
    c.r[4] |= c.r[1];  // 0604309E or r1,r4
    c.r[1] = ld32(c.r[8] + 40);  // 060430A0 mov.l @(40,r8),r1
    c.r[9] = ld32(0x0604314Cu);  // 060430A2 mov.l 0x0604314C,r9
    c.r[4] |= c.r[1];  // 060430A4 or r1,r4
    st32(c.r[9], c.r[4]);  // 060430A6 mov.l r4,@r9
    c.r[1] = ld32(0x06043150u);  // 060430A8 mov.l 0x06043150,r1
    c.r[1] = ld32(c.r[1]);  // 060430AA mov.l @r1,r1
    c.t = c.r[1] == c.r[4];  // 060430AC cmp/eq r4,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060430DC; } }  // 060430AE bt/s 0x060430DC ; mov r8,r1
    c.r[1] += 1;  // 060430B2 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060430B4 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060430B6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060430B8 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_060430D6; } }  // 060430BA bt/s 0x060430D6 ; mov #4,r1
    st32(c.r[8] + 32, c.r[1]);  // 060430BE mov.l r1,@(32,r8)
    c.r[7] = ld32(0x06043160u);  // 060430C0 mov.l 0x06043160,r7
    c.r[6] = ld32(0x06043164u);  // 060430C2 mov.l 0x06043164,r6
    c.r[4] = ld32(0x06043168u);  // 060430C4 mov.l 0x06043168,r4
    c.r[1] = ld32(0x0604316Cu);  // 060430C6 mov.l 0x0604316C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060430CCu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060430CCu) return; }  // 060430C8 jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x06043170u);  // 060430CC mov.l 0x06043170,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060430D2u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060430D2u) return; }  // 060430CE jsr @r1 ; mov.l @r9,r4
    goto L_060430DC;  // 060430D2 bra 0x060430DC ; nop
L_060430D6:
    c.r[0] = ld32(0x06043158u);  // 060430D6 mov.l 0x06043158,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060430DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060430DCu) return; }  // 060430D8 jsr @r0 ; nop
L_060430DC:
    c.r[2] = ld32(0x06043150u);  // 060430DC mov.l 0x06043150,r2
    c.r[1] = ld32(0x0604314Cu);  // 060430DE mov.l 0x0604314C,r1
    c.r[1] = ld32(c.r[1]);  // 060430E0 mov.l @r1,r1
    c.r[8] = ld32(0x06043148u);  // 060430E2 mov.l 0x06043148,r8
    st32(c.r[2], c.r[1]);  // 060430E4 mov.l r1,@r2
    c.r[2] = c.r[8];  // 060430E6 mov r8,r2
    c.r[1] = c.r[8];  // 060430E8 mov r8,r1
    c.r[1] += 116;  // 060430EA add #116,r1
    c.r[1] = ld32(c.r[1]);  // 060430EC mov.l @r1,r1
    c.r[2] += 76;  // 060430EE add #76,r2
    st32(c.r[2], c.r[1]);  // 060430F0 mov.l r1,@r2
    c.r[2] = c.r[8];  // 060430F2 mov r8,r2
    c.r[1] = c.r[8];  // 060430F4 mov r8,r1
    c.r[1] += 120;  // 060430F6 add #120,r1
    c.r[1] = ld32(c.r[1]);  // 060430F8 mov.l @r1,r1
    c.r[2] += 80;  // 060430FA add #80,r2
    st32(c.r[2], c.r[1]);  // 060430FC mov.l r1,@r2
    c.r[1] = c.r[8];  // 060430FE mov r8,r1
    c.r[1] += 20;  // 06043100 add #20,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06043102 mov.w @r1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06043104 extu.w r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06043106 tst r4,r4
    if (c.t) { goto L_06043124; }  // 06043108 bt 0x06043124
    c.r[1] = ld32(0x06043174u);  // 0604310A mov.l 0x06043174,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043110u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043110u) return; }  // 0604310C jsr @r1 ; nop
    c.r[1] = c.r[8];  // 06043110 mov r8,r1
    c.r[1] += 18;  // 06043112 add #18,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06043114 mov.w @r1,r6
    c.r[1] = c.r[8];  // 06043116 mov r8,r1
    c.r[1] += 16;  // 06043118 add #16,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604311A mov.w @r1,r5
    c.r[8] += 14;  // 0604311C add #14,r8
    c.r[1] = ld32(0x06043178u);  // 0604311E mov.l 0x06043178,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043124u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043124u) return; }  // 06043120 jsr @r1 ; mov.w @r8,r4
L_06043124:
    c.r[14] += 8;  // 06043124 add #8,r14
    c.r[15] = c.r[14];  // 06043126 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06043128 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604312A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604312C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604312E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06043130 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06043132 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06043134 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043136 rts ; mov.l @r15+,r8
}

void f_0604317C(SH2Context& c) {
    ran[1071] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604317C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604317E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043180 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06043182 sts.l pr,@-r15
    c.r[9] = ld32(0x060431E4u);  // 06043184 mov.l 0x060431E4,r9
    c.r[2] = c.r[9];  // 06043186 mov r9,r2
    c.r[2] += 1;  // 06043188 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604318A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0604318C mov r1,r0
    c.r[0] >>= 2;  // 0604318E shlr2 r0
    c.r[0] >>= 2;  // 06043190 shlr2 r0
    c.r[0] >>= 2;  // 06043192 shlr2 r0
    c.r[0] &= 0x1u;  // 06043194 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06043196 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060431A2; } }  // 06043198 bt/s 0x060431A2 ; mov r15,r14
    c.r[9] += 2;  // 0604319C add #2,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); goto L_060431CC;  // 0604319E bra 0x060431CC ; mov.w @r9,r4
L_060431A2:
    c.r[0] = c.r[1];  // 060431A2 mov r1,r0
    c.r[0] |= 0x40u;  // 060431A4 or #64,r0
    st8(c.r[2], c.r[0]);  // 060431A6 mov.b r0,@r2
    c.r[1] = ld32(0x060431E8u);  // 060431A8 mov.l 0x060431E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060431AEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060431AEu) return; }  // 060431AA jsr @r1 ; mov #6,r4
    c.r[1] = ld32(0x060431ECu);  // 060431AE mov.l 0x060431EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060431B4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060431B4u) return; }  // 060431B0 jsr @r1 ; mov #1,r4
    c.r[8] = c.r[9];  // 060431B4 mov r9,r8
    c.r[8] += 2;  // 060431B6 add #2,r8
    c.r[9] += 4;  // 060431B8 add #4,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060431BA mov.w @r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060431E0u);  // 060431BC mov.w 0x060431E0,r1
    c.r[4] |= c.r[1];  // 060431BE or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060431C0 mov.w @r8,r1
    c.r[4] |= c.r[1];  // 060431C2 or r1,r4
    c.r[1] = ld32(0x060431F0u);  // 060431C4 mov.l 0x060431F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060431CAu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060431CAu) return; }  // 060431C6 jsr @r1 ; extu.w r4,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060431CA mov.w @r8,r4
L_060431CC:
    c.r[1] = ld32(0x060431F4u);  // 060431CC mov.l 0x060431F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060431D2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060431D2u) return; }  // 060431CE jsr @r1 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 060431D2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060431D4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060431D6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060431D8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060431DA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060431DC rts ; mov #1,r0
}

void f_060431F8(SH2Context& c) {
    ran[1072] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060431F8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060431FA mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060431FC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060431FE rts ; mov #1,r0
}

void f_06043204(SH2Context& c) {
    ran[1073] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043204 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043206 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043208 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604320A rts ; mov #1,r0
}

void f_06043210(SH2Context& c) {
    ran[1074] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043210 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043212 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043214 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043216 rts ; mov #1,r0
}

void f_0604321C(SH2Context& c) {
    ran[1075] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604321C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604321E mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043220 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043222 rts ; mov #1,r0
}

void f_06043228(SH2Context& c) {
    ran[1076] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043228 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604322A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604322C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604322E rts ; mov #1,r0
}

void f_06043234(SH2Context& c) {
    ran[1077] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043234 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043236 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043238 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604323A rts ; mov #1,r0
}

void f_06043240(SH2Context& c) {
    ran[1078] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043240 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043242 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043244 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043246 rts ; mov #1,r0
}

void f_0604324C(SH2Context& c) {
    ran[1079] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604324C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604324E mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043250 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043252 rts ; mov #1,r0
}

void f_06043258(SH2Context& c) {
    ran[1080] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043258 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604325A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604325C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604325E rts ; mov #1,r0
}

void f_06043264(SH2Context& c) {
    ran[1081] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043264 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043266 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043268 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604326A rts ; mov #1,r0
}

void f_06043270(SH2Context& c) {
    ran[1082] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043270 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043272 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043274 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043276 rts ; mov #1,r0
}

void f_0604327C(SH2Context& c) {
    ran[1083] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604327C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604327E mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043280 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043282 rts ; mov #1,r0
}

void f_06043288(SH2Context& c) {
    ran[1084] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043288 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604328A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604328C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604328E rts ; mov #1,r0
}

void f_06043294(SH2Context& c) {
    ran[1085] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043294 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043296 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043298 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604329A rts ; mov #1,r0
}

void f_060432A0(SH2Context& c) {
    ran[1086] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060432A0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060432A2 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060432A4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060432A6 rts ; mov #1,r0
}

void f_060432AC(SH2Context& c) {
    ran[1087] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060432AC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060432AE mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060432B0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060432B2 rts ; mov #1,r0
}

void f_060432B8(SH2Context& c) {
    ran[1088] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060432B8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060432BA mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060432BC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060432BE rts ; mov #1,r0
}

void f_060432C4(SH2Context& c) {
    ran[1089] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060432C4 mov.l r14,@-r15
    c.r[3] = ld32(0x0604330Cu);  // 060432C6 mov.l 0x0604330C,r3
    c.r[7] = c.r[3];  // 060432C8 mov r3,r7
    c.r[7] += 1;  // 060432CA add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060432CC mov.b @r7,r1
    c.r[0] = c.r[1];  // 060432CE mov r1,r0
    c.r[0] >>= 2;  // 060432D0 shlr2 r0
    c.r[0] >>= 2;  // 060432D2 shlr2 r0
    c.r[0] >>= 2;  // 060432D4 shlr2 r0
    c.r[0] &= 0x1u;  // 060432D6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060432D8 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060432FE; } }  // 060432DA bf/s 0x060432FE ; mov r15,r14
    c.r[0] = c.r[1];  // 060432DE mov r1,r0
    c.r[0] |= 0x40u;  // 060432E0 or #64,r0
    st8(c.r[7], c.r[0]);  // 060432E2 mov.b r0,@r7
    c.r[1] = c.r[3];  // 060432E4 mov r3,r1
    c.r[1] += 2;  // 060432E6 add #2,r1
    c.r[2] = 0x0u;  // 060432E8 mov #0,r2
    st16(c.r[1], c.r[2]);  // 060432EA mov.w r2,@r1
    c.r[1] = c.r[3];  // 060432EC mov r3,r1
    c.r[1] += 4;  // 060432EE add #4,r1
    st16(c.r[1], c.r[2]);  // 060432F0 mov.w r2,@r1
    c.r[0] &= 0xCFu;  // 060432F2 and #207,r0
    st8(c.r[7], c.r[0]);  // 060432F4 mov.b r0,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043306u);  // 060432F6 mov.w 0x06043306,r0
    st16(c.r[0] + c.r[3], c.r[2]);  // 060432F8 mov.w r2,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043308u);  // 060432FA mov.w 0x06043308,r0
    st16(c.r[0] + c.r[3], c.r[2]);  // 060432FC mov.w r2,@(r0,r3)
L_060432FE:
    c.r[15] = c.r[14];  // 060432FE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043300 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043302 rts ; mov #1,r0
}

void f_06043310(SH2Context& c) {
    ran[1090] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043310 mov.l r14,@-r15
    c.r[3] = ld32(0x06043358u);  // 06043312 mov.l 0x06043358,r3
    c.r[7] = c.r[3];  // 06043314 mov r3,r7
    c.r[7] += 1;  // 06043316 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06043318 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0604331A mov r1,r0
    c.r[0] >>= 2;  // 0604331C shlr2 r0
    c.r[0] >>= 2;  // 0604331E shlr2 r0
    c.r[0] >>= 2;  // 06043320 shlr2 r0
    c.r[0] &= 0x1u;  // 06043322 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06043324 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604334C; } }  // 06043326 bf/s 0x0604334C ; mov r15,r14
    c.r[0] = c.r[1];  // 0604332A mov r1,r0
    c.r[0] |= 0x40u;  // 0604332C or #64,r0
    st8(c.r[7], c.r[0]);  // 0604332E mov.b r0,@r7
    c.r[1] = c.r[3];  // 06043330 mov r3,r1
    c.r[1] += 2;  // 06043332 add #2,r1
    c.r[2] = 0x0u;  // 06043334 mov #0,r2
    st16(c.r[1], c.r[2]);  // 06043336 mov.w r2,@r1
    c.r[1] = c.r[3];  // 06043338 mov r3,r1
    c.r[1] += 4;  // 0604333A add #4,r1
    st16(c.r[1], c.r[2]);  // 0604333C mov.w r2,@r1
    c.r[0] &= 0xCFu;  // 0604333E and #207,r0
    c.r[0] |= 0x20u;  // 06043340 or #32,r0
    st8(c.r[7], c.r[0]);  // 06043342 mov.b r0,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043354u);  // 06043344 mov.w 0x06043354,r0
    st16(c.r[0] + c.r[3], c.r[2]);  // 06043346 mov.w r2,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043356u);  // 06043348 mov.w 0x06043356,r0
    st16(c.r[0] + c.r[3], c.r[2]);  // 0604334A mov.w r2,@(r0,r3)
L_0604334C:
    c.r[15] = c.r[14];  // 0604334C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604334E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06043350 rts ; mov #1,r0
}

void f_0604335C(SH2Context& c) {
    ran[1091] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604335C mov.l r14,@-r15
    c.r[3] = ld32(0x060433A4u);  // 0604335E mov.l 0x060433A4,r3
    c.r[7] = c.r[3];  // 06043360 mov r3,r7
    c.r[7] += 1;  // 06043362 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06043364 mov.b @r7,r1
    c.r[0] = c.r[1];  // 06043366 mov r1,r0
    c.r[0] >>= 2;  // 06043368 shlr2 r0
    c.r[0] >>= 2;  // 0604336A shlr2 r0
    c.r[0] >>= 2;  // 0604336C shlr2 r0
    c.r[0] &= 0x1u;  // 0604336E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06043370 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06043398; } }  // 06043372 bf/s 0x06043398 ; mov r15,r14
    c.r[0] = c.r[1];  // 06043376 mov r1,r0
    c.r[0] |= 0x40u;  // 06043378 or #64,r0
    st8(c.r[7], c.r[0]);  // 0604337A mov.b r0,@r7
    c.r[1] = c.r[3];  // 0604337C mov r3,r1
    c.r[1] += 2;  // 0604337E add #2,r1
    c.r[2] = 0x0u;  // 06043380 mov #0,r2
    st16(c.r[1], c.r[2]);  // 06043382 mov.w r2,@r1
    c.r[1] = c.r[3];  // 06043384 mov r3,r1
    c.r[1] += 4;  // 06043386 add #4,r1
    st16(c.r[1], c.r[2]);  // 06043388 mov.w r2,@r1
    c.r[0] &= 0xCFu;  // 0604338A and #207,r0
    st8(c.r[7], c.r[0]);  // 0604338C mov.b r0,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060433A0u);  // 0604338E mov.w 0x060433A0,r0
    c.r[1] = 0x5u;  // 06043390 mov #5,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 06043392 mov.w r1,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060433A2u);  // 06043394 mov.w 0x060433A2,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06043396 mov.w r1,@(r0,r3)
L_06043398:
    c.r[15] = c.r[14];  // 06043398 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604339A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0604339C rts ; mov #1,r0
}

void f_060433A8(SH2Context& c) {
    ran[1092] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060433A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060433AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060433AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060433AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060433B0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060433B2 mov r15,r14
    c.r[0] = c.r[5];  // 060433B4 mov r5,r0
    c.r[3] = c.r[4] & 0xFFFFu;  // 060433B6 extu.w r4,r3
    c.r[0] &= 0x1u;  // 060433B8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060433BA tst r0,r0
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_060433C2; } }  // 060433BC bf/s 0x060433C2 ; mov #0,r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x060434BCu);  // 060433C0 mov.w 0x060434BC,r2
L_060433C2:
    c.r[0] = c.r[3];  // 060433C2 mov r3,r0
    c.t = c.r[0] == 0x2u;  // 060433C4 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06043404; } }  // 060433C6 bt/s 0x06043404 ; mov #2,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060433CA cmp/gt r1,r3
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_060433DA; } }  // 060433CC bt/s 0x060433DA ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060433D0 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_060433E2; } }  // 060433D2 bt/s 0x060433E2 ; mov #3,r0
    c.r[15] = c.r[14]; goto L_060434B0;  // 060433D6 bra 0x060434B0 ; mov r14,r15
L_060433DA:
    if (c.t) { goto L_06043424; }  // 060433DA bt 0x06043424
    c.r[15] = c.r[14];  // 060433DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060434B2;  // 060433DE bra 0x060434B2 ; lds.l @r15+,pr
L_060433E2:
    c.r[2] |= c.r[0];  // 060433E2 or r0,r2
    c.r[8] = ld32(0x060434C8u);  // 060433E4 mov.l 0x060434C8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434BEu);  // 060433E6 mov.w 0x060434BE,r1
    c.r[0] = c.r[8];  // 060433E8 mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060433EA mov.w @(r0,r1),r4
    c.r[5] = c.r[2] & 0xFFFFu;  // 060433EC extu.w r2,r5
    c.r[1] = ld32(0x060434CCu);  // 060433EE mov.l 0x060434CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060433F4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060433F4u) return; }  // 060433F0 jsr @r1 ; extu.w r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434C0u);  // 060433F4 mov.w 0x060434C0,r1
    c.r[0] = c.r[8];  // 060433F6 mov r8,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 060433F8 mov.l @(r0,r1),r4
    c.r[1] = ld32(0x060434D0u);  // 060433FA mov.l 0x060434D0,r1
    c.r[4] |= c.r[1];  // 060433FC or r1,r4
    c.r[1] = ld32(0x060434D4u);  // 060433FE mov.l 0x060434D4,r1
    goto L_060434AA;  // 06043400 bra 0x060434AA ; nop
L_06043404:
    c.r[0] = 0xCu;  // 06043404 mov #12,r0
    c.r[2] |= c.r[0];  // 06043406 or r0,r2
    c.r[8] = ld32(0x060434C8u);  // 06043408 mov.l 0x060434C8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434BEu);  // 0604340A mov.w 0x060434BE,r1
    c.r[0] = c.r[8];  // 0604340C mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604340E mov.w @(r0,r1),r4
    c.r[5] = c.r[2] & 0xFFFFu;  // 06043410 extu.w r2,r5
    c.r[1] = ld32(0x060434CCu);  // 06043412 mov.l 0x060434CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043418u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043418u) return; }  // 06043414 jsr @r1 ; extu.w r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434C2u);  // 06043418 mov.w 0x060434C2,r1
    c.r[0] = c.r[8];  // 0604341A mov r8,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0604341C mov.l @(r0,r1),r4
    c.r[1] = ld32(0x060434D0u);  // 0604341E mov.l 0x060434D0,r1
    c.r[4] |= c.r[1]; goto L_060434A8;  // 06043420 bra 0x060434A8 ; or r1,r4
L_06043424:
    c.r[10] = ld32(0x060434C8u);  // 06043424 mov.l 0x060434C8,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434C4u);  // 06043426 mov.w 0x060434C4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06043428 mov.w @(r0,r10),r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0604342A extu.w r1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0604342C tst r9,r9
    { const bool k = c.t; c.r[0] = 0xFu; if (k) { goto L_06043482; } }  // 0604342E bt/s 0x06043482 ; mov #15,r0
    c.r[0] = c.r[9];  // 06043432 mov r9,r0
    c.t = c.r[0] == 0x6u;  // 06043434 cmp/eq #6,r0
    { const bool k = !c.t; c.r[5] = c.r[3]; if (k) { goto L_06043460; } }  // 06043436 bf/s 0x06043460 ; mov r3,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434BEu);  // 0604343A mov.w 0x060434BE,r0
    c.r[8] = ld32(0x060434CCu);  // 0604343C mov.l 0x060434CC,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0604343E mov.w @(r0,r10),r4
    { const uint32_t x = c.r[8]; c.pr = 0x06043444u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043444u) return; }  // 06043440 jsr @r8 ; extu.w r4,r4
    c.r[5] = 0xCu;  // 06043444 mov #12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604344Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604344Au) return; }  // 06043446 jsr @r8 ; mov r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434C0u);  // 0604344A mov.w 0x060434C0,r0
    c.r[8] = ld32(0x060434D0u);  // 0604344C mov.l 0x060434D0,r8
    c.r[4] = ld32(c.r[0] + c.r[10]);  // 0604344E mov.l @(r0,r10),r4
    c.r[1] = ld32(0x060434D4u);  // 06043450 mov.l 0x060434D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043456u; c.r[4] |= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043456u) return; }  // 06043452 jsr @r1 ; or r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434C2u);  // 06043456 mov.w 0x060434C2,r0
    c.r[4] = ld32(c.r[0] + c.r[10]);  // 06043458 mov.l @(r0,r10),r4
    c.r[1] = ld32(0x060434D8u);  // 0604345A mov.l 0x060434D8,r1
    c.r[4] |= c.r[8]; goto L_060434AA;  // 0604345C bra 0x060434AA ; or r8,r4
L_06043460:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060434C6u);  // 06043460 mov.w 0x060434C6,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434BEu);  // 06043462 mov.w 0x060434BE,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06043464 mov.w @(r0,r10),r4
    c.r[1] = ld32(0x060434CCu);  // 06043466 mov.l 0x060434CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604346Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604346Cu) return; }  // 06043468 jsr @r1 ; extu.w r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434C0u);  // 0604346C mov.w 0x060434C0,r0
    c.r[8] = ld32(0x060434D0u);  // 0604346E mov.l 0x060434D0,r8
    c.r[4] = ld32(c.r[0] + c.r[10]);  // 06043470 mov.l @(r0,r10),r4
    c.r[1] = ld32(0x060434D4u);  // 06043472 mov.l 0x060434D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043478u; c.r[4] |= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043478u) return; }  // 06043474 jsr @r1 ; or r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060434C2u);  // 06043478 mov.w 0x060434C2,r0
    c.r[4] = ld32(c.r[0] + c.r[10]);  // 0604347A mov.l @(r0,r10),r4
    c.r[1] = ld32(0x060434D8u);  // 0604347C mov.l 0x060434D8,r1
    c.r[4] |= c.r[8]; goto L_060434AA;  // 0604347E bra 0x060434AA ; or r8,r4
L_06043482:
    c.r[2] |= c.r[0];  // 06043482 or r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434BEu);  // 06043484 mov.w 0x060434BE,r1
    c.r[0] = c.r[10];  // 06043486 mov r10,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06043488 mov.w @(r0,r1),r4
    c.r[5] = c.r[2] & 0xFFFFu;  // 0604348A extu.w r2,r5
    c.r[1] = ld32(0x060434CCu);  // 0604348C mov.l 0x060434CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043492u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043492u) return; }  // 0604348E jsr @r1 ; extu.w r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434C0u);  // 06043492 mov.w 0x060434C0,r1
    c.r[0] = c.r[10];  // 06043494 mov r10,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 06043496 mov.l @(r0,r1),r4
    c.r[8] = ld32(0x060434D0u);  // 06043498 mov.l 0x060434D0,r8
    c.r[1] = ld32(0x060434D4u);  // 0604349A mov.l 0x060434D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060434A0u; c.r[4] |= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060434A0u) return; }  // 0604349C jsr @r1 ; or r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060434C2u);  // 060434A0 mov.w 0x060434C2,r1
    c.r[0] = c.r[10];  // 060434A2 mov r10,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 060434A4 mov.l @(r0,r1),r4
    c.r[4] |= c.r[8];  // 060434A6 or r8,r4
L_060434A8:
    c.r[1] = ld32(0x060434D8u);  // 060434A8 mov.l 0x060434D8,r1
L_060434AA:
    { const uint32_t x = c.r[1]; c.pr = 0x060434AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060434AEu) return; }  // 060434AA jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060434AE mov r14,r15
L_060434B0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060434B0 lds.l @r15+,pr
L_060434B2:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060434B2 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060434B4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060434B6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060434B8 rts ; mov.l @r15+,r8
}

void f_060434DC(SH2Context& c) {
    ran[1093] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060434DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060434DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060434E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060434E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060434E4 sts.l pr,@-r15
    c.r[3] = ld32(0x06043554u);  // 060434E6 mov.l 0x06043554,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604354Au);  // 060434E8 mov.w 0x0604354A,r2
    c.r[0] = c.r[3];  // 060434EA mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060434EC mov.b @(r0,r2),r7
    c.r[1] = c.r[7] & 0xFFu;  // 060434EE extu.b r7,r1
    c.r[1] >>= 2;  // 060434F0 shlr2 r1
    c.r[1] >>= 2;  // 060434F2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060434F4 shlr r1
    c.r[1] >>= 2;  // 060434F6 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060434F8 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604351A; } }  // 060434FA bt/s 0x0604351A ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604354Cu);  // 060434FE mov.w 0x0604354C,r1
    c.r[1] &= c.r[7];  // 06043500 and r7,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06043502 mov.b r1,@(r0,r2)
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604354Eu);  // 06043504 mov.w 0x0604354E,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06043550u);  // 06043506 mov.w 0x06043550,r9
    c.r[4] = ld32(0x06043558u);  // 06043508 mov.l 0x06043558,r4
    c.r[10] = ld32(0x0604355Cu);  // 0604350A mov.l 0x0604355C,r10
    c.r[7] = c.r[8];  // 0604350C mov r8,r7
    c.r[6] = 0x1u;  // 0604350E mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06043514u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043514u) return; }  // 06043510 jsr @r10 ; mov r9,r5
    c.r[4] = ld32(0x06043560u);  // 06043514 mov.l 0x06043560,r4
    c.r[7] = c.r[8]; goto L_06043536;  // 06043516 bra 0x06043536 ; mov r8,r7
L_0604351A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043552u);  // 0604351A mov.w 0x06043552,r1
    c.r[1] &= c.r[7];  // 0604351C and r7,r1
    c.r[0] = c.r[3];  // 0604351E mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06043520 mov.b r1,@(r0,r2)
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604354Eu);  // 06043522 mov.w 0x0604354E,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06043550u);  // 06043524 mov.w 0x06043550,r9
    c.r[4] = ld32(0x06043564u);  // 06043526 mov.l 0x06043564,r4
    c.r[10] = ld32(0x0604355Cu);  // 06043528 mov.l 0x0604355C,r10
    c.r[7] = c.r[8];  // 0604352A mov r8,r7
    c.r[6] = 0x1u;  // 0604352C mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06043532u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043532u) return; }  // 0604352E jsr @r10 ; mov r9,r5
    c.r[4] = ld32(0x06043568u);  // 06043532 mov.l 0x06043568,r4
    c.r[7] = c.r[8];  // 06043534 mov r8,r7
L_06043536:
    c.r[6] = 0x1u;  // 06043536 mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0604353Cu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604353Cu) return; }  // 06043538 jsr @r10 ; mov r9,r5
    c.r[15] = c.r[14];  // 0604353C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604353E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043540 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06043542 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06043544 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043546 rts ; mov.l @r15+,r8
}

void f_0604356C(SH2Context& c) {
    ran[1094] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604356C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604356E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06043570 sts.l pr,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06043572 mov.b @r4,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06043574 extu.b r1,r2
    c.r[1] = c.r[2];  // 06043576 mov r2,r1
    c.r[1] >>= 2;  // 06043578 shlr2 r1
    c.r[1] >>= 2;  // 0604357A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604357C shlr r1
    c.r[1] >>= 2;  // 0604357E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06043580 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06043642; } }  // 06043582 bt/s 0x06043642 ; mov r15,r14
    c.r[0] = c.r[2];  // 06043586 mov r2,r0
    c.r[0] >>= 2;  // 06043588 shlr2 r0
    c.r[0] >>= 2;  // 0604358A shlr2 r0
    c.r[0] >>= 2;  // 0604358C shlr2 r0
    c.r[0] &= 0x1u;  // 0604358E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06043590 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06043642; } }  // 06043592 bt/s 0x06043642 ; mov r2,r0
    c.r[0] >>= 2;  // 06043596 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06043598 shlr r0
    c.r[0] >>= 2;  // 0604359A shlr2 r0
    c.r[0] &= 0x1u;  // 0604359C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604359E tst r0,r0
    if (c.t) { goto L_06043642; }  // 060435A0 bt 0x06043642
    c.r[8] = ld32(0x06043654u);  // 060435A2 mov.l 0x06043654,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604364Cu);  // 060435A4 mov.w 0x0604364C,r6
    c.r[0] = c.r[8];  // 060435A6 mov r8,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060435A8 mov.b @(r0,r6),r7
    c.r[3] = c.r[7] & 0xFFu;  // 060435AA extu.b r7,r3
    c.r[1] = c.r[3];  // 060435AC mov r3,r1
    c.r[1] >>= 2;  // 060435AE shlr2 r1
    c.r[1] >>= 2;  // 060435B0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060435B2 shlr r1
    c.r[1] >>= 2;  // 060435B4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060435B6 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_060435DE; } }  // 060435B8 bt/s 0x060435DE ; mov r2,r0
    c.r[0] >>= 2;  // 060435BC shlr2 r0
    c.r[1] = 0x3u;  // 060435BE mov #3,r1
    c.r[1] &= c.r[0];  // 060435C0 and r0,r1
    c.r[0] &= 0x2u;  // 060435C2 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060435C4 tst r0,r0
    c.r[5] = ld32(0x06043658u);  // 060435C6 mov.l 0x06043658,r5
    if (c.t) { goto L_060435CC; }  // 060435C8 bt 0x060435CC
    c.r[5] = ld32(0x0604365Cu);  // 060435CA mov.l 0x0604365C,r5
L_060435CC:
    c.r[3] >>= 2;  // 060435CC shlr2 r3
    c.r[3] >>= 2;  // 060435CE shlr2 r3
    c.r[0] = 0x3u;  // 060435D0 mov #3,r0
    c.r[3] &= c.r[0];  // 060435D2 and r0,r3
    c.r[3] |= c.r[1];  // 060435D4 or r1,r3
    c.r[3] <<= 2;  // 060435D6 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604364Eu);  // 060435D8 mov.w 0x0604364E,r1
    c.r[3] <<= 2; goto L_060435FA;  // 060435DA bra 0x060435FA ; shll2 r3
L_060435DE:
    c.r[0] >>= 2;  // 060435DE shlr2 r0
    c.r[1] = 0x3u;  // 060435E0 mov #3,r1
    c.r[1] &= c.r[0];  // 060435E2 and r0,r1
    c.r[0] &= 0x2u;  // 060435E4 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060435E6 tst r0,r0
    c.r[5] = ld32(0x06043660u);  // 060435E8 mov.l 0x06043660,r5
    if (c.t) { goto L_060435EE; }  // 060435EA bt 0x060435EE
    c.r[5] = ld32(0x06043664u);  // 060435EC mov.l 0x06043664,r5
L_060435EE:
    c.r[3] >>= 2;  // 060435EE shlr2 r3
    c.r[0] = 0x3u;  // 060435F0 mov #3,r0
    c.r[3] &= c.r[0];  // 060435F2 and r0,r3
    c.r[3] |= c.r[1];  // 060435F4 or r1,r3
    c.r[3] <<= 2;  // 060435F6 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043650u);  // 060435F8 mov.w 0x06043650,r1
L_060435FA:
    c.r[1] &= c.r[7];  // 060435FA and r7,r1
    c.r[1] |= c.r[3];  // 060435FC or r3,r1
    c.r[0] = c.r[8];  // 060435FE mov r8,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06043600 mov.b r1,@(r0,r6)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06043602 mov.b @r4,r1
    c.r[2] = 0x3u;  // 06043604 mov #3,r2
    c.r[2] &= c.r[1];  // 06043606 and r1,r2
    c.r[0] = c.r[2];  // 06043608 mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0604360A cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06043632; } }  // 0604360C bt/s 0x06043632 ; mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06043610 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06043620; } }  // 06043612 bt/s 0x06043620 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 06043616 cmp/eq #1,r0
    if (c.t) { goto L_06043628; }  // 06043618 bt 0x06043628
    c.r[15] = c.r[14];  // 0604361A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06043646;  // 0604361C bra 0x06043646 ; lds.l @r15+,pr
L_06043620:
    if (c.t) { goto L_0604363C; }  // 06043620 bt 0x0604363C
    c.r[15] = c.r[14];  // 06043622 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06043646;  // 06043624 bra 0x06043646 ; lds.l @r15+,pr
L_06043628:
    c.r[1] = ld32(0x06043668u);  // 06043628 mov.l 0x06043668,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604362Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604362Eu) return; }  // 0604362A jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_06043644;  // 0604362E bra 0x06043644 ; mov r14,r15
L_06043632:
    c.r[1] = ld32(0x0604366Cu);  // 06043632 mov.l 0x0604366C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043638u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043638u) return; }  // 06043634 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_06043644;  // 06043638 bra 0x06043644 ; mov r14,r15
L_0604363C:
    c.r[1] = ld32(0x06043670u);  // 0604363C mov.l 0x06043670,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043642u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043642u) return; }  // 0604363E jsr @r1 ; nop
L_06043642:
    c.r[15] = c.r[14];  // 06043642 mov r14,r15
L_06043644:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06043644 lds.l @r15+,pr
L_06043646:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043646 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043648 rts ; mov.l @r15+,r8
}

void f_06043674(SH2Context& c) {
    ran[1095] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06043674 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06043676 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06043678 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604367A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604367C mov.l r14,@-r15
    c.r[1] = ld32(0x06043738u);  // 0604367E mov.l 0x06043738,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043732u);  // 06043680 mov.w 0x06043732,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06043682 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06043684 extu.b r1,r1
    c.r[1] >>= 2;  // 06043686 shlr2 r1
    c.r[1] >>= 2;  // 06043688 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604368A shlr r1
    c.r[1] >>= 2;  // 0604368C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604368E tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604369C; } }  // 06043690 bt/s 0x0604369C ; mov r15,r14
    c.r[4] = ld32(0x0604373Cu);  // 06043694 mov.l 0x0604373C,r4
    c.r[5] = ld32(0x06043740u);  // 06043696 mov.l 0x06043740,r5
    goto L_060436A0;  // 06043698 bra 0x060436A0 ; nop
L_0604369C:
    c.r[4] = ld32(0x06043744u);  // 0604369C mov.l 0x06043744,r4
    c.r[5] = ld32(0x06043748u);  // 0604369E mov.l 0x06043748,r5
L_060436A0:
    c.r[1] = ld32(0x0604374Cu);  // 060436A0 mov.l 0x0604374C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060436A2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060436A4 mov r1,r0
    c.r[0] >>= 2;  // 060436A6 shlr2 r0
    c.r[0] >>= 2;  // 060436A8 shlr2 r0
    c.r[0] &= 0x3u;  // 060436AA and #3,r0
    c.t = c.r[0] == 0x2u;  // 060436AC cmp/eq #2,r0
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_06043784; } }  // 060436AE bf/s 0x06043784 ; mov #0,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x06043734u);  // 060436B2 mov.w 0x06043734,r10
    c.r[11] = c.r[9];  // 060436B4 mov r9,r11
L_060436B6:
    c.r[11] <<= 2;  // 060436B6 shll2 r11
    c.r[8] = c.r[11];  // 060436B8 mov r11,r8
    c.r[8] += c.r[4];  // 060436BA add r4,r8
    c.r[0] = c.r[11];  // 060436BC mov r11,r0
    c.r[8] += 2;  // 060436BE add #2,r8
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 060436C0 mov.w @(r0,r4),r3
    c.r[1] = c.r[11];  // 060436C2 mov r11,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060436C4 mov.w @r8,r6
    c.r[1] += c.r[5];  // 060436C6 add r5,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060436C8 mov.w @(r0,r5),r2
    c.r[1] += 2;  // 060436CA add #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 060436CC cmp/gt r3,r2
    { const bool k = c.t; c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]); if (k) { goto L_060436E8; } }  // 060436CE bt/s 0x060436E8 ; mov.w @r1,r7
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 060436D2 cmp/gt r7,r3
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[3]; if (k) { goto L_060436E8; } }  // 060436D4 bt/s 0x060436E8 ; cmp/gt r3,r2
    c.t = (int32_t)c.r[7] > (int32_t)c.r[6];  // 060436D8 cmp/gt r6,r7
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[3]; if (k) { goto L_060436E8; } }  // 060436DA bt/s 0x060436E8 ; cmp/gt r3,r2
    st16(c.r[0] + c.r[4], c.r[2]);  // 060436DE mov.w r2,@(r0,r4)
    st16(c.r[8], c.r[3]);  // 060436E0 mov.w r3,@r8
    st16(c.r[0] + c.r[5], c.r[7]);  // 060436E2 mov.w r7,@(r0,r5)
    st16(c.r[1], c.r[6]); goto L_06043778;  // 060436E4 bra 0x06043778 ; mov.w r6,@r1
L_060436E8:
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[2]; if (k) { goto L_06043708; } }  // 060436E8 bt/s 0x06043708 ; cmp/gt r2,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 060436EC cmp/gt r6,r3
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[2]; if (k) { goto L_06043708; } }  // 060436EE bt/s 0x06043708 ; cmp/gt r2,r3
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 060436F2 cmp/gt r7,r6
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[2]; if (k) { goto L_06043708; } }  // 060436F4 bt/s 0x06043708 ; cmp/gt r2,r3
    c.r[0] = c.r[9];  // 060436F8 mov r9,r0
    c.r[0] <<= 2;  // 060436FA shll2 r0
    c.r[1] = c.r[0];  // 060436FC mov r0,r1
    c.r[1] += c.r[4];  // 060436FE add r4,r1
    st16(c.r[0] + c.r[4], c.r[2]);  // 06043700 mov.w r2,@(r0,r4)
    c.r[1] += 2;  // 06043702 add #2,r1
    st16(c.r[1], c.r[3]); goto L_0604376E;  // 06043704 bra 0x0604376E ; mov.w r3,@r1
L_06043708:
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[2]; if (k) { goto L_06043750; } }  // 06043708 bt/s 0x06043750 ; cmp/gt r2,r3
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0604370C cmp/gt r7,r2
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[2]; if (k) { goto L_06043750; } }  // 0604370E bt/s 0x06043750 ; cmp/gt r2,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[6];  // 06043712 cmp/gt r6,r7
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[2]; if (k) { goto L_06043750; } }  // 06043714 bt/s 0x06043750 ; cmp/gt r2,r3
    c.r[0] = c.r[9];  // 06043718 mov r9,r0
    c.r[0] <<= 2;  // 0604371A shll2 r0
    c.r[1] = c.r[0];  // 0604371C mov r0,r1
    c.r[1] += c.r[4];  // 0604371E add r4,r1
    st16(c.r[0] + c.r[4], c.r[3]);  // 06043720 mov.w r3,@(r0,r4)
    c.r[1] += 2;  // 06043722 add #2,r1
    st16(c.r[1], c.r[2]);  // 06043724 mov.w r2,@r1
    c.r[1] = c.r[0];  // 06043726 mov r0,r1
    c.r[1] += c.r[5];  // 06043728 add r5,r1
    st16(c.r[0] + c.r[5], c.r[7]);  // 0604372A mov.w r7,@(r0,r5)
    c.r[1] += 2;  // 0604372C add #2,r1
    st16(c.r[1], c.r[6]); goto L_06043778;  // 0604372E bra 0x06043778 ; mov.w r6,@r1
L_06043750:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604377A; } }  // 06043750 bt/s 0x0604377A ; mov r9,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 06043754 cmp/gt r6,r2
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_0604377C; } }  // 06043756 bt/s 0x0604377C ; add #1,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 0604375A cmp/gt r7,r6
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0604377A; } }  // 0604375C bt/s 0x0604377A ; mov r9,r1
    c.r[0] = c.r[9];  // 06043760 mov r9,r0
    c.r[0] <<= 2;  // 06043762 shll2 r0
    c.r[1] = c.r[0];  // 06043764 mov r0,r1
    c.r[1] += c.r[4];  // 06043766 add r4,r1
    st16(c.r[0] + c.r[4], c.r[3]);  // 06043768 mov.w r3,@(r0,r4)
    c.r[1] += 2;  // 0604376A add #2,r1
    st16(c.r[1], c.r[2]);  // 0604376C mov.w r2,@r1
L_0604376E:
    c.r[1] = c.r[0];  // 0604376E mov r0,r1
    c.r[1] += c.r[5];  // 06043770 add r5,r1
    st16(c.r[0] + c.r[5], c.r[6]);  // 06043772 mov.w r6,@(r0,r5)
    c.r[1] += 2;  // 06043774 add #2,r1
    st16(c.r[1], c.r[7]);  // 06043776 mov.w r7,@r1
L_06043778:
    c.r[1] = c.r[9];  // 06043778 mov r9,r1
L_0604377A:
    c.r[1] += 1;  // 0604377A add #1,r1
L_0604377C:
    c.r[9] = c.r[1] & 0xFFFFu;  // 0604377C extu.w r1,r9
    c.t = c.r[9] > c.r[10];  // 0604377E cmp/hi r10,r9
    { const bool k = !c.t; c.r[11] = c.r[9]; if (k) { SH2_POLL(c); goto L_060436B6; } }  // 06043780 bf/s 0x060436B6 ; mov r9,r11
L_06043784:
    c.r[1] = ld32(0x060437C0u);  // 06043784 mov.l 0x060437C0,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060437BEu);  // 06043786 mov.w 0x060437BE,r3
    c.r[0] = c.r[1];  // 06043788 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0604378A mov.b @(r0,r3),r2
    c.r[15] = c.r[14];  // 0604378C mov r14,r15
    c.r[7] = c.r[2] & 0xFFu;  // 0604378E extu.b r2,r7
    c.r[7] >>= 2;  // 06043790 shlr2 r7
    c.r[7] >>= 2;  // 06043792 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06043794 shlr r7
    c.r[7] >>= 2;  // 06043796 shlr2 r7
    c.r[0] = 0x1u;  // 06043798 mov #1,r0
    c.r[7] ^= c.r[0];  // 0604379A xor r0,r7
    c.r[7] <<= 2;  // 0604379C shll2 r7
    c.r[7] <<= 2;  // 0604379E shll2 r7
    c.r[7] += c.r[7];  // 060437A0 add r7,r7
    c.r[7] <<= 2;  // 060437A2 shll2 r7
    c.r[0] = 0x7Fu;  // 060437A4 mov #127,r0
    c.r[2] &= c.r[0];  // 060437A6 and r0,r2
    c.r[2] |= c.r[7];  // 060437A8 or r7,r2
    c.r[0] = 0x40u;  // 060437AA mov #64,r0
    c.r[2] |= c.r[0];  // 060437AC or r0,r2
    c.r[0] = c.r[1];  // 060437AE mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 060437B0 mov.b r2,@(r0,r3)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060437B2 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060437B4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060437B6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060437B8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060437BA rts ; mov.l @r15+,r8
}

void f_060437C4(SH2Context& c) {
    ran[1096] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060437C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060437C6 sts.l pr,@-r15
    c.r[1] = ld32(0x060438D8u);  // 060437C8 mov.l 0x060438D8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060437CA mov.w @r1,r0
    c.r[0] &= 0x20u;  // 060437CC and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060437CE tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060437D8; } }  // 060437D0 bf/s 0x060437D8 ; mov r15,r14
    goto L_06043986;  // 060437D4 bra 0x06043986 ; nop
L_060437D8:
    c.r[1] = ld32(0x060438DCu);  // 060437D8 mov.l 0x060438DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CAu);  // 060437DA mov.w 0x060438CA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060437DC mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060437DE extu.b r1,r2
    c.r[0] = c.r[2];  // 060437E0 mov r2,r0
    c.r[0] >>= 2;  // 060437E2 shlr2 r0
    c.r[0] >>= 2;  // 060437E4 shlr2 r0
    c.r[0] >>= 2;  // 060437E6 shlr2 r0
    c.r[0] &= 0x1u;  // 060437E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060437EA tst r0,r0
    if (c.t) { goto L_060438AE; }  // 060437EC bt 0x060438AE
    c.r[1] = ld32(0x060438E0u);  // 060437EE mov.l 0x060438E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060437F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060437F2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060437F4 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060438AE; } }  // 060437F6 bf/s 0x060438AE ; mov r2,r1
    c.r[1] >>= 2;  // 060437FA shlr2 r1
    c.r[1] >>= 2;  // 060437FC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060437FE shlr r1
    c.r[1] >>= 2;  // 06043800 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06043802 tst r1,r1
    { const bool k = !c.t; c.r[2] >>= 2; if (k) { goto L_0604380A; } }  // 06043804 bf/s 0x0604380A ; shlr2 r2
    c.r[2] >>= 2;  // 06043808 shlr2 r2
L_0604380A:
    c.r[0] = 0x3u;  // 0604380A mov #3,r0
    c.r[2] &= c.r[0];  // 0604380C and r0,r2
    c.r[0] = c.r[2];  // 0604380E mov r2,r0
    c.t = c.r[0] == 0x2u;  // 06043810 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0604384E; } }  // 06043812 bt/s 0x0604384E ; mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06043816 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06043824; } }  // 06043818 bt/s 0x06043824 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 0604381C cmp/eq #1,r0
    if (!c.t) { goto L_0604389E; }  // 0604381E bf 0x0604389E
    goto L_0604382A;  // 06043820 bra 0x0604382A ; nop
L_06043824:
    if (!c.t) { goto L_0604389E; }  // 06043824 bf 0x0604389E
    goto L_06043872;  // 06043826 bra 0x06043872 ; nop
L_0604382A:
    c.r[1] = ld32(0x060438DCu);  // 0604382A mov.l 0x060438DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CCu);  // 0604382C mov.w 0x060438CC,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0604382E mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CAu);  // 06043830 mov.w 0x060438CA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06043832 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060438E4u);  // 06043834 mov.l 0x060438E4,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06043836 extu.b r1,r1
    c.r[1] >>= 2;  // 06043838 shlr2 r1
    c.r[1] >>= 2;  // 0604383A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604383C shlr r1
    c.r[1] >>= 2;  // 0604383E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06043840 tst r1,r1
    if (!c.t) { goto L_06043846; }  // 06043842 bf 0x06043846
    c.r[4] = ld32(0x060438E8u);  // 06043844 mov.l 0x060438E8,r4
L_06043846:
    c.r[1] = ld32(0x060438ECu);  // 06043846 mov.l 0x060438EC,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060438CEu);  // 06043848 mov.w 0x060438CE,r6
    c.r[7] = 0xEu; goto L_06043894;  // 0604384A bra 0x06043894 ; mov #14,r7
L_0604384E:
    c.r[1] = ld32(0x060438DCu);  // 0604384E mov.l 0x060438DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438D0u);  // 06043850 mov.w 0x060438D0,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 06043852 mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CAu);  // 06043854 mov.w 0x060438CA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06043856 mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060438F0u);  // 06043858 mov.l 0x060438F0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0604385A extu.b r1,r1
    c.r[1] >>= 2;  // 0604385C shlr2 r1
    c.r[1] >>= 2;  // 0604385E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06043860 shlr r1
    c.r[1] >>= 2;  // 06043862 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06043864 tst r1,r1
    if (!c.t) { goto L_0604386A; }  // 06043866 bf 0x0604386A
    c.r[4] = ld32(0x060438F4u);  // 06043868 mov.l 0x060438F4,r4
L_0604386A:
    c.r[1] = ld32(0x060438ECu);  // 0604386A mov.l 0x060438EC,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060438CEu);  // 0604386C mov.w 0x060438CE,r6
    c.r[7] = 0xEu; goto L_06043894;  // 0604386E bra 0x06043894 ; mov #14,r7
L_06043872:
    c.r[1] = ld32(0x060438DCu);  // 06043872 mov.l 0x060438DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CCu);  // 06043874 mov.w 0x060438CC,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 06043876 mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CAu);  // 06043878 mov.w 0x060438CA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604387A mov.b @(r0,r1),r1
    c.r[4] = ld32(0x060438E4u);  // 0604387C mov.l 0x060438E4,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0604387E extu.b r1,r1
    c.r[1] >>= 2;  // 06043880 shlr2 r1
    c.r[1] >>= 2;  // 06043882 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06043884 shlr r1
    c.r[1] >>= 2;  // 06043886 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06043888 tst r1,r1
    if (!c.t) { goto L_0604388E; }  // 0604388A bf 0x0604388E
    c.r[4] = ld32(0x060438E8u);  // 0604388C mov.l 0x060438E8,r4
L_0604388E:
    c.r[1] = ld32(0x060438ECu);  // 0604388E mov.l 0x060438EC,r1
    c.r[7] = 0xEu;  // 06043890 mov #14,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x060438D2u);  // 06043892 mov.w 0x060438D2,r6
L_06043894:
    { const uint32_t x = c.r[1]; c.pr = 0x06043898u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043898u) return; }  // 06043894 jsr @r1 ; nop
    c.r[1] = ld32(0x060438F8u);  // 06043898 mov.l 0x060438F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604389Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604389Eu) return; }  // 0604389A jsr @r1 ; nop
L_0604389E:
    c.r[1] = ld32(0x060438DCu);  // 0604389E mov.l 0x060438DC,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060438CAu);  // 060438A0 mov.w 0x060438CA,r2
    c.r[0] = c.r[1];  // 060438A2 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060438A4 mov.b @(r0,r2),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438D4u);  // 060438A6 mov.w 0x060438D4,r0
    c.r[3] &= c.r[0];  // 060438A8 and r0,r3
    c.r[0] = c.r[1];  // 060438AA mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 060438AC mov.b r3,@(r0,r2)
L_060438AE:
    c.r[1] = ld32(0x060438DCu);  // 060438AE mov.l 0x060438DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060438CAu);  // 060438B0 mov.w 0x060438CA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060438B2 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060438B4 extu.b r1,r2
    c.r[1] = c.r[2];  // 060438B6 mov r2,r1
    c.r[1] >>= 2;  // 060438B8 shlr2 r1
    c.r[1] >>= 2;  // 060438BA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060438BC shlr r1
    c.r[1] >>= 2;  // 060438BE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060438C0 tst r1,r1
    { const bool k = !c.t; c.r[2] >>= 2; if (k) { goto L_060438FC; } }  // 060438C2 bf/s 0x060438FC ; shlr2 r2
    c.r[2] >>= 2; goto L_060438FC;  // 060438C6 bra 0x060438FC ; shlr2 r2
L_060438FC:
    c.r[0] = 0x3u;  // 060438FC mov #3,r0
    c.r[2] &= c.r[0];  // 060438FE and r0,r2
    c.r[1] = 0x3u;  // 06043900 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 06043902 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06043986; } }  // 06043904 bt/s 0x06043986 ; mov r2,r1
    c.r[1] += c.r[1];  // 06043908 add r1,r1
    c.r[0] = 0x06043914u;  // 0604390A mova 0x06043914,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604390C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604390E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604391Cu: goto L_0604391C; case 0x06043946u: goto L_06043946; case 0x06043964u: goto L_06043964; case 0x06043972u: goto L_06043972; default: sh2_call(c, x); return; } }  // 06043910 jmp @r0 ; nop
L_0604391C:
    c.r[3] = ld32(0x06043990u);  // 0604391C mov.l 0x06043990,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604391E mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604398Eu);  // 06043920 mov.w 0x0604398E,r2
    c.r[1] &= c.r[2];  // 06043922 and r2,r1
    st16(c.r[3], c.r[1]);  // 06043924 mov.w r1,@r3
    c.r[1] = ld32(0x06043994u);  // 06043926 mov.l 0x06043994,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604392Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604392Cu) return; }  // 06043928 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06043998u);  // 0604392C mov.l 0x06043998,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043932u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043932u) return; }  // 0604392E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0604399Cu);  // 06043932 mov.l 0x0604399C,r1
    c.r[2] = 0x0u;  // 06043934 mov #0,r2
    st16(c.r[1], c.r[2]);  // 06043936 mov.w r2,@r1
    c.r[1] = ld32(0x060439A0u);  // 06043938 mov.l 0x060439A0,r1
    st16(c.r[1], c.r[2]);  // 0604393A mov.w r2,@r1
    c.r[1] = ld32(0x060439A4u);  // 0604393C mov.l 0x060439A4,r1
    st16(c.r[1], c.r[2]);  // 0604393E mov.w r2,@r1
    c.r[1] = ld32(0x060439A8u);  // 06043940 mov.l 0x060439A8,r1
    st16(c.r[1], c.r[2]); goto L_06043986;  // 06043942 bra 0x06043986 ; mov.w r2,@r1
L_06043946:
    c.r[1] = ld32(0x060439ACu);  // 06043946 mov.l 0x060439AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06043948 mov.b @r1,r1
    c.r[4] = 0x1u;  // 0604394A mov #1,r4
    c.r[0] = c.r[1];  // 0604394C mov r1,r0
    c.r[0] >>= 2;  // 0604394E shlr2 r0
    c.r[0] >>= 2;  // 06043950 shlr2 r0
    c.r[0] &= 0x3u;  // 06043952 and #3,r0
    c.r[1] = ld32(0x060439B0u);  // 06043954 mov.l 0x060439B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604395Au; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604395Au) return; }  // 06043956 jsr @r1 ; mov r0,r5
    c.r[1] = ld32(0x06043998u);  // 0604395A mov.l 0x06043998,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043960u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043960u) return; }  // 0604395C jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14]; goto L_06043988;  // 06043960 bra 0x06043988 ; mov r14,r15
L_06043964:
    c.r[1] = ld32(0x06043994u);  // 06043964 mov.l 0x06043994,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604396Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604396Au) return; }  // 06043966 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060439ACu);  // 0604396A mov.l 0x060439AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604396C mov.b @r1,r1
    c.r[4] = 0x2u; goto L_06043978;  // 0604396E bra 0x06043978 ; mov #2,r4
L_06043972:
    c.r[1] = ld32(0x060439ACu);  // 06043972 mov.l 0x060439AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06043974 mov.b @r1,r1
    c.r[4] = 0x3u;  // 06043976 mov #3,r4
L_06043978:
    c.r[0] = c.r[1];  // 06043978 mov r1,r0
    c.r[0] >>= 2;  // 0604397A shlr2 r0
    c.r[0] >>= 2;  // 0604397C shlr2 r0
    c.r[0] &= 0x3u;  // 0604397E and #3,r0
    c.r[1] = ld32(0x060439B0u);  // 06043980 mov.l 0x060439B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043986u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043986u) return; }  // 06043982 jsr @r1 ; mov r0,r5
L_06043986:
    c.r[15] = c.r[14];  // 06043986 mov r14,r15
L_06043988:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06043988 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604398A rts ; mov.l @r15+,r14
}

void f_060439B4(SH2Context& c) {
    ran[1097] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060439B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060439B6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060439B8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060439BA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060439BC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060439BE mov r15,r14
    c.r[1] = ld32(0x06043A34u);  // 060439C0 mov.l 0x06043A34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060439C6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060439C6u) return; }  // 060439C2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06043A38u);  // 060439C6 mov.l 0x06043A38,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060439CCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060439CCu) return; }  // 060439C8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06043A3Cu);  // 060439CC mov.l 0x06043A3C,r1
    c.r[2] = 0x0u;  // 060439CE mov #0,r2
    st16(c.r[1], c.r[2]);  // 060439D0 mov.w r2,@r1
    c.r[1] = ld32(0x06043A40u);  // 060439D2 mov.l 0x06043A40,r1
    st16(c.r[1], c.r[2]);  // 060439D4 mov.w r2,@r1
    c.r[1] = ld32(0x06043A44u);  // 060439D6 mov.l 0x06043A44,r1
    st16(c.r[1], c.r[2]);  // 060439D8 mov.w r2,@r1
    c.r[1] = ld32(0x06043A48u);  // 060439DA mov.l 0x06043A48,r1
    st16(c.r[1], c.r[2]);  // 060439DC mov.w r2,@r1
    c.r[1] = ld32(0x06043A4Cu);  // 060439DE mov.l 0x06043A4C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06043A2Cu);  // 060439E0 mov.w 0x06043A2C,r2
    c.r[0] = c.r[1];  // 060439E2 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060439E4 mov.b @(r0,r2),r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06043A2Eu);  // 060439E6 mov.w 0x06043A2E,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06043A30u);  // 060439E8 mov.w 0x06043A30,r5
    c.r[4] = ld32(0x06043A50u);  // 060439EA mov.l 0x06043A50,r4
    c.r[6] = 0x1u;  // 060439EC mov #1,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043A32u);  // 060439EE mov.w 0x06043A32,r0
    c.r[3] &= c.r[0];  // 060439F0 and r0,r3
    c.r[0] = c.r[1];  // 060439F2 mov r1,r0
    c.r[1] = ld32(0x06043A54u);  // 060439F4 mov.l 0x06043A54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060439FAu; st8(c.r[0] + c.r[2], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060439FAu) return; }  // 060439F6 jsr @r1 ; mov.b r3,@(r0,r2)
    c.r[8] = 0x0u;  // 060439FA mov #0,r8
    c.r[10] = ld32(0x06043A58u);  // 060439FC mov.l 0x06043A58,r10
    c.r[9] = 0xFu;  // 060439FE mov #15,r9
L_06043A00:
    { const uint32_t x = c.r[10]; c.pr = 0x06043A04u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043A04u) return; }  // 06043A00 jsr @r10 ; extu.b r8,r4
    c.r[1] = c.r[8];  // 06043A04 mov r8,r1
    c.r[1] += 1;  // 06043A06 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06043A08 extu.w r1,r8
    c.t = c.r[8] > c.r[9];  // 06043A0A cmp/hi r9,r8
    if (!c.t) { SH2_POLL(c); goto L_06043A00; }  // 06043A0C bf 0x06043A00
    c.r[15] = c.r[14];  // 06043A0E mov r14,r15
    c.r[1] = ld32(0x06043A4Cu);  // 06043A10 mov.l 0x06043A4C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06043A2Cu);  // 06043A12 mov.w 0x06043A2C,r2
    c.r[0] = c.r[1];  // 06043A14 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06043A16 mov.b @(r0,r2),r3
    c.r[0] = 0x40u;  // 06043A18 mov #64,r0
    c.r[3] |= c.r[0];  // 06043A1A or r0,r3
    c.r[0] = c.r[1];  // 06043A1C mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06043A1E mov.b r3,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06043A20 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06043A22 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06043A24 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06043A26 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043A28 rts ; mov.l @r15+,r8
}

void f_06043A5C(SH2Context& c) {
    ran[1098] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043A5C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06043A5E mov r15,r14
    c.r[3] = 0x0u;  // 06043A60 mov #0,r3
    c.r[7] = ld32(0x06043AB8u);  // 06043A62 mov.l 0x06043AB8,r7
    c.r[2] = 0x2Cu;  // 06043A64 mov #44,r2
    c.macl = c.r[3] * c.r[2];  // 06043A66 mul.l r2,r3
L_06043A68:
    c.r[0] = c.macl;  // 06043A68 sts macl,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06043A6A mov.b @(r0,r7),r6
    c.r[1] = c.r[6] & 0xFFu;  // 06043A6C extu.b r6,r1
    c.r[1] >>= 2;  // 06043A6E shlr2 r1
    c.r[1] >>= 2;  // 06043A70 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06043A72 shlr r1
    c.r[1] >>= 2;  // 06043A74 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06043A76 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06043A9C; } }  // 06043A78 bf/s 0x06043A9C ; mov r3,r1
    c.r[1] = c.macl;  // 06043A7C sts macl,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043AB0u);  // 06043A7E mov.w 0x06043AB0,r0
    c.r[6] |= c.r[0];  // 06043A80 or r0,r6
    c.r[0] = c.r[7];  // 06043A82 mov r7,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06043A84 mov.b r6,@(r0,r1)
    c.r[2] = c.macl;  // 06043A86 sts macl,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043AB2u);  // 06043A88 mov.w 0x06043AB2,r1
    c.r[1] &= c.r[6];  // 06043A8A and r6,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06043A8C mov.b r1,@(r0,r2)
    c.r[1] = c.macl;  // 06043A8E sts macl,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043AB4u);  // 06043A90 mov.w 0x06043AB4,r0
    c.r[6] &= c.r[0];  // 06043A92 and r0,r6
    c.r[0] = c.r[7];  // 06043A94 mov r7,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06043A96 mov.b r6,@(r0,r1)
    c.r[0] = c.r[3]; goto L_06043AAA;  // 06043A98 bra 0x06043AAA ; mov r3,r0
L_06043A9C:
    c.r[1] += 1;  // 06043A9C add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06043A9E extu.b r1,r3
    c.r[1] = 0xFu;  // 06043AA0 mov #15,r1
    c.t = c.r[3] > c.r[1];  // 06043AA2 cmp/hi r1,r3
    { const bool k = !c.t; c.macl = c.r[3] * c.r[2]; if (k) { SH2_POLL(c); goto L_06043A68; } }  // 06043AA4 bf/s 0x06043A68 ; mul.l r2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043AB6u);  // 06043AA8 mov.w 0x06043AB6,r0
L_06043AAA:
    c.r[15] = c.r[14];  // 06043AAA mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043AAC rts ; mov.l @r15+,r14
}

void f_06043ABC(SH2Context& c) {
    ran[1099] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043ABC mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 06043ABE extu.b r4,r4
    c.r[1] = 0x10u;  // 06043AC0 mov #16,r1
    c.t = c.r[4] > c.r[1];  // 06043AC2 cmp/hi r1,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06043B12; } }  // 06043AC4 bt/s 0x06043B12 ; mov r15,r14
    c.r[1] = 0x2Cu;  // 06043AC8 mov #44,r1
    c.r[2] = ld32(0x06043B1Cu);  // 06043ACA mov.l 0x06043B1C,r2
    c.macl = c.r[4] * c.r[1];  // 06043ACC mul.l r1,r4
    c.r[3] = 0x0u;  // 06043ACE mov #0,r3
    c.r[7] = 0x0u;  // 06043AD0 mov #0,r7
    c.r[1] = c.macl;  // 06043AD2 sts macl,r1
    c.r[1] += c.r[2];  // 06043AD4 add r2,r1
    st8(c.r[1], c.r[3]);  // 06043AD6 mov.b r3,@r1
    c.r[2] = c.r[1];  // 06043AD8 mov r1,r2
    c.r[2] += 2;  // 06043ADA add #2,r2
    st16(c.r[2], c.r[7]);  // 06043ADC mov.w r7,@r2
    c.r[6] = c.r[1];  // 06043ADE mov r1,r6
    c.r[6] += 6;  // 06043AE0 add #6,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06043B18u);  // 06043AE2 mov.w 0x06043B18,r2
    st16(c.r[6], c.r[2]);  // 06043AE4 mov.w r2,@r6
    c.r[2] = c.r[1];  // 06043AE6 mov r1,r2
    c.r[2] += 8;  // 06043AE8 add #8,r2
    st16(c.r[2], c.r[7]);  // 06043AEA mov.w r7,@r2
    c.r[2] = c.r[1];  // 06043AEC mov r1,r2
    c.r[2] += 10;  // 06043AEE add #10,r2
    st16(c.r[2], c.r[7]);  // 06043AF0 mov.w r7,@r2
    c.r[2] = c.r[1];  // 06043AF2 mov r1,r2
    c.r[2] += 4;  // 06043AF4 add #4,r2
    st16(c.r[2], c.r[7]);  // 06043AF6 mov.w r7,@r2
    c.r[2] = c.r[1];  // 06043AF8 mov r1,r2
    c.r[2] += 12;  // 06043AFA add #12,r2
    st16(c.r[2], c.r[7]);  // 06043AFC mov.w r7,@r2
    c.r[2] = c.r[1];  // 06043AFE mov r1,r2
    c.r[2] += 14;  // 06043B00 add #14,r2
    st16(c.r[2], c.r[7]);  // 06043B02 mov.w r7,@r2
    st32(c.r[1] + 16, c.r[3]);  // 06043B04 mov.l r3,@(16,r1)
    st32(c.r[1] + 20, c.r[3]);  // 06043B06 mov.l r3,@(20,r1)
    st32(c.r[1] + 24, c.r[3]);  // 06043B08 mov.l r3,@(24,r1)
    st32(c.r[1] + 28, c.r[3]);  // 06043B0A mov.l r3,@(28,r1)
    st32(c.r[1] + 32, c.r[3]);  // 06043B0C mov.l r3,@(32,r1)
    st32(c.r[1] + 36, c.r[3]);  // 06043B0E mov.l r3,@(36,r1)
    st32(c.r[1] + 40, c.r[3]);  // 06043B10 mov.l r3,@(40,r1)
L_06043B12:
    c.r[15] = c.r[14];  // 06043B12 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043B14 rts ; mov.l @r15+,r14
}

void f_06043B20(SH2Context& c) {
    ran[1100] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043B20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06043B22 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06043B24 mov r15,r14
    c.r[7] = (uint32_t)(int16_t)ld16(0x06043B3Au);  // 06043B26 mov.w 0x06043B3A,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06043B3Cu);  // 06043B28 mov.w 0x06043B3C,r5
    c.r[4] = ld32(0x06043B40u);  // 06043B2A mov.l 0x06043B40,r4
    c.r[1] = ld32(0x06043B44u);  // 06043B2C mov.l 0x06043B44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06043B32u; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06043B32u) return; }  // 06043B2E jsr @r1 ; mov #1,r6
    c.r[15] = c.r[14];  // 06043B32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06043B34 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06043B36 rts ; mov.l @r15+,r14
}

void f_06043B48(SH2Context& c) {
    ran[1101] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06043B48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06043B4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06043B4C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06043B4E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06043B50 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06043B52 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06043B54 mov.l r14,@-r15
    c.r[15] -= 32;  // 06043B56 add #-32,r15
    c.r[14] = c.r[15];  // 06043B58 mov r15,r14
    c.r[2] = ld32(c.r[4] + 32);  // 06043B5A mov.l @(32,r4),r2
    c.t = (int32_t)c.r[2] > 0;  // 06043B5C cmp/pl r2
    { const bool k = c.t; st32(c.r[14], c.r[5]); if (k) { goto L_06043B66; } }  // 06043B5E bt/s 0x06043B66 ; mov.l r5,@r14
    goto L_0604402C;  // 06043B62 bra 0x0604402C ; nop
L_06043B66:
    c.r[1] = c.r[4];  // 06043B66 mov r4,r1
    c.r[1] += 12;  // 06043B68 add #12,r1
    c.r[0] = 0x0u;  // 06043B6A mov #0,r0
    c.r[9] = ld32(c.r[4] + 16);  // 06043B6C mov.l @(16,r4),r9
    c.r[3] = 0x0u;  // 06043B6E mov #0,r3
    c.r[8] = ld32(c.r[4] + 20);  // 06043B70 mov.l @(20,r4),r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x06043C66u);  // 06043B72 mov.w 0x06043C66,r13
    c.r[5] = ld32(c.r[4] + 24);  // 06043B74 mov.l @(24,r4),r5
    c.r[12] = ld32(0x06043C6Cu);  // 06043B76 mov.l 0x06043C6C,r12
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06043B78 mov.w @r1,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x06043C68u);  // 06043B7A mov.w 0x06043C68,r11
    c.r[6] = ld32(c.r[4] + 28);  // 06043B7C mov.l @(28,r4),r6
    c.r[1] = ld32(0x06043C70u);  // 06043B7E mov.l 0x06043C70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06043B80 mov.b @r1,r1
    c.r[4] += 14;  // 06043B82 add #14,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06043B84 mov.w @r4,r4
    c.r[7] += c.r[1];  // 06043B86 add r1,r7
    c.r[1] = ld32(0x06043C74u);  // 06043B88 mov.l 0x06043C74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06043B8A mov.b @r1,r1
    c.r[10] = ld32(0x06043C78u);  // 06043B8C mov.l 0x06043C78,r10
    c.r[4] += c.r[1];  // 06043B8E add r1,r4
    st32(c.r[14] + 8, c.r[2]);  // 06043B90 mov.l r2,@(8,r14)
    st32(c.r[14] + 4, c.r[0]);  // 06043B92 mov.l r0,@(4,r14)
    c.r[1] = 0x0u;  // 06043B94 mov #0,r1
    st32(c.r[14] + 28, c.r[0]);  // 06043B96 mov.l r0,@(28,r14)
L_06043B98:
    c.r[0] = ld32(c.r[14] + 28);  // 06043B98 mov.l @(28,r14),r0
    c.r[3] += 1;  // 06043B9A add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[13];  // 06043B9C cmp/gt r13,r3
    st32(c.r[0] + c.r[12], c.r[11]);  // 06043B9E mov.l r11,@(r0,r12)
    st32(c.r[0] + c.r[10], c.r[1]);  // 06043BA0 mov.l r1,@(r0,r10)
    c.r[0] += 4;  // 06043BA2 add #4,r0
    { const bool k = !c.t; st32(c.r[14] + 28, c.r[0]); if (k) { SH2_POLL(c); goto L_06043B98; } }  // 06043BA4 bf/s 0x06043B98 ; mov.l r0,@(28,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 06043BA8 mov.l @(4,r14),r0
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[0];  // 06043BAA cmp/ge r0,r2
    { const bool k = c.t; c.r[0] += c.r[7]; if (k) { goto L_06043BB4; } }  // 06043BAC bt/s 0x06043BB4 ; add r7,r0
    goto L_06043FAA;  // 06043BB0 bra 0x06043FAA ; nop
L_06043BB4:
    c.r[12] = ld32(0x06043C6Cu);  // 06043BB4 mov.l 0x06043C6C,r12
    st32(c.r[14] + 12, c.r[0]);  // 06043BB6 mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 06043BB8 mov.l @(4,r14),r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06043C68u);  // 06043BBA mov.w 0x06043C68,r11
    c.r[0] += c.r[4];  // 06043BBC add r4,r0
    st32(c.r[14] + 16, c.r[0]);  // 06043BBE mov.l r0,@(16,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 06043BC0 mov.l @(4,r14),r0
    c.r[10] = ld32(0x06043C78u);  // 06043BC2 mov.l 0x06043C78,r10
    c.r[1] = 0u - c.r[0];  // 06043BC4 neg r0,r1
    c.r[0] = c.r[1];  // 06043BC6 mov r1,r0
    c.r[0] += c.r[7];  // 06043BC8 add r7,r0
    st32(c.r[14] + 20, c.r[0]);  // 06043BCA mov.l r0,@(20,r14)
    c.r[1] += c.r[4];  // 06043BCC add r4,r1
    st32(c.r[14] + 24, c.r[1]);  // 06043BCE mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 06043BD0 mov.l @(24,r14),r1
L_06043BD2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043C66u);  // 06043BD2 mov.w 0x06043C66,r0
    c.r[1] -= c.r[5];  // 06043BD4 sub r5,r1
    c.t = c.r[1] > c.r[0];  // 06043BD6 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043C3E; } }  // 06043BD8 bt/s 0x06043C3E ; mov r1,r0
    c.r[0] <<= 2;  // 06043BDC shll2 r0
    c.r[13] = c.r[0];  // 06043BDE mov r0,r13
    c.r[3] = c.r[7];  // 06043BE0 mov r7,r3
    c.r[3] -= c.r[2];  // 06043BE2 sub r2,r3
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043BE4 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043BE6 sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043BE8 cmp/gt r3,r1
    { const bool k = c.t; c.r[13] += c.r[12]; if (k) { goto L_06043BF8; } }  // 06043BEA bt/s 0x06043BF8 ; add r12,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043BEE cmp/pz r1
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_06043BFE; } }  // 06043BF0 bt/s 0x06043BFE ; mov r7,r3
    c.r[1] = 0x0u; goto L_06043C3C;  // 06043BF4 bra 0x06043C3C ; mov #0,r1
L_06043BF8:
    c.t = (int32_t)c.r[3] >= 0;  // 06043BF8 cmp/pz r3
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_06043C3A; } }  // 06043BFA bf/s 0x06043C3A ; mov r7,r3
L_06043BFE:
    c.r[0] = ld32(c.r[14] + 24);  // 06043BFE mov.l @(24,r14),r0
    c.r[3] -= c.r[2];  // 06043C00 sub r2,r3
    c.r[0] -= c.r[5];  // 06043C02 sub r5,r0
    c.r[0] <<= 2;  // 06043C04 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043C06 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043C08 sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043C0A cmp/gt r3,r1
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[11]; if (k) { goto L_06043C1A; } }  // 06043C0C bt/s 0x06043C1A ; cmp/gt r11,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 06043C10 cmp/gt r11,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06043C1E; } }  // 06043C12 bf/s 0x06043C1E ; mov r7,r1
    goto L_06043C34;  // 06043C16 bra 0x06043C34 ; nop
L_06043C1A:
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06043C34; } }  // 06043C1A bt/s 0x06043C34 ; mov r7,r1
L_06043C1E:
    c.r[0] = ld32(c.r[14] + 24);  // 06043C1E mov.l @(24,r14),r0
    c.r[1] -= c.r[2];  // 06043C20 sub r2,r1
    c.r[0] -= c.r[5];  // 06043C22 sub r5,r0
    c.r[0] <<= 2;  // 06043C24 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06043C26 mov.l @(r0,r12),r3
    c.r[1] -= c.r[9];  // 06043C28 sub r9,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06043C2A cmp/gt r1,r3
    if (c.t) { goto L_06043C3C; }  // 06043C2C bt 0x06043C3C
    c.r[1] = c.r[3];  // 06043C2E mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043C3E;  // 06043C30 bra 0x06043C3E ; mov.l r1,@r13
L_06043C34:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043C68u);  // 06043C34 mov.w 0x06043C68,r1
    st32(c.r[13], c.r[1]); goto L_06043C3E;  // 06043C36 bra 0x06043C3E ; mov.l r1,@r13
L_06043C3A:
    c.r[1] = 0x0u;  // 06043C3A mov #0,r1
L_06043C3C:
    st32(c.r[13], c.r[1]);  // 06043C3C mov.l r1,@r13
L_06043C3E:
    c.r[1] = c.r[4];  // 06043C3E mov r4,r1
    c.r[1] -= c.r[2];  // 06043C40 sub r2,r1
    c.r[1] -= c.r[5];  // 06043C42 sub r5,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043C66u);  // 06043C44 mov.w 0x06043C66,r0
    c.t = c.r[1] > c.r[0];  // 06043C46 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043CC2; } }  // 06043C48 bt/s 0x06043CC2 ; mov r1,r0
    c.r[0] <<= 2;  // 06043C4C shll2 r0
    c.r[13] = c.r[0];  // 06043C4E mov r0,r13
    c.r[3] = ld32(c.r[14] + 20);  // 06043C50 mov.l @(20,r14),r3
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043C52 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043C54 sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043C56 cmp/gt r3,r1
    { const bool k = c.t; c.r[13] += c.r[12]; if (k) { goto L_06043C7C; } }  // 06043C58 bt/s 0x06043C7C ; add r12,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043C5C cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043C82; } }  // 06043C5E bt/s 0x06043C82 ; mov r4,r0
    c.r[1] = 0x0u; goto L_06043CC0;  // 06043C62 bra 0x06043CC0 ; mov #0,r1
L_06043C7C:
    c.t = (int32_t)c.r[3] >= 0;  // 06043C7C cmp/pz r3
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043CBE; } }  // 06043C7E bf/s 0x06043CBE ; mov r4,r0
L_06043C82:
    c.r[0] -= c.r[2];  // 06043C82 sub r2,r0
    c.r[0] -= c.r[5];  // 06043C84 sub r5,r0
    c.r[3] = ld32(c.r[14] + 20);  // 06043C86 mov.l @(20,r14),r3
    c.r[0] <<= 2;  // 06043C88 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043C8A mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043C8C sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043C8E cmp/gt r3,r1
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[11]; if (k) { goto L_06043C9E; } }  // 06043C90 bt/s 0x06043C9E ; cmp/gt r11,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 06043C94 cmp/gt r11,r1
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043CA2; } }  // 06043C96 bf/s 0x06043CA2 ; mov r4,r0
    goto L_06043CB8;  // 06043C9A bra 0x06043CB8 ; nop
L_06043C9E:
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043CB8; } }  // 06043C9E bt/s 0x06043CB8 ; mov r4,r0
L_06043CA2:
    c.r[0] -= c.r[2];  // 06043CA2 sub r2,r0
    c.r[0] -= c.r[5];  // 06043CA4 sub r5,r0
    c.r[1] = ld32(c.r[14] + 20);  // 06043CA6 mov.l @(20,r14),r1
    c.r[0] <<= 2;  // 06043CA8 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06043CAA mov.l @(r0,r12),r3
    c.r[1] -= c.r[9];  // 06043CAC sub r9,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06043CAE cmp/gt r1,r3
    if (c.t) { goto L_06043CC0; }  // 06043CB0 bt 0x06043CC0
    c.r[1] = c.r[3];  // 06043CB2 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043CC2;  // 06043CB4 bra 0x06043CC2 ; mov.l r1,@r13
L_06043CB8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043D7Au);  // 06043CB8 mov.w 0x06043D7A,r1
    st32(c.r[13], c.r[1]); goto L_06043CC2;  // 06043CBA bra 0x06043CC2 ; mov.l r1,@r13
L_06043CBE:
    c.r[1] = 0x0u;  // 06043CBE mov #0,r1
L_06043CC0:
    st32(c.r[13], c.r[1]);  // 06043CC0 mov.l r1,@r13
L_06043CC2:
    c.r[1] = ld32(c.r[14] + 16);  // 06043CC2 mov.l @(16,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043D7Cu);  // 06043CC4 mov.w 0x06043D7C,r0
    c.r[1] += c.r[6];  // 06043CC6 add r6,r1
    c.t = c.r[1] > c.r[0];  // 06043CC8 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043D30; } }  // 06043CCA bt/s 0x06043D30 ; mov r1,r0
    c.r[0] <<= 2;  // 06043CCE shll2 r0
    c.r[13] = c.r[0];  // 06043CD0 mov r0,r13
    c.r[3] = c.r[7];  // 06043CD2 mov r7,r3
    c.r[3] -= c.r[2];  // 06043CD4 sub r2,r3
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043CD6 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043CD8 sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043CDA cmp/gt r3,r1
    { const bool k = c.t; c.r[13] += c.r[12]; if (k) { goto L_06043CEA; } }  // 06043CDC bt/s 0x06043CEA ; add r12,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043CE0 cmp/pz r1
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_06043CF0; } }  // 06043CE2 bt/s 0x06043CF0 ; mov r7,r3
    c.r[1] = 0x0u; goto L_06043D2E;  // 06043CE6 bra 0x06043D2E ; mov #0,r1
L_06043CEA:
    c.t = (int32_t)c.r[3] >= 0;  // 06043CEA cmp/pz r3
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_06043D2C; } }  // 06043CEC bf/s 0x06043D2C ; mov r7,r3
L_06043CF0:
    c.r[0] = ld32(c.r[14] + 16);  // 06043CF0 mov.l @(16,r14),r0
    c.r[3] -= c.r[2];  // 06043CF2 sub r2,r3
    c.r[0] += c.r[6];  // 06043CF4 add r6,r0
    c.r[0] <<= 2;  // 06043CF6 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043CF8 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043CFA sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043CFC cmp/gt r3,r1
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[11]; if (k) { goto L_06043D0C; } }  // 06043CFE bt/s 0x06043D0C ; cmp/gt r11,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 06043D02 cmp/gt r11,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06043D10; } }  // 06043D04 bf/s 0x06043D10 ; mov r7,r1
    goto L_06043D26;  // 06043D08 bra 0x06043D26 ; nop
L_06043D0C:
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06043D26; } }  // 06043D0C bt/s 0x06043D26 ; mov r7,r1
L_06043D10:
    c.r[0] = ld32(c.r[14] + 16);  // 06043D10 mov.l @(16,r14),r0
    c.r[1] -= c.r[2];  // 06043D12 sub r2,r1
    c.r[0] += c.r[6];  // 06043D14 add r6,r0
    c.r[0] <<= 2;  // 06043D16 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06043D18 mov.l @(r0,r12),r3
    c.r[1] -= c.r[9];  // 06043D1A sub r9,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06043D1C cmp/gt r1,r3
    if (c.t) { goto L_06043D2E; }  // 06043D1E bt 0x06043D2E
    c.r[1] = c.r[3];  // 06043D20 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043D30;  // 06043D22 bra 0x06043D30 ; mov.l r1,@r13
L_06043D26:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043D7Au);  // 06043D26 mov.w 0x06043D7A,r1
    st32(c.r[13], c.r[1]); goto L_06043D30;  // 06043D28 bra 0x06043D30 ; mov.l r1,@r13
L_06043D2C:
    c.r[1] = 0x0u;  // 06043D2C mov #0,r1
L_06043D2E:
    st32(c.r[13], c.r[1]);  // 06043D2E mov.l r1,@r13
L_06043D30:
    c.r[1] = c.r[4];  // 06043D30 mov r4,r1
    c.r[1] += c.r[2];  // 06043D32 add r2,r1
    c.r[1] += c.r[6];  // 06043D34 add r6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043D7Cu);  // 06043D36 mov.w 0x06043D7C,r0
    c.t = c.r[1] > c.r[0];  // 06043D38 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043DA2; } }  // 06043D3A bt/s 0x06043DA2 ; mov r1,r0
    c.r[0] <<= 2;  // 06043D3E shll2 r0
    c.r[13] = c.r[0];  // 06043D40 mov r0,r13
    c.r[3] = ld32(c.r[14] + 20);  // 06043D42 mov.l @(20,r14),r3
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043D44 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043D46 sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043D48 cmp/gt r3,r1
    { const bool k = c.t; c.r[13] += c.r[12]; if (k) { goto L_06043D58; } }  // 06043D4A bt/s 0x06043D58 ; add r12,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043D4E cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043D5E; } }  // 06043D50 bt/s 0x06043D5E ; mov r4,r0
    c.r[1] = 0x0u; goto L_06043DA0;  // 06043D54 bra 0x06043DA0 ; mov #0,r1
L_06043D58:
    c.t = (int32_t)c.r[3] >= 0;  // 06043D58 cmp/pz r3
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043D9E; } }  // 06043D5A bf/s 0x06043D9E ; mov r4,r0
L_06043D5E:
    c.r[0] += c.r[2];  // 06043D5E add r2,r0
    c.r[0] += c.r[6];  // 06043D60 add r6,r0
    c.r[3] = ld32(c.r[14] + 20);  // 06043D62 mov.l @(20,r14),r3
    c.r[0] <<= 2;  // 06043D64 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06043D66 mov.l @(r0,r12),r1
    c.r[3] -= c.r[9];  // 06043D68 sub r9,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06043D6A cmp/gt r3,r1
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[11]; if (k) { goto L_06043D7E; } }  // 06043D6C bt/s 0x06043D7E ; cmp/gt r11,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 06043D70 cmp/gt r11,r1
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043D82; } }  // 06043D72 bf/s 0x06043D82 ; mov r4,r0
    goto L_06043D98;  // 06043D76 bra 0x06043D98 ; nop
L_06043D7E:
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043D98; } }  // 06043D7E bt/s 0x06043D98 ; mov r4,r0
L_06043D82:
    c.r[0] += c.r[2];  // 06043D82 add r2,r0
    c.r[0] += c.r[6];  // 06043D84 add r6,r0
    c.r[1] = ld32(c.r[14] + 20);  // 06043D86 mov.l @(20,r14),r1
    c.r[0] <<= 2;  // 06043D88 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06043D8A mov.l @(r0,r12),r3
    c.r[1] -= c.r[9];  // 06043D8C sub r9,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06043D8E cmp/gt r1,r3
    if (c.t) { goto L_06043DA0; }  // 06043D90 bt 0x06043DA0
    c.r[1] = c.r[3];  // 06043D92 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043DA2;  // 06043D94 bra 0x06043DA2 ; mov.l r1,@r13
L_06043D98:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043E58u);  // 06043D98 mov.w 0x06043E58,r1
    st32(c.r[13], c.r[1]); goto L_06043DA2;  // 06043D9A bra 0x06043DA2 ; mov.l r1,@r13
L_06043D9E:
    c.r[1] = 0x0u;  // 06043D9E mov #0,r1
L_06043DA0:
    st32(c.r[13], c.r[1]);  // 06043DA0 mov.l r1,@r13
L_06043DA2:
    c.r[1] = c.r[4];  // 06043DA2 mov r4,r1
    c.r[1] -= c.r[2];  // 06043DA4 sub r2,r1
    c.r[1] -= c.r[5];  // 06043DA6 sub r5,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043E5Au);  // 06043DA8 mov.w 0x06043E5A,r0
    c.t = c.r[1] > c.r[0];  // 06043DAA cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043E10; } }  // 06043DAC bt/s 0x06043E10 ; mov r1,r0
    c.r[0] <<= 2;  // 06043DB0 shll2 r0
    c.r[13] = c.r[0];  // 06043DB2 mov r0,r13
    c.r[3] = ld32(c.r[14] + 12);  // 06043DB4 mov.l @(12,r14),r3
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043DB6 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043DB8 add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043DBA cmp/ge r3,r1
    { const bool k = !c.t; c.r[13] += c.r[10]; if (k) { goto L_06043DCA; } }  // 06043DBC bf/s 0x06043DCA ; add r10,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043DC0 cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043DD0; } }  // 06043DC2 bt/s 0x06043DD0 ; mov r4,r0
    c.r[1] = 0x0u; goto L_06043E0E;  // 06043DC6 bra 0x06043E0E ; mov #0,r1
L_06043DCA:
    c.t = (int32_t)c.r[3] >= 0;  // 06043DCA cmp/pz r3
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043E0C; } }  // 06043DCC bf/s 0x06043E0C ; mov r4,r0
L_06043DD0:
    c.r[0] -= c.r[2];  // 06043DD0 sub r2,r0
    c.r[0] -= c.r[5];  // 06043DD2 sub r5,r0
    c.r[3] = ld32(c.r[14] + 12);  // 06043DD4 mov.l @(12,r14),r3
    c.r[0] <<= 2;  // 06043DD6 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043DD8 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043DDA add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043DDC cmp/ge r3,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[11]; if (k) { goto L_06043DEA; } }  // 06043DDE bf/s 0x06043DEA ; cmp/gt r11,r1
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043DF0; } }  // 06043DE2 bf/s 0x06043DF0 ; mov r4,r0
    goto L_06043E06;  // 06043DE6 bra 0x06043E06 ; nop
L_06043DEA:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[11];  // 06043DEA cmp/gt r11,r3
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043E06; } }  // 06043DEC bt/s 0x06043E06 ; mov r4,r0
L_06043DF0:
    c.r[0] -= c.r[2];  // 06043DF0 sub r2,r0
    c.r[0] -= c.r[5];  // 06043DF2 sub r5,r0
    c.r[1] = ld32(c.r[14] + 12);  // 06043DF4 mov.l @(12,r14),r1
    c.r[0] <<= 2;  // 06043DF6 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[10]);  // 06043DF8 mov.l @(r0,r10),r3
    c.r[1] += c.r[8];  // 06043DFA add r8,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06043DFC cmp/ge r1,r3
    if (!c.t) { goto L_06043E0E; }  // 06043DFE bf 0x06043E0E
    c.r[1] = c.r[3];  // 06043E00 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043E10;  // 06043E02 bra 0x06043E10 ; mov.l r1,@r13
L_06043E06:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043E58u);  // 06043E06 mov.w 0x06043E58,r1
    st32(c.r[13], c.r[1]); goto L_06043E10;  // 06043E08 bra 0x06043E10 ; mov.l r1,@r13
L_06043E0C:
    c.r[1] = 0x0u;  // 06043E0C mov #0,r1
L_06043E0E:
    st32(c.r[13], c.r[1]);  // 06043E0E mov.l r1,@r13
L_06043E10:
    c.r[1] = ld32(c.r[14] + 24);  // 06043E10 mov.l @(24,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043E5Au);  // 06043E12 mov.w 0x06043E5A,r0
    c.r[1] -= c.r[5];  // 06043E14 sub r5,r1
    c.t = c.r[1] > c.r[0];  // 06043E16 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043E82; } }  // 06043E18 bt/s 0x06043E82 ; mov r1,r0
    c.r[0] <<= 2;  // 06043E1C shll2 r0
    c.r[13] = c.r[0];  // 06043E1E mov r0,r13
    c.r[3] = c.r[7];  // 06043E20 mov r7,r3
    c.r[3] += c.r[2];  // 06043E22 add r2,r3
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043E24 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043E26 add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043E28 cmp/ge r3,r1
    { const bool k = !c.t; c.r[13] += c.r[10]; if (k) { goto L_06043E38; } }  // 06043E2A bf/s 0x06043E38 ; add r10,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043E2E cmp/pz r1
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_06043E3E; } }  // 06043E30 bt/s 0x06043E3E ; mov r7,r3
    c.r[1] = 0x0u; goto L_06043E80;  // 06043E34 bra 0x06043E80 ; mov #0,r1
L_06043E38:
    c.t = (int32_t)c.r[3] >= 0;  // 06043E38 cmp/pz r3
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_06043E7E; } }  // 06043E3A bf/s 0x06043E7E ; mov r7,r3
L_06043E3E:
    c.r[0] = ld32(c.r[14] + 24);  // 06043E3E mov.l @(24,r14),r0
    c.r[3] += c.r[2];  // 06043E40 add r2,r3
    c.r[0] -= c.r[5];  // 06043E42 sub r5,r0
    c.r[0] <<= 2;  // 06043E44 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043E46 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043E48 add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043E4A cmp/ge r3,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[11]; if (k) { goto L_06043E5C; } }  // 06043E4C bf/s 0x06043E5C ; cmp/gt r11,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06043E62; } }  // 06043E50 bf/s 0x06043E62 ; mov r7,r1
    goto L_06043E78;  // 06043E54 bra 0x06043E78 ; nop
L_06043E5C:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[11];  // 06043E5C cmp/gt r11,r3
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06043E78; } }  // 06043E5E bt/s 0x06043E78 ; mov r7,r1
L_06043E62:
    c.r[0] = ld32(c.r[14] + 24);  // 06043E62 mov.l @(24,r14),r0
    c.r[1] += c.r[2];  // 06043E64 add r2,r1
    c.r[0] -= c.r[5];  // 06043E66 sub r5,r0
    c.r[0] <<= 2;  // 06043E68 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[10]);  // 06043E6A mov.l @(r0,r10),r3
    c.r[1] += c.r[8];  // 06043E6C add r8,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06043E6E cmp/ge r1,r3
    if (!c.t) { goto L_06043E80; }  // 06043E70 bf 0x06043E80
    c.r[1] = c.r[3];  // 06043E72 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043E82;  // 06043E74 bra 0x06043E82 ; mov.l r1,@r13
L_06043E78:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043F3Au);  // 06043E78 mov.w 0x06043F3A,r1
    st32(c.r[13], c.r[1]); goto L_06043E82;  // 06043E7A bra 0x06043E82 ; mov.l r1,@r13
L_06043E7E:
    c.r[1] = 0x0u;  // 06043E7E mov #0,r1
L_06043E80:
    st32(c.r[13], c.r[1]);  // 06043E80 mov.l r1,@r13
L_06043E82:
    c.r[1] = ld32(c.r[14] + 16);  // 06043E82 mov.l @(16,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043F3Cu);  // 06043E84 mov.w 0x06043F3C,r0
    c.r[1] += c.r[6];  // 06043E86 add r6,r1
    c.t = c.r[1] > c.r[0];  // 06043E88 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06043EF0; } }  // 06043E8A bt/s 0x06043EF0 ; mov r1,r0
    c.r[0] <<= 2;  // 06043E8E shll2 r0
    c.r[13] = c.r[0];  // 06043E90 mov r0,r13
    c.r[3] = c.r[7];  // 06043E92 mov r7,r3
    c.r[3] += c.r[2];  // 06043E94 add r2,r3
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043E96 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043E98 add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043E9A cmp/ge r3,r1
    { const bool k = !c.t; c.r[13] += c.r[10]; if (k) { goto L_06043EAA; } }  // 06043E9C bf/s 0x06043EAA ; add r10,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043EA0 cmp/pz r1
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_06043EB0; } }  // 06043EA2 bt/s 0x06043EB0 ; mov r7,r3
    c.r[1] = 0x0u; goto L_06043EEE;  // 06043EA6 bra 0x06043EEE ; mov #0,r1
L_06043EAA:
    c.t = (int32_t)c.r[3] >= 0;  // 06043EAA cmp/pz r3
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_06043EEC; } }  // 06043EAC bf/s 0x06043EEC ; mov r7,r3
L_06043EB0:
    c.r[0] = ld32(c.r[14] + 16);  // 06043EB0 mov.l @(16,r14),r0
    c.r[3] += c.r[2];  // 06043EB2 add r2,r3
    c.r[0] += c.r[6];  // 06043EB4 add r6,r0
    c.r[0] <<= 2;  // 06043EB6 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043EB8 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043EBA add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043EBC cmp/ge r3,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[11]; if (k) { goto L_06043ECA; } }  // 06043EBE bf/s 0x06043ECA ; cmp/gt r11,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06043ED0; } }  // 06043EC2 bf/s 0x06043ED0 ; mov r7,r1
    goto L_06043EE6;  // 06043EC6 bra 0x06043EE6 ; nop
L_06043ECA:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[11];  // 06043ECA cmp/gt r11,r3
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06043EE6; } }  // 06043ECC bt/s 0x06043EE6 ; mov r7,r1
L_06043ED0:
    c.r[0] = ld32(c.r[14] + 16);  // 06043ED0 mov.l @(16,r14),r0
    c.r[1] += c.r[2];  // 06043ED2 add r2,r1
    c.r[0] += c.r[6];  // 06043ED4 add r6,r0
    c.r[0] <<= 2;  // 06043ED6 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[10]);  // 06043ED8 mov.l @(r0,r10),r3
    c.r[1] += c.r[8];  // 06043EDA add r8,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06043EDC cmp/ge r1,r3
    if (!c.t) { goto L_06043EEE; }  // 06043EDE bf 0x06043EEE
    c.r[1] = c.r[3];  // 06043EE0 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043EF0;  // 06043EE2 bra 0x06043EF0 ; mov.l r1,@r13
L_06043EE6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06043F3Au);  // 06043EE6 mov.w 0x06043F3A,r1
    st32(c.r[13], c.r[1]); goto L_06043EF0;  // 06043EE8 bra 0x06043EF0 ; mov.l r1,@r13
L_06043EEC:
    c.r[1] = 0x0u;  // 06043EEC mov #0,r1
L_06043EEE:
    st32(c.r[13], c.r[1]);  // 06043EEE mov.l r1,@r13
L_06043EF0:
    c.r[1] = c.r[4];  // 06043EF0 mov r4,r1
    c.r[1] += c.r[2];  // 06043EF2 add r2,r1
    c.r[1] += c.r[6];  // 06043EF4 add r6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06043F3Cu);  // 06043EF6 mov.w 0x06043F3C,r0
    c.t = c.r[1] > c.r[0];  // 06043EF8 cmp/hi r0,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06043F66; } }  // 06043EFA bt/s 0x06043F66 ; mov.l @(8,r14),r0
    c.r[0] = c.r[1];  // 06043EFE mov r1,r0
    c.r[0] <<= 2;  // 06043F00 shll2 r0
    c.r[13] = c.r[0];  // 06043F02 mov r0,r13
    c.r[3] = ld32(c.r[14] + 12);  // 06043F04 mov.l @(12,r14),r3
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043F06 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043F08 add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043F0A cmp/ge r3,r1
    { const bool k = !c.t; c.r[13] += c.r[10]; if (k) { goto L_06043F1A; } }  // 06043F0C bf/s 0x06043F1A ; add r10,r13
    c.t = (int32_t)c.r[1] >= 0;  // 06043F10 cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043F20; } }  // 06043F12 bt/s 0x06043F20 ; mov r4,r0
    c.r[1] = 0x0u; goto L_06043F62;  // 06043F16 bra 0x06043F62 ; mov #0,r1
L_06043F1A:
    c.t = (int32_t)c.r[3] >= 0;  // 06043F1A cmp/pz r3
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043F60; } }  // 06043F1C bf/s 0x06043F60 ; mov r4,r0
L_06043F20:
    c.r[0] += c.r[2];  // 06043F20 add r2,r0
    c.r[0] += c.r[6];  // 06043F22 add r6,r0
    c.r[3] = ld32(c.r[14] + 12);  // 06043F24 mov.l @(12,r14),r3
    c.r[0] <<= 2;  // 06043F26 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043F28 mov.l @(r0,r10),r1
    c.r[3] += c.r[8];  // 06043F2A add r8,r3
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 06043F2C cmp/ge r3,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[11]; if (k) { goto L_06043F3E; } }  // 06043F2E bf/s 0x06043F3E ; cmp/gt r11,r1
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_06043F44; } }  // 06043F32 bf/s 0x06043F44 ; mov r4,r0
    goto L_06043F5A;  // 06043F36 bra 0x06043F5A ; nop
L_06043F3E:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[11];  // 06043F3E cmp/gt r11,r3
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06043F5A; } }  // 06043F40 bt/s 0x06043F5A ; mov r4,r0
L_06043F44:
    c.r[0] += c.r[2];  // 06043F44 add r2,r0
    c.r[0] += c.r[6];  // 06043F46 add r6,r0
    c.r[1] = ld32(c.r[14] + 12);  // 06043F48 mov.l @(12,r14),r1
    c.r[0] <<= 2;  // 06043F4A shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[10]);  // 06043F4C mov.l @(r0,r10),r3
    c.r[1] += c.r[8];  // 06043F4E add r8,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06043F50 cmp/ge r1,r3
    if (!c.t) { goto L_06043F62; }  // 06043F52 bf 0x06043F62
    c.r[1] = c.r[3];  // 06043F54 mov r3,r1
    st32(c.r[13], c.r[1]); goto L_06043F64;  // 06043F56 bra 0x06043F64 ; mov.l r1,@r13
L_06043F5A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044040u);  // 06043F5A mov.w 0x06044040,r1
    st32(c.r[13], c.r[1]); goto L_06043F64;  // 06043F5C bra 0x06043F64 ; mov.l r1,@r13
L_06043F60:
    c.r[1] = 0x0u;  // 06043F60 mov #0,r1
L_06043F62:
    st32(c.r[13], c.r[1]);  // 06043F62 mov.l r1,@r13
L_06043F64:
    c.r[0] = ld32(c.r[14] + 8);  // 06043F64 mov.l @(8,r14),r0
L_06043F66:
    c.r[1] = ld32(c.r[14] + 4);  // 06043F66 mov.l @(4,r14),r1
    c.r[0] += 1;  // 06043F68 add #1,r0
    c.r[1] += c.r[1];  // 06043F6A add r1,r1
    c.r[0] -= c.r[1];  // 06043F6C sub r1,r0
    st32(c.r[14] + 8, c.r[0]);  // 06043F6E mov.l r0,@(8,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 06043F70 mov.l @(12,r14),r0
    c.r[0] += 1;  // 06043F72 add #1,r0
    st32(c.r[14] + 12, c.r[0]);  // 06043F74 mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 06043F76 mov.l @(16,r14),r0
    c.r[0] += 1;  // 06043F78 add #1,r0
    st32(c.r[14] + 16, c.r[0]);  // 06043F7A mov.l r0,@(16,r14)
    c.r[0] = ld32(c.r[14] + 20);  // 06043F7C mov.l @(20,r14),r0
    c.r[0] -= 1;  // 06043F7E add #-1,r0
    st32(c.r[14] + 20, c.r[0]);  // 06043F80 mov.l r0,@(20,r14)
    c.r[0] = ld32(c.r[14] + 24);  // 06043F82 mov.l @(24,r14),r0
    c.r[0] -= 1;  // 06043F84 add #-1,r0
    st32(c.r[14] + 24, c.r[0]);  // 06043F86 mov.l r0,@(24,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 06043F88 mov.l @(4,r14),r0
    c.r[0] += 1;  // 06043F8A add #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 06043F8C mov.l r0,@(4,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 06043F8E mov.l @(8,r14),r0
    c.t = (int32_t)c.r[0] >= 0;  // 06043F90 cmp/pz r0
    if (c.t) { goto L_06043F9E; }  // 06043F92 bt 0x06043F9E
    c.r[2] -= 1;  // 06043F94 add #-1,r2
    c.r[1] = c.r[2];  // 06043F96 mov r2,r1
    c.r[1] += c.r[1];  // 06043F98 add r1,r1
    c.r[0] += c.r[1];  // 06043F9A add r1,r0
    st32(c.r[14] + 8, c.r[0]);  // 06043F9C mov.l r0,@(8,r14)
L_06043F9E:
    c.r[0] = ld32(c.r[14] + 4);  // 06043F9E mov.l @(4,r14),r0
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[0];  // 06043FA0 cmp/ge r0,r2
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 24); if (k) { goto L_06043FAA; } }  // 06043FA2 bf/s 0x06043FAA ; mov.l @(24,r14),r1
    SH2_POLL(c); goto L_06043BD2;  // 06043FA6 bra 0x06043BD2 ; nop
L_06043FAA:
    c.r[3] = 0x0u;  // 06043FAA mov #0,r3
    c.r[10] = ld32(0x06044044u);  // 06043FAC mov.l 0x06044044,r10
    c.r[9] = ld32(0x06044048u);  // 06043FAE mov.l 0x06044048,r9
    c.r[8] = c.r[4];  // 06043FB0 mov r4,r8
    c.r[8] -= c.r[5];  // 06043FB2 sub r5,r8
    c.r[8] <<= 2;  // 06043FB4 shll2 r8
    c.r[7] = c.r[4];  // 06043FB6 mov r4,r7
    c.r[7] += c.r[6];  // 06043FB8 add r6,r7
    c.r[7] <<= 2;  // 06043FBA shll2 r7
    c.r[11] = 0x0u;  // 06043FBC mov #0,r11
L_06043FBE:
    c.r[0] = c.r[11];  // 06043FBE mov r11,r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 06043FC0 mov.l @(r0,r10),r1
    c.r[2] = ld32(c.r[0] + c.r[9]);  // 06043FC2 mov.l @(r0,r9),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06043FC4 cmp/gt r2,r1
    { const bool k = c.t; c.t = (c.r[5] & c.r[5]) == 0; if (k) { goto L_06043FD8; } }  // 06043FC6 bt/s 0x06043FD8 ; tst r5,r5
    c.r[1] <<= 16;  // 06043FCA shll16 r1
    c.r[1] += c.r[1];  // 06043FCC add r1,r1
    c.r[2] += c.r[2];  // 06043FCE add r2,r2
    c.r[0] = ld32(c.r[14]);  // 06043FD0 mov.l @r14,r0
    c.r[1] |= c.r[2];  // 06043FD2 or r2,r1
    st32(c.r[0] + c.r[11], c.r[1]); goto L_06044022;  // 06043FD4 bra 0x06044022 ; mov.l r1,@(r0,r11)
L_06043FD8:
    { const bool k = c.t; c.t = (c.r[6] & c.r[6]) == 0; if (k) { goto L_06044000; } }  // 06043FD8 bt/s 0x06044000 ; tst r6,r6
    c.r[1] = c.r[3];  // 06043FDC mov r3,r1
    c.r[1] -= c.r[4];  // 06043FDE sub r4,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06043FE0 cmp/pz r1
    if (c.t) { goto L_06043FE6; }  // 06043FE2 bt 0x06043FE6
    c.r[1] = 0u - c.r[1];  // 06043FE4 neg r1,r1
L_06043FE6:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[5];  // 06043FE6 cmp/ge r5,r1
    { const bool k = c.t; c.t = (c.r[6] & c.r[6]) == 0; if (k) { goto L_06044000; } }  // 06043FE8 bt/s 0x06044000 ; tst r6,r6
    c.r[0] = c.r[8];  // 06043FEC mov r8,r0
    c.r[2] = ld32(c.r[0] + c.r[10]);  // 06043FEE mov.l @(r0,r10),r2
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 06043FF0 mov.l @(r0,r9),r1
    c.r[2] <<= 16;  // 06043FF2 shll16 r2
    c.r[2] += c.r[2];  // 06043FF4 add r2,r2
    c.r[1] += c.r[1];  // 06043FF6 add r1,r1
    c.r[0] = ld32(c.r[14]);  // 06043FF8 mov.l @r14,r0
    c.r[2] |= c.r[1];  // 06043FFA or r1,r2
    st32(c.r[0] + c.r[11], c.r[2]);  // 06043FFC mov.l r2,@(r0,r11)
    c.t = (c.r[6] & c.r[6]) == 0;  // 06043FFE tst r6,r6
L_06044000:
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06044022; } }  // 06044000 bt/s 0x06044022 ; mov r3,r1
    c.r[1] -= c.r[4];  // 06044004 sub r4,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06044006 cmp/pz r1
    if (c.t) { goto L_0604400C; }  // 06044008 bt 0x0604400C
    c.r[1] = 0u - c.r[1];  // 0604400A neg r1,r1
L_0604400C:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[6];  // 0604400C cmp/ge r6,r1
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_06044022; } }  // 0604400E bt/s 0x06044022 ; mov r7,r0
    c.r[2] = ld32(c.r[0] + c.r[10]);  // 06044012 mov.l @(r0,r10),r2
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 06044014 mov.l @(r0,r9),r1
    c.r[2] <<= 16;  // 06044016 shll16 r2
    c.r[2] += c.r[2];  // 06044018 add r2,r2
    c.r[1] += c.r[1];  // 0604401A add r1,r1
    c.r[0] = ld32(c.r[14]);  // 0604401C mov.l @r14,r0
    c.r[2] |= c.r[1];  // 0604401E or r1,r2
    st32(c.r[0] + c.r[11], c.r[2]);  // 06044020 mov.l r2,@(r0,r11)
L_06044022:
    c.r[3] += 1;  // 06044022 add #1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044042u);  // 06044024 mov.w 0x06044042,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06044026 cmp/gt r1,r3
    { const bool k = !c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_06043FBE; } }  // 06044028 bf/s 0x06043FBE ; add #4,r11
L_0604402C:
    c.r[14] += 32;  // 0604402C add #32,r14
    c.r[15] = c.r[14];  // 0604402E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044030 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06044032 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06044034 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06044036 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06044038 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604403A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604403C rts ; mov.l @r15+,r8
}

void f_0604404C(SH2Context& c) {
    ran[1102] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604404C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604404E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06044050 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06044052 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06044054 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044056 mov.l r14,@-r15
    c.r[1] = c.r[4];  // 06044058 mov r4,r1
    c.r[1] += 6;  // 0604405A add #6,r1
    c.r[0] = 0x6u;  // 0604405C mov #6,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604405E mov.w @r1,r2
    c.r[3] = ld32(0x060441C8u);  // 06044060 mov.l 0x060441C8,r3
    c.r[1] = c.r[2];  // 06044062 mov r2,r1
    c.r[1] >>= 2;  // 06044064 shlr2 r1
    c.r[1] >>= 2;  // 06044066 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06044068 shlr r1
    c.r[1] >>= 2;  // 0604406A shlr2 r1
    c.r[1] &= c.r[0];  // 0604406C and r0,r1
    c.r[0] = c.r[1];  // 0604406E mov r1,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06044070 extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06044072 mov.w @(r0,r3),r1
    c.r[2] += c.r[2];  // 06044074 add r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06044076 extu.w r1,r1
    c.r[1] += c.r[3];  // 06044078 add r3,r1
    c.r[0] = c.r[2];  // 0604407A mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604407C mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604407E extu.w r1,r1
    c.r[10] = c.r[1];  // 06044080 mov r1,r10
    c.r[2] = c.r[4];  // 06044082 mov r4,r2
    c.r[0] = c.r[1];  // 06044084 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06044086 mov.w @(r0,r3),r1
    c.r[2] += 8;  // 06044088 add #8,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604408A mov.w @r2,r2
    c.r[10] += c.r[3];  // 0604408C add r3,r10
    c.r[1] += c.r[2];  // 0604408E add r2,r1
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06044090 exts.w r1,r5
    c.r[1] = c.r[10];  // 06044092 mov r10,r1
    c.r[1] += 2;  // 06044094 add #2,r1
    c.r[2] = c.r[4];  // 06044096 mov r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044098 mov.w @r1,r1
    c.r[2] += 10;  // 0604409A add #10,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604409C mov.w @r2,r2
    c.r[1] += c.r[2];  // 0604409E add r2,r1
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060440A0 exts.w r1,r12
    c.r[2] = c.r[4];  // 060440A2 mov r4,r2
    c.r[1] = c.r[10];  // 060440A4 mov r10,r1
    c.r[1] += 4;  // 060440A6 add #4,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060440A8 mov.w @r1,r3
    c.r[2] += 2;  // 060440AA add #2,r2
    st16(c.r[2], c.r[3]);  // 060440AC mov.w r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060440AE mov.b @r4,r1
    c.r[0] = 0x1u;  // 060440B0 mov #1,r0
    c.r[1] >>= 2;  // 060440B2 shlr2 r1
    c.r[1] &= c.r[0];  // 060440B4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060440B6 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06044166; } }  // 060440B8 bt/s 0x06044166 ; mov r15,r14
    c.r[8] = ld32(0x060441CCu);  // 060440BC mov.l 0x060441CC,r8
    c.r[6] = 0x0u;  // 060440BE mov #0,r6
    c.r[1] = c.r[3] & 0xFFFFu;  // 060440C0 extu.w r3,r1
    c.r[1] += c.r[1];  // 060440C2 add r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 060440C4 cmp/ge r1,r6
    if (c.t) { goto L_06044166; }  // 060440C6 bt 0x06044166
    c.r[9] = (uint32_t)(int16_t)ld16(0x060441C2u);  // 060440C8 mov.w 0x060441C2,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x060441C4u);  // 060440CA mov.w 0x060441C4,r11
L_060440CC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060440CC mov.b @r4,r1
    c.r[0] = c.r[1];  // 060440CE mov r1,r0
    c.r[0] >>= 2;  // 060440D0 shlr2 r0
    c.r[0] >>= 2;  // 060440D2 shlr2 r0
    c.r[0] &= 0x1u;  // 060440D4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060440D6 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_06044104; } }  // 060440D8 bt/s 0x06044104 ; mov r6,r2
    c.r[2] += c.r[2];  // 060440DC add r2,r2
    c.r[2] += c.r[10];  // 060440DE add r10,r2
    c.r[1] = c.r[2];  // 060440E0 mov r2,r1
    c.r[1] += 6;  // 060440E2 add #6,r1
    c.r[0] = c.r[5];  // 060440E4 mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060440E6 mov.w @r1,r1
    c.r[2] += 8;  // 060440E8 add #8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060440EA extu.w r1,r1
    c.r[0] -= c.r[1];  // 060440EC sub r1,r0
    c.r[1] = c.r[0];  // 060440EE mov r0,r1
    c.r[1] += c.r[1];  // 060440F0 add r1,r1
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060440F2 exts.w r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060440F4 mov.w @r2,r1
    c.r[0] = c.r[5];  // 060440F6 mov r5,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 060440F8 extu.w r1,r1
    c.r[0] -= c.r[1];  // 060440FA sub r1,r0
    c.r[1] = c.r[0];  // 060440FC mov r0,r1
    c.r[1] += c.r[1];  // 060440FE add r1,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_06044122;  // 06044100 bra 0x06044122 ; exts.w r1,r3
L_06044104:
    c.r[2] += c.r[2];  // 06044104 add r2,r2
    c.r[2] += c.r[10];  // 06044106 add r10,r2
    c.r[1] = c.r[2];  // 06044108 mov r2,r1
    c.r[1] += 6;  // 0604410A add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604410C mov.w @r1,r1
    c.r[2] += 8;  // 0604410E add #8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06044110 extu.w r1,r1
    c.r[1] += c.r[5];  // 06044112 add r5,r1
    c.r[1] += c.r[1];  // 06044114 add r1,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06044116 exts.w r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06044118 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604411A extu.w r1,r1
    c.r[1] += c.r[5];  // 0604411C add r5,r1
    c.r[1] += c.r[1];  // 0604411E add r1,r1
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06044120 exts.w r1,r7
L_06044122:
    c.t = (int32_t)c.r[3] >= 0;  // 06044122 cmp/pz r3
    if (c.t) { goto L_06044128; }  // 06044124 bt 0x06044128
    c.r[3] = 0xFFFFFFFFu;  // 06044126 mov #-1,r3
L_06044128:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[9];  // 06044128 cmp/gt r9,r3
    if (!c.t) { goto L_0604412E; }  // 0604412A bf 0x0604412E
    c.r[3] = c.r[9];  // 0604412C mov r9,r3
L_0604412E:
    c.r[1] = c.r[6];  // 0604412E mov r6,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06044130 shlr r1
    c.r[1] += c.r[12];  // 06044132 add r12,r1
    c.r[0] = c.r[1];  // 06044134 mov r1,r0
    c.r[0] &= c.r[11];  // 06044136 and r11,r0
    c.r[0] += c.r[0];  // 06044138 add r0,r0
    c.t = (int32_t)c.r[7] >= 0;  // 0604413A cmp/pz r7
    { const bool k = c.t; st16(c.r[0] + c.r[8], c.r[3]); if (k) { goto L_06044142; } }  // 0604413C bt/s 0x06044142 ; mov.w r3,@(r0,r8)
    c.r[7] = 0xFFFFFFFFu;  // 06044140 mov #-1,r7
L_06044142:
    c.t = (int32_t)c.r[7] > (int32_t)c.r[9];  // 06044142 cmp/gt r9,r7
    if (!c.t) { goto L_06044148; }  // 06044144 bf 0x06044148
    c.r[7] = c.r[9];  // 06044146 mov r9,r7
L_06044148:
    c.r[1] += 1;  // 06044148 add #1,r1
    c.r[1] &= c.r[11];  // 0604414A and r11,r1
    c.r[1] += c.r[1];  // 0604414C add r1,r1
    c.r[0] = c.r[1];  // 0604414E mov r1,r0
    st16(c.r[0] + c.r[8], c.r[7]);  // 06044150 mov.w r7,@(r0,r8)
    c.r[1] = c.r[6];  // 06044152 mov r6,r1
    c.r[1] += 4;  // 06044154 add #4,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06044156 extu.w r1,r6
    c.r[1] = c.r[4];  // 06044158 mov r4,r1
    c.r[1] += 2;  // 0604415A add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604415C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604415E extu.w r1,r1
    c.r[1] += c.r[1];  // 06044160 add r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06044162 cmp/ge r1,r6
    if (!c.t) { SH2_POLL(c); goto L_060440CC; }  // 06044164 bf 0x060440CC
L_06044166:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06044166 mov.b @r4,r1
    c.r[0] = c.r[1];  // 06044168 mov r1,r0
    c.r[0] >>= 2;  // 0604416A shlr2 r0
    c.r[0] &= 0x2u;  // 0604416C and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604416E tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06044238; } }  // 06044170 bt/s 0x06044238 ; mov r14,r15
    c.r[8] = ld32(0x060441D0u);  // 06044174 mov.l 0x060441D0,r8
    c.r[1] = c.r[4];  // 06044176 mov r4,r1
    c.r[1] += 2;  // 06044178 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604417A mov.w @r1,r1
    c.r[6] = 0x0u;  // 0604417C mov #0,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604417E extu.w r1,r1
    c.r[1] += c.r[1];  // 06044180 add r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06044182 cmp/ge r1,r6
    if (c.t) { goto L_06044238; }  // 06044184 bt 0x06044238
    c.r[9] = (uint32_t)(int16_t)ld16(0x060441C2u);  // 06044186 mov.w 0x060441C2,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x060441C4u);  // 06044188 mov.w 0x060441C4,r11
L_0604418A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604418A mov.b @r4,r1
    c.r[0] = c.r[1];  // 0604418C mov r1,r0
    c.r[0] >>= 2;  // 0604418E shlr2 r0
    c.r[0] >>= 2;  // 06044190 shlr2 r0
    c.r[0] &= 0x1u;  // 06044192 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044194 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_060441D4; } }  // 06044196 bt/s 0x060441D4 ; mov r6,r2
    c.r[2] += c.r[2];  // 0604419A add r2,r2
    c.r[2] += c.r[10];  // 0604419C add r10,r2
    c.r[1] = c.r[2];  // 0604419E mov r2,r1
    c.r[1] += 10;  // 060441A0 add #10,r1
    c.r[0] = c.r[5];  // 060441A2 mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060441A4 mov.w @r1,r1
    c.r[2] += 12;  // 060441A6 add #12,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060441A8 extu.w r1,r1
    c.r[0] -= c.r[1];  // 060441AA sub r1,r0
    c.r[1] = c.r[0];  // 060441AC mov r0,r1
    c.r[1] += c.r[1];  // 060441AE add r1,r1
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060441B0 exts.w r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060441B2 mov.w @r2,r1
    c.r[0] = c.r[5];  // 060441B4 mov r5,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 060441B6 extu.w r1,r1
    c.r[0] -= c.r[1];  // 060441B8 sub r1,r0
    c.r[1] = c.r[0];  // 060441BA mov r0,r1
    c.r[1] += c.r[1];  // 060441BC add r1,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_060441F2;  // 060441BE bra 0x060441F2 ; exts.w r1,r3
L_060441D4:
    c.r[2] += c.r[2];  // 060441D4 add r2,r2
    c.r[2] += c.r[10];  // 060441D6 add r10,r2
    c.r[1] = c.r[2];  // 060441D8 mov r2,r1
    c.r[1] += 10;  // 060441DA add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060441DC mov.w @r1,r1
    c.r[2] += 12;  // 060441DE add #12,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060441E0 extu.w r1,r1
    c.r[1] += c.r[5];  // 060441E2 add r5,r1
    c.r[1] += c.r[1];  // 060441E4 add r1,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060441E6 exts.w r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060441E8 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060441EA extu.w r1,r1
    c.r[1] += c.r[5];  // 060441EC add r5,r1
    c.r[1] += c.r[1];  // 060441EE add r1,r1
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060441F0 exts.w r1,r7
L_060441F2:
    c.t = (int32_t)c.r[3] >= 0;  // 060441F2 cmp/pz r3
    if (c.t) { goto L_060441F8; }  // 060441F4 bt 0x060441F8
    c.r[3] = 0xFFFFFFFFu;  // 060441F6 mov #-1,r3
L_060441F8:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[9];  // 060441F8 cmp/gt r9,r3
    if (!c.t) { goto L_060441FE; }  // 060441FA bf 0x060441FE
    c.r[3] = c.r[9];  // 060441FC mov r9,r3
L_060441FE:
    c.r[1] = c.r[6];  // 060441FE mov r6,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06044200 shlr r1
    c.r[1] += c.r[12];  // 06044202 add r12,r1
    c.r[0] = c.r[1];  // 06044204 mov r1,r0
    c.r[0] &= c.r[11];  // 06044206 and r11,r0
    c.r[0] += c.r[0];  // 06044208 add r0,r0
    c.t = (int32_t)c.r[7] >= 0;  // 0604420A cmp/pz r7
    { const bool k = c.t; st16(c.r[0] + c.r[8], c.r[3]); if (k) { goto L_06044212; } }  // 0604420C bt/s 0x06044212 ; mov.w r3,@(r0,r8)
    c.r[7] = 0xFFFFFFFFu;  // 06044210 mov #-1,r7
L_06044212:
    c.t = (int32_t)c.r[7] > (int32_t)c.r[9];  // 06044212 cmp/gt r9,r7
    if (!c.t) { goto L_06044218; }  // 06044214 bf 0x06044218
    c.r[7] = c.r[9];  // 06044216 mov r9,r7
L_06044218:
    c.r[1] += 1;  // 06044218 add #1,r1
    c.r[1] &= c.r[11];  // 0604421A and r11,r1
    c.r[1] += c.r[1];  // 0604421C add r1,r1
    c.r[0] = c.r[1];  // 0604421E mov r1,r0
    st16(c.r[0] + c.r[8], c.r[7]);  // 06044220 mov.w r7,@(r0,r8)
    c.r[1] = c.r[6];  // 06044222 mov r6,r1
    c.r[1] += 4;  // 06044224 add #4,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06044226 extu.w r1,r6
    c.r[1] = c.r[4];  // 06044228 mov r4,r1
    c.r[1] += 2;  // 0604422A add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604422C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604422E extu.w r1,r1
    c.r[1] += c.r[1];  // 06044230 add r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06044232 cmp/ge r1,r6
    if (!c.t) { SH2_POLL(c); goto L_0604418A; }  // 06044234 bf 0x0604418A
    c.r[15] = c.r[14];  // 06044236 mov r14,r15
L_06044238:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044238 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604423A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604423C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604423E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06044240 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044242 rts ; mov.l @r15+,r8
}

void f_06044248(SH2Context& c) {
    ran[1103] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06044248 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604424A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604424C mov.l r14,@-r15
    c.r[3] = c.r[6];  // 0604424E mov r6,r3
    c.r[1] = c.r[4];  // 06044250 mov r4,r1
    c.r[1] += 54;  // 06044252 add #54,r1
    c.r[9] = 0x3u;  // 06044254 mov #3,r9
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044256 mov.w @r1,r2
    c.r[3] &= c.r[9];  // 06044258 and r9,r3
    c.r[1] = 0x2Cu;  // 0604425A mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604425C mulu.w r1,r2
    c.r[3] <<= 2;  // 0604425E shll2 r3
    c.r[7] = c.macl;  // 06044260 sts macl,r7
    c.r[1] = ld32(0x06044320u);  // 06044262 mov.l 0x06044320,r1
    c.r[7] += c.r[1];  // 06044264 add r1,r7
    c.r[1] = c.r[4];  // 06044266 mov r4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06044268 mov.b @r7,r0
    c.r[1] += 6;  // 0604426A add #6,r1
    c.r[0] &= 0xF3u;  // 0604426C and #243,r0
    c.r[0] |= c.r[3];  // 0604426E or r3,r0
    st8(c.r[7], c.r[0]);  // 06044270 mov.b r0,@r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044272 mov.w @r1,r3
    c.r[1] = c.r[4];  // 06044274 mov r4,r1
    c.r[1] += 10;  // 06044276 add #10,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044278 mov.w @r1,r6
    c.r[14] = c.r[15];  // 0604427A mov r15,r14
    c.r[1] = c.r[4];  // 0604427C mov r4,r1
    c.r[1] += 1;  // 0604427E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044280 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06044282 mov r1,r0
    c.r[0] >>= 2;  // 06044284 shlr2 r0
    c.r[0] >>= 2;  // 06044286 shlr2 r0
    c.r[0] &= 0x1u;  // 06044288 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604428A tst r0,r0
    { const bool k = c.t; c.r[8] = c.r[5] & 0xFFFFu; if (k) { goto L_060442CC; } }  // 0604428C bt/s 0x060442CC ; extu.w r5,r8
    c.r[1] = ld32(0x06044324u);  // 06044290 mov.l 0x06044324,r1
    c.r[5] = 0x4Cu;  // 06044292 mov #76,r5
    c.r[2] = ld32(c.r[1]);  // 06044294 mov.l @r1,r2
    c.r[4] += 65;  // 06044296 add #65,r4
L_06044298:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06044298 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604429A extu.b r1,r1
    c.macl = c.r[1] * c.r[5];  // 0604429C mul.l r5,r1
    c.r[4] = c.macl;  // 0604429E sts macl,r4
    c.r[4] += c.r[2];  // 060442A0 add r2,r4
    c.r[1] = c.r[4];  // 060442A2 mov r4,r1
    c.r[1] += 6;  // 060442A4 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060442A6 mov.w @r1,r1
    c.r[1] += c.r[3];  // 060442A8 add r3,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060442AA exts.w r1,r3
    c.r[1] = c.r[4];  // 060442AC mov r4,r1
    c.r[1] += 10;  // 060442AE add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060442B0 mov.w @r1,r1
    c.r[1] += c.r[6];  // 060442B2 add r6,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060442B4 exts.w r1,r6
    c.r[1] = c.r[4];  // 060442B6 mov r4,r1
    c.r[1] += 1;  // 060442B8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060442BA mov.b @r1,r1
    c.r[0] = c.r[1];  // 060442BC mov r1,r0
    c.r[0] >>= 2;  // 060442BE shlr2 r0
    c.r[0] >>= 2;  // 060442C0 shlr2 r0
    c.r[0] &= 0x1u;  // 060442C2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060442C4 tst r0,r0
    { const bool k = !c.t; c.r[4] += 65; if (k) { SH2_POLL(c); goto L_06044298; } }  // 060442C6 bf/s 0x06044298 ; add #65,r4
    c.r[4] -= 65;  // 060442CA add #-65,r4
L_060442CC:
    c.r[1] = ld32(0x06044328u);  // 060442CC mov.l 0x06044328,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060442CE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060442D0 extu.b r1,r1
    c.r[0] = c.r[1];  // 060442D2 mov r1,r0
    c.r[0] >>= 2;  // 060442D4 shlr2 r0
    c.r[0] >>= 2;  // 060442D6 shlr2 r0
    c.r[0] >>= 2;  // 060442D8 shlr2 r0
    c.r[1] >>= 2;  // 060442DA shlr2 r1
    c.r[1] >>= 2;  // 060442DC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060442DE shlr r1
    c.r[1] >>= 2;  // 060442E0 shlr2 r1
    c.r[0] &= 0x1u;  // 060442E2 and #1,r0
    c.t = c.r[1] == c.r[0];  // 060442E4 cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_060442F0; } }  // 060442E6 bt/s 0x060442F0 ; mov r7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060442EA mov.b @r7,r0
    c.r[0] |= 0x10u;  // 060442EC or #16,r0
    st8(c.r[7], c.r[0]);  // 060442EE mov.b r0,@r7
L_060442F0:
    c.r[1] += 6;  // 060442F0 add #6,r1
    st16(c.r[1], c.r[8]);  // 060442F2 mov.w r8,@r1
    c.r[2] = c.r[7];  // 060442F4 mov r7,r2
    c.r[2] += 8;  // 060442F6 add #8,r2
    c.r[1] = c.r[3];  // 060442F8 mov r3,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060442FA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060442FC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060442FE shar r1
    st16(c.r[2], c.r[1]);  // 06044300 mov.w r1,@r2
    c.r[2] = c.r[7];  // 06044302 mov r7,r2
    c.r[2] += 10;  // 06044304 add #10,r2
    c.r[1] = c.r[6];  // 06044306 mov r6,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06044308 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604430A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0604430C shar r1
    st16(c.r[2], c.r[1]);  // 0604430E mov.w r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06044310 mov.b @r7,r0
    c.r[15] = c.r[14];  // 06044312 mov r14,r15
    c.r[0] |= 0x63u;  // 06044314 or #99,r0
    st8(c.r[7], c.r[0]);  // 06044316 mov.b r0,@r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044318 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604431A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604431C rts ; mov.l @r15+,r8
}

void f_0604432C(SH2Context& c) {
    ran[1104] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604432C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604432E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06044330 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06044332 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06044334 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06044336 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044338 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604433A sts.l pr,@-r15
    c.r[15] -= 32;  // 0604433C add #-32,r15
    c.r[14] = c.r[15];  // 0604433E mov r15,r14
    st32(c.r[14], c.r[5]);  // 06044340 mov.l r5,@r14
    c.r[5] = ld32(c.r[4] + 32);  // 06044342 mov.l @(32,r4),r5
    c.t = (int32_t)c.r[5] > 0;  // 06044344 cmp/pl r5
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0604434E; } }  // 06044346 bt/s 0x0604434E ; mov r4,r1
    goto L_06044542;  // 0604434A bra 0x06044542 ; nop
L_0604434E:
    c.r[1] += 12;  // 0604434E add #12,r1
    c.r[9] = 0x0u;  // 06044350 mov #0,r9
    c.r[6] = ld32(0x06044484u);  // 06044352 mov.l 0x06044484,r6
    c.r[7] = ld32(0x06044488u);  // 06044354 mov.l 0x06044488,r7
    c.r[3] = ld32(0x0604448Cu);  // 06044356 mov.l 0x0604448C,r3
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044358 mov.w @r1,r13
    c.r[2] = 0x0u;  // 0604435A mov #0,r2
    c.r[0] = ld32(c.r[4] + 36);  // 0604435C mov.l @(36,r4),r0
    c.r[1] = c.r[4];  // 0604435E mov r4,r1
    c.r[1] += 14;  // 06044360 add #14,r1
    c.r[10] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044362 mov.w @r1,r10
    c.r[13] <<= 8;  // 06044364 shll8 r13
    c.r[10] <<= 8;  // 06044366 shll8 r10
    c.r[5] <<= 8;  // 06044368 shll8 r5
    c.r[1] = ld32(c.r[4] + 24);  // 0604436A mov.l @(24,r4),r1
    st32(c.r[14] + 4, c.r[5]);  // 0604436C mov.l r5,@(4,r14)
    c.r[8] = ld32(c.r[14] + 4);  // 0604436E mov.l @(4,r14),r8
    c.r[0] += c.r[1];  // 06044370 add r1,r0
    c.r[0] <<= 8;  // 06044372 shll8 r0
    st32(c.r[14] + 8, c.r[0]);  // 06044374 mov.l r0,@(8,r14)
    c.r[0] = ld32(c.r[4] + 40);  // 06044376 mov.l @(40,r4),r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x06044480u);  // 06044378 mov.w 0x06044480,r5
    c.r[1] = ld32(c.r[4] + 28);  // 0604437A mov.l @(28,r4),r1
    st32(c.r[14] + 28, c.r[8]);  // 0604437C mov.l r8,@(28,r14)
    c.r[0] += c.r[1];  // 0604437E add r1,r0
    c.r[0] <<= 8;  // 06044380 shll8 r0
    st32(c.r[14] + 12, c.r[0]);  // 06044382 mov.l r0,@(12,r14)
    c.r[1] = 0x0u;  // 06044384 mov #0,r1
    c.r[4] = 0x0u;  // 06044386 mov #0,r4
L_06044388:
    c.r[0] = c.r[4];  // 06044388 mov r4,r0
    st32(c.r[0] + c.r[6], c.r[7]);  // 0604438A mov.l r7,@(r0,r6)
    st32(c.r[0] + c.r[3], c.r[2]);  // 0604438C mov.l r2,@(r0,r3)
    c.r[1] += 1;  // 0604438E add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5];  // 06044390 cmp/gt r5,r1
    { const bool k = !c.t; c.r[4] += 4; if (k) { SH2_POLL(c); goto L_06044388; } }  // 06044392 bf/s 0x06044388 ; add #4,r4
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06044396 cmp/ge r9,r8
    if (c.t) { goto L_0604439E; }  // 06044398 bt 0x0604439E
    goto L_06044512;  // 0604439A bra 0x06044512 ; nop
L_0604439E:
    c.r[11] = c.r[13];  // 0604439E mov r13,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x06044482u);  // 060443A0 mov.w 0x06044482,r12
    c.r[6] = ld32(0x06044484u);  // 060443A2 mov.l 0x06044484,r6
    c.r[11] -= c.r[9];  // 060443A4 sub r9,r11
    c.r[0] = ld32(c.r[14] + 8);  // 060443A6 mov.l @(8,r14),r0
L_060443A8:
    c.macl = c.r[8] * c.r[0];  // 060443A8 mul.l r0,r8
    c.r[7] = ld32(0x06044490u);  // 060443AA mov.l 0x06044490,r7
    c.r[5] = ld32(c.r[14] + 4);  // 060443AC mov.l @(4,r14),r5
    { const uint32_t x = c.r[7]; c.pr = 0x060443B2u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060443B2u) return; }  // 060443AE jsr @r7 ; sts macl,r4
    st32(c.r[14] + 16, c.r[0]);  // 060443B2 mov.l r0,@(16,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 060443B4 mov.l @(8,r14),r0
    c.macl = c.r[9] * c.r[0];  // 060443B6 mul.l r0,r9
    c.r[5] = ld32(c.r[14] + 4);  // 060443B8 mov.l @(4,r14),r5
    { const uint32_t x = c.r[7]; c.pr = 0x060443BEu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060443BEu) return; }  // 060443BA jsr @r7 ; sts macl,r4
    st32(c.r[14] + 20, c.r[0]);  // 060443BE mov.l r0,@(20,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 060443C0 mov.l @(12,r14),r0
    c.macl = c.r[8] * c.r[0];  // 060443C2 mul.l r0,r8
    c.r[5] = ld32(c.r[14] + 4);  // 060443C4 mov.l @(4,r14),r5
    { const uint32_t x = c.r[7]; c.pr = 0x060443CAu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060443CAu) return; }  // 060443C6 jsr @r7 ; sts macl,r4
    st32(c.r[14] + 24, c.r[0]);  // 060443CA mov.l r0,@(24,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 060443CC mov.l @(12,r14),r0
    c.macl = c.r[9] * c.r[0];  // 060443CE mul.l r0,r9
    c.r[5] = ld32(c.r[14] + 4);  // 060443D0 mov.l @(4,r14),r5
    { const uint32_t x = c.r[7]; c.pr = 0x060443D6u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060443D6u) return; }  // 060443D2 jsr @r7 ; sts macl,r4
    c.r[7] = c.r[0];  // 060443D6 mov r0,r7
    c.r[2] = c.r[13];  // 060443D8 mov r13,r2
    c.r[0] = ld32(c.r[14] + 20);  // 060443DA mov.l @(20,r14),r0
    c.r[1] = c.r[10];  // 060443DC mov r10,r1
    c.r[1] -= c.r[0];  // 060443DE sub r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060443E0 cmp/pz r1
    { const bool k = !c.t; c.r[2] -= c.r[8]; if (k) { goto L_060443FA; } }  // 060443E2 bf/s 0x060443FA ; sub r8,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[12];  // 060443E6 cmp/ge r12,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 16); if (k) { goto L_060443FC; } }  // 060443E8 bt/s 0x060443FC ; mov.l @(16,r14),r0
    c.r[3] = c.r[1];  // 060443EC mov r1,r3
    c.r[3] <<= 2;  // 060443EE shll2 r3
    c.r[0] = c.r[3];  // 060443F0 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 060443F2 mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060443F4 cmp/gt r2,r1
    if (!c.t) { goto L_060443FA; }  // 060443F6 bf 0x060443FA
    st32(c.r[0] + c.r[6], c.r[2]);  // 060443F8 mov.l r2,@(r0,r6)
L_060443FA:
    c.r[0] = ld32(c.r[14] + 16);  // 060443FA mov.l @(16,r14),r0
L_060443FC:
    c.r[1] = c.r[10];  // 060443FC mov r10,r1
    c.r[1] -= c.r[0];  // 060443FE sub r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06044400 cmp/pz r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] >= (int32_t)c.r[12]; if (k) { goto L_06044418; } }  // 06044402 bf/s 0x06044418 ; cmp/ge r12,r1
    { const bool k = c.t; c.r[2] = c.r[13]; if (k) { goto L_0604441A; } }  // 06044406 bt/s 0x0604441A ; mov r13,r2
    c.r[2] = c.r[1];  // 0604440A mov r1,r2
    c.r[2] <<= 2;  // 0604440C shll2 r2
    c.r[0] = c.r[2];  // 0604440E mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 06044410 mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 06044412 cmp/gt r11,r1
    if (!c.t) { goto L_06044418; }  // 06044414 bf 0x06044418
    st32(c.r[0] + c.r[6], c.r[11]);  // 06044416 mov.l r11,@(r0,r6)
L_06044418:
    c.r[2] = c.r[13];  // 06044418 mov r13,r2
L_0604441A:
    c.r[1] = c.r[10];  // 0604441A mov r10,r1
    c.r[1] += c.r[7];  // 0604441C add r7,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0604441E cmp/pz r1
    { const bool k = !c.t; c.r[2] -= c.r[8]; if (k) { goto L_06044436; } }  // 06044420 bf/s 0x06044436 ; sub r8,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[12];  // 06044424 cmp/ge r12,r1
    if (c.t) { goto L_06044436; }  // 06044426 bt 0x06044436
    c.r[3] = c.r[1];  // 06044428 mov r1,r3
    c.r[3] <<= 2;  // 0604442A shll2 r3
    c.r[0] = c.r[3];  // 0604442C mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0604442E mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06044430 cmp/gt r2,r1
    if (!c.t) { goto L_06044436; }  // 06044432 bf 0x06044436
    st32(c.r[0] + c.r[6], c.r[2]);  // 06044434 mov.l r2,@(r0,r6)
L_06044436:
    c.r[1] = ld32(c.r[14] + 24);  // 06044436 mov.l @(24,r14),r1
    c.r[1] += c.r[10];  // 06044438 add r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0604443A cmp/pz r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] >= (int32_t)c.r[12]; if (k) { goto L_06044452; } }  // 0604443C bf/s 0x06044452 ; cmp/ge r12,r1
    { const bool k = c.t; c.r[4] = c.r[10]; if (k) { goto L_06044454; } }  // 06044440 bt/s 0x06044454 ; mov r10,r4
    c.r[2] = c.r[1];  // 06044444 mov r1,r2
    c.r[2] <<= 2;  // 06044446 shll2 r2
    c.r[0] = c.r[2];  // 06044448 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0604444A mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 0604444C cmp/gt r11,r1
    if (!c.t) { goto L_06044454; }  // 0604444E bf 0x06044454
    st32(c.r[0] + c.r[6], c.r[11]);  // 06044450 mov.l r11,@(r0,r6)
L_06044452:
    c.r[4] = c.r[10];  // 06044452 mov r10,r4
L_06044454:
    c.r[0] = ld32(c.r[14] + 16);  // 06044454 mov.l @(16,r14),r0
    c.r[2] = c.r[13];  // 06044456 mov r13,r2
    c.r[4] -= c.r[0];  // 06044458 sub r0,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0604445A cmp/pz r4
    { const bool k = !c.t; c.r[2] += c.r[9]; if (k) { goto L_06044472; } }  // 0604445C bf/s 0x06044472 ; add r9,r2
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[12];  // 06044460 cmp/ge r12,r4
    if (c.t) { goto L_06044472; }  // 06044462 bt 0x06044472
    c.r[3] = c.r[4];  // 06044464 mov r4,r3
    c.r[3] <<= 2;  // 06044466 shll2 r3
    c.r[0] = c.r[3];  // 06044468 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0604446A mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604446C cmp/gt r2,r1
    if (!c.t) { goto L_06044472; }  // 0604446E bf 0x06044472
    st32(c.r[0] + c.r[6], c.r[2]);  // 06044470 mov.l r2,@(r0,r6)
L_06044472:
    c.r[4] = c.r[10];  // 06044472 mov r10,r4
    c.r[0] = ld32(c.r[14] + 20);  // 06044474 mov.l @(20,r14),r0
    c.r[2] = c.r[13];  // 06044476 mov r13,r2
    c.r[2] += c.r[8];  // 06044478 add r8,r2
    c.r[4] -= c.r[0];  // 0604447A sub r0,r4
    c.t = (int32_t)c.r[4] >= 0; goto L_06044494;  // 0604447C bra 0x06044494 ; cmp/pz r4
L_06044494:
    { const bool k = !c.t; c.t = (int32_t)c.r[4] >= (int32_t)c.r[12]; if (k) { goto L_060444A8; } }  // 06044494 bf/s 0x060444A8 ; cmp/ge r12,r4
    if (c.t) { goto L_060444A8; }  // 06044498 bt 0x060444A8
    c.r[3] = c.r[4];  // 0604449A mov r4,r3
    c.r[3] <<= 2;  // 0604449C shll2 r3
    c.r[0] = c.r[3];  // 0604449E mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 060444A0 mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060444A2 cmp/gt r2,r1
    if (!c.t) { goto L_060444A8; }  // 060444A4 bf 0x060444A8
    st32(c.r[0] + c.r[6], c.r[2]);  // 060444A6 mov.l r2,@(r0,r6)
L_060444A8:
    c.r[2] = c.r[13];  // 060444A8 mov r13,r2
    c.r[4] = c.r[10];  // 060444AA mov r10,r4
    c.r[4] += c.r[7];  // 060444AC add r7,r4
    c.t = (int32_t)c.r[4] >= 0;  // 060444AE cmp/pz r4
    { const bool k = !c.t; c.r[2] += c.r[8]; if (k) { goto L_060444C6; } }  // 060444B0 bf/s 0x060444C6 ; add r8,r2
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[12];  // 060444B4 cmp/ge r12,r4
    if (c.t) { goto L_060444C6; }  // 060444B6 bt 0x060444C6
    c.r[3] = c.r[4];  // 060444B8 mov r4,r3
    c.r[3] <<= 2;  // 060444BA shll2 r3
    c.r[0] = c.r[3];  // 060444BC mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 060444BE mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060444C0 cmp/gt r2,r1
    if (!c.t) { goto L_060444C6; }  // 060444C2 bf 0x060444C6
    st32(c.r[0] + c.r[6], c.r[2]);  // 060444C4 mov.l r2,@(r0,r6)
L_060444C6:
    c.r[2] = c.r[13];  // 060444C6 mov r13,r2
    c.r[4] = ld32(c.r[14] + 24);  // 060444C8 mov.l @(24,r14),r4
    c.r[4] += c.r[10];  // 060444CA add r10,r4
    c.t = (int32_t)c.r[4] >= 0;  // 060444CC cmp/pz r4
    { const bool k = !c.t; c.r[2] += c.r[9]; if (k) { goto L_060444E6; } }  // 060444CE bf/s 0x060444E6 ; add r9,r2
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[12];  // 060444D2 cmp/ge r12,r4
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_060444E8; } }  // 060444D4 bt/s 0x060444E8 ; mov.l @(28,r14),r0
    c.r[3] = c.r[4];  // 060444D8 mov r4,r3
    c.r[3] <<= 2;  // 060444DA shll2 r3
    c.r[0] = c.r[3];  // 060444DC mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 060444DE mov.l @(r0,r6),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060444E0 cmp/gt r2,r1
    if (!c.t) { goto L_060444E6; }  // 060444E2 bf 0x060444E6
    st32(c.r[0] + c.r[6], c.r[2]);  // 060444E4 mov.l r2,@(r0,r6)
L_060444E6:
    c.r[0] = ld32(c.r[14] + 28);  // 060444E6 mov.l @(28,r14),r0
L_060444E8:
    c.r[1] = c.r[9];  // 060444E8 mov r9,r1
    c.r[1] += c.r[1];  // 060444EA add r1,r1
    c.r[11] -= 1;  // 060444EC add #-1,r11
    c.r[9] += 1;  // 060444EE add #1,r9
    c.r[0] += 1;  // 060444F0 add #1,r0
    c.r[0] -= c.r[1];  // 060444F2 sub r1,r0
    c.t = (int32_t)c.r[0] >= 0;  // 060444F4 cmp/pz r0
    { const bool k = c.t; st32(c.r[14] + 28, c.r[0]); if (k) { goto L_06044508; } }  // 060444F6 bt/s 0x06044508 ; mov.l r0,@(28,r14)
    c.r[2] = c.r[8];  // 060444FA mov r8,r2
    c.r[2] -= 1;  // 060444FC add #-1,r2
    c.r[1] = c.r[2];  // 060444FE mov r2,r1
    c.r[1] += c.r[1];  // 06044500 add r1,r1
    c.r[0] += c.r[1];  // 06044502 add r1,r0
    st32(c.r[14] + 28, c.r[0]);  // 06044504 mov.l r0,@(28,r14)
    c.r[8] = c.r[2];  // 06044506 mov r2,r8
L_06044508:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06044508 cmp/ge r9,r8
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06044512; } }  // 0604450A bf/s 0x06044512 ; mov.l @(8,r14),r0
    SH2_POLL(c); goto L_060443A8;  // 0604450E bra 0x060443A8 ; nop
L_06044512:
    c.r[5] = ld32(0x0604455Cu);  // 06044512 mov.l 0x0604455C,r5
    c.r[7] = ld32(0x06044560u);  // 06044514 mov.l 0x06044560,r7
    c.r[3] = ld32(0x06044564u);  // 06044516 mov.l 0x06044564,r3
    c.r[2] = ld32(c.r[14]);  // 06044518 mov.l @r14,r2
    c.r[8] = 0x0u;  // 0604451A mov #0,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x06044558u);  // 0604451C mov.w 0x06044558,r6
L_0604451E:
    c.r[0] = c.r[8];  // 0604451E mov r8,r0
    c.r[4] = ld32(c.r[0] + c.r[5]);  // 06044520 mov.l @(r0,r5),r4
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06044522 mov.l @(r0,r7),r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 06044524 cmp/gt r1,r4
    if (c.t) { goto L_0604453A; }  // 06044526 bt 0x0604453A
    { const uint32_t x = c.r[3]; c.pr = 0x0604452Cu; c.r[0] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604452Cu) return; }  // 06044528 jsr @r3 ; mov.l @r14,r0
    c.r[1] = c.r[2];  // 0604452C mov r2,r1
    st16(c.r[0] + c.r[8], c.r[4]);  // 0604452E mov.w r4,@(r0,r8)
    c.r[0] = c.r[8];  // 06044530 mov r8,r0
    c.r[4] = ld32(c.r[0] + c.r[7]);  // 06044532 mov.l @(r0,r7),r4
    { const uint32_t x = c.r[3]; c.pr = 0x06044538u; c.r[1] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044538u) return; }  // 06044534 jsr @r3 ; add #2,r1
    st16(c.r[1], c.r[4]);  // 06044538 mov.w r4,@r1
L_0604453A:
    c.r[8] += 4;  // 0604453A add #4,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[6];  // 0604453C cmp/gt r6,r8
    { const bool k = !c.t; c.r[2] += 4; if (k) { SH2_POLL(c); goto L_0604451E; } }  // 0604453E bf/s 0x0604451E ; add #4,r2
L_06044542:
    c.r[14] += 32;  // 06044542 add #32,r14
    c.r[15] = c.r[14];  // 06044544 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06044546 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044548 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604454A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604454C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604454E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06044550 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06044552 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044554 rts ; mov.l @r15+,r8
}

void f_06044568(SH2Context& c) {
    ran[1105] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06044568 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604456A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604456C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604456E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06044570 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044572 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06044574 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06044576 mov r15,r14
    c.r[11] = c.r[4];  // 06044578 mov r4,r11
    c.r[12] = c.r[5];  // 0604457A mov r5,r12
    c.r[1] = ld32(0x06044674u);  // 0604457C mov.l 0x06044674,r1
    c.r[2] = 0x0u;  // 0604457E mov #0,r2
    st8(c.r[1], c.r[2]);  // 06044580 mov.b r2,@r1
    c.r[1] = ld32(0x06044678u);  // 06044582 mov.l 0x06044678,r1
    st8(c.r[1], c.r[2]);  // 06044584 mov.b r2,@r1
    c.r[5] = ld32(0x0604467Cu);  // 06044586 mov.l 0x0604467C,r5
    c.r[4] = ld32(0x06044680u);  // 06044588 mov.l 0x06044680,r4
    c.r[1] = ld32(0x06044684u);  // 0604458A mov.l 0x06044684,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044590u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044590u) return; }  // 0604458C jsr @r1 ; mov #0,r9
    c.r[4] = 0x0u;  // 06044590 mov #0,r4
    c.r[10] = ld32(0x06044688u);  // 06044592 mov.l 0x06044688,r10
    c.r[5] = 0x0u;  // 06044594 mov #0,r5
    c.r[3] = c.r[10];  // 06044596 mov r10,r3
L_06044598:
    c.r[0] = c.r[9];  // 06044598 mov r9,r0
    st16(c.r[0] + c.r[10], c.r[5]);  // 0604459A mov.w r5,@(r0,r10)
    c.r[1] = c.r[3];  // 0604459C mov r3,r1
    c.r[1] += 2;  // 0604459E add #2,r1
    st16(c.r[1], c.r[5]);  // 060445A0 mov.w r5,@r1
    c.r[1] = c.r[3];  // 060445A2 mov r3,r1
    c.r[1] += 4;  // 060445A4 add #4,r1
    st16(c.r[1], c.r[5]);  // 060445A6 mov.w r5,@r1
    c.r[2] = 0x1u;  // 060445A8 mov #1,r2
    c.r[2] &= c.r[4];  // 060445AA and r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060445AC tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_060445B4; } }  // 060445AE bf/s 0x060445B4 ; mov r12,r1
    c.r[1] = c.r[11];  // 060445B2 mov r11,r1
L_060445B4:
    st32(c.r[3] + 20, c.r[1]);  // 060445B4 mov.l r1,@(20,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604466Au);  // 060445B6 mov.w 0x0604466A,r1
    c.macl = c.r[2] * c.r[1];  // 060445B8 mul.l r1,r2
    c.r[2] = c.macl;  // 060445BA sts macl,r2
    c.r[1] = ld32(0x0604468Cu);  // 060445BC mov.l 0x0604468C,r1
    c.r[2] += c.r[1];  // 060445BE add r1,r2
    { const bool k = c.t; st32(c.r[3] + 16, c.r[2]); if (k) { goto L_060445CA; } }  // 060445C0 bt/s 0x060445CA ; mov.l r2,@(16,r3)
    c.r[1] = ld32(0x06044690u);  // 060445C4 mov.l 0x06044690,r1
    st32(c.r[3] + 8, c.r[1]); goto L_060445CE;  // 060445C6 bra 0x060445CE ; mov.l r1,@(8,r3)
L_060445CA:
    c.r[1] = ld32(0x06044680u);  // 060445CA mov.l 0x06044680,r1
    st32(c.r[3] + 8, c.r[1]);  // 060445CC mov.l r1,@(8,r3)
L_060445CE:
    c.r[1] = 0x1u;  // 060445CE mov #1,r1
    c.r[1] &= c.r[4];  // 060445D0 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060445D2 tst r1,r1
    if (c.t) { goto L_060445DC; }  // 060445D4 bt 0x060445DC
    c.r[1] = ld32(0x06044694u);  // 060445D6 mov.l 0x06044694,r1
    st32(c.r[3] + 12, c.r[1]); goto L_060445E0;  // 060445D8 bra 0x060445E0 ; mov.l r1,@(12,r3)
L_060445DC:
    c.r[1] = ld32(0x06044698u);  // 060445DC mov.l 0x06044698,r1
    st32(c.r[3] + 12, c.r[1]);  // 060445DE mov.l r1,@(12,r3)
L_060445E0:
    c.r[7] = 0x0u;  // 060445E0 mov #0,r7
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604466Cu);  // 060445E2 mov.w 0x0604466C,r8
    c.r[6] = 0x0u;  // 060445E4 mov #0,r6
L_060445E6:
    c.r[1] = c.r[7];  // 060445E6 mov r7,r1
    c.r[0] = ld32(c.r[3] + 16);  // 060445E8 mov.l @(16,r3),r0
    c.r[1] <<= 16;  // 060445EA shll16 r1
    st32(c.r[0] + c.r[6], c.r[5]);  // 060445EC mov.l r5,@(r0,r6)
    c.r[0] = c.r[7];  // 060445EE mov r7,r0
    c.r[0] <<= 2;  // 060445F0 shll2 r0
    c.r[2] = ld32(c.r[3] + 16);  // 060445F2 mov.l @(16,r3),r2
    c.r[7] += 1;  // 060445F4 add #1,r7
    c.r[2] += c.r[6];  // 060445F6 add r6,r2
    st32(c.r[2] + 4, c.r[1]);  // 060445F8 mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[3] + 8);  // 060445FA mov.l @(8,r3),r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[8];  // 060445FC cmp/gt r8,r7
    st32(c.r[0] + c.r[1], c.r[5]);  // 060445FE mov.l r5,@(r0,r1)
    c.r[1] = ld32(c.r[3] + 12);  // 06044600 mov.l @(12,r3),r1
    c.r[6] += 8;  // 06044602 add #8,r6
    { const bool k = !c.t; st32(c.r[0] + c.r[1], c.r[5]); if (k) { SH2_POLL(c); goto L_060445E6; } }  // 06044604 bf/s 0x060445E6 ; mov.l r5,@(r0,r1)
    st32(c.r[3] + 28, c.r[5]);  // 06044608 mov.l r5,@(28,r3)
    st32(c.r[3] + 32, c.r[5]);  // 0604460A mov.l r5,@(32,r3)
    st32(c.r[3] + 36, c.r[5]);  // 0604460C mov.l r5,@(36,r3)
    st32(c.r[3] + 40, c.r[5]);  // 0604460E mov.l r5,@(40,r3)
    st32(c.r[3] + 44, c.r[5]);  // 06044610 mov.l r5,@(44,r3)
    st32(c.r[3] + 48, c.r[5]);  // 06044612 mov.l r5,@(48,r3)
    st32(c.r[3] + 52, c.r[5]);  // 06044614 mov.l r5,@(52,r3)
    st32(c.r[3] + 56, c.r[5]);  // 06044616 mov.l r5,@(56,r3)
    st32(c.r[3] + 24, c.r[5]);  // 06044618 mov.l r5,@(24,r3)
    c.r[3] += 60;  // 0604461A add #60,r3
    c.r[4] += 1;  // 0604461C add #1,r4
    c.r[1] = 0x3u;  // 0604461E mov #3,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 06044620 cmp/gt r1,r4
    { const bool k = !c.t; c.r[9] += 60; if (k) { SH2_POLL(c); goto L_06044598; } }  // 06044622 bf/s 0x06044598 ; add #60,r9
    c.r[8] = ld32(0x06044688u);  // 06044626 mov.l 0x06044688,r8
    st32(c.r[8] + 20, c.r[11]);  // 06044628 mov.l r11,@(20,r8)
    c.r[10] = c.r[8];  // 0604462A mov r8,r10
    c.r[10] += 80;  // 0604462C add #80,r10
    st32(c.r[10], c.r[12]);  // 0604462E mov.l r12,@r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604466Eu);  // 06044630 mov.w 0x0604466E,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044670u);  // 06044632 mov.w 0x06044670,r1
    c.r[11] += c.r[1];  // 06044634 add r1,r11
    st32(c.r[0] + c.r[8], c.r[11]);  // 06044636 mov.l r11,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06044672u);  // 06044638 mov.w 0x06044672,r0
    c.r[12] += c.r[1];  // 0604463A add r1,r12
    st32(c.r[0] + c.r[8], c.r[12]);  // 0604463C mov.l r12,@(r0,r8)
    c.r[9] = ld32(0x0604469Cu);  // 0604463E mov.l 0x0604469C,r9
    c.r[5] = 0x6u;  // 06044640 mov #6,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06044646u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044646u) return; }  // 06044642 jsr @r9 ; mov #1,r4
    c.r[1] = ld32(0x060446A0u);  // 06044646 mov.l 0x060446A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604464Cu; c.r[4] = ld32(c.r[8] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604464Cu) return; }  // 06044648 jsr @r1 ; mov.l @(20,r8),r4
    c.r[5] = 0x6u;  // 0604464C mov #6,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06044652u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044652u) return; }  // 0604464E jsr @r9 ; mov #0,r4
    c.r[1] = ld32(0x060446A4u);  // 06044652 mov.l 0x060446A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044658u; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044658u) return; }  // 06044654 jsr @r1 ; mov.l @r10,r4
    c.r[15] = c.r[14];  // 06044658 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604465A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604465C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604465E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06044660 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06044662 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06044664 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044666 rts ; mov.l @r15+,r8
}

void f_060446A8(SH2Context& c) {
    ran[1106] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060446A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060446AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060446AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060446AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060446B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060446B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060446B4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060446B6 mov r15,r14
    c.r[1] = ld32(0x06044794u);  // 060446B8 mov.l 0x06044794,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060446BA mov.b @r1,r0
    c.r[12] = 0x0u;  // 060446BC mov #0,r12
    c.r[10] = ld32(0x06044798u);  // 060446BE mov.l 0x06044798,r10
    c.r[11] = 0x3Cu;  // 060446C0 mov #60,r11
    c.r[0] ^= 0x2u;  // 060446C2 xor #2,r0
    c.r[9] = c.r[0] & 0xFFu;  // 060446C4 extu.b r0,r9
L_060446C6:
    c.macl = c.r[9] * c.r[11];  // 060446C6 mul.l r11,r9
    c.r[0] = c.r[10];  // 060446C8 mov r10,r0
    c.r[8] = c.macl;  // 060446CA sts macl,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 060446CC mov.w @(r0,r8),r1
    c.r[0] = 0x1u;  // 060446CE mov #1,r0
    c.r[1] &= c.r[0];  // 060446D0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060446D2 tst r1,r1
    { const bool k = c.t; c.r[0] = c.macl; if (k) { goto L_06044712; } }  // 060446D4 bt/s 0x06044712 ; sts macl,r0
    c.r[1] = ld32(0x0604479Cu);  // 060446D8 mov.l 0x0604479C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060446DA mov.w @r1,r0
    c.r[0] &= 0x1u;  // 060446DC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060446DE tst r0,r0
    if (c.t) { goto L_060446E8; }  // 060446E0 bt 0x060446E8
    c.r[1] = ld32(0x060447A0u);  // 060446E2 mov.l 0x060447A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060446E8u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060446E8u) return; }  // 060446E4 jsr @r1 ; extu.b r9,r4
L_060446E8:
    c.r[8] += c.r[10];  // 060446E8 add r10,r8
    c.r[3] = 0x0u;  // 060446EA mov #0,r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x06044792u);  // 060446EC mov.w 0x06044792,r5
    c.r[6] = c.r[9];  // 060446EE mov r9,r6
    c.r[7] = ld32(c.r[8] + 16);  // 060446F0 mov.l @(16,r8),r7
L_060446F2:
    c.r[0] = c.r[3];  // 060446F2 mov r3,r0
    c.macl = c.r[6] * c.r[11];  // 060446F4 mul.l r11,r6
    c.r[0] <<= 2;  // 060446F6 shll2 r0
    c.r[2] = ld32(c.r[7]);  // 060446F8 mov.l @r7,r2
    c.r[1] = c.macl;  // 060446FA sts macl,r1
    c.r[1] += c.r[10];  // 060446FC add r10,r1
    c.r[1] = ld32(c.r[1] + 8);  // 060446FE mov.l @(8,r1),r1
    c.r[3] += 1;  // 06044700 add #1,r3
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06044702 mov.l @(r0,r1),r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[5];  // 06044704 cmp/gt r5,r3
    c.r[2] += c.r[1];  // 06044706 add r1,r2
    st32(c.r[7], c.r[2]);  // 06044708 mov.l r2,@r7
    { const bool k = !c.t; c.r[7] += 8; if (k) { SH2_POLL(c); goto L_060446F2; } }  // 0604470A bf/s 0x060446F2 ; add #8,r7
    c.macl = c.r[9] * c.r[11];  // 0604470E mul.l r11,r9
    c.r[0] = c.macl;  // 06044710 sts macl,r0
L_06044712:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06044712 mov.w @(r0,r10),r0
    c.r[0] &= 0x2u;  // 06044714 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044716 tst r0,r0
    { const bool k = c.t; c.r[1] = c.macl; if (k) { goto L_06044744; } }  // 06044718 bt/s 0x06044744 ; sts macl,r1
    c.r[1] += c.r[10];  // 0604471C add r10,r1
    c.r[3] = 0x0u;  // 0604471E mov #0,r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x06044792u);  // 06044720 mov.w 0x06044792,r5
    c.r[6] = c.r[9];  // 06044722 mov r9,r6
    c.r[7] = ld32(c.r[1] + 16);  // 06044724 mov.l @(16,r1),r7
L_06044726:
    c.r[2] = c.r[3];  // 06044726 mov r3,r2
    c.r[2] <<= 16;  // 06044728 shll16 r2
    c.macl = c.r[6] * c.r[11];  // 0604472A mul.l r11,r6
    c.r[0] = c.r[3];  // 0604472C mov r3,r0
    c.r[0] <<= 2;  // 0604472E shll2 r0
    c.r[1] = c.macl;  // 06044730 sts macl,r1
    c.r[1] += c.r[10];  // 06044732 add r10,r1
    c.r[1] = ld32(c.r[1] + 12);  // 06044734 mov.l @(12,r1),r1
    c.r[3] += 1;  // 06044736 add #1,r3
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06044738 mov.l @(r0,r1),r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[5];  // 0604473A cmp/gt r5,r3
    c.r[2] += c.r[1];  // 0604473C add r1,r2
    st32(c.r[7] + 4, c.r[2]);  // 0604473E mov.l r2,@(4,r7)
    { const bool k = !c.t; c.r[7] += 8; if (k) { SH2_POLL(c); goto L_06044726; } }  // 06044740 bf/s 0x06044726 ; add #8,r7
L_06044744:
    c.r[12] += 1;  // 06044744 add #1,r12
    c.r[1] = 0x1u;  // 06044746 mov #1,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06044748 cmp/gt r1,r12
    { const bool k = !c.t; c.r[9] += 1; if (k) { SH2_POLL(c); goto L_060446C6; } }  // 0604474A bf/s 0x060446C6 ; add #1,r9
    c.r[8] = ld32(0x06044794u);  // 0604474E mov.l 0x06044794,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06044750 mov.b @r8,r1
    c.r[9] = 0x3Cu;  // 06044752 mov #60,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06044754 extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 06044756 mul.l r9,r1
    c.r[10] = ld32(0x06044798u);  // 06044758 mov.l 0x06044798,r10
    c.r[1] = c.macl;  // 0604475A sts macl,r1
    c.r[1] += c.r[10];  // 0604475C add r10,r1
    c.r[4] = ld32(c.r[1] + 20);  // 0604475E mov.l @(20,r1),r4
    c.r[1] = ld32(0x060447A4u);  // 06044760 mov.l 0x060447A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044766u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044766u) return; }  // 06044762 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06044766 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06044768 extu.b r1,r1
    c.r[1] += 1;  // 0604476A add #1,r1
    c.macl = c.r[1] * c.r[9];  // 0604476C mul.l r9,r1
    c.r[1] = c.macl;  // 0604476E sts macl,r1
    c.r[1] += c.r[10];  // 06044770 add r10,r1
    c.r[4] = ld32(c.r[1] + 20);  // 06044772 mov.l @(20,r1),r4
    c.r[1] = ld32(0x060447A8u);  // 06044774 mov.l 0x060447A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604477Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604477Au) return; }  // 06044776 jsr @r1 ; nop
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604477A mov.b @r8,r0
    c.r[15] = c.r[14];  // 0604477C mov r14,r15
    c.r[0] ^= 0x2u;  // 0604477E xor #2,r0
    st8(c.r[8], c.r[0]);  // 06044780 mov.b r0,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06044782 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044784 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06044786 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06044788 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604478A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604478C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604478E rts ; mov.l @r15+,r8
}

void f_060447AC(SH2Context& c) {
    ran[1107] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060447AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060447AE mov.l r14,@-r15
    c.r[0] = c.r[4] & 0xFFu;  // 060447B0 extu.b r4,r0
    c.r[3] = c.r[0];  // 060447B2 mov r0,r3
    c.r[0] &= 0x1u;  // 060447B4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060447B6 tst r0,r0
    c.r[6] = ld32(0x06044804u);  // 060447B8 mov.l 0x06044804,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060447C0; } }  // 060447BA bt/s 0x060447C0 ; mov r15,r14
    c.r[6] = ld32(0x06044808u);  // 060447BE mov.l 0x06044808,r6
L_060447C0:
    c.r[1] = 0x3Cu;  // 060447C0 mov #60,r1
    c.macl = c.r[3] * c.r[1];  // 060447C2 mul.l r1,r3
    c.r[2] = ld32(0x0604480Cu);  // 060447C4 mov.l 0x0604480C,r2
    c.r[4] = 0x7Fu;  // 060447C6 mov #127,r4
    c.r[3] = c.macl;  // 060447C8 sts macl,r3
    c.r[3] += c.r[2];  // 060447CA add r2,r3
    c.r[1] = c.r[3];  // 060447CC mov r3,r1
    c.r[1] += 2;  // 060447CE add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060447D0 mov.w @r1,r1
    c.r[2] = 0x0u;  // 060447D2 mov #0,r2
    c.r[5] = ld32(c.r[3] + 16);  // 060447D4 mov.l @(16,r3),r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 060447D6 extu.w r1,r1
    c.r[1] <<= 2;  // 060447D8 shll2 r1
    c.r[1] += c.r[1];  // 060447DA add r1,r1
    c.r[5] += c.r[1];  // 060447DC add r1,r5
    c.r[1] = ld32(0x06044810u);  // 060447DE mov.l 0x06044810,r1
    c.r[3] = 0x0u;  // 060447E0 mov #0,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060447E2 mov.b @r1,r7
L_060447E4:
    c.r[8] = c.r[2];  // 060447E4 mov r2,r8
    c.r[8] += c.r[7];  // 060447E6 add r7,r8
    c.r[8] <<= 2;  // 060447E8 shll2 r8
    c.r[8] += c.r[8];  // 060447EA add r8,r8
    c.r[0] = c.r[3];  // 060447EC mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 060447EE mov.l @(r0,r6),r1
    c.r[3] += 4;  // 060447F0 add #4,r3
    c.r[2] += 1;  // 060447F2 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[4];  // 060447F4 cmp/gt r4,r2
    c.r[0] = c.r[8];  // 060447F6 mov r8,r0
    { const bool k = !c.t; st32(c.r[0] + c.r[5], c.r[1]); if (k) { SH2_POLL(c); goto L_060447E4; } }  // 060447F8 bf/s 0x060447E4 ; mov.l r1,@(r0,r5)
    c.r[15] = c.r[14];  // 060447FC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060447FE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044800 rts ; mov.l @r15+,r8
}

void f_06044814(SH2Context& c) {
    ran[1108] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06044814 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06044816 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06044818 mov.l r10,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0604481A extu.b r4,r4
    c.r[1] = 0x3Cu;  // 0604481C mov #60,r1
    c.macl = c.r[4] * c.r[1];  // 0604481E mul.l r1,r4
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044820 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06044822 mov r15,r14
    c.r[3] = c.macl;  // 06044824 sts macl,r3
    c.r[1] = ld32(0x060448E4u);  // 06044826 mov.l 0x060448E4,r1
    c.r[3] += c.r[1];  // 06044828 add r1,r3
    c.r[0] = ld32(c.r[3] + 24);  // 0604482A mov.l @(24,r3),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604482C tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06044834; } }  // 0604482E bf/s 0x06044834 ; mov #0,r1
    c.r[1] = 0x20u;  // 06044832 mov #32,r1
L_06044834:
    c.r[4] = 0x0u;  // 06044834 mov #0,r4
    c.r[0] &= 0x1u;  // 06044836 and #1,r0
    c.r[0] += 1;  // 06044838 add #1,r0
    c.r[0] <<= 2;  // 0604483A shll2 r0
    c.r[0] <<= 2;  // 0604483C shll2 r0
    c.r[0] += c.r[0];  // 0604483E add r0,r0
    c.r[0] <<= 2;  // 06044840 shll2 r0
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 06044842 cmp/ge r0,r4
    { const bool k = c.t; c.r[5] = ld32(c.r[3] + 40); if (k) { goto L_060448CA; } }  // 06044844 bt/s 0x060448CA ; mov.l @(40,r3),r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x060448DEu);  // 06044848 mov.w 0x060448DE,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x060448E0u);  // 0604484A mov.w 0x060448E0,r8
    c.r[6] = c.r[1];  // 0604484C mov r1,r6
L_0604484E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060448E2u);  // 0604484E mov.w 0x060448E2,r0
    c.r[0] &= c.r[5];  // 06044850 and r5,r0
    c.t = c.r[0] == c.r[9];  // 06044852 cmp/eq r9,r0
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_06044874; } }  // 06044854 bf/s 0x06044874 ; mov r5,r1
    c.r[1] &= c.r[8];  // 06044858 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604485A tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_0604486A; } }  // 0604485C bt/s 0x0604486A ; mov r6,r0
    c.r[1] = ld32(c.r[3] + 32);  // 06044860 mov.l @(32,r3),r1
    c.r[0] <<= 2;  // 06044862 shll2 r0
    c.r[2] = ld32(c.r[3] + 8);  // 06044864 mov.l @(8,r3),r2
    c.r[1] <<= 16; goto L_060448AE;  // 06044866 bra 0x060448AE ; shll16 r1
L_0604486A:
    c.r[1] = ld32(c.r[3] + 32);  // 0604486A mov.l @(32,r3),r1
    c.r[0] <<= 2;  // 0604486C shll2 r0
    c.r[2] = ld32(c.r[3] + 8);  // 0604486E mov.l @(8,r3),r2
    c.r[1] <<= 16; goto L_060448AC;  // 06044870 bra 0x060448AC ; shll16 r1
L_06044874:
    c.r[1] = c.r[0];  // 06044874 mov r0,r1
    c.r[1] &= c.r[9];  // 06044876 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044878 tst r1,r1
    if (c.t) { goto L_06044880; }  // 0604487A bt 0x06044880
    c.r[0] ^= 0xFFu;  // 0604487C xor #255,r0
    c.r[0] += 1;  // 0604487E add #1,r0
L_06044880:
    c.r[0] = c.r[0] & 0xFFu;  // 06044880 extu.b r0,r0
    c.r[0] += c.r[0];  // 06044882 add r0,r0
    c.r[1] = ld32(0x060448E8u);  // 06044884 mov.l 0x060448E8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06044886 mov.w @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 06044888 extu.w r1,r7
    c.r[1] = c.r[5];  // 0604488A mov r5,r1
    c.r[1] &= c.r[8];  // 0604488C and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604488E tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060448A2; } }  // 06044890 bt/s 0x060448A2 ; mov r6,r0
    c.r[1] = ld32(c.r[3] + 32);  // 06044894 mov.l @(32,r3),r1
    c.macl = c.r[7] * c.r[1];  // 06044896 mul.l r1,r7
    c.r[2] = ld32(c.r[3] + 8);  // 06044898 mov.l @(8,r3),r2
    c.r[0] <<= 2;  // 0604489A shll2 r0
    c.r[10] = c.macl;  // 0604489C sts macl,r10
    st32(c.r[0] + c.r[2], c.r[10]); goto L_060448B0;  // 0604489E bra 0x060448B0 ; mov.l r10,@(r0,r2)
L_060448A2:
    c.r[1] = ld32(c.r[3] + 32);  // 060448A2 mov.l @(32,r3),r1
    c.macl = c.r[7] * c.r[1];  // 060448A4 mul.l r1,r7
    c.r[0] <<= 2;  // 060448A6 shll2 r0
    c.r[2] = ld32(c.r[3] + 8);  // 060448A8 mov.l @(8,r3),r2
    c.r[1] = c.macl;  // 060448AA sts macl,r1
L_060448AC:
    c.r[1] = 0u - c.r[1];  // 060448AC neg r1,r1
L_060448AE:
    st32(c.r[0] + c.r[2], c.r[1]);  // 060448AE mov.l r1,@(r0,r2)
L_060448B0:
    c.r[6] += 1;  // 060448B0 add #1,r6
    c.r[1] = ld32(c.r[3] + 28);  // 060448B2 mov.l @(28,r3),r1
    c.r[4] += 1;  // 060448B4 add #1,r4
    c.r[0] = ld32(c.r[3] + 24);  // 060448B6 mov.l @(24,r3),r0
    c.r[0] &= 0x1u;  // 060448B8 and #1,r0
    c.r[0] += 1;  // 060448BA add #1,r0
    c.r[0] <<= 2;  // 060448BC shll2 r0
    c.r[0] <<= 2;  // 060448BE shll2 r0
    c.r[0] += c.r[0];  // 060448C0 add r0,r0
    c.r[0] <<= 2;  // 060448C2 shll2 r0
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060448C4 cmp/ge r0,r4
    { const bool k = !c.t; c.r[5] += c.r[1]; if (k) { SH2_POLL(c); goto L_0604484E; } }  // 060448C6 bf/s 0x0604484E ; add r1,r5
L_060448CA:
    c.r[2] = ld32(c.r[3] + 40);  // 060448CA mov.l @(40,r3),r2
    c.r[1] = ld32(c.r[3] + 36);  // 060448CC mov.l @(36,r3),r1
    c.r[15] = c.r[14];  // 060448CE mov r14,r15
    c.r[2] += c.r[1];  // 060448D0 add r1,r2
    st32(c.r[3] + 40, c.r[2]);  // 060448D2 mov.l r2,@(40,r3)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060448D4 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060448D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060448D8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060448DA rts ; mov.l @r15+,r8
}

void f_060448EC(SH2Context& c) {
    ran[1109] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060448EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060448EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060448F0 mov.l r10,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 060448F2 extu.b r4,r4
    c.r[1] = 0x3Cu;  // 060448F4 mov #60,r1
    c.macl = c.r[4] * c.r[1];  // 060448F6 mul.l r1,r4
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060448F8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060448FA mov r15,r14
    c.r[3] = c.macl;  // 060448FC sts macl,r3
    c.r[1] = ld32(0x060449BCu);  // 060448FE mov.l 0x060449BC,r1
    c.r[3] += c.r[1];  // 06044900 add r1,r3
    c.r[0] = ld32(c.r[3] + 24);  // 06044902 mov.l @(24,r3),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044904 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0604490C; } }  // 06044906 bf/s 0x0604490C ; mov #0,r1
    c.r[1] = 0x20u;  // 0604490A mov #32,r1
L_0604490C:
    c.r[4] = 0x0u;  // 0604490C mov #0,r4
    c.r[0] &= 0x1u;  // 0604490E and #1,r0
    c.r[0] += 1;  // 06044910 add #1,r0
    c.r[0] <<= 2;  // 06044912 shll2 r0
    c.r[0] <<= 2;  // 06044914 shll2 r0
    c.r[0] += c.r[0];  // 06044916 add r0,r0
    c.r[0] <<= 2;  // 06044918 shll2 r0
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 0604491A cmp/ge r0,r4
    { const bool k = c.t; c.r[5] = ld32(c.r[3] + 56); if (k) { goto L_060449A2; } }  // 0604491C bt/s 0x060449A2 ; mov.l @(56,r3),r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x060449B6u);  // 06044920 mov.w 0x060449B6,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x060449B8u);  // 06044922 mov.w 0x060449B8,r8
    c.r[6] = c.r[1];  // 06044924 mov r1,r6
L_06044926:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060449BAu);  // 06044926 mov.w 0x060449BA,r0
    c.r[0] &= c.r[5];  // 06044928 and r5,r0
    c.t = c.r[0] == c.r[9];  // 0604492A cmp/eq r9,r0
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_0604494C; } }  // 0604492C bf/s 0x0604494C ; mov r5,r1
    c.r[1] &= c.r[8];  // 06044930 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044932 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06044942; } }  // 06044934 bt/s 0x06044942 ; mov r6,r0
    c.r[1] = ld32(c.r[3] + 48);  // 06044938 mov.l @(48,r3),r1
    c.r[0] <<= 2;  // 0604493A shll2 r0
    c.r[2] = ld32(c.r[3] + 12);  // 0604493C mov.l @(12,r3),r2
    c.r[1] <<= 16; goto L_06044986;  // 0604493E bra 0x06044986 ; shll16 r1
L_06044942:
    c.r[1] = ld32(c.r[3] + 48);  // 06044942 mov.l @(48,r3),r1
    c.r[0] <<= 2;  // 06044944 shll2 r0
    c.r[2] = ld32(c.r[3] + 12);  // 06044946 mov.l @(12,r3),r2
    c.r[1] <<= 16; goto L_06044984;  // 06044948 bra 0x06044984 ; shll16 r1
L_0604494C:
    c.r[1] = c.r[0];  // 0604494C mov r0,r1
    c.r[1] &= c.r[9];  // 0604494E and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044950 tst r1,r1
    if (c.t) { goto L_06044958; }  // 06044952 bt 0x06044958
    c.r[0] ^= 0xFFu;  // 06044954 xor #255,r0
    c.r[0] += 1;  // 06044956 add #1,r0
L_06044958:
    c.r[0] = c.r[0] & 0xFFu;  // 06044958 extu.b r0,r0
    c.r[0] += c.r[0];  // 0604495A add r0,r0
    c.r[1] = ld32(0x060449C0u);  // 0604495C mov.l 0x060449C0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604495E mov.w @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 06044960 extu.w r1,r7
    c.r[1] = c.r[5];  // 06044962 mov r5,r1
    c.r[1] &= c.r[8];  // 06044964 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044966 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_0604497A; } }  // 06044968 bt/s 0x0604497A ; mov r6,r0
    c.r[1] = ld32(c.r[3] + 48);  // 0604496C mov.l @(48,r3),r1
    c.macl = c.r[7] * c.r[1];  // 0604496E mul.l r1,r7
    c.r[2] = ld32(c.r[3] + 12);  // 06044970 mov.l @(12,r3),r2
    c.r[0] <<= 2;  // 06044972 shll2 r0
    c.r[10] = c.macl;  // 06044974 sts macl,r10
    st32(c.r[0] + c.r[2], c.r[10]); goto L_06044988;  // 06044976 bra 0x06044988 ; mov.l r10,@(r0,r2)
L_0604497A:
    c.r[1] = ld32(c.r[3] + 48);  // 0604497A mov.l @(48,r3),r1
    c.macl = c.r[7] * c.r[1];  // 0604497C mul.l r1,r7
    c.r[0] <<= 2;  // 0604497E shll2 r0
    c.r[2] = ld32(c.r[3] + 12);  // 06044980 mov.l @(12,r3),r2
    c.r[1] = c.macl;  // 06044982 sts macl,r1
L_06044984:
    c.r[1] = 0u - c.r[1];  // 06044984 neg r1,r1
L_06044986:
    st32(c.r[0] + c.r[2], c.r[1]);  // 06044986 mov.l r1,@(r0,r2)
L_06044988:
    c.r[6] += 1;  // 06044988 add #1,r6
    c.r[1] = ld32(c.r[3] + 44);  // 0604498A mov.l @(44,r3),r1
    c.r[4] += 1;  // 0604498C add #1,r4
    c.r[0] = ld32(c.r[3] + 24);  // 0604498E mov.l @(24,r3),r0
    c.r[0] &= 0x1u;  // 06044990 and #1,r0
    c.r[0] += 1;  // 06044992 add #1,r0
    c.r[0] <<= 2;  // 06044994 shll2 r0
    c.r[0] <<= 2;  // 06044996 shll2 r0
    c.r[0] += c.r[0];  // 06044998 add r0,r0
    c.r[0] <<= 2;  // 0604499A shll2 r0
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 0604499C cmp/ge r0,r4
    { const bool k = !c.t; c.r[5] += c.r[1]; if (k) { SH2_POLL(c); goto L_06044926; } }  // 0604499E bf/s 0x06044926 ; add r1,r5
L_060449A2:
    c.r[2] = ld32(c.r[3] + 56);  // 060449A2 mov.l @(56,r3),r2
    c.r[1] = ld32(c.r[3] + 52);  // 060449A4 mov.l @(52,r3),r1
    c.r[15] = c.r[14];  // 060449A6 mov r14,r15
    c.r[2] += c.r[1];  // 060449A8 add r1,r2
    st32(c.r[3] + 56, c.r[2]);  // 060449AA mov.l r2,@(56,r3)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060449AC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060449AE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060449B0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060449B2 rts ; mov.l @r15+,r8
}

void f_060449C4(SH2Context& c) {
    ran[1110] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060449C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060449C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060449C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060449CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060449CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060449CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060449D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060449D2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060449D4 mov r15,r14
    c.r[1] = ld32(0x06044A24u);  // 060449D6 mov.l 0x06044A24,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060449D8 mov.b @r1,r0
    c.r[8] = 0x0u;  // 060449DA mov #0,r8
    c.r[10] = ld32(0x06044A28u);  // 060449DC mov.l 0x06044A28,r10
    c.r[13] = ld32(0x06044A2Cu);  // 060449DE mov.l 0x06044A2C,r13
    c.r[12] = ld32(0x06044A30u);  // 060449E0 mov.l 0x06044A30,r12
    c.r[9] = 0x1u;  // 060449E2 mov #1,r9
    c.r[0] ^= 0x2u;  // 060449E4 xor #2,r0
    c.r[11] = c.r[0] & 0xFFu;  // 060449E6 extu.b r0,r11
L_060449E8:
    c.r[2] = c.r[11];  // 060449E8 mov r11,r2
    c.r[2] += c.r[8];  // 060449EA add r8,r2
    c.r[1] = 0x3Cu;  // 060449EC mov #60,r1
    c.macl = c.r[2] * c.r[1];  // 060449EE mul.l r1,r2
    st8(c.r[10], c.r[9]);  // 060449F0 mov.b r9,@r10
    c.r[1] = c.macl;  // 060449F2 sts macl,r1
    c.r[1] += c.r[13];  // 060449F4 add r13,r1
    c.r[5] = ld32(c.r[1] + 20);  // 060449F6 mov.l @(20,r1),r5
    c.r[7] = 0xEu;  // 060449F8 mov #14,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06044A22u);  // 060449FA mov.w 0x06044A22,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06044A00u; c.r[4] = ld32(c.r[1] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044A00u) return; }  // 060449FC jsr @r12 ; mov.l @(16,r1),r4
    c.r[1] = ld32(0x06044A34u);  // 06044A00 mov.l 0x06044A34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044A06u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044A06u) return; }  // 06044A02 jsr @r1 ; add #1,r8
    c.r[1] = 0x0u;  // 06044A06 mov #0,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06044A08 cmp/gt r9,r8
    { const bool k = !c.t; st8(c.r[10], c.r[1]); if (k) { SH2_POLL(c); goto L_060449E8; } }  // 06044A0A bf/s 0x060449E8 ; mov.b r1,@r10
    c.r[15] = c.r[14];  // 06044A0E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06044A10 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044A12 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06044A14 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06044A16 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06044A18 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06044A1A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06044A1C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044A1E rts ; mov.l @r15+,r8
}

void f_06044A38(SH2Context& c) {
    ran[1111] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044A38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06044A3A sts.l pr,@-r15
    c.r[1] = ld32(0x06044A90u);  // 06044A3C mov.l 0x06044A90,r1
    c.r[1] = ld32(c.r[1]);  // 06044A3E mov.l @r1,r1
    c.r[14] = c.r[15];  // 06044A40 mov r15,r14
    c.r[1] += 1;  // 06044A42 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044A44 mov.b @r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x06044A8Eu);  // 06044A46 mov.w 0x06044A8E,r5
    c.r[5] &= c.r[0];  // 06044A48 and r0,r5
    c.r[1] = 0x7Fu;  // 06044A4A mov #127,r1
    c.r[1] &= c.r[0];  // 06044A4C and r0,r1
    c.r[0] = ld32(0x06044A94u);  // 06044A4E mov.l 0x06044A94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06044A54u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044A54u) return; }  // 06044A50 jsr @r0 ; mov r1,r4
    c.r[1] = 0x3u;  // 06044A54 mov #3,r1
    c.t = c.r[0] > c.r[1];  // 06044A56 cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06044A84; } }  // 06044A58 bt/s 0x06044A84 ; mov r0,r1
    c.r[1] += c.r[1];  // 06044A5C add r1,r1
    c.r[0] = 0x06044A68u;  // 06044A5E mova 0x06044A68,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06044A60 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06044A62 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06044A84u: goto L_06044A84; case 0x06044A70u: goto L_06044A70; case 0x06044A7Eu: goto L_06044A7E; default: sh2_call(c, x); return; } }  // 06044A64 jmp @r0 ; nop
L_06044A70:
    c.r[1] = ld32(0x06044A98u);  // 06044A70 mov.l 0x06044A98,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044A72 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06044A74 or #128,r0
    st8(c.r[1], c.r[0]);  // 06044A76 mov.b r0,@r1
    c.r[0] = ld32(0x06044A9Cu);  // 06044A78 mov.l 0x06044A9C,r0
    c.r[15] = c.r[14]; goto L_06044A88;  // 06044A7A bra 0x06044A88 ; mov r14,r15
L_06044A7E:
    c.r[1] = ld32(0x06044AA0u);  // 06044A7E mov.l 0x06044AA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044A84u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044A84u) return; }  // 06044A80 jsr @r1 ; mov #1,r4
L_06044A84:
    c.r[0] = ld32(0x06044AA4u);  // 06044A84 mov.l 0x06044AA4,r0
    c.r[15] = c.r[14];  // 06044A86 mov r14,r15
L_06044A88:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06044A88 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044A8A rts ; mov.l @r15+,r14
}

void f_06044AA8(SH2Context& c) {
    ran[1112] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06044AA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06044AAA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06044AAC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06044AAE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06044AB0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044AB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06044AB4 sts.l pr,@-r15
    c.r[1] = ld32(0x06044AE8u);  // 06044AB6 mov.l 0x06044AE8,r1
    c.r[0] = ld32(c.r[1]);  // 06044AB8 mov.l @r1,r0
    c.r[10] = 0x3u;  // 06044ABA mov #3,r10
    c.t = c.r[0] > c.r[10];  // 06044ABC cmp/hi r10,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06044AD2; } }  // 06044ABE bt/s 0x06044AD2 ; mov r15,r14
    c.r[5] = ld32(0x06044AECu);  // 06044AC2 mov.l 0x06044AEC,r5
    c.r[0] <<= 16;  // 06044AC4 shll16 r0
    c.r[0] += c.r[0];  // 06044AC6 add r0,r0
    c.r[1] = ld32(0x06044AF0u);  // 06044AC8 mov.l 0x06044AF0,r1
    c.r[0] += c.r[1];  // 06044ACA add r1,r0
    c.r[1] = ld32(0x06044AF4u);  // 06044ACC mov.l 0x06044AF4,r1
    c.r[4] = c.r[0]; goto L_06044ADC;  // 06044ACE bra 0x06044ADC ; mov r0,r4
L_06044AD2:
    c.t = c.r[0] == 0x4u;  // 06044AD2 cmp/eq #4,r0
    if (!c.t) { goto L_06044B00; }  // 06044AD4 bf 0x06044B00
    c.r[5] = (uint32_t)(int16_t)ld16(0x06044AE6u);  // 06044AD6 mov.w 0x06044AE6,r5
    c.r[4] = ld32(0x06044AF8u);  // 06044AD8 mov.l 0x06044AF8,r4
    c.r[1] = ld32(0x06044AF4u);  // 06044ADA mov.l 0x06044AF4,r1
L_06044ADC:
    { const uint32_t x = c.r[1]; c.pr = 0x06044AE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044AE0u) return; }  // 06044ADC jsr @r1 ; nop
    c.r[0] = ld32(0x06044AFCu);  // 06044AE0 mov.l 0x06044AFC,r0
    c.r[15] = c.r[14]; goto L_06044EC0;  // 06044AE2 bra 0x06044EC0 ; mov r14,r15
L_06044B00:
    c.r[1] = ld32(0x06044D60u);  // 06044B00 mov.l 0x06044D60,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B06u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B06u) return; }  // 06044B02 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06044D64u);  // 06044B06 mov.l 0x06044D64,r1
    c.r[5] = 0x0u;  // 06044B08 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B0Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B0Eu) return; }  // 06044B0A jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x06044D68u);  // 06044B0E mov.l 0x06044D68,r8
    c.r[1] = ld32(0x06044D6Cu);  // 06044B10 mov.l 0x06044D6C,r1
    c.r[6] = 0x0u;  // 06044B12 mov #0,r6
    c.r[5] = 0x0u;  // 06044B14 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B1Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B1Au) return; }  // 06044B16 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06044D70u);  // 06044B1A mov.l 0x06044D70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B20u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B20u) return; }  // 06044B1C jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x06044D74u);  // 06044B20 mov.l 0x06044D74,r4
    c.r[1] = ld32(0x06044D78u);  // 06044B22 mov.l 0x06044D78,r1
    c.r[7] = c.r[4];  // 06044B24 mov r4,r7
    c.r[6] = c.r[4];  // 06044B26 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06044B2Cu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B2Cu) return; }  // 06044B28 jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x06044D7Cu);  // 06044B2C mov.l 0x06044D7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B32u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B32u) return; }  // 06044B2E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06044D80u);  // 06044B32 mov.l 0x06044D80,r1
    c.r[5] = 0x0u;  // 06044B34 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B3Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B3Au) return; }  // 06044B36 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06044D84u);  // 06044B3A mov.l 0x06044D84,r1
    c.r[6] = 0x0u;  // 06044B3C mov #0,r6
    c.r[5] = 0x0u;  // 06044B3E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B44u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B44u) return; }  // 06044B40 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06044D88u);  // 06044B44 mov.l 0x06044D88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B4Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B4Au) return; }  // 06044B46 jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x06044D8Cu);  // 06044B4A mov.l 0x06044D8C,r4
    c.r[1] = ld32(0x06044D90u);  // 06044B4C mov.l 0x06044D90,r1
    c.r[7] = c.r[4];  // 06044B4E mov r4,r7
    c.r[6] = c.r[4];  // 06044B50 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06044B56u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B56u) return; }  // 06044B52 jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x06044D94u);  // 06044B56 mov.l 0x06044D94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B5Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B5Cu) return; }  // 06044B58 jsr @r1 ; mov #2,r4
    c.r[1] = ld32(0x06044D98u);  // 06044B5C mov.l 0x06044D98,r1
    c.r[5] = 0x0u;  // 06044B5E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B64u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B64u) return; }  // 06044B60 jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x06044D9Cu);  // 06044B64 mov.l 0x06044D9C,r4
    c.r[1] = ld32(0x06044DA0u);  // 06044B66 mov.l 0x06044DA0,r1
    c.r[6] = 0x0u;  // 06044B68 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06044B6Eu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B6Eu) return; }  // 06044B6A jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x06044DA4u);  // 06044B6E mov.l 0x06044DA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B74u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B74u) return; }  // 06044B70 jsr @r1 ; mov #0,r4
    c.r[9] = ld32(0x06044DA8u);  // 06044B74 mov.l 0x06044DA8,r9
    c.r[1] = ld32(0x06044DACu);  // 06044B76 mov.l 0x06044DAC,r1
    c.r[7] = c.r[9];  // 06044B78 mov r9,r7
    c.r[6] = c.r[9];  // 06044B7A mov r9,r6
    c.r[5] = c.r[9];  // 06044B7C mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B82u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B82u) return; }  // 06044B7E jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x06044DB0u);  // 06044B82 mov.l 0x06044DB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044B88u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B88u) return; }  // 06044B84 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x06044DB4u);  // 06044B88 mov.l 0x06044DB4,r1
    c.r[5] = 0x0u;  // 06044B8A mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B90u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B90u) return; }  // 06044B8C jsr @r1 ; mov #0,r4
    c.r[6] = ld32(0x06044DB8u);  // 06044B90 mov.l 0x06044DB8,r6
    c.r[8] = ld32(0x06044DBCu);  // 06044B92 mov.l 0x06044DBC,r8
    c.r[1] = ld32(0x06044DC0u);  // 06044B94 mov.l 0x06044DC0,r1
    c.r[5] = 0x0u;  // 06044B96 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044B9Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044B9Cu) return; }  // 06044B98 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06044DC4u);  // 06044B9C mov.l 0x06044DC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044BA2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BA2u) return; }  // 06044B9E jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x06044DC8u);  // 06044BA2 mov.l 0x06044DC8,r4
    c.r[1] = ld32(0x06044DCCu);  // 06044BA4 mov.l 0x06044DCC,r1
    c.r[7] = c.r[4];  // 06044BA6 mov r4,r7
    c.r[6] = c.r[4];  // 06044BA8 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06044BAEu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BAEu) return; }  // 06044BAA jsr @r1 ; mov r4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06044D50u);  // 06044BAE mov.w 0x06044D50,r6
    c.r[4] = ld32(0x06044DD0u);  // 06044BB0 mov.l 0x06044DD0,r4
    c.r[1] = 0x20u;  // 06044BB2 mov #32,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06044BB4 mov.l r1,@-r15
    c.r[1] = ld32(0x06044DD4u);  // 06044BB6 mov.l 0x06044DD4,r1
    c.r[7] = 0x0u;  // 06044BB8 mov #0,r7
    { const uint32_t x = c.r[1]; c.pr = 0x06044BBEu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BBEu) return; }  // 06044BBA jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06044DD8u);  // 06044BBE mov.l 0x06044DD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044BC4u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BC4u) return; }  // 06044BC0 jsr @r1 ; mov #2,r4
    c.r[2] = ld32(0x06044DDCu);  // 06044BC4 mov.l 0x06044DDC,r2
    c.r[1] = 0x0u;  // 06044BC6 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06044BC8 mov.w r1,@r2
    c.r[1] = ld32(0x06044DE0u);  // 06044BCA mov.l 0x06044DE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044BD0u; c.r[4] = 0x4Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BD0u) return; }  // 06044BCC jsr @r1 ; mov #79,r4
    c.r[1] = ld32(0x06044DE4u);  // 06044BD0 mov.l 0x06044DE4,r1
    c.r[6] = 0x0u;  // 06044BD2 mov #0,r6
    c.r[5] = 0x0u;  // 06044BD4 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044BDAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BDAu) return; }  // 06044BD6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06044DE8u);  // 06044BDA mov.l 0x06044DE8,r1
    c.r[6] = 0x0u;  // 06044BDC mov #0,r6
    c.r[5] = 0x0u;  // 06044BDE mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044BE4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BE4u) return; }  // 06044BE0 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x06044DECu);  // 06044BE4 mov.l 0x06044DEC,r8
    c.r[5] = 0x7u;  // 06044BE6 mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044BECu; c.r[4] = 0xFFFFFFFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BECu) return; }  // 06044BE8 jsr @r8 ; mov #-2,r4
    c.r[5] = 0x7u;  // 06044BEC mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044BF2u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BF2u) return; }  // 06044BEE jsr @r8 ; mov #2,r4
    c.r[5] = 0x6u;  // 06044BF2 mov #6,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044BF8u; c.r[4] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BF8u) return; }  // 06044BF4 jsr @r8 ; mov #-1,r4
    c.r[5] = 0x5u;  // 06044BF8 mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044BFEu; c.r[4] = 0xFFFFFFFCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044BFEu) return; }  // 06044BFA jsr @r8 ; mov #-4,r4
    c.r[5] = 0x4u;  // 06044BFE mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044C04u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C04u) return; }  // 06044C00 jsr @r8 ; mov #1,r4
    c.r[5] = 0x4u;  // 06044C04 mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044C0Au; c.r[4] = 0xFFFFFFFDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C0Au) return; }  // 06044C06 jsr @r8 ; mov #-3,r4
    c.r[5] = 0x4u;  // 06044C0A mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044C10u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C10u) return; }  // 06044C0C jsr @r8 ; mov #0,r4
    c.r[5] = c.r[10];  // 06044C10 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044C16u; c.r[4] = 0xFFFFFFFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C16u) return; }  // 06044C12 jsr @r8 ; mov #-6,r4
    c.r[5] = c.r[10];  // 06044C16 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044C1Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C1Cu) return; }  // 06044C18 jsr @r8 ; mov r10,r4
    c.r[5] = 0x1u;  // 06044C1C mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044C22u; c.r[4] = 0xFFFFFFF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C22u) return; }  // 06044C1E jsr @r8 ; mov #-8,r4
    c.r[1] = ld32(0x06044DF0u);  // 06044C22 mov.l 0x06044DF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044C28u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C28u) return; }  // 06044C24 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06044DF4u);  // 06044C28 mov.l 0x06044DF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044C2Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C2Eu) return; }  // 06044C2A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06044DF8u);  // 06044C2E mov.l 0x06044DF8,r1
    c.r[5] = 0x0u;  // 06044C30 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044C36u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C36u) return; }  // 06044C32 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06044DFCu);  // 06044C36 mov.l 0x06044DFC,r1
    c.r[5] = 0x0u;  // 06044C38 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06044C3Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C3Eu) return; }  // 06044C3A jsr @r1 ; mov #0,r4
    c.r[0] = ld32(0x06044E00u);  // 06044C3E mov.l 0x06044E00,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06044C44u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C44u) return; }  // 06044C40 jsr @r0 ; mov #15,r4
    c.r[5] = ld32(0x06044E04u);  // 06044C44 mov.l 0x06044E04,r5
    c.r[4] = ld32(0x06044E08u);  // 06044C46 mov.l 0x06044E08,r4
    c.r[1] = ld32(0x06044E0Cu);  // 06044C48 mov.l 0x06044E0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044C4Eu; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044C4Eu) return; }  // 06044C4A jsr @r1 ; mov #0,r10
    c.r[2] = ld32(0x06044E10u);  // 06044C4E mov.l 0x06044E10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044D52u);  // 06044C50 mov.w 0x06044D52,r1
    st16(c.r[2], c.r[1]);  // 06044C52 mov.w r1,@r2
    c.r[2] = ld32(0x06044E14u);  // 06044C54 mov.l 0x06044E14,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044D54u);  // 06044C56 mov.w 0x06044D54,r1
    st16(c.r[2], c.r[1]);  // 06044C58 mov.w r1,@r2
    c.r[15] += 4;  // 06044C5A add #4,r15
    c.r[2] = (uint32_t)(int16_t)ld16(0x06044D56u);  // 06044C5C mov.w 0x06044D56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044D54u);  // 06044C5E mov.w 0x06044D54,r1
L_06044C60:
    st32(c.r[9], c.r[1]);  // 06044C60 mov.l r1,@r9
    c.r[10] += 1;  // 06044C62 add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[2];  // 06044C64 cmp/gt r2,r10
    { const bool k = !c.t; c.r[9] += 4; if (k) { SH2_POLL(c); goto L_06044C60; } }  // 06044C66 bf/s 0x06044C60 ; add #4,r9
    c.r[2] = ld32(0x06044E18u);  // 06044C6A mov.l 0x06044E18,r2
    c.r[11] = 0x1u;  // 06044C6C mov #1,r11
    st32(c.r[2] + 24, c.r[11]);  // 06044C6E mov.l r11,@(24,r2)
    c.r[12] = 0x2u;  // 06044C70 mov #2,r12
    st32(c.r[2] + 28, c.r[12]);  // 06044C72 mov.l r12,@(28,r2)
    c.r[1] = ld32(0x06044E1Cu);  // 06044C74 mov.l 0x06044E1C,r1
    st32(c.r[2] + 32, c.r[1]);  // 06044C76 mov.l r1,@(32,r2)
    c.r[1] = 0x8u;  // 06044C78 mov #8,r1
    st32(c.r[2] + 36, c.r[1]);  // 06044C7A mov.l r1,@(36,r2)
    c.r[1] = ld32(0x06044E20u);  // 06044C7C mov.l 0x06044E20,r1
    st32(c.r[2] + 40, c.r[1]);  // 06044C7E mov.l r1,@(40,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06044D58u);  // 06044C80 mov.w 0x06044D58,r0
    c.r[1] = ld32(0x06044D74u);  // 06044C82 mov.l 0x06044D74,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06044C84 mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06044D5Au);  // 06044C86 mov.w 0x06044D5A,r0
    c.r[1] = ld32(0x06044D8Cu);  // 06044C88 mov.l 0x06044D8C,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06044C8A mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06044D5Cu);  // 06044C8C mov.w 0x06044D5C,r0
    c.r[1] = ld32(0x06044DA8u);  // 06044C8E mov.l 0x06044DA8,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06044C90 mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06044D5Eu);  // 06044C92 mov.w 0x06044D5E,r0
    c.r[1] = ld32(0x06044DC8u);  // 06044C94 mov.l 0x06044DC8,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06044C96 mov.l r1,@(r0,r2)
    c.r[10] = ld32(0x06044E24u);  // 06044C98 mov.l 0x06044E24,r10
    c.r[8] = ld32(0x06044E28u);  // 06044C9A mov.l 0x06044E28,r8
    c.r[9] = ld32(0x06044E2Cu);  // 06044C9C mov.l 0x06044E2C,r9
    c.r[6] = 0x4u;  // 06044C9E mov #4,r6
    c.r[4] = ld32(c.r[8]);  // 06044CA0 mov.l @r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06044CA6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CA6u) return; }  // 06044CA2 jsr @r9 ; mov #0,r5
    st32(c.r[10], c.r[0]);  // 06044CA6 mov.l r0,@r10
    c.r[10] = ld32(0x06044E30u);  // 06044CA8 mov.l 0x06044E30,r10
    c.r[6] = 0x4u;  // 06044CAA mov #4,r6
    c.r[4] = ld32(c.r[8]);  // 06044CAC mov.l @r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06044CB2u; c.r[5] = 0x13u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CB2u) return; }  // 06044CAE jsr @r9 ; mov #19,r5
    c.r[0] += 76;  // 06044CB2 add #76,r0
    st32(c.r[10], c.r[0]);  // 06044CB4 mov.l r0,@r10
    c.r[10] = ld32(0x06044E34u);  // 06044CB6 mov.l 0x06044E34,r10
    c.r[6] = 0x4u;  // 06044CB8 mov #4,r6
    c.r[4] = ld32(c.r[8]);  // 06044CBA mov.l @r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06044CC0u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CC0u) return; }  // 06044CBC jsr @r9 ; mov r11,r5
    c.r[0] += 4;  // 06044CC0 add #4,r0
    st32(c.r[10], c.r[0]);  // 06044CC2 mov.l r0,@r10
    c.r[10] = ld32(0x06044E38u);  // 06044CC4 mov.l 0x06044E38,r10
    c.r[6] = 0x4u;  // 06044CC6 mov #4,r6
    c.r[4] = ld32(c.r[8]);  // 06044CC8 mov.l @r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06044CCEu; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CCEu) return; }  // 06044CCA jsr @r9 ; mov r12,r5
    c.r[0] += 8;  // 06044CCE add #8,r0
    st32(c.r[10], c.r[0]);  // 06044CD0 mov.l r0,@r10
    c.r[10] = ld32(0x06044E3Cu);  // 06044CD2 mov.l 0x06044E3C,r10
    c.r[6] = 0x4u;  // 06044CD4 mov #4,r6
    c.r[4] = ld32(c.r[8]);  // 06044CD6 mov.l @r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06044CDCu; c.r[5] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CDCu) return; }  // 06044CD8 jsr @r9 ; mov #3,r5
    c.r[0] += 12;  // 06044CDC add #12,r0
    st32(c.r[10], c.r[0]);  // 06044CDE mov.l r0,@r10
    c.r[1] = ld32(0x06044E40u);  // 06044CE0 mov.l 0x06044E40,r1
    c.r[4] = ld32(0x06044E44u);  // 06044CE2 mov.l 0x06044E44,r4
    st32(c.r[1], c.r[4]);  // 06044CE4 mov.l r4,@r1
    c.r[5] = ld32(0x06044E48u);  // 06044CE6 mov.l 0x06044E48,r5
    c.r[1] = ld32(0x06044E4Cu);  // 06044CE8 mov.l 0x06044E4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044CEEu; c.r[10] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CEEu) return; }  // 06044CEA jsr @r1 ; mov #9,r10
    c.r[1] = ld32(0x06044E50u);  // 06044CEE mov.l 0x06044E50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044CF4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CF4u) return; }  // 06044CF0 jsr @r1 ; nop
    c.r[1] = ld32(0x06044E54u);  // 06044CF4 mov.l 0x06044E54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044CFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044CFAu) return; }  // 06044CF6 jsr @r1 ; nop
    c.r[2] = ld32(0x06044E58u);  // 06044CFA mov.l 0x06044E58,r2
    c.r[1] = 0x0u;  // 06044CFC mov #0,r1
    st16(c.r[2], c.r[1]);  // 06044CFE mov.w r1,@r2
    c.r[9] = ld32(0x06044E5Cu);  // 06044D00 mov.l 0x06044E5C,r9
L_06044D02:
    c.r[8] = c.r[10] & 0xFFu;  // 06044D02 extu.b r10,r8
    c.r[6] = 0x0u;  // 06044D04 mov #0,r6
    c.r[5] = c.r[8];  // 06044D06 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06044D0Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044D0Cu) return; }  // 06044D08 jsr @r9 ; mov #0,r4
    c.r[6] = 0x0u;  // 06044D0C mov #0,r6
    c.r[5] = c.r[8];  // 06044D0E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06044D14u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044D14u) return; }  // 06044D10 jsr @r9 ; mov #1,r4
    c.r[10] += 1;  // 06044D14 add #1,r10
    c.r[1] = 0xFu;  // 06044D16 mov #15,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06044D18 cmp/gt r1,r10
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { SH2_POLL(c); goto L_06044D02; } }  // 06044D1A bf/s 0x06044D02 ; mov #1,r1
    c.r[2] = ld32(0x06044E60u);  // 06044D1E mov.l 0x06044E60,r2
    st8(c.r[2], c.r[1]);  // 06044D20 mov.b r1,@r2
    c.r[2] = ld32(0x06044E64u);  // 06044D22 mov.l 0x06044E64,r2
    c.r[1] = 0x2u;  // 06044D24 mov #2,r1
    st8(c.r[2], c.r[1]);  // 06044D26 mov.b r1,@r2
    c.r[8] = ld32(0x06044E5Cu);  // 06044D28 mov.l 0x06044E5C,r8
    c.r[6] = 0x0u;  // 06044D2A mov #0,r6
    c.r[5] = 0x2u;  // 06044D2C mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044D32u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044D32u) return; }  // 06044D2E jsr @r8 ; mov #1,r4
    c.r[6] = 0x0u;  // 06044D32 mov #0,r6
    c.r[5] = 0x3u;  // 06044D34 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044D3Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044D3Au) return; }  // 06044D36 jsr @r8 ; mov #1,r4
    c.r[6] = 0x0u;  // 06044D3A mov #0,r6
    c.r[5] = 0x2u;  // 06044D3C mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044D42u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044D42u) return; }  // 06044D3E jsr @r8 ; mov #0,r4
    c.r[6] = ld32(0x06044E68u);  // 06044D42 mov.l 0x06044E68,r6
    c.r[5] = 0x8u;  // 06044D44 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06044D4Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044D4Au) return; }  // 06044D46 jsr @r8 ; mov #0,r4
    c.r[6] = ld32(0x06044E6Cu);  // 06044D4A mov.l 0x06044E6C,r6
    c.r[5] = 0x7u; goto L_06044E70;  // 06044D4C bra 0x06044E70 ; mov #7,r5
L_06044E70:
    { const uint32_t x = c.r[8]; c.pr = 0x06044E74u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044E74u) return; }  // 06044E70 jsr @r8 ; mov #1,r4
    c.r[1] = ld32(0x06044ED4u);  // 06044E74 mov.l 0x06044ED4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044E7Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044E7Au) return; }  // 06044E76 jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x06044ED8u);  // 06044E7A mov.l 0x06044ED8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044ED0u);  // 06044E7C mov.w 0x06044ED0,r1
    st16(c.r[2], c.r[1]);  // 06044E7E mov.w r1,@r2
    c.r[1] = ld32(0x06044EDCu);  // 06044E80 mov.l 0x06044EDC,r1
    c.r[2] = 0x0u;  // 06044E82 mov #0,r2
    st8(c.r[1], c.r[2]);  // 06044E84 mov.b r2,@r1
    c.r[1] = ld32(0x06044EE0u);  // 06044E86 mov.l 0x06044EE0,r1
    st8(c.r[1], c.r[2]);  // 06044E88 mov.b r2,@r1
    c.r[1] = ld32(0x06044EE4u);  // 06044E8A mov.l 0x06044EE4,r1
    st8(c.r[1], c.r[2]);  // 06044E8C mov.b r2,@r1
    c.r[1] = ld32(0x06044EE8u);  // 06044E8E mov.l 0x06044EE8,r1
    st8(c.r[1], c.r[2]);  // 06044E90 mov.b r2,@r1
    c.r[2] = ld32(0x06044EECu);  // 06044E92 mov.l 0x06044EEC,r2
    c.r[1] = 0x0u;  // 06044E94 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06044E96 mov.l r1,@r2
    c.r[1] = ld32(0x06044EF0u);  // 06044E98 mov.l 0x06044EF0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044E9A mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06044E9C and #239,r0
    st8(c.r[1], c.r[0]);  // 06044E9E mov.b r0,@r1
    c.r[1] = ld32(0x06044EF4u);  // 06044EA0 mov.l 0x06044EF4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044EA2 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06044EA4 and #127,r0
    st8(c.r[1], c.r[0]);  // 06044EA6 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044EA8 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06044EAA and #191,r0
    st8(c.r[1], c.r[0]);  // 06044EAC mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044EAE mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 06044EB0 and #223,r0
    st8(c.r[1], c.r[0]);  // 06044EB2 mov.b r0,@r1
    c.r[1] = ld32(0x06044EF8u);  // 06044EB4 mov.l 0x06044EF8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044EB6 mov.b @r1,r0
    c.r[0] &= 0x87u;  // 06044EB8 and #135,r0
    st8(c.r[1], c.r[0]);  // 06044EBA mov.b r0,@r1
    c.r[0] = ld32(0x06044EFCu);  // 06044EBC mov.l 0x06044EFC,r0
    c.r[15] = c.r[14];  // 06044EBE mov r14,r15
L_06044EC0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06044EC0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044EC2 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06044EC4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06044EC6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06044EC8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06044ECA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044ECC rts ; mov.l @r15+,r8
}

void f_06044F00(SH2Context& c) {
    ran[1113] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06044F00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044F02 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06044F04 sts.l pr,@-r15
    c.r[8] = ld32(0x06044F78u);  // 06044F06 mov.l 0x06044F78,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044F08 mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06044F72u);  // 06044F0A mov.w 0x06044F72,r2
    c.r[2] &= c.r[1];  // 06044F0C and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06044F0E tst r2,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06044F1A; } }  // 06044F10 bt/s 0x06044F1A ; mov r15,r14
    c.r[1] = ld32(0x06044F7Cu);  // 06044F14 mov.l 0x06044F7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044F1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044F1Au) return; }  // 06044F16 jsr @r1 ; nop
L_06044F1A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044F1A mov.w @r8,r0
    c.r[0] &= 0x2u;  // 06044F1C and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044F1E tst r0,r0
    if (c.t) { goto L_06044F28; }  // 06044F20 bt 0x06044F28
    c.r[1] = ld32(0x06044F80u);  // 06044F22 mov.l 0x06044F80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044F28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044F28u) return; }  // 06044F24 jsr @r1 ; nop
L_06044F28:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044F28 mov.w @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044F74u);  // 06044F2A mov.w 0x06044F74,r1
    c.r[0] = c.r[2];  // 06044F2C mov r2,r0
    c.r[0] |= c.r[1];  // 06044F2E or r1,r0
    st16(c.r[8], c.r[0]);  // 06044F30 mov.w r0,@r8
    c.r[0] &= 0x1u;  // 06044F32 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044F34 tst r0,r0
    if (c.t) { goto L_06044F3E; }  // 06044F36 bt 0x06044F3E
    c.r[1] = ld32(0x06044F84u);  // 06044F38 mov.l 0x06044F84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044F3Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044F3Eu) return; }  // 06044F3A jsr @r1 ; nop
L_06044F3E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044F3E mov.w @r8,r0
    c.r[0] &= 0x40u;  // 06044F40 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044F42 tst r0,r0
    if (c.t) { goto L_06044F4C; }  // 06044F44 bt 0x06044F4C
    c.r[1] = ld32(0x06044F88u);  // 06044F46 mov.l 0x06044F88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044F4Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044F4Cu) return; }  // 06044F48 jsr @r1 ; nop
L_06044F4C:
    c.r[1] = ld32(0x06044F8Cu);  // 06044F4C mov.l 0x06044F8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044F52u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044F52u) return; }  // 06044F4E jsr @r1 ; nop
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044F52 mov.w @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06044F76u);  // 06044F54 mov.w 0x06044F76,r1
    c.r[0] = c.r[2];  // 06044F56 mov r2,r0
    c.r[0] |= c.r[1];  // 06044F58 or r1,r0
    st16(c.r[8], c.r[0]);  // 06044F5A mov.w r0,@r8
    c.r[0] &= 0x4u;  // 06044F5C and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044F5E tst r0,r0
    if (c.t) { goto L_06044F68; }  // 06044F60 bt 0x06044F68
    c.r[1] = ld32(0x06044F90u);  // 06044F62 mov.l 0x06044F90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044F68u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044F68u) return; }  // 06044F64 jsr @r1 ; nop
L_06044F68:
    c.r[15] = c.r[14];  // 06044F68 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06044F6A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06044F6C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06044F6E rts ; mov.l @r15+,r8
}

void f_06044F94(SH2Context& c) {
    ran[1114] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06044F94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06044F96 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06044F98 sts.l pr,@-r15
    c.r[1] = ld32(0x06045014u);  // 06044F9A mov.l 0x06045014,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06044F9C mov.b @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044F9E tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06044FDE; } }  // 06044FA0 bf/s 0x06044FDE ; mov r15,r14
    c.r[8] = ld32(0x06045018u);  // 06044FA4 mov.l 0x06045018,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044FA6 mov.w @r8,r2
    c.r[1] = ld32(0x0604501Cu);  // 06044FA8 mov.l 0x0604501C,r1
    c.r[1] &= c.r[2];  // 06044FAA and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044FAC tst r1,r1
    if (c.t) { goto L_06044FBC; }  // 06044FAE bt 0x06044FBC
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604500Cu);  // 06044FB0 mov.w 0x0604500C,r1
    c.r[1] &= c.r[2];  // 06044FB2 and r2,r1
    st16(c.r[8], c.r[1]);  // 06044FB4 mov.w r1,@r8
    c.r[1] = ld32(0x06045020u);  // 06044FB6 mov.l 0x06045020,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044FBCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044FBCu) return; }  // 06044FB8 jsr @r1 ; nop
L_06044FBC:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06044FBC mov.w @r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604500Eu);  // 06044FBE mov.w 0x0604500E,r1
    c.r[1] &= c.r[0];  // 06044FC0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06044FC2 tst r1,r1
    if (c.t) { goto L_06044FD8; }  // 06044FC4 bt 0x06044FD8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06045010u);  // 06044FC6 mov.w 0x06045010,r1
    c.r[1] &= c.r[0];  // 06044FC8 and r0,r1
    c.r[0] &= 0x40u;  // 06044FCA and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06044FCC tst r0,r0
    { const bool k = c.t; st16(c.r[8], c.r[1]); if (k) { goto L_06044FD8; } }  // 06044FCE bt/s 0x06044FD8 ; mov.w r1,@r8
    c.r[1] = ld32(0x06045024u);  // 06044FD2 mov.l 0x06045024,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044FD8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044FD8u) return; }  // 06044FD4 jsr @r1 ; nop
L_06044FD8:
    c.r[1] = ld32(0x06045028u);  // 06044FD8 mov.l 0x06045028,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06044FDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06044FDEu) return; }  // 06044FDA jsr @r1 ; nop
L_06044FDE:
    c.r[3] = ld32(0x0604502Cu);  // 06044FDE mov.l 0x0604502C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06044FE0 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06044FE2 mov r1,r0
    c.r[0] >>= 2;  // 06044FE4 shlr2 r0
    c.r[0] >>= 2;  // 06044FE6 shlr2 r0
    c.r[0] >>= 2;  // 06044FE8 shlr2 r0
    c.r[0] &= 0x1u;  // 06044FEA and #1,r0
    c.t = c.r[0] == 0x1u;  // 06044FEC cmp/eq #1,r0
    if (!c.t) { goto L_06045002; }  // 06044FEE bf 0x06045002
    c.r[1] = ld32(0x06045030u);  // 06044FF0 mov.l 0x06045030,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06044FF2 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06044FF4 extu.w r1,r0
    c.t = c.r[0] == 0x20u;  // 06044FF6 cmp/eq #32,r0
    if (!c.t) { goto L_06045002; }  // 06044FF8 bf 0x06045002
    c.r[1] = ld32(c.r[3] + 24);  // 06044FFA mov.l @(24,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06045012u);  // 06044FFC mov.w 0x06045012,r2
    c.r[2] += c.r[1];  // 06044FFE add r1,r2
    st32(c.r[3] + 24, c.r[2]);  // 06045000 mov.l r2,@(24,r3)
L_06045002:
    c.r[15] = c.r[14];  // 06045002 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06045004 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06045006 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045008 rts ; mov.l @r15+,r8
}

void f_06045034(SH2Context& c) {
    ran[1115] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045034 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06045036 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06045038 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604503A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604503C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604503E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06045040 sts.l pr,@-r15
    c.r[15] -= 32;  // 06045042 add #-32,r15
    c.r[14] = c.r[15];  // 06045044 mov r15,r14
    c.r[1] = ld32(0x06045190u);  // 06045046 mov.l 0x06045190,r1
    c.r[0] = ld32(0x06045194u);  // 06045048 mov.l 0x06045194,r0
    c.r[6] = 0x4u;  // 0604504A mov #4,r6
    c.r[4] = ld32(c.r[1]);  // 0604504C mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06045052u; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045052u) return; }  // 0604504E jsr @r0 ; mov #4,r5
    c.r[2] = c.r[0];  // 06045052 mov r0,r2
    c.r[2] += 16;  // 06045054 add #16,r2
    c.r[1] = ld32(0x06045198u);  // 06045056 mov.l 0x06045198,r1
    c.r[0] = ld32(0x0604519Cu);  // 06045058 mov.l 0x0604519C,r0
    c.r[6] = c.r[14];  // 0604505A mov r14,r6
    c.r[5] = ld32(c.r[1]);  // 0604505C mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06045062u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045062u) return; }  // 0604505E jsr @r0 ; mov r2,r4
    c.r[0] = ld32(0x060451A0u);  // 06045062 mov.l 0x060451A0,r0
    c.r[6] = 0x2u;  // 06045064 mov #2,r6
    c.r[5] = ld32(c.r[14] + 8);  // 06045066 mov.l @(8,r14),r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604506Cu; c.r[4] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604506Cu) return; }  // 06045068 jsr @r0 ; mov #38,r4
    c.r[8] = ld32(0x060451A4u);  // 0604506C mov.l 0x060451A4,r8
    c.r[1] = 0x1u;  // 0604506E mov #1,r1
    st8(c.r[8], c.r[1]);  // 06045070 mov.b r1,@r8
    c.r[1] = c.r[14];  // 06045072 mov r14,r1
    c.r[1] += 6;  // 06045074 add #6,r1
    c.r[5] = ld32(0x060451A8u);  // 06045076 mov.l 0x060451A8,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045078 mov.w @r1,r6
    c.r[7] = 0x7u;  // 0604507A mov #7,r7
    c.r[4] = ld32(c.r[14] + 16);  // 0604507C mov.l @(16,r14),r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 0604507E extu.w r6,r6
    c.r[6] <<= 2;  // 06045080 shll2 r6
    c.r[6] += c.r[6];  // 06045082 add r6,r6
    c.r[1] = ld32(0x060451ACu);  // 06045084 mov.l 0x060451AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604508Au; c.r[6] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604508Au) return; }  // 06045086 jsr @r1 ; shll2 r6
    c.r[1] = ld32(0x060451B0u);  // 0604508A mov.l 0x060451B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045090u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045090u) return; }  // 0604508C jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06045090 mov #0,r1
    st8(c.r[8], c.r[1]);  // 06045092 mov.b r1,@r8
    c.r[8] = ld32(0x060451B4u);  // 06045094 mov.l 0x060451B4,r8
    c.r[7] = 0xFu;  // 06045096 mov #15,r7
    c.r[6] = 0x1u;  // 06045098 mov #1,r6
    c.r[5] = 0x1u;  // 0604509A mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060450A0u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450A0u) return; }  // 0604509C jsr @r8 ; mov #32,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604517Eu);  // 060450A0 mov.w 0x0604517E,r4
    c.r[7] = 0x10u;  // 060450A2 mov #16,r7
    c.r[6] = 0x0u;  // 060450A4 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060450AAu; c.r[5] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450AAu) return; }  // 060450A6 jsr @r8 ; mov #38,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06045180u);  // 060450AA mov.w 0x06045180,r4
    c.r[7] = 0x10u;  // 060450AC mov #16,r7
    c.r[6] = 0x0u;  // 060450AE mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060450B4u; c.r[5] = 0x27u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450B4u) return; }  // 060450B0 jsr @r8 ; mov #39,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06045182u);  // 060450B4 mov.w 0x06045182,r4
    c.r[7] = 0x10u;  // 060450B6 mov #16,r7
    c.r[6] = 0x0u;  // 060450B8 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060450BEu; c.r[5] = 0x28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450BEu) return; }  // 060450BA jsr @r8 ; mov #40,r5
    c.r[2] = ld32(0x060451B8u);  // 060450BE mov.l 0x060451B8,r2
    c.r[1] = 0x1u;  // 060450C0 mov #1,r1
    st16(c.r[2], c.r[1]);  // 060450C2 mov.w r1,@r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06045184u);  // 060450C4 mov.w 0x06045184,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06045186u);  // 060450C6 mov.w 0x06045186,r5
    c.r[4] = ld32(0x060451BCu);  // 060450C8 mov.l 0x060451BC,r4
    c.r[8] = ld32(0x060451C0u);  // 060450CA mov.l 0x060451C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060450D0u; c.r[6] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450D0u) return; }  // 060450CC jsr @r8 ; mov #2,r6
    c.r[10] = 0x0u;  // 060450D0 mov #0,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06045188u);  // 060450D2 mov.w 0x06045188,r9
L_060450D4:
    c.r[12] = ld32(0x060451BCu);  // 060450D4 mov.l 0x060451BC,r12
    c.r[4] = c.r[9];  // 060450D6 mov r9,r4
    c.r[4] += c.r[12];  // 060450D8 add r12,r4
    c.r[7] = 0x30u;  // 060450DA mov #48,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06045186u);  // 060450DC mov.w 0x06045186,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060450E2u; c.r[6] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450E2u) return; }  // 060450DE jsr @r8 ; mov #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604518Au);  // 060450E2 mov.w 0x0604518A,r1
    c.r[9] += c.r[1];  // 060450E4 add r1,r9
    c.r[10] += 1;  // 060450E6 add #1,r10
    c.r[1] = 0xFu;  // 060450E8 mov #15,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060450EA cmp/gt r1,r10
    { const bool k = !c.t; c.r[6] = 0x2u; if (k) { SH2_POLL(c); goto L_060450D4; } }  // 060450EC bf/s 0x060450D4 ; mov #2,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604518Cu);  // 060450F0 mov.w 0x0604518C,r7
    c.r[8] = (uint32_t)(int16_t)ld16(0x06045186u);  // 060450F2 mov.w 0x06045186,r8
    c.r[4] = ld32(0x060451C4u);  // 060450F4 mov.l 0x060451C4,r4
    c.r[9] = ld32(0x060451C0u);  // 060450F6 mov.l 0x060451C0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060450FCu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060450FCu) return; }  // 060450F8 jsr @r9 ; mov r8,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604518Eu);  // 060450FC mov.w 0x0604518E,r11
    c.r[4] = ld32(0x060451C8u);  // 060450FE mov.l 0x060451C8,r4
    c.r[7] = c.r[11];  // 06045100 mov r11,r7
    c.r[6] = 0x2u;  // 06045102 mov #2,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06045108u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045108u) return; }  // 06045104 jsr @r9 ; mov r8,r5
    c.r[1] = ld32(0x06045190u);  // 06045108 mov.l 0x06045190,r1
    c.r[0] = ld32(0x06045194u);  // 0604510A mov.l 0x06045194,r0
    c.r[6] = 0x4u;  // 0604510C mov #4,r6
    c.r[4] = ld32(c.r[1]);  // 0604510E mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06045114u; c.r[5] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045114u) return; }  // 06045110 jsr @r0 ; mov #5,r5
    c.r[2] = c.r[0];  // 06045114 mov r0,r2
    c.r[2] += 20;  // 06045116 add #20,r2
    c.r[9] = c.r[14];  // 06045118 mov r14,r9
    c.r[9] += 24;  // 0604511A add #24,r9
    c.r[1] = ld32(0x06045198u);  // 0604511C mov.l 0x06045198,r1
    c.r[0] = ld32(0x060451CCu);  // 0604511E mov.l 0x060451CC,r0
    c.r[6] = c.r[9];  // 06045120 mov r9,r6
    c.r[5] = ld32(c.r[1]);  // 06045122 mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06045128u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045128u) return; }  // 06045124 jsr @r0 ; mov r2,r4
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06045128 mov.l r9,@-r15
    c.r[8] = 0x0u;  // 0604512A mov #0,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604512C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604512E mov.l r8,@-r15
    c.r[10] = ld32(0x060451D0u);  // 06045130 mov.l 0x060451D0,r10
    c.r[7] = c.r[12];  // 06045132 mov r12,r7
    c.r[6] = 0x10u;  // 06045134 mov #16,r6
    c.r[5] = c.r[11];  // 06045136 mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604513Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604513Cu) return; }  // 06045138 jsr @r10 ; mov #0,r4
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604513C mov.l r9,@-r15
    c.r[1] = 0x14u;  // 0604513E mov #20,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045140 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045142 mov.l r8,@-r15
    c.r[7] = c.r[12];  // 06045144 mov r12,r7
    c.r[6] = 0x10u;  // 06045146 mov #16,r6
    c.r[5] = c.r[11];  // 06045148 mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604514Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604514Eu) return; }  // 0604514A jsr @r10 ; mov #1,r4
    c.r[1] = ld32(0x060451D4u);  // 0604514E mov.l 0x060451D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045154u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045154u) return; }  // 06045150 jsr @r1 ; nop
    c.r[1] = ld32(0x060451D8u);  // 06045154 mov.l 0x060451D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604515Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604515Au) return; }  // 06045156 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060451DCu);  // 0604515A mov.l 0x060451DC,r1
    c.r[2] = ld32(0x060451E0u);  // 0604515C mov.l 0x060451E0,r2
    c.r[14] += 32;  // 0604515E add #32,r14
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045160 mov.w @r1,r0
    c.r[15] = c.r[14];  // 06045162 mov r14,r15
    c.r[0] |= 0x2u;  // 06045164 or #2,r0
    st16(c.r[1], c.r[0]);  // 06045166 mov.w r0,@r1
    c.r[1] = 0x8u;  // 06045168 mov #8,r1
    st32(c.r[2] + 36, c.r[1]);  // 0604516A mov.l r1,@(36,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604516C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604516E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06045170 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06045172 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06045174 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06045176 mov.l @r15+,r9
    c.r[0] = ld32(0x060451E4u);  // 06045178 mov.l 0x060451E4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604517A rts ; mov.l @r15+,r8
}

void f_060451E8(SH2Context& c) {
    ran[1116] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060451E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060451EA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060451EC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060451EE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060451F0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060451F2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060451F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060451F6 sts.l pr,@-r15
    c.r[3] = ld32(0x060452D0u);  // 060451F8 mov.l 0x060452D0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060451FA mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060452C8u);  // 060451FC mov.w 0x060452C8,r2
    c.r[1] &= c.r[2];  // 060451FE and r2,r1
    st16(c.r[3], c.r[1]);  // 06045200 mov.w r1,@r3
    c.r[1] = ld32(0x060452D4u);  // 06045202 mov.l 0x060452D4,r1
    c.r[1] = ld32(c.r[1]);  // 06045204 mov.l @r1,r1
    c.r[15] -= 24;  // 06045206 add #-24,r15
    c.r[1] += 1;  // 06045208 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604520A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0604520C extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060452CAu);  // 0604520E mov.w 0x060452CA,r1
    c.t = c.r[2] == c.r[1];  // 06045210 cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06045220; } }  // 06045212 bt/s 0x06045220 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060452CCu);  // 06045216 mov.w 0x060452CC,r1
    c.t = c.r[2] == c.r[1];  // 06045218 cmp/eq r1,r2
    if (!c.t) { goto L_060452F8; }  // 0604521A bf 0x060452F8
    goto L_06045270;  // 0604521C bra 0x06045270 ; nop
L_06045220:
    c.r[1] = ld32(0x060452D8u);  // 06045220 mov.l 0x060452D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045222 mov.b @r1,r1
    c.r[2] = ld32(0x060452DCu);  // 06045224 mov.l 0x060452DC,r2
    c.r[0] = c.r[1];  // 06045226 mov r1,r0
    c.r[0] >>= 2;  // 06045228 shlr2 r0
    c.r[0] >>= 2;  // 0604522A shlr2 r0
    c.r[0] >>= 2;  // 0604522C shlr2 r0
    c.r[0] &= 0x1u;  // 0604522E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06045230 tst r0,r0
    if (c.t) { goto L_0604523A; }  // 06045232 bt 0x0604523A
    c.r[1] = ld32(0x060452E0u);  // 06045234 mov.l 0x060452E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0604523E;  // 06045236 bra 0x0604523E ; mov.b @r1,r1
L_0604523A:
    c.r[1] = ld32(0x060452E4u);  // 0604523A mov.l 0x060452E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604523C mov.b @r1,r1
L_0604523E:
    st8(c.r[2], c.r[1]);  // 0604523E mov.b r1,@r2
    c.r[1] = ld32(0x060452D8u);  // 06045240 mov.l 0x060452D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045242 mov.b @r1,r1
    c.r[11] = ld32(0x060452E8u);  // 06045244 mov.l 0x060452E8,r11
    c.r[0] = c.r[1];  // 06045246 mov r1,r0
    c.r[0] >>= 2;  // 06045248 shlr2 r0
    c.r[0] >>= 2;  // 0604524A shlr2 r0
    c.r[0] >>= 2;  // 0604524C shlr2 r0
    c.r[0] &= 0x1u;  // 0604524E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06045250 tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 8, c.r[11]); if (k) { goto L_0604525A; } }  // 06045252 bt/s 0x0604525A ; mov.l r11,@(8,r14)
    c.r[11] = ld32(0x060452ECu);  // 06045256 mov.l 0x060452EC,r11
    st32(c.r[14] + 8, c.r[11]);  // 06045258 mov.l r11,@(8,r14)
L_0604525A:
    { const bool k = c.t; c.r[1] = 0x6u; if (k) { goto L_06045260; } }  // 0604525A bt/s 0x06045260 ; mov #6,r1
    c.r[1] = 0x16u;  // 0604525E mov #22,r1
L_06045260:
    c.r[2] = c.r[1];  // 06045260 mov r1,r2
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06045268; } }  // 06045262 bt/s 0x06045268 ; mov #0,r5
    c.r[5] = (uint32_t)(int16_t)ld16(0x060452CEu);  // 06045266 mov.w 0x060452CE,r5
L_06045268:
    { const bool k = !c.t; st32(c.r[14] + 12, c.r[5]); if (k) { goto L_060452C2; } }  // 06045268 bf/s 0x060452C2 ; mov.l r5,@(12,r14)
    goto L_060452BC;  // 0604526C bra 0x060452BC ; nop
L_06045270:
    c.r[1] = ld32(0x060452D8u);  // 06045270 mov.l 0x060452D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045272 mov.b @r1,r1
    c.r[2] = ld32(0x060452DCu);  // 06045274 mov.l 0x060452DC,r2
    c.r[0] = c.r[1];  // 06045276 mov r1,r0
    c.r[0] >>= 2;  // 06045278 shlr2 r0
    c.r[0] >>= 2;  // 0604527A shlr2 r0
    c.r[0] >>= 2;  // 0604527C shlr2 r0
    c.r[0] &= 0x1u;  // 0604527E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06045280 tst r0,r0
    if (c.t) { goto L_0604528A; }  // 06045282 bt 0x0604528A
    c.r[1] = ld32(0x060452E4u);  // 06045284 mov.l 0x060452E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0604528E;  // 06045286 bra 0x0604528E ; mov.b @r1,r1
L_0604528A:
    c.r[1] = ld32(0x060452E0u);  // 0604528A mov.l 0x060452E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604528C mov.b @r1,r1
L_0604528E:
    st8(c.r[2], c.r[1]);  // 0604528E mov.b r1,@r2
    c.r[1] = ld32(0x060452D8u);  // 06045290 mov.l 0x060452D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045292 mov.b @r1,r1
    c.r[11] = ld32(0x060452ECu);  // 06045294 mov.l 0x060452EC,r11
    c.r[0] = c.r[1];  // 06045296 mov r1,r0
    c.r[0] >>= 2;  // 06045298 shlr2 r0
    c.r[0] >>= 2;  // 0604529A shlr2 r0
    c.r[0] >>= 2;  // 0604529C shlr2 r0
    c.r[0] &= 0x1u;  // 0604529E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060452A0 tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 8, c.r[11]); if (k) { goto L_060452AA; } }  // 060452A2 bt/s 0x060452AA ; mov.l r11,@(8,r14)
    c.r[11] = ld32(0x060452E8u);  // 060452A6 mov.l 0x060452E8,r11
    st32(c.r[14] + 8, c.r[11]);  // 060452A8 mov.l r11,@(8,r14)
L_060452AA:
    { const bool k = c.t; c.r[1] = 0x16u; if (k) { goto L_060452B0; } }  // 060452AA bt/s 0x060452B0 ; mov #22,r1
    c.r[1] = 0x6u;  // 060452AE mov #6,r1
L_060452B0:
    c.r[2] = c.r[1];  // 060452B0 mov r1,r2
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_060452B8; } }  // 060452B2 bf/s 0x060452B8 ; mov #0,r5
    c.r[5] = (uint32_t)(int16_t)ld16(0x060452CEu);  // 060452B6 mov.w 0x060452CE,r5
L_060452B8:
    { const bool k = c.t; st32(c.r[14] + 12, c.r[5]); if (k) { goto L_060452C2; } }  // 060452B8 bt/s 0x060452C2 ; mov.l r5,@(12,r14)
L_060452BC:
    c.r[1] = ld32(0x060452F0u);  // 060452BC mov.l 0x060452F0,r1
    c.r[3] = ld32(c.r[1]); goto L_06045328;  // 060452BE bra 0x06045328 ; mov.l @r1,r3
L_060452C2:
    c.r[1] = ld32(0x060452F4u);  // 060452C2 mov.l 0x060452F4,r1
    c.r[3] = ld32(c.r[1]); goto L_06045328;  // 060452C4 bra 0x06045328 ; mov.l @r1,r3
L_060452F8:
    c.r[1] = ld32(0x060453C8u);  // 060452F8 mov.l 0x060453C8,r1
    c.r[1] = ld32(c.r[1]);  // 060452FA mov.l @r1,r1
    c.r[1] += 1;  // 060452FC add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060452FE mov.b @r1,r0
    c.r[2] = ld32(0x060453CCu);  // 06045300 mov.l 0x060453CC,r2
    c.r[0] &= 0xBFu;  // 06045302 and #191,r0
    st8(c.r[2], c.r[0]);  // 06045304 mov.b r0,@r2
    c.r[1] = ld32(0x060453D0u);  // 06045306 mov.l 0x060453D0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045308 mov.b @r1,r1
    c.r[11] = ld32(0x060453D4u);  // 0604530A mov.l 0x060453D4,r11
    c.r[0] = c.r[1];  // 0604530C mov r1,r0
    c.r[0] >>= 2;  // 0604530E shlr2 r0
    c.r[0] >>= 2;  // 06045310 shlr2 r0
    c.r[0] >>= 2;  // 06045312 shlr2 r0
    c.r[0] &= 0x1u;  // 06045314 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06045316 tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 8, c.r[11]); if (k) { goto L_06045320; } }  // 06045318 bt/s 0x06045320 ; mov.l r11,@(8,r14)
    c.r[11] = ld32(0x060453D8u);  // 0604531C mov.l 0x060453D8,r11
    st32(c.r[14] + 8, c.r[11]);  // 0604531E mov.l r11,@(8,r14)
L_06045320:
    c.r[2] = 0x0u;  // 06045320 mov #0,r2
    c.r[11] = 0x0u;  // 06045322 mov #0,r11
    st32(c.r[14] + 12, c.r[11]);  // 06045324 mov.l r11,@(12,r14)
    c.r[3] = 0x0u;  // 06045326 mov #0,r3
L_06045328:
    c.r[12] = 0x0u;  // 06045328 mov #0,r12
    c.r[13] = 0x3u;  // 0604532A mov #3,r13
    c.r[11] = 0x40u;  // 0604532C mov #64,r11
    st32(c.r[14] + 20, c.r[11]);  // 0604532E mov.l r11,@(20,r14)
    c.r[10] = c.r[2];  // 06045330 mov r2,r10
L_06045332:
    c.r[8] = 0x0u;  // 06045332 mov #0,r8
    c.r[9] = ld32(c.r[14] + 20);  // 06045334 mov.l @(20,r14),r9
L_06045336:
    c.r[5] = c.r[10];  // 06045336 mov r10,r5
    c.r[5] += c.r[8];  // 06045338 add r8,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0604533A extu.b r5,r5
    c.r[4] = c.r[9] & 0xFFFFu;  // 0604533C extu.w r9,r4
    c.r[7] = 0x10u;  // 0604533E mov #16,r7
    c.r[6] = 0x0u;  // 06045340 mov #0,r6
    c.r[11] = ld32(0x060453DCu);  // 06045342 mov.l 0x060453DC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06045348u; st32(c.r[14] + 16, c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045348u) return; }  // 06045344 jsr @r11 ; mov.l r3,@(16,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060453C4u);  // 06045348 mov.w 0x060453C4,r1
    c.r[9] += c.r[1];  // 0604534A add r1,r9
    c.r[8] += 1;  // 0604534C add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[13];  // 0604534E cmp/gt r13,r8
    { const bool k = !c.t; c.r[3] = ld32(c.r[14] + 16); if (k) { SH2_POLL(c); goto L_06045336; } }  // 06045350 bf/s 0x06045336 ; mov.l @(16,r14),r3
    c.r[11] = ld32(c.r[14] + 20);  // 06045354 mov.l @(20,r14),r11
    c.r[11] += 16;  // 06045356 add #16,r11
    st32(c.r[14] + 20, c.r[11]);  // 06045358 mov.l r11,@(20,r14)
    c.r[12] += 1;  // 0604535A add #1,r12
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 0604535C cmp/gt r13,r12
    { const bool k = !c.t; c.r[10] += 4; if (k) { SH2_POLL(c); goto L_06045332; } }  // 0604535E bf/s 0x06045332 ; add #4,r10
    c.r[8] = 0x0u;  // 06045362 mov #0,r8
    c.r[2] = ld32(0x060453E0u);  // 06045364 mov.l 0x060453E0,r2
    c.r[1] = 0x1u;  // 06045366 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06045368 mov.w r1,@r2
    c.r[1] = ld32(0x060453E4u);  // 0604536A mov.l 0x060453E4,r1
    c.r[11] = ld32(c.r[14] + 8);  // 0604536C mov.l @(8,r14),r11
    c.r[0] = ld32(0x060453E8u);  // 0604536E mov.l 0x060453E8,r0
    c.r[5] = ld32(c.r[1]);  // 06045370 mov.l @r1,r5
    c.r[11] += c.r[3];  // 06045372 add r3,r11
    st32(c.r[14] + 8, c.r[11]);  // 06045374 mov.l r11,@(8,r14)
    c.r[4] = ld32(c.r[14] + 8);  // 06045376 mov.l @(8,r14),r4
    { const uint32_t x = c.r[0]; c.pr = 0x0604537Cu; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604537Cu) return; }  // 06045378 jsr @r0 ; mov r14,r6
    c.r[7] = ld32(0x060453ECu);  // 0604537C mov.l 0x060453EC,r7
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604537E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045380 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045382 mov.l r8,@-r15
    c.r[9] = ld32(0x060453F0u);  // 06045384 mov.l 0x060453F0,r9
    c.r[6] = 0x0u;  // 06045386 mov #0,r6
    c.r[5] = ld32(c.r[14] + 12);  // 06045388 mov.l @(12,r14),r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604538Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604538Eu) return; }  // 0604538A jsr @r9 ; mov #0,r4
    c.r[7] = ld32(0x060453F4u);  // 0604538E mov.l 0x060453F4,r7
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045390 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045392 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045394 mov.l r8,@-r15
    c.r[6] = 0x0u;  // 06045396 mov #0,r6
    c.r[5] = ld32(c.r[14] + 12);  // 06045398 mov.l @(12,r14),r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604539Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604539Eu) return; }  // 0604539A jsr @r9 ; mov #1,r4
    c.r[1] = ld32(0x060453F8u);  // 0604539E mov.l 0x060453F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060453A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060453A4u) return; }  // 060453A0 jsr @r1 ; nop
    c.r[1] = ld32(0x060453FCu);  // 060453A4 mov.l 0x060453FC,r1
    c.r[14] += 24;  // 060453A6 add #24,r14
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060453A8 mov.w @r1,r0
    c.r[15] = c.r[14];  // 060453AA mov r14,r15
    c.r[0] |= 0x1u;  // 060453AC or #1,r0
    st16(c.r[1], c.r[0]);  // 060453AE mov.w r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060453B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060453B2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060453B4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060453B6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060453B8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060453BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060453BC mov.l @r15+,r9
    c.r[0] = ld32(0x06045400u);  // 060453BE mov.l 0x06045400,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060453C0 rts ; mov.l @r15+,r8
}

void f_06045404(SH2Context& c) {
    ran[1117] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045404 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06045406 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06045408 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604540A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604540C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604540E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045410 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06045412 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060455C6u);  // 06045414 mov.w 0x060455C6,r3
    c.r[15] += c.r[3];  // 06045416 add r3,r15
    c.r[14] = c.r[15];  // 06045418 mov r15,r14
    c.r[11] = ld32(0x060455DCu);  // 0604541A mov.l 0x060455DC,r11
    c.r[1] = c.r[11];  // 0604541C mov r11,r1
    c.r[1] += 88;  // 0604541E add #88,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x060455C8u);  // 06045420 mov.w 0x060455C8,r9
    c.r[6] = c.r[14];  // 06045422 mov r14,r6
    c.r[6] += c.r[9];  // 06045424 add r9,r6
    c.r[0] = c.r[14];  // 06045426 mov r14,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060455CAu);  // 06045428 mov.w 0x060455CA,r10
    c.r[3] = 0x0u;  // 0604542A mov #0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604542C mov.w @r1,r1
    c.r[2] = c.r[11];  // 0604542E mov r11,r2
    st16(c.r[0] + c.r[9], c.r[1]);  // 06045430 mov.w r1,@(r0,r9)
    st8(c.r[0] + c.r[10], c.r[3]);  // 06045432 mov.b r3,@(r0,r10)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06045434 mov.w @(r0,r9),r1
    c.r[2] += 40;  // 06045436 add #40,r2
    st16(c.r[2], c.r[1]);  // 06045438 mov.w r1,@r2
    c.r[1] = ld32(0x060455E0u);  // 0604543A mov.l 0x060455E0,r1
    c.r[5] = ld32(c.r[1]);  // 0604543C mov.l @r1,r5
    c.r[7] = c.r[14];  // 0604543E mov r14,r7
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045440 mov.l r14,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06045442 mov.w @(r0,r9),r1
    c.r[7] += c.r[10];  // 06045444 add r10,r7
    c.r[2] = ld32(c.r[11] + 16);  // 06045446 mov.l @(16,r11),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045448 extu.w r1,r1
    c.r[1] <<= 2;  // 0604544A shll2 r1
    c.r[2] += c.r[1];  // 0604544C add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0604544E mov.l r2,@-r15
    c.r[1] = ld32(c.r[11] + 8);  // 06045450 mov.l @(8,r11),r1
    c.r[4] = ld32(0x060455E4u);  // 06045452 mov.l 0x060455E4,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045454 mov.l r1,@-r15
    c.r[1] = ld32(c.r[11] + 4);  // 06045456 mov.l @(4,r11),r1
    c.r[8] = 0x4u;  // 06045458 mov #4,r8
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604545A mov.l r1,@-r15
    c.r[1] = ld32(c.r[11]);  // 0604545C mov.l @r11,r1
    c.r[13] = ld32(0x060455E8u);  // 0604545E mov.l 0x060455E8,r13
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045460 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045462 mov.l r8,@-r15
    c.r[1] = ld32(0x060455ECu);  // 06045464 mov.l 0x060455EC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045466 mov.l r1,@-r15
    { const uint32_t x = c.r[13]; c.pr = 0x0604546Cu; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604546Cu) return; }  // 06045468 jsr @r13 ; mov.l r3,@-r15
    c.r[0] = c.r[14];  // 0604546C mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0604546E mov.b @(r0,r10),r1
    c.r[6] = c.r[1] & 0xFFu;  // 06045470 extu.b r1,r6
    c.t = c.r[6] > c.r[8];  // 06045472 cmp/hi r8,r6
    { const bool k = !c.t; c.r[15] += 32; if (k) { goto L_0604547C; } }  // 06045474 bf/s 0x0604547C ; add #32,r15
    goto L_06045846;  // 06045478 bra 0x06045846 ; nop
L_0604547C:
    c.r[5] = c.r[14];  // 0604547C mov r14,r5
    c.r[13] = ld32(0x060455F0u);  // 0604547E mov.l 0x060455F0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06045484u; c.r[4] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045484u) return; }  // 06045480 jsr @r13 ; mov #58,r4
    c.r[0] = c.r[14];  // 06045484 mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06045486 mov.w @(r0,r9),r1
    c.r[7] = 0x0u;  // 06045488 mov #0,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604548A extu.w r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 0604548C cmp/ge r1,r7
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_060454BC; } }  // 0604548E bt/s 0x060454BC ; mov r11,r2
    c.r[5] = c.r[9];  // 06045492 mov r9,r5
    c.r[6] = 0x0u;  // 06045494 mov #0,r6
L_06045496:
    c.r[1] = ld32(c.r[2] + 8);  // 06045496 mov.l @(8,r2),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x060455CCu);  // 06045498 mov.w 0x060455CC,r13
    c.r[3] = ld32(c.r[2] + 20);  // 0604549A mov.l @(20,r2),r3
    c.r[1] += c.r[6];  // 0604549C add r6,r1
    c.r[1] += 4;  // 0604549E add #4,r1
    c.r[0] = c.r[3];  // 060454A0 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060454A2 mov.w @r1,r1
    c.r[1] &= c.r[13];  // 060454A4 and r13,r1
    c.r[1] >>= 2;  // 060454A6 shlr2 r1
    c.r[1] >>= 2;  // 060454A8 shlr2 r1
    c.r[1] += 58;  // 060454AA add #58,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 060454AC mov.b r1,@(r0,r7)
    c.r[0] = c.r[14];  // 060454AE mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060454B0 mov.w @(r0,r5),r1
    c.r[7] += 1;  // 060454B2 add #1,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 060454B4 extu.w r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 060454B6 cmp/ge r1,r7
    { const bool k = !c.t; c.r[6] += 10; if (k) { SH2_POLL(c); goto L_06045496; } }  // 060454B8 bf/s 0x06045496 ; add #10,r6
L_060454BC:
    c.r[13] = ld32(0x060455F4u);  // 060454BC mov.l 0x060455F4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060454C2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060454C2u) return; }  // 060454BE jsr @r13 ; mov #1,r4
    c.r[7] = c.r[0];  // 060454C2 mov r0,r7
    c.r[2] = c.r[7];  // 060454C4 mov r7,r2
    c.r[2] += 56;  // 060454C6 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060455CEu);  // 060454C8 mov.w 0x060455CE,r1
    st16(c.r[2], c.r[1]);  // 060454CA mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060455D0u);  // 060454CC mov.w 0x060455D0,r1
    st32(c.r[7] + 4, c.r[1]);  // 060454CE mov.l r1,@(4,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060455D2u);  // 060454D0 mov.w 0x060455D2,r1
    st32(c.r[7] + 8, c.r[1]);  // 060454D2 mov.l r1,@(8,r7)
    c.r[2] = ld32(0x060455F8u);  // 060454D4 mov.l 0x060455F8,r2
    c.r[0] = 0x1u;  // 060454D6 mov #1,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060455D4u);  // 060454D8 mov.w 0x060455D4,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060454DA mov.b @r2,r1
    c.r[5] = ld32(0x060455FCu);  // 060454DC mov.l 0x060455FC,r5
    c.r[1] = c.r[1] & 0xFFu;  // 060454DE extu.b r1,r1
    c.r[3] = c.r[1];  // 060454E0 mov r1,r3
    c.r[3] >>= 2;  // 060454E2 shlr2 r3
    c.r[3] >>= 2;  // 060454E4 shlr2 r3
    c.r[3] >>= 2;  // 060454E6 shlr2 r3
    c.r[1] >>= 2;  // 060454E8 shlr2 r1
    c.r[1] >>= 2;  // 060454EA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060454EC shlr r1
    c.r[1] >>= 2;  // 060454EE shlr2 r1
    c.r[3] &= c.r[0];  // 060454F0 and r0,r3
    c.t = c.r[1] == c.r[3];  // 060454F2 cmp/eq r3,r1
    c.r[6] = c.t;  // 060454F4 movt r6
    c.r[1] = c.r[7];  // 060454F6 mov r7,r1
    c.r[1] += 2;  // 060454F8 add #2,r1
    c.r[6] ^= c.r[0];  // 060454FA xor r0,r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060454FC mov.b @r1,r3
    c.r[6] += c.r[6];  // 060454FE add r6,r6
    c.r[3] &= c.r[13];  // 06045500 and r13,r3
    c.r[3] |= c.r[6];  // 06045502 or r6,r3
    st8(c.r[1], c.r[3]);  // 06045504 mov.b r3,@r1
    c.r[1] = c.r[7];  // 06045506 mov r7,r1
    c.r[1] += 1;  // 06045508 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604550A mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060455D6u);  // 0604550C mov.w 0x060455D6,r0
    c.r[3] |= c.r[0];  // 0604550E or r0,r3
    st8(c.r[1], c.r[3]);  // 06045510 mov.b r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06045512 mov.b @r2,r1
    c.r[13] = 0x1u;  // 06045514 mov #1,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06045516 extu.b r1,r1
    c.r[2] = c.r[1];  // 06045518 mov r1,r2
    c.r[2] >>= 2;  // 0604551A shlr2 r2
    c.r[2] >>= 2;  // 0604551C shlr2 r2
    c.r[2] >>= 2;  // 0604551E shlr2 r2
    c.r[1] >>= 2;  // 06045520 shlr2 r1
    c.r[1] >>= 2;  // 06045522 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06045524 shlr r1
    c.r[1] >>= 2;  // 06045526 shlr2 r1
    c.r[2] &= c.r[13];  // 06045528 and r13,r2
    c.t = c.r[1] == c.r[2];  // 0604552A cmp/eq r2,r1
    if (c.t) { goto L_06045530; }  // 0604552C bt 0x06045530
    c.r[5] = ld32(0x06045600u);  // 0604552E mov.l 0x06045600,r5
L_06045530:
    c.r[1] = ld32(0x06045604u);  // 06045530 mov.l 0x06045604,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045536u; c.r[4] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045536u) return; }  // 06045532 jsr @r1 ; mov r7,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x060455D6u);  // 06045536 mov.w 0x060455D6,r4
    c.r[8] = ld32(0x06045608u);  // 06045538 mov.l 0x06045608,r8
    c.r[7] = 0x10u;  // 0604553A mov #16,r7
    c.r[6] = 0x0u;  // 0604553C mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06045542u; c.r[5] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045542u) return; }  // 0604553E jsr @r8 ; mov #58,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060455D8u);  // 06045542 mov.w 0x060455D8,r4
    c.r[7] = 0x10u;  // 06045544 mov #16,r7
    c.r[6] = 0x0u;  // 06045546 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0604554Cu; c.r[5] = 0x3Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604554Cu) return; }  // 06045548 jsr @r8 ; mov #59,r5
    c.r[10] = (uint32_t)(int16_t)ld16(0x060455CAu);  // 0604554C mov.w 0x060455CA,r10
    c.r[7] = c.r[14];  // 0604554E mov r14,r7
    c.r[7] += c.r[10];  // 06045550 add r10,r7
    c.r[1] = 0x0u;  // 06045552 mov #0,r1
    c.r[0] = c.r[14];  // 06045554 mov r14,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 06045556 mov.b r1,@(r0,r10)
    c.r[11] = ld32(0x060455DCu);  // 06045558 mov.l 0x060455DC,r11
    c.r[12] = c.r[11];  // 0604555A mov r11,r12
    c.r[12] += 42;  // 0604555C add #42,r12
    c.r[9] = (uint32_t)(int16_t)ld16(0x060455C8u);  // 0604555E mov.w 0x060455C8,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06045560 mov.w @(r0,r9),r1
    c.r[6] = c.r[14];  // 06045562 mov r14,r6
    st16(c.r[12], c.r[1]);  // 06045564 mov.w r1,@r12
    c.r[1] = ld32(0x060455E0u);  // 06045566 mov.l 0x060455E0,r1
    c.r[5] = ld32(c.r[1]);  // 06045568 mov.l @r1,r5
    c.r[6] += c.r[9];  // 0604556A add r9,r6
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604556C mov.l r14,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0604556E mov.w @(r0,r9),r3
    c.r[4] = ld32(0x0604560Cu);  // 06045570 mov.l 0x0604560C,r4
    c.r[1] = ld32(c.r[11] + 16);  // 06045572 mov.l @(16,r11),r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06045574 extu.w r3,r2
    c.r[2] <<= 2;  // 06045576 shll2 r2
    c.r[1] += c.r[2];  // 06045578 add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604557A mov.l r1,@-r15
    c.r[1] = 0xAu;  // 0604557C mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604557E mulu.w r1,r3
    c.r[2] = ld32(c.r[11] + 8);  // 06045580 mov.l @(8,r11),r2
    c.r[1] = c.macl;  // 06045582 sts macl,r1
    c.r[2] += c.r[1];  // 06045584 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06045586 mov.l r2,@-r15
    c.r[1] = ld32(c.r[11] + 4);  // 06045588 mov.l @(4,r11),r1
    c.r[8] = 0x4u;  // 0604558A mov #4,r8
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604558C mov.l r1,@-r15
    c.r[1] = ld32(c.r[11]);  // 0604558E mov.l @r11,r1
    c.r[13] = ld32(0x060455E8u);  // 06045590 mov.l 0x060455E8,r13
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045592 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045594 mov.l r8,@-r15
    c.r[1] = ld32(0x060455ECu);  // 06045596 mov.l 0x060455EC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045598 mov.l r1,@-r15
    c.r[1] = 0x0u;  // 0604559A mov #0,r1
    { const uint32_t x = c.r[13]; c.pr = 0x060455A0u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060455A0u) return; }  // 0604559C jsr @r13 ; mov.l r1,@-r15
    c.r[0] = c.r[14];  // 060455A0 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060455A2 mov.b @(r0,r10),r1
    c.r[6] = c.r[1] & 0xFFu;  // 060455A4 extu.b r1,r6
    c.t = c.r[6] > c.r[8];  // 060455A6 cmp/hi r8,r6
    { const bool k = !c.t; c.r[15] += 32; if (k) { goto L_060455B0; } }  // 060455A8 bf/s 0x060455B0 ; add #32,r15
    goto L_06045846;  // 060455AC bra 0x06045846 ; nop
L_060455B0:
    c.r[5] = c.r[14];  // 060455B0 mov r14,r5
    c.r[13] = ld32(0x060455F0u);  // 060455B2 mov.l 0x060455F0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060455B8u; c.r[4] = 0x3Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060455B8u) return; }  // 060455B4 jsr @r13 ; mov #62,r4
    c.r[0] = c.r[14];  // 060455B8 mov r14,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 060455BA mov.w @(r0,r9),r2
    c.r[7] = 0x0u;  // 060455BC mov #0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[12]);  // 060455BE mov.w @r12,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060455C0 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu; goto L_06045610;  // 060455C2 bra 0x06045610 ; extu.w r1,r1
L_06045610:
    c.r[2] -= c.r[1];  // 06045610 sub r1,r2
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06045612 cmp/ge r2,r7
    { const bool k = c.t; c.r[5] = c.r[11]; if (k) { goto L_06045658; } }  // 06045614 bt/s 0x06045658 ; mov r11,r5
    c.r[8] = c.r[5];  // 06045618 mov r5,r8
    c.r[8] += 88;  // 0604561A add #88,r8
    c.r[4] = c.r[12];  // 0604561C mov r12,r4
L_0604561E:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604561E mov.w @r8,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x060457CEu);  // 06045620 mov.w 0x060457CE,r13
    c.r[6] = ld32(c.r[5] + 20);  // 06045622 mov.l @(20,r5),r6
    c.r[3] = c.r[1] & 0xFFFFu;  // 06045624 extu.w r1,r3
    c.r[3] += c.r[7];  // 06045626 add r7,r3
    c.r[2] = c.r[3];  // 06045628 mov r3,r2
    c.r[2] <<= 2;  // 0604562A shll2 r2
    c.r[2] += c.r[3];  // 0604562C add r3,r2
    c.r[1] = ld32(c.r[5] + 8);  // 0604562E mov.l @(8,r5),r1
    c.r[2] += c.r[2];  // 06045630 add r2,r2
    c.r[2] += c.r[1];  // 06045632 add r1,r2
    c.r[2] += 4;  // 06045634 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06045636 mov.w @r2,r1
    c.r[0] = c.r[6];  // 06045638 mov r6,r0
    c.r[1] &= c.r[13];  // 0604563A and r13,r1
    c.r[1] >>= 2;  // 0604563C shlr2 r1
    c.r[1] >>= 2;  // 0604563E shlr2 r1
    c.r[1] += 62;  // 06045640 add #62,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06045642 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060457D0u);  // 06045644 mov.w 0x060457D0,r1
    c.r[0] = c.r[14];  // 06045646 mov r14,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06045648 mov.w @(r0,r1),r2
    c.r[7] += 1;  // 0604564A add #1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604564C mov.w @r4,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0604564E extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045650 extu.w r1,r1
    c.r[2] -= c.r[1];  // 06045652 sub r1,r2
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06045654 cmp/ge r2,r7
    if (!c.t) { SH2_POLL(c); goto L_0604561E; }  // 06045656 bf 0x0604561E
L_06045658:
    c.r[13] = ld32(0x060457E4u);  // 06045658 mov.l 0x060457E4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0604565Eu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604565Eu) return; }  // 0604565A jsr @r13 ; mov #4,r4
    c.r[7] = c.r[0];  // 0604565E mov r0,r7
    c.r[2] = c.r[7];  // 06045660 mov r7,r2
    c.r[2] += 56;  // 06045662 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060457D2u);  // 06045664 mov.w 0x060457D2,r1
    st16(c.r[2], c.r[1]);  // 06045666 mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060457D4u);  // 06045668 mov.w 0x060457D4,r1
    st32(c.r[7] + 4, c.r[1]);  // 0604566A mov.l r1,@(4,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060457D6u);  // 0604566C mov.w 0x060457D6,r1
    st32(c.r[7] + 8, c.r[1]);  // 0604566E mov.l r1,@(8,r7)
    c.r[3] = ld32(0x060457E8u);  // 06045670 mov.l 0x060457E8,r3
    c.r[0] = 0x1u;  // 06045672 mov #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06045674 mov.b @r3,r1
    c.r[5] = ld32(0x060457ECu);  // 06045676 mov.l 0x060457EC,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06045678 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604567A mov r1,r2
    c.r[2] >>= 2;  // 0604567C shlr2 r2
    c.r[2] >>= 2;  // 0604567E shlr2 r2
    c.r[2] >>= 2;  // 06045680 shlr2 r2
    c.r[1] >>= 2;  // 06045682 shlr2 r1
    c.r[1] >>= 2;  // 06045684 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06045686 shlr r1
    c.r[1] >>= 2;  // 06045688 shlr2 r1
    c.r[2] &= c.r[0];  // 0604568A and r0,r2
    c.t = c.r[1] == c.r[2];  // 0604568C cmp/eq r2,r1
    c.r[13] = c.t;  // 0604568E movt r13
    c.r[1] = c.r[13];  // 06045690 mov r13,r1
    c.r[2] = c.r[7];  // 06045692 mov r7,r2
    c.r[2] += 2;  // 06045694 add #2,r2
    c.r[1] += c.r[1];  // 06045696 add r1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06045698 mov.b @r2,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x060457D8u);  // 0604569A mov.w 0x060457D8,r0
    c.r[6] &= c.r[0];  // 0604569C and r0,r6
    c.r[6] |= c.r[1];  // 0604569E or r1,r6
    st8(c.r[2], c.r[6]);  // 060456A0 mov.b r6,@r2
    c.r[1] = c.r[7];  // 060456A2 mov r7,r1
    c.r[1] += 1;  // 060456A4 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060456A6 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x060457DAu);  // 060456A8 mov.w 0x060457DA,r13
    c.r[2] |= c.r[13];  // 060456AA or r13,r2
    st8(c.r[1], c.r[2]);  // 060456AC mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060456AE mov.b @r3,r1
    c.r[0] = 0x1u;  // 060456B0 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060456B2 extu.b r1,r1
    c.r[2] = c.r[1];  // 060456B4 mov r1,r2
    c.r[2] >>= 2;  // 060456B6 shlr2 r2
    c.r[2] >>= 2;  // 060456B8 shlr2 r2
    c.r[2] >>= 2;  // 060456BA shlr2 r2
    c.r[1] >>= 2;  // 060456BC shlr2 r1
    c.r[1] >>= 2;  // 060456BE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060456C0 shlr r1
    c.r[1] >>= 2;  // 060456C2 shlr2 r1
    c.r[2] &= c.r[0];  // 060456C4 and r0,r2
    c.t = c.r[1] == c.r[2];  // 060456C6 cmp/eq r2,r1
    if (c.t) { goto L_060456CC; }  // 060456C8 bt 0x060456CC
    c.r[5] = ld32(0x060457F0u);  // 060456CA mov.l 0x060457F0,r5
L_060456CC:
    c.r[1] = ld32(0x060457F4u);  // 060456CC mov.l 0x060457F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060456D2u; c.r[4] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060456D2u) return; }  // 060456CE jsr @r1 ; mov r7,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x060457DCu);  // 060456D2 mov.w 0x060457DC,r4
    c.r[8] = ld32(0x060457F8u);  // 060456D4 mov.l 0x060457F8,r8
    c.r[7] = 0x10u;  // 060456D6 mov #16,r7
    c.r[6] = 0x0u;  // 060456D8 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060456DEu; c.r[5] = 0x3Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060456DEu) return; }  // 060456DA jsr @r8 ; mov #62,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060457DEu);  // 060456DE mov.w 0x060457DE,r4
    c.r[7] = 0x10u;  // 060456E0 mov #16,r7
    c.r[6] = 0x0u;  // 060456E2 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060456E8u; c.r[5] = 0x3Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060456E8u) return; }  // 060456E4 jsr @r8 ; mov #63,r5
    c.r[2] = ld32(0x060457FCu);  // 060456E8 mov.l 0x060457FC,r2
    c.r[1] = 0x1u;  // 060456EA mov #1,r1
    st16(c.r[2], c.r[1]);  // 060456EC mov.w r1,@r2
    c.r[1] = ld32(0x06045800u);  // 060456EE mov.l 0x06045800,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060456F0 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060456F2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060456F4 tst r1,r1
    if (c.t) { goto L_06045772; }  // 060456F6 bt 0x06045772
    c.r[7] = c.r[14];  // 060456F8 mov r14,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x060457E0u);  // 060456FA mov.w 0x060457E0,r9
    c.r[7] += c.r[9];  // 060456FC add r9,r7
    c.r[1] = 0x0u;  // 060456FE mov #0,r1
    c.r[0] = c.r[14];  // 06045700 mov r14,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06045702 mov.b r1,@(r0,r9)
    c.r[3] = ld32(0x06045804u);  // 06045704 mov.l 0x06045804,r3
    c.r[2] = c.r[3];  // 06045706 mov r3,r2
    c.r[2] += 44;  // 06045708 add #44,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x060457D0u);  // 0604570A mov.w 0x060457D0,r8
    c.r[6] = c.r[14];  // 0604570C mov r14,r6
    c.r[6] += c.r[8];  // 0604570E add r8,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06045710 mov.w @(r0,r8),r1
    c.r[4] = ld32(0x06045808u);  // 06045712 mov.l 0x06045808,r4
    st16(c.r[2], c.r[1]);  // 06045714 mov.w r1,@r2
    c.r[1] = ld32(0x0604580Cu);  // 06045716 mov.l 0x0604580C,r1
    c.r[5] = ld32(c.r[1]);  // 06045718 mov.l @r1,r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x060457E2u);  // 0604571A mov.w 0x060457E2,r13
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604571C mov.l r14,@-r15
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0604571E mov.w @(r0,r8),r8
    c.r[13] += c.r[14];  // 06045720 add r14,r13
    st16(c.r[13], c.r[8]);  // 06045722 mov.w r8,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060457E2u);  // 06045724 mov.w 0x060457E2,r0
    c.r[0] += c.r[14];  // 06045726 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060457E2u);  // 06045728 mov.w 0x060457E2,r13
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604572A mov.w @r0,r0
    c.r[13] += c.r[14];  // 0604572C add r14,r13
    c.r[1] = ld32(c.r[3] + 16);  // 0604572E mov.l @(16,r3),r1
    c.r[2] = c.r[0] & 0xFFFFu;  // 06045730 extu.w r0,r2
    c.r[2] <<= 2;  // 06045732 shll2 r2
    c.r[1] += c.r[2];  // 06045734 add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045736 mov.l r1,@-r15
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[13]);  // 06045738 mov.w @r13,r13
    c.r[1] = 0xAu;  // 0604573A mov #10,r1
    c.macl = (c.r[13] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0604573C mulu.w r1,r13
    c.r[2] = ld32(c.r[3] + 8);  // 0604573E mov.l @(8,r3),r2
    c.r[1] = c.macl;  // 06045740 sts macl,r1
    c.r[2] += c.r[1];  // 06045742 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06045744 mov.l r2,@-r15
    c.r[1] = ld32(c.r[3] + 4);  // 06045746 mov.l @(4,r3),r1
    c.r[8] = 0x4u;  // 06045748 mov #4,r8
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604574A mov.l r1,@-r15
    c.r[1] = ld32(c.r[3]);  // 0604574C mov.l @r3,r1
    c.r[0] = ld32(0x06045810u);  // 0604574E mov.l 0x06045810,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045750 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045752 mov.l r8,@-r15
    c.r[1] = ld32(0x06045814u);  // 06045754 mov.l 0x06045814,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045756 mov.l r1,@-r15
    c.r[1] = 0x0u;  // 06045758 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0604575Eu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604575Eu) return; }  // 0604575A jsr @r0 ; mov.l r1,@-r15
    c.r[0] = c.r[14];  // 0604575E mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06045760 mov.b @(r0,r9),r1
    c.r[6] = c.r[1] & 0xFFu;  // 06045762 extu.b r1,r6
    c.t = c.r[6] > c.r[8];  // 06045764 cmp/hi r8,r6
    { const bool k = c.t; c.r[15] += 32; if (k) { goto L_06045846; } }  // 06045766 bt/s 0x06045846 ; add #32,r15
    c.r[0] = ld32(0x06045818u);  // 0604576A mov.l 0x06045818,r0
    c.r[5] = c.r[14];  // 0604576C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06045772u; c.r[4] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045772u) return; }  // 0604576E jsr @r0 ; mov #66,r4
L_06045772:
    c.r[1] = ld32(0x0604581Cu);  // 06045772 mov.l 0x0604581C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045774 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045776 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06045778 tst r1,r1
    { const bool k = c.t; c.r[7] = c.r[14]; if (k) { goto L_06045852; } }  // 0604577A bt/s 0x06045852 ; mov r14,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x060457E0u);  // 0604577E mov.w 0x060457E0,r9
    c.r[7] += c.r[9];  // 06045780 add r9,r7
    c.r[1] = 0x0u;  // 06045782 mov #0,r1
    c.r[0] = c.r[14];  // 06045784 mov r14,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06045786 mov.b r1,@(r0,r9)
    c.r[3] = ld32(0x06045804u);  // 06045788 mov.l 0x06045804,r3
    c.r[2] = c.r[3];  // 0604578A mov r3,r2
    c.r[2] += 46;  // 0604578C add #46,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x060457D0u);  // 0604578E mov.w 0x060457D0,r8
    c.r[6] = c.r[14];  // 06045790 mov r14,r6
    c.r[6] += c.r[8];  // 06045792 add r8,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06045794 mov.w @(r0,r8),r1
    c.r[4] = ld32(0x06045820u);  // 06045796 mov.l 0x06045820,r4
    st16(c.r[2], c.r[1]);  // 06045798 mov.w r1,@r2
    c.r[1] = ld32(0x0604580Cu);  // 0604579A mov.l 0x0604580C,r1
    c.r[5] = ld32(c.r[1]);  // 0604579C mov.l @r1,r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x060457E2u);  // 0604579E mov.w 0x060457E2,r13
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060457A0 mov.l r14,@-r15
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 060457A2 mov.w @(r0,r8),r8
    c.r[13] += c.r[14];  // 060457A4 add r14,r13
    st16(c.r[13], c.r[8]);  // 060457A6 mov.w r8,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060457E2u);  // 060457A8 mov.w 0x060457E2,r0
    c.r[0] += c.r[14];  // 060457AA add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060457E2u);  // 060457AC mov.w 0x060457E2,r13
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 060457AE mov.w @r0,r0
    c.r[13] += c.r[14];  // 060457B0 add r14,r13
    c.r[1] = ld32(c.r[3] + 16);  // 060457B2 mov.l @(16,r3),r1
    c.r[2] = c.r[0] & 0xFFFFu;  // 060457B4 extu.w r0,r2
    c.r[2] <<= 2;  // 060457B6 shll2 r2
    c.r[1] += c.r[2];  // 060457B8 add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060457BA mov.l r1,@-r15
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[13]);  // 060457BC mov.w @r13,r13
    c.r[1] = 0xAu;  // 060457BE mov #10,r1
    c.macl = (c.r[13] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060457C0 mulu.w r1,r13
    c.r[2] = ld32(c.r[3] + 8);  // 060457C2 mov.l @(8,r3),r2
    c.r[1] = c.macl;  // 060457C4 sts macl,r1
    c.r[2] += c.r[1];  // 060457C6 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060457C8 mov.l r2,@-r15
    c.r[1] = ld32(c.r[3] + 4); goto L_06045824;  // 060457CA bra 0x06045824 ; mov.l @(4,r3),r1
L_06045824:
    c.r[8] = 0x4u;  // 06045824 mov #4,r8
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045826 mov.l r1,@-r15
    c.r[1] = ld32(c.r[3]);  // 06045828 mov.l @r3,r1
    c.r[0] = ld32(0x06045884u);  // 0604582A mov.l 0x06045884,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0604582C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604582E mov.l r8,@-r15
    c.r[1] = ld32(0x06045888u);  // 06045830 mov.l 0x06045888,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045832 mov.l r1,@-r15
    c.r[1] = 0x0u;  // 06045834 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0604583Au; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604583Au) return; }  // 06045836 jsr @r0 ; mov.l r1,@-r15
    c.r[0] = c.r[14];  // 0604583A mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0604583C mov.b @(r0,r9),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0604583E extu.b r1,r6
    c.t = c.r[6] > c.r[8];  // 06045840 cmp/hi r8,r6
    { const bool k = !c.t; c.r[15] += 32; if (k) { goto L_0604584A; } }  // 06045842 bf/s 0x0604584A ; add #32,r15
L_06045846:
    c.r[0] = 0x9u; goto L_06045864;  // 06045846 bra 0x06045864 ; mov #9,r0
L_0604584A:
    c.r[0] = ld32(0x0604588Cu);  // 0604584A mov.l 0x0604588C,r0
    c.r[5] = c.r[14];  // 0604584C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06045852u; c.r[4] = 0x46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045852u) return; }  // 0604584E jsr @r0 ; mov #70,r4
L_06045852:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604587Cu);  // 06045852 mov.w 0x0604587C,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06045854 mov.w @(r0,r14),r2
    c.r[1] = ld32(0x06045890u);  // 06045856 mov.l 0x06045890,r1
    st16(c.r[1], c.r[2]);  // 06045858 mov.w r2,@r1
    c.r[1] = ld32(0x06045894u);  // 0604585A mov.l 0x06045894,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604585C mov.w @r1,r0
    c.r[0] |= 0x4u;  // 0604585E or #4,r0
    st16(c.r[1], c.r[0]);  // 06045860 mov.w r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604587Eu);  // 06045862 mov.w 0x0604587E,r0
L_06045864:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06045880u);  // 06045864 mov.w 0x06045880,r3
    c.r[14] += c.r[3];  // 06045866 add r3,r14
    c.r[15] = c.r[14];  // 06045868 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604586A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604586C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604586E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06045870 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06045872 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06045874 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06045876 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045878 rts ; mov.l @r15+,r8
}

void f_06045898(SH2Context& c) {
    ran[1118] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045898 mov.l r14,@-r15
    c.r[7] = ld32(0x06045900u);  // 0604589A mov.l 0x06045900,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x060458F6u);  // 0604589C mov.w 0x060458F6,r1
    c.r[6] = ld32(c.r[7]);  // 0604589E mov.l @r7,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060458F8u);  // 060458A0 mov.w 0x060458F8,r3
    c.r[6] += c.r[1];  // 060458A2 add r1,r6
    c.r[2] = c.r[6];  // 060458A4 mov r6,r2
    c.r[1] = ld32(0x06045904u);  // 060458A6 mov.l 0x06045904,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060458A8 mov.b @r1,r1
    c.r[2] += 56;  // 060458AA add #56,r2
    c.r[0] = c.r[1];  // 060458AC mov r1,r0
    c.r[0] >>= 2;  // 060458AE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060458B0 shlr r0
    c.r[0] >>= 2;  // 060458B2 shlr2 r0
    c.r[0] &= 0x3u;  // 060458B4 and #3,r0
    c.r[1] = c.r[0];  // 060458B6 mov r0,r1
    c.r[1] += c.r[3];  // 060458B8 add r3,r1
    st16(c.r[2], c.r[1]);  // 060458BA mov.w r1,@r2
    c.r[1] = c.r[6];  // 060458BC mov r6,r1
    c.r[1] += 1;  // 060458BE add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060458C0 mov.b @r1,r0
    c.r[14] = c.r[15];  // 060458C2 mov r15,r14
    c.r[0] &= 0xBFu;  // 060458C4 and #191,r0
    st8(c.r[1], c.r[0]);  // 060458C6 mov.b r0,@r1
    c.r[6] = ld32(c.r[7]);  // 060458C8 mov.l @r7,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060458FAu);  // 060458CA mov.w 0x060458FA,r1
    c.r[6] += c.r[1];  // 060458CC add r1,r6
    c.r[2] = c.r[6];  // 060458CE mov r6,r2
    c.r[1] = ld32(0x06045908u);  // 060458D0 mov.l 0x06045908,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060458D2 mov.b @r1,r1
    c.r[2] += 56;  // 060458D4 add #56,r2
    c.r[0] = c.r[1];  // 060458D6 mov r1,r0
    c.r[0] >>= 2;  // 060458D8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060458DA shlr r0
    c.r[0] >>= 2;  // 060458DC shlr2 r0
    c.r[0] &= 0x3u;  // 060458DE and #3,r0
    c.r[1] = c.r[0];  // 060458E0 mov r0,r1
    c.r[1] += c.r[3];  // 060458E2 add r3,r1
    st16(c.r[2], c.r[1]);  // 060458E4 mov.w r1,@r2
    c.r[1] = c.r[6];  // 060458E6 mov r6,r1
    c.r[1] += 1;  // 060458E8 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060458EA mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 060458EC and #191,r0
    st8(c.r[1], c.r[0]);  // 060458EE mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060458FCu);  // 060458F0 mov.w 0x060458FC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060458F2 rts ; mov.l @r15+,r14
}

void f_0604590C(SH2Context& c) {
    ran[1119] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604590C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604590E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06045910 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045912 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06045914 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06045916 mov r15,r14
    c.r[8] = 0x0u;  // 06045918 mov #0,r8
    c.r[10] = ld32(0x060459BCu);  // 0604591A mov.l 0x060459BC,r10
    c.r[9] = 0xFu;  // 0604591C mov #15,r9
L_0604591E:
    { const uint32_t x = c.r[10]; c.pr = 0x06045922u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045922u) return; }  // 0604591E jsr @r10 ; mov r8,r4
    c.r[8] += 1;  // 06045922 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06045924 cmp/gt r9,r8
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_0604591E; } }  // 06045926 bf/s 0x0604591E ; mov #0,r3
    c.r[1] = ld32(0x060459C0u);  // 0604592A mov.l 0x060459C0,r1
    st8(c.r[1], c.r[3]);  // 0604592C mov.b r3,@r1
    c.r[1] = ld32(0x060459C4u);  // 0604592E mov.l 0x060459C4,r1
    st8(c.r[1], c.r[3]);  // 06045930 mov.b r3,@r1
    c.r[1] = ld32(0x060459C8u);  // 06045932 mov.l 0x060459C8,r1
    c.r[2] = 0x0u;  // 06045934 mov #0,r2
    st16(c.r[1], c.r[2]);  // 06045936 mov.w r2,@r1
    c.r[1] = ld32(0x060459CCu);  // 06045938 mov.l 0x060459CC,r1
    st16(c.r[1], c.r[2]);  // 0604593A mov.w r2,@r1
    c.r[1] = ld32(0x060459D0u);  // 0604593C mov.l 0x060459D0,r1
    st16(c.r[1], c.r[2]);  // 0604593E mov.w r2,@r1
    c.r[1] = ld32(0x060459D4u);  // 06045940 mov.l 0x060459D4,r1
    st8(c.r[1], c.r[3]);  // 06045942 mov.b r3,@r1
    c.r[1] = ld32(0x060459D8u);  // 06045944 mov.l 0x060459D8,r1
    st8(c.r[1], c.r[3]);  // 06045946 mov.b r3,@r1
    c.r[1] = ld32(0x060459DCu);  // 06045948 mov.l 0x060459DC,r1
    st16(c.r[1], c.r[2]);  // 0604594A mov.w r2,@r1
    c.r[6] = ld32(0x060459E0u);  // 0604594C mov.l 0x060459E0,r6
    c.r[1] = ld32(0x060459E4u);  // 0604594E mov.l 0x060459E4,r1
    c.r[5] = 0x0u;  // 06045950 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06045956u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045956u) return; }  // 06045952 jsr @r1 ; mov #0,r4
    c.r[6] = ld32(0x060459E8u);  // 06045956 mov.l 0x060459E8,r6
    c.r[7] = c.r[6];  // 06045958 mov r6,r7
    c.r[7] += 68;  // 0604595A add #68,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604595C mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0604595E extu.b r1,r3
    c.r[2] = c.r[3];  // 06045960 mov r3,r2
    c.r[2] += 1;  // 06045962 add #1,r2
    c.r[1] = 0x10u;  // 06045964 mov #16,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06045966 cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_060459AE; } }  // 06045968 bt/s 0x060459AE ; mov #1,r0
    c.r[3] <<= 2;  // 0604596C shll2 r3
    c.r[1] = ld32(c.r[6]);  // 0604596E mov.l @r6,r1
    c.r[3] += c.r[6];  // 06045970 add r6,r3
    c.r[1] += 1;  // 06045972 add #1,r1
    st32(c.r[3] + 4, c.r[1]);  // 06045974 mov.l r1,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06045976 mov.b @r7,r1
    c.r[1] += 1;  // 06045978 add #1,r1
    st8(c.r[7], c.r[1]);  // 0604597A mov.b r1,@r7
    c.r[1] = ld32(0x060459ECu);  // 0604597C mov.l 0x060459EC,r1
    c.r[2] = ld32(c.r[1]);  // 0604597E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06045980 mov r2,r1
    c.r[1] += 3;  // 06045982 add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045984 mov.b @r1,r3
    c.r[1] = c.r[2];  // 06045986 mov r2,r1
    c.r[1] += 2;  // 06045988 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604598A mov.b @r1,r1
    c.r[3] <<= 16;  // 0604598C shll16 r3
    c.r[3] <<= 8;  // 0604598E shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06045990 extu.b r1,r1
    c.r[1] <<= 16;  // 06045992 shll16 r1
    c.r[3] |= c.r[1];  // 06045994 or r1,r3
    c.r[1] = c.r[2];  // 06045996 mov r2,r1
    c.r[1] += 1;  // 06045998 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604599A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604599C extu.b r1,r1
    c.r[1] <<= 8;  // 0604599E shll8 r1
    c.r[3] |= c.r[1];  // 060459A0 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060459A2 mov.b @r2,r1
    c.r[0] = ld32(0x060459F0u);  // 060459A4 mov.l 0x060459F0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060459A6 extu.b r1,r1
    c.r[3] |= c.r[1];  // 060459A8 or r1,r3
    c.r[2] += c.r[3];  // 060459AA add r3,r2
    st32(c.r[6], c.r[2]);  // 060459AC mov.l r2,@r6
L_060459AE:
    c.r[15] = c.r[14];  // 060459AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060459B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060459B2 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060459B4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060459B6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060459B8 rts ; mov.l @r15+,r8
}

void f_060459F4(SH2Context& c) {
    ran[1120] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060459F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060459F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060459F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060459FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060459FC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060459FE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045A00 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06045A02 sts.l pr,@-r15
    c.r[15] -= 24;  // 06045A04 add #-24,r15
    c.r[14] = c.r[15];  // 06045A06 mov r15,r14
    c.r[12] = ld32(0x06045B10u);  // 06045A08 mov.l 0x06045B10,r12
    c.r[13] = ld32(0x06045B14u);  // 06045A0A mov.l 0x06045B14,r13
    c.r[6] = 0x4u;  // 06045A0C mov #4,r6
    c.r[4] = ld32(c.r[12]);  // 06045A0E mov.l @r12,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06045A14u; c.r[5] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A14u) return; }  // 06045A10 jsr @r13 ; mov #7,r5
    c.r[0] += 28;  // 06045A14 add #28,r0
    c.r[9] = 0x2u;  // 06045A16 mov #2,r9
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06045A18 mov.l r9,@-r15
    c.r[10] = ld32(0x06045B18u);  // 06045A1A mov.l 0x06045B18,r10
    c.r[7] = c.r[0];  // 06045A1C mov r0,r7
    c.r[6] = 0x4Au;  // 06045A1E mov #74,r6
    c.r[5] = 0x4u;  // 06045A20 mov #4,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06045A26u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A26u) return; }  // 06045A22 jsr @r10 ; mov #16,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06045B06u);  // 06045A26 mov.w 0x06045B06,r4
    c.r[8] = ld32(0x06045B1Cu);  // 06045A28 mov.l 0x06045B1C,r8
    c.r[7] = 0x10u;  // 06045A2A mov #16,r7
    c.r[6] = 0x0u;  // 06045A2C mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06045A32u; c.r[5] = 0x4Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A32u) return; }  // 06045A2E jsr @r8 ; mov #75,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06045B08u);  // 06045A32 mov.w 0x06045B08,r4
    c.r[7] = 0x10u;  // 06045A34 mov #16,r7
    c.r[6] = 0x0u;  // 06045A36 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06045A3Cu; c.r[5] = 0x4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A3Cu) return; }  // 06045A38 jsr @r8 ; mov #74,r5
    c.r[6] = 0x4u;  // 06045A3C mov #4,r6
    c.r[4] = ld32(c.r[12]);  // 06045A3E mov.l @r12,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06045A44u; c.r[5] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A44u) return; }  // 06045A40 jsr @r13 ; mov #20,r5
    c.r[0] += 80;  // 06045A44 add #80,r0
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06045A46 mov.l r9,@-r15
    c.r[7] = c.r[0];  // 06045A48 mov r0,r7
    c.r[6] = 0x60u;  // 06045A4A mov #96,r6
    c.r[5] = 0x4u;  // 06045A4C mov #4,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06045A52u; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A52u) return; }  // 06045A4E jsr @r10 ; mov #18,r4
    c.r[6] = 0x4u;  // 06045A52 mov #4,r6
    c.r[4] = ld32(c.r[12]);  // 06045A54 mov.l @r12,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06045A5Au; c.r[5] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A5Au) return; }  // 06045A56 jsr @r13 ; mov #8,r5
    c.r[3] = c.r[0];  // 06045A5A mov r0,r3
    c.r[3] += 32;  // 06045A5C add #32,r3
    c.r[2] = ld32(0x06045B20u);  // 06045A5E mov.l 0x06045B20,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045B0Au);  // 06045A60 mov.w 0x06045B0A,r0
    c.r[1] = 0x3u;  // 06045A62 mov #3,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045A64 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045B0Cu);  // 06045A66 mov.w 0x06045B0C,r0
    c.r[11] = ld32(0x06045B24u);  // 06045A68 mov.l 0x06045B24,r11
    c.r[1] = ld32(0x06045B28u);  // 06045A6A mov.l 0x06045B28,r1
    c.r[6] = c.r[14];  // 06045A6C mov r14,r6
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06045A6E mov.w @r11,r9
    c.r[4] = c.r[3];  // 06045A70 mov r3,r4
    st16(c.r[0] + c.r[2], c.r[9]);  // 06045A72 mov.w r9,@(r0,r2)
    c.r[9] = c.r[9] & 0xFFFFu;  // 06045A74 extu.w r9,r9
    c.r[9] <<= 2;  // 06045A76 shll2 r9
    c.r[9] += c.r[9];  // 06045A78 add r9,r9
    c.r[9] <<= 2;  // 06045A7A shll2 r9
    c.r[9] += c.r[1];  // 06045A7C add r1,r9
    c.r[1] = ld32(0x06045B2Cu);  // 06045A7E mov.l 0x06045B2C,r1
    c.r[0] = ld32(0x06045B30u);  // 06045A80 mov.l 0x06045B30,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06045A86u; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A86u) return; }  // 06045A82 jsr @r0 ; mov.l @r1,r5
    c.r[1] = c.r[14];  // 06045A86 mov r14,r1
    c.r[1] += 4;  // 06045A88 add #4,r1
    c.r[0] = ld32(0x06045B34u);  // 06045A8A mov.l 0x06045B34,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045A8C mov.w @r1,r6
    c.r[4] = 0x5Cu;  // 06045A8E mov #92,r4
    c.r[5] = ld32(c.r[14] + 8);  // 06045A90 mov.l @(8,r14),r5
    c.r[6] = c.r[6] & 0xFFFFu;  // 06045A92 extu.w r6,r6
    c.r[6] >>= 2;  // 06045A94 shlr2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x06045A9Au; c.r[6] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045A9Au) return; }  // 06045A96 jsr @r0 ; shlr2 r6
    c.r[1] = c.r[14];  // 06045A9A mov r14,r1
    c.r[1] += 6;  // 06045A9C add #6,r1
    c.r[10] = ld32(0x06045B38u);  // 06045A9E mov.l 0x06045B38,r10
    c.r[7] = 0xEu;  // 06045AA0 mov #14,r7
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045AA2 mov.w @r1,r8
    c.r[5] = c.r[9];  // 06045AA4 mov r9,r5
    c.r[8] = c.r[8] & 0xFFFFu;  // 06045AA6 extu.w r8,r8
    c.r[1] = 0x1u;  // 06045AA8 mov #1,r1
    st8(c.r[10], c.r[1]);  // 06045AAA mov.b r1,@r10
    c.r[6] = c.r[8];  // 06045AAC mov r8,r6
    c.r[6] <<= 2;  // 06045AAE shll2 r6
    c.r[6] += c.r[6];  // 06045AB0 add r6,r6
    c.r[6] <<= 2;  // 06045AB2 shll2 r6
    c.r[1] = ld32(0x06045B3Cu);  // 06045AB4 mov.l 0x06045B3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045ABAu; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045ABAu) return; }  // 06045AB6 jsr @r1 ; mov.l @(16,r14),r4
    c.r[1] = ld32(0x06045B40u);  // 06045ABA mov.l 0x06045B40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045AC0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045AC0u) return; }  // 06045ABC jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06045AC0 mov #0,r1
    st8(c.r[10], c.r[1]);  // 06045AC2 mov.b r1,@r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06045AC4 mov.w @r11,r1
    c.r[6] = 0x4u;  // 06045AC6 mov #4,r6
    c.r[8] += c.r[1];  // 06045AC8 add r1,r8
    st16(c.r[11], c.r[8]);  // 06045ACA mov.w r8,@r11
    c.r[4] = ld32(c.r[12]);  // 06045ACC mov.l @r12,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06045AD2u; c.r[5] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045AD2u) return; }  // 06045ACE jsr @r13 ; mov #9,r5
    c.r[1] = c.r[0];  // 06045AD2 mov r0,r1
    c.r[1] += 36;  // 06045AD4 add #36,r1
    c.r[6] = ld32(0x06045B44u);  // 06045AD6 mov.l 0x06045B44,r6
    c.r[8] = ld32(0x06045B48u);  // 06045AD8 mov.l 0x06045B48,r8
    c.r[0] = ld32(0x06045B4Cu);  // 06045ADA mov.l 0x06045B4C,r0
    c.r[5] = ld32(c.r[8]);  // 06045ADC mov.l @r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06045AE2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045AE2u) return; }  // 06045ADE jsr @r0 ; mov r1,r4
    c.r[0] += 3;  // 06045AE2 add #3,r0
    c.r[0] >>= 2;  // 06045AE4 shlr2 r0
    c.r[0] <<= 2;  // 06045AE6 shll2 r0
    c.r[14] += 24;  // 06045AE8 add #24,r14
    c.r[1] = ld32(c.r[8]);  // 06045AEA mov.l @r8,r1
    c.r[15] = c.r[14];  // 06045AEC mov r14,r15
    c.r[1] += c.r[0];  // 06045AEE add r0,r1
    st32(c.r[8], c.r[1]);  // 06045AF0 mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06045AF2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06045AF4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06045AF6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06045AF8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06045AFA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06045AFC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06045AFE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045B0Eu);  // 06045B00 mov.w 0x06045B0E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045B02 rts ; mov.l @r15+,r8
}

void f_06045B50(SH2Context& c) {
    ran[1121] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06045B50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06045B52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06045B54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06045B56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06045B58 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06045B5A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045B5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06045B5E sts.l pr,@-r15
    c.r[15] -= 24;  // 06045B60 add #-24,r15
    c.r[1] = ld32(0x06045D50u);  // 06045B62 mov.l 0x06045D50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045B64 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06045B66 mov r1,r0
    c.r[0] >>= 2;  // 06045B68 shlr2 r0
    c.r[0] >>= 2;  // 06045B6A shlr2 r0
    c.r[0] >>= 2;  // 06045B6C shlr2 r0
    c.r[0] &= 0x1u;  // 06045B6E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06045B70 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06045B90; } }  // 06045B72 bt/s 0x06045B90 ; mov r15,r14
    c.r[2] = ld32(0x06045D54u);  // 06045B76 mov.l 0x06045D54,r2
    c.r[1] = c.r[2];  // 06045B78 mov r2,r1
    c.r[1] += 6;  // 06045B7A add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045B7C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045B7E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06045B80 tst r1,r1
    if (c.t) { goto L_06045B8A; }  // 06045B82 bt 0x06045B8A
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06045B84 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06045BAA;  // 06045B86 bra 0x06045BAA ; extu.b r1,r1
L_06045B8A:
    c.r[1] = ld32(0x06045D58u);  // 06045B8A mov.l 0x06045D58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06045BA8;  // 06045B8C bra 0x06045BA8 ; mov.b @r1,r1
L_06045B90:
    c.r[2] = ld32(0x06045D5Cu);  // 06045B90 mov.l 0x06045D5C,r2
    c.r[1] = c.r[2];  // 06045B92 mov r2,r1
    c.r[1] += 6;  // 06045B94 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045B96 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045B98 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06045B9A tst r1,r1
    if (c.t) { goto L_06045BA4; }  // 06045B9C bt 0x06045BA4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06045B9E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06045BAA;  // 06045BA0 bra 0x06045BAA ; extu.b r1,r1
L_06045BA4:
    c.r[1] = ld32(0x06045D60u);  // 06045BA4 mov.l 0x06045D60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045BA6 mov.b @r1,r1
L_06045BA8:
    c.r[1] = c.r[1] & 0xFFu;  // 06045BA8 extu.b r1,r1
L_06045BAA:
    c.r[1] >>= 2;  // 06045BAA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06045BAC shlr r1
    c.r[1] >>= 2;  // 06045BAE shlr2 r1
    c.r[3] = c.r[1];  // 06045BB0 mov r1,r3
    c.r[1] = ld32(0x06045D64u);  // 06045BB2 mov.l 0x06045D64,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045BB4 mov.w @r1,r1
    c.r[2] = ld32(0x06045D68u);  // 06045BB6 mov.l 0x06045D68,r2
    st16(c.r[2], c.r[1]);  // 06045BB8 mov.w r1,@r2
    c.r[1] = 0x4u;  // 06045BBA mov #4,r1
    c.t = c.r[3] > c.r[1];  // 06045BBC cmp/hi r1,r3
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06045BC6; } }  // 06045BBE bf/s 0x06045BC6 ; mov r3,r1
    goto L_06045E68;  // 06045BC2 bra 0x06045E68 ; nop
L_06045BC6:
    c.r[1] += c.r[1];  // 06045BC6 add r1,r1
    c.r[0] = 0x06045BD4u;  // 06045BC8 mova 0x06045BD4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06045BCA mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06045BCC add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06045E68u: goto L_06045E68; case 0x06045BDEu: goto L_06045BDE; case 0x06045C94u: goto L_06045C94; case 0x06045D9Cu: goto L_06045D9C; default: sh2_call(c, x); return; } }  // 06045BCE jmp @r0 ; nop
L_06045BDE:
    c.r[10] = ld32(0x06045D6Cu);  // 06045BDE mov.l 0x06045D6C,r10
    c.r[11] = ld32(0x06045D70u);  // 06045BE0 mov.l 0x06045D70,r11
    c.r[6] = 0x4u;  // 06045BE2 mov #4,r6
    c.r[4] = ld32(c.r[10]);  // 06045BE4 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045BEAu; c.r[5] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045BEAu) return; }  // 06045BE6 jsr @r11 ; mov #10,r5
    c.r[0] += 40;  // 06045BEA add #40,r0
    c.r[8] = ld32(0x06045D64u);  // 06045BEC mov.l 0x06045D64,r8
    c.r[1] = 0x2u;  // 06045BEE mov #2,r1
    c.r[7] = c.r[0];  // 06045BF0 mov r0,r7
    c.r[5] = 0x4u;  // 06045BF2 mov #4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06045BF4 mov.w @r8,r6
    c.r[4] = 0x13u;  // 06045BF6 mov #19,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045BF8 mov.l r1,@-r15
    c.r[1] = ld32(0x06045D74u);  // 06045BFA mov.l 0x06045D74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045C00u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C00u) return; }  // 06045BFC jsr @r1 ; extu.w r6,r6
    c.r[6] = 0x4u;  // 06045C00 mov #4,r6
    c.r[4] = ld32(c.r[10]);  // 06045C02 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045C08u; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C08u) return; }  // 06045C04 jsr @r11 ; mov #11,r5
    c.r[3] = c.r[0];  // 06045C08 mov r0,r3
    c.r[3] += 44;  // 06045C0A add #44,r3
    c.r[2] = ld32(0x06045D78u);  // 06045C0C mov.l 0x06045D78,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045D4Au);  // 06045C0E mov.w 0x06045D4A,r0
    c.r[1] = 0x3u;  // 06045C10 mov #3,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045C12 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045D4Cu);  // 06045C14 mov.w 0x06045D4C,r0
    c.r[9] = ld32(0x06045D7Cu);  // 06045C16 mov.l 0x06045D7C,r9
    c.r[6] = c.r[14];  // 06045C18 mov r14,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06045C1A mov.w @r9,r1
    c.r[4] = c.r[3];  // 06045C1C mov r3,r4
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045C1E mov.w r1,@(r0,r2)
    c.r[13] = c.r[1] & 0xFFFFu;  // 06045C20 extu.w r1,r13
    c.r[13] <<= 2;  // 06045C22 shll2 r13
    c.r[13] += c.r[13];  // 06045C24 add r13,r13
    c.r[13] <<= 2;  // 06045C26 shll2 r13
    c.r[1] = ld32(0x06045D80u);  // 06045C28 mov.l 0x06045D80,r1
    c.r[13] += c.r[1];  // 06045C2A add r1,r13
    c.r[1] = ld32(0x06045D84u);  // 06045C2C mov.l 0x06045D84,r1
    c.r[0] = ld32(0x06045D88u);  // 06045C2E mov.l 0x06045D88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06045C34u; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C34u) return; }  // 06045C30 jsr @r0 ; mov.l @r1,r5
    c.r[1] = c.r[14];  // 06045C34 mov r14,r1
    c.r[1] += 4;  // 06045C36 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045C38 mov.w @r1,r1
    c.r[0] = ld32(0x06045D8Cu);  // 06045C3A mov.l 0x06045D8C,r0
    c.r[5] = ld32(c.r[14] + 8);  // 06045C3C mov.l @(8,r14),r5
    c.r[12] = c.r[1] & 0xFFFFu;  // 06045C3E extu.w r1,r12
    c.r[12] >>= 2;  // 06045C40 shlr2 r12
    c.r[12] >>= 2;  // 06045C42 shlr2 r12
    c.r[1] = c.r[8];  // 06045C44 mov r8,r1
    c.r[1] += 1;  // 06045C46 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045C48 mov.b @r1,r4
    c.r[6] = c.r[12];  // 06045C4A mov r12,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06045C50u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C50u) return; }  // 06045C4C jsr @r0 ; extu.b r4,r4
    c.r[7] = 0xEu;  // 06045C50 mov #14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06045C52 mov.w @r8,r1
    c.r[5] = c.r[13];  // 06045C54 mov r13,r5
    c.r[12] += c.r[1];  // 06045C56 add r1,r12
    st16(c.r[8], c.r[12]);  // 06045C58 mov.w r12,@r8
    c.r[1] = c.r[14];  // 06045C5A mov r14,r1
    c.r[1] += 6;  // 06045C5C add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045C5E mov.w @r1,r1
    c.r[8] = ld32(0x06045D90u);  // 06045C60 mov.l 0x06045D90,r8
    c.r[12] = c.r[1] & 0xFFFFu;  // 06045C62 extu.w r1,r12
    c.r[1] = 0x1u;  // 06045C64 mov #1,r1
    st8(c.r[8], c.r[1]);  // 06045C66 mov.b r1,@r8
    c.r[6] = c.r[12];  // 06045C68 mov r12,r6
    c.r[6] <<= 2;  // 06045C6A shll2 r6
    c.r[6] += c.r[6];  // 06045C6C add r6,r6
    c.r[6] <<= 2;  // 06045C6E shll2 r6
    c.r[1] = ld32(0x06045D94u);  // 06045C70 mov.l 0x06045D94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045C76u; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C76u) return; }  // 06045C72 jsr @r1 ; mov.l @(16,r14),r4
    c.r[1] = ld32(0x06045D98u);  // 06045C76 mov.l 0x06045D98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045C7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C7Cu) return; }  // 06045C78 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06045C7C mov #0,r1
    st8(c.r[8], c.r[1]);  // 06045C7E mov.b r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06045C80 mov.w @r9,r1
    c.r[6] = 0x4u;  // 06045C82 mov #4,r6
    c.r[12] += c.r[1];  // 06045C84 add r1,r12
    st16(c.r[9], c.r[12]);  // 06045C86 mov.w r12,@r9
    c.r[4] = ld32(c.r[10]);  // 06045C88 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045C8Eu; c.r[5] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045C8Eu) return; }  // 06045C8A jsr @r11 ; mov #12,r5
    c.r[1] = c.r[0];  // 06045C8E mov r0,r1
    c.r[1] += 48; goto L_06045E50;  // 06045C90 bra 0x06045E50 ; add #48,r1
L_06045C94:
    c.r[10] = ld32(0x06045D6Cu);  // 06045C94 mov.l 0x06045D6C,r10
    c.r[11] = ld32(0x06045D70u);  // 06045C96 mov.l 0x06045D70,r11
    c.r[6] = 0x4u;  // 06045C98 mov #4,r6
    c.r[4] = ld32(c.r[10]);  // 06045C9A mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045CA0u; c.r[5] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045CA0u) return; }  // 06045C9C jsr @r11 ; mov #10,r5
    c.r[0] += 40;  // 06045CA0 add #40,r0
    c.r[8] = ld32(0x06045D64u);  // 06045CA2 mov.l 0x06045D64,r8
    c.r[1] = 0x2u;  // 06045CA4 mov #2,r1
    c.r[7] = c.r[0];  // 06045CA6 mov r0,r7
    c.r[5] = 0x4u;  // 06045CA8 mov #4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06045CAA mov.w @r8,r6
    c.r[4] = 0x13u;  // 06045CAC mov #19,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045CAE mov.l r1,@-r15
    c.r[1] = ld32(0x06045D74u);  // 06045CB0 mov.l 0x06045D74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045CB6u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045CB6u) return; }  // 06045CB2 jsr @r1 ; extu.w r6,r6
    c.r[6] = 0x4u;  // 06045CB6 mov #4,r6
    c.r[4] = ld32(c.r[10]);  // 06045CB8 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045CBEu; c.r[5] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045CBEu) return; }  // 06045CBA jsr @r11 ; mov #14,r5
    c.r[3] = c.r[0];  // 06045CBE mov r0,r3
    c.r[3] += 56;  // 06045CC0 add #56,r3
    c.r[2] = ld32(0x06045D78u);  // 06045CC2 mov.l 0x06045D78,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045D4Au);  // 06045CC4 mov.w 0x06045D4A,r0
    c.r[1] = 0x3u;  // 06045CC6 mov #3,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045CC8 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045D4Cu);  // 06045CCA mov.w 0x06045D4C,r0
    c.r[9] = ld32(0x06045D7Cu);  // 06045CCC mov.l 0x06045D7C,r9
    c.r[6] = c.r[14];  // 06045CCE mov r14,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06045CD0 mov.w @r9,r1
    c.r[4] = c.r[3];  // 06045CD2 mov r3,r4
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045CD4 mov.w r1,@(r0,r2)
    c.r[13] = c.r[1] & 0xFFFFu;  // 06045CD6 extu.w r1,r13
    c.r[13] <<= 2;  // 06045CD8 shll2 r13
    c.r[13] += c.r[13];  // 06045CDA add r13,r13
    c.r[13] <<= 2;  // 06045CDC shll2 r13
    c.r[1] = ld32(0x06045D80u);  // 06045CDE mov.l 0x06045D80,r1
    c.r[13] += c.r[1];  // 06045CE0 add r1,r13
    c.r[1] = ld32(0x06045D84u);  // 06045CE2 mov.l 0x06045D84,r1
    c.r[0] = ld32(0x06045D88u);  // 06045CE4 mov.l 0x06045D88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06045CEAu; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045CEAu) return; }  // 06045CE6 jsr @r0 ; mov.l @r1,r5
    c.r[1] = c.r[14];  // 06045CEA mov r14,r1
    c.r[1] += 4;  // 06045CEC add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045CEE mov.w @r1,r1
    c.r[0] = ld32(0x06045D8Cu);  // 06045CF0 mov.l 0x06045D8C,r0
    c.r[5] = ld32(c.r[14] + 8);  // 06045CF2 mov.l @(8,r14),r5
    c.r[12] = c.r[1] & 0xFFFFu;  // 06045CF4 extu.w r1,r12
    c.r[12] >>= 2;  // 06045CF6 shlr2 r12
    c.r[12] >>= 2;  // 06045CF8 shlr2 r12
    c.r[1] = c.r[8];  // 06045CFA mov r8,r1
    c.r[1] += 1;  // 06045CFC add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045CFE mov.b @r1,r4
    c.r[6] = c.r[12];  // 06045D00 mov r12,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06045D06u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045D06u) return; }  // 06045D02 jsr @r0 ; extu.b r4,r4
    c.r[7] = 0xEu;  // 06045D06 mov #14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06045D08 mov.w @r8,r1
    c.r[5] = c.r[13];  // 06045D0A mov r13,r5
    c.r[12] += c.r[1];  // 06045D0C add r1,r12
    st16(c.r[8], c.r[12]);  // 06045D0E mov.w r12,@r8
    c.r[1] = c.r[14];  // 06045D10 mov r14,r1
    c.r[1] += 6;  // 06045D12 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045D14 mov.w @r1,r1
    c.r[8] = ld32(0x06045D90u);  // 06045D16 mov.l 0x06045D90,r8
    c.r[12] = c.r[1] & 0xFFFFu;  // 06045D18 extu.w r1,r12
    c.r[1] = 0x1u;  // 06045D1A mov #1,r1
    st8(c.r[8], c.r[1]);  // 06045D1C mov.b r1,@r8
    c.r[6] = c.r[12];  // 06045D1E mov r12,r6
    c.r[6] <<= 2;  // 06045D20 shll2 r6
    c.r[6] += c.r[6];  // 06045D22 add r6,r6
    c.r[6] <<= 2;  // 06045D24 shll2 r6
    c.r[1] = ld32(0x06045D94u);  // 06045D26 mov.l 0x06045D94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045D2Cu; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045D2Cu) return; }  // 06045D28 jsr @r1 ; mov.l @(16,r14),r4
    c.r[1] = ld32(0x06045D98u);  // 06045D2C mov.l 0x06045D98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045D32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045D32u) return; }  // 06045D2E jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06045D32 mov #0,r1
    st8(c.r[8], c.r[1]);  // 06045D34 mov.b r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06045D36 mov.w @r9,r1
    c.r[6] = 0x4u;  // 06045D38 mov #4,r6
    c.r[12] += c.r[1];  // 06045D3A add r1,r12
    st16(c.r[9], c.r[12]);  // 06045D3C mov.w r12,@r9
    c.r[4] = ld32(c.r[10]);  // 06045D3E mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045D44u; c.r[5] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045D44u) return; }  // 06045D40 jsr @r11 ; mov #15,r5
    c.r[1] = c.r[0];  // 06045D44 mov r0,r1
    c.r[1] += 60; goto L_06045E50;  // 06045D46 bra 0x06045E50 ; add #60,r1
L_06045D9C:
    c.r[10] = ld32(0x06045E84u);  // 06045D9C mov.l 0x06045E84,r10
    c.r[11] = ld32(0x06045E88u);  // 06045D9E mov.l 0x06045E88,r11
    c.r[6] = 0x4u;  // 06045DA0 mov #4,r6
    c.r[4] = ld32(c.r[10]);  // 06045DA2 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045DA8u; c.r[5] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045DA8u) return; }  // 06045DA4 jsr @r11 ; mov #16,r5
    c.r[0] += 64;  // 06045DA8 add #64,r0
    c.r[8] = ld32(0x06045E8Cu);  // 06045DAA mov.l 0x06045E8C,r8
    c.r[1] = 0x2u;  // 06045DAC mov #2,r1
    c.r[7] = c.r[0];  // 06045DAE mov r0,r7
    c.r[5] = 0x4u;  // 06045DB0 mov #4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06045DB2 mov.w @r8,r6
    c.r[4] = 0x13u;  // 06045DB4 mov #19,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06045DB6 mov.l r1,@-r15
    c.r[1] = ld32(0x06045E90u);  // 06045DB8 mov.l 0x06045E90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045DBEu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045DBEu) return; }  // 06045DBA jsr @r1 ; extu.w r6,r6
    c.r[6] = 0x4u;  // 06045DBE mov #4,r6
    c.r[4] = ld32(c.r[10]);  // 06045DC0 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045DC6u; c.r[5] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045DC6u) return; }  // 06045DC2 jsr @r11 ; mov #17,r5
    c.r[3] = c.r[0];  // 06045DC6 mov r0,r3
    c.r[3] += 68;  // 06045DC8 add #68,r3
    c.r[2] = ld32(0x06045E94u);  // 06045DCA mov.l 0x06045E94,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045E80u);  // 06045DCC mov.w 0x06045E80,r0
    c.r[1] = 0x3u;  // 06045DCE mov #3,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045DD0 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045E82u);  // 06045DD2 mov.w 0x06045E82,r0
    c.r[9] = ld32(0x06045E98u);  // 06045DD4 mov.l 0x06045E98,r9
    c.r[6] = c.r[14];  // 06045DD6 mov r14,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06045DD8 mov.w @r9,r1
    c.r[4] = c.r[3];  // 06045DDA mov r3,r4
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045DDC mov.w r1,@(r0,r2)
    c.r[13] = c.r[1] & 0xFFFFu;  // 06045DDE extu.w r1,r13
    c.r[13] <<= 2;  // 06045DE0 shll2 r13
    c.r[13] += c.r[13];  // 06045DE2 add r13,r13
    c.r[13] <<= 2;  // 06045DE4 shll2 r13
    c.r[1] = ld32(0x06045E9Cu);  // 06045DE6 mov.l 0x06045E9C,r1
    c.r[13] += c.r[1];  // 06045DE8 add r1,r13
    c.r[1] = ld32(0x06045EA0u);  // 06045DEA mov.l 0x06045EA0,r1
    c.r[0] = ld32(0x06045EA4u);  // 06045DEC mov.l 0x06045EA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06045DF2u; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045DF2u) return; }  // 06045DEE jsr @r0 ; mov.l @r1,r5
    c.r[1] = c.r[14];  // 06045DF2 mov r14,r1
    c.r[1] += 4;  // 06045DF4 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045DF6 mov.w @r1,r1
    c.r[0] = ld32(0x06045EA8u);  // 06045DF8 mov.l 0x06045EA8,r0
    c.r[5] = ld32(c.r[14] + 8);  // 06045DFA mov.l @(8,r14),r5
    c.r[12] = c.r[1] & 0xFFFFu;  // 06045DFC extu.w r1,r12
    c.r[12] >>= 2;  // 06045DFE shlr2 r12
    c.r[12] >>= 2;  // 06045E00 shlr2 r12
    c.r[1] = c.r[8];  // 06045E02 mov r8,r1
    c.r[1] += 1;  // 06045E04 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045E06 mov.b @r1,r4
    c.r[6] = c.r[12];  // 06045E08 mov r12,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06045E0Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045E0Eu) return; }  // 06045E0A jsr @r0 ; extu.b r4,r4
    c.r[7] = 0xEu;  // 06045E0E mov #14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06045E10 mov.w @r8,r1
    c.r[5] = c.r[13];  // 06045E12 mov r13,r5
    c.r[12] += c.r[1];  // 06045E14 add r1,r12
    st16(c.r[8], c.r[12]);  // 06045E16 mov.w r12,@r8
    c.r[1] = c.r[14];  // 06045E18 mov r14,r1
    c.r[1] += 6;  // 06045E1A add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045E1C mov.w @r1,r1
    c.r[8] = ld32(0x06045EACu);  // 06045E1E mov.l 0x06045EAC,r8
    c.r[12] = c.r[1] & 0xFFFFu;  // 06045E20 extu.w r1,r12
    c.r[1] = 0x1u;  // 06045E22 mov #1,r1
    st8(c.r[8], c.r[1]);  // 06045E24 mov.b r1,@r8
    c.r[6] = c.r[12];  // 06045E26 mov r12,r6
    c.r[6] <<= 2;  // 06045E28 shll2 r6
    c.r[6] += c.r[6];  // 06045E2A add r6,r6
    c.r[6] <<= 2;  // 06045E2C shll2 r6
    c.r[1] = ld32(0x06045EB0u);  // 06045E2E mov.l 0x06045EB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045E34u; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045E34u) return; }  // 06045E30 jsr @r1 ; mov.l @(16,r14),r4
    c.r[1] = ld32(0x06045EB4u);  // 06045E34 mov.l 0x06045EB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06045E3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045E3Au) return; }  // 06045E36 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06045E3A mov #0,r1
    st8(c.r[8], c.r[1]);  // 06045E3C mov.b r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06045E3E mov.w @r9,r1
    c.r[6] = 0x4u;  // 06045E40 mov #4,r6
    c.r[12] += c.r[1];  // 06045E42 add r1,r12
    st16(c.r[9], c.r[12]);  // 06045E44 mov.w r12,@r9
    c.r[4] = ld32(c.r[10]);  // 06045E46 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06045E4Cu; c.r[5] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045E4Cu) return; }  // 06045E48 jsr @r11 ; mov #18,r5
    c.r[1] = c.r[0];  // 06045E4C mov r0,r1
    c.r[1] += 72;  // 06045E4E add #72,r1
L_06045E50:
    c.r[6] = ld32(0x06045EB8u);  // 06045E50 mov.l 0x06045EB8,r6
    c.r[8] = ld32(0x06045EBCu);  // 06045E52 mov.l 0x06045EBC,r8
    c.r[0] = ld32(0x06045EC0u);  // 06045E54 mov.l 0x06045EC0,r0
    c.r[5] = ld32(c.r[8]);  // 06045E56 mov.l @r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06045E5Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045E5Cu) return; }  // 06045E58 jsr @r0 ; mov r1,r4
    c.r[0] += 3;  // 06045E5C add #3,r0
    c.r[0] >>= 2;  // 06045E5E shlr2 r0
    c.r[1] = ld32(c.r[8]);  // 06045E60 mov.l @r8,r1
    c.r[0] <<= 2;  // 06045E62 shll2 r0
    c.r[1] += c.r[0];  // 06045E64 add r0,r1
    st32(c.r[8], c.r[1]);  // 06045E66 mov.l r1,@r8
L_06045E68:
    c.r[14] += 24;  // 06045E68 add #24,r14
    c.r[15] = c.r[14];  // 06045E6A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06045E6C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06045E6E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06045E70 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06045E72 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06045E74 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06045E76 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06045E78 mov.l @r15+,r9
    c.r[0] = ld32(0x06045EC4u);  // 06045E7A mov.l 0x06045EC4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045E7C rts ; mov.l @r15+,r8
}

void f_06045EC8(SH2Context& c) {
    ran[1122] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045EC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06045ECA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06045ECC mov r15,r14
    c.r[2] = ld32(0x06045F08u);  // 06045ECE mov.l 0x06045F08,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045F00u);  // 06045ED0 mov.w 0x06045F00,r0
    c.r[1] = 0x4u;  // 06045ED2 mov #4,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045ED4 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045F02u);  // 06045ED6 mov.w 0x06045F02,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06045F04u);  // 06045ED8 mov.w 0x06045F04,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06045EDA mov.w r1,@(r0,r2)
    c.r[1] = ld32(0x06045F0Cu);  // 06045EDC mov.l 0x06045F0C,r1
    c.r[0] = ld32(0x06045F10u);  // 06045EDE mov.l 0x06045F10,r0
    c.r[6] = 0x4u;  // 06045EE0 mov #4,r6
    c.r[4] = ld32(c.r[1]);  // 06045EE2 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06045EE8u; c.r[5] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045EE8u) return; }  // 06045EE4 jsr @r0 ; mov #6,r5
    c.r[1] = c.r[0];  // 06045EE8 mov r0,r1
    c.r[1] += 24;  // 06045EEA add #24,r1
    c.r[6] = ld32(0x06045F14u);  // 06045EEC mov.l 0x06045F14,r6
    c.r[5] = ld32(0x06045F18u);  // 06045EEE mov.l 0x06045F18,r5
    c.r[0] = ld32(0x06045F1Cu);  // 06045EF0 mov.l 0x06045F1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06045EF6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06045EF6u) return; }  // 06045EF2 jsr @r0 ; mov r1,r4
    c.r[15] = c.r[14];  // 06045EF6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06045EF8 lds.l @r15+,pr
    c.r[0] = ld32(0x06045F20u);  // 06045EFA mov.l 0x06045F20,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045EFC rts ; mov.l @r15+,r14
}

void f_06045F24(SH2Context& c) {
    ran[1123] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045F24 mov.l r14,@-r15
    c.r[1] = ld32(0x06045F5Cu);  // 06045F26 mov.l 0x06045F5C,r1
    c.r[1] = ld32(c.r[1]);  // 06045F28 mov.l @r1,r1
    c.r[1] += 1;  // 06045F2A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045F2C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06045F2E extu.b r1,r2
    c.r[1] = 0x7Fu;  // 06045F30 mov #127,r1
    c.t = c.r[2] > c.r[1];  // 06045F32 cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06045F42; } }  // 06045F34 bf/s 0x06045F42 ; mov r15,r14
    c.r[1] = ld32(0x06045F60u);  // 06045F38 mov.l 0x06045F60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045F3A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06045F3C extu.b r1,r1
    c.t = c.r[1] >= c.r[2]; goto L_06045F4A;  // 06045F3E bra 0x06045F4A ; cmp/hs r2,r1
L_06045F42:
    c.r[1] = ld32(0x06045F60u);  // 06045F42 mov.l 0x06045F60,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045F44 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06045F46 and #127,r0
    c.t = c.r[0] >= c.r[2];  // 06045F48 cmp/hs r2,r0
L_06045F4A:
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06045F54; } }  // 06045F4A bf/s 0x06045F54 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045F5Au);  // 06045F4E mov.w 0x06045F5A,r0
    goto L_06045F56;  // 06045F50 bra 0x06045F56 ; nop
L_06045F54:
    c.r[0] = 0x0u;  // 06045F54 mov #0,r0
L_06045F56:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045F56 rts ; mov.l @r15+,r14
}

void f_06045F64(SH2Context& c) {
    ran[1124] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045F64 mov.l r14,@-r15
    c.r[1] = ld32(0x06045FB0u);  // 06045F66 mov.l 0x06045FB0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045F68 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06045F6A mov r1,r0
    c.r[0] >>= 2;  // 06045F6C shlr2 r0
    c.r[0] >>= 2;  // 06045F6E shlr2 r0
    c.r[0] >>= 2;  // 06045F70 shlr2 r0
    c.r[0] &= 0x1u;  // 06045F72 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06045F74 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06045F80; } }  // 06045F76 bt/s 0x06045F80 ; mov r15,r14
    c.r[1] = ld32(0x06045FB4u);  // 06045F7A mov.l 0x06045FB4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_06045F84;  // 06045F7C bra 0x06045F84 ; mov.w @r1,r1
L_06045F80:
    c.r[1] = ld32(0x06045FB8u);  // 06045F80 mov.l 0x06045FB8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045F82 mov.w @r1,r1
L_06045F84:
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045F84 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06045F86 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06045FA8; } }  // 06045F88 bf/s 0x06045FA8 ; mov #0,r0
    c.r[1] = ld32(0x06045FBCu);  // 06045F8C mov.l 0x06045FBC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06045F8E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06045F90 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06045F92 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06045FAA; } }  // 06045F94 bf/s 0x06045FAA ; mov r14,r15
    c.r[1] = ld32(0x06045FC0u);  // 06045F98 mov.l 0x06045FC0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045F9A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06045F9C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06045F9E tst r1,r1
    if (!c.t) { goto L_06045FAA; }  // 06045FA0 bf 0x06045FAA
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045FAEu);  // 06045FA2 mov.w 0x06045FAE,r0
    goto L_06045FAA;  // 06045FA4 bra 0x06045FAA ; nop
L_06045FA8:
    c.r[15] = c.r[14];  // 06045FA8 mov r14,r15
L_06045FAA:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045FAA rts ; mov.l @r15+,r14
}

void f_06045FC4(SH2Context& c) {
    ran[1125] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045FC4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06045FC6 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045FCEu);  // 06045FC8 mov.w 0x06045FCE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045FCA rts ; mov.l @r15+,r14
}

void f_06045FD0(SH2Context& c) {
    ran[1126] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06045FD0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06045FD2 mov r15,r14
    c.r[2] = ld32(0x06045FF4u);  // 06045FD4 mov.l 0x06045FF4,r2
    c.r[1] = ld32(0x06045FF8u);  // 06045FD6 mov.l 0x06045FF8,r1
    c.r[3] = ld32(c.r[1]);  // 06045FD8 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06045FDA mov r3,r1
    c.r[1] += 1;  // 06045FDC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06045FDE mov.b @r1,r1
    c.r[3] += 2;  // 06045FE0 add #2,r3
    st8(c.r[2], c.r[1]);  // 06045FE2 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06045FE4 mov.b @r3,r1
    c.r[2] = ld32(0x06045FFCu);  // 06045FE6 mov.l 0x06045FFC,r2
    st8(c.r[2], c.r[1]);  // 06045FE8 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06045FF0u);  // 06045FEA mov.w 0x06045FF0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06045FEC rts ; mov.l @r15+,r14
}

void f_06046000(SH2Context& c) {
    ran[1127] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06046000 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06046002 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046004 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06046006 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06046008 mov r15,r14
    c.r[2] = ld32(0x06046140u);  // 0604600A mov.l 0x06046140,r2
    c.r[1] = ld32(0x06046144u);  // 0604600C mov.l 0x06046144,r1
    c.r[8] = ld32(0x06046148u);  // 0604600E mov.l 0x06046148,r8
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604612Au);  // 06046010 mov.w 0x0604612A,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x0604612Cu);  // 06046012 mov.w 0x0604612C,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604612Eu);  // 06046014 mov.w 0x0604612E,r0
    c.r[1] = ld32(c.r[1]);  // 06046016 mov.l @r1,r1
    c.r[6] = 0x4u;  // 06046018 mov #4,r6
    st32(c.r[2], c.r[1]);  // 0604601A mov.l r1,@r2
    c.r[2] = ld32(0x0604614Cu);  // 0604601C mov.l 0x0604614C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046130u);  // 0604601E mov.w 0x06046130,r1
    st16(c.r[2], c.r[1]);  // 06046020 mov.w r1,@r2
    c.r[1] = ld32(0x06046150u);  // 06046022 mov.l 0x06046150,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06046024 mov.w @r1,r1
    c.r[2] = ld32(0x06046154u);  // 06046026 mov.l 0x06046154,r2
    st16(c.r[2], c.r[1]);  // 06046028 mov.w r1,@r2
    c.r[1] = ld32(0x06046158u);  // 0604602A mov.l 0x06046158,r1
    st32(c.r[8] + 32, c.r[1]);  // 0604602C mov.l r1,@(32,r8)
    c.r[1] = ld32(0x0604615Cu);  // 0604602E mov.l 0x0604615C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06046034u; c.r[4] = ld32(c.r[0] + c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046034u) return; }  // 06046030 jsr @r1 ; mov.l @(r0,r8),r4
    c.r[1] = c.r[8];  // 06046034 mov r8,r1
    c.r[1] += 51;  // 06046036 add #51,r1
    c.r[2] = 0x0u;  // 06046038 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0604603A mov.b r2,@r1
    c.r[1] = c.r[8];  // 0604603C mov r8,r1
    c.r[1] += 52;  // 0604603E add #52,r1
    st8(c.r[1], c.r[2]);  // 06046040 mov.b r2,@r1
    c.r[1] = c.r[8];  // 06046042 mov r8,r1
    c.r[1] += 124;  // 06046044 add #124,r1
    c.r[2] = 0x0u;  // 06046046 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06046048 mov.l r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046132u);  // 0604604A mov.w 0x06046132,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 0604604C mov.l r2,@(r0,r8)
    c.r[8] = ld32(0x06046160u);  // 0604604E mov.l 0x06046160,r8
    c.r[5] = 0x1Fu;  // 06046050 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06046056u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046056u) return; }  // 06046052 jsr @r8 ; mov #0,r4
    c.r[5] = 0x1Fu;  // 06046056 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604605Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604605Cu) return; }  // 06046058 jsr @r8 ; mov #1,r4
    c.r[5] = 0x1Fu;  // 0604605C mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06046062u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046062u) return; }  // 0604605E jsr @r8 ; mov #2,r4
    c.r[5] = 0x1Fu;  // 06046062 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06046068u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046068u) return; }  // 06046064 jsr @r8 ; mov #3,r4
    c.r[3] = ld32(0x06046164u);  // 06046068 mov.l 0x06046164,r3
    c.r[2] = c.r[3];  // 0604606A mov r3,r2
    c.r[2] += 88;  // 0604606C add #88,r2
    c.r[1] = ld32(0x06046168u);  // 0604606E mov.l 0x06046168,r1
    c.r[7] = 0x0u;  // 06046070 mov #0,r7
    c.r[5] = 0x5u;  // 06046072 mov #5,r5
    c.r[6] = c.r[2];  // 06046074 mov r2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06046076 mov.w @r1,r1
    st16(c.r[2], c.r[1]);  // 06046078 mov.w r1,@r2
L_0604607A:
    c.r[2] = c.r[3];  // 0604607A mov r3,r2
    c.r[2] += 24;  // 0604607C add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604607E mov.w @r6,r1
    c.r[3] += 2;  // 06046080 add #2,r3
    c.r[7] += 1;  // 06046082 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[5];  // 06046084 cmp/gt r5,r7
    { const bool k = !c.t; st16(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_0604607A; } }  // 06046086 bf/s 0x0604607A ; mov.w r1,@r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06046134u);  // 0604608A mov.w 0x06046134,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x06046136u);  // 0604608C mov.w 0x06046136,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x06046132u);  // 0604608E mov.w 0x06046132,r8
    c.r[0] = ld32(0x0604616Cu);  // 06046090 mov.l 0x0604616C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06046096u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046096u) return; }  // 06046092 jsr @r0 ; mov r8,r4
    c.r[7] = 0x0u;  // 06046096 mov #0,r7
    c.r[2] = 0xDu;  // 06046098 mov #13,r2
    c.r[1] = ld32(0x06046170u);  // 0604609A mov.l 0x06046170,r1
    c.r[0] = 0x0u;  // 0604609C mov #0,r0
L_0604609E:
    st16(c.r[0] + c.r[1], c.r[8]);  // 0604609E mov.w r8,@(r0,r1)
    c.r[7] += 1;  // 060460A0 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[2];  // 060460A2 cmp/gt r2,r7
    { const bool k = !c.t; c.r[0] += 2; if (k) { SH2_POLL(c); goto L_0604609E; } }  // 060460A4 bf/s 0x0604609E ; add #2,r0
    c.r[2] = ld32(0x06046174u);  // 060460A8 mov.l 0x06046174,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046132u);  // 060460AA mov.w 0x06046132,r1
    st16(c.r[2], c.r[1]);  // 060460AC mov.w r1,@r2
    c.r[7] = ld32(0x06046178u);  // 060460AE mov.l 0x06046178,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060460B0 mov.b @r7,r6
    c.r[9] = 0x1u;  // 060460B2 mov #1,r9
    c.r[1] = ld32(0x0604617Cu);  // 060460B4 mov.l 0x0604617C,r1
    c.r[3] = c.r[6];  // 060460B6 mov r6,r3
    c.r[3] >>= 2;  // 060460B8 shlr2 r3
    c.r[3] >>= 2;  // 060460BA shlr2 r3
    c.r[3] >>= 2;  // 060460BC shlr2 r3
    c.r[3] &= c.r[9];  // 060460BE and r9,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060460C0 tst r3,r3
    if (c.t) { goto L_060460C6; }  // 060460C2 bt 0x060460C6
    c.r[1] = ld32(0x06046180u);  // 060460C4 mov.l 0x06046180,r1
L_060460C6:
    c.r[2] = ld32(0x06046184u);  // 060460C6 mov.l 0x06046184,r2
    if (c.t) { goto L_060460CC; }  // 060460C8 bt 0x060460CC
    c.r[2] = ld32(0x06046188u);  // 060460CA mov.l 0x06046188,r2
L_060460CC:
    c.r[1] += 6;  // 060460CC add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060460CE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060460D0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060460D2 tst r1,r1
    if (c.t) { goto L_0604611C; }  // 060460D4 bt 0x0604611C
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060460D6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060460D8 mov r1,r0
    c.r[0] >>= 2;  // 060460DA shlr2 r0
    c.r[0] &= 0x3u;  // 060460DC and #3,r0
    c.r[1] = 0x1u;  // 060460DE mov #1,r1
    c.t = c.r[0] > c.r[1];  // 060460E0 cmp/hi r1,r0
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0604611C; } }  // 060460E2 bt/s 0x0604611C ; tst r3,r3
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { goto L_0604611C; } }  // 060460E6 bf/s 0x0604611C ; mov r6,r0
    c.r[0] &= 0xDFu;  // 060460EA and #223,r0
    c.r[0] |= 0x40u;  // 060460EC or #64,r0
    st8(c.r[7], c.r[0]);  // 060460EE mov.b r0,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060460F0 mov.w @r7,r1
    c.r[0] = c.r[1];  // 060460F2 mov r1,r0
    c.r[0] >>= 2;  // 060460F4 shlr2 r0
    c.r[0] >>= 2;  // 060460F6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060460F8 shlr r0
    c.r[0] >>= 2;  // 060460FA shlr2 r0
    c.r[0] &= 0x3u;  // 060460FC and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060460FE tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0604610A; } }  // 06046100 bf/s 0x0604610A ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046138u);  // 06046104 mov.w 0x06046138,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06046122;  // 06046106 bra 0x06046122 ; lds.l @r15+,pr
L_0604610A:
    c.t = (int32_t)c.r[0] >= 0;  // 0604610A cmp/pz r0
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_0604611C; } }  // 0604610C bf/s 0x0604611C ; mov #3,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06046110 cmp/gt r1,r0
    if (c.t) { goto L_0604611C; }  // 06046112 bt 0x0604611C
    c.r[15] = c.r[14];  // 06046114 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604613Au);  // 06046116 mov.w 0x0604613A,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06046122;  // 06046118 bra 0x06046122 ; lds.l @r15+,pr
L_0604611C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604613Cu);  // 0604611C mov.w 0x0604613C,r0
    c.r[15] = c.r[14];  // 0604611E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06046120 lds.l @r15+,pr
L_06046122:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06046122 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06046124 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046126 rts ; mov.l @r15+,r8
}

void f_0604618C(SH2Context& c) {
    ran[1128] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604618C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604618E mov r15,r14
    c.r[1] = ld32(0x060461B8u);  // 06046190 mov.l 0x060461B8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060461B4u);  // 06046192 mov.w 0x060461B4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046194 mov.b @r1,r2
    c.r[0] = c.r[2];  // 06046196 mov r2,r0
    c.r[0] >>= 2;  // 06046198 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604619A shlr r0
    c.r[0] >>= 2;  // 0604619C shlr2 r0
    c.r[0] &= 0x1u;  // 0604619E and #1,r0
    c.r[0] ^= 0x1u;  // 060461A0 xor #1,r0
    c.r[0] <<= 2;  // 060461A2 shll2 r0
    c.r[0] += c.r[0];  // 060461A4 add r0,r0
    c.r[0] <<= 2;  // 060461A6 shll2 r0
    c.r[2] &= c.r[3];  // 060461A8 and r3,r2
    c.r[2] |= c.r[0];  // 060461AA or r0,r2
    st8(c.r[1], c.r[2]);  // 060461AC mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060461B6u);  // 060461AE mov.w 0x060461B6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060461B0 rts ; mov.l @r15+,r14
}

void f_060461BC(SH2Context& c) {
    ran[1129] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060461BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060461BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060461C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060461C2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060461C4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060461C6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060461C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060461CA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060461CC mov r15,r14
    c.r[8] = ld32(0x06046300u);  // 060461CE mov.l 0x06046300,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060461D4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060461D4u) return; }  // 060461D0 jsr @r8 ; mov #1,r4
    c.r[9] = c.r[0];  // 060461D4 mov r0,r9
    { const uint32_t x = c.r[8]; c.pr = 0x060461DAu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060461DAu) return; }  // 060461D6 jsr @r8 ; mov #4,r4
    c.r[10] = c.r[0];  // 060461DA mov r0,r10
    { const uint32_t x = c.r[8]; c.pr = 0x060461E0u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060461E0u) return; }  // 060461DC jsr @r8 ; mov #5,r4
    c.r[1] = ld32(0x06046304u);  // 060461E0 mov.l 0x06046304,r1
    c.r[11] = ld32(c.r[1]);  // 060461E2 mov.l @r1,r11
    c.r[13] = ld32(0x06046308u);  // 060461E4 mov.l 0x06046308,r13
    c.t = (c.r[11] & c.r[11]) == 0;  // 060461E6 tst r11,r11
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { goto L_060461F0; } }  // 060461E8 bt/s 0x060461F0 ; mov r0,r8
    goto L_0604640E;  // 060461EC bra 0x0604640E ; nop
L_060461F0:
    c.r[2] = c.r[9];  // 060461F0 mov r9,r2
    c.r[2] += 56;  // 060461F2 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060462F8u);  // 060461F4 mov.w 0x060462F8,r1
    st16(c.r[2], c.r[1]);  // 060461F6 mov.w r1,@r2
    c.r[12] = ld32(0x0604630Cu);  // 060461F8 mov.l 0x0604630C,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060461FA mov.b @r12,r1
    c.r[0] = 0x1u;  // 060461FC mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060461FE extu.b r1,r1
    c.r[2] = c.r[1];  // 06046200 mov r1,r2
    c.r[2] >>= 2;  // 06046202 shlr2 r2
    c.r[2] >>= 2;  // 06046204 shlr2 r2
    c.r[2] >>= 2;  // 06046206 shlr2 r2
    c.r[1] >>= 2;  // 06046208 shlr2 r1
    c.r[1] >>= 2;  // 0604620A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604620C shlr r1
    c.r[1] >>= 2;  // 0604620E shlr2 r1
    c.r[2] &= c.r[0];  // 06046210 and r0,r2
    c.t = c.r[1] == c.r[2];  // 06046212 cmp/eq r2,r1
    c.r[3] = c.t;  // 06046214 movt r3
    c.r[1] = c.r[9];  // 06046216 mov r9,r1
    c.r[1] += 2;  // 06046218 add #2,r1
    c.r[3] ^= c.r[0];  // 0604621A xor r0,r3
    c.r[3] += c.r[3];  // 0604621C add r3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604621E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060462FAu);  // 06046220 mov.w 0x060462FA,r0
    c.r[2] &= c.r[0];  // 06046222 and r0,r2
    c.r[2] |= c.r[3];  // 06046224 or r3,r2
    st8(c.r[1], c.r[2]);  // 06046226 mov.b r2,@r1
    c.r[1] = c.r[9];  // 06046228 mov r9,r1
    c.r[1] += 1;  // 0604622A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604622C mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060462FCu);  // 0604622E mov.w 0x060462FC,r0
    c.r[2] |= c.r[0];  // 06046230 or r0,r2
    st8(c.r[1], c.r[2]);  // 06046232 mov.b r2,@r1
    c.r[1] = ld32(c.r[10] + 4);  // 06046234 mov.l @(4,r10),r1
    st32(c.r[9] + 4, c.r[1]);  // 06046236 mov.l r1,@(4,r9)
    c.r[1] = ld32(c.r[10] + 8);  // 06046238 mov.l @(8,r10),r1
    c.r[5] = ld32(0x06046310u);  // 0604623A mov.l 0x06046310,r5
    st32(c.r[9] + 8, c.r[1]);  // 0604623C mov.l r1,@(8,r9)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0604623E mov.b @r12,r1
    c.r[0] = 0x1u;  // 06046240 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06046242 extu.b r1,r1
    c.r[2] = c.r[1];  // 06046244 mov r1,r2
    c.r[2] >>= 2;  // 06046246 shlr2 r2
    c.r[2] >>= 2;  // 06046248 shlr2 r2
    c.r[2] >>= 2;  // 0604624A shlr2 r2
    c.r[1] >>= 2;  // 0604624C shlr2 r1
    c.r[1] >>= 2;  // 0604624E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06046250 shlr r1
    c.r[1] >>= 2;  // 06046252 shlr2 r1
    c.r[2] &= c.r[0];  // 06046254 and r0,r2
    c.t = c.r[1] == c.r[2];  // 06046256 cmp/eq r2,r1
    if (c.t) { goto L_0604625C; }  // 06046258 bt 0x0604625C
    c.r[5] = ld32(0x06046314u);  // 0604625A mov.l 0x06046314,r5
L_0604625C:
    c.r[0] = ld32(0x06046318u);  // 0604625C mov.l 0x06046318,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06046262u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046262u) return; }  // 0604625E jsr @r0 ; mov r9,r4
    c.r[13] += 1;  // 06046262 add #1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06046264 mov.b @r13,r1
    c.r[0] = 0x1u;  // 06046266 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06046268 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604626A mov r1,r2
    c.r[2] >>= 2;  // 0604626C shlr2 r2
    c.r[2] >>= 2;  // 0604626E shlr2 r2
    c.r[2] &= c.r[0];  // 06046270 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06046272 tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06046324; } }  // 06046274 bt/s 0x06046324 ; mov r1,r0
    c.r[0] >>= 2;  // 06046278 shlr2 r0
    c.r[0] &= 0x1u;  // 0604627A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604627C tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06046324; } }  // 0604627E bf/s 0x06046324 ; mov r8,r1
    c.r[1] += 1;  // 06046282 add #1,r1
    c.r[0] = 0x40u;  // 06046284 mov #64,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046286 mov.b @r1,r2
    c.r[5] = ld32(0x0604631Cu);  // 06046288 mov.l 0x0604631C,r5
    c.r[2] |= c.r[0];  // 0604628A or r0,r2
    st8(c.r[1], c.r[2]);  // 0604628C mov.b r2,@r1
    c.r[2] = c.r[8];  // 0604628E mov r8,r2
    c.r[2] += 56;  // 06046290 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060462FEu);  // 06046292 mov.w 0x060462FE,r1
    st16(c.r[2], c.r[1]);  // 06046294 mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06046296 mov.b @r12,r1
    c.r[0] = 0x1u;  // 06046298 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604629A extu.b r1,r1
    c.r[2] = c.r[1];  // 0604629C mov r1,r2
    c.r[2] >>= 2;  // 0604629E shlr2 r2
    c.r[2] >>= 2;  // 060462A0 shlr2 r2
    c.r[2] >>= 2;  // 060462A2 shlr2 r2
    c.r[1] >>= 2;  // 060462A4 shlr2 r1
    c.r[1] >>= 2;  // 060462A6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060462A8 shlr r1
    c.r[1] >>= 2;  // 060462AA shlr2 r1
    c.r[2] &= c.r[0];  // 060462AC and r0,r2
    c.t = c.r[1] == c.r[2];  // 060462AE cmp/eq r2,r1
    c.r[3] = c.t;  // 060462B0 movt r3
    c.r[1] = c.r[8];  // 060462B2 mov r8,r1
    c.r[1] += 2;  // 060462B4 add #2,r1
    c.r[3] ^= c.r[0];  // 060462B6 xor r0,r3
    c.r[3] += c.r[3];  // 060462B8 add r3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060462BA mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060462FAu);  // 060462BC mov.w 0x060462FA,r0
    c.r[2] &= c.r[0];  // 060462BE and r0,r2
    c.r[2] |= c.r[3];  // 060462C0 or r3,r2
    st8(c.r[1], c.r[2]);  // 060462C2 mov.b r2,@r1
    st32(c.r[8] + 4, c.r[11]);  // 060462C4 mov.l r11,@(4,r8)
    st32(c.r[8] + 8, c.r[11]);  // 060462C6 mov.l r11,@(8,r8)
    c.r[2] = c.r[8];  // 060462C8 mov r8,r2
    c.r[2] += 65;  // 060462CA add #65,r2
    c.r[1] = 0x1u;  // 060462CC mov #1,r1
    st8(c.r[2], c.r[1]);  // 060462CE mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060462D0 mov.b @r12,r1
    c.r[0] = 0x1u;  // 060462D2 mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060462D4 extu.b r1,r1
    c.r[2] = c.r[1];  // 060462D6 mov r1,r2
    c.r[2] >>= 2;  // 060462D8 shlr2 r2
    c.r[2] >>= 2;  // 060462DA shlr2 r2
    c.r[2] >>= 2;  // 060462DC shlr2 r2
    c.r[1] >>= 2;  // 060462DE shlr2 r1
    c.r[1] >>= 2;  // 060462E0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060462E2 shlr r1
    c.r[1] >>= 2;  // 060462E4 shlr2 r1
    c.r[2] &= c.r[0];  // 060462E6 and r0,r2
    c.t = c.r[1] == c.r[2];  // 060462E8 cmp/eq r2,r1
    if (c.t) { goto L_060462EE; }  // 060462EA bt 0x060462EE
    c.r[5] = ld32(0x06046320u);  // 060462EC mov.l 0x06046320,r5
L_060462EE:
    c.r[0] = ld32(0x06046318u);  // 060462EE mov.l 0x06046318,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060462F4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060462F4u) return; }  // 060462F0 jsr @r0 ; mov r8,r4
    c.r[2] = c.r[10]; goto L_06046330;  // 060462F4 bra 0x06046330 ; mov r10,r2
L_06046324:
    c.r[1] = c.r[8];  // 06046324 mov r8,r1
    c.r[1] += 1;  // 06046326 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046328 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 0604632A and #191,r0
    st8(c.r[1], c.r[0]);  // 0604632C mov.b r0,@r1
    c.r[2] = c.r[10];  // 0604632E mov r10,r2
L_06046330:
    c.r[2] += 56;  // 06046330 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046454u);  // 06046332 mov.w 0x06046454,r1
    st16(c.r[2], c.r[1]);  // 06046334 mov.w r1,@r2
    c.r[3] = ld32(0x06046470u);  // 06046336 mov.l 0x06046470,r3
    c.r[0] = 0x1u;  // 06046338 mov #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604633A mov.b @r3,r1
    c.r[5] = ld32(0x06046474u);  // 0604633C mov.l 0x06046474,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0604633E extu.b r1,r1
    c.r[2] = c.r[1];  // 06046340 mov r1,r2
    c.r[2] >>= 2;  // 06046342 shlr2 r2
    c.r[2] >>= 2;  // 06046344 shlr2 r2
    c.r[2] >>= 2;  // 06046346 shlr2 r2
    c.r[1] >>= 2;  // 06046348 shlr2 r1
    c.r[1] >>= 2;  // 0604634A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604634C shlr r1
    c.r[1] >>= 2;  // 0604634E shlr2 r1
    c.r[2] &= c.r[0];  // 06046350 and r0,r2
    c.t = c.r[1] == c.r[2];  // 06046352 cmp/eq r2,r1
    c.r[0] = c.t;  // 06046354 movt r0
    c.r[1] = c.r[0];  // 06046356 mov r0,r1
    c.r[2] = c.r[10];  // 06046358 mov r10,r2
    c.r[2] += 2;  // 0604635A add #2,r2
    c.r[1] += c.r[1];  // 0604635C add r1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604635E mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046456u);  // 06046360 mov.w 0x06046456,r0
    c.r[7] &= c.r[0];  // 06046362 and r0,r7
    c.r[7] |= c.r[1];  // 06046364 or r1,r7
    st8(c.r[2], c.r[7]);  // 06046366 mov.b r7,@r2
    c.r[1] = c.r[10];  // 06046368 mov r10,r1
    c.r[1] += 1;  // 0604636A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604636C mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046458u);  // 0604636E mov.w 0x06046458,r0
    c.r[2] |= c.r[0];  // 06046370 or r0,r2
    st8(c.r[1], c.r[2]);  // 06046372 mov.b r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604645Au);  // 06046374 mov.w 0x0604645A,r1
    st32(c.r[10] + 4, c.r[1]);  // 06046376 mov.l r1,@(4,r10)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604645Cu);  // 06046378 mov.w 0x0604645C,r1
    st32(c.r[10] + 8, c.r[1]);  // 0604637A mov.l r1,@(8,r10)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604637C mov.b @r3,r1
    c.r[0] = 0x1u;  // 0604637E mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06046380 extu.b r1,r1
    c.r[2] = c.r[1];  // 06046382 mov r1,r2
    c.r[2] >>= 2;  // 06046384 shlr2 r2
    c.r[2] >>= 2;  // 06046386 shlr2 r2
    c.r[2] >>= 2;  // 06046388 shlr2 r2
    c.r[1] >>= 2;  // 0604638A shlr2 r1
    c.r[1] >>= 2;  // 0604638C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604638E shlr r1
    c.r[1] >>= 2;  // 06046390 shlr2 r1
    c.r[2] &= c.r[0];  // 06046392 and r0,r2
    c.t = c.r[1] == c.r[2];  // 06046394 cmp/eq r2,r1
    if (c.t) { goto L_0604639A; }  // 06046396 bt 0x0604639A
    c.r[5] = ld32(0x06046478u);  // 06046398 mov.l 0x06046478,r5
L_0604639A:
    c.r[1] = ld32(0x0604647Cu);  // 0604639A mov.l 0x0604647C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060463A0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060463A0u) return; }  // 0604639C jsr @r1 ; mov r10,r4
    c.r[7] = ld32(0x06046480u);  // 060463A0 mov.l 0x06046480,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604645Eu);  // 060463A2 mov.w 0x0604645E,r1
    c.r[0] = 0x3u;  // 060463A4 mov #3,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06046460u);  // 060463A6 mov.w 0x06046460,r3
    c.r[10] = (uint32_t)(int16_t)ld16(0x06046462u);  // 060463A8 mov.w 0x06046462,r10
    c.r[4] = (uint32_t)(int16_t)ld16(0x06046458u);  // 060463AA mov.w 0x06046458,r4
    c.r[8] = ld32(0x06046484u);  // 060463AC mov.l 0x06046484,r8
    c.r[6] = 0x0u;  // 060463AE mov #0,r6
    c.r[9] = ld32(c.r[7]);  // 060463B0 mov.l @r7,r9
    c.r[5] = 0x3Eu;  // 060463B2 mov #62,r5
    c.r[9] += c.r[1];  // 060463B4 add r1,r9
    c.r[2] = c.r[9];  // 060463B6 mov r9,r2
    c.r[1] = ld32(0x06046488u);  // 060463B8 mov.l 0x06046488,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060463BA mov.b @r1,r1
    c.r[2] += 56;  // 060463BC add #56,r2
    c.r[1] >>= 2;  // 060463BE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060463C0 shlr r1
    c.r[1] >>= 2;  // 060463C2 shlr2 r1
    c.r[1] &= c.r[0];  // 060463C4 and r0,r1
    c.r[1] += c.r[3];  // 060463C6 add r3,r1
    st16(c.r[2], c.r[1]);  // 060463C8 mov.w r1,@r2
    c.r[2] = c.r[9];  // 060463CA mov r9,r2
    c.r[2] += 1;  // 060463CC add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060463CE mov.b @r2,r1
    c.r[0] = 0x40u;  // 060463D0 mov #64,r0
    c.r[1] |= c.r[0];  // 060463D2 or r0,r1
    st8(c.r[2], c.r[1]);  // 060463D4 mov.b r1,@r2
    c.r[1] = ld32(0x0604648Cu);  // 060463D6 mov.l 0x0604648C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060463D8 mov.b @r1,r1
    c.r[0] = 0x3u;  // 060463DA mov #3,r0
    c.r[7] = ld32(c.r[7]);  // 060463DC mov.l @r7,r7
    c.r[1] >>= 2;  // 060463DE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060463E0 shlr r1
    c.r[1] >>= 2;  // 060463E2 shlr2 r1
    c.r[1] &= c.r[0];  // 060463E4 and r0,r1
    c.r[1] += c.r[3];  // 060463E6 add r3,r1
    c.r[0] = c.r[7];  // 060463E8 mov r7,r0
    st16(c.r[0] + c.r[10], c.r[1]);  // 060463EA mov.w r1,@(r0,r10)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046464u);  // 060463EC mov.w 0x06046464,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060463EE mov.b @r2,r1
    c.r[7] = 0x10u;  // 060463F0 mov #16,r7
    c.r[1] &= c.r[0];  // 060463F2 and r0,r1
    { const uint32_t x = c.r[8]; c.pr = 0x060463F8u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060463F8u) return; }  // 060463F4 jsr @r8 ; mov.b r1,@r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06046466u);  // 060463F8 mov.w 0x06046466,r4
    c.r[7] = 0x10u;  // 060463FA mov #16,r7
    c.r[6] = 0x0u;  // 060463FC mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06046402u; c.r[5] = 0x3Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046402u) return; }  // 060463FE jsr @r8 ; mov #63,r5
    c.r[2] = ld32(0x06046490u);  // 06046402 mov.l 0x06046490,r2
    c.r[1] = 0x1u;  // 06046404 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06046406 mov.w r1,@r2
    c.r[0] = ld32(0x06046494u);  // 06046408 mov.l 0x06046494,r0
    c.r[15] = c.r[14]; goto L_06046442;  // 0604640A bra 0x06046442 ; mov r14,r15
L_0604640E:
    c.r[0] = c.r[11];  // 0604640E mov r11,r0
    c.t = c.r[0] == 0x2u;  // 06046410 cmp/eq #2,r0
    { const bool k = c.t; c.r[7] = 0x10u; if (k) { goto L_0604641C; } }  // 06046412 bt/s 0x0604641C ; mov #16,r7
    c.r[0] = ld32(0x06046494u);  // 06046416 mov.l 0x06046494,r0
    c.r[15] = c.r[14]; goto L_06046442;  // 06046418 bra 0x06046442 ; mov r14,r15
L_0604641C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06046468u);  // 0604641C mov.w 0x06046468,r4
    c.r[8] = ld32(0x06046484u);  // 0604641E mov.l 0x06046484,r8
    c.r[6] = 0x0u;  // 06046420 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06046426u; c.r[5] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046426u) return; }  // 06046422 jsr @r8 ; mov #58,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604646Au);  // 06046426 mov.w 0x0604646A,r4
    c.r[7] = 0x10u;  // 06046428 mov #16,r7
    c.r[6] = 0x0u;  // 0604642A mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06046430u; c.r[5] = 0x3Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046430u) return; }  // 0604642C jsr @r8 ; mov #59,r5
    c.r[2] = ld32(0x06046490u);  // 06046430 mov.l 0x06046490,r2
    c.r[1] = 0x1u;  // 06046432 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06046434 mov.w r1,@r2
    c.r[1] = ld32(0x06046470u);  // 06046436 mov.l 0x06046470,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046438 mov.b @r1,r0
    c.r[0] &= 0xE7u;  // 0604643A and #231,r0
    st8(c.r[1], c.r[0]);  // 0604643C mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604646Cu);  // 0604643E mov.w 0x0604646C,r0
    c.r[15] = c.r[14];  // 06046440 mov r14,r15
L_06046442:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06046442 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06046444 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06046446 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06046448 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604644A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604644C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604644E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046450 rts ; mov.l @r15+,r8
}

void f_06046498(SH2Context& c) {
    ran[1130] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046498 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604649A mov r15,r14
    c.r[2] = ld32(0x060464BCu);  // 0604649C mov.l 0x060464BC,r2
    c.r[1] = ld32(0x060464C0u);  // 0604649E mov.l 0x060464C0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060464A0 mov.w @r1,r1
    st16(c.r[2], c.r[1]);  // 060464A2 mov.w r1,@r2
    c.r[1] = ld32(0x060464C4u);  // 060464A4 mov.l 0x060464C4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060464A6 mov.w @r1,r1
    c.r[2] = ld32(0x060464C8u);  // 060464A8 mov.l 0x060464C8,r2
    st16(c.r[2], c.r[1]);  // 060464AA mov.w r1,@r2
    c.r[1] = ld32(0x060464CCu);  // 060464AC mov.l 0x060464CC,r1
    c.r[1] = ld32(c.r[1]);  // 060464AE mov.l @r1,r1
    c.r[2] = ld32(0x060464D0u);  // 060464B0 mov.l 0x060464D0,r2
    st32(c.r[2], c.r[1]);  // 060464B2 mov.l r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060464BAu);  // 060464B4 mov.w 0x060464BA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060464B6 rts ; mov.l @r15+,r14
}

void f_060464D4(SH2Context& c) {
    ran[1131] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060464D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060464D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060464D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060464DA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060464DC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060464DE mov r15,r14
    c.r[8] = 0x0u;  // 060464E0 mov #0,r8
    c.r[10] = ld32(0x0604657Cu);  // 060464E2 mov.l 0x0604657C,r10
    c.r[9] = 0xFu;  // 060464E4 mov #15,r9
L_060464E6:
    { const uint32_t x = c.r[10]; c.pr = 0x060464EAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060464EAu) return; }  // 060464E6 jsr @r10 ; mov r8,r4
    c.r[8] += 1;  // 060464EA add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 060464EC cmp/gt r9,r8
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_060464E6; } }  // 060464EE bf/s 0x060464E6 ; mov #0,r3
    c.r[1] = ld32(0x06046580u);  // 060464F2 mov.l 0x06046580,r1
    st8(c.r[1], c.r[3]);  // 060464F4 mov.b r3,@r1
    c.r[1] = ld32(0x06046584u);  // 060464F6 mov.l 0x06046584,r1
    st8(c.r[1], c.r[3]);  // 060464F8 mov.b r3,@r1
    c.r[1] = ld32(0x06046588u);  // 060464FA mov.l 0x06046588,r1
    c.r[2] = 0x0u;  // 060464FC mov #0,r2
    st16(c.r[1], c.r[2]);  // 060464FE mov.w r2,@r1
    c.r[1] = ld32(0x0604658Cu);  // 06046500 mov.l 0x0604658C,r1
    st16(c.r[1], c.r[2]);  // 06046502 mov.w r2,@r1
    c.r[1] = ld32(0x06046590u);  // 06046504 mov.l 0x06046590,r1
    st16(c.r[1], c.r[2]);  // 06046506 mov.w r2,@r1
    c.r[1] = ld32(0x06046594u);  // 06046508 mov.l 0x06046594,r1
    st8(c.r[1], c.r[3]);  // 0604650A mov.b r3,@r1
    c.r[1] = ld32(0x06046598u);  // 0604650C mov.l 0x06046598,r1
    st8(c.r[1], c.r[3]);  // 0604650E mov.b r3,@r1
    c.r[1] = ld32(0x0604659Cu);  // 06046510 mov.l 0x0604659C,r1
    st16(c.r[1], c.r[2]);  // 06046512 mov.w r2,@r1
    c.r[6] = ld32(0x060465A0u);  // 06046514 mov.l 0x060465A0,r6
    c.r[7] = c.r[6];  // 06046516 mov r6,r7
    c.r[7] += 68;  // 06046518 add #68,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604651A mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0604651C extu.b r1,r3
    c.r[2] = c.r[3];  // 0604651E mov r3,r2
    c.r[2] += 1;  // 06046520 add #1,r2
    c.r[1] = 0x10u;  // 06046522 mov #16,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06046524 cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0604656C; } }  // 06046526 bt/s 0x0604656C ; mov #1,r0
    c.r[3] <<= 2;  // 0604652A shll2 r3
    c.r[1] = ld32(c.r[6]);  // 0604652C mov.l @r6,r1
    c.r[3] += c.r[6];  // 0604652E add r6,r3
    c.r[1] += 1;  // 06046530 add #1,r1
    st32(c.r[3] + 4, c.r[1]);  // 06046532 mov.l r1,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06046534 mov.b @r7,r1
    c.r[1] += 1;  // 06046536 add #1,r1
    st8(c.r[7], c.r[1]);  // 06046538 mov.b r1,@r7
    c.r[1] = ld32(0x060465A4u);  // 0604653A mov.l 0x060465A4,r1
    c.r[2] = ld32(c.r[1]);  // 0604653C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0604653E mov r2,r1
    c.r[1] += 3;  // 06046540 add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046542 mov.b @r1,r3
    c.r[1] = c.r[2];  // 06046544 mov r2,r1
    c.r[1] += 2;  // 06046546 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046548 mov.b @r1,r1
    c.r[3] <<= 16;  // 0604654A shll16 r3
    c.r[3] <<= 8;  // 0604654C shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0604654E extu.b r1,r1
    c.r[1] <<= 16;  // 06046550 shll16 r1
    c.r[3] |= c.r[1];  // 06046552 or r1,r3
    c.r[1] = c.r[2];  // 06046554 mov r2,r1
    c.r[1] += 1;  // 06046556 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046558 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604655A extu.b r1,r1
    c.r[1] <<= 8;  // 0604655C shll8 r1
    c.r[3] |= c.r[1];  // 0604655E or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046560 mov.b @r2,r1
    c.r[0] = ld32(0x060465A8u);  // 06046562 mov.l 0x060465A8,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06046564 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06046566 or r1,r3
    c.r[2] += c.r[3];  // 06046568 add r3,r2
    st32(c.r[6], c.r[2]);  // 0604656A mov.l r2,@r6
L_0604656C:
    c.r[15] = c.r[14];  // 0604656C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604656E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06046570 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06046572 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06046574 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046576 rts ; mov.l @r15+,r8
}

void f_060465AC(SH2Context& c) {
    ran[1132] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060465AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060465AE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060465B0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060465B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060465B4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060465B6 mov r15,r14
    c.r[2] = ld32(0x06046708u);  // 060465B8 mov.l 0x06046708,r2
    c.r[9] = 0x0u;  // 060465BA mov #0,r9
    c.r[8] = ld32(0x0604670Cu);  // 060465BC mov.l 0x0604670C,r8
    c.r[7] = (uint32_t)(int16_t)ld16(0x060466F2u);  // 060465BE mov.w 0x060466F2,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x060466F4u);  // 060465C0 mov.w 0x060466F4,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060466F6u);  // 060465C2 mov.w 0x060466F6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060465C4 mov.b @r2,r1
    c.r[6] = 0x4u;  // 060465C6 mov #4,r6
    c.r[1] -= 1;  // 060465C8 add #-1,r1
    st8(c.r[2], c.r[1]);  // 060465CA mov.b r1,@r2
    c.r[1] = ld32(0x06046710u);  // 060465CC mov.l 0x06046710,r1
    st8(c.r[1], c.r[9]);  // 060465CE mov.b r9,@r1
    c.r[1] = ld32(0x06046714u);  // 060465D0 mov.l 0x06046714,r1
    c.r[1] = ld32(c.r[1]);  // 060465D2 mov.l @r1,r1
    c.r[2] = ld32(0x06046718u);  // 060465D4 mov.l 0x06046718,r2
    st32(c.r[2], c.r[1]);  // 060465D6 mov.l r1,@r2
    c.r[2] = ld32(0x0604671Cu);  // 060465D8 mov.l 0x0604671C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060466F8u);  // 060465DA mov.w 0x060466F8,r1
    st16(c.r[2], c.r[1]);  // 060465DC mov.w r1,@r2
    c.r[1] = ld32(0x06046720u);  // 060465DE mov.l 0x06046720,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060465E0 mov.w @r1,r1
    c.r[2] = ld32(0x06046724u);  // 060465E2 mov.l 0x06046724,r2
    st16(c.r[2], c.r[1]);  // 060465E4 mov.w r1,@r2
    c.r[1] = ld32(0x06046728u);  // 060465E6 mov.l 0x06046728,r1
    st32(c.r[8] + 32, c.r[1]);  // 060465E8 mov.l r1,@(32,r8)
    c.r[1] = ld32(0x0604672Cu);  // 060465EA mov.l 0x0604672C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060465F0u; c.r[4] = ld32(c.r[0] + c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060465F0u) return; }  // 060465EC jsr @r1 ; mov.l @(r0,r8),r4
    c.r[1] = c.r[8];  // 060465F0 mov r8,r1
    c.r[1] += 51;  // 060465F2 add #51,r1
    st8(c.r[1], c.r[9]);  // 060465F4 mov.b r9,@r1
    c.r[1] = c.r[8];  // 060465F6 mov r8,r1
    c.r[1] += 52;  // 060465F8 add #52,r1
    st8(c.r[1], c.r[9]);  // 060465FA mov.b r9,@r1
    c.r[1] = c.r[8];  // 060465FC mov r8,r1
    c.r[1] += 124;  // 060465FE add #124,r1
    c.r[2] = 0x0u;  // 06046600 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06046602 mov.l r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060466FAu);  // 06046604 mov.w 0x060466FA,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 06046606 mov.l r2,@(r0,r8)
    c.r[8] = ld32(0x06046730u);  // 06046608 mov.l 0x06046730,r8
    c.r[5] = 0x1Fu;  // 0604660A mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06046610u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046610u) return; }  // 0604660C jsr @r8 ; mov #0,r4
    c.r[5] = 0x1Fu;  // 06046610 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06046616u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046616u) return; }  // 06046612 jsr @r8 ; mov #1,r4
    c.r[5] = 0x1Fu;  // 06046616 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604661Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604661Cu) return; }  // 06046618 jsr @r8 ; mov #2,r4
    c.r[5] = 0x1Fu;  // 0604661C mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06046622u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046622u) return; }  // 0604661E jsr @r8 ; mov #3,r4
    c.r[3] = ld32(0x06046734u);  // 06046622 mov.l 0x06046734,r3
    c.r[2] = c.r[3];  // 06046624 mov r3,r2
    c.r[2] += 88;  // 06046626 add #88,r2
    c.r[1] = ld32(0x06046738u);  // 06046628 mov.l 0x06046738,r1
    c.r[7] = 0x0u;  // 0604662A mov #0,r7
    c.r[5] = 0x5u;  // 0604662C mov #5,r5
    c.r[6] = c.r[2];  // 0604662E mov r2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06046630 mov.w @r1,r1
    st16(c.r[2], c.r[1]);  // 06046632 mov.w r1,@r2
L_06046634:
    c.r[2] = c.r[3];  // 06046634 mov r3,r2
    c.r[2] += 24;  // 06046636 add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06046638 mov.w @r6,r1
    c.r[3] += 2;  // 0604663A add #2,r3
    c.r[7] += 1;  // 0604663C add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[5];  // 0604663E cmp/gt r5,r7
    { const bool k = !c.t; st16(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06046634; } }  // 06046640 bf/s 0x06046634 ; mov.w r1,@r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x060466FCu);  // 06046644 mov.w 0x060466FC,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x060466FEu);  // 06046646 mov.w 0x060466FE,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x060466FAu);  // 06046648 mov.w 0x060466FA,r8
    c.r[0] = ld32(0x0604673Cu);  // 0604664A mov.l 0x0604673C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06046650u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046650u) return; }  // 0604664C jsr @r0 ; mov r8,r4
    c.r[7] = 0x0u;  // 06046650 mov #0,r7
    c.r[2] = 0xDu;  // 06046652 mov #13,r2
    c.r[1] = ld32(0x06046740u);  // 06046654 mov.l 0x06046740,r1
    c.r[0] = 0x0u;  // 06046656 mov #0,r0
L_06046658:
    st16(c.r[0] + c.r[1], c.r[8]);  // 06046658 mov.w r8,@(r0,r1)
    c.r[7] += 1;  // 0604665A add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[2];  // 0604665C cmp/gt r2,r7
    { const bool k = !c.t; c.r[0] += 2; if (k) { SH2_POLL(c); goto L_06046658; } }  // 0604665E bf/s 0x06046658 ; add #2,r0
    c.r[2] = ld32(0x06046744u);  // 06046662 mov.l 0x06046744,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060466FAu);  // 06046664 mov.w 0x060466FA,r1
    st16(c.r[2], c.r[1]);  // 06046666 mov.w r1,@r2
    c.r[6] = ld32(0x06046748u);  // 06046668 mov.l 0x06046748,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604666A mov.b @r6,r5
    c.r[10] = 0x1u;  // 0604666C mov #1,r10
    c.r[3] = ld32(0x0604674Cu);  // 0604666E mov.l 0x0604674C,r3
    c.r[7] = c.r[5];  // 06046670 mov r5,r7
    c.r[7] >>= 2;  // 06046672 shlr2 r7
    c.r[7] >>= 2;  // 06046674 shlr2 r7
    c.r[7] >>= 2;  // 06046676 shlr2 r7
    c.r[7] &= c.r[10];  // 06046678 and r10,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604667A tst r7,r7
    if (c.t) { goto L_06046680; }  // 0604667C bt 0x06046680
    c.r[3] = ld32(0x06046750u);  // 0604667E mov.l 0x06046750,r3
L_06046680:
    c.r[2] = ld32(0x06046754u);  // 06046680 mov.l 0x06046754,r2
    if (c.t) { goto L_06046686; }  // 06046682 bt 0x06046686
    c.r[2] = ld32(0x06046758u);  // 06046684 mov.l 0x06046758,r2
L_06046686:
    c.r[1] = ld32(0x0604675Cu);  // 06046686 mov.l 0x0604675C,r1
    if (c.t) { goto L_0604668C; }  // 06046688 bt 0x0604668C
    c.r[1] = ld32(0x06046760u);  // 0604668A mov.l 0x06046760,r1
L_0604668C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604668C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604668E extu.b r1,r1
    c.r[0] = c.r[1];  // 06046690 mov r1,r0
    c.r[0] >>= 2;  // 06046692 shlr2 r0
    c.r[0] >>= 2;  // 06046694 shlr2 r0
    c.r[0] &= 0x1u;  // 06046696 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06046698 tst r0,r0
    if (c.t) { goto L_06046764; }  // 0604669A bt 0x06046764
    c.r[1] = c.r[2];  // 0604669C mov r2,r1
    c.r[1] += 6;  // 0604669E add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060466A0 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060466A2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060466A4 tst r1,r1
    if (c.t) { goto L_060466AE; }  // 060466A6 bt 0x060466AE
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060466A8 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu; goto L_060466B2;  // 060466AA bra 0x060466B2 ; extu.b r1,r2
L_060466AE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060466AE mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060466B0 extu.b r1,r2
L_060466B2:
    c.r[2] >>= 2;  // 060466B2 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060466B4 shlr r2
    c.r[2] >>= 2;  // 060466B6 shlr2 r2
    c.r[1] = 0x4u;  // 060466B8 mov #4,r1
    c.t = c.r[2] > c.r[1];  // 060466BA cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060466C4; } }  // 060466BC bf/s 0x060466C4 ; mov r2,r1
    goto L_060467F0;  // 060466C0 bra 0x060467F0 ; nop
L_060466C4:
    c.r[1] += c.r[1];  // 060466C4 add r1,r1
    c.r[0] = 0x060466D0u;  // 060466C6 mova 0x060466D0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060466C8 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060466CA add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060466DAu: goto L_060466DA; case 0x060466E0u: goto L_060466E0; case 0x060466E6u: goto L_060466E6; case 0x060466ECu: goto L_060466EC; default: sh2_call(c, x); return; } }  // 060466CC jmp @r0 ; nop
L_060466DA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046700u);  // 060466DA mov.w 0x06046700,r0
    c.r[15] = c.r[14]; goto L_060467F4;  // 060466DC bra 0x060467F4 ; mov r14,r15
L_060466E0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046702u);  // 060466E0 mov.w 0x06046702,r0
    c.r[15] = c.r[14]; goto L_060467F4;  // 060466E2 bra 0x060467F4 ; mov r14,r15
L_060466E6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046704u);  // 060466E6 mov.w 0x06046704,r0
    c.r[15] = c.r[14]; goto L_060467F4;  // 060466E8 bra 0x060467F4 ; mov r14,r15
L_060466EC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046706u);  // 060466EC mov.w 0x06046706,r0
    c.r[15] = c.r[14]; goto L_060467F4;  // 060466EE bra 0x060467F4 ; mov r14,r15
L_06046764:
    c.r[0] = c.r[1];  // 06046764 mov r1,r0
    c.r[0] >>= 2;  // 06046766 shlr2 r0
    c.r[0] &= 0x3u;  // 06046768 and #3,r0
    c.r[1] = 0x1u;  // 0604676A mov #1,r1
    c.t = c.r[0] > c.r[1];  // 0604676C cmp/hi r1,r0
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_060467F0; } }  // 0604676E bt/s 0x060467F0 ; tst r7,r7
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { goto L_060467F0; } }  // 06046772 bf/s 0x060467F0 ; mov r5,r0
    c.r[0] &= 0xDFu;  // 06046776 and #223,r0
    c.r[0] |= 0x40u;  // 06046778 or #64,r0
    st8(c.r[6], c.r[0]);  // 0604677A mov.b r0,@r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604677C mov.w @r6,r1
    c.r[0] = c.r[1];  // 0604677E mov r1,r0
    c.r[0] >>= 2;  // 06046780 shlr2 r0
    c.r[0] >>= 2;  // 06046782 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06046784 shlr r0
    c.r[0] >>= 2;  // 06046786 shlr2 r0
    c.r[0] &= 0x3u;  // 06046788 and #3,r0
    c.r[1] = 0x3u;  // 0604678A mov #3,r1
    c.t = c.r[0] > c.r[1];  // 0604678C cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_060467F0; } }  // 0604678E bt/s 0x060467F0 ; mov r0,r1
    c.r[1] += c.r[1];  // 06046792 add r1,r1
    c.r[0] = 0x060467A0u;  // 06046794 mova 0x060467A0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06046796 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06046798 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060467A8u: goto L_060467A8; case 0x060467C0u: goto L_060467C0; case 0x060467D8u: goto L_060467D8; default: sh2_call(c, x); return; } }  // 0604679A jmp @r0 ; nop
L_060467A8:
    c.r[2] += 6;  // 060467A8 add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060467AA mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060467AC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060467AE tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060467BA; } }  // 060467B0 bt/s 0x060467BA ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046800u);  // 060467B4 mov.w 0x06046800,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060467F6;  // 060467B6 bra 0x060467F6 ; lds.l @r15+,pr
L_060467BA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046802u);  // 060467BA mov.w 0x06046802,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060467F6;  // 060467BC bra 0x060467F6 ; lds.l @r15+,pr
L_060467C0:
    c.r[2] += 6;  // 060467C0 add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060467C2 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060467C4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060467C6 tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060467D2; } }  // 060467C8 bt/s 0x060467D2 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046804u);  // 060467CC mov.w 0x06046804,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060467F6;  // 060467CE bra 0x060467F6 ; lds.l @r15+,pr
L_060467D2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046806u);  // 060467D2 mov.w 0x06046806,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060467F6;  // 060467D4 bra 0x060467F6 ; lds.l @r15+,pr
L_060467D8:
    c.r[2] += 6;  // 060467D8 add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060467DA mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060467DC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060467DE tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060467EA; } }  // 060467E0 bt/s 0x060467EA ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046808u);  // 060467E4 mov.w 0x06046808,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060467F6;  // 060467E6 bra 0x060467F6 ; lds.l @r15+,pr
L_060467EA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604680Au);  // 060467EA mov.w 0x0604680A,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060467F6;  // 060467EC bra 0x060467F6 ; lds.l @r15+,pr
L_060467F0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604680Cu);  // 060467F0 mov.w 0x0604680C,r0
    c.r[15] = c.r[14];  // 060467F2 mov r14,r15
L_060467F4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060467F4 lds.l @r15+,pr
L_060467F6:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060467F6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060467F8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060467FA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060467FC rts ; mov.l @r15+,r8
}

void f_06046810(SH2Context& c) {
    ran[1133] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046810 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06046812 mov r15,r14
    c.r[1] = ld32(0x06046840u);  // 06046814 mov.l 0x06046840,r1
    c.r[3] = ld32(c.r[1]);  // 06046816 mov.l @r1,r3
    c.r[7] = ld32(0x06046844u);  // 06046818 mov.l 0x06046844,r7
    c.r[1] = c.r[3];  // 0604681A mov r3,r1
    c.r[1] += 1;  // 0604681C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604681E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06046820 extu.b r1,r0
    c.r[0] += c.r[0];  // 06046822 add r0,r0
    c.r[1] = c.r[3];  // 06046824 mov r3,r1
    c.r[1] += 2;  // 06046826 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046828 mov.b @r1,r2
    c.r[3] += 3;  // 0604682A add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0604682C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604682E mov.b @r3,r1
    c.r[2] <<= 8;  // 06046830 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046832 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06046834 or r1,r2
    st16(c.r[0] + c.r[7], c.r[2]);  // 06046836 mov.w r2,@(r0,r7)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604683Eu);  // 06046838 mov.w 0x0604683E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604683A rts ; mov.l @r15+,r14
}

void f_06046848(SH2Context& c) {
    ran[1134] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046848 mov.l r14,@-r15
    c.r[1] = ld32(0x06046884u);  // 0604684A mov.l 0x06046884,r1
    c.r[3] = ld32(c.r[1]);  // 0604684C mov.l @r1,r3
    c.r[1] = c.r[3];  // 0604684E mov r3,r1
    c.r[1] += 1;  // 06046850 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046852 mov.b @r1,r1
    c.r[7] = ld32(0x06046888u);  // 06046854 mov.l 0x06046888,r7
    c.r[0] = c.r[1] & 0xFFu;  // 06046856 extu.b r1,r0
    c.r[0] += c.r[0];  // 06046858 add r0,r0
    c.r[1] = c.r[3];  // 0604685A mov r3,r1
    c.r[1] += 2;  // 0604685C add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604685E mov.b @r1,r2
    c.r[3] += 3;  // 06046860 add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06046862 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046864 mov.b @r3,r1
    c.r[2] <<= 8;  // 06046866 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046868 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604686A or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0604686C mov.w @(r0,r7),r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0604686E exts.w r2,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06046870 cmp/gt r2,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604687A; } }  // 06046872 bf/s 0x0604687A ; mov r15,r14
    c.r[0] = 0x0u; goto L_0604687C;  // 06046876 bra 0x0604687C ; mov #0,r0
L_0604687A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046882u);  // 0604687A mov.w 0x06046882,r0
L_0604687C:
    c.r[15] = c.r[14];  // 0604687C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604687E rts ; mov.l @r15+,r14
}

void f_0604688C(SH2Context& c) {
    ran[1135] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604688C mov.l r14,@-r15
    c.r[1] = ld32(0x060468ACu);  // 0604688E mov.l 0x060468AC,r1
    c.r[1] = ld32(c.r[1]);  // 06046890 mov.l @r1,r1
    c.r[14] = c.r[15];  // 06046892 mov r15,r14
    c.r[1] += 1;  // 06046894 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046896 mov.b @r1,r1
    c.r[2] = ld32(0x060468B0u);  // 06046898 mov.l 0x060468B0,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0604689A extu.b r1,r0
    c.r[0] += c.r[0];  // 0604689C add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0604689E mov.w @(r0,r2),r1
    c.r[1] += 1;  // 060468A0 add #1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 060468A2 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060468AAu);  // 060468A4 mov.w 0x060468AA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060468A6 rts ; mov.l @r15+,r14
}

void f_060468B4(SH2Context& c) {
    ran[1136] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060468B4 mov.l r14,@-r15
    c.r[1] = ld32(0x060468D4u);  // 060468B6 mov.l 0x060468D4,r1
    c.r[1] = ld32(c.r[1]);  // 060468B8 mov.l @r1,r1
    c.r[14] = c.r[15];  // 060468BA mov r15,r14
    c.r[1] += 1;  // 060468BC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060468BE mov.b @r1,r1
    c.r[2] = ld32(0x060468D8u);  // 060468C0 mov.l 0x060468D8,r2
    c.r[0] = c.r[1] & 0xFFu;  // 060468C2 extu.b r1,r0
    c.r[0] += c.r[0];  // 060468C4 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060468C6 mov.w @(r0,r2),r1
    c.r[1] -= 1;  // 060468C8 add #-1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 060468CA mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060468D2u);  // 060468CC mov.w 0x060468D2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060468CE rts ; mov.l @r15+,r14
}

void f_060468DC(SH2Context& c) {
    ran[1137] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060468DC mov.l r14,@-r15
    c.r[1] = ld32(0x0604691Cu);  // 060468DE mov.l 0x0604691C,r1
    c.r[3] = ld32(c.r[1]);  // 060468E0 mov.l @r1,r3
    c.r[1] = c.r[3];  // 060468E2 mov r3,r1
    c.r[1] += 1;  // 060468E4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060468E6 mov.b @r1,r1
    c.r[7] = ld32(0x06046920u);  // 060468E8 mov.l 0x06046920,r7
    c.r[0] = c.r[1] & 0xFFu;  // 060468EA extu.b r1,r0
    c.r[0] += c.r[0];  // 060468EC add r0,r0
    c.r[1] = c.r[3];  // 060468EE mov r3,r1
    c.r[1] += 2;  // 060468F0 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060468F2 mov.b @r1,r2
    c.r[3] += 3;  // 060468F4 add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060468F6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060468F8 mov.b @r3,r1
    c.r[2] <<= 8;  // 060468FA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060468FC extu.b r1,r1
    c.r[2] |= c.r[1];  // 060468FE or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06046900 mov.w @(r0,r7),r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06046902 exts.w r2,r2
    c.t = c.r[1] == c.r[2];  // 06046904 cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06046910; } }  // 06046906 bt/s 0x06046910 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046918u);  // 0604690A mov.w 0x06046918,r0
    c.r[15] = c.r[14]; goto L_06046914;  // 0604690C bra 0x06046914 ; mov r14,r15
L_06046910:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604691Au);  // 06046910 mov.w 0x0604691A,r0
    c.r[15] = c.r[14];  // 06046912 mov r14,r15
L_06046914:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046914 rts ; mov.l @r15+,r14
}

void f_06046924(SH2Context& c) {
    ran[1138] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046924 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06046926 mov r15,r14
    c.r[0] = ld32(0x06046930u);  // 06046928 mov.l 0x06046930,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604692A rts ; mov.l @r15+,r14
}

void f_06046934(SH2Context& c) {
    ran[1139] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06046934 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06046936 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06046938 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604693A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604693C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604693E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06046940 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06046942 mov r15,r14
    c.r[1] = ld32(0x060469BCu);  // 06046944 mov.l 0x060469BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046946 mov.b @r1,r1
    c.r[2] = 0xBu;  // 06046948 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604694A extu.b r1,r1
    c.r[1] -= 1;  // 0604694C add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0604694E mul.l r2,r1
    c.r[3] = ld32(0x060469C0u);  // 06046950 mov.l 0x060469C0,r3
    c.r[1] = ld32(0x060469C4u);  // 06046952 mov.l 0x060469C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046954 mov.b @r1,r1
    c.r[9] = c.macl;  // 06046956 sts macl,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06046958 extu.b r1,r1
    c.r[9] += c.r[1];  // 0604695A add r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604695C mov.w @r3,r1
    c.r[2] = ld32(0x060469C8u);  // 0604695E mov.l 0x060469C8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06046960 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06046962 cmp/eq r2,r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06046994; } }  // 06046964 bt/s 0x06046994 ; mov #0,r10
    c.r[11] = c.r[3];  // 06046968 mov r3,r11
    c.r[12] = ld32(0x060469CCu);  // 0604696A mov.l 0x060469CC,r12
    c.r[8] = 0x0u;  // 0604696C mov #0,r8
    c.r[0] = c.r[8];  // 0604696E mov r8,r0
L_06046970:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 06046970 mov.w @(r0,r11),r4
    c.r[5] = 0x2u;  // 06046972 mov #2,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06046978u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046978u) return; }  // 06046974 jsr @r12 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 06046978 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604697A tst r1,r1
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_06046984; } }  // 0604697C bt/s 0x06046984 ; tst r9,r9
    { const bool k = c.t; c.r[9] -= 1; if (k) { goto L_06046994; } }  // 06046980 bt/s 0x06046994 ; add #-1,r9
L_06046984:
    c.r[8] += 2;  // 06046984 add #2,r8
    c.r[0] = c.r[8];  // 06046986 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 06046988 mov.w @(r0,r11),r1
    c.r[2] = ld32(0x060469C8u);  // 0604698A mov.l 0x060469C8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604698C extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0604698E cmp/eq r2,r1
    { const bool k = !c.t; c.r[10] += 1; if (k) { SH2_POLL(c); goto L_06046970; } }  // 06046990 bf/s 0x06046970 ; add #1,r10
L_06046994:
    c.r[10] += c.r[10];  // 06046994 add r10,r10
    c.r[1] = ld32(0x060469C0u);  // 06046996 mov.l 0x060469C0,r1
    c.r[15] = c.r[14];  // 06046998 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604699A lds.l @r15+,pr
    c.r[0] = c.r[10];  // 0604699C mov r10,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604699E mov.w @(r0,r1),r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060469A0 mov.l @r15+,r14
    c.r[2] += c.r[2];  // 060469A2 add r2,r2
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060469A4 mov.l @r15+,r12
    c.r[2] += 1;  // 060469A6 add #1,r2
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060469A8 mov.l @r15+,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x060469BAu);  // 060469AA mov.w 0x060469BA,r1
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060469AC mov.l @r15+,r10
    c.r[2] |= c.r[1];  // 060469AE or r1,r2
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060469B0 mov.l @r15+,r9
    c.r[1] = c.r[2] & 0xFFFFu;  // 060469B2 extu.w r2,r1
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060469B4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 060469B6 rts ; mov r1,r0
}

void f_060469E8(SH2Context& c) {
    ran[1140] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060469E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060469EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060469EC sts.l pr,@-r15
    c.r[15] -= 24;  // 060469EE add #-24,r15
    c.r[14] = c.r[15];  // 060469F0 mov r15,r14
    c.r[5] = ld32(0x06046A54u);  // 060469F2 mov.l 0x06046A54,r5
    c.r[1] = ld32(0x06046A58u);  // 060469F4 mov.l 0x06046A58,r1
    c.r[6] = 0x15u;  // 060469F6 mov #21,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060469FCu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060469FCu) return; }  // 060469F8 jsr @r1 ; mov r14,r4
    c.r[3] = ld32(0x06046A5Cu);  // 060469FC mov.l 0x06046A5C,r3
    c.r[8] = c.r[3];  // 060469FE mov r3,r8
    c.r[1] = ld32(0x06046A60u);  // 06046A00 mov.l 0x06046A60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046A02 mov.b @r1,r1
    c.r[2] = 0xBu;  // 06046A04 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046A06 extu.b r1,r1
    c.r[1] -= 1;  // 06046A08 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06046A0A mul.l r2,r1
    c.r[8] += 12;  // 06046A0C add #12,r8
    c.r[3] += 10;  // 06046A0E add #10,r3
    c.r[1] = ld32(0x06046A64u);  // 06046A10 mov.l 0x06046A64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046A12 mov.b @r1,r1
    c.r[2] = c.macl;  // 06046A14 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046A16 extu.b r1,r1
    c.r[2] += c.r[1];  // 06046A18 add r1,r2
    st16(c.r[8], c.r[2]);  // 06046A1A mov.w r2,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06046A1C mov.w @r8,r1
    c.r[4] = ld32(0x06046A68u);  // 06046A1E mov.l 0x06046A68,r4
    c.r[0] = c.r[1] & 0xFFFFu;  // 06046A20 extu.w r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06046A22 mov.b @(r0,r14),r1
    c.r[5] = 0x28u;  // 06046A24 mov #40,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06046A26 extu.b r1,r1
    st16(c.r[3], c.r[1]);  // 06046A28 mov.w r1,@r3
    c.r[0] = ld32(0x06046A6Cu);  // 06046A2A mov.l 0x06046A6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06046A30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046A30u) return; }  // 06046A2C jsr @r0 ; nop
    c.r[2] = c.r[0];  // 06046A30 mov r0,r2
    c.r[1] = ld32(0x06046A70u);  // 06046A32 mov.l 0x06046A70,r1
    c.r[0] = ld32(0x06046A74u);  // 06046A34 mov.l 0x06046A74,r0
    c.r[6] = 0x2u;  // 06046A36 mov #2,r6
    c.r[5] = c.r[2];  // 06046A38 mov r2,r5
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06046A3A mov.w @r8,r7
    c.r[4] = 0x13u;  // 06046A3C mov #19,r4
    c.r[7] = c.r[7] & 0xFFFFu;  // 06046A3E extu.w r7,r7
    { const uint32_t x = c.r[0]; c.pr = 0x06046A44u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046A44u) return; }  // 06046A40 jsr @r0 ; mov.l r1,@-r15
    c.r[14] += 24;  // 06046A44 add #24,r14
    c.r[15] = c.r[14];  // 06046A46 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06046A48 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06046A4A mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046A52u);  // 06046A4C mov.w 0x06046A52,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046A4E rts ; mov.l @r15+,r8
}

void f_06046A78(SH2Context& c) {
    ran[1141] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06046A78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06046A7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046A7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06046A7E sts.l pr,@-r15
    c.r[1] = ld32(0x06046BCCu);  // 06046A80 mov.l 0x06046BCC,r1
    c.r[1] = ld32(c.r[1]);  // 06046A82 mov.l @r1,r1
    c.r[1] += 1;  // 06046A84 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046A86 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06046A88 extu.b r1,r7
    c.r[0] = c.r[7];  // 06046A8A mov r7,r0
    c.t = c.r[0] == 0x1u;  // 06046A8C cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06046A9A; } }  // 06046A8E bt/s 0x06046A9A ; mov r15,r14
    c.t = c.r[0] == 0x2u;  // 06046A92 cmp/eq #2,r0
    if (!c.t) { goto L_06046ABA; }  // 06046A94 bf 0x06046ABA
    goto L_06046AAA;  // 06046A96 bra 0x06046AAA ; nop
L_06046A9A:
    c.r[3] = ld32(0x06046BD0u);  // 06046A9A mov.l 0x06046BD0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046A9C mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06046A9E extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06046AA0 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06046ABA; } }  // 06046AA2 bt/s 0x06046ABA ; mov r2,r1
    c.r[1] -= 1; goto L_06046AB8;  // 06046AA6 bra 0x06046AB8 ; add #-1,r1
L_06046AAA:
    c.r[3] = ld32(0x06046BD0u);  // 06046AAA mov.l 0x06046BD0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046AAC mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06046AAE extu.b r2,r1
    c.t = c.r[1] > c.r[7];  // 06046AB0 cmp/hi r7,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06046ABA; } }  // 06046AB2 bt/s 0x06046ABA ; mov r2,r1
    c.r[1] += 1;  // 06046AB6 add #1,r1
L_06046AB8:
    st8(c.r[3], c.r[1]);  // 06046AB8 mov.b r1,@r3
L_06046ABA:
    c.r[1] = ld32(0x06046BD0u);  // 06046ABA mov.l 0x06046BD0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046ABC mov.b @r1,r0
    c.r[7] = 0x3u;  // 06046ABE mov #3,r7
    c.r[3] = ld32(0x06046BD4u);  // 06046AC0 mov.l 0x06046BD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046B92u);  // 06046AC2 mov.w 0x06046B92,r2
    c.r[7] &= c.r[0];  // 06046AC4 and r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06046AC6 tst r7,r7
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046AD2; } }  // 06046AC8 bf/s 0x06046AD2 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046B94u);  // 06046ACC mov.w 0x06046B94,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046AD8;  // 06046ACE bra 0x06046AD8 ; mov.w r1,@(r0,r2)
L_06046AD2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046B96u);  // 06046AD2 mov.w 0x06046B96,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046AD4 mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046BD4u);  // 06046AD6 mov.l 0x06046BD4,r3
L_06046AD8:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046B98u);  // 06046AD8 mov.w 0x06046B98,r2
    c.t = (c.r[7] & c.r[7]) == 0;  // 06046ADA tst r7,r7
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046AE6; } }  // 06046ADC bf/s 0x06046AE6 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046B9Au);  // 06046AE0 mov.w 0x06046B9A,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046AEA;  // 06046AE2 bra 0x06046AEA ; mov.w r1,@(r0,r2)
L_06046AE6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046B9Cu);  // 06046AE6 mov.w 0x06046B9C,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046AE8 mov.w r1,@(r0,r2)
L_06046AEA:
    c.r[3] = ld32(0x06046BD4u);  // 06046AEA mov.l 0x06046BD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046B9Eu);  // 06046AEC mov.w 0x06046B9E,r2
    c.t = (c.r[7] & c.r[7]) == 0;  // 06046AEE tst r7,r7
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046AFA; } }  // 06046AF0 bf/s 0x06046AFA ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BA0u);  // 06046AF4 mov.w 0x06046BA0,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B00;  // 06046AF6 bra 0x06046B00 ; mov.w r1,@(r0,r2)
L_06046AFA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BA2u);  // 06046AFA mov.w 0x06046BA2,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046AFC mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046BD4u);  // 06046AFE mov.l 0x06046BD4,r3
L_06046B00:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BA4u);  // 06046B00 mov.w 0x06046BA4,r2
    c.t = (c.r[7] & c.r[7]) == 0;  // 06046B02 tst r7,r7
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046B0E; } }  // 06046B04 bf/s 0x06046B0E ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BA6u);  // 06046B08 mov.w 0x06046BA6,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B12;  // 06046B0A bra 0x06046B12 ; mov.w r1,@(r0,r2)
L_06046B0E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BA8u);  // 06046B0E mov.w 0x06046BA8,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046B10 mov.w r1,@(r0,r2)
L_06046B12:
    c.r[3] = ld32(0x06046BD4u);  // 06046B12 mov.l 0x06046BD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BAAu);  // 06046B14 mov.w 0x06046BAA,r2
    c.r[0] = c.r[7];  // 06046B16 mov r7,r0
    c.t = c.r[0] == 0x1u;  // 06046B18 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046B24; } }  // 06046B1A bf/s 0x06046B24 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BACu);  // 06046B1E mov.w 0x06046BAC,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B2A;  // 06046B20 bra 0x06046B2A ; mov.w r1,@(r0,r2)
L_06046B24:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BAEu);  // 06046B24 mov.w 0x06046BAE,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046B26 mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046BD4u);  // 06046B28 mov.l 0x06046BD4,r3
L_06046B2A:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BB0u);  // 06046B2A mov.w 0x06046BB0,r2
    c.r[0] = c.r[7];  // 06046B2C mov r7,r0
    c.t = c.r[0] == 0x1u;  // 06046B2E cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046B3A; } }  // 06046B30 bf/s 0x06046B3A ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BB2u);  // 06046B34 mov.w 0x06046BB2,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B3E;  // 06046B36 bra 0x06046B3E ; mov.w r1,@(r0,r2)
L_06046B3A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BB4u);  // 06046B3A mov.w 0x06046BB4,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046B3C mov.w r1,@(r0,r2)
L_06046B3E:
    c.r[3] = ld32(0x06046BD4u);  // 06046B3E mov.l 0x06046BD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BB6u);  // 06046B40 mov.w 0x06046BB6,r2
    c.r[0] = c.r[7];  // 06046B42 mov r7,r0
    c.t = c.r[0] == 0x1u;  // 06046B44 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046B50; } }  // 06046B46 bf/s 0x06046B50 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BB8u);  // 06046B4A mov.w 0x06046BB8,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B56;  // 06046B4C bra 0x06046B56 ; mov.w r1,@(r0,r2)
L_06046B50:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BBAu);  // 06046B50 mov.w 0x06046BBA,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046B52 mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046BD4u);  // 06046B54 mov.l 0x06046BD4,r3
L_06046B56:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BBCu);  // 06046B56 mov.w 0x06046BBC,r2
    c.r[0] = c.r[7];  // 06046B58 mov r7,r0
    c.t = c.r[0] == 0x1u;  // 06046B5A cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046B66; } }  // 06046B5C bf/s 0x06046B66 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BBEu);  // 06046B60 mov.w 0x06046BBE,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B6A;  // 06046B62 bra 0x06046B6A ; mov.w r1,@(r0,r2)
L_06046B66:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BC0u);  // 06046B66 mov.w 0x06046BC0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046B68 mov.w r1,@(r0,r2)
L_06046B6A:
    c.r[3] = ld32(0x06046BD4u);  // 06046B6A mov.l 0x06046BD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BC2u);  // 06046B6C mov.w 0x06046BC2,r2
    c.r[0] = c.r[7];  // 06046B6E mov r7,r0
    c.t = c.r[0] == 0x2u;  // 06046B70 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046B7C; } }  // 06046B72 bf/s 0x06046B7C ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BC4u);  // 06046B76 mov.w 0x06046BC4,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046B82;  // 06046B78 bra 0x06046B82 ; mov.w r1,@(r0,r2)
L_06046B7C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BC6u);  // 06046B7C mov.w 0x06046BC6,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046B7E mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046BD4u);  // 06046B80 mov.l 0x06046BD4,r3
L_06046B82:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046BC8u);  // 06046B82 mov.w 0x06046BC8,r2
    c.r[0] = c.r[7];  // 06046B84 mov r7,r0
    c.t = c.r[0] == 0x2u;  // 06046B86 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046BD8; } }  // 06046B88 bf/s 0x06046BD8 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046BCAu);  // 06046B8C mov.w 0x06046BCA,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046BDC;  // 06046B8E bra 0x06046BDC ; mov.w r1,@(r0,r2)
L_06046BD8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CAAu);  // 06046BD8 mov.w 0x06046CAA,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046BDA mov.w r1,@(r0,r2)
L_06046BDC:
    c.r[3] = ld32(0x06046CD4u);  // 06046BDC mov.l 0x06046CD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046CACu);  // 06046BDE mov.w 0x06046CAC,r2
    c.r[0] = c.r[7];  // 06046BE0 mov r7,r0
    c.t = c.r[0] == 0x2u;  // 06046BE2 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046BEE; } }  // 06046BE4 bf/s 0x06046BEE ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CAEu);  // 06046BE8 mov.w 0x06046CAE,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046BF4;  // 06046BEA bra 0x06046BF4 ; mov.w r1,@(r0,r2)
L_06046BEE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CB0u);  // 06046BEE mov.w 0x06046CB0,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046BF0 mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046CD4u);  // 06046BF2 mov.l 0x06046CD4,r3
L_06046BF4:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046CB2u);  // 06046BF4 mov.w 0x06046CB2,r2
    c.r[0] = c.r[7];  // 06046BF6 mov r7,r0
    c.t = c.r[0] == 0x2u;  // 06046BF8 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046C04; } }  // 06046BFA bf/s 0x06046C04 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CB4u);  // 06046BFE mov.w 0x06046CB4,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046C08;  // 06046C00 bra 0x06046C08 ; mov.w r1,@(r0,r2)
L_06046C04:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CB6u);  // 06046C04 mov.w 0x06046CB6,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046C06 mov.w r1,@(r0,r2)
L_06046C08:
    c.r[3] = ld32(0x06046CD4u);  // 06046C08 mov.l 0x06046CD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046CB8u);  // 06046C0A mov.w 0x06046CB8,r2
    c.r[0] = c.r[7];  // 06046C0C mov r7,r0
    c.t = c.r[0] == 0x3u;  // 06046C0E cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046C1A; } }  // 06046C10 bf/s 0x06046C1A ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CBAu);  // 06046C14 mov.w 0x06046CBA,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046C20;  // 06046C16 bra 0x06046C20 ; mov.w r1,@(r0,r2)
L_06046C1A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CBCu);  // 06046C1A mov.w 0x06046CBC,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046C1C mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046CD4u);  // 06046C1E mov.l 0x06046CD4,r3
L_06046C20:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046CBEu);  // 06046C20 mov.w 0x06046CBE,r2
    c.r[0] = c.r[7];  // 06046C22 mov r7,r0
    c.t = c.r[0] == 0x3u;  // 06046C24 cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046C30; } }  // 06046C26 bf/s 0x06046C30 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CC0u);  // 06046C2A mov.w 0x06046CC0,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046C34;  // 06046C2C bra 0x06046C34 ; mov.w r1,@(r0,r2)
L_06046C30:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CC2u);  // 06046C30 mov.w 0x06046CC2,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046C32 mov.w r1,@(r0,r2)
L_06046C34:
    c.r[3] = ld32(0x06046CD4u);  // 06046C34 mov.l 0x06046CD4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046CC4u);  // 06046C36 mov.w 0x06046CC4,r2
    c.r[0] = c.r[7];  // 06046C38 mov r7,r0
    c.t = c.r[0] == 0x3u;  // 06046C3A cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046C46; } }  // 06046C3C bf/s 0x06046C46 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CC6u);  // 06046C40 mov.w 0x06046CC6,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046C4C;  // 06046C42 bra 0x06046C4C ; mov.w r1,@(r0,r2)
L_06046C46:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CC8u);  // 06046C46 mov.w 0x06046CC8,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046C48 mov.w r1,@(r0,r2)
    c.r[3] = ld32(0x06046CD4u);  // 06046C4A mov.l 0x06046CD4,r3
L_06046C4C:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06046CCAu);  // 06046C4C mov.w 0x06046CCA,r2
    c.r[0] = c.r[7];  // 06046C4E mov r7,r0
    c.t = c.r[0] == 0x3u;  // 06046C50 cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06046C5C; } }  // 06046C52 bf/s 0x06046C5C ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CCCu);  // 06046C56 mov.w 0x06046CCC,r1
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06046C60;  // 06046C58 bra 0x06046C60 ; mov.w r1,@(r0,r2)
L_06046C5C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06046CCEu);  // 06046C5C mov.w 0x06046CCE,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06046C5E mov.w r1,@(r0,r2)
L_06046C60:
    c.r[8] = ld32(0x06046CD8u);  // 06046C60 mov.l 0x06046CD8,r8
    c.r[1] = ld32(0x06046CDCu);  // 06046C62 mov.l 0x06046CDC,r1
    c.r[5] = 0x0u;  // 06046C64 mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06046C66 mov.b @r8,r6
    c.r[4] = 0x0u;  // 06046C68 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06046C6A extu.b r6,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06046C70u; c.r[6] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046C70u) return; }  // 06046C6C jsr @r1 ; add #1,r6
    c.r[4] = ld32(0x06046CE0u);  // 06046C70 mov.l 0x06046CE0,r4
    c.r[9] = ld32(0x06046CE4u);  // 06046C72 mov.l 0x06046CE4,r9
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06046C74 mov.b @r8,r8
    c.r[5] = 0x17u;  // 06046C76 mov #23,r5
    c.r[8] = c.r[8] & 0xFFu;  // 06046C78 extu.b r8,r8
    c.r[8] += 88;  // 06046C7A add #88,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06046C80u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046C80u) return; }  // 06046C7C jsr @r9 ; extu.w r8,r8
    c.r[5] = 0x24u;  // 06046C80 mov #36,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06046C86u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046C86u) return; }  // 06046C82 jsr @r9 ; mov r0,r4
    c.r[5] = c.r[8];  // 06046C86 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06046C8Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046C8Cu) return; }  // 06046C88 jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x06046CE8u);  // 06046C8C mov.l 0x06046CE8,r1
    c.r[6] = 0x0u;  // 06046C8E mov #0,r6
    c.r[5] = c.r[0];  // 06046C90 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06046C96u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046C96u) return; }  // 06046C92 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06046CECu);  // 06046C96 mov.l 0x06046CEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06046C9Cu; c.r[4] = 0x67u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046C9Cu) return; }  // 06046C98 jsr @r1 ; mov #103,r4
    c.r[15] = c.r[14];  // 06046C9C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06046C9E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06046CA0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06046CA2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046CD0u);  // 06046CA4 mov.w 0x06046CD0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046CA6 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
