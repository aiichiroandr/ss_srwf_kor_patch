#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06084BA8(SH2Context& c) {
    ran[1850] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06084BA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06084BAA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06084BAC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06084BAE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06084BB0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06084BB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06084BB4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06084BB6 mov r15,r14
    c.r[1] = ld32(0x06084CE8u);  // 06084BB8 mov.l 0x06084CE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084BBEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084BBEu) return; }  // 06084BBA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084CECu);  // 06084BBE mov.l 0x06084CEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084BC4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084BC4u) return; }  // 06084BC0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084CF0u);  // 06084BC4 mov.l 0x06084CF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084BCAu; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084BCAu) return; }  // 06084BC6 jsr @r1 ; mov #0,r8
    c.r[1] = ld32(0x06084CF4u);  // 06084BCA mov.l 0x06084CF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084BD0u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084BD0u) return; }  // 06084BCC jsr @r1 ; mov #2,r4
    c.r[1] = ld32(0x06084CF8u);  // 06084BD0 mov.l 0x06084CF8,r1
    c.r[1] = ld32(c.r[1]);  // 06084BD2 mov.l @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084BD4 mov.w @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06084CE0u);  // 06084BD6 mov.w 0x06084CE0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06084CE2u);  // 06084BD8 mov.w 0x06084CE2,r1
    c.r[4] += c.r[1];  // 06084BDA add r1,r4
    c.r[1] = ld32(0x06084CFCu);  // 06084BDC mov.l 0x06084CFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084BE2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084BE2u) return; }  // 06084BDE jsr @r1 ; extu.w r4,r4
    c.r[9] = ld32(0x06084D00u);  // 06084BE2 mov.l 0x06084D00,r9
    c.r[10] = ld32(0x06084D04u);  // 06084BE4 mov.l 0x06084D04,r10
L_06084BE6:
    c.r[1] = ld32(0x06084CF8u);  // 06084BE6 mov.l 0x06084CF8,r1
    c.r[1] = ld32(c.r[1]);  // 06084BE8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084CE4u);  // 06084BEA mov.w 0x06084CE4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084BEC mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 06084BEE mov r1,r0
    c.r[0] >>= 2;  // 06084BF0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06084BF2 shlr r0
    c.r[0] &= 0x7u;  // 06084BF4 and #7,r0
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 06084BF6 cmp/ge r0,r8
    if (c.t) { goto L_06084C0A; }  // 06084BF8 bt 0x06084C0A
    c.r[4] = ld32(0x06084D08u);  // 06084BFA mov.l 0x06084D08,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084C00u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C00u) return; }  // 06084BFC jsr @r9 ; mov #23,r5
    c.r[5] = 0x23u;  // 06084C00 mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084C06u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C06u) return; }  // 06084C02 jsr @r9 ; mov r0,r4
    c.r[5] = 0x37u; goto L_06084C18;  // 06084C06 bra 0x06084C18 ; mov #55,r5
L_06084C0A:
    c.r[4] = ld32(0x06084D08u);  // 06084C0A mov.l 0x06084D08,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084C10u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C10u) return; }  // 06084C0C jsr @r9 ; mov #23,r5
    c.r[5] = 0x23u;  // 06084C10 mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084C16u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C16u) return; }  // 06084C12 jsr @r9 ; mov r0,r4
    c.r[5] = 0x38u;  // 06084C16 mov #56,r5
L_06084C18:
    { const uint32_t x = c.r[9]; c.pr = 0x06084C1Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C1Cu) return; }  // 06084C18 jsr @r9 ; mov r0,r4
    c.r[6] = 0x0u;  // 06084C1C mov #0,r6
    c.r[5] = c.r[0];  // 06084C1E mov r0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06084C24u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C24u) return; }  // 06084C20 jsr @r10 ; mov #0,r4
    c.r[8] += 1;  // 06084C24 add #1,r8
    c.r[1] = 0x3u;  // 06084C26 mov #3,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06084C28 cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06084BE6; }  // 06084C2A bf 0x06084BE6
    c.r[8] = 0x0u;  // 06084C2C mov #0,r8
    c.r[9] = ld32(0x06084CFCu);  // 06084C2E mov.l 0x06084CFC,r9
L_06084C30:
    c.r[12] = ld32(0x06084D0Cu);  // 06084C30 mov.l 0x06084D0C,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06084C32 mov.b @r12,r1
    c.r[10] = 0x1Eu;  // 06084C34 mov #30,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06084C36 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06084C38 mul.l r10,r1
    c.r[11] = ld32(0x06084D10u);  // 06084C3A mov.l 0x06084D10,r11
    c.r[2] = ld32(c.r[11]);  // 06084C3C mov.l @r11,r2
    c.r[1] = c.macl;  // 06084C3E sts macl,r1
    c.r[1] += c.r[2];  // 06084C40 add r2,r1
    c.r[1] += c.r[8];  // 06084C42 add r8,r1
    c.r[1] += 17;  // 06084C44 add #17,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084C46 mov.b @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06084CE0u);  // 06084C48 mov.w 0x06084CE0,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06084C4A extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06084CE6u);  // 06084C4C mov.w 0x06084CE6,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06084C52u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C52u) return; }  // 06084C4E jsr @r9 ; or r1,r4
    c.r[8] += 1;  // 06084C52 add #1,r8
    c.r[1] = 0x3u;  // 06084C54 mov #3,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06084C56 cmp/gt r1,r8
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { SH2_POLL(c); goto L_06084C30; } }  // 06084C58 bf/s 0x06084C30 ; mov #0,r5
    c.r[8] = ld32(0x06084CF8u);  // 06084C5C mov.l 0x06084CF8,r8
    c.r[9] = ld32(0x06084D14u);  // 06084C5E mov.l 0x06084D14,r9
    c.r[1] = ld32(c.r[8]);  // 06084C60 mov.l @r8,r1
    c.r[1] += 26;  // 06084C62 add #26,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084C64 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06084C66 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084C6Cu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C6Cu) return; }  // 06084C68 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 06084C6C mov.l @r8,r1
    c.r[5] = 0x0u;  // 06084C6E mov #0,r5
    c.r[1] += 28;  // 06084C70 add #28,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084C72 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06084C74 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084C7Au; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C7Au) return; }  // 06084C76 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 06084C7A mov.l @r8,r1
    c.r[5] = 0x0u;  // 06084C7C mov #0,r5
    c.r[1] += 36;  // 06084C7E add #36,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084C80 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06084C82 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084C88u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C88u) return; }  // 06084C84 jsr @r9 ; extu.b r6,r6
    c.r[1] = ld32(c.r[8]);  // 06084C88 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06084C8A mov #0,r5
    c.r[1] += 34;  // 06084C8C add #34,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084C8E mov.w @r1,r6
    c.r[4] = 0x0u;  // 06084C90 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084C96u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084C96u) return; }  // 06084C92 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 06084C96 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06084C98 mov #0,r5
    c.r[1] += 30;  // 06084C9A add #30,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084C9C mov.w @r1,r6
    c.r[4] = 0x0u;  // 06084C9E mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084CA4u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084CA4u) return; }  // 06084CA0 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 06084CA4 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06084CA6 mov #0,r5
    c.r[1] += 32;  // 06084CA8 add #32,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084CAA mov.w @r1,r6
    c.r[4] = 0x0u;  // 06084CAC mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06084CB2u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084CB2u) return; }  // 06084CAE jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(0x06084D18u);  // 06084CB2 mov.l 0x06084D18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084CB4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06084CB6 extu.b r1,r0
    c.r[1] = ld32(0x06084D1Cu);  // 06084CB8 mov.l 0x06084D1C,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084CBA mov.b @(r0,r1),r7
    c.r[2] = ld32(0x06084D20u);  // 06084CBC mov.l 0x06084D20,r2
    st8(c.r[2], c.r[7]);  // 06084CBE mov.b r7,@r2
    c.r[1] = ld32(0x06084D24u);  // 06084CC0 mov.l 0x06084D24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084CC2 mov.b @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06084CC4 tst r1,r1
    if (!c.t) { goto L_06084D28; }  // 06084CC6 bf 0x06084D28
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06084CC8 mov.b @r12,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06084CCA extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06084CCC mul.l r10,r1
    c.r[2] = ld32(c.r[11]);  // 06084CCE mov.l @r11,r2
    c.r[3] = c.macl;  // 06084CD0 sts macl,r3
    c.r[3] += c.r[2];  // 06084CD2 add r2,r3
    c.r[1] = c.r[7] & 0xFFu;  // 06084CD4 extu.b r7,r1
    c.r[3] += c.r[1];  // 06084CD6 add r1,r3
    c.r[3] += 17;  // 06084CD8 add #17,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06084CDA mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06084D2A;  // 06084CDC bra 0x06084D2A ; extu.b r1,r1
L_06084D28:
    c.r[1] = 0x0u;  // 06084D28 mov #0,r1
L_06084D2A:
    c.r[1] += 56;  // 06084D2A add #56,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06084D2C extu.w r1,r9
    c.r[4] = ld32(0x06084DA4u);  // 06084D2E mov.l 0x06084DA4,r4
    c.r[8] = ld32(0x06084DA8u);  // 06084D30 mov.l 0x06084DA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06084D36u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084D36u) return; }  // 06084D32 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06084D36 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06084D3Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084D3Cu) return; }  // 06084D38 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 06084D3C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06084D42u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084D42u) return; }  // 06084D3E jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06084DACu);  // 06084D42 mov.l 0x06084DAC,r1
    c.r[6] = 0x0u;  // 06084D44 mov #0,r6
    c.r[5] = c.r[0];  // 06084D46 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06084D4Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084D4Cu) return; }  // 06084D48 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084DB0u);  // 06084D4C mov.l 0x06084DB0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084D9Eu);  // 06084D4E mov.w 0x06084D9E,r0
    c.r[2] = 0x1u;  // 06084D50 mov #1,r2
    c.r[7] = 0x2u;  // 06084D52 mov #2,r7
    c.r[6] = 0x10u;  // 06084D54 mov #16,r6
    c.r[1] = ld32(c.r[1]);  // 06084D56 mov.l @r1,r1
    c.r[5] = 0x5u;  // 06084D58 mov #5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084D5A mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 06084D5C mov #2,r4
    c.r[0] = c.r[1];  // 06084D5E mov r1,r0
    c.r[0] >>= 2;  // 06084D60 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06084D62 shlr r0
    c.r[0] &= 0x7u;  // 06084D64 and #7,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06084D66 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084D68 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084D6A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084D6C mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06084D6E mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084D70 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084D72 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084D74 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084D76 mov.l r1,@-r15
    c.r[1] = 0x4u;  // 06084D78 mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084D7A mov.l r1,@-r15
    c.r[1] = ld32(0x06084DB4u);  // 06084D7C mov.l 0x06084DB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084D82u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084D82u) return; }  // 06084D7E jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06084D82 add #40,r15
    c.r[1] = ld32(0x06084DB8u);  // 06084D84 mov.l 0x06084DB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084D8Au; c.r[4] = 0x51u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084D8Au) return; }  // 06084D86 jsr @r1 ; mov #81,r4
    c.r[15] = c.r[14];  // 06084D8A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06084D8C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06084D8E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06084D90 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06084D92 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06084D94 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06084D96 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084DA0u);  // 06084D98 mov.w 0x06084DA0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06084D9A rts ; mov.l @r15+,r8
}

void f_06084DBC(SH2Context& c) {
    ran[1851] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06084DBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06084DBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06084DC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06084DC2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06084DC4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06084DC6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06084DC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06084DCA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06084EDEu);  // 06084DCC mov.w 0x06084EDE,r3
    c.r[15] += c.r[3];  // 06084DCE add r3,r15
    c.r[14] = c.r[15];  // 06084DD0 mov r15,r14
    c.r[1] = ld32(0x06084EECu);  // 06084DD2 mov.l 0x06084EEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084DD8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084DD8u) return; }  // 06084DD4 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06084EF0u);  // 06084DD8 mov.l 0x06084EF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084DDEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084DDEu) return; }  // 06084DDA jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06084EF4u);  // 06084DDE mov.l 0x06084EF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084DE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084DE4u) return; }  // 06084DE0 jsr @r1 ; nop
    c.r[1] = ld32(0x06084EF8u);  // 06084DE4 mov.l 0x06084EF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084DEAu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084DEAu) return; }  // 06084DE6 jsr @r1 ; mov #2,r4
    c.r[1] = ld32(0x06084EFCu);  // 06084DEA mov.l 0x06084EFC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084DEC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06084DEE extu.b r1,r0
    c.r[1] = ld32(0x06084F00u);  // 06084DF0 mov.l 0x06084F00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084DF2 mov.b @(r0,r1),r1
    c.r[2] = 0x1u;  // 06084DF4 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06084DF6 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06084DF8 cmp/hi r2,r1
    { const bool k = !c.t; c.r[4] = 0x9u; if (k) { goto L_06084E06; } }  // 06084DFA bf/s 0x06084E06 ; mov #9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06084EE0u);  // 06084DFE mov.w 0x06084EE0,r4
    c.r[1] = ld32(0x06084F04u);  // 06084E00 mov.l 0x06084F04,r1
    goto L_06084E08;  // 06084E02 bra 0x06084E08 ; nop
L_06084E06:
    c.r[1] = ld32(0x06084F04u);  // 06084E06 mov.l 0x06084F04,r1
L_06084E08:
    { const uint32_t x = c.r[1]; c.pr = 0x06084E0Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084E0Cu) return; }  // 06084E08 jsr @r1 ; nop
    c.r[1] = ld32(0x06084EFCu);  // 06084E0C mov.l 0x06084EFC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084E0E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06084E10 extu.b r1,r0
    c.r[1] = ld32(0x06084F00u);  // 06084E12 mov.l 0x06084F00,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084E14 mov.b @(r0,r1),r3
    c.r[1] = ld32(0x06084F08u);  // 06084E16 mov.l 0x06084F08,r1
    c.r[1] = ld32(c.r[1]);  // 06084E18 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084EE2u);  // 06084E1A mov.w 0x06084EE2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084E1C mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06084E1E extu.b r2,r2
    c.r[2] += 6;  // 06084E20 add #6,r2
    c.r[1] = ld32(0x06084F0Cu);  // 06084E22 mov.l 0x06084F0C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06084E24 dmuls.l r1,r2
    c.r[3] = c.r[3] & 0xFFu;  // 06084E26 extu.b r3,r3
    c.r[1] = c.mach;  // 06084E28 sts mach,r1
    c.r[1] += c.r[2];  // 06084E2A add r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06084E2C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06084E2E shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06084E30 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06084E32 subc r2,r2
    c.r[1] -= c.r[2];  // 06084E34 sub r2,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06084E36 cmp/ge r1,r3
    { const bool k = c.t; c.r[4] = 0x9u; if (k) { goto L_06084E44; } }  // 06084E38 bt/s 0x06084E44 ; mov #9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06084EE4u);  // 06084E3C mov.w 0x06084EE4,r4
    c.r[1] = ld32(0x06084F04u);  // 06084E3E mov.l 0x06084F04,r1
    goto L_06084E46;  // 06084E40 bra 0x06084E46 ; nop
L_06084E44:
    c.r[1] = ld32(0x06084F04u);  // 06084E44 mov.l 0x06084F04,r1
L_06084E46:
    { const uint32_t x = c.r[1]; c.pr = 0x06084E4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084E4Au) return; }  // 06084E46 jsr @r1 ; nop
    c.r[10] = ld32(0x06084EFCu);  // 06084E4A mov.l 0x06084EFC,r10
    c.r[9] = ld32(0x06084F00u);  // 06084E4C mov.l 0x06084F00,r9
    c.r[8] = ld32(0x06084F10u);  // 06084E4E mov.l 0x06084F10,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06084E50 mov.b @r10,r1
    c.r[5] = 0x0u;  // 06084E52 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06084E54 extu.b r1,r1
    c.r[0] = c.r[1];  // 06084E56 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06084E58 mov.b @(r0,r9),r6
    c.r[4] = 0x0u;  // 06084E5A mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084E60u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084E60u) return; }  // 06084E5C jsr @r8 ; extu.b r6,r6
    c.r[11] = ld32(0x06084F08u);  // 06084E60 mov.l 0x06084F08,r11
    c.r[1] = ld32(c.r[11]);  // 06084E62 mov.l @r11,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084EE2u);  // 06084E64 mov.w 0x06084EE2,r13
    c.r[0] = c.r[1];  // 06084E66 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06084E68 mov.b @(r0,r13),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06084E6A extu.b r2,r2
    c.r[2] += 6;  // 06084E6C add #6,r2
    c.r[1] = ld32(0x06084F0Cu);  // 06084E6E mov.l 0x06084F0C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06084E70 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06084E72 mov #0,r5
    c.r[4] = 0x0u;  // 06084E74 mov #0,r4
    c.r[6] = c.mach;  // 06084E76 sts mach,r6
    c.r[6] += c.r[2];  // 06084E78 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06084E7A shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06084E7C shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06084E7E shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06084E80 subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06084E86u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084E86u) return; }  // 06084E82 jsr @r8 ; sub r2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06084E86 mov.b @r10,r1
    c.r[2] = 0x7u;  // 06084E88 mov #7,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06084E8A extu.b r1,r3
    c.r[0] = c.r[3];  // 06084E8C mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06084E8E mov.b @(r0,r9),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084EE6u);  // 06084E90 mov.w 0x06084EE6,r12
    c.r[10] = c.r[1] & 0xFFu;  // 06084E92 extu.b r1,r10
    c.r[10] -= 1;  // 06084E94 add #-1,r10
    c.macl = c.r[10] * c.r[2];  // 06084E96 mul.l r2,r10
    c.r[12] += c.r[14];  // 06084E98 add r14,r12
    c.r[1] = ld32(0x06084F14u);  // 06084E9A mov.l 0x06084F14,r1
    c.r[0] = c.macl;  // 06084E9C sts macl,r0
    st32(c.r[12], c.r[0]);  // 06084E9E mov.l r0,@r12
    c.r[0] = c.r[3];  // 06084EA0 mov r3,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084EE6u);  // 06084EA2 mov.w 0x06084EE6,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084EA4 mov.b @(r0,r1),r1
    c.r[12] += c.r[14];  // 06084EA6 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06084EA8 mov.l @r12,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06084EAA extu.b r1,r1
    c.r[0] += c.r[1];  // 06084EAC add r1,r0
    st32(c.r[12], c.r[0]);  // 06084EAE mov.l r0,@r12
    c.r[1] = ld32(c.r[11]);  // 06084EB0 mov.l @r11,r1
    c.r[0] = c.r[1];  // 06084EB2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06084EB4 mov.b @(r0,r13),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06084EB6 extu.b r1,r4
    c.r[1] = c.macl;  // 06084EB8 sts macl,r1
    c.r[4] -= c.r[1];  // 06084EBA sub r1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[2];  // 06084EBC cmp/gt r2,r4
    { const bool k = c.t; c.r[9] = c.r[2]; if (k) { goto L_06084EC4; } }  // 06084EBE bt/s 0x06084EC4 ; mov r2,r9
    c.r[9] = c.r[4];  // 06084EC2 mov r4,r9
L_06084EC4:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06084EE8u);  // 06084EC4 mov.w 0x06084EE8,r4
    c.r[8] = ld32(0x06084F04u);  // 06084EC6 mov.l 0x06084F04,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06084ECCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084ECCu) return; }  // 06084EC8 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x06084ED0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084ED0u) return; }  // 06084ECC jsr @r8 ; mov #0,r4
    c.t = (c.r[10] & c.r[10]) == 0;  // 06084ED0 tst r10,r10
    if (!c.t) { goto L_06084F18; }  // 06084ED2 bf 0x06084F18
    { const uint32_t x = c.r[8]; c.pr = 0x06084ED8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084ED8u) return; }  // 06084ED4 jsr @r8 ; mov #0,r4
    c.r[9] -= 1;  // 06084ED8 add #-1,r9
    c.r[8] = 0x1u; goto L_06084F24;  // 06084EDA bra 0x06084F24 ; mov #1,r8
L_06084F18:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06085092u);  // 06084F18 mov.w 0x06085092,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084F1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084F1Eu) return; }  // 06084F1A jsr @r8 ; nop
    c.r[1] = 0x7u;  // 06084F1E mov #7,r1
    c.macl = c.r[10] * c.r[1];  // 06084F20 mul.l r1,r10
    c.r[8] = c.macl;  // 06084F22 sts macl,r8
L_06084F24:
    c.r[1] = ld32(0x060850A0u);  // 06084F24 mov.l 0x060850A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084F2Au; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084F2Au) return; }  // 06084F26 jsr @r1 ; extu.b r9,r4
    c.r[9] += c.r[8];  // 06084F2A add r8,r9
    c.r[12] = (uint32_t)(int16_t)ld16(0x06085094u);  // 06084F2C mov.w 0x06085094,r12
    c.r[12] += c.r[14];  // 06084F2E add r14,r12
    st32(c.r[12], c.r[9]);  // 06084F30 mov.l r9,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085094u);  // 06084F32 mov.w 0x06085094,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06084F34 mov.l @(r0,r14),r0
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 06084F36 cmp/ge r0,r8
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06084FBC; } }  // 06084F38 bt/s 0x06084FBC ; mov r8,r1
    c.r[13] = ld32(0x060850A4u);  // 06084F3C mov.l 0x060850A4,r13
    c.r[1] += c.r[1];  // 06084F3E add r1,r1
    c.r[1] += c.r[8];  // 06084F40 add r8,r1
    c.r[1] += c.r[1];  // 06084F42 add r1,r1
    c.r[11] = c.r[1];  // 06084F44 mov r1,r11
    c.r[11] += 2;  // 06084F46 add #2,r11
    c.r[10] = c.r[1];  // 06084F48 mov r1,r10
    c.r[10] += 4;  // 06084F4A add #4,r10
    c.r[9] = c.r[1];  // 06084F4C mov r1,r9
L_06084F4E:
    c.r[12] = 0x7Fu;  // 06084F4E mov #127,r12
    c.r[1] = ld32(c.r[13]);  // 06084F50 mov.l @r13,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06085096u);  // 06084F52 mov.w 0x06085096,r5
    c.r[0] = c.r[1];  // 06084F54 mov r1,r0
    c.r[1] += c.r[9];  // 06084F56 add r9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06084F58 mov.b @(r0,r9),r2
    c.r[1] += 1;  // 06084F5A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084F5C mov.b @r1,r4
    c.r[2] &= c.r[12];  // 06084F5E and r12,r2
    c.r[2] <<= 8;  // 06084F60 shll8 r2
    c.r[4] = c.r[4] & 0xFFu;  // 06084F62 extu.b r4,r4
    c.r[4] |= c.r[2];  // 06084F64 or r2,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085098u);  // 06084F66 mov.w 0x06085098,r1
    c.r[4] += c.r[1];  // 06084F68 add r1,r4
    c.r[1] = ld32(0x060850A8u);  // 06084F6A mov.l 0x060850A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084F70u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084F70u) return; }  // 06084F6C jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x0u;  // 06084F70 mov #0,r5
    c.r[1] = ld32(c.r[13]);  // 06084F72 mov.l @r13,r1
    c.r[4] = 0x0u;  // 06084F74 mov #0,r4
    c.r[0] = c.r[1];  // 06084F76 mov r1,r0
    c.r[1] += c.r[10];  // 06084F78 add r10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06084F7A mov.b @(r0,r10),r2
    c.r[1] += 1;  // 06084F7C add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084F7E mov.b @r1,r6
    c.r[2] &= c.r[12];  // 06084F80 and r12,r2
    c.r[2] <<= 8;  // 06084F82 shll8 r2
    c.r[6] = c.r[6] & 0xFFu;  // 06084F84 extu.b r6,r6
    c.r[12] = ld32(0x060850ACu);  // 06084F86 mov.l 0x060850AC,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06084F8Cu; c.r[6] |= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084F8Cu) return; }  // 06084F88 jsr @r12 ; or r2,r6
    c.r[12] = 0x7Fu;  // 06084F8C mov #127,r12
    c.r[5] = 0x0u;  // 06084F8E mov #0,r5
    c.r[1] = ld32(c.r[13]);  // 06084F90 mov.l @r13,r1
    c.r[4] = 0x0u;  // 06084F92 mov #0,r4
    c.r[0] = c.r[1];  // 06084F94 mov r1,r0
    c.r[1] += c.r[11];  // 06084F96 add r11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06084F98 mov.b @(r0,r11),r2
    c.r[1] += 1;  // 06084F9A add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084F9C mov.b @r1,r6
    c.r[2] &= c.r[12];  // 06084F9E and r12,r2
    c.r[2] <<= 8;  // 06084FA0 shll8 r2
    c.r[6] = c.r[6] & 0xFFu;  // 06084FA2 extu.b r6,r6
    c.r[0] = ld32(0x060850ACu);  // 06084FA4 mov.l 0x060850AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06084FAAu; c.r[6] |= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084FAAu) return; }  // 06084FA6 jsr @r0 ; or r2,r6
    c.r[11] += 6;  // 06084FAA add #6,r11
    c.r[10] += 6;  // 06084FAC add #6,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06085094u);  // 06084FAE mov.w 0x06085094,r12
    c.r[12] += c.r[14];  // 06084FB0 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06084FB2 mov.l @r12,r12
    c.r[8] += 1;  // 06084FB4 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12];  // 06084FB6 cmp/ge r12,r8
    { const bool k = !c.t; c.r[9] += 6; if (k) { SH2_POLL(c); goto L_06084F4E; } }  // 06084FB8 bf/s 0x06084F4E ; add #6,r9
L_06084FBC:
    c.r[6] = ld32(0x060850B0u);  // 06084FBC mov.l 0x060850B0,r6
    c.r[1] = ld32(0x060850A4u);  // 06084FBE mov.l 0x060850A4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608509Au);  // 06084FC0 mov.w 0x0608509A,r0
    c.r[0] += c.r[14];  // 06084FC2 add r14,r0
    c.r[2] = ld32(c.r[1]);  // 06084FC4 mov.l @r1,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0608509Au);  // 06084FC6 mov.w 0x0608509A,r12
    c.r[3] = ld32(c.r[0]);  // 06084FC8 mov.l @r0,r3
    c.r[12] += c.r[14];  // 06084FCA add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06084FCC mov.l @r12,r12
    c.r[3] += c.r[3];  // 06084FCE add r3,r3
    c.r[3] += c.r[12];  // 06084FD0 add r12,r3
    c.r[1] = c.r[3];  // 06084FD2 mov r3,r1
    c.r[1] += c.r[1];  // 06084FD4 add r1,r1
    c.r[0] = c.r[2];  // 06084FD6 mov r2,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084FD8 mov.b @(r0,r1),r7
    c.r[12] = 0x7Fu;  // 06084FDA mov #127,r12
    c.r[7] &= c.r[12];  // 06084FDC and r12,r7
    c.r[1] += c.r[2];  // 06084FDE add r2,r1
    c.r[1] += 1;  // 06084FE0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084FE2 mov.b @r1,r1
    c.r[7] <<= 8;  // 06084FE4 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06084FE6 extu.b r1,r1
    c.r[1] |= c.r[7];  // 06084FE8 or r7,r1
    st32(c.r[6], c.r[1]);  // 06084FEA mov.l r1,@r6
    c.r[7] = ld32(0x060850B4u);  // 06084FEC mov.l 0x060850B4,r7
    c.r[1] = c.r[3];  // 06084FEE mov r3,r1
    c.r[1] += 2;  // 06084FF0 add #2,r1
    c.r[1] += c.r[1];  // 06084FF2 add r1,r1
    c.r[2] += c.r[1];  // 06084FF4 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084FF6 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 06084FF8 add #1,r2
    c.r[3] &= c.r[12];  // 06084FFA and r12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06084FFC mov.b @r2,r1
    c.r[3] <<= 8;  // 06084FFE shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06085000 extu.b r1,r1
    c.r[1] |= c.r[3];  // 06085002 or r3,r1
    st32(c.r[7], c.r[1]);  // 06085004 mov.l r1,@r7
    c.r[1] = ld32(0x060850B8u);  // 06085006 mov.l 0x060850B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085008 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0608500A mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0608500C cmp/eq #1,r0
    { const bool k = !c.t; c.r[10] = 0x1Eu; if (k) { goto L_06085060; } }  // 0608500E bf/s 0x06085060 ; mov #30,r10
    c.r[8] = ld32(0x060850BCu);  // 06085012 mov.l 0x060850BC,r8
    c.r[11] = ld32(0x060850C0u);  // 06085014 mov.l 0x060850C0,r11
    c.r[9] = ld32(0x060850C4u);  // 06085016 mov.l 0x060850C4,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06085018 mov.b @r8,r1
    c.r[6] += 3;  // 0608501A add #3,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0608501C extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0608501E mul.l r10,r1
    c.r[4] = c.r[14];  // 06085020 mov r14,r4
    c.r[2] = ld32(c.r[11]);  // 06085022 mov.l @r11,r2
    c.r[3] = c.macl;  // 06085024 sts macl,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06085026 mov.b @r9,r1
    c.r[3] += c.r[2];  // 06085028 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0608502A extu.b r1,r1
    c.r[3] += c.r[1];  // 0608502C add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0608502E mov.b @r6,r1
    c.r[3] += 17;  // 06085030 add #17,r3
    st8(c.r[3], c.r[1]);  // 06085032 mov.b r1,@r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06085096u);  // 06085034 mov.w 0x06085096,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06085036 mov.b @r8,r5
    c.r[1] = ld32(0x060850C8u);  // 06085038 mov.l 0x060850C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608503Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608503Eu) return; }  // 0608503A jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0608503E mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06085040 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06085042 mul.l r10,r1
    c.r[2] = ld32(c.r[11]);  // 06085044 mov.l @r11,r2
    c.r[3] = c.macl;  // 06085046 sts macl,r3
    c.r[3] += c.r[2];  // 06085048 add r2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0608504A mov.b @r9,r2
    c.r[1] = ld32(0x060850CCu);  // 0608504C mov.l 0x060850CC,r1
    c.r[1] = ld32(c.r[1]);  // 0608504E mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06085050 extu.b r2,r2
    c.r[3] += c.r[2];  // 06085052 add r2,r3
    c.r[1] += c.r[2];  // 06085054 add r2,r1
    c.r[1] += 16;  // 06085056 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085058 mov.b @r1,r1
    c.r[3] += 17;  // 0608505A add #17,r3
    st8(c.r[3], c.r[1]); goto L_0608506E;  // 0608505C bra 0x0608506E ; mov.b r1,@r3
L_06085060:
    c.r[6] = (uint32_t)(int16_t)ld16(0x06085096u);  // 06085060 mov.w 0x06085096,r6
    c.r[1] = ld32(0x060850BCu);  // 06085062 mov.l 0x060850BC,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085064 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06085066 mov r14,r4
    c.r[1] = ld32(0x060850C8u);  // 06085068 mov.l 0x060850C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608506Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608506Eu) return; }  // 0608506A jsr @r1 ; extu.b r5,r5
L_0608506E:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608509Cu);  // 0608506E mov.w 0x0608509C,r4
    c.r[8] = ld32(0x060850A0u);  // 06085070 mov.l 0x060850A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06085076u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085076u) return; }  // 06085072 jsr @r8 ; nop
    c.r[1] = ld32(0x060850CCu);  // 06085076 mov.l 0x060850CC,r1
    c.r[2] = ld32(c.r[1]);  // 06085078 mov.l @r1,r2
    c.r[2] += 26;  // 0608507A add #26,r2
    c.r[1] = c.r[14];  // 0608507C mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608507E mov.w @r2,r2
    c.r[1] += 26;  // 06085080 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06085082 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06085084 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06085086 extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 06085088 cmp/hs r1,r2
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_060850D0; } }  // 0608508A bt/s 0x060850D0 ; cmp/hi r1,r2
    c.r[4] = 0x4u; goto L_060850D6;  // 0608508E bra 0x060850D6 ; mov #4,r4
L_060850D0:
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_060850D6; } }  // 060850D0 bt/s 0x060850D6 ; mov #2,r4
    c.r[4] = 0x1u;  // 060850D4 mov #1,r4
L_060850D6:
    { const uint32_t x = c.r[8]; c.pr = 0x060850DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060850DAu) return; }  // 060850D6 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 060850DA mov r14,r1
    c.r[1] += 26;  // 060850DC add #26,r1
    c.r[5] = 0x0u;  // 060850DE mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060850E0 mov.w @r1,r6
    c.r[4] = 0x0u;  // 060850E2 mov #0,r4
    c.r[1] = ld32(0x060851D4u);  // 060850E4 mov.l 0x060851D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060850EAu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060850EAu) return; }  // 060850E6 jsr @r1 ; extu.w r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060851D0u);  // 060850EA mov.w 0x060851D0,r4
    c.r[8] = ld32(0x060851D8u);  // 060850EC mov.l 0x060851D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060850F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060850F2u) return; }  // 060850EE jsr @r8 ; nop
    c.r[1] = ld32(0x060851DCu);  // 060850F2 mov.l 0x060851DC,r1
    c.r[2] = ld32(c.r[1]);  // 060850F4 mov.l @r1,r2
    c.r[2] += 28;  // 060850F6 add #28,r2
    c.r[1] = c.r[14];  // 060850F8 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060850FA mov.w @r2,r2
    c.r[1] += 28;  // 060850FC add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060850FE mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06085100 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06085102 extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 06085104 cmp/hs r1,r2
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_0608510E; } }  // 06085106 bt/s 0x0608510E ; cmp/hi r1,r2
    c.r[4] = 0x4u; goto L_06085114;  // 0608510A bra 0x06085114 ; mov #4,r4
L_0608510E:
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_06085114; } }  // 0608510E bt/s 0x06085114 ; mov #2,r4
    c.r[4] = 0x1u;  // 06085112 mov #1,r4
L_06085114:
    { const uint32_t x = c.r[8]; c.pr = 0x06085118u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085118u) return; }  // 06085114 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06085118 mov r14,r1
    c.r[1] += 28;  // 0608511A add #28,r1
    c.r[5] = 0x0u;  // 0608511C mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608511E mov.w @r1,r6
    c.r[4] = 0x0u;  // 06085120 mov #0,r4
    c.r[1] = ld32(0x060851D4u);  // 06085122 mov.l 0x060851D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085128u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085128u) return; }  // 06085124 jsr @r1 ; extu.w r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060851D0u);  // 06085128 mov.w 0x060851D0,r4
    c.r[8] = ld32(0x060851D8u);  // 0608512A mov.l 0x060851D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06085130u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085130u) return; }  // 0608512C jsr @r8 ; nop
    c.r[1] = ld32(0x060851DCu);  // 06085130 mov.l 0x060851DC,r1
    c.r[2] = ld32(c.r[1]);  // 06085132 mov.l @r1,r2
    c.r[2] += 36;  // 06085134 add #36,r2
    c.r[1] = c.r[14];  // 06085136 mov r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085138 mov.b @r2,r2
    c.r[1] += 36;  // 0608513A add #36,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608513C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0608513E extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06085140 extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 06085142 cmp/hs r1,r2
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_0608514C; } }  // 06085144 bt/s 0x0608514C ; cmp/hi r1,r2
    c.r[4] = 0x4u; goto L_06085152;  // 06085148 bra 0x06085152 ; mov #4,r4
L_0608514C:
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_06085152; } }  // 0608514C bt/s 0x06085152 ; mov #2,r4
    c.r[4] = 0x1u;  // 06085150 mov #1,r4
L_06085152:
    { const uint32_t x = c.r[8]; c.pr = 0x06085156u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085156u) return; }  // 06085152 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06085156 mov r14,r1
    c.r[1] += 36;  // 06085158 add #36,r1
    c.r[5] = 0x0u;  // 0608515A mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608515C mov.b @r1,r6
    c.r[4] = 0x0u;  // 0608515E mov #0,r4
    c.r[1] = ld32(0x060851D4u);  // 06085160 mov.l 0x060851D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085166u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085166u) return; }  // 06085162 jsr @r1 ; extu.b r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060851D0u);  // 06085166 mov.w 0x060851D0,r4
    c.r[8] = ld32(0x060851D8u);  // 06085168 mov.l 0x060851D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608516Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608516Eu) return; }  // 0608516A jsr @r8 ; nop
    c.r[1] = ld32(0x060851DCu);  // 0608516E mov.l 0x060851DC,r1
    c.r[2] = ld32(c.r[1]);  // 06085170 mov.l @r1,r2
    c.r[2] += 34;  // 06085172 add #34,r2
    c.r[1] = c.r[14];  // 06085174 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06085176 mov.w @r2,r2
    c.r[1] += 34;  // 06085178 add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608517A mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0608517C extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0608517E extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 06085180 cmp/hs r1,r2
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_0608518A; } }  // 06085182 bt/s 0x0608518A ; cmp/hi r1,r2
    c.r[4] = 0x4u; goto L_06085190;  // 06085186 bra 0x06085190 ; mov #4,r4
L_0608518A:
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_06085190; } }  // 0608518A bt/s 0x06085190 ; mov #2,r4
    c.r[4] = 0x1u;  // 0608518E mov #1,r4
L_06085190:
    { const uint32_t x = c.r[8]; c.pr = 0x06085194u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085194u) return; }  // 06085190 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06085194 mov r14,r1
    c.r[1] += 34;  // 06085196 add #34,r1
    c.r[5] = 0x0u;  // 06085198 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608519A mov.w @r1,r6
    c.r[4] = 0x0u;  // 0608519C mov #0,r4
    c.r[1] = ld32(0x060851D4u);  // 0608519E mov.l 0x060851D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060851A4u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060851A4u) return; }  // 060851A0 jsr @r1 ; extu.w r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060851D0u);  // 060851A4 mov.w 0x060851D0,r4
    c.r[8] = ld32(0x060851D8u);  // 060851A6 mov.l 0x060851D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060851ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060851ACu) return; }  // 060851A8 jsr @r8 ; nop
    c.r[1] = ld32(0x060851DCu);  // 060851AC mov.l 0x060851DC,r1
    c.r[2] = ld32(c.r[1]);  // 060851AE mov.l @r1,r2
    c.r[2] += 30;  // 060851B0 add #30,r2
    c.r[1] = c.r[14];  // 060851B2 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060851B4 mov.w @r2,r2
    c.r[1] += 30;  // 060851B6 add #30,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060851B8 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060851BA extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060851BC extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 060851BE cmp/hs r1,r2
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_060851C8; } }  // 060851C0 bt/s 0x060851C8 ; cmp/hi r1,r2
    c.r[4] = 0x4u; goto L_060851E2;  // 060851C4 bra 0x060851E2 ; mov #4,r4
L_060851C8:
    { const bool k = !c.t; c.r[4] = 0x2u; if (k) { goto L_060851E0; } }  // 060851C8 bf/s 0x060851E0 ; mov #2,r4
    goto L_060851E2;  // 060851CC bra 0x060851E2 ; nop
L_060851E0:
    c.r[4] = 0x1u;  // 060851E0 mov #1,r4
L_060851E2:
    { const uint32_t x = c.r[8]; c.pr = 0x060851E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060851E6u) return; }  // 060851E2 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 060851E6 mov r14,r1
    c.r[1] += 30;  // 060851E8 add #30,r1
    c.r[5] = 0x0u;  // 060851EA mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060851EC mov.w @r1,r6
    c.r[4] = 0x0u;  // 060851EE mov #0,r4
    c.r[1] = ld32(0x060852D8u);  // 060851F0 mov.l 0x060852D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060851F6u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060851F6u) return; }  // 060851F2 jsr @r1 ; extu.w r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060852D0u);  // 060851F6 mov.w 0x060852D0,r4
    c.r[8] = ld32(0x060852DCu);  // 060851F8 mov.l 0x060852DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060851FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060851FEu) return; }  // 060851FA jsr @r8 ; nop
    c.r[1] = ld32(0x060852E0u);  // 060851FE mov.l 0x060852E0,r1
    c.r[2] = ld32(c.r[1]);  // 06085200 mov.l @r1,r2
    c.r[2] += 32;  // 06085202 add #32,r2
    c.r[1] = c.r[14];  // 06085204 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06085206 mov.w @r2,r2
    c.r[1] += 32;  // 06085208 add #32,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608520A mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0608520C extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0608520E extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 06085210 cmp/hs r1,r2
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_0608521A; } }  // 06085212 bt/s 0x0608521A ; cmp/hi r1,r2
    c.r[4] = 0x4u; goto L_06085224;  // 06085216 bra 0x06085224 ; mov #4,r4
L_0608521A:
    if (!c.t) { goto L_06085222; }  // 0608521A bf 0x06085222
    c.r[4] = 0x2u;  // 0608521C mov #2,r4
    goto L_06085224;  // 0608521E bra 0x06085224 ; nop
L_06085222:
    c.r[4] = 0x1u;  // 06085222 mov #1,r4
L_06085224:
    { const uint32_t x = c.r[8]; c.pr = 0x06085228u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085228u) return; }  // 06085224 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06085228 mov r14,r1
    c.r[1] += 32;  // 0608522A add #32,r1
    c.r[5] = 0x0u;  // 0608522C mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608522E mov.w @r1,r6
    c.r[4] = 0x0u;  // 06085230 mov #0,r4
    c.r[1] = ld32(0x060852D8u);  // 06085232 mov.l 0x060852D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085238u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085238u) return; }  // 06085234 jsr @r1 ; extu.w r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060852D0u);  // 06085238 mov.w 0x060852D0,r4
    c.r[8] = ld32(0x060852DCu);  // 0608523A mov.l 0x060852DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06085240u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085240u) return; }  // 0608523C jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x06085244u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085244u) return; }  // 06085240 jsr @r8 ; mov #1,r4
    c.r[1] = ld32(0x060852E4u);  // 06085244 mov.l 0x060852E4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085246 mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 06085248 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0608525C; } }  // 0608524A bf/s 0x0608525C ; mov #0,r1
    c.r[1] = ld32(0x060852E8u);  // 0608524E mov.l 0x060852E8,r1
    c.r[1] = ld32(c.r[1]);  // 06085250 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06085252 tst r1,r1
    if (!c.t) { goto L_0608525C; }  // 06085254 bf 0x0608525C
    c.r[1] = 0x1Eu;  // 06085256 mov #30,r1
    c.r[1] += 56; goto L_0608525E;  // 06085258 bra 0x0608525E ; add #56,r1
L_0608525C:
    c.r[1] += 56;  // 0608525C add #56,r1
L_0608525E:
    c.r[9] = c.r[1] & 0xFFFFu;  // 0608525E extu.w r1,r9
    c.r[4] = ld32(0x060852ECu);  // 06085260 mov.l 0x060852EC,r4
    c.r[8] = ld32(0x060852F0u);  // 06085262 mov.l 0x060852F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06085268u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085268u) return; }  // 06085264 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06085268 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608526Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608526Eu) return; }  // 0608526A jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 0608526E mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085274u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085274u) return; }  // 06085270 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060852F4u);  // 06085274 mov.l 0x060852F4,r1
    c.r[6] = 0x0u;  // 06085276 mov #0,r6
    c.r[5] = c.r[0];  // 06085278 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608527Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608527Eu) return; }  // 0608527A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060852F8u);  // 0608527E mov.l 0x060852F8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060852D2u);  // 06085280 mov.w 0x060852D2,r0
    c.r[2] = 0x1u;  // 06085282 mov #1,r2
    c.r[7] = 0x2u;  // 06085284 mov #2,r7
    c.r[6] = 0x11u;  // 06085286 mov #17,r6
    c.r[1] = ld32(c.r[1]);  // 06085288 mov.l @r1,r1
    c.r[5] = 0x6u;  // 0608528A mov #6,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608528C mov.b @(r0,r1),r1
    c.r[4] = 0x15u;  // 0608528E mov #21,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06085290 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085292 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06085294 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06085296 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06085298 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0608529A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608529C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608529E mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060852A0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060852A2 mov.l r1,@-r15
    c.r[1] = 0x7u;  // 060852A4 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060852A6 mov.l r1,@-r15
    c.r[1] = ld32(0x060852FCu);  // 060852A8 mov.l 0x060852FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060852AEu; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060852AEu) return; }  // 060852AA jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 060852AE add #40,r15
    c.r[1] = ld32(0x06085300u);  // 060852B0 mov.l 0x06085300,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060852B6u; c.r[4] = 0x52u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060852B6u) return; }  // 060852B2 jsr @r1 ; mov #82,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060852D4u);  // 060852B6 mov.w 0x060852D4,r3
    c.r[14] += c.r[3];  // 060852B8 add r3,r14
    c.r[15] = c.r[14];  // 060852BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060852BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060852BE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060852C0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060852C2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060852C4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060852C6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060852C8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060852D6u);  // 060852CA mov.w 0x060852D6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060852CC rts ; mov.l @r15+,r8
}

void f_06085304(SH2Context& c) {
    ran[1852] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085304 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06085306 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085308 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608530A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608530C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608530E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085310 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085312 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06085314 mov r15,r14
    c.r[1] = ld32(0x0608545Cu);  // 06085316 mov.l 0x0608545C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608531Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608531Cu) return; }  // 06085318 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06085460u);  // 0608531C mov.l 0x06085460,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085322u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085322u) return; }  // 0608531E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06085464u);  // 06085322 mov.l 0x06085464,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085328u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085328u) return; }  // 06085324 jsr @r1 ; mov #0,r9
    c.r[1] = ld32(0x06085468u);  // 06085328 mov.l 0x06085468,r1
    c.r[1] = ld32(c.r[1]);  // 0608532A mov.l @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608532C mov.w @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06085450u);  // 0608532E mov.w 0x06085450,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085452u);  // 06085330 mov.w 0x06085452,r1
    c.r[4] += c.r[1];  // 06085332 add r1,r4
    c.r[1] = ld32(0x0608546Cu);  // 06085334 mov.l 0x0608546C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608533Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608533Au) return; }  // 06085336 jsr @r1 ; extu.w r4,r4
    c.r[8] = ld32(0x06085470u);  // 0608533A mov.l 0x06085470,r8
    c.r[10] = ld32(0x06085474u);  // 0608533C mov.l 0x06085474,r10
L_0608533E:
    c.r[1] = ld32(0x06085468u);  // 0608533E mov.l 0x06085468,r1
    c.r[1] = ld32(c.r[1]);  // 06085340 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085454u);  // 06085342 mov.w 0x06085454,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06085344 mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 06085346 mov r1,r0
    c.r[0] >>= 2;  // 06085348 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0608534A shlr r0
    c.r[0] &= 0x7u;  // 0608534C and #7,r0
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[0];  // 0608534E cmp/ge r0,r9
    if (c.t) { goto L_06085362; }  // 06085350 bt 0x06085362
    c.r[4] = ld32(0x06085478u);  // 06085352 mov.l 0x06085478,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06085358u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085358u) return; }  // 06085354 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06085358 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608535Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608535Eu) return; }  // 0608535A jsr @r8 ; mov r0,r4
    c.r[5] = 0x37u; goto L_06085370;  // 0608535E bra 0x06085370 ; mov #55,r5
L_06085362:
    c.r[4] = ld32(0x06085478u);  // 06085362 mov.l 0x06085478,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06085368u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085368u) return; }  // 06085364 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06085368 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608536Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608536Eu) return; }  // 0608536A jsr @r8 ; mov r0,r4
    c.r[5] = 0x38u;  // 0608536E mov #56,r5
L_06085370:
    { const uint32_t x = c.r[8]; c.pr = 0x06085374u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085374u) return; }  // 06085370 jsr @r8 ; mov r0,r4
    c.r[6] = 0x0u;  // 06085374 mov #0,r6
    c.r[5] = c.r[0];  // 06085376 mov r0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0608537Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608537Cu) return; }  // 06085378 jsr @r10 ; mov #0,r4
    c.r[9] += 1;  // 0608537C add #1,r9
    c.r[1] = 0x3u;  // 0608537E mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06085380 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_0608533E; }  // 06085382 bf 0x0608533E
    c.r[9] = 0x0u;  // 06085384 mov #0,r9
    c.r[8] = ld32(0x0608546Cu);  // 06085386 mov.l 0x0608546C,r8
L_06085388:
    c.r[1] = ld32(0x0608547Cu);  // 06085388 mov.l 0x0608547C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608538A mov.b @r1,r2
    c.r[1] = ld32(0x06085480u);  // 0608538C mov.l 0x06085480,r1
    c.r[3] = ld32(c.r[1]);  // 0608538E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06085390 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06085392 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06085394 mul.l r1,r2
    c.r[1] = c.macl;  // 06085396 sts macl,r1
    c.r[1] += c.r[3];  // 06085398 add r3,r1
    c.r[1] += c.r[9];  // 0608539A add r9,r1
    c.r[1] += 17;  // 0608539C add #17,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608539E mov.b @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06085450u);  // 060853A0 mov.w 0x06085450,r5
    c.r[4] = c.r[4] & 0xFFu;  // 060853A2 extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085456u);  // 060853A4 mov.w 0x06085456,r1
    { const uint32_t x = c.r[8]; c.pr = 0x060853AAu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060853AAu) return; }  // 060853A6 jsr @r8 ; or r1,r4
    c.r[9] += 1;  // 060853AA add #1,r9
    c.r[1] = 0x3u;  // 060853AC mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060853AE cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06085388; }  // 060853B0 bf 0x06085388
    c.r[8] = ld32(0x06085484u);  // 060853B2 mov.l 0x06085484,r8
    c.r[2] = ld32(c.r[8]);  // 060853B4 mov.l @r8,r2
    c.r[11] = ld32(0x06085488u);  // 060853B6 mov.l 0x06085488,r11
    c.r[1] = ld32(c.r[11]);  // 060853B8 mov.l @r11,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06085458u);  // 060853BA mov.w 0x06085458,r10
    c.r[2] += c.r[1];  // 060853BC add r1,r2
    c.r[0] = c.r[2];  // 060853BE mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060853C0 mov.b @(r0,r10),r4
    c.r[1] = ld32(0x0608548Cu);  // 060853C2 mov.l 0x0608548C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060853C8u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060853C8u) return; }  // 060853C4 jsr @r1 ; extu.b r4,r4
    c.r[2] = ld32(c.r[8]);  // 060853C8 mov.l @r8,r2
    c.r[1] = ld32(c.r[11]);  // 060853CA mov.l @r11,r1
    c.r[2] += c.r[1];  // 060853CC add r1,r2
    c.r[0] = c.r[2];  // 060853CE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060853D0 mov.b @(r0,r10),r1
    c.r[9] = 0x0u;  // 060853D2 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 060853D4 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060853D6 cmp/ge r1,r9
    { const bool k = c.t; c.r[12] = c.r[11]; if (k) { goto L_060854BC; } }  // 060853D8 bt/s 0x060854BC ; mov r11,r12
    c.r[10] = (uint32_t)(int16_t)ld16(0x06085450u);  // 060853DC mov.w 0x06085450,r10
    c.r[13] = c.r[12];  // 060853DE mov r12,r13
    c.r[13] += 2;  // 060853E0 add #2,r13
    c.r[11] = ld32(0x0608546Cu);  // 060853E2 mov.l 0x0608546C,r11
L_060853E4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085456u);  // 060853E4 mov.w 0x06085456,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[13]);  // 060853E6 mov.w @r13,r4
    c.r[5] = c.r[10];  // 060853E8 mov r10,r5
    c.r[4] += c.r[1];  // 060853EA add r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060853F0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060853F0u) return; }  // 060853EC jsr @r11 ; extu.w r4,r4
    c.r[1] = ld32(0x06085490u);  // 060853F0 mov.l 0x06085490,r1
    c.r[1] = ld32(c.r[1]);  // 060853F2 mov.l @r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060853F4 cmp/ge r1,r9
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0608549C; } }  // 060853F6 bt/s 0x0608549C ; mov r9,r2
    c.r[1] = ld32(0x06085494u);  // 060853FA mov.l 0x06085494,r1
    c.r[1] = ld32(c.r[1]);  // 060853FC mov.l @r1,r1
    c.r[2] += c.r[2];  // 060853FE add r2,r2
    c.r[0] = c.r[1];  // 06085400 mov r1,r0
    c.r[1] += c.r[2];  // 06085402 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06085404 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06085406 add #1,r1
    c.r[0] = 0x7Fu;  // 06085408 mov #127,r0
    c.r[3] &= c.r[0];  // 0608540A and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608540C mov.b @r1,r2
    c.r[3] <<= 8;  // 0608540E shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06085410 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06085412 or r3,r2
    c.r[1] = ld32(0x06085480u);  // 06085414 mov.l 0x06085480,r1
    c.r[3] = ld32(c.r[1]);  // 06085416 mov.l @r1,r3
    c.r[1] = 0x1Eu;  // 06085418 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0608541A mul.l r1,r2
    c.r[2] = c.macl;  // 0608541C sts macl,r2
    c.r[2] += c.r[3];  // 0608541E add r3,r2
    c.r[1] = c.r[2];  // 06085420 mov r2,r1
    c.r[1] += 15;  // 06085422 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085424 mov.b @r1,r1
    c.r[5] = c.r[10];  // 06085426 mov r10,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06085428 mov.w @r2,r4
    c.r[8] = c.r[1] & 0xFFu;  // 0608542A extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085452u);  // 0608542C mov.w 0x06085452,r1
    c.r[4] += c.r[1];  // 0608542E add r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06085434u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085434u) return; }  // 06085430 jsr @r11 ; extu.w r4,r4
    c.t = c.r[8] == c.r[10];  // 06085434 cmp/eq r10,r8
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_060854A4; } }  // 06085436 bt/s 0x060854A4 ; mov r10,r5
    c.r[1] = ld32(0x06085498u);  // 0608543A mov.l 0x06085498,r1
    c.r[0] = c.r[8];  // 0608543C mov r8,r0
    c.r[0] += c.r[0];  // 0608543E add r0,r0
    c.r[0] += c.r[8];  // 06085440 add r8,r0
    c.r[1] = ld32(c.r[1]);  // 06085442 mov.l @r1,r1
    c.r[0] <<= 2;  // 06085444 shll2 r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06085446 mov.w @(r0,r1),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608545Au);  // 06085448 mov.w 0x0608545A,r1
    c.r[4] += c.r[1];  // 0608544A add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_060854A6;  // 0608544C bra 0x060854A6 ; extu.w r4,r4
L_0608549C:
    c.r[4] = ld32(0x06085514u);  // 0608549C mov.l 0x06085514,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060854A2u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060854A2u) return; }  // 0608549E jsr @r11 ; mov r10,r5
    c.r[5] = c.r[10];  // 060854A2 mov r10,r5
L_060854A4:
    c.r[4] = ld32(0x06085518u);  // 060854A4 mov.l 0x06085518,r4
L_060854A6:
    { const uint32_t x = c.r[11]; c.pr = 0x060854AAu; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060854AAu) return; }  // 060854A6 jsr @r11 ; add #1,r9
    c.r[1] = ld32(0x0608551Cu);  // 060854AA mov.l 0x0608551C,r1
    c.r[2] = ld32(c.r[1]);  // 060854AC mov.l @r1,r2
    c.r[1] = ld32(c.r[12]);  // 060854AE mov.l @r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608550Eu);  // 060854B0 mov.w 0x0608550E,r0
    c.r[2] += c.r[1];  // 060854B2 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060854B4 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060854B6 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060854B8 cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_060853E4; }  // 060854BA bf 0x060853E4
L_060854BC:
    c.r[1] = ld32(0x0608551Cu);  // 060854BC mov.l 0x0608551C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608550Eu);  // 060854BE mov.w 0x0608550E,r0
    c.r[5] = 0x9u;  // 060854C0 mov #9,r5
    c.r[2] = ld32(c.r[1]);  // 060854C2 mov.l @r1,r2
    c.r[7] = 0x2u;  // 060854C4 mov #2,r7
    c.r[1] = ld32(0x06085520u);  // 060854C6 mov.l 0x06085520,r1
    c.r[1] = ld32(c.r[1]);  // 060854C8 mov.l @r1,r1
    c.r[6] = 0x24u;  // 060854CA mov #36,r6
    c.r[2] += c.r[1];  // 060854CC add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060854CE mov.b @(r0,r2),r1
    c.r[4] = 0x2u;  // 060854D0 mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 060854D2 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060854D4 mov.l r1,@-r15
    c.r[2] = 0x1u;  // 060854D6 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060854D8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060854DA mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060854DC mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060854DE mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060854E0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060854E2 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060854E4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060854E6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060854E8 mov.l r5,@-r15
    c.r[1] = ld32(0x06085524u);  // 060854EA mov.l 0x06085524,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060854F0u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060854F0u) return; }  // 060854EC jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 060854F0 add #40,r15
    c.r[1] = ld32(0x06085528u);  // 060854F2 mov.l 0x06085528,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060854F8u; c.r[4] = 0x53u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060854F8u) return; }  // 060854F4 jsr @r1 ; mov #83,r4
    c.r[15] = c.r[14];  // 060854F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060854FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060854FC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060854FE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06085500 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06085502 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06085504 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06085506 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085510u);  // 06085508 mov.w 0x06085510,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608550A rts ; mov.l @r15+,r8
}

void f_0608552C(SH2Context& c) {
    ran[1853] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608552C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608552E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085530 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085532 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085534 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06085536 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085538 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608553A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608553C mov r15,r14
    c.r[11] = 0x7u;  // 0608553E mov #7,r11
    c.r[12] = 0x8u;  // 06085540 mov #8,r12
    c.r[10] = 0x1Bu;  // 06085542 mov #27,r10
    c.r[13] = 0xAu;  // 06085544 mov #10,r13
    c.r[1] = ld32(0x06085600u);  // 06085546 mov.l 0x06085600,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608554Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608554Cu) return; }  // 06085548 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06085604u);  // 0608554C mov.l 0x06085604,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085552u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085552u) return; }  // 0608554E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06085608u);  // 06085552 mov.l 0x06085608,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085558u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085558u) return; }  // 06085554 jsr @r1 ; nop
    c.r[9] = (uint32_t)(int16_t)ld16(0x060855FAu);  // 06085558 mov.w 0x060855FA,r9
    c.r[3] = 0x2u;  // 0608555A mov #2,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0608555C mov.l r3,@-r15
    c.r[8] = ld32(0x0608560Cu);  // 0608555E mov.l 0x0608560C,r8
    c.r[7] = 0x18u;  // 06085560 mov #24,r7
    c.r[6] = c.r[12];  // 06085562 mov r12,r6
    c.r[5] = c.r[11];  // 06085564 mov r11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608556Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608556Au) return; }  // 06085566 jsr @r8 ; mov r9,r4
    c.r[1] = 0x4u;  // 0608556A mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608556C mov.l r1,@-r15
    c.r[7] = 0x3u;  // 0608556E mov #3,r7
    c.r[6] = c.r[13];  // 06085570 mov r13,r6
    c.r[5] = c.r[10];  // 06085572 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085578u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085578u) return; }  // 06085574 jsr @r8 ; mov r9,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x060855FCu);  // 06085578 mov.w 0x060855FC,r11
    c.r[9] = ld32(0x06085610u);  // 0608557A mov.l 0x06085610,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06085580u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085580u) return; }  // 0608557C jsr @r9 ; mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06085584u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085584u) return; }  // 06085580 jsr @r9 ; mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06085588u; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085588u) return; }  // 06085584 jsr @r9 ; mov #9,r4
    c.r[4] = ld32(0x06085614u);  // 06085588 mov.l 0x06085614,r4
    c.r[8] = ld32(0x06085618u);  // 0608558A mov.l 0x06085618,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06085590u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085590u) return; }  // 0608558C jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06085590 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085596u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085596u) return; }  // 06085592 jsr @r8 ; mov r0,r4
    c.r[5] = 0x5Au;  // 06085596 mov #90,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608559Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608559Cu) return; }  // 06085598 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0608561Cu);  // 0608559C mov.l 0x0608561C,r1
    c.r[6] = 0x0u;  // 0608559E mov #0,r6
    c.r[5] = c.r[0];  // 060855A0 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060855A6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060855A6u) return; }  // 060855A2 jsr @r1 ; mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060855AAu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060855AAu) return; }  // 060855A6 jsr @r9 ; mov r11,r4
    c.r[11] = 0x1Cu;  // 060855AA mov #28,r11
    { const uint32_t x = c.r[9]; c.pr = 0x060855B0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060855B0u) return; }  // 060855AC jsr @r9 ; mov r11,r4
    c.r[8] = 0xBu;  // 060855B0 mov #11,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060855B6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060855B6u) return; }  // 060855B2 jsr @r9 ; mov r8,r4
    c.r[3] = 0x2u;  // 060855B6 mov #2,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060855B8 mov.l r3,@-r15
    c.r[2] = 0x1u;  // 060855BA mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060855BC mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060855BE mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060855C0 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060855C2 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060855C4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060855C6 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060855C8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060855CA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060855CC mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060855CE mov.l r2,@-r15
    c.r[1] = ld32(0x06085620u);  // 060855D0 mov.l 0x06085620,r1
    c.r[7] = 0x2u;  // 060855D2 mov #2,r7
    c.r[6] = 0x5u;  // 060855D4 mov #5,r6
    c.r[5] = c.r[8];  // 060855D6 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060855DCu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060855DCu) return; }  // 060855D8 jsr @r1 ; mov r11,r4
    c.r[15] += 48;  // 060855DC add #48,r15
    c.r[1] = ld32(0x06085624u);  // 060855DE mov.l 0x06085624,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060855E4u; c.r[4] = 0x41u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060855E4u) return; }  // 060855E0 jsr @r1 ; mov #65,r4
    c.r[15] = c.r[14];  // 060855E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060855E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060855E8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060855EA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060855EC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060855EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060855F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060855F2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060855FEu);  // 060855F4 mov.w 0x060855FE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060855F6 rts ; mov.l @r15+,r8
}

void f_06085628(SH2Context& c) {
    ran[1854] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085628 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608562A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608562C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608562E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085630 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06085632 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085634 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085636 sts.l pr,@-r15
    c.r[15] -= 16;  // 06085638 add #-16,r15
    c.r[14] = c.r[15];  // 0608563A mov r15,r14
    c.r[1] = ld32(0x060856C4u);  // 0608563C mov.l 0x060856C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085642u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085642u) return; }  // 0608563E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060856C8u);  // 06085642 mov.l 0x060856C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085648u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085648u) return; }  // 06085644 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060856CCu);  // 06085648 mov.l 0x060856CC,r1
    c.r[4] = ld32(c.r[1]);  // 0608564A mov.l @r1,r4
    c.r[1] = ld32(0x060856D0u);  // 0608564C mov.l 0x060856D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085652u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085652u) return; }  // 0608564E jsr @r1 ; nop
    c.r[1] = ld32(0x060856D4u);  // 06085652 mov.l 0x060856D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085658u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085658u) return; }  // 06085654 jsr @r1 ; nop
    c.r[11] = ld32(0x060856D8u);  // 06085658 mov.l 0x060856D8,r11
    c.r[10] = ld32(0x060856DCu);  // 0608565A mov.l 0x060856DC,r10
    c.r[9] = ld32(0x060856E0u);  // 0608565C mov.l 0x060856E0,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0608565E mov.b @r11,r1
    c.r[5] = 0x0u;  // 06085660 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06085662 extu.b r1,r1
    c.r[0] = c.r[1];  // 06085664 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06085666 mov.b @(r0,r10),r6
    c.r[4] = 0x0u;  // 06085668 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0608566Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608566Eu) return; }  // 0608566A jsr @r9 ; extu.b r6,r6
    c.r[8] = ld32(0x060856E4u);  // 0608566E mov.l 0x060856E4,r8
    c.r[1] = ld32(c.r[8]);  // 06085670 mov.l @r8,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060856C0u);  // 06085672 mov.w 0x060856C0,r12
    c.r[0] = c.r[1];  // 06085674 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06085676 mov.b @(r0,r12),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06085678 extu.b r2,r2
    c.r[2] += 6;  // 0608567A add #6,r2
    c.r[1] = ld32(0x060856E8u);  // 0608567C mov.l 0x060856E8,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0608567E dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06085680 mov #0,r5
    c.r[4] = 0x0u;  // 06085682 mov #0,r4
    c.r[6] = c.mach;  // 06085684 sts mach,r6
    c.r[6] += c.r[2];  // 06085686 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06085688 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0608568A shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0608568C shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0608568E subc r2,r2
    { const uint32_t x = c.r[9]; c.pr = 0x06085694u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085694u) return; }  // 06085690 jsr @r9 ; sub r2,r6
    c.r[1] = ld32(c.r[8]);  // 06085694 mov.l @r8,r1
    c.r[0] = c.r[1];  // 06085696 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06085698 mov.b @(r0,r12),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0608569A mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608569C extu.b r1,r1
    c.r[0] = c.r[1];  // 0608569E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060856A0 mov.b @(r0,r10),r1
    c.r[3] = 0x7u;  // 060856A2 mov #7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060856A4 extu.b r1,r1
    c.r[1] -= 1;  // 060856A6 add #-1,r1
    c.macl = c.r[1] * c.r[3];  // 060856A8 mul.l r3,r1
    c.r[2] = c.r[7] & 0xFFu;  // 060856AA extu.b r7,r2
    c.r[1] = c.macl;  // 060856AC sts macl,r1
    c.r[2] -= c.r[1];  // 060856AE sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 060856B0 cmp/gt r3,r2
    { const bool k = c.t; c.r[4] = c.r[3]; if (k) { goto L_060856EC; } }  // 060856B2 bt/s 0x060856EC ; mov r3,r4
    c.r[0] = c.r[7];  // 060856B6 mov r7,r0
    c.r[0] -= c.r[1];  // 060856B8 sub r1,r0
    c.r[1] = c.r[0];  // 060856BA mov r0,r1
    c.r[4] = c.r[1] & 0xFFu; goto L_060856EC;  // 060856BC bra 0x060856EC ; extu.b r1,r4
L_060856EC:
    c.r[1] = ld32(0x06085878u);  // 060856EC mov.l 0x06085878,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060856F2u; c.r[10] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060856F2u) return; }  // 060856EE jsr @r1 ; mov r4,r10
    c.r[1] = ld32(0x0608587Cu);  // 060856F2 mov.l 0x0608587C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060856F4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060856F6 extu.b r1,r0
    c.r[1] = ld32(0x06085880u);  // 060856F8 mov.l 0x06085880,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060856FA mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 060856FC mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060856FE extu.b r1,r1
    c.r[1] -= 1;  // 06085700 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06085702 mul.l r2,r1
    c.r[9] = c.macl;  // 06085704 sts macl,r9
    c.r[1] = c.macl;  // 06085706 sts macl,r1
    c.r[1] += c.r[10];  // 06085708 add r10,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0608570A cmp/ge r1,r9
    if (c.t) { goto L_06085798; }  // 0608570C bt 0x06085798
    c.r[12] = ld32(0x06085884u);  // 0608570E mov.l 0x06085884,r12
L_06085710:
    c.r[1] = ld32(0x06085888u);  // 06085710 mov.l 0x06085888,r1
    c.r[2] = ld32(c.r[1]);  // 06085712 mov.l @r1,r2
    c.r[8] = ld32(0x06085878u);  // 06085714 mov.l 0x06085878,r8
    c.r[1] = c.r[9];  // 06085716 mov r9,r1
    c.r[1] += c.r[1];  // 06085718 add r1,r1
    c.r[2] += c.r[1];  // 0608571A add r1,r2
    c.r[2] += 1;  // 0608571C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608571E mov.b @r2,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608586Eu);  // 06085720 mov.w 0x0608586E,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06085726u; c.r[11] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085726u) return; }  // 06085722 jsr @r8 ; extu.b r1,r11
    { const uint32_t x = c.r[8]; c.pr = 0x0608572Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608572Au) return; }  // 06085726 jsr @r8 ; mov #1,r4
    c.r[8] = c.r[11];  // 0608572A mov r11,r8
    c.r[8] <<= 2;  // 0608572C shll2 r8
    c.r[8] += c.r[11];  // 0608572E add r11,r8
    c.r[1] = ld32(c.r[12]);  // 06085730 mov.l @r12,r1
    c.r[8] <<= 2;  // 06085732 shll2 r8
    c.r[1] += c.r[8];  // 06085734 add r8,r1
    c.r[1] += 44;  // 06085736 add #44,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06085738 mov.w @r1,r4
    c.r[5] = c.r[11];  // 0608573A mov r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085870u);  // 0608573C mov.w 0x06085870,r1
    c.r[4] += c.r[1];  // 0608573E add r1,r4
    c.r[1] = ld32(0x0608588Cu);  // 06085740 mov.l 0x0608588C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085746u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085746u) return; }  // 06085742 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[12]);  // 06085746 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06085748 mov #0,r5
    c.r[1] += c.r[8];  // 0608574A add r8,r1
    c.r[1] += 48;  // 0608574C add #48,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608574E mov.w @r1,r6
    c.r[4] = 0x0u;  // 06085750 mov #0,r4
    c.r[1] = ld32(0x06085890u);  // 06085752 mov.l 0x06085890,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085758u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085758u) return; }  // 06085754 jsr @r1 ; extu.w r6,r6
    c.r[2] = ld32(c.r[12]);  // 06085758 mov.l @r12,r2
    c.r[2] += c.r[8];  // 0608575A add r8,r2
    c.r[1] = c.r[2];  // 0608575C mov r2,r1
    c.r[1] += 62;  // 0608575E add #62,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085760 mov.b @r1,r5
    c.r[2] += 61;  // 06085762 add #61,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085764 mov.b @r2,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06085766 extu.b r5,r5
    c.r[1] = ld32(0x06085894u);  // 06085768 mov.l 0x06085894,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608576Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608576Eu) return; }  // 0608576A jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(c.r[12]);  // 0608576E mov.l @r12,r1
    c.r[1] += c.r[8];  // 06085770 add r8,r1
    c.r[1] += 58;  // 06085772 add #58,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085774 mov.b @r1,r5
    c.r[1] = ld32(0x06085898u);  // 06085776 mov.l 0x06085898,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608577Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608577Cu) return; }  // 06085778 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0608587Cu);  // 0608577C mov.l 0x0608587C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608577E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06085780 extu.b r1,r0
    c.r[1] = ld32(0x06085880u);  // 06085782 mov.l 0x06085880,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06085784 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06085786 extu.b r2,r2
    c.r[2] -= 1;  // 06085788 add #-1,r2
    c.r[1] = 0x7u;  // 0608578A mov #7,r1
    c.macl = c.r[2] * c.r[1];  // 0608578C mul.l r1,r2
    c.r[9] += 1;  // 0608578E add #1,r9
    c.r[1] = c.macl;  // 06085790 sts macl,r1
    c.r[1] += c.r[10];  // 06085792 add r10,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06085794 cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06085710; }  // 06085796 bf 0x06085710
L_06085798:
    c.r[1] = ld32(0x0608589Cu);  // 06085798 mov.l 0x0608589C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608579A mov.b @r1,r4
    c.r[5] = c.r[14];  // 0608579C mov r14,r5
    c.r[1] = ld32(0x060858A0u);  // 0608579E mov.l 0x060858A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060857A4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060857A4u) return; }  // 060857A0 jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0608587Cu);  // 060857A4 mov.l 0x0608587C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060857A6 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060857A8 extu.b r1,r3
    c.r[1] = ld32(0x06085880u);  // 060857AA mov.l 0x06085880,r1
    c.r[0] = c.r[3];  // 060857AC mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060857AE mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 060857B0 mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060857B2 extu.b r1,r1
    c.r[1] -= 1;  // 060857B4 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 060857B6 mul.l r2,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06085872u);  // 060857B8 mov.w 0x06085872,r9
    c.r[1] = ld32(0x060858A4u);  // 060857BA mov.l 0x060858A4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060857BC mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 060857BE sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060857C0 extu.b r1,r1
    c.r[2] += c.r[1];  // 060857C2 add r1,r2
    c.r[1] = ld32(0x06085888u);  // 060857C4 mov.l 0x06085888,r1
    c.r[1] = ld32(c.r[1]);  // 060857C6 mov.l @r1,r1
    c.r[2] += c.r[2];  // 060857C8 add r2,r2
    c.r[1] += c.r[2];  // 060857CA add r2,r1
    c.r[1] += 1;  // 060857CC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060857CE mov.b @r1,r1
    c.r[0] = ld32(0x06085884u);  // 060857D0 mov.l 0x06085884,r0
    c.r[11] = c.r[1] & 0xFFu;  // 060857D2 extu.b r1,r11
    c.r[8] = c.r[11];  // 060857D4 mov r11,r8
    c.r[8] <<= 2;  // 060857D6 shll2 r8
    c.r[12] = c.r[8];  // 060857D8 mov r8,r12
    c.r[12] += c.r[11];  // 060857DA add r11,r12
    c.r[1] = ld32(c.r[0]);  // 060857DC mov.l @r0,r1
    c.r[12] <<= 2;  // 060857DE shll2 r12
    c.r[1] += c.r[12];  // 060857E0 add r12,r1
    c.r[1] += 52;  // 060857E2 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060857E4 mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 060857E6 extu.w r1,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060857E8 shlr r6
    c.r[6] &= c.r[9];  // 060857EA and r9,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 060857EC tst r6,r6
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_060857F4; } }  // 060857EE bf/s 0x060857F4 ; mov #0,r4
    c.r[4] = 0x30u;  // 060857F2 mov #48,r4
L_060857F4:
    c.r[10] = c.r[4];  // 060857F4 mov r4,r10
    c.r[13] = ld32(0x06085890u);  // 060857F6 mov.l 0x06085890,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060857FCu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060857FCu) return; }  // 060857F8 jsr @r13 ; mov #0,r5
    c.r[0] = ld32(0x06085884u);  // 060857FC mov.l 0x06085884,r0
    c.r[1] = ld32(c.r[0]);  // 060857FE mov.l @r0,r1
    c.r[5] = 0x0u;  // 06085800 mov #0,r5
    c.r[1] += c.r[12];  // 06085802 add r12,r1
    c.r[1] += 52;  // 06085804 add #52,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06085806 mov.w @r1,r6
    c.r[4] = c.r[10];  // 06085808 mov r10,r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 0608580A extu.w r6,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0608580C shlr r6
    { const uint32_t x = c.r[13]; c.pr = 0x06085812u; c.r[6] &= c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085812u) return; }  // 0608580E jsr @r13 ; and r9,r6
    c.r[0] = 0x2u;  // 06085812 mov #2,r0
    c.r[8] |= c.r[0];  // 06085814 or r0,r8
    c.r[8] = c.r[8] & 0xFFu;  // 06085816 extu.b r8,r8
    c.r[9] = ld32(0x060858A8u);  // 06085818 mov.l 0x060858A8,r9
    c.r[5] = 0x2u;  // 0608581A mov #2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06085820u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085820u) return; }  // 0608581C jsr @r9 ; mov r8,r4
    c.r[5] = 0x0u;  // 06085820 mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06085826u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085826u) return; }  // 06085822 jsr @r9 ; mov r8,r4
    c.r[5] = 0x1u;  // 06085826 mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608582Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608582Cu) return; }  // 06085828 jsr @r9 ; mov r8,r4
    c.r[5] = 0x3u;  // 0608582C mov #3,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06085832u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085832u) return; }  // 0608582E jsr @r9 ; mov r8,r4
    c.r[0] = ld32(0x06085884u);  // 06085832 mov.l 0x06085884,r0
    c.r[1] = ld32(c.r[0]);  // 06085834 mov.l @r0,r1
    c.r[5] = 0x0u;  // 06085836 mov #0,r5
    c.r[1] += c.r[12];  // 06085838 add r12,r1
    c.r[1] += 59;  // 0608583A add #59,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608583C mov.b @r1,r6
    c.r[4] = 0x30u;  // 0608583E mov #48,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06085844u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085844u) return; }  // 06085840 jsr @r13 ; extu.b r6,r6
    c.r[0] = ld32(0x06085884u);  // 06085844 mov.l 0x06085884,r0
    c.r[1] = ld32(c.r[0]);  // 06085846 mov.l @r0,r1
    c.r[1] += 14;  // 06085848 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608584A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0608584C extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085874u);  // 0608584E mov.w 0x06085874,r1
    c.t = c.r[3] == c.r[1];  // 06085850 cmp/eq r1,r3
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060858B0; } }  // 06085852 bt/s 0x060858B0 ; mov #0,r5
    c.r[1] = ld32(0x060858ACu);  // 06085856 mov.l 0x060858AC,r1
    c.r[2] = c.r[3];  // 06085858 mov r3,r2
    c.r[2] += c.r[2];  // 0608585A add r2,r2
    c.r[2] += c.r[3];  // 0608585C add r3,r2
    c.r[2] <<= 2;  // 0608585E shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06085860 mov.l @r1,r1
    c.r[2] += c.r[1];  // 06085862 add r1,r2
    c.r[2] += 9;  // 06085864 add #9,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085866 mov.b @r2,r6
    c.r[4] = 0x0u;  // 06085868 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu; goto L_060858B4;  // 0608586A bra 0x060858B4 ; extu.b r6,r6
L_060858B0:
    c.r[6] = 0x0u;  // 060858B0 mov #0,r6
    c.r[4] = 0x30u;  // 060858B2 mov #48,r4
L_060858B4:
    { const uint32_t x = c.r[13]; c.pr = 0x060858B8u; c.r[10] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060858B8u) return; }  // 060858B4 jsr @r13 ; mov r11,r10
    c.r[8] = ld32(0x06085990u);  // 060858B8 mov.l 0x06085990,r8
    c.r[10] <<= 2;  // 060858BA shll2 r10
    c.r[10] += c.r[11];  // 060858BC add r11,r10
    c.r[10] <<= 2;  // 060858BE shll2 r10
    c.r[9] = ld32(0x06085994u);  // 060858C0 mov.l 0x06085994,r9
    c.r[1] = ld32(c.r[8]);  // 060858C2 mov.l @r8,r1
    c.r[5] = 0x0u;  // 060858C4 mov #0,r5
    c.r[1] += c.r[10];  // 060858C6 add r10,r1
    c.r[1] += 54;  // 060858C8 add #54,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060858CA mov.w @r1,r6
    c.r[4] = 0x30u;  // 060858CC mov #48,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060858D2u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060858D2u) return; }  // 060858CE jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 060858D2 mov.l @r8,r1
    c.r[5] = 0x0u;  // 060858D4 mov #0,r5
    c.r[1] += 24;  // 060858D6 add #24,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060858D8 mov.w @r1,r6
    c.r[4] = 0x0u;  // 060858DA mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060858E0u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060858E0u) return; }  // 060858DC jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 060858E0 mov.l @r8,r1
    c.r[1] += c.r[10];  // 060858E2 add r10,r1
    c.r[1] += 60;  // 060858E4 add #60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060858E6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060858E8 extu.b r1,r1
    c.r[4] = c.r[1];  // 060858EA mov r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060858EC tst r4,r4
    if (!c.t) { goto L_060858F8; }  // 060858EE bf 0x060858F8
    c.r[5] = (uint32_t)(int16_t)ld16(0x06085986u);  // 060858F0 mov.w 0x06085986,r5
    c.r[4] = ld32(0x06085998u);  // 060858F2 mov.l 0x06085998,r4
    goto L_06085900;  // 060858F4 bra 0x06085900 ; nop
L_060858F8:
    c.r[5] = (uint32_t)(int16_t)ld16(0x06085986u);  // 060858F8 mov.w 0x06085986,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085988u);  // 060858FA mov.w 0x06085988,r1
    c.r[4] += c.r[1];  // 060858FC add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 060858FE extu.w r4,r4
L_06085900:
    c.r[1] = ld32(0x0608599Cu);  // 06085900 mov.l 0x0608599C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085906u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085906u) return; }  // 06085902 jsr @r1 ; nop
    c.r[1] = ld32(0x06085990u);  // 06085906 mov.l 0x06085990,r1
    c.r[2] = ld32(c.r[1]);  // 06085908 mov.l @r1,r2
    c.r[1] = c.r[11];  // 0608590A mov r11,r1
    c.r[1] <<= 2;  // 0608590C shll2 r1
    c.r[1] += c.r[11];  // 0608590E add r11,r1
    c.r[1] <<= 2;  // 06085910 shll2 r1
    c.r[2] += c.r[1];  // 06085912 add r1,r2
    c.r[1] = c.r[2];  // 06085914 mov r2,r1
    c.r[1] += 51;  // 06085916 add #51,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085918 mov.b @r1,r0
    c.r[2] += 52;  // 0608591A add #52,r2
    c.r[0] &= 0x1u;  // 0608591C and #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608591E mov.b @r2,r1
    c.r[0] <<= 2;  // 06085920 shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 06085922 extu.b r1,r1
    c.r[1] >>= 2;  // 06085924 shlr2 r1
    c.r[1] >>= 2;  // 06085926 shlr2 r1
    c.r[1] >>= 2;  // 06085928 shlr2 r1
    c.r[0] |= c.r[1];  // 0608592A or r1,r0
    c.r[1] = ld32(0x060859A0u);  // 0608592C mov.l 0x060859A0,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608592E mov.b @(r0,r1),r5
    c.r[1] = ld32(0x060859A4u);  // 06085930 mov.l 0x060859A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085936u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085936u) return; }  // 06085932 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060859A8u);  // 06085936 mov.l 0x060859A8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608598Au);  // 06085938 mov.w 0x0608598A,r0
    c.r[2] = 0x1u;  // 0608593A mov #1,r2
    c.r[7] = 0x2u;  // 0608593C mov #2,r7
    c.r[6] = 0x22u;  // 0608593E mov #34,r6
    c.r[1] = ld32(c.r[1]);  // 06085940 mov.l @r1,r1
    c.r[5] = 0x4u;  // 06085942 mov #4,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06085944 mov.b @(r0,r1),r1
    c.r[4] = 0x3u;  // 06085946 mov #3,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06085948 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608594A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608594C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608594E mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06085950 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085952 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085954 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06085956 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085958 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608595A mov.l r1,@-r15
    c.r[1] = 0x7u;  // 0608595C mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608595E mov.l r1,@-r15
    c.r[1] = ld32(0x060859ACu);  // 06085960 mov.l 0x060859AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085966u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085966u) return; }  // 06085962 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06085966 add #40,r15
    c.r[1] = ld32(0x060859B0u);  // 06085968 mov.l 0x060859B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608596Eu; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608596Eu) return; }  // 0608596A jsr @r1 ; mov #9,r4
    c.r[14] += 16;  // 0608596E add #16,r14
    c.r[15] = c.r[14];  // 06085970 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085972 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085974 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06085976 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06085978 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608597A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608597C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608597E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608598Cu);  // 06085980 mov.w 0x0608598C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085982 rts ; mov.l @r15+,r8
}

void f_060859B4(SH2Context& c) {
    ran[1855] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060859B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060859B6 sts.l pr,@-r15
    c.r[1] = ld32(0x060859D4u);  // 060859B8 mov.l 0x060859D4,r1
    c.r[1] = ld32(c.r[1]);  // 060859BA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060859BC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060859BE extu.b r1,r0
    c.r[0] <<= 2;  // 060859C0 shll2 r0
    c.r[1] = ld32(0x060859D8u);  // 060859C2 mov.l 0x060859D8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060859C4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060859CAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060859CAu) return; }  // 060859C6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060859CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060859CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060859CE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060859D0 rts ; extu.w r0,r0
}

void f_060859DC(SH2Context& c) {
    ran[1856] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060859DC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060859DE sts.l pr,@-r15
    c.r[1] = ld32(0x06085A30u);  // 060859E0 mov.l 0x06085A30,r1
    c.r[2] = ld32(c.r[1]);  // 060859E2 mov.l @r1,r2
    c.r[2] += 1;  // 060859E4 add #1,r2
    st32(c.r[1], c.r[2]);  // 060859E6 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060859E8 mov.b @r2,r1
    c.r[14] = c.r[15];  // 060859EA mov r15,r14
    c.r[3] = c.r[1] & 0xFFu;  // 060859EC extu.b r1,r3
    c.r[0] = c.r[3];  // 060859EE mov r3,r0
    c.t = c.r[0] == 0x1u;  // 060859F0 cmp/eq #1,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06085A18; } }  // 060859F2 bt/s 0x06085A18 ; mov r3,r2
    c.r[1] = 0x1u;  // 060859F6 mov #1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060859F8 cmp/gt r1,r3
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06085A08; } }  // 060859FA bt/s 0x06085A08 ; mov r2,r0
    c.t = (c.r[3] & c.r[3]) == 0;  // 060859FE tst r3,r3
    if (c.t) { goto L_06085A12; }  // 06085A00 bt 0x06085A12
    c.r[15] = c.r[14];  // 06085A02 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06085A28;  // 06085A04 bra 0x06085A28 ; lds.l @r15+,pr
L_06085A08:
    c.t = c.r[0] == 0x2u;  // 06085A08 cmp/eq #2,r0
    if (c.t) { goto L_06085A1E; }  // 06085A0A bt 0x06085A1E
    c.r[15] = c.r[14];  // 06085A0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06085A28;  // 06085A0E bra 0x06085A28 ; lds.l @r15+,pr
L_06085A12:
    c.r[1] = ld32(0x06085A34u);  // 06085A12 mov.l 0x06085A34,r1
    goto L_06085A20;  // 06085A14 bra 0x06085A20 ; nop
L_06085A18:
    c.r[1] = ld32(0x06085A38u);  // 06085A18 mov.l 0x06085A38,r1
    goto L_06085A20;  // 06085A1A bra 0x06085A20 ; nop
L_06085A1E:
    c.r[1] = ld32(0x06085A3Cu);  // 06085A1E mov.l 0x06085A3C,r1
L_06085A20:
    { const uint32_t x = c.r[1]; c.pr = 0x06085A24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085A24u) return; }  // 06085A20 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06085A24 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085A26 lds.l @r15+,pr
L_06085A28:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085A2Eu);  // 06085A28 mov.w 0x06085A2E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085A2A rts ; mov.l @r15+,r14
}

void f_06085A40(SH2Context& c) {
    ran[1857] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085A40 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085A42 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06085A44 mov r15,r14
    c.r[2] = ld32(0x06085A68u);  // 06085A46 mov.l 0x06085A68,r2
    c.r[1] = 0x1u;  // 06085A48 mov #1,r1
    c.r[0] = ld32(0x06085A6Cu);  // 06085A4A mov.l 0x06085A6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06085A50u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085A50u) return; }  // 06085A4C jsr @r0 ; mov.b r1,@r2
    c.r[1] = ld32(0x06085A70u);  // 06085A50 mov.l 0x06085A70,r1
    c.r[0] = c.r[0] & 0xFFu;  // 06085A52 extu.b r0,r0
    c.t = c.r[0] == 0x1u;  // 06085A54 cmp/eq #1,r0
    c.r[2] = c.t;  // 06085A56 movt r2
    c.r[0] = c.r[2];  // 06085A58 mov r2,r0
    c.r[0] ^= 0x1u;  // 06085A5A xor #1,r0
    st8(c.r[1], c.r[0]);  // 06085A5C mov.b r0,@r1
    c.r[15] = c.r[14];  // 06085A5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085A60 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085A62 rts ; mov.l @r15+,r14
}

void f_06085A74(SH2Context& c) {
    ran[1858] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085A74 mov.l r14,@-r15
    c.r[1] = ld32(0x06085A98u);  // 06085A76 mov.l 0x06085A98,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085A78 mov.b @r1,r2
    c.r[14] = c.r[15];  // 06085A7A mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 06085A7C extu.b r2,r2
    c.r[2] -= 1;  // 06085A7E add #-1,r2
    c.r[1] = 0x16u;  // 06085A80 mov #22,r1
    c.macl = c.r[2] * c.r[1];  // 06085A82 mul.l r1,r2
    c.r[3] = ld32(0x06085A9Cu);  // 06085A84 mov.l 0x06085A9C,r3
    c.r[1] = ld32(0x06085AA0u);  // 06085A86 mov.l 0x06085AA0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085A88 mov.b @r1,r1
    c.r[2] = c.macl;  // 06085A8A sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06085A8C extu.b r1,r1
    c.r[2] += c.r[1];  // 06085A8E add r1,r2
    st16(c.r[3], c.r[2]);  // 06085A90 mov.w r2,@r3
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085A92 rts ; mov.l @r15+,r14
}

void f_06085AA8(SH2Context& c) {
    ran[1859] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085AA8 mov.l r14,@-r15
    c.r[1] = ld32(0x06085AD8u);  // 06085AAA mov.l 0x06085AD8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06085AAC mov.w @r1,r2
    c.r[1] = ld32(0x06085ADCu);  // 06085AAE mov.l 0x06085ADC,r1
    c.r[1] = ld32(c.r[1]);  // 06085AB0 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06085AB2 extu.w r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06085AB4 dmulu.l r1,r2
    c.r[14] = c.r[15];  // 06085AB6 mov r15,r14
    c.r[7] = ld32(0x06085AE0u);  // 06085AB8 mov.l 0x06085AE0,r7
    c.r[3] = c.mach;  // 06085ABA sts mach,r3
    c.r[3] >>= 2;  // 06085ABC shlr2 r3
    c.r[3] >>= 2;  // 06085ABE shlr2 r3
    c.r[1] = c.r[3];  // 06085AC0 mov r3,r1
    c.r[1] += 1;  // 06085AC2 add #1,r1
    st8(c.r[7], c.r[1]);  // 06085AC4 mov.b r1,@r7
    c.r[1] = 0x16u;  // 06085AC6 mov #22,r1
    c.macl = c.r[3] * c.r[1];  // 06085AC8 mul.l r1,r3
    c.r[7] = ld32(0x06085AE4u);  // 06085ACA mov.l 0x06085AE4,r7
    c.r[1] = c.macl;  // 06085ACC sts macl,r1
    c.r[2] -= c.r[1];  // 06085ACE sub r1,r2
    st8(c.r[7], c.r[2]);  // 06085AD0 mov.b r2,@r7
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085AD2 rts ; mov.l @r15+,r14
}

void f_06085AE8(SH2Context& c) {
    ran[1860] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085AE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085AEA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085AEC sts.l pr,@-r15
    c.r[8] = ld32(0x06085B44u);  // 06085AEE mov.l 0x06085B44,r8
    c.r[1] = ld32(c.r[8]);  // 06085AF0 mov.l @r8,r1
    c.r[1] += 8;  // 06085AF2 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085AF4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06085AF6 mov r1,r0
    c.r[0] >>= 2;  // 06085AF8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06085AFA shlr r0
    c.r[0] &= 0x1u;  // 06085AFC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085AFE tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06085B16; } }  // 06085B00 bf/s 0x06085B16 ; mov r15,r14
    c.r[1] = ld32(0x06085B48u);  // 06085B04 mov.l 0x06085B48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085B0Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085B0Au) return; }  // 06085B06 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(c.r[8]);  // 06085B0A mov.l @r8,r1
    c.r[1] += 8;  // 06085B0C add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085B0E mov.b @r1,r0
    c.r[4] = 0x1u;  // 06085B10 mov #1,r4
    c.r[0] |= 0x8u; goto L_06085B26;  // 06085B12 bra 0x06085B26 ; or #8,r0
L_06085B16:
    c.r[1] = ld32(0x06085B48u);  // 06085B16 mov.l 0x06085B48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085B1Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085B1Cu) return; }  // 06085B18 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(c.r[8]);  // 06085B1C mov.l @r8,r1
    c.r[1] += 8;  // 06085B1E add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085B20 mov.b @r1,r0
    c.r[4] = 0x0u;  // 06085B22 mov #0,r4
    c.r[0] &= 0xF7u;  // 06085B24 and #247,r0
L_06085B26:
    st8(c.r[1], c.r[0]);  // 06085B26 mov.b r0,@r1
    c.r[1] = ld32(0x06085B4Cu);  // 06085B28 mov.l 0x06085B4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085B2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085B2Eu) return; }  // 06085B2A jsr @r1 ; nop
    c.r[0] = ld32(0x06085B50u);  // 06085B2E mov.l 0x06085B50,r0
    c.r[5] = 0x0u;  // 06085B30 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06085B36u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085B36u) return; }  // 06085B32 jsr @r0 ; mov #15,r4
    c.r[15] = c.r[14];  // 06085B36 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085B38 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085B3A mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085B42u);  // 06085B3C mov.w 0x06085B42,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085B3E rts ; mov.l @r15+,r8
}

void f_06085B54(SH2Context& c) {
    ran[1861] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085B54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06085B56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085B58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085B5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085B5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085B5E sts.l pr,@-r15
    c.r[9] = ld32(0x06085C08u);  // 06085B60 mov.l 0x06085C08,r9
    c.r[1] = 0x0u;  // 06085B62 mov #0,r1
    st16(c.r[9], c.r[1]);  // 06085B64 mov.w r1,@r9
    c.r[1] = ld32(0x06085C0Cu);  // 06085B66 mov.l 0x06085C0C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085B68 mov.b @r1,r1
    c.r[8] = ld32(0x06085C10u);  // 06085B6A mov.l 0x06085C10,r8
    c.t = (c.r[1] & c.r[1]) == 0;  // 06085B6C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06085B98; } }  // 06085B6E bt/s 0x06085B98 ; mov r15,r14
    c.r[1] = 0x1u;  // 06085B72 mov #1,r1
    st16(c.r[9], c.r[1]);  // 06085B74 mov.w r1,@r9
    c.r[11] = ld32(0x06085C14u);  // 06085B76 mov.l 0x06085C14,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085C00u);  // 06085B78 mov.w 0x06085C00,r1
    st16(c.r[11], c.r[1]);  // 06085B7A mov.w r1,@r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x06085C02u);  // 06085B7C mov.w 0x06085C02,r10
    c.r[0] = ld32(0x06085C18u);  // 06085B7E mov.l 0x06085C18,r0
    c.r[5] = 0x0u;  // 06085B80 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06085B86u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085B86u) return; }  // 06085B82 jsr @r0 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085B86 tst r0,r0
    if (c.t) { goto L_06085B98; }  // 06085B88 bt 0x06085B98
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06085B8A mov.w @r9,r2
    c.r[1] = c.r[2];  // 06085B8C mov r2,r1
    c.r[1] += 1;  // 06085B8E add #1,r1
    st16(c.r[9], c.r[1]);  // 06085B90 mov.w r1,@r9
    c.r[0] = c.r[2] & 0xFFFFu;  // 06085B92 extu.w r2,r0
    c.r[0] += c.r[0];  // 06085B94 add r0,r0
    st16(c.r[0] + c.r[11], c.r[10]);  // 06085B96 mov.w r10,@(r0,r11)
L_06085B98:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085B98 mov.w @r8,r4
    c.r[1] = ld32(0x06085C1Cu);  // 06085B9A mov.l 0x06085C1C,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 06085B9C extu.w r4,r2
    c.t = c.r[2] == c.r[1];  // 06085B9E cmp/eq r1,r2
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06085BD8; } }  // 06085BA0 bt/s 0x06085BD8 ; mov #0,r9
    c.r[11] = ld32(0x06085C18u);  // 06085BA4 mov.l 0x06085C18,r11
    c.r[10] = ld32(0x06085C08u);  // 06085BA6 mov.l 0x06085C08,r10
L_06085BA8:
    c.r[4] = c.r[4] & 0xFFFFu;  // 06085BA8 extu.w r4,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06085BAEu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085BAEu) return; }  // 06085BAA jsr @r11 ; mov #0,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085BAE tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06085BC8; } }  // 06085BB0 bt/s 0x06085BC8 ; mov r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06085BB4 mov.w @r10,r2
    c.r[1] = c.r[2];  // 06085BB6 mov r2,r1
    c.r[1] += 1;  // 06085BB8 add #1,r1
    st16(c.r[10], c.r[1]);  // 06085BBA mov.w r1,@r10
    c.r[0] = c.r[2] & 0xFFFFu;  // 06085BBC extu.w r2,r0
    c.r[0] += c.r[0];  // 06085BBE add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085BC0 mov.w @r8,r1
    c.r[2] = ld32(0x06085C14u);  // 06085BC2 mov.l 0x06085C14,r2
    st16(c.r[0] + c.r[2], c.r[1]);  // 06085BC4 mov.w r1,@(r0,r2)
    c.r[1] = c.r[9];  // 06085BC6 mov r9,r1
L_06085BC8:
    c.r[1] += 1;  // 06085BC8 add #1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06085BCA extu.w r1,r9
    c.r[8] += 2;  // 06085BCC add #2,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085BCE mov.w @r8,r4
    c.r[1] = ld32(0x06085C1Cu);  // 06085BD0 mov.l 0x06085C1C,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 06085BD2 extu.w r4,r2
    c.t = c.r[2] == c.r[1];  // 06085BD4 cmp/eq r1,r2
    if (!c.t) { SH2_POLL(c); goto L_06085BA8; }  // 06085BD6 bf 0x06085BA8
L_06085BD8:
    c.r[6] = ld32(0x06085C20u);  // 06085BD8 mov.l 0x06085C20,r6
    c.r[1] = ld32(0x06085C08u);  // 06085BDA mov.l 0x06085C08,r1
    c.r[9] += 2;  // 06085BDC add #2,r9
    c.r[5] = c.r[9];  // 06085BDE mov r9,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06085BE0 mov.w @r1,r2
    c.r[7] = ld32(0x06085C24u);  // 06085BE2 mov.l 0x06085C24,r7
    c.r[1] = 0x64u;  // 06085BE4 mov #100,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06085BE6 mulu.w r1,r2
    c.r[15] = c.r[14];  // 06085BE8 mov r14,r15
    { const uint32_t x = c.r[7]; c.pr = 0x06085BEEu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085BEEu) return; }  // 06085BEA jsr @r7 ; sts macl,r4
    st32(c.r[6], c.r[0]);  // 06085BEE mov.l r0,@r6
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085BF0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085BF2 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06085BF4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06085BF6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06085BF8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085C04u);  // 06085BFA mov.w 0x06085C04,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085BFC rts ; mov.l @r15+,r8
}

void f_06085C28(SH2Context& c) {
    ran[1862] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085C28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06085C2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085C2C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085C2E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085C30 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085C32 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085C34 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06085C36 mov r15,r14
    c.r[8] = ld32(0x06085CDCu);  // 06085C38 mov.l 0x06085CDC,r8
    c.r[9] = ld32(0x06085CE0u);  // 06085C3A mov.l 0x06085CE0,r9
    c.r[5] = 0x1u;  // 06085C3C mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06085C42u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085C42u) return; }  // 06085C3E jsr @r9 ; mov #2,r4
    c.r[10] = c.r[0] & 0xFFFFu;  // 06085C42 extu.w r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06085C44 tst r10,r10
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_06085C5E; } }  // 06085C46 bt/s 0x06085C5E ; mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06085C4Eu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085C4Eu) return; }  // 06085C4A jsr @r9 ; mov #3,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085C4E tst r0,r0
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_06085C5C; } }  // 06085C50 bt/s 0x06085C5C ; mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06085C58u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085C58u) return; }  // 06085C54 jsr @r9 ; mov #4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085C58 tst r0,r0
    if (!c.t) { goto L_06085C5E; }  // 06085C5A bf 0x06085C5E
L_06085C5C:
    c.r[10] = 0x0u;  // 06085C5C mov #0,r10
L_06085C5E:
    c.r[3] = ld32(0x06085CE4u);  // 06085C5E mov.l 0x06085CE4,r3
    c.r[1] = 0x0u;  // 06085C60 mov #0,r1
    st16(c.r[3], c.r[1]);  // 06085C62 mov.w r1,@r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085C64 mov.w @r8,r4
    c.r[1] = ld32(0x06085CE8u);  // 06085C66 mov.l 0x06085CE8,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 06085C68 extu.w r4,r2
    c.t = c.r[2] == c.r[1];  // 06085C6A cmp/eq r1,r2
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06085CB2; } }  // 06085C6C bt/s 0x06085CB2 ; mov #0,r9
    c.r[12] = ld32(0x06085CE0u);  // 06085C70 mov.l 0x06085CE0,r12
    c.r[11] = c.r[3];  // 06085C72 mov r3,r11
L_06085C74:
    c.r[4] = c.r[4] & 0xFFFFu;  // 06085C74 extu.w r4,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06085C7Au; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085C7Au) return; }  // 06085C76 jsr @r12 ; mov #1,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085C7A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06085CA2; } }  // 06085C7C bt/s 0x06085CA2 ; mov r9,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085C80 mov.w @r8,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06085C82 extu.w r1,r0
    c.t = c.r[0] == 0x2u;  // 06085C84 cmp/eq #2,r0
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_06085C8E; } }  // 06085C86 bf/s 0x06085C8E ; tst r10,r10
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06085CA2; } }  // 06085C8A bt/s 0x06085CA2 ; mov r9,r1
L_06085C8E:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06085C8E mov.w @r11,r2
    c.r[1] = c.r[2];  // 06085C90 mov r2,r1
    c.r[1] += 1;  // 06085C92 add #1,r1
    st16(c.r[11], c.r[1]);  // 06085C94 mov.w r1,@r11
    c.r[0] = c.r[2] & 0xFFFFu;  // 06085C96 extu.w r2,r0
    c.r[0] += c.r[0];  // 06085C98 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085C9A mov.w @r8,r1
    c.r[2] = ld32(0x06085CECu);  // 06085C9C mov.l 0x06085CEC,r2
    st16(c.r[0] + c.r[2], c.r[1]);  // 06085C9E mov.w r1,@(r0,r2)
    c.r[1] = c.r[9];  // 06085CA0 mov r9,r1
L_06085CA2:
    c.r[1] += 1;  // 06085CA2 add #1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06085CA4 extu.w r1,r9
    c.r[8] += 2;  // 06085CA6 add #2,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06085CA8 mov.w @r8,r4
    c.r[1] = ld32(0x06085CE8u);  // 06085CAA mov.l 0x06085CE8,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 06085CAC extu.w r4,r2
    c.t = c.r[2] == c.r[1];  // 06085CAE cmp/eq r1,r2
    if (!c.t) { SH2_POLL(c); goto L_06085C74; }  // 06085CB0 bf 0x06085C74
L_06085CB2:
    c.r[6] = ld32(0x06085CF0u);  // 06085CB2 mov.l 0x06085CF0,r6
    c.r[1] = ld32(0x06085CE4u);  // 06085CB4 mov.l 0x06085CE4,r1
    c.r[5] = c.r[9];  // 06085CB6 mov r9,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06085CB8 mov.w @r1,r2
    c.r[7] = ld32(0x06085CF4u);  // 06085CBA mov.l 0x06085CF4,r7
    c.r[1] = 0x64u;  // 06085CBC mov #100,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06085CBE mulu.w r1,r2
    c.r[15] = c.r[14];  // 06085CC0 mov r14,r15
    { const uint32_t x = c.r[7]; c.pr = 0x06085CC6u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085CC6u) return; }  // 06085CC2 jsr @r7 ; sts macl,r4
    st32(c.r[6], c.r[0]);  // 06085CC6 mov.l r0,@r6
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085CC8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085CCA mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06085CCC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06085CCE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06085CD0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06085CD2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085CDAu);  // 06085CD4 mov.w 0x06085CDA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085CD6 rts ; mov.l @r15+,r8
}

void f_06085CF8(SH2Context& c) {
    ran[1863] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085CF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06085CFA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085CFC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085CFE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085D00 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085D02 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085D04 sts.l pr,@-r15
    c.r[3] = ld32(0x06085D98u);  // 06085D06 mov.l 0x06085D98,r3
    c.r[12] = ld32(0x06085D9Cu);  // 06085D08 mov.l 0x06085D9C,r12
    c.r[11] = ld32(0x06085DA0u);  // 06085D0A mov.l 0x06085DA0,r11
    c.r[1] = ld32(0x06085DA4u);  // 06085D0C mov.l 0x06085DA4,r1
    c.r[2] = ld32(c.r[1]);  // 06085D0E mov.l @r1,r2
    c.r[10] = ld32(0x06085DA8u);  // 06085D10 mov.l 0x06085DA8,r10
    c.r[2] += 1;  // 06085D12 add #1,r2
    st32(c.r[1], c.r[2]);  // 06085D14 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085D16 mov.b @r2,r1
    c.r[9] = ld32(0x06085DACu);  // 06085D18 mov.l 0x06085DAC,r9
    c.r[0] = c.r[1] & 0xFFu;  // 06085D1A extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085D1C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06085D2C; } }  // 06085D1E bt/s 0x06085D2C ; mov r15,r14
    c.t = c.r[0] == 0x1u;  // 06085D22 cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_06085D62; } }  // 06085D24 bt/s 0x06085D62 ; mov r9,r7
    goto L_06085D7C;  // 06085D28 bra 0x06085D7C ; nop
L_06085D2C:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06085D2C mov.l r3,@-r15
    c.r[8] = ld32(0x06085DB0u);  // 06085D2E mov.l 0x06085DB0,r8
    c.r[7] = c.r[9];  // 06085D30 mov r9,r7
    c.r[6] = 0x0u;  // 06085D32 mov #0,r6
    c.r[5] = 0x0u;  // 06085D34 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085D3Au; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D3Au) return; }  // 06085D36 jsr @r8 ; mov #18,r4
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085D3A mov.l r11,@-r15
    c.r[7] = c.r[9];  // 06085D3C mov r9,r7
    c.r[6] = 0x3u;  // 06085D3E mov #3,r6
    c.r[5] = 0x0u;  // 06085D40 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085D46u; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D46u) return; }  // 06085D42 jsr @r8 ; mov #18,r4
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085D46 mov.l r10,@-r15
    c.r[7] = c.r[9];  // 06085D48 mov r9,r7
    c.r[6] = 0x4u;  // 06085D4A mov #4,r6
    c.r[5] = 0x0u;  // 06085D4C mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085D52u; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D52u) return; }  // 06085D4E jsr @r8 ; mov #18,r4
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085D52 mov.l r12,@-r15
    c.r[7] = c.r[9];  // 06085D54 mov r9,r7
    c.r[6] = 0x1u;  // 06085D56 mov #1,r6
    c.r[5] = 0x0u;  // 06085D58 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085D5Eu; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D5Eu) return; }  // 06085D5A jsr @r8 ; mov #18,r4
    c.r[15] += 16; goto L_06085D7C;  // 06085D5E bra 0x06085D7C ; add #16,r15
L_06085D62:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085D62 mov.l r10,@-r15
    c.r[8] = ld32(0x06085DB0u);  // 06085D64 mov.l 0x06085DB0,r8
    c.r[6] = 0x5u;  // 06085D66 mov #5,r6
    c.r[5] = 0x0u;  // 06085D68 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085D6Eu; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D6Eu) return; }  // 06085D6A jsr @r8 ; mov #18,r4
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085D6E mov.l r12,@-r15
    c.r[7] = c.r[9];  // 06085D70 mov r9,r7
    c.r[6] = 0x2u;  // 06085D72 mov #2,r6
    c.r[5] = 0x0u;  // 06085D74 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06085D7Au; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D7Au) return; }  // 06085D76 jsr @r8 ; mov #18,r4
    c.r[15] += 8;  // 06085D7A add #8,r15
L_06085D7C:
    c.r[1] = ld32(0x06085DB4u);  // 06085D7C mov.l 0x06085DB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06085D82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085D82u) return; }  // 06085D7E jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06085D82 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085D84 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085D86 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06085D88 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06085D8A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06085D8C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06085D8E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085D96u);  // 06085D90 mov.w 0x06085D96,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085D92 rts ; mov.l @r15+,r8
}

void f_06085DB8(SH2Context& c) {
    ran[1864] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085DB8 mov.l r14,@-r15
    c.r[1] = ld32(0x06085DE0u);  // 06085DBA mov.l 0x06085DE0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085DBC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06085DBE extu.b r1,r0
    c.r[1] = ld32(0x06085DE4u);  // 06085DC0 mov.l 0x06085DE4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06085DC2 mov.b @(r0,r1),r0
    c.r[0] &= 0x1u;  // 06085DC4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06085DC6 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06085DD2; } }  // 06085DC8 bt/s 0x06085DD2 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085DDAu);  // 06085DCC mov.w 0x06085DDA,r0
    c.r[15] = c.r[14]; goto L_06085DD6;  // 06085DCE bra 0x06085DD6 ; mov r14,r15
L_06085DD2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085DDCu);  // 06085DD2 mov.w 0x06085DDC,r0
    c.r[15] = c.r[14];  // 06085DD4 mov r14,r15
L_06085DD6:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085DD6 rts ; mov.l @r15+,r14
}

void f_06085DE8(SH2Context& c) {
    ran[1865] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085DE8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06085DEA mov r15,r14
    c.r[1] = ld32(0x06085E08u);  // 06085DEC mov.l 0x06085E08,r1
    c.r[2] = ld32(c.r[1]);  // 06085DEE mov.l @r1,r2
    c.r[2] += 1;  // 06085DF0 add #1,r2
    st32(c.r[1], c.r[2]);  // 06085DF2 mov.l r2,@r1
    c.r[1] = ld32(0x06085E0Cu);  // 06085DF4 mov.l 0x06085E0C,r1
    c.r[2] = 0x0u;  // 06085DF6 mov #0,r2
    st8(c.r[1], c.r[2]);  // 06085DF8 mov.b r2,@r1
    c.r[1] = ld32(0x06085E10u);  // 06085DFA mov.l 0x06085E10,r1
    st8(c.r[1], c.r[2]);  // 06085DFC mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085E04u);  // 06085DFE mov.w 0x06085E04,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085E00 rts ; mov.l @r15+,r14
}

void f_06085E14(SH2Context& c) {
    ran[1866] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085E14 mov.l r14,@-r15
    c.r[1] = ld32(0x06085E5Cu);  // 06085E16 mov.l 0x06085E5C,r1
    c.r[2] = ld32(c.r[1]);  // 06085E18 mov.l @r1,r2
    c.r[2] += 1;  // 06085E1A add #1,r2
    st32(c.r[1], c.r[2]);  // 06085E1C mov.l r2,@r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085E1E mov.b @r2,r3
    c.r[14] = c.r[15];  // 06085E20 mov r15,r14
    c.t = (int32_t)c.r[3] > 0;  // 06085E22 cmp/pl r3
    { const bool k = !c.t; c.r[7] = c.r[3]; if (k) { goto L_06085E3E; } }  // 06085E24 bf/s 0x06085E3E ; mov r3,r7
    c.r[1] = ld32(0x06085E60u);  // 06085E28 mov.l 0x06085E60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085E2A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06085E2C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06085E2E tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06085E54; } }  // 06085E30 bf/s 0x06085E54 ; mov r14,r15
    c.r[2] = ld32(0x06085E64u);  // 06085E34 mov.l 0x06085E64,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085E36 mov.b @r2,r1
    c.r[3] += c.r[1];  // 06085E38 add r1,r3
    st8(c.r[2], c.r[3]); goto L_06085E54;  // 06085E3A bra 0x06085E54 ; mov.b r3,@r2
L_06085E3E:
    c.r[3] = ld32(0x06085E64u);  // 06085E3E mov.l 0x06085E64,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06085E40 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06085E42 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06085E44 tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06085E54; } }  // 06085E46 bt/s 0x06085E54 ; mov r14,r15
    c.r[7] += c.r[2];  // 06085E4A add r2,r7
    st8(c.r[3], c.r[7]);  // 06085E4C mov.b r7,@r3
    c.r[2] = ld32(0x06085E60u);  // 06085E4E mov.l 0x06085E60,r2
    c.r[1] = 0x0u;  // 06085E50 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06085E52 mov.b r1,@r2
L_06085E54:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085E5Au);  // 06085E54 mov.w 0x06085E5A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085E56 rts ; mov.l @r15+,r14
}

void f_06085E68(SH2Context& c) {
    ran[1867] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085E68 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06085E6A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085E6C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085E6E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085E70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085E72 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06085E74 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 06085E76 extu.b r4,r11
    c.r[4] = ld32(0x06085F1Cu);  // 06085E78 mov.l 0x06085F1C,r4
    c.r[0] = ld32(0x06085F20u);  // 06085E7A mov.l 0x06085F20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06085E80u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085E80u) return; }  // 06085E7C jsr @r0 ; extu.w r5,r5
    c.r[1] = ld32(0x06085F24u);  // 06085E80 mov.l 0x06085F24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06085E82 mov.b @r1,r1
    c.r[7] = 0x0u;  // 06085E84 mov #0,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06085E86 extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06085E88 cmp/ge r1,r7
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06085EB2; } }  // 06085E8A bt/s 0x06085EB2 ; mov #0,r6
    c.r[5] = 0x1u;  // 06085E8E mov #1,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x06085F12u);  // 06085E90 mov.w 0x06085F12,r7
    c.r[3] = c.r[1];  // 06085E92 mov r1,r3
L_06085E94:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06085E94 mov.b @r0,r2
    c.r[1] = c.r[2];  // 06085E96 mov r2,r1
    c.r[1] += 10;  // 06085E98 add #10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06085E9A extu.b r1,r1
    c.t = c.r[1] > c.r[5];  // 06085E9C cmp/hi r5,r1
    { const bool k = c.t; c.r[1] = c.r[2] & 0xFFu; if (k) { goto L_06085EA6; } }  // 06085E9E bt/s 0x06085EA6 ; extu.b r2,r1
    c.r[6] += 1; goto L_06085EAC;  // 06085EA2 bra 0x06085EAC ; add #1,r6
L_06085EA6:
    c.t = c.r[1] > c.r[7];  // 06085EA6 cmp/hi r7,r1
    if (!c.t) { goto L_06085EAC; }  // 06085EA8 bf 0x06085EAC
    c.r[0] += 1;  // 06085EAA add #1,r0
L_06085EAC:
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[3];  // 06085EAC cmp/ge r3,r6
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_06085E94; } }  // 06085EAE bf/s 0x06085E94 ; add #1,r0
L_06085EB2:
    c.r[6] = 0x0u;  // 06085EB2 mov #0,r6
    c.r[7] = 0x0u;  // 06085EB4 mov #0,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x06085F14u);  // 06085EB6 mov.w 0x06085F14,r9
    c.r[5] = 0xFFFFFFFFu;  // 06085EB8 mov #-1,r5
    c.r[10] = ld32(0x06085F28u);  // 06085EBA mov.l 0x06085F28,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06085F16u);  // 06085EBC mov.w 0x06085F16,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x06085F12u);  // 06085EBE mov.w 0x06085F12,r4
    c.r[2] = ld32(0x06085F2Cu);  // 06085EC0 mov.l 0x06085F2C,r2
L_06085EC2:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06085EC2 mov.b @r0,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06085EC4 extu.b r3,r1
    c.t = c.r[1] > c.r[9];  // 06085EC6 cmp/hi r9,r1
    if (!c.t) { goto L_06085ED2; }  // 06085EC8 bf 0x06085ED2
    st8(c.r[2], c.r[5]);  // 06085ECA mov.b r5,@r2
    c.r[1] = 0x1u;  // 06085ECC mov #1,r1
    st8(c.r[10], c.r[1]); goto L_06085F02;  // 06085ECE bra 0x06085F02 ; mov.b r1,@r10
L_06085ED2:
    c.t = c.r[1] > c.r[8];  // 06085ED2 cmp/hi r8,r1
    if (!c.t) { goto L_06085EE6; }  // 06085ED4 bf 0x06085EE6
    c.r[6] += 1;  // 06085ED6 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[11];  // 06085ED8 cmp/ge r11,r6
    if (!c.t) { goto L_06085EE2; }  // 06085EDA bf 0x06085EE2
    st8(c.r[2], c.r[5]);  // 06085EDC mov.b r5,@r2
    c.r[15] = c.r[14]; goto L_06085F04;  // 06085EDE bra 0x06085F04 ; mov r14,r15
L_06085EE2:
    c.r[1] = 0xFFFFFFF6u; goto L_06085EF4;  // 06085EE2 bra 0x06085EF4 ; mov #-10,r1
L_06085EE6:
    c.t = c.r[1] > c.r[4];  // 06085EE6 cmp/hi r4,r1
    if (!c.t) { goto L_06085EF2; }  // 06085EE8 bf 0x06085EF2
    st8(c.r[2], c.r[3]);  // 06085EEA mov.b r3,@r2
    c.r[2] += 1;  // 06085EEC add #1,r2
    c.r[7] += 1;  // 06085EEE add #1,r7
    c.r[0] += 1;  // 06085EF0 add #1,r0
L_06085EF2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06085EF2 mov.b @r0,r1
L_06085EF4:
    st8(c.r[2], c.r[1]);  // 06085EF4 mov.b r1,@r2
    c.r[2] += 1;  // 06085EF6 add #1,r2
    c.r[7] += 1;  // 06085EF8 add #1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06085F18u);  // 06085EFA mov.w 0x06085F18,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06085EFC cmp/gt r1,r7
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_06085EC2; } }  // 06085EFE bf/s 0x06085EC2 ; add #1,r0
L_06085F02:
    c.r[15] = c.r[14];  // 06085F02 mov r14,r15
L_06085F04:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085F04 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085F06 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06085F08 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06085F0A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06085F0C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085F0E rts ; mov.l @r15+,r8
}

void f_06085F30(SH2Context& c) {
    ran[1868] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085F30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06085F32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06085F34 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06085F36 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06085F38 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06085F3A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085F3C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06085F3E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06085FF4u);  // 06085F40 mov.w 0x06085FF4,r3
    c.r[15] += c.r[3];  // 06085F42 add r3,r15
    c.r[14] = c.r[15];  // 06085F44 mov r15,r14
    c.r[1] = ld32(0x06086000u);  // 06085F46 mov.l 0x06086000,r1
    c.r[9] = ld32(0x06086004u);  // 06085F48 mov.l 0x06086004,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06085FF6u);  // 06085F4A mov.w 0x06085FF6,r13
    c.r[11] = c.r[14];  // 06085F4C mov r14,r11
    c.r[11] += c.r[13];  // 06085F4E add r13,r11
    c.r[0] = c.r[14];  // 06085F50 mov r14,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06085FF8u);  // 06085F52 mov.w 0x06085FF8,r3
    c.r[12] = c.r[14];  // 06085F54 mov r14,r12
    c.r[12] += c.r[3];  // 06085F56 add r3,r12
    c.r[10] = ld32(0x06086008u);  // 06085F58 mov.l 0x06086008,r10
    c.r[7] = ld32(0x0608600Cu);  // 06085F5A mov.l 0x0608600C,r7
    c.r[2] = ld32(c.r[1]);  // 06085F5C mov.l @r1,r2
    c.r[5] = 0xFFFFFFFFu;  // 06085F5E mov #-1,r5
    c.r[2] += 1;  // 06085F60 add #1,r2
    st32(c.r[1], c.r[2]);  // 06085F62 mov.l r2,@r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06085F64 mov.b @r2,r6
    c.r[4] = 0x11u;  // 06085F66 mov #17,r4
    c.r[2] = c.r[9];  // 06085F68 mov r9,r2
    c.r[2] += 88;  // 06085F6A add #88,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06085F6C mov.w @r2,r1
    st16(c.r[0] + c.r[13], c.r[1]);  // 06085F6E mov.w r1,@(r0,r13)
    c.r[1] = 0x30u;  // 06085F70 mov #48,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06085F72 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06085F74 mov.w @r2,r1
    c.r[0] = ld32(0x06086010u);  // 06085F76 mov.l 0x06086010,r0
    st16(c.r[10], c.r[1]);  // 06085F78 mov.w r1,@r10
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06085F7A mov.l r0,@-r15
    c.r[0] = ld32(0x06086014u);  // 06085F7C mov.l 0x06086014,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06085F82u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085F82u) return; }  // 06085F7E jsr @r0 ; extu.b r6,r6
    c.r[8] = 0x0u;  // 06085F82 mov #0,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085F84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06085F86 mov.l r14,@-r15
    c.r[0] = c.r[14];  // 06085F88 mov r14,r0
    c.r[1] = 0xAu;  // 06085F8A mov #10,r1
    c.r[7] = c.r[12];  // 06085F8C mov r12,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06085F8E mov.w @(r0,r13),r2
    c.r[6] = c.r[11];  // 06085F90 mov r11,r6
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06085F92 mulu.w r1,r2
    c.r[5] = ld32(0x06086010u);  // 06085F94 mov.l 0x06086010,r5
    c.r[2] = ld32(c.r[9] + 8);  // 06085F96 mov.l @(8,r9),r2
    c.r[1] = c.macl;  // 06085F98 sts macl,r1
    c.r[2] += c.r[1];  // 06085F9A add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06085F9C mov.l r2,@-r15
    c.r[1] = ld32(c.r[9] + 4);  // 06085F9E mov.l @(4,r9),r1
    c.r[4] = ld32(0x0608600Cu);  // 06085FA0 mov.l 0x0608600C,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085FA2 mov.l r1,@-r15
    c.r[1] = ld32(c.r[9]);  // 06085FA4 mov.l @r9,r1
    c.r[0] = ld32(0x06086018u);  // 06085FA6 mov.l 0x06086018,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085FA8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06085FAA mov.l r8,@-r15
    c.r[1] = 0x1u;  // 06085FAC mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06085FAE mov.l r1,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x06085FB4u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06085FB4u) return; }  // 06085FB0 jsr @r0 ; mov.l r8,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06085FB4 mov.w @r10,r1
    c.r[2] = ld32(c.r[9] + 12);  // 06085FB6 mov.l @(12,r9),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06085FB8 extu.w r1,r1
    c.r[3] = c.r[1];  // 06085FBA mov r1,r3
    c.r[3] += c.r[3];  // 06085FBC add r3,r3
    c.r[3] += c.r[1];  // 06085FBE add r1,r3
    c.r[3] <<= 2;  // 06085FC0 shll2 r3
    c.r[0] = c.r[3];  // 06085FC2 mov r3,r0
    st32(c.r[0] + c.r[2], c.r[8]);  // 06085FC4 mov.l r8,@(r0,r2)
    c.r[2] = ld32(0x0608601Cu);  // 06085FC6 mov.l 0x0608601C,r2
    c.r[1] = ld32(c.r[9] + 12);  // 06085FC8 mov.l @(12,r9),r1
    c.r[0] = c.r[2];  // 06085FCA mov r2,r0
    c.r[3] += c.r[1];  // 06085FCC add r1,r3
    c.r[1] = ld32(0x06086020u);  // 06085FCE mov.l 0x06086020,r1
    st32(c.r[3] + 4, c.r[1]);  // 06085FD0 mov.l r1,@(4,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06085FFAu);  // 06085FD2 mov.w 0x06085FFA,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06085FD4 mov.w @(r0,r3),r1
    c.r[1] += 1;  // 06085FD6 add #1,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 06085FD8 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06085FFCu);  // 06085FDA mov.w 0x06085FFC,r3
    c.r[14] += c.r[3];  // 06085FDC add r3,r14
    c.r[15] = c.r[14];  // 06085FDE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06085FE0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06085FE2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06085FE4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06085FE6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06085FE8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06085FEA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06085FEC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06085FFEu);  // 06085FEE mov.w 0x06085FFE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06085FF0 rts ; mov.l @r15+,r8
}

void f_06086024(SH2Context& c) {
    ran[1869] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086024 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086026 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086028 sts.l pr,@-r15
    c.r[1] = ld32(0x060860ECu);  // 0608602A mov.l 0x060860EC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608602C mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0608602E extu.w r1,r0
    c.r[0] += c.r[0];  // 06086030 add r0,r0
    c.r[1] = ld32(0x060860F0u);  // 06086032 mov.l 0x060860F0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086034 mov.w @(r0,r1),r1
    c.r[2] = 0x1u;  // 06086036 mov #1,r2
    c.r[3] = c.r[1] & 0xFFFFu;  // 06086038 extu.w r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060860DAu);  // 0608603A mov.w 0x060860DA,r1
    c.r[1] += c.r[3];  // 0608603C add r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0608603E extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06086040 cmp/hi r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0608608E; } }  // 06086042 bt/s 0x0608608E ; mov r15,r14
    c.r[1] = ld32(0x060860F4u);  // 06086046 mov.l 0x060860F4,r1
    c.r[2] = ld32(c.r[1]);  // 06086048 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608604A mov r2,r1
    c.r[1] += 8;  // 0608604C add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608604E mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06086050 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06086052 tst r0,r0
    if (c.t) { goto L_060860CE; }  // 06086054 bt 0x060860CE
    c.r[1] = (uint32_t)(int16_t)ld16(0x060860DCu);  // 06086056 mov.w 0x060860DC,r1
    c.t = c.r[3] == c.r[1];  // 06086058 cmp/eq r1,r3
    { const bool k = !c.t; c.r[7] = 0x4u; if (k) { goto L_0608606C; } }  // 0608605A bf/s 0x0608606C ; mov #4,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060860DEu);  // 0608605E mov.w 0x060860DE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06086060 mov.b @(r0,r2),r1
    c.r[3] = c.r[1];  // 06086062 mov r1,r3
    c.r[3] >>= 2;  // 06086064 shlr2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060860E0u);  // 06086066 mov.w 0x060860E0,r0
    c.r[3] >>= 2; goto L_06086078;  // 06086068 bra 0x06086078 ; shlr2 r3
L_0608606C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060860E2u);  // 0608606C mov.w 0x060860E2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0608606E mov.b @(r0,r2),r1
    c.r[3] = c.r[1];  // 06086070 mov r1,r3
    c.r[3] >>= 2;  // 06086072 shlr2 r3
    c.r[3] >>= 2;  // 06086074 shlr2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060860E4u);  // 06086076 mov.w 0x060860E4,r0
L_06086078:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06086078 mov.b @(r0,r2),r1
    c.r[3] &= c.r[7];  // 0608607A and r7,r3
    c.r[0] = c.r[1];  // 0608607C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0608607E shlr r0
    c.r[0] &= 0x3u;  // 06086080 and #3,r0
    c.r[3] |= c.r[0];  // 06086082 or r0,r3
    c.r[2] = c.r[3];  // 06086084 mov r3,r2
    c.r[2] += c.r[2];  // 06086086 add r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060860E6u);  // 06086088 mov.w 0x060860E6,r1
    c.r[2] += c.r[1];  // 0608608A add r1,r2
    c.r[3] = c.r[2] & 0xFFFFu;  // 0608608C extu.w r2,r3
L_0608608E:
    c.r[4] = ld32(0x060860F8u);  // 0608608E mov.l 0x060860F8,r4
    c.r[0] = ld32(0x060860FCu);  // 06086090 mov.l 0x060860FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06086096u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086096u) return; }  // 06086092 jsr @r0 ; mov r3,r5
    c.r[8] = c.r[0];  // 06086096 mov r0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06086098 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608609A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608609C tst r1,r1
    if (c.t) { goto L_060860CE; }  // 0608609E bt 0x060860CE
    c.r[0] = ld32(0x06086100u);  // 060860A0 mov.l 0x06086100,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060860A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060860A6u) return; }  // 060860A2 jsr @r0 ; nop
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060860A6 mov.b @r8+,r1
    c.r[3] = ld32(0x06086104u);  // 060860A8 mov.l 0x06086104,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060860AA extu.b r1,r1
    c.macl = c.r[0] * c.r[1];  // 060860AC mul.l r1,r0
    c.r[2] = c.r[3];  // 060860AE mov r3,r2
    c.r[2] += 22;  // 060860B0 add #22,r2
    c.r[1] = c.macl;  // 060860B2 sts macl,r1
    c.r[1] >>= 16;  // 060860B4 shlr16 r1
    c.r[1] = c.r[1] & 0xFFu;  // 060860B6 extu.b r1,r1
    c.r[1] += c.r[1];  // 060860B8 add r1,r1
    c.r[8] += c.r[1];  // 060860BA add r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060860BC mov.b @r8+,r1
    c.r[3] += 24;  // 060860BE add #24,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060860C0 extu.b r1,r1
    st16(c.r[2], c.r[1]);  // 060860C2 mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060860C4 mov.b @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060860E8u);  // 060860C6 mov.w 0x060860E8,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060860C8 extu.b r1,r1
    st16(c.r[3], c.r[1]); goto L_060860D0;  // 060860CA bra 0x060860D0 ; mov.w r1,@r3
L_060860CE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060860EAu);  // 060860CE mov.w 0x060860EA,r0
L_060860D0:
    c.r[15] = c.r[14];  // 060860D0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060860D2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060860D4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060860D6 rts ; mov.l @r15+,r8
}

void f_06086108(SH2Context& c) {
    ran[1870] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086108 mov.l r14,@-r15
    c.r[3] = ld32(0x06086138u);  // 0608610A mov.l 0x06086138,r3
    c.r[2] = ld32(c.r[3]);  // 0608610C mov.l @r3,r2
    c.r[2] += 1;  // 0608610E add #1,r2
    st32(c.r[3], c.r[2]);  // 06086110 mov.l r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06086112 mov.b @r2+,r1
    c.r[14] = c.r[15];  // 06086114 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06086116 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06086118 tst r1,r1
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06086126; } }  // 0608611A bf/s 0x06086126 ; mov.l r2,@r3
    c.r[2] = ld32(0x0608613Cu);  // 0608611E mov.l 0x0608613C,r2
    c.r[1] = ld32(0x06086140u);  // 06086120 mov.l 0x06086140,r1
    st32(c.r[2], c.r[1]); goto L_0608612C;  // 06086122 bra 0x0608612C ; mov.l r1,@r2
L_06086126:
    c.r[2] = ld32(0x0608613Cu);  // 06086126 mov.l 0x0608613C,r2
    c.r[1] = ld32(0x06086144u);  // 06086128 mov.l 0x06086144,r1
    st32(c.r[2], c.r[1]);  // 0608612A mov.l r1,@r2
L_0608612C:
    c.r[15] = c.r[14];  // 0608612C mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086134u);  // 0608612E mov.w 0x06086134,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086130 rts ; mov.l @r15+,r14
}

void f_06086148(SH2Context& c) {
    ran[1871] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086148 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608614A mov r15,r14
    c.r[2] = 0x0u;  // 0608614C mov #0,r2
    c.r[6] = 0x3Fu;  // 0608614E mov #63,r6
    c.r[7] = ld32(0x06086170u);  // 06086150 mov.l 0x06086170,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608616Au);  // 06086152 mov.w 0x0608616A,r0
    c.r[3] = 0x0u;  // 06086154 mov #0,r3
L_06086156:
    c.r[1] = ld32(c.r[7]);  // 06086156 mov.l @r7,r1
    c.r[1] += c.r[2];  // 06086158 add r2,r1
    c.r[2] += 1;  // 0608615A add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0608615C cmp/gt r6,r2
    { const bool k = !c.t; st8(c.r[0] + c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_06086156; } }  // 0608615E bf/s 0x06086156 ; mov.b r3,@(r0,r1)
    c.r[15] = c.r[14];  // 06086162 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608616Cu);  // 06086164 mov.w 0x0608616C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086166 rts ; mov.l @r15+,r14
}

void f_06086174(SH2Context& c) {
    ran[1872] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086174 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06086176 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06086178 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608617A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608617C sts.l pr,@-r15
    c.r[1] = ld32(0x060861ECu);  // 0608617E mov.l 0x060861EC,r1
    c.r[2] = ld32(c.r[1]);  // 06086180 mov.l @r1,r2
    c.r[2] += 1;  // 06086182 add #1,r2
    st32(c.r[1], c.r[2]);  // 06086184 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06086186 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06086188 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608618A tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060861B6; } }  // 0608618C bf/s 0x060861B6 ; mov r15,r14
    c.r[8] = 0x0u;  // 06086190 mov #0,r8
    c.r[10] = ld32(0x060861F0u);  // 06086192 mov.l 0x060861F0,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x060861E2u);  // 06086194 mov.w 0x060861E2,r9
    c.r[5] = 0x0u;  // 06086196 mov #0,r5
L_06086198:
    { const uint32_t x = c.r[10]; c.pr = 0x0608619Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608619Cu) return; }  // 06086198 jsr @r10 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608619C tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060861B0; } }  // 0608619E bf/s 0x060861B0 ; mov r8,r1
    c.r[1] += 1;  // 060861A2 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060861A4 extu.w r1,r8
    c.t = c.r[8] > c.r[9];  // 060861A6 cmp/hi r9,r8
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { SH2_POLL(c); goto L_06086198; } }  // 060861A8 bf/s 0x06086198 ; mov #0,r5
    goto L_060861D2;  // 060861AC bra 0x060861D2 ; nop
L_060861B0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060861E4u);  // 060861B0 mov.w 0x060861E4,r0
    c.r[15] = c.r[14]; goto L_060861D6;  // 060861B2 bra 0x060861D6 ; mov r14,r15
L_060861B6:
    c.r[8] = 0x0u;  // 060861B6 mov #0,r8
    c.r[10] = ld32(0x060861F0u);  // 060861B8 mov.l 0x060861F0,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x060861E6u);  // 060861BA mov.w 0x060861E6,r9
    c.r[5] = 0x1u;  // 060861BC mov #1,r5
L_060861BE:
    { const uint32_t x = c.r[10]; c.pr = 0x060861C2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060861C2u) return; }  // 060861BE jsr @r10 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060861C2 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_060861B0; } }  // 060861C4 bf/s 0x060861B0 ; mov r8,r1
    c.r[1] += 1;  // 060861C8 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060861CA extu.w r1,r8
    c.t = c.r[8] > c.r[9];  // 060861CC cmp/hi r9,r8
    { const bool k = !c.t; c.r[5] = 0x1u; if (k) { SH2_POLL(c); goto L_060861BE; } }  // 060861CE bf/s 0x060861BE ; mov #1,r5
L_060861D2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060861E8u);  // 060861D2 mov.w 0x060861E8,r0
    c.r[15] = c.r[14];  // 060861D4 mov r14,r15
L_060861D6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060861D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060861D8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060861DA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060861DC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060861DE rts ; mov.l @r15+,r8
}

void f_060861F4(SH2Context& c) {
    ran[1873] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060861F4 mov.l r14,@-r15
    c.r[1] = ld32(0x06086228u);  // 060861F6 mov.l 0x06086228,r1
    c.r[1] = ld32(c.r[1]);  // 060861F8 mov.l @r1,r1
    c.r[1] += 1;  // 060861FA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060861FC mov.b @r1,r1
    c.r[7] = ld32(0x0608622Cu);  // 060861FE mov.l 0x0608622C,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06086200 mov.w @r7,r2
    c.r[3] = c.r[1];  // 06086202 mov r1,r3
    c.r[1] = c.r[2] & 0xFFFFu;  // 06086204 extu.w r2,r1
    c.r[1] += c.r[3];  // 06086206 add r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06086208 cmp/pz r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06086218; } }  // 0608620A bt/s 0x06086218 ; mov r15,r14
    c.r[1] = ld32(0x06086230u);  // 0608620E mov.l 0x06086230,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06086210 mov.w @r1,r1
    c.r[1] -= 1;  // 06086212 add #-1,r1
    st16(c.r[7], c.r[1]); goto L_0608621C;  // 06086214 bra 0x0608621C ; mov.w r1,@r7
L_06086218:
    c.r[3] += c.r[2];  // 06086218 add r2,r3
    st16(c.r[7], c.r[3]);  // 0608621A mov.w r3,@r7
L_0608621C:
    c.r[15] = c.r[14];  // 0608621C mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086224u);  // 0608621E mov.w 0x06086224,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086220 rts ; mov.l @r15+,r14
}

void f_06086234(SH2Context& c) {
    ran[1874] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086234 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06086236 mov r15,r14
    c.r[2] = ld32(0x06086248u);  // 06086238 mov.l 0x06086248,r2
    c.r[1] = 0x0u;  // 0608623A mov #0,r1
    st16(c.r[2], c.r[1]);  // 0608623C mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086244u);  // 0608623E mov.w 0x06086244,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086240 rts ; mov.l @r15+,r14
}

void f_0608624C(SH2Context& c) {
    ran[1875] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608624C mov.l r14,@-r15
    c.r[1] = ld32(0x06086274u);  // 0608624E mov.l 0x06086274,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06086250 mov.w @r1,r2
    c.r[3] = ld32(0x06086278u);  // 06086252 mov.l 0x06086278,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06086254 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06086256 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06086258 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0608625A cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06086266; } }  // 0608625C bt/s 0x06086266 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608626Eu);  // 06086260 mov.w 0x0608626E,r0
    c.r[15] = c.r[14]; goto L_0608626A;  // 06086262 bra 0x0608626A ; mov r14,r15
L_06086266:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086270u);  // 06086266 mov.w 0x06086270,r0
    c.r[15] = c.r[14];  // 06086268 mov r14,r15
L_0608626A:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608626A rts ; mov.l @r15+,r14
}

void f_0608627C(SH2Context& c) {
    ran[1876] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608627C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608627E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06086280 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06086282 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086284 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086286 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06086288 mov r15,r14
    c.r[3] = ld32(0x0608633Cu);  // 0608628A mov.l 0x0608633C,r3
    c.r[2] = c.r[3];  // 0608628C mov r3,r2
    c.r[2] += 112;  // 0608628E add #112,r2
    c.r[1] = 0x47u;  // 06086290 mov #71,r1
    st16(c.r[2], c.r[1]);  // 06086292 mov.w r1,@r2
    c.r[3] += 114;  // 06086294 add #114,r3
    c.r[1] = 0xFFFFFFCFu;  // 06086296 mov #-49,r1
    st16(c.r[3], c.r[1]);  // 06086298 mov.w r1,@r3
    c.r[1] = ld32(0x06086340u);  // 0608629A mov.l 0x06086340,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060862A0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060862A0u) return; }  // 0608629C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086344u);  // 060862A0 mov.l 0x06086344,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060862A6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060862A6u) return; }  // 060862A2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086348u);  // 060862A6 mov.l 0x06086348,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060862ACu; c.r[10] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060862ACu) return; }  // 060862A8 jsr @r1 ; mov #2,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06086336u);  // 060862AC mov.w 0x06086336,r9
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060862AE mov.l r10,@-r15
    c.r[8] = ld32(0x0608634Cu);  // 060862B0 mov.l 0x0608634C,r8
    c.r[7] = 0x6u;  // 060862B2 mov #6,r7
    c.r[6] = c.r[10];  // 060862B4 mov r10,r6
    c.r[5] = 0x10u;  // 060862B6 mov #16,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060862BCu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060862BCu) return; }  // 060862B8 jsr @r8 ; mov r9,r4
    c.r[1] = 0xCu;  // 060862BC mov #12,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060862BE mov.l r1,@-r15
    c.r[7] = 0xCu;  // 060862C0 mov #12,r7
    c.r[6] = 0x6u;  // 060862C2 mov #6,r6
    c.r[5] = 0xDu;  // 060862C4 mov #13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060862CAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060862CAu) return; }  // 060862C6 jsr @r8 ; mov r9,r4
    c.r[1] = ld32(0x06086350u);  // 060862CA mov.l 0x06086350,r1
    c.r[15] += 8;  // 060862CC add #8,r15
    c.r[11] = 0x1u;  // 060862CE mov #1,r11
    c.r[4] = ld32(0x06086354u);  // 060862D0 mov.l 0x06086354,r4
    c.r[1] = ld32(c.r[1]);  // 060862D2 mov.l @r1,r1
    c.r[8] = ld32(0x06086358u);  // 060862D4 mov.l 0x06086358,r8
    c.r[1] += 8;  // 060862D6 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060862D8 mov.b @r1,r1
    c.r[5] = 0x17u;  // 060862DA mov #23,r5
    c.r[9] = c.r[1];  // 060862DC mov r1,r9
    c.r[9] >>= 2;  // 060862DE shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060862E0 shlr r9
    c.r[0] = c.r[4];  // 060862E2 mov r4,r0
    c.r[9] &= c.r[11];  // 060862E4 and r11,r9
    c.r[5] = 0x17u;  // 060862E6 mov #23,r5
    ;  // 060862E8 nop
    c.r[4] = c.r[0];  // 060862EA mov r0,r4
    c.r[1] = ld32(0x0608635Cu);  // 060862EC mov.l 0x0608635C,r1
    c.r[6] = 0x8u;  // 060862EE mov #8,r6
    c.r[5] = c.r[9];  // 060862F0 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060862F6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060862F6u) return; }  // 060862F2 jsr @r1 ; mov r0,r4
    c.r[3] = 0x6u;  // 060862F6 mov #6,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060862F8 mov.l r3,@-r15
    c.r[2] = 0x1u;  // 060862FA mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060862FC mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060862FE mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086300 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06086302 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086304 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086306 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086308 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608630A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0608630C mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608630E mov.l r2,@-r15
    c.r[1] = ld32(0x06086360u);  // 06086310 mov.l 0x06086360,r1
    c.r[7] = c.r[10];  // 06086312 mov r10,r7
    c.r[6] = 0xCu;  // 06086314 mov #12,r6
    c.r[5] = 0x7u;  // 06086316 mov #7,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608631Cu; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608631Cu) return; }  // 06086318 jsr @r1 ; mov #14,r4
    c.r[15] += 40;  // 0608631C add #40,r15
    c.r[1] = ld32(0x06086364u);  // 0608631E mov.l 0x06086364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086324u; c.r[4] = 0x54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086324u) return; }  // 06086320 jsr @r1 ; mov #84,r4
    c.r[15] = c.r[14];  // 06086324 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086326 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086328 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608632A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608632C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608632E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086338u);  // 06086330 mov.w 0x06086338,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086332 rts ; mov.l @r15+,r8
}

void f_06086368(SH2Context& c) {
    ran[1877] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086368 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608636A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608636C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608636E mov r15,r14
    c.r[1] = ld32(0x060863CCu);  // 06086370 mov.l 0x060863CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086376u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086376u) return; }  // 06086372 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060863D0u);  // 06086376 mov.l 0x060863D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608637Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608637Cu) return; }  // 06086378 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060863D4u);  // 0608637C mov.l 0x060863D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086382u; c.r[8] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086382u) return; }  // 0608637E jsr @r1 ; mov #4,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x060863C8u);  // 06086382 mov.w 0x060863C8,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086384 mov.l r8,@-r15
    c.r[1] = ld32(0x060863D8u);  // 06086386 mov.l 0x060863D8,r1
    c.r[7] = c.r[8];  // 06086388 mov r8,r7
    c.r[6] = 0x6u;  // 0608638A mov #6,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06086390u; c.r[5] = 0x1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086390u) return; }  // 0608638C jsr @r1 ; mov #26,r5
    c.r[7] = 0x2u;  // 06086390 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06086392 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 06086394 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086396 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086398 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608639A mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0608639C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608639E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060863A0 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060863A2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060863A4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060863A6 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060863A8 mov.l r2,@-r15
    c.r[1] = ld32(0x060863DCu);  // 060863AA mov.l 0x060863DC,r1
    c.r[6] = c.r[8];  // 060863AC mov r8,r6
    c.r[5] = 0x7u;  // 060863AE mov #7,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060863B4u; c.r[4] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060863B4u) return; }  // 060863B0 jsr @r1 ; mov #27,r4
    c.r[15] += 44;  // 060863B4 add #44,r15
    c.r[1] = ld32(0x060863E0u);  // 060863B6 mov.l 0x060863E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060863BCu; c.r[4] = 0x55u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060863BCu) return; }  // 060863B8 jsr @r1 ; mov #85,r4
    c.r[15] = c.r[14];  // 060863BC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060863BE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060863C0 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060863CAu);  // 060863C2 mov.w 0x060863CA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060863C4 rts ; mov.l @r15+,r8
}

void f_060863E4(SH2Context& c) {
    ran[1878] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060863E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060863E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060863E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060863EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060863EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060863EE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060863F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060863F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060863F4 mov r15,r14
    c.r[1] = ld32(0x06086594u);  // 060863F6 mov.l 0x06086594,r1
    c.r[1] += 97;  // 060863F8 add #97,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060863FA mov.b @r1,r1
    c.r[4] = 0x0u;  // 060863FC mov #0,r4
    c.r[13] = c.r[1] & 0xFFu;  // 060863FE extu.b r1,r13
    c.r[1] = ld32(0x06086598u);  // 06086400 mov.l 0x06086598,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086406u; c.r[13] -= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086406u) return; }  // 06086402 jsr @r1 ; add #-2,r13
    c.r[1] = ld32(0x0608659Cu);  // 06086406 mov.l 0x0608659C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608640Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608640Cu) return; }  // 06086408 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060865A0u);  // 0608640C mov.l 0x060865A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086412u; c.r[9] = c.r[13] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086412u) return; }  // 0608640E jsr @r1 ; extu.w r13,r9
    c.r[12] = ld32(0x060865A4u);  // 06086412 mov.l 0x060865A4,r12
    c.r[11] = ld32(0x060865A8u);  // 06086414 mov.l 0x060865A8,r11
    c.r[10] = ld32(0x060865ACu);  // 06086416 mov.l 0x060865AC,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06086418 mov.b @r12,r1
    c.r[5] = 0x0u;  // 0608641A mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0608641C extu.b r1,r1
    c.r[0] = c.r[1];  // 0608641E mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06086420 mov.b @(r0,r11),r6
    c.r[4] = 0x0u;  // 06086422 mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06086428u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086428u) return; }  // 06086424 jsr @r10 ; extu.b r6,r6
    c.r[0] = ld32(0x060865B0u);  // 06086428 mov.l 0x060865B0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0608642A mov.w @r0,r2
    c.r[1] = ld32(0x060865B4u);  // 0608642C mov.l 0x060865B4,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0608642E extu.w r2,r2
    c.r[2] += 21;  // 06086430 add #21,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086432 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06086434 mov #0,r5
    c.r[4] = 0x0u;  // 06086436 mov #0,r4
    c.r[6] = c.mach;  // 06086438 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0608643A shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0608643C shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0608643E shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086440 subc r2,r2
    { const uint32_t x = c.r[10]; c.pr = 0x06086446u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086446u) return; }  // 06086442 jsr @r10 ; sub r2,r6
    c.r[4] = ld32(0x060865B8u);  // 06086446 mov.l 0x060865B8,r4
    c.r[8] = ld32(0x060865BCu);  // 06086448 mov.l 0x060865BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608644Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608644Eu) return; }  // 0608644A jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 0608644E mov r0,r1
    c.r[5] = 0x24u;  // 06086450 mov #36,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086456u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086456u) return; }  // 06086452 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06086456 mov r0,r1
    c.r[5] = c.r[9];  // 06086458 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608645Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608645Eu) return; }  // 0608645A jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0608645E mov r0,r2
    c.r[1] = ld32(0x060865C0u);  // 06086460 mov.l 0x060865C0,r1
    c.r[6] = 0x0u;  // 06086462 mov #0,r6
    c.r[5] = c.r[2];  // 06086464 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608646Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608646Au) return; }  // 06086466 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060865C4u);  // 0608646A mov.l 0x060865C4,r1
    c.r[5] = 0x0u;  // 0608646C mov #0,r5
    c.r[6] = ld32(c.r[1]);  // 0608646E mov.l @r1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06086474u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086474u) return; }  // 06086470 jsr @r10 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06086474 mov.b @r12,r1
    c.r[3] = ld32(0x060865C8u);  // 06086476 mov.l 0x060865C8,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06086478 extu.b r1,r6
    c.r[0] = c.r[6];  // 0608647A mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0608647C mov.b @(r0,r11),r1
    c.r[7] = 0x16u;  // 0608647E mov #22,r7
    c.r[10] = c.r[1] & 0xFFu;  // 06086480 extu.b r1,r10
    c.r[10] -= 1;  // 06086482 add #-1,r10
    c.r[0] = ld32(0x06086594u);  // 06086484 mov.l 0x06086594,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06086486 mov.b @(r0,r6),r1
    c.macl = c.r[10] * c.r[7];  // 06086488 mul.l r7,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0608648A extu.b r1,r1
    c.r[0] = ld32(0x060865B0u);  // 0608648C mov.l 0x060865B0,r0
    c.r[2] = c.macl;  // 0608648E sts macl,r2
    c.r[2] += c.r[1];  // 06086490 add r1,r2
    st16(c.r[3], c.r[2]);  // 06086492 mov.w r2,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06086494 mov.w @r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06086496 extu.w r1,r2
    c.r[1] = c.macl;  // 06086498 sts macl,r1
    c.r[2] -= c.r[1];  // 0608649A sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0608649C cmp/gt r7,r2
    { const bool k = c.t; c.r[9] = c.r[7]; if (k) { goto L_060864A4; } }  // 0608649E bt/s 0x060864A4 ; mov r7,r9
    c.r[9] = c.r[2];  // 060864A2 mov r2,r9
L_060864A4:
    c.r[4] = 0x1u;  // 060864A4 mov #1,r4
    c.r[4] &= c.r[9];  // 060864A6 and r9,r4
    c.r[4] += c.r[9];  // 060864A8 add r9,r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060864AA shar r4
    c.r[1] = ld32(0x060865CCu);  // 060864AC mov.l 0x060865CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060864B2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060864B2u) return; }  // 060864AE jsr @r1 ; extu.b r4,r4
    c.t = (c.r[13] & c.r[13]) == 0;  // 060864B2 tst r13,r13
    { const bool k = !c.t; c.r[1] = 0x16u; if (k) { goto L_060864EE; } }  // 060864B4 bf/s 0x060864EE ; mov #22,r1
    c.macl = c.r[10] * c.r[1];  // 060864B8 mul.l r1,r10
    c.r[8] = c.macl;  // 060864BA sts macl,r8
    c.r[1] = c.macl;  // 060864BC sts macl,r1
    c.r[1] += c.r[9];  // 060864BE add r9,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060864C0 cmp/ge r1,r8
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06086522; } }  // 060864C2 bt/s 0x06086522 ; mov #1,r0
    c.r[11] = ld32(0x060865D0u);  // 060864C6 mov.l 0x060865D0,r11
    c.r[0] = c.r[8];  // 060864C8 mov r8,r0
L_060864CA:
    c.r[0] += c.r[0];  // 060864CA add r0,r0
    c.r[1] = ld32(0x060865D4u);  // 060864CC mov.l 0x060865D4,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060864CE mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608658Cu);  // 060864D0 mov.w 0x0608658C,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608658Eu);  // 060864D2 mov.w 0x0608658E,r1
    c.r[4] += c.r[1];  // 060864D4 add r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060864DAu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060864DAu) return; }  // 060864D6 jsr @r11 ; extu.w r4,r4
    c.r[1] = 0x16u;  // 060864DA mov #22,r1
    c.macl = c.r[10] * c.r[1];  // 060864DC mul.l r1,r10
    c.r[8] += 1;  // 060864DE add #1,r8
    c.r[1] = c.macl;  // 060864E0 sts macl,r1
    c.r[1] += c.r[9];  // 060864E2 add r9,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060864E4 cmp/ge r1,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_060864CA; } }  // 060864E6 bf/s 0x060864CA ; mov r8,r0
    c.r[0] = 0x1u; goto L_06086522;  // 060864EA bra 0x06086522 ; mov #1,r0
L_060864EE:
    c.macl = c.r[10] * c.r[1];  // 060864EE mul.l r1,r10
    c.r[8] = c.macl;  // 060864F0 sts macl,r8
    c.r[1] = c.macl;  // 060864F2 sts macl,r1
    c.r[1] += c.r[9];  // 060864F4 add r9,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060864F6 cmp/ge r1,r8
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06086522; } }  // 060864F8 bt/s 0x06086522 ; mov #1,r0
    c.r[11] = ld32(0x060865D0u);  // 060864FC mov.l 0x060865D0,r11
    c.r[0] = c.r[8];  // 060864FE mov r8,r0
L_06086500:
    c.r[0] += c.r[0];  // 06086500 add r0,r0
    c.r[1] = ld32(0x060865D4u);  // 06086502 mov.l 0x060865D4,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086504 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608658Cu);  // 06086506 mov.w 0x0608658C,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086590u);  // 06086508 mov.w 0x06086590,r1
    c.r[4] += c.r[1];  // 0608650A add r1,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06086510u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086510u) return; }  // 0608650C jsr @r11 ; extu.w r4,r4
    c.r[1] = 0x16u;  // 06086510 mov #22,r1
    c.macl = c.r[10] * c.r[1];  // 06086512 mul.l r1,r10
    c.r[8] += 1;  // 06086514 add #1,r8
    c.r[1] = c.macl;  // 06086516 sts macl,r1
    c.r[1] += c.r[9];  // 06086518 add r9,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0608651A cmp/ge r1,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_06086500; } }  // 0608651C bf/s 0x06086500 ; mov r8,r0
    c.r[0] = 0x1u;  // 06086520 mov #1,r0
L_06086522:
    c.r[9] &= c.r[0];  // 06086522 and r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06086524 tst r9,r9
    if (c.t) { goto L_06086532; }  // 06086526 bt 0x06086532
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608658Cu);  // 06086528 mov.w 0x0608658C,r5
    c.r[4] = ld32(0x060865D8u);  // 0608652A mov.l 0x060865D8,r4
    c.r[1] = ld32(0x060865D0u);  // 0608652C mov.l 0x060865D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086532u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086532u) return; }  // 0608652E jsr @r1 ; nop
L_06086532:
    c.r[7] = ld32(0x060865B0u);  // 06086532 mov.l 0x060865B0,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06086534 mov.w @r7,r3
    c.r[1] = 0x0u;  // 06086536 mov #0,r1
    c.r[2] = 0x1u;  // 06086538 mov #1,r2
    c.r[3] = c.r[3] & 0xFFFFu;  // 0608653A extu.w r3,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0608653C mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608653E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086540 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086542 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086544 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086546 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086548 mov.l r1,@-r15
    c.r[1] = 0x4u;  // 0608654A mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608654C mov.l r1,@-r15
    c.r[1] = 0xBu;  // 0608654E mov #11,r1
    c.t = c.r[3] > c.r[2];  // 06086550 cmp/hi r2,r3
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.r[1]); if (k) { goto L_0608655E; } }  // 06086552 bt/s 0x0608655E ; mov.l r1,@-r15
    c.r[7] += 1;  // 06086556 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06086558 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06086560;  // 0608655A bra 0x06086560 ; extu.b r1,r1
L_0608655E:
    c.r[1] = 0x2u;  // 0608655E mov #2,r1
L_06086560:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086560 mov.l r1,@-r15
    c.r[1] = ld32(0x060865DCu);  // 06086562 mov.l 0x060865DC,r1
    c.r[7] = 0x2u;  // 06086564 mov #2,r7
    c.r[6] = 0x10u;  // 06086566 mov #16,r6
    c.r[5] = 0x5u;  // 06086568 mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608656Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608656Eu) return; }  // 0608656A jsr @r1 ; mov #2,r4
    c.r[15] += 40;  // 0608656E add #40,r15
    c.r[1] = ld32(0x060865E0u);  // 06086570 mov.l 0x060865E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086576u; c.r[4] = 0x56u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086576u) return; }  // 06086572 jsr @r1 ; mov #86,r4
    c.r[15] = c.r[14];  // 06086576 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086578 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608657A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608657C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608657E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06086580 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06086582 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06086584 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086592u);  // 06086586 mov.w 0x06086592,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086588 rts ; mov.l @r15+,r8
}

void f_060865E4(SH2Context& c) {
    ran[1879] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060865E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060865E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060865E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060865EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060865EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060865EE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060865F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060865F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060865F4 mov r15,r14
    c.r[1] = ld32(0x06086774u);  // 060865F6 mov.l 0x06086774,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060865FCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060865FCu) return; }  // 060865F8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086778u);  // 060865FC mov.l 0x06086778,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086602u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086602u) return; }  // 060865FE jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0608677Cu);  // 06086602 mov.l 0x0608677C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086608u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086608u) return; }  // 06086604 jsr @r1 ; nop
    c.r[11] = ld32(0x06086780u);  // 06086608 mov.l 0x06086780,r11
    c.r[0] = ld32(0x06086784u);  // 0608660A mov.l 0x06086784,r0
    c.r[12] = ld32(0x06086788u);  // 0608660C mov.l 0x06086788,r12
    c.r[9] = ld32(0x0608678Cu);  // 0608660E mov.l 0x0608678C,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06086610 mov.w @r11,r1
    c.r[5] = 0x1Cu;  // 06086612 mov #28,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 06086614 extu.w r1,r1
    c.r[1] += c.r[1];  // 06086616 add r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086618 mov.w @(r0,r1),r8
    c.r[4] = c.r[12];  // 0608661A mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06086620u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086620u) return; }  // 0608661C jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06086620 mov r0,r1
    c.r[5] = c.r[8];  // 06086622 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086628u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086628u) return; }  // 06086624 jsr @r9 ; mov r1,r4
    c.r[13] = c.r[0];  // 06086628 mov r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0608662A mov.w @r11,r1
    c.r[0] = ld32(0x06086784u);  // 0608662C mov.l 0x06086784,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0608662E extu.w r1,r1
    c.r[1] += c.r[1];  // 06086630 add r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086632 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608675Eu);  // 06086634 mov.w 0x0608675E,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086760u);  // 06086636 mov.w 0x06086760,r1
    c.r[4] += c.r[1];  // 06086638 add r1,r4
    c.r[1] = ld32(0x06086790u);  // 0608663A mov.l 0x06086790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086640u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086640u) return; }  // 0608663C jsr @r1 ; extu.w r4,r4
    c.r[3] = c.r[13];  // 06086640 mov r13,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086762u);  // 06086642 mov.w 0x06086762,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06086644 mov.b @r3+,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06086646 extu.b r4,r4
    c.r[4] <<= 8;  // 06086648 shll8 r4
    c.r[4] &= c.r[1];  // 0608664A and r1,r4
    c.r[1] = ld32(0x06086794u);  // 0608664C mov.l 0x06086794,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086652u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086652u) return; }  // 0608664E jsr @r1 ; mov #23,r5
    c.r[8] = c.r[4];  // 06086652 mov r4,r8
    c.r[8] += 2;  // 06086654 add #2,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06086656 extu.w r8,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0608665Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608665Cu) return; }  // 06086658 jsr @r9 ; mov r12,r4
    c.r[1] = c.r[0];  // 0608665C mov r0,r1
    c.r[5] = 0x24u;  // 0608665E mov #36,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086664u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086664u) return; }  // 06086660 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06086664 mov r0,r1
    c.r[5] = c.r[8];  // 06086666 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608666Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608666Cu) return; }  // 06086668 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0608666C mov r0,r1
    c.r[8] = ld32(0x06086798u);  // 0608666E mov.l 0x06086798,r8
    c.r[6] = 0x0u;  // 06086670 mov #0,r6
    c.r[5] = c.r[1];  // 06086672 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086678u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086678u) return; }  // 06086674 jsr @r8 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06086678 mov.w @r11,r1
    c.r[0] = ld32(0x06086784u);  // 0608667A mov.l 0x06086784,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0608667C extu.w r1,r1
    c.r[1] += c.r[1];  // 0608667E add r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086680 mov.w @(r0,r1),r5
    c.r[2] = 0x1u;  // 06086682 mov #1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086764u);  // 06086684 mov.w 0x06086764,r1
    c.r[1] += c.r[5];  // 06086686 add r5,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06086688 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0608668A cmp/hi r2,r1
    if (c.t) { goto L_06086724; }  // 0608668C bt 0x06086724
    c.r[1] = ld32(0x0608679Cu);  // 0608668E mov.l 0x0608679C,r1
    c.r[3] = ld32(c.r[1]);  // 06086690 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06086692 mov r3,r1
    c.r[1] += 8;  // 06086694 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06086696 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06086698 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608669A tst r0,r0
    if (!c.t) { goto L_060866BC; }  // 0608669C bf 0x060866BC
    c.r[5] = 0x17u;  // 0608669E mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060866A4u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060866A4u) return; }  // 060866A0 jsr @r9 ; mov r12,r4
    c.r[5] = 0x23u;  // 060866A4 mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060866AAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060866AAu) return; }  // 060866A6 jsr @r9 ; mov r0,r4
    c.r[5] = 0x37u;  // 060866AA mov #55,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060866B0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060866B0u) return; }  // 060866AC jsr @r9 ; mov r0,r4
    c.r[6] = 0x0u;  // 060866B0 mov #0,r6
    c.r[5] = c.r[0];  // 060866B2 mov r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060866B8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060866B8u) return; }  // 060866B4 jsr @r8 ; mov #0,r4
    c.r[5] = 0x17u; goto L_060867A8;  // 060866B8 bra 0x060867A8 ; mov #23,r5
L_060866BC:
    c.r[2] = c.r[5] & 0xFFFFu;  // 060866BC extu.w r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086766u);  // 060866BE mov.w 0x06086766,r1
    c.t = c.r[2] == c.r[1];  // 060866C0 cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_060866D4; } }  // 060866C2 bf/s 0x060866D4 ; mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086768u);  // 060866C6 mov.w 0x06086768,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060866C8 mov.b @(r0,r1),r1
    c.r[2] = c.r[1];  // 060866CA mov r1,r2
    c.r[2] >>= 2;  // 060866CC shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608676Au);  // 060866CE mov.w 0x0608676A,r1
    c.r[2] >>= 2; goto L_060866E0;  // 060866D0 bra 0x060866E0 ; shlr2 r2
L_060866D4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608676Cu);  // 060866D4 mov.w 0x0608676C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060866D6 mov.b @(r0,r1),r1
    c.r[2] = c.r[1];  // 060866D8 mov r1,r2
    c.r[2] >>= 2;  // 060866DA shlr2 r2
    c.r[2] >>= 2;  // 060866DC shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608676Eu);  // 060866DE mov.w 0x0608676E,r1
L_060866E0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060866E0 mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060866E2 shlr r1
    c.r[0] = 0x3u;  // 060866E4 mov #3,r0
    c.r[1] &= c.r[0];  // 060866E6 and r0,r1
    c.r[0] = 0x4u;  // 060866E8 mov #4,r0
    c.r[2] &= c.r[0];  // 060866EA and r0,r2
    c.r[2] |= c.r[1];  // 060866EC or r1,r2
    c.r[2] += c.r[2];  // 060866EE add r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086770u);  // 060866F0 mov.w 0x06086770,r1
    c.r[2] += c.r[1];  // 060866F2 add r1,r2
    c.r[4] = ld32(0x060867A0u);  // 060866F4 mov.l 0x060867A0,r4
    c.r[8] = ld32(0x0608678Cu);  // 060866F6 mov.l 0x0608678C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060866FCu; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060866FCu) return; }  // 060866F8 jsr @r8 ; mov r2,r5
    c.r[9] = ld32(0x06086798u);  // 060866FC mov.l 0x06086798,r9
    c.r[6] = 0x0u;  // 060866FE mov #0,r6
    c.r[5] = c.r[0];  // 06086700 mov r0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086706u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086706u) return; }  // 06086702 jsr @r9 ; mov #0,r4
    c.r[4] = ld32(0x06086788u);  // 06086706 mov.l 0x06086788,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608670Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608670Cu) return; }  // 06086708 jsr @r8 ; mov #23,r5
    c.r[5] = 0x24u;  // 0608670C mov #36,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086712u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086712u) return; }  // 0608670E jsr @r8 ; mov r0,r4
    c.r[5] = 0x1Bu;  // 06086712 mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086718u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086718u) return; }  // 06086714 jsr @r8 ; mov r0,r4
    c.r[6] = 0x0u;  // 06086718 mov #0,r6
    c.r[5] = c.r[0];  // 0608671A mov r0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086720u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086720u) return; }  // 0608671C jsr @r9 ; mov #0,r4
    goto L_060867C0;  // 06086720 bra 0x060867C0 ; nop
L_06086724:
    c.r[4] = ld32(0x060867A0u);  // 06086724 mov.l 0x060867A0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0608672Au; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608672Au) return; }  // 06086726 jsr @r9 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0608672A mov r0,r1
    c.r[6] = 0x0u;  // 0608672C mov #0,r6
    c.r[5] = c.r[1];  // 0608672E mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086734u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086734u) return; }  // 06086730 jsr @r8 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06086734 mov.w @r11,r1
    c.r[0] = ld32(0x06086784u);  // 06086736 mov.l 0x06086784,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06086738 extu.w r1,r1
    c.r[1] += c.r[1];  // 0608673A add r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0608673C mov.w @(r0,r1),r5
    c.r[4] = ld32(0x060867A4u);  // 0608673E mov.l 0x060867A4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06086744u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086744u) return; }  // 06086740 jsr @r9 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06086744 mov r0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06086746 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06086748 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608674A tst r1,r1
    { const bool k = c.t; c.r[5] = 0x17u; if (k) { goto L_060867A8; } }  // 0608674C bt/s 0x060867A8 ; mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086754u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086754u) return; }  // 06086750 jsr @r9 ; mov r12,r4
    c.r[5] = 0x24u;  // 06086754 mov #36,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608675Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608675Au) return; }  // 06086756 jsr @r9 ; mov r0,r4
    c.r[5] = 0x1Bu; goto L_060867B4;  // 0608675A bra 0x060867B4 ; mov #27,r5
L_060867A8:
    { const uint32_t x = c.r[9]; c.pr = 0x060867ACu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867ACu) return; }  // 060867A8 jsr @r9 ; mov r12,r4
    c.r[5] = 0x23u;  // 060867AC mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060867B2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867B2u) return; }  // 060867AE jsr @r9 ; mov r0,r4
    c.r[5] = 0x38u;  // 060867B2 mov #56,r5
L_060867B4:
    { const uint32_t x = c.r[9]; c.pr = 0x060867B8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867B8u) return; }  // 060867B4 jsr @r9 ; mov r0,r4
    c.r[6] = 0x0u;  // 060867B8 mov #0,r6
    c.r[5] = c.r[0];  // 060867BA mov r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060867C0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867C0u) return; }  // 060867BC jsr @r8 ; mov #0,r4
L_060867C0:
    c.r[1] = ld32(0x0608681Cu);  // 060867C0 mov.l 0x0608681C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060867C2 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060867C4 extu.w r1,r0
    c.r[0] += c.r[0];  // 060867C6 add r0,r0
    c.r[1] = ld32(0x06086820u);  // 060867C8 mov.l 0x06086820,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060867CA mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06086812u);  // 060867CC mov.w 0x06086812,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086814u);  // 060867CE mov.w 0x06086814,r1
    c.r[4] += c.r[1];  // 060867D0 add r1,r4
    c.r[1] = ld32(0x06086824u);  // 060867D2 mov.l 0x06086824,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060867D8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867D8u) return; }  // 060867D4 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x06086828u);  // 060867D8 mov.l 0x06086828,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060867DEu; c.r[4] = 0x57u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867DEu) return; }  // 060867DA jsr @r1 ; mov #87,r4
    c.r[0] = ld32(0x0608682Cu);  // 060867DE mov.l 0x0608682C,r0
    c.r[6] = 0x1u;  // 060867E0 mov #1,r6
    c.r[5] = 0x2u;  // 060867E2 mov #2,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[13]); c.r[13] += 1;  // 060867E4 mov.b @r13+,r7
    c.r[4] = 0x0u;  // 060867E6 mov #0,r4
    c.r[7] = c.r[7] & 0xFFu;  // 060867E8 extu.b r7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060867EA mov.b @r13,r1
    c.r[7] <<= 8;  // 060867EC shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 060867EE extu.b r1,r1
    c.r[7] |= c.r[1];  // 060867F0 or r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086816u);  // 060867F2 mov.w 0x06086816,r1
    c.r[7] &= c.r[1];  // 060867F4 and r1,r7
    c.r[1] = 0x0u;  // 060867F6 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060867FCu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060867FCu) return; }  // 060867F8 jsr @r0 ; mov.l r1,@-r15
    c.r[15] = c.r[14];  // 060867FC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060867FE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086800 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06086802 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06086804 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06086806 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06086808 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608680A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086818u);  // 0608680C mov.w 0x06086818,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608680E rts ; mov.l @r15+,r8
}

void f_06086830(SH2Context& c) {
    ran[1880] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086830 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086832 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06086834 mov r15,r14
    c.r[1] = ld32(0x060868CCu);  // 06086836 mov.l 0x060868CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608683Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608683Cu) return; }  // 06086838 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060868D0u);  // 0608683C mov.l 0x060868D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086842u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086842u) return; }  // 0608683E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060868D4u);  // 06086842 mov.l 0x060868D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086848u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086848u) return; }  // 06086844 jsr @r1 ; nop
    c.r[1] = ld32(0x060868D8u);  // 06086848 mov.l 0x060868D8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608684A mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0608684C extu.w r1,r0
    c.r[0] += c.r[0];  // 0608684E add r0,r0
    c.r[1] = ld32(0x060868DCu);  // 06086850 mov.l 0x060868DC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086852 mov.w @(r0,r1),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06086854 extu.w r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060868BAu);  // 06086856 mov.w 0x060868BA,r1
    c.t = c.r[3] == c.r[1];  // 06086858 cmp/eq r1,r3
    { const bool k = !c.t; c.r[7] = 0x4u; if (k) { goto L_06086870; } }  // 0608685A bf/s 0x06086870 ; mov #4,r7
    c.r[1] = ld32(0x060868E0u);  // 0608685E mov.l 0x060868E0,r1
    c.r[2] = ld32(c.r[1]);  // 06086860 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060868BCu);  // 06086862 mov.w 0x060868BC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06086864 mov.b @(r0,r2),r1
    c.r[3] = c.r[1];  // 06086866 mov r1,r3
    c.r[3] >>= 2;  // 06086868 shlr2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060868BEu);  // 0608686A mov.w 0x060868BE,r0
    c.r[3] >>= 2; goto L_06086886;  // 0608686C bra 0x06086886 ; shlr2 r3
L_06086870:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060868C0u);  // 06086870 mov.w 0x060868C0,r1
    c.t = c.r[3] == c.r[1];  // 06086872 cmp/eq r1,r3
    if (!c.t) { goto L_06086898; }  // 06086874 bf 0x06086898
    c.r[1] = ld32(0x060868E0u);  // 06086876 mov.l 0x060868E0,r1
    c.r[2] = ld32(c.r[1]);  // 06086878 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060868C2u);  // 0608687A mov.w 0x060868C2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0608687C mov.b @(r0,r2),r1
    c.r[3] = c.r[1];  // 0608687E mov r1,r3
    c.r[3] >>= 2;  // 06086880 shlr2 r3
    c.r[3] >>= 2;  // 06086882 shlr2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060868C4u);  // 06086884 mov.w 0x060868C4,r0
L_06086886:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06086886 mov.b @(r0,r2),r1
    c.r[3] &= c.r[7];  // 06086888 and r7,r3
    c.r[0] = c.r[1];  // 0608688A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0608688C shlr r0
    c.r[0] &= 0x3u;  // 0608688E and #3,r0
    c.r[3] += c.r[0];  // 06086890 add r0,r3
    c.r[3] += c.r[3];  // 06086892 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060868C6u);  // 06086894 mov.w 0x060868C6,r1
    c.r[3] += c.r[1];  // 06086896 add r1,r3
L_06086898:
    c.r[1] = ld32(0x060868E4u);  // 06086898 mov.l 0x060868E4,r1
    c.r[5] = c.r[3];  // 0608689A mov r3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060868A0u; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060868A0u) return; }  // 0608689C jsr @r1 ; mov #7,r4
    c.r[5] = ld32(0x060868E8u);  // 060868A0 mov.l 0x060868E8,r5
    c.r[1] = ld32(0x060868ECu);  // 060868A2 mov.l 0x060868EC,r1
    c.r[6] = 0x0u;  // 060868A4 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060868AAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060868AAu) return; }  // 060868A6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060868F0u);  // 060868AA mov.l 0x060868F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060868B0u; c.r[4] = 0x58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060868B0u) return; }  // 060868AC jsr @r1 ; mov #88,r4
    c.r[15] = c.r[14];  // 060868B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060868B2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060868C8u);  // 060868B4 mov.w 0x060868C8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060868B6 rts ; mov.l @r15+,r14
}

void f_060868F4(SH2Context& c) {
    ran[1881] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060868F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060868F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060868F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060868FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060868FC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060868FE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086900 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086902 sts.l pr,@-r15
    c.r[15] -= 8;  // 06086904 add #-8,r15
    c.r[14] = c.r[15];  // 06086906 mov r15,r14
    c.r[11] = ld32(0x06086B04u);  // 06086908 mov.l 0x06086B04,r11
    c.r[10] = ld32(0x06086B08u);  // 0608690A mov.l 0x06086B08,r10
    c.r[12] = ld32(0x06086B0Cu);  // 0608690C mov.l 0x06086B0C,r12
    c.r[5] = 0x1Bu;  // 0608690E mov #27,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06086910 mov.w @r11,r1
    c.r[4] = c.r[12];  // 06086912 mov r12,r4
    c.r[0] = c.r[1] & 0xFFFFu;  // 06086914 extu.w r1,r0
    c.r[0] += c.r[0];  // 06086916 add r0,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06086918 mov.w @(r0,r10),r8
    c.r[9] = ld32(0x06086B10u);  // 0608691A mov.l 0x06086B10,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06086920u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086920u) return; }  // 0608691C jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06086920 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086926u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086926u) return; }  // 06086922 jsr @r9 ; mov r0,r4
    c.r[13] = c.r[0];  // 06086926 mov r0,r13
    c.r[1] = ld32(0x06086B14u);  // 06086928 mov.l 0x06086B14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608692Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608692Eu) return; }  // 0608692A jsr @r1 ; mov #0,r4
    c.r[1] = c.r[13];  // 0608692E mov r13,r1
    c.r[1] += 2;  // 06086930 add #2,r1
    c.r[0] = ld32(0x06086B18u);  // 06086932 mov.l 0x06086B18,r0
    c.r[6] = 0x0u;  // 06086934 mov #0,r6
    c.r[5] = 0x13u;  // 06086936 mov #19,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06086938 mov.b @r1,r7
    c.r[4] = 0x0u;  // 0608693A mov #0,r4
    c.r[7] = c.r[7] & 0xFFu;  // 0608693C extu.b r7,r7
    c.r[1] = c.r[13];  // 0608693E mov r13,r1
    c.r[1] += 3;  // 06086940 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06086942 mov.b @r1,r1
    c.r[7] <<= 8;  // 06086944 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06086946 extu.b r1,r1
    c.r[7] |= c.r[1];  // 06086948 or r1,r7
    c.r[1] = 0x0u;  // 0608694A mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06086950u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086950u) return; }  // 0608694C jsr @r0 ; mov.l r1,@-r15
    c.r[1] = ld32(0x06086B1Cu);  // 06086950 mov.l 0x06086B1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086956u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086956u) return; }  // 06086952 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086B20u);  // 06086956 mov.l 0x06086B20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608695Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608695Cu) return; }  // 06086958 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0608695C mov.w @r11,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06086B00u);  // 0608695E mov.w 0x06086B00,r5
    c.r[0] = c.r[1] & 0xFFFFu;  // 06086960 extu.w r1,r0
    c.r[0] += c.r[0];  // 06086962 add r0,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06086964 mov.w @(r0,r10),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06086B02u);  // 06086966 mov.w 0x06086B02,r1
    c.r[4] += c.r[1];  // 06086968 add r1,r4
    c.r[1] = ld32(0x06086B24u);  // 0608696A mov.l 0x06086B24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086970u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086970u) return; }  // 0608696C jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x17u;  // 06086970 mov #23,r5
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06086972 mov.b @r13,r8
    c.r[4] = c.r[12];  // 06086974 mov r12,r4
    c.r[8] = c.r[8] & 0xFFu;  // 06086976 extu.b r8,r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06086978 shlr r8
    c.r[8] += 2;  // 0608697A add #2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06086980u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086980u) return; }  // 0608697C jsr @r9 ; extu.w r8,r8
    c.r[5] = 0x24u;  // 06086980 mov #36,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086986u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086986u) return; }  // 06086982 jsr @r9 ; mov r0,r4
    c.r[5] = c.r[8];  // 06086986 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608698Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608698Cu) return; }  // 06086988 jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x06086B28u);  // 0608698C mov.l 0x06086B28,r1
    c.r[6] = 0x0u;  // 0608698E mov #0,r6
    c.r[5] = c.r[0];  // 06086990 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06086996u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086996u) return; }  // 06086992 jsr @r1 ; mov #0,r4
    c.r[9] = c.r[13];  // 06086996 mov r13,r9
    c.r[9] += 11;  // 06086998 add #11,r9
    st32(c.r[14], c.r[9]);  // 0608699A mov.l r9,@r14
    c.r[12] = c.r[13];  // 0608699C mov r13,r12
    c.r[12] += 12;  // 0608699E add #12,r12
    c.r[11] = c.r[13];  // 060869A0 mov r13,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060869A2 mov.b @r9,r1
    c.r[11] += 13;  // 060869A4 add #13,r11
    c.r[2] = c.r[1];  // 060869A6 mov r1,r2
    c.r[2] <<= 16;  // 060869A8 shll16 r2
    c.r[2] <<= 8;  // 060869AA shll8 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060869AC mov.b @r12,r1
    c.r[10] = c.r[13];  // 060869AE mov r13,r10
    c.r[1] = c.r[1] & 0xFFu;  // 060869B0 extu.b r1,r1
    c.r[1] <<= 16;  // 060869B2 shll16 r1
    c.r[2] |= c.r[1];  // 060869B4 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060869B6 mov.b @r11,r1
    c.r[10] += 14;  // 060869B8 add #14,r10
    c.r[1] = c.r[1] & 0xFFu;  // 060869BA extu.b r1,r1
    c.r[1] <<= 8;  // 060869BC shll8 r1
    c.r[2] |= c.r[1];  // 060869BE or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060869C0 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060869C2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060869C4 or r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060869C6 tst r2,r2
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06086A42; } }  // 060869C8 bt/s 0x06086A42 ; add #4,r15
    c.r[8] = ld32(0x06086B2Cu);  // 060869CC mov.l 0x06086B2C,r8
    c.r[5] = 0x0u;  // 060869CE mov #0,r5
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[8]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060869D0 dmuls.l r8,r2
    c.r[4] = 0x0u;  // 060869D2 mov #0,r4
    c.r[9] = ld32(0x06086B30u);  // 060869D4 mov.l 0x06086B30,r9
    c.r[6] = c.mach;  // 060869D6 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060869D8 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060869DA shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060869DC shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060869DE shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060869E0 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060869E2 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060869E4 subc r2,r2
    { const uint32_t x = c.r[9]; c.pr = 0x060869EAu; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060869EAu) return; }  // 060869E6 jsr @r9 ; sub r2,r6
    c.r[9] = ld32(c.r[14]);  // 060869EA mov.l @r14,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060869EC mov.b @r12,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060869EE mov.b @r9,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060869F0 extu.b r1,r1
    c.r[3] <<= 16;  // 060869F2 shll16 r3
    c.r[3] <<= 8;  // 060869F4 shll8 r3
    c.r[1] <<= 16;  // 060869F6 shll16 r1
    c.r[3] |= c.r[1];  // 060869F8 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060869FA mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060869FC extu.b r1,r1
    c.r[1] <<= 8;  // 060869FE shll8 r1
    c.r[3] |= c.r[1];  // 06086A00 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086A02 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06086A04 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06086A06 or r1,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[8]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086A08 dmuls.l r8,r3
    c.r[2] = c.r[3];  // 06086A0A mov r3,r2
    c.r[1] = c.mach;  // 06086A0C sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086A0E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086A10 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086A12 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086A14 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086A16 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06086A18 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086A1A subc r2,r2
    c.r[1] -= c.r[2];  // 06086A1C sub r2,r1
    c.r[2] = 0x64u;  // 06086A1E mov #100,r2
    c.macl = c.r[1] * c.r[2];  // 06086A20 mul.l r2,r1
    c.r[5] = 0x0u;  // 06086A22 mov #0,r5
    c.r[1] = c.macl;  // 06086A24 sts macl,r1
    c.r[3] -= c.r[1];  // 06086A26 sub r1,r3
    c.r[1] = ld32(0x06086B34u);  // 06086A28 mov.l 0x06086B34,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086A2A dmuls.l r1,r3
    c.r[4] = 0x0u;  // 06086A2C mov #0,r4
    c.r[9] = ld32(0x06086B30u);  // 06086A2E mov.l 0x06086B30,r9
    c.r[6] = c.mach;  // 06086A30 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A32 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A34 shar r6
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 06086A36 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086A38 subc r3,r3
    { const uint32_t x = c.r[9]; c.pr = 0x06086A3Eu; c.r[6] -= c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086A3Eu) return; }  // 06086A3A jsr @r9 ; sub r3,r6
    c.r[9] = c.r[13]; goto L_06086A56;  // 06086A3E bra 0x06086A56 ; mov r13,r9
L_06086A42:
    c.r[8] = ld32(0x06086B30u);  // 06086A42 mov.l 0x06086B30,r8
    c.r[6] = 0x0u;  // 06086A44 mov #0,r6
    c.r[5] = 0x0u;  // 06086A46 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086A4Cu; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086A4Cu) return; }  // 06086A48 jsr @r8 ; mov #32,r4
    c.r[6] = 0x0u;  // 06086A4C mov #0,r6
    c.r[5] = 0x0u;  // 06086A4E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086A54u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086A54u) return; }  // 06086A50 jsr @r8 ; mov #16,r4
    c.r[9] = c.r[13];  // 06086A54 mov r13,r9
L_06086A56:
    c.r[9] += 15;  // 06086A56 add #15,r9
    st32(c.r[14] + 4, c.r[9]);  // 06086A58 mov.l r9,@(4,r14)
    c.r[12] = c.r[13];  // 06086A5A mov r13,r12
    c.r[12] += 16;  // 06086A5C add #16,r12
    c.r[11] = c.r[13];  // 06086A5E mov r13,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06086A60 mov.b @r9,r1
    c.r[11] += 17;  // 06086A62 add #17,r11
    c.r[2] = c.r[1];  // 06086A64 mov r1,r2
    c.r[2] <<= 16;  // 06086A66 shll16 r2
    c.r[2] <<= 8;  // 06086A68 shll8 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06086A6A mov.b @r12,r1
    c.r[10] = c.r[13];  // 06086A6C mov r13,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06086A6E extu.b r1,r1
    c.r[1] <<= 16;  // 06086A70 shll16 r1
    c.r[2] |= c.r[1];  // 06086A72 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06086A74 mov.b @r11,r1
    c.r[10] += 18;  // 06086A76 add #18,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06086A78 extu.b r1,r1
    c.r[1] <<= 8;  // 06086A7A shll8 r1
    c.r[2] |= c.r[1];  // 06086A7C or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086A7E mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06086A80 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06086A82 or r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06086A84 tst r2,r2
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06086B38; } }  // 06086A86 bt/s 0x06086B38 ; mov #0,r6
    c.r[8] = ld32(0x06086B2Cu);  // 06086A8A mov.l 0x06086B2C,r8
    c.r[5] = 0x0u;  // 06086A8C mov #0,r5
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[8]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086A8E dmuls.l r8,r2
    c.r[4] = 0x0u;  // 06086A90 mov #0,r4
    c.r[9] = ld32(0x06086B30u);  // 06086A92 mov.l 0x06086B30,r9
    c.r[6] = c.mach;  // 06086A94 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A96 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A98 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A9A shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A9C shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086A9E shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06086AA0 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086AA2 subc r2,r2
    { const uint32_t x = c.r[9]; c.pr = 0x06086AA8u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086AA8u) return; }  // 06086AA4 jsr @r9 ; sub r2,r6
    c.r[9] = ld32(c.r[14] + 4);  // 06086AA8 mov.l @(4,r14),r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06086AAA mov.b @r12,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06086AAC mov.b @r9,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06086AAE extu.b r1,r1
    c.r[3] <<= 16;  // 06086AB0 shll16 r3
    c.r[3] <<= 8;  // 06086AB2 shll8 r3
    c.r[1] <<= 16;  // 06086AB4 shll16 r1
    c.r[3] |= c.r[1];  // 06086AB6 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06086AB8 mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06086ABA extu.b r1,r1
    c.r[1] <<= 8;  // 06086ABC shll8 r1
    c.r[3] |= c.r[1];  // 06086ABE or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086AC0 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06086AC2 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06086AC4 or r1,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[8]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086AC6 dmuls.l r8,r3
    c.r[2] = c.r[3];  // 06086AC8 mov r3,r2
    c.r[1] = c.mach;  // 06086ACA sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086ACC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086ACE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086AD0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086AD2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086AD4 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06086AD6 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086AD8 subc r2,r2
    c.r[1] -= c.r[2];  // 06086ADA sub r2,r1
    c.r[2] = 0x64u;  // 06086ADC mov #100,r2
    c.macl = c.r[1] * c.r[2];  // 06086ADE mul.l r2,r1
    c.r[5] = 0x0u;  // 06086AE0 mov #0,r5
    c.r[1] = c.macl;  // 06086AE2 sts macl,r1
    c.r[3] -= c.r[1];  // 06086AE4 sub r1,r3
    c.r[1] = ld32(0x06086B34u);  // 06086AE6 mov.l 0x06086B34,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[3] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086AE8 dmuls.l r1,r3
    c.r[4] = 0x0u;  // 06086AEA mov #0,r4
    c.r[9] = ld32(0x06086B30u);  // 06086AEC mov.l 0x06086B30,r9
    c.r[6] = c.mach;  // 06086AEE sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086AF0 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086AF2 shar r6
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 06086AF4 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086AF6 subc r3,r3
    { const uint32_t x = c.r[9]; c.pr = 0x06086AFCu; c.r[6] -= c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086AFCu) return; }  // 06086AF8 jsr @r9 ; sub r3,r6
    goto L_06086B48;  // 06086AFC bra 0x06086B48 ; nop
L_06086B38:
    c.r[8] = ld32(0x06086B68u);  // 06086B38 mov.l 0x06086B68,r8
    c.r[5] = 0x0u;  // 06086B3A mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086B40u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B40u) return; }  // 06086B3C jsr @r8 ; mov #32,r4
    c.r[6] = 0x0u;  // 06086B40 mov #0,r6
    c.r[5] = 0x0u;  // 06086B42 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086B48u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B48u) return; }  // 06086B44 jsr @r8 ; mov #16,r4
L_06086B48:
    c.r[1] = ld32(0x06086B6Cu);  // 06086B48 mov.l 0x06086B6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086B4Eu; c.r[4] = 0x59u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B4Eu) return; }  // 06086B4A jsr @r1 ; mov #89,r4
    c.r[14] += 8;  // 06086B4E add #8,r14
    c.r[15] = c.r[14];  // 06086B50 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086B52 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086B54 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06086B56 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06086B58 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06086B5A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06086B5C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06086B5E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086B66u);  // 06086B60 mov.w 0x06086B66,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086B62 rts ; mov.l @r15+,r8
}

void f_06086B70(SH2Context& c) {
    ran[1882] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086B70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086B72 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06086B74 mov r15,r14
    c.r[1] = ld32(0x06086BB8u);  // 06086B76 mov.l 0x06086BB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086B7Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B7Cu) return; }  // 06086B78 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06086BBCu);  // 06086B7C mov.l 0x06086BBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086B82u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B82u) return; }  // 06086B7E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06086BC0u);  // 06086B82 mov.l 0x06086BC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086B88u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B88u) return; }  // 06086B84 jsr @r1 ; nop
    c.r[1] = ld32(0x06086BC4u);  // 06086B88 mov.l 0x06086BC4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06086B8A mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06086B8C extu.w r1,r0
    c.r[0] += c.r[0];  // 06086B8E add r0,r0
    c.r[1] = ld32(0x06086BC8u);  // 06086B90 mov.l 0x06086BC8,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086B92 mov.w @(r0,r1),r5
    c.r[4] = 0x6u;  // 06086B94 mov #6,r4
    c.r[1] = ld32(0x06086BCCu);  // 06086B96 mov.l 0x06086BCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086B9Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086B9Cu) return; }  // 06086B98 jsr @r1 ; extu.w r5,r5
    c.r[5] = ld32(0x06086BD0u);  // 06086B9C mov.l 0x06086BD0,r5
    c.r[1] = ld32(0x06086BD4u);  // 06086B9E mov.l 0x06086BD4,r1
    c.r[6] = 0x0u;  // 06086BA0 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06086BA6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086BA6u) return; }  // 06086BA2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086BD8u);  // 06086BA6 mov.l 0x06086BD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086BACu; c.r[4] = 0x5Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086BACu) return; }  // 06086BA8 jsr @r1 ; mov #90,r4
    c.r[15] = c.r[14];  // 06086BAC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086BAE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086BB6u);  // 06086BB0 mov.w 0x06086BB6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086BB2 rts ; mov.l @r15+,r14
}

void f_06086BDC(SH2Context& c) {
    ran[1883] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086BDC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06086BDE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06086BE0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06086BE2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06086BE4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06086BE6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086BE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086BEA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06086BEC mov r15,r14
    c.r[1] = ld32(0x06086D6Cu);  // 06086BEE mov.l 0x06086D6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086BF4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086BF4u) return; }  // 06086BF0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086D70u);  // 06086BF4 mov.l 0x06086D70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086BFAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086BFAu) return; }  // 06086BF6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086D74u);  // 06086BFA mov.l 0x06086D74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086C00u; c.r[11] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086C00u) return; }  // 06086BFC jsr @r1 ; mov #0,r11
    c.r[3] = ld32(0x06086D78u);  // 06086C00 mov.l 0x06086D78,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06086C02 mov.w @r3,r1
    c.r[2] = ld32(0x06086D7Cu);  // 06086C04 mov.l 0x06086D7C,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06086C06 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06086C08 cmp/eq r2,r1
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06086C3A; } }  // 06086C0A bt/s 0x06086C3A ; mov #0,r9
    c.r[8] = c.r[3];  // 06086C0E mov r3,r8
    c.r[10] = ld32(0x06086D80u);  // 06086C10 mov.l 0x06086D80,r10
    c.r[0] = c.r[9];  // 06086C12 mov r9,r0
L_06086C14:
    c.r[0] += c.r[0];  // 06086C14 add r0,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06086C16 mov.w @(r0,r8),r4
    c.r[5] = 0x2u;  // 06086C18 mov #2,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06086C1Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086C1Eu) return; }  // 06086C1A jsr @r10 ; extu.w r4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06086C1E tst r0,r0
    if (c.t) { goto L_06086C24; }  // 06086C20 bt 0x06086C24
    c.r[11] += 1;  // 06086C22 add #1,r11
L_06086C24:
    c.r[1] = c.r[9];  // 06086C24 mov r9,r1
    c.r[1] += 1;  // 06086C26 add #1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06086C28 extu.w r1,r9
    c.r[0] = c.r[9];  // 06086C2A mov r9,r0
    c.r[0] += c.r[0];  // 06086C2C add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06086C2E mov.w @(r0,r8),r1
    c.r[2] = ld32(0x06086D7Cu);  // 06086C30 mov.l 0x06086D7C,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06086C32 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06086C34 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_06086C14; } }  // 06086C36 bf/s 0x06086C14 ; mov r9,r0
L_06086C3A:
    c.r[10] = ld32(0x06086D84u);  // 06086C3A mov.l 0x06086D84,r10
    c.r[9] = ld32(0x06086D88u);  // 06086C3C mov.l 0x06086D88,r9
    c.r[8] = ld32(0x06086D8Cu);  // 06086C3E mov.l 0x06086D8C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086C40 mov.b @r10,r1
    c.r[5] = 0x0u;  // 06086C42 mov #0,r5
    c.r[0] = c.r[1] & 0xFFu;  // 06086C44 extu.b r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06086C46 mov.b @(r0,r9),r6
    c.r[4] = 0x0u;  // 06086C48 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06086C4Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086C4Eu) return; }  // 06086C4A jsr @r8 ; extu.b r6,r6
    c.r[1] = c.r[11];  // 06086C4E mov r11,r1
    c.r[1] += 10;  // 06086C50 add #10,r1
    c.r[12] = ld32(0x06086D90u);  // 06086C52 mov.l 0x06086D90,r12
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[12]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06086C54 dmuls.l r12,r1
    c.r[5] = 0x0u;  // 06086C56 mov #0,r5
    c.r[4] = 0x0u;  // 06086C58 mov #0,r4
    c.r[6] = c.mach;  // 06086C5A sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06086C5C shar r6
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06086C5E shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086C60 subc r1,r1
    { const uint32_t x = c.r[8]; c.pr = 0x06086C66u; c.r[6] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086C66u) return; }  // 06086C62 jsr @r8 ; sub r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086C66 mov.b @r10,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06086C68 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06086C6A mov.b @(r0,r9),r1
    c.r[4] = 0xBu;  // 06086C6C mov #11,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06086C6E extu.b r1,r1
    c.r[1] -= 1;  // 06086C70 add #-1,r1
    c.macl = c.r[1] * c.r[4];  // 06086C72 mul.l r4,r1
    c.r[2] = c.r[11];  // 06086C74 mov r11,r2
    c.r[10] = c.macl;  // 06086C76 sts macl,r10
    c.r[2] -= c.r[10];  // 06086C78 sub r10,r2
    c.r[1] = 0xAu;  // 06086C7A mov #10,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06086C7C cmp/gt r1,r2
    { const bool k = c.t; { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[11] * (int32_t)c.r[12]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; } if (k) { goto L_06086C9A; } }  // 06086C7E bt/s 0x06086C9A ; dmuls.l r12,r11
    c.r[2] = c.r[11];  // 06086C82 mov r11,r2
    c.r[1] = c.mach;  // 06086C84 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06086C86 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06086C88 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06086C8A subc r2,r2
    c.r[1] -= c.r[2];  // 06086C8C sub r2,r1
    c.macl = c.r[1] * c.r[4];  // 06086C8E mul.l r4,r1
    c.r[0] = c.r[11];  // 06086C90 mov r11,r0
    c.r[1] = c.macl;  // 06086C92 sts macl,r1
    c.r[0] -= c.r[1];  // 06086C94 sub r1,r0
    c.r[1] = c.r[0];  // 06086C96 mov r0,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06086C98 extu.b r1,r4
L_06086C9A:
    c.r[1] = ld32(0x06086D94u);  // 06086C9A mov.l 0x06086D94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086CA0u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086CA0u) return; }  // 06086C9C jsr @r1 ; mov #0,r9
    c.t = (c.r[10] & c.r[10]) == 0;  // 06086CA0 tst r10,r10
    if (c.t) { goto L_06086CCA; }  // 06086CA2 bt 0x06086CCA
    c.r[8] = ld32(0x06086D80u);  // 06086CA4 mov.l 0x06086D80,r8
L_06086CA6:
    c.r[0] = c.r[9];  // 06086CA6 mov r9,r0
    c.r[0] += c.r[0];  // 06086CA8 add r0,r0
    c.r[1] = ld32(0x06086D78u);  // 06086CAA mov.l 0x06086D78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06086CAC mov.w @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06086CAE extu.w r1,r4
    c.r[1] = ld32(0x06086D7Cu);  // 06086CB0 mov.l 0x06086D7C,r1
    c.t = c.r[4] == c.r[1];  // 06086CB2 cmp/eq r1,r4
    if (c.t) { goto L_06086CCA; }  // 06086CB4 bt 0x06086CCA
    { const uint32_t x = c.r[8]; c.pr = 0x06086CBAu; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086CBAu) return; }  // 06086CB6 jsr @r8 ; mov #2,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06086CBA tst r0,r0
    if (c.t) { goto L_06086CC0; }  // 06086CBC bt 0x06086CC0
    c.r[10] -= 1;  // 06086CBE add #-1,r10
L_06086CC0:
    c.r[1] = c.r[9];  // 06086CC0 mov r9,r1
    c.r[1] += 1;  // 06086CC2 add #1,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 06086CC4 tst r10,r10
    { const bool k = !c.t; c.r[9] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06086CA6; } }  // 06086CC6 bf/s 0x06086CA6 ; extu.w r1,r9
L_06086CCA:
    c.r[10] = 0xBu;  // 06086CCA mov #11,r10
    c.r[13] = ld32(0x06086D78u);  // 06086CCC mov.l 0x06086D78,r13
    c.r[12] = ld32(0x06086D98u);  // 06086CCE mov.l 0x06086D98,r12
L_06086CD0:
    c.r[8] = c.r[9];  // 06086CD0 mov r9,r8
    c.r[8] += c.r[8];  // 06086CD2 add r8,r8
    c.r[0] = c.r[8];  // 06086CD4 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06086CD6 mov.w @(r0,r13),r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 06086CD8 extu.w r1,r4
    c.r[1] = ld32(0x06086D7Cu);  // 06086CDA mov.l 0x06086D7C,r1
    c.t = c.r[4] == c.r[1];  // 06086CDC cmp/eq r1,r4
    { const bool k = c.t; c.r[1] = c.r[11] & 0xFFFFu; if (k) { goto L_06086D26; } }  // 06086CDE bt/s 0x06086D26 ; extu.w r11,r1
    c.r[0] = ld32(0x06086D80u);  // 06086CE2 mov.l 0x06086D80,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06086CE8u; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086CE8u) return; }  // 06086CE4 jsr @r0 ; mov #2,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06086CE8 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06086D1C; } }  // 06086CEA bt/s 0x06086D1C ; mov r9,r1
    c.r[10] -= 1;  // 06086CEE add #-1,r10
    c.r[0] = c.r[8];  // 06086CF0 mov r8,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06086CF2 mov.w @(r0,r13),r8
    c.r[5] = 0x17u;  // 06086CF4 mov #23,r5
    c.r[4] = ld32(0x06086D9Cu);  // 06086CF6 mov.l 0x06086D9C,r4
    c.r[8] += 32;  // 06086CF8 add #32,r8
    { const uint32_t x = c.r[12]; c.pr = 0x06086CFEu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086CFEu) return; }  // 06086CFA jsr @r12 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06086CFE mov r0,r1
    c.r[5] = 0x24u;  // 06086D00 mov #36,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06086D06u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086D06u) return; }  // 06086D02 jsr @r12 ; mov r1,r4
    c.r[1] = c.r[0];  // 06086D06 mov r0,r1
    c.r[5] = c.r[8];  // 06086D08 mov r8,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06086D0Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086D0Eu) return; }  // 06086D0A jsr @r12 ; mov r1,r4
    c.r[2] = c.r[0];  // 06086D0E mov r0,r2
    c.r[1] = ld32(0x06086DA0u);  // 06086D10 mov.l 0x06086DA0,r1
    c.r[6] = 0x0u;  // 06086D12 mov #0,r6
    c.r[5] = c.r[2];  // 06086D14 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06086D1Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086D1Au) return; }  // 06086D16 jsr @r1 ; mov #0,r4
    c.r[1] = c.r[9];  // 06086D1A mov r9,r1
L_06086D1C:
    c.r[1] += 1;  // 06086D1C add #1,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 06086D1E tst r10,r10
    { const bool k = !c.t; c.r[9] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06086CD0; } }  // 06086D20 bf/s 0x06086CD0 ; extu.w r1,r9
    c.r[1] = c.r[11] & 0xFFFFu;  // 06086D24 extu.w r11,r1
L_06086D26:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086D26 mov.l r1,@-r15
    c.r[2] = 0x1u;  // 06086D28 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086D2A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086D2C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086D2E mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06086D30 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086D32 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086D34 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086D36 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086D38 mov.l r1,@-r15
    c.r[1] = 0xBu;  // 06086D3A mov #11,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086D3C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086D3E mov.l r2,@-r15
    c.r[1] = ld32(0x06086DA4u);  // 06086D40 mov.l 0x06086DA4,r1
    c.r[7] = 0x2u;  // 06086D42 mov #2,r7
    c.r[6] = 0x18u;  // 06086D44 mov #24,r6
    c.r[5] = 0x5u;  // 06086D46 mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06086D4Cu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086D4Cu) return; }  // 06086D48 jsr @r1 ; mov #8,r4
    c.r[15] += 40;  // 06086D4C add #40,r15
    c.r[1] = ld32(0x06086DA8u);  // 06086D4E mov.l 0x06086DA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086D54u; c.r[4] = 0x64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086D54u) return; }  // 06086D50 jsr @r1 ; mov #100,r4
    c.r[15] = c.r[14];  // 06086D54 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086D56 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086D58 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06086D5A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06086D5C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06086D5E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06086D60 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06086D62 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086D6Au);  // 06086D64 mov.w 0x06086D6A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086D66 rts ; mov.l @r15+,r8
}

void f_06086DAC(SH2Context& c) {
    ran[1884] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086DAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06086DAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06086DB0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06086DB2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06086DB4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06086DB6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086DB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086DBA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06086DBC mov r15,r14
    c.r[1] = ld32(0x06086E94u);  // 06086DBE mov.l 0x06086E94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086DC4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086DC4u) return; }  // 06086DC0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086E98u);  // 06086DC4 mov.l 0x06086E98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086DCAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086DCAu) return; }  // 06086DC6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06086E9Cu);  // 06086DCA mov.l 0x06086E9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086DD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086DD0u) return; }  // 06086DCC jsr @r1 ; nop
    c.r[10] = ld32(0x06086EA0u);  // 06086DD0 mov.l 0x06086EA0,r10
    c.r[9] = ld32(0x06086EA4u);  // 06086DD2 mov.l 0x06086EA4,r9
    c.r[8] = ld32(0x06086EA8u);  // 06086DD4 mov.l 0x06086EA8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086DD6 mov.b @r10,r1
    c.r[5] = 0x0u;  // 06086DD8 mov #0,r5
    c.r[0] = c.r[1] & 0xFFu;  // 06086DDA extu.b r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06086DDC mov.b @(r0,r9),r6
    c.r[4] = 0x0u;  // 06086DDE mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06086DE4u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086DE4u) return; }  // 06086DE0 jsr @r8 ; extu.b r6,r6
    c.r[6] = 0x2u;  // 06086DE4 mov #2,r6
    c.r[5] = 0x0u;  // 06086DE6 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06086DECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086DECu) return; }  // 06086DE8 jsr @r8 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06086DEC mov.b @r10,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06086DEE extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06086DF0 mov.b @(r0,r9),r1
    c.r[2] = 0xBu;  // 06086DF2 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06086DF4 extu.b r1,r1
    c.r[1] -= 1;  // 06086DF6 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06086DF8 mul.l r2,r1
    c.r[4] = 0xAu;  // 06086DFA mov #10,r4
    c.r[12] = c.macl;  // 06086DFC sts macl,r12
    c.r[1] = 0x15u;  // 06086DFE mov #21,r1
    c.r[1] -= c.r[12];  // 06086E00 sub r12,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 06086E02 cmp/gt r4,r1
    { const bool k = c.t; c.r[10] = c.r[2]; if (k) { goto L_06086E0A; } }  // 06086E04 bt/s 0x06086E0A ; mov r2,r10
    c.r[10] = c.r[4];  // 06086E08 mov r4,r10
L_06086E0A:
    c.r[1] = ld32(0x06086EACu);  // 06086E0A mov.l 0x06086EAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086E10u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E10u) return; }  // 06086E0C jsr @r1 ; extu.b r10,r4
    c.r[9] = c.r[12];  // 06086E10 mov r12,r9
    c.r[1] = c.r[10];  // 06086E12 mov r10,r1
    c.r[1] += c.r[9];  // 06086E14 add r9,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06086E16 cmp/ge r1,r9
    { const bool k = c.t; c.r[3] = 0x15u; if (k) { goto L_06086E4E; } }  // 06086E18 bt/s 0x06086E4E ; mov #21,r3
    c.r[11] = ld32(0x06086EB0u);  // 06086E1C mov.l 0x06086EB0,r11
    c.r[13] = ld32(0x06086EB4u);  // 06086E1E mov.l 0x06086EB4,r13
    c.r[8] = c.r[9];  // 06086E20 mov r9,r8
L_06086E22:
    c.r[8] += 64;  // 06086E22 add #64,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06086E24 extu.w r8,r8
    c.r[4] = ld32(0x06086EB8u);  // 06086E26 mov.l 0x06086EB8,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06086E2Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E2Cu) return; }  // 06086E28 jsr @r11 ; mov #23,r5
    c.r[5] = 0x24u;  // 06086E2C mov #36,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06086E32u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E32u) return; }  // 06086E2E jsr @r11 ; mov r0,r4
    c.r[5] = c.r[8];  // 06086E32 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06086E38u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E38u) return; }  // 06086E34 jsr @r11 ; mov r0,r4
    c.r[6] = 0x0u;  // 06086E38 mov #0,r6
    c.r[5] = c.r[0];  // 06086E3A mov r0,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06086E40u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E40u) return; }  // 06086E3C jsr @r13 ; mov #0,r4
    c.r[9] += 1;  // 06086E40 add #1,r9
    c.r[1] = c.r[10];  // 06086E42 mov r10,r1
    c.r[1] += c.r[12];  // 06086E44 add r12,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06086E46 cmp/ge r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9]; if (k) { SH2_POLL(c); goto L_06086E22; } }  // 06086E48 bf/s 0x06086E22 ; mov r9,r8
    c.r[3] = 0x15u;  // 06086E4C mov #21,r3
L_06086E4E:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06086E4E mov.l r3,@-r15
    c.r[2] = 0x1u;  // 06086E50 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086E52 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086E54 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086E56 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06086E58 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086E5A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086E5C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086E5E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086E60 mov.l r1,@-r15
    c.r[1] = 0xBu;  // 06086E62 mov #11,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06086E64 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06086E66 mov.l r2,@-r15
    c.r[1] = ld32(0x06086EBCu);  // 06086E68 mov.l 0x06086EBC,r1
    c.r[7] = 0x2u;  // 06086E6A mov #2,r7
    c.r[6] = 0x18u;  // 06086E6C mov #24,r6
    c.r[5] = 0x5u;  // 06086E6E mov #5,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06086E74u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E74u) return; }  // 06086E70 jsr @r1 ; mov #8,r4
    c.r[15] += 40;  // 06086E74 add #40,r15
    c.r[1] = ld32(0x06086EC0u);  // 06086E76 mov.l 0x06086EC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086E7Cu; c.r[4] = 0x65u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086E7Cu) return; }  // 06086E78 jsr @r1 ; mov #101,r4
    c.r[15] = c.r[14];  // 06086E7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086E7E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086E80 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06086E82 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06086E84 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06086E86 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06086E88 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06086E8A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086E92u);  // 06086E8C mov.w 0x06086E92,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086E8E rts ; mov.l @r15+,r8
}

void f_06086EC4(SH2Context& c) {
    ran[1885] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086EC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06086EC6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06086EC8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086ECA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086ECC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06086ECE mov r15,r14
    c.r[1] = ld32(0x06086F24u);  // 06086ED0 mov.l 0x06086F24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086ED6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086ED6u) return; }  // 06086ED2 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06086F28u);  // 06086ED6 mov.l 0x06086F28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086EDCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086EDCu) return; }  // 06086ED8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06086F2Cu);  // 06086EDC mov.l 0x06086F2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086EE2u; c.r[8] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086EE2u) return; }  // 06086EDE jsr @r1 ; mov #2,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06086F20u);  // 06086EE2 mov.w 0x06086F20,r10
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086EE4 mov.l r8,@-r15
    c.r[9] = ld32(0x06086F30u);  // 06086EE6 mov.l 0x06086F30,r9
    c.r[7] = 0x8u;  // 06086EE8 mov #8,r7
    c.r[6] = 0x11u;  // 06086EEA mov #17,r6
    c.r[5] = 0x1u;  // 06086EEC mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086EF2u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086EF2u) return; }  // 06086EEE jsr @r9 ; mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086EF2 mov.l r8,@-r15
    c.r[7] = 0x24u;  // 06086EF4 mov #36,r7
    c.r[6] = 0x15u;  // 06086EF6 mov #21,r6
    c.r[5] = 0x1u;  // 06086EF8 mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06086EFEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086EFEu) return; }  // 06086EFA jsr @r9 ; mov r10,r4
    c.r[2] = ld32(0x06086F34u);  // 06086EFE mov.l 0x06086F34,r2
    c.r[1] = 0x0u;  // 06086F00 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06086F02 mov.b r1,@r2
    c.r[2] = ld32(0x06086F38u);  // 06086F04 mov.l 0x06086F38,r2
    c.r[1] = 0x1u;  // 06086F06 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06086F08 mov.b r1,@r2
    c.r[1] = ld32(0x06086F3Cu);  // 06086F0A mov.l 0x06086F3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06086F10u; c.r[4] = 0x66u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086F10u) return; }  // 06086F0C jsr @r1 ; mov #102,r4
    c.r[15] = c.r[14];  // 06086F10 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086F12 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086F14 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06086F16 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06086F18 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06086F22u);  // 06086F1A mov.w 0x06086F22,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06086F1C rts ; mov.l @r15+,r8
}

void f_06086F40(SH2Context& c) {
    ran[1886] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086F40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086F42 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086F44 sts.l pr,@-r15
    c.r[15] -= 4;  // 06086F46 add #-4,r15
    c.r[14] = c.r[15];  // 06086F48 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06086F4A mov.l r4,@r14
    c.r[4] = 0xFu;  // 06086F4C mov #15,r4
    c.r[8] = ld32(0x06086FBCu);  // 06086F4E mov.l 0x06086FBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06086F54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086F54u) return; }  // 06086F50 jsr @r8 ; nop
    c.r[1] = ld32(0x06086FC0u);  // 06086F54 mov.l 0x06086FC0,r1
    c.r[2] = ld32(0x06086FC4u);  // 06086F56 mov.l 0x06086FC4,r2
    c.r[1] = ld32(c.r[1]);  // 06086F58 mov.l @r1,r1
    c.r[4] = c.r[2];  // 06086F5A mov r2,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06086F60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086F60u) return; }  // 06086F5C jsr @r1 ; nop
    c.r[1] = ld32(c.r[14]);  // 06086F60 mov.l @r14,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06086F62 cmp/pz r1
    if (c.t) { goto L_06086F72; }  // 06086F64 bt 0x06086F72
L_06086F66:
    goto L_06086F6E;  // 06086F66 bra 0x06086F6E ; nop
L_06086F6E:
    SH2_POLL(c); goto L_06086F66;  // 06086F6E bra 0x06086F66 ; nop
L_06086F72:
    c.r[0] = ld32(c.r[14]);  // 06086F72 mov.l @r14,r0
    c.t = c.r[0] == 0x1u;  // 06086F74 cmp/eq #1,r0
    if (c.t) { goto L_06086F80; }  // 06086F76 bt 0x06086F80
    c.t = c.r[0] == 0x2u;  // 06086F78 cmp/eq #2,r0
    if (c.t) { goto L_06086F84; }  // 06086F7A bt 0x06086F84
    goto L_06086F8E;  // 06086F7C bra 0x06086F8E ; nop
L_06086F80:
    goto L_06086FA2;  // 06086F80 bra 0x06086FA2 ; nop
L_06086F84:
    c.r[8] = ld32(0x06086FC8u);  // 06086F84 mov.l 0x06086FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06086F8Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086F8Au) return; }  // 06086F86 jsr @r8 ; nop
    goto L_06086FA2;  // 06086F8A bra 0x06086FA2 ; nop
L_06086F8E:
    c.r[1] = ld32(0x06086FCCu);  // 06086F8E mov.l 0x06086FCC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06086F90 mov.b @r1,r2
    c.r[0] = c.r[2] & 0xFFu;  // 06086F92 extu.b r2,r0
    c.t = c.r[0] == 0x1u;  // 06086F94 cmp/eq #1,r0
    if (!c.t) { goto L_06086F9E; }  // 06086F96 bf 0x06086F9E
    c.r[8] = ld32(0x06086FC8u);  // 06086F98 mov.l 0x06086FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06086F9Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086F9Eu) return; }  // 06086F9A jsr @r8 ; nop
L_06086F9E:
    goto L_06086FA2;  // 06086F9E bra 0x06086FA2 ; nop
L_06086FA2:
    c.r[1] = ld32(0x06086FD0u);  // 06086FA2 mov.l 0x06086FD0,r1
    c.r[8] = ld32(c.r[1]);  // 06086FA4 mov.l @r1,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06086FAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086FAAu) return; }  // 06086FA6 jsr @r8 ; nop
    goto L_06086FAE;  // 06086FAA bra 0x06086FAE ; nop
L_06086FAE:
    c.r[14] += 4;  // 06086FAE add #4,r14
    c.r[15] = c.r[14];  // 06086FB0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06086FB2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06086FB4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06086FB6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06086FB8 rts ; nop
}

void f_06086FD4(SH2Context& c) {
    ran[1887] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06086FD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06086FD6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06086FD8 sts.l pr,@-r15
    c.r[15] -= 4;  // 06086FDA add #-4,r15
    c.r[14] = c.r[15];  // 06086FDC mov r15,r14
    c.r[8] = ld32(0x06087020u);  // 06086FDE mov.l 0x06087020,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06086FE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086FE4u) return; }  // 06086FE0 jsr @r8 ; nop
    c.r[8] = ld32(0x06087024u);  // 06086FE4 mov.l 0x06087024,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06086FEAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086FEAu) return; }  // 06086FE6 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 06086FEA tst r0,r0
    if (c.t) { goto L_06086FF2; }  // 06086FEC bt 0x06086FF2
    goto L_06087012;  // 06086FEE bra 0x06087012 ; nop
L_06086FF2:
    c.r[1] = ld32(0x06087028u);  // 06086FF2 mov.l 0x06087028,r1
    c.r[2] = ld32(c.r[1]);  // 06086FF4 mov.l @r1,r2
    c.r[4] = 0x0u;  // 06086FF6 mov #0,r4
    { const uint32_t x = c.r[2]; c.pr = 0x06086FFCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06086FFCu) return; }  // 06086FF8 jsr @r2 ; nop
    st32(c.r[14], c.r[0]);  // 06086FFC mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 06086FFE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06087000 tst r1,r1
    if (c.t) { goto L_06087008; }  // 06087002 bt 0x06087008
    goto L_06087012;  // 06087004 bra 0x06087012 ; nop
L_06087008:
    c.r[8] = ld32(0x0608702Cu);  // 06087008 mov.l 0x0608702C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608700Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608700Eu) return; }  // 0608700A jsr @r8 ; nop
    goto L_06087012;  // 0608700E bra 0x06087012 ; nop
L_06087012:
    c.r[14] += 4;  // 06087012 add #4,r14
    c.r[15] = c.r[14];  // 06087014 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087016 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087018 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608701A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608701C rts ; nop
}

void f_06087030(SH2Context& c) {
    ran[1888] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087030 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087032 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06087034 mov r15,r14
    c.r[1] = ld32(0x06087050u);  // 06087036 mov.l 0x06087050,r1
    c.r[2] = ld32(c.r[1]);  // 06087038 mov.l @r1,r2
    c.r[4] = 0x0u;  // 0608703A mov #0,r4
    { const uint32_t x = c.r[2]; c.pr = 0x06087040u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087040u) return; }  // 0608703C jsr @r2 ; nop
    goto L_06087044;  // 06087040 bra 0x06087044 ; nop
L_06087044:
    c.r[15] = c.r[14];  // 06087044 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087046 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087048 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608704A rts ; nop
}

void f_06087054(SH2Context& c) {
    ran[1889] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06087054 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087056 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087058 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608705A mov r15,r14
    c.r[7] = 0x0u;  // 0608705C mov #0,r7
    c.r[6] = 0x0u;  // 0608705E mov #0,r6
    c.r[5] = 0x0u;  // 06087060 mov #0,r5
    c.r[4] = 0x1u;  // 06087062 mov #1,r4
    c.r[8] = ld32(0x060870B0u);  // 06087064 mov.l 0x060870B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608706Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608706Au) return; }  // 06087066 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608706A tst r0,r0
    if (c.t) { goto L_06087074; }  // 0608706C bt 0x06087074
    c.r[0] = 0xFFFFFFFFu;  // 0608706E mov #-1,r0
    goto L_060870A2;  // 06087070 bra 0x060870A2 ; nop
L_06087074:
    c.r[4] = 0x40u;  // 06087074 mov #64,r4
    c.r[8] = ld32(0x060870B4u);  // 06087076 mov.l 0x060870B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608707Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608707Cu) return; }  // 06087078 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608707C tst r0,r0
    if (c.t) { goto L_06087086; }  // 0608707E bt 0x06087086
    c.r[0] = 0xFFFFFFFFu;  // 06087080 mov #-1,r0
    goto L_060870A2;  // 06087082 bra 0x060870A2 ; nop
L_06087086:
    c.r[8] = ld32(0x060870B8u);  // 06087086 mov.l 0x060870B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608708Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608708Cu) return; }  // 06087088 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608708C tst r0,r0
    if (c.t) { goto L_06087096; }  // 0608708E bt 0x06087096
    c.r[0] = 0xFFFFFFFFu;  // 06087090 mov #-1,r0
    goto L_060870A2;  // 06087092 bra 0x060870A2 ; nop
L_06087096:
    c.r[8] = ld32(0x060870BCu);  // 06087096 mov.l 0x060870BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608709Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608709Cu) return; }  // 06087098 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608709C mov #0,r0
    goto L_060870A2;  // 0608709E bra 0x060870A2 ; nop
L_060870A2:
    c.r[15] = c.r[14];  // 060870A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060870A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060870A6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060870A8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060870AA rts ; nop
}

void f_060870C0(SH2Context& c) {
    ran[1890] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060870C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060870C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060870C4 sts.l pr,@-r15
    c.r[15] -= 4;  // 060870C6 add #-4,r15
    c.r[14] = c.r[15];  // 060870C8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060870CA mov.l r4,@r14
    c.r[8] = ld32(0x060870F4u);  // 060870CC mov.l 0x060870F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060870D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060870D2u) return; }  // 060870CE jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 060870D2 mov.l @r14,r2
    c.r[1] = c.r[0];  // 060870D4 mov r0,r1
    c.r[1] &= c.r[2];  // 060870D6 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060870D8 tst r1,r1
    c.r[1] = c.t;  // 060870DA movt r1
    c.r[3] = 0x1u;  // 060870DC mov #1,r3
    c.r[1] ^= c.r[3];  // 060870DE xor r3,r1
    c.r[0] = c.r[1];  // 060870E0 mov r1,r0
    goto L_060870E6;  // 060870E2 bra 0x060870E6 ; nop
L_060870E6:
    c.r[14] += 4;  // 060870E6 add #4,r14
    c.r[15] = c.r[14];  // 060870E8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060870EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060870EC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060870EE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060870F0 rts ; nop
}

void f_060870F8(SH2Context& c) {
    ran[1891] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060870F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060870FA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060870FC sts.l pr,@-r15
    c.r[15] -= 8;  // 060870FE add #-8,r15
    c.r[14] = c.r[15];  // 06087100 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06087102 mov.l r4,@r14
    c.r[1] = 0x0u;  // 06087104 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06087106 mov.l r1,@(4,r14)
L_06087108:
    c.r[1] = ld32(c.r[14] + 4);  // 06087108 mov.l @(4,r14),r1
    c.r[2] = ld32(0x06087148u);  // 0608710A mov.l 0x06087148,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608710C cmp/gt r2,r1
    if (!c.t) { goto L_06087114; }  // 0608710E bf 0x06087114
    goto L_06087134;  // 06087110 bra 0x06087134 ; nop
L_06087114:
    c.r[4] = ld32(c.r[14]);  // 06087114 mov.l @r14,r4
    c.r[8] = ld32(0x0608714Cu);  // 06087116 mov.l 0x0608714C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608711Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608711Cu) return; }  // 06087118 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608711C tst r0,r0
    if (c.t) { goto L_06087126; }  // 0608711E bt 0x06087126
    c.r[0] = 0x0u;  // 06087120 mov #0,r0
    goto L_0608713A;  // 06087122 bra 0x0608713A ; nop
L_06087126:
    c.r[2] = ld32(c.r[14] + 4);  // 06087126 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06087128 mov r2,r1
    c.r[1] += 1;  // 0608712A add #1,r1
    c.r[2] = c.r[1];  // 0608712C mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608712E mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_06087108;  // 06087130 bra 0x06087108 ; nop
L_06087134:
    c.r[0] = 0xFFFFFFFFu;  // 06087134 mov #-1,r0
    goto L_0608713A;  // 06087136 bra 0x0608713A ; nop
L_0608713A:
    c.r[14] += 8;  // 0608713A add #8,r14
    c.r[15] = c.r[14];  // 0608713C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608713E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087140 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06087142 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06087144 rts ; nop
}

void f_06087150(SH2Context& c) {
    ran[1892] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06087150 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087152 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087154 sts.l pr,@-r15
    c.r[15] -= 20;  // 06087156 add #-20,r15
    c.r[14] = c.r[15];  // 06087158 mov r15,r14
    c.r[1] = c.r[14];  // 0608715A mov r14,r1
    c.r[1] += 8;  // 0608715C add #8,r1
    c.r[4] = c.r[1];  // 0608715E mov r1,r4
    c.r[8] = ld32(0x060871C8u);  // 06087160 mov.l 0x060871C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06087166u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087166u) return; }  // 06087162 jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 06087166 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 06087168 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608716A tst r1,r1
    if (c.t) { goto L_06087174; }  // 0608716C bt 0x06087174
    c.r[0] = 0xFFFFFFFFu;  // 0608716E mov #-1,r0
    goto L_060871B8;  // 06087170 bra 0x060871B8 ; nop
L_06087174:
    c.r[1] = c.r[14];  // 06087174 mov r14,r1
    c.r[2] = c.r[14];  // 06087176 mov r14,r2
    c.r[2] += 8;  // 06087178 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608717A mov.b @r2,r1
    c.r[2] = 0xFu;  // 0608717C mov #15,r2
    c.r[2] &= c.r[1];  // 0608717E and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06087180 extu.b r2,r1
    st32(c.r[14] + 4, c.r[1]);  // 06087182 mov.l r1,@(4,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 06087184 mov.l @(4,r14),r0
    c.r[1] = 0x6u;  // 06087186 mov #6,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06087188 cmp/ge r1,r0
    if (!c.t) { goto L_060871A0; }  // 0608718A bf 0x060871A0
    c.r[1] = 0x7u;  // 0608718C mov #7,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0608718E cmp/gt r1,r0
    if (!c.t) { goto L_0608719A; }  // 06087190 bf 0x0608719A
    c.t = c.r[0] == 0xAu;  // 06087192 cmp/eq #10,r0
    if (c.t) { goto L_0608719A; }  // 06087194 bt 0x0608719A
    goto L_060871A0;  // 06087196 bra 0x060871A0 ; nop
L_0608719A:
    c.r[0] = 0xFFFFFFFFu;  // 0608719A mov #-1,r0
    goto L_060871B8;  // 0608719C bra 0x060871B8 ; nop
L_060871A0:
    c.r[4] = 0x20u;  // 060871A0 mov #32,r4
    c.r[8] = ld32(0x060871CCu);  // 060871A2 mov.l 0x060871CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060871A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060871A8u) return; }  // 060871A4 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 060871A8 tst r0,r0
    if (c.t) { goto L_060871B2; }  // 060871AA bt 0x060871B2
    c.r[0] = 0xFFFFFFFFu;  // 060871AC mov #-1,r0
    goto L_060871B8;  // 060871AE bra 0x060871B8 ; nop
L_060871B2:
    c.r[0] = 0x0u;  // 060871B2 mov #0,r0
    goto L_060871B8;  // 060871B4 bra 0x060871B8 ; nop
L_060871B8:
    c.r[14] += 20;  // 060871B8 add #20,r14
    c.r[15] = c.r[14];  // 060871BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060871BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060871BE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060871C0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060871C2 rts ; nop
}

void f_060871D0(SH2Context& c) {
    ran[1893] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060871D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060871D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060871D4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060871D6 mov r15,r14
    c.r[5] = 0xFFFFFFFFu;  // 060871D8 mov #-1,r5
    c.r[4] = 0x17u;  // 060871DA mov #23,r4
    c.r[8] = ld32(0x060871F8u);  // 060871DC mov.l 0x060871F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060871E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060871E2u) return; }  // 060871DE jsr @r8 ; nop
    c.r[8] = ld32(0x060871FCu);  // 060871E2 mov.l 0x060871FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060871E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060871E8u) return; }  // 060871E4 jsr @r8 ; nop
    goto L_060871EC;  // 060871E8 bra 0x060871EC ; nop
L_060871EC:
    c.r[15] = c.r[14];  // 060871EC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060871EE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060871F0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060871F2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060871F4 rts ; nop
}

void f_06087200(SH2Context& c) {
    ran[1894] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06087200 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06087202 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06087204 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087206 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087208 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608720A mov r15,r14
    c.r[1] = ld32(0x06087274u);  // 0608720C mov.l 0x06087274,r1
    c.r[4] = c.r[1];  // 0608720E mov r1,r4
    c.r[10] = ld32(0x06087278u);  // 06087210 mov.l 0x06087278,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06087216u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087216u) return; }  // 06087212 jsr @r10 ; nop
    c.r[1] = ld32(0x0608727Cu);  // 06087216 mov.l 0x0608727C,r1
    st32(c.r[1], c.r[0]);  // 06087218 mov.l r0,@r1
    c.r[8] = 0x0u;  // 0608721A mov #0,r8
L_0608721C:
    goto L_06087224;  // 0608721C bra 0x06087224 ; nop
L_06087224:
    c.r[1] = ld32(0x06087280u);  // 06087224 mov.l 0x06087280,r1
    c.r[2] = ld32(c.r[1]);  // 06087226 mov.l @r1,r2
    c.r[4] = 0x0u;  // 06087228 mov #0,r4
    { const uint32_t x = c.r[2]; c.pr = 0x0608722Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608722Eu) return; }  // 0608722A jsr @r2 ; nop
    c.r[9] = c.r[0];  // 0608722E mov r0,r9
    c.t = (int32_t)c.r[9] >= 0;  // 06087230 cmp/pz r9
    if (c.t) { goto L_06087238; }  // 06087232 bt 0x06087238
    goto L_0608724A;  // 06087234 bra 0x0608724A ; nop
L_06087238:
    c.r[1] = c.r[8];  // 06087238 mov r8,r1
    c.r[8] += 1;  // 0608723A add #1,r8
    c.r[2] = ld32(0x06087284u);  // 0608723C mov.l 0x06087284,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608723E cmp/gt r2,r1
    if (!c.t) { goto L_06087246; }  // 06087240 bf 0x06087246
    goto L_0608724A;  // 06087242 bra 0x0608724A ; nop
L_06087246:
    SH2_POLL(c); goto L_0608721C;  // 06087246 bra 0x0608721C ; nop
L_0608724A:
    c.r[1] = ld32(0x0608727Cu);  // 0608724A mov.l 0x0608727C,r1
    c.r[2] = ld32(c.r[1]);  // 0608724C mov.l @r1,r2
    c.r[4] = c.r[2];  // 0608724E mov r2,r4
    c.r[10] = ld32(0x06087278u);  // 06087250 mov.l 0x06087278,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06087256u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087256u) return; }  // 06087252 jsr @r10 ; nop
    c.r[1] = ld32(0x06087288u);  // 06087256 mov.l 0x06087288,r1
    c.r[10] = ld32(c.r[1]);  // 06087258 mov.l @r1,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0608725Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608725Eu) return; }  // 0608725A jsr @r10 ; nop
    goto L_06087262;  // 0608725E bra 0x06087262 ; nop
L_06087262:
    c.r[15] = c.r[14];  // 06087262 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087264 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087266 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06087268 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608726A mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608726C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608726E rts ; nop
}

void f_0608728C(SH2Context& c) {
    ran[1895] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608728C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608728E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087290 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087292 sts.l pr,@-r15
    c.r[15] -= 4;  // 06087294 add #-4,r15
    c.r[14] = c.r[15];  // 06087296 mov r15,r14
    c.r[8] = c.r[4];  // 06087298 mov r4,r8
    c.r[9] = ld32(0x060872D0u);  // 0608729A mov.l 0x060872D0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060872A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060872A0u) return; }  // 0608729C jsr @r9 ; nop
    st32(c.r[14], c.r[0]);  // 060872A0 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 060872A2 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060872CEu);  // 060872A4 mov.w 0x060872CE,r2
    c.r[1] &= c.r[2];  // 060872A6 and r2,r1
    st32(c.r[14], c.r[1]);  // 060872A8 mov.l r1,@r14
    c.r[1] = c.r[8];  // 060872AA mov r8,r1
    c.r[1] <<= 2;  // 060872AC shll2 r1
    c.r[1] <<= 2;  // 060872AE shll2 r1
    c.r[2] = ld32(c.r[14]);  // 060872B0 mov.l @r14,r2
    c.r[1] |= c.r[2];  // 060872B2 or r2,r1
    st32(c.r[14], c.r[1]);  // 060872B4 mov.l r1,@r14
    c.r[4] = ld32(c.r[14]);  // 060872B6 mov.l @r14,r4
    c.r[9] = ld32(0x060872D4u);  // 060872B8 mov.l 0x060872D4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060872BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060872BEu) return; }  // 060872BA jsr @r9 ; nop
    c.r[14] += 4;  // 060872BE add #4,r14
    c.r[15] = c.r[14];  // 060872C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060872C2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060872C4 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060872C6 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060872C8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060872CA rts ; nop
}

void f_060872D8(SH2Context& c) {
    ran[1896] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060872D8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060872DA mov r15,r14
    c.r[1] = c.r[4];  // 060872DC mov r4,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 060872DE ldc r1,sr
    c.r[15] = c.r[14];  // 060872E0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060872E2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060872E4 rts ; nop
}

void f_060872E8(SH2Context& c) {
    ran[1897] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060872E8 mov.l r14,@-r15
    c.r[15] -= 4;  // 060872EA add #-4,r15
    c.r[14] = c.r[15];  // 060872EC mov r15,r14
    c.r[1] = sh2_get_sr(c);  // 060872EE stc sr,r1
    st32(c.r[14], c.r[1]);  // 060872F0 mov.l r1,@r14
    c.r[0] = ld32(c.r[14]);  // 060872F2 mov.l @r14,r0
    goto L_060872F8;  // 060872F4 bra 0x060872F8 ; nop
L_060872F8:
    c.r[14] += 4;  // 060872F8 add #4,r14
    c.r[15] = c.r[14];  // 060872FA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060872FC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060872FE rts ; nop
}

void f_06087304(SH2Context& c) {
    ran[1898] = 1;
    c.r[0] = c.r[15];  // 06087304 mov r15,r0
    { const uint32_t x = c.pr; c.r[15] = c.r[4]; c.pc = x; return; }  // 06087306 rts ; mov r4,r15
}

void f_06087318(SH2Context& c) {
    ran[1899] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06087318 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608731A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608731C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608731E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06087320 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06087322 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087324 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087326 sts.l pr,@-r15
    c.r[15] -= 8;  // 06087328 add #-8,r15
    c.r[14] = c.r[15];  // 0608732A mov r15,r14
    c.r[8] = c.r[4];  // 0608732C mov r4,r8
    c.r[1] = 0xFu;  // 0608732E mov #15,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06087330 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] = c.r[5]; if (k) { goto L_0608733A; } }  // 06087332 bf/s 0x0608733A ; mov r5,r9
    c.r[0] = 0x3u; goto L_06087560;  // 06087336 bra 0x06087560 ; mov #3,r0
L_0608733A:
    c.r[4] = ld32(0x06087578u);  // 0608733A mov.l 0x06087578,r4
    c.r[0] = ld32(0x0608757Cu);  // 0608733C mov.l 0x0608757C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087342u; c.r[5] = 0x27u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087342u) return; }  // 0608733E jsr @r0 ; mov #39,r5
    c.r[1] = c.r[8];  // 06087342 mov r8,r1
    c.r[1] <<= 2;  // 06087344 shll2 r1
    c.r[1] += c.r[1];  // 06087346 add r1,r1
    c.r[6] = c.r[0];  // 06087348 mov r0,r6
    c.r[6] += c.r[1];  // 0608734A add r1,r6
    c.r[7] = ld32(0x06087580u);  // 0608734C mov.l 0x06087580,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608734E mov.b @(r0,r1),r2
    c.r[10] = ld32(0x06087584u);  // 06087350 mov.l 0x06087584,r10
    c.r[2] = c.r[2] & 0xFFu;  // 06087352 extu.b r2,r2
    c.r[2] <<= 8;  // 06087354 shll8 r2
    c.r[2] <<= 2;  // 06087356 shll2 r2
    c.r[2] += c.r[2];  // 06087358 add r2,r2
    c.r[2] <<= 2;  // 0608735A shll2 r2
    st32(c.r[7], c.r[2]);  // 0608735C mov.l r2,@r7
    c.r[1] = c.r[6];  // 0608735E mov r6,r1
    c.r[1] += 1;  // 06087360 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06087362 mov.b @r1,r3
    c.r[6] += 2;  // 06087364 add #2,r6
    c.r[3] = c.r[3] & 0xFFu;  // 06087366 extu.b r3,r3
    c.r[3] <<= 2;  // 06087368 shll2 r3
    c.r[3] += c.r[3];  // 0608736A add r3,r3
    c.r[3] <<= 2;  // 0608736C shll2 r3
    c.r[3] += c.r[2];  // 0608736E add r2,r3
    st32(c.r[7], c.r[3]);  // 06087370 mov.l r3,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06087372 mov.b @r6,r1
    c.r[2] = ld32(0x06087588u);  // 06087374 mov.l 0x06087588,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06087376 extu.b r1,r1
    c.r[1] >>= 2;  // 06087378 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0608737A shlr r1
    c.r[3] += c.r[1];  // 0608737C add r1,r3
    st32(c.r[7], c.r[3]);  // 0608737E mov.l r3,@r7
    c.r[1] = ld32(0x0608758Cu);  // 06087380 mov.l 0x0608758C,r1
    st32(c.r[1], c.r[9]);  // 06087382 mov.l r9,@r1
    c.r[1] = 0x0u;  // 06087384 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06087386 mov.l r1,@r2
    c.r[2] = ld32(0x06087590u);  // 06087388 mov.l 0x06087590,r2
    c.r[1] = 0x0u;  // 0608738A mov #0,r1
    st16(c.r[2], c.r[1]);  // 0608738C mov.w r1,@r2
    c.r[9] = 0x8u;  // 0608738E mov #8,r9
    c.r[8] = c.r[9] & 0xFFu;  // 06087390 extu.b r9,r8
L_06087392:
    c.r[6] = 0x0u;  // 06087392 mov #0,r6
    c.r[5] = c.r[8];  // 06087394 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0608739Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608739Au) return; }  // 06087396 jsr @r10 ; mov #0,r4
    c.r[6] = 0x0u;  // 0608739A mov #0,r6
    c.r[5] = c.r[8];  // 0608739C mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060873A2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873A2u) return; }  // 0608739E jsr @r10 ; mov #1,r4
    c.r[9] += 1;  // 060873A2 add #1,r9
    c.r[1] = 0xFu;  // 060873A4 mov #15,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060873A6 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_06087392; } }  // 060873A8 bf/s 0x06087392 ; extu.b r9,r8
    c.r[4] = ld32(0x06087594u);  // 060873AC mov.l 0x06087594,r4
    c.r[12] = ld32(0x06087598u);  // 060873AE mov.l 0x06087598,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060873B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873B4u) return; }  // 060873B0 jsr @r12 ; nop
    c.r[12] = 0x1u;  // 060873B4 mov #1,r12
    c.r[13] = ld32(0x0608759Cu);  // 060873B6 mov.l 0x0608759C,r13
    st8(c.r[13], c.r[12]);  // 060873B8 mov.b r12,@r13
    c.r[6] = ld32(0x060875A0u);  // 060873BA mov.l 0x060875A0,r6
    c.r[5] = ld32(0x060875A4u);  // 060873BC mov.l 0x060875A4,r5
    c.r[4] = ld32(0x060875A8u);  // 060873BE mov.l 0x060875A8,r4
    c.r[13] = ld32(0x060875ACu);  // 060873C0 mov.l 0x060875AC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060873C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873C6u) return; }  // 060873C2 jsr @r13 ; nop
    c.r[12] = ld32(0x060875B0u);  // 060873C6 mov.l 0x060875B0,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060873CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873CCu) return; }  // 060873C8 jsr @r12 ; nop
    c.r[12] = 0x0u;  // 060873CC mov #0,r12
    c.r[13] = ld32(0x0608759Cu);  // 060873CE mov.l 0x0608759C,r13
    c.r[9] = ld32(0x060875B4u);  // 060873D0 mov.l 0x060875B4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060873D6u; st8(c.r[13], c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873D6u) return; }  // 060873D2 jsr @r9 ; mov.b r12,@r13
    c.r[11] = ld32(0x060875B8u);  // 060873D6 mov.l 0x060875B8,r11
    c.r[7] = ld32(0x060875A0u);  // 060873D8 mov.l 0x060875A0,r7
    c.r[6] = 0x4u;  // 060873DA mov #4,r6
    c.r[4] = ld32(0x060875A8u);  // 060873DC mov.l 0x060875A8,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060873E2u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873E2u) return; }  // 060873DE jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060873E6u; c.r[12] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873E6u) return; }  // 060873E2 jsr @r9 ; mov #-1,r12
    c.r[1] = ld32(0x060875BCu);  // 060873E6 mov.l 0x060875BC,r1
    c.r[5] = ld32(0x060875A0u);  // 060873E8 mov.l 0x060875A0,r5
    c.r[4] = ld32(0x060875A8u);  // 060873EA mov.l 0x060875A8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060873F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873F0u) return; }  // 060873EC jsr @r1 ; nop
    c.r[8] = ld32(0x060875C0u);  // 060873F0 mov.l 0x060875C0,r8
    c.r[5] = 0xCu;  // 060873F2 mov #12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060873F8u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060873F8u) return; }  // 060873F4 jsr @r8 ; mov #64,r4
    st32(c.r[14], c.r[0]);  // 060873F8 mov.l r0,@r14
    c.r[5] = 0x18u;  // 060873FA mov #24,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06087400u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087400u) return; }  // 060873FC jsr @r8 ; mov #64,r4
    c.r[1] = ld32(0x060875C4u);  // 06087400 mov.l 0x060875C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087406u; st32(c.r[14] + 4, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087406u) return; }  // 06087402 jsr @r1 ; mov.l r0,@(4,r14)
    c.r[6] = 0x1u;  // 06087406 mov #1,r6
    c.r[5] = 0x0u;  // 06087408 mov #0,r5
    c.r[13] = ld32(0x060875C8u);  // 0608740A mov.l 0x060875C8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06087410u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087410u) return; }  // 0608740C jsr @r13 ; mov #0,r4
    c.r[1] = ld32(0x060875CCu);  // 06087410 mov.l 0x060875CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087416u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087416u) return; }  // 06087412 jsr @r1 ; mov #2,r4
    c.r[4] = ld32(0x060875D0u);  // 06087416 mov.l 0x060875D0,r4
    c.r[1] = ld32(0x060875D4u);  // 06087418 mov.l 0x060875D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608741Eu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608741Eu) return; }  // 0608741A jsr @r1 ; mov #0,r5
    c.r[10] = ld32(0x060875D8u);  // 0608741E mov.l 0x060875D8,r10
    c.r[7] = c.r[10];  // 06087420 mov r10,r7
    c.r[6] = 0x4u;  // 06087422 mov #4,r6
    c.r[4] = ld32(0x060875DCu);  // 06087424 mov.l 0x060875DC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0608742Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608742Au) return; }  // 06087426 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608742Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608742Eu) return; }  // 0608742A jsr @r9 ; nop
    c.r[7] = c.r[10];  // 0608742E mov r10,r7
    c.r[6] = 0x4u;  // 06087430 mov #4,r6
    c.r[4] = ld32(0x060875E0u);  // 06087432 mov.l 0x060875E0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087438u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087438u) return; }  // 06087434 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608743Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608743Cu) return; }  // 06087438 jsr @r9 ; nop
    c.r[7] = c.r[10];  // 0608743C mov r10,r7
    c.r[6] = 0x4u;  // 0608743E mov #4,r6
    c.r[4] = ld32(0x060875E4u);  // 06087440 mov.l 0x060875E4,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087446u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087446u) return; }  // 06087442 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608744Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608744Au) return; }  // 06087446 jsr @r9 ; nop
    c.r[7] = c.r[10];  // 0608744A mov r10,r7
    c.r[6] = 0x4u;  // 0608744C mov #4,r6
    c.r[4] = ld32(0x060875E8u);  // 0608744E mov.l 0x060875E8,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087454u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087454u) return; }  // 06087450 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06087458u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087458u) return; }  // 06087454 jsr @r9 ; nop
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087576u);  // 06087458 mov.w 0x06087576,r7
    c.r[6] = 0x4u;  // 0608745A mov #4,r6
    c.r[4] = ld32(0x060875ECu);  // 0608745C mov.l 0x060875EC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087462u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087462u) return; }  // 0608745E jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06087466u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087466u) return; }  // 06087462 jsr @r9 ; nop
    c.r[0] = ld32(0x060875F0u);  // 06087466 mov.l 0x060875F0,r0
    c.r[5] = 0x3u;  // 06087468 mov #3,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608746Eu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608746Eu) return; }  // 0608746A jsr @r0 ; mov #3,r4
    c.r[0] = ld32(0x060875F4u);  // 0608746E mov.l 0x060875F4,r0
    c.r[5] = 0x1u;  // 06087470 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06087476u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087476u) return; }  // 06087472 jsr @r0 ; mov #1,r4
    c.r[0] = ld32(0x060875F8u);  // 06087476 mov.l 0x060875F8,r0
    c.r[6] = 0x1u;  // 06087478 mov #1,r6
    c.r[5] = 0x4u;  // 0608747A mov #4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06087480u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087480u) return; }  // 0608747C jsr @r0 ; mov #1,r4
    c.r[1] = ld32(0x060875FCu);  // 06087480 mov.l 0x060875FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087486u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087486u) return; }  // 06087482 jsr @r1 ; nop
    c.r[5] = ld32(c.r[14] + 4);  // 06087486 mov.l @(4,r14),r5
    c.r[0] = ld32(0x06087600u);  // 06087488 mov.l 0x06087600,r0
    c.r[4] = ld32(c.r[14]);  // 0608748A mov.l @r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06087490u; c.r[6] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087490u) return; }  // 0608748C jsr @r0 ; mov #64,r6
    c.t = (int32_t)c.r[0] > (int32_t)c.r[12];  // 06087490 cmp/gt r12,r0
    if (!c.t) { goto L_0608749E; }  // 06087492 bf 0x0608749E
    c.r[5] = ld32(0x06087604u);  // 06087494 mov.l 0x06087604,r5
    c.r[4] = ld32(0x06087608u);  // 06087496 mov.l 0x06087608,r4
    c.r[0] = ld32(0x0608760Cu);  // 06087498 mov.l 0x0608760C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608749Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608749Eu) return; }  // 0608749A jsr @r0 ; nop
L_0608749E:
    c.r[1] = ld32(0x06087610u);  // 0608749E mov.l 0x06087610,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060874A4u; c.r[12] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874A4u) return; }  // 060874A0 jsr @r1 ; mov #1,r12
    c.r[1] = ld32(0x06087614u);  // 060874A4 mov.l 0x06087614,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060874AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874AAu) return; }  // 060874A6 jsr @r1 ; nop
    c.r[1] = ld32(0x06087618u);  // 060874AA mov.l 0x06087618,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060874B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874B0u) return; }  // 060874AC jsr @r1 ; nop
    c.r[8] = ld32(0x0608761Cu);  // 060874B0 mov.l 0x0608761C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060874B6u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874B6u) return; }  // 060874B2 jsr @r8 ; mov.l @r14,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060874BAu; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874BAu) return; }  // 060874B6 jsr @r8 ; mov.l @(4,r14),r4
    c.r[13] = ld32(0x0608759Cu);  // 060874BA mov.l 0x0608759C,r13
    st8(c.r[13], c.r[12]);  // 060874BC mov.b r12,@r13
    c.r[6] = ld32(0x060875A0u);  // 060874BE mov.l 0x060875A0,r6
    c.r[5] = ld32(0x060875A8u);  // 060874C0 mov.l 0x060875A8,r5
    c.r[4] = ld32(0x060875A4u);  // 060874C2 mov.l 0x060875A4,r4
    c.r[13] = ld32(0x060875ACu);  // 060874C4 mov.l 0x060875AC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060874CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874CAu) return; }  // 060874C6 jsr @r13 ; nop
    c.r[12] = ld32(0x060875B0u);  // 060874CA mov.l 0x060875B0,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060874D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874D0u) return; }  // 060874CC jsr @r12 ; nop
    c.r[12] = 0x0u;  // 060874D0 mov #0,r12
    c.r[13] = ld32(0x0608759Cu);  // 060874D2 mov.l 0x0608759C,r13
    st8(c.r[13], c.r[12]);  // 060874D4 mov.b r12,@r13
    c.r[6] = 0xFFFFFFFFu;  // 060874D6 mov #-1,r6
    c.r[5] = 0x0u;  // 060874D8 mov #0,r5
    c.r[13] = ld32(0x060875C8u);  // 060874DA mov.l 0x060875C8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060874E0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874E0u) return; }  // 060874DC jsr @r13 ; mov #0,r4
    c.r[1] = ld32(0x06087620u);  // 060874E0 mov.l 0x06087620,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060874E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874E6u) return; }  // 060874E2 jsr @r1 ; nop
    c.r[4] = ld32(0x06087624u);  // 060874E6 mov.l 0x06087624,r4
    c.r[12] = ld32(0x06087598u);  // 060874E8 mov.l 0x06087598,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060874EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874EEu) return; }  // 060874EA jsr @r12 ; nop
    { const uint32_t x = c.r[9]; c.pr = 0x060874F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874F2u) return; }  // 060874EE jsr @r9 ; nop
    c.r[7] = c.r[10];  // 060874F2 mov r10,r7
    c.r[6] = 0x4u;  // 060874F4 mov #4,r6
    c.r[4] = ld32(0x060875DCu);  // 060874F6 mov.l 0x060875DC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060874FCu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060874FCu) return; }  // 060874F8 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06087500u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087500u) return; }  // 060874FC jsr @r9 ; nop
    c.r[7] = c.r[10];  // 06087500 mov r10,r7
    c.r[6] = 0x4u;  // 06087502 mov #4,r6
    c.r[4] = ld32(0x060875E0u);  // 06087504 mov.l 0x060875E0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0608750Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608750Au) return; }  // 06087506 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608750Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608750Eu) return; }  // 0608750A jsr @r9 ; nop
    c.r[7] = c.r[10];  // 0608750E mov r10,r7
    c.r[6] = 0x4u;  // 06087510 mov #4,r6
    c.r[4] = ld32(0x060875E4u);  // 06087512 mov.l 0x060875E4,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087518u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087518u) return; }  // 06087514 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608751Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608751Cu) return; }  // 06087518 jsr @r9 ; nop
    c.r[7] = c.r[10];  // 0608751C mov r10,r7
    c.r[6] = 0x4u;  // 0608751E mov #4,r6
    c.r[4] = ld32(0x060875E8u);  // 06087520 mov.l 0x060875E8,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087526u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087526u) return; }  // 06087522 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608752Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608752Au) return; }  // 06087526 jsr @r9 ; nop
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087576u);  // 0608752A mov.w 0x06087576,r7
    c.r[6] = 0x4u;  // 0608752C mov #4,r6
    c.r[4] = ld32(0x060875ECu);  // 0608752E mov.l 0x060875EC,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06087534u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087534u) return; }  // 06087530 jsr @r11 ; mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06087538u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087538u) return; }  // 06087534 jsr @r9 ; nop
    c.r[1] = ld32(0x06087628u);  // 06087538 mov.l 0x06087628,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608753Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608753Eu) return; }  // 0608753A jsr @r1 ; nop
    c.r[0] = ld32(0x0608762Cu);  // 0608753E mov.l 0x0608762C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087544u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087544u) return; }  // 06087540 jsr @r0 ; nop
    c.r[1] = ld32(0x06087630u);  // 06087544 mov.l 0x06087630,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608754Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608754Au) return; }  // 06087546 jsr @r1 ; nop
    c.r[1] = ld32(0x06087634u);  // 0608754A mov.l 0x06087634,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087550u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087550u) return; }  // 0608754C jsr @r1 ; nop
    c.r[1] = ld32(0x06087638u);  // 06087550 mov.l 0x06087638,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087556u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087556u) return; }  // 06087552 jsr @r1 ; nop
    c.r[1] = ld32(0x0608763Cu);  // 06087556 mov.l 0x0608763C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608755Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608755Cu) return; }  // 06087558 jsr @r1 ; nop
    c.r[1] = ld32(0x06087588u);  // 0608755C mov.l 0x06087588,r1
    c.r[0] = ld32(c.r[1]);  // 0608755E mov.l @r1,r0
L_06087560:
    c.r[14] += 8;  // 06087560 add #8,r14
    c.r[15] = c.r[14];  // 06087562 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087564 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087566 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06087568 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608756A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608756C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608756E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06087570 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06087572 rts ; mov.l @r15+,r8
}

void f_06087640(SH2Context& c) {
    ran[1900] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087640 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087642 sts.l pr,@-r15
    c.r[0] = ld32(0x06087654u);  // 06087644 mov.l 0x06087654,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608764Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608764Au) return; }  // 06087646 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0608764A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608764C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608764E rts ; mov.l @r15+,r14
}

void f_06087658(SH2Context& c) {
    ran[1901] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087658 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608765A sts.l pr,@-r15
    c.r[0] = ld32(0x0608766Cu);  // 0608765C mov.l 0x0608766C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087662u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087662u) return; }  // 0608765E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06087662 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087664 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06087666 rts ; mov.l @r15+,r14
}

void f_06087670(SH2Context& c) {
    ran[1902] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087670 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087672 sts.l pr,@-r15
    c.r[1] = ld32(0x06087684u);  // 06087674 mov.l 0x06087684,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608767Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608767Au) return; }  // 06087676 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0608767A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608767C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608767E rts ; mov.l @r15+,r14
}

void f_06087688(SH2Context& c) {
    ran[1903] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087688 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608768A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608768C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 0608768E rts ; mov #1,r0
}

void f_06087694(SH2Context& c) {
    ran[1904] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087694 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06087696 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087698 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608769A rts ; nop
}

void f_060876A0(SH2Context& c) {
    ran[1905] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060876A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060876A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060876A4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060876A6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060876A8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060876AA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060876AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060876AE sts.l pr,@-r15
    c.r[15] -= 12;  // 060876B0 add #-12,r15
    c.r[14] = c.r[15];  // 060876B2 mov r15,r14
    c.r[1] = ld32(0x060877B0u);  // 060876B4 mov.l 0x060877B0,r1
    c.r[1] = ld32(c.r[1]);  // 060876B6 mov.l @r1,r1
    c.r[13] = 0x0u;  // 060876B8 mov #0,r13
    st32(c.r[14] + 8, c.r[1]);  // 060876BA mov.l r1,@(8,r14)
    st32(c.r[14], c.r[13]);  // 060876BC mov.l r13,@r14
    c.r[1] = ld32(0x060877B4u);  // 060876BE mov.l 0x060877B4,r1
    c.r[5] = ld32(c.r[1]);  // 060876C0 mov.l @r1,r5
    c.r[10] = 0x0u;  // 060876C2 mov #0,r10
    c.r[1] = ld32(0x060877B8u);  // 060876C4 mov.l 0x060877B8,r1
    c.r[0] = ld32(0x060877BCu);  // 060876C6 mov.l 0x060877BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060876CCu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060876CCu) return; }  // 060876C8 jsr @r0 ; mov.l @r1,r4
    st32(c.r[14] + 4, c.r[0]);  // 060876CC mov.l r0,@(4,r14)
    c.r[6] = ld32(0x060877C0u);  // 060876CE mov.l 0x060877C0,r6
    c.r[1] = ld32(0x060877C4u);  // 060876D0 mov.l 0x060877C4,r1
    c.r[5] = 0x2u;  // 060876D2 mov #2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060876D8u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060876D8u) return; }  // 060876D4 jsr @r1 ; mov #48,r4
    c.r[6] = ld32(0x060877C8u);  // 060876D8 mov.l 0x060877C8,r6
    c.r[1] = ld32(0x060877CCu);  // 060876DA mov.l 0x060877CC,r1
    c.r[5] = 0x2u;  // 060876DC mov #2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060876E2u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060876E2u) return; }  // 060876DE jsr @r1 ; mov #48,r4
    c.r[1] = ld32(0x060877D0u);  // 060876E2 mov.l 0x060877D0,r1
    c.r[5] = 0x0u;  // 060876E4 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060876EAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060876EAu) return; }  // 060876E6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060877D4u);  // 060876EA mov.l 0x060877D4,r1
    c.r[5] = 0x0u;  // 060876EC mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060876F2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060876F2u) return; }  // 060876EE jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060877D8u);  // 060876F2 mov.l 0x060877D8,r1
    c.r[1] = ld32(c.r[1]);  // 060876F4 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060877A6u);  // 060876F6 mov.w 0x060877A6,r2
    c.r[2] -= c.r[1];  // 060876F8 sub r1,r2
    c.r[6] = c.r[2];  // 060876FA mov r2,r6
    c.t = c.r[6] >> 31; c.r[6] = c.r[6] << 1 | c.t;  // 060876FC rotl r6
    c.r[6] = c.t;  // 060876FE movt r6
    c.r[6] += c.r[2];  // 06087700 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06087702 shar r6
    c.r[1] = ld32(0x060877DCu);  // 06087704 mov.l 0x060877DC,r1
    c.r[1] = ld32(c.r[1]);  // 06087706 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060877A8u);  // 06087708 mov.w 0x060877A8,r2
    c.r[2] -= c.r[1];  // 0608770A sub r1,r2
    c.r[7] = c.r[2];  // 0608770C mov r2,r7
    c.t = c.r[7] >> 31; c.r[7] = c.r[7] << 1 | c.t;  // 0608770E rotl r7
    c.r[7] = c.t;  // 06087710 movt r7
    c.r[7] += c.r[2];  // 06087712 add r2,r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 06087714 shar r7
    c.t = (int32_t)c.r[7] >= 0;  // 06087716 cmp/pz r7
    if (c.t) { goto L_0608771C; }  // 06087718 bt 0x0608771C
    c.r[7] = 0x0u;  // 0608771A mov #0,r7
L_0608771C:
    c.r[8] = ld32(0x060877E0u);  // 0608771C mov.l 0x060877E0,r8
    c.r[0] = ld32(0x060877E4u);  // 0608771E mov.l 0x060877E4,r0
    c.r[4] = ld32(c.r[8]);  // 06087720 mov.l @r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06087726u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087726u) return; }  // 06087722 jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x060877E8u);  // 06087726 mov.l 0x060877E8,r1
    c.r[5] = ld32(c.r[1]);  // 06087728 mov.l @r1,r5
    c.r[0] = ld32(0x060877ECu);  // 0608772A mov.l 0x060877EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087730u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087730u) return; }  // 0608772C jsr @r0 ; mov.l @r8,r4
    c.r[1] = ld32(0x060877F0u);  // 06087730 mov.l 0x060877F0,r1
    c.r[5] = ld32(c.r[1]);  // 06087732 mov.l @r1,r5
    c.r[0] = ld32(0x060877F4u);  // 06087734 mov.l 0x060877F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608773Au; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608773Au) return; }  // 06087736 jsr @r0 ; mov.l @r8,r4
    c.r[1] = ld32(0x060877F8u);  // 0608773A mov.l 0x060877F8,r1
    c.r[0] = ld32(0x060877FCu);  // 0608773C mov.l 0x060877FC,r0
    c.r[6] = 0xFFFFFFFEu;  // 0608773E mov #-2,r6
    c.r[4] = ld32(c.r[1]);  // 06087740 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06087746u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087746u) return; }  // 06087742 jsr @r0 ; mov #0,r5
    c.r[0] = ld32(0x06087800u);  // 06087746 mov.l 0x06087800,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608774Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608774Cu) return; }  // 06087748 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(0x06087804u);  // 0608774C mov.l 0x06087804,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087752u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087752u) return; }  // 0608774E jsr @r1 ; nop
    c.r[8] = ld32(0x06087808u);  // 06087752 mov.l 0x06087808,r8
    c.r[5] = 0x1u;  // 06087754 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608775Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608775Au) return; }  // 06087756 jsr @r8 ; mov #1,r4
    c.r[5] = 0x1u;  // 0608775A mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06087760u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087760u) return; }  // 0608775C jsr @r8 ; mov #0,r4
L_06087760:
    c.r[0] = ld32(0x0608780Cu);  // 06087760 mov.l 0x0608780C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087766u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087766u) return; }  // 06087762 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06087766 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06087768 tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 8); if (k) { goto L_06087776; } }  // 0608776A bt/s 0x06087776 ; mov.l @(8,r14),r1
    c.r[1] = 0x3u;  // 0608776E mov #3,r1
    c.r[3] = ld32(0x06087810u);  // 06087770 mov.l 0x06087810,r3
    st32(c.r[3], c.r[1]); goto L_060878E8;  // 06087772 bra 0x060878E8 ; mov.l r1,@r3
L_06087776:
    c.r[1] += 2;  // 06087776 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06087778 mov.w @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060877AAu);  // 0608777A mov.w 0x060877AA,r1
    c.r[1] &= c.r[2];  // 0608777C and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608777E tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_0608778A; } }  // 06087780 bf/s 0x0608778A ; mov #2,r1
    c.r[11] = ld32(0x06087810u);  // 06087784 mov.l 0x06087810,r11
    st32(c.r[11], c.r[1]); goto L_060878E8;  // 06087786 bra 0x060878E8 ; mov.l r1,@r11
L_0608778A:
    c.r[1] = ld32(0x06087814u);  // 0608778A mov.l 0x06087814,r1
    c.r[1] = ld32(c.r[1]);  // 0608778C mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608778E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2] & 0xFFFFu; if (k) { goto L_06087818; } }  // 06087790 bt/s 0x06087818 ; extu.w r2,r1
    c.r[1] = ~c.r[1];  // 06087794 not r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060877ACu);  // 06087796 mov.w 0x060877AC,r3
    c.r[1] &= c.r[3];  // 06087798 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608779A tst r1,r1
    { const bool k = c.t; c.r[3] = 0x1u; if (k) { goto L_06087818; } }  // 0608779C bt/s 0x06087818 ; mov #1,r3
    c.r[11] = ld32(0x06087810u);  // 060877A0 mov.l 0x06087810,r11
    st32(c.r[11], c.r[3]); goto L_060878E8;  // 060877A2 bra 0x060878E8 ; mov.l r3,@r11
L_06087818:
    c.r[1] = ld32(0x06087908u);  // 06087818 mov.l 0x06087908,r1
    c.r[1] = ld32(c.r[1]);  // 0608781A mov.l @r1,r1
    c.r[11] = ld32(c.r[14]);  // 0608781C mov.l @r14,r11
    c.r[1] = ld32(c.r[1]);  // 0608781E mov.l @r1,r1
    c.t = c.r[11] >= c.r[1];  // 06087820 cmp/hs r1,r11
    { const bool k = c.t; c.r[8] = 0xFFFFFFFFu; if (k) { goto L_060878C2; } }  // 06087822 bt/s 0x060878C2 ; mov #-1,r8
    c.r[3] = ld32(0x0608790Cu);  // 06087826 mov.l 0x0608790C,r3
    c.r[5] = ld32(c.r[3]);  // 06087828 mov.l @r3,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[8];  // 0608782A cmp/gt r8,r5
    if (!c.t) { goto L_06087838; }  // 0608782C bf 0x06087838
    c.r[1] = ld32(0x06087910u);  // 0608782E mov.l 0x06087910,r1
    c.r[4] = ld32(c.r[1]);  // 06087830 mov.l @r1,r4
    c.r[1] = ld32(0x06087914u);  // 06087832 mov.l 0x06087914,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087838u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087838u) return; }  // 06087834 jsr @r1 ; nop
L_06087838:
    c.r[1] = ld32(0x06087918u);  // 06087838 mov.l 0x06087918,r1
    c.r[4] = ld32(c.r[1]);  // 0608783A mov.l @r1,r4
    c.r[11] = 0x1u;  // 0608783C mov #1,r11
    c.r[0] = ld32(0x0608791Cu);  // 0608783E mov.l 0x0608791C,r0
    c.r[7] = 0x1u;  // 06087840 mov #1,r7
    c.r[6] = ld32(0x06087920u);  // 06087842 mov.l 0x06087920,r6
    c.r[5] = ld32(0x06087924u);  // 06087844 mov.l 0x06087924,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608784Au; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608784Au) return; }  // 06087846 jsr @r0 ; mov.l r11,@-r15
    c.r[3] = ld32(0x0608790Cu);  // 0608784A mov.l 0x0608790C,r3
    st32(c.r[3], c.r[0]);  // 0608784C mov.l r0,@r3
    c.t = (int32_t)c.r[0] > (int32_t)c.r[8];  // 0608784E cmp/gt r8,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_060878BE; } }  // 06087850 bf/s 0x060878BE ; add #4,r15
    c.r[11] = ld32(c.r[14]);  // 06087854 mov.l @r14,r11
    c.r[11] += 1;  // 06087856 add #1,r11
    c.r[3] = 0x1u;  // 06087858 mov #1,r3
    c.r[10] ^= c.r[3];  // 0608785A xor r3,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0608785C tst r10,r10
    c.r[5] = ld32(0x06087928u);  // 0608785E mov.l 0x06087928,r5
    { const bool k = c.t; st32(c.r[14], c.r[11]); if (k) { goto L_06087866; } }  // 06087860 bt/s 0x06087866 ; mov.l r11,@r14
    c.r[5] = ld32(0x0608792Cu);  // 06087864 mov.l 0x0608792C,r5
L_06087866:
    c.r[9] = ld32(0x06087930u);  // 06087866 mov.l 0x06087930,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x06087904u);  // 06087868 mov.w 0x06087904,r11
    c.r[12] = ld32(0x06087934u);  // 0608786A mov.l 0x06087934,r12
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087906u);  // 0608786C mov.w 0x06087906,r7
    c.r[4] = ld32(c.r[9]);  // 0608786E mov.l @r9,r4
    c.r[6] = 0x2u;  // 06087870 mov #2,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06087876u; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087876u) return; }  // 06087872 jsr @r12 ; mov.l r11,@-r15
    c.r[3] = ld32(0x06087924u);  // 06087876 mov.l 0x06087924,r3
    c.r[5] = ld32(c.r[3]);  // 06087878 mov.l @r3,r5
    c.r[8] = ld32(0x06087938u);  // 0608787A mov.l 0x06087938,r8
    c.r[0] = ld32(0x0608793Cu);  // 0608787C mov.l 0x0608793C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087882u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087882u) return; }  // 0608787E jsr @r0 ; mov.l @r8,r4
    c.r[5] = ld32(c.r[9]);  // 06087882 mov.l @r9,r5
    c.r[0] = ld32(0x06087940u);  // 06087884 mov.l 0x06087940,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608788Au; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608788Au) return; }  // 06087886 jsr @r0 ; mov.l @r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608788A tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_060878A2; } }  // 0608788C bf/s 0x060878A2 ; add #4,r15
    c.t = (c.r[10] & c.r[10]) == 0;  // 06087890 tst r10,r10
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06087898; } }  // 06087892 bt/s 0x06087898 ; mov #1,r4
    c.r[4] = 0x2u;  // 06087896 mov #2,r4
L_06087898:
    c.r[0] = ld32(0x06087944u);  // 06087898 mov.l 0x06087944,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608789Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608789Eu) return; }  // 0608789A jsr @r0 ; nop
    goto L_060878C2;  // 0608789E bra 0x060878C2 ; nop
L_060878A2:
    c.r[11] = 0x1u;  // 060878A2 mov #1,r11
    c.r[10] ^= c.r[11];  // 060878A4 xor r11,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060878A6 tst r10,r10
    c.r[5] = ld32(0x06087928u);  // 060878A8 mov.l 0x06087928,r5
    if (c.t) { goto L_060878AE; }  // 060878AA bt 0x060878AE
    c.r[5] = ld32(0x0608792Cu);  // 060878AC mov.l 0x0608792C,r5
L_060878AE:
    c.r[4] = ld32(c.r[9]);  // 060878AE mov.l @r9,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06087904u);  // 060878B0 mov.w 0x06087904,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087906u);  // 060878B2 mov.w 0x06087906,r7
    c.r[6] = 0x2u;  // 060878B4 mov #2,r6
    { const uint32_t x = c.r[12]; c.pr = 0x060878BAu; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060878BAu) return; }  // 060878B6 jsr @r12 ; mov.l r3,@-r15
    c.r[15] += 4; goto L_060878C2;  // 060878BA bra 0x060878C2 ; add #4,r15
L_060878BE:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060878BE cmp/eq #-1,r0
    if (c.t) { goto L_060878E8; }  // 060878C0 bt 0x060878E8
L_060878C2:
    c.r[1] = ld32(0x06087908u);  // 060878C2 mov.l 0x06087908,r1
    c.r[1] = ld32(c.r[1]);  // 060878C4 mov.l @r1,r1
    c.r[1] = ld32(c.r[1]);  // 060878C6 mov.l @r1,r1
    c.t = c.r[13] >= c.r[1];  // 060878C8 cmp/hs r1,r13
    if (!c.t) { goto L_060878D0; }  // 060878CA bf 0x060878D0
    SH2_POLL(c); goto L_06087760;  // 060878CC bra 0x06087760 ; nop
L_060878D0:
    c.r[13] += 1;  // 060878D0 add #1,r13
    c.r[1] = ld32(0x06087948u);  // 060878D2 mov.l 0x06087948,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060878D8u; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060878D8u) return; }  // 060878D4 jsr @r1 ; mov.l @(4,r14),r4
    c.r[1] = ld32(0x06087910u);  // 060878D8 mov.l 0x06087910,r1
    c.r[0] = ld32(0x0608794Cu);  // 060878DA mov.l 0x0608794C,r0
    c.r[6] = 0xFFFFFFFEu;  // 060878DC mov #-2,r6
    c.r[4] = ld32(c.r[1]);  // 060878DE mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060878E4u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060878E4u) return; }  // 060878E0 jsr @r0 ; mov #0,r5
    SH2_POLL(c); goto L_06087760;  // 060878E4 bra 0x06087760 ; nop
L_060878E8:
    c.r[1] = ld32(0x06087950u);  // 060878E8 mov.l 0x06087950,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060878EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060878EEu) return; }  // 060878EA jsr @r1 ; nop
    c.r[14] += 12;  // 060878EE add #12,r14
    c.r[15] = c.r[14];  // 060878F0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060878F2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060878F4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060878F6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060878F8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060878FA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060878FC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060878FE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06087900 rts ; mov.l @r15+,r8
}

void f_06087954(SH2Context& c) {
    ran[1906] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087954 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087956 sts.l pr,@-r15
    c.r[1] = ld32(0x060879D8u);  // 06087958 mov.l 0x060879D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608795Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608795Eu) return; }  // 0608795A jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x060879DCu);  // 0608795E mov.l 0x060879DC,r2
    c.r[1] = ld32(c.r[2]);  // 06087960 mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06087962 tst r1,r1
    if (c.t) { goto L_060879CE; }  // 06087964 bt 0x060879CE
    c.r[0] = ld32(c.r[2]);  // 06087966 mov.l @r2,r0
    c.t = c.r[0] == 0x1u;  // 06087968 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0608799C; } }  // 0608796A bf/s 0x0608799C ; mov #0,r1
    c.r[4] = ld32(0x060879E0u);  // 0608796E mov.l 0x060879E0,r4
    c.r[7] = ld32(0x060879E4u);  // 06087970 mov.l 0x060879E4,r7
    c.r[2] = ld32(0x060879E8u);  // 06087972 mov.l 0x060879E8,r2
    st16(c.r[2], c.r[1]);  // 06087974 mov.w r1,@r2
    c.r[2] = 0x0u;  // 06087976 mov #0,r2
    c.r[3] = 0x0u;  // 06087978 mov #0,r3
    c.r[0] = 0x0u;  // 0608797A mov #0,r0
L_0608797C:
    st16(c.r[0] + c.r[7], c.r[3]);  // 0608797C mov.w r3,@(r0,r7)
    c.r[2] += 1;  // 0608797E add #1,r2
    c.r[1] = 0x1u;  // 06087980 mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06087982 cmp/gt r1,r2
    { const bool k = !c.t; c.r[0] += 2; if (k) { SH2_POLL(c); goto L_0608797C; } }  // 06087984 bf/s 0x0608797C ; add #2,r0
    c.r[1] = ld32(0x060879ECu);  // 06087988 mov.l 0x060879EC,r1
    c.r[7] = c.r[4];  // 0608798A mov r4,r7
    c.r[6] = c.r[4];  // 0608798C mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06087992u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087992u) return; }  // 0608798E jsr @r1 ; mov r4,r5
    c.r[6] = ld32(0x060879F0u);  // 06087992 mov.l 0x060879F0,r6
    c.r[4] = ld32(0x060879F4u);  // 06087994 mov.l 0x060879F4,r4
    c.r[1] = ld32(0x060879F8u);  // 06087996 mov.l 0x060879F8,r1
    c.r[7] = c.r[6]; goto L_060879C4;  // 06087998 bra 0x060879C4 ; mov r6,r7
L_0608799C:
    c.r[4] = ld32(0x060879FCu);  // 0608799C mov.l 0x060879FC,r4
    c.r[3] = ld32(0x060879E4u);  // 0608799E mov.l 0x060879E4,r3
    c.r[2] = ld32(0x060879E8u);  // 060879A0 mov.l 0x060879E8,r2
    st16(c.r[2], c.r[1]);  // 060879A2 mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x060879D6u);  // 060879A4 mov.w 0x060879D6,r2
    c.r[0] = 0x0u;  // 060879A6 mov #0,r0
    c.r[1] = 0x2u;  // 060879A8 mov #2,r1
L_060879AA:
    st16(c.r[0] + c.r[3], c.r[2]);  // 060879AA mov.w r2,@(r0,r3)
    c.r[0] += 2;  // 060879AC add #2,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060879AE cmp/gt r1,r0
    { const bool k = !c.t; c.r[7] = c.r[4]; if (k) { SH2_POLL(c); goto L_060879AA; } }  // 060879B0 bf/s 0x060879AA ; mov r4,r7
    c.r[1] = ld32(0x060879ECu);  // 060879B4 mov.l 0x060879EC,r1
    c.r[6] = c.r[4];  // 060879B6 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060879BCu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060879BCu) return; }  // 060879B8 jsr @r1 ; mov r4,r5
    c.r[7] = ld32(0x060879F4u);  // 060879BC mov.l 0x060879F4,r7
    c.r[6] = ld32(0x06087A00u);  // 060879BE mov.l 0x06087A00,r6
    c.r[4] = ld32(0x060879F0u);  // 060879C0 mov.l 0x060879F0,r4
    c.r[1] = ld32(0x060879F8u);  // 060879C2 mov.l 0x060879F8,r1
L_060879C4:
    { const uint32_t x = c.r[1]; c.pr = 0x060879C8u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060879C8u) return; }  // 060879C4 jsr @r1 ; mov r4,r5
    c.r[2] = ld32(0x060879DCu);  // 060879C8 mov.l 0x060879DC,r2
    c.r[1] = 0x0u;  // 060879CA mov #0,r1
    st32(c.r[2], c.r[1]);  // 060879CC mov.l r1,@r2
L_060879CE:
    c.r[15] = c.r[14];  // 060879CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060879D0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060879D2 rts ; mov.l @r15+,r14
}

void f_06087A0C(SH2Context& c) {
    ran[1907] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06087A0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06087A0E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06087A10 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06087A12 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06087A14 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06087A16 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087A18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087A1A sts.l pr,@-r15
    c.r[15] -= 12;  // 06087A1C add #-12,r15
    c.r[14] = c.r[15];  // 06087A1E mov r15,r14
    c.r[0] = 0x0u;  // 06087A20 mov #0,r0
    st32(c.r[14] + 4, c.r[0]);  // 06087A22 mov.l r0,@(4,r14)
    c.r[13] = ld32(0x06087AECu);  // 06087A24 mov.l 0x06087AEC,r13
    c.r[12] = ld32(0x06087AF0u);  // 06087A26 mov.l 0x06087AF0,r12
    c.r[1] = ld32(0x06087AF4u);  // 06087A28 mov.l 0x06087AF4,r1
    c.r[1] = ld32(c.r[1]);  // 06087A2A mov.l @r1,r1
    c.r[4] = ld32(0x06087AF8u);  // 06087A2C mov.l 0x06087AF8,r4
    st32(c.r[14] + 8, c.r[1]);  // 06087A2E mov.l r1,@(8,r14)
    c.r[1] = ld32(0x06087AFCu);  // 06087A30 mov.l 0x06087AFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087A36u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087A36u) return; }  // 06087A32 jsr @r1 ; nop
    c.r[7] = 0x0u;  // 06087A36 mov #0,r7
    c.r[4] = 0x3Fu;  // 06087A38 mov #63,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06087AE2u);  // 06087A3A mov.w 0x06087AE2,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06087AE4u);  // 06087A3C mov.w 0x06087AE4,r6
    c.r[2] = 0x0u;  // 06087A3E mov #0,r2
L_06087A40:
    c.r[3] = 0x0u;  // 06087A40 mov #0,r3
    c.r[1] = c.r[2];  // 06087A42 mov r2,r1
L_06087A44:
    c.r[0] = c.r[1];  // 06087A44 mov r1,r0
    c.r[0] += c.r[3];  // 06087A46 add r3,r0
    c.r[0] <<= 2;  // 06087A48 shll2 r0
    st32(c.r[0] + c.r[13], c.r[5]);  // 06087A4A mov.l r5,@(r0,r13)
    c.r[3] += 1;  // 06087A4C add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[4];  // 06087A4E cmp/gt r4,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[12], c.r[6]); if (k) { SH2_POLL(c); goto L_06087A44; } }  // 06087A50 bf/s 0x06087A44 ; mov.l r6,@(r0,r12)
    c.r[7] += 1;  // 06087A54 add #1,r7
    c.r[1] = 0x3Fu;  // 06087A56 mov #63,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06087A58 cmp/gt r1,r7
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_06087A40; } }  // 06087A5A bf/s 0x06087A40 ; add #64,r2
    c.r[1] = ld32(0x06087B00u);  // 06087A5E mov.l 0x06087B00,r1
    c.r[1] = ld32(c.r[1]);  // 06087A60 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06087AE6u);  // 06087A62 mov.w 0x06087AE6,r2
    c.r[0] = c.r[2];  // 06087A64 mov r2,r0
    c.r[0] -= c.r[1];  // 06087A66 sub r1,r0
    c.r[1] = c.r[0];  // 06087A68 mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06087A6A cmp/pz r1
    if (c.t) { goto L_06087A70; }  // 06087A6C bt 0x06087A70
    c.r[1] += 15;  // 06087A6E add #15,r1
L_06087A70:
    c.r[9] = c.r[1];  // 06087A70 mov r1,r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06087A72 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06087A74 shar r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06087A76 shar r9
    c.r[1] = ld32(0x06087B04u);  // 06087A78 mov.l 0x06087B04,r1
    c.r[1] = ld32(c.r[1]);  // 06087A7A mov.l @r1,r1
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 06087A7C shar r9
    c.t = (int32_t)c.r[1] >= 0;  // 06087A7E cmp/pz r1
    if (c.t) { goto L_06087A84; }  // 06087A80 bt 0x06087A84
    c.r[1] += 7;  // 06087A82 add #7,r1
L_06087A84:
    c.r[5] = c.r[1];  // 06087A84 mov r1,r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 06087A86 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 06087A88 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 06087A8A shar r5
    c.r[7] = c.r[9];  // 06087A8C mov r9,r7
    c.r[11] = c.r[2];  // 06087A8E mov r2,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x06087AE8u);  // 06087A90 mov.w 0x06087AE8,r10
    c.r[8] = c.r[7];  // 06087A92 mov r7,r8
    c.r[8] <<= 2;  // 06087A94 shll2 r8
    c.r[8] <<= 2;  // 06087A96 shll2 r8
    c.r[8] <<= 2;  // 06087A98 shll2 r8
L_06087A9A:
    c.r[1] = ld32(0x06087B00u);  // 06087A9A mov.l 0x06087B00,r1
    c.r[1] = ld32(c.r[1]);  // 06087A9C mov.l @r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06087A9E cmp/pz r1
    if (c.t) { goto L_06087AA4; }  // 06087AA0 bt 0x06087AA4
    c.r[1] += 7;  // 06087AA2 add #7,r1
L_06087AA4:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06087AA4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06087AA6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06087AA8 shar r1
    c.r[1] += c.r[9];  // 06087AAA add r9,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06087AAC cmp/ge r1,r7
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_06087B08; } }  // 06087AAE bt/s 0x06087B08 ; mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[5];  // 06087AB2 cmp/ge r5,r3
    if (c.t) { goto L_06087ADC; }  // 06087AB4 bt 0x06087ADC
    c.r[4] = c.r[8];  // 06087AB6 mov r8,r4
    c.r[6] = c.r[7];  // 06087AB8 mov r7,r6
    c.r[6] -= c.r[9];  // 06087ABA sub r9,r6
L_06087ABC:
    c.r[0] = c.r[4];  // 06087ABC mov r4,r0
    c.macl = c.r[6] * c.r[5];  // 06087ABE mul.l r5,r6
    c.r[0] += c.r[3];  // 06087AC0 add r3,r0
    c.r[0] <<= 2;  // 06087AC2 shll2 r0
    c.r[2] = c.macl;  // 06087AC4 sts macl,r2
    c.r[2] += c.r[3];  // 06087AC6 add r3,r2
    c.r[2] <<= 2;  // 06087AC8 shll2 r2
    c.r[2] += c.r[2];  // 06087ACA add r2,r2
    c.r[1] = c.r[2];  // 06087ACC mov r2,r1
    c.r[1] += c.r[11];  // 06087ACE add r11,r1
    st32(c.r[0] + c.r[13], c.r[1]);  // 06087AD0 mov.l r1,@(r0,r13)
    c.r[2] += c.r[10];  // 06087AD2 add r10,r2
    c.r[3] += 1;  // 06087AD4 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[5];  // 06087AD6 cmp/ge r5,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[12], c.r[2]); if (k) { SH2_POLL(c); goto L_06087ABC; } }  // 06087AD8 bf/s 0x06087ABC ; mov.l r2,@(r0,r12)
L_06087ADC:
    c.r[8] += 64;  // 06087ADC add #64,r8
    c.r[7] += 1; SH2_POLL(c); goto L_06087A9A;  // 06087ADE bra 0x06087A9A ; add #1,r7
L_06087B08:
    c.r[1] = ld32(0x06087C70u);  // 06087B08 mov.l 0x06087C70,r1
    c.r[1] = ld32(c.r[1]);  // 06087B0A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06087C66u);  // 06087B0C mov.w 0x06087C66,r0
    c.r[0] -= c.r[1];  // 06087B0E sub r1,r0
    c.r[1] = c.r[0];  // 06087B10 mov r0,r1
    c.r[2] = c.r[1];  // 06087B12 mov r1,r2
    c.t = c.r[2] >> 31; c.r[2] = c.r[2] << 1 | c.t;  // 06087B14 rotl r2
    c.r[2] = c.t;  // 06087B16 movt r2
    c.r[2] += c.r[1];  // 06087B18 add r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06087B1A shar r2
    c.t = (int32_t)c.r[2] >= 0;  // 06087B1C cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[2]; if (k) { goto L_06087B24; } }  // 06087B1E bt/s 0x06087B24 ; mov r2,r4
    c.r[4] += 7;  // 06087B22 add #7,r4
L_06087B24:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 06087B24 shar r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 06087B26 shar r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 06087B28 shar r4
    c.r[4] <<= 2;  // 06087B2A shll2 r4
    c.r[4] += c.r[4];  // 06087B2C add r4,r4
    c.r[4] -= c.r[2];  // 06087B2E sub r2,r4
    c.r[12] = ld32(0x06087C74u);  // 06087B30 mov.l 0x06087C74,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06087B36u; c.r[4] += 16; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B36u) return; }  // 06087B32 jsr @r12 ; add #16,r4
    c.r[4] = c.r[0];  // 06087B36 mov r0,r4
    c.r[5] = c.r[1];  // 06087B38 mov r1,r5
    c.r[1] = ld32(0x06087C78u);  // 06087B3A mov.l 0x06087C78,r1
    c.r[8] = ld32(c.r[1]);  // 06087B3C mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 06087B3E mov.l @(4,r1),r9
    c.r[11] = ld32(0x06087C7Cu);  // 06087B40 mov.l 0x06087C7C,r11
    c.r[6] = c.r[8];  // 06087B42 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06087B48u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B48u) return; }  // 06087B44 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 06087B48 mov r0,r4
    c.r[10] = ld32(0x06087C80u);  // 06087B4A mov.l 0x06087C80,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06087B50u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B50u) return; }  // 06087B4C jsr @r10 ; mov r1,r5
    c.r[1] = ld32(0x06087C84u);  // 06087B50 mov.l 0x06087C84,r1
    c.r[4] = ld32(c.r[1]);  // 06087B52 mov.l @r1,r4
    c.r[13] = c.r[0];  // 06087B54 mov r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06087C68u);  // 06087B56 mov.w 0x06087C68,r1
    c.r[4] += c.r[1];  // 06087B58 add r1,r4
    c.r[1] = c.r[4];  // 06087B5A mov r4,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06087B5C rotl r1
    c.r[1] = c.t;  // 06087B5E movt r1
    c.r[4] += c.r[1];  // 06087B60 add r1,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06087B66u; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B66u) return; }  // 06087B62 jsr @r12 ; shar r4
    c.r[4] = c.r[0];  // 06087B66 mov r0,r4
    c.r[5] = c.r[1];  // 06087B68 mov r1,r5
    c.r[6] = c.r[8];  // 06087B6A mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x06087B70u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B70u) return; }  // 06087B6C jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 06087B70 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06087B76u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B76u) return; }  // 06087B72 jsr @r10 ; mov r1,r5
    c.r[2] = c.r[0];  // 06087B76 mov r0,r2
    c.r[1] = ld32(0x06087C88u);  // 06087B78 mov.l 0x06087C88,r1
    c.r[5] = c.r[13];  // 06087B7A mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06087B80u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B80u) return; }  // 06087B7C jsr @r1 ; mov r2,r4
    c.r[1] = ld32(0x06087C8Cu);  // 06087B80 mov.l 0x06087C8C,r1
    c.r[5] = 0x0u;  // 06087B82 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06087B88u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B88u) return; }  // 06087B84 jsr @r1 ; mov #64,r4
    c.r[1] = ld32(0x06087C90u);  // 06087B88 mov.l 0x06087C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087B8Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B8Eu) return; }  // 06087B8A jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x06087C94u);  // 06087B8E mov.l 0x06087C94,r4
    c.r[1] = ld32(0x06087C98u);  // 06087B90 mov.l 0x06087C98,r1
    c.r[6] = 0x0u;  // 06087B92 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06087B98u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087B98u) return; }  // 06087B94 jsr @r1 ; mov #0,r5
    c.r[4] = ld32(0x06087C9Cu);  // 06087B98 mov.l 0x06087C9C,r4
    c.r[1] = ld32(0x06087CA0u);  // 06087B9A mov.l 0x06087CA0,r1
    c.r[7] = c.r[4];  // 06087B9C mov r4,r7
    c.r[6] = c.r[4];  // 06087B9E mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06087BA4u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BA4u) return; }  // 06087BA0 jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x06087CA4u);  // 06087BA4 mov.l 0x06087CA4,r1
    c.r[5] = ld32(c.r[1]);  // 06087BA6 mov.l @r1,r5
    c.r[13] = 0x0u;  // 06087BA8 mov #0,r13
    c.r[1] = ld32(0x06087CA8u);  // 06087BAA mov.l 0x06087CA8,r1
    c.r[0] = ld32(0x06087CACu);  // 06087BAC mov.l 0x06087CAC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087BB2u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BB2u) return; }  // 06087BAE jsr @r0 ; mov.l @r1,r4
    st32(c.r[14], c.r[0]);  // 06087BB2 mov.l r0,@r14
    c.r[11] = (uint32_t)(int16_t)ld16(0x06087C6Au);  // 06087BB4 mov.w 0x06087C6A,r11
    c.r[5] = ld32(0x06087CB0u);  // 06087BB6 mov.l 0x06087CB0,r5
    c.r[9] = ld32(0x06087CB4u);  // 06087BB8 mov.l 0x06087CB4,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06087C66u);  // 06087BBA mov.w 0x06087C66,r0
    c.r[10] = ld32(0x06087CB8u);  // 06087BBC mov.l 0x06087CB8,r10
    c.r[7] = c.r[11];  // 06087BBE mov r11,r7
    c.r[4] = ld32(c.r[9]);  // 06087BC0 mov.l @r9,r4
    c.r[6] = 0x3u;  // 06087BC2 mov #3,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06087BC8u; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BC8u) return; }  // 06087BC4 jsr @r10 ; mov.l r0,@-r15
    c.r[1] = ld32(0x06087CBCu);  // 06087BC8 mov.l 0x06087CBC,r1
    c.r[5] = ld32(c.r[1]);  // 06087BCA mov.l @r1,r5
    c.r[8] = ld32(0x06087CC0u);  // 06087BCC mov.l 0x06087CC0,r8
    c.r[0] = ld32(0x06087CC4u);  // 06087BCE mov.l 0x06087CC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087BD4u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BD4u) return; }  // 06087BD0 jsr @r0 ; mov.l @r8,r4
    c.r[5] = ld32(c.r[9]);  // 06087BD4 mov.l @r9,r5
    c.r[12] = 0x0u;  // 06087BD6 mov #0,r12
    c.r[0] = ld32(0x06087CC8u);  // 06087BD8 mov.l 0x06087CC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087BDEu; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BDEu) return; }  // 06087BDA jsr @r0 ; mov.l @r8,r4
    c.r[5] = ld32(0x06087CCCu);  // 06087BDE mov.l 0x06087CCC,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06087C66u);  // 06087BE0 mov.w 0x06087C66,r0
    c.r[7] = c.r[11];  // 06087BE2 mov r11,r7
    c.r[4] = ld32(c.r[9]);  // 06087BE4 mov.l @r9,r4
    c.r[6] = 0x3u;  // 06087BE6 mov #3,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06087BECu; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BECu) return; }  // 06087BE8 jsr @r10 ; mov.l r0,@-r15
    c.r[1] = ld32(0x06087CD0u);  // 06087BEC mov.l 0x06087CD0,r1
    c.r[5] = ld32(c.r[1]);  // 06087BEE mov.l @r1,r5
    c.r[8] = ld32(0x06087CD4u);  // 06087BF0 mov.l 0x06087CD4,r8
    c.r[1] = ld32(0x06087CD8u);  // 06087BF2 mov.l 0x06087CD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087BF8u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087BF8u) return; }  // 06087BF4 jsr @r1 ; mov.l @r8,r4
    c.r[6] = 0xFFFFFFFEu;  // 06087BF8 mov #-2,r6
    c.r[5] = 0x0u;  // 06087BFA mov #0,r5
    c.r[0] = ld32(0x06087CDCu);  // 06087BFC mov.l 0x06087CDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087C02u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087C02u) return; }  // 06087BFE jsr @r0 ; mov.l @r8,r4
    c.r[1] = ld32(0x06087CE0u);  // 06087C02 mov.l 0x06087CE0,r1
    c.r[5] = 0x1u;  // 06087C04 mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06087C0Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087C0Au) return; }  // 06087C06 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06087CE4u);  // 06087C0A mov.l 0x06087CE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087C10u; c.r[10] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087C10u) return; }  // 06087C0C jsr @r1 ; mov #1,r10
    c.r[0] = ld32(0x06087CE8u);  // 06087C10 mov.l 0x06087CE8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087C16u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087C16u) return; }  // 06087C12 jsr @r0 ; mov #1,r4
    c.r[6] = ld32(0x06087CECu);  // 06087C16 mov.l 0x06087CEC,r6
    c.r[4] = ld32(0x06087CF0u);  // 06087C18 mov.l 0x06087CF0,r4
    c.r[1] = ld32(0x06087CF4u);  // 06087C1A mov.l 0x06087CF4,r1
    c.r[7] = c.r[6];  // 06087C1C mov r6,r7
    { const uint32_t x = c.r[1]; c.pr = 0x06087C22u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087C22u) return; }  // 06087C1E jsr @r1 ; mov r4,r5
    c.r[15] += 8;  // 06087C22 add #8,r15
    c.r[11] = ld32(0x06087CF8u);  // 06087C24 mov.l 0x06087CF8,r11
L_06087C26:
    c.r[0] = ld32(0x06087CFCu);  // 06087C26 mov.l 0x06087CFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087C2Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087C2Cu) return; }  // 06087C28 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06087C2C and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06087C2E tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 8); if (k) { goto L_06087C38; } }  // 06087C30 bt/s 0x06087C38 ; mov.l @(8,r14),r1
    c.r[1] = 0x3u; goto L_06087C46;  // 06087C34 bra 0x06087C46 ; mov #3,r1
L_06087C38:
    c.r[1] += 2;  // 06087C38 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06087C3A mov.w @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06087C6Cu);  // 06087C3C mov.w 0x06087C6C,r1
    c.r[1] &= c.r[2];  // 06087C3E and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06087C40 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_06087C4C; } }  // 06087C42 bf/s 0x06087C4C ; mov #2,r1
L_06087C46:
    c.r[0] = ld32(0x06087D00u);  // 06087C46 mov.l 0x06087D00,r0
    st32(c.r[0], c.r[1]); goto L_06087DD2;  // 06087C48 bra 0x06087DD2 ; mov.l r1,@r0
L_06087C4C:
    c.r[1] = ld32(0x06087D04u);  // 06087C4C mov.l 0x06087D04,r1
    c.r[1] = ld32(c.r[1]);  // 06087C4E mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06087C50 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[2] & 0xFFFFu; if (k) { goto L_06087D08; } }  // 06087C52 bt/s 0x06087D08 ; extu.w r2,r2
    c.r[2] = ~c.r[2];  // 06087C56 not r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06087C66u);  // 06087C58 mov.w 0x06087C66,r1
    c.r[2] &= c.r[1];  // 06087C5A and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06087C5C tst r2,r2
    if (c.t) { goto L_06087D08; }  // 06087C5E bt 0x06087D08
    c.r[0] = ld32(0x06087D00u);  // 06087C60 mov.l 0x06087D00,r0
    st32(c.r[0], c.r[10]); goto L_06087DD2;  // 06087C62 bra 0x06087DD2 ; mov.l r10,@r0
L_06087D08:
    c.r[1] = ld32(c.r[11]);  // 06087D08 mov.l @r11,r1
    c.r[1] = ld32(c.r[1]);  // 06087D0A mov.l @r1,r1
    c.t = c.r[12] > c.r[1];  // 06087D0C cmp/hi r1,r12
    { const bool k = c.t; c.r[7] = c.r[10]; if (k) { goto L_06087DAE; } }  // 06087D0E bt/s 0x06087DAE ; mov r10,r7
    c.r[1] = ld32(0x06087DF4u);  // 06087D12 mov.l 0x06087DF4,r1
    c.r[4] = ld32(c.r[1]);  // 06087D14 mov.l @r1,r4
    c.r[0] = ld32(0x06087DF8u);  // 06087D16 mov.l 0x06087DF8,r0
    c.r[6] = ld32(0x06087DFCu);  // 06087D18 mov.l 0x06087DFC,r6
    c.r[5] = ld32(0x06087E00u);  // 06087D1A mov.l 0x06087E00,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06087D20u; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087D20u) return; }  // 06087D1C jsr @r0 ; mov.l r10,@-r15
    c.r[2] = c.r[0];  // 06087D20 mov r0,r2
    c.r[1] = ld32(0x06087E04u);  // 06087D22 mov.l 0x06087E04,r1
    st32(c.r[1], c.r[2]);  // 06087D24 mov.l r2,@r1
    c.r[1] = 0xFFFFFFFFu;  // 06087D26 mov #-1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06087D28 cmp/gt r1,r2
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_06087DA8; } }  // 06087D2A bf/s 0x06087DA8 ; add #4,r15
    c.r[1] = c.r[12];  // 06087D2E mov r12,r1
    c.r[2] = ld32(c.r[11]);  // 06087D30 mov.l @r11,r2
    c.r[2] = ld32(c.r[2]);  // 06087D32 mov.l @r2,r2
    c.r[1] += 2;  // 06087D34 add #2,r1
    c.t = c.r[1] > c.r[2];  // 06087D36 cmp/hi r2,r1
    if (!c.t) { goto L_06087D82; }  // 06087D38 bf 0x06087D82
    c.r[2] = ld32(0x06087E08u);  // 06087D3A mov.l 0x06087E08,r2
L_06087D3C:
    c.r[1] = ld32(c.r[2]);  // 06087D3C mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06087D3E tst r1,r1
    if (!c.t) { SH2_POLL(c); goto L_06087D3C; }  // 06087D40 bf 0x06087D3C
    c.r[5] = ld32(c.r[9]);  // 06087D42 mov.l @r9,r5
    c.r[1] = ld32(0x06087E0Cu);  // 06087D44 mov.l 0x06087E0C,r1
    c.r[0] = ld32(0x06087E10u);  // 06087D46 mov.l 0x06087E10,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087D4Cu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087D4Cu) return; }  // 06087D48 jsr @r0 ; mov.l @r1,r4
    c.r[0] = ld32(c.r[14] + 4);  // 06087D4C mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06087D4E tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_06087D66; } }  // 06087D50 bf/s 0x06087D66 ; mov #2,r1
    c.r[1] = ld32(0x06087E08u);  // 06087D54 mov.l 0x06087E08,r1
    st32(c.r[1], c.r[10]);  // 06087D56 mov.l r10,@r1
    c.r[4] = ld32(c.r[9]);  // 06087D58 mov.l @r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06087DEEu);  // 06087D5A mov.w 0x06087DEE,r1
    c.r[0] = ld32(0x06087E14u);  // 06087D5C mov.l 0x06087E14,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087DF0u);  // 06087D5E mov.w 0x06087DF0,r7
    c.r[5] = ld32(0x06087E18u);  // 06087D60 mov.l 0x06087E18,r5
    c.r[6] = 0x3u; goto L_06087D76;  // 06087D62 bra 0x06087D76 ; mov #3,r6
L_06087D66:
    c.r[2] = ld32(0x06087E08u);  // 06087D66 mov.l 0x06087E08,r2
    st32(c.r[2], c.r[1]);  // 06087D68 mov.l r1,@r2
    c.r[4] = ld32(c.r[9]);  // 06087D6A mov.l @r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06087DEEu);  // 06087D6C mov.w 0x06087DEE,r1
    c.r[0] = ld32(0x06087E14u);  // 06087D6E mov.l 0x06087E14,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087DF0u);  // 06087D70 mov.w 0x06087DF0,r7
    c.r[6] = 0x3u;  // 06087D72 mov #3,r6
    c.r[5] = ld32(0x06087E1Cu);  // 06087D74 mov.l 0x06087E1C,r5
L_06087D76:
    { const uint32_t x = c.r[0]; c.pr = 0x06087D7Au; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087D7Au) return; }  // 06087D76 jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4;  // 06087D7A add #4,r15
    c.r[0] = ld32(c.r[14] + 4);  // 06087D7C mov.l @(4,r14),r0
    c.r[0] ^= 0x1u;  // 06087D7E xor #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 06087D80 mov.l r0,@(4,r14)
L_06087D82:
    c.r[1] = ld32(0x06087E00u);  // 06087D82 mov.l 0x06087E00,r1
    c.r[5] = ld32(c.r[1]);  // 06087D84 mov.l @r1,r5
    c.r[8] = ld32(0x06087E0Cu);  // 06087D86 mov.l 0x06087E0C,r8
    c.r[0] = ld32(0x06087E20u);  // 06087D88 mov.l 0x06087E20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087D8Eu; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087D8Eu) return; }  // 06087D8A jsr @r0 ; mov.l @r8,r4
    c.r[5] = ld32(c.r[9]);  // 06087D8E mov.l @r9,r5
    c.r[0] = ld32(0x06087E24u);  // 06087D90 mov.l 0x06087E24,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087D96u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087D96u) return; }  // 06087D92 jsr @r0 ; mov.l @r8,r4
    c.r[1] = ld32(0x06087E04u);  // 06087D96 mov.l 0x06087E04,r1
    c.r[5] = ld32(c.r[1]);  // 06087D98 mov.l @r1,r5
    c.r[1] = ld32(0x06087E28u);  // 06087D9A mov.l 0x06087E28,r1
    c.r[4] = ld32(c.r[1]);  // 06087D9C mov.l @r1,r4
    c.r[1] = ld32(0x06087E2Cu);  // 06087D9E mov.l 0x06087E2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087DA4u; c.r[12] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087DA4u) return; }  // 06087DA0 jsr @r1 ; add #1,r12
    c.r[1] = ld32(c.r[11]); goto L_06087DB0;  // 06087DA4 bra 0x06087DB0 ; mov.l @r11,r1
L_06087DA8:
    c.r[0] = c.r[2];  // 06087DA8 mov r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06087DAA cmp/eq #-1,r0
    if (c.t) { goto L_06087DD2; }  // 06087DAC bt 0x06087DD2
L_06087DAE:
    c.r[1] = ld32(c.r[11]);  // 06087DAE mov.l @r11,r1
L_06087DB0:
    c.r[1] = ld32(c.r[1]);  // 06087DB0 mov.l @r1,r1
    c.t = c.r[13] >= c.r[1];  // 06087DB2 cmp/hs r1,r13
    if (!c.t) { goto L_06087DBA; }  // 06087DB4 bf 0x06087DBA
    SH2_POLL(c); goto L_06087C26;  // 06087DB6 bra 0x06087C26 ; nop
L_06087DBA:
    c.r[13] += 1;  // 06087DBA add #1,r13
    c.r[1] = ld32(0x06087E30u);  // 06087DBC mov.l 0x06087E30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087DC2u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087DC2u) return; }  // 06087DBE jsr @r1 ; mov.l @r14,r4
    c.r[1] = ld32(0x06087E28u);  // 06087DC2 mov.l 0x06087E28,r1
    c.r[0] = ld32(0x06087E34u);  // 06087DC4 mov.l 0x06087E34,r0
    c.r[6] = 0xFFFFFFFEu;  // 06087DC6 mov #-2,r6
    c.r[4] = ld32(c.r[1]);  // 06087DC8 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06087DCEu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087DCEu) return; }  // 06087DCA jsr @r0 ; mov #0,r5
    SH2_POLL(c); goto L_06087C26;  // 06087DCE bra 0x06087C26 ; nop
L_06087DD2:
    c.r[1] = ld32(0x06087E38u);  // 06087DD2 mov.l 0x06087E38,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087DD8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087DD8u) return; }  // 06087DD4 jsr @r1 ; nop
    c.r[14] += 12;  // 06087DD8 add #12,r14
    c.r[15] = c.r[14];  // 06087DDA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087DDC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087DDE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06087DE0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06087DE2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06087DE4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06087DE6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06087DE8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06087DEA rts ; mov.l @r15+,r8
}

void f_06087E3C(SH2Context& c) {
    ran[1908] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06087E3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06087E3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06087E40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06087E42 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06087E44 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06087E46 mov r15,r14
    c.r[8] = c.r[4];  // 06087E48 mov r4,r8
    c.r[4] = c.r[5];  // 06087E4A mov r5,r4
    c.r[0] = ld32(0x06087F9Cu);  // 06087E4C mov.l 0x06087F9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087E52u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087E52u) return; }  // 06087E4E jsr @r0 ; mov #0,r5
    c.r[1] = c.r[0];  // 06087E52 mov r0,r1
    c.r[9] = ld32(0x06087FA0u);  // 06087E54 mov.l 0x06087FA0,r9
    st32(c.r[9], c.r[1]);  // 06087E56 mov.l r1,@r9
    c.r[0] = ld32(0x06087FA4u);  // 06087E58 mov.l 0x06087FA4,r0
    c.r[5] = c.r[1];  // 06087E5A mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06087E60u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087E60u) return; }  // 06087E5C jsr @r0 ; mov r8,r4
    c.r[8] = ld32(0x06087FA8u);  // 06087E60 mov.l 0x06087FA8,r8
    c.t = (c.r[0] & c.r[0]) == 0;  // 06087E62 tst r0,r0
    { const bool k = c.t; st32(c.r[8], c.r[0]); if (k) { goto L_06087E8E; } }  // 06087E64 bt/s 0x06087E8E ; mov.l r0,@r8
    c.r[1] = ld32(0x06087FACu);  // 06087E68 mov.l 0x06087FAC,r1
    c.r[7] = 0xFFFFFFFFu;  // 06087E6A mov #-1,r7
    c.r[6] = 0x0u;  // 06087E6C mov #0,r6
    c.r[4] = ld32(c.r[9]);  // 06087E6E mov.l @r9,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06087E74u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087E74u) return; }  // 06087E70 jsr @r1 ; mov r0,r5
    c.r[10] = ld32(0x06087FB0u);  // 06087E74 mov.l 0x06087FB0,r10
    c.r[7] = 0x2u;  // 06087E76 mov #2,r7
    c.r[6] = 0x1u;  // 06087E78 mov #1,r6
    c.r[4] = ld32(c.r[8]);  // 06087E7A mov.l @r8,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06087E80u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087E80u) return; }  // 06087E7C jsr @r10 ; mov #0,r5
    c.r[1] = ld32(0x06087FB4u);  // 06087E80 mov.l 0x06087FB4,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 06087E82 tst r0,r0
    { const bool k = !c.t; st32(c.r[1], c.r[0]); if (k) { goto L_06087E98; } }  // 06087E84 bf/s 0x06087E98 ; mov.l r0,@r1
    c.r[1] = ld32(0x06087FB8u);  // 06087E88 mov.l 0x06087FB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087E8Eu; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087E8Eu) return; }  // 06087E8A jsr @r1 ; mov.l @r8,r4
L_06087E8E:
    c.r[1] = ld32(0x06087FBCu);  // 06087E8E mov.l 0x06087FBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087E94u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087E94u) return; }  // 06087E90 jsr @r1 ; mov.l @r9,r4
    c.r[8] = 0xFFFFFFFFu; goto L_06087EA8;  // 06087E94 bra 0x06087EA8 ; mov #-1,r8
L_06087E98:
    c.r[4] = ld32(c.r[8]);  // 06087E98 mov.l @r8,r4
    c.r[7] = 0x1u;  // 06087E9A mov #1,r7
    c.r[6] = 0x1u;  // 06087E9C mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06087EA2u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087EA2u) return; }  // 06087E9E jsr @r10 ; mov #0,r5
    c.r[1] = ld32(0x06087FC0u);  // 06087EA2 mov.l 0x06087FC0,r1
    st32(c.r[1], c.r[0]);  // 06087EA4 mov.l r0,@r1
    c.r[8] = 0x0u;  // 06087EA6 mov #0,r8
L_06087EA8:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06087EA8 tst r8,r8
    { const bool k = !c.t; c.r[5] = 0x2u; if (k) { goto L_06087F82; } }  // 06087EAA bf/s 0x06087F82 ; mov #2,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x06087F96u);  // 06087EAE mov.w 0x06087F96,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06087F98u);  // 06087EB0 mov.w 0x06087F98,r6
    c.r[10] = ld32(0x06087FC4u);  // 06087EB2 mov.l 0x06087FC4,r10
    c.r[0] = ld32(0x06087FC8u);  // 06087EB4 mov.l 0x06087FC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087EBAu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087EBAu) return; }  // 06087EB6 jsr @r0 ; mov r10,r4
    c.r[1] = ld32(0x06087FCCu);  // 06087EBA mov.l 0x06087FCC,r1
    st32(c.r[1], c.r[0]);  // 06087EBC mov.l r0,@r1
    c.r[1] = ld32(0x06087FD0u);  // 06087EBE mov.l 0x06087FD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087EC4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087EC4u) return; }  // 06087EC0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06087FD4u);  // 06087EC4 mov.l 0x06087FD4,r1
    c.r[6] = ld32(0x06087FD8u);  // 06087EC6 mov.l 0x06087FD8,r6
    c.r[9] = ld32(0x06087FDCu);  // 06087EC8 mov.l 0x06087FDC,r9
    c.r[0] = ld32(0x06087FE0u);  // 06087ECA mov.l 0x06087FE0,r0
    c.r[1] = ld32(c.r[1]);  // 06087ECC mov.l @r1,r1
    c.r[5] = c.r[9];  // 06087ECE mov r9,r5
    st32(c.r[1], c.r[8]);  // 06087ED0 mov.l r8,@r1
    c.r[1] = ld32(0x06087FB4u);  // 06087ED2 mov.l 0x06087FB4,r1
    c.r[8] = 0x1u;  // 06087ED4 mov #1,r8
    c.r[4] = ld32(c.r[1]);  // 06087ED6 mov.l @r1,r4
    c.r[7] = c.r[8];  // 06087ED8 mov r8,r7
    { const uint32_t x = c.r[0]; c.pr = 0x06087EDEu; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087EDEu) return; }  // 06087EDA jsr @r0 ; mov.l r8,@-r15
    c.r[1] = ld32(0x06087FE4u);  // 06087EDE mov.l 0x06087FE4,r1
    st32(c.r[1], c.r[0]);  // 06087EE0 mov.l r0,@r1
    c.r[0] = ld32(0x06087FE8u);  // 06087EE2 mov.l 0x06087FE8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087EE8u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087EE8u) return; }  // 06087EE4 jsr @r0 ; mov.l @r9,r4
    c.r[2] = c.r[0];  // 06087EE8 mov r0,r2
    c.r[9] = ld32(0x06087FECu);  // 06087EEA mov.l 0x06087FEC,r9
    st32(c.r[9], c.r[2]);  // 06087EEC mov.l r2,@r9
    c.r[7] = ld32(0x06087FF0u);  // 06087EEE mov.l 0x06087FF0,r7
    c.r[6] = ld32(0x06087FF4u);  // 06087EF0 mov.l 0x06087FF4,r6
    c.r[5] = ld32(0x06087FF8u);  // 06087EF2 mov.l 0x06087FF8,r5
    c.r[1] = ld32(0x06087FFCu);  // 06087EF4 mov.l 0x06087FFC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06087EF6 mov.l r1,@-r15
    c.r[0] = ld32(0x06088000u);  // 06087EF8 mov.l 0x06088000,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087EFEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087EFEu) return; }  // 06087EFA jsr @r0 ; mov r2,r4
    c.r[0] = ld32(0x06088004u);  // 06087EFE mov.l 0x06088004,r0
    c.r[6] = 0x0u;  // 06087F00 mov #0,r6
    c.r[4] = ld32(c.r[9]);  // 06087F02 mov.l @r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06087F08u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F08u) return; }  // 06087F04 jsr @r0 ; mov r8,r5
    c.r[1] = ld32(0x06088008u);  // 06087F08 mov.l 0x06088008,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F0Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F0Eu) return; }  // 06087F0A jsr @r1 ; nop
    c.r[15] += 8;  // 06087F0E add #8,r15
    c.r[2] = ld32(0x0608800Cu);  // 06087F10 mov.l 0x0608800C,r2
    c.r[3] = 0x0u;  // 06087F12 mov #0,r3
L_06087F14:
    st32(c.r[10], c.r[3]);  // 06087F14 mov.l r3,@r10
    c.r[10] += 4;  // 06087F16 add #4,r10
    c.r[1] = c.r[2];  // 06087F18 mov r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06087F1A tst r1,r1
    { const bool k = !c.t; c.r[2] -= 1; if (k) { SH2_POLL(c); goto L_06087F14; } }  // 06087F1C bf/s 0x06087F14 ; add #-1,r2
    c.r[1] = ld32(0x06087FECu);  // 06087F20 mov.l 0x06087FEC,r1
    c.r[0] = ld32(0x06088010u);  // 06087F22 mov.l 0x06088010,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06087F28u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F28u) return; }  // 06087F24 jsr @r0 ; mov.l @r1,r4
    c.t = c.r[0] == 0x2u;  // 06087F28 cmp/eq #2,r0
    if (!c.t) { goto L_06087F32; }  // 06087F2A bf 0x06087F32
    c.r[1] = ld32(0x06088014u);  // 06087F2C mov.l 0x06088014,r1
    goto L_06087F34;  // 06087F2E bra 0x06087F34 ; nop
L_06087F32:
    c.r[1] = ld32(0x06088018u);  // 06087F32 mov.l 0x06088018,r1
L_06087F34:
    { const uint32_t x = c.r[1]; c.pr = 0x06087F38u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F38u) return; }  // 06087F34 jsr @r1 ; mov #0,r9
    c.r[1] = ld32(0x0608801Cu);  // 06087F38 mov.l 0x0608801C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F3Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F3Eu) return; }  // 06087F3A jsr @r1 ; nop
    c.r[8] = ld32(0x06087FCCu);  // 06087F3E mov.l 0x06087FCC,r8
    c.r[1] = ld32(0x06088020u);  // 06087F40 mov.l 0x06088020,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F46u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F46u) return; }  // 06087F42 jsr @r1 ; mov.l @r8,r4
    st32(c.r[8], c.r[9]);  // 06087F46 mov.l r9,@r8
    c.r[8] = ld32(0x06087FECu);  // 06087F48 mov.l 0x06087FEC,r8
    c.r[1] = ld32(0x06088024u);  // 06087F4A mov.l 0x06088024,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F50u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F50u) return; }  // 06087F4C jsr @r1 ; mov.l @r8,r4
    st32(c.r[8], c.r[9]);  // 06087F50 mov.l r9,@r8
    c.r[10] = ld32(0x06087FC0u);  // 06087F52 mov.l 0x06087FC0,r10
    c.r[4] = ld32(c.r[10]);  // 06087F54 mov.l @r10,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06087F56 tst r4,r4
    if (c.t) { goto L_06087F60; }  // 06087F58 bt 0x06087F60
    c.r[1] = ld32(0x06088028u);  // 06087F5A mov.l 0x06088028,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F60u) return; }  // 06087F5C jsr @r1 ; nop
L_06087F60:
    c.r[8] = ld32(0x06087FB4u);  // 06087F60 mov.l 0x06087FB4,r8
    c.r[1] = ld32(0x06088028u);  // 06087F62 mov.l 0x06088028,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F68u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F68u) return; }  // 06087F64 jsr @r1 ; mov.l @r8,r4
    c.r[1] = ld32(0x06087FA8u);  // 06087F68 mov.l 0x06087FA8,r1
    c.r[4] = ld32(c.r[1]);  // 06087F6A mov.l @r1,r4
    c.r[1] = ld32(0x06087FB8u);  // 06087F6C mov.l 0x06087FB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F72u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F72u) return; }  // 06087F6E jsr @r1 ; nop
    c.r[1] = ld32(0x06087FA0u);  // 06087F72 mov.l 0x06087FA0,r1
    c.r[4] = ld32(c.r[1]);  // 06087F74 mov.l @r1,r4
    c.r[1] = ld32(0x06087FBCu);  // 06087F76 mov.l 0x06087FBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06087F7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06087F7Cu) return; }  // 06087F78 jsr @r1 ; nop
    st32(c.r[10], c.r[9]);  // 06087F7C mov.l r9,@r10
    st32(c.r[8], c.r[9]); goto L_06087F86;  // 06087F7E bra 0x06087F86 ; mov.l r9,@r8
L_06087F82:
    c.r[0] = 0xFFFFFFFFu; goto L_06087F88;  // 06087F82 bra 0x06087F88 ; mov #-1,r0
L_06087F86:
    c.r[0] = 0x0u;  // 06087F86 mov #0,r0
L_06087F88:
    c.r[15] = c.r[14];  // 06087F88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06087F8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06087F8C mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06087F8E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06087F90 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06087F92 rts ; mov.l @r15+,r8
}

void f_0608802C(SH2Context& c) {
    ran[1909] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608802C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608802E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06088030 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088032 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088034 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06088036 mov r15,r14
    c.r[9] = c.r[4];  // 06088038 mov r4,r9
    c.r[8] = 0x0u;  // 0608803A mov #0,r8
    c.r[10] = ld32(0x06088068u);  // 0608803C mov.l 0x06088068,r10
L_0608803E:
    { const uint32_t x = c.r[10]; c.pr = 0x06088042u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088042u) return; }  // 0608803E jsr @r10 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088042 tst r0,r0
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= 0; if (k) { goto L_06088058; } }  // 06088044 bt/s 0x06088058 ; cmp/pz r0
    { const bool k = !c.t; c.r[8] += 1; if (k) { goto L_06088058; } }  // 06088048 bf/s 0x06088058 ; add #1,r8
    c.r[1] = ld32(0x0608806Cu);  // 0608804C mov.l 0x0608806C,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0608804E cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { SH2_POLL(c); goto L_0608803E; } }  // 06088050 bf/s 0x0608803E ; mov #0,r0
    c.r[15] = c.r[14]; goto L_0608805C;  // 06088054 bra 0x0608805C ; mov r14,r15
L_06088058:
    c.r[0] = 0x1u;  // 06088058 mov #1,r0
    c.r[15] = c.r[14];  // 0608805A mov r14,r15
L_0608805C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608805C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608805E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088060 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088062 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088064 rts ; mov.l @r15+,r8
}

void f_06088070(SH2Context& c) {
    ran[1910] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088070 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088072 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06088074 mov r15,r14
    c.r[0] = c.r[6];  // 06088076 mov r6,r0
    c.r[3] = ld32(0x060880A8u);  // 06088078 mov.l 0x060880A8,r3
    c.r[2] = ld32(0x060880ACu);  // 0608807A mov.l 0x060880AC,r2
    c.r[1] = ld32(0x060880B0u);  // 0608807C mov.l 0x060880B0,r1
    c.r[2] |= c.r[1];  // 0608807E or r1,r2
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06088080 cmp/eq #-1,r0
    { const bool k = c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06088090; } }  // 06088082 bt/s 0x06088090 ; mov.l r2,@r3
    c.r[1] = ld32(0x060880B4u);  // 06088086 mov.l 0x060880B4,r1
    c.r[2] = 0x1u;  // 06088088 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608808A mov.l r2,@r1
    st32(c.r[1] + 4, c.r[0]);  // 0608808C mov.l r0,@(4,r1)
    st32(c.r[1] + 8, c.r[5]);  // 0608808E mov.l r5,@(8,r1)
L_06088090:
    c.r[6] = ld32(0x060880B4u);  // 06088090 mov.l 0x060880B4,r6
    c.r[5] = ld32(0x060880B8u);  // 06088092 mov.l 0x060880B8,r5
    c.r[0] = ld32(0x060880BCu);  // 06088094 mov.l 0x060880BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608809Au; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608809Au) return; }  // 06088096 jsr @r0 ; mov #2,r4
    c.r[1] = ld32(0x060880C0u);  // 0608809A mov.l 0x060880C0,r1
    st32(c.r[1], c.r[0]);  // 0608809C mov.l r0,@r1
    c.r[15] = c.r[14];  // 0608809E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060880A0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060880A2 rts ; mov.l @r15+,r14
}

void f_060880C4(SH2Context& c) {
    ran[1911] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060880C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060880C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060880C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060880CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060880CC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060880CE mov r15,r14
    c.r[8] = c.r[4];  // 060880D0 mov r4,r8
    c.r[0] = ld32(0x06088108u);  // 060880D2 mov.l 0x06088108,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060880D8u; c.r[9] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060880D8u) return; }  // 060880D4 jsr @r0 ; mov r5,r9
    c.r[10] = ld32(0x0608810Cu);  // 060880D8 mov.l 0x0608810C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x060880DEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060880DEu) return; }  // 060880DA jsr @r10 ; mov r8,r4
    c.t = (int32_t)c.r[9] > 0;  // 060880DE cmp/pl r9
    if (!c.t) { goto L_060880F4; }  // 060880E0 bf 0x060880F4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088106u);  // 060880E2 mov.w 0x06088106,r1
    c.r[9] += c.r[1];  // 060880E4 add r1,r9
    c.r[1] = ld32(0x06088110u);  // 060880E6 mov.l 0x06088110,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060880ECu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060880ECu) return; }  // 060880E8 jsr @r1 ; mov r9,r4
    c.r[5] = c.r[4];  // 060880EC mov r4,r5
    c.r[0] = ld32(0x06088114u);  // 060880EE mov.l 0x06088114,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060880F4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060880F4u) return; }  // 060880F0 jsr @r0 ; mov r8,r4
L_060880F4:
    { const uint32_t x = c.r[10]; c.pr = 0x060880F8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060880F8u) return; }  // 060880F4 jsr @r10 ; mov r8,r4
    c.r[15] = c.r[14];  // 060880F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060880FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060880FC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060880FE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088100 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088102 rts ; mov.l @r15+,r8
}

void f_06088118(SH2Context& c) {
    ran[1912] = 1;
    c.r[12] = ld32(c.r[0]);  // 06088118 mov.l @(0,r0),r12
    ;  // 0608811A nop
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608811C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608811E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06088120 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06088122 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06088124 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088126 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088128 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608812A add #-16,r15
    c.r[14] = c.r[15];  // 0608812C mov r15,r14
    c.r[3] = 0x0u;  // 0608812E mov #0,r3
    c.r[9] = c.r[4];  // 06088130 mov r4,r9
    c.r[2] = ld32(0x06088214u);  // 06088132 mov.l 0x06088214,r2
    c.r[1] = ld32(0x06088218u);  // 06088134 mov.l 0x06088218,r1
    st32(c.r[1], c.r[3]);  // 06088136 mov.l r3,@r1
    st32(c.r[2], c.r[3]);  // 06088138 mov.l r3,@r2
    c.r[8] = ld32(0x0608821Cu);  // 0608813A mov.l 0x0608821C,r8
    c.r[10] = ld32(0x06088220u);  // 0608813C mov.l 0x06088220,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06088142u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088142u) return; }  // 0608813E jsr @r10 ; mov r8,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088142 tst r0,r0
    if (!c.t) { goto L_06088148; }  // 06088144 bf 0x06088148
    c.r[9] += 1;  // 06088146 add #1,r9
L_06088148:
    c.r[11] = c.r[8];  // 06088148 mov r8,r11
    c.r[12] = ld32(0x06088224u);  // 0608814A mov.l 0x06088224,r12
    c.r[5] = c.r[11];  // 0608814C mov r11,r5
L_0608814E:
    { const uint32_t x = c.r[10]; c.pr = 0x06088152u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088152u) return; }  // 0608814E jsr @r10 ; mov r9,r4
    c.r[8] = c.r[0];  // 06088152 mov r0,r8
    c.r[0] = ld32(0x06088228u);  // 06088154 mov.l 0x06088228,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608815Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608815Au) return; }  // 06088156 jsr @r0 ; mov r9,r4
    c.t = c.r[8] == c.r[0];  // 0608815A cmp/eq r0,r8
    { const bool k = c.t; c.r[5] = c.r[11]; if (k) { goto L_0608819E; } }  // 0608815C bt/s 0x0608819E ; mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06088164u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088164u) return; }  // 06088160 jsr @r10 ; mov r9,r4
    c.r[1] = c.r[0];  // 06088164 mov r0,r1
    c.r[0] = ld32(0x0608822Cu);  // 06088166 mov.l 0x0608822C,r0
    c.r[6] = c.r[1];  // 06088168 mov r1,r6
    c.r[5] = c.r[9];  // 0608816A mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088170u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088170u) return; }  // 0608816C jsr @r0 ; mov r14,r4
    c.r[5] = c.r[11];  // 06088170 mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06088176u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088176u) return; }  // 06088172 jsr @r10 ; mov r9,r4
    c.r[1] = 0x0u;  // 06088176 mov #0,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 06088178 mov.b r1,@(r0,r14)
    c.r[5] = c.r[11];  // 0608817A mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06088180u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088180u) return; }  // 0608817C jsr @r10 ; mov r9,r4
    c.r[0] += 1;  // 06088180 add #1,r0
    c.r[9] += c.r[0];  // 06088182 add r0,r9
    c.r[0] = ld32(0x06088230u);  // 06088184 mov.l 0x06088230,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608818Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608818Au) return; }  // 06088186 jsr @r0 ; mov r14,r4
    c.r[3] = c.r[0];  // 0608818A mov r0,r3
    c.r[0] = ld32(0x06088234u);  // 0608818C mov.l 0x06088234,r0
    c.r[5] = c.r[12];  // 0608818E mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088194u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088194u) return; }  // 06088190 jsr @r0 ; mov r3,r4
    c.r[0] = ld32(0x06088238u);  // 06088194 mov.l 0x06088238,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608819Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608819Au) return; }  // 06088196 jsr @r0 ; mov r12,r4
    c.r[5] = c.r[11]; SH2_POLL(c); goto L_0608814E;  // 0608819A bra 0x0608814E ; mov r11,r5
L_0608819E:
    c.r[0] = ld32(0x06088230u);  // 0608819E mov.l 0x06088230,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060881A4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881A4u) return; }  // 060881A0 jsr @r0 ; mov r9,r4
    c.r[1] = c.r[0];  // 060881A4 mov r0,r1
    c.r[8] = ld32(0x0608823Cu);  // 060881A6 mov.l 0x0608823C,r8
    c.t = (int32_t)c.r[1] >= 0;  // 060881A8 cmp/pz r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_060881FE; } }  // 060881AA bf/s 0x060881FE ; mov.l r1,@r8
    c.r[0] = ld32(0x06088240u);  // 060881AE mov.l 0x06088240,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060881B4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881B4u) return; }  // 060881B0 jsr @r0 ; mov r1,r4
    c.r[9] = c.r[0];  // 060881B4 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060881B6 tst r9,r9
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_060881FC; } }  // 060881B8 bt/s 0x060881FC ; mov #16,r5
    c.r[0] = ld32(0x06088244u);  // 060881BC mov.l 0x06088244,r0
    c.r[1] = ld32(c.r[8]);  // 060881BE mov.l @r8,r1
    c.r[4] = c.r[9];  // 060881C0 mov r9,r4
    c.r[1] += 1;  // 060881C2 add #1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060881C8u; st32(c.r[8], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881C8u) return; }  // 060881C4 jsr @r0 ; mov.l r1,@r8
    c.r[0] = ld32(0x06088248u);  // 060881C8 mov.l 0x06088248,r0
    c.r[5] = 0x0u;  // 060881CA mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060881D0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881D0u) return; }  // 060881CC jsr @r0 ; mov r9,r4
    c.r[1] = ld32(0x0608824Cu);  // 060881D0 mov.l 0x0608824C,r1
    st32(c.r[1], c.r[0]);  // 060881D2 mov.l r0,@r1
    c.r[1] = ld32(0x06088250u);  // 060881D4 mov.l 0x06088250,r1
    c.r[0] = ld32(0x06088254u);  // 060881D6 mov.l 0x06088254,r0
    c.r[6] = 0x0u;  // 060881D8 mov #0,r6
    c.r[5] = ld32(c.r[1]);  // 060881DA mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060881E0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881E0u) return; }  // 060881DC jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x06088258u);  // 060881E0 mov.l 0x06088258,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060881E6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881E6u) return; }  // 060881E2 jsr @r0 ; mov r9,r4
    c.r[8] = ld32(0x0608825Cu);  // 060881E6 mov.l 0x0608825C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060881ECu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881ECu) return; }  // 060881E8 jsr @r8 ; mov r9,r4
    c.r[0] = ld32(0x06088260u);  // 060881EC mov.l 0x06088260,r0
    c.r[5] = 0x1u;  // 060881EE mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060881F4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881F4u) return; }  // 060881F0 jsr @r0 ; mov r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060881F8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881F8u) return; }  // 060881F4 jsr @r8 ; mov r9,r4
    c.r[0] = c.r[9]; goto L_06088200;  // 060881F8 bra 0x06088200 ; mov r9,r0
L_060881FC:
    st32(c.r[8], c.r[9]);  // 060881FC mov.l r9,@r8
L_060881FE:
    c.r[0] = 0xFFFFFFFFu;  // 060881FE mov #-1,r0
L_06088200:
    c.r[14] += 16;  // 06088200 add #16,r14
    c.r[15] = c.r[14];  // 06088202 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088204 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088206 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06088208 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608820A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608820C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608820E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088210 rts ; mov.l @r15+,r8
}

void f_0608811C(SH2Context& c) {
    ran[1913] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608811C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608811E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06088120 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06088122 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06088124 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088126 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088128 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608812A add #-16,r15
    c.r[14] = c.r[15];  // 0608812C mov r15,r14
    c.r[3] = 0x0u;  // 0608812E mov #0,r3
    c.r[9] = c.r[4];  // 06088130 mov r4,r9
    c.r[2] = ld32(0x06088214u);  // 06088132 mov.l 0x06088214,r2
    c.r[1] = ld32(0x06088218u);  // 06088134 mov.l 0x06088218,r1
    st32(c.r[1], c.r[3]);  // 06088136 mov.l r3,@r1
    st32(c.r[2], c.r[3]);  // 06088138 mov.l r3,@r2
    c.r[8] = ld32(0x0608821Cu);  // 0608813A mov.l 0x0608821C,r8
    c.r[10] = ld32(0x06088220u);  // 0608813C mov.l 0x06088220,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06088142u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088142u) return; }  // 0608813E jsr @r10 ; mov r8,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088142 tst r0,r0
    if (!c.t) { goto L_06088148; }  // 06088144 bf 0x06088148
    c.r[9] += 1;  // 06088146 add #1,r9
L_06088148:
    c.r[11] = c.r[8];  // 06088148 mov r8,r11
    c.r[12] = ld32(0x06088224u);  // 0608814A mov.l 0x06088224,r12
    c.r[5] = c.r[11];  // 0608814C mov r11,r5
L_0608814E:
    { const uint32_t x = c.r[10]; c.pr = 0x06088152u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088152u) return; }  // 0608814E jsr @r10 ; mov r9,r4
    c.r[8] = c.r[0];  // 06088152 mov r0,r8
    c.r[0] = ld32(0x06088228u);  // 06088154 mov.l 0x06088228,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608815Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608815Au) return; }  // 06088156 jsr @r0 ; mov r9,r4
    c.t = c.r[8] == c.r[0];  // 0608815A cmp/eq r0,r8
    { const bool k = c.t; c.r[5] = c.r[11]; if (k) { goto L_0608819E; } }  // 0608815C bt/s 0x0608819E ; mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06088164u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088164u) return; }  // 06088160 jsr @r10 ; mov r9,r4
    c.r[1] = c.r[0];  // 06088164 mov r0,r1
    c.r[0] = ld32(0x0608822Cu);  // 06088166 mov.l 0x0608822C,r0
    c.r[6] = c.r[1];  // 06088168 mov r1,r6
    c.r[5] = c.r[9];  // 0608816A mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088170u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088170u) return; }  // 0608816C jsr @r0 ; mov r14,r4
    c.r[5] = c.r[11];  // 06088170 mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06088176u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088176u) return; }  // 06088172 jsr @r10 ; mov r9,r4
    c.r[1] = 0x0u;  // 06088176 mov #0,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 06088178 mov.b r1,@(r0,r14)
    c.r[5] = c.r[11];  // 0608817A mov r11,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06088180u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088180u) return; }  // 0608817C jsr @r10 ; mov r9,r4
    c.r[0] += 1;  // 06088180 add #1,r0
    c.r[9] += c.r[0];  // 06088182 add r0,r9
    c.r[0] = ld32(0x06088230u);  // 06088184 mov.l 0x06088230,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608818Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608818Au) return; }  // 06088186 jsr @r0 ; mov r14,r4
    c.r[3] = c.r[0];  // 0608818A mov r0,r3
    c.r[0] = ld32(0x06088234u);  // 0608818C mov.l 0x06088234,r0
    c.r[5] = c.r[12];  // 0608818E mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088194u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088194u) return; }  // 06088190 jsr @r0 ; mov r3,r4
    c.r[0] = ld32(0x06088238u);  // 06088194 mov.l 0x06088238,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608819Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608819Au) return; }  // 06088196 jsr @r0 ; mov r12,r4
    c.r[5] = c.r[11]; SH2_POLL(c); goto L_0608814E;  // 0608819A bra 0x0608814E ; mov r11,r5
L_0608819E:
    c.r[0] = ld32(0x06088230u);  // 0608819E mov.l 0x06088230,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060881A4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881A4u) return; }  // 060881A0 jsr @r0 ; mov r9,r4
    c.r[1] = c.r[0];  // 060881A4 mov r0,r1
    c.r[8] = ld32(0x0608823Cu);  // 060881A6 mov.l 0x0608823C,r8
    c.t = (int32_t)c.r[1] >= 0;  // 060881A8 cmp/pz r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_060881FE; } }  // 060881AA bf/s 0x060881FE ; mov.l r1,@r8
    c.r[0] = ld32(0x06088240u);  // 060881AE mov.l 0x06088240,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060881B4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881B4u) return; }  // 060881B0 jsr @r0 ; mov r1,r4
    c.r[9] = c.r[0];  // 060881B4 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060881B6 tst r9,r9
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_060881FC; } }  // 060881B8 bt/s 0x060881FC ; mov #16,r5
    c.r[0] = ld32(0x06088244u);  // 060881BC mov.l 0x06088244,r0
    c.r[1] = ld32(c.r[8]);  // 060881BE mov.l @r8,r1
    c.r[4] = c.r[9];  // 060881C0 mov r9,r4
    c.r[1] += 1;  // 060881C2 add #1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060881C8u; st32(c.r[8], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881C8u) return; }  // 060881C4 jsr @r0 ; mov.l r1,@r8
    c.r[0] = ld32(0x06088248u);  // 060881C8 mov.l 0x06088248,r0
    c.r[5] = 0x0u;  // 060881CA mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060881D0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881D0u) return; }  // 060881CC jsr @r0 ; mov r9,r4
    c.r[1] = ld32(0x0608824Cu);  // 060881D0 mov.l 0x0608824C,r1
    st32(c.r[1], c.r[0]);  // 060881D2 mov.l r0,@r1
    c.r[1] = ld32(0x06088250u);  // 060881D4 mov.l 0x06088250,r1
    c.r[0] = ld32(0x06088254u);  // 060881D6 mov.l 0x06088254,r0
    c.r[6] = 0x0u;  // 060881D8 mov #0,r6
    c.r[5] = ld32(c.r[1]);  // 060881DA mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060881E0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881E0u) return; }  // 060881DC jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x06088258u);  // 060881E0 mov.l 0x06088258,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060881E6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881E6u) return; }  // 060881E2 jsr @r0 ; mov r9,r4
    c.r[8] = ld32(0x0608825Cu);  // 060881E6 mov.l 0x0608825C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060881ECu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881ECu) return; }  // 060881E8 jsr @r8 ; mov r9,r4
    c.r[0] = ld32(0x06088260u);  // 060881EC mov.l 0x06088260,r0
    c.r[5] = 0x1u;  // 060881EE mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060881F4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881F4u) return; }  // 060881F0 jsr @r0 ; mov r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060881F8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060881F8u) return; }  // 060881F4 jsr @r8 ; mov r9,r4
    c.r[0] = c.r[9]; goto L_06088200;  // 060881F8 bra 0x06088200 ; mov r9,r0
L_060881FC:
    st32(c.r[8], c.r[9]);  // 060881FC mov.l r9,@r8
L_060881FE:
    c.r[0] = 0xFFFFFFFFu;  // 060881FE mov #-1,r0
L_06088200:
    c.r[14] += 16;  // 06088200 add #16,r14
    c.r[15] = c.r[14];  // 06088202 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088204 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088206 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06088208 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608820A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608820C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608820E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088210 rts ; mov.l @r15+,r8
}

void f_06088264(SH2Context& c) {
    ran[1914] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088264 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088266 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088268 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608826A mov r15,r14
    c.r[0] = ld32(0x06088284u);  // 0608826C mov.l 0x06088284,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088272u; c.r[8] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088272u) return; }  // 0608826E jsr @r0 ; mov r4,r8
    c.r[1] = ld32(0x06088288u);  // 06088272 mov.l 0x06088288,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088278u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088278u) return; }  // 06088274 jsr @r1 ; mov r8,r4
    c.r[15] = c.r[14];  // 06088278 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608827A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608827C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608827E rts ; mov.l @r15+,r8
}

void f_0608828C(SH2Context& c) {
    ran[1915] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608828C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608828E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06088290 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06088292 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06088294 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06088296 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088298 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608829A sts.l pr,@-r15
    c.r[15] -= 4;  // 0608829C add #-4,r15
    c.r[14] = c.r[15];  // 0608829E mov r15,r14
    c.r[10] = c.r[4];  // 060882A0 mov r4,r10
    c.r[12] = c.r[5];  // 060882A2 mov r5,r12
    c.r[11] = c.r[6];  // 060882A4 mov r6,r11
    c.r[3] = 0x0u;  // 060882A6 mov #0,r3
    c.t = (c.r[11] & c.r[11]) == 0;  // 060882A8 tst r11,r11
    { const bool k = !c.t; st32(c.r[14], c.r[3]); if (k) { goto L_060882B2; } }  // 060882AA bf/s 0x060882B2 ; mov.l r3,@r14
    c.r[0] = 0x0u; goto L_06088486;  // 060882AE bra 0x06088486 ; mov #0,r0
L_060882B2:
    c.r[9] = ld32(0x060883DCu);  // 060882B2 mov.l 0x060883DC,r9
    c.r[2] = ld32(c.r[9]);  // 060882B4 mov.l @r9,r2
    c.r[1] = ld32(0x060883E0u);  // 060882B6 mov.l 0x060883E0,r1
    c.r[1] = ld32(c.r[1]);  // 060882B8 mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 060882BA cmp/eq r1,r2
    { const bool k = c.t; c.r[1] -= c.r[2]; if (k) { goto L_060882E8; } }  // 060882BC bt/s 0x060882E8 ; sub r2,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 060882C0 cmp/ge r1,r11
    { const bool k = !c.t; c.r[8] = c.r[11]; if (k) { goto L_060882C8; } }  // 060882C2 bf/s 0x060882C8 ; mov r11,r8
    c.r[8] = c.r[1];  // 060882C6 mov r1,r8
L_060882C8:
    c.t = (c.r[12] & c.r[12]) == 0;  // 060882C8 tst r12,r12
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_060882DC; } }  // 060882CA bt/s 0x060882DC ; mov r8,r6
    c.r[1] = ld32(0x060883E4u);  // 060882CE mov.l 0x060883E4,r1
    c.r[5] = ld32(c.r[1]);  // 060882D0 mov.l @r1,r5
    c.r[4] = c.r[12];  // 060882D2 mov r12,r4
    c.r[1] = ld32(0x060883E8u);  // 060882D4 mov.l 0x060883E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060882DAu; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060882DAu) return; }  // 060882D6 jsr @r1 ; add r2,r5
    c.r[12] += c.r[8];  // 060882DA add r8,r12
L_060882DC:
    st32(c.r[14], c.r[8]);  // 060882DC mov.l r8,@r14
    c.r[1] = ld32(c.r[9]);  // 060882DE mov.l @r9,r1
    c.r[1] += c.r[8];  // 060882E0 add r8,r1
    st32(c.r[9], c.r[1]);  // 060882E2 mov.l r1,@r9
    c.r[3] = ld32(c.r[14]);  // 060882E4 mov.l @r14,r3
    c.r[11] -= c.r[3];  // 060882E6 sub r3,r11
L_060882E8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060883D6u);  // 060882E8 mov.w 0x060883D6,r1
    c.t = c.r[11] > c.r[1];  // 060882EA cmp/hi r1,r11
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_060882F4; } }  // 060882EC bt/s 0x060882F4 ; tst r11,r11
    goto L_06088482;  // 060882F0 bra 0x06088482 ; nop
L_060882F4:
    c.r[1] = 0x3u;  // 060882F4 mov #3,r1
    c.r[1] &= c.r[12];  // 060882F6 and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060882F8 tst r1,r1
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06088302; } }  // 060882FA bt/s 0x06088302 ; tst r11,r11
    goto L_06088482;  // 060882FE bra 0x06088482 ; nop
L_06088302:
    c.r[9] = c.r[11];  // 06088302 mov r11,r9
    c.r[9] >>= 8;  // 06088304 shlr8 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06088306 shlr r9
    c.r[9] >>= 2;  // 06088308 shlr2 r9
    c.r[9] <<= 8;  // 0608830A shll8 r9
    c.r[9] += c.r[9];  // 0608830C add r9,r9
    c.r[9] <<= 2;  // 0608830E shll2 r9
    c.t = (c.r[12] & c.r[12]) == 0;  // 06088310 tst r12,r12
    if (!c.t) { goto L_06088328; }  // 06088312 bf 0x06088328
    c.r[1] = ld32(0x060883ECu);  // 06088314 mov.l 0x060883EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608831Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608831Au) return; }  // 06088316 jsr @r1 ; mov r9,r4
    c.r[5] = c.r[4];  // 0608831A mov r4,r5
    c.r[0] = ld32(0x060883F0u);  // 0608831C mov.l 0x060883F0,r0
    c.r[6] = 0x1u;  // 0608831E mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06088324u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088324u) return; }  // 06088320 jsr @r0 ; mov r10,r4
    c.r[8] = c.r[9]; goto L_06088384;  // 06088324 bra 0x06088384 ; mov r9,r8
L_06088328:
    c.r[0] = ld32(0x060883F4u);  // 06088328 mov.l 0x060883F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608832Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608832Eu) return; }  // 0608832A jsr @r0 ; mov r10,r4
    c.r[13] = c.r[0];  // 0608832E mov r0,r13
    c.r[1] = ld32(0x060883ECu);  // 06088330 mov.l 0x060883EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088336u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088336u) return; }  // 06088332 jsr @r1 ; mov r9,r4
    c.r[5] = c.r[4];  // 06088336 mov r4,r5
    c.r[7] = c.r[9];  // 06088338 mov r9,r7
    c.r[6] = c.r[12];  // 0608833A mov r12,r6
    c.r[3] = ld32(0x060883F8u);  // 0608833C mov.l 0x060883F8,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06088342u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088342u) return; }  // 0608833E jsr @r3 ; mov r10,r4
    c.r[8] = c.r[0];  // 06088342 mov r0,r8
    c.t = (int32_t)c.r[8] >= 0;  // 06088344 cmp/pz r8
    { const bool k = c.t; c.t = c.r[8] == c.r[9]; if (k) { goto L_06088380; } }  // 06088346 bt/s 0x06088380 ; cmp/eq r9,r8
    c.r[14] += 4; goto L_06088488;  // 0608834A bra 0x06088488 ; add #4,r14
L_0608834E:
    c.r[0] = c.r[8]; goto L_06088486;  // 0608834E bra 0x06088486 ; mov r8,r0
L_06088352:
    c.r[3] = ld32(0x060883FCu);  // 06088352 mov.l 0x060883FC,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06088358u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088358u) return; }  // 06088354 jsr @r3 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088358 tst r0,r0
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_06088382; } }  // 0608835A bf/s 0x06088382 ; mov #0,r6
    c.r[5] = c.r[13];  // 0608835E mov r13,r5
    c.r[3] = ld32(0x060883F0u);  // 06088360 mov.l 0x060883F0,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06088366u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088366u) return; }  // 06088362 jsr @r3 ; mov r10,r4
    c.r[1] = ld32(0x060883ECu);  // 06088366 mov.l 0x060883EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608836Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608836Cu) return; }  // 06088368 jsr @r1 ; mov r9,r4
    c.r[5] = c.r[4];  // 0608836C mov r4,r5
    c.r[7] = c.r[9];  // 0608836E mov r9,r7
    c.r[6] = c.r[12];  // 06088370 mov r12,r6
    c.r[3] = ld32(0x060883F8u);  // 06088372 mov.l 0x060883F8,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06088378u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088378u) return; }  // 06088374 jsr @r3 ; mov r10,r4
    c.r[8] = c.r[0];  // 06088378 mov r0,r8
    c.t = (int32_t)c.r[8] >= 0;  // 0608837A cmp/pz r8
    { const bool k = !c.t; c.t = c.r[8] == c.r[9]; if (k) { SH2_POLL(c); goto L_0608834E; } }  // 0608837C bf/s 0x0608834E ; cmp/eq r9,r8
L_06088380:
    if (!c.t) { SH2_POLL(c); goto L_06088352; }  // 06088380 bf 0x06088352
L_06088382:
    c.r[12] += c.r[8];  // 06088382 add r8,r12
L_06088384:
    c.r[3] = ld32(c.r[14]);  // 06088384 mov.l @r14,r3
    c.r[11] -= c.r[8];  // 06088386 sub r8,r11
    c.r[3] += c.r[8];  // 06088388 add r8,r3
    st32(c.r[14], c.r[3]); goto L_06088480;  // 0608838A bra 0x06088480 ; mov.l r3,@r14
L_0608838E:
    c.r[0] = ld32(0x060883F4u);  // 0608838E mov.l 0x060883F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088394u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088394u) return; }  // 06088390 jsr @r0 ; mov r10,r4
    c.r[13] = c.r[0];  // 06088394 mov r0,r13
    c.r[3] = ld32(0x060883E4u);  // 06088396 mov.l 0x060883E4,r3
    c.r[6] = ld32(c.r[3]);  // 06088398 mov.l @r3,r6
    c.r[0] = ld32(0x06088400u);  // 0608839A mov.l 0x06088400,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x060883D8u);  // 0608839C mov.w 0x060883D8,r7
    c.r[5] = 0x1u;  // 0608839E mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060883A4u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060883A4u) return; }  // 060883A0 jsr @r0 ; mov r10,r4
    c.r[3] = ld32(0x060883E0u);  // 060883A4 mov.l 0x060883E0,r3
    c.t = (int32_t)c.r[0] >= 0;  // 060883A6 cmp/pz r0
    { const bool k = !c.t; st32(c.r[3], c.r[0]); if (k) { goto L_06088486; } }  // 060883A8 bf/s 0x06088486 ; mov.l r0,@r3
L_060883AC:
    c.r[3] = ld32(0x060883E0u);  // 060883AC mov.l 0x060883E0,r3
    c.r[2] = ld32(c.r[3]);  // 060883AE mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060883D8u);  // 060883B0 mov.w 0x060883D8,r1
    c.t = c.r[2] == c.r[1];  // 060883B2 cmp/eq r1,r2
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06088412; } }  // 060883B4 bf/s 0x06088412 ; mov #0,r8
    c.r[9] = 0x0u;  // 060883B8 mov #0,r9
L_060883BA:
    c.r[3] = ld32(0x06088404u);  // 060883BA mov.l 0x06088404,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060883C0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060883C0u) return; }  // 060883BC jsr @r3 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060883C0 tst r0,r0
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= 0; if (k) { goto L_0608840C; } }  // 060883C2 bt/s 0x0608840C ; cmp/pz r0
    { const bool k = !c.t; c.r[8] += 1; if (k) { goto L_0608840C; } }  // 060883C6 bf/s 0x0608840C ; add #1,r8
    c.r[1] = ld32(0x06088408u);  // 060883CA mov.l 0x06088408,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060883CC cmp/gt r1,r8
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { SH2_POLL(c); goto L_060883BA; } }  // 060883CE bf/s 0x060883BA ; tst r9,r9
    goto L_06088410;  // 060883D2 bra 0x06088410 ; nop
L_0608840C:
    c.r[9] = 0x1u;  // 0608840C mov #1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0608840E tst r9,r9
L_06088410:
    if (!c.t) { goto L_06088446; }  // 06088410 bf 0x06088446
L_06088412:
    c.r[0] = ld32(0x060884A0u);  // 06088412 mov.l 0x060884A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088418u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088418u) return; }  // 06088414 jsr @r0 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088418 tst r0,r0
    if (!c.t) { goto L_06088446; }  // 0608841A bf 0x06088446
    c.r[0] = ld32(0x060884A4u);  // 0608841C mov.l 0x060884A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088422u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088422u) return; }  // 0608841E jsr @r0 ; mov r10,r4
    c.r[0] = ld32(0x060884A8u);  // 06088422 mov.l 0x060884A8,r0
    c.r[6] = 0x0u;  // 06088424 mov #0,r6
    c.r[5] = c.r[13];  // 06088426 mov r13,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608842Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608842Cu) return; }  // 06088428 jsr @r0 ; mov r10,r4
    c.r[3] = ld32(0x060884ACu);  // 0608842C mov.l 0x060884AC,r3
    c.r[6] = ld32(c.r[3]);  // 0608842E mov.l @r3,r6
    c.r[0] = ld32(0x060884B0u);  // 06088430 mov.l 0x060884B0,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608849Cu);  // 06088432 mov.w 0x0608849C,r7
    c.r[5] = 0x1u;  // 06088434 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608843Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608843Au) return; }  // 06088436 jsr @r0 ; mov r10,r4
    c.r[3] = ld32(0x060884B4u);  // 0608843A mov.l 0x060884B4,r3
    c.t = (int32_t)c.r[0] >= 0;  // 0608843C cmp/pz r0
    { const bool k = c.t; st32(c.r[3], c.r[0]); if (k) { SH2_POLL(c); goto L_060883AC; } }  // 0608843E bt/s 0x060883AC ; mov.l r0,@r3
    c.r[14] += 4; goto L_06088488;  // 06088442 bra 0x06088488 ; add #4,r14
L_06088446:
    c.r[3] = ld32(0x060884B4u);  // 06088446 mov.l 0x060884B4,r3
    c.r[1] = ld32(c.r[3]);  // 06088448 mov.l @r3,r1
    c.t = c.r[1] >= c.r[11];  // 0608844A cmp/hs r11,r1
    { const bool k = c.t; c.r[8] = c.r[11]; if (k) { goto L_06088452; } }  // 0608844C bt/s 0x06088452 ; mov r11,r8
    c.r[8] = c.r[1];  // 06088450 mov r1,r8
L_06088452:
    c.t = (c.r[12] & c.r[12]) == 0;  // 06088452 tst r12,r12
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_06088464; } }  // 06088454 bt/s 0x06088464 ; mov r8,r6
    c.r[3] = ld32(0x060884ACu);  // 06088458 mov.l 0x060884AC,r3
    c.r[5] = ld32(c.r[3]);  // 0608845A mov.l @r3,r5
    c.r[1] = ld32(0x060884B8u);  // 0608845C mov.l 0x060884B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088462u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088462u) return; }  // 0608845E jsr @r1 ; mov r12,r4
    c.r[12] += c.r[8];  // 06088462 add r8,r12
L_06088464:
    c.r[1] = ld32(0x060884BCu);  // 06088464 mov.l 0x060884BC,r1
    st32(c.r[1], c.r[8]);  // 06088466 mov.l r8,@r1
    c.r[3] = ld32(c.r[14]);  // 06088468 mov.l @r14,r3
    c.r[11] -= c.r[8];  // 0608846A sub r8,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 0608846C tst r11,r11
    c.r[3] += c.r[8];  // 0608846E add r8,r3
    { const bool k = c.t; st32(c.r[14], c.r[3]); if (k) { goto L_06088482; } }  // 06088470 bt/s 0x06088482 ; mov.l r3,@r14
    c.r[0] = ld32(0x060884A0u);  // 06088474 mov.l 0x060884A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608847Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608847Au) return; }  // 06088476 jsr @r0 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608847A tst r0,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06088486; } }  // 0608847C bf/s 0x06088486 ; mov.l @r14,r0
L_06088480:
    c.t = (c.r[11] & c.r[11]) == 0;  // 06088480 tst r11,r11
L_06088482:
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_0608838E; } }  // 06088482 bf/s 0x0608838E ; mov.l @r14,r0
L_06088486:
    c.r[14] += 4;  // 06088486 add #4,r14
L_06088488:
    c.r[15] = c.r[14];  // 06088488 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608848A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608848C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608848E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06088490 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06088492 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088494 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088496 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088498 rts ; mov.l @r15+,r8
}

void f_060884C0(SH2Context& c) {
    ran[1916] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060884C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060884C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060884C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060884C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060884C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060884CA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060884CC mov r15,r14
    c.r[9] = c.r[4];  // 060884CE mov r4,r9
    c.r[8] = c.r[6];  // 060884D0 mov r6,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060884D2 tst r8,r8
    { const bool k = !c.t; c.r[10] = c.r[5]; if (k) { goto L_0608855C; } }  // 060884D4 bf/s 0x0608855C ; mov r5,r10
    c.r[0] = ld32(0x060885A0u);  // 060884D8 mov.l 0x060885A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060884DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060884DEu) return; }  // 060884DA jsr @r0 ; nop
    c.r[11] = ld32(0x060885A4u);  // 060884DE mov.l 0x060885A4,r11
    c.r[8] = ld32(0x060885A8u);  // 060884E0 mov.l 0x060885A8,r8
L_060884E2:
    { const uint32_t x = c.r[11]; c.pr = 0x060884E6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060884E6u) return; }  // 060884E2 jsr @r11 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060884E6 tst r0,r0
    if (!c.t) { goto L_060884F2; }  // 060884E8 bf 0x060884F2
    { const uint32_t x = c.r[8]; c.pr = 0x060884EEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060884EEu) return; }  // 060884EA jsr @r8 ; mov r9,r4
    SH2_POLL(c); goto L_060884E2;  // 060884EE bra 0x060884E2 ; nop
L_060884F2:
    c.r[11] = ld32(0x060885ACu);  // 060884F2 mov.l 0x060885AC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060884F8u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060884F8u) return; }  // 060884F4 jsr @r11 ; mov r10,r4
    c.r[5] = c.r[4];  // 060884F8 mov r4,r5
    c.r[0] = ld32(0x060885B0u);  // 060884FA mov.l 0x060885B0,r0
    c.r[6] = 0x0u;  // 060884FC mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06088502u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088502u) return; }  // 060884FE jsr @r0 ; mov r9,r4
    c.r[8] = ld32(0x060885B4u);  // 06088502 mov.l 0x060885B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06088508u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088508u) return; }  // 06088504 jsr @r8 ; mov r9,r4
    c.r[0] = ld32(0x060885B8u);  // 06088508 mov.l 0x060885B8,r0
    c.r[5] = 0x4u;  // 0608850A mov #4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088510u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088510u) return; }  // 0608850C jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x060885BCu);  // 06088510 mov.l 0x060885BC,r0
    c.r[5] = 0x0u;  // 06088512 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088518u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088518u) return; }  // 06088514 jsr @r0 ; mov r9,r4
    c.r[1] = ld32(0x060885C0u);  // 06088518 mov.l 0x060885C0,r1
    st32(c.r[1], c.r[0]);  // 0608851A mov.l r0,@r1
    { const uint32_t x = c.r[8]; c.pr = 0x06088520u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088520u) return; }  // 0608851C jsr @r8 ; mov r9,r4
    c.r[0] = ld32(0x060885C4u);  // 06088520 mov.l 0x060885C4,r0
    c.r[5] = ld32(0x060885C8u);  // 06088522 mov.l 0x060885C8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088528u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088528u) return; }  // 06088524 jsr @r0 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088528 tst r0,r0
    if (!c.t) { goto L_06088532; }  // 0608852A bf 0x06088532
    c.r[0] = ld32(0x060885A8u);  // 0608852C mov.l 0x060885A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088532u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088532u) return; }  // 0608852E jsr @r0 ; mov r9,r4
L_06088532:
    c.r[3] = ld32(0x060885CCu);  // 06088532 mov.l 0x060885CC,r3
    c.r[2] = ld32(0x060885D0u);  // 06088534 mov.l 0x060885D0,r2
    c.r[1] = 0x0u;  // 06088536 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06088538 mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 0608853A mov.l r1,@r3
    c.r[2] = ld32(0x060885D4u);  // 0608853C mov.l 0x060885D4,r2
    c.t = (int32_t)c.r[10] >= 0;  // 0608853E cmp/pz r10
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06088548; } }  // 06088540 bt/s 0x06088548 ; mov r10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608859Eu);  // 06088544 mov.w 0x0608859E,r1
    c.r[1] += c.r[10];  // 06088546 add r10,r1
L_06088548:
    { const uint32_t x = c.r[11]; c.pr = 0x0608854Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608854Cu) return; }  // 06088548 jsr @r11 ; mov r1,r4
    c.r[4] <<= 8;  // 0608854C shll8 r4
    c.r[4] += c.r[4];  // 0608854E add r4,r4
    c.r[4] <<= 2;  // 06088550 shll2 r4
    c.r[1] = c.r[10];  // 06088552 mov r10,r1
    c.r[1] -= c.r[4];  // 06088554 sub r4,r1
    st32(c.r[2], c.r[1]);  // 06088556 mov.l r1,@r2
    c.r[0] = c.r[10]; goto L_0608858E;  // 06088558 bra 0x0608858E ; mov r10,r0
L_0608855C:
    c.r[0] = c.r[8];  // 0608855C mov r8,r0
    c.t = c.r[0] == 0x1u;  // 0608855E cmp/eq #1,r0
    { const bool k = c.t; c.r[6] = c.r[10]; if (k) { goto L_06088568; } }  // 06088560 bt/s 0x06088568 ; mov r10,r6
    c.r[0] = 0xFFFFFFFFu; goto L_0608858E;  // 06088564 bra 0x0608858E ; mov #-1,r0
L_06088568:
    c.r[0] = ld32(0x060885D8u);  // 06088568 mov.l 0x060885D8,r0
    c.r[5] = 0x0u;  // 0608856A mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088570u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088570u) return; }  // 0608856C jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x060885B4u);  // 06088570 mov.l 0x060885B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088576u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088576u) return; }  // 06088572 jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x060885B0u);  // 06088576 mov.l 0x060885B0,r0
    c.r[6] = c.r[8];  // 06088578 mov r8,r6
    c.r[5] = 0x0u;  // 0608857A mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088580u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088580u) return; }  // 0608857C jsr @r0 ; mov r9,r4
    c.r[0] -= 1;  // 06088580 add #-1,r0
    c.r[1] = ld32(0x060885CCu);  // 06088582 mov.l 0x060885CC,r1
    c.r[1] = ld32(c.r[1]);  // 06088584 mov.l @r1,r1
    c.r[0] <<= 8;  // 06088586 shll8 r0
    c.r[0] += c.r[0];  // 06088588 add r0,r0
    c.r[0] <<= 2;  // 0608858A shll2 r0
    c.r[0] += c.r[1];  // 0608858C add r1,r0
L_0608858E:
    c.r[15] = c.r[14];  // 0608858E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088590 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088592 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06088594 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088596 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088598 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608859A rts ; mov.l @r15+,r8
}

void f_060885DC(SH2Context& c) {
    ran[1917] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060885DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060885DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060885E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060885E2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060885E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060885E6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060885E8 mov r15,r14
    c.r[9] = c.r[4];  // 060885EA mov r4,r9
    c.r[8] = c.r[6];  // 060885EC mov r6,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060885EE tst r8,r8
    { const bool k = !c.t; c.r[10] = c.r[5]; if (k) { goto L_06088660; } }  // 060885F0 bf/s 0x06088660 ; mov r5,r10
    c.r[0] = ld32(0x060886A0u);  // 060885F4 mov.l 0x060886A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060885FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060885FAu) return; }  // 060885F6 jsr @r0 ; nop
    c.r[11] = ld32(0x060886A4u);  // 060885FA mov.l 0x060886A4,r11
    c.r[8] = ld32(0x060886A8u);  // 060885FC mov.l 0x060886A8,r8
L_060885FE:
    { const uint32_t x = c.r[11]; c.pr = 0x06088602u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088602u) return; }  // 060885FE jsr @r11 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088602 tst r0,r0
    if (!c.t) { goto L_0608860E; }  // 06088604 bf 0x0608860E
    { const uint32_t x = c.r[8]; c.pr = 0x0608860Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608860Au) return; }  // 06088606 jsr @r8 ; mov r9,r4
    SH2_POLL(c); goto L_060885FE;  // 0608860A bra 0x060885FE ; nop
L_0608860E:
    c.r[1] = ld32(0x060886ACu);  // 0608860E mov.l 0x060886AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088614u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088614u) return; }  // 06088610 jsr @r1 ; mov r10,r4
    c.r[5] = c.r[4];  // 06088614 mov r4,r5
    c.r[0] = ld32(0x060886B0u);  // 06088616 mov.l 0x060886B0,r0
    c.r[6] = 0x0u;  // 06088618 mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0608861Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608861Eu) return; }  // 0608861A jsr @r0 ; mov r9,r4
    c.r[8] = ld32(0x060886A4u);  // 0608861E mov.l 0x060886A4,r8
L_06088620:
    { const uint32_t x = c.r[8]; c.pr = 0x06088624u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088624u) return; }  // 06088620 jsr @r8 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088624 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { SH2_POLL(c); goto L_06088620; } }  // 06088626 bt/s 0x06088620 ; mov #0,r1
    c.r[3] = ld32(0x060886B4u);  // 0608862A mov.l 0x060886B4,r3
    c.r[2] = ld32(0x060886B8u);  // 0608862C mov.l 0x060886B8,r2
    st32(c.r[2], c.r[1]);  // 0608862E mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 06088630 mov.l r1,@r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608869Cu);  // 06088632 mov.w 0x0608869C,r2
    c.r[1] = c.r[10];  // 06088634 mov r10,r1
    c.r[1] &= c.r[2];  // 06088636 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088638 tst r1,r1
    { const bool k = c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0608865C; } }  // 0608863A bt/s 0x0608865C ; cmp/pz r10
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06088644; } }  // 0608863E bt/s 0x06088644 ; mov r10,r1
    c.r[1] += c.r[2];  // 06088642 add r2,r1
L_06088644:
    c.r[4] = c.r[1];  // 06088644 mov r1,r4
    c.r[1] = ld32(0x060886ACu);  // 06088646 mov.l 0x060886AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608864Cu; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608864Cu) return; }  // 06088648 jsr @r1 ; mov r10,r6
    c.r[4] <<= 8;  // 0608864C shll8 r4
    c.r[4] += c.r[4];  // 0608864E add r4,r4
    c.r[4] <<= 2;  // 06088650 shll2 r4
    c.r[6] -= c.r[4];  // 06088652 sub r4,r6
    c.r[0] = ld32(0x060886BCu);  // 06088654 mov.l 0x060886BC,r0
    c.r[5] = 0x0u;  // 06088656 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608865Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608865Cu) return; }  // 06088658 jsr @r0 ; mov r9,r4
L_0608865C:
    c.r[0] = c.r[10]; goto L_0608868C;  // 0608865C bra 0x0608868C ; mov r10,r0
L_06088660:
    c.r[0] = c.r[8];  // 06088660 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 06088662 cmp/eq #1,r0
    { const bool k = c.t; c.r[6] = c.r[10]; if (k) { goto L_0608866C; } }  // 06088664 bt/s 0x0608866C ; mov r10,r6
    c.r[0] = 0xFFFFFFFFu; goto L_0608868C;  // 06088668 bra 0x0608868C ; mov #-1,r0
L_0608866C:
    c.r[0] = ld32(0x060886BCu);  // 0608866C mov.l 0x060886BC,r0
    c.r[5] = 0x0u;  // 0608866E mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088674u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088674u) return; }  // 06088670 jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x060886B0u);  // 06088674 mov.l 0x060886B0,r0
    c.r[6] = c.r[8];  // 06088676 mov r8,r6
    c.r[5] = 0x0u;  // 06088678 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608867Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608867Eu) return; }  // 0608867A jsr @r0 ; mov r9,r4
    c.r[0] -= 1;  // 0608867E add #-1,r0
    c.r[1] = ld32(0x060886B4u);  // 06088680 mov.l 0x060886B4,r1
    c.r[1] = ld32(c.r[1]);  // 06088682 mov.l @r1,r1
    c.r[0] <<= 8;  // 06088684 shll8 r0
    c.r[0] += c.r[0];  // 06088686 add r0,r0
    c.r[0] <<= 2;  // 06088688 shll2 r0
    c.r[0] += c.r[1];  // 0608868A add r1,r0
L_0608868C:
    c.r[15] = c.r[14];  // 0608868C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608868E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088690 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06088692 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088694 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088696 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088698 rts ; mov.l @r15+,r8
}

void f_060886C0(SH2Context& c) {
    ran[1918] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060886C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060886C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060886C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060886C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060886C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060886CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060886CC sts.l pr,@-r15
    c.r[15] -= 8;  // 060886CE add #-8,r15
    c.r[14] = c.r[15];  // 060886D0 mov r15,r14
    c.r[1] = ld32(0x06088750u);  // 060886D2 mov.l 0x06088750,r1
    c.r[1] = ld32(c.r[1]);  // 060886D4 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060886D6 tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[4]; if (k) { goto L_0608873C; } }  // 060886D8 bt/s 0x0608873C ; mov r4,r8
    c.r[9] = ld32(0x06088754u);  // 060886DC mov.l 0x06088754,r9
    c.r[12] = ld32(0x06088758u);  // 060886DE mov.l 0x06088758,r12
    c.r[11] = 0xFFFFFFFFu;  // 060886E0 mov #-1,r11
    c.r[10] = ld32(0x0608875Cu);  // 060886E2 mov.l 0x0608875C,r10
L_060886E4:
    c.r[1] = ld32(0x06088760u);  // 060886E4 mov.l 0x06088760,r1
    c.r[5] = ld32(c.r[1]);  // 060886E6 mov.l @r1,r5
    c.r[0] = ld32(0x06088764u);  // 060886E8 mov.l 0x06088764,r0
    c.r[4] = ld32(c.r[9]);  // 060886EA mov.l @r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060886F0u; c.r[6] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060886F0u) return; }  // 060886EC jsr @r0 ; mov r8,r6
    c.t = c.r[0] == c.r[8];  // 060886F0 cmp/eq r8,r0
    if (c.t) { goto L_0608873C; }  // 060886F2 bt 0x0608873C
    c.r[5] = ld32(c.r[12]);  // 060886F4 mov.l @r12,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[11];  // 060886F6 cmp/gt r11,r5
    { const bool k = !c.t; c.r[8] -= c.r[0]; if (k) { goto L_06088706; } }  // 060886F8 bf/s 0x06088706 ; sub r0,r8
    c.r[1] = ld32(0x06088768u);  // 060886FC mov.l 0x06088768,r1
    c.r[4] = ld32(c.r[1]);  // 060886FE mov.l @r1,r4
    c.r[1] = ld32(0x0608876Cu);  // 06088700 mov.l 0x0608876C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088706u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088706u) return; }  // 06088702 jsr @r1 ; nop
L_06088706:
    c.r[1] = ld32(0x06088770u);  // 06088706 mov.l 0x06088770,r1
    c.r[4] = ld32(c.r[1]);  // 06088708 mov.l @r1,r4
    c.r[7] = 0x1u;  // 0608870A mov #1,r7
    c.r[0] = ld32(0x06088774u);  // 0608870C mov.l 0x06088774,r0
    c.r[6] = c.r[14];  // 0608870E mov r14,r6
    c.r[6] += 4;  // 06088710 add #4,r6
    c.r[5] = c.r[14];  // 06088712 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088718u; c.r[15] -= 4; st32(c.r[15], c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088718u) return; }  // 06088714 jsr @r0 ; mov.l r7,@-r15
    st32(c.r[12], c.r[0]);  // 06088718 mov.l r0,@r12
    c.t = (int32_t)c.r[0] > (int32_t)c.r[11];  // 0608871A cmp/gt r11,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0608872C; } }  // 0608871C bf/s 0x0608872C ; add #4,r15
    c.r[6] = ld32(c.r[14] + 4);  // 06088720 mov.l @(4,r14),r6
    c.r[4] = ld32(c.r[9]);  // 06088722 mov.l @r9,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06088728u; c.r[5] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088728u) return; }  // 06088724 jsr @r10 ; mov.l @r14,r5
    SH2_POLL(c); goto L_060886E4;  // 06088728 bra 0x060886E4 ; nop
L_0608872C:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608872C cmp/eq #-1,r0
    if (!c.t) { goto L_0608873C; }  // 0608872E bf 0x0608873C
    c.r[4] = ld32(c.r[9]);  // 06088730 mov.l @r9,r4
    c.r[6] = 0x0u;  // 06088732 mov #0,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06088738u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088738u) return; }  // 06088734 jsr @r10 ; mov #0,r5
    SH2_POLL(c); goto L_060886E4;  // 06088738 bra 0x060886E4 ; nop
L_0608873C:
    c.r[14] += 8;  // 0608873C add #8,r14
    c.r[15] = c.r[14];  // 0608873E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088740 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088742 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06088744 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06088746 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088748 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608874A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608874C rts ; mov.l @r15+,r8
}

void f_06088778(SH2Context& c) {
    ran[1919] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088778 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608877A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608877C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608877E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06088780 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06088782 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088784 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088786 sts.l pr,@-r15
    c.r[1] = ld32(0x06088898u);  // 06088788 mov.l 0x06088898,r1
    c.r[7] = ld32(c.r[1]);  // 0608878A mov.l @r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0608878C tst r7,r7
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06088796; } }  // 0608878E bf/s 0x06088796 ; mov r15,r14
    goto L_06088904;  // 06088792 bra 0x06088904 ; nop
L_06088796:
    c.r[1] = ld32(0x0608889Cu);  // 06088796 mov.l 0x0608889C,r1
    c.r[1] = ld32(c.r[1]);  // 06088798 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608879A tst r1,r1
    if (c.t) { goto L_060887B8; }  // 0608879C bt 0x060887B8
    c.r[1] = ld32(0x060888A0u);  // 0608879E mov.l 0x060888A0,r1
    c.r[2] = ld32(c.r[1]);  // 060887A0 mov.l @r1,r2
    c.r[3] = ld32(0x060888A4u);  // 060887A2 mov.l 0x060888A4,r3
    c.r[1] = ld32(0x060888A8u);  // 060887A4 mov.l 0x060888A8,r1
    c.t = c.r[2] == c.r[1];  // 060887A6 cmp/eq r1,r2
    { const bool k = !c.t; c.r[2] = ld32(c.r[3]); if (k) { goto L_060887B2; } }  // 060887A8 bf/s 0x060887B2 ; mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608888Cu);  // 060887AC mov.w 0x0608888C,r1
    c.r[2] += c.r[1]; goto L_060887DA;  // 060887AE bra 0x060887DA ; add r1,r2
L_060887B2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608888Eu);  // 060887B2 mov.w 0x0608888E,r1
    c.r[2] += c.r[1]; goto L_060887DA;  // 060887B4 bra 0x060887DA ; add r1,r2
L_060887B8:
    c.r[1] = ld32(0x060888A0u);  // 060887B8 mov.l 0x060888A0,r1
    c.r[2] = ld32(c.r[1]);  // 060887BA mov.l @r1,r2
    c.r[3] = ld32(0x060888A4u);  // 060887BC mov.l 0x060888A4,r3
    c.r[1] = ld32(0x060888A8u);  // 060887BE mov.l 0x060888A8,r1
    c.t = c.r[2] == c.r[1];  // 060887C0 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] = ld32(c.r[3]); if (k) { goto L_060887D6; } }  // 060887C2 bt/s 0x060887D6 ; mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088890u);  // 060887C6 mov.w 0x06088890,r1
    c.r[2] += c.r[1];  // 060887C8 add r1,r2
    c.r[1] = ld32(0x060888ACu);  // 060887CA mov.l 0x060888AC,r1
    c.r[0] = ld32(c.r[1]);  // 060887CC mov.l @r1,r0
    c.r[0] ^= 0x1u;  // 060887CE xor #1,r0
    st32(c.r[1], c.r[0]);  // 060887D0 mov.l r0,@r1
    c.r[2] += c.r[0]; goto L_060887DA;  // 060887D2 bra 0x060887DA ; add r0,r2
L_060887D6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088892u);  // 060887D6 mov.w 0x06088892,r1
    c.r[2] += c.r[1];  // 060887D8 add r1,r2
L_060887DA:
    st32(c.r[3], c.r[2]);  // 060887DA mov.l r2,@r3
    c.r[1] = ld32(0x060888B0u);  // 060887DC mov.l 0x060888B0,r1
    c.r[1] = ld32(c.r[1]);  // 060887DE mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060887E0 tst r1,r1
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0608880C; } }  // 060887E2 bt/s 0x0608880C ; mov #0,r5
    c.r[8] = ld32(0x060888B4u);  // 060887E6 mov.l 0x060888B4,r8
    c.r[1] = ld32(0x060888B8u);  // 060887E8 mov.l 0x060888B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060887EEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060887EEu) return; }  // 060887EA jsr @r1 ; mov r8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060887EE mov.b @r8,r1
    c.r[3] = ld32(0x060888BCu);  // 060887F0 mov.l 0x060888BC,r3
    c.r[2] = c.r[1] & 0xFFu;  // 060887F2 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060887F4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060887F6 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060887F8 cmp/eq r1,r2
    if (c.t) { goto L_0608880C; }  // 060887FA bt 0x0608880C
    st8(c.r[3], c.r[2]);  // 060887FC mov.b r2,@r3
    c.r[2] = ld32(0x060888C0u);  // 060887FE mov.l 0x060888C0,r2
    c.r[3] = ld32(c.r[2]);  // 06088800 mov.l @r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088894u);  // 06088802 mov.w 0x06088894,r1
    c.r[3] += c.r[1];  // 06088804 add r1,r3
    st32(c.r[2], c.r[3]);  // 06088806 mov.l r3,@r2
    c.r[1] = ld32(0x060888A4u);  // 06088808 mov.l 0x060888A4,r1
    st32(c.r[1], c.r[3]);  // 0608880A mov.l r3,@r1
L_0608880C:
    c.r[1] = ld32(0x060888A4u);  // 0608880C mov.l 0x060888A4,r1
    c.r[2] = ld32(c.r[1]);  // 0608880E mov.l @r1,r2
    c.r[3] = ld32(0x060888C4u);  // 06088810 mov.l 0x060888C4,r3
    c.r[1] = ld32(c.r[3]);  // 06088812 mov.l @r3,r1
    c.t = c.r[2] >= c.r[1];  // 06088814 cmp/hs r1,r2
    if (!c.t) { goto L_060888FA; }  // 06088816 bf 0x060888FA
    c.r[10] = c.r[3];  // 06088818 mov r3,r10
    c.r[13] = ld32(0x060888A8u);  // 0608881A mov.l 0x060888A8,r13
    c.r[12] = ld32(0x060888C8u);  // 0608881C mov.l 0x060888C8,r12
    c.r[11] = ld32(0x060888CCu);  // 0608881E mov.l 0x060888CC,r11
L_06088820:
    c.r[2] = ld32(c.r[10]);  // 06088820 mov.l @r10,r2
    c.r[0] = ld32(0x060888D0u);  // 06088822 mov.l 0x060888D0,r0
    c.r[3] = ld32(c.r[0]);  // 06088824 mov.l @r0,r3
    c.r[2] += c.r[3];  // 06088826 add r3,r2
    st32(c.r[10], c.r[2]);  // 06088828 mov.l r2,@r10
    c.r[0] = ld32(0x060888A0u);  // 0608882A mov.l 0x060888A0,r0
    c.r[1] = ld32(c.r[0]);  // 0608882C mov.l @r0,r1
    c.t = c.r[1] == c.r[13];  // 0608882E cmp/eq r13,r1
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { goto L_06088836; } }  // 06088830 bf/s 0x06088836 ; add r3,r2
    st32(c.r[10], c.r[2]);  // 06088834 mov.l r2,@r10
L_06088836:
    c.r[2] = ld32(c.r[12]);  // 06088836 mov.l @r12,r2
    c.r[1] = ld32(c.r[2]);  // 06088838 mov.l @r2,r1
    c.r[1] += 1;  // 0608883A add #1,r1
    st32(c.r[2], c.r[1]);  // 0608883C mov.l r1,@r2
    c.r[1] = ld32(c.r[2]);  // 0608883E mov.l @r2,r1
    c.r[1] = ld32(0x060888D4u);  // 06088840 mov.l 0x060888D4,r1
    c.r[9] = ld32(c.r[1]);  // 06088842 mov.l @r1,r9
    c.r[1] = ld32(0x060888D8u);  // 06088844 mov.l 0x060888D8,r1
    c.r[0] = c.r[9];  // 06088846 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06088848 mov.b @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0608884A extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0608884C tst r8,r8
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_060888EE; } }  // 0608884E bt/s 0x060888EE ; mov r9,r2
    c.r[2] += c.r[2];  // 06088852 add r2,r2
    c.r[1] = ld32(0x060888DCu);  // 06088854 mov.l 0x060888DC,r1
    c.r[0] = c.r[2];  // 06088856 mov r2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06088858 mov.w @(r0,r1),r2
    c.r[0] = ld32(0x060888D0u);  // 0608885A mov.l 0x060888D0,r0
    c.r[1] = ld32(c.r[0]);  // 0608885C mov.l @r0,r1
    c.t = c.r[1] == c.r[2];  // 0608885E cmp/eq r2,r1
    if (!c.t) { goto L_060888EE; }  // 06088860 bf 0x060888EE
    c.r[1] = ld32(c.r[12]);  // 06088862 mov.l @r12,r1
    c.r[5] = c.r[8];  // 06088864 mov r8,r5
    c.r[6] = ld32(c.r[1]);  // 06088866 mov.l @r1,r6
    c.r[7] = ld32(0x060888E0u);  // 06088868 mov.l 0x060888E0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608886Eu; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608886Eu) return; }  // 0608886A jsr @r7 ; mov r6,r4
    c.macl = c.r[0] * c.r[8];  // 0608886E mul.l r8,r0
    c.r[1] = c.macl;  // 06088870 sts macl,r1
    c.r[6] -= c.r[1];  // 06088872 sub r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06088874 tst r6,r6
    if (!c.t) { goto L_060888EE; }  // 06088876 bf 0x060888EE
    c.r[0] = ld32(0x060888A0u);  // 06088878 mov.l 0x060888A0,r0
    c.r[1] = ld32(c.r[0]);  // 0608887A mov.l @r0,r1
    c.t = c.r[1] == c.r[13];  // 0608887C cmp/eq r13,r1
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_060888E4; } }  // 0608887E bf/s 0x060888E4 ; mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06088882 mov.b @(r0,r11),r1
    c.r[2] = ld32(c.r[10]);  // 06088884 mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06088886 extu.b r1,r1
    c.r[1] += c.r[1]; goto L_060888EA;  // 06088888 bra 0x060888EA ; add r1,r1
L_060888E4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060888E4 mov.b @(r0,r11),r1
    c.r[2] = ld32(c.r[10]);  // 060888E6 mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060888E8 extu.b r1,r1
L_060888EA:
    c.r[2] += c.r[1];  // 060888EA add r1,r2
    st32(c.r[10], c.r[2]);  // 060888EC mov.l r2,@r10
L_060888EE:
    c.r[1] = ld32(0x0608893Cu);  // 060888EE mov.l 0x0608893C,r1
    c.r[2] = ld32(c.r[1]);  // 060888F0 mov.l @r1,r2
    c.r[3] = ld32(0x06088940u);  // 060888F2 mov.l 0x06088940,r3
    c.r[1] = ld32(c.r[3]);  // 060888F4 mov.l @r3,r1
    c.t = c.r[2] >= c.r[1];  // 060888F6 cmp/hs r1,r2
    if (c.t) { SH2_POLL(c); goto L_06088820; }  // 060888F8 bt 0x06088820
L_060888FA:
    c.r[1] = ld32(0x06088944u);  // 060888FA mov.l 0x06088944,r1
    c.r[7] = ld32(c.r[1]);  // 060888FC mov.l @r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 060888FE tst r7,r7
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0608892A; } }  // 06088900 bf/s 0x0608892A ; mov r14,r15
L_06088904:
    c.r[1] = ld32(0x06088948u);  // 06088904 mov.l 0x06088948,r1
    c.r[3] = ld32(c.r[1]);  // 06088906 mov.l @r1,r3
    c.r[6] = ld32(0x06088940u);  // 06088908 mov.l 0x06088940,r6
    st32(c.r[6], c.r[3]);  // 0608890A mov.l r3,@r6
    c.r[1] = ld32(0x0608894Cu);  // 0608890C mov.l 0x0608894C,r1
    c.r[2] = ld32(c.r[1]);  // 0608890E mov.l @r1,r2
    c.r[1] = ld32(0x06088950u);  // 06088910 mov.l 0x06088950,r1
    c.t = c.r[2] == c.r[1];  // 06088912 cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] += c.r[3]; if (k) { goto L_0608891A; } }  // 06088914 bf/s 0x0608891A ; add r3,r3
    st32(c.r[6], c.r[3]);  // 06088918 mov.l r3,@r6
L_0608891A:
    c.r[3] = ld32(0x06088954u);  // 0608891A mov.l 0x06088954,r3
    c.r[1] = ld32(0x06088958u);  // 0608891C mov.l 0x06088958,r1
    c.r[1] = ld32(c.r[1]);  // 0608891E mov.l @r1,r1
    c.r[2] = ld32(0x0608893Cu);  // 06088920 mov.l 0x0608893C,r2
    st32(c.r[1], c.r[7]);  // 06088922 mov.l r7,@r1
    st32(c.r[2], c.r[7]);  // 06088924 mov.l r7,@r2
    st32(c.r[3], c.r[7]);  // 06088926 mov.l r7,@r3
    c.r[15] = c.r[14];  // 06088928 mov r14,r15
L_0608892A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608892A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608892C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608892E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06088930 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06088932 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088934 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088936 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088938 rts ; mov.l @r15+,r8
}

void f_0608895C(SH2Context& c) {
    ran[1920] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608895C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608895E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088960 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088962 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06088964 mov r15,r14
    c.r[2] = ld32(0x060889C4u);  // 06088966 mov.l 0x060889C4,r2
    c.r[1] = ld32(0x060889C8u);  // 06088968 mov.l 0x060889C8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608896A mov.w @r1,r0
    c.r[9] = ld32(0x060889CCu);  // 0608896C mov.l 0x060889CC,r9
    c.r[8] = ld32(0x060889D0u);  // 0608896E mov.l 0x060889D0,r8
    c.r[0] &= 0x1u;  // 06088970 and #1,r0
    st32(c.r[2], c.r[0]);  // 06088972 mov.l r0,@r2
    c.r[2] = ld32(0x060889D4u);  // 06088974 mov.l 0x060889D4,r2
    c.r[1] = 0x0u;  // 06088976 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06088978 mov.b r1,@r2
L_0608897A:
    { const uint32_t x = c.r[9]; c.pr = 0x0608897Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608897Eu) return; }  // 0608897A jsr @r9 ; mov #0,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0608897E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088980 tst r1,r1
    if (c.t) { goto L_06088992; }  // 06088982 bt 0x06088992
    c.r[1] = ld32(c.r[8]);  // 06088984 mov.l @r8,r1
    c.r[2] = c.r[1];  // 06088986 mov r1,r2
    c.r[2] += 1;  // 06088988 add #1,r2
    st32(c.r[8], c.r[2]);  // 0608898A mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x060889C2u);  // 0608898C mov.w 0x060889C2,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608898E cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_0608897A; }  // 06088990 bf 0x0608897A
L_06088992:
    c.r[9] = ld32(0x060889D8u);  // 06088992 mov.l 0x060889D8,r9
    c.r[8] = ld32(0x060889D0u);  // 06088994 mov.l 0x060889D0,r8
L_06088996:
    { const uint32_t x = c.r[9]; c.pr = 0x0608899Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608899Au) return; }  // 06088996 jsr @r9 ; mov #0,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0608899A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608899C tst r1,r1
    if (c.t) { goto L_060889AE; }  // 0608899E bt 0x060889AE
    c.r[1] = ld32(c.r[8]);  // 060889A0 mov.l @r8,r1
    c.r[2] = c.r[1];  // 060889A2 mov r1,r2
    c.r[2] += 1;  // 060889A4 add #1,r2
    st32(c.r[8], c.r[2]);  // 060889A6 mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x060889C2u);  // 060889A8 mov.w 0x060889C2,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060889AA cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06088996; }  // 060889AC bf 0x06088996
L_060889AE:
    c.r[4] = ld32(0x060889DCu);  // 060889AE mov.l 0x060889DC,r4
    c.r[1] = ld32(0x060889E0u);  // 060889B0 mov.l 0x060889E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060889B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060889B6u) return; }  // 060889B2 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060889B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060889B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060889BA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060889BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060889BE rts ; mov.l @r15+,r8
}

void f_060889E4(SH2Context& c) {
    ran[1921] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060889E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060889E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060889E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060889EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060889EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060889EE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060889F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060889F2 sts.l pr,@-r15
    c.r[15] -= 12;  // 060889F4 add #-12,r15
    c.r[14] = c.r[15];  // 060889F6 mov r15,r14
    st32(c.r[14] + 8, c.r[4]);  // 060889F8 mov.l r4,@(8,r14)
    c.r[7] = ld32(0x06088B4Cu);  // 060889FA mov.l 0x06088B4C,r7
    c.r[6] = ld32(0x06088B50u);  // 060889FC mov.l 0x06088B50,r6
    c.r[9] = ld32(0x06088B54u);  // 060889FE mov.l 0x06088B54,r9
    c.r[5] = ld32(c.r[9]);  // 06088A00 mov.l @r9,r5
    c.r[8] = ld32(0x06088B58u);  // 06088A02 mov.l 0x06088B58,r8
    c.r[1] = ld32(0x06088B5Cu);  // 06088A04 mov.l 0x06088B5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088A0Au; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088A0Au) return; }  // 06088A06 jsr @r1 ; mov.l @r8,r4
    c.r[0] = ld32(0x06088B60u);  // 06088A0A mov.l 0x06088B60,r0
    c.r[4] = ld32(c.r[8]);  // 06088A0C mov.l @r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06088A12u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088A12u) return; }  // 06088A0E jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x06088B64u);  // 06088A12 mov.l 0x06088B64,r1
    st32(c.r[1], c.r[0]);  // 06088A14 mov.l r0,@r1
    c.r[12] = ld32(0x06088B68u);  // 06088A16 mov.l 0x06088B68,r12
    c.r[13] = ld32(0x06088B6Cu);  // 06088A18 mov.l 0x06088B6C,r13
    c.r[11] = ld32(0x06088B70u);  // 06088A1A mov.l 0x06088B70,r11
    c.r[10] = ld32(0x06088B74u);  // 06088A1C mov.l 0x06088B74,r10
    c.r[0] = ld32(0x06088B78u);  // 06088A1E mov.l 0x06088B78,r0
    c.r[7] = c.r[12];  // 06088A20 mov r12,r7
    c.r[6] = c.r[13];  // 06088A22 mov r13,r6
    c.r[4] = ld32(c.r[9]);  // 06088A24 mov.l @r9,r4
    c.r[5] = c.r[11];  // 06088A26 mov r11,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088A2Cu; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088A2Cu) return; }  // 06088A28 jsr @r0 ; mov.l r10,@-r15
    c.r[8] = c.r[0];  // 06088A2C mov r0,r8
    c.r[1] = ld32(0x06088B7Cu);  // 06088A2E mov.l 0x06088B7C,r1
    c.r[15] += 4;  // 06088A30 add #4,r15
    c.t = (c.r[8] & c.r[8]) == 0;  // 06088A32 tst r8,r8
    c.r[0] = c.t;  // 06088A34 movt r0
    c.r[0] ^= 0x1u;  // 06088A36 xor #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06088A38 tst r0,r0
    { const bool k = c.t; st32(c.r[1], c.r[0]); if (k) { goto L_06088B34; } }  // 06088A3A bt/s 0x06088B34 ; mov.l r0,@r1
    c.r[6] = c.r[14];  // 06088A3E mov r14,r6
    c.r[6] += 4;  // 06088A40 add #4,r6
    c.r[4] = ld32(c.r[9]);  // 06088A42 mov.l @r9,r4
    c.r[1] = 0x0u;  // 06088A44 mov #0,r1
    c.r[0] = ld32(0x06088B80u);  // 06088A46 mov.l 0x06088B80,r0
    c.r[7] = 0x0u;  // 06088A48 mov #0,r7
    c.r[5] = c.r[14];  // 06088A4A mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088A50u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088A50u) return; }  // 06088A4C jsr @r0 ; mov.l r1,@-r15
    c.r[1] = ld32(0x06088B84u);  // 06088A50 mov.l 0x06088B84,r1
    st32(c.r[1], c.r[0]);  // 06088A52 mov.l r0,@r1
    c.r[1] = 0xFFFFFFFFu;  // 06088A54 mov #-1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06088A56 cmp/gt r1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_06088A6A; } }  // 06088A58 bf/s 0x06088A6A ; add #4,r15
    c.r[6] = ld32(c.r[14] + 4);  // 06088A5C mov.l @(4,r14),r6
    c.r[0] = ld32(0x06088B88u);  // 06088A5E mov.l 0x06088B88,r0
    c.r[5] = ld32(c.r[14]);  // 06088A60 mov.l @r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06088A66u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088A66u) return; }  // 06088A62 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x06088B8Cu);  // 06088A66 mov.l 0x06088B8C,r1
    st32(c.r[1], c.r[0]);  // 06088A68 mov.l r0,@r1
L_06088A6A:
    c.r[9] = ld32(c.r[10]);  // 06088A6A mov.l @r10,r9
    c.r[0] = c.r[9];  // 06088A6C mov r9,r0
    c.t = c.r[0] == 0x1u;  // 06088A6E cmp/eq #1,r0
    if (!c.t) { goto L_06088AA8; }  // 06088A70 bf 0x06088AA8
    c.r[8] = ld32(c.r[11]);  // 06088A72 mov.l @r11,r8
    c.r[7] = ld32(0x06088B90u);  // 06088A74 mov.l 0x06088B90,r7
    c.r[4] = ld32(c.r[12]);  // 06088A76 mov.l @r12,r4
    { const uint32_t x = c.r[7]; c.pr = 0x06088A7Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088A7Cu) return; }  // 06088A78 jsr @r7 ; mov r8,r5
    c.r[1] = ld32(c.r[13]);  // 06088A7C mov.l @r13,r1
    c.r[7] = c.r[0];  // 06088A7E mov r0,r7
    c.t = c.r[7] == c.r[1];  // 06088A80 cmp/eq r1,r7
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_06088AA8; } }  // 06088A82 bf/s 0x06088AA8 ; mov r8,r0
    c.t = c.r[0] == 0x2u;  // 06088A86 cmp/eq #2,r0
    { const bool k = !c.t; c.r[15] -= 4; st32(c.r[15], c.r[7]); if (k) { goto L_06088A9A; } }  // 06088A88 bf/s 0x06088A9A ; mov.l r7,@-r15
    c.r[6] = ld32(0x06088B94u);  // 06088A8C mov.l 0x06088B94,r6
    c.r[5] = ld32(0x06088B98u);  // 06088A8E mov.l 0x06088B98,r5
    c.r[4] = ld32(0x06088B9Cu);  // 06088A90 mov.l 0x06088B9C,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088A92 mov.l r8,@-r15
    c.r[0] = ld32(0x06088BA0u);  // 06088A94 mov.l 0x06088BA0,r0
    c.r[7] = 0x8u; goto L_06088AD8;  // 06088A96 bra 0x06088AD8 ; mov #8,r7
L_06088A9A:
    c.r[6] = ld32(0x06088B94u);  // 06088A9A mov.l 0x06088B94,r6
    c.r[4] = ld32(0x06088B98u);  // 06088A9C mov.l 0x06088B98,r4
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06088A9E mov.l r9,@-r15
    c.r[0] = ld32(0x06088BA0u);  // 06088AA0 mov.l 0x06088BA0,r0
    c.r[7] = 0x8u;  // 06088AA2 mov #8,r7
    c.r[5] = 0x0u; goto L_06088AD8;  // 06088AA4 bra 0x06088AD8 ; mov #0,r5
L_06088AA8:
    c.r[1] = ld32(0x06088B70u);  // 06088AA8 mov.l 0x06088B70,r1
    c.r[2] = ld32(c.r[1]);  // 06088AAA mov.l @r1,r2
    c.r[0] = c.r[2];  // 06088AAC mov r2,r0
    c.t = c.r[0] == 0x2u;  // 06088AAE cmp/eq #2,r0
    { const bool k = !c.t; c.r[7] = 0x10u; if (k) { goto L_06088AC6; } }  // 06088AB0 bf/s 0x06088AC6 ; mov #16,r7
    c.r[6] = ld32(0x06088B94u);  // 06088AB4 mov.l 0x06088B94,r6
    c.r[5] = ld32(0x06088B98u);  // 06088AB6 mov.l 0x06088B98,r5
    c.r[4] = ld32(0x06088BA4u);  // 06088AB8 mov.l 0x06088BA4,r4
    c.r[1] = ld32(0x06088B6Cu);  // 06088ABA mov.l 0x06088B6C,r1
    c.r[1] = ld32(c.r[1]);  // 06088ABC mov.l @r1,r1
    c.r[0] = ld32(0x06088BA0u);  // 06088ABE mov.l 0x06088BA0,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06088AC0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]); goto L_06088AD8;  // 06088AC2 bra 0x06088AD8 ; mov.l r2,@-r15
L_06088AC6:
    c.r[6] = ld32(0x06088B94u);  // 06088AC6 mov.l 0x06088B94,r6
    c.r[4] = ld32(0x06088B98u);  // 06088AC8 mov.l 0x06088B98,r4
    c.r[1] = ld32(0x06088B6Cu);  // 06088ACA mov.l 0x06088B6C,r1
    c.r[1] = ld32(c.r[1]);  // 06088ACC mov.l @r1,r1
    c.r[0] = ld32(0x06088BA0u);  // 06088ACE mov.l 0x06088BA0,r0
    c.r[5] = 0x0u;  // 06088AD0 mov #0,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06088AD2 mov.l r1,@-r15
    c.r[1] = 0x1u;  // 06088AD4 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06088AD6 mov.l r1,@-r15
L_06088AD8:
    { const uint32_t x = c.r[0]; c.pr = 0x06088ADCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088ADCu) return; }  // 06088AD8 jsr @r0 ; nop
    c.r[1] = ld32(0x06088BA8u);  // 06088ADC mov.l 0x06088BA8,r1
    st32(c.r[1], c.r[0]);  // 06088ADE mov.l r0,@r1
    c.r[0] = ld32(c.r[14] + 8);  // 06088AE0 mov.l @(8,r14),r0
    c.t = (int32_t)c.r[0] > 0;  // 06088AE2 cmp/pl r0
    { const bool k = !c.t; c.r[15] += 8; if (k) { goto L_06088B2A; } }  // 06088AE4 bf/s 0x06088B2A ; add #8,r15
    c.r[1] = ld32(0x06088B6Cu);  // 06088AE8 mov.l 0x06088B6C,r1
    c.r[1] = ld32(c.r[1]);  // 06088AEA mov.l @r1,r1
    c.macl = c.r[0] * c.r[1];  // 06088AEC mul.l r1,r0
    c.r[7] = ld32(0x06088B90u);  // 06088AEE mov.l 0x06088B90,r7
    c.r[1] = ld32(0x06088B50u);  // 06088AF0 mov.l 0x06088B50,r1
    c.r[5] = ld32(c.r[1]);  // 06088AF2 mov.l @r1,r5
    { const uint32_t x = c.r[7]; c.pr = 0x06088AF8u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088AF8u) return; }  // 06088AF4 jsr @r7 ; sts macl,r4
    c.r[8] = c.r[0];  // 06088AF8 mov r0,r8
    c.r[1] = ld32(0x06088B54u);  // 06088AFA mov.l 0x06088B54,r1
    c.r[5] = 0xFFFFFFFFu;  // 06088AFC mov #-1,r5
    c.r[0] = ld32(0x06088BACu);  // 06088AFE mov.l 0x06088BAC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06088B04u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088B04u) return; }  // 06088B00 jsr @r0 ; mov.l @r1,r4
    c.r[1] = c.r[0];  // 06088B04 mov r0,r1
    c.r[8] -= c.r[1];  // 06088B06 sub r1,r8
    c.t = (int32_t)c.r[8] > 0;  // 06088B08 cmp/pl r8
    if (!c.t) { goto L_06088B2A; }  // 06088B0A bf 0x06088B2A
    c.r[1] = ld32(0x06088BB0u);  // 06088B0C mov.l 0x06088BB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088B12u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088B12u) return; }  // 06088B0E jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06088BA8u);  // 06088B12 mov.l 0x06088BA8,r1
    c.r[4] = ld32(c.r[1]);  // 06088B14 mov.l @r1,r4
    c.r[7] = 0xFFFFFFFFu;  // 06088B16 mov #-1,r7
    c.r[6] = 0x0u;  // 06088B18 mov #0,r6
    c.r[1] = 0x0u;  // 06088B1A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06088B1C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06088B1E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06088B20 mov.l r1,@-r15
    c.r[1] = ld32(0x06088BB4u);  // 06088B22 mov.l 0x06088BB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088B28u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088B28u) return; }  // 06088B24 jsr @r1 ; mov #0,r5
    c.r[15] += 12;  // 06088B28 add #12,r15
L_06088B2A:
    c.r[1] = ld32(0x06088B4Cu);  // 06088B2A mov.l 0x06088B4C,r1
    c.r[4] = ld32(c.r[1]);  // 06088B2C mov.l @r1,r4
    c.r[1] = ld32(0x06088BB0u);  // 06088B2E mov.l 0x06088BB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088B34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088B34u) return; }  // 06088B30 jsr @r1 ; nop
L_06088B34:
    c.r[14] += 12;  // 06088B34 add #12,r14
    c.r[15] = c.r[14];  // 06088B36 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088B38 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088B3A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06088B3C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06088B3E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06088B40 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06088B42 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088B44 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088B46 rts ; mov.l @r15+,r8
}

void f_06088BB8(SH2Context& c) {
    ran[1922] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088BB8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06088BBA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088BBC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088BBE sts.l pr,@-r15
    c.r[1] = ld32(0x06088BF4u);  // 06088BC0 mov.l 0x06088BF4,r1
    c.r[1] = ld32(c.r[1]);  // 06088BC2 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088BC4 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06088BE6; } }  // 06088BC6 bt/s 0x06088BE6 ; mov r15,r14
    c.r[9] = ld32(0x06088BF8u);  // 06088BCA mov.l 0x06088BF8,r9
    c.r[8] = ld32(0x06088BFCu);  // 06088BCC mov.l 0x06088BFC,r8
L_06088BCE:
    { const uint32_t x = c.r[9]; c.pr = 0x06088BD2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088BD2u) return; }  // 06088BCE jsr @r9 ; mov #0,r4
    c.r[1] = c.r[0] & 0xFFu;  // 06088BD2 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088BD4 tst r1,r1
    if (c.t) { goto L_06088BE6; }  // 06088BD6 bt 0x06088BE6
    c.r[1] = ld32(c.r[8]);  // 06088BD8 mov.l @r8,r1
    c.r[2] = c.r[1];  // 06088BDA mov r1,r2
    c.r[2] += 1;  // 06088BDC add #1,r2
    st32(c.r[8], c.r[2]);  // 06088BDE mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06088BF2u);  // 06088BE0 mov.w 0x06088BF2,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06088BE2 cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06088BCE; }  // 06088BE4 bf 0x06088BCE
L_06088BE6:
    c.r[15] = c.r[14];  // 06088BE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088BE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088BEA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088BEC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088BEE rts ; mov.l @r15+,r8
}

void f_06088C00(SH2Context& c) {
    ran[1923] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088C00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06088C02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088C04 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088C06 sts.l pr,@-r15
    c.r[1] = ld32(0x06088C40u);  // 06088C08 mov.l 0x06088C40,r1
    c.r[1] = ld32(c.r[1]);  // 06088C0A mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088C0C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06088C32; } }  // 06088C0E bt/s 0x06088C32 ; mov r15,r14
    c.r[9] = ld32(0x06088C44u);  // 06088C12 mov.l 0x06088C44,r9
    c.r[8] = ld32(0x06088C48u);  // 06088C14 mov.l 0x06088C48,r8
L_06088C16:
    c.r[5] = ld32(0x06088C4Cu);  // 06088C16 mov.l 0x06088C4C,r5
    c.r[4] = ld32(0x06088C50u);  // 06088C18 mov.l 0x06088C50,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06088C1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088C1Eu) return; }  // 06088C1A jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06088C1E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088C20 tst r1,r1
    if (c.t) { goto L_06088C32; }  // 06088C22 bt 0x06088C32
    c.r[1] = ld32(c.r[8]);  // 06088C24 mov.l @r8,r1
    c.r[2] = c.r[1];  // 06088C26 mov r1,r2
    c.r[2] += 1;  // 06088C28 add #1,r2
    st32(c.r[8], c.r[2]);  // 06088C2A mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06088C3Eu);  // 06088C2C mov.w 0x06088C3E,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06088C2E cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06088C16; }  // 06088C30 bf 0x06088C16
L_06088C32:
    c.r[15] = c.r[14];  // 06088C32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088C34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088C36 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088C38 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088C3A rts ; mov.l @r15+,r8
}

void f_06088C54(SH2Context& c) {
    ran[1924] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088C54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06088C56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088C58 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088C5A sts.l pr,@-r15
    c.r[1] = ld32(0x06088D30u);  // 06088C5C mov.l 0x06088D30,r1
    c.r[1] = ld32(c.r[1]);  // 06088C5E mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088C60 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06088C6A; } }  // 06088C62 bf/s 0x06088C6A ; mov r15,r14
    goto L_06088DA8;  // 06088C66 bra 0x06088DA8 ; nop
L_06088C6A:
    c.r[9] = ld32(0x06088D34u);  // 06088C6A mov.l 0x06088D34,r9
    c.r[8] = ld32(0x06088D38u);  // 06088C6C mov.l 0x06088D38,r8
L_06088C6E:
    { const uint32_t x = c.r[9]; c.pr = 0x06088C72u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088C72u) return; }  // 06088C6E jsr @r9 ; mov #15,r4
    c.r[1] = c.r[0] & 0xFFu;  // 06088C72 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088C74 tst r1,r1
    if (c.t) { goto L_06088C86; }  // 06088C76 bt 0x06088C86
    c.r[1] = ld32(c.r[8]);  // 06088C78 mov.l @r8,r1
    c.r[2] = c.r[1];  // 06088C7A mov r1,r2
    c.r[2] += 1;  // 06088C7C add #1,r2
    st32(c.r[8], c.r[2]);  // 06088C7E mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06088D22u);  // 06088C80 mov.w 0x06088D22,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06088C82 cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06088C6E; }  // 06088C84 bf 0x06088C6E
L_06088C86:
    c.r[1] = ld32(0x06088D3Cu);  // 06088C86 mov.l 0x06088D3C,r1
    c.r[4] = ld32(c.r[1]);  // 06088C88 mov.l @r1,r4
    c.r[2] = ld32(0x06088D40u);  // 06088C8A mov.l 0x06088D40,r2
    c.r[7] = ld32(0x06088D44u);  // 06088C8C mov.l 0x06088D44,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06088C92u; c.r[5] = ld32(c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088C92u) return; }  // 06088C8E jsr @r7 ; mov.l @r2,r5
    c.r[1] = ld32(0x06088D48u);  // 06088C92 mov.l 0x06088D48,r1
    c.r[1] = ld32(c.r[1]);  // 06088C94 mov.l @r1,r1
    c.t = c.r[0] == c.r[1];  // 06088C96 cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = 0x10u; if (k) { goto L_06088CA2; } }  // 06088C98 bf/s 0x06088CA2 ; mov #16,r1
    c.r[2] = ld32(0x06088D4Cu);  // 06088C9C mov.l 0x06088D4C,r2
    st8(c.r[2], c.r[1]); goto L_06088CA8;  // 06088C9E bra 0x06088CA8 ; mov.b r1,@r2
L_06088CA2:
    c.r[2] = ld32(0x06088D4Cu);  // 06088CA2 mov.l 0x06088D4C,r2
    c.r[1] = 0x0u;  // 06088CA4 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06088CA6 mov.b r1,@r2
L_06088CA8:
    c.r[1] = ld32(0x06088D48u);  // 06088CA8 mov.l 0x06088D48,r1
    c.r[0] = ld32(c.r[1]);  // 06088CAA mov.l @r1,r0
    c.t = c.r[0] == 0x2u;  // 06088CAC cmp/eq #2,r0
    if (!c.t) { goto L_06088CBA; }  // 06088CAE bf 0x06088CBA
    c.r[1] = ld32(0x06088D4Cu);  // 06088CB0 mov.l 0x06088D4C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06088CB2 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06088CB4 or #128,r0
    st8(c.r[1], c.r[0]); goto L_06088CC0;  // 06088CB6 bra 0x06088CC0 ; mov.b r0,@r1
L_06088CBA:
    c.r[2] = ld32(0x06088D4Cu);  // 06088CBA mov.l 0x06088D4C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06088CBC mov.b @r2,r1
    st8(c.r[2], c.r[1]);  // 06088CBE mov.b r1,@r2
L_06088CC0:
    c.r[1] = ld32(0x06088D50u);  // 06088CC0 mov.l 0x06088D50,r1
    c.r[2] = ld32(c.r[1]);  // 06088CC2 mov.l @r1,r2
    c.r[1] = 0x1u;  // 06088CC4 mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06088CC6 cmp/gt r1,r2
    if (!c.t) { goto L_06088CE0; }  // 06088CC8 bf 0x06088CE0
    c.r[1] = ld32(0x06088D48u);  // 06088CCA mov.l 0x06088D48,r1
    c.r[0] = ld32(c.r[1]);  // 06088CCC mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06088CCE cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06088CDA; } }  // 06088CD0 bf/s 0x06088CDA ; mov #0,r1
    c.r[2] = ld32(0x06088D4Cu);  // 06088CD4 mov.l 0x06088D4C,r2
    st8(c.r[2], c.r[1]); goto L_06088CE0;  // 06088CD6 bra 0x06088CE0 ; mov.b r1,@r2
L_06088CDA:
    c.r[2] = ld32(0x06088D4Cu);  // 06088CDA mov.l 0x06088D4C,r2
    c.r[1] = 0xFFFFFF80u;  // 06088CDC mov #-128,r1
    st8(c.r[2], c.r[1]);  // 06088CDE mov.b r1,@r2
L_06088CE0:
    c.r[3] = ld32(0x06088D4Cu);  // 06088CE0 mov.l 0x06088D4C,r3
    c.r[2] = c.r[3];  // 06088CE2 mov r3,r2
    c.r[2] += 2;  // 06088CE4 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088D24u);  // 06088CE6 mov.w 0x06088D24,r1
    st16(c.r[2], c.r[1]);  // 06088CE8 mov.w r1,@r2
    c.r[3] += 4;  // 06088CEA add #4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088D26u);  // 06088CEC mov.w 0x06088D26,r1
    st16(c.r[3], c.r[1]);  // 06088CEE mov.w r1,@r3
    c.r[7] = ld32(0x06088D54u);  // 06088CF0 mov.l 0x06088D54,r7
    c.r[3] = 0x0u;  // 06088CF2 mov #0,r3
    st8(c.r[7], c.r[3]);  // 06088CF4 mov.b r3,@r7
    c.r[2] = c.r[7];  // 06088CF6 mov r7,r2
    c.r[2] += 1;  // 06088CF8 add #1,r2
    c.r[1] = 0x6u;  // 06088CFA mov #6,r1
    st8(c.r[2], c.r[1]);  // 06088CFC mov.b r1,@r2
    c.r[1] = c.r[7];  // 06088CFE mov r7,r1
    c.r[1] += 2;  // 06088D00 add #2,r1
    st8(c.r[1], c.r[3]);  // 06088D02 mov.b r3,@r1
    c.r[1] = ld32(0x06088D40u);  // 06088D04 mov.l 0x06088D40,r1
    c.r[2] = ld32(c.r[1]);  // 06088D06 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088D28u);  // 06088D08 mov.w 0x06088D28,r1
    c.t = c.r[2] == c.r[1];  // 06088D0A cmp/eq r1,r2
    { const bool k = !c.t; c.r[7] += 4; if (k) { goto L_06088D16; } }  // 06088D0C bf/s 0x06088D16 ; add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088D2Au);  // 06088D10 mov.w 0x06088D2A,r1
    st16(c.r[7], c.r[1]); goto L_06088D5C;  // 06088D12 bra 0x06088D5C ; mov.w r1,@r7
L_06088D16:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088D2Cu);  // 06088D16 mov.w 0x06088D2C,r1
    c.t = c.r[2] == c.r[1];  // 06088D18 cmp/eq r1,r2
    if (!c.t) { goto L_06088D58; }  // 06088D1A bf 0x06088D58
    c.r[1] = (uint32_t)(int16_t)ld16(0x06088D2Eu);  // 06088D1C mov.w 0x06088D2E,r1
    st16(c.r[7], c.r[1]); goto L_06088D5C;  // 06088D1E bra 0x06088D5C ; mov.w r1,@r7
L_06088D58:
    c.r[1] = 0x0u;  // 06088D58 mov #0,r1
    st16(c.r[7], c.r[1]);  // 06088D5A mov.w r1,@r7
L_06088D5C:
    c.r[2] = ld32(0x06088DE4u);  // 06088D5C mov.l 0x06088DE4,r2
    c.r[1] = c.r[2];  // 06088D5E mov r2,r1
    c.r[1] += 8;  // 06088D60 add #8,r1
    c.r[7] = 0x0u;  // 06088D62 mov #0,r7
    st8(c.r[1], c.r[7]);  // 06088D64 mov.b r7,@r1
    c.r[1] = c.r[2];  // 06088D66 mov r2,r1
    c.r[1] += 9;  // 06088D68 add #9,r1
    c.r[3] = 0x7u;  // 06088D6A mov #7,r3
    st8(c.r[1], c.r[3]);  // 06088D6C mov.b r3,@r1
    c.r[1] = c.r[2];  // 06088D6E mov r2,r1
    c.r[1] += 6;  // 06088D70 add #6,r1
    st8(c.r[1], c.r[7]);  // 06088D72 mov.b r7,@r1
    c.r[2] += 7;  // 06088D74 add #7,r2
    st8(c.r[2], c.r[3]);  // 06088D76 mov.b r3,@r2
    c.r[9] = ld32(0x06088DE8u);  // 06088D78 mov.l 0x06088DE8,r9
    c.r[8] = ld32(0x06088DECu);  // 06088D7A mov.l 0x06088DEC,r8
L_06088D7C:
    c.r[5] = ld32(0x06088DE4u);  // 06088D7C mov.l 0x06088DE4,r5
    c.r[4] = ld32(0x06088DF0u);  // 06088D7E mov.l 0x06088DF0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06088D84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088D84u) return; }  // 06088D80 jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06088D84 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088D86 tst r1,r1
    if (c.t) { goto L_06088D98; }  // 06088D88 bt 0x06088D98
    c.r[1] = ld32(c.r[8]);  // 06088D8A mov.l @r8,r1
    c.r[2] = c.r[1];  // 06088D8C mov r1,r2
    c.r[2] += 1;  // 06088D8E add #1,r2
    st32(c.r[8], c.r[2]);  // 06088D90 mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06088DE0u);  // 06088D92 mov.w 0x06088DE0,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06088D94 cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06088D7C; }  // 06088D96 bf 0x06088D7C
L_06088D98:
    c.r[8] = ld32(0x06088DF4u);  // 06088D98 mov.l 0x06088DF4,r8
    c.r[1] = ld32(0x06088DF8u);  // 06088D9A mov.l 0x06088DF8,r1
    c.r[5] = 0x0u;  // 06088D9C mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06088DA2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088DA2u) return; }  // 06088D9E jsr @r1 ; mov r8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06088DA2 mov.b @r8,r1
    c.r[2] = ld32(0x06088DFCu);  // 06088DA4 mov.l 0x06088DFC,r2
    st8(c.r[2], c.r[1]);  // 06088DA6 mov.b r1,@r2
L_06088DA8:
    c.r[1] = ld32(0x06088E00u);  // 06088DA8 mov.l 0x06088E00,r1
    c.r[3] = ld32(c.r[1]);  // 06088DAA mov.l @r1,r3
    c.r[7] = ld32(0x06088E04u);  // 06088DAC mov.l 0x06088E04,r7
    st32(c.r[7], c.r[3]);  // 06088DAE mov.l r3,@r7
    c.r[1] = ld32(0x06088E08u);  // 06088DB0 mov.l 0x06088E08,r1
    c.r[2] = ld32(c.r[1]);  // 06088DB2 mov.l @r1,r2
    c.r[1] = ld32(0x06088E0Cu);  // 06088DB4 mov.l 0x06088E0C,r1
    c.t = c.r[2] == c.r[1];  // 06088DB6 cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] += c.r[3]; if (k) { goto L_06088DBE; } }  // 06088DB8 bf/s 0x06088DBE ; add r3,r3
    st32(c.r[7], c.r[3]);  // 06088DBC mov.l r3,@r7
L_06088DBE:
    c.r[7] = ld32(0x06088E10u);  // 06088DBE mov.l 0x06088E10,r7
    c.r[3] = ld32(0x06088E14u);  // 06088DC0 mov.l 0x06088E14,r3
    c.r[1] = ld32(0x06088E18u);  // 06088DC2 mov.l 0x06088E18,r1
    c.r[2] = ld32(c.r[1]);  // 06088DC4 mov.l @r1,r2
    c.r[15] = c.r[14];  // 06088DC6 mov r14,r15
    c.r[1] = 0x0u;  // 06088DC8 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06088DCA mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 06088DCC mov.l r1,@r3
    st32(c.r[7], c.r[1]);  // 06088DCE mov.l r1,@r7
    c.r[2] = ld32(0x06088E1Cu);  // 06088DD0 mov.l 0x06088E1C,r2
    c.r[1] = 0x1u;  // 06088DD2 mov #1,r1
    st32(c.r[2], c.r[1]);  // 06088DD4 mov.l r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088DD6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088DD8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088DDA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088DDC rts ; mov.l @r15+,r8
}

void f_06088E20(SH2Context& c) {
    ran[1925] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088E20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06088E22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088E24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088E26 sts.l pr,@-r15
    c.r[1] = ld32(0x06088E88u);  // 06088E28 mov.l 0x06088E88,r1
    c.r[1] = ld32(c.r[1]);  // 06088E2A mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088E2C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06088E4E; } }  // 06088E2E bt/s 0x06088E4E ; mov r15,r14
    c.r[9] = ld32(0x06088E8Cu);  // 06088E32 mov.l 0x06088E8C,r9
    c.r[8] = ld32(0x06088E90u);  // 06088E34 mov.l 0x06088E90,r8
L_06088E36:
    { const uint32_t x = c.r[9]; c.pr = 0x06088E3Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088E3Au) return; }  // 06088E36 jsr @r9 ; mov #0,r4
    c.r[1] = c.r[0] & 0xFFu;  // 06088E3A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088E3C tst r1,r1
    if (c.t) { goto L_06088E4E; }  // 06088E3E bt 0x06088E4E
    c.r[1] = ld32(c.r[8]);  // 06088E40 mov.l @r8,r1
    c.r[2] = c.r[1];  // 06088E42 mov r1,r2
    c.r[2] += 1;  // 06088E44 add #1,r2
    st32(c.r[8], c.r[2]);  // 06088E46 mov.l r2,@r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x06088E84u);  // 06088E48 mov.w 0x06088E84,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06088E4A cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06088E36; }  // 06088E4C bf 0x06088E36
L_06088E4E:
    c.r[8] = ld32(0x06088E94u);  // 06088E4E mov.l 0x06088E94,r8
    c.r[4] = ld32(c.r[8]);  // 06088E50 mov.l @r8,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06088E52 tst r4,r4
    if (c.t) { goto L_06088E60; }  // 06088E54 bt 0x06088E60
    c.r[1] = ld32(0x06088E98u);  // 06088E56 mov.l 0x06088E98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088E5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088E5Cu) return; }  // 06088E58 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06088E5C mov #0,r1
    st32(c.r[8], c.r[1]);  // 06088E5E mov.l r1,@r8
L_06088E60:
    c.r[8] = ld32(0x06088E9Cu);  // 06088E60 mov.l 0x06088E9C,r8
    c.r[4] = ld32(c.r[8]);  // 06088E62 mov.l @r8,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06088E64 tst r4,r4
    if (c.t) { goto L_06088E72; }  // 06088E66 bt 0x06088E72
    c.r[1] = ld32(0x06088EA0u);  // 06088E68 mov.l 0x06088EA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06088E6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088E6Eu) return; }  // 06088E6A jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06088E6E mov #0,r1
    st32(c.r[8], c.r[1]);  // 06088E70 mov.l r1,@r8
L_06088E72:
    c.r[2] = ld32(0x06088EA4u);  // 06088E72 mov.l 0x06088EA4,r2
    c.r[1] = 0x0u;  // 06088E74 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06088E76 mov.l r1,@r2
    c.r[15] = c.r[14];  // 06088E78 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088E7A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088E7C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06088E7E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06088E80 rts ; mov.l @r15+,r8
}

void f_06088EA8(SH2Context& c) {
    ran[1926] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088EA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088EAA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088EAC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06088EAE mov r15,r14
    c.r[1] = ld32(0x06088ED0u);  // 06088EB0 mov.l 0x06088ED0,r1
    c.r[2] = 0x0u;  // 06088EB2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06088EB4 mov.l r2,@r1
    c.r[8] = ld32(0x06088ED4u);  // 06088EB6 mov.l 0x06088ED4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06088EBCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088EBCu) return; }  // 06088EB8 jsr @r8 ; nop
    c.r[0] = 0x1u;  // 06088EBC mov #1,r0
    goto L_06088EC2;  // 06088EBE bra 0x06088EC2 ; nop
L_06088EC2:
    c.r[15] = c.r[14];  // 06088EC2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088EC4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088EC6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06088EC8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06088ECA rts ; nop
}

void f_06088ED8(SH2Context& c) {
    ran[1927] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088ED8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088EDA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088EDC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06088EDE mov r15,r14
    c.r[8] = ld32(0x06088EF4u);  // 06088EE0 mov.l 0x06088EF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06088EE6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088EE6u) return; }  // 06088EE2 jsr @r8 ; nop
    c.r[15] = c.r[14];  // 06088EE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06088EE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06088EEA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06088EEC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06088EEE rts ; nop
}

void f_06088EF8(SH2Context& c) {
    ran[1928] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06088EF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06088EFA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06088EFC sts.l pr,@-r15
    c.r[15] -= 60;  // 06088EFE add #-60,r15
    c.r[14] = c.r[15];  // 06088F00 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06088F02 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06088F04 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06088F06 tst r1,r1
    if (!c.t) { goto L_06088F1A; }  // 06088F08 bf 0x06088F1A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089052u);  // 06088F0A mov.w 0x06089052,r1
    c.r[4] = c.r[1];  // 06088F0C mov r1,r4
    c.r[8] = ld32(0x06089064u);  // 06088F0E mov.l 0x06089064,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06088F14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088F14u) return; }  // 06088F10 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06088F14 mov #0,r0
    goto L_06089044;  // 06088F16 bra 0x06089044 ; nop
L_06088F1A:
    c.r[1] = ld32(c.r[14]);  // 06088F1A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06088F1C mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06088F1E tst r2,r2
    if (c.t) { goto L_06088F46; }  // 06088F20 bt 0x06088F46
    c.r[1] = ld32(c.r[14]);  // 06088F22 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06088F24 mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06088F26 tst r2,r2
    if (c.t) { goto L_06088F46; }  // 06088F28 bt 0x06088F46
    c.r[1] = ld32(c.r[14]);  // 06088F2A mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06088F2C mov.l @(8,r1),r2
    c.t = (int32_t)c.r[2] > 0;  // 06088F2E cmp/pl r2
    if (!c.t) { goto L_06088F46; }  // 06088F30 bf 0x06088F46
    c.r[1] = ld32(c.r[14]);  // 06088F32 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 12);  // 06088F34 mov.l @(12,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06088F36 tst r2,r2
    if (c.t) { goto L_06088F46; }  // 06088F38 bt 0x06088F46
    c.r[1] = ld32(c.r[14]);  // 06088F3A mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06088F3C mov.l @(16,r1),r2
    c.t = (int32_t)c.r[2] > 0;  // 06088F3E cmp/pl r2
    if (!c.t) { goto L_06088F46; }  // 06088F40 bf 0x06088F46
    goto L_06088F56;  // 06088F42 bra 0x06088F56 ; nop
L_06088F46:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089052u);  // 06088F46 mov.w 0x06089052,r1
    c.r[4] = c.r[1];  // 06088F48 mov r1,r4
    c.r[8] = ld32(0x06089064u);  // 06088F4A mov.l 0x06089064,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06088F50u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088F50u) return; }  // 06088F4C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06088F50 mov #0,r0
    goto L_06089044;  // 06088F52 bra 0x06089044 ; nop
L_06088F56:
    c.r[2] = c.r[14];  // 06088F56 mov r14,r2
    c.r[1] = c.r[14];  // 06088F58 mov r14,r1
    c.r[1] += 4;  // 06088F5A add #4,r1
    c.r[2] = ld32(c.r[14]);  // 06088F5C mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 4);  // 06088F5E mov.l @(4,r2),r3
    st32(c.r[1], c.r[3]);  // 06088F60 mov.l r3,@r1
    c.r[2] = c.r[14];  // 06088F62 mov r14,r2
    c.r[1] = c.r[14];  // 06088F64 mov r14,r1
    c.r[1] += 4;  // 06088F66 add #4,r1
    c.r[2] = ld32(c.r[14]);  // 06088F68 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 8);  // 06088F6A mov.l @(8,r2),r3
    st32(c.r[1] + 4, c.r[3]);  // 06088F6C mov.l r3,@(4,r1)
    c.r[1] = c.r[14];  // 06088F6E mov r14,r1
    c.r[2] = c.r[14];  // 06088F70 mov r14,r2
    c.r[2] += 4;  // 06088F72 add #4,r2
    c.r[1] = 0x0u;  // 06088F74 mov #0,r1
    st32(c.r[2] + 40, c.r[1]);  // 06088F76 mov.l r1,@(40,r2)
    c.r[1] = c.r[14];  // 06088F78 mov r14,r1
    c.r[2] = c.r[14];  // 06088F7A mov r14,r2
    c.r[2] += 4;  // 06088F7C add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089054u);  // 06088F7E mov.w 0x06089054,r1
    st32(c.r[2] + 44, c.r[1]);  // 06088F80 mov.l r1,@(44,r2)
    c.r[1] = c.r[14];  // 06088F82 mov r14,r1
    c.r[2] = c.r[14];  // 06088F84 mov r14,r2
    c.r[2] += 4;  // 06088F86 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089056u);  // 06088F88 mov.w 0x06089056,r1
    st32(c.r[2] + 48, c.r[1]);  // 06088F8A mov.l r1,@(48,r2)
    c.r[1] = c.r[14];  // 06088F8C mov r14,r1
    c.r[2] = c.r[14];  // 06088F8E mov r14,r2
    c.r[2] += 4;  // 06088F90 add #4,r2
    c.r[1] = 0x1u;  // 06088F92 mov #1,r1
    st32(c.r[2] + 16, c.r[1]);  // 06088F94 mov.l r1,@(16,r2)
    c.r[1] = c.r[14];  // 06088F96 mov r14,r1
    c.r[2] = c.r[14];  // 06088F98 mov r14,r2
    c.r[2] += 4;  // 06088F9A add #4,r2
    c.r[1] = 0x1u;  // 06088F9C mov #1,r1
    st32(c.r[2] + 20, c.r[1]);  // 06088F9E mov.l r1,@(20,r2)
    c.r[2] = c.r[14];  // 06088FA0 mov r14,r2
    c.r[1] = c.r[14];  // 06088FA2 mov r14,r1
    c.r[1] += 4;  // 06088FA4 add #4,r1
    c.r[2] = ld32(c.r[14]);  // 06088FA6 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 12);  // 06088FA8 mov.l @(12,r2),r3
    st32(c.r[1] + 8, c.r[3]);  // 06088FAA mov.l r3,@(8,r1)
    c.r[2] = c.r[14];  // 06088FAC mov r14,r2
    c.r[1] = c.r[14];  // 06088FAE mov r14,r1
    c.r[1] += 4;  // 06088FB0 add #4,r1
    c.r[2] = ld32(c.r[14]);  // 06088FB2 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 16);  // 06088FB4 mov.l @(16,r2),r3
    st32(c.r[1] + 12, c.r[3]);  // 06088FB6 mov.l r3,@(12,r1)
    c.r[1] = c.r[14];  // 06088FB8 mov r14,r1
    c.r[2] = c.r[14];  // 06088FBA mov r14,r2
    c.r[2] += 4;  // 06088FBC add #4,r2
    c.r[1] = 0x0u;  // 06088FBE mov #0,r1
    st32(c.r[2] + 24, c.r[1]);  // 06088FC0 mov.l r1,@(24,r2)
    c.r[1] = c.r[14];  // 06088FC2 mov r14,r1
    c.r[2] = c.r[14];  // 06088FC4 mov r14,r2
    c.r[2] += 4;  // 06088FC6 add #4,r2
    c.r[1] = 0x7u;  // 06088FC8 mov #7,r1
    st32(c.r[2] + 28, c.r[1]);  // 06088FCA mov.l r1,@(28,r2)
    c.r[1] = c.r[14];  // 06088FCC mov r14,r1
    c.r[2] = c.r[14];  // 06088FCE mov r14,r2
    c.r[2] += 4;  // 06088FD0 add #4,r2
    c.r[1] = 0x7u;  // 06088FD2 mov #7,r1
    st32(c.r[2] + 32, c.r[1]);  // 06088FD4 mov.l r1,@(32,r2)
    c.r[1] = c.r[14];  // 06088FD6 mov r14,r1
    c.r[1] += 4;  // 06088FD8 add #4,r1
    c.r[2] = ld32(c.r[14]);  // 06088FDA mov.l @r14,r2
    c.r[3] = ld32(c.r[2]);  // 06088FDC mov.l @r2,r3
    c.r[5] = c.r[1];  // 06088FDE mov r1,r5
    c.r[4] = c.r[3];  // 06088FE0 mov r3,r4
    c.r[8] = ld32(0x06089068u);  // 06088FE2 mov.l 0x06089068,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06088FE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06088FE8u) return; }  // 06088FE4 jsr @r8 ; nop
    st32(c.r[14] + 56, c.r[0]);  // 06088FE8 mov.l r0,@(56,r14)
    c.r[2] = ld32(c.r[14] + 56);  // 06088FEA mov.l @(56,r14),r2
    c.r[1] = ld32(c.r[2]);  // 06088FEC mov.l @r2,r1
    c.r[2] = c.r[1];  // 06088FEE mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089058u);  // 06088FF0 mov.w 0x06089058,r3
    c.r[1] += c.r[3];  // 06088FF2 add r3,r1
    c.r[2] = 0x0u;  // 06088FF4 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06088FF6 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 56);  // 06088FF8 mov.l @(56,r14),r2
    c.r[1] = ld32(c.r[2]);  // 06088FFA mov.l @r2,r1
    c.r[2] = c.r[1];  // 06088FFC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608905Au);  // 06088FFE mov.w 0x0608905A,r3
    c.r[1] += c.r[3];  // 06089000 add r3,r1
    c.r[2] = ld32(0x0608906Cu);  // 06089002 mov.l 0x0608906C,r2
    st32(c.r[1], c.r[2]);  // 06089004 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 56);  // 06089006 mov.l @(56,r14),r2
    c.r[1] = ld32(c.r[2]);  // 06089008 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608900A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608905Cu);  // 0608900C mov.w 0x0608905C,r3
    c.r[1] += c.r[3];  // 0608900E add r3,r1
    c.r[2] = ld32(0x06089070u);  // 06089010 mov.l 0x06089070,r2
    st32(c.r[1], c.r[2]);  // 06089012 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 56);  // 06089014 mov.l @(56,r14),r2
    c.r[1] = ld32(c.r[2]);  // 06089016 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089018 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608905Eu);  // 0608901A mov.w 0x0608905E,r3
    c.r[1] += c.r[3];  // 0608901C add r3,r1
    c.r[2] = ld32(0x06089074u);  // 0608901E mov.l 0x06089074,r2
    st32(c.r[1], c.r[2]);  // 06089020 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 56);  // 06089022 mov.l @(56,r14),r2
    c.r[1] = ld32(c.r[2]);  // 06089024 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089026 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089060u);  // 06089028 mov.w 0x06089060,r3
    c.r[1] += c.r[3];  // 0608902A add r3,r1
    c.r[2] = ld32(0x06089078u);  // 0608902C mov.l 0x06089078,r2
    st32(c.r[1], c.r[2]);  // 0608902E mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 56);  // 06089030 mov.l @(56,r14),r2
    c.r[1] = ld32(c.r[2]);  // 06089032 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089034 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089062u);  // 06089036 mov.w 0x06089062,r3
    c.r[1] += c.r[3];  // 06089038 add r3,r1
    c.r[2] = ld32(0x0608907Cu);  // 0608903A mov.l 0x0608907C,r2
    st32(c.r[1], c.r[2]);  // 0608903C mov.l r2,@r1
    c.r[0] = ld32(c.r[14] + 56);  // 0608903E mov.l @(56,r14),r0
    goto L_06089044;  // 06089040 bra 0x06089044 ; nop
L_06089044:
    c.r[14] += 60;  // 06089044 add #60,r14
    c.r[15] = c.r[14];  // 06089046 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089048 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608904A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608904C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608904E rts ; nop
}

void f_06089080(SH2Context& c) {
    ran[1929] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089080 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089082 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089084 sts.l pr,@-r15
    c.r[15] -= 4;  // 06089086 add #-4,r15
    c.r[14] = c.r[15];  // 06089088 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608908A mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608908C mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608908E tst r1,r1
    if (!c.t) { goto L_060890A0; }  // 06089090 bf 0x060890A0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060890D0u);  // 06089092 mov.w 0x060890D0,r1
    c.r[4] = c.r[1];  // 06089094 mov r1,r4
    c.r[8] = ld32(0x060890D8u);  // 06089096 mov.l 0x060890D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608909Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608909Cu) return; }  // 06089098 jsr @r8 ; nop
    goto L_060890C2;  // 0608909C bra 0x060890C2 ; nop
L_060890A0:
    c.r[2] = ld32(c.r[14]);  // 060890A0 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 060890A2 mov.l @r2,r1
    c.r[2] = c.r[1];  // 060890A4 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060890D2u);  // 060890A6 mov.w 0x060890D2,r3
    c.r[1] += c.r[3];  // 060890A8 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 060890AA mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060890AC tst r2,r2
    if (c.t) { goto L_060890BA; }  // 060890AE bt 0x060890BA
    c.r[1] = (uint32_t)(int16_t)ld16(0x060890D4u);  // 060890B0 mov.w 0x060890D4,r1
    c.r[4] = c.r[1];  // 060890B2 mov r1,r4
    c.r[8] = ld32(0x060890D8u);  // 060890B4 mov.l 0x060890D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060890BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060890BAu) return; }  // 060890B6 jsr @r8 ; nop
L_060890BA:
    c.r[4] = ld32(c.r[14]);  // 060890BA mov.l @r14,r4
    c.r[8] = ld32(0x060890DCu);  // 060890BC mov.l 0x060890DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060890C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060890C2u) return; }  // 060890BE jsr @r8 ; nop
L_060890C2:
    c.r[14] += 4;  // 060890C2 add #4,r14
    c.r[15] = c.r[14];  // 060890C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060890C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060890C8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060890CA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060890CC rts ; nop
}

void f_060890E0(SH2Context& c) {
    ran[1930] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060890E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060890E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060890E4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060890E6 add #-8,r15
    c.r[14] = c.r[15];  // 060890E8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060890EA mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 060890EC mov.l @r14,r4
    c.r[8] = ld32(0x0608915Cu);  // 060890EE mov.l 0x0608915C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060890F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060890F4u) return; }  // 060890F0 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 060890F4 mov.l @r14,r4
    c.r[8] = ld32(0x06089160u);  // 060890F6 mov.l 0x06089160,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060890FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060890FCu) return; }  // 060890F8 jsr @r8 ; nop
    c.t = c.r[0] == 0x5u;  // 060890FC cmp/eq #5,r0
    if (!c.t) { goto L_0608914E; }  // 060890FE bf 0x0608914E
    c.r[1] = ld32(c.r[14]);  // 06089100 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06089102 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06089104 mov r2,r1
    c.r[2] += 72;  // 06089106 add #72,r2
    c.r[1] = ld32(c.r[14]);  // 06089108 mov.l @r14,r1
    c.r[3] = ld32(c.r[1]);  // 0608910A mov.l @r1,r3
    c.r[2] = c.r[3];  // 0608910C mov r3,r2
    c.r[1] = c.r[3];  // 0608910E mov r3,r1
    c.r[1] += 72;  // 06089110 add #72,r1
    c.r[2] = ld32(c.r[14]);  // 06089112 mov.l @r14,r2
    c.r[3] = ld32(c.r[2]);  // 06089114 mov.l @r2,r3
    c.r[2] = c.r[3];  // 06089116 mov r3,r2
    c.r[3] += 72;  // 06089118 add #72,r3
    c.r[7] = ld32(c.r[3]);  // 0608911A mov.l @r3,r7
    c.r[2] = c.r[7];  // 0608911C mov r7,r2
    c.r[2] -= 1;  // 0608911E add #-1,r2
    c.r[3] = c.r[2];  // 06089120 mov r2,r3
    st32(c.r[1], c.r[3]);  // 06089122 mov.l r3,@r1
    c.t = (int32_t)c.r[3] > 0;  // 06089124 cmp/pl r3
    if (!c.t) { goto L_0608914E; }  // 06089126 bf 0x0608914E
    c.r[4] = ld32(c.r[14]);  // 06089128 mov.l @r14,r4
    c.r[8] = ld32(0x06089164u);  // 0608912A mov.l 0x06089164,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089130u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089130u) return; }  // 0608912C jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06089130 mov.l r0,@(4,r14)
    c.r[4] = ld32(c.r[14]);  // 06089132 mov.l @r14,r4
    c.r[8] = ld32(0x06089168u);  // 06089134 mov.l 0x06089168,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608913Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608913Au) return; }  // 06089136 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0608913A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608913C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608913E mov.l @r14,r4
    c.r[8] = ld32(0x0608916Cu);  // 06089140 mov.l 0x0608916C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089146u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089146u) return; }  // 06089142 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 06089146 mov.l @r14,r4
    c.r[8] = ld32(0x06089170u);  // 06089148 mov.l 0x06089170,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608914Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608914Eu) return; }  // 0608914A jsr @r8 ; nop
L_0608914E:
    c.r[14] += 8;  // 0608914E add #8,r14
    c.r[15] = c.r[14];  // 06089150 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089152 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089154 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089156 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089158 rts ; nop
}

void f_06089174(SH2Context& c) {
    ran[1931] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089174 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089176 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089178 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608917A add #-8,r15
    c.r[14] = c.r[15];  // 0608917C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608917E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089180 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089182 tst r1,r1
    if (!c.t) { goto L_060891CC; }  // 06089184 bf 0x060891CC
    c.r[1] = 0x0u;  // 06089186 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06089188 mov.l r1,@(4,r14)
L_0608918A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608918A mov.l @(4,r14),r1
    c.r[2] = 0x1Fu;  // 0608918C mov #31,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608918E cmp/gt r2,r1
    if (!c.t) { goto L_06089196; }  // 06089190 bf 0x06089196
    goto L_060891C8;  // 06089192 bra 0x060891C8 ; nop
L_06089196:
    c.r[1] = ld32(c.r[14] + 4);  // 06089196 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 06089198 mov r1,r4
    c.r[8] = ld32(0x060891F0u);  // 0608919A mov.l 0x060891F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060891A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060891A0u) return; }  // 0608919C jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 060891A0 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 060891A2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060891A4 tst r1,r1
    if (c.t) { goto L_060891BA; }  // 060891A6 bt 0x060891BA
    c.r[2] = ld32(c.r[14]);  // 060891A8 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 060891AA mov.l @r2,r1
    c.r[2] = c.r[1];  // 060891AC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060891ECu);  // 060891AE mov.w 0x060891EC,r3
    c.r[1] += c.r[3];  // 060891B0 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 060891B2 mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 060891B4 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x060891BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060891BAu) return; }  // 060891B6 jsr @r2 ; nop
L_060891BA:
    c.r[2] = ld32(c.r[14] + 4);  // 060891BA mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060891BC mov r2,r1
    c.r[1] += 1;  // 060891BE add #1,r1
    c.r[2] = c.r[1];  // 060891C0 mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 060891C2 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0608918A;  // 060891C4 bra 0x0608918A ; nop
L_060891C8:
    goto L_060891DE;  // 060891C8 bra 0x060891DE ; nop
L_060891CC:
    c.r[2] = ld32(c.r[14]);  // 060891CC mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 060891CE mov.l @r2,r1
    c.r[2] = c.r[1];  // 060891D0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060891ECu);  // 060891D2 mov.w 0x060891EC,r3
    c.r[1] += c.r[3];  // 060891D4 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 060891D6 mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 060891D8 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x060891DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060891DEu) return; }  // 060891DA jsr @r2 ; nop
L_060891DE:
    c.r[14] += 8;  // 060891DE add #8,r14
    c.r[15] = c.r[14];  // 060891E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060891E2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060891E4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060891E6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060891E8 rts ; nop
}

void f_060891F4(SH2Context& c) {
    ran[1932] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060891F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060891F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060891F8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060891FA mov r15,r14
    c.r[8] = ld32(0x06089210u);  // 060891FC mov.l 0x06089210,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089202u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089202u) return; }  // 060891FE jsr @r8 ; nop
    c.r[15] = c.r[14];  // 06089202 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089204 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089206 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089208 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608920A rts ; nop
}

void f_06089214(SH2Context& c) {
    ran[1933] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089214 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089216 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089218 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608921A add #-4,r15
    c.r[14] = c.r[15];  // 0608921C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608921E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089220 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089222 tst r1,r1
    if (!c.t) { goto L_06089234; }  // 06089224 bf 0x06089234
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089254u);  // 06089226 mov.w 0x06089254,r1
    c.r[4] = c.r[1];  // 06089228 mov r1,r4
    c.r[8] = ld32(0x06089258u);  // 0608922A mov.l 0x06089258,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089230u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089230u) return; }  // 0608922C jsr @r8 ; nop
    goto L_06089246;  // 06089230 bra 0x06089246 ; nop
L_06089234:
    c.r[2] = ld32(c.r[14]);  // 06089234 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 06089236 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089238 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089256u);  // 0608923A mov.w 0x06089256,r3
    c.r[1] += c.r[3];  // 0608923C add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608923E mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 06089240 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x06089246u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089246u) return; }  // 06089242 jsr @r2 ; nop
L_06089246:
    c.r[14] += 4;  // 06089246 add #4,r14
    c.r[15] = c.r[14];  // 06089248 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608924A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608924C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608924E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089250 rts ; nop
}

void f_0608925C(SH2Context& c) {
    ran[1934] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608925C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608925E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089260 sts.l pr,@-r15
    c.r[15] -= 4;  // 06089262 add #-4,r15
    c.r[14] = c.r[15];  // 06089264 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089266 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089268 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608926A tst r1,r1
    if (!c.t) { goto L_0608927C; }  // 0608926C bf 0x0608927C
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089292u);  // 0608926E mov.w 0x06089292,r1
    c.r[4] = c.r[1];  // 06089270 mov r1,r4
    c.r[8] = ld32(0x06089294u);  // 06089272 mov.l 0x06089294,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089278u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089278u) return; }  // 06089274 jsr @r8 ; nop
    goto L_06089284;  // 06089278 bra 0x06089284 ; nop
L_0608927C:
    c.r[4] = ld32(c.r[14]);  // 0608927C mov.l @r14,r4
    c.r[8] = ld32(0x06089298u);  // 0608927E mov.l 0x06089298,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089284u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089284u) return; }  // 06089280 jsr @r8 ; nop
L_06089284:
    c.r[14] += 4;  // 06089284 add #4,r14
    c.r[15] = c.r[14];  // 06089286 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089288 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608928A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608928C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608928E rts ; nop
}

void f_0608929C(SH2Context& c) {
    ran[1935] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608929C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608929E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060892A0 sts.l pr,@-r15
    c.r[15] -= 8;  // 060892A2 add #-8,r15
    c.r[14] = c.r[15];  // 060892A4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060892A6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060892A8 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060892AA mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060892AC tst r1,r1
    if (!c.t) { goto L_060892BE; }  // 060892AE bf 0x060892BE
    c.r[1] = (uint32_t)(int16_t)ld16(0x060892D8u);  // 060892B0 mov.w 0x060892D8,r1
    c.r[4] = c.r[1];  // 060892B2 mov r1,r4
    c.r[8] = ld32(0x060892DCu);  // 060892B4 mov.l 0x060892DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060892BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060892BAu) return; }  // 060892B6 jsr @r8 ; nop
    goto L_060892CA;  // 060892BA bra 0x060892CA ; nop
L_060892BE:
    c.r[1] = ld32(c.r[14] + 4);  // 060892BE mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060892C0 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060892C2 mov.l @r14,r4
    c.r[8] = ld32(0x060892E0u);  // 060892C4 mov.l 0x060892E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060892CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060892CAu) return; }  // 060892C6 jsr @r8 ; nop
L_060892CA:
    c.r[14] += 8;  // 060892CA add #8,r14
    c.r[15] = c.r[14];  // 060892CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060892CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060892D0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060892D2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060892D4 rts ; nop
}

void f_060892E4(SH2Context& c) {
    ran[1936] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060892E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060892E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060892E8 sts.l pr,@-r15
    c.r[15] -= 8;  // 060892EA add #-8,r15
    c.r[14] = c.r[15];  // 060892EC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060892EE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060892F0 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060892F2 tst r1,r1
    if (!c.t) { goto L_06089306; }  // 060892F4 bf 0x06089306
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089328u);  // 060892F6 mov.w 0x06089328,r1
    c.r[4] = c.r[1];  // 060892F8 mov r1,r4
    c.r[8] = ld32(0x0608932Cu);  // 060892FA mov.l 0x0608932C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089300u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089300u) return; }  // 060892FC jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089300 mov #0,r0
    goto L_0608931A;  // 06089302 bra 0x0608931A ; nop
L_06089306:
    c.r[1] = c.r[14];  // 06089306 mov r14,r1
    c.r[1] += 4;  // 06089308 add #4,r1
    c.r[5] = c.r[1];  // 0608930A mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608930C mov.l @r14,r4
    c.r[8] = ld32(0x06089330u);  // 0608930E mov.l 0x06089330,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089314u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089314u) return; }  // 06089310 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 4);  // 06089314 mov.l @(4,r14),r0
    goto L_0608931A;  // 06089316 bra 0x0608931A ; nop
L_0608931A:
    c.r[14] += 8;  // 0608931A add #8,r14
    c.r[15] = c.r[14];  // 0608931C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608931E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089320 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089322 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089324 rts ; nop
}

void f_06089334(SH2Context& c) {
    ran[1937] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089334 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089336 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089338 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608933A add #-8,r15
    c.r[14] = c.r[15];  // 0608933C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608933E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089340 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089342 tst r1,r1
    if (!c.t) { goto L_06089356; }  // 06089344 bf 0x06089356
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089396u);  // 06089346 mov.w 0x06089396,r1
    c.r[4] = c.r[1];  // 06089348 mov r1,r4
    c.r[8] = ld32(0x06089398u);  // 0608934A mov.l 0x06089398,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089350u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089350u) return; }  // 0608934C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089350 mov #0,r0
    goto L_06089388;  // 06089352 bra 0x06089388 ; nop
L_06089356:
    c.r[4] = ld32(c.r[14]);  // 06089356 mov.l @r14,r4
    c.r[8] = ld32(0x0608939Cu);  // 06089358 mov.l 0x0608939C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608935Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608935Eu) return; }  // 0608935A jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0608935E mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089360 mov.l @(4,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 06089362 mov.l @(4,r1),r0
    c.r[1] = 0xFFFFFFFFu;  // 06089364 mov #-1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06089366 cmp/ge r1,r0
    if (!c.t) { goto L_0608937C; }  // 06089368 bf 0x0608937C
    c.t = (int32_t)c.r[0] > 0;  // 0608936A cmp/pl r0
    if (!c.t) { goto L_06089376; }  // 0608936C bf 0x06089376
    c.t = c.r[0] == 0x2u;  // 0608936E cmp/eq #2,r0
    if (c.t) { goto L_06089376; }  // 06089370 bt 0x06089376
    goto L_0608937C;  // 06089372 bra 0x0608937C ; nop
L_06089376:
    c.r[0] = 0x0u;  // 06089376 mov #0,r0
    goto L_06089388;  // 06089378 bra 0x06089388 ; nop
L_0608937C:
    c.r[2] = ld32(c.r[14] + 4);  // 0608937C mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0608937E mov r2,r1
    c.r[1] += 24;  // 06089380 add #24,r1
    c.r[0] = ld32(c.r[1] + 20);  // 06089382 mov.l @(20,r1),r0
    goto L_06089388;  // 06089384 bra 0x06089388 ; nop
L_06089388:
    c.r[14] += 8;  // 06089388 add #8,r14
    c.r[15] = c.r[14];  // 0608938A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608938C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608938E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089390 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089392 rts ; nop
}

void f_060893A0(SH2Context& c) {
    ran[1938] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060893A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060893A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060893A4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060893A6 add #-8,r15
    c.r[14] = c.r[15];  // 060893A8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060893AA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060893AC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060893AE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060893B0 tst r1,r1
    if (!c.t) { goto L_060893C2; }  // 060893B2 bf 0x060893C2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060893DCu);  // 060893B4 mov.w 0x060893DC,r1
    c.r[4] = c.r[1];  // 060893B6 mov r1,r4
    c.r[8] = ld32(0x060893E0u);  // 060893B8 mov.l 0x060893E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060893BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060893BEu) return; }  // 060893BA jsr @r8 ; nop
    goto L_060893CE;  // 060893BE bra 0x060893CE ; nop
L_060893C2:
    c.r[1] = ld32(c.r[14] + 4);  // 060893C2 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060893C4 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060893C6 mov.l @r14,r4
    c.r[8] = ld32(0x060893E4u);  // 060893C8 mov.l 0x060893E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060893CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060893CEu) return; }  // 060893CA jsr @r8 ; nop
L_060893CE:
    c.r[14] += 8;  // 060893CE add #8,r14
    c.r[15] = c.r[14];  // 060893D0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060893D2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060893D4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060893D6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060893D8 rts ; nop
}

void f_060893E8(SH2Context& c) {
    ran[1939] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060893E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060893EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060893EC sts.l pr,@-r15
    c.r[15] -= 8;  // 060893EE add #-8,r15
    c.r[14] = c.r[15];  // 060893F0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060893F2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060893F4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060893F6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060893F8 tst r1,r1
    if (!c.t) { goto L_0608940A; }  // 060893FA bf 0x0608940A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089424u);  // 060893FC mov.w 0x06089424,r1
    c.r[4] = c.r[1];  // 060893FE mov r1,r4
    c.r[8] = ld32(0x06089428u);  // 06089400 mov.l 0x06089428,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089406u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089406u) return; }  // 06089402 jsr @r8 ; nop
    goto L_06089416;  // 06089406 bra 0x06089416 ; nop
L_0608940A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608940A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608940C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608940E mov.l @r14,r4
    c.r[8] = ld32(0x0608942Cu);  // 06089410 mov.l 0x0608942C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089416u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089416u) return; }  // 06089412 jsr @r8 ; nop
L_06089416:
    c.r[14] += 8;  // 06089416 add #8,r14
    c.r[15] = c.r[14];  // 06089418 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608941A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608941C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608941E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089420 rts ; nop
}

void f_06089430(SH2Context& c) {
    ran[1940] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089430 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089432 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089434 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089436 add #-8,r15
    c.r[14] = c.r[15];  // 06089438 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608943A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608943C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608943E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089440 tst r1,r1
    if (!c.t) { goto L_06089452; }  // 06089442 bf 0x06089452
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608946Cu);  // 06089444 mov.w 0x0608946C,r1
    c.r[4] = c.r[1];  // 06089446 mov r1,r4
    c.r[8] = ld32(0x06089470u);  // 06089448 mov.l 0x06089470,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608944Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608944Eu) return; }  // 0608944A jsr @r8 ; nop
    goto L_0608945E;  // 0608944E bra 0x0608945E ; nop
L_06089452:
    c.r[1] = ld32(c.r[14] + 4);  // 06089452 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089454 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089456 mov.l @r14,r4
    c.r[8] = ld32(0x06089474u);  // 06089458 mov.l 0x06089474,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608945Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608945Eu) return; }  // 0608945A jsr @r8 ; nop
L_0608945E:
    c.r[14] += 8;  // 0608945E add #8,r14
    c.r[15] = c.r[14];  // 06089460 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089462 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089464 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089466 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089468 rts ; nop
}

void f_06089478(SH2Context& c) {
    ran[1941] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089478 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608947A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608947C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608947E add #-8,r15
    c.r[14] = c.r[15];  // 06089480 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089482 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089484 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06089486 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089488 tst r1,r1
    if (!c.t) { goto L_0608949A; }  // 0608948A bf 0x0608949A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060894B4u);  // 0608948C mov.w 0x060894B4,r1
    c.r[4] = c.r[1];  // 0608948E mov r1,r4
    c.r[8] = ld32(0x060894B8u);  // 06089490 mov.l 0x060894B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089496u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089496u) return; }  // 06089492 jsr @r8 ; nop
    goto L_060894A6;  // 06089496 bra 0x060894A6 ; nop
L_0608949A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608949A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608949C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608949E mov.l @r14,r4
    c.r[8] = ld32(0x060894BCu);  // 060894A0 mov.l 0x060894BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060894A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060894A6u) return; }  // 060894A2 jsr @r8 ; nop
L_060894A6:
    c.r[14] += 8;  // 060894A6 add #8,r14
    c.r[15] = c.r[14];  // 060894A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060894AA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060894AC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060894AE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060894B0 rts ; nop
}

void f_060894C0(SH2Context& c) {
    ran[1942] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060894C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060894C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060894C4 sts.l pr,@-r15
    c.r[15] -= 12;  // 060894C6 add #-12,r15
    c.r[14] = c.r[15];  // 060894C8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060894CA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060894CC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060894CE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060894D0 tst r1,r1
    if (!c.t) { goto L_060894E2; }  // 060894D2 bf 0x060894E2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089520u);  // 060894D4 mov.w 0x06089520,r1
    c.r[4] = c.r[1];  // 060894D6 mov r1,r4
    c.r[8] = ld32(0x06089524u);  // 060894D8 mov.l 0x06089524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060894DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060894DEu) return; }  // 060894DA jsr @r8 ; nop
    goto L_06089512;  // 060894DE bra 0x06089512 ; nop
L_060894E2:
    c.r[1] = ld32(c.r[14] + 4);  // 060894E2 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060894E4 cmp/pz r1
    if (!c.t) { goto L_060894F4; }  // 060894E6 bf 0x060894F4
    c.r[1] = ld32(c.r[14] + 4);  // 060894E8 mov.l @(4,r14),r1
    c.r[2] = 0x7u;  // 060894EA mov #7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060894EC cmp/gt r2,r1
    if (c.t) { goto L_060894F4; }  // 060894EE bt 0x060894F4
    goto L_06089502;  // 060894F0 bra 0x06089502 ; nop
L_060894F4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089522u);  // 060894F4 mov.w 0x06089522,r1
    c.r[4] = c.r[1];  // 060894F6 mov r1,r4
    c.r[8] = ld32(0x06089524u);  // 060894F8 mov.l 0x06089524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060894FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060894FEu) return; }  // 060894FA jsr @r8 ; nop
    goto L_06089512;  // 060894FE bra 0x06089512 ; nop
L_06089502:
    c.r[4] = ld32(c.r[14]);  // 06089502 mov.l @r14,r4
    c.r[8] = ld32(0x06089528u);  // 06089504 mov.l 0x06089528,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608950Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608950Au) return; }  // 06089506 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 0608950A mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608950C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608950E mov.l @(4,r14),r2
    st32(c.r[1] + 16, c.r[2]);  // 06089510 mov.l r2,@(16,r1)
L_06089512:
    c.r[14] += 12;  // 06089512 add #12,r14
    c.r[15] = c.r[14];  // 06089514 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089516 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089518 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608951A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608951C rts ; nop
}

void f_0608952C(SH2Context& c) {
    ran[1943] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608952C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608952E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089530 sts.l pr,@-r15
    c.r[15] -= 12;  // 06089532 add #-12,r15
    c.r[14] = c.r[15];  // 06089534 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089536 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089538 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608953A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608953C tst r1,r1
    if (!c.t) { goto L_0608954E; }  // 0608953E bf 0x0608954E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608958Cu);  // 06089540 mov.w 0x0608958C,r1
    c.r[4] = c.r[1];  // 06089542 mov r1,r4
    c.r[8] = ld32(0x06089590u);  // 06089544 mov.l 0x06089590,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608954Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608954Au) return; }  // 06089546 jsr @r8 ; nop
    goto L_0608957E;  // 0608954A bra 0x0608957E ; nop
L_0608954E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608954E mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06089550 cmp/pz r1
    if (!c.t) { goto L_06089560; }  // 06089552 bf 0x06089560
    c.r[1] = ld32(c.r[14] + 4);  // 06089554 mov.l @(4,r14),r1
    c.r[2] = 0x7u;  // 06089556 mov #7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06089558 cmp/gt r2,r1
    if (c.t) { goto L_06089560; }  // 0608955A bt 0x06089560
    goto L_0608956E;  // 0608955C bra 0x0608956E ; nop
L_06089560:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608958Eu);  // 06089560 mov.w 0x0608958E,r1
    c.r[4] = c.r[1];  // 06089562 mov r1,r4
    c.r[8] = ld32(0x06089590u);  // 06089564 mov.l 0x06089590,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608956Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608956Au) return; }  // 06089566 jsr @r8 ; nop
    goto L_0608957E;  // 0608956A bra 0x0608957E ; nop
L_0608956E:
    c.r[4] = ld32(c.r[14]);  // 0608956E mov.l @r14,r4
    c.r[8] = ld32(0x06089594u);  // 06089570 mov.l 0x06089594,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089576u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089576u) return; }  // 06089572 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06089576 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06089578 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608957A mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 0608957C mov.l r2,@(20,r1)
L_0608957E:
    c.r[14] += 12;  // 0608957E add #12,r14
    c.r[15] = c.r[14];  // 06089580 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089582 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089584 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089586 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089588 rts ; nop
}

void f_06089598(SH2Context& c) {
    ran[1944] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089598 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608959A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608959C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608959E add #-8,r15
    c.r[14] = c.r[15];  // 060895A0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060895A2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060895A4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060895A6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060895A8 tst r1,r1
    if (!c.t) { goto L_060895BA; }  // 060895AA bf 0x060895BA
    c.r[1] = (uint32_t)(int16_t)ld16(0x060895D4u);  // 060895AC mov.w 0x060895D4,r1
    c.r[4] = c.r[1];  // 060895AE mov r1,r4
    c.r[8] = ld32(0x060895D8u);  // 060895B0 mov.l 0x060895D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060895B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060895B6u) return; }  // 060895B2 jsr @r8 ; nop
    goto L_060895C6;  // 060895B6 bra 0x060895C6 ; nop
L_060895BA:
    c.r[1] = ld32(c.r[14] + 4);  // 060895BA mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060895BC mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060895BE mov.l @r14,r4
    c.r[8] = ld32(0x060895DCu);  // 060895C0 mov.l 0x060895DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060895C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060895C6u) return; }  // 060895C2 jsr @r8 ; nop
L_060895C6:
    c.r[14] += 8;  // 060895C6 add #8,r14
    c.r[15] = c.r[14];  // 060895C8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060895CA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060895CC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060895CE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060895D0 rts ; nop
}

void f_060895E0(SH2Context& c) {
    ran[1945] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060895E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060895E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060895E4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060895E6 add #-8,r15
    c.r[14] = c.r[15];  // 060895E8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060895EA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060895EC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060895EE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060895F0 tst r1,r1
    if (!c.t) { goto L_06089602; }  // 060895F2 bf 0x06089602
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608961Cu);  // 060895F4 mov.w 0x0608961C,r1
    c.r[4] = c.r[1];  // 060895F6 mov r1,r4
    c.r[8] = ld32(0x06089620u);  // 060895F8 mov.l 0x06089620,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060895FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060895FEu) return; }  // 060895FA jsr @r8 ; nop
    goto L_0608960E;  // 060895FE bra 0x0608960E ; nop
L_06089602:
    c.r[1] = ld32(c.r[14] + 4);  // 06089602 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089604 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089606 mov.l @r14,r4
    c.r[8] = ld32(0x06089624u);  // 06089608 mov.l 0x06089624,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608960Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608960Eu) return; }  // 0608960A jsr @r8 ; nop
L_0608960E:
    c.r[14] += 8;  // 0608960E add #8,r14
    c.r[15] = c.r[14];  // 06089610 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089612 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089614 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089616 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089618 rts ; nop
}

void f_06089628(SH2Context& c) {
    ran[1946] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089628 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608962A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608962C sts.l pr,@-r15
    c.r[15] -= 12;  // 0608962E add #-12,r15
    c.r[14] = c.r[15];  // 06089630 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089632 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089634 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06089636 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 06089638 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608963A tst r1,r1
    if (!c.t) { goto L_0608964C; }  // 0608963C bf 0x0608964C
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608966Au);  // 0608963E mov.w 0x0608966A,r1
    c.r[4] = c.r[1];  // 06089640 mov r1,r4
    c.r[8] = ld32(0x0608966Cu);  // 06089642 mov.l 0x0608966C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089648u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089648u) return; }  // 06089644 jsr @r8 ; nop
    goto L_0608965C;  // 06089648 bra 0x0608965C ; nop
L_0608964C:
    c.r[1] = ld32(c.r[14] + 8);  // 0608964C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608964E mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 06089650 mov r1,r6
    c.r[5] = c.r[2];  // 06089652 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 06089654 mov.l @r14,r4
    c.r[8] = ld32(0x06089670u);  // 06089656 mov.l 0x06089670,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608965Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608965Cu) return; }  // 06089658 jsr @r8 ; nop
L_0608965C:
    c.r[14] += 12;  // 0608965C add #12,r14
    c.r[15] = c.r[14];  // 0608965E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089660 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089662 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089664 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089666 rts ; nop
}

void f_06089674(SH2Context& c) {
    ran[1947] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089674 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089676 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089678 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608967A add #-4,r15
    c.r[14] = c.r[15];  // 0608967C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608967E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089680 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089682 tst r1,r1
    if (!c.t) { goto L_06089694; }  // 06089684 bf 0x06089694
    c.r[1] = (uint32_t)(int16_t)ld16(0x060896AAu);  // 06089686 mov.w 0x060896AA,r1
    c.r[4] = c.r[1];  // 06089688 mov r1,r4
    c.r[8] = ld32(0x060896ACu);  // 0608968A mov.l 0x060896AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089690u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089690u) return; }  // 0608968C jsr @r8 ; nop
    goto L_0608969C;  // 06089690 bra 0x0608969C ; nop
L_06089694:
    c.r[4] = ld32(c.r[14]);  // 06089694 mov.l @r14,r4
    c.r[8] = ld32(0x060896B0u);  // 06089696 mov.l 0x060896B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608969Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608969Cu) return; }  // 06089698 jsr @r8 ; nop
L_0608969C:
    c.r[14] += 4;  // 0608969C add #4,r14
    c.r[15] = c.r[14];  // 0608969E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060896A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060896A2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060896A4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060896A6 rts ; nop
}

void f_060896B4(SH2Context& c) {
    ran[1948] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060896B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060896B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060896B8 sts.l pr,@-r15
    c.r[15] -= 8;  // 060896BA add #-8,r15
    c.r[14] = c.r[15];  // 060896BC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060896BE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060896C0 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060896C2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060896C4 tst r1,r1
    if (!c.t) { goto L_060896D6; }  // 060896C6 bf 0x060896D6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060896F0u);  // 060896C8 mov.w 0x060896F0,r1
    c.r[4] = c.r[1];  // 060896CA mov r1,r4
    c.r[8] = ld32(0x060896F4u);  // 060896CC mov.l 0x060896F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060896D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060896D2u) return; }  // 060896CE jsr @r8 ; nop
    goto L_060896E2;  // 060896D2 bra 0x060896E2 ; nop
L_060896D6:
    c.r[1] = ld32(c.r[14] + 4);  // 060896D6 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060896D8 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060896DA mov.l @r14,r4
    c.r[8] = ld32(0x060896F8u);  // 060896DC mov.l 0x060896F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060896E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060896E2u) return; }  // 060896DE jsr @r8 ; nop
L_060896E2:
    c.r[14] += 8;  // 060896E2 add #8,r14
    c.r[15] = c.r[14];  // 060896E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060896E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060896E8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060896EA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060896EC rts ; nop
}

void f_060896FC(SH2Context& c) {
    ran[1949] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060896FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060896FE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089700 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089702 add #-8,r15
    c.r[14] = c.r[15];  // 06089704 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089706 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089708 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608970A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608970C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608970E mov.l @r14,r4
    c.r[8] = ld32(0x06089724u);  // 06089710 mov.l 0x06089724,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089716u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089716u) return; }  // 06089712 jsr @r8 ; nop
    c.r[14] += 8;  // 06089716 add #8,r14
    c.r[15] = c.r[14];  // 06089718 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608971A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608971C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608971E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089720 rts ; nop
}

void f_06089728(SH2Context& c) {
    ran[1950] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089728 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608972A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608972C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608972E add #-8,r15
    c.r[14] = c.r[15];  // 06089730 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089732 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089734 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089736 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089738 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608973A mov.l @r14,r4
    c.r[8] = ld32(0x06089750u);  // 0608973C mov.l 0x06089750,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089742u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089742u) return; }  // 0608973E jsr @r8 ; nop
    c.r[14] += 8;  // 06089742 add #8,r14
    c.r[15] = c.r[14];  // 06089744 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089746 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089748 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608974A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608974C rts ; nop
}

void f_06089754(SH2Context& c) {
    ran[1951] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089754 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089756 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089758 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608975A add #-4,r15
    c.r[14] = c.r[15];  // 0608975C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608975E mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 06089760 mov.l @r14,r4
    c.r[8] = ld32(0x06089778u);  // 06089762 mov.l 0x06089778,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089768u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089768u) return; }  // 06089764 jsr @r8 ; nop
    c.r[14] += 4;  // 06089768 add #4,r14
    c.r[15] = c.r[14];  // 0608976A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608976C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608976E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089770 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089772 rts ; nop
}

void f_0608977C(SH2Context& c) {
    ran[1952] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608977C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608977E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089780 sts.l pr,@-r15
    c.r[15] -= 16;  // 06089782 add #-16,r15
    c.r[14] = c.r[15];  // 06089784 mov r15,r14
    c.r[1] = 0x0u;  // 06089786 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06089788 mov.l r1,@(4,r14)
    c.r[8] = ld32(0x06089834u);  // 0608978A mov.l 0x06089834,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089790u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089790u) return; }  // 0608978C jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06089790 mov.l r0,@(8,r14)
    c.r[1] = 0x0u;  // 06089792 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 06089794 mov.l r1,@(12,r14)
L_06089796:
    c.r[1] = ld32(c.r[14] + 12);  // 06089796 mov.l @(12,r14),r1
    c.r[2] = 0x1Fu;  // 06089798 mov #31,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608979A cmp/gt r2,r1
    if (!c.t) { goto L_060897A2; }  // 0608979C bf 0x060897A2
    goto L_060897CE;  // 0608979E bra 0x060897CE ; nop
L_060897A2:
    c.r[1] = ld32(c.r[14] + 12);  // 060897A2 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 060897A4 mov r1,r4
    c.r[8] = ld32(0x06089838u);  // 060897A6 mov.l 0x06089838,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060897ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060897ACu) return; }  // 060897A8 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060897AC mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 060897AE mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 060897B0 mov.l @(8,r14),r2
    c.t = c.r[1] == c.r[2];  // 060897B2 cmp/eq r2,r1
    if (c.t) { goto L_060897C0; }  // 060897B4 bt 0x060897C0
    c.r[1] = ld32(c.r[14] + 4);  // 060897B6 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060897B8 tst r1,r1
    if (c.t) { goto L_060897C0; }  // 060897BA bt 0x060897C0
    goto L_060897CE;  // 060897BC bra 0x060897CE ; nop
L_060897C0:
    c.r[2] = ld32(c.r[14] + 12);  // 060897C0 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 060897C2 mov r2,r1
    c.r[1] += 1;  // 060897C4 add #1,r1
    c.r[2] = c.r[1];  // 060897C6 mov r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 060897C8 mov.l r2,@(12,r14)
    SH2_POLL(c); goto L_06089796;  // 060897CA bra 0x06089796 ; nop
L_060897CE:
    c.r[8] = ld32(0x0608983Cu);  // 060897CE mov.l 0x0608983C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060897D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060897D4u) return; }  // 060897D0 jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 060897D4 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 060897D6 mov.l @r14,r1
    c.r[3] = 0x3u;  // 060897D8 mov #3,r3
    c.r[2] = 0x0u;  // 060897DA mov #0,r2
    c.r[1] -= c.r[2];  // 060897DC sub r2,r1
    c.t = c.r[1] > c.r[3];  // 060897DE cmp/hi r3,r1
    if (c.t) { goto L_06089814; }  // 060897E0 bt 0x06089814
    c.r[1] += c.r[1];  // 060897E2 add r1,r1
    c.r[0] = 0x060897F0u;  // 060897E4 mova 0x060897F0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060897E6 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060897E8 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060897F8u: goto L_060897F8; case 0x06089814u: goto L_06089814; case 0x06089806u: goto L_06089806; default: sh2_call(c, x); return; } }  // 060897EA jmp @r0 ; nop
L_060897F8:
    c.r[1] = ld32(c.r[14] + 4);  // 060897F8 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 060897FA mov r1,r4
    c.r[8] = ld32(0x06089840u);  // 060897FC mov.l 0x06089840,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089802u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089802u) return; }  // 060897FE jsr @r8 ; nop
    goto L_06089822;  // 06089802 bra 0x06089822 ; nop
L_06089806:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089830u);  // 06089806 mov.w 0x06089830,r1
    c.r[4] = c.r[1];  // 06089808 mov r1,r4
    c.r[8] = ld32(0x06089844u);  // 0608980A mov.l 0x06089844,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089810u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089810u) return; }  // 0608980C jsr @r8 ; nop
    goto L_06089822;  // 06089810 bra 0x06089822 ; nop
L_06089814:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089832u);  // 06089814 mov.w 0x06089832,r1
    c.r[4] = c.r[1];  // 06089816 mov r1,r4
    c.r[8] = ld32(0x06089844u);  // 06089818 mov.l 0x06089844,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608981Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608981Eu) return; }  // 0608981A jsr @r8 ; nop
    goto L_06089822;  // 0608981E bra 0x06089822 ; nop
L_06089822:
    c.r[14] += 16;  // 06089822 add #16,r14
    c.r[15] = c.r[14];  // 06089824 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089826 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089828 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608982A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608982C rts ; nop
}

}  // namespace p_srwfin_installed
