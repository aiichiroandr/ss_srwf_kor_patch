#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060A0100(SH2Context& c) {
    ran[2590] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A0100 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A0102 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A0104 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A0106 sts.l pr,@-r15
    c.r[10] = c.r[4];  // 060A0108 mov r4,r10
    c.r[0] = ld32(0x060A0134u);  // 060A010A mov.l 0x060A0134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A0110u; c.r[8] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0110u) return; }  // 060A010C jsr @r0 ; mov r5,r8
    c.r[9] = c.r[0];  // 060A0110 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A0112 tst r9,r9
    if (!c.t) { goto L_060A0128; }  // 060A0114 bf 0x060A0128
    c.r[0] = ld32(c.r[8] + 16);  // 060A0116 mov.l @(16,r8),r0
    c.t = c.r[0] == 0x3u;  // 060A0118 cmp/eq #3,r0
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060A0128; } }  // 060A011A bf/s 0x060A0128 ; tst r8,r8
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_060A0128; } }  // 060A011E bt/s 0x060A0128 ; mov r8,r5
    c.r[0] = ld32(0x060A0138u);  // 060A0122 mov.l 0x060A0138,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A0128u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0128u) return; }  // 060A0124 jsr @r0 ; mov r10,r4
L_060A0128:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A0128 lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A012A mov.l @r15+,r10
    c.r[0] = c.r[9];  // 060A012C mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A012E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A0130 rts ; mov.l @r15+,r8
}

void f_060A013C(SH2Context& c) {
    ran[2591] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A013C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A013E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A0140 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A0142 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A0144 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A0146 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A0148 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A014A sts.l pr,@-r15
    c.r[15] -= 20;  // 060A014C add #-20,r15
    c.r[12] = c.r[4];  // 060A014E mov r4,r12
    c.r[1] = ld32(0x060A0260u);  // 060A0150 mov.l 0x060A0260,r1
    c.r[1] = ld32(c.r[1]);  // 060A0152 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A0154 tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_060A0162; } }  // 060A0156 bt/s 0x060A0162 ; mov r5,r8
    c.r[2] = ld32(0x060A0264u);  // 060A015A mov.l 0x060A0264,r2
L_060A015C:
    c.r[1] = ld32(c.r[2]);  // 060A015C mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A015E tst r1,r1
    if (!c.t) { SH2_POLL(c); goto L_060A015C; }  // 060A0160 bf 0x060A015C
L_060A0162:
    c.r[0] = ld32(0x060A0268u);  // 060A0162 mov.l 0x060A0268,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A0168u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0168u) return; }  // 060A0164 jsr @r0 ; nop
    c.r[7] = c.r[12];  // 060A0168 mov r12,r7
    c.r[7] += 72;  // 060A016A add #72,r7
    c.r[2] = ld32(c.r[12] + 8);  // 060A016C mov.l @(8,r12),r2
    c.r[3] = c.r[12];  // 060A016E mov r12,r3
    c.r[1] = ld32(c.r[7]);  // 060A0170 mov.l @r7,r1
    c.r[3] += 76;  // 060A0172 add #76,r3
    c.r[9] = ld32(c.r[12] + 16);  // 060A0174 mov.l @(16,r12),r9
    c.r[14] = c.r[2];  // 060A0176 mov r2,r14
    c.r[14] += c.r[1];  // 060A0178 add r1,r14
    c.r[2] = ld32(c.r[8] + 4);  // 060A017A mov.l @(4,r8),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060A025Cu);  // 060A017C mov.w 0x060A025C,r0
    c.r[8] = ld32(c.r[3]);  // 060A017E mov.l @r3,r8
    c.r[11] = c.r[1];  // 060A0180 mov r1,r11
    st16(c.r[0] + c.r[12], c.r[8]);  // 060A0182 mov.w r8,@(r0,r12)
    c.t = (int32_t)c.r[8] >= 0;  // 060A0184 cmp/pz r8
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060A018C; } }  // 060A0186 bt/s 0x060A018C ; mov r8,r1
    c.r[1] += 7;  // 060A018A add #7,r1
L_060A018C:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060A018C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060A018E shar r1
    c.r[8] = c.r[1];  // 060A0190 mov r1,r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 060A0192 shar r8
    c.r[0] = c.r[11];  // 060A0194 mov r11,r0
    c.r[0] <<= 2;  // 060A0196 shll2 r0
    c.r[0] += c.r[0];  // 060A0198 add r0,r0
    st32(c.r[15], c.r[0]);  // 060A019A mov.l r0,@r15
    c.t = (int32_t)c.r[11] >= 0;  // 060A019C cmp/pz r11
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060A01A4; } }  // 060A019E bt/s 0x060A01A4 ; mov r11,r1
    c.r[1] += 7;  // 060A01A2 add #7,r1
L_060A01A4:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060A01A4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060A01A6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060A01A8 shar r1
    c.r[1] <<= 2;  // 060A01AA shll2 r1
    c.r[1] <<= 2;  // 060A01AC shll2 r1
    c.r[1] <<= 2;  // 060A01AE shll2 r1
    st32(c.r[15] + 4, c.r[1]);  // 060A01B0 mov.l r1,@(4,r15)
    c.r[1] = ld32(0x060A026Cu);  // 060A01B2 mov.l 0x060A026C,r1
    c.r[14] &= c.r[1];  // 060A01B4 and r1,r14
    c.r[9] &= c.r[1];  // 060A01B6 and r1,r9
    c.r[1] = c.r[12];  // 060A01B8 mov r12,r1
    c.r[1] += 88;  // 060A01BA add #88,r1
    c.r[1] = ld32(c.r[1]);  // 060A01BC mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A01BE tst r1,r1
    { const bool k = c.t; c.r[1] = ld32(c.r[7]); if (k) { goto L_060A01E2; } }  // 060A01C0 bt/s 0x060A01E2 ; mov.l @r7,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060A01C4 shlr r1
    c.r[1] <<= 2;  // 060A01C6 shll2 r1
    c.r[9] += c.r[1];  // 060A01C8 add r1,r9
    c.r[1] = c.r[12];  // 060A01CA mov r12,r1
    c.r[1] += 84;  // 060A01CC add #84,r1
    c.r[0] = ld32(c.r[1]);  // 060A01CE mov.l @r1,r0
    c.t = c.r[0] == 0x3u;  // 060A01D0 cmp/eq #3,r0
    { const bool k = !c.t; c.r[13] = c.r[11]; if (k) { goto L_060A01DC; } }  // 060A01D2 bf/s 0x060A01DC ; mov r11,r13
    c.r[10] = ld32(0x060A0270u);  // 060A01D6 mov.l 0x060A0270,r10
    c.r[8] -= 1; goto L_060A01FE;  // 060A01D8 bra 0x060A01FE ; add #-1,r8
L_060A01DC:
    c.r[10] = ld32(0x060A0274u);  // 060A01DC mov.l 0x060A0274,r10
    c.r[13] += c.r[13]; goto L_060A01FC;  // 060A01DE bra 0x060A01FC ; add r13,r13
L_060A01E2:
    c.r[1] >>= 2;  // 060A01E2 shlr2 r1
    c.r[1] <<= 2;  // 060A01E4 shll2 r1
    c.r[9] += c.r[1];  // 060A01E6 add r1,r9
    c.r[1] = c.r[12];  // 060A01E8 mov r12,r1
    c.r[1] += 84;  // 060A01EA add #84,r1
    c.r[0] = ld32(c.r[1]);  // 060A01EC mov.l @r1,r0
    c.t = c.r[0] == 0x3u;  // 060A01EE cmp/eq #3,r0
    { const bool k = !c.t; c.r[13] = c.r[11]; if (k) { goto L_060A01FA; } }  // 060A01F0 bf/s 0x060A01FA ; mov r11,r13
    c.r[10] = ld32(0x060A0278u);  // 060A01F4 mov.l 0x060A0278,r10
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1); goto L_060A01FC;  // 060A01F6 bra 0x060A01FC ; shar r13
L_060A01FA:
    c.r[10] = ld32(0x060A027Cu);  // 060A01FA mov.l 0x060A027C,r10
L_060A01FC:
    c.r[8] -= 1;  // 060A01FC add #-1,r8
L_060A01FE:
    c.r[0] = c.r[8];  // 060A01FE mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0200 cmp/eq #-1,r0
    { const bool k = c.t; c.r[7] = c.r[11]; if (k) { goto L_060A023A; } }  // 060A0202 bt/s 0x060A023A ; mov r11,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x060A025Cu);  // 060A0206 mov.w 0x060A025C,r3
L_060A0208:
    c.r[6] = c.r[2];  // 060A0208 mov r2,r6
    c.r[5] = c.r[9];  // 060A020A mov r9,r5
    c.r[4] = c.r[14];  // 060A020C mov r14,r4
    st32(c.r[15] + 12, c.r[2]);  // 060A020E mov.l r2,@(12,r15)
    { const uint32_t x = c.r[10]; c.pr = 0x060A0214u; st32(c.r[15] + 16, c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0214u) return; }  // 060A0210 jsr @r10 ; mov.l r3,@(16,r15)
    c.r[1] = c.r[13];  // 060A0214 mov r13,r1
    c.r[1] <<= 2;  // 060A0216 shll2 r1
    c.r[0] = ld32(c.r[15]);  // 060A0218 mov.l @r15,r0
    c.r[9] += c.r[1];  // 060A021A add r1,r9
    c.r[1] = ld32(c.r[15] + 4);  // 060A021C mov.l @(4,r15),r1
    c.r[2] = ld32(c.r[15] + 12);  // 060A021E mov.l @(12,r15),r2
    c.r[3] = ld32(c.r[15] + 16);  // 060A0220 mov.l @(16,r15),r3
    c.r[14] += c.r[0];  // 060A0222 add r0,r14
    c.r[1] <<= 2;  // 060A0224 shll2 r1
    c.r[2] += c.r[1];  // 060A0226 add r1,r2
    c.r[0] = c.r[12];  // 060A0228 mov r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060A022A mov.w @(r0,r3),r1
    c.r[8] -= 1;  // 060A022C add #-1,r8
    c.r[1] -= 8;  // 060A022E add #-8,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 060A0230 mov.w r1,@(r0,r3)
    c.r[0] = c.r[8];  // 060A0232 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0234 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[7] = c.r[11]; if (k) { SH2_POLL(c); goto L_060A0208; } }  // 060A0236 bf/s 0x060A0208 ; mov r11,r7
L_060A023A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060A025Cu);  // 060A023A mov.w 0x060A025C,r0
    c.r[1] = 0x0u;  // 060A023C mov #0,r1
    st16(c.r[0] + c.r[12], c.r[1]);  // 060A023E mov.w r1,@(r0,r12)
    c.r[2] = ld32(0x060A0264u);  // 060A0240 mov.l 0x060A0264,r2
    c.r[1] = 0x1u;  // 060A0242 mov #1,r1
    st32(c.r[2], c.r[1]);  // 060A0244 mov.l r1,@r2
    c.r[15] += 20;  // 060A0246 add #20,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A0248 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A024A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A024C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A024E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A0250 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A0252 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A0254 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060A0256 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060A0258 rts ; mov #0,r0
}

void f_060A02A0(SH2Context& c) {
    ran[2592] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A02A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A02A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A02A4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A02A6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A02A8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A02AA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A02AC sts.l pr,@-r15
    c.r[11] = c.r[4];  // 060A02AE mov r4,r11
    c.r[10] = c.r[5];  // 060A02B0 mov r5,r10
    c.r[8] = ld32(c.r[11]);  // 060A02B2 mov.l @r11,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A02B4 tst r8,r8
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060A02C6; } }  // 060A02B6 bt/s 0x060A02C6 ; mov r6,r9
    c.r[1] = ld32(c.r[11] + 32);  // 060A02BA mov.l @(32,r11),r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060A02BC cmp/gt r1,r9
    if (!c.t) { goto L_060A02C2; }  // 060A02BE bf 0x060A02C2
    c.r[9] = c.r[1];  // 060A02C0 mov r1,r9
L_060A02C2:
    c.r[1] -= c.r[9];  // 060A02C2 sub r9,r1
    st32(c.r[11] + 32, c.r[1]);  // 060A02C4 mov.l r1,@(32,r11)
L_060A02C6:
    c.r[12] = c.r[9];  // 060A02C6 mov r9,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 060A02C8 tst r12,r12
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060A02D2; } }  // 060A02CA bf/s 0x060A02D2 ; mov #0,r0
    goto L_060A0470;  // 060A02CE bra 0x060A0470 ; nop
L_060A02D2:
    c.r[6] = ld32(c.r[10] + 8);  // 060A02D2 mov.l @(8,r10),r6
    c.r[7] = ld32(0x060A03A4u);  // 060A02D4 mov.l 0x060A03A4,r7
    c.r[4] = ld32(c.r[10] + 12);  // 060A02D6 mov.l @(12,r10),r4
    { const uint32_t x = c.r[7]; c.pr = 0x060A02DCu; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A02DCu) return; }  // 060A02D8 jsr @r7 ; mov r6,r5
    c.r[7] = c.r[0];  // 060A02DC mov r0,r7
    c.macl = c.r[7] * c.r[6];  // 060A02DE mul.l r6,r7
    c.r[1] = c.macl;  // 060A02E0 sts macl,r1
    c.r[7] = c.r[4];  // 060A02E2 mov r4,r7
    c.r[7] -= c.r[1];  // 060A02E4 sub r1,r7
    c.r[1] = c.r[11];  // 060A02E6 mov r11,r1
    c.r[1] += 78;  // 060A02E8 add #78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A02EA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A02EC extu.w r1,r1
    c.r[0] = c.r[1];  // 060A02EE mov r1,r0
    c.t = c.r[0] == 0x8u;  // 060A02F0 cmp/eq #8,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_060A03A8; } }  // 060A02F2 bf/s 0x060A03A8 ; mov r7,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x060A03A0u);  // 060A02F6 mov.w 0x060A03A0,r4
    c.r[2] = ld32(c.r[10]);  // 060A02F8 mov.l @r10,r2
    c.r[5] = 0x0u;  // 060A02FA mov #0,r5
    c.r[6] = ld32(c.r[10] + 4);  // 060A02FC mov.l @(4,r10),r6
    c.r[2] += c.r[7];  // 060A02FE add r7,r2
    c.r[6] += c.r[7];  // 060A0300 add r7,r6
L_060A0302:
    c.r[1] = c.r[9];  // 060A0302 mov r9,r1
    c.r[1] += c.r[7];  // 060A0304 add r7,r1
    c.r[3] = ld32(c.r[10] + 8);  // 060A0306 mov.l @(8,r10),r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 060A0308 cmp/gt r3,r1
    { const bool k = !c.t; c.r[13] = c.r[9]; if (k) { goto L_060A0312; } }  // 060A030A bf/s 0x060A0312 ; mov r9,r13
    c.r[13] = c.r[3];  // 060A030E mov r3,r13
    c.r[13] -= c.r[7];  // 060A0310 sub r7,r13
L_060A0312:
    c.r[1] = ld32(c.r[11] + 24);  // 060A0312 mov.l @(24,r11),r1
    c.r[0] = c.r[1];  // 060A0314 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060A0316 cmp/eq #1,r0
    { const bool k = c.t; c.r[9] -= c.r[13]; if (k) { goto L_060A0326; } }  // 060A0318 bt/s 0x060A0326 ; sub r13,r9
    c.t = c.r[0] == 0x2u;  // 060A031C cmp/eq #2,r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060A035C; } }  // 060A031E bt/s 0x060A035C ; tst r8,r8
    c.r[2] = ld32(c.r[10]); goto L_060A0394;  // 060A0322 bra 0x060A0394 ; mov.l @r10,r2
L_060A0326:
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A0326 tst r8,r8
    { const bool k = c.t; c.r[13] -= 1; if (k) { goto L_060A0346; } }  // 060A0328 bt/s 0x060A0346 ; add #-1,r13
    c.r[0] = c.r[13];  // 060A032C mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A032E cmp/eq #-1,r0
    if (c.t) { goto L_060A0392; }  // 060A0330 bt 0x060A0392
L_060A0332:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A0332 mov.b @r8+,r1
    c.r[13] -= 1;  // 060A0334 add #-1,r13
    c.r[0] = c.r[13];  // 060A0336 mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0338 cmp/eq #-1,r0
    c.r[1] += c.r[4];  // 060A033A add r4,r1
    st8(c.r[2], c.r[1]);  // 060A033C mov.b r1,@r2
    { const bool k = !c.t; c.r[2] += 1; if (k) { SH2_POLL(c); goto L_060A0332; } }  // 060A033E bf/s 0x060A0332 ; add #1,r2
    c.r[2] = ld32(c.r[10]); goto L_060A0394;  // 060A0342 bra 0x060A0394 ; mov.l @r10,r2
L_060A0346:
    c.r[0] = c.r[13];  // 060A0346 mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0348 cmp/eq #-1,r0
    if (c.t) { goto L_060A0392; }  // 060A034A bt 0x060A0392
L_060A034C:
    st8(c.r[2], c.r[5]);  // 060A034C mov.b r5,@r2
    c.r[13] -= 1;  // 060A034E add #-1,r13
    c.r[0] = c.r[13];  // 060A0350 mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0352 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[2] += 1; if (k) { SH2_POLL(c); goto L_060A034C; } }  // 060A0354 bf/s 0x060A034C ; add #1,r2
    c.r[2] = ld32(c.r[10]); goto L_060A0394;  // 060A0358 bra 0x060A0394 ; mov.l @r10,r2
L_060A035C:
    if (c.t) { goto L_060A038A; }  // 060A035C bt 0x060A038A
    c.r[13] -= 1;  // 060A035E add #-1,r13
    c.r[0] = c.r[13];  // 060A0360 mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0362 cmp/eq #-1,r0
    if (c.t) { goto L_060A0392; }  // 060A0364 bt 0x060A0392
L_060A0366:
    c.r[13] -= 1;  // 060A0366 add #-1,r13
    c.r[0] = c.r[13];  // 060A0368 mov r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A036A mov.b @r8+,r1
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A036C cmp/eq #-1,r0
    c.r[1] += c.r[4];  // 060A036E add r4,r1
    st8(c.r[2], c.r[1]);  // 060A0370 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A0372 mov.b @r8+,r1
    c.r[2] += 1;  // 060A0374 add #1,r2
    c.r[1] += c.r[4];  // 060A0376 add r4,r1
    st8(c.r[6], c.r[1]);  // 060A0378 mov.b r1,@r6
    { const bool k = !c.t; c.r[6] += 1; if (k) { SH2_POLL(c); goto L_060A0366; } }  // 060A037A bf/s 0x060A0366 ; add #1,r6
    c.r[2] = ld32(c.r[10]); goto L_060A0394;  // 060A037E bra 0x060A0394 ; mov.l @r10,r2
L_060A0382:
    st8(c.r[2], c.r[5]);  // 060A0382 mov.b r5,@r2
    st8(c.r[6], c.r[5]);  // 060A0384 mov.b r5,@r6
    c.r[2] += 1;  // 060A0386 add #1,r2
    c.r[6] += 1;  // 060A0388 add #1,r6
L_060A038A:
    c.r[13] -= 1;  // 060A038A add #-1,r13
    c.r[0] = c.r[13];  // 060A038C mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A038E cmp/eq #-1,r0
    if (!c.t) { SH2_POLL(c); goto L_060A0382; }  // 060A0390 bf 0x060A0382
L_060A0392:
    c.r[2] = ld32(c.r[10]);  // 060A0392 mov.l @r10,r2
L_060A0394:
    c.r[7] = 0x0u;  // 060A0394 mov #0,r7
    c.t = (int32_t)c.r[9] > 0;  // 060A0396 cmp/pl r9
    { const bool k = c.t; c.r[6] = ld32(c.r[10] + 4); if (k) { SH2_POLL(c); goto L_060A0302; } }  // 060A0398 bt/s 0x060A0302 ; mov.l @(4,r10),r6
    c.r[1] = ld32(c.r[10] + 12); goto L_060A0468;  // 060A039C bra 0x060A0468 ; mov.l @(12,r10),r1
L_060A03A8:
    c.r[1] += c.r[1];  // 060A03A8 add r1,r1
    c.r[3] = ld32(c.r[10]);  // 060A03AA mov.l @r10,r3
    c.r[5] = 0x0u;  // 060A03AC mov #0,r5
    c.r[6] = ld32(c.r[10] + 4);  // 060A03AE mov.l @(4,r10),r6
    c.r[3] += c.r[1];  // 060A03B0 add r1,r3
    c.r[6] += c.r[1];  // 060A03B2 add r1,r6
L_060A03B4:
    c.r[1] = c.r[9];  // 060A03B4 mov r9,r1
    c.r[1] += c.r[7];  // 060A03B6 add r7,r1
    c.r[2] = ld32(c.r[10] + 8);  // 060A03B8 mov.l @(8,r10),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060A03BA cmp/gt r2,r1
    { const bool k = !c.t; c.r[13] = c.r[9]; if (k) { goto L_060A03C4; } }  // 060A03BC bf/s 0x060A03C4 ; mov r9,r13
    c.r[13] = c.r[2];  // 060A03C0 mov r2,r13
    c.r[13] -= c.r[7];  // 060A03C2 sub r7,r13
L_060A03C4:
    c.r[1] = ld32(c.r[11] + 24);  // 060A03C4 mov.l @(24,r11),r1
    c.r[0] = c.r[1];  // 060A03C6 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060A03C8 cmp/eq #1,r0
    { const bool k = c.t; c.r[9] -= c.r[13]; if (k) { goto L_060A03D8; } }  // 060A03CA bt/s 0x060A03D8 ; sub r13,r9
    c.t = c.r[0] == 0x2u;  // 060A03CE cmp/eq #2,r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060A0416; } }  // 060A03D0 bt/s 0x060A0416 ; tst r8,r8
    c.r[3] = ld32(c.r[10]); goto L_060A045E;  // 060A03D4 bra 0x060A045E ; mov.l @r10,r3
L_060A03D8:
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A03D8 tst r8,r8
    { const bool k = c.t; c.r[13] -= 1; if (k) { goto L_060A0400; } }  // 060A03DA bt/s 0x060A0400 ; add #-1,r13
    c.r[0] = c.r[13];  // 060A03DE mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A03E0 cmp/eq #-1,r0
    if (c.t) { goto L_060A045C; }  // 060A03E2 bt 0x060A045C
L_060A03E4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A03E4 mov.b @r8+,r1
    c.r[13] -= 1;  // 060A03E6 add #-1,r13
    c.r[2] = c.r[1] & 0xFFu;  // 060A03E8 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A03EA mov.b @r8+,r1
    c.r[0] = c.r[13];  // 060A03EC mov r13,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060A03EE extu.b r1,r1
    c.r[1] <<= 8;  // 060A03F0 shll8 r1
    c.r[2] |= c.r[1];  // 060A03F2 or r1,r2
    st16(c.r[3], c.r[2]);  // 060A03F4 mov.w r2,@r3
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A03F6 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_060A03E4; } }  // 060A03F8 bf/s 0x060A03E4 ; add #2,r3
    c.r[3] = ld32(c.r[10]); goto L_060A045E;  // 060A03FC bra 0x060A045E ; mov.l @r10,r3
L_060A0400:
    c.r[0] = c.r[13];  // 060A0400 mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0402 cmp/eq #-1,r0
    if (c.t) { goto L_060A045C; }  // 060A0404 bt 0x060A045C
L_060A0406:
    st16(c.r[3], c.r[5]);  // 060A0406 mov.w r5,@r3
    c.r[13] -= 1;  // 060A0408 add #-1,r13
    c.r[0] = c.r[13];  // 060A040A mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A040C cmp/eq #-1,r0
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_060A0406; } }  // 060A040E bf/s 0x060A0406 ; add #2,r3
    c.r[3] = ld32(c.r[10]); goto L_060A045E;  // 060A0412 bra 0x060A045E ; mov.l @r10,r3
L_060A0416:
    if (c.t) { goto L_060A0454; }  // 060A0416 bt 0x060A0454
    c.r[13] -= 1;  // 060A0418 add #-1,r13
    c.r[0] = c.r[13];  // 060A041A mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A041C cmp/eq #-1,r0
    if (c.t) { goto L_060A045C; }  // 060A041E bt 0x060A045C
L_060A0420:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A0420 mov.b @r8+,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060A0422 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A0424 mov.b @r8+,r1
    c.r[13] -= 1;  // 060A0426 add #-1,r13
    c.r[1] = c.r[1] & 0xFFu;  // 060A0428 extu.b r1,r1
    c.r[1] <<= 8;  // 060A042A shll8 r1
    c.r[2] |= c.r[1];  // 060A042C or r1,r2
    st16(c.r[3], c.r[2]);  // 060A042E mov.w r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A0430 mov.b @r8+,r1
    c.r[0] = c.r[13];  // 060A0432 mov r13,r0
    c.r[2] = c.r[1] & 0xFFu;  // 060A0434 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060A0436 mov.b @r8+,r1
    c.r[3] += 2;  // 060A0438 add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060A043A extu.b r1,r1
    c.r[1] <<= 8;  // 060A043C shll8 r1
    c.r[2] |= c.r[1];  // 060A043E or r1,r2
    st16(c.r[6], c.r[2]);  // 060A0440 mov.w r2,@r6
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0442 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_060A0420; } }  // 060A0444 bf/s 0x060A0420 ; add #2,r6
    c.r[3] = ld32(c.r[10]); goto L_060A045E;  // 060A0448 bra 0x060A045E ; mov.l @r10,r3
L_060A044C:
    st16(c.r[3], c.r[5]);  // 060A044C mov.w r5,@r3
    st16(c.r[6], c.r[5]);  // 060A044E mov.w r5,@r6
    c.r[3] += 2;  // 060A0450 add #2,r3
    c.r[6] += 2;  // 060A0452 add #2,r6
L_060A0454:
    c.r[13] -= 1;  // 060A0454 add #-1,r13
    c.r[0] = c.r[13];  // 060A0456 mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060A0458 cmp/eq #-1,r0
    if (!c.t) { SH2_POLL(c); goto L_060A044C; }  // 060A045A bf 0x060A044C
L_060A045C:
    c.r[3] = ld32(c.r[10]);  // 060A045C mov.l @r10,r3
L_060A045E:
    c.r[7] = 0x0u;  // 060A045E mov #0,r7
    c.t = (int32_t)c.r[9] > 0;  // 060A0460 cmp/pl r9
    { const bool k = c.t; c.r[6] = ld32(c.r[10] + 4); if (k) { SH2_POLL(c); goto L_060A03B4; } }  // 060A0462 bt/s 0x060A03B4 ; mov.l @(4,r10),r6
    c.r[1] = ld32(c.r[10] + 12);  // 060A0466 mov.l @(12,r10),r1
L_060A0468:
    c.r[0] = c.r[12];  // 060A0468 mov r12,r0
    c.r[1] += c.r[12];  // 060A046A add r12,r1
    st32(c.r[10] + 12, c.r[1]);  // 060A046C mov.l r1,@(12,r10)
    st32(c.r[11], c.r[8]);  // 060A046E mov.l r8,@r11
L_060A0470:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A0470 lds.l @r15+,pr
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A0472 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A0474 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A0476 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A0478 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A047A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A047C rts ; mov.l @r15+,r8
}

void f_060A0480(SH2Context& c) {
    ran[2593] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A0480 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A0482 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A0484 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A0486 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A0488 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A048A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A048C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A048E sts.l pr,@-r15
    c.r[12] = c.r[4];  // 060A0490 mov r4,r12
    c.r[9] = c.r[5];  // 060A0492 mov r5,r9
    c.r[13] = ld32(c.r[9]);  // 060A0494 mov.l @r9,r13
    c.r[11] = c.r[6];  // 060A0496 mov r6,r11
    c.r[1] = ld32(c.r[12]);  // 060A0498 mov.l @r12,r1
    c.r[14] = 0x0u;  // 060A049A mov #0,r14
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A049C tst r1,r1
    { const bool k = c.t; c.r[10] = ld32(c.r[9] + 4); if (k) { goto L_060A04AE; } }  // 060A049E bt/s 0x060A04AE ; mov.l @(4,r9),r10
    c.r[1] = ld32(c.r[12] + 8);  // 060A04A2 mov.l @(8,r12),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A04A4 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_060A04B0; } }  // 060A04A6 bf/s 0x060A04B0 ; mov r12,r1
    c.r[0] = 0x0u; goto L_060A0546;  // 060A04AA bra 0x060A0546 ; mov #0,r0
L_060A04AE:
    c.r[1] = c.r[12];  // 060A04AE mov r12,r1
L_060A04B0:
    c.r[1] += 64;  // 060A04B0 add #64,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A04B2 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060A04B4 extu.w r1,r0
    c.t = c.r[0] == 0x1u;  // 060A04B6 cmp/eq #1,r0
    if (c.t) { goto L_060A04C0; }  // 060A04B8 bt 0x060A04C0
    c.r[1] = ld32(c.r[12]);  // 060A04BA mov.l @r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A04BC tst r1,r1
    if (!c.t) { goto L_060A04CE; }  // 060A04BE bf 0x060A04CE
L_060A04C0:
    c.r[0] = ld32(0x060A0558u);  // 060A04C0 mov.l 0x060A0558,r0
    c.r[6] = c.r[11];  // 060A04C2 mov r11,r6
    c.r[5] = c.r[9];  // 060A04C4 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060A04CAu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A04CAu) return; }  // 060A04C6 jsr @r0 ; mov r12,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060A0548;  // 060A04CA bra 0x060A0548 ; lds.l @r15+,pr
L_060A04CE:
    c.r[6] = ld32(c.r[9] + 8);  // 060A04CE mov.l @(8,r9),r6
    c.r[7] = ld32(0x060A055Cu);  // 060A04D0 mov.l 0x060A055C,r7
    c.r[4] = ld32(c.r[9] + 12);  // 060A04D2 mov.l @(12,r9),r4
    { const uint32_t x = c.r[7]; c.pr = 0x060A04D8u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A04D8u) return; }  // 060A04D4 jsr @r7 ; mov r6,r5
    c.r[7] = c.r[0];  // 060A04D8 mov r0,r7
    c.macl = c.r[7] * c.r[6];  // 060A04DA mul.l r6,r7
    c.r[3] = c.r[4];  // 060A04DC mov r4,r3
    c.r[1] = c.macl;  // 060A04DE sts macl,r1
    c.r[3] -= c.r[1];  // 060A04E0 sub r1,r3
    c.r[1] = c.r[3];  // 060A04E2 mov r3,r1
    c.r[1] += c.r[1];  // 060A04E4 add r1,r1
    c.r[13] += c.r[1];  // 060A04E6 add r1,r13
    c.r[10] += c.r[1];  // 060A04E8 add r1,r10
    c.r[1] = c.r[11];  // 060A04EA mov r11,r1
L_060A04EC:
    c.r[1] += c.r[3];  // 060A04EC add r3,r1
    c.r[2] = ld32(c.r[9] + 8);  // 060A04EE mov.l @(8,r9),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060A04F0 cmp/gt r2,r1
    { const bool k = !c.t; c.r[8] = c.r[11]; if (k) { goto L_060A04FA; } }  // 060A04F2 bf/s 0x060A04FA ; mov r11,r8
    c.r[8] = c.r[2];  // 060A04F6 mov r2,r8
    c.r[8] -= c.r[3];  // 060A04F8 sub r3,r8
L_060A04FA:
    c.r[1] = c.r[12];  // 060A04FA mov r12,r1
    c.r[1] += 78;  // 060A04FC add #78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A04FE mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060A0500 extu.w r1,r0
    c.t = c.r[0] == 0x3u;  // 060A0502 cmp/eq #3,r0
    { const bool k = c.t; c.r[11] -= c.r[8]; if (k) { goto L_060A051C; } }  // 060A0504 bt/s 0x060A051C ; sub r8,r11
    c.r[0] = ld32(c.r[9] + 24);  // 060A0508 mov.l @(24,r9),r0
    c.t = c.r[0] == 0x2u;  // 060A050A cmp/eq #2,r0
    if (c.t) { goto L_060A0510; }  // 060A050C bt 0x060A0510
    c.r[10] = 0x0u;  // 060A050E mov #0,r10
L_060A0510:
    c.r[7] = c.r[8];  // 060A0510 mov r8,r7
    c.r[6] = c.r[10];  // 060A0512 mov r10,r6
    c.r[5] = c.r[13];  // 060A0514 mov r13,r5
    c.r[0] = ld32(0x060A0560u);  // 060A0516 mov.l 0x060A0560,r0
    c.r[4] = c.r[12]; goto L_060A0526;  // 060A0518 bra 0x060A0526 ; mov r12,r4
L_060A051C:
    c.r[7] = c.r[8];  // 060A051C mov r8,r7
    c.r[6] = c.r[10];  // 060A051E mov r10,r6
    c.r[5] = c.r[13];  // 060A0520 mov r13,r5
    c.r[4] = c.r[12];  // 060A0522 mov r12,r4
    c.r[0] = ld32(0x060A0564u);  // 060A0524 mov.l 0x060A0564,r0
L_060A0526:
    { const uint32_t x = c.r[0]; c.pr = 0x060A052Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A052Au) return; }  // 060A0526 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 060A052A mov r0,r1
    c.r[14] += c.r[1];  // 060A052C add r1,r14
    c.r[13] = ld32(c.r[9]);  // 060A052E mov.l @r9,r13
    c.r[3] = 0x0u;  // 060A0530 mov #0,r3
    c.t = (int32_t)c.r[11] > 0;  // 060A0532 cmp/pl r11
    { const bool k = !c.t; c.r[10] = ld32(c.r[9] + 4); if (k) { goto L_060A053E; } }  // 060A0534 bf/s 0x060A053E ; mov.l @(4,r9),r10
    c.t = c.r[1] == c.r[8];  // 060A0538 cmp/eq r8,r1
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { SH2_POLL(c); goto L_060A04EC; } }  // 060A053A bt/s 0x060A04EC ; mov r11,r1
L_060A053E:
    c.r[1] = ld32(c.r[9] + 12);  // 060A053E mov.l @(12,r9),r1
    c.r[0] = c.r[14];  // 060A0540 mov r14,r0
    c.r[1] += c.r[14];  // 060A0542 add r14,r1
    st32(c.r[9] + 12, c.r[1]);  // 060A0544 mov.l r1,@(12,r9)
L_060A0546:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A0546 lds.l @r15+,pr
L_060A0548:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A0548 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A054A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A054C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A054E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A0550 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A0552 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A0554 rts ; mov.l @r15+,r8
}

void f_060A0568(SH2Context& c) {
    ran[2594] = 1;
    c.r[1] = ld32(0x060A057Cu);  // 060A0568 mov.l 0x060A057C,r1
    c.r[2] = 0xFFFFFFFFu;  // 060A056A mov #-1,r2
    st8(c.r[1], c.r[2]);  // 060A056C mov.b r2,@r1
    c.r[1] = ld32(0x060A0580u);  // 060A056E mov.l 0x060A0580,r1
    st8(c.r[1], c.r[2]);  // 060A0570 mov.b r2,@r1
    c.r[2] = ld32(0x060A0584u);  // 060A0572 mov.l 0x060A0584,r2
    c.r[1] = 0xFFFFFFFFu;  // 060A0574 mov #-1,r1
    { const uint32_t x = c.pr; st16(c.r[2], c.r[1]); c.pc = x; return; }  // 060A0576 rts ; mov.w r1,@r2
}

void f_060A0588(SH2Context& c) {
    ran[2595] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A0588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A058A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A058C sts.l pr,@-r15
    c.r[9] = c.r[5];  // 060A058E mov r5,r9
    c.r[1] = c.r[9];  // 060A0590 mov r9,r1
    c.r[1] += 40;  // 060A0592 add #40,r1
    c.r[2] = 0xFFFFFFFFu;  // 060A0594 mov #-1,r2
    st16(c.r[1], c.r[2]);  // 060A0596 mov.w r2,@r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060A0598 mov.b @r4,r7
    c.r[1] = 0xFu;  // 060A059A mov #15,r1
    c.r[2] = c.r[7] & 0xFFu;  // 060A059C extu.b r7,r2
    c.t = c.r[2] > c.r[1];  // 060A059E cmp/hi r1,r2
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060A05A8; } }  // 060A05A0 bt/s 0x060A05A8 ; mov #-1,r0
    goto L_060A08AE;  // 060A05A4 bra 0x060A08AE ; nop
L_060A05A8:
    c.r[6] = c.r[9];  // 060A05A8 mov r9,r6
    c.r[6] += 48;  // 060A05AA add #48,r6
    c.r[3] = c.r[9];  // 060A05AC mov r9,r3
    c.r[3] += 38;  // 060A05AE add #38,r3
    c.r[2] >>= 2;  // 060A05B0 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060A05B2 shlr r2
    c.r[2] >>= 2;  // 060A05B4 shlr2 r2
    c.r[1] = c.r[7] & 0xFFu;  // 060A05B6 extu.b r7,r1
    c.r[1] <<= 2;  // 060A05B8 shll2 r1
    c.r[1] += c.r[1];  // 060A05BA add r1,r1
    c.r[0] = c.r[2];  // 060A05BC mov r2,r0
    c.r[0] |= c.r[1];  // 060A05BE or r1,r0
    c.r[0] &= 0x7Fu;  // 060A05C0 and #127,r0
    st16(c.r[3], c.r[0]);  // 060A05C2 mov.w r0,@r3
    c.r[0] = 0x1u;  // 060A05C4 mov #1,r0
    c.r[7] = 0x15u;  // 060A05C6 mov #21,r7
    c.r[2] = c.r[4];  // 060A05C8 mov r4,r2
    c.r[2] += 1;  // 060A05CA add #1,r2
L_060A05CC:
    c.r[1] = c.r[2];  // 060A05CC mov r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A05CE mov.b @r2,r2
    c.r[1] += 1;  // 060A05D0 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A05D2 mov.b @r1,r3
    c.r[2] ^= c.r[3];  // 060A05D4 xor r3,r2
    st8(c.r[0] + c.r[6], c.r[2]);  // 060A05D6 mov.b r2,@(r0,r6)
    c.r[0] += 1;  // 060A05D8 add #1,r0
    c.t = c.r[0] > c.r[7];  // 060A05DA cmp/hi r7,r0
    { const bool k = !c.t; c.r[2] = c.r[1]; if (k) { SH2_POLL(c); goto L_060A05CC; } }  // 060A05DC bf/s 0x060A05CC ; mov r1,r2
    c.r[2] = c.r[9];  // 060A05E0 mov r9,r2
    c.r[2] += 56;  // 060A05E2 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060A05E4 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A05E6 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A05E8 swap.b r1,r1
    st16(c.r[2], c.r[1]);  // 060A05EA mov.w r1,@r2
    c.r[1] = c.r[9];  // 060A05EC mov r9,r1
    c.r[1] += 38;  // 060A05EE add #38,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A05F0 mov.w @r1,r1
    c.r[2] = 0xAu;  // 060A05F2 mov #10,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A05F4 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 060A05F6 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060A066E; } }  // 060A05F8 bf/s 0x060A066E ; mov r9,r1
    c.r[1] += 58;  // 060A05FC add #58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A05FE mov.b @r1,r1
    c.r[7] = c.t;  // 060A0600 movt r7
    c.r[1] = c.r[1] & 0xFFu;  // 060A0602 extu.b r1,r1
    c.t = c.r[1] > c.r[7];  // 060A0604 cmp/hi r7,r1
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_060A0670; } }  // 060A0606 bf/s 0x060A0670 ; mov r9,r2
    c.r[1] = c.r[9];  // 060A060A mov r9,r1
    c.r[1] += 59;  // 060A060C add #59,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A060E mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 060A0610 extu.b r3,r2
    c.r[1] = 0x3u;  // 060A0612 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 060A0614 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_060A061E; } }  // 060A0616 bf/s 0x060A061E ; mov r3,r1
    c.r[0] = 0xFFFFFFFDu; goto L_060A08AE;  // 060A061A bra 0x060A08AE ; mov #-3,r0
L_060A061E:
    c.r[1] -= 2;  // 060A061E add #-2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A0620 extu.b r1,r1
    c.t = c.r[1] > c.r[7];  // 060A0622 cmp/hi r7,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_060A067E; } }  // 060A0624 bt/s 0x060A067E ; mov r9,r2
    c.r[3] = c.r[9];  // 060A0628 mov r9,r3
    c.r[3] += 60;  // 060A062A add #60,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060A062C mov.b @r3,r1
    c.r[2] += 28;  // 060A062E add #28,r2
    c.r[0] = c.r[1];  // 060A0630 mov r1,r0
    c.r[0] >>= 2;  // 060A0632 shlr2 r0
    c.r[0] &= 0x1u;  // 060A0634 and #1,r0
    st16(c.r[2], c.r[0]);  // 060A0636 mov.w r0,@r2
    c.r[2] = c.r[9];  // 060A0638 mov r9,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060A063A mov.b @r3,r0
    c.r[2] += 30;  // 060A063C add #30,r2
    c.r[0] &= 0x8u;  // 060A063E and #8,r0
    c.r[1] = c.r[0] & 0xFFu;  // 060A0640 extu.b r0,r1
    st16(c.r[2], c.r[1]);  // 060A0642 mov.w r1,@r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A0644 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A0646 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060A0656; } }  // 060A0648 bt/s 0x060A0656 ; mov r9,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060A064C mov.b @r3,r0
    c.r[1] += 32;  // 060A064E add #32,r1
    c.r[0] &= 0x10u;  // 060A0650 and #16,r0
    st16(c.r[1], c.r[0]); goto L_060A065E;  // 060A0652 bra 0x060A065E ; mov.w r0,@r1
L_060A0656:
    c.r[2] = c.r[9];  // 060A0656 mov r9,r2
    c.r[2] += 32;  // 060A0658 add #32,r2
    c.r[1] = 0x1u;  // 060A065A mov #1,r1
    st16(c.r[2], c.r[1]);  // 060A065C mov.w r1,@r2
L_060A065E:
    c.r[2] = c.r[9];  // 060A065E mov r9,r2
    c.r[1] = c.r[9];  // 060A0660 mov r9,r1
    c.r[1] += 60;  // 060A0662 add #60,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A0664 mov.b @r1,r0
    c.r[2] += 34;  // 060A0666 add #34,r2
    c.r[0] &= 0x20u;  // 060A0668 and #32,r0
    st16(c.r[2], c.r[0]); goto L_060A069A;  // 060A066A bra 0x060A069A ; mov.w r0,@r2
L_060A066E:
    c.r[2] = c.r[9];  // 060A066E mov r9,r2
L_060A0670:
    c.r[2] += 58;  // 060A0670 add #58,r2
    c.r[1] = 0x2u;  // 060A0672 mov #2,r1
    st8(c.r[2], c.r[1]);  // 060A0674 mov.b r1,@r2
    c.r[2] = c.r[9];  // 060A0676 mov r9,r2
    c.r[2] += 59;  // 060A0678 add #59,r2
    c.r[1] = 0x0u;  // 060A067A mov #0,r1
    st8(c.r[2], c.r[1]);  // 060A067C mov.b r1,@r2
L_060A067E:
    c.r[1] = c.r[9];  // 060A067E mov r9,r1
    c.r[1] += 28;  // 060A0680 add #28,r1
    c.r[2] = 0x0u;  // 060A0682 mov #0,r2
    st16(c.r[1], c.r[2]);  // 060A0684 mov.w r2,@r1
    c.r[1] = c.r[9];  // 060A0686 mov r9,r1
    c.r[1] += 30;  // 060A0688 add #30,r1
    st16(c.r[1], c.r[2]);  // 060A068A mov.w r2,@r1
    c.r[1] = c.r[9];  // 060A068C mov r9,r1
    c.r[1] += 34;  // 060A068E add #34,r1
    st16(c.r[1], c.r[2]);  // 060A0690 mov.w r2,@r1
    c.r[2] = c.r[9];  // 060A0692 mov r9,r2
    c.r[2] += 32;  // 060A0694 add #32,r2
    c.r[1] = 0x1u;  // 060A0696 mov #1,r1
    st16(c.r[2], c.r[1]);  // 060A0698 mov.w r1,@r2
L_060A069A:
    c.r[1] = c.r[9];  // 060A069A mov r9,r1
    c.r[1] += 34;  // 060A069C add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A069E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06A0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A06A2 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060A06D8; } }  // 060A06A4 bt/s 0x060A06D8 ; mov r9,r1
    c.r[1] += 66;  // 060A06A8 add #66,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A06AA mov.w @r1,r1
    c.r[2] = c.r[9];  // 060A06AC mov r9,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06AE extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A06B0 swap.b r1,r1
    st32(c.r[9] + 4, c.r[1]);  // 060A06B2 mov.l r1,@(4,r9)
    c.r[1] = c.r[9];  // 060A06B4 mov r9,r1
    c.r[1] += 68;  // 060A06B6 add #68,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A06B8 mov.w @r1,r1
    c.r[2] += 62;  // 060A06BA add #62,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06BC extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A06BE swap.b r1,r1
    st32(c.r[9] + 8, c.r[1]);  // 060A06C0 mov.l r1,@(8,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060A06C2 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06C4 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A06C6 swap.b r1,r1
    st16(c.r[2], c.r[1]);  // 060A06C8 mov.w r1,@r2
    c.r[2] = c.r[9];  // 060A06CA mov r9,r2
    c.r[2] += 64;  // 060A06CC add #64,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060A06CE mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06D0 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A06D2 swap.b r1,r1
    st16(c.r[2], c.r[1]); goto L_060A0710;  // 060A06D4 bra 0x060A0710 ; mov.w r1,@r2
L_060A06D8:
    c.r[1] += 54;  // 060A06D8 add #54,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A06DA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06DC extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A06DE swap.b r1,r1
    st32(c.r[9] + 4, c.r[1]);  // 060A06E0 mov.l r1,@(4,r9)
    c.r[1] = c.r[9];  // 060A06E2 mov r9,r1
    c.r[1] += 52;  // 060A06E4 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A06E6 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A06E8 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A06EA swap.b r1,r1
    st32(c.r[9] + 8, c.r[1]);  // 060A06EC mov.l r1,@(8,r9)
    c.r[1] = c.r[9];  // 060A06EE mov r9,r1
    c.r[1] += 59;  // 060A06F0 add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A06F2 mov.b @r1,r1
    c.r[2] = c.t;  // 060A06F4 movt r2
    c.r[1] = c.r[1] & 0xFFu;  // 060A06F6 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 060A06F8 cmp/hi r2,r1
    if (c.t) { goto L_060A0710; }  // 060A06FA bt 0x060A0710
    c.r[1] = ld32(c.r[9] + 4);  // 060A06FC mov.l @(4,r9),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060A07F0u);  // 060A06FE mov.w 0x060A07F0,r2
    c.r[1] += c.r[2];  // 060A0700 add r2,r1
    c.r[2] = 0x24u;  // 060A0702 mov #36,r2
    c.t = c.r[1] > c.r[2];  // 060A0704 cmp/hi r2,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_060A0710; } }  // 060A0706 bt/s 0x060A0710 ; mov r9,r2
    c.r[2] += 28;  // 060A070A add #28,r2
    c.r[1] = 0x2u;  // 060A070C mov #2,r1
    st16(c.r[2], c.r[1]);  // 060A070E mov.w r1,@r2
L_060A0710:
    c.r[2] = c.r[9];  // 060A0710 mov r9,r2
    c.r[2] += 54;  // 060A0712 add #54,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060A0714 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A0716 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A0718 swap.b r1,r1
    st16(c.r[2], c.r[1]);  // 060A071A mov.w r1,@r2
    c.r[2] = c.r[9];  // 060A071C mov r9,r2
    c.r[2] += 52;  // 060A071E add #52,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060A0720 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060A0722 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 060A0724 swap.b r1,r1
    st16(c.r[2], c.r[1]);  // 060A0726 mov.w r1,@r2
    c.r[1] = c.r[9];  // 060A0728 mov r9,r1
    c.r[1] += 49;  // 060A072A add #49,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A072C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060A072E extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060A0730 tst r2,r2
    { const bool k = !c.t; c.r[1] = 0x10u; if (k) { goto L_060A073A; } }  // 060A0732 bf/s 0x060A073A ; mov #16,r1
    c.r[0] = 0x0u; goto L_060A08AE;  // 060A0736 bra 0x060A08AE ; mov #0,r0
L_060A073A:
    c.t = c.r[2] > c.r[1];  // 060A073A cmp/hi r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_060A075A; } }  // 060A073C bt/s 0x060A075A ; shll2 r2
    c.r[2] += c.r[2];  // 060A0740 add r2,r2
    c.r[1] = ld32(0x060A07F4u);  // 060A0742 mov.l 0x060A07F4,r1
    c.r[3] = c.r[2];  // 060A0744 mov r2,r3
    c.r[3] += c.r[1];  // 060A0746 add r1,r3
    c.r[1] = c.r[9];  // 060A0748 mov r9,r1
    c.r[1] += 59;  // 060A074A add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A074C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060A074E extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060A0750 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A0752 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A0754 tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_060A075E; } }  // 060A0756 bf/s 0x060A075E ; mov r9,r2
L_060A075A:
    c.r[0] = 0xFFFFFFFBu; goto L_060A08AE;  // 060A075A bra 0x060A08AE ; mov #-5,r0
L_060A075E:
    c.r[1] = c.r[3];  // 060A075E mov r3,r1
    c.r[1] += 4;  // 060A0760 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A0762 mov.b @r1,r1
    c.r[2] += 72;  // 060A0764 add #72,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060A0766 extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 060A0768 mov.l r1,@r2
    c.r[1] = c.r[9];  // 060A076A mov r9,r1
    c.r[1] += 50;  // 060A076C add #50,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A076E mov.b @r1,r2
    c.r[3] = ld32(0x060A07F8u);  // 060A0770 mov.l 0x060A07F8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060A0772 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060A0774 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060A0776 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060A0778 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060A079E; } }  // 060A077A bf/s 0x060A079E ; mov r9,r1
    c.r[1] += 51;  // 060A077E add #51,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A0780 mov.b @r1,r2
    c.r[3] = ld32(0x060A07FCu);  // 060A0782 mov.l 0x060A07FC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060A0784 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060A0786 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060A0788 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060A078A cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060A079E; } }  // 060A078C bf/s 0x060A079E ; mov r9,r1
    c.r[1] += 40;  // 060A0790 add #40,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A0792 mov.w @r1,r3
    c.r[2] = ld32(0x060A0800u);  // 060A0794 mov.l 0x060A0800,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060A0796 mov.w @r2,r1
    c.t = c.r[3] == c.r[1];  // 060A0798 cmp/eq r1,r3
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060A087A; } }  // 060A079A bt/s 0x060A087A ; mov r9,r1
L_060A079E:
    c.r[1] += 50;  // 060A079E add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A07A0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A07A2 extu.b r1,r1
    c.r[0] = c.r[1];  // 060A07A4 mov r1,r0
    c.r[0] <<= 2;  // 060A07A6 shll2 r0
    c.r[1] = ld32(0x060A0804u);  // 060A07A8 mov.l 0x060A0804,r1
    c.r[7] = ld32(c.r[0] + c.r[1]);  // 060A07AA mov.l @(r0,r1),r7
    c.r[1] = ld32(0x060A0808u);  // 060A07AC mov.l 0x060A0808,r1
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 060A07AE mov.l @(r0,r1),r6
    c.r[1] = ld32(0x060A080Cu);  // 060A07B0 mov.l 0x060A080C,r1
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 060A07B2 mov.l @(r0,r1),r5
    c.r[1] = ld32(0x060A0810u);  // 060A07B4 mov.l 0x060A0810,r1
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 060A07B6 mov.l @(r0,r1),r4
    c.r[1] = ld32(0x060A0814u);  // 060A07B8 mov.l 0x060A0814,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060A07BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A07BEu) return; }  // 060A07BA jsr @r1 ; nop
    c.r[1] = c.r[9];  // 060A07BE mov r9,r1
    c.r[1] += 49;  // 060A07C0 add #49,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A07C2 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060A07C4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A07C6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060A07DE; } }  // 060A07C8 bt/s 0x060A07DE ; mov r9,r1
    c.r[1] += 59;  // 060A07CC add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A07CE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A07D0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A07D2 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060A07DE; } }  // 060A07D4 bt/s 0x060A07DE ; mov r9,r1
    c.r[1] = ld32(0x060A0818u);  // 060A07D8 mov.l 0x060A0818,r1
    st32(c.r[9] + 24, c.r[1]); goto L_060A0824;  // 060A07DA bra 0x060A0824 ; mov.l r1,@(24,r9)
L_060A07DE:
    c.r[1] += 51;  // 060A07DE add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A07E0 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060A07E2 extu.b r1,r2
    c.r[1] = 0x3u;  // 060A07E4 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 060A07E6 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_060A081C; } }  // 060A07E8 bf/s 0x060A081C ; mov r2,r0
    c.r[0] = 0xFFFFFFFAu; goto L_060A08AE;  // 060A07EC bra 0x060A08AE ; mov #-6,r0
L_060A081C:
    c.r[0] <<= 2;  // 060A081C shll2 r0
    c.r[1] = ld32(0x060A08B8u);  // 060A081E mov.l 0x060A08B8,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060A0820 mov.l @(r0,r1),r1
    st32(c.r[9] + 24, c.r[1]);  // 060A0822 mov.l r1,@(24,r9)
L_060A0824:
    c.r[1] = c.r[9];  // 060A0824 mov r9,r1
    c.r[1] += 49;  // 060A0826 add #49,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A0828 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A082A extu.b r1,r1
    c.r[0] = c.r[1];  // 060A082C mov r1,r0
    c.r[0] <<= 2;  // 060A082E shll2 r0
    c.r[0] += c.r[0];  // 060A0830 add r0,r0
    c.r[1] = ld32(0x060A08BCu);  // 060A0832 mov.l 0x060A08BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060A0834 mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 060A0836 extu.b r1,r0
    c.t = c.r[0] == 0x3u;  // 060A0838 cmp/eq #3,r0
    if (!c.t) { goto L_060A0852; }  // 060A083A bf 0x060A0852
    c.r[1] = ld32(c.r[9] + 24);  // 060A083C mov.l @(24,r9),r1
    c.r[7] = ld32(0x060A08C0u);  // 060A083E mov.l 0x060A08C0,r7
    c.r[6] = ld32(0x060A08C4u);  // 060A0840 mov.l 0x060A08C4,r6
    c.r[5] = ld32(0x060A08C8u);  // 060A0842 mov.l 0x060A08C8,r5
    c.r[4] = ld32(0x060A08CCu);  // 060A0844 mov.l 0x060A08CC,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060A0846 mov.l r1,@-r15
    c.r[1] = ld32(0x060A08D0u);  // 060A0848 mov.l 0x060A08D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060A084Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A084Eu) return; }  // 060A084A jsr @r1 ; nop
    c.r[15] += 4; goto L_060A085C;  // 060A084E bra 0x060A085C ; add #4,r15
L_060A0852:
    c.r[5] = ld32(0x060A08C8u);  // 060A0852 mov.l 0x060A08C8,r5
    c.r[4] = ld32(0x060A08CCu);  // 060A0854 mov.l 0x060A08CC,r4
    c.r[1] = ld32(0x060A08D4u);  // 060A0856 mov.l 0x060A08D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060A085Cu; c.r[6] = ld32(c.r[9] + 24); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A085Cu) return; }  // 060A0858 jsr @r1 ; mov.l @(24,r9),r6
L_060A085C:
    c.r[1] = c.r[9];  // 060A085C mov r9,r1
    c.r[1] += 50;  // 060A085E add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A0860 mov.b @r1,r1
    c.r[2] = ld32(0x060A08D8u);  // 060A0862 mov.l 0x060A08D8,r2
    st8(c.r[2], c.r[1]);  // 060A0864 mov.b r1,@r2
    c.r[1] = c.r[9];  // 060A0866 mov r9,r1
    c.r[1] += 51;  // 060A0868 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060A086A mov.b @r1,r1
    c.r[2] = ld32(0x060A08DCu);  // 060A086C mov.l 0x060A08DC,r2
    st8(c.r[2], c.r[1]);  // 060A086E mov.b r1,@r2
    c.r[1] = c.r[9];  // 060A0870 mov r9,r1
    c.r[1] += 40;  // 060A0872 add #40,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A0874 mov.w @r1,r1
    c.r[2] = ld32(0x060A08E0u);  // 060A0876 mov.l 0x060A08E0,r2
    st16(c.r[2], c.r[1]);  // 060A0878 mov.w r1,@r2
L_060A087A:
    c.r[8] = c.r[9];  // 060A087A mov r9,r8
    c.r[8] += 49;  // 060A087C add #49,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060A087E mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A0880 extu.b r1,r1
    c.r[0] = c.r[1];  // 060A0882 mov r1,r0
    c.r[0] += c.r[0];  // 060A0884 add r0,r0
    c.r[1] = ld32(0x060A08E4u);  // 060A0886 mov.l 0x060A08E4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060A0888 mov.w @(r0,r1),r5
    c.r[4] = 0x1u;  // 060A088A mov #1,r4
    c.r[0] = ld32(0x060A08E8u);  // 060A088C mov.l 0x060A08E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A0892u; st32(c.r[9] + 12, c.r[5]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0892u) return; }  // 060A088E jsr @r0 ; mov.l r5,@(12,r9)
    c.r[1] = c.r[0];  // 060A0892 mov r0,r1
    c.r[1] -= 1;  // 060A0894 add #-1,r1
    st32(c.r[9] + 16, c.r[1]);  // 060A0896 mov.l r1,@(16,r9)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060A0898 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A089A extu.b r1,r1
    c.r[0] = c.r[1];  // 060A089C mov r1,r0
    c.r[0] += c.r[0];  // 060A089E add r0,r0
    c.r[1] = ld32(0x060A08ECu);  // 060A08A0 mov.l 0x060A08EC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060A08A2 mov.w @(r0,r1),r1
    st32(c.r[9] + 20, c.r[1]);  // 060A08A4 mov.l r1,@(20,r9)
    c.r[1] = c.r[9];  // 060A08A6 mov r9,r1
    c.r[1] += 38;  // 060A08A8 add #38,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060A08AA mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060A08AC extu.w r1,r0
L_060A08AE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A08AE lds.l @r15+,pr
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A08B0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A08B2 rts ; mov.l @r15+,r8
}

void f_060A08F0(SH2Context& c) {
    ran[2596] = 1;
    c.r[4] += c.r[3];  // 060A08F0 add r3,r4
    ;  // 060A08F2 nop
L_060A08F4:
    c.r[13] = ld32(c.r[15] + 32);  // 060A08F4 mov.l @(32,r15),r13
    c.r[2] = 0x1u;  // 060A08F6 mov #1,r2
    c.t = c.r[13] == c.r[2];  // 060A08F8 cmp/eq r2,r13
    if (!c.t) { goto L_060A0914; }  // 060A08FA bf 0x060A0914
    c.r[13] = ld32(c.r[15] + 16);  // 060A08FC mov.l @(16,r15),r13
    c.r[8] = 0x20u;  // 060A08FE mov #32,r8
    c.r[2] = c.gbr;  // 060A0900 stc gbr,r2
    c.t = c.r[8] >= c.r[13];  // 060A0902 cmp/hs r13,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A0904 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A090C; } }  // 060A0906 bf/s 0x060A090C ; ldc r2,gbr
    c.r[8] = c.r[13];  // 060A090A mov r13,r8
L_060A090C:
    c.r[13] -= c.r[8];  // 060A090C sub r8,r13
    st32(c.r[15] + 16, c.r[13]);  // 060A090E mov.l r13,@(16,r15)
    goto L_060A0958;  // 060A0910 bra 0x060A0958 ; nop
L_060A0914:
    c.r[9] = ld32(c.r[15] + 16);  // 060A0914 mov.l @(16,r15),r9
    c.r[8] = 0x20u;  // 060A0916 mov #32,r8
    c.t = c.r[8] >= c.r[9];  // 060A0918 cmp/hs r9,r8
    { const bool k = !c.t; c.r[13] = c.r[0]; if (k) { goto L_060A0920; } }  // 060A091A bf/s 0x060A0920 ; mov r0,r13
    c.r[8] = c.r[9];  // 060A091E mov r9,r8
L_060A0920:
    c.r[2] = ld32(c.r[15] + 12);  // 060A0920 mov.l @(12,r15),r2
    c.r[9] -= c.r[8];  // 060A0922 sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A0924 mov.l r9,@(16,r15)
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A0926 mov.b @r2,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A0928 mov.b @(1,r2),r0
    c.r[9] = c.r[9] & 0xFFu;  // 060A092A extu.b r9,r9
    c.r[0] = c.r[0] & 0xFFu;  // 060A092C extu.b r0,r0
    c.r[0] <<= 8;  // 060A092E shll8 r0
    c.r[9] += c.r[0];  // 060A0930 add r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A0932 mov.b @(2,r2),r0
    c.r[0] = c.r[0] & 0xFFu;  // 060A0934 extu.b r0,r0
    c.r[0] <<= 16;  // 060A0936 shll16 r0
    c.r[9] += c.r[0];  // 060A0938 add r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A093A mov.b @(3,r2),r0
    c.r[0] <<= 8;  // 060A093C shll8 r0
    c.r[0] <<= 16;  // 060A093E shll16 r0
    c.r[9] += c.r[0];  // 060A0940 add r0,r9
    c.r[0] = c.r[13];  // 060A0942 mov r13,r0
    c.r[13] = c.r[8];  // 060A0944 mov r8,r13
    c.r[13] += 7;  // 060A0946 add #7,r13
    c.r[13] >>= 2;  // 060A0948 shlr2 r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 060A094A shlr r13
    c.r[2] += c.r[13];  // 060A094C add r13,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A094E mov.l r2,@(12,r15)
    c.r[13] = c.gbr;  // 060A0950 stc gbr,r13
    st32(c.r[13], c.r[9]);  // 060A0952 mov.l r9,@r13
    c.r[13] += 4;  // 060A0954 add #4,r13
    c.gbr = c.r[13];  // 060A0956 ldc r13,gbr
L_060A0958:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A0958 shlr r9
    { const bool k = !c.t; c.r[6] = ld32(c.r[10]); c.r[10] += 4; if (k) { goto L_060A0978; } }  // 060A095A bf/s 0x060A0978 ; mov.l @r10+,r6
    ;  // 060A095E nop
    c.r[5] = ld32(c.r[0] + c.r[10]);  // 060A0960 mov.l @(r0,r10),r5
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A0962 dt r8
    c.r[12] = ld32(c.r[11]); c.r[11] += 4;  // 060A0964 mov.l @r11+,r12
    c.r[5] -= c.r[6];  // 060A0966 sub r6,r5
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 060A0968 mov.l @(r0,r11),r1
    { const bool k = !c.t; c.r[1] -= c.r[12]; if (k) { SH2_POLL(c); goto L_060A0958; } }  // 060A096A bf/s 0x060A0958 ; sub r12,r1
    c.r[9] = ld32(c.r[15] + 16);  // 060A096E mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A0970 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A08F4; }  // 060A0972 bf 0x060A08F4
    { const uint32_t x = c.pr; c.r[4] -= c.r[3]; c.pc = x; return; }  // 060A0974 rts ; sub r3,r4
L_060A0978:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0978 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A097A sub r3,r4
    c.r[12] = ld32(c.r[11]); c.r[11] += 4;  // 060A097C mov.l @r11+,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A097E shar r13
    { const bool k = c.t; c.r[1] += c.r[13]; if (k) { goto L_060A09B4; } }  // 060A0980 bt/s 0x060A09B4 ; add r13,r1
L_060A0984:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0984 mov.l @r4+,r13
    c.r[12] += c.r[1];  // 060A0986 add r1,r12
    st32(c.r[0] + c.r[11], c.r[12]);  // 060A0988 mov.l r12,@(r0,r11)
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A098A shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A09EC; } }  // 060A098C bt/s 0x060A09EC ; add r13,r5
L_060A0990:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0990 mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A0992 swap.w r6,r12
    c.r[12] += c.r[5];  // 060A0994 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0996 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A0A20; } }  // 060A0998 bt/s 0x060A0A20 ; add r13,r5
L_060A099C:
    c.r[6] += c.r[5];  // 060A099C add r5,r6
    c.r[6] <<= 16;  // 060A099E shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A09A0 xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A09A2 dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A09A4 mov.l r6,@(r0,r10)
    { const bool k = !c.t; c.r[4] += c.r[3]; if (k) { SH2_POLL(c); goto L_060A0958; } }  // 060A09A6 bf/s 0x060A0958 ; add r3,r4
    c.r[13] = ld32(c.r[15] + 16);  // 060A09AA mov.l @(16,r15),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060A09AC tst r13,r13
    if (!c.t) { SH2_POLL(c); goto L_060A08F4; }  // 060A09AE bf 0x060A08F4
    { const uint32_t x = c.pr; c.r[4] -= c.r[3]; c.pc = x; return; }  // 060A09B0 rts ; sub r3,r4
L_060A09B4:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A09B4 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A09B6 tst r4,r4
    if (c.t) { goto L_060A09C4; }  // 060A09B8 bt 0x060A09C4
    c.r[4] <<= 2;  // 060A09BA shll2 r4
    c.r[4] <<= 2;  // 060A09BC shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0984;  // 060A09BE bra 0x060A0984 ; add r7,r4
L_060A09C4:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A09C4 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A09C6 shll2 r4
    c.r[4] <<= 2;  // 060A09C8 shll2 r4
    c.r[4] += c.r[7];  // 060A09CA add r7,r4
    c.r[4] += c.r[3];  // 060A09CC add r3,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A09CE shll r3
    c.r[4] += c.r[3];  // 060A09D0 add r3,r4
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060A09D2 mov.l @r4+,r2
    c.r[4] -= c.r[3];  // 060A09D4 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A09D6 shlr r3
    c.r[4] -= c.r[3];  // 060A09D8 sub r3,r4
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A09DA shar r2
    { const bool k = !c.t; c.r[1] += c.r[2]; if (k) { SH2_POLL(c); goto L_060A0984; } }  // 060A09DC bf/s 0x060A0984 ; add r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A09E0 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A09E2 shll2 r4
    c.r[4] <<= 2;  // 060A09E4 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0984;  // 060A09E6 bra 0x060A0984 ; add r7,r4
L_060A09EC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A09EC mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A09EE tst r4,r4
    if (c.t) { goto L_060A09FC; }  // 060A09F0 bt 0x060A09FC
    c.r[4] <<= 2;  // 060A09F2 shll2 r4
    c.r[4] <<= 2;  // 060A09F4 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0990;  // 060A09F6 bra 0x060A0990 ; add r7,r4
L_060A09FC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A09FC mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A09FE shll r3
    c.r[4] <<= 2;  // 060A0A00 shll2 r4
    c.r[4] <<= 2;  // 060A0A02 shll2 r4
    c.r[4] += c.r[7];  // 060A0A04 add r7,r4
    c.r[4] += c.r[3];  // 060A0A06 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0A08 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A0A0A sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A0A0C shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0A0E shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A0990; } }  // 060A0A10 bf/s 0x060A0990 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0A14 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A0A16 shll2 r4
    c.r[4] <<= 2;  // 060A0A18 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0990;  // 060A0A1A bra 0x060A0990 ; add r7,r4
L_060A0A20:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0A20 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A0A22 tst r4,r4
    if (c.t) { goto L_060A0A30; }  // 060A0A24 bt 0x060A0A30
    c.r[4] <<= 2;  // 060A0A26 shll2 r4
    c.r[4] <<= 2;  // 060A0A28 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A099C;  // 060A0A2A bra 0x060A099C ; add r7,r4
L_060A0A30:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0A30 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A0A32 shll r3
    c.r[4] <<= 2;  // 060A0A34 shll2 r4
    c.r[4] <<= 2;  // 060A0A36 shll2 r4
    c.r[4] += c.r[7];  // 060A0A38 add r7,r4
    c.r[4] += c.r[3];  // 060A0A3A add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0A3C mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A0A3E sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A0A40 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0A42 shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A099C; } }  // 060A0A44 bf/s 0x060A099C ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0A48 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A0A4A shll2 r4
    c.r[4] <<= 2;  // 060A0A4C shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A099C;  // 060A0A4E bra 0x060A099C ; add r7,r4
}

void f_060A0A54(SH2Context& c) {
    ran[2597] = 1;
L_060A0A54:
    c.r[13] = ld32(c.r[15] + 16);  // 060A0A54 mov.l @(16,r15),r13
    c.r[8] = 0x20u;  // 060A0A56 mov #32,r8
    c.r[2] = c.gbr;  // 060A0A58 stc gbr,r2
    c.t = c.r[8] >= c.r[13];  // 060A0A5A cmp/hs r13,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A0A5C mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A0A64; } }  // 060A0A5E bf/s 0x060A0A64 ; ldc r2,gbr
    c.r[8] = c.r[13];  // 060A0A62 mov r13,r8
L_060A0A64:
    c.r[13] -= c.r[8];  // 060A0A64 sub r8,r13
    st32(c.r[15] + 16, c.r[13]);  // 060A0A66 mov.l r13,@(16,r15)
L_060A0A68:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A0A68 shlr r9
    { const bool k = !c.t; c.r[6] = ld32(c.r[10]); c.r[10] += 4; if (k) { goto L_060A0A84; } }  // 060A0A6A bf/s 0x060A0A84 ; mov.l @r10+,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A0A6E dt r8
    c.r[5] = ld32(c.r[0] + c.r[10]);  // 060A0A70 mov.l @(r0,r10),r5
    { const bool k = !c.t; c.r[5] -= c.r[6]; if (k) { SH2_POLL(c); goto L_060A0A68; } }  // 060A0A72 bf/s 0x060A0A68 ; sub r6,r5
    ;  // 060A0A76 nop
    c.r[9] = ld32(c.r[15] + 16);  // 060A0A78 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A0A7A tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A0A54; }  // 060A0A7C bf 0x060A0A54
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0A7E rts ; nop
L_060A0A84:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0A84 mov.l @r4+,r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0A86 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A0AB0; } }  // 060A0A88 bt/s 0x060A0AB0 ; add r13,r5
L_060A0A8C:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0A8C mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A0A8E swap.w r6,r12
    c.r[12] += c.r[5];  // 060A0A90 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0A92 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A0AE4; } }  // 060A0A94 bt/s 0x060A0AE4 ; add r13,r5
L_060A0A98:
    c.r[6] += c.r[5];  // 060A0A98 add r5,r6
    c.r[6] <<= 16;  // 060A0A9A shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A0A9C xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A0A9E dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A0AA0 mov.l r6,@(r0,r10)
    if (!c.t) { SH2_POLL(c); goto L_060A0A68; }  // 060A0AA2 bf 0x060A0A68
    c.r[13] = ld32(c.r[15] + 16);  // 060A0AA4 mov.l @(16,r15),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060A0AA6 tst r13,r13
    if (!c.t) { SH2_POLL(c); goto L_060A0A54; }  // 060A0AA8 bf 0x060A0A54
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0AAA rts ; nop
L_060A0AB0:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0AB0 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A0AB2 tst r4,r4
    if (c.t) { goto L_060A0AC0; }  // 060A0AB4 bt 0x060A0AC0
    c.r[4] <<= 2;  // 060A0AB6 shll2 r4
    c.r[4] <<= 2;  // 060A0AB8 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0A8C;  // 060A0ABA bra 0x060A0A8C ; add r7,r4
L_060A0AC0:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0AC0 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A0AC2 shll r3
    c.r[4] <<= 2;  // 060A0AC4 shll2 r4
    c.r[4] <<= 2;  // 060A0AC6 shll2 r4
    c.r[4] += c.r[7];  // 060A0AC8 add r7,r4
    c.r[4] += c.r[3];  // 060A0ACA add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0ACC mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A0ACE sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A0AD0 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0AD2 shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A0A8C; } }  // 060A0AD4 bf/s 0x060A0A8C ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0AD8 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A0ADA shll2 r4
    c.r[4] <<= 2;  // 060A0ADC shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0A8C;  // 060A0ADE bra 0x060A0A8C ; add r7,r4
L_060A0AE4:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0AE4 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A0AE6 tst r4,r4
    if (c.t) { goto L_060A0AF4; }  // 060A0AE8 bt 0x060A0AF4
    c.r[4] <<= 2;  // 060A0AEA shll2 r4
    c.r[4] <<= 2;  // 060A0AEC shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0A98;  // 060A0AEE bra 0x060A0A98 ; add r7,r4
L_060A0AF4:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0AF4 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A0AF6 shll r3
    c.r[4] <<= 2;  // 060A0AF8 shll2 r4
    c.r[4] <<= 2;  // 060A0AFA shll2 r4
    c.r[4] += c.r[7];  // 060A0AFC add r7,r4
    c.r[4] += c.r[3];  // 060A0AFE add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A0B00 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A0B02 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A0B04 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A0B06 shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A0A98; } }  // 060A0B08 bf/s 0x060A0A98 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B0C mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A0B0E shll2 r4
    c.r[4] <<= 2;  // 060A0B10 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A0A98;  // 060A0B12 bra 0x060A0A98 ; add r7,r4
}

void f_060A0B80(SH2Context& c) {
    ran[2598] = 1;
    goto L_060A0B80;
L_060A0B18:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B18 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0B1A tst r11,r11
    if (c.t) { goto L_060A0B28; }  // 060A0B1C bt 0x060A0B28
    c.r[11] <<= 2;  // 060A0B1E shll2 r11
    c.r[11] <<= 2;  // 060A0B20 shll2 r11
    c.r[11] += c.r[12]; goto L_060A0C08;  // 060A0B22 bra 0x060A0C08 ; add r12,r11
L_060A0B28:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B28 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A0B2A mov r3,r0
    c.r[11] <<= 2;  // 060A0B2C shll2 r11
    c.r[11] <<= 2;  // 060A0B2E shll2 r11
    c.r[11] += c.r[12];  // 060A0B30 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A0B32 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A0B34 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0B36 shar r0
    c.r[5] += c.r[0];  // 060A0B38 add r0,r5
    c.r[0] <<= 2;  // 060A0B3A shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A0C08; } }  // 060A0B3C bf/s 0x060A0C08 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B40 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0B42 shll2 r11
    c.r[11] <<= 2;  // 060A0B44 shll2 r11
    c.r[11] += c.r[12]; goto L_060A0C08;  // 060A0B46 bra 0x060A0C08 ; add r12,r11
L_060A0B4C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B4C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A0B4E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0B50 tst r11,r11
    if (c.t) { goto L_060A0B5C; }  // 060A0B52 bt 0x060A0B5C
    c.r[11] <<= 2;  // 060A0B54 shll2 r11
    c.r[11] <<= 2;  // 060A0B56 shll2 r11
    c.r[11] += c.r[12]; goto L_060A0C14;  // 060A0B58 bra 0x060A0C14 ; add r12,r11
L_060A0B5C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B5C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A0B5E sub r5,r6
    c.r[11] <<= 2;  // 060A0B60 shll2 r11
    c.r[11] <<= 2;  // 060A0B62 shll2 r11
    c.r[11] += c.r[12];  // 060A0B64 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0B66 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0B68 shar r0
    c.r[5] += c.r[0];  // 060A0B6A add r0,r5
    c.r[0] <<= 2;  // 060A0B6C shll2 r0
    c.r[5] += c.r[0];  // 060A0B6E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A0C14; } }  // 060A0B70 bf/s 0x060A0C14 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0B74 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0B76 shll2 r11
    c.r[11] <<= 2;  // 060A0B78 shll2 r11
    c.r[11] += c.r[12]; goto L_060A0C14;  // 060A0B7A bra 0x060A0C14 ; add r12,r11
L_060A0B80:
    c.r[0] = ld32(c.r[15] + 32);  // 060A0B80 mov.l @(32,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A0B82 cmp/eq #1,r0
    if (!c.t) { goto L_060A0BA0; }  // 060A0B84 bf 0x060A0BA0
    c.r[0] = ld32(c.r[15] + 16);  // 060A0B86 mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A0B88 mov #32,r8
    c.r[2] = c.gbr;  // 060A0B8A stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A0B8C cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A0B8E mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A0B96; } }  // 060A0B90 bf/s 0x060A0B96 ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A0B94 mov r0,r8
L_060A0B96:
    c.r[0] -= c.r[8];  // 060A0B96 sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A0B98 mov.l r0,@(16,r15)
    goto L_060A0BE0;  // 060A0B9A bra 0x060A0BE0 ; nop
L_060A0BA0:
    c.r[9] = ld32(c.r[15] + 16);  // 060A0BA0 mov.l @(16,r15),r9
    c.r[8] = 0x20u;  // 060A0BA2 mov #32,r8
    c.t = c.r[8] >= c.r[9];  // 060A0BA4 cmp/hs r9,r8
    { const bool k = !c.t; c.r[2] = ld32(c.r[15] + 12); if (k) { goto L_060A0BAC; } }  // 060A0BA6 bf/s 0x060A0BAC ; mov.l @(12,r15),r2
    c.r[8] = c.r[9];  // 060A0BAA mov r9,r8
L_060A0BAC:
    c.r[9] -= c.r[8];  // 060A0BAC sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A0BAE mov.l r9,@(16,r15)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A0BB0 mov.b @r2,r0
    c.r[9] = c.r[0] & 0xFFu;  // 060A0BB2 extu.b r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A0BB4 mov.b @(1,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 060A0BB6 extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A0BB8 mov.b @(2,r2),r0
    c.r[6] <<= 8;  // 060A0BBA shll8 r6
    c.r[9] += c.r[6];  // 060A0BBC add r6,r9
    c.r[6] = c.r[0] & 0xFFu;  // 060A0BBE extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A0BC0 mov.b @(3,r2),r0
    c.r[6] <<= 16;  // 060A0BC2 shll16 r6
    c.r[9] += c.r[6];  // 060A0BC4 add r6,r9
    c.r[0] <<= 8;  // 060A0BC6 shll8 r0
    c.r[0] <<= 16;  // 060A0BC8 shll16 r0
    c.r[9] += c.r[0];  // 060A0BCA add r0,r9
    c.r[0] = c.r[8];  // 060A0BCC mov r8,r0
    c.r[0] += 7;  // 060A0BCE add #7,r0
    c.r[0] >>= 2;  // 060A0BD0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060A0BD2 shlr r0
    c.r[2] += c.r[0];  // 060A0BD4 add r0,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A0BD6 mov.l r2,@(12,r15)
    c.r[0] = c.gbr;  // 060A0BD8 stc gbr,r0
    st32(c.r[0], c.r[9]);  // 060A0BDA mov.l r9,@r0
    c.r[0] += 4;  // 060A0BDC add #4,r0
    c.gbr = c.r[0];  // 060A0BDE ldc r0,gbr
L_060A0BE0:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A0BE0 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A0BFC; } }  // 060A0BE2 bf/s 0x060A0BFC ; dt r8
    c.r[4] += 4;  // 060A0BE6 add #4,r4
    c.r[0] = ld32(c.r[10] + 4);  // 060A0BE8 mov.l @(4,r10),r0
    c.r[10] += 8;  // 060A0BEA add #8,r10
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A0BEC mov.l @r4+,r5
    { const bool k = !c.t; c.r[5] -= c.r[0]; if (k) { SH2_POLL(c); goto L_060A0BE0; } }  // 060A0BEE bf/s 0x060A0BE0 ; sub r0,r5
    c.r[9] = ld32(c.r[15] + 16);  // 060A0BF2 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A0BF4 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A0B80; }  // 060A0BF6 bf 0x060A0B80
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0BF8 rts ; nop
L_060A0BFC:
    c.r[0] = c.r[3];  // 060A0BFC mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A0BFE mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0C00 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A0B18; } }  // 060A0C02 bt/s 0x060A0B18 ; add r0,r5
    c.r[11] += 4;  // 060A0C06 add #4,r11
L_060A0C08:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0C08 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A0C0A mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0C0C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A0B4C; } }  // 060A0C0E bt/s 0x060A0B4C ; add r0,r5
    c.r[6] += c.r[5];  // 060A0C12 add r5,r6
L_060A0C14:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0C14 mov.l @r11+,r0
    ;  // 060A0C16 nop
    st32(c.r[4], c.r[6]);  // 060A0C18 mov.l r6,@r4
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0C1A shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A0C1C mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A0C3C; } }  // 060A0C1E bt/s 0x060A0C3C ; add r0,r5
    c.r[6] += c.r[5];  // 060A0C22 add r5,r6
L_060A0C24:
    st32(c.r[4] + 4, c.r[6]);  // 060A0C24 mov.l r6,@(4,r4)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A0C26 tst r8,r8
    { const bool k = !c.t; c.r[4] += 8; if (k) { SH2_POLL(c); goto L_060A0BE0; } }  // 060A0C28 bf/s 0x060A0BE0 ; add #8,r4
    c.r[0] = ld32(c.r[15] + 16);  // 060A0C2C mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A0C2E tst r0,r0
    if (c.t) { goto L_060A0C36; }  // 060A0C30 bt 0x060A0C36
    SH2_POLL(c); goto L_060A0B80;  // 060A0C32 bra 0x060A0B80 ; nop
L_060A0C36:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0C36 rts ; nop
L_060A0C3C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0C3C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A0C3E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0C40 tst r11,r11
    if (c.t) { goto L_060A0C4C; }  // 060A0C42 bt 0x060A0C4C
    c.r[11] <<= 2;  // 060A0C44 shll2 r11
    c.r[11] <<= 2;  // 060A0C46 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0C24;  // 060A0C48 bra 0x060A0C24 ; add r12,r11
L_060A0C4C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0C4C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A0C4E sub r5,r6
    c.r[11] <<= 2;  // 060A0C50 shll2 r11
    c.r[11] <<= 2;  // 060A0C52 shll2 r11
    c.r[11] += c.r[12];  // 060A0C54 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0C56 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0C58 shar r0
    c.r[5] += c.r[0];  // 060A0C5A add r0,r5
    c.r[0] <<= 2;  // 060A0C5C shll2 r0
    c.r[5] += c.r[0];  // 060A0C5E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A0C24; } }  // 060A0C60 bf/s 0x060A0C24 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0C64 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0C66 shll2 r11
    c.r[11] <<= 2;  // 060A0C68 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0C24;  // 060A0C6A bra 0x060A0C24 ; add r12,r11
}

void f_060A0C70(SH2Context& c) {
    ran[2599] = 1;
L_060A0C70:
    c.r[0] = ld32(c.r[15] + 16);  // 060A0C70 mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A0C72 mov #32,r8
    c.r[2] = c.gbr;  // 060A0C74 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A0C76 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A0C78 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A0C80; } }  // 060A0C7A bf/s 0x060A0C80 ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A0C7E mov r0,r8
L_060A0C80:
    c.r[0] -= c.r[8];  // 060A0C80 sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A0C82 mov.l r0,@(16,r15)
L_060A0C84:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A0C84 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A0CA0; } }  // 060A0C86 bf/s 0x060A0CA0 ; dt r8
    c.r[4] += 4;  // 060A0C8A add #4,r4
    c.r[0] = ld32(c.r[10] + 4);  // 060A0C8C mov.l @(4,r10),r0
    c.r[10] += 8;  // 060A0C8E add #8,r10
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A0C90 mov.l @r4+,r5
    { const bool k = !c.t; c.r[5] -= c.r[0]; if (k) { SH2_POLL(c); goto L_060A0C84; } }  // 060A0C92 bf/s 0x060A0C84 ; sub r0,r5
    c.r[9] = ld32(c.r[15] + 16);  // 060A0C96 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A0C98 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A0C70; }  // 060A0C9A bf 0x060A0C70
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0C9C rts ; nop
L_060A0CA0:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0CA0 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A0CA2 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0CA4 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A0CD0; } }  // 060A0CA6 bt/s 0x060A0CD0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A0CAA add r5,r6
L_060A0CAC:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0CAC mov.l @r11+,r0
    ;  // 060A0CAE nop
    st32(c.r[4], c.r[6]);  // 060A0CB0 mov.l r6,@r4
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0CB2 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A0CB4 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A0D04; } }  // 060A0CB6 bt/s 0x060A0D04 ; add r0,r5
    c.r[6] += c.r[5];  // 060A0CBA add r5,r6
L_060A0CBC:
    st32(c.r[4] + 4, c.r[6]);  // 060A0CBC mov.l r6,@(4,r4)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A0CBE tst r8,r8
    { const bool k = !c.t; c.r[4] += 8; if (k) { SH2_POLL(c); goto L_060A0C84; } }  // 060A0CC0 bf/s 0x060A0C84 ; add #8,r4
    c.r[0] = ld32(c.r[15] + 16);  // 060A0CC4 mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A0CC6 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060A0C70; }  // 060A0CC8 bf 0x060A0C70
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0CCA rts ; nop
L_060A0CD0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0CD0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A0CD2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0CD4 tst r11,r11
    if (c.t) { goto L_060A0CE0; }  // 060A0CD6 bt 0x060A0CE0
    c.r[11] <<= 2;  // 060A0CD8 shll2 r11
    c.r[11] <<= 2;  // 060A0CDA shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0CAC;  // 060A0CDC bra 0x060A0CAC ; add r12,r11
L_060A0CE0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0CE0 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A0CE2 sub r5,r6
    c.r[11] <<= 2;  // 060A0CE4 shll2 r11
    c.r[11] <<= 2;  // 060A0CE6 shll2 r11
    c.r[11] += c.r[12];  // 060A0CE8 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0CEA mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0CEC shar r0
    c.r[5] += c.r[0];  // 060A0CEE add r0,r5
    c.r[0] <<= 2;  // 060A0CF0 shll2 r0
    c.r[5] += c.r[0];  // 060A0CF2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A0CAC; } }  // 060A0CF4 bf/s 0x060A0CAC ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0CF8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0CFA shll2 r11
    c.r[11] <<= 2;  // 060A0CFC shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0CAC;  // 060A0CFE bra 0x060A0CAC ; add r12,r11
L_060A0D04:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0D04 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A0D06 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0D08 tst r11,r11
    if (c.t) { goto L_060A0D14; }  // 060A0D0A bt 0x060A0D14
    c.r[11] <<= 2;  // 060A0D0C shll2 r11
    c.r[11] <<= 2;  // 060A0D0E shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0CBC;  // 060A0D10 bra 0x060A0CBC ; add r12,r11
L_060A0D14:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0D14 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A0D16 sub r5,r6
    c.r[11] <<= 2;  // 060A0D18 shll2 r11
    c.r[11] <<= 2;  // 060A0D1A shll2 r11
    c.r[11] += c.r[12];  // 060A0D1C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0D1E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0D20 shar r0
    c.r[5] += c.r[0];  // 060A0D22 add r0,r5
    c.r[0] <<= 2;  // 060A0D24 shll2 r0
    c.r[5] += c.r[0];  // 060A0D26 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A0CBC; } }  // 060A0D28 bf/s 0x060A0CBC ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0D2C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0D2E shll2 r11
    c.r[11] <<= 2;  // 060A0D30 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0CBC;  // 060A0D32 bra 0x060A0CBC ; add r12,r11
}

void f_060A0D3C(SH2Context& c) {
    ran[2600] = 1;
    c.r[0] = 0x060A0E98u;  // 060A0D3C mova 0x060A0E98,r0
    st32(c.r[0], c.r[4]);  // 060A0D3E mov.l r4,@r0
    c.r[0] = 0x060A0EA0u;  // 060A0D40 mova 0x060A0EA0,r0
    st32(c.r[0], c.r[5]);  // 060A0D42 mov.l r5,@r0
    c.r[0] = 0x060A0EA4u;  // 060A0D44 mova 0x060A0EA4,r0
    st32(c.r[0], c.r[6]);  // 060A0D46 mov.l r6,@r0
    c.r[0] = 0x060A0E74u;  // 060A0D48 mova 0x060A0E74,r0
    st32(c.r[0], c.r[7]);  // 060A0D4A mov.l r7,@r0
    c.r[2] = ld32(0x060A0E90u);  // 060A0D4C mov.l 0x060A0E90,r2
    c.r[0] = 0x060A0E94u;  // 060A0D4E mova 0x060A0E94,r0
    st32(c.r[0], c.r[2]);  // 060A0D50 mov.l r2,@r0
    c.r[2] = ld32(0x060A0EB0u);  // 060A0D52 mov.l 0x060A0EB0,r2
    c.r[0] = 0x060A0EB4u;  // 060A0D54 mova 0x060A0EB4,r0
    st32(c.r[0], c.r[2]);  // 060A0D56 mov.l r2,@r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0D58 rts ; nop
}

void f_060A0D5C(SH2Context& c) {
    ran[2601] = 1;
    c.r[0] = 0x060A0E88u;  // 060A0D5C mova 0x060A0E88,r0
    st32(c.r[0], c.r[4]);  // 060A0D5E mov.l r4,@r0
    c.r[0] = 0x060A0E70u;  // 060A0D60 mova 0x060A0E70,r0
    st32(c.r[0], c.r[5]);  // 060A0D62 mov.l r5,@r0
    c.r[2] = c.r[7];  // 060A0D64 mov r7,r2
    c.r[2] >>= 2;  // 060A0D66 shlr2 r2
    c.r[0] = 0x060A0E7Cu;  // 060A0D68 mova 0x060A0E7C,r0
    st32(c.r[0], c.r[2]);  // 060A0D6A mov.l r2,@r0
    c.t = c.r[6] >> 31; c.r[6] <<= 1;  // 060A0D6C shll r6
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 060A0D6E shll r7
    c.r[0] = 0x060A0E84u;  // 060A0D70 mova 0x060A0E84,r0
    st32(c.r[0], c.r[6]);  // 060A0D72 mov.l r6,@r0
    c.r[0] = 0x060A0E78u;  // 060A0D74 mova 0x060A0E78,r0
    st32(c.r[0], c.r[7]);  // 060A0D76 mov.l r7,@r0
    c.r[0] = 0x060A0E80u;  // 060A0D78 mova 0x060A0E80,r0
    c.r[1] = ld32(c.r[15]);  // 060A0D7A mov.l @r15,r1
    st32(c.r[0], c.r[1]);  // 060A0D7C mov.l r1,@r0
    c.r[1] = ld32(c.r[15] + 4);  // 060A0D7E mov.l @(4,r15),r1
    c.r[0] = 0x060A0E6Cu;  // 060A0D80 mova 0x060A0E6C,r0
    st32(c.r[0], c.r[1]);  // 060A0D82 mov.l r1,@r0
    c.r[0] = 0x060A0EACu;  // 060A0D84 mova 0x060A0EAC,r0
    c.r[1] = ld32(c.r[15] + 8);  // 060A0D86 mov.l @(8,r15),r1
    st32(c.r[0], c.r[1]);  // 060A0D88 mov.l r1,@r0
    c.r[1] = ld32(c.r[15] + 12);  // 060A0D8A mov.l @(12,r15),r1
    c.r[0] = 0x060A0E9Cu;  // 060A0D8C mova 0x060A0E9C,r0
    st32(c.r[0], c.r[1]);  // 060A0D8E mov.l r1,@r0
    c.r[0] = 0x060A0EB8u;  // 060A0D90 mova 0x060A0EB8,r0
    c.r[1] = ld32(c.r[15] + 16);  // 060A0D92 mov.l @(16,r15),r1
    st32(c.r[0], c.r[1]);  // 060A0D94 mov.l r1,@r0
    c.r[1] = ld32(c.r[15] + 20);  // 060A0D96 mov.l @(20,r15),r1
    c.r[0] = 0x060A0EBCu;  // 060A0D98 mova 0x060A0EBC,r0
    st32(c.r[0], c.r[1]);  // 060A0D9A mov.l r1,@r0
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A0D9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A0D9E sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060A0DA0 stc.l gbr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A0DA2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A0DA4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A0DA6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A0DA8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A0DAA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A0DAC mov.l r14,@-r15
    c.r[15] -= 64;  // 060A0DAE add #-64,r15
    c.r[0] = ld32(0x060A0EACu);  // 060A0DB0 mov.l 0x060A0EAC,r0
    st32(c.r[15] + 12, c.r[0]);  // 060A0DB2 mov.l r0,@(12,r15)
    c.r[0] = ld32(0x060A0E6Cu);  // 060A0DB4 mov.l 0x060A0E6C,r0
    st32(c.r[15] + 24, c.r[0]);  // 060A0DB6 mov.l r0,@(24,r15)
    c.r[12] = ld32(0x060A0E8Cu);  // 060A0DB8 mov.l 0x060A0E8C,r12
    c.r[0] = ld32(0x060A0E94u);  // 060A0DBA mov.l 0x060A0E94,r0
    c.r[1] = ld32(0x060A0EB8u);  // 060A0DBC mov.l 0x060A0EB8,r1
    c.r[12] += c.r[0];  // 060A0DBE add r0,r12
    c.r[10] = ld32(0x060A0E98u);  // 060A0DC0 mov.l 0x060A0E98,r10
    c.r[8] = ld32(0x060A0E78u);  // 060A0DC2 mov.l 0x060A0E78,r8
    c.r[10] += c.r[8];  // 060A0DC4 add r8,r10
    c.r[8] >>= 2;  // 060A0DC6 shlr2 r8
    c.r[6] = ld32(0x060A0DD0u);  // 060A0DC8 mov.l 0x060A0DD0,r6
    c.t = c.r[8] & 1; c.r[8] >>= 1; goto L_060A0DD4;  // 060A0DCA bra 0x060A0DD4 ; shlr r8
L_060A0DD4:
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A0DD4 dt r8
    c.r[10] -= 4; st32(c.r[10], c.r[6]);  // 060A0DD6 mov.l r6,@-r10
    { const bool k = !c.t; c.r[10] -= 4; st32(c.r[10], c.r[6]); if (k) { SH2_POLL(c); goto L_060A0DD4; } }  // 060A0DD8 bf/s 0x060A0DD4 ; mov.l r6,@-r10
    c.r[3] = ld32(0x060A0EB4u);  // 060A0DDC mov.l 0x060A0EB4,r3
    c.r[14] = ld32(0x060A0E88u);  // 060A0DDE mov.l 0x060A0E88,r14
    c.r[13] = ld32(0x060A0E70u);  // 060A0DE0 mov.l 0x060A0E70,r13
    st32(c.r[15] + 40, c.r[13]);  // 060A0DE2 mov.l r13,@(40,r15)
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0DE4 mov.b @r14+,r11
    c.r[9] = ld32(0x060A0E80u);  // 060A0DE6 mov.l 0x060A0E80,r9
    c.r[11] <<= 2;  // 060A0DE8 shll2 r11
    c.r[11] <<= 2;  // 060A0DEA shll2 r11
    c.r[10] = ld32(0x060A0E98u);  // 060A0DEC mov.l 0x060A0E98,r10
    c.r[11] += c.r[12];  // 060A0DEE add r12,r11
L_060A0DF0:
    c.r[8] = ld32(0x060A0E7Cu);  // 060A0DF0 mov.l 0x060A0E7C,r8
    ;  // 060A0DF2 nop
    st32(c.r[15] + 16, c.r[8]);  // 060A0DF4 mov.l r8,@(16,r15)
    c.r[5] = 0x0u;  // 060A0DF6 mov #0,r5
    c.r[2] = ld32(c.r[15] + 24);  // 060A0DF8 mov.l @(24,r15),r2
    c.r[0] = c.r[9];  // 060A0DFA mov r9,r0
    c.r[0] &= c.r[2];  // 060A0DFC and r2,r0
    st32(c.r[15] + 20, c.r[9]);  // 060A0DFE mov.l r9,@(20,r15)
    c.r[2] = ld32(0x060A0E74u);  // 060A0E00 mov.l 0x060A0E74,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A0E02 shar r2
    if (c.t) { goto L_060A0E0C; }  // 060A0E04 bt 0x060A0E0C
    c.r[10] = ld32(0x060A0E98u);  // 060A0E06 mov.l 0x060A0E98,r10
    c.r[4] = c.r[10]; goto L_060A0E10;  // 060A0E08 bra 0x060A0E10 ; mov r10,r4
L_060A0E0C:
    c.r[4] = ld32(0x060A0E78u);  // 060A0E0C mov.l 0x060A0E78,r4
    c.r[4] += c.r[10];  // 060A0E0E add r10,r4
L_060A0E10:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A0E10 tst r0,r0
    ;  // 060A0E12 nop
    c.r[0] = ld32(0x060A0EA8u);  // 060A0E14 mov.l 0x060A0EA8,r0
    { const bool k = !c.t; c.gbr = c.r[0]; if (k) { goto L_060A0E34; } }  // 060A0E16 bf/s 0x060A0E34 ; ldc r0,gbr
    c.r[0] = c.r[9];  // 060A0E1A mov r9,r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060A0E1C tst #2,r0
    { const bool k = c.t; c.t = 0; if (k) { goto L_060A0E26; } }  // 060A0E1E bt/s 0x060A0E26 ; clrt
    c.r[0] = ld32(c.r[15] + 24);  // 060A0E22 mov.l @(24,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A0E24 cmp/eq #1,r0
L_060A0E26:
    c.r[2] = c.t;  // 060A0E26 movt r2
    st32(c.r[15] + 32, c.r[2]);  // 060A0E28 mov.l r2,@(32,r15)
    c.r[0] = ld32(0x060A0EA0u);  // 060A0E2A mov.l 0x060A0EA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A0E30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0E30u) return; }  // 060A0E2C jsr @r0 ; nop
    c.r[9] = ld32(c.r[15] + 20); goto L_060A0E3C;  // 060A0E30 bra 0x060A0E3C ; mov.l @(20,r15),r9
L_060A0E34:
    c.r[0] = ld32(0x060A0EA4u);  // 060A0E34 mov.l 0x060A0EA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A0E3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0E3Au) return; }  // 060A0E36 jsr @r0 ; nop
    c.r[9] = ld32(c.r[15] + 20);  // 060A0E3A mov.l @(20,r15),r9
L_060A0E3C:
    c.r[13] = ld32(c.r[15] + 40);  // 060A0E3C mov.l @(40,r15),r13
    c.r[2] = ld32(0x060A0E84u);  // 060A0E3E mov.l 0x060A0E84,r2
    c.r[13] += c.r[2];  // 060A0E40 add r2,r13
    st32(c.r[15] + 40, c.r[13]);  // 060A0E42 mov.l r13,@(40,r15)
    c.r[2] = ld32(0x060A0EBCu);  // 060A0E44 mov.l 0x060A0EBC,r2
    c.r[0] = 0x060A0EB8u;  // 060A0E46 mova 0x060A0EB8,r0
    c.r[1] = ld32(c.r[0]);  // 060A0E48 mov.l @r0,r1
    c.r[1] += c.r[2];  // 060A0E4A add r2,r1
    c.r[1] += c.r[2];  // 060A0E4C add r2,r1
    st32(c.r[0], c.r[1]);  // 060A0E4E mov.l r1,@r0
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060A0E50 dt r9
    if (!c.t) { SH2_POLL(c); goto L_060A0DF0; }  // 060A0E52 bf 0x060A0DF0
    c.r[15] += 64;  // 060A0E54 add #64,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A0E56 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A0E58 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A0E5A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A0E5C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A0E5E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A0E60 mov.l @r15+,r9
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060A0E62 ldc.l @r15+,gbr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A0E64 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A0E66 rts ; mov.l @r15+,r8
}

void f_060A0F28(SH2Context& c) {
    ran[2602] = 1;
    goto L_060A0F28;
L_060A0EC0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0EC0 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0EC2 tst r11,r11
    if (c.t) { goto L_060A0ED0; }  // 060A0EC4 bt 0x060A0ED0
    c.r[11] <<= 2;  // 060A0EC6 shll2 r11
    c.r[11] <<= 2;  // 060A0EC8 shll2 r11
    c.r[11] += c.r[12]; goto L_060A0FB8;  // 060A0ECA bra 0x060A0FB8 ; add r12,r11
L_060A0ED0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0ED0 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A0ED2 mov r3,r0
    c.r[11] <<= 2;  // 060A0ED4 shll2 r11
    c.r[11] <<= 2;  // 060A0ED6 shll2 r11
    c.r[11] += c.r[12];  // 060A0ED8 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A0EDA mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A0EDC add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0EDE shar r0
    c.r[5] += c.r[0];  // 060A0EE0 add r0,r5
    c.r[0] <<= 2;  // 060A0EE2 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A0FB8; } }  // 060A0EE4 bf/s 0x060A0FB8 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0EE8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0EEA shll2 r11
    c.r[11] <<= 2;  // 060A0EEC shll2 r11
    c.r[11] += c.r[12]; goto L_060A0FB8;  // 060A0EEE bra 0x060A0FB8 ; add r12,r11
L_060A0EF4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0EF4 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A0EF6 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0EF8 tst r11,r11
    if (c.t) { goto L_060A0F04; }  // 060A0EFA bt 0x060A0F04
    c.r[11] <<= 2;  // 060A0EFC shll2 r11
    c.r[11] <<= 2;  // 060A0EFE shll2 r11
    c.r[11] += c.r[12]; goto L_060A0FC4;  // 060A0F00 bra 0x060A0FC4 ; add r12,r11
L_060A0F04:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0F04 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A0F06 sub r5,r6
    c.r[11] <<= 2;  // 060A0F08 shll2 r11
    c.r[11] <<= 2;  // 060A0F0A shll2 r11
    c.r[11] += c.r[12];  // 060A0F0C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0F0E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0F10 shar r0
    c.r[5] += c.r[0];  // 060A0F12 add r0,r5
    c.r[0] <<= 2;  // 060A0F14 shll2 r0
    c.r[5] += c.r[0];  // 060A0F16 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A0FC4; } }  // 060A0F18 bf/s 0x060A0FC4 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0F1C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A0F1E shll2 r11
    c.r[11] <<= 2;  // 060A0F20 shll2 r11
    c.r[11] += c.r[12]; goto L_060A0FC4;  // 060A0F22 bra 0x060A0FC4 ; add r12,r11
L_060A0F28:
    c.r[0] = ld32(c.r[15] + 32);  // 060A0F28 mov.l @(32,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A0F2A cmp/eq #1,r0
    if (!c.t) { goto L_060A0F48; }  // 060A0F2C bf 0x060A0F48
    c.r[0] = ld32(c.r[15] + 16);  // 060A0F2E mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A0F30 mov #32,r8
    c.r[2] = c.gbr;  // 060A0F32 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A0F34 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A0F36 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A0F3E; } }  // 060A0F38 bf/s 0x060A0F3E ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A0F3C mov r0,r8
L_060A0F3E:
    c.r[0] -= c.r[8];  // 060A0F3E sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A0F40 mov.l r0,@(16,r15)
    goto L_060A0F88;  // 060A0F42 bra 0x060A0F88 ; nop
L_060A0F48:
    c.r[9] = ld32(c.r[15] + 16);  // 060A0F48 mov.l @(16,r15),r9
    c.r[8] = 0x20u;  // 060A0F4A mov #32,r8
    c.t = c.r[8] >= c.r[9];  // 060A0F4C cmp/hs r9,r8
    { const bool k = !c.t; c.r[2] = ld32(c.r[15] + 12); if (k) { goto L_060A0F54; } }  // 060A0F4E bf/s 0x060A0F54 ; mov.l @(12,r15),r2
    c.r[8] = c.r[9];  // 060A0F52 mov r9,r8
L_060A0F54:
    c.r[9] -= c.r[8];  // 060A0F54 sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A0F56 mov.l r9,@(16,r15)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A0F58 mov.b @r2,r0
    c.r[9] = c.r[0] & 0xFFu;  // 060A0F5A extu.b r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A0F5C mov.b @(1,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 060A0F5E extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A0F60 mov.b @(2,r2),r0
    c.r[6] <<= 8;  // 060A0F62 shll8 r6
    c.r[9] += c.r[6];  // 060A0F64 add r6,r9
    c.r[6] = c.r[0] & 0xFFu;  // 060A0F66 extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A0F68 mov.b @(3,r2),r0
    c.r[6] <<= 16;  // 060A0F6A shll16 r6
    c.r[9] += c.r[6];  // 060A0F6C add r6,r9
    c.r[0] <<= 8;  // 060A0F6E shll8 r0
    c.r[0] <<= 16;  // 060A0F70 shll16 r0
    c.r[9] += c.r[0];  // 060A0F72 add r0,r9
    c.r[0] = c.r[8];  // 060A0F74 mov r8,r0
    c.r[0] += 7;  // 060A0F76 add #7,r0
    c.r[0] >>= 2;  // 060A0F78 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060A0F7A shlr r0
    c.r[2] += c.r[0];  // 060A0F7C add r0,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A0F7E mov.l r2,@(12,r15)
    c.r[0] = c.gbr;  // 060A0F80 stc gbr,r0
    st32(c.r[0], c.r[9]);  // 060A0F82 mov.l r9,@r0
    c.r[0] += 4;  // 060A0F84 add #4,r0
    c.gbr = c.r[0];  // 060A0F86 ldc r0,gbr
L_060A0F88:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A0F88 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A0FAC; } }  // 060A0F8A bf/s 0x060A0FAC ; dt r8
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060A0F8E mov.l @r4+,r0
    c.r[10] += 4;  // 060A0F90 add #4,r10
    st32(c.r[13], c.r[0]);  // 060A0F92 mov.l r0,@r13
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A0F94 mov.l @r4+,r5
    c.r[2] = ld32(c.r[10]); c.r[10] += 4;  // 060A0F96 mov.l @r10+,r2
    st32(c.r[13] + 4, c.r[5]);  // 060A0F98 mov.l r5,@(4,r13)
    c.r[5] -= c.r[2];  // 060A0F9A sub r2,r5
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A0F88; } }  // 060A0F9C bf/s 0x060A0F88 ; add #8,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A0FA0 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A0FA2 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A0F28; }  // 060A0FA4 bf 0x060A0F28
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0FA6 rts ; nop
L_060A0FAC:
    c.r[0] = c.r[3];  // 060A0FAC mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A0FAE mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0FB0 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A0EC0; } }  // 060A0FB2 bt/s 0x060A0EC0 ; add r0,r5
    c.r[11] += 4;  // 060A0FB6 add #4,r11
L_060A0FB8:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0FB8 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A0FBA mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0FBC shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A0EF4; } }  // 060A0FBE bt/s 0x060A0EF4 ; add r0,r5
    c.r[6] += c.r[5];  // 060A0FC2 add r5,r6
L_060A0FC4:
    st32(c.r[4], c.r[6]);  // 060A0FC4 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A0FC6 mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A0FC8 mov.l @r11+,r0
    c.r[4] += 8;  // 060A0FCA add #8,r4
    st32(c.r[13], c.r[6]);  // 060A0FCC mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A0FCE shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A0FD0 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A0FF0; } }  // 060A0FD2 bt/s 0x060A0FF0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A0FD6 add r5,r6
L_060A0FD8:
    st32(c.r[7] + 4, c.r[6]);  // 060A0FD8 mov.l r6,@(4,r7)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A0FDA tst r8,r8
    st32(c.r[13] + 4, c.r[6]);  // 060A0FDC mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A0F88; } }  // 060A0FDE bf/s 0x060A0F88 ; add #8,r13
    c.r[0] = ld32(c.r[15] + 16);  // 060A0FE2 mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A0FE4 tst r0,r0
    if (c.t) { goto L_060A0FEC; }  // 060A0FE6 bt 0x060A0FEC
    SH2_POLL(c); goto L_060A0F28;  // 060A0FE8 bra 0x060A0F28 ; nop
L_060A0FEC:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A0FEC rts ; nop
L_060A0FF0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A0FF0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A0FF2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A0FF4 tst r11,r11
    if (c.t) { goto L_060A1000; }  // 060A0FF6 bt 0x060A1000
    c.r[11] <<= 2;  // 060A0FF8 shll2 r11
    c.r[11] <<= 2;  // 060A0FFA shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0FD8;  // 060A0FFC bra 0x060A0FD8 ; add r12,r11
L_060A1000:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1000 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1002 sub r5,r6
    c.r[11] <<= 2;  // 060A1004 shll2 r11
    c.r[11] <<= 2;  // 060A1006 shll2 r11
    c.r[11] += c.r[12];  // 060A1008 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A100A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A100C shar r0
    c.r[5] += c.r[0];  // 060A100E add r0,r5
    c.r[0] <<= 2;  // 060A1010 shll2 r0
    c.r[5] += c.r[0];  // 060A1012 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A0FD8; } }  // 060A1014 bf/s 0x060A0FD8 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1018 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A101A shll2 r11
    c.r[11] <<= 2;  // 060A101C shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A0FD8;  // 060A101E bra 0x060A0FD8 ; add r12,r11
}

void f_060A1024(SH2Context& c) {
    ran[2603] = 1;
L_060A1024:
    c.r[0] = ld32(c.r[15] + 16);  // 060A1024 mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A1026 mov #32,r8
    c.r[2] = c.gbr;  // 060A1028 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A102A cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A102C mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A1034; } }  // 060A102E bf/s 0x060A1034 ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A1032 mov r0,r8
L_060A1034:
    c.r[0] -= c.r[8];  // 060A1034 sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A1036 mov.l r0,@(16,r15)
L_060A1038:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A1038 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A105C; } }  // 060A103A bf/s 0x060A105C ; dt r8
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060A103E mov.l @r4+,r0
    c.r[10] += 4;  // 060A1040 add #4,r10
    st32(c.r[13], c.r[0]);  // 060A1042 mov.l r0,@r13
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A1044 mov.l @r4+,r5
    c.r[2] = ld32(c.r[10]); c.r[10] += 4;  // 060A1046 mov.l @r10+,r2
    st32(c.r[13] + 4, c.r[5]);  // 060A1048 mov.l r5,@(4,r13)
    c.r[5] -= c.r[2];  // 060A104A sub r2,r5
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A1038; } }  // 060A104C bf/s 0x060A1038 ; add #8,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A1050 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A1052 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A1024; }  // 060A1054 bf 0x060A1024
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1056 rts ; nop
L_060A105C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A105C mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A105E mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1060 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1090; } }  // 060A1062 bt/s 0x060A1090 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1066 add r5,r6
L_060A1068:
    st32(c.r[4], c.r[6]);  // 060A1068 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A106A mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A106C mov.l @r11+,r0
    c.r[4] += 8;  // 060A106E add #8,r4
    st32(c.r[13], c.r[6]);  // 060A1070 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1072 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1074 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A10C4; } }  // 060A1076 bt/s 0x060A10C4 ; add r0,r5
    c.r[6] += c.r[5];  // 060A107A add r5,r6
L_060A107C:
    st32(c.r[7] + 4, c.r[6]);  // 060A107C mov.l r6,@(4,r7)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A107E tst r8,r8
    st32(c.r[13] + 4, c.r[6]);  // 060A1080 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A1038; } }  // 060A1082 bf/s 0x060A1038 ; add #8,r13
    c.r[0] = ld32(c.r[15] + 16);  // 060A1086 mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A1088 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060A1024; }  // 060A108A bf 0x060A1024
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A108C rts ; nop
L_060A1090:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1090 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1092 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1094 tst r11,r11
    if (c.t) { goto L_060A10A0; }  // 060A1096 bt 0x060A10A0
    c.r[11] <<= 2;  // 060A1098 shll2 r11
    c.r[11] <<= 2;  // 060A109A shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1068;  // 060A109C bra 0x060A1068 ; add r12,r11
L_060A10A0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A10A0 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A10A2 sub r5,r6
    c.r[11] <<= 2;  // 060A10A4 shll2 r11
    c.r[11] <<= 2;  // 060A10A6 shll2 r11
    c.r[11] += c.r[12];  // 060A10A8 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A10AA mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A10AC shar r0
    c.r[5] += c.r[0];  // 060A10AE add r0,r5
    c.r[0] <<= 2;  // 060A10B0 shll2 r0
    c.r[5] += c.r[0];  // 060A10B2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1068; } }  // 060A10B4 bf/s 0x060A1068 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A10B8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A10BA shll2 r11
    c.r[11] <<= 2;  // 060A10BC shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1068;  // 060A10BE bra 0x060A1068 ; add r12,r11
L_060A10C4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A10C4 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A10C6 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A10C8 tst r11,r11
    if (c.t) { goto L_060A10D4; }  // 060A10CA bt 0x060A10D4
    c.r[11] <<= 2;  // 060A10CC shll2 r11
    c.r[11] <<= 2;  // 060A10CE shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A107C;  // 060A10D0 bra 0x060A107C ; add r12,r11
L_060A10D4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A10D4 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A10D6 sub r5,r6
    c.r[11] <<= 2;  // 060A10D8 shll2 r11
    c.r[11] <<= 2;  // 060A10DA shll2 r11
    c.r[11] += c.r[12];  // 060A10DC add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A10DE mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A10E0 shar r0
    c.r[5] += c.r[0];  // 060A10E2 add r0,r5
    c.r[0] <<= 2;  // 060A10E4 shll2 r0
    c.r[5] += c.r[0];  // 060A10E6 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A107C; } }  // 060A10E8 bf/s 0x060A107C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A10EC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A10EE shll2 r11
    c.r[11] <<= 2;  // 060A10F0 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A107C;  // 060A10F2 bra 0x060A107C ; add r12,r11
}

void f_060A10FC(SH2Context& c) {
    ran[2604] = 1;
    c.r[4] += c.r[3];  // 060A10FC add r3,r4
    ;  // 060A10FE nop
L_060A1100:
    c.r[13] = ld32(c.r[15] + 32);  // 060A1100 mov.l @(32,r15),r13
    c.r[2] = 0x1u;  // 060A1102 mov #1,r2
    c.t = c.r[13] == c.r[2];  // 060A1104 cmp/eq r2,r13
    if (!c.t) { goto L_060A1120; }  // 060A1106 bf 0x060A1120
    c.r[13] = ld32(c.r[15] + 16);  // 060A1108 mov.l @(16,r15),r13
    c.r[8] = 0x20u;  // 060A110A mov #32,r8
    c.r[2] = c.gbr;  // 060A110C stc gbr,r2
    c.t = c.r[8] >= c.r[13];  // 060A110E cmp/hs r13,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A1110 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A1118; } }  // 060A1112 bf/s 0x060A1118 ; ldc r2,gbr
    c.r[8] = c.r[13];  // 060A1116 mov r13,r8
L_060A1118:
    c.r[13] -= c.r[8];  // 060A1118 sub r8,r13
    st32(c.r[15] + 16, c.r[13]);  // 060A111A mov.l r13,@(16,r15)
    goto L_060A1164;  // 060A111C bra 0x060A1164 ; nop
L_060A1120:
    c.r[9] = ld32(c.r[15] + 16);  // 060A1120 mov.l @(16,r15),r9
    c.r[8] = 0x20u;  // 060A1122 mov #32,r8
    c.t = c.r[8] >= c.r[9];  // 060A1124 cmp/hs r9,r8
    { const bool k = !c.t; c.r[13] = c.r[0]; if (k) { goto L_060A112C; } }  // 060A1126 bf/s 0x060A112C ; mov r0,r13
    c.r[8] = c.r[9];  // 060A112A mov r9,r8
L_060A112C:
    c.r[2] = ld32(c.r[15] + 12);  // 060A112C mov.l @(12,r15),r2
    c.r[9] -= c.r[8];  // 060A112E sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A1130 mov.l r9,@(16,r15)
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A1132 mov.b @r2,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A1134 mov.b @(1,r2),r0
    c.r[9] = c.r[9] & 0xFFu;  // 060A1136 extu.b r9,r9
    c.r[0] = c.r[0] & 0xFFu;  // 060A1138 extu.b r0,r0
    c.r[0] <<= 8;  // 060A113A shll8 r0
    c.r[9] += c.r[0];  // 060A113C add r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A113E mov.b @(2,r2),r0
    c.r[0] = c.r[0] & 0xFFu;  // 060A1140 extu.b r0,r0
    c.r[0] <<= 16;  // 060A1142 shll16 r0
    c.r[9] += c.r[0];  // 060A1144 add r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A1146 mov.b @(3,r2),r0
    c.r[0] <<= 8;  // 060A1148 shll8 r0
    c.r[0] <<= 16;  // 060A114A shll16 r0
    c.r[9] += c.r[0];  // 060A114C add r0,r9
    c.r[0] = c.r[13];  // 060A114E mov r13,r0
    c.r[13] = c.r[8];  // 060A1150 mov r8,r13
    c.r[13] += 7;  // 060A1152 add #7,r13
    c.r[13] >>= 2;  // 060A1154 shlr2 r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 060A1156 shlr r13
    c.r[2] += c.r[13];  // 060A1158 add r13,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A115A mov.l r2,@(12,r15)
    c.r[13] = c.gbr;  // 060A115C stc gbr,r13
    st32(c.r[13], c.r[9]);  // 060A115E mov.l r9,@r13
    c.r[13] += 4;  // 060A1160 add #4,r13
    c.gbr = c.r[13];  // 060A1162 ldc r13,gbr
L_060A1164:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A1164 shlr r9
    { const bool k = !c.t; c.r[6] = ld32(c.r[10]); c.r[10] += 4; if (k) { goto L_060A118C; } }  // 060A1166 bf/s 0x060A118C ; mov.l @r10+,r6
    ;  // 060A116A nop
    c.r[5] = ld32(c.r[0] + c.r[10]);  // 060A116C mov.l @(r0,r10),r5
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A116E dt r8
    c.r[5] -= c.r[6];  // 060A1170 sub r6,r5
    c.r[12] = ld32(c.r[11] + 4);  // 060A1172 mov.l @(4,r11),r12
    c.r[11] += c.r[0];  // 060A1174 add r0,r11
    c.r[11] += 12;  // 060A1176 add #12,r11
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 060A1178 mov.l @(r0,r11),r1
    c.r[11] -= 4;  // 060A117A add #-4,r11
    c.r[11] -= c.r[0];  // 060A117C sub r0,r11
    { const bool k = !c.t; c.r[1] -= c.r[12]; if (k) { SH2_POLL(c); goto L_060A1164; } }  // 060A117E bf/s 0x060A1164 ; sub r12,r1
    c.r[9] = ld32(c.r[15] + 16);  // 060A1182 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A1184 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A1100; }  // 060A1186 bf 0x060A1100
    { const uint32_t x = c.pr; c.r[4] -= c.r[3]; c.pc = x; return; }  // 060A1188 rts ; sub r3,r4
L_060A118C:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A118C mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A118E sub r3,r4
    c.r[12] = ld32(c.r[11]); c.r[11] += 4;  // 060A1190 mov.l @r11+,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1192 shar r13
    { const bool k = c.t; c.r[1] += c.r[13]; if (k) { goto L_060A11E8; } }  // 060A1194 bt/s 0x060A11E8 ; add r13,r1
L_060A1198:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1198 mov.l @r4+,r13
    c.r[12] += c.r[1];  // 060A119A add r1,r12
    c.r[2] = c.r[11];  // 060A119C mov r11,r2
    c.r[2] += c.r[0];  // 060A119E add r0,r2
    c.r[2] += 4;  // 060A11A0 add #4,r2
    ;  // 060A11A2 nop
    st32(c.r[0] + c.r[2], c.r[12]);  // 060A11A4 mov.l r12,@(r0,r2)
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A11A6 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1220; } }  // 060A11A8 bt/s 0x060A1220 ; add r13,r5
L_060A11AC:
    c.r[4] += c.r[3];  // 060A11AC add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A11AE mov.l @r4+,r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A11B0 shar r13
    { const bool k = c.t; c.r[1] += c.r[13]; if (k) { goto L_060A1254; } }  // 060A11B2 bt/s 0x060A1254 ; add r13,r1
    c.r[4] -= c.r[3];  // 060A11B6 sub r3,r4
L_060A11B8:
    c.r[13] = ld32(c.r[11]); c.r[11] += 4;  // 060A11B8 mov.l @r11+,r13
    c.r[2] = c.r[11];  // 060A11BA mov r11,r2
    c.r[13] += c.r[1];  // 060A11BC add r1,r13
    c.r[2] += c.r[0];  // 060A11BE add r0,r2
    c.r[2] += 4;  // 060A11C0 add #4,r2
    st32(c.r[0] + c.r[2], c.r[13]);  // 060A11C2 mov.l r13,@(r0,r2)
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A11C4 mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A11C6 swap.w r6,r12
    c.r[12] += c.r[5];  // 060A11C8 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A11CA shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A128C; } }  // 060A11CC bt/s 0x060A128C ; add r13,r5
L_060A11D0:
    c.r[6] += c.r[5];  // 060A11D0 add r5,r6
    c.r[6] <<= 16;  // 060A11D2 shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A11D4 xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A11D6 dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A11D8 mov.l r6,@(r0,r10)
    { const bool k = !c.t; c.r[4] += c.r[3]; if (k) { SH2_POLL(c); goto L_060A1164; } }  // 060A11DA bf/s 0x060A1164 ; add r3,r4
    c.r[13] = ld32(c.r[15] + 16);  // 060A11DE mov.l @(16,r15),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060A11E0 tst r13,r13
    if (!c.t) { SH2_POLL(c); goto L_060A1100; }  // 060A11E2 bf 0x060A1100
    { const uint32_t x = c.pr; c.r[4] -= c.r[3]; c.pc = x; return; }  // 060A11E4 rts ; sub r3,r4
L_060A11E8:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A11E8 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A11EA tst r4,r4
    if (c.t) { goto L_060A11F8; }  // 060A11EC bt 0x060A11F8
    c.r[4] <<= 2;  // 060A11EE shll2 r4
    c.r[4] <<= 2;  // 060A11F0 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1198;  // 060A11F2 bra 0x060A1198 ; add r7,r4
L_060A11F8:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A11F8 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A11FA shll2 r4
    c.r[4] <<= 2;  // 060A11FC shll2 r4
    c.r[4] += c.r[7];  // 060A11FE add r7,r4
    c.r[4] += c.r[3];  // 060A1200 add r3,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1202 shll r3
    c.r[4] += c.r[3];  // 060A1204 add r3,r4
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060A1206 mov.l @r4+,r2
    c.r[4] -= c.r[3];  // 060A1208 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A120A shlr r3
    c.r[4] -= c.r[3];  // 060A120C sub r3,r4
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A120E shar r2
    { const bool k = !c.t; c.r[1] += c.r[2]; if (k) { SH2_POLL(c); goto L_060A1198; } }  // 060A1210 bf/s 0x060A1198 ; add r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1214 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1216 shll2 r4
    c.r[4] <<= 2;  // 060A1218 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1198;  // 060A121A bra 0x060A1198 ; add r7,r4
L_060A1220:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1220 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1222 tst r4,r4
    if (c.t) { goto L_060A1230; }  // 060A1224 bt 0x060A1230
    c.r[4] <<= 2;  // 060A1226 shll2 r4
    c.r[4] <<= 2;  // 060A1228 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A11AC;  // 060A122A bra 0x060A11AC ; add r7,r4
L_060A1230:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1230 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1232 shll r3
    c.r[4] <<= 2;  // 060A1234 shll2 r4
    c.r[4] <<= 2;  // 060A1236 shll2 r4
    c.r[4] += c.r[7];  // 060A1238 add r7,r4
    c.r[4] += c.r[3];  // 060A123A add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A123C mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A123E sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1240 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1242 shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A11AC; } }  // 060A1244 bf/s 0x060A11AC ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1248 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A124A shll2 r4
    c.r[4] <<= 2;  // 060A124C shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A11AC;  // 060A124E bra 0x060A11AC ; add r7,r4
L_060A1254:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1254 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1256 tst r4,r4
    if (c.t) { goto L_060A1264; }  // 060A1258 bt 0x060A1264
    c.r[4] <<= 2;  // 060A125A shll2 r4
    c.r[4] <<= 2;  // 060A125C shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A11B8;  // 060A125E bra 0x060A11B8 ; add r7,r4
L_060A1264:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1264 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1266 shll2 r4
    c.r[4] <<= 2;  // 060A1268 shll2 r4
    c.r[4] += c.r[7];  // 060A126A add r7,r4
    c.r[4] += c.r[3];  // 060A126C add r3,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A126E shll r3
    c.r[4] += c.r[3];  // 060A1270 add r3,r4
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060A1272 mov.l @r4+,r2
    c.r[4] -= c.r[3];  // 060A1274 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1276 shlr r3
    c.r[4] -= c.r[3];  // 060A1278 sub r3,r4
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A127A shar r2
    { const bool k = !c.t; c.r[1] += c.r[2]; if (k) { SH2_POLL(c); goto L_060A11B8; } }  // 060A127C bf/s 0x060A11B8 ; add r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1280 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1282 shll2 r4
    c.r[4] <<= 2;  // 060A1284 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A11B8;  // 060A1286 bra 0x060A11B8 ; add r7,r4
L_060A128C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A128C mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A128E tst r4,r4
    if (c.t) { goto L_060A129C; }  // 060A1290 bt 0x060A129C
    c.r[4] <<= 2;  // 060A1292 shll2 r4
    c.r[4] <<= 2;  // 060A1294 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A11D0;  // 060A1296 bra 0x060A11D0 ; add r7,r4
L_060A129C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A129C mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A129E shll r3
    c.r[4] <<= 2;  // 060A12A0 shll2 r4
    c.r[4] <<= 2;  // 060A12A2 shll2 r4
    c.r[4] += c.r[7];  // 060A12A4 add r7,r4
    c.r[4] += c.r[3];  // 060A12A6 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A12A8 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A12AA sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A12AC shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A12AE shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A11D0; } }  // 060A12B0 bf/s 0x060A11D0 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A12B4 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A12B6 shll2 r4
    c.r[4] <<= 2;  // 060A12B8 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A11D0;  // 060A12BA bra 0x060A11D0 ; add r7,r4
}

void f_060A12C0(SH2Context& c) {
    ran[2605] = 1;
L_060A12C0:
    c.r[13] = ld32(c.r[15] + 16);  // 060A12C0 mov.l @(16,r15),r13
    c.r[8] = 0x20u;  // 060A12C2 mov #32,r8
    c.r[2] = c.gbr;  // 060A12C4 stc gbr,r2
    c.t = c.r[8] >= c.r[13];  // 060A12C6 cmp/hs r13,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A12C8 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A12D0; } }  // 060A12CA bf/s 0x060A12D0 ; ldc r2,gbr
    c.r[8] = c.r[13];  // 060A12CE mov r13,r8
L_060A12D0:
    c.r[13] -= c.r[8];  // 060A12D0 sub r8,r13
    st32(c.r[15] + 16, c.r[13]);  // 060A12D2 mov.l r13,@(16,r15)
L_060A12D4:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A12D4 shlr r9
    { const bool k = !c.t; c.r[6] = ld32(c.r[10]); c.r[10] += 4; if (k) { goto L_060A12F0; } }  // 060A12D6 bf/s 0x060A12F0 ; mov.l @r10+,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A12DA dt r8
    c.r[5] = ld32(c.r[0] + c.r[10]);  // 060A12DC mov.l @(r0,r10),r5
    { const bool k = !c.t; c.r[5] -= c.r[6]; if (k) { SH2_POLL(c); goto L_060A12D4; } }  // 060A12DE bf/s 0x060A12D4 ; sub r6,r5
    ;  // 060A12E2 nop
    c.r[9] = ld32(c.r[15] + 16);  // 060A12E4 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A12E6 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A12C0; }  // 060A12E8 bf 0x060A12C0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A12EA rts ; nop
L_060A12F0:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A12F0 mov.l @r4+,r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A12F2 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A131C; } }  // 060A12F4 bt/s 0x060A131C ; add r13,r5
L_060A12F8:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A12F8 mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A12FA swap.w r6,r12
    c.r[12] += c.r[5];  // 060A12FC add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A12FE shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1350; } }  // 060A1300 bt/s 0x060A1350 ; add r13,r5
L_060A1304:
    c.r[6] += c.r[5];  // 060A1304 add r5,r6
    c.r[6] <<= 16;  // 060A1306 shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A1308 xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A130A dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A130C mov.l r6,@(r0,r10)
    if (!c.t) { SH2_POLL(c); goto L_060A12D4; }  // 060A130E bf 0x060A12D4
    c.r[13] = ld32(c.r[15] + 16);  // 060A1310 mov.l @(16,r15),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060A1312 tst r13,r13
    if (!c.t) { SH2_POLL(c); goto L_060A12C0; }  // 060A1314 bf 0x060A12C0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1316 rts ; nop
L_060A131C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A131C mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A131E tst r4,r4
    if (c.t) { goto L_060A132C; }  // 060A1320 bt 0x060A132C
    c.r[4] <<= 2;  // 060A1322 shll2 r4
    c.r[4] <<= 2;  // 060A1324 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A12F8;  // 060A1326 bra 0x060A12F8 ; add r7,r4
L_060A132C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A132C mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A132E shll r3
    c.r[4] <<= 2;  // 060A1330 shll2 r4
    c.r[4] <<= 2;  // 060A1332 shll2 r4
    c.r[4] += c.r[7];  // 060A1334 add r7,r4
    c.r[4] += c.r[3];  // 060A1336 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1338 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A133A sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A133C shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A133E shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A12F8; } }  // 060A1340 bf/s 0x060A12F8 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1344 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1346 shll2 r4
    c.r[4] <<= 2;  // 060A1348 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A12F8;  // 060A134A bra 0x060A12F8 ; add r7,r4
L_060A1350:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1350 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1352 tst r4,r4
    if (c.t) { goto L_060A1360; }  // 060A1354 bt 0x060A1360
    c.r[4] <<= 2;  // 060A1356 shll2 r4
    c.r[4] <<= 2;  // 060A1358 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1304;  // 060A135A bra 0x060A1304 ; add r7,r4
L_060A1360:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1360 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1362 shll r3
    c.r[4] <<= 2;  // 060A1364 shll2 r4
    c.r[4] <<= 2;  // 060A1366 shll2 r4
    c.r[4] += c.r[7];  // 060A1368 add r7,r4
    c.r[4] += c.r[3];  // 060A136A add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A136C mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A136E sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1370 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1372 shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1304; } }  // 060A1374 bf/s 0x060A1304 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1378 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A137A shll2 r4
    c.r[4] <<= 2;  // 060A137C shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1304;  // 060A137E bra 0x060A1304 ; add r7,r4
}

void f_060A13EC(SH2Context& c) {
    ran[2606] = 1;
    goto L_060A13EC;
L_060A1384:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1384 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1386 tst r11,r11
    if (c.t) { goto L_060A1394; }  // 060A1388 bt 0x060A1394
    c.r[11] <<= 2;  // 060A138A shll2 r11
    c.r[11] <<= 2;  // 060A138C shll2 r11
    c.r[11] += c.r[12]; goto L_060A1474;  // 060A138E bra 0x060A1474 ; add r12,r11
L_060A1394:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1394 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A1396 mov r3,r0
    c.r[11] <<= 2;  // 060A1398 shll2 r11
    c.r[11] <<= 2;  // 060A139A shll2 r11
    c.r[11] += c.r[12];  // 060A139C add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A139E mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A13A0 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A13A2 shar r0
    c.r[5] += c.r[0];  // 060A13A4 add r0,r5
    c.r[0] <<= 2;  // 060A13A6 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1474; } }  // 060A13A8 bf/s 0x060A1474 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A13AC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A13AE shll2 r11
    c.r[11] <<= 2;  // 060A13B0 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1474;  // 060A13B2 bra 0x060A1474 ; add r12,r11
L_060A13B8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A13B8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A13BA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A13BC tst r11,r11
    if (c.t) { goto L_060A13C8; }  // 060A13BE bt 0x060A13C8
    c.r[11] <<= 2;  // 060A13C0 shll2 r11
    c.r[11] <<= 2;  // 060A13C2 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1480;  // 060A13C4 bra 0x060A1480 ; add r12,r11
L_060A13C8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A13C8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A13CA sub r5,r6
    c.r[11] <<= 2;  // 060A13CC shll2 r11
    c.r[11] <<= 2;  // 060A13CE shll2 r11
    c.r[11] += c.r[12];  // 060A13D0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A13D2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A13D4 shar r0
    c.r[5] += c.r[0];  // 060A13D6 add r0,r5
    c.r[0] <<= 2;  // 060A13D8 shll2 r0
    c.r[5] += c.r[0];  // 060A13DA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A1480; } }  // 060A13DC bf/s 0x060A1480 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A13E0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A13E2 shll2 r11
    c.r[11] <<= 2;  // 060A13E4 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1480;  // 060A13E6 bra 0x060A1480 ; add r12,r11
L_060A13EC:
    c.r[0] = ld32(c.r[15] + 32);  // 060A13EC mov.l @(32,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A13EE cmp/eq #1,r0
    if (!c.t) { goto L_060A140C; }  // 060A13F0 bf 0x060A140C
    c.r[0] = ld32(c.r[15] + 16);  // 060A13F2 mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A13F4 mov #32,r8
    c.r[2] = c.gbr;  // 060A13F6 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A13F8 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A13FA mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A1402; } }  // 060A13FC bf/s 0x060A1402 ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A1400 mov r0,r8
L_060A1402:
    c.r[0] -= c.r[8];  // 060A1402 sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A1404 mov.l r0,@(16,r15)
    goto L_060A144C;  // 060A1406 bra 0x060A144C ; nop
L_060A140C:
    c.r[9] = ld32(c.r[15] + 16);  // 060A140C mov.l @(16,r15),r9
    c.r[8] = 0x20u;  // 060A140E mov #32,r8
    c.t = c.r[8] >= c.r[9];  // 060A1410 cmp/hs r9,r8
    { const bool k = !c.t; c.r[2] = ld32(c.r[15] + 12); if (k) { goto L_060A1418; } }  // 060A1412 bf/s 0x060A1418 ; mov.l @(12,r15),r2
    c.r[8] = c.r[9];  // 060A1416 mov r9,r8
L_060A1418:
    c.r[9] -= c.r[8];  // 060A1418 sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A141A mov.l r9,@(16,r15)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A141C mov.b @r2,r0
    c.r[9] = c.r[0] & 0xFFu;  // 060A141E extu.b r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A1420 mov.b @(1,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 060A1422 extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A1424 mov.b @(2,r2),r0
    c.r[6] <<= 8;  // 060A1426 shll8 r6
    c.r[9] += c.r[6];  // 060A1428 add r6,r9
    c.r[6] = c.r[0] & 0xFFu;  // 060A142A extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A142C mov.b @(3,r2),r0
    c.r[6] <<= 16;  // 060A142E shll16 r6
    c.r[9] += c.r[6];  // 060A1430 add r6,r9
    c.r[0] <<= 8;  // 060A1432 shll8 r0
    c.r[0] <<= 16;  // 060A1434 shll16 r0
    c.r[9] += c.r[0];  // 060A1436 add r0,r9
    c.r[0] = c.r[8];  // 060A1438 mov r8,r0
    c.r[0] += 7;  // 060A143A add #7,r0
    c.r[0] >>= 2;  // 060A143C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060A143E shlr r0
    c.r[2] += c.r[0];  // 060A1440 add r0,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A1442 mov.l r2,@(12,r15)
    c.r[0] = c.gbr;  // 060A1444 stc gbr,r0
    st32(c.r[0], c.r[9]);  // 060A1446 mov.l r9,@r0
    c.r[0] += 4;  // 060A1448 add #4,r0
    c.gbr = c.r[0];  // 060A144A ldc r0,gbr
L_060A144C:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A144C shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A1468; } }  // 060A144E bf/s 0x060A1468 ; dt r8
    c.r[4] += 4;  // 060A1452 add #4,r4
    c.r[0] = ld32(c.r[10] + 4);  // 060A1454 mov.l @(4,r10),r0
    c.r[10] += 8;  // 060A1456 add #8,r10
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A1458 mov.l @r4+,r5
    { const bool k = !c.t; c.r[5] -= c.r[0]; if (k) { SH2_POLL(c); goto L_060A144C; } }  // 060A145A bf/s 0x060A144C ; sub r0,r5
    c.r[9] = ld32(c.r[15] + 16);  // 060A145E mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A1460 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A13EC; }  // 060A1462 bf 0x060A13EC
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1464 rts ; nop
L_060A1468:
    c.r[0] = c.r[3];  // 060A1468 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A146A mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A146C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1384; } }  // 060A146E bt/s 0x060A1384 ; add r0,r5
    c.r[11] += 4;  // 060A1472 add #4,r11
L_060A1474:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1474 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1476 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1478 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A13B8; } }  // 060A147A bt/s 0x060A13B8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A147E add r5,r6
L_060A1480:
    c.r[0] = c.r[3];  // 060A1480 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A1482 mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1484 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A14B4; } }  // 060A1486 bt/s 0x060A14B4 ; add r0,r5
    c.r[11] += 4;  // 060A148A add #4,r11
L_060A148C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A148C mov.l @r11+,r0
    ;  // 060A148E nop
    st32(c.r[4], c.r[6]);  // 060A1490 mov.l r6,@r4
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1492 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1494 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A14E8; } }  // 060A1496 bt/s 0x060A14E8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A149A add r5,r6
L_060A149C:
    st32(c.r[4] + 4, c.r[6]);  // 060A149C mov.l r6,@(4,r4)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A149E tst r8,r8
    { const bool k = !c.t; c.r[4] += 8; if (k) { SH2_POLL(c); goto L_060A144C; } }  // 060A14A0 bf/s 0x060A144C ; add #8,r4
    c.r[0] = ld32(c.r[15] + 16);  // 060A14A4 mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A14A6 tst r0,r0
    if (c.t) { goto L_060A14AE; }  // 060A14A8 bt 0x060A14AE
    SH2_POLL(c); goto L_060A13EC;  // 060A14AA bra 0x060A13EC ; nop
L_060A14AE:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A14AE rts ; nop
L_060A14B4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A14B4 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A14B6 tst r11,r11
    if (c.t) { goto L_060A14C4; }  // 060A14B8 bt 0x060A14C4
    c.r[11] <<= 2;  // 060A14BA shll2 r11
    c.r[11] <<= 2;  // 060A14BC shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A148C;  // 060A14BE bra 0x060A148C ; add r12,r11
L_060A14C4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A14C4 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A14C6 mov r3,r0
    c.r[11] <<= 2;  // 060A14C8 shll2 r11
    c.r[11] <<= 2;  // 060A14CA shll2 r11
    c.r[11] += c.r[12];  // 060A14CC add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A14CE mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A14D0 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A14D2 shar r0
    c.r[5] += c.r[0];  // 060A14D4 add r0,r5
    c.r[0] <<= 2;  // 060A14D6 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A148C; } }  // 060A14D8 bf/s 0x060A148C ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A14DC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A14DE shll2 r11
    c.r[11] <<= 2;  // 060A14E0 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A148C;  // 060A14E2 bra 0x060A148C ; add r12,r11
L_060A14E8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A14E8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A14EA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A14EC tst r11,r11
    if (c.t) { goto L_060A14F8; }  // 060A14EE bt 0x060A14F8
    c.r[11] <<= 2;  // 060A14F0 shll2 r11
    c.r[11] <<= 2;  // 060A14F2 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A149C;  // 060A14F4 bra 0x060A149C ; add r12,r11
L_060A14F8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A14F8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A14FA sub r5,r6
    c.r[11] <<= 2;  // 060A14FC shll2 r11
    c.r[11] <<= 2;  // 060A14FE shll2 r11
    c.r[11] += c.r[12];  // 060A1500 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1502 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1504 shar r0
    c.r[5] += c.r[0];  // 060A1506 add r0,r5
    c.r[0] <<= 2;  // 060A1508 shll2 r0
    c.r[5] += c.r[0];  // 060A150A add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A149C; } }  // 060A150C bf/s 0x060A149C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1510 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1512 shll2 r11
    c.r[11] <<= 2;  // 060A1514 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A149C;  // 060A1516 bra 0x060A149C ; add r12,r11
}

void f_060A151C(SH2Context& c) {
    ran[2607] = 1;
L_060A151C:
    c.r[0] = ld32(c.r[15] + 16);  // 060A151C mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A151E mov #32,r8
    c.r[2] = c.gbr;  // 060A1520 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A1522 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A1524 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A152C; } }  // 060A1526 bf/s 0x060A152C ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A152A mov r0,r8
L_060A152C:
    c.r[0] -= c.r[8];  // 060A152C sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A152E mov.l r0,@(16,r15)
L_060A1530:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A1530 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A154C; } }  // 060A1532 bf/s 0x060A154C ; dt r8
    c.r[4] += 4;  // 060A1536 add #4,r4
    c.r[0] = ld32(c.r[10] + 4);  // 060A1538 mov.l @(4,r10),r0
    c.r[10] += 8;  // 060A153A add #8,r10
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A153C mov.l @r4+,r5
    { const bool k = !c.t; c.r[5] -= c.r[0]; if (k) { SH2_POLL(c); goto L_060A1530; } }  // 060A153E bf/s 0x060A1530 ; sub r0,r5
    c.r[9] = ld32(c.r[15] + 16);  // 060A1542 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A1544 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A151C; }  // 060A1546 bf 0x060A151C
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1548 rts ; nop
L_060A154C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A154C mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A154E mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1550 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A157C; } }  // 060A1552 bt/s 0x060A157C ; add r0,r5
    c.r[6] += c.r[5];  // 060A1556 add r5,r6
L_060A1558:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1558 mov.l @r11+,r0
    ;  // 060A155A nop
    st32(c.r[4], c.r[6]);  // 060A155C mov.l r6,@r4
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A155E shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1560 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A15B0; } }  // 060A1562 bt/s 0x060A15B0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1566 add r5,r6
L_060A1568:
    st32(c.r[4] + 4, c.r[6]);  // 060A1568 mov.l r6,@(4,r4)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A156A tst r8,r8
    { const bool k = !c.t; c.r[4] += 8; if (k) { SH2_POLL(c); goto L_060A1530; } }  // 060A156C bf/s 0x060A1530 ; add #8,r4
    c.r[0] = ld32(c.r[15] + 16);  // 060A1570 mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A1572 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060A151C; }  // 060A1574 bf 0x060A151C
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1576 rts ; nop
L_060A157C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A157C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A157E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1580 tst r11,r11
    if (c.t) { goto L_060A158C; }  // 060A1582 bt 0x060A158C
    c.r[11] <<= 2;  // 060A1584 shll2 r11
    c.r[11] <<= 2;  // 060A1586 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1558;  // 060A1588 bra 0x060A1558 ; add r12,r11
L_060A158C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A158C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A158E sub r5,r6
    c.r[11] <<= 2;  // 060A1590 shll2 r11
    c.r[11] <<= 2;  // 060A1592 shll2 r11
    c.r[11] += c.r[12];  // 060A1594 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1596 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1598 shar r0
    c.r[5] += c.r[0];  // 060A159A add r0,r5
    c.r[0] <<= 2;  // 060A159C shll2 r0
    c.r[5] += c.r[0];  // 060A159E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1558; } }  // 060A15A0 bf/s 0x060A1558 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A15A4 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A15A6 shll2 r11
    c.r[11] <<= 2;  // 060A15A8 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1558;  // 060A15AA bra 0x060A1558 ; add r12,r11
L_060A15B0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A15B0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A15B2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A15B4 tst r11,r11
    if (c.t) { goto L_060A15C0; }  // 060A15B6 bt 0x060A15C0
    c.r[11] <<= 2;  // 060A15B8 shll2 r11
    c.r[11] <<= 2;  // 060A15BA shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1568;  // 060A15BC bra 0x060A1568 ; add r12,r11
L_060A15C0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A15C0 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A15C2 sub r5,r6
    c.r[11] <<= 2;  // 060A15C4 shll2 r11
    c.r[11] <<= 2;  // 060A15C6 shll2 r11
    c.r[11] += c.r[12];  // 060A15C8 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A15CA mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A15CC shar r0
    c.r[5] += c.r[0];  // 060A15CE add r0,r5
    c.r[0] <<= 2;  // 060A15D0 shll2 r0
    c.r[5] += c.r[0];  // 060A15D2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1568; } }  // 060A15D4 bf/s 0x060A1568 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A15D8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A15DA shll2 r11
    c.r[11] <<= 2;  // 060A15DC shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1568;  // 060A15DE bra 0x060A1568 ; add r12,r11
}

void f_060A1650(SH2Context& c) {
    ran[2608] = 1;
    goto L_060A1650;
L_060A15E8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A15E8 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A15EA tst r11,r11
    if (c.t) { goto L_060A15F8; }  // 060A15EC bt 0x060A15F8
    c.r[11] <<= 2;  // 060A15EE shll2 r11
    c.r[11] <<= 2;  // 060A15F0 shll2 r11
    c.r[11] += c.r[12]; goto L_060A16E0;  // 060A15F2 bra 0x060A16E0 ; add r12,r11
L_060A15F8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A15F8 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A15FA mov r3,r0
    c.r[11] <<= 2;  // 060A15FC shll2 r11
    c.r[11] <<= 2;  // 060A15FE shll2 r11
    c.r[11] += c.r[12];  // 060A1600 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A1602 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A1604 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1606 shar r0
    c.r[5] += c.r[0];  // 060A1608 add r0,r5
    c.r[0] <<= 2;  // 060A160A shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A16E0; } }  // 060A160C bf/s 0x060A16E0 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1610 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1612 shll2 r11
    c.r[11] <<= 2;  // 060A1614 shll2 r11
    c.r[11] += c.r[12]; goto L_060A16E0;  // 060A1616 bra 0x060A16E0 ; add r12,r11
L_060A161C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A161C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A161E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1620 tst r11,r11
    if (c.t) { goto L_060A162C; }  // 060A1622 bt 0x060A162C
    c.r[11] <<= 2;  // 060A1624 shll2 r11
    c.r[11] <<= 2;  // 060A1626 shll2 r11
    c.r[11] += c.r[12]; goto L_060A16EC;  // 060A1628 bra 0x060A16EC ; add r12,r11
L_060A162C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A162C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A162E sub r5,r6
    c.r[11] <<= 2;  // 060A1630 shll2 r11
    c.r[11] <<= 2;  // 060A1632 shll2 r11
    c.r[11] += c.r[12];  // 060A1634 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1636 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1638 shar r0
    c.r[5] += c.r[0];  // 060A163A add r0,r5
    c.r[0] <<= 2;  // 060A163C shll2 r0
    c.r[5] += c.r[0];  // 060A163E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A16EC; } }  // 060A1640 bf/s 0x060A16EC ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1644 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1646 shll2 r11
    c.r[11] <<= 2;  // 060A1648 shll2 r11
    c.r[11] += c.r[12]; goto L_060A16EC;  // 060A164A bra 0x060A16EC ; add r12,r11
L_060A1650:
    c.r[0] = ld32(c.r[15] + 32);  // 060A1650 mov.l @(32,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A1652 cmp/eq #1,r0
    if (!c.t) { goto L_060A1670; }  // 060A1654 bf 0x060A1670
    c.r[0] = ld32(c.r[15] + 16);  // 060A1656 mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A1658 mov #32,r8
    c.r[2] = c.gbr;  // 060A165A stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A165C cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A165E mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A1666; } }  // 060A1660 bf/s 0x060A1666 ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A1664 mov r0,r8
L_060A1666:
    c.r[0] -= c.r[8];  // 060A1666 sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A1668 mov.l r0,@(16,r15)
    goto L_060A16B0;  // 060A166A bra 0x060A16B0 ; nop
L_060A1670:
    c.r[9] = ld32(c.r[15] + 16);  // 060A1670 mov.l @(16,r15),r9
    c.r[8] = 0x20u;  // 060A1672 mov #32,r8
    c.t = c.r[8] >= c.r[9];  // 060A1674 cmp/hs r9,r8
    { const bool k = !c.t; c.r[2] = ld32(c.r[15] + 12); if (k) { goto L_060A167C; } }  // 060A1676 bf/s 0x060A167C ; mov.l @(12,r15),r2
    c.r[8] = c.r[9];  // 060A167A mov r9,r8
L_060A167C:
    c.r[9] -= c.r[8];  // 060A167C sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A167E mov.l r9,@(16,r15)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A1680 mov.b @r2,r0
    c.r[9] = c.r[0] & 0xFFu;  // 060A1682 extu.b r0,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A1684 mov.b @(1,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 060A1686 extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A1688 mov.b @(2,r2),r0
    c.r[6] <<= 8;  // 060A168A shll8 r6
    c.r[9] += c.r[6];  // 060A168C add r6,r9
    c.r[6] = c.r[0] & 0xFFu;  // 060A168E extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A1690 mov.b @(3,r2),r0
    c.r[6] <<= 16;  // 060A1692 shll16 r6
    c.r[9] += c.r[6];  // 060A1694 add r6,r9
    c.r[0] <<= 8;  // 060A1696 shll8 r0
    c.r[0] <<= 16;  // 060A1698 shll16 r0
    c.r[9] += c.r[0];  // 060A169A add r0,r9
    c.r[0] = c.r[8];  // 060A169C mov r8,r0
    c.r[0] += 7;  // 060A169E add #7,r0
    c.r[0] >>= 2;  // 060A16A0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060A16A2 shlr r0
    c.r[2] += c.r[0];  // 060A16A4 add r0,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A16A6 mov.l r2,@(12,r15)
    c.r[0] = c.gbr;  // 060A16A8 stc gbr,r0
    st32(c.r[0], c.r[9]);  // 060A16AA mov.l r9,@r0
    c.r[0] += 4;  // 060A16AC add #4,r0
    c.gbr = c.r[0];  // 060A16AE ldc r0,gbr
L_060A16B0:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A16B0 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A16D4; } }  // 060A16B2 bf/s 0x060A16D4 ; dt r8
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060A16B6 mov.l @r4+,r0
    c.r[10] += 4;  // 060A16B8 add #4,r10
    st32(c.r[13], c.r[0]);  // 060A16BA mov.l r0,@r13
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A16BC mov.l @r4+,r5
    c.r[2] = ld32(c.r[10]); c.r[10] += 4;  // 060A16BE mov.l @r10+,r2
    st32(c.r[13] + 4, c.r[5]);  // 060A16C0 mov.l r5,@(4,r13)
    c.r[5] -= c.r[2];  // 060A16C2 sub r2,r5
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A16B0; } }  // 060A16C4 bf/s 0x060A16B0 ; add #8,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A16C8 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A16CA tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A1650; }  // 060A16CC bf 0x060A1650
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A16CE rts ; nop
L_060A16D4:
    c.r[0] = c.r[3];  // 060A16D4 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A16D6 mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A16D8 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A15E8; } }  // 060A16DA bt/s 0x060A15E8 ; add r0,r5
    c.r[11] += 4;  // 060A16DE add #4,r11
L_060A16E0:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A16E0 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A16E2 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A16E4 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A161C; } }  // 060A16E6 bt/s 0x060A161C ; add r0,r5
    c.r[6] += c.r[5];  // 060A16EA add r5,r6
L_060A16EC:
    c.r[0] = c.r[3];  // 060A16EC mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A16EE mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A16F0 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1724; } }  // 060A16F2 bt/s 0x060A1724 ; add r0,r5
    c.r[11] += 4;  // 060A16F6 add #4,r11
L_060A16F8:
    st32(c.r[4], c.r[6]);  // 060A16F8 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A16FA mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A16FC mov.l @r11+,r0
    c.r[4] += 8;  // 060A16FE add #8,r4
    st32(c.r[13], c.r[6]);  // 060A1700 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1702 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1704 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1758; } }  // 060A1706 bt/s 0x060A1758 ; add r0,r5
    c.r[6] += c.r[5];  // 060A170A add r5,r6
L_060A170C:
    st32(c.r[7] + 4, c.r[6]);  // 060A170C mov.l r6,@(4,r7)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A170E tst r8,r8
    st32(c.r[13] + 4, c.r[6]);  // 060A1710 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A16B0; } }  // 060A1712 bf/s 0x060A16B0 ; add #8,r13
    c.r[0] = ld32(c.r[15] + 16);  // 060A1716 mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A1718 tst r0,r0
    if (c.t) { goto L_060A1720; }  // 060A171A bt 0x060A1720
    SH2_POLL(c); goto L_060A1650;  // 060A171C bra 0x060A1650 ; nop
L_060A1720:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1720 rts ; nop
L_060A1724:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1724 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1726 tst r11,r11
    if (c.t) { goto L_060A1734; }  // 060A1728 bt 0x060A1734
    c.r[11] <<= 2;  // 060A172A shll2 r11
    c.r[11] <<= 2;  // 060A172C shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A16F8;  // 060A172E bra 0x060A16F8 ; add r12,r11
L_060A1734:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1734 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A1736 mov r3,r0
    c.r[11] <<= 2;  // 060A1738 shll2 r11
    c.r[11] <<= 2;  // 060A173A shll2 r11
    c.r[11] += c.r[12];  // 060A173C add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A173E mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A1740 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1742 shar r0
    c.r[5] += c.r[0];  // 060A1744 add r0,r5
    c.r[0] <<= 2;  // 060A1746 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A16F8; } }  // 060A1748 bf/s 0x060A16F8 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A174C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A174E shll2 r11
    c.r[11] <<= 2;  // 060A1750 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A16F8;  // 060A1752 bra 0x060A16F8 ; add r12,r11
L_060A1758:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1758 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A175A add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A175C tst r11,r11
    if (c.t) { goto L_060A1768; }  // 060A175E bt 0x060A1768
    c.r[11] <<= 2;  // 060A1760 shll2 r11
    c.r[11] <<= 2;  // 060A1762 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A170C;  // 060A1764 bra 0x060A170C ; add r12,r11
L_060A1768:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1768 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A176A sub r5,r6
    c.r[11] <<= 2;  // 060A176C shll2 r11
    c.r[11] <<= 2;  // 060A176E shll2 r11
    c.r[11] += c.r[12];  // 060A1770 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1772 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1774 shar r0
    c.r[5] += c.r[0];  // 060A1776 add r0,r5
    c.r[0] <<= 2;  // 060A1778 shll2 r0
    c.r[5] += c.r[0];  // 060A177A add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A170C; } }  // 060A177C bf/s 0x060A170C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1780 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1782 shll2 r11
    c.r[11] <<= 2;  // 060A1784 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A170C;  // 060A1786 bra 0x060A170C ; add r12,r11
}

void f_060A178C(SH2Context& c) {
    ran[2609] = 1;
L_060A178C:
    c.r[0] = ld32(c.r[15] + 16);  // 060A178C mov.l @(16,r15),r0
    c.r[8] = 0x20u;  // 060A178E mov #32,r8
    c.r[2] = c.gbr;  // 060A1790 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A1792 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A1794 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A179C; } }  // 060A1796 bf/s 0x060A179C ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A179A mov r0,r8
L_060A179C:
    c.r[0] -= c.r[8];  // 060A179C sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A179E mov.l r0,@(16,r15)
L_060A17A0:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A17A0 shlr r9
    { const bool k = !c.t; c.r[8] -= 1; c.t = c.r[8] == 0; if (k) { goto L_060A17C4; } }  // 060A17A2 bf/s 0x060A17C4 ; dt r8
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060A17A6 mov.l @r4+,r0
    c.r[10] += 4;  // 060A17A8 add #4,r10
    st32(c.r[13], c.r[0]);  // 060A17AA mov.l r0,@r13
    c.r[5] = ld32(c.r[4]); c.r[4] += 4;  // 060A17AC mov.l @r4+,r5
    c.r[2] = ld32(c.r[10]); c.r[10] += 4;  // 060A17AE mov.l @r10+,r2
    st32(c.r[13] + 4, c.r[5]);  // 060A17B0 mov.l r5,@(4,r13)
    c.r[5] -= c.r[2];  // 060A17B2 sub r2,r5
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A17A0; } }  // 060A17B4 bf/s 0x060A17A0 ; add #8,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A17B8 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A17BA tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A178C; }  // 060A17BC bf 0x060A178C
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A17BE rts ; nop
L_060A17C4:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A17C4 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A17C6 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A17C8 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A17F8; } }  // 060A17CA bt/s 0x060A17F8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A17CE add r5,r6
L_060A17D0:
    st32(c.r[4], c.r[6]);  // 060A17D0 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A17D2 mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A17D4 mov.l @r11+,r0
    c.r[4] += 8;  // 060A17D6 add #8,r4
    st32(c.r[13], c.r[6]);  // 060A17D8 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A17DA shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A17DC mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A182C; } }  // 060A17DE bt/s 0x060A182C ; add r0,r5
    c.r[6] += c.r[5];  // 060A17E2 add r5,r6
L_060A17E4:
    st32(c.r[7] + 4, c.r[6]);  // 060A17E4 mov.l r6,@(4,r7)
    c.t = (c.r[8] & c.r[8]) == 0;  // 060A17E6 tst r8,r8
    st32(c.r[13] + 4, c.r[6]);  // 060A17E8 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A17A0; } }  // 060A17EA bf/s 0x060A17A0 ; add #8,r13
    c.r[0] = ld32(c.r[15] + 16);  // 060A17EE mov.l @(16,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A17F0 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060A178C; }  // 060A17F2 bf 0x060A178C
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A17F4 rts ; nop
L_060A17F8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A17F8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A17FA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A17FC tst r11,r11
    if (c.t) { goto L_060A1808; }  // 060A17FE bt 0x060A1808
    c.r[11] <<= 2;  // 060A1800 shll2 r11
    c.r[11] <<= 2;  // 060A1802 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A17D0;  // 060A1804 bra 0x060A17D0 ; add r12,r11
L_060A1808:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1808 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A180A sub r5,r6
    c.r[11] <<= 2;  // 060A180C shll2 r11
    c.r[11] <<= 2;  // 060A180E shll2 r11
    c.r[11] += c.r[12];  // 060A1810 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1812 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1814 shar r0
    c.r[5] += c.r[0];  // 060A1816 add r0,r5
    c.r[0] <<= 2;  // 060A1818 shll2 r0
    c.r[5] += c.r[0];  // 060A181A add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A17D0; } }  // 060A181C bf/s 0x060A17D0 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1820 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1822 shll2 r11
    c.r[11] <<= 2;  // 060A1824 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A17D0;  // 060A1826 bra 0x060A17D0 ; add r12,r11
L_060A182C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A182C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A182E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1830 tst r11,r11
    if (c.t) { goto L_060A183C; }  // 060A1832 bt 0x060A183C
    c.r[11] <<= 2;  // 060A1834 shll2 r11
    c.r[11] <<= 2;  // 060A1836 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A17E4;  // 060A1838 bra 0x060A17E4 ; add r12,r11
L_060A183C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A183C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A183E sub r5,r6
    c.r[11] <<= 2;  // 060A1840 shll2 r11
    c.r[11] <<= 2;  // 060A1842 shll2 r11
    c.r[11] += c.r[12];  // 060A1844 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1846 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1848 shar r0
    c.r[5] += c.r[0];  // 060A184A add r0,r5
    c.r[0] <<= 2;  // 060A184C shll2 r0
    c.r[5] += c.r[0];  // 060A184E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A17E4; } }  // 060A1850 bf/s 0x060A17E4 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1854 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1856 shll2 r11
    c.r[11] <<= 2;  // 060A1858 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A17E4;  // 060A185A bra 0x060A17E4 ; add r12,r11
}

void f_060A18CC(SH2Context& c) {
    ran[2610] = 1;
    goto L_060A18CC;
L_060A1864:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1864 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1866 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1868 tst r11,r11
    if (c.t) { goto L_060A1874; }  // 060A186A bt 0x060A1874
    c.r[11] <<= 2;  // 060A186C shll2 r11
    c.r[11] <<= 2;  // 060A186E shll2 r11
    c.r[11] += c.r[12]; goto L_060A18E4;  // 060A1870 bra 0x060A18E4 ; add r12,r11
L_060A1874:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1874 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1876 sub r5,r6
    c.r[11] <<= 2;  // 060A1878 shll2 r11
    c.r[11] <<= 2;  // 060A187A shll2 r11
    c.r[11] += c.r[12];  // 060A187C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A187E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1880 shar r0
    c.r[5] += c.r[0];  // 060A1882 add r0,r5
    c.r[0] <<= 2;  // 060A1884 shll2 r0
    c.r[5] += c.r[0];  // 060A1886 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A18E4; } }  // 060A1888 bf/s 0x060A18E4 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A188C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A188E shll2 r11
    c.r[11] <<= 2;  // 060A1890 shll2 r11
    c.r[11] += c.r[12]; goto L_060A18E4;  // 060A1892 bra 0x060A18E4 ; add r12,r11
L_060A1898:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1898 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A189A tst r11,r11
    if (c.t) { goto L_060A18A8; }  // 060A189C bt 0x060A18A8
    c.r[11] <<= 2;  // 060A189E shll2 r11
    c.r[11] <<= 2;  // 060A18A0 shll2 r11
    c.r[11] += c.r[12]; goto L_060A18D8;  // 060A18A2 bra 0x060A18D8 ; add r12,r11
L_060A18A8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A18A8 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A18AA mov r3,r0
    c.r[11] <<= 2;  // 060A18AC shll2 r11
    c.r[11] <<= 2;  // 060A18AE shll2 r11
    c.r[11] += c.r[12];  // 060A18B0 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A18B2 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A18B4 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A18B6 shar r0
    c.r[5] += c.r[0];  // 060A18B8 add r0,r5
    c.r[0] <<= 2;  // 060A18BA shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A18D8; } }  // 060A18BC bf/s 0x060A18D8 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A18C0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A18C2 shll2 r11
    c.r[11] <<= 2;  // 060A18C4 shll2 r11
    c.r[11] += c.r[12]; goto L_060A18D8;  // 060A18C6 bra 0x060A18D8 ; add r12,r11
L_060A18CC:
    c.r[0] = c.r[3];  // 060A18CC mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A18CE mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A18D0 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1898; } }  // 060A18D2 bt/s 0x060A1898 ; add r0,r5
    c.r[11] += 4;  // 060A18D6 add #4,r11
L_060A18D8:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A18D8 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A18DA mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A18DC shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1864; } }  // 060A18DE bt/s 0x060A1864 ; add r0,r5
    c.r[6] += c.r[5];  // 060A18E2 add r5,r6
L_060A18E4:
    st32(c.r[4], c.r[6]);  // 060A18E4 mov.l r6,@r4
    ;  // 060A18E6 nop
    c.r[0] = ld32(0x060A1A5Cu);  // 060A18E8 mov.l 0x060A1A5C,r0
    c.r[1] = c.r[6] << 16 | c.r[6] >> 16;  // 060A18EA swap.w r6,r1
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A18EC swap.w r6,r2
    c.r[2] += c.r[0];  // 060A18EE add r0,r2
    c.r[0] = ~c.r[0];  // 060A18F0 not r0,r0
    c.r[2] &= c.r[0];  // 060A18F2 and r0,r2
    c.r[6] &= c.r[0];  // 060A18F4 and r0,r6
    c.r[6] += c.r[2];  // 060A18F6 add r2,r6
    c.r[2] = 0xFFFFFF80u;  // 060A18F8 mov #-128,r2
    c.r[2] <<= 8;  // 060A18FA shll8 r2
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A18FC shar r6
    c.r[6] |= c.r[2];  // 060A18FE or r2,r6
    c.r[6] <<= 16;  // 060A1900 shll16 r6
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A1902 xtrct r1,r6
    st32(c.r[13], c.r[6]);  // 060A1904 mov.l r6,@r13
    c.r[1] >>= 16;  // 060A1906 shlr16 r1
    ;  // 060A1908 nop
    c.r[7] = c.r[4];  // 060A190A mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A190C mov.l @r11+,r0
    c.r[4] += 8;  // 060A190E add #8,r4
    st32(c.r[13], c.r[6]);  // 060A1910 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1912 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1914 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A194C; } }  // 060A1916 bt/s 0x060A194C ; add r0,r5
    c.r[6] += c.r[5];  // 060A191A add r5,r6
L_060A191C:
    st32(c.r[7] + 4, c.r[6]);  // 060A191C mov.l r6,@(4,r7)
    ;  // 060A191E nop
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1920 swap.w r6,r2
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A1922 xtrct r1,r6
    st32(c.r[13] + 4, c.r[6]);  // 060A1924 mov.l r6,@(4,r13)
    c.r[6] = c.r[2] << 16 | c.r[2] >> 16;  // 060A1926 swap.w r2,r6
    c.r[0] = ld32(0x060A1A5Cu);  // 060A1928 mov.l 0x060A1A5C,r0
    c.r[1] = c.r[2];  // 060A192A mov r2,r1
    c.r[2] += c.r[0];  // 060A192C add r0,r2
    c.r[0] = ~c.r[0];  // 060A192E not r0,r0
    c.r[2] &= c.r[0];  // 060A1930 and r0,r2
    c.r[6] &= c.r[0];  // 060A1932 and r0,r6
    c.r[6] += c.r[2];  // 060A1934 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A1936 shar r6
    c.r[2] = 0xFFFFFF80u;  // 060A1938 mov #-128,r2
    c.r[2] <<= 8;  // 060A193A shll8 r2
    c.r[6] |= c.r[2];  // 060A193C or r2,r6
    c.r[1] = c.r[6] << 16 | c.r[1] >> 16;  // 060A193E xtrct r6,r1
    st32(c.r[13] + 8, c.r[1]);  // 060A1940 mov.l r1,@(8,r13)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1942 dt r8
    { const bool k = !c.t; c.r[13] += 12; if (k) { SH2_POLL(c); goto L_060A18CC; } }  // 060A1944 bf/s 0x060A18CC ; add #12,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1948 rts ; nop
L_060A194C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A194C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A194E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1950 tst r11,r11
    if (c.t) { goto L_060A195C; }  // 060A1952 bt 0x060A195C
    c.r[11] <<= 2;  // 060A1954 shll2 r11
    c.r[11] <<= 2;  // 060A1956 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A191C;  // 060A1958 bra 0x060A191C ; add r12,r11
L_060A195C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A195C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A195E sub r5,r6
    c.r[11] <<= 2;  // 060A1960 shll2 r11
    c.r[11] <<= 2;  // 060A1962 shll2 r11
    c.r[11] += c.r[12];  // 060A1964 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1966 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1968 shar r0
    c.r[5] += c.r[0];  // 060A196A add r0,r5
    c.r[0] <<= 2;  // 060A196C shll2 r0
    c.r[5] += c.r[0];  // 060A196E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A191C; } }  // 060A1970 bf/s 0x060A191C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1974 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1976 shll2 r11
    c.r[11] <<= 2;  // 060A1978 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A191C;  // 060A197A bra 0x060A191C ; add r12,r11
}

void f_060A1980(SH2Context& c) {
    ran[2611] = 1;
L_060A1980:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1980 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1982 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1984 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A19F4; } }  // 060A1986 bt/s 0x060A19F4 ; add r0,r5
    c.r[6] += c.r[5];  // 060A198A add r5,r6
L_060A198C:
    st32(c.r[4], c.r[6]);  // 060A198C mov.l r6,@r4
    ;  // 060A198E nop
    c.r[0] = ld32(0x060A1A5Cu);  // 060A1990 mov.l 0x060A1A5C,r0
    c.r[1] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1992 swap.w r6,r1
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1994 swap.w r6,r2
    c.r[2] += c.r[0];  // 060A1996 add r0,r2
    c.r[0] = ~c.r[0];  // 060A1998 not r0,r0
    c.r[2] &= c.r[0];  // 060A199A and r0,r2
    c.r[6] &= c.r[0];  // 060A199C and r0,r6
    c.r[6] += c.r[2];  // 060A199E add r2,r6
    c.r[2] = 0xFFFFFF80u;  // 060A19A0 mov #-128,r2
    c.r[2] <<= 8;  // 060A19A2 shll8 r2
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A19A4 shar r6
    c.r[6] |= c.r[2];  // 060A19A6 or r2,r6
    c.r[6] <<= 16;  // 060A19A8 shll16 r6
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A19AA xtrct r1,r6
    st32(c.r[13], c.r[6]);  // 060A19AC mov.l r6,@r13
    c.r[1] >>= 16;  // 060A19AE shlr16 r1
    ;  // 060A19B0 nop
    c.r[7] = c.r[4];  // 060A19B2 mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A19B4 mov.l @r11+,r0
    c.r[4] += 8;  // 060A19B6 add #8,r4
    st32(c.r[13], c.r[6]);  // 060A19B8 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A19BA shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A19BC mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1A28; } }  // 060A19BE bt/s 0x060A1A28 ; add r0,r5
    c.r[6] += c.r[5];  // 060A19C2 add r5,r6
L_060A19C4:
    st32(c.r[7] + 4, c.r[6]);  // 060A19C4 mov.l r6,@(4,r7)
    ;  // 060A19C6 nop
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A19C8 swap.w r6,r2
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A19CA xtrct r1,r6
    st32(c.r[13] + 4, c.r[6]);  // 060A19CC mov.l r6,@(4,r13)
    c.r[6] = c.r[2] << 16 | c.r[2] >> 16;  // 060A19CE swap.w r2,r6
    c.r[0] = ld32(0x060A1A5Cu);  // 060A19D0 mov.l 0x060A1A5C,r0
    c.r[1] = c.r[2];  // 060A19D2 mov r2,r1
    c.r[2] += c.r[0];  // 060A19D4 add r0,r2
    c.r[0] = ~c.r[0];  // 060A19D6 not r0,r0
    c.r[2] &= c.r[0];  // 060A19D8 and r0,r2
    c.r[6] &= c.r[0];  // 060A19DA and r0,r6
    c.r[6] += c.r[2];  // 060A19DC add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A19DE shar r6
    c.r[2] = 0xFFFFFF80u;  // 060A19E0 mov #-128,r2
    c.r[2] <<= 8;  // 060A19E2 shll8 r2
    c.r[6] |= c.r[2];  // 060A19E4 or r2,r6
    c.r[1] = c.r[6] << 16 | c.r[1] >> 16;  // 060A19E6 xtrct r6,r1
    st32(c.r[13] + 8, c.r[1]);  // 060A19E8 mov.l r1,@(8,r13)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A19EA dt r8
    { const bool k = !c.t; c.r[13] += 12; if (k) { SH2_POLL(c); goto L_060A1980; } }  // 060A19EC bf/s 0x060A1980 ; add #12,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A19F0 rts ; nop
L_060A19F4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A19F4 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A19F6 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A19F8 tst r11,r11
    if (c.t) { goto L_060A1A04; }  // 060A19FA bt 0x060A1A04
    c.r[11] <<= 2;  // 060A19FC shll2 r11
    c.r[11] <<= 2;  // 060A19FE shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A198C;  // 060A1A00 bra 0x060A198C ; add r12,r11
L_060A1A04:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A04 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1A06 sub r5,r6
    c.r[11] <<= 2;  // 060A1A08 shll2 r11
    c.r[11] <<= 2;  // 060A1A0A shll2 r11
    c.r[11] += c.r[12];  // 060A1A0C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1A0E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1A10 shar r0
    c.r[5] += c.r[0];  // 060A1A12 add r0,r5
    c.r[0] <<= 2;  // 060A1A14 shll2 r0
    c.r[5] += c.r[0];  // 060A1A16 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A198C; } }  // 060A1A18 bf/s 0x060A198C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A1C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1A1E shll2 r11
    c.r[11] <<= 2;  // 060A1A20 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A198C;  // 060A1A22 bra 0x060A198C ; add r12,r11
L_060A1A28:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A28 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1A2A add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1A2C tst r11,r11
    if (c.t) { goto L_060A1A38; }  // 060A1A2E bt 0x060A1A38
    c.r[11] <<= 2;  // 060A1A30 shll2 r11
    c.r[11] <<= 2;  // 060A1A32 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A19C4;  // 060A1A34 bra 0x060A19C4 ; add r12,r11
L_060A1A38:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A38 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1A3A sub r5,r6
    c.r[11] <<= 2;  // 060A1A3C shll2 r11
    c.r[11] <<= 2;  // 060A1A3E shll2 r11
    c.r[11] += c.r[12];  // 060A1A40 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1A42 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1A44 shar r0
    c.r[5] += c.r[0];  // 060A1A46 add r0,r5
    c.r[0] <<= 2;  // 060A1A48 shll2 r0
    c.r[5] += c.r[0];  // 060A1A4A add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A19C4; } }  // 060A1A4C bf/s 0x060A19C4 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A50 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1A52 shll2 r11
    c.r[11] <<= 2;  // 060A1A54 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A19C4;  // 060A1A56 bra 0x060A19C4 ; add r12,r11
}

void f_060A1ACC(SH2Context& c) {
    ran[2612] = 1;
    goto L_060A1ACC;
L_060A1A60:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A60 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1A62 tst r4,r4
    if (c.t) { goto L_060A1A70; }  // 060A1A64 bt 0x060A1A70
    c.r[4] <<= 2;  // 060A1A66 shll2 r4
    c.r[4] <<= 2;  // 060A1A68 shll2 r4
    c.r[4] += c.r[7]; goto L_060A1AEC;  // 060A1A6A bra 0x060A1AEC ; add r7,r4
L_060A1A70:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A70 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1A72 shll r3
    c.r[4] <<= 2;  // 060A1A74 shll2 r4
    c.r[4] <<= 2;  // 060A1A76 shll2 r4
    c.r[4] += c.r[7];  // 060A1A78 add r7,r4
    c.r[4] += c.r[3];  // 060A1A7A add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1A7C mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1A7E sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1A80 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1A82 shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1AEC; } }  // 060A1A84 bf/s 0x060A1AEC ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A88 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1A8A shll2 r4
    c.r[4] <<= 2;  // 060A1A8C shll2 r4
    c.r[4] += c.r[7]; goto L_060A1AEC;  // 060A1A8E bra 0x060A1AEC ; add r7,r4
L_060A1A94:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1A94 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1A96 tst r4,r4
    if (c.t) { goto L_060A1AA4; }  // 060A1A98 bt 0x060A1AA4
    c.r[4] <<= 2;  // 060A1A9A shll2 r4
    c.r[4] <<= 2;  // 060A1A9C shll2 r4
    c.r[4] += c.r[7]; goto L_060A1ADC;  // 060A1A9E bra 0x060A1ADC ; add r7,r4
L_060A1AA4:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1AA4 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1AA6 shll2 r4
    c.r[4] <<= 2;  // 060A1AA8 shll2 r4
    c.r[4] += c.r[7];  // 060A1AAA add r7,r4
    c.r[4] += c.r[3];  // 060A1AAC add r3,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1AAE shll r3
    c.r[4] += c.r[3];  // 060A1AB0 add r3,r4
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060A1AB2 mov.l @r4+,r2
    c.r[4] -= c.r[3];  // 060A1AB4 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1AB6 shlr r3
    c.r[4] -= c.r[3];  // 060A1AB8 sub r3,r4
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A1ABA shar r2
    { const bool k = !c.t; c.r[1] += c.r[2]; if (k) { goto L_060A1ADC; } }  // 060A1ABC bf/s 0x060A1ADC ; add r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1AC0 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1AC2 shll2 r4
    c.r[4] <<= 2;  // 060A1AC4 shll2 r4
    c.r[4] += c.r[7]; goto L_060A1ADC;  // 060A1AC6 bra 0x060A1ADC ; add r7,r4
L_060A1ACC:
    c.r[4] += c.r[3];  // 060A1ACC add r3,r4
    ;  // 060A1ACE nop
L_060A1AD0:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1AD0 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1AD2 sub r3,r4
    c.r[12] = ld32(c.r[11]); c.r[11] += 4;  // 060A1AD4 mov.l @r11+,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1AD6 shar r13
    { const bool k = c.t; c.r[1] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1A94; } }  // 060A1AD8 bt/s 0x060A1A94 ; add r13,r1
L_060A1ADC:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1ADC mov.l @r4+,r13
    c.r[12] += c.r[1];  // 060A1ADE add r1,r12
    st32(c.r[0] + c.r[11], c.r[12]);  // 060A1AE0 mov.l r12,@(r0,r11)
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1AE2 shar r13
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1AE4 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1A60; } }  // 060A1AE6 bt/s 0x060A1A60 ; add r13,r5
    ;  // 060A1AEA nop
L_060A1AEC:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1AEC mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1AEE swap.w r6,r12
    c.r[12] += c.r[5];  // 060A1AF0 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1AF2 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1B0C; } }  // 060A1AF4 bt/s 0x060A1B0C ; add r13,r5
L_060A1AF8:
    c.r[6] += c.r[5];  // 060A1AF8 add r5,r6
    c.r[6] <<= 16;  // 060A1AFA shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A1AFC xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1AFE dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A1B00 mov.l r6,@(r0,r10)
    { const bool k = !c.t; c.r[4] += c.r[3]; if (k) { SH2_POLL(c); goto L_060A1AD0; } }  // 060A1B02 bf/s 0x060A1AD0 ; add r3,r4
    { const uint32_t x = c.pr; c.r[4] -= c.r[3]; c.pc = x; return; }  // 060A1B06 rts ; sub r3,r4
L_060A1B0C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B0C mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1B0E tst r4,r4
    if (c.t) { goto L_060A1B1C; }  // 060A1B10 bt 0x060A1B1C
    c.r[4] <<= 2;  // 060A1B12 shll2 r4
    c.r[4] <<= 2;  // 060A1B14 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1AF8;  // 060A1B16 bra 0x060A1AF8 ; add r7,r4
L_060A1B1C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B1C mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1B1E shll r3
    c.r[4] <<= 2;  // 060A1B20 shll2 r4
    c.r[4] <<= 2;  // 060A1B22 shll2 r4
    c.r[4] += c.r[7];  // 060A1B24 add r7,r4
    c.r[4] += c.r[3];  // 060A1B26 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1B28 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1B2A sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1B2C shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1B2E shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1AF8; } }  // 060A1B30 bf/s 0x060A1AF8 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B34 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1B36 shll2 r4
    c.r[4] <<= 2;  // 060A1B38 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1AF8;  // 060A1B3A bra 0x060A1AF8 ; add r7,r4
}

void f_060A1B40(SH2Context& c) {
    ran[2613] = 1;
L_060A1B40:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1B40 mov.l @r4+,r13
    ;  // 060A1B42 nop
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1B44 mov.l @r10+,r6
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1B46 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1B68; } }  // 060A1B48 bt/s 0x060A1B68 ; add r13,r5
L_060A1B4C:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1B4C mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1B4E swap.w r6,r12
    c.r[12] += c.r[5];  // 060A1B50 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1B52 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1B9C; } }  // 060A1B54 bt/s 0x060A1B9C ; add r13,r5
L_060A1B58:
    c.r[6] += c.r[5];  // 060A1B58 add r5,r6
    c.r[6] <<= 16;  // 060A1B5A shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A1B5C xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1B5E dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A1B60 mov.l r6,@(r0,r10)
    if (!c.t) { SH2_POLL(c); goto L_060A1B40; }  // 060A1B62 bf 0x060A1B40
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1B64 rts ; nop
L_060A1B68:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B68 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1B6A tst r4,r4
    if (c.t) { goto L_060A1B78; }  // 060A1B6C bt 0x060A1B78
    c.r[4] <<= 2;  // 060A1B6E shll2 r4
    c.r[4] <<= 2;  // 060A1B70 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1B4C;  // 060A1B72 bra 0x060A1B4C ; add r7,r4
L_060A1B78:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B78 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1B7A shll r3
    c.r[4] <<= 2;  // 060A1B7C shll2 r4
    c.r[4] <<= 2;  // 060A1B7E shll2 r4
    c.r[4] += c.r[7];  // 060A1B80 add r7,r4
    c.r[4] += c.r[3];  // 060A1B82 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1B84 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1B86 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1B88 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1B8A shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1B4C; } }  // 060A1B8C bf/s 0x060A1B4C ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B90 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1B92 shll2 r4
    c.r[4] <<= 2;  // 060A1B94 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1B4C;  // 060A1B96 bra 0x060A1B4C ; add r7,r4
L_060A1B9C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1B9C mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1B9E tst r4,r4
    if (c.t) { goto L_060A1BAC; }  // 060A1BA0 bt 0x060A1BAC
    c.r[4] <<= 2;  // 060A1BA2 shll2 r4
    c.r[4] <<= 2;  // 060A1BA4 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1B58;  // 060A1BA6 bra 0x060A1B58 ; add r7,r4
L_060A1BAC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1BAC mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1BAE shll r3
    c.r[4] <<= 2;  // 060A1BB0 shll2 r4
    c.r[4] <<= 2;  // 060A1BB2 shll2 r4
    c.r[4] += c.r[7];  // 060A1BB4 add r7,r4
    c.r[4] += c.r[3];  // 060A1BB6 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1BB8 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1BBA sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1BBC shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1BBE shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1B58; } }  // 060A1BC0 bf/s 0x060A1B58 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1BC4 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1BC6 shll2 r4
    c.r[4] <<= 2;  // 060A1BC8 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1B58;  // 060A1BCA bra 0x060A1B58 ; add r7,r4
}

void f_060A1C38(SH2Context& c) {
    ran[2614] = 1;
    goto L_060A1C38;
L_060A1BD0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1BD0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1BD2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1BD4 tst r11,r11
    if (c.t) { goto L_060A1BE0; }  // 060A1BD6 bt 0x060A1BE0
    c.r[11] <<= 2;  // 060A1BD8 shll2 r11
    c.r[11] <<= 2;  // 060A1BDA shll2 r11
    c.r[11] += c.r[12]; goto L_060A1C50;  // 060A1BDC bra 0x060A1C50 ; add r12,r11
L_060A1BE0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1BE0 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1BE2 sub r5,r6
    c.r[11] <<= 2;  // 060A1BE4 shll2 r11
    c.r[11] <<= 2;  // 060A1BE6 shll2 r11
    c.r[11] += c.r[12];  // 060A1BE8 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1BEA mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1BEC shar r0
    c.r[5] += c.r[0];  // 060A1BEE add r0,r5
    c.r[0] <<= 2;  // 060A1BF0 shll2 r0
    c.r[5] += c.r[0];  // 060A1BF2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A1C50; } }  // 060A1BF4 bf/s 0x060A1C50 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1BF8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1BFA shll2 r11
    c.r[11] <<= 2;  // 060A1BFC shll2 r11
    c.r[11] += c.r[12]; goto L_060A1C50;  // 060A1BFE bra 0x060A1C50 ; add r12,r11
L_060A1C04:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1C04 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1C06 tst r11,r11
    if (c.t) { goto L_060A1C14; }  // 060A1C08 bt 0x060A1C14
    c.r[11] <<= 2;  // 060A1C0A shll2 r11
    c.r[11] <<= 2;  // 060A1C0C shll2 r11
    c.r[11] += c.r[12]; goto L_060A1C44;  // 060A1C0E bra 0x060A1C44 ; add r12,r11
L_060A1C14:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1C14 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A1C16 mov r3,r0
    c.r[11] <<= 2;  // 060A1C18 shll2 r11
    c.r[11] <<= 2;  // 060A1C1A shll2 r11
    c.r[11] += c.r[12];  // 060A1C1C add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A1C1E mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A1C20 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1C22 shar r0
    c.r[5] += c.r[0];  // 060A1C24 add r0,r5
    c.r[0] <<= 2;  // 060A1C26 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1C44; } }  // 060A1C28 bf/s 0x060A1C44 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1C2C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1C2E shll2 r11
    c.r[11] <<= 2;  // 060A1C30 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1C44;  // 060A1C32 bra 0x060A1C44 ; add r12,r11
L_060A1C38:
    c.r[0] = c.r[3];  // 060A1C38 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A1C3A mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1C3C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1C04; } }  // 060A1C3E bt/s 0x060A1C04 ; add r0,r5
    c.r[11] += 4;  // 060A1C42 add #4,r11
L_060A1C44:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1C44 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1C46 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1C48 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1BD0; } }  // 060A1C4A bt/s 0x060A1BD0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1C4E add r5,r6
L_060A1C50:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1C50 mov.l @r11+,r0
    ;  // 060A1C52 nop
    st32(c.r[4], c.r[6]);  // 060A1C54 mov.l r6,@r4
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1C56 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1C58 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1C6C; } }  // 060A1C5A bt/s 0x060A1C6C ; add r0,r5
    c.r[6] += c.r[5];  // 060A1C5E add r5,r6
L_060A1C60:
    st32(c.r[4] + 4, c.r[6]);  // 060A1C60 mov.l r6,@(4,r4)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1C62 dt r8
    { const bool k = !c.t; c.r[4] += 8; if (k) { SH2_POLL(c); goto L_060A1C38; } }  // 060A1C64 bf/s 0x060A1C38 ; add #8,r4
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1C68 rts ; nop
L_060A1C6C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1C6C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1C6E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1C70 tst r11,r11
    if (c.t) { goto L_060A1C7C; }  // 060A1C72 bt 0x060A1C7C
    c.r[11] <<= 2;  // 060A1C74 shll2 r11
    c.r[11] <<= 2;  // 060A1C76 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1C60;  // 060A1C78 bra 0x060A1C60 ; add r12,r11
L_060A1C7C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1C7C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1C7E sub r5,r6
    c.r[11] <<= 2;  // 060A1C80 shll2 r11
    c.r[11] <<= 2;  // 060A1C82 shll2 r11
    c.r[11] += c.r[12];  // 060A1C84 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1C86 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1C88 shar r0
    c.r[5] += c.r[0];  // 060A1C8A add r0,r5
    c.r[0] <<= 2;  // 060A1C8C shll2 r0
    c.r[5] += c.r[0];  // 060A1C8E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1C60; } }  // 060A1C90 bf/s 0x060A1C60 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1C94 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1C96 shll2 r11
    c.r[11] <<= 2;  // 060A1C98 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1C60;  // 060A1C9A bra 0x060A1C60 ; add r12,r11
}

void f_060A1CA0(SH2Context& c) {
    ran[2615] = 1;
L_060A1CA0:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1CA0 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1CA2 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1CA4 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1CC8; } }  // 060A1CA6 bt/s 0x060A1CC8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1CAA add r5,r6
L_060A1CAC:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1CAC mov.l @r11+,r0
    ;  // 060A1CAE nop
    st32(c.r[4], c.r[6]);  // 060A1CB0 mov.l r6,@r4
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1CB2 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1CB4 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1CFC; } }  // 060A1CB6 bt/s 0x060A1CFC ; add r0,r5
    c.r[6] += c.r[5];  // 060A1CBA add r5,r6
L_060A1CBC:
    st32(c.r[4] + 4, c.r[6]);  // 060A1CBC mov.l r6,@(4,r4)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1CBE dt r8
    { const bool k = !c.t; c.r[4] += 8; if (k) { SH2_POLL(c); goto L_060A1CA0; } }  // 060A1CC0 bf/s 0x060A1CA0 ; add #8,r4
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1CC4 rts ; nop
L_060A1CC8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1CC8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1CCA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1CCC tst r11,r11
    if (c.t) { goto L_060A1CD8; }  // 060A1CCE bt 0x060A1CD8
    c.r[11] <<= 2;  // 060A1CD0 shll2 r11
    c.r[11] <<= 2;  // 060A1CD2 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1CAC;  // 060A1CD4 bra 0x060A1CAC ; add r12,r11
L_060A1CD8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1CD8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1CDA sub r5,r6
    c.r[11] <<= 2;  // 060A1CDC shll2 r11
    c.r[11] <<= 2;  // 060A1CDE shll2 r11
    c.r[11] += c.r[12];  // 060A1CE0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1CE2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1CE4 shar r0
    c.r[5] += c.r[0];  // 060A1CE6 add r0,r5
    c.r[0] <<= 2;  // 060A1CE8 shll2 r0
    c.r[5] += c.r[0];  // 060A1CEA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1CAC; } }  // 060A1CEC bf/s 0x060A1CAC ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1CF0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1CF2 shll2 r11
    c.r[11] <<= 2;  // 060A1CF4 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1CAC;  // 060A1CF6 bra 0x060A1CAC ; add r12,r11
L_060A1CFC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1CFC mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1CFE add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1D00 tst r11,r11
    if (c.t) { goto L_060A1D0C; }  // 060A1D02 bt 0x060A1D0C
    c.r[11] <<= 2;  // 060A1D04 shll2 r11
    c.r[11] <<= 2;  // 060A1D06 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1CBC;  // 060A1D08 bra 0x060A1CBC ; add r12,r11
L_060A1D0C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D0C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1D0E sub r5,r6
    c.r[11] <<= 2;  // 060A1D10 shll2 r11
    c.r[11] <<= 2;  // 060A1D12 shll2 r11
    c.r[11] += c.r[12];  // 060A1D14 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1D16 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1D18 shar r0
    c.r[5] += c.r[0];  // 060A1D1A add r0,r5
    c.r[0] <<= 2;  // 060A1D1C shll2 r0
    c.r[5] += c.r[0];  // 060A1D1E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1CBC; } }  // 060A1D20 bf/s 0x060A1CBC ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D24 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1D26 shll2 r11
    c.r[11] <<= 2;  // 060A1D28 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1CBC;  // 060A1D2A bra 0x060A1CBC ; add r12,r11
}

void f_060A1D9C(SH2Context& c) {
    ran[2616] = 1;
    goto L_060A1D9C;
L_060A1D34:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D34 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1D36 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1D38 tst r11,r11
    if (c.t) { goto L_060A1D44; }  // 060A1D3A bt 0x060A1D44
    c.r[11] <<= 2;  // 060A1D3C shll2 r11
    c.r[11] <<= 2;  // 060A1D3E shll2 r11
    c.r[11] += c.r[12]; goto L_060A1DB4;  // 060A1D40 bra 0x060A1DB4 ; add r12,r11
L_060A1D44:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D44 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1D46 sub r5,r6
    c.r[11] <<= 2;  // 060A1D48 shll2 r11
    c.r[11] <<= 2;  // 060A1D4A shll2 r11
    c.r[11] += c.r[12];  // 060A1D4C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1D4E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1D50 shar r0
    c.r[5] += c.r[0];  // 060A1D52 add r0,r5
    c.r[0] <<= 2;  // 060A1D54 shll2 r0
    c.r[5] += c.r[0];  // 060A1D56 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A1DB4; } }  // 060A1D58 bf/s 0x060A1DB4 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D5C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1D5E shll2 r11
    c.r[11] <<= 2;  // 060A1D60 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1DB4;  // 060A1D62 bra 0x060A1DB4 ; add r12,r11
L_060A1D68:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D68 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1D6A tst r11,r11
    if (c.t) { goto L_060A1D78; }  // 060A1D6C bt 0x060A1D78
    c.r[11] <<= 2;  // 060A1D6E shll2 r11
    c.r[11] <<= 2;  // 060A1D70 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1DA8;  // 060A1D72 bra 0x060A1DA8 ; add r12,r11
L_060A1D78:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D78 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A1D7A mov r3,r0
    c.r[11] <<= 2;  // 060A1D7C shll2 r11
    c.r[11] <<= 2;  // 060A1D7E shll2 r11
    c.r[11] += c.r[12];  // 060A1D80 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A1D82 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A1D84 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1D86 shar r0
    c.r[5] += c.r[0];  // 060A1D88 add r0,r5
    c.r[0] <<= 2;  // 060A1D8A shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1DA8; } }  // 060A1D8C bf/s 0x060A1DA8 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1D90 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1D92 shll2 r11
    c.r[11] <<= 2;  // 060A1D94 shll2 r11
    c.r[11] += c.r[12]; goto L_060A1DA8;  // 060A1D96 bra 0x060A1DA8 ; add r12,r11
L_060A1D9C:
    c.r[0] = c.r[3];  // 060A1D9C mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A1D9E mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1DA0 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1D68; } }  // 060A1DA2 bt/s 0x060A1D68 ; add r0,r5
    c.r[11] += 4;  // 060A1DA6 add #4,r11
L_060A1DA8:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1DA8 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1DAA mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1DAC shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A1D34; } }  // 060A1DAE bt/s 0x060A1D34 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1DB2 add r5,r6
L_060A1DB4:
    st32(c.r[4], c.r[6]);  // 060A1DB4 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A1DB6 mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1DB8 mov.l @r11+,r0
    c.r[4] += 8;  // 060A1DBA add #8,r4
    st32(c.r[13], c.r[6]);  // 060A1DBC mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1DBE shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1DC0 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1DD8; } }  // 060A1DC2 bt/s 0x060A1DD8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1DC6 add r5,r6
L_060A1DC8:
    st32(c.r[7] + 4, c.r[6]);  // 060A1DC8 mov.l r6,@(4,r7)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1DCA dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A1DCC mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A1D9C; } }  // 060A1DCE bf/s 0x060A1D9C ; add #8,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1DD2 rts ; nop
L_060A1DD8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1DD8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1DDA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1DDC tst r11,r11
    if (c.t) { goto L_060A1DE8; }  // 060A1DDE bt 0x060A1DE8
    c.r[11] <<= 2;  // 060A1DE0 shll2 r11
    c.r[11] <<= 2;  // 060A1DE2 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1DC8;  // 060A1DE4 bra 0x060A1DC8 ; add r12,r11
L_060A1DE8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1DE8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1DEA sub r5,r6
    c.r[11] <<= 2;  // 060A1DEC shll2 r11
    c.r[11] <<= 2;  // 060A1DEE shll2 r11
    c.r[11] += c.r[12];  // 060A1DF0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1DF2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1DF4 shar r0
    c.r[5] += c.r[0];  // 060A1DF6 add r0,r5
    c.r[0] <<= 2;  // 060A1DF8 shll2 r0
    c.r[5] += c.r[0];  // 060A1DFA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1DC8; } }  // 060A1DFC bf/s 0x060A1DC8 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E00 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1E02 shll2 r11
    c.r[11] <<= 2;  // 060A1E04 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1DC8;  // 060A1E06 bra 0x060A1DC8 ; add r12,r11
}

void f_060A1E0C(SH2Context& c) {
    ran[2617] = 1;
L_060A1E0C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1E0C mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1E0E mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1E10 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1E3C; } }  // 060A1E12 bt/s 0x060A1E3C ; add r0,r5
    c.r[6] += c.r[5];  // 060A1E16 add r5,r6
L_060A1E18:
    st32(c.r[4], c.r[6]);  // 060A1E18 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A1E1A mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1E1C mov.l @r11+,r0
    c.r[4] += 8;  // 060A1E1E add #8,r4
    st32(c.r[13], c.r[6]);  // 060A1E20 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1E22 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1E24 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A1E70; } }  // 060A1E26 bt/s 0x060A1E70 ; add r0,r5
    c.r[6] += c.r[5];  // 060A1E2A add r5,r6
L_060A1E2C:
    st32(c.r[7] + 4, c.r[6]);  // 060A1E2C mov.l r6,@(4,r7)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1E2E dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A1E30 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A1E0C; } }  // 060A1E32 bf/s 0x060A1E0C ; add #8,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A1E36 rts ; nop
L_060A1E3C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E3C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1E3E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1E40 tst r11,r11
    if (c.t) { goto L_060A1E4C; }  // 060A1E42 bt 0x060A1E4C
    c.r[11] <<= 2;  // 060A1E44 shll2 r11
    c.r[11] <<= 2;  // 060A1E46 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1E18;  // 060A1E48 bra 0x060A1E18 ; add r12,r11
L_060A1E4C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E4C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1E4E sub r5,r6
    c.r[11] <<= 2;  // 060A1E50 shll2 r11
    c.r[11] <<= 2;  // 060A1E52 shll2 r11
    c.r[11] += c.r[12];  // 060A1E54 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1E56 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1E58 shar r0
    c.r[5] += c.r[0];  // 060A1E5A add r0,r5
    c.r[0] <<= 2;  // 060A1E5C shll2 r0
    c.r[5] += c.r[0];  // 060A1E5E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1E18; } }  // 060A1E60 bf/s 0x060A1E18 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E64 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1E66 shll2 r11
    c.r[11] <<= 2;  // 060A1E68 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1E18;  // 060A1E6A bra 0x060A1E18 ; add r12,r11
L_060A1E70:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E70 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A1E72 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A1E74 tst r11,r11
    if (c.t) { goto L_060A1E80; }  // 060A1E76 bt 0x060A1E80
    c.r[11] <<= 2;  // 060A1E78 shll2 r11
    c.r[11] <<= 2;  // 060A1E7A shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1E2C;  // 060A1E7C bra 0x060A1E2C ; add r12,r11
L_060A1E80:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E80 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A1E82 sub r5,r6
    c.r[11] <<= 2;  // 060A1E84 shll2 r11
    c.r[11] <<= 2;  // 060A1E86 shll2 r11
    c.r[11] += c.r[12];  // 060A1E88 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A1E8A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A1E8C shar r0
    c.r[5] += c.r[0];  // 060A1E8E add r0,r5
    c.r[0] <<= 2;  // 060A1E90 shll2 r0
    c.r[5] += c.r[0];  // 060A1E92 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A1E2C; } }  // 060A1E94 bf/s 0x060A1E2C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1E98 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A1E9A shll2 r11
    c.r[11] <<= 2;  // 060A1E9C shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A1E2C;  // 060A1E9E bra 0x060A1E2C ; add r12,r11
}

void f_060A1F14(SH2Context& c) {
    ran[2618] = 1;
    goto L_060A1F14;
L_060A1EA8:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1EA8 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1EAA tst r4,r4
    if (c.t) { goto L_060A1EB8; }  // 060A1EAC bt 0x060A1EB8
    c.r[4] <<= 2;  // 060A1EAE shll2 r4
    c.r[4] <<= 2;  // 060A1EB0 shll2 r4
    c.r[4] += c.r[7]; goto L_060A1F3C;  // 060A1EB2 bra 0x060A1F3C ; add r7,r4
L_060A1EB8:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1EB8 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1EBA shll r3
    c.r[4] <<= 2;  // 060A1EBC shll2 r4
    c.r[4] <<= 2;  // 060A1EBE shll2 r4
    c.r[4] += c.r[7];  // 060A1EC0 add r7,r4
    c.r[4] += c.r[3];  // 060A1EC2 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1EC4 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1EC6 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1EC8 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1ECA shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1F3C; } }  // 060A1ECC bf/s 0x060A1F3C ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1ED0 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1ED2 shll2 r4
    c.r[4] <<= 2;  // 060A1ED4 shll2 r4
    c.r[4] += c.r[7]; goto L_060A1F3C;  // 060A1ED6 bra 0x060A1F3C ; add r7,r4
L_060A1EDC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1EDC mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1EDE tst r4,r4
    if (c.t) { goto L_060A1EEC; }  // 060A1EE0 bt 0x060A1EEC
    c.r[4] <<= 2;  // 060A1EE2 shll2 r4
    c.r[4] <<= 2;  // 060A1EE4 shll2 r4
    c.r[4] += c.r[7]; goto L_060A1F24;  // 060A1EE6 bra 0x060A1F24 ; add r7,r4
L_060A1EEC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1EEC mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1EEE shll2 r4
    c.r[4] <<= 2;  // 060A1EF0 shll2 r4
    c.r[4] += c.r[7];  // 060A1EF2 add r7,r4
    c.r[4] += c.r[3];  // 060A1EF4 add r3,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1EF6 shll r3
    c.r[4] += c.r[3];  // 060A1EF8 add r3,r4
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060A1EFA mov.l @r4+,r2
    c.r[4] -= c.r[3];  // 060A1EFC sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1EFE shlr r3
    c.r[4] -= c.r[3];  // 060A1F00 sub r3,r4
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A1F02 shar r2
    { const bool k = !c.t; c.r[1] += c.r[2]; if (k) { goto L_060A1F24; } }  // 060A1F04 bf/s 0x060A1F24 ; add r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1F08 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1F0A shll2 r4
    c.r[4] <<= 2;  // 060A1F0C shll2 r4
    c.r[4] += c.r[7]; goto L_060A1F24;  // 060A1F0E bra 0x060A1F24 ; add r7,r4
L_060A1F14:
    c.r[4] += c.r[3];  // 060A1F14 add r3,r4
    ;  // 060A1F16 nop
L_060A1F18:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1F18 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1F1A sub r3,r4
    c.r[12] = ld32(c.r[11]); c.r[11] += 4;  // 060A1F1C mov.l @r11+,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1F1E shar r13
    { const bool k = c.t; c.r[1] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1EDC; } }  // 060A1F20 bt/s 0x060A1EDC ; add r13,r1
L_060A1F24:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1F24 mov.l @r4+,r13
    c.r[12] += c.r[1];  // 060A1F26 add r1,r12
    c.r[2] = c.r[11];  // 060A1F28 mov r11,r2
    c.r[2] += c.r[0];  // 060A1F2A add r0,r2
    c.r[2] += 4;  // 060A1F2C add #4,r2
    ;  // 060A1F2E nop
    st32(c.r[0] + c.r[2], c.r[12]);  // 060A1F30 mov.l r12,@(r0,r2)
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1F32 shar r13
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1F34 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1EA8; } }  // 060A1F36 bt/s 0x060A1EA8 ; add r13,r5
    ;  // 060A1F3A nop
L_060A1F3C:
    c.r[4] += c.r[3];  // 060A1F3C add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1F3E mov.l @r4+,r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1F40 shar r13
    { const bool k = c.t; c.r[1] += c.r[13]; if (k) { goto L_060A1F74; } }  // 060A1F42 bt/s 0x060A1F74 ; add r13,r1
    c.r[4] -= c.r[3];  // 060A1F46 sub r3,r4
L_060A1F48:
    c.r[13] = ld32(c.r[11]); c.r[11] += 4;  // 060A1F48 mov.l @r11+,r13
    c.r[2] = c.r[11];  // 060A1F4A mov r11,r2
    c.r[13] += c.r[1];  // 060A1F4C add r1,r13
    c.r[2] += c.r[0];  // 060A1F4E add r0,r2
    c.r[2] += 4;  // 060A1F50 add #4,r2
    st32(c.r[0] + c.r[2], c.r[13]);  // 060A1F52 mov.l r13,@(r0,r2)
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1F54 mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1F56 swap.w r6,r12
    c.r[12] += c.r[5];  // 060A1F58 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1F5A shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A1FAC; } }  // 060A1F5C bt/s 0x060A1FAC ; add r13,r5
L_060A1F60:
    c.r[6] += c.r[5];  // 060A1F60 add r5,r6
    c.r[6] <<= 16;  // 060A1F62 shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A1F64 xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1F66 dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A1F68 mov.l r6,@(r0,r10)
    { const bool k = !c.t; c.r[4] += c.r[3]; if (k) { SH2_POLL(c); goto L_060A1F18; } }  // 060A1F6A bf/s 0x060A1F18 ; add r3,r4
    { const uint32_t x = c.pr; c.r[4] -= c.r[3]; c.pc = x; return; }  // 060A1F6E rts ; sub r3,r4
L_060A1F74:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1F74 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1F76 tst r4,r4
    if (c.t) { goto L_060A1F84; }  // 060A1F78 bt 0x060A1F84
    c.r[4] <<= 2;  // 060A1F7A shll2 r4
    c.r[4] <<= 2;  // 060A1F7C shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1F48;  // 060A1F7E bra 0x060A1F48 ; add r7,r4
L_060A1F84:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1F84 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1F86 shll2 r4
    c.r[4] <<= 2;  // 060A1F88 shll2 r4
    c.r[4] += c.r[7];  // 060A1F8A add r7,r4
    c.r[4] += c.r[3];  // 060A1F8C add r3,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1F8E shll r3
    c.r[4] += c.r[3];  // 060A1F90 add r3,r4
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060A1F92 mov.l @r4+,r2
    c.r[4] -= c.r[3];  // 060A1F94 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1F96 shlr r3
    c.r[4] -= c.r[3];  // 060A1F98 sub r3,r4
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A1F9A shar r2
    { const bool k = !c.t; c.r[1] += c.r[2]; if (k) { SH2_POLL(c); goto L_060A1F48; } }  // 060A1F9C bf/s 0x060A1F48 ; add r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1FA0 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1FA2 shll2 r4
    c.r[4] <<= 2;  // 060A1FA4 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1F48;  // 060A1FA6 bra 0x060A1F48 ; add r7,r4
L_060A1FAC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1FAC mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A1FAE tst r4,r4
    if (c.t) { goto L_060A1FBC; }  // 060A1FB0 bt 0x060A1FBC
    c.r[4] <<= 2;  // 060A1FB2 shll2 r4
    c.r[4] <<= 2;  // 060A1FB4 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1F60;  // 060A1FB6 bra 0x060A1F60 ; add r7,r4
L_060A1FBC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1FBC mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A1FBE shll r3
    c.r[4] <<= 2;  // 060A1FC0 shll2 r4
    c.r[4] <<= 2;  // 060A1FC2 shll2 r4
    c.r[4] += c.r[7];  // 060A1FC4 add r7,r4
    c.r[4] += c.r[3];  // 060A1FC6 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1FC8 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A1FCA sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A1FCC shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1FCE shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1F60; } }  // 060A1FD0 bf/s 0x060A1F60 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A1FD4 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A1FD6 shll2 r4
    c.r[4] <<= 2;  // 060A1FD8 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1F60;  // 060A1FDA bra 0x060A1F60 ; add r7,r4
}

void f_060A1FE0(SH2Context& c) {
    ran[2619] = 1;
L_060A1FE0:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1FE0 mov.l @r4+,r13
    ;  // 060A1FE2 nop
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A1FE4 mov.l @r10+,r6
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1FE6 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A2008; } }  // 060A1FE8 bt/s 0x060A2008 ; add r13,r5
L_060A1FEC:
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A1FEC mov.l @r4+,r13
    c.r[12] = c.r[6] << 16 | c.r[6] >> 16;  // 060A1FEE swap.w r6,r12
    c.r[12] += c.r[5];  // 060A1FF0 add r5,r12
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A1FF2 shar r13
    { const bool k = c.t; c.r[5] += c.r[13]; if (k) { goto L_060A203C; } }  // 060A1FF4 bt/s 0x060A203C ; add r13,r5
L_060A1FF8:
    c.r[6] += c.r[5];  // 060A1FF8 add r5,r6
    c.r[6] <<= 16;  // 060A1FFA shll16 r6
    c.r[6] = c.r[12] << 16 | c.r[6] >> 16;  // 060A1FFC xtrct r12,r6
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A1FFE dt r8
    st32(c.r[0] + c.r[10], c.r[6]);  // 060A2000 mov.l r6,@(r0,r10)
    if (!c.t) { SH2_POLL(c); goto L_060A1FE0; }  // 060A2002 bf 0x060A1FE0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A2004 rts ; nop
L_060A2008:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2008 mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A200A tst r4,r4
    if (c.t) { goto L_060A2018; }  // 060A200C bt 0x060A2018
    c.r[4] <<= 2;  // 060A200E shll2 r4
    c.r[4] <<= 2;  // 060A2010 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1FEC;  // 060A2012 bra 0x060A1FEC ; add r7,r4
L_060A2018:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2018 mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A201A shll r3
    c.r[4] <<= 2;  // 060A201C shll2 r4
    c.r[4] <<= 2;  // 060A201E shll2 r4
    c.r[4] += c.r[7];  // 060A2020 add r7,r4
    c.r[4] += c.r[3];  // 060A2022 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A2024 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A2026 sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A2028 shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A202A shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1FEC; } }  // 060A202C bf/s 0x060A1FEC ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2030 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A2032 shll2 r4
    c.r[4] <<= 2;  // 060A2034 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1FEC;  // 060A2036 bra 0x060A1FEC ; add r7,r4
L_060A203C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A203C mov.b @r14+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060A203E tst r4,r4
    if (c.t) { goto L_060A204C; }  // 060A2040 bt 0x060A204C
    c.r[4] <<= 2;  // 060A2042 shll2 r4
    c.r[4] <<= 2;  // 060A2044 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1FF8;  // 060A2046 bra 0x060A1FF8 ; add r7,r4
L_060A204C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A204C mov.b @r14+,r4
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060A204E shll r3
    c.r[4] <<= 2;  // 060A2050 shll2 r4
    c.r[4] <<= 2;  // 060A2052 shll2 r4
    c.r[4] += c.r[7];  // 060A2054 add r7,r4
    c.r[4] += c.r[3];  // 060A2056 add r3,r4
    c.r[13] = ld32(c.r[4]); c.r[4] += 4;  // 060A2058 mov.l @r4+,r13
    c.r[4] -= c.r[3];  // 060A205A sub r3,r4
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060A205C shlr r3
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060A205E shar r13
    { const bool k = !c.t; c.r[5] += c.r[13]; if (k) { SH2_POLL(c); goto L_060A1FF8; } }  // 060A2060 bf/s 0x060A1FF8 ; add r13,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2064 mov.b @r14+,r4
    c.r[4] <<= 2;  // 060A2066 shll2 r4
    c.r[4] <<= 2;  // 060A2068 shll2 r4
    c.r[4] += c.r[7]; SH2_POLL(c); goto L_060A1FF8;  // 060A206A bra 0x060A1FF8 ; add r7,r4
}

void f_060A2070(SH2Context& c) {
    ran[2620] = 1;
    c.r[0] = 0x060A2188u;  // 060A2070 mova 0x060A2188,r0
    st32(c.r[0], c.r[4]);  // 060A2072 mov.l r4,@r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A2074 rts ; nop
}

void f_060A2078(SH2Context& c) {
    ran[2621] = 1;
    c.r[0] = 0x060A21ACu;  // 060A2078 mova 0x060A21AC,r0
    st32(c.r[0], c.r[4]);  // 060A207A mov.l r4,@r0
    c.r[0] = 0x060A21B8u;  // 060A207C mova 0x060A21B8,r0
    st32(c.r[0], c.r[5]);  // 060A207E mov.l r5,@r0
    c.r[0] = 0x060A21BCu;  // 060A2080 mova 0x060A21BC,r0
    st32(c.r[0], c.r[6]);  // 060A2082 mov.l r6,@r0
    c.r[0] = 0x060A21B0u;  // 060A2084 mova 0x060A21B0,r0
    st32(c.r[0], c.r[7]);  // 060A2086 mov.l r7,@r0
    c.r[2] = ld32(0x060A21A4u);  // 060A2088 mov.l 0x060A21A4,r2
    c.r[0] = 0x060A21A8u;  // 060A208A mova 0x060A21A8,r0
    st32(c.r[0], c.r[2]);  // 060A208C mov.l r2,@r0
    c.r[2] = ld32(0x060A21CCu);  // 060A208E mov.l 0x060A21CC,r2
    c.r[0] = 0x060A21D0u;  // 060A2090 mova 0x060A21D0,r0
    st32(c.r[0], c.r[2]);  // 060A2092 mov.l r2,@r0
    c.r[2] = ld32(c.r[15]);  // 060A2094 mov.l @r15,r2
    c.r[0] = 0x060A21D4u;  // 060A2096 mova 0x060A21D4,r0
    st32(c.r[0], c.r[2]);  // 060A2098 mov.l r2,@r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A209A rts ; nop
}

void f_060A20A0(SH2Context& c) {
    ran[2622] = 1;
    c.r[0] = 0x060A219Cu;  // 060A20A0 mova 0x060A219C,r0
    st32(c.r[0], c.r[4]);  // 060A20A2 mov.l r4,@r0
    c.r[0] = 0x060A2180u;  // 060A20A4 mova 0x060A2180,r0
    st32(c.r[0], c.r[5]);  // 060A20A6 mov.l r5,@r0
    c.r[2] = c.r[7];  // 060A20A8 mov r7,r2
    c.r[2] >>= 2;  // 060A20AA shlr2 r2
    c.r[0] = 0x060A2190u;  // 060A20AC mova 0x060A2190,r0
    st32(c.r[0], c.r[2]);  // 060A20AE mov.l r2,@r0
    c.t = c.r[6] >> 31; c.r[6] <<= 1;  // 060A20B0 shll r6
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 060A20B2 shll r7
    c.t = c.r[6] >> 31; c.r[6] <<= 1;  // 060A20B4 shll r6
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 060A20B6 shll r7
    c.r[0] = 0x060A2198u;  // 060A20B8 mova 0x060A2198,r0
    st32(c.r[0], c.r[6]);  // 060A20BA mov.l r6,@r0
    c.r[0] = 0x060A218Cu;  // 060A20BC mova 0x060A218C,r0
    st32(c.r[0], c.r[7]);  // 060A20BE mov.l r7,@r0
    c.r[0] = 0x060A2194u;  // 060A20C0 mova 0x060A2194,r0
    c.r[1] = ld32(c.r[15]);  // 060A20C2 mov.l @r15,r1
    st32(c.r[0], c.r[1]);  // 060A20C4 mov.l r1,@r0
    c.r[1] = ld32(c.r[15] + 4);  // 060A20C6 mov.l @(4,r15),r1
    c.r[0] = 0x060A217Cu;  // 060A20C8 mova 0x060A217C,r0
    st32(c.r[0], c.r[1]);  // 060A20CA mov.l r1,@r0
    c.r[0] = 0x060A21C4u;  // 060A20CC mova 0x060A21C4,r0
    c.r[1] = ld32(c.r[15] + 8);  // 060A20CE mov.l @(8,r15),r1
    st32(c.r[0], c.r[1]);  // 060A20D0 mov.l r1,@r0
    c.r[1] = ld32(c.r[15] + 12);  // 060A20D2 mov.l @(12,r15),r1
    c.r[0] = 0x060A21B4u;  // 060A20D4 mova 0x060A21B4,r0
    st32(c.r[0], c.r[1]);  // 060A20D6 mov.l r1,@r0
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A20D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A20DA sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060A20DC stc.l gbr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A20DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A20E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A20E2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A20E4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A20E6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A20E8 mov.l r14,@-r15
    c.r[15] -= 64;  // 060A20EA add #-64,r15
    c.r[0] = ld32(0x060A21C4u);  // 060A20EC mov.l 0x060A21C4,r0
    st32(c.r[15] + 12, c.r[0]);  // 060A20EE mov.l r0,@(12,r15)
    c.r[0] = ld32(0x060A217Cu);  // 060A20F0 mov.l 0x060A217C,r0
    st32(c.r[15] + 24, c.r[0]);  // 060A20F2 mov.l r0,@(24,r15)
    c.r[7] = ld32(0x060A21A0u);  // 060A20F4 mov.l 0x060A21A0,r7
    c.r[0] = ld32(0x060A21A8u);  // 060A20F6 mov.l 0x060A21A8,r0
    c.r[7] += c.r[0];  // 060A20F8 add r0,r7
    ;  // 060A20FA nop
    c.r[13] = ld32(0x060A2188u);  // 060A20FC mov.l 0x060A2188,r13
    st32(c.r[15] + 44, c.r[13]);  // 060A20FE mov.l r13,@(44,r15)
    c.r[14] = ld32(0x060A219Cu);  // 060A2100 mov.l 0x060A219C,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2102 mov.b @r14+,r4
    c.r[9] = ld32(0x060A2194u);  // 060A2104 mov.l 0x060A2194,r9
    c.r[4] <<= 2;  // 060A2106 shll2 r4
    c.r[10] = ld32(0x060A21ACu);  // 060A2108 mov.l 0x060A21AC,r10
    c.r[4] <<= 2;  // 060A210A shll2 r4
    c.r[11] = ld32(0x060A21B0u);  // 060A210C mov.l 0x060A21B0,r11
    c.r[4] += c.r[7];  // 060A210E add r7,r4
    c.r[0] = ld32(0x060A2190u);  // 060A2110 mov.l 0x060A2190,r0
    c.r[0] <<= 2;  // 060A2112 shll2 r0
    c.r[3] = ld32(0x060A21D0u);  // 060A2114 mov.l 0x060A21D0,r3
    c.r[0] -= 4;  // 060A2116 add #-4,r0
L_060A2118:
    c.r[8] = ld32(0x060A2190u);  // 060A2118 mov.l 0x060A2190,r8
    c.r[5] = 0x0u;  // 060A211A mov #0,r5
    st32(c.r[15] + 16, c.r[8]);  // 060A211C mov.l r8,@(16,r15)
    c.r[1] = 0x0u;  // 060A211E mov #0,r1
    c.r[2] = ld32(c.r[15] + 24);  // 060A2120 mov.l @(24,r15),r2
    c.r[13] = c.r[9];  // 060A2122 mov r9,r13
    c.r[13] &= c.r[2];  // 060A2124 and r2,r13
    st32(c.r[15] + 20, c.r[9]);  // 060A2126 mov.l r9,@(20,r15)
    c.t = (c.r[13] & c.r[13]) == 0;  // 060A2128 tst r13,r13
    ;  // 060A212A nop
    c.r[13] = ld32(0x060A21C0u);  // 060A212C mov.l 0x060A21C0,r13
    { const bool k = !c.t; c.gbr = c.r[13]; if (k) { goto L_060A2158; } }  // 060A212E bf/s 0x060A2158 ; ldc r13,gbr
    c.r[13] = c.r[9];  // 060A2132 mov r9,r13
    c.r[2] = 0x2u;  // 060A2134 mov #2,r2
    c.t = (c.r[13] & c.r[2]) == 0;  // 060A2136 tst r2,r13
    { const bool k = c.t; c.t = 0; if (k) { goto L_060A2142; } }  // 060A2138 bt/s 0x060A2142 ; clrt
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060A213C shlr r2
    c.r[13] = ld32(c.r[15] + 24);  // 060A213E mov.l @(24,r15),r13
    c.t = c.r[13] == c.r[2];  // 060A2140 cmp/eq r2,r13
L_060A2142:
    c.r[2] = c.t;  // 060A2142 movt r2
    st32(c.r[15] + 32, c.r[2]);  // 060A2144 mov.l r2,@(32,r15)
    c.r[13] = ld32(0x060A21D4u);  // 060A2146 mov.l 0x060A21D4,r13
L_060A2148:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[13]);  // 060A2148 mov.w @r13,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[9];  // 060A214A cmp/ge r9,r2
    if (c.t) { SH2_POLL(c); goto L_060A2148; }  // 060A214C bt 0x060A2148
    c.r[13] = ld32(0x060A21B8u);  // 060A214E mov.l 0x060A21B8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060A2154u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A2154u) return; }  // 060A2150 jsr @r13 ; nop
    c.r[9] = ld32(c.r[15] + 20); goto L_060A2160;  // 060A2154 bra 0x060A2160 ; mov.l @(20,r15),r9
L_060A2158:
    c.r[13] = ld32(0x060A21BCu);  // 060A2158 mov.l 0x060A21BC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060A215Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A215Eu) return; }  // 060A215A jsr @r13 ; nop
    c.r[9] = ld32(c.r[15] + 20);  // 060A215E mov.l @(20,r15),r9
L_060A2160:
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060A2160 dt r9
    if (!c.t) { SH2_POLL(c); goto L_060A2118; }  // 060A2162 bf 0x060A2118
    c.r[15] += 64;  // 060A2164 add #64,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A2166 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A2168 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A216A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A216C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A216E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A2170 mov.l @r15+,r9
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060A2172 ldc.l @r15+,gbr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A2174 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A2176 rts ; mov.l @r15+,r8
}

void f_060A2240(SH2Context& c) {
    ran[2623] = 1;
    goto L_060A2240;
L_060A21D8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A21D8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A21DA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A21DC tst r11,r11
    if (c.t) { goto L_060A21E8; }  // 060A21DE bt 0x060A21E8
    c.r[11] <<= 2;  // 060A21E0 shll2 r11
    c.r[11] <<= 2;  // 060A21E2 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2258;  // 060A21E4 bra 0x060A2258 ; add r12,r11
L_060A21E8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A21E8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A21EA sub r5,r6
    c.r[11] <<= 2;  // 060A21EC shll2 r11
    c.r[11] <<= 2;  // 060A21EE shll2 r11
    c.r[11] += c.r[12];  // 060A21F0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A21F2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A21F4 shar r0
    c.r[5] += c.r[0];  // 060A21F6 add r0,r5
    c.r[0] <<= 2;  // 060A21F8 shll2 r0
    c.r[5] += c.r[0];  // 060A21FA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2258; } }  // 060A21FC bf/s 0x060A2258 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2200 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2202 shll2 r11
    c.r[11] <<= 2;  // 060A2204 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2258;  // 060A2206 bra 0x060A2258 ; add r12,r11
L_060A220C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A220C mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A220E tst r11,r11
    if (c.t) { goto L_060A221C; }  // 060A2210 bt 0x060A221C
    c.r[11] <<= 2;  // 060A2212 shll2 r11
    c.r[11] <<= 2;  // 060A2214 shll2 r11
    c.r[11] += c.r[12]; goto L_060A224C;  // 060A2216 bra 0x060A224C ; add r12,r11
L_060A221C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A221C mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A221E mov r3,r0
    c.r[11] <<= 2;  // 060A2220 shll2 r11
    c.r[11] <<= 2;  // 060A2222 shll2 r11
    c.r[11] += c.r[12];  // 060A2224 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2226 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A2228 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A222A shar r0
    c.r[5] += c.r[0];  // 060A222C add r0,r5
    c.r[0] <<= 2;  // 060A222E shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A224C; } }  // 060A2230 bf/s 0x060A224C ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2234 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2236 shll2 r11
    c.r[11] <<= 2;  // 060A2238 shll2 r11
    c.r[11] += c.r[12]; goto L_060A224C;  // 060A223A bra 0x060A224C ; add r12,r11
L_060A2240:
    c.r[0] = c.r[3];  // 060A2240 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2242 mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2244 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A220C; } }  // 060A2246 bt/s 0x060A220C ; add r0,r5
    c.r[11] += 4;  // 060A224A add #4,r11
L_060A224C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A224C mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A224E mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2250 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A21D8; } }  // 060A2252 bt/s 0x060A21D8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2256 add r5,r6
L_060A2258:
    st32(c.r[4], c.r[6]);  // 060A2258 mov.l r6,@r4
    ;  // 060A225A nop
    c.r[0] = ld32(0x060A2410u);  // 060A225C mov.l 0x060A2410,r0
    c.r[1] = c.r[6] << 16 | c.r[6] >> 16;  // 060A225E swap.w r6,r1
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A2260 swap.w r6,r2
    c.r[2] += c.r[0];  // 060A2262 add r0,r2
    c.r[0] = ~c.r[0];  // 060A2264 not r0,r0
    c.r[2] &= c.r[0];  // 060A2266 and r0,r2
    c.r[6] &= c.r[0];  // 060A2268 and r0,r6
    c.r[6] += c.r[2];  // 060A226A add r2,r6
    c.r[2] = 0xFFFFFF80u;  // 060A226C mov #-128,r2
    c.r[2] <<= 8;  // 060A226E shll8 r2
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A2270 shar r6
    c.r[6] |= c.r[2];  // 060A2272 or r2,r6
    c.r[6] <<= 16;  // 060A2274 shll16 r6
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A2276 xtrct r1,r6
    st32(c.r[13], c.r[6]);  // 060A2278 mov.l r6,@r13
    c.r[1] >>= 16;  // 060A227A shlr16 r1
    c.r[0] = c.r[3];  // 060A227C mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A227E mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2280 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A22CC; } }  // 060A2282 bt/s 0x060A22CC ; add r0,r5
    c.r[11] += 4;  // 060A2286 add #4,r11
L_060A2288:
    ;  // 060A2288 nop
    c.r[7] = c.r[4];  // 060A228A mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A228C mov.l @r11+,r0
    c.r[4] += 8;  // 060A228E add #8,r4
    st32(c.r[13], c.r[6]);  // 060A2290 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2292 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A2294 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2300; } }  // 060A2296 bt/s 0x060A2300 ; add r0,r5
    c.r[6] += c.r[5];  // 060A229A add r5,r6
L_060A229C:
    st32(c.r[7] + 4, c.r[6]);  // 060A229C mov.l r6,@(4,r7)
    ;  // 060A229E nop
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A22A0 swap.w r6,r2
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A22A2 xtrct r1,r6
    st32(c.r[13] + 4, c.r[6]);  // 060A22A4 mov.l r6,@(4,r13)
    c.r[6] = c.r[2] << 16 | c.r[2] >> 16;  // 060A22A6 swap.w r2,r6
    c.r[0] = ld32(0x060A2410u);  // 060A22A8 mov.l 0x060A2410,r0
    c.r[1] = c.r[2];  // 060A22AA mov r2,r1
    c.r[2] += c.r[0];  // 060A22AC add r0,r2
    c.r[0] = ~c.r[0];  // 060A22AE not r0,r0
    c.r[2] &= c.r[0];  // 060A22B0 and r0,r2
    c.r[6] &= c.r[0];  // 060A22B2 and r0,r6
    c.r[6] += c.r[2];  // 060A22B4 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A22B6 shar r6
    c.r[2] = 0xFFFFFF80u;  // 060A22B8 mov #-128,r2
    c.r[2] <<= 8;  // 060A22BA shll8 r2
    c.r[6] |= c.r[2];  // 060A22BC or r2,r6
    c.r[1] = c.r[6] << 16 | c.r[1] >> 16;  // 060A22BE xtrct r6,r1
    st32(c.r[13] + 8, c.r[1]);  // 060A22C0 mov.l r1,@(8,r13)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A22C2 dt r8
    { const bool k = !c.t; c.r[13] += 12; if (k) { SH2_POLL(c); goto L_060A2240; } }  // 060A22C4 bf/s 0x060A2240 ; add #12,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A22C8 rts ; nop
L_060A22CC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A22CC mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A22CE tst r11,r11
    if (c.t) { goto L_060A22DC; }  // 060A22D0 bt 0x060A22DC
    c.r[11] <<= 2;  // 060A22D2 shll2 r11
    c.r[11] <<= 2;  // 060A22D4 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2288;  // 060A22D6 bra 0x060A2288 ; add r12,r11
L_060A22DC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A22DC mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A22DE mov r3,r0
    c.r[11] <<= 2;  // 060A22E0 shll2 r11
    c.r[11] <<= 2;  // 060A22E2 shll2 r11
    c.r[11] += c.r[12];  // 060A22E4 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A22E6 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A22E8 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A22EA shar r0
    c.r[5] += c.r[0];  // 060A22EC add r0,r5
    c.r[0] <<= 2;  // 060A22EE shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2288; } }  // 060A22F0 bf/s 0x060A2288 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A22F4 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A22F6 shll2 r11
    c.r[11] <<= 2;  // 060A22F8 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2288;  // 060A22FA bra 0x060A2288 ; add r12,r11
L_060A2300:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2300 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2302 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2304 tst r11,r11
    if (c.t) { goto L_060A2310; }  // 060A2306 bt 0x060A2310
    c.r[11] <<= 2;  // 060A2308 shll2 r11
    c.r[11] <<= 2;  // 060A230A shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A229C;  // 060A230C bra 0x060A229C ; add r12,r11
L_060A2310:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2310 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2312 sub r5,r6
    c.r[11] <<= 2;  // 060A2314 shll2 r11
    c.r[11] <<= 2;  // 060A2316 shll2 r11
    c.r[11] += c.r[12];  // 060A2318 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A231A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A231C shar r0
    c.r[5] += c.r[0];  // 060A231E add r0,r5
    c.r[0] <<= 2;  // 060A2320 shll2 r0
    c.r[5] += c.r[0];  // 060A2322 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A229C; } }  // 060A2324 bf/s 0x060A229C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2328 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A232A shll2 r11
    c.r[11] <<= 2;  // 060A232C shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A229C;  // 060A232E bra 0x060A229C ; add r12,r11
}

void f_060A2334(SH2Context& c) {
    ran[2624] = 1;
L_060A2334:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2334 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A2336 mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2338 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A23A8; } }  // 060A233A bt/s 0x060A23A8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A233E add r5,r6
L_060A2340:
    st32(c.r[4], c.r[6]);  // 060A2340 mov.l r6,@r4
    ;  // 060A2342 nop
    c.r[0] = ld32(0x060A2410u);  // 060A2344 mov.l 0x060A2410,r0
    c.r[1] = c.r[6] << 16 | c.r[6] >> 16;  // 060A2346 swap.w r6,r1
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A2348 swap.w r6,r2
    c.r[2] += c.r[0];  // 060A234A add r0,r2
    c.r[0] = ~c.r[0];  // 060A234C not r0,r0
    c.r[2] &= c.r[0];  // 060A234E and r0,r2
    c.r[6] &= c.r[0];  // 060A2350 and r0,r6
    c.r[6] += c.r[2];  // 060A2352 add r2,r6
    c.r[2] = 0xFFFFFF80u;  // 060A2354 mov #-128,r2
    c.r[2] <<= 8;  // 060A2356 shll8 r2
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A2358 shar r6
    c.r[6] |= c.r[2];  // 060A235A or r2,r6
    c.r[6] <<= 16;  // 060A235C shll16 r6
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A235E xtrct r1,r6
    st32(c.r[13], c.r[6]);  // 060A2360 mov.l r6,@r13
    c.r[1] >>= 16;  // 060A2362 shlr16 r1
    ;  // 060A2364 nop
    c.r[7] = c.r[4];  // 060A2366 mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2368 mov.l @r11+,r0
    c.r[4] += 8;  // 060A236A add #8,r4
    st32(c.r[13], c.r[6]);  // 060A236C mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A236E shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A2370 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A23DC; } }  // 060A2372 bt/s 0x060A23DC ; add r0,r5
    c.r[6] += c.r[5];  // 060A2376 add r5,r6
L_060A2378:
    st32(c.r[7] + 4, c.r[6]);  // 060A2378 mov.l r6,@(4,r7)
    ;  // 060A237A nop
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060A237C swap.w r6,r2
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060A237E xtrct r1,r6
    st32(c.r[13] + 4, c.r[6]);  // 060A2380 mov.l r6,@(4,r13)
    c.r[6] = c.r[2] << 16 | c.r[2] >> 16;  // 060A2382 swap.w r2,r6
    c.r[0] = ld32(0x060A2410u);  // 060A2384 mov.l 0x060A2410,r0
    c.r[1] = c.r[2];  // 060A2386 mov r2,r1
    c.r[2] += c.r[0];  // 060A2388 add r0,r2
    c.r[0] = ~c.r[0];  // 060A238A not r0,r0
    c.r[2] &= c.r[0];  // 060A238C and r0,r2
    c.r[6] &= c.r[0];  // 060A238E and r0,r6
    c.r[6] += c.r[2];  // 060A2390 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060A2392 shar r6
    c.r[2] = 0xFFFFFF80u;  // 060A2394 mov #-128,r2
    c.r[2] <<= 8;  // 060A2396 shll8 r2
    c.r[6] |= c.r[2];  // 060A2398 or r2,r6
    c.r[1] = c.r[6] << 16 | c.r[1] >> 16;  // 060A239A xtrct r6,r1
    st32(c.r[13] + 8, c.r[1]);  // 060A239C mov.l r1,@(8,r13)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A239E dt r8
    { const bool k = !c.t; c.r[13] += 12; if (k) { SH2_POLL(c); goto L_060A2334; } }  // 060A23A0 bf/s 0x060A2334 ; add #12,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A23A4 rts ; nop
L_060A23A8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A23A8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A23AA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A23AC tst r11,r11
    if (c.t) { goto L_060A23B8; }  // 060A23AE bt 0x060A23B8
    c.r[11] <<= 2;  // 060A23B0 shll2 r11
    c.r[11] <<= 2;  // 060A23B2 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2340;  // 060A23B4 bra 0x060A2340 ; add r12,r11
L_060A23B8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A23B8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A23BA sub r5,r6
    c.r[11] <<= 2;  // 060A23BC shll2 r11
    c.r[11] <<= 2;  // 060A23BE shll2 r11
    c.r[11] += c.r[12];  // 060A23C0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A23C2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A23C4 shar r0
    c.r[5] += c.r[0];  // 060A23C6 add r0,r5
    c.r[0] <<= 2;  // 060A23C8 shll2 r0
    c.r[5] += c.r[0];  // 060A23CA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2340; } }  // 060A23CC bf/s 0x060A2340 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A23D0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A23D2 shll2 r11
    c.r[11] <<= 2;  // 060A23D4 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2340;  // 060A23D6 bra 0x060A2340 ; add r12,r11
L_060A23DC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A23DC mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A23DE add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A23E0 tst r11,r11
    if (c.t) { goto L_060A23EC; }  // 060A23E2 bt 0x060A23EC
    c.r[11] <<= 2;  // 060A23E4 shll2 r11
    c.r[11] <<= 2;  // 060A23E6 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2378;  // 060A23E8 bra 0x060A2378 ; add r12,r11
L_060A23EC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A23EC mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A23EE sub r5,r6
    c.r[11] <<= 2;  // 060A23F0 shll2 r11
    c.r[11] <<= 2;  // 060A23F2 shll2 r11
    c.r[11] += c.r[12];  // 060A23F4 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A23F6 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A23F8 shar r0
    c.r[5] += c.r[0];  // 060A23FA add r0,r5
    c.r[0] <<= 2;  // 060A23FC shll2 r0
    c.r[5] += c.r[0];  // 060A23FE add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2378; } }  // 060A2400 bf/s 0x060A2378 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2404 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2406 shll2 r11
    c.r[11] <<= 2;  // 060A2408 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2378;  // 060A240A bra 0x060A2378 ; add r12,r11
}

void f_060A247C(SH2Context& c) {
    ran[2625] = 1;
    goto L_060A247C;
L_060A2414:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2414 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2416 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2418 tst r11,r11
    if (c.t) { goto L_060A2424; }  // 060A241A bt 0x060A2424
    c.r[11] <<= 2;  // 060A241C shll2 r11
    c.r[11] <<= 2;  // 060A241E shll2 r11
    c.r[11] += c.r[12]; goto L_060A2494;  // 060A2420 bra 0x060A2494 ; add r12,r11
L_060A2424:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2424 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2426 sub r5,r6
    c.r[11] <<= 2;  // 060A2428 shll2 r11
    c.r[11] <<= 2;  // 060A242A shll2 r11
    c.r[11] += c.r[12];  // 060A242C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A242E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2430 shar r0
    c.r[5] += c.r[0];  // 060A2432 add r0,r5
    c.r[0] <<= 2;  // 060A2434 shll2 r0
    c.r[5] += c.r[0];  // 060A2436 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2494; } }  // 060A2438 bf/s 0x060A2494 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A243C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A243E shll2 r11
    c.r[11] <<= 2;  // 060A2440 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2494;  // 060A2442 bra 0x060A2494 ; add r12,r11
L_060A2448:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2448 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A244A tst r11,r11
    if (c.t) { goto L_060A2458; }  // 060A244C bt 0x060A2458
    c.r[11] <<= 2;  // 060A244E shll2 r11
    c.r[11] <<= 2;  // 060A2450 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2488;  // 060A2452 bra 0x060A2488 ; add r12,r11
L_060A2458:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2458 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A245A mov r3,r0
    c.r[11] <<= 2;  // 060A245C shll2 r11
    c.r[11] <<= 2;  // 060A245E shll2 r11
    c.r[11] += c.r[12];  // 060A2460 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2462 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A2464 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2466 shar r0
    c.r[5] += c.r[0];  // 060A2468 add r0,r5
    c.r[0] <<= 2;  // 060A246A shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2488; } }  // 060A246C bf/s 0x060A2488 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2470 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2472 shll2 r11
    c.r[11] <<= 2;  // 060A2474 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2488;  // 060A2476 bra 0x060A2488 ; add r12,r11
L_060A247C:
    c.r[0] = c.r[3];  // 060A247C mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A247E mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2480 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2448; } }  // 060A2482 bt/s 0x060A2448 ; add r0,r5
    c.r[11] += 4;  // 060A2486 add #4,r11
L_060A2488:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2488 mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A248A mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A248C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2414; } }  // 060A248E bt/s 0x060A2414 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2492 add r5,r6
L_060A2494:
    c.r[0] = c.r[3];  // 060A2494 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2496 mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2498 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A24C4; } }  // 060A249A bt/s 0x060A24C4 ; add r0,r5
    c.r[11] += 4;  // 060A249E add #4,r11
L_060A24A0:
    st32(c.r[4], c.r[6]);  // 060A24A0 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A24A2 mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A24A4 mov.l @r11+,r0
    c.r[4] += 8;  // 060A24A6 add #8,r4
    st32(c.r[13], c.r[6]);  // 060A24A8 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A24AA shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A24AC mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A24F8; } }  // 060A24AE bt/s 0x060A24F8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A24B2 add r5,r6
L_060A24B4:
    st32(c.r[7] + 4, c.r[6]);  // 060A24B4 mov.l r6,@(4,r7)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A24B6 dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A24B8 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A247C; } }  // 060A24BA bf/s 0x060A247C ; add #8,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A24BE rts ; nop
L_060A24C4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A24C4 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A24C6 tst r11,r11
    if (c.t) { goto L_060A24D4; }  // 060A24C8 bt 0x060A24D4
    c.r[11] <<= 2;  // 060A24CA shll2 r11
    c.r[11] <<= 2;  // 060A24CC shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A24A0;  // 060A24CE bra 0x060A24A0 ; add r12,r11
L_060A24D4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A24D4 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A24D6 mov r3,r0
    c.r[11] <<= 2;  // 060A24D8 shll2 r11
    c.r[11] <<= 2;  // 060A24DA shll2 r11
    c.r[11] += c.r[12];  // 060A24DC add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A24DE mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A24E0 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A24E2 shar r0
    c.r[5] += c.r[0];  // 060A24E4 add r0,r5
    c.r[0] <<= 2;  // 060A24E6 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A24A0; } }  // 060A24E8 bf/s 0x060A24A0 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A24EC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A24EE shll2 r11
    c.r[11] <<= 2;  // 060A24F0 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A24A0;  // 060A24F2 bra 0x060A24A0 ; add r12,r11
L_060A24F8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A24F8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A24FA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A24FC tst r11,r11
    if (c.t) { goto L_060A2508; }  // 060A24FE bt 0x060A2508
    c.r[11] <<= 2;  // 060A2500 shll2 r11
    c.r[11] <<= 2;  // 060A2502 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A24B4;  // 060A2504 bra 0x060A24B4 ; add r12,r11
L_060A2508:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2508 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A250A sub r5,r6
    c.r[11] <<= 2;  // 060A250C shll2 r11
    c.r[11] <<= 2;  // 060A250E shll2 r11
    c.r[11] += c.r[12];  // 060A2510 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2512 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2514 shar r0
    c.r[5] += c.r[0];  // 060A2516 add r0,r5
    c.r[0] <<= 2;  // 060A2518 shll2 r0
    c.r[5] += c.r[0];  // 060A251A add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A24B4; } }  // 060A251C bf/s 0x060A24B4 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2520 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2522 shll2 r11
    c.r[11] <<= 2;  // 060A2524 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A24B4;  // 060A2526 bra 0x060A24B4 ; add r12,r11
}

void f_060A252C(SH2Context& c) {
    ran[2626] = 1;
L_060A252C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A252C mov.l @r11+,r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A252E mov.l @r10+,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2530 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A255C; } }  // 060A2532 bt/s 0x060A255C ; add r0,r5
    c.r[6] += c.r[5];  // 060A2536 add r5,r6
L_060A2538:
    st32(c.r[4], c.r[6]);  // 060A2538 mov.l r6,@r4
    c.r[7] = c.r[4];  // 060A253A mov r4,r7
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A253C mov.l @r11+,r0
    c.r[4] += 8;  // 060A253E add #8,r4
    st32(c.r[13], c.r[6]);  // 060A2540 mov.l r6,@r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2542 shar r0
    c.r[6] = ld32(c.r[10]); c.r[10] += 4;  // 060A2544 mov.l @r10+,r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2590; } }  // 060A2546 bt/s 0x060A2590 ; add r0,r5
    c.r[6] += c.r[5];  // 060A254A add r5,r6
L_060A254C:
    st32(c.r[7] + 4, c.r[6]);  // 060A254C mov.l r6,@(4,r7)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A254E dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A2550 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A252C; } }  // 060A2552 bf/s 0x060A252C ; add #8,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A2556 rts ; nop
L_060A255C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A255C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A255E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2560 tst r11,r11
    if (c.t) { goto L_060A256C; }  // 060A2562 bt 0x060A256C
    c.r[11] <<= 2;  // 060A2564 shll2 r11
    c.r[11] <<= 2;  // 060A2566 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2538;  // 060A2568 bra 0x060A2538 ; add r12,r11
L_060A256C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A256C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A256E sub r5,r6
    c.r[11] <<= 2;  // 060A2570 shll2 r11
    c.r[11] <<= 2;  // 060A2572 shll2 r11
    c.r[11] += c.r[12];  // 060A2574 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2576 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2578 shar r0
    c.r[5] += c.r[0];  // 060A257A add r0,r5
    c.r[0] <<= 2;  // 060A257C shll2 r0
    c.r[5] += c.r[0];  // 060A257E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2538; } }  // 060A2580 bf/s 0x060A2538 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2584 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2586 shll2 r11
    c.r[11] <<= 2;  // 060A2588 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2538;  // 060A258A bra 0x060A2538 ; add r12,r11
L_060A2590:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2590 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2592 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2594 tst r11,r11
    if (c.t) { goto L_060A25A0; }  // 060A2596 bt 0x060A25A0
    c.r[11] <<= 2;  // 060A2598 shll2 r11
    c.r[11] <<= 2;  // 060A259A shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A254C;  // 060A259C bra 0x060A254C ; add r12,r11
L_060A25A0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A25A0 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A25A2 sub r5,r6
    c.r[11] <<= 2;  // 060A25A4 shll2 r11
    c.r[11] <<= 2;  // 060A25A6 shll2 r11
    c.r[11] += c.r[12];  // 060A25A8 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A25AA mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A25AC shar r0
    c.r[5] += c.r[0];  // 060A25AE add r0,r5
    c.r[0] <<= 2;  // 060A25B0 shll2 r0
    c.r[5] += c.r[0];  // 060A25B2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A254C; } }  // 060A25B4 bf/s 0x060A254C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A25B8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A25BA shll2 r11
    c.r[11] <<= 2;  // 060A25BC shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A254C;  // 060A25BE bra 0x060A254C ; add r12,r11
}

void f_060A25DC(SH2Context& c) {
    ran[2627] = 1;
    goto L_060A25DC;
L_060A25C8:
    { const uint32_t x = c.pr; c.r[6] = c.r[7]; c.pc = x; return; }  // 060A25C8 rts ; mov r7,r6
L_060A25CC:
    { const uint32_t x = c.pr; c.r[6] = c.r[6]; c.pc = x; return; }  // 060A25CC rts ; mov r6,r6
L_060A25D0:
    c.r[6] = c.r[7] << 16 | c.r[6] >> 16;  // 060A25D0 xtrct r7,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A25D2 rts ; swap.w r6,r6
L_060A25D6:
    c.r[7] = c.r[6] << 16 | c.r[7] >> 16;  // 060A25D6 xtrct r6,r7
    { const uint32_t x = c.pr; c.r[6] = c.r[7] << 16 | c.r[7] >> 16; c.pc = x; return; }  // 060A25D8 rts ; swap.w r7,r6
L_060A25DC:
    c.r[1] += 4;  // 060A25DC add #4,r1
    c.r[7] <<= 2;  // 060A25DE shll2 r7
    c.r[2] = 0x0u;  // 060A25E0 mov #0,r2
    c.r[0] = 0x060A25F0u;  // 060A25E2 mova 0x060A25F0,r0
    c.r[10] = ld32(c.r[0] + c.r[7]);  // 060A25E4 mov.l @(r0,r7),r10
    { const uint32_t x = c.r[10]; c.r[7] = c.r[2]; SH2_POLL(c); switch (x) { case 0x060A25C8u: goto L_060A25C8; case 0x060A25D6u: goto L_060A25D6; case 0x060A25D0u: goto L_060A25D0; case 0x060A25CCu: goto L_060A25CC; default: sh2_call(c, x); return; } }  // 060A25E6 jmp @r10 ; mov r2,r7
}

void f_060A27AC(SH2Context& c) {
    ran[2628] = 1;
    goto L_060A27AC;
L_060A2654:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2654 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2656 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2658 tst r11,r11
    if (c.t) { goto L_060A2664; }  // 060A265A bt 0x060A2664
    c.r[11] <<= 2;  // 060A265C shll2 r11
    c.r[11] <<= 2;  // 060A265E shll2 r11
    c.r[11] += c.r[12]; goto L_060A2714;  // 060A2660 bra 0x060A2714 ; add r12,r11
L_060A2664:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2664 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2666 sub r5,r6
    c.r[11] <<= 2;  // 060A2668 shll2 r11
    c.r[11] <<= 2;  // 060A266A shll2 r11
    c.r[11] += c.r[12];  // 060A266C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A266E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2670 shar r0
    c.r[5] += c.r[0];  // 060A2672 add r0,r5
    c.r[0] <<= 2;  // 060A2674 shll2 r0
    c.r[5] += c.r[0];  // 060A2676 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2714; } }  // 060A2678 bf/s 0x060A2714 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A267C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A267E shll2 r11
    c.r[11] <<= 2;  // 060A2680 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2714;  // 060A2682 bra 0x060A2714 ; add r12,r11
L_060A2688:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2688 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A268A add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A268C tst r11,r11
    if (c.t) { goto L_060A2698; }  // 060A268E bt 0x060A2698
    c.r[11] <<= 2;  // 060A2690 shll2 r11
    c.r[11] <<= 2;  // 060A2692 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2738;  // 060A2694 bra 0x060A2738 ; add r12,r11
L_060A2698:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2698 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A269A sub r5,r6
    c.r[11] <<= 2;  // 060A269C shll2 r11
    c.r[11] <<= 2;  // 060A269E shll2 r11
    c.r[11] += c.r[12];  // 060A26A0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A26A2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A26A4 shar r0
    c.r[5] += c.r[0];  // 060A26A6 add r0,r5
    c.r[0] <<= 2;  // 060A26A8 shll2 r0
    c.r[5] += c.r[0];  // 060A26AA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2738; } }  // 060A26AC bf/s 0x060A2738 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A26B0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A26B2 shll2 r11
    c.r[11] <<= 2;  // 060A26B4 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2738;  // 060A26B6 bra 0x060A2738 ; add r12,r11
L_060A26BC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A26BC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A26BE shll2 r11
    c.r[11] <<= 2;  // 060A26C0 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2720;  // 060A26C2 bra 0x060A2720 ; add r12,r11
L_060A26C8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A26C8 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A26CA tst r11,r11
    if (c.t) { goto L_060A26D8; }  // 060A26CC bt 0x060A26D8
    c.r[11] <<= 2;  // 060A26CE shll2 r11
    c.r[11] <<= 2;  // 060A26D0 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2708;  // 060A26D2 bra 0x060A2708 ; add r12,r11
L_060A26D8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A26D8 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A26DA mov r3,r0
    c.r[11] <<= 2;  // 060A26DC shll2 r11
    c.r[11] <<= 2;  // 060A26DE shll2 r11
    c.r[11] += c.r[12];  // 060A26E0 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A26E2 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A26E4 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A26E6 shar r0
    c.r[5] += c.r[0];  // 060A26E8 add r0,r5
    c.r[0] <<= 2;  // 060A26EA shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2708; } }  // 060A26EC bf/s 0x060A2708 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A26F0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A26F2 shll2 r11
    c.r[11] <<= 2;  // 060A26F4 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2708;  // 060A26F6 bra 0x060A2708 ; add r12,r11
L_060A26FC:
    c.r[0] = c.r[3];  // 060A26FC mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A26FE mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2700 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A26C8; } }  // 060A2702 bt/s 0x060A26C8 ; add r0,r5
    c.r[11] += 4;  // 060A2706 add #4,r11
L_060A2708:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2708 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A270A mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A270C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2654; } }  // 060A270E bt/s 0x060A2654 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2712 add r5,r6
L_060A2714:
    st32(c.r[4], c.r[6]);  // 060A2714 mov.l r6,@r4
    c.r[0] = ld32(0x060A2A8Cu);  // 060A2716 mov.l 0x060A2A8C,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A2718 mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A271A shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_060A26BC; } }  // 060A271C bt/s 0x060A26BC ; add #4,r11
L_060A2720:
    c.r[0] = ld32(0x060A2764u);  // 060A2720 mov.l 0x060A2764,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A2726u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A2726u) return; }  // 060A2722 jsr @r0 ; add #4,r4
    ;  // 060A2726 nop
    st32(c.r[13], c.r[6]);  // 060A2728 mov.l r6,@r13
    c.r[13] += 4;  // 060A272A add #4,r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A272C mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A272E mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2730 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2688; } }  // 060A2732 bt/s 0x060A2688 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2736 add r5,r6
L_060A2738:
    st32(c.r[4], c.r[6]);  // 060A2738 mov.l r6,@r4
    c.r[0] = ld32(0x060A2A8Cu);  // 060A273A mov.l 0x060A2A8C,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A273C mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A273E shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { goto L_060A276C; } }  // 060A2740 bt/s 0x060A276C ; add #4,r11
L_060A2744:
    c.r[0] = ld32(0x060A2764u);  // 060A2744 mov.l 0x060A2764,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A274Au; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A274Au) return; }  // 060A2746 jsr @r0 ; add #4,r4
    ;  // 060A274A nop
    st32(c.r[13], c.r[6]);  // 060A274C mov.l r6,@r13
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A274E dt r8
    { const bool k = !c.t; c.r[13] += 4; if (k) { goto L_060A2818; } }  // 060A2750 bf/s 0x060A2818 ; add #4,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A2754 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A2756 tst r9,r9
    if (!c.t) { goto L_060A27B0; }  // 060A2758 bf 0x060A27B0
    c.r[2] = ld32(c.r[15] + 36);  // 060A275A mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A275C lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A275E rts ; nop
L_060A2768:
    SH2_POLL(c); goto L_060A26FC;  // 060A2768 bra 0x060A26FC ; nop
L_060A276C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A276C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A276E shll2 r11
    c.r[11] <<= 2;  // 060A2770 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2744;  // 060A2772 bra 0x060A2744 ; add r12,r11
L_060A2778:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2778 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A277A tst r11,r11
    if (c.t) { goto L_060A2788; }  // 060A277C bt 0x060A2788
    c.r[11] <<= 2;  // 060A277E shll2 r11
    c.r[11] <<= 2;  // 060A2780 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2848;  // 060A2782 bra 0x060A2848 ; add r12,r11
L_060A2788:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2788 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A278A mov r3,r0
    c.r[11] <<= 2;  // 060A278C shll2 r11
    c.r[11] <<= 2;  // 060A278E shll2 r11
    c.r[11] += c.r[12];  // 060A2790 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2792 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A2794 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2796 shar r0
    c.r[5] += c.r[0];  // 060A2798 add r0,r5
    c.r[0] <<= 2;  // 060A279A shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2848; } }  // 060A279C bf/s 0x060A2848 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A27A0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A27A2 shll2 r11
    c.r[11] <<= 2;  // 060A27A4 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2848;  // 060A27A6 bra 0x060A2848 ; add r12,r11
L_060A27AC:
    c.r[0] = c.pr;  // 060A27AC sts pr,r0
    st32(c.r[15] + 36, c.r[0]);  // 060A27AE mov.l r0,@(36,r15)
L_060A27B0:
    c.r[0] = ld32(c.r[15] + 32);  // 060A27B0 mov.l @(32,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A27B2 cmp/eq #1,r0
    if (!c.t) { goto L_060A27D8; }  // 060A27B4 bf 0x060A27D8
    ;  // 060A27B6 nop
    c.r[0] = ld32(c.r[15] + 16);  // 060A27B8 mov.l @(16,r15),r0
    c.r[8] = 0x10u;  // 060A27BA mov #16,r8
    c.r[2] = c.gbr;  // 060A27BC stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A27BE cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A27C0 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A27C8; } }  // 060A27C2 bf/s 0x060A27C8 ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A27C6 mov r0,r8
L_060A27C8:
    c.r[0] -= c.r[8];  // 060A27C8 sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A27CA mov.l r0,@(16,r15)
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A27CC shlr r9
    { const bool k = c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { goto L_060A283C; } }  // 060A27CE bt/s 0x060A283C ; shlr r9
    if (c.t) { SH2_POLL(c); goto L_060A26FC; }  // 060A27D2 bt 0x060A26FC
    goto L_060A2820;  // 060A27D4 bra 0x060A2820 ; nop
L_060A27D8:
    c.r[9] = ld32(c.r[15] + 16);  // 060A27D8 mov.l @(16,r15),r9
    c.r[8] = 0x10u;  // 060A27DA mov #16,r8
    c.t = c.r[8] >= c.r[9];  // 060A27DC cmp/hs r9,r8
    { const bool k = !c.t; c.r[2] = ld32(c.r[15] + 12); if (k) { goto L_060A27E4; } }  // 060A27DE bf/s 0x060A27E4 ; mov.l @(12,r15),r2
    c.r[8] = c.r[9];  // 060A27E2 mov r9,r8
L_060A27E4:
    c.r[9] -= c.r[8];  // 060A27E4 sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A27E6 mov.l r9,@(16,r15)
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A27E8 mov.b @r2,r9
    c.r[9] = c.r[9] & 0xFFu;  // 060A27EA extu.b r9,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A27EC mov.b @(1,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 060A27EE extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A27F0 mov.b @(2,r2),r0
    c.r[6] <<= 8;  // 060A27F2 shll8 r6
    c.r[9] += c.r[6];  // 060A27F4 add r6,r9
    c.r[6] = c.r[0] & 0xFFu;  // 060A27F6 extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A27F8 mov.b @(3,r2),r0
    c.r[6] <<= 16;  // 060A27FA shll16 r6
    c.r[9] += c.r[6];  // 060A27FC add r6,r9
    c.r[0] <<= 8;  // 060A27FE shll8 r0
    c.r[0] <<= 16;  // 060A2800 shll16 r0
    c.r[9] += c.r[0];  // 060A2802 add r0,r9
    c.r[0] = c.r[8];  // 060A2804 mov r8,r0
    c.r[0] += 3;  // 060A2806 add #3,r0
    c.r[0] >>= 2;  // 060A2808 shlr2 r0
    ;  // 060A280A nop
    c.r[2] += c.r[0];  // 060A280C add r0,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A280E mov.l r2,@(12,r15)
    c.r[2] = c.gbr;  // 060A2810 stc gbr,r2
    st32(c.r[2], c.r[9]);  // 060A2812 mov.l r9,@r2
    c.r[2] += 4;  // 060A2814 add #4,r2
    c.gbr = c.r[2];  // 060A2816 ldc r2,gbr
L_060A2818:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2818 shlr r9
    { const bool k = c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { goto L_060A283C; } }  // 060A281A bt/s 0x060A283C ; shlr r9
L_060A281E:
    if (c.t) { SH2_POLL(c); goto L_060A2768; }  // 060A281E bt 0x060A2768
L_060A2820:
    c.r[5] = 0x0u;  // 060A2820 mov #0,r5
    c.r[4] += 8;  // 060A2822 add #8,r4
    c.r[1] += 8;  // 060A2824 add #8,r1
    ;  // 060A2826 nop
    st32(c.r[13], c.r[5]);  // 060A2828 mov.l r5,@r13
    ;  // 060A282A nop
    st32(c.r[13] + 4, c.r[0]);  // 060A282C mov.l r0,@(4,r13)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A282E dt r8
    { const bool k = c.t; c.r[13] += 8; if (k) { goto L_060A2876; } }  // 060A2830 bt/s 0x060A2876 ; add #8,r13
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2834 shlr r9
    { const bool k = !c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { SH2_POLL(c); goto L_060A281E; } }  // 060A2836 bf/s 0x060A281E ; shlr r9
    ;  // 060A283A nop
L_060A283C:
    c.r[0] = c.r[3];  // 060A283C mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A283E mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2840 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2778; } }  // 060A2842 bt/s 0x060A2778 ; add r0,r5
    c.r[11] += 4;  // 060A2846 add #4,r11
L_060A2848:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2848 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A284A mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A284C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2884; } }  // 060A284E bt/s 0x060A2884 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2852 add r5,r6
L_060A2854:
    st32(c.r[4], c.r[6]);  // 060A2854 mov.l r6,@r4
    ;  // 060A2856 nop
    c.r[1] += 4;  // 060A2858 add #4,r1
    st32(c.r[13], c.r[6]);  // 060A285A mov.l r6,@r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A285C mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A285E shar r0
    c.r[6] = ld32(c.r[4] + 4);  // 060A2860 mov.l @(4,r4),r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A28B8; } }  // 060A2862 bt/s 0x060A28B8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2866 add r5,r6
L_060A2868:
    st32(c.r[4] + 4, c.r[6]);  // 060A2868 mov.l r6,@(4,r4)
    c.r[1] += 4;  // 060A286A add #4,r1
    c.r[4] += 8;  // 060A286C add #8,r4
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A286E dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A2870 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A2818; } }  // 060A2872 bf/s 0x060A2818 ; add #8,r13
L_060A2876:
    c.r[9] = ld32(c.r[15] + 16);  // 060A2876 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A2878 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A27B0; }  // 060A287A bf 0x060A27B0
    c.r[2] = ld32(c.r[15] + 36);  // 060A287C mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A287E lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A2880 rts ; nop
L_060A2884:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2884 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2886 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2888 tst r11,r11
    if (c.t) { goto L_060A2894; }  // 060A288A bt 0x060A2894
    c.r[11] <<= 2;  // 060A288C shll2 r11
    c.r[11] <<= 2;  // 060A288E shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2854;  // 060A2890 bra 0x060A2854 ; add r12,r11
L_060A2894:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2894 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2896 sub r5,r6
    c.r[11] <<= 2;  // 060A2898 shll2 r11
    c.r[11] <<= 2;  // 060A289A shll2 r11
    c.r[11] += c.r[12];  // 060A289C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A289E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A28A0 shar r0
    c.r[5] += c.r[0];  // 060A28A2 add r0,r5
    c.r[0] <<= 2;  // 060A28A4 shll2 r0
    c.r[5] += c.r[0];  // 060A28A6 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2854; } }  // 060A28A8 bf/s 0x060A2854 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A28AC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A28AE shll2 r11
    c.r[11] <<= 2;  // 060A28B0 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2854;  // 060A28B2 bra 0x060A2854 ; add r12,r11
L_060A28B8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A28B8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A28BA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A28BC tst r11,r11
    if (c.t) { goto L_060A28C8; }  // 060A28BE bt 0x060A28C8
    c.r[11] <<= 2;  // 060A28C0 shll2 r11
    c.r[11] <<= 2;  // 060A28C2 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2868;  // 060A28C4 bra 0x060A2868 ; add r12,r11
L_060A28C8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A28C8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A28CA sub r5,r6
    c.r[11] <<= 2;  // 060A28CC shll2 r11
    c.r[11] <<= 2;  // 060A28CE shll2 r11
    c.r[11] += c.r[12];  // 060A28D0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A28D2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A28D4 shar r0
    c.r[5] += c.r[0];  // 060A28D6 add r0,r5
    c.r[0] <<= 2;  // 060A28D8 shll2 r0
    c.r[5] += c.r[0];  // 060A28DA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2868; } }  // 060A28DC bf/s 0x060A2868 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A28E0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A28E2 shll2 r11
    c.r[11] <<= 2;  // 060A28E4 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2868;  // 060A28E6 bra 0x060A2868 ; add r12,r11
}

void f_060A2A08(SH2Context& c) {
    ran[2629] = 1;
    goto L_060A2A08;
L_060A28F0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A28F0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A28F2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A28F4 tst r11,r11
    if (c.t) { goto L_060A2900; }  // 060A28F6 bt 0x060A2900
    c.r[11] <<= 2;  // 060A28F8 shll2 r11
    c.r[11] <<= 2;  // 060A28FA shll2 r11
    c.r[11] += c.r[12]; goto L_060A297C;  // 060A28FC bra 0x060A297C ; add r12,r11
L_060A2900:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2900 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2902 sub r5,r6
    c.r[11] <<= 2;  // 060A2904 shll2 r11
    c.r[11] <<= 2;  // 060A2906 shll2 r11
    c.r[11] += c.r[12];  // 060A2908 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A290A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A290C shar r0
    c.r[5] += c.r[0];  // 060A290E add r0,r5
    c.r[0] <<= 2;  // 060A2910 shll2 r0
    c.r[5] += c.r[0];  // 060A2912 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A297C; } }  // 060A2914 bf/s 0x060A297C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2918 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A291A shll2 r11
    c.r[11] <<= 2;  // 060A291C shll2 r11
    c.r[11] += c.r[12]; goto L_060A297C;  // 060A291E bra 0x060A297C ; add r12,r11
L_060A2924:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2924 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2926 shll2 r11
    c.r[11] <<= 2;  // 060A2928 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2988;  // 060A292A bra 0x060A2988 ; add r12,r11
L_060A2930:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2930 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2932 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2934 tst r11,r11
    if (c.t) { goto L_060A2940; }  // 060A2936 bt 0x060A2940
    c.r[11] <<= 2;  // 060A2938 shll2 r11
    c.r[11] <<= 2;  // 060A293A shll2 r11
    c.r[11] += c.r[12]; goto L_060A29A0;  // 060A293C bra 0x060A29A0 ; add r12,r11
L_060A2940:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2940 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2942 sub r5,r6
    c.r[11] <<= 2;  // 060A2944 shll2 r11
    c.r[11] <<= 2;  // 060A2946 shll2 r11
    c.r[11] += c.r[12];  // 060A2948 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A294A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A294C shar r0
    c.r[5] += c.r[0];  // 060A294E add r0,r5
    c.r[0] <<= 2;  // 060A2950 shll2 r0
    c.r[5] += c.r[0];  // 060A2952 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A29A0; } }  // 060A2954 bf/s 0x060A29A0 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2958 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A295A shll2 r11
    c.r[11] <<= 2;  // 060A295C shll2 r11
    c.r[11] += c.r[12]; goto L_060A29A0;  // 060A295E bra 0x060A29A0 ; add r12,r11
L_060A2964:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2964 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2966 shll2 r11
    c.r[11] <<= 2;  // 060A2968 shll2 r11
    c.r[11] += c.r[12]; goto L_060A29AC;  // 060A296A bra 0x060A29AC ; add r12,r11
L_060A2970:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2970 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A2972 mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2974 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A28F0; } }  // 060A2976 bt/s 0x060A28F0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A297A add r5,r6
L_060A297C:
    st32(c.r[4], c.r[6]);  // 060A297C mov.l r6,@r4
    c.r[0] = ld32(0x060A2A8Cu);  // 060A297E mov.l 0x060A2A8C,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A2980 mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A2982 shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_060A2924; } }  // 060A2984 bt/s 0x060A2924 ; add #4,r11
L_060A2988:
    c.r[0] = ld32(0x060A29CCu);  // 060A2988 mov.l 0x060A29CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A298Eu; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A298Eu) return; }  // 060A298A jsr @r0 ; add #4,r4
    ;  // 060A298E nop
    st32(c.r[13], c.r[6]);  // 060A2990 mov.l r6,@r13
    c.r[13] += 4;  // 060A2992 add #4,r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2994 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A2996 mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2998 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2930; } }  // 060A299A bt/s 0x060A2930 ; add r0,r5
    c.r[6] += c.r[5];  // 060A299E add r5,r6
L_060A29A0:
    st32(c.r[4], c.r[6]);  // 060A29A0 mov.l r6,@r4
    c.r[0] = ld32(0x060A2A8Cu);  // 060A29A2 mov.l 0x060A2A8C,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A29A4 mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A29A6 shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_060A2964; } }  // 060A29A8 bt/s 0x060A2964 ; add #4,r11
L_060A29AC:
    c.r[0] = ld32(0x060A29CCu);  // 060A29AC mov.l 0x060A29CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A29B2u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A29B2u) return; }  // 060A29AE jsr @r0 ; add #4,r4
    ;  // 060A29B2 nop
    st32(c.r[13], c.r[6]);  // 060A29B4 mov.l r6,@r13
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A29B6 dt r8
    { const bool k = !c.t; c.r[13] += 4; if (k) { goto L_060A2A20; } }  // 060A29B8 bf/s 0x060A2A20 ; add #4,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A29BC mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A29BE tst r9,r9
    if (!c.t) { goto L_060A2A0C; }  // 060A29C0 bf 0x060A2A0C
    c.r[2] = ld32(c.r[15] + 36);  // 060A29C2 mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A29C4 lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A29C6 rts ; nop
L_060A29D0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A29D0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A29D2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A29D4 tst r11,r11
    if (c.t) { goto L_060A29E0; }  // 060A29D6 bt 0x060A29E0
    c.r[11] <<= 2;  // 060A29D8 shll2 r11
    c.r[11] <<= 2;  // 060A29DA shll2 r11
    c.r[11] += c.r[12]; goto L_060A2A58;  // 060A29DC bra 0x060A2A58 ; add r12,r11
L_060A29E0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A29E0 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A29E2 sub r5,r6
    c.r[11] <<= 2;  // 060A29E4 shll2 r11
    c.r[11] <<= 2;  // 060A29E6 shll2 r11
    c.r[11] += c.r[12];  // 060A29E8 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A29EA mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A29EC shar r0
    c.r[5] += c.r[0];  // 060A29EE add r0,r5
    c.r[0] <<= 2;  // 060A29F0 shll2 r0
    c.r[5] += c.r[0];  // 060A29F2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2A58; } }  // 060A29F4 bf/s 0x060A2A58 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A29F8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A29FA shll2 r11
    c.r[11] <<= 2;  // 060A29FC shll2 r11
    c.r[11] += c.r[12]; goto L_060A2A58;  // 060A29FE bra 0x060A2A58 ; add r12,r11
L_060A2A04:
    SH2_POLL(c); goto L_060A2970;  // 060A2A04 bra 0x060A2970 ; nop
L_060A2A08:
    c.r[0] = c.pr;  // 060A2A08 sts pr,r0
    st32(c.r[15] + 36, c.r[0]);  // 060A2A0A mov.l r0,@(36,r15)
L_060A2A0C:
    c.r[0] = ld32(c.r[15] + 16);  // 060A2A0C mov.l @(16,r15),r0
    c.r[8] = 0x10u;  // 060A2A0E mov #16,r8
    c.r[2] = c.gbr;  // 060A2A10 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A2A12 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A2A14 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A2A1C; } }  // 060A2A16 bf/s 0x060A2A1C ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A2A1A mov r0,r8
L_060A2A1C:
    c.r[0] -= c.r[8];  // 060A2A1C sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A2A1E mov.l r0,@(16,r15)
L_060A2A20:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2A20 shlr r9
    { const bool k = c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { goto L_060A2A4C; } }  // 060A2A22 bt/s 0x060A2A4C ; shlr r9
L_060A2A26:
    if (c.t) { SH2_POLL(c); goto L_060A2A04; }  // 060A2A26 bt 0x060A2A04
    c.r[5] = 0x0u;  // 060A2A28 mov #0,r5
    ;  // 060A2A2A nop
    st32(c.r[13], c.r[5]);  // 060A2A2C mov.l r5,@r13
    ;  // 060A2A2E nop
    st32(c.r[13] + 4, c.r[5]);  // 060A2A30 mov.l r5,@(4,r13)
    ;  // 060A2A32 nop
    c.r[2] = ld32(0x060A2A90u);  // 060A2A34 mov.l 0x060A2A90,r2
    c.r[1] += 8;  // 060A2A36 add #8,r1
    st32(c.r[4], c.r[2]);  // 060A2A38 mov.l r2,@r4
    c.r[13] += 8;  // 060A2A3A add #8,r13
    st32(c.r[4] + 4, c.r[2]);  // 060A2A3C mov.l r2,@(4,r4)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A2A3E dt r8
    { const bool k = c.t; c.r[4] += 8; if (k) { goto L_060A2A7A; } }  // 060A2A40 bt/s 0x060A2A7A ; add #8,r4
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2A44 shlr r9
    { const bool k = !c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { SH2_POLL(c); goto L_060A2A26; } }  // 060A2A46 bf/s 0x060A2A26 ; shlr r9
    ;  // 060A2A4A nop
L_060A2A4C:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2A4C mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A2A4E mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2A50 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A29D0; } }  // 060A2A52 bt/s 0x060A29D0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2A56 add r5,r6
L_060A2A58:
    st32(c.r[4], c.r[6]);  // 060A2A58 mov.l r6,@r4
    ;  // 060A2A5A nop
    c.r[1] += 4;  // 060A2A5C add #4,r1
    st32(c.r[13], c.r[6]);  // 060A2A5E mov.l r6,@r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2A60 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2A62 shar r0
    c.r[6] = ld32(c.r[4] + 4);  // 060A2A64 mov.l @(4,r4),r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2A94; } }  // 060A2A66 bt/s 0x060A2A94 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2A6A add r5,r6
L_060A2A6C:
    st32(c.r[4] + 4, c.r[6]);  // 060A2A6C mov.l r6,@(4,r4)
    c.r[1] += 4;  // 060A2A6E add #4,r1
    c.r[4] += 8;  // 060A2A70 add #8,r4
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A2A72 dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A2A74 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A2A20; } }  // 060A2A76 bf/s 0x060A2A20 ; add #8,r13
L_060A2A7A:
    c.r[9] = ld32(c.r[15] + 16);  // 060A2A7A mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A2A7C tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A2A0C; }  // 060A2A7E bf 0x060A2A0C
    c.r[2] = ld32(c.r[15] + 36);  // 060A2A80 mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A2A82 lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A2A84 rts ; nop
L_060A2A94:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2A94 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2A96 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2A98 tst r11,r11
    if (c.t) { goto L_060A2AA4; }  // 060A2A9A bt 0x060A2AA4
    c.r[11] <<= 2;  // 060A2A9C shll2 r11
    c.r[11] <<= 2;  // 060A2A9E shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2A6C;  // 060A2AA0 bra 0x060A2A6C ; add r12,r11
L_060A2AA4:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2AA4 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2AA6 sub r5,r6
    c.r[11] <<= 2;  // 060A2AA8 shll2 r11
    c.r[11] <<= 2;  // 060A2AAA shll2 r11
    c.r[11] += c.r[12];  // 060A2AAC add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2AAE mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2AB0 shar r0
    c.r[5] += c.r[0];  // 060A2AB2 add r0,r5
    c.r[0] <<= 2;  // 060A2AB4 shll2 r0
    c.r[5] += c.r[0];  // 060A2AB6 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2A6C; } }  // 060A2AB8 bf/s 0x060A2A6C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2ABC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2ABE shll2 r11
    c.r[11] <<= 2;  // 060A2AC0 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2A6C;  // 060A2AC2 bra 0x060A2A6C ; add r12,r11
}

void f_060A2AE0(SH2Context& c) {
    ran[2630] = 1;
    c.r[2] = c.r[7];  // 060A2AE0 mov r7,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2AE2 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2AE4 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2AE6 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2AE8 and r0,r6
    c.r[6] >>= 2;  // 060A2AEA shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2AEC mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2AEE and r7,r0
    c.r[0] >>= 2;  // 060A2AF0 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2AF2 sub r0,r7
    c.r[7] += c.r[6];  // 060A2AF4 add r6,r7
    c.r[7] = c.r[2] << 16 | c.r[7] >> 16;  // 060A2AF6 xtrct r2,r7
    { const uint32_t x = c.pr; c.r[6] = c.r[7] << 16 | c.r[7] >> 16; c.pc = x; return; }  // 060A2AF8 rts ; swap.w r7,r6
}

void f_060A2AFC(SH2Context& c) {
    ran[2631] = 1;
    c.r[2] = c.r[6];  // 060A2AFC mov r6,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2AFE mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2B00 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B02 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2B04 and r0,r6
    c.r[6] >>= 2;  // 060A2B06 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B08 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2B0A and r7,r0
    c.r[0] >>= 2;  // 060A2B0C shlr2 r0
    c.r[7] -= c.r[0];  // 060A2B0E sub r0,r7
    c.r[7] += c.r[6];  // 060A2B10 add r6,r7
    c.r[7] = c.r[2] << 16 | c.r[7] >> 16;  // 060A2B12 xtrct r2,r7
    { const uint32_t x = c.pr; c.r[6] = c.r[7] << 16 | c.r[7] >> 16; c.pc = x; return; }  // 060A2B14 rts ; swap.w r7,r6
}

void f_060A2B18(SH2Context& c) {
    ran[2632] = 1;
    c.r[2] = c.r[7];  // 060A2B18 mov r7,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2B1A mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2B1C add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B1E mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2B20 and r0,r6
    c.r[6] >>= 2;  // 060A2B22 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B24 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2B26 and r7,r0
    c.r[0] >>= 2;  // 060A2B28 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2B2A sub r0,r7
    c.r[7] += c.r[6];  // 060A2B2C add r6,r7
    c.r[2] = c.r[7] << 16 | c.r[2] >> 16;  // 060A2B2E xtrct r7,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2B30 rts ; swap.w r2,r6
}

void f_060A2B34(SH2Context& c) {
    ran[2633] = 1;
    c.r[2] = c.r[6];  // 060A2B34 mov r6,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2B36 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2B38 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B3A mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2B3C and r0,r6
    c.r[6] >>= 2;  // 060A2B3E shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B40 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2B42 and r7,r0
    c.r[0] >>= 2;  // 060A2B44 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2B46 sub r0,r7
    c.r[7] += c.r[6];  // 060A2B48 add r6,r7
    c.r[2] = c.r[7] << 16 | c.r[2] >> 16;  // 060A2B4A xtrct r7,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2B4C rts ; swap.w r2,r6
}

void f_060A2B50(SH2Context& c) {
    ran[2634] = 1;
    c.r[2] = c.r[6];  // 060A2B50 mov r6,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2B52 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2B54 and r6,r0
    c.r[0] >>= 2;  // 060A2B56 shlr2 r0
    c.r[6] -= c.r[0];  // 060A2B58 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2B5A mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2B5C add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2B5E mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2B60 and r0,r7
    c.r[7] >>= 2;  // 060A2B62 shlr2 r7
    c.r[6] += c.r[7];  // 060A2B64 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2B66 xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2B68 rts ; swap.w r6,r6
}

void f_060A2B6C(SH2Context& c) {
    ran[2635] = 1;
    c.r[2] = c.r[6];  // 060A2B6C mov r6,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2B6E mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2B70 and r6,r0
    c.r[0] >>= 2;  // 060A2B72 shlr2 r0
    c.r[6] -= c.r[0];  // 060A2B74 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2B76 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2B78 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2B7A mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2B7C and r0,r7
    c.r[7] >>= 2;  // 060A2B7E shlr2 r7
    c.r[6] += c.r[7];  // 060A2B80 add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2B82 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2B84 rts ; swap.w r2,r6
}

void f_060A2B88(SH2Context& c) {
    ran[2636] = 1;
    c.r[2] = c.r[7];  // 060A2B88 mov r7,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2B8A mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2B8C and r6,r0
    c.r[0] >>= 2;  // 060A2B8E shlr2 r0
    c.r[6] -= c.r[0];  // 060A2B90 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2B92 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2B94 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2B96 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2B98 and r0,r7
    c.r[7] >>= 2;  // 060A2B9A shlr2 r7
    c.r[6] += c.r[7];  // 060A2B9C add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2B9E xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2BA0 rts ; swap.w r2,r6
}

void f_060A2BA4(SH2Context& c) {
    ran[2637] = 1;
    c.r[2] = c.r[7];  // 060A2BA4 mov r7,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2BA6 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2BA8 and r6,r0
    c.r[0] >>= 2;  // 060A2BAA shlr2 r0
    c.r[6] -= c.r[0];  // 060A2BAC sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2BAE mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2BB0 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2BB2 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2BB4 and r0,r7
    c.r[7] >>= 2;  // 060A2BB6 shlr2 r7
    c.r[6] += c.r[7];  // 060A2BB8 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2BBA xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2BBC rts ; swap.w r6,r6
}

void f_060A2BC0(SH2Context& c) {
    ran[2638] = 1;
    c.r[0] = ld32(0x060A2D14u);  // 060A2BC0 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2BC2 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2BC4 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2BC6 and r0,r6
    c.r[6] >>= 2;  // 060A2BC8 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2BCA mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2BCC and r7,r0
    c.r[0] >>= 2;  // 060A2BCE shlr2 r0
    c.r[7] -= c.r[0];  // 060A2BD0 sub r0,r7
    { const uint32_t x = c.pr; c.r[6] += c.r[7]; c.pc = x; return; }  // 060A2BD2 rts ; add r7,r6
}

void f_060A2BD6(SH2Context& c) {
    ran[2639] = 1;
    c.r[0] = ld32(0x060A2D70u);  // 060A2BD6 mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2BD8 and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2BDA shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2BDC mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2BDE and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2BE0 shlr r7
    { const uint32_t x = c.pr; c.r[6] += c.r[7]; c.pc = x; return; }  // 060A2BE2 rts ; add r7,r6
}

void f_060A2BE6(SH2Context& c) {
    ran[2640] = 1;
    c.r[0] = ld32(0x060A2D10u);  // 060A2BE6 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2BE8 and r6,r0
    c.r[0] >>= 2;  // 060A2BEA shlr2 r0
    c.r[6] -= c.r[0];  // 060A2BEC sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2BEE mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2BF0 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2BF2 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2BF4 and r0,r7
    c.r[7] >>= 2;  // 060A2BF6 shlr2 r7
    { const uint32_t x = c.pr; c.r[6] += c.r[7]; c.pc = x; return; }  // 060A2BF8 rts ; add r7,r6
}

void f_060A2BFC(SH2Context& c) {
    ran[2641] = 1;
    c.r[2] = c.r[7];  // 060A2BFC mov r7,r2
    c.r[10] = c.r[6];  // 060A2BFE mov r6,r10
    c.r[0] = ld32(0x060A2D14u);  // 060A2C00 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2C02 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C04 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2C06 and r0,r6
    c.r[6] >>= 2;  // 060A2C08 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C0A mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2C0C and r7,r0
    c.r[0] >>= 2;  // 060A2C0E shlr2 r0
    c.r[7] -= c.r[0];  // 060A2C10 sub r0,r7
    c.r[6] += c.r[7];  // 060A2C12 add r7,r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2C14 mov.l 0x060A2D70,r0
    c.r[10] &= c.r[0];  // 060A2C16 and r0,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060A2C18 shlr r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2C1A mov.l 0x060A2D70,r0
    c.r[2] &= c.r[0];  // 060A2C1C and r0,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060A2C1E shlr r2
    c.r[2] += c.r[10];  // 060A2C20 add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2C22 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2C24 rts ; swap.w r2,r6
}

void f_060A2C28(SH2Context& c) {
    ran[2642] = 1;
    c.r[2] = c.r[7];  // 060A2C28 mov r7,r2
    c.r[10] = c.r[6];  // 060A2C2A mov r6,r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2C2C mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2C2E and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2C30 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2C32 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2C34 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2C36 shlr r7
    c.r[6] += c.r[7];  // 060A2C38 add r7,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2C3A mov.l 0x060A2D14,r0
    c.r[10] += c.r[0];  // 060A2C3C add r0,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2C3E mov.l 0x060A2D10,r0
    c.r[10] &= c.r[0];  // 060A2C40 and r0,r10
    c.r[10] >>= 2;  // 060A2C42 shlr2 r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2C44 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[2];  // 060A2C46 and r2,r0
    c.r[0] >>= 2;  // 060A2C48 shlr2 r0
    c.r[2] -= c.r[0];  // 060A2C4A sub r0,r2
    c.r[2] += c.r[10];  // 060A2C4C add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2C4E xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2C50 rts ; swap.w r2,r6
}

void f_060A2C54(SH2Context& c) {
    ran[2643] = 1;
    c.r[2] = c.r[7];  // 060A2C54 mov r7,r2
    c.r[10] = c.r[6];  // 060A2C56 mov r6,r10
    c.r[0] = ld32(0x060A2D14u);  // 060A2C58 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2C5A add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C5C mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2C5E and r0,r6
    c.r[6] >>= 2;  // 060A2C60 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C62 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2C64 and r7,r0
    c.r[0] >>= 2;  // 060A2C66 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2C68 sub r0,r7
    c.r[6] += c.r[7];  // 060A2C6A add r7,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2C6C mov.l 0x060A2D14,r0
    c.r[2] += c.r[0];  // 060A2C6E add r0,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2C70 mov.l 0x060A2D10,r0
    c.r[2] &= c.r[0];  // 060A2C72 and r0,r2
    c.r[2] >>= 2;  // 060A2C74 shlr2 r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2C76 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[10];  // 060A2C78 and r10,r0
    c.r[0] >>= 2;  // 060A2C7A shlr2 r0
    c.r[10] -= c.r[0];  // 060A2C7C sub r0,r10
    c.r[2] += c.r[10];  // 060A2C7E add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2C80 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2C82 rts ; swap.w r2,r6
}

void f_060A2C86(SH2Context& c) {
    ran[2644] = 1;
    c.r[2] = c.r[7];  // 060A2C86 mov r7,r2
    c.r[10] = c.r[6];  // 060A2C88 mov r6,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2C8A mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2C8C and r6,r0
    c.r[0] >>= 2;  // 060A2C8E shlr2 r0
    c.r[6] -= c.r[0];  // 060A2C90 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2C92 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2C94 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2C96 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2C98 and r0,r7
    c.r[7] >>= 2;  // 060A2C9A shlr2 r7
    c.r[6] += c.r[7];  // 060A2C9C add r7,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C9E mov.l 0x060A2D10,r0
    c.r[0] &= c.r[2];  // 060A2CA0 and r2,r0
    c.r[0] >>= 2;  // 060A2CA2 shlr2 r0
    c.r[2] -= c.r[0];  // 060A2CA4 sub r0,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2CA6 mov.l 0x060A2D14,r0
    c.r[10] += c.r[0];  // 060A2CA8 add r0,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2CAA mov.l 0x060A2D10,r0
    c.r[10] &= c.r[0];  // 060A2CAC and r0,r10
    c.r[10] >>= 2;  // 060A2CAE shlr2 r10
    c.r[2] += c.r[10];  // 060A2CB0 add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2CB2 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2CB4 rts ; swap.w r2,r6
}

void f_060A2CB8(SH2Context& c) {
    ran[2645] = 1;
    c.r[2] = c.r[7];  // 060A2CB8 mov r7,r2
    c.r[10] = c.r[6];  // 060A2CBA mov r6,r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2CBC mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2CBE and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2CC0 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2CC2 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2CC4 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2CC6 shlr r7
    c.r[6] += c.r[7];  // 060A2CC8 add r7,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2CCA mov.l 0x060A2D10,r0
    c.r[0] &= c.r[10];  // 060A2CCC and r10,r0
    c.r[0] >>= 2;  // 060A2CCE shlr2 r0
    c.r[10] -= c.r[0];  // 060A2CD0 sub r0,r10
    c.r[0] = ld32(0x060A2D14u);  // 060A2CD2 mov.l 0x060A2D14,r0
    c.r[2] += c.r[0];  // 060A2CD4 add r0,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2CD6 mov.l 0x060A2D10,r0
    c.r[2] &= c.r[0];  // 060A2CD8 and r0,r2
    c.r[2] >>= 2;  // 060A2CDA shlr2 r2
    c.r[2] += c.r[10];  // 060A2CDC add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2CDE xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2CE0 rts ; swap.w r2,r6
}

void f_060A2CE4(SH2Context& c) {
    ran[2646] = 1;
    c.r[2] = c.r[7];  // 060A2CE4 mov r7,r2
    c.r[10] = c.r[6];  // 060A2CE6 mov r6,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2CE8 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2CEA and r6,r0
    c.r[0] >>= 2;  // 060A2CEC shlr2 r0
    c.r[6] -= c.r[0];  // 060A2CEE sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2CF0 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2CF2 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2CF4 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2CF6 and r0,r7
    c.r[7] >>= 2;  // 060A2CF8 shlr2 r7
    c.r[6] += c.r[7];  // 060A2CFA add r7,r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2CFC mov.l 0x060A2D70,r0
    c.r[10] &= c.r[0];  // 060A2CFE and r0,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060A2D00 shlr r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2D02 mov.l 0x060A2D70,r0
    c.r[2] &= c.r[0];  // 060A2D04 and r0,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060A2D06 shlr r2
    c.r[2] += c.r[10];  // 060A2D08 add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2D0A xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2D0C rts ; swap.w r2,r6
}

void f_060A2D18(SH2Context& c) {
    ran[2647] = 1;
    c.r[7] = c.r[2];  // 060A2D18 mov r2,r7
    c.r[0] = ld32(0x060A2D70u);  // 060A2D1A mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D1C and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D1E shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D20 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D22 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D24 shlr r7
    c.r[6] += c.r[7];  // 060A2D26 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2D28 xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2D2A rts ; swap.w r6,r6
}

void f_060A2D2E(SH2Context& c) {
    ran[2648] = 1;
    c.r[2] = c.r[7];  // 060A2D2E mov r7,r2
    c.r[0] = ld32(0x060A2D70u);  // 060A2D30 mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D32 and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D34 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D36 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D38 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D3A shlr r7
    c.r[6] += c.r[7];  // 060A2D3C add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2D3E xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2D40 rts ; swap.w r2,r6
}

void f_060A2D44(SH2Context& c) {
    ran[2649] = 1;
    c.r[2] = c.r[6];  // 060A2D44 mov r6,r2
    c.r[0] = ld32(0x060A2D70u);  // 060A2D46 mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D48 and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D4A shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D4C mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D4E and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D50 shlr r7
    c.r[6] += c.r[7];  // 060A2D52 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2D54 xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2D56 rts ; swap.w r6,r6
}

void f_060A2D5A(SH2Context& c) {
    ran[2650] = 1;
    c.r[2] = c.r[6];  // 060A2D5A mov r6,r2
    c.r[0] = ld32(0x060A2D70u);  // 060A2D5C mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D5E and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D60 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D62 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D64 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D66 shlr r7
    c.r[6] += c.r[7];  // 060A2D68 add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2D6A xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2D6C rts ; swap.w r2,r6
}

void f_060A2D74(SH2Context& c) {
    ran[2651] = 1;
    goto L_060A2D74;
L_060A2ACC:
    { const uint32_t x = c.pr; c.r[6] = c.r[7]; c.pc = x; return; }  // 060A2ACC rts ; mov r7,r6
L_060A2AD0:
    { const uint32_t x = c.pr; c.r[6] = c.r[6]; c.pc = x; return; }  // 060A2AD0 rts ; mov r6,r6
L_060A2AD4:
    c.r[6] = c.r[7] << 16 | c.r[6] >> 16;  // 060A2AD4 xtrct r7,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2AD6 rts ; swap.w r6,r6
L_060A2ADA:
    c.r[7] = c.r[6] << 16 | c.r[7] >> 16;  // 060A2ADA xtrct r6,r7
    { const uint32_t x = c.pr; c.r[6] = c.r[7] << 16 | c.r[7] >> 16; c.pc = x; return; }  // 060A2ADC rts ; swap.w r7,r6
L_060A2AE0:
    c.r[2] = c.r[7];  // 060A2AE0 mov r7,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2AE2 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2AE4 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2AE6 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2AE8 and r0,r6
    c.r[6] >>= 2;  // 060A2AEA shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2AEC mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2AEE and r7,r0
    c.r[0] >>= 2;  // 060A2AF0 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2AF2 sub r0,r7
    c.r[7] += c.r[6];  // 060A2AF4 add r6,r7
    c.r[7] = c.r[2] << 16 | c.r[7] >> 16;  // 060A2AF6 xtrct r2,r7
    { const uint32_t x = c.pr; c.r[6] = c.r[7] << 16 | c.r[7] >> 16; c.pc = x; return; }  // 060A2AF8 rts ; swap.w r7,r6
L_060A2AFC:
    c.r[2] = c.r[6];  // 060A2AFC mov r6,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2AFE mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2B00 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B02 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2B04 and r0,r6
    c.r[6] >>= 2;  // 060A2B06 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B08 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2B0A and r7,r0
    c.r[0] >>= 2;  // 060A2B0C shlr2 r0
    c.r[7] -= c.r[0];  // 060A2B0E sub r0,r7
    c.r[7] += c.r[6];  // 060A2B10 add r6,r7
    c.r[7] = c.r[2] << 16 | c.r[7] >> 16;  // 060A2B12 xtrct r2,r7
    { const uint32_t x = c.pr; c.r[6] = c.r[7] << 16 | c.r[7] >> 16; c.pc = x; return; }  // 060A2B14 rts ; swap.w r7,r6
L_060A2B18:
    c.r[2] = c.r[7];  // 060A2B18 mov r7,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2B1A mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2B1C add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B1E mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2B20 and r0,r6
    c.r[6] >>= 2;  // 060A2B22 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B24 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2B26 and r7,r0
    c.r[0] >>= 2;  // 060A2B28 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2B2A sub r0,r7
    c.r[7] += c.r[6];  // 060A2B2C add r6,r7
    c.r[2] = c.r[7] << 16 | c.r[2] >> 16;  // 060A2B2E xtrct r7,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2B30 rts ; swap.w r2,r6
L_060A2B34:
    c.r[2] = c.r[6];  // 060A2B34 mov r6,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2B36 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2B38 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B3A mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2B3C and r0,r6
    c.r[6] >>= 2;  // 060A2B3E shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2B40 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2B42 and r7,r0
    c.r[0] >>= 2;  // 060A2B44 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2B46 sub r0,r7
    c.r[7] += c.r[6];  // 060A2B48 add r6,r7
    c.r[2] = c.r[7] << 16 | c.r[2] >> 16;  // 060A2B4A xtrct r7,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2B4C rts ; swap.w r2,r6
L_060A2B50:
    c.r[2] = c.r[6];  // 060A2B50 mov r6,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2B52 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2B54 and r6,r0
    c.r[0] >>= 2;  // 060A2B56 shlr2 r0
    c.r[6] -= c.r[0];  // 060A2B58 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2B5A mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2B5C add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2B5E mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2B60 and r0,r7
    c.r[7] >>= 2;  // 060A2B62 shlr2 r7
    c.r[6] += c.r[7];  // 060A2B64 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2B66 xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2B68 rts ; swap.w r6,r6
L_060A2B6C:
    c.r[2] = c.r[6];  // 060A2B6C mov r6,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2B6E mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2B70 and r6,r0
    c.r[0] >>= 2;  // 060A2B72 shlr2 r0
    c.r[6] -= c.r[0];  // 060A2B74 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2B76 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2B78 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2B7A mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2B7C and r0,r7
    c.r[7] >>= 2;  // 060A2B7E shlr2 r7
    c.r[6] += c.r[7];  // 060A2B80 add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2B82 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2B84 rts ; swap.w r2,r6
L_060A2B88:
    c.r[2] = c.r[7];  // 060A2B88 mov r7,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2B8A mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2B8C and r6,r0
    c.r[0] >>= 2;  // 060A2B8E shlr2 r0
    c.r[6] -= c.r[0];  // 060A2B90 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2B92 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2B94 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2B96 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2B98 and r0,r7
    c.r[7] >>= 2;  // 060A2B9A shlr2 r7
    c.r[6] += c.r[7];  // 060A2B9C add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2B9E xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2BA0 rts ; swap.w r2,r6
L_060A2BA4:
    c.r[2] = c.r[7];  // 060A2BA4 mov r7,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2BA6 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2BA8 and r6,r0
    c.r[0] >>= 2;  // 060A2BAA shlr2 r0
    c.r[6] -= c.r[0];  // 060A2BAC sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2BAE mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2BB0 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2BB2 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2BB4 and r0,r7
    c.r[7] >>= 2;  // 060A2BB6 shlr2 r7
    c.r[6] += c.r[7];  // 060A2BB8 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2BBA xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2BBC rts ; swap.w r6,r6
L_060A2BC0:
    c.r[0] = ld32(0x060A2D14u);  // 060A2BC0 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2BC2 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2BC4 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2BC6 and r0,r6
    c.r[6] >>= 2;  // 060A2BC8 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2BCA mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2BCC and r7,r0
    c.r[0] >>= 2;  // 060A2BCE shlr2 r0
    c.r[7] -= c.r[0];  // 060A2BD0 sub r0,r7
    { const uint32_t x = c.pr; c.r[6] += c.r[7]; c.pc = x; return; }  // 060A2BD2 rts ; add r7,r6
L_060A2BD6:
    c.r[0] = ld32(0x060A2D70u);  // 060A2BD6 mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2BD8 and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2BDA shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2BDC mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2BDE and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2BE0 shlr r7
    { const uint32_t x = c.pr; c.r[6] += c.r[7]; c.pc = x; return; }  // 060A2BE2 rts ; add r7,r6
L_060A2BE6:
    c.r[0] = ld32(0x060A2D10u);  // 060A2BE6 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2BE8 and r6,r0
    c.r[0] >>= 2;  // 060A2BEA shlr2 r0
    c.r[6] -= c.r[0];  // 060A2BEC sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2BEE mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2BF0 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2BF2 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2BF4 and r0,r7
    c.r[7] >>= 2;  // 060A2BF6 shlr2 r7
    { const uint32_t x = c.pr; c.r[6] += c.r[7]; c.pc = x; return; }  // 060A2BF8 rts ; add r7,r6
L_060A2BFC:
    c.r[2] = c.r[7];  // 060A2BFC mov r7,r2
    c.r[10] = c.r[6];  // 060A2BFE mov r6,r10
    c.r[0] = ld32(0x060A2D14u);  // 060A2C00 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2C02 add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C04 mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2C06 and r0,r6
    c.r[6] >>= 2;  // 060A2C08 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C0A mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2C0C and r7,r0
    c.r[0] >>= 2;  // 060A2C0E shlr2 r0
    c.r[7] -= c.r[0];  // 060A2C10 sub r0,r7
    c.r[6] += c.r[7];  // 060A2C12 add r7,r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2C14 mov.l 0x060A2D70,r0
    c.r[10] &= c.r[0];  // 060A2C16 and r0,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060A2C18 shlr r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2C1A mov.l 0x060A2D70,r0
    c.r[2] &= c.r[0];  // 060A2C1C and r0,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060A2C1E shlr r2
    c.r[2] += c.r[10];  // 060A2C20 add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2C22 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2C24 rts ; swap.w r2,r6
L_060A2C28:
    c.r[2] = c.r[7];  // 060A2C28 mov r7,r2
    c.r[10] = c.r[6];  // 060A2C2A mov r6,r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2C2C mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2C2E and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2C30 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2C32 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2C34 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2C36 shlr r7
    c.r[6] += c.r[7];  // 060A2C38 add r7,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2C3A mov.l 0x060A2D14,r0
    c.r[10] += c.r[0];  // 060A2C3C add r0,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2C3E mov.l 0x060A2D10,r0
    c.r[10] &= c.r[0];  // 060A2C40 and r0,r10
    c.r[10] >>= 2;  // 060A2C42 shlr2 r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2C44 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[2];  // 060A2C46 and r2,r0
    c.r[0] >>= 2;  // 060A2C48 shlr2 r0
    c.r[2] -= c.r[0];  // 060A2C4A sub r0,r2
    c.r[2] += c.r[10];  // 060A2C4C add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2C4E xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2C50 rts ; swap.w r2,r6
L_060A2C54:
    c.r[2] = c.r[7];  // 060A2C54 mov r7,r2
    c.r[10] = c.r[6];  // 060A2C56 mov r6,r10
    c.r[0] = ld32(0x060A2D14u);  // 060A2C58 mov.l 0x060A2D14,r0
    c.r[6] += c.r[0];  // 060A2C5A add r0,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C5C mov.l 0x060A2D10,r0
    c.r[6] &= c.r[0];  // 060A2C5E and r0,r6
    c.r[6] >>= 2;  // 060A2C60 shlr2 r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C62 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[7];  // 060A2C64 and r7,r0
    c.r[0] >>= 2;  // 060A2C66 shlr2 r0
    c.r[7] -= c.r[0];  // 060A2C68 sub r0,r7
    c.r[6] += c.r[7];  // 060A2C6A add r7,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2C6C mov.l 0x060A2D14,r0
    c.r[2] += c.r[0];  // 060A2C6E add r0,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2C70 mov.l 0x060A2D10,r0
    c.r[2] &= c.r[0];  // 060A2C72 and r0,r2
    c.r[2] >>= 2;  // 060A2C74 shlr2 r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2C76 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[10];  // 060A2C78 and r10,r0
    c.r[0] >>= 2;  // 060A2C7A shlr2 r0
    c.r[10] -= c.r[0];  // 060A2C7C sub r0,r10
    c.r[2] += c.r[10];  // 060A2C7E add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2C80 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2C82 rts ; swap.w r2,r6
L_060A2C86:
    c.r[2] = c.r[7];  // 060A2C86 mov r7,r2
    c.r[10] = c.r[6];  // 060A2C88 mov r6,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2C8A mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2C8C and r6,r0
    c.r[0] >>= 2;  // 060A2C8E shlr2 r0
    c.r[6] -= c.r[0];  // 060A2C90 sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2C92 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2C94 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2C96 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2C98 and r0,r7
    c.r[7] >>= 2;  // 060A2C9A shlr2 r7
    c.r[6] += c.r[7];  // 060A2C9C add r7,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2C9E mov.l 0x060A2D10,r0
    c.r[0] &= c.r[2];  // 060A2CA0 and r2,r0
    c.r[0] >>= 2;  // 060A2CA2 shlr2 r0
    c.r[2] -= c.r[0];  // 060A2CA4 sub r0,r2
    c.r[0] = ld32(0x060A2D14u);  // 060A2CA6 mov.l 0x060A2D14,r0
    c.r[10] += c.r[0];  // 060A2CA8 add r0,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2CAA mov.l 0x060A2D10,r0
    c.r[10] &= c.r[0];  // 060A2CAC and r0,r10
    c.r[10] >>= 2;  // 060A2CAE shlr2 r10
    c.r[2] += c.r[10];  // 060A2CB0 add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2CB2 xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2CB4 rts ; swap.w r2,r6
L_060A2CB8:
    c.r[2] = c.r[7];  // 060A2CB8 mov r7,r2
    c.r[10] = c.r[6];  // 060A2CBA mov r6,r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2CBC mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2CBE and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2CC0 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2CC2 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2CC4 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2CC6 shlr r7
    c.r[6] += c.r[7];  // 060A2CC8 add r7,r6
    c.r[0] = ld32(0x060A2D10u);  // 060A2CCA mov.l 0x060A2D10,r0
    c.r[0] &= c.r[10];  // 060A2CCC and r10,r0
    c.r[0] >>= 2;  // 060A2CCE shlr2 r0
    c.r[10] -= c.r[0];  // 060A2CD0 sub r0,r10
    c.r[0] = ld32(0x060A2D14u);  // 060A2CD2 mov.l 0x060A2D14,r0
    c.r[2] += c.r[0];  // 060A2CD4 add r0,r2
    c.r[0] = ld32(0x060A2D10u);  // 060A2CD6 mov.l 0x060A2D10,r0
    c.r[2] &= c.r[0];  // 060A2CD8 and r0,r2
    c.r[2] >>= 2;  // 060A2CDA shlr2 r2
    c.r[2] += c.r[10];  // 060A2CDC add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2CDE xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2CE0 rts ; swap.w r2,r6
L_060A2CE4:
    c.r[2] = c.r[7];  // 060A2CE4 mov r7,r2
    c.r[10] = c.r[6];  // 060A2CE6 mov r6,r10
    c.r[0] = ld32(0x060A2D10u);  // 060A2CE8 mov.l 0x060A2D10,r0
    c.r[0] &= c.r[6];  // 060A2CEA and r6,r0
    c.r[0] >>= 2;  // 060A2CEC shlr2 r0
    c.r[6] -= c.r[0];  // 060A2CEE sub r0,r6
    c.r[0] = ld32(0x060A2D14u);  // 060A2CF0 mov.l 0x060A2D14,r0
    c.r[7] += c.r[0];  // 060A2CF2 add r0,r7
    c.r[0] = ld32(0x060A2D10u);  // 060A2CF4 mov.l 0x060A2D10,r0
    c.r[7] &= c.r[0];  // 060A2CF6 and r0,r7
    c.r[7] >>= 2;  // 060A2CF8 shlr2 r7
    c.r[6] += c.r[7];  // 060A2CFA add r7,r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2CFC mov.l 0x060A2D70,r0
    c.r[10] &= c.r[0];  // 060A2CFE and r0,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060A2D00 shlr r10
    c.r[0] = ld32(0x060A2D70u);  // 060A2D02 mov.l 0x060A2D70,r0
    c.r[2] &= c.r[0];  // 060A2D04 and r0,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060A2D06 shlr r2
    c.r[2] += c.r[10];  // 060A2D08 add r10,r2
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2D0A xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2D0C rts ; swap.w r2,r6
L_060A2D18:
    c.r[7] = c.r[2];  // 060A2D18 mov r2,r7
    c.r[0] = ld32(0x060A2D70u);  // 060A2D1A mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D1C and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D1E shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D20 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D22 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D24 shlr r7
    c.r[6] += c.r[7];  // 060A2D26 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2D28 xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2D2A rts ; swap.w r6,r6
L_060A2D2E:
    c.r[2] = c.r[7];  // 060A2D2E mov r7,r2
    c.r[0] = ld32(0x060A2D70u);  // 060A2D30 mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D32 and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D34 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D36 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D38 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D3A shlr r7
    c.r[6] += c.r[7];  // 060A2D3C add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2D3E xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2D40 rts ; swap.w r2,r6
L_060A2D44:
    c.r[2] = c.r[6];  // 060A2D44 mov r6,r2
    c.r[0] = ld32(0x060A2D70u);  // 060A2D46 mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D48 and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D4A shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D4C mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D4E and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D50 shlr r7
    c.r[6] += c.r[7];  // 060A2D52 add r7,r6
    c.r[6] = c.r[2] << 16 | c.r[6] >> 16;  // 060A2D54 xtrct r2,r6
    { const uint32_t x = c.pr; c.r[6] = c.r[6] << 16 | c.r[6] >> 16; c.pc = x; return; }  // 060A2D56 rts ; swap.w r6,r6
L_060A2D5A:
    c.r[2] = c.r[6];  // 060A2D5A mov r6,r2
    c.r[0] = ld32(0x060A2D70u);  // 060A2D5C mov.l 0x060A2D70,r0
    c.r[6] &= c.r[0];  // 060A2D5E and r0,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060A2D60 shlr r6
    c.r[0] = ld32(0x060A2D70u);  // 060A2D62 mov.l 0x060A2D70,r0
    c.r[7] &= c.r[0];  // 060A2D64 and r0,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A2D66 shlr r7
    c.r[6] += c.r[7];  // 060A2D68 add r7,r6
    c.r[2] = c.r[6] << 16 | c.r[2] >> 16;  // 060A2D6A xtrct r6,r2
    { const uint32_t x = c.pr; c.r[6] = c.r[2] << 16 | c.r[2] >> 16; c.pc = x; return; }  // 060A2D6C rts ; swap.w r2,r6
L_060A2D74:
    c.r[10] = ld32(0x060A2D88u);  // 060A2D74 mov.l 0x060A2D88,r10
    c.r[7] <<= 2;  // 060A2D76 shll2 r7
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060A2D78 mov.l @r1+,r2
    c.r[6] &= c.r[10];  // 060A2D7A and r10,r6
    c.r[2] &= c.r[10];  // 060A2D7C and r10,r2
    c.r[0] = 0x060A2D8Cu;  // 060A2D7E mova 0x060A2D8C,r0
    c.r[10] = ld32(c.r[0] + c.r[7]);  // 060A2D80 mov.l @(r0,r7),r10
    { const uint32_t x = c.r[10]; c.r[7] = c.r[2]; SH2_POLL(c); switch (x) { case 0x060A2ACCu: goto L_060A2ACC; case 0x060A2ADAu: goto L_060A2ADA; case 0x060A2B18u: goto L_060A2B18; case 0x060A2D2Eu: goto L_060A2D2E; case 0x060A2B88u: goto L_060A2B88; case 0x060A2AD4u: goto L_060A2AD4; case 0x060A2AD0u: goto L_060A2AD0; case 0x060A2B34u: goto L_060A2B34; case 0x060A2D5Au: goto L_060A2D5A; case 0x060A2B6Cu: goto L_060A2B6C; case 0x060A2AE0u: goto L_060A2AE0; case 0x060A2AFCu: goto L_060A2AFC; case 0x060A2BC0u: goto L_060A2BC0; case 0x060A2C28u: goto L_060A2C28; case 0x060A2C86u: goto L_060A2C86; case 0x060A2D18u: goto L_060A2D18; case 0x060A2D44u: goto L_060A2D44; case 0x060A2BFCu: goto L_060A2BFC; case 0x060A2BD6u: goto L_060A2BD6; case 0x060A2CE4u: goto L_060A2CE4; case 0x060A2BA4u: goto L_060A2BA4; case 0x060A2B50u: goto L_060A2B50; case 0x060A2C54u: goto L_060A2C54; case 0x060A2CB8u: goto L_060A2CB8; case 0x060A2BE6u: goto L_060A2BE6; default: sh2_call(c, x); return; } }  // 060A2D82 jmp @r10 ; mov r2,r7
}

void f_060A2F50(SH2Context& c) {
    ran[2652] = 1;
    goto L_060A2F50;
L_060A2DF0:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2DF0 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2DF2 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2DF4 tst r11,r11
    if (c.t) { goto L_060A2E00; }  // 060A2DF6 bt 0x060A2E00
    c.r[11] <<= 2;  // 060A2DF8 shll2 r11
    c.r[11] <<= 2;  // 060A2DFA shll2 r11
    c.r[11] += c.r[12]; goto L_060A2EB0;  // 060A2DFC bra 0x060A2EB0 ; add r12,r11
L_060A2E00:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E00 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2E02 sub r5,r6
    c.r[11] <<= 2;  // 060A2E04 shll2 r11
    c.r[11] <<= 2;  // 060A2E06 shll2 r11
    c.r[11] += c.r[12];  // 060A2E08 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2E0A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2E0C shar r0
    c.r[5] += c.r[0];  // 060A2E0E add r0,r5
    c.r[0] <<= 2;  // 060A2E10 shll2 r0
    c.r[5] += c.r[0];  // 060A2E12 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2EB0; } }  // 060A2E14 bf/s 0x060A2EB0 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E18 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2E1A shll2 r11
    c.r[11] <<= 2;  // 060A2E1C shll2 r11
    c.r[11] += c.r[12]; goto L_060A2EB0;  // 060A2E1E bra 0x060A2EB0 ; add r12,r11
L_060A2E24:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E24 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A2E26 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2E28 tst r11,r11
    if (c.t) { goto L_060A2E34; }  // 060A2E2A bt 0x060A2E34
    c.r[11] <<= 2;  // 060A2E2C shll2 r11
    c.r[11] <<= 2;  // 060A2E2E shll2 r11
    c.r[11] += c.r[12]; goto L_060A2ED8;  // 060A2E30 bra 0x060A2ED8 ; add r12,r11
L_060A2E34:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E34 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A2E36 sub r5,r6
    c.r[11] <<= 2;  // 060A2E38 shll2 r11
    c.r[11] <<= 2;  // 060A2E3A shll2 r11
    c.r[11] += c.r[12];  // 060A2E3C add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2E3E mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2E40 shar r0
    c.r[5] += c.r[0];  // 060A2E42 add r0,r5
    c.r[0] <<= 2;  // 060A2E44 shll2 r0
    c.r[5] += c.r[0];  // 060A2E46 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A2ED8; } }  // 060A2E48 bf/s 0x060A2ED8 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E4C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2E4E shll2 r11
    c.r[11] <<= 2;  // 060A2E50 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2ED8;  // 060A2E52 bra 0x060A2ED8 ; add r12,r11
L_060A2E58:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E58 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2E5A shll2 r11
    c.r[11] <<= 2;  // 060A2E5C shll2 r11
    c.r[11] += c.r[12]; goto L_060A2EBC;  // 060A2E5E bra 0x060A2EBC ; add r12,r11
L_060A2E64:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E64 mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2E66 tst r11,r11
    if (c.t) { goto L_060A2E74; }  // 060A2E68 bt 0x060A2E74
    c.r[11] <<= 2;  // 060A2E6A shll2 r11
    c.r[11] <<= 2;  // 060A2E6C shll2 r11
    c.r[11] += c.r[12]; goto L_060A2EA4;  // 060A2E6E bra 0x060A2EA4 ; add r12,r11
L_060A2E74:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E74 mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A2E76 mov r3,r0
    c.r[11] <<= 2;  // 060A2E78 shll2 r11
    c.r[11] <<= 2;  // 060A2E7A shll2 r11
    c.r[11] += c.r[12];  // 060A2E7C add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2E7E mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A2E80 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2E82 shar r0
    c.r[5] += c.r[0];  // 060A2E84 add r0,r5
    c.r[0] <<= 2;  // 060A2E86 shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2EA4; } }  // 060A2E88 bf/s 0x060A2EA4 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2E8C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2E8E shll2 r11
    c.r[11] <<= 2;  // 060A2E90 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2EA4;  // 060A2E92 bra 0x060A2EA4 ; add r12,r11
L_060A2E98:
    c.r[0] = c.r[3];  // 060A2E98 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2E9A mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2E9C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2E64; } }  // 060A2E9E bt/s 0x060A2E64 ; add r0,r5
    c.r[11] += 4;  // 060A2EA2 add #4,r11
L_060A2EA4:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2EA4 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A2EA6 mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2EA8 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2DF0; } }  // 060A2EAA bt/s 0x060A2DF0 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2EAE add r5,r6
L_060A2EB0:
    st32(c.r[4], c.r[6]);  // 060A2EB0 mov.l r6,@r4
    c.r[0] = ld32(0x060A3240u);  // 060A2EB2 mov.l 0x060A3240,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A2EB4 mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A2EB6 shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_060A2E58; } }  // 060A2EB8 bt/s 0x060A2E58 ; add #4,r11
L_060A2EBC:
    c.r[0] = ld32(0x060A2F08u);  // 060A2EBC mov.l 0x060A2F08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A2EC2u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A2EC2u) return; }  // 060A2EBE jsr @r0 ; add #4,r4
    c.r[0] = ld32(0x060A3094u);  // 060A2EC2 mov.l 0x060A3094,r0
    ;  // 060A2EC4 nop
    c.r[6] |= c.r[0];  // 060A2EC6 or r0,r6
    st32(c.r[13], c.r[6]);  // 060A2EC8 mov.l r6,@r13
    c.r[13] += 4;  // 060A2ECA add #4,r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2ECC mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A2ECE mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2ED0 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2E24; } }  // 060A2ED2 bt/s 0x060A2E24 ; add r0,r5
    c.r[6] += c.r[5];  // 060A2ED6 add r5,r6
L_060A2ED8:
    st32(c.r[4], c.r[6]);  // 060A2ED8 mov.l r6,@r4
    c.r[0] = ld32(0x060A3240u);  // 060A2EDA mov.l 0x060A3240,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A2EDC mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A2EDE shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { goto L_060A2F10; } }  // 060A2EE0 bt/s 0x060A2F10 ; add #4,r11
L_060A2EE4:
    c.r[0] = ld32(0x060A2F08u);  // 060A2EE4 mov.l 0x060A2F08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A2EEAu; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A2EEAu) return; }  // 060A2EE6 jsr @r0 ; add #4,r4
    c.r[0] = ld32(0x060A3094u);  // 060A2EEA mov.l 0x060A3094,r0
    ;  // 060A2EEC nop
    c.r[6] |= c.r[0];  // 060A2EEE or r0,r6
    st32(c.r[13], c.r[6]);  // 060A2EF0 mov.l r6,@r13
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A2EF2 dt r8
    { const bool k = !c.t; c.r[13] += 4; if (k) { goto L_060A2FBC; } }  // 060A2EF4 bf/s 0x060A2FBC ; add #4,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A2EF8 mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A2EFA tst r9,r9
    if (!c.t) { goto L_060A2F54; }  // 060A2EFC bf 0x060A2F54
    c.r[2] = ld32(c.r[15] + 36);  // 060A2EFE mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A2F00 lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A2F02 rts ; nop
L_060A2F0C:
    SH2_POLL(c); goto L_060A2E98;  // 060A2F0C bra 0x060A2E98 ; nop
L_060A2F10:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2F10 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2F12 shll2 r11
    c.r[11] <<= 2;  // 060A2F14 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2EE4;  // 060A2F16 bra 0x060A2EE4 ; add r12,r11
L_060A2F1C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2F1C mov.b @r14+,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A2F1E tst r11,r11
    if (c.t) { goto L_060A2F2C; }  // 060A2F20 bt 0x060A2F2C
    c.r[11] <<= 2;  // 060A2F22 shll2 r11
    c.r[11] <<= 2;  // 060A2F24 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2FF0;  // 060A2F26 bra 0x060A2FF0 ; add r12,r11
L_060A2F2C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2F2C mov.b @r14+,r11
    c.r[0] = c.r[3];  // 060A2F2E mov r3,r0
    c.r[11] <<= 2;  // 060A2F30 shll2 r11
    c.r[11] <<= 2;  // 060A2F32 shll2 r11
    c.r[11] += c.r[12];  // 060A2F34 add r12,r11
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2F36 mov.l @(r0,r11),r0
    c.r[11] += 4;  // 060A2F38 add #4,r11
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2F3A shar r0
    c.r[5] += c.r[0];  // 060A2F3C add r0,r5
    c.r[0] <<= 2;  // 060A2F3E shll2 r0
    { const bool k = !c.t; c.r[5] += c.r[0]; if (k) { goto L_060A2FF0; } }  // 060A2F40 bf/s 0x060A2FF0 ; add r0,r5
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A2F44 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A2F46 shll2 r11
    c.r[11] <<= 2;  // 060A2F48 shll2 r11
    c.r[11] += c.r[12]; goto L_060A2FF0;  // 060A2F4A bra 0x060A2FF0 ; add r12,r11
L_060A2F50:
    c.r[0] = c.pr;  // 060A2F50 sts pr,r0
    st32(c.r[15] + 36, c.r[0]);  // 060A2F52 mov.l r0,@(36,r15)
L_060A2F54:
    c.r[0] = ld32(c.r[15] + 32);  // 060A2F54 mov.l @(32,r15),r0
    c.t = c.r[0] == 0x1u;  // 060A2F56 cmp/eq #1,r0
    if (!c.t) { goto L_060A2F7C; }  // 060A2F58 bf 0x060A2F7C
    ;  // 060A2F5A nop
    c.r[0] = ld32(c.r[15] + 16);  // 060A2F5C mov.l @(16,r15),r0
    c.r[8] = 0x10u;  // 060A2F5E mov #16,r8
    c.r[2] = c.gbr;  // 060A2F60 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A2F62 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A2F64 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A2F6C; } }  // 060A2F66 bf/s 0x060A2F6C ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A2F6A mov r0,r8
L_060A2F6C:
    c.r[0] -= c.r[8];  // 060A2F6C sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A2F6E mov.l r0,@(16,r15)
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2F70 shlr r9
    { const bool k = c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { goto L_060A2FE4; } }  // 060A2F72 bt/s 0x060A2FE4 ; shlr r9
    if (c.t) { SH2_POLL(c); goto L_060A2E98; }  // 060A2F76 bt 0x060A2E98
    goto L_060A2FC4;  // 060A2F78 bra 0x060A2FC4 ; nop
L_060A2F7C:
    c.r[9] = ld32(c.r[15] + 16);  // 060A2F7C mov.l @(16,r15),r9
    c.r[8] = 0x10u;  // 060A2F7E mov #16,r8
    c.t = c.r[8] >= c.r[9];  // 060A2F80 cmp/hs r9,r8
    { const bool k = !c.t; c.r[2] = ld32(c.r[15] + 12); if (k) { goto L_060A2F88; } }  // 060A2F82 bf/s 0x060A2F88 ; mov.l @(12,r15),r2
    c.r[8] = c.r[9];  // 060A2F86 mov r9,r8
L_060A2F88:
    c.r[9] -= c.r[8];  // 060A2F88 sub r8,r9
    st32(c.r[15] + 16, c.r[9]);  // 060A2F8A mov.l r9,@(16,r15)
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A2F8C mov.b @r2,r9
    c.r[9] = c.r[9] & 0xFFu;  // 060A2F8E extu.b r9,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060A2F90 mov.b @(1,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 060A2F92 extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 2);  // 060A2F94 mov.b @(2,r2),r0
    c.r[6] <<= 8;  // 060A2F96 shll8 r6
    c.r[9] += c.r[6];  // 060A2F98 add r6,r9
    c.r[6] = c.r[0] & 0xFFu;  // 060A2F9A extu.b r0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 3);  // 060A2F9C mov.b @(3,r2),r0
    c.r[6] <<= 16;  // 060A2F9E shll16 r6
    c.r[9] += c.r[6];  // 060A2FA0 add r6,r9
    c.r[0] <<= 8;  // 060A2FA2 shll8 r0
    c.r[0] <<= 16;  // 060A2FA4 shll16 r0
    c.r[9] += c.r[0];  // 060A2FA6 add r0,r9
    c.r[0] = c.r[8];  // 060A2FA8 mov r8,r0
    c.r[0] += 3;  // 060A2FAA add #3,r0
    c.r[0] >>= 2;  // 060A2FAC shlr2 r0
    ;  // 060A2FAE nop
    c.r[2] += c.r[0];  // 060A2FB0 add r0,r2
    st32(c.r[15] + 12, c.r[2]);  // 060A2FB2 mov.l r2,@(12,r15)
    c.r[2] = c.gbr;  // 060A2FB4 stc gbr,r2
    st32(c.r[2], c.r[9]);  // 060A2FB6 mov.l r9,@r2
    c.r[2] += 4;  // 060A2FB8 add #4,r2
    c.gbr = c.r[2];  // 060A2FBA ldc r2,gbr
L_060A2FBC:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2FBC shlr r9
    { const bool k = c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { goto L_060A2FE4; } }  // 060A2FBE bt/s 0x060A2FE4 ; shlr r9
L_060A2FC2:
    if (c.t) { SH2_POLL(c); goto L_060A2F0C; }  // 060A2FC2 bt 0x060A2F0C
L_060A2FC4:
    c.r[5] = 0x0u;  // 060A2FC4 mov #0,r5
    c.r[4] += 8;  // 060A2FC6 add #8,r4
    c.t = c.r[1] == c.r[13];  // 060A2FC8 cmp/eq r13,r1
    { const bool k = c.t; c.r[1] += 8; if (k) { goto L_060A2FD6; } }  // 060A2FCA bt/s 0x060A2FD6 ; add #8,r1
    ;  // 060A2FCE nop
    st32(c.r[13], c.r[5]);  // 060A2FD0 mov.l r5,@r13
    ;  // 060A2FD2 nop
    st32(c.r[13] + 4, c.r[0]);  // 060A2FD4 mov.l r0,@(4,r13)
L_060A2FD6:
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A2FD6 dt r8
    { const bool k = c.t; c.r[13] += 8; if (k) { goto L_060A301E; } }  // 060A2FD8 bt/s 0x060A301E ; add #8,r13
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A2FDC shlr r9
    { const bool k = !c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { SH2_POLL(c); goto L_060A2FC2; } }  // 060A2FDE bf/s 0x060A2FC2 ; shlr r9
    ;  // 060A2FE2 nop
L_060A2FE4:
    c.r[0] = c.r[3];  // 060A2FE4 mov r3,r0
    c.r[0] = ld32(c.r[0] + c.r[11]);  // 060A2FE6 mov.l @(r0,r11),r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2FE8 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A2F1C; } }  // 060A2FEA bt/s 0x060A2F1C ; add r0,r5
    c.r[11] += 4;  // 060A2FEE add #4,r11
L_060A2FF0:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A2FF0 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A2FF2 mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A2FF4 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A302C; } }  // 060A2FF6 bt/s 0x060A302C ; add r0,r5
    c.r[6] += c.r[5];  // 060A2FFA add r5,r6
L_060A2FFC:
    st32(c.r[4], c.r[6]);  // 060A2FFC mov.l r6,@r4
    ;  // 060A2FFE nop
    c.r[1] += 4;  // 060A3000 add #4,r1
    st32(c.r[13], c.r[6]);  // 060A3002 mov.l r6,@r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3004 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A3006 shar r0
    c.r[6] = ld32(c.r[4] + 4);  // 060A3008 mov.l @(4,r4),r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A3060; } }  // 060A300A bt/s 0x060A3060 ; add r0,r5
    c.r[6] += c.r[5];  // 060A300E add r5,r6
L_060A3010:
    st32(c.r[4] + 4, c.r[6]);  // 060A3010 mov.l r6,@(4,r4)
    c.r[1] += 4;  // 060A3012 add #4,r1
    c.r[4] += 8;  // 060A3014 add #8,r4
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A3016 dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A3018 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A2FBC; } }  // 060A301A bf/s 0x060A2FBC ; add #8,r13
L_060A301E:
    c.r[9] = ld32(c.r[15] + 16);  // 060A301E mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A3020 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A2F54; }  // 060A3022 bf 0x060A2F54
    c.r[2] = ld32(c.r[15] + 36);  // 060A3024 mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A3026 lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A3028 rts ; nop
L_060A302C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A302C mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A302E add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A3030 tst r11,r11
    if (c.t) { goto L_060A303C; }  // 060A3032 bt 0x060A303C
    c.r[11] <<= 2;  // 060A3034 shll2 r11
    c.r[11] <<= 2;  // 060A3036 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2FFC;  // 060A3038 bra 0x060A2FFC ; add r12,r11
L_060A303C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A303C mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A303E sub r5,r6
    c.r[11] <<= 2;  // 060A3040 shll2 r11
    c.r[11] <<= 2;  // 060A3042 shll2 r11
    c.r[11] += c.r[12];  // 060A3044 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3046 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A3048 shar r0
    c.r[5] += c.r[0];  // 060A304A add r0,r5
    c.r[0] <<= 2;  // 060A304C shll2 r0
    c.r[5] += c.r[0];  // 060A304E add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A2FFC; } }  // 060A3050 bf/s 0x060A2FFC ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3054 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A3056 shll2 r11
    c.r[11] <<= 2;  // 060A3058 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A2FFC;  // 060A305A bra 0x060A2FFC ; add r12,r11
L_060A3060:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3060 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A3062 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A3064 tst r11,r11
    if (c.t) { goto L_060A3070; }  // 060A3066 bt 0x060A3070
    c.r[11] <<= 2;  // 060A3068 shll2 r11
    c.r[11] <<= 2;  // 060A306A shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A3010;  // 060A306C bra 0x060A3010 ; add r12,r11
L_060A3070:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3070 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A3072 sub r5,r6
    c.r[11] <<= 2;  // 060A3074 shll2 r11
    c.r[11] <<= 2;  // 060A3076 shll2 r11
    c.r[11] += c.r[12];  // 060A3078 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A307A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A307C shar r0
    c.r[5] += c.r[0];  // 060A307E add r0,r5
    c.r[0] <<= 2;  // 060A3080 shll2 r0
    c.r[5] += c.r[0];  // 060A3082 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A3010; } }  // 060A3084 bf/s 0x060A3010 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3088 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A308A shll2 r11
    c.r[11] <<= 2;  // 060A308C shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A3010;  // 060A308E bra 0x060A3010 ; add r12,r11
}

void f_060A31B8(SH2Context& c) {
    ran[2653] = 1;
    goto L_060A31B8;
L_060A3098:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3098 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A309A add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A309C tst r11,r11
    if (c.t) { goto L_060A30A8; }  // 060A309E bt 0x060A30A8
    c.r[11] <<= 2;  // 060A30A0 shll2 r11
    c.r[11] <<= 2;  // 060A30A2 shll2 r11
    c.r[11] += c.r[12]; goto L_060A3124;  // 060A30A4 bra 0x060A3124 ; add r12,r11
L_060A30A8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A30A8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A30AA sub r5,r6
    c.r[11] <<= 2;  // 060A30AC shll2 r11
    c.r[11] <<= 2;  // 060A30AE shll2 r11
    c.r[11] += c.r[12];  // 060A30B0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A30B2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A30B4 shar r0
    c.r[5] += c.r[0];  // 060A30B6 add r0,r5
    c.r[0] <<= 2;  // 060A30B8 shll2 r0
    c.r[5] += c.r[0];  // 060A30BA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A3124; } }  // 060A30BC bf/s 0x060A3124 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A30C0 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A30C2 shll2 r11
    c.r[11] <<= 2;  // 060A30C4 shll2 r11
    c.r[11] += c.r[12]; goto L_060A3124;  // 060A30C6 bra 0x060A3124 ; add r12,r11
L_060A30CC:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A30CC mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A30CE shll2 r11
    c.r[11] <<= 2;  // 060A30D0 shll2 r11
    c.r[11] += c.r[12]; goto L_060A3130;  // 060A30D2 bra 0x060A3130 ; add r12,r11
L_060A30D8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A30D8 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A30DA add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A30DC tst r11,r11
    if (c.t) { goto L_060A30E8; }  // 060A30DE bt 0x060A30E8
    c.r[11] <<= 2;  // 060A30E0 shll2 r11
    c.r[11] <<= 2;  // 060A30E2 shll2 r11
    c.r[11] += c.r[12]; goto L_060A314C;  // 060A30E4 bra 0x060A314C ; add r12,r11
L_060A30E8:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A30E8 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A30EA sub r5,r6
    c.r[11] <<= 2;  // 060A30EC shll2 r11
    c.r[11] <<= 2;  // 060A30EE shll2 r11
    c.r[11] += c.r[12];  // 060A30F0 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A30F2 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A30F4 shar r0
    c.r[5] += c.r[0];  // 060A30F6 add r0,r5
    c.r[0] <<= 2;  // 060A30F8 shll2 r0
    c.r[5] += c.r[0];  // 060A30FA add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A314C; } }  // 060A30FC bf/s 0x060A314C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3100 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A3102 shll2 r11
    c.r[11] <<= 2;  // 060A3104 shll2 r11
    c.r[11] += c.r[12]; goto L_060A314C;  // 060A3106 bra 0x060A314C ; add r12,r11
L_060A310C:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A310C mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A310E shll2 r11
    c.r[11] <<= 2;  // 060A3110 shll2 r11
    c.r[11] += c.r[12]; goto L_060A3158;  // 060A3112 bra 0x060A3158 ; add r12,r11
L_060A3118:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3118 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A311A mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A311C shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A3098; } }  // 060A311E bt/s 0x060A3098 ; add r0,r5
    c.r[6] += c.r[5];  // 060A3122 add r5,r6
L_060A3124:
    st32(c.r[4], c.r[6]);  // 060A3124 mov.l r6,@r4
    c.r[0] = ld32(0x060A3240u);  // 060A3126 mov.l 0x060A3240,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A3128 mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A312A shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_060A30CC; } }  // 060A312C bt/s 0x060A30CC ; add #4,r11
L_060A3130:
    c.r[0] = ld32(0x060A317Cu);  // 060A3130 mov.l 0x060A317C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A3136u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A3136u) return; }  // 060A3132 jsr @r0 ; add #4,r4
    c.r[0] = ld32(0x060A3244u);  // 060A3136 mov.l 0x060A3244,r0
    ;  // 060A3138 nop
    c.r[6] |= c.r[0];  // 060A313A or r0,r6
    st32(c.r[13], c.r[6]);  // 060A313C mov.l r6,@r13
    c.r[13] += 4;  // 060A313E add #4,r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3140 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A3142 mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A3144 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A30D8; } }  // 060A3146 bt/s 0x060A30D8 ; add r0,r5
    c.r[6] += c.r[5];  // 060A314A add r5,r6
L_060A314C:
    st32(c.r[4], c.r[6]);  // 060A314C mov.l r6,@r4
    c.r[0] = ld32(0x060A3240u);  // 060A314E mov.l 0x060A3240,r0
    c.r[7] = ld32(c.r[0] + c.r[11]);  // 060A3150 mov.l @(r0,r11),r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060A3152 shar r7
    { const bool k = c.t; c.r[11] += 4; if (k) { SH2_POLL(c); goto L_060A310C; } }  // 060A3154 bt/s 0x060A310C ; add #4,r11
L_060A3158:
    c.r[0] = ld32(0x060A317Cu);  // 060A3158 mov.l 0x060A317C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060A315Eu; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A315Eu) return; }  // 060A315A jsr @r0 ; add #4,r4
    c.r[0] = ld32(0x060A3244u);  // 060A315E mov.l 0x060A3244,r0
    ;  // 060A3160 nop
    c.r[6] |= c.r[0];  // 060A3162 or r0,r6
    st32(c.r[13], c.r[6]);  // 060A3164 mov.l r6,@r13
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A3166 dt r8
    { const bool k = !c.t; c.r[13] += 4; if (k) { goto L_060A31D0; } }  // 060A3168 bf/s 0x060A31D0 ; add #4,r13
    c.r[9] = ld32(c.r[15] + 16);  // 060A316C mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A316E tst r9,r9
    if (!c.t) { goto L_060A31BC; }  // 060A3170 bf 0x060A31BC
    c.r[2] = ld32(c.r[15] + 36);  // 060A3172 mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A3174 lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A3176 rts ; nop
L_060A3180:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3180 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A3182 add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A3184 tst r11,r11
    if (c.t) { goto L_060A3190; }  // 060A3186 bt 0x060A3190
    c.r[11] <<= 2;  // 060A3188 shll2 r11
    c.r[11] <<= 2;  // 060A318A shll2 r11
    c.r[11] += c.r[12]; goto L_060A320C;  // 060A318C bra 0x060A320C ; add r12,r11
L_060A3190:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3190 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A3192 sub r5,r6
    c.r[11] <<= 2;  // 060A3194 shll2 r11
    c.r[11] <<= 2;  // 060A3196 shll2 r11
    c.r[11] += c.r[12];  // 060A3198 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A319A mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A319C shar r0
    c.r[5] += c.r[0];  // 060A319E add r0,r5
    c.r[0] <<= 2;  // 060A31A0 shll2 r0
    c.r[5] += c.r[0];  // 060A31A2 add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { goto L_060A320C; } }  // 060A31A4 bf/s 0x060A320C ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A31A8 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A31AA shll2 r11
    c.r[11] <<= 2;  // 060A31AC shll2 r11
    c.r[11] += c.r[12]; goto L_060A320C;  // 060A31AE bra 0x060A320C ; add r12,r11
L_060A31B4:
    SH2_POLL(c); goto L_060A3118;  // 060A31B4 bra 0x060A3118 ; nop
L_060A31B8:
    c.r[0] = c.pr;  // 060A31B8 sts pr,r0
    st32(c.r[15] + 36, c.r[0]);  // 060A31BA mov.l r0,@(36,r15)
L_060A31BC:
    c.r[0] = ld32(c.r[15] + 16);  // 060A31BC mov.l @(16,r15),r0
    c.r[8] = 0x10u;  // 060A31BE mov #16,r8
    c.r[2] = c.gbr;  // 060A31C0 stc gbr,r2
    c.t = c.r[8] >= c.r[0];  // 060A31C2 cmp/hs r0,r8
    c.r[9] = ld32(c.r[2]); c.r[2] += 4;  // 060A31C4 mov.l @r2+,r9
    { const bool k = !c.t; c.gbr = c.r[2]; if (k) { goto L_060A31CC; } }  // 060A31C6 bf/s 0x060A31CC ; ldc r2,gbr
    c.r[8] = c.r[0];  // 060A31CA mov r0,r8
L_060A31CC:
    c.r[0] -= c.r[8];  // 060A31CC sub r8,r0
    st32(c.r[15] + 16, c.r[0]);  // 060A31CE mov.l r0,@(16,r15)
L_060A31D0:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A31D0 shlr r9
    { const bool k = c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { goto L_060A3200; } }  // 060A31D2 bt/s 0x060A3200 ; shlr r9
L_060A31D6:
    if (c.t) { SH2_POLL(c); goto L_060A31B4; }  // 060A31D6 bt 0x060A31B4
    c.t = c.r[1] == c.r[13];  // 060A31D8 cmp/eq r13,r1
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060A31E8; } }  // 060A31DA bt/s 0x060A31E8 ; mov #0,r5
    ;  // 060A31DE nop
    st32(c.r[13], c.r[5]);  // 060A31E0 mov.l r5,@r13
    ;  // 060A31E2 nop
    st32(c.r[13] + 4, c.r[5]);  // 060A31E4 mov.l r5,@(4,r13)
    ;  // 060A31E6 nop
L_060A31E8:
    c.r[2] = ld32(0x060A3244u);  // 060A31E8 mov.l 0x060A3244,r2
    c.r[1] += 8;  // 060A31EA add #8,r1
    st32(c.r[4], c.r[2]);  // 060A31EC mov.l r2,@r4
    c.r[13] += 8;  // 060A31EE add #8,r13
    st32(c.r[4] + 4, c.r[2]);  // 060A31F0 mov.l r2,@(4,r4)
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A31F2 dt r8
    { const bool k = c.t; c.r[4] += 8; if (k) { goto L_060A322E; } }  // 060A31F4 bt/s 0x060A322E ; add #8,r4
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A31F8 shlr r9
    { const bool k = !c.t; c.t = c.r[9] & 1; c.r[9] >>= 1; if (k) { SH2_POLL(c); goto L_060A31D6; } }  // 060A31FA bf/s 0x060A31D6 ; shlr r9
    ;  // 060A31FE nop
L_060A3200:
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3200 mov.l @r11+,r0
    c.r[6] = ld32(c.r[4]);  // 060A3202 mov.l @r4,r6
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A3204 shar r0
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { SH2_POLL(c); goto L_060A3180; } }  // 060A3206 bt/s 0x060A3180 ; add r0,r5
    c.r[6] += c.r[5];  // 060A320A add r5,r6
L_060A320C:
    st32(c.r[4], c.r[6]);  // 060A320C mov.l r6,@r4
    ;  // 060A320E nop
    c.r[1] += 4;  // 060A3210 add #4,r1
    st32(c.r[13], c.r[6]);  // 060A3212 mov.l r6,@r13
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3214 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A3216 shar r0
    c.r[6] = ld32(c.r[4] + 4);  // 060A3218 mov.l @(4,r4),r6
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_060A3248; } }  // 060A321A bt/s 0x060A3248 ; add r0,r5
    c.r[6] += c.r[5];  // 060A321E add r5,r6
L_060A3220:
    st32(c.r[4] + 4, c.r[6]);  // 060A3220 mov.l r6,@(4,r4)
    c.r[1] += 4;  // 060A3222 add #4,r1
    c.r[4] += 8;  // 060A3224 add #8,r4
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060A3226 dt r8
    st32(c.r[13] + 4, c.r[6]);  // 060A3228 mov.l r6,@(4,r13)
    { const bool k = !c.t; c.r[13] += 8; if (k) { SH2_POLL(c); goto L_060A31D0; } }  // 060A322A bf/s 0x060A31D0 ; add #8,r13
L_060A322E:
    c.r[9] = ld32(c.r[15] + 16);  // 060A322E mov.l @(16,r15),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060A3230 tst r9,r9
    if (!c.t) { SH2_POLL(c); goto L_060A31BC; }  // 060A3232 bf 0x060A31BC
    c.r[2] = ld32(c.r[15] + 36);  // 060A3234 mov.l @(36,r15),r2
    c.pr = c.r[2];  // 060A3236 lds r2,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A3238 rts ; nop
L_060A3248:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3248 mov.b @r14+,r11
    c.r[6] += c.r[5];  // 060A324A add r5,r6
    c.t = (c.r[11] & c.r[11]) == 0;  // 060A324C tst r11,r11
    if (c.t) { goto L_060A3258; }  // 060A324E bt 0x060A3258
    c.r[11] <<= 2;  // 060A3250 shll2 r11
    c.r[11] <<= 2;  // 060A3252 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A3220;  // 060A3254 bra 0x060A3220 ; add r12,r11
L_060A3258:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3258 mov.b @r14+,r11
    c.r[6] -= c.r[5];  // 060A325A sub r5,r6
    c.r[11] <<= 2;  // 060A325C shll2 r11
    c.r[11] <<= 2;  // 060A325E shll2 r11
    c.r[11] += c.r[12];  // 060A3260 add r12,r11
    c.r[0] = ld32(c.r[11]); c.r[11] += 4;  // 060A3262 mov.l @r11+,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060A3264 shar r0
    c.r[5] += c.r[0];  // 060A3266 add r0,r5
    c.r[0] <<= 2;  // 060A3268 shll2 r0
    c.r[5] += c.r[0];  // 060A326A add r0,r5
    { const bool k = !c.t; c.r[6] += c.r[5]; if (k) { SH2_POLL(c); goto L_060A3220; } }  // 060A326C bf/s 0x060A3220 ; add r5,r6
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[14]); c.r[14] += 1;  // 060A3270 mov.b @r14+,r11
    c.r[11] <<= 2;  // 060A3272 shll2 r11
    c.r[11] <<= 2;  // 060A3274 shll2 r11
    c.r[11] += c.r[12]; SH2_POLL(c); goto L_060A3220;  // 060A3276 bra 0x060A3220 ; add r12,r11
}

void f_060A3280(SH2Context& c) {
    ran[2654] = 1;
    c.r[6] = ld32(0x060A32ACu);  // 060A3280 mov.l 0x060A32AC,r6
    c.r[7] = ld32(0x060A32B0u);  // 060A3282 mov.l 0x060A32B0,r7
    c.r[3] = ld32(0x060A32B4u);  // 060A3284 mov.l 0x060A32B4,r3
    c.r[2] = ld32(0x060A32B8u);  // 060A3286 mov.l 0x060A32B8,r2
    c.r[1] = ld32(0x060A32BCu);  // 060A3288 mov.l 0x060A32BC,r1
    st32(c.r[1], c.r[6]);  // 060A328A mov.l r6,@r1
    st32(c.r[2], c.r[6]);  // 060A328C mov.l r6,@r2
    st32(c.r[3], c.r[6]);  // 060A328E mov.l r6,@r3
    st32(c.r[7], c.r[6]);  // 060A3290 mov.l r6,@r7
    c.r[1] = ld32(0x060A32C0u);  // 060A3292 mov.l 0x060A32C0,r1
    st32(c.r[6], c.r[1]);  // 060A3294 mov.l r1,@r6
    c.r[6] += 4;  // 060A3296 add #4,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x060A32AAu);  // 060A3298 mov.w 0x060A32AA,r2
    c.r[3] = ld32(0x060A32C4u);  // 060A329A mov.l 0x060A32C4,r3
L_060A329C:
    c.r[1] += c.r[3];  // 060A329C add r3,r1
    st32(c.r[6], c.r[1]);  // 060A329E mov.l r1,@r6
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060A32A0 dt r2
    { const bool k = !c.t; c.r[6] += 4; if (k) { SH2_POLL(c); goto L_060A329C; } }  // 060A32A2 bf/s 0x060A329C ; add #4,r6
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060A32A6 rts ; nop
}

void f_060A32C8(SH2Context& c) {
    ran[2655] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A32C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A32CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A32CC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A32CE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A32D0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A32D2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A32D4 mov.l r14,@-r15
    c.r[0] = ld32(0x060A32E4u);  // 060A32D6 mov.l 0x060A32E4,r0
    c.r[9] = c.r[7];  // 060A32D8 mov r7,r9
    c.r[9] >>= 2;  // 060A32DA shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A32DC shlr r9
    c.r[6] -= 32; goto L_060A32EC;  // 060A32DE bra 0x060A32EC ; add #-32,r6
L_060A32EC:
    c.r[8] = ld32(c.r[5]);  // 060A32EC mov.l @r5,r8
    c.r[10] = ld32(c.r[5] + 4);  // 060A32EE mov.l @(4,r5),r10
    c.r[11] = ld32(c.r[5] + 8);  // 060A32F0 mov.l @(8,r5),r11
    c.r[12] = ld32(c.r[5] + 12);  // 060A32F2 mov.l @(12,r5),r12
    c.r[3] = ld32(c.r[4]);  // 060A32F4 mov.l @r4,r3
    c.r[6] += 32;  // 060A32F6 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A32F8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A32FA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A32FC mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A32FE add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3300 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A3302 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3304 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3306 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3308 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A330A add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A330C mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A330E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3310 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3312 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3314 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3316 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3318 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A331A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A331C extu.b r3,r1
    c.r[1] <<= 2;  // 060A331E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3320 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3322 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3324 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A3326 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3328 extu.b r3,r1
    c.r[1] <<= 2;  // 060A332A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A332C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A332E add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3330 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3332 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3334 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3336 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3338 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A333A add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A333C mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A333E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3340 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3342 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3344 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3346 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3348 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A334A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A334C extu.b r3,r1
    c.r[1] <<= 2;  // 060A334E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3350 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3352 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A3354 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A3356 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3358 mov.l @r4,r3
    c.r[6] += 32;  // 060A335A add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A335C extu.b r3,r1
    c.r[1] <<= 2;  // 060A335E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3360 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3362 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3364 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A3366 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3368 extu.b r3,r1
    c.r[1] <<= 2;  // 060A336A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A336C mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A336E add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3370 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A3372 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3374 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3376 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3378 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A337A add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A337C mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A337E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3380 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3382 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3384 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3386 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3388 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A338A mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A338C extu.b r3,r1
    c.r[1] <<= 2;  // 060A338E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3390 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3392 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3394 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3396 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3398 extu.b r3,r1
    c.r[1] <<= 2;  // 060A339A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A339C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A339E add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A33A0 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A33A2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33A4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A33A6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33A8 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A33AA add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A33AC mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A33AE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33B0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A33B2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33B4 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A33B6 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A33B8 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A33BA add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A33BC mov.l @r4,r3
    c.r[6] += 32;  // 060A33BE add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A33C0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A33C2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33C4 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A33C6 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A33C8 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A33CA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33CC extu.b r3,r1
    c.r[1] <<= 2;  // 060A33CE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33D0 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A33D2 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A33D4 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A33D6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33D8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A33DA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33DC mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A33DE add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A33E0 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A33E2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33E4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A33E6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33E8 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A33EA add r8,r2
    st32(c.r[6], c.r[2]);  // 060A33EC mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A33EE mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33F0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A33F2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A33F4 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A33F6 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A33F8 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A33FA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A33FC extu.b r3,r1
    c.r[1] <<= 2;  // 060A33FE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3400 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3402 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A3404 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A3406 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3408 extu.b r3,r1
    c.r[1] <<= 2;  // 060A340A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A340C mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A340E add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3410 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A3412 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3414 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3416 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3418 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A341A add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A341C mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A341E add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3420 mov.l @r4,r3
    c.r[6] += 32;  // 060A3422 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A3424 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3426 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3428 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A342A add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A342C mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A342E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3430 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3432 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3434 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3436 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3438 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A343A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A343C extu.b r3,r1
    c.r[1] <<= 2;  // 060A343E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3440 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3442 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3444 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A3446 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3448 extu.b r3,r1
    c.r[1] <<= 2;  // 060A344A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A344C mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A344E add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3450 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A3452 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3454 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3456 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3458 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A345A add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A345C mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A345E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3460 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3462 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3464 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3466 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A3468 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A346A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A346C extu.b r3,r1
    c.r[1] <<= 2;  // 060A346E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3470 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3472 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3474 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A3476 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3478 extu.b r3,r1
    c.r[1] <<= 2;  // 060A347A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A347C mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A347E add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A3480 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A3482 add r7,r4
    c.r[5] += c.r[7];  // 060A3484 add r7,r5
    c.r[5] += c.r[7];  // 060A3486 add r7,r5
    c.r[8] = ld32(c.r[5]);  // 060A3488 mov.l @r5,r8
    c.r[10] = ld32(c.r[5] + 4);  // 060A348A mov.l @(4,r5),r10
    c.r[11] = ld32(c.r[5] + 8);  // 060A348C mov.l @(8,r5),r11
    c.r[12] = ld32(c.r[5] + 12);  // 060A348E mov.l @(12,r5),r12
    c.r[3] = ld32(c.r[4]);  // 060A3490 mov.l @r4,r3
    c.r[6] += 32;  // 060A3492 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A3494 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3496 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3498 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A349A add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A349C mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A349E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34A0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A34A2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34A4 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A34A6 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A34A8 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A34AA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34AC extu.b r3,r1
    c.r[1] <<= 2;  // 060A34AE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34B0 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A34B2 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A34B4 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A34B6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34B8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A34BA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34BC mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A34BE add r8,r2
    st32(c.r[6], c.r[2]);  // 060A34C0 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A34C2 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34C4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A34C6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34C8 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A34CA add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A34CC mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A34CE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34D0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A34D2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34D4 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A34D6 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A34D8 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A34DA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34DC extu.b r3,r1
    c.r[1] <<= 2;  // 060A34DE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34E0 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A34E2 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A34E4 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A34E6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A34E8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A34EA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34EC mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A34EE add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A34F0 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A34F2 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A34F4 mov.l @r4,r3
    c.r[6] += 32;  // 060A34F6 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A34F8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A34FA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A34FC mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A34FE add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3500 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A3502 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3504 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3506 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3508 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A350A add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A350C mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A350E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3510 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3512 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3514 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3516 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3518 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A351A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A351C extu.b r3,r1
    c.r[1] <<= 2;  // 060A351E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3520 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3522 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3524 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A3526 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3528 extu.b r3,r1
    c.r[1] <<= 2;  // 060A352A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A352C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A352E add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3530 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3532 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3534 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3536 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3538 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A353A add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A353C mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A353E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3540 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3542 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3544 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3546 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3548 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A354A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A354C extu.b r3,r1
    c.r[1] <<= 2;  // 060A354E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3550 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3552 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A3554 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A3556 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3558 mov.l @r4,r3
    c.r[6] += 32;  // 060A355A add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A355C extu.b r3,r1
    c.r[1] <<= 2;  // 060A355E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3560 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3562 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3564 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A3566 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3568 extu.b r3,r1
    c.r[1] <<= 2;  // 060A356A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A356C mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A356E add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3570 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A3572 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3574 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3576 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3578 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A357A add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A357C mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A357E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3580 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3582 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3584 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3586 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3588 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A358A mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A358C extu.b r3,r1
    c.r[1] <<= 2;  // 060A358E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3590 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3592 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3594 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3596 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3598 extu.b r3,r1
    c.r[1] <<= 2;  // 060A359A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A359C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A359E add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A35A0 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A35A2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35A4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A35A6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35A8 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A35AA add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A35AC mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A35AE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35B0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A35B2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35B4 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A35B6 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A35B8 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A35BA add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A35BC mov.l @r4,r3
    c.r[6] += 32;  // 060A35BE add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A35C0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A35C2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35C4 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A35C6 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A35C8 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A35CA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35CC extu.b r3,r1
    c.r[1] <<= 2;  // 060A35CE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35D0 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A35D2 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A35D4 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A35D6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35D8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A35DA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35DC mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A35DE add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A35E0 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A35E2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35E4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A35E6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35E8 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A35EA add r8,r2
    st32(c.r[6], c.r[2]);  // 060A35EC mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A35EE mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35F0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A35F2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A35F4 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A35F6 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A35F8 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A35FA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A35FC extu.b r3,r1
    c.r[1] <<= 2;  // 060A35FE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3600 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3602 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A3604 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A3606 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3608 extu.b r3,r1
    c.r[1] <<= 2;  // 060A360A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A360C mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A360E add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3610 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A3612 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3614 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3616 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3618 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A361A add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A361C mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A361E add r7,r4
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060A3620 dt r9
    { const bool k = c.t; c.r[5] += 16; if (k) { goto L_060A3636; } }  // 060A3622 bt/s 0x060A3636 ; add #16,r5
    c.r[5] -= c.r[7];  // 060A3626 sub r7,r5
    c.r[5] -= c.r[7];  // 060A3628 sub r7,r5
    c.r[7] <<= 2;  // 060A362A shll2 r7
    c.r[4] -= c.r[7];  // 060A362C sub r7,r4
    c.r[4] -= c.r[7];  // 060A362E sub r7,r4
    c.r[7] >>= 2;  // 060A3630 shlr2 r7
    c.r[4] += 8; SH2_POLL(c); goto L_060A32EC;  // 060A3632 bra 0x060A32EC ; add #8,r4
L_060A3636:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A3636 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A3638 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A363A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A363C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A363E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A3640 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A3642 rts ; mov.l @r15+,r8
}

void f_060A3648(SH2Context& c) {
    ran[2656] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A3648 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A364A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A364C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A364E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A3650 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A3652 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A3654 mov.l r14,@-r15
    c.r[0] = ld32(0x060A3664u);  // 060A3656 mov.l 0x060A3664,r0
    c.r[9] = c.r[7];  // 060A3658 mov r7,r9
    c.r[9] >>= 2;  // 060A365A shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060A365C shlr r9
    c.r[6] -= 32; goto L_060A3668;  // 060A365E bra 0x060A3668 ; add #-32,r6
L_060A3668:
    c.r[8] = ld32(c.r[5]);  // 060A3668 mov.l @r5,r8
    c.r[10] = ld32(c.r[5] + 4);  // 060A366A mov.l @(4,r5),r10
    c.r[11] = ld32(c.r[5] + 8);  // 060A366C mov.l @(8,r5),r11
    c.r[12] = ld32(c.r[5] + 12);  // 060A366E mov.l @(12,r5),r12
    c.r[3] = ld32(c.r[4]);  // 060A3670 mov.l @r4,r3
    c.r[6] += 32;  // 060A3672 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A3674 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3676 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3678 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A367A add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A367C mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A367E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3680 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3682 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3684 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3686 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3688 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A368A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A368C extu.b r3,r1
    c.r[1] <<= 2;  // 060A368E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3690 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3692 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3694 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A3696 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3698 extu.b r3,r1
    c.r[1] <<= 2;  // 060A369A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A369C mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A369E add r8,r2
    st32(c.r[6], c.r[2]);  // 060A36A0 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A36A2 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36A4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A36A6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36A8 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A36AA add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A36AC mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A36AE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36B0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A36B2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36B4 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A36B6 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A36B8 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A36BA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36BC extu.b r3,r1
    c.r[1] <<= 2;  // 060A36BE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36C0 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A36C2 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A36C4 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A36C6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36C8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A36CA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36CC mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A36CE add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A36D0 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A36D2 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A36D4 mov.l @r4,r3
    c.r[6] += 32;  // 060A36D6 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A36D8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A36DA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36DC mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A36DE add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A36E0 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A36E2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36E4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A36E6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36E8 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A36EA add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A36EC mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A36EE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36F0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A36F2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A36F4 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A36F6 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A36F8 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A36FA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A36FC extu.b r3,r1
    c.r[1] <<= 2;  // 060A36FE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3700 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3702 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3704 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A3706 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3708 extu.b r3,r1
    c.r[1] <<= 2;  // 060A370A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A370C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A370E add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3710 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3712 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3714 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3716 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3718 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A371A add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A371C mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A371E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3720 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3722 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3724 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3726 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3728 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A372A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A372C extu.b r3,r1
    c.r[1] <<= 2;  // 060A372E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3730 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3732 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A3734 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A3736 add r7,r4
    c.r[5] += c.r[7];  // 060A3738 add r7,r5
    c.r[5] += c.r[7];  // 060A373A add r7,r5
    c.r[8] = ld32(c.r[5]);  // 060A373C mov.l @r5,r8
    c.r[10] = ld32(c.r[5] + 4);  // 060A373E mov.l @(4,r5),r10
    c.r[11] = ld32(c.r[5] + 8);  // 060A3740 mov.l @(8,r5),r11
    c.r[12] = ld32(c.r[5] + 12);  // 060A3742 mov.l @(12,r5),r12
    c.r[3] = ld32(c.r[4]);  // 060A3744 mov.l @r4,r3
    c.r[6] += 32;  // 060A3746 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A3748 extu.b r3,r1
    c.r[1] <<= 2;  // 060A374A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A374C mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A374E add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3750 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A3752 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3754 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3756 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3758 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A375A add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A375C mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A375E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3760 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3762 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3764 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3766 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3768 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A376A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A376C extu.b r3,r1
    c.r[1] <<= 2;  // 060A376E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3770 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3772 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3774 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A3776 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3778 extu.b r3,r1
    c.r[1] <<= 2;  // 060A377A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A377C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A377E add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3780 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3782 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3784 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3786 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3788 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A378A add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A378C mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A378E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3790 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3792 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3794 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3796 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3798 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A379A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A379C extu.b r3,r1
    c.r[1] <<= 2;  // 060A379E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37A0 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A37A2 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A37A4 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A37A6 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A37A8 mov.l @r4,r3
    c.r[6] += 32;  // 060A37AA add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A37AC extu.b r3,r1
    c.r[1] <<= 2;  // 060A37AE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37B0 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A37B2 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A37B4 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A37B6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A37B8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A37BA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37BC mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A37BE add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A37C0 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A37C2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A37C4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A37C6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37C8 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A37CA add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A37CC mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A37CE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A37D0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A37D2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37D4 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A37D6 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A37D8 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A37DA mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A37DC extu.b r3,r1
    c.r[1] <<= 2;  // 060A37DE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37E0 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A37E2 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A37E4 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A37E6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A37E8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A37EA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37EC mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A37EE add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A37F0 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A37F2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A37F4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A37F6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A37F8 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A37FA add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A37FC mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A37FE shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3800 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3802 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3804 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3806 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A3808 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A380A add r7,r4
    c.r[5] += c.r[7];  // 060A380C add r7,r5
    c.r[5] += c.r[7];  // 060A380E add r7,r5
    c.r[8] = ld32(c.r[5]);  // 060A3810 mov.l @r5,r8
    c.r[10] = ld32(c.r[5] + 4);  // 060A3812 mov.l @(4,r5),r10
    c.r[11] = ld32(c.r[5] + 8);  // 060A3814 mov.l @(8,r5),r11
    c.r[12] = ld32(c.r[5] + 12);  // 060A3816 mov.l @(12,r5),r12
    c.r[3] = ld32(c.r[4]);  // 060A3818 mov.l @r4,r3
    c.r[6] += 32;  // 060A381A add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A381C extu.b r3,r1
    c.r[1] <<= 2;  // 060A381E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3820 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3822 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3824 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A3826 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3828 extu.b r3,r1
    c.r[1] <<= 2;  // 060A382A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A382C mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A382E add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3830 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A3832 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3834 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3836 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3838 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A383A add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A383C mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A383E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3840 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3842 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3844 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3846 add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3848 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A384A mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A384C extu.b r3,r1
    c.r[1] <<= 2;  // 060A384E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3850 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3852 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3854 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A3856 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3858 extu.b r3,r1
    c.r[1] <<= 2;  // 060A385A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A385C mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A385E add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A3860 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A3862 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3864 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3866 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3868 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A386A add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A386C mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A386E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3870 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3872 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3874 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A3876 add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A3878 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A387A add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A387C mov.l @r4,r3
    c.r[6] += 32;  // 060A387E add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A3880 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3882 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3884 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3886 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3888 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A388A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A388C extu.b r3,r1
    c.r[1] <<= 2;  // 060A388E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3890 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3892 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3894 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A3896 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3898 extu.b r3,r1
    c.r[1] <<= 2;  // 060A389A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A389C mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A389E add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A38A0 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A38A2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A38A4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A38A6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A38A8 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A38AA add r8,r2
    st32(c.r[6], c.r[2]);  // 060A38AC mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A38AE mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A38B0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A38B2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A38B4 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A38B6 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A38B8 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A38BA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A38BC extu.b r3,r1
    c.r[1] <<= 2;  // 060A38BE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A38C0 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A38C2 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A38C4 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A38C6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A38C8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A38CA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A38CC mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A38CE add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A38D0 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A38D2 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A38D4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A38D6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A38D8 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A38DA add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A38DC mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A38DE add r7,r4
    c.r[5] += c.r[7];  // 060A38E0 add r7,r5
    c.r[5] += c.r[7];  // 060A38E2 add r7,r5
    c.r[8] = ld32(c.r[5]);  // 060A38E4 mov.l @r5,r8
    c.r[10] = ld32(c.r[5] + 4);  // 060A38E6 mov.l @(4,r5),r10
    c.r[11] = ld32(c.r[5] + 8);  // 060A38E8 mov.l @(8,r5),r11
    c.r[12] = ld32(c.r[5] + 12);  // 060A38EA mov.l @(12,r5),r12
    c.r[3] = ld32(c.r[4]);  // 060A38EC mov.l @r4,r3
    c.r[6] += 32;  // 060A38EE add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A38F0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A38F2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A38F4 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A38F6 add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A38F8 mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A38FA shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A38FC extu.b r3,r1
    c.r[1] <<= 2;  // 060A38FE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3900 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3902 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3904 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A3906 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3908 extu.b r3,r1
    c.r[1] <<= 2;  // 060A390A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A390C mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A390E add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3910 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A3912 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3914 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3916 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3918 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A391A add r8,r2
    st32(c.r[6], c.r[2]);  // 060A391C mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A391E mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3920 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3922 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3924 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3926 add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A3928 mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A392A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A392C extu.b r3,r1
    c.r[1] <<= 2;  // 060A392E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3930 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3932 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A3934 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A3936 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3938 extu.b r3,r1
    c.r[1] <<= 2;  // 060A393A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A393C mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A393E add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A3940 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A3942 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3944 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3946 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3948 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A394A add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A394C mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A394E add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3950 mov.l @r4,r3
    c.r[6] += 32;  // 060A3952 add #32,r6
    c.r[1] = c.r[3] & 0xFFu;  // 060A3954 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3956 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3958 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A395A add r10,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A395C mov.l r2,@(12,r6)
    c.r[3] >>= 8;  // 060A395E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3960 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3962 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3964 mov.l @(r0,r1),r2
    c.r[2] += c.r[10];  // 060A3966 add r10,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3968 mov.l r2,@(8,r6)
    c.r[3] >>= 8;  // 060A396A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A396C extu.b r3,r1
    c.r[1] <<= 2;  // 060A396E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3970 mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A3972 add r8,r2
    st32(c.r[6] + 4, c.r[2]);  // 060A3974 mov.l r2,@(4,r6)
    c.r[3] >>= 8;  // 060A3976 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3978 extu.b r3,r1
    c.r[1] <<= 2;  // 060A397A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A397C mov.l @(r0,r1),r2
    c.r[2] += c.r[8];  // 060A397E add r8,r2
    st32(c.r[6], c.r[2]);  // 060A3980 mov.l r2,@r6
    c.r[3] = ld32(c.r[4] + 4);  // 060A3982 mov.l @(4,r4),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3984 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3986 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3988 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A398A add r12,r2
    st32(c.r[6] + 28, c.r[2]);  // 060A398C mov.l r2,@(28,r6)
    c.r[3] >>= 8;  // 060A398E shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A3990 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3992 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3994 mov.l @(r0,r1),r2
    c.r[2] += c.r[12];  // 060A3996 add r12,r2
    st32(c.r[6] + 24, c.r[2]);  // 060A3998 mov.l r2,@(24,r6)
    c.r[3] >>= 8;  // 060A399A shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A399C extu.b r3,r1
    c.r[1] <<= 2;  // 060A399E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A39A0 mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A39A2 add r11,r2
    st32(c.r[6] + 20, c.r[2]);  // 060A39A4 mov.l r2,@(20,r6)
    c.r[3] >>= 8;  // 060A39A6 shlr8 r3
    c.r[1] = c.r[3] & 0xFFu;  // 060A39A8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A39AA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A39AC mov.l @(r0,r1),r2
    c.r[2] += c.r[11];  // 060A39AE add r11,r2
    st32(c.r[6] + 16, c.r[2]);  // 060A39B0 mov.l r2,@(16,r6)
    c.r[4] += c.r[7];  // 060A39B2 add r7,r4
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060A39B4 dt r9
    { const bool k = c.t; c.r[7] <<= 2; if (k) { goto L_060A39CE; } }  // 060A39B6 bt/s 0x060A39CE ; shll2 r7
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 060A39BA shll r7
    c.r[4] -= c.r[7];  // 060A39BC sub r7,r4
    c.r[7] >>= 2;  // 060A39BE shlr2 r7
    c.r[5] -= c.r[7];  // 060A39C0 sub r7,r5
    c.r[5] -= c.r[7];  // 060A39C2 sub r7,r5
    c.r[5] -= c.r[7];  // 060A39C4 sub r7,r5
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A39C6 shlr r7
    c.r[4] += 8;  // 060A39C8 add #8,r4
    c.r[5] += 16; SH2_POLL(c); goto L_060A3668;  // 060A39CA bra 0x060A3668 ; add #16,r5
L_060A39CE:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A39CE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A39D0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A39D2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A39D4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A39D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A39D8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A39DA rts ; mov.l @r15+,r8
}

void f_060A39E0(SH2Context& c) {
    ran[2657] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A39E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A39E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A39E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A39E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A39E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A39EA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A39EC mov.l r14,@-r15
    c.r[0] = ld32(0x060A39F8u);  // 060A39EE mov.l 0x060A39F8,r0
    c.r[9] = c.r[7];  // 060A39F0 mov r7,r9
    c.r[9] >>= 2;  // 060A39F2 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1; goto L_060A3A00;  // 060A39F4 bra 0x060A3A00 ; shlr r9
L_060A3A00:
    c.r[3] = ld32(c.r[4]);  // 060A3A00 mov.l @r4,r3
    c.r[8] = ld32(c.r[5]);  // 060A3A02 mov.l @r5,r8
    c.r[14] = ld32(c.r[4] + 4);  // 060A3A04 mov.l @(4,r4),r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3A06 extu.b r3,r1
    c.r[11] = ld32(c.r[5] + 4);  // 060A3A08 mov.l @(4,r5),r11
    c.r[1] <<= 2;  // 060A3A0A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3A0C mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3A0E shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3A10 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3A12 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3A14 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3A16 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3A18 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3A1A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3A1C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3A1E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3A20 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3A22 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3A24 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3A26 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3A28 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3A2A shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3A2C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3A2E add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3A30 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3A32 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3A34 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3A36 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3A38 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3A3A add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3A3C mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3A3E extu.b r14,r1
    c.r[1] <<= 2;  // 060A3A40 shll2 r1
    c.r[2] += c.r[8];  // 060A3A42 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3A44 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3A46 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3A48 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3A4A add r11,r13
    c.r[14] >>= 8;  // 060A3A4C shlr8 r14
    c.r[3] <<= 2;  // 060A3A4E shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3A50 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3A52 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3A54 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3A56 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3A58 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3A5A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3A5C mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3A5E extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3A60 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3A62 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3A64 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3A66 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3A68 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3A6A shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3A6C mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3A6E add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3A70 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3A72 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3A74 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3A76 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3A78 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3A7A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3A7C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3A7E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3A80 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3A82 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3A84 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3A86 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3A88 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3A8A shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3A8C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3A8E add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3A90 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3A92 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3A94 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3A96 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3A98 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3A9A add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3A9C mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3A9E extu.b r14,r1
    c.r[1] <<= 2;  // 060A3AA0 shll2 r1
    c.r[2] += c.r[8];  // 060A3AA2 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3AA4 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3AA6 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3AA8 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3AAA add r11,r13
    c.r[14] >>= 8;  // 060A3AAC shlr8 r14
    c.r[3] <<= 2;  // 060A3AAE shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3AB0 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3AB2 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3AB4 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3AB6 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3AB8 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3ABA add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3ABC mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3ABE extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3AC0 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3AC2 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3AC4 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3AC6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3AC8 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3ACA shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3ACC mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3ACE add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3AD0 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3AD2 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3AD4 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3AD6 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3AD8 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3ADA shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3ADC extu.b r3,r1
    c.r[1] <<= 2;  // 060A3ADE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3AE0 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3AE2 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3AE4 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3AE6 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3AE8 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3AEA shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3AEC mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3AEE add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3AF0 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3AF2 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3AF4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3AF6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3AF8 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3AFA add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3AFC mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3AFE extu.b r14,r1
    c.r[1] <<= 2;  // 060A3B00 shll2 r1
    c.r[2] += c.r[8];  // 060A3B02 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3B04 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3B06 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3B08 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3B0A add r11,r13
    c.r[14] >>= 8;  // 060A3B0C shlr8 r14
    c.r[3] <<= 2;  // 060A3B0E shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3B10 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3B12 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3B14 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3B16 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3B18 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3B1A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3B1C mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3B1E extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3B20 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3B22 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3B24 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3B26 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3B28 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3B2A shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3B2C mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3B2E add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3B30 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3B32 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3B34 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3B36 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3B38 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3B3A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3B3C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3B3E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3B40 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3B42 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3B44 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3B46 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3B48 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3B4A shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3B4C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3B4E add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3B50 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3B52 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3B54 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3B56 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3B58 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3B5A add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3B5C mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3B5E extu.b r14,r1
    c.r[1] <<= 2;  // 060A3B60 shll2 r1
    c.r[2] += c.r[8];  // 060A3B62 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3B64 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3B66 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3B68 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3B6A add r11,r13
    c.r[14] >>= 8;  // 060A3B6C shlr8 r14
    c.r[3] <<= 2;  // 060A3B6E shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3B70 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3B72 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3B74 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3B76 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3B78 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3B7A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3B7C mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3B7E extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3B80 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3B82 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3B84 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3B86 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3B88 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3B8A shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3B8C mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3B8E add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3B90 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3B92 shll2 r1
    c.r[5] += c.r[7];  // 060A3B94 add r7,r5
    c.r[8] = ld32(c.r[5]); c.r[5] += 4;  // 060A3B96 mov.l @r5+,r8
    c.r[11] = ld32(c.r[5]); c.r[5] += 4;  // 060A3B98 mov.l @r5+,r11
    c.r[5] -= c.r[7];  // 060A3B9A sub r7,r5
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3B9C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3B9E add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3BA0 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3BA2 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3BA4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3BA6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3BA8 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3BAA add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3BAC mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3BAE shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3BB0 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3BB2 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3BB4 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3BB6 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3BB8 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3BBA shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3BBC extu.b r3,r1
    c.r[1] <<= 2;  // 060A3BBE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3BC0 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3BC2 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3BC4 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3BC6 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3BC8 shll2 r1
    c.r[2] += c.r[8];  // 060A3BCA add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3BCC mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3BCE shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3BD0 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3BD2 add r11,r13
    c.r[14] >>= 8;  // 060A3BD4 shlr8 r14
    c.r[3] <<= 2;  // 060A3BD6 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3BD8 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3BDA shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3BDC mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3BDE add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3BE0 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3BE2 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3BE4 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3BE6 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3BE8 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3BEA add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3BEC mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3BEE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3BF0 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3BF2 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3BF4 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3BF6 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3BF8 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3BFA shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3BFC mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3BFE add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3C00 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3C02 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3C04 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3C06 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3C08 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3C0A add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3C0C mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3C0E shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3C10 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3C12 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3C14 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3C16 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3C18 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3C1A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3C1C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3C1E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3C20 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3C22 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3C24 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3C26 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3C28 shll2 r1
    c.r[2] += c.r[8];  // 060A3C2A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3C2C mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3C2E shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3C30 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3C32 add r11,r13
    c.r[14] >>= 8;  // 060A3C34 shlr8 r14
    c.r[3] <<= 2;  // 060A3C36 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3C38 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3C3A shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3C3C mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3C3E add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3C40 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3C42 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3C44 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3C46 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3C48 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3C4A add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3C4C mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3C4E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3C50 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3C52 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3C54 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3C56 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3C58 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3C5A shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3C5C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3C5E add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3C60 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3C62 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3C64 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3C66 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3C68 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3C6A add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3C6C mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3C6E shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3C70 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3C72 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3C74 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3C76 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3C78 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3C7A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3C7C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3C7E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3C80 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3C82 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3C84 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3C86 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3C88 shll2 r1
    c.r[2] += c.r[8];  // 060A3C8A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3C8C mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3C8E shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3C90 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3C92 add r11,r13
    c.r[14] >>= 8;  // 060A3C94 shlr8 r14
    c.r[3] <<= 2;  // 060A3C96 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3C98 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3C9A shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3C9C mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3C9E add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3CA0 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3CA2 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3CA4 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3CA6 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3CA8 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3CAA add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3CAC mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3CAE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3CB0 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3CB2 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3CB4 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3CB6 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3CB8 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3CBA shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3CBC mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3CBE add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3CC0 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3CC2 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3CC4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3CC6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3CC8 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3CCA add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3CCC mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3CCE shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3CD0 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3CD2 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3CD4 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3CD6 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3CD8 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3CDA shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3CDC extu.b r3,r1
    c.r[1] <<= 2;  // 060A3CDE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3CE0 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3CE2 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3CE4 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3CE6 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3CE8 shll2 r1
    c.r[2] += c.r[8];  // 060A3CEA add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3CEC mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3CEE shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3CF0 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3CF2 add r11,r13
    c.r[14] >>= 8;  // 060A3CF4 shlr8 r14
    c.r[3] <<= 2;  // 060A3CF6 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3CF8 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3CFA shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3CFC mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3CFE add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3D00 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3D02 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3D04 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3D06 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3D08 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3D0A add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3D0C mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3D0E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3D10 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3D12 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3D14 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3D16 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3D18 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3D1A shll2 r1
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060A3D1C dt r9
    { const bool k = c.t; c.r[7] <<= 2; if (k) { goto L_060A3D2C; } }  // 060A3D1E bt/s 0x060A3D2C ; shll2 r7
    c.r[4] -= c.r[7];  // 060A3D22 sub r7,r4
    c.r[4] -= c.r[7];  // 060A3D24 sub r7,r4
    c.r[7] >>= 2;  // 060A3D26 shlr2 r7
    c.r[4] += 8; SH2_POLL(c); goto L_060A3A00;  // 060A3D28 bra 0x060A3A00 ; add #8,r4
L_060A3D2C:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A3D2C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A3D2E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A3D30 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A3D32 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A3D34 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A3D36 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A3D38 rts ; mov.l @r15+,r8
}

void f_060A3D3C(SH2Context& c) {
    ran[2658] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A3D3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A3D3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A3D40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A3D42 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A3D44 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A3D46 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A3D48 mov.l r14,@-r15
    c.r[0] = ld32(0x060A3D54u);  // 060A3D4A mov.l 0x060A3D54,r0
    c.r[9] = c.r[7];  // 060A3D4C mov r7,r9
    c.r[9] >>= 2;  // 060A3D4E shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1; goto L_060A3D58;  // 060A3D50 bra 0x060A3D58 ; shlr r9
L_060A3D58:
    c.r[3] = ld32(c.r[4]);  // 060A3D58 mov.l @r4,r3
    c.r[8] = ld32(c.r[5]);  // 060A3D5A mov.l @r5,r8
    c.r[14] = ld32(c.r[4] + 4);  // 060A3D5C mov.l @(4,r4),r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3D5E extu.b r3,r1
    c.r[11] = ld32(c.r[5] + 4);  // 060A3D60 mov.l @(4,r5),r11
    c.r[1] <<= 2;  // 060A3D62 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3D64 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3D66 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3D68 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3D6A shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3D6C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3D6E add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3D70 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3D72 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3D74 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3D76 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3D78 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3D7A add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3D7C mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3D7E shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3D80 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3D82 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3D84 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3D86 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3D88 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3D8A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3D8C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3D8E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3D90 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3D92 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3D94 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3D96 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3D98 shll2 r1
    c.r[2] += c.r[8];  // 060A3D9A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3D9C mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3D9E shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3DA0 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3DA2 add r11,r13
    c.r[14] >>= 8;  // 060A3DA4 shlr8 r14
    c.r[3] <<= 2;  // 060A3DA6 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3DA8 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3DAA shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3DAC mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3DAE add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3DB0 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3DB2 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3DB4 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3DB6 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3DB8 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3DBA add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3DBC mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3DBE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3DC0 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3DC2 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3DC4 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3DC6 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3DC8 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3DCA shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3DCC mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3DCE add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3DD0 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3DD2 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3DD4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3DD6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3DD8 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3DDA add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3DDC mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3DDE shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3DE0 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3DE2 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3DE4 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3DE6 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3DE8 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3DEA shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3DEC extu.b r3,r1
    c.r[1] <<= 2;  // 060A3DEE shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3DF0 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3DF2 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3DF4 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3DF6 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3DF8 shll2 r1
    c.r[2] += c.r[8];  // 060A3DFA add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3DFC mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3DFE shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3E00 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3E02 add r11,r13
    c.r[14] >>= 8;  // 060A3E04 shlr8 r14
    c.r[3] <<= 2;  // 060A3E06 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3E08 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3E0A shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3E0C mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3E0E add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3E10 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3E12 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3E14 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3E16 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3E18 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3E1A add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3E1C mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3E1E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3E20 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3E22 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3E24 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3E26 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3E28 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3E2A shll2 r1
    c.r[5] += c.r[7];  // 060A3E2C add r7,r5
    c.r[8] = ld32(c.r[5]);  // 060A3E2E mov.l @r5,r8
    c.r[11] = ld32(c.r[5] + 4);  // 060A3E30 mov.l @(4,r5),r11
    c.r[5] += c.r[7];  // 060A3E32 add r7,r5
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3E34 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3E36 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3E38 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3E3A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3E3C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3E3E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3E40 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3E42 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3E44 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3E46 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3E48 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3E4A shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3E4C mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3E4E add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3E50 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3E52 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3E54 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3E56 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3E58 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3E5A add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3E5C mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3E5E extu.b r14,r1
    c.r[1] <<= 2;  // 060A3E60 shll2 r1
    c.r[2] += c.r[8];  // 060A3E62 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3E64 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3E66 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3E68 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3E6A add r11,r13
    c.r[14] >>= 8;  // 060A3E6C shlr8 r14
    c.r[3] <<= 2;  // 060A3E6E shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3E70 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3E72 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3E74 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3E76 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3E78 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3E7A add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3E7C mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3E7E extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3E80 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3E82 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3E84 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3E86 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3E88 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3E8A shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3E8C mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3E8E add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3E90 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3E92 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3E94 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3E96 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3E98 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3E9A shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3E9C extu.b r3,r1
    c.r[1] <<= 2;  // 060A3E9E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3EA0 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3EA2 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3EA4 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3EA6 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3EA8 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3EAA shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3EAC mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3EAE add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3EB0 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3EB2 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3EB4 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3EB6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3EB8 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3EBA add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3EBC mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3EBE extu.b r14,r1
    c.r[1] <<= 2;  // 060A3EC0 shll2 r1
    c.r[2] += c.r[8];  // 060A3EC2 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3EC4 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3EC6 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3EC8 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3ECA add r11,r13
    c.r[14] >>= 8;  // 060A3ECC shlr8 r14
    c.r[3] <<= 2;  // 060A3ECE shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3ED0 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3ED2 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3ED4 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3ED6 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3ED8 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3EDA add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3EDC mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3EDE extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3EE0 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3EE2 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3EE4 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3EE6 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3EE8 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3EEA shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3EEC mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3EEE add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3EF0 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3EF2 shll2 r1
    c.r[8] = ld32(c.r[5]);  // 060A3EF4 mov.l @r5,r8
    c.r[11] = ld32(c.r[5] + 4);  // 060A3EF6 mov.l @(4,r5),r11
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3EF8 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3EFA add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3EFC mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3EFE shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3F00 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3F02 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3F04 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3F06 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3F08 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3F0A shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3F0C extu.b r14,r1
    c.r[1] <<= 2;  // 060A3F0E shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3F10 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3F12 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3F14 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3F16 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3F18 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3F1A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3F1C mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3F1E add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3F20 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3F22 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3F24 shll2 r1
    c.r[2] += c.r[8];  // 060A3F26 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3F28 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3F2A shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3F2C mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3F2E add r11,r13
    c.r[14] >>= 8;  // 060A3F30 shlr8 r14
    c.r[3] <<= 2;  // 060A3F32 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3F34 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3F36 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3F38 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3F3A add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3F3C mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3F3E add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3F40 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3F42 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3F44 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3F46 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3F48 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3F4A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3F4C mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3F4E shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3F50 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3F52 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3F54 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3F56 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3F58 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3F5A add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3F5C mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3F5E shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3F60 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3F62 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3F64 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3F66 add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3F68 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3F6A shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3F6C extu.b r14,r1
    c.r[1] <<= 2;  // 060A3F6E shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3F70 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3F72 add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3F74 mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3F76 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3F78 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3F7A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3F7C mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3F7E add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3F80 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3F82 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3F84 shll2 r1
    c.r[2] += c.r[8];  // 060A3F86 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3F88 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3F8A shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3F8C mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3F8E add r11,r13
    c.r[14] >>= 8;  // 060A3F90 shlr8 r14
    c.r[3] <<= 2;  // 060A3F92 shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3F94 mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3F96 shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A3F98 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A3F9A add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A3F9C mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A3F9E add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A3FA0 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A3FA2 extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A3FA4 mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A3FA6 add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A3FA8 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A3FAA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3FAC mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A3FAE shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A3FB0 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A3FB2 add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A3FB4 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3FB6 shll2 r1
    c.r[5] += c.r[7];  // 060A3FB8 add r7,r5
    c.r[8] = ld32(c.r[5]);  // 060A3FBA mov.l @r5,r8
    c.r[11] = ld32(c.r[5] + 4);  // 060A3FBC mov.l @(4,r5),r11
    ;  // 060A3FBE nop
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3FC0 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3FC2 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A3FC4 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A3FC6 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3FC8 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3FCA shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3FCC mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3FCE add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A3FD0 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A3FD2 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A3FD4 extu.b r14,r1
    c.r[1] <<= 2;  // 060A3FD6 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3FD8 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A3FDA add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A3FDC mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A3FDE shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A3FE0 extu.b r3,r1
    c.r[1] <<= 2;  // 060A3FE2 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A3FE4 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A3FE6 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A3FE8 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A3FEA extu.b r14,r1
    c.r[1] <<= 2;  // 060A3FEC shll2 r1
    c.r[2] += c.r[8];  // 060A3FEE add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A3FF0 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A3FF2 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A3FF4 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A3FF6 add r11,r13
    c.r[14] >>= 8;  // 060A3FF8 shlr8 r14
    c.r[3] <<= 2;  // 060A3FFA shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A3FFC mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A3FFE shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A4000 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A4002 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A4004 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A4006 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A4008 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A400A extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A400C mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A400E add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A4010 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A4012 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A4014 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A4016 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A4018 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A401A add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A401C extu.b r14,r1
    c.r[1] <<= 2;  // 060A401E shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A4020 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A4022 add r8,r2
    st32(c.r[6] + 12, c.r[2]);  // 060A4024 mov.l r2,@(12,r6)
    c.r[14] >>= 8;  // 060A4026 shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A4028 extu.b r3,r1
    c.r[1] <<= 2;  // 060A402A shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A402C mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A402E add r11,r13
    st32(c.r[6] + 28, c.r[13]);  // 060A4030 mov.l r13,@(28,r6)
    c.r[3] >>= 8;  // 060A4032 shlr8 r3
    c.r[1] = c.r[14] & 0xFFu;  // 060A4034 extu.b r14,r1
    c.r[1] <<= 2;  // 060A4036 shll2 r1
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A4038 mov.l @(r0,r1),r13
    c.r[2] += c.r[8];  // 060A403A add r8,r2
    st32(c.r[6] + 8, c.r[2]);  // 060A403C mov.l r2,@(8,r6)
    c.r[14] >>= 8;  // 060A403E shlr8 r14
    c.r[1] = c.r[3] & 0xFFu;  // 060A4040 extu.b r3,r1
    c.r[1] <<= 2;  // 060A4042 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A4044 mov.l @(r0,r1),r2
    c.r[13] += c.r[11];  // 060A4046 add r11,r13
    st32(c.r[6] + 24, c.r[13]);  // 060A4048 mov.l r13,@(24,r6)
    c.r[1] = c.r[14] & 0xFFu;  // 060A404A extu.b r14,r1
    c.r[1] <<= 2;  // 060A404C shll2 r1
    c.r[2] += c.r[8];  // 060A404E add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[1]);  // 060A4050 mov.l @(r0,r1),r13
    c.r[3] >>= 8;  // 060A4052 shlr8 r3
    st32(c.r[6] + 4, c.r[2]);  // 060A4054 mov.l r2,@(4,r6)
    c.r[13] += c.r[11];  // 060A4056 add r11,r13
    c.r[14] >>= 8;  // 060A4058 shlr8 r14
    c.r[3] <<= 2;  // 060A405A shll2 r3
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060A405C mov.l @(r0,r3),r2
    c.r[14] <<= 2;  // 060A405E shll2 r14
    st32(c.r[6] + 20, c.r[13]);  // 060A4060 mov.l r13,@(20,r6)
    c.r[4] += c.r[7];  // 060A4062 add r7,r4
    c.r[3] = ld32(c.r[4]);  // 060A4064 mov.l @r4,r3
    c.r[2] += c.r[8];  // 060A4066 add r8,r2
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 060A4068 mov.l @(r0,r14),r13
    c.r[1] = c.r[3] & 0xFFu;  // 060A406A extu.b r3,r1
    st32(c.r[6], c.r[2]);  // 060A406C mov.l r2,@r6
    c.r[13] += c.r[11];  // 060A406E add r11,r13
    c.r[14] = ld32(c.r[4] + 4);  // 060A4070 mov.l @(4,r4),r14
    c.r[1] <<= 2;  // 060A4072 shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060A4074 mov.l @(r0,r1),r2
    c.r[3] >>= 8;  // 060A4076 shlr8 r3
    st32(c.r[6] + 16, c.r[13]);  // 060A4078 mov.l r13,@(16,r6)
    c.r[6] += 32;  // 060A407A add #32,r6
    c.r[1] = c.r[14] & 0xFFu;  // 060A407C extu.b r14,r1
    c.r[1] <<= 2;  // 060A407E shll2 r1
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060A4080 dt r9
    { const bool k = c.t; c.r[7] <<= 2; if (k) { goto L_060A4098; } }  // 060A4082 bt/s 0x060A4098 ; shll2 r7
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 060A4086 shll r7
    c.r[4] -= c.r[7];  // 060A4088 sub r7,r4
    c.r[7] >>= 2;  // 060A408A shlr2 r7
    c.r[5] -= c.r[7];  // 060A408C sub r7,r5
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060A408E shlr r7
    c.r[5] -= c.r[7];  // 060A4090 sub r7,r5
    c.r[4] += 8;  // 060A4092 add #8,r4
    c.r[5] += 8; SH2_POLL(c); goto L_060A3D58;  // 060A4094 bra 0x060A3D58 ; add #8,r5
L_060A4098:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A4098 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A409A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A409C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A409E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A40A0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A40A2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A40A4 rts ; mov.l @r15+,r8
}

void f_060A40A8(SH2Context& c) {
    ran[2659] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060A40A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060A40AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060A40AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060A40AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060A40B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A40B2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A40B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060A40B6 sts.l pr,@-r15
    c.r[15] -= 24;  // 060A40B8 add #-24,r15
    c.r[8] = c.r[4];  // 060A40BA mov r4,r8
    c.r[11] = c.r[5];  // 060A40BC mov r5,r11
    c.r[12] = c.r[6];  // 060A40BE mov r6,r12
    st32(c.r[15], c.r[7]);  // 060A40C0 mov.l r7,@r15
    c.r[10] = ld32(c.r[15]);  // 060A40C2 mov.l @r15,r10
    c.r[14] = c.r[8];  // 060A40C4 mov r8,r14
    c.r[14] += 36;  // 060A40C6 add #36,r14
    c.r[3] = c.r[8];  // 060A40C8 mov r8,r3
    c.r[3] += 40;  // 060A40CA add #40,r3
    st32(c.r[15] + 4, c.r[3]);  // 060A40CC mov.l r3,@(4,r15)
    c.r[3] = c.r[8];  // 060A40CE mov r8,r3
    c.r[3] += 38;  // 060A40D0 add #38,r3
    st32(c.r[15] + 8, c.r[3]);  // 060A40D2 mov.l r3,@(8,r15)
    c.r[3] = c.r[8];  // 060A40D4 mov r8,r3
    c.r[3] += 52;  // 060A40D6 add #52,r3
    st32(c.r[15] + 12, c.r[3]);  // 060A40D8 mov.l r3,@(12,r15)
L_060A40DA:
    c.r[1] = ld32(c.r[8] + 44);  // 060A40DA mov.l @(44,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060A40DC tst r1,r1
    if (c.t) { goto L_060A4192; }  // 060A40DE bt 0x060A4192
    c.r[1] = ld32(c.r[8] + 24);  // 060A40E0 mov.l @(24,r8),r1
    c.r[2] = ld32(c.r[8] + 4);  // 060A40E2 mov.l @(4,r8),r2
    c.r[1] <<= 2;  // 060A40E4 shll2 r1
    c.r[2] += c.r[1];  // 060A40E6 add r1,r2
    c.r[1] = ld32(c.r[8] + 8);  // 060A40E8 mov.l @(8,r8),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060A40EA cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[8] + 4, c.r[2]); if (k) { goto L_060A40F6; } }  // 060A40EC bf/s 0x060A40F6 ; mov.l r2,@(4,r8)
    c.r[0] = ld32(c.r[15]);  // 060A40F0 mov.l @r15,r0
    c.r[0] -= c.r[10]; goto L_060A4246;  // 060A40F2 bra 0x060A4246 ; sub r10,r0
L_060A40F6:
    c.r[2] = ld32(c.r[8]);  // 060A40F6 mov.l @r8,r2
    c.r[1] = c.r[2];  // 060A40F8 mov r2,r1
    c.r[1] += 1;  // 060A40FA add #1,r1
    st32(c.r[8], c.r[1]);  // 060A40FC mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A40FE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060A4100 extu.b r1,r1
    st16(c.r[14], c.r[1]);  // 060A4102 mov.w r1,@r14
    c.r[2] = ld32(c.r[8]);  // 060A4104 mov.l @r8,r2
    c.r[1] = c.r[2];  // 060A4106 mov r2,r1
    c.r[1] += 1;  // 060A4108 add #1,r1
    st32(c.r[8], c.r[1]);  // 060A410A mov.l r1,@r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A410C mov.b @r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 060A410E mov.w @r14,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060A4110 extu.b r2,r2
    c.r[2] <<= 8;  // 060A4112 shll8 r2
    c.r[1] |= c.r[2];  // 060A4114 or r2,r1
    st16(c.r[14], c.r[1]);  // 060A4116 mov.w r1,@r14
    c.r[2] = ld32(c.r[8]);  // 060A4118 mov.l @r8,r2
    c.r[1] = c.r[2];  // 060A411A mov r2,r1
    c.r[1] += 1;  // 060A411C add #1,r1
    st32(c.r[8], c.r[1]);  // 060A411E mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A4120 mov.b @r2,r1
    c.r[3] = ld32(c.r[15] + 4);  // 060A4122 mov.l @(4,r15),r3
    c.r[1] = c.r[1] & 0xFFu;  // 060A4124 extu.b r1,r1
    st16(c.r[3], c.r[1]);  // 060A4126 mov.w r1,@r3
    c.r[1] = ld32(c.r[8]);  // 060A4128 mov.l @r8,r1
    c.r[1] += 1;  // 060A412A add #1,r1
    st32(c.r[8], c.r[1]);  // 060A412C mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 060A412E mov.w @r14,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 060A4130 tst r12,r12
    st16(c.r[11], c.r[1]);  // 060A4132 mov.w r1,@r11
    { const bool k = c.t; c.r[11] += 2; if (k) { goto L_060A417E; } }  // 060A4134 bt/s 0x060A417E ; add #2,r11
    c.r[2] = ld32(c.r[8]);  // 060A4138 mov.l @r8,r2
    c.r[1] = c.r[2];  // 060A413A mov r2,r1
    c.r[1] += 1;  // 060A413C add #1,r1
    st32(c.r[8], c.r[1]);  // 060A413E mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A4140 mov.b @r2,r1
    c.r[3] = ld32(c.r[15] + 8);  // 060A4142 mov.l @(8,r15),r3
    c.r[1] = c.r[1] & 0xFFu;  // 060A4144 extu.b r1,r1
    st16(c.r[3], c.r[1]);  // 060A4146 mov.w r1,@r3
    c.r[2] = ld32(c.r[8]);  // 060A4148 mov.l @r8,r2
    c.r[1] = c.r[2];  // 060A414A mov r2,r1
    c.r[1] += 1;  // 060A414C add #1,r1
    st32(c.r[8], c.r[1]);  // 060A414E mov.l r1,@r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A4150 mov.b @r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060A4152 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060A4154 extu.b r2,r2
    c.r[2] <<= 8;  // 060A4156 shll8 r2
    c.r[1] |= c.r[2];  // 060A4158 or r2,r1
    st16(c.r[3], c.r[1]);  // 060A415A mov.w r1,@r3
    c.r[2] = ld32(c.r[8]);  // 060A415C mov.l @r8,r2
    c.r[3] = c.r[8];  // 060A415E mov r8,r3
    c.r[1] = c.r[2];  // 060A4160 mov r2,r1
    c.r[1] += 1;  // 060A4162 add #1,r1
    st32(c.r[8], c.r[1]);  // 060A4164 mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060A4166 mov.b @r2,r1
    c.r[3] += 42;  // 060A4168 add #42,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060A416A extu.b r1,r1
    st16(c.r[3], c.r[1]);  // 060A416C mov.w r1,@r3
    c.r[1] = ld32(c.r[8]);  // 060A416E mov.l @r8,r1
    c.r[1] += 1;  // 060A4170 add #1,r1
    st32(c.r[8], c.r[1]);  // 060A4172 mov.l r1,@r8
    c.r[3] = ld32(c.r[15] + 8);  // 060A4174 mov.l @(8,r15),r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060A4176 mov.w @r3,r1
    st16(c.r[12], c.r[1]);  // 060A4178 mov.w r1,@r12
    c.r[12] += 2; goto L_060A4184;  // 060A417A bra 0x060A4184 ; add #2,r12
L_060A417E:
    c.r[3] = ld32(c.r[15] + 12);  // 060A417E mov.l @(12,r15),r3
    c.r[1] = 0x1u;  // 060A4180 mov #1,r1
    st16(c.r[3], c.r[1]);  // 060A4182 mov.w r1,@r3
L_060A4184:
    c.r[1] = 0x0u;  // 060A4184 mov #0,r1
    st32(c.r[8] + 44, c.r[1]);  // 060A4186 mov.l r1,@(44,r8)
    c.r[1] = 0x1u;  // 060A4188 mov #1,r1
    c.r[10] -= 1;  // 060A418A add #-1,r10
    c.t = (int32_t)c.r[10] > 0;  // 060A418C cmp/pl r10
    { const bool k = !c.t; st32(c.r[8] + 48, c.r[1]); if (k) { goto L_060A4244; } }  // 060A418E bf/s 0x060A4244 ; mov.l r1,@(48,r8)
L_060A4192:
    c.r[1] = ld32(c.r[8] + 32);  // 060A4192 mov.l @(32,r8),r1
    c.r[2] = ld32(c.r[8] + 48);  // 060A4194 mov.l @(48,r8),r2
    c.r[9] = c.r[1];  // 060A4196 mov r1,r9
    c.r[9] -= c.r[2];  // 060A4198 sub r2,r9
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[9];  // 060A419A cmp/ge r9,r10
    if (c.t) { goto L_060A41A8; }  // 060A419C bt 0x060A41A8
    c.r[9] = c.r[10];  // 060A419E mov r10,r9
    c.r[1] = c.r[2];  // 060A41A0 mov r2,r1
    c.r[1] += c.r[10];  // 060A41A2 add r10,r1
    st32(c.r[8] + 48, c.r[1]); goto L_060A41AC;  // 060A41A4 bra 0x060A41AC ; mov.l r1,@(48,r8)
L_060A41A8:
    c.r[3] = c.t;  // 060A41A8 movt r3
    st32(c.r[8] + 44, c.r[3]);  // 060A41AA mov.l r3,@(44,r8)
L_060A41AC:
    c.t = (c.r[12] & c.r[12]) == 0;  // 060A41AC tst r12,r12
    { const bool k = c.t; c.r[10] -= c.r[9]; if (k) { goto L_060A41DC; } }  // 060A41AE bt/s 0x060A41DC ; sub r9,r10
    c.r[0] = ld32(0x060A425Cu);  // 060A41B2 mov.l 0x060A425C,r0
    c.r[7] = c.r[12];  // 060A41B4 mov r12,r7
    c.r[1] = ld32(c.r[8] + 4);  // 060A41B6 mov.l @(4,r8),r1
    c.r[6] = c.r[11];  // 060A41B8 mov r11,r6
    c.r[5] = ld32(c.r[8]);  // 060A41BA mov.l @r8,r5
    c.r[1] += c.r[9];  // 060A41BC add r9,r1
    st32(c.r[8] + 4, c.r[1]);  // 060A41BE mov.l r1,@(4,r8)
    c.r[3] = ld32(c.r[15] + 4);  // 060A41C0 mov.l @(4,r15),r3
    c.r[4] = c.r[9];  // 060A41C2 mov r9,r4
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060A41C4 mov.l r3,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060A41CAu; c.r[15] -= 4; st32(c.r[15], c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A41CAu) return; }  // 060A41C6 jsr @r0 ; mov.l r14,@-r15
    c.r[1] = c.r[9];  // 060A41CA mov r9,r1
    c.r[1] += c.r[1];  // 060A41CC add r1,r1
    c.r[12] += c.r[1];  // 060A41CE add r1,r12
    c.r[11] += c.r[1];  // 060A41D0 add r1,r11
    c.r[1] = ld32(c.r[8]);  // 060A41D2 mov.l @r8,r1
    c.r[15] += 8;  // 060A41D4 add #8,r15
    c.r[1] += c.r[9];  // 060A41D6 add r9,r1
    st32(c.r[8], c.r[1]); goto L_060A423C;  // 060A41D8 bra 0x060A423C ; mov.l r1,@r8
L_060A41DC:
    c.r[3] = c.r[9];  // 060A41DC mov r9,r3
    c.r[3] += c.r[3];  // 060A41DE add r3,r3
    st32(c.r[15] + 16, c.r[3]);  // 060A41E0 mov.l r3,@(16,r15)
    c.r[2] = c.r[9];  // 060A41E2 mov r9,r2
    c.r[3] = ld32(c.r[15] + 12);  // 060A41E4 mov.l @(12,r15),r3
    c.r[0] = ld32(0x060A4260u);  // 060A41E6 mov.l 0x060A4260,r0
    c.r[5] = ld32(c.r[8]);  // 060A41E8 mov.l @r8,r5
    c.r[6] = c.r[11];  // 060A41EA mov r11,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060A41EC mov.w @r3,r1
    c.r[13] = c.r[5];  // 060A41EE mov r5,r13
    c.r[2] += c.r[1];  // 060A41F0 add r1,r2
    c.r[1] = c.r[2];  // 060A41F2 mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 060A41F4 rotl r1
    c.r[1] = c.t;  // 060A41F6 movt r1
    c.r[2] += c.r[1];  // 060A41F8 add r1,r2
    c.r[1] = ld32(c.r[8] + 4);  // 060A41FA mov.l @(4,r8),r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060A41FC shar r2
    c.r[1] += c.r[2];  // 060A41FE add r2,r1
    st32(c.r[8] + 4, c.r[1]);  // 060A4200 mov.l r1,@(4,r8)
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060A4202 mov.w @r3,r7
    c.r[1] = c.r[9];  // 060A4204 mov r9,r1
    c.r[1] += c.r[7];  // 060A4206 add r7,r1
    c.r[2] = c.r[1];  // 060A4208 mov r1,r2
    c.t = c.r[2] >> 31; c.r[2] = c.r[2] << 1 | c.t;  // 060A420A rotl r2
    c.r[2] = c.t;  // 060A420C movt r2
    c.r[1] += c.r[2];  // 060A420E add r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060A4210 shar r1
    c.r[13] += c.r[1];  // 060A4212 add r1,r13
    c.r[1] = c.r[8];  // 060A4214 mov r8,r1
    c.r[1] += 54;  // 060A4216 add #54,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060A4218 mov.l r1,@-r15
    c.r[3] = ld32(c.r[15] + 8);  // 060A421A mov.l @(8,r15),r3
    c.r[4] = c.r[9];  // 060A421C mov r9,r4
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060A421E mov.l r3,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060A4224u; c.r[15] -= 4; st32(c.r[15], c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A4224u) return; }  // 060A4220 jsr @r0 ; mov.l r14,@-r15
    c.r[0] = c.r[9];  // 060A4224 mov r9,r0
    c.r[0] &= 0x1u;  // 060A4226 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060A4228 tst r0,r0
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_060A4236; } }  // 060A422A bt/s 0x060A4236 ; add #12,r15
    c.r[3] = ld32(c.r[15] + 12);  // 060A422E mov.l @(12,r15),r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060A4230 mov.w @r3,r0
    c.r[0] ^= 0x1u;  // 060A4232 xor #1,r0
    st16(c.r[3], c.r[0]);  // 060A4234 mov.w r0,@r3
L_060A4236:
    st32(c.r[8], c.r[13]);  // 060A4236 mov.l r13,@r8
    c.r[3] = ld32(c.r[15] + 16);  // 060A4238 mov.l @(16,r15),r3
    c.r[11] += c.r[3];  // 060A423A add r3,r11
L_060A423C:
    c.t = (int32_t)c.r[10] > 0;  // 060A423C cmp/pl r10
    if (!c.t) { goto L_060A4244; }  // 060A423E bf 0x060A4244
    SH2_POLL(c); goto L_060A40DA;  // 060A4240 bra 0x060A40DA ; nop
L_060A4244:
    c.r[0] = ld32(c.r[15]);  // 060A4244 mov.l @r15,r0
L_060A4246:
    c.r[15] += 24;  // 060A4246 add #24,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A4248 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A424A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A424C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A424E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A4250 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A4252 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A4254 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A4256 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
