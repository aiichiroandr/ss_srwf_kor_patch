#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0607C158(SH2Context& c) {
    ran[1718] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C158 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C15A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607C15C mov r15,r14
    c.r[1] = ld32(0x0607C244u);  // 0607C15E mov.l 0x0607C244,r1
    c.r[0] = ld32(c.r[1]);  // 0607C160 mov.l @r1,r0
    c.r[7] = c.r[7] & 0xFFu;  // 0607C162 extu.b r7,r7
    c.r[0] |= 0x2u;  // 0607C164 or #2,r0
    st32(c.r[1], c.r[0]);  // 0607C166 mov.l r0,@r1
    c.r[0] = ld32(0x0607C248u);  // 0607C168 mov.l 0x0607C248,r0
    c.r[1] = 0xFFFFFFFFu;  // 0607C16A mov #-1,r1
    st32(c.r[0] + 24, c.r[1]);  // 0607C16C mov.l r1,@(24,r0)
    c.r[1] = ld32(0x0607C24Cu);  // 0607C16E mov.l 0x0607C24C,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0607C170 mov.l @(12,r1),r2
    c.t = (c.r[7] & c.r[7]) == 0;  // 0607C172 tst r7,r7
    st32(c.r[0], c.r[2]);  // 0607C174 mov.l r2,@r0
    c.r[3] = ld32(c.r[1] + 16);  // 0607C176 mov.l @(16,r1),r3
    c.r[4] -= c.r[2];  // 0607C178 sub r2,r4
    st32(c.r[0] + 4, c.r[3]);  // 0607C17A mov.l r3,@(4,r0)
    c.r[1] = ld32(c.r[1] + 20);  // 0607C17C mov.l @(20,r1),r1
    c.r[5] -= c.r[3];  // 0607C17E sub r3,r5
    st32(c.r[0] + 8, c.r[1]);  // 0607C180 mov.l r1,@(8,r0)
    st32(c.r[0] + 12, c.r[4]);  // 0607C182 mov.l r4,@(12,r0)
    st32(c.r[0] + 16, c.r[5]);  // 0607C184 mov.l r5,@(16,r0)
    c.r[6] -= c.r[1];  // 0607C186 sub r1,r6
    { const bool k = c.t; st32(c.r[0] + 20, c.r[6]); if (k) { goto L_0607C192; } }  // 0607C188 bt/s 0x0607C192 ; mov.l r6,@(20,r0)
    c.r[1] = 0x0u;  // 0607C18C mov #0,r1
    st32(c.r[0] + 28, c.r[1]); goto L_0607C234;  // 0607C18E bra 0x0607C234 ; mov.l r1,@(28,r0)
L_0607C192:
    c.t = (int32_t)c.r[4] >= 0;  // 0607C192 cmp/pz r4
    { const bool k = c.t; c.r[7] = c.r[4]; if (k) { goto L_0607C19A; } }  // 0607C194 bt/s 0x0607C19A ; mov r4,r7
    c.r[7] = 0u - c.r[4];  // 0607C198 neg r4,r7
L_0607C19A:
    c.r[1] = ld32(0x0607C248u);  // 0607C19A mov.l 0x0607C248,r1
    c.r[1] = ld32(c.r[1] + 16);  // 0607C19C mov.l @(16,r1),r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607C19E cmp/pz r1
    if (c.t) { goto L_0607C1A4; }  // 0607C1A0 bt 0x0607C1A4
    c.r[1] = 0u - c.r[1];  // 0607C1A2 neg r1,r1
L_0607C1A4:
    c.t = c.r[7] >= c.r[1];  // 0607C1A4 cmp/hs r1,r7
    if (c.t) { goto L_0607C1AA; }  // 0607C1A6 bt 0x0607C1AA
    c.r[7] = c.r[1];  // 0607C1A8 mov r1,r7
L_0607C1AA:
    c.r[1] = ld32(0x0607C248u);  // 0607C1AA mov.l 0x0607C248,r1
    c.r[1] = ld32(c.r[1] + 20);  // 0607C1AC mov.l @(20,r1),r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607C1AE cmp/pz r1
    if (c.t) { goto L_0607C1B4; }  // 0607C1B0 bt 0x0607C1B4
    c.r[1] = 0u - c.r[1];  // 0607C1B2 neg r1,r1
L_0607C1B4:
    c.t = c.r[7] >= c.r[1];  // 0607C1B4 cmp/hs r1,r7
    if (c.t) { goto L_0607C1BA; }  // 0607C1B6 bt 0x0607C1BA
    c.r[7] = c.r[1];  // 0607C1B8 mov r1,r7
L_0607C1BA:
    c.r[1] = ld32(0x0607C244u);  // 0607C1BA mov.l 0x0607C244,r1
    c.r[0] = ld32(c.r[1]);  // 0607C1BC mov.l @r1,r0
    c.r[7] >>= 16;  // 0607C1BE shlr16 r7
    c.r[0] &= 0x80u;  // 0607C1C0 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607C1C2 tst r0,r0
    { const bool k = c.t; c.r[4] = c.r[7]; if (k) { goto L_0607C1D2; } }  // 0607C1C4 bt/s 0x0607C1D2 ; mov r7,r4
    c.r[2] = ld32(0x0607C250u);  // 0607C1C8 mov.l 0x0607C250,r2
    c.r[2] = ld32(c.r[2]);  // 0607C1CA mov.l @r2,r2
    c.r[1] = ld32(0x0607C248u);  // 0607C1CC mov.l 0x0607C248,r1
    st32(c.r[1] + 28, c.r[2]); goto L_0607C1E0;  // 0607C1CE bra 0x0607C1E0 ; mov.l r2,@(28,r1)
L_0607C1D2:
    c.r[2] = ld32(0x0607C248u);  // 0607C1D2 mov.l 0x0607C248,r2
    c.r[4] <<= 2;  // 0607C1D4 shll2 r4
    c.r[1] = ld32(0x0607C254u);  // 0607C1D6 mov.l 0x0607C254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C1DCu; c.r[5] = ld32(c.r[2] + 32); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C1DCu) return; }  // 0607C1D8 jsr @r1 ; mov.l @(32,r2),r5
    c.r[0] >>= 2;  // 0607C1DC shlr2 r0
    st32(c.r[2] + 28, c.r[0]);  // 0607C1DE mov.l r0,@(28,r2)
L_0607C1E0:
    c.r[2] = ld32(0x0607C244u);  // 0607C1E0 mov.l 0x0607C244,r2
    c.r[0] = ld32(c.r[2]);  // 0607C1E2 mov.l @r2,r0
    c.r[1] = 0xFFFFFFF7u;  // 0607C1E4 mov #-9,r1
    c.r[0] &= c.r[1];  // 0607C1E6 and r1,r0
    c.r[0] |= 0x4u;  // 0607C1E8 or #4,r0
    st32(c.r[2], c.r[0]);  // 0607C1EA mov.l r0,@r2
    c.r[2] = ld32(0x0607C248u);  // 0607C1EC mov.l 0x0607C248,r2
    c.r[1] = ld32(c.r[2]);  // 0607C1EE mov.l @r2,r1
    c.r[3] = ld32(0x0607C258u);  // 0607C1F0 mov.l 0x0607C258,r3
    st32(c.r[3], c.r[1]);  // 0607C1F2 mov.l r1,@r3
    c.r[1] = ld32(c.r[2] + 4);  // 0607C1F4 mov.l @(4,r2),r1
    st32(c.r[3] + 4, c.r[1]);  // 0607C1F6 mov.l r1,@(4,r3)
    c.r[1] = ld32(c.r[2] + 12);  // 0607C1F8 mov.l @(12,r2),r1
    st32(c.r[3] + 8, c.r[1]);  // 0607C1FA mov.l r1,@(8,r3)
    c.r[1] = ld32(c.r[2] + 16);  // 0607C1FC mov.l @(16,r2),r1
    c.r[6] = c.r[3];  // 0607C1FE mov r3,r6
    st32(c.r[3] + 12, c.r[1]);  // 0607C200 mov.l r1,@(12,r3)
    c.r[1] = ld32(c.r[2] + 28);  // 0607C202 mov.l @(28,r2),r1
    c.r[6] += 21;  // 0607C204 add #21,r6
    st32(c.r[3] + 16, c.r[1]);  // 0607C206 mov.l r1,@(16,r3)
    c.r[2] = c.r[7];  // 0607C208 mov r7,r2
    c.r[2] <<= 2;  // 0607C20A shll2 r2
    c.r[2] >>= 2;  // 0607C20C shlr2 r2
    c.r[2] >>= 2;  // 0607C20E shlr2 r2
    c.r[2] >>= 2;  // 0607C210 shlr2 r2
    st8(c.r[6], c.r[2]);  // 0607C212 mov.b r2,@r6
    c.r[7] = ld32(0x0607C24Cu);  // 0607C214 mov.l 0x0607C24C,r7
    c.r[1] = c.r[7];  // 0607C216 mov r7,r1
    c.r[1] += 100;  // 0607C218 add #100,r1
    c.r[3] = ld32(c.r[1]);  // 0607C21A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607C21C extu.b r2,r2
    c.r[3] += c.r[3];  // 0607C21E add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607C242u);  // 0607C220 mov.w 0x0607C242,r1
    c.r[1] -= c.r[3];  // 0607C222 sub r3,r1
    c.t = c.r[2] > c.r[1];  // 0607C224 cmp/hi r1,r2
    { const bool k = !c.t; c.r[7] += 103; if (k) { goto L_0607C234; } }  // 0607C226 bf/s 0x0607C234 ; add #103,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607C22A mov.b @r7,r2
    c.r[1] = 0xFFFFFFEEu;  // 0607C22C mov #-18,r1
    c.r[2] += c.r[2];  // 0607C22E add r2,r2
    c.r[1] -= c.r[2];  // 0607C230 sub r2,r1
    st8(c.r[6], c.r[1]);  // 0607C232 mov.b r1,@r6
L_0607C234:
    c.r[1] = ld32(0x0607C25Cu);  // 0607C234 mov.l 0x0607C25C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C23Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C23Au) return; }  // 0607C236 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607C23A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C23C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C23E rts ; mov.l @r15+,r14
}

void f_0607C260(SH2Context& c) {
    ran[1719] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607C260 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607C262 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607C264 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607C266 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C268 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C26A sts.l pr,@-r15
    c.r[8] = ld32(0x0607C300u);  // 0607C26C mov.l 0x0607C300,r8
    c.r[9] = ld32(c.r[8] + 24);  // 0607C26E mov.l @(24,r8),r9
    c.r[14] = c.r[15];  // 0607C270 mov r15,r14
    c.r[10] = ld32(c.r[8] + 28);  // 0607C272 mov.l @(28,r8),r10
    c.r[9] += 1;  // 0607C274 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 0607C276 cmp/ge r10,r9
    { const bool k = c.t; st32(c.r[8] + 24, c.r[9]); if (k) { goto L_0607C2AE; } }  // 0607C278 bt/s 0x0607C2AE ; mov.l r9,@(24,r8)
    c.r[5] = c.r[10];  // 0607C27C mov r10,r5
    c.r[7] = ld32(0x0607C304u);  // 0607C27E mov.l 0x0607C304,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0607C284u; c.r[4] = ld32(c.r[8] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C284u) return; }  // 0607C280 jsr @r7 ; mov.l @(12,r8),r4
    c.macl = c.r[0] * c.r[9];  // 0607C284 mul.l r9,r0
    c.r[6] = ld32(0x0607C308u);  // 0607C286 mov.l 0x0607C308,r6
    c.r[2] = ld32(c.r[8]);  // 0607C288 mov.l @r8,r2
    c.r[1] = c.macl;  // 0607C28A sts macl,r1
    c.r[2] += c.r[1];  // 0607C28C add r1,r2
    st32(c.r[6] + 12, c.r[2]);  // 0607C28E mov.l r2,@(12,r6)
    { const uint32_t x = c.r[7]; c.pr = 0x0607C294u; c.r[4] = ld32(c.r[8] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C294u) return; }  // 0607C290 jsr @r7 ; mov.l @(16,r8),r4
    c.macl = c.r[0] * c.r[9];  // 0607C294 mul.l r9,r0
    c.r[2] = ld32(c.r[8] + 4);  // 0607C296 mov.l @(4,r8),r2
    c.r[1] = c.macl;  // 0607C298 sts macl,r1
    c.r[2] += c.r[1];  // 0607C29A add r1,r2
    st32(c.r[6] + 16, c.r[2]);  // 0607C29C mov.l r2,@(16,r6)
    { const uint32_t x = c.r[7]; c.pr = 0x0607C2A2u; c.r[4] = ld32(c.r[8] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C2A2u) return; }  // 0607C29E jsr @r7 ; mov.l @(20,r8),r4
    c.macl = c.r[0] * c.r[9];  // 0607C2A2 mul.l r9,r0
    c.r[2] = ld32(c.r[8] + 8);  // 0607C2A4 mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 0607C2A6 sts macl,r1
    c.r[2] += c.r[1];  // 0607C2A8 add r1,r2
    st32(c.r[6] + 20, c.r[2]); goto L_0607C2EC;  // 0607C2AA bra 0x0607C2EC ; mov.l r2,@(20,r6)
L_0607C2AE:
    c.r[3] = ld32(c.r[8]);  // 0607C2AE mov.l @r8,r3
    c.r[1] = ld32(c.r[8] + 12);  // 0607C2B0 mov.l @(12,r8),r1
    c.r[2] = ld32(0x0607C308u);  // 0607C2B2 mov.l 0x0607C308,r2
    c.r[3] += c.r[1];  // 0607C2B4 add r1,r3
    st32(c.r[2] + 12, c.r[3]);  // 0607C2B6 mov.l r3,@(12,r2)
    c.r[3] = ld32(c.r[8] + 4);  // 0607C2B8 mov.l @(4,r8),r3
    c.r[1] = ld32(c.r[8] + 16);  // 0607C2BA mov.l @(16,r8),r1
    c.r[3] += c.r[1];  // 0607C2BC add r1,r3
    st32(c.r[2] + 16, c.r[3]);  // 0607C2BE mov.l r3,@(16,r2)
    c.r[3] = ld32(c.r[8] + 8);  // 0607C2C0 mov.l @(8,r8),r3
    c.r[1] = ld32(c.r[8] + 20);  // 0607C2C2 mov.l @(20,r8),r1
    c.r[3] += c.r[1];  // 0607C2C4 add r1,r3
    st32(c.r[2] + 20, c.r[3]);  // 0607C2C6 mov.l r3,@(20,r2)
    c.r[1] = 0x0u;  // 0607C2C8 mov #0,r1
    st32(c.r[8] + 28, c.r[1]);  // 0607C2CA mov.l r1,@(28,r8)
    st32(c.r[8] + 24, c.r[1]);  // 0607C2CC mov.l r1,@(24,r8)
    c.r[3] = ld32(0x0607C30Cu);  // 0607C2CE mov.l 0x0607C30C,r3
    c.r[2] = 0xFFFFFFFDu;  // 0607C2D0 mov #-3,r2
    c.r[0] = ld32(c.r[3]);  // 0607C2D2 mov.l @r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607C2FCu);  // 0607C2D4 mov.w 0x0607C2FC,r1
    c.r[2] &= c.r[0];  // 0607C2D6 and r0,r2
    c.r[2] &= c.r[1];  // 0607C2D8 and r1,r2
    c.r[0] &= 0x4u;  // 0607C2DA and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607C2DC tst r0,r0
    { const bool k = c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0607C2EC; } }  // 0607C2DE bt/s 0x0607C2EC ; mov.l r2,@r3
    c.r[1] = 0xFFFFFFFBu;  // 0607C2E2 mov #-5,r1
    c.r[2] &= c.r[1];  // 0607C2E4 and r1,r2
    c.r[11] = 0x8u;  // 0607C2E6 mov #8,r11
    c.r[2] |= c.r[11];  // 0607C2E8 or r11,r2
    st32(c.r[3], c.r[2]);  // 0607C2EA mov.l r2,@r3
L_0607C2EC:
    c.r[15] = c.r[14];  // 0607C2EC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C2EE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607C2F0 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607C2F2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607C2F4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607C2F6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C2F8 rts ; mov.l @r15+,r8
}

void f_0607C310(SH2Context& c) {
    ran[1720] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C310 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C312 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607C314 mov r15,r14
    c.r[5] = c.r[5] & 0xFFu;  // 0607C316 extu.b r5,r5
    c.r[1] = ld32(0x0607C36Cu);  // 0607C318 mov.l 0x0607C36C,r1
    c.r[0] = ld32(c.r[1]);  // 0607C31A mov.l @r1,r0
    c.r[2] = ld32(0x0607C370u);  // 0607C31C mov.l 0x0607C370,r2
    c.r[0] |= 0x10u;  // 0607C31E or #16,r0
    st32(c.r[1], c.r[0]);  // 0607C320 mov.l r0,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0607C322 mov #-1,r1
    st32(c.r[2] + 8, c.r[1]);  // 0607C324 mov.l r1,@(8,r2)
    c.r[1] = ld32(0x0607C374u);  // 0607C326 mov.l 0x0607C374,r1
    c.r[1] = ld32(c.r[1]);  // 0607C328 mov.l @r1,r1
    c.t = (c.r[5] & c.r[5]) == 0;  // 0607C32A tst r5,r5
    st32(c.r[2], c.r[1]);  // 0607C32C mov.l r1,@r2
    c.r[4] -= c.r[1];  // 0607C32E sub r1,r4
    { const bool k = c.t; st32(c.r[2] + 4, c.r[4]); if (k) { goto L_0607C33A; } }  // 0607C330 bt/s 0x0607C33A ; mov.l r4,@(4,r2)
    c.r[1] = 0x0u;  // 0607C334 mov #0,r1
    st32(c.r[2] + 12, c.r[1]); goto L_0607C35E;  // 0607C336 bra 0x0607C35E ; mov.l r1,@(12,r2)
L_0607C33A:
    c.r[0] &= 0x80u;  // 0607C33A and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607C33C tst r0,r0
    { const bool k = c.t; c.t = (int32_t)c.r[4] >= 0; if (k) { goto L_0607C34A; } }  // 0607C33E bt/s 0x0607C34A ; cmp/pz r4
    c.r[1] = ld32(0x0607C378u);  // 0607C342 mov.l 0x0607C378,r1
    c.r[1] = ld32(c.r[1]);  // 0607C344 mov.l @r1,r1
    st32(c.r[2] + 12, c.r[1]); goto L_0607C35E;  // 0607C346 bra 0x0607C35E ; mov.l r1,@(12,r2)
L_0607C34A:
    if (c.t) { goto L_0607C34E; }  // 0607C34A bt 0x0607C34E
    c.r[4] = 0u - c.r[4];  // 0607C34C neg r4,r4
L_0607C34E:
    c.r[4] >>= 16;  // 0607C34E shlr16 r4
    c.r[2] = ld32(0x0607C370u);  // 0607C350 mov.l 0x0607C370,r2
    c.r[4] <<= 2;  // 0607C352 shll2 r4
    c.r[1] = ld32(0x0607C37Cu);  // 0607C354 mov.l 0x0607C37C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C35Au; c.r[5] = ld32(c.r[2] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C35Au) return; }  // 0607C356 jsr @r1 ; mov.l @(16,r2),r5
    c.r[0] >>= 2;  // 0607C35A shlr2 r0
    st32(c.r[2] + 12, c.r[0]);  // 0607C35C mov.l r0,@(12,r2)
L_0607C35E:
    c.r[1] = ld32(0x0607C380u);  // 0607C35E mov.l 0x0607C380,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C364u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C364u) return; }  // 0607C360 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607C364 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C366 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C368 rts ; mov.l @r15+,r14
}

void f_0607C384(SH2Context& c) {
    ran[1721] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607C384 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607C386 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C388 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C38A sts.l pr,@-r15
    c.r[9] = ld32(0x0607C40Cu);  // 0607C38C mov.l 0x0607C40C,r9
    c.r[8] = ld32(c.r[9] + 8);  // 0607C38E mov.l @(8,r9),r8
    c.r[14] = c.r[15];  // 0607C390 mov r15,r14
    c.r[5] = ld32(c.r[9] + 12);  // 0607C392 mov.l @(12,r9),r5
    c.r[8] += 1;  // 0607C394 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[5];  // 0607C396 cmp/ge r5,r8
    { const bool k = c.t; st32(c.r[9] + 8, c.r[8]); if (k) { goto L_0607C3B0; } }  // 0607C398 bt/s 0x0607C3B0 ; mov.l r8,@(8,r9)
    c.r[7] = ld32(0x0607C410u);  // 0607C39C mov.l 0x0607C410,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0607C3A2u; c.r[4] = ld32(c.r[9] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C3A2u) return; }  // 0607C39E jsr @r7 ; mov.l @(4,r9),r4
    c.macl = c.r[0] * c.r[8];  // 0607C3A2 mul.l r8,r0
    c.r[6] = ld32(0x0607C414u);  // 0607C3A4 mov.l 0x0607C414,r6
    c.r[2] = ld32(c.r[9]);  // 0607C3A6 mov.l @r9,r2
    c.r[1] = c.macl;  // 0607C3A8 sts macl,r1
    c.r[2] += c.r[1];  // 0607C3AA add r1,r2
    st32(c.r[6], c.r[2]); goto L_0607C3CE;  // 0607C3AC bra 0x0607C3CE ; mov.l r2,@r6
L_0607C3B0:
    c.r[2] = ld32(c.r[9]);  // 0607C3B0 mov.l @r9,r2
    c.r[1] = ld32(c.r[9] + 4);  // 0607C3B2 mov.l @(4,r9),r1
    c.r[3] = ld32(0x0607C414u);  // 0607C3B4 mov.l 0x0607C414,r3
    c.r[2] += c.r[1];  // 0607C3B6 add r1,r2
    st32(c.r[3], c.r[2]);  // 0607C3B8 mov.l r2,@r3
    c.r[1] = 0x0u;  // 0607C3BA mov #0,r1
    st32(c.r[9] + 12, c.r[1]);  // 0607C3BC mov.l r1,@(12,r9)
    st32(c.r[9] + 8, c.r[1]);  // 0607C3BE mov.l r1,@(8,r9)
    c.r[2] = ld32(0x0607C418u);  // 0607C3C0 mov.l 0x0607C418,r2
    c.r[3] = ld32(c.r[2]);  // 0607C3C2 mov.l @r2,r3
    c.r[1] = 0xFFFFFFEFu;  // 0607C3C4 mov #-17,r1
    c.r[3] &= c.r[1];  // 0607C3C6 and r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607C408u);  // 0607C3C8 mov.w 0x0607C408,r1
    c.r[3] &= c.r[1];  // 0607C3CA and r1,r3
    st32(c.r[2], c.r[3]);  // 0607C3CC mov.l r3,@r2
L_0607C3CE:
    c.r[1] = ld32(0x0607C41Cu);  // 0607C3CE mov.l 0x0607C41C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C3D4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C3D4u) return; }  // 0607C3D0 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0607C420u);  // 0607C3D4 mov.l 0x0607C420,r8
    c.r[1] = ld32(0x0607C424u);  // 0607C3D6 mov.l 0x0607C424,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C3DCu; c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C3DCu) return; }  // 0607C3D8 jsr @r1 ; mov.w @r8,r4
    c.r[1] = c.r[8];  // 0607C3DC mov r8,r1
    c.r[1] -= 2;  // 0607C3DE add #-2,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C3E0 mov.w @r1,r4
    c.r[1] = ld32(0x0607C428u);  // 0607C3E2 mov.l 0x0607C428,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C3E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C3E8u) return; }  // 0607C3E4 jsr @r1 ; nop
    c.r[1] = c.r[8];  // 0607C3E8 mov r8,r1
    c.r[1] -= 6;  // 0607C3EA add #-6,r1
    c.r[0] = ld32(0x0607C42Cu);  // 0607C3EC mov.l 0x0607C42C,r0
    c.r[7] = c.r[8];  // 0607C3EE mov r8,r7
    c.r[7] -= 78;  // 0607C3F0 add #-78,r7
    c.r[5] = 0x0u;  // 0607C3F2 mov #0,r5
    c.r[6] = ld32(c.r[1]);  // 0607C3F4 mov.l @r1,r6
    c.r[4] = 0x0u;  // 0607C3F6 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607C3FCu; c.r[6] = 0u - c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C3FCu) return; }  // 0607C3F8 jsr @r0 ; neg r6,r6
    c.r[15] = c.r[14];  // 0607C3FC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C3FE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607C400 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607C402 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C404 rts ; mov.l @r15+,r8
}

void f_0607C430(SH2Context& c) {
    ran[1722] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C430 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C432 sts.l pr,@-r15
    c.r[1] = ld32(0x0607C464u);  // 0607C434 mov.l 0x0607C464,r1
    c.r[3] = ld32(0x0607C468u);  // 0607C436 mov.l 0x0607C468,r3
    c.r[0] = ld32(c.r[1]);  // 0607C438 mov.l @r1,r0
    c.r[2] = ld32(0x0607C46Cu);  // 0607C43A mov.l 0x0607C46C,r2
    c.r[0] |= 0x20u;  // 0607C43C or #32,r0
    st32(c.r[1], c.r[0]);  // 0607C43E mov.l r0,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0607C440 mov #-1,r1
    st32(c.r[3] + 12, c.r[1]);  // 0607C442 mov.l r1,@(12,r3)
    c.r[1] = c.r[3];  // 0607C444 mov r3,r1
    c.r[1] += 16;  // 0607C446 add #16,r1
    st8(c.r[1], c.r[4]);  // 0607C448 mov.b r4,@r1
    c.r[1] = ld32(c.r[2] + 12);  // 0607C44A mov.l @(12,r2),r1
    st32(c.r[3], c.r[1]);  // 0607C44C mov.l r1,@r3
    c.r[1] = ld32(c.r[2] + 16);  // 0607C44E mov.l @(16,r2),r1
    st32(c.r[3] + 4, c.r[1]);  // 0607C450 mov.l r1,@(4,r3)
    c.r[1] = ld32(c.r[2] + 20);  // 0607C452 mov.l @(20,r2),r1
    st32(c.r[3] + 8, c.r[1]);  // 0607C454 mov.l r1,@(8,r3)
    c.r[1] = ld32(0x0607C470u);  // 0607C456 mov.l 0x0607C470,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C45Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C45Cu) return; }  // 0607C458 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0607C45C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C45E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C460 rts ; mov.l @r15+,r14
}

void f_0607C474(SH2Context& c) {
    ran[1723] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C474 mov.l r14,@-r15
    c.r[15] -= 8;  // 0607C476 add #-8,r15
    c.r[14] = c.r[15];  // 0607C478 mov r15,r14
    c.r[3] = 0xFFFFFFFFu;  // 0607C47A mov #-1,r3
    st8(c.r[14], c.r[3]);  // 0607C47C mov.b r3,@r14
    c.r[1] = c.r[14];  // 0607C47E mov r14,r1
    c.r[1] += 1;  // 0607C480 add #1,r1
    c.r[2] = 0x1u;  // 0607C482 mov #1,r2
    st8(c.r[1], c.r[2]);  // 0607C484 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607C486 mov r14,r1
    c.r[1] += 2;  // 0607C488 add #2,r1
    st8(c.r[1], c.r[2]);  // 0607C48A mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607C48C mov r14,r1
    c.r[1] += 3;  // 0607C48E add #3,r1
    st8(c.r[1], c.r[3]);  // 0607C490 mov.b r3,@r1
    c.r[6] = c.r[14];  // 0607C492 mov r14,r6
    c.r[6] += 4;  // 0607C494 add #4,r6
    st8(c.r[6], c.r[3]);  // 0607C496 mov.b r3,@r6
    c.r[1] = c.r[14];  // 0607C498 mov r14,r1
    c.r[1] += 5;  // 0607C49A add #5,r1
    st8(c.r[1], c.r[2]);  // 0607C49C mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607C49E mov r14,r1
    c.r[1] += 6;  // 0607C4A0 add #6,r1
    st8(c.r[1], c.r[3]);  // 0607C4A2 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0607C4A4 mov r14,r1
    c.r[1] += 7;  // 0607C4A6 add #7,r1
    st8(c.r[1], c.r[2]);  // 0607C4A8 mov.b r2,@r1
    c.r[7] = ld32(0x0607C4E4u);  // 0607C4AA mov.l 0x0607C4E4,r7
    c.r[1] = c.r[7];  // 0607C4AC mov r7,r1
    c.r[0] = ld32(c.r[7] + 12);  // 0607C4AE mov.l @(12,r7),r0
    c.r[1] += 16;  // 0607C4B0 add #16,r1
    c.r[0] += 1;  // 0607C4B2 add #1,r0
    st32(c.r[7] + 12, c.r[0]);  // 0607C4B4 mov.l r0,@(12,r7)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C4B6 mov.b @r1,r2
    c.r[0] &= 0x3u;  // 0607C4B8 and #3,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607C4BA mov.b @(r0,r14),r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607C4BC extu.b r2,r2
    c.macl = c.r[3] * c.r[2];  // 0607C4BE mul.l r2,r3
    c.r[5] = ld32(0x0607C4E8u);  // 0607C4C0 mov.l 0x0607C4E8,r5
    c.r[1] = ld32(c.r[7]);  // 0607C4C2 mov.l @r7,r1
    c.r[3] = c.macl;  // 0607C4C4 sts macl,r3
    c.r[3] <<= 16;  // 0607C4C6 shll16 r3
    c.r[1] += c.r[3];  // 0607C4C8 add r3,r1
    st32(c.r[5] + 12, c.r[1]);  // 0607C4CA mov.l r1,@(12,r5)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607C4CC mov.b @(r0,r6),r1
    c.macl = c.r[1] * c.r[2];  // 0607C4CE mul.l r2,r1
    c.r[14] += 8;  // 0607C4D0 add #8,r14
    c.r[15] = c.r[14];  // 0607C4D2 mov r14,r15
    c.r[2] = c.macl;  // 0607C4D4 sts macl,r2
    c.r[1] = ld32(c.r[7] + 4);  // 0607C4D6 mov.l @(4,r7),r1
    c.r[2] <<= 16;  // 0607C4D8 shll16 r2
    c.r[1] += c.r[2];  // 0607C4DA add r2,r1
    st32(c.r[5] + 16, c.r[1]);  // 0607C4DC mov.l r1,@(16,r5)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C4DE rts ; mov.l @r15+,r14
}

void f_0607C4EC(SH2Context& c) {
    ran[1724] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C4EC mov.l r14,@-r15
    c.r[2] = ld32(0x0607C514u);  // 0607C4EE mov.l 0x0607C514,r2
    c.r[1] = ld32(c.r[2]);  // 0607C4F0 mov.l @r2,r1
    c.r[3] = ld32(0x0607C518u);  // 0607C4F2 mov.l 0x0607C518,r3
    st32(c.r[3] + 12, c.r[1]);  // 0607C4F4 mov.l r1,@(12,r3)
    c.r[1] = ld32(c.r[2] + 4);  // 0607C4F6 mov.l @(4,r2),r1
    c.r[14] = c.r[15];  // 0607C4F8 mov r15,r14
    st32(c.r[3] + 16, c.r[1]);  // 0607C4FA mov.l r1,@(16,r3)
    c.r[1] = ld32(c.r[2] + 8);  // 0607C4FC mov.l @(8,r2),r1
    st32(c.r[3] + 20, c.r[1]);  // 0607C4FE mov.l r1,@(20,r3)
    c.r[1] = 0x0u;  // 0607C500 mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 0607C502 mov.l r1,@(12,r2)
    c.r[2] = ld32(0x0607C51Cu);  // 0607C504 mov.l 0x0607C51C,r2
    c.r[3] = ld32(c.r[2]);  // 0607C506 mov.l @r2,r3
    c.r[1] = 0xFFFFFFDFu;  // 0607C508 mov #-33,r1
    c.r[3] &= c.r[1];  // 0607C50A and r1,r3
    st32(c.r[2], c.r[3]);  // 0607C50C mov.l r3,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C50E rts ; mov.l @r15+,r14
}

void f_0607C520(SH2Context& c) {
    ran[1725] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C520 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C522 sts.l pr,@-r15
    c.r[1] = ld32(0x0607C540u);  // 0607C524 mov.l 0x0607C540,r1
    c.r[1] = ld32(c.r[1]);  // 0607C526 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C528 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607C52A extu.b r1,r0
    c.r[0] <<= 2;  // 0607C52C shll2 r0
    c.r[1] = ld32(0x0607C544u);  // 0607C52E mov.l 0x0607C544,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0607C530 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607C536u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C536u) return; }  // 0607C532 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0607C536 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C538 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607C53A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0607C53C rts ; extu.w r0,r0
}

void f_0607C570(SH2Context& c) {
    ran[1726] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607C570 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607C572 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607C574 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C576 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C578 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607C57A mov r15,r14
    c.r[1] = ld32(0x0607C5D4u);  // 0607C57C mov.l 0x0607C5D4,r1
    c.r[2] = ld32(c.r[1]);  // 0607C57E mov.l @r1,r2
    c.r[8] = ld32(0x0607C5D8u);  // 0607C580 mov.l 0x0607C5D8,r8
    c.r[2] += 1;  // 0607C582 add #1,r2
    st32(c.r[1], c.r[2]);  // 0607C584 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607C586 mov.b @r2,r1
    st8(c.r[8], c.r[1]);  // 0607C588 mov.b r1,@r8
    c.r[1] = ld32(0x0607C5DCu);  // 0607C58A mov.l 0x0607C5DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C590u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C590u) return; }  // 0607C58C jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x0607C5E0u);  // 0607C590 mov.l 0x0607C5E0,r2
    c.r[1] = 0x2u;  // 0607C592 mov #2,r1
    st8(c.r[2], c.r[1]);  // 0607C594 mov.b r1,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607C596 mov.b @r8,r4
    c.r[1] = ld32(0x0607C5E4u);  // 0607C598 mov.l 0x0607C5E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C59Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C59Eu) return; }  // 0607C59A jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0607C5E8u);  // 0607C59E mov.l 0x0607C5E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C5A4u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C5A4u) return; }  // 0607C5A0 jsr @r1 ; mov #0,r8
    c.r[10] = ld32(0x0607C5ECu);  // 0607C5A4 mov.l 0x0607C5EC,r10
    c.r[9] = ld32(0x0607C5F0u);  // 0607C5A6 mov.l 0x0607C5F0,r9
    c.r[5] = c.r[8];  // 0607C5A8 mov r8,r5
L_0607C5AA:
    { const uint32_t x = c.r[10]; c.pr = 0x0607C5AEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C5AEu) return; }  // 0607C5AA jsr @r10 ; mov #0,r4
    c.r[4] = ld32(0x0607C5F4u);  // 0607C5AE mov.l 0x0607C5F4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0607C5B4u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C5B4u) return; }  // 0607C5B0 jsr @r9 ; mov r0,r5
    c.r[1] = c.r[8];  // 0607C5B4 mov r8,r1
    c.r[1] += 1;  // 0607C5B6 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0607C5B8 extu.b r1,r8
    c.r[1] = 0x3u;  // 0607C5BA mov #3,r1
    c.t = c.r[8] > c.r[1];  // 0607C5BC cmp/hi r1,r8
    { const bool k = !c.t; c.r[5] = c.r[8]; if (k) { SH2_POLL(c); goto L_0607C5AA; } }  // 0607C5BE bf/s 0x0607C5AA ; mov r8,r5
    c.r[15] = c.r[14];  // 0607C5C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C5C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607C5C6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607C5C8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607C5CA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C5D2u);  // 0607C5CC mov.w 0x0607C5D2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C5CE rts ; mov.l @r15+,r8
}

void f_0607C5F8(SH2Context& c) {
    ran[1727] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C5F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C5FA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607C5FC mov r15,r14
    c.r[5] = 0xFu;  // 0607C5FE mov #15,r5
    c.r[1] = ld32(0x0607C634u);  // 0607C600 mov.l 0x0607C634,r1
    c.r[6] = ld32(c.r[1] + 60);  // 0607C602 mov.l @(60,r1),r6
    c.r[1] = ld32(0x0607C638u);  // 0607C604 mov.l 0x0607C638,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C60Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C60Au) return; }  // 0607C606 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607C63Cu);  // 0607C60A mov.l 0x0607C63C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C60C mov.b @r1,r1
    c.r[7] = ld32(0x0607C640u);  // 0607C60E mov.l 0x0607C640,r7
    c.r[2] = ld32(c.r[7]);  // 0607C610 mov.l @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607C612 extu.b r1,r1
    c.r[1] <<= 2;  // 0607C614 shll2 r1
    c.r[3] = c.r[2];  // 0607C616 mov r2,r3
    c.r[3] += c.r[1];  // 0607C618 add r1,r3
    st32(c.r[7], c.r[3]);  // 0607C61A mov.l r3,@r7
    c.r[0] = c.r[2];  // 0607C61C mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0607C61E mov.l @(r0,r1),r1
    c.r[15] = c.r[14];  // 0607C620 mov r14,r15
    c.r[3] += c.r[1];  // 0607C622 add r1,r3
    c.r[1] = ld32(0x0607C644u);  // 0607C624 mov.l 0x0607C644,r1
    st32(c.r[1], c.r[3]);  // 0607C626 mov.l r3,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C628 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C630u);  // 0607C62A mov.w 0x0607C630,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C62C rts ; mov.l @r15+,r14
}

void f_0607C648(SH2Context& c) {
    ran[1728] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C648 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C64A sts.l pr,@-r15
    c.r[2] = ld32(0x0607C6A4u);  // 0607C64C mov.l 0x0607C6A4,r2
    c.r[1] = ld32(c.r[2]);  // 0607C64E mov.l @r2,r1
    c.r[1] += 1;  // 0607C650 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607C652 mov.l r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C654 mov.b @r1+,r2
    c.r[14] = c.r[15];  // 0607C656 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0607C658 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C65A mov.b @r1,r1
    c.r[2] <<= 2;  // 0607C65C shll2 r2
    c.r[7] = c.r[1] & 0xFFu;  // 0607C65E extu.b r1,r7
    c.r[1] = ld32(0x0607C6A8u);  // 0607C660 mov.l 0x0607C6A8,r1
    c.r[3] = ld32(c.r[1]);  // 0607C662 mov.l @r1,r3
    c.r[6] = c.r[7];  // 0607C664 mov r7,r6
    c.r[1] = ld32(0x0607C6ACu);  // 0607C666 mov.l 0x0607C6AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C668 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607C66A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607C66C tst r1,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_0607C686; } }  // 0607C66E bt/s 0x0607C686 ; add r2,r3
    c.r[7] = c.r[7] & 0xFFu;  // 0607C672 extu.b r7,r7
    c.r[1] = c.r[3];  // 0607C674 mov r3,r1
    c.r[1] += 2;  // 0607C676 add #2,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C678 mov.w @r1,r5
    c.r[6] = 0x0u;  // 0607C67A mov #0,r6
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607C67C mov.w @r3,r4
    c.r[5] <<= 16;  // 0607C67E shll16 r5
    c.r[1] = ld32(0x0607C6B0u);  // 0607C680 mov.l 0x0607C6B0,r1
    c.r[4] <<= 16; goto L_0607C694;  // 0607C682 bra 0x0607C694 ; shll16 r4
L_0607C686:
    c.r[7] = c.r[6] & 0xFFu;  // 0607C686 extu.b r6,r7
    c.r[1] = c.r[3];  // 0607C688 mov r3,r1
    c.r[1] += 2;  // 0607C68A add #2,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C68C mov.w @r1,r5
    c.r[6] = 0x0u;  // 0607C68E mov #0,r6
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607C690 mov.w @r3,r4
    c.r[1] = ld32(0x0607C6B4u);  // 0607C692 mov.l 0x0607C6B4,r1
L_0607C694:
    { const uint32_t x = c.r[1]; c.pr = 0x0607C698u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C698u) return; }  // 0607C694 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607C698 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C69A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C6A2u);  // 0607C69C mov.w 0x0607C6A2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C69E rts ; mov.l @r15+,r14
}

void f_0607C6B8(SH2Context& c) {
    ran[1729] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C6B8 mov.l r14,@-r15
    c.r[1] = ld32(0x0607C6F8u);  // 0607C6BA mov.l 0x0607C6F8,r1
    c.r[7] = ld32(c.r[1]);  // 0607C6BC mov.l @r1,r7
    c.r[14] = c.r[15];  // 0607C6BE mov r15,r14
    c.r[3] = c.r[7];  // 0607C6C0 mov r7,r3
    c.r[3] += 1;  // 0607C6C2 add #1,r3
    st32(c.r[1], c.r[3]);  // 0607C6C4 mov.l r3,@r1
    c.r[1] = c.r[3];  // 0607C6C6 mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C6C8 mov.b @r1+,r2
    c.r[6] = ld32(0x0607C6FCu);  // 0607C6CA mov.l 0x0607C6FC,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C6CC mov.b @r1,r1
    c.r[2] <<= 16;  // 0607C6CE shll16 r2
    c.r[2] <<= 8;  // 0607C6D0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607C6D2 extu.b r1,r1
    c.r[1] <<= 16;  // 0607C6D4 shll16 r1
    c.r[2] |= c.r[1];  // 0607C6D6 or r1,r2
    c.r[1] = c.r[7];  // 0607C6D8 mov r7,r1
    c.r[1] += 3;  // 0607C6DA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C6DC mov.b @r1,r1
    c.r[7] += 4;  // 0607C6DE add #4,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607C6E0 extu.b r1,r1
    c.r[1] <<= 8;  // 0607C6E2 shll8 r1
    c.r[2] |= c.r[1];  // 0607C6E4 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607C6E6 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607C6E8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607C6EA or r1,r2
    c.r[3] += c.r[2];  // 0607C6EC add r2,r3
    st32(c.r[6], c.r[3]);  // 0607C6EE mov.l r3,@r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C6F6u);  // 0607C6F0 mov.w 0x0607C6F6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C6F2 rts ; mov.l @r15+,r14
}

void f_0607C700(SH2Context& c) {
    ran[1730] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607C700 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607C702 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607C704 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C706 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C708 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607C70A mov r15,r14
    c.r[8] = 0x0u;  // 0607C70C mov #0,r8
    c.r[10] = ld32(0x0607C768u);  // 0607C70E mov.l 0x0607C768,r10
    c.r[9] = ld32(0x0607C76Cu);  // 0607C710 mov.l 0x0607C76C,r9
    c.r[5] = c.r[8] & 0xFFFFu;  // 0607C712 extu.w r8,r5
L_0607C714:
    { const uint32_t x = c.r[10]; c.pr = 0x0607C718u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C718u) return; }  // 0607C714 jsr @r10 ; mov #0,r4
    c.r[4] = ld32(0x0607C770u);  // 0607C718 mov.l 0x0607C770,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0607C71Eu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C71Eu) return; }  // 0607C71A jsr @r9 ; mov r0,r5
    c.r[8] += 1;  // 0607C71E add #1,r8
    c.r[1] = 0x4u;  // 0607C720 mov #4,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0607C722 cmp/gt r1,r8
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0607C714; } }  // 0607C724 bf/s 0x0607C714 ; extu.w r8,r5
    c.r[1] = ld32(0x0607C774u);  // 0607C728 mov.l 0x0607C774,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C72Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C72Eu) return; }  // 0607C72A jsr @r1 ; nop
    c.r[1] = ld32(0x0607C778u);  // 0607C72E mov.l 0x0607C778,r1
    c.r[6] = 0x0u;  // 0607C730 mov #0,r6
    c.r[5] = 0xFu;  // 0607C732 mov #15,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607C738u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C738u) return; }  // 0607C734 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607C77Cu);  // 0607C738 mov.l 0x0607C77C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C73Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C73Eu) return; }  // 0607C73A jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x0607C780u);  // 0607C73E mov.l 0x0607C780,r4
    c.r[1] = ld32(0x0607C784u);  // 0607C740 mov.l 0x0607C784,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C746u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C746u) return; }  // 0607C742 jsr @r1 ; nop
    c.r[2] = ld32(0x0607C788u);  // 0607C746 mov.l 0x0607C788,r2
    c.r[1] = 0x0u;  // 0607C748 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0607C74A mov.b r1,@r2
    c.r[1] = ld32(0x0607C78Cu);  // 0607C74C mov.l 0x0607C78C,r1
    c.r[6] = 0x0u;  // 0607C74E mov #0,r6
    c.r[5] = 0x0u;  // 0607C750 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607C756u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C756u) return; }  // 0607C752 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0607C756 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C758 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607C75A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607C75C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607C75E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C766u);  // 0607C760 mov.w 0x0607C766,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C762 rts ; mov.l @r15+,r8
}

void f_0607C790(SH2Context& c) {
    ran[1731] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C790 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C792 sts.l pr,@-r15
    c.r[2] = ld32(0x0607C7CCu);  // 0607C794 mov.l 0x0607C7CC,r2
    c.r[1] = ld32(c.r[2]);  // 0607C796 mov.l @r2,r1
    c.r[1] += 1;  // 0607C798 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607C79A mov.l r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C79C mov.b @r1+,r2
    c.r[14] = c.r[15];  // 0607C79E mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0607C7A0 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C7A2 mov.b @r1,r1
    c.r[2] <<= 8;  // 0607C7A4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607C7A6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607C7A8 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0607C7AA exts.w r2,r2
    c.r[1] = ld32(0x0607C7D0u);  // 0607C7AC mov.l 0x0607C7D0,r1
    c.r[1] = ld32(c.r[1]);  // 0607C7AE mov.l @r1,r1
    c.r[2] <<= 2;  // 0607C7B0 shll2 r2
    c.r[1] += c.r[2];  // 0607C7B2 add r2,r1
    c.r[2] = c.r[1];  // 0607C7B4 mov r1,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C7B6 mov.w @r1,r4
    c.r[2] += 2;  // 0607C7B8 add #2,r2
    c.r[1] = ld32(0x0607C7D4u);  // 0607C7BA mov.l 0x0607C7D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C7C0u; c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C7C0u) return; }  // 0607C7BC jsr @r1 ; mov.w @r2,r5
    c.r[15] = c.r[14];  // 0607C7C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C7C2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C7CAu);  // 0607C7C4 mov.w 0x0607C7CA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C7C6 rts ; mov.l @r15+,r14
}

void f_0607C7D8(SH2Context& c) {
    ran[1732] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C7D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C7DA sts.l pr,@-r15
    c.r[2] = ld32(0x0607C80Cu);  // 0607C7DC mov.l 0x0607C80C,r2
    c.r[3] = ld32(c.r[2]);  // 0607C7DE mov.l @r2,r3
    c.r[14] = c.r[15];  // 0607C7E0 mov r15,r14
    c.r[1] = c.r[3];  // 0607C7E2 mov r3,r1
    c.r[1] += 1;  // 0607C7E4 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607C7E6 mov.l r1,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C7E8 mov.b @r1+,r4
    c.r[3] += 3;  // 0607C7EA add #3,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607C7EC mov.b @r3,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0607C7EE extu.b r4,r4
    c.r[4] <<= 8;  // 0607C7F0 shll8 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C7F2 mov.b @r1,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0607C7F4 extu.b r5,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607C7F6 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0607C7F8 or r1,r4
    c.r[1] = ld32(0x0607C810u);  // 0607C7FA mov.l 0x0607C810,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C800u; c.r[4] <<= 16; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C800u) return; }  // 0607C7FC jsr @r1 ; shll16 r4
    c.r[15] = c.r[14];  // 0607C800 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C802 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C80Au);  // 0607C804 mov.w 0x0607C80A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C806 rts ; mov.l @r15+,r14
}

void f_0607C814(SH2Context& c) {
    ran[1733] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C814 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C816 sts.l pr,@-r15
    c.r[1] = ld32(0x0607C838u);  // 0607C818 mov.l 0x0607C838,r1
    c.r[2] = ld32(c.r[1]);  // 0607C81A mov.l @r1,r2
    c.r[14] = c.r[15];  // 0607C81C mov r15,r14
    c.r[2] += 1;  // 0607C81E add #1,r2
    st32(c.r[1], c.r[2]);  // 0607C820 mov.l r2,@r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607C822 mov.b @r2,r4
    c.r[1] = ld32(0x0607C83Cu);  // 0607C824 mov.l 0x0607C83C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C82Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C82Au) return; }  // 0607C826 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 0607C82A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C82C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C834u);  // 0607C82E mov.w 0x0607C834,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C830 rts ; mov.l @r15+,r14
}

void f_0607C840(SH2Context& c) {
    ran[1734] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C840 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C842 sts.l pr,@-r15
    c.r[1] = ld32(0x0607C860u);  // 0607C844 mov.l 0x0607C860,r1
    c.r[2] = ld32(c.r[1]);  // 0607C846 mov.l @r1,r2
    c.r[2] += 1;  // 0607C848 add #1,r2
    st32(c.r[1], c.r[2]);  // 0607C84A mov.l r2,@r1
    c.r[1] = ld32(0x0607C864u);  // 0607C84C mov.l 0x0607C864,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C852u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C852u) return; }  // 0607C84E jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0607C852 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C854 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C85Cu);  // 0607C856 mov.w 0x0607C85C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C858 rts ; mov.l @r15+,r14
}

void f_0607C868(SH2Context& c) {
    ran[1735] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C868 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C86A sts.l pr,@-r15
    c.r[2] = ld32(0x0607C8D8u);  // 0607C86C mov.l 0x0607C8D8,r2
    c.r[3] = ld32(c.r[2]);  // 0607C86E mov.l @r2,r3
    c.r[1] = c.r[3];  // 0607C870 mov r3,r1
    c.r[1] += 1;  // 0607C872 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607C874 mov.l r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C876 mov.b @r1+,r2
    c.r[14] = c.r[15];  // 0607C878 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0607C87A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C87C mov.b @r1,r1
    c.r[2] <<= 8;  // 0607C87E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607C880 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607C882 or r1,r2
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0607C884 exts.w r2,r4
    c.r[1] = c.r[3];  // 0607C886 mov r3,r1
    c.r[1] += 3;  // 0607C888 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C88A mov.b @r1,r2
    c.r[0] = c.r[4];  // 0607C88C mov r4,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0607C88E extu.b r2,r2
    c.r[2] <<= 8;  // 0607C890 shll8 r2
    c.r[1] = c.r[3];  // 0607C892 mov r3,r1
    c.r[1] += 4;  // 0607C894 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C896 mov.b @r1,r1
    c.r[3] += 5;  // 0607C898 add #5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607C89A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607C89C or r1,r2
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0607C89E exts.w r2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607C8A0 mov.b @r3,r1
    c.r[2] = c.r[5];  // 0607C8A2 mov r5,r2
    c.r[7] = c.r[1] & 0xFFu;  // 0607C8A4 extu.b r1,r7
    c.r[1] = ld32(0x0607C8DCu);  // 0607C8A6 mov.l 0x0607C8DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C8A8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607C8AA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607C8AC tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_0607C8BE; } }  // 0607C8AE bt/s 0x0607C8BE ; mov r7,r3
    c.r[7] = c.r[7] & 0xFFu;  // 0607C8B2 extu.b r7,r7
    c.r[5] <<= 16;  // 0607C8B4 shll16 r5
    c.r[4] <<= 16;  // 0607C8B6 shll16 r4
    c.r[1] = ld32(0x0607C8E0u);  // 0607C8B8 mov.l 0x0607C8E0,r1
    c.r[6] = 0x0u; goto L_0607C8C8;  // 0607C8BA bra 0x0607C8C8 ; mov #0,r6
L_0607C8BE:
    c.r[7] = c.r[3] & 0xFFu;  // 0607C8BE extu.b r3,r7
    c.r[1] = ld32(0x0607C8E4u);  // 0607C8C0 mov.l 0x0607C8E4,r1
    c.r[6] = 0x0u;  // 0607C8C2 mov #0,r6
    c.r[5] = c.r[2];  // 0607C8C4 mov r2,r5
    c.r[4] = c.r[0];  // 0607C8C6 mov r0,r4
L_0607C8C8:
    { const uint32_t x = c.r[1]; c.pr = 0x0607C8CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C8CCu) return; }  // 0607C8C8 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607C8CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C8CE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C8D6u);  // 0607C8D0 mov.w 0x0607C8D6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C8D2 rts ; mov.l @r15+,r14
}

void f_0607C8E8(SH2Context& c) {
    ran[1736] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C8E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C8EA sts.l pr,@-r15
    c.r[2] = ld32(0x0607C92Cu);  // 0607C8EC mov.l 0x0607C92C,r2
    c.r[3] = ld32(c.r[2]);  // 0607C8EE mov.l @r2,r3
    c.r[1] = c.r[3];  // 0607C8F0 mov r3,r1
    c.r[1] += 1;  // 0607C8F2 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607C8F4 mov.l r1,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C8F6 mov.b @r1+,r4
    c.r[14] = c.r[15];  // 0607C8F8 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0607C8FA extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C8FC mov.b @r1,r1
    c.r[4] <<= 8;  // 0607C8FE shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0607C900 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0607C902 or r1,r4
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 0607C904 exts.w r4,r4
    c.r[1] = c.r[3];  // 0607C906 mov r3,r1
    c.r[1] += 3;  // 0607C908 add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C90A mov.b @r1,r5
    c.r[3] += 4;  // 0607C90C add #4,r3
    c.r[5] = c.r[5] & 0xFFu;  // 0607C90E extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607C910 mov.b @r3,r1
    c.r[5] <<= 8;  // 0607C912 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607C914 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0607C916 or r1,r5
    c.r[1] = ld32(0x0607C930u);  // 0607C918 mov.l 0x0607C930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C91Eu; c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C91Eu) return; }  // 0607C91A jsr @r1 ; exts.w r5,r5
    c.r[15] = c.r[14];  // 0607C91E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C920 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C928u);  // 0607C922 mov.w 0x0607C928,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C924 rts ; mov.l @r15+,r14
}

void f_0607C934(SH2Context& c) {
    ran[1737] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C934 mov.l r14,@-r15
    c.r[1] = ld32(0x0607C98Cu);  // 0607C936 mov.l 0x0607C98C,r1
    c.r[2] = ld32(c.r[1]);  // 0607C938 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0607C93A mov r15,r14
    c.r[2] += 1;  // 0607C93C add #1,r2
    st32(c.r[1], c.r[2]);  // 0607C93E mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607C940 mov.b @r2,r1
    c.r[3] = 0x0u;  // 0607C942 mov #0,r3
    c.r[0] = c.r[1] & 0xFFu;  // 0607C944 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607C946 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0607C95C; } }  // 0607C948 bf/s 0x0607C95C ; mov r0,r1
    c.r[1] = ld32(0x0607C990u);  // 0607C94C mov.l 0x0607C990,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C94E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607C950 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607C952 tst r1,r1
    { const bool k = c.t; c.r[3] = 0x1u; if (k) { goto L_0607C964; } }  // 0607C954 bt/s 0x0607C964 ; mov #1,r3
    c.r[3] = 0x2u; goto L_0607C964;  // 0607C958 bra 0x0607C964 ; mov #2,r3
L_0607C95C:
    c.r[0] = c.r[1];  // 0607C95C mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0607C95E cmp/eq #1,r0
    if (!c.t) { goto L_0607C964; }  // 0607C960 bf 0x0607C964
    c.r[3] = 0x10u;  // 0607C962 mov #16,r3
L_0607C964:
    c.r[1] = ld32(0x0607C994u);  // 0607C964 mov.l 0x0607C994,r1
    c.r[1] = ld32(c.r[1]);  // 0607C966 mov.l @r1,r1
    c.r[1] &= c.r[3];  // 0607C968 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607C96A tst r1,r1
    if (!c.t) { goto L_0607C980; }  // 0607C96C bf 0x0607C980
    c.r[1] = ld32(0x0607C998u);  // 0607C96E mov.l 0x0607C998,r1
    c.r[1] = ld32(c.r[1]);  // 0607C970 mov.l @r1,r1
    c.r[1] &= c.r[3];  // 0607C972 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607C974 tst r1,r1
    if (!c.t) { goto L_0607C980; }  // 0607C976 bf 0x0607C980
    c.r[15] = c.r[14];  // 0607C978 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C988u);  // 0607C97A mov.w 0x0607C988,r0
    goto L_0607C984;  // 0607C97C bra 0x0607C984 ; nop
L_0607C980:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C98Au);  // 0607C980 mov.w 0x0607C98A,r0
    c.r[15] = c.r[14];  // 0607C982 mov r14,r15
L_0607C984:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C984 rts ; mov.l @r15+,r14
}

void f_0607C99C(SH2Context& c) {
    ran[1738] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C99C mov.l r14,@-r15
    c.r[3] = ld32(0x0607C9C8u);  // 0607C99E mov.l 0x0607C9C8,r3
    c.r[2] = ld32(c.r[3]);  // 0607C9A0 mov.l @r3,r2
    c.r[14] = c.r[15];  // 0607C9A2 mov r15,r14
    c.r[1] = c.r[2];  // 0607C9A4 mov r2,r1
    c.r[1] += 1;  // 0607C9A6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C9A8 mov.b @r1,r1
    c.r[2] -= 1;  // 0607C9AA add #-1,r2
    c.r[7] = c.r[1];  // 0607C9AC mov r1,r7
    c.t = (int32_t)c.r[1] > 0;  // 0607C9AE cmp/pl r1
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0607C9BA; } }  // 0607C9B0 bf/s 0x0607C9BA ; mov.l r2,@r3
    c.r[1] += 3;  // 0607C9B4 add #3,r1
    c.r[2] += c.r[1]; goto L_0607C9BC;  // 0607C9B6 bra 0x0607C9BC ; add r1,r2
L_0607C9BA:
    c.r[2] += c.r[7];  // 0607C9BA add r7,r2
L_0607C9BC:
    st32(c.r[3], c.r[2]);  // 0607C9BC mov.l r2,@r3
    c.r[15] = c.r[14];  // 0607C9BE mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607C9C6u);  // 0607C9C0 mov.w 0x0607C9C6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C9C2 rts ; mov.l @r15+,r14
}

void f_0607C9CC(SH2Context& c) {
    ran[1739] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C9CC mov.l r14,@-r15
    c.r[2] = ld32(0x0607CA30u);  // 0607C9CE mov.l 0x0607CA30,r2
    c.r[1] = ld32(c.r[2]);  // 0607C9D0 mov.l @r2,r1
    c.r[1] += 1;  // 0607C9D2 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607C9D4 mov.l r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607C9D6 mov.b @r1+,r0
    c.r[14] = c.r[15];  // 0607C9D8 mov r15,r14
    c.r[0] &= 0x10u;  // 0607C9DA and #16,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C9DC mov.b @r1,r2
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607C9DE tst r0,r0
    { const bool k = !c.t; c.r[3] = c.r[2]; if (k) { goto L_0607CA16; } }  // 0607C9E0 bf/s 0x0607CA16 ; mov r2,r3
    c.r[1] = ld32(0x0607CA34u);  // 0607C9E4 mov.l 0x0607CA34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607C9E6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607C9E8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607C9EA tst r1,r1
    if (c.t) { goto L_0607CA00; }  // 0607C9EC bt 0x0607CA00
    c.r[3] = ld32(0x0607CA38u);  // 0607C9EE mov.l 0x0607CA38,r3
    c.r[1] = ld32(c.r[3] + 32);  // 0607C9F0 mov.l @(32,r3),r1
    c.r[1] += c.r[2];  // 0607C9F2 add r2,r1
    c.t = (int32_t)c.r[1] > 0;  // 0607C9F4 cmp/pl r1
    { const bool k = c.t; st32(c.r[3] + 32, c.r[1]); if (k) { goto L_0607CA26; } }  // 0607C9F6 bt/s 0x0607CA26 ; mov.l r1,@(32,r3)
    c.r[1] = 0x1u;  // 0607C9FA mov #1,r1
    st32(c.r[3] + 32, c.r[1]); goto L_0607CA26;  // 0607C9FC bra 0x0607CA26 ; mov.l r1,@(32,r3)
L_0607CA00:
    c.r[3] = ld32(0x0607CA3Cu);  // 0607CA00 mov.l 0x0607CA3C,r3
    c.r[1] = ld32(c.r[3] + 20);  // 0607CA02 mov.l @(20,r3),r1
    c.r[2] <<= 2;  // 0607CA04 shll2 r2
    c.r[2] <<= 2;  // 0607CA06 shll2 r2
    c.r[1] += c.r[2];  // 0607CA08 add r2,r1
    c.t = (int32_t)c.r[1] > 0;  // 0607CA0A cmp/pl r1
    { const bool k = c.t; st32(c.r[3] + 20, c.r[1]); if (k) { goto L_0607CA26; } }  // 0607CA0C bt/s 0x0607CA26 ; mov.l r1,@(20,r3)
    c.r[1] = 0x1u;  // 0607CA10 mov #1,r1
    st32(c.r[3] + 20, c.r[1]); goto L_0607CA26;  // 0607CA12 bra 0x0607CA26 ; mov.l r1,@(20,r3)
L_0607CA16:
    c.r[2] = ld32(0x0607CA40u);  // 0607CA16 mov.l 0x0607CA40,r2
    c.r[1] = ld32(c.r[2] + 16);  // 0607CA18 mov.l @(16,r2),r1
    c.r[1] += c.r[3];  // 0607CA1A add r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0607CA1C cmp/pl r1
    { const bool k = c.t; st32(c.r[2] + 16, c.r[1]); if (k) { goto L_0607CA26; } }  // 0607CA1E bt/s 0x0607CA26 ; mov.l r1,@(16,r2)
    c.r[1] = 0x1u;  // 0607CA22 mov #1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0607CA24 mov.l r1,@(16,r2)
L_0607CA26:
    c.r[15] = c.r[14];  // 0607CA26 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CA2Eu);  // 0607CA28 mov.w 0x0607CA2E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607CA2A rts ; mov.l @r15+,r14
}

void f_0607CA44(SH2Context& c) {
    ran[1740] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607CA44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607CA46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607CA48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607CA4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607CA4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607CA4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607CA50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607CA52 sts.l pr,@-r15
    c.r[15] -= 4;  // 0607CA54 add #-4,r15
    c.r[14] = c.r[15];  // 0607CA56 mov r15,r14
    c.r[9] = 0x0u;  // 0607CA58 mov #0,r9
    c.r[13] = ld32(0x0607CAFCu);  // 0607CA5A mov.l 0x0607CAFC,r13
    c.r[1] = ld32(0x0607CB00u);  // 0607CA5C mov.l 0x0607CB00,r1
    c.r[8] = ld32(0x0607CB04u);  // 0607CA5E mov.l 0x0607CB04,r8
    c.r[11] = c.r[8];  // 0607CA60 mov r8,r11
    c.r[11] += 90;  // 0607CA62 add #90,r11
    c.r[12] = ld32(0x0607CB08u);  // 0607CA64 mov.l 0x0607CB08,r12
    c.r[10] = c.r[8];  // 0607CA66 mov r8,r10
    c.r[10] += 88;  // 0607CA68 add #88,r10
    c.r[0] = ld32(0x0607CB0Cu);  // 0607CA6A mov.l 0x0607CB0C,r0
    c.r[7] = c.r[13];  // 0607CA6C mov r13,r7
    c.r[5] = 0xFFFFFFFFu;  // 0607CA6E mov #-1,r5
    c.r[2] = ld32(c.r[1]);  // 0607CA70 mov.l @r1,r2
    c.r[4] = 0x10u;  // 0607CA72 mov #16,r4
    c.r[2] += 1;  // 0607CA74 add #1,r2
    st32(c.r[1], c.r[2]);  // 0607CA76 mov.l r2,@r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607CA78 mov.b @r2,r6
    c.r[1] = 0x2u;  // 0607CA7A mov #2,r1
    c.r[6] = c.r[6] & 0xFFu;  // 0607CA7C extu.b r6,r6
    st8(c.r[11], c.r[1]);  // 0607CA7E mov.b r1,@r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0607CA80 mov.w @r10,r1
    c.r[6] += 23;  // 0607CA82 add #23,r6
    st16(c.r[12], c.r[1]);  // 0607CA84 mov.w r1,@r12
    { const uint32_t x = c.r[0]; c.pr = 0x0607CA8Au; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607CA8Au) return; }  // 0607CA86 jsr @r0 ; mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607CA8A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607CA8C mov.l r9,@-r15
    c.r[1] = 0xAu;  // 0607CA8E mov #10,r1
    c.r[3] = 0x3u;  // 0607CA90 mov #3,r3
    c.r[0] = ld32(0x0607CB10u);  // 0607CA92 mov.l 0x0607CB10,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0607CA94 mov.w @r10,r2
    c.r[7] = c.r[11];  // 0607CA96 mov r11,r7
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607CA98 mulu.w r1,r2
    c.r[6] = c.r[10];  // 0607CA9A mov r10,r6
    c.r[2] = ld32(c.r[8] + 8);  // 0607CA9C mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 0607CA9E sts macl,r1
    c.r[2] += c.r[1];  // 0607CAA0 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607CAA2 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0607CAA4 mov.l @(4,r8),r1
    c.r[5] = ld32(0x0607CB14u);  // 0607CAA6 mov.l 0x0607CB14,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607CAA8 mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 0607CAAA mov.l @r8,r1
    c.r[4] = c.r[13];  // 0607CAAC mov r13,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607CAAE mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607CAB0 mov.l r3,@-r15
    c.r[3] = 0x1u;  // 0607CAB2 mov #1,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607CAB4 mov.l r3,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x0607CABAu; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607CABAu) return; }  // 0607CAB6 jsr @r0 ; mov.l r9,@-r15
    c.r[2] = ld32(0x0607CB18u);  // 0607CABA mov.l 0x0607CB18,r2
    c.r[1] = 0xFFFFFFBFu;  // 0607CABC mov #-65,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CAF2u);  // 0607CABE mov.w 0x0607CAF2,r0
    c.r[14] += 4;  // 0607CAC0 add #4,r14
    c.r[3] = ld32(c.r[2]);  // 0607CAC2 mov.l @r2,r3
    c.r[15] = c.r[14];  // 0607CAC4 mov r14,r15
    c.r[3] &= c.r[1];  // 0607CAC6 and r1,r3
    st32(c.r[2], c.r[3]);  // 0607CAC8 mov.l r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0607CACA mov.w @r12,r1
    c.r[2] = ld32(0x0607CB1Cu);  // 0607CACC mov.l 0x0607CB1C,r2
    c.r[1] += 1;  // 0607CACE add #1,r1
    st16(c.r[10], c.r[1]);  // 0607CAD0 mov.w r1,@r10
    st16(c.r[0] + c.r[2], c.r[1]);  // 0607CAD2 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CAF4u);  // 0607CAD4 mov.w 0x0607CAF4,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0607CAD6 mov.w r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CAF6u);  // 0607CAD8 mov.w 0x0607CAF6,r0
    c.r[1] = 0x18u;  // 0607CADA mov #24,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0607CADC mov.w r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607CADE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607CAE0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607CAE2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607CAE4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607CAE6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607CAE8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607CAEA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CAF8u);  // 0607CAEC mov.w 0x0607CAF8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607CAEE rts ; mov.l @r15+,r8
}

void f_0607CB20(SH2Context& c) {
    ran[1741] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607CB20 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607CB22 mov r15,r14
    c.r[1] = ld32(0x0607CB38u);  // 0607CB24 mov.l 0x0607CB38,r1
    c.r[2] = 0xFFFFFFBFu;  // 0607CB26 mov #-65,r2
    c.r[3] = ld32(c.r[1]);  // 0607CB28 mov.l @r1,r3
    c.r[3] &= c.r[2];  // 0607CB2A and r2,r3
    st32(c.r[1], c.r[3]);  // 0607CB2C mov.l r3,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CB34u);  // 0607CB2E mov.w 0x0607CB34,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607CB30 rts ; mov.l @r15+,r14
}

void f_0607CB3C(SH2Context& c) {
    ran[1742] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607CB3C mov.l r14,@-r15
    c.r[2] = ld32(0x0607CB68u);  // 0607CB3E mov.l 0x0607CB68,r2
    c.r[1] = ld32(c.r[2]);  // 0607CB40 mov.l @r2,r1
    c.r[14] = c.r[15];  // 0607CB42 mov r15,r14
    c.r[1] += 1;  // 0607CB44 add #1,r1
    st32(c.r[2], c.r[1]);  // 0607CB46 mov.l r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0607CB48 mov.b @r1+,r2
    c.r[3] = ld32(0x0607CB6Cu);  // 0607CB4A mov.l 0x0607CB6C,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607CB4C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607CB4E mov.b @r1,r1
    c.r[2] <<= 8;  // 0607CB50 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607CB52 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607CB54 or r1,r2
    st32(c.r[3], c.r[2]);  // 0607CB56 mov.l r2,@r3
    c.r[1] = ld32(0x0607CB70u);  // 0607CB58 mov.l 0x0607CB70,r1
    c.r[0] = ld32(c.r[1]);  // 0607CB5A mov.l @r1,r0
    c.r[0] |= 0x80u;  // 0607CB5C or #128,r0
    st32(c.r[1], c.r[0]);  // 0607CB5E mov.l r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CB66u);  // 0607CB60 mov.w 0x0607CB66,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607CB62 rts ; mov.l @r15+,r14
}

void f_0607CB74(SH2Context& c) {
    ran[1743] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607CB74 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607CB76 mov r15,r14
    c.r[1] = ld32(0x0607CB88u);  // 0607CB78 mov.l 0x0607CB88,r1
    c.r[0] = ld32(c.r[1]);  // 0607CB7A mov.l @r1,r0
    c.r[0] |= 0x40u;  // 0607CB7C or #64,r0
    st32(c.r[1], c.r[0]);  // 0607CB7E mov.l r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CB86u);  // 0607CB80 mov.w 0x0607CB86,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607CB82 rts ; mov.l @r15+,r14
}

void f_0607CC4C(SH2Context& c) {
    ran[1744] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607CC4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607CC4E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CC7Eu);  // 0607CC50 mov.w 0x0607CC7E,r3
    c.r[15] += c.r[3];  // 0607CC52 add r3,r15
    c.r[14] = c.r[15];  // 0607CC54 mov r15,r14
    c.r[5] = ld32(0x0607CC84u);  // 0607CC56 mov.l 0x0607CC84,r5
    c.r[1] = ld32(0x0607CC88u);  // 0607CC58 mov.l 0x0607CC88,r1
    c.r[4] = c.r[14];  // 0607CC5A mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0607CC60u; c.r[6] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607CC60u) return; }  // 0607CC5C jsr @r1 ; mov #48,r6
    c.r[1] = ld32(0x0607CC8Cu);  // 0607CC60 mov.l 0x0607CC8C,r1
    c.r[1] = ld32(c.r[1]);  // 0607CC62 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607CC64 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607CC66 extu.b r1,r0
    c.r[0] <<= 2;  // 0607CC68 shll2 r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0607CC6A mov.l @(r0,r14),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607CC70u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607CC70u) return; }  // 0607CC6C jsr @r0 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CC80u);  // 0607CC70 mov.w 0x0607CC80,r3
    c.r[14] += c.r[3];  // 0607CC72 add r3,r14
    c.r[15] = c.r[14];  // 0607CC74 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607CC76 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607CC78 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0607CC7A rts ; extu.w r0,r0
}

void f_0607CC90(SH2Context& c) {
    ran[1745] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607CC90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607CC92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607CC94 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607CC96 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607CC98 mov r15,r14
    c.r[8] = ld32(0x0607CF18u);  // 0607CC9A mov.l 0x0607CF18,r8
    c.r[2] = c.r[8];  // 0607CC9C mov r8,r2
    c.r[2] += 56;  // 0607CC9E add #56,r2
    c.r[1] = 0x0u;  // 0607CCA0 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0607CCA2 mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CE96u);  // 0607CCA4 mov.w 0x0607CE96,r0
    c.r[9] = ld32(0x0607CF1Cu);  // 0607CCA6 mov.l 0x0607CF1C,r9
    c.r[4] = ld32(0x0607CF20u);  // 0607CCA8 mov.l 0x0607CF20,r4
    c.r[1] = ld32(c.r[9]);  // 0607CCAA mov.l @r9,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCAC mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 4);  // 0607CCAE mov.l @(4,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CE98u);  // 0607CCB0 mov.w 0x0607CE98,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCB2 mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 8);  // 0607CCB4 mov.l @(8,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CE9Au);  // 0607CCB6 mov.w 0x0607CE9A,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCB8 mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 12);  // 0607CCBA mov.l @(12,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CE9Cu);  // 0607CCBC mov.w 0x0607CE9C,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCBE mov.l r1,@(r0,r8)
    c.r[0] = ld32(0x0607CF24u);  // 0607CCC0 mov.l 0x0607CF24,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607CCC6u; c.r[5] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607CCC6u) return; }  // 0607CCC2 jsr @r0 ; mov #36,r5
    c.r[1] = c.r[0];  // 0607CCC6 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CE9Eu);  // 0607CCC8 mov.w 0x0607CE9E,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCCA mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEA0u);  // 0607CCCC mov.w 0x0607CEA0,r0
    c.r[1] = ld32(0x0607CF28u);  // 0607CCCE mov.l 0x0607CF28,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCD0 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEA2u);  // 0607CCD2 mov.w 0x0607CEA2,r0
    c.r[1] = ld32(0x0607CF2Cu);  // 0607CCD4 mov.l 0x0607CF2C,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CCD6 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEA4u);  // 0607CCD8 mov.w 0x0607CEA4,r0
    c.r[1] = c.r[9];  // 0607CCDA mov r9,r1
    c.r[1] += 88;  // 0607CCDC add #88,r1
    c.r[9] += 90;  // 0607CCDE add #90,r9
    c.r[2] = c.r[8];  // 0607CCE0 mov r8,r2
    c.r[3] = 0x0u;  // 0607CCE2 mov #0,r3
    c.r[5] = 0x3u;  // 0607CCE4 mov #3,r5
    c.r[6] = 0x0u;  // 0607CCE6 mov #0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607CCE8 mov.w @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEA6u);  // 0607CCEA mov.w 0x0607CEA6,r7
    st16(c.r[0] + c.r[8], c.r[1]);  // 0607CCEC mov.w r1,@(r0,r8)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0607CCEE mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEA8u);  // 0607CCF0 mov.w 0x0607CEA8,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607CCF2 extu.b r1,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 0607CCF4 mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEAAu);  // 0607CCF6 mov.w 0x0607CEAA,r0
    c.r[2] += c.r[0];  // 0607CCF8 add r0,r2
    c.r[1] = 0x20u;  // 0607CCFA mov #32,r1
    st16(c.r[0] + c.r[8], c.r[1]);  // 0607CCFC mov.w r1,@(r0,r8)
    c.r[2] += 1;  // 0607CCFE add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607CD00 mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEACu);  // 0607CD02 mov.w 0x0607CEAC,r0
    c.r[1] += 3;  // 0607CD04 add #3,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607CD06 mov.b r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEAEu);  // 0607CD08 mov.w 0x0607CEAE,r0
    c.r[1] = ld32(0x0607CF30u);  // 0607CD0A mov.l 0x0607CF30,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0607CD0C mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEB0u);  // 0607CD0E mov.w 0x0607CEB0,r0
    c.r[1] = 0x33u;  // 0607CD10 mov #51,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607CD12 mov.b r1,@(r0,r8)
L_0607CD14:
    c.r[1] = c.r[8];  // 0607CD14 mov r8,r1
    c.r[1] += 64;  // 0607CD16 add #64,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607CD18 mov.b @r1,r0
    c.r[2] = c.r[8];  // 0607CD1A mov r8,r2
    c.r[2] += 65;  // 0607CD1C add #65,r2
    c.r[3] += 1;  // 0607CD1E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[5];  // 0607CD20 cmp/gt r5,r3
    c.r[0] &= 0x7Fu;  // 0607CD22 and #127,r0
    st8(c.r[1], c.r[0]);  // 0607CD24 mov.b r0,@r1
    c.r[1] = 0x28u;  // 0607CD26 mov #40,r1
    st8(c.r[2], c.r[1]);  // 0607CD28 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0607CD2A mov r8,r2
    c.r[2] += 66;  // 0607CD2C add #66,r2
    c.r[1] = 0x1Cu;  // 0607CD2E mov #28,r1
    st8(c.r[2], c.r[1]);  // 0607CD30 mov.b r1,@r2
    c.r[1] = c.r[8];  // 0607CD32 mov r8,r1
    c.r[1] += 67;  // 0607CD34 add #67,r1
    st8(c.r[1], c.r[6]);  // 0607CD36 mov.b r6,@r1
    c.r[1] = c.r[8];  // 0607CD38 mov r8,r1
    c.r[1] += 68;  // 0607CD3A add #68,r1
    st8(c.r[1], c.r[6]);  // 0607CD3C mov.b r6,@r1
    c.r[1] = c.r[8];  // 0607CD3E mov r8,r1
    c.r[1] += 70;  // 0607CD40 add #70,r1
    st16(c.r[1], c.r[7]);  // 0607CD42 mov.w r7,@r1
    c.r[1] = c.r[8];  // 0607CD44 mov r8,r1
    c.r[1] += 72;  // 0607CD46 add #72,r1
    st16(c.r[1], c.r[7]);  // 0607CD48 mov.w r7,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEB2u);  // 0607CD4A mov.w 0x0607CEB2,r1
    { const bool k = !c.t; c.r[8] += c.r[1]; if (k) { SH2_POLL(c); goto L_0607CD14; } }  // 0607CD4C bf/s 0x0607CD14 ; add r1,r8
    c.r[2] = ld32(0x0607CF18u);  // 0607CD50 mov.l 0x0607CF18,r2
    c.r[1] = c.r[2];  // 0607CD52 mov r2,r1
    c.r[1] += 64;  // 0607CD54 add #64,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607CD56 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEB4u);  // 0607CD58 mov.w 0x0607CEB4,r0
    c.r[3] &= c.r[0];  // 0607CD5A and r0,r3
    c.r[0] = 0x44u;  // 0607CD5C mov #68,r0
    c.r[3] |= c.r[0];  // 0607CD5E or r0,r3
    st8(c.r[1], c.r[3]);  // 0607CD60 mov.b r3,@r1
    c.r[1] = c.r[2];  // 0607CD62 mov r2,r1
    c.r[1] += 74;  // 0607CD64 add #74,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CEB6u);  // 0607CD66 mov.w 0x0607CEB6,r3
    st16(c.r[1], c.r[3]);  // 0607CD68 mov.w r3,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEA4u);  // 0607CD6A mov.w 0x0607CEA4,r1
    c.r[0] = c.r[2];  // 0607CD6C mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607CD6E mov.w @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEB8u);  // 0607CD70 mov.w 0x0607CEB8,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 0607CD72 mov.w r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEA8u);  // 0607CD74 mov.w 0x0607CEA8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607CD76 mov.w @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEBAu);  // 0607CD78 mov.w 0x0607CEBA,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 0607CD7A mov.w r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEBCu);  // 0607CD7C mov.w 0x0607CEBC,r7
    c.r[1] = ld32(0x0607CF34u);  // 0607CD7E mov.l 0x0607CF34,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CD80 mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEBEu);  // 0607CD82 mov.w 0x0607CEBE,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607CD84 mov.b @(r0,r1),r7
    c.r[4] = ld32(0x0607CF38u);  // 0607CD86 mov.l 0x0607CF38,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607CEC0u);  // 0607CD88 mov.w 0x0607CEC0,r0
    c.r[7] &= c.r[0];  // 0607CD8A and r0,r7
    c.r[0] = 0x28u;  // 0607CD8C mov #40,r0
    c.r[7] |= c.r[0];  // 0607CD8E or r0,r7
    c.r[0] = c.r[2];  // 0607CD90 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0607CD92 mov.b r7,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEC2u);  // 0607CD94 mov.w 0x0607CEC2,r1
    st16(c.r[0] + c.r[1], c.r[3]);  // 0607CD96 mov.w r3,@(r0,r1)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CEC4u);  // 0607CD98 mov.w 0x0607CEC4,r3
    c.r[1] = 0x0u;  // 0607CD9A mov #0,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0607CD9C mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CEC6u);  // 0607CD9E mov.w 0x0607CEC6,r3
    st16(c.r[0] + c.r[3], c.r[1]);  // 0607CDA0 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CEC8u);  // 0607CDA2 mov.w 0x0607CEC8,r3
    c.r[1] = ld32(0x0607CF3Cu);  // 0607CDA4 mov.l 0x0607CF3C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CDA6 mov.l r1,@(r0,r3)
    c.r[2] = ld32(0x0607CF40u);  // 0607CDA8 mov.l 0x0607CF40,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CECAu);  // 0607CDAA mov.w 0x0607CECA,r3
    c.r[1] = ld32(0x0607CF44u);  // 0607CDAC mov.l 0x0607CF44,r1
    c.r[0] = c.r[2];  // 0607CDAE mov r2,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CDB0 mov.l r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CECCu);  // 0607CDB2 mov.w 0x0607CECC,r1
    c.r[3] = ld32(0x0607CF48u);  // 0607CDB4 mov.l 0x0607CF48,r3
    st32(c.r[0] + c.r[1], c.r[3]);  // 0607CDB6 mov.l r3,@(r0,r1)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CECEu);  // 0607CDB8 mov.w 0x0607CECE,r7
    c.r[1] = ld32(0x0607CF4Cu);  // 0607CDBA mov.l 0x0607CF4C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDBC mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CED0u);  // 0607CDBE mov.w 0x0607CED0,r7
    c.r[1] = ld32(0x0607CF50u);  // 0607CDC0 mov.l 0x0607CF50,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDC2 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEB6u);  // 0607CDC4 mov.w 0x0607CEB6,r7
    c.r[1] = ld32(0x0607CF54u);  // 0607CDC6 mov.l 0x0607CF54,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDC8 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CED2u);  // 0607CDCA mov.w 0x0607CED2,r7
    c.r[1] = ld32(0x0607CF58u);  // 0607CDCC mov.l 0x0607CF58,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDCE mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CED4u);  // 0607CDD0 mov.w 0x0607CED4,r7
    c.r[1] = ld32(0x0607CF5Cu);  // 0607CDD2 mov.l 0x0607CF5C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDD4 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CED6u);  // 0607CDD6 mov.w 0x0607CED6,r7
    c.r[1] = ld32(0x0607CF60u);  // 0607CDD8 mov.l 0x0607CF60,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDDA mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CED8u);  // 0607CDDC mov.w 0x0607CED8,r7
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDDE mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEDAu);  // 0607CDE0 mov.w 0x0607CEDA,r7
    c.r[1] = ld32(0x0607CF64u);  // 0607CDE2 mov.l 0x0607CF64,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDE4 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEDCu);  // 0607CDE6 mov.w 0x0607CEDC,r7
    c.r[1] = ld32(0x0607CF68u);  // 0607CDE8 mov.l 0x0607CF68,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDEA mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEDEu);  // 0607CDEC mov.w 0x0607CEDE,r7
    c.r[1] = ld32(0x0607CF6Cu);  // 0607CDEE mov.l 0x0607CF6C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDF0 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEE0u);  // 0607CDF2 mov.w 0x0607CEE0,r7
    c.r[1] = ld32(0x0607CF70u);  // 0607CDF4 mov.l 0x0607CF70,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDF6 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEE2u);  // 0607CDF8 mov.w 0x0607CEE2,r7
    c.r[1] = ld32(0x0607CF74u);  // 0607CDFA mov.l 0x0607CF74,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CDFC mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEE4u);  // 0607CDFE mov.w 0x0607CEE4,r1
    st32(c.r[0] + c.r[1], c.r[3]);  // 0607CE00 mov.l r3,@(r0,r1)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CEE6u);  // 0607CE02 mov.w 0x0607CEE6,r3
    c.r[1] = ld32(0x0607CF78u);  // 0607CE04 mov.l 0x0607CF78,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE06 mov.l r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEE8u);  // 0607CE08 mov.w 0x0607CEE8,r1
    c.r[3] = ld32(0x0607CF7Cu);  // 0607CE0A mov.l 0x0607CF7C,r3
    st32(c.r[0] + c.r[1], c.r[3]);  // 0607CE0C mov.l r3,@(r0,r1)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEEAu);  // 0607CE0E mov.w 0x0607CEEA,r7
    c.r[1] = ld32(0x0607CF80u);  // 0607CE10 mov.l 0x0607CF80,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE12 mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CEECu);  // 0607CE14 mov.w 0x0607CEEC,r1
    st32(c.r[0] + c.r[1], c.r[3]);  // 0607CE16 mov.l r3,@(r0,r1)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEEEu);  // 0607CE18 mov.w 0x0607CEEE,r7
    c.r[1] = ld32(0x0607CF84u);  // 0607CE1A mov.l 0x0607CF84,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE1C mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEF0u);  // 0607CE1E mov.w 0x0607CEF0,r7
    c.r[1] = ld32(0x0607CF88u);  // 0607CE20 mov.l 0x0607CF88,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE22 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEF2u);  // 0607CE24 mov.w 0x0607CEF2,r7
    c.r[1] = ld32(0x0607CF8Cu);  // 0607CE26 mov.l 0x0607CF8C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE28 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEF4u);  // 0607CE2A mov.w 0x0607CEF4,r7
    c.r[1] = ld32(0x0607CF90u);  // 0607CE2C mov.l 0x0607CF90,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE2E mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEF6u);  // 0607CE30 mov.w 0x0607CEF6,r7
    c.r[1] = ld32(0x0607CF94u);  // 0607CE32 mov.l 0x0607CF94,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE34 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEF8u);  // 0607CE36 mov.w 0x0607CEF8,r7
    c.r[1] = ld32(0x0607CF98u);  // 0607CE38 mov.l 0x0607CF98,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE3A mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEFAu);  // 0607CE3C mov.w 0x0607CEFA,r7
    c.r[1] = ld32(0x0607CF9Cu);  // 0607CE3E mov.l 0x0607CF9C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE40 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEFCu);  // 0607CE42 mov.w 0x0607CEFC,r7
    c.r[1] = ld32(0x0607CFA0u);  // 0607CE44 mov.l 0x0607CFA0,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE46 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CEFEu);  // 0607CE48 mov.w 0x0607CEFE,r7
    c.r[1] = ld32(0x0607CFA4u);  // 0607CE4A mov.l 0x0607CFA4,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE4C mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CF00u);  // 0607CE4E mov.w 0x0607CF00,r7
    c.r[1] = ld32(0x0607CFA8u);  // 0607CE50 mov.l 0x0607CFA8,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE52 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607CF02u);  // 0607CE54 mov.w 0x0607CF02,r7
    c.r[1] = ld32(0x0607CFACu);  // 0607CE56 mov.l 0x0607CFAC,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0607CE58 mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607CF04u);  // 0607CE5A mov.w 0x0607CF04,r1
    st32(c.r[0] + c.r[1], c.r[3]);  // 0607CE5C mov.l r3,@(r0,r1)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF06u);  // 0607CE5E mov.w 0x0607CF06,r3
    c.r[1] = ld32(0x0607CFB0u);  // 0607CE60 mov.l 0x0607CFB0,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE62 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF08u);  // 0607CE64 mov.w 0x0607CF08,r3
    c.r[1] = ld32(0x0607CFB4u);  // 0607CE66 mov.l 0x0607CFB4,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE68 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF0Au);  // 0607CE6A mov.w 0x0607CF0A,r3
    c.r[1] = ld32(0x0607CFB8u);  // 0607CE6C mov.l 0x0607CFB8,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE6E mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF0Cu);  // 0607CE70 mov.w 0x0607CF0C,r3
    c.r[1] = ld32(0x0607CFBCu);  // 0607CE72 mov.l 0x0607CFBC,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE74 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF0Eu);  // 0607CE76 mov.w 0x0607CF0E,r3
    c.r[1] = ld32(0x0607CFC0u);  // 0607CE78 mov.l 0x0607CFC0,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE7A mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF10u);  // 0607CE7C mov.w 0x0607CF10,r3
    c.r[1] = ld32(0x0607CFC4u);  // 0607CE7E mov.l 0x0607CFC4,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE80 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF12u);  // 0607CE82 mov.w 0x0607CF12,r3
    c.r[1] = ld32(0x0607CFC8u);  // 0607CE84 mov.l 0x0607CFC8,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE86 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF14u);  // 0607CE88 mov.w 0x0607CF14,r3
    c.r[1] = ld32(0x0607CFCCu);  // 0607CE8A mov.l 0x0607CFCC,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CE8C mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607CF16u);  // 0607CE8E mov.w 0x0607CF16,r3
    c.r[1] = ld32(0x0607CFD0u);  // 0607CE90 mov.l 0x0607CFD0,r1
    st32(c.r[0] + c.r[3], c.r[1]); goto L_0607CFD4;  // 0607CE92 bra 0x0607CFD4 ; mov.l r1,@(r0,r3)
L_0607CFD4:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D078u);  // 0607CFD4 mov.w 0x0607D078,r3
    c.r[1] = ld32(0x0607D084u);  // 0607CFD6 mov.l 0x0607D084,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CFD8 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D07Au);  // 0607CFDA mov.w 0x0607D07A,r3
    c.r[1] = ld32(0x0607D088u);  // 0607CFDC mov.l 0x0607D088,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CFDE mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D07Cu);  // 0607CFE0 mov.w 0x0607D07C,r3
    c.r[1] = ld32(0x0607D08Cu);  // 0607CFE2 mov.l 0x0607D08C,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 0607CFE4 mov.l r1,@(r0,r3)
    c.r[1] = ld32(0x0607D090u);  // 0607CFE6 mov.l 0x0607D090,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607CFECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607CFECu) return; }  // 0607CFE8 jsr @r1 ; nop
    c.r[1] = ld32(0x0607D094u);  // 0607CFEC mov.l 0x0607D094,r1
    c.r[2] = ld32(c.r[1]);  // 0607CFEE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D07Eu);  // 0607CFF0 mov.w 0x0607D07E,r1
    c.r[0] = c.r[2];  // 0607CFF2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607CFF4 mov.b @(r0,r1),r1
    c.r[0] = 0x8u;  // 0607CFF6 mov #8,r0
    c.r[1] &= c.r[0];  // 0607CFF8 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607CFFA tst r1,r1
    { const bool k = c.t; c.r[1] = 0x5u; if (k) { goto L_0607D006; } }  // 0607CFFC bt/s 0x0607D006 ; mov #5,r1
    c.r[2] = ld32(0x0607D098u);  // 0607D000 mov.l 0x0607D098,r2
    c.r[1] = 0xAu; goto L_0607D008;  // 0607D002 bra 0x0607D008 ; mov #10,r1
L_0607D006:
    c.r[2] = ld32(0x0607D098u);  // 0607D006 mov.l 0x0607D098,r2
L_0607D008:
    st8(c.r[2], c.r[1]);  // 0607D008 mov.b r1,@r2
    c.r[1] = ld32(0x0607D094u);  // 0607D00A mov.l 0x0607D094,r1
    c.r[2] = ld32(c.r[1]);  // 0607D00C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D07Eu);  // 0607D00E mov.w 0x0607D07E,r1
    c.r[0] = c.r[2];  // 0607D010 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D012 mov.b @(r0,r1),r1
    c.r[0] = 0x8u;  // 0607D014 mov #8,r0
    c.r[1] &= c.r[0];  // 0607D016 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607D018 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x5u; if (k) { goto L_0607D024; } }  // 0607D01A bt/s 0x0607D024 ; mov #5,r1
    c.r[2] = ld32(0x0607D09Cu);  // 0607D01E mov.l 0x0607D09C,r2
    c.r[1] = 0xAu; goto L_0607D026;  // 0607D020 bra 0x0607D026 ; mov #10,r1
L_0607D024:
    c.r[2] = ld32(0x0607D09Cu);  // 0607D024 mov.l 0x0607D09C,r2
L_0607D026:
    st8(c.r[2], c.r[1]);  // 0607D026 mov.b r1,@r2
    c.r[7] = ld32(0x0607D0A0u);  // 0607D028 mov.l 0x0607D0A0,r7
    c.r[6] = 0x0u;  // 0607D02A mov #0,r6
    st8(c.r[7], c.r[6]);  // 0607D02C mov.b r6,@r7
    c.r[3] = ld32(0x0607D0A4u);  // 0607D02E mov.l 0x0607D0A4,r3
    c.r[1] = ld32(c.r[3]);  // 0607D030 mov.l @r3,r1
    c.r[1] += 7;  // 0607D032 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D034 mov.b @r1,r2
    c.r[0] = 0x4u;  // 0607D036 mov #4,r0
    c.r[2] |= c.r[0];  // 0607D038 or r0,r2
    st8(c.r[1], c.r[2]);  // 0607D03A mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607D03C mov.b @r7,r1
    c.r[2] = ld32(c.r[3]);  // 0607D03E mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D040 extu.b r1,r1
    c.r[1] <<= 2;  // 0607D042 shll2 r1
    c.r[1] <<= 2;  // 0607D044 shll2 r1
    c.r[1] += c.r[2];  // 0607D046 add r2,r1
    c.r[1] += 2;  // 0607D048 add #2,r1
    st8(c.r[1], c.r[6]);  // 0607D04A mov.b r6,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607D04C mov.b @r7,r1
    c.r[2] = ld32(c.r[3]);  // 0607D04E mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D050 extu.b r1,r1
    c.r[1] <<= 2;  // 0607D052 shll2 r1
    c.r[1] <<= 2;  // 0607D054 shll2 r1
    c.r[0] = c.r[1];  // 0607D056 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[6]);  // 0607D058 mov.b r6,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607D05A mov.b @r7,r1
    c.r[15] = c.r[14];  // 0607D05C mov r14,r15
    c.r[2] = ld32(c.r[3]);  // 0607D05E mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D060 extu.b r1,r1
    c.r[1] <<= 2;  // 0607D062 shll2 r1
    c.r[1] <<= 2;  // 0607D064 shll2 r1
    c.r[1] += c.r[2];  // 0607D066 add r2,r1
    c.r[1] += 1;  // 0607D068 add #1,r1
    st8(c.r[1], c.r[6]);  // 0607D06A mov.b r6,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607D06C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607D06E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607D070 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D080u);  // 0607D072 mov.w 0x0607D080,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D074 rts ; mov.l @r15+,r8
}

void f_0607D0A8(SH2Context& c) {
    ran[1746] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607D0A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607D0AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607D0AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607D0AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607D0B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D0B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607D0B4 sts.l pr,@-r15
    c.r[1] = ld32(0x0607D1B4u);  // 0607D0B6 mov.l 0x0607D1B4,r1
    c.r[2] = ld32(c.r[1]);  // 0607D0B8 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0607D0BA mov r15,r14
    c.r[2] += 1;  // 0607D0BC add #1,r2
    st32(c.r[1], c.r[2]);  // 0607D0BE mov.l r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607D0C0 mov.b @r2,r2
    c.r[1] = ld32(0x0607D1B8u);  // 0607D0C2 mov.l 0x0607D1B8,r1
    c.r[3] = ld32(c.r[1]);  // 0607D0C4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607D0C6 extu.b r2,r2
    c.r[1] = ld32(0x0607D1BCu);  // 0607D0C8 mov.l 0x0607D1BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D0CA mov.b @r1,r1
    c.r[0] = c.r[3];  // 0607D0CC mov r3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607D0CE extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D0D0 add r1,r1
    c.r[3] += c.r[1];  // 0607D0D2 add r1,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D0D4 mov.b @(r0,r1),r7
    c.r[3] += 1;  // 0607D0D6 add #1,r3
    c.r[0] = 0x7Fu;  // 0607D0D8 mov #127,r0
    c.r[7] &= c.r[0];  // 0607D0DA and r0,r7
    c.r[7] <<= 8;  // 0607D0DC shll8 r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607D0DE mov.b @r3,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 0607D0E0 tst r2,r2
    c.r[11] = c.r[1] & 0xFFu;  // 0607D0E2 extu.b r1,r11
    { const bool k = c.t; c.r[11] |= c.r[7]; if (k) { goto L_0607D10E; } }  // 0607D0E4 bt/s 0x0607D10E ; or r7,r11
    c.r[3] = ld32(0x0607D1C0u);  // 0607D0E8 mov.l 0x0607D1C0,r3
    c.r[1] = 0x0u;  // 0607D0EA mov #0,r1
    st8(c.r[3], c.r[1]);  // 0607D0EC mov.b r1,@r3
    c.r[2] = ld32(0x0607D1C4u);  // 0607D0EE mov.l 0x0607D1C4,r2
    c.r[1] = ld32(c.r[2]);  // 0607D0F0 mov.l @r2,r1
    c.r[1] += 7;  // 0607D0F2 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D0F4 mov.b @r1,r0
    c.r[0] |= 0x4u;  // 0607D0F6 or #4,r0
    st8(c.r[1], c.r[0]);  // 0607D0F8 mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607D0FA mov.b @r3,r1
    c.r[6] = 0x0u;  // 0607D0FC mov #0,r6
    c.r[2] = ld32(c.r[2]);  // 0607D0FE mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D100 extu.b r1,r1
    c.r[1] <<= 2;  // 0607D102 shll2 r1
    c.r[1] <<= 2;  // 0607D104 shll2 r1
    c.r[1] += c.r[2];  // 0607D106 add r2,r1
    c.r[1] += 2;  // 0607D108 add #2,r1
    st8(c.r[1], c.r[11]); goto L_0607D110;  // 0607D10A bra 0x0607D110 ; mov.b r11,@r1
L_0607D10E:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607D1B0u);  // 0607D10E mov.w 0x0607D1B0,r6
L_0607D110:
    c.r[1] = ld32(0x0607D1B8u);  // 0607D110 mov.l 0x0607D1B8,r1
    c.r[2] = ld32(c.r[1]);  // 0607D112 mov.l @r1,r2
    c.r[12] = ld32(0x0607D1BCu);  // 0607D114 mov.l 0x0607D1BC,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0607D116 mov.b @r12,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D118 extu.b r1,r7
    c.r[0] = c.r[7];  // 0607D11A mov r7,r0
    c.r[0] += c.r[0];  // 0607D11C add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607D11E mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D120 extu.b r1,r1
    c.r[1] >>= 2;  // 0607D122 shlr2 r1
    c.r[1] >>= 2;  // 0607D124 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607D126 shlr r1
    c.r[1] >>= 2;  // 0607D128 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607D12A tst r1,r1
    { const bool k = !c.t; c.r[6] = c.r[6] & 0xFFu; if (k) { goto L_0607D13E; } }  // 0607D12C bf/s 0x0607D13E ; extu.b r6,r6
    c.r[1] = ld32(0x0607D1C8u);  // 0607D130 mov.l 0x0607D1C8,r1
    c.r[4] = ld32(c.r[1]);  // 0607D132 mov.l @r1,r4
    c.r[1] = ld32(0x0607D1CCu);  // 0607D134 mov.l 0x0607D1CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D13Au; c.r[5] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D13Au) return; }  // 0607D136 jsr @r1 ; extu.b r11,r5
    goto L_0607D176;  // 0607D13A bra 0x0607D176 ; nop
L_0607D13E:
    c.r[10] = ld32(0x0607D1D0u);  // 0607D13E mov.l 0x0607D1D0,r10
    c.r[1] = 0x1Eu;  // 0607D140 mov #30,r1
    c.r[9] = ld32(0x0607D1D4u);  // 0607D142 mov.l 0x0607D1D4,r9
    c.r[0] = c.r[7];  // 0607D144 mov r7,r0
    c.macl = c.r[11] * c.r[1];  // 0607D146 mul.l r1,r11
    c.r[3] = ld32(c.r[10]);  // 0607D148 mov.l @r10,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607D14A mov.b @(r0,r9),r2
    c.r[8] = c.macl;  // 0607D14C sts macl,r8
    c.r[3] += c.r[8];  // 0607D14E add r8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607D150 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D152 extu.b r2,r2
    c.r[1] += c.r[2];  // 0607D154 add r2,r1
    st16(c.r[3], c.r[1]);  // 0607D156 mov.w r1,@r3
    c.r[1] = ld32(0x0607D1C8u);  // 0607D158 mov.l 0x0607D1C8,r1
    c.r[4] = ld32(c.r[1]);  // 0607D15A mov.l @r1,r4
    c.r[1] = ld32(0x0607D1CCu);  // 0607D15C mov.l 0x0607D1CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D162u; c.r[5] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D162u) return; }  // 0607D15E jsr @r1 ; extu.b r11,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0607D162 mov.b @r12,r1
    c.r[3] = ld32(c.r[10]);  // 0607D164 mov.l @r10,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607D166 extu.b r1,r1
    c.r[0] = c.r[1];  // 0607D168 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607D16A mov.b @(r0,r9),r2
    c.r[3] += c.r[8];  // 0607D16C add r8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607D16E mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D170 extu.b r2,r2
    c.r[1] -= c.r[2];  // 0607D172 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0607D174 mov.w r1,@r3
L_0607D176:
    c.r[1] = ld32(0x0607D1C8u);  // 0607D176 mov.l 0x0607D1C8,r1
    c.r[2] = ld32(c.r[1]);  // 0607D178 mov.l @r1,r2
    c.r[15] = c.r[14];  // 0607D17A mov r14,r15
    c.r[3] = c.r[2];  // 0607D17C mov r2,r3
    c.r[1] = c.r[2];  // 0607D17E mov r2,r1
    c.r[1] += 26;  // 0607D180 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607D182 mov.w @r1,r1
    c.r[3] += 22;  // 0607D184 add #22,r3
    st16(c.r[3], c.r[1]);  // 0607D186 mov.w r1,@r3
    c.r[3] = c.r[2];  // 0607D188 mov r2,r3
    c.r[2] += 28;  // 0607D18A add #28,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607D18C mov.w @r2,r1
    c.r[3] += 24;  // 0607D18E add #24,r3
    st16(c.r[3], c.r[1]);  // 0607D190 mov.w r1,@r3
    c.r[1] = ld32(0x0607D1D8u);  // 0607D192 mov.l 0x0607D1D8,r1
    st8(c.r[1], c.r[11]);  // 0607D194 mov.b r11,@r1
    c.r[1] = ld32(0x0607D1BCu);  // 0607D196 mov.l 0x0607D1BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D198 mov.b @r1,r1
    c.r[2] = ld32(0x0607D1DCu);  // 0607D19A mov.l 0x0607D1DC,r2
    st8(c.r[2], c.r[1]);  // 0607D19C mov.b r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607D19E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607D1A0 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607D1A2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607D1A4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607D1A6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607D1A8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D1B2u);  // 0607D1AA mov.w 0x0607D1B2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D1AC rts ; mov.l @r15+,r8
}

void f_0607D1E0(SH2Context& c) {
    ran[1747] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607D1E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607D1E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607D1E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607D1E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607D1E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D1EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607D1EC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607D1EE mov r15,r14
    c.r[1] = ld32(0x0607D2CCu);  // 0607D1F0 mov.l 0x0607D2CC,r1
    c.r[2] = ld32(c.r[1]);  // 0607D1F2 mov.l @r1,r2
    c.r[12] = ld32(0x0607D2D0u);  // 0607D1F4 mov.l 0x0607D2D0,r12
    c.r[2] += 1;  // 0607D1F6 add #1,r2
    st32(c.r[1], c.r[2]);  // 0607D1F8 mov.l r2,@r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607D1FA mov.b @r2,r8
    c.r[11] = ld32(0x0607D2D4u);  // 0607D1FC mov.l 0x0607D2D4,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0607D1FE mov.b @r11,r1
    c.r[8] = c.r[8] & 0xFFu;  // 0607D200 extu.b r8,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0607D202 extu.b r1,r1
    c.r[2] = ld32(c.r[12]);  // 0607D204 mov.l @r12,r2
    c.r[1] += c.r[1];  // 0607D206 add r1,r1
    c.r[0] = c.r[2];  // 0607D208 mov r2,r0
    c.r[2] += c.r[1];  // 0607D20A add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D20C mov.b @(r0,r1),r3
    c.r[2] += 1;  // 0607D20E add #1,r2
    c.r[0] = 0x7Fu;  // 0607D210 mov #127,r0
    c.r[3] &= c.r[0];  // 0607D212 and r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607D214 mov.b @r2,r1
    c.r[3] <<= 8;  // 0607D216 shll8 r3
    c.r[10] = c.r[1] & 0xFFu;  // 0607D218 extu.b r1,r10
    c.r[10] |= c.r[3];  // 0607D21A or r3,r10
    c.r[9] = c.r[10] & 0xFFu;  // 0607D21C extu.b r10,r9
    c.r[1] = ld32(0x0607D2D8u);  // 0607D21E mov.l 0x0607D2D8,r1
    c.r[4] = ld32(c.r[1]);  // 0607D220 mov.l @r1,r4
    c.r[1] = ld32(0x0607D2DCu);  // 0607D222 mov.l 0x0607D2DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D228u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D228u) return; }  // 0607D224 jsr @r1 ; mov r9,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 0607D228 tst r8,r8
    if (c.t) { goto L_0607D2B0; }  // 0607D22A bt 0x0607D2B0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0607D22C mov.b @r11,r1
    c.r[2] = ld32(c.r[12]);  // 0607D22E mov.l @r12,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0607D230 extu.b r1,r0
    c.r[0] += c.r[0];  // 0607D232 add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607D234 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D236 extu.b r1,r1
    c.r[1] >>= 2;  // 0607D238 shlr2 r1
    c.r[1] >>= 2;  // 0607D23A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607D23C shlr r1
    c.r[1] >>= 2;  // 0607D23E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607D240 tst r1,r1
    if (!c.t) { goto L_0607D252; }  // 0607D242 bf 0x0607D252
    c.r[0] = ld32(0x0607D2E0u);  // 0607D244 mov.l 0x0607D2E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607D24Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D24Au) return; }  // 0607D246 jsr @r0 ; mov r9,r4
    c.r[5] = c.r[0] & 0xFFu;  // 0607D24A extu.b r0,r5
    c.r[1] = ld32(0x0607D2E4u);  // 0607D24C mov.l 0x0607D2E4,r1
    st8(c.r[1], c.r[10]); goto L_0607D276;  // 0607D24E bra 0x0607D276 ; mov.b r10,@r1
L_0607D252:
    c.r[0] = ld32(0x0607D2E8u);  // 0607D252 mov.l 0x0607D2E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607D258u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D258u) return; }  // 0607D254 jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0607D258 extu.b r0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D2C4u);  // 0607D25A mov.w 0x0607D2C4,r1
    c.t = c.r[8] == c.r[1];  // 0607D25C cmp/eq r1,r8
    { const bool k = !c.t; c.r[4] = c.r[9]; if (k) { goto L_0607D268; } }  // 0607D25E bf/s 0x0607D268 ; mov r9,r4
    c.r[0] = ld32(0x0607D2E0u);  // 0607D262 mov.l 0x0607D2E0,r0
    goto L_0607D26C;  // 0607D264 bra 0x0607D26C ; nop
L_0607D268:
    c.r[4] = c.r[8] & 0xFFu;  // 0607D268 extu.b r8,r4
    c.r[0] = ld32(0x0607D2E0u);  // 0607D26A mov.l 0x0607D2E0,r0
L_0607D26C:
    { const uint32_t x = c.r[0]; c.pr = 0x0607D270u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D270u) return; }  // 0607D26C jsr @r0 ; nop
    c.r[5] = c.r[0] & 0xFFu;  // 0607D270 extu.b r0,r5
    c.r[1] = ld32(0x0607D2E4u);  // 0607D272 mov.l 0x0607D2E4,r1
    st8(c.r[1], c.r[8]);  // 0607D274 mov.b r8,@r1
L_0607D276:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607D2C4u);  // 0607D276 mov.w 0x0607D2C4,r6
    c.t = c.r[5] == c.r[6];  // 0607D278 cmp/eq r6,r5
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0607D28C; } }  // 0607D27A bt/s 0x0607D28C ; mov #0,r2
    c.r[1] = ld32(0x0607D2ECu);  // 0607D27E mov.l 0x0607D2EC,r1
    c.r[4] = ld32(c.r[1]);  // 0607D280 mov.l @r1,r4
    c.r[1] = ld32(0x0607D2F0u);  // 0607D282 mov.l 0x0607D2F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D288u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D288u) return; }  // 0607D284 jsr @r1 ; extu.b r5,r5
    goto L_0607D2B0;  // 0607D288 bra 0x0607D2B0 ; nop
L_0607D28C:
    c.r[1] = ld32(0x0607D2ECu);  // 0607D28C mov.l 0x0607D2EC,r1
    c.r[3] = ld32(c.r[1]);  // 0607D28E mov.l @r1,r3
    st16(c.r[3], c.r[2]);  // 0607D290 mov.w r2,@r3
    c.r[1] = c.r[3];  // 0607D292 mov r3,r1
    c.r[1] += 34;  // 0607D294 add #34,r1
    st16(c.r[1], c.r[2]);  // 0607D296 mov.w r2,@r1
    c.r[1] = c.r[3];  // 0607D298 mov r3,r1
    c.r[1] += 32;  // 0607D29A add #32,r1
    st16(c.r[1], c.r[2]);  // 0607D29C mov.w r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D2C6u);  // 0607D29E mov.w 0x0607D2C6,r1
    c.r[0] = c.r[3];  // 0607D2A0 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D2A2 mov.b @(r0,r1),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D2C8u);  // 0607D2A4 mov.w 0x0607D2C8,r0
    c.r[2] &= c.r[0];  // 0607D2A6 and r0,r2
    c.r[0] = 0x8u;  // 0607D2A8 mov #8,r0
    c.r[2] |= c.r[0];  // 0607D2AA or r0,r2
    c.r[0] = c.r[3];  // 0607D2AC mov r3,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0607D2AE mov.b r2,@(r0,r1)
L_0607D2B0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D2CAu);  // 0607D2B0 mov.w 0x0607D2CA,r0
    c.r[15] = c.r[14];  // 0607D2B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607D2B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607D2B6 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607D2B8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607D2BA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607D2BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607D2BE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D2C0 rts ; mov.l @r15+,r8
}

void f_0607D2F4(SH2Context& c) {
    ran[1748] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607D2F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607D2F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607D2F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D2FA mov.l r14,@-r15
    c.r[1] = ld32(0x0607D494u);  // 0607D2FC mov.l 0x0607D494,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D2FE mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D300 extu.b r1,r7
    c.r[1] = ld32(0x0607D498u);  // 0607D302 mov.l 0x0607D498,r1
    c.r[0] = c.r[7];  // 0607D304 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D306 mov.b @(r0,r1),r2
    c.r[15] -= 128;  // 0607D308 add #-128,r15
    c.r[2] = c.r[2] & 0xFFu;  // 0607D30A extu.b r2,r2
    c.r[2] -= 1;  // 0607D30C add #-1,r2
    c.r[1] = 0x9u;  // 0607D30E mov #9,r1
    c.macl = c.r[2] * c.r[1];  // 0607D310 mul.l r1,r2
    c.r[14] = c.r[15];  // 0607D312 mov r15,r14
    c.r[3] = ld32(0x0607D49Cu);  // 0607D314 mov.l 0x0607D49C,r3
    c.r[1] = ld32(0x0607D4A0u);  // 0607D316 mov.l 0x0607D4A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D318 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0607D31A sts macl,r2
    c.r[2] += c.r[1];  // 0607D31C add r1,r2
    st8(c.r[3], c.r[2]);  // 0607D31E mov.b r2,@r3
    c.r[7] = ld32(0x0607D4A4u);  // 0607D320 mov.l 0x0607D4A4,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0607D322 extu.b r2,r2
    c.r[1] = ld32(c.r[7]);  // 0607D324 mov.l @r7,r1
    c.r[2] += c.r[2];  // 0607D326 add r2,r2
    c.r[0] = c.r[1];  // 0607D328 mov r1,r0
    c.r[1] += c.r[2];  // 0607D32A add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607D32C mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0607D32E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D330 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 0607D332 mov #127,r0
    c.r[3] &= c.r[0];  // 0607D334 and r0,r3
    c.r[3] <<= 8;  // 0607D336 shll8 r3
    c.r[9] = c.r[1] & 0xFFu;  // 0607D338 extu.b r1,r9
    c.r[9] |= c.r[3];  // 0607D33A or r3,r9
    c.r[3] = ld32(0x0607D4A8u);  // 0607D33C mov.l 0x0607D4A8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607D33E mov.b @r3,r1
    c.r[6] = 0x0u; goto L_0607D356;  // 0607D340 bra 0x0607D356 ; mov #0,r6
L_0607D344:
    c.r[2] = ld32(c.r[7]);  // 0607D344 mov.l @r7,r2
    c.r[1] += c.r[1];  // 0607D346 add r1,r1
    c.r[2] += c.r[1];  // 0607D348 add r1,r2
    c.r[2] += 1;  // 0607D34A add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607D34C mov.b @r2,r1
    c.r[0] = c.r[14];  // 0607D34E mov r14,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 0607D350 mov.b r1,@(r0,r6)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607D352 mov.b @r3,r1
    c.r[6] += 1;  // 0607D354 add #1,r6
L_0607D356:
    c.r[1] = c.r[1] & 0xFFu;  // 0607D356 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0607D358 cmp/ge r1,r6
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { SH2_POLL(c); goto L_0607D344; } }  // 0607D35A bf/s 0x0607D344 ; mov r6,r1
    c.r[3] = ld32(0x0607D4A4u);  // 0607D35E mov.l 0x0607D4A4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607D488u);  // 0607D360 mov.w 0x0607D488,r7
    c.r[2] = ld32(c.r[3]);  // 0607D362 mov.l @r3,r2
    c.r[1] = 0x0u;  // 0607D364 mov #0,r1
    c.r[0] = c.r[2];  // 0607D366 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607D368 mov.b r1,@(r0,r7)
    c.r[1] = ld32(0x0607D4A8u);  // 0607D36A mov.l 0x0607D4A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D36C mov.b @r1,r1
    c.r[6] = 0x0u;  // 0607D36E mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0607D370 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0607D372 cmp/ge r1,r6
    if (c.t) { goto L_0607D430; }  // 0607D374 bt 0x0607D430
    c.r[8] = c.r[3];  // 0607D376 mov r3,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0607D48Au);  // 0607D378 mov.w 0x0607D48A,r10
    c.r[4] = c.r[14];  // 0607D37A mov r14,r4
L_0607D37C:
    c.r[2] = ld32(c.r[8]);  // 0607D37C mov.l @r8,r2
    c.r[0] = c.r[2];  // 0607D37E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D380 mov.b @(r0,r7),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607D382 extu.b r1,r3
    c.r[3] += c.r[3];  // 0607D384 add r3,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607D386 mov.b @(r0,r3),r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0607D388 mov.b @r4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D48Cu);  // 0607D38A mov.w 0x0607D48C,r0
    c.r[5] &= c.r[0];  // 0607D38C and r0,r5
    c.r[0] = c.r[2];  // 0607D38E mov r2,r0
    st8(c.r[0] + c.r[3], c.r[5]);  // 0607D390 mov.b r5,@(r0,r3)
    c.r[2] += c.r[3];  // 0607D392 add r3,r2
    c.r[2] += 1;  // 0607D394 add #1,r2
    st8(c.r[2], c.r[1]);  // 0607D396 mov.b r1,@r2
    c.r[2] = ld32(c.r[8]);  // 0607D398 mov.l @r8,r2
    c.r[0] = c.r[2];  // 0607D39A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D39C mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D39E extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D3A0 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D3A2 mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607D3A4 mov #127,r0
    c.r[3] &= c.r[0];  // 0607D3A6 and r0,r3
    c.r[0] = c.r[2];  // 0607D3A8 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D3AA mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[8]);  // 0607D3AC mov.l @r8,r2
    c.r[0] = c.r[2];  // 0607D3AE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D3B0 mov.b @(r0,r7),r1
    c.r[1] += 1;  // 0607D3B2 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607D3B4 mov.b r1,@(r0,r7)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0607D3B6 mov.b @r4,r2
    c.r[1] = ld32(0x0607D4ACu);  // 0607D3B8 mov.l 0x0607D4AC,r1
    c.r[3] = ld32(c.r[1]);  // 0607D3BA mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607D3BC extu.b r2,r2
    c.r[1] = c.r[2];  // 0607D3BE mov r2,r1
    c.r[1] += c.r[1];  // 0607D3C0 add r1,r1
    c.r[1] += c.r[2];  // 0607D3C2 add r2,r1
    c.r[1] <<= 2;  // 0607D3C4 shll2 r1
    c.r[1] += c.r[3];  // 0607D3C6 add r3,r1
    c.r[1] += 8;  // 0607D3C8 add #8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D3CA mov.b @r1,r5
    c.r[1] = c.r[5] & 0xFFu;  // 0607D3CC extu.b r5,r1
    c.t = c.r[1] == c.r[10];  // 0607D3CE cmp/eq r10,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0607D422; } }  // 0607D3D0 bt/s 0x0607D422 ; mov r1,r0
    c.r[0] += c.r[0];  // 0607D3D4 add r0,r0
    c.r[0] += c.r[1];  // 0607D3D6 add r1,r0
    c.r[0] <<= 2;  // 0607D3D8 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0607D3DA mov.w @(r0,r3),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0607D3DC extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D48Eu);  // 0607D3DE mov.w 0x0607D48E,r1
    c.t = c.r[2] == c.r[1];  // 0607D3E0 cmp/eq r1,r2
    if (c.t) { goto L_0607D3EA; }  // 0607D3E2 bt 0x0607D3EA
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D490u);  // 0607D3E4 mov.w 0x0607D490,r1
    c.t = c.r[2] == c.r[1];  // 0607D3E6 cmp/eq r1,r2
    if (!c.t) { goto L_0607D422; }  // 0607D3E8 bf 0x0607D422
L_0607D3EA:
    c.r[2] = ld32(c.r[8]);  // 0607D3EA mov.l @r8,r2
    c.r[0] = c.r[2];  // 0607D3EC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D3EE mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D3F0 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D3F2 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D3F4 mov.b @(r0,r1),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D48Cu);  // 0607D3F6 mov.w 0x0607D48C,r0
    c.r[3] &= c.r[0];  // 0607D3F8 and r0,r3
    c.r[0] = c.r[2];  // 0607D3FA mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D3FC mov.b r3,@(r0,r1)
    c.r[2] += c.r[1];  // 0607D3FE add r1,r2
    c.r[2] += 1;  // 0607D400 add #1,r2
    st8(c.r[2], c.r[5]);  // 0607D402 mov.b r5,@r2
    c.r[2] = ld32(c.r[8]);  // 0607D404 mov.l @r8,r2
    c.r[0] = c.r[2];  // 0607D406 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D408 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D40A extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D40C add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D40E mov.b @(r0,r1),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D48Cu);  // 0607D410 mov.w 0x0607D48C,r0
    c.r[3] |= c.r[0];  // 0607D412 or r0,r3
    c.r[0] = c.r[2];  // 0607D414 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D416 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[8]);  // 0607D418 mov.l @r8,r2
    c.r[0] = c.r[2];  // 0607D41A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D41C mov.b @(r0,r7),r1
    c.r[1] += 1;  // 0607D41E add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607D420 mov.b r1,@(r0,r7)
L_0607D422:
    c.r[1] = ld32(0x0607D4A8u);  // 0607D422 mov.l 0x0607D4A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D424 mov.b @r1,r1
    c.r[6] += 1;  // 0607D426 add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0607D428 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0607D42A cmp/ge r1,r6
    { const bool k = !c.t; c.r[4] += 1; if (k) { SH2_POLL(c); goto L_0607D37C; } }  // 0607D42C bf/s 0x0607D37C ; add #1,r4
L_0607D430:
    c.r[6] = ld32(0x0607D4A8u);  // 0607D430 mov.l 0x0607D4A8,r6
    c.r[1] = ld32(0x0607D4A4u);  // 0607D432 mov.l 0x0607D4A4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D488u);  // 0607D434 mov.w 0x0607D488,r0
    c.r[3] = ld32(c.r[1]);  // 0607D436 mov.l @r1,r3
    c.r[7] = ld32(0x0607D49Cu);  // 0607D438 mov.l 0x0607D49C,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607D43A mov.b @(r0,r3),r2
    c.r[1] = 0x0u;  // 0607D43C mov #0,r1
    st8(c.r[6], c.r[2]);  // 0607D43E mov.b r2,@r6
    st8(c.r[7], c.r[1]);  // 0607D440 mov.b r1,@r7
    c.r[1] = 0x0u;  // 0607D442 mov #0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D444 extu.b r2,r2
    c.t = c.r[1] >= c.r[2];  // 0607D446 cmp/hs r2,r1
    if (c.t) { goto L_0607D476; }  // 0607D448 bt 0x0607D476
L_0607D44A:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607D44A mov.b @r7,r2
    c.r[0] = c.r[3];  // 0607D44C mov r3,r0
    c.r[1] = c.r[2] & 0xFFu;  // 0607D44E extu.b r2,r1
    c.r[1] += c.r[1];  // 0607D450 add r1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D452 mov.b @(r0,r1),r5
    c.r[0] = 0x7Fu;  // 0607D454 mov #127,r0
    c.r[5] &= c.r[0];  // 0607D456 and r0,r5
    c.r[1] += c.r[3];  // 0607D458 add r3,r1
    c.r[1] += 1;  // 0607D45A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D45C mov.b @r1,r1
    c.r[5] <<= 8;  // 0607D45E shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607D460 extu.b r1,r1
    c.r[1] |= c.r[5];  // 0607D462 or r5,r1
    c.t = c.r[1] == c.r[9];  // 0607D464 cmp/eq r9,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_0607D476; } }  // 0607D466 bt/s 0x0607D476 ; add #1,r2
    st8(c.r[7], c.r[2]);  // 0607D46A mov.b r2,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607D46C mov.b @r6,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D46E extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D470 extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 0607D472 cmp/hs r1,r2
    if (!c.t) { SH2_POLL(c); goto L_0607D44A; }  // 0607D474 bf 0x0607D44A
L_0607D476:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D48Cu);  // 0607D476 mov.w 0x0607D48C,r3
    c.r[14] += c.r[3];  // 0607D478 add r3,r14
    c.r[15] = c.r[14];  // 0607D47A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607D47C mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607D47E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607D480 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D492u);  // 0607D482 mov.w 0x0607D492,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D484 rts ; mov.l @r15+,r8
}

void f_0607D4B0(SH2Context& c) {
    ran[1749] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D4B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607D4B2 sts.l pr,@-r15
    c.r[1] = ld32(0x0607D504u);  // 0607D4B4 mov.l 0x0607D504,r1
    c.r[2] = ld32(c.r[1]);  // 0607D4B6 mov.l @r1,r2
    c.r[2] += 1;  // 0607D4B8 add #1,r2
    st32(c.r[1], c.r[2]);  // 0607D4BA mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607D4BC mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607D4BE extu.b r1,r2
    c.r[1] = 0x3u;  // 0607D4C0 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0607D4C2 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607D4F8; } }  // 0607D4C4 bt/s 0x0607D4F8 ; mov r15,r14
    c.r[1] = c.r[2];  // 0607D4C8 mov r2,r1
    c.r[1] += c.r[1];  // 0607D4CA add r1,r1
    c.r[0] = 0x0607D4D8u;  // 0607D4CC mova 0x0607D4D8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607D4CE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607D4D0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607D4E0u: goto L_0607D4E0; case 0x0607D4E6u: goto L_0607D4E6; case 0x0607D4ECu: goto L_0607D4EC; case 0x0607D4F2u: goto L_0607D4F2; default: sh2_call(c, x); return; } }  // 0607D4D2 jmp @r0 ; nop
L_0607D4E0:
    c.r[1] = ld32(0x0607D508u);  // 0607D4E0 mov.l 0x0607D508,r1
    goto L_0607D4F4;  // 0607D4E2 bra 0x0607D4F4 ; nop
L_0607D4E6:
    c.r[1] = ld32(0x0607D50Cu);  // 0607D4E6 mov.l 0x0607D50C,r1
    goto L_0607D4F4;  // 0607D4E8 bra 0x0607D4F4 ; nop
L_0607D4EC:
    c.r[1] = ld32(0x0607D510u);  // 0607D4EC mov.l 0x0607D510,r1
    goto L_0607D4F4;  // 0607D4EE bra 0x0607D4F4 ; nop
L_0607D4F2:
    c.r[1] = ld32(0x0607D514u);  // 0607D4F2 mov.l 0x0607D514,r1
L_0607D4F4:
    { const uint32_t x = c.r[1]; c.pr = 0x0607D4F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D4F8u) return; }  // 0607D4F4 jsr @r1 ; nop
L_0607D4F8:
    c.r[15] = c.r[14];  // 0607D4F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607D4FA lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D502u);  // 0607D4FC mov.w 0x0607D502,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D4FE rts ; mov.l @r15+,r14
}

void f_0607D518(SH2Context& c) {
    ran[1750] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607D518 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607D51A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607D51C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607D51E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607D520 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607D522 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D524 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607D526 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D620u);  // 0607D528 mov.w 0x0607D620,r3
    c.r[15] += c.r[3];  // 0607D52A add r3,r15
    c.r[14] = c.r[15];  // 0607D52C mov r15,r14
    c.r[3] = ld32(0x0607D630u);  // 0607D52E mov.l 0x0607D630,r3
    c.r[2] = ld32(c.r[3]);  // 0607D530 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D622u);  // 0607D532 mov.w 0x0607D622,r0
    c.r[1] = 0x0u;  // 0607D534 mov #0,r1
    c.r[8] = 0x0u;  // 0607D536 mov #0,r8
    c.r[12] = ld32(0x0607D634u);  // 0607D538 mov.l 0x0607D634,r12
    c.r[11] = c.r[3];  // 0607D53A mov r3,r11
    c.r[10] = c.r[0];  // 0607D53C mov r0,r10
    c.r[13] = 0x0u;  // 0607D53E mov #0,r13
    c.r[9] = 0x0u;  // 0607D540 mov #0,r9
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607D542 mov.b r1,@(r0,r2)
L_0607D544:
    c.r[1] = ld32(0x0607D638u);  // 0607D544 mov.l 0x0607D638,r1
    c.r[0] = ld32(c.r[1]);  // 0607D546 mov.l @r1,r0
    c.r[2] = c.r[9];  // 0607D548 mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0607D54A mov.w @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607D54C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607D54E tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_0607D5E6; } }  // 0607D550 bt/s 0x0607D5E6 ; add r0,r2
    c.r[2] += 2;  // 0607D554 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607D556 mov.b @r2,r2
    c.r[1] = ld32(c.r[12]);  // 0607D558 mov.l @r12,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D55A extu.b r2,r2
    c.r[1] += 8;  // 0607D55C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D55E mov.b @r1,r1
    c.r[2] >>= 2;  // 0607D560 shlr2 r2
    c.r[2] >>= 2;  // 0607D562 shlr2 r2
    c.r[2] >>= 2;  // 0607D564 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D566 extu.b r1,r1
    c.r[1] >>= 2;  // 0607D568 shlr2 r1
    c.r[1] >>= 2;  // 0607D56A shlr2 r1
    c.r[1] >>= 2;  // 0607D56C shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607D56E cmp/eq r1,r2
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_0607D5E6; } }  // 0607D570 bf/s 0x0607D5E6 ; extu.b r8,r5
    c.r[1] = ld32(0x0607D63Cu);  // 0607D574 mov.l 0x0607D63C,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607D624u);  // 0607D576 mov.w 0x0607D624,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607D57Cu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D57Cu) return; }  // 0607D578 jsr @r1 ; mov r14,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D626u);  // 0607D57C mov.w 0x0607D626,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607D57E mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0607D580 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607D582 shlr r0
    c.r[0] &= 0xFu;  // 0607D584 and #15,r0
    c.t = c.r[0] == 0x6u;  // 0607D586 cmp/eq #6,r0
    if (!c.t) { goto L_0607D596; }  // 0607D588 bf 0x0607D596
    c.r[1] = ld32(c.r[12]);  // 0607D58A mov.l @r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D628u);  // 0607D58C mov.w 0x0607D628,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D58E mov.b @(r0,r1),r0
    c.r[0] &= 0x80u;  // 0607D590 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607D592 tst r0,r0
    if (!c.t) { goto L_0607D5E6; }  // 0607D594 bf 0x0607D5E6
L_0607D596:
    c.r[2] = ld32(c.r[11]);  // 0607D596 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D598 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607D59A mov.b @(r0,r10),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D59C extu.b r1,r7
    c.r[7] += c.r[7];  // 0607D59E add r7,r7
    c.r[1] = c.r[8] & 0xFFFFu;  // 0607D5A0 extu.w r8,r1
    c.r[6] = c.r[1];  // 0607D5A2 mov r1,r6
    c.r[6] >>= 8;  // 0607D5A4 shlr8 r6
    c.r[0] = 0x7Fu;  // 0607D5A6 mov #127,r0
    c.r[6] &= c.r[0];  // 0607D5A8 and r0,r6
    c.r[0] = c.r[2];  // 0607D5AA mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D5AC mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D62Au);  // 0607D5AE mov.w 0x0607D62A,r0
    c.r[3] &= c.r[0];  // 0607D5B0 and r0,r3
    c.r[3] |= c.r[6];  // 0607D5B2 or r6,r3
    c.r[0] = c.r[2];  // 0607D5B4 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607D5B6 mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607D5B8 add r7,r2
    c.r[2] += 1;  // 0607D5BA add #1,r2
    st8(c.r[2], c.r[1]);  // 0607D5BC mov.b r1,@r2
    c.r[2] = ld32(c.r[11]);  // 0607D5BE mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D5C0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607D5C2 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D5C4 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D5C6 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D5C8 mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607D5CA mov #127,r0
    c.r[3] &= c.r[0];  // 0607D5CC and r0,r3
    c.r[0] = c.r[2];  // 0607D5CE mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D5D0 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[11]);  // 0607D5D2 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D5D4 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607D5D6 mov.b @(r0,r10),r3
    c.r[1] = c.r[3];  // 0607D5D8 mov r3,r1
    c.r[1] += 1;  // 0607D5DA add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0607D5DC mov.b r1,@(r0,r10)
    c.r[2] = c.r[3] & 0xFFu;  // 0607D5DE extu.b r3,r2
    c.r[1] = ld32(0x0607D640u);  // 0607D5E0 mov.l 0x0607D640,r1
    c.r[0] = c.r[2];  // 0607D5E2 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[13]);  // 0607D5E4 mov.b r13,@(r0,r1)
L_0607D5E6:
    c.r[8] += 1;  // 0607D5E6 add #1,r8
    c.r[1] = 0x7Fu;  // 0607D5E8 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0607D5EA cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0607D544; } }  // 0607D5EC bf/s 0x0607D544 ; add #30,r9
    c.r[1] = ld32(0x0607D644u);  // 0607D5F0 mov.l 0x0607D644,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D5F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D5F6u) return; }  // 0607D5F2 jsr @r1 ; nop
    c.r[1] = ld32(0x0607D630u);  // 0607D5F6 mov.l 0x0607D630,r1
    c.r[1] = ld32(c.r[1]);  // 0607D5F8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D622u);  // 0607D5FA mov.w 0x0607D622,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D5FC mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607D648u);  // 0607D5FE mov.l 0x0607D648,r2
    st8(c.r[2], c.r[1]);  // 0607D600 mov.b r1,@r2
    c.r[1] = ld32(0x0607D64Cu);  // 0607D602 mov.l 0x0607D64C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D608u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D608u) return; }  // 0607D604 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D62Cu);  // 0607D608 mov.w 0x0607D62C,r3
    c.r[14] += c.r[3];  // 0607D60A add r3,r14
    c.r[15] = c.r[14];  // 0607D60C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607D60E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607D610 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607D612 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607D614 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607D616 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607D618 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607D61A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D61C rts ; mov.l @r15+,r8
}

void f_0607D650(SH2Context& c) {
    ran[1751] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607D650 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607D652 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607D654 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607D656 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607D658 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D65A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607D65C sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D77Au);  // 0607D65E mov.w 0x0607D77A,r3
    c.r[15] += c.r[3];  // 0607D660 add r3,r15
    c.r[14] = c.r[15];  // 0607D662 mov r15,r14
    c.r[10] = 0x0u;  // 0607D664 mov #0,r10
    c.r[3] = ld32(0x0607D788u);  // 0607D666 mov.l 0x0607D788,r3
    c.r[2] = ld32(c.r[3]);  // 0607D668 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D77Cu);  // 0607D66A mov.w 0x0607D77C,r0
    c.r[1] = 0x0u;  // 0607D66C mov #0,r1
    c.r[9] = 0x0u;  // 0607D66E mov #0,r9
    c.r[11] = c.r[3];  // 0607D670 mov r3,r11
    c.r[8] = c.r[0];  // 0607D672 mov r0,r8
    c.r[12] = 0x0u;  // 0607D674 mov #0,r12
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607D676 mov.b r1,@(r0,r2)
L_0607D678:
    c.r[1] = ld32(0x0607D78Cu);  // 0607D678 mov.l 0x0607D78C,r1
    c.r[2] = ld32(c.r[1]);  // 0607D67A mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607D67C mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0607D67E mul.l r1,r9
    c.r[3] = c.macl;  // 0607D680 sts macl,r3
    c.r[3] += c.r[2];  // 0607D682 add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607D684 mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607D686 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607D688 tst r1,r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_0607D692; } }  // 0607D68A bf/s 0x0607D692 ; add #2,r3
    goto L_0607D85A;  // 0607D68E bra 0x0607D85A ; nop
L_0607D692:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607D692 mov.b @r3,r2
    c.r[1] = ld32(0x0607D790u);  // 0607D694 mov.l 0x0607D790,r1
    c.r[1] = ld32(c.r[1]);  // 0607D696 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D698 extu.b r2,r2
    c.r[1] += 8;  // 0607D69A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D69C mov.b @r1,r1
    c.r[2] >>= 2;  // 0607D69E shlr2 r2
    c.r[2] >>= 2;  // 0607D6A0 shlr2 r2
    c.r[2] >>= 2;  // 0607D6A2 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D6A4 extu.b r1,r1
    c.r[1] >>= 2;  // 0607D6A6 shlr2 r1
    c.r[1] >>= 2;  // 0607D6A8 shlr2 r1
    c.r[1] >>= 2;  // 0607D6AA shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607D6AC cmp/eq r1,r2
    if (c.t) { goto L_0607D6B4; }  // 0607D6AE bt 0x0607D6B4
    goto L_0607D85A;  // 0607D6B0 bra 0x0607D85A ; nop
L_0607D6B4:
    c.r[5] = c.r[9] & 0xFFu;  // 0607D6B4 extu.b r9,r5
    c.r[1] = ld32(0x0607D794u);  // 0607D6B6 mov.l 0x0607D794,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607D77Eu);  // 0607D6B8 mov.w 0x0607D77E,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607D6BEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D6BEu) return; }  // 0607D6BA jsr @r1 ; mov r14,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D780u);  // 0607D6BE mov.w 0x0607D780,r1
    c.r[0] = c.r[14];  // 0607D6C0 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D6C2 mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607D6C4 shlr r1
    c.r[0] = 0xFu;  // 0607D6C6 mov #15,r0
    c.r[1] &= c.r[0];  // 0607D6C8 and r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607D6CA extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0607D6CC tst r3,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0607D6E2; } }  // 0607D6CE bt/s 0x0607D6E2 ; mov r3,r0
    c.t = c.r[0] == 0x4u;  // 0607D6D2 cmp/eq #4,r0
    { const bool k = c.t; c.r[1] -= 7; if (k) { goto L_0607D6E2; } }  // 0607D6D4 bt/s 0x0607D6E2 ; add #-7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607D6D8 extu.b r1,r2
    c.r[1] = 0x1u;  // 0607D6DA mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0607D6DC cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_0607D734; } }  // 0607D6DE bt/s 0x0607D734 ; mov #8,r1
L_0607D6E2:
    c.r[2] = ld32(c.r[11]);  // 0607D6E2 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D6E4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D6E6 mov.b @(r0,r8),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D6E8 extu.b r1,r7
    c.r[7] += c.r[7];  // 0607D6EA add r7,r7
    c.r[1] = c.r[9] & 0xFFFFu;  // 0607D6EC extu.w r9,r1
    c.r[6] = c.r[1];  // 0607D6EE mov r1,r6
    c.r[6] >>= 8;  // 0607D6F0 shlr8 r6
    c.r[0] = 0x7Fu;  // 0607D6F2 mov #127,r0
    c.r[6] &= c.r[0];  // 0607D6F4 and r0,r6
    c.r[0] = c.r[2];  // 0607D6F6 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D6F8 mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D782u);  // 0607D6FA mov.w 0x0607D782,r0
    c.r[3] &= c.r[0];  // 0607D6FC and r0,r3
    c.r[3] |= c.r[6];  // 0607D6FE or r6,r3
    c.r[0] = c.r[2];  // 0607D700 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607D702 mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607D704 add r7,r2
    c.r[2] += 1;  // 0607D706 add #1,r2
    st8(c.r[2], c.r[1]);  // 0607D708 mov.b r1,@r2
    c.r[2] = ld32(c.r[11]);  // 0607D70A mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D70C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D70E mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D710 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D712 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D714 mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607D716 mov #127,r0
    c.r[3] &= c.r[0];  // 0607D718 and r0,r3
    c.r[0] = c.r[2];  // 0607D71A mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D71C mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[11]);  // 0607D71E mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D720 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D722 mov.b @(r0,r8),r3
    c.r[1] = c.r[3];  // 0607D724 mov r3,r1
    c.r[1] += 1;  // 0607D726 add #1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607D728 mov.b r1,@(r0,r8)
    c.r[2] = c.r[3] & 0xFFu;  // 0607D72A extu.b r3,r2
    c.r[1] = ld32(0x0607D798u);  // 0607D72C mov.l 0x0607D798,r1
    c.r[0] = c.r[2];  // 0607D72E mov r2,r0
    st8(c.r[0] + c.r[1], c.r[12]); goto L_0607D85A;  // 0607D730 bra 0x0607D85A ; mov.b r12,@(r0,r1)
L_0607D734:
    c.r[2] = c.r[3];  // 0607D734 mov r3,r2
    c.r[2] -= 1;  // 0607D736 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0607D738 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0607D800; } }  // 0607D73A bt/s 0x0607D800 ; mov #0,r7
    c.r[1] = c.r[2];  // 0607D73E mov r2,r1
    c.r[1] += c.r[1];  // 0607D740 add r1,r1
    c.r[0] = 0x0607D74Cu;  // 0607D742 mova 0x0607D74C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607D744 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607D746 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607D75Eu: goto L_0607D75E; case 0x0607D762u: goto L_0607D762; case 0x0607D7FEu: goto L_0607D7FE; case 0x0607D766u: goto L_0607D766; case 0x0607D79Cu: goto L_0607D79C; default: sh2_call(c, x); return; } }  // 0607D748 jmp @r0 ; nop
L_0607D75E:
    c.r[10] = 0x2u; goto L_0607D7FE;  // 0607D75E bra 0x0607D7FE ; mov #2,r10
L_0607D762:
    c.r[10] = 0x3u; goto L_0607D7FE;  // 0607D762 bra 0x0607D7FE ; mov #3,r10
L_0607D766:
    c.r[1] = ld32(0x0607D790u);  // 0607D766 mov.l 0x0607D790,r1
    c.r[1] = ld32(c.r[1]);  // 0607D768 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D784u);  // 0607D76A mov.w 0x0607D784,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D76C mov.b @(r0,r1),r0
    c.r[0] &= 0x80u;  // 0607D76E and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607D770 tst r0,r0
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0607D7FE; } }  // 0607D772 bf/s 0x0607D7FE ; mov #0,r10
    c.r[2] = ld32(c.r[11]); goto L_0607D7B0;  // 0607D776 bra 0x0607D7B0 ; mov.l @r11,r2
L_0607D79C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D88Eu);  // 0607D79C mov.w 0x0607D88E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607D79E mov.b @(r0,r14),r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607D7A0 extu.b r1,r0
    c.r[0] >>= 2;  // 0607D7A2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607D7A4 shlr r0
    c.r[0] >>= 2;  // 0607D7A6 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 0607D7A8 cmp/eq #2,r0
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0607D7FE; } }  // 0607D7AA bt/s 0x0607D7FE ; mov #0,r10
    c.r[2] = ld32(c.r[11]);  // 0607D7AE mov.l @r11,r2
L_0607D7B0:
    c.r[0] = c.r[2];  // 0607D7B0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D7B2 mov.b @(r0,r8),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D7B4 extu.b r1,r7
    c.r[7] += c.r[7];  // 0607D7B6 add r7,r7
    c.r[1] = c.r[9] & 0xFFFFu;  // 0607D7B8 extu.w r9,r1
    c.r[6] = c.r[1];  // 0607D7BA mov r1,r6
    c.r[6] >>= 8;  // 0607D7BC shlr8 r6
    c.r[0] = 0x7Fu;  // 0607D7BE mov #127,r0
    c.r[6] &= c.r[0];  // 0607D7C0 and r0,r6
    c.r[0] = c.r[2];  // 0607D7C2 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D7C4 mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D890u);  // 0607D7C6 mov.w 0x0607D890,r0
    c.r[3] &= c.r[0];  // 0607D7C8 and r0,r3
    c.r[3] |= c.r[6];  // 0607D7CA or r6,r3
    c.r[0] = c.r[2];  // 0607D7CC mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607D7CE mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607D7D0 add r7,r2
    c.r[2] += 1;  // 0607D7D2 add #1,r2
    st8(c.r[2], c.r[1]);  // 0607D7D4 mov.b r1,@r2
    c.r[2] = ld32(c.r[11]);  // 0607D7D6 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D7D8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D7DA mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D7DC extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D7DE add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D7E0 mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607D7E2 mov #127,r0
    c.r[3] &= c.r[0];  // 0607D7E4 and r0,r3
    c.r[0] = c.r[2];  // 0607D7E6 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D7E8 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[11]);  // 0607D7EA mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D7EC mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D7EE mov.b @(r0,r8),r3
    c.r[1] = c.r[3];  // 0607D7F0 mov r3,r1
    c.r[1] += 1;  // 0607D7F2 add #1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607D7F4 mov.b r1,@(r0,r8)
    c.r[2] = c.r[3] & 0xFFu;  // 0607D7F6 extu.b r3,r2
    c.r[1] = ld32(0x0607D898u);  // 0607D7F8 mov.l 0x0607D898,r1
    c.r[0] = c.r[2];  // 0607D7FA mov r2,r0
    st8(c.r[0] + c.r[1], c.r[12]);  // 0607D7FC mov.b r12,@(r0,r1)
L_0607D7FE:
    c.r[7] = 0x0u;  // 0607D7FE mov #0,r7
L_0607D800:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 0607D800 cmp/ge r10,r7
    { const bool k = c.t; c.r[1] = c.r[9] & 0xFFFFu; if (k) { goto L_0607D85A; } }  // 0607D802 bt/s 0x0607D85A ; extu.w r9,r1
    c.r[5] = c.r[1];  // 0607D806 mov r1,r5
    c.r[5] >>= 8;  // 0607D808 shlr8 r5
    c.r[0] = 0x7Fu;  // 0607D80A mov #127,r0
    c.r[5] &= c.r[0];  // 0607D80C and r0,r5
    c.r[6] = c.r[1];  // 0607D80E mov r1,r6
L_0607D810:
    c.r[2] = ld32(c.r[11]);  // 0607D810 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D812 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D814 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607D816 extu.b r1,r3
    c.r[3] += c.r[3];  // 0607D818 add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607D81A mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D890u);  // 0607D81C mov.w 0x0607D890,r0
    c.r[1] &= c.r[0];  // 0607D81E and r0,r1
    c.r[1] |= c.r[5];  // 0607D820 or r5,r1
    c.r[0] = c.r[2];  // 0607D822 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0607D824 mov.b r1,@(r0,r3)
    c.r[2] += c.r[3];  // 0607D826 add r3,r2
    c.r[2] += 1;  // 0607D828 add #1,r2
    st8(c.r[2], c.r[6]);  // 0607D82A mov.b r6,@r2
    c.r[2] = ld32(c.r[11]);  // 0607D82C mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D82E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D830 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607D832 extu.b r1,r3
    c.r[3] += c.r[3];  // 0607D834 add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607D836 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D890u);  // 0607D838 mov.w 0x0607D890,r0
    c.r[1] |= c.r[0];  // 0607D83A or r0,r1
    c.r[0] = c.r[2];  // 0607D83C mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0607D83E mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[11]);  // 0607D840 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607D842 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D844 mov.b @(r0,r8),r3
    c.r[1] = c.r[3];  // 0607D846 mov r3,r1
    c.r[1] += 1;  // 0607D848 add #1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607D84A mov.b r1,@(r0,r8)
    c.r[2] = c.r[3] & 0xFFu;  // 0607D84C extu.b r3,r2
    c.r[1] = ld32(0x0607D898u);  // 0607D84E mov.l 0x0607D898,r1
    c.r[0] = c.r[2];  // 0607D850 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0607D852 mov.b r7,@(r0,r1)
    c.r[7] += 1;  // 0607D854 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 0607D856 cmp/ge r10,r7
    if (!c.t) { SH2_POLL(c); goto L_0607D810; }  // 0607D858 bf 0x0607D810
L_0607D85A:
    c.r[9] += 1;  // 0607D85A add #1,r9
    c.r[1] = 0x7Fu;  // 0607D85C mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0607D85E cmp/gt r1,r9
    if (c.t) { goto L_0607D866; }  // 0607D860 bt 0x0607D866
    SH2_POLL(c); goto L_0607D678;  // 0607D862 bra 0x0607D678 ; nop
L_0607D866:
    c.r[1] = ld32(0x0607D89Cu);  // 0607D866 mov.l 0x0607D89C,r1
    c.r[1] = ld32(c.r[1]);  // 0607D868 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D892u);  // 0607D86A mov.w 0x0607D892,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D86C mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607D8A0u);  // 0607D86E mov.l 0x0607D8A0,r2
    st8(c.r[2], c.r[1]);  // 0607D870 mov.b r1,@r2
    c.r[1] = ld32(0x0607D8A4u);  // 0607D872 mov.l 0x0607D8A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607D878u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D878u) return; }  // 0607D874 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D894u);  // 0607D878 mov.w 0x0607D894,r3
    c.r[14] += c.r[3];  // 0607D87A add r3,r14
    c.r[15] = c.r[14];  // 0607D87C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607D87E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607D880 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607D882 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607D884 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607D886 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607D888 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607D88A rts ; mov.l @r15+,r8
}

void f_0607D8A8(SH2Context& c) {
    ran[1752] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607D8A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607D8AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607D8AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607D8AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607D8B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607D8B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607D8B4 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607D9BCu);  // 0607D8B6 mov.w 0x0607D9BC,r3
    c.r[15] += c.r[3];  // 0607D8B8 add r3,r15
    c.r[14] = c.r[15];  // 0607D8BA mov r15,r14
    c.r[11] = 0x0u;  // 0607D8BC mov #0,r11
    c.r[3] = ld32(0x0607D9C8u);  // 0607D8BE mov.l 0x0607D9C8,r3
    c.r[2] = ld32(c.r[3]);  // 0607D8C0 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D9BEu);  // 0607D8C2 mov.w 0x0607D9BE,r0
    c.r[1] = 0x0u;  // 0607D8C4 mov #0,r1
    c.r[9] = 0x0u;  // 0607D8C6 mov #0,r9
    c.r[10] = c.r[3];  // 0607D8C8 mov r3,r10
    c.r[8] = c.r[0];  // 0607D8CA mov r0,r8
    c.r[12] = 0x0u;  // 0607D8CC mov #0,r12
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607D8CE mov.b r1,@(r0,r2)
L_0607D8D0:
    c.r[1] = ld32(0x0607D9CCu);  // 0607D8D0 mov.l 0x0607D9CC,r1
    c.r[2] = ld32(c.r[1]);  // 0607D8D2 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607D8D4 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0607D8D6 mul.l r1,r9
    c.r[3] = c.macl;  // 0607D8D8 sts macl,r3
    c.r[3] += c.r[2];  // 0607D8DA add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607D8DC mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607D8DE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607D8E0 tst r1,r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_0607D8EA; } }  // 0607D8E2 bf/s 0x0607D8EA ; add #2,r3
    goto L_0607DA98;  // 0607D8E6 bra 0x0607DA98 ; nop
L_0607D8EA:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607D8EA mov.b @r3,r2
    c.r[1] = ld32(0x0607D9D0u);  // 0607D8EC mov.l 0x0607D9D0,r1
    c.r[1] = ld32(c.r[1]);  // 0607D8EE mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607D8F0 extu.b r2,r2
    c.r[1] += 8;  // 0607D8F2 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607D8F4 mov.b @r1,r1
    c.r[2] >>= 2;  // 0607D8F6 shlr2 r2
    c.r[2] >>= 2;  // 0607D8F8 shlr2 r2
    c.r[2] >>= 2;  // 0607D8FA shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607D8FC extu.b r1,r1
    c.r[1] >>= 2;  // 0607D8FE shlr2 r1
    c.r[1] >>= 2;  // 0607D900 shlr2 r1
    c.r[1] >>= 2;  // 0607D902 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607D904 cmp/eq r1,r2
    if (c.t) { goto L_0607D90C; }  // 0607D906 bt 0x0607D90C
    goto L_0607DA98;  // 0607D908 bra 0x0607DA98 ; nop
L_0607D90C:
    c.r[5] = c.r[9] & 0xFFu;  // 0607D90C extu.b r9,r5
    c.r[1] = ld32(0x0607D9D4u);  // 0607D90E mov.l 0x0607D9D4,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607D9C0u);  // 0607D910 mov.w 0x0607D9C0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607D916u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607D916u) return; }  // 0607D912 jsr @r1 ; mov r14,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607D9C2u);  // 0607D916 mov.w 0x0607D9C2,r1
    c.r[0] = c.r[14];  // 0607D918 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D91A mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607D91C shlr r1
    c.r[0] = 0xFu;  // 0607D91E mov #15,r0
    c.r[1] &= c.r[0];  // 0607D920 and r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607D922 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0607D924 tst r3,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0607D93E; } }  // 0607D926 bt/s 0x0607D93E ; mov r3,r0
    c.t = c.r[0] == 0x4u;  // 0607D92A cmp/eq #4,r0
    { const bool k = c.t; c.r[1] -= 7; if (k) { goto L_0607D93E; } }  // 0607D92C bt/s 0x0607D93E ; add #-7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607D930 extu.b r1,r2
    c.r[1] = 0x1u;  // 0607D932 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0607D934 cmp/hi r1,r2
    { const bool k = !c.t; c.t = c.r[0] == 0x9u; if (k) { goto L_0607D93E; } }  // 0607D936 bf/s 0x0607D93E ; cmp/eq #9,r0
    { const bool k = !c.t; c.r[1] = 0x5u; if (k) { goto L_0607D990; } }  // 0607D93A bf/s 0x0607D990 ; mov #5,r1
L_0607D93E:
    c.r[2] = ld32(c.r[10]);  // 0607D93E mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607D940 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D942 mov.b @(r0,r8),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D944 extu.b r1,r7
    c.r[7] += c.r[7];  // 0607D946 add r7,r7
    c.r[1] = c.r[9] & 0xFFFFu;  // 0607D948 extu.w r9,r1
    c.r[6] = c.r[1];  // 0607D94A mov r1,r6
    c.r[6] >>= 8;  // 0607D94C shlr8 r6
    c.r[0] = 0x7Fu;  // 0607D94E mov #127,r0
    c.r[6] &= c.r[0];  // 0607D950 and r0,r6
    c.r[0] = c.r[2];  // 0607D952 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607D954 mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607D9C4u);  // 0607D956 mov.w 0x0607D9C4,r0
    c.r[3] &= c.r[0];  // 0607D958 and r0,r3
    c.r[3] |= c.r[6];  // 0607D95A or r6,r3
    c.r[0] = c.r[2];  // 0607D95C mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607D95E mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607D960 add r7,r2
    c.r[2] += 1;  // 0607D962 add #1,r2
    st8(c.r[2], c.r[1]);  // 0607D964 mov.b r1,@r2
    c.r[2] = ld32(c.r[10]);  // 0607D966 mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607D968 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D96A mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607D96C extu.b r1,r1
    c.r[1] += c.r[1];  // 0607D96E add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D970 mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607D972 mov #127,r0
    c.r[3] &= c.r[0];  // 0607D974 and r0,r3
    c.r[0] = c.r[2];  // 0607D976 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607D978 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[10]);  // 0607D97A mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607D97C mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D97E mov.b @(r0,r8),r3
    c.r[1] = c.r[3];  // 0607D980 mov r3,r1
    c.r[1] += 1;  // 0607D982 add #1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607D984 mov.b r1,@(r0,r8)
    c.r[2] = c.r[3] & 0xFFu;  // 0607D986 extu.b r3,r2
    c.r[1] = ld32(0x0607D9D8u);  // 0607D988 mov.l 0x0607D9D8,r1
    c.r[0] = c.r[2];  // 0607D98A mov r2,r0
    st8(c.r[0] + c.r[1], c.r[12]); goto L_0607DA98;  // 0607D98C bra 0x0607DA98 ; mov.b r12,@(r0,r1)
L_0607D990:
    c.r[2] = c.r[3];  // 0607D990 mov r3,r2
    c.r[2] -= 1;  // 0607D992 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0607D994 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0607DA3E; } }  // 0607D996 bt/s 0x0607DA3E ; mov #0,r7
    c.r[1] = c.r[2];  // 0607D99A mov r2,r1
    c.r[1] += c.r[1];  // 0607D99C add r1,r1
    c.r[0] = 0x0607D9A8u;  // 0607D99E mova 0x0607D9A8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607D9A0 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607D9A2 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607D9B4u: goto L_0607D9B4; case 0x0607D9B8u: goto L_0607D9B8; case 0x0607DA3Cu: goto L_0607DA3C; case 0x0607D9DCu: goto L_0607D9DC; default: sh2_call(c, x); return; } }  // 0607D9A4 jmp @r0 ; nop
L_0607D9B4:
    c.r[11] = 0x2u; goto L_0607DA3C;  // 0607D9B4 bra 0x0607DA3C ; mov #2,r11
L_0607D9B8:
    c.r[11] = 0x3u; goto L_0607DA3C;  // 0607D9B8 bra 0x0607DA3C ; mov #3,r11
L_0607D9DC:
    c.r[1] = ld32(0x0607DADCu);  // 0607D9DC mov.l 0x0607DADC,r1
    c.r[1] = ld32(c.r[1]);  // 0607D9DE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DAD2u);  // 0607D9E0 mov.w 0x0607DAD2,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607D9E2 mov.b @(r0,r1),r0
    c.r[0] &= 0x80u;  // 0607D9E4 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607D9E6 tst r0,r0
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_0607DA3C; } }  // 0607D9E8 bf/s 0x0607DA3C ; mov #0,r11
    c.r[2] = ld32(c.r[10]);  // 0607D9EC mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607D9EE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607D9F0 mov.b @(r0,r8),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607D9F2 extu.b r1,r7
    c.r[7] += c.r[7];  // 0607D9F4 add r7,r7
    c.r[1] = c.r[9] & 0xFFFFu;  // 0607D9F6 extu.w r9,r1
    c.r[6] = c.r[1];  // 0607D9F8 mov r1,r6
    c.r[6] >>= 8;  // 0607D9FA shlr8 r6
    c.r[0] = 0x7Fu;  // 0607D9FC mov #127,r0
    c.r[6] &= c.r[0];  // 0607D9FE and r0,r6
    c.r[0] = c.r[2];  // 0607DA00 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607DA02 mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DAD4u);  // 0607DA04 mov.w 0x0607DAD4,r0
    c.r[3] &= c.r[0];  // 0607DA06 and r0,r3
    c.r[3] |= c.r[6];  // 0607DA08 or r6,r3
    c.r[0] = c.r[2];  // 0607DA0A mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607DA0C mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607DA0E add r7,r2
    c.r[2] += 1;  // 0607DA10 add #1,r2
    st8(c.r[2], c.r[1]);  // 0607DA12 mov.b r1,@r2
    c.r[2] = ld32(c.r[10]);  // 0607DA14 mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607DA16 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DA18 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607DA1A extu.b r1,r1
    c.r[1] += c.r[1];  // 0607DA1C add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DA1E mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607DA20 mov #127,r0
    c.r[3] &= c.r[0];  // 0607DA22 and r0,r3
    c.r[0] = c.r[2];  // 0607DA24 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607DA26 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[10]);  // 0607DA28 mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607DA2A mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DA2C mov.b @(r0,r8),r3
    c.r[1] = c.r[3];  // 0607DA2E mov r3,r1
    c.r[1] += 1;  // 0607DA30 add #1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607DA32 mov.b r1,@(r0,r8)
    c.r[2] = c.r[3] & 0xFFu;  // 0607DA34 extu.b r3,r2
    c.r[1] = ld32(0x0607DAE0u);  // 0607DA36 mov.l 0x0607DAE0,r1
    c.r[0] = c.r[2];  // 0607DA38 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[12]);  // 0607DA3A mov.b r12,@(r0,r1)
L_0607DA3C:
    c.r[7] = 0x0u;  // 0607DA3C mov #0,r7
L_0607DA3E:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[11];  // 0607DA3E cmp/ge r11,r7
    { const bool k = c.t; c.r[1] = c.r[9] & 0xFFFFu; if (k) { goto L_0607DA98; } }  // 0607DA40 bt/s 0x0607DA98 ; extu.w r9,r1
    c.r[5] = c.r[1];  // 0607DA44 mov r1,r5
    c.r[5] >>= 8;  // 0607DA46 shlr8 r5
    c.r[0] = 0x7Fu;  // 0607DA48 mov #127,r0
    c.r[5] &= c.r[0];  // 0607DA4A and r0,r5
    c.r[6] = c.r[1];  // 0607DA4C mov r1,r6
L_0607DA4E:
    c.r[2] = ld32(c.r[10]);  // 0607DA4E mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607DA50 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DA52 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607DA54 extu.b r1,r3
    c.r[3] += c.r[3];  // 0607DA56 add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607DA58 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DAD4u);  // 0607DA5A mov.w 0x0607DAD4,r0
    c.r[1] &= c.r[0];  // 0607DA5C and r0,r1
    c.r[1] |= c.r[5];  // 0607DA5E or r5,r1
    c.r[0] = c.r[2];  // 0607DA60 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0607DA62 mov.b r1,@(r0,r3)
    c.r[2] += c.r[3];  // 0607DA64 add r3,r2
    c.r[2] += 1;  // 0607DA66 add #1,r2
    st8(c.r[2], c.r[6]);  // 0607DA68 mov.b r6,@r2
    c.r[2] = ld32(c.r[10]);  // 0607DA6A mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607DA6C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DA6E mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607DA70 extu.b r1,r3
    c.r[3] += c.r[3];  // 0607DA72 add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607DA74 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DAD4u);  // 0607DA76 mov.w 0x0607DAD4,r0
    c.r[1] |= c.r[0];  // 0607DA78 or r0,r1
    c.r[0] = c.r[2];  // 0607DA7A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0607DA7C mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[10]);  // 0607DA7E mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607DA80 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DA82 mov.b @(r0,r8),r3
    c.r[1] = c.r[3];  // 0607DA84 mov r3,r1
    c.r[1] += 1;  // 0607DA86 add #1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607DA88 mov.b r1,@(r0,r8)
    c.r[2] = c.r[3] & 0xFFu;  // 0607DA8A extu.b r3,r2
    c.r[1] = ld32(0x0607DAE0u);  // 0607DA8C mov.l 0x0607DAE0,r1
    c.r[0] = c.r[2];  // 0607DA8E mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0607DA90 mov.b r7,@(r0,r1)
    c.r[7] += 1;  // 0607DA92 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[11];  // 0607DA94 cmp/ge r11,r7
    if (!c.t) { SH2_POLL(c); goto L_0607DA4E; }  // 0607DA96 bf 0x0607DA4E
L_0607DA98:
    c.r[9] += 1;  // 0607DA98 add #1,r9
    c.r[1] = 0x7Fu;  // 0607DA9A mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0607DA9C cmp/gt r1,r9
    if (c.t) { goto L_0607DAA4; }  // 0607DA9E bt 0x0607DAA4
    SH2_POLL(c); goto L_0607D8D0;  // 0607DAA0 bra 0x0607D8D0 ; nop
L_0607DAA4:
    c.r[1] = ld32(0x0607DAE4u);  // 0607DAA4 mov.l 0x0607DAE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607DAAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607DAAAu) return; }  // 0607DAA6 jsr @r1 ; nop
    c.r[1] = ld32(0x0607DAE8u);  // 0607DAAA mov.l 0x0607DAE8,r1
    c.r[1] = ld32(c.r[1]);  // 0607DAAC mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DAD6u);  // 0607DAAE mov.w 0x0607DAD6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DAB0 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607DAECu);  // 0607DAB2 mov.l 0x0607DAEC,r2
    st8(c.r[2], c.r[1]);  // 0607DAB4 mov.b r1,@r2
    c.r[1] = ld32(0x0607DAF0u);  // 0607DAB6 mov.l 0x0607DAF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607DABCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607DABCu) return; }  // 0607DAB8 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DAD8u);  // 0607DABC mov.w 0x0607DAD8,r3
    c.r[14] += c.r[3];  // 0607DABE add r3,r14
    c.r[15] = c.r[14];  // 0607DAC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607DAC2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607DAC4 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607DAC6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607DAC8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607DACA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607DACC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607DACE rts ; mov.l @r15+,r8
}

void f_0607DAF4(SH2Context& c) {
    ran[1753] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607DAF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607DAF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607DAF8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607DAFA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607DAFC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607DAFE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607DB00 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607DB02 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DBFEu);  // 0607DB04 mov.w 0x0607DBFE,r3
    c.r[15] += c.r[3];  // 0607DB06 add r3,r15
    c.r[14] = c.r[15];  // 0607DB08 mov r15,r14
    c.r[3] = ld32(0x0607DC0Cu);  // 0607DB0A mov.l 0x0607DC0C,r3
    c.r[2] = ld32(c.r[3]);  // 0607DB0C mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DC00u);  // 0607DB0E mov.w 0x0607DC00,r0
    c.r[1] = 0x0u;  // 0607DB10 mov #0,r1
    c.r[8] = 0x0u;  // 0607DB12 mov #0,r8
    c.r[12] = ld32(0x0607DC10u);  // 0607DB14 mov.l 0x0607DC10,r12
    c.r[11] = c.r[3];  // 0607DB16 mov r3,r11
    c.r[10] = c.r[0];  // 0607DB18 mov r0,r10
    c.r[13] = 0x0u;  // 0607DB1A mov #0,r13
    c.r[9] = 0x0u;  // 0607DB1C mov #0,r9
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607DB1E mov.b r1,@(r0,r2)
L_0607DB20:
    c.r[1] = ld32(0x0607DC14u);  // 0607DB20 mov.l 0x0607DC14,r1
    c.r[0] = ld32(c.r[1]);  // 0607DB22 mov.l @r1,r0
    c.r[2] = c.r[9];  // 0607DB24 mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0607DB26 mov.w @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607DB28 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607DB2A tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_0607DBCA; } }  // 0607DB2C bt/s 0x0607DBCA ; add r0,r2
    c.r[2] += 2;  // 0607DB30 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607DB32 mov.b @r2,r2
    c.r[1] = ld32(c.r[12]);  // 0607DB34 mov.l @r12,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607DB36 extu.b r2,r2
    c.r[1] += 8;  // 0607DB38 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DB3A mov.b @r1,r1
    c.r[2] >>= 2;  // 0607DB3C shlr2 r2
    c.r[2] >>= 2;  // 0607DB3E shlr2 r2
    c.r[2] >>= 2;  // 0607DB40 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607DB42 extu.b r1,r1
    c.r[1] >>= 2;  // 0607DB44 shlr2 r1
    c.r[1] >>= 2;  // 0607DB46 shlr2 r1
    c.r[1] >>= 2;  // 0607DB48 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607DB4A cmp/eq r1,r2
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_0607DBCA; } }  // 0607DB4C bf/s 0x0607DBCA ; extu.b r8,r5
    c.r[1] = ld32(0x0607DC18u);  // 0607DB50 mov.l 0x0607DC18,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607DC02u);  // 0607DB52 mov.w 0x0607DC02,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607DB58u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607DB58u) return; }  // 0607DB54 jsr @r1 ; mov r14,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DC04u);  // 0607DB58 mov.w 0x0607DC04,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607DB5A mov.b @(r0,r14),r2
    c.r[0] = c.r[2];  // 0607DB5C mov r2,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607DB5E shlr r0
    c.r[0] &= 0xFu;  // 0607DB60 and #15,r0
    c.t = c.r[0] == 0x6u;  // 0607DB62 cmp/eq #6,r0
    if (!c.t) { goto L_0607DB72; }  // 0607DB64 bf 0x0607DB72
    c.r[1] = ld32(c.r[12]);  // 0607DB66 mov.l @r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DC06u);  // 0607DB68 mov.w 0x0607DC06,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DB6A mov.b @(r0,r1),r0
    c.r[0] &= 0x80u;  // 0607DB6C and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607DB6E tst r0,r0
    if (!c.t) { goto L_0607DBCA; }  // 0607DB70 bf 0x0607DBCA
L_0607DB72:
    c.r[0] = c.r[2];  // 0607DB72 mov r2,r0
    c.r[0] &= 0xFEu;  // 0607DB74 and #254,r0
    c.t = c.r[0] == 0x52u;  // 0607DB76 cmp/eq #82,r0
    if (c.t) { goto L_0607DBCA; }  // 0607DB78 bt 0x0607DBCA
    c.r[2] = ld32(c.r[11]);  // 0607DB7A mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607DB7C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607DB7E mov.b @(r0,r10),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607DB80 extu.b r1,r7
    c.r[7] += c.r[7];  // 0607DB82 add r7,r7
    c.r[1] = c.r[8] & 0xFFFFu;  // 0607DB84 extu.w r8,r1
    c.r[6] = c.r[1];  // 0607DB86 mov r1,r6
    c.r[6] >>= 8;  // 0607DB88 shlr8 r6
    c.r[0] = 0x7Fu;  // 0607DB8A mov #127,r0
    c.r[6] &= c.r[0];  // 0607DB8C and r0,r6
    c.r[0] = c.r[2];  // 0607DB8E mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607DB90 mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DC08u);  // 0607DB92 mov.w 0x0607DC08,r0
    c.r[3] &= c.r[0];  // 0607DB94 and r0,r3
    c.r[3] |= c.r[6];  // 0607DB96 or r6,r3
    c.r[0] = c.r[2];  // 0607DB98 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607DB9A mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607DB9C add r7,r2
    c.r[2] += 1;  // 0607DB9E add #1,r2
    st8(c.r[2], c.r[1]);  // 0607DBA0 mov.b r1,@r2
    c.r[2] = ld32(c.r[11]);  // 0607DBA2 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607DBA4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607DBA6 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607DBA8 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607DBAA add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DBAC mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607DBAE mov #127,r0
    c.r[3] &= c.r[0];  // 0607DBB0 and r0,r3
    c.r[0] = c.r[2];  // 0607DBB2 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607DBB4 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[11]);  // 0607DBB6 mov.l @r11,r2
    c.r[0] = c.r[2];  // 0607DBB8 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607DBBA mov.b @(r0,r10),r3
    c.r[1] = c.r[3];  // 0607DBBC mov r3,r1
    c.r[1] += 1;  // 0607DBBE add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0607DBC0 mov.b r1,@(r0,r10)
    c.r[2] = c.r[3] & 0xFFu;  // 0607DBC2 extu.b r3,r2
    c.r[1] = ld32(0x0607DC1Cu);  // 0607DBC4 mov.l 0x0607DC1C,r1
    c.r[0] = c.r[2];  // 0607DBC6 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[13]);  // 0607DBC8 mov.b r13,@(r0,r1)
L_0607DBCA:
    c.r[8] += 1;  // 0607DBCA add #1,r8
    c.r[1] = 0x7Fu;  // 0607DBCC mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0607DBCE cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0607DB20; } }  // 0607DBD0 bf/s 0x0607DB20 ; add #30,r9
    c.r[1] = ld32(0x0607DC0Cu);  // 0607DBD4 mov.l 0x0607DC0C,r1
    c.r[1] = ld32(c.r[1]);  // 0607DBD6 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DC00u);  // 0607DBD8 mov.w 0x0607DC00,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DBDA mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607DC20u);  // 0607DBDC mov.l 0x0607DC20,r2
    st8(c.r[2], c.r[1]);  // 0607DBDE mov.b r1,@r2
    c.r[1] = ld32(0x0607DC24u);  // 0607DBE0 mov.l 0x0607DC24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607DBE6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607DBE6u) return; }  // 0607DBE2 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DC0Au);  // 0607DBE6 mov.w 0x0607DC0A,r3
    c.r[14] += c.r[3];  // 0607DBE8 add r3,r14
    c.r[15] = c.r[14];  // 0607DBEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607DBEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607DBEE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607DBF0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607DBF2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607DBF4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607DBF6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607DBF8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607DBFA rts ; mov.l @r15+,r8
}

void f_0607DC28(SH2Context& c) {
    ran[1754] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607DC28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607DC2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607DC2C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607DC2E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607DC30 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607DC32 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607DC34 mov r15,r14
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607DD48u);  // 0607DC36 mov.w 0x0607DD48,r9
    c.r[8] = 0x0u;  // 0607DC38 mov #0,r8
    c.r[1] = ld32(0x0607DD50u);  // 0607DC3A mov.l 0x0607DD50,r1
    c.r[2] = ld32(c.r[1]);  // 0607DC3C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607DD4Au);  // 0607DC3E mov.w 0x0607DD4A,r1
    c.r[0] = c.r[2];  // 0607DC40 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DC42 mov.b @(r0,r1),r1
    c.r[6] = 0x0u;  // 0607DC44 mov #0,r6
    c.r[3] = c.r[1] & 0xFFu;  // 0607DC46 extu.b r1,r3
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[3];  // 0607DC48 cmp/ge r3,r6
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_0607DC9C; } }  // 0607DC4A bt/s 0x0607DC9C ; mov #0,r4
    c.r[5] = c.r[2];  // 0607DC4E mov r2,r5
    c.r[1] = ld32(0x0607DD54u);  // 0607DC50 mov.l 0x0607DD54,r1
    c.r[11] = ld32(c.r[1]);  // 0607DC52 mov.l @r1,r11
    c.r[10] = c.r[3];  // 0607DC54 mov r3,r10
    c.r[7] = c.r[5];  // 0607DC56 mov r5,r7
    c.r[3] = 0x0u;  // 0607DC58 mov #0,r3
L_0607DC5A:
    c.r[0] = c.r[3];  // 0607DC5A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607DC5C mov.b @(r0,r5),r1
    c.r[12] = 0x7Fu;  // 0607DC5E mov #127,r12
    c.r[12] &= c.r[1];  // 0607DC60 and r1,r12
    c.r[1] = c.r[7];  // 0607DC62 mov r7,r1
    c.r[1] += 1;  // 0607DC64 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DC66 mov.b @r1,r2
    c.r[12] <<= 8;  // 0607DC68 shll8 r12
    c.r[2] = c.r[2] & 0xFFu;  // 0607DC6A extu.b r2,r2
    c.r[2] |= c.r[12];  // 0607DC6C or r12,r2
    c.r[1] = 0x1Eu;  // 0607DC6E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0607DC70 mul.l r1,r2
    c.r[1] = c.macl;  // 0607DC72 sts macl,r1
    c.r[0] = c.r[1];  // 0607DC74 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0607DC76 mov.w @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607DC78 extu.w r1,r1
    c.r[0] = c.r[1];  // 0607DC7A mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0607DC7C cmp/eq #2,r0
    if (!c.t) { goto L_0607DC84; }  // 0607DC7E bf 0x0607DC84
    c.r[9] = c.r[6];  // 0607DC80 mov r6,r9
    c.r[0] = c.r[1];  // 0607DC82 mov r1,r0
L_0607DC84:
    c.t = c.r[0] == 0x3u;  // 0607DC84 cmp/eq #3,r0
    if (!c.t) { goto L_0607DC8A; }  // 0607DC86 bf 0x0607DC8A
    c.r[4] = 0x1u;  // 0607DC88 mov #1,r4
L_0607DC8A:
    c.r[0] = c.r[1];  // 0607DC8A mov r1,r0
    c.t = c.r[0] == 0x4u;  // 0607DC8C cmp/eq #4,r0
    if (!c.t) { goto L_0607DC92; }  // 0607DC8E bf 0x0607DC92
    c.r[8] = 0x1u;  // 0607DC90 mov #1,r8
L_0607DC92:
    c.r[7] += 2;  // 0607DC92 add #2,r7
    c.r[6] += 1;  // 0607DC94 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 0607DC96 cmp/ge r10,r6
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0607DC5A; } }  // 0607DC98 bf/s 0x0607DC5A ; add #2,r3
L_0607DC9C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607DD48u);  // 0607DC9C mov.w 0x0607DD48,r1
    c.t = c.r[9] == c.r[1];  // 0607DC9E cmp/eq r1,r9
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0607DD3A; } }  // 0607DCA0 bt/s 0x0607DD3A ; mov r14,r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0607DCA4 tst r4,r4
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0607DCAC; } }  // 0607DCA6 bt/s 0x0607DCAC ; tst r8,r8
    if (!c.t) { goto L_0607DD3A; }  // 0607DCAA bf 0x0607DD3A
L_0607DCAC:
    c.r[3] = ld32(0x0607DD50u);  // 0607DCAC mov.l 0x0607DD50,r3
    c.r[2] = ld32(c.r[3]);  // 0607DCAE mov.l @r3,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x0607DD4Au);  // 0607DCB0 mov.w 0x0607DD4A,r8
    c.r[0] = c.r[2];  // 0607DCB2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DCB4 mov.b @(r0,r8),r1
    c.r[1] -= 1;  // 0607DCB6 add #-1,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0607DCB8 mov.b r1,@(r0,r8)
    c.r[1] = ld32(c.r[3]);  // 0607DCBA mov.l @r3,r1
    c.r[0] = c.r[1];  // 0607DCBC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DCBE mov.b @(r0,r8),r1
    c.r[6] = c.r[9];  // 0607DCC0 mov r9,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0607DCC2 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0607DCC4 cmp/ge r1,r6
    { const bool k = c.t; c.r[9] = c.r[3]; if (k) { goto L_0607DD38; } }  // 0607DCC6 bt/s 0x0607DD38 ; mov r3,r9
    c.r[10] = ld32(0x0607DD58u);  // 0607DCCA mov.l 0x0607DD58,r10
    c.r[7] = c.r[6];  // 0607DCCC mov r6,r7
L_0607DCCE:
    c.r[7] += c.r[7];  // 0607DCCE add r7,r7
    c.r[4] = c.r[6];  // 0607DCD0 mov r6,r4
    c.r[4] += 1;  // 0607DCD2 add #1,r4
    c.r[5] = c.r[4];  // 0607DCD4 mov r4,r5
    c.r[3] = ld32(c.r[9]);  // 0607DCD6 mov.l @r9,r3
    c.r[5] += c.r[5];  // 0607DCD8 add r5,r5
    c.r[0] = c.r[3];  // 0607DCDA mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607DCDC mov.b @(r0,r5),r1
    c.r[2] = 0x7Fu;  // 0607DCDE mov #127,r2
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607DCE0 mov.b @(r0,r7),r11
    c.r[2] &= c.r[1];  // 0607DCE2 and r1,r2
    c.r[2] <<= 8;  // 0607DCE4 shll8 r2
    c.r[1] = c.r[3];  // 0607DCE6 mov r3,r1
    c.r[1] += c.r[5];  // 0607DCE8 add r5,r1
    c.r[1] += 1;  // 0607DCEA add #1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DD4Cu);  // 0607DCEC mov.w 0x0607DD4C,r0
    c.r[11] &= c.r[0];  // 0607DCEE and r0,r11
    c.r[0] = c.r[3];  // 0607DCF0 mov r3,r0
    c.r[3] += c.r[7];  // 0607DCF2 add r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DCF4 mov.b @r1,r1
    c.r[3] += 1;  // 0607DCF6 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607DCF8 extu.b r1,r1
    c.r[1] |= c.r[2];  // 0607DCFA or r2,r1
    c.r[2] = c.r[1];  // 0607DCFC mov r1,r2
    c.r[2] >>= 8;  // 0607DCFE shlr8 r2
    c.r[11] |= c.r[2];  // 0607DD00 or r2,r11
    st8(c.r[0] + c.r[7], c.r[11]);  // 0607DD02 mov.b r11,@(r0,r7)
    st8(c.r[3], c.r[1]);  // 0607DD04 mov.b r1,@r3
    c.r[1] = ld32(c.r[9]);  // 0607DD06 mov.l @r9,r1
    c.r[0] = c.r[1];  // 0607DD08 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607DD0A mov.b @(r0,r5),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DD4Cu);  // 0607DD0C mov.w 0x0607DD4C,r0
    c.r[2] &= c.r[0];  // 0607DD0E and r0,r2
    c.r[0] = c.r[1];  // 0607DD10 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607DD12 mov.b @(r0,r7),r3
    c.r[0] = 0x7Fu;  // 0607DD14 mov #127,r0
    c.r[3] &= c.r[0];  // 0607DD16 and r0,r3
    c.r[3] |= c.r[2];  // 0607DD18 or r2,r3
    c.r[0] = c.r[1];  // 0607DD1A mov r1,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607DD1C mov.b r3,@(r0,r7)
    c.r[1] = c.r[10];  // 0607DD1E mov r10,r1
    c.r[1] += 1;  // 0607DD20 add #1,r1
    c.r[0] = c.r[6];  // 0607DD22 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DD24 mov.b @(r0,r1),r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0607DD26 mov.b r1,@(r0,r10)
    c.r[1] = ld32(c.r[9]);  // 0607DD28 mov.l @r9,r1
    c.r[0] = c.r[1];  // 0607DD2A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607DD2C mov.b @(r0,r8),r1
    c.r[6] = c.r[4];  // 0607DD2E mov r4,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0607DD30 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0607DD32 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] = c.r[6]; if (k) { SH2_POLL(c); goto L_0607DCCE; } }  // 0607DD34 bf/s 0x0607DCCE ; mov r6,r7
L_0607DD38:
    c.r[15] = c.r[14];  // 0607DD38 mov r14,r15
L_0607DD3A:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607DD3A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607DD3C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607DD3E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607DD40 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607DD42 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607DD44 rts ; mov.l @r15+,r8
}

void f_0607DD5C(SH2Context& c) {
    ran[1755] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607DD5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607DD5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607DD60 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607DD62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607DD64 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607DD66 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607DD68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607DD6A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DE70u);  // 0607DD6C mov.w 0x0607DE70,r3
    c.r[15] += c.r[3];  // 0607DD6E add r3,r15
    c.r[14] = c.r[15];  // 0607DD70 mov r15,r14
    c.r[13] = 0x0u;  // 0607DD72 mov #0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DE72u);  // 0607DD74 mov.w 0x0607DE72,r0
    c.r[0] += c.r[14];  // 0607DD76 add r14,r0
    c.r[2] = ld32(0x0607DE78u);  // 0607DD78 mov.l 0x0607DE78,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DE74u);  // 0607DD7A mov.w 0x0607DE74,r3
    st32(c.r[0], c.r[13]); goto L_0607DF62;  // 0607DD7C bra 0x0607DF62 ; mov.l r13,@r0
L_0607DD80:
    c.r[2] = ld32(0x0607DE78u);  // 0607DD80 mov.l 0x0607DE78,r2
    c.r[1] = ld32(c.r[2]);  // 0607DD82 mov.l @r2,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607DE72u);  // 0607DD84 mov.w 0x0607DE72,r13
    c.r[0] = c.r[1];  // 0607DD86 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607DD88 mov.b @(r0,r3),r1
    c.r[13] += c.r[14];  // 0607DD8A add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0607DD8C mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607DD8E extu.b r1,r1
    c.r[1] -= c.r[13];  // 0607DD90 sub r13,r1
    c.r[1] -= 1;  // 0607DD92 add #-1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607DD94 cmp/ge r1,r12
    if (!c.t) { goto L_0607DD9C; }  // 0607DD96 bf 0x0607DD9C
    goto L_0607DF54;  // 0607DD98 bra 0x0607DF54 ; nop
L_0607DD9C:
    c.r[11] = 0x2u;  // 0607DD9C mov #2,r11
L_0607DD9E:
    c.r[0] = c.r[12];  // 0607DD9E mov r12,r0
    c.r[1] = ld32(c.r[2]);  // 0607DDA0 mov.l @r2,r1
    c.r[0] += c.r[0];  // 0607DDA2 add r0,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DDA4 mov.b @(r0,r1),r2
    c.r[3] = 0x7Fu;  // 0607DDA6 mov #127,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607DDA8 extu.b r2,r2
    c.r[3] &= c.r[2];  // 0607DDAA and r2,r3
    c.r[3] <<= 8;  // 0607DDAC shll8 r3
    c.r[1] += c.r[0];  // 0607DDAE add r0,r1
    c.r[1] += 1;  // 0607DDB0 add #1,r1
    c.r[2] >>= 2;  // 0607DDB2 shlr2 r2
    c.r[2] >>= 2;  // 0607DDB4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607DDB6 shlr r2
    c.r[2] >>= 2;  // 0607DDB8 shlr2 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DDBA mov.b @r1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 0607DDBC tst r2,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0607DDBE extu.b r1,r10
    { const bool k = c.t; c.r[10] |= c.r[3]; if (k) { goto L_0607DDFE; } }  // 0607DDC0 bt/s 0x0607DDFE ; or r3,r10
    c.r[1] = ld32(0x0607DE7Cu);  // 0607DDC4 mov.l 0x0607DE7C,r1
    c.r[0] = c.r[12];  // 0607DDC6 mov r12,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DDC8 mov.b @(r0,r1),r7
    c.r[1] = c.r[7] & 0xFFu;  // 0607DDCA extu.b r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607DDCC tst r1,r1
    { const bool k = c.t; c.r[0] = 0x1Eu; if (k) { goto L_0607DE00; } }  // 0607DDCE bt/s 0x0607DE00 ; mov #30,r0
    c.r[13] = ld32(0x0607DE80u);  // 0607DDD2 mov.l 0x0607DE80,r13
    c.r[1] = c.r[7] & 0xFFu;  // 0607DDD4 extu.b r7,r1
    c.r[5] = c.r[10] & 0xFFu;  // 0607DDD6 extu.b r10,r5
    c.macl = c.r[10] * c.r[0];  // 0607DDD8 mul.l r0,r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607DE76u);  // 0607DDDA mov.w 0x0607DE76,r6
    c.r[3] = ld32(c.r[13]);  // 0607DDDC mov.l @r13,r3
    c.r[8] = c.macl;  // 0607DDDE sts macl,r8
    c.r[3] += c.r[8];  // 0607DDE0 add r8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607DDE2 mov.w @r3,r2
    c.r[4] = c.r[14];  // 0607DDE4 mov r14,r4
    c.r[9] = c.r[2] & 0xFFFFu;  // 0607DDE6 extu.w r2,r9
    c.r[2] += c.r[1];  // 0607DDE8 add r1,r2
    c.r[1] = ld32(0x0607DE84u);  // 0607DDEA mov.l 0x0607DE84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607DDF0u; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607DDF0u) return; }  // 0607DDEC jsr @r1 ; mov.w r2,@r3
    c.r[1] = ld32(c.r[13]);  // 0607DDF0 mov.l @r13,r1
    c.r[0] = c.r[8];  // 0607DDF2 mov r8,r0
    st16(c.r[0] + c.r[1], c.r[9]);  // 0607DDF4 mov.w r9,@(r0,r1)
    c.r[1] = c.r[14];  // 0607DDF6 mov r14,r1
    c.r[1] += 26;  // 0607DDF8 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0607DE0E;  // 0607DDFA bra 0x0607DE0E ; mov.w @r1,r1
L_0607DDFE:
    c.r[0] = 0x1Eu;  // 0607DDFE mov #30,r0
L_0607DE00:
    c.macl = c.r[10] * c.r[0];  // 0607DE00 mul.l r0,r10
    c.r[13] = ld32(0x0607DE80u);  // 0607DE02 mov.l 0x0607DE80,r13
    c.r[1] = ld32(c.r[13]);  // 0607DE04 mov.l @r13,r1
    c.r[2] = c.macl;  // 0607DE06 sts macl,r2
    c.r[2] += c.r[1];  // 0607DE08 add r1,r2
    c.r[2] += 22;  // 0607DE0A add #22,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607DE0C mov.w @r2,r1
L_0607DE0E:
    c.r[10] = c.r[1] & 0xFFFFu;  // 0607DE0E extu.w r1,r10
    c.r[13] = ld32(0x0607DE78u);  // 0607DE10 mov.l 0x0607DE78,r13
    c.r[1] = ld32(c.r[13]);  // 0607DE12 mov.l @r13,r1
    c.r[3] = 0x7Fu;  // 0607DE14 mov #127,r3
    c.r[0] = c.r[1];  // 0607DE16 mov r1,r0
    c.r[1] += c.r[11];  // 0607DE18 add r11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0607DE1A mov.b @(r0,r11),r2
    c.r[1] += 1;  // 0607DE1C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DE1E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607DE20 extu.b r2,r2
    c.r[3] &= c.r[2];  // 0607DE22 and r2,r3
    c.r[3] <<= 8;  // 0607DE24 shll8 r3
    c.r[5] = c.r[1] & 0xFFu;  // 0607DE26 extu.b r1,r5
    c.r[2] >>= 2;  // 0607DE28 shlr2 r2
    c.r[2] >>= 2;  // 0607DE2A shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607DE2C shlr r2
    c.r[2] >>= 2;  // 0607DE2E shlr2 r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0607DE30 tst r2,r2
    { const bool k = c.t; c.r[5] |= c.r[3]; if (k) { goto L_0607DE8C; } }  // 0607DE32 bt/s 0x0607DE8C ; or r3,r5
    c.r[1] = ld32(0x0607DE88u);  // 0607DE36 mov.l 0x0607DE88,r1
    c.r[0] = c.r[12];  // 0607DE38 mov r12,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DE3A mov.b @(r0,r1),r7
    c.r[1] = c.r[7] & 0xFFu;  // 0607DE3C extu.b r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607DE3E tst r1,r1
    { const bool k = c.t; c.r[0] = 0x1Eu; if (k) { goto L_0607DE8E; } }  // 0607DE40 bt/s 0x0607DE8E ; mov #30,r0
    c.r[13] = ld32(0x0607DE80u);  // 0607DE44 mov.l 0x0607DE80,r13
    c.r[1] = c.r[7] & 0xFFu;  // 0607DE46 extu.b r7,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607DE76u);  // 0607DE48 mov.w 0x0607DE76,r6
    c.macl = c.r[5] * c.r[0];  // 0607DE4A mul.l r0,r5
    c.r[4] = c.r[14];  // 0607DE4C mov r14,r4
    c.r[3] = ld32(c.r[13]);  // 0607DE4E mov.l @r13,r3
    c.r[8] = c.macl;  // 0607DE50 sts macl,r8
    c.r[3] += c.r[8];  // 0607DE52 add r8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607DE54 mov.w @r3,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0607DE56 extu.b r5,r5
    c.r[9] = c.r[2] & 0xFFFFu;  // 0607DE58 extu.w r2,r9
    c.r[2] += c.r[1];  // 0607DE5A add r1,r2
    c.r[1] = ld32(0x0607DE84u);  // 0607DE5C mov.l 0x0607DE84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607DE62u; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607DE62u) return; }  // 0607DE5E jsr @r1 ; mov.w r2,@r3
    c.r[1] = ld32(c.r[13]);  // 0607DE62 mov.l @r13,r1
    c.r[0] = c.r[8];  // 0607DE64 mov r8,r0
    st16(c.r[0] + c.r[1], c.r[9]);  // 0607DE66 mov.w r9,@(r0,r1)
    c.r[1] = c.r[14];  // 0607DE68 mov r14,r1
    c.r[1] += 26;  // 0607DE6A add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0607DE9C;  // 0607DE6C bra 0x0607DE9C ; mov.w @r1,r1
L_0607DE8C:
    c.r[0] = 0x1Eu;  // 0607DE8C mov #30,r0
L_0607DE8E:
    c.macl = c.r[5] * c.r[0];  // 0607DE8E mul.l r0,r5
    c.r[13] = ld32(0x0607DF9Cu);  // 0607DE90 mov.l 0x0607DF9C,r13
    c.r[1] = ld32(c.r[13]);  // 0607DE92 mov.l @r13,r1
    c.r[2] = c.macl;  // 0607DE94 sts macl,r2
    c.r[2] += c.r[1];  // 0607DE96 add r1,r2
    c.r[2] += 22;  // 0607DE98 add #22,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607DE9A mov.w @r2,r1
L_0607DE9C:
    c.r[5] = c.r[1] & 0xFFFFu;  // 0607DE9C extu.w r1,r5
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[5];  // 0607DE9E cmp/ge r5,r10
    { const bool k = c.t; c.r[4] = c.r[12]; if (k) { goto L_0607DF32; } }  // 0607DEA0 bt/s 0x0607DF32 ; mov r12,r4
    c.r[13] = ld32(0x0607DFA0u);  // 0607DEA4 mov.l 0x0607DFA0,r13
    c.r[4] += c.r[4];  // 0607DEA6 add r4,r4
    c.r[5] = 0x7Fu;  // 0607DEA8 mov #127,r5
    c.r[3] = ld32(c.r[13]);  // 0607DEAA mov.l @r13,r3
    c.r[2] = 0x7Fu;  // 0607DEAC mov #127,r2
    c.r[0] = c.r[3];  // 0607DEAE mov r3,r0
    c.r[6] = c.r[3];  // 0607DEB0 mov r3,r6
    c.r[6] += c.r[4];  // 0607DEB2 add r4,r6
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607DEB4 mov.b @(r0,r4),r8
    c.r[6] += 1;  // 0607DEB6 add #1,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607DEB8 mov.b @r6,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607DF92u);  // 0607DEBA mov.w 0x0607DF92,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0607DEBC mov.b @(r0,r11),r1
    c.r[5] &= c.r[8];  // 0607DEBE and r8,r5
    c.r[5] <<= 8;  // 0607DEC0 shll8 r5
    c.r[7] = c.r[7] & 0xFFu;  // 0607DEC2 extu.b r7,r7
    c.r[2] &= c.r[1];  // 0607DEC4 and r1,r2
    c.r[2] <<= 8;  // 0607DEC6 shll8 r2
    c.r[1] = c.r[3];  // 0607DEC8 mov r3,r1
    c.r[1] += c.r[11];  // 0607DECA add r11,r1
    c.r[1] += 1;  // 0607DECC add #1,r1
    c.r[8] &= c.r[13];  // 0607DECE and r13,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DED0 mov.b @r1,r1
    c.r[7] |= c.r[5];  // 0607DED2 or r5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607DED4 extu.b r1,r1
    c.r[1] |= c.r[2];  // 0607DED6 or r2,r1
    c.r[2] = c.r[1];  // 0607DED8 mov r1,r2
    c.r[2] >>= 8;  // 0607DEDA shlr8 r2
    c.r[8] |= c.r[2];  // 0607DEDC or r2,r8
    st8(c.r[0] + c.r[4], c.r[8]);  // 0607DEDE mov.b r8,@(r0,r4)
    st8(c.r[6], c.r[1]);  // 0607DEE0 mov.b r1,@r6
    c.r[0] = ld32(0x0607DFA0u);  // 0607DEE2 mov.l 0x0607DFA0,r0
    c.r[2] = c.r[7];  // 0607DEE4 mov r7,r2
    c.r[1] = ld32(c.r[0]);  // 0607DEE6 mov.l @r0,r1
    c.r[2] >>= 8;  // 0607DEE8 shlr8 r2
    c.r[0] = c.r[1];  // 0607DEEA mov r1,r0
    c.r[1] += c.r[11];  // 0607DEEC add r11,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0607DEEE mov.b @(r0,r11),r3
    c.r[1] += 1;  // 0607DEF0 add #1,r1
    c.r[3] &= c.r[13];  // 0607DEF2 and r13,r3
    c.r[3] |= c.r[2];  // 0607DEF4 or r2,r3
    st8(c.r[0] + c.r[11], c.r[3]);  // 0607DEF6 mov.b r3,@(r0,r11)
    st8(c.r[1], c.r[7]);  // 0607DEF8 mov.b r7,@r1
    c.r[13] = ld32(0x0607DFA0u);  // 0607DEFA mov.l 0x0607DFA0,r13
    c.r[1] = ld32(c.r[13]);  // 0607DEFC mov.l @r13,r1
    c.r[0] = c.r[1];  // 0607DEFE mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0607DF00 mov.b @(r0,r11),r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607DF92u);  // 0607DF02 mov.w 0x0607DF92,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607DF04 mov.b @(r0,r4),r3
    c.r[7] &= c.r[2];  // 0607DF06 and r2,r7
    c.r[2] = 0x7Fu;  // 0607DF08 mov #127,r2
    c.r[2] &= c.r[3];  // 0607DF0A and r3,r2
    c.r[2] |= c.r[7];  // 0607DF0C or r7,r2
    st8(c.r[0] + c.r[4], c.r[2]);  // 0607DF0E mov.b r2,@(r0,r4)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607DF92u);  // 0607DF10 mov.w 0x0607DF92,r2
    c.r[1] = ld32(c.r[13]);  // 0607DF12 mov.l @r13,r1
    c.r[2] &= c.r[3];  // 0607DF14 and r3,r2
    c.r[0] = c.r[1];  // 0607DF16 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0607DF18 mov.b @(r0,r11),r3
    c.r[13] = 0x7Fu;  // 0607DF1A mov #127,r13
    c.r[3] &= c.r[13];  // 0607DF1C and r13,r3
    c.r[3] |= c.r[2];  // 0607DF1E or r2,r3
    st8(c.r[0] + c.r[11], c.r[3]);  // 0607DF20 mov.b r3,@(r0,r11)
    c.r[2] = ld32(0x0607DFA4u);  // 0607DF22 mov.l 0x0607DFA4,r2
    c.r[0] = c.r[12];  // 0607DF24 mov r12,r0
    c.r[3] = c.r[2];  // 0607DF26 mov r2,r3
    c.r[3] += 1;  // 0607DF28 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607DF2A mov.b @(r0,r3),r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607DF2C mov.b @(r0,r2),r7
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607DF2E mov.b r1,@(r0,r2)
    st8(c.r[0] + c.r[3], c.r[7]);  // 0607DF30 mov.b r7,@(r0,r3)
L_0607DF32:
    c.r[12] += 1;  // 0607DF32 add #1,r12
    c.r[2] = ld32(0x0607DFA0u);  // 0607DF34 mov.l 0x0607DFA0,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DF94u);  // 0607DF36 mov.w 0x0607DF94,r3
    c.r[1] = ld32(c.r[2]);  // 0607DF38 mov.l @r2,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607DF96u);  // 0607DF3A mov.w 0x0607DF96,r13
    c.r[0] = c.r[1];  // 0607DF3C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607DF3E mov.b @(r0,r3),r1
    c.r[13] += c.r[14];  // 0607DF40 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0607DF42 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607DF44 extu.b r1,r1
    c.r[1] -= c.r[13];  // 0607DF46 sub r13,r1
    c.r[1] -= 1;  // 0607DF48 add #-1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607DF4A cmp/ge r1,r12
    { const bool k = c.t; c.r[11] += 2; if (k) { goto L_0607DF54; } }  // 0607DF4C bt/s 0x0607DF54 ; add #2,r11
    SH2_POLL(c); goto L_0607DD9E;  // 0607DF50 bra 0x0607DD9E ; nop
L_0607DF54:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607DF96u);  // 0607DF54 mov.w 0x0607DF96,r0
    c.r[0] += c.r[14];  // 0607DF56 add r14,r0
    c.r[2] = ld32(0x0607DFA0u);  // 0607DF58 mov.l 0x0607DFA0,r2
    c.r[13] = ld32(c.r[0]);  // 0607DF5A mov.l @r0,r13
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DF94u);  // 0607DF5C mov.w 0x0607DF94,r3
    c.r[13] += 1;  // 0607DF5E add #1,r13
    st32(c.r[0], c.r[13]);  // 0607DF60 mov.l r13,@r0
L_0607DF62:
    c.r[1] = ld32(c.r[2]);  // 0607DF62 mov.l @r2,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607DF96u);  // 0607DF64 mov.w 0x0607DF96,r13
    c.r[0] = c.r[1];  // 0607DF66 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607DF68 mov.b @(r0,r3),r1
    c.r[13] += c.r[14];  // 0607DF6A add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0607DF6C mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607DF6E extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 0607DF70 cmp/ge r1,r13
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_0607DF7A; } }  // 0607DF72 bt/s 0x0607DF7A ; mov #0,r12
    SH2_POLL(c); goto L_0607DD80;  // 0607DF76 bra 0x0607DD80 ; nop
L_0607DF7A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607DF98u);  // 0607DF7A mov.w 0x0607DF98,r3
    c.r[14] += c.r[3];  // 0607DF7C add r3,r14
    c.r[15] = c.r[14];  // 0607DF7E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607DF80 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607DF82 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607DF84 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607DF86 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607DF88 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607DF8A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607DF8C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607DF8E rts ; mov.l @r15+,r8
}

void f_0607DFA8(SH2Context& c) {
    ran[1756] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607DFA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607DFAA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607DFAC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607DFAE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607DFB0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607DFB2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607DFB4 mov.l r14,@-r15
    c.r[15] -= 8;  // 0607DFB6 add #-8,r15
    c.r[3] = ld32(0x0607E070u);  // 0607DFB8 mov.l 0x0607E070,r3
    c.r[1] = ld32(c.r[3]);  // 0607DFBA mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E06Au);  // 0607DFBC mov.w 0x0607E06A,r2
    c.r[0] = c.r[1];  // 0607DFBE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607DFC0 mov.b @(r0,r2),r1
    c.r[12] = 0x0u;  // 0607DFC2 mov #0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0607DFC4 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607DFC6 cmp/ge r1,r12
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607DFD0; } }  // 0607DFC8 bf/s 0x0607DFD0 ; mov r15,r14
    goto L_0607E144;  // 0607DFCC bra 0x0607E144 ; nop
L_0607DFD0:
    c.r[11] = c.r[3];  // 0607DFD0 mov r3,r11
    c.r[13] = 0x1Eu;  // 0607DFD2 mov #30,r13
L_0607DFD4:
    c.r[0] = ld32(c.r[11]);  // 0607DFD4 mov.l @r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607DFD6 mov.b @(r0,r2),r1
    c.r[9] = 0x0u;  // 0607DFD8 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0607DFDA extu.b r1,r1
    c.r[1] -= c.r[12];  // 0607DFDC sub r12,r1
    c.r[1] -= 1;  // 0607DFDE add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0607DFE0 cmp/ge r1,r9
    if (!c.t) { goto L_0607DFE8; }  // 0607DFE2 bf 0x0607DFE8
    goto L_0607E12E;  // 0607DFE4 bra 0x0607E12E ; nop
L_0607DFE8:
    c.r[4] = 0x2u;  // 0607DFE8 mov #2,r4
L_0607DFEA:
    c.r[1] = c.r[9];  // 0607DFEA mov r9,r1
    c.r[3] = ld32(c.r[11]);  // 0607DFEC mov.l @r11,r3
    c.r[1] += c.r[1];  // 0607DFEE add r1,r1
    c.r[0] = c.r[3];  // 0607DFF0 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607DFF2 mov.b @(r0,r1),r2
    c.r[7] = 0x7Fu;  // 0607DFF4 mov #127,r7
    c.r[7] &= c.r[2];  // 0607DFF6 and r2,r7
    c.r[1] += c.r[3];  // 0607DFF8 add r3,r1
    c.r[1] += 1;  // 0607DFFA add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607DFFC mov.b @r1,r2
    c.r[7] <<= 8;  // 0607DFFE shll8 r7
    c.r[2] = c.r[2] & 0xFFu;  // 0607E000 extu.b r2,r2
    c.r[2] |= c.r[7];  // 0607E002 or r7,r2
    c.r[1] = ld32(0x0607E074u);  // 0607E004 mov.l 0x0607E074,r1
    c.macl = c.r[2] * c.r[13];  // 0607E006 mul.l r13,r2
    c.r[7] = ld32(c.r[1]);  // 0607E008 mov.l @r1,r7
    c.r[3] += c.r[4];  // 0607E00A add r4,r3
    c.r[1] = c.macl;  // 0607E00C sts macl,r1
    c.r[1] += c.r[7];  // 0607E00E add r7,r1
    c.r[1] += 15;  // 0607E010 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E012 mov.b @r1,r1
    c.r[3] += 1;  // 0607E014 add #1,r3
    c.r[6] = c.r[1] & 0xFFu;  // 0607E016 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E018 mov.b @(r0,r4),r1
    c.r[2] = 0x7Fu;  // 0607E01A mov #127,r2
    c.r[2] &= c.r[1];  // 0607E01C and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E01E mov.b @r3,r1
    c.r[2] <<= 8;  // 0607E020 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607E022 extu.b r1,r1
    c.r[1] |= c.r[2];  // 0607E024 or r2,r1
    c.macl = c.r[1] * c.r[13];  // 0607E026 mul.l r13,r1
    c.r[1] = c.macl;  // 0607E028 sts macl,r1
    c.r[1] += c.r[7];  // 0607E02A add r7,r1
    c.r[1] += 15;  // 0607E02C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E02E mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607E030 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607E06Cu);  // 0607E032 mov.w 0x0607E06C,r1
    c.t = c.r[6] == c.r[1];  // 0607E034 cmp/eq r1,r6
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0607E050; } }  // 0607E036 bt/s 0x0607E050 ; mov #0,r8
    c.r[1] = ld32(0x0607E078u);  // 0607E03A mov.l 0x0607E078,r1
    c.r[2] = c.r[6];  // 0607E03C mov r6,r2
    c.r[2] += c.r[2];  // 0607E03E add r2,r2
    c.r[2] += c.r[6];  // 0607E040 add r6,r2
    c.r[1] = ld32(c.r[1]);  // 0607E042 mov.l @r1,r1
    c.r[2] <<= 2;  // 0607E044 shll2 r2
    c.r[2] += c.r[1];  // 0607E046 add r1,r2
    c.r[2] += 2;  // 0607E048 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E04A mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0607E04C extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607E06Cu);  // 0607E04E mov.w 0x0607E06C,r1
L_0607E050:
    c.t = c.r[3] == c.r[1];  // 0607E050 cmp/eq r1,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0607E07C; } }  // 0607E052 bt/s 0x0607E07C ; mov r3,r2
    c.r[1] = ld32(0x0607E078u);  // 0607E056 mov.l 0x0607E078,r1
    c.r[2] += c.r[2];  // 0607E058 add r2,r2
    c.r[2] += c.r[3];  // 0607E05A add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0607E05C mov.l @r1,r1
    c.r[2] <<= 2;  // 0607E05E shll2 r2
    c.r[2] += c.r[1];  // 0607E060 add r1,r2
    c.r[2] += 2;  // 0607E062 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E064 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_0607E07E;  // 0607E066 bra 0x0607E07E ; extu.b r1,r1
L_0607E07C:
    c.r[1] = 0x0u;  // 0607E07C mov #0,r1
L_0607E07E:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607E07E cmp/ge r1,r8
    { const bool k = c.t; c.r[8] = c.r[9]; if (k) { goto L_0607E114; } }  // 0607E080 bt/s 0x0607E114 ; mov r9,r8
    c.r[8] += c.r[8];  // 0607E084 add r8,r8
    c.r[3] = ld32(c.r[11]);  // 0607E086 mov.l @r11,r3
    c.r[5] = 0x7Fu;  // 0607E088 mov #127,r5
    c.r[0] = c.r[3];  // 0607E08A mov r3,r0
    c.r[6] = c.r[3];  // 0607E08C mov r3,r6
    c.r[6] += c.r[8];  // 0607E08E add r8,r6
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607E090 mov.b @(r0,r8),r10
    c.r[6] += 1;  // 0607E092 add #1,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607E094 mov.b @r6,r7
    c.r[2] = 0x7Fu;  // 0607E096 mov #127,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E098 mov.b @(r0,r4),r1
    c.r[5] &= c.r[10];  // 0607E09A and r10,r5
    c.r[5] <<= 8;  // 0607E09C shll8 r5
    c.r[7] = c.r[7] & 0xFFu;  // 0607E09E extu.b r7,r7
    c.r[2] &= c.r[1];  // 0607E0A0 and r1,r2
    c.r[2] <<= 8;  // 0607E0A2 shll8 r2
    c.r[1] = c.r[3];  // 0607E0A4 mov r3,r1
    c.r[1] += c.r[4];  // 0607E0A6 add r4,r1
    c.r[1] += 1;  // 0607E0A8 add #1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E1B6u);  // 0607E0AA mov.w 0x0607E1B6,r0
    c.r[10] &= c.r[0];  // 0607E0AC and r0,r10
    c.r[0] = c.r[3];  // 0607E0AE mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E0B0 mov.b @r1,r1
    c.r[7] |= c.r[5];  // 0607E0B2 or r5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607E0B4 extu.b r1,r1
    c.r[1] |= c.r[2];  // 0607E0B6 or r2,r1
    c.r[2] = c.r[1];  // 0607E0B8 mov r1,r2
    c.r[2] >>= 8;  // 0607E0BA shlr8 r2
    c.r[10] |= c.r[2];  // 0607E0BC or r2,r10
    st8(c.r[0] + c.r[8], c.r[10]);  // 0607E0BE mov.b r10,@(r0,r8)
    st8(c.r[6], c.r[1]);  // 0607E0C0 mov.b r1,@r6
    c.r[1] = ld32(c.r[11]);  // 0607E0C2 mov.l @r11,r1
    c.r[2] = c.r[7];  // 0607E0C4 mov r7,r2
    c.r[0] = c.r[1];  // 0607E0C6 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E0C8 mov.b @(r0,r4),r3
    c.r[2] >>= 8;  // 0607E0CA shlr8 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E1B6u);  // 0607E0CC mov.w 0x0607E1B6,r0
    c.r[3] &= c.r[0];  // 0607E0CE and r0,r3
    c.r[3] |= c.r[2];  // 0607E0D0 or r2,r3
    c.r[0] = c.r[1];  // 0607E0D2 mov r1,r0
    st8(c.r[0] + c.r[4], c.r[3]);  // 0607E0D4 mov.b r3,@(r0,r4)
    c.r[1] += c.r[4];  // 0607E0D6 add r4,r1
    c.r[1] += 1;  // 0607E0D8 add #1,r1
    st8(c.r[1], c.r[7]);  // 0607E0DA mov.b r7,@r1
    c.r[1] = ld32(c.r[11]);  // 0607E0DC mov.l @r11,r1
    c.r[0] = c.r[1];  // 0607E0DE mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E0E0 mov.b @(r0,r4),r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607E1B6u);  // 0607E0E2 mov.w 0x0607E1B6,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607E0E4 mov.b @(r0,r8),r3
    c.r[7] &= c.r[2];  // 0607E0E6 and r2,r7
    c.r[2] = 0x7Fu;  // 0607E0E8 mov #127,r2
    c.r[2] &= c.r[3];  // 0607E0EA and r3,r2
    c.r[2] |= c.r[7];  // 0607E0EC or r7,r2
    st8(c.r[0] + c.r[8], c.r[2]);  // 0607E0EE mov.b r2,@(r0,r8)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E1B6u);  // 0607E0F0 mov.w 0x0607E1B6,r2
    c.r[1] = ld32(c.r[11]);  // 0607E0F2 mov.l @r11,r1
    c.r[2] &= c.r[3];  // 0607E0F4 and r3,r2
    c.r[0] = c.r[1];  // 0607E0F6 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E0F8 mov.b @(r0,r4),r3
    c.r[0] = 0x7Fu;  // 0607E0FA mov #127,r0
    c.r[3] &= c.r[0];  // 0607E0FC and r0,r3
    c.r[3] |= c.r[2];  // 0607E0FE or r2,r3
    c.r[0] = c.r[1];  // 0607E100 mov r1,r0
    st8(c.r[0] + c.r[4], c.r[3]);  // 0607E102 mov.b r3,@(r0,r4)
    c.r[2] = ld32(0x0607E1BCu);  // 0607E104 mov.l 0x0607E1BC,r2
    c.r[0] = c.r[9];  // 0607E106 mov r9,r0
    c.r[3] = c.r[2];  // 0607E108 mov r2,r3
    c.r[3] += 1;  // 0607E10A add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607E10C mov.b @(r0,r3),r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E10E mov.b @(r0,r2),r7
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607E110 mov.b r1,@(r0,r2)
    st8(c.r[0] + c.r[3], c.r[7]);  // 0607E112 mov.b r7,@(r0,r3)
L_0607E114:
    c.r[1] = ld32(0x0607E1C0u);  // 0607E114 mov.l 0x0607E1C0,r1
    c.r[1] = ld32(c.r[1]);  // 0607E116 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E1B8u);  // 0607E118 mov.w 0x0607E1B8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607E11A mov.b @(r0,r1),r1
    c.r[9] += 1;  // 0607E11C add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0607E11E extu.b r1,r1
    c.r[1] -= c.r[12];  // 0607E120 sub r12,r1
    c.r[1] -= 1;  // 0607E122 add #-1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0607E124 cmp/ge r1,r9
    { const bool k = c.t; c.r[4] += 2; if (k) { goto L_0607E12E; } }  // 0607E126 bt/s 0x0607E12E ; add #2,r4
    SH2_POLL(c); goto L_0607DFEA;  // 0607E12A bra 0x0607DFEA ; nop
L_0607E12E:
    c.r[3] = ld32(0x0607E1C0u);  // 0607E12E mov.l 0x0607E1C0,r3
    c.r[1] = ld32(c.r[3]);  // 0607E130 mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E1B8u);  // 0607E132 mov.w 0x0607E1B8,r2
    c.r[0] = c.r[1];  // 0607E134 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E136 mov.b @(r0,r2),r1
    c.r[12] += 1;  // 0607E138 add #1,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0607E13A extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607E13C cmp/ge r1,r12
    if (c.t) { goto L_0607E144; }  // 0607E13E bt 0x0607E144
    SH2_POLL(c); goto L_0607DFD4;  // 0607E140 bra 0x0607DFD4 ; nop
L_0607E144:
    c.r[1] = ld32(0x0607E1C0u);  // 0607E144 mov.l 0x0607E1C0,r1
    c.r[2] = ld32(c.r[1]);  // 0607E146 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E1B8u);  // 0607E148 mov.w 0x0607E1B8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E14A mov.b @(r0,r2),r1
    c.r[12] = c.r[1] & 0xFFu;  // 0607E14C extu.b r1,r12
    c.r[12] -= 1;  // 0607E14E add #-1,r12
    c.t = (int32_t)c.r[12] >= 0;  // 0607E150 cmp/pz r12
    { const bool k = !c.t; c.r[6] = c.r[2]; if (k) { goto L_0607E196; } }  // 0607E152 bf/s 0x0607E196 ; mov r2,r6
    c.r[1] = ld32(0x0607E1C4u);  // 0607E156 mov.l 0x0607E1C4,r1
    c.r[5] = ld32(c.r[1]);  // 0607E158 mov.l @r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607E1BAu);  // 0607E15A mov.w 0x0607E1BA,r4
    c.r[0] = c.r[12];  // 0607E15C mov r12,r0
    c.r[0] += c.r[0];  // 0607E15E add r0,r0
    c.r[7] = c.r[0];  // 0607E160 mov r0,r7
    c.r[7] += c.r[6];  // 0607E162 add r6,r7
    c.r[3] = c.r[0];  // 0607E164 mov r0,r3
L_0607E166:
    c.r[0] = c.r[3];  // 0607E166 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607E168 mov.b @(r0,r6),r1
    c.r[8] = 0x7Fu;  // 0607E16A mov #127,r8
    c.r[8] &= c.r[1];  // 0607E16C and r1,r8
    c.r[1] = c.r[7];  // 0607E16E mov r7,r1
    c.r[1] += 1;  // 0607E170 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E172 mov.b @r1,r2
    c.r[8] <<= 8;  // 0607E174 shll8 r8
    c.r[2] = c.r[2] & 0xFFu;  // 0607E176 extu.b r2,r2
    c.r[2] |= c.r[8];  // 0607E178 or r8,r2
    c.r[1] = 0x1Eu;  // 0607E17A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0607E17C mul.l r1,r2
    c.r[1] = c.macl;  // 0607E17E sts macl,r1
    c.r[1] += c.r[5];  // 0607E180 add r5,r1
    c.r[1] += 15;  // 0607E182 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E184 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607E186 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0607E188 cmp/eq r4,r1
    { const bool k = !c.t; c.r[7] -= 2; if (k) { goto L_0607E196; } }  // 0607E18A bf/s 0x0607E196 ; add #-2,r7
    c.r[12] -= 1;  // 0607E18E add #-1,r12
    c.t = (int32_t)c.r[12] >= 0;  // 0607E190 cmp/pz r12
    { const bool k = c.t; c.r[3] -= 2; if (k) { SH2_POLL(c); goto L_0607E166; } }  // 0607E192 bt/s 0x0607E166 ; add #-2,r3
L_0607E196:
    c.r[12] += 1;  // 0607E196 add #1,r12
    st32(c.r[14], c.r[12]);  // 0607E198 mov.l r12,@r14
    c.r[3] = ld32(0x0607E1C0u);  // 0607E19A mov.l 0x0607E1C0,r3
    c.r[1] = ld32(c.r[3]);  // 0607E19C mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E1B8u);  // 0607E19E mov.w 0x0607E1B8,r2
    c.r[0] = c.r[1];  // 0607E1A0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]); goto L_0607E2BC;  // 0607E1A2 bra 0x0607E2BC ; mov.b @(r0,r2),r1
L_0607E1A6:
    c.r[0] = ld32(0x0607E1C0u);  // 0607E1A6 mov.l 0x0607E1C0,r0
    c.r[1] = ld32(c.r[0]);  // 0607E1A8 mov.l @r0,r1
    c.r[0] = c.r[1];  // 0607E1AA mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E1AC mov.b @(r0,r2),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607E1AE extu.b r2,r2
    c.r[1] = c.r[12];  // 0607E1B0 mov r12,r1
    c.r[1] -= c.r[9]; goto L_0607E2A6;  // 0607E1B2 bra 0x0607E2A6 ; sub r9,r1
L_0607E1C8:
    c.r[0] = ld32(0x0607E2E0u);  // 0607E1C8 mov.l 0x0607E2E0,r0
    c.r[4] += c.r[4];  // 0607E1CA add r4,r4
    c.r[2] = 0x7Fu;  // 0607E1CC mov #127,r2
    c.r[13] = c.r[9];  // 0607E1CE mov r9,r13
    c.r[13] += 1;  // 0607E1D0 add #1,r13
    c.r[5] = ld32(c.r[0]);  // 0607E1D2 mov.l @r0,r5
    c.r[6] = c.r[13];  // 0607E1D4 mov r13,r6
    c.r[0] = c.r[5];  // 0607E1D6 mov r5,r0
    c.r[11] = c.r[5];  // 0607E1D8 mov r5,r11
    c.r[11] += c.r[4];  // 0607E1DA add r4,r11
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E1DC mov.b @(r0,r4),r10
    c.r[11] += 1;  // 0607E1DE add #1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0607E1E0 mov.b @r11,r1
    c.r[2] &= c.r[10];  // 0607E1E2 and r10,r2
    c.r[2] <<= 8;  // 0607E1E4 shll8 r2
    c.r[3] = c.r[1] & 0xFFu;  // 0607E1E6 extu.b r1,r3
    c.r[3] |= c.r[2];  // 0607E1E8 or r2,r3
    c.r[1] = ld32(0x0607E2E4u);  // 0607E1EA mov.l 0x0607E2E4,r1
    c.r[0] = 0x1Eu;  // 0607E1EC mov #30,r0
    c.macl = c.r[3] * c.r[0];  // 0607E1EE mul.l r0,r3
    c.r[2] = ld32(c.r[1]);  // 0607E1F0 mov.l @r1,r2
    c.r[6] += c.r[6];  // 0607E1F2 add r6,r6
    c.r[1] = c.macl;  // 0607E1F4 sts macl,r1
    c.r[1] += c.r[2];  // 0607E1F6 add r2,r1
    c.r[1] += 22;  // 0607E1F8 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607E1FA mov.w @r1,r1
    c.r[0] = c.r[5];  // 0607E1FC mov r5,r0
    c.r[8] = c.r[1] & 0xFFFFu;  // 0607E1FE extu.w r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607E200 mov.b @(r0,r6),r1
    c.r[0] = c.r[1];  // 0607E202 mov r1,r0
    c.r[0] &= 0x7Fu;  // 0607E204 and #127,r0
    c.r[1] = c.r[5];  // 0607E206 mov r5,r1
    c.r[1] += c.r[6];  // 0607E208 add r6,r1
    c.r[1] += 1;  // 0607E20A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E20C mov.b @r1,r1
    c.r[0] <<= 8;  // 0607E20E shll8 r0
    c.r[7] = c.r[1] & 0xFFu;  // 0607E210 extu.b r1,r7
    c.r[7] |= c.r[0];  // 0607E212 or r0,r7
    c.r[0] = 0x1Eu;  // 0607E214 mov #30,r0
    c.macl = c.r[7] * c.r[0];  // 0607E216 mul.l r0,r7
    c.r[1] = c.macl;  // 0607E218 sts macl,r1
    c.r[1] += c.r[2];  // 0607E21A add r2,r1
    c.r[1] += 22;  // 0607E21C add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607E21E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607E220 extu.w r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0607E222 cmp/ge r1,r8
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0607E292; } }  // 0607E224 bt/s 0x0607E292 ; mov r7,r1
    c.r[1] >>= 8;  // 0607E228 shlr8 r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E2DCu);  // 0607E22A mov.w 0x0607E2DC,r2
    c.r[2] &= c.r[10];  // 0607E22C and r10,r2
    c.r[2] |= c.r[1];  // 0607E22E or r1,r2
    c.r[0] = c.r[5];  // 0607E230 mov r5,r0
    st8(c.r[0] + c.r[4], c.r[2]);  // 0607E232 mov.b r2,@(r0,r4)
    st8(c.r[11], c.r[7]);  // 0607E234 mov.b r7,@r11
    c.r[0] = ld32(0x0607E2E0u);  // 0607E236 mov.l 0x0607E2E0,r0
    c.r[1] = ld32(c.r[0]);  // 0607E238 mov.l @r0,r1
    c.r[2] = c.r[3];  // 0607E23A mov r3,r2
    c.r[0] = c.r[1];  // 0607E23C mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607E23E mov.b @(r0,r6),r7
    c.r[2] >>= 8;  // 0607E240 shlr8 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E2DCu);  // 0607E242 mov.w 0x0607E2DC,r0
    c.r[7] &= c.r[0];  // 0607E244 and r0,r7
    c.r[7] |= c.r[2];  // 0607E246 or r2,r7
    c.r[0] = c.r[1];  // 0607E248 mov r1,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 0607E24A mov.b r7,@(r0,r6)
    c.r[1] += c.r[6];  // 0607E24C add r6,r1
    c.r[1] += 1;  // 0607E24E add #1,r1
    st8(c.r[1], c.r[3]);  // 0607E250 mov.b r3,@r1
    c.r[0] = ld32(0x0607E2E0u);  // 0607E252 mov.l 0x0607E2E0,r0
    c.r[1] = ld32(c.r[0]);  // 0607E254 mov.l @r0,r1
    c.r[0] = c.r[1];  // 0607E256 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607E258 mov.b @(r0,r6),r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607E2DCu);  // 0607E25A mov.w 0x0607E2DC,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607E25C mov.b @(r0,r4),r3
    c.r[7] &= c.r[2];  // 0607E25E and r2,r7
    c.r[2] = 0x7Fu;  // 0607E260 mov #127,r2
    c.r[2] &= c.r[3];  // 0607E262 and r3,r2
    c.r[2] |= c.r[7];  // 0607E264 or r7,r2
    st8(c.r[0] + c.r[4], c.r[2]);  // 0607E266 mov.b r2,@(r0,r4)
    c.r[0] = ld32(0x0607E2E0u);  // 0607E268 mov.l 0x0607E2E0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E2DCu);  // 0607E26A mov.w 0x0607E2DC,r2
    c.r[1] = ld32(c.r[0]);  // 0607E26C mov.l @r0,r1
    c.r[2] &= c.r[3];  // 0607E26E and r3,r2
    c.r[0] = c.r[1];  // 0607E270 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607E272 mov.b @(r0,r6),r3
    c.r[0] = 0x7Fu;  // 0607E274 mov #127,r0
    c.r[3] &= c.r[0];  // 0607E276 and r0,r3
    c.r[3] |= c.r[2];  // 0607E278 or r2,r3
    c.r[0] = c.r[1];  // 0607E27A mov r1,r0
    st8(c.r[0] + c.r[6], c.r[3]);  // 0607E27C mov.b r3,@(r0,r6)
    c.r[0] = ld32(0x0607E2E8u);  // 0607E27E mov.l 0x0607E2E8,r0
    c.r[2] = ld32(0x0607E2E8u);  // 0607E280 mov.l 0x0607E2E8,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607E282 mov.b @(r0,r9),r3
    c.r[2] += 1;  // 0607E284 add #1,r2
    c.r[0] = c.r[9];  // 0607E286 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E288 mov.b @(r0,r2),r1
    c.r[0] = ld32(0x0607E2E8u);  // 0607E28A mov.l 0x0607E2E8,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 0607E28C mov.b r1,@(r0,r9)
    c.r[0] = c.r[9];  // 0607E28E mov r9,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 0607E290 mov.b r3,@(r0,r2)
L_0607E292:
    c.r[0] = ld32(0x0607E2E0u);  // 0607E292 mov.l 0x0607E2E0,r0
    c.r[1] = ld32(c.r[0]);  // 0607E294 mov.l @r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E2DEu);  // 0607E296 mov.w 0x0607E2DE,r2
    c.r[0] = c.r[1];  // 0607E298 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E29A mov.b @(r0,r2),r2
    c.r[9] = c.r[13];  // 0607E29C mov r13,r9
    c.r[2] = c.r[2] & 0xFFu;  // 0607E29E extu.b r2,r2
    c.r[0] = ld32(c.r[14]);  // 0607E2A0 mov.l @r14,r0
    c.r[1] = c.r[12];  // 0607E2A2 mov r12,r1
    c.r[1] -= c.r[0];  // 0607E2A4 sub r0,r1
L_0607E2A6:
    c.r[2] -= c.r[1];  // 0607E2A6 sub r1,r2
    c.r[2] -= 1;  // 0607E2A8 add #-1,r2
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[2];  // 0607E2AA cmp/ge r2,r9
    { const bool k = !c.t; c.r[4] = c.r[9]; if (k) { SH2_POLL(c); goto L_0607E1C8; } }  // 0607E2AC bf/s 0x0607E1C8 ; mov r9,r4
    c.r[3] = ld32(0x0607E2E0u);  // 0607E2B0 mov.l 0x0607E2E0,r3
    c.r[1] = ld32(c.r[3]);  // 0607E2B2 mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E2DEu);  // 0607E2B4 mov.w 0x0607E2DE,r2
    c.r[0] = c.r[1];  // 0607E2B6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0607E2B8 mov.b @(r0,r2),r1
    c.r[12] += 1;  // 0607E2BA add #1,r12
L_0607E2BC:
    c.r[1] = c.r[1] & 0xFFu;  // 0607E2BC extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607E2BE cmp/ge r1,r12
    { const bool k = c.t; c.r[9] = ld32(c.r[14]); if (k) { goto L_0607E2C8; } }  // 0607E2C0 bt/s 0x0607E2C8 ; mov.l @r14,r9
    SH2_POLL(c); goto L_0607E1A6;  // 0607E2C4 bra 0x0607E1A6 ; nop
L_0607E2C8:
    c.r[14] += 8;  // 0607E2C8 add #8,r14
    c.r[15] = c.r[14];  // 0607E2CA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607E2CC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607E2CE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607E2D0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607E2D2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607E2D4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607E2D6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607E2D8 rts ; mov.l @r15+,r8
}

void f_0607E2EC(SH2Context& c) {
    ran[1757] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607E2EC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607E2EE mov r15,r14
    c.r[1] = ld32(0x0607E3FCu);  // 0607E2F0 mov.l 0x0607E3FC,r1
    c.r[6] = ld32(0x0607E400u);  // 0607E2F2 mov.l 0x0607E400,r6
    c.r[7] = ld32(0x0607E404u);  // 0607E2F4 mov.l 0x0607E404,r7
    c.r[5] = 0xFu;  // 0607E2F6 mov #15,r5
    c.r[2] = ld32(c.r[1]);  // 0607E2F8 mov.l @r1,r2
    c.r[1] = ld32(0x0607E408u);  // 0607E2FA mov.l 0x0607E408,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E2FC mov.b @r1,r1
    c.r[0] = c.r[2];  // 0607E2FE mov r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607E300 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607E302 add r1,r1
    c.r[2] += c.r[1];  // 0607E304 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607E306 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 0607E308 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E30A mov.b @r2,r2
    c.r[0] = 0x7Fu;  // 0607E30C mov #127,r0
    c.r[3] &= c.r[0];  // 0607E30E and r0,r3
    c.r[3] <<= 8;  // 0607E310 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607E312 extu.b r2,r2
    c.r[2] |= c.r[3];  // 0607E314 or r3,r2
    c.r[1] = 0x1Eu;  // 0607E316 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0607E318 mul.l r1,r2
    c.r[3] = ld32(c.r[6]);  // 0607E31A mov.l @r6,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E3F2u);  // 0607E31C mov.w 0x0607E3F2,r0
    c.r[1] = ld32(c.r[7]);  // 0607E31E mov.l @r7,r1
    c.r[2] = c.macl;  // 0607E320 sts macl,r2
    c.r[1] += 3;  // 0607E322 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E324 mov.b @r1,r1
    c.r[2] += c.r[3];  // 0607E326 add r3,r2
    c.r[5] &= c.r[1];  // 0607E328 and r1,r5
    c.r[3] = c.r[5];  // 0607E32A mov r5,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0607E32C shlr r3
    c.r[1] = c.r[2];  // 0607E32E mov r2,r1
    c.r[1] += 3;  // 0607E330 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E332 mov.b @r1,r4
    c.r[2] += 4;  // 0607E334 add #4,r2
    c.r[4] &= c.r[0];  // 0607E336 and r0,r4
    c.r[4] |= c.r[3];  // 0607E338 or r3,r4
    st8(c.r[1], c.r[4]);  // 0607E33A mov.b r4,@r1
    c.r[0] = 0x1u;  // 0607E33C mov #1,r0
    c.r[5] &= c.r[0];  // 0607E33E and r0,r5
    c.r[5] <<= 2;  // 0607E340 shll2 r5
    c.r[5] <<= 2;  // 0607E342 shll2 r5
    c.r[5] += c.r[5];  // 0607E344 add r5,r5
    c.r[5] <<= 2;  // 0607E346 shll2 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E348 mov.b @r2,r1
    c.r[0] = 0x7Fu;  // 0607E34A mov #127,r0
    c.r[1] &= c.r[0];  // 0607E34C and r0,r1
    c.r[1] |= c.r[5];  // 0607E34E or r5,r1
    st8(c.r[2], c.r[1]);  // 0607E350 mov.b r1,@r2
    c.r[1] = ld32(c.r[6]);  // 0607E352 mov.l @r6,r1
    c.r[2] = c.macl;  // 0607E354 sts macl,r2
    c.r[2] += c.r[1];  // 0607E356 add r1,r2
    c.r[1] = ld32(c.r[7]);  // 0607E358 mov.l @r7,r1
    c.r[0] = 0x78u;  // 0607E35A mov #120,r0
    c.r[1] += 4;  // 0607E35C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E35E mov.b @r1,r1
    c.r[2] += 4;  // 0607E360 add #4,r2
    c.r[3] = c.r[1];  // 0607E362 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0607E364 shlr r3
    c.r[3] &= c.r[0];  // 0607E366 and r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E368 mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E3F4u);  // 0607E36A mov.w 0x0607E3F4,r0
    c.r[1] &= c.r[0];  // 0607E36C and r0,r1
    c.r[1] |= c.r[3];  // 0607E36E or r3,r1
    st8(c.r[2], c.r[1]);  // 0607E370 mov.b r1,@r2
    c.r[1] = ld32(c.r[6]);  // 0607E372 mov.l @r6,r1
    c.r[2] = c.macl;  // 0607E374 sts macl,r2
    c.r[2] += c.r[1];  // 0607E376 add r1,r2
    c.r[1] = ld32(c.r[7]);  // 0607E378 mov.l @r7,r1
    c.r[5] = 0xFu;  // 0607E37A mov #15,r5
    c.r[1] += 5;  // 0607E37C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E37E mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E3F2u);  // 0607E380 mov.w 0x0607E3F2,r0
    c.r[5] &= c.r[1];  // 0607E382 and r1,r5
    c.r[3] = c.r[5];  // 0607E384 mov r5,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0607E386 shlr r3
    c.r[1] = c.r[2];  // 0607E388 mov r2,r1
    c.r[1] += 5;  // 0607E38A add #5,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E38C mov.b @r1,r4
    c.r[2] += 6;  // 0607E38E add #6,r2
    c.r[4] &= c.r[0];  // 0607E390 and r0,r4
    c.r[4] |= c.r[3];  // 0607E392 or r3,r4
    st8(c.r[1], c.r[4]);  // 0607E394 mov.b r4,@r1
    c.r[0] = 0x1u;  // 0607E396 mov #1,r0
    c.r[5] &= c.r[0];  // 0607E398 and r0,r5
    c.r[5] <<= 2;  // 0607E39A shll2 r5
    c.r[5] <<= 2;  // 0607E39C shll2 r5
    c.r[5] += c.r[5];  // 0607E39E add r5,r5
    c.r[5] <<= 2;  // 0607E3A0 shll2 r5
    c.r[0] = 0x7Fu;  // 0607E3A2 mov #127,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E3A4 mov.b @r2,r1
    c.r[3] = c.macl;  // 0607E3A6 sts macl,r3
    c.r[1] &= c.r[0];  // 0607E3A8 and r0,r1
    c.r[1] |= c.r[5];  // 0607E3AA or r5,r1
    st8(c.r[2], c.r[1]);  // 0607E3AC mov.b r1,@r2
    c.r[5] = 0xFu;  // 0607E3AE mov #15,r5
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E3F6u);  // 0607E3B0 mov.w 0x0607E3F6,r2
    c.r[1] = ld32(c.r[6]);  // 0607E3B2 mov.l @r6,r1
    c.r[0] = 0x78u;  // 0607E3B4 mov #120,r0
    c.r[6] = ld32(c.r[7]);  // 0607E3B6 mov.l @r7,r6
    c.r[3] += c.r[1];  // 0607E3B8 add r1,r3
    c.r[1] = c.r[6];  // 0607E3BA mov r6,r1
    c.r[1] += 4;  // 0607E3BC add #4,r1
    c.r[7] = c.r[3];  // 0607E3BE mov r3,r7
    c.r[7] += 4;  // 0607E3C0 add #4,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E3C2 mov.b @r1,r1
    c.r[6] += 5;  // 0607E3C4 add #5,r6
    c.r[5] &= c.r[1];  // 0607E3C6 and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0607E3C8 mov.w @r7,r1
    c.r[5] <<= 2;  // 0607E3CA shll2 r5
    c.r[5] <<= 2;  // 0607E3CC shll2 r5
    c.r[5] += c.r[5];  // 0607E3CE add r5,r5
    c.r[5] <<= 2;  // 0607E3D0 shll2 r5
    c.r[1] &= c.r[2];  // 0607E3D2 and r2,r1
    c.r[1] |= c.r[5];  // 0607E3D4 or r5,r1
    st16(c.r[7], c.r[1]);  // 0607E3D6 mov.w r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607E3D8 mov.b @r6,r1
    c.r[3] += 5;  // 0607E3DA add #5,r3
    c.r[2] = c.r[1];  // 0607E3DC mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607E3DE shlr r2
    c.r[2] &= c.r[0];  // 0607E3E0 and r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E3E2 mov.b @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E3F4u);  // 0607E3E4 mov.w 0x0607E3F4,r0
    c.r[1] &= c.r[0];  // 0607E3E6 and r0,r1
    c.r[1] |= c.r[2];  // 0607E3E8 or r2,r1
    st8(c.r[3], c.r[1]);  // 0607E3EA mov.b r1,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E3F8u);  // 0607E3EC mov.w 0x0607E3F8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607E3EE rts ; mov.l @r15+,r14
}

void f_0607E40C(SH2Context& c) {
    ran[1758] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607E40C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607E40E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607E410 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607E412 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607E414 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607E416 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607E418 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607E41A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607E5D6u);  // 0607E41C mov.w 0x0607E5D6,r3
    c.r[15] += c.r[3];  // 0607E41E add r3,r15
    c.r[14] = c.r[15];  // 0607E420 mov r15,r14
    c.r[1] = ld32(0x0607E5E4u);  // 0607E422 mov.l 0x0607E5E4,r1
    c.r[2] = ld32(c.r[1]);  // 0607E424 mov.l @r1,r2
    c.r[13] = 0x7Fu;  // 0607E426 mov #127,r13
    c.r[1] = ld32(0x0607E5E8u);  // 0607E428 mov.l 0x0607E5E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E42A mov.b @r1,r1
    c.r[0] = c.r[2];  // 0607E42C mov r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607E42E extu.b r1,r1
    c.r[1] += c.r[1];  // 0607E430 add r1,r1
    c.r[2] += c.r[1];  // 0607E432 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607E434 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 0607E436 add #1,r2
    c.r[3] &= c.r[13];  // 0607E438 and r13,r3
    c.r[3] <<= 8;  // 0607E43A shll8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E43C mov.b @r2,r1
    c.r[13] = ld32(0x0607E5ECu);  // 0607E43E mov.l 0x0607E5EC,r13
    c.r[12] = c.r[1] & 0xFFu;  // 0607E440 extu.b r1,r12
    c.r[1] = ld32(0x0607E5F0u);  // 0607E442 mov.l 0x0607E5F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E444 mov.b @r1,r1
    c.r[12] |= c.r[3];  // 0607E446 or r3,r12
    c.r[2] = c.r[1] & 0xFFu;  // 0607E448 extu.b r1,r2
    c.r[1] = ld32(0x0607E5F4u);  // 0607E44A mov.l 0x0607E5F4,r1
    c.r[0] = c.r[2];  // 0607E44C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607E44E mov.b @(r0,r1),r1
    c.r[4] = c.r[12];  // 0607E450 mov r12,r4
    c.r[8] = c.r[1] & 0xFFu;  // 0607E452 extu.b r1,r8
    { const uint32_t x = c.r[13]; c.pr = 0x0607E458u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E458u) return; }  // 0607E454 jsr @r13 ; mov r8,r5
    c.r[1] = ld32(0x0607E5F8u);  // 0607E458 mov.l 0x0607E5F8,r1
    c.r[3] = ld32(c.r[1]);  // 0607E45A mov.l @r1,r3
    c.r[6] = c.r[0];  // 0607E45C mov r0,r6
    c.r[7] = c.r[3];  // 0607E45E mov r3,r7
    c.r[7] += 10;  // 0607E460 add #10,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0607E462 mov.w @r7,r1
    c.r[3] += 12;  // 0607E464 add #12,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E466 mov.b @r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607E468 extu.w r1,r1
    c.r[1] <<= 8;  // 0607E46A shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607E46C extu.b r2,r2
    c.r[2] |= c.r[1];  // 0607E46E or r1,r2
    c.r[2] -= c.r[6];  // 0607E470 sub r6,r2
    c.r[1] = c.r[2];  // 0607E472 mov r2,r1
    c.r[1] >>= 8;  // 0607E474 shlr8 r1
    st16(c.r[7], c.r[1]);  // 0607E476 mov.w r1,@r7
    c.t = (c.r[8] & c.r[8]) == 0;  // 0607E478 tst r8,r8
    { const bool k = c.t; st8(c.r[3], c.r[2]); if (k) { goto L_0607E4C0; } }  // 0607E47A bt/s 0x0607E4C0 ; mov.b r2,@r3
    c.r[1] = ld32(0x0607E5FCu);  // 0607E47E mov.l 0x0607E5FC,r1
    c.r[3] = ld32(c.r[1]);  // 0607E480 mov.l @r1,r3
    c.r[7] = 0xFu;  // 0607E482 mov #15,r7
    c.r[1] = 0x1Eu;  // 0607E484 mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0607E486 mul.l r1,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E5D8u);  // 0607E488 mov.w 0x0607E5D8,r0
    c.r[13] = 0x1u;  // 0607E48A mov #1,r13
    c.r[1] = ld32(0x0607E600u);  // 0607E48C mov.l 0x0607E600,r1
    c.r[1] = ld32(c.r[1]);  // 0607E48E mov.l @r1,r1
    c.r[2] = c.macl;  // 0607E490 sts macl,r2
    c.r[1] += 3;  // 0607E492 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E494 mov.b @r1,r1
    c.r[2] += c.r[3];  // 0607E496 add r3,r2
    c.r[7] &= c.r[1];  // 0607E498 and r1,r7
    c.r[3] = c.r[7];  // 0607E49A mov r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0607E49C shlr r3
    c.r[1] = c.r[2];  // 0607E49E mov r2,r1
    c.r[1] += 3;  // 0607E4A0 add #3,r1
    c.r[7] &= c.r[13];  // 0607E4A2 and r13,r7
    c.r[2] += 4;  // 0607E4A4 add #4,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E4A6 mov.b @r1,r6
    c.r[7] <<= 2;  // 0607E4A8 shll2 r7
    c.r[7] <<= 2;  // 0607E4AA shll2 r7
    c.r[7] += c.r[7];  // 0607E4AC add r7,r7
    c.r[7] <<= 2;  // 0607E4AE shll2 r7
    c.r[6] &= c.r[0];  // 0607E4B0 and r0,r6
    c.r[6] |= c.r[3];  // 0607E4B2 or r3,r6
    st8(c.r[1], c.r[6]);  // 0607E4B4 mov.b r6,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E4B6 mov.b @r2,r1
    c.r[0] = 0x7Fu;  // 0607E4B8 mov #127,r0
    c.r[1] &= c.r[0];  // 0607E4BA and r0,r1
    c.r[1] |= c.r[7];  // 0607E4BC or r7,r1
    st8(c.r[2], c.r[1]);  // 0607E4BE mov.b r1,@r2
L_0607E4C0:
    c.r[0] = c.r[8];  // 0607E4C0 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 0607E4C2 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0607E4F4; } }  // 0607E4C4 bt/s 0x0607E4F4 ; cmp/eq #2,r0
    c.r[1] = ld32(0x0607E5FCu);  // 0607E4C8 mov.l 0x0607E5FC,r1
    c.r[2] = ld32(c.r[1]);  // 0607E4CA mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607E4CC mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0607E4CE mul.l r1,r12
    c.r[13] = 0x78u;  // 0607E4D0 mov #120,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E5DAu);  // 0607E4D2 mov.w 0x0607E5DA,r0
    c.r[3] = c.macl;  // 0607E4D4 sts macl,r3
    c.r[1] = ld32(0x0607E600u);  // 0607E4D6 mov.l 0x0607E600,r1
    c.r[1] = ld32(c.r[1]);  // 0607E4D8 mov.l @r1,r1
    c.r[3] += c.r[2];  // 0607E4DA add r2,r3
    c.r[1] += 4;  // 0607E4DC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E4DE mov.b @r1,r1
    c.r[3] += 4;  // 0607E4E0 add #4,r3
    c.r[2] = c.r[1];  // 0607E4E2 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607E4E4 shlr r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E4E6 mov.b @r3,r1
    c.r[2] &= c.r[13];  // 0607E4E8 and r13,r2
    c.r[1] &= c.r[0];  // 0607E4EA and r0,r1
    c.r[1] |= c.r[2];  // 0607E4EC or r2,r1
    st8(c.r[3], c.r[1]);  // 0607E4EE mov.b r1,@r3
    c.r[0] = c.r[8];  // 0607E4F0 mov r8,r0
    c.t = c.r[0] == 0x2u;  // 0607E4F2 cmp/eq #2,r0
L_0607E4F4:
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0607E53C; } }  // 0607E4F4 bt/s 0x0607E53C ; mov r8,r0
    c.r[1] = ld32(0x0607E5FCu);  // 0607E4F8 mov.l 0x0607E5FC,r1
    c.r[3] = ld32(c.r[1]);  // 0607E4FA mov.l @r1,r3
    c.r[7] = 0xFu;  // 0607E4FC mov #15,r7
    c.r[1] = 0x1Eu;  // 0607E4FE mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0607E500 mul.l r1,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E5D8u);  // 0607E502 mov.w 0x0607E5D8,r13
    c.r[0] = 0x1u;  // 0607E504 mov #1,r0
    c.r[1] = ld32(0x0607E600u);  // 0607E506 mov.l 0x0607E600,r1
    c.r[1] = ld32(c.r[1]);  // 0607E508 mov.l @r1,r1
    c.r[2] = c.macl;  // 0607E50A sts macl,r2
    c.r[1] += 5;  // 0607E50C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E50E mov.b @r1,r1
    c.r[2] += c.r[3];  // 0607E510 add r3,r2
    c.r[7] &= c.r[1];  // 0607E512 and r1,r7
    c.r[3] = c.r[7];  // 0607E514 mov r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0607E516 shlr r3
    c.r[1] = c.r[2];  // 0607E518 mov r2,r1
    c.r[1] += 5;  // 0607E51A add #5,r1
    c.r[7] &= c.r[0];  // 0607E51C and r0,r7
    c.r[2] += 6;  // 0607E51E add #6,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E520 mov.b @r1,r6
    c.r[7] <<= 2;  // 0607E522 shll2 r7
    c.r[7] <<= 2;  // 0607E524 shll2 r7
    c.r[7] += c.r[7];  // 0607E526 add r7,r7
    c.r[7] <<= 2;  // 0607E528 shll2 r7
    c.r[6] &= c.r[13];  // 0607E52A and r13,r6
    c.r[6] |= c.r[3];  // 0607E52C or r3,r6
    st8(c.r[1], c.r[6]);  // 0607E52E mov.b r6,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E530 mov.b @r2,r1
    c.r[13] = 0x7Fu;  // 0607E532 mov #127,r13
    c.r[1] &= c.r[13];  // 0607E534 and r13,r1
    c.r[1] |= c.r[7];  // 0607E536 or r7,r1
    st8(c.r[2], c.r[1]);  // 0607E538 mov.b r1,@r2
    c.r[0] = c.r[8];  // 0607E53A mov r8,r0
L_0607E53C:
    c.t = c.r[0] == 0x3u;  // 0607E53C cmp/eq #3,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0607E56E; } }  // 0607E53E bt/s 0x0607E56E ; mov r8,r0
    c.r[1] = ld32(0x0607E5FCu);  // 0607E542 mov.l 0x0607E5FC,r1
    c.r[2] = ld32(c.r[1]);  // 0607E544 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607E546 mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0607E548 mul.l r1,r12
    c.r[3] = c.macl;  // 0607E54A sts macl,r3
    c.r[3] += c.r[2];  // 0607E54C add r2,r3
    c.r[1] = ld32(0x0607E600u);  // 0607E54E mov.l 0x0607E600,r1
    c.r[1] = ld32(c.r[1]);  // 0607E550 mov.l @r1,r1
    c.r[3] += 4;  // 0607E552 add #4,r3
    c.r[1] += 4;  // 0607E554 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E556 mov.b @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607E5DCu);  // 0607E558 mov.w 0x0607E5DC,r2
    c.r[0] &= 0xFu;  // 0607E55A and #15,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607E55C mov.w @r3,r1
    c.r[0] <<= 2;  // 0607E55E shll2 r0
    c.r[0] <<= 2;  // 0607E560 shll2 r0
    c.r[0] += c.r[0];  // 0607E562 add r0,r0
    c.r[0] <<= 2;  // 0607E564 shll2 r0
    c.r[1] &= c.r[2];  // 0607E566 and r2,r1
    c.r[1] |= c.r[0];  // 0607E568 or r0,r1
    st16(c.r[3], c.r[1]);  // 0607E56A mov.w r1,@r3
    c.r[0] = c.r[8];  // 0607E56C mov r8,r0
L_0607E56E:
    c.t = c.r[0] == 0x4u;  // 0607E56E cmp/eq #4,r0
    { const bool k = c.t; c.r[13] = 0x78u; if (k) { goto L_0607E59A; } }  // 0607E570 bt/s 0x0607E59A ; mov #120,r13
    c.r[1] = ld32(0x0607E5FCu);  // 0607E574 mov.l 0x0607E5FC,r1
    c.r[2] = ld32(c.r[1]);  // 0607E576 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607E578 mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0607E57A mul.l r1,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E5DAu);  // 0607E57C mov.w 0x0607E5DA,r0
    c.r[3] = c.macl;  // 0607E57E sts macl,r3
    c.r[1] = ld32(0x0607E600u);  // 0607E580 mov.l 0x0607E600,r1
    c.r[1] = ld32(c.r[1]);  // 0607E582 mov.l @r1,r1
    c.r[3] += c.r[2];  // 0607E584 add r2,r3
    c.r[1] += 5;  // 0607E586 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E588 mov.b @r1,r1
    c.r[3] += 5;  // 0607E58A add #5,r3
    c.r[2] = c.r[1];  // 0607E58C mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607E58E shlr r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E590 mov.b @r3,r1
    c.r[2] &= c.r[13];  // 0607E592 and r13,r2
    c.r[1] &= c.r[0];  // 0607E594 and r0,r1
    c.r[1] |= c.r[2];  // 0607E596 or r2,r1
    st8(c.r[3], c.r[1]);  // 0607E598 mov.b r1,@r3
L_0607E59A:
    c.r[8] = (uint32_t)(int16_t)ld16(0x0607E5DEu);  // 0607E59A mov.w 0x0607E5DE,r8
    c.r[5] = c.r[12] & 0xFFu;  // 0607E59C extu.b r12,r5
    c.r[11] = ld32(0x0607E604u);  // 0607E59E mov.l 0x0607E604,r11
    c.r[6] = c.r[8];  // 0607E5A0 mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0607E5A6u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E5A6u) return; }  // 0607E5A2 jsr @r11 ; mov r14,r4
    c.r[7] = ld32(0x0607E5FCu);  // 0607E5A6 mov.l 0x0607E5FC,r7
    c.r[1] = 0x1Eu;  // 0607E5A8 mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0607E5AA mul.l r1,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E5E0u);  // 0607E5AC mov.w 0x0607E5E0,r0
    c.r[2] = ld32(c.r[7]);  // 0607E5AE mov.l @r7,r2
    c.r[3] = c.macl;  // 0607E5B0 sts macl,r3
    c.r[3] += c.r[2];  // 0607E5B2 add r2,r3
    c.r[2] = c.r[3];  // 0607E5B4 mov r3,r2
    c.r[1] = c.r[14];  // 0607E5B6 mov r14,r1
    c.r[1] += 26;  // 0607E5B8 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607E5BA mov.w @r1,r1
    c.r[2] += 22;  // 0607E5BC add #22,r2
    st16(c.r[2], c.r[1]);  // 0607E5BE mov.w r1,@r2
    c.r[1] = c.r[14];  // 0607E5C0 mov r14,r1
    c.r[1] += 28;  // 0607E5C2 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607E5C4 mov.w @r1,r1
    c.r[3] += 24;  // 0607E5C6 add #24,r3
    st16(c.r[3], c.r[1]);  // 0607E5C8 mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607E5CA mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0607E5CC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607E5CE shlr r0
    c.r[0] &= 0xFu;  // 0607E5D0 and #15,r0
    c.t = c.r[0] == 0x4u; goto L_0607E608;  // 0607E5D2 bra 0x0607E608 ; cmp/eq #4,r0
L_0607E608:
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0607E610; } }  // 0607E608 bt/s 0x0607E610 ; mov #0,r0
    goto L_0607E798;  // 0607E60C bra 0x0607E798 ; nop
L_0607E610:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C2u);  // 0607E610 mov.w 0x0607E7C2,r13
    c.r[13] += c.r[14];  // 0607E612 add r14,r13
    st32(c.r[13], c.r[0]);  // 0607E614 mov.l r0,@r13
    c.r[10] = 0x0u;  // 0607E616 mov #0,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607E7C4u);  // 0607E618 mov.w 0x0607E7C4,r9
    c.r[9] += c.r[14];  // 0607E61A add r14,r9
    c.r[11] = c.r[7];  // 0607E61C mov r7,r11
    c.r[0] = c.r[9];  // 0607E61E mov r9,r0
    c.r[0] += 28;  // 0607E620 add #28,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C6u);  // 0607E622 mov.w 0x0607E7C6,r13
    c.r[13] += c.r[14];  // 0607E624 add r14,r13
    st32(c.r[13], c.r[0]);  // 0607E626 mov.l r0,@r13
    c.r[8] = 0x0u;  // 0607E628 mov #0,r8
L_0607E62A:
    c.r[0] = c.r[10] & 0xFFu;  // 0607E62A extu.b r10,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C8u);  // 0607E62C mov.w 0x0607E7C8,r13
    c.r[13] += c.r[14];  // 0607E62E add r14,r13
    st32(c.r[13], c.r[0]);  // 0607E630 mov.l r0,@r13
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607E7CAu);  // 0607E632 mov.w 0x0607E7CA,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C8u);  // 0607E634 mov.w 0x0607E7C8,r13
    c.r[13] += c.r[14];  // 0607E636 add r14,r13
    c.r[4] = c.r[9];  // 0607E638 mov r9,r4
    c.r[0] = ld32(0x0607E7DCu);  // 0607E63A mov.l 0x0607E7DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607E640u; c.r[5] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E640u) return; }  // 0607E63C jsr @r0 ; mov.l @r13,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607E7CCu);  // 0607E640 mov.w 0x0607E7CC,r1
    c.r[0] = c.r[9];  // 0607E642 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607E644 mov.b @(r0,r1),r1
    c.r[13] = 0xFu;  // 0607E646 mov #15,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E648 shlr r1
    c.r[1] &= c.r[13];  // 0607E64A and r13,r1
    c.r[0] = c.r[1];  // 0607E64C mov r1,r0
    c.t = c.r[0] == 0x4u;  // 0607E64E cmp/eq #4,r0
    { const bool k = c.t; c.r[1] = 0x1Eu; if (k) { goto L_0607E658; } }  // 0607E650 bt/s 0x0607E658 ; mov #30,r1
    goto L_0607E78A;  // 0607E654 bra 0x0607E78A ; nop
L_0607E658:
    c.r[3] = c.r[8];  // 0607E658 mov r8,r3
    c.r[7] = 0x7u;  // 0607E65A mov #7,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7CEu);  // 0607E65C mov.w 0x0607E7CE,r13
    c.r[0] = 0x1u;  // 0607E65E mov #1,r0
    c.macl = c.r[12] * c.r[1];  // 0607E660 mul.l r1,r12
    c.r[2] = ld32(c.r[11]);  // 0607E662 mov.l @r11,r2
    c.r[4] = c.r[9];  // 0607E664 mov r9,r4
    c.r[3] += c.r[2];  // 0607E666 add r2,r3
    c.r[5] = c.macl;  // 0607E668 sts macl,r5
    c.r[2] += c.r[5];  // 0607E66A add r5,r2
    c.r[1] = c.r[2];  // 0607E66C mov r2,r1
    c.r[1] += 3;  // 0607E66E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E670 mov.b @r1,r1
    c.r[2] += 4;  // 0607E672 add #4,r2
    c.r[7] &= c.r[1];  // 0607E674 and r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E676 mov.b @r2,r1
    c.r[7] += c.r[7];  // 0607E678 add r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607E67A extu.b r1,r1
    c.r[1] >>= 2;  // 0607E67C shlr2 r1
    c.r[1] >>= 2;  // 0607E67E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E680 shlr r1
    c.r[1] >>= 2;  // 0607E682 shlr2 r1
    c.r[7] |= c.r[1];  // 0607E684 or r1,r7
    c.r[2] = c.r[7];  // 0607E686 mov r7,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607E688 shlr r2
    c.r[1] = c.r[3];  // 0607E68A mov r3,r1
    c.r[1] += 3;  // 0607E68C add #3,r1
    c.r[7] &= c.r[0];  // 0607E68E and r0,r7
    c.r[3] += 4;  // 0607E690 add #4,r3
    c.r[7] <<= 2;  // 0607E692 shll2 r7
    c.r[7] <<= 2;  // 0607E694 shll2 r7
    c.r[7] += c.r[7];  // 0607E696 add r7,r7
    c.r[7] <<= 2;  // 0607E698 shll2 r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E69A mov.b @r1,r6
    c.r[0] = 0x78u;  // 0607E69C mov #120,r0
    c.r[6] &= c.r[13];  // 0607E69E and r13,r6
    c.r[6] |= c.r[2];  // 0607E6A0 or r2,r6
    st8(c.r[1], c.r[6]);  // 0607E6A2 mov.b r6,@r1
    c.r[13] = 0x7Fu;  // 0607E6A4 mov #127,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E6A6 mov.b @r3,r1
    c.r[2] = c.r[8];  // 0607E6A8 mov r8,r2
    c.r[1] &= c.r[13];  // 0607E6AA and r13,r1
    c.r[1] |= c.r[7];  // 0607E6AC or r7,r1
    st8(c.r[3], c.r[1]);  // 0607E6AE mov.b r1,@r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7D0u);  // 0607E6B0 mov.w 0x0607E7D0,r13
    c.r[1] = ld32(c.r[11]);  // 0607E6B2 mov.l @r11,r1
    c.r[7] = 0x7u;  // 0607E6B4 mov #7,r7
    c.r[2] += c.r[1];  // 0607E6B6 add r1,r2
    c.r[1] += c.r[5];  // 0607E6B8 add r5,r1
    c.r[1] += 4;  // 0607E6BA add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E6BC mov.b @r1,r1
    c.r[2] += 4;  // 0607E6BE add #4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E6C0 mov.b @r2,r3
    c.r[1] &= c.r[0];  // 0607E6C2 and r0,r1
    c.r[3] &= c.r[13];  // 0607E6C4 and r13,r3
    c.r[3] |= c.r[1];  // 0607E6C6 or r1,r3
    st8(c.r[2], c.r[3]);  // 0607E6C8 mov.b r3,@r2
    c.r[3] = c.r[8];  // 0607E6CA mov r8,r3
    c.r[2] = c.r[5];  // 0607E6CC mov r5,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E7CEu);  // 0607E6CE mov.w 0x0607E7CE,r0
    c.r[1] = ld32(c.r[11]);  // 0607E6D0 mov.l @r11,r1
    c.r[13] = 0x1u;  // 0607E6D2 mov #1,r13
    c.r[3] += c.r[1];  // 0607E6D4 add r1,r3
    c.r[2] += c.r[1];  // 0607E6D6 add r1,r2
    c.r[1] = c.r[2];  // 0607E6D8 mov r2,r1
    c.r[1] += 5;  // 0607E6DA add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E6DC mov.b @r1,r1
    c.r[2] += 6;  // 0607E6DE add #6,r2
    c.r[7] &= c.r[1];  // 0607E6E0 and r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E6E2 mov.b @r2,r1
    c.r[7] += c.r[7];  // 0607E6E4 add r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607E6E6 extu.b r1,r1
    c.r[1] >>= 2;  // 0607E6E8 shlr2 r1
    c.r[1] >>= 2;  // 0607E6EA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E6EC shlr r1
    c.r[1] >>= 2;  // 0607E6EE shlr2 r1
    c.r[7] |= c.r[1];  // 0607E6F0 or r1,r7
    c.r[2] = c.r[7];  // 0607E6F2 mov r7,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607E6F4 shlr r2
    c.r[1] = c.r[3];  // 0607E6F6 mov r3,r1
    c.r[1] += 5;  // 0607E6F8 add #5,r1
    c.r[7] &= c.r[13];  // 0607E6FA and r13,r7
    c.r[3] += 6;  // 0607E6FC add #6,r3
    c.r[7] <<= 2;  // 0607E6FE shll2 r7
    c.r[7] <<= 2;  // 0607E700 shll2 r7
    c.r[7] += c.r[7];  // 0607E702 add r7,r7
    c.r[7] <<= 2;  // 0607E704 shll2 r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E706 mov.b @r1,r6
    c.r[13] = 0x78u;  // 0607E708 mov #120,r13
    c.r[6] &= c.r[0];  // 0607E70A and r0,r6
    c.r[6] |= c.r[2];  // 0607E70C or r2,r6
    st8(c.r[1], c.r[6]);  // 0607E70E mov.b r6,@r1
    c.r[0] = 0x7Fu;  // 0607E710 mov #127,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E712 mov.b @r3,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607E7D2u);  // 0607E714 mov.w 0x0607E7D2,r6
    c.r[1] &= c.r[0];  // 0607E716 and r0,r1
    c.r[1] |= c.r[7];  // 0607E718 or r7,r1
    st8(c.r[3], c.r[1]);  // 0607E71A mov.b r1,@r3
    c.r[7] = c.r[8];  // 0607E71C mov r8,r7
    c.r[1] = ld32(c.r[11]);  // 0607E71E mov.l @r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E7D0u);  // 0607E720 mov.w 0x0607E7D0,r0
    c.r[7] += c.r[1];  // 0607E722 add r1,r7
    c.r[5] += c.r[1];  // 0607E724 add r1,r5
    c.r[1] = c.r[5];  // 0607E726 mov r5,r1
    c.r[1] += 4;  // 0607E728 add #4,r1
    c.r[3] = c.r[7];  // 0607E72A mov r7,r3
    c.r[3] += 4;  // 0607E72C add #4,r3
    c.r[5] += 5;  // 0607E72E add #5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607E730 mov.w @r1,r1
    c.r[7] += 5;  // 0607E732 add #5,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607E734 mov.w @r3,r2
    c.r[6] &= c.r[1];  // 0607E736 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607E7D4u);  // 0607E738 mov.w 0x0607E7D4,r1
    c.r[2] &= c.r[1];  // 0607E73A and r1,r2
    c.r[2] |= c.r[6];  // 0607E73C or r6,r2
    st16(c.r[3], c.r[2]);  // 0607E73E mov.w r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0607E740 mov.b @r5,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607E7CAu);  // 0607E742 mov.w 0x0607E7CA,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607E744 mov.b @r7,r2
    c.r[1] &= c.r[13];  // 0607E746 and r13,r1
    c.r[2] &= c.r[0];  // 0607E748 and r0,r2
    c.r[2] |= c.r[1];  // 0607E74A or r1,r2
    st8(c.r[7], c.r[2]);  // 0607E74C mov.b r2,@r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C8u);  // 0607E74E mov.w 0x0607E7C8,r13
    c.r[13] += c.r[14];  // 0607E750 add r14,r13
    c.r[0] = ld32(0x0607E7DCu);  // 0607E752 mov.l 0x0607E7DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607E758u; c.r[5] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E758u) return; }  // 0607E754 jsr @r0 ; mov.l @r13,r5
    c.r[1] = c.r[9];  // 0607E758 mov r9,r1
    c.r[1] += 26;  // 0607E75A add #26,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C6u);  // 0607E75C mov.w 0x0607E7C6,r13
    c.r[3] = ld32(c.r[11]);  // 0607E75E mov.l @r11,r3
    c.r[13] += c.r[14];  // 0607E760 add r14,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607E762 mov.w @r1,r1
    c.r[3] += c.r[8];  // 0607E764 add r8,r3
    c.r[2] = c.r[3];  // 0607E766 mov r3,r2
    c.r[2] += 22;  // 0607E768 add #22,r2
    st16(c.r[2], c.r[1]);  // 0607E76A mov.w r1,@r2
    c.r[0] = ld32(c.r[13]);  // 0607E76C mov.l @r13,r0
    c.r[3] += 24;  // 0607E76E add #24,r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C2u);  // 0607E770 mov.w 0x0607E7C2,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0607E772 mov.w @r0,r1
    c.r[13] += c.r[14];  // 0607E774 add r14,r13
    st16(c.r[3], c.r[1]);  // 0607E776 mov.w r1,@r3
    c.r[0] = ld32(c.r[13]);  // 0607E778 mov.l @r13,r0
    c.r[0] += 1;  // 0607E77A add #1,r0
    st32(c.r[13], c.r[0]);  // 0607E77C mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607E7C2u);  // 0607E77E mov.w 0x0607E7C2,r13
    c.r[13] += c.r[14];  // 0607E780 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0607E782 mov.l @r13,r13
    c.r[1] = 0x2u;  // 0607E784 mov #2,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0607E786 cmp/gt r1,r13
    if (c.t) { goto L_0607E798; }  // 0607E788 bt 0x0607E798
L_0607E78A:
    c.r[10] += 1;  // 0607E78A add #1,r10
    c.r[1] = 0x7Fu;  // 0607E78C mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0607E78E cmp/gt r1,r10
    { const bool k = c.t; c.r[8] += 30; if (k) { goto L_0607E798; } }  // 0607E790 bt/s 0x0607E798 ; add #30,r8
    SH2_POLL(c); goto L_0607E62A;  // 0607E794 bra 0x0607E62A ; nop
L_0607E798:
    c.r[0] = ld32(0x0607E7E0u);  // 0607E798 mov.l 0x0607E7E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607E79Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E79Eu) return; }  // 0607E79A jsr @r0 ; mov r12,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607E79E tst r0,r0
    if (!c.t) { goto L_0607E7A8; }  // 0607E7A0 bf 0x0607E7A8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E7D6u);  // 0607E7A2 mov.w 0x0607E7D6,r0
    goto L_0607E7AA;  // 0607E7A4 bra 0x0607E7AA ; nop
L_0607E7A8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607E7D8u);  // 0607E7A8 mov.w 0x0607E7D8,r0
L_0607E7AA:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607E7DAu);  // 0607E7AA mov.w 0x0607E7DA,r3
    c.r[14] += c.r[3];  // 0607E7AC add r3,r14
    c.r[15] = c.r[14];  // 0607E7AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607E7B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607E7B2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607E7B4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607E7B6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607E7B8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607E7BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607E7BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607E7BE rts ; mov.l @r15+,r8
}

void f_0607E7E4(SH2Context& c) {
    ran[1759] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607E7E4 mov.l r14,@-r15
    c.r[1] = ld32(0x0607E870u);  // 0607E7E6 mov.l 0x0607E870,r1
    c.r[2] = ld32(c.r[1]);  // 0607E7E8 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607E7EA mov #30,r1
    c.macl = c.r[4] * c.r[1];  // 0607E7EC mul.l r1,r4
    c.r[7] = 0x9u;  // 0607E7EE mov #9,r7
    c.r[3] = c.macl;  // 0607E7F0 sts macl,r3
    c.r[3] += c.r[2];  // 0607E7F2 add r2,r3
    c.r[1] = c.r[3];  // 0607E7F4 mov r3,r1
    c.r[1] += 3;  // 0607E7F6 add #3,r1
    c.r[5] = c.r[3];  // 0607E7F8 mov r3,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E7FA mov.b @r1,r0
    c.r[5] += 4;  // 0607E7FC add #4,r5
    c.r[0] &= 0x7u;  // 0607E7FE and #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0607E800 mov.b @r5,r1
    c.r[0] += c.r[0];  // 0607E802 add r0,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0607E804 extu.b r1,r2
    c.r[1] = c.r[2];  // 0607E806 mov r2,r1
    c.r[1] >>= 2;  // 0607E808 shlr2 r1
    c.r[1] >>= 2;  // 0607E80A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E80C shlr r1
    c.r[1] >>= 2;  // 0607E80E shlr2 r1
    c.r[0] |= c.r[1];  // 0607E810 or r1,r0
    c.t = c.r[0] > c.r[7];  // 0607E812 cmp/hi r7,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607E866; } }  // 0607E814 bf/s 0x0607E866 ; mov r15,r14
    c.r[0] = c.r[2];  // 0607E818 mov r2,r0
    c.r[0] >>= 2;  // 0607E81A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607E81C shlr r0
    c.r[0] &= 0xFu;  // 0607E81E and #15,r0
    c.t = c.r[0] > c.r[7];  // 0607E820 cmp/hi r7,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0607E866; } }  // 0607E822 bf/s 0x0607E866 ; mov r3,r1
    c.r[1] += 5;  // 0607E826 add #5,r1
    c.r[2] = 0x7u;  // 0607E828 mov #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E82A mov.b @r1,r1
    c.r[3] += 6;  // 0607E82C add #6,r3
    c.r[6] = c.r[1] & 0xFFu;  // 0607E82E extu.b r1,r6
    c.r[2] &= c.r[6];  // 0607E830 and r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607E832 mov.b @r3,r1
    c.r[2] += c.r[2];  // 0607E834 add r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607E836 extu.b r1,r1
    c.r[1] >>= 2;  // 0607E838 shlr2 r1
    c.r[1] >>= 2;  // 0607E83A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E83C shlr r1
    c.r[1] >>= 2;  // 0607E83E shlr2 r1
    c.r[2] |= c.r[1];  // 0607E840 or r1,r2
    c.t = c.r[2] > c.r[7];  // 0607E842 cmp/hi r7,r2
    if (!c.t) { goto L_0607E866; }  // 0607E844 bf 0x0607E866
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0607E846 mov.w @r5,r1
    c.r[0] = c.r[1];  // 0607E848 mov r1,r0
    c.r[0] >>= 2;  // 0607E84A shlr2 r0
    c.r[0] >>= 2;  // 0607E84C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607E84E shlr r0
    c.r[0] >>= 2;  // 0607E850 shlr2 r0
    c.r[0] &= 0xFu;  // 0607E852 and #15,r0
    c.t = c.r[0] > c.r[7];  // 0607E854 cmp/hi r7,r0
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { goto L_0607E866; } }  // 0607E856 bf/s 0x0607E866 ; mov r6,r0
    c.r[0] >>= 2;  // 0607E85A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607E85C shlr r0
    c.r[0] &= 0xFu;  // 0607E85E and #15,r0
    c.t = c.r[0] > c.r[7];  // 0607E860 cmp/hi r7,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0607E868; } }  // 0607E862 bt/s 0x0607E868 ; mov #1,r0
L_0607E866:
    c.r[0] = 0x0u;  // 0607E866 mov #0,r0
L_0607E868:
    c.r[15] = c.r[14];  // 0607E868 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607E86A rts ; mov.l @r15+,r14
}

void f_0607E874(SH2Context& c) {
    ran[1760] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607E874 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607E876 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607E878 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607E87A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607E87C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607E87E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607E880 mov r15,r14
    c.r[10] = c.r[4];  // 0607E882 mov r4,r10
    c.r[1] = 0x4u;  // 0607E884 mov #4,r1
    c.t = c.r[5] > c.r[1];  // 0607E886 cmp/hi r1,r5
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0607E890; } }  // 0607E888 bf/s 0x0607E890 ; mov #0,r9
    goto L_0607EB5A;  // 0607E88C bra 0x0607EB5A ; nop
L_0607E890:
    c.r[1] = c.r[5];  // 0607E890 mov r5,r1
    c.r[1] += c.r[1];  // 0607E892 add r1,r1
    c.r[0] = 0x0607E8A0u;  // 0607E894 mova 0x0607E8A0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607E896 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607E898 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607E8AAu: goto L_0607E8AA; case 0x0607E946u: goto L_0607E946; case 0x0607E9C6u: goto L_0607E9C6; case 0x0607EA62u: goto L_0607EA62; case 0x0607EAE4u: goto L_0607EAE4; default: sh2_call(c, x); return; } }  // 0607E89A jmp @r0 ; nop
L_0607E8AA:
    c.r[4] = ld32(0x0607EB6Cu);  // 0607E8AA mov.l 0x0607EB6C,r4
    c.r[8] = ld32(0x0607EB70u);  // 0607E8AC mov.l 0x0607EB70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607E8B2u; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E8B2u) return; }  // 0607E8AE jsr @r8 ; mov #31,r5
    c.r[5] = 0x1u;  // 0607E8B2 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607E8B8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E8B8u) return; }  // 0607E8B4 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[0];  // 0607E8B8 mov r0,r5
    c.r[1] = ld32(0x0607EB74u);  // 0607E8BA mov.l 0x0607EB74,r1
    c.r[3] = 0xFu;  // 0607E8BC mov #15,r3
    c.r[1] = ld32(c.r[1]);  // 0607E8BE mov.l @r1,r1
    c.r[8] = 0x1Eu;  // 0607E8C0 mov #30,r8
    c.r[1] += 3;  // 0607E8C2 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E8C4 mov.b @r1,r0
    c.macl = c.r[10] * c.r[8];  // 0607E8C6 mul.l r8,r10
    c.r[3] &= c.r[0];  // 0607E8C8 and r0,r3
    c.r[1] = ld32(0x0607EB78u);  // 0607E8CA mov.l 0x0607EB78,r1
    c.r[7] = ld32(c.r[1]);  // 0607E8CC mov.l @r1,r7
    c.r[2] = c.macl;  // 0607E8CE sts macl,r2
    c.r[2] += c.r[7];  // 0607E8D0 add r7,r2
    c.r[1] = c.r[2];  // 0607E8D2 mov r2,r1
    c.r[1] += 3;  // 0607E8D4 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E8D6 mov.b @r1,r0
    c.r[2] += 4;  // 0607E8D8 add #4,r2
    c.r[0] &= 0x7u;  // 0607E8DA and #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E8DC mov.b @r2,r1
    c.r[0] += c.r[0];  // 0607E8DE add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607E8E0 extu.b r1,r1
    c.r[1] >>= 2;  // 0607E8E2 shlr2 r1
    c.r[1] >>= 2;  // 0607E8E4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E8E6 shlr r1
    c.r[1] >>= 2;  // 0607E8E8 shlr2 r1
    c.r[0] |= c.r[1];  // 0607E8EA or r1,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 0607E8EC cmp/ge r0,r3
    { const bool k = !c.t; c.r[5] += 60; if (k) { goto L_0607E8F6; } }  // 0607E8EE bf/s 0x0607E8F6 ; add #60,r5
    goto L_0607EB5A;  // 0607E8F2 bra 0x0607EB5A ; nop
L_0607E8F6:
    c.r[4] = c.r[7];  // 0607E8F6 mov r7,r4
    c.r[0] = c.r[3];  // 0607E8F8 mov r3,r0
    c.r[0] += c.r[0];  // 0607E8FA add r0,r0
    c.r[6] = c.r[0];  // 0607E8FC mov r0,r6
    c.r[6] += c.r[5];  // 0607E8FE add r5,r6
    c.r[7] = c.r[0];  // 0607E900 mov r0,r7
L_0607E902:
    c.r[0] = c.r[7];  // 0607E902 mov r7,r0
    c.r[1] = c.r[6];  // 0607E904 mov r6,r1
    c.r[1] += 1;  // 0607E906 add #1,r1
    c.r[6] += 2;  // 0607E908 add #2,r6
    c.r[3] += 1;  // 0607E90A add #1,r3
    c.r[11] = 0x7u;  // 0607E90C mov #7,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607E90E mov.b @(r0,r5),r2
    c.macl = c.r[10] * c.r[8];  // 0607E910 mul.l r8,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E912 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607E914 extu.b r2,r2
    c.r[2] <<= 8;  // 0607E916 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607E918 extu.b r1,r1
    c.r[2] += c.r[1];  // 0607E91A add r1,r2
    c.r[9] += c.r[2];  // 0607E91C add r2,r9
    c.r[2] = c.macl;  // 0607E91E sts macl,r2
    c.r[2] += c.r[4];  // 0607E920 add r4,r2
    c.r[1] = c.r[2];  // 0607E922 mov r2,r1
    c.r[1] += 3;  // 0607E924 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E926 mov.b @r1,r1
    c.r[2] += 4;  // 0607E928 add #4,r2
    c.r[11] &= c.r[1];  // 0607E92A and r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E92C mov.b @r2,r1
    c.r[11] += c.r[11];  // 0607E92E add r11,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0607E930 extu.b r1,r1
    c.r[1] >>= 2;  // 0607E932 shlr2 r1
    c.r[1] >>= 2;  // 0607E934 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E936 shlr r1
    c.r[1] >>= 2;  // 0607E938 shlr2 r1
    c.r[11] |= c.r[1];  // 0607E93A or r1,r11
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 0607E93C cmp/ge r11,r3
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_0607E902; } }  // 0607E93E bf/s 0x0607E902 ; add #2,r7
    c.r[15] = c.r[14]; goto L_0607EB5C;  // 0607E942 bra 0x0607EB5C ; mov r14,r15
L_0607E946:
    c.r[4] = ld32(0x0607EB6Cu);  // 0607E946 mov.l 0x0607EB6C,r4
    c.r[8] = ld32(0x0607EB70u);  // 0607E948 mov.l 0x0607EB70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607E94Eu; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E94Eu) return; }  // 0607E94A jsr @r8 ; mov #31,r5
    c.r[5] = 0x1u;  // 0607E94E mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607E954u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E954u) return; }  // 0607E950 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[0];  // 0607E954 mov r0,r5
    c.r[1] = ld32(0x0607EB74u);  // 0607E956 mov.l 0x0607EB74,r1
    c.r[1] = ld32(c.r[1]);  // 0607E958 mov.l @r1,r1
    c.r[8] = 0x1Eu;  // 0607E95A mov #30,r8
    c.r[1] += 4;  // 0607E95C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E95E mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0607E960 mul.l r8,r10
    c.r[3] = c.r[1] & 0xFFu;  // 0607E962 extu.b r1,r3
    c.r[1] = ld32(0x0607EB78u);  // 0607E964 mov.l 0x0607EB78,r1
    c.r[2] = ld32(c.r[1]);  // 0607E966 mov.l @r1,r2
    c.r[1] = c.macl;  // 0607E968 sts macl,r1
    c.r[1] += c.r[2];  // 0607E96A add r2,r1
    c.r[1] += 4;  // 0607E96C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E96E mov.b @r1,r1
    c.r[3] >>= 2;  // 0607E970 shlr2 r3
    c.r[3] >>= 2;  // 0607E972 shlr2 r3
    c.r[0] = c.r[1];  // 0607E974 mov r1,r0
    c.r[0] >>= 2;  // 0607E976 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607E978 shlr r0
    c.r[0] &= 0xFu;  // 0607E97A and #15,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 0607E97C cmp/ge r0,r3
    { const bool k = !c.t; c.r[5] += 40; if (k) { goto L_0607E986; } }  // 0607E97E bf/s 0x0607E986 ; add #40,r5
    goto L_0607EB5A;  // 0607E982 bra 0x0607EB5A ; nop
L_0607E986:
    c.r[4] = c.r[2];  // 0607E986 mov r2,r4
    c.r[0] = c.r[3];  // 0607E988 mov r3,r0
    c.r[0] += c.r[0];  // 0607E98A add r0,r0
    c.r[6] = c.r[0];  // 0607E98C mov r0,r6
    c.r[6] += c.r[5];  // 0607E98E add r5,r6
    c.r[7] = c.r[0];  // 0607E990 mov r0,r7
L_0607E992:
    c.r[0] = c.r[7];  // 0607E992 mov r7,r0
    c.r[1] = c.r[6];  // 0607E994 mov r6,r1
    c.r[1] += 1;  // 0607E996 add #1,r1
    c.r[6] += 2;  // 0607E998 add #2,r6
    c.r[7] += 2;  // 0607E99A add #2,r7
    c.r[3] += 1;  // 0607E99C add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607E99E mov.b @(r0,r5),r2
    c.macl = c.r[10] * c.r[8];  // 0607E9A0 mul.l r8,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E9A2 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607E9A4 extu.b r2,r2
    c.r[2] <<= 8;  // 0607E9A6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607E9A8 extu.b r1,r1
    c.r[2] += c.r[1];  // 0607E9AA add r1,r2
    c.r[1] = c.macl;  // 0607E9AC sts macl,r1
    c.r[1] += c.r[4];  // 0607E9AE add r4,r1
    c.r[1] += 4;  // 0607E9B0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E9B2 mov.b @r1,r1
    c.r[0] = 0xFu;  // 0607E9B4 mov #15,r0
    c.r[1] >>= 2;  // 0607E9B6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607E9B8 shlr r1
    c.r[1] &= c.r[0];  // 0607E9BA and r0,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0607E9BC cmp/ge r1,r3
    { const bool k = !c.t; c.r[9] += c.r[2]; if (k) { SH2_POLL(c); goto L_0607E992; } }  // 0607E9BE bf/s 0x0607E992 ; add r2,r9
    c.r[15] = c.r[14]; goto L_0607EB5C;  // 0607E9C2 bra 0x0607EB5C ; mov r14,r15
L_0607E9C6:
    c.r[4] = ld32(0x0607EB6Cu);  // 0607E9C6 mov.l 0x0607EB6C,r4
    c.r[8] = ld32(0x0607EB70u);  // 0607E9C8 mov.l 0x0607EB70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607E9CEu; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E9CEu) return; }  // 0607E9CA jsr @r8 ; mov #31,r5
    c.r[5] = 0x1u;  // 0607E9CE mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607E9D4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607E9D4u) return; }  // 0607E9D0 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[0];  // 0607E9D4 mov r0,r5
    c.r[1] = ld32(0x0607EB74u);  // 0607E9D6 mov.l 0x0607EB74,r1
    c.r[3] = 0xFu;  // 0607E9D8 mov #15,r3
    c.r[1] = ld32(c.r[1]);  // 0607E9DA mov.l @r1,r1
    c.r[8] = 0x1Eu;  // 0607E9DC mov #30,r8
    c.r[1] += 5;  // 0607E9DE add #5,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E9E0 mov.b @r1,r0
    c.macl = c.r[10] * c.r[8];  // 0607E9E2 mul.l r8,r10
    c.r[3] &= c.r[0];  // 0607E9E4 and r0,r3
    c.r[1] = ld32(0x0607EB78u);  // 0607E9E6 mov.l 0x0607EB78,r1
    c.r[7] = ld32(c.r[1]);  // 0607E9E8 mov.l @r1,r7
    c.r[2] = c.macl;  // 0607E9EA sts macl,r2
    c.r[2] += c.r[7];  // 0607E9EC add r7,r2
    c.r[1] = c.r[2];  // 0607E9EE mov r2,r1
    c.r[1] += 5;  // 0607E9F0 add #5,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607E9F2 mov.b @r1,r0
    c.r[2] += 6;  // 0607E9F4 add #6,r2
    c.r[0] &= 0x7u;  // 0607E9F6 and #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607E9F8 mov.b @r2,r1
    c.r[0] += c.r[0];  // 0607E9FA add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607E9FC extu.b r1,r1
    c.r[1] >>= 2;  // 0607E9FE shlr2 r1
    c.r[1] >>= 2;  // 0607EA00 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607EA02 shlr r1
    c.r[1] >>= 2;  // 0607EA04 shlr2 r1
    c.r[0] |= c.r[1];  // 0607EA06 or r1,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 0607EA08 cmp/ge r0,r3
    { const bool k = !c.t; c.r[5] += 80; if (k) { goto L_0607EA12; } }  // 0607EA0A bf/s 0x0607EA12 ; add #80,r5
    goto L_0607EB5A;  // 0607EA0E bra 0x0607EB5A ; nop
L_0607EA12:
    c.r[4] = c.r[7];  // 0607EA12 mov r7,r4
    c.r[0] = c.r[3];  // 0607EA14 mov r3,r0
    c.r[0] += c.r[0];  // 0607EA16 add r0,r0
    c.r[6] = c.r[0];  // 0607EA18 mov r0,r6
    c.r[6] += c.r[5];  // 0607EA1A add r5,r6
    c.r[7] = c.r[0];  // 0607EA1C mov r0,r7
L_0607EA1E:
    c.r[0] = c.r[7];  // 0607EA1E mov r7,r0
    c.r[1] = c.r[6];  // 0607EA20 mov r6,r1
    c.r[1] += 1;  // 0607EA22 add #1,r1
    c.r[6] += 2;  // 0607EA24 add #2,r6
    c.r[3] += 1;  // 0607EA26 add #1,r3
    c.r[11] = 0x7u;  // 0607EA28 mov #7,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607EA2A mov.b @(r0,r5),r2
    c.macl = c.r[10] * c.r[8];  // 0607EA2C mul.l r8,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EA2E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607EA30 extu.b r2,r2
    c.r[2] <<= 8;  // 0607EA32 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607EA34 extu.b r1,r1
    c.r[2] += c.r[1];  // 0607EA36 add r1,r2
    c.r[9] += c.r[2];  // 0607EA38 add r2,r9
    c.r[2] = c.macl;  // 0607EA3A sts macl,r2
    c.r[2] += c.r[4];  // 0607EA3C add r4,r2
    c.r[1] = c.r[2];  // 0607EA3E mov r2,r1
    c.r[1] += 5;  // 0607EA40 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EA42 mov.b @r1,r1
    c.r[2] += 6;  // 0607EA44 add #6,r2
    c.r[11] &= c.r[1];  // 0607EA46 and r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EA48 mov.b @r2,r1
    c.r[11] += c.r[11];  // 0607EA4A add r11,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0607EA4C extu.b r1,r1
    c.r[1] >>= 2;  // 0607EA4E shlr2 r1
    c.r[1] >>= 2;  // 0607EA50 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607EA52 shlr r1
    c.r[1] >>= 2;  // 0607EA54 shlr2 r1
    c.r[11] |= c.r[1];  // 0607EA56 or r1,r11
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 0607EA58 cmp/ge r11,r3
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_0607EA1E; } }  // 0607EA5A bf/s 0x0607EA1E ; add #2,r7
    c.r[15] = c.r[14]; goto L_0607EB5C;  // 0607EA5E bra 0x0607EB5C ; mov r14,r15
L_0607EA62:
    c.r[4] = ld32(0x0607EB6Cu);  // 0607EA62 mov.l 0x0607EB6C,r4
    c.r[8] = ld32(0x0607EB70u);  // 0607EA64 mov.l 0x0607EB70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607EA6Au; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EA6Au) return; }  // 0607EA66 jsr @r8 ; mov #31,r5
    c.r[5] = 0x1u;  // 0607EA6A mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607EA70u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EA70u) return; }  // 0607EA6C jsr @r8 ; mov r0,r4
    c.r[5] = c.r[0];  // 0607EA70 mov r0,r5
    c.r[1] = ld32(0x0607EB74u);  // 0607EA72 mov.l 0x0607EB74,r1
    c.r[1] = ld32(c.r[1]);  // 0607EA74 mov.l @r1,r1
    c.r[8] = 0x1Eu;  // 0607EA76 mov #30,r8
    c.r[1] += 4;  // 0607EA78 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EA7A mov.b @r1,r0
    c.macl = c.r[10] * c.r[8];  // 0607EA7C mul.l r8,r10
    c.r[1] = ld32(0x0607EB78u);  // 0607EA7E mov.l 0x0607EB78,r1
    c.r[2] = ld32(c.r[1]);  // 0607EA80 mov.l @r1,r2
    c.r[3] = 0xFu;  // 0607EA82 mov #15,r3
    c.r[1] = c.macl;  // 0607EA84 sts macl,r1
    c.r[1] += c.r[2];  // 0607EA86 add r2,r1
    c.r[1] += 4;  // 0607EA88 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607EA8A mov.w @r1,r1
    c.r[3] &= c.r[0];  // 0607EA8C and r0,r3
    c.r[0] = c.r[1];  // 0607EA8E mov r1,r0
    c.r[0] >>= 2;  // 0607EA90 shlr2 r0
    c.r[0] >>= 2;  // 0607EA92 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607EA94 shlr r0
    c.r[0] >>= 2;  // 0607EA96 shlr2 r0
    c.r[0] &= 0xFu;  // 0607EA98 and #15,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 0607EA9A cmp/ge r0,r3
    { const bool k = c.t; c.r[5] += 20; if (k) { goto L_0607EB5A; } }  // 0607EA9C bt/s 0x0607EB5A ; add #20,r5
    c.r[4] = c.r[2];  // 0607EAA0 mov r2,r4
    c.r[0] = c.r[3];  // 0607EAA2 mov r3,r0
    c.r[0] += c.r[0];  // 0607EAA4 add r0,r0
    c.r[6] = c.r[0];  // 0607EAA6 mov r0,r6
    c.r[6] += c.r[5];  // 0607EAA8 add r5,r6
    c.r[7] = c.r[0];  // 0607EAAA mov r0,r7
L_0607EAAC:
    c.r[0] = c.r[7];  // 0607EAAC mov r7,r0
    c.r[1] = c.r[6];  // 0607EAAE mov r6,r1
    c.r[1] += 1;  // 0607EAB0 add #1,r1
    c.r[6] += 2;  // 0607EAB2 add #2,r6
    c.r[7] += 2;  // 0607EAB4 add #2,r7
    c.r[3] += 1;  // 0607EAB6 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607EAB8 mov.b @(r0,r5),r2
    c.macl = c.r[10] * c.r[8];  // 0607EABA mul.l r8,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EABC mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607EABE extu.b r2,r2
    c.r[2] <<= 8;  // 0607EAC0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607EAC2 extu.b r1,r1
    c.r[2] += c.r[1];  // 0607EAC4 add r1,r2
    c.r[1] = c.macl;  // 0607EAC6 sts macl,r1
    c.r[1] += c.r[4];  // 0607EAC8 add r4,r1
    c.r[1] += 4;  // 0607EACA add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607EACC mov.w @r1,r1
    c.r[0] = 0xFu;  // 0607EACE mov #15,r0
    c.r[1] >>= 2;  // 0607EAD0 shlr2 r1
    c.r[1] >>= 2;  // 0607EAD2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607EAD4 shlr r1
    c.r[1] >>= 2;  // 0607EAD6 shlr2 r1
    c.r[1] &= c.r[0];  // 0607EAD8 and r0,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0607EADA cmp/ge r1,r3
    { const bool k = !c.t; c.r[9] += c.r[2]; if (k) { SH2_POLL(c); goto L_0607EAAC; } }  // 0607EADC bf/s 0x0607EAAC ; add r2,r9
    c.r[15] = c.r[14]; goto L_0607EB5C;  // 0607EAE0 bra 0x0607EB5C ; mov r14,r15
L_0607EAE4:
    c.r[4] = ld32(0x0607EB6Cu);  // 0607EAE4 mov.l 0x0607EB6C,r4
    c.r[8] = ld32(0x0607EB70u);  // 0607EAE6 mov.l 0x0607EB70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607EAECu; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EAECu) return; }  // 0607EAE8 jsr @r8 ; mov #31,r5
    c.r[5] = 0x1u;  // 0607EAEC mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607EAF2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EAF2u) return; }  // 0607EAEE jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0607EB74u);  // 0607EAF2 mov.l 0x0607EB74,r1
    c.r[1] = ld32(c.r[1]);  // 0607EAF4 mov.l @r1,r1
    c.r[8] = 0x1Eu;  // 0607EAF6 mov #30,r8
    c.r[1] += 5;  // 0607EAF8 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EAFA mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0607EAFC mul.l r8,r10
    c.r[3] = c.r[1] & 0xFFu;  // 0607EAFE extu.b r1,r3
    c.r[1] = ld32(0x0607EB78u);  // 0607EB00 mov.l 0x0607EB78,r1
    c.r[2] = ld32(c.r[1]);  // 0607EB02 mov.l @r1,r2
    c.r[5] = c.r[0];  // 0607EB04 mov r0,r5
    c.r[1] = c.macl;  // 0607EB06 sts macl,r1
    c.r[1] += c.r[2];  // 0607EB08 add r2,r1
    c.r[1] += 5;  // 0607EB0A add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB0C mov.b @r1,r1
    c.r[3] >>= 2;  // 0607EB0E shlr2 r3
    c.r[3] >>= 2;  // 0607EB10 shlr2 r3
    c.r[0] = c.r[1];  // 0607EB12 mov r1,r0
    c.r[0] >>= 2;  // 0607EB14 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607EB16 shlr r0
    c.r[0] &= 0xFu;  // 0607EB18 and #15,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 0607EB1A cmp/ge r0,r3
    { const bool k = c.t; c.r[4] = c.r[2]; if (k) { goto L_0607EB5A; } }  // 0607EB1C bt/s 0x0607EB5A ; mov r2,r4
    c.r[0] = c.r[3];  // 0607EB20 mov r3,r0
    c.r[0] += c.r[0];  // 0607EB22 add r0,r0
    c.r[6] = c.r[0];  // 0607EB24 mov r0,r6
    c.r[6] += c.r[5];  // 0607EB26 add r5,r6
    c.r[7] = c.r[0];  // 0607EB28 mov r0,r7
L_0607EB2A:
    c.r[0] = c.r[7];  // 0607EB2A mov r7,r0
    c.r[1] = c.r[6];  // 0607EB2C mov r6,r1
    c.r[1] += 1;  // 0607EB2E add #1,r1
    c.r[6] += 2;  // 0607EB30 add #2,r6
    c.r[7] += 2;  // 0607EB32 add #2,r7
    c.r[3] += 1;  // 0607EB34 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607EB36 mov.b @(r0,r5),r2
    c.macl = c.r[10] * c.r[8];  // 0607EB38 mul.l r8,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB3A mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607EB3C extu.b r2,r2
    c.r[2] <<= 8;  // 0607EB3E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607EB40 extu.b r1,r1
    c.r[2] += c.r[1];  // 0607EB42 add r1,r2
    c.r[1] = c.macl;  // 0607EB44 sts macl,r1
    c.r[1] += c.r[4];  // 0607EB46 add r4,r1
    c.r[1] += 5;  // 0607EB48 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB4A mov.b @r1,r1
    c.r[0] = 0xFu;  // 0607EB4C mov #15,r0
    c.r[1] >>= 2;  // 0607EB4E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607EB50 shlr r1
    c.r[1] &= c.r[0];  // 0607EB52 and r0,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0607EB54 cmp/ge r1,r3
    { const bool k = !c.t; c.r[9] += c.r[2]; if (k) { SH2_POLL(c); goto L_0607EB2A; } }  // 0607EB56 bf/s 0x0607EB2A ; add r2,r9
L_0607EB5A:
    c.r[15] = c.r[14];  // 0607EB5A mov r14,r15
L_0607EB5C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EB5C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607EB5E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EB60 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607EB62 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0607EB64 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607EB66 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EB68 rts ; mov.l @r15+,r8
}

void f_0607EB7C(SH2Context& c) {
    ran[1761] = 1;
    goto L_0607EB7C;
L_0601B124:
    c.r[3] = ld32(0x0601B240u);  // 0601B124 mov.l 0x0601B240,r3
L_0601B126:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601B126 mov.w @r3,r2
L_0601B128:
    c.r[7] = ld32(0x0601B244u);  // 0601B128 mov.l 0x0601B244,r7
L_0601B12A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601B12A mov.w @r7,r1
L_0601B12C:
    c.r[2] |= c.r[1];  // 0601B12C or r1,r2
L_0601B12E:
    st16(c.r[3], c.r[2]);  // 0601B12E mov.w r2,@r3
L_0601B130:
    c.r[1] = 0x0u;  // 0601B130 mov #0,r1
L_0601B132:
    st16(c.r[7], c.r[1]);  // 0601B132 mov.w r1,@r7
L_0601B134:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B232u);  // 0601B134 mov.w 0x0601B232,r1
L_0601B136:
    c.r[1] &= c.r[2];  // 0601B136 and r2,r1
L_0601B138:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B138 tst r1,r1
L_0601B13A:
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B144; } }  // 0601B13A bt/s 0x0601B144 ; mov r15,r14
L_0601B13E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B234u);  // 0601B13E mov.w 0x0601B234,r0
L_0601B140:
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B140 bra 0x0601B6D2 ; mov r14,r15
L_0601B144:
    c.r[0] = c.r[2];  // 0601B144 mov r2,r0
L_0601B146:
    c.r[0] >>= 8;  // 0601B146 shlr8 r0
L_0601B148:
    c.r[0] &= 0x1u;  // 0601B148 and #1,r0
L_0601B14A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B14A tst r0,r0
L_0601B14C:
    if (c.t) { goto L_0601B156; }  // 0601B14C bt 0x0601B156
L_0601B14E:
    c.r[15] = c.r[14];  // 0601B14E mov r14,r15
L_0601B150:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B236u);  // 0601B150 mov.w 0x0601B236,r0
L_0601B152:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601B6D4;  // 0601B152 bra 0x0601B6D4 ; lds.l @r15+,pr
L_0601B156:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B238u);  // 0601B156 mov.w 0x0601B238,r1
L_0601B158:
    c.r[2] &= c.r[1];  // 0601B158 and r1,r2
L_0601B15A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B15A tst r2,r2
L_0601B15C:
    if (c.t) { goto L_0601B162; }  // 0601B15C bt 0x0601B162
L_0601B15E:
    goto L_0601B46A;  // 0601B15E bra 0x0601B46A ; nop
L_0601B162:
    c.r[1] = ld32(0x0601B248u);  // 0601B162 mov.l 0x0601B248,r1
L_0601B164:
    c.r[9] = ld32(c.r[1]);  // 0601B164 mov.l @r1,r9
L_0601B166:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B166 mov.b @r9,r0
L_0601B168:
    c.r[0] &= 0xC0u;  // 0601B168 and #192,r0
L_0601B16A:
    c.r[0] >>= 2;  // 0601B16A shlr2 r0
L_0601B16C:
    c.r[0] >>= 2;  // 0601B16C shlr2 r0
L_0601B16E:
    c.r[0] >>= 2;  // 0601B16E shlr2 r0
L_0601B170:
    c.t = c.r[0] == 0x1u;  // 0601B170 cmp/eq #1,r0
L_0601B172:
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601B18C; } }  // 0601B172 bt/s 0x0601B18C ; tst r9,r9
L_0601B176:
    c.r[1] = ld32(0x0601B24Cu);  // 0601B176 mov.l 0x0601B24C,r1
L_0601B178:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B178 mov.b @r1,r1
L_0601B17A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B17A extu.b r1,r0
L_0601B17C:
    c.r[1] = ld32(0x0601B250u);  // 0601B17C mov.l 0x0601B250,r1
L_0601B17E:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B17E mov.b @(r0,r1),r5
L_0601B180:
    c.r[4] = c.r[9];  // 0601B180 mov r9,r4
L_0601B182:
    c.r[0] = ld32(0x0601B254u);  // 0601B182 mov.l 0x0601B254,r0
L_0601B184:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B188u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B188u) return; }  // 0601B184 jsr @r0 ; extu.b r5,r5
L_0601B188:
    c.r[9] = c.r[0];  // 0601B188 mov r0,r9
L_0601B18A:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601B18A tst r9,r9
L_0601B18C:
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0601B194; } }  // 0601B18C bf/s 0x0601B194 ; mov #0,r4
L_0601B190:
    goto L_0601B6C8;  // 0601B190 bra 0x0601B6C8 ; nop
L_0601B194:
    c.r[1] = ld32(0x0601B258u);  // 0601B194 mov.l 0x0601B258,r1
L_0601B196:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B196 mov.b @r1,r0
L_0601B198:
    c.r[7] = 0x3u;  // 0601B198 mov #3,r7
L_0601B19A:
    c.r[3] = 0x0u;  // 0601B19A mov #0,r3
L_0601B19C:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B19C mov.l 0x0601B25C,r2
L_0601B19E:
    c.r[0] &= 0xFEu;  // 0601B19E and #254,r0
L_0601B1A0:
    st8(c.r[1], c.r[0]);  // 0601B1A0 mov.b r0,@r1
L_0601B1A2:
    c.r[1] = c.r[2];  // 0601B1A2 mov r2,r1
L_0601B1A4:
    c.r[1] += 2;  // 0601B1A4 add #2,r1
L_0601B1A6:
    st8(c.r[1], c.r[3]);  // 0601B1A6 mov.b r3,@r1
L_0601B1A8:
    c.r[4] += 1;  // 0601B1A8 add #1,r4
L_0601B1AA:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 0601B1AA cmp/gt r7,r4
L_0601B1AC:
    { const bool k = !c.t; c.r[2] += 3; if (k) { SH2_POLL(c); goto L_0601B1A2; } }  // 0601B1AC bf/s 0x0601B1A2 ; add #3,r2
L_0601B1B0:
    c.r[7] = c.r[9];  // 0601B1B0 mov r9,r7
L_0601B1B2:
    c.r[7] += 2;  // 0601B1B2 add #2,r7
L_0601B1B4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1B4 mov.b @r7,r1
L_0601B1B6:
    c.r[0] = c.r[1];  // 0601B1B6 mov r1,r0
L_0601B1B8:
    c.r[0] >>= 2;  // 0601B1B8 shlr2 r0
L_0601B1BA:
    c.r[0] >>= 2;  // 0601B1BA shlr2 r0
L_0601B1BC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B1BC shlr r0
L_0601B1BE:
    c.r[0] >>= 2;  // 0601B1BE shlr2 r0
L_0601B1C0:
    c.r[0] &= 0x1u;  // 0601B1C0 and #1,r0
L_0601B1C2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1C2 tst r0,r0
L_0601B1C4:
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0601B1E2; } }  // 0601B1C4 bt/s 0x0601B1E2 ; mov r1,r0
L_0601B1C8:
    c.r[1] = ld32(0x0601B258u);  // 0601B1C8 mov.l 0x0601B258,r1
L_0601B1CA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1CA mov.b @r1,r0
L_0601B1CC:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1CC mov.l 0x0601B25C,r2
L_0601B1CE:
    c.r[3] = c.r[2];  // 0601B1CE mov r2,r3
L_0601B1D0:
    c.r[3] += 8;  // 0601B1D0 add #8,r3
L_0601B1D2:
    c.r[2] += 11;  // 0601B1D2 add #11,r2
L_0601B1D4:
    c.r[0] |= 0x1u;  // 0601B1D4 or #1,r0
L_0601B1D6:
    st8(c.r[1], c.r[0]);  // 0601B1D6 mov.b r0,@r1
L_0601B1D8:
    c.r[1] = 0x1u;  // 0601B1D8 mov #1,r1
L_0601B1DA:
    st8(c.r[2], c.r[1]);  // 0601B1DA mov.b r1,@r2
L_0601B1DC:
    st8(c.r[3], c.r[1]);  // 0601B1DC mov.b r1,@r3
L_0601B1DE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1DE mov.b @r7,r1
L_0601B1E0:
    c.r[0] = c.r[1];  // 0601B1E0 mov r1,r0
L_0601B1E2:
    c.r[0] >>= 2;  // 0601B1E2 shlr2 r0
L_0601B1E4:
    c.r[0] >>= 2;  // 0601B1E4 shlr2 r0
L_0601B1E6:
    c.r[0] >>= 2;  // 0601B1E6 shlr2 r0
L_0601B1E8:
    c.r[0] &= 0x1u;  // 0601B1E8 and #1,r0
L_0601B1EA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1EA tst r0,r0
L_0601B1EC:
    if (c.t) { goto L_0601B204; }  // 0601B1EC bt 0x0601B204
L_0601B1EE:
    c.r[1] = ld32(0x0601B258u);  // 0601B1EE mov.l 0x0601B258,r1
L_0601B1F0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1F0 mov.b @r1,r0
L_0601B1F2:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1F2 mov.l 0x0601B25C,r2
L_0601B1F4:
    c.r[3] = c.r[2];  // 0601B1F4 mov r2,r3
L_0601B1F6:
    c.r[3] += 2;  // 0601B1F6 add #2,r3
L_0601B1F8:
    c.r[2] += 5;  // 0601B1F8 add #5,r2
L_0601B1FA:
    c.r[0] |= 0x1u;  // 0601B1FA or #1,r0
L_0601B1FC:
    st8(c.r[1], c.r[0]);  // 0601B1FC mov.b r0,@r1
L_0601B1FE:
    c.r[1] = 0x1u;  // 0601B1FE mov #1,r1
L_0601B200:
    st8(c.r[2], c.r[1]);  // 0601B200 mov.b r1,@r2
L_0601B202:
    st8(c.r[3], c.r[1]);  // 0601B202 mov.b r1,@r3
L_0601B204:
    c.r[1] = ld32(0x0601B240u);  // 0601B204 mov.l 0x0601B240,r1
L_0601B206:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B206 mov.w @r1,r1
L_0601B208:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B23Au);  // 0601B208 mov.w 0x0601B23A,r2
L_0601B20A:
    c.r[2] &= c.r[1];  // 0601B20A and r1,r2
L_0601B20C:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B20C tst r2,r2
L_0601B20E:
    if (!c.t) { goto L_0601B214; }  // 0601B20E bf 0x0601B214
L_0601B210:
    goto L_0601B36E;  // 0601B210 bra 0x0601B36E ; nop
L_0601B214:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B214 mov.b @r9,r1
L_0601B216:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B23Cu);  // 0601B216 mov.w 0x0601B23C,r0
L_0601B218:
    c.r[1] &= c.r[0];  // 0601B218 and r0,r1
L_0601B21A:
    c.r[1] >>= 2;  // 0601B21A shlr2 r1
L_0601B21C:
    c.r[1] >>= 2;  // 0601B21C shlr2 r1
L_0601B21E:
    c.r[1] >>= 2;  // 0601B21E shlr2 r1
L_0601B220:
    c.r[0] = c.r[1];  // 0601B220 mov r1,r0
L_0601B222:
    c.t = c.r[0] == 0x1u;  // 0601B222 cmp/eq #1,r0
L_0601B224:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B260; } }  // 0601B224 bt/s 0x0601B260 ; mov r9,r1
L_0601B228:
    c.t = c.r[0] == 0x2u;  // 0601B228 cmp/eq #2,r0
L_0601B22A:
    { const bool k = c.t; c.r[1] += 4; if (k) { goto L_0601B312; } }  // 0601B22A bt/s 0x0601B312 ; add #4,r1
L_0601B22E:
    goto L_0601B32C;  // 0601B22E bra 0x0601B32C ; nop
L_0601B260:
    c.r[1] += 5;  // 0601B260 add #5,r1
L_0601B262:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B262 mov.b @r1,r1
L_0601B264:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B264 extu.b r1,r10
L_0601B266:
    c.r[1] = c.r[9];  // 0601B266 mov r9,r1
L_0601B268:
    c.r[1] += 4;  // 0601B268 add #4,r1
L_0601B26A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B26A mov.b @r1,r1
L_0601B26C:
    c.r[13] = ld32(0x0601B438u);  // 0601B26C mov.l 0x0601B438,r13
L_0601B26E:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B26E extu.b r1,r8
L_0601B270:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B270 mov.l 0x0601B43C,r1
L_0601B272:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B272 mov.b @r1,r1
L_0601B274:
    c.r[7] = ld32(0x0601B440u);  // 0601B274 mov.l 0x0601B440,r7
L_0601B276:
    c.r[12] = c.r[1] & 0xFFu;  // 0601B276 extu.b r1,r12
L_0601B278:
    c.r[0] = c.r[12];  // 0601B278 mov r12,r0
L_0601B27A:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0601B27A mov.b @(r0,r13),r11
L_0601B27C:
    c.r[5] = c.r[8];  // 0601B27C mov r8,r5
L_0601B27E:
    c.r[6] = c.r[11] & 0xFFu;  // 0601B27E extu.b r11,r6
L_0601B280:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B284u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B284u) return; }  // 0601B280 jsr @r7 ; mov r6,r4
L_0601B284:
    c.r[7] = c.r[0];  // 0601B284 mov r0,r7
L_0601B286:
    c.macl = c.r[7] * c.r[8];  // 0601B286 mul.l r8,r7
L_0601B288:
    c.r[0] = c.r[6];  // 0601B288 mov r6,r0
L_0601B28A:
    c.r[1] = c.macl;  // 0601B28A sts macl,r1
L_0601B28C:
    c.r[0] -= c.r[1];  // 0601B28C sub r1,r0
L_0601B28E:
    c.r[1] = c.r[0];  // 0601B28E mov r0,r1
L_0601B290:
    c.t = (int32_t)c.r[1] > 0;  // 0601B290 cmp/pl r1
L_0601B292:
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0601B29E; } }  // 0601B292 bf/s 0x0601B29E ; mov r11,r1
L_0601B296:
    c.r[1] -= 1;  // 0601B296 add #-1,r1
L_0601B298:
    c.r[0] = c.r[12];  // 0601B298 mov r12,r0
L_0601B29A:
    st8(c.r[0] + c.r[13], c.r[1]); goto L_0601B358;  // 0601B29A bra 0x0601B358 ; mov.b r1,@(r0,r13)
L_0601B29E:
    c.r[1] = c.r[9];  // 0601B29E mov r9,r1
L_0601B2A0:
    c.r[1] += 1;  // 0601B2A0 add #1,r1
L_0601B2A2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2A2 mov.b @r1,r1
L_0601B2A4:
    c.r[0] = c.r[1];  // 0601B2A4 mov r1,r0
L_0601B2A6:
    c.r[0] >>= 2;  // 0601B2A6 shlr2 r0
L_0601B2A8:
    c.r[0] >>= 2;  // 0601B2A8 shlr2 r0
L_0601B2AA:
    c.r[0] >>= 2;  // 0601B2AA shlr2 r0
L_0601B2AC:
    c.r[0] &= 0x1u;  // 0601B2AC and #1,r0
L_0601B2AE:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B2AE tst r0,r0
L_0601B2B0:
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B2B8; } }  // 0601B2B0 bf/s 0x0601B2B8 ; mov r6,r4
L_0601B2B4:
    goto L_0601B46A;  // 0601B2B4 bra 0x0601B46A ; nop
L_0601B2B8:
    c.r[1] = c.r[9];  // 0601B2B8 mov r9,r1
L_0601B2BA:
    c.r[1] += 8;  // 0601B2BA add #8,r1
L_0601B2BC:
    c.r[3] = c.r[12];  // 0601B2BC mov r12,r3
L_0601B2BE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2BE mov.b @r1,r1
L_0601B2C0:
    c.r[0] = c.r[3];  // 0601B2C0 mov r3,r0
L_0601B2C2:
    c.r[2] = c.r[1] & 0xFFu;  // 0601B2C2 extu.b r1,r2
L_0601B2C4:
    c.r[1] = c.r[9];  // 0601B2C4 mov r9,r1
L_0601B2C6:
    c.r[1] += 9;  // 0601B2C6 add #9,r1
L_0601B2C8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2C8 mov.b @r1,r1
L_0601B2CA:
    c.r[2] <<= 8;  // 0601B2CA shll8 r2
L_0601B2CC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2CC extu.b r1,r1
L_0601B2CE:
    c.r[2] |= c.r[1];  // 0601B2CE or r1,r2
L_0601B2D0:
    c.r[1] = ld32(0x0601B444u);  // 0601B2D0 mov.l 0x0601B444,r1
L_0601B2D2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2D2 mov.b @(r0,r1),r1
L_0601B2D4:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2D4 extu.b r1,r1
L_0601B2D6:
    c.r[1] -= 1;  // 0601B2D6 add #-1,r1
L_0601B2D8:
    c.macl = c.r[1] * c.r[10];  // 0601B2D8 mul.l r10,r1
L_0601B2DA:
    c.r[4] += c.r[8]; goto L_0601B2F2;  // 0601B2DA bra 0x0601B2F2 ; add r8,r4
L_0601B2DE:
    c.r[1] = ld32(0x0601B438u);  // 0601B2DE mov.l 0x0601B438,r1
L_0601B2E0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2E0 mov.b @(r0,r1),r1
L_0601B2E2:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2E2 extu.b r1,r1
L_0601B2E4:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B2E4 cmp/gt r1,r4
L_0601B2E6:
    if (!c.t) { goto L_0601B306; }  // 0601B2E6 bf 0x0601B306
L_0601B2E8:
    c.r[1] = ld32(0x0601B444u);  // 0601B2E8 mov.l 0x0601B444,r1
L_0601B2EA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2EA mov.b @(r0,r1),r1
L_0601B2EC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2EC extu.b r1,r1
L_0601B2EE:
    c.r[1] -= 1;  // 0601B2EE add #-1,r1
L_0601B2F0:
    c.macl = c.r[1] * c.r[10];  // 0601B2F0 mul.l r10,r1
L_0601B2F2:
    c.r[1] = c.macl;  // 0601B2F2 sts macl,r1
L_0601B2F4:
    c.macl = c.r[1] * c.r[8];  // 0601B2F4 mul.l r8,r1
L_0601B2F6:
    c.r[4] -= 1;  // 0601B2F6 add #-1,r4
L_0601B2F8:
    c.r[0] = c.r[2];  // 0601B2F8 mov r2,r0
L_0601B2FA:
    c.r[1] = c.macl;  // 0601B2FA sts macl,r1
L_0601B2FC:
    c.r[0] -= c.r[1];  // 0601B2FC sub r1,r0
L_0601B2FE:
    c.r[1] = c.r[0];  // 0601B2FE mov r0,r1
L_0601B300:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B300 cmp/gt r4,r1
L_0601B302:
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0601B2DE; } }  // 0601B302 bf/s 0x0601B2DE ; mov r3,r0
L_0601B306:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B306 mov.l 0x0601B43C,r1
L_0601B308:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B308 mov.b @r1,r1
L_0601B30A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B30A extu.b r1,r0
L_0601B30C:
    c.r[1] = ld32(0x0601B438u);  // 0601B30C mov.l 0x0601B438,r1
L_0601B30E:
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B358;  // 0601B30E bra 0x0601B358 ; mov.b r4,@(r0,r1)
L_0601B312:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B312 mov.b @r1,r3
L_0601B314:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B314 extu.b r3,r2
L_0601B316:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B434u);  // 0601B316 mov.w 0x0601B434,r1
L_0601B318:
    c.t = c.r[2] == c.r[1];  // 0601B318 cmp/eq r1,r2
L_0601B31A:
    if (!c.t) { goto L_0601B320; }  // 0601B31A bf 0x0601B320
L_0601B31C:
    goto L_0601B46A;  // 0601B31C bra 0x0601B46A ; nop
L_0601B320:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B320 mov.l 0x0601B43C,r1
L_0601B322:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B322 mov.b @r1,r1
L_0601B324:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B324 extu.b r1,r0
L_0601B326:
    c.r[1] = ld32(0x0601B438u);  // 0601B326 mov.l 0x0601B438,r1
L_0601B328:
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B358;  // 0601B328 bra 0x0601B358 ; mov.b r3,@(r0,r1)
L_0601B32C:
    c.r[10] = ld32(0x0601B43Cu);  // 0601B32C mov.l 0x0601B43C,r10
L_0601B32E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B32E mov.b @r10,r1
L_0601B330:
    c.r[8] = ld32(0x0601B438u);  // 0601B330 mov.l 0x0601B438,r8
L_0601B332:
    c.r[3] = c.r[1] & 0xFFu;  // 0601B332 extu.b r1,r3
L_0601B334:
    c.r[0] = c.r[3];  // 0601B334 mov r3,r0
L_0601B336:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601B336 mov.b @(r0,r8),r2
L_0601B338:
    c.r[1] = c.r[2] & 0xFFu;  // 0601B338 extu.b r2,r1
L_0601B33A:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B33A tst r1,r1
L_0601B33C:
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601B346; } }  // 0601B33C bt/s 0x0601B346 ; mov r2,r1
L_0601B340:
    c.r[1] -= 1;  // 0601B340 add #-1,r1
L_0601B342:
    st8(c.r[0] + c.r[8], c.r[1]); goto L_0601B358;  // 0601B342 bra 0x0601B358 ; mov.b r1,@(r0,r8)
L_0601B346:
    c.r[1] = ld32(0x0601B448u);  // 0601B346 mov.l 0x0601B448,r1
L_0601B348:
    c.r[0] = ld32(0x0601B44Cu);  // 0601B348 mov.l 0x0601B44C,r0
L_0601B34A:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B34Eu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B34Eu) return; }  // 0601B34A jsr @r0 ; mov.l @r1,r4
L_0601B34E:
    c.r[2] = c.r[0];  // 0601B34E mov r0,r2
L_0601B350:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B350 mov.b @r10,r1
L_0601B352:
    c.r[2] -= 1;  // 0601B352 add #-1,r2
L_0601B354:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B354 extu.b r1,r0
L_0601B356:
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601B356 mov.b r2,@(r0,r8)
L_0601B358:
    c.r[1] = c.r[9];  // 0601B358 mov r9,r1
L_0601B35A:
    c.r[1] += 1;  // 0601B35A add #1,r1
L_0601B35C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B35C mov.b @r1,r1
L_0601B35E:
    c.r[0] = c.r[1];  // 0601B35E mov r1,r0
L_0601B360:
    c.r[0] >>= 2;  // 0601B360 shlr2 r0
L_0601B362:
    c.r[0] >>= 2;  // 0601B362 shlr2 r0
L_0601B364:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B364 shlr r0
L_0601B366:
    c.r[0] >>= 2;  // 0601B366 shlr2 r0
L_0601B368:
    c.r[0] &= 0x1u;  // 0601B368 and #1,r0
L_0601B36A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B36A tst r0,r0
L_0601B36C:
    if (!c.t) { goto L_0601B46A; }  // 0601B36C bf 0x0601B46A
L_0601B36E:
    c.r[1] = ld32(0x0601B450u);  // 0601B36E mov.l 0x0601B450,r1
L_0601B370:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B370 mov.w @r1,r1
L_0601B372:
    c.r[2] = ld32(0x0601B454u);  // 0601B372 mov.l 0x0601B454,r2
L_0601B374:
    c.r[2] &= c.r[1];  // 0601B374 and r1,r2
L_0601B376:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B376 tst r2,r2
L_0601B378:
    if (!c.t) { goto L_0601B37E; }  // 0601B378 bf 0x0601B37E
L_0601B37A:
    goto L_0601B4C6;  // 0601B37A bra 0x0601B4C6 ; nop
L_0601B37E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B37E mov.b @r9,r1
L_0601B380:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B436u);  // 0601B380 mov.w 0x0601B436,r0
L_0601B382:
    c.r[1] &= c.r[0];  // 0601B382 and r0,r1
L_0601B384:
    c.r[1] >>= 2;  // 0601B384 shlr2 r1
L_0601B386:
    c.r[1] >>= 2;  // 0601B386 shlr2 r1
L_0601B388:
    c.r[1] >>= 2;  // 0601B388 shlr2 r1
L_0601B38A:
    c.r[0] = c.r[1];  // 0601B38A mov r1,r0
L_0601B38C:
    c.t = c.r[0] == 0x1u;  // 0601B38C cmp/eq #1,r0
L_0601B38E:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B39C; } }  // 0601B38E bt/s 0x0601B39C ; mov r9,r1
L_0601B392:
    c.t = c.r[0] == 0x2u;  // 0601B392 cmp/eq #2,r0
L_0601B394:
    { const bool k = c.t; c.r[1] += 5; if (k) { goto L_0601B470; } }  // 0601B394 bt/s 0x0601B470 ; add #5,r1
L_0601B398:
    goto L_0601B486;  // 0601B398 bra 0x0601B486 ; nop
L_0601B39C:
    c.r[1] += 5;  // 0601B39C add #5,r1
L_0601B39E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B39E mov.b @r1,r1
L_0601B3A0:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3A0 extu.b r1,r10
L_0601B3A2:
    c.r[1] = c.r[9];  // 0601B3A2 mov r9,r1
L_0601B3A4:
    c.r[1] += 4;  // 0601B3A4 add #4,r1
L_0601B3A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3A6 mov.b @r1,r1
L_0601B3A8:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B3A8 extu.b r1,r8
L_0601B3AA:
    c.r[1] = c.r[9];  // 0601B3AA mov r9,r1
L_0601B3AC:
    c.r[1] += 8;  // 0601B3AC add #8,r1
L_0601B3AE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3AE mov.b @r1,r1
L_0601B3B0:
    c.macl = c.r[10] * c.r[8];  // 0601B3B0 mul.l r8,r10
L_0601B3B2:
    c.r[4] = c.r[1] & 0xFFu;  // 0601B3B2 extu.b r1,r4
L_0601B3B4:
    c.r[1] = c.r[9];  // 0601B3B4 mov r9,r1
L_0601B3B6:
    c.r[1] += 9;  // 0601B3B6 add #9,r1
L_0601B3B8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3B8 mov.b @r1,r1
L_0601B3BA:
    c.r[4] <<= 8;  // 0601B3BA shll8 r4
L_0601B3BC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3BC extu.b r1,r1
L_0601B3BE:
    c.r[4] |= c.r[1];  // 0601B3BE or r1,r4
L_0601B3C0:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B3C0 mov.l 0x0601B43C,r1
L_0601B3C2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3C2 mov.b @r1,r1
L_0601B3C4:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3C4 extu.b r1,r10
L_0601B3C6:
    c.r[1] = ld32(0x0601B444u);  // 0601B3C6 mov.l 0x0601B444,r1
L_0601B3C8:
    c.r[0] = c.r[10];  // 0601B3C8 mov r10,r0
L_0601B3CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B3CA mov.b @(r0,r1),r1
L_0601B3CC:
    c.r[2] = c.macl;  // 0601B3CC sts macl,r2
L_0601B3CE:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3CE extu.b r1,r1
L_0601B3D0:
    c.r[1] -= 1;  // 0601B3D0 add #-1,r1
L_0601B3D2:
    c.macl = c.r[2] * c.r[1];  // 0601B3D2 mul.l r1,r2
L_0601B3D4:
    c.r[1] = c.macl;  // 0601B3D4 sts macl,r1
L_0601B3D6:
    c.macl = c.r[2];  // 0601B3D6 lds r2,macl
L_0601B3D8:
    c.r[4] -= c.r[1];  // 0601B3D8 sub r1,r4
L_0601B3DA:
    c.r[1] = c.macl;  // 0601B3DA sts macl,r1
L_0601B3DC:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B3DC cmp/gt r1,r4
L_0601B3DE:
    if (!c.t) { goto L_0601B3E2; }  // 0601B3DE bf 0x0601B3E2
L_0601B3E0:
    c.r[4] = c.macl;  // 0601B3E0 sts macl,r4
L_0601B3E2:
    c.r[12] = ld32(0x0601B438u);  // 0601B3E2 mov.l 0x0601B438,r12
L_0601B3E4:
    c.r[0] = c.r[10];  // 0601B3E4 mov r10,r0
L_0601B3E6:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0601B3E6 mov.b @(r0,r12),r11
L_0601B3E8:
    c.r[6] = c.r[11] & 0xFFu;  // 0601B3E8 extu.b r11,r6
L_0601B3EA:
    c.r[6] += 1;  // 0601B3EA add #1,r6
L_0601B3EC:
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0601B3EC cmp/ge r4,r6
L_0601B3EE:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B3EE bt/s 0x0601B410 ; mov r9,r1
L_0601B3F2:
    c.r[4] = c.r[6];  // 0601B3F2 mov r6,r4
L_0601B3F4:
    c.r[7] = ld32(0x0601B440u);  // 0601B3F4 mov.l 0x0601B440,r7
L_0601B3F6:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B3FAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B3FAu) return; }  // 0601B3F6 jsr @r7 ; mov r8,r5
L_0601B3FA:
    c.macl = c.r[0] * c.r[8];  // 0601B3FA mul.l r8,r0
L_0601B3FC:
    c.r[1] = c.macl;  // 0601B3FC sts macl,r1
L_0601B3FE:
    c.r[6] -= c.r[1];  // 0601B3FE sub r1,r6
L_0601B400:
    c.t = (c.r[6] & c.r[6]) == 0;  // 0601B400 tst r6,r6
L_0601B402:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B402 bt/s 0x0601B410 ; mov r9,r1
L_0601B406:
    c.r[1] = c.r[11];  // 0601B406 mov r11,r1
L_0601B408:
    c.r[1] += 1;  // 0601B408 add #1,r1
L_0601B40A:
    c.r[0] = c.r[10];  // 0601B40A mov r10,r0
L_0601B40C:
    st8(c.r[0] + c.r[12], c.r[1]); goto L_0601B4B0;  // 0601B40C bra 0x0601B4B0 ; mov.b r1,@(r0,r12)
L_0601B410:
    c.r[1] += 1;  // 0601B410 add #1,r1
L_0601B412:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B412 mov.b @r1,r1
L_0601B414:
    c.r[0] = c.r[1];  // 0601B414 mov r1,r0
L_0601B416:
    c.r[0] >>= 2;  // 0601B416 shlr2 r0
L_0601B418:
    c.r[0] >>= 2;  // 0601B418 shlr2 r0
L_0601B41A:
    c.r[0] >>= 2;  // 0601B41A shlr2 r0
L_0601B41C:
    c.r[0] &= 0x1u;  // 0601B41C and #1,r0
L_0601B41E:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B41E tst r0,r0
L_0601B420:
    { const bool k = c.t; c.r[8] -= 1; if (k) { goto L_0601B458; } }  // 0601B420 bt/s 0x0601B458 ; add #-1,r8
L_0601B424:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B424 mov.l 0x0601B43C,r1
L_0601B426:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B426 mov.b @r1,r1
L_0601B428:
    c.r[2] = ld32(0x0601B438u);  // 0601B428 mov.l 0x0601B438,r2
L_0601B42A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B42A extu.b r1,r0
L_0601B42C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601B42C mov.b @(r0,r2),r1
L_0601B42E:
    c.r[1] -= c.r[8];  // 0601B42E sub r8,r1
L_0601B430:
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0601B4B0;  // 0601B430 bra 0x0601B4B0 ; mov.b r1,@(r0,r2)
L_0601B458:
    c.r[1] = ld32(0x0601B564u);  // 0601B458 mov.l 0x0601B564,r1
L_0601B45A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B45A mov.b @r1,r1
L_0601B45C:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B45C extu.b r1,r0
L_0601B45E:
    c.r[1] = ld32(0x0601B568u);  // 0601B45E mov.l 0x0601B568,r1
L_0601B460:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B460 mov.b @(r0,r1),r1
L_0601B462:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B462 extu.b r1,r1
L_0601B464:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B464 tst r1,r1
L_0601B466:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4B2; } }  // 0601B466 bt/s 0x0601B4B2 ; mov r9,r1
L_0601B46A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B55Cu);  // 0601B46A mov.w 0x0601B55C,r0
L_0601B46C:
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B46C bra 0x0601B6D2 ; mov r14,r15
L_0601B470:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B470 mov.b @r1,r3
L_0601B472:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B472 extu.b r3,r2
L_0601B474:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B55Eu);  // 0601B474 mov.w 0x0601B55E,r1
L_0601B476:
    c.t = c.r[2] == c.r[1];  // 0601B476 cmp/eq r1,r2
L_0601B478:
    if (c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B478 bt 0x0601B46A
L_0601B47A:
    c.r[1] = ld32(0x0601B564u);  // 0601B47A mov.l 0x0601B564,r1
L_0601B47C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B47C mov.b @r1,r1
L_0601B47E:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B47E extu.b r1,r0
L_0601B480:
    c.r[1] = ld32(0x0601B568u);  // 0601B480 mov.l 0x0601B568,r1
L_0601B482:
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B4B0;  // 0601B482 bra 0x0601B4B0 ; mov.b r3,@(r0,r1)
L_0601B486:
    c.r[10] = ld32(0x0601B564u);  // 0601B486 mov.l 0x0601B564,r10
L_0601B488:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B488 mov.b @r10,r1
L_0601B48A:
    c.r[11] = ld32(0x0601B568u);  // 0601B48A mov.l 0x0601B568,r11
L_0601B48C:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B48C extu.b r1,r0
L_0601B48E:
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B48E mov.b @(r0,r11),r8
L_0601B490:
    c.r[1] = ld32(0x0601B56Cu);  // 0601B490 mov.l 0x0601B56C,r1
L_0601B492:
    c.r[4] = ld32(c.r[1]);  // 0601B492 mov.l @r1,r4
L_0601B494:
    c.r[0] = ld32(0x0601B570u);  // 0601B494 mov.l 0x0601B570,r0
L_0601B496:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B49Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B49Au) return; }  // 0601B496 jsr @r0 ; extu.b r8,r8
L_0601B49A:
    c.r[0] -= 1;  // 0601B49A add #-1,r0
L_0601B49C:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 0601B49C cmp/ge r0,r8
L_0601B49E:
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0601B4AA; } }  // 0601B49E bt/s 0x0601B4AA ; mov.b @r10,r1
L_0601B4A2:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4A2 extu.b r1,r0
L_0601B4A4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B4A4 mov.b @(r0,r11),r1
L_0601B4A6:
    c.r[1] += 1; goto L_0601B4AE;  // 0601B4A6 bra 0x0601B4AE ; add #1,r1
L_0601B4AA:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4AA extu.b r1,r0
L_0601B4AC:
    c.r[1] = 0x0u;  // 0601B4AC mov #0,r1
L_0601B4AE:
    st8(c.r[0] + c.r[11], c.r[1]);  // 0601B4AE mov.b r1,@(r0,r11)
L_0601B4B0:
    c.r[1] = c.r[9];  // 0601B4B0 mov r9,r1
L_0601B4B2:
    c.r[1] += 1;  // 0601B4B2 add #1,r1
L_0601B4B4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4B4 mov.b @r1,r1
L_0601B4B6:
    c.r[0] = c.r[1];  // 0601B4B6 mov r1,r0
L_0601B4B8:
    c.r[0] >>= 2;  // 0601B4B8 shlr2 r0
L_0601B4BA:
    c.r[0] >>= 2;  // 0601B4BA shlr2 r0
L_0601B4BC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B4BC shlr r0
L_0601B4BE:
    c.r[0] >>= 2;  // 0601B4BE shlr2 r0
L_0601B4C0:
    c.r[0] &= 0x1u;  // 0601B4C0 and #1,r0
L_0601B4C2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B4C2 tst r0,r0
L_0601B4C4:
    if (!c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B4C4 bf 0x0601B46A
L_0601B4C6:
    c.r[1] = ld32(0x0601B574u);  // 0601B4C6 mov.l 0x0601B574,r1
L_0601B4C8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B4C8 mov.w @r1,r1
L_0601B4CA:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B560u);  // 0601B4CA mov.w 0x0601B560,r2
L_0601B4CC:
    c.r[2] &= c.r[1];  // 0601B4CC and r1,r2
L_0601B4CE:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B4CE tst r2,r2
L_0601B4D0:
    if (!c.t) { goto L_0601B4D6; }  // 0601B4D0 bf 0x0601B4D6
L_0601B4D2:
    goto L_0601B5E2;  // 0601B4D2 bra 0x0601B5E2 ; nop
L_0601B4D6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B4D6 mov.b @r9,r1
L_0601B4D8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B562u);  // 0601B4D8 mov.w 0x0601B562,r0
L_0601B4DA:
    c.r[1] &= c.r[0];  // 0601B4DA and r0,r1
L_0601B4DC:
    c.r[1] >>= 2;  // 0601B4DC shlr2 r1
L_0601B4DE:
    c.r[1] >>= 2;  // 0601B4DE shlr2 r1
L_0601B4E0:
    c.r[1] >>= 2;  // 0601B4E0 shlr2 r1
L_0601B4E2:
    c.r[0] = c.r[1];  // 0601B4E2 mov r1,r0
L_0601B4E4:
    c.t = c.r[0] == 0x1u;  // 0601B4E4 cmp/eq #1,r0
L_0601B4E6:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4F4; } }  // 0601B4E6 bt/s 0x0601B4F4 ; mov r9,r1
L_0601B4EA:
    c.t = c.r[0] == 0x2u;  // 0601B4EA cmp/eq #2,r0
L_0601B4EC:
    { const bool k = c.t; c.r[1] += 6; if (k) { goto L_0601B5B0; } }  // 0601B4EC bt/s 0x0601B5B0 ; add #6,r1
L_0601B4F0:
    c.r[1] = c.r[9]; goto L_0601B5CA;  // 0601B4F0 bra 0x0601B5CA ; mov r9,r1
L_0601B4F4:
    c.r[1] += 5;  // 0601B4F4 add #5,r1
L_0601B4F6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4F6 mov.b @r1,r1
L_0601B4F8:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B4F8 extu.b r1,r10
L_0601B4FA:
    c.r[1] = c.r[9];  // 0601B4FA mov r9,r1
L_0601B4FC:
    c.r[1] += 4;  // 0601B4FC add #4,r1
L_0601B4FE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4FE mov.b @r1,r1
L_0601B500:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B500 extu.b r1,r8
L_0601B502:
    c.r[1] = ld32(0x0601B564u);  // 0601B502 mov.l 0x0601B564,r1
L_0601B504:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B504 mov.b @r1,r1
L_0601B506:
    c.r[3] = ld32(0x0601B568u);  // 0601B506 mov.l 0x0601B568,r3
L_0601B508:
    c.r[2] = c.r[1] & 0xFFu;  // 0601B508 extu.b r1,r2
L_0601B50A:
    c.r[0] = c.r[2];  // 0601B50A mov r2,r0
L_0601B50C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B50C mov.b @(r0,r3),r1
L_0601B50E:
    c.r[7] = c.r[1] & 0xFFu;  // 0601B50E extu.b r1,r7
L_0601B510:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0601B510 cmp/ge r8,r7
L_0601B512:
    { const bool k = !c.t; c.r[1] -= c.r[8]; if (k) { goto L_0601B51A; } }  // 0601B512 bf/s 0x0601B51A ; sub r8,r1
L_0601B516:
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0601B5C8;  // 0601B516 bra 0x0601B5C8 ; mov.b r1,@(r0,r3)
L_0601B51A:
    c.r[1] = c.r[9];  // 0601B51A mov r9,r1
L_0601B51C:
    c.r[1] += 1;  // 0601B51C add #1,r1
L_0601B51E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B51E mov.b @r1,r1
L_0601B520:
    c.r[0] = c.r[1];  // 0601B520 mov r1,r0
L_0601B522:
    c.r[0] >>= 2;  // 0601B522 shlr2 r0
L_0601B524:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B524 shlr r0
L_0601B526:
    c.r[0] >>= 2;  // 0601B526 shlr2 r0
L_0601B528:
    c.r[0] &= 0x1u;  // 0601B528 and #1,r0
L_0601B52A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B52A tst r0,r0
L_0601B52C:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0601B46A; } }  // 0601B52C bt/s 0x0601B46A ; mov r9,r1
L_0601B530:
    c.r[1] += 8;  // 0601B530 add #8,r1
L_0601B532:
    c.r[0] = c.r[2];  // 0601B532 mov r2,r0
L_0601B534:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B534 mov.b @r1,r1
L_0601B536:
    c.macl = c.r[10] * c.r[8];  // 0601B536 mul.l r8,r10
L_0601B538:
    c.r[3] = c.r[1] & 0xFFu;  // 0601B538 extu.b r1,r3
L_0601B53A:
    c.r[1] = c.r[9];  // 0601B53A mov r9,r1
L_0601B53C:
    c.r[1] += 9;  // 0601B53C add #9,r1
L_0601B53E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B53E mov.b @r1,r1
L_0601B540:
    c.r[3] <<= 8;  // 0601B540 shll8 r3
L_0601B542:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B542 extu.b r1,r1
L_0601B544:
    c.r[3] |= c.r[1];  // 0601B544 or r1,r3
L_0601B546:
    c.r[1] = ld32(0x0601B578u);  // 0601B546 mov.l 0x0601B578,r1
L_0601B548:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B548 mov.b @(r0,r1),r1
L_0601B54A:
    c.r[4] = c.macl;  // 0601B54A sts macl,r4
L_0601B54C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B54C extu.b r1,r1
L_0601B54E:
    c.r[1] -= 1;  // 0601B54E add #-1,r1
L_0601B550:
    c.macl = c.r[1] * c.r[10];  // 0601B550 mul.l r10,r1
L_0601B552:
    c.r[4] -= c.r[8];  // 0601B552 sub r8,r4
L_0601B554:
    c.r[1] = c.macl;  // 0601B554 sts macl,r1
L_0601B556:
    c.macl = c.r[1] * c.r[8];  // 0601B556 mul.l r8,r1
L_0601B558:
    c.r[4] += c.r[7]; goto L_0601B596;  // 0601B558 bra 0x0601B596 ; add r7,r4
L_0601B57C:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B57C mov.l 0x0601B6EC,r1
L_0601B57E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B57E mov.b @(r0,r1),r1
L_0601B580:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B580 extu.b r1,r1
L_0601B582:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B582 cmp/gt r1,r4
L_0601B584:
    if (!c.t) { goto L_0601B5A4; }  // 0601B584 bf 0x0601B5A4
L_0601B586:
    c.r[4] -= c.r[8];  // 0601B586 sub r8,r4
L_0601B588:
    c.r[1] = ld32(0x0601B6F0u);  // 0601B588 mov.l 0x0601B6F0,r1
L_0601B58A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B58A mov.b @(r0,r1),r1
L_0601B58C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B58C extu.b r1,r1
L_0601B58E:
    c.r[1] -= 1;  // 0601B58E add #-1,r1
L_0601B590:
    c.macl = c.r[1] * c.r[10];  // 0601B590 mul.l r10,r1
L_0601B592:
    c.r[1] = c.macl;  // 0601B592 sts macl,r1
L_0601B594:
    c.macl = c.r[1] * c.r[8];  // 0601B594 mul.l r8,r1
L_0601B596:
    c.r[0] = c.r[3];  // 0601B596 mov r3,r0
L_0601B598:
    c.r[1] = c.macl;  // 0601B598 sts macl,r1
L_0601B59A:
    c.r[0] -= c.r[1];  // 0601B59A sub r1,r0
L_0601B59C:
    c.r[1] = c.r[0];  // 0601B59C mov r0,r1
L_0601B59E:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B59E cmp/gt r4,r1
L_0601B5A0:
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0601B57C; } }  // 0601B5A0 bf/s 0x0601B57C ; mov r2,r0
L_0601B5A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5A4 mov.l 0x0601B6F4,r1
L_0601B5A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5A6 mov.b @r1,r1
L_0601B5A8:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5A8 extu.b r1,r0
L_0601B5AA:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5AA mov.l 0x0601B6EC,r1
L_0601B5AC:
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B5C8;  // 0601B5AC bra 0x0601B5C8 ; mov.b r4,@(r0,r1)
L_0601B5B0:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5B0 mov.b @r1,r3
L_0601B5B2:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B5B2 extu.b r3,r2
L_0601B5B4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B5B4 mov.w 0x0601B6E4,r1
L_0601B5B6:
    c.t = c.r[2] == c.r[1];  // 0601B5B6 cmp/eq r1,r2
L_0601B5B8:
    if (!c.t) { goto L_0601B5BE; }  // 0601B5B8 bf 0x0601B5BE
L_0601B5BA:
    SH2_POLL(c); goto L_0601B46A;  // 0601B5BA bra 0x0601B46A ; nop
L_0601B5BE:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5BE mov.l 0x0601B6F4,r1
L_0601B5C0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5C0 mov.b @r1,r1
L_0601B5C2:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5C2 extu.b r1,r0
L_0601B5C4:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5C4 mov.l 0x0601B6EC,r1
L_0601B5C6:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B5C6 mov.b r3,@(r0,r1)
L_0601B5C8:
    c.r[1] = c.r[9];  // 0601B5C8 mov r9,r1
L_0601B5CA:
    c.r[1] += 1;  // 0601B5CA add #1,r1
L_0601B5CC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5CC mov.b @r1,r1
L_0601B5CE:
    c.r[0] = c.r[1];  // 0601B5CE mov r1,r0
L_0601B5D0:
    c.r[0] >>= 2;  // 0601B5D0 shlr2 r0
L_0601B5D2:
    c.r[0] >>= 2;  // 0601B5D2 shlr2 r0
L_0601B5D4:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B5D4 shlr r0
L_0601B5D6:
    c.r[0] >>= 2;  // 0601B5D6 shlr2 r0
L_0601B5D8:
    c.r[0] &= 0x1u;  // 0601B5D8 and #1,r0
L_0601B5DA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B5DA tst r0,r0
L_0601B5DC:
    if (c.t) { goto L_0601B5E2; }  // 0601B5DC bt 0x0601B5E2
L_0601B5DE:
    SH2_POLL(c); goto L_0601B46A;  // 0601B5DE bra 0x0601B46A ; nop
L_0601B5E2:
    c.r[1] = ld32(0x0601B6F8u);  // 0601B5E2 mov.l 0x0601B6F8,r1
L_0601B5E4:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B5E4 mov.w @r1,r1
L_0601B5E6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B6E6u);  // 0601B5E6 mov.w 0x0601B6E6,r2
L_0601B5E8:
    c.r[2] &= c.r[1];  // 0601B5E8 and r1,r2
L_0601B5EA:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B5EA tst r2,r2
L_0601B5EC:
    if (c.t) { goto L_0601B6C8; }  // 0601B5EC bt 0x0601B6C8
L_0601B5EE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B5EE mov.b @r9,r1
L_0601B5F0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B6E8u);  // 0601B5F0 mov.w 0x0601B6E8,r0
L_0601B5F2:
    c.r[1] &= c.r[0];  // 0601B5F2 and r0,r1
L_0601B5F4:
    c.r[1] >>= 2;  // 0601B5F4 shlr2 r1
L_0601B5F6:
    c.r[1] >>= 2;  // 0601B5F6 shlr2 r1
L_0601B5F8:
    c.r[1] >>= 2;  // 0601B5F8 shlr2 r1
L_0601B5FA:
    c.r[0] = c.r[1];  // 0601B5FA mov r1,r0
L_0601B5FC:
    c.t = c.r[0] == 0x1u;  // 0601B5FC cmp/eq #1,r0
L_0601B5FE:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B60C; } }  // 0601B5FE bt/s 0x0601B60C ; mov r9,r1
L_0601B602:
    c.t = c.r[0] == 0x2u;  // 0601B602 cmp/eq #2,r0
L_0601B604:
    { const bool k = c.t; c.r[1] += 7; if (k) { goto L_0601B696; } }  // 0601B604 bt/s 0x0601B696 ; add #7,r1
L_0601B608:
    c.r[1] = c.r[9]; goto L_0601B6B0;  // 0601B608 bra 0x0601B6B0 ; mov r9,r1
L_0601B60C:
    c.r[1] += 5;  // 0601B60C add #5,r1
L_0601B60E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B60E mov.b @r1,r1
L_0601B610:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B610 extu.b r1,r10
L_0601B612:
    c.r[1] = c.r[9];  // 0601B612 mov r9,r1
L_0601B614:
    c.r[1] += 4;  // 0601B614 add #4,r1
L_0601B616:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B616 mov.b @r1,r1
L_0601B618:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B618 extu.b r1,r8
L_0601B61A:
    c.r[1] = c.r[9];  // 0601B61A mov r9,r1
L_0601B61C:
    c.r[1] += 8;  // 0601B61C add #8,r1
L_0601B61E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B61E mov.b @r1,r1
L_0601B620:
    c.macl = c.r[10] * c.r[8];  // 0601B620 mul.l r8,r10
L_0601B622:
    c.r[4] = c.r[1] & 0xFFu;  // 0601B622 extu.b r1,r4
L_0601B624:
    c.r[1] = c.r[9];  // 0601B624 mov r9,r1
L_0601B626:
    c.r[1] += 9;  // 0601B626 add #9,r1
L_0601B628:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B628 mov.b @r1,r1
L_0601B62A:
    c.r[4] <<= 8;  // 0601B62A shll8 r4
L_0601B62C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B62C extu.b r1,r1
L_0601B62E:
    c.r[4] |= c.r[1];  // 0601B62E or r1,r4
L_0601B630:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B630 mov.l 0x0601B6F4,r1
L_0601B632:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B632 mov.b @r1,r1
L_0601B634:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B634 extu.b r1,r10
L_0601B636:
    c.r[1] = ld32(0x0601B6F0u);  // 0601B636 mov.l 0x0601B6F0,r1
L_0601B638:
    c.r[0] = c.r[10];  // 0601B638 mov r10,r0
L_0601B63A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B63A mov.b @(r0,r1),r1
L_0601B63C:
    c.r[2] = c.macl;  // 0601B63C sts macl,r2
L_0601B63E:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B63E extu.b r1,r1
L_0601B640:
    c.r[1] -= 1;  // 0601B640 add #-1,r1
L_0601B642:
    c.macl = c.r[2] * c.r[1];  // 0601B642 mul.l r1,r2
L_0601B644:
    c.r[1] = c.macl;  // 0601B644 sts macl,r1
L_0601B646:
    c.macl = c.r[2];  // 0601B646 lds r2,macl
L_0601B648:
    c.r[4] -= c.r[1];  // 0601B648 sub r1,r4
L_0601B64A:
    c.r[1] = c.macl;  // 0601B64A sts macl,r1
L_0601B64C:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B64C cmp/gt r1,r4
L_0601B64E:
    if (!c.t) { goto L_0601B652; }  // 0601B64E bf 0x0601B652
L_0601B650:
    c.r[4] = c.macl;  // 0601B650 sts macl,r4
L_0601B652:
    c.r[11] = ld32(0x0601B6ECu);  // 0601B652 mov.l 0x0601B6EC,r11
L_0601B654:
    c.r[0] = c.r[10];  // 0601B654 mov r10,r0
L_0601B656:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B656 mov.b @(r0,r11),r2
L_0601B658:
    c.r[6] = c.r[2] & 0xFFu;  // 0601B658 extu.b r2,r6
L_0601B65A:
    c.r[1] = c.r[6];  // 0601B65A mov r6,r1
L_0601B65C:
    c.r[1] += c.r[8];  // 0601B65C add r8,r1
L_0601B65E:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[4];  // 0601B65E cmp/ge r4,r1
L_0601B660:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B66A; } }  // 0601B660 bt/s 0x0601B66A ; mov r9,r1
L_0601B664:
    c.r[8] += c.r[2];  // 0601B664 add r2,r8
L_0601B666:
    st8(c.r[0] + c.r[11], c.r[8]); goto L_0601B6B0;  // 0601B666 bra 0x0601B6B0 ; mov.b r8,@(r0,r11)
L_0601B66A:
    c.r[1] += 1;  // 0601B66A add #1,r1
L_0601B66C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B66C mov.b @r1,r1
L_0601B66E:
    c.r[0] = c.r[1];  // 0601B66E mov r1,r0
L_0601B670:
    c.r[0] >>= 2;  // 0601B670 shlr2 r0
L_0601B672:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B672 shlr r0
L_0601B674:
    c.r[0] >>= 2;  // 0601B674 shlr2 r0
L_0601B676:
    c.r[0] &= 0x1u;  // 0601B676 and #1,r0
L_0601B678:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B678 tst r0,r0
L_0601B67A:
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B682; } }  // 0601B67A bf/s 0x0601B682 ; mov r6,r4
L_0601B67E:
    SH2_POLL(c); goto L_0601B46A;  // 0601B67E bra 0x0601B46A ; nop
L_0601B682:
    c.r[7] = ld32(0x0601B6FCu);  // 0601B682 mov.l 0x0601B6FC,r7
L_0601B684:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B688u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B688u) return; }  // 0601B684 jsr @r7 ; mov r8,r5
L_0601B688:
    c.r[7] = c.r[0];  // 0601B688 mov r0,r7
L_0601B68A:
    c.macl = c.r[7] * c.r[8];  // 0601B68A mul.l r8,r7
L_0601B68C:
    c.r[0] = c.r[10];  // 0601B68C mov r10,r0
L_0601B68E:
    c.r[1] = c.macl;  // 0601B68E sts macl,r1
L_0601B690:
    c.r[6] -= c.r[1];  // 0601B690 sub r1,r6
L_0601B692:
    st8(c.r[0] + c.r[11], c.r[6]); goto L_0601B6AE;  // 0601B692 bra 0x0601B6AE ; mov.b r6,@(r0,r11)
L_0601B696:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B696 mov.b @r1,r3
L_0601B698:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B698 extu.b r3,r2
L_0601B69A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B69A mov.w 0x0601B6E4,r1
L_0601B69C:
    c.t = c.r[2] == c.r[1];  // 0601B69C cmp/eq r1,r2
L_0601B69E:
    if (!c.t) { goto L_0601B6A4; }  // 0601B69E bf 0x0601B6A4
L_0601B6A0:
    SH2_POLL(c); goto L_0601B46A;  // 0601B6A0 bra 0x0601B46A ; nop
L_0601B6A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B6A4 mov.l 0x0601B6F4,r1
L_0601B6A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6A6 mov.b @r1,r1
L_0601B6A8:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B6A8 extu.b r1,r0
L_0601B6AA:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B6AA mov.l 0x0601B6EC,r1
L_0601B6AC:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B6AC mov.b r3,@(r0,r1)
L_0601B6AE:
    c.r[1] = c.r[9];  // 0601B6AE mov r9,r1
L_0601B6B0:
    c.r[1] += 1;  // 0601B6B0 add #1,r1
L_0601B6B2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6B2 mov.b @r1,r1
L_0601B6B4:
    c.r[0] = c.r[1];  // 0601B6B4 mov r1,r0
L_0601B6B6:
    c.r[0] >>= 2;  // 0601B6B6 shlr2 r0
L_0601B6B8:
    c.r[0] >>= 2;  // 0601B6B8 shlr2 r0
L_0601B6BA:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B6BA shlr r0
L_0601B6BC:
    c.r[0] >>= 2;  // 0601B6BC shlr2 r0
L_0601B6BE:
    c.r[0] &= 0x1u;  // 0601B6BE and #1,r0
L_0601B6C0:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B6C0 tst r0,r0
L_0601B6C2:
    if (c.t) { goto L_0601B6C8; }  // 0601B6C2 bt 0x0601B6C8
L_0601B6C4:
    SH2_POLL(c); goto L_0601B46A;  // 0601B6C4 bra 0x0601B46A ; nop
L_0601B6C8:
    c.r[1] = ld32(0x0601B700u);  // 0601B6C8 mov.l 0x0601B700,r1
L_0601B6CA:
    { const uint32_t x = c.r[1]; c.pr = 0x0601B6CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B6CEu) return; }  // 0601B6CA jsr @r1 ; mov r9,r4
L_0601B6CE:
    c.r[0] = 0x0u;  // 0601B6CE mov #0,r0
L_0601B6D0:
    c.r[15] = c.r[14];  // 0601B6D0 mov r14,r15
L_0601B6D2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B6D2 lds.l @r15+,pr
L_0601B6D4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D4 mov.l @r15+,r14
L_0601B6D6:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D6 mov.l @r15+,r13
L_0601B6D8:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D8 mov.l @r15+,r12
L_0601B6DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DA mov.l @r15+,r11
L_0601B6DC:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DC mov.l @r15+,r10
L_0601B6DE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DE mov.l @r15+,r9
L_0601B6E0:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B6E0 rts ; mov.l @r15+,r8
L_0607EB7C:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607EB7C mov.l r8,@-r15
L_0607EB7E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607EB7E mov.l r9,@-r15
L_0607EB80:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607EB80 mov.l r10,@-r15
L_0607EB82:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607EB82 mov.l r11,@-r15
L_0607EB84:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607EB84 mov.l r12,@-r15
L_0607EB86:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607EB86 mov.l r13,@-r15
L_0607EB88:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EB88 mov.l r14,@-r15
L_0607EB8A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EB8A sts.l pr,@-r15
L_0607EB8C:
    c.r[1] = ld32(0x0607ED04u);  // 0607EB8C mov.l 0x0607ED04,r1
L_0607EB8E:
    c.r[10] = ld32(c.r[1]);  // 0607EB8E mov.l @r1,r10
L_0607EB90:
    c.r[0] = 0x0u;  // 0607EB90 mov #0,r0
L_0607EB92:
    st32(c.r[1], c.r[0]);  // 0607EB92 mov.l r0,@r1
L_0607EB94:
    c.r[1] = ld32(0x0607ED08u);  // 0607EB94 mov.l 0x0607ED08,r1
L_0607EB96:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB96 mov.b @r1,r0
L_0607EB98:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EB98 extu.b r0,r0
L_0607EB9A:
    c.r[13] = c.r[0];  // 0607EB9A mov r0,r13
L_0607EB9C:
    c.r[1] = ld32(0x0607ED0Cu);  // 0607EB9C mov.l 0x0607ED0C,r1
L_0607EB9E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB9E mov.b @r1,r0
L_0607EBA0:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EBA0 extu.b r0,r0
L_0607EBA2:
    c.r[1] = c.r[13];  // 0607EBA2 mov r13,r1
L_0607EBA4:
    c.r[1] <<= 8;  // 0607EBA4 shll8 r1
L_0607EBA6:
    c.r[0] |= c.r[1];  // 0607EBA6 or r1,r0
L_0607EBA8:
    c.r[1] = ld32(0x0607ED10u);  // 0607EBA8 mov.l 0x0607ED10,r1
L_0607EBAA:
    st16(c.r[1], c.r[0]);  // 0607EBAA mov.w r0,@r1
L_0607EBAC:
    c.r[0] = c.r[13];  // 0607EBAC mov r13,r0
L_0607EBAE:
    c.t = c.r[0] == 0x43u;  // 0607EBAE cmp/eq #67,r0
L_0607EBB0:
    if (!c.t) { goto L_0607EBBA; }  // 0607EBB0 bf 0x0607EBBA
L_0607EBB2:
    c.r[1] = ld32(0x0607ED14u);  // 0607EBB2 mov.l 0x0607ED14,r1
L_0607EBB4:
    c.r[2] = ld32(0x0607ED18u);  // 0607EBB4 mov.l 0x0607ED18,r2
L_0607EBB6:
    goto L_0607EBC6;  // 0607EBB6 bra 0x0607EBC6 ; nop
L_0607EBBA:
    c.t = c.r[0] == 0x58u;  // 0607EBBA cmp/eq #88,r0
L_0607EBBC:
    if (c.t) { goto L_0607EBC2; }  // 0607EBBC bt 0x0607EBC2
L_0607EBBE:
    goto L_0607ECE8;  // 0607EBBE bra 0x0607ECE8 ; nop
L_0607EBC2:
    c.r[1] = ld32(0x0607ED1Cu);  // 0607EBC2 mov.l 0x0607ED1C,r1
L_0607EBC4:
    c.r[2] = ld32(0x0607ED20u);  // 0607EBC4 mov.l 0x0607ED20,r2
L_0607EBC6:
    c.r[1] = ld32(c.r[1]);  // 0607EBC6 mov.l @r1,r1
L_0607EBC8:
    c.t = c.r[2] == c.r[1];  // 0607EBC8 cmp/eq r1,r2
L_0607EBCA:
    if (c.t) { goto L_0607EBD0; }  // 0607EBCA bt 0x0607EBD0
L_0607EBCC:
    goto L_0607ECE8;  // 0607EBCC bra 0x0607ECE8 ; nop
L_0607EBD0:
    c.r[0] = c.r[13];  // 0607EBD0 mov r13,r0
L_0607EBD2:
    c.t = c.r[0] == 0x43u;  // 0607EBD2 cmp/eq #67,r0
L_0607EBD4:
    if (!c.t) { goto L_0607EC02; }  // 0607EBD4 bf 0x0607EC02
L_0607EBD6:
    c.t = (c.r[10] & c.r[10]) == 0;  // 0607EBD6 tst r10,r10
L_0607EBD8:
    if (c.t) { goto L_0607EC02; }  // 0607EBD8 bt 0x0607EC02
L_0607EBDA:
    c.r[1] = ld32(0x0607ED24u);  // 0607EBDA mov.l 0x0607ED24,r1
L_0607EBDC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EBDC mov.b @r1,r0
L_0607EBDE:
    c.t = (c.r[0] & 0x8u) == 0;  // 0607EBDE tst #8,r0
L_0607EBE0:
    if (!c.t) { goto L_0607EC02; }  // 0607EBE0 bf 0x0607EC02
L_0607EBE2:
    c.r[1] = ld32(0x0607ED28u);  // 0607EBE2 mov.l 0x0607ED28,r1
L_0607EBE4:
    c.r[1] = ld32(c.r[1]);  // 0607EBE4 mov.l @r1,r1
L_0607EBE6:
    c.t = c.r[10] == c.r[1];  // 0607EBE6 cmp/eq r1,r10
L_0607EBE8:
    if (!c.t) { goto L_0607EC02; }  // 0607EBE8 bf 0x0607EC02
L_0607EBEA:
    c.r[3] = c.r[10];  // 0607EBEA mov r10,r3
L_0607EBEC:
    c.r[8] = ld32(0x0607ED2Cu);  // 0607EBEC mov.l 0x0607ED2C,r8
L_0607EBEE:
    c.r[9] = 0x1Cu;  // 0607EBEE mov #28,r9
L_0607EBF0:
    c.r[10] = 0x28u;  // 0607EBF0 mov #40,r10
L_0607EBF2:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]); c.r[8] += 2;  // 0607EBF2 mov.w @r8+,r1
L_0607EBF4:
    st16(c.r[3], c.r[1]);  // 0607EBF4 mov.w r1,@r3
L_0607EBF6:
    c.r[10] -= 1; c.t = c.r[10] == 0;  // 0607EBF6 dt r10
L_0607EBF8:
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0607EBF2; } }  // 0607EBF8 bf/s 0x0607EBF2 ; add #2,r3
L_0607EBFC:
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 0607EBFC dt r9
L_0607EBFE:
    { const bool k = !c.t; c.r[3] += 48; if (k) { SH2_POLL(c); goto L_0607EBF0; } }  // 0607EBFE bf/s 0x0607EBF0 ; add #48,r3
L_0607EC02:
    c.r[3] = ld32(0x0607ED30u);  // 0607EC02 mov.l 0x0607ED30,r3
L_0607EC04:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607EC04 mov.w @r3,r1
L_0607EC06:
    c.r[4] = ld32(0x0607ED34u);  // 0607EC06 mov.l 0x0607ED34,r4
L_0607EC08:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0607EC08 mov.w @r4,r2
L_0607EC0A:
    c.r[1] |= c.r[2];  // 0607EC0A or r2,r1
L_0607EC0C:
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607EC0C extu.w r1,r1
L_0607EC0E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607ED68u);  // 0607EC0E mov.w 0x0607ED68,r0
L_0607EC10:
    c.t = (c.r[1] & c.r[0]) == 0;  // 0607EC10 tst r0,r1
L_0607EC12:
    if (!c.t) { goto L_0607ECE8; }  // 0607EC12 bf 0x0607ECE8
L_0607EC14:
    c.r[0] = c.r[1];  // 0607EC14 mov r1,r0
L_0607EC16:
    c.r[0] <<= 2;  // 0607EC16 shll2 r0
L_0607EC18:
    c.r[0] >>= 16;  // 0607EC18 shlr16 r0
L_0607EC1A:
    c.t = c.r[0] == 0x1u;  // 0607EC1A cmp/eq #1,r0
L_0607EC1C:
    if (c.t) { goto L_0607EC26; }  // 0607EC1C bt 0x0607EC26
L_0607EC1E:
    c.t = c.r[0] == 0x2u;  // 0607EC1E cmp/eq #2,r0
L_0607EC20:
    if (!c.t) { goto L_0607ECE8; }  // 0607EC20 bf 0x0607ECE8
L_0607EC22:
    c.r[5] = 0x1u; goto L_0607EC28;  // 0607EC22 bra 0x0607EC28 ; mov #1,r5
L_0607EC26:
    c.r[5] = 0xFFFFFFFFu;  // 0607EC26 mov #-1,r5
L_0607EC28:
    c.r[6] = ld32(0x0607ED38u);  // 0607EC28 mov.l 0x0607ED38,r6
L_0607EC2A:
    c.r[7] = ld32(c.r[6]);  // 0607EC2A mov.l @r6,r7
L_0607EC2C:
    c.r[8] = c.r[7];  // 0607EC2C mov r7,r8
L_0607EC2E:
    c.r[8] -= 14;  // 0607EC2E add #-14,r8
L_0607EC30:
    c.r[9] = ld32(0x0607ED3Cu);  // 0607EC30 mov.l 0x0607ED3C,r9
L_0607EC32:
    c.r[0] = c.r[13];  // 0607EC32 mov r13,r0
L_0607EC34:
    st8(c.r[9] + 2, c.r[0]);  // 0607EC34 mov.b r0,@(2,r9)
L_0607EC36:
    c.r[10] = 0xEu;  // 0607EC36 mov #14,r10
L_0607EC38:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0607EC38 mov.b @r8+,r11
L_0607EC3A:
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[9]); c.r[9] += 1;  // 0607EC3A mov.b @r9+,r12
L_0607EC3C:
    c.t = c.r[12] == c.r[11];  // 0607EC3C cmp/eq r11,r12
L_0607EC3E:
    if (!c.t) { goto L_0607ECE8; }  // 0607EC3E bf 0x0607ECE8
L_0607EC40:
    c.r[10] -= 1; c.t = c.r[10] == 0;  // 0607EC40 dt r10
L_0607EC42:
    if (!c.t) { SH2_POLL(c); goto L_0607EC38; }  // 0607EC42 bf 0x0607EC38
L_0607EC44:
    c.r[0] = c.r[13];  // 0607EC44 mov r13,r0
L_0607EC46:
    c.t = c.r[0] == 0x58u;  // 0607EC46 cmp/eq #88,r0
L_0607EC48:
    if (!c.t) { goto L_0607EC50; }  // 0607EC48 bf 0x0607EC50
L_0607EC4A:
    c.r[0] = ld32(0x0607ED40u);  // 0607EC4A mov.l 0x0607ED40,r0
L_0607EC4C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0607EC4C jmp @r0 ; nop
L_0607EC50:
    c.r[1] = ld32(0x0607ED44u);  // 0607EC50 mov.l 0x0607ED44,r1
L_0607EC52:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EC52 mov.b @r1,r0
L_0607EC54:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EC54 extu.b r0,r0
L_0607EC56:
    c.r[13] = c.r[0];  // 0607EC56 mov r0,r13
L_0607EC58:
    c.r[1] = 0x5u;  // 0607EC58 mov #5,r1
L_0607EC5A:
    c.t = c.r[0] >= c.r[1];  // 0607EC5A cmp/hs r1,r0
L_0607EC5C:
    if (c.t) { goto L_0607ECE8; }  // 0607EC5C bt 0x0607ECE8
L_0607EC5E:
    c.r[0] = ld32(0x0607ED48u);  // 0607EC5E mov.l 0x0607ED48,r0
L_0607EC60:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EC64u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EC64u) return; }  // 0607EC60 jsr @r0 ; mov r13,r4
L_0607EC64:
    c.r[1] = ld32(0x0607ED4Cu);  // 0607EC64 mov.l 0x0607ED4C,r1
L_0607EC66:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EC66 mov.b @r1,r1
L_0607EC68:
    c.r[1] = c.r[1] & 0xFFu;  // 0607EC68 extu.b r1,r1
L_0607EC6A:
    c.r[1] -= c.r[0];  // 0607EC6A sub r0,r1
L_0607EC6C:
    c.r[10] = c.r[1];  // 0607EC6C mov r1,r10
L_0607EC6E:
    c.r[0] = ld32(0x0607ED50u);  // 0607EC6E mov.l 0x0607ED50,r0
L_0607EC70:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EC74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EC74u) return; }  // 0607EC70 jsr @r0 ; nop
L_0607EC74:
    c.r[12] = c.r[0];  // 0607EC74 mov r0,r12
L_0607EC76:
    c.r[14] = ld32(0x0607ED54u);  // 0607EC76 mov.l 0x0607ED54,r14
L_0607EC78:
    c.r[2] = c.r[14];  // 0607EC78 mov r14,r2
L_0607EC7A:
    c.r[2] += c.r[13];  // 0607EC7A add r13,r2
L_0607EC7C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EC7C mov.b @r2,r0
L_0607EC7E:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EC7E extu.b r0,r0
L_0607EC80:
    c.r[11] = 0x0u;  // 0607EC80 mov #0,r11
L_0607EC82:
    c.t = (c.r[12] & c.r[12]) == 0;  // 0607EC82 tst r12,r12
L_0607EC84:
    if (!c.t) { goto L_0607EC8A; }  // 0607EC84 bf 0x0607EC8A
L_0607EC86:
    c.r[0] = 0x1u;  // 0607EC86 mov #1,r0
L_0607EC88:
    c.r[11] = 0x1u;  // 0607EC88 mov #1,r11
L_0607EC8A:
    c.r[0] += c.r[5];  // 0607EC8A add r5,r0
L_0607EC8C:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[11];  // 0607EC8C cmp/ge r11,r0
L_0607EC8E:
    if (!c.t) { goto L_0607ECE4; }  // 0607EC8E bf 0x0607ECE4
L_0607EC90:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[10];  // 0607EC90 cmp/gt r10,r0
L_0607EC92:
    if (c.t) { goto L_0607ECE4; }  // 0607EC92 bt 0x0607ECE4
L_0607EC94:
    st8(c.r[2], c.r[0]);  // 0607EC94 mov.b r0,@r2
L_0607EC96:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607EC96 tst r0,r0
L_0607EC98:
    if (!c.t) { goto L_0607EC9C; }  // 0607EC98 bf 0x0607EC9C
L_0607EC9A:
    c.r[0] = 0x1u;  // 0607EC9A mov #1,r0
L_0607EC9C:
    c.r[1] = c.r[2];  // 0607EC9C mov r2,r1
L_0607EC9E:
    c.r[1] += 5;  // 0607EC9E add #5,r1
L_0607ECA0:
    st8(c.r[1], c.r[0]);  // 0607ECA0 mov.b r0,@r1
L_0607ECA2:
    c.r[0] = ld32(0x0607ED50u);  // 0607ECA2 mov.l 0x0607ED50,r0
L_0607ECA4:
    { const uint32_t x = c.r[0]; c.pr = 0x0607ECA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ECA8u) return; }  // 0607ECA4 jsr @r0 ; nop
L_0607ECA8:
    c.t = c.r[0] == 0x1u;  // 0607ECA8 cmp/eq #1,r0
L_0607ECAA:
    if (!c.t) { goto L_0607ECBE; }  // 0607ECAA bf 0x0607ECBE
L_0607ECAC:
    c.r[2] = ld32(0x0607ED44u);  // 0607ECAC mov.l 0x0607ED44,r2
L_0607ECAE:
    st8(c.r[2], c.r[1]);  // 0607ECAE mov.b r1,@r2
L_0607ECB0:
    c.r[2] = c.r[14];  // 0607ECB0 mov r14,r2
L_0607ECB2:
    c.r[2] += c.r[1];  // 0607ECB2 add r1,r2
L_0607ECB4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607ECB4 mov.b @r2,r0
L_0607ECB6:
    c.t = c.r[0] == 0x1u;  // 0607ECB6 cmp/eq #1,r0
L_0607ECB8:
    if (!c.t) { goto L_0607ECBE; }  // 0607ECB8 bf 0x0607ECBE
L_0607ECBA:
    c.r[0] = 0x0u;  // 0607ECBA mov #0,r0
L_0607ECBC:
    st8(c.r[2], c.r[0]);  // 0607ECBC mov.b r0,@r2
L_0607ECBE:
    c.r[1] = ld32(0x0607ED58u);  // 0607ECBE mov.l 0x0607ED58,r1
L_0607ECC0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607ECC0 mov.b @r1,r0
L_0607ECC2:
    c.t = (c.r[0] & 0x80u) == 0;  // 0607ECC2 tst #128,r0
L_0607ECC4:
    if (!c.t) { goto L_0607ECD2; }  // 0607ECC4 bf 0x0607ECD2
L_0607ECC6:
    c.r[1] = ld32(0x0607ED5Cu);  // 0607ECC6 mov.l 0x0607ED5C,r1
L_0607ECC8:
    c.r[0] = 0x0u;  // 0607ECC8 mov #0,r0
L_0607ECCA:
    st8(c.r[1], c.r[0]);  // 0607ECCA mov.b r0,@r1
L_0607ECCC:
    c.r[1] = ld32(0x0607ED60u);  // 0607ECCC mov.l 0x0607ED60,r1
L_0607ECCE:
    c.r[0] = 0x10u;  // 0607ECCE mov #16,r0
L_0607ECD0:
    st16(c.r[1], c.r[0]);  // 0607ECD0 mov.w r0,@r1
L_0607ECD2:
    c.pr = 0x0607ECD6u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECD6u) return;  // 0607ECD2 bsr 0x0607ECEE ; nop
L_0607ECD6:
    c.r[6] = ld32(0x0607ED38u);  // 0607ECD6 mov.l 0x0607ED38,r6
L_0607ECD8:
    c.r[7] = ld32(c.r[6]);  // 0607ECD8 mov.l @r6,r7
L_0607ECDA:
    c.r[7] -= 14;  // 0607ECDA add #-14,r7
L_0607ECDC:
    st32(c.r[6], c.r[7]);  // 0607ECDC mov.l r7,@r6
L_0607ECDE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607ED6Au);  // 0607ECDE mov.w 0x0607ED6A,r0
L_0607ECE0:
    goto L_0607EE54;  // 0607ECE0 bra 0x0607EE54 ; nop
L_0607ECE4:
    c.pr = 0x0607ECE8u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECE8u) return;  // 0607ECE4 bsr 0x0607ECEE ; nop
L_0607ECE8:
    c.r[0] = ld32(0x0607ED64u);  // 0607ECE8 mov.l 0x0607ED64,r0
L_0607ECEA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0607ECEA jmp @r0 ; nop
L_0607EE54:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EE54 lds.l @r15+,pr
L_0607EE56:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE56 mov.l @r15+,r14
L_0607EE58:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE58 mov.l @r15+,r13
L_0607EE5A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5A mov.l @r15+,r12
L_0607EE5C:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5C mov.l @r15+,r11
L_0607EE5E:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5E mov.l @r15+,r10
L_0607EE60:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE60 mov.l @r15+,r9
L_0607EE62:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EE62 rts ; mov.l @r15+,r8
L_0608431E:
    c.r[10] = c.r[5];  // 0608431E mov r5,r10
L_06084320:
    c.r[1] = ld32(0x06084394u);  // 06084320 mov.l 0x06084394,r1
L_06084322:
    c.r[4] = ld32(c.r[1]);  // 06084322 mov.l @r1,r4
L_06084324:
    c.r[1] = ld32(0x060843D0u);  // 06084324 mov.l 0x060843D0,r1
L_06084326:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084326 mov.b @r1,r5
L_06084328:
    c.r[5] = c.r[5] & 0xFFu;  // 06084328 extu.b r5,r5
L_0608432A:
    c.r[0] = ld32(0x06084390u);  // 0608432A mov.l 0x06084390,r0
L_0608432C:
    { const uint32_t x = c.r[0]; c.pr = 0x06084330u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084330u) return; }  // 0608432C jsr @r0 ; nop
L_06084330:
    c.r[1] = ld32(0x06084384u);  // 06084330 mov.l 0x06084384,r1
L_06084332:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084332 mov.b @r1,r1
L_06084334:
    c.r[1] = c.r[1] & 0xFFu;  // 06084334 extu.b r1,r1
L_06084336:
    c.r[1] -= c.r[0];  // 06084336 sub r0,r1
L_06084338:
    c.r[2] = ld32(0x0608439Cu);  // 06084338 mov.l 0x0608439C,r2
L_0608433A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 14);  // 0608433A mov.b @(14,r2),r0
L_0608433C:
    c.r[0] = c.r[0] & 0xFFu;  // 0608433C extu.b r0,r0
L_0608433E:
    c.r[0] += c.r[10];  // 0608433E add r10,r0
L_06084340:
    c.r[3] = 0x1u;  // 06084340 mov #1,r3
L_06084342:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06084342 cmp/ge r3,r0
L_06084344:
    if (!c.t) { goto L_06084362; }  // 06084344 bf 0x06084362
L_06084346:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06084346 cmp/gt r1,r0
L_06084348:
    if (c.t) { goto L_06084362; }  // 06084348 bt 0x06084362
L_0608434A:
    c.t = (int32_t)c.r[10] > 0;  // 0608434A cmp/pl r10
L_0608434C:
    if (!c.t) { goto L_0608435A; }  // 0608434C bf 0x0608435A
L_0608434E:
    c.r[3] = ld32(0x060843C4u);  // 0608434E mov.l 0x060843C4,r3
L_06084350:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06084350 mov.w @r3,r3
L_06084352:
    c.r[3] = c.r[3] & 0xFFFFu;  // 06084352 extu.w r3,r3
L_06084354:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060843E2u);  // 06084354 mov.w 0x060843E2,r4
L_06084356:
    c.t = c.r[3] > c.r[4];  // 06084356 cmp/hi r4,r3
L_06084358:
    if (c.t) { goto L_06084362; }  // 06084358 bt 0x06084362
L_0608435A:
    st8(c.r[2] + 14, c.r[0]);  // 0608435A mov.b r0,@(14,r2)
L_0608435C:
    c.r[0] = ld32(0x060843D4u);  // 0608435C mov.l 0x060843D4,r0
L_0608435E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0608435E jmp @r0 ; nop
L_06084362:
    c.r[0] = ld32(0x060843D8u);  // 06084362 mov.l 0x060843D8,r0
L_06084364:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 06084364 jmp @r0 ; nop
}

void f_0607ECBE(SH2Context& c) {
    ran[1762] = 1;
    c.r[1] = ld32(0x0607ED58u);  // 0607ECBE mov.l 0x0607ED58,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607ECC0 mov.b @r1,r0
    c.t = (c.r[0] & 0x80u) == 0;  // 0607ECC2 tst #128,r0
    if (!c.t) { goto L_0607ECD2; }  // 0607ECC4 bf 0x0607ECD2
    c.r[1] = ld32(0x0607ED5Cu);  // 0607ECC6 mov.l 0x0607ED5C,r1
    c.r[0] = 0x0u;  // 0607ECC8 mov #0,r0
    st8(c.r[1], c.r[0]);  // 0607ECCA mov.b r0,@r1
    c.r[1] = ld32(0x0607ED60u);  // 0607ECCC mov.l 0x0607ED60,r1
    c.r[0] = 0x10u;  // 0607ECCE mov #16,r0
    st16(c.r[1], c.r[0]);  // 0607ECD0 mov.w r0,@r1
L_0607ECD2:
    c.pr = 0x0607ECD6u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECD6u) return;  // 0607ECD2 bsr 0x0607ECEE ; nop
    c.r[6] = ld32(0x0607ED38u);  // 0607ECD6 mov.l 0x0607ED38,r6
    c.r[7] = ld32(c.r[6]);  // 0607ECD8 mov.l @r6,r7
    c.r[7] -= 14;  // 0607ECDA add #-14,r7
    st32(c.r[6], c.r[7]);  // 0607ECDC mov.l r7,@r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607ED6Au);  // 0607ECDE mov.w 0x0607ED6A,r0
    goto L_0607EE54;  // 0607ECE0 bra 0x0607EE54 ; nop
L_0607EE54:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EE54 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE56 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE58 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE60 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EE62 rts ; mov.l @r15+,r8
}

void f_0607ECE4(SH2Context& c) {
    ran[1763] = 1;
L_0607ECE4:
    c.pr = 0x0607ECE8u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECE8u) return;  // 0607ECE4 bsr 0x0607ECEE ; nop
L_0607ECE8:
    c.r[0] = ld32(0x0607ED64u);  // 0607ECE8 mov.l 0x0607ED64,r0
L_0607ECEA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; default: sh2_call(c, x); return; } }  // 0607ECEA jmp @r0 ; nop
}

void f_0607ECEE(SH2Context& c) {
    ran[1764] = 1;
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607ED68u);  // 0607ECEE mov.w 0x0607ED68,r1
    c.r[3] = ld32(0x0607ED30u);  // 0607ECF0 mov.l 0x0607ED30,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607ECF2 mov.w @r3,r0
    c.r[0] &= c.r[1];  // 0607ECF4 and r1,r0
    st16(c.r[3], c.r[0]);  // 0607ECF6 mov.w r0,@r3
    c.r[3] = ld32(0x0607ED34u);  // 0607ECF8 mov.l 0x0607ED34,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607ECFA mov.w @r3,r0
    c.r[0] &= c.r[1];  // 0607ECFC and r1,r0
    { const uint32_t x = c.pr; st16(c.r[3], c.r[0]); c.pc = x; return; }  // 0607ECFE rts ; mov.w r0,@r3
}

void f_0607ED6C(SH2Context& c) {
    ran[1765] = 1;
L_0607ED6C:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607ED6C mov.l r11,@-r15
L_0607ED6E:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607ED6E sts.l pr,@-r15
L_0607ED70:
    c.r[0] = ld32(0x0607EE84u);  // 0607ED70 mov.l 0x0607EE84,r0
L_0607ED72:
    { const uint32_t x = c.r[0]; c.pr = 0x0607ED76u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ED76u) return; }  // 0607ED72 jsr @r0 ; nop
L_0607ED76:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607ED76 tst r0,r0
L_0607ED78:
    if (c.t) { goto L_0607ED88; }  // 0607ED78 bt 0x0607ED88
L_0607ED7A:
    c.t = c.r[0] == 0x1u;  // 0607ED7A cmp/eq #1,r0
L_0607ED7C:
    if (!c.t) { goto L_0607ED92; }  // 0607ED7C bf 0x0607ED92
L_0607ED7E:
    c.r[2] = ld32(0x0607EE88u);  // 0607ED7E mov.l 0x0607EE88,r2
L_0607ED80:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607ED80 mov.b @r2,r0
L_0607ED82:
    c.r[3] = ld32(0x0607EE8Cu);  // 0607ED82 mov.l 0x0607EE8C,r3
L_0607ED84:
    st8(c.r[3] + 13, c.r[0]);  // 0607ED84 mov.b r0,@(13,r3)
L_0607ED86:
    st8(c.r[2], c.r[1]);  // 0607ED86 mov.b r1,@r2
L_0607ED88:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607ED88 lds.l @r15+,pr
L_0607ED8A:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607ED8A mov.l @r15+,r11
L_0607ED8C:
    c.r[0] = ld32(0x0607EE90u);  // 0607ED8C mov.l 0x0607EE90,r0
L_0607ED8E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0607ED6Cu: goto L_0607ED6C; case 0x0607ED6Eu: goto L_0607ED6E; case 0x0607ED70u: goto L_0607ED70; case 0x0607ED72u: goto L_0607ED72; case 0x0607ED76u: goto L_0607ED76; case 0x0607ED78u: goto L_0607ED78; case 0x0607ED7Au: goto L_0607ED7A; case 0x0607ED7Cu: goto L_0607ED7C; case 0x0607ED7Eu: goto L_0607ED7E; case 0x0607ED80u: goto L_0607ED80; case 0x0607ED82u: goto L_0607ED82; case 0x0607ED84u: goto L_0607ED84; case 0x0607ED86u: goto L_0607ED86; case 0x0607ED88u: goto L_0607ED88; case 0x0607ED8Au: goto L_0607ED8A; case 0x0607ED8Cu: goto L_0607ED8C; case 0x0607ED8Eu: goto L_0607ED8E; case 0x0607ED92u: goto L_0607ED92; case 0x0607ED94u: goto L_0607ED94; case 0x0607ED98u: goto L_0607ED98; case 0x0607ED9Au: goto L_0607ED9A; case 0x0607ED9Cu: goto L_0607ED9C; case 0x0607EDA0u: goto L_0607EDA0; case 0x0607EDA2u: goto L_0607EDA2; case 0x0607EDA4u: goto L_0607EDA4; case 0x0607EDA6u: goto L_0607EDA6; case 0x0607EDA8u: goto L_0607EDA8; case 0x0607EDAAu: goto L_0607EDAA; case 0x0607EDACu: goto L_0607EDAC; case 0x0607EDAEu: goto L_0607EDAE; case 0x0607EDB0u: goto L_0607EDB0; case 0x0607EDB2u: goto L_0607EDB2; case 0x0607EDB4u: goto L_0607EDB4; case 0x0607EDB6u: goto L_0607EDB6; case 0x0607EDB8u: goto L_0607EDB8; case 0x0607EDBAu: goto L_0607EDBA; case 0x0607EDBCu: goto L_0607EDBC; case 0x0607EEC4u: goto L_0607EEC4; case 0x0607EEC6u: goto L_0607EEC6; case 0x0607EEC8u: goto L_0607EEC8; case 0x0607EECAu: goto L_0607EECA; case 0x0607EECCu: goto L_0607EECC; case 0x0607EECEu: goto L_0607EECE; case 0x0607EED0u: goto L_0607EED0; case 0x0607EED2u: goto L_0607EED2; case 0x0607EED4u: goto L_0607EED4; case 0x0607EED6u: goto L_0607EED6; case 0x0607EED8u: goto L_0607EED8; case 0x0607EEDAu: goto L_0607EEDA; case 0x0607EEDCu: goto L_0607EEDC; case 0x0607EEDEu: goto L_0607EEDE; case 0x0607EEE0u: goto L_0607EEE0; case 0x0607EEE2u: goto L_0607EEE2; case 0x0607EEE4u: goto L_0607EEE4; case 0x0607EEE6u: goto L_0607EEE6; case 0x0607EEE8u: goto L_0607EEE8; case 0x0607EEEAu: goto L_0607EEEA; case 0x0607EEECu: goto L_0607EEEC; case 0x0607EEEEu: goto L_0607EEEE; case 0x0607EEF0u: goto L_0607EEF0; case 0x0607EEF2u: goto L_0607EEF2; case 0x0607EEF4u: goto L_0607EEF4; case 0x0607EEF6u: goto L_0607EEF6; case 0x0607EEF8u: goto L_0607EEF8; case 0x0607EEFCu: goto L_0607EEFC; case 0x0607EEFEu: goto L_0607EEFE; case 0x0607EF00u: goto L_0607EF00; case 0x0607EF04u: goto L_0607EF04; case 0x0607EF06u: goto L_0607EF06; case 0x0607EF0Au: goto L_0607EF0A; case 0x0607EF0Cu: goto L_0607EF0C; case 0x0607EF0Eu: goto L_0607EF0E; case 0x0607EF10u: goto L_0607EF10; case 0x0607EF12u: goto L_0607EF12; case 0x0607EF14u: goto L_0607EF14; case 0x0607EF16u: goto L_0607EF16; case 0x0607EF18u: goto L_0607EF18; case 0x0607EF1Au: goto L_0607EF1A; case 0x0607EF1Cu: goto L_0607EF1C; case 0x0607EF1Eu: goto L_0607EF1E; case 0x0607EF20u: goto L_0607EF20; case 0x0607EF22u: goto L_0607EF22; case 0x0607EF24u: goto L_0607EF24; case 0x0607EF26u: goto L_0607EF26; case 0x0607EF2Au: goto L_0607EF2A; case 0x0607EF2Cu: goto L_0607EF2C; case 0x0607EF2Eu: goto L_0607EF2E; default: sh2_call(c, x); return; } }  // 0607ED8E jmp @r0 ; nop
L_0607ED92:
    c.r[0] = ld32(0x0607EE94u);  // 0607ED92 mov.l 0x0607EE94,r0
L_0607ED94:
    { const uint32_t x = c.r[0]; c.pr = 0x0607ED98u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ED98u) return; }  // 0607ED94 jsr @r0 ; nop
L_0607ED98:
    c.r[11] = c.r[0];  // 0607ED98 mov r0,r11
L_0607ED9A:
    c.r[0] = ld32(0x0607EE98u);  // 0607ED9A mov.l 0x0607EE98,r0
L_0607ED9C:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EDA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EDA0u) return; }  // 0607ED9C jsr @r0 ; nop
L_0607EDA0:
    c.r[1] = ld32(0x0607EE9Cu);  // 0607EDA0 mov.l 0x0607EE9C,r1
L_0607EDA2:
    c.r[1] = ld32(c.r[1]);  // 0607EDA2 mov.l @r1,r1
L_0607EDA4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 10);  // 0607EDA4 mov.w @(10,r1),r0
L_0607EDA6:
    c.r[2] = c.r[0] & 0xFFFFu;  // 0607EDA6 extu.w r0,r2
L_0607EDA8:
    c.r[2] <<= 8;  // 0607EDA8 shll8 r2
L_0607EDAA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 12);  // 0607EDAA mov.b @(12,r1),r0
L_0607EDAC:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EDAC extu.b r0,r0
L_0607EDAE:
    c.r[2] |= c.r[0];  // 0607EDAE or r0,r2
L_0607EDB0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EEC0u);  // 0607EDB0 mov.w 0x0607EEC0,r0
L_0607EDB2:
    c.t = c.r[6] > c.r[2];  // 0607EDB2 cmp/hi r2,r6
L_0607EDB4:
    if (!c.t) { goto L_0607EDB8; }  // 0607EDB4 bf 0x0607EDB8
L_0607EDB6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EEC2u);  // 0607EDB6 mov.w 0x0607EEC2,r0
L_0607EDB8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EDB8 lds.l @r15+,pr
L_0607EDBA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EDBA mov.l @r15+,r11
L_0607EDBC:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0607EDBC rts ; nop
L_0607EEC4:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EEC4 mov.l r14,@-r15
L_0607EEC6:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EEC6 sts.l pr,@-r15
L_0607EEC8:
    c.r[1] = ld32(0x0607EF38u);  // 0607EEC8 mov.l 0x0607EF38,r1
L_0607EECA:
    c.r[2] = ld32(c.r[1]);  // 0607EECA mov.l @r1,r2
L_0607EECC:
    c.r[14] = c.r[15];  // 0607EECC mov r15,r14
L_0607EECE:
    c.r[1] = ld32(0x0607EF3Cu);  // 0607EECE mov.l 0x0607EF3C,r1
L_0607EED0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EED0 mov.b @r1,r1
L_0607EED2:
    c.r[0] = c.r[2];  // 0607EED2 mov r2,r0
L_0607EED4:
    c.r[1] = c.r[1] & 0xFFu;  // 0607EED4 extu.b r1,r1
L_0607EED6:
    c.r[1] += c.r[1];  // 0607EED6 add r1,r1
L_0607EED8:
    c.r[2] += c.r[1];  // 0607EED8 add r1,r2
L_0607EEDA:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607EEDA mov.b @(r0,r1),r3
L_0607EEDC:
    c.r[2] += 1;  // 0607EEDC add #1,r2
L_0607EEDE:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EEDE mov.b @r2,r4
L_0607EEE0:
    c.r[0] = 0x7Fu;  // 0607EEE0 mov #127,r0
L_0607EEE2:
    c.r[3] &= c.r[0];  // 0607EEE2 and r0,r3
L_0607EEE4:
    c.r[3] <<= 8;  // 0607EEE4 shll8 r3
L_0607EEE6:
    c.r[1] = ld32(0x0607EF40u);  // 0607EEE6 mov.l 0x0607EF40,r1
L_0607EEE8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EEE8 mov.b @r1,r1
L_0607EEEA:
    c.r[4] = c.r[4] & 0xFFu;  // 0607EEEA extu.b r4,r4
L_0607EEEC:
    c.r[2] = c.r[1] & 0xFFu;  // 0607EEEC extu.b r1,r2
L_0607EEEE:
    c.r[1] = ld32(0x0607EF44u);  // 0607EEEE mov.l 0x0607EF44,r1
L_0607EEF0:
    c.r[0] = c.r[2];  // 0607EEF0 mov r2,r0
L_0607EEF2:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607EEF2 mov.b @(r0,r1),r5
L_0607EEF4:
    c.r[4] |= c.r[3];  // 0607EEF4 or r3,r4
L_0607EEF6:
    c.r[0] = ld32(0x0607EF48u);  // 0607EEF6 mov.l 0x0607EF48,r0
L_0607EEF8:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EEFCu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EEFCu) return; }  // 0607EEF8 jsr @r0 ; extu.b r5,r5
L_0607EEFC:
    c.r[7] = c.r[0];  // 0607EEFC mov r0,r7
L_0607EEFE:
    c.t = (c.r[7] & c.r[7]) == 0;  // 0607EEFE tst r7,r7
L_0607EF00:
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0607EF0A; } }  // 0607EF00 bf/s 0x0607EF0A ; mov r14,r15
L_0607EF04:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF32u);  // 0607EF04 mov.w 0x0607EF32,r0
L_0607EF06:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607EF2E;  // 0607EF06 bra 0x0607EF2E ; lds.l @r15+,pr
L_0607EF0A:
    c.r[1] = ld32(0x0607EF4Cu);  // 0607EF0A mov.l 0x0607EF4C,r1
L_0607EF0C:
    c.r[3] = ld32(c.r[1]);  // 0607EF0C mov.l @r1,r3
L_0607EF0E:
    c.r[1] = c.r[3];  // 0607EF0E mov r3,r1
L_0607EF10:
    c.r[1] += 10;  // 0607EF10 add #10,r1
L_0607EF12:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607EF12 mov.w @r1,r2
L_0607EF14:
    c.r[3] += 12;  // 0607EF14 add #12,r3
L_0607EF16:
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607EF16 extu.w r2,r2
L_0607EF18:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607EF18 mov.b @r3,r1
L_0607EF1A:
    c.r[2] <<= 8;  // 0607EF1A shll8 r2
L_0607EF1C:
    c.r[1] = c.r[1] & 0xFFu;  // 0607EF1C extu.b r1,r1
L_0607EF1E:
    c.r[1] |= c.r[2];  // 0607EF1E or r2,r1
L_0607EF20:
    c.t = c.r[7] > c.r[1];  // 0607EF20 cmp/hi r1,r7
L_0607EF22:
    if (!c.t) { goto L_0607EF2A; }  // 0607EF22 bf 0x0607EF2A
L_0607EF24:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF34u);  // 0607EF24 mov.w 0x0607EF34,r0
L_0607EF26:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607EF2E;  // 0607EF26 bra 0x0607EF2E ; lds.l @r15+,pr
L_0607EF2A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF36u);  // 0607EF2A mov.w 0x0607EF36,r0
L_0607EF2C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EF2C lds.l @r15+,pr
L_0607EF2E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EF2E rts ; mov.l @r15+,r14
}

void f_0607EDC0(SH2Context& c) {
    ran[1766] = 1;
L_0607EDC0:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EDC0 sts.l pr,@-r15
L_0607EDC2:
    c.r[0] = ld32(0x0607EE84u);  // 0607EDC2 mov.l 0x0607EE84,r0
L_0607EDC4:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EDC8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EDC8u) return; }  // 0607EDC4 jsr @r0 ; nop
L_0607EDC8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EDC8 lds.l @r15+,pr
L_0607EDCA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607EDCA tst r0,r0
L_0607EDCC:
    if (!c.t) { goto L_0607EDD4; }  // 0607EDCC bf 0x0607EDD4
L_0607EDCE:
    c.r[0] = ld32(0x0607EEA0u);  // 0607EDCE mov.l 0x0607EEA0,r0
L_0607EDD0:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0607EDC0u: goto L_0607EDC0; case 0x0607EDC2u: goto L_0607EDC2; case 0x0607EDC4u: goto L_0607EDC4; case 0x0607EDC8u: goto L_0607EDC8; case 0x0607EDCAu: goto L_0607EDCA; case 0x0607EDCCu: goto L_0607EDCC; case 0x0607EDCEu: goto L_0607EDCE; case 0x0607EDD0u: goto L_0607EDD0; case 0x0607EDD4u: goto L_0607EDD4; case 0x0607EDD6u: goto L_0607EDD6; case 0x0607EDD8u: goto L_0607EDD8; case 0x0607EDDAu: goto L_0607EDDA; case 0x0607EDDCu: goto L_0607EDDC; case 0x0607EDDEu: goto L_0607EDDE; case 0x0607EDE0u: goto L_0607EDE0; case 0x0607EDE2u: goto L_0607EDE2; case 0x0607EDE4u: goto L_0607EDE4; case 0x0607EDE6u: goto L_0607EDE6; case 0x0607EDE8u: goto L_0607EDE8; case 0x0607EDEAu: goto L_0607EDEA; case 0x0607EDECu: goto L_0607EDEC; case 0x0607EDEEu: goto L_0607EDEE; case 0x0607EDF0u: goto L_0607EDF0; case 0x0607EDF2u: goto L_0607EDF2; case 0x0607EDF4u: goto L_0607EDF4; case 0x0607EDF6u: goto L_0607EDF6; case 0x0607EDF8u: goto L_0607EDF8; case 0x0607EDFAu: goto L_0607EDFA; case 0x0607EDFCu: goto L_0607EDFC; case 0x0607EDFEu: goto L_0607EDFE; case 0x0607EE02u: goto L_0607EE02; case 0x0607EE04u: goto L_0607EE04; case 0x0607EE06u: goto L_0607EE06; case 0x0607EE08u: goto L_0607EE08; case 0x0607EE0Au: goto L_0607EE0A; case 0x0607EE0Cu: goto L_0607EE0C; case 0x0607EE0Eu: goto L_0607EE0E; case 0x0607EE12u: goto L_0607EE12; case 0x0607EE14u: goto L_0607EE14; case 0x0607EE16u: goto L_0607EE16; case 0x0607EE1Au: goto L_0607EE1A; case 0x0607EE1Cu: goto L_0607EE1C; case 0x0607EE1Eu: goto L_0607EE1E; case 0x0607EE22u: goto L_0607EE22; case 0x0607EE24u: goto L_0607EE24; case 0x0607EE26u: goto L_0607EE26; case 0x0607EE28u: goto L_0607EE28; case 0x0607EE2Au: goto L_0607EE2A; case 0x0607EE2Cu: goto L_0607EE2C; case 0x0607EE2Eu: goto L_0607EE2E; case 0x0607EE30u: goto L_0607EE30; case 0x0607EE32u: goto L_0607EE32; case 0x0607EE34u: goto L_0607EE34; case 0x0607EE36u: goto L_0607EE36; case 0x0607EE38u: goto L_0607EE38; case 0x0607EE3Au: goto L_0607EE3A; case 0x0607EE3Cu: goto L_0607EE3C; case 0x0607EE3Eu: goto L_0607EE3E; case 0x0607EE40u: goto L_0607EE40; case 0x0607EE42u: goto L_0607EE42; case 0x0607EE46u: goto L_0607EE46; case 0x0607EE48u: goto L_0607EE48; case 0x0607EE4Au: goto L_0607EE4A; case 0x0607EE4Cu: goto L_0607EE4C; case 0x0607EE4Eu: goto L_0607EE4E; case 0x0607EE50u: goto L_0607EE50; case 0x0607EE52u: goto L_0607EE52; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; default: sh2_call(c, x); return; } }  // 0607EDD0 jmp @r0 ; nop
L_0607EDD4:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607EDD4 mov.l r8,@-r15
L_0607EDD6:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607EDD6 mov.l r9,@-r15
L_0607EDD8:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607EDD8 mov.l r10,@-r15
L_0607EDDA:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607EDDA mov.l r11,@-r15
L_0607EDDC:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607EDDC mov.l r12,@-r15
L_0607EDDE:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607EDDE mov.l r13,@-r15
L_0607EDE0:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EDE0 mov.l r14,@-r15
L_0607EDE2:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EDE2 sts.l pr,@-r15
L_0607EDE4:
    c.r[8] = ld32(0x0607EE88u);  // 0607EDE4 mov.l 0x0607EE88,r8
L_0607EDE6:
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607EDE6 mov.b @r8,r9
L_0607EDE8:
    c.r[10] = ld32(0x0607EEA4u);  // 0607EDE8 mov.l 0x0607EEA4,r10
L_0607EDEA:
    c.r[11] = ld32(c.r[10]);  // 0607EDEA mov.l @r10,r11
L_0607EDEC:
    c.r[12] = (uint32_t)(int16_t)ld16(0x0607EEC2u);  // 0607EDEC mov.w 0x0607EEC2,r12
L_0607EDEE:
    c.r[13] = 0x0u;  // 0607EDEE mov #0,r13
L_0607EDF0:
    c.r[14] = ld32(0x0607EE8Cu);  // 0607EDF0 mov.l 0x0607EE8C,r14
L_0607EDF2:
    c.r[0] = c.r[14];  // 0607EDF2 mov r14,r0
L_0607EDF4:
    c.r[0] += c.r[13];  // 0607EDF4 add r13,r0
L_0607EDF6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0607EDF6 mov.b @r0,r0
L_0607EDF8:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607EDF8 tst r0,r0
L_0607EDFA:
    if (c.t) { goto L_0607EE48; }  // 0607EDFA bt 0x0607EE48
L_0607EDFC:
    c.r[0] = ld32(0x0607EEA8u);  // 0607EDFC mov.l 0x0607EEA8,r0
L_0607EDFE:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EE02u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EE02u) return; }  // 0607EDFE jsr @r0 ; mov r13,r4
L_0607EE02:
    c.r[1] = c.r[14];  // 0607EE02 mov r14,r1
L_0607EE04:
    c.r[1] += c.r[13];  // 0607EE04 add r13,r1
L_0607EE06:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EE06 mov.b @r1,r5
L_0607EE08:
    c.r[5] = c.r[5] & 0xFFu;  // 0607EE08 extu.b r5,r5
L_0607EE0A:
    c.r[5] += c.r[0];  // 0607EE0A add r0,r5
L_0607EE0C:
    c.r[0] = ld32(0x0607EE94u);  // 0607EE0C mov.l 0x0607EE94,r0
L_0607EE0E:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EE12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EE12u) return; }  // 0607EE0E jsr @r0 ; nop
L_0607EE12:
    c.r[6] = c.r[0];  // 0607EE12 mov r0,r6
L_0607EE14:
    c.r[0] = ld32(0x0607EEACu);  // 0607EE14 mov.l 0x0607EEAC,r0
L_0607EE16:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EE1Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EE1Au) return; }  // 0607EE16 jsr @r0 ; mov r13,r4
L_0607EE1A:
    st8(c.r[8], c.r[13]);  // 0607EE1A mov.b r13,@r8
L_0607EE1C:
    c.r[0] = ld32(0x0607EEA0u);  // 0607EE1C mov.l 0x0607EEA0,r0
L_0607EE1E:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EE22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EE22u) return; }  // 0607EE1E jsr @r0 ; nop
L_0607EE22:
    c.r[0] = c.r[0] & 0xFFFFu;  // 0607EE22 extu.w r0,r0
L_0607EE24:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607EEC0u);  // 0607EE24 mov.w 0x0607EEC0,r1
L_0607EE26:
    c.t = c.r[0] == c.r[1];  // 0607EE26 cmp/eq r1,r0
L_0607EE28:
    if (!c.t) { goto L_0607EE2C; }  // 0607EE28 bf 0x0607EE2C
L_0607EE2A:
    c.r[12] = c.r[1];  // 0607EE2A mov r1,r12
L_0607EE2C:
    c.r[1] = c.r[14];  // 0607EE2C mov r14,r1
L_0607EE2E:
    c.r[1] += c.r[13];  // 0607EE2E add r13,r1
L_0607EE30:
    c.r[0] = 0x0u;  // 0607EE30 mov #0,r0
L_0607EE32:
    st8(c.r[1], c.r[0]);  // 0607EE32 mov.b r0,@r1
L_0607EE34:
    c.r[1] += 5;  // 0607EE34 add #5,r1
L_0607EE36:
    c.r[0] = 0x1u;  // 0607EE36 mov #1,r0
L_0607EE38:
    st8(c.r[1], c.r[0]);  // 0607EE38 mov.b r0,@r1
L_0607EE3A:
    c.r[0] = 0x0607EE68u;  // 0607EE3A mova 0x0607EE68,r0
L_0607EE3C:
    c.r[0] -= 1;  // 0607EE3C add #-1,r0
L_0607EE3E:
    st32(c.r[10], c.r[0]);  // 0607EE3E mov.l r0,@r10
L_0607EE40:
    c.r[0] = ld32(0x0607EEB0u);  // 0607EE40 mov.l 0x0607EEB0,r0
L_0607EE42:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EE46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EE46u) return; }  // 0607EE42 jsr @r0 ; nop
L_0607EE46:
    st32(c.r[10], c.r[11]);  // 0607EE46 mov.l r11,@r10
L_0607EE48:
    c.r[13] += 1;  // 0607EE48 add #1,r13
L_0607EE4A:
    c.r[0] = 0x5u;  // 0607EE4A mov #5,r0
L_0607EE4C:
    c.t = c.r[13] >= c.r[0];  // 0607EE4C cmp/hs r0,r13
L_0607EE4E:
    if (!c.t) { SH2_POLL(c); goto L_0607EDF2; }  // 0607EE4E bf 0x0607EDF2
L_0607EE50:
    st8(c.r[8], c.r[9]);  // 0607EE50 mov.b r9,@r8
L_0607EE52:
    c.r[0] = c.r[12];  // 0607EE52 mov r12,r0
L_0607EE54:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EE54 lds.l @r15+,pr
L_0607EE56:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE56 mov.l @r15+,r14
L_0607EE58:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE58 mov.l @r15+,r13
L_0607EE5A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5A mov.l @r15+,r12
L_0607EE5C:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5C mov.l @r15+,r11
L_0607EE5E:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5E mov.l @r15+,r10
L_0607EE60:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE60 mov.l @r15+,r9
L_0607EE62:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EE62 rts ; mov.l @r15+,r8
}

void f_0607EE6C(SH2Context& c) {
    ran[1767] = 1;
L_0607EE6C:
    c.r[1] = ld32(0x0607EE8Cu);  // 0607EE6C mov.l 0x0607EE8C,r1
L_0607EE6E:
    c.r[0] = 0x1u;  // 0607EE6E mov #1,r0
L_0607EE70:
    st8(c.r[1] + 14, c.r[0]);  // 0607EE70 mov.b r0,@(14,r1)
L_0607EE72:
    c.r[1] = ld32(0x0607EEB4u);  // 0607EE72 mov.l 0x0607EEB4,r1
L_0607EE74:
    c.r[0] = 0xFFFFFFFFu;  // 0607EE74 mov #-1,r0
L_0607EE76:
    st16(c.r[1], c.r[0]);  // 0607EE76 mov.w r0,@r1
L_0607EE78:
    c.r[1] = ld32(0x0607EEB8u);  // 0607EE78 mov.l 0x0607EEB8,r1
L_0607EE7A:
    c.r[0] = 0x0u;  // 0607EE7A mov #0,r0
L_0607EE7C:
    st8(c.r[1], c.r[0]);  // 0607EE7C mov.b r0,@r1
L_0607EE7E:
    c.r[0] = ld32(0x0607EEBCu);  // 0607EE7E mov.l 0x0607EEBC,r0
L_0607EE80:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0607EE6Cu: goto L_0607EE6C; case 0x0607EE6Eu: goto L_0607EE6E; case 0x0607EE70u: goto L_0607EE70; case 0x0607EE72u: goto L_0607EE72; case 0x0607EE74u: goto L_0607EE74; case 0x0607EE76u: goto L_0607EE76; case 0x0607EE78u: goto L_0607EE78; case 0x0607EE7Au: goto L_0607EE7A; case 0x0607EE7Cu: goto L_0607EE7C; case 0x0607EE7Eu: goto L_0607EE7E; case 0x0607EE80u: goto L_0607EE80; case 0x0607FD48u: goto L_0607FD48; case 0x0607FD4Au: goto L_0607FD4A; case 0x0607FD4Cu: goto L_0607FD4C; case 0x0607FD4Eu: goto L_0607FD4E; case 0x0607FD50u: goto L_0607FD50; case 0x0607FD52u: goto L_0607FD52; case 0x0607FD54u: goto L_0607FD54; case 0x0607FD56u: goto L_0607FD56; case 0x0607FD58u: goto L_0607FD58; case 0x0607FD5Au: goto L_0607FD5A; case 0x0607FD5Cu: goto L_0607FD5C; case 0x0607FD5Eu: goto L_0607FD5E; case 0x0607FD60u: goto L_0607FD60; case 0x0607FD62u: goto L_0607FD62; case 0x0607FD64u: goto L_0607FD64; case 0x0607FD66u: goto L_0607FD66; case 0x0607FD68u: goto L_0607FD68; case 0x0607FD6Au: goto L_0607FD6A; case 0x0607FD6Cu: goto L_0607FD6C; case 0x0607FD6Eu: goto L_0607FD6E; case 0x0607FD72u: goto L_0607FD72; case 0x0607FD74u: goto L_0607FD74; case 0x0607FD78u: goto L_0607FD78; case 0x0607FD7Au: goto L_0607FD7A; case 0x0607FD7Cu: goto L_0607FD7C; case 0x0607FD7Eu: goto L_0607FD7E; case 0x0607FD80u: goto L_0607FD80; case 0x0607FD82u: goto L_0607FD82; case 0x0607FD84u: goto L_0607FD84; case 0x0607FD88u: goto L_0607FD88; case 0x0607FD8Au: goto L_0607FD8A; case 0x0607FD8Eu: goto L_0607FD8E; case 0x0607FD90u: goto L_0607FD90; case 0x0607FD94u: goto L_0607FD94; case 0x0607FD96u: goto L_0607FD96; case 0x0607FD98u: goto L_0607FD98; case 0x0607FD9Au: goto L_0607FD9A; case 0x0607FD9Cu: goto L_0607FD9C; case 0x0607FDA0u: goto L_0607FDA0; case 0x0607FDA2u: goto L_0607FDA2; case 0x0607FDA4u: goto L_0607FDA4; case 0x0607FDA6u: goto L_0607FDA6; case 0x0607FDA8u: goto L_0607FDA8; case 0x0607FDAAu: goto L_0607FDAA; case 0x0607FDACu: goto L_0607FDAC; case 0x0607FDB0u: goto L_0607FDB0; case 0x0607FDB2u: goto L_0607FDB2; case 0x0607FDB4u: goto L_0607FDB4; case 0x0607FDB6u: goto L_0607FDB6; case 0x0607FDB8u: goto L_0607FDB8; case 0x0607FDBAu: goto L_0607FDBA; default: sh2_call(c, x); return; } }  // 0607EE80 jmp @r0 ; nop
L_0607FD48:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607FD48 mov.l r8,@-r15
L_0607FD4A:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607FD4A mov.l r9,@-r15
L_0607FD4C:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FD4C mov.l r14,@-r15
L_0607FD4E:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607FD4E sts.l pr,@-r15
L_0607FD50:
    c.r[8] = ld32(0x0607FDC8u);  // 0607FD50 mov.l 0x0607FDC8,r8
L_0607FD52:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FD52 mov.b @r8,r1
L_0607FD54:
    c.r[9] = ld32(0x0607FDCCu);  // 0607FD54 mov.l 0x0607FDCC,r9
L_0607FD56:
    c.r[4] = ld32(c.r[9]);  // 0607FD56 mov.l @r9,r4
L_0607FD58:
    c.r[5] = c.r[1] & 0xFFu;  // 0607FD58 extu.b r1,r5
L_0607FD5A:
    c.r[1] = c.r[5];  // 0607FD5A mov r5,r1
L_0607FD5C:
    c.r[1] <<= 2;  // 0607FD5C shll2 r1
L_0607FD5E:
    c.r[1] += c.r[5];  // 0607FD5E add r5,r1
L_0607FD60:
    c.r[1] <<= 2;  // 0607FD60 shll2 r1
L_0607FD62:
    c.r[1] += c.r[4];  // 0607FD62 add r4,r1
L_0607FD64:
    c.r[1] += 48;  // 0607FD64 add #48,r1
L_0607FD66:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607FD66 mov.w @r1,r1
L_0607FD68:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607FDBEu);  // 0607FD68 mov.w 0x0607FDBE,r2
L_0607FD6A:
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FD6A extu.w r1,r1
L_0607FD6C:
    c.t = c.r[1] > c.r[2];  // 0607FD6C cmp/hi r2,r1
L_0607FD6E:
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607FDB0; } }  // 0607FD6E bt/s 0x0607FDB0 ; mov r15,r14
L_0607FD72:
    c.r[0] = ld32(0x0607FDD0u);  // 0607FD72 mov.l 0x0607FDD0,r0
L_0607FD74:
    { const uint32_t x = c.r[0]; c.pr = 0x0607FD78u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FD78u) return; }  // 0607FD74 jsr @r0 ; nop
L_0607FD78:
    c.r[1] = c.r[0] & 0xFFu;  // 0607FD78 extu.b r0,r1
L_0607FD7A:
    c.r[3] = c.r[1];  // 0607FD7A mov r1,r3
L_0607FD7C:
    c.r[1] = ld32(0x0607FDD4u);  // 0607FD7C mov.l 0x0607FDD4,r1
L_0607FD7E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FD7E mov.b @r1,r1
L_0607FD80:
    c.r[2] = c.r[1] & 0xFFu;  // 0607FD80 extu.b r1,r2
L_0607FD82:
    c.t = c.r[3] >= c.r[2];  // 0607FD82 cmp/hs r2,r3
L_0607FD84:
    { const bool k = c.t; c.r[1] = 0x9u; if (k) { goto L_0607FD8E; } }  // 0607FD84 bt/s 0x0607FD8E ; mov #9,r1
L_0607FD88:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FDC0u);  // 0607FD88 mov.w 0x0607FDC0,r0
L_0607FD8A:
    c.r[15] = c.r[14]; goto L_0607FDB4;  // 0607FD8A bra 0x0607FDB4 ; mov r14,r15
L_0607FD8E:
    c.t = c.r[2] > c.r[1];  // 0607FD8E cmp/hi r1,r2
L_0607FD90:
    { const bool k = !c.t; c.t = c.r[3] == c.r[2]; if (k) { goto L_0607FDB0; } }  // 0607FD90 bf/s 0x0607FDB0 ; cmp/eq r2,r3
L_0607FD94:
    if (!c.t) { goto L_0607FDB0; }  // 0607FD94 bf 0x0607FDB0
L_0607FD96:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FD96 mov.b @r8,r5
L_0607FD98:
    c.r[0] = ld32(0x0607FDD8u);  // 0607FD98 mov.l 0x0607FDD8,r0
L_0607FD9A:
    c.r[4] = ld32(c.r[9]);  // 0607FD9A mov.l @r9,r4
L_0607FD9C:
    { const uint32_t x = c.r[0]; c.pr = 0x0607FDA0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FDA0u) return; }  // 0607FD9C jsr @r0 ; extu.b r5,r5
L_0607FDA0:
    c.r[2] = c.r[0] & 0xFFu;  // 0607FDA0 extu.b r0,r2
L_0607FDA2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607FDC2u);  // 0607FDA2 mov.w 0x0607FDC2,r1
L_0607FDA4:
    c.t = c.r[2] == c.r[1];  // 0607FDA4 cmp/eq r1,r2
L_0607FDA6:
    if (c.t) { goto L_0607FDB0; }  // 0607FDA6 bt 0x0607FDB0
L_0607FDA8:
    c.r[15] = c.r[14];  // 0607FDA8 mov r14,r15
L_0607FDAA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FDC4u);  // 0607FDAA mov.w 0x0607FDC4,r0
L_0607FDAC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607FDB6;  // 0607FDAC bra 0x0607FDB6 ; lds.l @r15+,pr
L_0607FDB0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FDC6u);  // 0607FDB0 mov.w 0x0607FDC6,r0
L_0607FDB2:
    c.r[15] = c.r[14];  // 0607FDB2 mov r14,r15
L_0607FDB4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607FDB4 lds.l @r15+,pr
L_0607FDB6:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607FDB6 mov.l @r15+,r14
L_0607FDB8:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607FDB8 mov.l @r15+,r9
L_0607FDBA:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FDBA rts ; mov.l @r15+,r8
}

void f_0607EEC4(SH2Context& c) {
    ran[1768] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EEC4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EEC6 sts.l pr,@-r15
    c.r[1] = ld32(0x0607EF38u);  // 0607EEC8 mov.l 0x0607EF38,r1
    c.r[2] = ld32(c.r[1]);  // 0607EECA mov.l @r1,r2
    c.r[14] = c.r[15];  // 0607EECC mov r15,r14
    c.r[1] = ld32(0x0607EF3Cu);  // 0607EECE mov.l 0x0607EF3C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EED0 mov.b @r1,r1
    c.r[0] = c.r[2];  // 0607EED2 mov r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607EED4 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607EED6 add r1,r1
    c.r[2] += c.r[1];  // 0607EED8 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607EEDA mov.b @(r0,r1),r3
    c.r[2] += 1;  // 0607EEDC add #1,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EEDE mov.b @r2,r4
    c.r[0] = 0x7Fu;  // 0607EEE0 mov #127,r0
    c.r[3] &= c.r[0];  // 0607EEE2 and r0,r3
    c.r[3] <<= 8;  // 0607EEE4 shll8 r3
    c.r[1] = ld32(0x0607EF40u);  // 0607EEE6 mov.l 0x0607EF40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EEE8 mov.b @r1,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0607EEEA extu.b r4,r4
    c.r[2] = c.r[1] & 0xFFu;  // 0607EEEC extu.b r1,r2
    c.r[1] = ld32(0x0607EF44u);  // 0607EEEE mov.l 0x0607EF44,r1
    c.r[0] = c.r[2];  // 0607EEF0 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607EEF2 mov.b @(r0,r1),r5
    c.r[4] |= c.r[3];  // 0607EEF4 or r3,r4
    c.r[0] = ld32(0x0607EF48u);  // 0607EEF6 mov.l 0x0607EF48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607EEFCu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EEFCu) return; }  // 0607EEF8 jsr @r0 ; extu.b r5,r5
    c.r[7] = c.r[0];  // 0607EEFC mov r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0607EEFE tst r7,r7
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0607EF0A; } }  // 0607EF00 bf/s 0x0607EF0A ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF32u);  // 0607EF04 mov.w 0x0607EF32,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607EF2E;  // 0607EF06 bra 0x0607EF2E ; lds.l @r15+,pr
L_0607EF0A:
    c.r[1] = ld32(0x0607EF4Cu);  // 0607EF0A mov.l 0x0607EF4C,r1
    c.r[3] = ld32(c.r[1]);  // 0607EF0C mov.l @r1,r3
    c.r[1] = c.r[3];  // 0607EF0E mov r3,r1
    c.r[1] += 10;  // 0607EF10 add #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607EF12 mov.w @r1,r2
    c.r[3] += 12;  // 0607EF14 add #12,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607EF16 extu.w r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607EF18 mov.b @r3,r1
    c.r[2] <<= 8;  // 0607EF1A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607EF1C extu.b r1,r1
    c.r[1] |= c.r[2];  // 0607EF1E or r2,r1
    c.t = c.r[7] > c.r[1];  // 0607EF20 cmp/hi r1,r7
    if (!c.t) { goto L_0607EF2A; }  // 0607EF22 bf 0x0607EF2A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF34u);  // 0607EF24 mov.w 0x0607EF34,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607EF2E;  // 0607EF26 bra 0x0607EF2E ; lds.l @r15+,pr
L_0607EF2A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF36u);  // 0607EF2A mov.w 0x0607EF36,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EF2C lds.l @r15+,pr
L_0607EF2E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EF2E rts ; mov.l @r15+,r14
}

void f_0607EF50(SH2Context& c) {
    ran[1769] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EF50 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607EF52 mov r15,r14
    c.r[1] = ld32(0x0607EF6Cu);  // 0607EF54 mov.l 0x0607EF6C,r1
    c.r[3] = ld32(c.r[1]);  // 0607EF56 mov.l @r1,r3
    c.r[2] = ld32(0x0607EF70u);  // 0607EF58 mov.l 0x0607EF70,r2
    c.r[3] += 1;  // 0607EF5A add #1,r3
    st32(c.r[1], c.r[3]);  // 0607EF5C mov.l r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607EF5E mov.b @r3,r1
    st8(c.r[2], c.r[1]);  // 0607EF60 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607EF68u);  // 0607EF62 mov.w 0x0607EF68,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EF64 rts ; mov.l @r15+,r14
}

void f_0607EF74(SH2Context& c) {
    ran[1770] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607EF74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607EF76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607EF78 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607EF7A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607EF7C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607EF7E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EF80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EF82 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F0AEu);  // 0607EF84 mov.w 0x0607F0AE,r3
    c.r[15] += c.r[3];  // 0607EF86 add r3,r15
    c.r[14] = c.r[15];  // 0607EF88 mov r15,r14
    c.r[1] = ld32(0x0607F0C0u);  // 0607EF8A mov.l 0x0607F0C0,r1
    c.r[7] = 0x7Fu;  // 0607EF8C mov #127,r7
    c.r[9] = ld32(0x0607F0C4u);  // 0607EF8E mov.l 0x0607F0C4,r9
    c.r[6] = 0xFu;  // 0607EF90 mov #15,r6
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607F0B0u);  // 0607EF92 mov.w 0x0607F0B0,r11
    c.r[12] = ld32(0x0607F0C8u);  // 0607EF94 mov.l 0x0607F0C8,r12
    c.r[2] = ld32(c.r[1]);  // 0607EF96 mov.l @r1,r2
    c.r[4] = c.r[14];  // 0607EF98 mov r14,r4
    c.r[1] = ld32(0x0607F0CCu);  // 0607EF9A mov.l 0x0607F0CC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EF9C mov.b @r1,r1
    c.r[0] = c.r[2];  // 0607EF9E mov r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607EFA0 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607EFA2 add r1,r1
    c.r[2] += c.r[1];  // 0607EFA4 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607EFA6 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 0607EFA8 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EFAA mov.b @r2,r5
    c.r[3] &= c.r[7];  // 0607EFAC and r7,r3
    c.r[3] <<= 8;  // 0607EFAE shll8 r3
    c.r[5] = c.r[5] & 0xFFu;  // 0607EFB0 extu.b r5,r5
    c.r[5] |= c.r[3];  // 0607EFB2 or r3,r5
    c.r[1] = 0x1Eu;  // 0607EFB4 mov #30,r1
    c.r[3] = ld32(0x0607F0D0u);  // 0607EFB6 mov.l 0x0607F0D0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F0B2u);  // 0607EFB8 mov.w 0x0607F0B2,r0
    c.macl = c.r[5] * c.r[1];  // 0607EFBA mul.l r1,r5
    c.r[7] = 0xFu;  // 0607EFBC mov #15,r7
    c.r[2] = ld32(c.r[9]);  // 0607EFBE mov.l @r9,r2
    c.r[8] = c.macl;  // 0607EFC0 sts macl,r8
    c.r[2] += c.r[8];  // 0607EFC2 add r8,r2
    c.r[2] += 3;  // 0607EFC4 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607EFC6 mov.b @r3,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0607EFC8 extu.b r5,r5
    c.r[6] &= c.r[1];  // 0607EFCA and r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EFCC mov.b @r2,r1
    c.r[6] <<= 2;  // 0607EFCE shll2 r6
    c.r[6] += c.r[6];  // 0607EFD0 add r6,r6
    c.r[1] &= c.r[0];  // 0607EFD2 and r0,r1
    c.r[1] |= c.r[6];  // 0607EFD4 or r6,r1
    st8(c.r[2], c.r[1]);  // 0607EFD6 mov.b r1,@r2
    c.r[1] = ld32(0x0607F0D4u);  // 0607EFD8 mov.l 0x0607F0D4,r1
    c.r[2] = ld32(c.r[1]);  // 0607EFDA mov.l @r1,r2
    c.r[6] = c.r[11];  // 0607EFDC mov r11,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607EFDE mov.b @r3,r1
    c.r[2] += 3;  // 0607EFE0 add #3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EFE2 mov.b @r2,r3
    c.r[1] <<= 2;  // 0607EFE4 shll2 r1
    c.r[1] <<= 2;  // 0607EFE6 shll2 r1
    c.r[3] &= c.r[7];  // 0607EFE8 and r7,r3
    c.r[3] |= c.r[1];  // 0607EFEA or r1,r3
    { const uint32_t x = c.r[12]; c.pr = 0x0607EFF0u; st8(c.r[2], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EFF0u) return; }  // 0607EFEC jsr @r12 ; mov.b r3,@r2
    c.r[1] = c.r[14];  // 0607EFF0 mov r14,r1
    c.r[1] += 26;  // 0607EFF2 add #26,r1
    c.r[3] = ld32(c.r[9]);  // 0607EFF4 mov.l @r9,r3
    c.r[0] = c.r[14];  // 0607EFF6 mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607EFF8 mov.w @r1,r1
    c.r[3] += c.r[8];  // 0607EFFA add r8,r3
    c.r[2] = c.r[3];  // 0607EFFC mov r3,r2
    c.r[2] += 22;  // 0607EFFE add #22,r2
    st16(c.r[2], c.r[1]);  // 0607F000 mov.w r1,@r2
    c.r[1] = c.r[14];  // 0607F002 mov r14,r1
    c.r[1] += 28;  // 0607F004 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607F006 mov.w @r1,r1
    c.r[3] += 24;  // 0607F008 add #24,r3
    st16(c.r[3], c.r[1]);  // 0607F00A mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607F0B4u);  // 0607F00C mov.w 0x0607F0B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F00E mov.b @(r0,r1),r1
    c.r[7] = 0xFu;  // 0607F010 mov #15,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0607F012 shlr r1
    c.r[1] &= c.r[7];  // 0607F014 and r7,r1
    c.r[0] = c.r[1];  // 0607F016 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 0607F018 cmp/eq #4,r0
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0607F094; } }  // 0607F01A bf/s 0x0607F094 ; mov #0,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x0607F0B6u);  // 0607F01E mov.w 0x0607F0B6,r8
    c.r[8] += c.r[14];  // 0607F020 add r14,r8
    c.r[13] = c.r[12];  // 0607F022 mov r12,r13
    c.r[12] = c.r[9];  // 0607F024 mov r9,r12
    c.r[0] = c.r[8];  // 0607F026 mov r8,r0
    c.r[0] += 28;  // 0607F028 add #28,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607F0B8u);  // 0607F02A mov.w 0x0607F0B8,r7
    c.r[7] += c.r[14];  // 0607F02C add r14,r7
    st32(c.r[7], c.r[0]);  // 0607F02E mov.l r0,@r7
    c.r[9] = 0x0u;  // 0607F030 mov #0,r9
L_0607F032:
    c.r[11] = c.r[10] & 0xFFu;  // 0607F032 extu.b r10,r11
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607F0B0u);  // 0607F034 mov.w 0x0607F0B0,r6
    c.r[5] = c.r[11];  // 0607F036 mov r11,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0607F03Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F03Cu) return; }  // 0607F038 jsr @r13 ; mov r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F0B4u);  // 0607F03C mov.w 0x0607F0B4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607F03E mov.b @(r0,r8),r1
    c.r[0] = c.r[1];  // 0607F040 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F042 shlr r0
    c.r[0] &= 0xFu;  // 0607F044 and #15,r0
    c.t = c.r[0] == 0x4u;  // 0607F046 cmp/eq #4,r0
    { const bool k = !c.t; c.r[3] = 0xFu; if (k) { goto L_0607F08A; } }  // 0607F048 bf/s 0x0607F08A ; mov #15,r3
    c.r[1] = ld32(0x0607F0D0u);  // 0607F04C mov.l 0x0607F0D0,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607F0B2u);  // 0607F04E mov.w 0x0607F0B2,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607F0B0u);  // 0607F050 mov.w 0x0607F0B0,r6
    c.r[5] = c.r[11];  // 0607F052 mov r11,r5
    c.r[2] = ld32(c.r[12]);  // 0607F054 mov.l @r12,r2
    c.r[4] = c.r[8];  // 0607F056 mov r8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F058 mov.b @r1,r1
    c.r[2] += c.r[9];  // 0607F05A add r9,r2
    c.r[2] += 3;  // 0607F05C add #3,r2
    c.r[3] &= c.r[1];  // 0607F05E and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607F060 mov.b @r2,r1
    c.r[3] <<= 2;  // 0607F062 shll2 r3
    c.r[3] += c.r[3];  // 0607F064 add r3,r3
    c.r[1] &= c.r[7];  // 0607F066 and r7,r1
    c.r[1] |= c.r[3];  // 0607F068 or r3,r1
    { const uint32_t x = c.r[13]; c.pr = 0x0607F06Eu; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F06Eu) return; }  // 0607F06A jsr @r13 ; mov.b r1,@r2
    c.r[1] = c.r[8];  // 0607F06E mov r8,r1
    c.r[1] += 26;  // 0607F070 add #26,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F0B8u);  // 0607F072 mov.w 0x0607F0B8,r0
    c.r[3] = ld32(c.r[12]);  // 0607F074 mov.l @r12,r3
    c.r[0] += c.r[14];  // 0607F076 add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607F078 mov.w @r1,r1
    c.r[3] += c.r[9];  // 0607F07A add r9,r3
    c.r[2] = c.r[3];  // 0607F07C mov r3,r2
    c.r[2] += 22;  // 0607F07E add #22,r2
    st16(c.r[2], c.r[1]);  // 0607F080 mov.w r1,@r2
    c.r[7] = ld32(c.r[0]);  // 0607F082 mov.l @r0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0607F084 mov.w @r7,r1
    c.r[3] += 24;  // 0607F086 add #24,r3
    st16(c.r[3], c.r[1]);  // 0607F088 mov.w r1,@r3
L_0607F08A:
    c.r[10] += 1;  // 0607F08A add #1,r10
    c.r[1] = 0x7Fu;  // 0607F08C mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0607F08E cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0607F032; } }  // 0607F090 bf/s 0x0607F032 ; add #30,r9
L_0607F094:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F0BAu);  // 0607F094 mov.w 0x0607F0BA,r3
    c.r[14] += c.r[3];  // 0607F096 add r3,r14
    c.r[15] = c.r[14];  // 0607F098 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607F09A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607F09C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607F09E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607F0A0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607F0A2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607F0A4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607F0A6 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F0BCu);  // 0607F0A8 mov.w 0x0607F0BC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F0AA rts ; mov.l @r15+,r8
}

void f_0607F0D8(SH2Context& c) {
    ran[1771] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F0D8 mov.l r14,@-r15
    c.r[1] = ld32(0x0607F15Cu);  // 0607F0DA mov.l 0x0607F15C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F0DC mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 0607F0DE cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607F0FC; } }  // 0607F0E0 bf/s 0x0607F0FC ; mov r15,r14
    c.r[1] = ld32(0x0607F160u);  // 0607F0E4 mov.l 0x0607F160,r1
    c.r[1] = ld32(c.r[1]);  // 0607F0E6 mov.l @r1,r1
    c.r[1] += 37;  // 0607F0E8 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F0EA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607F0EC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F0EE shlr r0
    c.r[0] &= 0x7u;  // 0607F0F0 and #7,r0
    c.r[1] = 0x3u;  // 0607F0F2 mov #3,r1
    c.t = c.r[0] > c.r[1];  // 0607F0F4 cmp/hi r1,r0
    if (!c.t) { goto L_0607F14A; }  // 0607F0F6 bf 0x0607F14A
    c.r[1] = ld32(0x0607F15Cu);  // 0607F0F8 mov.l 0x0607F15C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F0FA mov.b @r1,r0
L_0607F0FC:
    c.t = c.r[0] == 0x2u;  // 0607F0FC cmp/eq #2,r0
    if (!c.t) { goto L_0607F116; }  // 0607F0FE bf 0x0607F116
    c.r[1] = ld32(0x0607F160u);  // 0607F100 mov.l 0x0607F160,r1
    c.r[1] = ld32(c.r[1]);  // 0607F102 mov.l @r1,r1
    c.r[0] = ld32(c.r[1] + 36);  // 0607F104 mov.l @(36,r1),r0
    c.r[0] >>= 8;  // 0607F106 shlr8 r0
    c.r[0] <<= 2;  // 0607F108 shll2 r0
    c.r[0] >>= 8;  // 0607F10A shlr8 r0
    c.r[0] &= 0x7u;  // 0607F10C and #7,r0
    c.r[1] = 0x3u;  // 0607F10E mov #3,r1
    c.t = c.r[0] > c.r[1];  // 0607F110 cmp/hi r1,r0
    if (!c.t) { goto L_0607F14A; }  // 0607F112 bf 0x0607F14A
    c.r[1] = ld32(0x0607F15Cu);  // 0607F114 mov.l 0x0607F15C,r1
L_0607F116:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F116 mov.b @r1,r2
    c.r[0] = c.r[2];  // 0607F118 mov r2,r0
    c.t = c.r[0] == 0x3u;  // 0607F11A cmp/eq #3,r0
    if (!c.t) { goto L_0607F132; }  // 0607F11C bf 0x0607F132
    c.r[1] = ld32(0x0607F160u);  // 0607F11E mov.l 0x0607F160,r1
    c.r[1] = ld32(c.r[1]);  // 0607F120 mov.l @r1,r1
    c.r[1] += 38;  // 0607F122 add #38,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F124 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607F126 mov r1,r0
    c.r[0] >>= 2;  // 0607F128 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F12A shlr r0
    c.r[0] &= 0x7u;  // 0607F12C and #7,r0
    c.t = c.r[0] > c.r[2];  // 0607F12E cmp/hi r2,r0
    if (!c.t) { goto L_0607F14A; }  // 0607F130 bf 0x0607F14A
L_0607F132:
    c.r[1] = ld32(0x0607F15Cu);  // 0607F132 mov.l 0x0607F15C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F134 mov.b @r1,r0
    c.t = c.r[0] == 0x4u;  // 0607F136 cmp/eq #4,r0
    if (!c.t) { goto L_0607F150; }  // 0607F138 bf 0x0607F150
    c.r[1] = ld32(0x0607F160u);  // 0607F13A mov.l 0x0607F160,r1
    c.r[1] = ld32(c.r[1]);  // 0607F13C mov.l @r1,r1
    c.r[1] += 38;  // 0607F13E add #38,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F140 mov.b @r1,r0
    c.r[0] &= 0x7u;  // 0607F142 and #7,r0
    c.r[1] = 0x3u;  // 0607F144 mov #3,r1
    c.t = c.r[0] > c.r[1];  // 0607F146 cmp/hi r1,r0
    if (c.t) { goto L_0607F150; }  // 0607F148 bt 0x0607F150
L_0607F14A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F158u);  // 0607F14A mov.w 0x0607F158,r0
    c.r[15] = c.r[14]; goto L_0607F154;  // 0607F14C bra 0x0607F154 ; mov r14,r15
L_0607F150:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F15Au);  // 0607F150 mov.w 0x0607F15A,r0
    c.r[15] = c.r[14];  // 0607F152 mov r14,r15
L_0607F154:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F154 rts ; mov.l @r15+,r14
}

void f_0607F164(SH2Context& c) {
    ran[1772] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607F164 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607F166 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607F168 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607F16A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F16C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607F16E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607F170 mov r15,r14
    c.r[3] = ld32(0x0607F24Cu);  // 0607F172 mov.l 0x0607F24C,r3
    c.r[2] = ld32(c.r[3]);  // 0607F174 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F240u);  // 0607F176 mov.w 0x0607F240,r0
    c.r[1] = 0x0u;  // 0607F178 mov #0,r1
    c.r[8] = 0x0u;  // 0607F17A mov #0,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0607F242u);  // 0607F17C mov.w 0x0607F242,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607F244u);  // 0607F17E mov.w 0x0607F244,r9
    c.r[5] = c.r[0];  // 0607F180 mov r0,r5
    c.r[4] = 0x0u;  // 0607F182 mov #0,r4
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607F184 mov.b r1,@(r0,r2)
L_0607F186:
    c.r[1] = ld32(0x0607F250u);  // 0607F186 mov.l 0x0607F250,r1
    c.r[0] = ld32(c.r[1]);  // 0607F188 mov.l @r1,r0
    c.r[2] = c.r[4];  // 0607F18A mov r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0607F18C mov.w @(r0,r4),r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 0607F18E extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0607F190 tst r7,r7
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_0607F212; } }  // 0607F192 bt/s 0x0607F212 ; add r0,r2
    c.r[2] += 3;  // 0607F196 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607F198 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607F19A extu.b r1,r2
    c.r[0] = c.r[2];  // 0607F19C mov r2,r0
    c.r[1] = ld32(0x0607F254u);  // 0607F19E mov.l 0x0607F254,r1
    c.r[1] = ld32(c.r[1]);  // 0607F1A0 mov.l @r1,r1
    c.r[0] >>= 2;  // 0607F1A2 shlr2 r0
    c.r[0] >>= 2;  // 0607F1A4 shlr2 r0
    c.r[1] += 8;  // 0607F1A6 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F1A8 mov.b @r1,r1
    c.r[0] &= 0x3u;  // 0607F1AA and #3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607F1AC extu.b r1,r1
    c.r[1] >>= 2;  // 0607F1AE shlr2 r1
    c.r[1] >>= 2;  // 0607F1B0 shlr2 r1
    c.r[1] >>= 2;  // 0607F1B2 shlr2 r1
    c.t = c.r[0] == c.r[1];  // 0607F1B4 cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] >>= 2; if (k) { goto L_0607F212; } }  // 0607F1B6 bf/s 0x0607F212 ; shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607F1BA shlr r2
    c.r[0] = 0x1u;  // 0607F1BC mov #1,r0
    c.r[2] &= c.r[0];  // 0607F1BE and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0607F1C0 tst r2,r2
    { const bool k = c.t; c.t = c.r[7] == c.r[10]; if (k) { goto L_0607F1CC; } }  // 0607F1C2 bt/s 0x0607F1CC ; cmp/eq r10,r7
    { const bool k = c.t; c.t = c.r[7] == c.r[9]; if (k) { goto L_0607F212; } }  // 0607F1C6 bt/s 0x0607F212 ; cmp/eq r9,r7
    if (c.t) { goto L_0607F212; }  // 0607F1CA bt 0x0607F212
L_0607F1CC:
    c.r[2] = ld32(c.r[3]);  // 0607F1CC mov.l @r3,r2
    c.r[0] = c.r[2];  // 0607F1CE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607F1D0 mov.b @(r0,r5),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0607F1D2 extu.b r1,r6
    c.r[6] += c.r[6];  // 0607F1D4 add r6,r6
    c.r[1] = c.r[8] & 0xFFFFu;  // 0607F1D6 extu.w r8,r1
    c.r[11] = c.r[1];  // 0607F1D8 mov r1,r11
    c.r[11] >>= 8;  // 0607F1DA shlr8 r11
    c.r[0] = 0x7Fu;  // 0607F1DC mov #127,r0
    c.r[11] &= c.r[0];  // 0607F1DE and r0,r11
    c.r[0] = c.r[2];  // 0607F1E0 mov r2,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607F1E2 mov.b @(r0,r6),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F246u);  // 0607F1E4 mov.w 0x0607F246,r0
    c.r[7] &= c.r[0];  // 0607F1E6 and r0,r7
    c.r[7] |= c.r[11];  // 0607F1E8 or r11,r7
    c.r[0] = c.r[2];  // 0607F1EA mov r2,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 0607F1EC mov.b r7,@(r0,r6)
    c.r[2] += c.r[6];  // 0607F1EE add r6,r2
    c.r[2] += 1;  // 0607F1F0 add #1,r2
    st8(c.r[2], c.r[1]);  // 0607F1F2 mov.b r1,@r2
    c.r[2] = ld32(c.r[3]);  // 0607F1F4 mov.l @r3,r2
    c.r[0] = c.r[2];  // 0607F1F6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607F1F8 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F1FA extu.b r1,r1
    c.r[1] += c.r[1];  // 0607F1FC add r1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F1FE mov.b @(r0,r1),r7
    c.r[0] = 0x7Fu;  // 0607F200 mov #127,r0
    c.r[7] &= c.r[0];  // 0607F202 and r0,r7
    c.r[0] = c.r[2];  // 0607F204 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 0607F206 mov.b r7,@(r0,r1)
    c.r[2] = ld32(c.r[3]);  // 0607F208 mov.l @r3,r2
    c.r[0] = c.r[2];  // 0607F20A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0607F20C mov.b @(r0,r5),r1
    c.r[1] += 1;  // 0607F20E add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 0607F210 mov.b r1,@(r0,r5)
L_0607F212:
    c.r[8] += 1;  // 0607F212 add #1,r8
    c.r[1] = 0x7Fu;  // 0607F214 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0607F216 cmp/gt r1,r8
    { const bool k = !c.t; c.r[4] += 12; if (k) { SH2_POLL(c); goto L_0607F186; } }  // 0607F218 bf/s 0x0607F186 ; add #12,r4
    c.r[1] = ld32(0x0607F24Cu);  // 0607F21C mov.l 0x0607F24C,r1
    c.r[1] = ld32(c.r[1]);  // 0607F21E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F240u);  // 0607F220 mov.w 0x0607F240,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F222 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607F258u);  // 0607F224 mov.l 0x0607F258,r2
    st8(c.r[2], c.r[1]);  // 0607F226 mov.b r1,@r2
    c.r[1] = ld32(0x0607F25Cu);  // 0607F228 mov.l 0x0607F25C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607F22Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F22Eu) return; }  // 0607F22A jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607F22E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607F230 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607F232 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607F234 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607F236 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607F238 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F248u);  // 0607F23A mov.w 0x0607F248,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F23C rts ; mov.l @r15+,r8
}

void f_0607F260(SH2Context& c) {
    ran[1773] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607F260 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607F262 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607F264 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607F266 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607F268 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607F26A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F26C mov.l r14,@-r15
    c.r[15] -= 8;  // 0607F26E add #-8,r15
    c.r[2] = ld32(0x0607F394u);  // 0607F270 mov.l 0x0607F394,r2
    c.r[1] = ld32(c.r[2]);  // 0607F272 mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F38Eu);  // 0607F274 mov.w 0x0607F38E,r3
    c.r[0] = c.r[1];  // 0607F276 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607F278 mov.b @(r0,r3),r1
    c.r[13] = 0x0u;  // 0607F27A mov #0,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607F27C extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 0607F27E cmp/ge r1,r13
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607F37A; } }  // 0607F280 bt/s 0x0607F37A ; mov r15,r14
    st32(c.r[14], c.r[3]);  // 0607F284 mov.l r3,@r14
L_0607F286:
    c.r[0] = ld32(0x0607F394u);  // 0607F286 mov.l 0x0607F394,r0
    c.r[1] = ld32(c.r[0]);  // 0607F288 mov.l @r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607F28A mov.l @r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F28C mov.b @(r0,r1),r1
    c.r[7] = 0x0u; goto L_0607F35C;  // 0607F28E bra 0x0607F35C ; mov #0,r7
L_0607F292:
    c.r[0] = ld32(0x0607F394u);  // 0607F292 mov.l 0x0607F394,r0
    c.r[4] += c.r[4];  // 0607F294 add r4,r4
    c.r[2] = 0x7Fu;  // 0607F296 mov #127,r2
    c.r[12] = c.r[7];  // 0607F298 mov r7,r12
    c.r[12] += 1;  // 0607F29A add #1,r12
    c.r[5] = ld32(c.r[0]);  // 0607F29C mov.l @r0,r5
    c.r[6] = c.r[12];  // 0607F29E mov r12,r6
    c.r[0] = c.r[5];  // 0607F2A0 mov r5,r0
    c.r[11] = c.r[5];  // 0607F2A2 mov r5,r11
    c.r[11] += c.r[4];  // 0607F2A4 add r4,r11
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607F2A6 mov.b @(r0,r4),r10
    c.r[11] += 1;  // 0607F2A8 add #1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0607F2AA mov.b @r11,r1
    c.r[8] = c.r[10] & 0xFFu;  // 0607F2AC extu.b r10,r8
    c.r[2] &= c.r[8];  // 0607F2AE and r8,r2
    c.r[2] <<= 8;  // 0607F2B0 shll8 r2
    c.r[9] = c.r[1] & 0xFFu;  // 0607F2B2 extu.b r1,r9
    c.r[1] = ld32(0x0607F398u);  // 0607F2B4 mov.l 0x0607F398,r1
    c.r[3] = ld32(c.r[1]);  // 0607F2B6 mov.l @r1,r3
    c.r[9] |= c.r[2];  // 0607F2B8 or r2,r9
    c.r[1] = c.r[9];  // 0607F2BA mov r9,r1
    c.r[1] += c.r[1];  // 0607F2BC add r1,r1
    c.r[1] += c.r[9];  // 0607F2BE add r9,r1
    c.r[1] <<= 2;  // 0607F2C0 shll2 r1
    c.r[1] += c.r[3];  // 0607F2C2 add r3,r1
    c.r[1] += 2;  // 0607F2C4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F2C6 mov.b @r1,r2
    c.r[6] += c.r[6];  // 0607F2C8 add r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607F2CA mov.b @(r0,r6),r1
    c.r[0] = c.r[1];  // 0607F2CC mov r1,r0
    c.r[0] &= 0x7Fu;  // 0607F2CE and #127,r0
    c.r[1] = c.r[5];  // 0607F2D0 mov r5,r1
    c.r[1] += c.r[6];  // 0607F2D2 add r6,r1
    c.r[1] += 1;  // 0607F2D4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F2D6 mov.b @r1,r1
    c.r[0] <<= 8;  // 0607F2D8 shll8 r0
    c.r[7] = c.r[1] & 0xFFu;  // 0607F2DA extu.b r1,r7
    c.r[7] |= c.r[0];  // 0607F2DC or r0,r7
    c.r[1] = c.r[7];  // 0607F2DE mov r7,r1
    c.r[1] += c.r[1];  // 0607F2E0 add r1,r1
    c.r[1] += c.r[7];  // 0607F2E2 add r7,r1
    c.r[1] <<= 2;  // 0607F2E4 shll2 r1
    c.r[1] += c.r[3];  // 0607F2E6 add r3,r1
    c.r[1] += 2;  // 0607F2E8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F2EA mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607F2EC extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607F2EE extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0607F2F0 cmp/ge r1,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0607F352; } }  // 0607F2F2 bt/s 0x0607F352 ; mov r7,r1
    c.r[1] >>= 8;  // 0607F2F6 shlr8 r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607F390u);  // 0607F2F8 mov.w 0x0607F390,r2
    c.r[2] &= c.r[10];  // 0607F2FA and r10,r2
    c.r[2] |= c.r[1];  // 0607F2FC or r1,r2
    c.r[0] = c.r[5];  // 0607F2FE mov r5,r0
    st8(c.r[0] + c.r[4], c.r[2]);  // 0607F300 mov.b r2,@(r0,r4)
    st8(c.r[11], c.r[7]);  // 0607F302 mov.b r7,@r11
    c.r[0] = ld32(0x0607F394u);  // 0607F304 mov.l 0x0607F394,r0
    c.r[1] = ld32(c.r[0]);  // 0607F306 mov.l @r0,r1
    c.r[0] = c.r[1];  // 0607F308 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607F30A mov.b @(r0,r6),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F390u);  // 0607F30C mov.w 0x0607F390,r0
    c.r[2] &= c.r[0];  // 0607F30E and r0,r2
    c.r[0] = c.r[1];  // 0607F310 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0607F312 mov.b @(r0,r4),r3
    c.r[0] = 0x7Fu;  // 0607F314 mov #127,r0
    c.r[3] &= c.r[0];  // 0607F316 and r0,r3
    c.r[3] |= c.r[2];  // 0607F318 or r2,r3
    c.r[0] = c.r[1];  // 0607F31A mov r1,r0
    st8(c.r[0] + c.r[4], c.r[3]);  // 0607F31C mov.b r3,@(r0,r4)
    c.r[0] = ld32(0x0607F394u);  // 0607F31E mov.l 0x0607F394,r0
    c.r[3] = c.r[9] & 0xFFFFu;  // 0607F320 extu.w r9,r3
    c.r[1] = ld32(c.r[0]);  // 0607F322 mov.l @r0,r1
    c.r[2] = c.r[3];  // 0607F324 mov r3,r2
    c.r[0] = c.r[1];  // 0607F326 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607F328 mov.b @(r0,r6),r7
    c.r[2] >>= 8;  // 0607F32A shlr8 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F390u);  // 0607F32C mov.w 0x0607F390,r0
    c.r[7] &= c.r[0];  // 0607F32E and r0,r7
    c.r[7] |= c.r[2];  // 0607F330 or r2,r7
    c.r[0] = c.r[1];  // 0607F332 mov r1,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 0607F334 mov.b r7,@(r0,r6)
    c.r[1] += c.r[6];  // 0607F336 add r6,r1
    c.r[1] += 1;  // 0607F338 add #1,r1
    st8(c.r[1], c.r[3]);  // 0607F33A mov.b r3,@r1
    c.r[0] = ld32(0x0607F394u);  // 0607F33C mov.l 0x0607F394,r0
    c.r[1] = ld32(c.r[0]);  // 0607F33E mov.l @r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F390u);  // 0607F340 mov.w 0x0607F390,r0
    c.r[8] &= c.r[0];  // 0607F342 and r0,r8
    c.r[0] = c.r[1];  // 0607F344 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0607F346 mov.b @(r0,r6),r2
    c.r[0] = 0x7Fu;  // 0607F348 mov #127,r0
    c.r[2] &= c.r[0];  // 0607F34A and r0,r2
    c.r[2] |= c.r[8];  // 0607F34C or r8,r2
    c.r[0] = c.r[1];  // 0607F34E mov r1,r0
    st8(c.r[0] + c.r[6], c.r[2]);  // 0607F350 mov.b r2,@(r0,r6)
L_0607F352:
    c.r[0] = ld32(0x0607F394u);  // 0607F352 mov.l 0x0607F394,r0
    c.r[1] = ld32(c.r[0]);  // 0607F354 mov.l @r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607F356 mov.l @r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F358 mov.b @(r0,r1),r1
    c.r[7] = c.r[12];  // 0607F35A mov r12,r7
L_0607F35C:
    c.r[1] = c.r[1] & 0xFFu;  // 0607F35C extu.b r1,r1
    c.r[1] -= c.r[13];  // 0607F35E sub r13,r1
    c.r[1] -= 1;  // 0607F360 add #-1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 0607F362 cmp/ge r1,r7
    { const bool k = !c.t; c.r[4] = c.r[7]; if (k) { SH2_POLL(c); goto L_0607F292; } }  // 0607F364 bf/s 0x0607F292 ; mov r7,r4
    c.r[2] = ld32(0x0607F394u);  // 0607F368 mov.l 0x0607F394,r2
    c.r[1] = ld32(c.r[2]);  // 0607F36A mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F38Eu);  // 0607F36C mov.w 0x0607F38E,r3
    c.r[0] = c.r[1];  // 0607F36E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607F370 mov.b @(r0,r3),r1
    c.r[13] += 1;  // 0607F372 add #1,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607F374 extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 0607F376 cmp/ge r1,r13
    if (!c.t) { SH2_POLL(c); goto L_0607F286; }  // 0607F378 bf 0x0607F286
L_0607F37A:
    c.r[14] += 8;  // 0607F37A add #8,r14
    c.r[15] = c.r[14];  // 0607F37C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607F37E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607F380 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607F382 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607F384 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607F386 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607F388 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F38A rts ; mov.l @r15+,r8
}

void f_0607F39C(SH2Context& c) {
    ran[1774] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F39C mov.l r14,@-r15
    c.r[1] = ld32(0x0607F3DCu);  // 0607F39E mov.l 0x0607F3DC,r1
    c.r[2] = ld32(c.r[1]);  // 0607F3A0 mov.l @r1,r2
    c.r[2] += 1;  // 0607F3A2 add #1,r2
    st32(c.r[1], c.r[2]);  // 0607F3A4 mov.l r2,@r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0607F3A6 mov.b @r2+,r3
    c.r[14] = c.r[15];  // 0607F3A8 mov r15,r14
    c.r[0] = c.r[3] & 0xFFu;  // 0607F3AA extu.b r3,r0
    c.r[3] = c.r[2];  // 0607F3AC mov r2,r3
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607F3AE tst r0,r0
    { const bool k = c.t; st32(c.r[1], c.r[3]); if (k) { goto L_0607F3BE; } }  // 0607F3B0 bt/s 0x0607F3BE ; mov.l r3,@r1
    c.t = c.r[0] == 0x1u;  // 0607F3B4 cmp/eq #1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0607F3CA; } }  // 0607F3B6 bt/s 0x0607F3CA ; mov r14,r15
    goto L_0607F3D2;  // 0607F3BA bra 0x0607F3D2 ; nop
L_0607F3BE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607F3BE mov.b @r3,r1
    c.r[2] = ld32(0x0607F3E0u);  // 0607F3C0 mov.l 0x0607F3E0,r2
    st8(c.r[2], c.r[1]);  // 0607F3C2 mov.b r1,@r2
    c.r[2] = ld32(0x0607F3E4u);  // 0607F3C4 mov.l 0x0607F3E4,r2
    c.r[1] = 0x0u; goto L_0607F3CE;  // 0607F3C6 bra 0x0607F3CE ; mov #0,r1
L_0607F3CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607F3CA mov.b @r3,r1
    c.r[2] = ld32(0x0607F3E4u);  // 0607F3CC mov.l 0x0607F3E4,r2
L_0607F3CE:
    st8(c.r[2], c.r[1]);  // 0607F3CE mov.b r1,@r2
    c.r[15] = c.r[14];  // 0607F3D0 mov r14,r15
L_0607F3D2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F3D8u);  // 0607F3D2 mov.w 0x0607F3D8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F3D4 rts ; mov.l @r15+,r14
}

void f_0607F3E8(SH2Context& c) {
    ran[1775] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F3E8 mov.l r14,@-r15
    c.r[1] = ld32(0x0607F43Cu);  // 0607F3EA mov.l 0x0607F43C,r1
    c.r[2] = ld32(c.r[1]);  // 0607F3EC mov.l @r1,r2
    c.r[2] += 1;  // 0607F3EE add #1,r2
    st32(c.r[1], c.r[2]);  // 0607F3F0 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607F3F2 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607F3F4 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0607F3F6 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607F40C; } }  // 0607F3F8 bt/s 0x0607F40C ; mov r15,r14
    c.r[1] = 0x1u;  // 0607F3FC mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0607F3FE cmp/gt r1,r0
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_0607F41C; } }  // 0607F400 bt/s 0x0607F41C ; tst r0,r0
    if (!c.t) { goto L_0607F41C; }  // 0607F404 bf 0x0607F41C
    c.r[1] = ld32(0x0607F440u);  // 0607F406 mov.l 0x0607F440,r1
    st32(c.r[1], c.r[0]); goto L_0607F42E;  // 0607F408 bra 0x0607F42E ; mov.l r0,@r1
L_0607F40C:
    c.r[1] = ld32(0x0607F444u);  // 0607F40C mov.l 0x0607F444,r1
    c.r[1] = ld32(c.r[1]);  // 0607F40E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F436u);  // 0607F410 mov.w 0x0607F436,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F412 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607F440u);  // 0607F414 mov.l 0x0607F440,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607F416 extu.b r1,r1
    st32(c.r[2], c.r[1]); goto L_0607F42E;  // 0607F418 bra 0x0607F42E ; mov.l r1,@r2
L_0607F41C:
    c.r[1] = ld32(0x0607F444u);  // 0607F41C mov.l 0x0607F444,r1
    c.r[1] = ld32(c.r[1]);  // 0607F41E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F436u);  // 0607F420 mov.w 0x0607F436,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F422 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607F440u);  // 0607F424 mov.l 0x0607F440,r3
    c.r[2] = ld32(c.r[3]);  // 0607F426 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607F428 extu.b r1,r1
    c.r[2] += c.r[1];  // 0607F42A add r1,r2
    st32(c.r[3], c.r[2]);  // 0607F42C mov.l r2,@r3
L_0607F42E:
    c.r[15] = c.r[14];  // 0607F42E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F438u);  // 0607F430 mov.w 0x0607F438,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F432 rts ; mov.l @r15+,r14
}

void f_0607F448(SH2Context& c) {
    ran[1776] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607F448 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607F44A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607F44C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607F44E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607F450 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607F452 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F454 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607F456 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F5BAu);  // 0607F458 mov.w 0x0607F5BA,r3
    c.r[15] += c.r[3];  // 0607F45A add r3,r15
    c.r[14] = c.r[15];  // 0607F45C mov r15,r14
    c.r[1] = ld32(0x0607F5CCu);  // 0607F45E mov.l 0x0607F5CC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F5BCu);  // 0607F460 mov.w 0x0607F5BC,r0
    c.r[0] += c.r[14];  // 0607F462 add r14,r0
    c.r[3] = ld32(0x0607F5D0u);  // 0607F464 mov.l 0x0607F5D0,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607F5BEu);  // 0607F466 mov.w 0x0607F5BE,r7
    c.r[12] = 0x0u;  // 0607F468 mov #0,r12
    c.r[2] = ld32(c.r[1]);  // 0607F46A mov.l @r1,r2
    c.r[13] = c.r[3];  // 0607F46C mov r3,r13
    c.r[2] += 1;  // 0607F46E add #1,r2
    st32(c.r[1], c.r[2]);  // 0607F470 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607F472 mov.b @r2,r1
    c.r[10] = c.r[7];  // 0607F474 mov r7,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0607F476 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0607F478 mov.l r1,@r0
    c.r[2] = ld32(c.r[3]);  // 0607F47A mov.l @r3,r2
    c.r[1] = 0x0u;  // 0607F47C mov #0,r1
    c.r[0] = c.r[2];  // 0607F47E mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607F480 mov.b r1,@(r0,r7)
    c.r[0] = 0x0u;  // 0607F482 mov #0,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607F5C0u);  // 0607F484 mov.w 0x0607F5C0,r11
    c.r[11] += c.r[14];  // 0607F486 add r14,r11
    st32(c.r[11], c.r[0]);  // 0607F488 mov.l r0,@r11
L_0607F48A:
    c.r[11] = ld32(0x0607F5D4u);  // 0607F48A mov.l 0x0607F5D4,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F5C0u);  // 0607F48C mov.w 0x0607F5C0,r0
    c.r[1] = ld32(c.r[11]);  // 0607F48E mov.l @r11,r1
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 0607F490 mov.l @(r0,r14),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607F5C0u);  // 0607F492 mov.w 0x0607F5C0,r11
    c.r[11] += c.r[14];  // 0607F494 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0607F496 mov.l @r11,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607F498 mov.w @(r0,r1),r3
    c.r[2] += c.r[1];  // 0607F49A add r1,r2
    c.r[1] = c.r[3] & 0xFFFFu;  // 0607F49C extu.w r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607F49E tst r1,r1
    { const bool k = !c.t; c.r[2] += 3; if (k) { goto L_0607F4A8; } }  // 0607F4A0 bf/s 0x0607F4A8 ; add #3,r2
    goto L_0607F5A8;  // 0607F4A4 bra 0x0607F5A8 ; nop
L_0607F4A8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607F4A8 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607F4AA extu.b r1,r2
    c.r[0] = c.r[2];  // 0607F4AC mov r2,r0
    c.r[1] = ld32(0x0607F5D8u);  // 0607F4AE mov.l 0x0607F5D8,r1
    c.r[1] = ld32(c.r[1]);  // 0607F4B0 mov.l @r1,r1
    c.r[0] >>= 2;  // 0607F4B2 shlr2 r0
    c.r[0] >>= 2;  // 0607F4B4 shlr2 r0
    c.r[1] += 8;  // 0607F4B6 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F4B8 mov.b @r1,r1
    c.r[0] &= 0x3u;  // 0607F4BA and #3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607F4BC extu.b r1,r1
    c.r[1] >>= 2;  // 0607F4BE shlr2 r1
    c.r[1] >>= 2;  // 0607F4C0 shlr2 r1
    c.r[1] >>= 2;  // 0607F4C2 shlr2 r1
    c.t = c.r[0] == c.r[1];  // 0607F4C4 cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] >>= 2; if (k) { goto L_0607F5A8; } }  // 0607F4C6 bf/s 0x0607F5A8 ; shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607F4CA shlr r2
    c.r[0] = 0x1u;  // 0607F4CC mov #1,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607F5BCu);  // 0607F4CE mov.w 0x0607F5BC,r11
    c.r[11] += c.r[14];  // 0607F4D0 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0607F4D2 mov.l @r11,r11
    c.r[2] &= c.r[0];  // 0607F4D4 and r0,r2
    c.t = c.r[2] == c.r[11];  // 0607F4D6 cmp/eq r11,r2
    { const bool k = !c.t; c.r[2] = 0x1u; if (k) { goto L_0607F5A8; } }  // 0607F4D8 bf/s 0x0607F5A8 ; mov #1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607F5C2u);  // 0607F4DC mov.w 0x0607F5C2,r1
    c.r[1] += c.r[3];  // 0607F4DE add r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F4E0 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0607F4E2 cmp/hi r2,r1
    { const bool k = !c.t; c.r[9] = c.r[12] & 0xFFu; if (k) { goto L_0607F54A; } }  // 0607F4E4 bf/s 0x0607F54A ; extu.b r12,r9
    c.r[8] = ld32(0x0607F5DCu);  // 0607F4E8 mov.l 0x0607F5DC,r8
    c.r[1] = ld32(0x0607F5E0u);  // 0607F4EA mov.l 0x0607F5E0,r1
    c.r[4] = ld32(c.r[8]);  // 0607F4EC mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0607F4F2u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F4F2u) return; }  // 0607F4EE jsr @r1 ; mov r9,r5
    c.r[1] = ld32(c.r[8]);  // 0607F4F2 mov.l @r8,r1
    c.r[1] += 34;  // 0607F4F4 add #34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F4F6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F4F8 extu.b r1,r1
    c.r[0] = c.r[1];  // 0607F4FA mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F4FC shlr r0
    c.r[0] &= 0x1u;  // 0607F4FE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607F500 tst r0,r0
    { const bool k = !c.t; c.r[1] >>= 2; if (k) { goto L_0607F5A8; } }  // 0607F502 bf/s 0x0607F5A8 ; shlr2 r1
    c.r[1] >>= 2;  // 0607F506 shlr2 r1
    c.r[0] = c.r[1];  // 0607F508 mov r1,r0
    c.t = c.r[0] == 0x7u;  // 0607F50A cmp/eq #7,r0
    if (c.t) { goto L_0607F5A8; }  // 0607F50C bt 0x0607F5A8
    c.r[0] = ld32(0x0607F5E4u);  // 0607F50E mov.l 0x0607F5E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607F514u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F514u) return; }  // 0607F510 jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0607F514 extu.b r0,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607F5C4u);  // 0607F516 mov.w 0x0607F5C4,r9
    c.t = c.r[8] == c.r[9];  // 0607F518 cmp/eq r9,r8
    { const bool k = c.t; c.r[6] = c.r[9]; if (k) { goto L_0607F528; } }  // 0607F51A bt/s 0x0607F528 ; mov r9,r6
    c.r[1] = ld32(0x0607F5E8u);  // 0607F51E mov.l 0x0607F5E8,r1
    c.r[5] = c.r[8];  // 0607F520 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607F526u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F526u) return; }  // 0607F522 jsr @r1 ; mov r14,r4
    c.t = c.r[8] == c.r[9];  // 0607F526 cmp/eq r9,r8
L_0607F528:
    if (c.t) { goto L_0607F54A; }  // 0607F528 bt 0x0607F54A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F5C6u);  // 0607F52A mov.w 0x0607F5C6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607F52C mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0607F52E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F530 shlr r0
    c.r[0] &= 0xFu;  // 0607F532 and #15,r0
    c.t = c.r[0] == 0x7u;  // 0607F534 cmp/eq #7,r0
    if (c.t) { goto L_0607F5A8; }  // 0607F536 bt 0x0607F5A8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F5C8u);  // 0607F538 mov.w 0x0607F5C8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0607F53A mov.w @(r0,r14),r1
    c.r[1] <<= 16;  // 0607F53C shll16 r1
    c.r[1] <<= 2;  // 0607F53E shll2 r1
    c.r[1] >>= 16;  // 0607F540 shlr16 r1
    c.r[1] += c.r[1];  // 0607F542 add r1,r1
    c.r[1] >>= 8;  // 0607F544 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607F546 tst r1,r1
    if (!c.t) { goto L_0607F5A8; }  // 0607F548 bf 0x0607F5A8
L_0607F54A:
    c.r[2] = ld32(c.r[13]);  // 0607F54A mov.l @r13,r2
    c.r[0] = c.r[2];  // 0607F54C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607F54E mov.b @(r0,r10),r1
    c.r[11] = 0x7Fu;  // 0607F550 mov #127,r11
    c.r[7] = c.r[1] & 0xFFu;  // 0607F552 extu.b r1,r7
    c.r[7] += c.r[7];  // 0607F554 add r7,r7
    c.r[1] = c.r[12] & 0xFFFFu;  // 0607F556 extu.w r12,r1
    c.r[6] = c.r[1];  // 0607F558 mov r1,r6
    c.r[6] >>= 8;  // 0607F55A shlr8 r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607F55C mov.b @(r0,r7),r3
    c.r[6] &= c.r[11];  // 0607F55E and r11,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F5CAu);  // 0607F560 mov.w 0x0607F5CA,r0
    c.r[3] &= c.r[0];  // 0607F562 and r0,r3
    c.r[3] |= c.r[6];  // 0607F564 or r6,r3
    c.r[0] = c.r[2];  // 0607F566 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 0607F568 mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 0607F56A add r7,r2
    c.r[2] += 1;  // 0607F56C add #1,r2
    st8(c.r[2], c.r[1]);  // 0607F56E mov.b r1,@r2
    c.r[2] = ld32(c.r[13]);  // 0607F570 mov.l @r13,r2
    c.r[0] = c.r[2];  // 0607F572 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607F574 mov.b @(r0,r10),r1
    c.r[11] = ld32(0x0607F5D4u);  // 0607F576 mov.l 0x0607F5D4,r11
    c.r[3] = c.r[1] & 0xFFu;  // 0607F578 extu.b r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F5C0u);  // 0607F57A mov.w 0x0607F5C0,r0
    c.r[1] = ld32(c.r[11]);  // 0607F57C mov.l @r11,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0607F57E mov.l @(r0,r14),r0
    c.r[3] += c.r[3];  // 0607F580 add r3,r3
    c.r[1] += c.r[0];  // 0607F582 add r0,r1
    c.r[1] += 3;  // 0607F584 add #3,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607F5CAu);  // 0607F586 mov.w 0x0607F5CA,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F588 mov.b @r1,r1
    c.r[0] = c.r[2];  // 0607F58A mov r2,r0
    c.r[7] = c.r[1];  // 0607F58C mov r1,r7
    c.r[7] <<= 2;  // 0607F58E shll2 r7
    c.r[7] <<= 2;  // 0607F590 shll2 r7
    c.r[7] &= c.r[11];  // 0607F592 and r11,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607F594 mov.b @(r0,r3),r1
    c.r[11] = 0x7Fu;  // 0607F596 mov #127,r11
    c.r[1] &= c.r[11];  // 0607F598 and r11,r1
    c.r[1] |= c.r[7];  // 0607F59A or r7,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0607F59C mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[13]);  // 0607F59E mov.l @r13,r2
    c.r[0] = c.r[2];  // 0607F5A0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607F5A2 mov.b @(r0,r10),r1
    c.r[1] += 1;  // 0607F5A4 add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0607F5A6 mov.b r1,@(r0,r10)
L_0607F5A8:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607F5C0u);  // 0607F5A8 mov.w 0x0607F5C0,r11
    c.r[11] += c.r[14];  // 0607F5AA add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0607F5AC mov.l @r11,r0
    c.r[12] += 1;  // 0607F5AE add #1,r12
    c.r[1] = 0x7Fu;  // 0607F5B0 mov #127,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 0607F5B2 cmp/gt r1,r12
    c.r[0] += 12;  // 0607F5B4 add #12,r0
    st32(c.r[11], c.r[0]); goto L_0607F5EC;  // 0607F5B6 bra 0x0607F5EC ; mov.l r0,@r11
L_0607F5EC:
    if (c.t) { goto L_0607F5F2; }  // 0607F5EC bt 0x0607F5F2
    SH2_POLL(c); goto L_0607F48A;  // 0607F5EE bra 0x0607F48A ; nop
L_0607F5F2:
    c.r[8] = ld32(0x0607F63Cu);  // 0607F5F2 mov.l 0x0607F63C,r8
    c.r[1] = ld32(c.r[8]);  // 0607F5F4 mov.l @r8,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607F632u);  // 0607F5F6 mov.w 0x0607F632,r9
    c.r[0] = c.r[1];  // 0607F5F8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607F5FA mov.b @(r0,r9),r1
    c.r[2] = ld32(0x0607F640u);  // 0607F5FC mov.l 0x0607F640,r2
    st8(c.r[2], c.r[1]);  // 0607F5FE mov.b r1,@r2
    c.r[1] = ld32(0x0607F644u);  // 0607F600 mov.l 0x0607F644,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607F606u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F606u) return; }  // 0607F602 jsr @r1 ; nop
    c.r[1] = ld32(c.r[8]);  // 0607F606 mov.l @r8,r1
    c.r[0] = c.r[1];  // 0607F608 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607F60A mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F60C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607F60E tst r1,r1
    if (!c.t) { goto L_0607F618; }  // 0607F610 bf 0x0607F618
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F634u);  // 0607F612 mov.w 0x0607F634,r0
    goto L_0607F61A;  // 0607F614 bra 0x0607F61A ; nop
L_0607F618:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F636u);  // 0607F618 mov.w 0x0607F636,r0
L_0607F61A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F638u);  // 0607F61A mov.w 0x0607F638,r3
    c.r[14] += c.r[3];  // 0607F61C add r3,r14
    c.r[15] = c.r[14];  // 0607F61E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607F620 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607F622 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607F624 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607F626 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607F628 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607F62A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607F62C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F62E rts ; mov.l @r15+,r8
}

void f_0607F648(SH2Context& c) {
    ran[1777] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607F648 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607F64A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607F64C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607F64E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607F650 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F652 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607F654 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F790u);  // 0607F656 mov.w 0x0607F790,r3
    c.r[7] = ld32(0x0607F7A0u);  // 0607F658 mov.l 0x0607F7A0,r7
    c.r[4] = ld32(c.r[7]);  // 0607F65A mov.l @r7,r4
    c.r[15] += c.r[3];  // 0607F65C add r3,r15
    c.r[1] = c.r[4];  // 0607F65E mov r4,r1
    c.r[1] += 3;  // 0607F660 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F662 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607F664 mov r1,r0
    c.r[0] >>= 2;  // 0607F666 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F668 shlr r0
    c.r[0] &= 0x1u;  // 0607F66A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607F66C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607F676; } }  // 0607F66E bt/s 0x0607F676 ; mov r15,r14
    goto L_0607F7C8;  // 0607F672 bra 0x0607F7C8 ; nop
L_0607F676:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0607F676 mov.w @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607F792u);  // 0607F678 mov.w 0x0607F792,r2
    c.r[1] += c.r[2];  // 0607F67A add r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F67C extu.w r1,r1
    c.r[2] = 0x1u;  // 0607F67E mov #1,r2
    c.t = c.r[1] > c.r[2];  // 0607F680 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0607F690; } }  // 0607F682 bt/s 0x0607F690 ; mov #0,r1
    c.r[1] = ld32(0x0607F7A4u);  // 0607F686 mov.l 0x0607F7A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607F68Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F68Cu) return; }  // 0607F688 jsr @r1 ; nop
    goto L_0607F8C0;  // 0607F68C bra 0x0607F8C0 ; nop
L_0607F690:
    c.r[3] = ld32(0x0607F7A8u);  // 0607F690 mov.l 0x0607F7A8,r3
    c.r[2] = ld32(c.r[3]);  // 0607F692 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F794u);  // 0607F694 mov.w 0x0607F794,r0
    c.r[8] = 0x0u;  // 0607F696 mov #0,r8
    c.r[11] = c.r[7];  // 0607F698 mov r7,r11
    c.r[10] = c.r[3];  // 0607F69A mov r3,r10
    c.r[9] = c.r[0];  // 0607F69C mov r0,r9
    c.r[12] = 0x0u;  // 0607F69E mov #0,r12
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607F6A0 mov.b r1,@(r0,r2)
L_0607F6A2:
    c.r[1] = ld32(0x0607F7ACu);  // 0607F6A2 mov.l 0x0607F7AC,r1
    c.r[2] = ld32(c.r[1]);  // 0607F6A4 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0607F6A6 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0607F6A8 mul.l r1,r8
    c.r[3] = c.macl;  // 0607F6AA sts macl,r3
    c.r[3] += c.r[2];  // 0607F6AC add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607F6AE mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F6B0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607F6B2 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F774; } }  // 0607F6B4 bt/s 0x0607F774 ; mov r8,r1
    c.r[1] = c.r[3];  // 0607F6B8 mov r3,r1
    c.r[1] += 2;  // 0607F6BA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F6BC mov.b @r1,r2
    c.r[1] = ld32(0x0607F7B0u);  // 0607F6BE mov.l 0x0607F7B0,r1
    c.r[1] = ld32(c.r[1]);  // 0607F6C0 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607F6C2 extu.b r2,r2
    c.r[1] += 8;  // 0607F6C4 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F6C6 mov.b @r1,r1
    c.r[2] >>= 2;  // 0607F6C8 shlr2 r2
    c.r[2] >>= 2;  // 0607F6CA shlr2 r2
    c.r[2] >>= 2;  // 0607F6CC shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607F6CE extu.b r1,r1
    c.r[1] >>= 2;  // 0607F6D0 shlr2 r1
    c.r[1] >>= 2;  // 0607F6D2 shlr2 r1
    c.r[1] >>= 2;  // 0607F6D4 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607F6D6 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F774; } }  // 0607F6D8 bf/s 0x0607F774 ; mov r8,r1
    c.r[3] += 15;  // 0607F6DC add #15,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607F6DE mov.b @r3,r2
    c.r[1] = ld32(0x0607F7B4u);  // 0607F6E0 mov.l 0x0607F7B4,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607F6E2 extu.b r2,r2
    c.r[0] = c.r[2];  // 0607F6E4 mov r2,r0
    c.r[0] += c.r[0];  // 0607F6E6 add r0,r0
    c.r[3] = ld32(c.r[1]);  // 0607F6E8 mov.l @r1,r3
    c.r[0] += c.r[2];  // 0607F6EA add r2,r0
    c.r[1] = ld32(c.r[11]);  // 0607F6EC mov.l @r11,r1
    c.r[0] <<= 2;  // 0607F6EE shll2 r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0607F6F0 mov.w @(r0,r3),r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607F6F2 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607F6F4 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F6F6 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0607F6F8 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F774; } }  // 0607F6FA bt/s 0x0607F774 ; mov r8,r1
    c.r[1] = ld32(0x0607F7B8u);  // 0607F6FE mov.l 0x0607F7B8,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607F796u);  // 0607F700 mov.w 0x0607F796,r6
    c.r[5] = c.r[8];  // 0607F702 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607F708u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F708u) return; }  // 0607F704 jsr @r1 ; mov r14,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F798u);  // 0607F708 mov.w 0x0607F798,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607F70A mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0607F70C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F70E shlr r0
    c.r[1] = ld32(c.r[11]);  // 0607F710 mov.l @r11,r1
    c.r[1] += 34;  // 0607F712 add #34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F714 mov.b @r1,r1
    c.r[0] &= 0xFu;  // 0607F716 and #15,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607F718 extu.b r1,r1
    c.r[1] >>= 2;  // 0607F71A shlr2 r1
    c.r[1] >>= 2;  // 0607F71C shlr2 r1
    c.t = c.r[0] == c.r[1];  // 0607F71E cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F774; } }  // 0607F720 bf/s 0x0607F774 ; mov r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F79Au);  // 0607F724 mov.w 0x0607F79A,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607F726 mov.b @(r0,r14),r0
    c.r[0] &= 0xFEu;  // 0607F728 and #254,r0
    c.t = c.r[0] == 0x52u;  // 0607F72A cmp/eq #82,r0
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_0607F776; } }  // 0607F72C bt/s 0x0607F776 ; add #1,r1
    c.r[2] = ld32(c.r[10]);  // 0607F730 mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607F732 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607F734 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F736 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607F738 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F73A mov.b @(r0,r1),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F79Cu);  // 0607F73C mov.w 0x0607F79C,r0
    c.r[3] &= c.r[0];  // 0607F73E and r0,r3
    c.r[0] = c.r[2];  // 0607F740 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607F742 mov.b r3,@(r0,r1)
    c.r[2] += c.r[1];  // 0607F744 add r1,r2
    c.r[2] += 1;  // 0607F746 add #1,r2
    st8(c.r[2], c.r[8]);  // 0607F748 mov.b r8,@r2
    c.r[2] = ld32(c.r[10]);  // 0607F74A mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607F74C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607F74E mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F750 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607F752 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F754 mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 0607F756 mov #127,r0
    c.r[3] &= c.r[0];  // 0607F758 and r0,r3
    c.r[0] = c.r[2];  // 0607F75A mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607F75C mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[10]);  // 0607F75E mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607F760 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607F762 mov.b @(r0,r9),r3
    c.r[1] = c.r[3];  // 0607F764 mov r3,r1
    c.r[1] += 1;  // 0607F766 add #1,r1
    st8(c.r[0] + c.r[9], c.r[1]);  // 0607F768 mov.b r1,@(r0,r9)
    c.r[2] = c.r[3] & 0xFFu;  // 0607F76A extu.b r3,r2
    c.r[1] = ld32(0x0607F7BCu);  // 0607F76C mov.l 0x0607F7BC,r1
    c.r[0] = c.r[2];  // 0607F76E mov r2,r0
    st8(c.r[0] + c.r[1], c.r[12]);  // 0607F770 mov.b r12,@(r0,r1)
    c.r[1] = c.r[8];  // 0607F772 mov r8,r1
L_0607F774:
    c.r[1] += 1;  // 0607F774 add #1,r1
L_0607F776:
    c.r[8] = c.r[1] & 0xFFu;  // 0607F776 extu.b r1,r8
    c.r[1] = 0x7Fu;  // 0607F778 mov #127,r1
    c.t = c.r[8] > c.r[1];  // 0607F77A cmp/hi r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0607F6A2; }  // 0607F77C bf 0x0607F6A2
    c.r[1] = ld32(0x0607F7A8u);  // 0607F77E mov.l 0x0607F7A8,r1
    c.r[1] = ld32(c.r[1]);  // 0607F780 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F794u);  // 0607F782 mov.w 0x0607F794,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F784 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607F7C0u);  // 0607F786 mov.l 0x0607F7C0,r2
    st8(c.r[2], c.r[1]);  // 0607F788 mov.b r1,@r2
    c.r[1] = ld32(0x0607F7C4u);  // 0607F78A mov.l 0x0607F7C4,r1
    goto L_0607F8BC;  // 0607F78C bra 0x0607F8BC ; nop
L_0607F7C8:
    c.r[1] = ld32(0x0607F8F8u);  // 0607F7C8 mov.l 0x0607F8F8,r1
    c.r[2] = ld32(c.r[1]);  // 0607F7CA mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F8ECu);  // 0607F7CC mov.w 0x0607F8EC,r0
    c.r[8] = 0x0u;  // 0607F7CE mov #0,r8
    c.r[10] = c.r[7];  // 0607F7D0 mov r7,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x0607F8EEu);  // 0607F7D2 mov.w 0x0607F8EE,r9
    c.r[9] += c.r[14];  // 0607F7D4 add r14,r9
    c.r[11] = c.r[9];  // 0607F7D6 mov r9,r11
    c.r[11] += 34;  // 0607F7D8 add #34,r11
    c.r[1] = 0x0u;  // 0607F7DA mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0607F7DC mov.b r1,@(r0,r2)
L_0607F7DE:
    c.r[1] = ld32(0x0607F8FCu);  // 0607F7DE mov.l 0x0607F8FC,r1
    c.r[0] = c.r[8];  // 0607F7E0 mov r8,r0
    c.r[0] += c.r[0];  // 0607F7E2 add r0,r0
    c.r[0] += c.r[8];  // 0607F7E4 add r8,r0
    c.r[0] <<= 2;  // 0607F7E6 shll2 r0
    c.r[3] = ld32(c.r[1]);  // 0607F7E8 mov.l @r1,r3
    c.r[7] = c.r[0];  // 0607F7EA mov r0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0607F7EC mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F7EE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607F7F0 tst r1,r1
    { const bool k = c.t; c.r[7] += c.r[3]; if (k) { goto L_0607F8A2; } }  // 0607F7F2 bt/s 0x0607F8A2 ; add r3,r7
    c.r[1] = c.r[7];  // 0607F7F6 mov r7,r1
    c.r[1] += 3;  // 0607F7F8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F7FA mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607F7FC extu.b r1,r2
    c.r[0] = c.r[2];  // 0607F7FE mov r2,r0
    c.r[0] >>= 2;  // 0607F800 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607F802 shlr r0
    c.r[0] &= 0x1u;  // 0607F804 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607F806 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F8A4; } }  // 0607F808 bf/s 0x0607F8A4 ; mov r8,r1
    c.r[2] >>= 2;  // 0607F80C shlr2 r2
    c.r[2] >>= 2;  // 0607F80E shlr2 r2
    c.r[1] = ld32(0x0607F900u);  // 0607F810 mov.l 0x0607F900,r1
    c.r[1] = ld32(c.r[1]);  // 0607F812 mov.l @r1,r1
    c.r[0] = 0x3u;  // 0607F814 mov #3,r0
    c.r[1] += 8;  // 0607F816 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F818 mov.b @r1,r1
    c.r[2] &= c.r[0];  // 0607F81A and r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607F81C extu.b r1,r1
    c.r[1] >>= 2;  // 0607F81E shlr2 r1
    c.r[1] >>= 2;  // 0607F820 shlr2 r1
    c.r[1] >>= 2;  // 0607F822 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607F824 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F8A4; } }  // 0607F826 bf/s 0x0607F8A4 ; mov r8,r1
    c.r[7] += 8;  // 0607F82A add #8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607F82C mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F82E extu.b r1,r1
    c.r[0] = c.r[1];  // 0607F830 mov r1,r0
    c.r[0] += c.r[0];  // 0607F832 add r0,r0
    c.r[0] += c.r[1];  // 0607F834 add r1,r0
    c.r[1] = ld32(c.r[10]);  // 0607F836 mov.l @r10,r1
    c.r[0] <<= 2;  // 0607F838 shll2 r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0607F83A mov.w @(r0,r3),r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607F83C mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607F83E extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F840 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0607F842 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F8A4; } }  // 0607F844 bt/s 0x0607F8A4 ; mov r8,r1
    c.r[1] = ld32(0x0607F904u);  // 0607F848 mov.l 0x0607F904,r1
    c.r[5] = c.r[8];  // 0607F84A mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607F850u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F850u) return; }  // 0607F84C jsr @r1 ; mov r9,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0607F850 mov.b @r11,r2
    c.r[1] = ld32(c.r[10]);  // 0607F852 mov.l @r10,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607F854 extu.b r2,r2
    c.r[1] += 34;  // 0607F856 add #34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607F858 mov.b @r1,r1
    c.r[2] >>= 2;  // 0607F85A shlr2 r2
    c.r[2] >>= 2;  // 0607F85C shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607F85E extu.b r1,r1
    c.r[1] >>= 2;  // 0607F860 shlr2 r1
    c.r[1] >>= 2;  // 0607F862 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607F864 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607F8A4; } }  // 0607F866 bf/s 0x0607F8A4 ; mov r8,r1
    c.r[3] = ld32(0x0607F8F8u);  // 0607F86A mov.l 0x0607F8F8,r3
    c.r[2] = ld32(c.r[3]);  // 0607F86C mov.l @r3,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607F8ECu);  // 0607F86E mov.w 0x0607F8EC,r7
    c.r[0] = c.r[2];  // 0607F870 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607F872 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F874 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607F876 add r1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F878 mov.b @(r0,r1),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F8F0u);  // 0607F87A mov.w 0x0607F8F0,r0
    c.r[6] &= c.r[0];  // 0607F87C and r0,r6
    c.r[0] = c.r[2];  // 0607F87E mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 0607F880 mov.b r6,@(r0,r1)
    c.r[2] += c.r[1];  // 0607F882 add r1,r2
    c.r[2] += 1;  // 0607F884 add #1,r2
    st8(c.r[2], c.r[8]);  // 0607F886 mov.b r8,@r2
    c.r[3] = ld32(c.r[3]);  // 0607F888 mov.l @r3,r3
    c.r[0] = c.r[3];  // 0607F88A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607F88C mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 0607F88E mov r2,r1
    c.r[1] += 1;  // 0607F890 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607F892 mov.b r1,@(r0,r7)
    c.r[1] = c.r[2] & 0xFFu;  // 0607F894 extu.b r2,r1
    c.r[1] += c.r[1];  // 0607F896 add r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F898 mov.b @(r0,r1),r2
    c.r[0] = 0x7Fu;  // 0607F89A mov #127,r0
    c.r[2] &= c.r[0];  // 0607F89C and r0,r2
    c.r[0] = c.r[3];  // 0607F89E mov r3,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0607F8A0 mov.b r2,@(r0,r1)
L_0607F8A2:
    c.r[1] = c.r[8];  // 0607F8A2 mov r8,r1
L_0607F8A4:
    c.r[1] += 1;  // 0607F8A4 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0607F8A6 extu.b r1,r8
    c.r[1] = 0x7Fu;  // 0607F8A8 mov #127,r1
    c.t = c.r[8] > c.r[1];  // 0607F8AA cmp/hi r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0607F7DE; }  // 0607F8AC bf 0x0607F7DE
    c.r[1] = ld32(0x0607F8F8u);  // 0607F8AE mov.l 0x0607F8F8,r1
    c.r[1] = ld32(c.r[1]);  // 0607F8B0 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F8ECu);  // 0607F8B2 mov.w 0x0607F8EC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F8B4 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607F908u);  // 0607F8B6 mov.l 0x0607F908,r2
    st8(c.r[2], c.r[1]);  // 0607F8B8 mov.b r1,@r2
    c.r[1] = ld32(0x0607F90Cu);  // 0607F8BA mov.l 0x0607F90C,r1
L_0607F8BC:
    { const uint32_t x = c.r[1]; c.pr = 0x0607F8C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607F8C0u) return; }  // 0607F8BC jsr @r1 ; nop
L_0607F8C0:
    c.r[1] = ld32(0x0607F8F8u);  // 0607F8C0 mov.l 0x0607F8F8,r1
    c.r[1] = ld32(c.r[1]);  // 0607F8C2 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F8ECu);  // 0607F8C4 mov.w 0x0607F8EC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F8C6 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607F8C8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607F8CA tst r1,r1
    if (!c.t) { goto L_0607F8D4; }  // 0607F8CC bf 0x0607F8D4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F8F2u);  // 0607F8CE mov.w 0x0607F8F2,r0
    goto L_0607F8D6;  // 0607F8D0 bra 0x0607F8D6 ; nop
L_0607F8D4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F8F4u);  // 0607F8D4 mov.w 0x0607F8F4,r0
L_0607F8D6:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F8F6u);  // 0607F8D6 mov.w 0x0607F8F6,r3
    c.r[14] += c.r[3];  // 0607F8D8 add r3,r14
    c.r[15] = c.r[14];  // 0607F8DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607F8DC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607F8DE mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607F8E0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607F8E2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607F8E4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607F8E6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607F8E8 rts ; mov.l @r15+,r8
}

void f_0607F910(SH2Context& c) {
    ran[1778] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607F910 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607F912 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607F914 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607F916 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607F918 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607F91A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607F91C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607F91E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F9BEu);  // 0607F920 mov.w 0x0607F9BE,r3
    c.r[15] += c.r[3];  // 0607F922 add r3,r15
    c.r[14] = c.r[15];  // 0607F924 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F9C0u);  // 0607F926 mov.w 0x0607F9C0,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 0607F928 mov.l r4,@(r0,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607F9C2u);  // 0607F92A mov.w 0x0607F9C2,r1
    c.r[4] = c.r[14];  // 0607F92C mov r14,r4
    c.r[4] += c.r[1];  // 0607F92E add r1,r4
    c.r[3] = 0x4Du;  // 0607F930 mov #77,r3
    c.r[0] = c.r[14];  // 0607F932 mov r14,r0
    st16(c.r[0] + c.r[1], c.r[3]);  // 0607F934 mov.w r3,@(r0,r1)
    c.r[1] = c.r[4];  // 0607F936 mov r4,r1
    c.r[1] += 2;  // 0607F938 add #2,r1
    c.r[2] = 0x4Fu;  // 0607F93A mov #79,r2
    st16(c.r[1], c.r[2]);  // 0607F93C mov.w r2,@r1
    c.r[1] = c.r[4];  // 0607F93E mov r4,r1
    c.r[1] += 4;  // 0607F940 add #4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0607F9C4u);  // 0607F942 mov.w 0x0607F9C4,r5
    st16(c.r[1], c.r[5]);  // 0607F944 mov.w r5,@r1
    c.r[1] = c.r[4];  // 0607F946 mov r4,r1
    c.r[1] += 6;  // 0607F948 add #6,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607F9C6u);  // 0607F94A mov.w 0x0607F9C6,r6
    st16(c.r[1], c.r[6]);  // 0607F94C mov.w r6,@r1
    c.r[1] = c.r[4];  // 0607F94E mov r4,r1
    c.r[1] += 8;  // 0607F950 add #8,r1
    st16(c.r[1], c.r[3]);  // 0607F952 mov.w r3,@r1
    c.r[1] = c.r[4];  // 0607F954 mov r4,r1
    c.r[1] += 10;  // 0607F956 add #10,r1
    st16(c.r[1], c.r[2]);  // 0607F958 mov.w r2,@r1
    c.r[1] = c.r[4];  // 0607F95A mov r4,r1
    c.r[1] += 12;  // 0607F95C add #12,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607F9C8u);  // 0607F95E mov.w 0x0607F9C8,r2
    st16(c.r[1], c.r[2]);  // 0607F960 mov.w r2,@r1
    c.r[1] = c.r[4];  // 0607F962 mov r4,r1
    c.r[1] += 14;  // 0607F964 add #14,r1
    st16(c.r[1], c.r[2]);  // 0607F966 mov.w r2,@r1
    c.r[1] = c.r[4];  // 0607F968 mov r4,r1
    c.r[1] += 16;  // 0607F96A add #16,r1
    c.r[7] = 0x4Eu;  // 0607F96C mov #78,r7
    st16(c.r[1], c.r[7]);  // 0607F96E mov.w r7,@r1
    c.r[1] = c.r[4];  // 0607F970 mov r4,r1
    c.r[1] += 18;  // 0607F972 add #18,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607F9CAu);  // 0607F974 mov.w 0x0607F9CA,r3
    st16(c.r[1], c.r[3]);  // 0607F976 mov.w r3,@r1
    c.r[1] = c.r[4];  // 0607F978 mov r4,r1
    c.r[1] += 20;  // 0607F97A add #20,r1
    st16(c.r[1], c.r[5]);  // 0607F97C mov.w r5,@r1
    c.r[1] = c.r[4];  // 0607F97E mov r4,r1
    c.r[1] += 22;  // 0607F980 add #22,r1
    st16(c.r[1], c.r[6]);  // 0607F982 mov.w r6,@r1
    c.r[1] = c.r[4];  // 0607F984 mov r4,r1
    c.r[1] += 24;  // 0607F986 add #24,r1
    st16(c.r[1], c.r[7]);  // 0607F988 mov.w r7,@r1
    c.r[1] = c.r[4];  // 0607F98A mov r4,r1
    c.r[1] += 26;  // 0607F98C add #26,r1
    st16(c.r[1], c.r[3]);  // 0607F98E mov.w r3,@r1
    c.r[1] = c.r[4];  // 0607F990 mov r4,r1
    c.r[1] += 28;  // 0607F992 add #28,r1
    st16(c.r[1], c.r[2]);  // 0607F994 mov.w r2,@r1
    c.r[1] = c.r[4];  // 0607F996 mov r4,r1
    c.r[1] += 30;  // 0607F998 add #30,r1
    st16(c.r[1], c.r[2]);  // 0607F99A mov.w r2,@r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607F9C0u);  // 0607F99C mov.w 0x0607F9C0,r13
    c.r[13] += c.r[14];  // 0607F99E add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0607F9A0 mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0607F9A2 mov.w @r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607F9CCu);  // 0607F9A4 mov.w 0x0607F9CC,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607F9A6 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0607F9A8 cmp/eq r2,r1
    { const bool k = !c.t; c.r[11] = 0x1u; if (k) { goto L_0607F9D4; } }  // 0607F9AA bf/s 0x0607F9D4 ; mov #1,r11
    c.r[1] = ld32(0x0607F9D0u);  // 0607F9AE mov.l 0x0607F9D0,r1
    c.r[1] = ld32(c.r[1]);  // 0607F9B0 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607F9CEu);  // 0607F9B2 mov.w 0x0607F9CE,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F9B4 mov.b @(r0,r1),r0
    c.r[11] &= c.r[0];  // 0607F9B6 and r0,r11
    c.r[11] <<= 2;  // 0607F9B8 shll2 r11
    c.r[11] <<= 2; goto L_0607F9E4;  // 0607F9BA bra 0x0607F9E4 ; shll2 r11
L_0607F9D4:
    c.r[1] = ld32(0x0607FB44u);  // 0607F9D4 mov.l 0x0607FB44,r1
    c.r[1] = ld32(c.r[1]);  // 0607F9D6 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FB34u);  // 0607F9D8 mov.w 0x0607FB34,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607F9DA mov.b @(r0,r1),r0
    c.r[11] &= c.r[0];  // 0607F9DC and r0,r11
    c.r[11] <<= 2;  // 0607F9DE shll2 r11
    c.r[11] <<= 2;  // 0607F9E0 shll2 r11
    c.r[11] += 8;  // 0607F9E2 add #8,r11
L_0607F9E4:
    c.r[11] += c.r[4];  // 0607F9E4 add r4,r11
    c.r[3] = ld32(0x0607FB48u);  // 0607F9E6 mov.l 0x0607FB48,r3
    c.r[2] = ld32(c.r[3]);  // 0607F9E8 mov.l @r3,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607FB36u);  // 0607F9EA mov.w 0x0607FB36,r7
    c.r[1] = 0x0u;  // 0607F9EC mov #0,r1
    c.r[8] = 0x0u;  // 0607F9EE mov #0,r8
    c.r[12] = 0x1Eu;  // 0607F9F0 mov #30,r12
    c.r[10] = c.r[3];  // 0607F9F2 mov r3,r10
    c.r[9] = c.r[7];  // 0607F9F4 mov r7,r9
    c.r[0] = c.r[2];  // 0607F9F6 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0607F9F8 mov.b r1,@(r0,r7)
    c.macl = c.r[8] * c.r[12];  // 0607F9FA mul.l r12,r8
L_0607F9FC:
    c.r[13] = ld32(0x0607FB4Cu);  // 0607F9FC mov.l 0x0607FB4C,r13
    c.r[1] = ld32(c.r[13]);  // 0607F9FE mov.l @r13,r1
    c.r[3] = c.macl;  // 0607FA00 sts macl,r3
    c.r[3] += c.r[1];  // 0607FA02 add r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607FA04 mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FA06 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607FA08 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0607FAFA; } }  // 0607FA0A bt/s 0x0607FAFA ; mov r8,r1
    c.r[1] = c.r[3];  // 0607FA0E mov r3,r1
    c.r[1] += 2;  // 0607FA10 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FA12 mov.b @r1,r2
    c.r[1] = ld32(0x0607FB44u);  // 0607FA14 mov.l 0x0607FB44,r1
    c.r[7] = ld32(c.r[1]);  // 0607FA16 mov.l @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0607FA18 extu.b r2,r2
    c.r[1] = c.r[7];  // 0607FA1A mov r7,r1
    c.r[1] += 8;  // 0607FA1C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FA1E mov.b @r1,r1
    c.r[2] >>= 2;  // 0607FA20 shlr2 r2
    c.r[2] >>= 2;  // 0607FA22 shlr2 r2
    c.r[2] >>= 2;  // 0607FA24 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607FA26 extu.b r1,r1
    c.r[1] >>= 2;  // 0607FA28 shlr2 r1
    c.r[1] >>= 2;  // 0607FA2A shlr2 r1
    c.r[1] >>= 2;  // 0607FA2C shlr2 r1
    c.t = c.r[2] == c.r[1];  // 0607FA2E cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607FAFA; } }  // 0607FA30 bf/s 0x0607FAFA ; mov r8,r1
    c.r[3] += 15;  // 0607FA34 add #15,r3
    c.r[1] = ld32(0x0607FB50u);  // 0607FA36 mov.l 0x0607FB50,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607FA38 mov.b @r3,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607FB38u);  // 0607FA3A mov.w 0x0607FB38,r13
    c.r[1] = ld32(c.r[1]);  // 0607FA3C mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607FA3E extu.b r2,r2
    c.r[3] = c.r[2];  // 0607FA40 mov r2,r3
    c.r[3] += c.r[3];  // 0607FA42 add r3,r3
    c.r[3] += c.r[2];  // 0607FA44 add r2,r3
    c.r[3] <<= 2;  // 0607FA46 shll2 r3
    c.r[0] = c.r[3];  // 0607FA48 mov r3,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607FA4A mov.w @(r0,r1),r2
    c.r[13] += c.r[14];  // 0607FA4C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0607FA4E mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0607FA50 mov.w @r0,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607FA52 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FA54 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0607FA56 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0607FAFA; } }  // 0607FA58 bt/s 0x0607FAFA ; mov r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FB34u);  // 0607FA5C mov.w 0x0607FB34,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0607FA5E mov.b @(r0,r7),r0
    c.r[0] &= 0x1u;  // 0607FA60 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607FA62 tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[8]; if (k) { goto L_0607FACC; } }  // 0607FA64 bf/s 0x0607FACC ; mov r8,r5
    c.r[1] = ld32(0x0607FB54u);  // 0607FA68 mov.l 0x0607FB54,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607FB3Au);  // 0607FA6A mov.w 0x0607FB3A,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607FA70u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FA70u) return; }  // 0607FA6C jsr @r1 ; mov r14,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FB3Cu);  // 0607FA70 mov.w 0x0607FB3C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607FA72 mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0607FA74 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607FA76 shlr r0
    c.r[0] &= 0xFu;  // 0607FA78 and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607FA7A tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_0607FACE; } }  // 0607FA7C bf/s 0x0607FACE ; mov #0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FB3Eu);  // 0607FA80 mov.w 0x0607FB3E,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0607FA82 mov.b @(r0,r14),r0
    c.r[0] &= 0xFEu;  // 0607FA84 and #254,r0
    c.t = c.r[0] == 0x52u;  // 0607FA86 cmp/eq #82,r0
    if (c.t) { goto L_0607FACE; }  // 0607FA88 bt 0x0607FACE
L_0607FA8A:
    c.r[2] = ld32(c.r[10]);  // 0607FA8A mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607FA8C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607FA8E mov.b @(r0,r9),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0607FB40u);  // 0607FA90 mov.w 0x0607FB40,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0607FA92 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607FA94 add r1,r1
    c.r[2] += c.r[1];  // 0607FA96 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FA98 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 0607FA9A add #1,r2
    c.r[3] &= c.r[13];  // 0607FA9C and r13,r3
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607FA9E mov.b r3,@(r0,r1)
    st8(c.r[2], c.r[8]);  // 0607FAA0 mov.b r8,@r2
    c.r[2] = ld32(c.r[10]);  // 0607FAA2 mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607FAA4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607FAA6 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607FAA8 extu.b r1,r1
    c.r[1] += c.r[1];  // 0607FAAA add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FAAC mov.b @(r0,r1),r3
    c.r[13] = 0x7Fu;  // 0607FAAE mov #127,r13
    c.r[3] &= c.r[13];  // 0607FAB0 and r13,r3
    st8(c.r[0] + c.r[1], c.r[3]);  // 0607FAB2 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[10]);  // 0607FAB4 mov.l @r10,r2
    c.r[0] = c.r[2];  // 0607FAB6 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607FAB8 mov.b @(r0,r9),r3
    c.r[1] = c.r[3];  // 0607FABA mov r3,r1
    c.r[1] += 1;  // 0607FABC add #1,r1
    st8(c.r[0] + c.r[9], c.r[1]);  // 0607FABE mov.b r1,@(r0,r9)
    c.r[2] = c.r[3] & 0xFFu;  // 0607FAC0 extu.b r3,r2
    c.r[1] = ld32(0x0607FB58u);  // 0607FAC2 mov.l 0x0607FB58,r1
    c.r[13] = 0x0u;  // 0607FAC4 mov #0,r13
    c.r[0] = c.r[2];  // 0607FAC6 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[13]); goto L_0607FAF8;  // 0607FAC8 bra 0x0607FAF8 ; mov.b r13,@(r0,r1)
L_0607FACC:
    c.r[3] = 0x0u;  // 0607FACC mov #0,r3
L_0607FACE:
    c.r[0] = ld32(0x0607FB4Cu);  // 0607FACE mov.l 0x0607FB4C,r0
    c.r[7] = ld32(c.r[0]);  // 0607FAD0 mov.l @r0,r7
    c.r[6] = 0x4u;  // 0607FAD2 mov #4,r6
    c.macl = c.r[8] * c.r[12];  // 0607FAD4 mul.l r12,r8
    c.r[1] = c.r[3];  // 0607FAD6 mov r3,r1
L_0607FAD8:
    c.r[2] = c.macl;  // 0607FAD8 sts macl,r2
    c.r[0] = c.r[2];  // 0607FADA mov r2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0607FADC mov.w @(r0,r7),r2
    c.r[1] += c.r[1];  // 0607FADE add r1,r1
    c.r[0] = c.r[1];  // 0607FAE0 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0607FAE2 mov.w @(r0,r11),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607FAE4 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FAE6 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0607FAE8 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { SH2_POLL(c); goto L_0607FA8A; } }  // 0607FAEA bt/s 0x0607FA8A ; mov r3,r1
    c.r[1] += 1;  // 0607FAEE add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607FAF0 extu.b r1,r3
    c.t = c.r[3] > c.r[6];  // 0607FAF2 cmp/hi r6,r3
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { SH2_POLL(c); goto L_0607FAD8; } }  // 0607FAF4 bf/s 0x0607FAD8 ; mov r3,r1
L_0607FAF8:
    c.r[1] = c.r[8];  // 0607FAF8 mov r8,r1
L_0607FAFA:
    c.r[1] += 1;  // 0607FAFA add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0607FAFC extu.b r1,r8
    c.r[1] = 0x7Fu;  // 0607FAFE mov #127,r1
    c.t = c.r[8] > c.r[1];  // 0607FB00 cmp/hi r1,r8
    { const bool k = c.t; c.macl = c.r[8] * c.r[12]; if (k) { goto L_0607FB0A; } }  // 0607FB02 bt/s 0x0607FB0A ; mul.l r12,r8
    SH2_POLL(c); goto L_0607F9FC;  // 0607FB06 bra 0x0607F9FC ; nop
L_0607FB0A:
    c.r[1] = ld32(0x0607FB48u);  // 0607FB0A mov.l 0x0607FB48,r1
    c.r[1] = ld32(c.r[1]);  // 0607FB0C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FB36u);  // 0607FB0E mov.w 0x0607FB36,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FB10 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0607FB5Cu);  // 0607FB12 mov.l 0x0607FB5C,r2
    st8(c.r[2], c.r[1]);  // 0607FB14 mov.b r1,@r2
    c.r[1] = ld32(0x0607FB60u);  // 0607FB16 mov.l 0x0607FB60,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607FB1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FB1Cu) return; }  // 0607FB18 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607FB42u);  // 0607FB1C mov.w 0x0607FB42,r3
    c.r[14] += c.r[3];  // 0607FB1E add r3,r14
    c.r[15] = c.r[14];  // 0607FB20 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607FB22 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607FB24 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607FB26 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607FB28 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607FB2A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607FB2C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607FB2E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FB30 rts ; mov.l @r15+,r8
}

void f_0607FB64(SH2Context& c) {
    ran[1779] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FB64 mov.l r14,@-r15
    c.r[1] = ld32(0x0607FBC4u);  // 0607FB66 mov.l 0x0607FBC4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FB68 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607FB6A extu.b r1,r0
    c.r[1] = ld32(0x0607FBC8u);  // 0607FB6C mov.l 0x0607FBC8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FB6E mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 0607FB70 mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607FB72 extu.b r1,r1
    c.r[1] -= 1;  // 0607FB74 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0607FB76 mul.l r2,r1
    c.r[1] = ld32(0x0607FBCCu);  // 0607FB78 mov.l 0x0607FBCC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FB7A mov.b @(r0,r1),r1
    c.r[3] = c.macl;  // 0607FB7C sts macl,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607FB7E extu.b r1,r1
    c.r[3] += c.r[1];  // 0607FB80 add r1,r3
    c.r[1] = ld32(0x0607FBD0u);  // 0607FB82 mov.l 0x0607FBD0,r1
    c.r[1] = ld32(c.r[1]);  // 0607FB84 mov.l @r1,r1
    c.r[1] += 3;  // 0607FB86 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FB88 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607FB8A mov r1,r0
    c.r[0] >>= 2;  // 0607FB8C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607FB8E shlr r0
    c.r[0] &= 0x1u;  // 0607FB90 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607FB92 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607FBA8; } }  // 0607FB94 bf/s 0x0607FBA8 ; mov r15,r14
    c.r[1] = ld32(0x0607FBD4u);  // 0607FB98 mov.l 0x0607FBD4,r1
    c.r[1] = ld32(c.r[1]);  // 0607FB9A mov.l @r1,r1
    c.r[3] += c.r[3];  // 0607FB9C add r3,r3
    c.r[1] += c.r[3];  // 0607FB9E add r3,r1
    c.r[1] += 1;  // 0607FBA0 add #1,r1
    c.r[2] = ld32(0x0607FBD8u);  // 0607FBA2 mov.l 0x0607FBD8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0607FBB6;  // 0607FBA4 bra 0x0607FBB6 ; mov.b @r1,r1
L_0607FBA8:
    c.r[1] = ld32(0x0607FBD4u);  // 0607FBA8 mov.l 0x0607FBD4,r1
    c.r[1] = ld32(c.r[1]);  // 0607FBAA mov.l @r1,r1
    c.r[3] += c.r[3];  // 0607FBAC add r3,r3
    c.r[1] += c.r[3];  // 0607FBAE add r3,r1
    c.r[1] += 1;  // 0607FBB0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FBB2 mov.b @r1,r1
    c.r[2] = ld32(0x0607FBDCu);  // 0607FBB4 mov.l 0x0607FBDC,r2
L_0607FBB6:
    st8(c.r[2], c.r[1]);  // 0607FBB6 mov.b r1,@r2
    c.r[15] = c.r[14];  // 0607FBB8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FBC0u);  // 0607FBBA mov.w 0x0607FBC0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FBBC rts ; mov.l @r15+,r14
}

void f_0607FBE0(SH2Context& c) {
    ran[1780] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607FBE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607FBE2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FBE4 mov.l r14,@-r15
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607FC94u);  // 0607FBE6 mov.w 0x0607FC94,r4
    c.r[7] = ld32(0x0607FC98u);  // 0607FBE8 mov.l 0x0607FC98,r7
    c.r[5] = ld32(0x0607FC9Cu);  // 0607FBEA mov.l 0x0607FC9C,r5
    c.r[6] = 0x1Eu;  // 0607FBEC mov #30,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607FBEE mov.b @r7,r1
    c.r[9] = c.r[4];  // 0607FBF0 mov r4,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0607FBF2 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 0607FBF4 mul.l r6,r1
    c.r[8] = ld32(0x0607FCA0u);  // 0607FBF6 mov.l 0x0607FCA0,r8
    c.r[2] = ld32(c.r[5]);  // 0607FBF8 mov.l @r5,r2
    c.r[1] = c.macl;  // 0607FBFA sts macl,r1
    c.r[1] += c.r[2];  // 0607FBFC add r2,r1
    c.r[1] += 15;  // 0607FBFE add #15,r1
    st8(c.r[1], c.r[9]);  // 0607FC00 mov.b r9,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FC02 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607FC04 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 0607FC06 mul.l r6,r1
    c.r[2] = ld32(c.r[5]);  // 0607FC08 mov.l @r5,r2
    c.r[3] = c.macl;  // 0607FC0A sts macl,r3
    c.r[3] += c.r[2];  // 0607FC0C add r2,r3
    c.r[1] = ld32(0x0607FCA4u);  // 0607FC0E mov.l 0x0607FCA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FC10 mov.b @r1,r1
    c.r[3] += 15;  // 0607FC12 add #15,r3
    st8(c.r[3], c.r[1]);  // 0607FC14 mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607FC16 mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607FC18 extu.b r1,r2
    c.macl = c.r[2] * c.r[6];  // 0607FC1A mul.l r6,r2
    c.r[3] = ld32(c.r[5]);  // 0607FC1C mov.l @r5,r3
    c.r[1] = c.macl;  // 0607FC1E sts macl,r1
    c.r[0] = c.r[1];  // 0607FC20 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0607FC22 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FC24 extu.w r1,r1
    c.r[0] = c.r[1];  // 0607FC26 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0607FC28 cmp/eq #3,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607FC30; } }  // 0607FC2A bf/s 0x0607FC30 ; mov r15,r14
    c.r[4] = c.r[2];  // 0607FC2E mov r2,r4
L_0607FC30:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FC30 mov.b @r8,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607FC32 extu.b r1,r2
    c.macl = c.r[2] * c.r[6];  // 0607FC34 mul.l r6,r2
    c.r[1] = c.macl;  // 0607FC36 sts macl,r1
    c.r[0] = c.r[1];  // 0607FC38 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0607FC3A mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FC3C extu.w r1,r1
    c.r[0] = c.r[1];  // 0607FC3E mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0607FC40 cmp/eq #3,r0
    if (!c.t) { goto L_0607FC46; }  // 0607FC42 bf 0x0607FC46
    c.r[4] = c.r[2];  // 0607FC44 mov r2,r4
L_0607FC46:
    c.r[1] = c.r[9] & 0xFFu;  // 0607FC46 extu.b r9,r1
    c.t = c.r[4] == c.r[1];  // 0607FC48 cmp/eq r1,r4
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0607FC80; } }  // 0607FC4A bt/s 0x0607FC80 ; mov #0,r7
    c.r[8] = c.r[5];  // 0607FC4E mov r5,r8
    c.r[5] = c.r[6];  // 0607FC50 mov r6,r5
    c.r[2] = 0x7Fu;  // 0607FC52 mov #127,r2
    c.macl = c.r[7] * c.r[5];  // 0607FC54 mul.l r5,r7
L_0607FC56:
    c.r[6] = ld32(c.r[8]);  // 0607FC56 mov.l @r8,r6
    c.r[3] = c.macl;  // 0607FC58 sts macl,r3
    c.r[3] += c.r[6];  // 0607FC5A add r6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607FC5C mov.w @r3,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0607FC5E extu.w r1,r0
    c.t = c.r[0] == 0x2u;  // 0607FC60 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0607FC76; } }  // 0607FC62 bf/s 0x0607FC76 ; mov r7,r1
    c.macl = c.r[4] * c.r[5];  // 0607FC66 mul.l r5,r4
    c.r[1] = c.macl;  // 0607FC68 sts macl,r1
    c.r[1] += c.r[6];  // 0607FC6A add r6,r1
    c.r[1] += 15;  // 0607FC6C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FC6E mov.b @r1,r1
    c.r[3] += 15;  // 0607FC70 add #15,r3
    st8(c.r[3], c.r[1]); goto L_0607FC80;  // 0607FC72 bra 0x0607FC80 ; mov.b r1,@r3
L_0607FC76:
    c.r[1] += 1;  // 0607FC76 add #1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0607FC78 extu.b r1,r7
    c.t = c.r[7] > c.r[2];  // 0607FC7A cmp/hi r2,r7
    { const bool k = !c.t; c.macl = c.r[7] * c.r[5]; if (k) { SH2_POLL(c); goto L_0607FC56; } }  // 0607FC7C bf/s 0x0607FC56 ; mul.l r5,r7
L_0607FC80:
    c.r[1] = ld32(0x0607FC98u);  // 0607FC80 mov.l 0x0607FC98,r1
    c.r[2] = ld32(0x0607FCA0u);  // 0607FC82 mov.l 0x0607FCA0,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607FC84 mov.b @r2,r2
    c.r[15] = c.r[14];  // 0607FC86 mov r14,r15
    st8(c.r[1], c.r[2]);  // 0607FC88 mov.b r2,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607FC8A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607FC8C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FC96u);  // 0607FC8E mov.w 0x0607FC96,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FC90 rts ; mov.l @r15+,r8
}

void f_0607FCA8(SH2Context& c) {
    ran[1781] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FCA8 mov.l r14,@-r15
    c.r[5] = ld32(0x0607FCECu);  // 0607FCAA mov.l 0x0607FCEC,r5
    c.r[7] = ld32(0x0607FCF0u);  // 0607FCAC mov.l 0x0607FCF0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0607FCAE mov.b @r5,r1
    c.r[6] = ld32(0x0607FCF4u);  // 0607FCB0 mov.l 0x0607FCF4,r6
    c.r[2] = ld32(c.r[7]);  // 0607FCB2 mov.l @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607FCB4 extu.b r1,r1
    c.r[3] = c.r[1];  // 0607FCB6 mov r1,r3
    c.r[3] += c.r[3];  // 0607FCB8 add r3,r3
    c.r[3] += c.r[1];  // 0607FCBA add r1,r3
    c.r[3] <<= 2;  // 0607FCBC shll2 r3
    c.r[3] += c.r[2];  // 0607FCBE add r2,r3
    c.r[3] += 8;  // 0607FCC0 add #8,r3
    c.r[1] = 0xFFFFFFFFu;  // 0607FCC2 mov #-1,r1
    st8(c.r[3], c.r[1]);  // 0607FCC4 mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607FCC6 mov.b @r6,r1
    c.r[14] = c.r[15];  // 0607FCC8 mov r15,r14
    c.r[2] = ld32(c.r[7]);  // 0607FCCA mov.l @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607FCCC extu.b r1,r1
    c.r[3] = c.r[1];  // 0607FCCE mov r1,r3
    c.r[3] += c.r[3];  // 0607FCD0 add r3,r3
    c.r[3] += c.r[1];  // 0607FCD2 add r1,r3
    c.r[3] <<= 2;  // 0607FCD4 shll2 r3
    c.r[3] += c.r[2];  // 0607FCD6 add r2,r3
    c.r[1] = ld32(0x0607FCF8u);  // 0607FCD8 mov.l 0x0607FCF8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FCDA mov.b @r1,r1
    c.r[3] += 8;  // 0607FCDC add #8,r3
    st8(c.r[3], c.r[1]);  // 0607FCDE mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607FCE0 mov.b @r6,r1
    st8(c.r[5], c.r[1]);  // 0607FCE2 mov.b r1,@r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FCEAu);  // 0607FCE4 mov.w 0x0607FCEA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FCE6 rts ; mov.l @r15+,r14
}

void f_0607FCFC(SH2Context& c) {
    ran[1782] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FCFC mov.l r14,@-r15
    c.r[1] = ld32(0x0607FD34u);  // 0607FCFE mov.l 0x0607FD34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FD00 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607FD02 extu.b r1,r0
    c.r[1] = ld32(0x0607FD38u);  // 0607FD04 mov.l 0x0607FD38,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FD06 mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 0607FD08 mov #7,r2
    c.r[1] -= 1;  // 0607FD0A add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607FD0C extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0607FD0E mul.l r2,r1
    c.r[14] = c.r[15];  // 0607FD10 mov r15,r14
    c.r[3] = ld32(0x0607FD3Cu);  // 0607FD12 mov.l 0x0607FD3C,r3
    c.r[1] = ld32(0x0607FD40u);  // 0607FD14 mov.l 0x0607FD40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607FD16 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0607FD18 sts macl,r2
    c.r[2] += c.r[1];  // 0607FD1A add r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607FD1C extu.b r2,r2
    c.r[1] = ld32(0x0607FD44u);  // 0607FD1E mov.l 0x0607FD44,r1
    c.r[1] = ld32(c.r[1]);  // 0607FD20 mov.l @r1,r1
    c.r[2] += c.r[2];  // 0607FD22 add r2,r2
    c.r[1] += c.r[2];  // 0607FD24 add r2,r1
    c.r[1] += 1;  // 0607FD26 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FD28 mov.b @r1,r1
    st8(c.r[3], c.r[1]);  // 0607FD2A mov.b r1,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FD32u);  // 0607FD2C mov.w 0x0607FD32,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FD2E rts ; mov.l @r15+,r14
}

void f_0607FD48(SH2Context& c) {
    ran[1783] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607FD48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607FD4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FD4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607FD4E sts.l pr,@-r15
    c.r[8] = ld32(0x0607FDC8u);  // 0607FD50 mov.l 0x0607FDC8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FD52 mov.b @r8,r1
    c.r[9] = ld32(0x0607FDCCu);  // 0607FD54 mov.l 0x0607FDCC,r9
    c.r[4] = ld32(c.r[9]);  // 0607FD56 mov.l @r9,r4
    c.r[5] = c.r[1] & 0xFFu;  // 0607FD58 extu.b r1,r5
    c.r[1] = c.r[5];  // 0607FD5A mov r5,r1
    c.r[1] <<= 2;  // 0607FD5C shll2 r1
    c.r[1] += c.r[5];  // 0607FD5E add r5,r1
    c.r[1] <<= 2;  // 0607FD60 shll2 r1
    c.r[1] += c.r[4];  // 0607FD62 add r4,r1
    c.r[1] += 48;  // 0607FD64 add #48,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607FD66 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607FDBEu);  // 0607FD68 mov.w 0x0607FDBE,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FD6A extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0607FD6C cmp/hi r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607FDB0; } }  // 0607FD6E bt/s 0x0607FDB0 ; mov r15,r14
    c.r[0] = ld32(0x0607FDD0u);  // 0607FD72 mov.l 0x0607FDD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FD78u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FD78u) return; }  // 0607FD74 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0607FD78 extu.b r0,r1
    c.r[3] = c.r[1];  // 0607FD7A mov r1,r3
    c.r[1] = ld32(0x0607FDD4u);  // 0607FD7C mov.l 0x0607FDD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FD7E mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607FD80 extu.b r1,r2
    c.t = c.r[3] >= c.r[2];  // 0607FD82 cmp/hs r2,r3
    { const bool k = c.t; c.r[1] = 0x9u; if (k) { goto L_0607FD8E; } }  // 0607FD84 bt/s 0x0607FD8E ; mov #9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FDC0u);  // 0607FD88 mov.w 0x0607FDC0,r0
    c.r[15] = c.r[14]; goto L_0607FDB4;  // 0607FD8A bra 0x0607FDB4 ; mov r14,r15
L_0607FD8E:
    c.t = c.r[2] > c.r[1];  // 0607FD8E cmp/hi r1,r2
    { const bool k = !c.t; c.t = c.r[3] == c.r[2]; if (k) { goto L_0607FDB0; } }  // 0607FD90 bf/s 0x0607FDB0 ; cmp/eq r2,r3
    if (!c.t) { goto L_0607FDB0; }  // 0607FD94 bf 0x0607FDB0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FD96 mov.b @r8,r5
    c.r[0] = ld32(0x0607FDD8u);  // 0607FD98 mov.l 0x0607FDD8,r0
    c.r[4] = ld32(c.r[9]);  // 0607FD9A mov.l @r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607FDA0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FDA0u) return; }  // 0607FD9C jsr @r0 ; extu.b r5,r5
    c.r[2] = c.r[0] & 0xFFu;  // 0607FDA0 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607FDC2u);  // 0607FDA2 mov.w 0x0607FDC2,r1
    c.t = c.r[2] == c.r[1];  // 0607FDA4 cmp/eq r1,r2
    if (c.t) { goto L_0607FDB0; }  // 0607FDA6 bt 0x0607FDB0
    c.r[15] = c.r[14];  // 0607FDA8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FDC4u);  // 0607FDAA mov.w 0x0607FDC4,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607FDB6;  // 0607FDAC bra 0x0607FDB6 ; lds.l @r15+,pr
L_0607FDB0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FDC6u);  // 0607FDB0 mov.w 0x0607FDC6,r0
    c.r[15] = c.r[14];  // 0607FDB2 mov r14,r15
L_0607FDB4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607FDB4 lds.l @r15+,pr
L_0607FDB6:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607FDB6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607FDB8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FDBA rts ; mov.l @r15+,r8
}

void f_0607FDDC(SH2Context& c) {
    ran[1784] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FDDC mov.l r14,@-r15
    c.r[1] = ld32(0x0607FE10u);  // 0607FDDE mov.l 0x0607FE10,r1
    c.r[3] = ld32(c.r[1]);  // 0607FDE0 mov.l @r1,r3
    c.r[7] = ld32(0x0607FE14u);  // 0607FDE2 mov.l 0x0607FE14,r7
    c.r[1] = c.r[3];  // 0607FDE4 mov r3,r1
    c.r[1] += 10;  // 0607FDE6 add #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607FDE8 mov.w @r1,r2
    c.r[3] += 12;  // 0607FDEA add #12,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607FDEC extu.w r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607FDEE mov.b @r3,r1
    c.r[2] <<= 8;  // 0607FDF0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607FDF2 extu.b r1,r1
    c.r[1] |= c.r[2];  // 0607FDF4 or r2,r1
    c.r[2] = ld32(c.r[7]);  // 0607FDF6 mov.l @r7,r2
    c.t = c.r[2] > c.r[1];  // 0607FDF8 cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607FE04; } }  // 0607FDFA bf/s 0x0607FE04 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FE0Cu);  // 0607FDFE mov.w 0x0607FE0C,r0
    c.r[15] = c.r[14]; goto L_0607FE08;  // 0607FE00 bra 0x0607FE08 ; mov r14,r15
L_0607FE04:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FE0Eu);  // 0607FE04 mov.w 0x0607FE0E,r0
    c.r[15] = c.r[14];  // 0607FE06 mov r14,r15
L_0607FE08:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FE08 rts ; mov.l @r15+,r14
}

void f_0607FE18(SH2Context& c) {
    ran[1785] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607FE18 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607FE1A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607FE1C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607FE1E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607FE20 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607FE22 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FE24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607FE26 sts.l pr,@-r15
    c.r[1] = ld32(0x0607FF74u);  // 0607FE28 mov.l 0x0607FF74,r1
    c.r[3] = ld32(c.r[1]);  // 0607FE2A mov.l @r1,r3
    c.r[7] = c.r[3];  // 0607FE2C mov r3,r7
    c.r[7] += 10;  // 0607FE2E add #10,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0607FE30 mov.w @r7,r1
    c.r[3] += 12;  // 0607FE32 add #12,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607FE34 mov.b @r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607FE36 extu.w r1,r1
    c.r[1] <<= 8;  // 0607FE38 shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607FE3A extu.b r2,r2
    c.r[2] |= c.r[1];  // 0607FE3C or r1,r2
    c.r[1] = ld32(0x0607FF78u);  // 0607FE3E mov.l 0x0607FF78,r1
    c.r[1] = ld32(c.r[1]);  // 0607FE40 mov.l @r1,r1
    c.r[15] -= 8;  // 0607FE42 add #-8,r15
    c.r[2] -= c.r[1];  // 0607FE44 sub r1,r2
    c.r[1] = c.r[2];  // 0607FE46 mov r2,r1
    c.r[1] >>= 8;  // 0607FE48 shlr8 r1
    st16(c.r[7], c.r[1]);  // 0607FE4A mov.w r1,@r7
    st8(c.r[3], c.r[2]);  // 0607FE4C mov.b r2,@r3
    c.r[1] = ld32(0x0607FF7Cu);  // 0607FE4E mov.l 0x0607FF7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FE50 mov.b @r1,r1
    c.r[14] = c.r[15];  // 0607FE52 mov r15,r14
    c.r[9] = c.r[1] & 0xFFu;  // 0607FE54 extu.b r1,r9
    c.r[0] = c.r[9] & 0xFFu;  // 0607FE56 extu.b r9,r0
    st32(c.r[14], c.r[0]);  // 0607FE58 mov.l r0,@r14
    c.r[0] = ld32(0x0607FF80u);  // 0607FE5A mov.l 0x0607FF80,r0
    c.r[4] = ld32(c.r[0]);  // 0607FE5C mov.l @r0,r4
    c.r[6] = 0x0u;  // 0607FE5E mov #0,r6
    c.r[0] = ld32(0x0607FF84u);  // 0607FE60 mov.l 0x0607FF84,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FE66u; c.r[5] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FE66u) return; }  // 0607FE62 jsr @r0 ; mov.l @r14,r5
    c.r[8] = ld32(0x0607FF88u);  // 0607FE66 mov.l 0x0607FF88,r8
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FE68 mov.b @r8,r5
    c.r[0] = ld32(0x0607FF80u);  // 0607FE6A mov.l 0x0607FF80,r0
    c.r[4] = ld32(c.r[0]);  // 0607FE6C mov.l @r0,r4
    c.r[0] = ld32(0x0607FF8Cu);  // 0607FE6E mov.l 0x0607FF8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FE74u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FE74u) return; }  // 0607FE70 jsr @r0 ; extu.b r5,r5
    c.r[1] = c.r[0];  // 0607FE74 mov r0,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0607FE76 extu.b r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FE78 mov.b @r8,r1
    c.r[10] = 0x0u;  // 0607FE7A mov #0,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0607FE7C extu.b r1,r1
    c.r[0] = c.r[1];  // 0607FE7E mov r1,r0
    c.r[0] &= 0x1u;  // 0607FE80 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607FE82 tst r0,r0
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[0]); if (k) { goto L_0607FE8A; } }  // 0607FE84 bf/s 0x0607FE8A ; mov.l r0,@(4,r14)
    c.r[10] = 0x4u;  // 0607FE88 mov #4,r10
L_0607FE8A:
    c.r[12] = ld32(0x0607FF90u);  // 0607FE8A mov.l 0x0607FF90,r12
    c.r[0] = 0x1Eu;  // 0607FE8C mov #30,r0
    c.r[11] = c.r[1];  // 0607FE8E mov r1,r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 0607FE90 shlr r11
    c.r[5] = c.r[10];  // 0607FE92 mov r10,r5
    c.macl = c.r[9] * c.r[0];  // 0607FE94 mul.l r0,r9
    c.r[4] = 0xFu;  // 0607FE96 mov #15,r4
    c.r[8] = ld32(c.r[12]);  // 0607FE98 mov.l @r12,r8
    c.r[9] = c.macl;  // 0607FE9A sts macl,r9
    c.r[8] += c.r[9];  // 0607FE9C add r9,r8
    c.r[8] += c.r[11];  // 0607FE9E add r11,r8
    c.r[0] = ld32(0x0607FF94u);  // 0607FEA0 mov.l 0x0607FF94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FEA6u; c.r[8] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FEA6u) return; }  // 0607FEA2 jsr @r0 ; add #7,r8
    c.r[1] = c.r[0];  // 0607FEA6 mov r0,r1
    c.r[2] = ~c.r[1];  // 0607FEA8 not r1,r2
    c.r[13] += 1;  // 0607FEAA add #1,r13
    c.r[5] = c.r[10];  // 0607FEAC mov r10,r5
    c.r[4] = c.r[13];  // 0607FEAE mov r13,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FEB0 mov.b @r8,r1
    c.r[0] = ld32(0x0607FF94u);  // 0607FEB2 mov.l 0x0607FF94,r0
    c.r[2] &= c.r[1];  // 0607FEB4 and r1,r2
    { const uint32_t x = c.r[0]; c.pr = 0x0607FEBAu; st8(c.r[8], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FEBAu) return; }  // 0607FEB6 jsr @r0 ; mov.b r2,@r8
    c.r[8] = ld32(c.r[12]);  // 0607FEBA mov.l @r12,r8
    c.r[2] = c.r[0];  // 0607FEBC mov r0,r2
    c.r[8] += c.r[9];  // 0607FEBE add r9,r8
    c.r[8] += c.r[11];  // 0607FEC0 add r11,r8
    c.r[8] += 7;  // 0607FEC2 add #7,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FEC4 mov.b @r8,r1
    c.r[10] = ld32(0x0607FF98u);  // 0607FEC6 mov.l 0x0607FF98,r10
    c.r[2] |= c.r[1];  // 0607FEC8 or r1,r2
    st8(c.r[8], c.r[2]);  // 0607FECA mov.b r2,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0607FECC mov.b @r10,r1
    c.r[8] = ld32(0x0607FF9Cu);  // 0607FECE mov.l 0x0607FF9C,r8
    c.r[3] = ld32(c.r[12]);  // 0607FED0 mov.l @r12,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607FED2 extu.b r1,r1
    c.r[0] = c.r[1];  // 0607FED4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607FED6 mov.b @(r0,r8),r2
    c.r[3] += c.r[9];  // 0607FED8 add r9,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607FEDA extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607FEDC mov.w @r3,r1
    c.r[0] = ld32(0x0607FF80u);  // 0607FEDE mov.l 0x0607FF80,r0
    c.r[1] += c.r[2];  // 0607FEE0 add r2,r1
    st16(c.r[3], c.r[1]);  // 0607FEE2 mov.w r1,@r3
    c.r[4] = ld32(c.r[0]);  // 0607FEE4 mov.l @r0,r4
    c.r[6] = 0x0u;  // 0607FEE6 mov #0,r6
    c.r[0] = ld32(0x0607FF84u);  // 0607FEE8 mov.l 0x0607FF84,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FEEEu; c.r[5] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FEEEu) return; }  // 0607FEEA jsr @r0 ; mov.l @r14,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0607FEEE mov.b @r10,r1
    c.r[3] = ld32(c.r[12]);  // 0607FEF0 mov.l @r12,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0607FEF2 extu.b r1,r1
    c.r[0] = c.r[1];  // 0607FEF4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607FEF6 mov.b @(r0,r8),r1
    c.r[3] += c.r[9];  // 0607FEF8 add r9,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607FEFA mov.w @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607FEFC extu.b r1,r1
    c.r[2] -= c.r[1];  // 0607FEFE sub r1,r2
    st16(c.r[3], c.r[2]);  // 0607FF00 mov.w r2,@r3
    c.r[2] -= 3;  // 0607FF02 add #-3,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607FF04 extu.w r2,r2
    c.r[1] = 0x1u;  // 0607FF06 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0607FF08 cmp/hi r1,r2
    if (c.t) { goto L_0607FF58; }  // 0607FF0A bt 0x0607FF58
    c.r[0] = ld32(0x0607FFA0u);  // 0607FF0C mov.l 0x0607FFA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FF12u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FF12u) return; }  // 0607FF0E jsr @r0 ; mov #2,r4
    c.r[1] = c.r[0];  // 0607FF12 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607FF14 extu.b r1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0607FF16 mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607FF18 tst r0,r0
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0607FF20; } }  // 0607FF1A bf/s 0x0607FF20 ; mov #0,r10
    c.r[10] = 0x4u;  // 0607FF1E mov #4,r10
L_0607FF20:
    c.r[0] = 0x1Eu;  // 0607FF20 mov #30,r0
    c.r[5] = c.r[10];  // 0607FF22 mov r10,r5
    c.macl = c.r[1] * c.r[0];  // 0607FF24 mul.l r0,r1
    c.r[4] = 0xFu;  // 0607FF26 mov #15,r4
    c.r[8] = ld32(c.r[12]);  // 0607FF28 mov.l @r12,r8
    c.r[9] = c.macl;  // 0607FF2A sts macl,r9
    c.r[8] += c.r[9];  // 0607FF2C add r9,r8
    c.r[8] += c.r[11];  // 0607FF2E add r11,r8
    c.r[0] = ld32(0x0607FF94u);  // 0607FF30 mov.l 0x0607FF94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607FF36u; c.r[8] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FF36u) return; }  // 0607FF32 jsr @r0 ; add #7,r8
    c.r[1] = c.r[0];  // 0607FF36 mov r0,r1
    c.r[2] = ~c.r[1];  // 0607FF38 not r1,r2
    c.r[5] = c.r[10];  // 0607FF3A mov r10,r5
    c.r[4] = c.r[13];  // 0607FF3C mov r13,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FF3E mov.b @r8,r1
    c.r[0] = ld32(0x0607FF94u);  // 0607FF40 mov.l 0x0607FF94,r0
    c.r[2] &= c.r[1];  // 0607FF42 and r1,r2
    st8(c.r[8], c.r[2]);  // 0607FF44 mov.b r2,@r8
    { const uint32_t x = c.r[0]; c.pr = 0x0607FF4Au; c.r[8] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607FF4Au) return; }  // 0607FF46 jsr @r0 ; mov.l @r12,r8
    c.r[8] += c.r[9];  // 0607FF4A add r9,r8
    c.r[8] += c.r[11];  // 0607FF4C add r11,r8
    c.r[8] += 7;  // 0607FF4E add #7,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607FF50 mov.b @r8,r1
    c.r[2] = c.r[0];  // 0607FF52 mov r0,r2
    c.r[2] |= c.r[1];  // 0607FF54 or r1,r2
    st8(c.r[8], c.r[2]);  // 0607FF56 mov.b r2,@r8
L_0607FF58:
    c.r[14] += 8;  // 0607FF58 add #8,r14
    c.r[15] = c.r[14];  // 0607FF5A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607FF5C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607FF5E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607FF60 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607FF62 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607FF64 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607FF66 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607FF68 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FF70u);  // 0607FF6A mov.w 0x0607FF70,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FF6C rts ; mov.l @r15+,r8
}

void f_0607FFA4(SH2Context& c) {
    ran[1786] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FFA4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607FFA6 mov r15,r14
    c.r[2] = 0x1u;  // 0607FFA8 mov #1,r2
    c.r[1] = ld32(0x0607FFDCu);  // 0607FFAA mov.l 0x0607FFDC,r1
    c.r[7] = ld32(c.r[1]);  // 0607FFAC mov.l @r1,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607FFD4u);  // 0607FFAE mov.w 0x0607FFD4,r3
    c.r[6] = 0x1Du;  // 0607FFB0 mov #29,r6
    c.r[0] = c.r[7];  // 0607FFB2 mov r7,r0
L_0607FFB4:
    c.r[0] += c.r[2];  // 0607FFB4 add r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607FFB6 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607FFB8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607FFBA tst r1,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_0607FFC6; } }  // 0607FFBC bt/s 0x0607FFC6 ; add #1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FFD6u);  // 0607FFC0 mov.w 0x0607FFD6,r0
    c.r[15] = c.r[14]; goto L_0607FFD0;  // 0607FFC2 bra 0x0607FFD0 ; mov r14,r15
L_0607FFC6:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0607FFC6 cmp/gt r6,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_0607FFB4; } }  // 0607FFC8 bf/s 0x0607FFB4 ; mov r7,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607FFD8u);  // 0607FFCC mov.w 0x0607FFD8,r0
    c.r[15] = c.r[14];  // 0607FFCE mov r14,r15
L_0607FFD0:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607FFD0 rts ; mov.l @r15+,r14
}

void f_0607FFE4(SH2Context& c) {
    ran[1787] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607FFE4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607FFE6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607FFE8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607FFEA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607FFEC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607FFEE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607FFF0 mov.l r14,@-r15
    c.r[15] -= 4;  // 0607FFF2 add #-4,r15
    c.r[14] = c.r[15];  // 0607FFF4 mov r15,r14
    c.r[7] = ld32(0x060801A8u);  // 0607FFF6 mov.l 0x060801A8,r7
    c.r[1] = ld32(c.r[7]);  // 0607FFF8 mov.l @r7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060801A0u);  // 0607FFFA mov.w 0x060801A0,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607FFFC mov.b @r1,r2
    c.r[11] = 0x1u;  // 0607FFFE mov #1,r11
    c.r[2] &= c.r[0];  // 06080000 and r0,r2
    st8(c.r[1], c.r[2]);  // 06080002 mov.b r2,@r1
    c.r[1] += 1;  // 06080004 add #1,r1
    c.r[2] = 0x0u;  // 06080006 mov #0,r2
    st8(c.r[1], c.r[2]);  // 06080008 mov.b r2,@r1
    c.r[3] = ld32(c.r[7]);  // 0608000A mov.l @r7,r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x060801A2u);  // 0608000C mov.w 0x060801A2,r13
    c.r[1] = c.r[3];  // 0608000E mov r3,r1
    c.r[1] += 2;  // 06080010 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080012 mov.b @r1,r6
    c.r[3] += 3;  // 06080014 add #3,r3
    c.r[6] &= c.r[0];  // 06080016 and r0,r6
    st8(c.r[1], c.r[6]);  // 06080018 mov.b r6,@r1
    st8(c.r[3], c.r[2]);  // 0608001A mov.b r2,@r3
    c.r[3] = ld32(c.r[7]);  // 0608001C mov.l @r7,r3
    c.r[12] = c.r[7];  // 0608001E mov r7,r12
    c.r[1] = c.r[3];  // 06080020 mov r3,r1
    c.r[1] += 4;  // 06080022 add #4,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080024 mov.b @r1,r6
    c.r[3] += 5;  // 06080026 add #5,r3
    c.r[6] &= c.r[0];  // 06080028 and r0,r6
    st8(c.r[1], c.r[6]);  // 0608002A mov.b r6,@r1
    st8(c.r[3], c.r[2]);  // 0608002C mov.b r2,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x060801A4u);  // 0608002E mov.w 0x060801A4,r3
    c.r[1] = 0x3u;  // 06080030 mov #3,r1
    c.r[2] = ld32(c.r[7]);  // 06080032 mov.l @r7,r2
    c.r[10] = c.r[3];  // 06080034 mov r3,r10
    c.r[0] = c.r[2];  // 06080036 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06080038 mov.b r1,@(r0,r3)
L_0608003A:
    c.r[0] = ld32(0x060801ACu);  // 0608003A mov.l 0x060801AC,r0
    c.r[1] = ld32(c.r[0]);  // 0608003C mov.l @r0,r1
    c.r[1] += c.r[11];  // 0608003E add r11,r1
    c.r[0] = c.r[1];  // 06080040 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06080042 mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080044 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080046 tst r1,r1
    if (!c.t) { goto L_0608004E; }  // 06080048 bf 0x0608004E
    goto L_06080172;  // 0608004A bra 0x06080172 ; nop
L_0608004E:
    c.r[3] = ld32(c.r[12]);  // 0608004E mov.l @r12,r3
    c.r[0] = c.r[3];  // 06080050 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06080052 mov.b @(r0,r10),r2
    c.r[1] = c.r[2];  // 06080054 mov r2,r1
    c.r[1] += 1;  // 06080056 add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 06080058 mov.b r1,@(r0,r10)
    c.r[7] = c.r[2] & 0xFFu;  // 0608005A extu.b r2,r7
    c.r[7] += c.r[7];  // 0608005C add r7,r7
    c.r[1] = c.r[11] & 0xFFFFu;  // 0608005E extu.w r11,r1
    c.r[6] = c.r[1];  // 06080060 mov r1,r6
    c.r[6] >>= 8;  // 06080062 shlr8 r6
    c.r[0] = 0x7Fu;  // 06080064 mov #127,r0
    c.r[6] &= c.r[0];  // 06080066 and r0,r6
    c.r[0] = c.r[3];  // 06080068 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0608006A mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060801A0u);  // 0608006C mov.w 0x060801A0,r0
    c.r[2] &= c.r[0];  // 0608006E and r0,r2
    c.r[2] |= c.r[6];  // 06080070 or r6,r2
    c.r[0] = c.r[3];  // 06080072 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06080074 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06080076 add r7,r3
    c.r[3] += 1;  // 06080078 add #1,r3
    st8(c.r[3], c.r[1]);  // 0608007A mov.b r1,@r3
    c.r[3] = ld32(c.r[12]);  // 0608007C mov.l @r12,r3
    c.r[0] = c.r[3];  // 0608007E mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06080080 mov.b @(r0,r10),r2
    c.r[1] = c.r[2];  // 06080082 mov r2,r1
    c.r[1] += 1;  // 06080084 add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 06080086 mov.b r1,@(r0,r10)
    c.r[0] = ld32(0x060801ACu);  // 06080088 mov.l 0x060801AC,r0
    c.r[1] = ld32(c.r[0]);  // 0608008A mov.l @r0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0608008C extu.b r2,r2
    c.r[1] += c.r[11];  // 0608008E add r11,r1
    c.r[0] = c.r[1];  // 06080090 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06080092 mov.b @(r0,r13),r1
    c.r[2] += c.r[2];  // 06080094 add r2,r2
    c.r[0] = c.r[3];  // 06080096 mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080098 mov.b @(r0,r2),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060801A0u);  // 0608009A mov.w 0x060801A0,r0
    c.r[7] &= c.r[0];  // 0608009C and r0,r7
    c.r[0] = c.r[3];  // 0608009E mov r3,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 060800A0 mov.b r7,@(r0,r2)
    c.r[3] += c.r[2];  // 060800A2 add r2,r3
    c.r[3] += 1;  // 060800A4 add #1,r3
    st8(c.r[3], c.r[1]);  // 060800A6 mov.b r1,@r3
    c.r[2] = ld32(c.r[12]);  // 060800A8 mov.l @r12,r2
    c.r[0] = c.r[2];  // 060800AA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060800AC mov.b @(r0,r10),r1
    c.r[9] = 0x0u;  // 060800AE mov #0,r9
    c.r[3] = c.r[1] & 0xFFu;  // 060800B0 extu.b r1,r3
    c.r[3] += c.r[3];  // 060800B2 add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060800B4 mov.b @(r0,r3),r1
    c.r[8] = 0x0u;  // 060800B6 mov #0,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x060801A0u);  // 060800B8 mov.w 0x060801A0,r0
    c.r[1] &= c.r[0];  // 060800BA and r0,r1
    c.r[0] = c.r[2];  // 060800BC mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060800BE mov.b r1,@(r0,r3)
    c.r[2] += c.r[3];  // 060800C0 add r3,r2
    c.r[2] += 1;  // 060800C2 add #1,r2
    c.r[0] = 0x0u;  // 060800C4 mov #0,r0
    st8(c.r[2], c.r[0]);  // 060800C6 mov.b r0,@r2
L_060800C8:
    c.r[4] = 0x0u;  // 060800C8 mov #0,r4
L_060800CA:
    c.r[1] = ld32(0x060801B0u);  // 060800CA mov.l 0x060801B0,r1
    c.r[2] = ld32(c.r[1]);  // 060800CC mov.l @r1,r2
    c.r[1] = c.r[8];  // 060800CE mov r8,r1
    c.r[1] += c.r[2];  // 060800D0 add r2,r1
    c.r[1] += c.r[4];  // 060800D2 add r4,r1
    c.r[1] += 17;  // 060800D4 add #17,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060800D6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060800D8 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 060800DA cmp/eq r11,r1
    if (!c.t) { goto L_0608011E; }  // 060800DC bf 0x0608011E
    c.r[0] = c.r[8];  // 060800DE mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060800E0 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060800E2 extu.w r1,r1
    c.r[0] = c.r[1];  // 060800E4 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060800E6 cmp/eq #2,r0
    if (c.t) { goto L_0608011E; }  // 060800E8 bt 0x0608011E
    c.r[2] = ld32(c.r[12]);  // 060800EA mov.l @r12,r2
    c.r[3] = 0x7Fu;  // 060800EC mov #127,r3
    c.r[0] = c.r[2];  // 060800EE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060800F0 mov.b @(r0,r10),r1
    c.r[7] = c.r[2];  // 060800F2 mov r2,r7
    c.r[6] = c.r[1] & 0xFFu;  // 060800F4 extu.b r1,r6
    c.r[6] += c.r[6];  // 060800F6 add r6,r6
    c.r[7] += c.r[6];  // 060800F8 add r6,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060800FA mov.b @(r0,r6),r5
    c.r[7] += 1;  // 060800FC add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060800FE mov.b @r7,r1
    c.r[3] &= c.r[5];  // 06080100 and r5,r3
    c.r[3] <<= 8;  // 06080102 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06080104 extu.b r1,r1
    c.r[1] |= c.r[3];  // 06080106 or r3,r1
    c.r[1] += 1;  // 06080108 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0608010A extu.w r1,r1
    c.r[0] = c.r[1];  // 0608010C mov r1,r0
    c.r[0] >>= 8;  // 0608010E shlr8 r0
    c.r[0] &= 0x7Fu;  // 06080110 and #127,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060801A0u);  // 06080112 mov.w 0x060801A0,r3
    c.r[3] &= c.r[5];  // 06080114 and r5,r3
    c.r[3] |= c.r[0];  // 06080116 or r0,r3
    c.r[0] = c.r[2];  // 06080118 mov r2,r0
    st8(c.r[0] + c.r[6], c.r[3]);  // 0608011A mov.b r3,@(r0,r6)
    st8(c.r[7], c.r[1]);  // 0608011C mov.b r1,@r7
L_0608011E:
    c.r[4] += 1;  // 0608011E add #1,r4
    c.r[1] = 0x3u;  // 06080120 mov #3,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 06080122 cmp/gt r1,r4
    if (!c.t) { SH2_POLL(c); goto L_060800CA; }  // 06080124 bf 0x060800CA
    c.r[9] += 1;  // 06080126 add #1,r9
    c.r[1] = 0x7Fu;  // 06080128 mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0608012A cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 30; if (k) { SH2_POLL(c); goto L_060800C8; } }  // 0608012C bf/s 0x060800C8 ; add #30,r8
    c.r[7] = ld32(c.r[12]);  // 06080130 mov.l @r12,r7
    c.r[3] = 0x7Fu;  // 06080132 mov #127,r3
    c.r[0] = c.r[7];  // 06080134 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06080136 mov.b @(r0,r10),r1
    c.r[5] = c.r[7];  // 06080138 mov r7,r5
    c.r[6] = c.r[1] & 0xFFu;  // 0608013A extu.b r1,r6
    c.r[6] += c.r[6];  // 0608013C add r6,r6
    c.r[5] += c.r[6];  // 0608013E add r6,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06080140 mov.b @(r0,r6),r4
    c.r[5] += 1;  // 06080142 add #1,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06080144 mov.b @r5,r2
    c.r[3] &= c.r[4];  // 06080146 and r4,r3
    c.r[3] <<= 8;  // 06080148 shll8 r3
    c.r[0] = ld32(0x060801ACu);  // 0608014A mov.l 0x060801AC,r0
    c.r[1] = ld32(c.r[0]);  // 0608014C mov.l @r0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0608014E extu.b r2,r2
    c.r[1] += c.r[11];  // 06080150 add r11,r1
    c.r[0] = c.r[1];  // 06080152 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06080154 mov.b @(r0,r13),r1
    c.r[2] |= c.r[3];  // 06080156 or r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06080158 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 0608015A cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06080168; } }  // 0608015C bf/s 0x06080168 ; mov r7,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x060801A0u);  // 06080160 mov.w 0x060801A0,r2
    c.r[2] &= c.r[4];  // 06080162 and r4,r2
    st8(c.r[0] + c.r[6], c.r[2]);  // 06080164 mov.b r2,@(r0,r6)
    st8(c.r[5], c.r[1]);  // 06080166 mov.b r1,@r5
L_06080168:
    c.r[2] = ld32(c.r[12]);  // 06080168 mov.l @r12,r2
    c.r[0] = c.r[2];  // 0608016A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0608016C mov.b @(r0,r10),r1
    c.r[1] += 1;  // 0608016E add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 06080170 mov.b r1,@(r0,r10)
L_06080172:
    c.r[11] += 1;  // 06080172 add #1,r11
    c.r[1] = 0x1Du;  // 06080174 mov #29,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06080176 cmp/gt r1,r11
    if (c.t) { goto L_0608017E; }  // 06080178 bt 0x0608017E
    SH2_POLL(c); goto L_0608003A;  // 0608017A bra 0x0608003A ; nop
L_0608017E:
    c.r[14] += 4;  // 0608017E add #4,r14
    c.r[7] = ld32(0x060801B4u);  // 06080180 mov.l 0x060801B4,r7
    c.r[1] = ld32(0x060801A8u);  // 06080182 mov.l 0x060801A8,r1
    c.r[3] = ld32(c.r[1]);  // 06080184 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060801A4u);  // 06080186 mov.w 0x060801A4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06080188 mov.b @(r0,r3),r1
    c.r[2] = ld32(0x060801B8u);  // 0608018A mov.l 0x060801B8,r2
    c.r[2] = ld32(c.r[2]);  // 0608018C mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0608018E extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06080190 dmulu.l r2,r1
    c.r[15] = c.r[14];  // 06080192 mov r14,r15
    c.r[1] = c.mach;  // 06080194 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06080196 shlr r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06080198 mov.b r1,@(r0,r3)
    st8(c.r[7], c.r[1]);  // 0608019A mov.b r1,@r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4; goto L_060801BC;  // 0608019C bra 0x060801BC ; mov.l @r15+,r14
L_060801BC:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060801BC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060801BE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060801C0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060801C2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060801C4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060801CCu);  // 060801C6 mov.w 0x060801CC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060801C8 rts ; mov.l @r15+,r8
}

void f_060801D0(SH2Context& c) {
    ran[1788] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060801D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060801D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060801D4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060801D6 mov r15,r14
    c.r[1] = ld32(0x06080270u);  // 060801D8 mov.l 0x06080270,r1
    c.r[2] = ld32(c.r[1]);  // 060801DA mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080268u);  // 060801DC mov.w 0x06080268,r0
    c.r[5] = 0x0u;  // 060801DE mov #0,r5
    c.r[4] = c.r[0];  // 060801E0 mov r0,r4
    c.r[6] = 0x0u;  // 060801E2 mov #0,r6
    c.r[1] = 0x0u;  // 060801E4 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060801E6 mov.b r1,@(r0,r2)
L_060801E8:
    c.r[7] = 0x0u;  // 060801E8 mov #0,r7
    c.r[1] = c.r[5] & 0xFFFFu;  // 060801EA extu.w r5,r1
    c.r[9] = c.r[1];  // 060801EC mov r1,r9
    c.r[9] >>= 8;  // 060801EE shlr8 r9
    c.r[0] = 0x7Fu;  // 060801F0 mov #127,r0
    c.r[9] &= c.r[0];  // 060801F2 and r0,r9
    c.r[8] = c.r[1];  // 060801F4 mov r1,r8
L_060801F6:
    c.r[1] = ld32(0x06080274u);  // 060801F6 mov.l 0x06080274,r1
    c.r[3] = ld32(c.r[1]);  // 060801F8 mov.l @r1,r3
    c.r[1] = c.r[6];  // 060801FA mov r6,r1
    c.r[1] += c.r[3];  // 060801FC add r3,r1
    c.r[1] += c.r[7];  // 060801FE add r7,r1
    c.r[1] += 17;  // 06080200 add #17,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080202 mov.b @r1,r2
    c.r[1] = ld32(0x06080278u);  // 06080204 mov.l 0x06080278,r1
    c.r[1] = ld32(c.r[1]);  // 06080206 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06080208 extu.b r2,r2
    c.t = c.r[2] == c.r[1];  // 0608020A cmp/eq r1,r2
    if (!c.t) { goto L_0608023E; }  // 0608020C bf 0x0608023E
    c.r[0] = c.r[6];  // 0608020E mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06080210 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06080212 extu.w r1,r1
    c.r[0] = c.r[1];  // 06080214 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06080216 cmp/eq #2,r0
    if (c.t) { goto L_0608023E; }  // 06080218 bt 0x0608023E
    c.r[1] = ld32(0x06080270u);  // 0608021A mov.l 0x06080270,r1
    c.r[3] = ld32(c.r[1]);  // 0608021C mov.l @r1,r3
    c.r[0] = c.r[3];  // 0608021E mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06080220 mov.b @(r0,r4),r2
    c.r[1] = c.r[2];  // 06080222 mov r2,r1
    c.r[1] += 1;  // 06080224 add #1,r1
    st8(c.r[0] + c.r[4], c.r[1]);  // 06080226 mov.b r1,@(r0,r4)
    c.r[2] = c.r[2] & 0xFFu;  // 06080228 extu.b r2,r2
    c.r[2] += c.r[2];  // 0608022A add r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0608022C mov.b @(r0,r2),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608026Au);  // 0608022E mov.w 0x0608026A,r0
    c.r[1] &= c.r[0];  // 06080230 and r0,r1
    c.r[1] |= c.r[9];  // 06080232 or r9,r1
    c.r[0] = c.r[3];  // 06080234 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06080236 mov.b r1,@(r0,r2)
    c.r[3] += c.r[2];  // 06080238 add r2,r3
    c.r[3] += 1;  // 0608023A add #1,r3
    st8(c.r[3], c.r[8]);  // 0608023C mov.b r8,@r3
L_0608023E:
    c.r[7] += 1;  // 0608023E add #1,r7
    c.r[1] = 0x3u;  // 06080240 mov #3,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06080242 cmp/gt r1,r7
    if (!c.t) { SH2_POLL(c); goto L_060801F6; }  // 06080244 bf 0x060801F6
    c.r[5] += 1;  // 06080246 add #1,r5
    c.r[1] = 0x7Fu;  // 06080248 mov #127,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0608024A cmp/gt r1,r5
    { const bool k = !c.t; c.r[6] += 30; if (k) { SH2_POLL(c); goto L_060801E8; } }  // 0608024C bf/s 0x060801E8 ; add #30,r6
    c.r[2] = ld32(0x0608027Cu);  // 06080250 mov.l 0x0608027C,r2
    c.r[1] = ld32(0x06080270u);  // 06080252 mov.l 0x06080270,r1
    c.r[1] = ld32(c.r[1]);  // 06080254 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080268u);  // 06080256 mov.w 0x06080268,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080258 mov.b @(r0,r1),r1
    c.r[15] = c.r[14];  // 0608025A mov r14,r15
    st8(c.r[2], c.r[1]);  // 0608025C mov.b r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608025E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06080260 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608026Cu);  // 06080262 mov.w 0x0608026C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080264 rts ; mov.l @r15+,r8
}

void f_06080280(SH2Context& c) {
    ran[1789] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080280 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06080282 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06080284 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06080286 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06080288 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608028A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608028C sts.l pr,@-r15
    c.r[1] = ld32(0x06080404u);  // 0608028E mov.l 0x06080404,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080290 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06080292 extu.b r1,r2
    c.r[1] = ld32(0x06080408u);  // 06080294 mov.l 0x06080408,r1
    c.r[0] = c.r[2];  // 06080296 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080298 mov.b @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060803FEu);  // 0608029A mov.w 0x060803FE,r3
    c.r[7] = c.r[1] & 0xFFu;  // 0608029C extu.b r1,r7
    c.r[1] = ld32(0x0608040Cu);  // 0608029E mov.l 0x0608040C,r1
    c.r[2] = ld32(c.r[1]);  // 060802A0 mov.l @r1,r2
    c.r[15] += c.r[3];  // 060802A2 add r3,r15
    c.r[1] = c.r[7];  // 060802A4 mov r7,r1
    c.r[1] += c.r[1];  // 060802A6 add r1,r1
    c.r[0] = c.r[2];  // 060802A8 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060802AA mov.b @(r0,r1),r3
    c.r[0] = 0x7Fu;  // 060802AC mov #127,r0
    c.r[3] &= c.r[0];  // 060802AE and r0,r3
    c.r[3] <<= 8;  // 060802B0 shll8 r3
    c.r[1] += c.r[2];  // 060802B2 add r2,r1
    c.r[1] += 1;  // 060802B4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060802B6 mov.b @r1,r1
    c.r[0] = c.r[2];  // 060802B8 mov r2,r0
    c.r[5] = c.r[1] & 0xFFu;  // 060802BA extu.b r1,r5
    c.r[5] |= c.r[3];  // 060802BC or r3,r5
    c.r[3] = c.r[7];  // 060802BE mov r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080400u);  // 060802C0 mov.w 0x06080400,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060802C2 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 060802C4 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060802C6 extu.b r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060802C8 cmp/gt r1,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06080398; } }  // 060802CA bt/s 0x06080398 ; mov r15,r14
    c.r[9] = 0x0u;  // 060802CE mov #0,r9
    c.r[10] = ld32(0x06080410u);  // 060802D0 mov.l 0x06080410,r10
    c.r[11] = 0x1Eu;  // 060802D2 mov #30,r11
    c.r[12] = ld32(0x06080414u);  // 060802D4 mov.l 0x06080414,r12
L_060802D6:
    c.r[1] = ld32(0x0608040Cu);  // 060802D6 mov.l 0x0608040C,r1
    c.r[2] = c.r[7];  // 060802D8 mov r7,r2
    c.r[1] = ld32(c.r[1]);  // 060802DA mov.l @r1,r1
    c.r[2] += c.r[2];  // 060802DC add r2,r2
    c.r[0] = c.r[1];  // 060802DE mov r1,r0
    c.r[1] += c.r[2];  // 060802E0 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060802E2 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 060802E4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060802E6 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 060802E8 mov #127,r0
    c.r[3] &= c.r[0];  // 060802EA and r0,r3
    c.r[3] <<= 8;  // 060802EC shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 060802EE extu.b r1,r1
    c.r[1] |= c.r[3];  // 060802F0 or r3,r1
    c.macl = c.r[1] * c.r[11];  // 060802F2 mul.l r11,r1
    c.r[3] = ld32(c.r[10]);  // 060802F4 mov.l @r10,r3
    c.r[1] = c.macl;  // 060802F6 sts macl,r1
    c.r[1] += c.r[3];  // 060802F8 add r3,r1
    c.r[1] += c.r[9];  // 060802FA add r9,r1
    c.r[1] += 17;  // 060802FC add #17,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060802FE mov.b @r1,r2
    c.r[1] = ld32(0x06080418u);  // 06080300 mov.l 0x06080418,r1
    c.r[1] = ld32(c.r[1]);  // 06080302 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06080304 extu.b r2,r2
    c.t = c.r[2] == c.r[1];  // 06080306 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_06080392; } }  // 06080308 bf/s 0x06080392 ; mov #3,r1
    c.r[1] = 0x0u;  // 0608030C mov #0,r1
    c.macl = c.r[5] * c.r[11];  // 0608030E mul.l r11,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06080402u);  // 06080310 mov.w 0x06080402,r6
    c.r[4] = c.r[14];  // 06080312 mov r14,r4
    c.r[8] = c.macl;  // 06080314 sts macl,r8
    c.r[3] += c.r[8];  // 06080316 add r8,r3
    c.r[3] += c.r[9];  // 06080318 add r9,r3
    c.r[3] += 17;  // 0608031A add #17,r3
    st8(c.r[3], c.r[1]);  // 0608031C mov.b r1,@r3
    { const uint32_t x = c.r[12]; c.pr = 0x06080322u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080322u) return; }  // 0608031E jsr @r12 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 06080322 mov r14,r1
    c.r[3] = ld32(c.r[10]);  // 06080324 mov.l @r10,r3
    c.r[1] += 26;  // 06080326 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080328 mov.w @r1,r1
    c.r[3] += c.r[8];  // 0608032A add r8,r3
    c.r[2] = c.r[3];  // 0608032C mov r3,r2
    c.r[2] += 22;  // 0608032E add #22,r2
    st16(c.r[2], c.r[1]);  // 06080330 mov.w r1,@r2
    c.r[2] = c.r[3];  // 06080332 mov r3,r2
    c.r[1] = c.r[14];  // 06080334 mov r14,r1
    c.r[1] += 28;  // 06080336 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080338 mov.w @r1,r1
    c.r[2] += 24;  // 0608033A add #24,r2
    st16(c.r[2], c.r[1]);  // 0608033C mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608033E mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06080340 extu.w r1,r1
    c.r[0] = c.r[1];  // 06080342 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06080344 cmp/eq #3,r0
    { const bool k = !c.t; c.r[4] = 0x2u; if (k) { goto L_06080350; } }  // 06080346 bf/s 0x06080350 ; mov #2,r4
    c.r[0] = ld32(0x0608041Cu);  // 0608034A mov.l 0x0608041C,r0
    goto L_06080358;  // 0608034C bra 0x06080358 ; nop
L_06080350:
    c.t = c.r[0] == 0x2u;  // 06080350 cmp/eq #2,r0
    { const bool k = !c.t; c.r[4] = 0x3u; if (k) { goto L_06080398; } }  // 06080352 bf/s 0x06080398 ; mov #3,r4
    c.r[0] = ld32(0x0608041Cu);  // 06080356 mov.l 0x0608041C,r0
L_06080358:
    { const uint32_t x = c.r[0]; c.pr = 0x0608035Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608035Cu) return; }  // 06080358 jsr @r0 ; nop
    c.r[5] = c.r[0] & 0xFFu;  // 0608035C extu.b r0,r5
    c.r[1] = 0x0u;  // 0608035E mov #0,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06080402u);  // 06080360 mov.w 0x06080402,r6
    c.macl = c.r[5] * c.r[11];  // 06080362 mul.l r11,r5
    c.r[4] = c.r[14];  // 06080364 mov r14,r4
    c.r[2] = ld32(c.r[10]);  // 06080366 mov.l @r10,r2
    c.r[8] = c.macl;  // 06080368 sts macl,r8
    c.r[2] += c.r[8];  // 0608036A add r8,r2
    c.r[2] += c.r[9];  // 0608036C add r9,r2
    c.r[2] += 17;  // 0608036E add #17,r2
    st8(c.r[2], c.r[1]);  // 06080370 mov.b r1,@r2
    { const uint32_t x = c.r[12]; c.pr = 0x06080376u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080376u) return; }  // 06080372 jsr @r12 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 06080376 mov r14,r1
    c.r[3] = ld32(c.r[10]);  // 06080378 mov.l @r10,r3
    c.r[1] += 26;  // 0608037A add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608037C mov.w @r1,r1
    c.r[3] += c.r[8];  // 0608037E add r8,r3
    c.r[2] = c.r[3];  // 06080380 mov r3,r2
    c.r[2] += 22;  // 06080382 add #22,r2
    st16(c.r[2], c.r[1]);  // 06080384 mov.w r1,@r2
    c.r[1] = c.r[14];  // 06080386 mov r14,r1
    c.r[1] += 28;  // 06080388 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608038A mov.w @r1,r1
    c.r[3] += 24;  // 0608038C add #24,r3
    st16(c.r[3], c.r[1]); goto L_06080398;  // 0608038E bra 0x06080398 ; mov.w r1,@r3
L_06080392:
    c.r[9] += 1;  // 06080392 add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06080394 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_060802D6; }  // 06080396 bf 0x060802D6
L_06080398:
    c.r[8] = ld32(0x06080420u);  // 06080398 mov.l 0x06080420,r8
    c.r[11] = ld32(0x06080410u);  // 0608039A mov.l 0x06080410,r11
    c.r[10] = 0x1Eu;  // 0608039C mov #30,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0608039E mov.b @r8,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06080402u);  // 060803A0 mov.w 0x06080402,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060803A2 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060803A4 mul.l r10,r1
    c.r[9] = ld32(0x06080424u);  // 060803A6 mov.l 0x06080424,r9
    c.r[2] = ld32(c.r[11]);  // 060803A8 mov.l @r11,r2
    c.r[3] = c.macl;  // 060803AA sts macl,r3
    c.r[1] = ld32(0x06080428u);  // 060803AC mov.l 0x06080428,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060803AE mov.b @r1,r1
    c.r[3] += c.r[2];  // 060803B0 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060803B2 extu.b r1,r1
    c.r[3] += c.r[1];  // 060803B4 add r1,r3
    c.r[1] = ld32(0x0608042Cu);  // 060803B6 mov.l 0x0608042C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060803B8 mov.b @r1,r1
    c.r[3] += 17;  // 060803BA add #17,r3
    st8(c.r[3], c.r[1]);  // 060803BC mov.b r1,@r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060803BE mov.b @r8,r5
    c.r[1] = ld32(0x06080414u);  // 060803C0 mov.l 0x06080414,r1
    c.r[4] = ld32(c.r[9]);  // 060803C2 mov.l @r9,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060803C8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060803C8u) return; }  // 060803C4 jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060803C8 mov.b @r8,r1
    c.r[3] = ld32(c.r[11]);  // 060803CA mov.l @r11,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060803CC extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060803CE mul.l r10,r1
    c.r[7] = ld32(c.r[9]);  // 060803D0 mov.l @r9,r7
    c.r[2] = c.macl;  // 060803D2 sts macl,r2
    c.r[2] += c.r[3];  // 060803D4 add r3,r2
    c.r[3] = c.r[2];  // 060803D6 mov r2,r3
    c.r[3] += 22;  // 060803D8 add #22,r3
    c.r[1] = c.r[7];  // 060803DA mov r7,r1
    c.r[1] += 26;  // 060803DC add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060803DE mov.w @r1,r1
    c.r[7] += 28;  // 060803E0 add #28,r7
    st16(c.r[3], c.r[1]);  // 060803E2 mov.w r1,@r3
    c.r[3] = c.r[2];  // 060803E4 mov r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060803E6 mov.w @r7,r1
    c.r[3] += 24;  // 060803E8 add #24,r3
    st16(c.r[3], c.r[1]);  // 060803EA mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060803EC mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060803EE extu.w r1,r1
    c.r[0] = c.r[1];  // 060803F0 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 060803F2 cmp/eq #3,r0
    { const bool k = !c.t; c.r[4] = 0x2u; if (k) { goto L_06080430; } }  // 060803F4 bf/s 0x06080430 ; mov #2,r4
    c.r[0] = ld32(0x0608041Cu);  // 060803F8 mov.l 0x0608041C,r0
    goto L_0608043E;  // 060803FA bra 0x0608043E ; nop
L_06080430:
    c.t = c.r[0] == 0x2u;  // 06080430 cmp/eq #2,r0
    { const bool k = c.t; c.r[4] = 0x3u; if (k) { goto L_0608043C; } }  // 06080432 bt/s 0x0608043C ; mov #3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608049Cu);  // 06080436 mov.w 0x0608049C,r0
    goto L_06080486;  // 06080438 bra 0x06080486 ; nop
L_0608043C:
    c.r[0] = ld32(0x060804A4u);  // 0608043C mov.l 0x060804A4,r0
L_0608043E:
    { const uint32_t x = c.r[0]; c.pr = 0x06080442u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080442u) return; }  // 0608043E jsr @r0 ; nop
    c.r[5] = c.r[0] & 0xFFu;  // 06080442 extu.b r0,r5
    c.r[9] = ld32(0x060804A8u);  // 06080444 mov.l 0x060804A8,r9
    c.r[1] = 0x1Eu;  // 06080446 mov #30,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0608049Eu);  // 06080448 mov.w 0x0608049E,r6
    c.macl = c.r[5] * c.r[1];  // 0608044A mul.l r1,r5
    c.r[4] = c.r[14];  // 0608044C mov r14,r4
    c.r[2] = ld32(c.r[9]);  // 0608044E mov.l @r9,r2
    c.r[8] = c.macl;  // 06080450 sts macl,r8
    c.r[2] += c.r[8];  // 06080452 add r8,r2
    c.r[1] = ld32(0x060804ACu);  // 06080454 mov.l 0x060804AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080456 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080458 extu.b r1,r1
    c.r[2] += c.r[1];  // 0608045A add r1,r2
    c.r[1] = ld32(0x060804B0u);  // 0608045C mov.l 0x060804B0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608045E mov.b @r1,r1
    c.r[2] += 17;  // 06080460 add #17,r2
    st8(c.r[2], c.r[1]);  // 06080462 mov.b r1,@r2
    c.r[1] = ld32(0x060804B4u);  // 06080464 mov.l 0x060804B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608046Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608046Au) return; }  // 06080466 jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 0608046A mov r14,r1
    c.r[1] += 26;  // 0608046C add #26,r1
    c.r[3] = ld32(c.r[9]);  // 0608046E mov.l @r9,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608049Cu);  // 06080470 mov.w 0x0608049C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080472 mov.w @r1,r1
    c.r[3] += c.r[8];  // 06080474 add r8,r3
    c.r[2] = c.r[3];  // 06080476 mov r3,r2
    c.r[2] += 22;  // 06080478 add #22,r2
    st16(c.r[2], c.r[1]);  // 0608047A mov.w r1,@r2
    c.r[1] = c.r[14];  // 0608047C mov r14,r1
    c.r[1] += 28;  // 0608047E add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080480 mov.w @r1,r1
    c.r[3] += 24;  // 06080482 add #24,r3
    st16(c.r[3], c.r[1]);  // 06080484 mov.w r1,@r3
L_06080486:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060804A0u);  // 06080486 mov.w 0x060804A0,r3
    c.r[14] += c.r[3];  // 06080488 add r3,r14
    c.r[15] = c.r[14];  // 0608048A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608048C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608048E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06080490 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06080492 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06080494 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06080496 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080498 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
