#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06046D2C(SH2Context& c) {
    ran[1142] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046D2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06046D2E sts.l pr,@-r15
    c.r[15] -= 60;  // 06046D30 add #-60,r15
    c.r[14] = c.r[15];  // 06046D32 mov r15,r14
    c.r[5] = ld32(0x06046DD4u);  // 06046D34 mov.l 0x06046DD4,r5
    c.r[1] = ld32(0x06046DD8u);  // 06046D36 mov.l 0x06046DD8,r1
    c.r[6] = 0x3Cu;  // 06046D38 mov #60,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06046D3Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046D3Eu) return; }  // 06046D3A jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x06046DDCu);  // 06046D3E mov.l 0x06046DDC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046D40 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06046D42 extu.b r1,r2
    c.r[1] = 0x3u;  // 06046D44 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 06046D46 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06046DBC; } }  // 06046D48 bt/s 0x06046DBC ; mov r2,r1
    c.r[1] += c.r[1];  // 06046D4C add r1,r1
    c.r[0] = 0x06046D58u;  // 06046D4E mova 0x06046D58,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06046D50 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06046D52 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06046D60u: goto L_06046D60; case 0x06046D78u: goto L_06046D78; case 0x06046D9Cu: goto L_06046D9C; case 0x06046DA2u: goto L_06046DA2; default: sh2_call(c, x); return; } }  // 06046D54 jmp @r0 ; nop
L_06046D60:
    c.r[2] = ld32(0x06046DE0u);  // 06046D60 mov.l 0x06046DE0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046D62 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046D64 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06046D66 tst r1,r1
    if (c.t) { goto L_06046D72; }  // 06046D68 bt 0x06046D72
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046D6A mov.b @r2,r1
    c.r[1] -= 1;  // 06046D6C add #-1,r1
    st8(c.r[2], c.r[1]);  // 06046D6E mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046D70 mov.b @r2,r1
L_06046D72:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046DC8u);  // 06046D72 mov.w 0x06046DC8,r0
    c.r[14] += 60; goto L_06046DC0;  // 06046D74 bra 0x06046DC0 ; add #60,r14
L_06046D78:
    c.r[7] = ld32(0x06046DE4u);  // 06046D78 mov.l 0x06046DE4,r7
    c.r[3] = ld32(0x06046DE0u);  // 06046D7A mov.l 0x06046DE0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046D7C mov.b @r3,r1
    c.r[2] = 0x3Bu;  // 06046D7E mov #59,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046D80 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06046D82 cmp/hi r2,r1
    if (c.t) { goto L_06046D8E; }  // 06046D84 bt 0x06046D8E
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046D86 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046D88 extu.b r1,r1
    c.r[1] += c.r[14]; goto L_06046D92;  // 06046D8A bra 0x06046D92 ; add r14,r1
L_06046D8E:
    c.r[1] = c.r[14];  // 06046D8E mov r14,r1
    c.r[1] += 59;  // 06046D90 add #59,r1
L_06046D92:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046D92 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046DCAu);  // 06046D94 mov.w 0x06046DCA,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06046D96 extu.b r1,r1
    st16(c.r[7], c.r[1]); goto L_06046DBE;  // 06046D98 bra 0x06046DBE ; mov.w r1,@r7
L_06046D9C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046DCCu);  // 06046D9C mov.w 0x06046DCC,r0
    c.r[14] += 60; goto L_06046DC0;  // 06046D9E bra 0x06046DC0 ; add #60,r14
L_06046DA2:
    c.r[3] = ld32(0x06046DE0u);  // 06046DA2 mov.l 0x06046DE0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046DA4 mov.b @r3,r1
    c.r[2] = 0x3Au;  // 06046DA6 mov #58,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046DA8 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06046DAA cmp/hi r2,r1
    if (c.t) { goto L_06046DB6; }  // 06046DAC bt 0x06046DB6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046DAE mov.b @r3,r1
    c.r[1] += 1;  // 06046DB0 add #1,r1
    st8(c.r[3], c.r[1]);  // 06046DB2 mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046DB4 mov.b @r3,r1
L_06046DB6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046DCEu);  // 06046DB6 mov.w 0x06046DCE,r0
    c.r[14] += 60; goto L_06046DC0;  // 06046DB8 bra 0x06046DC0 ; add #60,r14
L_06046DBC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046DD0u);  // 06046DBC mov.w 0x06046DD0,r0
L_06046DBE:
    c.r[14] += 60;  // 06046DBE add #60,r14
L_06046DC0:
    c.r[15] = c.r[14];  // 06046DC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06046DC2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046DC4 rts ; mov.l @r15+,r14
}

void f_06046DE8(SH2Context& c) {
    ran[1143] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046DE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06046DEA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06046DEC mov r15,r14
    c.r[2] = 0x0u;  // 06046DEE mov #0,r2
    c.r[6] = 0x1Fu;  // 06046DF0 mov #31,r6
    c.r[7] = ld32(0x06046EA8u);  // 06046DF2 mov.l 0x06046EA8,r7
    c.r[3] = 0x0u;  // 06046DF4 mov #0,r3
    c.r[1] = c.r[2];  // 06046DF6 mov r2,r1
L_06046DF8:
    c.r[1] <<= 2;  // 06046DF8 shll2 r1
    c.r[1] += c.r[7];  // 06046DFA add r7,r1
    c.r[1] += 108;  // 06046DFC add #108,r1
    st32(c.r[1], c.r[3]);  // 06046DFE mov.l r3,@r1
    c.r[1] = c.r[2];  // 06046E00 mov r2,r1
    c.r[1] += 1;  // 06046E02 add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06046E04 extu.w r1,r2
    c.t = c.r[2] > c.r[6];  // 06046E06 cmp/hi r6,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_06046DF8; } }  // 06046E08 bf/s 0x06046DF8 ; mov r2,r1
    c.r[1] = ld32(0x06046EACu);  // 06046E0C mov.l 0x06046EAC,r1
    c.r[4] = ld32(c.r[1] + 12);  // 06046E0E mov.l @(12,r1),r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x06046EA4u);  // 06046E10 mov.w 0x06046EA4,r6
    c.r[4] += c.r[1];  // 06046E12 add r1,r4
    c.r[7] = c.r[4];  // 06046E14 mov r4,r7
    c.r[7] += 20;  // 06046E16 add #20,r7
    c.r[1] = c.r[4];  // 06046E18 mov r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06046E1A mov.b @r7,r2
    c.r[1] += 21;  // 06046E1C add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046E1E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06046E20 extu.b r2,r2
    c.r[2] <<= 8;  // 06046E22 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046E24 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06046E26 or r1,r2
    c.r[1] = c.r[6] & 0xFFFFu;  // 06046E28 extu.w r6,r1
    c.t = c.r[2] == c.r[1];  // 06046E2A cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06046E62; } }  // 06046E2C bt/s 0x06046E62 ; mov r7,r1
    c.r[1] = ld32(0x06046EB0u);  // 06046E30 mov.l 0x06046EB0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046E32 mov.b @r1,r1
    c.r[3] = c.r[4];  // 06046E34 mov r4,r3
    c.r[3] += 21;  // 06046E36 add #21,r3
    c.r[5] = c.r[1] & 0xFFu;  // 06046E38 extu.b r1,r5
L_06046E3A:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06046E3A mov.b @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046E3C mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06046E3E extu.b r2,r2
    c.r[2] <<= 8;  // 06046E40 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046E42 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06046E44 or r1,r2
    c.t = c.r[2] == c.r[5];  // 06046E46 cmp/eq r5,r2
    if (c.t) { goto L_06046E60; }  // 06046E48 bt 0x06046E60
    c.r[7] += 6;  // 06046E4A add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06046E4C mov.b @r7,r1
    c.r[3] += 6;  // 06046E4E add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046E50 mov.b @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06046E52 extu.b r1,r1
    c.r[1] <<= 8;  // 06046E54 shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 06046E56 extu.b r2,r2
    c.r[1] |= c.r[2];  // 06046E58 or r2,r1
    c.r[2] = c.r[6] & 0xFFFFu;  // 06046E5A extu.w r6,r2
    c.t = c.r[1] == c.r[2];  // 06046E5C cmp/eq r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06046E3A; }  // 06046E5E bf 0x06046E3A
L_06046E60:
    c.r[1] = c.r[7];  // 06046E60 mov r7,r1
L_06046E62:
    c.r[1] += 2;  // 06046E62 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046E64 mov.b @r1,r5
    c.r[0] = ld32(0x06046EB4u);  // 06046E66 mov.l 0x06046EB4,r0
    c.r[1] = c.r[7];  // 06046E68 mov r7,r1
    c.r[1] += 3;  // 06046E6A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046E6C mov.b @r1,r1
    c.r[5] <<= 16;  // 06046E6E shll16 r5
    c.r[5] <<= 8;  // 06046E70 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 06046E72 extu.b r1,r1
    c.r[1] <<= 16;  // 06046E74 shll16 r1
    c.r[5] |= c.r[1];  // 06046E76 or r1,r5
    c.r[1] = c.r[7];  // 06046E78 mov r7,r1
    c.r[1] += 4;  // 06046E7A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046E7C mov.b @r1,r1
    c.r[7] += 5;  // 06046E7E add #5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06046E80 extu.b r1,r1
    c.r[1] <<= 8;  // 06046E82 shll8 r1
    c.r[5] |= c.r[1];  // 06046E84 or r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06046E86 mov.b @r7,r1
    c.r[6] = 0x4u;  // 06046E88 mov #4,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06046E8A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06046E90u; c.r[5] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046E90u) return; }  // 06046E8C jsr @r0 ; or r1,r5
    c.r[2] = ld32(0x06046EB8u);  // 06046E90 mov.l 0x06046EB8,r2
    c.r[1] = 0x0u;  // 06046E92 mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 06046E94 mov.l r1,@(12,r2)
    c.r[1] = ld32(0x06046EBCu);  // 06046E96 mov.l 0x06046EBC,r1
    st32(c.r[2] + 4, c.r[1]);  // 06046E98 mov.l r1,@(4,r2)
    c.r[15] = c.r[14];  // 06046E9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06046E9C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06046EA6u);  // 06046E9E mov.w 0x06046EA6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06046EA0 rts ; mov.l @r15+,r14
}

void f_06046EC4(SH2Context& c) {
    ran[1144] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06046EC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06046EC6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06046EC8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06046ECA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06046ECC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06046ECE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06046ED0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06046ED2 sts.l pr,@-r15
    c.r[12] = ld32(0x06047098u);  // 06046ED4 mov.l 0x06047098,r12
    c.r[13] = c.r[12];  // 06046ED6 mov r12,r13
    c.r[13] += 66;  // 06046ED8 add #66,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 06046EDA mov.w @r13,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06046EDC extu.w r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06046EDE tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06046EF2; } }  // 06046EE0 bt/s 0x06046EF2 ; mov r15,r14
    c.t = c.r[0] == 0x8u;  // 06046EE4 cmp/eq #8,r0
    { const bool k = c.t; c.r[1] = 0x10u; if (k) { goto L_06046EEE; } }  // 06046EE6 bt/s 0x06046EEE ; mov #16,r1
    goto L_060471B2;  // 06046EEA bra 0x060471B2 ; nop
L_06046EEE:
    st16(c.r[13], c.r[1]); goto L_060471B2;  // 06046EEE bra 0x060471B2 ; mov.w r1,@r13
L_06046EF2:
    c.r[8] = ld32(0x0604709Cu);  // 06046EF2 mov.l 0x0604709C,r8
    c.r[1] = ld32(c.r[8] + 12);  // 06046EF4 mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06046EF6 tst r1,r1
    { const bool k = c.t; c.r[1] -= 1; if (k) { goto L_06046F00; } }  // 06046EF8 bt/s 0x06046F00 ; add #-1,r1
    st32(c.r[8] + 12, c.r[1]); goto L_060471B2;  // 06046EFC bra 0x060471B2 ; mov.l r1,@(12,r8)
L_06046F00:
    c.r[3] = ld32(c.r[8] + 4);  // 06046F00 mov.l @(4,r8),r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06046F02 tst r3,r3
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06046F0C; } }  // 06046F04 bf/s 0x06046F0C ; mov #0,r0
    goto L_060471B4;  // 06046F08 bra 0x060471B4 ; nop
L_06046F0C:
    c.r[2] = c.r[3];  // 06046F0C mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06046F0E mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046F10 extu.b r1,r1
    c.r[0] = c.r[1];  // 06046F12 mov r1,r0
    c.r[0] <<= 8;  // 06046F14 shll8 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046F16 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046F18 extu.b r1,r1
    c.r[0] |= c.r[1];  // 06046F1A or r1,r0
    c.r[1] = 0x12u;  // 06046F1C mov #18,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06046F1E cmp/gt r1,r0
    { const bool k = c.t; c.r[2] = 0x10u; if (k) { goto L_06046F38; } }  // 06046F20 bt/s 0x06046F38 ; mov #16,r2
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[2];  // 06046F24 cmp/ge r2,r0
    { const bool k = c.t; c.r[11] = 0x7Fu; if (k) { goto L_06046F4A; } }  // 06046F26 bt/s 0x06046F4A ; mov #127,r11
    c.t = c.r[0] == 0xFu;  // 06046F2A cmp/eq #15,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06046F34; } }  // 06046F2C bf/s 0x06046F34 ; mov #0,r0
    goto L_06047108;  // 06046F30 bra 0x06047108 ; nop
L_06046F34:
    c.r[15] = c.r[14]; goto L_060471B6;  // 06046F34 bra 0x060471B6 ; mov r14,r15
L_06046F38:
    c.r[1] = ld32(0x060470A0u);  // 06046F38 mov.l 0x060470A0,r1
    c.t = c.r[0] == c.r[1];  // 06046F3A cmp/eq r1,r0
    if (c.t) { goto L_06046F42; }  // 06046F3C bt 0x06046F42
    goto L_060471B2;  // 06046F3E bra 0x060471B2 ; nop
L_06046F42:
    c.r[15] = c.r[14];  // 06046F42 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604708Eu);  // 06046F44 mov.w 0x0604708E,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060471B8;  // 06046F46 bra 0x060471B8 ; lds.l @r15+,pr
L_06046F4A:
    c.r[1] = c.r[3];  // 06046F4A mov r3,r1
    c.r[1] += 2;  // 06046F4C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046F4E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046F50 extu.b r1,r1
    c.r[10] = c.r[1];  // 06046F52 mov r1,r10
    c.r[10] <<= 8;  // 06046F54 shll8 r10
    c.r[1] = c.r[3];  // 06046F56 mov r3,r1
    c.r[1] += 3;  // 06046F58 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046F5A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046F5C extu.b r1,r1
    c.r[10] |= c.r[1];  // 06046F5E or r1,r10
    c.r[10] >>= 2;  // 06046F60 shlr2 r10
    c.r[10] >>= 2;  // 06046F62 shlr2 r10
    c.r[10] >>= 2;  // 06046F64 shlr2 r10
    c.r[1] = c.r[3];  // 06046F66 mov r3,r1
    c.r[1] += 4;  // 06046F68 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046F6A mov.b @r1,r1
    c.r[3] += 5;  // 06046F6C add #5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06046F6E extu.b r1,r1
    c.r[0] = c.r[1];  // 06046F70 mov r1,r0
    c.r[0] <<= 8;  // 06046F72 shll8 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06046F74 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046F76 extu.b r1,r1
    c.r[0] |= c.r[1];  // 06046F78 or r1,r0
    c.r[9] = c.r[0];  // 06046F7A mov r0,r9
    c.r[9] >>= 2;  // 06046F7C shlr2 r9
    c.r[9] >>= 2;  // 06046F7E shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06046F80 shlr r9
    c.r[9] >>= 2;  // 06046F82 shlr2 r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047090u);  // 06046F84 mov.w 0x06047090,r1
    c.t = c.r[10] == c.r[1];  // 06046F86 cmp/eq r1,r10
    { const bool k = !c.t; c.r[11] &= c.r[0]; if (k) { goto L_06046F9A; } }  // 06046F88 bf/s 0x06046F9A ; and r0,r11
    c.r[1] = ld32(0x060470A4u);  // 06046F8C mov.l 0x060470A4,r1
    c.r[1] = ld32(c.r[1]);  // 06046F8E mov.l @r1,r1
    c.r[1] += 8;  // 06046F90 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046F92 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06046F94 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06046F96 tst r0,r0
    if (c.t) { goto L_06046FA8; }  // 06046F98 bt 0x06046FA8
L_06046F9A:
    c.r[0] = ld32(0x060470A8u);  // 06046F9A mov.l 0x060470A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06046FA0u; c.r[4] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046FA0u) return; }  // 06046F9C jsr @r0 ; mov #22,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06046FA0 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06046FA2 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0604702C; } }  // 06046FA4 bt/s 0x0604702C ; mov r8,r2
L_06046FA8:
    c.r[8] = ld32(0x0604709Cu);  // 06046FA8 mov.l 0x0604709C,r8
    c.r[2] = c.r[8];  // 06046FAA mov r8,r2
    c.r[2] += 1;  // 06046FAC add #1,r2
    c.r[4] = ld32(0x060470ACu);  // 06046FAE mov.l 0x060470AC,r4
    c.r[0] = ld32(0x060470B0u);  // 06046FB0 mov.l 0x060470B0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046FB2 mov.b @r2,r1
    c.r[5] = 0x5u;  // 06046FB4 mov #5,r5
    c.r[1] += 1;  // 06046FB6 add #1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06046FBCu; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06046FBCu) return; }  // 06046FB8 jsr @r0 ; mov.b r1,@r2
    c.r[7] = c.r[0];  // 06046FBC mov r0,r7
    c.r[0] = c.r[9];  // 06046FBE mov r9,r0
    c.r[0] += c.r[0];  // 06046FC0 add r0,r0
    c.r[0] += c.r[9];  // 06046FC2 add r9,r0
    c.r[2] = c.r[0];  // 06046FC4 mov r0,r2
    c.r[2] += c.r[7];  // 06046FC6 add r7,r2
    c.r[1] = c.r[2];  // 06046FC8 mov r2,r1
    c.r[1] += 1;  // 06046FCA add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06046FCC mov.b @(r0,r7),r3
    c.r[2] += 2;  // 06046FCE add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046FD0 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06046FD2 extu.b r3,r3
    c.r[3] <<= 16;  // 06046FD4 shll16 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06046FD6 extu.b r1,r1
    c.r[1] <<= 8;  // 06046FD8 shll8 r1
    c.r[3] |= c.r[1];  // 06046FDA or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06046FDC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06046FDE extu.b r1,r1
    c.r[3] |= c.r[1];  // 06046FE0 or r1,r3
    c.r[3] += c.r[7];  // 06046FE2 add r7,r3
    c.r[1] = c.r[11];  // 06046FE4 mov r11,r1
    c.r[1] -= 1;  // 06046FE6 add #-1,r1
    c.r[2] = c.r[1];  // 06046FE8 mov r1,r2
    c.r[2] += c.r[2];  // 06046FEA add r2,r2
    c.r[2] += c.r[1];  // 06046FEC add r1,r2
    c.r[2] += c.r[2];  // 06046FEE add r2,r2
    c.r[3] += c.r[2];  // 06046FF0 add r2,r3
    c.r[1] = c.r[3];  // 06046FF2 mov r3,r1
    c.r[1] += 3;  // 06046FF4 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06046FF6 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06046FF8 extu.b r2,r2
    c.r[2] <<= 16;  // 06046FFA shll16 r2
    c.r[1] = c.r[3];  // 06046FFC mov r3,r1
    c.r[1] += 4;  // 06046FFE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047000 mov.b @r1,r1
    c.r[3] += 5;  // 06047002 add #5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06047004 extu.b r1,r1
    c.r[1] <<= 8;  // 06047006 shll8 r1
    c.r[2] |= c.r[1];  // 06047008 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604700A mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604700C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604700E or r1,r2
    c.r[2] += 1;  // 06047010 add #1,r2
    c.r[1] = ld32(0x060470B4u);  // 06047012 mov.l 0x060470B4,r1
    c.r[1] = ld32(c.r[1]);  // 06047014 mov.l @r1,r1
    c.r[2] <<= 2;  // 06047016 shll2 r2
    c.r[2] <<= 2;  // 06047018 shll2 r2
    c.r[2] <<= 2;  // 0604701A shll2 r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0604701C dmulu.l r1,r2
    c.r[1] = c.mach;  // 0604701E sts mach,r1
    c.r[2] -= c.r[1];  // 06047020 sub r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06047022 shlr r2
    c.r[1] += c.r[2];  // 06047024 add r2,r1
    c.r[1] >>= 8;  // 06047026 shlr8 r1
    st32(c.r[8] + 12, c.r[1]); goto L_060470FE;  // 06047028 bra 0x060470FE ; mov.l r1,@(12,r8)
L_0604702C:
    c.r[2] += 1;  // 0604702C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604702E mov.b @r2,r1
    c.r[9] <<= 2;  // 06047030 shll2 r9
    c.r[9] <<= 2;  // 06047032 shll2 r9
    c.r[9] += c.r[9];  // 06047034 add r9,r9
    c.r[9] <<= 2;  // 06047036 shll2 r9
    c.r[11] -= 1;  // 06047038 add #-1,r11
    c.r[9] |= c.r[11];  // 0604703A or r11,r9
    c.r[11] = ld32(0x060470ACu);  // 0604703C mov.l 0x060470AC,r11
    c.r[8] = ld32(0x060470B0u);  // 0604703E mov.l 0x060470B0,r8
    c.r[5] = 0x1Cu;  // 06047040 mov #28,r5
    c.r[4] = c.r[11];  // 06047042 mov r11,r4
    c.r[1] += 1;  // 06047044 add #1,r1
    st8(c.r[2], c.r[1]);  // 06047046 mov.b r1,@r2
    c.r[2] = c.r[12];  // 06047048 mov r12,r2
    c.r[2] += 68;  // 0604704A add #68,r2
    c.r[1] = 0x1u;  // 0604704C mov #1,r1
    st16(c.r[2], c.r[1]);  // 0604704E mov.w r1,@r2
    c.r[1] = c.r[12];  // 06047050 mov r12,r1
    c.r[1] += 70;  // 06047052 add #70,r1
    st16(c.r[1], c.r[9]);  // 06047054 mov.w r9,@r1
    c.r[1] = 0x2u;  // 06047056 mov #2,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0604705Cu; st16(c.r[13], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604705Cu) return; }  // 06047058 jsr @r8 ; mov.w r1,@r13
    c.r[5] = c.r[10];  // 0604705C mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06047062u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047062u) return; }  // 0604705E jsr @r8 ; mov r0,r4
    c.r[5] = 0x1Cu;  // 06047062 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06047068u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047068u) return; }  // 06047064 jsr @r8 ; mov r11,r4
    c.r[5] = c.r[10];  // 06047068 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604706Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604706Eu) return; }  // 0604706A jsr @r8 ; mov r0,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x06047092u);  // 0604706E mov.w 0x06047092,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047094u);  // 06047070 mov.w 0x06047094,r1
    c.r[1] += c.r[10];  // 06047072 add r10,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06047074 extu.w r1,r1
    c.r[2] = 0x1u;  // 06047076 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 06047078 cmp/hi r2,r1
    { const bool k = c.t; c.r[5] = 0x1Cu; if (k) { goto L_060470B8; } }  // 0604707A bt/s 0x060470B8 ; mov #28,r5
    c.r[1] = ld32(0x060470A4u);  // 0604707E mov.l 0x060470A4,r1
    c.r[1] = ld32(c.r[1]);  // 06047080 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047096u);  // 06047082 mov.w 0x06047096,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06047084 mov.b @(r0,r1),r0
    c.r[12] += 64;  // 06047086 add #64,r12
    c.r[0] &= 0x1u;  // 06047088 and #1,r0
    st16(c.r[12], c.r[0]); goto L_060470FE;  // 0604708A bra 0x060470FE ; mov.w r0,@r12
L_060470B8:
    { const uint32_t x = c.r[8]; c.pr = 0x060470BCu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060470BCu) return; }  // 060470B8 jsr @r8 ; mov r11,r4
    c.r[5] = c.r[10];  // 060470BC mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060470C2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060470C2u) return; }  // 060470BE jsr @r8 ; mov r0,r4
    c.r[9] = c.r[0];  // 060470C2 mov r0,r9
    c.r[5] = 0x1Cu;  // 060470C4 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060470CAu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060470CAu) return; }  // 060470C6 jsr @r8 ; mov r11,r4
    c.r[5] = c.r[10];  // 060470CA mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060470D0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060470D0u) return; }  // 060470CC jsr @r8 ; mov r0,r4
    c.r[0] += 1;  // 060470D0 add #1,r0
    c.r[7] = ld32(0x060471D0u);  // 060470D2 mov.l 0x060471D0,r7
    c.r[2] = c.r[12];  // 060470D4 mov r12,r2
    c.r[2] += 64;  // 060470D6 add #64,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060470D8 mov.b @r9,r4
    c.r[3] = 0x0u;  // 060470DA mov #0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060470DC mov.b @r0,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060470DE extu.b r4,r4
    c.r[4] <<= 8;  // 060470E0 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 060470E2 extu.b r1,r1
    c.r[4] |= c.r[1];  // 060470E4 or r1,r4
    { const uint32_t x = c.r[7]; c.pr = 0x060470EAu; c.r[4] &= c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060470EAu) return; }  // 060470E6 jsr @r7 ; and r13,r4
    c.r[0] = c.r[4] & 0xFFFFu;  // 060470EA extu.w r4,r0
    c.r[1] = 0x6u;  // 060470EC mov #6,r1
    c.t = c.r[0] > c.r[1];  // 060470EE cmp/hi r1,r0
    { const bool k = !c.t; c.t = c.r[0] == 0x11u; if (k) { goto L_060470FA; } }  // 060470F0 bf/s 0x060470FA ; cmp/eq #17,r0
    { const bool k = c.t; c.t = c.r[0] == 0x14u; if (k) { goto L_060470FA; } }  // 060470F4 bt/s 0x060470FA ; cmp/eq #20,r0
    if (!c.t) { goto L_060470FC; }  // 060470F8 bf 0x060470FC
L_060470FA:
    c.r[3] = 0x1u;  // 060470FA mov #1,r3
L_060470FC:
    st16(c.r[2], c.r[3]);  // 060470FC mov.w r3,@r2
L_060470FE:
    c.r[1] = ld32(0x060471D4u);  // 060470FE mov.l 0x060471D4,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06047100 mov.l @(4,r1),r2
    c.r[2] += 10;  // 06047102 add #10,r2
    st32(c.r[1] + 4, c.r[2]); goto L_060471B2;  // 06047104 bra 0x060471B2 ; mov.l r2,@(4,r1)
L_06047108:
    c.r[1] = ld32(0x060471D8u);  // 06047108 mov.l 0x060471D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604710A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604710C extu.b r1,r1
    c.r[1] += 1;  // 0604710E add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06047110 cmp/gt r2,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_060471A6; } }  // 06047112 bt/s 0x060471A6 ; add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06047116 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06047118 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604711A mov r1,r2
    c.r[2] <<= 8;  // 0604711C shll8 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060471C8u);  // 0604711E mov.w 0x060471C8,r1
    c.t = c.r[2] == c.r[1];  // 06047120 cmp/eq r1,r2
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0604714E; } }  // 06047122 bt/s 0x0604714E ; mov #0,r6
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06047126 cmp/gt r1,r2
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06047132; } }  // 06047128 bt/s 0x06047132 ; tst r2,r2
    if (!c.t) { goto L_06047168; }  // 0604712C bf 0x06047168
    goto L_06047146;  // 0604712E bra 0x06047146 ; nop
L_06047132:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060471CAu);  // 06047132 mov.w 0x060471CA,r1
    c.t = c.r[2] == c.r[1];  // 06047134 cmp/eq r1,r2
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06047156; } }  // 06047136 bt/s 0x06047156 ; mov #0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060471CCu);  // 0604713A mov.w 0x060471CC,r1
    c.t = c.r[2] == c.r[1];  // 0604713C cmp/eq r1,r2
    { const bool k = c.t; c.r[5] = 0x78u; if (k) { goto L_0604715E; } }  // 0604713E bt/s 0x0604715E ; mov #120,r5
    goto L_06047168;  // 06047142 bra 0x06047168 ; nop
L_06047146:
    c.r[1] = ld32(0x060471DCu);  // 06047146 mov.l 0x060471DC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047148 mov.b @r1,r4
    c.r[5] = 0x75u; goto L_06047162;  // 0604714A bra 0x06047162 ; mov #117,r5
L_0604714E:
    c.r[1] = ld32(0x060471DCu);  // 0604714E mov.l 0x060471DC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047150 mov.b @r1,r4
    c.r[5] = 0x76u; goto L_06047162;  // 06047152 bra 0x06047162 ; mov #118,r5
L_06047156:
    c.r[1] = ld32(0x060471DCu);  // 06047156 mov.l 0x060471DC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047158 mov.b @r1,r4
    c.r[5] = 0x77u; goto L_06047162;  // 0604715A bra 0x06047162 ; mov #119,r5
L_0604715E:
    c.r[1] = ld32(0x060471DCu);  // 0604715E mov.l 0x060471DC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047160 mov.b @r1,r4
L_06047162:
    c.r[1] = ld32(0x060471E0u);  // 06047162 mov.l 0x060471E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047168u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047168u) return; }  // 06047164 jsr @r1 ; extu.b r4,r4
L_06047168:
    c.r[1] = ld32(0x060471D4u);  // 06047168 mov.l 0x060471D4,r1
    c.r[1] = ld32(c.r[1] + 4);  // 0604716A mov.l @(4,r1),r1
    c.r[1] += 3;  // 0604716C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604716E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06047170 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047172 tst r1,r1
    { const bool k = c.t; c.r[5] = 0x4u; if (k) { goto L_06047184; } }  // 06047174 bt/s 0x06047184 ; mov #4,r5
    c.r[8] = ld32(0x060471E4u);  // 06047178 mov.l 0x060471E4,r8
    c.r[3] = c.r[8];  // 0604717A mov r8,r3
    c.r[3] += 68;  // 0604717C add #68,r3
    c.r[0] = ld32(0x060471E8u);  // 0604717E mov.l 0x060471E8,r0
    c.r[5] = 0x5u; goto L_0604718C;  // 06047180 bra 0x0604718C ; mov #5,r5
L_06047184:
    c.r[8] = ld32(0x060471E4u);  // 06047184 mov.l 0x060471E4,r8
    c.r[3] = c.r[8];  // 06047186 mov r8,r3
    c.r[3] += 68;  // 06047188 add #68,r3
    c.r[0] = ld32(0x060471E8u);  // 0604718A mov.l 0x060471E8,r0
L_0604718C:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604718C mov.b @r3,r2
    c.r[4] = 0x3u;  // 0604718E mov #3,r4
    c.r[1] = c.r[2];  // 06047190 mov r2,r1
    c.r[1] += 1;  // 06047192 add #1,r1
    st8(c.r[3], c.r[1]);  // 06047194 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 06047196 extu.b r2,r2
    c.r[2] <<= 2;  // 06047198 shll2 r2
    c.r[1] = ld32(c.r[8]);  // 0604719A mov.l @r8,r1
    c.r[2] += c.r[8];  // 0604719C add r8,r2
    c.r[1] -= 1;  // 0604719E add #-1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060471A4u; st32(c.r[2] + 4, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060471A4u) return; }  // 060471A0 jsr @r0 ; mov.l r1,@(4,r2)
    st32(c.r[8], c.r[0]);  // 060471A4 mov.l r0,@r8
L_060471A6:
    c.r[1] = ld32(0x060471D4u);  // 060471A6 mov.l 0x060471D4,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060471A8 mov.l @(4,r1),r2
    c.r[0] = ld32(0x060471ECu);  // 060471AA mov.l 0x060471EC,r0
    c.r[2] += 4;  // 060471AC add #4,r2
    st32(c.r[1] + 4, c.r[2]); goto L_060471B4;  // 060471AE bra 0x060471B4 ; mov.l r2,@(4,r1)
L_060471B2:
    c.r[0] = 0x0u;  // 060471B2 mov #0,r0
L_060471B4:
    c.r[15] = c.r[14];  // 060471B4 mov r14,r15
L_060471B6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060471B6 lds.l @r15+,pr
L_060471B8:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060471B8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060471BA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060471BC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060471BE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060471C0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060471C2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060471C4 rts ; mov.l @r15+,r8
}

void f_060471F0(SH2Context& c) {
    ran[1145] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060471F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060471F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060471F4 mov r15,r14
    c.r[1] = ld32(0x06047228u);  // 060471F6 mov.l 0x06047228,r1
    c.r[2] = ld32(0x0604722Cu);  // 060471F8 mov.l 0x0604722C,r2
    c.r[7] = 0x10u;  // 060471FA mov #16,r7
    c.r[6] = 0x0u;  // 060471FC mov #0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060471FE mov.b @r1,r0
    c.r[4] = 0x30u;  // 06047200 mov #48,r4
    c.r[0] &= 0x7Fu;  // 06047202 and #127,r0
    st8(c.r[1], c.r[0]);  // 06047204 mov.b r0,@r1
    c.r[1] = 0x0u;  // 06047206 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06047208 mov.w r1,@r2
    c.r[2] += 1;  // 0604720A add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604720C mov.b @r2,r5
    c.r[1] = ld32(0x06047230u);  // 0604720E mov.l 0x06047230,r1
    c.r[5] += 42;  // 06047210 add #42,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06047216u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047216u) return; }  // 06047212 jsr @r1 ; extu.b r5,r5
    c.r[2] = ld32(0x06047234u);  // 06047216 mov.l 0x06047234,r2
    c.r[1] = 0x1u;  // 06047218 mov #1,r1
    st16(c.r[2], c.r[1]);  // 0604721A mov.w r1,@r2
    c.r[15] = c.r[14];  // 0604721C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604721E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047226u);  // 06047220 mov.w 0x06047226,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06047222 rts ; mov.l @r15+,r14
}

void f_06047238(SH2Context& c) {
    ran[1146] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06047238 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604723A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604723C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604723E mov r15,r14
    c.r[1] = ld32(0x06047274u);  // 06047240 mov.l 0x06047274,r1
    c.r[8] = 0x1u;  // 06047242 mov #1,r8
    c.r[7] = 0x10u;  // 06047244 mov #16,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047246 mov.b @r1,r0
    c.r[6] = 0x0u;  // 06047248 mov #0,r6
    c.r[0] &= 0x7Fu;  // 0604724A and #127,r0
    st8(c.r[1], c.r[0]);  // 0604724C mov.b r0,@r1
    c.r[1] = ld32(0x06047278u);  // 0604724E mov.l 0x06047278,r1
    st16(c.r[1], c.r[8]);  // 06047250 mov.w r8,@r1
    c.r[1] += 1;  // 06047252 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047254 mov.b @r1,r5
    c.r[4] = 0x30u;  // 06047256 mov #48,r4
    c.r[5] += 42;  // 06047258 add #42,r5
    c.r[1] = ld32(0x0604727Cu);  // 0604725A mov.l 0x0604727C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047260u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047260u) return; }  // 0604725C jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06047280u);  // 06047260 mov.l 0x06047280,r1
    st16(c.r[1], c.r[8]);  // 06047262 mov.w r8,@r1
    c.r[15] = c.r[14];  // 06047264 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06047266 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06047268 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047270u);  // 0604726A mov.w 0x06047270,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604726C rts ; mov.l @r15+,r8
}

void f_06047284(SH2Context& c) {
    ran[1147] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06047284 mov.l r14,@-r15
    c.r[1] = ld32(0x060472C0u);  // 06047286 mov.l 0x060472C0,r1
    c.r[1] = ld32(c.r[1]);  // 06047288 mov.l @r1,r1
    c.r[1] += 2;  // 0604728A add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604728C mov.w @r1,r1
    c.r[1] = ~c.r[1];  // 0604728E not r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06047290 extu.w r1,r0
    c.r[1] = c.r[0];  // 06047292 mov r0,r1
    c.r[0] &= 0x80u;  // 06047294 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06047296 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060472A2; } }  // 06047298 bt/s 0x060472A2 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060472B8u);  // 0604729C mov.w 0x060472B8,r0
    c.r[15] = c.r[14]; goto L_060472B4;  // 0604729E bra 0x060472B4 ; mov r14,r15
L_060472A2:
    c.r[2] = 0x8u;  // 060472A2 mov #8,r2
    c.r[1] &= c.r[2];  // 060472A4 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060472A6 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_060472B2; } }  // 060472A8 bf/s 0x060472B2 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060472BAu);  // 060472AC mov.w 0x060472BA,r0
    goto L_060472B4;  // 060472AE bra 0x060472B4 ; nop
L_060472B2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060472BCu);  // 060472B2 mov.w 0x060472BC,r0
L_060472B4:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060472B4 rts ; mov.l @r15+,r14
}

void f_060472C4(SH2Context& c) {
    ran[1148] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060472C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060472C6 sts.l pr,@-r15
    c.r[1] = ld32(0x060472E8u);  // 060472C8 mov.l 0x060472E8,r1
    c.r[1] = ld32(c.r[1]);  // 060472CA mov.l @r1,r1
    c.r[14] = c.r[15];  // 060472CC mov r15,r14
    c.r[1] += 1;  // 060472CE add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060472D0 mov.b @r1,r4
    c.r[5] = 0x2u;  // 060472D2 mov #2,r5
    c.r[1] = ld32(0x060472ECu);  // 060472D4 mov.l 0x060472EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060472DAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060472DAu) return; }  // 060472D6 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 060472DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060472DC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060472E4u);  // 060472DE mov.w 0x060472E4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060472E0 rts ; mov.l @r15+,r14
}

void f_060472F0(SH2Context& c) {
    ran[1149] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060472F0 mov.l r14,@-r15
    c.r[1] = ld32(0x06047318u);  // 060472F2 mov.l 0x06047318,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060472F4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060472F6 extu.b r1,r1
    c.r[1] >>= 2;  // 060472F8 shlr2 r1
    c.r[1] >>= 2;  // 060472FA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060472FC shlr r1
    c.r[1] >>= 2;  // 060472FE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047300 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604730C; } }  // 06047302 bf/s 0x0604730C ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047314u);  // 06047306 mov.w 0x06047314,r0
    c.r[15] = c.r[14]; goto L_06047310;  // 06047308 bra 0x06047310 ; mov r14,r15
L_0604730C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047316u);  // 0604730C mov.w 0x06047316,r0
    c.r[15] = c.r[14];  // 0604730E mov r14,r15
L_06047310:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06047310 rts ; mov.l @r15+,r14
}

void f_0604731C(SH2Context& c) {
    ran[1150] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604731C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604731E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06047320 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06047322 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06047324 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06047326 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06047328 mov r15,r14
    c.r[9] = 0x0u;  // 0604732A mov #0,r9
    c.r[3] = ld32(0x06047388u);  // 0604732C mov.l 0x06047388,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604732E mov.w @r3,r1
    c.r[2] = ld32(0x0604738Cu);  // 06047330 mov.l 0x0604738C,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06047332 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06047334 cmp/eq r2,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06047366; } }  // 06047336 bt/s 0x06047366 ; mov #0,r8
    c.r[10] = c.r[3];  // 0604733A mov r3,r10
    c.r[11] = ld32(0x06047390u);  // 0604733C mov.l 0x06047390,r11
    c.r[0] = c.r[8];  // 0604733E mov r8,r0
L_06047340:
    c.r[0] += c.r[0];  // 06047340 add r0,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06047342 mov.w @(r0,r10),r4
    c.r[5] = 0x2u;  // 06047344 mov #2,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0604734Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604734Au) return; }  // 06047346 jsr @r11 ; extu.w r4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604734A tst r0,r0
    if (c.t) { goto L_06047350; }  // 0604734C bt 0x06047350
    c.r[9] += 1;  // 0604734E add #1,r9
L_06047350:
    c.r[1] = c.r[8];  // 06047350 mov r8,r1
    c.r[1] += 1;  // 06047352 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06047354 extu.w r1,r8
    c.r[0] = c.r[8];  // 06047356 mov r8,r0
    c.r[0] += c.r[0];  // 06047358 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0604735A mov.w @(r0,r10),r1
    c.r[2] = ld32(0x0604738Cu);  // 0604735C mov.l 0x0604738C,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604735E extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06047360 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_06047340; } }  // 06047362 bf/s 0x06047340 ; mov r8,r0
L_06047366:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06047366 tst r9,r9
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06047372; } }  // 06047368 bf/s 0x06047372 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047382u);  // 0604736C mov.w 0x06047382,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06047376;  // 0604736E bra 0x06047376 ; lds.l @r15+,pr
L_06047372:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047384u);  // 06047372 mov.w 0x06047384,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06047374 lds.l @r15+,pr
L_06047376:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06047376 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06047378 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604737A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604737C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604737E rts ; mov.l @r15+,r8
}

void f_06047394(SH2Context& c) {
    ran[1151] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06047394 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06047396 mov r15,r14
    c.r[3] = 0x4u;  // 06047398 mov #4,r3
    c.r[5] = 0x27u;  // 0604739A mov #39,r5
    c.r[7] = ld32(0x060473C8u);  // 0604739C mov.l 0x060473C8,r7
    c.r[6] = 0x0u;  // 0604739E mov #0,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x060473C4u);  // 060473A0 mov.w 0x060473C4,r2
L_060473A2:
    c.r[1] = 0x0u;  // 060473A2 mov #0,r1
L_060473A4:
    c.r[0] = c.r[2];  // 060473A4 mov r2,r0
    c.r[0] += c.r[1];  // 060473A6 add r1,r0
    c.r[0] += c.r[0];  // 060473A8 add r0,r0
    c.r[1] += 1;  // 060473AA add #1,r1
    c.t = c.r[1] > c.r[5];  // 060473AC cmp/hi r5,r1
    { const bool k = !c.t; st16(c.r[0] + c.r[7], c.r[6]); if (k) { SH2_POLL(c); goto L_060473A4; } }  // 060473AE bf/s 0x060473A4 ; mov.w r6,@(r0,r7)
    c.r[3] += 1;  // 060473B2 add #1,r3
    c.r[1] = 0x13u;  // 060473B4 mov #19,r1
    c.t = c.r[3] > c.r[1];  // 060473B6 cmp/hi r1,r3
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_060473A2; } }  // 060473B8 bf/s 0x060473A2 ; add #64,r2
    c.r[15] = c.r[14];  // 060473BC mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060473C6u);  // 060473BE mov.w 0x060473C6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060473C0 rts ; mov.l @r15+,r14
}

void f_060473CC(SH2Context& c) {
    ran[1152] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060473CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060473CE mov r15,r14
    c.r[3] = 0x4u;  // 060473D0 mov #4,r3
    c.r[5] = 0x27u;  // 060473D2 mov #39,r5
    c.r[7] = ld32(0x06047404u);  // 060473D4 mov.l 0x06047404,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x060473FCu);  // 060473D6 mov.w 0x060473FC,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x060473FEu);  // 060473D8 mov.w 0x060473FE,r2
L_060473DA:
    c.r[1] = 0x0u;  // 060473DA mov #0,r1
L_060473DC:
    c.r[0] = c.r[2];  // 060473DC mov r2,r0
    c.r[0] += c.r[1];  // 060473DE add r1,r0
    c.r[0] += c.r[0];  // 060473E0 add r0,r0
    c.r[1] += 1;  // 060473E2 add #1,r1
    c.t = c.r[1] > c.r[5];  // 060473E4 cmp/hi r5,r1
    { const bool k = !c.t; st16(c.r[0] + c.r[7], c.r[6]); if (k) { SH2_POLL(c); goto L_060473DC; } }  // 060473E6 bf/s 0x060473DC ; mov.w r6,@(r0,r7)
    c.r[3] += 1;  // 060473EA add #1,r3
    c.r[1] = 0x13u;  // 060473EC mov #19,r1
    c.t = c.r[3] > c.r[1];  // 060473EE cmp/hi r1,r3
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_060473DA; } }  // 060473F0 bf/s 0x060473DA ; add #64,r2
    c.r[15] = c.r[14];  // 060473F4 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047400u);  // 060473F6 mov.w 0x06047400,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060473F8 rts ; mov.l @r15+,r14
}

void f_06047408(SH2Context& c) {
    ran[1153] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06047408 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604740A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604740C sts.l pr,@-r15
    c.r[1] = ld32(0x06047520u);  // 0604740E mov.l 0x06047520,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047410 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06047412 mov r1,r0
    c.r[0] >>= 2;  // 06047414 shlr2 r0
    c.r[0] >>= 2;  // 06047416 shlr2 r0
    c.r[0] >>= 2;  // 06047418 shlr2 r0
    c.r[0] &= 0x1u;  // 0604741A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604741C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06047428; } }  // 0604741E bt/s 0x06047428 ; mov r15,r14
L_06047422:
    c.r[0] = ld32(0x06047524u);  // 06047422 mov.l 0x06047524,r0
    c.r[15] = c.r[14]; goto L_06047514;  // 06047424 bra 0x06047514 ; mov r14,r15
L_06047428:
    c.r[3] = ld32(0x06047528u);  // 06047428 mov.l 0x06047528,r3
    c.r[1] = c.r[3];  // 0604742A mov r3,r1
    c.r[1] += 72;  // 0604742C add #72,r1
    c.r[2] = ld32(c.r[1]);  // 0604742E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06047430 tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06047498; } }  // 06047432 bf/s 0x06047498 ; mov r3,r1
    c.r[1] = ld32(0x0604752Cu);  // 06047436 mov.l 0x0604752C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047438 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604743A extu.b r1,r0
    c.r[0] >>= 2;  // 0604743C shlr2 r0
    c.r[0] >>= 2;  // 0604743E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06047440 shlr r0
    c.r[0] >>= 2;  // 06047442 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 06047444 cmp/eq #1,r0
    if (!c.t) { goto L_0604746A; }  // 06047446 bf 0x0604746A
    c.r[1] = ld32(0x06047530u);  // 06047448 mov.l 0x06047530,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604744A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604744C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0604744E cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0604746A; } }  // 06047450 bf/s 0x0604746A ; mov r3,r1
    c.r[1] += 76;  // 06047454 add #76,r1
    st32(c.r[1], c.r[2]);  // 06047456 mov.l r2,@r1
    c.r[3] += 80;  // 06047458 add #80,r3
    st32(c.r[3], c.r[2]);  // 0604745A mov.l r2,@r3
    c.r[1] = ld32(0x06047534u);  // 0604745C mov.l 0x06047534,r1
    c.r[6] = 0x0u;  // 0604745E mov #0,r6
    c.r[5] = 0x0u;  // 06047460 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06047466u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047466u) return; }  // 06047462 jsr @r1 ; mov #0,r4
    goto L_060474F6;  // 06047466 bra 0x060474F6 ; nop
L_0604746A:
    c.r[1] = ld32(0x06047538u);  // 0604746A mov.l 0x06047538,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047470u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047470u) return; }  // 0604746C jsr @r1 ; nop
    c.r[2] = ld32(0x06047528u);  // 06047470 mov.l 0x06047528,r2
    c.r[1] = c.r[2];  // 06047472 mov r2,r1
    c.r[1] += 76;  // 06047474 add #76,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604751Cu);  // 06047476 mov.w 0x0604751C,r8
    st32(c.r[1], c.r[8]);  // 06047478 mov.l r8,@r1
    c.r[2] += 80;  // 0604747A add #80,r2
    st32(c.r[2], c.r[8]);  // 0604747C mov.l r8,@r2
    c.r[1] = ld32(0x06047534u);  // 0604747E mov.l 0x06047534,r1
    c.r[6] = c.r[8];  // 06047480 mov r8,r6
    c.r[5] = c.r[8];  // 06047482 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06047488u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047488u) return; }  // 06047484 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0604753Cu);  // 06047488 mov.l 0x0604753C,r1
    c.r[6] = c.r[8];  // 0604748A mov r8,r6
    c.r[5] = c.r[8];  // 0604748C mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06047492u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047492u) return; }  // 0604748E jsr @r1 ; mov r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604751Eu);  // 06047492 mov.w 0x0604751E,r0
    c.r[15] = c.r[14]; goto L_06047514;  // 06047494 bra 0x06047514 ; mov r14,r15
L_06047498:
    c.r[1] += 76;  // 06047498 add #76,r1
    c.r[6] = c.r[3];  // 0604749A mov r3,r6
    c.r[1] = ld32(c.r[1]);  // 0604749C mov.l @r1,r1
    c.r[6] += 80;  // 0604749E add #80,r6
    c.r[7] = ld32(c.r[6]);  // 060474A0 mov.l @r6,r7
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[7];  // 060474A2 cmp/ge r7,r1
    if (!c.t) { goto L_060474C4; }  // 060474A4 bf 0x060474C4
    c.r[1] = ld32(c.r[3]);  // 060474A6 mov.l @r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060474A8 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060474AA extu.b r2,r2
    c.r[2] += c.r[7];  // 060474AC add r7,r2
    st32(c.r[6], c.r[2]);  // 060474AE mov.l r2,@r6
    c.r[1] = ld32(0x06047540u);  // 060474B0 mov.l 0x06047540,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060474B2 mov.w @r1,r4
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[4];  // 060474B4 cmp/ge r4,r2
    { const bool k = c.t; c.r[3] += 82; if (k) { goto L_060474BC; } }  // 060474B6 bt/s 0x060474BC ; add #82,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060474BA mov.w @r3,r4
L_060474BC:
    c.r[1] = ld32(0x0604753Cu);  // 060474BC mov.l 0x0604753C,r1
    c.r[6] = c.r[4];  // 060474BE mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060474C4u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060474C4u) return; }  // 060474C0 jsr @r1 ; mov r4,r5
L_060474C4:
    c.r[7] = ld32(0x06047528u);  // 060474C4 mov.l 0x06047528,r7
    c.r[1] = ld32(c.r[7]);  // 060474C6 mov.l @r7,r1
    c.r[3] = c.r[7];  // 060474C8 mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060474CA mov.b @r1,r1
    c.r[3] += 76;  // 060474CC add #76,r3
    c.r[2] = ld32(c.r[3]);  // 060474CE mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060474D0 extu.b r1,r1
    c.r[2] += c.r[1];  // 060474D2 add r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 060474D4 cmp/pz r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06047504; } }  // 060474D6 bf/s 0x06047504 ; mov.l r2,@r3
    c.r[1] = ld32(0x0604752Cu);  // 060474DA mov.l 0x0604752C,r1
    c.r[6] = 0x0u;  // 060474DC mov #0,r6
    c.r[5] = 0x0u;  // 060474DE mov #0,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060474E0 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 060474E2 or #128,r0
    st8(c.r[1], c.r[0]);  // 060474E4 mov.b r0,@r1
    c.r[1] = ld32(0x06047534u);  // 060474E6 mov.l 0x06047534,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060474ECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060474ECu) return; }  // 060474E8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06047530u);  // 060474EC mov.l 0x06047530,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060474EE mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060474F0 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 060474F2 cmp/eq #2,r0
    if (c.t) { SH2_POLL(c); goto L_06047422; }  // 060474F4 bt 0x06047422
L_060474F6:
    c.r[1] = ld32(0x0604753Cu);  // 060474F6 mov.l 0x0604753C,r1
    c.r[6] = 0x0u;  // 060474F8 mov #0,r6
    c.r[5] = 0x0u;  // 060474FA mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06047500u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047500u) return; }  // 060474FC jsr @r1 ; mov #0,r4
    SH2_POLL(c); goto L_06047422;  // 06047500 bra 0x06047422 ; nop
L_06047504:
    c.r[7] += 78;  // 06047504 add #78,r7
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06047506 mov.w @r7,r4
    c.r[1] = ld32(0x06047534u);  // 06047508 mov.l 0x06047534,r1
    c.r[6] = c.r[4];  // 0604750A mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06047510u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047510u) return; }  // 0604750C jsr @r1 ; mov r4,r5
    c.r[0] = 0x0u;  // 06047510 mov #0,r0
    c.r[15] = c.r[14];  // 06047512 mov r14,r15
L_06047514:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06047514 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06047516 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06047518 rts ; mov.l @r15+,r8
}

void f_06047544(SH2Context& c) {
    ran[1154] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06047544 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06047546 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06047548 sts.l pr,@-r15
    c.r[1] = ld32(0x0604763Cu);  // 0604754A mov.l 0x0604763C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604754C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604754E mov r1,r0
    c.r[0] >>= 2;  // 06047550 shlr2 r0
    c.r[0] >>= 2;  // 06047552 shlr2 r0
    c.r[0] >>= 2;  // 06047554 shlr2 r0
    c.r[0] &= 0x1u;  // 06047556 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06047558 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06047628; } }  // 0604755A bf/s 0x06047628 ; mov r15,r14
    c.r[3] = ld32(0x06047640u);  // 0604755E mov.l 0x06047640,r3
    c.r[1] = c.r[3];  // 06047560 mov r3,r1
    c.r[1] += 72;  // 06047562 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 06047564 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047566 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_060475BC; } }  // 06047568 bf/s 0x060475BC ; mov r3,r1
    c.r[1] = ld32(0x06047644u);  // 0604756C mov.l 0x06047644,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604756E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06047570 extu.b r1,r1
    c.r[1] >>= 2;  // 06047572 shlr2 r1
    c.r[1] >>= 2;  // 06047574 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06047576 shlr r1
    c.r[1] >>= 2;  // 06047578 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604757A tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_060475AA; } }  // 0604757C bf/s 0x060475AA ; mov r3,r2
    c.r[1] = ld32(0x06047648u);  // 06047580 mov.l 0x06047648,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047582 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06047584 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06047586 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_060475AA; } }  // 06047588 bf/s 0x060475AA ; mov r3,r1
    c.r[1] += 76;  // 0604758C add #76,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06047634u);  // 0604758E mov.w 0x06047634,r8
    st32(c.r[1], c.r[8]);  // 06047590 mov.l r8,@r1
    c.r[3] += 80;  // 06047592 add #80,r3
    st32(c.r[3], c.r[8]);  // 06047594 mov.l r8,@r3
    c.r[1] = ld32(0x0604764Cu);  // 06047596 mov.l 0x0604764C,r1
    c.r[6] = c.r[8];  // 06047598 mov r8,r6
    c.r[5] = c.r[8];  // 0604759A mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060475A0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060475A0u) return; }  // 0604759C jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06047650u);  // 060475A0 mov.l 0x06047650,r1
    c.r[6] = c.r[8];  // 060475A2 mov r8,r6
    c.r[5] = c.r[8];  // 060475A4 mov r8,r5
    c.r[4] = c.r[8]; goto L_06047624;  // 060475A6 bra 0x06047624 ; mov r8,r4
L_060475AA:
    c.r[2] += 76;  // 060475AA add #76,r2
    c.r[1] = 0x0u;  // 060475AC mov #0,r1
    st32(c.r[2], c.r[1]);  // 060475AE mov.l r1,@r2
    c.r[3] += 80;  // 060475B0 add #80,r3
    c.r[1] = ld32(0x06047654u);  // 060475B2 mov.l 0x06047654,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060475B4 mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047636u);  // 060475B6 mov.w 0x06047636,r0
    st32(c.r[3], c.r[1]); goto L_0604762A;  // 060475B8 bra 0x0604762A ; mov.l r1,@r3
L_060475BC:
    c.r[1] += 76;  // 060475BC add #76,r1
    c.r[7] = c.r[3];  // 060475BE mov r3,r7
    c.r[1] = ld32(c.r[1]);  // 060475C0 mov.l @r1,r1
    c.r[7] += 80;  // 060475C2 add #80,r7
    c.r[2] = ld32(c.r[7]);  // 060475C4 mov.l @r7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060475C6 cmp/gt r2,r1
    if (c.t) { goto L_060475EC; }  // 060475C8 bt 0x060475EC
    c.r[1] = ld32(c.r[3]);  // 060475CA mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060475CC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060475CE extu.b r1,r1
    c.r[2] -= c.r[1];  // 060475D0 sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047638u);  // 060475D2 mov.w 0x06047638,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060475D4 cmp/gt r1,r2
    { const bool k = c.t; st32(c.r[7], c.r[2]); if (k) { goto L_060475E0; } }  // 060475D6 bt/s 0x060475E0 ; mov.l r2,@r7
    c.r[4] = (uint32_t)(int16_t)ld16(0x06047634u);  // 060475DA mov.w 0x06047634,r4
    goto L_060475E4;  // 060475DC bra 0x060475E4 ; nop
L_060475E0:
    c.r[3] += 82;  // 060475E0 add #82,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060475E2 mov.w @r3,r4
L_060475E4:
    c.r[1] = ld32(0x06047650u);  // 060475E4 mov.l 0x06047650,r1
    c.r[6] = c.r[4];  // 060475E6 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060475ECu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060475ECu) return; }  // 060475E8 jsr @r1 ; mov r4,r5
L_060475EC:
    c.r[7] = ld32(0x06047640u);  // 060475EC mov.l 0x06047640,r7
    c.r[1] = ld32(c.r[7]);  // 060475EE mov.l @r7,r1
    c.r[3] = c.r[7];  // 060475F0 mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060475F2 mov.b @r1,r1
    c.r[3] += 76;  // 060475F4 add #76,r3
    c.r[2] = ld32(c.r[3]);  // 060475F6 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060475F8 extu.b r1,r1
    c.r[2] -= c.r[1];  // 060475FA sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047638u);  // 060475FC mov.w 0x06047638,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060475FE cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06047614; } }  // 06047600 bf/s 0x06047614 ; mov.l r2,@r3
    c.r[7] += 78;  // 06047604 add #78,r7
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06047606 mov.w @r7,r4
    c.r[1] = ld32(0x0604764Cu);  // 06047608 mov.l 0x0604764C,r1
    c.r[6] = c.r[4];  // 0604760A mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06047610u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047610u) return; }  // 0604760C jsr @r1 ; mov r4,r5
    c.r[0] = 0x0u; goto L_0604762A;  // 06047610 bra 0x0604762A ; mov #0,r0
L_06047614:
    c.r[1] = ld32(0x06047644u);  // 06047614 mov.l 0x06047644,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047616 mov.b @r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x06047634u);  // 06047618 mov.w 0x06047634,r4
    c.r[6] = c.r[4];  // 0604761A mov r4,r6
    c.r[5] = c.r[4];  // 0604761C mov r4,r5
    c.r[0] &= 0x7Fu;  // 0604761E and #127,r0
    st8(c.r[1], c.r[0]);  // 06047620 mov.b r0,@r1
    c.r[1] = ld32(0x0604764Cu);  // 06047622 mov.l 0x0604764C,r1
L_06047624:
    { const uint32_t x = c.r[1]; c.pr = 0x06047628u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047628u) return; }  // 06047624 jsr @r1 ; nop
L_06047628:
    c.r[0] = ld32(0x06047658u);  // 06047628 mov.l 0x06047658,r0
L_0604762A:
    c.r[15] = c.r[14];  // 0604762A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604762C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604762E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06047630 rts ; mov.l @r15+,r8
}

void f_0604765C(SH2Context& c) {
    ran[1155] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604765C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604765E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06047660 sts.l pr,@-r15
    c.r[1] = ld32(0x060476B8u);  // 06047662 mov.l 0x060476B8,r1
    c.r[2] = ld32(c.r[1]);  // 06047664 mov.l @r1,r2
    c.r[8] = 0x7Fu;  // 06047666 mov #127,r8
    c.r[1] = c.r[2];  // 06047668 mov r2,r1
    c.r[1] += 1;  // 0604766A add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604766C mov.b @r1,r0
    c.r[2] += 2;  // 0604766E add #2,r2
    c.r[8] &= c.r[0];  // 06047670 and r0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047672 mov.b @r2,r1
    c.r[8] <<= 8;  // 06047674 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 06047676 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06047678 or r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060476B2u);  // 0604767A mov.w 0x060476B2,r1
    c.t = c.r[8] > c.r[1];  // 0604767C cmp/hi r1,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06047684; } }  // 0604767E bf/s 0x06047684 ; mov r15,r14
    c.r[8] = 0x0u;  // 06047682 mov #0,r8
L_06047684:
    c.r[4] = ld32(0x060476BCu);  // 06047684 mov.l 0x060476BC,r4
    c.r[0] = ld32(0x060476C0u);  // 06047686 mov.l 0x060476C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604768Cu; c.r[5] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604768Cu) return; }  // 06047688 jsr @r0 ; mov #6,r5
    c.r[2] = c.r[0];  // 0604768C mov r0,r2
    c.r[1] = ld32(0x060476C4u);  // 0604768E mov.l 0x060476C4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06047690 mov.l r1,@-r15
    c.r[0] = ld32(0x060476C8u);  // 06047692 mov.l 0x060476C8,r0
    c.r[7] = c.r[8];  // 06047694 mov r8,r7
    c.r[6] = 0x2u;  // 06047696 mov #2,r6
    c.r[5] = c.r[2];  // 06047698 mov r2,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604769Eu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604769Eu) return; }  // 0604769A jsr @r0 ; mov #8,r4
    c.r[1] = ld32(0x060476CCu);  // 0604769E mov.l 0x060476CC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060476A0 mov.b @r1,r0
    c.r[15] = c.r[14];  // 060476A2 mov r14,r15
    c.r[0] |= 0xCu;  // 060476A4 or #12,r0
    st8(c.r[1], c.r[0]);  // 060476A6 mov.b r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060476A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060476AA mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060476B4u);  // 060476AC mov.w 0x060476B4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060476AE rts ; mov.l @r15+,r8
}

void f_060476D0(SH2Context& c) {
    ran[1156] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060476D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060476D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060476D4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060476D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060476D8 sts.l pr,@-r15
    c.r[15] -= 24;  // 060476DA add #-24,r15
    c.r[14] = c.r[15];  // 060476DC mov r15,r14
    c.r[1] = ld32(0x060477B8u);  // 060476DE mov.l 0x060477B8,r1
    c.r[0] = ld32(0x060477BCu);  // 060476E0 mov.l 0x060477BC,r0
    c.r[6] = 0x4u;  // 060476E2 mov #4,r6
    c.r[4] = ld32(c.r[1]);  // 060476E4 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060476EAu; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060476EAu) return; }  // 060476E6 jsr @r0 ; mov #4,r5
    c.r[2] = c.r[0];  // 060476EA mov r0,r2
    c.r[2] += 16;  // 060476EC add #16,r2
    c.r[1] = ld32(0x060477C0u);  // 060476EE mov.l 0x060477C0,r1
    c.r[0] = ld32(0x060477C4u);  // 060476F0 mov.l 0x060477C4,r0
    c.r[6] = c.r[14];  // 060476F2 mov r14,r6
    c.r[5] = ld32(c.r[1]);  // 060476F4 mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060476FAu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060476FAu) return; }  // 060476F6 jsr @r0 ; mov r2,r4
    c.r[0] = ld32(0x060477C8u);  // 060476FA mov.l 0x060477C8,r0
    c.r[6] = 0x2u;  // 060476FC mov #2,r6
    c.r[5] = ld32(c.r[14] + 8);  // 060476FE mov.l @(8,r14),r5
    { const uint32_t x = c.r[0]; c.pr = 0x06047704u; c.r[4] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047704u) return; }  // 06047700 jsr @r0 ; mov #38,r4
    c.r[8] = ld32(0x060477CCu);  // 06047704 mov.l 0x060477CC,r8
    c.r[1] = 0x1u;  // 06047706 mov #1,r1
    st8(c.r[8], c.r[1]);  // 06047708 mov.b r1,@r8
    c.r[1] = c.r[14];  // 0604770A mov r14,r1
    c.r[1] += 6;  // 0604770C add #6,r1
    c.r[5] = ld32(0x060477D0u);  // 0604770E mov.l 0x060477D0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06047710 mov.w @r1,r6
    c.r[7] = 0x7u;  // 06047712 mov #7,r7
    c.r[4] = ld32(c.r[14] + 16);  // 06047714 mov.l @(16,r14),r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 06047716 extu.w r6,r6
    c.r[6] <<= 2;  // 06047718 shll2 r6
    c.r[6] += c.r[6];  // 0604771A add r6,r6
    c.r[1] = ld32(0x060477D4u);  // 0604771C mov.l 0x060477D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047722u; c.r[6] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047722u) return; }  // 0604771E jsr @r1 ; shll2 r6
    c.r[1] = ld32(0x060477D8u);  // 06047722 mov.l 0x060477D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047728u; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047728u) return; }  // 06047724 jsr @r1 ; mov #0,r10
    st8(c.r[8], c.r[10]);  // 06047728 mov.b r10,@r8
    c.r[8] = ld32(0x060477DCu);  // 0604772A mov.l 0x060477DC,r8
    c.r[7] = 0xFu;  // 0604772C mov #15,r7
    c.r[6] = 0x1u;  // 0604772E mov #1,r6
    c.r[5] = 0x1u;  // 06047730 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06047736u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047736u) return; }  // 06047732 jsr @r8 ; mov #32,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x060477AAu);  // 06047736 mov.w 0x060477AA,r4
    c.r[7] = 0x10u;  // 06047738 mov #16,r7
    c.r[6] = 0x0u;  // 0604773A mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06047740u; c.r[5] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047740u) return; }  // 0604773C jsr @r8 ; mov #38,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060477ACu);  // 06047740 mov.w 0x060477AC,r4
    c.r[7] = 0x10u;  // 06047742 mov #16,r7
    c.r[6] = 0x0u;  // 06047744 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0604774Au; c.r[5] = 0x27u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604774Au) return; }  // 06047746 jsr @r8 ; mov #39,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060477AEu);  // 0604774A mov.w 0x060477AE,r4
    c.r[7] = 0x10u;  // 0604774C mov #16,r7
    c.r[6] = 0x0u;  // 0604774E mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06047754u; c.r[5] = 0x28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047754u) return; }  // 06047750 jsr @r8 ; mov #40,r5
    c.r[2] = ld32(0x060477E0u);  // 06047754 mov.l 0x060477E0,r2
    c.r[1] = 0x1u;  // 06047756 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06047758 mov.w r1,@r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060477B0u);  // 0604775A mov.w 0x060477B0,r7
    c.r[8] = (uint32_t)(int16_t)ld16(0x060477B2u);  // 0604775C mov.w 0x060477B2,r8
    c.r[4] = ld32(0x060477E4u);  // 0604775E mov.l 0x060477E4,r4
    c.r[9] = ld32(0x060477E8u);  // 06047760 mov.l 0x060477E8,r9
    c.r[6] = 0x2u;  // 06047762 mov #2,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06047768u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047768u) return; }  // 06047764 jsr @r9 ; mov r8,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x060477B4u);  // 06047768 mov.w 0x060477B4,r7
    c.r[4] = ld32(0x060477ECu);  // 0604776A mov.l 0x060477EC,r4
    c.r[6] = 0x2u;  // 0604776C mov #2,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06047772u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047772u) return; }  // 0604776E jsr @r9 ; mov r8,r5
    c.r[1] = ld32(0x060477F0u);  // 06047772 mov.l 0x060477F0,r1
    st8(c.r[1], c.r[10]);  // 06047774 mov.b r10,@r1
    c.r[1] = ld32(0x060477F4u);  // 06047776 mov.l 0x060477F4,r1
    c.r[2] = 0x20u;  // 06047778 mov #32,r2
    st8(c.r[1], c.r[2]);  // 0604777A mov.b r2,@r1
    c.r[1] = ld32(0x060477F8u);  // 0604777C mov.l 0x060477F8,r1
    st8(c.r[1], c.r[10]);  // 0604777E mov.b r10,@r1
    c.r[1] = ld32(0x060477FCu);  // 06047780 mov.l 0x060477FC,r1
    st8(c.r[1], c.r[2]);  // 06047782 mov.b r2,@r1
    c.r[2] = ld32(0x06047800u);  // 06047784 mov.l 0x06047800,r2
    c.r[1] = 0x0u;  // 06047786 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06047788 mov.w r1,@r2
    c.r[2] = ld32(0x06047804u);  // 0604778A mov.l 0x06047804,r2
    c.r[1] = 0x8u;  // 0604778C mov #8,r1
    st32(c.r[2] + 36, c.r[1]);  // 0604778E mov.l r1,@(36,r2)
    c.r[1] = ld32(0x06047808u);  // 06047790 mov.l 0x06047808,r1
    c.r[14] += 24;  // 06047792 add #24,r14
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06047794 mov.w @r1,r0
    c.r[15] = c.r[14];  // 06047796 mov r14,r15
    c.r[0] |= 0x4u;  // 06047798 or #4,r0
    st16(c.r[1], c.r[0]);  // 0604779A mov.w r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604779C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604779E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060477A0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060477A2 mov.l @r15+,r9
    c.r[0] = ld32(0x0604780Cu);  // 060477A4 mov.l 0x0604780C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060477A6 rts ; mov.l @r15+,r8
}

void f_06047810(SH2Context& c) {
    ran[1157] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06047810 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06047812 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06047814 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06047816 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06047818 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604781A sts.l pr,@-r15
    c.r[15] -= 24;  // 0604781C add #-24,r15
    c.r[14] = c.r[15];  // 0604781E mov r15,r14
    c.r[1] = ld32(0x06047940u);  // 06047820 mov.l 0x06047940,r1
    c.r[0] = ld32(0x06047944u);  // 06047822 mov.l 0x06047944,r0
    c.r[6] = 0x4u;  // 06047824 mov #4,r6
    c.r[4] = ld32(c.r[1]);  // 06047826 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0604782Cu; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604782Cu) return; }  // 06047828 jsr @r0 ; mov #4,r5
    c.r[2] = c.r[0];  // 0604782C mov r0,r2
    c.r[2] += 16;  // 0604782E add #16,r2
    c.r[1] = ld32(0x06047948u);  // 06047830 mov.l 0x06047948,r1
    c.r[0] = ld32(0x0604794Cu);  // 06047832 mov.l 0x0604794C,r0
    c.r[6] = c.r[14];  // 06047834 mov r14,r6
    c.r[5] = ld32(c.r[1]);  // 06047836 mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604783Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604783Cu) return; }  // 06047838 jsr @r0 ; mov r2,r4
    c.r[0] = ld32(0x06047950u);  // 0604783C mov.l 0x06047950,r0
    c.r[6] = 0x2u;  // 0604783E mov #2,r6
    c.r[5] = ld32(c.r[14] + 8);  // 06047840 mov.l @(8,r14),r5
    { const uint32_t x = c.r[0]; c.pr = 0x06047846u; c.r[4] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047846u) return; }  // 06047842 jsr @r0 ; mov #38,r4
    c.r[8] = ld32(0x06047954u);  // 06047846 mov.l 0x06047954,r8
    c.r[1] = 0x1u;  // 06047848 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0604784A mov.b r1,@r8
    c.r[1] = c.r[14];  // 0604784C mov r14,r1
    c.r[1] += 6;  // 0604784E add #6,r1
    c.r[5] = ld32(0x06047958u);  // 06047850 mov.l 0x06047958,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06047852 mov.w @r1,r6
    c.r[7] = 0x7u;  // 06047854 mov #7,r7
    c.r[4] = ld32(c.r[14] + 16);  // 06047856 mov.l @(16,r14),r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 06047858 extu.w r6,r6
    c.r[6] <<= 2;  // 0604785A shll2 r6
    c.r[6] += c.r[6];  // 0604785C add r6,r6
    c.r[1] = ld32(0x0604795Cu);  // 0604785E mov.l 0x0604795C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047864u; c.r[6] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047864u) return; }  // 06047860 jsr @r1 ; shll2 r6
    c.r[1] = ld32(0x06047960u);  // 06047864 mov.l 0x06047960,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604786Au; c.r[11] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604786Au) return; }  // 06047866 jsr @r1 ; mov #0,r11
    st8(c.r[8], c.r[11]);  // 0604786A mov.b r11,@r8
    c.r[8] = ld32(0x06047964u);  // 0604786C mov.l 0x06047964,r8
    c.r[7] = 0xFu;  // 0604786E mov #15,r7
    c.r[6] = 0x1u;  // 06047870 mov #1,r6
    c.r[5] = 0x1u;  // 06047872 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06047878u; c.r[4] = 0x21u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047878u) return; }  // 06047874 jsr @r8 ; mov #33,r4
    c.r[7] = 0x2u;  // 06047878 mov #2,r7
    c.r[6] = 0x1u;  // 0604787A mov #1,r6
    c.r[5] = 0x3u;  // 0604787C mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06047882u; c.r[4] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047882u) return; }  // 0604787E jsr @r8 ; mov #34,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604792Eu);  // 06047882 mov.w 0x0604792E,r4
    c.r[7] = 0x10u;  // 06047884 mov #16,r7
    c.r[6] = 0x0u;  // 06047886 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0604788Cu; c.r[5] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604788Cu) return; }  // 06047888 jsr @r8 ; mov #38,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06047930u);  // 0604788C mov.w 0x06047930,r4
    c.r[7] = 0x10u;  // 0604788E mov #16,r7
    c.r[6] = 0x0u;  // 06047890 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06047896u; c.r[5] = 0x27u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047896u) return; }  // 06047892 jsr @r8 ; mov #39,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06047932u);  // 06047896 mov.w 0x06047932,r4
    c.r[7] = 0x10u;  // 06047898 mov #16,r7
    c.r[6] = 0x0u;  // 0604789A mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060478A0u; c.r[5] = 0x28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060478A0u) return; }  // 0604789C jsr @r8 ; mov #40,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06047934u);  // 060478A0 mov.w 0x06047934,r4
    c.r[7] = 0x10u;  // 060478A2 mov #16,r7
    c.r[6] = 0x0u;  // 060478A4 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060478AAu; c.r[5] = 0x28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060478AAu) return; }  // 060478A6 jsr @r8 ; mov #40,r5
    c.r[2] = ld32(0x06047968u);  // 060478AA mov.l 0x06047968,r2
    c.r[1] = 0x1u;  // 060478AC mov #1,r1
    st16(c.r[2], c.r[1]);  // 060478AE mov.w r1,@r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x06047936u);  // 060478B0 mov.w 0x06047936,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06047938u);  // 060478B2 mov.w 0x06047938,r8
    c.r[4] = ld32(0x0604796Cu);  // 060478B4 mov.l 0x0604796C,r4
    c.r[9] = ld32(0x06047970u);  // 060478B6 mov.l 0x06047970,r9
    c.r[7] = c.r[10];  // 060478B8 mov r10,r7
    c.r[6] = 0x2u;  // 060478BA mov #2,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060478C0u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060478C0u) return; }  // 060478BC jsr @r9 ; mov r8,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604793Au);  // 060478C0 mov.w 0x0604793A,r7
    c.r[4] = ld32(0x06047974u);  // 060478C2 mov.l 0x06047974,r4
    c.r[6] = 0x2u;  // 060478C4 mov #2,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060478CAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060478CAu) return; }  // 060478C6 jsr @r9 ; mov r8,r5
    c.r[4] = ld32(0x06047978u);  // 060478CA mov.l 0x06047978,r4
    c.r[7] = c.r[10];  // 060478CC mov r10,r7
    c.r[6] = 0x2u;  // 060478CE mov #2,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060478D4u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060478D4u) return; }  // 060478D0 jsr @r9 ; mov r8,r5
    c.r[1] = ld32(0x0604797Cu);  // 060478D4 mov.l 0x0604797C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060478D6 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 060478D8 or #128,r0
    st8(c.r[1], c.r[0]);  // 060478DA mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060478DC mov.b @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604793Cu);  // 060478DE mov.w 0x0604793C,r2
    c.r[0] |= 0x40u;  // 060478E0 or #64,r0
    st8(c.r[1], c.r[0]);  // 060478E2 mov.b r0,@r1
    st32(c.r[1] + 24, c.r[2]);  // 060478E4 mov.l r2,@(24,r1)
    c.r[2] = 0x0u;  // 060478E6 mov #0,r2
    st32(c.r[1] + 20, c.r[2]);  // 060478E8 mov.l r2,@(20,r1)
    c.r[1] += 14;  // 060478EA add #14,r1
    c.r[2] = 0x0u;  // 060478EC mov #0,r2
    st16(c.r[1], c.r[2]);  // 060478EE mov.w r2,@r1
    c.r[1] = ld32(0x06047980u);  // 060478F0 mov.l 0x06047980,r1
    st8(c.r[1], c.r[11]);  // 060478F2 mov.b r11,@r1
    c.r[1] = ld32(0x06047984u);  // 060478F4 mov.l 0x06047984,r1
    st8(c.r[1], c.r[11]);  // 060478F6 mov.b r11,@r1
    c.r[1] = ld32(0x06047988u);  // 060478F8 mov.l 0x06047988,r1
    st8(c.r[1], c.r[11]);  // 060478FA mov.b r11,@r1
    c.r[1] = ld32(0x0604798Cu);  // 060478FC mov.l 0x0604798C,r1
    st8(c.r[1], c.r[11]);  // 060478FE mov.b r11,@r1
    c.r[1] = ld32(0x06047990u);  // 06047900 mov.l 0x06047990,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06047906u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047906u) return; }  // 06047902 jsr @r1 ; nop
    c.r[1] = ld32(0x06047994u);  // 06047906 mov.l 0x06047994,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604790Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604790Cu) return; }  // 06047908 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(0x06047998u);  // 0604790C mov.l 0x06047998,r2
    c.r[1] = 0x8u;  // 0604790E mov #8,r1
    st32(c.r[2] + 36, c.r[1]);  // 06047910 mov.l r1,@(36,r2)
    c.r[1] = ld32(0x0604799Cu);  // 06047912 mov.l 0x0604799C,r1
    c.r[14] += 24;  // 06047914 add #24,r14
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06047916 mov.w @r1,r0
    c.r[15] = c.r[14];  // 06047918 mov r14,r15
    c.r[0] |= 0x6u;  // 0604791A or #6,r0
    st16(c.r[1], c.r[0]);  // 0604791C mov.w r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604791E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06047920 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06047922 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06047924 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06047926 mov.l @r15+,r9
    c.r[0] = ld32(0x060479A0u);  // 06047928 mov.l 0x060479A0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604792A rts ; mov.l @r15+,r8
}

void f_060479A4(SH2Context& c) {
    ran[1158] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060479A4 mov.l r14,@-r15
    c.r[1] = ld32(0x06047A0Cu);  // 060479A6 mov.l 0x06047A0C,r1
    c.r[2] = ld32(c.r[1]);  // 060479A8 mov.l @r1,r2
    c.r[7] = ld32(0x06047A10u);  // 060479AA mov.l 0x06047A10,r7
    c.r[1] = ld32(0x06047A14u);  // 060479AC mov.l 0x06047A14,r1
    c.r[3] = c.r[2];  // 060479AE mov r2,r3
    c.r[0] = c.r[2];  // 060479B0 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060479B2 mov.b @(r0,r1),r2
    c.r[3] += c.r[1];  // 060479B4 add r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060479B6 extu.b r2,r2
    c.r[2] <<= 8;  // 060479B8 shll8 r2
    c.r[1] = c.r[3];  // 060479BA mov r3,r1
    c.r[1] += 1;  // 060479BC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060479BE mov.b @r1,r1
    c.r[2] += c.r[3];  // 060479C0 add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060479C2 extu.b r1,r1
    c.r[2] += c.r[1];  // 060479C4 add r1,r2
    st32(c.r[7] + 28, c.r[2]);  // 060479C6 mov.l r2,@(28,r7)
    c.r[1] = c.r[3];  // 060479C8 mov r3,r1
    c.r[1] += 2;  // 060479CA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060479CC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060479CE extu.b r2,r2
    c.r[2] <<= 8;  // 060479D0 shll8 r2
    c.r[2] += 2;  // 060479D2 add #2,r2
    c.r[1] = c.r[3];  // 060479D4 mov r3,r1
    c.r[1] += 3;  // 060479D6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060479D8 mov.b @r1,r1
    c.r[2] += c.r[3];  // 060479DA add r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060479DC extu.b r1,r1
    c.r[2] += c.r[1];  // 060479DE add r1,r2
    st32(c.r[7] + 32, c.r[2]);  // 060479E0 mov.l r2,@(32,r7)
    c.r[1] = c.r[3];  // 060479E2 mov r3,r1
    c.r[1] += 4;  // 060479E4 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060479E6 mov.b @r1,r2
    c.r[14] = c.r[15];  // 060479E8 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 060479EA extu.b r2,r2
    c.r[2] <<= 8;  // 060479EC shll8 r2
    c.r[2] += 4;  // 060479EE add #4,r2
    c.r[2] += c.r[3];  // 060479F0 add r3,r2
    c.r[3] += 5;  // 060479F2 add #5,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060479F4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060479F6 extu.b r1,r1
    c.r[2] += c.r[1];  // 060479F8 add r1,r2
    st32(c.r[7] + 36, c.r[2]);  // 060479FA mov.l r2,@(36,r7)
    c.r[7] += 10;  // 060479FC add #10,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060479FE mov.w @r7,r1
    c.r[2] = ld32(0x06047A18u);  // 06047A00 mov.l 0x06047A18,r2
    st16(c.r[2], c.r[1]);  // 06047A02 mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047A0Au);  // 06047A04 mov.w 0x06047A0A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06047A06 rts ; mov.l @r15+,r14
}

void f_06047A1C(SH2Context& c) {
    ran[1159] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06047A1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06047A1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06047A20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06047A22 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06047A24 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06047A26 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06047A28 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06047A2A sts.l pr,@-r15
    c.r[7] = ld32(0x06047A50u);  // 06047A2C mov.l 0x06047A50,r7
    c.r[2] = ld32(c.r[7] + 28);  // 06047A2E mov.l @(28,r7),r2
    c.r[15] -= 12;  // 06047A30 add #-12,r15
    c.r[1] = c.r[2];  // 06047A32 mov r2,r1
    c.r[1] += 1;  // 06047A34 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047A36 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047A38 mov.b @r2,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06047A3A extu.b r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047A4Au);  // 06047A3C mov.w 0x06047A4A,r1
    c.t = c.r[5] == c.r[1];  // 06047A3E cmp/eq r1,r5
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06047A54; } }  // 06047A40 bf/s 0x06047A54 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047A4Cu);  // 06047A44 mov.w 0x06047A4C,r0
    c.r[14] += 12; goto L_06048816;  // 06047A46 bra 0x06048816 ; add #12,r14
L_06047A54:
    c.r[2] = ld32(0x06047D7Cu);  // 06047A54 mov.l 0x06047D7C,r2
    c.r[1] = 0x1u;  // 06047A56 mov #1,r1
    c.r[1] &= c.r[5];  // 06047A58 and r5,r1
    c.r[1] <<= 2;  // 06047A5A shll2 r1
    c.r[1] <<= 2;  // 06047A5C shll2 r1
    c.r[1] += c.r[1];  // 06047A5E add r1,r1
    c.r[1] <<= 2;  // 06047A60 shll2 r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047A62 mov.b @r2,r3
    c.r[0] = 0x7Fu;  // 06047A64 mov #127,r0
    c.r[3] &= c.r[0];  // 06047A66 and r0,r3
    c.r[3] |= c.r[1];  // 06047A68 or r1,r3
    st8(c.r[2], c.r[3]);  // 06047A6A mov.b r3,@r2
    c.r[2] = ld32(c.r[7] + 28);  // 06047A6C mov.l @(28,r7),r2
    c.r[13] = ld32(0x06047D80u);  // 06047A6E mov.l 0x06047D80,r13
    c.r[1] = c.r[2];  // 06047A70 mov r2,r1
    c.r[1] += 1;  // 06047A72 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047A74 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047A76 mov.b @r2,r1
    c.r[0] = ld32(0x06047D84u);  // 06047A78 mov.l 0x06047D84,r0
    c.r[5] = c.r[1] & 0xFFu;  // 06047A7A extu.b r1,r5
    c.r[1] = c.r[13];  // 06047A7C mov r13,r1
    c.r[1] += 30;  // 06047A7E add #30,r1
    st8(c.r[1], c.r[5]);  // 06047A80 mov.b r5,@r1
    st32(c.r[14], c.r[0]);  // 06047A82 mov.l r0,@r14
    c.r[1] = c.r[0];  // 06047A84 mov r0,r1
    c.r[1] += 30;  // 06047A86 add #30,r1
    st8(c.r[1], c.r[5]);  // 06047A88 mov.b r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047A8A mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047A8C mov r2,r1
    c.r[1] += 1;  // 06047A8E add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047A90 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047A92 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047A94 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047A96 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047A98 mov r2,r1
    c.r[1] += 1;  // 06047A9A add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047A9C mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047A9E mov.b @r2,r1
    c.r[5] <<= 8;  // 06047AA0 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047AA2 extu.b r1,r6
    c.r[1] = c.r[13];  // 06047AA4 mov r13,r1
    c.r[1] += 6;  // 06047AA6 add #6,r1
    c.r[5] += c.r[6];  // 06047AA8 add r6,r5
    st16(c.r[1], c.r[5]);  // 06047AAA mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047AAC mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047AAE mov r2,r1
    c.r[1] += 1;  // 06047AB0 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047AB2 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047AB4 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047AB6 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047AB8 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047ABA mov r2,r1
    c.r[1] += 1;  // 06047ABC add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047ABE mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047AC0 mov.b @r2,r1
    c.r[5] <<= 8;  // 06047AC2 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047AC4 extu.b r1,r6
    c.r[1] = c.r[13];  // 06047AC6 mov r13,r1
    c.r[1] += 10;  // 06047AC8 add #10,r1
    c.r[5] += c.r[6];  // 06047ACA add r6,r5
    st16(c.r[1], c.r[5]);  // 06047ACC mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047ACE mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047AD0 mov r2,r1
    c.r[1] += 1;  // 06047AD2 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047AD4 mov.l r1,@(28,r7)
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047AD6 mov.b @r2,r3
    c.r[2] = ld32(c.r[7] + 28);  // 06047AD8 mov.l @(28,r7),r2
    c.r[3] = c.r[3] & 0xFFu;  // 06047ADA extu.b r3,r3
    c.r[1] = c.r[2];  // 06047ADC mov r2,r1
    c.r[1] += 1;  // 06047ADE add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047AE0 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047AE2 mov.b @r2,r1
    c.r[3] <<= 8;  // 06047AE4 shll8 r3
    c.r[6] = c.r[1] & 0xFFu;  // 06047AE6 extu.b r1,r6
    c.r[2] = ld32(0x06047D88u);  // 06047AE8 mov.l 0x06047D88,r2
    c.r[1] = c.r[2];  // 06047AEA mov r2,r1
    c.r[1] += 4;  // 06047AEC add #4,r1
    c.r[3] += c.r[6];  // 06047AEE add r6,r3
    st16(c.r[1], c.r[3]);  // 06047AF0 mov.w r3,@r1
    c.r[2] += 2;  // 06047AF2 add #2,r2
    st16(c.r[2], c.r[3]);  // 06047AF4 mov.w r3,@r2
    c.r[2] = ld32(c.r[7] + 28);  // 06047AF6 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047AF8 mov r2,r1
    c.r[1] += 1;  // 06047AFA add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047AFC mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047AFE mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047B00 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047B02 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047B04 mov r2,r1
    c.r[1] += 1;  // 06047B06 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B08 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B0A mov.b @r2,r1
    c.r[5] <<= 8;  // 06047B0C shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047B0E extu.b r1,r6
    c.r[1] = c.r[13];  // 06047B10 mov r13,r1
    c.r[1] += 14;  // 06047B12 add #14,r1
    c.r[5] += c.r[6];  // 06047B14 add r6,r5
    st16(c.r[1], c.r[5]);  // 06047B16 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047B18 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047B1A mov r2,r1
    c.r[1] += 1;  // 06047B1C add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B1E mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B20 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047B22 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047B24 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047B26 mov r2,r1
    c.r[1] += 1;  // 06047B28 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B2A mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B2C mov.b @r2,r1
    c.r[5] <<= 8;  // 06047B2E shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047B30 extu.b r1,r6
    c.r[1] = c.r[13];  // 06047B32 mov r13,r1
    c.r[1] += 16;  // 06047B34 add #16,r1
    c.r[5] += c.r[6];  // 06047B36 add r6,r5
    st16(c.r[1], c.r[5]);  // 06047B38 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047B3A mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047B3C mov r2,r1
    c.r[1] += 1;  // 06047B3E add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B40 mov.l r1,@(28,r7)
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B42 mov.b @r2,r3
    c.r[2] = ld32(c.r[7] + 28);  // 06047B44 mov.l @(28,r7),r2
    c.r[3] = c.r[3] & 0xFFu;  // 06047B46 extu.b r3,r3
    c.r[1] = c.r[2];  // 06047B48 mov r2,r1
    c.r[1] += 1;  // 06047B4A add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B4C mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B4E mov.b @r2,r1
    c.r[3] <<= 8;  // 06047B50 shll8 r3
    c.r[6] = c.r[1] & 0xFFu;  // 06047B52 extu.b r1,r6
    c.r[1] = c.r[13];  // 06047B54 mov r13,r1
    c.r[1] += 24;  // 06047B56 add #24,r1
    c.r[3] += c.r[6];  // 06047B58 add r6,r3
    st16(c.r[1], c.r[3]);  // 06047B5A mov.w r3,@r1
    c.r[1] = c.r[13];  // 06047B5C mov r13,r1
    c.r[1] += 22;  // 06047B5E add #22,r1
    st16(c.r[1], c.r[3]);  // 06047B60 mov.w r3,@r1
    c.r[1] = ld32(c.r[7] + 28);  // 06047B62 mov.l @(28,r7),r1
    c.r[1] += 1;  // 06047B64 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B66 mov.l r1,@(28,r7)
    c.r[2] = ld32(c.r[7] + 28);  // 06047B68 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047B6A mov r2,r1
    c.r[1] += 1;  // 06047B6C add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B6E mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B70 mov.b @r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06047B72 extu.b r1,r6
    c.r[1] = c.r[13];  // 06047B74 mov r13,r1
    c.r[1] += 27;  // 06047B76 add #27,r1
    st8(c.r[1], c.r[6]);  // 06047B78 mov.b r6,@r1
    c.r[1] = c.r[13];  // 06047B7A mov r13,r1
    c.r[1] += 26;  // 06047B7C add #26,r1
    st8(c.r[1], c.r[6]);  // 06047B7E mov.b r6,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047B80 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047B82 mov r2,r1
    c.r[1] += 1;  // 06047B84 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B86 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B88 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047B8A mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047B8C extu.b r1,r5
    c.r[1] = c.r[2];  // 06047B8E mov r2,r1
    c.r[1] += 1;  // 06047B90 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047B92 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047B94 mov.b @r2,r1
    c.r[5] <<= 8;  // 06047B96 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047B98 extu.b r1,r6
    c.r[1] = c.r[13];  // 06047B9A mov r13,r1
    c.r[1] += 18;  // 06047B9C add #18,r1
    c.r[5] += c.r[6];  // 06047B9E add r6,r5
    st16(c.r[1], c.r[5]);  // 06047BA0 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047BA2 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047BA4 mov r2,r1
    c.r[1] += 1;  // 06047BA6 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047BA8 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047BAA mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047BAC mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047BAE extu.b r1,r5
    c.r[1] = c.r[2];  // 06047BB0 mov r2,r1
    c.r[1] += 1;  // 06047BB2 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047BB4 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047BB6 mov.b @r2,r1
    c.r[5] <<= 8;  // 06047BB8 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047BBA extu.b r1,r6
    c.r[1] = c.r[13];  // 06047BBC mov r13,r1
    c.r[1] += 20;  // 06047BBE add #20,r1
    c.r[5] += c.r[6];  // 06047BC0 add r6,r5
    st16(c.r[1], c.r[5]);  // 06047BC2 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047BC4 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047BC6 mov r2,r1
    c.r[1] += 1;  // 06047BC8 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047BCA mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047BCC mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047BCE mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047BD0 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047BD2 mov r2,r1
    c.r[1] += 1;  // 06047BD4 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047BD6 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047BD8 mov.b @r2,r1
    c.r[5] <<= 8;  // 06047BDA shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047BDC extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047BDE mov.l @r14,r1
    c.r[5] += c.r[6];  // 06047BE0 add r6,r5
    c.r[1] += 6;  // 06047BE2 add #6,r1
    st16(c.r[1], c.r[5]);  // 06047BE4 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047BE6 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047BE8 mov r2,r1
    c.r[1] += 1;  // 06047BEA add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047BEC mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047BEE mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047BF0 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047BF2 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047BF4 mov r2,r1
    c.r[1] += 1;  // 06047BF6 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047BF8 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047BFA mov.b @r2,r1
    c.r[5] <<= 8;  // 06047BFC shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047BFE extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047C00 mov.l @r14,r1
    c.r[5] += c.r[6];  // 06047C02 add r6,r5
    c.r[1] += 10;  // 06047C04 add #10,r1
    st16(c.r[1], c.r[5]);  // 06047C06 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C08 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047C0A mov r2,r1
    c.r[1] += 1;  // 06047C0C add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C0E mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C10 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C12 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047C14 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047C16 mov r2,r1
    c.r[1] += 1;  // 06047C18 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C1A mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C1C mov.b @r2,r1
    c.r[5] <<= 8;  // 06047C1E shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047C20 extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047C22 mov.l @r14,r1
    c.r[5] += c.r[6];  // 06047C24 add r6,r5
    c.r[1] += 14;  // 06047C26 add #14,r1
    st16(c.r[1], c.r[5]);  // 06047C28 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C2A mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047C2C mov r2,r1
    c.r[1] += 1;  // 06047C2E add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C30 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C32 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C34 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047C36 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047C38 mov r2,r1
    c.r[1] += 1;  // 06047C3A add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C3C mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C3E mov.b @r2,r1
    c.r[5] <<= 8;  // 06047C40 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047C42 extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047C44 mov.l @r14,r1
    c.r[5] += c.r[6];  // 06047C46 add r6,r5
    c.r[1] += 16;  // 06047C48 add #16,r1
    st16(c.r[1], c.r[5]);  // 06047C4A mov.w r5,@r1
    c.r[1] = ld32(c.r[7] + 28);  // 06047C4C mov.l @(28,r7),r1
    c.r[1] += 1;  // 06047C4E add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C50 mov.l r1,@(28,r7)
    c.r[2] = ld32(c.r[7] + 28);  // 06047C52 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047C54 mov r2,r1
    c.r[1] += 1;  // 06047C56 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C58 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C5A mov.b @r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06047C5C extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047C5E mov.l @r14,r1
    c.r[3] = 0x0u;  // 06047C60 mov #0,r3
    c.r[1] += 24;  // 06047C62 add #24,r1
    st16(c.r[1], c.r[3]);  // 06047C64 mov.w r3,@r1
    c.r[1] = ld32(c.r[14]);  // 06047C66 mov.l @r14,r1
    c.r[1] += 22;  // 06047C68 add #22,r1
    st16(c.r[1], c.r[3]);  // 06047C6A mov.w r3,@r1
    c.r[1] = ld32(c.r[14]);  // 06047C6C mov.l @r14,r1
    c.r[1] += 27;  // 06047C6E add #27,r1
    st8(c.r[1], c.r[6]);  // 06047C70 mov.b r6,@r1
    c.r[1] = ld32(c.r[14]);  // 06047C72 mov.l @r14,r1
    c.r[1] += 26;  // 06047C74 add #26,r1
    st8(c.r[1], c.r[6]);  // 06047C76 mov.b r6,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C78 mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047C7A mov r2,r1
    c.r[1] += 1;  // 06047C7C add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C7E mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C80 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C82 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047C84 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047C86 mov r2,r1
    c.r[1] += 1;  // 06047C88 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047C8A mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047C8C mov.b @r2,r1
    c.r[5] <<= 8;  // 06047C8E shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047C90 extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047C92 mov.l @r14,r1
    c.r[5] += c.r[6];  // 06047C94 add r6,r5
    c.r[1] += 18;  // 06047C96 add #18,r1
    st16(c.r[1], c.r[5]);  // 06047C98 mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047C9A mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047C9C mov r2,r1
    c.r[1] += 1;  // 06047C9E add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047CA0 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047CA2 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047CA4 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047CA6 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047CA8 mov r2,r1
    c.r[1] += 1;  // 06047CAA add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047CAC mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047CAE mov.b @r2,r1
    c.r[5] <<= 8;  // 06047CB0 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06047CB2 extu.b r1,r6
    c.r[1] = ld32(c.r[14]);  // 06047CB4 mov.l @r14,r1
    c.r[5] += c.r[6];  // 06047CB6 add r6,r5
    c.r[1] += 20;  // 06047CB8 add #20,r1
    st16(c.r[1], c.r[5]);  // 06047CBA mov.w r5,@r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047CBC mov.l @(28,r7),r2
    c.r[1] = c.r[2];  // 06047CBE mov r2,r1
    c.r[1] += 1;  // 06047CC0 add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047CC2 mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047CC4 mov.b @r2,r1
    c.r[2] = ld32(c.r[7] + 28);  // 06047CC6 mov.l @(28,r7),r2
    c.r[5] = c.r[1] & 0xFFu;  // 06047CC8 extu.b r1,r5
    c.r[1] = c.r[2];  // 06047CCA mov r2,r1
    c.r[1] += 1;  // 06047CCC add #1,r1
    st32(c.r[7] + 28, c.r[1]);  // 06047CCE mov.l r1,@(28,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047CD0 mov.b @r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06047CD2 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06047CD4 mov.b @r7,r1
    c.r[0] = 0x1u;  // 06047CD6 mov #1,r0
    c.r[1] >>= 2;  // 06047CD8 shlr2 r1
    c.r[1] >>= 2;  // 06047CDA shlr2 r1
    c.r[1] &= c.r[0];  // 06047CDC and r0,r1
    c.r[0] = c.r[1];  // 06047CDE mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06047CE0 cmp/eq #1,r0
    { const bool k = !c.t; c.r[12] = c.r[13]; if (k) { goto L_06047D94; } }  // 06047CE2 bf/s 0x06047D94 ; mov r13,r12
    c.r[12] += 2;  // 06047CE6 add #2,r12
    c.r[8] = c.r[5];  // 06047CE8 mov r5,r8
    c.r[8] <<= 8;  // 06047CEA shll8 r8
    c.r[8] += c.r[6];  // 06047CEC add r6,r8
    st16(c.r[12], c.r[8]);  // 06047CEE mov.w r8,@r12
    c.r[10] = ld32(0x06047D8Cu);  // 06047CF0 mov.l 0x06047D8C,r10
    c.r[9] = ld32(0x06047D90u);  // 06047CF2 mov.l 0x06047D90,r9
    c.r[5] = 0x1Du;  // 06047CF4 mov #29,r5
    c.r[11] = ld32(c.r[14]);  // 06047CF6 mov.l @r14,r11
    c.r[4] = c.r[10];  // 06047CF8 mov r10,r4
    c.r[11] += 2;  // 06047CFA add #2,r11
    st16(c.r[11], c.r[8]);  // 06047CFC mov.w r8,@r11
    { const uint32_t x = c.r[9]; c.pr = 0x06047D02u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D02u) return; }  // 06047CFE jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047D02 mov r0,r1
    c.r[5] = c.r[8];  // 06047D04 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06047D0Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D0Au) return; }  // 06047D06 jsr @r9 ; mov r1,r4
    st32(c.r[14] + 4, c.r[0]);  // 06047D0A mov.l r0,@(4,r14)
    c.r[5] = 0x1Du;  // 06047D0C mov #29,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06047D0E mov.w @r12,r8
    c.r[4] = c.r[10];  // 06047D10 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06047D16u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D16u) return; }  // 06047D12 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047D16 mov r0,r1
    c.r[5] = c.r[8];  // 06047D18 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06047D1Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D1Eu) return; }  // 06047D1A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06047D1E mov r0,r1
    c.r[13] += 4;  // 06047D20 add #4,r13
    c.r[0] = ld32(c.r[14] + 4);  // 06047D22 mov.l @(4,r14),r0
    c.r[1] += 4;  // 06047D24 add #4,r1
    c.r[0] += 3;  // 06047D26 add #3,r0
    st32(c.r[14] + 4, c.r[0]);  // 06047D28 mov.l r0,@(4,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06047D2A mov.b @r0,r2
    c.r[5] = 0x1Du;  // 06047D2C mov #29,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047D2E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06047D30 extu.b r2,r2
    c.r[2] <<= 8;  // 06047D32 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06047D34 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06047D36 or r1,r2
    st16(c.r[13], c.r[2]);  // 06047D38 mov.w r2,@r13
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06047D3A mov.w @r11,r8
    c.r[4] = c.r[10];  // 06047D3C mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06047D42u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D42u) return; }  // 06047D3E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047D42 mov r0,r1
    c.r[5] = c.r[8];  // 06047D44 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06047D4Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D4Au) return; }  // 06047D46 jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 06047D4A mov r0,r12
    c.r[5] = 0x1Du;  // 06047D4C mov #29,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06047D4E mov.w @r11,r8
    c.r[4] = c.r[10];  // 06047D50 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06047D56u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D56u) return; }  // 06047D52 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047D56 mov r0,r1
    c.r[5] = c.r[8];  // 06047D58 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06047D5Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047D5Eu) return; }  // 06047D5A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06047D5E mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 06047D60 mov.l @r14,r0
    c.r[12] += 3;  // 06047D62 add #3,r12
    c.r[0] += 4;  // 06047D64 add #4,r0
    st32(c.r[14], c.r[0]);  // 06047D66 mov.l r0,@r14
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06047D68 mov.b @r12,r2
    c.r[1] += 4;  // 06047D6A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047D6C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06047D6E extu.b r2,r2
    c.r[2] <<= 8;  // 06047D70 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06047D72 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06047D74 or r1,r2
    st16(c.r[0], c.r[2]); goto L_06047DB2;  // 06047D76 bra 0x06047DB2 ; mov.w r2,@r0
L_06047D94:
    c.r[1] = c.r[13];  // 06047D94 mov r13,r1
    c.r[1] += 2;  // 06047D96 add #2,r1
    st16(c.r[1], c.r[3]);  // 06047D98 mov.w r3,@r1
    c.r[1] = ld32(c.r[14]);  // 06047D9A mov.l @r14,r1
    c.r[13] += 4;  // 06047D9C add #4,r13
    c.r[0] = ld32(c.r[14]);  // 06047D9E mov.l @r14,r0
    c.r[1] += 2;  // 06047DA0 add #2,r1
    st16(c.r[1], c.r[3]);  // 06047DA2 mov.w r3,@r1
    c.r[1] = c.r[5];  // 06047DA4 mov r5,r1
    c.r[1] <<= 8;  // 06047DA6 shll8 r1
    c.r[1] += c.r[6];  // 06047DA8 add r6,r1
    st16(c.r[13], c.r[1]);  // 06047DAA mov.w r1,@r13
    c.r[0] += 4;  // 06047DAC add #4,r0
    st32(c.r[14], c.r[0]);  // 06047DAE mov.l r0,@r14
    st16(c.r[0], c.r[1]);  // 06047DB0 mov.w r1,@r0
L_06047DB2:
    c.r[2] = ld32(0x06047F18u);  // 06047DB2 mov.l 0x06047F18,r2
    c.r[3] = ld32(c.r[2] + 28);  // 06047DB4 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06047DB6 mov r3,r1
    c.r[1] += 1;  // 06047DB8 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06047DBA mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06047DBC mov.b @r3,r1
    c.r[0] = 0x2u;  // 06047DBE mov #2,r0
    c.r[7] = c.r[1] & 0xFFu;  // 06047DC0 extu.b r1,r7
    c.r[3] = ld32(c.r[2] + 28);  // 06047DC2 mov.l @(28,r2),r3
    c.r[7] <<= 8;  // 06047DC4 shll8 r7
    c.r[1] = c.r[3];  // 06047DC6 mov r3,r1
    c.r[1] += 1;  // 06047DC8 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06047DCA mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06047DCC mov.b @r3,r1
    c.r[2] = ld32(0x06047F1Cu);  // 06047DCE mov.l 0x06047F1C,r2
    c.r[6] = c.r[1] & 0xFFu;  // 06047DD0 extu.b r1,r6
    c.r[7] |= c.r[6];  // 06047DD2 or r6,r7
    c.r[3] = c.r[7];  // 06047DD4 mov r7,r3
    c.r[3] >>= 8;  // 06047DD6 shlr8 r3
    c.r[3] <<= 2;  // 06047DD8 shll2 r3
    c.r[3] >>= 8;  // 06047DDA shlr8 r3
    c.r[3] <<= 2;  // 06047DDC shll2 r3
    c.r[3] <<= 2;  // 06047DDE shll2 r3
    c.r[3] += c.r[3];  // 06047DE0 add r3,r3
    c.r[3] <<= 2;  // 06047DE2 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06047DE4 mov.w @r2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06047F06u);  // 06047DE6 mov.w 0x06047F06,r6
    c.r[1] &= c.r[6];  // 06047DE8 and r6,r1
    c.r[1] |= c.r[3];  // 06047DEA or r3,r1
    st16(c.r[2], c.r[1]);  // 06047DEC mov.w r1,@r2
    c.r[1] = ld32(0x06047F20u);  // 06047DEE mov.l 0x06047F20,r1
    c.r[2] = 0x0u;  // 06047DF0 mov #0,r2
    st8(c.r[1], c.r[2]);  // 06047DF2 mov.b r2,@r1
    c.r[1] = ld32(0x06047F24u);  // 06047DF4 mov.l 0x06047F24,r1
    st8(c.r[1], c.r[2]);  // 06047DF6 mov.b r2,@r1
    c.r[3] = ld32(0x06047F28u);  // 06047DF8 mov.l 0x06047F28,r3
    c.r[2] = c.r[7];  // 06047DFA mov r7,r2
    c.r[2] >>= 8;  // 06047DFC shlr8 r2
    c.r[2] >>= 2;  // 06047DFE shlr2 r2
    c.r[2] >>= 2;  // 06047E00 shlr2 r2
    c.r[2] &= c.r[0];  // 06047E02 and r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06047E04 mov.b @r3,r1
    c.r[0] = 0x7Du;  // 06047E06 mov #125,r0
    c.r[1] &= c.r[0];  // 06047E08 and r0,r1
    c.r[1] |= c.r[2];  // 06047E0A or r2,r1
    c.r[2] = c.r[7];  // 06047E0C mov r7,r2
    c.r[2] >>= 2;  // 06047E0E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06047E10 shlr r2
    c.r[2] >>= 2;  // 06047E12 shlr2 r2
    c.r[0] = 0x10u;  // 06047E14 mov #16,r0
    c.r[2] &= c.r[0];  // 06047E16 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047F08u);  // 06047E18 mov.w 0x06047F08,r0
    c.r[1] &= c.r[0];  // 06047E1A and r0,r1
    c.r[1] |= c.r[2];  // 06047E1C or r2,r1
    c.r[2] = c.r[7];  // 06047E1E mov r7,r2
    c.r[2] >>= 2;  // 06047E20 shlr2 r2
    c.r[0] = 0x40u;  // 06047E22 mov #64,r0
    c.r[2] &= c.r[0];  // 06047E24 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047F0Au);  // 06047E26 mov.w 0x06047F0A,r0
    c.r[1] &= c.r[0];  // 06047E28 and r0,r1
    c.r[1] |= c.r[2];  // 06047E2A or r2,r1
    c.r[2] = c.r[7];  // 06047E2C mov r7,r2
    c.r[2] >>= 2;  // 06047E2E shlr2 r2
    c.r[0] = 0x20u;  // 06047E30 mov #32,r0
    c.r[2] &= c.r[0];  // 06047E32 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047F0Cu);  // 06047E34 mov.w 0x06047F0C,r0
    c.r[1] &= c.r[0];  // 06047E36 and r0,r1
    c.r[1] |= c.r[2];  // 06047E38 or r2,r1
    st8(c.r[3], c.r[1]);  // 06047E3A mov.b r1,@r3
    c.r[1] = 0x20u;  // 06047E3C mov #32,r1
    c.r[1] &= c.r[7];  // 06047E3E and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047E40 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_06047E52; } }  // 06047E42 bt/s 0x06047E52 ; mov #64,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06047E46 mov.w @r3,r1
    c.r[0] = c.r[1];  // 06047E48 mov r1,r0
    c.r[0] &= c.r[6];  // 06047E4A and r6,r0
    c.r[0] |= 0x80u;  // 06047E4C or #128,r0
    st16(c.r[3], c.r[0]); goto L_06047E64;  // 06047E4E bra 0x06047E64 ; mov.w r0,@r3
L_06047E52:
    c.r[1] &= c.r[7];  // 06047E52 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047E54 tst r1,r1
    { const bool k = c.t; c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { goto L_06047E60; } }  // 06047E56 bt/s 0x06047E60 ; mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06047F0Eu);  // 06047E5A mov.w 0x06047F0E,r2
    c.r[1] |= c.r[2]; goto L_06047E62;  // 06047E5C bra 0x06047E62 ; or r2,r1
L_06047E60:
    c.r[1] &= c.r[6];  // 06047E60 and r6,r1
L_06047E62:
    st16(c.r[3], c.r[1]);  // 06047E62 mov.w r1,@r3
L_06047E64:
    c.r[1] = 0x10u;  // 06047E64 mov #16,r1
    c.r[1] &= c.r[7];  // 06047E66 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047E68 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_06047E78; } }  // 06047E6A bt/s 0x06047E78 ; mov #8,r1
    c.r[1] = ld32(0x06047F28u);  // 06047E6E mov.l 0x06047F28,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047E70 mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 06047E72 and #243,r0
    c.r[0] |= 0x4u; goto L_06047E8C;  // 06047E74 bra 0x06047E8C ; or #4,r0
L_06047E78:
    c.r[1] &= c.r[7];  // 06047E78 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06047E7A tst r1,r1
    if (c.t) { goto L_06047E86; }  // 06047E7C bt 0x06047E86
    c.r[1] = ld32(0x06047F28u);  // 06047E7E mov.l 0x06047F28,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047E80 mov.b @r1,r0
    c.r[0] |= 0xCu; goto L_06047E8C;  // 06047E82 bra 0x06047E8C ; or #12,r0
L_06047E86:
    c.r[1] = ld32(0x06047F28u);  // 06047E86 mov.l 0x06047F28,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047E88 mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 06047E8A and #243,r0
L_06047E8C:
    st8(c.r[1], c.r[0]);  // 06047E8C mov.b r0,@r1
    c.r[2] = 0x3u;  // 06047E8E mov #3,r2
    c.r[2] &= c.r[7];  // 06047E90 and r7,r2
    c.r[1] = ld32(0x06047F2Cu);  // 06047E92 mov.l 0x06047F2C,r1
    c.r[2] <<= 2;  // 06047E94 shll2 r2
    c.r[2] <<= 2;  // 06047E96 shll2 r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047E98 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047F10u);  // 06047E9A mov.w 0x06047F10,r0
    c.r[5] = c.r[7];  // 06047E9C mov r7,r5
    c.r[5] >>= 8;  // 06047E9E shlr8 r5
    c.r[5] >>= 2;  // 06047EA0 shlr2 r5
    c.r[3] &= c.r[0];  // 06047EA2 and r0,r3
    c.r[3] |= c.r[2];  // 06047EA4 or r2,r3
    c.r[0] = 0x7u;  // 06047EA6 mov #7,r0
    c.r[5] &= c.r[0];  // 06047EA8 and r0,r5
    c.r[2] = c.r[5] & 0xFFFFu;  // 06047EAA extu.w r5,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06047EAC tst r2,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { goto L_06047ED2; } }  // 06047EAE bf/s 0x06047ED2 ; mov.b r3,@r1
    c.r[3] = ld32(0x06047F30u);  // 06047EB2 mov.l 0x06047F30,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047F12u);  // 06047EB4 mov.w 0x06047F12,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06047EB6 mov.b @r3,r0
    c.r[2] = ld32(0x06047F34u);  // 06047EB8 mov.l 0x06047F34,r2
    c.r[1] &= c.r[0];  // 06047EBA and r0,r1
    st8(c.r[3], c.r[1]);  // 06047EBC mov.b r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047F12u);  // 06047EBE mov.w 0x06047F12,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047EC0 mov.b @r2,r7
    c.r[0] &= 0xE0u;  // 06047EC2 and #224,r0
    c.r[1] &= c.r[7];  // 06047EC4 and r7,r1
    st8(c.r[2], c.r[1]);  // 06047EC6 mov.b r1,@r2
    st8(c.r[3], c.r[0]);  // 06047EC8 mov.b r0,@r3
    c.r[0] = c.r[7];  // 06047ECA mov r7,r0
    c.r[0] &= 0xE0u;  // 06047ECC and #224,r0
    st8(c.r[2], c.r[0]); goto L_06047F5E;  // 06047ECE bra 0x06047F5E ; mov.b r0,@r2
L_06047ED2:
    c.r[1] = 0x4u;  // 06047ED2 mov #4,r1
    c.t = c.r[2] > c.r[1];  // 06047ED4 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06047F38; } }  // 06047ED6 bf/s 0x06047F38 ; mov #3,r0
    c.r[3] = ld32(0x06047F30u);  // 06047EDA mov.l 0x06047F30,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047F12u);  // 06047EDC mov.w 0x06047F12,r1
    c.r[2] = ld32(0x06047F34u);  // 06047EDE mov.l 0x06047F34,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06047EE0 mov.b @r3,r6
    c.r[1] &= c.r[6];  // 06047EE2 and r6,r1
    st8(c.r[3], c.r[1]);  // 06047EE4 mov.b r1,@r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047EE6 mov.b @r2,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06047F12u);  // 06047EE8 mov.w 0x06047F12,r1
    c.r[1] &= c.r[7];  // 06047EEA and r7,r1
    st8(c.r[2], c.r[1]);  // 06047EEC mov.b r1,@r2
    c.r[1] = c.r[5];  // 06047EEE mov r5,r1
    c.r[1] -= 4;  // 06047EF0 add #-4,r1
    c.r[1] &= c.r[0];  // 06047EF2 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06047F14u);  // 06047EF4 mov.w 0x06047F14,r0
    c.r[6] &= c.r[0];  // 06047EF6 and r0,r6
    c.r[6] |= c.r[1];  // 06047EF8 or r1,r6
    st8(c.r[3], c.r[6]);  // 06047EFA mov.b r6,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06047F14u);  // 06047EFC mov.w 0x06047F14,r3
    c.r[3] &= c.r[7];  // 06047EFE and r7,r3
    c.r[3] |= c.r[1];  // 06047F00 or r1,r3
    st8(c.r[2], c.r[3]); goto L_06047F5E;  // 06047F02 bra 0x06047F5E ; mov.b r3,@r2
L_06047F38:
    c.r[1] = ld32(0x06048128u);  // 06047F38 mov.l 0x06048128,r1
    c.r[3] = c.r[5];  // 06047F3A mov r5,r3
    c.r[3] <<= 2;  // 06047F3C shll2 r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047F3E mov.b @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06048120u);  // 06047F40 mov.w 0x06048120,r7
    c.r[7] &= c.r[2];  // 06047F42 and r2,r7
    c.r[7] |= c.r[3];  // 06047F44 or r3,r7
    st8(c.r[1], c.r[7]);  // 06047F46 mov.b r7,@r1
    c.r[2] = ld32(0x0604812Cu);  // 06047F48 mov.l 0x0604812C,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06047F4A mov.b @r2,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048120u);  // 06047F4C mov.w 0x06048120,r0
    c.r[6] &= c.r[0];  // 06047F4E and r0,r6
    c.r[6] |= c.r[3];  // 06047F50 or r3,r6
    st8(c.r[2], c.r[6]);  // 06047F52 mov.b r6,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048122u);  // 06047F54 mov.w 0x06048122,r0
    c.r[7] &= c.r[0];  // 06047F56 and r0,r7
    st8(c.r[1], c.r[7]);  // 06047F58 mov.b r7,@r1
    c.r[6] &= c.r[0];  // 06047F5A and r0,r6
    st8(c.r[2], c.r[6]);  // 06047F5C mov.b r6,@r2
L_06047F5E:
    c.r[10] = ld32(0x06048128u);  // 06047F5E mov.l 0x06048128,r10
    c.r[12] = c.r[10];  // 06047F60 mov r10,r12
    c.r[12] += 10;  // 06047F62 add #10,r12
    c.r[5] = 0x1Bu;  // 06047F64 mov #27,r5
    c.r[4] = ld32(0x06048130u);  // 06047F66 mov.l 0x06048130,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06047F68 mov.w @r12,r8
    c.r[0] = ld32(0x06048134u);  // 06047F6A mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047F70u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047F70u) return; }  // 06047F6C jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047F70 mov r0,r1
    c.r[5] = c.r[8];  // 06047F72 mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 06047F74 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047F7Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047F7Au) return; }  // 06047F76 jsr @r0 ; mov r1,r4
    c.r[9] = c.r[0];  // 06047F7A mov r0,r9
    c.r[5] = 0x1Bu;  // 06047F7C mov #27,r5
    c.r[4] = ld32(0x06048130u);  // 06047F7E mov.l 0x06048130,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06047F80 mov.w @r12,r8
    c.r[0] = ld32(0x06048134u);  // 06047F82 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047F88u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047F88u) return; }  // 06047F84 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047F88 mov r0,r1
    c.r[5] = c.r[8];  // 06047F8A mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 06047F8C mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047F92u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047F92u) return; }  // 06047F8E jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 06047F92 mov r0,r1
    c.r[3] = c.r[10];  // 06047F94 mov r10,r3
    c.r[3] += 12;  // 06047F96 add #12,r3
    c.r[9] += 2;  // 06047F98 add #2,r9
    c.r[1] += 3;  // 06047F9A add #3,r1
    c.r[5] = 0x1Bu;  // 06047F9C mov #27,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06047F9E mov.b @r9,r2
    c.r[4] = ld32(0x06048130u);  // 06047FA0 mov.l 0x06048130,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047FA2 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06047FA4 extu.b r2,r2
    c.r[2] <<= 8;  // 06047FA6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06047FA8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06047FAA or r1,r2
    st16(c.r[3], c.r[2]);  // 06047FAC mov.w r2,@r3
    c.r[9] = ld32(0x0604812Cu);  // 06047FAE mov.l 0x0604812C,r9
    c.r[11] = c.r[9];  // 06047FB0 mov r9,r11
    c.r[11] += 10;  // 06047FB2 add #10,r11
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06047FB4 mov.w @r11,r8
    c.r[0] = ld32(0x06048134u);  // 06047FB6 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047FBCu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047FBCu) return; }  // 06047FB8 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047FBC mov r0,r1
    c.r[5] = c.r[8];  // 06047FBE mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 06047FC0 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047FC6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047FC6u) return; }  // 06047FC2 jsr @r0 ; mov r1,r4
    c.r[13] = c.r[0];  // 06047FC6 mov r0,r13
    c.r[5] = 0x1Bu;  // 06047FC8 mov #27,r5
    c.r[4] = ld32(0x06048130u);  // 06047FCA mov.l 0x06048130,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06047FCC mov.w @r11,r8
    c.r[0] = ld32(0x06048134u);  // 06047FCE mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047FD4u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047FD4u) return; }  // 06047FD0 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06047FD4 mov r0,r1
    c.r[5] = c.r[8];  // 06047FD6 mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 06047FD8 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06047FDEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06047FDEu) return; }  // 06047FDA jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 06047FDE mov r0,r1
    c.r[3] = c.r[9];  // 06047FE0 mov r9,r3
    c.r[3] += 12;  // 06047FE2 add #12,r3
    c.r[13] += 2;  // 06047FE4 add #2,r13
    c.r[1] += 3;  // 06047FE6 add #3,r1
    c.r[5] = 0x1Bu;  // 06047FE8 mov #27,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06047FEA mov.b @r13,r2
    c.r[4] = ld32(0x06048130u);  // 06047FEC mov.l 0x06048130,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06047FEE mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06047FF0 extu.b r2,r2
    c.r[2] <<= 8;  // 06047FF2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06047FF4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06047FF6 or r1,r2
    st16(c.r[3], c.r[2]);  // 06047FF8 mov.w r2,@r3
    c.r[1] = c.r[10];  // 06047FFA mov r10,r1
    c.r[1] += 8;  // 06047FFC add #8,r1
    c.r[13] = 0x0u;  // 06047FFE mov #0,r13
    st16(c.r[1], c.r[13]);  // 06048000 mov.w r13,@r1
    c.r[1] = c.r[9];  // 06048002 mov r9,r1
    c.r[1] += 8;  // 06048004 add #8,r1
    st16(c.r[1], c.r[13]);  // 06048006 mov.w r13,@r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06048008 mov.w @r12,r8
    c.r[0] = ld32(0x06048134u);  // 0604800A mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048010u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048010u) return; }  // 0604800C jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06048010 mov r0,r1
    c.r[5] = c.r[8];  // 06048012 mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 06048014 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604801Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604801Au) return; }  // 06048016 jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 0604801A mov r0,r1
    c.r[1] += 6;  // 0604801C add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048124u);  // 0604801E mov.w 0x06048124,r0
    c.r[5] = 0x1Bu;  // 06048020 mov #27,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048022 mov.b @r1,r1
    c.r[4] = ld32(0x06048130u);  // 06048024 mov.l 0x06048130,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06048026 mov.b @r10,r2
    c.r[1] &= c.r[0];  // 06048028 and r0,r1
    c.r[0] = 0x1Fu;  // 0604802A mov #31,r0
    c.r[2] &= c.r[0];  // 0604802C and r0,r2
    c.r[2] |= c.r[1];  // 0604802E or r1,r2
    st8(c.r[10], c.r[2]);  // 06048030 mov.b r2,@r10
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06048032 mov.w @r11,r8
    c.r[0] = ld32(0x06048134u);  // 06048034 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604803Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604803Au) return; }  // 06048036 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0604803A mov r0,r1
    c.r[5] = c.r[8];  // 0604803C mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 0604803E mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048044u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048044u) return; }  // 06048040 jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 06048044 mov r0,r1
    c.r[1] += 6;  // 06048046 add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048124u);  // 06048048 mov.w 0x06048124,r0
    c.r[5] = 0x1Bu;  // 0604804A mov #27,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604804C mov.b @r1,r1
    c.r[4] = ld32(0x06048130u);  // 0604804E mov.l 0x06048130,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06048050 mov.b @r9,r2
    c.r[1] &= c.r[0];  // 06048052 and r0,r1
    c.r[0] = 0x1Fu;  // 06048054 mov #31,r0
    c.r[2] &= c.r[0];  // 06048056 and r0,r2
    c.r[2] |= c.r[1];  // 06048058 or r1,r2
    st8(c.r[9], c.r[2]);  // 0604805A mov.b r2,@r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0604805C mov.w @r12,r8
    c.r[0] = ld32(0x06048134u);  // 0604805E mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048064u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048064u) return; }  // 06048060 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06048064 mov r0,r1
    c.r[5] = c.r[8];  // 06048066 mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 06048068 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604806Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604806Eu) return; }  // 0604806A jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 0604806E mov r0,r1
    c.r[1] += 10;  // 06048070 add #10,r1
    c.r[10] += 1;  // 06048072 add #1,r10
    c.r[2] = 0x3u;  // 06048074 mov #3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048126u);  // 06048076 mov.w 0x06048126,r0
    c.r[5] = 0x1Bu;  // 06048078 mov #27,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604807A mov.b @r1,r1
    c.r[4] = ld32(0x06048130u);  // 0604807C mov.l 0x06048130,r4
    c.r[2] &= c.r[1];  // 0604807E and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06048080 mov.b @r10,r1
    c.r[2] <<= 2;  // 06048082 shll2 r2
    c.r[2] += c.r[2];  // 06048084 add r2,r2
    c.r[2] <<= 2;  // 06048086 shll2 r2
    c.r[1] &= c.r[0];  // 06048088 and r0,r1
    c.r[1] |= c.r[2];  // 0604808A or r2,r1
    st8(c.r[10], c.r[1]);  // 0604808C mov.b r1,@r10
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604808E mov.w @r11,r8
    c.r[0] = ld32(0x06048134u);  // 06048090 mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048096u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048096u) return; }  // 06048092 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06048096 mov r0,r1
    c.r[5] = c.r[8];  // 06048098 mov r8,r5
    c.r[0] = ld32(0x06048134u);  // 0604809A mov.l 0x06048134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060480A0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060480A0u) return; }  // 0604809C jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 060480A0 mov r0,r1
    c.r[1] += 10;  // 060480A2 add #10,r1
    c.r[9] += 1;  // 060480A4 add #1,r9
    c.r[2] = 0x3u;  // 060480A6 mov #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060480A8 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048126u);  // 060480AA mov.w 0x06048126,r0
    c.r[2] &= c.r[1];  // 060480AC and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060480AE mov.b @r9,r1
    c.r[2] <<= 2;  // 060480B0 shll2 r2
    c.r[2] += c.r[2];  // 060480B2 add r2,r2
    c.r[2] <<= 2;  // 060480B4 shll2 r2
    c.r[1] &= c.r[0];  // 060480B6 and r0,r1
    c.r[1] |= c.r[2];  // 060480B8 or r2,r1
    st8(c.r[9], c.r[1]);  // 060480BA mov.b r1,@r9
    c.r[2] = ld32(0x06048138u);  // 060480BC mov.l 0x06048138,r2
    c.r[3] = ld32(c.r[2] + 28);  // 060480BE mov.l @(28,r2),r3
    c.r[11] = ld32(0x0604813Cu);  // 060480C0 mov.l 0x0604813C,r11
    c.r[1] = c.r[3];  // 060480C2 mov r3,r1
    c.r[1] += 1;  // 060480C4 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060480C6 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060480C8 mov.b @r3,r1
    c.r[12] = ld32(0x06048140u);  // 060480CA mov.l 0x06048140,r12
    c.r[5] = c.r[1] & 0xFFu;  // 060480CC extu.b r1,r5
    c.r[1] = c.r[11];  // 060480CE mov r11,r1
    c.r[1] += 30;  // 060480D0 add #30,r1
    st8(c.r[1], c.r[5]);  // 060480D2 mov.b r5,@r1
    c.r[1] = c.r[12];  // 060480D4 mov r12,r1
    c.r[1] += 30;  // 060480D6 add #30,r1
    st8(c.r[1], c.r[5]);  // 060480D8 mov.b r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 060480DA mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060480DC mov r3,r1
    c.r[1] += 1;  // 060480DE add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060480E0 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060480E2 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 060480E4 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 060480E6 extu.b r1,r5
    c.r[1] = c.r[3];  // 060480E8 mov r3,r1
    c.r[1] += 1;  // 060480EA add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060480EC mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060480EE mov.b @r3,r1
    c.r[5] <<= 8;  // 060480F0 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 060480F2 extu.b r1,r6
    c.r[1] = c.r[11];  // 060480F4 mov r11,r1
    c.r[1] += 6;  // 060480F6 add #6,r1
    c.r[5] += c.r[6];  // 060480F8 add r6,r5
    st16(c.r[1], c.r[5]);  // 060480FA mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 060480FC mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060480FE mov r3,r1
    c.r[1] += 1;  // 06048100 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048102 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048104 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048106 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 06048108 extu.b r1,r5
    c.r[1] = c.r[3];  // 0604810A mov r3,r1
    c.r[1] += 1;  // 0604810C add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604810E mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048110 mov.b @r3,r1
    c.r[5] <<= 8;  // 06048112 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048114 extu.b r1,r6
    c.r[1] = c.r[11];  // 06048116 mov r11,r1
    c.r[1] += 10;  // 06048118 add #10,r1
    c.r[5] += c.r[6];  // 0604811A add r6,r5
    st16(c.r[1], c.r[5]); goto L_06048144;  // 0604811C bra 0x06048144 ; mov.w r5,@r1
L_06048144:
    c.r[3] = ld32(c.r[2] + 28);  // 06048144 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06048146 mov r3,r1
    c.r[1] += 1;  // 06048148 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604814A mov.l r1,@(28,r2)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604814C mov.b @r3,r7
    c.r[3] = ld32(c.r[2] + 28);  // 0604814E mov.l @(28,r2),r3
    c.r[7] = c.r[7] & 0xFFu;  // 06048150 extu.b r7,r7
    c.r[1] = c.r[3];  // 06048152 mov r3,r1
    c.r[1] += 1;  // 06048154 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048156 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048158 mov.b @r3,r1
    c.r[7] <<= 8;  // 0604815A shll8 r7
    c.r[6] = c.r[1] & 0xFFu;  // 0604815C extu.b r1,r6
    c.r[3] = ld32(0x060484C4u);  // 0604815E mov.l 0x060484C4,r3
    c.r[1] = c.r[3];  // 06048160 mov r3,r1
    c.r[1] += 4;  // 06048162 add #4,r1
    c.r[7] += c.r[6];  // 06048164 add r6,r7
    st16(c.r[1], c.r[7]);  // 06048166 mov.w r7,@r1
    c.r[3] += 2;  // 06048168 add #2,r3
    st16(c.r[3], c.r[7]);  // 0604816A mov.w r7,@r3
    c.r[3] = ld32(c.r[2] + 28);  // 0604816C mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 0604816E mov r3,r1
    c.r[1] += 1;  // 06048170 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048172 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048174 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048176 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 06048178 extu.b r1,r5
    c.r[1] = c.r[3];  // 0604817A mov r3,r1
    c.r[1] += 1;  // 0604817C add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604817E mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048180 mov.b @r3,r1
    c.r[5] <<= 8;  // 06048182 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048184 extu.b r1,r6
    c.r[1] = c.r[11];  // 06048186 mov r11,r1
    c.r[1] += 14;  // 06048188 add #14,r1
    c.r[5] += c.r[6];  // 0604818A add r6,r5
    st16(c.r[1], c.r[5]);  // 0604818C mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 0604818E mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06048190 mov r3,r1
    c.r[1] += 1;  // 06048192 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048194 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048196 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048198 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 0604819A extu.b r1,r5
    c.r[1] = c.r[3];  // 0604819C mov r3,r1
    c.r[1] += 1;  // 0604819E add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060481A0 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060481A2 mov.b @r3,r1
    c.r[5] <<= 8;  // 060481A4 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 060481A6 extu.b r1,r6
    c.r[1] = c.r[11];  // 060481A8 mov r11,r1
    c.r[1] += 16;  // 060481AA add #16,r1
    c.r[5] += c.r[6];  // 060481AC add r6,r5
    st16(c.r[1], c.r[5]);  // 060481AE mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 060481B0 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060481B2 mov r3,r1
    c.r[1] += 1;  // 060481B4 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060481B6 mov.l r1,@(28,r2)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060481B8 mov.b @r3,r7
    c.r[3] = ld32(c.r[2] + 28);  // 060481BA mov.l @(28,r2),r3
    c.r[7] = c.r[7] & 0xFFu;  // 060481BC extu.b r7,r7
    c.r[1] = c.r[3];  // 060481BE mov r3,r1
    c.r[1] += 1;  // 060481C0 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060481C2 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060481C4 mov.b @r3,r1
    c.r[7] <<= 8;  // 060481C6 shll8 r7
    c.r[6] = c.r[1] & 0xFFu;  // 060481C8 extu.b r1,r6
    c.r[1] = c.r[11];  // 060481CA mov r11,r1
    c.r[1] += 24;  // 060481CC add #24,r1
    c.r[7] += c.r[6];  // 060481CE add r6,r7
    st16(c.r[1], c.r[7]);  // 060481D0 mov.w r7,@r1
    c.r[1] = c.r[11];  // 060481D2 mov r11,r1
    c.r[1] += 22;  // 060481D4 add #22,r1
    st16(c.r[1], c.r[7]);  // 060481D6 mov.w r7,@r1
    c.r[1] = ld32(c.r[2] + 28);  // 060481D8 mov.l @(28,r2),r1
    c.r[1] += 1;  // 060481DA add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060481DC mov.l r1,@(28,r2)
    c.r[3] = ld32(c.r[2] + 28);  // 060481DE mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060481E0 mov r3,r1
    c.r[1] += 1;  // 060481E2 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060481E4 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060481E6 mov.b @r3,r1
    c.r[6] = c.r[1] & 0xFFu;  // 060481E8 extu.b r1,r6
    c.r[1] = c.r[11];  // 060481EA mov r11,r1
    c.r[1] += 27;  // 060481EC add #27,r1
    st8(c.r[1], c.r[6]);  // 060481EE mov.b r6,@r1
    c.r[1] = c.r[11];  // 060481F0 mov r11,r1
    c.r[1] += 26;  // 060481F2 add #26,r1
    st8(c.r[1], c.r[6]);  // 060481F4 mov.b r6,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 060481F6 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060481F8 mov r3,r1
    c.r[1] += 1;  // 060481FA add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060481FC mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060481FE mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048200 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 06048202 extu.b r1,r5
    c.r[1] = c.r[3];  // 06048204 mov r3,r1
    c.r[1] += 1;  // 06048206 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048208 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604820A mov.b @r3,r1
    c.r[5] <<= 8;  // 0604820C shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 0604820E extu.b r1,r6
    c.r[1] = c.r[11];  // 06048210 mov r11,r1
    c.r[1] += 18;  // 06048212 add #18,r1
    c.r[5] += c.r[6];  // 06048214 add r6,r5
    st16(c.r[1], c.r[5]);  // 06048216 mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048218 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 0604821A mov r3,r1
    c.r[1] += 1;  // 0604821C add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604821E mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048220 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048222 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 06048224 extu.b r1,r5
    c.r[1] = c.r[3];  // 06048226 mov r3,r1
    c.r[1] += 1;  // 06048228 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604822A mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604822C mov.b @r3,r1
    c.r[5] <<= 8;  // 0604822E shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048230 extu.b r1,r6
    c.r[1] = c.r[11];  // 06048232 mov r11,r1
    c.r[1] += 20;  // 06048234 add #20,r1
    c.r[5] += c.r[6];  // 06048236 add r6,r5
    st16(c.r[1], c.r[5]);  // 06048238 mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 0604823A mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 0604823C mov r3,r1
    c.r[1] += 1;  // 0604823E add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048240 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048242 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048244 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 06048246 extu.b r1,r5
    c.r[1] = c.r[3];  // 06048248 mov r3,r1
    c.r[1] += 1;  // 0604824A add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604824C mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604824E mov.b @r3,r1
    c.r[5] <<= 8;  // 06048250 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048252 extu.b r1,r6
    c.r[1] = c.r[12];  // 06048254 mov r12,r1
    c.r[1] += 6;  // 06048256 add #6,r1
    c.r[5] += c.r[6];  // 06048258 add r6,r5
    st16(c.r[1], c.r[5]);  // 0604825A mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 0604825C mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 0604825E mov r3,r1
    c.r[1] += 1;  // 06048260 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048262 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048264 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048266 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 06048268 extu.b r1,r5
    c.r[1] = c.r[3];  // 0604826A mov r3,r1
    c.r[1] += 1;  // 0604826C add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604826E mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048270 mov.b @r3,r1
    c.r[5] <<= 8;  // 06048272 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048274 extu.b r1,r6
    c.r[1] = c.r[12];  // 06048276 mov r12,r1
    c.r[1] += 10;  // 06048278 add #10,r1
    c.r[5] += c.r[6];  // 0604827A add r6,r5
    st16(c.r[1], c.r[5]);  // 0604827C mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 0604827E mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06048280 mov r3,r1
    c.r[1] += 1;  // 06048282 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048284 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048286 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048288 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 0604828A extu.b r1,r5
    c.r[1] = c.r[3];  // 0604828C mov r3,r1
    c.r[1] += 1;  // 0604828E add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048290 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048292 mov.b @r3,r1
    c.r[5] <<= 8;  // 06048294 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048296 extu.b r1,r6
    c.r[1] = c.r[12];  // 06048298 mov r12,r1
    c.r[1] += 14;  // 0604829A add #14,r1
    c.r[5] += c.r[6];  // 0604829C add r6,r5
    st16(c.r[1], c.r[5]);  // 0604829E mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 060482A0 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060482A2 mov r3,r1
    c.r[1] += 1;  // 060482A4 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060482A6 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060482A8 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 060482AA mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 060482AC extu.b r1,r5
    c.r[1] = c.r[3];  // 060482AE mov r3,r1
    c.r[1] += 1;  // 060482B0 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060482B2 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060482B4 mov.b @r3,r1
    c.r[5] <<= 8;  // 060482B6 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 060482B8 extu.b r1,r6
    c.r[1] = c.r[12];  // 060482BA mov r12,r1
    c.r[1] += 16;  // 060482BC add #16,r1
    c.r[5] += c.r[6];  // 060482BE add r6,r5
    st16(c.r[1], c.r[5]);  // 060482C0 mov.w r5,@r1
    c.r[1] = ld32(c.r[2] + 28);  // 060482C2 mov.l @(28,r2),r1
    c.r[1] += 1;  // 060482C4 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060482C6 mov.l r1,@(28,r2)
    c.r[3] = ld32(c.r[2] + 28);  // 060482C8 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060482CA mov r3,r1
    c.r[1] += 1;  // 060482CC add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060482CE mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060482D0 mov.b @r3,r1
    c.r[6] = c.r[1] & 0xFFu;  // 060482D2 extu.b r1,r6
    c.r[1] = c.r[12];  // 060482D4 mov r12,r1
    c.r[1] += 24;  // 060482D6 add #24,r1
    st16(c.r[1], c.r[13]);  // 060482D8 mov.w r13,@r1
    c.r[1] = c.r[12];  // 060482DA mov r12,r1
    c.r[1] += 22;  // 060482DC add #22,r1
    st16(c.r[1], c.r[13]);  // 060482DE mov.w r13,@r1
    c.r[1] = c.r[12];  // 060482E0 mov r12,r1
    c.r[1] += 27;  // 060482E2 add #27,r1
    st8(c.r[1], c.r[6]);  // 060482E4 mov.b r6,@r1
    c.r[1] = c.r[12];  // 060482E6 mov r12,r1
    c.r[1] += 26;  // 060482E8 add #26,r1
    st8(c.r[1], c.r[6]);  // 060482EA mov.b r6,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 060482EC mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 060482EE mov r3,r1
    c.r[1] += 1;  // 060482F0 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060482F2 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060482F4 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 060482F6 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 060482F8 extu.b r1,r5
    c.r[1] = c.r[3];  // 060482FA mov r3,r1
    c.r[1] += 1;  // 060482FC add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060482FE mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048300 mov.b @r3,r1
    c.r[5] <<= 8;  // 06048302 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048304 extu.b r1,r6
    c.r[1] = c.r[12];  // 06048306 mov r12,r1
    c.r[1] += 18;  // 06048308 add #18,r1
    c.r[5] += c.r[6];  // 0604830A add r6,r5
    st16(c.r[1], c.r[5]);  // 0604830C mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 0604830E mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06048310 mov r3,r1
    c.r[1] += 1;  // 06048312 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048314 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048316 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048318 mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 0604831A extu.b r1,r5
    c.r[1] = c.r[3];  // 0604831C mov r3,r1
    c.r[1] += 1;  // 0604831E add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048320 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048322 mov.b @r3,r1
    c.r[5] <<= 8;  // 06048324 shll8 r5
    c.r[6] = c.r[1] & 0xFFu;  // 06048326 extu.b r1,r6
    c.r[1] = c.r[12];  // 06048328 mov r12,r1
    c.r[1] += 20;  // 0604832A add #20,r1
    c.r[5] += c.r[6];  // 0604832C add r6,r5
    st16(c.r[1], c.r[5]);  // 0604832E mov.w r5,@r1
    c.r[3] = ld32(c.r[2] + 28);  // 06048330 mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06048332 mov r3,r1
    c.r[1] += 1;  // 06048334 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048336 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048338 mov.b @r3,r1
    c.r[3] = ld32(c.r[2] + 28);  // 0604833A mov.l @(28,r2),r3
    c.r[5] = c.r[1] & 0xFFu;  // 0604833C extu.b r1,r5
    c.r[1] = c.r[3];  // 0604833E mov r3,r1
    c.r[1] += 1;  // 06048340 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048342 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048344 mov.b @r3,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06048346 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06048348 mov.b @r2,r1
    c.r[0] = 0x1u;  // 0604834A mov #1,r0
    c.r[1] >>= 2;  // 0604834C shlr2 r1
    c.r[1] >>= 2;  // 0604834E shlr2 r1
    c.r[1] &= c.r[0];  // 06048350 and r0,r1
    c.r[0] = c.r[1];  // 06048352 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06048354 cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = c.r[11]; if (k) { goto L_060483F2; } }  // 06048356 bf/s 0x060483F2 ; mov r11,r9
    c.r[9] += 2;  // 0604835A add #2,r9
    c.r[8] = c.r[5];  // 0604835C mov r5,r8
    c.r[8] <<= 8;  // 0604835E shll8 r8
    c.r[8] += c.r[6];  // 06048360 add r6,r8
    st16(c.r[9], c.r[8]);  // 06048362 mov.w r8,@r9
    c.r[10] = c.r[12];  // 06048364 mov r12,r10
    c.r[10] += 2;  // 06048366 add #2,r10
    st16(c.r[10], c.r[8]);  // 06048368 mov.w r8,@r10
    c.r[8] = c.r[8] & 0xFFFFu;  // 0604836A extu.w r8,r8
    c.r[4] = ld32(0x060484C8u);  // 0604836C mov.l 0x060484C8,r4
    c.r[0] = ld32(0x060484CCu);  // 0604836E mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048374u; c.r[5] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048374u) return; }  // 06048370 jsr @r0 ; mov #29,r5
    c.r[1] = c.r[0];  // 06048374 mov r0,r1
    c.r[5] = c.r[8];  // 06048376 mov r8,r5
    c.r[0] = ld32(0x060484CCu);  // 06048378 mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604837Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604837Eu) return; }  // 0604837A jsr @r0 ; mov r1,r4
    c.r[13] = c.r[0];  // 0604837E mov r0,r13
    c.r[5] = 0x1Du;  // 06048380 mov #29,r5
    c.r[4] = ld32(0x060484C8u);  // 06048382 mov.l 0x060484C8,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06048384 mov.w @r9,r8
    c.r[0] = ld32(0x060484CCu);  // 06048386 mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604838Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604838Cu) return; }  // 06048388 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0604838C mov r0,r1
    c.r[5] = c.r[8];  // 0604838E mov r8,r5
    c.r[0] = ld32(0x060484CCu);  // 06048390 mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048396u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048396u) return; }  // 06048392 jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 06048396 mov r0,r1
    c.r[11] += 4;  // 06048398 add #4,r11
    c.r[13] += 3;  // 0604839A add #3,r13
    c.r[1] += 4;  // 0604839C add #4,r1
    c.r[5] = 0x1Du;  // 0604839E mov #29,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060483A0 mov.b @r13,r2
    c.r[4] = ld32(0x060484C8u);  // 060483A2 mov.l 0x060484C8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060483A4 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060483A6 extu.b r2,r2
    c.r[2] <<= 8;  // 060483A8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060483AA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060483AC or r1,r2
    st16(c.r[11], c.r[2]);  // 060483AE mov.w r2,@r11
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060483B0 mov.w @r10,r8
    c.r[0] = ld32(0x060484CCu);  // 060483B2 mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060483B8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060483B8u) return; }  // 060483B4 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060483B8 mov r0,r1
    c.r[5] = c.r[8];  // 060483BA mov r8,r5
    c.r[0] = ld32(0x060484CCu);  // 060483BC mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060483C2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060483C2u) return; }  // 060483BE jsr @r0 ; mov r1,r4
    c.r[9] = c.r[0];  // 060483C2 mov r0,r9
    c.r[5] = 0x1Du;  // 060483C4 mov #29,r5
    c.r[4] = ld32(0x060484C8u);  // 060483C6 mov.l 0x060484C8,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060483C8 mov.w @r10,r8
    c.r[0] = ld32(0x060484CCu);  // 060483CA mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060483D0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060483D0u) return; }  // 060483CC jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060483D0 mov r0,r1
    c.r[5] = c.r[8];  // 060483D2 mov r8,r5
    c.r[0] = ld32(0x060484CCu);  // 060483D4 mov.l 0x060484CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060483DAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060483DAu) return; }  // 060483D6 jsr @r0 ; mov r1,r4
    c.r[1] = c.r[0];  // 060483DA mov r0,r1
    c.r[12] += 4;  // 060483DC add #4,r12
    c.r[9] += 3;  // 060483DE add #3,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060483E0 mov.b @r9,r2
    c.r[1] += 4;  // 060483E2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060483E4 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060483E6 extu.b r2,r2
    c.r[2] <<= 8;  // 060483E8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060483EA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060483EC or r1,r2
    st16(c.r[12], c.r[2]); goto L_0604840C;  // 060483EE bra 0x0604840C ; mov.w r2,@r12
L_060483F2:
    c.r[1] = c.r[11];  // 060483F2 mov r11,r1
    c.r[1] += 2;  // 060483F4 add #2,r1
    st16(c.r[1], c.r[13]);  // 060483F6 mov.w r13,@r1
    c.r[1] = c.r[12];  // 060483F8 mov r12,r1
    c.r[1] += 2;  // 060483FA add #2,r1
    st16(c.r[1], c.r[13]);  // 060483FC mov.w r13,@r1
    c.r[11] += 4;  // 060483FE add #4,r11
    c.r[1] = c.r[5];  // 06048400 mov r5,r1
    c.r[1] <<= 8;  // 06048402 shll8 r1
    c.r[1] += c.r[6];  // 06048404 add r6,r1
    st16(c.r[11], c.r[1]);  // 06048406 mov.w r1,@r11
    c.r[12] += 4;  // 06048408 add #4,r12
    st16(c.r[12], c.r[1]);  // 0604840A mov.w r1,@r12
L_0604840C:
    c.r[2] = ld32(0x060484D0u);  // 0604840C mov.l 0x060484D0,r2
    c.r[3] = ld32(c.r[2] + 28);  // 0604840E mov.l @(28,r2),r3
    c.r[1] = c.r[3];  // 06048410 mov r3,r1
    c.r[1] += 1;  // 06048412 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048414 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048416 mov.b @r3,r1
    c.r[0] = 0x2u;  // 06048418 mov #2,r0
    c.r[7] = c.r[1] & 0xFFu;  // 0604841A extu.b r1,r7
    c.r[3] = ld32(c.r[2] + 28);  // 0604841C mov.l @(28,r2),r3
    c.r[7] <<= 8;  // 0604841E shll8 r7
    c.r[1] = c.r[3];  // 06048420 mov r3,r1
    c.r[1] += 1;  // 06048422 add #1,r1
    st32(c.r[2] + 28, c.r[1]);  // 06048424 mov.l r1,@(28,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048426 mov.b @r3,r1
    c.r[2] = 0x0u;  // 06048428 mov #0,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0604842A extu.b r1,r6
    c.r[7] |= c.r[6];  // 0604842C or r6,r7
    c.r[1] = ld32(0x060484D4u);  // 0604842E mov.l 0x060484D4,r1
    st8(c.r[1], c.r[2]);  // 06048430 mov.b r2,@r1
    c.r[1] = ld32(0x060484D8u);  // 06048432 mov.l 0x060484D8,r1
    st8(c.r[1], c.r[2]);  // 06048434 mov.b r2,@r1
    c.r[3] = ld32(0x060484C4u);  // 06048436 mov.l 0x060484C4,r3
    c.r[2] = c.r[7];  // 06048438 mov r7,r2
    c.r[2] >>= 8;  // 0604843A shlr8 r2
    c.r[2] >>= 2;  // 0604843C shlr2 r2
    c.r[2] >>= 2;  // 0604843E shlr2 r2
    c.r[2] &= c.r[0];  // 06048440 and r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048442 mov.b @r3,r1
    c.r[0] = 0x7Du;  // 06048444 mov #125,r0
    c.r[1] &= c.r[0];  // 06048446 and r0,r1
    c.r[1] |= c.r[2];  // 06048448 or r2,r1
    c.r[2] = c.r[7];  // 0604844A mov r7,r2
    c.r[2] >>= 2;  // 0604844C shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0604844E shlr r2
    c.r[2] >>= 2;  // 06048450 shlr2 r2
    c.r[0] = 0x10u;  // 06048452 mov #16,r0
    c.r[2] &= c.r[0];  // 06048454 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060484BAu);  // 06048456 mov.w 0x060484BA,r0
    c.r[1] &= c.r[0];  // 06048458 and r0,r1
    c.r[1] |= c.r[2];  // 0604845A or r2,r1
    c.r[2] = c.r[7];  // 0604845C mov r7,r2
    c.r[2] >>= 2;  // 0604845E shlr2 r2
    c.r[0] = 0x40u;  // 06048460 mov #64,r0
    c.r[2] &= c.r[0];  // 06048462 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060484BCu);  // 06048464 mov.w 0x060484BC,r0
    c.r[1] &= c.r[0];  // 06048466 and r0,r1
    c.r[1] |= c.r[2];  // 06048468 or r2,r1
    c.r[2] = c.r[7];  // 0604846A mov r7,r2
    c.r[2] >>= 2;  // 0604846C shlr2 r2
    c.r[0] = 0x20u;  // 0604846E mov #32,r0
    c.r[2] &= c.r[0];  // 06048470 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060484BEu);  // 06048472 mov.w 0x060484BE,r0
    c.r[1] &= c.r[0];  // 06048474 and r0,r1
    c.r[1] |= c.r[2];  // 06048476 or r2,r1
    st8(c.r[3], c.r[1]);  // 06048478 mov.b r1,@r3
    c.r[1] = 0x20u;  // 0604847A mov #32,r1
    c.r[1] &= c.r[7];  // 0604847C and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604847E tst r1,r1
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_06048492; } }  // 06048480 bt/s 0x06048492 ; mov #64,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06048484 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060484C0u);  // 06048486 mov.w 0x060484C0,r1
    c.r[0] = c.r[2];  // 06048488 mov r2,r0
    c.r[0] &= c.r[1];  // 0604848A and r1,r0
    c.r[0] |= 0x80u;  // 0604848C or #128,r0
    st16(c.r[3], c.r[0]); goto L_060484A6;  // 0604848E bra 0x060484A6 ; mov.w r0,@r3
L_06048492:
    c.r[1] &= c.r[7];  // 06048492 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048494 tst r1,r1
    { const bool k = c.t; c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { goto L_060484A0; } }  // 06048496 bt/s 0x060484A0 ; mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060484C2u);  // 0604849A mov.w 0x060484C2,r2
    c.r[1] |= c.r[2]; goto L_060484A4;  // 0604849C bra 0x060484A4 ; or r2,r1
L_060484A0:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060484C0u);  // 060484A0 mov.w 0x060484C0,r2
    c.r[1] &= c.r[2];  // 060484A2 and r2,r1
L_060484A4:
    st16(c.r[3], c.r[1]);  // 060484A4 mov.w r1,@r3
L_060484A6:
    c.r[1] = 0x10u;  // 060484A6 mov #16,r1
    c.r[1] &= c.r[7];  // 060484A8 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060484AA tst r1,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_060484DC; } }  // 060484AC bt/s 0x060484DC ; mov #8,r1
    c.r[1] = ld32(0x060484C4u);  // 060484B0 mov.l 0x060484C4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060484B2 mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 060484B4 and #243,r0
    c.r[0] |= 0x4u; goto L_060484F0;  // 060484B6 bra 0x060484F0 ; or #4,r0
L_060484DC:
    c.r[1] &= c.r[7];  // 060484DC and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060484DE tst r1,r1
    if (c.t) { goto L_060484EA; }  // 060484E0 bt 0x060484EA
    c.r[1] = ld32(0x06048570u);  // 060484E2 mov.l 0x06048570,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060484E4 mov.b @r1,r0
    c.r[0] |= 0xCu; goto L_060484F0;  // 060484E6 bra 0x060484F0 ; or #12,r0
L_060484EA:
    c.r[1] = ld32(0x06048570u);  // 060484EA mov.l 0x06048570,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060484EC mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 060484EE and #243,r0
L_060484F0:
    st8(c.r[1], c.r[0]);  // 060484F0 mov.b r0,@r1
    c.r[2] = 0x3u;  // 060484F2 mov #3,r2
    c.r[2] &= c.r[7];  // 060484F4 and r7,r2
    c.r[1] = ld32(0x06048574u);  // 060484F6 mov.l 0x06048574,r1
    c.r[2] <<= 2;  // 060484F8 shll2 r2
    c.r[2] <<= 2;  // 060484FA shll2 r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060484FC mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604856Au);  // 060484FE mov.w 0x0604856A,r0
    c.r[5] = c.r[7];  // 06048500 mov r7,r5
    c.r[5] >>= 8;  // 06048502 shlr8 r5
    c.r[5] >>= 2;  // 06048504 shlr2 r5
    c.r[3] &= c.r[0];  // 06048506 and r0,r3
    c.r[3] |= c.r[2];  // 06048508 or r2,r3
    c.r[0] = 0x7u;  // 0604850A mov #7,r0
    c.r[5] &= c.r[0];  // 0604850C and r0,r5
    c.r[2] = c.r[5] & 0xFFFFu;  // 0604850E extu.w r5,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06048510 tst r2,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { goto L_06048536; } }  // 06048512 bf/s 0x06048536 ; mov.b r3,@r1
    c.r[3] = ld32(0x06048578u);  // 06048516 mov.l 0x06048578,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604856Cu);  // 06048518 mov.w 0x0604856C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604851A mov.b @r3,r0
    c.r[2] = ld32(0x0604857Cu);  // 0604851C mov.l 0x0604857C,r2
    c.r[1] &= c.r[0];  // 0604851E and r0,r1
    st8(c.r[3], c.r[1]);  // 06048520 mov.b r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604856Cu);  // 06048522 mov.w 0x0604856C,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06048524 mov.b @r2,r7
    c.r[0] &= 0xE0u;  // 06048526 and #224,r0
    c.r[1] &= c.r[7];  // 06048528 and r7,r1
    st8(c.r[2], c.r[1]);  // 0604852A mov.b r1,@r2
    st8(c.r[3], c.r[0]);  // 0604852C mov.b r0,@r3
    c.r[0] = c.r[7];  // 0604852E mov r7,r0
    c.r[0] &= 0xE0u;  // 06048530 and #224,r0
    st8(c.r[2], c.r[0]); goto L_060485A6;  // 06048532 bra 0x060485A6 ; mov.b r0,@r2
L_06048536:
    c.r[1] = 0x4u;  // 06048536 mov #4,r1
    c.t = c.r[2] > c.r[1];  // 06048538 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06048580; } }  // 0604853A bf/s 0x06048580 ; mov #3,r0
    c.r[3] = ld32(0x06048578u);  // 0604853E mov.l 0x06048578,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604856Cu);  // 06048540 mov.w 0x0604856C,r1
    c.r[2] = ld32(0x0604857Cu);  // 06048542 mov.l 0x0604857C,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048544 mov.b @r3,r6
    c.r[1] &= c.r[6];  // 06048546 and r6,r1
    st8(c.r[3], c.r[1]);  // 06048548 mov.b r1,@r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604854A mov.b @r2,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604856Cu);  // 0604854C mov.w 0x0604856C,r1
    c.r[1] &= c.r[7];  // 0604854E and r7,r1
    st8(c.r[2], c.r[1]);  // 06048550 mov.b r1,@r2
    c.r[1] = c.r[5];  // 06048552 mov r5,r1
    c.r[1] -= 4;  // 06048554 add #-4,r1
    c.r[1] &= c.r[0];  // 06048556 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604856Eu);  // 06048558 mov.w 0x0604856E,r0
    c.r[6] &= c.r[0];  // 0604855A and r0,r6
    c.r[6] |= c.r[1];  // 0604855C or r1,r6
    st8(c.r[3], c.r[6]);  // 0604855E mov.b r6,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604856Eu);  // 06048560 mov.w 0x0604856E,r3
    c.r[3] &= c.r[7];  // 06048562 and r7,r3
    c.r[3] |= c.r[1];  // 06048564 or r1,r3
    st8(c.r[2], c.r[3]); goto L_060485A6;  // 06048566 bra 0x060485A6 ; mov.b r3,@r2
L_06048580:
    c.r[1] = ld32(0x06048764u);  // 06048580 mov.l 0x06048764,r1
    c.r[3] = c.r[5];  // 06048582 mov r5,r3
    c.r[3] <<= 2;  // 06048584 shll2 r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048586 mov.b @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06048758u);  // 06048588 mov.w 0x06048758,r7
    c.r[7] &= c.r[2];  // 0604858A and r2,r7
    c.r[7] |= c.r[3];  // 0604858C or r3,r7
    st8(c.r[1], c.r[7]);  // 0604858E mov.b r7,@r1
    c.r[2] = ld32(0x06048768u);  // 06048590 mov.l 0x06048768,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06048592 mov.b @r2,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048758u);  // 06048594 mov.w 0x06048758,r0
    c.r[6] &= c.r[0];  // 06048596 and r0,r6
    c.r[6] |= c.r[3];  // 06048598 or r3,r6
    st8(c.r[2], c.r[6]);  // 0604859A mov.b r6,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604875Au);  // 0604859C mov.w 0x0604875A,r0
    c.r[7] &= c.r[0];  // 0604859E and r0,r7
    st8(c.r[1], c.r[7]);  // 060485A0 mov.b r7,@r1
    c.r[6] &= c.r[0];  // 060485A2 and r0,r6
    st8(c.r[2], c.r[6]);  // 060485A4 mov.b r6,@r2
L_060485A6:
    c.r[11] = ld32(0x06048764u);  // 060485A6 mov.l 0x06048764,r11
    c.r[0] = ld32(0x0604876Cu);  // 060485A8 mov.l 0x0604876C,r0
    c.r[12] = ld32(0x06048770u);  // 060485AA mov.l 0x06048770,r12
    c.r[9] = ld32(0x06048774u);  // 060485AC mov.l 0x06048774,r9
    c.r[5] = 0x1Bu;  // 060485AE mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0]);  // 060485B0 mov.w @r0,r8
    c.r[4] = c.r[12];  // 060485B2 mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060485B8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060485B8u) return; }  // 060485B4 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060485B8 mov r0,r1
    c.r[5] = c.r[8];  // 060485BA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060485C0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060485C0u) return; }  // 060485BC jsr @r9 ; mov r1,r4
    c.r[10] = c.r[0];  // 060485C0 mov r0,r10
    c.r[0] = ld32(0x0604876Cu);  // 060485C2 mov.l 0x0604876C,r0
    c.r[5] = 0x1Bu;  // 060485C4 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0]);  // 060485C6 mov.w @r0,r8
    c.r[4] = c.r[12];  // 060485C8 mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060485CEu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060485CEu) return; }  // 060485CA jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060485CE mov r0,r1
    c.r[5] = c.r[8];  // 060485D0 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060485D6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060485D6u) return; }  // 060485D2 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060485D6 mov r0,r1
    c.r[3] = c.r[11];  // 060485D8 mov r11,r3
    c.r[3] += 12;  // 060485DA add #12,r3
    c.r[10] += 2;  // 060485DC add #2,r10
    c.r[1] += 3;  // 060485DE add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060485E0 mov.b @r10,r2
    c.r[5] = 0x1Bu;  // 060485E2 mov #27,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060485E4 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060485E6 extu.b r2,r2
    c.r[2] <<= 8;  // 060485E8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060485EA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060485EC or r1,r2
    st16(c.r[3], c.r[2]);  // 060485EE mov.w r2,@r3
    c.r[10] = ld32(0x06048768u);  // 060485F0 mov.l 0x06048768,r10
    c.r[13] = c.r[10];  // 060485F2 mov r10,r13
    c.r[13] += 10;  // 060485F4 add #10,r13
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[13]);  // 060485F6 mov.w @r13,r8
    c.r[4] = c.r[12];  // 060485F8 mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060485FEu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060485FEu) return; }  // 060485FA jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060485FE mov r0,r1
    c.r[5] = c.r[8];  // 06048600 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06048606u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048606u) return; }  // 06048602 jsr @r9 ; mov r1,r4
    st32(c.r[14] + 8, c.r[0]);  // 06048606 mov.l r0,@(8,r14)
    c.r[5] = 0x1Bu;  // 06048608 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0604860A mov.w @r13,r8
    c.r[4] = c.r[12];  // 0604860C mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06048612u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048612u) return; }  // 0604860E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06048612 mov r0,r1
    c.r[5] = c.r[8];  // 06048614 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604861Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604861Au) return; }  // 06048616 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0604861A mov r0,r1
    c.r[3] = c.r[10];  // 0604861C mov r10,r3
    c.r[3] += 12;  // 0604861E add #12,r3
    c.r[0] = ld32(c.r[14] + 8);  // 06048620 mov.l @(8,r14),r0
    c.r[1] += 3;  // 06048622 add #3,r1
    c.r[0] += 2;  // 06048624 add #2,r0
    st32(c.r[14] + 8, c.r[0]);  // 06048626 mov.l r0,@(8,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06048628 mov.b @r0,r2
    c.r[5] = 0x1Bu;  // 0604862A mov #27,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604862C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604862E extu.b r2,r2
    c.r[2] <<= 8;  // 06048630 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06048632 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06048634 or r1,r2
    st16(c.r[3], c.r[2]);  // 06048636 mov.w r2,@r3
    c.r[1] = c.r[11];  // 06048638 mov r11,r1
    c.r[1] += 8;  // 0604863A add #8,r1
    c.r[2] = 0x0u;  // 0604863C mov #0,r2
    st16(c.r[1], c.r[2]);  // 0604863E mov.w r2,@r1
    c.r[1] = c.r[10];  // 06048640 mov r10,r1
    c.r[1] += 8;  // 06048642 add #8,r1
    st16(c.r[1], c.r[2]);  // 06048644 mov.w r2,@r1
    c.r[0] = ld32(0x0604876Cu);  // 06048646 mov.l 0x0604876C,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06048648 mov.w @r0,r8
    c.r[4] = c.r[12];  // 0604864A mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06048650u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048650u) return; }  // 0604864C jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06048650 mov r0,r1
    c.r[5] = c.r[8];  // 06048652 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06048658u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048658u) return; }  // 06048654 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06048658 mov r0,r1
    c.r[1] += 6;  // 0604865A add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604875Cu);  // 0604865C mov.w 0x0604875C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604865E mov.b @r1,r1
    c.r[5] = 0x1Bu;  // 06048660 mov #27,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06048662 mov.b @r11,r2
    c.r[1] &= c.r[0];  // 06048664 and r0,r1
    c.r[0] = 0x1Fu;  // 06048666 mov #31,r0
    c.r[2] &= c.r[0];  // 06048668 and r0,r2
    c.r[2] |= c.r[1];  // 0604866A or r1,r2
    st8(c.r[11], c.r[2]);  // 0604866C mov.b r2,@r11
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0604866E mov.w @r13,r8
    c.r[4] = c.r[12];  // 06048670 mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06048676u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048676u) return; }  // 06048672 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06048676 mov r0,r1
    c.r[5] = c.r[8];  // 06048678 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604867Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604867Eu) return; }  // 0604867A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0604867E mov r0,r1
    c.r[1] += 6;  // 06048680 add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604875Cu);  // 06048682 mov.w 0x0604875C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048684 mov.b @r1,r1
    c.r[5] = 0x1Bu;  // 06048686 mov #27,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06048688 mov.b @r10,r2
    c.r[1] &= c.r[0];  // 0604868A and r0,r1
    c.r[0] = 0x1Fu;  // 0604868C mov #31,r0
    c.r[2] &= c.r[0];  // 0604868E and r0,r2
    c.r[2] |= c.r[1];  // 06048690 or r1,r2
    st8(c.r[10], c.r[2]);  // 06048692 mov.b r2,@r10
    c.r[0] = ld32(0x0604876Cu);  // 06048694 mov.l 0x0604876C,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06048696 mov.w @r0,r8
    c.r[4] = c.r[12];  // 06048698 mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604869Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604869Eu) return; }  // 0604869A jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0604869E mov r0,r1
    c.r[5] = c.r[8];  // 060486A0 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060486A6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060486A6u) return; }  // 060486A2 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060486A6 mov r0,r1
    c.r[1] += 10;  // 060486A8 add #10,r1
    c.r[11] += 1;  // 060486AA add #1,r11
    c.r[2] = 0x3u;  // 060486AC mov #3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604875Eu);  // 060486AE mov.w 0x0604875E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060486B0 mov.b @r1,r1
    c.r[5] = 0x1Bu;  // 060486B2 mov #27,r5
    c.r[2] &= c.r[1];  // 060486B4 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060486B6 mov.b @r11,r1
    c.r[2] <<= 2;  // 060486B8 shll2 r2
    c.r[2] += c.r[2];  // 060486BA add r2,r2
    c.r[2] <<= 2;  // 060486BC shll2 r2
    c.r[1] &= c.r[0];  // 060486BE and r0,r1
    c.r[1] |= c.r[2];  // 060486C0 or r2,r1
    st8(c.r[11], c.r[1]);  // 060486C2 mov.b r1,@r11
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[13]);  // 060486C4 mov.w @r13,r8
    c.r[4] = c.r[12];  // 060486C6 mov r12,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060486CCu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060486CCu) return; }  // 060486C8 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060486CC mov r0,r1
    c.r[5] = c.r[8];  // 060486CE mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060486D4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060486D4u) return; }  // 060486D0 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060486D4 mov r0,r1
    c.r[1] += 10;  // 060486D6 add #10,r1
    c.r[10] += 1;  // 060486D8 add #1,r10
    c.r[2] = 0x3u;  // 060486DA mov #3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604875Eu);  // 060486DC mov.w 0x0604875E,r0
    c.r[8] = 0x0u;  // 060486DE mov #0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060486E0 mov.b @r1,r1
    c.r[9] = 0xFu;  // 060486E2 mov #15,r9
    c.r[2] &= c.r[1];  // 060486E4 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060486E6 mov.b @r10,r1
    c.r[2] <<= 2;  // 060486E8 shll2 r2
    c.r[2] += c.r[2];  // 060486EA add r2,r2
    c.r[2] <<= 2;  // 060486EC shll2 r2
    c.r[1] &= c.r[0];  // 060486EE and r0,r1
    c.r[1] |= c.r[2];  // 060486F0 or r2,r1
    st8(c.r[10], c.r[1]);  // 060486F2 mov.b r1,@r10
    c.r[1] = ld32(0x06048778u);  // 060486F4 mov.l 0x06048778,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048760u);  // 060486F6 mov.w 0x06048760,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060486F8 mov.b @r1,r2
    c.r[10] = ld32(0x0604877Cu);  // 060486FA mov.l 0x0604877C,r10
    c.r[2] &= c.r[0];  // 060486FC and r0,r2
    st8(c.r[1], c.r[2]);  // 060486FE mov.b r2,@r1
    c.r[2] = ld32(0x06048780u);  // 06048700 mov.l 0x06048780,r2
    c.r[1] = 0x0u;  // 06048702 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06048704 mov.b r1,@r2
L_06048706:
    { const uint32_t x = c.r[10]; c.pr = 0x0604870Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604870Au) return; }  // 06048706 jsr @r10 ; mov r8,r4
    c.r[8] += 1;  // 0604870A add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 0604870C cmp/gt r9,r8
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_06048706; } }  // 0604870E bf/s 0x06048706 ; mov #0,r3
    c.r[1] = ld32(0x06048784u);  // 06048712 mov.l 0x06048784,r1
    st8(c.r[1], c.r[3]);  // 06048714 mov.b r3,@r1
    c.r[1] = ld32(0x06048788u);  // 06048716 mov.l 0x06048788,r1
    c.r[2] = 0x0u;  // 06048718 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0604871A mov.w r2,@r1
    c.r[1] = ld32(0x0604878Cu);  // 0604871C mov.l 0x0604878C,r1
    st16(c.r[1], c.r[2]);  // 0604871E mov.w r2,@r1
    c.r[1] = ld32(0x06048790u);  // 06048720 mov.l 0x06048790,r1
    st16(c.r[1], c.r[2]);  // 06048722 mov.w r2,@r1
    c.r[1] = ld32(0x06048794u);  // 06048724 mov.l 0x06048794,r1
    st8(c.r[1], c.r[3]);  // 06048726 mov.b r3,@r1
    c.r[1] = ld32(0x06048798u);  // 06048728 mov.l 0x06048798,r1
    st8(c.r[1], c.r[3]);  // 0604872A mov.b r3,@r1
    c.r[1] = ld32(0x0604879Cu);  // 0604872C mov.l 0x0604879C,r1
    st16(c.r[1], c.r[2]);  // 0604872E mov.w r2,@r1
    c.r[2] = ld32(0x060487A0u);  // 06048730 mov.l 0x060487A0,r2
    c.r[1] = c.r[2];  // 06048732 mov r2,r1
    c.r[1] += 51;  // 06048734 add #51,r1
    st8(c.r[1], c.r[3]);  // 06048736 mov.b r3,@r1
    c.r[1] = c.r[2];  // 06048738 mov r2,r1
    c.r[1] += 52;  // 0604873A add #52,r1
    st8(c.r[1], c.r[3]);  // 0604873C mov.b r3,@r1
    c.r[1] = c.r[2];  // 0604873E mov r2,r1
    c.r[1] += 124;  // 06048740 add #124,r1
    c.r[3] = 0x0u;  // 06048742 mov #0,r3
    st32(c.r[1], c.r[3]);  // 06048744 mov.l r3,@r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06048762u);  // 06048746 mov.w 0x06048762,r9
    c.r[0] = c.r[2];  // 06048748 mov r2,r0
    st32(c.r[0] + c.r[9], c.r[3]);  // 0604874A mov.l r3,@(r0,r9)
    c.r[8] = ld32(0x060487A4u);  // 0604874C mov.l 0x060487A4,r8
    c.r[5] = 0x1Fu;  // 0604874E mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06048754u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048754u) return; }  // 06048750 jsr @r8 ; mov #0,r4
    c.r[5] = 0x1Fu; goto L_060487A8;  // 06048754 bra 0x060487A8 ; mov #31,r5
L_060487A8:
    { const uint32_t x = c.r[8]; c.pr = 0x060487ACu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060487ACu) return; }  // 060487A8 jsr @r8 ; mov #1,r4
    c.r[5] = 0x1Fu;  // 060487AC mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060487B2u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060487B2u) return; }  // 060487AE jsr @r8 ; mov #2,r4
    c.r[5] = 0x1Fu;  // 060487B2 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060487B8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060487B8u) return; }  // 060487B4 jsr @r8 ; mov #3,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0604882Au);  // 060487B8 mov.w 0x0604882A,r5
    c.r[6] = c.r[5];  // 060487BA mov r5,r6
    c.r[0] = ld32(0x06048838u);  // 060487BC mov.l 0x06048838,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060487C2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060487C2u) return; }  // 060487BE jsr @r0 ; mov #0,r4
    c.r[3] = ld32(0x0604883Cu);  // 060487C2 mov.l 0x0604883C,r3
    c.r[2] = c.r[9];  // 060487C4 mov r9,r2
    c.r[7] = 0x0u;  // 060487C6 mov #0,r7
    c.r[1] = 0x1Au;  // 060487C8 mov #26,r1
L_060487CA:
    c.r[0] = c.r[7];  // 060487CA mov r7,r0
    c.r[7] += 2;  // 060487CC add #2,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 060487CE cmp/gt r1,r7
    { const bool k = !c.t; st16(c.r[0] + c.r[3], c.r[2]); if (k) { SH2_POLL(c); goto L_060487CA; } }  // 060487D0 bf/s 0x060487CA ; mov.w r2,@(r0,r3)
    c.r[2] = ld32(0x06048840u);  // 060487D4 mov.l 0x06048840,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604882Cu);  // 060487D6 mov.w 0x0604882C,r1
    st16(c.r[2], c.r[1]);  // 060487D8 mov.w r1,@r2
    c.r[3] = ld32(0x06048844u);  // 060487DA mov.l 0x06048844,r3
    c.r[2] = c.r[3];  // 060487DC mov r3,r2
    c.r[2] += 88;  // 060487DE add #88,r2
    c.r[1] = 0x1u;  // 060487E0 mov #1,r1
    st16(c.r[2], c.r[1]);  // 060487E2 mov.w r1,@r2
    c.r[8] = 0x0u;  // 060487E4 mov #0,r8
    c.r[6] = 0x5u;  // 060487E6 mov #5,r6
    c.r[7] = c.r[2];  // 060487E8 mov r2,r7
L_060487EA:
    c.r[2] = c.r[3];  // 060487EA mov r3,r2
    c.r[2] += 24;  // 060487EC add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060487EE mov.w @r7,r1
    c.r[3] += 2;  // 060487F0 add #2,r3
    c.r[8] += 1;  // 060487F2 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[6];  // 060487F4 cmp/gt r6,r8
    { const bool k = !c.t; st16(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_060487EA; } }  // 060487F6 bf/s 0x060487EA ; mov.w r1,@r2
    c.r[2] = ld32(0x06048848u);  // 060487FA mov.l 0x06048848,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604882Eu);  // 060487FC mov.w 0x0604882E,r1
    st16(c.r[2], c.r[1]);  // 060487FE mov.w r1,@r2
    c.r[2] = ld32(0x0604884Cu);  // 06048800 mov.l 0x0604884C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06048830u);  // 06048802 mov.w 0x06048830,r1
    st16(c.r[2], c.r[1]);  // 06048804 mov.w r1,@r2
    c.r[2] = ld32(0x06048850u);  // 06048806 mov.l 0x06048850,r2
    c.r[1] = ld32(0x06048854u);  // 06048808 mov.l 0x06048854,r1
    st32(c.r[2], c.r[1]);  // 0604880A mov.l r1,@r2
    c.r[2] = ld32(0x06048858u);  // 0604880C mov.l 0x06048858,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06048832u);  // 0604880E mov.w 0x06048832,r1
    st16(c.r[2], c.r[1]);  // 06048810 mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048834u);  // 06048812 mov.w 0x06048834,r0
    c.r[14] += 12;  // 06048814 add #12,r14
L_06048816:
    c.r[15] = c.r[14];  // 06048816 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06048818 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604881A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604881C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604881E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06048820 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06048822 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06048824 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048826 rts ; mov.l @r15+,r8
}

void f_0604885C(SH2Context& c) {
    ran[1160] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604885C mov.l r14,@-r15
    c.r[1] = ld32(0x0604888Cu);  // 0604885E mov.l 0x0604888C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048860 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048862 mov r1,r0
    c.r[0] >>= 2;  // 06048864 shlr2 r0
    c.r[0] >>= 2;  // 06048866 shlr2 r0
    c.r[0] >>= 2;  // 06048868 shlr2 r0
    c.r[0] &= 0x1u;  // 0604886A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604886C tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06048884; } }  // 0604886E bf/s 0x06048884 ; mov r15,r14
    c.r[1] = ld32(0x06048890u);  // 06048872 mov.l 0x06048890,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048874 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06048876 extu.w r1,r0
    c.t = c.r[0] == 0x1u;  // 06048878 cmp/eq #1,r0
    if (!c.t) { goto L_06048884; }  // 0604887A bf 0x06048884
    c.r[15] = c.r[14];  // 0604887C mov r14,r15
    c.r[0] = ld32(0x06048894u);  // 0604887E mov.l 0x06048894,r0
    goto L_06048888;  // 06048880 bra 0x06048888 ; nop
L_06048884:
    c.r[0] = 0x0u;  // 06048884 mov #0,r0
    c.r[15] = c.r[14];  // 06048886 mov r14,r15
L_06048888:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048888 rts ; mov.l @r15+,r14
}

void f_06048898(SH2Context& c) {
    ran[1161] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06048898 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604889A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604889C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604889E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060488A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060488A2 sts.l pr,@-r15
    c.r[1] = ld32(0x06048A00u);  // 060488A4 mov.l 0x06048A00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060488A6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060488A8 mov r1,r0
    c.r[0] >>= 2;  // 060488AA shlr2 r0
    c.r[0] >>= 2;  // 060488AC shlr2 r0
    c.r[0] >>= 2;  // 060488AE shlr2 r0
    c.r[0] &= 0x1u;  // 060488B0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060488B2 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060488BE; } }  // 060488B4 bt/s 0x060488BE ; mov r15,r14
    c.r[1] = ld32(0x06048A04u);  // 060488B8 mov.l 0x06048A04,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_060488C2;  // 060488BA bra 0x060488C2 ; mov.b @r1,r1
L_060488BE:
    c.r[1] = ld32(0x06048A08u);  // 060488BE mov.l 0x06048A08,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060488C0 mov.b @r1,r1
L_060488C2:
    c.r[2] = c.r[1] & 0xFFu;  // 060488C2 extu.b r1,r2
    c.r[1] = ld32(0x06048A00u);  // 060488C4 mov.l 0x06048A00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060488C6 mov.b @r1,r1
    c.r[8] = ld32(0x06048A0Cu);  // 060488C8 mov.l 0x06048A0C,r8
    c.r[0] = c.r[1];  // 060488CA mov r1,r0
    c.r[0] >>= 2;  // 060488CC shlr2 r0
    c.r[0] >>= 2;  // 060488CE shlr2 r0
    c.r[0] >>= 2;  // 060488D0 shlr2 r0
    c.r[0] &= 0x1u;  // 060488D2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060488D4 tst r0,r0
    if (c.t) { goto L_060488DA; }  // 060488D6 bt 0x060488DA
    c.r[8] = ld32(0x06048A10u);  // 060488D8 mov.l 0x06048A10,r8
L_060488DA:
    c.r[1] = ld32(0x06048A14u);  // 060488DA mov.l 0x06048A14,r1
    c.r[1] = ld32(c.r[1]);  // 060488DC mov.l @r1,r1
    c.r[2] += c.r[2];  // 060488DE add r2,r2
    c.r[2] += c.r[1];  // 060488E0 add r1,r2
    c.r[2] += 1;  // 060488E2 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060488E4 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060488E6 mov r1,r0
    c.r[0] >>= 2;  // 060488E8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060488EA shlr r0
    c.r[0] >>= 2;  // 060488EC shlr2 r0
    c.r[0] &= 0x3u;  // 060488EE and #3,r0
    c.r[1] = 0x3u;  // 060488F0 mov #3,r1
    c.t = c.r[0] > c.r[1];  // 060488F2 cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_060489E0; } }  // 060488F4 bt/s 0x060489E0 ; mov r0,r1
    c.r[1] += c.r[1];  // 060488F8 add r1,r1
    c.r[0] = 0x06048904u;  // 060488FA mova 0x06048904,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060488FC mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060488FE add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604890Cu: goto L_0604890C; case 0x0604893Au: goto L_0604893A; case 0x06048968u: goto L_06048968; default: sh2_call(c, x); return; } }  // 06048900 jmp @r0 ; nop
L_0604890C:
    c.r[8] += 10;  // 0604890C add #10,r8
    c.r[4] = ld32(0x06048A18u);  // 0604890E mov.l 0x06048A18,r4
    c.r[9] = ld32(0x06048A1Cu);  // 06048910 mov.l 0x06048A1C,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06048912 mov.w @r8,r8
    c.r[5] = 0x1Bu;  // 06048914 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604891Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604891Au) return; }  // 06048916 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 0604891A mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06048920u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048920u) return; }  // 0604891C jsr @r9 ; mov r0,r4
    c.r[0] += 10;  // 06048920 add #10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06048922 mov.b @r0,r1
    c.r[0] = c.r[1];  // 06048924 mov r1,r0
    c.r[0] >>= 2;  // 06048926 shlr2 r0
    c.r[0] >>= 2;  // 06048928 shlr2 r0
    c.r[0] >>= 2;  // 0604892A shlr2 r0
    c.r[0] &= 0x1u;  // 0604892C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604892E tst r0,r0
    if (c.t) { goto L_060489E0; }  // 06048930 bt 0x060489E0
    c.r[15] = c.r[14];  // 06048932 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060489F2u);  // 06048934 mov.w 0x060489F2,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060489E6;  // 06048936 bra 0x060489E6 ; lds.l @r15+,pr
L_0604893A:
    c.r[8] += 10;  // 0604893A add #10,r8
    c.r[4] = ld32(0x06048A18u);  // 0604893C mov.l 0x06048A18,r4
    c.r[9] = ld32(0x06048A1Cu);  // 0604893E mov.l 0x06048A1C,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06048940 mov.w @r8,r8
    c.r[5] = 0x1Bu;  // 06048942 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06048948u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048948u) return; }  // 06048944 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06048948 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604894Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604894Eu) return; }  // 0604894A jsr @r9 ; mov r0,r4
    c.r[0] += 10;  // 0604894E add #10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06048950 mov.b @r0,r1
    c.r[0] = c.r[1];  // 06048952 mov r1,r0
    c.r[0] >>= 2;  // 06048954 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06048956 shlr r0
    c.r[0] >>= 2;  // 06048958 shlr2 r0
    c.r[0] &= 0x1u;  // 0604895A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604895C tst r0,r0
    if (c.t) { goto L_060489E0; }  // 0604895E bt 0x060489E0
    c.r[15] = c.r[14];  // 06048960 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060489F4u);  // 06048962 mov.w 0x060489F4,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060489E6;  // 06048964 bra 0x060489E6 ; lds.l @r15+,pr
L_06048968:
    c.r[9] = c.r[8];  // 06048968 mov r8,r9
    c.r[9] += 10;  // 0604896A add #10,r9
    c.r[11] = ld32(0x06048A18u);  // 0604896C mov.l 0x06048A18,r11
    c.r[10] = ld32(0x06048A1Cu);  // 0604896E mov.l 0x06048A1C,r10
    c.r[5] = 0x1Bu;  // 06048970 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06048972 mov.w @r9,r8
    c.r[4] = c.r[11];  // 06048974 mov r11,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604897Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604897Au) return; }  // 06048976 jsr @r10 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 0604897A mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06048980u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048980u) return; }  // 0604897C jsr @r10 ; mov r0,r4
    c.r[0] += 10;  // 06048980 add #10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06048982 mov.b @r0,r1
    c.r[0] = c.r[1];  // 06048984 mov r1,r0
    c.r[0] >>= 2;  // 06048986 shlr2 r0
    c.r[0] >>= 2;  // 06048988 shlr2 r0
    c.r[0] &= 0x1u;  // 0604898A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604898C tst r0,r0
    { const bool k = c.t; c.r[5] = 0x1Bu; if (k) { goto L_06048998; } }  // 0604898E bt/s 0x06048998 ; mov #27,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060489F6u);  // 06048992 mov.w 0x060489F6,r0
    c.r[15] = c.r[14]; goto L_060489E4;  // 06048994 bra 0x060489E4 ; mov r14,r15
L_06048998:
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06048998 mov.w @r9,r8
    c.r[4] = c.r[11];  // 0604899A mov r11,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060489A0u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060489A0u) return; }  // 0604899C jsr @r10 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 060489A0 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060489A6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060489A6u) return; }  // 060489A2 jsr @r10 ; mov r0,r4
    c.r[0] += 10;  // 060489A6 add #10,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060489A8 mov.b @r0,r0
    c.r[1] = 0x1u;  // 060489AA mov #1,r1
    c.r[0] &= 0xCu;  // 060489AC and #12,r0
    c.r[0] >>= 2;  // 060489AE shlr2 r0
    c.t = c.r[0] > c.r[1];  // 060489B0 cmp/hi r1,r0
    if (!c.t) { goto L_060489BC; }  // 060489B2 bf 0x060489BC
    c.r[15] = c.r[14];  // 060489B4 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060489F8u);  // 060489B6 mov.w 0x060489F8,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060489E6;  // 060489B8 bra 0x060489E6 ; lds.l @r15+,pr
L_060489BC:
    c.r[5] = 0x1Bu;  // 060489BC mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060489BE mov.w @r9,r8
    c.r[4] = c.r[11];  // 060489C0 mov r11,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060489C6u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060489C6u) return; }  // 060489C2 jsr @r10 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 060489C6 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060489CCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060489CCu) return; }  // 060489C8 jsr @r10 ; mov r0,r4
    c.r[0] += 10;  // 060489CC add #10,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060489CE mov.b @r0,r0
    c.r[0] &= 0xCu;  // 060489D0 and #12,r0
    c.r[0] >>= 2;  // 060489D2 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 060489D4 cmp/eq #1,r0
    if (!c.t) { goto L_060489E0; }  // 060489D6 bf 0x060489E0
    c.r[15] = c.r[14];  // 060489D8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060489FAu);  // 060489DA mov.w 0x060489FA,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060489E6;  // 060489DC bra 0x060489E6 ; lds.l @r15+,pr
L_060489E0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060489FCu);  // 060489E0 mov.w 0x060489FC,r0
    c.r[15] = c.r[14];  // 060489E2 mov r14,r15
L_060489E4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060489E4 lds.l @r15+,pr
L_060489E6:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060489E6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060489E8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060489EA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060489EC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060489EE rts ; mov.l @r15+,r8
}

void f_06048A20(SH2Context& c) {
    ran[1162] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048A20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06048A22 sts.l pr,@-r15
    c.r[1] = ld32(0x06048A8Cu);  // 06048A24 mov.l 0x06048A8C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048A26 mov.b @r1,r1
    c.r[2] = ld32(0x06048A90u);  // 06048A28 mov.l 0x06048A90,r2
    c.r[0] = c.r[1];  // 06048A2A mov r1,r0
    c.r[0] >>= 2;  // 06048A2C shlr2 r0
    c.r[0] >>= 2;  // 06048A2E shlr2 r0
    c.r[0] >>= 2;  // 06048A30 shlr2 r0
    c.r[0] &= 0x1u;  // 06048A32 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048A34 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048A3C; } }  // 06048A36 bt/s 0x06048A3C ; mov r15,r14
    c.r[2] = ld32(0x06048A94u);  // 06048A3A mov.l 0x06048A94,r2
L_06048A3C:
    c.r[1] = c.r[2];  // 06048A3C mov r2,r1
    c.r[1] += 6;  // 06048A3E add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048A40 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06048A42 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048A44 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06048A52; } }  // 06048A46 bf/s 0x06048A52 ; tst r0,r0
    c.r[2] = ld32(0x06048A98u);  // 06048A4A mov.l 0x06048A98,r2
    { const bool k = c.t; c.r[3] = 0x3u; if (k) { goto L_06048A54; } }  // 06048A4C bt/s 0x06048A54 ; mov #3,r3
    c.r[2] = ld32(0x06048A9Cu);  // 06048A50 mov.l 0x06048A9C,r2
L_06048A52:
    c.r[3] = 0x3u;  // 06048A52 mov #3,r3
L_06048A54:
    c.r[0] = ld32(0x06048AA0u);  // 06048A54 mov.l 0x06048AA0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06048A56 mov.b @r2,r1
    c.r[4] = 0x1u;  // 06048A58 mov #1,r4
    c.r[1] >>= 2;  // 06048A5A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06048A5C shlr r1
    c.r[1] >>= 2;  // 06048A5E shlr2 r1
    c.r[1] &= c.r[3];  // 06048A60 and r3,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06048A66u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048A66u) return; }  // 06048A62 jsr @r0 ; mov r1,r5
    c.r[1] = ld32(0x06048AA4u);  // 06048A66 mov.l 0x06048AA4,r1
    c.r[1] = ld32(c.r[1]);  // 06048A68 mov.l @r1,r1
    c.r[1] += 1;  // 06048A6A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048A6C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06048A6E extu.b r1,r1
    c.r[1] &= c.r[0];  // 06048A70 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048A72 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048A7E; } }  // 06048A74 bf/s 0x06048A7E ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048A86u);  // 06048A78 mov.w 0x06048A86,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06048A82;  // 06048A7A bra 0x06048A82 ; lds.l @r15+,pr
L_06048A7E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048A88u);  // 06048A7E mov.w 0x06048A88,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06048A80 lds.l @r15+,pr
L_06048A82:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048A82 rts ; mov.l @r15+,r14
}

void f_06048AA8(SH2Context& c) {
    ran[1163] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048AA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06048AAA sts.l pr,@-r15
    c.r[1] = ld32(0x06048B14u);  // 06048AAC mov.l 0x06048B14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048AAE mov.b @r1,r1
    c.r[2] = ld32(0x06048B18u);  // 06048AB0 mov.l 0x06048B18,r2
    c.r[0] = c.r[1];  // 06048AB2 mov r1,r0
    c.r[0] >>= 2;  // 06048AB4 shlr2 r0
    c.r[0] >>= 2;  // 06048AB6 shlr2 r0
    c.r[0] >>= 2;  // 06048AB8 shlr2 r0
    c.r[0] &= 0x1u;  // 06048ABA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048ABC tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048AC4; } }  // 06048ABE bt/s 0x06048AC4 ; mov r15,r14
    c.r[2] = ld32(0x06048B1Cu);  // 06048AC2 mov.l 0x06048B1C,r2
L_06048AC4:
    c.r[1] = c.r[2];  // 06048AC4 mov r2,r1
    c.r[1] += 6;  // 06048AC6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048AC8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06048ACA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048ACC tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06048ADA; } }  // 06048ACE bf/s 0x06048ADA ; tst r0,r0
    c.r[2] = ld32(0x06048B20u);  // 06048AD2 mov.l 0x06048B20,r2
    { const bool k = c.t; c.r[3] = 0x3u; if (k) { goto L_06048ADC; } }  // 06048AD4 bt/s 0x06048ADC ; mov #3,r3
    c.r[2] = ld32(0x06048B24u);  // 06048AD8 mov.l 0x06048B24,r2
L_06048ADA:
    c.r[3] = 0x3u;  // 06048ADA mov #3,r3
L_06048ADC:
    c.r[0] = ld32(0x06048B28u);  // 06048ADC mov.l 0x06048B28,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06048ADE mov.b @r2,r1
    c.r[4] = 0x1u;  // 06048AE0 mov #1,r4
    c.r[1] >>= 2;  // 06048AE2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06048AE4 shlr r1
    c.r[1] >>= 2;  // 06048AE6 shlr2 r1
    c.r[1] &= c.r[3];  // 06048AE8 and r3,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06048AEEu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048AEEu) return; }  // 06048AEA jsr @r0 ; mov r1,r5
    c.r[1] = ld32(0x06048B2Cu);  // 06048AEE mov.l 0x06048B2C,r1
    c.r[1] = ld32(c.r[1]);  // 06048AF0 mov.l @r1,r1
    c.r[1] += 1;  // 06048AF2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048AF4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06048AF6 extu.b r1,r1
    c.r[1] &= c.r[0];  // 06048AF8 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048AFA tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048B06; } }  // 06048AFC bf/s 0x06048B06 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048B0Eu);  // 06048B00 mov.w 0x06048B0E,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06048B0A;  // 06048B02 bra 0x06048B0A ; lds.l @r15+,pr
L_06048B06:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048B10u);  // 06048B06 mov.w 0x06048B10,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06048B08 lds.l @r15+,pr
L_06048B0A:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048B0A rts ; mov.l @r15+,r14
}

void f_06048B30(SH2Context& c) {
    ran[1164] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048B30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06048B32 sts.l pr,@-r15
    c.r[1] = ld32(0x06048B98u);  // 06048B34 mov.l 0x06048B98,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048B36 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048B38 mov r1,r0
    c.r[0] >>= 2;  // 06048B3A shlr2 r0
    c.r[0] >>= 2;  // 06048B3C shlr2 r0
    c.r[0] >>= 2;  // 06048B3E shlr2 r0
    c.r[0] &= 0x1u;  // 06048B40 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048B42 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048B4E; } }  // 06048B44 bt/s 0x06048B4E ; mov r15,r14
    c.r[1] = ld32(0x06048B9Cu);  // 06048B48 mov.l 0x06048B9C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06048B52;  // 06048B4A bra 0x06048B52 ; mov.b @r1,r1
L_06048B4E:
    c.r[1] = ld32(0x06048BA0u);  // 06048B4E mov.l 0x06048BA0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048B50 mov.b @r1,r1
L_06048B52:
    c.r[0] = c.r[1] & 0xFFu;  // 06048B52 extu.b r1,r0
    c.r[1] = ld32(0x06048BA4u);  // 06048B54 mov.l 0x06048BA4,r1
    c.r[0] += c.r[0];  // 06048B56 add r0,r0
    c.r[1] = ld32(c.r[1]);  // 06048B58 mov.l @r1,r1
    c.r[2] = 0x3u;  // 06048B5A mov #3,r2
    c.r[0] += c.r[1];  // 06048B5C add r1,r0
    c.r[0] += 1;  // 06048B5E add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06048B60 mov.b @r0,r1
    c.r[4] = 0x1u;  // 06048B62 mov #1,r4
    c.r[1] >>= 2;  // 06048B64 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06048B66 shlr r1
    c.r[1] >>= 2;  // 06048B68 shlr2 r1
    c.r[1] &= c.r[2];  // 06048B6A and r2,r1
    c.r[0] = ld32(0x06048BA8u);  // 06048B6C mov.l 0x06048BA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048B72u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048B72u) return; }  // 06048B6E jsr @r0 ; mov r1,r5
    c.r[1] = ld32(0x06048BACu);  // 06048B72 mov.l 0x06048BAC,r1
    c.r[1] = ld32(c.r[1]);  // 06048B74 mov.l @r1,r1
    c.r[1] += 1;  // 06048B76 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048B78 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06048B7A extu.b r1,r1
    c.r[1] &= c.r[0];  // 06048B7C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048B7E tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048B8A; } }  // 06048B80 bf/s 0x06048B8A ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048B92u);  // 06048B84 mov.w 0x06048B92,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06048B8E;  // 06048B86 bra 0x06048B8E ; lds.l @r15+,pr
L_06048B8A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048B94u);  // 06048B8A mov.w 0x06048B94,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06048B8C lds.l @r15+,pr
L_06048B8E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048B8E rts ; mov.l @r15+,r14
}

void f_06048BB0(SH2Context& c) {
    ran[1165] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048BB0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06048BB2 sts.l pr,@-r15
    c.r[1] = ld32(0x06048C18u);  // 06048BB4 mov.l 0x06048C18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048BB6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048BB8 mov r1,r0
    c.r[0] >>= 2;  // 06048BBA shlr2 r0
    c.r[0] >>= 2;  // 06048BBC shlr2 r0
    c.r[0] >>= 2;  // 06048BBE shlr2 r0
    c.r[0] &= 0x1u;  // 06048BC0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048BC2 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048BCE; } }  // 06048BC4 bt/s 0x06048BCE ; mov r15,r14
    c.r[1] = ld32(0x06048C1Cu);  // 06048BC8 mov.l 0x06048C1C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06048BD2;  // 06048BCA bra 0x06048BD2 ; mov.b @r1,r1
L_06048BCE:
    c.r[1] = ld32(0x06048C20u);  // 06048BCE mov.l 0x06048C20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048BD0 mov.b @r1,r1
L_06048BD2:
    c.r[0] = c.r[1] & 0xFFu;  // 06048BD2 extu.b r1,r0
    c.r[1] = ld32(0x06048C24u);  // 06048BD4 mov.l 0x06048C24,r1
    c.r[0] += c.r[0];  // 06048BD6 add r0,r0
    c.r[1] = ld32(c.r[1]);  // 06048BD8 mov.l @r1,r1
    c.r[2] = 0x3u;  // 06048BDA mov #3,r2
    c.r[0] += c.r[1];  // 06048BDC add r1,r0
    c.r[0] += 1;  // 06048BDE add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06048BE0 mov.b @r0,r1
    c.r[4] = 0x1u;  // 06048BE2 mov #1,r4
    c.r[1] >>= 2;  // 06048BE4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06048BE6 shlr r1
    c.r[1] >>= 2;  // 06048BE8 shlr2 r1
    c.r[1] &= c.r[2];  // 06048BEA and r2,r1
    c.r[0] = ld32(0x06048C28u);  // 06048BEC mov.l 0x06048C28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06048BF2u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06048BF2u) return; }  // 06048BEE jsr @r0 ; mov r1,r5
    c.r[1] = ld32(0x06048C2Cu);  // 06048BF2 mov.l 0x06048C2C,r1
    c.r[1] = ld32(c.r[1]);  // 06048BF4 mov.l @r1,r1
    c.r[1] += 1;  // 06048BF6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048BF8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06048BFA extu.b r1,r1
    c.r[1] &= c.r[0];  // 06048BFC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048BFE tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048C0A; } }  // 06048C00 bf/s 0x06048C0A ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048C12u);  // 06048C04 mov.w 0x06048C12,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06048C0E;  // 06048C06 bra 0x06048C0E ; lds.l @r15+,pr
L_06048C0A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048C14u);  // 06048C0A mov.w 0x06048C14,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06048C0C lds.l @r15+,pr
L_06048C0E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048C0E rts ; mov.l @r15+,r14
}

void f_06048C30(SH2Context& c) {
    ran[1166] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048C30 mov.l r14,@-r15
    c.r[1] = ld32(0x06048C6Cu);  // 06048C32 mov.l 0x06048C6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048C34 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048C36 mov r1,r0
    c.r[0] >>= 2;  // 06048C38 shlr2 r0
    c.r[0] >>= 2;  // 06048C3A shlr2 r0
    c.r[0] >>= 2;  // 06048C3C shlr2 r0
    c.r[0] &= 0x1u;  // 06048C3E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048C40 tst r0,r0
    c.r[1] = ld32(0x06048C70u);  // 06048C42 mov.l 0x06048C70,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048C4A; } }  // 06048C44 bt/s 0x06048C4A ; mov r15,r14
    c.r[1] = ld32(0x06048C74u);  // 06048C48 mov.l 0x06048C74,r1
L_06048C4A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048C4A mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048C4C mov r1,r0
    c.r[0] >>= 2;  // 06048C4E shlr2 r0
    c.r[0] >>= 2;  // 06048C50 shlr2 r0
    c.r[0] >>= 2;  // 06048C52 shlr2 r0
    c.r[0] &= 0x1u;  // 06048C54 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048C56 tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048C62; } }  // 06048C58 bf/s 0x06048C62 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048C68u);  // 06048C5C mov.w 0x06048C68,r0
    goto L_06048C64;  // 06048C5E bra 0x06048C64 ; nop
L_06048C62:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048C6Au);  // 06048C62 mov.w 0x06048C6A,r0
L_06048C64:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048C64 rts ; mov.l @r15+,r14
}

void f_06048C78(SH2Context& c) {
    ran[1167] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048C78 mov.l r14,@-r15
    c.r[1] = ld32(0x06048CB4u);  // 06048C7A mov.l 0x06048CB4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048C7C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048C7E mov r1,r0
    c.r[0] >>= 2;  // 06048C80 shlr2 r0
    c.r[0] >>= 2;  // 06048C82 shlr2 r0
    c.r[0] >>= 2;  // 06048C84 shlr2 r0
    c.r[0] &= 0x1u;  // 06048C86 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048C88 tst r0,r0
    c.r[1] = ld32(0x06048CB8u);  // 06048C8A mov.l 0x06048CB8,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048C92; } }  // 06048C8C bt/s 0x06048C92 ; mov r15,r14
    c.r[1] = ld32(0x06048CBCu);  // 06048C90 mov.l 0x06048CBC,r1
L_06048C92:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048C92 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048C94 mov r1,r0
    c.r[0] >>= 2;  // 06048C96 shlr2 r0
    c.r[0] >>= 2;  // 06048C98 shlr2 r0
    c.r[0] &= 0x1u;  // 06048C9A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048C9C tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048CA8; } }  // 06048C9E bf/s 0x06048CA8 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048CAEu);  // 06048CA2 mov.w 0x06048CAE,r0
    goto L_06048CAA;  // 06048CA4 bra 0x06048CAA ; nop
L_06048CA8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048CB0u);  // 06048CA8 mov.w 0x06048CB0,r0
L_06048CAA:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048CAA rts ; mov.l @r15+,r14
}

void f_06048CC0(SH2Context& c) {
    ran[1168] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048CC0 mov.l r14,@-r15
    c.r[1] = ld32(0x06048CFCu);  // 06048CC2 mov.l 0x06048CFC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048CC4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048CC6 mov r1,r0
    c.r[0] >>= 2;  // 06048CC8 shlr2 r0
    c.r[0] >>= 2;  // 06048CCA shlr2 r0
    c.r[0] >>= 2;  // 06048CCC shlr2 r0
    c.r[0] &= 0x1u;  // 06048CCE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048CD0 tst r0,r0
    c.r[1] = ld32(0x06048D00u);  // 06048CD2 mov.l 0x06048D00,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048CDA; } }  // 06048CD4 bt/s 0x06048CDA ; mov r15,r14
    c.r[1] = ld32(0x06048D04u);  // 06048CD8 mov.l 0x06048D04,r1
L_06048CDA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048CDA mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048CDC mov r1,r0
    c.r[0] >>= 2;  // 06048CDE shlr2 r0
    c.r[0] >>= 2;  // 06048CE0 shlr2 r0
    c.r[0] >>= 2;  // 06048CE2 shlr2 r0
    c.r[0] &= 0x1u;  // 06048CE4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048CE6 tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06048CF2; } }  // 06048CE8 bt/s 0x06048CF2 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048CF8u);  // 06048CEC mov.w 0x06048CF8,r0
    goto L_06048CF4;  // 06048CEE bra 0x06048CF4 ; nop
L_06048CF2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048CFAu);  // 06048CF2 mov.w 0x06048CFA,r0
L_06048CF4:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048CF4 rts ; mov.l @r15+,r14
}

void f_06048D08(SH2Context& c) {
    ran[1169] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048D08 mov.l r14,@-r15
    c.r[1] = ld32(0x06048D44u);  // 06048D0A mov.l 0x06048D44,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048D0C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048D0E mov r1,r0
    c.r[0] >>= 2;  // 06048D10 shlr2 r0
    c.r[0] >>= 2;  // 06048D12 shlr2 r0
    c.r[0] >>= 2;  // 06048D14 shlr2 r0
    c.r[0] &= 0x1u;  // 06048D16 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048D18 tst r0,r0
    c.r[1] = ld32(0x06048D48u);  // 06048D1A mov.l 0x06048D48,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048D22; } }  // 06048D1C bt/s 0x06048D22 ; mov r15,r14
    c.r[1] = ld32(0x06048D4Cu);  // 06048D20 mov.l 0x06048D4C,r1
L_06048D22:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048D22 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048D24 mov r1,r0
    c.r[0] >>= 2;  // 06048D26 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06048D28 shlr r0
    c.r[0] >>= 2;  // 06048D2A shlr2 r0
    c.r[0] &= 0x1u;  // 06048D2C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048D2E tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048D3A; } }  // 06048D30 bf/s 0x06048D3A ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048D40u);  // 06048D34 mov.w 0x06048D40,r0
    goto L_06048D3C;  // 06048D36 bra 0x06048D3C ; nop
L_06048D3A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048D42u);  // 06048D3A mov.w 0x06048D42,r0
L_06048D3C:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048D3C rts ; mov.l @r15+,r14
}

void f_06048D50(SH2Context& c) {
    ran[1170] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048D50 mov.l r14,@-r15
    c.r[1] = ld32(0x06048D88u);  // 06048D52 mov.l 0x06048D88,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048D54 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048D56 mov r1,r0
    c.r[0] >>= 2;  // 06048D58 shlr2 r0
    c.r[0] >>= 2;  // 06048D5A shlr2 r0
    c.r[0] >>= 2;  // 06048D5C shlr2 r0
    c.r[0] &= 0x1u;  // 06048D5E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048D60 tst r0,r0
    c.r[1] = ld32(0x06048D8Cu);  // 06048D62 mov.l 0x06048D8C,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048D6A; } }  // 06048D64 bt/s 0x06048D6A ; mov r15,r14
    c.r[1] = ld32(0x06048D90u);  // 06048D68 mov.l 0x06048D90,r1
L_06048D6A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048D6A mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048D6C mov r1,r0
    c.r[0] >>= 2;  // 06048D6E shlr2 r0
    c.r[0] &= 0x3u;  // 06048D70 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06048D72 cmp/eq #1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06048D7E; } }  // 06048D74 bt/s 0x06048D7E ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048D84u);  // 06048D78 mov.w 0x06048D84,r0
    goto L_06048D80;  // 06048D7A bra 0x06048D80 ; nop
L_06048D7E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048D86u);  // 06048D7E mov.w 0x06048D86,r0
L_06048D80:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048D80 rts ; mov.l @r15+,r14
}

void f_06048D94(SH2Context& c) {
    ran[1171] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048D94 mov.l r14,@-r15
    c.r[1] = ld32(0x06048E2Cu);  // 06048D96 mov.l 0x06048E2C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048D98 mov.b @r1,r1
    c.r[3] = ld32(0x06048E30u);  // 06048D9A mov.l 0x06048E30,r3
    c.r[0] = c.r[1];  // 06048D9C mov r1,r0
    c.r[0] >>= 2;  // 06048D9E shlr2 r0
    c.r[0] >>= 2;  // 06048DA0 shlr2 r0
    c.r[0] >>= 2;  // 06048DA2 shlr2 r0
    c.r[0] &= 0x1u;  // 06048DA4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048DA6 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048DAE; } }  // 06048DA8 bt/s 0x06048DAE ; mov r15,r14
    c.r[3] = ld32(0x06048E34u);  // 06048DAC mov.l 0x06048E34,r3
L_06048DAE:
    c.r[1] = c.r[3];  // 06048DAE mov r3,r1
    c.r[1] += 6;  // 06048DB0 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048DB2 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06048DB4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048DB6 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06048DC2; } }  // 06048DB8 bf/s 0x06048DC2 ; tst r0,r0
    c.r[3] = ld32(0x06048E38u);  // 06048DBC mov.l 0x06048E38,r3
    if (c.t) { goto L_06048DC2; }  // 06048DBE bt 0x06048DC2
    c.r[3] = ld32(0x06048E3Cu);  // 06048DC0 mov.l 0x06048E3C,r3
L_06048DC2:
    c.r[1] = ld32(0x06048E2Cu);  // 06048DC2 mov.l 0x06048E2C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048DC4 mov.b @r1,r1
    c.r[2] = ld32(0x06048E34u);  // 06048DC6 mov.l 0x06048E34,r2
    c.r[0] = c.r[1];  // 06048DC8 mov r1,r0
    c.r[0] >>= 2;  // 06048DCA shlr2 r0
    c.r[0] >>= 2;  // 06048DCC shlr2 r0
    c.r[0] >>= 2;  // 06048DCE shlr2 r0
    c.r[0] &= 0x1u;  // 06048DD0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048DD2 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06048DDC; } }  // 06048DD4 bt/s 0x06048DDC ; mov r2,r1
    c.r[2] = ld32(0x06048E30u);  // 06048DD8 mov.l 0x06048E30,r2
    c.r[1] = c.r[2];  // 06048DDA mov r2,r1
L_06048DDC:
    c.r[1] += 6;  // 06048DDC add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048DDE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06048DE0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048DE2 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06048DEE; } }  // 06048DE4 bf/s 0x06048DEE ; tst r0,r0
    c.r[2] = ld32(0x06048E3Cu);  // 06048DE8 mov.l 0x06048E3C,r2
    if (c.t) { goto L_06048DEE; }  // 06048DEA bt 0x06048DEE
    c.r[2] = ld32(0x06048E38u);  // 06048DEC mov.l 0x06048E38,r2
L_06048DEE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06048DEE mov.b @r3,r1
    c.r[0] = c.r[1];  // 06048DF0 mov r1,r0
    c.r[0] &= 0x3u;  // 06048DF2 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06048DF4 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06048E1C; } }  // 06048DF6 bt/s 0x06048E1C ; mov r1,r0
    c.r[0] &= 0x1Fu;  // 06048DFA and #31,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048DFC tst r0,r0
    { const bool k = c.t; c.r[2] += 10; if (k) { goto L_06048E1C; } }  // 06048DFE bt/s 0x06048E1C ; add #10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06048E02 mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06048E04 extu.w r1,r0
    c.t = c.r[0] == 0x9u;  // 06048E06 cmp/eq #9,r0
    if (c.t) { goto L_06048E10; }  // 06048E08 bt 0x06048E10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06048E24u);  // 06048E0A mov.w 0x06048E24,r1
    c.t = c.r[0] == c.r[1];  // 06048E0C cmp/eq r1,r0
    if (!c.t) { goto L_06048E16; }  // 06048E0E bf 0x06048E16
L_06048E10:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048E26u);  // 06048E10 mov.w 0x06048E26,r0
    c.r[15] = c.r[14]; goto L_06048E20;  // 06048E12 bra 0x06048E20 ; mov r14,r15
L_06048E16:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048E28u);  // 06048E16 mov.w 0x06048E28,r0
    c.r[15] = c.r[14]; goto L_06048E20;  // 06048E18 bra 0x06048E20 ; mov r14,r15
L_06048E1C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048E2Au);  // 06048E1C mov.w 0x06048E2A,r0
    c.r[15] = c.r[14];  // 06048E1E mov r14,r15
L_06048E20:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048E20 rts ; mov.l @r15+,r14
}

void f_06048E40(SH2Context& c) {
    ran[1172] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048E40 mov.l r14,@-r15
    c.r[1] = ld32(0x06048E80u);  // 06048E42 mov.l 0x06048E80,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048E44 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048E46 mov r1,r0
    c.r[0] >>= 2;  // 06048E48 shlr2 r0
    c.r[0] >>= 2;  // 06048E4A shlr2 r0
    c.r[0] >>= 2;  // 06048E4C shlr2 r0
    c.r[0] &= 0x1u;  // 06048E4E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048E50 tst r0,r0
    c.r[1] = ld32(0x06048E84u);  // 06048E52 mov.l 0x06048E84,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048E5A; } }  // 06048E54 bt/s 0x06048E5A ; mov r15,r14
    c.r[1] = ld32(0x06048E88u);  // 06048E58 mov.l 0x06048E88,r1
L_06048E5A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048E5A mov.w @r1,r1
    c.r[0] = c.r[1];  // 06048E5C mov r1,r0
    c.r[0] >>= 2;  // 06048E5E shlr2 r0
    c.r[0] >>= 2;  // 06048E60 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06048E62 shlr r0
    c.r[0] >>= 2;  // 06048E64 shlr2 r0
    c.r[0] &= 0x3u;  // 06048E66 and #3,r0
    c.t = c.r[0] == 0x3u;  // 06048E68 cmp/eq #3,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06048E74; } }  // 06048E6A bt/s 0x06048E74 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048E7Au);  // 06048E6E mov.w 0x06048E7A,r0
    goto L_06048E76;  // 06048E70 bra 0x06048E76 ; nop
L_06048E74:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048E7Cu);  // 06048E74 mov.w 0x06048E7C,r0
L_06048E76:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048E76 rts ; mov.l @r15+,r14
}

void f_06048E8C(SH2Context& c) {
    ran[1173] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048E8C mov.l r14,@-r15
    c.r[1] = ld32(0x06048ECCu);  // 06048E8E mov.l 0x06048ECC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048E90 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048E92 mov r1,r0
    c.r[0] >>= 2;  // 06048E94 shlr2 r0
    c.r[0] >>= 2;  // 06048E96 shlr2 r0
    c.r[0] >>= 2;  // 06048E98 shlr2 r0
    c.r[0] &= 0x1u;  // 06048E9A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048E9C tst r0,r0
    c.r[1] = ld32(0x06048ED0u);  // 06048E9E mov.l 0x06048ED0,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048EA6; } }  // 06048EA0 bt/s 0x06048EA6 ; mov r15,r14
    c.r[1] = ld32(0x06048ED4u);  // 06048EA4 mov.l 0x06048ED4,r1
L_06048EA6:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048EA6 mov.w @r1,r1
    c.r[0] = c.r[1];  // 06048EA8 mov r1,r0
    c.r[0] >>= 2;  // 06048EAA shlr2 r0
    c.r[0] >>= 2;  // 06048EAC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06048EAE shlr r0
    c.r[0] >>= 2;  // 06048EB0 shlr2 r0
    c.r[0] &= 0x3u;  // 06048EB2 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06048EB4 cmp/eq #1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06048EC0; } }  // 06048EB6 bt/s 0x06048EC0 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048EC6u);  // 06048EBA mov.w 0x06048EC6,r0
    goto L_06048EC2;  // 06048EBC bra 0x06048EC2 ; nop
L_06048EC0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048EC8u);  // 06048EC0 mov.w 0x06048EC8,r0
L_06048EC2:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048EC2 rts ; mov.l @r15+,r14
}

void f_06048ED8(SH2Context& c) {
    ran[1174] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048ED8 mov.l r14,@-r15
    c.r[1] = ld32(0x06048F18u);  // 06048EDA mov.l 0x06048F18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048EDC mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048EDE mov r1,r0
    c.r[0] >>= 2;  // 06048EE0 shlr2 r0
    c.r[0] >>= 2;  // 06048EE2 shlr2 r0
    c.r[0] >>= 2;  // 06048EE4 shlr2 r0
    c.r[0] &= 0x1u;  // 06048EE6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048EE8 tst r0,r0
    c.r[1] = ld32(0x06048F1Cu);  // 06048EEA mov.l 0x06048F1C,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048EF2; } }  // 06048EEC bt/s 0x06048EF2 ; mov r15,r14
    c.r[1] = ld32(0x06048F20u);  // 06048EF0 mov.l 0x06048F20,r1
L_06048EF2:
    c.r[1] += 1;  // 06048EF2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048EF4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06048EF6 extu.b r1,r1
    c.r[1] >>= 2;  // 06048EF8 shlr2 r1
    c.r[1] >>= 2;  // 06048EFA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06048EFC shlr r1
    c.r[1] >>= 2;  // 06048EFE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048F00 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06048F0C; } }  // 06048F02 bf/s 0x06048F0C ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048F12u);  // 06048F06 mov.w 0x06048F12,r0
    goto L_06048F0E;  // 06048F08 bra 0x06048F0E ; nop
L_06048F0C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048F14u);  // 06048F0C mov.w 0x06048F14,r0
L_06048F0E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048F0E rts ; mov.l @r15+,r14
}

void f_06048F24(SH2Context& c) {
    ran[1175] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048F24 mov.l r14,@-r15
    c.r[1] = ld32(0x06048F9Cu);  // 06048F26 mov.l 0x06048F9C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048F28 mov.b @r1,r1
    c.r[2] = ld32(0x06048FA0u);  // 06048F2A mov.l 0x06048FA0,r2
    c.r[0] = c.r[1];  // 06048F2C mov r1,r0
    c.r[0] >>= 2;  // 06048F2E shlr2 r0
    c.r[0] >>= 2;  // 06048F30 shlr2 r0
    c.r[0] >>= 2;  // 06048F32 shlr2 r0
    c.r[0] &= 0x1u;  // 06048F34 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048F36 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06048F3E; } }  // 06048F38 bt/s 0x06048F3E ; mov r15,r14
    c.r[2] = ld32(0x06048FA4u);  // 06048F3C mov.l 0x06048FA4,r2
L_06048F3E:
    c.r[1] = c.r[2];  // 06048F3E mov r2,r1
    c.r[1] += 6;  // 06048F40 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06048F42 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06048F44 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06048F46 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06048F52; } }  // 06048F48 bf/s 0x06048F52 ; tst r0,r0
    c.r[2] = ld32(0x06048FA8u);  // 06048F4C mov.l 0x06048FA8,r2
    if (c.t) { goto L_06048F52; }  // 06048F4E bt 0x06048F52
    c.r[2] = ld32(0x06048FACu);  // 06048F50 mov.l 0x06048FAC,r2
L_06048F52:
    c.r[1] = ld32(0x06048F9Cu);  // 06048F52 mov.l 0x06048F9C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048F54 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048F56 mov r1,r0
    c.r[0] >>= 2;  // 06048F58 shlr2 r0
    c.r[0] >>= 2;  // 06048F5A shlr2 r0
    c.r[0] >>= 2;  // 06048F5C shlr2 r0
    c.r[0] &= 0x1u;  // 06048F5E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048F60 tst r0,r0
    c.r[1] = ld32(0x06048FB0u);  // 06048F62 mov.l 0x06048FB0,r1
    if (c.t) { goto L_06048F68; }  // 06048F64 bt 0x06048F68
    c.r[1] = ld32(0x06048FB4u);  // 06048F66 mov.l 0x06048FB4,r1
L_06048F68:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06048F68 mov.b @r2,r2
    c.r[0] = c.r[2];  // 06048F6A mov r2,r0
    c.r[0] &= 0x3u;  // 06048F6C and #3,r0
    c.t = c.r[0] == 0x1u;  // 06048F6E cmp/eq #1,r0
    if (c.t) { goto L_06048F8E; }  // 06048F70 bt 0x06048F8E
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048F72 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06048F74 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06048F76 shlr r0
    c.r[0] &= 0x1u;  // 06048F78 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048F7A tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06048F8E; } }  // 06048F7C bt/s 0x06048F8E ; mov r2,r0
    c.r[0] &= 0x1Fu;  // 06048F80 and #31,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06048F82 tst r0,r0
    if (c.t) { goto L_06048F8E; }  // 06048F84 bt 0x06048F8E
    c.r[15] = c.r[14];  // 06048F86 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048F96u);  // 06048F88 mov.w 0x06048F96,r0
    goto L_06048F92;  // 06048F8A bra 0x06048F92 ; nop
L_06048F8E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048F98u);  // 06048F8E mov.w 0x06048F98,r0
    c.r[15] = c.r[14];  // 06048F90 mov r14,r15
L_06048F92:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048F92 rts ; mov.l @r15+,r14
}

void f_06048FB8(SH2Context& c) {
    ran[1176] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048FB8 mov.l r14,@-r15
    c.r[1] = ld32(0x06048FECu);  // 06048FBA mov.l 0x06048FEC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048FBC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06048FBE extu.b r1,r1
    c.r[0] = c.r[1];  // 06048FC0 mov r1,r0
    c.r[0] >>= 2;  // 06048FC2 shlr2 r0
    c.r[0] >>= 2;  // 06048FC4 shlr2 r0
    c.r[0] >>= 2;  // 06048FC6 shlr2 r0
    c.r[1] >>= 2;  // 06048FC8 shlr2 r1
    c.r[1] >>= 2;  // 06048FCA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06048FCC shlr r1
    c.r[1] >>= 2;  // 06048FCE shlr2 r1
    c.r[0] &= 0x1u;  // 06048FD0 and #1,r0
    c.t = c.r[1] == c.r[0];  // 06048FD2 cmp/eq r0,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06048FDE; } }  // 06048FD4 bf/s 0x06048FDE ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048FE6u);  // 06048FD8 mov.w 0x06048FE6,r0
    c.r[15] = c.r[14]; goto L_06048FE2;  // 06048FDA bra 0x06048FE2 ; mov r14,r15
L_06048FDE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06048FE8u);  // 06048FDE mov.w 0x06048FE8,r0
    c.r[15] = c.r[14];  // 06048FE0 mov r14,r15
L_06048FE2:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06048FE2 rts ; mov.l @r15+,r14
}

void f_06048FF0(SH2Context& c) {
    ran[1177] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06048FF0 mov.l r14,@-r15
    c.r[1] = ld32(0x06049038u);  // 06048FF2 mov.l 0x06049038,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06048FF4 mov.b @r1,r1
    c.r[2] = ld32(0x0604903Cu);  // 06048FF6 mov.l 0x0604903C,r2
    c.r[0] = c.r[1];  // 06048FF8 mov r1,r0
    c.r[0] >>= 2;  // 06048FFA shlr2 r0
    c.r[0] >>= 2;  // 06048FFC shlr2 r0
    c.r[0] >>= 2;  // 06048FFE shlr2 r0
    c.r[0] &= 0x1u;  // 06049000 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049002 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604900A; } }  // 06049004 bt/s 0x0604900A ; mov r15,r14
    c.r[2] = ld32(0x06049040u);  // 06049008 mov.l 0x06049040,r2
L_0604900A:
    c.r[1] = c.r[2];  // 0604900A mov r2,r1
    c.r[1] += 6;  // 0604900C add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604900E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06049010 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049012 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_0604901E; } }  // 06049014 bf/s 0x0604901E ; tst r0,r0
    c.r[2] = ld32(0x06049044u);  // 06049018 mov.l 0x06049044,r2
    if (c.t) { goto L_0604901E; }  // 0604901A bt 0x0604901E
    c.r[2] = ld32(0x06049048u);  // 0604901C mov.l 0x06049048,r2
L_0604901E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604901E mov.b @r2,r0
    c.r[0] &= 0x3u;  // 06049020 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06049022 cmp/eq #1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0604902E; } }  // 06049024 bt/s 0x0604902E ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049034u);  // 06049028 mov.w 0x06049034,r0
    goto L_06049030;  // 0604902A bra 0x06049030 ; nop
L_0604902E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049036u);  // 0604902E mov.w 0x06049036,r0
L_06049030:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049030 rts ; mov.l @r15+,r14
}

void f_0604904C(SH2Context& c) {
    ran[1178] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604904C mov.l r14,@-r15
    c.r[1] = ld32(0x060490B8u);  // 0604904E mov.l 0x060490B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049050 mov.b @r1,r1
    c.r[2] = ld32(0x060490BCu);  // 06049052 mov.l 0x060490BC,r2
    c.r[0] = c.r[1];  // 06049054 mov r1,r0
    c.r[0] >>= 2;  // 06049056 shlr2 r0
    c.r[0] >>= 2;  // 06049058 shlr2 r0
    c.r[0] >>= 2;  // 0604905A shlr2 r0
    c.r[0] &= 0x1u;  // 0604905C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604905E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06049066; } }  // 06049060 bt/s 0x06049066 ; mov r15,r14
    c.r[2] = ld32(0x060490C0u);  // 06049064 mov.l 0x060490C0,r2
L_06049066:
    c.r[1] = c.r[2];  // 06049066 mov r2,r1
    c.r[1] += 6;  // 06049068 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604906A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604906C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604906E tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_0604907A; } }  // 06049070 bf/s 0x0604907A ; tst r0,r0
    c.r[2] = ld32(0x060490C4u);  // 06049074 mov.l 0x060490C4,r2
    if (c.t) { goto L_0604907A; }  // 06049076 bt 0x0604907A
    c.r[2] = ld32(0x060490C8u);  // 06049078 mov.l 0x060490C8,r2
L_0604907A:
    c.r[1] = ld32(0x060490B8u);  // 0604907A mov.l 0x060490B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604907C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604907E mov r1,r0
    c.r[0] >>= 2;  // 06049080 shlr2 r0
    c.r[0] >>= 2;  // 06049082 shlr2 r0
    c.r[0] >>= 2;  // 06049084 shlr2 r0
    c.r[0] &= 0x1u;  // 06049086 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049088 tst r0,r0
    c.r[1] = ld32(0x060490CCu);  // 0604908A mov.l 0x060490CC,r1
    if (c.t) { goto L_06049090; }  // 0604908C bt 0x06049090
    c.r[1] = ld32(0x060490D0u);  // 0604908E mov.l 0x060490D0,r1
L_06049090:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049090 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06049092 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06049094 shlr r0
    c.r[0] &= 0x1u;  // 06049096 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049098 tst r0,r0
    if (c.t) { goto L_060490AC; }  // 0604909A bt 0x060490AC
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604909C mov.b @r2,r0
    c.r[0] &= 0x3u;  // 0604909E and #3,r0
    c.t = c.r[0] == 0x1u;  // 060490A0 cmp/eq #1,r0
    if (!c.t) { goto L_060490AC; }  // 060490A2 bf 0x060490AC
    c.r[15] = c.r[14];  // 060490A4 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060490B4u);  // 060490A6 mov.w 0x060490B4,r0
    goto L_060490B0;  // 060490A8 bra 0x060490B0 ; nop
L_060490AC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060490B6u);  // 060490AC mov.w 0x060490B6,r0
    c.r[15] = c.r[14];  // 060490AE mov r14,r15
L_060490B0:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060490B0 rts ; mov.l @r15+,r14
}

void f_060490D4(SH2Context& c) {
    ran[1179] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060490D4 mov.l r14,@-r15
    c.r[1] = ld32(0x06049120u);  // 060490D6 mov.l 0x06049120,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060490D8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060490DA mov r1,r0
    c.r[0] >>= 2;  // 060490DC shlr2 r0
    c.r[0] >>= 2;  // 060490DE shlr2 r0
    c.r[0] >>= 2;  // 060490E0 shlr2 r0
    c.r[0] &= 0x1u;  // 060490E2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060490E4 tst r0,r0
    c.r[1] = ld32(0x06049124u);  // 060490E6 mov.l 0x06049124,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060490EE; } }  // 060490E8 bt/s 0x060490EE ; mov r15,r14
    c.r[1] = ld32(0x06049128u);  // 060490EC mov.l 0x06049128,r1
L_060490EE:
    c.r[1] += 1;  // 060490EE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060490F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060490F2 extu.b r1,r1
    c.r[0] = c.r[1];  // 060490F4 mov r1,r0
    c.r[0] >>= 2;  // 060490F6 shlr2 r0
    c.r[0] >>= 2;  // 060490F8 shlr2 r0
    c.r[0] &= 0x1u;  // 060490FA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060490FC tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06049112; } }  // 060490FE bt/s 0x06049112 ; mov r1,r0
    c.r[0] >>= 2;  // 06049102 shlr2 r0
    c.r[0] &= 0x1u;  // 06049104 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049106 tst r0,r0
    if (!c.t) { goto L_06049112; }  // 06049108 bf 0x06049112
    c.r[15] = c.r[14];  // 0604910A mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604911Au);  // 0604910C mov.w 0x0604911A,r0
    goto L_06049116;  // 0604910E bra 0x06049116 ; nop
L_06049112:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604911Cu);  // 06049112 mov.w 0x0604911C,r0
    c.r[15] = c.r[14];  // 06049114 mov r14,r15
L_06049116:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049116 rts ; mov.l @r15+,r14
}

void f_0604912C(SH2Context& c) {
    ran[1180] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604912C mov.l r14,@-r15
    c.r[1] = ld32(0x06049178u);  // 0604912E mov.l 0x06049178,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049130 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06049132 mov r1,r0
    c.r[0] >>= 2;  // 06049134 shlr2 r0
    c.r[0] >>= 2;  // 06049136 shlr2 r0
    c.r[0] >>= 2;  // 06049138 shlr2 r0
    c.r[0] &= 0x1u;  // 0604913A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604913C tst r0,r0
    c.r[1] = ld32(0x0604917Cu);  // 0604913E mov.l 0x0604917C,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06049146; } }  // 06049140 bt/s 0x06049146 ; mov r15,r14
    c.r[1] = ld32(0x06049180u);  // 06049144 mov.l 0x06049180,r1
L_06049146:
    c.r[1] += 1;  // 06049146 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049148 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604914A extu.b r1,r1
    c.r[0] = c.r[1];  // 0604914C mov r1,r0
    c.r[0] >>= 2;  // 0604914E shlr2 r0
    c.r[0] >>= 2;  // 06049150 shlr2 r0
    c.r[0] &= 0x1u;  // 06049152 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049154 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0604916A; } }  // 06049156 bt/s 0x0604916A ; mov r1,r0
    c.r[0] >>= 2;  // 0604915A shlr2 r0
    c.r[0] &= 0x1u;  // 0604915C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604915E tst r0,r0
    if (!c.t) { goto L_0604916A; }  // 06049160 bf 0x0604916A
    c.r[15] = c.r[14];  // 06049162 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049172u);  // 06049164 mov.w 0x06049172,r0
    goto L_0604916E;  // 06049166 bra 0x0604916E ; nop
L_0604916A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049174u);  // 0604916A mov.w 0x06049174,r0
    c.r[15] = c.r[14];  // 0604916C mov r14,r15
L_0604916E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604916E rts ; mov.l @r15+,r14
}

void f_06049184(SH2Context& c) {
    ran[1181] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049184 mov.l r14,@-r15
    c.r[1] = ld32(0x060491CCu);  // 06049186 mov.l 0x060491CC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049188 mov.b @r1,r1
    c.r[2] = ld32(0x060491D0u);  // 0604918A mov.l 0x060491D0,r2
    c.r[0] = c.r[1];  // 0604918C mov r1,r0
    c.r[0] >>= 2;  // 0604918E shlr2 r0
    c.r[0] >>= 2;  // 06049190 shlr2 r0
    c.r[0] >>= 2;  // 06049192 shlr2 r0
    c.r[0] &= 0x1u;  // 06049194 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049196 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604919E; } }  // 06049198 bt/s 0x0604919E ; mov r15,r14
    c.r[2] = ld32(0x060491D4u);  // 0604919C mov.l 0x060491D4,r2
L_0604919E:
    c.r[1] = c.r[2];  // 0604919E mov r2,r1
    c.r[1] += 6;  // 060491A0 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060491A2 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060491A4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060491A6 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_060491B2; } }  // 060491A8 bf/s 0x060491B2 ; tst r0,r0
    c.r[2] = ld32(0x060491D8u);  // 060491AC mov.l 0x060491D8,r2
    if (c.t) { goto L_060491B2; }  // 060491AE bt 0x060491B2
    c.r[2] = ld32(0x060491DCu);  // 060491B0 mov.l 0x060491DC,r2
L_060491B2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060491B2 mov.b @r2,r0
    c.r[0] &= 0x3u;  // 060491B4 and #3,r0
    c.t = c.r[0] == 0x2u;  // 060491B6 cmp/eq #2,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060491C2; } }  // 060491B8 bt/s 0x060491C2 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060491C8u);  // 060491BC mov.w 0x060491C8,r0
    goto L_060491C4;  // 060491BE bra 0x060491C4 ; nop
L_060491C2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060491CAu);  // 060491C2 mov.w 0x060491CA,r0
L_060491C4:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060491C4 rts ; mov.l @r15+,r14
}

void f_060491E0(SH2Context& c) {
    ran[1182] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060491E0 mov.l r14,@-r15
    c.r[1] = ld32(0x06049218u);  // 060491E2 mov.l 0x06049218,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060491E4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060491E6 mov r1,r0
    c.r[0] >>= 2;  // 060491E8 shlr2 r0
    c.r[0] >>= 2;  // 060491EA shlr2 r0
    c.r[0] >>= 2;  // 060491EC shlr2 r0
    c.r[0] &= 0x1u;  // 060491EE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060491F0 tst r0,r0
    c.r[1] = ld32(0x0604921Cu);  // 060491F2 mov.l 0x0604921C,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060491FA; } }  // 060491F4 bt/s 0x060491FA ; mov r15,r14
    c.r[1] = ld32(0x06049220u);  // 060491F8 mov.l 0x06049220,r1
L_060491FA:
    c.r[1] += 6;  // 060491FA add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060491FC mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060491FE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049200 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0604920C; } }  // 06049202 bf/s 0x0604920C ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049212u);  // 06049206 mov.w 0x06049212,r0
    goto L_0604920E;  // 06049208 bra 0x0604920E ; nop
L_0604920C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049214u);  // 0604920C mov.w 0x06049214,r0
L_0604920E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604920E rts ; mov.l @r15+,r14
}

void f_06049224(SH2Context& c) {
    ran[1183] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049224 mov.l r14,@-r15
    c.r[1] = ld32(0x06049264u);  // 06049226 mov.l 0x06049264,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049228 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604922A mov r1,r0
    c.r[0] >>= 2;  // 0604922C shlr2 r0
    c.r[0] >>= 2;  // 0604922E shlr2 r0
    c.r[0] >>= 2;  // 06049230 shlr2 r0
    c.r[0] &= 0x1u;  // 06049232 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049234 tst r0,r0
    c.r[1] = ld32(0x06049268u);  // 06049236 mov.l 0x06049268,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604923E; } }  // 06049238 bt/s 0x0604923E ; mov r15,r14
    c.r[1] = ld32(0x0604926Cu);  // 0604923C mov.l 0x0604926C,r1
L_0604923E:
    c.r[1] += 1;  // 0604923E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049240 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06049242 mov r1,r0
    c.r[0] >>= 2;  // 06049244 shlr2 r0
    c.r[0] >>= 2;  // 06049246 shlr2 r0
    c.r[0] >>= 2;  // 06049248 shlr2 r0
    c.r[0] &= 0x1u;  // 0604924A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604924C tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06049258; } }  // 0604924E bf/s 0x06049258 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604925Eu);  // 06049252 mov.w 0x0604925E,r0
    goto L_0604925A;  // 06049254 bra 0x0604925A ; nop
L_06049258:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049260u);  // 06049258 mov.w 0x06049260,r0
L_0604925A:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604925A rts ; mov.l @r15+,r14
}

void f_06049270(SH2Context& c) {
    ran[1184] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06049270 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049272 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049274 sts.l pr,@-r15
    c.r[1] = ld32(0x060492FCu);  // 06049276 mov.l 0x060492FC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049278 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604927A mov r1,r0
    c.r[0] >>= 2;  // 0604927C shlr2 r0
    c.r[0] >>= 2;  // 0604927E shlr2 r0
    c.r[0] >>= 2;  // 06049280 shlr2 r0
    c.r[0] &= 0x1u;  // 06049282 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049284 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060492B4; } }  // 06049286 bt/s 0x060492B4 ; mov r15,r14
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F2u);  // 0604928A mov.w 0x060492F2,r4
    c.r[8] = ld32(0x06049300u);  // 0604928C mov.l 0x06049300,r8
    c.r[7] = 0x10u;  // 0604928E mov #16,r7
    c.r[6] = 0x0u;  // 06049290 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06049296u; c.r[5] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049296u) return; }  // 06049292 jsr @r8 ; mov #58,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F4u);  // 06049296 mov.w 0x060492F4,r4
    c.r[7] = 0x10u;  // 06049298 mov #16,r7
    c.r[6] = 0x0u;  // 0604929A mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060492A0u; c.r[5] = 0x3Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060492A0u) return; }  // 0604929C jsr @r8 ; mov #59,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F6u);  // 060492A0 mov.w 0x060492F6,r4
    c.r[7] = 0x10u;  // 060492A2 mov #16,r7
    c.r[6] = 0x0u;  // 060492A4 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060492AAu; c.r[5] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060492AAu) return; }  // 060492A6 jsr @r8 ; mov #66,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F8u);  // 060492AA mov.w 0x060492F8,r4
    c.r[7] = 0x10u;  // 060492AC mov #16,r7
    c.r[6] = 0x0u;  // 060492AE mov #0,r6
    c.r[5] = 0x43u; goto L_060492DC;  // 060492B0 bra 0x060492DC ; mov #67,r5
L_060492B4:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F2u);  // 060492B4 mov.w 0x060492F2,r4
    c.r[8] = ld32(0x06049300u);  // 060492B6 mov.l 0x06049300,r8
    c.r[7] = 0x10u;  // 060492B8 mov #16,r7
    c.r[6] = 0x0u;  // 060492BA mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060492C0u; c.r[5] = 0x3Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060492C0u) return; }  // 060492BC jsr @r8 ; mov #62,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F4u);  // 060492C0 mov.w 0x060492F4,r4
    c.r[7] = 0x10u;  // 060492C2 mov #16,r7
    c.r[6] = 0x0u;  // 060492C4 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060492CAu; c.r[5] = 0x3Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060492CAu) return; }  // 060492C6 jsr @r8 ; mov #63,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F6u);  // 060492CA mov.w 0x060492F6,r4
    c.r[7] = 0x10u;  // 060492CC mov #16,r7
    c.r[6] = 0x0u;  // 060492CE mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060492D4u; c.r[5] = 0x46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060492D4u) return; }  // 060492D0 jsr @r8 ; mov #70,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060492F8u);  // 060492D4 mov.w 0x060492F8,r4
    c.r[7] = 0x10u;  // 060492D6 mov #16,r7
    c.r[6] = 0x0u;  // 060492D8 mov #0,r6
    c.r[5] = 0x47u;  // 060492DA mov #71,r5
L_060492DC:
    { const uint32_t x = c.r[8]; c.pr = 0x060492E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060492E0u) return; }  // 060492DC jsr @r8 ; nop
    c.r[2] = ld32(0x06049304u);  // 060492E0 mov.l 0x06049304,r2
    c.r[1] = 0x1u;  // 060492E2 mov #1,r1
    st16(c.r[2], c.r[1]);  // 060492E4 mov.w r1,@r2
    c.r[15] = c.r[14];  // 060492E6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060492E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060492EA mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060492FAu);  // 060492EC mov.w 0x060492FA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060492EE rts ; mov.l @r15+,r8
}

void f_06049308(SH2Context& c) {
    ran[1185] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049308 mov.l r14,@-r15
    c.r[1] = ld32(0x06049348u);  // 0604930A mov.l 0x06049348,r1
    c.r[3] = ld32(c.r[1]);  // 0604930C mov.l @r1,r3
    c.r[1] = c.r[3];  // 0604930E mov r3,r1
    c.r[1] += 1;  // 06049310 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049312 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06049314 extu.b r1,r0
    c.r[1] = c.r[3];  // 06049316 mov r3,r1
    c.r[1] += 2;  // 06049318 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604931A mov.b @r1,r2
    c.r[3] += 3;  // 0604931C add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0604931E extu.b r2,r2
    c.r[2] <<= 8;  // 06049320 shll8 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06049322 mov.b @r3,r1
    c.r[0] += c.r[0];  // 06049324 add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06049326 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06049328 or r1,r2
    c.r[1] = ld32(0x0604934Cu);  // 0604932A mov.l 0x0604934C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604932C mov.w @(r0,r1),r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0604932E exts.w r2,r2
    c.t = c.r[1] == c.r[2];  // 06049330 cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604933C; } }  // 06049332 bt/s 0x0604933C ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049344u);  // 06049336 mov.w 0x06049344,r0
    c.r[15] = c.r[14]; goto L_06049340;  // 06049338 bra 0x06049340 ; mov r14,r15
L_0604933C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049346u);  // 0604933C mov.w 0x06049346,r0
    c.r[15] = c.r[14];  // 0604933E mov r14,r15
L_06049340:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049340 rts ; mov.l @r15+,r14
}

void f_06049350(SH2Context& c) {
    ran[1186] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06049350 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06049352 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049354 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049356 sts.l pr,@-r15
    c.r[9] = ld32(0x06049454u);  // 06049358 mov.l 0x06049454,r9
    c.r[0] = ld32(c.r[9]);  // 0604935A mov.l @r9,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604935C tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060493A6; } }  // 0604935E bf/s 0x060493A6 ; mov r15,r14
    c.r[8] = ld32(0x06049458u);  // 06049362 mov.l 0x06049458,r8
    c.r[6] = 0x0u;  // 06049364 mov #0,r6
    c.r[5] = 0x0u;  // 06049366 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604936Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604936Cu) return; }  // 06049368 jsr @r8 ; mov #0,r4
    c.r[6] = 0x0u;  // 0604936C mov #0,r6
    c.r[5] = 0x2u;  // 0604936E mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06049374u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049374u) return; }  // 06049370 jsr @r8 ; mov #0,r4
    c.r[6] = 0x0u;  // 06049374 mov #0,r6
    c.r[5] = 0x8u;  // 06049376 mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604937Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604937Cu) return; }  // 06049378 jsr @r8 ; mov #0,r4
    c.r[6] = 0x0u;  // 0604937C mov #0,r6
    c.r[5] = 0x2u;  // 0604937E mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06049384u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049384u) return; }  // 06049380 jsr @r8 ; mov #1,r4
    c.r[6] = 0x0u;  // 06049384 mov #0,r6
    c.r[5] = 0x3u;  // 06049386 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604938Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604938Cu) return; }  // 06049388 jsr @r8 ; mov #1,r4
    c.r[6] = 0x0u;  // 0604938C mov #0,r6
    c.r[5] = 0x7u;  // 0604938E mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06049394u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049394u) return; }  // 06049390 jsr @r8 ; mov #1,r4
    c.r[5] = ld32(0x0604945Cu);  // 06049394 mov.l 0x0604945C,r5
    c.r[4] = ld32(c.r[9]);  // 06049396 mov.l @r9,r4
    c.r[1] = ld32(0x06049460u);  // 06049398 mov.l 0x06049460,r1
    c.r[4] <<= 16;  // 0604939A shll16 r4
    c.r[4] += c.r[4];  // 0604939C add r4,r4
    c.r[4] += c.r[1];  // 0604939E add r1,r4
    c.r[1] = ld32(0x06049464u);  // 060493A0 mov.l 0x06049464,r1
    goto L_060493BC;  // 060493A2 bra 0x060493BC ; nop
L_060493A6:
    c.r[1] = 0x3u;  // 060493A6 mov #3,r1
    c.t = c.r[0] > c.r[1];  // 060493A8 cmp/hi r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_060493C6; } }  // 060493AA bt/s 0x060493C6 ; cmp/eq #4,r0
    c.r[5] = ld32(0x0604945Cu);  // 060493AE mov.l 0x0604945C,r5
    c.r[0] <<= 16;  // 060493B0 shll16 r0
    c.r[0] += c.r[0];  // 060493B2 add r0,r0
    c.r[1] = ld32(0x06049460u);  // 060493B4 mov.l 0x06049460,r1
    c.r[0] += c.r[1];  // 060493B6 add r1,r0
    c.r[1] = ld32(0x06049464u);  // 060493B8 mov.l 0x06049464,r1
    c.r[4] = c.r[0];  // 060493BA mov r0,r4
L_060493BC:
    { const uint32_t x = c.r[1]; c.pr = 0x060493C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060493C0u) return; }  // 060493BC jsr @r1 ; nop
    c.r[0] = ld32(0x06049468u);  // 060493C0 mov.l 0x06049468,r0
    c.r[15] = c.r[14]; goto L_06049444;  // 060493C2 bra 0x06049444 ; mov r14,r15
L_060493C6:
    if (!c.t) { goto L_060493D2; }  // 060493C6 bf 0x060493D2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0604944Eu);  // 060493C8 mov.w 0x0604944E,r5
    c.r[4] = ld32(0x0604946Cu);  // 060493CA mov.l 0x0604946C,r4
    c.r[1] = ld32(0x06049464u);  // 060493CC mov.l 0x06049464,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060493D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060493D2u) return; }  // 060493CE jsr @r1 ; nop
L_060493D2:
    c.r[1] = ld32(0x06049470u);  // 060493D2 mov.l 0x06049470,r1
    c.r[8] = 0x0u;  // 060493D4 mov #0,r8
    st8(c.r[1], c.r[8]);  // 060493D6 mov.b r8,@r1
    c.r[1] = ld32(0x06049474u);  // 060493D8 mov.l 0x06049474,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060493DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060493DEu) return; }  // 060493DA jsr @r1 ; nop
    c.r[1] = ld32(0x06049478u);  // 060493DE mov.l 0x06049478,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060493E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060493E4u) return; }  // 060493E0 jsr @r1 ; nop
    c.r[2] = ld32(0x0604947Cu);  // 060493E4 mov.l 0x0604947C,r2
    c.r[1] = 0x1u;  // 060493E6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 060493E8 mov.b r1,@r2
    c.r[1] = ld32(0x06049480u);  // 060493EA mov.l 0x06049480,r1
    c.r[2] = 0x0u;  // 060493EC mov #0,r2
    st16(c.r[1], c.r[2]);  // 060493EE mov.w r2,@r1
    c.r[1] = ld32(0x06049484u);  // 060493F0 mov.l 0x06049484,r1
    st16(c.r[1], c.r[2]);  // 060493F2 mov.w r2,@r1
    c.r[1] = ld32(0x06049488u);  // 060493F4 mov.l 0x06049488,r1
    c.r[6] = 0x0u;  // 060493F6 mov #0,r6
    c.r[5] = 0x0u;  // 060493F8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060493FEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060493FEu) return; }  // 060493FA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0604948Cu);  // 060493FE mov.l 0x0604948C,r1
    st8(c.r[1], c.r[8]);  // 06049400 mov.b r8,@r1
    c.r[1] = ld32(0x06049490u);  // 06049402 mov.l 0x06049490,r1
    st8(c.r[1], c.r[8]);  // 06049404 mov.b r8,@r1
    c.r[1] = ld32(0x06049494u);  // 06049406 mov.l 0x06049494,r1
    st8(c.r[1], c.r[8]);  // 06049408 mov.b r8,@r1
    c.r[1] = ld32(0x06049498u);  // 0604940A mov.l 0x06049498,r1
    st8(c.r[1], c.r[8]);  // 0604940C mov.b r8,@r1
    c.r[2] = ld32(0x0604949Cu);  // 0604940E mov.l 0x0604949C,r2
    c.r[1] = 0x0u;  // 06049410 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06049412 mov.l r1,@r2
    c.r[1] = ld32(0x060494A0u);  // 06049414 mov.l 0x060494A0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049416 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06049418 and #239,r0
    st8(c.r[1], c.r[0]);  // 0604941A mov.b r0,@r1
    c.r[1] = ld32(0x060494A4u);  // 0604941C mov.l 0x060494A4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604941E mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06049420 and #127,r0
    st8(c.r[1], c.r[0]);  // 06049422 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049424 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06049426 and #191,r0
    st8(c.r[1], c.r[0]);  // 06049428 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604942A mov.b @r1,r0
    c.r[3] = ld32(0x060494A8u);  // 0604942C mov.l 0x060494A8,r3
    c.r[0] &= 0xDFu;  // 0604942E and #223,r0
    st8(c.r[1], c.r[0]);  // 06049430 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06049432 mov.b @r3,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06049450u);  // 06049434 mov.w 0x06049450,r2
    c.r[0] &= 0x7u;  // 06049436 and #7,r0
    st8(c.r[3], c.r[0]);  // 06049438 mov.b r0,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604943A mov.w @r3,r1
    c.r[0] = ld32(0x060494ACu);  // 0604943C mov.l 0x060494AC,r0
    c.r[1] &= c.r[2];  // 0604943E and r2,r1
    st16(c.r[3], c.r[1]);  // 06049440 mov.w r1,@r3
    c.r[15] = c.r[14];  // 06049442 mov r14,r15
L_06049444:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049444 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06049446 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06049448 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604944A rts ; mov.l @r15+,r8
}

void f_060494B0(SH2Context& c) {
    ran[1187] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060494B0 mov.l r14,@-r15
    c.r[1] = ld32(0x0604950Cu);  // 060494B2 mov.l 0x0604950C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060494B4 mov.b @r1,r1
    c.r[3] = ld32(0x06049510u);  // 060494B6 mov.l 0x06049510,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060494B8 extu.b r1,r1
    c.r[1] >>= 2;  // 060494BA shlr2 r1
    c.r[1] >>= 2;  // 060494BC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060494BE shlr r1
    c.r[1] >>= 2;  // 060494C0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060494C2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060494D2; } }  // 060494C4 bt/s 0x060494D2 ; mov r15,r14
    c.r[2] = ld32(0x06049514u);  // 060494C8 mov.l 0x06049514,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060494CA mov.b @r2,r0
    c.r[1] = 0xFFFFFFFFu;  // 060494CC mov #-1,r1
    c.r[0] |= 0xC0u; goto L_060494DA;  // 060494CE bra 0x060494DA ; or #192,r0
L_060494D2:
    c.r[2] = ld32(0x06049514u);  // 060494D2 mov.l 0x06049514,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060494D4 mov.b @r2,r0
    c.r[1] = 0x0u;  // 060494D6 mov #0,r1
    c.r[0] &= 0x3Fu;  // 060494D8 and #63,r0
L_060494DA:
    st8(c.r[2], c.r[0]);  // 060494DA mov.b r0,@r2
    c.r[2] += 1;  // 060494DC add #1,r2
    st8(c.r[2], c.r[1]);  // 060494DE mov.b r1,@r2
    c.r[2] = ld32(0x06049514u);  // 060494E0 mov.l 0x06049514,r2
    c.r[1] = 0x0u;  // 060494E2 mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 060494E4 mov.l r1,@(12,r2)
    c.r[1] = ld32(0x06049518u);  // 060494E6 mov.l 0x06049518,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060494E8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060494EA mov r1,r0
    c.r[0] >>= 2;  // 060494EC shlr2 r0
    c.r[0] >>= 2;  // 060494EE shlr2 r0
    c.r[0] >>= 2;  // 060494F0 shlr2 r0
    c.r[0] &= 0x1u;  // 060494F2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060494F4 tst r0,r0
    if (c.t) { goto L_060494FC; }  // 060494F6 bt 0x060494FC
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049506u);  // 060494F8 mov.w 0x06049506,r1
    c.r[3] += c.r[1];  // 060494FA add r1,r3
L_060494FC:
    st32(c.r[2] + 4, c.r[3]);  // 060494FC mov.l r3,@(4,r2)
    c.r[15] = c.r[14];  // 060494FE mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049508u);  // 06049500 mov.w 0x06049508,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049502 rts ; mov.l @r15+,r14
}

void f_0604951C(SH2Context& c) {
    ran[1188] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604951C mov.l r14,@-r15
    c.r[1] = ld32(0x06049580u);  // 0604951E mov.l 0x06049580,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049520 mov.b @r1,r1
    c.r[3] = ld32(0x06049584u);  // 06049522 mov.l 0x06049584,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06049524 extu.b r1,r1
    c.r[1] >>= 2;  // 06049526 shlr2 r1
    c.r[1] >>= 2;  // 06049528 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604952A shlr r1
    c.r[1] >>= 2;  // 0604952C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604952E tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604953E; } }  // 06049530 bt/s 0x0604953E ; mov r15,r14
    c.r[2] = ld32(0x06049588u);  // 06049534 mov.l 0x06049588,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06049536 mov.b @r2,r0
    c.r[1] = 0xFFFFFFFFu;  // 06049538 mov #-1,r1
    c.r[0] |= 0xC0u; goto L_06049546;  // 0604953A bra 0x06049546 ; or #192,r0
L_0604953E:
    c.r[2] = ld32(0x06049588u);  // 0604953E mov.l 0x06049588,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06049540 mov.b @r2,r0
    c.r[1] = 0x0u;  // 06049542 mov #0,r1
    c.r[0] &= 0x3Fu;  // 06049544 and #63,r0
L_06049546:
    st8(c.r[2], c.r[0]);  // 06049546 mov.b r0,@r2
    c.r[2] += 1;  // 06049548 add #1,r2
    st8(c.r[2], c.r[1]);  // 0604954A mov.b r1,@r2
    c.r[2] = ld32(0x06049588u);  // 0604954C mov.l 0x06049588,r2
    c.r[1] = 0x0u;  // 0604954E mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 06049550 mov.l r1,@(12,r2)
    c.r[1] = ld32(0x0604958Cu);  // 06049552 mov.l 0x0604958C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049554 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06049556 mov r1,r0
    c.r[0] >>= 2;  // 06049558 shlr2 r0
    c.r[0] >>= 2;  // 0604955A shlr2 r0
    c.r[0] >>= 2;  // 0604955C shlr2 r0
    c.r[0] &= 0x1u;  // 0604955E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049560 tst r0,r0
    if (!c.t) { goto L_0604956A; }  // 06049562 bf 0x0604956A
    c.r[7] = (uint32_t)(int16_t)ld16(0x06049578u);  // 06049564 mov.w 0x06049578,r7
    c.r[3] |= c.r[7]; goto L_0604956E;  // 06049566 bra 0x0604956E ; or r7,r3
L_0604956A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604957Au);  // 0604956A mov.w 0x0604957A,r1
    c.r[3] += c.r[1];  // 0604956C add r1,r3
L_0604956E:
    st32(c.r[2] + 4, c.r[3]);  // 0604956E mov.l r3,@(4,r2)
    c.r[15] = c.r[14];  // 06049570 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604957Cu);  // 06049572 mov.w 0x0604957C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049574 rts ; mov.l @r15+,r14
}

void f_06049590(SH2Context& c) {
    ran[1189] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06049590 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049592 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049594 sts.l pr,@-r15
    c.r[3] = ld32(0x06049610u);  // 06049596 mov.l 0x06049610,r3
    c.r[8] = c.r[3];  // 06049598 mov r3,r8
    c.r[8] += 12;  // 0604959A add #12,r8
    c.r[1] = 0x15u;  // 0604959C mov #21,r1
    st16(c.r[8], c.r[1]);  // 0604959E mov.w r1,@r8
    c.r[1] = c.r[3];  // 060495A0 mov r3,r1
    c.r[1] += 10;  // 060495A2 add #10,r1
    c.r[2] = 0x0u;  // 060495A4 mov #0,r2
    st16(c.r[1], c.r[2]);  // 060495A6 mov.w r2,@r1
    c.r[1] = c.r[3];  // 060495A8 mov r3,r1
    c.r[1] += 16;  // 060495AA add #16,r1
    st16(c.r[1], c.r[2]);  // 060495AC mov.w r2,@r1
    c.r[6] = ld32(0x06049614u);  // 060495AE mov.l 0x06049614,r6
    c.r[7] = ld32(c.r[6]);  // 060495B0 mov.l @r6,r7
    c.r[14] = c.r[15];  // 060495B2 mov r15,r14
    c.r[1] = c.r[7];  // 060495B4 mov r7,r1
    c.r[1] += 1;  // 060495B6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060495B8 mov.b @r1,r2
    c.r[6] += 68;  // 060495BA add #68,r6
    c.r[2] = c.r[2] & 0xFFu;  // 060495BC extu.b r2,r2
    c.r[1] = c.r[7];  // 060495BE mov r7,r1
    c.r[1] += 2;  // 060495C0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060495C2 mov.b @r1,r1
    c.r[2] <<= 8;  // 060495C4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060495C6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060495C8 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060495CA exts.w r2,r2
    c.r[2] += c.r[7];  // 060495CC add r7,r2
    c.r[2] += 1;  // 060495CE add #1,r2
    st32(c.r[3] + 4, c.r[2]);  // 060495D0 mov.l r2,@(4,r3)
    c.r[2] = c.r[3];  // 060495D2 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060495D4 mov.b @r6,r1
    c.r[2] += 8;  // 060495D6 add #8,r2
    st8(c.r[2], c.r[1]);  // 060495D8 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060495DA mov.b @r3,r0
    c.r[4] = ld32(0x06049618u);  // 060495DC mov.l 0x06049618,r4
    c.r[0] &= 0xF7u;  // 060495DE and #247,r0
    st8(c.r[3], c.r[0]);  // 060495E0 mov.b r0,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060495E2 mov.b @r3,r0
    c.r[5] = 0x28u;  // 060495E4 mov #40,r5
    c.r[0] |= 0x10u;  // 060495E6 or #16,r0
    st8(c.r[3], c.r[0]);  // 060495E8 mov.b r0,@r3
    c.r[0] = ld32(0x0604961Cu);  // 060495EA mov.l 0x0604961C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060495F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060495F0u) return; }  // 060495EC jsr @r0 ; nop
    c.r[2] = c.r[0];  // 060495F0 mov r0,r2
    c.r[1] = ld32(0x06049620u);  // 060495F2 mov.l 0x06049620,r1
    c.r[0] = ld32(0x06049624u);  // 060495F4 mov.l 0x06049624,r0
    c.r[6] = 0x2u;  // 060495F6 mov #2,r6
    c.r[5] = c.r[2];  // 060495F8 mov r2,r5
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060495FA mov.w @r8,r7
    c.r[4] = 0x13u;  // 060495FC mov #19,r4
    c.r[7] = c.r[7] & 0xFFFFu;  // 060495FE extu.w r7,r7
    { const uint32_t x = c.r[0]; c.pr = 0x06049604u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049604u) return; }  // 06049600 jsr @r0 ; mov.l r1,@-r15
    c.r[15] = c.r[14];  // 06049604 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049606 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06049608 mov.l @r15+,r14
    c.r[0] = ld32(0x06049628u);  // 0604960A mov.l 0x06049628,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604960C rts ; mov.l @r15+,r8
}

void f_0604962C(SH2Context& c) {
    ran[1190] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604962C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604962E sts.l pr,@-r15
    c.r[1] = ld32(0x06049688u);  // 06049630 mov.l 0x06049688,r1
    c.r[0] = ld32(c.r[1]);  // 06049632 mov.l @r1,r0
    c.r[1] = 0x3u;  // 06049634 mov #3,r1
    c.t = c.r[0] > c.r[1];  // 06049636 cmp/hi r1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604964C; } }  // 06049638 bt/s 0x0604964C ; mov r15,r14
    c.r[5] = ld32(0x0604968Cu);  // 0604963C mov.l 0x0604968C,r5
    c.r[0] <<= 16;  // 0604963E shll16 r0
    c.r[0] += c.r[0];  // 06049640 add r0,r0
    c.r[1] = ld32(0x06049690u);  // 06049642 mov.l 0x06049690,r1
    c.r[0] += c.r[1];  // 06049644 add r1,r0
    c.r[1] = ld32(0x06049694u);  // 06049646 mov.l 0x06049694,r1
    c.r[4] = c.r[0]; goto L_06049656;  // 06049648 bra 0x06049656 ; mov r0,r4
L_0604964C:
    c.t = c.r[0] == 0x4u;  // 0604964C cmp/eq #4,r0
    if (!c.t) { goto L_06049660; }  // 0604964E bf 0x06049660
    c.r[5] = (uint32_t)(int16_t)ld16(0x06049680u);  // 06049650 mov.w 0x06049680,r5
    c.r[4] = ld32(0x06049698u);  // 06049652 mov.l 0x06049698,r4
    c.r[1] = ld32(0x06049694u);  // 06049654 mov.l 0x06049694,r1
L_06049656:
    { const uint32_t x = c.r[1]; c.pr = 0x0604965Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604965Au) return; }  // 06049656 jsr @r1 ; nop
    c.r[0] = ld32(0x0604969Cu);  // 0604965A mov.l 0x0604969C,r0
    c.r[15] = c.r[14]; goto L_0604967A;  // 0604965C bra 0x0604967A ; mov r14,r15
L_06049660:
    c.r[1] = ld32(0x060496A0u);  // 06049660 mov.l 0x060496A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049662 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06049664 mov r1,r0
    c.r[0] >>= 2;  // 06049666 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06049668 shlr r0
    c.r[0] &= 0x1u;  // 0604966A and #1,r0
    c.t = c.r[0] == 0x1u;  // 0604966C cmp/eq #1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06049678; } }  // 0604966E bt/s 0x06049678 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049682u);  // 06049672 mov.w 0x06049682,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0604967C;  // 06049674 bra 0x0604967C ; lds.l @r15+,pr
L_06049678:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049684u);  // 06049678 mov.w 0x06049684,r0
L_0604967A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604967A lds.l @r15+,pr
L_0604967C:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604967C rts ; mov.l @r15+,r14
}

void f_060496DC(SH2Context& c) {
    ran[1191] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060496DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060496DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060496E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060496E2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060496E4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060496E6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060496E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060496EA sts.l pr,@-r15
    c.r[15] -= 56;  // 060496EC add #-56,r15
    c.r[14] = c.r[15];  // 060496EE mov r15,r14
    c.r[5] = ld32(0x0604986Cu);  // 060496F0 mov.l 0x0604986C,r5
    c.r[1] = ld32(0x06049870u);  // 060496F2 mov.l 0x06049870,r1
    c.r[6] = 0x38u;  // 060496F4 mov #56,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060496FAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060496FAu) return; }  // 060496F6 jsr @r1 ; mov r14,r4
    c.r[3] = ld32(0x06049874u);  // 060496FA mov.l 0x06049874,r3
    c.r[8] = ld32(0x06049878u);  // 060496FC mov.l 0x06049878,r8
    c.r[2] = c.r[8];  // 060496FE mov r8,r2
    c.r[2] += 10;  // 06049700 add #10,r2
    c.r[8] += 16;  // 06049702 add #16,r8
    c.r[13] = ld32(0x0604987Cu);  // 06049704 mov.l 0x0604987C,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06049706 mov.w @r8,r1
    c.r[11] = ld32(0x06049880u);  // 06049708 mov.l 0x06049880,r11
    c.r[0] = c.r[1] & 0xFFFFu;  // 0604970A extu.w r1,r0
    c.r[0] += c.r[0];  // 0604970C add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0604970E mov.b @(r0,r14),r1
    c.r[5] = 0x28u;  // 06049710 mov #40,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06049712 extu.b r1,r1
    st16(c.r[2], c.r[1]);  // 06049714 mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06049716 mov.w @r2,r1
    c.r[4] = c.r[13];  // 06049718 mov r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0604971Eu; st16(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604971Eu) return; }  // 0604971A jsr @r11 ; mov.w r1,@r3
    c.r[10] = c.r[0];  // 0604971E mov r0,r10
    c.r[1] = ld32(0x06049884u);  // 06049720 mov.l 0x06049884,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06049722 mov.l r1,@-r15
    c.r[9] = ld32(0x06049888u);  // 06049724 mov.l 0x06049888,r9
    c.r[7] = 0x16u;  // 06049726 mov #22,r7
    c.r[6] = 0x2u;  // 06049728 mov #2,r6
    c.r[5] = c.r[10];  // 0604972A mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06049730u; c.r[4] = 0x13u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049730u) return; }  // 0604972C jsr @r9 ; mov #19,r4
    c.r[6] = 0x2u;  // 06049730 mov #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06049732 mov.w @r8,r1
    c.r[5] = c.r[10];  // 06049734 mov r10,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 06049736 extu.w r1,r1
    c.r[1] += c.r[1];  // 06049738 add r1,r1
    c.r[1] += c.r[14];  // 0604973A add r14,r1
    c.r[1] += 1;  // 0604973C add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604973E mov.b @r1,r7
    c.r[4] = 0x13u;  // 06049740 mov #19,r4
    c.r[7] = c.r[7] & 0xFFu;  // 06049742 extu.b r7,r7
    c.r[1] = ld32(0x0604988Cu);  // 06049744 mov.l 0x0604988C,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0604974Au; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604974Au) return; }  // 06049746 jsr @r9 ; mov.l r1,@-r15
    c.r[9] = ld32(0x06049890u);  // 0604974A mov.l 0x06049890,r9
    c.r[12] = c.r[9];  // 0604974C mov r9,r12
    c.r[12] += 6;  // 0604974E add #6,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06049750 mov.w @r8,r1
    c.r[15] += 8;  // 06049752 add #8,r15
    c.r[1] += 1;  // 06049754 add #1,r1
    st16(c.r[8], c.r[1]);  // 06049756 mov.w r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06049758 mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06049864u);  // 0604975A mov.w 0x06049864,r2
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0604975C mov.w @r12,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049866u);  // 0604975E mov.w 0x06049866,r1
    c.r[1] &= c.r[8];  // 06049760 and r8,r1
    c.t = c.r[1] == c.r[2];  // 06049762 cmp/eq r2,r1
    if (!c.t) { goto L_0604976C; }  // 06049764 bf 0x0604976C
    c.r[9] += 8;  // 06049766 add #8,r9
    st16(c.r[9], c.r[8]); goto L_060497A2;  // 06049768 bra 0x060497A2 ; mov.w r8,@r9
L_0604976C:
    c.r[8] = c.r[8] & 0xFFFFu;  // 0604976C extu.w r8,r8
    c.r[5] = 0x1Cu;  // 0604976E mov #28,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06049774u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049774u) return; }  // 06049770 jsr @r11 ; mov r13,r4
    c.r[5] = c.r[8];  // 06049774 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0604977Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604977Au) return; }  // 06049776 jsr @r11 ; mov r0,r4
    c.r[10] = c.r[0];  // 0604977A mov r0,r10
    c.r[5] = 0x1Cu;  // 0604977C mov #28,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0604977E mov.w @r12,r8
    c.r[4] = c.r[13];  // 06049780 mov r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06049786u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049786u) return; }  // 06049782 jsr @r11 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06049786 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0604978Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604978Cu) return; }  // 06049788 jsr @r11 ; mov r0,r4
    c.r[9] += 8;  // 0604978C add #8,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0604978E mov.b @r10,r2
    c.r[0] += 1;  // 06049790 add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06049792 mov.b @r0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06049794 extu.b r2,r2
    c.r[2] <<= 8;  // 06049796 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06049798 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604979A or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049868u);  // 0604979C mov.w 0x06049868,r1
    c.r[2] &= c.r[1];  // 0604979E and r1,r2
    st16(c.r[9], c.r[2]);  // 060497A0 mov.w r2,@r9
L_060497A2:
    c.r[1] = ld32(0x06049894u);  // 060497A2 mov.l 0x06049894,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060497A4 mov.w @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049866u);  // 060497A6 mov.w 0x06049866,r1
    c.r[1] &= c.r[2];  // 060497A8 and r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06049864u);  // 060497AA mov.w 0x06049864,r2
    c.t = c.r[1] == c.r[2];  // 060497AC cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] = 0x1Cu; if (k) { goto L_060497C0; } }  // 060497AE bf/s 0x060497C0 ; mov #28,r5
    c.r[1] = ld32(0x06049898u);  // 060497B2 mov.l 0x06049898,r1
    c.r[2] = c.r[1];  // 060497B4 mov r1,r2
    c.r[1] += 6;  // 060497B6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060497B8 mov.w @r1,r1
    c.r[2] += 8;  // 060497BA add #8,r2
    st16(c.r[2], c.r[1]); goto L_06049800;  // 060497BC bra 0x06049800 ; mov.w r1,@r2
L_060497C0:
    c.r[12] = ld32(0x06049898u);  // 060497C0 mov.l 0x06049898,r12
    c.r[10] = c.r[12];  // 060497C2 mov r12,r10
    c.r[10] += 6;  // 060497C4 add #6,r10
    c.r[11] = ld32(0x0604987Cu);  // 060497C6 mov.l 0x0604987C,r11
    c.r[9] = ld32(0x06049880u);  // 060497C8 mov.l 0x06049880,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060497CA mov.w @r10,r8
    c.r[4] = c.r[11];  // 060497CC mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060497D2u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060497D2u) return; }  // 060497CE jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 060497D2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060497D8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060497D8u) return; }  // 060497D4 jsr @r9 ; mov r0,r4
    c.r[13] = c.r[0];  // 060497D8 mov r0,r13
    c.r[5] = 0x1Cu;  // 060497DA mov #28,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[10]);  // 060497DC mov.w @r10,r8
    c.r[4] = c.r[11];  // 060497DE mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060497E4u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060497E4u) return; }  // 060497E0 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 060497E4 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060497EAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060497EAu) return; }  // 060497E6 jsr @r9 ; mov r0,r4
    c.r[12] += 8;  // 060497EA add #8,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060497EC mov.b @r13,r2
    c.r[0] += 1;  // 060497EE add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060497F0 mov.b @r0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060497F2 extu.b r2,r2
    c.r[2] <<= 8;  // 060497F4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060497F6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060497F8 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049868u);  // 060497FA mov.w 0x06049868,r1
    c.r[2] &= c.r[1];  // 060497FC and r1,r2
    st16(c.r[12], c.r[2]);  // 060497FE mov.w r2,@r12
L_06049800:
    c.r[10] = ld32(0x06049890u);  // 06049800 mov.l 0x06049890,r10
    c.r[1] = c.r[10];  // 06049802 mov r10,r1
    c.r[1] += 2;  // 06049804 add #2,r1
    c.r[11] = ld32(0x0604987Cu);  // 06049806 mov.l 0x0604987C,r11
    c.r[9] = ld32(0x06049880u);  // 06049808 mov.l 0x06049880,r9
    c.r[5] = 0x1Du;  // 0604980A mov #29,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604980C mov.w @r1,r8
    c.r[4] = c.r[11];  // 0604980E mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06049814u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049814u) return; }  // 06049810 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06049814 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604981Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604981Au) return; }  // 06049816 jsr @r9 ; mov r0,r4
    c.r[10] += 28;  // 0604981A add #28,r10
    c.r[0] += 2;  // 0604981C add #2,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604981E mov.b @r0,r0
    c.r[5] = 0x1Du;  // 06049820 mov #29,r5
    c.r[0] &= 0x3Fu;  // 06049822 and #63,r0
    st8(c.r[10], c.r[0]);  // 06049824 mov.b r0,@r10
    c.r[10] = ld32(0x06049898u);  // 06049826 mov.l 0x06049898,r10
    c.r[1] = c.r[10];  // 06049828 mov r10,r1
    c.r[1] += 2;  // 0604982A add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604982C mov.w @r1,r8
    c.r[4] = c.r[11];  // 0604982E mov r11,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06049834u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049834u) return; }  // 06049830 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06049834 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604983Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604983Au) return; }  // 06049836 jsr @r9 ; mov r0,r4
    c.r[10] += 28;  // 0604983A add #28,r10
    c.r[0] += 2;  // 0604983C add #2,r0
    c.r[1] = ld32(0x06049878u);  // 0604983E mov.l 0x06049878,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06049840 mov.b @r0,r0
    c.r[14] += 56;  // 06049842 add #56,r14
    c.r[0] &= 0x3Fu;  // 06049844 and #63,r0
    st8(c.r[10], c.r[0]);  // 06049846 mov.b r0,@r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049848 mov.b @r1,r0
    c.r[15] = c.r[14];  // 0604984A mov r14,r15
    c.r[0] |= 0x20u;  // 0604984C or #32,r0
    st8(c.r[1], c.r[0]);  // 0604984E mov.b r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049850 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06049852 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06049854 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06049856 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06049858 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604985A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604985C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604986Au);  // 0604985E mov.w 0x0604986A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049860 rts ; mov.l @r15+,r8
}

void f_0604989C(SH2Context& c) {
    ran[1192] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604989C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604989E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060498A0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060498A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060498A4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060498A6 mov r15,r14
    c.r[7] = ld32(0x060498E4u);  // 060498A8 mov.l 0x060498E4,r7
    c.r[8] = ld32(0x060498E8u);  // 060498AA mov.l 0x060498E8,r8
    c.r[9] = 0x1u;  // 060498AC mov #1,r9
    c.r[10] = ld32(0x060498ECu);  // 060498AE mov.l 0x060498EC,r10
    c.r[5] = 0x4u;  // 060498B0 mov #4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]); c.r[8] += 2;  // 060498B2 mov.w @r8+,r6
    c.r[4] = 0x0u;  // 060498B4 mov #0,r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 060498B6 extu.w r6,r6
    { const uint32_t x = c.r[10]; c.pr = 0x060498BCu; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060498BCu) return; }  // 060498B8 jsr @r10 ; mov.l r9,@-r15
    c.r[7] = ld32(0x060498F0u);  // 060498BC mov.l 0x060498F0,r7
    c.r[5] = 0x4u;  // 060498BE mov #4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060498C0 mov.w @r8,r6
    c.r[4] = c.r[9];  // 060498C2 mov r9,r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 060498C4 extu.w r6,r6
    { const uint32_t x = c.r[10]; c.pr = 0x060498CAu; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060498CAu) return; }  // 060498C6 jsr @r10 ; mov.l r9,@-r15
    c.r[1] = ld32(0x060498F4u);  // 060498CA mov.l 0x060498F4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060498CC mov.w @r1,r0
    c.r[15] = c.r[14];  // 060498CE mov r14,r15
    c.r[0] |= 0x4u;  // 060498D0 or #4,r0
    st16(c.r[1], c.r[0]);  // 060498D2 mov.w r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060498D4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060498D6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060498D8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060498DA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060498E2u);  // 060498DC mov.w 0x060498E2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060498DE rts ; mov.l @r15+,r8
}

void f_060498F8(SH2Context& c) {
    ran[1193] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060498F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060498FA sts.l pr,@-r15
    c.r[1] = ld32(0x06049914u);  // 060498FC mov.l 0x06049914,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049902u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049902u) return; }  // 060498FE jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06049918u);  // 06049902 mov.l 0x06049918,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049908u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049908u) return; }  // 06049904 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06049908 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604990A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049912u);  // 0604990C mov.w 0x06049912,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604990E rts ; mov.l @r15+,r14
}

void f_0604991C(SH2Context& c) {
    ran[1194] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604991C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0604991E mov r15,r14
    c.r[1] = ld32(0x06049930u);  // 06049920 mov.l 0x06049930,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049922 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06049924 and #239,r0
    st8(c.r[1], c.r[0]);  // 06049926 mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604992Eu);  // 06049928 mov.w 0x0604992E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604992A rts ; mov.l @r15+,r14
}

void f_06049934(SH2Context& c) {
    ran[1195] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049934 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06049936 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604993Eu);  // 06049938 mov.w 0x0604993E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604993A rts ; mov.l @r15+,r14
}

void f_06049940(SH2Context& c) {
    ran[1196] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049940 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049942 sts.l pr,@-r15
    c.r[1] = ld32(0x06049960u);  // 06049944 mov.l 0x06049960,r1
    c.r[1] = ld32(c.r[1]);  // 06049946 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049948 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604994A extu.b r1,r0
    c.r[0] <<= 2;  // 0604994C shll2 r0
    c.r[1] = ld32(0x06049964u);  // 0604994E mov.l 0x06049964,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06049950 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049956u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049956u) return; }  // 06049952 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06049956 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049958 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604995A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0604995C rts ; extu.w r0,r0
}

void f_06049968(SH2Context& c) {
    ran[1197] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049968 mov.l r14,@-r15
    c.r[1] = ld32(0x06049990u);  // 0604996A mov.l 0x06049990,r1
    c.r[2] = ld32(c.r[1]);  // 0604996C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604998Eu);  // 0604996E mov.w 0x0604998E,r1
    c.r[0] = c.r[2];  // 06049970 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06049972 mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 06049974 mov #4,r0
    c.r[1] &= c.r[0];  // 06049976 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049978 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06049986; } }  // 0604997A bt/s 0x06049986 ; mov r15,r14
    c.r[1] = ld32(0x06049994u);  // 0604997E mov.l 0x06049994,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049980 mov.b @r1,r0
    c.r[0] |= 0x28u;  // 06049982 or #40,r0
    st8(c.r[1], c.r[0]);  // 06049984 mov.b r0,@r1
L_06049986:
    c.r[15] = c.r[14];  // 06049986 mov r14,r15
    c.r[0] = ld32(0x06049998u);  // 06049988 mov.l 0x06049998,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604998A rts ; mov.l @r15+,r14
}

void f_0604999C(SH2Context& c) {
    ran[1198] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604999C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604999E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060499A0 sts.l pr,@-r15
    c.r[2] = ld32(0x06049AC8u);  // 060499A2 mov.l 0x06049AC8,r2
    c.r[1] = c.r[2];  // 060499A4 mov r2,r1
    c.r[1] += 72;  // 060499A6 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 060499A8 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060499AA tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060499C6; } }  // 060499AC bt/s 0x060499C6 ; mov r15,r14
    c.r[3] = ld32(0x06049ACCu);  // 060499B0 mov.l 0x06049ACC,r3
    c.r[2] = ld32(c.r[3]);  // 060499B2 mov.l @r3,r2
    c.r[1] = ld32(0x06049AD0u);  // 060499B4 mov.l 0x06049AD0,r1
    c.r[1] &= c.r[2];  // 060499B6 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060499B8 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06049AB2; } }  // 060499BA bt/s 0x06049AB2 ; mov #0,r0
    c.r[1] = ld32(0x06049AD4u);  // 060499BE mov.l 0x06049AD4,r1
    c.r[2] &= c.r[1];  // 060499C0 and r1,r2
    st32(c.r[3], c.r[2]); goto L_06049AB0;  // 060499C2 bra 0x06049AB0 ; mov.l r2,@r3
L_060499C6:
    c.r[3] = ld32(c.r[2]);  // 060499C6 mov.l @r2,r3
    c.r[1] = c.r[3];  // 060499C8 mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060499CA mov.b @r1+,r2
    c.r[7] = ld32(0x06049AD8u);  // 060499CC mov.l 0x06049AD8,r7
    c.r[2] = c.r[2] & 0xFFu;  // 060499CE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060499D0 mov.b @r1,r1
    c.r[2] <<= 8;  // 060499D2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060499D4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060499D6 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060499D8 exts.w r2,r2
    st32(c.r[7], c.r[2]);  // 060499DA mov.l r2,@r7
    c.r[1] = ld32(0x06049ADCu);  // 060499DC mov.l 0x06049ADC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060499DE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060499E0 extu.b r1,r1
    c.r[0] = c.r[1];  // 060499E2 mov r1,r0
    c.r[0] >>= 2;  // 060499E4 shlr2 r0
    c.r[0] >>= 2;  // 060499E6 shlr2 r0
    c.r[0] >>= 2;  // 060499E8 shlr2 r0
    c.r[1] >>= 2;  // 060499EA shlr2 r1
    c.r[1] >>= 2;  // 060499EC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060499EE shlr r1
    c.r[1] >>= 2;  // 060499F0 shlr2 r1
    c.r[0] &= 0x1u;  // 060499F2 and #1,r0
    c.t = c.r[1] == c.r[0];  // 060499F4 cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = 0u - c.r[2]; if (k) { goto L_060499FC; } }  // 060499F6 bt/s 0x060499FC ; neg r2,r1
    st32(c.r[7], c.r[1]);  // 060499FA mov.l r1,@r7
L_060499FC:
    c.r[2] = ld32(c.r[7]);  // 060499FC mov.l @r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049ABCu);  // 060499FE mov.w 0x06049ABC,r1
    c.r[2] += c.r[1];  // 06049A00 add r1,r2
    st32(c.r[7], c.r[2]);  // 06049A02 mov.l r2,@r7
    c.r[1] = c.r[3];  // 06049A04 mov r3,r1
    c.r[1] += 2;  // 06049A06 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049A08 mov.b @r1,r2
    c.r[6] = ld32(0x06049AE0u);  // 06049A0A mov.l 0x06049AE0,r6
    c.r[2] = c.r[2] & 0xFFu;  // 06049A0C extu.b r2,r2
    c.r[1] = c.r[3];  // 06049A0E mov r3,r1
    c.r[1] += 3;  // 06049A10 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049A12 mov.b @r1,r1
    c.r[2] <<= 8;  // 06049A14 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06049A16 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06049A18 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06049A1A exts.w r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049ABEu);  // 06049A1C mov.w 0x06049ABE,r1
    c.r[2] += c.r[1];  // 06049A1E add r1,r2
    st32(c.r[6], c.r[2]);  // 06049A20 mov.l r2,@r6
    c.r[1] = ld32(0x06049AE4u);  // 06049A22 mov.l 0x06049AE4,r1
    c.r[2] = ld32(c.r[1]);  // 06049A24 mov.l @r1,r2
    c.r[3] += 4;  // 06049A26 add #4,r3
    c.r[4] = c.r[2];  // 06049A28 mov r2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06049A2A mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06049A2C extu.b r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049AC0u);  // 06049A2E mov.w 0x06049AC0,r1
    c.r[1] &= c.r[0];  // 06049A30 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049A32 tst r1,r1
    { const bool k = c.t; c.r[4] += 76; if (k) { goto L_06049A64; } }  // 06049A34 bt/s 0x06049A64 ; add #76,r4
    c.r[1] = 0x1u;  // 06049A38 mov #1,r1
    c.r[1] &= c.r[0];  // 06049A3A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049A3C tst r1,r1
    { const bool k = c.t; c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[0]; if (k) { goto L_06049A46; } }  // 06049A3E bt/s 0x06049A46 ; exts.b r0,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06049AC2u);  // 06049A42 mov.w 0x06049AC2,r4
    c.r[4] += c.r[2];  // 06049A44 add r2,r4
L_06049A46:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06049A46 shar r1
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06049A48 exts.b r1,r0
    c.r[0] ^= 0x1u;  // 06049A4A xor #1,r0
    c.r[0] &= 0x1u;  // 06049A4C and #1,r0
    c.r[1] = c.r[4];  // 06049A4E mov r4,r1
    c.r[1] += 1;  // 06049A50 add #1,r1
    c.r[0] <<= 2;  // 06049A52 shll2 r0
    c.r[0] <<= 2;  // 06049A54 shll2 r0
    c.r[0] <<= 2;  // 06049A56 shll2 r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049A58 mov.b @r1,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x06049AC4u);  // 06049A5A mov.w 0x06049AC4,r8
    c.r[2] &= c.r[8];  // 06049A5C and r8,r2
    c.r[2] |= c.r[0];  // 06049A5E or r0,r2
    st8(c.r[1], c.r[2]); goto L_06049A9E;  // 06049A60 bra 0x06049A9E ; mov.b r2,@r1
L_06049A64:
    c.r[1] = 0x40u;  // 06049A64 mov #64,r1
    c.r[1] &= c.r[0];  // 06049A66 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049A68 tst r1,r1
    if (c.t) { goto L_06049A70; }  // 06049A6A bt 0x06049A70
    c.r[4] = (uint32_t)(int16_t)ld16(0x06049AC2u);  // 06049A6C mov.w 0x06049AC2,r4
    c.r[4] += c.r[2];  // 06049A6E add r2,r4
L_06049A70:
    c.r[1] = ld32(0x06049AE8u);  // 06049A70 mov.l 0x06049AE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049A72 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06049A74 extu.b r1,r1
    c.r[1] >>= 2;  // 06049A76 shlr2 r1
    c.r[1] >>= 2;  // 06049A78 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06049A7A shlr r1
    c.r[1] >>= 2;  // 06049A7C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049A7E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_06049A96; } }  // 06049A80 bt/s 0x06049A96 ; mov r4,r1
    c.r[1] = ld32(0x06049AECu);  // 06049A84 mov.l 0x06049AEC,r1
    c.r[0] &= 0x3Fu;  // 06049A86 and #63,r0
    st32(c.r[1], c.r[0]);  // 06049A88 mov.l r0,@r1
    c.r[5] = ld32(0x06049AF0u);  // 06049A8A mov.l 0x06049AF0,r5
    c.r[1] = ld32(0x06049AF4u);  // 06049A8C mov.l 0x06049AF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049A92u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049A92u) return; }  // 06049A8E jsr @r1 ; nop
    goto L_06049AB0;  // 06049A92 bra 0x06049AB0 ; nop
L_06049A96:
    c.r[1] += 1;  // 06049A96 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049A98 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 06049A9A or #64,r0
    st8(c.r[1], c.r[0]);  // 06049A9C mov.b r0,@r1
L_06049A9E:
    c.r[1] = ld32(c.r[7]);  // 06049A9E mov.l @r7,r1
    st32(c.r[4] + 4, c.r[1]);  // 06049AA0 mov.l r1,@(4,r4)
    c.r[1] = ld32(c.r[6]);  // 06049AA2 mov.l @r6,r1
    c.r[2] = ld32(0x06049ACCu);  // 06049AA4 mov.l 0x06049ACC,r2
    st32(c.r[4] + 8, c.r[1]);  // 06049AA6 mov.l r1,@(8,r4)
    c.r[3] = ld32(c.r[2]);  // 06049AA8 mov.l @r2,r3
    c.r[1] = ld32(0x06049AD0u);  // 06049AAA mov.l 0x06049AD0,r1
    c.r[3] |= c.r[1];  // 06049AAC or r1,r3
    st32(c.r[2], c.r[3]);  // 06049AAE mov.l r3,@r2
L_06049AB0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049AC6u);  // 06049AB0 mov.w 0x06049AC6,r0
L_06049AB2:
    c.r[15] = c.r[14];  // 06049AB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049AB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06049AB6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049AB8 rts ; mov.l @r15+,r8
}

void f_06049AF8(SH2Context& c) {
    ran[1199] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049AF8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049AFA sts.l pr,@-r15
    c.r[1] = ld32(0x06049B64u);  // 06049AFC mov.l 0x06049B64,r1
    c.r[1] = ld32(c.r[1]);  // 06049AFE mov.l @r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049B00 mov.b @r1,r3
    c.r[7] = ld32(0x06049B68u);  // 06049B02 mov.l 0x06049B68,r7
    c.r[6] = c.r[3];  // 06049B04 mov r3,r6
    c.r[6] <<= 8;  // 06049B06 shll8 r6
    st32(c.r[7] + 12, c.r[6]);  // 06049B08 mov.l r6,@(12,r7)
    st32(c.r[7] + 16, c.r[3]);  // 06049B0A mov.l r3,@(16,r7)
    c.r[1] = c.r[7];  // 06049B0C mov r7,r1
    c.r[1] += 1;  // 06049B0E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049B10 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06049B12 extu.b r2,r2
    c.r[1] = ld32(0x06049B6Cu);  // 06049B14 mov.l 0x06049B6C,r1
    c.r[1] = ld32(c.r[1]);  // 06049B16 mov.l @r1,r1
    c.r[2] += c.r[2];  // 06049B18 add r2,r2
    c.r[2] += c.r[1];  // 06049B1A add r1,r2
    c.r[2] += 1;  // 06049B1C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06049B1E mov.b @r2,r1
    c.macl = c.r[3] * c.r[1];  // 06049B20 mul.l r1,r3
    c.r[14] = c.r[15];  // 06049B22 mov r15,r14
    c.r[5] = c.macl;  // 06049B24 sts macl,r5
    c.r[1] = c.macl;  // 06049B26 sts macl,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06049B28 cmp/pz r1
    { const bool k = c.t; st32(c.r[7] + 16, c.r[5]); if (k) { goto L_06049B32; } }  // 06049B2A bt/s 0x06049B32 ; mov.l r5,@(16,r7)
    c.r[1] = 0u - c.r[1];  // 06049B2E neg r1,r1
    st32(c.r[7] + 16, c.r[1]);  // 06049B30 mov.l r1,@(16,r7)
L_06049B32:
    c.r[1] = ld32(0x06049B70u);  // 06049B32 mov.l 0x06049B70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049B34 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06049B36 extu.b r1,r1
    c.r[0] = c.r[1];  // 06049B38 mov r1,r0
    c.r[0] >>= 2;  // 06049B3A shlr2 r0
    c.r[0] >>= 2;  // 06049B3C shlr2 r0
    c.r[0] >>= 2;  // 06049B3E shlr2 r0
    c.r[1] >>= 2;  // 06049B40 shlr2 r1
    c.r[1] >>= 2;  // 06049B42 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06049B44 shlr r1
    c.r[1] >>= 2;  // 06049B46 shlr2 r1
    c.r[0] &= 0x1u;  // 06049B48 and #1,r0
    c.t = c.r[1] == c.r[0];  // 06049B4A cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = 0u - c.r[6]; if (k) { goto L_06049B52; } }  // 06049B4C bt/s 0x06049B52 ; neg r6,r1
    st32(c.r[7] + 12, c.r[1]);  // 06049B50 mov.l r1,@(12,r7)
L_06049B52:
    c.r[1] = ld32(0x06049B74u);  // 06049B52 mov.l 0x06049B74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049B58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049B58u) return; }  // 06049B54 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06049B58 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049B5A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049B62u);  // 06049B5C mov.w 0x06049B62,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049B5E rts ; mov.l @r15+,r14
}

void f_06049B78(SH2Context& c) {
    ran[1200] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049B78 mov.l r14,@-r15
    c.r[1] = ld32(0x06049BB8u);  // 06049B7A mov.l 0x06049BB8,r1
    c.r[7] = ld32(c.r[1]);  // 06049B7C mov.l @r1,r7
    c.r[3] = ld32(0x06049BBCu);  // 06049B7E mov.l 0x06049BBC,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06049B80 mov.b @r7,r2
    c.r[1] = ld32(0x06049BC0u);  // 06049B82 mov.l 0x06049BC0,r1
    st32(c.r[3] + 12, c.r[2]);  // 06049B84 mov.l r2,@(12,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049B86 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06049B88 extu.b r1,r1
    c.r[0] = c.r[1];  // 06049B8A mov r1,r0
    c.r[0] >>= 2;  // 06049B8C shlr2 r0
    c.r[0] >>= 2;  // 06049B8E shlr2 r0
    c.r[0] >>= 2;  // 06049B90 shlr2 r0
    c.r[1] >>= 2;  // 06049B92 shlr2 r1
    c.r[1] >>= 2;  // 06049B94 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06049B96 shlr r1
    c.r[1] >>= 2;  // 06049B98 shlr2 r1
    c.r[0] &= 0x1u;  // 06049B9A and #1,r0
    c.t = c.r[1] == c.r[0];  // 06049B9C cmp/eq r0,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06049BA6; } }  // 06049B9E bt/s 0x06049BA6 ; mov r15,r14
    c.r[1] = 0u - c.r[2];  // 06049BA2 neg r2,r1
    st32(c.r[3] + 12, c.r[1]);  // 06049BA4 mov.l r1,@(12,r3)
L_06049BA6:
    c.r[7] += 1;  // 06049BA6 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06049BA8 mov.b @r7,r1
    c.r[15] = c.r[14];  // 06049BAA mov r14,r15
    st32(c.r[3] + 16, c.r[1]);  // 06049BAC mov.l r1,@(16,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049BB4u);  // 06049BAE mov.w 0x06049BB4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049BB0 rts ; mov.l @r15+,r14
}

void f_06049BC4(SH2Context& c) {
    ran[1201] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06049BC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06049BC6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049BC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049BCA sts.l pr,@-r15
    c.r[1] = ld32(0x06049C84u);  // 06049BCC mov.l 0x06049C84,r1
    c.r[3] = ld32(c.r[1]);  // 06049BCE mov.l @r1,r3
    c.r[15] -= 4;  // 06049BD0 add #-4,r15
    c.r[2] = c.r[3];  // 06049BD2 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06049BD4 mov.b @r2+,r1
    c.r[14] = c.r[15];  // 06049BD6 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06049BD8 extu.b r1,r1
    c.r[9] = c.r[1];  // 06049BDA mov r1,r9
    c.r[9] <<= 8;  // 06049BDC shll8 r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06049BDE mov.b @r2,r1
    c.r[7] = c.r[3];  // 06049BE0 mov r3,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06049BE2 extu.b r1,r1
    c.r[9] |= c.r[1];  // 06049BE4 or r1,r9
    c.r[1] = c.r[3];  // 06049BE6 mov r3,r1
    c.r[1] += 2;  // 06049BE8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049BEA mov.b @r1,r1
    c.r[7] += 4;  // 06049BEC add #4,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06049BEE mov.b @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06049BF0 extu.b r1,r1
    c.r[8] = c.r[1];  // 06049BF2 mov r1,r8
    c.r[8] <<= 8;  // 06049BF4 shll8 r8
    c.r[1] = c.r[3];  // 06049BF6 mov r3,r1
    c.r[1] += 3;  // 06049BF8 add #3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06049BFA extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049BFC mov.b @r1,r1
    c.r[3] += 5;  // 06049BFE add #5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06049C00 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06049C02 or r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06049C04 mov.b @r3,r1
    c.r[2] <<= 8;  // 06049C06 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06049C08 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06049C0A or r1,r2
    st16(c.r[14], c.r[2]);  // 06049C0C mov.w r2,@r14
    c.r[1] = ld32(0x06049C88u);  // 06049C0E mov.l 0x06049C88,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049C10 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06049C12 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06049C14 cmp/eq #1,r0
    if (!c.t) { goto L_06049C22; }  // 06049C16 bf 0x06049C22
    c.r[0] = ld32(0x06049C8Cu);  // 06049C18 mov.l 0x06049C8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049C1Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049C1Eu) return; }  // 06049C1A jsr @r0 ; mov r14,r4
    c.r[0] = c.r[0] & 0xFFFFu; goto L_06049C2C;  // 06049C1E bra 0x06049C2C ; extu.w r0,r0
L_06049C22:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06049C22 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06049C24 extu.b r1,r1
    st16(c.r[14], c.r[1]);  // 06049C26 mov.w r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06049C28 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06049C2A extu.b r1,r0
L_06049C2C:
    c.r[1] = c.r[8];  // 06049C2C mov r8,r1
    c.r[1] >>= 8;  // 06049C2E shlr8 r1
    c.r[1] += c.r[1];  // 06049C30 add r1,r1
    c.r[1] >>= 8;  // 06049C32 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049C34 tst r1,r1
    { const bool k = !c.t; c.r[6] = c.r[0] & 0xFFu; if (k) { goto L_06049C54; } }  // 06049C36 bf/s 0x06049C54 ; extu.b r0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049C7Eu);  // 06049C3A mov.w 0x06049C7E,r1
    c.r[8] &= c.r[1];  // 06049C3C and r1,r8
    c.r[1] = c.r[14];  // 06049C3E mov r14,r1
    c.r[1] += 1;  // 06049C40 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049C42 mov.b @r1,r5
    c.r[7] = c.r[8];  // 06049C44 mov r8,r7
    c.r[4] = c.r[9];  // 06049C46 mov r9,r4
    c.r[1] = ld32(0x06049C90u);  // 06049C48 mov.l 0x06049C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049C4Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049C4Eu) return; }  // 06049C4A jsr @r1 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049C80u);  // 06049C4E mov.w 0x06049C80,r0
    c.r[14] += 4; goto L_06049C72;  // 06049C50 bra 0x06049C72 ; add #4,r14
L_06049C54:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049C7Eu);  // 06049C54 mov.w 0x06049C7E,r1
    c.r[8] &= c.r[1];  // 06049C56 and r1,r8
    c.r[1] = c.r[14];  // 06049C58 mov r14,r1
    c.r[1] += 1;  // 06049C5A add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049C5C mov.b @r1,r5
    c.r[7] = c.r[8];  // 06049C5E mov r8,r7
    c.r[4] = c.r[9];  // 06049C60 mov r9,r4
    c.r[1] = ld32(0x06049C90u);  // 06049C62 mov.l 0x06049C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049C68u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049C68u) return; }  // 06049C64 jsr @r1 ; extu.b r5,r5
    c.r[2] = ld32(0x06049C94u);  // 06049C68 mov.l 0x06049C94,r2
    c.r[1] = 0x1u;  // 06049C6A mov #1,r1
    st16(c.r[2], c.r[1]);  // 06049C6C mov.w r1,@r2
    c.r[0] = ld32(0x06049C98u);  // 06049C6E mov.l 0x06049C98,r0
    c.r[14] += 4;  // 06049C70 add #4,r14
L_06049C72:
    c.r[15] = c.r[14];  // 06049C72 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049C74 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06049C76 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06049C78 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049C7A rts ; mov.l @r15+,r8
}

void f_06049C9C(SH2Context& c) {
    ran[1202] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049C9C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049C9E sts.l pr,@-r15
    c.r[1] = ld32(0x06049CBCu);  // 06049CA0 mov.l 0x06049CBC,r1
    c.r[1] = ld32(c.r[1]);  // 06049CA2 mov.l @r1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049CA4 mov.b @r1,r4
    c.r[14] = c.r[15];  // 06049CA6 mov r15,r14
    c.r[1] = ld32(0x06049CC0u);  // 06049CA8 mov.l 0x06049CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049CAEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049CAEu) return; }  // 06049CAA jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 06049CAE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049CB0 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049CB8u);  // 06049CB2 mov.w 0x06049CB8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049CB4 rts ; mov.l @r15+,r14
}

void f_06049CC4(SH2Context& c) {
    ran[1203] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049CC4 mov.l r14,@-r15
    c.r[7] = ld32(0x06049CF4u);  // 06049CC6 mov.l 0x06049CF4,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06049CC8 mov.b @r7,r0
    c.r[1] = 0x2u;  // 06049CCA mov #2,r1
    c.r[3] = c.r[0] & 0xFFu;  // 06049CCC extu.b r0,r3
    c.r[3] >>= 2;  // 06049CCE shlr2 r3
    c.r[3] >>= 2;  // 06049CD0 shlr2 r3
    c.r[3] >>= 2;  // 06049CD2 shlr2 r3
    c.r[2] = c.r[3] & 0xFFu;  // 06049CD4 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 06049CD6 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06049CEA; } }  // 06049CD8 bt/s 0x06049CEA ; mov r15,r14
    c.r[3] += 1;  // 06049CDC add #1,r3
    c.r[3] <<= 2;  // 06049CDE shll2 r3
    c.r[3] <<= 2;  // 06049CE0 shll2 r3
    c.r[3] <<= 2;  // 06049CE2 shll2 r3
    c.r[0] &= 0x3Fu;  // 06049CE4 and #63,r0
    c.r[0] |= c.r[3];  // 06049CE6 or r3,r0
    st8(c.r[7], c.r[0]);  // 06049CE8 mov.b r0,@r7
L_06049CEA:
    c.r[15] = c.r[14];  // 06049CEA mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049CF2u);  // 06049CEC mov.w 0x06049CF2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049CEE rts ; mov.l @r15+,r14
}

void f_06049CF8(SH2Context& c) {
    ran[1204] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06049CF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06049CFA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06049CFC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06049CFE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06049D00 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049D02 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049D04 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06049D06 mov r15,r14
    c.r[2] = 0x0u;  // 06049D08 mov #0,r2
    c.r[6] = 0x1Fu;  // 06049D0A mov #31,r6
    c.r[7] = ld32(0x06049DB0u);  // 06049D0C mov.l 0x06049DB0,r7
    c.r[3] = 0xFFFFFFFFu;  // 06049D0E mov #-1,r3
    c.r[1] = c.r[2];  // 06049D10 mov r2,r1
L_06049D12:
    c.r[1] <<= 2;  // 06049D12 shll2 r1
    c.r[1] += c.r[7];  // 06049D14 add r7,r1
    c.r[1] += 108;  // 06049D16 add #108,r1
    st32(c.r[1], c.r[3]);  // 06049D18 mov.l r3,@r1
    c.r[1] = c.r[2];  // 06049D1A mov r2,r1
    c.r[1] += 1;  // 06049D1C add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06049D1E extu.w r1,r2
    c.t = c.r[2] > c.r[6];  // 06049D20 cmp/hi r6,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_06049D12; } }  // 06049D22 bf/s 0x06049D12 ; mov r2,r1
    c.r[4] = ld32(0x06049DB4u);  // 06049D26 mov.l 0x06049DB4,r4
    c.r[0] = ld32(0x06049DB8u);  // 06049D28 mov.l 0x06049DB8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049D2Eu; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049D2Eu) return; }  // 06049D2A jsr @r0 ; mov #2,r5
    c.r[12] = c.r[0];  // 06049D2E mov r0,r12
    c.r[2] = ld32(0x06049DB0u);  // 06049D30 mov.l 0x06049DB0,r2
    c.r[3] = c.r[2];  // 06049D32 mov r2,r3
    c.r[3] += 108;  // 06049D34 add #108,r3
    c.r[7] = ld32(0x06049DBCu);  // 06049D36 mov.l 0x06049DBC,r7
    c.r[1] = c.r[7];  // 06049D38 mov r7,r1
    c.r[1] += 6;  // 06049D3A add #6,r1
    c.r[11] = ld32(0x06049DC0u);  // 06049D3C mov.l 0x06049DC0,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049DACu);  // 06049D3E mov.w 0x06049DAC,r0
    c.r[10] = ld32(0x06049DC4u);  // 06049D40 mov.l 0x06049DC4,r10
    c.r[8] = 0x2u;  // 06049D42 mov #2,r8
    c.r[7] += 8;  // 06049D44 add #8,r7
    c.r[9] = ld32(0x06049DC8u);  // 06049D46 mov.l 0x06049DC8,r9
    c.r[6] = c.r[8];  // 06049D48 mov r8,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06049D4A mov.w @r1,r1
    c.r[5] = c.r[12];  // 06049D4C mov r12,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 06049D4E extu.w r1,r1
    c.r[1] <<= 2;  // 06049D50 shll2 r1
    c.r[1] <<= 2;  // 06049D52 shll2 r1
    c.r[1] <<= 2;  // 06049D54 shll2 r1
    st32(c.r[3], c.r[1]);  // 06049D56 mov.l r1,@r3
    c.r[3] = c.r[2];  // 06049D58 mov r2,r3
    c.r[1] = c.r[11];  // 06049D5A mov r11,r1
    c.r[1] += 6;  // 06049D5C add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06049D5E mov.w @r1,r1
    c.r[3] += 112;  // 06049D60 add #112,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 06049D62 extu.w r1,r1
    c.r[1] <<= 2;  // 06049D64 shll2 r1
    c.r[1] <<= 2;  // 06049D66 shll2 r1
    c.r[1] <<= 2;  // 06049D68 shll2 r1
    st32(c.r[3], c.r[1]);  // 06049D6A mov.l r1,@r3
    c.r[1] = ld32(0x06049DCCu);  // 06049D6C mov.l 0x06049DCC,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06049D6E mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049DAEu);  // 06049D70 mov.w 0x06049DAE,r0
    st32(c.r[0] + c.r[2], c.r[10]);  // 06049D72 mov.l r10,@(r0,r2)
    c.r[2] += 76;  // 06049D74 add #76,r2
    st32(c.r[2], c.r[8]);  // 06049D76 mov.l r8,@r2
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06049D78 mov.w @r7,r7
    c.r[4] = 0x5u;  // 06049D7A mov #5,r4
    c.r[7] = c.r[7] & 0xFFFFu;  // 06049D7C extu.w r7,r7
    { const uint32_t x = c.r[9]; c.pr = 0x06049D82u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049D82u) return; }  // 06049D7E jsr @r9 ; mov.l r1,@-r15
    c.r[11] += 8;  // 06049D82 add #8,r11
    c.r[6] = c.r[8];  // 06049D84 mov r8,r6
    c.r[5] = c.r[12];  // 06049D86 mov r12,r5
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06049D88 mov.w @r11,r7
    c.r[4] = 0x5u;  // 06049D8A mov #5,r4
    c.r[7] = c.r[7] & 0xFFFFu;  // 06049D8C extu.w r7,r7
    { const uint32_t x = c.r[9]; c.pr = 0x06049D92u; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049D92u) return; }  // 06049D8E jsr @r9 ; mov.l r10,@-r15
    c.r[1] = ld32(0x06049DD0u);  // 06049D92 mov.l 0x06049DD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049D98u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049D98u) return; }  // 06049D94 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06049D98 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06049D9A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06049D9C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06049D9E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06049DA0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06049DA2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06049DA4 mov.l @r15+,r9
    c.r[0] = ld32(0x06049DD4u);  // 06049DA6 mov.l 0x06049DD4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049DA8 rts ; mov.l @r15+,r8
}

void f_06049DD8(SH2Context& c) {
    ran[1205] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049DD8 mov.l r14,@-r15
    c.r[1] = ld32(0x06049E00u);  // 06049DDA mov.l 0x06049E00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049DDC mov.b @r1,r1
    c.r[0] = c.r[1];  // 06049DDE mov r1,r0
    c.r[0] >>= 2;  // 06049DE0 shlr2 r0
    c.r[0] >>= 2;  // 06049DE2 shlr2 r0
    c.r[0] >>= 2;  // 06049DE4 shlr2 r0
    c.r[0] &= 0x1u;  // 06049DE6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049DE8 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06049DF4; } }  // 06049DEA bf/s 0x06049DF4 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049DFCu);  // 06049DEE mov.w 0x06049DFC,r0
    c.r[15] = c.r[14]; goto L_06049DF8;  // 06049DF0 bra 0x06049DF8 ; mov r14,r15
L_06049DF4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049DFEu);  // 06049DF4 mov.w 0x06049DFE,r0
    c.r[15] = c.r[14];  // 06049DF6 mov r14,r15
L_06049DF8:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06049DF8 rts ; mov.l @r15+,r14
}

void f_06049E04(SH2Context& c) {
    ran[1206] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06049E04 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06049E06 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06049E08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06049E0A sts.l pr,@-r15
    c.r[1] = ld32(0x06049F68u);  // 06049E0C mov.l 0x06049F68,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06049E0E mov.w @r1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06049E10 extu.w r1,r8
    c.r[0] = c.r[8];  // 06049E12 mov r8,r0
    c.r[0] >>= 8;  // 06049E14 shlr8 r0
    c.r[0] <<= 2;  // 06049E16 shll2 r0
    c.r[0] >>= 8;  // 06049E18 shlr8 r0
    c.r[0] &= 0x1u;  // 06049E1A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049E1C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06049E30; } }  // 06049E1E bt/s 0x06049E30 ; mov r15,r14
    c.r[2] = ld32(0x06049F6Cu);  // 06049E22 mov.l 0x06049F6C,r2
    c.r[3] = ld32(c.r[2] + 12);  // 06049E24 mov.l @(12,r2),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049F58u);  // 06049E26 mov.w 0x06049F58,r1
    c.r[3] += c.r[1];  // 06049E28 add r1,r3
    c.r[1] = ld32(0x06049F70u);  // 06049E2A mov.l 0x06049F70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049E30u; st32(c.r[2] + 12, c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049E30u) return; }  // 06049E2C jsr @r1 ; mov.l r3,@(12,r2)
L_06049E30:
    c.r[1] = c.r[8];  // 06049E30 mov r8,r1
    c.r[1] >>= 8;  // 06049E32 shlr8 r1
    c.r[1] += c.r[1];  // 06049E34 add r1,r1
    c.r[1] >>= 8;  // 06049E36 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049E38 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06049E4E; } }  // 06049E3A bt/s 0x06049E4E ; mov r8,r0
    c.r[2] = ld32(0x06049F6Cu);  // 06049E3E mov.l 0x06049F6C,r2
    c.r[3] = ld32(c.r[2] + 12);  // 06049E40 mov.l @(12,r2),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06049F5Au);  // 06049E42 mov.w 0x06049F5A,r1
    c.r[3] += c.r[1];  // 06049E44 add r1,r3
    c.r[1] = ld32(0x06049F70u);  // 06049E46 mov.l 0x06049F70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049E4Cu; st32(c.r[2] + 12, c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049E4Cu) return; }  // 06049E48 jsr @r1 ; mov.l r3,@(12,r2)
    c.r[0] = c.r[8];  // 06049E4C mov r8,r0
L_06049E4E:
    c.r[0] >>= 8;  // 06049E4E shlr8 r0
    c.r[0] >>= 2;  // 06049E50 shlr2 r0
    c.r[0] >>= 2;  // 06049E52 shlr2 r0
    c.r[0] &= 0x1u;  // 06049E54 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049E56 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06049E66; } }  // 06049E58 bt/s 0x06049E66 ; mov r8,r0
    c.r[1] = ld32(0x06049F6Cu);  // 06049E5C mov.l 0x06049F6C,r1
    c.r[3] = ld32(c.r[1] + 16);  // 06049E5E mov.l @(16,r1),r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06049F5Cu);  // 06049E60 mov.w 0x06049F5C,r2
    c.r[3] += c.r[2];  // 06049E62 add r2,r3
    st32(c.r[1] + 16, c.r[3]);  // 06049E64 mov.l r3,@(16,r1)
L_06049E66:
    c.r[0] >>= 8;  // 06049E66 shlr8 r0
    c.r[0] >>= 2;  // 06049E68 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06049E6A shlr r0
    c.r[0] >>= 2;  // 06049E6C shlr2 r0
    c.r[0] &= 0x1u;  // 06049E6E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049E70 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06049E80; } }  // 06049E72 bt/s 0x06049E80 ; mov r8,r0
    c.r[1] = ld32(0x06049F6Cu);  // 06049E76 mov.l 0x06049F6C,r1
    c.r[3] = ld32(c.r[1] + 16);  // 06049E78 mov.l @(16,r1),r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06049F5Eu);  // 06049E7A mov.w 0x06049F5E,r2
    c.r[3] += c.r[2];  // 06049E7C add r2,r3
    st32(c.r[1] + 16, c.r[3]);  // 06049E7E mov.l r3,@(16,r1)
L_06049E80:
    c.r[0] >>= 8;  // 06049E80 shlr8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06049E82 shlr r0
    c.r[0] >>= 2;  // 06049E84 shlr2 r0
    c.r[0] &= 0x1u;  // 06049E86 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049E88 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_06049EFC; } }  // 06049E8A bt/s 0x06049EFC ; mov #64,r1
    c.r[0] = c.r[8];  // 06049E8E mov r8,r0
    c.r[0] >>= 8;  // 06049E90 shlr8 r0
    c.r[0] >>= 2;  // 06049E92 shlr2 r0
    c.r[0] &= 0x1u;  // 06049E94 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049E96 tst r0,r0
    if (c.t) { goto L_06049EA2; }  // 06049E98 bt 0x06049EA2
    c.r[15] = c.r[14];  // 06049E9A mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049F60u);  // 06049E9C mov.w 0x06049F60,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0604A026;  // 06049E9E bra 0x0604A026 ; lds.l @r15+,pr
L_06049EA2:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06049F5Au);  // 06049EA2 mov.w 0x06049F5A,r2
    c.r[2] &= c.r[8];  // 06049EA4 and r8,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06049EA6 tst r2,r2
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06049EEE; } }  // 06049EA8 bt/s 0x06049EEE ; mov #1,r1
    c.r[2] = ld32(0x06049F74u);  // 06049EAC mov.l 0x06049F74,r2
    st8(c.r[2], c.r[1]);  // 06049EAE mov.b r1,@r2
    c.r[1] = ld32(0x06049F78u);  // 06049EB0 mov.l 0x06049F78,r1
    c.r[6] = 0xFFFFFFF0u;  // 06049EB2 mov #-16,r6
    c.r[5] = 0xFFFFFFF0u;  // 06049EB4 mov #-16,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06049EBAu; c.r[4] = 0xFFFFFFF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049EBAu) return; }  // 06049EB6 jsr @r1 ; mov #-16,r4
    c.r[1] = ld32(0x06049F7Cu);  // 06049EBA mov.l 0x06049F7C,r1
    c.r[0] = 0x40u;  // 06049EBC mov #64,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049EBE mov.b @r1,r2
    c.r[6] = 0x0u;  // 06049EC0 mov #0,r6
    c.r[2] |= c.r[0];  // 06049EC2 or r0,r2
    st8(c.r[1], c.r[2]);  // 06049EC4 mov.b r2,@r1
    c.r[2] = ld32(0x06049F80u);  // 06049EC6 mov.l 0x06049F80,r2
    c.r[3] = c.r[2];  // 06049EC8 mov r2,r3
    c.r[3] += 10;  // 06049ECA add #10,r3
    c.r[1] = 0x0u;  // 06049ECC mov #0,r1
    st16(c.r[3], c.r[1]);  // 06049ECE mov.w r1,@r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06049ED0 mov.b @r2,r2
    c.r[1] = ld32(0x06049F84u);  // 06049ED2 mov.l 0x06049F84,r1
    c.r[1] = ld32(c.r[1]);  // 06049ED4 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06049ED6 extu.b r2,r2
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06049ED8 mov.w @r3,r5
    c.r[0] = c.r[1];  // 06049EDA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06049EDC mov.b @(r0,r2),r1
    c.r[4] = 0x0u;  // 06049EDE mov #0,r4
    c.r[5] += c.r[1];  // 06049EE0 add r1,r5
    c.r[0] = ld32(0x06049F88u);  // 06049EE2 mov.l 0x06049F88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049EE8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049EE8u) return; }  // 06049EE4 jsr @r0 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049F62u);  // 06049EE8 mov.w 0x06049F62,r0
    c.r[15] = c.r[14]; goto L_0604A024;  // 06049EEA bra 0x0604A024 ; mov r14,r15
L_06049EEE:
    c.r[1] = ld32(0x06049F6Cu);  // 06049EEE mov.l 0x06049F6C,r1
    st32(c.r[1] + 12, c.r[2]);  // 06049EF0 mov.l r2,@(12,r1)
    st32(c.r[1] + 16, c.r[2]);  // 06049EF2 mov.l r2,@(16,r1)
    c.r[1] = ld32(0x06049F70u);  // 06049EF4 mov.l 0x06049F70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06049EFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049EFAu) return; }  // 06049EF6 jsr @r1 ; nop
    c.r[1] = 0x40u;  // 06049EFA mov #64,r1
L_06049EFC:
    c.r[1] &= c.r[8];  // 06049EFC and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049EFE tst r1,r1
    { const bool k = c.t; c.r[1] = 0x20u; if (k) { goto L_06049F0C; } }  // 06049F00 bt/s 0x06049F0C ; mov #32,r1
    c.r[0] = ld32(0x06049F8Cu);  // 06049F04 mov.l 0x06049F8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049F0Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049F0Au) return; }  // 06049F06 jsr @r0 ; mov #1,r4
    c.r[1] = 0x20u;  // 06049F0A mov #32,r1
L_06049F0C:
    c.r[1] &= c.r[8];  // 06049F0C and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049F0E tst r1,r1
    { const bool k = c.t; c.r[1] = 0x10u; if (k) { goto L_06049F1C; } }  // 06049F10 bt/s 0x06049F1C ; mov #16,r1
    c.r[0] = ld32(0x06049F8Cu);  // 06049F14 mov.l 0x06049F8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049F1Au; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049F1Au) return; }  // 06049F16 jsr @r0 ; mov #2,r4
    c.r[1] = 0x10u;  // 06049F1A mov #16,r1
L_06049F1C:
    c.r[1] &= c.r[8];  // 06049F1C and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049F1E tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06049F2C; } }  // 06049F20 bt/s 0x06049F2C ; mov r8,r0
    c.r[0] = ld32(0x06049F8Cu);  // 06049F24 mov.l 0x06049F8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06049F2Au; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049F2Au) return; }  // 06049F26 jsr @r0 ; mov #11,r4
    c.r[0] = c.r[8];  // 06049F2A mov r8,r0
L_06049F2C:
    c.r[0] >>= 8;  // 06049F2C shlr8 r0
    c.r[0] >>= 2;  // 06049F2E shlr2 r0
    c.r[0] &= 0x1u;  // 06049F30 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049F32 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06049F9C; } }  // 06049F34 bt/s 0x06049F9C ; mov r8,r0
    c.r[9] = ld32(0x06049F90u);  // 06049F38 mov.l 0x06049F90,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06049F3A mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06049F3C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049F3E tst r1,r1
    { const bool k = c.t; c.r[0] >>= 8; if (k) { goto L_06049F9E; } }  // 06049F40 bt/s 0x06049F9E ; shlr8 r0
    c.r[0] = ld32(0x06049F94u);  // 06049F44 mov.l 0x06049F94,r0
    c.r[6] = 0x42u;  // 06049F46 mov #66,r6
    c.r[5] = 0x10u;  // 06049F48 mov #16,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06049F4Eu; c.r[4] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049F4Eu) return; }  // 06049F4A jsr @r0 ; mov #58,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06049F4E mov.w @r9,r1
    c.r[2] = ld32(0x06049F98u);  // 06049F50 mov.l 0x06049F98,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06049F64u);  // 06049F52 mov.w 0x06049F64,r0
    c.r[1] -= 1; goto L_06049FC6;  // 06049F54 bra 0x06049FC6 ; add #-1,r1
L_06049F9C:
    c.r[0] >>= 8;  // 06049F9C shlr8 r0
L_06049F9E:
    c.r[0] &= 0x1u;  // 06049F9E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06049FA0 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_06049FCE; } }  // 06049FA2 bt/s 0x06049FCE ; mov #8,r1
    c.r[9] = ld32(0x0604A038u);  // 06049FA6 mov.l 0x0604A038,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06049FA8 mov.w @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604A02Eu);  // 06049FAA mov.w 0x0604A02E,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06049FAC extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06049FAE cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_06049FCE; } }  // 06049FB0 bt/s 0x06049FCE ; mov #8,r1
    c.r[0] = ld32(0x0604A03Cu);  // 06049FB4 mov.l 0x0604A03C,r0
    c.r[6] = 0x42u;  // 06049FB6 mov #66,r6
    c.r[5] = 0x10u;  // 06049FB8 mov #16,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06049FBEu; c.r[4] = 0x3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06049FBEu) return; }  // 06049FBA jsr @r0 ; mov #58,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06049FBE mov.w @r9,r1
    c.r[2] = ld32(0x0604A040u);  // 06049FC0 mov.l 0x0604A040,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604A030u);  // 06049FC2 mov.w 0x0604A030,r0
    c.r[1] += 1;  // 06049FC4 add #1,r1
L_06049FC6:
    st16(c.r[9], c.r[1]);  // 06049FC6 mov.w r1,@r9
    c.r[1] = 0x0u;  // 06049FC8 mov #0,r1
    st16(c.r[2], c.r[1]); goto L_0604A022;  // 06049FCA bra 0x0604A022 ; mov.w r1,@r2
L_06049FCE:
    c.r[1] &= c.r[8];  // 06049FCE and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049FD0 tst r1,r1
    if (c.t) { goto L_06049FEA; }  // 06049FD2 bt 0x06049FEA
    c.r[1] = ld32(0x0604A044u);  // 06049FD4 mov.l 0x0604A044,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049FD6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06049FD8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06049FDA tst r1,r1
    if (c.t) { goto L_06049FEA; }  // 06049FDC bt 0x06049FEA
    c.r[2] = ld32(0x0604A048u);  // 06049FDE mov.l 0x0604A048,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06049FE0 mov.b @r2,r1
    c.r[5] = ld32(0x0604A04Cu);  // 06049FE2 mov.l 0x0604A04C,r5
    c.r[4] = ld32(0x0604A050u);  // 06049FE4 mov.l 0x0604A050,r4
    c.r[1] -= 1; goto L_0604A008;  // 06049FE6 bra 0x0604A008 ; add #-1,r1
L_06049FEA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604A032u);  // 06049FEA mov.w 0x0604A032,r0
    c.r[8] &= c.r[0];  // 06049FEC and r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06049FEE tst r8,r8
    if (c.t) { goto L_0604A020; }  // 06049FF0 bt 0x0604A020
    c.r[1] = ld32(0x0604A044u);  // 06049FF2 mov.l 0x0604A044,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06049FF4 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604A034u);  // 06049FF6 mov.w 0x0604A034,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06049FF8 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06049FFA cmp/hi r2,r1
    if (c.t) { goto L_0604A020; }  // 06049FFC bt 0x0604A020
    c.r[2] = ld32(0x0604A048u);  // 06049FFE mov.l 0x0604A048,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604A000 mov.b @r2,r1
    c.r[5] = ld32(0x0604A04Cu);  // 0604A002 mov.l 0x0604A04C,r5
    c.r[4] = ld32(0x0604A050u);  // 0604A004 mov.l 0x0604A050,r4
    c.r[1] += 1;  // 0604A006 add #1,r1
L_0604A008:
    st8(c.r[2], c.r[1]);  // 0604A008 mov.b r1,@r2
    c.r[1] = ld32(0x0604A054u);  // 0604A00A mov.l 0x0604A054,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604A010u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A010u) return; }  // 0604A00C jsr @r1 ; nop
    c.r[0] = ld32(0x0604A03Cu);  // 0604A010 mov.l 0x0604A03C,r0
    c.r[6] = 0x26u;  // 0604A012 mov #38,r6
    c.r[5] = 0x20u;  // 0604A014 mov #32,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604A01Au; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A01Au) return; }  // 0604A016 jsr @r0 ; mov #6,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604A036u);  // 0604A01A mov.w 0x0604A036,r0
    c.r[15] = c.r[14]; goto L_0604A024;  // 0604A01C bra 0x0604A024 ; mov r14,r15
L_0604A020:
    c.r[0] = ld32(0x0604A058u);  // 0604A020 mov.l 0x0604A058,r0
L_0604A022:
    c.r[15] = c.r[14];  // 0604A022 mov r14,r15
L_0604A024:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604A024 lds.l @r15+,pr
L_0604A026:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604A026 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604A028 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604A02A rts ; mov.l @r15+,r8
}

void f_0604A130(SH2Context& c) {
    ran[1207] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604A130 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604A132 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604A134 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604A136 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604A138 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604A13A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604A13C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604A13E sts.l pr,@-r15
    c.r[15] -= 76;  // 0604A140 add #-76,r15
    c.r[14] = c.r[15];  // 0604A142 mov r15,r14
    c.r[1] = ld32(0x0604A388u);  // 0604A144 mov.l 0x0604A388,r1
    c.r[12] = c.r[14];  // 0604A146 mov r14,r12
    c.r[12] += 4;  // 0604A148 add #4,r12
    c.r[7] = ld32(0x0604A38Cu);  // 0604A14A mov.l 0x0604A38C,r7
    c.r[0] = 0x48u;  // 0604A14C mov #72,r0
    c.r[0] += c.r[14];  // 0604A14E add r14,r0
    c.r[11] = ld32(0x0604A390u);  // 0604A150 mov.l 0x0604A390,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604A152 mov.b @r1+,r2
    c.r[10] = c.r[11];  // 0604A154 mov r11,r10
    st8(c.r[14], c.r[2]);  // 0604A156 mov.b r2,@r14
    c.r[2] = c.r[14];  // 0604A158 mov r14,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604A15A mov.b @r1+,r3
    c.r[2] += 1;  // 0604A15C add #1,r2
    st8(c.r[2], c.r[3]);  // 0604A15E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604A160 mov.b @r1+,r3
    c.r[2] += 1;  // 0604A162 add #1,r2
    st8(c.r[2], c.r[3]);  // 0604A164 mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A166 mov.b @r1,r1
    c.r[2] += 1;  // 0604A168 add #1,r2
    st8(c.r[2], c.r[1]);  // 0604A16A mov.b r1,@r2
    c.r[1] = ld32(0x0604A394u);  // 0604A16C mov.l 0x0604A394,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604A16E mov.b @r1+,r2
    c.r[10] += 30;  // 0604A170 add #30,r10
    st8(c.r[12], c.r[2]);  // 0604A172 mov.b r2,@r12
    c.r[12] = c.r[14];  // 0604A174 mov r14,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604A176 mov.b @r1+,r2
    c.r[12] += 5;  // 0604A178 add #5,r12
    st8(c.r[12], c.r[2]);  // 0604A17A mov.b r2,@r12
    c.r[12] = c.r[14];  // 0604A17C mov r14,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0604A17E mov.b @r1+,r2
    c.r[12] += 6;  // 0604A180 add #6,r12
    st8(c.r[12], c.r[2]);  // 0604A182 mov.b r2,@r12
    c.r[12] = c.r[14];  // 0604A184 mov r14,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A186 mov.b @r1,r1
    c.r[12] += 7;  // 0604A188 add #7,r12
    st8(c.r[12], c.r[1]);  // 0604A18A mov.b r1,@r12
    c.r[12] = c.r[14];  // 0604A18C mov r14,r12
    st32(c.r[0], c.r[7]);  // 0604A18E mov.l r7,@r0
    c.r[0] = ld32(0x0604A398u);  // 0604A190 mov.l 0x0604A398,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604A192 mov.w @r0,r2
    c.r[7] = ld32(0x0604A39Cu);  // 0604A194 mov.l 0x0604A39C,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604A196 mov.w @r7,r1
    c.r[2] <<= 2;  // 0604A198 shll2 r2
    c.r[2] <<= 2;  // 0604A19A shll2 r2
    c.r[2] += c.r[2];  // 0604A19C add r2,r2
    c.r[2] <<= 2;  // 0604A19E shll2 r2
    c.r[1] -= 1;  // 0604A1A0 add #-1,r1
    c.r[2] |= c.r[1];  // 0604A1A2 or r1,r2
    c.r[0] = ld32(0x0604A3A0u);  // 0604A1A4 mov.l 0x0604A3A0,r0
    st16(c.r[0], c.r[2]);  // 0604A1A6 mov.w r2,@r0
    c.r[1] = c.r[11];  // 0604A1A8 mov r11,r1
    c.r[1] += 27;  // 0604A1AA add #27,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A1AC mov.b @r1,r1
    c.r[7] = ld32(0x0604A3A4u);  // 0604A1AE mov.l 0x0604A3A4,r7
    st8(c.r[7], c.r[1]);  // 0604A1B0 mov.b r1,@r7
    c.r[1] = c.r[11];  // 0604A1B2 mov r11,r1
    c.r[1] += 29;  // 0604A1B4 add #29,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A1B6 mov.b @r1,r1
    c.r[0] = ld32(0x0604A3A8u);  // 0604A1B8 mov.l 0x0604A3A8,r0
    c.r[1] -= 1;  // 0604A1BA add #-1,r1
    st8(c.r[0], c.r[1]);  // 0604A1BC mov.b r1,@r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604A1BE mov.w @r10,r1
    c.r[7] = 0xBu;  // 0604A1C0 mov #11,r7
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0604A1C2 cmp/gt r7,r1
    { const bool k = !c.t; c.r[12] += 8; if (k) { goto L_0604A1CC; } }  // 0604A1C4 bf/s 0x0604A1CC ; add #8,r12
    c.r[1] = 0xFFFFFFFFu;  // 0604A1C8 mov #-1,r1
    st16(c.r[10], c.r[1]);  // 0604A1CA mov.w r1,@r10
L_0604A1CC:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604A1CC mov.w @r10,r2
    c.r[1] = 0xFFFFFFFFu;  // 0604A1CE mov #-1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0604A1D0 cmp/ge r1,r2
    { const bool k = c.t; c.r[13] = c.r[11]; if (k) { goto L_0604A1DA; } }  // 0604A1D2 bt/s 0x0604A1DA ; mov r11,r13
    c.r[1] = 0xBu;  // 0604A1D6 mov #11,r1
    st16(c.r[10], c.r[1]);  // 0604A1D8 mov.w r1,@r10
L_0604A1DA:
    c.r[13] += 18;  // 0604A1DA add #18,r13
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0604A1DC mov.w @r13,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604A1DE mov.w @r10,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 0604A1E0 exts.w r5,r2
    c.t = c.r[2] == c.r[1];  // 0604A1E2 cmp/eq r1,r2
    { const bool k = c.t; c.r[5] += 5; if (k) { goto L_0604A1F8; } }  // 0604A1E4 bt/s 0x0604A1F8 ; add #5,r5
    c.r[5] = c.r[5] & 0xFFFFu;  // 0604A1E8 extu.w r5,r5
    c.r[0] = ld32(0x0604A3ACu);  // 0604A1EA mov.l 0x0604A3AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A1F0u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A1F0u) return; }  // 0604A1EC jsr @r0 ; mov #4,r4
    c.r[4] = ld32(0x0604A3B0u);  // 0604A1F0 mov.l 0x0604A3B0,r4
    c.r[1] = ld32(0x0604A3B4u);  // 0604A1F2 mov.l 0x0604A3B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604A1F8u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A1F8u) return; }  // 0604A1F4 jsr @r1 ; mov r0,r5
L_0604A1F8:
    c.r[9] = ld32(0x0604A3ACu);  // 0604A1F8 mov.l 0x0604A3AC,r9
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604A1FA mov.w @r10,r5
    c.r[4] = 0x4u;  // 0604A1FC mov #4,r4
    c.r[5] += 5;  // 0604A1FE add #5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A204u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A204u) return; }  // 0604A200 jsr @r9 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0604A204 mov r0,r1
    c.r[4] = ld32(0x0604A3B8u);  // 0604A206 mov.l 0x0604A3B8,r4
    c.r[8] = ld32(0x0604A3B4u);  // 0604A208 mov.l 0x0604A3B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604A20Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A20Eu) return; }  // 0604A20A jsr @r8 ; mov r1,r5
    c.r[5] = ld32(0x0604A3BCu);  // 0604A20E mov.l 0x0604A3BC,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0604A210 mov.w @r10,r1
    c.r[4] = c.r[12];  // 0604A212 mov r12,r4
    st16(c.r[13], c.r[1]);  // 0604A214 mov.w r1,@r13
    c.r[1] = ld32(0x0604A3C0u);  // 0604A216 mov.l 0x0604A3C0,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A218 mov.w @r1,r6
    c.r[10] = ld32(0x0604A3C4u);  // 0604A21A mov.l 0x0604A3C4,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0604A220u; c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A220u) return; }  // 0604A21C jsr @r10 ; exts.w r6,r6
    c.r[5] = 0x4u;  // 0604A220 mov #4,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A226u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A226u) return; }  // 0604A222 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A226 mov r0,r1
    c.r[5] = c.r[1];  // 0604A228 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A22Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A22Eu) return; }  // 0604A22A jsr @r8 ; mov r12,r4
    c.r[11] += 20;  // 0604A22E add #20,r11
    c.r[5] = ld32(0x0604A3C8u);  // 0604A230 mov.l 0x0604A3C8,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604A232 mov.w @r11,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0604A238u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A238u) return; }  // 0604A234 jsr @r10 ; mov r12,r4
    c.r[5] = 0x5u;  // 0604A238 mov #5,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A23Eu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A23Eu) return; }  // 0604A23A jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A23E mov r0,r1
    c.r[5] = c.r[1];  // 0604A240 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A246u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A246u) return; }  // 0604A242 jsr @r8 ; mov r12,r4
    c.r[1] = ld32(0x0604A3CCu);  // 0604A246 mov.l 0x0604A3CC,r1
    c.r[1] = ld32(c.r[1]);  // 0604A248 mov.l @r1,r1
    c.r[5] = ld32(0x0604A3D0u);  // 0604A24A mov.l 0x0604A3D0,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0604A24C mov.w @r11,r2
    c.r[0] = c.r[1];  // 0604A24E mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604A250 mov.b @(r0,r2),r6
    c.r[4] = c.r[12];  // 0604A252 mov r12,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0604A258u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A258u) return; }  // 0604A254 jsr @r10 ; extu.b r6,r6
    c.r[5] = 0x6u;  // 0604A258 mov #6,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A25Eu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A25Eu) return; }  // 0604A25A jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A25E mov r0,r1
    c.r[5] = c.r[1];  // 0604A260 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A266u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A266u) return; }  // 0604A262 jsr @r8 ; mov r12,r4
    c.r[7] = 0x48u;  // 0604A266 mov #72,r7
    c.r[7] += c.r[14];  // 0604A268 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0604A26A mov.l @r7,r0
    c.r[5] = ld32(0x0604A3D4u);  // 0604A26C mov.l 0x0604A3D4,r5
    c.r[0] += 64;  // 0604A26E add #64,r0
    st32(c.r[7], c.r[0]);  // 0604A270 mov.l r0,@r7
    c.r[7] = 0x48u;  // 0604A272 mov #72,r7
    c.r[7] += c.r[14];  // 0604A274 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 0604A276 mov.l @r7,r0
    c.r[4] = c.r[12];  // 0604A278 mov r12,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604A27A mov.w @r0,r1
    c.r[7] = 0x1u;  // 0604A27C mov #1,r7
    c.r[1] &= c.r[7];  // 0604A27E and r7,r1
    c.r[1] <<= 2;  // 0604A280 shll2 r1
    c.r[1] += c.r[14];  // 0604A282 add r14,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0604A288u; c.r[6] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A288u) return; }  // 0604A284 jsr @r10 ; mov r1,r6
    c.r[5] = 0x7u;  // 0604A288 mov #7,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A28Eu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A28Eu) return; }  // 0604A28A jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A28E mov r0,r1
    c.r[5] = c.r[1];  // 0604A290 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A296u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A296u) return; }  // 0604A292 jsr @r8 ; mov r12,r4
    c.r[0] = ld32(0x0604A398u);  // 0604A296 mov.l 0x0604A398,r0
    c.r[5] = ld32(0x0604A3D8u);  // 0604A298 mov.l 0x0604A3D8,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604A29A mov.w @r0,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0604A2A0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2A0u) return; }  // 0604A29C jsr @r10 ; mov r12,r4
    c.r[5] = 0x8u;  // 0604A2A0 mov #8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A2A6u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2A6u) return; }  // 0604A2A2 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A2A6 mov r0,r1
    c.r[5] = c.r[1];  // 0604A2A8 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A2AEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2AEu) return; }  // 0604A2AA jsr @r8 ; mov r12,r4
    c.r[7] = ld32(0x0604A39Cu);  // 0604A2AE mov.l 0x0604A39C,r7
    c.r[5] = ld32(0x0604A3DCu);  // 0604A2B0 mov.l 0x0604A3DC,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604A2B2 mov.w @r7,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0604A2B8u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2B8u) return; }  // 0604A2B4 jsr @r10 ; mov r12,r4
    c.r[5] = 0x9u;  // 0604A2B8 mov #9,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A2BEu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2BEu) return; }  // 0604A2BA jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A2BE mov r0,r1
    c.r[5] = c.r[1];  // 0604A2C0 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A2C6u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2C6u) return; }  // 0604A2C2 jsr @r8 ; mov r12,r4
    c.r[0] = ld32(0x0604A3A0u);  // 0604A2C6 mov.l 0x0604A3A0,r0
    c.r[4] = 0x0u;  // 0604A2C8 mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604A2CA mov.w @r0,r5
    c.r[7] = ld32(0x0604A3E0u);  // 0604A2CC mov.l 0x0604A3E0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0604A2D2u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2D2u) return; }  // 0604A2CE jsr @r7 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0604A2D2 mov r0,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0604A2D4 extu.b r1,r6
    c.r[5] = ld32(0x0604A3E4u);  // 0604A2D6 mov.l 0x0604A3E4,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604A2DCu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2DCu) return; }  // 0604A2D8 jsr @r10 ; mov r12,r4
    c.r[5] = 0xAu;  // 0604A2DC mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A2E2u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2E2u) return; }  // 0604A2DE jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A2E2 mov r0,r1
    c.r[5] = c.r[1];  // 0604A2E4 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A2EAu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2EAu) return; }  // 0604A2E6 jsr @r8 ; mov r12,r4
    c.r[0] = ld32(0x0604A3E8u);  // 0604A2EA mov.l 0x0604A3E8,r0
    c.r[5] = ld32(0x0604A3ECu);  // 0604A2EC mov.l 0x0604A3EC,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0604A2EE mov.w @r0,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0604A2F4u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2F4u) return; }  // 0604A2F0 jsr @r10 ; mov r12,r4
    c.r[5] = 0xBu;  // 0604A2F4 mov #11,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A2FAu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A2FAu) return; }  // 0604A2F6 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A2FA mov r0,r1
    c.r[5] = c.r[1];  // 0604A2FC mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A302u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A302u) return; }  // 0604A2FE jsr @r8 ; mov r12,r4
    c.r[7] = ld32(0x0604A3F0u);  // 0604A302 mov.l 0x0604A3F0,r7
    c.r[5] = ld32(0x0604A3F4u);  // 0604A304 mov.l 0x0604A3F4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604A306 mov.w @r7,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0604A30Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A30Cu) return; }  // 0604A308 jsr @r10 ; mov r12,r4
    c.r[5] = 0xCu;  // 0604A30C mov #12,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A312u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A312u) return; }  // 0604A30E jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A312 mov r0,r1
    c.r[5] = c.r[1];  // 0604A314 mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A31Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A31Au) return; }  // 0604A316 jsr @r8 ; mov r12,r4
    c.r[0] = ld32(0x0604A3A8u);  // 0604A31A mov.l 0x0604A3A8,r0
    c.r[7] = ld32(0x0604A3A4u);  // 0604A31C mov.l 0x0604A3A4,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604A31E mov.b @r0,r6
    c.r[4] = 0x0u;  // 0604A320 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0604A322 extu.b r6,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604A324 mov.b @r7,r5
    c.r[0] = ld32(0x0604A3F8u);  // 0604A326 mov.l 0x0604A3F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A32Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A32Cu) return; }  // 0604A328 jsr @r0 ; extu.b r5,r5
    c.r[1] = c.r[0];  // 0604A32C mov r0,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0604A32E extu.b r1,r6
    c.r[5] = ld32(0x0604A3FCu);  // 0604A330 mov.l 0x0604A3FC,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604A336u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A336u) return; }  // 0604A332 jsr @r10 ; mov r12,r4
    c.r[5] = 0xDu;  // 0604A336 mov #13,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A33Cu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A33Cu) return; }  // 0604A338 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A33C mov r0,r1
    c.r[5] = c.r[1];  // 0604A33E mov r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604A344u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A344u) return; }  // 0604A340 jsr @r8 ; mov r12,r4
    c.r[5] = 0xEu;  // 0604A344 mov #14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A34Au; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A34Au) return; }  // 0604A346 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A34A mov r0,r1
    c.r[4] = ld32(0x0604A400u);  // 0604A34C mov.l 0x0604A400,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604A352u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A352u) return; }  // 0604A34E jsr @r8 ; mov r1,r5
    c.r[5] = 0xFu;  // 0604A352 mov #15,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A358u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A358u) return; }  // 0604A354 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A358 mov r0,r1
    c.r[4] = ld32(0x0604A404u);  // 0604A35A mov.l 0x0604A404,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604A360u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A360u) return; }  // 0604A35C jsr @r8 ; mov r1,r5
    c.r[5] = 0x10u;  // 0604A360 mov #16,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604A366u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A366u) return; }  // 0604A362 jsr @r9 ; mov #10,r4
    c.r[1] = c.r[0];  // 0604A366 mov r0,r1
    c.r[4] = ld32(0x0604A408u);  // 0604A368 mov.l 0x0604A408,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604A36Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A36Eu) return; }  // 0604A36A jsr @r8 ; mov r1,r5
    c.r[14] += 76;  // 0604A36E add #76,r14
    c.r[15] = c.r[14];  // 0604A370 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604A372 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604A374 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604A376 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604A378 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604A37A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604A37C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604A37E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604A386u);  // 0604A380 mov.w 0x0604A386,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604A382 rts ; mov.l @r15+,r8
}

void f_0604A40C(SH2Context& c) {
    ran[1208] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604A40C mov.l r14,@-r15
    c.r[3] = ld32(0x0604A4DCu);  // 0604A40E mov.l 0x0604A4DC,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A410 mov.w @r3,r2
    c.r[1] = 0xCu;  // 0604A412 mov #12,r1
    c.r[2] += 1;  // 0604A414 add #1,r2
    c.t = c.r[2] > c.r[1];  // 0604A416 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604A4CE; } }  // 0604A418 bt/s 0x0604A4CE ; mov r15,r14
    c.r[1] = c.r[2];  // 0604A41C mov r2,r1
    c.r[1] += c.r[1];  // 0604A41E add r1,r1
    c.r[0] = 0x0604A42Cu;  // 0604A420 mova 0x0604A42C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604A422 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604A424 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604A44Cu: goto L_0604A44C; case 0x0604A446u: goto L_0604A446; case 0x0604A452u: goto L_0604A452; case 0x0604A458u: goto L_0604A458; case 0x0604A486u: goto L_0604A486; case 0x0604A4B4u: goto L_0604A4B4; case 0x0604A4BAu: goto L_0604A4BA; case 0x0604A4C0u: goto L_0604A4C0; default: sh2_call(c, x); return; } }  // 0604A426 jmp @r0 ; nop
L_0604A446:
    c.r[0] = ld32(0x0604A4E0u);  // 0604A446 mov.l 0x0604A4E0,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A448 bra 0x0604A4D6 ; mov r14,r15
L_0604A44C:
    c.r[0] = ld32(0x0604A4E4u);  // 0604A44C mov.l 0x0604A4E4,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A44E bra 0x0604A4D6 ; mov r14,r15
L_0604A452:
    c.r[0] = ld32(0x0604A4E8u);  // 0604A452 mov.l 0x0604A4E8,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A454 bra 0x0604A4D6 ; mov r14,r15
L_0604A458:
    c.r[3] = ld32(0x0604A4ECu);  // 0604A458 mov.l 0x0604A4EC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604A45A mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604A45C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604A45E tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0604A472; } }  // 0604A460 bt/s 0x0604A472 ; mov r3,r2
    c.r[2] += 2;  // 0604A464 add #2,r2
    c.r[1] = 0x2u;  // 0604A466 mov #2,r1
    st8(c.r[2], c.r[1]);  // 0604A468 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0604A46A mov r3,r2
    c.r[2] += 3;  // 0604A46C add #3,r2
    c.r[1] = 0x1u; goto L_0604A47E;  // 0604A46E bra 0x0604A47E ; mov #1,r1
L_0604A472:
    c.r[2] += 2;  // 0604A472 add #2,r2
    c.r[1] = 0x1u;  // 0604A474 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0604A476 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0604A478 mov r3,r2
    c.r[2] += 3;  // 0604A47A add #3,r2
    c.r[1] = 0x0u;  // 0604A47C mov #0,r1
L_0604A47E:
    st8(c.r[2], c.r[1]);  // 0604A47E mov.b r1,@r2
    c.r[0] = ld32(0x0604A4F0u);  // 0604A480 mov.l 0x0604A4F0,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A482 bra 0x0604A4D6 ; mov r14,r15
L_0604A486:
    c.r[3] = ld32(0x0604A4ECu);  // 0604A486 mov.l 0x0604A4EC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604A488 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604A48A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604A48C tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0604A4A0; } }  // 0604A48E bt/s 0x0604A4A0 ; mov r3,r2
    c.r[2] += 2;  // 0604A492 add #2,r2
    c.r[1] = 0x2u;  // 0604A494 mov #2,r1
    st8(c.r[2], c.r[1]);  // 0604A496 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0604A498 mov r3,r2
    c.r[2] += 3;  // 0604A49A add #3,r2
    c.r[1] = 0x1u; goto L_0604A4AC;  // 0604A49C bra 0x0604A4AC ; mov #1,r1
L_0604A4A0:
    c.r[2] += 2;  // 0604A4A0 add #2,r2
    c.r[1] = 0x1u;  // 0604A4A2 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0604A4A4 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0604A4A6 mov r3,r2
    c.r[2] += 3;  // 0604A4A8 add #3,r2
    c.r[1] = 0x0u;  // 0604A4AA mov #0,r1
L_0604A4AC:
    st8(c.r[2], c.r[1]);  // 0604A4AC mov.b r1,@r2
    c.r[0] = ld32(0x0604A4F4u);  // 0604A4AE mov.l 0x0604A4F4,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A4B0 bra 0x0604A4D6 ; mov r14,r15
L_0604A4B4:
    c.r[0] = ld32(0x0604A4F8u);  // 0604A4B4 mov.l 0x0604A4F8,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A4B6 bra 0x0604A4D6 ; mov r14,r15
L_0604A4BA:
    c.r[0] = ld32(0x0604A4FCu);  // 0604A4BA mov.l 0x0604A4FC,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A4BC bra 0x0604A4D6 ; mov r14,r15
L_0604A4C0:
    c.r[1] = ld32(0x0604A500u);  // 0604A4C0 mov.l 0x0604A500,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A4C2 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 0604A4C4 and #191,r0
    st8(c.r[1], c.r[0]);  // 0604A4C6 mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604A4DAu);  // 0604A4C8 mov.w 0x0604A4DA,r0
    c.r[15] = c.r[14]; goto L_0604A4D6;  // 0604A4CA bra 0x0604A4D6 ; mov r14,r15
L_0604A4CE:
    c.r[1] = 0x0u;  // 0604A4CE mov #0,r1
    st16(c.r[3], c.r[1]);  // 0604A4D0 mov.w r1,@r3
    c.r[0] = ld32(0x0604A504u);  // 0604A4D2 mov.l 0x0604A504,r0
    c.r[15] = c.r[14];  // 0604A4D4 mov r14,r15
L_0604A4D6:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604A4D6 rts ; mov.l @r15+,r14
}

void f_0604A508(SH2Context& c) {
    ran[1209] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604A508 mov.l r14,@-r15
    c.r[3] = ld32(0x0604A584u);  // 0604A50A mov.l 0x0604A584,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A50C mov.w @r3,r2
    c.r[1] = 0x9u;  // 0604A50E mov #9,r1
    c.r[2] += 1;  // 0604A510 add #1,r2
    c.t = c.r[2] > c.r[1];  // 0604A512 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604A576; } }  // 0604A514 bt/s 0x0604A576 ; mov r15,r14
    c.r[1] = c.r[2];  // 0604A518 mov r2,r1
    c.r[1] += c.r[1];  // 0604A51A add r1,r1
    c.r[0] = 0x0604A528u;  // 0604A51C mova 0x0604A528,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604A51E mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604A520 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604A53Cu: goto L_0604A53C; case 0x0604A542u: goto L_0604A542; case 0x0604A548u: goto L_0604A548; default: sh2_call(c, x); return; } }  // 0604A522 jmp @r0 ; nop
L_0604A53C:
    c.r[0] = ld32(0x0604A588u);  // 0604A53C mov.l 0x0604A588,r0
    c.r[15] = c.r[14]; goto L_0604A57E;  // 0604A53E bra 0x0604A57E ; mov r14,r15
L_0604A542:
    c.r[0] = ld32(0x0604A58Cu);  // 0604A542 mov.l 0x0604A58C,r0
    c.r[15] = c.r[14]; goto L_0604A57E;  // 0604A544 bra 0x0604A57E ; mov r14,r15
L_0604A548:
    c.r[3] = ld32(0x0604A590u);  // 0604A548 mov.l 0x0604A590,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604A54A mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604A54C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604A54E tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0604A562; } }  // 0604A550 bt/s 0x0604A562 ; mov r3,r2
    c.r[2] += 2;  // 0604A554 add #2,r2
    c.r[1] = 0x2u;  // 0604A556 mov #2,r1
    st8(c.r[2], c.r[1]);  // 0604A558 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0604A55A mov r3,r2
    c.r[2] += 3;  // 0604A55C add #3,r2
    c.r[1] = 0x1u; goto L_0604A56E;  // 0604A55E bra 0x0604A56E ; mov #1,r1
L_0604A562:
    c.r[2] += 2;  // 0604A562 add #2,r2
    c.r[1] = 0x1u;  // 0604A564 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0604A566 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0604A568 mov r3,r2
    c.r[2] += 3;  // 0604A56A add #3,r2
    c.r[1] = 0x0u;  // 0604A56C mov #0,r1
L_0604A56E:
    st8(c.r[2], c.r[1]);  // 0604A56E mov.b r1,@r2
    c.r[0] = ld32(0x0604A594u);  // 0604A570 mov.l 0x0604A594,r0
    c.r[15] = c.r[14]; goto L_0604A57E;  // 0604A572 bra 0x0604A57E ; mov r14,r15
L_0604A576:
    c.r[1] = 0x0u;  // 0604A576 mov #0,r1
    st16(c.r[3], c.r[1]);  // 0604A578 mov.w r1,@r3
    c.r[0] = ld32(0x0604A598u);  // 0604A57A mov.l 0x0604A598,r0
    c.r[15] = c.r[14];  // 0604A57C mov r14,r15
L_0604A57E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604A57E rts ; mov.l @r15+,r14
}

void f_0604A59C(SH2Context& c) {
    ran[1210] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604A59C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604A59E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604A5A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604A5A2 sts.l pr,@-r15
    c.r[15] -= 64;  // 0604A5A4 add #-64,r15
    c.r[1] = ld32(0x0604A770u);  // 0604A5A6 mov.l 0x0604A770,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A5A8 mov.w @r1,r2
    c.r[1] = 0x9u;  // 0604A5AA mov #9,r1
    c.r[2] += 1;  // 0604A5AC add #1,r2
    c.t = c.r[2] > c.r[1];  // 0604A5AE cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604A5B8; } }  // 0604A5B0 bf/s 0x0604A5B8 ; mov r15,r14
    goto L_0604A758;  // 0604A5B4 bra 0x0604A758 ; nop
L_0604A5B8:
    c.r[1] = c.r[2];  // 0604A5B8 mov r2,r1
    c.r[1] += c.r[1];  // 0604A5BA add r1,r1
    c.r[0] = 0x0604A5C8u;  // 0604A5BC mova 0x0604A5C8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604A5BE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604A5C0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604A5DCu: goto L_0604A5DC; case 0x0604A63Cu: goto L_0604A63C; case 0x0604A652u: goto L_0604A652; case 0x0604A69Cu: goto L_0604A69C; case 0x0604A6A6u: goto L_0604A6A6; case 0x0604A6BCu: goto L_0604A6BC; case 0x0604A6E0u: goto L_0604A6E0; case 0x0604A6E6u: goto L_0604A6E6; case 0x0604A6F8u: goto L_0604A6F8; case 0x0604A718u: goto L_0604A718; default: sh2_call(c, x); return; } }  // 0604A5C2 jmp @r0 ; nop
L_0604A5DC:
    c.r[3] = ld32(0x0604A774u);  // 0604A5DC mov.l 0x0604A774,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A5DE mov.w @r3,r1
    c.r[2] = 0x3Fu;  // 0604A5E0 mov #63,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0604A5E2 exts.w r1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604A5E4 cmp/gt r2,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0604A5F6; } }  // 0604A5E6 bt/s 0x0604A5F6 ; mov #0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A5EA mov.w @r3,r1
    c.r[1] += 1;  // 0604A5EC add #1,r1
    st16(c.r[3], c.r[1]);  // 0604A5EE mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A5F0 mov.w @r3,r1
    goto L_0604A5F8;  // 0604A5F2 bra 0x0604A5F8 ; nop
L_0604A5F6:
    st16(c.r[3], c.r[1]);  // 0604A5F6 mov.w r1,@r3
L_0604A5F8:
    c.r[8] = ld32(0x0604A778u);  // 0604A5F8 mov.l 0x0604A778,r8
    c.r[9] = ld32(0x0604A77Cu);  // 0604A5FA mov.l 0x0604A77C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A5FC mov.b @r8,r1
    c.r[5] = ld32(0x0604A780u);  // 0604A5FE mov.l 0x0604A780,r5
    c.r[2] = ld32(c.r[9]);  // 0604A600 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604A602 extu.b r1,r1
    c.r[0] = c.r[2];  // 0604A604 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604A606 mov.b @(r0,r1),r6
    c.r[4] = c.r[14];  // 0604A608 mov r14,r4
    c.r[0] = ld32(0x0604A784u);  // 0604A60A mov.l 0x0604A784,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A610u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A610u) return; }  // 0604A60C jsr @r0 ; extu.b r6,r6
    c.r[5] = 0x6u;  // 0604A610 mov #6,r5
    c.r[0] = ld32(0x0604A788u);  // 0604A612 mov.l 0x0604A788,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A618u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A618u) return; }  // 0604A614 jsr @r0 ; mov #10,r4
    c.r[2] = c.r[0];  // 0604A618 mov r0,r2
    c.r[1] = ld32(0x0604A78Cu);  // 0604A61A mov.l 0x0604A78C,r1
    c.r[5] = c.r[2];  // 0604A61C mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604A622u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A622u) return; }  // 0604A61E jsr @r1 ; mov r14,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A622 mov.b @r8,r1
    c.r[6] = 0x0u;  // 0604A624 mov #0,r6
    c.r[2] = ld32(c.r[9]);  // 0604A626 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604A628 extu.b r1,r1
    c.r[8] += 10;  // 0604A62A add #10,r8
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604A62C mov.w @r8,r5
    c.r[0] = c.r[2];  // 0604A62E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604A630 mov.b @(r0,r1),r1
L_0604A632:
    c.r[4] = 0x0u;  // 0604A632 mov #0,r4
    c.r[5] += c.r[1];  // 0604A634 add r1,r5
    c.r[0] = ld32(0x0604A790u);  // 0604A636 mov.l 0x0604A790,r0
    c.r[5] = c.r[5] & 0xFFu; goto L_0604A754;  // 0604A638 bra 0x0604A754 ; extu.b r5,r5
L_0604A63C:
    c.r[3] = ld32(0x0604A794u);  // 0604A63C mov.l 0x0604A794,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A63E mov.w @r3,r2
    c.r[1] = 0x3Fu;  // 0604A640 mov #63,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604A642 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0604A64E; } }  // 0604A644 bt/s 0x0604A64E ; mov #0,r1
    c.r[0] = ld32(0x0604A798u);  // 0604A648 mov.l 0x0604A798,r0
    c.r[14] += 64; goto L_0604A75C;  // 0604A64A bra 0x0604A75C ; add #64,r14
L_0604A64E:
    st16(c.r[3], c.r[1]); goto L_0604A758;  // 0604A64E bra 0x0604A758 ; mov.w r1,@r3
L_0604A652:
    c.r[6] = ld32(0x0604A778u);  // 0604A652 mov.l 0x0604A778,r6
    c.r[1] = c.r[6];  // 0604A654 mov r6,r1
    c.r[1] += 10;  // 0604A656 add #10,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A658 mov.w @r1,r3
    c.r[2] = ld32(0x0604A77Cu);  // 0604A65A mov.l 0x0604A77C,r2
    c.r[7] = ld32(c.r[2]);  // 0604A65C mov.l @r2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604A65E mov.b @r6,r1
    c.r[0] = c.r[7];  // 0604A660 mov r7,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604A662 extu.b r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604A664 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604A768u);  // 0604A666 mov.w 0x0604A768,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604A668 extu.b r1,r1
    c.r[1] += c.r[3];  // 0604A66A add r3,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604A66C cmp/gt r2,r1
    if (c.t) { goto L_0604A67C; }  // 0604A66E bt 0x0604A67C
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604A670 mov.b @r6,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604A672 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604A674 mov.b @(r0,r2),r1
    c.r[1] += 1;  // 0604A676 add #1,r1
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0604A686;  // 0604A678 bra 0x0604A686 ; mov.b r1,@(r0,r2)
L_0604A67C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604A67C mov.b @r6,r1
    c.r[2] = 0x0u;  // 0604A67E mov #0,r2
    c.r[0] = c.r[7];  // 0604A680 mov r7,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604A682 extu.b r1,r1
    st8(c.r[0] + c.r[1], c.r[2]);  // 0604A684 mov.b r2,@(r0,r1)
L_0604A686:
    c.r[2] = ld32(0x0604A778u);  // 0604A686 mov.l 0x0604A778,r2
    c.r[1] = ld32(0x0604A77Cu);  // 0604A688 mov.l 0x0604A77C,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604A68A mov.b @r2,r3
    c.r[6] = 0x0u;  // 0604A68C mov #0,r6
    c.r[1] = ld32(c.r[1]);  // 0604A68E mov.l @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0604A690 extu.b r3,r3
    c.r[2] += 10;  // 0604A692 add #10,r2
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604A694 mov.w @r2,r5
    c.r[0] = c.r[1];  // 0604A696 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); SH2_POLL(c); goto L_0604A632;  // 0604A698 bra 0x0604A632 ; mov.b @(r0,r3),r1
L_0604A69C:
    c.r[1] = ld32(0x0604A79Cu);  // 0604A69C mov.l 0x0604A79C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A69E mov.w @r1,r0
    c.r[0] ^= 0x1u;  // 0604A6A0 xor #1,r0
    st16(c.r[1], c.r[0]); goto L_0604A758;  // 0604A6A2 bra 0x0604A758 ; mov.w r0,@r1
L_0604A6A6:
    c.r[3] = ld32(0x0604A7A0u);  // 0604A6A6 mov.l 0x0604A7A0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A6A8 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604A76Au);  // 0604A6AA mov.w 0x0604A76A,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604A6AC cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0604A6B8; } }  // 0604A6AE bt/s 0x0604A6B8 ; mov #1,r1
    c.r[0] = ld32(0x0604A7A4u);  // 0604A6B2 mov.l 0x0604A7A4,r0
    c.r[14] += 64; goto L_0604A75C;  // 0604A6B4 bra 0x0604A75C ; add #64,r14
L_0604A6B8:
    st16(c.r[3], c.r[1]); goto L_0604A758;  // 0604A6B8 bra 0x0604A758 ; mov.w r1,@r3
L_0604A6BC:
    c.r[8] = ld32(0x0604A7A8u);  // 0604A6BC mov.l 0x0604A7A8,r8
    c.r[1] = c.r[8];  // 0604A6BE mov r8,r1
    c.r[1] += 23;  // 0604A6C0 add #23,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A6C2 mov.b @r1,r4
    c.r[0] = ld32(0x0604A7ACu);  // 0604A6C4 mov.l 0x0604A7AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A6CAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A6CAu) return; }  // 0604A6C6 jsr @r0 ; extu.b r4,r4
    c.r[8] += 24;  // 0604A6CA add #24,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604A6CC mov.w @r8,r1
    c.r[2] = c.r[0] & 0xFFFFu;  // 0604A6CE extu.w r0,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0604A6D0 cmp/ge r2,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0604A6DC; } }  // 0604A6D2 bt/s 0x0604A6DC ; mov #1,r1
    c.r[0] = ld32(0x0604A7B0u);  // 0604A6D6 mov.l 0x0604A7B0,r0
    c.r[14] += 64; goto L_0604A75C;  // 0604A6D8 bra 0x0604A75C ; add #64,r14
L_0604A6DC:
    st16(c.r[8], c.r[1]); goto L_0604A758;  // 0604A6DC bra 0x0604A758 ; mov.w r1,@r8
L_0604A6E0:
    c.r[0] = ld32(0x0604A7B4u);  // 0604A6E0 mov.l 0x0604A7B4,r0
    c.r[14] += 64; goto L_0604A75C;  // 0604A6E2 bra 0x0604A75C ; add #64,r14
L_0604A6E6:
    c.r[3] = ld32(0x0604A7B8u);  // 0604A6E6 mov.l 0x0604A7B8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A6E8 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604A76Cu);  // 0604A6EA mov.w 0x0604A76C,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604A6EC cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { SH2_POLL(c); goto L_0604A64E; } }  // 0604A6EE bt/s 0x0604A64E ; mov #0,r1
    c.r[0] = ld32(0x0604A7BCu);  // 0604A6F2 mov.l 0x0604A7BC,r0
    c.r[14] += 64; goto L_0604A75C;  // 0604A6F4 bra 0x0604A75C ; add #64,r14
L_0604A6F8:
    c.r[3] = ld32(0x0604A7A8u);  // 0604A6F8 mov.l 0x0604A7A8,r3
    c.r[1] = c.r[3];  // 0604A6FA mov r3,r1
    c.r[1] += 26;  // 0604A6FC add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A6FE mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604A700 tst r1,r1
    { const bool k = c.t; c.r[2] = 0x40u; if (k) { goto L_0604A708; } }  // 0604A702 bt/s 0x0604A708 ; mov #64,r2
    c.r[2] = 0x10u;  // 0604A706 mov #16,r2
L_0604A708:
    c.r[3] += 28;  // 0604A708 add #28,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A70A mov.w @r3,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0604A70C cmp/ge r2,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { SH2_POLL(c); goto L_0604A6B8; } }  // 0604A70E bt/s 0x0604A6B8 ; mov #1,r1
    c.r[0] = ld32(0x0604A7C0u);  // 0604A712 mov.l 0x0604A7C0,r0
    c.r[14] += 64; goto L_0604A75C;  // 0604A714 bra 0x0604A75C ; add #64,r14
L_0604A718:
    c.r[8] = ld32(0x0604A7C4u);  // 0604A718 mov.l 0x0604A7C4,r8
    c.r[1] = c.r[8];  // 0604A71A mov r8,r1
    c.r[1] += 1;  // 0604A71C add #1,r1
    c.r[0] = ld32(0x0604A7C8u);  // 0604A71E mov.l 0x0604A7C8,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A720 mov.b @r1,r6
    c.r[4] = 0x1u;  // 0604A722 mov #1,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A724 mov.b @r8,r5
    c.r[6] = c.r[6] & 0xFFu;  // 0604A726 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604A72Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A72Cu) return; }  // 0604A728 jsr @r0 ; extu.b r5,r5
    c.r[9] = c.r[0] & 0xFFu;  // 0604A72C extu.b r0,r9
    c.r[5] = ld32(0x0604A7CCu);  // 0604A72E mov.l 0x0604A7CC,r5
    c.r[0] = ld32(0x0604A784u);  // 0604A730 mov.l 0x0604A784,r0
    c.r[6] = c.r[9];  // 0604A732 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604A738u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A738u) return; }  // 0604A734 jsr @r0 ; mov r14,r4
    c.r[0] = ld32(0x0604A788u);  // 0604A738 mov.l 0x0604A788,r0
    c.r[5] = 0xDu;  // 0604A73A mov #13,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604A740u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A740u) return; }  // 0604A73C jsr @r0 ; mov #10,r4
    c.r[1] = ld32(0x0604A78Cu);  // 0604A740 mov.l 0x0604A78C,r1
    c.r[5] = c.r[0];  // 0604A742 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604A748u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A748u) return; }  // 0604A744 jsr @r1 ; mov r14,r4
    c.r[8] += 2;  // 0604A748 add #2,r8
    c.r[0] = ld32(0x0604A790u);  // 0604A74A mov.l 0x0604A790,r0
    c.r[6] = 0x0u;  // 0604A74C mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A74E mov.b @r8,r4
    c.r[5] = c.r[9];  // 0604A750 mov r9,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0604A752 extu.b r4,r4
L_0604A754:
    { const uint32_t x = c.r[0]; c.pr = 0x0604A758u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A758u) return; }  // 0604A754 jsr @r0 ; nop
L_0604A758:
    c.r[0] = ld32(0x0604A7D0u);  // 0604A758 mov.l 0x0604A7D0,r0
    c.r[14] += 64;  // 0604A75A add #64,r14
L_0604A75C:
    c.r[15] = c.r[14];  // 0604A75C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604A75E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604A760 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604A762 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604A764 rts ; mov.l @r15+,r8
}

void f_0604A7D4(SH2Context& c) {
    ran[1211] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604A7D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604A7D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604A7D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604A7DA sts.l pr,@-r15
    c.r[15] -= 64;  // 0604A7DC add #-64,r15
    c.r[1] = ld32(0x0604A9B0u);  // 0604A7DE mov.l 0x0604A9B0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A7E0 mov.w @r1,r2
    c.r[1] = 0x9u;  // 0604A7E2 mov #9,r1
    c.r[2] += 1;  // 0604A7E4 add #1,r2
    c.t = c.r[2] > c.r[1];  // 0604A7E6 cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604A7F0; } }  // 0604A7E8 bf/s 0x0604A7F0 ; mov r15,r14
    goto L_0604A99A;  // 0604A7EC bra 0x0604A99A ; nop
L_0604A7F0:
    c.r[1] = c.r[2];  // 0604A7F0 mov r2,r1
    c.r[1] += c.r[1];  // 0604A7F2 add r1,r1
    c.r[0] = 0x0604A800u;  // 0604A7F4 mova 0x0604A800,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604A7F6 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0604A7F8 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0604A814u: goto L_0604A814; case 0x0604A874u: goto L_0604A874; case 0x0604A88Au: goto L_0604A88A; case 0x0604A8D2u: goto L_0604A8D2; case 0x0604A8DCu: goto L_0604A8DC; case 0x0604A8F4u: goto L_0604A8F4; case 0x0604A918u: goto L_0604A918; case 0x0604A91Eu: goto L_0604A91E; case 0x0604A934u: goto L_0604A934; case 0x0604A95Au: goto L_0604A95A; default: sh2_call(c, x); return; } }  // 0604A7FA jmp @r0 ; nop
L_0604A814:
    c.r[3] = ld32(0x0604A9B4u);  // 0604A814 mov.l 0x0604A9B4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A816 mov.w @r3,r1
    c.r[2] = 0xFFFFFFC0u;  // 0604A818 mov #-64,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0604A81A exts.w r1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0604A81C cmp/gt r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0604A82E; } }  // 0604A81E bf/s 0x0604A82E ; mov #0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A822 mov.w @r3,r1
    c.r[1] -= 1;  // 0604A824 add #-1,r1
    st16(c.r[3], c.r[1]);  // 0604A826 mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A828 mov.w @r3,r1
    goto L_0604A830;  // 0604A82A bra 0x0604A830 ; nop
L_0604A82E:
    st16(c.r[3], c.r[1]);  // 0604A82E mov.w r1,@r3
L_0604A830:
    c.r[8] = ld32(0x0604A9B8u);  // 0604A830 mov.l 0x0604A9B8,r8
    c.r[9] = ld32(0x0604A9BCu);  // 0604A832 mov.l 0x0604A9BC,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A834 mov.b @r8,r1
    c.r[5] = ld32(0x0604A9C0u);  // 0604A836 mov.l 0x0604A9C0,r5
    c.r[2] = ld32(c.r[9]);  // 0604A838 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604A83A extu.b r1,r1
    c.r[0] = c.r[2];  // 0604A83C mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604A83E mov.b @(r0,r1),r6
    c.r[4] = c.r[14];  // 0604A840 mov r14,r4
    c.r[0] = ld32(0x0604A9C4u);  // 0604A842 mov.l 0x0604A9C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A848u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A848u) return; }  // 0604A844 jsr @r0 ; extu.b r6,r6
    c.r[5] = 0x6u;  // 0604A848 mov #6,r5
    c.r[0] = ld32(0x0604A9C8u);  // 0604A84A mov.l 0x0604A9C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A850u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A850u) return; }  // 0604A84C jsr @r0 ; mov #10,r4
    c.r[2] = c.r[0];  // 0604A850 mov r0,r2
    c.r[1] = ld32(0x0604A9CCu);  // 0604A852 mov.l 0x0604A9CC,r1
    c.r[5] = c.r[2];  // 0604A854 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604A85Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A85Au) return; }  // 0604A856 jsr @r1 ; mov r14,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A85A mov.b @r8,r1
    c.r[6] = 0x0u;  // 0604A85C mov #0,r6
    c.r[2] = ld32(c.r[9]);  // 0604A85E mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604A860 extu.b r1,r1
    c.r[8] += 10;  // 0604A862 add #10,r8
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604A864 mov.w @r8,r5
    c.r[0] = c.r[2];  // 0604A866 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604A868 mov.b @(r0,r1),r1
L_0604A86A:
    c.r[4] = 0x0u;  // 0604A86A mov #0,r4
    c.r[5] += c.r[1];  // 0604A86C add r1,r5
    c.r[0] = ld32(0x0604A9D0u);  // 0604A86E mov.l 0x0604A9D0,r0
    c.r[5] = c.r[5] & 0xFFu; goto L_0604A996;  // 0604A870 bra 0x0604A996 ; extu.b r5,r5
L_0604A874:
    c.r[2] = ld32(0x0604A9D4u);  // 0604A874 mov.l 0x0604A9D4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604A876 mov.w @r2,r1
    c.t = (int32_t)c.r[1] > 0;  // 0604A878 cmp/pl r1
    if (!c.t) { goto L_0604A884; }  // 0604A87A bf 0x0604A884
    c.r[14] += 64;  // 0604A87C add #64,r14
    c.r[0] = ld32(0x0604A9D8u);  // 0604A87E mov.l 0x0604A9D8,r0
    c.r[15] = c.r[14]; goto L_0604A9A0;  // 0604A880 bra 0x0604A9A0 ; mov r14,r15
L_0604A884:
    c.r[1] = 0x40u;  // 0604A884 mov #64,r1
    st16(c.r[2], c.r[1]); goto L_0604A99A;  // 0604A886 bra 0x0604A99A ; mov.w r1,@r2
L_0604A88A:
    c.r[6] = ld32(0x0604A9B8u);  // 0604A88A mov.l 0x0604A9B8,r6
    c.r[1] = c.r[6];  // 0604A88C mov r6,r1
    c.r[1] += 10;  // 0604A88E add #10,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A890 mov.w @r1,r3
    c.r[2] = ld32(0x0604A9BCu);  // 0604A892 mov.l 0x0604A9BC,r2
    c.r[7] = ld32(c.r[2]);  // 0604A894 mov.l @r2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604A896 mov.b @r6,r1
    c.r[0] = c.r[7];  // 0604A898 mov r7,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604A89A extu.b r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604A89C mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604A89E extu.b r1,r1
    c.r[1] += c.r[3];  // 0604A8A0 add r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0604A8A2 cmp/pl r1
    if (!c.t) { goto L_0604A8B2; }  // 0604A8A4 bf 0x0604A8B2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604A8A6 mov.b @r6,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604A8A8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0604A8AA mov.b @(r0,r2),r1
    c.r[1] -= 1;  // 0604A8AC add #-1,r1
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0604A8BC;  // 0604A8AE bra 0x0604A8BC ; mov.b r1,@(r0,r2)
L_0604A8B2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0604A8B2 mov.b @r6,r1
    c.r[2] = 0xFFFFFFFFu;  // 0604A8B4 mov #-1,r2
    c.r[0] = c.r[7];  // 0604A8B6 mov r7,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604A8B8 extu.b r1,r1
    st8(c.r[0] + c.r[1], c.r[2]);  // 0604A8BA mov.b r2,@(r0,r1)
L_0604A8BC:
    c.r[2] = ld32(0x0604A9B8u);  // 0604A8BC mov.l 0x0604A9B8,r2
    c.r[1] = ld32(0x0604A9BCu);  // 0604A8BE mov.l 0x0604A9BC,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604A8C0 mov.b @r2,r3
    c.r[6] = 0x0u;  // 0604A8C2 mov #0,r6
    c.r[1] = ld32(c.r[1]);  // 0604A8C4 mov.l @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0604A8C6 extu.b r3,r3
    c.r[2] += 10;  // 0604A8C8 add #10,r2
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604A8CA mov.w @r2,r5
    c.r[0] = c.r[1];  // 0604A8CC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); SH2_POLL(c); goto L_0604A86A;  // 0604A8CE bra 0x0604A86A ; mov.b @(r0,r3),r1
L_0604A8D2:
    c.r[1] = ld32(0x0604A9DCu);  // 0604A8D2 mov.l 0x0604A9DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604A8D4 mov.w @r1,r0
    c.r[0] ^= 0x1u;  // 0604A8D6 xor #1,r0
    st16(c.r[1], c.r[0]); goto L_0604A99A;  // 0604A8D8 bra 0x0604A99A ; mov.w r0,@r1
L_0604A8DC:
    c.r[3] = ld32(0x0604A9E0u);  // 0604A8DC mov.l 0x0604A9E0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A8DE mov.w @r3,r2
    c.r[1] = 0x1u;  // 0604A8E0 mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604A8E2 cmp/gt r1,r2
    if (!c.t) { goto L_0604A8EE; }  // 0604A8E4 bf 0x0604A8EE
    c.r[14] += 64;  // 0604A8E6 add #64,r14
    c.r[0] = ld32(0x0604A9E4u);  // 0604A8E8 mov.l 0x0604A9E4,r0
    c.r[15] = c.r[14]; goto L_0604A9A0;  // 0604A8EA bra 0x0604A9A0 ; mov r14,r15
L_0604A8EE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604A9AAu);  // 0604A8EE mov.w 0x0604A9AA,r1
    st16(c.r[3], c.r[1]); goto L_0604A99A;  // 0604A8F0 bra 0x0604A99A ; mov.w r1,@r3
L_0604A8F4:
    c.r[4] = ld32(0x0604A9E8u);  // 0604A8F4 mov.l 0x0604A9E8,r4
    c.r[8] = c.r[4];  // 0604A8F6 mov r4,r8
    c.r[8] += 24;  // 0604A8F8 add #24,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604A8FA mov.w @r8,r2
    c.r[1] = 0x1u;  // 0604A8FC mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604A8FE cmp/gt r1,r2
    if (!c.t) { goto L_0604A90A; }  // 0604A900 bf 0x0604A90A
    c.r[14] += 64;  // 0604A902 add #64,r14
    c.r[0] = ld32(0x0604A9ECu);  // 0604A904 mov.l 0x0604A9EC,r0
    c.r[15] = c.r[14]; goto L_0604A9A0;  // 0604A906 bra 0x0604A9A0 ; mov r14,r15
L_0604A90A:
    c.r[4] += 23;  // 0604A90A add #23,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604A90C mov.b @r4,r4
    c.r[0] = ld32(0x0604A9F0u);  // 0604A90E mov.l 0x0604A9F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604A914u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A914u) return; }  // 0604A910 jsr @r0 ; extu.b r4,r4
    st16(c.r[8], c.r[0]); goto L_0604A99A;  // 0604A914 bra 0x0604A99A ; mov.w r0,@r8
L_0604A918:
    c.r[0] = ld32(0x0604A9F4u);  // 0604A918 mov.l 0x0604A9F4,r0
    c.r[14] += 64; goto L_0604A99E;  // 0604A91A bra 0x0604A99E ; add #64,r14
L_0604A91E:
    c.r[2] = ld32(0x0604A9F8u);  // 0604A91E mov.l 0x0604A9F8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604A920 mov.w @r2,r1
    c.t = (int32_t)c.r[1] > 0;  // 0604A922 cmp/pl r1
    if (!c.t) { goto L_0604A92E; }  // 0604A924 bf 0x0604A92E
    c.r[14] += 64;  // 0604A926 add #64,r14
    c.r[0] = ld32(0x0604A9FCu);  // 0604A928 mov.l 0x0604A9FC,r0
    c.r[15] = c.r[14]; goto L_0604A9A0;  // 0604A92A bra 0x0604A9A0 ; mov r14,r15
L_0604A92E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604A9ACu);  // 0604A92E mov.w 0x0604A9AC,r1
    st16(c.r[2], c.r[1]); goto L_0604A99A;  // 0604A930 bra 0x0604A99A ; mov.w r1,@r2
L_0604A934:
    c.r[3] = ld32(0x0604A9E8u);  // 0604A934 mov.l 0x0604A9E8,r3
    c.r[7] = c.r[3];  // 0604A936 mov r3,r7
    c.r[7] += 28;  // 0604A938 add #28,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604A93A mov.w @r7,r2
    c.r[1] = 0x1u;  // 0604A93C mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0604A93E cmp/gt r1,r2
    if (!c.t) { goto L_0604A94A; }  // 0604A940 bf 0x0604A94A
    c.r[14] += 64;  // 0604A942 add #64,r14
    c.r[0] = ld32(0x0604AA00u);  // 0604A944 mov.l 0x0604AA00,r0
    c.r[15] = c.r[14]; goto L_0604A9A0;  // 0604A946 bra 0x0604A9A0 ; mov r14,r15
L_0604A94A:
    c.r[3] += 26;  // 0604A94A add #26,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0604A94C mov.w @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604A94E tst r1,r1
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_0604A956; } }  // 0604A950 bt/s 0x0604A956 ; mov #64,r1
    c.r[1] = 0x10u;  // 0604A954 mov #16,r1
L_0604A956:
    st16(c.r[7], c.r[1]); goto L_0604A99A;  // 0604A956 bra 0x0604A99A ; mov.w r1,@r7
L_0604A95A:
    c.r[8] = ld32(0x0604AA04u);  // 0604A95A mov.l 0x0604AA04,r8
    c.r[1] = c.r[8];  // 0604A95C mov r8,r1
    c.r[1] += 1;  // 0604A95E add #1,r1
    c.r[0] = ld32(0x0604AA08u);  // 0604A960 mov.l 0x0604AA08,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604A962 mov.b @r1,r6
    c.r[4] = 0xFFFFFFFFu;  // 0604A964 mov #-1,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A966 mov.b @r8,r5
    c.r[6] = c.r[6] & 0xFFu;  // 0604A968 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604A96Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A96Eu) return; }  // 0604A96A jsr @r0 ; extu.b r5,r5
    c.r[9] = c.r[0] & 0xFFu;  // 0604A96E extu.b r0,r9
    c.r[5] = ld32(0x0604AA0Cu);  // 0604A970 mov.l 0x0604AA0C,r5
    c.r[0] = ld32(0x0604A9C4u);  // 0604A972 mov.l 0x0604A9C4,r0
    c.r[6] = c.r[9];  // 0604A974 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0604A97Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A97Au) return; }  // 0604A976 jsr @r0 ; mov r14,r4
    c.r[0] = ld32(0x0604A9C8u);  // 0604A97A mov.l 0x0604A9C8,r0
    c.r[5] = 0xDu;  // 0604A97C mov #13,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604A982u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A982u) return; }  // 0604A97E jsr @r0 ; mov #10,r4
    c.r[1] = ld32(0x0604A9CCu);  // 0604A982 mov.l 0x0604A9CC,r1
    c.r[5] = c.r[0];  // 0604A984 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604A98Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A98Au) return; }  // 0604A986 jsr @r1 ; mov r14,r4
    c.r[8] += 2;  // 0604A98A add #2,r8
    c.r[0] = ld32(0x0604A9D0u);  // 0604A98C mov.l 0x0604A9D0,r0
    c.r[6] = 0x0u;  // 0604A98E mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604A990 mov.b @r8,r4
    c.r[5] = c.r[9];  // 0604A992 mov r9,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0604A994 extu.b r4,r4
L_0604A996:
    { const uint32_t x = c.r[0]; c.pr = 0x0604A99Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604A99Au) return; }  // 0604A996 jsr @r0 ; nop
L_0604A99A:
    c.r[0] = ld32(0x0604AA10u);  // 0604A99A mov.l 0x0604AA10,r0
    c.r[14] += 64;  // 0604A99C add #64,r14
L_0604A99E:
    c.r[15] = c.r[14];  // 0604A99E mov r14,r15
L_0604A9A0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604A9A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604A9A2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604A9A4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604A9A6 rts ; mov.l @r15+,r8
}

void f_0604ABBC(SH2Context& c) {
    ran[1212] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604ABBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604ABBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604ABC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604ABC2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604ABC4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604ABC6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604ABC8 mov r15,r14
    c.r[1] = ld32(0x0604ACB4u);  // 0604ABCA mov.l 0x0604ACB4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604ABCC mov.w @r1,r1
    c.r[10] = ld32(0x0604ACB8u);  // 0604ABCE mov.l 0x0604ACB8,r10
    c.r[5] = 0xFu;  // 0604ABD0 mov #15,r5
    c.r[4] = 0xAu;  // 0604ABD2 mov #10,r4
    c.r[8] = c.r[1] & 0xFFFFu;  // 0604ABD4 extu.w r1,r8
    { const uint32_t x = c.r[10]; c.pr = 0x0604ABDAu; c.r[9] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604ABDAu) return; }  // 0604ABD6 jsr @r10 ; mov r8,r9
    c.r[4] = ld32(0x0604ACBCu);  // 0604ABDA mov.l 0x0604ACBC,r4
    c.r[11] = ld32(0x0604ACC0u);  // 0604ABDC mov.l 0x0604ACC0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0604ABE2u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604ABE2u) return; }  // 0604ABDE jsr @r11 ; mov r0,r5
    c.r[8] >>= 8;  // 0604ABE2 shlr8 r8
    c.r[2] = 0x1u;  // 0604ABE4 mov #1,r2
    c.r[8] &= c.r[2];  // 0604ABE6 and r2,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604ABE8 tst r8,r8
    { const bool k = c.t; c.r[9] >>= 8; if (k) { goto L_0604ABF4; } }  // 0604ABEA bt/s 0x0604ABF4 ; shlr8 r9
    c.r[0] = ld32(0x0604ACC4u);  // 0604ABEE mov.l 0x0604ACC4,r0
    c.r[15] = c.r[14]; goto L_0604ACA4;  // 0604ABF0 bra 0x0604ACA4 ; mov r14,r15
L_0604ABF4:
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0604ABF4 shlr r9
    c.r[2] = 0x1u;  // 0604ABF6 mov #1,r2
    c.r[9] &= c.r[2];  // 0604ABF8 and r2,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0604ABFA tst r9,r9
    if (c.t) { goto L_0604ACA0; }  // 0604ABFC bt 0x0604ACA0
    c.r[1] = ld32(0x0604ACC8u);  // 0604ABFE mov.l 0x0604ACC8,r1
    c.r[5] = ld32(c.r[1]);  // 0604AC00 mov.l @r1,r5
    c.r[4] = ld32(0x0604ACCCu);  // 0604AC02 mov.l 0x0604ACCC,r4
    c.r[9] = ld32(0x0604ACD0u);  // 0604AC04 mov.l 0x0604ACD0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0604AC0Au; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC0Au) return; }  // 0604AC06 jsr @r9 ; mov #1,r6
    c.r[8] = c.r[0];  // 0604AC0A mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604AC0C tst r8,r8
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_0604AC1C; } }  // 0604AC0E bt/s 0x0604AC1C ; mov #16,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604AC16u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC16u) return; }  // 0604AC12 jsr @r10 ; mov #10,r4
    c.r[4] = ld32(0x0604ACD4u);  // 0604AC16 mov.l 0x0604ACD4,r4
    goto L_0604AC96;  // 0604AC18 bra 0x0604AC96 ; nop
L_0604AC1C:
    c.r[1] = ld32(0x0604ACD8u);  // 0604AC1C mov.l 0x0604ACD8,r1
    c.r[5] = ld32(c.r[1]);  // 0604AC1E mov.l @r1,r5
    c.r[4] = ld32(0x0604ACDCu);  // 0604AC20 mov.l 0x0604ACDC,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604AC26u; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC26u) return; }  // 0604AC22 jsr @r9 ; mov #1,r6
    c.r[8] = c.r[0];  // 0604AC26 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604AC28 tst r8,r8
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_0604AC38; } }  // 0604AC2A bt/s 0x0604AC38 ; mov #16,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604AC32u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC32u) return; }  // 0604AC2E jsr @r10 ; mov #10,r4
    c.r[4] = ld32(0x0604ACE0u);  // 0604AC32 mov.l 0x0604ACE0,r4
    goto L_0604AC96;  // 0604AC34 bra 0x0604AC96 ; nop
L_0604AC38:
    c.r[1] = ld32(0x0604ACE4u);  // 0604AC38 mov.l 0x0604ACE4,r1
    c.r[5] = ld32(c.r[1]);  // 0604AC3A mov.l @r1,r5
    c.r[4] = ld32(0x0604ACE8u);  // 0604AC3C mov.l 0x0604ACE8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604AC42u; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC42u) return; }  // 0604AC3E jsr @r9 ; mov #1,r6
    c.r[8] = c.r[0];  // 0604AC42 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604AC44 tst r8,r8
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_0604AC54; } }  // 0604AC46 bt/s 0x0604AC54 ; mov #16,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604AC4Eu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC4Eu) return; }  // 0604AC4A jsr @r10 ; mov #10,r4
    c.r[4] = ld32(0x0604ACECu);  // 0604AC4E mov.l 0x0604ACEC,r4
    goto L_0604AC96;  // 0604AC50 bra 0x0604AC96 ; nop
L_0604AC54:
    c.r[5] = ld32(0x0604ACF0u);  // 0604AC54 mov.l 0x0604ACF0,r5
    c.r[4] = ld32(0x0604ACF4u);  // 0604AC56 mov.l 0x0604ACF4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604AC5Cu; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC5Cu) return; }  // 0604AC58 jsr @r9 ; mov #1,r6
    c.r[8] = c.r[0];  // 0604AC5C mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604AC5E tst r8,r8
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_0604AC6E; } }  // 0604AC60 bt/s 0x0604AC6E ; mov #16,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604AC68u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC68u) return; }  // 0604AC64 jsr @r10 ; mov #10,r4
    c.r[4] = ld32(0x0604ACF8u);  // 0604AC68 mov.l 0x0604ACF8,r4
    goto L_0604AC96;  // 0604AC6A bra 0x0604AC96 ; nop
L_0604AC6E:
    c.r[1] = ld32(0x0604ACFCu);  // 0604AC6E mov.l 0x0604ACFC,r1
    c.r[5] = ld32(c.r[1]);  // 0604AC70 mov.l @r1,r5
    c.r[4] = ld32(0x0604AD00u);  // 0604AC72 mov.l 0x0604AD00,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604AC78u; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC78u) return; }  // 0604AC74 jsr @r9 ; mov #1,r6
    c.r[1] = ld32(0x0604AD04u);  // 0604AC78 mov.l 0x0604AD04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604AC7Eu; c.r[8] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC7Eu) return; }  // 0604AC7A jsr @r1 ; mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604AC7E tst r8,r8
    { const bool k = c.t; c.r[5] = 0xFu; if (k) { goto L_0604AC90; } }  // 0604AC80 bt/s 0x0604AC90 ; mov #15,r5
    c.r[5] = 0x10u;  // 0604AC84 mov #16,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0604AC8Au; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC8Au) return; }  // 0604AC86 jsr @r10 ; mov #10,r4
    c.r[4] = ld32(0x0604AD08u);  // 0604AC8A mov.l 0x0604AD08,r4
    goto L_0604AC96;  // 0604AC8C bra 0x0604AC96 ; nop
L_0604AC90:
    { const uint32_t x = c.r[10]; c.pr = 0x0604AC94u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC94u) return; }  // 0604AC90 jsr @r10 ; mov #10,r4
    c.r[4] = ld32(0x0604AD0Cu);  // 0604AC94 mov.l 0x0604AD0C,r4
L_0604AC96:
    { const uint32_t x = c.r[11]; c.pr = 0x0604AC9Au; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AC9Au) return; }  // 0604AC96 jsr @r11 ; mov r0,r5
    c.r[0] = ld32(0x0604ACC4u);  // 0604AC9A mov.l 0x0604ACC4,r0
    c.r[15] = c.r[14]; goto L_0604ACA4;  // 0604AC9C bra 0x0604ACA4 ; mov r14,r15
L_0604ACA0:
    c.r[0] = ld32(0x0604AD10u);  // 0604ACA0 mov.l 0x0604AD10,r0
    c.r[15] = c.r[14];  // 0604ACA2 mov r14,r15
L_0604ACA4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604ACA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604ACA6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604ACA8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604ACAA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604ACAC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604ACAE rts ; mov.l @r15+,r8
}

void f_0604ADE0(SH2Context& c) {
    ran[1213] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604ADE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604ADE2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604ADE4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604ADE6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604ADE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604ADEA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604ADEC mov r15,r14
    c.r[1] = ld32(0x0604AED8u);  // 0604ADEE mov.l 0x0604AED8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604ADF0 mov.w @r1,r1
    c.r[9] = ld32(0x0604AEDCu);  // 0604ADF2 mov.l 0x0604AEDC,r9
    c.r[5] = 0xEu;  // 0604ADF4 mov #14,r5
    c.r[4] = 0xAu;  // 0604ADF6 mov #10,r4
    c.r[8] = c.r[1] & 0xFFFFu;  // 0604ADF8 extu.w r1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0604ADFEu; c.r[10] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604ADFEu) return; }  // 0604ADFA jsr @r9 ; mov r8,r10
    c.r[4] = ld32(0x0604AEE0u);  // 0604ADFE mov.l 0x0604AEE0,r4
    c.r[11] = ld32(0x0604AEE4u);  // 0604AE00 mov.l 0x0604AEE4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0604AE06u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE06u) return; }  // 0604AE02 jsr @r11 ; mov r0,r5
    c.r[8] >>= 8;  // 0604AE06 shlr8 r8
    c.r[2] = 0x1u;  // 0604AE08 mov #1,r2
    c.r[8] &= c.r[2];  // 0604AE0A and r2,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0604AE0C tst r8,r8
    { const bool k = c.t; c.r[10] >>= 8; if (k) { goto L_0604AE18; } }  // 0604AE0E bt/s 0x0604AE18 ; shlr8 r10
    c.r[0] = ld32(0x0604AEE8u);  // 0604AE12 mov.l 0x0604AEE8,r0
    c.r[15] = c.r[14]; goto L_0604AEC4;  // 0604AE14 bra 0x0604AEC4 ; mov r14,r15
L_0604AE18:
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0604AE18 shlr r10
    c.r[2] = 0x1u;  // 0604AE1A mov #1,r2
    c.r[10] &= c.r[2];  // 0604AE1C and r2,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0604AE1E tst r10,r10
    if (c.t) { goto L_0604AEC0; }  // 0604AE20 bt 0x0604AEC0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604AED2u);  // 0604AE22 mov.w 0x0604AED2,r6
    c.r[1] = ld32(0x0604AEECu);  // 0604AE24 mov.l 0x0604AEEC,r1
    c.r[5] = ld32(c.r[1]);  // 0604AE26 mov.l @r1,r5
    c.r[4] = ld32(0x0604AEF0u);  // 0604AE28 mov.l 0x0604AEF0,r4
    c.r[8] = ld32(0x0604AEF4u);  // 0604AE2A mov.l 0x0604AEF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604AE30u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE30u) return; }  // 0604AE2C jsr @r8 ; mov #0,r7
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604AE30 tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0604AE42; } }  // 0604AE32 bt/s 0x0604AE42 ; mov #0,r7
    c.r[5] = 0x10u;  // 0604AE36 mov #16,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604AE3Cu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE3Cu) return; }  // 0604AE38 jsr @r9 ; mov #10,r4
    c.r[4] = ld32(0x0604AEF8u);  // 0604AE3C mov.l 0x0604AEF8,r4
    goto L_0604AEB6;  // 0604AE3E bra 0x0604AEB6 ; nop
L_0604AE42:
    c.r[1] = ld32(0x0604AEFCu);  // 0604AE42 mov.l 0x0604AEFC,r1
    c.r[5] = ld32(c.r[1]);  // 0604AE44 mov.l @r1,r5
    c.r[4] = ld32(0x0604AF00u);  // 0604AE46 mov.l 0x0604AF00,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604AE4Cu; c.r[6] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE4Cu) return; }  // 0604AE48 jsr @r8 ; mov #64,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604AE4C tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0604AE5E; } }  // 0604AE4E bt/s 0x0604AE5E ; mov #0,r7
    c.r[5] = 0x10u;  // 0604AE52 mov #16,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604AE58u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE58u) return; }  // 0604AE54 jsr @r9 ; mov #10,r4
    c.r[4] = ld32(0x0604AF04u);  // 0604AE58 mov.l 0x0604AF04,r4
    goto L_0604AEB6;  // 0604AE5A bra 0x0604AEB6 ; nop
L_0604AE5E:
    c.r[1] = ld32(0x0604AF08u);  // 0604AE5E mov.l 0x0604AF08,r1
    c.r[5] = ld32(c.r[1]);  // 0604AE60 mov.l @r1,r5
    c.r[4] = ld32(0x0604AF0Cu);  // 0604AE62 mov.l 0x0604AF0C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604AE68u; c.r[6] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE68u) return; }  // 0604AE64 jsr @r8 ; mov #64,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604AE68 tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0604AE7A; } }  // 0604AE6A bt/s 0x0604AE7A ; mov #0,r7
    c.r[5] = 0x10u;  // 0604AE6E mov #16,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604AE74u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE74u) return; }  // 0604AE70 jsr @r9 ; mov #10,r4
    c.r[4] = ld32(0x0604AF10u);  // 0604AE74 mov.l 0x0604AF10,r4
    goto L_0604AEB6;  // 0604AE76 bra 0x0604AEB6 ; nop
L_0604AE7A:
    c.r[5] = ld32(0x0604AF14u);  // 0604AE7A mov.l 0x0604AF14,r5
    c.r[4] = ld32(0x0604AF18u);  // 0604AE7C mov.l 0x0604AF18,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604AE82u; c.r[6] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE82u) return; }  // 0604AE7E jsr @r8 ; mov #2,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604AE82 tst r0,r0
    { const bool k = c.t; c.r[5] = 0x10u; if (k) { goto L_0604AE92; } }  // 0604AE84 bt/s 0x0604AE92 ; mov #16,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604AE8Cu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE8Cu) return; }  // 0604AE88 jsr @r9 ; mov #10,r4
    c.r[4] = ld32(0x0604AF1Cu);  // 0604AE8C mov.l 0x0604AF1C,r4
    goto L_0604AEB6;  // 0604AE8E bra 0x0604AEB6 ; nop
L_0604AE92:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604AED4u);  // 0604AE92 mov.w 0x0604AED4,r6
    c.r[1] = ld32(0x0604AF20u);  // 0604AE94 mov.l 0x0604AF20,r1
    c.r[5] = ld32(c.r[1]);  // 0604AE96 mov.l @r1,r5
    c.r[4] = ld32(0x0604AF24u);  // 0604AE98 mov.l 0x0604AF24,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604AE9Eu; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AE9Eu) return; }  // 0604AE9A jsr @r8 ; mov #0,r7
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604AE9E tst r0,r0
    { const bool k = c.t; c.r[5] = 0xEu; if (k) { goto L_0604AEB0; } }  // 0604AEA0 bt/s 0x0604AEB0 ; mov #14,r5
    c.r[5] = 0x10u;  // 0604AEA4 mov #16,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604AEAAu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AEAAu) return; }  // 0604AEA6 jsr @r9 ; mov #10,r4
    c.r[4] = ld32(0x0604AF28u);  // 0604AEAA mov.l 0x0604AF28,r4
    goto L_0604AEB6;  // 0604AEAC bra 0x0604AEB6 ; nop
L_0604AEB0:
    { const uint32_t x = c.r[9]; c.pr = 0x0604AEB4u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AEB4u) return; }  // 0604AEB0 jsr @r9 ; mov #10,r4
    c.r[4] = ld32(0x0604AF2Cu);  // 0604AEB4 mov.l 0x0604AF2C,r4
L_0604AEB6:
    { const uint32_t x = c.r[11]; c.pr = 0x0604AEBAu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AEBAu) return; }  // 0604AEB6 jsr @r11 ; mov r0,r5
    c.r[0] = ld32(0x0604AEE8u);  // 0604AEBA mov.l 0x0604AEE8,r0
    c.r[15] = c.r[14]; goto L_0604AEC4;  // 0604AEBC bra 0x0604AEC4 ; mov r14,r15
L_0604AEC0:
    c.r[0] = ld32(0x0604AF30u);  // 0604AEC0 mov.l 0x0604AF30,r0
    c.r[15] = c.r[14];  // 0604AEC2 mov r14,r15
L_0604AEC4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604AEC4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604AEC6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604AEC8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604AECA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604AECC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604AECE rts ; mov.l @r15+,r8
}

void f_0604AF44(SH2Context& c) {
    ran[1214] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604AF44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604AF46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604AF48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604AF4A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604AF4C mov r15,r14
    c.r[9] = ld32(0x0604AF9Cu);  // 0604AF4E mov.l 0x0604AF9C,r9
    c.r[5] = 0x12u;  // 0604AF50 mov #18,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0604AF56u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AF56u) return; }  // 0604AF52 jsr @r9 ; mov #15,r4
    c.r[4] = ld32(0x0604AFA0u);  // 0604AF56 mov.l 0x0604AFA0,r4
    c.r[1] = ld32(0x0604AFA4u);  // 0604AF58 mov.l 0x0604AFA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604AF5Eu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AF5Eu) return; }  // 0604AF5A jsr @r1 ; mov r0,r5
    c.r[1] = ld32(0x0604AFA8u);  // 0604AF5E mov.l 0x0604AFA8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604AF60 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604AF98u);  // 0604AF62 mov.w 0x0604AF98,r2
    c.r[2] &= c.r[1];  // 0604AF64 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604AF66 tst r2,r2
    if (!c.t) { goto L_0604AF72; }  // 0604AF68 bf 0x0604AF72
    c.r[15] = c.r[14];  // 0604AF6A mov r14,r15
    c.r[0] = ld32(0x0604AFACu);  // 0604AF6C mov.l 0x0604AFAC,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0604AF90;  // 0604AF6E bra 0x0604AF90 ; lds.l @r15+,pr
L_0604AF72:
    c.r[1] = ld32(0x0604AFB0u);  // 0604AF72 mov.l 0x0604AFB0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604AF74 mov.b @r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604AF9Au);  // 0604AF76 mov.w 0x0604AF9A,r8
    c.r[5] = 0xEu;  // 0604AF78 mov #14,r5
    c.r[4] = 0x0u;  // 0604AF7A mov #0,r4
    c.r[0] |= 0x40u;  // 0604AF7C or #64,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0604AF82u; st8(c.r[1], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AF82u) return; }  // 0604AF7E jsr @r9 ; mov.b r0,@r1
    c.r[1] = ld32(0x0604AFB4u);  // 0604AF82 mov.l 0x0604AFB4,r1
    c.r[5] = c.r[8];  // 0604AF84 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604AF8Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AF8Au) return; }  // 0604AF86 jsr @r1 ; mov r0,r4
    c.r[0] = ld32(0x0604AFB8u);  // 0604AF8A mov.l 0x0604AFB8,r0
    c.r[15] = c.r[14];  // 0604AF8C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604AF8E lds.l @r15+,pr
L_0604AF90:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604AF90 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604AF92 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604AF94 rts ; mov.l @r15+,r8
}

void f_0604AFBC(SH2Context& c) {
    ran[1215] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604AFBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604AFBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604AFC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604AFC2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604AFC4 sts.l pr,@-r15
    c.r[15] -= 64;  // 0604AFC6 add #-64,r15
    c.r[14] = c.r[15];  // 0604AFC8 mov r15,r14
    c.r[8] = ld32(0x0604B03Cu);  // 0604AFCA mov.l 0x0604B03C,r8
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604AFCC mov.w @r8,r5
    c.r[9] = ld32(0x0604B040u);  // 0604AFCE mov.l 0x0604B040,r9
    c.r[4] = 0x0u;  // 0604AFD0 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604AFD6u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AFD6u) return; }  // 0604AFD2 jsr @r9 ; extu.w r5,r5
    c.r[2] = c.r[0] & 0xFFu;  // 0604AFD6 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B038u);  // 0604AFD8 mov.w 0x0604B038,r1
    c.t = c.r[2] > c.r[1];  // 0604AFDA cmp/hi r1,r2
    { const bool k = c.t; c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]); if (k) { goto L_0604AFE4; } }  // 0604AFDC bt/s 0x0604AFE4 ; mov.w @r8,r5
    c.r[4] = 0x1u; goto L_0604AFE6;  // 0604AFE0 bra 0x0604AFE6 ; mov #1,r4
L_0604AFE4:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604B03Au);  // 0604AFE4 mov.w 0x0604B03A,r4
L_0604AFE6:
    { const uint32_t x = c.r[9]; c.pr = 0x0604AFEAu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AFEAu) return; }  // 0604AFE6 jsr @r9 ; extu.w r5,r5
    c.r[10] = ld32(0x0604B044u);  // 0604AFEA mov.l 0x0604B044,r10
    c.r[8] = c.r[10];  // 0604AFEC mov r10,r8
    c.r[8] += 70;  // 0604AFEE add #70,r8
    c.r[9] = ld32(0x0604B040u);  // 0604AFF0 mov.l 0x0604B040,r9
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604AFF2 mov.w @r8,r5
    c.r[4] = 0x0u;  // 0604AFF4 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604AFFAu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604AFFAu) return; }  // 0604AFF6 jsr @r9 ; extu.w r5,r5
    c.r[6] = c.r[0] & 0xFFu;  // 0604AFFA extu.b r0,r6
    c.r[5] = ld32(0x0604B048u);  // 0604AFFC mov.l 0x0604B048,r5
    c.r[0] = ld32(0x0604B04Cu);  // 0604AFFE mov.l 0x0604B04C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604B004u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B004u) return; }  // 0604B000 jsr @r0 ; mov r14,r4
    c.r[0] = ld32(0x0604B050u);  // 0604B004 mov.l 0x0604B050,r0
    c.r[5] = 0xAu;  // 0604B006 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604B00Cu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B00Cu) return; }  // 0604B008 jsr @r0 ; mov #10,r4
    c.r[1] = ld32(0x0604B054u);  // 0604B00C mov.l 0x0604B054,r1
    c.r[5] = c.r[0];  // 0604B00E mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604B014u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B014u) return; }  // 0604B010 jsr @r1 ; mov r14,r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604B014 mov.w @r8,r5
    c.r[4] = 0x0u;  // 0604B016 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604B01Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B01Cu) return; }  // 0604B018 jsr @r9 ; extu.w r5,r5
    c.r[5] = c.r[0] & 0xFFu;  // 0604B01C extu.b r0,r5
    c.r[1] = ld32(0x0604B058u);  // 0604B01E mov.l 0x0604B058,r1
    c.r[6] = 0x1u;  // 0604B020 mov #1,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0604B026u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B026u) return; }  // 0604B022 jsr @r1 ; mov r10,r4
    c.r[14] += 64;  // 0604B026 add #64,r14
    c.r[15] = c.r[14];  // 0604B028 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B02A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B02C mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604B02E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604B030 mov.l @r15+,r9
    c.r[0] = ld32(0x0604B05Cu);  // 0604B032 mov.l 0x0604B05C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B034 rts ; mov.l @r15+,r8
}

void f_0604B060(SH2Context& c) {
    ran[1216] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B060 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604B062 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604B064 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B066 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B068 sts.l pr,@-r15
    c.r[15] -= 64;  // 0604B06A add #-64,r15
    c.r[14] = c.r[15];  // 0604B06C mov r15,r14
    c.r[8] = ld32(0x0604B0DCu);  // 0604B06E mov.l 0x0604B0DC,r8
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604B070 mov.w @r8,r5
    c.r[9] = ld32(0x0604B0E0u);  // 0604B072 mov.l 0x0604B0E0,r9
    c.r[4] = 0x0u;  // 0604B074 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604B07Au; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B07Au) return; }  // 0604B076 jsr @r9 ; extu.w r5,r5
    c.r[1] = c.r[0] & 0xFFu;  // 0604B07A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604B07C tst r1,r1
    { const bool k = c.t; c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]); if (k) { goto L_0604B086; } }  // 0604B07E bt/s 0x0604B086 ; mov.w @r8,r5
    c.r[4] = 0xFFFFFFFFu; goto L_0604B088;  // 0604B082 bra 0x0604B088 ; mov #-1,r4
L_0604B086:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604B0DAu);  // 0604B086 mov.w 0x0604B0DA,r4
L_0604B088:
    { const uint32_t x = c.r[9]; c.pr = 0x0604B08Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B08Cu) return; }  // 0604B088 jsr @r9 ; extu.w r5,r5
    c.r[10] = ld32(0x0604B0E4u);  // 0604B08C mov.l 0x0604B0E4,r10
    c.r[8] = c.r[10];  // 0604B08E mov r10,r8
    c.r[8] += 70;  // 0604B090 add #70,r8
    c.r[9] = ld32(0x0604B0E0u);  // 0604B092 mov.l 0x0604B0E0,r9
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604B094 mov.w @r8,r5
    c.r[4] = 0x0u;  // 0604B096 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604B09Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B09Cu) return; }  // 0604B098 jsr @r9 ; extu.w r5,r5
    c.r[6] = c.r[0] & 0xFFu;  // 0604B09C extu.b r0,r6
    c.r[5] = ld32(0x0604B0E8u);  // 0604B09E mov.l 0x0604B0E8,r5
    c.r[0] = ld32(0x0604B0ECu);  // 0604B0A0 mov.l 0x0604B0EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604B0A6u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B0A6u) return; }  // 0604B0A2 jsr @r0 ; mov r14,r4
    c.r[0] = ld32(0x0604B0F0u);  // 0604B0A6 mov.l 0x0604B0F0,r0
    c.r[5] = 0xAu;  // 0604B0A8 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0604B0AEu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B0AEu) return; }  // 0604B0AA jsr @r0 ; mov #10,r4
    c.r[1] = ld32(0x0604B0F4u);  // 0604B0AE mov.l 0x0604B0F4,r1
    c.r[5] = c.r[0];  // 0604B0B0 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604B0B6u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B0B6u) return; }  // 0604B0B2 jsr @r1 ; mov r14,r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604B0B6 mov.w @r8,r5
    c.r[4] = 0x0u;  // 0604B0B8 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0604B0BEu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B0BEu) return; }  // 0604B0BA jsr @r9 ; extu.w r5,r5
    c.r[5] = c.r[0] & 0xFFu;  // 0604B0BE extu.b r0,r5
    c.r[1] = ld32(0x0604B0F8u);  // 0604B0C0 mov.l 0x0604B0F8,r1
    c.r[6] = 0x1u;  // 0604B0C2 mov #1,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0604B0C8u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B0C8u) return; }  // 0604B0C4 jsr @r1 ; mov r10,r4
    c.r[14] += 64;  // 0604B0C8 add #64,r14
    c.r[15] = c.r[14];  // 0604B0CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B0CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B0CE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604B0D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604B0D2 mov.l @r15+,r9
    c.r[0] = ld32(0x0604B0FCu);  // 0604B0D4 mov.l 0x0604B0FC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B0D6 rts ; mov.l @r15+,r8
}

void f_0604B100(SH2Context& c) {
    ran[1217] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B100 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B102 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604B104 mov r15,r14
    c.r[1] = ld32(0x0604B12Cu);  // 0604B106 mov.l 0x0604B12C,r1
    c.r[6] = 0x0u;  // 0604B108 mov #0,r6
    c.r[5] = 0x0u;  // 0604B10A mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604B110u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B110u) return; }  // 0604B10C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0604B130u);  // 0604B110 mov.l 0x0604B130,r1
    c.r[1] = ld32(c.r[1]);  // 0604B112 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B114 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0604B116 extu.b r1,r0
    c.r[0] <<= 2;  // 0604B118 shll2 r0
    c.r[1] = ld32(0x0604B134u);  // 0604B11A mov.l 0x0604B134,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0604B11C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604B122u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B122u) return; }  // 0604B11E jsr @r0 ; nop
    c.r[15] = c.r[14];  // 0604B122 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B124 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B126 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0604B128 rts ; extu.w r0,r0
}

void f_0604B138(SH2Context& c) {
    ran[1218] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B138 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604B13A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604B13C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604B13E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604B140 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604B142 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B144 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B146 sts.l pr,@-r15
    c.r[15] -= 4;  // 0604B148 add #-4,r15
    c.r[14] = c.r[15];  // 0604B14A mov r15,r14
    c.r[2] = ld32(0x0604B380u);  // 0604B14C mov.l 0x0604B380,r2
    c.r[1] = 0x1u;  // 0604B14E mov #1,r1
    st32(c.r[2] + 24, c.r[1]);  // 0604B150 mov.l r1,@(24,r2)
    c.r[1] = 0x2u;  // 0604B152 mov #2,r1
    st32(c.r[2] + 28, c.r[1]);  // 0604B154 mov.l r1,@(28,r2)
    c.r[3] = ld32(0x0604B384u);  // 0604B156 mov.l 0x0604B384,r3
    c.r[1] = ld32(0x0604B388u);  // 0604B158 mov.l 0x0604B388,r1
    st32(c.r[3] + 24, c.r[1]);  // 0604B15A mov.l r1,@(24,r3)
    st32(c.r[3] + 32, c.r[1]);  // 0604B15C mov.l r1,@(32,r3)
    st32(c.r[3] + 28, c.r[1]);  // 0604B15E mov.l r1,@(28,r3)
    st32(c.r[3] + 36, c.r[1]);  // 0604B160 mov.l r1,@(36,r3)
    c.r[1] = 0x0u;  // 0604B162 mov #0,r1
    st32(c.r[3] + 40, c.r[1]);  // 0604B164 mov.l r1,@(40,r3)
    st32(c.r[3] + 44, c.r[1]);  // 0604B166 mov.l r1,@(44,r3)
    st32(c.r[3] + 4, c.r[1]);  // 0604B168 mov.l r1,@(4,r3)
    st32(c.r[3] + 8, c.r[1]);  // 0604B16A mov.l r1,@(8,r3)
    st32(c.r[3] + 12, c.r[1]);  // 0604B16C mov.l r1,@(12,r3)
    st32(c.r[3] + 16, c.r[1]);  // 0604B16E mov.l r1,@(16,r3)
    st32(c.r[3] + 20, c.r[1]);  // 0604B170 mov.l r1,@(20,r3)
    st32(c.r[3] + 48, c.r[1]);  // 0604B172 mov.l r1,@(48,r3)
    st32(c.r[3] + 52, c.r[1]);  // 0604B174 mov.l r1,@(52,r3)
    c.r[1] = c.r[3];  // 0604B176 mov r3,r1
    c.r[1] += 1;  // 0604B178 add #1,r1
    c.r[5] = c.r[3];  // 0604B17A mov r3,r5
    c.r[5] += 56;  // 0604B17C add #56,r5
    c.r[9] = ld32(0x0604B38Cu);  // 0604B17E mov.l 0x0604B38C,r9
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B180 mov.b @r1,r7
    c.r[8] = 0x0u;  // 0604B182 mov #0,r8
    c.r[7] = c.r[7] & 0xFFu;  // 0604B184 extu.b r7,r7
    c.r[1] = ld32(0x0604B390u);  // 0604B186 mov.l 0x0604B390,r1
    c.r[0] = ld32(c.r[1]);  // 0604B188 mov.l @r1,r0
    c.r[7] += c.r[7];  // 0604B18A add r7,r7
    c.r[1] = c.r[7];  // 0604B18C mov r7,r1
    c.r[1] += c.r[0];  // 0604B18E add r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604B190 mov.b @(r0,r7),r2
    c.r[1] += 1;  // 0604B192 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B194 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604B196 extu.b r2,r2
    c.r[2] <<= 8;  // 0604B198 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B19A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604B19C or r1,r2
    c.r[7] += c.r[2];  // 0604B19E add r2,r7
    c.r[10] = c.r[7] & 0xFFFFu;  // 0604B1A0 extu.w r7,r10
    c.r[7] = c.r[3];  // 0604B1A2 mov r3,r7
    c.r[7] += 57;  // 0604B1A4 add #57,r7
    c.r[2] = c.r[10];  // 0604B1A6 mov r10,r2
    c.r[2] += c.r[0];  // 0604B1A8 add r0,r2
    c.r[1] = c.r[2];  // 0604B1AA mov r2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0604B1AC mov.b @(r0,r10),r6
    c.r[1] += 1;  // 0604B1AE add #1,r1
    st8(c.r[5], c.r[6]);  // 0604B1B0 mov.b r6,@r5
    c.r[6] = c.r[6] & 0xFFu;  // 0604B1B2 extu.b r6,r6
    c.r[6] += c.r[6];  // 0604B1B4 add r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B1B6 mov.b @r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[6];  // 0604B1B8 cmp/ge r6,r8
    st8(c.r[7], c.r[1]);  // 0604B1BA mov.b r1,@r7
    c.r[7] = c.r[3];  // 0604B1BC mov r3,r7
    c.r[7] += 58;  // 0604B1BE add #58,r7
    c.r[1] = c.r[2];  // 0604B1C0 mov r2,r1
    c.r[1] += 2;  // 0604B1C2 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B1C4 mov.b @r1,r1
    c.r[2] += 3;  // 0604B1C6 add #3,r2
    st8(c.r[7], c.r[1]);  // 0604B1C8 mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B1CA mov.b @r2,r1
    c.r[3] += 59;  // 0604B1CC add #59,r3
    st8(c.r[3], c.r[1]);  // 0604B1CE mov.b r1,@r3
    c.r[1] = c.r[10];  // 0604B1D0 mov r10,r1
    c.r[1] += 4;  // 0604B1D2 add #4,r1
    { const bool k = c.t; c.r[10] = c.r[1] & 0xFFFFu; if (k) { goto L_0604B254; } }  // 0604B1D4 bt/s 0x0604B254 ; extu.w r1,r10
    c.r[13] = c.r[5];  // 0604B1D8 mov r5,r13
    c.r[12] = c.r[0];  // 0604B1DA mov r0,r12
    c.r[6] = ld32(0x0604B394u);  // 0604B1DC mov.l 0x0604B394,r6
    c.r[11] = ld32(0x0604B398u);  // 0604B1DE mov.l 0x0604B398,r11
    st32(c.r[14], c.r[11]);  // 0604B1E0 mov.l r11,@r14
L_0604B1E2:
    c.r[4] = c.r[8];  // 0604B1E2 mov r8,r4
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604B1E4 mov.b @r13,r7
    c.r[11] = ld32(0x0604B39Cu);  // 0604B1E6 mov.l 0x0604B39C,r11
    c.r[7] = c.r[7] & 0xFFu;  // 0604B1E8 extu.b r7,r7
    { const uint32_t x = c.r[11]; c.pr = 0x0604B1EEu; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B1EEu) return; }  // 0604B1EA jsr @r11 ; mov r7,r5
    c.macl = c.r[0] * c.r[7];  // 0604B1EE mul.l r7,r0
    c.r[1] = c.macl;  // 0604B1F0 sts macl,r1
    c.r[0] = c.r[8];  // 0604B1F2 mov r8,r0
    c.r[0] -= c.r[1];  // 0604B1F4 sub r1,r0
    c.r[0] <<= 2;  // 0604B1F6 shll2 r0
    c.r[0] += c.r[10];  // 0604B1F8 add r10,r0
    c.r[1] = c.r[12];  // 0604B1FA mov r12,r1
    c.r[1] += c.r[0];  // 0604B1FC add r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0604B1FE mov.b @(r0,r12),r2
    c.r[1] += 1;  // 0604B200 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B202 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604B204 extu.b r2,r2
    c.r[2] <<= 8;  // 0604B206 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B208 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604B20A or r1,r2
    st16(c.r[9], c.r[2]);  // 0604B20C mov.w r2,@r9
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604B20E mov.b @r13,r7
    c.r[9] += 12;  // 0604B210 add #12,r9
    c.r[7] = c.r[7] & 0xFFu;  // 0604B212 extu.b r7,r7
    { const uint32_t x = c.r[11]; c.pr = 0x0604B218u; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B218u) return; }  // 0604B214 jsr @r11 ; mov r7,r5
    c.r[3] = c.r[8];  // 0604B218 mov r8,r3
    c.macl = c.r[0] * c.r[7];  // 0604B21A mul.l r7,r0
    c.r[8] += 1;  // 0604B21C add #1,r8
    c.r[11] = ld32(c.r[14]);  // 0604B21E mov.l @r14,r11
    c.r[1] = c.macl;  // 0604B220 sts macl,r1
    c.r[3] -= c.r[1];  // 0604B222 sub r1,r3
    c.r[3] <<= 2;  // 0604B224 shll2 r3
    c.r[3] += c.r[10];  // 0604B226 add r10,r3
    c.r[3] += c.r[12];  // 0604B228 add r12,r3
    c.r[1] = c.r[3];  // 0604B22A mov r3,r1
    c.r[1] += 2;  // 0604B22C add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B22E mov.b @r1,r2
    c.r[3] += 3;  // 0604B230 add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0604B232 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604B234 mov.b @r3,r1
    c.r[2] <<= 8;  // 0604B236 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B238 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604B23A or r1,r2
    st16(c.r[11], c.r[2]);  // 0604B23C mov.w r2,@r11
    c.r[11] += 12;  // 0604B23E add #12,r11
    st32(c.r[14], c.r[11]);  // 0604B240 mov.l r11,@r14
    c.r[1] = 0x0u;  // 0604B242 mov #0,r1
    st32(c.r[6], c.r[1]);  // 0604B244 mov.l r1,@r6
    st32(c.r[6] + 4, c.r[1]);  // 0604B246 mov.l r1,@(4,r6)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604B248 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B24A extu.b r1,r1
    c.r[1] += c.r[1];  // 0604B24C add r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0604B24E cmp/ge r1,r8
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_0604B1E2; } }  // 0604B250 bf/s 0x0604B1E2 ; add #12,r6
L_0604B254:
    c.r[7] = ld32(0x0604B384u);  // 0604B254 mov.l 0x0604B384,r7
    c.r[3] = c.r[7];  // 0604B256 mov r7,r3
    c.r[3] += 56;  // 0604B258 add #56,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604B25A mov.b @r3,r1
    c.r[2] = 0x3Fu;  // 0604B25C mov #63,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B25E extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0604B260 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0604B276; } }  // 0604B262 bt/s 0x0604B276 ; mov #0,r1
    st16(c.r[9], c.r[1]);  // 0604B266 mov.w r1,@r9
    c.r[2] = c.r[9];  // 0604B268 mov r9,r2
    c.r[2] += 2;  // 0604B26A add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B378u);  // 0604B26C mov.w 0x0604B378,r1
    st16(c.r[2], c.r[1]);  // 0604B26E mov.w r1,@r2
    c.r[1] = 0x0u;  // 0604B270 mov #0,r1
    st32(c.r[9] + 4, c.r[1]);  // 0604B272 mov.l r1,@(4,r9)
    st32(c.r[9] + 8, c.r[1]);  // 0604B274 mov.l r1,@(8,r9)
L_0604B276:
    c.r[9] = ld32(0x0604B3A0u);  // 0604B276 mov.l 0x0604B3A0,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604B278 mov.b @r3,r1
    c.r[7] += 57;  // 0604B27A add #57,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604B27C extu.b r1,r1
    c.r[1] <<= 2;  // 0604B27E shll2 r1
    c.r[1] += c.r[10];  // 0604B280 add r10,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 0604B282 extu.w r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0604B284 mov.b @r7,r1
    c.r[8] = 0x0u;  // 0604B286 mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604B288 extu.b r1,r1
    c.r[1] += c.r[1];  // 0604B28A add r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0604B28C cmp/ge r1,r8
    { const bool k = c.t; c.r[13] = c.r[7]; if (k) { goto L_0604B30E; } }  // 0604B28E bt/s 0x0604B30E ; mov r7,r13
    c.r[1] = ld32(0x0604B390u);  // 0604B292 mov.l 0x0604B390,r1
    c.r[12] = ld32(c.r[1]);  // 0604B294 mov.l @r1,r12
    c.r[6] = ld32(0x0604B3A4u);  // 0604B296 mov.l 0x0604B3A4,r6
    c.r[11] = ld32(0x0604B3A8u);  // 0604B298 mov.l 0x0604B3A8,r11
    st32(c.r[14], c.r[11]);  // 0604B29A mov.l r11,@r14
L_0604B29C:
    c.r[4] = c.r[8];  // 0604B29C mov r8,r4
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604B29E mov.b @r13,r7
    c.r[11] = ld32(0x0604B39Cu);  // 0604B2A0 mov.l 0x0604B39C,r11
    c.r[7] = c.r[7] & 0xFFu;  // 0604B2A2 extu.b r7,r7
    { const uint32_t x = c.r[11]; c.pr = 0x0604B2A8u; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B2A8u) return; }  // 0604B2A4 jsr @r11 ; mov r7,r5
    c.macl = c.r[0] * c.r[7];  // 0604B2A8 mul.l r7,r0
    c.r[1] = c.macl;  // 0604B2AA sts macl,r1
    c.r[0] = c.r[8];  // 0604B2AC mov r8,r0
    c.r[0] -= c.r[1];  // 0604B2AE sub r1,r0
    c.r[0] <<= 2;  // 0604B2B0 shll2 r0
    c.r[0] += c.r[10];  // 0604B2B2 add r10,r0
    c.r[1] = c.r[12];  // 0604B2B4 mov r12,r1
    c.r[1] += c.r[0];  // 0604B2B6 add r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0604B2B8 mov.b @(r0,r12),r2
    c.r[1] += 1;  // 0604B2BA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B2BC mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0604B2BE extu.b r2,r2
    c.r[2] <<= 8;  // 0604B2C0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B2C2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604B2C4 or r1,r2
    st16(c.r[9], c.r[2]);  // 0604B2C6 mov.w r2,@r9
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604B2C8 mov.b @r13,r7
    c.r[9] += 12;  // 0604B2CA add #12,r9
    c.r[7] = c.r[7] & 0xFFu;  // 0604B2CC extu.b r7,r7
    { const uint32_t x = c.r[11]; c.pr = 0x0604B2D2u; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B2D2u) return; }  // 0604B2CE jsr @r11 ; mov r7,r5
    c.r[3] = c.r[8];  // 0604B2D2 mov r8,r3
    c.macl = c.r[0] * c.r[7];  // 0604B2D4 mul.l r7,r0
    c.r[8] += 1;  // 0604B2D6 add #1,r8
    c.r[11] = ld32(c.r[14]);  // 0604B2D8 mov.l @r14,r11
    c.r[1] = c.macl;  // 0604B2DA sts macl,r1
    c.r[3] -= c.r[1];  // 0604B2DC sub r1,r3
    c.r[3] <<= 2;  // 0604B2DE shll2 r3
    c.r[3] += c.r[10];  // 0604B2E0 add r10,r3
    c.r[3] += c.r[12];  // 0604B2E2 add r12,r3
    c.r[1] = c.r[3];  // 0604B2E4 mov r3,r1
    c.r[1] += 2;  // 0604B2E6 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B2E8 mov.b @r1,r2
    c.r[3] += 3;  // 0604B2EA add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0604B2EC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604B2EE mov.b @r3,r1
    c.r[2] <<= 8;  // 0604B2F0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B2F2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0604B2F4 or r1,r2
    st16(c.r[11], c.r[2]);  // 0604B2F6 mov.w r2,@r11
    c.r[11] += 12;  // 0604B2F8 add #12,r11
    st32(c.r[14], c.r[11]);  // 0604B2FA mov.l r11,@r14
    c.r[1] = 0x0u;  // 0604B2FC mov #0,r1
    st32(c.r[6], c.r[1]);  // 0604B2FE mov.l r1,@r6
    st32(c.r[6] + 4, c.r[1]);  // 0604B300 mov.l r1,@(4,r6)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0604B302 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B304 extu.b r1,r1
    c.r[1] += c.r[1];  // 0604B306 add r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0604B308 cmp/ge r1,r8
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_0604B29C; } }  // 0604B30A bf/s 0x0604B29C ; add #12,r6
L_0604B30E:
    c.r[1] = ld32(0x0604B3ACu);  // 0604B30E mov.l 0x0604B3AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B310 mov.b @r1,r1
    c.r[2] = 0x3Fu;  // 0604B312 mov #63,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604B314 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0604B316 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0604B32C; } }  // 0604B318 bt/s 0x0604B32C ; mov #0,r1
    st16(c.r[9], c.r[1]);  // 0604B31C mov.w r1,@r9
    c.r[2] = c.r[9];  // 0604B31E mov r9,r2
    c.r[2] += 2;  // 0604B320 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B378u);  // 0604B322 mov.w 0x0604B378,r1
    st16(c.r[2], c.r[1]);  // 0604B324 mov.w r1,@r2
    c.r[1] = 0x0u;  // 0604B326 mov #0,r1
    st32(c.r[9] + 4, c.r[1]);  // 0604B328 mov.l r1,@(4,r9)
    st32(c.r[9] + 8, c.r[1]);  // 0604B32A mov.l r1,@(8,r9)
L_0604B32C:
    c.r[2] = ld32(0x0604B3B0u);  // 0604B32C mov.l 0x0604B3B0,r2
    c.r[3] = 0x3u;  // 0604B32E mov #3,r3
    st16(c.r[2], c.r[3]);  // 0604B330 mov.w r3,@r2
    c.r[1] = c.r[2];  // 0604B332 mov r2,r1
    c.r[1] += 60;  // 0604B334 add #60,r1
    st16(c.r[1], c.r[3]);  // 0604B336 mov.w r3,@r1
    c.r[1] = c.r[2];  // 0604B338 mov r2,r1
    c.r[1] += 120;  // 0604B33A add #120,r1
    st16(c.r[1], c.r[3]);  // 0604B33C mov.w r3,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B37Au);  // 0604B33E mov.w 0x0604B37A,r0
    st16(c.r[0] + c.r[2], c.r[3]);  // 0604B340 mov.w r3,@(r0,r2)
    c.r[1] = c.r[2];  // 0604B342 mov r2,r1
    c.r[1] += 2;  // 0604B344 add #2,r1
    c.r[3] = 0x20u;  // 0604B346 mov #32,r3
    st16(c.r[1], c.r[3]);  // 0604B348 mov.w r3,@r1
    c.r[1] = c.r[2];  // 0604B34A mov r2,r1
    c.r[1] += 62;  // 0604B34C add #62,r1
    st16(c.r[1], c.r[3]);  // 0604B34E mov.w r3,@r1
    c.r[1] = c.r[2];  // 0604B350 mov r2,r1
    c.r[1] += 122;  // 0604B352 add #122,r1
    st16(c.r[1], c.r[3]);  // 0604B354 mov.w r3,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B37Cu);  // 0604B356 mov.w 0x0604B37C,r0
    st16(c.r[0] + c.r[2], c.r[3]);  // 0604B358 mov.w r3,@(r0,r2)
    c.r[1] = ld32(0x0604B3B4u);  // 0604B35A mov.l 0x0604B3B4,r1
    c.r[14] += 4;  // 0604B35C add #4,r14
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604B35E mov.w @r1,r0
    c.r[15] = c.r[14];  // 0604B360 mov r14,r15
    c.r[0] |= 0x40u;  // 0604B362 or #64,r0
    st16(c.r[1], c.r[0]);  // 0604B364 mov.w r0,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B366 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B368 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604B36A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604B36C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604B36E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604B370 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604B372 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B374 rts ; mov.l @r15+,r8
}

void f_0604B3B8(SH2Context& c) {
    ran[1219] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B3B8 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0604B3BA extu.b r4,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0604B3BC tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604B3C8; } }  // 0604B3BE bt/s 0x0604B3C8 ; mov r15,r14
    c.r[1] = ld32(0x0604B450u);  // 0604B3C2 mov.l 0x0604B450,r1
    c.r[6] = ld32(c.r[1] + 32); goto L_0604B3CC;  // 0604B3C4 bra 0x0604B3CC ; mov.l @(32,r1),r6
L_0604B3C8:
    c.r[1] = ld32(0x0604B450u);  // 0604B3C8 mov.l 0x0604B450,r1
    c.r[6] = ld32(c.r[1] + 36);  // 0604B3CA mov.l @(36,r1),r6
L_0604B3CC:
    c.r[6] = c.r[6] << 16 | c.r[6] >> 16;  // 0604B3CC swap.w r6,r6
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0604B3CE exts.w r6,r6
    c.r[6] += 32;  // 0604B3D0 add #32,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B44Cu);  // 0604B3D2 mov.w 0x0604B44C,r1
    c.t = (c.r[4] & c.r[4]) == 0;  // 0604B3D4 tst r4,r4
    c.r[5] = ld32(0x0604B454u);  // 0604B3D6 mov.l 0x0604B454,r5
    { const bool k = c.t; c.r[6] &= c.r[1]; if (k) { goto L_0604B3DE; } }  // 0604B3D8 bt/s 0x0604B3DE ; and r1,r6
    c.r[5] = ld32(0x0604B458u);  // 0604B3DC mov.l 0x0604B458,r5
L_0604B3DE:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604B44Eu);  // 0604B3DE mov.w 0x0604B44E,r7
    c.t = (int32_t)c.r[6] > 0;  // 0604B3E0 cmp/pl r6
    { const bool k = !c.t; c.r[2] = c.r[5]; if (k) { goto L_0604B3F6; } }  // 0604B3E2 bf/s 0x0604B3F6 ; mov r5,r2
    c.r[2] += 2;  // 0604B3E6 add #2,r2
L_0604B3E8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0604B3E8 mov.w @r2,r1
    c.r[5] += 12;  // 0604B3EA add #12,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604B3EC extu.w r1,r1
    c.r[6] -= c.r[1];  // 0604B3EE sub r1,r6
    c.t = (int32_t)c.r[6] > 0;  // 0604B3F0 cmp/pl r6
    { const bool k = c.t; c.r[2] += 12; if (k) { SH2_POLL(c); goto L_0604B3E8; } }  // 0604B3F2 bt/s 0x0604B3E8 ; add #12,r2
L_0604B3F6:
    c.r[6] = 0u - c.r[6];  // 0604B3F6 neg r6,r6
    c.t = (c.r[4] & c.r[4]) == 0;  // 0604B3F8 tst r4,r4
    c.r[3] = ld32(0x0604B45Cu);  // 0604B3FA mov.l 0x0604B45C,r3
    { const bool k = c.t; c.r[5] -= 12; if (k) { goto L_0604B402; } }  // 0604B3FC bt/s 0x0604B402 ; add #-12,r5
    c.r[3] = ld32(0x0604B460u);  // 0604B400 mov.l 0x0604B460,r3
L_0604B402:
    c.r[2] = 0x0u;  // 0604B402 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 0604B404 cmp/ge r6,r2
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0604B442; } }  // 0604B406 bt/s 0x0604B442 ; tst r7,r7
L_0604B40A:
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604B40A tst r7,r7
    if (c.t) { goto L_0604B442; }  // 0604B40C bt 0x0604B442
    c.r[1] = ld32(c.r[5] + 8);  // 0604B40E mov.l @(8,r5),r1
    c.r[2] += 1;  // 0604B410 add #1,r2
    c.r[7] -= 1;  // 0604B412 add #-1,r7
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 0604B414 cmp/ge r6,r2
    st32(c.r[3], c.r[1]);  // 0604B416 mov.l r1,@r3
    { const bool k = !c.t; c.r[3] += 4; if (k) { SH2_POLL(c); goto L_0604B40A; } }  // 0604B418 bf/s 0x0604B40A ; add #4,r3
    c.t = (c.r[7] & c.r[7]) == 0; goto L_0604B442;  // 0604B41C bra 0x0604B442 ; tst r7,r7
L_0604B420:
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604B420 tst r7,r7
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0604B442; } }  // 0604B422 bt/s 0x0604B442 ; mov #0,r2
    c.r[6] = c.r[5];  // 0604B426 mov r5,r6
    c.r[6] += 2;  // 0604B428 add #2,r6
L_0604B42A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604B42A mov.w @r6,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604B42C extu.w r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0604B42E cmp/ge r1,r2
    if (c.t) { goto L_0604B440; }  // 0604B430 bt 0x0604B440
    c.r[1] = ld32(c.r[5] + 8);  // 0604B432 mov.l @(8,r5),r1
    c.r[7] -= 1;  // 0604B434 add #-1,r7
    c.r[2] += 1;  // 0604B436 add #1,r2
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604B438 tst r7,r7
    st32(c.r[3], c.r[1]);  // 0604B43A mov.l r1,@r3
    { const bool k = !c.t; c.r[3] += 4; if (k) { SH2_POLL(c); goto L_0604B42A; } }  // 0604B43C bf/s 0x0604B42A ; add #4,r3
L_0604B440:
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604B440 tst r7,r7
L_0604B442:
    { const bool k = !c.t; c.r[5] += 12; if (k) { SH2_POLL(c); goto L_0604B420; } }  // 0604B442 bf/s 0x0604B420 ; add #12,r5
    c.r[15] = c.r[14];  // 0604B446 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B448 rts ; mov.l @r15+,r14
}

void f_0604B464(SH2Context& c) {
    ran[1220] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B464 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B466 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B468 sts.l pr,@-r15
    c.r[1] = ld32(0x0604B4B8u);  // 0604B46A mov.l 0x0604B4B8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604B46C mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0604B4B4u);  // 0604B46E mov.w 0x0604B4B4,r2
    c.r[2] &= c.r[1];  // 0604B470 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0604B472 tst r2,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604B4AA; } }  // 0604B474 bf/s 0x0604B4AA ; mov r15,r14
    c.r[1] = ld32(0x0604B4BCu);  // 0604B478 mov.l 0x0604B4BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604B47Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B47Eu) return; }  // 0604B47A jsr @r1 ; nop
    c.r[8] = ld32(0x0604B4C0u);  // 0604B47E mov.l 0x0604B4C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0604B484u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B484u) return; }  // 0604B480 jsr @r8 ; mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0604B488u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B488u) return; }  // 0604B484 jsr @r8 ; mov #1,r4
    c.r[7] = ld32(0x0604B4C4u);  // 0604B488 mov.l 0x0604B4C4,r7
    c.r[3] = c.r[7];  // 0604B48A mov r7,r3
    c.r[2] = ld32(0x0604B4C8u);  // 0604B48C mov.l 0x0604B4C8,r2
    c.r[1] = ld32(c.r[2] + 52);  // 0604B48E mov.l @(52,r2),r1
    c.r[3] += 108;  // 0604B490 add #108,r3
    st32(c.r[3], c.r[1]);  // 0604B492 mov.l r1,@r3
    c.r[3] = c.r[7];  // 0604B494 mov r7,r3
    c.r[1] = ld32(c.r[2] + 28);  // 0604B496 mov.l @(28,r2),r1
    c.r[3] += 112;  // 0604B498 add #112,r3
    st32(c.r[3], c.r[1]);  // 0604B49A mov.l r1,@r3
    c.r[3] = c.r[7];  // 0604B49C mov r7,r3
    c.r[1] = ld32(c.r[2] + 48);  // 0604B49E mov.l @(48,r2),r1
    c.r[3] += 116;  // 0604B4A0 add #116,r3
    st32(c.r[3], c.r[1]);  // 0604B4A2 mov.l r1,@r3
    c.r[1] = ld32(c.r[2] + 24);  // 0604B4A4 mov.l @(24,r2),r1
    c.r[7] += 120;  // 0604B4A6 add #120,r7
    st32(c.r[7], c.r[1]);  // 0604B4A8 mov.l r1,@r7
L_0604B4AA:
    c.r[15] = c.r[14];  // 0604B4AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B4AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B4AE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B4B0 rts ; mov.l @r15+,r8
}

void f_0604B4CC(SH2Context& c) {
    ran[1221] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B4CC mov.l r14,@-r15
    c.r[5] = ld32(0x0604B580u);  // 0604B4CE mov.l 0x0604B580,r5
    c.r[2] = ld32(0x0604B584u);  // 0604B4D0 mov.l 0x0604B584,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B4D2 mov.b @r2,r1
    c.r[6] = 0x0u;  // 0604B4D4 mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604B4D6 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B4D8 cmp/ge r1,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604B508; } }  // 0604B4DA bt/s 0x0604B508 ; mov r15,r14
    c.r[4] = c.r[2];  // 0604B4DE mov r2,r4
    c.r[7] = ld32(0x0604B588u);  // 0604B4E0 mov.l 0x0604B588,r7
L_0604B4E2:
    c.r[3] = ld32(c.r[7] + 4);  // 0604B4E2 mov.l @(4,r7),r3
    c.r[1] = ld32(c.r[7]);  // 0604B4E4 mov.l @r7,r1
    c.r[6] += 1;  // 0604B4E6 add #1,r6
    c.r[3] += c.r[1];  // 0604B4E8 add r1,r3
    st32(c.r[7] + 4, c.r[3]);  // 0604B4EA mov.l r3,@(4,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604B4EC mov.b @r4,r1
    c.r[7] += 12;  // 0604B4EE add #12,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604B4F0 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604B4F2 mov r1,r2
    c.r[2] += c.r[2];  // 0604B4F4 add r2,r2
    c.r[2] += c.r[1];  // 0604B4F6 add r1,r2
    c.r[2] <<= 2;  // 0604B4F8 shll2 r2
    c.r[2] += c.r[5];  // 0604B4FA add r5,r2
    st32(c.r[2] + 8, c.r[3]);  // 0604B4FC mov.l r3,@(8,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604B4FE mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B500 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B502 cmp/ge r1,r6
    { const bool k = !c.t; c.r[5] += 12; if (k) { SH2_POLL(c); goto L_0604B4E2; } }  // 0604B504 bf/s 0x0604B4E2 ; add #12,r5
L_0604B508:
    c.r[5] = ld32(0x0604B58Cu);  // 0604B508 mov.l 0x0604B58C,r5
    c.r[2] = ld32(0x0604B590u);  // 0604B50A mov.l 0x0604B590,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B50C mov.b @r2,r1
    c.r[6] = 0x0u;  // 0604B50E mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604B510 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B512 cmp/ge r1,r6
    if (c.t) { goto L_0604B540; }  // 0604B514 bt 0x0604B540
    c.r[4] = c.r[2];  // 0604B516 mov r2,r4
    c.r[7] = ld32(0x0604B594u);  // 0604B518 mov.l 0x0604B594,r7
L_0604B51A:
    c.r[3] = ld32(c.r[7] + 4);  // 0604B51A mov.l @(4,r7),r3
    c.r[1] = ld32(c.r[7]);  // 0604B51C mov.l @r7,r1
    c.r[6] += 1;  // 0604B51E add #1,r6
    c.r[3] += c.r[1];  // 0604B520 add r1,r3
    st32(c.r[7] + 4, c.r[3]);  // 0604B522 mov.l r3,@(4,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604B524 mov.b @r4,r1
    c.r[7] += 12;  // 0604B526 add #12,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0604B528 extu.b r1,r1
    c.r[2] = c.r[1];  // 0604B52A mov r1,r2
    c.r[2] += c.r[2];  // 0604B52C add r2,r2
    c.r[2] += c.r[1];  // 0604B52E add r1,r2
    c.r[2] <<= 2;  // 0604B530 shll2 r2
    c.r[2] += c.r[5];  // 0604B532 add r5,r2
    st32(c.r[2] + 8, c.r[3]);  // 0604B534 mov.l r3,@(8,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604B536 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B538 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B53A cmp/ge r1,r6
    { const bool k = !c.t; c.r[5] += 12; if (k) { SH2_POLL(c); goto L_0604B51A; } }  // 0604B53C bf/s 0x0604B51A ; add #12,r5
L_0604B540:
    c.r[7] = ld32(0x0604B598u);  // 0604B540 mov.l 0x0604B598,r7
    c.r[1] = ld32(c.r[7] + 8);  // 0604B542 mov.l @(8,r7),r1
    c.r[2] = ld32(c.r[7] + 16);  // 0604B544 mov.l @(16,r7),r2
    c.t = c.r[1] == c.r[2];  // 0604B546 cmp/eq r2,r1
    if (c.t) { goto L_0604B564; }  // 0604B548 bt 0x0604B564
    st32(c.r[7] + 8, c.r[2]);  // 0604B54A mov.l r2,@(8,r7)
    c.r[1] = c.r[7];  // 0604B54C mov r7,r1
    c.r[1] += 58;  // 0604B54E add #58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B550 mov.b @r1,r1
    c.macl = c.r[1] * c.r[2];  // 0604B552 mul.l r2,r1
    c.r[0] = c.macl;  // 0604B554 sts macl,r0
    st32(c.r[7] + 40, c.r[0]);  // 0604B556 mov.l r0,@(40,r7)
    c.r[1] = c.r[7];  // 0604B558 mov r7,r1
    c.r[1] += 59;  // 0604B55A add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B55C mov.b @r1,r1
    c.macl = c.r[1] * c.r[2];  // 0604B55E mul.l r2,r1
    c.r[0] = c.macl;  // 0604B560 sts macl,r0
    st32(c.r[7] + 44, c.r[0]);  // 0604B562 mov.l r0,@(44,r7)
L_0604B564:
    c.r[2] = ld32(c.r[7] + 28);  // 0604B564 mov.l @(28,r7),r2
    c.r[3] = ld32(c.r[7] + 24);  // 0604B566 mov.l @(24,r7),r3
    c.r[15] = c.r[14];  // 0604B568 mov r14,r15
    c.r[1] = ld32(c.r[7] + 44);  // 0604B56A mov.l @(44,r7),r1
    st32(c.r[7] + 36, c.r[2]);  // 0604B56C mov.l r2,@(36,r7)
    st32(c.r[7] + 32, c.r[3]);  // 0604B56E mov.l r3,@(32,r7)
    c.r[2] += c.r[1];  // 0604B570 add r1,r2
    c.r[1] = ld32(c.r[7] + 40);  // 0604B572 mov.l @(40,r7),r1
    st32(c.r[7] + 28, c.r[2]);  // 0604B574 mov.l r2,@(28,r7)
    c.r[3] += c.r[1];  // 0604B576 add r1,r3
    st32(c.r[7] + 24, c.r[3]);  // 0604B578 mov.l r3,@(24,r7)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B57A rts ; mov.l @r15+,r14
}

void f_0604B59C(SH2Context& c) {
    ran[1222] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B59C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B59E mov.l r14,@-r15
    c.r[3] = ld32(0x0604B658u);  // 0604B5A0 mov.l 0x0604B658,r3
    c.r[1] = c.r[3];  // 0604B5A2 mov r3,r1
    c.r[1] += 1;  // 0604B5A4 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B5A6 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0604B5A8 extu.b r2,r2
    c.r[1] = ld32(0x0604B65Cu);  // 0604B5AA mov.l 0x0604B65C,r1
    c.r[2] += c.r[2];  // 0604B5AC add r2,r2
    c.r[1] = ld32(c.r[1]);  // 0604B5AE mov.l @r1,r1
    c.r[0] = c.r[2];  // 0604B5B0 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0604B5B2 mov.b @(r0,r1),r2
    c.r[1] = ld32(c.r[3] + 12);  // 0604B5B4 mov.l @(12,r3),r1
    c.r[7] = ld32(0x0604B660u);  // 0604B5B6 mov.l 0x0604B660,r7
    c.macl = c.r[1] * c.r[2];  // 0604B5B8 mul.l r2,r1
    c.r[6] = 0x0u;  // 0604B5BA mov #0,r6
    c.r[3] += 56;  // 0604B5BC add #56,r3
    c.r[8] = c.macl;  // 0604B5BE sts macl,r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0604B5C0 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0604B5C2 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0604B5C4 shar r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604B5C6 mov.b @r3,r1
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0604B5C8 shar r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604B5CA extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B5CC cmp/ge r1,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604B608; } }  // 0604B5CE bt/s 0x0604B608 ; mov r15,r14
    c.r[4] = c.r[8];  // 0604B5D2 mov r8,r4
    c.r[4] <<= 2;  // 0604B5D4 shll2 r4
    c.r[4] += c.r[4];  // 0604B5D6 add r4,r4
    c.r[5] = c.r[3];  // 0604B5D8 mov r3,r5
L_0604B5DA:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604B5DA mov.w @r7,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604B5DC extu.w r1,r1
    c.macl = c.r[4] * c.r[1];  // 0604B5DE mul.l r1,r4
    c.r[2] = c.macl;  // 0604B5E0 sts macl,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B5E2 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B5E4 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B5E6 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B5E8 shar r2
    st32(c.r[7] + 4, c.r[2]);  // 0604B5EA mov.l r2,@(4,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604B5EC mov.b @r5,r1
    c.r[6] += 1;  // 0604B5EE add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604B5F0 extu.b r1,r1
    c.r[3] = c.r[1];  // 0604B5F2 mov r1,r3
    c.r[3] += c.r[3];  // 0604B5F4 add r3,r3
    c.r[3] += c.r[1];  // 0604B5F6 add r1,r3
    c.r[3] <<= 2;  // 0604B5F8 shll2 r3
    c.r[3] += c.r[7];  // 0604B5FA add r7,r3
    st32(c.r[3] + 4, c.r[2]);  // 0604B5FC mov.l r2,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604B5FE mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B600 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B602 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] += 12; if (k) { SH2_POLL(c); goto L_0604B5DA; } }  // 0604B604 bf/s 0x0604B5DA ; add #12,r7
L_0604B608:
    c.r[7] = ld32(0x0604B664u);  // 0604B608 mov.l 0x0604B664,r7
    c.r[2] = ld32(0x0604B668u);  // 0604B60A mov.l 0x0604B668,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B60C mov.b @r2,r1
    c.r[6] = 0x0u;  // 0604B60E mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604B610 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B612 cmp/ge r1,r6
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0604B650; } }  // 0604B614 bt/s 0x0604B650 ; mov r14,r15
    c.r[4] = c.r[8];  // 0604B618 mov r8,r4
    c.r[4] <<= 2;  // 0604B61A shll2 r4
    c.r[4] += c.r[4];  // 0604B61C add r4,r4
    c.r[5] = c.r[2];  // 0604B61E mov r2,r5
L_0604B620:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0604B620 mov.w @r7,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0604B622 extu.w r1,r1
    c.macl = c.r[4] * c.r[1];  // 0604B624 mul.l r1,r4
    c.r[2] = c.macl;  // 0604B626 sts macl,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B628 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B62A shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B62C shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0604B62E shar r2
    st32(c.r[7] + 4, c.r[2]);  // 0604B630 mov.l r2,@(4,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604B632 mov.b @r5,r1
    c.r[6] += 1;  // 0604B634 add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0604B636 extu.b r1,r1
    c.r[3] = c.r[1];  // 0604B638 mov r1,r3
    c.r[3] += c.r[3];  // 0604B63A add r3,r3
    c.r[3] += c.r[1];  // 0604B63C add r1,r3
    c.r[3] <<= 2;  // 0604B63E shll2 r3
    c.r[3] += c.r[7];  // 0604B640 add r7,r3
    st32(c.r[3] + 4, c.r[2]);  // 0604B642 mov.l r2,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604B644 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B646 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0604B648 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] += 12; if (k) { SH2_POLL(c); goto L_0604B620; } }  // 0604B64A bf/s 0x0604B620 ; add #12,r7
    c.r[15] = c.r[14];  // 0604B64E mov r14,r15
L_0604B650:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B650 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B652 rts ; mov.l @r15+,r8
}

void f_0604B66C(SH2Context& c) {
    ran[1223] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B66C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604B66E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B670 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B672 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0604B674 mov r15,r14
    c.r[2] = ld32(0x0604B7D0u);  // 0604B676 mov.l 0x0604B7D0,r2
    c.r[3] = c.r[2];  // 0604B678 mov r2,r3
    c.r[3] += 1;  // 0604B67A add #1,r3
    c.r[1] = 0xFFFFFFFFu;  // 0604B67C mov #-1,r1
    c.r[8] = ld32(0x0604B7D4u);  // 0604B67E mov.l 0x0604B7D4,r8
    c.r[9] = ld32(0x0604B7D8u);  // 0604B680 mov.l 0x0604B7D8,r9
    c.r[4] = ld32(0x0604B7DCu);  // 0604B682 mov.l 0x0604B7DC,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B684 mov.b @r2,r0
    c.r[0] &= 0x3Fu;  // 0604B686 and #63,r0
    st8(c.r[2], c.r[0]);  // 0604B688 mov.b r0,@r2
    st8(c.r[3], c.r[1]);  // 0604B68A mov.b r1,@r3
    c.r[1] = 0x0u;  // 0604B68C mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 0604B68E mov.l r1,@(12,r2)
    st32(c.r[2] + 4, c.r[1]);  // 0604B690 mov.l r1,@(4,r2)
    c.r[2] = c.r[8];  // 0604B692 mov r8,r2
    c.r[2] += 56;  // 0604B694 add #56,r2
    c.r[1] = 0x0u;  // 0604B696 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0604B698 mov.w r1,@r2
    c.r[1] = ld32(c.r[9]);  // 0604B69A mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B79Cu);  // 0604B69C mov.w 0x0604B79C,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B69E mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 4);  // 0604B6A0 mov.l @(4,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B79Eu);  // 0604B6A2 mov.w 0x0604B79E,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6A4 mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 8);  // 0604B6A6 mov.l @(8,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7A0u);  // 0604B6A8 mov.w 0x0604B7A0,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6AA mov.l r1,@(r0,r8)
    c.r[1] = ld32(c.r[9] + 12);  // 0604B6AC mov.l @(12,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7A2u);  // 0604B6AE mov.w 0x0604B7A2,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6B0 mov.l r1,@(r0,r8)
    c.r[0] = ld32(0x0604B7E0u);  // 0604B6B2 mov.l 0x0604B7E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0604B6B8u; c.r[5] = 0x24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B6B8u) return; }  // 0604B6B4 jsr @r0 ; mov #36,r5
    c.r[1] = c.r[0];  // 0604B6B8 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7A4u);  // 0604B6BA mov.w 0x0604B7A4,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6BC mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7A6u);  // 0604B6BE mov.w 0x0604B7A6,r0
    c.r[1] = ld32(0x0604B7E4u);  // 0604B6C0 mov.l 0x0604B7E4,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6C2 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7A8u);  // 0604B6C4 mov.w 0x0604B7A8,r0
    c.r[1] = ld32(0x0604B7E8u);  // 0604B6C6 mov.l 0x0604B7E8,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6C8 mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7AAu);  // 0604B6CA mov.w 0x0604B7AA,r0
    c.r[9] += 88;  // 0604B6CC add #88,r9
    c.r[1] = 0x33u;  // 0604B6CE mov #51,r1
    c.r[7] = 0x0u;  // 0604B6D0 mov #0,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604B7ACu);  // 0604B6D2 mov.w 0x0604B7AC,r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0604B6D4 mov.w @r9,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0604B7AEu);  // 0604B6D6 mov.w 0x0604B7AE,r4
    st16(c.r[0] + c.r[8], c.r[2]);  // 0604B6D8 mov.w r2,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7B0u);  // 0604B6DA mov.w 0x0604B7B0,r0
    st16(c.r[0] + c.r[8], c.r[1]);  // 0604B6DC mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7B2u);  // 0604B6DE mov.w 0x0604B7B2,r0
    st16(c.r[0] + c.r[8], c.r[1]);  // 0604B6E0 mov.w r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7B4u);  // 0604B6E2 mov.w 0x0604B7B4,r0
    c.r[1] = 0x30u;  // 0604B6E4 mov #48,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0604B6E6 mov.b r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7B6u);  // 0604B6E8 mov.w 0x0604B7B6,r0
    c.r[1] = ld32(0x0604B7ECu);  // 0604B6EA mov.l 0x0604B7EC,r1
    st32(c.r[0] + c.r[8], c.r[1]);  // 0604B6EC mov.l r1,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7B8u);  // 0604B6EE mov.w 0x0604B7B8,r0
    c.r[1] = 0x33u;  // 0604B6F0 mov #51,r1
    st8(c.r[0] + c.r[8], c.r[1]);  // 0604B6F2 mov.b r1,@(r0,r8)
    c.r[2] += 1;  // 0604B6F4 add #1,r2
    st16(c.r[9], c.r[2]);  // 0604B6F6 mov.w r2,@r9
    c.r[9] = 0x3u;  // 0604B6F8 mov #3,r9
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604B7BAu);  // 0604B6FA mov.w 0x0604B7BA,r3
L_0604B6FC:
    c.r[1] = c.r[8];  // 0604B6FC mov r8,r1
    c.r[1] += 64;  // 0604B6FE add #64,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B700 mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 0604B702 mov #127,r0
    c.r[5] = 0x0u;  // 0604B704 mov #0,r5
    c.r[7] += 1;  // 0604B706 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[9];  // 0604B708 cmp/gt r9,r7
    c.r[2] &= c.r[0];  // 0604B70A and r0,r2
    st8(c.r[1], c.r[2]);  // 0604B70C mov.b r2,@r1
    c.r[2] = c.r[8];  // 0604B70E mov r8,r2
    c.r[2] += 65;  // 0604B710 add #65,r2
    c.r[1] = 0x21u;  // 0604B712 mov #33,r1
    st8(c.r[2], c.r[1]);  // 0604B714 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0604B716 mov r8,r2
    c.r[2] += 66;  // 0604B718 add #66,r2
    c.r[1] = 0x6u;  // 0604B71A mov #6,r1
    st8(c.r[2], c.r[1]);  // 0604B71C mov.b r1,@r2
    c.r[2] = c.r[8];  // 0604B71E mov r8,r2
    c.r[2] += 67;  // 0604B720 add #67,r2
    c.r[1] = 0x7u;  // 0604B722 mov #7,r1
    st8(c.r[2], c.r[1]);  // 0604B724 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0604B726 mov r8,r2
    c.r[2] += 68;  // 0604B728 add #68,r2
    c.r[1] = 0x14u;  // 0604B72A mov #20,r1
    st8(c.r[2], c.r[1]);  // 0604B72C mov.b r1,@r2
    c.r[1] = c.r[8];  // 0604B72E mov r8,r1
    c.r[1] += 70;  // 0604B730 add #70,r1
    st16(c.r[1], c.r[6]);  // 0604B732 mov.w r6,@r1
    c.r[1] = c.r[8];  // 0604B734 mov r8,r1
    c.r[1] += 72;  // 0604B736 add #72,r1
    st16(c.r[1], c.r[6]);  // 0604B738 mov.w r6,@r1
    c.r[0] = c.r[8];  // 0604B73A mov r8,r0
    st16(c.r[0] + c.r[4], c.r[5]);  // 0604B73C mov.w r5,@(r0,r4)
    { const bool k = !c.t; c.r[8] += c.r[3]; if (k) { SH2_POLL(c); goto L_0604B6FC; } }  // 0604B73E bf/s 0x0604B6FC ; add r3,r8
    c.r[2] = ld32(0x0604B7D4u);  // 0604B742 mov.l 0x0604B7D4,r2
    c.r[1] = c.r[2];  // 0604B744 mov r2,r1
    c.r[1] += 64;  // 0604B746 add #64,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B748 mov.b @r1,r3
    c.r[0] = 0x7Cu;  // 0604B74A mov #124,r0
    c.r[3] |= c.r[0];  // 0604B74C or r0,r3
    st8(c.r[1], c.r[3]);  // 0604B74E mov.b r3,@r1
    c.r[1] = c.r[2];  // 0604B750 mov r2,r1
    c.r[1] += 74;  // 0604B752 add #74,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604B7BCu);  // 0604B754 mov.w 0x0604B7BC,r3
    st16(c.r[1], c.r[3]);  // 0604B756 mov.w r3,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B7AAu);  // 0604B758 mov.w 0x0604B7AA,r1
    c.r[0] = c.r[2];  // 0604B75A mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604B75C mov.w @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604B7BEu);  // 0604B75E mov.w 0x0604B7BE,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 0604B760 mov.w r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B7B0u);  // 0604B762 mov.w 0x0604B7B0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0604B764 mov.w @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604B7C0u);  // 0604B766 mov.w 0x0604B7C0,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 0604B768 mov.w r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604B7C2u);  // 0604B76A mov.w 0x0604B7C2,r7
    c.r[1] = 0x0u;  // 0604B76C mov #0,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0604B76E mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604B7C4u);  // 0604B770 mov.w 0x0604B7C4,r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604B772 mov.b @(r0,r7),r6
    c.r[15] = c.r[14];  // 0604B774 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0604B7C6u);  // 0604B776 mov.w 0x0604B7C6,r0
    c.r[6] &= c.r[0];  // 0604B778 and r0,r6
    c.r[0] = 0x28u;  // 0604B77A mov #40,r0
    c.r[6] |= c.r[0];  // 0604B77C or r0,r6
    c.r[0] = c.r[2];  // 0604B77E mov r2,r0
    st8(c.r[0] + c.r[7], c.r[6]);  // 0604B780 mov.b r6,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604B7C8u);  // 0604B782 mov.w 0x0604B7C8,r7
    st16(c.r[0] + c.r[7], c.r[3]);  // 0604B784 mov.w r3,@(r0,r7)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604B7CAu);  // 0604B786 mov.w 0x0604B7CA,r3
    st16(c.r[0] + c.r[3], c.r[5]);  // 0604B788 mov.w r5,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604B7CCu);  // 0604B78A mov.w 0x0604B7CC,r3
    st16(c.r[0] + c.r[3], c.r[5]);  // 0604B78C mov.w r5,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604B7CEu);  // 0604B78E mov.w 0x0604B7CE,r3
    st32(c.r[0] + c.r[3], c.r[1]);  // 0604B790 mov.l r1,@(r0,r3)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B792 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B794 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604B796 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B798 rts ; mov.l @r15+,r8
}

void f_0604B7F0(SH2Context& c) {
    ran[1224] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B7F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B7F2 sts.l pr,@-r15
    c.r[1] = ld32(0x0604B828u);  // 0604B7F4 mov.l 0x0604B828,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B7F6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B7F8 extu.b r1,r1
    c.r[1] >>= 2;  // 0604B7FA shlr2 r1
    c.r[1] >>= 2;  // 0604B7FC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604B7FE shlr r1
    c.r[1] >>= 2;  // 0604B800 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604B802 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604B814; } }  // 0604B804 bt/s 0x0604B814 ; mov r15,r14
    c.r[1] = ld32(0x0604B82Cu);  // 0604B808 mov.l 0x0604B82C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604B80Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B80Eu) return; }  // 0604B80A jsr @r1 ; nop
    c.r[1] = ld32(0x0604B830u);  // 0604B80E mov.l 0x0604B830,r1
    goto L_0604B81C;  // 0604B810 bra 0x0604B81C ; nop
L_0604B814:
    c.r[1] = ld32(0x0604B834u);  // 0604B814 mov.l 0x0604B834,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604B81Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B81Au) return; }  // 0604B816 jsr @r1 ; nop
    c.r[1] = ld32(0x0604B838u);  // 0604B81A mov.l 0x0604B838,r1
L_0604B81C:
    { const uint32_t x = c.r[1]; c.pr = 0x0604B820u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B820u) return; }  // 0604B81C jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0604B820 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B822 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B824 rts ; mov.l @r15+,r14
}

void f_0604B83C(SH2Context& c) {
    ran[1225] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B83C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604B83E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604B840 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604B842 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604B844 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604B846 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B848 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604B84A sts.l pr,@-r15
    c.r[3] = ld32(0x0604B9D0u);  // 0604B84C mov.l 0x0604B9D0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0604B84E mov.b @r3,r1
    c.r[0] = c.r[1];  // 0604B850 mov r1,r0
    c.r[0] >>= 2;  // 0604B852 shlr2 r0
    c.r[0] >>= 2;  // 0604B854 shlr2 r0
    c.r[0] >>= 2;  // 0604B856 shlr2 r0
    c.r[0] &= 0x1u;  // 0604B858 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604B85A tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0604B864; } }  // 0604B85C bf/s 0x0604B864 ; mov r15,r14
    goto L_0604B9B0;  // 0604B860 bra 0x0604B9B0 ; nop
L_0604B864:
    c.r[2] = ld32(c.r[3] + 20);  // 0604B864 mov.l @(20,r3),r2
    c.r[1] = ld32(c.r[3] + 24);  // 0604B866 mov.l @(24,r3),r1
    c.t = c.r[2] >= c.r[1];  // 0604B868 cmp/hs r1,r2
    if (!c.t) { goto L_0604B870; }  // 0604B86A bf 0x0604B870
    goto L_0604B9B0;  // 0604B86C bra 0x0604B9B0 ; nop
L_0604B870:
    c.r[2] = ld32(c.r[3] + 20);  // 0604B870 mov.l @(20,r3),r2
    c.r[1] = ld32(c.r[3] + 24);  // 0604B872 mov.l @(24,r3),r1
    c.t = c.r[2] >= c.r[1];  // 0604B874 cmp/hs r1,r2
    { const bool k = c.t; c.r[6] = c.r[3]; if (k) { goto L_0604B900; } }  // 0604B876 bt/s 0x0604B900 ; mov r3,r6
    c.r[5] = c.r[3];  // 0604B87A mov r3,r5
    c.r[8] = ld32(0x0604B9D4u);  // 0604B87C mov.l 0x0604B9D4,r8
    c.r[9] = c.r[8];  // 0604B87E mov r8,r9
    c.r[9] -= 8;  // 0604B880 add #-8,r9
    c.r[4] = c.r[5];  // 0604B882 mov r5,r4
    c.r[4] += 14;  // 0604B884 add #14,r4
L_0604B886:
    c.r[2] = ld32(c.r[5] + 32);  // 0604B886 mov.l @(32,r5),r2
    c.r[1] = c.r[2];  // 0604B888 mov r2,r1
    c.r[1] += 1;  // 0604B88A add #1,r1
    st32(c.r[5] + 32, c.r[1]);  // 0604B88C mov.l r1,@(32,r5)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B88E mov.b @r2,r7
    c.r[2] = ld32(c.r[5] + 32);  // 0604B890 mov.l @(32,r5),r2
    c.r[0] = c.r[7];  // 0604B892 mov r7,r0
    c.r[1] = c.r[2];  // 0604B894 mov r2,r1
    c.r[1] += 1;  // 0604B896 add #1,r1
    st32(c.r[5] + 32, c.r[1]);  // 0604B898 mov.l r1,@(32,r5)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B89A mov.b @r2,r1
    c.r[0] <<= 16;  // 0604B89C shll16 r0
    c.r[0] <<= 8;  // 0604B89E shll8 r0
    c.r[6] = c.r[1] & 0xFFu;  // 0604B8A0 extu.b r1,r6
    c.r[2] = ld32(c.r[5] + 32);  // 0604B8A2 mov.l @(32,r5),r2
    c.r[6] <<= 16;  // 0604B8A4 shll16 r6
    c.r[1] = c.r[2];  // 0604B8A6 mov r2,r1
    c.r[1] += 1;  // 0604B8A8 add #1,r1
    st32(c.r[5] + 32, c.r[1]);  // 0604B8AA mov.l r1,@(32,r5)
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B8AC mov.b @r2,r3
    c.r[0] += c.r[6];  // 0604B8AE add r6,r0
    c.r[3] = c.r[3] & 0xFFu;  // 0604B8B0 extu.b r3,r3
    c.r[2] = ld32(c.r[5] + 32);  // 0604B8B2 mov.l @(32,r5),r2
    c.r[3] <<= 8;  // 0604B8B4 shll8 r3
    c.r[1] = c.r[2];  // 0604B8B6 mov r2,r1
    c.r[1] += 1;  // 0604B8B8 add #1,r1
    st32(c.r[5] + 32, c.r[1]);  // 0604B8BA mov.l r1,@(32,r5)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B8BC mov.b @r2,r1
    c.r[0] += c.r[3];  // 0604B8BE add r3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0604B8C0 extu.b r1,r1
    c.r[0] += c.r[1];  // 0604B8C2 add r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0604B8C4 cmp/eq #-1,r0
    if (!c.t) { goto L_0604B8E6; }  // 0604B8C6 bf 0x0604B8E6
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0604B8C8 mov.w @r8,r0
    c.r[0] &= 0x20u;  // 0604B8CA and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604B8CC tst r0,r0
    if (c.t) { goto L_0604B8D8; }  // 0604B8CE bt 0x0604B8D8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B9C4u);  // 0604B8D0 mov.w 0x0604B9C4,r1
    st16(c.r[8], c.r[1]);  // 0604B8D2 mov.w r1,@r8
    c.r[1] = 0x0u;  // 0604B8D4 mov #0,r1
    st16(c.r[9], c.r[1]);  // 0604B8D6 mov.w r1,@r9
L_0604B8D8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604B8D8 mov.b @r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0604B9C6u);  // 0604B8DA mov.w 0x0604B9C6,r1
    c.r[0] &= 0xBFu;  // 0604B8DC and #191,r0
    st8(c.r[5], c.r[0]);  // 0604B8DE mov.b r0,@r5
    st16(c.r[4], c.r[1]);  // 0604B8E0 mov.w r1,@r4
    goto L_0604B8FC;  // 0604B8E2 bra 0x0604B8FC ; nop
L_0604B8E6:
    c.r[1] = ld32(c.r[5] + 20);  // 0604B8E6 mov.l @(20,r5),r1
    c.r[1] += c.r[0];  // 0604B8E8 add r0,r1
    st32(c.r[5] + 20, c.r[1]);  // 0604B8EA mov.l r1,@(20,r5)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604B8EC mov.w @r4,r1
    c.r[1] += 1;  // 0604B8EE add #1,r1
    st16(c.r[4], c.r[1]);  // 0604B8F0 mov.w r1,@r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0604B8F2 mov.w @r4,r1
    c.r[2] = ld32(c.r[5] + 20);  // 0604B8F4 mov.l @(20,r5),r2
    c.r[1] = ld32(c.r[5] + 24);  // 0604B8F6 mov.l @(24,r5),r1
    c.t = c.r[2] >= c.r[1];  // 0604B8F8 cmp/hs r1,r2
    if (!c.t) { SH2_POLL(c); goto L_0604B886; }  // 0604B8FA bf 0x0604B886
L_0604B8FC:
    c.r[3] = ld32(0x0604B9D0u);  // 0604B8FC mov.l 0x0604B9D0,r3
    c.r[6] = c.r[3];  // 0604B8FE mov r3,r6
L_0604B900:
    c.r[6] += 14;  // 0604B900 add #14,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0604B902 mov.w @r6,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 0604B904 extu.w r1,r7
    c.r[2] = ld32(c.r[3] + 36);  // 0604B906 mov.l @(36,r3),r2
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604B908 tst r7,r7
    { const bool k = c.t; c.r[13] = c.r[3]; if (k) { goto L_0604B982; } }  // 0604B90A bt/s 0x0604B982 ; mov r3,r13
    c.r[8] = (uint32_t)(int16_t)ld16(0x0604B9C8u);  // 0604B90E mov.w 0x0604B9C8,r8
    c.r[12] = c.r[6];  // 0604B910 mov r6,r12
    c.r[11] = (uint32_t)(int16_t)ld16(0x0604B9CAu);  // 0604B912 mov.w 0x0604B9CA,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x0604B9CCu);  // 0604B914 mov.w 0x0604B9CC,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x0604B9CEu);  // 0604B916 mov.w 0x0604B9CE,r9
    c.r[0] = c.r[2];  // 0604B918 mov r2,r0
    c.r[0] += 3;  // 0604B91A add #3,r0
    c.r[4] = c.r[2];  // 0604B91C mov r2,r4
    c.r[4] += 2;  // 0604B91E add #2,r4
    c.r[5] = c.r[2];  // 0604B920 mov r2,r5
    c.r[5] += 1;  // 0604B922 add #1,r5
L_0604B924:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0604B924 mov.b @r2+,r1
    c.r[0] += 1;  // 0604B926 add #1,r0
    c.r[4] += 1;  // 0604B928 add #1,r4
    c.r[3] = c.r[1] & 0xFFu;  // 0604B92A extu.b r1,r3
    c.t = c.r[3] == c.r[8];  // 0604B92C cmp/eq r8,r3
    { const bool k = !c.t; c.r[5] += 1; if (k) { goto L_0604B95A; } }  // 0604B92E bf/s 0x0604B95A ; add #1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0604B932 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B934 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0604B936 cmp/eq r8,r1
    if (!c.t) { goto L_0604B952; }  // 0604B938 bf 0x0604B952
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0604B93A mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B93C extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0604B93E cmp/eq r8,r1
    if (!c.t) { goto L_0604B952; }  // 0604B940 bf 0x0604B952
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0604B942 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B944 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0604B946 cmp/eq r8,r1
    if (!c.t) { goto L_0604B952; }  // 0604B948 bf 0x0604B952
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0604B94A mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604B94C extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0604B94E cmp/eq r8,r1
    if (c.t) { goto L_0604B982; }  // 0604B950 bt 0x0604B982
L_0604B952:
    st32(c.r[13] + 36, c.r[2]);  // 0604B952 mov.l r2,@(36,r13)
    st16(c.r[12], c.r[7]);  // 0604B954 mov.w r7,@r12
    c.t = (c.r[7] & c.r[7]) == 0; goto L_0604B980;  // 0604B956 bra 0x0604B980 ; tst r7,r7
L_0604B95A:
    c.t = c.r[3] > c.r[11];  // 0604B95A cmp/hi r11,r3
    { const bool k = !c.t; c.t = c.r[3] > c.r[10]; if (k) { goto L_0604B978; } }  // 0604B95C bf/s 0x0604B978 ; cmp/hi r10,r3
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0604B980; } }  // 0604B960 bt/s 0x0604B980 ; tst r7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0604B964 mov.b @r2+,r1
    c.r[0] += 1;  // 0604B966 add #1,r0
    c.r[4] += 1;  // 0604B968 add #1,r4
    c.r[5] += 1;  // 0604B96A add #1,r5
    c.t = c.r[3] == c.r[9];  // 0604B96C cmp/eq r9,r3
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFu; if (k) { goto L_0604B978; } }  // 0604B96E bf/s 0x0604B978 ; extu.b r1,r6
    c.t = c.r[6] == c.r[8];  // 0604B972 cmp/eq r8,r6
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0604B980; } }  // 0604B974 bt/s 0x0604B980 ; tst r7,r7
L_0604B978:
    c.r[1] = c.r[7];  // 0604B978 mov r7,r1
    c.r[1] -= 1;  // 0604B97A add #-1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 0604B97C extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0604B97E tst r7,r7
L_0604B980:
    if (!c.t) { SH2_POLL(c); goto L_0604B924; }  // 0604B980 bf 0x0604B924
L_0604B982:
    c.r[2] = ld32(0x0604B9D0u);  // 0604B982 mov.l 0x0604B9D0,r2
    c.r[1] = c.r[2];  // 0604B984 mov r2,r1
    c.r[1] += 14;  // 0604B986 add #14,r1
    c.r[8] = ld32(0x0604B9D8u);  // 0604B988 mov.l 0x0604B9D8,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0604B98A mov.w @r1,r6
    c.r[5] = c.r[8];  // 0604B98C mov r8,r5
    c.r[6] -= 1;  // 0604B98E add #-1,r6
    c.r[6] = c.r[6] & 0xFFFFu;  // 0604B990 extu.w r6,r6
    c.r[4] = ld32(c.r[2] + 36);  // 0604B992 mov.l @(36,r2),r4
    c.r[1] = ld32(0x0604B9DCu);  // 0604B994 mov.l 0x0604B9DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604B99Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B99Au) return; }  // 0604B996 jsr @r1 ; nop
    c.r[6] = ld32(0x0604B9E0u);  // 0604B99A mov.l 0x0604B9E0,r6
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B99C mov.l r8,@-r15
    c.r[1] = ld32(0x0604B9E4u);  // 0604B99E mov.l 0x0604B9E4,r1
    c.r[7] = 0x0u;  // 0604B9A0 mov #0,r7
    c.r[5] = 0x2u;  // 0604B9A2 mov #2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0604B9A8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604B9A8u) return; }  // 0604B9A4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0604B9E8u);  // 0604B9A8 mov.l 0x0604B9E8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604B9AA mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0604B9AC or #128,r0
    st8(c.r[1], c.r[0]);  // 0604B9AE mov.b r0,@r1
L_0604B9B0:
    c.r[15] = c.r[14];  // 0604B9B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604B9B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604B9B4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604B9B6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604B9B8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604B9BA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604B9BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604B9BE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604B9C0 rts ; mov.l @r15+,r8
}

void f_0604B9EC(SH2Context& c) {
    ran[1226] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604B9EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604B9EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604B9F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604B9F2 mov.l r14,@-r15
    c.r[15] -= 16;  // 0604B9F4 add #-16,r15
    c.r[14] = c.r[15];  // 0604B9F6 mov r15,r14
    c.r[9] = c.r[4];  // 0604B9F8 mov r4,r9
    c.r[8] = c.r[5];  // 0604B9FA mov r5,r8
    c.r[10] = c.r[6] & 0xFFFFu;  // 0604B9FC extu.w r6,r10
    c.r[6] = 0xFFFFFFF7u;  // 0604B9FE mov #-9,r6
    st8(c.r[14], c.r[6]);  // 0604BA00 mov.b r6,@r14
    c.r[1] = c.r[14];  // 0604BA02 mov r14,r1
    c.r[1] += 1;  // 0604BA04 add #1,r1
    c.r[3] = 0x0u;  // 0604BA06 mov #0,r3
    st8(c.r[1], c.r[3]);  // 0604BA08 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604BA0A mov r14,r1
    c.r[1] += 2;  // 0604BA0C add #2,r1
    st8(c.r[1], c.r[3]);  // 0604BA0E mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604BA10 mov r14,r1
    c.r[1] += 3;  // 0604BA12 add #3,r1
    c.r[4] = 0xFFFFFFF4u;  // 0604BA14 mov #-12,r4
    st8(c.r[1], c.r[4]);  // 0604BA16 mov.b r4,@r1
    c.r[2] = c.r[14];  // 0604BA18 mov r14,r2
    c.r[2] += 4;  // 0604BA1A add #4,r2
    c.r[1] = 0x1u;  // 0604BA1C mov #1,r1
    st8(c.r[2], c.r[1]);  // 0604BA1E mov.b r1,@r2
    c.r[1] = c.r[14];  // 0604BA20 mov r14,r1
    c.r[1] += 5;  // 0604BA22 add #5,r1
    st8(c.r[1], c.r[6]);  // 0604BA24 mov.b r6,@r1
    c.r[1] = c.r[14];  // 0604BA26 mov r14,r1
    c.r[1] += 6;  // 0604BA28 add #6,r1
    st8(c.r[1], c.r[3]);  // 0604BA2A mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604BA2C mov r14,r1
    c.r[1] += 7;  // 0604BA2E add #7,r1
    c.r[5] = 0x40u;  // 0604BA30 mov #64,r5
    st8(c.r[1], c.r[5]);  // 0604BA32 mov.b r5,@r1
    c.r[7] = c.r[14];  // 0604BA34 mov r14,r7
    c.r[7] += 8;  // 0604BA36 add #8,r7
    st8(c.r[7], c.r[6]);  // 0604BA38 mov.b r6,@r7
    c.r[1] = c.r[14];  // 0604BA3A mov r14,r1
    c.r[1] += 9;  // 0604BA3C add #9,r1
    st8(c.r[1], c.r[3]);  // 0604BA3E mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604BA40 mov r14,r1
    c.r[1] += 10;  // 0604BA42 add #10,r1
    st8(c.r[1], c.r[3]);  // 0604BA44 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604BA46 mov r14,r1
    c.r[1] += 11;  // 0604BA48 add #11,r1
    st8(c.r[1], c.r[4]);  // 0604BA4A mov.b r4,@r1
    c.r[2] = c.r[14];  // 0604BA4C mov r14,r2
    c.r[2] += 12;  // 0604BA4E add #12,r2
    c.r[1] = 0x2u;  // 0604BA50 mov #2,r1
    st8(c.r[2], c.r[1]);  // 0604BA52 mov.b r1,@r2
    c.r[1] = c.r[14];  // 0604BA54 mov r14,r1
    c.r[1] += 13;  // 0604BA56 add #13,r1
    st8(c.r[1], c.r[6]);  // 0604BA58 mov.b r6,@r1
    c.r[1] = c.r[14];  // 0604BA5A mov r14,r1
    c.r[1] += 14;  // 0604BA5C add #14,r1
    st8(c.r[1], c.r[3]);  // 0604BA5E mov.b r3,@r1
    c.r[1] = c.r[14];  // 0604BA60 mov r14,r1
    c.r[1] += 15;  // 0604BA62 add #15,r1
    st8(c.r[1], c.r[5]);  // 0604BA64 mov.b r5,@r1
    c.r[0] = 0x0u;  // 0604BA66 mov #0,r0
    c.r[2] = 0x7u;  // 0604BA68 mov #7,r2
L_0604BA6A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0604BA6A mov.b @(r0,r7),r1
    st8(c.r[8], c.r[1]);  // 0604BA6C mov.b r1,@r8
    c.r[0] += 1;  // 0604BA6E add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[2];  // 0604BA70 cmp/gt r2,r0
    { const bool k = !c.t; c.r[8] += 1; if (k) { SH2_POLL(c); goto L_0604BA6A; } }  // 0604BA72 bf/s 0x0604BA6A ; add #1,r8
    c.t = (c.r[10] & c.r[10]) == 0;  // 0604BA76 tst r10,r10
    if (c.t) { goto L_0604BAB4; }  // 0604BA78 bt 0x0604BAB4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0604BAF2u);  // 0604BA7A mov.w 0x0604BAF2,r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x0604BAF4u);  // 0604BA7C mov.w 0x0604BAF4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0604BAF6u);  // 0604BA7E mov.w 0x0604BAF6,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604BAF8u);  // 0604BA80 mov.w 0x0604BAF8,r7
L_0604BA82:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]); c.r[9] += 1;  // 0604BA82 mov.b @r9+,r1
    st8(c.r[8], c.r[1]);  // 0604BA84 mov.b r1,@r8
    c.r[2] = c.r[1] & 0xFFu;  // 0604BA86 extu.b r1,r2
    c.t = c.r[2] == c.r[3];  // 0604BA88 cmp/eq r3,r2
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_0604BAE4; } }  // 0604BA8A bt/s 0x0604BAE4 ; add #1,r8
    c.t = c.r[2] > c.r[5];  // 0604BA8E cmp/hi r5,r2
    { const bool k = !c.t; c.t = c.r[2] > c.r[6]; if (k) { goto L_0604BAAA; } }  // 0604BA90 bf/s 0x0604BAAA ; cmp/hi r6,r2
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0604BAB2; } }  // 0604BA94 bt/s 0x0604BAB2 ; tst r10,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]); c.r[9] += 1;  // 0604BA98 mov.b @r9+,r1
    c.t = c.r[2] == c.r[7];  // 0604BA9A cmp/eq r7,r2
    st8(c.r[8], c.r[1]);  // 0604BA9C mov.b r1,@r8
    c.r[1] = c.r[1] & 0xFFu;  // 0604BA9E extu.b r1,r1
    { const bool k = !c.t; c.r[8] += 1; if (k) { goto L_0604BAAA; } }  // 0604BAA0 bf/s 0x0604BAAA ; add #1,r8
    c.t = c.r[1] == c.r[3];  // 0604BAA4 cmp/eq r3,r1
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0604BAB2; } }  // 0604BAA6 bt/s 0x0604BAB2 ; tst r10,r10
L_0604BAAA:
    c.r[1] = c.r[10];  // 0604BAAA mov r10,r1
    c.r[1] -= 1;  // 0604BAAC add #-1,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 0604BAAE extu.w r1,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0604BAB0 tst r10,r10
L_0604BAB2:
    if (!c.t) { SH2_POLL(c); goto L_0604BA82; }  // 0604BAB2 bf 0x0604BA82
L_0604BAB4:
    c.r[0] = 0x0u;  // 0604BAB4 mov #0,r0
    c.r[2] = 0x7u;  // 0604BAB6 mov #7,r2
L_0604BAB8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0604BAB8 mov.b @(r0,r14),r1
    st8(c.r[8], c.r[1]);  // 0604BABA mov.b r1,@r8
    c.r[0] += 1;  // 0604BABC add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[2];  // 0604BABE cmp/gt r2,r0
    { const bool k = !c.t; c.r[8] += 1; if (k) { SH2_POLL(c); goto L_0604BAB8; } }  // 0604BAC0 bf/s 0x0604BAB8 ; add #1,r8
    c.r[7] = (uint32_t)(int16_t)ld16(0x0604BAF2u);  // 0604BAC4 mov.w 0x0604BAF2,r7
    c.r[3] = 0xAu;  // 0604BAC6 mov #10,r3
L_0604BAC8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]); c.r[9] += 1;  // 0604BAC8 mov.b @r9+,r1
    st8(c.r[8], c.r[1]);  // 0604BACA mov.b r1,@r8
    c.r[2] = c.r[1] & 0xFFu;  // 0604BACC extu.b r1,r2
    c.t = c.r[2] == c.r[7];  // 0604BACE cmp/eq r7,r2
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_0604BAE4; } }  // 0604BAD0 bt/s 0x0604BAE4 ; add #1,r8
    c.r[2] += 21;  // 0604BAD4 add #21,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0604BAD6 extu.b r2,r1
    c.t = c.r[1] > c.r[3];  // 0604BAD8 cmp/hi r3,r1
    if (c.t) { SH2_POLL(c); goto L_0604BAC8; }  // 0604BADA bt 0x0604BAC8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]); c.r[9] += 1;  // 0604BADC mov.b @r9+,r1
    st8(c.r[8], c.r[1]);  // 0604BADE mov.b r1,@r8
    c.r[8] += 1; SH2_POLL(c); goto L_0604BAC8;  // 0604BAE0 bra 0x0604BAC8 ; add #1,r8
L_0604BAE4:
    c.r[14] += 16;  // 0604BAE4 add #16,r14
    c.r[15] = c.r[14];  // 0604BAE6 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604BAE8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604BAEA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604BAEC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604BAEE rts ; mov.l @r15+,r8
}

void f_0604BAFC(SH2Context& c) {
    ran[1227] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0604BAFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0604BAFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0604BB00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0604BB02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0604BB04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0604BB06 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0604BB08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0604BB0A sts.l pr,@-r15
    c.r[15] -= 4;  // 0604BB0C add #-4,r15
    c.r[1] = ld32(0x0604BD6Cu);  // 0604BB0E mov.l 0x0604BD6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BB10 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604BB12 extu.b r1,r1
    c.r[0] = c.r[1];  // 0604BB14 mov r1,r0
    c.r[0] >>= 2;  // 0604BB16 shlr2 r0
    c.r[0] >>= 2;  // 0604BB18 shlr2 r0
    c.r[0] >>= 2;  // 0604BB1A shlr2 r0
    c.r[0] &= 0x1u;  // 0604BB1C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BB1E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0604BB5A; } }  // 0604BB20 bt/s 0x0604BB5A ; mov r15,r14
    c.r[0] = c.r[1];  // 0604BB24 mov r1,r0
    c.r[0] >>= 2;  // 0604BB26 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BB28 shlr r0
    c.r[0] &= 0x1u;  // 0604BB2A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BB2C tst r0,r0
    if (c.t) { goto L_0604BB36; }  // 0604BB2E bt 0x0604BB36
    c.r[12] = ld32(0x0604BD70u);  // 0604BB30 mov.l 0x0604BD70,r12
    c.r[3] = c.r[12]; goto L_0604BB3A;  // 0604BB32 bra 0x0604BB3A ; mov r12,r3
L_0604BB36:
    c.r[12] = ld32(0x0604BD74u);  // 0604BB36 mov.l 0x0604BD74,r12
    c.r[3] = c.r[12];  // 0604BB38 mov r12,r3
L_0604BB3A:
    c.r[3] += 4;  // 0604BB3A add #4,r3
    st32(c.r[14], c.r[3]);  // 0604BB3C mov.l r3,@r14
    c.r[1] = ld32(0x0604BD6Cu);  // 0604BB3E mov.l 0x0604BD6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BB40 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604BB42 mov r1,r0
    c.r[0] >>= 2;  // 0604BB44 shlr2 r0
    c.r[0] >>= 2;  // 0604BB46 shlr2 r0
    c.r[0] &= 0x1u;  // 0604BB48 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BB4A tst r0,r0
    if (c.t) { goto L_0604BB54; }  // 0604BB4C bt 0x0604BB54
    c.r[11] = ld32(0x0604BD78u);  // 0604BB4E mov.l 0x0604BD78,r11
    c.r[13] = c.r[11]; goto L_0604BB8E;  // 0604BB50 bra 0x0604BB8E ; mov r11,r13
L_0604BB54:
    c.r[11] = ld32(0x0604BD7Cu);  // 0604BB54 mov.l 0x0604BD7C,r11
    c.r[13] = c.r[11]; goto L_0604BB8E;  // 0604BB56 bra 0x0604BB8E ; mov r11,r13
L_0604BB5A:
    c.r[0] = c.r[1];  // 0604BB5A mov r1,r0
    c.r[0] >>= 2;  // 0604BB5C shlr2 r0
    c.r[0] >>= 2;  // 0604BB5E shlr2 r0
    c.r[0] &= 0x1u;  // 0604BB60 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BB62 tst r0,r0
    if (c.t) { goto L_0604BB6C; }  // 0604BB64 bt 0x0604BB6C
    c.r[12] = ld32(0x0604BD78u);  // 0604BB66 mov.l 0x0604BD78,r12
    c.r[3] = c.r[12]; goto L_0604BB70;  // 0604BB68 bra 0x0604BB70 ; mov r12,r3
L_0604BB6C:
    c.r[12] = ld32(0x0604BD7Cu);  // 0604BB6C mov.l 0x0604BD7C,r12
    c.r[3] = c.r[12];  // 0604BB6E mov r12,r3
L_0604BB70:
    c.r[3] += 4;  // 0604BB70 add #4,r3
    st32(c.r[14], c.r[3]);  // 0604BB72 mov.l r3,@r14
    c.r[1] = ld32(0x0604BD6Cu);  // 0604BB74 mov.l 0x0604BD6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BB76 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0604BB78 mov r1,r0
    c.r[0] >>= 2;  // 0604BB7A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BB7C shlr r0
    c.r[0] &= 0x1u;  // 0604BB7E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BB80 tst r0,r0
    if (c.t) { goto L_0604BB8A; }  // 0604BB82 bt 0x0604BB8A
    c.r[11] = ld32(0x0604BD70u);  // 0604BB84 mov.l 0x0604BD70,r11
    c.r[13] = c.r[11]; goto L_0604BB8E;  // 0604BB86 bra 0x0604BB8E ; mov r11,r13
L_0604BB8A:
    c.r[11] = ld32(0x0604BD74u);  // 0604BB8A mov.l 0x0604BD74,r11
    c.r[13] = c.r[11];  // 0604BB8C mov r11,r13
L_0604BB8E:
    c.r[13] += 4;  // 0604BB8E add #4,r13
    c.r[1] = ld32(0x0604BD80u);  // 0604BB90 mov.l 0x0604BD80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604BB96u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BB96u) return; }  // 0604BB92 jsr @r1 ; mov r11,r4
    c.r[1] = ld32(0x0604BD84u);  // 0604BB96 mov.l 0x0604BD84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604BB9Cu; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BB9Cu) return; }  // 0604BB98 jsr @r1 ; mov.l @r14,r4
    c.r[1] = ld32(0x0604BD88u);  // 0604BB9C mov.l 0x0604BD88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604BBA2u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BBA2u) return; }  // 0604BB9E jsr @r1 ; mov r13,r4
    c.r[1] = ld32(0x0604BD6Cu);  // 0604BBA2 mov.l 0x0604BD6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BBA4 mov.b @r1,r1
    c.r[2] = 0x1u;  // 0604BBA6 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604BBA8 extu.b r1,r1
    c.r[0] = c.r[1];  // 0604BBAA mov r1,r0
    c.r[0] >>= 2;  // 0604BBAC shlr2 r0
    c.r[0] >>= 2;  // 0604BBAE shlr2 r0
    c.r[0] >>= 2;  // 0604BBB0 shlr2 r0
    c.r[1] >>= 2;  // 0604BBB2 shlr2 r1
    c.r[1] >>= 2;  // 0604BBB4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604BBB6 shlr r1
    c.r[1] >>= 2;  // 0604BBB8 shlr2 r1
    c.r[2] &= c.r[0];  // 0604BBBA and r0,r2
    c.t = c.r[1] == c.r[2];  // 0604BBBC cmp/eq r2,r1
    { const bool k = c.t; c.r[0] &= 0x1u; if (k) { goto L_0604BC7C; } }  // 0604BBBE bt/s 0x0604BC7C ; and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BBC2 tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[12]; if (k) { goto L_0604BBFC; } }  // 0604BBC4 bt/s 0x0604BBFC ; mov r12,r5
    c.r[9] = ld32(0x0604BD8Cu);  // 0604BBC8 mov.l 0x0604BD8C,r9
    c.r[1] = c.r[9];  // 0604BBCA mov r9,r1
    c.r[1] += 1;  // 0604BBCC add #1,r1
    c.r[8] = ld32(0x0604BD90u);  // 0604BBCE mov.l 0x0604BD90,r8
    c.r[10] = ld32(0x0604BD94u);  // 0604BBD0 mov.l 0x0604BD94,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BBD2 mov.b @r1,r1
    c.r[2] = ld32(c.r[8]);  // 0604BBD4 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604BBD6 extu.b r1,r1
    c.r[1] <<= 2;  // 0604BBD8 shll2 r1
    c.r[1] <<= 2;  // 0604BBDA shll2 r1
    c.r[1] += c.r[2];  // 0604BBDC add r2,r1
    c.r[1] += 3;  // 0604BBDE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BBE0 mov.b @r1,r1
    c.r[4] = 0x2u;  // 0604BBE2 mov #2,r4
    c.r[0] = c.r[1];  // 0604BBE4 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BBE6 shlr r0
    c.r[0] &= 0x3u;  // 0604BBE8 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BBEA tst r0,r0
    c.r[0] = c.t;  // 0604BBEC movt r0
    c.r[0] ^= 0x1u;  // 0604BBEE xor #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0604BBF4u; c.r[6] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BBF4u) return; }  // 0604BBF0 jsr @r10 ; mov r0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604BBF4 mov.b @r9,r1
    c.r[5] = c.r[11];  // 0604BBF6 mov r11,r5
    c.r[2] = ld32(c.r[8]); goto L_0604BC2A;  // 0604BBF8 bra 0x0604BC2A ; mov.l @r8,r2
L_0604BBFC:
    c.r[8] = ld32(0x0604BD8Cu);  // 0604BBFC mov.l 0x0604BD8C,r8
    c.r[9] = ld32(0x0604BD90u);  // 0604BBFE mov.l 0x0604BD90,r9
    c.r[10] = ld32(0x0604BD94u);  // 0604BC00 mov.l 0x0604BD94,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0604BC02 mov.b @r8+,r1
    c.r[2] = ld32(c.r[9]);  // 0604BC04 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604BC06 extu.b r1,r1
    c.r[1] <<= 2;  // 0604BC08 shll2 r1
    c.r[1] <<= 2;  // 0604BC0A shll2 r1
    c.r[1] += c.r[2];  // 0604BC0C add r2,r1
    c.r[1] += 3;  // 0604BC0E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BC10 mov.b @r1,r1
    c.r[4] = 0x2u;  // 0604BC12 mov #2,r4
    c.r[0] = c.r[1];  // 0604BC14 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BC16 shlr r0
    c.r[0] &= 0x3u;  // 0604BC18 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BC1A tst r0,r0
    c.r[0] = c.t;  // 0604BC1C movt r0
    c.r[0] ^= 0x1u;  // 0604BC1E xor #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0604BC24u; c.r[6] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC24u) return; }  // 0604BC20 jsr @r10 ; mov r0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604BC24 mov.b @r8,r1
    c.r[5] = c.r[11];  // 0604BC26 mov r11,r5
    c.r[2] = ld32(c.r[9]);  // 0604BC28 mov.l @r9,r2
L_0604BC2A:
    c.r[1] = c.r[1] & 0xFFu;  // 0604BC2A extu.b r1,r1
    c.r[1] <<= 2;  // 0604BC2C shll2 r1
    c.r[1] <<= 2;  // 0604BC2E shll2 r1
    c.r[1] += c.r[2];  // 0604BC30 add r2,r1
    c.r[1] += 3;  // 0604BC32 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BC34 mov.b @r1,r1
    c.r[4] = 0x0u;  // 0604BC36 mov #0,r4
    c.r[0] = c.r[1];  // 0604BC38 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BC3A shlr r0
    c.r[0] &= 0x3u;  // 0604BC3C and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BC3E tst r0,r0
    c.r[0] = c.t;  // 0604BC40 movt r0
    c.r[0] ^= 0x1u;  // 0604BC42 xor #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0604BC48u; c.r[6] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC48u) return; }  // 0604BC44 jsr @r10 ; mov r0,r6
    c.r[8] = ld32(0x0604BD94u);  // 0604BC48 mov.l 0x0604BD94,r8
    c.r[6] = 0x1u;  // 0604BC4A mov #1,r6
    c.r[5] = ld32(c.r[14]);  // 0604BC4C mov.l @r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BC52u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC52u) return; }  // 0604BC4E jsr @r8 ; mov #3,r4
    c.r[6] = 0x1u;  // 0604BC52 mov #1,r6
    c.r[5] = c.r[13];  // 0604BC54 mov r13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BC5Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC5Au) return; }  // 0604BC56 jsr @r8 ; mov #1,r4
    c.r[8] = ld32(0x0604BD98u);  // 0604BC5A mov.l 0x0604BD98,r8
    c.r[6] = 0x58u;  // 0604BC5C mov #88,r6
    c.r[5] = c.r[12];  // 0604BC5E mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BC64u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC64u) return; }  // 0604BC60 jsr @r8 ; mov #2,r4
    c.r[6] = 0x18u;  // 0604BC64 mov #24,r6
    c.r[5] = ld32(c.r[14]);  // 0604BC66 mov.l @r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BC6Cu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC6Cu) return; }  // 0604BC68 jsr @r8 ; mov #3,r4
    c.r[6] = 0x58u;  // 0604BC6C mov #88,r6
    c.r[5] = c.r[11];  // 0604BC6E mov r11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BC74u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BC74u) return; }  // 0604BC70 jsr @r8 ; mov #0,r4
    c.r[6] = 0x18u;  // 0604BC74 mov #24,r6
    c.r[5] = c.r[13];  // 0604BC76 mov r13,r5
    c.r[4] = 0x1u; goto L_0604BD34;  // 0604BC78 bra 0x0604BD34 ; mov #1,r4
L_0604BC7C:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BC7C tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[12]; if (k) { goto L_0604BCB6; } }  // 0604BC7E bt/s 0x0604BCB6 ; mov r12,r5
    c.r[9] = ld32(0x0604BD8Cu);  // 0604BC82 mov.l 0x0604BD8C,r9
    c.r[1] = c.r[9];  // 0604BC84 mov r9,r1
    c.r[1] += 1;  // 0604BC86 add #1,r1
    c.r[8] = ld32(0x0604BD90u);  // 0604BC88 mov.l 0x0604BD90,r8
    c.r[10] = ld32(0x0604BD94u);  // 0604BC8A mov.l 0x0604BD94,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BC8C mov.b @r1,r1
    c.r[2] = ld32(c.r[8]);  // 0604BC8E mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604BC90 extu.b r1,r1
    c.r[1] <<= 2;  // 0604BC92 shll2 r1
    c.r[1] <<= 2;  // 0604BC94 shll2 r1
    c.r[1] += c.r[2];  // 0604BC96 add r2,r1
    c.r[1] += 3;  // 0604BC98 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BC9A mov.b @r1,r1
    c.r[4] = 0x0u;  // 0604BC9C mov #0,r4
    c.r[0] = c.r[1];  // 0604BC9E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BCA0 shlr r0
    c.r[0] &= 0x3u;  // 0604BCA2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BCA4 tst r0,r0
    c.r[0] = c.t;  // 0604BCA6 movt r0
    c.r[0] ^= 0x1u;  // 0604BCA8 xor #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0604BCAEu; c.r[6] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BCAEu) return; }  // 0604BCAA jsr @r10 ; mov r0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0604BCAE mov.b @r9,r1
    c.r[5] = c.r[11];  // 0604BCB0 mov r11,r5
    c.r[2] = ld32(c.r[8]); goto L_0604BCE4;  // 0604BCB2 bra 0x0604BCE4 ; mov.l @r8,r2
L_0604BCB6:
    c.r[8] = ld32(0x0604BD8Cu);  // 0604BCB6 mov.l 0x0604BD8C,r8
    c.r[9] = ld32(0x0604BD90u);  // 0604BCB8 mov.l 0x0604BD90,r9
    c.r[10] = ld32(0x0604BD94u);  // 0604BCBA mov.l 0x0604BD94,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0604BCBC mov.b @r8+,r1
    c.r[2] = ld32(c.r[9]);  // 0604BCBE mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0604BCC0 extu.b r1,r1
    c.r[1] <<= 2;  // 0604BCC2 shll2 r1
    c.r[1] <<= 2;  // 0604BCC4 shll2 r1
    c.r[1] += c.r[2];  // 0604BCC6 add r2,r1
    c.r[1] += 3;  // 0604BCC8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BCCA mov.b @r1,r1
    c.r[4] = 0x0u;  // 0604BCCC mov #0,r4
    c.r[0] = c.r[1];  // 0604BCCE mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BCD0 shlr r0
    c.r[0] &= 0x3u;  // 0604BCD2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BCD4 tst r0,r0
    c.r[0] = c.t;  // 0604BCD6 movt r0
    c.r[0] ^= 0x1u;  // 0604BCD8 xor #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0604BCDEu; c.r[6] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BCDEu) return; }  // 0604BCDA jsr @r10 ; mov r0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0604BCDE mov.b @r8,r1
    c.r[5] = c.r[11];  // 0604BCE0 mov r11,r5
    c.r[2] = ld32(c.r[9]);  // 0604BCE2 mov.l @r9,r2
L_0604BCE4:
    c.r[1] = c.r[1] & 0xFFu;  // 0604BCE4 extu.b r1,r1
    c.r[1] <<= 2;  // 0604BCE6 shll2 r1
    c.r[1] <<= 2;  // 0604BCE8 shll2 r1
    c.r[1] += c.r[2];  // 0604BCEA add r2,r1
    c.r[1] += 3;  // 0604BCEC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BCEE mov.b @r1,r1
    c.r[4] = 0x2u;  // 0604BCF0 mov #2,r4
    c.r[0] = c.r[1];  // 0604BCF2 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0604BCF4 shlr r0
    c.r[0] &= 0x3u;  // 0604BCF6 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0604BCF8 tst r0,r0
    c.r[0] = c.t;  // 0604BCFA movt r0
    c.r[0] ^= 0x1u;  // 0604BCFC xor #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0604BD02u; c.r[6] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD02u) return; }  // 0604BCFE jsr @r10 ; mov r0,r6
    c.r[8] = ld32(0x0604BD94u);  // 0604BD02 mov.l 0x0604BD94,r8
    c.r[6] = 0x1u;  // 0604BD04 mov #1,r6
    c.r[5] = ld32(c.r[14]);  // 0604BD06 mov.l @r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BD0Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD0Cu) return; }  // 0604BD08 jsr @r8 ; mov #1,r4
    c.r[6] = 0x1u;  // 0604BD0C mov #1,r6
    c.r[5] = c.r[13];  // 0604BD0E mov r13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BD14u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD14u) return; }  // 0604BD10 jsr @r8 ; mov #3,r4
    c.r[8] = ld32(0x0604BD98u);  // 0604BD14 mov.l 0x0604BD98,r8
    c.r[6] = 0x58u;  // 0604BD16 mov #88,r6
    c.r[5] = c.r[12];  // 0604BD18 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BD1Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD1Eu) return; }  // 0604BD1A jsr @r8 ; mov #0,r4
    c.r[6] = 0x18u;  // 0604BD1E mov #24,r6
    c.r[5] = ld32(c.r[14]);  // 0604BD20 mov.l @r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BD26u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD26u) return; }  // 0604BD22 jsr @r8 ; mov #1,r4
    c.r[6] = 0x58u;  // 0604BD26 mov #88,r6
    c.r[5] = c.r[11];  // 0604BD28 mov r11,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0604BD2Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD2Eu) return; }  // 0604BD2A jsr @r8 ; mov #2,r4
    c.r[6] = 0x18u;  // 0604BD2E mov #24,r6
    c.r[5] = c.r[13];  // 0604BD30 mov r13,r5
    c.r[4] = 0x3u;  // 0604BD32 mov #3,r4
L_0604BD34:
    { const uint32_t x = c.r[8]; c.pr = 0x0604BD38u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD38u) return; }  // 0604BD34 jsr @r8 ; nop
    c.r[1] = ld32(0x0604BD6Cu);  // 0604BD38 mov.l 0x0604BD6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0604BD3A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0604BD3C extu.b r1,r1
    c.r[1] >>= 2;  // 0604BD3E shlr2 r1
    c.r[1] >>= 2;  // 0604BD40 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0604BD42 shlr r1
    c.r[1] >>= 2;  // 0604BD44 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0604BD46 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x11u; if (k) { goto L_0604BD4E; } }  // 0604BD48 bt/s 0x0604BD4E ; mov #17,r4
    c.r[4] = 0x24u;  // 0604BD4C mov #36,r4
L_0604BD4E:
    c.r[1] = ld32(0x0604BD9Cu);  // 0604BD4E mov.l 0x0604BD9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0604BD54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0604BD54u) return; }  // 0604BD50 jsr @r1 ; nop
    c.r[14] += 4;  // 0604BD54 add #4,r14
    c.r[15] = c.r[14];  // 0604BD56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0604BD58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0604BD5A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0604BD5C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0604BD5E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0604BD60 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0604BD62 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0604BD64 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0604BD66 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
