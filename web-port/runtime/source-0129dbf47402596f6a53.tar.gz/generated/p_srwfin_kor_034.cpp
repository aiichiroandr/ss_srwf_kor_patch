#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_0608DA40(SH2Context& c) {
    ran[2066] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DA40 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608DA42 add #-20,r15
    c.r[14] = c.r[15];  // 0608DA44 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DA46 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608DA48 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608DA4A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DA4C mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DA4E mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DA50 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DA52 mov r1,r2
    c.r[2] += 4;  // 0608DA54 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608DA56 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DA58 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DA5A mov r1,r2
    c.r[2] += 56;  // 0608DA5C add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608DA5E mov.l r2,@(16,r14)
    c.r[4] = ld32(c.r[14] + 16);  // 0608DA60 mov.l @(16,r14),r4
    c.r[5] = c.r[4];  // 0608DA62 mov r4,r5
    c.r[4] += 68;  // 0608DA64 add #68,r4
    c.r[6] = ld32(c.r[4]);  // 0608DA66 mov.l @r4,r6
    c.r[4] = ld32(c.r[14] + 4);  // 0608DA68 mov.l @(4,r14),r4
    c.r[0] = ld32(c.r[4] + 12);  // 0608DA6A mov.l @(12,r4),r0
    c.r[4] = c.r[0];  // 0608DA6C mov r0,r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 0608DA6E shar r4
    c.r[5] = c.r[4];  // 0608DA70 mov r4,r5
    c.r[4] = ld32(c.r[14] + 4);  // 0608DA72 mov.l @(4,r14),r4
    c.r[1] = ld32(c.r[4]);  // 0608DA74 mov.l @r4,r1
    c.r[4] = ld32(c.r[14] + 4);  // 0608DA76 mov.l @(4,r14),r4
    c.r[2] = ld32(c.r[4] + 4);  // 0608DA78 mov.l @(4,r4),r2
    c.r[4] = ld32(c.r[14] + 4);  // 0608DA7A mov.l @(4,r14),r4
    c.r[3] = ld32(c.r[4] + 8);  // 0608DA7C mov.l @(8,r4),r3
    c.r[4] = c.r[5];  // 0608DA7E mov r5,r4
    c.r[0] = c.r[4];  // 0608DA80 mov r4,r0
    c.r[0] <<= 2;  // 0608DA82 shll2 r0
    c.r[7] = c.r[3];  // 0608DA84 mov r3,r7
    c.r[7] += c.r[0];  // 0608DA86 add r0,r7
    c.r[4] = ld32(c.r[14] + 12);  // 0608DA88 mov.l @(12,r14),r4
    c.r[0] = ld32(c.r[4]);  // 0608DA8A mov.l @r4,r0
    c.t = c.r[7] > c.r[0];  // 0608DA8C cmp/hi r0,r7
    if (c.t) { goto L_0608DAB0; }  // 0608DA8E bt 0x0608DAB0
L_0608DA90:
    c.t = c.r[3] >= c.r[7];  // 0608DA90 cmp/hs r7,r3
    if (!c.t) { goto L_0608DA98; }  // 0608DA92 bf 0x0608DA98
    goto L_0608DAAC;  // 0608DA94 bra 0x0608DAAC ; nop
L_0608DA98:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608DA98 mov.w @r3,r4
    st16(c.r[1], c.r[4]);  // 0608DA9A mov.w r4,@r1
    c.r[3] += 2;  // 0608DA9C add #2,r3
    c.r[1] += 2;  // 0608DA9E add #2,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608DAA0 mov.w @r3,r4
    st16(c.r[2], c.r[4]);  // 0608DAA2 mov.w r4,@r2
    c.r[3] += 2;  // 0608DAA4 add #2,r3
    c.r[2] += 2;  // 0608DAA6 add #2,r2
    SH2_POLL(c); goto L_0608DA90;  // 0608DAA8 bra 0x0608DA90 ; nop
L_0608DAAC:
    goto L_0608DADE;  // 0608DAAC bra 0x0608DADE ; nop
L_0608DAB0:
    c.t = (int32_t)c.r[5] > 0;  // 0608DAB0 cmp/pl r5
    if (c.t) { goto L_0608DAB8; }  // 0608DAB2 bt 0x0608DAB8
    goto L_0608DADE;  // 0608DAB4 bra 0x0608DADE ; nop
L_0608DAB8:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608DAB8 mov.w @r3,r4
    st16(c.r[1], c.r[4]);  // 0608DABA mov.w r4,@r1
    c.r[3] += 2;  // 0608DABC add #2,r3
    c.r[1] += 2;  // 0608DABE add #2,r1
    c.t = c.r[3] >= c.r[6];  // 0608DAC0 cmp/hs r6,r3
    if (!c.t) { goto L_0608DAC8; }  // 0608DAC2 bf 0x0608DAC8
    c.r[4] = ld32(c.r[14] + 12);  // 0608DAC4 mov.l @(12,r14),r4
    c.r[3] = ld32(c.r[4]);  // 0608DAC6 mov.l @r4,r3
L_0608DAC8:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608DAC8 mov.w @r3,r4
    st16(c.r[2], c.r[4]);  // 0608DACA mov.w r4,@r2
    c.r[3] += 2;  // 0608DACC add #2,r3
    c.r[2] += 2;  // 0608DACE add #2,r2
    c.t = c.r[3] >= c.r[6];  // 0608DAD0 cmp/hs r6,r3
    if (!c.t) { goto L_0608DAD8; }  // 0608DAD2 bf 0x0608DAD8
    c.r[4] = ld32(c.r[14] + 12);  // 0608DAD4 mov.l @(12,r14),r4
    c.r[3] = ld32(c.r[4]);  // 0608DAD6 mov.l @r4,r3
L_0608DAD8:
    c.r[5] -= 1;  // 0608DAD8 add #-1,r5
    SH2_POLL(c); goto L_0608DAB0;  // 0608DADA bra 0x0608DAB0 ; nop
L_0608DADE:
    c.r[14] += 20;  // 0608DADE add #20,r14
    c.r[15] = c.r[14];  // 0608DAE0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DAE2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DAE4 rts ; nop
}

void f_0608DAE8(SH2Context& c) {
    ran[2067] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DAE8 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608DAEA add #-20,r15
    c.r[14] = c.r[15];  // 0608DAEC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DAEE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608DAF0 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608DAF2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DAF4 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DAF6 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DAF8 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DAFA mov r1,r2
    c.r[2] += 4;  // 0608DAFC add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608DAFE mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DB00 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DB02 mov r1,r2
    c.r[2] += 56;  // 0608DB04 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608DB06 mov.l r2,@(16,r14)
    c.r[4] = ld32(c.r[14] + 16);  // 0608DB08 mov.l @(16,r14),r4
    c.r[5] = c.r[4];  // 0608DB0A mov r4,r5
    c.r[4] += 68;  // 0608DB0C add #68,r4
    c.r[6] = ld32(c.r[4]);  // 0608DB0E mov.l @r4,r6
    c.r[4] = ld32(c.r[14] + 4);  // 0608DB10 mov.l @(4,r14),r4
    c.r[5] = ld32(c.r[4] + 12);  // 0608DB12 mov.l @(12,r4),r5
    c.r[4] = ld32(c.r[14] + 4);  // 0608DB14 mov.l @(4,r14),r4
    c.r[1] = ld32(c.r[4]);  // 0608DB16 mov.l @r4,r1
    c.r[4] = ld32(c.r[14] + 4);  // 0608DB18 mov.l @(4,r14),r4
    c.r[2] = ld32(c.r[4] + 4);  // 0608DB1A mov.l @(4,r4),r2
    c.r[4] = ld32(c.r[14] + 4);  // 0608DB1C mov.l @(4,r14),r4
    c.r[3] = ld32(c.r[4] + 8);  // 0608DB1E mov.l @(8,r4),r3
    c.r[4] = c.r[5];  // 0608DB20 mov r5,r4
    c.r[0] = c.r[4];  // 0608DB22 mov r4,r0
    c.r[0] += c.r[0];  // 0608DB24 add r0,r0
    c.r[7] = c.r[3];  // 0608DB26 mov r3,r7
    c.r[7] += c.r[0];  // 0608DB28 add r0,r7
    c.r[4] = ld32(c.r[14] + 12);  // 0608DB2A mov.l @(12,r14),r4
    c.r[0] = ld32(c.r[4]);  // 0608DB2C mov.l @r4,r0
    c.t = c.r[7] > c.r[0];  // 0608DB2E cmp/hi r0,r7
    if (c.t) { goto L_0608DB52; }  // 0608DB30 bt 0x0608DB52
L_0608DB32:
    c.t = c.r[3] >= c.r[7];  // 0608DB32 cmp/hs r7,r3
    if (!c.t) { goto L_0608DB3A; }  // 0608DB34 bf 0x0608DB3A
    goto L_0608DB4E;  // 0608DB36 bra 0x0608DB4E ; nop
L_0608DB3A:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608DB3A mov.b @r3,r4
    st8(c.r[1], c.r[4]);  // 0608DB3C mov.b r4,@r1
    c.r[3] += 1;  // 0608DB3E add #1,r3
    c.r[1] += 1;  // 0608DB40 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608DB42 mov.b @r3,r4
    st8(c.r[2], c.r[4]);  // 0608DB44 mov.b r4,@r2
    c.r[3] += 1;  // 0608DB46 add #1,r3
    c.r[2] += 1;  // 0608DB48 add #1,r2
    SH2_POLL(c); goto L_0608DB32;  // 0608DB4A bra 0x0608DB32 ; nop
L_0608DB4E:
    goto L_0608DB80;  // 0608DB4E bra 0x0608DB80 ; nop
L_0608DB52:
    c.t = (int32_t)c.r[5] > 0;  // 0608DB52 cmp/pl r5
    if (c.t) { goto L_0608DB5A; }  // 0608DB54 bt 0x0608DB5A
    goto L_0608DB80;  // 0608DB56 bra 0x0608DB80 ; nop
L_0608DB5A:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608DB5A mov.b @r3,r4
    st8(c.r[1], c.r[4]);  // 0608DB5C mov.b r4,@r1
    c.r[3] += 1;  // 0608DB5E add #1,r3
    c.r[1] += 1;  // 0608DB60 add #1,r1
    c.t = c.r[3] >= c.r[6];  // 0608DB62 cmp/hs r6,r3
    if (!c.t) { goto L_0608DB6A; }  // 0608DB64 bf 0x0608DB6A
    c.r[4] = ld32(c.r[14] + 12);  // 0608DB66 mov.l @(12,r14),r4
    c.r[3] = ld32(c.r[4]);  // 0608DB68 mov.l @r4,r3
L_0608DB6A:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608DB6A mov.b @r3,r4
    st8(c.r[2], c.r[4]);  // 0608DB6C mov.b r4,@r2
    c.r[3] += 1;  // 0608DB6E add #1,r3
    c.r[2] += 1;  // 0608DB70 add #1,r2
    c.t = c.r[3] >= c.r[6];  // 0608DB72 cmp/hs r6,r3
    if (!c.t) { goto L_0608DB7A; }  // 0608DB74 bf 0x0608DB7A
    c.r[4] = ld32(c.r[14] + 12);  // 0608DB76 mov.l @(12,r14),r4
    c.r[3] = ld32(c.r[4]);  // 0608DB78 mov.l @r4,r3
L_0608DB7A:
    c.r[5] -= 1;  // 0608DB7A add #-1,r5
    SH2_POLL(c); goto L_0608DB52;  // 0608DB7C bra 0x0608DB52 ; nop
L_0608DB80:
    c.r[14] += 20;  // 0608DB80 add #20,r14
    c.r[15] = c.r[14];  // 0608DB82 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DB84 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DB86 rts ; nop
}

void f_0608DB8C(SH2Context& c) {
    ran[2068] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DB8C mov.l r14,@-r15
    c.r[15] -= 20;  // 0608DB8E add #-20,r15
    c.r[14] = c.r[15];  // 0608DB90 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DB92 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608DB94 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608DB96 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DB98 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DB9A mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DB9C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DB9E mov r1,r2
    c.r[2] += 4;  // 0608DBA0 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608DBA2 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DBA4 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DBA6 mov r1,r2
    c.r[2] += 56;  // 0608DBA8 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608DBAA mov.l r2,@(16,r14)
    c.r[5] = ld32(c.r[14] + 16);  // 0608DBAC mov.l @(16,r14),r5
    c.r[6] = c.r[5];  // 0608DBAE mov r5,r6
    c.r[5] += 68;  // 0608DBB0 add #68,r5
    c.r[7] = ld32(c.r[5]);  // 0608DBB2 mov.l @r5,r7
    c.r[5] = ld32(c.r[14] + 4);  // 0608DBB4 mov.l @(4,r14),r5
    c.r[4] = ld32(c.r[5] + 12);  // 0608DBB6 mov.l @(12,r5),r4
    c.r[5] = c.r[4];  // 0608DBB8 mov r4,r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0608DBBA shar r5
    c.r[6] = c.r[5];  // 0608DBBC mov r5,r6
    c.r[5] = ld32(c.r[14] + 4);  // 0608DBBE mov.l @(4,r14),r5
    c.r[1] = ld32(c.r[5]);  // 0608DBC0 mov.l @r5,r1
    c.r[5] = ld32(c.r[14] + 4);  // 0608DBC2 mov.l @(4,r14),r5
    c.r[2] = ld32(c.r[5] + 8);  // 0608DBC4 mov.l @(8,r5),r2
    c.r[5] = c.r[6];  // 0608DBC6 mov r6,r5
    c.r[4] = c.r[5];  // 0608DBC8 mov r5,r4
    c.r[4] += c.r[4];  // 0608DBCA add r4,r4
    c.r[3] = c.r[2];  // 0608DBCC mov r2,r3
    c.r[3] += c.r[4];  // 0608DBCE add r4,r3
    c.t = c.r[3] > c.r[7];  // 0608DBD0 cmp/hi r7,r3
    if (c.t) { goto L_0608DBEC; }  // 0608DBD2 bt 0x0608DBEC
L_0608DBD4:
    c.t = c.r[2] >= c.r[3];  // 0608DBD4 cmp/hs r3,r2
    if (!c.t) { goto L_0608DBDC; }  // 0608DBD6 bf 0x0608DBDC
    goto L_0608DBE8;  // 0608DBD8 bra 0x0608DBE8 ; nop
L_0608DBDC:
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608DBDC mov.w @r2,r5
    st16(c.r[1], c.r[5]);  // 0608DBDE mov.w r5,@r1
    c.r[2] += 2;  // 0608DBE0 add #2,r2
    c.r[1] += 2;  // 0608DBE2 add #2,r1
    SH2_POLL(c); goto L_0608DBD4;  // 0608DBE4 bra 0x0608DBD4 ; nop
L_0608DBE8:
    goto L_0608DC34;  // 0608DBE8 bra 0x0608DC34 ; nop
L_0608DBEC:
    c.r[5] = c.r[6];  // 0608DBEC mov r6,r5
    c.r[4] = c.r[5];  // 0608DBEE mov r5,r4
    c.r[4] += c.r[4];  // 0608DBF0 add r4,r4
    c.r[3] = c.r[2];  // 0608DBF2 mov r2,r3
    c.r[3] += c.r[4];  // 0608DBF4 add r4,r3
    c.r[5] = ld32(c.r[14] + 12);  // 0608DBF6 mov.l @(12,r14),r5
    c.r[4] = ld32(c.r[5] + 4);  // 0608DBF8 mov.l @(4,r5),r4
    c.r[5] = c.r[4];  // 0608DBFA mov r4,r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0608DBFC shar r5
    c.r[4] = c.r[5];  // 0608DBFE mov r5,r4
    c.r[5] = c.r[4];  // 0608DC00 mov r4,r5
    c.r[4] = c.r[5];  // 0608DC02 mov r5,r4
    c.r[4] += c.r[4];  // 0608DC04 add r4,r4
    c.r[3] -= c.r[4];  // 0608DC06 sub r4,r3
L_0608DC08:
    c.t = c.r[2] >= c.r[7];  // 0608DC08 cmp/hs r7,r2
    if (!c.t) { goto L_0608DC10; }  // 0608DC0A bf 0x0608DC10
    goto L_0608DC1C;  // 0608DC0C bra 0x0608DC1C ; nop
L_0608DC10:
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608DC10 mov.w @r2,r5
    st16(c.r[1], c.r[5]);  // 0608DC12 mov.w r5,@r1
    c.r[2] += 2;  // 0608DC14 add #2,r2
    c.r[1] += 2;  // 0608DC16 add #2,r1
    SH2_POLL(c); goto L_0608DC08;  // 0608DC18 bra 0x0608DC08 ; nop
L_0608DC1C:
    c.r[5] = ld32(c.r[14] + 12);  // 0608DC1C mov.l @(12,r14),r5
    c.r[2] = ld32(c.r[5]);  // 0608DC1E mov.l @r5,r2
L_0608DC20:
    c.t = c.r[2] >= c.r[3];  // 0608DC20 cmp/hs r3,r2
    if (!c.t) { goto L_0608DC28; }  // 0608DC22 bf 0x0608DC28
    goto L_0608DC34;  // 0608DC24 bra 0x0608DC34 ; nop
L_0608DC28:
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608DC28 mov.w @r2,r5
    st16(c.r[1], c.r[5]);  // 0608DC2A mov.w r5,@r1
    c.r[2] += 2;  // 0608DC2C add #2,r2
    c.r[1] += 2;  // 0608DC2E add #2,r1
    SH2_POLL(c); goto L_0608DC20;  // 0608DC30 bra 0x0608DC20 ; nop
L_0608DC34:
    c.r[14] += 20;  // 0608DC34 add #20,r14
    c.r[15] = c.r[14];  // 0608DC36 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DC38 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DC3A rts ; nop
}

void f_0608DC40(SH2Context& c) {
    ran[2069] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DC40 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608DC42 add #-20,r15
    c.r[14] = c.r[15];  // 0608DC44 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DC46 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608DC48 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608DC4A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DC4C mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DC4E mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DC50 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DC52 mov r1,r2
    c.r[2] += 4;  // 0608DC54 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608DC56 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DC58 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DC5A mov r1,r2
    c.r[2] += 56;  // 0608DC5C add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608DC5E mov.l r2,@(16,r14)
    c.r[5] = ld32(c.r[14] + 16);  // 0608DC60 mov.l @(16,r14),r5
    c.r[6] = c.r[5];  // 0608DC62 mov r5,r6
    c.r[5] += 68;  // 0608DC64 add #68,r5
    c.r[7] = ld32(c.r[5]);  // 0608DC66 mov.l @r5,r7
    c.r[5] = ld32(c.r[14] + 4);  // 0608DC68 mov.l @(4,r14),r5
    c.r[6] = ld32(c.r[5] + 12);  // 0608DC6A mov.l @(12,r5),r6
    c.r[5] = ld32(c.r[14] + 4);  // 0608DC6C mov.l @(4,r14),r5
    c.r[1] = ld32(c.r[5]);  // 0608DC6E mov.l @r5,r1
    c.r[5] = ld32(c.r[14] + 4);  // 0608DC70 mov.l @(4,r14),r5
    c.r[2] = ld32(c.r[5] + 8);  // 0608DC72 mov.l @(8,r5),r2
    c.r[3] = c.r[2];  // 0608DC74 mov r2,r3
    c.r[3] += c.r[6];  // 0608DC76 add r6,r3
    c.t = c.r[3] > c.r[7];  // 0608DC78 cmp/hi r7,r3
    if (c.t) { goto L_0608DC94; }  // 0608DC7A bt 0x0608DC94
L_0608DC7C:
    c.t = c.r[2] >= c.r[3];  // 0608DC7C cmp/hs r3,r2
    if (!c.t) { goto L_0608DC84; }  // 0608DC7E bf 0x0608DC84
    goto L_0608DC90;  // 0608DC80 bra 0x0608DC90 ; nop
L_0608DC84:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608DC84 mov.b @r2,r5
    st8(c.r[1], c.r[5]);  // 0608DC86 mov.b r5,@r1
    c.r[2] += 1;  // 0608DC88 add #1,r2
    c.r[1] += 1;  // 0608DC8A add #1,r1
    SH2_POLL(c); goto L_0608DC7C;  // 0608DC8C bra 0x0608DC7C ; nop
L_0608DC90:
    goto L_0608DCCA;  // 0608DC90 bra 0x0608DCCA ; nop
L_0608DC94:
    c.r[3] = c.r[2];  // 0608DC94 mov r2,r3
    c.r[3] += c.r[6];  // 0608DC96 add r6,r3
    c.r[5] = ld32(c.r[14] + 12);  // 0608DC98 mov.l @(12,r14),r5
    c.r[4] = ld32(c.r[5] + 4);  // 0608DC9A mov.l @(4,r5),r4
    c.r[3] -= c.r[4];  // 0608DC9C sub r4,r3
L_0608DC9E:
    c.t = c.r[2] >= c.r[7];  // 0608DC9E cmp/hs r7,r2
    if (!c.t) { goto L_0608DCA6; }  // 0608DCA0 bf 0x0608DCA6
    goto L_0608DCB2;  // 0608DCA2 bra 0x0608DCB2 ; nop
L_0608DCA6:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608DCA6 mov.b @r2,r5
    st8(c.r[1], c.r[5]);  // 0608DCA8 mov.b r5,@r1
    c.r[2] += 1;  // 0608DCAA add #1,r2
    c.r[1] += 1;  // 0608DCAC add #1,r1
    SH2_POLL(c); goto L_0608DC9E;  // 0608DCAE bra 0x0608DC9E ; nop
L_0608DCB2:
    c.r[5] = ld32(c.r[14] + 12);  // 0608DCB2 mov.l @(12,r14),r5
    c.r[2] = ld32(c.r[5]);  // 0608DCB4 mov.l @r5,r2
L_0608DCB6:
    c.t = c.r[2] >= c.r[3];  // 0608DCB6 cmp/hs r3,r2
    if (!c.t) { goto L_0608DCBE; }  // 0608DCB8 bf 0x0608DCBE
    goto L_0608DCCA;  // 0608DCBA bra 0x0608DCCA ; nop
L_0608DCBE:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608DCBE mov.b @r2,r5
    st8(c.r[1], c.r[5]);  // 0608DCC0 mov.b r5,@r1
    c.r[2] += 1;  // 0608DCC2 add #1,r2
    c.r[1] += 1;  // 0608DCC4 add #1,r1
    SH2_POLL(c); goto L_0608DCB6;  // 0608DCC6 bra 0x0608DCB6 ; nop
L_0608DCCA:
    c.r[14] += 20;  // 0608DCCA add #20,r14
    c.r[15] = c.r[14];  // 0608DCCC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DCCE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DCD0 rts ; nop
}

void f_0608DCD4(SH2Context& c) {
    ran[2070] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608DCD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DCD6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608DCD8 sts.l pr,@-r15
    c.r[15] -= 12;  // 0608DCDA add #-12,r15
    c.r[14] = c.r[15];  // 0608DCDC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DCDE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608DCE0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DCE2 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608DCE4 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608DCE6 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608DCE8 mov r1,r2
    c.r[2] += 56;  // 0608DCEA add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DCEC mov.l r2,@(8,r14)
L_0608DCEE:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DCEE mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DCF0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DCF2 mov.w 0x0608DDF6,r3
    c.r[1] += c.r[3];  // 0608DCF4 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608DCF6 mov.l @r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0608DCF8 cmp/pz r2
    if (c.t) { goto L_0608DD00; }  // 0608DCFA bt 0x0608DD00
    goto L_0608DDE8;  // 0608DCFC bra 0x0608DDE8 ; nop
L_0608DD00:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD00 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 36);  // 0608DD02 mov.l @(36,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608DD04 cmp/eq #1,r0
    if (!c.t) { goto L_0608DD66; }  // 0608DD06 bf 0x0608DD66
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD08 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 0608DD0A mov.l @(40,r1),r2
    c.r[1] = 0x8u;  // 0608DD0C mov #8,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608DD0E cmp/gt r1,r2
    if (c.t) { goto L_0608DD3C; }  // 0608DD10 bt 0x0608DD3C
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD12 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DD14 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DD16 mov.w 0x0608DDF6,r3
    c.r[1] += c.r[3];  // 0608DD18 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608DD1A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608DD1C mov r2,r1
    c.r[2] = c.r[1];  // 0608DD1E mov r1,r2
    c.r[2] <<= 2;  // 0608DD20 shll2 r2
    c.r[2] <<= 2;  // 0608DD22 shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF8u);  // 0608DD24 mov.w 0x0608DDF8,r3
    c.r[1] = c.r[2];  // 0608DD26 mov r2,r1
    c.r[1] += c.r[3];  // 0608DD28 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DD2A mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0608DD2C add r2,r1
    c.r[5] = c.r[1];  // 0608DD2E mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DD30 mov.l @r14,r4
    c.r[8] = ld32(0x0608DDFCu);  // 0608DD32 mov.l 0x0608DDFC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DD38u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DD38u) return; }  // 0608DD34 jsr @r8 ; nop
    goto L_0608DD62;  // 0608DD38 bra 0x0608DD62 ; nop
L_0608DD3C:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD3C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DD3E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DD40 mov.w 0x0608DDF6,r3
    c.r[1] += c.r[3];  // 0608DD42 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608DD44 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608DD46 mov r2,r1
    c.r[2] = c.r[1];  // 0608DD48 mov r1,r2
    c.r[2] <<= 2;  // 0608DD4A shll2 r2
    c.r[2] <<= 2;  // 0608DD4C shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF8u);  // 0608DD4E mov.w 0x0608DDF8,r3
    c.r[1] = c.r[2];  // 0608DD50 mov r2,r1
    c.r[1] += c.r[3];  // 0608DD52 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DD54 mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0608DD56 add r2,r1
    c.r[5] = c.r[1];  // 0608DD58 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DD5A mov.l @r14,r4
    c.r[8] = ld32(0x0608DE00u);  // 0608DD5C mov.l 0x0608DE00,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DD62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DD62u) return; }  // 0608DD5E jsr @r8 ; nop
L_0608DD62:
    goto L_0608DDC0;  // 0608DD62 bra 0x0608DDC0 ; nop
L_0608DD66:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD66 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 0608DD68 mov.l @(40,r1),r2
    c.r[1] = 0x8u;  // 0608DD6A mov #8,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608DD6C cmp/gt r1,r2
    if (c.t) { goto L_0608DD9A; }  // 0608DD6E bt 0x0608DD9A
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD70 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DD72 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DD74 mov.w 0x0608DDF6,r3
    c.r[1] += c.r[3];  // 0608DD76 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608DD78 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608DD7A mov r2,r1
    c.r[2] = c.r[1];  // 0608DD7C mov r1,r2
    c.r[2] <<= 2;  // 0608DD7E shll2 r2
    c.r[2] <<= 2;  // 0608DD80 shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF8u);  // 0608DD82 mov.w 0x0608DDF8,r3
    c.r[1] = c.r[2];  // 0608DD84 mov r2,r1
    c.r[1] += c.r[3];  // 0608DD86 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DD88 mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0608DD8A add r2,r1
    c.r[5] = c.r[1];  // 0608DD8C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DD8E mov.l @r14,r4
    c.r[8] = ld32(0x0608DE04u);  // 0608DD90 mov.l 0x0608DE04,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DD96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DD96u) return; }  // 0608DD92 jsr @r8 ; nop
    goto L_0608DDC0;  // 0608DD96 bra 0x0608DDC0 ; nop
L_0608DD9A:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DD9A mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DD9C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DD9E mov.w 0x0608DDF6,r3
    c.r[1] += c.r[3];  // 0608DDA0 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608DDA2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608DDA4 mov r2,r1
    c.r[2] = c.r[1];  // 0608DDA6 mov r1,r2
    c.r[2] <<= 2;  // 0608DDA8 shll2 r2
    c.r[2] <<= 2;  // 0608DDAA shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF8u);  // 0608DDAC mov.w 0x0608DDF8,r3
    c.r[1] = c.r[2];  // 0608DDAE mov r2,r1
    c.r[1] += c.r[3];  // 0608DDB0 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DDB2 mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0608DDB4 add r2,r1
    c.r[5] = c.r[1];  // 0608DDB6 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DDB8 mov.l @r14,r4
    c.r[8] = ld32(0x0608DE08u);  // 0608DDBA mov.l 0x0608DE08,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DDC0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DDC0u) return; }  // 0608DDBC jsr @r8 ; nop
L_0608DDC0:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DDC0 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DDC2 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DDC4 mov.w 0x0608DDF6,r3
    c.r[2] = c.r[1];  // 0608DDC6 mov r1,r2
    c.r[2] += c.r[3];  // 0608DDC8 add r3,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608DDCA mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DDCC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DDCE mov.w 0x0608DDF6,r3
    c.r[1] += c.r[3];  // 0608DDD0 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DDD2 mov.l @(8,r14),r2
    c.r[3] = c.r[2];  // 0608DDD4 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608DDF6u);  // 0608DDD6 mov.w 0x0608DDF6,r7
    c.r[2] += c.r[7];  // 0608DDD8 add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608DDDA mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608DDDC mov r3,r2
    c.r[2] -= 1;  // 0608DDDE add #-1,r2
    c.r[3] = c.r[2];  // 0608DDE0 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608DDE2 mov.l r3,@r1
    SH2_POLL(c); goto L_0608DCEE;  // 0608DDE4 bra 0x0608DCEE ; nop
L_0608DDE8:
    c.r[14] += 12;  // 0608DDE8 add #12,r14
    c.r[15] = c.r[14];  // 0608DDEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608DDEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DDEE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608DDF0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DDF2 rts ; nop
}

void f_0608DE0C(SH2Context& c) {
    ran[2071] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608DE0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DE0E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608DE10 sts.l pr,@-r15
    c.r[15] -= 40;  // 0608DE12 add #-40,r15
    c.r[14] = c.r[15];  // 0608DE14 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DE16 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608DE18 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DE1A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608DE1C mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608DE1E mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608DE20 mov r1,r2
    c.r[2] += 56;  // 0608DE22 add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DE24 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DE26 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DE28 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[1] + 60);  // 0608DE2A mov.l @(60,r1),r1
    c.r[2] = ld32(c.r[2] + 32);  // 0608DE2C mov.l @(32,r2),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608DE2E cmp/gt r2,r1
    if (!c.t) { goto L_0608DE46; }  // 0608DE30 bf 0x0608DE46
    c.r[1] = ld32(c.r[14] + 8);  // 0608DE32 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608DE34 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608DE36 mov r3,r2
    c.r[3] += 64;  // 0608DE38 add #64,r3
    c.r[1] = ld32(c.r[1] + 32);  // 0608DE3A mov.l @(32,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608DE3C mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608DE3E sub r2,r1
    st32(c.r[14] + 20, c.r[1]);  // 0608DE40 mov.l r1,@(20,r14)
    goto L_0608DE56;  // 0608DE42 bra 0x0608DE56 ; nop
L_0608DE46:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DE46 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608DE48 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608DE4A mov r3,r2
    c.r[3] += 64;  // 0608DE4C add #64,r3
    c.r[1] = ld32(c.r[1] + 60);  // 0608DE4E mov.l @(60,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608DE50 mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608DE52 sub r2,r1
    st32(c.r[14] + 20, c.r[1]);  // 0608DE54 mov.l r1,@(20,r14)
L_0608DE56:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DE56 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 36);  // 0608DE58 mov.l @(36,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608DE5A cmp/eq #1,r0
    if (!c.t) { goto L_0608DE66; }  // 0608DE5C bf 0x0608DE66
    c.r[1] = ld32(c.r[14] + 20);  // 0608DE5E mov.l @(20,r14),r1
    st32(c.r[14] + 24, c.r[1]);  // 0608DE60 mov.l r1,@(24,r14)
    goto L_0608DE70;  // 0608DE62 bra 0x0608DE70 ; nop
L_0608DE66:
    c.r[2] = ld32(c.r[14] + 20);  // 0608DE66 mov.l @(20,r14),r2
    c.r[1] = c.r[2];  // 0608DE68 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608DE6A shar r1
    c.r[2] = c.r[1];  // 0608DE6C mov r1,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608DE6E mov.l r2,@(24,r14)
L_0608DE70:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DE70 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 0608DE72 mov.l @(40,r1),r2
    c.r[1] = 0x8u;  // 0608DE74 mov #8,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608DE76 cmp/gt r1,r2
    if (c.t) { goto L_0608DE8E; }  // 0608DE78 bt 0x0608DE8E
    c.r[1] = ld32(c.r[14] + 24);  // 0608DE7A mov.l @(24,r14),r1
    c.r[2] = 0xFFFFFFFEu;  // 0608DE7C mov #-2,r2
    c.r[1] &= c.r[2];  // 0608DE7E and r2,r1
    st32(c.r[14] + 24, c.r[1]);  // 0608DE80 mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608DE82 mov.l @(24,r14),r1
    c.r[2] = 0xFFFFFFFCu;  // 0608DE84 mov #-4,r2
    c.r[1] &= c.r[2];  // 0608DE86 and r2,r1
    st32(c.r[14] + 24, c.r[1]);  // 0608DE88 mov.l r1,@(24,r14)
    goto L_0608DE96;  // 0608DE8A bra 0x0608DE96 ; nop
L_0608DE8E:
    c.r[1] = ld32(c.r[14] + 24);  // 0608DE8E mov.l @(24,r14),r1
    c.r[2] = 0xFFFFFFFCu;  // 0608DE90 mov #-4,r2
    c.r[1] &= c.r[2];  // 0608DE92 and r2,r1
    st32(c.r[14] + 24, c.r[1]);  // 0608DE94 mov.l r1,@(24,r14)
L_0608DE96:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DE96 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 0608DE98 mov.l @(40,r1),r2
    c.r[1] = 0x8u;  // 0608DE9A mov #8,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608DE9C cmp/gt r1,r2
    if (c.t) { goto L_0608DEB8; }  // 0608DE9E bt 0x0608DEB8
    c.r[1] = ld32(c.r[14] + 8);  // 0608DEA0 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608DEA2 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608DEA4 mov r3,r2
    c.r[3] += 104;  // 0608DEA6 add #104,r3
    c.r[1] = ld32(c.r[1] + 48);  // 0608DEA8 mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608DEAA mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608DEAC sub r2,r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608DEAE mov.l @(24,r14),r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608DEB0 cmp/ge r1,r2
    if (c.t) { goto L_0608DED4; }  // 0608DEB2 bt 0x0608DED4
    goto L_0608DEF2;  // 0608DEB4 bra 0x0608DEF2 ; nop
L_0608DEB8:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DEB8 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608DEBA mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608DEBC mov r3,r2
    c.r[3] += 104;  // 0608DEBE add #104,r3
    c.r[1] = ld32(c.r[1] + 48);  // 0608DEC0 mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608DEC2 mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608DEC4 sub r2,r1
    c.r[2] = c.r[1];  // 0608DEC6 mov r1,r2
    c.r[2] += c.r[2];  // 0608DEC8 add r2,r2
    c.r[1] = ld32(c.r[14] + 24);  // 0608DECA mov.l @(24,r14),r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608DECC cmp/ge r2,r1
    if (c.t) { goto L_0608DED4; }  // 0608DECE bt 0x0608DED4
    goto L_0608DEF2;  // 0608DED0 bra 0x0608DEF2 ; nop
L_0608DED4:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DED4 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608DED6 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608DED8 mov r3,r2
    c.r[3] += 104;  // 0608DEDA add #104,r3
    c.r[1] = ld32(c.r[1] + 48);  // 0608DEDC mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608DEDE mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608DEE0 sub r2,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DEE2 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2] + 40);  // 0608DEE4 mov.l @(40,r2),r3
    c.r[2] = 0x8u;  // 0608DEE6 mov #8,r2
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0608DEE8 cmp/gt r2,r3
    if (!c.t) { goto L_0608DEEE; }  // 0608DEEA bf 0x0608DEEE
    c.r[1] += c.r[1];  // 0608DEEC add r1,r1
L_0608DEEE:
    goto L_0608DEF4;  // 0608DEEE bra 0x0608DEF4 ; nop
L_0608DEF2:
    c.r[1] = ld32(c.r[14] + 24);  // 0608DEF2 mov.l @(24,r14),r1
L_0608DEF4:
    st32(c.r[14] + 24, c.r[1]);  // 0608DEF4 mov.l r1,@(24,r14)
    c.r[1] = c.r[14];  // 0608DEF6 mov r14,r1
    c.r[1] += 12;  // 0608DEF8 add #12,r1
    c.r[2] = c.r[14];  // 0608DEFA mov r14,r2
    c.r[2] += 36;  // 0608DEFC add #36,r2
    c.r[3] = c.r[14];  // 0608DEFE mov r14,r3
    c.r[3] += 32;  // 0608DF00 add #32,r3
    c.r[7] = c.r[14];  // 0608DF02 mov r14,r7
    c.r[7] += 16;  // 0608DF04 add #16,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608DF06 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608DF08 mov r1,r7
    c.r[6] = c.r[2];  // 0608DF0A mov r2,r6
    c.r[5] = c.r[3];  // 0608DF0C mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608DF0E mov.l @r14,r4
    c.r[8] = ld32(0x0608DFB8u);  // 0608DF10 mov.l 0x0608DFB8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DF16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DF16u) return; }  // 0608DF12 jsr @r8 ; nop
    c.r[15] += 4;  // 0608DF16 add #4,r15
    c.r[2] = ld32(c.r[14] + 8);  // 0608DF18 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608DF1A mov r2,r1
    c.r[2] += 92;  // 0608DF1C add #92,r2
    c.r[1] = ld32(c.r[14] + 16);  // 0608DF1E mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[2]);  // 0608DF20 mov.l @r2,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608DF22 cmp/gt r2,r1
    if (!c.t) { goto L_0608DF4A; }  // 0608DF24 bf 0x0608DF4A
    c.r[1] = ld32(c.r[14] + 8);  // 0608DF26 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DF28 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DFB2u);  // 0608DF2A mov.w 0x0608DFB2,r3
    c.r[2] = c.r[1];  // 0608DF2C mov r1,r2
    c.r[2] += c.r[3];  // 0608DF2E add r3,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608DF30 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DF32 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DFB2u);  // 0608DF34 mov.w 0x0608DFB2,r3
    c.r[1] += c.r[3];  // 0608DF36 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DF38 mov.l @(8,r14),r2
    c.r[3] = c.r[2];  // 0608DF3A mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608DFB2u);  // 0608DF3C mov.w 0x0608DFB2,r7
    c.r[2] += c.r[7];  // 0608DF3E add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608DF40 mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608DF42 mov r3,r2
    c.r[2] += 1;  // 0608DF44 add #1,r2
    c.r[3] = c.r[2];  // 0608DF46 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608DF48 mov.l r3,@r1
L_0608DF4A:
    c.r[1] = ld32(c.r[14] + 24);  // 0608DF4A mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608DF4C mov.l @(16,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608DF4E cmp/gt r2,r1
    if (!c.t) { goto L_0608DF54; }  // 0608DF50 bf 0x0608DF54
    c.r[1] = ld32(c.r[14] + 16);  // 0608DF52 mov.l @(16,r14),r1
L_0608DF54:
    st32(c.r[14] + 28, c.r[1]);  // 0608DF54 mov.l r1,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 0608DF56 mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608DF58 tst r1,r1
    if (!c.t) { goto L_0608DF60; }  // 0608DF5A bf 0x0608DF60
    goto L_0608DFA4;  // 0608DF5C bra 0x0608DFA4 ; nop
L_0608DF60:
    c.r[1] = ld32(c.r[14] + 8);  // 0608DF60 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608DF62 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DFB4u);  // 0608DF64 mov.w 0x0608DFB4,r3
    c.r[2] = c.r[1];  // 0608DF66 mov r1,r2
    c.r[2] += c.r[3];  // 0608DF68 add r3,r2
    c.r[1] = ld32(c.r[14] + 28);  // 0608DF6A mov.l @(28,r14),r1
    c.r[3] = ld32(c.r[2]);  // 0608DF6C mov.l @r2,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 0608DF6E cmp/gt r3,r1
    if (!c.t) { goto L_0608DF74; }  // 0608DF70 bf 0x0608DF74
    c.r[1] = ld32(c.r[2]);  // 0608DF72 mov.l @r2,r1
L_0608DF74:
    st32(c.r[14] + 28, c.r[1]);  // 0608DF74 mov.l r1,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 0608DF76 mov.l @(28,r14),r1
    c.r[5] = c.r[1];  // 0608DF78 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DF7A mov.l @r14,r4
    c.r[8] = ld32(0x0608DFBCu);  // 0608DF7C mov.l 0x0608DFBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DF82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DF82u) return; }  // 0608DF7E jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 0608DF82 mov.l @r14,r4
    c.r[8] = ld32(0x0608DFC0u);  // 0608DF84 mov.l 0x0608DFC0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DF8Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DF8Au) return; }  // 0608DF86 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 28);  // 0608DF8A mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608DF8C mov.l @(8,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608DF8E mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608DF90 cmp/eq #1,r0
    if (c.t) { goto L_0608DF96; }  // 0608DF92 bt 0x0608DF96
    c.r[1] += c.r[1];  // 0608DF94 add r1,r1
L_0608DF96:
    c.r[5] = c.r[1];  // 0608DF96 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DF98 mov.l @r14,r4
    c.r[8] = ld32(0x0608DFC4u);  // 0608DF9A mov.l 0x0608DFC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DFA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DFA0u) return; }  // 0608DF9C jsr @r8 ; nop
    goto L_0608DFA4;  // 0608DFA0 bra 0x0608DFA4 ; nop
L_0608DFA4:
    c.r[14] += 40;  // 0608DFA4 add #40,r14
    c.r[15] = c.r[14];  // 0608DFA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608DFA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DFAA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608DFAC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DFAE rts ; nop
}

void f_0608DFC8(SH2Context& c) {
    ran[2072] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608DFC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608DFCA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608DFCC sts.l pr,@-r15
    c.r[15] -= 12;  // 0608DFCE add #-12,r15
    c.r[14] = c.r[15];  // 0608DFD0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608DFD2 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608DFD4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608DFD6 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608DFD8 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608DFDA mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608DFDC mov r1,r2
    c.r[2] += 56;  // 0608DFDE add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608DFE0 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608DFE2 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 28);  // 0608DFE4 mov.l @(28,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608DFE6 cmp/eq #1,r0
    if (c.t) { goto L_0608DFF6; }  // 0608DFE8 bt 0x0608DFF6
    c.r[1] = ld32(c.r[14] + 8);  // 0608DFEA mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 28);  // 0608DFEC mov.l @(28,r1),r0
    c.t = c.r[0] == 0x2u;  // 0608DFEE cmp/eq #2,r0
    if (c.t) { goto L_0608DFF6; }  // 0608DFF0 bt 0x0608DFF6
    goto L_0608E002;  // 0608DFF2 bra 0x0608E002 ; nop
L_0608DFF6:
    c.r[4] = ld32(c.r[14]);  // 0608DFF6 mov.l @r14,r4
    c.r[8] = ld32(0x0608E024u);  // 0608DFF8 mov.l 0x0608E024,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608DFFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DFFEu) return; }  // 0608DFFA jsr @r8 ; nop
    goto L_0608E016;  // 0608DFFE bra 0x0608E016 ; nop
L_0608E002:
    c.r[1] = ld32(c.r[14] + 8);  // 0608E002 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 28);  // 0608E004 mov.l @(28,r1),r0
    c.t = c.r[0] == 0x3u;  // 0608E006 cmp/eq #3,r0
    if (c.t) { goto L_0608E016; }  // 0608E008 bt 0x0608E016
    c.r[1] = ld32(c.r[14] + 8);  // 0608E00A mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 28);  // 0608E00C mov.l @(28,r1),r0
    c.t = c.r[0] == 0x4u;  // 0608E00E cmp/eq #4,r0
    if (c.t) { goto L_0608E016; }  // 0608E010 bt 0x0608E016
    goto L_0608E016;  // 0608E012 bra 0x0608E016 ; nop
L_0608E016:
    c.r[14] += 12;  // 0608E016 add #12,r14
    c.r[15] = c.r[14];  // 0608E018 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E01A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E01C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E01E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E020 rts ; nop
}

void f_0608E108(SH2Context& c) {
    ran[2073] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E108 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608E10A add #-12,r15
    c.r[14] = c.r[15];  // 0608E10C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E10E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E110 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608E112 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E114 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E116 mov r1,r2
    c.r[1] = c.r[2];  // 0608E118 mov r2,r1
    c.r[1] <<= 2;  // 0608E11A shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608E11C mov.l @r14,r2
    c.r[1] += c.r[2];  // 0608E11E add r2,r1
    st32(c.r[14], c.r[1]);  // 0608E120 mov.l r1,@r14
L_0608E122:
    c.r[2] = ld32(c.r[14] + 8);  // 0608E122 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608E124 mov r2,r1
    c.r[1] -= 1;  // 0608E126 add #-1,r1
    c.r[2] = c.r[1];  // 0608E128 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E12A mov.l r2,@(8,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608E12C cmp/pz r2
    if (c.t) { goto L_0608E134; }  // 0608E12E bt 0x0608E134
    goto L_0608E146;  // 0608E130 bra 0x0608E146 ; nop
L_0608E134:
    c.r[1] = ld32(c.r[14]);  // 0608E134 mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608E136 mov r1,r2
    c.r[2] -= 4;  // 0608E138 add #-4,r2
    c.r[1] = c.r[2];  // 0608E13A mov r2,r1
    st32(c.r[14], c.r[1]);  // 0608E13C mov.l r1,@r14
    c.r[2] = ld32(c.r[14] + 4);  // 0608E13E mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608E140 mov.l r2,@r1
    SH2_POLL(c); goto L_0608E122;  // 0608E142 bra 0x0608E122 ; nop
L_0608E146:
    c.r[14] += 12;  // 0608E146 add #12,r14
    c.r[15] = c.r[14];  // 0608E148 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E14A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E14C rts ; nop
}

void f_0608E150(SH2Context& c) {
    ran[2074] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E150 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608E152 add #-12,r15
    c.r[14] = c.r[15];  // 0608E154 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E156 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E158 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608E15A mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E15C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E15E mov r1,r2
    c.r[1] = c.r[2];  // 0608E160 mov r2,r1
    c.r[1] <<= 2;  // 0608E162 shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608E164 mov.l @r14,r2
    c.r[1] += c.r[2];  // 0608E166 add r2,r1
    st32(c.r[14], c.r[1]);  // 0608E168 mov.l r1,@r14
    c.r[1] = ld32(c.r[14] + 8);  // 0608E16A mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E16C mov r1,r2
    c.r[1] = c.r[2];  // 0608E16E mov r2,r1
    c.r[1] <<= 2;  // 0608E170 shll2 r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E172 mov.l @(4,r14),r2
    c.r[1] += c.r[2];  // 0608E174 add r2,r1
    st32(c.r[14] + 4, c.r[1]);  // 0608E176 mov.l r1,@(4,r14)
L_0608E178:
    c.r[2] = ld32(c.r[14] + 8);  // 0608E178 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608E17A mov r2,r1
    c.r[1] -= 1;  // 0608E17C add #-1,r1
    c.r[2] = c.r[1];  // 0608E17E mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E180 mov.l r2,@(8,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608E182 cmp/pz r2
    if (c.t) { goto L_0608E18A; }  // 0608E184 bt 0x0608E18A
    goto L_0608E1A6;  // 0608E186 bra 0x0608E1A6 ; nop
L_0608E18A:
    c.r[1] = ld32(c.r[14]);  // 0608E18A mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608E18C mov r1,r2
    c.r[2] -= 4;  // 0608E18E add #-4,r2
    c.r[1] = c.r[2];  // 0608E190 mov r2,r1
    st32(c.r[14], c.r[1]);  // 0608E192 mov.l r1,@r14
    c.r[3] = ld32(c.r[14] + 4);  // 0608E194 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E196 mov r3,r2
    c.r[2] -= 4;  // 0608E198 add #-4,r2
    c.r[3] = c.r[2];  // 0608E19A mov r2,r3
    st32(c.r[14] + 4, c.r[3]);  // 0608E19C mov.l r3,@(4,r14)
    c.r[2] = ld32(c.r[3]);  // 0608E19E mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608E1A0 mov.l r2,@r1
    SH2_POLL(c); goto L_0608E178;  // 0608E1A2 bra 0x0608E178 ; nop
L_0608E1A6:
    c.r[14] += 12;  // 0608E1A6 add #12,r14
    c.r[15] = c.r[14];  // 0608E1A8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E1AA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E1AC rts ; nop
}

void f_0608E1B0(SH2Context& c) {
    ran[2075] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E1B0 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608E1B2 add #-12,r15
    c.r[14] = c.r[15];  // 0608E1B4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E1B6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E1B8 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608E1BA mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608E1BC mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E1BE mov.l @(4,r14),r2
    c.t = c.r[1] >= c.r[2];  // 0608E1C0 cmp/hs r2,r1
    if (c.t) { goto L_0608E1F2; }  // 0608E1C2 bt 0x0608E1F2
L_0608E1C4:
    c.r[2] = ld32(c.r[14] + 8);  // 0608E1C4 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608E1C6 mov r2,r1
    c.r[1] -= 1;  // 0608E1C8 add #-1,r1
    c.r[2] = c.r[1];  // 0608E1CA mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E1CC mov.l r2,@(8,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608E1CE cmp/pz r2
    if (c.t) { goto L_0608E1D6; }  // 0608E1D0 bt 0x0608E1D6
    goto L_0608E1EE;  // 0608E1D2 bra 0x0608E1EE ; nop
L_0608E1D6:
    c.r[1] = ld32(c.r[14]);  // 0608E1D6 mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608E1D8 mov r1,r2
    c.r[2] += 1;  // 0608E1DA add #1,r2
    st32(c.r[14], c.r[2]);  // 0608E1DC mov.l r2,@r14
    c.r[2] = ld32(c.r[14] + 4);  // 0608E1DE mov.l @(4,r14),r2
    c.r[3] = c.r[2];  // 0608E1E0 mov r2,r3
    c.r[3] += 1;  // 0608E1E2 add #1,r3
    st32(c.r[14] + 4, c.r[3]);  // 0608E1E4 mov.l r3,@(4,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608E1E6 mov.b @r2,r2
    st8(c.r[1], c.r[2]);  // 0608E1E8 mov.b r2,@r1
    SH2_POLL(c); goto L_0608E1C4;  // 0608E1EA bra 0x0608E1C4 ; nop
L_0608E1EE:
    goto L_0608E238;  // 0608E1EE bra 0x0608E238 ; nop
L_0608E1F2:
    c.r[1] = ld32(c.r[14]);  // 0608E1F2 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E1F4 mov.l @(4,r14),r2
    c.t = c.r[1] > c.r[2];  // 0608E1F6 cmp/hi r2,r1
    if (!c.t) { goto L_0608E238; }  // 0608E1F8 bf 0x0608E238
    c.r[1] = ld32(c.r[14]);  // 0608E1FA mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608E1FC mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0608E1FE add r2,r1
    st32(c.r[14], c.r[1]);  // 0608E200 mov.l r1,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 0608E202 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608E204 mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0608E206 add r2,r1
    st32(c.r[14] + 4, c.r[1]);  // 0608E208 mov.l r1,@(4,r14)
L_0608E20A:
    c.r[2] = ld32(c.r[14] + 8);  // 0608E20A mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608E20C mov r2,r1
    c.r[1] -= 1;  // 0608E20E add #-1,r1
    c.r[2] = c.r[1];  // 0608E210 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E212 mov.l r2,@(8,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608E214 cmp/pz r2
    if (c.t) { goto L_0608E21C; }  // 0608E216 bt 0x0608E21C
    goto L_0608E238;  // 0608E218 bra 0x0608E238 ; nop
L_0608E21C:
    c.r[1] = ld32(c.r[14]);  // 0608E21C mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608E21E mov r1,r2
    c.r[2] -= 1;  // 0608E220 add #-1,r2
    c.r[1] = c.r[2];  // 0608E222 mov r2,r1
    st32(c.r[14], c.r[1]);  // 0608E224 mov.l r1,@r14
    c.r[3] = ld32(c.r[14] + 4);  // 0608E226 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E228 mov r3,r2
    c.r[2] -= 1;  // 0608E22A add #-1,r2
    c.r[3] = c.r[2];  // 0608E22C mov r2,r3
    st32(c.r[14] + 4, c.r[3]);  // 0608E22E mov.l r3,@(4,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608E230 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608E232 mov.b r2,@r1
    SH2_POLL(c); goto L_0608E20A;  // 0608E234 bra 0x0608E20A ; nop
L_0608E238:
    c.r[14] += 12;  // 0608E238 add #12,r14
    c.r[15] = c.r[14];  // 0608E23A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E23C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E23E rts ; nop
}

void f_0608E244(SH2Context& c) {
    ran[2076] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E244 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608E246 add #-12,r15
    c.r[14] = c.r[15];  // 0608E248 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E24A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E24C mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608E24E mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608E250 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E252 mov.l @(4,r14),r2
    c.t = c.r[1] >= c.r[2];  // 0608E254 cmp/hs r2,r1
    if (c.t) { goto L_0608E286; }  // 0608E256 bt 0x0608E286
L_0608E258:
    c.r[2] = ld32(c.r[14] + 8);  // 0608E258 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608E25A mov r2,r1
    c.r[1] -= 1;  // 0608E25C add #-1,r1
    c.r[2] = c.r[1];  // 0608E25E mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E260 mov.l r2,@(8,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608E262 cmp/pz r2
    if (c.t) { goto L_0608E26A; }  // 0608E264 bt 0x0608E26A
    goto L_0608E282;  // 0608E266 bra 0x0608E282 ; nop
L_0608E26A:
    c.r[1] = ld32(c.r[14]);  // 0608E26A mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608E26C mov r1,r2
    c.r[2] += 4;  // 0608E26E add #4,r2
    st32(c.r[14], c.r[2]);  // 0608E270 mov.l r2,@r14
    c.r[2] = ld32(c.r[14] + 4);  // 0608E272 mov.l @(4,r14),r2
    c.r[3] = c.r[2];  // 0608E274 mov r2,r3
    c.r[3] += 4;  // 0608E276 add #4,r3
    st32(c.r[14] + 4, c.r[3]);  // 0608E278 mov.l r3,@(4,r14)
    c.r[2] = ld32(c.r[2]);  // 0608E27A mov.l @r2,r2
    st32(c.r[1], c.r[2]);  // 0608E27C mov.l r2,@r1
    SH2_POLL(c); goto L_0608E258;  // 0608E27E bra 0x0608E258 ; nop
L_0608E282:
    goto L_0608E2D8;  // 0608E282 bra 0x0608E2D8 ; nop
L_0608E286:
    c.r[1] = ld32(c.r[14]);  // 0608E286 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E288 mov.l @(4,r14),r2
    c.t = c.r[1] > c.r[2];  // 0608E28A cmp/hi r2,r1
    if (!c.t) { goto L_0608E2D8; }  // 0608E28C bf 0x0608E2D8
    c.r[1] = ld32(c.r[14] + 8);  // 0608E28E mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E290 mov r1,r2
    c.r[1] = c.r[2];  // 0608E292 mov r2,r1
    c.r[1] <<= 2;  // 0608E294 shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608E296 mov.l @r14,r2
    c.r[1] += c.r[2];  // 0608E298 add r2,r1
    st32(c.r[14], c.r[1]);  // 0608E29A mov.l r1,@r14
    c.r[1] = ld32(c.r[14] + 8);  // 0608E29C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E29E mov r1,r2
    c.r[1] = c.r[2];  // 0608E2A0 mov r2,r1
    c.r[1] <<= 2;  // 0608E2A2 shll2 r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E2A4 mov.l @(4,r14),r2
    c.r[1] += c.r[2];  // 0608E2A6 add r2,r1
    st32(c.r[14] + 4, c.r[1]);  // 0608E2A8 mov.l r1,@(4,r14)
L_0608E2AA:
    c.r[2] = ld32(c.r[14] + 8);  // 0608E2AA mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608E2AC mov r2,r1
    c.r[1] -= 1;  // 0608E2AE add #-1,r1
    c.r[2] = c.r[1];  // 0608E2B0 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E2B2 mov.l r2,@(8,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608E2B4 cmp/pz r2
    if (c.t) { goto L_0608E2BC; }  // 0608E2B6 bt 0x0608E2BC
    goto L_0608E2D8;  // 0608E2B8 bra 0x0608E2D8 ; nop
L_0608E2BC:
    c.r[1] = ld32(c.r[14]);  // 0608E2BC mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608E2BE mov r1,r2
    c.r[2] -= 4;  // 0608E2C0 add #-4,r2
    c.r[1] = c.r[2];  // 0608E2C2 mov r2,r1
    st32(c.r[14], c.r[1]);  // 0608E2C4 mov.l r1,@r14
    c.r[3] = ld32(c.r[14] + 4);  // 0608E2C6 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E2C8 mov r3,r2
    c.r[2] -= 4;  // 0608E2CA add #-4,r2
    c.r[3] = c.r[2];  // 0608E2CC mov r2,r3
    st32(c.r[14] + 4, c.r[3]);  // 0608E2CE mov.l r3,@(4,r14)
    c.r[2] = ld32(c.r[3]);  // 0608E2D0 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608E2D2 mov.l r2,@r1
    SH2_POLL(c); goto L_0608E2AA;  // 0608E2D4 bra 0x0608E2AA ; nop
L_0608E2D8:
    c.r[14] += 12;  // 0608E2D8 add #12,r14
    c.r[15] = c.r[14];  // 0608E2DA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E2DC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E2DE rts ; nop
}

void f_0608E2E4(SH2Context& c) {
    ran[2077] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608E2E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E2E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608E2E8 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608E2EA add #-20,r15
    c.r[14] = c.r[15];  // 0608E2EC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E2EE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E2F0 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608E2F2 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608E2F4 mov.l r7,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E2F6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E2F8 mov.l @(12,r14),r2
    c.r[1] -= c.r[2];  // 0608E2FA sub r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608E2FC mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E2FE mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E300 mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 0608E302 mov r1,r6
    c.r[5] = c.r[2];  // 0608E304 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 0608E306 mov.l @r14,r4
    c.r[8] = ld32(0x0608E348u);  // 0608E308 mov.l 0x0608E348,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E30Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E30Eu) return; }  // 0608E30A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 0608E30E mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E310 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 12);  // 0608E312 mov.l @(12,r14),r3
    c.r[2] += c.r[3];  // 0608E314 add r3,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608E316 mov.l @(4,r14),r3
    c.r[6] = c.r[1];  // 0608E318 mov r1,r6
    c.r[5] = c.r[2];  // 0608E31A mov r2,r5
    c.r[4] = c.r[3];  // 0608E31C mov r3,r4
    c.r[8] = ld32(0x0608E348u);  // 0608E31E mov.l 0x0608E348,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E324u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E324u) return; }  // 0608E320 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608E324 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E326 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608E328 mov.l @(16,r14),r3
    c.r[2] += c.r[3];  // 0608E32A add r3,r2
    c.r[6] = c.r[1];  // 0608E32C mov r1,r6
    c.r[5] = ld32(c.r[14]);  // 0608E32E mov.l @r14,r5
    c.r[4] = c.r[2];  // 0608E330 mov r2,r4
    c.r[8] = ld32(0x0608E348u);  // 0608E332 mov.l 0x0608E348,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E338u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E338u) return; }  // 0608E334 jsr @r8 ; nop
    c.r[14] += 20;  // 0608E338 add #20,r14
    c.r[15] = c.r[14];  // 0608E33A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E33C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E33E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E340 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E342 rts ; nop
}

void f_0608E34C(SH2Context& c) {
    ran[2078] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608E34C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E34E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608E350 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608E352 add #-20,r15
    c.r[14] = c.r[15];  // 0608E354 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E356 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E358 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608E35A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608E35C mov.l r7,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E35E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E360 mov.l @(12,r14),r2
    c.r[1] -= c.r[2];  // 0608E362 sub r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608E364 mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E366 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608E368 mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 0608E36A mov r1,r6
    c.r[5] = c.r[2];  // 0608E36C mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 0608E36E mov.l @r14,r4
    c.r[8] = ld32(0x0608E3BCu);  // 0608E370 mov.l 0x0608E3BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E376u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E376u) return; }  // 0608E372 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 0608E376 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E378 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608E37A mov r2,r3
    c.r[2] = c.r[3];  // 0608E37C mov r3,r2
    c.r[2] <<= 2;  // 0608E37E shll2 r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608E380 mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 0608E382 add r3,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608E384 mov.l @(4,r14),r3
    c.r[6] = c.r[1];  // 0608E386 mov r1,r6
    c.r[5] = c.r[2];  // 0608E388 mov r2,r5
    c.r[4] = c.r[3];  // 0608E38A mov r3,r4
    c.r[8] = ld32(0x0608E3BCu);  // 0608E38C mov.l 0x0608E3BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E392u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E392u) return; }  // 0608E38E jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608E392 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608E394 mov.l @(16,r14),r2
    c.r[3] = c.r[2];  // 0608E396 mov r2,r3
    c.r[2] = c.r[3];  // 0608E398 mov r3,r2
    c.r[2] <<= 2;  // 0608E39A shll2 r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608E39C mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 0608E39E add r3,r2
    c.r[6] = c.r[1];  // 0608E3A0 mov r1,r6
    c.r[5] = ld32(c.r[14]);  // 0608E3A2 mov.l @r14,r5
    c.r[4] = c.r[2];  // 0608E3A4 mov r2,r4
    c.r[8] = ld32(0x0608E3BCu);  // 0608E3A6 mov.l 0x0608E3BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E3ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E3ACu) return; }  // 0608E3A8 jsr @r8 ; nop
    c.r[14] += 20;  // 0608E3AC add #20,r14
    c.r[15] = c.r[14];  // 0608E3AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E3B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E3B2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E3B4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E3B6 rts ; nop
}

void f_0608E3C0(SH2Context& c) {
    ran[2079] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608E3C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E3C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608E3C4 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608E3C6 add #-16,r15
    c.r[14] = c.r[15];  // 0608E3C8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E3CA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E3CC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608E3CE mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608E3D0 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E3D2 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E3D4 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E3D6 mov r1,r2
    c.r[2] += 56;  // 0608E3D8 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608E3DA mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E3DC mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 8);  // 0608E3DE mov.l @(8,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608E3E0 cmp/eq #1,r0
    if (!c.t) { goto L_0608E3E8; }  // 0608E3E2 bf 0x0608E3E8
    goto L_0608E45C;  // 0608E3E4 bra 0x0608E45C ; nop
L_0608E3E8:
    c.r[1] = ld32(c.r[14] + 12);  // 0608E3E8 mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608E3EA mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E3EC mov r3,r2
    c.r[3] += 8;  // 0608E3EE add #8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E3F0 mov.w @r3,r2
    st32(c.r[1] + 36, c.r[2]);  // 0608E3F2 mov.l r2,@(36,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E3F4 mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608E3F6 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E3F8 mov r3,r2
    c.r[3] += 14;  // 0608E3FA add #14,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E3FC mov.w @r3,r2
    st32(c.r[1] + 40, c.r[2]);  // 0608E3FE mov.l r2,@(40,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E400 mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608E402 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E404 mov r3,r2
    c.r[3] += 18;  // 0608E406 add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E408 mov.w @r3,r2
    c.r[3] = ld32(0x0608E46Cu);  // 0608E40A mov.l 0x0608E46C,r3
    c.r[2] &= c.r[3];  // 0608E40C and r3,r2
    st32(c.r[1] + 44, c.r[2]);  // 0608E40E mov.l r2,@(44,r1)
    c.r[8] = ld32(c.r[14] + 12);  // 0608E410 mov.l @(12,r14),r8
    c.r[1] = ld32(c.r[14] + 12);  // 0608E412 mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608E414 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E416 mov r3,r2
    c.r[3] += 16;  // 0608E418 add #16,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E41A mov.w @r3,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608E46Au);  // 0608E41C mov.w 0x0608E46A,r7
    c.r[3] = c.r[7];  // 0608E41E mov r7,r3
    c.r[3] -= c.r[2];  // 0608E420 sub r2,r3
    c.r[2] = ld32(0x0608E470u);  // 0608E422 mov.l 0x0608E470,r2
    c.r[5] = c.r[3];  // 0608E424 mov r3,r5
    c.r[4] = ld32(c.r[1] + 44);  // 0608E426 mov.l @(44,r1),r4
    { const uint32_t x = c.r[2]; c.pr = 0x0608E42Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E42Cu) return; }  // 0608E428 jsr @r2 ; nop
    st32(c.r[8] + 44, c.r[0]);  // 0608E42C mov.l r0,@(44,r8)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E42E mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608E430 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E432 mov r3,r2
    c.r[2] += 10;  // 0608E434 add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E436 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E438 exts.w r3,r2
    c.r[3] = c.r[2];  // 0608E43A mov r2,r3
    c.r[3] <<= 16;  // 0608E43C shll16 r3
    c.r[7] = ld32(0x0608E474u);  // 0608E43E mov.l 0x0608E474,r7
    c.r[2] = c.r[3];  // 0608E440 mov r3,r2
    c.r[2] &= c.r[7];  // 0608E442 and r7,r2
    c.r[7] = ld32(c.r[14] + 4);  // 0608E444 mov.l @(4,r14),r7
    c.r[3] = c.r[7];  // 0608E446 mov r7,r3
    c.r[3] += 12;  // 0608E448 add #12,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E44A mov.w @r3,r7
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0608E44C exts.w r7,r3
    c.r[7] = ld32(0x0608E46Cu);  // 0608E44E mov.l 0x0608E46C,r7
    c.r[3] &= c.r[7];  // 0608E450 and r7,r3
    c.r[2] |= c.r[3];  // 0608E452 or r3,r2
    st32(c.r[1] + 48, c.r[2]);  // 0608E454 mov.l r2,@(48,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E456 mov.l @(12,r14),r1
    c.r[2] = 0x1u;  // 0608E458 mov #1,r2
    st32(c.r[1] + 28, c.r[2]);  // 0608E45A mov.l r2,@(28,r1)
L_0608E45C:
    c.r[14] += 16;  // 0608E45C add #16,r14
    c.r[15] = c.r[14];  // 0608E45E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E460 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E462 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E464 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E466 rts ; nop
}

void f_0608E478(SH2Context& c) {
    ran[2080] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608E478 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E47A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608E47C sts.l pr,@-r15
    c.r[15] -= 16;  // 0608E47E add #-16,r15
    c.r[14] = c.r[15];  // 0608E480 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E482 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E484 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608E486 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608E488 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E48A mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E48C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E48E mov r1,r2
    c.r[2] += 56;  // 0608E490 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608E492 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E494 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 8);  // 0608E496 mov.l @(8,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608E498 cmp/eq #1,r0
    if (!c.t) { goto L_0608E4A0; }  // 0608E49A bf 0x0608E4A0
    goto L_0608E4E8;  // 0608E49C bra 0x0608E4E8 ; nop
L_0608E4A0:
    c.r[1] = ld32(c.r[14] + 4);  // 0608E4A0 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608E4A2 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608E4A4 mov.l @r14,r4
    c.r[8] = ld32(0x0608E4F8u);  // 0608E4A6 mov.l 0x0608E4F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E4ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E4ACu) return; }  // 0608E4A8 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608E4AC mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608E4AE mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608E4B0 mov r3,r2
    c.r[2] += 26;  // 0608E4B2 add #26,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E4B4 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E4B6 exts.w r3,r2
    c.r[3] = c.r[2];  // 0608E4B8 mov r2,r3
    c.r[3] <<= 16;  // 0608E4BA shll16 r3
    c.r[7] = ld32(0x0608E4FCu);  // 0608E4BC mov.l 0x0608E4FC,r7
    c.r[2] = c.r[3];  // 0608E4BE mov r3,r2
    c.r[2] &= c.r[7];  // 0608E4C0 and r7,r2
    c.r[7] = ld32(c.r[14] + 4);  // 0608E4C2 mov.l @(4,r14),r7
    c.r[3] = c.r[7];  // 0608E4C4 mov r7,r3
    c.r[3] += 28;  // 0608E4C6 add #28,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E4C8 mov.w @r3,r7
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0608E4CA exts.w r7,r3
    c.r[7] = ld32(0x0608E500u);  // 0608E4CC mov.l 0x0608E500,r7
    c.r[3] &= c.r[7];  // 0608E4CE and r7,r3
    c.r[2] |= c.r[3];  // 0608E4D0 or r3,r2
    st32(c.r[1] + 52, c.r[2]);  // 0608E4D2 mov.l r2,@(52,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E4D4 mov.l @(12,r14),r1
    c.r[2] = 0x6u;  // 0608E4D6 mov #6,r2
    st32(c.r[1] + 28, c.r[2]);  // 0608E4D8 mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E4DA mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E4DC mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 48);  // 0608E4DE mov.l @(48,r2),r3
    c.r[2] = 0x40u;  // 0608E4E0 mov #64,r2
    c.macl = c.r[3] * c.r[2];  // 0608E4E2 mul.l r2,r3
    c.r[2] = c.macl;  // 0608E4E4 sts macl,r2
    st32(c.r[1] + 48, c.r[2]);  // 0608E4E6 mov.l r2,@(48,r1)
L_0608E4E8:
    c.r[14] += 16;  // 0608E4E8 add #16,r14
    c.r[15] = c.r[14];  // 0608E4EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E4EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E4EE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E4F0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E4F2 rts ; nop
}

void f_0608E504(SH2Context& c) {
    ran[2081] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E504 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608E506 add #-20,r15
    c.r[14] = c.r[15];  // 0608E508 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E50A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E50C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608E50E mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608E510 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E512 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E514 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E516 mov r1,r2
    c.r[2] += 4;  // 0608E518 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608E51A mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E51C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E51E mov r1,r2
    c.r[2] += 56;  // 0608E520 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608E522 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608E524 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608E526 mov r1,r2
    c.r[1] += 80;  // 0608E528 add #80,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E52A mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608E52C mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608E52E mov r3,r2
    c.r[2] -= 16;  // 0608E530 add #-16,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608E532 mov.l @(4,r14),r3
    c.r[7] = c.r[3];  // 0608E534 mov r3,r7
    c.r[7] -= c.r[2];  // 0608E536 sub r2,r7
    c.r[2] = c.r[7];  // 0608E538 mov r7,r2
    st32(c.r[1], c.r[2]);  // 0608E53A mov.l r2,@r1
    c.r[14] += 20;  // 0608E53C add #20,r14
    c.r[15] = c.r[14];  // 0608E53E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E540 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E542 rts ; nop
}

void f_0608E548(SH2Context& c) {
    ran[2082] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608E548 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E54A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608E54C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608E54E add #-8,r15
    c.r[14] = c.r[15];  // 0608E550 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E552 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E554 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E56Eu);  // 0608E556 mov.w 0x0608E56E,r1
    c.r[4] = c.r[1];  // 0608E558 mov r1,r4
    c.r[8] = ld32(0x0608E570u);  // 0608E55A mov.l 0x0608E570,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E560u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E560u) return; }  // 0608E55C jsr @r8 ; nop
    c.r[14] += 8;  // 0608E560 add #8,r14
    c.r[15] = c.r[14];  // 0608E562 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E564 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E566 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E568 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E56A rts ; nop
}

void f_0608E5B4(SH2Context& c) {
    ran[2083] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608E5B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E5B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608E5B8 sts.l pr,@-r15
    c.r[15] -= 40;  // 0608E5BA add #-40,r15
    c.r[14] = c.r[15];  // 0608E5BC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E5BE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608E5C0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608E5C2 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608E5C4 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608E5C6 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608E5C8 mov r1,r2
    c.r[2] += 4;  // 0608E5CA add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E5CC mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608E5CE mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608E5D0 mov r1,r2
    c.r[2] += 56;  // 0608E5D2 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608E5D4 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E5D6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0608E5D8 mov.l @r1,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608E5DA mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E5DC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0608E5DE mov.l @r1,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608E5E0 mov.l r2,@(24,r14)
    c.r[1] = 0x0u;  // 0608E5E2 mov #0,r1
    st32(c.r[14] + 28, c.r[1]);  // 0608E5E4 mov.l r1,@(28,r14)
    c.r[1] = 0x0u;  // 0608E5E6 mov #0,r1
    st32(c.r[14] + 32, c.r[1]);  // 0608E5E8 mov.l r1,@(32,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608E5EA mov.l @(24,r14),r1
    c.r[2] = c.r[1];  // 0608E5EC mov r1,r2
    c.r[2] += 12;  // 0608E5EE add #12,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608E5F0 mov.l r2,@(24,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 0608E5F2 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608E5F4 mov r1,r2
    c.r[2] += 12;  // 0608E5F6 add #12,r2
    st32(c.r[14] + 28, c.r[2]);  // 0608E5F8 mov.l r2,@(28,r14)
    c.r[2] = ld32(c.r[14] + 28);  // 0608E5FA mov.l @(28,r14),r2
    c.r[1] = c.r[2];  // 0608E5FC mov r2,r1
    c.r[1] += 32;  // 0608E5FE add #32,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E600 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 60);  // 0608E602 mov.l @(60,r2),r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 0608E604 cmp/gt r3,r1
    if (!c.t) { goto L_0608E60E; }  // 0608E606 bf 0x0608E60E
    c.r[0] = 0xFFFFFFFFu;  // 0608E608 mov #-1,r0
    goto L_0608E9AE;  // 0608E60A bra 0x0608E9AE ; nop
L_0608E60E:
    c.r[1] = ld32(c.r[14] + 20);  // 0608E60E mov.l @(20,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E610 mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E612 exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E614 mov r1,r2
    c.r[2] <<= 16;  // 0608E616 shll16 r2
    c.r[3] = ld32(0x0608E784u);  // 0608E618 mov.l 0x0608E784,r3
    c.r[1] = c.r[2];  // 0608E61A mov r2,r1
    c.r[1] &= c.r[3];  // 0608E61C and r3,r1
    c.r[3] = ld32(c.r[14] + 20);  // 0608E61E mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0608E620 mov r3,r2
    c.r[2] += 2;  // 0608E622 add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E624 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E626 exts.w r3,r2
    c.r[3] = ld32(0x0608E788u);  // 0608E628 mov.l 0x0608E788,r3
    c.r[2] &= c.r[3];  // 0608E62A and r3,r2
    c.r[1] |= c.r[2];  // 0608E62C or r2,r1
    c.r[2] = ld32(0x0608E78Cu);  // 0608E62E mov.l 0x0608E78C,r2
    c.r[3] = ld32(c.r[2]);  // 0608E630 mov.l @r2,r3
    c.t = c.r[1] == c.r[3];  // 0608E632 cmp/eq r3,r1
    if (c.t) { goto L_0608E646; }  // 0608E634 bt 0x0608E646
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E77Eu);  // 0608E636 mov.w 0x0608E77E,r1
    c.r[4] = c.r[1];  // 0608E638 mov r1,r4
    c.r[8] = ld32(0x0608E790u);  // 0608E63A mov.l 0x0608E790,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E640u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E640u) return; }  // 0608E63C jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E640 mov #-1,r0
    goto L_0608E9AE;  // 0608E642 bra 0x0608E9AE ; nop
L_0608E646:
    c.r[1] = ld32(c.r[14] + 12);  // 0608E646 mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 20);  // 0608E648 mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0608E64A mov r3,r2
    c.r[2] += 4;  // 0608E64C add #4,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E64E mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E650 exts.w r3,r2
    c.r[3] = c.r[2];  // 0608E652 mov r2,r3
    c.r[3] <<= 16;  // 0608E654 shll16 r3
    c.r[7] = ld32(0x0608E784u);  // 0608E656 mov.l 0x0608E784,r7
    c.r[2] = c.r[3];  // 0608E658 mov r3,r2
    c.r[2] &= c.r[7];  // 0608E65A and r7,r2
    c.r[7] = ld32(c.r[14] + 20);  // 0608E65C mov.l @(20,r14),r7
    c.r[3] = c.r[7];  // 0608E65E mov r7,r3
    c.r[3] += 6;  // 0608E660 add #6,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E662 mov.w @r3,r7
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0608E664 exts.w r7,r3
    c.r[7] = ld32(0x0608E788u);  // 0608E666 mov.l 0x0608E788,r7
    c.r[3] &= c.r[7];  // 0608E668 and r7,r3
    c.r[2] |= c.r[3];  // 0608E66A or r3,r2
    c.r[3] = c.r[2];  // 0608E66C mov r2,r3
    c.r[3] += 8;  // 0608E66E add #8,r3
    st32(c.r[1] + 32, c.r[3]);  // 0608E670 mov.l r3,@(32,r1)
    c.r[2] = ld32(c.r[14] + 20);  // 0608E672 mov.l @(20,r14),r2
    c.r[1] = c.r[2];  // 0608E674 mov r2,r1
    c.r[1] += 8;  // 0608E676 add #8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E678 mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E67A exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E67C mov r1,r2
    c.r[2] <<= 16;  // 0608E67E shll16 r2
    c.r[3] = ld32(0x0608E784u);  // 0608E680 mov.l 0x0608E784,r3
    c.r[1] = c.r[2];  // 0608E682 mov r2,r1
    c.r[1] &= c.r[3];  // 0608E684 and r3,r1
    c.r[3] = ld32(c.r[14] + 20);  // 0608E686 mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0608E688 mov r3,r2
    c.r[2] += 10;  // 0608E68A add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E68C mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E68E exts.w r3,r2
    c.r[3] = ld32(0x0608E788u);  // 0608E690 mov.l 0x0608E788,r3
    c.r[2] &= c.r[3];  // 0608E692 and r3,r2
    c.r[1] |= c.r[2];  // 0608E694 or r2,r1
    c.r[2] = ld32(0x0608E794u);  // 0608E696 mov.l 0x0608E794,r2
    c.r[3] = ld32(c.r[2]);  // 0608E698 mov.l @r2,r3
    c.t = c.r[1] == c.r[3];  // 0608E69A cmp/eq r3,r1
    if (c.t) { goto L_0608E6A2; }  // 0608E69C bt 0x0608E6A2
    goto L_0608E816;  // 0608E69E bra 0x0608E816 ; nop
L_0608E6A2:
    c.r[1] = ld32(c.r[14] + 12);  // 0608E6A2 mov.l @(12,r14),r1
    c.r[2] = 0x2u;  // 0608E6A4 mov #2,r2
    st32(c.r[1] + 24, c.r[2]);  // 0608E6A6 mov.l r2,@(24,r1)
L_0608E6A8:
    c.r[1] = ld32(c.r[14] + 24);  // 0608E6A8 mov.l @(24,r14),r1
    st32(c.r[14] + 16, c.r[1]);  // 0608E6AA mov.l r1,@(16,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 0608E6AC mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 0608E6AE mov r2,r1
    c.r[1] += 4;  // 0608E6B0 add #4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E6B2 mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E6B4 exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E6B6 mov r1,r2
    c.r[2] <<= 16;  // 0608E6B8 shll16 r2
    c.r[3] = ld32(0x0608E784u);  // 0608E6BA mov.l 0x0608E784,r3
    c.r[1] = c.r[2];  // 0608E6BC mov r2,r1
    c.r[1] &= c.r[3];  // 0608E6BE and r3,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608E6C0 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608E6C2 mov r3,r2
    c.r[2] += 6;  // 0608E6C4 add #6,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E6C6 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E6C8 exts.w r3,r2
    c.r[3] = ld32(0x0608E788u);  // 0608E6CA mov.l 0x0608E788,r3
    c.r[2] &= c.r[3];  // 0608E6CC and r3,r2
    c.r[1] |= c.r[2];  // 0608E6CE or r2,r1
    c.r[2] = c.r[1];  // 0608E6D0 mov r1,r2
    c.r[2] += 8;  // 0608E6D2 add #8,r2
    c.r[1] = ld32(c.r[14] + 24);  // 0608E6D4 mov.l @(24,r14),r1
    c.r[2] += c.r[1];  // 0608E6D6 add r1,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608E6D8 mov.l r2,@(24,r14)
    c.r[2] = ld32(c.r[14] + 28);  // 0608E6DA mov.l @(28,r14),r2
    c.r[1] = c.r[2];  // 0608E6DC mov r2,r1
    c.r[1] += 8;  // 0608E6DE add #8,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608E6E0 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608E6E2 mov r3,r2
    c.r[2] += 4;  // 0608E6E4 add #4,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E6E6 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E6E8 exts.w r3,r2
    c.r[3] = c.r[2];  // 0608E6EA mov r2,r3
    c.r[3] <<= 16;  // 0608E6EC shll16 r3
    c.r[7] = ld32(0x0608E784u);  // 0608E6EE mov.l 0x0608E784,r7
    c.r[2] = c.r[3];  // 0608E6F0 mov r3,r2
    c.r[2] &= c.r[7];  // 0608E6F2 and r7,r2
    c.r[7] = ld32(c.r[14] + 16);  // 0608E6F4 mov.l @(16,r14),r7
    c.r[3] = c.r[7];  // 0608E6F6 mov r7,r3
    c.r[3] += 6;  // 0608E6F8 add #6,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608E6FA mov.w @r3,r7
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0608E6FC exts.w r7,r3
    c.r[7] = ld32(0x0608E788u);  // 0608E6FE mov.l 0x0608E788,r7
    c.r[3] &= c.r[7];  // 0608E700 and r7,r3
    c.r[2] |= c.r[3];  // 0608E702 or r3,r2
    c.r[1] += c.r[2];  // 0608E704 add r2,r1
    st32(c.r[14] + 28, c.r[1]);  // 0608E706 mov.l r1,@(28,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608E708 mov.l @(16,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E70A mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E70C exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E70E mov r1,r2
    c.r[2] <<= 16;  // 0608E710 shll16 r2
    c.r[3] = ld32(0x0608E784u);  // 0608E712 mov.l 0x0608E784,r3
    c.r[1] = c.r[2];  // 0608E714 mov r2,r1
    c.r[1] &= c.r[3];  // 0608E716 and r3,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608E718 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608E71A mov r3,r2
    c.r[2] += 2;  // 0608E71C add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E71E mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E720 exts.w r3,r2
    c.r[3] = ld32(0x0608E788u);  // 0608E722 mov.l 0x0608E788,r3
    c.r[2] &= c.r[3];  // 0608E724 and r3,r2
    c.r[1] |= c.r[2];  // 0608E726 or r2,r1
    st32(c.r[14] + 36, c.r[1]);  // 0608E728 mov.l r1,@(36,r14)
    c.r[1] = ld32(0x0608E798u);  // 0608E72A mov.l 0x0608E798,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608E72C mov.l @(36,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608E72E mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 0608E730 cmp/eq r1,r2
    if (!c.t) { goto L_0608E748; }  // 0608E732 bf 0x0608E748
    c.r[1] = ld32(c.r[14] + 16);  // 0608E734 mov.l @(16,r14),r1
    c.r[5] = c.r[1];  // 0608E736 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608E738 mov.l @r14,r4
    c.r[8] = ld32(0x0608E79Cu);  // 0608E73A mov.l 0x0608E79C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E740u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E740u) return; }  // 0608E73C jsr @r8 ; nop
    c.r[1] = 0x1u;  // 0608E740 mov #1,r1
    st32(c.r[14] + 32, c.r[1]);  // 0608E742 mov.l r1,@(32,r14)
    goto L_0608E7DC;  // 0608E744 bra 0x0608E7DC ; nop
L_0608E748:
    c.r[1] = ld32(0x0608E7A0u);  // 0608E748 mov.l 0x0608E7A0,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608E74A mov.l @(36,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608E74C mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 0608E74E cmp/eq r1,r2
    if (!c.t) { goto L_0608E7A8; }  // 0608E750 bf 0x0608E7A8
    c.r[1] = ld32(c.r[14] + 16);  // 0608E752 mov.l @(16,r14),r1
    c.r[5] = c.r[1];  // 0608E754 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608E756 mov.l @r14,r4
    c.r[8] = ld32(0x0608E7A4u);  // 0608E758 mov.l 0x0608E7A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E75Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E75Eu) return; }  // 0608E75A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 32);  // 0608E75E mov.l @(32,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608E760 tst r1,r1
    if (!c.t) { goto L_0608E774; }  // 0608E762 bf 0x0608E774
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E780u);  // 0608E764 mov.w 0x0608E780,r1
    c.r[4] = c.r[1];  // 0608E766 mov r1,r4
    c.r[8] = ld32(0x0608E790u);  // 0608E768 mov.l 0x0608E790,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E76Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E76Eu) return; }  // 0608E76A jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E76E mov #-1,r0
    goto L_0608E9AE;  // 0608E770 bra 0x0608E9AE ; nop
L_0608E774:
    c.r[0] = 0x0u;  // 0608E774 mov #0,r0
    goto L_0608E9AE;  // 0608E776 bra 0x0608E9AE ; nop
L_0608E7A8:
    c.r[1] = ld32(0x0608E8F8u);  // 0608E7A8 mov.l 0x0608E8F8,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608E7AA mov.l @(36,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608E7AC mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 0608E7AE cmp/eq r1,r2
    if (!c.t) { goto L_0608E7DC; }  // 0608E7B0 bf 0x0608E7DC
    c.r[1] = ld32(0x0608E8FCu);  // 0608E7B2 mov.l 0x0608E8FC,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608E7B4 mov.l @(16,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608E7B6 mov.l @r1,r1
    c.r[5] = c.r[2];  // 0608E7B8 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 0608E7BA mov.l @r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0608E7C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E7C0u) return; }  // 0608E7BC jsr @r1 ; nop
    c.r[1] = ld32(c.r[14] + 32);  // 0608E7C0 mov.l @(32,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608E7C2 tst r1,r1
    if (!c.t) { goto L_0608E7D6; }  // 0608E7C4 bf 0x0608E7D6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E8F2u);  // 0608E7C6 mov.w 0x0608E8F2,r1
    c.r[4] = c.r[1];  // 0608E7C8 mov r1,r4
    c.r[8] = ld32(0x0608E900u);  // 0608E7CA mov.l 0x0608E900,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E7D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E7D0u) return; }  // 0608E7CC jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E7D0 mov #-1,r0
    goto L_0608E9AE;  // 0608E7D2 bra 0x0608E9AE ; nop
L_0608E7D6:
    c.r[0] = 0x0u;  // 0608E7D6 mov #0,r0
    goto L_0608E9AE;  // 0608E7D8 bra 0x0608E9AE ; nop
L_0608E7DC:
    c.r[2] = ld32(c.r[14] + 28);  // 0608E7DC mov.l @(28,r14),r2
    c.r[1] = c.r[2];  // 0608E7DE mov r2,r1
    c.r[1] += 32;  // 0608E7E0 add #32,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E7E2 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 60);  // 0608E7E4 mov.l @(60,r2),r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 0608E7E6 cmp/gt r3,r1
    if (c.t) { goto L_0608E7EE; }  // 0608E7E8 bt 0x0608E7EE
    goto L_0608E80E;  // 0608E7EA bra 0x0608E80E ; nop
L_0608E7EE:
    c.r[1] = ld32(c.r[14] + 8);  // 0608E7EE mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0608E7F0 mov.l @(28,r14),r2
    c.r[1] = ld32(c.r[1] + 4);  // 0608E7F2 mov.l @(4,r1),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608E7F4 cmp/gt r1,r2
    if (!c.t) { goto L_0608E808; }  // 0608E7F6 bf 0x0608E808
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E8F4u);  // 0608E7F8 mov.w 0x0608E8F4,r1
    c.r[4] = c.r[1];  // 0608E7FA mov r1,r4
    c.r[8] = ld32(0x0608E900u);  // 0608E7FC mov.l 0x0608E900,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E802u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E802u) return; }  // 0608E7FE jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E802 mov #-1,r0
    goto L_0608E9AE;  // 0608E804 bra 0x0608E9AE ; nop
L_0608E808:
    c.r[0] = 0xFFFFFFFFu;  // 0608E808 mov #-1,r0
    goto L_0608E9AE;  // 0608E80A bra 0x0608E9AE ; nop
L_0608E80E:
    SH2_POLL(c); goto L_0608E6A8;  // 0608E80E bra 0x0608E6A8 ; nop
L_0608E816:
    c.r[2] = ld32(c.r[14] + 20);  // 0608E816 mov.l @(20,r14),r2
    c.r[1] = c.r[2];  // 0608E818 mov r2,r1
    c.r[1] += 8;  // 0608E81A add #8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E81C mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E81E exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E820 mov r1,r2
    c.r[2] <<= 16;  // 0608E822 shll16 r2
    c.r[3] = ld32(0x0608E904u);  // 0608E824 mov.l 0x0608E904,r3
    c.r[1] = c.r[2];  // 0608E826 mov r2,r1
    c.r[1] &= c.r[3];  // 0608E828 and r3,r1
    c.r[3] = ld32(c.r[14] + 20);  // 0608E82A mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0608E82C mov r3,r2
    c.r[2] += 10;  // 0608E82E add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E830 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E832 exts.w r3,r2
    c.r[3] = ld32(0x0608E908u);  // 0608E834 mov.l 0x0608E908,r3
    c.r[2] &= c.r[3];  // 0608E836 and r3,r2
    c.r[1] |= c.r[2];  // 0608E838 or r2,r1
    c.r[2] = ld32(0x0608E90Cu);  // 0608E83A mov.l 0x0608E90C,r2
    c.r[3] = ld32(c.r[2]);  // 0608E83C mov.l @r2,r3
    c.t = c.r[1] == c.r[3];  // 0608E83E cmp/eq r3,r1
    if (c.t) { goto L_0608E846; }  // 0608E840 bt 0x0608E846
    goto L_0608E998;  // 0608E842 bra 0x0608E998 ; nop
L_0608E846:
    c.r[1] = ld32(c.r[14] + 12);  // 0608E846 mov.l @(12,r14),r1
    c.r[2] = 0x3u;  // 0608E848 mov #3,r2
    st32(c.r[1] + 24, c.r[2]);  // 0608E84A mov.l r2,@(24,r1)
L_0608E84C:
    c.r[1] = ld32(c.r[14] + 24);  // 0608E84C mov.l @(24,r14),r1
    st32(c.r[14] + 16, c.r[1]);  // 0608E84E mov.l r1,@(16,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 0608E850 mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 0608E852 mov r2,r1
    c.r[1] += 4;  // 0608E854 add #4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E856 mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E858 exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E85A mov r1,r2
    c.r[2] <<= 16;  // 0608E85C shll16 r2
    c.r[3] = ld32(0x0608E904u);  // 0608E85E mov.l 0x0608E904,r3
    c.r[1] = c.r[2];  // 0608E860 mov r2,r1
    c.r[1] &= c.r[3];  // 0608E862 and r3,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608E864 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608E866 mov r3,r2
    c.r[2] += 6;  // 0608E868 add #6,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E86A mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E86C exts.w r3,r2
    c.r[3] = ld32(0x0608E908u);  // 0608E86E mov.l 0x0608E908,r3
    c.r[2] &= c.r[3];  // 0608E870 and r3,r2
    c.r[1] |= c.r[2];  // 0608E872 or r2,r1
    c.r[2] = c.r[1];  // 0608E874 mov r1,r2
    c.r[2] += 8;  // 0608E876 add #8,r2
    c.r[1] = ld32(c.r[14] + 24);  // 0608E878 mov.l @(24,r14),r1
    c.r[2] += c.r[1];  // 0608E87A add r1,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608E87C mov.l r2,@(24,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608E87E mov.l @(16,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608E880 mov.w @r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0608E882 exts.w r2,r1
    c.r[2] = c.r[1];  // 0608E884 mov r1,r2
    c.r[2] <<= 16;  // 0608E886 shll16 r2
    c.r[3] = ld32(0x0608E904u);  // 0608E888 mov.l 0x0608E904,r3
    c.r[1] = c.r[2];  // 0608E88A mov r2,r1
    c.r[1] &= c.r[3];  // 0608E88C and r3,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608E88E mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608E890 mov r3,r2
    c.r[2] += 2;  // 0608E892 add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608E894 mov.w @r2,r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0608E896 exts.w r3,r2
    c.r[3] = ld32(0x0608E908u);  // 0608E898 mov.l 0x0608E908,r3
    c.r[2] &= c.r[3];  // 0608E89A and r3,r2
    c.r[1] |= c.r[2];  // 0608E89C or r2,r1
    st32(c.r[14] + 36, c.r[1]);  // 0608E89E mov.l r1,@(36,r14)
    c.r[1] = ld32(0x0608E910u);  // 0608E8A0 mov.l 0x0608E910,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608E8A2 mov.l @(36,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608E8A4 mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 0608E8A6 cmp/eq r1,r2
    if (c.t) { goto L_0608E8AE; }  // 0608E8A8 bt 0x0608E8AE
    goto L_0608E920;  // 0608E8AA bra 0x0608E920 ; nop
L_0608E8AE:
    c.r[1] = ld32(c.r[14] + 16);  // 0608E8AE mov.l @(16,r14),r1
    c.r[5] = c.r[1];  // 0608E8B0 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608E8B2 mov.l @r14,r4
    c.r[8] = ld32(0x0608E914u);  // 0608E8B4 mov.l 0x0608E914,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E8BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E8BAu) return; }  // 0608E8B6 jsr @r8 ; nop
    c.r[1] = 0x1u;  // 0608E8BA mov #1,r1
    st32(c.r[14] + 32, c.r[1]);  // 0608E8BC mov.l r1,@(32,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608E8BE mov.l @(12,r14),r1
    c.r[2] = ld32(0x0608E918u);  // 0608E8C0 mov.l 0x0608E918,r2
    c.r[1] = ld32(c.r[1] + 52);  // 0608E8C2 mov.l @(52,r1),r1
    c.r[2] = ld32(c.r[2]);  // 0608E8C4 mov.l @r2,r2
    c.t = c.r[1] == c.r[2];  // 0608E8C6 cmp/eq r2,r1
    if (!c.t) { goto L_0608E8CE; }  // 0608E8C8 bf 0x0608E8CE
    goto L_0608E8EE;  // 0608E8CA bra 0x0608E8EE ; nop
L_0608E8CE:
    c.r[1] = ld32(c.r[14] + 12);  // 0608E8CE mov.l @(12,r14),r1
    c.r[2] = ld32(0x0608E91Cu);  // 0608E8D0 mov.l 0x0608E91C,r2
    c.r[1] = ld32(c.r[1] + 52);  // 0608E8D2 mov.l @(52,r1),r1
    c.r[2] = ld32(c.r[2]);  // 0608E8D4 mov.l @r2,r2
    c.t = c.r[1] == c.r[2];  // 0608E8D6 cmp/eq r2,r1
    if (!c.t) { goto L_0608E8DE; }  // 0608E8D8 bf 0x0608E8DE
    goto L_0608E8EE;  // 0608E8DA bra 0x0608E8EE ; nop
L_0608E8DE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E8F6u);  // 0608E8DE mov.w 0x0608E8F6,r1
    c.r[4] = c.r[1];  // 0608E8E0 mov r1,r4
    c.r[8] = ld32(0x0608E900u);  // 0608E8E2 mov.l 0x0608E900,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E8E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E8E8u) return; }  // 0608E8E4 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E8E8 mov #-1,r0
    goto L_0608E9AE;  // 0608E8EA bra 0x0608E9AE ; nop
L_0608E8EE:
    goto L_0608E95A;  // 0608E8EE bra 0x0608E95A ; nop
L_0608E920:
    c.r[1] = ld32(0x0608E9C4u);  // 0608E920 mov.l 0x0608E9C4,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608E922 mov.l @(36,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608E924 mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 0608E926 cmp/eq r1,r2
    if (c.t) { goto L_0608E92E; }  // 0608E928 bt 0x0608E92E
    goto L_0608E95A;  // 0608E92A bra 0x0608E95A ; nop
L_0608E92E:
    c.r[1] = ld32(c.r[14] + 16);  // 0608E92E mov.l @(16,r14),r1
    c.r[5] = c.r[1];  // 0608E930 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608E932 mov.l @r14,r4
    c.r[8] = ld32(0x0608E9C8u);  // 0608E934 mov.l 0x0608E9C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E93Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E93Au) return; }  // 0608E936 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 32);  // 0608E93A mov.l @(32,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608E93C tst r1,r1
    if (c.t) { goto L_0608E944; }  // 0608E93E bt 0x0608E944
    goto L_0608E954;  // 0608E940 bra 0x0608E954 ; nop
L_0608E944:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E9BCu);  // 0608E944 mov.w 0x0608E9BC,r1
    c.r[4] = c.r[1];  // 0608E946 mov r1,r4
    c.r[8] = ld32(0x0608E9CCu);  // 0608E948 mov.l 0x0608E9CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E94Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E94Eu) return; }  // 0608E94A jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E94E mov #-1,r0
    goto L_0608E9AE;  // 0608E950 bra 0x0608E9AE ; nop
L_0608E954:
    c.r[0] = 0x0u;  // 0608E954 mov #0,r0
    goto L_0608E9AE;  // 0608E956 bra 0x0608E9AE ; nop
L_0608E95A:
    c.r[2] = ld32(c.r[14] + 28);  // 0608E95A mov.l @(28,r14),r2
    c.r[1] = c.r[2];  // 0608E95C mov r2,r1
    c.r[1] += 32;  // 0608E95E add #32,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E960 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 60);  // 0608E962 mov.l @(60,r2),r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 0608E964 cmp/gt r3,r1
    if (c.t) { goto L_0608E96C; }  // 0608E966 bt 0x0608E96C
    goto L_0608E990;  // 0608E968 bra 0x0608E990 ; nop
L_0608E96C:
    c.r[1] = ld32(c.r[14] + 8);  // 0608E96C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0608E96E mov.l @(28,r14),r2
    c.r[1] = ld32(c.r[1] + 4);  // 0608E970 mov.l @(4,r1),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608E972 cmp/gt r1,r2
    if (c.t) { goto L_0608E97A; }  // 0608E974 bt 0x0608E97A
    goto L_0608E98A;  // 0608E976 bra 0x0608E98A ; nop
L_0608E97A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E9BEu);  // 0608E97A mov.w 0x0608E9BE,r1
    c.r[4] = c.r[1];  // 0608E97C mov r1,r4
    c.r[8] = ld32(0x0608E9CCu);  // 0608E97E mov.l 0x0608E9CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E984u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E984u) return; }  // 0608E980 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E984 mov #-1,r0
    goto L_0608E9AE;  // 0608E986 bra 0x0608E9AE ; nop
L_0608E98A:
    c.r[0] = 0xFFFFFFFFu;  // 0608E98A mov #-1,r0
    goto L_0608E9AE;  // 0608E98C bra 0x0608E9AE ; nop
L_0608E990:
    SH2_POLL(c); goto L_0608E84C;  // 0608E990 bra 0x0608E84C ; nop
L_0608E998:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608E9C0u);  // 0608E998 mov.w 0x0608E9C0,r1
    c.r[4] = c.r[1];  // 0608E99A mov r1,r4
    c.r[8] = ld32(0x0608E9CCu);  // 0608E99C mov.l 0x0608E9CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608E9A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608E9A2u) return; }  // 0608E99E jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608E9A2 mov #-1,r0
    goto L_0608E9AE;  // 0608E9A4 bra 0x0608E9AE ; nop
L_0608E9AE:
    c.r[14] += 40;  // 0608E9AE add #40,r14
    c.r[15] = c.r[14];  // 0608E9B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608E9B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608E9B4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608E9B6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608E9B8 rts ; nop
}

void f_0608E9D0(SH2Context& c) {
    ran[2084] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608E9D0 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608E9D2 add #-20,r15
    c.r[14] = c.r[15];  // 0608E9D4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608E9D6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608E9D8 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608E9DA mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608E9DC mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608E9DE mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E9E0 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E9E2 mov r1,r2
    c.r[2] += 4;  // 0608E9E4 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608E9E6 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608E9E8 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608E9EA mov r1,r2
    c.r[2] += 56;  // 0608E9EC add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608E9EE mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608E9F0 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608E9F2 mov r1,r2
    c.r[1] += 80;  // 0608E9F4 add #80,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608E9F6 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608E9F8 mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608E9FA mov r3,r2
    c.r[2] -= 16;  // 0608E9FC add #-16,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608E9FE mov.l @(4,r14),r3
    c.r[7] = c.r[3];  // 0608EA00 mov r3,r7
    c.r[7] -= c.r[2];  // 0608EA02 sub r2,r7
    c.r[2] = c.r[7];  // 0608EA04 mov r7,r2
    st32(c.r[1], c.r[2]);  // 0608EA06 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608EA08 mov.l @(16,r14),r1
    c.r[2] = 0x6u;  // 0608EA0A mov #6,r2
    st32(c.r[1] + 28, c.r[2]);  // 0608EA0C mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14] + 16);  // 0608EA0E mov.l @(16,r14),r1
    c.r[2] = 0x10u;  // 0608EA10 mov #16,r2
    st32(c.r[1] + 40, c.r[2]);  // 0608EA12 mov.l r2,@(40,r1)
    c.r[1] = ld32(c.r[14] + 16);  // 0608EA14 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608EA16 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608EA2Au);  // 0608EA18 mov.w 0x0608EA2A,r3
    c.r[1] += c.r[3];  // 0608EA1A add r3,r1
    c.r[2] = ld32(0x0608EA2Cu);  // 0608EA1C mov.l 0x0608EA2C,r2
    st32(c.r[1], c.r[2]);  // 0608EA1E mov.l r2,@r1
    c.r[14] += 20;  // 0608EA20 add #20,r14
    c.r[15] = c.r[14];  // 0608EA22 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608EA24 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608EA26 rts ; nop
}

void f_0608EB30(SH2Context& c) {
    ran[2085] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608EB30 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608EB32 add #-4,r15
    c.r[14] = c.r[15];  // 0608EB34 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608EB36 mov.l r4,@r14
L_0608EB38:
    c.r[2] = ld32(c.r[14]);  // 0608EB38 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608EB3A mov r2,r1
    c.r[1] -= 1;  // 0608EB3C add #-1,r1
    c.r[2] = c.r[1];  // 0608EB3E mov r1,r2
    st32(c.r[14], c.r[2]);  // 0608EB40 mov.l r2,@r14
    c.t = (int32_t)c.r[2] > 0;  // 0608EB42 cmp/pl r2
    if (c.t) { goto L_0608EB4A; }  // 0608EB44 bt 0x0608EB4A
    goto L_0608EB4E;  // 0608EB46 bra 0x0608EB4E ; nop
L_0608EB4A:
    SH2_POLL(c); goto L_0608EB38;  // 0608EB4A bra 0x0608EB38 ; nop
L_0608EB4E:
    c.r[14] += 4;  // 0608EB4E add #4,r14
    c.r[15] = c.r[14];  // 0608EB50 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608EB52 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608EB54 rts ; nop
}

void f_0608EB58(SH2Context& c) {
    ran[2086] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608EB58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608EB5A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608EB5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608EB5E sts.l pr,@-r15
    c.r[15] -= 24;  // 0608EB60 add #-24,r15
    c.r[14] = c.r[15];  // 0608EB62 mov r15,r14
    c.r[8] = c.r[4];  // 0608EB64 mov r4,r8
    st8(c.r[14], c.r[8]);  // 0608EB66 mov.b r8,@r14
    c.r[1] = 0x0u;  // 0608EB68 mov #0,r1
    st32(c.r[14] + 20, c.r[1]);  // 0608EB6A mov.l r1,@(20,r14)
L_0608EB6C:
    c.r[1] = ld32(c.r[14] + 20);  // 0608EB6C mov.l @(20,r14),r1
    c.r[2] = 0x1Fu;  // 0608EB6E mov #31,r2
    c.t = c.r[1] > c.r[2];  // 0608EB70 cmp/hi r2,r1
    if (!c.t) { goto L_0608EB78; }  // 0608EB72 bf 0x0608EB78
    goto L_0608EC10;  // 0608EB74 bra 0x0608EC10 ; nop
L_0608EB78:
    c.r[1] = ld32(c.r[14] + 20);  // 0608EB78 mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 0608EB7A mov r1,r4
    c.r[9] = ld32(0x0608EC24u);  // 0608EB7C mov.l 0x0608EC24,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608EB82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EB82u) return; }  // 0608EB7E jsr @r9 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0608EB82 mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608EB84 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608EB86 tst r1,r1
    if (!c.t) { goto L_0608EB8E; }  // 0608EB88 bf 0x0608EB8E
    goto L_0608EC02;  // 0608EB8A bra 0x0608EC02 ; nop
L_0608EB8E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608EB8E mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0608EB90 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608EB92 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608EB94 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608EB96 mov r1,r2
    c.r[2] += 4;  // 0608EB98 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608EB9A mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608EB9C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608EB9E mov r1,r2
    c.r[2] += 56;  // 0608EBA0 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608EBA2 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608EBA4 mov.l @(16,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608EBA6 mov.l @(4,r1),r0
    c.t = c.r[0] == 0x4u;  // 0608EBA8 cmp/eq #4,r0
    if (c.t) { goto L_0608EBB0; }  // 0608EBAA bt 0x0608EBB0
    goto L_0608EC02;  // 0608EBAC bra 0x0608EC02 ; nop
L_0608EBB0:
    c.r[1] = ld32(c.r[14] + 12);  // 0608EBB0 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 0608EBB2 mov.l @(20,r1),r2
    c.r[3] = ld32(0x0608EC28u);  // 0608EBB4 mov.l 0x0608EC28,r3
    c.r[1] = c.r[2];  // 0608EBB6 mov r2,r1
    c.r[1] += c.r[3];  // 0608EBB8 add r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608EBBA mov.b @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608EBBC mov.b @r14,r1
    c.r[2] &= c.r[1];  // 0608EBBE and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0608EBC0 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608EBC2 tst r1,r1
    if (c.t) { goto L_0608EC02; }  // 0608EBC4 bt 0x0608EC02
    c.r[1] = ld32(0x0608EC2Cu);  // 0608EBC6 mov.l 0x0608EC2C,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608EBC8 mov.l @(16,r14),r2
    c.r[3] = c.r[2];  // 0608EBCA mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608EC20u);  // 0608EBCC mov.w 0x0608EC20,r7
    c.r[2] += c.r[7];  // 0608EBCE add r7,r2
    c.r[1] = ld32(c.r[1]);  // 0608EBD0 mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608EBD2 mov.l @r2,r2
    c.r[1] -= c.r[2];  // 0608EBD4 sub r2,r1
    c.r[2] = 0x2u;  // 0608EBD6 mov #2,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608EBD8 cmp/gt r2,r1
    if (!c.t) { goto L_0608EC02; }  // 0608EBDA bf 0x0608EC02
    c.r[2] = ld32(c.r[14] + 16);  // 0608EBDC mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 0608EBDE mov r2,r1
    c.r[2] += 100;  // 0608EBE0 add #100,r2
    c.r[1] = ld32(c.r[14] + 16);  // 0608EBE2 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608EBE4 mov r1,r2
    c.r[1] += 100;  // 0608EBE6 add #100,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608EBE8 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608EBEA mov r3,r2
    c.r[3] += 100;  // 0608EBEC add #100,r3
    c.r[7] = ld32(c.r[3]);  // 0608EBEE mov.l @r3,r7
    c.r[2] = c.r[7];  // 0608EBF0 mov r7,r2
    c.r[2] += 1;  // 0608EBF2 add #1,r2
    c.r[3] = c.r[2];  // 0608EBF4 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608EBF6 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 0608EBF8 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 0608EBFA mov r1,r4
    c.r[9] = ld32(0x0608EC30u);  // 0608EBFC mov.l 0x0608EC30,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608EC02u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EC02u) return; }  // 0608EBFE jsr @r9 ; nop
L_0608EC02:
    c.r[2] = ld32(c.r[14] + 20);  // 0608EC02 mov.l @(20,r14),r2
    c.r[1] = c.r[2];  // 0608EC04 mov r2,r1
    c.r[1] += 1;  // 0608EC06 add #1,r1
    c.r[2] = c.r[1];  // 0608EC08 mov r1,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608EC0A mov.l r2,@(20,r14)
    SH2_POLL(c); goto L_0608EB6C;  // 0608EC0C bra 0x0608EB6C ; nop
L_0608EC10:
    c.r[14] += 24;  // 0608EC10 add #24,r14
    c.r[15] = c.r[14];  // 0608EC12 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608EC14 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608EC16 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608EC18 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608EC1A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608EC1C rts ; nop
}

void f_0608EC34(SH2Context& c) {
    ran[2087] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608EC34 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608EC36 add #-4,r15
    c.r[14] = c.r[15];  // 0608EC38 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608EC3A mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608EC3C mov.l @r14,r1
    c.r[2] = ld32(0x0608EC64u);  // 0608EC3E mov.l 0x0608EC64,r2
    c.r[1] += c.r[2];  // 0608EC40 add r2,r1
    c.r[2] = ld32(0x0608EC68u);  // 0608EC42 mov.l 0x0608EC68,r2
    c.r[3] = ld32(c.r[14]);  // 0608EC44 mov.l @r14,r3
    c.r[7] = c.r[3];  // 0608EC46 mov r3,r7
    c.r[3] = c.r[7];  // 0608EC48 mov r7,r3
    c.r[3] += c.r[3];  // 0608EC4A add r3,r3
    c.r[7] = ld32(c.r[2]);  // 0608EC4C mov.l @r2,r7
    c.r[2] = c.r[3];  // 0608EC4E mov r3,r2
    c.r[2] += c.r[7];  // 0608EC50 add r7,r2
    c.r[3] = ld32(0x0608EC6Cu);  // 0608EC52 mov.l 0x0608EC6C,r3
    c.r[2] += c.r[3];  // 0608EC54 add r3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608EC56 mov.b @r2,r3
    st8(c.r[1], c.r[3]);  // 0608EC58 mov.b r3,@r1
    c.r[14] += 4;  // 0608EC5A add #4,r14
    c.r[15] = c.r[14];  // 0608EC5C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608EC5E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608EC60 rts ; nop
}

void f_0608EC70(SH2Context& c) {
    ran[2088] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608EC70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608EC72 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608EC74 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608EC76 add #-8,r15
    c.r[14] = c.r[15];  // 0608EC78 mov r15,r14
    c.r[1] = c.r[14];  // 0608EC7A mov r14,r1
    c.r[2] = c.r[14];  // 0608EC7C mov r14,r2
    c.r[2] += 4;  // 0608EC7E add #4,r2
    c.r[1] = 0x0u;  // 0608EC80 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0608EC82 mov.b r1,@r2
    c.r[1] = 0x0u;  // 0608EC84 mov #0,r1
    st32(c.r[14], c.r[1]);  // 0608EC86 mov.l r1,@r14
L_0608EC88:
    c.r[1] = ld32(c.r[14]);  // 0608EC88 mov.l @r14,r1
    c.r[2] = 0x7u;  // 0608EC8A mov #7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608EC8C cmp/gt r2,r1
    if (!c.t) { goto L_0608EC94; }  // 0608EC8E bf 0x0608EC94
    goto L_0608ED00;  // 0608EC90 bra 0x0608ED00 ; nop
L_0608EC94:
    c.r[1] = ld32(c.r[14]);  // 0608EC94 mov.l @r14,r1
    c.r[2] = ld32(0x0608ED30u);  // 0608EC96 mov.l 0x0608ED30,r2
    c.r[1] += c.r[2];  // 0608EC98 add r2,r1
    c.r[2] = ld32(0x0608ED34u);  // 0608EC9A mov.l 0x0608ED34,r2
    c.r[3] = ld32(c.r[14]);  // 0608EC9C mov.l @r14,r3
    c.r[7] = c.r[3];  // 0608EC9E mov r3,r7
    c.r[3] = c.r[7];  // 0608ECA0 mov r7,r3
    c.r[3] += c.r[3];  // 0608ECA2 add r3,r3
    c.r[7] = ld32(c.r[2]);  // 0608ECA4 mov.l @r2,r7
    c.r[2] = c.r[3];  // 0608ECA6 mov r3,r2
    c.r[2] += c.r[7];  // 0608ECA8 add r7,r2
    c.r[3] = ld32(0x0608ED38u);  // 0608ECAA mov.l 0x0608ED38,r3
    c.r[2] += c.r[3];  // 0608ECAC add r3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608ECAE mov.b @r1,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0608ECB0 extu.b r3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608ECB2 mov.b @r2,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0608ECB4 extu.b r3,r2
    c.t = c.r[1] == c.r[2];  // 0608ECB6 cmp/eq r2,r1
    if (c.t) { goto L_0608ECF2; }  // 0608ECB8 bt 0x0608ECF2
    c.r[1] = ld32(c.r[14]);  // 0608ECBA mov.l @r14,r1
    c.r[2] = ld32(0x0608ED30u);  // 0608ECBC mov.l 0x0608ED30,r2
    c.r[1] += c.r[2];  // 0608ECBE add r2,r1
    c.r[2] = ld32(0x0608ED34u);  // 0608ECC0 mov.l 0x0608ED34,r2
    c.r[3] = ld32(c.r[14]);  // 0608ECC2 mov.l @r14,r3
    c.r[7] = c.r[3];  // 0608ECC4 mov r3,r7
    c.r[3] = c.r[7];  // 0608ECC6 mov r7,r3
    c.r[3] += c.r[3];  // 0608ECC8 add r3,r3
    c.r[7] = ld32(c.r[2]);  // 0608ECCA mov.l @r2,r7
    c.r[2] = c.r[3];  // 0608ECCC mov r3,r2
    c.r[2] += c.r[7];  // 0608ECCE add r7,r2
    c.r[3] = ld32(0x0608ED38u);  // 0608ECD0 mov.l 0x0608ED38,r3
    c.r[2] += c.r[3];  // 0608ECD2 add r3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608ECD4 mov.b @r2,r3
    st8(c.r[1], c.r[3]);  // 0608ECD6 mov.b r3,@r1
    c.r[2] = c.r[14];  // 0608ECD8 mov r14,r2
    c.r[1] = c.r[14];  // 0608ECDA mov r14,r1
    c.r[1] += 4;  // 0608ECDC add #4,r1
    c.r[3] = c.r[14];  // 0608ECDE mov r14,r3
    c.r[2] = c.r[14];  // 0608ECE0 mov r14,r2
    c.r[2] += 4;  // 0608ECE2 add #4,r2
    c.r[3] = ld32(c.r[14]);  // 0608ECE4 mov.l @r14,r3
    c.r[7] = ld32(0x0608ED3Cu);  // 0608ECE6 mov.l 0x0608ED3C,r7
    c.r[3] += c.r[7];  // 0608ECE8 add r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608ECEA mov.b @r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608ECEC mov.b @r3,r3
    c.r[2] |= c.r[3];  // 0608ECEE or r3,r2
    st8(c.r[1], c.r[2]);  // 0608ECF0 mov.b r2,@r1
L_0608ECF2:
    c.r[2] = ld32(c.r[14]);  // 0608ECF2 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608ECF4 mov r2,r1
    c.r[1] += 1;  // 0608ECF6 add #1,r1
    c.r[2] = c.r[1];  // 0608ECF8 mov r1,r2
    st32(c.r[14], c.r[2]);  // 0608ECFA mov.l r2,@r14
    SH2_POLL(c); goto L_0608EC88;  // 0608ECFC bra 0x0608EC88 ; nop
L_0608ED00:
    c.r[1] = c.r[14];  // 0608ED00 mov r14,r1
    c.r[2] = c.r[14];  // 0608ED02 mov r14,r2
    c.r[2] += 4;  // 0608ED04 add #4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608ED06 mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0608ED08 extu.b r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608ED0A tst r1,r1
    if (c.t) { goto L_0608ED20; }  // 0608ED0C bt 0x0608ED20
    c.r[1] = c.r[14];  // 0608ED0E mov r14,r1
    c.r[2] = c.r[14];  // 0608ED10 mov r14,r2
    c.r[2] += 4;  // 0608ED12 add #4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608ED14 mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0608ED16 extu.b r3,r1
    c.r[4] = c.r[1];  // 0608ED18 mov r1,r4
    c.r[8] = ld32(0x0608ED40u);  // 0608ED1A mov.l 0x0608ED40,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608ED20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608ED20u) return; }  // 0608ED1C jsr @r8 ; nop
L_0608ED20:
    c.r[14] += 8;  // 0608ED20 add #8,r14
    c.r[15] = c.r[14];  // 0608ED22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608ED24 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608ED26 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608ED28 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608ED2A rts ; nop
}

void f_0608ED44(SH2Context& c) {
    ran[2089] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608ED44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608ED46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608ED48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608ED4A sts.l pr,@-r15
    c.r[15] -= 60;  // 0608ED4C add #-60,r15
    c.r[14] = c.r[15];  // 0608ED4E mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608ED50 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608ED52 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608ED54 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608ED56 mov.l r7,@(12,r14)
    c.r[1] = ld32(c.r[14]);  // 0608ED58 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608ED5A mov.l @r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608ED5C mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608ED5E mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608ED60 mov r1,r2
    c.r[2] += 4;  // 0608ED62 add #4,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608ED64 mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608ED66 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608ED68 mov r1,r2
    c.r[2] += 56;  // 0608ED6A add #56,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608ED6C mov.l r2,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608ED6E mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[1] + 44);  // 0608ED70 mov.l @(44,r1),r2
    c.r[1] = c.r[2];  // 0608ED72 mov r2,r1
    c.r[1] += 1;  // 0608ED74 add #1,r1
    c.r[4] = ld32(0x0608EF58u);  // 0608ED76 mov.l 0x0608EF58,r4
    c.r[5] = c.r[1];  // 0608ED78 mov r1,r5
    c.r[7] = ld32(0x0608EF5Cu);  // 0608ED7A mov.l 0x0608EF5C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608ED80u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608ED80u) return; }  // 0608ED7C jsr @r7 ; nop
    st32(c.r[14] + 56, c.r[0]);  // 0608ED80 mov.l r0,@(56,r14)
    c.r[2] = ld32(0x0608EF60u);  // 0608ED82 mov.l 0x0608EF60,r2
    c.r[1] = ld32(c.r[14] + 56);  // 0608ED84 mov.l @(56,r14),r1
    c.r[1] += c.r[2];  // 0608ED86 add r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608ED88 mov.b @r1,r2
    st32(c.r[14] + 28, c.r[2]);  // 0608ED8A mov.l r2,@(28,r14)
    c.r[1] = ld32(0x0608EF64u);  // 0608ED8C mov.l 0x0608EF64,r1
    c.r[5] = ld32(c.r[14] + 28);  // 0608ED8E mov.l @(28,r14),r5
    c.r[4] = ld32(0x0608EF58u);  // 0608ED90 mov.l 0x0608EF58,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0608ED96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608ED96u) return; }  // 0608ED92 jsr @r1 ; nop
    st32(c.r[14] + 56, c.r[0]);  // 0608ED96 mov.l r0,@(56,r14)
    c.r[9] = ld32(c.r[14] + 56);  // 0608ED98 mov.l @(56,r14),r9
    st32(c.r[14] + 32, c.r[9]);  // 0608ED9A mov.l r9,@(32,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608ED9C mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[1] + 44);  // 0608ED9E mov.l @(44,r1),r2
    c.r[3] = ld32(c.r[14] + 32);  // 0608EDA0 mov.l @(32,r14),r3
    c.r[1] = c.r[2];  // 0608EDA2 mov r2,r1
    c.r[1] -= c.r[3];  // 0608EDA4 sub r3,r1
    c.r[2] = c.r[1];  // 0608EDA6 mov r1,r2
    c.r[2] <<= 8;  // 0608EDA8 shll8 r2
    c.r[2] <<= 2;  // 0608EDAA shll2 r2
    c.r[4] = c.r[2];  // 0608EDAC mov r2,r4
    c.r[5] = ld32(c.r[14] + 32);  // 0608EDAE mov.l @(32,r14),r5
    c.r[7] = ld32(0x0608EF5Cu);  // 0608EDB0 mov.l 0x0608EF5C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608EDB6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EDB6u) return; }  // 0608EDB2 jsr @r7 ; nop
    st32(c.r[14] + 56, c.r[0]);  // 0608EDB6 mov.l r0,@(56,r14)
    c.r[9] = ld32(c.r[14] + 56);  // 0608EDB8 mov.l @(56,r14),r9
    st32(c.r[14] + 36, c.r[9]);  // 0608EDBA mov.l r9,@(36,r14)
    c.r[2] = c.r[14];  // 0608EDBC mov r14,r2
    c.r[1] = c.r[14];  // 0608EDBE mov r14,r1
    c.r[1] += 44;  // 0608EDC0 add #44,r1
    c.r[3] = ld32(c.r[14] + 20);  // 0608EDC2 mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0608EDC4 mov r3,r2
    c.r[3] += 23;  // 0608EDC6 add #23,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EDC8 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608EDCA mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608EDCC mov r14,r1
    c.r[3] = c.r[14];  // 0608EDCE mov r14,r3
    c.r[3] += 44;  // 0608EDD0 add #44,r3
    c.r[2] = c.r[3];  // 0608EDD2 mov r3,r2
    c.r[1] = c.r[3];  // 0608EDD4 mov r3,r1
    c.r[1] += 1;  // 0608EDD6 add #1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0608EDD8 mov.l @(4,r14),r0
    st32(c.r[14] + 56, c.r[0]);  // 0608EDDA mov.l r0,@(56,r14)
    c.r[0] = ld32(c.r[14] + 56);  // 0608EDDC mov.l @(56,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608EDDE cmp/eq #-1,r0
    if (c.t) { goto L_0608EDEE; }  // 0608EDE0 bt 0x0608EDEE
    c.r[2] = c.r[14];  // 0608EDE2 mov r14,r2
    c.r[3] = c.r[14];  // 0608EDE4 mov r14,r3
    c.r[3] += 7;  // 0608EDE6 add #7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EDE8 mov.b @r3,r2
    goto L_0608EDF6;  // 0608EDEA bra 0x0608EDF6 ; nop
L_0608EDEE:
    c.r[7] = ld32(c.r[14] + 20);  // 0608EDEE mov.l @(20,r14),r7
    c.r[3] = c.r[7];  // 0608EDF0 mov r7,r3
    c.r[7] += 31;  // 0608EDF2 add #31,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0608EDF4 mov.b @r7,r2
L_0608EDF6:
    st8(c.r[1], c.r[2]);  // 0608EDF6 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608EDF8 mov r14,r1
    c.r[3] = c.r[14];  // 0608EDFA mov r14,r3
    c.r[3] += 44;  // 0608EDFC add #44,r3
    c.r[2] = c.r[3];  // 0608EDFE mov r3,r2
    c.r[1] = c.r[3];  // 0608EE00 mov r3,r1
    c.r[1] += 2;  // 0608EE02 add #2,r1
    c.r[9] = ld32(c.r[14] + 8);  // 0608EE04 mov.l @(8,r14),r9
    st32(c.r[14] + 56, c.r[9]);  // 0608EE06 mov.l r9,@(56,r14)
    c.r[0] = ld32(c.r[14] + 56);  // 0608EE08 mov.l @(56,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608EE0A cmp/eq #-1,r0
    if (c.t) { goto L_0608EE1A; }  // 0608EE0C bt 0x0608EE1A
    c.r[2] = c.r[14];  // 0608EE0E mov r14,r2
    c.r[3] = c.r[14];  // 0608EE10 mov r14,r3
    c.r[3] += 11;  // 0608EE12 add #11,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EE14 mov.b @r3,r2
    goto L_0608EE22;  // 0608EE16 bra 0x0608EE22 ; nop
L_0608EE1A:
    c.r[7] = ld32(c.r[14] + 20);  // 0608EE1A mov.l @(20,r14),r7
    c.r[3] = c.r[7];  // 0608EE1C mov r7,r3
    c.r[7] += 27;  // 0608EE1E add #27,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0608EE20 mov.b @r7,r2
L_0608EE22:
    st8(c.r[1], c.r[2]);  // 0608EE22 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608EE24 mov r14,r1
    c.r[3] = c.r[14];  // 0608EE26 mov r14,r3
    c.r[3] += 44;  // 0608EE28 add #44,r3
    c.r[2] = c.r[3];  // 0608EE2A mov r3,r2
    c.r[1] = c.r[3];  // 0608EE2C mov r3,r1
    c.r[1] += 4;  // 0608EE2E add #4,r1
    c.r[2] = c.r[14];  // 0608EE30 mov r14,r2
    c.r[3] = c.r[14];  // 0608EE32 mov r14,r3
    c.r[3] += 30;  // 0608EE34 add #30,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608EE36 mov.w @r3,r2
    c.r[3] = 0u - c.r[2];  // 0608EE38 neg r2,r3
    c.r[2] = c.r[3];  // 0608EE3A mov r3,r2
    c.r[3] = 0xFu;  // 0608EE3C mov #15,r3
    c.r[3] &= c.r[2];  // 0608EE3E and r2,r3
    c.r[7] = c.r[3];  // 0608EE40 mov r3,r7
    c.r[2] = c.r[7];  // 0608EE42 mov r7,r2
    c.r[2] <<= 8;  // 0608EE44 shll8 r2
    c.r[2] += c.r[2];  // 0608EE46 add r2,r2
    c.r[2] <<= 2;  // 0608EE48 shll2 r2
    c.r[3] = c.r[14];  // 0608EE4A mov r14,r3
    c.r[7] = c.r[14];  // 0608EE4C mov r14,r7
    c.r[7] += 38;  // 0608EE4E add #38,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0608EE50 mov.w @r7,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608EF54u);  // 0608EE52 mov.w 0x0608EF54,r7
    c.r[3] &= c.r[7];  // 0608EE54 and r7,r3
    c.r[2] = c.r[2];  // 0608EE56 mov r2,r2
    c.r[3] = c.r[3];  // 0608EE58 mov r3,r3
    c.r[2] |= c.r[3];  // 0608EE5A or r3,r2
    st16(c.r[1], c.r[2]);  // 0608EE5C mov.w r2,@r1
    c.r[1] = c.r[14];  // 0608EE5E mov r14,r1
    c.r[3] = c.r[14];  // 0608EE60 mov r14,r3
    c.r[3] += 44;  // 0608EE62 add #44,r3
    c.r[2] = c.r[3];  // 0608EE64 mov r3,r2
    c.r[1] = c.r[3];  // 0608EE66 mov r3,r1
    c.r[1] += 10;  // 0608EE68 add #10,r1
    c.r[3] = ld32(c.r[14] + 20);  // 0608EE6A mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0608EE6C mov r3,r2
    c.r[3] += 39;  // 0608EE6E add #39,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EE70 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608EE72 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608EE74 mov r14,r1
    c.r[2] = c.r[14];  // 0608EE76 mov r14,r2
    c.r[2] += 44;  // 0608EE78 add #44,r2
    c.r[1] = c.r[2];  // 0608EE7A mov r2,r1
    c.r[2] += 6;  // 0608EE7C add #6,r2
    c.r[1] = 0x4u;  // 0608EE7E mov #4,r1
    st8(c.r[2], c.r[1]);  // 0608EE80 mov.b r1,@r2
    c.r[1] = c.r[14];  // 0608EE82 mov r14,r1
    c.r[3] = c.r[14];  // 0608EE84 mov r14,r3
    c.r[3] += 44;  // 0608EE86 add #44,r3
    c.r[2] = c.r[3];  // 0608EE88 mov r3,r2
    c.r[1] = c.r[3];  // 0608EE8A mov r3,r1
    c.r[1] += 7;  // 0608EE8C add #7,r1
    c.r[9] = ld32(c.r[14] + 12);  // 0608EE8E mov.l @(12,r14),r9
    st32(c.r[14] + 56, c.r[9]);  // 0608EE90 mov.l r9,@(56,r14)
    c.r[0] = ld32(c.r[14] + 56);  // 0608EE92 mov.l @(56,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608EE94 cmp/eq #-1,r0
    if (c.t) { goto L_0608EEA4; }  // 0608EE96 bt 0x0608EEA4
    c.r[2] = c.r[14];  // 0608EE98 mov r14,r2
    c.r[3] = c.r[14];  // 0608EE9A mov r14,r3
    c.r[3] += 15;  // 0608EE9C add #15,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EE9E mov.b @r3,r2
    goto L_0608EEAC;  // 0608EEA0 bra 0x0608EEAC ; nop
L_0608EEA4:
    c.r[7] = ld32(c.r[14] + 20);  // 0608EEA4 mov.l @(20,r14),r7
    c.r[3] = c.r[7];  // 0608EEA6 mov r7,r3
    c.r[7] += 35;  // 0608EEA8 add #35,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0608EEAA mov.b @r7,r2
L_0608EEAC:
    st8(c.r[1], c.r[2]);  // 0608EEAC mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608EEAE mov r14,r1
    c.r[2] = c.r[14];  // 0608EEB0 mov r14,r2
    c.r[2] += 44;  // 0608EEB2 add #44,r2
    c.r[1] = c.r[2];  // 0608EEB4 mov r2,r1
    c.r[2] += 8;  // 0608EEB6 add #8,r2
    c.r[1] = 0x4u;  // 0608EEB8 mov #4,r1
    st8(c.r[2], c.r[1]);  // 0608EEBA mov.b r1,@r2
    c.r[1] = c.r[14];  // 0608EEBC mov r14,r1
    c.r[3] = c.r[14];  // 0608EEBE mov r14,r3
    c.r[3] += 44;  // 0608EEC0 add #44,r3
    c.r[2] = c.r[3];  // 0608EEC2 mov r3,r2
    c.r[1] = c.r[3];  // 0608EEC4 mov r3,r1
    c.r[1] += 9;  // 0608EEC6 add #9,r1
    c.r[9] = ld32(c.r[14] + 12);  // 0608EEC8 mov.l @(12,r14),r9
    st32(c.r[14] + 56, c.r[9]);  // 0608EECA mov.l r9,@(56,r14)
    c.r[0] = ld32(c.r[14] + 56);  // 0608EECC mov.l @(56,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608EECE cmp/eq #-1,r0
    if (c.t) { goto L_0608EEDE; }  // 0608EED0 bt 0x0608EEDE
    c.r[2] = c.r[14];  // 0608EED2 mov r14,r2
    c.r[3] = c.r[14];  // 0608EED4 mov r14,r3
    c.r[3] += 15;  // 0608EED6 add #15,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EED8 mov.b @r3,r2
    goto L_0608EEE6;  // 0608EEDA bra 0x0608EEE6 ; nop
L_0608EEDE:
    c.r[7] = ld32(c.r[14] + 20);  // 0608EEDE mov.l @(20,r14),r7
    c.r[3] = c.r[7];  // 0608EEE0 mov r7,r3
    c.r[7] += 35;  // 0608EEE2 add #35,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0608EEE4 mov.b @r7,r2
L_0608EEE6:
    st8(c.r[1], c.r[2]);  // 0608EEE6 mov.b r2,@r1
    c.r[8] = ld32(0x0608EF68u);  // 0608EEE8 mov.l 0x0608EF68,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EEEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EEEEu) return; }  // 0608EEEA jsr @r8 ; nop
    st32(c.r[14] + 40, c.r[0]);  // 0608EEEE mov.l r0,@(40,r14)
    c.r[4] = 0xFu;  // 0608EEF0 mov #15,r4
    c.r[8] = ld32(0x0608EF6Cu);  // 0608EEF2 mov.l 0x0608EF6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EEF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EEF8u) return; }  // 0608EEF4 jsr @r8 ; nop
L_0608EEF8:
    c.r[1] = c.r[14];  // 0608EEF8 mov r14,r1
    c.r[1] += 44;  // 0608EEFA add #44,r1
    c.r[4] = c.r[1];  // 0608EEFC mov r1,r4
    c.r[8] = ld32(0x0608EF70u);  // 0608EEFE mov.l 0x0608EF70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EF04u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EF04u) return; }  // 0608EF00 jsr @r8 ; nop
    c.r[9] = 0x38u;  // 0608EF04 mov #56,r9
    c.r[9] += c.r[14];  // 0608EF06 add r14,r9
    st8(c.r[9], c.r[0]);  // 0608EF08 mov.b r0,@r9
    c.r[0] = 0x38u;  // 0608EF0A mov #56,r0
    c.r[0] += c.r[14];  // 0608EF0C add r14,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0608EF0E mov.b @r0,r0
    c.r[1] = c.r[0] & 0xFFu;  // 0608EF10 extu.b r0,r1
    c.r[0] = c.r[1];  // 0608EF12 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0608EF14 cmp/eq #1,r0
    if (c.t) { goto L_0608EF1C; }  // 0608EF16 bt 0x0608EF1C
    goto L_0608EF3A;  // 0608EF18 bra 0x0608EF3A ; nop
L_0608EF1C:
    c.r[1] = ld32(c.r[14] + 40);  // 0608EF1C mov.l @(40,r14),r1
    c.r[4] = c.r[1];  // 0608EF1E mov r1,r4
    c.r[8] = ld32(0x0608EF6Cu);  // 0608EF20 mov.l 0x0608EF6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EF26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EF26u) return; }  // 0608EF22 jsr @r8 ; nop
    c.r[4] = 0x64u;  // 0608EF26 mov #100,r4
    c.r[8] = ld32(0x0608EF74u);  // 0608EF28 mov.l 0x0608EF74,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EF2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EF2Eu) return; }  // 0608EF2A jsr @r8 ; nop
    c.r[4] = 0xFu;  // 0608EF2E mov #15,r4
    c.r[8] = ld32(0x0608EF6Cu);  // 0608EF30 mov.l 0x0608EF6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EF36u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EF36u) return; }  // 0608EF32 jsr @r8 ; nop
    SH2_POLL(c); goto L_0608EEF8;  // 0608EF36 bra 0x0608EEF8 ; nop
L_0608EF3A:
    c.r[1] = ld32(c.r[14] + 40);  // 0608EF3A mov.l @(40,r14),r1
    c.r[4] = c.r[1];  // 0608EF3C mov r1,r4
    c.r[8] = ld32(0x0608EF6Cu);  // 0608EF3E mov.l 0x0608EF6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608EF44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EF44u) return; }  // 0608EF40 jsr @r8 ; nop
    c.r[14] += 60;  // 0608EF44 add #60,r14
    c.r[15] = c.r[14];  // 0608EF46 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608EF48 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608EF4A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608EF4C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608EF4E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608EF50 rts ; nop
}

void f_0608EF78(SH2Context& c) {
    ran[2090] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608EF78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608EF7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608EF7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608EF7E sts.l pr,@-r15
    c.r[15] -= 56;  // 0608EF80 add #-56,r15
    c.r[14] = c.r[15];  // 0608EF82 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608EF84 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608EF86 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608EF88 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608EF8A mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608EF8C mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608EF8E mov r1,r2
    c.r[2] += 4;  // 0608EF90 add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608EF92 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608EF94 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608EF96 mov r1,r2
    c.r[2] += 56;  // 0608EF98 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608EF9A mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608EF9C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 44);  // 0608EF9E mov.l @(44,r1),r2
    c.r[1] = c.r[2];  // 0608EFA0 mov r2,r1
    c.r[1] += 1;  // 0608EFA2 add #1,r1
    c.r[4] = ld32(0x0608F1B0u);  // 0608EFA4 mov.l 0x0608F1B0,r4
    c.r[5] = c.r[1];  // 0608EFA6 mov r1,r5
    c.r[7] = ld32(0x0608F1B4u);  // 0608EFA8 mov.l 0x0608F1B4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608EFAEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EFAEu) return; }  // 0608EFAA jsr @r7 ; nop
    st32(c.r[14] + 52, c.r[0]);  // 0608EFAE mov.l r0,@(52,r14)
    c.r[2] = ld32(0x0608F1B8u);  // 0608EFB0 mov.l 0x0608F1B8,r2
    c.r[1] = ld32(c.r[14] + 52);  // 0608EFB2 mov.l @(52,r14),r1
    c.r[1] += c.r[2];  // 0608EFB4 add r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608EFB6 mov.b @r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608EFB8 mov.l r2,@(16,r14)
    c.r[1] = ld32(0x0608F1BCu);  // 0608EFBA mov.l 0x0608F1BC,r1
    c.r[5] = ld32(c.r[14] + 16);  // 0608EFBC mov.l @(16,r14),r5
    c.r[4] = ld32(0x0608F1B0u);  // 0608EFBE mov.l 0x0608F1B0,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0608EFC4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EFC4u) return; }  // 0608EFC0 jsr @r1 ; nop
    st32(c.r[14] + 52, c.r[0]);  // 0608EFC4 mov.l r0,@(52,r14)
    c.r[6] = ld32(c.r[14] + 52);  // 0608EFC6 mov.l @(52,r14),r6
    st32(c.r[14] + 20, c.r[6]);  // 0608EFC8 mov.l r6,@(20,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608EFCA mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 44);  // 0608EFCC mov.l @(44,r1),r2
    c.r[3] = ld32(c.r[14] + 20);  // 0608EFCE mov.l @(20,r14),r3
    c.r[1] = c.r[2];  // 0608EFD0 mov r2,r1
    c.r[1] -= c.r[3];  // 0608EFD2 sub r3,r1
    c.r[2] = c.r[1];  // 0608EFD4 mov r1,r2
    c.r[2] <<= 8;  // 0608EFD6 shll8 r2
    c.r[2] <<= 2;  // 0608EFD8 shll2 r2
    c.r[4] = c.r[2];  // 0608EFDA mov r2,r4
    c.r[5] = ld32(c.r[14] + 20);  // 0608EFDC mov.l @(20,r14),r5
    c.r[7] = ld32(0x0608F1B4u);  // 0608EFDE mov.l 0x0608F1B4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608EFE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608EFE4u) return; }  // 0608EFE0 jsr @r7 ; nop
    st32(c.r[14] + 52, c.r[0]);  // 0608EFE4 mov.l r0,@(52,r14)
    c.r[6] = ld32(c.r[14] + 52);  // 0608EFE6 mov.l @(52,r14),r6
    st32(c.r[14] + 24, c.r[6]);  // 0608EFE8 mov.l r6,@(24,r14)
    c.r[2] = c.r[14];  // 0608EFEA mov r14,r2
    c.r[1] = c.r[14];  // 0608EFEC mov r14,r1
    c.r[1] += 40;  // 0608EFEE add #40,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608EFF0 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608EFF2 mov r3,r2
    c.r[3] += 23;  // 0608EFF4 add #23,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608EFF6 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608EFF8 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608EFFA mov r14,r1
    c.r[3] = c.r[14];  // 0608EFFC mov r14,r3
    c.r[3] += 40;  // 0608EFFE add #40,r3
    c.r[2] = c.r[3];  // 0608F000 mov r3,r2
    c.r[1] = c.r[3];  // 0608F002 mov r3,r1
    c.r[1] += 1;  // 0608F004 add #1,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608F006 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608F008 mov r3,r2
    c.r[3] += 31;  // 0608F00A add #31,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608F00C mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608F00E mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608F010 mov r14,r1
    c.r[3] = c.r[14];  // 0608F012 mov r14,r3
    c.r[3] += 40;  // 0608F014 add #40,r3
    c.r[2] = c.r[3];  // 0608F016 mov r3,r2
    c.r[1] = c.r[3];  // 0608F018 mov r3,r1
    c.r[1] += 2;  // 0608F01A add #2,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608F01C mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608F01E mov r3,r2
    c.r[3] += 27;  // 0608F020 add #27,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608F022 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608F024 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608F026 mov r14,r1
    c.r[3] = c.r[14];  // 0608F028 mov r14,r3
    c.r[3] += 40;  // 0608F02A add #40,r3
    c.r[2] = c.r[3];  // 0608F02C mov r3,r2
    c.r[1] = c.r[3];  // 0608F02E mov r3,r1
    c.r[1] += 4;  // 0608F030 add #4,r1
    c.r[2] = c.r[14];  // 0608F032 mov r14,r2
    c.r[3] = c.r[14];  // 0608F034 mov r14,r3
    c.r[3] += 18;  // 0608F036 add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608F038 mov.w @r3,r2
    c.r[3] = 0u - c.r[2];  // 0608F03A neg r2,r3
    c.r[2] = c.r[3];  // 0608F03C mov r3,r2
    c.r[3] = 0xFu;  // 0608F03E mov #15,r3
    c.r[3] &= c.r[2];  // 0608F040 and r2,r3
    c.r[7] = c.r[3];  // 0608F042 mov r3,r7
    c.r[2] = c.r[7];  // 0608F044 mov r7,r2
    c.r[2] <<= 8;  // 0608F046 shll8 r2
    c.r[2] += c.r[2];  // 0608F048 add r2,r2
    c.r[2] <<= 2;  // 0608F04A shll2 r2
    c.r[3] = c.r[14];  // 0608F04C mov r14,r3
    c.r[7] = c.r[14];  // 0608F04E mov r14,r7
    c.r[7] += 26;  // 0608F050 add #26,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0608F052 mov.w @r7,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608F1AAu);  // 0608F054 mov.w 0x0608F1AA,r7
    c.r[3] &= c.r[7];  // 0608F056 and r7,r3
    c.r[2] = c.r[2];  // 0608F058 mov r2,r2
    c.r[3] = c.r[3];  // 0608F05A mov r3,r3
    c.r[2] |= c.r[3];  // 0608F05C or r3,r2
    st16(c.r[1], c.r[2]);  // 0608F05E mov.w r2,@r1
    c.r[1] = c.r[14];  // 0608F060 mov r14,r1
    c.r[2] = c.r[14];  // 0608F062 mov r14,r2
    c.r[2] += 40;  // 0608F064 add #40,r2
    c.r[1] = c.r[2];  // 0608F066 mov r2,r1
    c.r[2] += 6;  // 0608F068 add #6,r2
    c.r[1] = 0x4u;  // 0608F06A mov #4,r1
    st8(c.r[2], c.r[1]);  // 0608F06C mov.b r1,@r2
    c.r[1] = c.r[14];  // 0608F06E mov r14,r1
    c.r[3] = c.r[14];  // 0608F070 mov r14,r3
    c.r[3] += 40;  // 0608F072 add #40,r3
    c.r[2] = c.r[3];  // 0608F074 mov r3,r2
    c.r[1] = c.r[3];  // 0608F076 mov r3,r1
    c.r[1] += 7;  // 0608F078 add #7,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608F07A mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608F07C mov r3,r2
    c.r[3] += 35;  // 0608F07E add #35,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608F080 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608F082 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608F084 mov r14,r1
    c.r[2] = c.r[14];  // 0608F086 mov r14,r2
    c.r[2] += 40;  // 0608F088 add #40,r2
    c.r[1] = c.r[2];  // 0608F08A mov r2,r1
    c.r[2] += 8;  // 0608F08C add #8,r2
    c.r[1] = 0x4u;  // 0608F08E mov #4,r1
    st8(c.r[2], c.r[1]);  // 0608F090 mov.b r1,@r2
    c.r[1] = c.r[14];  // 0608F092 mov r14,r1
    c.r[3] = c.r[14];  // 0608F094 mov r14,r3
    c.r[3] += 40;  // 0608F096 add #40,r3
    c.r[2] = c.r[3];  // 0608F098 mov r3,r2
    c.r[1] = c.r[3];  // 0608F09A mov r3,r1
    c.r[1] += 9;  // 0608F09C add #9,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608F09E mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608F0A0 mov r3,r2
    c.r[3] += 35;  // 0608F0A2 add #35,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608F0A4 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608F0A6 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608F0A8 mov r14,r1
    c.r[3] = c.r[14];  // 0608F0AA mov r14,r3
    c.r[3] += 40;  // 0608F0AC add #40,r3
    c.r[2] = c.r[3];  // 0608F0AE mov r3,r2
    c.r[1] = c.r[3];  // 0608F0B0 mov r3,r1
    c.r[1] += 10;  // 0608F0B2 add #10,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608F0B4 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608F0B6 mov r3,r2
    c.r[3] += 39;  // 0608F0B8 add #39,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608F0BA mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608F0BC mov.b r2,@r1
    c.r[2] = c.r[14];  // 0608F0BE mov r14,r2
    c.r[1] = c.r[14];  // 0608F0C0 mov r14,r1
    c.r[1] += 32;  // 0608F0C2 add #32,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608F0C4 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608F0C6 mov.l @(36,r2),r0
    st32(c.r[14] + 52, c.r[0]);  // 0608F0C8 mov.l r0,@(52,r14)
    c.r[0] = ld32(c.r[14] + 52);  // 0608F0CA mov.l @(52,r14),r0
    c.t = c.r[0] == 0x1u;  // 0608F0CC cmp/eq #1,r0
    if (c.t) { goto L_0608F0D6; }  // 0608F0CE bt 0x0608F0D6
    c.r[8] = (uint32_t)(int16_t)ld16(0x0608F1ACu);  // 0608F0D0 mov.w 0x0608F1AC,r8
    goto L_0608F0D8;  // 0608F0D2 bra 0x0608F0D8 ; nop
L_0608F0D6:
    c.r[8] = 0x0u;  // 0608F0D6 mov #0,r8
L_0608F0D8:
    c.r[2] = ld32(c.r[14] + 12);  // 0608F0D8 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 40);  // 0608F0DA mov.l @(40,r2),r3
    c.r[2] = 0x10u;  // 0608F0DC mov #16,r2
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0608F0DE cmp/gt r2,r3
    if (c.t) { goto L_0608F0F0; }  // 0608F0E0 bt 0x0608F0F0
    c.r[2] = ld32(c.r[14] + 12);  // 0608F0E2 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 40);  // 0608F0E4 mov.l @(40,r2),r3
    c.r[2] = 0x8u;  // 0608F0E6 mov #8,r2
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0608F0E8 cmp/gt r2,r3
    if (!c.t) { goto L_0608F0F0; }  // 0608F0EA bf 0x0608F0F0
    goto L_0608F0FA;  // 0608F0EC bra 0x0608F0FA ; nop
L_0608F0F0:
    c.r[3] = 0x10u;  // 0608F0F0 mov #16,r3
    c.r[3] |= c.r[8];  // 0608F0F2 or r8,r3
    c.r[2] = c.r[3];  // 0608F0F4 mov r3,r2
    goto L_0608F0FC;  // 0608F0F6 bra 0x0608F0FC ; nop
L_0608F0FA:
    c.r[2] = c.r[8];  // 0608F0FA mov r8,r2
L_0608F0FC:
    st8(c.r[1], c.r[2]);  // 0608F0FC mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608F0FE mov r14,r1
    c.r[3] = c.r[14];  // 0608F100 mov r14,r3
    c.r[3] += 32;  // 0608F102 add #32,r3
    c.r[2] = c.r[3];  // 0608F104 mov r3,r2
    c.r[1] = c.r[3];  // 0608F106 mov r3,r1
    c.r[1] += 2;  // 0608F108 add #2,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608F10A mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2] + 8);  // 0608F10C mov.l @(8,r2),r3
    c.r[2] = c.r[3];  // 0608F10E mov r3,r2
    c.r[2] >>= 2;  // 0608F110 shlr2 r2
    c.r[2] >>= 2;  // 0608F112 shlr2 r2
    st16(c.r[1], c.r[2]);  // 0608F114 mov.w r2,@r1
    c.r[1] = c.r[14];  // 0608F116 mov r14,r1
    c.r[3] = c.r[14];  // 0608F118 mov r14,r3
    c.r[3] += 32;  // 0608F11A add #32,r3
    c.r[2] = c.r[3];  // 0608F11C mov r3,r2
    c.r[1] = c.r[3];  // 0608F11E mov r3,r1
    c.r[1] += 4;  // 0608F120 add #4,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608F122 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608F124 mov r3,r2
    c.r[3] += 14;  // 0608F126 add #14,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608F128 mov.w @r3,r2
    st16(c.r[1], c.r[2]);  // 0608F12A mov.w r2,@r1
    c.r[9] = ld32(0x0608F1C0u);  // 0608F12C mov.l 0x0608F1C0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F132u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F132u) return; }  // 0608F12E jsr @r9 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 0608F132 mov.l r0,@(28,r14)
    c.r[4] = 0xFu;  // 0608F134 mov #15,r4
    c.r[9] = ld32(0x0608F1C4u);  // 0608F136 mov.l 0x0608F1C4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F13Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F13Cu) return; }  // 0608F138 jsr @r9 ; nop
L_0608F13C:
    c.r[1] = c.r[14];  // 0608F13C mov r14,r1
    c.r[1] += 40;  // 0608F13E add #40,r1
    c.r[2] = c.r[14];  // 0608F140 mov r14,r2
    c.r[2] += 32;  // 0608F142 add #32,r2
    c.r[5] = c.r[1];  // 0608F144 mov r1,r5
    c.r[4] = c.r[2];  // 0608F146 mov r2,r4
    c.r[9] = ld32(0x0608F1C8u);  // 0608F148 mov.l 0x0608F1C8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F14Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F14Eu) return; }  // 0608F14A jsr @r9 ; nop
    c.r[6] = 0x34u;  // 0608F14E mov #52,r6
    c.r[6] += c.r[14];  // 0608F150 add r14,r6
    st8(c.r[6], c.r[0]);  // 0608F152 mov.b r0,@r6
    c.r[0] = 0x34u;  // 0608F154 mov #52,r0
    c.r[0] += c.r[14];  // 0608F156 add r14,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0608F158 mov.b @r0,r0
    c.r[1] = c.r[0] & 0xFFu;  // 0608F15A extu.b r0,r1
    c.r[0] = c.r[1];  // 0608F15C mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0608F15E cmp/eq #1,r0
    if (c.t) { goto L_0608F166; }  // 0608F160 bt 0x0608F166
    goto L_0608F184;  // 0608F162 bra 0x0608F184 ; nop
L_0608F166:
    c.r[1] = ld32(c.r[14] + 28);  // 0608F166 mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 0608F168 mov r1,r4
    c.r[9] = ld32(0x0608F1C4u);  // 0608F16A mov.l 0x0608F1C4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F170u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F170u) return; }  // 0608F16C jsr @r9 ; nop
    c.r[4] = 0x64u;  // 0608F170 mov #100,r4
    c.r[9] = ld32(0x0608F1CCu);  // 0608F172 mov.l 0x0608F1CC,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F178u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F178u) return; }  // 0608F174 jsr @r9 ; nop
    c.r[4] = 0xFu;  // 0608F178 mov #15,r4
    c.r[9] = ld32(0x0608F1C4u);  // 0608F17A mov.l 0x0608F1C4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F180u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F180u) return; }  // 0608F17C jsr @r9 ; nop
    SH2_POLL(c); goto L_0608F13C;  // 0608F180 bra 0x0608F13C ; nop
L_0608F184:
    c.r[1] = ld32(c.r[14] + 8);  // 0608F184 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 0608F186 mov.l @(20,r1),r2
    c.r[4] = c.r[2];  // 0608F188 mov r2,r4
    c.r[9] = ld32(0x0608F1D0u);  // 0608F18A mov.l 0x0608F1D0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F190u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F190u) return; }  // 0608F18C jsr @r9 ; nop
    c.r[1] = ld32(c.r[14] + 28);  // 0608F190 mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 0608F192 mov r1,r4
    c.r[9] = ld32(0x0608F1C4u);  // 0608F194 mov.l 0x0608F1C4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F19Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F19Au) return; }  // 0608F196 jsr @r9 ; nop
    c.r[14] += 56;  // 0608F19A add #56,r14
    c.r[15] = c.r[14];  // 0608F19C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F19E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F1A0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F1A2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F1A4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F1A6 rts ; nop
}

void f_0608F1D4(SH2Context& c) {
    ran[2091] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F1D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F1D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F1D8 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608F1DA add #-20,r15
    c.r[14] = c.r[15];  // 0608F1DC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608F1DE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608F1E0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608F1E2 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608F1E4 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608F1E6 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608F1E8 mov r1,r2
    c.r[2] += 4;  // 0608F1EA add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608F1EC mov.l r2,@(8,r14)
    c.r[8] = ld32(0x0608F260u);  // 0608F1EE mov.l 0x0608F260,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F1F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F1F4u) return; }  // 0608F1F0 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0608F1F4 mov.l r0,@(12,r14)
    c.r[4] = 0xFu;  // 0608F1F6 mov #15,r4
    c.r[8] = ld32(0x0608F264u);  // 0608F1F8 mov.l 0x0608F264,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F1FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F1FEu) return; }  // 0608F1FA jsr @r8 ; nop
L_0608F1FE:
    c.r[2] = ld32(c.r[14] + 8);  // 0608F1FE mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608F200 mov r2,r1
    c.r[2] += 23;  // 0608F202 add #23,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608F204 mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0608F206 extu.b r3,r1
    c.r[4] = c.r[1];  // 0608F208 mov r1,r4
    c.r[8] = ld32(0x0608F268u);  // 0608F20A mov.l 0x0608F268,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F210u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F210u) return; }  // 0608F20C jsr @r8 ; nop
    c.r[7] = 0x13u;  // 0608F210 mov #19,r7
    c.r[7] += c.r[14];  // 0608F212 add r14,r7
    st8(c.r[7], c.r[0]);  // 0608F214 mov.b r0,@r7
    c.r[0] = 0x13u;  // 0608F216 mov #19,r0
    c.r[0] += c.r[14];  // 0608F218 add r14,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0608F21A mov.b @r0,r0
    c.r[1] = c.r[0] & 0xFFu;  // 0608F21C extu.b r0,r1
    c.r[0] = c.r[1];  // 0608F21E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0608F220 cmp/eq #1,r0
    if (c.t) { goto L_0608F228; }  // 0608F222 bt 0x0608F228
    goto L_0608F246;  // 0608F224 bra 0x0608F246 ; nop
L_0608F228:
    c.r[1] = ld32(c.r[14] + 12);  // 0608F228 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608F22A mov r1,r4
    c.r[8] = ld32(0x0608F264u);  // 0608F22C mov.l 0x0608F264,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F232u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F232u) return; }  // 0608F22E jsr @r8 ; nop
    c.r[4] = 0x64u;  // 0608F232 mov #100,r4
    c.r[8] = ld32(0x0608F26Cu);  // 0608F234 mov.l 0x0608F26C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F23Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F23Au) return; }  // 0608F236 jsr @r8 ; nop
    c.r[4] = 0xFu;  // 0608F23A mov #15,r4
    c.r[8] = ld32(0x0608F264u);  // 0608F23C mov.l 0x0608F264,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F242u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F242u) return; }  // 0608F23E jsr @r8 ; nop
    SH2_POLL(c); goto L_0608F1FE;  // 0608F242 bra 0x0608F1FE ; nop
L_0608F246:
    c.r[1] = ld32(c.r[14] + 12);  // 0608F246 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608F248 mov r1,r4
    c.r[8] = ld32(0x0608F264u);  // 0608F24A mov.l 0x0608F264,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F250u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F250u) return; }  // 0608F24C jsr @r8 ; nop
    c.r[14] += 20;  // 0608F250 add #20,r14
    c.r[15] = c.r[14];  // 0608F252 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F254 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F256 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F258 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F25A rts ; nop
}

void f_0608F270(SH2Context& c) {
    ran[2092] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F270 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F272 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F274 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608F276 add #-4,r15
    c.r[14] = c.r[15];  // 0608F278 mov r15,r14
    c.r[8] = ld32(0x0608F2A4u);  // 0608F27A mov.l 0x0608F2A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F280u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F280u) return; }  // 0608F27C jsr @r8 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608F2A0u);  // 0608F280 mov.w 0x0608F2A0,r1
    c.r[1] &= c.r[0];  // 0608F282 and r0,r1
    c.r[2] = c.r[1];  // 0608F284 mov r1,r2
    c.r[2] >>= 2;  // 0608F286 shlr2 r2
    c.r[2] >>= 2;  // 0608F288 shlr2 r2
    st32(c.r[14], c.r[2]);  // 0608F28A mov.l r2,@r14
    c.r[0] = ld32(c.r[14]);  // 0608F28C mov.l @r14,r0
    goto L_0608F292;  // 0608F28E bra 0x0608F292 ; nop
L_0608F292:
    c.r[14] += 4;  // 0608F292 add #4,r14
    c.r[15] = c.r[14];  // 0608F294 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F296 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F298 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F29A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F29C rts ; nop
}

void f_0608F2A8(SH2Context& c) {
    ran[2093] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F2A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F2AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F2AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F2AE sts.l pr,@-r15
    c.r[15] -= 4;  // 0608F2B0 add #-4,r15
    c.r[14] = c.r[15];  // 0608F2B2 mov r15,r14
    c.r[8] = c.r[4];  // 0608F2B4 mov r4,r8
    c.r[9] = ld32(0x0608F2ECu);  // 0608F2B6 mov.l 0x0608F2EC,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F2BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F2BCu) return; }  // 0608F2B8 jsr @r9 ; nop
    st32(c.r[14], c.r[0]);  // 0608F2BC mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 0608F2BE mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F2EAu);  // 0608F2C0 mov.w 0x0608F2EA,r2
    c.r[1] &= c.r[2];  // 0608F2C2 and r2,r1
    st32(c.r[14], c.r[1]);  // 0608F2C4 mov.l r1,@r14
    c.r[1] = c.r[8];  // 0608F2C6 mov r8,r1
    c.r[1] <<= 2;  // 0608F2C8 shll2 r1
    c.r[1] <<= 2;  // 0608F2CA shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608F2CC mov.l @r14,r2
    c.r[1] |= c.r[2];  // 0608F2CE or r2,r1
    st32(c.r[14], c.r[1]);  // 0608F2D0 mov.l r1,@r14
    c.r[4] = ld32(c.r[14]);  // 0608F2D2 mov.l @r14,r4
    c.r[9] = ld32(0x0608F2F0u);  // 0608F2D4 mov.l 0x0608F2F0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F2DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F2DAu) return; }  // 0608F2D6 jsr @r9 ; nop
    c.r[14] += 4;  // 0608F2DA add #4,r14
    c.r[15] = c.r[14];  // 0608F2DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F2DE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F2E0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F2E2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F2E4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F2E6 rts ; nop
}

void f_0608F2F4(SH2Context& c) {
    ran[2094] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F2F4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608F2F6 mov r15,r14
    c.r[1] = c.r[4];  // 0608F2F8 mov r4,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0608F2FA ldc r1,sr
    c.r[15] = c.r[14];  // 0608F2FC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F2FE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F300 rts ; nop
}

void f_0608F304(SH2Context& c) {
    ran[2095] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F304 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608F306 add #-4,r15
    c.r[14] = c.r[15];  // 0608F308 mov r15,r14
    c.r[1] = sh2_get_sr(c);  // 0608F30A stc sr,r1
    st32(c.r[14], c.r[1]);  // 0608F30C mov.l r1,@r14
    c.r[0] = ld32(c.r[14]);  // 0608F30E mov.l @r14,r0
    goto L_0608F314;  // 0608F310 bra 0x0608F314 ; nop
L_0608F314:
    c.r[14] += 4;  // 0608F314 add #4,r14
    c.r[15] = c.r[14];  // 0608F316 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F318 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F31A rts ; nop
}

void f_0608F320(SH2Context& c) {
    ran[2096] = 1;
    c.r[8] = c.r[6];  // 0608F320 mov r6,r8
    c.r[0] = c.r[7];  // 0608F322 mov r7,r0
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0608F324 shar r8
    c.r[0] <<= 2;  // 0608F326 shll2 r0
    c.r[0] += c.r[8];  // 0608F328 add r8,r0
    c.r[0] += 16;  // 0608F32A add #16,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608F32C mov.b @(r0,r1),r8
    c.r[0] = c.r[6];  // 0608F32E mov r6,r0
    c.r[8] <<= 8;  // 0608F330 shll8 r8
    c.t = (c.r[0] & 0x1u) == 0;  // 0608F332 tst #1,r0
    if (!c.t) { goto L_0608F33A; }  // 0608F334 bf 0x0608F33A
    c.r[8] <<= 2;  // 0608F336 shll2 r8
    c.r[8] <<= 2;  // 0608F338 shll2 r8
L_0608F33A:
    c.r[0] = ld32(0x0608F520u);  // 0608F33A mov.l 0x0608F520,r0
    c.r[8] &= c.r[0];  // 0608F33C and r0,r8
    c.r[0] = c.r[11];  // 0608F33E mov r11,r0
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 0608F340 exts.w r8,r8
    c.t = (c.r[0] & 0x1u) == 0;  // 0608F342 tst #1,r0
    if (c.t) { goto L_0608F348; }  // 0608F344 bt 0x0608F348
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0608F346 shlr r8
L_0608F348:
    c.t = (c.r[0] & 0x2u) == 0;  // 0608F348 tst #2,r0
    if (c.t) { goto L_0608F34E; }  // 0608F34A bt 0x0608F34E
    c.r[8] >>= 2;  // 0608F34C shlr2 r8
L_0608F34E:
    c.t = (c.r[0] & 0x4u) == 0;  // 0608F34E tst #4,r0
    if (c.t) { goto L_0608F356; }  // 0608F350 bt 0x0608F356
    c.r[8] >>= 2;  // 0608F352 shlr2 r8
    c.r[8] >>= 2;  // 0608F354 shlr2 r8
L_0608F356:
    c.t = (c.r[0] & 0x8u) == 0;  // 0608F356 tst #8,r0
    if (c.t) { goto L_0608F35C; }  // 0608F358 bt 0x0608F35C
    c.r[8] >>= 8;  // 0608F35A shlr8 r8
L_0608F35C:
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[5] * (int16_t)c.r[9]);  // 0608F35C muls.w r9,r5
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 0608F35E exts.w r8,r8
    c.r[0] = c.macl;  // 0608F360 sts macl,r0
    c.t = (int32_t)c.r[0] >= 0;  // 0608F362 cmp/pz r0
    { const bool k = c.t; c.r[0] >>= 8; if (k) { goto L_0608F36A; } }  // 0608F364 bt/s 0x0608F36A ; shlr8 r0
    c.r[0] |= c.r[14];  // 0608F368 or r14,r0
L_0608F36A:
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[4] * (int16_t)c.r[10]);  // 0608F36A muls.w r10,r4
    c.r[8] += c.r[0];  // 0608F36C add r0,r8
    c.r[0] = c.macl;  // 0608F36E sts macl,r0
    c.t = (int32_t)c.r[0] >= 0;  // 0608F370 cmp/pz r0
    { const bool k = c.t; c.r[0] >>= 8; if (k) { goto L_0608F378; } }  // 0608F372 bt/s 0x0608F378 ; shlr8 r0
    c.r[0] |= c.r[14];  // 0608F376 or r14,r0
L_0608F378:
    c.r[8] += c.r[0];  // 0608F378 add r0,r8
    c.r[10] = c.r[9];  // 0608F37A mov r9,r10
    c.t = (int32_t)c.r[8] > (int32_t)c.r[12];  // 0608F37C cmp/gt r12,r8
    if (!c.t) { goto L_0608F388; }  // 0608F37E bf 0x0608F388
    st16(c.r[2], c.r[12]);  // 0608F380 mov.w r12,@r2
    c.r[9] = c.r[12];  // 0608F382 mov r12,r9
    { const uint32_t x = c.pr; c.r[2] += 2; c.pc = x; return; }  // 0608F384 rts ; add #2,r2
L_0608F388:
    c.t = (int32_t)c.r[13] > (int32_t)c.r[8];  // 0608F388 cmp/gt r8,r13
    if (!c.t) { goto L_0608F394; }  // 0608F38A bf 0x0608F394
    st16(c.r[2], c.r[13]);  // 0608F38C mov.w r13,@r2
    c.r[9] = c.r[13];  // 0608F38E mov r13,r9
    { const uint32_t x = c.pr; c.r[2] += 2; c.pc = x; return; }  // 0608F390 rts ; add #2,r2
L_0608F394:
    st16(c.r[2], c.r[8]);  // 0608F394 mov.w r8,@r2
    c.r[9] = c.r[8];  // 0608F396 mov r8,r9
    { const uint32_t x = c.pr; c.r[2] += 2; c.pc = x; return; }  // 0608F398 rts ; add #2,r2
}

void f_0608F39C(SH2Context& c) {
    ran[2097] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F39C sts.l pr,@-r15
    c.r[0] = c.r[6];  // 0608F39E mov r6,r0
    c.r[0] += 4;  // 0608F3A0 add #4,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608F3A2 mov.b @(r0,r1),r4
    c.r[0] = c.r[4];  // 0608F3A4 mov r4,r0
    c.r[0] &= 0xFu;  // 0608F3A6 and #15,r0
    c.r[11] = c.r[0];  // 0608F3A8 mov r0,r11
    c.r[0] = c.r[4];  // 0608F3AA mov r4,r0
    c.r[0] &= 0xF0u;  // 0608F3AC and #240,r0
    c.r[0] >>= 2;  // 0608F3AE shlr2 r0
    c.r[4] = c.r[3];  // 0608F3B0 mov r3,r4
    c.r[4] += c.r[0];  // 0608F3B2 add r0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[4]); c.r[4] += 2;  // 0608F3B4 mov.w @r4+,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0608F3B6 mov.w @r4,r4
    c.pr = 0x0608F3BCu; c.r[7] ^= c.r[7]; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3BCu) return;  // 0608F3B8 bsr 0x0608F320 ; xor r7,r7
    c.pr = 0x0608F3C0u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3C0u) return;  // 0608F3BC bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3C4u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3C4u) return;  // 0608F3C0 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3C8u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3C8u) return;  // 0608F3C4 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3CCu; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3CCu) return;  // 0608F3C8 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3D0u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3D0u) return;  // 0608F3CC bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3D4u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3D4u) return;  // 0608F3D0 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3D8u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3D8u) return;  // 0608F3D4 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3DCu; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3DCu) return;  // 0608F3D8 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3E0u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3E0u) return;  // 0608F3DC bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3E4u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3E4u) return;  // 0608F3E0 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3E8u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3E8u) return;  // 0608F3E4 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3ECu; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3ECu) return;  // 0608F3E8 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3F0u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3F0u) return;  // 0608F3EC bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3F4u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3F4u) return;  // 0608F3F0 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3F8u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3F8u) return;  // 0608F3F4 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F3FCu; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F3FCu) return;  // 0608F3F8 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F400u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F400u) return;  // 0608F3FC bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F404u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F404u) return;  // 0608F400 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F408u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F408u) return;  // 0608F404 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F40Cu; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F40Cu) return;  // 0608F408 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F410u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F410u) return;  // 0608F40C bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F414u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F414u) return;  // 0608F410 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F418u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F418u) return;  // 0608F414 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F41Cu; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F41Cu) return;  // 0608F418 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F420u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F420u) return;  // 0608F41C bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F424u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F424u) return;  // 0608F420 bsr 0x0608F320 ; add #1,r7
    c.pr = 0x0608F428u; c.r[7] += 1; SH2_POLL(c); sh2_call(c, 0x0608F320u); if (c.pc != 0x0608F428u) return;  // 0608F424 bsr 0x0608F320 ; add #1,r7
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F428 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F42A rts ; nop
}

void f_0608F42E(SH2Context& c) {
    ran[2098] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F42E mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F430 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608F432 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608F434 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608F436 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608F438 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F43A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 0608F43C sts.l macl,@-r15
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 0608F43E sts.l mach,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F440 sts.l pr,@-r15
    c.r[1] = c.r[4];  // 0608F442 mov r4,r1
    c.r[2] = c.r[5];  // 0608F444 mov r5,r2
    c.r[3] = ld32(0x0608F534u);  // 0608F446 mov.l 0x0608F534,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x0608F53Cu);  // 0608F448 mov.w 0x0608F53C,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0608F53Eu);  // 0608F44A mov.w 0x0608F53E,r13
    c.r[14] = ld32(0x0608F538u);  // 0608F44C mov.l 0x0608F538,r14
    c.r[9] = ld32(0x0608F490u);  // 0608F44E mov.l 0x0608F490,r9
    c.r[10] = ld32(0x0608F494u);  // 0608F450 mov.l 0x0608F494,r10
    c.pr = 0x0608F456u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F456u) return;  // 0608F452 bsr 0x0608F39C ; mov #0,r6
    c.pr = 0x0608F45Au; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F45Au) return;  // 0608F456 bsr 0x0608F39C ; add #1,r6
    c.pr = 0x0608F45Eu; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F45Eu) return;  // 0608F45A bsr 0x0608F39C ; add #1,r6
    c.pr = 0x0608F462u; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F462u) return;  // 0608F45E bsr 0x0608F39C ; add #1,r6
    c.pr = 0x0608F466u; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F466u) return;  // 0608F462 bsr 0x0608F39C ; add #1,r6
    c.pr = 0x0608F46Au; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F46Au) return;  // 0608F466 bsr 0x0608F39C ; add #1,r6
    c.pr = 0x0608F46Eu; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F46Eu) return;  // 0608F46A bsr 0x0608F39C ; add #1,r6
    c.pr = 0x0608F472u; c.r[6] += 1; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F472u) return;  // 0608F46E bsr 0x0608F39C ; add #1,r6
    c.r[0] = 0x0608F494u;  // 0608F472 mova 0x0608F494,r0
    st32(c.r[0], c.r[10]);  // 0608F474 mov.l r10,@r0
    c.r[0] -= 4; st32(c.r[0], c.r[9]);  // 0608F476 mov.l r9,@-r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F478 lds.l @r15+,pr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 0608F47A lds.l @r15+,mach
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 0608F47C lds.l @r15+,macl
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F47E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608F480 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608F482 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608F484 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608F486 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F488 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608F48A rts ; mov.l @r15+,r8
}

void f_0608F498(SH2Context& c) {
    ran[2099] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F498 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F49A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608F49C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608F49E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608F4A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608F4A2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F4A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 0608F4A6 sts.l macl,@-r15
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 0608F4A8 sts.l mach,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F4AA sts.l pr,@-r15
    c.r[1] = c.r[4];  // 0608F4AC mov r4,r1
    c.r[2] = c.r[5];  // 0608F4AE mov r5,r2
    c.r[3] = ld32(0x0608F534u);  // 0608F4B0 mov.l 0x0608F534,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x0608F53Cu);  // 0608F4B2 mov.w 0x0608F53C,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0608F53Eu);  // 0608F4B4 mov.w 0x0608F53E,r13
    c.r[14] = ld32(0x0608F538u);  // 0608F4B6 mov.l 0x0608F538,r14
    c.r[9] = ld32(0x0608F510u);  // 0608F4B8 mov.l 0x0608F510,r9
    c.r[10] = ld32(0x0608F514u);  // 0608F4BA mov.l 0x0608F514,r10
    c.pr = 0x0608F4C0u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4C0u) return;  // 0608F4BC bsr 0x0608F39C ; mov #0,r6
    c.pr = 0x0608F4C4u; c.r[6] += 2; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4C4u) return;  // 0608F4C0 bsr 0x0608F39C ; add #2,r6
    c.pr = 0x0608F4C8u; c.r[6] += 2; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4C8u) return;  // 0608F4C4 bsr 0x0608F39C ; add #2,r6
    c.pr = 0x0608F4CCu; c.r[6] += 2; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4CCu) return;  // 0608F4C8 bsr 0x0608F39C ; add #2,r6
    c.r[0] = 0x0608F514u;  // 0608F4CC mova 0x0608F514,r0
    st32(c.r[0], c.r[10]);  // 0608F4CE mov.l r10,@r0
    c.r[0] -= 4; st32(c.r[0], c.r[9]);  // 0608F4D0 mov.l r9,@-r0
    c.r[9] = ld32(0x0608F518u);  // 0608F4D2 mov.l 0x0608F518,r9
    c.r[10] = ld32(0x0608F51Cu);  // 0608F4D4 mov.l 0x0608F51C,r10
    c.pr = 0x0608F4DAu; c.r[6] -= 5; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4DAu) return;  // 0608F4D6 bsr 0x0608F39C ; add #-5,r6
    c.pr = 0x0608F4DEu; c.r[6] += 2; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4DEu) return;  // 0608F4DA bsr 0x0608F39C ; add #2,r6
    c.pr = 0x0608F4E2u; c.r[6] += 2; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4E2u) return;  // 0608F4DE bsr 0x0608F39C ; add #2,r6
    c.pr = 0x0608F4E6u; c.r[6] += 2; SH2_POLL(c); sh2_call(c, 0x0608F39Cu); if (c.pc != 0x0608F4E6u) return;  // 0608F4E2 bsr 0x0608F39C ; add #2,r6
    c.r[0] = 0x0608F51Cu;  // 0608F4E6 mova 0x0608F51C,r0
    st32(c.r[0], c.r[10]);  // 0608F4E8 mov.l r10,@r0
    c.r[0] -= 4; st32(c.r[0], c.r[9]);  // 0608F4EA mov.l r9,@-r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F4EC lds.l @r15+,pr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 0608F4EE lds.l @r15+,mach
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 0608F4F0 lds.l @r15+,macl
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F4F2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608F4F4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608F4F6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608F4F8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608F4FA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F4FC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608F4FE rts ; mov.l @r15+,r8
}

void f_0608F540(SH2Context& c) {
    ran[2100] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F540 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608F542 mov r15,r14
    c.r[1] = ld32(0x0608F57Cu);  // 0608F544 mov.l 0x0608F57C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608F546 mov.b @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608F578u);  // 0608F548 mov.w 0x0608F578,r1
    c.r[1] &= c.r[2];  // 0608F54A and r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0608F54C extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F54E tst r2,r2
    if (c.t) { goto L_0608F55C; }  // 0608F550 bt 0x0608F55C
    c.r[1] = ld32(0x0608F580u);  // 0608F552 mov.l 0x0608F580,r1
    c.r[2] = 0xFFFFFF80u;  // 0608F554 mov #-128,r2
    st8(c.r[1], c.r[2]);  // 0608F556 mov.b r2,@r1
    goto L_0608F570;  // 0608F558 bra 0x0608F570 ; nop
L_0608F55C:
    c.r[2] = ld32(0x0608F584u);  // 0608F55C mov.l 0x0608F584,r2
    c.r[1] = ld32(c.r[2]);  // 0608F55E mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608F560 mov.w @r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0608F562 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608F564 tst r1,r1
    if (!c.t) { goto L_0608F56C; }  // 0608F566 bf 0x0608F56C
    goto L_0608F570;  // 0608F568 bra 0x0608F570 ; nop
L_0608F56C:
    SH2_POLL(c); goto L_0608F55C;  // 0608F56C bra 0x0608F55C ; nop
L_0608F570:
    c.r[15] = c.r[14];  // 0608F570 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F572 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F574 rts ; nop
}

void f_0608F588(SH2Context& c) {
    ran[2101] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F58A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F58C sts.l pr,@-r15
    c.r[15] -= 4;  // 0608F58E add #-4,r15
    c.r[14] = c.r[15];  // 0608F590 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608F592 mov.l r4,@r14
L_0608F594:
    c.r[1] = ld32(0x0608F75Cu);  // 0608F594 mov.l 0x0608F75C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608F596 mov.b @r1,r2
    c.r[1] = 0x1u;  // 0608F598 mov #1,r1
    c.r[1] &= c.r[2];  // 0608F59A and r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0608F59C extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F59E tst r2,r2
    if (!c.t) { goto L_0608F5A6; }  // 0608F5A0 bf 0x0608F5A6
    goto L_0608F5AA;  // 0608F5A2 bra 0x0608F5AA ; nop
L_0608F5A6:
    SH2_POLL(c); goto L_0608F594;  // 0608F5A6 bra 0x0608F594 ; nop
L_0608F5AA:
    c.r[1] = ld32(0x0608F75Cu);  // 0608F5AA mov.l 0x0608F75C,r1
    c.r[2] = 0x1u;  // 0608F5AC mov #1,r2
    st8(c.r[1], c.r[2]);  // 0608F5AE mov.b r2,@r1
    goto L_0608F5B8;  // 0608F5B0 bra 0x0608F5B8 ; nop
L_0608F5B8:
    ;  // 0608F5B8 nop
    c.r[1] = ld32(0x0608F760u);  // 0608F5BA mov.l 0x0608F760,r1
    c.r[2] = 0x7u;  // 0608F5BC mov #7,r2
    st8(c.r[1], c.r[2]);  // 0608F5BE mov.b r2,@r1
L_0608F5C0:
    c.r[1] = ld32(0x0608F75Cu);  // 0608F5C0 mov.l 0x0608F75C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608F5C2 mov.b @r1,r2
    c.r[1] = 0x1u;  // 0608F5C4 mov #1,r1
    c.r[1] &= c.r[2];  // 0608F5C6 and r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0608F5C8 extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F5CA tst r2,r2
    if (!c.t) { goto L_0608F5D2; }  // 0608F5CC bf 0x0608F5D2
    goto L_0608F5D6;  // 0608F5CE bra 0x0608F5D6 ; nop
L_0608F5D2:
    SH2_POLL(c); goto L_0608F5C0;  // 0608F5D2 bra 0x0608F5C0 ; nop
L_0608F5D6:
    goto L_0608F5DE;  // 0608F5D6 bra 0x0608F5DE ; nop
L_0608F5DE:
    goto L_0608F5E6;  // 0608F5DE bra 0x0608F5E6 ; nop
L_0608F5E6:
    goto L_0608F5EE;  // 0608F5E6 bra 0x0608F5EE ; nop
L_0608F5EE:
    c.r[1] = ld32(0x0608F764u);  // 0608F5EE mov.l 0x0608F764,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F750u);  // 0608F5F0 mov.w 0x0608F750,r2
    st16(c.r[1], c.r[2]);  // 0608F5F2 mov.w r2,@r1
    c.r[1] = ld32(0x0608F768u);  // 0608F5F4 mov.l 0x0608F768,r1
    c.r[2] = ld32(0x0608F76Cu);  // 0608F5F6 mov.l 0x0608F76C,r2
    c.r[5] = c.r[1];  // 0608F5F8 mov r1,r5
    c.r[4] = c.r[2];  // 0608F5FA mov r2,r4
    c.r[8] = ld32(0x0608F770u);  // 0608F5FC mov.l 0x0608F770,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F602u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F602u) return; }  // 0608F5FE jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 0608F602 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608F604 mov r2,r1
    c.r[2] += 4;  // 0608F606 add #4,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608F608 mov.w @r2,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0608F60A extu.w r3,r1
    c.r[3] = ld32(c.r[14]);  // 0608F60C mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608F60E mov.l @r3,r2
    c.r[3] = ld32(0x0608F76Cu);  // 0608F610 mov.l 0x0608F76C,r3
    c.r[6] = c.r[1];  // 0608F612 mov r1,r6
    c.r[5] = c.r[2];  // 0608F614 mov r2,r5
    c.r[4] = c.r[3];  // 0608F616 mov r3,r4
    c.r[8] = ld32(0x0608F774u);  // 0608F618 mov.l 0x0608F774,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F61Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F61Eu) return; }  // 0608F61A jsr @r8 ; nop
    c.r[1] = ld32(0x0608F778u);  // 0608F61E mov.l 0x0608F778,r1
    c.r[2] = ld32(0x0608F77Cu);  // 0608F620 mov.l 0x0608F77C,r2
    c.r[3] = ld32(c.r[2]);  // 0608F622 mov.l @r2,r3
    c.r[2] = ld32(0x0608F76Cu);  // 0608F624 mov.l 0x0608F76C,r2
    c.r[3] += c.r[2];  // 0608F626 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F628 mov.l r3,@r1
    c.r[1] = ld32(0x0608F780u);  // 0608F62A mov.l 0x0608F780,r1
    c.r[2] = ld32(0x0608F784u);  // 0608F62C mov.l 0x0608F784,r2
    c.r[3] = ld32(c.r[2]);  // 0608F62E mov.l @r2,r3
    c.r[2] = ld32(0x0608F76Cu);  // 0608F630 mov.l 0x0608F76C,r2
    c.r[3] += c.r[2];  // 0608F632 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F634 mov.l r3,@r1
    c.r[1] = ld32(0x0608F788u);  // 0608F636 mov.l 0x0608F788,r1
    c.r[2] = ld32(0x0608F78Cu);  // 0608F638 mov.l 0x0608F78C,r2
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608F63A mov.w @r2,r7
    c.r[3] = c.r[7] & 0xFFFFu;  // 0608F63C extu.w r7,r3
    c.r[2] = c.r[3];  // 0608F63E mov r3,r2
    c.r[2] <<= 16;  // 0608F640 shll16 r2
    c.r[3] = ld32(0x0608F790u);  // 0608F642 mov.l 0x0608F790,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608F644 mov.w @r3,r7
    c.r[3] = c.r[7] & 0xFFFFu;  // 0608F646 extu.w r7,r3
    c.r[2] |= c.r[3];  // 0608F648 or r3,r2
    c.r[3] = ld32(0x0608F76Cu);  // 0608F64A mov.l 0x0608F76C,r3
    c.r[2] += c.r[3];  // 0608F64C add r3,r2
    st32(c.r[1], c.r[2]);  // 0608F64E mov.l r2,@r1
    c.r[1] = ld32(0x0608F794u);  // 0608F650 mov.l 0x0608F794,r1
    c.r[2] = ld32(0x0608F780u);  // 0608F652 mov.l 0x0608F780,r2
    c.r[3] = ld32(c.r[2]);  // 0608F654 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608F656 mov.l r3,@r1
    c.r[1] = ld32(0x0608F798u);  // 0608F658 mov.l 0x0608F798,r1
    c.r[2] = ld32(0x0608F79Cu);  // 0608F65A mov.l 0x0608F79C,r2
    c.r[3] = ld32(c.r[2]);  // 0608F65C mov.l @r2,r3
    c.r[2] = ld32(0x0608F76Cu);  // 0608F65E mov.l 0x0608F76C,r2
    c.r[3] += c.r[2];  // 0608F660 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F662 mov.l r3,@r1
    c.r[1] = ld32(0x0608F7A0u);  // 0608F664 mov.l 0x0608F7A0,r1
    c.r[2] = ld32(0x0608F780u);  // 0608F666 mov.l 0x0608F780,r2
    c.r[3] = ld32(c.r[2]);  // 0608F668 mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F752u);  // 0608F66A mov.w 0x0608F752,r2
    c.r[3] += c.r[2];  // 0608F66C add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F66E mov.l r3,@r1
    c.r[1] = ld32(0x0608F7A4u);  // 0608F670 mov.l 0x0608F7A4,r1
    c.r[2] = ld32(0x0608F780u);  // 0608F672 mov.l 0x0608F780,r2
    c.r[3] = ld32(c.r[2]);  // 0608F674 mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F754u);  // 0608F676 mov.w 0x0608F754,r2
    c.r[3] += c.r[2];  // 0608F678 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F67A mov.l r3,@r1
    c.r[1] = ld32(0x0608F7A8u);  // 0608F67C mov.l 0x0608F7A8,r1
    c.r[2] = ld32(0x0608F780u);  // 0608F67E mov.l 0x0608F780,r2
    c.r[3] = ld32(c.r[2]);  // 0608F680 mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F756u);  // 0608F682 mov.w 0x0608F756,r2
    c.r[3] += c.r[2];  // 0608F684 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F686 mov.l r3,@r1
    c.r[1] = ld32(0x0608F7ACu);  // 0608F688 mov.l 0x0608F7AC,r1
    c.r[2] = ld32(0x0608F780u);  // 0608F68A mov.l 0x0608F780,r2
    c.r[3] = ld32(c.r[2]);  // 0608F68C mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F758u);  // 0608F68E mov.w 0x0608F758,r2
    c.r[3] += c.r[2];  // 0608F690 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F692 mov.l r3,@r1
    c.r[1] = ld32(0x0608F7B0u);  // 0608F694 mov.l 0x0608F7B0,r1
    c.r[2] = ld32(0x0608F780u);  // 0608F696 mov.l 0x0608F780,r2
    c.r[3] = ld32(c.r[2]);  // 0608F698 mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F75Au);  // 0608F69A mov.w 0x0608F75A,r2
    c.r[3] += c.r[2];  // 0608F69C add r2,r3
    st32(c.r[1], c.r[3]);  // 0608F69E mov.l r3,@r1
    c.r[2] = ld32(c.r[14]);  // 0608F6A0 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608F6A2 mov r2,r1
    c.r[2] += 12;  // 0608F6A4 add #12,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608F6A6 mov.w @r2,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0608F6A8 extu.w r3,r1
    c.r[2] = c.r[1];  // 0608F6AA mov r1,r2
    c.r[3] = c.r[2];  // 0608F6AC mov r2,r3
    c.r[3] += c.r[3];  // 0608F6AE add r3,r3
    c.r[1] = c.r[3];  // 0608F6B0 mov r3,r1
    c.r[1] += 4;  // 0608F6B2 add #4,r1
    c.r[3] = ld32(c.r[14]);  // 0608F6B4 mov.l @r14,r3
    c.r[2] = c.r[3];  // 0608F6B6 mov r3,r2
    c.r[3] += 12;  // 0608F6B8 add #12,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608F6BA mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0608F6BC extu.w r7,r2
    c.r[3] = c.r[2];  // 0608F6BE mov r2,r3
    c.r[2] = c.r[3];  // 0608F6C0 mov r3,r2
    c.r[2] += c.r[2];  // 0608F6C2 add r2,r2
    c.r[3] = c.r[2];  // 0608F6C4 mov r2,r3
    c.t = (int32_t)c.r[3] >= 0;  // 0608F6C6 cmp/pz r3
    if (c.t) { goto L_0608F6CC; }  // 0608F6C8 bt 0x0608F6CC
    c.r[3] += 3;  // 0608F6CA add #3,r3
L_0608F6CC:
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0608F6CC shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0608F6CE shar r3
    c.r[7] = c.r[3];  // 0608F6D0 mov r3,r7
    c.r[3] = c.r[7];  // 0608F6D2 mov r7,r3
    c.r[7] = c.r[3];  // 0608F6D4 mov r3,r7
    c.r[7] <<= 2;  // 0608F6D6 shll2 r7
    c.r[2] -= c.r[7];  // 0608F6D8 sub r7,r2
    c.r[1] -= c.r[2];  // 0608F6DA sub r2,r1
    c.r[3] = ld32(c.r[14]);  // 0608F6DC mov.l @r14,r3
    c.r[2] = ld32(c.r[3] + 8);  // 0608F6DE mov.l @(8,r3),r2
    c.r[3] = ld32(0x0608F778u);  // 0608F6E0 mov.l 0x0608F778,r3
    c.r[7] = ld32(c.r[3]);  // 0608F6E2 mov.l @r3,r7
    c.r[3] = c.r[7];  // 0608F6E4 mov r7,r3
    c.r[3] += 8;  // 0608F6E6 add #8,r3
    c.r[7] = ld32(c.r[3]);  // 0608F6E8 mov.l @r3,r7
    c.r[6] = ld32(0x0608F76Cu);  // 0608F6EA mov.l 0x0608F76C,r6
    c.r[3] = c.r[7];  // 0608F6EC mov r7,r3
    c.r[3] += c.r[6];  // 0608F6EE add r6,r3
    c.r[6] = c.r[1];  // 0608F6F0 mov r1,r6
    c.r[5] = c.r[2];  // 0608F6F2 mov r2,r5
    c.r[4] = c.r[3];  // 0608F6F4 mov r3,r4
    c.r[8] = ld32(0x0608F774u);  // 0608F6F6 mov.l 0x0608F774,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608F6FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F6FCu) return; }  // 0608F6F8 jsr @r8 ; nop
    c.r[1] = ld32(0x0608F7B4u);  // 0608F6FC mov.l 0x0608F7B4,r1
    c.r[2] = 0x0u;  // 0608F6FE mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608F700 mov.l r2,@r1
L_0608F702:
    c.r[1] = ld32(0x0608F75Cu);  // 0608F702 mov.l 0x0608F75C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608F704 mov.b @r1,r2
    c.r[1] = 0x1u;  // 0608F706 mov #1,r1
    c.r[1] &= c.r[2];  // 0608F708 and r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0608F70A extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F70C tst r2,r2
    if (!c.t) { goto L_0608F714; }  // 0608F70E bf 0x0608F714
    goto L_0608F718;  // 0608F710 bra 0x0608F718 ; nop
L_0608F714:
    SH2_POLL(c); goto L_0608F702;  // 0608F714 bra 0x0608F702 ; nop
L_0608F718:
    c.r[1] = ld32(0x0608F75Cu);  // 0608F718 mov.l 0x0608F75C,r1
    c.r[2] = 0x1u;  // 0608F71A mov #1,r2
    st8(c.r[1], c.r[2]);  // 0608F71C mov.b r2,@r1
    goto L_0608F726;  // 0608F71E bra 0x0608F726 ; nop
L_0608F726:
    ;  // 0608F726 nop
    c.r[1] = ld32(0x0608F760u);  // 0608F728 mov.l 0x0608F760,r1
    c.r[2] = 0x6u;  // 0608F72A mov #6,r2
    st8(c.r[1], c.r[2]);  // 0608F72C mov.b r2,@r1
L_0608F72E:
    c.r[1] = ld32(0x0608F75Cu);  // 0608F72E mov.l 0x0608F75C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608F730 mov.b @r1,r2
    c.r[1] = 0x1u;  // 0608F732 mov #1,r1
    c.r[1] &= c.r[2];  // 0608F734 and r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0608F736 extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F738 tst r2,r2
    if (c.t) { goto L_0608F740; }  // 0608F73A bt 0x0608F740
    goto L_0608F744;  // 0608F73C bra 0x0608F744 ; nop
L_0608F740:
    goto L_0608F748;  // 0608F740 bra 0x0608F748 ; nop
L_0608F744:
    SH2_POLL(c); goto L_0608F72E;  // 0608F744 bra 0x0608F72E ; nop
L_0608F748:
    goto L_0608F7B8;  // 0608F748 bra 0x0608F7B8 ; nop
L_0608F7B8:
    goto L_0608F7C0;  // 0608F7B8 bra 0x0608F7C0 ; nop
L_0608F7C0:
    goto L_0608F7C8;  // 0608F7C0 bra 0x0608F7C8 ; nop
L_0608F7C8:
    c.r[14] += 4;  // 0608F7C8 add #4,r14
    c.r[15] = c.r[14];  // 0608F7CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F7CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F7CE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F7D0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F7D2 rts ; nop
}

void f_0608F7D8(SH2Context& c) {
    ran[2102] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F7D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F7DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608F7DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608F7DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608F7E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608F7E2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F7E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F7E6 sts.l pr,@-r15
    c.r[15] -= 28;  // 0608F7E8 add #-28,r15
    c.r[14] = c.r[15];  // 0608F7EA mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608F7EC mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608F7EE mov.l r5,@(4,r14)
    c.r[9] = c.r[6];  // 0608F7F0 mov r6,r9
    c.r[8] = c.r[7];  // 0608F7F2 mov r7,r8
    c.r[10] = c.r[14];  // 0608F7F4 mov r14,r10
    c.r[12] = c.r[14];  // 0608F7F6 mov r14,r12
    c.r[12] += 8;  // 0608F7F8 add #8,r12
    st16(c.r[12], c.r[9]);  // 0608F7FA mov.w r9,@r12
    c.r[11] = c.r[14];  // 0608F7FC mov r14,r11
    c.r[13] = c.r[14];  // 0608F7FE mov r14,r13
    c.r[13] += 10;  // 0608F800 add #10,r13
    st16(c.r[13], c.r[8]);  // 0608F802 mov.w r8,@r13
    c.r[1] = c.r[14];  // 0608F804 mov r14,r1
    c.r[2] = c.r[14];  // 0608F806 mov r14,r2
    c.r[2] += 10;  // 0608F808 add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608F80A mov.w @r2,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0608F80C extu.w r3,r1
    c.r[2] = c.r[14];  // 0608F80E mov r14,r2
    c.r[3] = c.r[14];  // 0608F810 mov r14,r3
    c.r[3] += 8;  // 0608F812 add #8,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608F814 mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0608F816 extu.w r7,r2
    c.r[3] = c.r[14];  // 0608F818 mov r14,r3
    c.r[3] += 16;  // 0608F81A add #16,r3
    c.r[4] = c.r[14];  // 0608F81C mov r14,r4
    c.r[4] += 12;  // 0608F81E add #12,r4
    c.r[7] = c.r[1];  // 0608F820 mov r1,r7
    c.r[6] = c.r[2];  // 0608F822 mov r2,r6
    c.r[5] = c.r[3];  // 0608F824 mov r3,r5
    c.r[0] = ld32(0x0608F868u);  // 0608F826 mov.l 0x0608F868,r0
    st32(c.r[14] + 20, c.r[0]);  // 0608F828 mov.l r0,@(20,r14)
    c.r[0] = ld32(c.r[14] + 20);  // 0608F82A mov.l @(20,r14),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608F830u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F830u) return; }  // 0608F82C jsr @r0 ; nop
    c.r[2] = ld32(c.r[14] + 4);  // 0608F830 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608F832 mov.l @(12,r14),r1
    c.r[6] = c.r[2];  // 0608F834 mov r2,r6
    c.r[5] = ld32(c.r[14]);  // 0608F836 mov.l @r14,r5
    c.r[4] = c.r[1];  // 0608F838 mov r1,r4
    c.r[0] = ld32(0x0608F86Cu);  // 0608F83A mov.l 0x0608F86C,r0
    st32(c.r[14] + 24, c.r[0]);  // 0608F83C mov.l r0,@(24,r14)
    c.r[0] = ld32(c.r[14] + 24);  // 0608F83E mov.l @(24,r14),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608F844u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F844u) return; }  // 0608F840 jsr @r0 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 0608F844 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608F846 mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608F848 mov.l @r2,r3
    c.r[2] = ld32(0x0608F870u);  // 0608F84A mov.l 0x0608F870,r2
    c.r[3] |= c.r[2];  // 0608F84C or r2,r3
    st32(c.r[1], c.r[3]);  // 0608F84E mov.l r3,@r1
    c.r[14] += 28;  // 0608F850 add #28,r14
    c.r[15] = c.r[14];  // 0608F852 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F854 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F856 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608F858 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608F85A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608F85C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608F85E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F860 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F862 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F864 rts ; nop
}

void f_0608F874(SH2Context& c) {
    ran[2103] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F874 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F876 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F878 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F87A sts.l pr,@-r15
    c.r[15] -= 4;  // 0608F87C add #-4,r15
    c.r[14] = c.r[15];  // 0608F87E mov r15,r14
    c.r[8] = c.r[4];  // 0608F880 mov r4,r8
    st8(c.r[14], c.r[8]);  // 0608F882 mov.b r8,@r14
    c.r[1] = ld32(0x0608F934u);  // 0608F884 mov.l 0x0608F934,r1
    c.r[2] = ld32(c.r[1]);  // 0608F886 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F888 tst r2,r2
    if (c.t) { goto L_0608F892; }  // 0608F88A bt 0x0608F892
    c.r[0] = 0x1u;  // 0608F88C mov #1,r0
    goto L_0608F920;  // 0608F88E bra 0x0608F920 ; nop
L_0608F892:
    c.r[1] = ld32(0x0608F934u);  // 0608F892 mov.l 0x0608F934,r1
    c.r[2] = 0x1u;  // 0608F894 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608F896 mov.l r2,@r1
    c.r[9] = ld32(0x0608F938u);  // 0608F898 mov.l 0x0608F938,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F89Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F89Eu) return; }  // 0608F89A jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608F89E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608F8A0 tst r1,r1
    if (!c.t) { goto L_0608F8B8; }  // 0608F8A2 bf 0x0608F8B8
    c.r[1] = ld32(0x0608F934u);  // 0608F8A4 mov.l 0x0608F934,r1
    c.r[2] = 0x0u;  // 0608F8A6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608F8A8 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608F8AA mov #1,r0
    goto L_0608F920;  // 0608F8AC bra 0x0608F920 ; nop
L_0608F8B8:
    c.r[1] = ld32(0x0608F93Cu);  // 0608F8B8 mov.l 0x0608F93C,r1
    c.r[2] = ld32(c.r[1]);  // 0608F8BA mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608F8BC mov r2,r1
    c.r[1] += 2;  // 0608F8BE add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608F8C0 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608F8C2 mov.b r2,@r1
    c.r[2] = ld32(0x0608F93Cu);  // 0608F8C4 mov.l 0x0608F93C,r2
    c.r[1] = ld32(c.r[2]);  // 0608F8C6 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F930u);  // 0608F8C8 mov.w 0x0608F930,r2
    st16(c.r[1], c.r[2]);  // 0608F8CA mov.w r2,@r1
    c.r[9] = ld32(0x0608F940u);  // 0608F8CC mov.l 0x0608F940,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F8D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F8D2u) return; }  // 0608F8CE jsr @r9 ; nop
    c.r[9] = ld32(0x0608F938u);  // 0608F8D2 mov.l 0x0608F938,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F8D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F8D8u) return; }  // 0608F8D4 jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608F8D8 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608F8DA tst r1,r1
    if (!c.t) { goto L_0608F8F2; }  // 0608F8DC bf 0x0608F8F2
    c.r[1] = ld32(0x0608F934u);  // 0608F8DE mov.l 0x0608F934,r1
    c.r[2] = 0x0u;  // 0608F8E0 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608F8E2 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608F8E4 mov #1,r0
    goto L_0608F920;  // 0608F8E6 bra 0x0608F920 ; nop
L_0608F8F2:
    c.r[1] = ld32(0x0608F93Cu);  // 0608F8F2 mov.l 0x0608F93C,r1
    c.r[2] = ld32(c.r[1]);  // 0608F8F4 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608F8F6 mov r2,r1
    c.r[1] += 2;  // 0608F8F8 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608F8FA mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608F8FC mov.b r2,@r1
    c.r[2] = ld32(0x0608F93Cu);  // 0608F8FE mov.l 0x0608F93C,r2
    c.r[1] = ld32(c.r[2]);  // 0608F900 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F930u);  // 0608F902 mov.w 0x0608F930,r2
    st16(c.r[1], c.r[2]);  // 0608F904 mov.w r2,@r1
    c.r[9] = ld32(0x0608F940u);  // 0608F906 mov.l 0x0608F940,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F90Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F90Cu) return; }  // 0608F908 jsr @r9 ; nop
    c.r[1] = ld32(0x0608F934u);  // 0608F90C mov.l 0x0608F934,r1
    c.r[2] = 0x0u;  // 0608F90E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608F910 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608F912 mov #0,r0
    goto L_0608F920;  // 0608F914 bra 0x0608F920 ; nop
L_0608F920:
    c.r[14] += 4;  // 0608F920 add #4,r14
    c.r[15] = c.r[14];  // 0608F922 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F924 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F926 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F928 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F92A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F92C rts ; nop
}

void f_0608F944(SH2Context& c) {
    ran[2104] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F944 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F946 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F948 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F94A sts.l pr,@-r15
    c.r[15] -= 4;  // 0608F94C add #-4,r15
    c.r[14] = c.r[15];  // 0608F94E mov r15,r14
    c.r[8] = c.r[4];  // 0608F950 mov r4,r8
    st8(c.r[14], c.r[8]);  // 0608F952 mov.b r8,@r14
    c.r[1] = ld32(0x0608F9C4u);  // 0608F954 mov.l 0x0608F9C4,r1
    c.r[2] = ld32(c.r[1]);  // 0608F956 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F958 tst r2,r2
    if (c.t) { goto L_0608F962; }  // 0608F95A bt 0x0608F962
    c.r[0] = 0x1u;  // 0608F95C mov #1,r0
    goto L_0608F9B0;  // 0608F95E bra 0x0608F9B0 ; nop
L_0608F962:
    c.r[1] = ld32(0x0608F9C4u);  // 0608F962 mov.l 0x0608F9C4,r1
    c.r[2] = 0x1u;  // 0608F964 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608F966 mov.l r2,@r1
    c.r[9] = ld32(0x0608F9C8u);  // 0608F968 mov.l 0x0608F9C8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F96Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F96Eu) return; }  // 0608F96A jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608F96E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608F970 tst r1,r1
    if (!c.t) { goto L_0608F988; }  // 0608F972 bf 0x0608F988
    c.r[1] = ld32(0x0608F9C4u);  // 0608F974 mov.l 0x0608F9C4,r1
    c.r[2] = 0x0u;  // 0608F976 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608F978 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608F97A mov #1,r0
    goto L_0608F9B0;  // 0608F97C bra 0x0608F9B0 ; nop
L_0608F988:
    c.r[1] = ld32(0x0608F9CCu);  // 0608F988 mov.l 0x0608F9CC,r1
    c.r[2] = ld32(c.r[1]);  // 0608F98A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608F98C mov r2,r1
    c.r[1] += 2;  // 0608F98E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608F990 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608F992 mov.b r2,@r1
    c.r[2] = ld32(0x0608F9CCu);  // 0608F994 mov.l 0x0608F9CC,r2
    c.r[1] = ld32(c.r[2]);  // 0608F996 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608F9C0u);  // 0608F998 mov.w 0x0608F9C0,r2
    st16(c.r[1], c.r[2]);  // 0608F99A mov.w r2,@r1
    c.r[1] = ld32(0x0608F9C4u);  // 0608F99C mov.l 0x0608F9C4,r1
    c.r[2] = 0x0u;  // 0608F99E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608F9A0 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608F9A2 mov #0,r0
    goto L_0608F9B0;  // 0608F9A4 bra 0x0608F9B0 ; nop
L_0608F9B0:
    c.r[14] += 4;  // 0608F9B0 add #4,r14
    c.r[15] = c.r[14];  // 0608F9B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608F9B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608F9B6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608F9B8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608F9BA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608F9BC rts ; nop
}

void f_0608F9D0(SH2Context& c) {
    ran[2105] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608F9D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608F9D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608F9D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608F9D6 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608F9D8 add #-4,r15
    c.r[14] = c.r[15];  // 0608F9DA mov r15,r14
    c.r[8] = c.r[4];  // 0608F9DC mov r4,r8
    st8(c.r[14], c.r[8]);  // 0608F9DE mov.b r8,@r14
    c.r[1] = ld32(0x0608FA50u);  // 0608F9E0 mov.l 0x0608FA50,r1
    c.r[2] = ld32(c.r[1]);  // 0608F9E2 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608F9E4 tst r2,r2
    if (c.t) { goto L_0608F9EE; }  // 0608F9E6 bt 0x0608F9EE
    c.r[0] = 0x1u;  // 0608F9E8 mov #1,r0
    goto L_0608FA3C;  // 0608F9EA bra 0x0608FA3C ; nop
L_0608F9EE:
    c.r[1] = ld32(0x0608FA50u);  // 0608F9EE mov.l 0x0608FA50,r1
    c.r[2] = 0x1u;  // 0608F9F0 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608F9F2 mov.l r2,@r1
    c.r[9] = ld32(0x0608FA54u);  // 0608F9F4 mov.l 0x0608FA54,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608F9FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608F9FAu) return; }  // 0608F9F6 jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608F9FA extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608F9FC tst r1,r1
    if (!c.t) { goto L_0608FA14; }  // 0608F9FE bf 0x0608FA14
    c.r[1] = ld32(0x0608FA50u);  // 0608FA00 mov.l 0x0608FA50,r1
    c.r[2] = 0x0u;  // 0608FA02 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FA04 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FA06 mov #1,r0
    goto L_0608FA3C;  // 0608FA08 bra 0x0608FA3C ; nop
L_0608FA14:
    c.r[1] = ld32(0x0608FA58u);  // 0608FA14 mov.l 0x0608FA58,r1
    c.r[2] = ld32(c.r[1]);  // 0608FA16 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FA18 mov r2,r1
    c.r[1] += 2;  // 0608FA1A add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608FA1C mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608FA1E mov.b r2,@r1
    c.r[2] = ld32(0x0608FA58u);  // 0608FA20 mov.l 0x0608FA58,r2
    c.r[1] = ld32(c.r[2]);  // 0608FA22 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FA4Cu);  // 0608FA24 mov.w 0x0608FA4C,r2
    st16(c.r[1], c.r[2]);  // 0608FA26 mov.w r2,@r1
    c.r[1] = ld32(0x0608FA50u);  // 0608FA28 mov.l 0x0608FA50,r1
    c.r[2] = 0x0u;  // 0608FA2A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FA2C mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FA2E mov #0,r0
    goto L_0608FA3C;  // 0608FA30 bra 0x0608FA3C ; nop
L_0608FA3C:
    c.r[14] += 4;  // 0608FA3C add #4,r14
    c.r[15] = c.r[14];  // 0608FA3E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FA40 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FA42 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608FA44 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FA46 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FA48 rts ; nop
}

void f_0608FA5C(SH2Context& c) {
    ran[2106] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FA5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608FA5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608FA60 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608FA62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608FA64 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FA66 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FA68 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608FA6A add #-4,r15
    c.r[14] = c.r[15];  // 0608FA6C mov r15,r14
    c.r[8] = c.r[4];  // 0608FA6E mov r4,r8
    c.r[9] = c.r[5];  // 0608FA70 mov r5,r9
    st8(c.r[14], c.r[8]);  // 0608FA72 mov.b r8,@r14
    c.r[10] = c.r[14];  // 0608FA74 mov r14,r10
    c.r[11] = c.r[14];  // 0608FA76 mov r14,r11
    c.r[11] += 1;  // 0608FA78 add #1,r11
    st8(c.r[11], c.r[9]);  // 0608FA7A mov.b r9,@r11
    c.r[1] = ld32(0x0608FB04u);  // 0608FA7C mov.l 0x0608FB04,r1
    c.r[2] = ld32(c.r[1]);  // 0608FA7E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FA80 tst r2,r2
    if (c.t) { goto L_0608FA8A; }  // 0608FA82 bt 0x0608FA8A
    c.r[0] = 0x1u;  // 0608FA84 mov #1,r0
    goto L_0608FAEA;  // 0608FA86 bra 0x0608FAEA ; nop
L_0608FA8A:
    c.r[1] = ld32(0x0608FB04u);  // 0608FA8A mov.l 0x0608FB04,r1
    c.r[2] = 0x1u;  // 0608FA8C mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FA8E mov.l r2,@r1
    c.r[12] = ld32(0x0608FB08u);  // 0608FA90 mov.l 0x0608FB08,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0608FA96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FA96u) return; }  // 0608FA92 jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FA96 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FA98 tst r1,r1
    if (!c.t) { goto L_0608FAB0; }  // 0608FA9A bf 0x0608FAB0
    c.r[1] = ld32(0x0608FB04u);  // 0608FA9C mov.l 0x0608FB04,r1
    c.r[2] = 0x0u;  // 0608FA9E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FAA0 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FAA2 mov #1,r0
    goto L_0608FAEA;  // 0608FAA4 bra 0x0608FAEA ; nop
L_0608FAB0:
    c.r[1] = ld32(0x0608FB0Cu);  // 0608FAB0 mov.l 0x0608FB0C,r1
    c.r[2] = ld32(c.r[1]);  // 0608FAB2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FAB4 mov r2,r1
    c.r[1] += 2;  // 0608FAB6 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608FAB8 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608FABA mov.b r2,@r1
    c.r[1] = ld32(0x0608FB0Cu);  // 0608FABC mov.l 0x0608FB0C,r1
    c.r[2] = ld32(c.r[1]);  // 0608FABE mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FAC0 mov r2,r1
    c.r[1] += 3;  // 0608FAC2 add #3,r1
    c.r[2] = c.r[14];  // 0608FAC4 mov r14,r2
    c.r[3] = c.r[14];  // 0608FAC6 mov r14,r3
    c.r[3] += 1;  // 0608FAC8 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608FACA mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608FACC mov.b r2,@r1
    c.r[2] = ld32(0x0608FB0Cu);  // 0608FACE mov.l 0x0608FB0C,r2
    c.r[1] = ld32(c.r[2]);  // 0608FAD0 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FB00u);  // 0608FAD2 mov.w 0x0608FB00,r2
    st16(c.r[1], c.r[2]);  // 0608FAD4 mov.w r2,@r1
    c.r[1] = ld32(0x0608FB04u);  // 0608FAD6 mov.l 0x0608FB04,r1
    c.r[2] = 0x0u;  // 0608FAD8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FADA mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FADC mov #0,r0
    goto L_0608FAEA;  // 0608FADE bra 0x0608FAEA ; nop
L_0608FAEA:
    c.r[14] += 4;  // 0608FAEA add #4,r14
    c.r[15] = c.r[14];  // 0608FAEC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FAEE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FAF0 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608FAF2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608FAF4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608FAF6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608FAF8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FAFA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FAFC rts ; nop
}

void f_0608FB10(SH2Context& c) {
    ran[2107] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FB10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608FB12 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608FB14 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608FB16 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608FB18 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608FB1A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FB1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FB1E sts.l pr,@-r15
    c.r[15] -= 16;  // 0608FB20 add #-16,r15
    c.r[14] = c.r[15];  // 0608FB22 mov r15,r14
    c.r[9] = c.r[4];  // 0608FB24 mov r4,r9
    c.r[10] = c.r[5];  // 0608FB26 mov r5,r10
    c.r[8] = c.r[6];  // 0608FB28 mov r6,r8
    st8(c.r[14], c.r[9]);  // 0608FB2A mov.b r9,@r14
    c.r[11] = c.r[14];  // 0608FB2C mov r14,r11
    c.r[13] = c.r[14];  // 0608FB2E mov r14,r13
    c.r[13] += 1;  // 0608FB30 add #1,r13
    st8(c.r[13], c.r[10]);  // 0608FB32 mov.b r10,@r13
    c.r[12] = c.r[14];  // 0608FB34 mov r14,r12
    c.r[7] = c.r[14];  // 0608FB36 mov r14,r7
    c.r[7] += 2;  // 0608FB38 add #2,r7
    st32(c.r[14] + 4, c.r[7]);  // 0608FB3A mov.l r7,@(4,r14)
    c.r[7] = ld32(c.r[14] + 4);  // 0608FB3C mov.l @(4,r14),r7
    st8(c.r[7], c.r[8]);  // 0608FB3E mov.b r8,@r7
    c.r[1] = ld32(0x0608FBF0u);  // 0608FB40 mov.l 0x0608FBF0,r1
    c.r[2] = ld32(c.r[1]);  // 0608FB42 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FB44 tst r2,r2
    if (c.t) { goto L_0608FB4E; }  // 0608FB46 bt 0x0608FB4E
    c.r[0] = 0x1u;  // 0608FB48 mov #1,r0
    goto L_0608FBD4;  // 0608FB4A bra 0x0608FBD4 ; nop
L_0608FB4E:
    c.r[1] = ld32(0x0608FBF0u);  // 0608FB4E mov.l 0x0608FBF0,r1
    c.r[2] = 0x1u;  // 0608FB50 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FB52 mov.l r2,@r1
    c.r[7] = ld32(0x0608FBF4u);  // 0608FB54 mov.l 0x0608FBF4,r7
    st32(c.r[14] + 8, c.r[7]);  // 0608FB56 mov.l r7,@(8,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 0608FB58 mov.l @(8,r14),r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608FB5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FB5Eu) return; }  // 0608FB5A jsr @r7 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FB5E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FB60 tst r1,r1
    if (!c.t) { goto L_0608FB78; }  // 0608FB62 bf 0x0608FB78
    c.r[1] = ld32(0x0608FBF0u);  // 0608FB64 mov.l 0x0608FBF0,r1
    c.r[2] = 0x0u;  // 0608FB66 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FB68 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FB6A mov #1,r0
    goto L_0608FBD4;  // 0608FB6C bra 0x0608FBD4 ; nop
L_0608FB78:
    c.r[1] = ld32(0x0608FBF8u);  // 0608FB78 mov.l 0x0608FBF8,r1
    c.r[2] = ld32(c.r[1]);  // 0608FB7A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FB7C mov r2,r1
    c.r[1] += 2;  // 0608FB7E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608FB80 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608FB82 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0608FB84 mov r14,r1
    c.r[2] = c.r[14];  // 0608FB86 mov r14,r2
    c.r[2] += 2;  // 0608FB88 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608FB8A mov.b @r2,r1
    c.r[4] = c.r[1];  // 0608FB8C mov r1,r4
    c.r[7] = ld32(0x0608FBFCu);  // 0608FB8E mov.l 0x0608FBFC,r7
    st32(c.r[14] + 12, c.r[7]);  // 0608FB90 mov.l r7,@(12,r14)
    c.r[7] = ld32(c.r[14] + 12);  // 0608FB92 mov.l @(12,r14),r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608FB98u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FB98u) return; }  // 0608FB94 jsr @r7 ; nop
    c.r[1] = ld32(0x0608FBF8u);  // 0608FB98 mov.l 0x0608FBF8,r1
    c.r[2] = ld32(c.r[1]);  // 0608FB9A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FB9C mov r2,r1
    c.r[1] += 3;  // 0608FB9E add #3,r1
    c.r[2] = c.r[14];  // 0608FBA0 mov r14,r2
    c.r[3] = c.r[14];  // 0608FBA2 mov r14,r3
    c.r[3] += 1;  // 0608FBA4 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608FBA6 mov.b @r3,r2
    c.r[3] = c.r[2];  // 0608FBA8 mov r2,r3
    c.r[3] <<= 2;  // 0608FBAA shll2 r3
    c.r[3] += c.r[3];  // 0608FBAC add r3,r3
    c.r[3] <<= 2;  // 0608FBAE shll2 r3
    c.r[2] = c.r[0];  // 0608FBB0 mov r0,r2
    c.r[3] = c.r[3];  // 0608FBB2 mov r3,r3
    c.r[2] |= c.r[3];  // 0608FBB4 or r3,r2
    st8(c.r[1], c.r[2]);  // 0608FBB6 mov.b r2,@r1
    c.r[2] = ld32(0x0608FBF8u);  // 0608FBB8 mov.l 0x0608FBF8,r2
    c.r[1] = ld32(c.r[2]);  // 0608FBBA mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FBECu);  // 0608FBBC mov.w 0x0608FBEC,r2
    st16(c.r[1], c.r[2]);  // 0608FBBE mov.w r2,@r1
    c.r[1] = ld32(0x0608FBF0u);  // 0608FBC0 mov.l 0x0608FBF0,r1
    c.r[2] = 0x0u;  // 0608FBC2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FBC4 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FBC6 mov #0,r0
    goto L_0608FBD4;  // 0608FBC8 bra 0x0608FBD4 ; nop
L_0608FBD4:
    c.r[14] += 16;  // 0608FBD4 add #16,r14
    c.r[15] = c.r[14];  // 0608FBD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FBD8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBDA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBDC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBDE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBE4 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FBE6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FBE8 rts ; nop
}

void f_0608FC00(SH2Context& c) {
    ran[2108] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FC00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608FC02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608FC04 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608FC06 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FC08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FC0A sts.l pr,@-r15
    c.r[15] -= 8;  // 0608FC0C add #-8,r15
    c.r[14] = c.r[15];  // 0608FC0E mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608FC10 mov.l r4,@r14
    c.r[9] = c.r[5];  // 0608FC12 mov r5,r9
    c.r[8] = c.r[14];  // 0608FC14 mov r14,r8
    c.r[10] = c.r[14];  // 0608FC16 mov r14,r10
    c.r[10] += 4;  // 0608FC18 add #4,r10
    st8(c.r[10], c.r[9]);  // 0608FC1A mov.b r9,@r10
    c.r[1] = ld32(0x0608FCB4u);  // 0608FC1C mov.l 0x0608FCB4,r1
    c.r[2] = ld32(c.r[1]);  // 0608FC1E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FC20 tst r2,r2
    if (c.t) { goto L_0608FC2A; }  // 0608FC22 bt 0x0608FC2A
    c.r[0] = 0x1u;  // 0608FC24 mov #1,r0
    goto L_0608FC9C;  // 0608FC26 bra 0x0608FC9C ; nop
L_0608FC2A:
    c.r[1] = ld32(0x0608FCB4u);  // 0608FC2A mov.l 0x0608FCB4,r1
    c.r[2] = 0x1u;  // 0608FC2C mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FC2E mov.l r2,@r1
    c.r[11] = ld32(0x0608FCB8u);  // 0608FC30 mov.l 0x0608FCB8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0608FC36u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FC36u) return; }  // 0608FC32 jsr @r11 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FC36 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FC38 tst r1,r1
    if (!c.t) { goto L_0608FC50; }  // 0608FC3A bf 0x0608FC50
    c.r[1] = ld32(0x0608FCB4u);  // 0608FC3C mov.l 0x0608FCB4,r1
    c.r[2] = 0x0u;  // 0608FC3E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FC40 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FC42 mov #1,r0
    goto L_0608FC9C;  // 0608FC44 bra 0x0608FC9C ; nop
L_0608FC50:
    c.r[1] = ld32(0x0608FCBCu);  // 0608FC50 mov.l 0x0608FCBC,r1
    c.r[2] = 0x0u;  // 0608FC52 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0608FC54 mov.w r2,@r1
    c.r[1] = ld32(0x0608FCC0u);  // 0608FC56 mov.l 0x0608FCC0,r1
    c.r[2] = ld32(c.r[1]);  // 0608FC58 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FC5A mov r2,r1
    c.r[1] += 2;  // 0608FC5C add #2,r1
    c.r[2] = c.r[14];  // 0608FC5E mov r14,r2
    c.r[3] = c.r[14];  // 0608FC60 mov r14,r3
    c.r[3] += 4;  // 0608FC62 add #4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608FC64 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608FC66 mov.b r2,@r1
    c.r[2] = ld32(0x0608FCC0u);  // 0608FC68 mov.l 0x0608FCC0,r2
    c.r[1] = ld32(c.r[2]);  // 0608FC6A mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FCB0u);  // 0608FC6C mov.w 0x0608FCB0,r2
    st16(c.r[1], c.r[2]);  // 0608FC6E mov.w r2,@r1
L_0608FC70:
    c.r[1] = ld32(c.r[14]);  // 0608FC70 mov.l @r14,r1
    c.r[2] = ld32(0x0608FCBCu);  // 0608FC72 mov.l 0x0608FCBC,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608FC74 mov.w @r2,r3
    st16(c.r[1], c.r[3]);  // 0608FC76 mov.w r3,@r1
    c.r[1] = c.r[3] & 0xFFFFu;  // 0608FC78 extu.w r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FC7A tst r1,r1
    if (c.t) { goto L_0608FC82; }  // 0608FC7C bt 0x0608FC82
    goto L_0608FC86;  // 0608FC7E bra 0x0608FC86 ; nop
L_0608FC82:
    SH2_POLL(c); goto L_0608FC70;  // 0608FC82 bra 0x0608FC70 ; nop
L_0608FC86:
    ;  // 0608FC86 nop
    c.r[1] = ld32(0x0608FCB4u);  // 0608FC88 mov.l 0x0608FCB4,r1
    c.r[2] = 0x0u;  // 0608FC8A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FC8C mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FC8E mov #0,r0
    goto L_0608FC9C;  // 0608FC90 bra 0x0608FC9C ; nop
L_0608FC9C:
    c.r[14] += 8;  // 0608FC9C add #8,r14
    c.r[15] = c.r[14];  // 0608FC9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FCA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FCA2 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608FCA4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608FCA6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608FCA8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FCAA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FCAC rts ; nop
}

void f_0608FCC4(SH2Context& c) {
    ran[2109] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FCC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FCC6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FCC8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608FCCA mov r15,r14
    c.r[1] = ld32(0x0608FD68u);  // 0608FCCC mov.l 0x0608FD68,r1
    c.r[2] = ld32(c.r[1]);  // 0608FCCE mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FCD0 tst r2,r2
    if (c.t) { goto L_0608FCDA; }  // 0608FCD2 bt 0x0608FCDA
    c.r[0] = 0x1u;  // 0608FCD4 mov #1,r0
    goto L_0608FD58;  // 0608FCD6 bra 0x0608FD58 ; nop
L_0608FCDA:
    c.r[1] = ld32(0x0608FD68u);  // 0608FCDA mov.l 0x0608FD68,r1
    c.r[2] = 0x1u;  // 0608FCDC mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FCDE mov.l r2,@r1
    c.r[8] = ld32(0x0608FD6Cu);  // 0608FCE0 mov.l 0x0608FD6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608FCE6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FCE6u) return; }  // 0608FCE2 jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FCE6 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FCE8 tst r1,r1
    if (!c.t) { goto L_0608FD00; }  // 0608FCEA bf 0x0608FD00
    c.r[1] = ld32(0x0608FD68u);  // 0608FCEC mov.l 0x0608FD68,r1
    c.r[2] = 0x0u;  // 0608FCEE mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FCF0 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FCF2 mov #1,r0
    goto L_0608FD58;  // 0608FCF4 bra 0x0608FD58 ; nop
L_0608FD00:
    c.r[1] = ld32(0x0608FD70u);  // 0608FD00 mov.l 0x0608FD70,r1
    c.r[2] = ld32(c.r[1]);  // 0608FD02 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FD04 mov r2,r1
    c.r[1] += 2;  // 0608FD06 add #2,r1
    c.r[2] = 0x0u;  // 0608FD08 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FD0A mov.b r2,@r1
    c.r[1] = ld32(0x0608FD70u);  // 0608FD0C mov.l 0x0608FD70,r1
    c.r[2] = ld32(c.r[1]);  // 0608FD0E mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FD10 mov r2,r1
    c.r[1] += 3;  // 0608FD12 add #3,r1
    c.r[2] = 0x0u;  // 0608FD14 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FD16 mov.b r2,@r1
    c.r[1] = ld32(0x0608FD70u);  // 0608FD18 mov.l 0x0608FD70,r1
    c.r[2] = ld32(c.r[1]);  // 0608FD1A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FD1C mov r2,r1
    c.r[1] += 4;  // 0608FD1E add #4,r1
    c.r[2] = 0x0u;  // 0608FD20 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FD22 mov.b r2,@r1
    c.r[1] = ld32(0x0608FD70u);  // 0608FD24 mov.l 0x0608FD70,r1
    c.r[2] = ld32(c.r[1]);  // 0608FD26 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FD28 mov r2,r1
    c.r[1] += 5;  // 0608FD2A add #5,r1
    c.r[2] = 0x1u;  // 0608FD2C mov #1,r2
    st8(c.r[1], c.r[2]);  // 0608FD2E mov.b r2,@r1
    c.r[1] = ld32(0x0608FD70u);  // 0608FD30 mov.l 0x0608FD70,r1
    c.r[2] = ld32(c.r[1]);  // 0608FD32 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FD34 mov r2,r1
    c.r[1] += 6;  // 0608FD36 add #6,r1
    c.r[2] = 0x0u;  // 0608FD38 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FD3A mov.b r2,@r1
    c.r[2] = ld32(0x0608FD70u);  // 0608FD3C mov.l 0x0608FD70,r2
    c.r[1] = ld32(c.r[2]);  // 0608FD3E mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FD64u);  // 0608FD40 mov.w 0x0608FD64,r2
    st16(c.r[1], c.r[2]);  // 0608FD42 mov.w r2,@r1
    c.r[1] = ld32(0x0608FD68u);  // 0608FD44 mov.l 0x0608FD68,r1
    c.r[2] = 0x0u;  // 0608FD46 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FD48 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FD4A mov #0,r0
    goto L_0608FD58;  // 0608FD4C bra 0x0608FD58 ; nop
L_0608FD58:
    c.r[15] = c.r[14];  // 0608FD58 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FD5A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FD5C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FD5E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FD60 rts ; nop
}

void f_0608FD74(SH2Context& c) {
    ran[2110] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FD74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FD76 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FD78 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608FD7A mov r15,r14
    c.r[1] = ld32(0x0608FE18u);  // 0608FD7C mov.l 0x0608FE18,r1
    c.r[2] = ld32(c.r[1]);  // 0608FD7E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FD80 tst r2,r2
    if (c.t) { goto L_0608FD8A; }  // 0608FD82 bt 0x0608FD8A
    c.r[0] = 0x1u;  // 0608FD84 mov #1,r0
    goto L_0608FE08;  // 0608FD86 bra 0x0608FE08 ; nop
L_0608FD8A:
    c.r[1] = ld32(0x0608FE18u);  // 0608FD8A mov.l 0x0608FE18,r1
    c.r[2] = 0x1u;  // 0608FD8C mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FD8E mov.l r2,@r1
    c.r[8] = ld32(0x0608FE1Cu);  // 0608FD90 mov.l 0x0608FE1C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608FD96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FD96u) return; }  // 0608FD92 jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FD96 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FD98 tst r1,r1
    if (!c.t) { goto L_0608FDB0; }  // 0608FD9A bf 0x0608FDB0
    c.r[1] = ld32(0x0608FE18u);  // 0608FD9C mov.l 0x0608FE18,r1
    c.r[2] = 0x0u;  // 0608FD9E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FDA0 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FDA2 mov #1,r0
    goto L_0608FE08;  // 0608FDA4 bra 0x0608FE08 ; nop
L_0608FDB0:
    c.r[1] = ld32(0x0608FE20u);  // 0608FDB0 mov.l 0x0608FE20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FDB2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FDB4 mov r2,r1
    c.r[1] += 2;  // 0608FDB6 add #2,r1
    c.r[2] = 0x1u;  // 0608FDB8 mov #1,r2
    st8(c.r[1], c.r[2]);  // 0608FDBA mov.b r2,@r1
    c.r[1] = ld32(0x0608FE20u);  // 0608FDBC mov.l 0x0608FE20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FDBE mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FDC0 mov r2,r1
    c.r[1] += 3;  // 0608FDC2 add #3,r1
    c.r[2] = 0x0u;  // 0608FDC4 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FDC6 mov.b r2,@r1
    c.r[1] = ld32(0x0608FE20u);  // 0608FDC8 mov.l 0x0608FE20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FDCA mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FDCC mov r2,r1
    c.r[1] += 4;  // 0608FDCE add #4,r1
    c.r[2] = 0x0u;  // 0608FDD0 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FDD2 mov.b r2,@r1
    c.r[1] = ld32(0x0608FE20u);  // 0608FDD4 mov.l 0x0608FE20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FDD6 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FDD8 mov r2,r1
    c.r[1] += 5;  // 0608FDDA add #5,r1
    c.r[2] = 0x0u;  // 0608FDDC mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FDDE mov.b r2,@r1
    c.r[1] = ld32(0x0608FE20u);  // 0608FDE0 mov.l 0x0608FE20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FDE2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FDE4 mov r2,r1
    c.r[1] += 6;  // 0608FDE6 add #6,r1
    c.r[2] = 0x0u;  // 0608FDE8 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0608FDEA mov.b r2,@r1
    c.r[2] = ld32(0x0608FE20u);  // 0608FDEC mov.l 0x0608FE20,r2
    c.r[1] = ld32(c.r[2]);  // 0608FDEE mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FE14u);  // 0608FDF0 mov.w 0x0608FE14,r2
    st16(c.r[1], c.r[2]);  // 0608FDF2 mov.w r2,@r1
    c.r[1] = ld32(0x0608FE18u);  // 0608FDF4 mov.l 0x0608FE18,r1
    c.r[2] = 0x0u;  // 0608FDF6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FDF8 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FDFA mov #0,r0
    goto L_0608FE08;  // 0608FDFC bra 0x0608FE08 ; nop
L_0608FE08:
    c.r[15] = c.r[14];  // 0608FE08 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FE0A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FE0C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FE0E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FE10 rts ; nop
}

void f_0608FE24(SH2Context& c) {
    ran[2111] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FE24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608FE26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608FE28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608FE2A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608FE2C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608FE2E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FE30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FE32 sts.l pr,@-r15
    c.r[15] -= 28;  // 0608FE34 add #-28,r15
    c.r[14] = c.r[15];  // 0608FE36 mov r15,r14
    c.r[10] = c.r[4];  // 0608FE38 mov r4,r10
    c.r[11] = c.r[5];  // 0608FE3A mov r5,r11
    c.r[9] = c.r[6];  // 0608FE3C mov r6,r9
    c.r[8] = c.r[7];  // 0608FE3E mov r7,r8
    st8(c.r[14], c.r[10]);  // 0608FE40 mov.b r10,@r14
    st32(c.r[14] + 24, c.r[14]);  // 0608FE42 mov.l r14,@(24,r14)
    c.r[12] = c.r[14];  // 0608FE44 mov r14,r12
    c.r[12] += 1;  // 0608FE46 add #1,r12
    st32(c.r[14] + 4, c.r[12]);  // 0608FE48 mov.l r12,@(4,r14)
    c.r[12] = ld32(c.r[14] + 4);  // 0608FE4A mov.l @(4,r14),r12
    st8(c.r[12], c.r[11]);  // 0608FE4C mov.b r11,@r12
    c.r[13] = c.r[14];  // 0608FE4E mov r14,r13
    c.r[12] = c.r[14];  // 0608FE50 mov r14,r12
    c.r[12] += 2;  // 0608FE52 add #2,r12
    st32(c.r[14] + 8, c.r[12]);  // 0608FE54 mov.l r12,@(8,r14)
    c.r[12] = ld32(c.r[14] + 8);  // 0608FE56 mov.l @(8,r14),r12
    st8(c.r[12], c.r[9]);  // 0608FE58 mov.b r9,@r12
    st32(c.r[14] + 12, c.r[14]);  // 0608FE5A mov.l r14,@(12,r14)
    c.r[12] = c.r[14];  // 0608FE5C mov r14,r12
    c.r[12] += 3;  // 0608FE5E add #3,r12
    st32(c.r[14] + 16, c.r[12]);  // 0608FE60 mov.l r12,@(16,r14)
    c.r[12] = ld32(c.r[14] + 16);  // 0608FE62 mov.l @(16,r14),r12
    st8(c.r[12], c.r[8]);  // 0608FE64 mov.b r8,@r12
    c.r[1] = ld32(0x0608FF18u);  // 0608FE66 mov.l 0x0608FF18,r1
    c.r[2] = ld32(c.r[1]);  // 0608FE68 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FE6A tst r2,r2
    if (c.t) { goto L_0608FE74; }  // 0608FE6C bt 0x0608FE74
    c.r[0] = 0x1u;  // 0608FE6E mov #1,r0
    goto L_0608FEFC;  // 0608FE70 bra 0x0608FEFC ; nop
L_0608FE74:
    c.r[1] = ld32(0x0608FF18u);  // 0608FE74 mov.l 0x0608FF18,r1
    c.r[2] = 0x1u;  // 0608FE76 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FE78 mov.l r2,@r1
    c.r[12] = ld32(0x0608FF1Cu);  // 0608FE7A mov.l 0x0608FF1C,r12
    st32(c.r[14] + 20, c.r[12]);  // 0608FE7C mov.l r12,@(20,r14)
    c.r[12] = ld32(c.r[14] + 20);  // 0608FE7E mov.l @(20,r14),r12
    { const uint32_t x = c.r[12]; c.pr = 0x0608FE84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FE84u) return; }  // 0608FE80 jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FE84 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FE86 tst r1,r1
    if (!c.t) { goto L_0608FE9E; }  // 0608FE88 bf 0x0608FE9E
    c.r[1] = ld32(0x0608FF18u);  // 0608FE8A mov.l 0x0608FF18,r1
    c.r[2] = 0x0u;  // 0608FE8C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FE8E mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FE90 mov #1,r0
    goto L_0608FEFC;  // 0608FE92 bra 0x0608FEFC ; nop
L_0608FE9E:
    c.r[1] = ld32(0x0608FF20u);  // 0608FE9E mov.l 0x0608FF20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FEA0 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FEA2 mov r2,r1
    c.r[1] += 2;  // 0608FEA4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608FEA6 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608FEA8 mov.b r2,@r1
    c.r[1] = ld32(0x0608FF20u);  // 0608FEAA mov.l 0x0608FF20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FEAC mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FEAE mov r2,r1
    c.r[1] += 3;  // 0608FEB0 add #3,r1
    c.r[2] = c.r[14];  // 0608FEB2 mov r14,r2
    c.r[3] = c.r[14];  // 0608FEB4 mov r14,r3
    c.r[3] += 1;  // 0608FEB6 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608FEB8 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608FEBA mov.b r2,@r1
    c.r[1] = ld32(0x0608FF20u);  // 0608FEBC mov.l 0x0608FF20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FEBE mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FEC0 mov r2,r1
    c.r[1] += 4;  // 0608FEC2 add #4,r1
    c.r[2] = c.r[14];  // 0608FEC4 mov r14,r2
    c.r[3] = c.r[14];  // 0608FEC6 mov r14,r3
    c.r[3] += 2;  // 0608FEC8 add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608FECA mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608FECC mov.b r2,@r1
    c.r[1] = ld32(0x0608FF20u);  // 0608FECE mov.l 0x0608FF20,r1
    c.r[2] = ld32(c.r[1]);  // 0608FED0 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FED2 mov r2,r1
    c.r[1] += 5;  // 0608FED4 add #5,r1
    c.r[2] = c.r[14];  // 0608FED6 mov r14,r2
    c.r[3] = c.r[14];  // 0608FED8 mov r14,r3
    c.r[3] += 3;  // 0608FEDA add #3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608FEDC mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0608FEDE mov.b r2,@r1
    c.r[2] = ld32(0x0608FF20u);  // 0608FEE0 mov.l 0x0608FF20,r2
    c.r[1] = ld32(c.r[2]);  // 0608FEE2 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FF14u);  // 0608FEE4 mov.w 0x0608FF14,r2
    st16(c.r[1], c.r[2]);  // 0608FEE6 mov.w r2,@r1
    c.r[1] = ld32(0x0608FF18u);  // 0608FEE8 mov.l 0x0608FF18,r1
    c.r[2] = 0x0u;  // 0608FEEA mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FEEC mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FEEE mov #0,r0
    goto L_0608FEFC;  // 0608FEF0 bra 0x0608FEFC ; nop
L_0608FEFC:
    c.r[14] += 28;  // 0608FEFC add #28,r14
    c.r[15] = c.r[14];  // 0608FEFE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FF00 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF02 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF04 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF06 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF08 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF0A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF0C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF0E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FF10 rts ; nop
}

void f_0608FF24(SH2Context& c) {
    ran[2112] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FF24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608FF26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FF28 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FF2A sts.l pr,@-r15
    c.r[15] -= 4;  // 0608FF2C add #-4,r15
    c.r[14] = c.r[15];  // 0608FF2E mov r15,r14
    c.r[8] = c.r[4];  // 0608FF30 mov r4,r8
    st8(c.r[14], c.r[8]);  // 0608FF32 mov.b r8,@r14
    c.r[1] = ld32(0x0608FFA4u);  // 0608FF34 mov.l 0x0608FFA4,r1
    c.r[2] = ld32(c.r[1]);  // 0608FF36 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FF38 tst r2,r2
    if (c.t) { goto L_0608FF42; }  // 0608FF3A bt 0x0608FF42
    c.r[0] = 0x1u;  // 0608FF3C mov #1,r0
    goto L_0608FF90;  // 0608FF3E bra 0x0608FF90 ; nop
L_0608FF42:
    c.r[1] = ld32(0x0608FFA4u);  // 0608FF42 mov.l 0x0608FFA4,r1
    c.r[2] = 0x1u;  // 0608FF44 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FF46 mov.l r2,@r1
    c.r[9] = ld32(0x0608FFA8u);  // 0608FF48 mov.l 0x0608FFA8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608FF4Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FF4Eu) return; }  // 0608FF4A jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FF4E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FF50 tst r1,r1
    if (!c.t) { goto L_0608FF68; }  // 0608FF52 bf 0x0608FF68
    c.r[1] = ld32(0x0608FFA4u);  // 0608FF54 mov.l 0x0608FFA4,r1
    c.r[2] = 0x0u;  // 0608FF56 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FF58 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FF5A mov #1,r0
    goto L_0608FF90;  // 0608FF5C bra 0x0608FF90 ; nop
L_0608FF68:
    c.r[1] = ld32(0x0608FFACu);  // 0608FF68 mov.l 0x0608FFAC,r1
    c.r[2] = ld32(c.r[1]);  // 0608FF6A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FF6C mov r2,r1
    c.r[1] += 2;  // 0608FF6E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608FF70 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608FF72 mov.b r2,@r1
    c.r[2] = ld32(0x0608FFACu);  // 0608FF74 mov.l 0x0608FFAC,r2
    c.r[1] = ld32(c.r[2]);  // 0608FF76 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608FFA0u);  // 0608FF78 mov.w 0x0608FFA0,r2
    st16(c.r[1], c.r[2]);  // 0608FF7A mov.w r2,@r1
    c.r[1] = ld32(0x0608FFA4u);  // 0608FF7C mov.l 0x0608FFA4,r1
    c.r[2] = 0x0u;  // 0608FF7E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FF80 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0608FF82 mov #0,r0
    goto L_0608FF90;  // 0608FF84 bra 0x0608FF90 ; nop
L_0608FF90:
    c.r[14] += 4;  // 0608FF90 add #4,r14
    c.r[15] = c.r[14];  // 0608FF92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608FF94 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF96 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF98 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608FF9A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608FF9C rts ; nop
}

void f_0608FFB0(SH2Context& c) {
    ran[2113] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608FFB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608FFB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608FFB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608FFB6 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608FFB8 add #-4,r15
    c.r[14] = c.r[15];  // 0608FFBA mov r15,r14
    c.r[8] = c.r[4];  // 0608FFBC mov r4,r8
    st8(c.r[14], c.r[8]);  // 0608FFBE mov.b r8,@r14
    c.r[1] = ld32(0x06090030u);  // 0608FFC0 mov.l 0x06090030,r1
    c.r[2] = ld32(c.r[1]);  // 0608FFC2 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608FFC4 tst r2,r2
    if (c.t) { goto L_0608FFCE; }  // 0608FFC6 bt 0x0608FFCE
    c.r[0] = 0x1u;  // 0608FFC8 mov #1,r0
    goto L_0609001C;  // 0608FFCA bra 0x0609001C ; nop
L_0608FFCE:
    c.r[1] = ld32(0x06090030u);  // 0608FFCE mov.l 0x06090030,r1
    c.r[2] = 0x1u;  // 0608FFD0 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608FFD2 mov.l r2,@r1
    c.r[9] = ld32(0x06090034u);  // 0608FFD4 mov.l 0x06090034,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608FFDAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608FFDAu) return; }  // 0608FFD6 jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0608FFDA extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608FFDC tst r1,r1
    if (!c.t) { goto L_0608FFF4; }  // 0608FFDE bf 0x0608FFF4
    c.r[1] = ld32(0x06090030u);  // 0608FFE0 mov.l 0x06090030,r1
    c.r[2] = 0x0u;  // 0608FFE2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608FFE4 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0608FFE6 mov #1,r0
    goto L_0609001C;  // 0608FFE8 bra 0x0609001C ; nop
L_0608FFF4:
    c.r[1] = ld32(0x06090038u);  // 0608FFF4 mov.l 0x06090038,r1
    c.r[2] = ld32(c.r[1]);  // 0608FFF6 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608FFF8 mov r2,r1
    c.r[1] += 2;  // 0608FFFA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608FFFC mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608FFFE mov.b r2,@r1
    c.r[2] = ld32(0x06090038u);  // 06090000 mov.l 0x06090038,r2
    c.r[1] = ld32(c.r[2]);  // 06090002 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609002Cu);  // 06090004 mov.w 0x0609002C,r2
    st16(c.r[1], c.r[2]);  // 06090006 mov.w r2,@r1
    c.r[1] = ld32(0x06090030u);  // 06090008 mov.l 0x06090030,r1
    c.r[2] = 0x0u;  // 0609000A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609000C mov.l r2,@r1
    c.r[0] = 0x0u;  // 0609000E mov #0,r0
    goto L_0609001C;  // 06090010 bra 0x0609001C ; nop
L_0609001C:
    c.r[14] += 4;  // 0609001C add #4,r14
    c.r[15] = c.r[14];  // 0609001E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090020 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090022 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090024 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090026 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090028 rts ; nop
}

void f_0609003C(SH2Context& c) {
    ran[2114] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609003C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609003E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090040 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090042 sts.l pr,@-r15
    c.r[15] -= 4;  // 06090044 add #-4,r15
    c.r[14] = c.r[15];  // 06090046 mov r15,r14
    c.r[8] = c.r[4];  // 06090048 mov r4,r8
    st8(c.r[14], c.r[8]);  // 0609004A mov.b r8,@r14
    c.r[1] = ld32(0x060900BCu);  // 0609004C mov.l 0x060900BC,r1
    c.r[2] = ld32(c.r[1]);  // 0609004E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090050 tst r2,r2
    if (c.t) { goto L_0609005A; }  // 06090052 bt 0x0609005A
    c.r[0] = 0x1u;  // 06090054 mov #1,r0
    goto L_060900A8;  // 06090056 bra 0x060900A8 ; nop
L_0609005A:
    c.r[1] = ld32(0x060900BCu);  // 0609005A mov.l 0x060900BC,r1
    c.r[2] = 0x1u;  // 0609005C mov #1,r2
    st32(c.r[1], c.r[2]);  // 0609005E mov.l r2,@r1
    c.r[9] = ld32(0x060900C0u);  // 06090060 mov.l 0x060900C0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06090066u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090066u) return; }  // 06090062 jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090066 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090068 tst r1,r1
    if (!c.t) { goto L_06090080; }  // 0609006A bf 0x06090080
    c.r[1] = ld32(0x060900BCu);  // 0609006C mov.l 0x060900BC,r1
    c.r[2] = 0x0u;  // 0609006E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090070 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090072 mov #1,r0
    goto L_060900A8;  // 06090074 bra 0x060900A8 ; nop
L_06090080:
    c.r[1] = ld32(0x060900C4u);  // 06090080 mov.l 0x060900C4,r1
    c.r[2] = ld32(c.r[1]);  // 06090082 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090084 mov r2,r1
    c.r[1] += 2;  // 06090086 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090088 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0609008A mov.b r2,@r1
    c.r[2] = ld32(0x060900C4u);  // 0609008C mov.l 0x060900C4,r2
    c.r[1] = ld32(c.r[2]);  // 0609008E mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060900B8u);  // 06090090 mov.w 0x060900B8,r2
    st16(c.r[1], c.r[2]);  // 06090092 mov.w r2,@r1
    c.r[1] = ld32(0x060900BCu);  // 06090094 mov.l 0x060900BC,r1
    c.r[2] = 0x0u;  // 06090096 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090098 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0609009A mov #0,r0
    goto L_060900A8;  // 0609009C bra 0x060900A8 ; nop
L_060900A8:
    c.r[14] += 4;  // 060900A8 add #4,r14
    c.r[15] = c.r[14];  // 060900AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060900AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060900AE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060900B0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060900B2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060900B4 rts ; nop
}

void f_060900C8(SH2Context& c) {
    ran[2115] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060900C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060900CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060900CC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060900CE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060900D0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060900D2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060900D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060900D6 sts.l pr,@-r15
    c.r[15] -= 12;  // 060900D8 add #-12,r15
    c.r[14] = c.r[15];  // 060900DA mov r15,r14
    c.r[9] = c.r[4];  // 060900DC mov r4,r9
    c.r[10] = c.r[5];  // 060900DE mov r5,r10
    c.r[8] = c.r[6];  // 060900E0 mov r6,r8
    st8(c.r[14], c.r[9]);  // 060900E2 mov.b r9,@r14
    c.r[11] = c.r[14];  // 060900E4 mov r14,r11
    c.r[13] = c.r[14];  // 060900E6 mov r14,r13
    c.r[13] += 1;  // 060900E8 add #1,r13
    st8(c.r[13], c.r[10]);  // 060900EA mov.b r10,@r13
    c.r[12] = c.r[14];  // 060900EC mov r14,r12
    c.r[7] = c.r[14];  // 060900EE mov r14,r7
    c.r[7] += 2;  // 060900F0 add #2,r7
    st32(c.r[14] + 4, c.r[7]);  // 060900F2 mov.l r7,@(4,r14)
    c.r[7] = ld32(c.r[14] + 4);  // 060900F4 mov.l @(4,r14),r7
    st8(c.r[7], c.r[8]);  // 060900F6 mov.b r8,@r7
    c.r[1] = ld32(0x06090198u);  // 060900F8 mov.l 0x06090198,r1
    c.r[2] = ld32(c.r[1]);  // 060900FA mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060900FC tst r2,r2
    if (c.t) { goto L_06090106; }  // 060900FE bt 0x06090106
    c.r[0] = 0x1u;  // 06090100 mov #1,r0
    goto L_0609017C;  // 06090102 bra 0x0609017C ; nop
L_06090106:
    c.r[1] = ld32(0x06090198u);  // 06090106 mov.l 0x06090198,r1
    c.r[2] = 0x1u;  // 06090108 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0609010A mov.l r2,@r1
    c.r[7] = ld32(0x0609019Cu);  // 0609010C mov.l 0x0609019C,r7
    st32(c.r[14] + 8, c.r[7]);  // 0609010E mov.l r7,@(8,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 06090110 mov.l @(8,r14),r7
    { const uint32_t x = c.r[7]; c.pr = 0x06090116u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090116u) return; }  // 06090112 jsr @r7 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090116 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090118 tst r1,r1
    if (!c.t) { goto L_06090130; }  // 0609011A bf 0x06090130
    c.r[1] = ld32(0x06090198u);  // 0609011C mov.l 0x06090198,r1
    c.r[2] = 0x0u;  // 0609011E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090120 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090122 mov #1,r0
    goto L_0609017C;  // 06090124 bra 0x0609017C ; nop
L_06090130:
    c.r[1] = ld32(0x060901A0u);  // 06090130 mov.l 0x060901A0,r1
    c.r[2] = ld32(c.r[1]);  // 06090132 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090134 mov r2,r1
    c.r[1] += 2;  // 06090136 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090138 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0609013A mov.b r2,@r1
    c.r[1] = ld32(0x060901A0u);  // 0609013C mov.l 0x060901A0,r1
    c.r[2] = ld32(c.r[1]);  // 0609013E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090140 mov r2,r1
    c.r[1] += 3;  // 06090142 add #3,r1
    c.r[2] = c.r[14];  // 06090144 mov r14,r2
    c.r[3] = c.r[14];  // 06090146 mov r14,r3
    c.r[3] += 1;  // 06090148 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609014A mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609014C mov.b r2,@r1
    c.r[1] = ld32(0x060901A0u);  // 0609014E mov.l 0x060901A0,r1
    c.r[2] = ld32(c.r[1]);  // 06090150 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090152 mov r2,r1
    c.r[1] += 4;  // 06090154 add #4,r1
    c.r[2] = c.r[14];  // 06090156 mov r14,r2
    c.r[3] = c.r[14];  // 06090158 mov r14,r3
    c.r[3] += 2;  // 0609015A add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609015C mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609015E mov.b r2,@r1
    c.r[2] = ld32(0x060901A0u);  // 06090160 mov.l 0x060901A0,r2
    c.r[1] = ld32(c.r[2]);  // 06090162 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090194u);  // 06090164 mov.w 0x06090194,r2
    st16(c.r[1], c.r[2]);  // 06090166 mov.w r2,@r1
    c.r[1] = ld32(0x06090198u);  // 06090168 mov.l 0x06090198,r1
    c.r[2] = 0x0u;  // 0609016A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609016C mov.l r2,@r1
    c.r[0] = 0x0u;  // 0609016E mov #0,r0
    goto L_0609017C;  // 06090170 bra 0x0609017C ; nop
L_0609017C:
    c.r[14] += 12;  // 0609017C add #12,r14
    c.r[15] = c.r[14];  // 0609017E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090180 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090182 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06090184 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06090186 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06090188 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609018A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609018C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609018E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090190 rts ; nop
}

void f_060901A4(SH2Context& c) {
    ran[2116] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060901A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060901A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060901A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060901AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060901AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060901AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060901B0 sts.l pr,@-r15
    c.r[15] -= 4;  // 060901B2 add #-4,r15
    c.r[14] = c.r[15];  // 060901B4 mov r15,r14
    c.r[8] = c.r[4];  // 060901B6 mov r4,r8
    c.r[9] = c.r[5];  // 060901B8 mov r5,r9
    st8(c.r[14], c.r[8]);  // 060901BA mov.b r8,@r14
    c.r[10] = c.r[14];  // 060901BC mov r14,r10
    c.r[11] = c.r[14];  // 060901BE mov r14,r11
    c.r[11] += 2;  // 060901C0 add #2,r11
    st16(c.r[11], c.r[9]);  // 060901C2 mov.w r9,@r11
    c.r[1] = ld32(0x0609026Cu);  // 060901C4 mov.l 0x0609026C,r1
    c.r[2] = ld32(c.r[1]);  // 060901C6 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060901C8 tst r2,r2
    if (c.t) { goto L_060901D2; }  // 060901CA bt 0x060901D2
    c.r[0] = 0x1u;  // 060901CC mov #1,r0
    goto L_06090252;  // 060901CE bra 0x06090252 ; nop
L_060901D2:
    c.r[1] = ld32(0x0609026Cu);  // 060901D2 mov.l 0x0609026C,r1
    c.r[2] = 0x1u;  // 060901D4 mov #1,r2
    st32(c.r[1], c.r[2]);  // 060901D6 mov.l r2,@r1
    c.r[12] = ld32(0x06090270u);  // 060901D8 mov.l 0x06090270,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060901DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060901DEu) return; }  // 060901DA jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 060901DE extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060901E0 tst r1,r1
    if (!c.t) { goto L_060901F8; }  // 060901E2 bf 0x060901F8
    c.r[1] = ld32(0x0609026Cu);  // 060901E4 mov.l 0x0609026C,r1
    c.r[2] = 0x0u;  // 060901E6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 060901E8 mov.l r2,@r1
    c.r[0] = 0x1u;  // 060901EA mov #1,r0
    goto L_06090252;  // 060901EC bra 0x06090252 ; nop
L_060901F8:
    c.r[1] = ld32(0x06090274u);  // 060901F8 mov.l 0x06090274,r1
    c.r[2] = ld32(c.r[1]);  // 060901FA mov.l @r1,r2
    c.r[1] = c.r[2];  // 060901FC mov r2,r1
    c.r[1] += 2;  // 060901FE add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090200 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 06090202 mov.b r2,@r1
    c.r[1] = ld32(0x06090274u);  // 06090204 mov.l 0x06090274,r1
    c.r[2] = ld32(c.r[1]);  // 06090206 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090208 mov r2,r1
    c.r[1] += 4;  // 0609020A add #4,r1
    c.r[2] = c.r[14];  // 0609020C mov r14,r2
    c.r[3] = c.r[14];  // 0609020E mov r14,r3
    c.r[3] += 2;  // 06090210 add #2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06090212 mov.w @r3,r2
    c.r[4] = c.r[2];  // 06090214 mov r2,r4
    c.r[2] = ld32(0x06090278u);  // 06090216 mov.l 0x06090278,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0609021Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609021Cu) return; }  // 06090218 jsr @r2 ; nop
    c.r[2] = c.r[4];  // 0609021C mov r4,r2
    st8(c.r[1], c.r[2]);  // 0609021E mov.b r2,@r1
    c.r[1] = ld32(0x06090274u);  // 06090220 mov.l 0x06090274,r1
    c.r[2] = ld32(c.r[1]);  // 06090222 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090224 mov r2,r1
    c.r[1] += 5;  // 06090226 add #5,r1
    c.r[2] = c.r[14];  // 06090228 mov r14,r2
    c.r[3] = c.r[14];  // 0609022A mov r14,r3
    c.r[3] += 2;  // 0609022C add #2,r3
    c.r[2] = c.r[3];  // 0609022E mov r3,r2
    c.r[3] += 1;  // 06090230 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090232 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090234 mov.b r2,@r1
    c.r[2] = ld32(0x06090274u);  // 06090236 mov.l 0x06090274,r2
    c.r[1] = ld32(c.r[2]);  // 06090238 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090268u);  // 0609023A mov.w 0x06090268,r2
    st16(c.r[1], c.r[2]);  // 0609023C mov.w r2,@r1
    c.r[1] = ld32(0x0609026Cu);  // 0609023E mov.l 0x0609026C,r1
    c.r[2] = 0x0u;  // 06090240 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090242 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090244 mov #0,r0
    goto L_06090252;  // 06090246 bra 0x06090252 ; nop
L_06090252:
    c.r[14] += 4;  // 06090252 add #4,r14
    c.r[15] = c.r[14];  // 06090254 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090256 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090258 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609025A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609025C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609025E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090260 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090262 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090264 rts ; nop
}

void f_0609027C(SH2Context& c) {
    ran[2117] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609027C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609027E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06090280 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06090282 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06090284 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06090286 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090288 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609028A sts.l pr,@-r15
    c.r[15] -= 60;  // 0609028C add #-60,r15
    c.r[14] = c.r[15];  // 0609028E mov r15,r14
    c.r[12] = c.r[4];  // 06090290 mov r4,r12
    c.r[13] = c.r[5];  // 06090292 mov r5,r13
    c.r[11] = c.r[6];  // 06090294 mov r6,r11
    c.r[10] = c.r[7];  // 06090296 mov r7,r10
    c.r[8] = 0x5Cu;  // 06090298 mov #92,r8
    c.r[8] += c.r[14];  // 0609029A add r14,r8
    c.r[8] = ld32(c.r[8]);  // 0609029C mov.l @r8,r8
    st32(c.r[14] + 56, c.r[8]);  // 0609029E mov.l r8,@(56,r14)
    c.r[9] = 0x60u;  // 060902A0 mov #96,r9
    c.r[9] += c.r[14];  // 060902A2 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 060902A4 mov.l @r9,r9
    st32(c.r[14] + 52, c.r[9]);  // 060902A6 mov.l r9,@(52,r14)
    st8(c.r[14], c.r[12]);  // 060902A8 mov.b r12,@r14
    st32(c.r[14] + 8, c.r[14]);  // 060902AA mov.l r14,@(8,r14)
    c.r[8] = c.r[14];  // 060902AC mov r14,r8
    c.r[8] += 1;  // 060902AE add #1,r8
    st32(c.r[14] + 12, c.r[8]);  // 060902B0 mov.l r8,@(12,r14)
    c.r[9] = ld32(c.r[14] + 12);  // 060902B2 mov.l @(12,r14),r9
    st8(c.r[9], c.r[13]);  // 060902B4 mov.b r13,@r9
    st32(c.r[14] + 16, c.r[14]);  // 060902B6 mov.l r14,@(16,r14)
    c.r[8] = c.r[14];  // 060902B8 mov r14,r8
    c.r[8] += 2;  // 060902BA add #2,r8
    st32(c.r[14] + 20, c.r[8]);  // 060902BC mov.l r8,@(20,r14)
    c.r[9] = ld32(c.r[14] + 20);  // 060902BE mov.l @(20,r14),r9
    st8(c.r[9], c.r[11]);  // 060902C0 mov.b r11,@r9
    st32(c.r[14] + 24, c.r[14]);  // 060902C2 mov.l r14,@(24,r14)
    c.r[8] = c.r[14];  // 060902C4 mov r14,r8
    c.r[8] += 3;  // 060902C6 add #3,r8
    st32(c.r[14] + 28, c.r[8]);  // 060902C8 mov.l r8,@(28,r14)
    c.r[9] = ld32(c.r[14] + 28);  // 060902CA mov.l @(28,r14),r9
    st8(c.r[9], c.r[10]);  // 060902CC mov.b r10,@r9
    st32(c.r[14] + 32, c.r[14]);  // 060902CE mov.l r14,@(32,r14)
    c.r[8] = c.r[14];  // 060902D0 mov r14,r8
    c.r[8] += 4;  // 060902D2 add #4,r8
    st32(c.r[14] + 36, c.r[8]);  // 060902D4 mov.l r8,@(36,r14)
    c.r[9] = 0x3Bu;  // 060902D6 mov #59,r9
    c.r[9] += c.r[14];  // 060902D8 add r14,r9
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060902DA mov.b @r9,r8
    c.r[9] = ld32(c.r[14] + 36);  // 060902DC mov.l @(36,r14),r9
    st8(c.r[9], c.r[8]);  // 060902DE mov.b r8,@r9
    st32(c.r[14] + 40, c.r[14]);  // 060902E0 mov.l r14,@(40,r14)
    c.r[9] = c.r[14];  // 060902E2 mov r14,r9
    c.r[9] += 5;  // 060902E4 add #5,r9
    st32(c.r[14] + 44, c.r[9]);  // 060902E6 mov.l r9,@(44,r14)
    c.r[8] = 0x37u;  // 060902E8 mov #55,r8
    c.r[8] += c.r[14];  // 060902EA add r14,r8
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060902EC mov.b @r8,r9
    c.r[8] = ld32(c.r[14] + 44);  // 060902EE mov.l @(44,r14),r8
    st8(c.r[8], c.r[9]);  // 060902F0 mov.b r9,@r8
    c.r[1] = ld32(0x060903C8u);  // 060902F2 mov.l 0x060903C8,r1
    c.r[2] = ld32(c.r[1]);  // 060902F4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060902F6 tst r2,r2
    if (c.t) { goto L_06090300; }  // 060902F8 bt 0x06090300
    c.r[0] = 0x1u;  // 060902FA mov #1,r0
    goto L_060903AE;  // 060902FC bra 0x060903AE ; nop
L_06090300:
    c.r[1] = ld32(0x060903C8u);  // 06090300 mov.l 0x060903C8,r1
    c.r[2] = 0x1u;  // 06090302 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090304 mov.l r2,@r1
    c.r[8] = ld32(0x060903CCu);  // 06090306 mov.l 0x060903CC,r8
    st32(c.r[14] + 48, c.r[8]);  // 06090308 mov.l r8,@(48,r14)
    c.r[9] = ld32(c.r[14] + 48);  // 0609030A mov.l @(48,r14),r9
    { const uint32_t x = c.r[9]; c.pr = 0x06090310u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090310u) return; }  // 0609030C jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090310 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090312 tst r1,r1
    if (!c.t) { goto L_0609032A; }  // 06090314 bf 0x0609032A
    c.r[1] = ld32(0x060903C8u);  // 06090316 mov.l 0x060903C8,r1
    c.r[2] = 0x0u;  // 06090318 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609031A mov.l r2,@r1
    c.r[0] = 0x1u;  // 0609031C mov #1,r0
    goto L_060903AE;  // 0609031E bra 0x060903AE ; nop
L_0609032A:
    c.r[1] = ld32(0x060903D0u);  // 0609032A mov.l 0x060903D0,r1
    c.r[2] = ld32(c.r[1]);  // 0609032C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609032E mov r2,r1
    c.r[1] += 2;  // 06090330 add #2,r1
    c.r[2] = c.r[14];  // 06090332 mov r14,r2
    c.r[3] = c.r[14];  // 06090334 mov r14,r3
    c.r[3] += 1;  // 06090336 add #1,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090338 mov.b @r3,r7
    c.r[2] = c.r[7];  // 0609033A mov r7,r2
    c.r[2] <<= 2;  // 0609033C shll2 r2
    c.r[2] += c.r[2];  // 0609033E add r2,r2
    c.r[3] = c.r[14];  // 06090340 mov r14,r3
    c.r[7] = c.r[14];  // 06090342 mov r14,r7
    c.r[7] += 2;  // 06090344 add #2,r7
    c.r[2] = c.r[2];  // 06090346 mov r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06090348 mov.b @r7,r3
    c.r[2] |= c.r[3];  // 0609034A or r3,r2
    st8(c.r[1], c.r[2]);  // 0609034C mov.b r2,@r1
    c.r[1] = ld32(0x060903D0u);  // 0609034E mov.l 0x060903D0,r1
    c.r[2] = ld32(c.r[1]);  // 06090350 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090352 mov r2,r1
    c.r[1] += 3;  // 06090354 add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090356 mov.b @r14,r3
    c.r[2] = c.r[3];  // 06090358 mov r3,r2
    c.r[2] <<= 2;  // 0609035A shll2 r2
    c.r[2] += c.r[2];  // 0609035C add r2,r2
    c.r[2] <<= 2;  // 0609035E shll2 r2
    c.r[3] = c.r[14];  // 06090360 mov r14,r3
    c.r[7] = c.r[14];  // 06090362 mov r14,r7
    c.r[7] += 3;  // 06090364 add #3,r7
    c.r[2] = c.r[2];  // 06090366 mov r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06090368 mov.b @r7,r3
    c.r[2] |= c.r[3];  // 0609036A or r3,r2
    st8(c.r[1], c.r[2]);  // 0609036C mov.b r2,@r1
    c.r[1] = ld32(0x060903D0u);  // 0609036E mov.l 0x060903D0,r1
    c.r[2] = ld32(c.r[1]);  // 06090370 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090372 mov r2,r1
    c.r[1] += 4;  // 06090374 add #4,r1
    c.r[2] = c.r[14];  // 06090376 mov r14,r2
    c.r[3] = c.r[14];  // 06090378 mov r14,r3
    c.r[3] += 4;  // 0609037A add #4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609037C mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609037E mov.b r2,@r1
    c.r[1] = ld32(0x060903D0u);  // 06090380 mov.l 0x060903D0,r1
    c.r[2] = ld32(c.r[1]);  // 06090382 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090384 mov r2,r1
    c.r[1] += 5;  // 06090386 add #5,r1
    c.r[2] = c.r[14];  // 06090388 mov r14,r2
    c.r[3] = c.r[14];  // 0609038A mov r14,r3
    c.r[3] += 5;  // 0609038C add #5,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609038E mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090390 mov.b r2,@r1
    c.r[2] = ld32(0x060903D0u);  // 06090392 mov.l 0x060903D0,r2
    c.r[1] = ld32(c.r[2]);  // 06090394 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060903C6u);  // 06090396 mov.w 0x060903C6,r2
    st16(c.r[1], c.r[2]);  // 06090398 mov.w r2,@r1
    c.r[1] = ld32(0x060903C8u);  // 0609039A mov.l 0x060903C8,r1
    c.r[2] = 0x0u;  // 0609039C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609039E mov.l r2,@r1
    c.r[0] = 0x0u;  // 060903A0 mov #0,r0
    goto L_060903AE;  // 060903A2 bra 0x060903AE ; nop
L_060903AE:
    c.r[14] += 60;  // 060903AE add #60,r14
    c.r[15] = c.r[14];  // 060903B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060903B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060903B4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060903B6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060903B8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060903BA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060903BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060903BE mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060903C0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060903C2 rts ; nop
}

void f_060903D4(SH2Context& c) {
    ran[2118] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060903D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060903D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060903D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060903DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060903DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060903DE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060903E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060903E2 sts.l pr,@-r15
    c.r[15] -= 16;  // 060903E4 add #-16,r15
    c.r[14] = c.r[15];  // 060903E6 mov r15,r14
    c.r[9] = c.r[4];  // 060903E8 mov r4,r9
    c.r[10] = c.r[5];  // 060903EA mov r5,r10
    c.r[8] = c.r[6];  // 060903EC mov r6,r8
    st8(c.r[14], c.r[9]);  // 060903EE mov.b r9,@r14
    c.r[11] = c.r[14];  // 060903F0 mov r14,r11
    c.r[13] = c.r[14];  // 060903F2 mov r14,r13
    c.r[13] += 1;  // 060903F4 add #1,r13
    st8(c.r[13], c.r[10]);  // 060903F6 mov.b r10,@r13
    c.r[12] = c.r[14];  // 060903F8 mov r14,r12
    c.r[7] = c.r[14];  // 060903FA mov r14,r7
    c.r[7] += 2;  // 060903FC add #2,r7
    st32(c.r[14] + 4, c.r[7]);  // 060903FE mov.l r7,@(4,r14)
    c.r[7] = ld32(c.r[14] + 4);  // 06090400 mov.l @(4,r14),r7
    st8(c.r[7], c.r[8]);  // 06090402 mov.b r8,@r7
    c.r[1] = ld32(0x060904A0u);  // 06090404 mov.l 0x060904A0,r1
    c.r[2] = ld32(c.r[1]);  // 06090406 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090408 tst r2,r2
    if (c.t) { goto L_06090412; }  // 0609040A bt 0x06090412
    c.r[0] = 0x1u;  // 0609040C mov #1,r0
    goto L_06090484;  // 0609040E bra 0x06090484 ; nop
L_06090412:
    c.r[1] = ld32(0x060904A0u);  // 06090412 mov.l 0x060904A0,r1
    c.r[2] = 0x1u;  // 06090414 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090416 mov.l r2,@r1
    c.r[7] = ld32(0x060904A4u);  // 06090418 mov.l 0x060904A4,r7
    st32(c.r[14] + 8, c.r[7]);  // 0609041A mov.l r7,@(8,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 0609041C mov.l @(8,r14),r7
    { const uint32_t x = c.r[7]; c.pr = 0x06090422u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090422u) return; }  // 0609041E jsr @r7 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090422 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090424 tst r1,r1
    if (!c.t) { goto L_0609043C; }  // 06090426 bf 0x0609043C
    c.r[1] = ld32(0x060904A0u);  // 06090428 mov.l 0x060904A0,r1
    c.r[2] = 0x0u;  // 0609042A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609042C mov.l r2,@r1
    c.r[0] = 0x1u;  // 0609042E mov #1,r0
    goto L_06090484;  // 06090430 bra 0x06090484 ; nop
L_0609043C:
    c.r[1] = ld32(0x060904A8u);  // 0609043C mov.l 0x060904A8,r1
    c.r[2] = ld32(c.r[1]);  // 0609043E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090440 mov r2,r1
    c.r[1] += 2;  // 06090442 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090444 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 06090446 mov.b r2,@r1
    c.r[1] = ld32(0x060904A8u);  // 06090448 mov.l 0x060904A8,r1
    c.r[2] = ld32(c.r[1]);  // 0609044A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609044C mov r2,r1
    c.r[1] += 3;  // 0609044E add #3,r1
    c.r[3] = c.r[14];  // 06090450 mov r14,r3
    c.r[2] = c.r[14];  // 06090452 mov r14,r2
    c.r[2] += 1;  // 06090454 add #1,r2
    c.r[3] = c.r[14];  // 06090456 mov r14,r3
    c.r[7] = c.r[14];  // 06090458 mov r14,r7
    c.r[7] += 2;  // 0609045A add #2,r7
    st32(c.r[14] + 12, c.r[7]);  // 0609045C mov.l r7,@(12,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609045E mov.b @r2,r2
    c.r[7] = ld32(c.r[14] + 12);  // 06090460 mov.l @(12,r14),r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06090462 mov.b @r7,r3
    c.r[2] |= c.r[3];  // 06090464 or r3,r2
    st8(c.r[1], c.r[2]);  // 06090466 mov.b r2,@r1
    c.r[2] = ld32(0x060904A8u);  // 06090468 mov.l 0x060904A8,r2
    c.r[1] = ld32(c.r[2]);  // 0609046A mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609049Cu);  // 0609046C mov.w 0x0609049C,r2
    st16(c.r[1], c.r[2]);  // 0609046E mov.w r2,@r1
    c.r[1] = ld32(0x060904A0u);  // 06090470 mov.l 0x060904A0,r1
    c.r[2] = 0x0u;  // 06090472 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090474 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090476 mov #0,r0
    goto L_06090484;  // 06090478 bra 0x06090484 ; nop
L_06090484:
    c.r[14] += 16;  // 06090484 add #16,r14
    c.r[15] = c.r[14];  // 06090486 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090488 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609048A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609048C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609048E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06090490 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06090492 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090494 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090496 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090498 rts ; nop
}

void f_060904AC(SH2Context& c) {
    ran[2119] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060904AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060904AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060904B0 sts.l pr,@-r15
    c.r[15] -= 8;  // 060904B2 add #-8,r15
    c.r[14] = c.r[15];  // 060904B4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060904B6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060904B8 mov.l r5,@(4,r14)
    c.r[1] = ld32(0x06090650u);  // 060904BA mov.l 0x06090650,r1
    c.r[2] = ld32(c.r[1]);  // 060904BC mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060904BE tst r2,r2
    if (c.t) { goto L_060904C8; }  // 060904C0 bt 0x060904C8
    c.r[0] = 0x1u;  // 060904C2 mov #1,r0
    goto L_0609063E;  // 060904C4 bra 0x0609063E ; nop
L_060904C8:
    c.r[1] = ld32(0x06090650u);  // 060904C8 mov.l 0x06090650,r1
    c.r[2] = 0x1u;  // 060904CA mov #1,r2
    st32(c.r[1], c.r[2]);  // 060904CC mov.l r2,@r1
    c.r[8] = ld32(0x06090654u);  // 060904CE mov.l 0x06090654,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060904D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060904D4u) return; }  // 060904D0 jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 060904D4 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060904D6 tst r1,r1
    if (!c.t) { goto L_060904EE; }  // 060904D8 bf 0x060904EE
    c.r[1] = ld32(0x06090650u);  // 060904DA mov.l 0x06090650,r1
    c.r[2] = 0x0u;  // 060904DC mov #0,r2
    st32(c.r[1], c.r[2]);  // 060904DE mov.l r2,@r1
    c.r[0] = 0x1u;  // 060904E0 mov #1,r0
    goto L_0609063E;  // 060904E2 bra 0x0609063E ; nop
L_060904EE:
    c.r[1] = ld32(0x06090658u);  // 060904EE mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 060904F0 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060904F2 mov r2,r1
    c.r[1] += 2;  // 060904F4 add #2,r1
    c.r[2] = ld32(c.r[14]);  // 060904F6 mov.l @r14,r2
    c.r[3] = ld32(c.r[14] + 4);  // 060904F8 mov.l @(4,r14),r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060904FA mov.b @r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060904FC mov.b @r3,r3
    c.r[2] |= c.r[3];  // 060904FE or r3,r2
    st8(c.r[1], c.r[2]);  // 06090500 mov.b r2,@r1
    c.r[2] = ld32(c.r[14] + 4);  // 06090502 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06090504 mov r2,r1
    c.r[2] += 2;  // 06090506 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06090508 mov.b @r2,r1
    c.r[4] = c.r[1];  // 0609050A mov r1,r4
    c.r[8] = ld32(0x0609065Cu);  // 0609050C mov.l 0x0609065C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06090512u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090512u) return; }  // 0609050E jsr @r8 ; nop
    c.r[1] = ld32(0x06090658u);  // 06090512 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 06090514 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090516 mov r2,r1
    c.r[1] += 3;  // 06090518 add #3,r1
    c.r[3] = ld32(c.r[14] + 4);  // 0609051A mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0609051C mov r3,r2
    c.r[3] += 1;  // 0609051E add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090520 mov.b @r3,r2
    c.r[3] = c.r[2];  // 06090522 mov r2,r3
    c.r[3] <<= 2;  // 06090524 shll2 r3
    c.r[3] += c.r[3];  // 06090526 add r3,r3
    c.r[3] <<= 2;  // 06090528 shll2 r3
    c.r[2] = c.r[3];  // 0609052A mov r3,r2
    c.r[3] = c.r[0];  // 0609052C mov r0,r3
    c.r[2] |= c.r[3];  // 0609052E or r3,r2
    st8(c.r[1], c.r[2]);  // 06090530 mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 06090532 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 06090534 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090536 mov r2,r1
    c.r[1] += 4;  // 06090538 add #4,r1
    c.r[3] = ld32(c.r[14]);  // 0609053A mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609053C mov r3,r2
    c.r[3] += 2;  // 0609053E add #2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06090540 mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 06090542 extu.w r7,r2
    c.r[3] = c.r[2];  // 06090544 mov r2,r3
    c.r[3] >>= 8;  // 06090546 shlr8 r3
    st8(c.r[1], c.r[3]);  // 06090548 mov.b r3,@r1
    c.r[1] = ld32(0x06090658u);  // 0609054A mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 0609054C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609054E mov r2,r1
    c.r[1] += 5;  // 06090550 add #5,r1
    c.r[3] = ld32(c.r[14]);  // 06090552 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06090554 mov r3,r2
    c.r[3] += 2;  // 06090556 add #2,r3
    c.r[2] = c.r[3];  // 06090558 mov r3,r2
    c.r[3] += 1;  // 0609055A add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609055C mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609055E mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 06090560 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 06090562 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090564 mov r2,r1
    c.r[1] += 6;  // 06090566 add #6,r1
    c.r[3] = ld32(c.r[14]);  // 06090568 mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609056A mov r3,r2
    c.r[3] += 4;  // 0609056C add #4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609056E mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 06090570 extu.w r7,r2
    c.r[3] = c.r[2];  // 06090572 mov r2,r3
    c.r[3] >>= 8;  // 06090574 shlr8 r3
    st8(c.r[1], c.r[3]);  // 06090576 mov.b r3,@r1
    c.r[1] = ld32(0x06090658u);  // 06090578 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 0609057A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609057C mov r2,r1
    c.r[1] += 7;  // 0609057E add #7,r1
    c.r[3] = ld32(c.r[14]);  // 06090580 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06090582 mov r3,r2
    c.r[3] += 4;  // 06090584 add #4,r3
    c.r[2] = c.r[3];  // 06090586 mov r3,r2
    c.r[3] += 1;  // 06090588 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609058A mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609058C mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 0609058E mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 06090590 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090592 mov r2,r1
    c.r[1] += 8;  // 06090594 add #8,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06090596 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06090598 mov r3,r2
    c.r[3] += 4;  // 0609059A add #4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609059C mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0609059E extu.w r7,r2
    c.r[3] = c.r[2];  // 060905A0 mov r2,r3
    c.r[3] >>= 8;  // 060905A2 shlr8 r3
    st8(c.r[1], c.r[3]);  // 060905A4 mov.b r3,@r1
    c.r[1] = ld32(0x06090658u);  // 060905A6 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 060905A8 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060905AA mov r2,r1
    c.r[1] += 9;  // 060905AC add #9,r1
    c.r[3] = ld32(c.r[14] + 4);  // 060905AE mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 060905B0 mov r3,r2
    c.r[3] += 4;  // 060905B2 add #4,r3
    c.r[2] = c.r[3];  // 060905B4 mov r3,r2
    c.r[3] += 1;  // 060905B6 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060905B8 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060905BA mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 060905BC mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 060905BE mov.l @r1,r2
    c.r[1] = c.r[2];  // 060905C0 mov r2,r1
    c.r[1] += 10;  // 060905C2 add #10,r1
    c.r[3] = ld32(c.r[14] + 4);  // 060905C4 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 060905C6 mov r3,r2
    c.r[3] += 6;  // 060905C8 add #6,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060905CA mov.b @r3,r7
    c.r[2] = c.r[7];  // 060905CC mov r7,r2
    c.r[2] <<= 2;  // 060905CE shll2 r2
    c.r[2] += c.r[2];  // 060905D0 add r2,r2
    c.r[7] = ld32(c.r[14] + 4);  // 060905D2 mov.l @(4,r14),r7
    c.r[3] = c.r[7];  // 060905D4 mov r7,r3
    c.r[7] += 7;  // 060905D6 add #7,r7
    c.r[2] = c.r[2];  // 060905D8 mov r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060905DA mov.b @r7,r3
    c.r[2] |= c.r[3];  // 060905DC or r3,r2
    st8(c.r[1], c.r[2]);  // 060905DE mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 060905E0 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 060905E2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060905E4 mov r2,r1
    c.r[1] += 11;  // 060905E6 add #11,r1
    c.r[3] = ld32(c.r[14] + 4);  // 060905E8 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 060905EA mov r3,r2
    c.r[3] += 8;  // 060905EC add #8,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060905EE mov.b @r3,r7
    c.r[2] = c.r[7];  // 060905F0 mov r7,r2
    c.r[2] <<= 2;  // 060905F2 shll2 r2
    c.r[2] += c.r[2];  // 060905F4 add r2,r2
    c.r[7] = ld32(c.r[14] + 4);  // 060905F6 mov.l @(4,r14),r7
    c.r[3] = c.r[7];  // 060905F8 mov r7,r3
    c.r[7] += 9;  // 060905FA add #9,r7
    c.r[2] = c.r[2];  // 060905FC mov r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060905FE mov.b @r7,r3
    c.r[2] |= c.r[3];  // 06090600 or r3,r2
    st8(c.r[1], c.r[2]);  // 06090602 mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 06090604 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 06090606 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090608 mov r2,r1
    c.r[1] += 12;  // 0609060A add #12,r1
    c.r[3] = ld32(c.r[14] + 4);  // 0609060C mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0609060E mov r3,r2
    c.r[3] += 10;  // 06090610 add #10,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090612 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090614 mov.b r2,@r1
    c.r[1] = ld32(0x06090658u);  // 06090616 mov.l 0x06090658,r1
    c.r[2] = ld32(c.r[1]);  // 06090618 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609061A mov r2,r1
    c.r[1] += 13;  // 0609061C add #13,r1
    c.r[2] = 0x0u;  // 0609061E mov #0,r2
    st8(c.r[1], c.r[2]);  // 06090620 mov.b r2,@r1
    c.r[2] = ld32(0x06090658u);  // 06090622 mov.l 0x06090658,r2
    c.r[1] = ld32(c.r[2]);  // 06090624 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609064Cu);  // 06090626 mov.w 0x0609064C,r2
    st16(c.r[1], c.r[2]);  // 06090628 mov.w r2,@r1
    c.r[1] = ld32(0x06090650u);  // 0609062A mov.l 0x06090650,r1
    c.r[2] = 0x0u;  // 0609062C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609062E mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090630 mov #0,r0
    goto L_0609063E;  // 06090632 bra 0x0609063E ; nop
L_0609063E:
    c.r[14] += 8;  // 0609063E add #8,r14
    c.r[15] = c.r[14];  // 06090640 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090642 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090644 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090646 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090648 rts ; nop
}

void f_06090660(SH2Context& c) {
    ran[2120] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090660 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06090662 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090664 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090666 sts.l pr,@-r15
    c.r[15] -= 4;  // 06090668 add #-4,r15
    c.r[14] = c.r[15];  // 0609066A mov r15,r14
    c.r[8] = c.r[4];  // 0609066C mov r4,r8
    st8(c.r[14], c.r[8]);  // 0609066E mov.b r8,@r14
    c.r[1] = ld32(0x060906E0u);  // 06090670 mov.l 0x060906E0,r1
    c.r[2] = ld32(c.r[1]);  // 06090672 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090674 tst r2,r2
    if (c.t) { goto L_0609067E; }  // 06090676 bt 0x0609067E
    c.r[0] = 0x1u;  // 06090678 mov #1,r0
    goto L_060906CC;  // 0609067A bra 0x060906CC ; nop
L_0609067E:
    c.r[1] = ld32(0x060906E0u);  // 0609067E mov.l 0x060906E0,r1
    c.r[2] = 0x1u;  // 06090680 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090682 mov.l r2,@r1
    c.r[9] = ld32(0x060906E4u);  // 06090684 mov.l 0x060906E4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0609068Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609068Au) return; }  // 06090686 jsr @r9 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0609068A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609068C tst r1,r1
    if (!c.t) { goto L_060906A4; }  // 0609068E bf 0x060906A4
    c.r[1] = ld32(0x060906E0u);  // 06090690 mov.l 0x060906E0,r1
    c.r[2] = 0x0u;  // 06090692 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090694 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090696 mov #1,r0
    goto L_060906CC;  // 06090698 bra 0x060906CC ; nop
L_060906A4:
    c.r[1] = ld32(0x060906E8u);  // 060906A4 mov.l 0x060906E8,r1
    c.r[2] = ld32(c.r[1]);  // 060906A6 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060906A8 mov r2,r1
    c.r[1] += 2;  // 060906AA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060906AC mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 060906AE mov.b r2,@r1
    c.r[2] = ld32(0x060906E8u);  // 060906B0 mov.l 0x060906E8,r2
    c.r[1] = ld32(c.r[2]);  // 060906B2 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060906DCu);  // 060906B4 mov.w 0x060906DC,r2
    st16(c.r[1], c.r[2]);  // 060906B6 mov.w r2,@r1
    c.r[1] = ld32(0x060906E0u);  // 060906B8 mov.l 0x060906E0,r1
    c.r[2] = 0x0u;  // 060906BA mov #0,r2
    st32(c.r[1], c.r[2]);  // 060906BC mov.l r2,@r1
    c.r[0] = 0x0u;  // 060906BE mov #0,r0
    goto L_060906CC;  // 060906C0 bra 0x060906CC ; nop
L_060906CC:
    c.r[14] += 4;  // 060906CC add #4,r14
    c.r[15] = c.r[14];  // 060906CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060906D0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060906D2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060906D4 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060906D6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060906D8 rts ; nop
}

void f_060906EC(SH2Context& c) {
    ran[2121] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060906EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060906EE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060906F0 sts.l pr,@-r15
    c.r[15] -= 4;  // 060906F2 add #-4,r15
    c.r[14] = c.r[15];  // 060906F4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060906F6 mov.l r4,@r14
    c.r[1] = ld32(0x06090820u);  // 060906F8 mov.l 0x06090820,r1
    c.r[2] = ld32(c.r[1]);  // 060906FA mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060906FC tst r2,r2
    if (c.t) { goto L_06090706; }  // 060906FE bt 0x06090706
    c.r[0] = 0x1u;  // 06090700 mov #1,r0
    goto L_0609080E;  // 06090702 bra 0x0609080E ; nop
L_06090706:
    c.r[1] = ld32(0x06090820u);  // 06090706 mov.l 0x06090820,r1
    c.r[2] = 0x1u;  // 06090708 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0609070A mov.l r2,@r1
    c.r[8] = ld32(0x06090824u);  // 0609070C mov.l 0x06090824,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06090712u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090712u) return; }  // 0609070E jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090712 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090714 tst r1,r1
    if (!c.t) { goto L_0609072C; }  // 06090716 bf 0x0609072C
    c.r[1] = ld32(0x06090820u);  // 06090718 mov.l 0x06090820,r1
    c.r[2] = 0x0u;  // 0609071A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609071C mov.l r2,@r1
    c.r[0] = 0x1u;  // 0609071E mov #1,r0
    goto L_0609080E;  // 06090720 bra 0x0609080E ; nop
L_0609072C:
    c.r[1] = ld32(0x06090828u);  // 0609072C mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 0609072E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090730 mov r2,r1
    c.r[1] += 2;  // 06090732 add #2,r1
    c.r[2] = ld32(c.r[14]);  // 06090734 mov.l @r14,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06090736 mov.b @r2,r3
    st8(c.r[1], c.r[3]);  // 06090738 mov.b r3,@r1
    c.r[2] = ld32(c.r[14]);  // 0609073A mov.l @r14,r2
    c.r[1] = c.r[2];  // 0609073C mov r2,r1
    c.r[2] += 2;  // 0609073E add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06090740 mov.b @r2,r1
    c.r[4] = c.r[1];  // 06090742 mov r1,r4
    c.r[8] = ld32(0x0609082Cu);  // 06090744 mov.l 0x0609082C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609074Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609074Au) return; }  // 06090746 jsr @r8 ; nop
    c.r[1] = ld32(0x06090828u);  // 0609074A mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 0609074C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609074E mov r2,r1
    c.r[1] += 3;  // 06090750 add #3,r1
    c.r[3] = ld32(c.r[14]);  // 06090752 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06090754 mov r3,r2
    c.r[3] += 1;  // 06090756 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090758 mov.b @r3,r2
    c.r[3] = c.r[2];  // 0609075A mov r2,r3
    c.r[3] <<= 2;  // 0609075C shll2 r3
    c.r[3] += c.r[3];  // 0609075E add r3,r3
    c.r[3] <<= 2;  // 06090760 shll2 r3
    c.r[2] = c.r[3];  // 06090762 mov r3,r2
    c.r[3] = c.r[0];  // 06090764 mov r0,r3
    c.r[2] |= c.r[3];  // 06090766 or r3,r2
    st8(c.r[1], c.r[2]);  // 06090768 mov.b r2,@r1
    c.r[1] = ld32(0x06090828u);  // 0609076A mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 0609076C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609076E mov r2,r1
    c.r[1] += 4;  // 06090770 add #4,r1
    c.r[3] = ld32(c.r[14]);  // 06090772 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06090774 mov r3,r2
    c.r[3] += 4;  // 06090776 add #4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06090778 mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0609077A extu.w r7,r2
    c.r[3] = c.r[2];  // 0609077C mov r2,r3
    c.r[3] >>= 8;  // 0609077E shlr8 r3
    st8(c.r[1], c.r[3]);  // 06090780 mov.b r3,@r1
    c.r[1] = ld32(0x06090828u);  // 06090782 mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 06090784 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090786 mov r2,r1
    c.r[1] += 5;  // 06090788 add #5,r1
    c.r[3] = ld32(c.r[14]);  // 0609078A mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609078C mov r3,r2
    c.r[3] += 4;  // 0609078E add #4,r3
    c.r[2] = c.r[3];  // 06090790 mov r3,r2
    c.r[3] += 1;  // 06090792 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090794 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090796 mov.b r2,@r1
    c.r[1] = ld32(0x06090828u);  // 06090798 mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 0609079A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609079C mov r2,r1
    c.r[1] += 6;  // 0609079E add #6,r1
    c.r[3] = ld32(c.r[14]);  // 060907A0 mov.l @r14,r3
    c.r[2] = c.r[3];  // 060907A2 mov r3,r2
    c.r[3] += 6;  // 060907A4 add #6,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060907A6 mov.b @r3,r7
    c.r[2] = c.r[7];  // 060907A8 mov r7,r2
    c.r[2] <<= 2;  // 060907AA shll2 r2
    c.r[2] += c.r[2];  // 060907AC add r2,r2
    c.r[7] = ld32(c.r[14]);  // 060907AE mov.l @r14,r7
    c.r[3] = c.r[7];  // 060907B0 mov r7,r3
    c.r[7] += 7;  // 060907B2 add #7,r7
    c.r[2] = c.r[2];  // 060907B4 mov r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060907B6 mov.b @r7,r3
    c.r[2] |= c.r[3];  // 060907B8 or r3,r2
    st8(c.r[1], c.r[2]);  // 060907BA mov.b r2,@r1
    c.r[1] = ld32(0x06090828u);  // 060907BC mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 060907BE mov.l @r1,r2
    c.r[1] = c.r[2];  // 060907C0 mov r2,r1
    c.r[1] += 7;  // 060907C2 add #7,r1
    c.r[3] = ld32(c.r[14]);  // 060907C4 mov.l @r14,r3
    c.r[2] = c.r[3];  // 060907C6 mov r3,r2
    c.r[3] += 8;  // 060907C8 add #8,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060907CA mov.b @r3,r7
    c.r[2] = c.r[7];  // 060907CC mov r7,r2
    c.r[2] <<= 2;  // 060907CE shll2 r2
    c.r[2] += c.r[2];  // 060907D0 add r2,r2
    c.r[7] = ld32(c.r[14]);  // 060907D2 mov.l @r14,r7
    c.r[3] = c.r[7];  // 060907D4 mov r7,r3
    c.r[7] += 9;  // 060907D6 add #9,r7
    c.r[2] = c.r[2];  // 060907D8 mov r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060907DA mov.b @r7,r3
    c.r[2] |= c.r[3];  // 060907DC or r3,r2
    st8(c.r[1], c.r[2]);  // 060907DE mov.b r2,@r1
    c.r[1] = ld32(0x06090828u);  // 060907E0 mov.l 0x06090828,r1
    c.r[2] = ld32(c.r[1]);  // 060907E2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060907E4 mov r2,r1
    c.r[1] += 8;  // 060907E6 add #8,r1
    c.r[3] = ld32(c.r[14]);  // 060907E8 mov.l @r14,r3
    c.r[2] = c.r[3];  // 060907EA mov r3,r2
    c.r[3] += 10;  // 060907EC add #10,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060907EE mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060907F0 mov.b r2,@r1
    c.r[2] = ld32(0x06090828u);  // 060907F2 mov.l 0x06090828,r2
    c.r[1] = ld32(c.r[2]);  // 060907F4 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609081Cu);  // 060907F6 mov.w 0x0609081C,r2
    st16(c.r[1], c.r[2]);  // 060907F8 mov.w r2,@r1
    c.r[1] = ld32(0x06090820u);  // 060907FA mov.l 0x06090820,r1
    c.r[2] = 0x0u;  // 060907FC mov #0,r2
    st32(c.r[1], c.r[2]);  // 060907FE mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090800 mov #0,r0
    goto L_0609080E;  // 06090802 bra 0x0609080E ; nop
L_0609080E:
    c.r[14] += 4;  // 0609080E add #4,r14
    c.r[15] = c.r[14];  // 06090810 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090812 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090814 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090816 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090818 rts ; nop
}

void f_06090830(SH2Context& c) {
    ran[2122] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090830 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090832 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090834 sts.l pr,@-r15
    c.r[15] -= 4;  // 06090836 add #-4,r15
    c.r[14] = c.r[15];  // 06090838 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609083A mov.l r4,@r14
    c.r[1] = ld32(0x060908ACu);  // 0609083C mov.l 0x060908AC,r1
    c.r[2] = ld32(c.r[1]);  // 0609083E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090840 tst r2,r2
    if (c.t) { goto L_0609084A; }  // 06090842 bt 0x0609084A
    c.r[0] = 0x1u;  // 06090844 mov #1,r0
    goto L_0609089A;  // 06090846 bra 0x0609089A ; nop
L_0609084A:
    c.r[1] = ld32(0x060908ACu);  // 0609084A mov.l 0x060908AC,r1
    c.r[2] = 0x1u;  // 0609084C mov #1,r2
    st32(c.r[1], c.r[2]);  // 0609084E mov.l r2,@r1
    c.r[8] = ld32(0x060908B0u);  // 06090850 mov.l 0x060908B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06090856u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090856u) return; }  // 06090852 jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090856 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090858 tst r1,r1
    if (!c.t) { goto L_06090870; }  // 0609085A bf 0x06090870
    c.r[1] = ld32(0x060908ACu);  // 0609085C mov.l 0x060908AC,r1
    c.r[2] = 0x0u;  // 0609085E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090860 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090862 mov #1,r0
    goto L_0609089A;  // 06090864 bra 0x0609089A ; nop
L_06090870:
    c.r[1] = ld32(0x060908B4u);  // 06090870 mov.l 0x060908B4,r1
    c.r[2] = ld32(c.r[1]);  // 06090872 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090874 mov r2,r1
    c.r[1] += 2;  // 06090876 add #2,r1
    c.r[2] = ld32(c.r[14]);  // 06090878 mov.l @r14,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609087A mov.b @r2,r3
    st8(c.r[1], c.r[3]);  // 0609087C mov.b r3,@r1
    c.r[2] = ld32(0x060908B4u);  // 0609087E mov.l 0x060908B4,r2
    c.r[1] = ld32(c.r[2]);  // 06090880 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060908A8u);  // 06090882 mov.w 0x060908A8,r2
    st16(c.r[1], c.r[2]);  // 06090884 mov.w r2,@r1
    c.r[1] = ld32(0x060908ACu);  // 06090886 mov.l 0x060908AC,r1
    c.r[2] = 0x0u;  // 06090888 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609088A mov.l r2,@r1
    c.r[0] = 0x0u;  // 0609088C mov #0,r0
    goto L_0609089A;  // 0609088E bra 0x0609089A ; nop
L_0609089A:
    c.r[14] += 4;  // 0609089A add #4,r14
    c.r[15] = c.r[14];  // 0609089C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609089E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060908A0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060908A2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060908A4 rts ; nop
}

void f_060908B8(SH2Context& c) {
    ran[2123] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060908B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060908BA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060908BC sts.l pr,@-r15
    c.r[15] -= 4;  // 060908BE add #-4,r15
    c.r[14] = c.r[15];  // 060908C0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060908C2 mov.l r4,@r14
    c.r[1] = ld32(0x06090934u);  // 060908C4 mov.l 0x06090934,r1
    c.r[2] = ld32(c.r[1]);  // 060908C6 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060908C8 tst r2,r2
    if (c.t) { goto L_060908D2; }  // 060908CA bt 0x060908D2
    c.r[0] = 0x1u;  // 060908CC mov #1,r0
    goto L_06090922;  // 060908CE bra 0x06090922 ; nop
L_060908D2:
    c.r[1] = ld32(0x06090934u);  // 060908D2 mov.l 0x06090934,r1
    c.r[2] = 0x1u;  // 060908D4 mov #1,r2
    st32(c.r[1], c.r[2]);  // 060908D6 mov.l r2,@r1
    c.r[8] = ld32(0x06090938u);  // 060908D8 mov.l 0x06090938,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060908DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060908DEu) return; }  // 060908DA jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 060908DE extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060908E0 tst r1,r1
    if (!c.t) { goto L_060908F8; }  // 060908E2 bf 0x060908F8
    c.r[1] = ld32(0x06090934u);  // 060908E4 mov.l 0x06090934,r1
    c.r[2] = 0x0u;  // 060908E6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 060908E8 mov.l r2,@r1
    c.r[0] = 0x1u;  // 060908EA mov #1,r0
    goto L_06090922;  // 060908EC bra 0x06090922 ; nop
L_060908F8:
    c.r[1] = ld32(0x0609093Cu);  // 060908F8 mov.l 0x0609093C,r1
    c.r[2] = ld32(c.r[1]);  // 060908FA mov.l @r1,r2
    c.r[1] = c.r[2];  // 060908FC mov r2,r1
    c.r[1] += 2;  // 060908FE add #2,r1
    c.r[2] = ld32(c.r[14]);  // 06090900 mov.l @r14,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06090902 mov.b @r2,r3
    st8(c.r[1], c.r[3]);  // 06090904 mov.b r3,@r1
    c.r[2] = ld32(0x0609093Cu);  // 06090906 mov.l 0x0609093C,r2
    c.r[1] = ld32(c.r[2]);  // 06090908 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090930u);  // 0609090A mov.w 0x06090930,r2
    st16(c.r[1], c.r[2]);  // 0609090C mov.w r2,@r1
    c.r[1] = ld32(0x06090934u);  // 0609090E mov.l 0x06090934,r1
    c.r[2] = 0x0u;  // 06090910 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090912 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090914 mov #0,r0
    goto L_06090922;  // 06090916 bra 0x06090922 ; nop
L_06090922:
    c.r[14] += 4;  // 06090922 add #4,r14
    c.r[15] = c.r[14];  // 06090924 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090926 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090928 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609092A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609092C rts ; nop
}

void f_06090940(SH2Context& c) {
    ran[2124] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090940 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090942 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090944 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06090946 mov r15,r14
    c.r[1] = ld32(0x060909A8u);  // 06090948 mov.l 0x060909A8,r1
    c.r[2] = ld32(c.r[1]);  // 0609094A mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609094C tst r2,r2
    if (c.t) { goto L_06090956; }  // 0609094E bt 0x06090956
    c.r[0] = 0x1u;  // 06090950 mov #1,r0
    goto L_06090998;  // 06090952 bra 0x06090998 ; nop
L_06090956:
    c.r[1] = ld32(0x060909A8u);  // 06090956 mov.l 0x060909A8,r1
    c.r[2] = 0x1u;  // 06090958 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0609095A mov.l r2,@r1
    c.r[8] = ld32(0x060909ACu);  // 0609095C mov.l 0x060909AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06090962u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090962u) return; }  // 0609095E jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090962 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090964 tst r1,r1
    if (!c.t) { goto L_0609097C; }  // 06090966 bf 0x0609097C
    c.r[1] = ld32(0x060909A8u);  // 06090968 mov.l 0x060909A8,r1
    c.r[2] = 0x0u;  // 0609096A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609096C mov.l r2,@r1
    c.r[0] = 0x1u;  // 0609096E mov #1,r0
    goto L_06090998;  // 06090970 bra 0x06090998 ; nop
L_0609097C:
    c.r[2] = ld32(0x060909B0u);  // 0609097C mov.l 0x060909B0,r2
    c.r[1] = ld32(c.r[2]);  // 0609097E mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060909A4u);  // 06090980 mov.w 0x060909A4,r2
    st16(c.r[1], c.r[2]);  // 06090982 mov.w r2,@r1
    c.r[1] = ld32(0x060909A8u);  // 06090984 mov.l 0x060909A8,r1
    c.r[2] = 0x0u;  // 06090986 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090988 mov.l r2,@r1
    c.r[0] = 0x0u;  // 0609098A mov #0,r0
    goto L_06090998;  // 0609098C bra 0x06090998 ; nop
L_06090998:
    c.r[15] = c.r[14];  // 06090998 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609099A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609099C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609099E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060909A0 rts ; nop
}

void f_060909B4(SH2Context& c) {
    ran[2125] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060909B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060909B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060909B8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060909BA mov r15,r14
    c.r[1] = ld32(0x06090A1Cu);  // 060909BC mov.l 0x06090A1C,r1
    c.r[2] = ld32(c.r[1]);  // 060909BE mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060909C0 tst r2,r2
    if (c.t) { goto L_060909CA; }  // 060909C2 bt 0x060909CA
    c.r[0] = 0x1u;  // 060909C4 mov #1,r0
    goto L_06090A0C;  // 060909C6 bra 0x06090A0C ; nop
L_060909CA:
    c.r[1] = ld32(0x06090A1Cu);  // 060909CA mov.l 0x06090A1C,r1
    c.r[2] = 0x1u;  // 060909CC mov #1,r2
    st32(c.r[1], c.r[2]);  // 060909CE mov.l r2,@r1
    c.r[8] = ld32(0x06090A20u);  // 060909D0 mov.l 0x06090A20,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060909D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060909D6u) return; }  // 060909D2 jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 060909D6 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060909D8 tst r1,r1
    if (!c.t) { goto L_060909F0; }  // 060909DA bf 0x060909F0
    c.r[1] = ld32(0x06090A1Cu);  // 060909DC mov.l 0x06090A1C,r1
    c.r[2] = 0x0u;  // 060909DE mov #0,r2
    st32(c.r[1], c.r[2]);  // 060909E0 mov.l r2,@r1
    c.r[0] = 0x1u;  // 060909E2 mov #1,r0
    goto L_06090A0C;  // 060909E4 bra 0x06090A0C ; nop
L_060909F0:
    c.r[2] = ld32(0x06090A24u);  // 060909F0 mov.l 0x06090A24,r2
    c.r[1] = ld32(c.r[2]);  // 060909F2 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090A18u);  // 060909F4 mov.w 0x06090A18,r2
    st16(c.r[1], c.r[2]);  // 060909F6 mov.w r2,@r1
    c.r[1] = ld32(0x06090A1Cu);  // 060909F8 mov.l 0x06090A1C,r1
    c.r[2] = 0x0u;  // 060909FA mov #0,r2
    st32(c.r[1], c.r[2]);  // 060909FC mov.l r2,@r1
    c.r[0] = 0x0u;  // 060909FE mov #0,r0
    goto L_06090A0C;  // 06090A00 bra 0x06090A0C ; nop
L_06090A0C:
    c.r[15] = c.r[14];  // 06090A0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090A0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090A10 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090A12 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090A14 rts ; nop
}

void f_06090A28(SH2Context& c) {
    ran[2126] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090A28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06090A2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06090A2C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06090A2E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06090A30 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090A32 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090A34 sts.l pr,@-r15
    c.r[15] -= 4;  // 06090A36 add #-4,r15
    c.r[14] = c.r[15];  // 06090A38 mov r15,r14
    c.r[8] = c.r[4];  // 06090A3A mov r4,r8
    c.r[9] = c.r[5];  // 06090A3C mov r5,r9
    st8(c.r[14], c.r[8]);  // 06090A3E mov.b r8,@r14
    c.r[10] = c.r[14];  // 06090A40 mov r14,r10
    c.r[11] = c.r[14];  // 06090A42 mov r14,r11
    c.r[11] += 1;  // 06090A44 add #1,r11
    st8(c.r[11], c.r[9]);  // 06090A46 mov.b r9,@r11
    c.r[1] = ld32(0x06090AF0u);  // 06090A48 mov.l 0x06090AF0,r1
    c.r[2] = ld32(c.r[1]);  // 06090A4A mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090A4C tst r2,r2
    if (c.t) { goto L_06090A56; }  // 06090A4E bt 0x06090A56
    c.r[0] = 0x1u;  // 06090A50 mov #1,r0
    goto L_06090AD6;  // 06090A52 bra 0x06090AD6 ; nop
L_06090A56:
    c.r[1] = ld32(0x06090AF0u);  // 06090A56 mov.l 0x06090AF0,r1
    c.r[2] = 0x1u;  // 06090A58 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090A5A mov.l r2,@r1
    c.r[12] = ld32(0x06090AF4u);  // 06090A5C mov.l 0x06090AF4,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06090A62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090A62u) return; }  // 06090A5E jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090A62 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090A64 tst r1,r1
    if (!c.t) { goto L_06090A7C; }  // 06090A66 bf 0x06090A7C
    c.r[1] = ld32(0x06090AF0u);  // 06090A68 mov.l 0x06090AF0,r1
    c.r[2] = 0x0u;  // 06090A6A mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090A6C mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090A6E mov #1,r0
    goto L_06090AD6;  // 06090A70 bra 0x06090AD6 ; nop
L_06090A7C:
    c.r[1] = ld32(0x06090AF8u);  // 06090A7C mov.l 0x06090AF8,r1
    c.r[2] = ld32(c.r[1]);  // 06090A7E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090A80 mov r2,r1
    c.r[1] += 2;  // 06090A82 add #2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090A84 mov.b @r14,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06090A86 extu.b r3,r2
    c.r[3] = c.r[2];  // 06090A88 mov r2,r3
    c.r[2] = c.r[3];  // 06090A8A mov r3,r2
    c.r[2] += c.r[2];  // 06090A8C add r2,r2
    c.r[3] = c.r[2];  // 06090A8E mov r2,r3
    c.r[2] = c.r[3];  // 06090A90 mov r3,r2
    c.r[2] <<= 2;  // 06090A92 shll2 r2
    c.r[2] <<= 2;  // 06090A94 shll2 r2
    st8(c.r[1], c.r[2]);  // 06090A96 mov.b r2,@r1
    c.r[1] = ld32(0x06090AF8u);  // 06090A98 mov.l 0x06090AF8,r1
    c.r[2] = ld32(c.r[1]);  // 06090A9A mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090A9C mov r2,r1
    c.r[1] += 3;  // 06090A9E add #3,r1
    c.r[2] = c.r[14];  // 06090AA0 mov r14,r2
    c.r[3] = c.r[14];  // 06090AA2 mov r14,r3
    c.r[3] += 1;  // 06090AA4 add #1,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090AA6 mov.b @r3,r7
    c.r[2] = c.r[7] & 0xFFu;  // 06090AA8 extu.b r7,r2
    c.r[3] = c.r[2];  // 06090AAA mov r2,r3
    c.r[2] = c.r[3];  // 06090AAC mov r3,r2
    c.r[2] += c.r[2];  // 06090AAE add r2,r2
    c.r[3] = c.r[2];  // 06090AB0 mov r2,r3
    c.r[2] = c.r[3];  // 06090AB2 mov r3,r2
    c.r[2] <<= 2;  // 06090AB4 shll2 r2
    c.r[2] <<= 2;  // 06090AB6 shll2 r2
    st8(c.r[1], c.r[2]);  // 06090AB8 mov.b r2,@r1
    c.r[2] = ld32(0x06090AF8u);  // 06090ABA mov.l 0x06090AF8,r2
    c.r[1] = ld32(c.r[2]);  // 06090ABC mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090AECu);  // 06090ABE mov.w 0x06090AEC,r2
    st16(c.r[1], c.r[2]);  // 06090AC0 mov.w r2,@r1
    c.r[1] = ld32(0x06090AF0u);  // 06090AC2 mov.l 0x06090AF0,r1
    c.r[2] = 0x0u;  // 06090AC4 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090AC6 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090AC8 mov #0,r0
    goto L_06090AD6;  // 06090ACA bra 0x06090AD6 ; nop
L_06090AD6:
    c.r[14] += 4;  // 06090AD6 add #4,r14
    c.r[15] = c.r[14];  // 06090AD8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090ADA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090ADC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06090ADE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06090AE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06090AE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090AE4 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090AE6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090AE8 rts ; nop
}

void f_06090AFC(SH2Context& c) {
    ran[2127] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090AFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06090AFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06090B00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06090B02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06090B04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090B06 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090B08 sts.l pr,@-r15
    c.r[15] -= 4;  // 06090B0A add #-4,r15
    c.r[14] = c.r[15];  // 06090B0C mov r15,r14
    c.r[8] = c.r[4];  // 06090B0E mov r4,r8
    c.r[9] = c.r[5];  // 06090B10 mov r5,r9
    st8(c.r[14], c.r[8]);  // 06090B12 mov.b r8,@r14
    c.r[10] = c.r[14];  // 06090B14 mov r14,r10
    c.r[11] = c.r[14];  // 06090B16 mov r14,r11
    c.r[11] += 1;  // 06090B18 add #1,r11
    st8(c.r[11], c.r[9]);  // 06090B1A mov.b r9,@r11
    c.r[1] = ld32(0x06090BB4u);  // 06090B1C mov.l 0x06090BB4,r1
    c.r[2] = ld32(c.r[1]);  // 06090B1E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090B20 tst r2,r2
    if (c.t) { goto L_06090B2A; }  // 06090B22 bt 0x06090B2A
    c.r[0] = 0x1u;  // 06090B24 mov #1,r0
    goto L_06090B9A;  // 06090B26 bra 0x06090B9A ; nop
L_06090B2A:
    c.r[1] = ld32(0x06090BB4u);  // 06090B2A mov.l 0x06090BB4,r1
    c.r[2] = 0x1u;  // 06090B2C mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090B2E mov.l r2,@r1
    c.r[12] = ld32(0x06090BB8u);  // 06090B30 mov.l 0x06090BB8,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06090B36u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090B36u) return; }  // 06090B32 jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090B36 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090B38 tst r1,r1
    if (!c.t) { goto L_06090B50; }  // 06090B3A bf 0x06090B50
    c.r[1] = ld32(0x06090BB4u);  // 06090B3C mov.l 0x06090BB4,r1
    c.r[2] = 0x0u;  // 06090B3E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090B40 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090B42 mov #1,r0
    goto L_06090B9A;  // 06090B44 bra 0x06090B9A ; nop
L_06090B50:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090B50 mov.b @r14,r1
    c.r[4] = c.r[1];  // 06090B52 mov r1,r4
    c.r[12] = ld32(0x06090BBCu);  // 06090B54 mov.l 0x06090BBC,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06090B5Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090B5Au) return; }  // 06090B56 jsr @r12 ; nop
    c.r[1] = ld32(0x06090BC0u);  // 06090B5A mov.l 0x06090BC0,r1
    c.r[2] = ld32(c.r[1]);  // 06090B5C mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090B5E mov r2,r1
    c.r[1] += 2;  // 06090B60 add #2,r1
    st8(c.r[1], c.r[0]);  // 06090B62 mov.b r0,@r1
    c.r[1] = c.r[14];  // 06090B64 mov r14,r1
    c.r[2] = c.r[14];  // 06090B66 mov r14,r2
    c.r[2] += 1;  // 06090B68 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06090B6A mov.b @r2,r1
    c.r[4] = c.r[1];  // 06090B6C mov r1,r4
    c.r[12] = ld32(0x06090BBCu);  // 06090B6E mov.l 0x06090BBC,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06090B74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090B74u) return; }  // 06090B70 jsr @r12 ; nop
    c.r[1] = ld32(0x06090BC0u);  // 06090B74 mov.l 0x06090BC0,r1
    c.r[2] = ld32(c.r[1]);  // 06090B76 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090B78 mov r2,r1
    c.r[1] += 3;  // 06090B7A add #3,r1
    st8(c.r[1], c.r[0]);  // 06090B7C mov.b r0,@r1
    c.r[2] = ld32(0x06090BC0u);  // 06090B7E mov.l 0x06090BC0,r2
    c.r[1] = ld32(c.r[2]);  // 06090B80 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090BB0u);  // 06090B82 mov.w 0x06090BB0,r2
    st16(c.r[1], c.r[2]);  // 06090B84 mov.w r2,@r1
    c.r[1] = ld32(0x06090BB4u);  // 06090B86 mov.l 0x06090BB4,r1
    c.r[2] = 0x0u;  // 06090B88 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090B8A mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090B8C mov #0,r0
    goto L_06090B9A;  // 06090B8E bra 0x06090B9A ; nop
L_06090B9A:
    c.r[14] += 4;  // 06090B9A add #4,r14
    c.r[15] = c.r[14];  // 06090B9C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090B9E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090BA0 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06090BA2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06090BA4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06090BA6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090BA8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090BAA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090BAC rts ; nop
}

void f_06090BC4(SH2Context& c) {
    ran[2128] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090BC4 mov.l r14,@-r15
    c.r[15] -= 8;  // 06090BC6 add #-8,r15
    c.r[14] = c.r[15];  // 06090BC8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06090BCA mov.l r4,@r14
    c.r[2] = c.r[5];  // 06090BCC mov r5,r2
    c.r[1] = c.r[14];  // 06090BCE mov r14,r1
    c.r[3] = c.r[14];  // 06090BD0 mov r14,r3
    c.r[3] += 4;  // 06090BD2 add #4,r3
    st8(c.r[3], c.r[2]);  // 06090BD4 mov.b r2,@r3
    c.r[7] = ld32(c.r[14]);  // 06090BD6 mov.l @r14,r7
    c.r[6] = c.r[14];  // 06090BD8 mov r14,r6
    c.r[5] = c.r[14];  // 06090BDA mov r14,r5
    c.r[5] += 4;  // 06090BDC add #4,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06090BDE mov.b @r5,r4
    c.r[6] = c.r[4] & 0xFFu;  // 06090BE0 extu.b r4,r6
    c.r[5] = c.r[6];  // 06090BE2 mov r6,r5
    c.r[6] = c.r[5];  // 06090BE4 mov r5,r6
    c.r[6] += c.r[6];  // 06090BE6 add r6,r6
    c.r[4] = ld32(0x06090C24u);  // 06090BE8 mov.l 0x06090C24,r4
    c.r[5] = ld32(c.r[4]);  // 06090BEA mov.l @r4,r5
    c.r[6] += c.r[5];  // 06090BEC add r5,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06090BEE mov.w @r6,r5
    c.r[4] = ld32(0x06090C28u);  // 06090BF0 mov.l 0x06090C28,r4
    c.r[6] = c.r[5];  // 06090BF2 mov r5,r6
    c.r[6] &= c.r[4];  // 06090BF4 and r4,r6
    st16(c.r[7], c.r[6]);  // 06090BF6 mov.w r6,@r7
    c.r[7] = ld32(c.r[14]);  // 06090BF8 mov.l @r14,r7
    c.r[6] = c.r[7];  // 06090BFA mov r7,r6
    c.r[7] += 2;  // 06090BFC add #2,r7
    c.r[6] = c.r[14];  // 06090BFE mov r14,r6
    c.r[5] = c.r[14];  // 06090C00 mov r14,r5
    c.r[5] += 4;  // 06090C02 add #4,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06090C04 mov.b @r5,r4
    c.r[6] = c.r[4] & 0xFFu;  // 06090C06 extu.b r4,r6
    c.r[5] = c.r[6];  // 06090C08 mov r6,r5
    c.r[6] = c.r[5];  // 06090C0A mov r5,r6
    c.r[6] += c.r[6];  // 06090C0C add r6,r6
    c.r[4] = ld32(0x06090C24u);  // 06090C0E mov.l 0x06090C24,r4
    c.r[5] = ld32(c.r[4]);  // 06090C10 mov.l @r4,r5
    c.r[6] += c.r[5];  // 06090C12 add r5,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06090C14 mov.w @r6,r5
    st8(c.r[7], c.r[5]);  // 06090C16 mov.b r5,@r7
    c.r[14] += 8;  // 06090C18 add #8,r14
    c.r[15] = c.r[14];  // 06090C1A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090C1C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090C1E rts ; nop
}

void f_06090C2C(SH2Context& c) {
    ran[2129] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090C2C mov.l r14,@-r15
    c.r[15] -= 8;  // 06090C2E add #-8,r15
    c.r[14] = c.r[15];  // 06090C30 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06090C32 mov.l r4,@r14
    c.r[2] = c.r[5];  // 06090C34 mov r5,r2
    c.r[1] = c.r[14];  // 06090C36 mov r14,r1
    c.r[3] = c.r[14];  // 06090C38 mov r14,r3
    c.r[3] += 4;  // 06090C3A add #4,r3
    st8(c.r[3], c.r[2]);  // 06090C3C mov.b r2,@r3
    c.r[7] = ld32(c.r[14]);  // 06090C3E mov.l @r14,r7
    c.r[6] = c.r[14];  // 06090C40 mov r14,r6
    c.r[5] = c.r[14];  // 06090C42 mov r14,r5
    c.r[5] += 4;  // 06090C44 add #4,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06090C46 mov.b @r5,r4
    c.r[6] = c.r[4] & 0xFFu;  // 06090C48 extu.b r4,r6
    c.r[5] = c.r[6];  // 06090C4A mov r6,r5
    c.r[6] = c.r[5];  // 06090C4C mov r5,r6
    c.r[6] += c.r[6];  // 06090C4E add r6,r6
    c.r[4] = ld32(0x06090C64u);  // 06090C50 mov.l 0x06090C64,r4
    c.r[5] = ld32(c.r[4]);  // 06090C52 mov.l @r4,r5
    c.r[6] += c.r[5];  // 06090C54 add r5,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06090C56 mov.w @r6,r5
    st16(c.r[7], c.r[5]);  // 06090C58 mov.w r5,@r7
    c.r[14] += 8;  // 06090C5A add #8,r14
    c.r[15] = c.r[14];  // 06090C5C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090C5E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090C60 rts ; nop
}

void f_06090C68(SH2Context& c) {
    ran[2130] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090C68 mov.l r14,@-r15
    c.r[15] -= 8;  // 06090C6A add #-8,r15
    c.r[14] = c.r[15];  // 06090C6C mov r15,r14
    st32(c.r[14], c.r[4]);  // 06090C6E mov.l r4,@r14
    c.r[2] = c.r[5];  // 06090C70 mov r5,r2
    c.r[1] = c.r[14];  // 06090C72 mov r14,r1
    c.r[3] = c.r[14];  // 06090C74 mov r14,r3
    c.r[3] += 4;  // 06090C76 add #4,r3
    st8(c.r[3], c.r[2]);  // 06090C78 mov.b r2,@r3
    c.r[7] = ld32(c.r[14]);  // 06090C7A mov.l @r14,r7
    c.r[6] = c.r[14];  // 06090C7C mov r14,r6
    c.r[5] = c.r[14];  // 06090C7E mov r14,r5
    c.r[5] += 4;  // 06090C80 add #4,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06090C82 mov.b @r5,r4
    c.r[6] = c.r[4] & 0xFFu;  // 06090C84 extu.b r4,r6
    c.r[5] = c.r[6];  // 06090C86 mov r6,r5
    c.r[6] = c.r[5];  // 06090C88 mov r5,r6
    c.r[6] += c.r[6];  // 06090C8A add r6,r6
    c.r[4] = ld32(0x06090CC8u);  // 06090C8C mov.l 0x06090CC8,r4
    c.r[5] = ld32(c.r[4]);  // 06090C8E mov.l @r4,r5
    c.r[6] += c.r[5];  // 06090C90 add r5,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06090C92 mov.w @r6,r5
    c.r[6] = c.r[5] & 0xFFFFu;  // 06090C94 extu.w r5,r6
    c.r[5] = c.r[6];  // 06090C96 mov r6,r5
    c.r[5] >>= 8;  // 06090C98 shlr8 r5
    st8(c.r[7], c.r[5]);  // 06090C9A mov.b r5,@r7
    c.r[7] = ld32(c.r[14]);  // 06090C9C mov.l @r14,r7
    c.r[6] = c.r[7];  // 06090C9E mov r7,r6
    c.r[7] += 1;  // 06090CA0 add #1,r7
    c.r[6] = c.r[14];  // 06090CA2 mov r14,r6
    c.r[5] = c.r[14];  // 06090CA4 mov r14,r5
    c.r[5] += 4;  // 06090CA6 add #4,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06090CA8 mov.b @r5,r4
    c.r[6] = c.r[4] & 0xFFu;  // 06090CAA extu.b r4,r6
    c.r[5] = c.r[6];  // 06090CAC mov r6,r5
    c.r[6] = c.r[5];  // 06090CAE mov r5,r6
    c.r[6] += c.r[6];  // 06090CB0 add r6,r6
    c.r[4] = ld32(0x06090CC8u);  // 06090CB2 mov.l 0x06090CC8,r4
    c.r[5] = ld32(c.r[4]);  // 06090CB4 mov.l @r4,r5
    c.r[6] += c.r[5];  // 06090CB6 add r5,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06090CB8 mov.w @r6,r5
    st8(c.r[7], c.r[5]);  // 06090CBA mov.b r5,@r7
    c.r[14] += 8;  // 06090CBC add #8,r14
    c.r[15] = c.r[14];  // 06090CBE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090CC0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090CC2 rts ; nop
}

void f_06090CCC(SH2Context& c) {
    ran[2131] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090CCC mov.l r14,@-r15
    c.r[15] -= 8;  // 06090CCE add #-8,r15
    c.r[14] = c.r[15];  // 06090CD0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06090CD2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06090CD4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06090CD6 mov.l @r14,r1
    c.r[3] = ld32(0x06090CF8u);  // 06090CD8 mov.l 0x06090CF8,r3
    c.r[2] = ld32(c.r[3]);  // 06090CDA mov.l @r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06090CDC mov.w @r2,r3
    st16(c.r[1], c.r[3]);  // 06090CDE mov.w r3,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 06090CE0 mov.l @(4,r14),r1
    c.r[2] = ld32(0x06090CF8u);  // 06090CE2 mov.l 0x06090CF8,r2
    c.r[3] = ld32(c.r[2]);  // 06090CE4 mov.l @r2,r3
    c.r[2] = c.r[3];  // 06090CE6 mov r3,r2
    c.r[2] += 2;  // 06090CE8 add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06090CEA mov.w @r2,r3
    st16(c.r[1], c.r[3]);  // 06090CEC mov.w r3,@r1
    c.r[14] += 8;  // 06090CEE add #8,r14
    c.r[15] = c.r[14];  // 06090CF0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090CF2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090CF4 rts ; nop
}

void f_06090D74(SH2Context& c) {
    ran[2132] = 1;
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[0]);  // 06090D74 mov.b @(r0,r0),r6
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06090D76 mov.b @r4,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090D78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06090D7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06090D7C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06090D7E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06090D80 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090D82 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090D84 sts.l pr,@-r15
    c.r[15] -= 4;  // 06090D86 add #-4,r15
    c.r[14] = c.r[15];  // 06090D88 mov r15,r14
    c.r[8] = c.r[4];  // 06090D8A mov r4,r8
    c.r[9] = c.r[5];  // 06090D8C mov r5,r9
    st8(c.r[14], c.r[8]);  // 06090D8E mov.b r8,@r14
    c.r[10] = c.r[14];  // 06090D90 mov r14,r10
    c.r[11] = c.r[14];  // 06090D92 mov r14,r11
    c.r[11] += 1;  // 06090D94 add #1,r11
    st8(c.r[11], c.r[9]);  // 06090D96 mov.b r9,@r11
    c.r[1] = ld32(0x06090E20u);  // 06090D98 mov.l 0x06090E20,r1
    c.r[2] = ld32(c.r[1]);  // 06090D9A mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090D9C tst r2,r2
    if (c.t) { goto L_06090DA6; }  // 06090D9E bt 0x06090DA6
    c.r[0] = 0x1u;  // 06090DA0 mov #1,r0
    goto L_06090E06;  // 06090DA2 bra 0x06090E06 ; nop
L_06090DA6:
    c.r[1] = ld32(0x06090E20u);  // 06090DA6 mov.l 0x06090E20,r1
    c.r[2] = 0x1u;  // 06090DA8 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090DAA mov.l r2,@r1
    c.r[12] = ld32(0x06090E24u);  // 06090DAC mov.l 0x06090E24,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06090DB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090DB2u) return; }  // 06090DAE jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090DB2 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090DB4 tst r1,r1
    if (!c.t) { goto L_06090DCC; }  // 06090DB6 bf 0x06090DCC
    c.r[1] = ld32(0x06090E20u);  // 06090DB8 mov.l 0x06090E20,r1
    c.r[2] = 0x0u;  // 06090DBA mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090DBC mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090DBE mov #1,r0
    goto L_06090E06;  // 06090DC0 bra 0x06090E06 ; nop
L_06090DCC:
    c.r[1] = ld32(0x06090E28u);  // 06090DCC mov.l 0x06090E28,r1
    c.r[2] = ld32(c.r[1]);  // 06090DCE mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090DD0 mov r2,r1
    c.r[1] += 2;  // 06090DD2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090DD4 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 06090DD6 mov.b r2,@r1
    c.r[1] = ld32(0x06090E28u);  // 06090DD8 mov.l 0x06090E28,r1
    c.r[2] = ld32(c.r[1]);  // 06090DDA mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090DDC mov r2,r1
    c.r[1] += 3;  // 06090DDE add #3,r1
    c.r[2] = c.r[14];  // 06090DE0 mov r14,r2
    c.r[3] = c.r[14];  // 06090DE2 mov r14,r3
    c.r[3] += 1;  // 06090DE4 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090DE6 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090DE8 mov.b r2,@r1
    c.r[2] = ld32(0x06090E28u);  // 06090DEA mov.l 0x06090E28,r2
    c.r[1] = ld32(c.r[2]);  // 06090DEC mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090E1Cu);  // 06090DEE mov.w 0x06090E1C,r2
    st16(c.r[1], c.r[2]);  // 06090DF0 mov.w r2,@r1
    c.r[1] = ld32(0x06090E20u);  // 06090DF2 mov.l 0x06090E20,r1
    c.r[2] = 0x0u;  // 06090DF4 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090DF6 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090DF8 mov #0,r0
    goto L_06090E06;  // 06090DFA bra 0x06090E06 ; nop
L_06090E06:
    c.r[14] += 4;  // 06090E06 add #4,r14
    c.r[15] = c.r[14];  // 06090E08 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090E0A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090E0C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06090E0E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06090E10 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06090E12 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090E14 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090E16 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090E18 rts ; nop
}

void f_06090E2C(SH2Context& c) {
    ran[2133] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090E2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06090E2E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06090E30 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06090E32 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06090E34 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06090E36 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090E38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090E3A sts.l pr,@-r15
    c.r[15] -= 12;  // 06090E3C add #-12,r15
    c.r[14] = c.r[15];  // 06090E3E mov r15,r14
    c.r[9] = c.r[4];  // 06090E40 mov r4,r9
    c.r[10] = c.r[5];  // 06090E42 mov r5,r10
    c.r[8] = c.r[6];  // 06090E44 mov r6,r8
    st8(c.r[14], c.r[9]);  // 06090E46 mov.b r9,@r14
    c.r[11] = c.r[14];  // 06090E48 mov r14,r11
    c.r[13] = c.r[14];  // 06090E4A mov r14,r13
    c.r[13] += 1;  // 06090E4C add #1,r13
    st8(c.r[13], c.r[10]);  // 06090E4E mov.b r10,@r13
    c.r[12] = c.r[14];  // 06090E50 mov r14,r12
    c.r[7] = c.r[14];  // 06090E52 mov r14,r7
    c.r[7] += 2;  // 06090E54 add #2,r7
    st32(c.r[14] + 4, c.r[7]);  // 06090E56 mov.l r7,@(4,r14)
    c.r[7] = ld32(c.r[14] + 4);  // 06090E58 mov.l @(4,r14),r7
    st8(c.r[7], c.r[8]);  // 06090E5A mov.b r8,@r7
    c.r[1] = ld32(0x06090EFCu);  // 06090E5C mov.l 0x06090EFC,r1
    c.r[2] = ld32(c.r[1]);  // 06090E5E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090E60 tst r2,r2
    if (c.t) { goto L_06090E6A; }  // 06090E62 bt 0x06090E6A
    c.r[0] = 0x1u;  // 06090E64 mov #1,r0
    goto L_06090EE0;  // 06090E66 bra 0x06090EE0 ; nop
L_06090E6A:
    c.r[1] = ld32(0x06090EFCu);  // 06090E6A mov.l 0x06090EFC,r1
    c.r[2] = 0x1u;  // 06090E6C mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090E6E mov.l r2,@r1
    c.r[7] = ld32(0x06090F00u);  // 06090E70 mov.l 0x06090F00,r7
    st32(c.r[14] + 8, c.r[7]);  // 06090E72 mov.l r7,@(8,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 06090E74 mov.l @(8,r14),r7
    { const uint32_t x = c.r[7]; c.pr = 0x06090E7Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090E7Au) return; }  // 06090E76 jsr @r7 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090E7A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090E7C tst r1,r1
    if (!c.t) { goto L_06090E94; }  // 06090E7E bf 0x06090E94
    c.r[1] = ld32(0x06090EFCu);  // 06090E80 mov.l 0x06090EFC,r1
    c.r[2] = 0x0u;  // 06090E82 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090E84 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090E86 mov #1,r0
    goto L_06090EE0;  // 06090E88 bra 0x06090EE0 ; nop
L_06090E94:
    c.r[1] = ld32(0x06090F04u);  // 06090E94 mov.l 0x06090F04,r1
    c.r[2] = ld32(c.r[1]);  // 06090E96 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090E98 mov r2,r1
    c.r[1] += 2;  // 06090E9A add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090E9C mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 06090E9E mov.b r2,@r1
    c.r[1] = ld32(0x06090F04u);  // 06090EA0 mov.l 0x06090F04,r1
    c.r[2] = ld32(c.r[1]);  // 06090EA2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090EA4 mov r2,r1
    c.r[1] += 3;  // 06090EA6 add #3,r1
    c.r[2] = c.r[14];  // 06090EA8 mov r14,r2
    c.r[3] = c.r[14];  // 06090EAA mov r14,r3
    c.r[3] += 1;  // 06090EAC add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090EAE mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090EB0 mov.b r2,@r1
    c.r[1] = ld32(0x06090F04u);  // 06090EB2 mov.l 0x06090F04,r1
    c.r[2] = ld32(c.r[1]);  // 06090EB4 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06090EB6 mov r2,r1
    c.r[1] += 4;  // 06090EB8 add #4,r1
    c.r[2] = c.r[14];  // 06090EBA mov r14,r2
    c.r[3] = c.r[14];  // 06090EBC mov r14,r3
    c.r[3] += 2;  // 06090EBE add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06090EC0 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06090EC2 mov.b r2,@r1
    c.r[2] = ld32(0x06090F04u);  // 06090EC4 mov.l 0x06090F04,r2
    c.r[1] = ld32(c.r[2]);  // 06090EC6 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090EF8u);  // 06090EC8 mov.w 0x06090EF8,r2
    st16(c.r[1], c.r[2]);  // 06090ECA mov.w r2,@r1
    c.r[1] = ld32(0x06090EFCu);  // 06090ECC mov.l 0x06090EFC,r1
    c.r[2] = 0x0u;  // 06090ECE mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090ED0 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090ED2 mov #0,r0
    goto L_06090EE0;  // 06090ED4 bra 0x06090EE0 ; nop
L_06090EE0:
    c.r[14] += 12;  // 06090EE0 add #12,r14
    c.r[15] = c.r[14];  // 06090EE2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090EE4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090EE6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06090EE8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06090EEA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06090EEC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06090EEE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06090EF0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090EF2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090EF4 rts ; nop
}

void f_06090F08(SH2Context& c) {
    ran[2134] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090F08 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090F0A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06090F0C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06090F0E mov r15,r14
    c.r[1] = ld32(0x06090F70u);  // 06090F10 mov.l 0x06090F70,r1
    c.r[2] = ld32(c.r[1]);  // 06090F12 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06090F14 tst r2,r2
    if (c.t) { goto L_06090F1E; }  // 06090F16 bt 0x06090F1E
    c.r[0] = 0x1u;  // 06090F18 mov #1,r0
    goto L_06090F60;  // 06090F1A bra 0x06090F60 ; nop
L_06090F1E:
    c.r[1] = ld32(0x06090F70u);  // 06090F1E mov.l 0x06090F70,r1
    c.r[2] = 0x1u;  // 06090F20 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06090F22 mov.l r2,@r1
    c.r[8] = ld32(0x06090F74u);  // 06090F24 mov.l 0x06090F74,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06090F2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06090F2Au) return; }  // 06090F26 jsr @r8 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 06090F2A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06090F2C tst r1,r1
    if (!c.t) { goto L_06090F44; }  // 06090F2E bf 0x06090F44
    c.r[1] = ld32(0x06090F70u);  // 06090F30 mov.l 0x06090F70,r1
    c.r[2] = 0x0u;  // 06090F32 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090F34 mov.l r2,@r1
    c.r[0] = 0x1u;  // 06090F36 mov #1,r0
    goto L_06090F60;  // 06090F38 bra 0x06090F60 ; nop
L_06090F44:
    c.r[2] = ld32(0x06090F78u);  // 06090F44 mov.l 0x06090F78,r2
    c.r[1] = ld32(c.r[2]);  // 06090F46 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06090F6Cu);  // 06090F48 mov.w 0x06090F6C,r2
    st16(c.r[1], c.r[2]);  // 06090F4A mov.w r2,@r1
    c.r[1] = ld32(0x06090F70u);  // 06090F4C mov.l 0x06090F70,r1
    c.r[2] = 0x0u;  // 06090F4E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06090F50 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06090F52 mov #0,r0
    goto L_06090F60;  // 06090F54 bra 0x06090F60 ; nop
L_06090F60:
    c.r[15] = c.r[14];  // 06090F60 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06090F62 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06090F64 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06090F66 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06090F68 rts ; nop
}

void f_06090F7C(SH2Context& c) {
    ran[2135] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06090F7C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06090F7E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06090F80 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06090F82 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06090F84 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06090F86 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06090F88 mov.l r14,@-r15
    c.r[15] -= 100;  // 06090F8A add #-100,r15
    c.r[14] = c.r[15];  // 06090F8C mov r15,r14
    c.r[3] = c.r[6];  // 06090F8E mov r6,r3
    c.r[2] = c.r[7];  // 06090F90 mov r7,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x060910D6u);  // 06090F92 mov.w 0x060910D6,r8
    c.r[8] += c.r[14];  // 06090F94 add r14,r8
    c.r[1] = ld32(c.r[8]);  // 06090F96 mov.l @r8,r1
    st8(c.r[14], c.r[4]);  // 06090F98 mov.b r4,@r14
    c.r[7] = c.r[14];  // 06090F9A mov r14,r7
    c.r[10] = c.r[14];  // 06090F9C mov r14,r10
    c.r[10] += 1;  // 06090F9E add #1,r10
    st8(c.r[10], c.r[5]);  // 06090FA0 mov.b r5,@r10
    c.r[6] = c.r[14];  // 06090FA2 mov r14,r6
    c.r[11] = c.r[14];  // 06090FA4 mov r14,r11
    c.r[11] += 2;  // 06090FA6 add #2,r11
    st8(c.r[11], c.r[3]);  // 06090FA8 mov.b r3,@r11
    c.r[9] = 0x5Cu;  // 06090FAA mov #92,r9
    c.r[9] += c.r[14];  // 06090FAC add r14,r9
    st32(c.r[9], c.r[14]);  // 06090FAE mov.l r14,@r9
    c.r[12] = c.r[14];  // 06090FB0 mov r14,r12
    c.r[12] += 3;  // 06090FB2 add #3,r12
    st8(c.r[12], c.r[2]);  // 06090FB4 mov.b r2,@r12
    c.r[8] = 0x60u;  // 06090FB6 mov #96,r8
    c.r[8] += c.r[14];  // 06090FB8 add r14,r8
    st32(c.r[8], c.r[14]);  // 06090FBA mov.l r14,@r8
    c.r[13] = c.r[14];  // 06090FBC mov r14,r13
    c.r[13] += 4;  // 06090FBE add #4,r13
    st8(c.r[13], c.r[1]);  // 06090FC0 mov.b r1,@r13
    c.r[0] = ld32(0x060910DCu);  // 06090FC2 mov.l 0x060910DC,r0
    c.r[9] = ld32(c.r[0]);  // 06090FC4 mov.l @r0,r9
    st32(c.r[14] + 8, c.r[9]);  // 06090FC6 mov.l r9,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 06090FC8 mov.l @(8,r14),r0
    c.r[0] += 2;  // 06090FCA add #2,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06090FCC mov.b @r14,r9
    c.r[8] = 0xFu;  // 06090FCE mov #15,r8
    c.r[8] += c.r[14];  // 06090FD0 add r14,r8
    st8(c.r[8], c.r[9]);  // 06090FD2 mov.b r9,@r8
    c.r[8] = 0xFu;  // 06090FD4 mov #15,r8
    c.r[8] += c.r[14];  // 06090FD6 add r14,r8
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06090FD8 mov.b @r8,r8
    st8(c.r[0], c.r[8]);  // 06090FDA mov.b r8,@r0
    c.r[0] = ld32(0x060910DCu);  // 06090FDC mov.l 0x060910DC,r0
    c.r[9] = ld32(c.r[0]);  // 06090FDE mov.l @r0,r9
    st32(c.r[14] + 16, c.r[9]);  // 06090FE0 mov.l r9,@(16,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 06090FE2 mov.l @(16,r14),r0
    c.r[0] += 3;  // 06090FE4 add #3,r0
    st32(c.r[14] + 20, c.r[14]);  // 06090FE6 mov.l r14,@(20,r14)
    c.r[8] = c.r[14];  // 06090FE8 mov r14,r8
    c.r[8] += 1;  // 06090FEA add #1,r8
    st32(c.r[14] + 24, c.r[8]);  // 06090FEC mov.l r8,@(24,r14)
    c.r[9] = ld32(c.r[14] + 24);  // 06090FEE mov.l @(24,r14),r9
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06090FF0 mov.b @r9,r8
    c.r[9] = 0x1Fu;  // 06090FF2 mov #31,r9
    c.r[9] += c.r[14];  // 06090FF4 add r14,r9
    st8(c.r[9], c.r[8]);  // 06090FF6 mov.b r8,@r9
    c.r[9] = 0x1Fu;  // 06090FF8 mov #31,r9
    c.r[9] += c.r[14];  // 06090FFA add r14,r9
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06090FFC mov.b @r9,r9
    st8(c.r[0], c.r[9]);  // 06090FFE mov.b r9,@r0
    c.r[0] = ld32(0x060910DCu);  // 06091000 mov.l 0x060910DC,r0
    c.r[8] = ld32(c.r[0]);  // 06091002 mov.l @r0,r8
    st32(c.r[14] + 32, c.r[8]);  // 06091004 mov.l r8,@(32,r14)
    c.r[0] = ld32(c.r[14] + 32);  // 06091006 mov.l @(32,r14),r0
    c.r[0] += 4;  // 06091008 add #4,r0
    st32(c.r[14] + 36, c.r[14]);  // 0609100A mov.l r14,@(36,r14)
    c.r[9] = c.r[14];  // 0609100C mov r14,r9
    c.r[9] += 2;  // 0609100E add #2,r9
    st32(c.r[14] + 40, c.r[9]);  // 06091010 mov.l r9,@(40,r14)
    c.r[8] = ld32(c.r[14] + 40);  // 06091012 mov.l @(40,r14),r8
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06091014 mov.b @r8,r9
    c.r[8] = 0x2Fu;  // 06091016 mov #47,r8
    c.r[8] += c.r[14];  // 06091018 add r14,r8
    st8(c.r[8], c.r[9]);  // 0609101A mov.b r9,@r8
    c.r[8] = 0x2Fu;  // 0609101C mov #47,r8
    c.r[8] += c.r[14];  // 0609101E add r14,r8
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06091020 mov.b @r8,r8
    st8(c.r[0], c.r[8]);  // 06091022 mov.b r8,@r0
    c.r[0] = ld32(0x060910DCu);  // 06091024 mov.l 0x060910DC,r0
    c.r[9] = ld32(c.r[0]);  // 06091026 mov.l @r0,r9
    st32(c.r[14] + 48, c.r[9]);  // 06091028 mov.l r9,@(48,r14)
    c.r[0] = ld32(c.r[14] + 48);  // 0609102A mov.l @(48,r14),r0
    c.r[0] += 5;  // 0609102C add #5,r0
    st32(c.r[14] + 52, c.r[14]);  // 0609102E mov.l r14,@(52,r14)
    c.r[8] = c.r[14];  // 06091030 mov r14,r8
    c.r[8] += 3;  // 06091032 add #3,r8
    st32(c.r[14] + 56, c.r[8]);  // 06091034 mov.l r8,@(56,r14)
    c.r[9] = ld32(c.r[14] + 56);  // 06091036 mov.l @(56,r14),r9
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06091038 mov.b @r9,r8
    c.r[9] = 0x3Fu;  // 0609103A mov #63,r9
    c.r[9] += c.r[14];  // 0609103C add r14,r9
    st8(c.r[9], c.r[8]);  // 0609103E mov.b r8,@r9
    c.r[9] = 0x3Fu;  // 06091040 mov #63,r9
    c.r[9] += c.r[14];  // 06091042 add r14,r9
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06091044 mov.b @r9,r9
    st8(c.r[0], c.r[9]);  // 06091046 mov.b r9,@r0
    c.r[0] = ld32(0x060910DCu);  // 06091048 mov.l 0x060910DC,r0
    c.r[9] = ld32(c.r[0]);  // 0609104A mov.l @r0,r9
    c.r[8] = 0x40u;  // 0609104C mov #64,r8
    c.r[8] += c.r[14];  // 0609104E add r14,r8
    st32(c.r[8], c.r[9]);  // 06091050 mov.l r9,@r8
    c.r[8] = 0x40u;  // 06091052 mov #64,r8
    c.r[8] += c.r[14];  // 06091054 add r14,r8
    c.r[0] = ld32(c.r[8]);  // 06091056 mov.l @r8,r0
    c.r[0] += 6;  // 06091058 add #6,r0
    c.r[9] = 0x44u;  // 0609105A mov #68,r9
    c.r[9] += c.r[14];  // 0609105C add r14,r9
    st32(c.r[9], c.r[14]);  // 0609105E mov.l r14,@r9
    c.r[9] = c.r[14];  // 06091060 mov r14,r9
    c.r[9] += 4;  // 06091062 add #4,r9
    c.r[8] = 0x48u;  // 06091064 mov #72,r8
    c.r[8] += c.r[14];  // 06091066 add r14,r8
    st32(c.r[8], c.r[9]);  // 06091068 mov.l r9,@r8
    c.r[8] = 0x48u;  // 0609106A mov #72,r8
    c.r[8] += c.r[14];  // 0609106C add r14,r8
    c.r[9] = ld32(c.r[8]);  // 0609106E mov.l @r8,r9
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06091070 mov.b @r9,r9
    c.r[8] = 0x4Fu;  // 06091072 mov #79,r8
    c.r[8] += c.r[14];  // 06091074 add r14,r8
    st8(c.r[8], c.r[9]);  // 06091076 mov.b r9,@r8
    c.r[8] = 0x4Fu;  // 06091078 mov #79,r8
    c.r[8] += c.r[14];  // 0609107A add r14,r8
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609107C mov.b @r8,r8
    st8(c.r[0], c.r[8]);  // 0609107E mov.b r8,@r0
    c.r[8] = ld32(0x060910DCu);  // 06091080 mov.l 0x060910DC,r8
    c.r[9] = 0x50u;  // 06091082 mov #80,r9
    c.r[9] += c.r[14];  // 06091084 add r14,r9
    st32(c.r[9], c.r[8]);  // 06091086 mov.l r8,@r9
    c.r[9] = 0x50u;  // 06091088 mov #80,r9
    c.r[9] += c.r[14];  // 0609108A add r14,r9
    c.r[8] = ld32(c.r[9]);  // 0609108C mov.l @r9,r8
    c.r[0] = ld32(c.r[8]);  // 0609108E mov.l @r8,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x060910D8u);  // 06091090 mov.w 0x060910D8,r8
    c.r[9] = 0x56u;  // 06091092 mov #86,r9
    c.r[9] += c.r[14];  // 06091094 add r14,r9
    st16(c.r[9], c.r[8]);  // 06091096 mov.w r8,@r9
    c.r[9] = 0x56u;  // 06091098 mov #86,r9
    c.r[9] += c.r[14];  // 0609109A add r14,r9
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0609109C mov.w @r9,r9
    st16(c.r[0], c.r[9]);  // 0609109E mov.w r9,@r0
    c.r[0] = ld32(0x060910E0u);  // 060910A0 mov.l 0x060910E0,r0
    c.r[9] = 0x0u;  // 060910A2 mov #0,r9
    c.r[8] = 0x58u;  // 060910A4 mov #88,r8
    c.r[8] += c.r[14];  // 060910A6 add r14,r8
    st32(c.r[8], c.r[9]);  // 060910A8 mov.l r9,@r8
    c.r[8] = 0x58u;  // 060910AA mov #88,r8
    c.r[8] += c.r[14];  // 060910AC add r14,r8
    c.r[8] = ld32(c.r[8]);  // 060910AE mov.l @r8,r8
    st32(c.r[0], c.r[8]);  // 060910B0 mov.l r8,@r0
    c.r[0] = 0x0u;  // 060910B2 mov #0,r0
    goto L_060910C0;  // 060910B4 bra 0x060910C0 ; nop
L_060910C0:
    c.r[14] += 100;  // 060910C0 add #100,r14
    c.r[15] = c.r[14];  // 060910C2 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060910C4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060910C6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060910C8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060910CA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060910CC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060910CE mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060910D0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060910D2 rts ; nop
}

void f_060910E4(SH2Context& c) {
    ran[2136] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060910E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060910E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060910E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060910EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060910EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060910EE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060910F0 sts.l pr,@-r15
    c.r[15] -= 4;  // 060910F2 add #-4,r15
    c.r[14] = c.r[15];  // 060910F4 mov r15,r14
    c.r[8] = c.r[4];  // 060910F6 mov r4,r8
    c.r[9] = c.r[5];  // 060910F8 mov r5,r9
    st8(c.r[14], c.r[8]);  // 060910FA mov.b r8,@r14
    c.r[10] = c.r[14];  // 060910FC mov r14,r10
    c.r[11] = c.r[14];  // 060910FE mov r14,r11
    c.r[11] += 1;  // 06091100 add #1,r11
    st8(c.r[11], c.r[9]);  // 06091102 mov.b r9,@r11
    c.r[1] = ld32(0x0609118Cu);  // 06091104 mov.l 0x0609118C,r1
    c.r[2] = ld32(c.r[1]);  // 06091106 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06091108 tst r2,r2
    if (c.t) { goto L_06091112; }  // 0609110A bt 0x06091112
    c.r[0] = 0x1u;  // 0609110C mov #1,r0
    goto L_06091172;  // 0609110E bra 0x06091172 ; nop
L_06091112:
    c.r[1] = ld32(0x0609118Cu);  // 06091112 mov.l 0x0609118C,r1
    c.r[2] = 0x1u;  // 06091114 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06091116 mov.l r2,@r1
    c.r[12] = ld32(0x06091190u);  // 06091118 mov.l 0x06091190,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0609111Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609111Eu) return; }  // 0609111A jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0609111E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091120 tst r1,r1
    if (!c.t) { goto L_06091138; }  // 06091122 bf 0x06091138
    c.r[1] = ld32(0x0609118Cu);  // 06091124 mov.l 0x0609118C,r1
    c.r[2] = 0x0u;  // 06091126 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06091128 mov.l r2,@r1
    c.r[0] = 0x1u;  // 0609112A mov #1,r0
    goto L_06091172;  // 0609112C bra 0x06091172 ; nop
L_06091138:
    c.r[1] = ld32(0x06091194u);  // 06091138 mov.l 0x06091194,r1
    c.r[2] = ld32(c.r[1]);  // 0609113A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609113C mov r2,r1
    c.r[1] += 2;  // 0609113E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06091140 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 06091142 mov.b r2,@r1
    c.r[1] = ld32(0x06091194u);  // 06091144 mov.l 0x06091194,r1
    c.r[2] = ld32(c.r[1]);  // 06091146 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06091148 mov r2,r1
    c.r[1] += 3;  // 0609114A add #3,r1
    c.r[2] = c.r[14];  // 0609114C mov r14,r2
    c.r[3] = c.r[14];  // 0609114E mov r14,r3
    c.r[3] += 1;  // 06091150 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06091152 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06091154 mov.b r2,@r1
    c.r[2] = ld32(0x06091194u);  // 06091156 mov.l 0x06091194,r2
    c.r[1] = ld32(c.r[2]);  // 06091158 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06091188u);  // 0609115A mov.w 0x06091188,r2
    st16(c.r[1], c.r[2]);  // 0609115C mov.w r2,@r1
    c.r[1] = ld32(0x0609118Cu);  // 0609115E mov.l 0x0609118C,r1
    c.r[2] = 0x0u;  // 06091160 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06091162 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06091164 mov #0,r0
    goto L_06091172;  // 06091166 bra 0x06091172 ; nop
L_06091172:
    c.r[14] += 4;  // 06091172 add #4,r14
    c.r[15] = c.r[14];  // 06091174 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091176 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091178 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609117A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609117C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609117E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091180 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06091182 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06091184 rts ; nop
}

void f_06091198(SH2Context& c) {
    ran[2137] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091198 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609119A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609119C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609119E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060911A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060911A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060911A4 sts.l pr,@-r15
    c.r[15] -= 4;  // 060911A6 add #-4,r15
    c.r[14] = c.r[15];  // 060911A8 mov r15,r14
    c.r[8] = c.r[4];  // 060911AA mov r4,r8
    c.r[9] = c.r[5];  // 060911AC mov r5,r9
    st8(c.r[14], c.r[8]);  // 060911AE mov.b r8,@r14
    c.r[10] = c.r[14];  // 060911B0 mov r14,r10
    c.r[11] = c.r[14];  // 060911B2 mov r14,r11
    c.r[11] += 1;  // 060911B4 add #1,r11
    st8(c.r[11], c.r[9]);  // 060911B6 mov.b r9,@r11
    c.r[1] = ld32(0x0609125Cu);  // 060911B8 mov.l 0x0609125C,r1
    c.r[2] = ld32(c.r[1]);  // 060911BA mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060911BC tst r2,r2
    if (c.t) { goto L_060911C6; }  // 060911BE bt 0x060911C6
    c.r[0] = 0x1u;  // 060911C0 mov #1,r0
    goto L_06091244;  // 060911C2 bra 0x06091244 ; nop
L_060911C6:
    c.r[1] = ld32(0x0609125Cu);  // 060911C6 mov.l 0x0609125C,r1
    c.r[2] = 0x1u;  // 060911C8 mov #1,r2
    st32(c.r[1], c.r[2]);  // 060911CA mov.l r2,@r1
    c.r[12] = ld32(0x06091260u);  // 060911CC mov.l 0x06091260,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060911D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060911D2u) return; }  // 060911CE jsr @r12 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 060911D2 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060911D4 tst r1,r1
    if (!c.t) { goto L_060911EC; }  // 060911D6 bf 0x060911EC
    c.r[1] = ld32(0x0609125Cu);  // 060911D8 mov.l 0x0609125C,r1
    c.r[2] = 0x0u;  // 060911DA mov #0,r2
    st32(c.r[1], c.r[2]);  // 060911DC mov.l r2,@r1
    c.r[0] = 0x1u;  // 060911DE mov #1,r0
    goto L_06091244;  // 060911E0 bra 0x06091244 ; nop
L_060911EC:
    c.r[1] = ld32(0x06091264u);  // 060911EC mov.l 0x06091264,r1
    c.r[2] = ld32(c.r[1]);  // 060911EE mov.l @r1,r2
    c.r[1] = c.r[2];  // 060911F0 mov r2,r1
    c.r[1] += 2;  // 060911F2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060911F4 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 060911F6 mov.b r2,@r1
    c.r[1] = ld32(0x06091264u);  // 060911F8 mov.l 0x06091264,r1
    c.r[2] = ld32(c.r[1]);  // 060911FA mov.l @r1,r2
    c.r[1] = c.r[2];  // 060911FC mov r2,r1
    c.r[1] += 4;  // 060911FE add #4,r1
    c.r[2] = c.r[14];  // 06091200 mov r14,r2
    c.r[3] = c.r[14];  // 06091202 mov r14,r3
    c.r[3] += 1;  // 06091204 add #1,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06091206 mov.b @r3,r7
    c.r[2] = c.r[7] & 0xFFu;  // 06091208 extu.b r7,r2
    c.r[4] = c.r[2];  // 0609120A mov r2,r4
    c.r[2] = ld32(0x06091268u);  // 0609120C mov.l 0x06091268,r2
    { const uint32_t x = c.r[2]; c.pr = 0x06091212u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091212u) return; }  // 0609120E jsr @r2 ; nop
    c.r[2] = c.r[4];  // 06091212 mov r4,r2
    st8(c.r[1], c.r[2]);  // 06091214 mov.b r2,@r1
    c.r[1] = ld32(0x06091264u);  // 06091216 mov.l 0x06091264,r1
    c.r[2] = ld32(c.r[1]);  // 06091218 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609121A mov r2,r1
    c.r[1] += 5;  // 0609121C add #5,r1
    c.r[2] = c.r[14];  // 0609121E mov r14,r2
    c.r[3] = c.r[14];  // 06091220 mov r14,r3
    c.r[3] += 1;  // 06091222 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06091224 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06091226 mov.b r2,@r1
    c.r[2] = ld32(0x06091264u);  // 06091228 mov.l 0x06091264,r2
    c.r[1] = ld32(c.r[2]);  // 0609122A mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609125Au);  // 0609122C mov.w 0x0609125A,r2
    st16(c.r[1], c.r[2]);  // 0609122E mov.w r2,@r1
    c.r[1] = ld32(0x0609125Cu);  // 06091230 mov.l 0x0609125C,r1
    c.r[2] = 0x0u;  // 06091232 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06091234 mov.l r2,@r1
    c.r[0] = 0x0u;  // 06091236 mov #0,r0
    goto L_06091244;  // 06091238 bra 0x06091244 ; nop
L_06091244:
    c.r[14] += 4;  // 06091244 add #4,r14
    c.r[15] = c.r[14];  // 06091246 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091248 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609124A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609124C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609124E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06091250 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091252 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06091254 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06091256 rts ; nop
}

void f_0609126C(SH2Context& c) {
    ran[2138] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609126C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609126E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091270 sts.l pr,@-r15
    c.r[15] -= 8;  // 06091272 add #-8,r15
    c.r[14] = c.r[15];  // 06091274 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06091276 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06091278 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609127A mov.l @(4,r14),r1
    c.r[6] = c.r[1];  // 0609127C mov r1,r6
    c.r[5] = 0x0u;  // 0609127E mov #0,r5
    c.r[4] = ld32(c.r[14]);  // 06091280 mov.l @r14,r4
    c.r[8] = ld32(0x06091298u);  // 06091282 mov.l 0x06091298,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06091288u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091288u) return; }  // 06091284 jsr @r8 ; nop
    c.r[14] += 8;  // 06091288 add #8,r14
    c.r[15] = c.r[14];  // 0609128A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609128C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609128E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06091290 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06091292 rts ; nop
}

void f_0609129C(SH2Context& c) {
    ran[2139] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609129C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609129E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060912A0 mov.l r14,@-r15
    c.r[15] -= 20;  // 060912A2 add #-20,r15
    c.r[14] = c.r[15];  // 060912A4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060912A6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060912A8 mov.l r5,@(4,r14)
    c.r[2] = c.r[6];  // 060912AA mov r6,r2
    c.r[1] = c.r[7];  // 060912AC mov r7,r1
    c.r[3] = c.r[14];  // 060912AE mov r14,r3
    c.r[6] = c.r[14];  // 060912B0 mov r14,r6
    c.r[6] += 8;  // 060912B2 add #8,r6
    st16(c.r[6], c.r[2]);  // 060912B4 mov.w r2,@r6
    c.r[7] = c.r[14];  // 060912B6 mov r14,r7
    c.r[5] = c.r[14];  // 060912B8 mov r14,r5
    c.r[5] += 10;  // 060912BA add #10,r5
    st16(c.r[5], c.r[1]);  // 060912BC mov.w r1,@r5
    c.r[4] = 0x0u;  // 060912BE mov #0,r4
    st32(c.r[14] + 12, c.r[4]);  // 060912C0 mov.l r4,@(12,r14)
    c.r[0] = ld32(0x0609137Cu);  // 060912C2 mov.l 0x0609137C,r0
    c.r[4] = ld32(c.r[0]);  // 060912C4 mov.l @r0,r4
    c.r[0] = ld32(c.r[4]);  // 060912C6 mov.l @r4,r0
    st32(c.r[14] + 16, c.r[0]);  // 060912C8 mov.l r0,@(16,r14)
    c.r[4] = 0x1u;  // 060912CA mov #1,r4
    st32(c.r[14] + 12, c.r[4]);  // 060912CC mov.l r4,@(12,r14)
L_060912CE:
    c.r[4] = ld32(c.r[14] + 16);  // 060912CE mov.l @(16,r14),r4
    c.r[0] = ld32(0x06091380u);  // 060912D0 mov.l 0x06091380,r0
    c.r[4] &= c.r[0];  // 060912D2 and r0,r4
    c.r[0] = ld32(0x06091380u);  // 060912D4 mov.l 0x06091380,r0
    c.t = c.r[4] == c.r[0];  // 060912D6 cmp/eq r0,r4
    if (!c.t) { goto L_060912DE; }  // 060912D8 bf 0x060912DE
    goto L_0609136C;  // 060912DA bra 0x0609136C ; nop
L_060912DE:
    c.r[4] = ld32(c.r[14] + 16);  // 060912DE mov.l @(16,r14),r4
    c.r[8] = ld32(0x06091384u);  // 060912E0 mov.l 0x06091384,r8
    c.r[0] = c.r[4];  // 060912E2 mov r4,r0
    c.r[0] &= c.r[8];  // 060912E4 and r8,r0
    c.r[4] = c.r[0];  // 060912E6 mov r0,r4
    c.r[4] >>= 16;  // 060912E8 shlr16 r4
    c.r[4] >>= 8;  // 060912EA shlr8 r4
    c.r[4] >>= 2;  // 060912EC shlr2 r4
    c.r[4] >>= 2;  // 060912EE shlr2 r4
    c.r[0] = c.r[14];  // 060912F0 mov r14,r0
    c.r[8] = c.r[14];  // 060912F2 mov r14,r8
    c.r[8] += 8;  // 060912F4 add #8,r8
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060912F6 mov.w @r8,r9
    c.r[0] = c.r[9] & 0xFFFFu;  // 060912F8 extu.w r9,r0
    c.t = c.r[4] == c.r[0];  // 060912FA cmp/eq r0,r4
    if (!c.t) { goto L_0609134A; }  // 060912FC bf 0x0609134A
    c.r[4] = ld32(c.r[14] + 16);  // 060912FE mov.l @(16,r14),r4
    c.r[8] = ld32(0x06091388u);  // 06091300 mov.l 0x06091388,r8
    c.r[0] = c.r[4];  // 06091302 mov r4,r0
    c.r[0] &= c.r[8];  // 06091304 and r8,r0
    c.r[4] = c.r[0];  // 06091306 mov r0,r4
    c.r[4] >>= 16;  // 06091308 shlr16 r4
    c.r[4] >>= 8;  // 0609130A shlr8 r4
    c.r[0] = c.r[14];  // 0609130C mov r14,r0
    c.r[8] = c.r[14];  // 0609130E mov r14,r8
    c.r[8] += 10;  // 06091310 add #10,r8
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06091312 mov.w @r8,r9
    c.r[0] = c.r[9] & 0xFFFFu;  // 06091314 extu.w r9,r0
    c.t = c.r[4] == c.r[0];  // 06091316 cmp/eq r0,r4
    if (!c.t) { goto L_0609134A; }  // 06091318 bf 0x0609134A
    c.r[4] = ld32(c.r[14]);  // 0609131A mov.l @r14,r4
    c.r[0] = ld32(c.r[14] + 16);  // 0609131C mov.l @(16,r14),r0
    c.r[8] = ld32(0x0609138Cu);  // 0609131E mov.l 0x0609138C,r8
    c.r[0] &= c.r[8];  // 06091320 and r8,r0
    c.r[8] = ld32(0x06091390u);  // 06091322 mov.l 0x06091390,r8
    c.r[0] += c.r[8];  // 06091324 add r8,r0
    st32(c.r[4], c.r[0]);  // 06091326 mov.l r0,@r4
    c.r[4] = ld32(c.r[14] + 4);  // 06091328 mov.l @(4,r14),r4
    c.r[0] = ld32(0x0609137Cu);  // 0609132A mov.l 0x0609137C,r0
    c.r[9] = ld32(c.r[14] + 12);  // 0609132C mov.l @(12,r14),r9
    c.r[8] = c.r[9];  // 0609132E mov r9,r8
    c.r[8] -= 1;  // 06091330 add #-1,r8
    c.r[9] = c.r[8];  // 06091332 mov r8,r9
    c.r[8] = c.r[9];  // 06091334 mov r9,r8
    c.r[8] <<= 2;  // 06091336 shll2 r8
    c.r[8] += c.r[8];  // 06091338 add r8,r8
    c.r[9] = ld32(c.r[0]);  // 0609133A mov.l @r0,r9
    c.r[0] = c.r[8];  // 0609133C mov r8,r0
    c.r[0] += c.r[9];  // 0609133E add r9,r0
    c.r[8] = c.r[0];  // 06091340 mov r0,r8
    c.r[8] += 4;  // 06091342 add #4,r8
    st32(c.r[4], c.r[8]);  // 06091344 mov.l r8,@r4
    goto L_0609136C;  // 06091346 bra 0x0609136C ; nop
L_0609134A:
    c.r[4] = ld32(c.r[14] + 12);  // 0609134A mov.l @(12,r14),r4
    c.r[0] = c.r[4];  // 0609134C mov r4,r0
    c.r[4] = c.r[0];  // 0609134E mov r0,r4
    c.r[4] <<= 2;  // 06091350 shll2 r4
    c.r[4] += c.r[4];  // 06091352 add r4,r4
    c.r[8] = ld32(0x0609137Cu);  // 06091354 mov.l 0x0609137C,r8
    c.r[0] = ld32(c.r[8]);  // 06091356 mov.l @r8,r0
    c.r[4] += c.r[0];  // 06091358 add r0,r4
    c.r[0] = ld32(c.r[4]);  // 0609135A mov.l @r4,r0
    st32(c.r[14] + 16, c.r[0]);  // 0609135C mov.l r0,@(16,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 0609135E mov.l @(12,r14),r0
    c.r[4] = c.r[0];  // 06091360 mov r0,r4
    c.r[4] += 1;  // 06091362 add #1,r4
    c.r[0] = c.r[4];  // 06091364 mov r4,r0
    st32(c.r[14] + 12, c.r[0]);  // 06091366 mov.l r0,@(12,r14)
    SH2_POLL(c); goto L_060912CE;  // 06091368 bra 0x060912CE ; nop
L_0609136C:
    c.r[14] += 20;  // 0609136C add #20,r14
    c.r[15] = c.r[14];  // 0609136E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091370 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091372 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06091374 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06091376 rts ; nop
}

void f_06091394(SH2Context& c) {
    ran[2140] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091394 mov.l r14,@-r15
    c.r[15] -= 4;  // 06091396 add #-4,r15
    c.r[14] = c.r[15];  // 06091398 mov r15,r14
    c.r[1] = c.r[4];  // 0609139A mov r4,r1
    st8(c.r[14], c.r[1]);  // 0609139C mov.b r1,@r14
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609139E mov.b @r14,r2
    c.t = (int32_t)c.r[2] >= 0;  // 060913A0 cmp/pz r2
    if (!c.t) { goto L_060913AC; }  // 060913A2 bf 0x060913AC
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060913A4 mov.b @r14,r2
    c.r[0] = c.r[2] & 0xFFFFu;  // 060913A6 extu.w r2,r0
    goto L_060913B8;  // 060913A8 bra 0x060913B8 ; nop
L_060913AC:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060913AC mov.b @r14,r2
    c.r[3] = ~c.r[2];  // 060913AE not r2,r3
    c.r[2] = c.r[3];  // 060913B0 mov r3,r2
    c.r[3] = c.r[2];  // 060913B2 mov r2,r3
    c.r[3] += 17;  // 060913B4 add #17,r3
    c.r[0] = c.r[3] & 0xFFFFu;  // 060913B6 extu.w r3,r0
L_060913B8:
    goto L_060913BC;  // 060913B8 bra 0x060913BC ; nop
L_060913BC:
    c.r[14] += 4;  // 060913BC add #4,r14
    c.r[15] = c.r[14];  // 060913BE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060913C0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060913C2 rts ; nop
}

void f_060913C8(SH2Context& c) {
    ran[2141] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060913C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060913CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060913CC sts.l pr,@-r15
    c.r[15] -= 12;  // 060913CE add #-12,r15
    c.r[14] = c.r[15];  // 060913D0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060913D2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060913D4 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 060913D6 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060913D8 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 060913DA mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 060913DC mov r1,r6
    c.r[5] = c.r[2];  // 060913DE mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 060913E0 mov.l @r14,r4
    c.r[8] = ld32(0x060913F8u);  // 060913E2 mov.l 0x060913F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060913E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060913E8u) return; }  // 060913E4 jsr @r8 ; nop
    c.r[14] += 12;  // 060913E8 add #12,r14
    c.r[15] = c.r[14];  // 060913EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060913EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060913EE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060913F0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060913F2 rts ; nop
}

void f_060913FC(SH2Context& c) {
    ran[2142] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060913FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060913FE mov r15,r14
    c.r[2] = ld32(0x060914C8u);  // 06091400 mov.l 0x060914C8,r2
    c.r[1] = ld32(c.r[2]);  // 06091402 mov.l @r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06091404 mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06091406 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091408 tst r1,r1
    if (c.t) { goto L_06091476; }  // 0609140A bt 0x06091476
    c.r[1] = ld32(0x060914C8u);  // 0609140C mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914CCu);  // 0609140E mov.l 0x060914CC,r2
    c.r[3] = ld32(c.r[2]);  // 06091410 mov.l @r2,r3
    c.r[2] = c.r[3];  // 06091412 mov r3,r2
    c.r[2] += 112;  // 06091414 add #112,r2
    c.r[1] = ld32(c.r[1]);  // 06091416 mov.l @r1,r1
    c.t = c.r[1] >= c.r[2];  // 06091418 cmp/hs r2,r1
    if (!c.t) { goto L_06091426; }  // 0609141A bf 0x06091426
    c.r[0] = 0x0u;  // 0609141C mov #0,r0
    goto L_060914BE;  // 0609141E bra 0x060914BE ; nop
L_06091426:
    c.r[1] = ld32(0x060914C8u);  // 06091426 mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914C8u);  // 06091428 mov.l 0x060914C8,r2
    c.r[3] = ld32(c.r[2]);  // 0609142A mov.l @r2,r3
    c.r[2] = c.r[3];  // 0609142C mov r3,r2
    c.r[2] += 16;  // 0609142E add #16,r2
    st32(c.r[1], c.r[2]);  // 06091430 mov.l r2,@r1
L_06091432:
    c.r[1] = ld32(0x060914C8u);  // 06091432 mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914CCu);  // 06091434 mov.l 0x060914CC,r2
    c.r[3] = ld32(c.r[2]);  // 06091436 mov.l @r2,r3
    c.r[2] = c.r[3];  // 06091438 mov r3,r2
    c.r[2] += 112;  // 0609143A add #112,r2
    c.r[1] = ld32(c.r[1]);  // 0609143C mov.l @r1,r1
    c.t = c.r[1] >= c.r[2];  // 0609143E cmp/hs r2,r1
    if (!c.t) { goto L_06091446; }  // 06091440 bf 0x06091446
    goto L_0609146C;  // 06091442 bra 0x0609146C ; nop
L_06091446:
    c.r[2] = ld32(0x060914C8u);  // 06091446 mov.l 0x060914C8,r2
    c.r[1] = ld32(c.r[2]);  // 06091448 mov.l @r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609144A mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0609144C extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609144E tst r1,r1
    if (c.t) { goto L_06091462; }  // 06091450 bt 0x06091462
    c.r[1] = ld32(0x060914C8u);  // 06091452 mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914C8u);  // 06091454 mov.l 0x060914C8,r2
    c.r[3] = ld32(c.r[2]);  // 06091456 mov.l @r2,r3
    c.r[2] = c.r[3];  // 06091458 mov r3,r2
    c.r[2] += 16;  // 0609145A add #16,r2
    st32(c.r[1], c.r[2]);  // 0609145C mov.l r2,@r1
    goto L_06091468;  // 0609145E bra 0x06091468 ; nop
L_06091462:
    c.r[0] = 0x1u;  // 06091462 mov #1,r0
    goto L_060914BE;  // 06091464 bra 0x060914BE ; nop
L_06091468:
    SH2_POLL(c); goto L_06091432;  // 06091468 bra 0x06091432 ; nop
L_0609146C:
    c.r[0] = 0x0u;  // 0609146C mov #0,r0
    goto L_060914BE;  // 0609146E bra 0x060914BE ; nop
L_06091476:
    c.r[1] = ld32(0x060914C8u);  // 06091476 mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914CCu);  // 06091478 mov.l 0x060914CC,r2
    c.r[3] = ld32(c.r[2]);  // 0609147A mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0609147C mov.l r3,@r1
L_0609147E:
    c.r[1] = ld32(0x060914C8u);  // 0609147E mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914CCu);  // 06091480 mov.l 0x060914CC,r2
    c.r[3] = ld32(c.r[2]);  // 06091482 mov.l @r2,r3
    c.r[2] = c.r[3];  // 06091484 mov r3,r2
    c.r[2] += 112;  // 06091486 add #112,r2
    c.r[1] = ld32(c.r[1]);  // 06091488 mov.l @r1,r1
    c.t = c.r[1] >= c.r[2];  // 0609148A cmp/hs r2,r1
    if (!c.t) { goto L_06091492; }  // 0609148C bf 0x06091492
    goto L_060914B8;  // 0609148E bra 0x060914B8 ; nop
L_06091492:
    c.r[2] = ld32(0x060914C8u);  // 06091492 mov.l 0x060914C8,r2
    c.r[1] = ld32(c.r[2]);  // 06091494 mov.l @r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06091496 mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06091498 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609149A tst r1,r1
    if (c.t) { goto L_060914AE; }  // 0609149C bt 0x060914AE
    c.r[1] = ld32(0x060914C8u);  // 0609149E mov.l 0x060914C8,r1
    c.r[2] = ld32(0x060914C8u);  // 060914A0 mov.l 0x060914C8,r2
    c.r[3] = ld32(c.r[2]);  // 060914A2 mov.l @r2,r3
    c.r[2] = c.r[3];  // 060914A4 mov r3,r2
    c.r[2] += 16;  // 060914A6 add #16,r2
    st32(c.r[1], c.r[2]);  // 060914A8 mov.l r2,@r1
    goto L_060914B4;  // 060914AA bra 0x060914B4 ; nop
L_060914AE:
    c.r[0] = 0x1u;  // 060914AE mov #1,r0
    goto L_060914BE;  // 060914B0 bra 0x060914BE ; nop
L_060914B4:
    SH2_POLL(c); goto L_0609147E;  // 060914B4 bra 0x0609147E ; nop
L_060914B8:
    c.r[0] = 0x0u;  // 060914B8 mov #0,r0
    goto L_060914BE;  // 060914BA bra 0x060914BE ; nop
L_060914BE:
    c.r[15] = c.r[14];  // 060914BE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060914C0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060914C2 rts ; nop
}

void f_060914D0(SH2Context& c) {
    ran[2143] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060914D0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060914D2 mov r15,r14
    c.r[0] = ld32(0x060914DCu);  // 060914D4 mov.l 0x060914DC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060914D6 rts ; mov.l @r15+,r14
}

void f_060914E0(SH2Context& c) {
    ran[2144] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060914E0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060914E2 mov r15,r14
    c.r[1] = ld32(0x060914F0u);  // 060914E4 mov.l 0x060914F0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060914E6 mov.w @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060914E8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFFFu; c.pc = x; return; }  // 060914EA rts ; extu.w r1,r0
}

void f_060914F4(SH2Context& c) {
    ran[2145] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060914F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060914F6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060914F8 mov r15,r14
    c.r[0] = c.r[4];  // 060914FA mov r4,r0
    c.r[3] = ld32(0x06091518u);  // 060914FC mov.l 0x06091518,r3
    c.r[2] = ld32(0x0609151Cu);  // 060914FE mov.l 0x0609151C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06091500 mov.w @r3,r1
    c.r[0] |= 0x1u;  // 06091502 or #1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06091504 mov.w @r2,r2
    c.r[1] |= c.r[2];  // 06091506 or r2,r1
    st16(c.r[3], c.r[1]);  // 06091508 mov.w r1,@r3
    c.r[1] = ld32(0x06091520u);  // 0609150A mov.l 0x06091520,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091510u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091510u) return; }  // 0609150C jsr @r1 ; mov r0,r4
    c.r[15] = c.r[14];  // 06091510 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091512 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091514 rts ; mov.l @r15+,r14
}

void f_06091524(SH2Context& c) {
    ran[2146] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091524 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06091526 mov r15,r14
    c.r[1] = ld32(0x06091530u);  // 06091528 mov.l 0x06091530,r1
    st16(c.r[1], c.r[4]);  // 0609152A mov.w r4,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609152C rts ; mov.l @r15+,r14
}

void f_06091534(SH2Context& c) {
    ran[2147] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091534 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091536 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091538 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609153A mov r15,r14
    c.r[8] = (uint32_t)(int16_t)ld16(0x06091552u);  // 0609153C mov.w 0x06091552,r8
    c.r[1] = ld32(0x06091554u);  // 0609153E mov.l 0x06091554,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091544u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091544u) return; }  // 06091540 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06091558u);  // 06091544 mov.l 0x06091558,r1
    st16(c.r[1], c.r[8]);  // 06091546 mov.w r8,@r1
    c.r[15] = c.r[14];  // 06091548 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609154A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609154C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609154E rts ; mov.l @r15+,r8
}

void f_0609155C(SH2Context& c) {
    ran[2148] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609155C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609155E mov r15,r14
    c.r[2] = ld32(0x0609156Cu);  // 06091560 mov.l 0x0609156C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06091562 mov.w @r2,r1
    c.r[1] |= c.r[4];  // 06091564 or r4,r1
    st16(c.r[2], c.r[1]);  // 06091566 mov.w r1,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091568 rts ; mov.l @r15+,r14
}

void f_06091570(SH2Context& c) {
    ran[2149] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091570 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06091572 mov r15,r14
    c.r[1] = ld32(0x06091580u);  // 06091574 mov.l 0x06091580,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06091576 mov.w @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091578 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFFFu; c.pc = x; return; }  // 0609157A rts ; extu.w r1,r0
}

void f_06091590(SH2Context& c) {
    ran[2150] = 1;
    c.r[5] &= c.r[8];  // 06091590 and r8,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[0]);  // 06091592 mov.b @(r0,r0),r0
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091594 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06091596 mov r15,r14
    c.r[0] = ld32(0x060915A0u);  // 06091598 mov.l 0x060915A0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609159A rts ; mov.l @r15+,r14
}

void f_060915A4(SH2Context& c) {
    ran[2151] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060915A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060915A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060915A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060915AA sts.l pr,@-r15
    c.r[15] -= 4;  // 060915AC add #-4,r15
    c.r[14] = c.r[15];  // 060915AE mov r15,r14
    c.r[8] = c.r[4];  // 060915B0 mov r4,r8
    c.r[9] = c.r[5];  // 060915B2 mov r5,r9
    c.r[0] = ld32(0x060915F4u);  // 060915B4 mov.l 0x060915F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060915BAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060915BAu) return; }  // 060915B6 jsr @r0 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060915BA tst r0,r0
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_060915E6; } }  // 060915BC bf/s 0x060915E6 ; mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[8];  // 060915C0 cmp/ge r8,r2
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060915D4; } }  // 060915C2 bt/s 0x060915D4 ; mov r9,r5
    c.r[3] = ld32(0x060915F8u);  // 060915C6 mov.l 0x060915F8,r3
L_060915C8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060915C8 mov.w @r3,r1
    c.r[2] += 1;  // 060915CA add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[8];  // 060915CC cmp/ge r8,r2
    st16(c.r[5], c.r[1]);  // 060915CE mov.w r1,@r5
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_060915C8; } }  // 060915D0 bf/s 0x060915C8 ; add #2,r5
L_060915D4:
    c.r[0] = ld32(0x060915FCu);  // 060915D4 mov.l 0x060915FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060915DAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060915DAu) return; }  // 060915D6 jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060915DA tst r0,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_060915E6; } }  // 060915DC bf/s 0x060915E6 ; mov.l @r14,r1
    c.t = c.r[8] == c.r[1];  // 060915E0 cmp/eq r1,r8
    if (c.t) { goto L_060915E6; }  // 060915E2 bt 0x060915E6
    c.r[0] = 0xFFFFFFF9u;  // 060915E4 mov #-7,r0
L_060915E6:
    c.r[14] += 4;  // 060915E6 add #4,r14
    c.r[15] = c.r[14];  // 060915E8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060915EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060915EC mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060915EE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060915F0 rts ; mov.l @r15+,r8
}

void f_06091600(SH2Context& c) {
    ran[2152] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091600 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091602 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091604 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091606 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06091608 mov r15,r14
    c.r[0] = sh2_get_sr(c);  // 0609160A stc sr,r0
    c.r[0] &= 0xF0u;  // 0609160C and #240,r0
    c.r[8] = c.r[0];  // 0609160E mov r0,r8
    c.r[8] >>= 2;  // 06091610 shlr2 r8
    c.r[8] >>= 2;  // 06091612 shlr2 r8
    c.r[0] = sh2_get_sr(c);  // 06091614 stc sr,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609163Au);  // 06091616 mov.w 0x0609163A,r9
    c.r[0] |= 0xF0u;  // 06091618 or #240,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 0609161A ldc r0,sr
    c.r[0] = ld32(0x0609163Cu);  // 0609161C mov.l 0x0609163C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091622u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091622u) return; }  // 0609161E jsr @r0 ; nop
    c.r[1] = sh2_get_sr(c);  // 06091622 stc sr,r1
    c.r[1] &= c.r[9];  // 06091624 and r9,r1
    c.r[8] <<= 2;  // 06091626 shll2 r8
    c.r[8] <<= 2;  // 06091628 shll2 r8
    c.r[1] |= c.r[8];  // 0609162A or r8,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0609162C ldc r1,sr
    c.r[15] = c.r[14];  // 0609162E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091630 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091632 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091634 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091636 rts ; mov.l @r15+,r8
}

void f_06091640(SH2Context& c) {
    ran[2153] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091640 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091642 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06091644 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06091646 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091648 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609164A sts.l pr,@-r15
    c.r[15] -= 4;  // 0609164C add #-4,r15
    c.r[14] = c.r[15];  // 0609164E mov r15,r14
    c.r[9] = c.r[4];  // 06091650 mov r4,r9
    c.r[11] = c.r[5];  // 06091652 mov r5,r11
    c.r[10] = c.r[6];  // 06091654 mov r6,r10
    c.r[8] = ld32(0x060916E4u);  // 06091656 mov.l 0x060916E4,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06091658 mov.w @r8,r2
    c.r[1] = ld32(0x060916E8u);  // 0609165A mov.l 0x060916E8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609165C mov.w @r1,r1
    c.r[0] = c.r[2];  // 0609165E mov r2,r0
    c.r[0] |= c.r[1];  // 06091660 or r1,r0
    c.r[1] = c.r[0] & 0xFFFFu;  // 06091662 extu.w r0,r1
    c.r[1] &= c.r[9];  // 06091664 and r9,r1
    c.t = c.r[1] == c.r[9];  // 06091666 cmp/eq r9,r1
    { const bool k = c.t; st16(c.r[8], c.r[0]); if (k) { goto L_06091670; } }  // 06091668 bt/s 0x06091670 ; mov.w r0,@r8
    c.r[0] = 0xFFFFFFFFu; goto L_060916CE;  // 0609166C bra 0x060916CE ; mov #-1,r0
L_06091670:
    c.r[0] &= 0x1u;  // 06091670 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06091672 tst r0,r0
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_0609167C; } }  // 06091674 bf/s 0x0609167C ; mov #1,r4
    c.r[0] = 0xFFFFFFFEu; goto L_060916CE;  // 06091678 bra 0x060916CE ; mov #-2,r0
L_0609167C:
    c.r[4] |= c.r[9];  // 0609167C or r9,r4
    c.r[1] = ld32(0x060916ECu);  // 0609167E mov.l 0x060916EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091684u; c.r[4] = ~c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091684u) return; }  // 06091680 jsr @r1 ; not r4,r4
    c.r[2] = ld32(0x060916F0u);  // 06091684 mov.l 0x060916F0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06091686 mov.w @r8,r1
    c.r[1] &= c.r[2];  // 06091688 and r2,r1
    st16(c.r[8], c.r[1]);  // 0609168A mov.w r1,@r8
    c.r[1] = ld32(0x060916F4u);  // 0609168C mov.l 0x060916F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091692u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091692u) return; }  // 0609168E jsr @r1 ; mov r11,r4
    c.r[0] = ld32(0x060916F8u);  // 06091692 mov.l 0x060916F8,r0
    c.r[5] = c.r[14];  // 06091694 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609169Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609169Au) return; }  // 06091696 jsr @r0 ; mov #1,r4
    c.r[8] = c.r[0];  // 0609169A mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609169C tst r8,r8
    if (!c.t) { goto L_060916CE; }  // 0609169E bf 0x060916CE
    c.r[1] = ld32(0x060916FCu);  // 060916A0 mov.l 0x060916FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060916A6u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060916A6u) return; }  // 060916A2 jsr @r1 ; mov r10,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060916A6 mov.b @r10,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060916A8 extu.b r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060916E0u);  // 060916AA mov.w 0x060916E0,r1
    c.t = c.r[0] == c.r[1];  // 060916AC cmp/eq r1,r0
    { const bool k = !c.t; c.r[0] &= 0x80u; if (k) { goto L_060916B6; } }  // 060916AE bf/s 0x060916B6 ; and #128,r0
    c.r[8] = 0xFFFFFFFBu; goto L_060916BE;  // 060916B2 bra 0x060916BE ; mov #-5,r8
L_060916B6:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060916B6 tst r0,r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060916C0; } }  // 060916B8 bt/s 0x060916C0 ; tst r8,r8
    c.r[8] = 0xFFFFFFFAu;  // 060916BC mov #-6,r8
L_060916BE:
    c.t = (c.r[8] & c.r[8]) == 0;  // 060916BE tst r8,r8
L_060916C0:
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_060916CE; } }  // 060916C0 bf/s 0x060916CE ; mov r8,r0
    c.r[3] = ld32(0x060916E4u);  // 060916C4 mov.l 0x060916E4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060916C6 mov.w @r3,r1
    c.r[2] = ~c.r[9];  // 060916C8 not r9,r2
    c.r[1] &= c.r[2];  // 060916CA and r2,r1
    st16(c.r[3], c.r[1]);  // 060916CC mov.w r1,@r3
L_060916CE:
    c.r[14] += 4;  // 060916CE add #4,r14
    c.r[15] = c.r[14];  // 060916D0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060916D2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060916D4 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060916D6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060916D8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060916DA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060916DC rts ; mov.l @r15+,r8
}

void f_06091700(SH2Context& c) {
    ran[2154] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091700 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06091702 mov r15,r14
    c.r[0] = 0xFFFFFFFDu;  // 06091704 mov #-3,r0
    c.r[3] = 0x0u;  // 06091706 mov #0,r3
    c.r[6] = ld32(0x0609172Cu);  // 06091708 mov.l 0x0609172C,r6
    c.r[7] = ld32(0x06091730u);  // 0609170A mov.l 0x06091730,r7
L_0609170C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0609170C mov.w @r6,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0609170E extu.w r1,r2
    c.r[1] = c.r[2];  // 06091710 mov r2,r1
    c.r[1] &= c.r[4];  // 06091712 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091714 tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_06091720; } }  // 06091716 bt/s 0x06091720 ; add #1,r3
    c.r[0] = 0x0u;  // 0609171A mov #0,r0
    st32(c.r[5], c.r[2]); goto L_06091724;  // 0609171C bra 0x06091724 ; mov.l r2,@r5
L_06091720:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06091720 cmp/gt r7,r3
    if (!c.t) { SH2_POLL(c); goto L_0609170C; }  // 06091722 bf 0x0609170C
L_06091724:
    c.r[15] = c.r[14];  // 06091724 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091726 rts ; mov.l @r15+,r14
}

void f_06091734(SH2Context& c) {
    ran[2155] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091734 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06091736 mov r15,r14
    c.r[2] = ld32(0x06091760u);  // 06091738 mov.l 0x06091760,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0609173A mov.w @r4,r1
    st16(c.r[2], c.r[1]);  // 0609173C mov.w r1,@r2
    c.r[1] = c.r[4];  // 0609173E mov r4,r1
    c.r[1] += 2;  // 06091740 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06091742 mov.w @r1,r1
    c.r[2] = ld32(0x06091764u);  // 06091744 mov.l 0x06091764,r2
    st16(c.r[2], c.r[1]);  // 06091746 mov.w r1,@r2
    c.r[2] = ld32(0x06091768u);  // 06091748 mov.l 0x06091768,r2
    c.r[1] = c.r[4];  // 0609174A mov r4,r1
    c.r[1] += 4;  // 0609174C add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609174E mov.w @r1,r1
    c.r[4] += 6;  // 06091750 add #6,r4
    st16(c.r[2], c.r[1]);  // 06091752 mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06091754 mov.w @r4,r1
    c.r[2] = ld32(0x0609176Cu);  // 06091756 mov.l 0x0609176C,r2
    st16(c.r[2], c.r[1]);  // 06091758 mov.w r1,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609175A rts ; mov.l @r15+,r14
}

void f_06091770(SH2Context& c) {
    ran[2156] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091770 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06091772 mov r15,r14
    c.r[1] = ld32(0x0609179Cu);  // 06091774 mov.l 0x0609179C,r1
    c.r[2] = c.r[4];  // 06091776 mov r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06091778 mov.w @r1,r1
    c.r[2] += 2;  // 0609177A add #2,r2
    st16(c.r[4], c.r[1]);  // 0609177C mov.w r1,@r4
    c.r[1] = ld32(0x060917A0u);  // 0609177E mov.l 0x060917A0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06091780 mov.w @r1,r1
    st16(c.r[2], c.r[1]);  // 06091782 mov.w r1,@r2
    c.r[2] = c.r[4];  // 06091784 mov r4,r2
    c.r[1] = ld32(0x060917A4u);  // 06091786 mov.l 0x060917A4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06091788 mov.w @r1,r1
    c.r[2] += 4;  // 0609178A add #4,r2
    st16(c.r[2], c.r[1]);  // 0609178C mov.w r1,@r2
    c.r[1] = ld32(0x060917A8u);  // 0609178E mov.l 0x060917A8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06091790 mov.w @r1,r1
    c.r[4] += 6;  // 06091792 add #6,r4
    st16(c.r[4], c.r[1]);  // 06091794 mov.w r1,@r4
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091796 rts ; mov.l @r15+,r14
}

void f_060917CC(SH2Context& c) {
    ran[2157] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060917CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060917CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060917D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060917D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060917D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060917D6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060917D8 mov r15,r14
    c.r[11] = c.r[4];  // 060917DA mov r4,r11
    c.r[10] = c.r[5];  // 060917DC mov r5,r10
    c.r[2] = ld32(0x0609189Cu);  // 060917DE mov.l 0x0609189C,r2
    c.r[1] = 0x0u;  // 060917E0 mov #0,r1
    st32(c.r[2], c.r[1]);  // 060917E2 mov.l r1,@r2
    c.r[2] = c.r[11];  // 060917E4 mov r11,r2
    c.r[2] -= 1;  // 060917E6 add #-1,r2
    c.r[1] = 0x17u;  // 060917E8 mov #23,r1
    c.t = c.r[2] > c.r[1];  // 060917EA cmp/hi r1,r2
    { const bool k = !c.t; c.r[8] = c.r[6]; if (k) { goto L_060917F4; } }  // 060917EC bf/s 0x060917F4 ; mov r6,r8
    c.r[0] = 0xFFFFFFFBu; goto L_06091888;  // 060917F0 bra 0x06091888 ; mov #-5,r0
L_060917F4:
    c.r[1] = 0x3u;  // 060917F4 mov #3,r1
    c.r[1] &= c.r[10];  // 060917F6 and r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060917F8 tst r1,r1
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06091802; } }  // 060917FA bt/s 0x06091802 ; tst r8,r8
    c.r[0] = 0xFFFFFFEBu; goto L_06091888;  // 060917FE bra 0x06091888 ; mov #-21,r0
L_06091802:
    if (c.t) { goto L_06091820; }  // 06091802 bt 0x06091820
    c.r[1] = ld32(c.r[8]);  // 06091804 mov.l @r8,r1
    c.r[2] = 0x1u;  // 06091806 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 06091808 cmp/hi r2,r1
    { const bool k = c.t; c.r[0] = 0xFFFFFFFCu; if (k) { goto L_06091888; } }  // 0609180A bt/s 0x06091888 ; mov #-4,r0
    c.r[1] = ld32(c.r[8] + 4);  // 0609180E mov.l @(4,r8),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06091810 cmp/gt r2,r1
    if (!c.t) { goto L_06091888; }  // 06091812 bf 0x06091888
    c.r[1] = ld32(c.r[8] + 8);  // 06091814 mov.l @(8,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091816 tst r1,r1
    if (!c.t) { goto L_06091820; }  // 06091818 bf 0x06091820
    c.r[15] = c.r[14];  // 0609181A mov r14,r15
    goto L_0609188A;  // 0609181C bra 0x0609188A ; nop
L_06091820:
    c.r[1] = ld32(0x060918A0u);  // 06091820 mov.l 0x060918A0,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06091898u);  // 06091822 mov.w 0x06091898,r4
    c.r[1] = ld32(c.r[1]);  // 06091824 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609182Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609182Au) return; }  // 06091826 jsr @r1 ; mov #0,r5
    c.r[9] = ld32(0x060918A4u);  // 0609182A mov.l 0x060918A4,r9
    st32(c.r[9], c.r[10]);  // 0609182C mov.l r10,@r9
    c.r[1] = ld32(0x060918A8u);  // 0609182E mov.l 0x060918A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091834u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091834u) return; }  // 06091830 jsr @r1 ; mov r11,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 06091834 tst r8,r8
    c.r[0] = ld32(0x060918ACu);  // 06091836 mov.l 0x060918AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609183Cu; c.r[4] = c.t; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609183Cu) return; }  // 06091838 jsr @r0 ; movt r4
    c.r[1] = c.r[0];  // 0609183C mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609183E tst r1,r1
    if (c.t) { goto L_0609184C; }  // 06091840 bt 0x0609184C
    c.r[0] = ld32(0x060918B0u);  // 06091842 mov.l 0x060918B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091848u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091848u) return; }  // 06091844 jsr @r0 ; mov r1,r4
    c.r[15] = c.r[14]; goto L_0609188A;  // 06091848 bra 0x0609188A ; mov r14,r15
L_0609184C:
    c.r[1] = ld32(c.r[9]);  // 0609184C mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609189Au);  // 0609184E mov.w 0x0609189A,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06091850 mov.l @(r0,r1),r0
    c.r[0] &= 0x1u;  // 06091852 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06091854 tst r0,r0
    if (!c.t) { goto L_06091862; }  // 06091856 bf 0x06091862
    c.r[0] = ld32(0x060918B0u);  // 06091858 mov.l 0x060918B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609185Eu; c.r[4] = 0xFFFFFFFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609185Eu) return; }  // 0609185A jsr @r0 ; mov #-2,r4
    c.r[15] = c.r[14]; goto L_0609188A;  // 0609185E bra 0x0609188A ; mov r14,r15
L_06091862:
    c.r[0] = ld32(0x060918B4u);  // 06091862 mov.l 0x060918B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091868u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091868u) return; }  // 06091864 jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0];  // 06091868 mov r0,r8
    c.t = (int32_t)c.r[8] >= 0;  // 0609186A cmp/pz r8
    if (c.t) { goto L_06091878; }  // 0609186C bt 0x06091878
    c.r[0] = ld32(0x060918B0u);  // 0609186E mov.l 0x060918B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091874u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091874u) return; }  // 06091870 jsr @r0 ; mov r8,r4
    c.r[15] = c.r[14]; goto L_0609188A;  // 06091874 bra 0x0609188A ; mov r14,r15
L_06091878:
    c.r[0] = ld32(0x060918B0u);  // 06091878 mov.l 0x060918B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609187Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609187Eu) return; }  // 0609187A jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 0609187E mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06091880 cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06091888; } }  // 06091882 bt/s 0x06091888 ; mov r8,r0
    c.r[0] = c.r[1];  // 06091886 mov r1,r0
L_06091888:
    c.r[15] = c.r[14];  // 06091888 mov r14,r15
L_0609188A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609188A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609188C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609188E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06091890 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091892 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091894 rts ; mov.l @r15+,r8
}

void f_060918B8(SH2Context& c) {
    ran[2158] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060918B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060918BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060918BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060918BE sts.l pr,@-r15
    c.r[15] -= 4;  // 060918C0 add #-4,r15
    c.r[8] = c.r[5];  // 060918C2 mov r5,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060918C4 tst r8,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060918FA; } }  // 060918C6 bf/s 0x060918FA ; mov r15,r14
    c.r[1] = ld32(0x06091944u);  // 060918CA mov.l 0x06091944,r1
    c.r[2] = ld32(c.r[1]);  // 060918CC mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06091940u);  // 060918CE mov.w 0x06091940,r1
    c.r[2] += c.r[1];  // 060918D0 add r1,r2
    c.r[1] = ld32(c.r[2] + 8);  // 060918D2 mov.l @(8,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060918D4 tst r1,r1
    if (c.t) { goto L_060918E2; }  // 060918D6 bt 0x060918E2
    c.r[0] = ld32(0x06091948u);  // 060918D8 mov.l 0x06091948,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060918DEu; c.r[4] = 0xFFFFFFF9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060918DEu) return; }  // 060918DA jsr @r0 ; mov #-7,r4
    c.r[14] += 4; goto L_06091934;  // 060918DE bra 0x06091934 ; add #4,r14
L_060918E2:
    c.r[0] = ld32(0x0609194Cu);  // 060918E2 mov.l 0x0609194C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060918E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060918E8u) return; }  // 060918E4 jsr @r0 ; nop
    c.r[8] = c.r[0];  // 060918E8 mov r0,r8
    c.t = (int32_t)c.r[0] >= 0;  // 060918EA cmp/pz r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06091932; } }  // 060918EC bt/s 0x06091932 ; mov r8,r0
    c.r[0] = ld32(0x06091948u);  // 060918F0 mov.l 0x06091948,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060918F6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060918F6u) return; }  // 060918F2 jsr @r0 ; mov r8,r4
    c.r[14] += 4; goto L_06091934;  // 060918F6 bra 0x06091934 ; add #4,r14
L_060918FA:
    c.r[0] = ld32(0x06091950u);  // 060918FA mov.l 0x06091950,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091900u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091900u) return; }  // 060918FC jsr @r0 ; nop
    c.r[9] = c.r[0];  // 06091900 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06091902 tst r9,r9
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06091928; } }  // 06091904 bt/s 0x06091928 ; mov #0,r7
    c.r[1] = ld32(0x06091954u);  // 06091908 mov.l 0x06091954,r1
    c.r[6] = c.r[14];  // 0609190A mov r14,r6
    c.r[5] = 0x0u;  // 0609190C mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06091912u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091912u) return; }  // 0609190E jsr @r1 ; mov r9,r4
    c.r[0] = ld32(0x06091958u);  // 06091912 mov.l 0x06091958,r0
    c.r[6] = ld32(c.r[14]);  // 06091914 mov.l @r14,r6
    c.r[5] = c.r[8];  // 06091916 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609191Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609191Cu) return; }  // 06091918 jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0];  // 0609191C mov r0,r8
    c.r[1] = ld32(0x0609195Cu);  // 0609191E mov.l 0x0609195C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091924u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091924u) return; }  // 06091920 jsr @r1 ; mov r9,r4
    c.r[0] = c.r[8]; goto L_06091932;  // 06091924 bra 0x06091932 ; mov r8,r0
L_06091928:
    c.r[1] = ld32(0x06091944u);  // 06091928 mov.l 0x06091944,r1
    c.r[2] = ld32(c.r[1]);  // 0609192A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06091942u);  // 0609192C mov.w 0x06091942,r1
    c.r[2] += c.r[1];  // 0609192E add r1,r2
    c.r[0] = ld32(c.r[2] + 8);  // 06091930 mov.l @(8,r2),r0
L_06091932:
    c.r[14] += 4;  // 06091932 add #4,r14
L_06091934:
    c.r[15] = c.r[14];  // 06091934 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091936 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091938 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609193A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609193C rts ; mov.l @r15+,r8
}

void f_06091960(SH2Context& c) {
    ran[2159] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091960 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091962 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091964 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06091966 mov r15,r14
    c.r[1] = ld32(0x060919B8u);  // 06091968 mov.l 0x060919B8,r1
    c.r[3] = ld32(c.r[1]);  // 0609196A mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060919B6u);  // 0609196C mov.w 0x060919B6,r7
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609196E tst r4,r4
    c.r[8] = c.r[3];  // 06091970 mov r3,r8
    { const bool k = !c.t; c.r[8] += c.r[7]; if (k) { goto L_0609198C; } }  // 06091972 bf/s 0x0609198C ; add r7,r8
    c.r[1] = ld32(c.r[8] + 8);  // 06091976 mov.l @(8,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091978 tst r1,r1
    if (c.t) { goto L_06091984; }  // 0609197A bt 0x06091984
    c.r[4] = 0xFFFFFFF9u;  // 0609197C mov #-7,r4
    c.r[0] = ld32(0x060919BCu);  // 0609197E mov.l 0x060919BC,r0
    goto L_060919A8;  // 06091980 bra 0x060919A8 ; nop
L_06091984:
    st32(c.r[8] + 8, c.r[4]);  // 06091984 mov.l r4,@(8,r8)
    st32(c.r[8] + 12, c.r[4]);  // 06091986 mov.l r4,@(12,r8)
    st32(c.r[8] + 4, c.r[4]); goto L_060919A4;  // 06091988 bra 0x060919A4 ; mov.l r4,@(4,r8)
L_0609198C:
    c.r[1] = c.r[4];  // 0609198C mov r4,r1
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 0609198E mov.l @r1+,r2
    c.r[0] = c.r[3];  // 06091990 mov r3,r0
    st32(c.r[0] + c.r[7], c.r[2]);  // 06091992 mov.l r2,@(r0,r7)
    c.r[2] = ld32(c.r[4] + 4);  // 06091994 mov.l @(4,r4),r2
    st32(c.r[8] + 4, c.r[2]);  // 06091996 mov.l r2,@(4,r8)
    c.r[1] = ld32(c.r[1] + 4);  // 06091998 mov.l @(4,r1),r1
    c.r[0] = ld32(0x060919C0u);  // 0609199A mov.l 0x060919C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060919A0u; st32(c.r[8] + 8, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060919A0u) return; }  // 0609199C jsr @r0 ; mov.l r1,@(8,r8)
    c.r[1] = c.r[0];  // 060919A0 mov r0,r1
    st32(c.r[8] + 12, c.r[1]);  // 060919A2 mov.l r1,@(12,r8)
L_060919A4:
    c.r[0] = ld32(0x060919BCu);  // 060919A4 mov.l 0x060919BC,r0
    c.r[4] = 0x0u;  // 060919A6 mov #0,r4
L_060919A8:
    { const uint32_t x = c.r[0]; c.pr = 0x060919ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060919ACu) return; }  // 060919A8 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 060919AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060919AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060919B0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060919B2 rts ; mov.l @r15+,r8
}

void f_060919C4(SH2Context& c) {
    ran[2160] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060919C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060919C6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060919C8 sts.l pr,@-r15
    c.r[5] = c.r[4];  // 060919CA mov r4,r5
    c.r[1] = ld32(0x06091A24u);  // 060919CC mov.l 0x06091A24,r1
    c.r[1] = ld32(c.r[1]);  // 060919CE mov.l @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06091A22u);  // 060919D0 mov.w 0x06091A22,r3
    c.r[2] = c.r[1];  // 060919D2 mov r1,r2
    c.r[2] += c.r[3];  // 060919D4 add r3,r2
    c.r[4] = ld32(c.r[2] + 8);  // 060919D6 mov.l @(8,r2),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060919D8 tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060919E8; } }  // 060919DA bt/s 0x060919E8 ; mov r15,r14
    c.r[0] = c.r[1];  // 060919DE mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 060919E0 mov.l @(r0,r3),r1
    c.r[0] = c.r[1];  // 060919E2 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060919E4 cmp/eq #1,r0
    if (c.t) { goto L_060919F2; }  // 060919E6 bt 0x060919F2
L_060919E8:
    c.r[0] = ld32(0x06091A28u);  // 060919E8 mov.l 0x06091A28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060919EEu; c.r[4] = 0xFFFFFFF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060919EEu) return; }  // 060919EA jsr @r0 ; mov #-8,r4
    c.r[15] = c.r[14]; goto L_06091A1A;  // 060919EE bra 0x06091A1A ; mov r14,r15
L_060919F2:
    c.r[0] = ld32(0x06091A2Cu);  // 060919F2 mov.l 0x06091A2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060919F8u; c.r[6] = ld32(c.r[2] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060919F8u) return; }  // 060919F4 jsr @r0 ; mov.l @(4,r2),r6
    c.r[8] = c.r[0];  // 060919F8 mov r0,r8
    c.t = (int32_t)c.r[8] >= 0;  // 060919FA cmp/pz r8
    if (c.t) { goto L_06091A08; }  // 060919FC bt 0x06091A08
    c.r[0] = ld32(0x06091A28u);  // 060919FE mov.l 0x06091A28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091A04u; c.r[4] = 0xFFFFFFF7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091A04u) return; }  // 06091A00 jsr @r0 ; mov #-9,r4
    c.r[15] = c.r[14]; goto L_06091A1A;  // 06091A04 bra 0x06091A1A ; mov r14,r15
L_06091A08:
    c.r[0] = ld32(0x06091A28u);  // 06091A08 mov.l 0x06091A28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091A0Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091A0Eu) return; }  // 06091A0A jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 06091A0E mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06091A10 cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06091A18; } }  // 06091A12 bt/s 0x06091A18 ; mov r8,r0
    c.r[0] = c.r[1];  // 06091A16 mov r1,r0
L_06091A18:
    c.r[15] = c.r[14];  // 06091A18 mov r14,r15
L_06091A1A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091A1A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091A1C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091A1E rts ; mov.l @r15+,r8
}

void f_06091A30(SH2Context& c) {
    ran[2161] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091A30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091A32 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091A34 sts.l pr,@-r15
    c.r[1] = ld32(0x06091A98u);  // 06091A36 mov.l 0x06091A98,r1
    c.r[1] = ld32(c.r[1]);  // 06091A38 mov.l @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06091A94u);  // 06091A3A mov.w 0x06091A94,r3
    c.r[2] = c.r[1];  // 06091A3C mov r1,r2
    c.r[2] += c.r[3];  // 06091A3E add r3,r2
    c.r[5] = ld32(c.r[2] + 8);  // 06091A40 mov.l @(8,r2),r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 06091A42 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06091A54; } }  // 06091A44 bt/s 0x06091A54 ; mov r15,r14
    c.r[0] = c.r[1];  // 06091A48 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06091A4A mov.l @(r0,r3),r1
    c.r[0] = c.r[1];  // 06091A4C mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06091A4E cmp/eq #1,r0
    { const bool k = c.t; c.t = (int32_t)c.r[4] >= 0; if (k) { goto L_06091A5E; } }  // 06091A50 bt/s 0x06091A5E ; cmp/pz r4
L_06091A54:
    c.r[0] = ld32(0x06091A9Cu);  // 06091A54 mov.l 0x06091A9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091A5Au; c.r[4] = 0xFFFFFFF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091A5Au) return; }  // 06091A56 jsr @r0 ; mov #-8,r4
    c.r[0] = 0x0u; goto L_06091A8A;  // 06091A5A bra 0x06091A8A ; mov #0,r0
L_06091A5E:
    if (!c.t) { goto L_06091A66; }  // 06091A5E bf 0x06091A66
    c.r[1] = ld32(c.r[2] + 12);  // 06091A60 mov.l @(12,r2),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 06091A62 cmp/gt r4,r1
    if (c.t) { goto L_06091A70; }  // 06091A64 bt 0x06091A70
L_06091A66:
    c.r[0] = ld32(0x06091A9Cu);  // 06091A66 mov.l 0x06091A9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091A6Cu; c.r[4] = 0xFFFFFFF7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091A6Cu) return; }  // 06091A68 jsr @r0 ; mov #-9,r4
    c.r[0] = 0x0u; goto L_06091A8A;  // 06091A6C bra 0x06091A8A ; mov #0,r0
L_06091A70:
    c.r[0] = ld32(0x06091AA0u);  // 06091A70 mov.l 0x06091AA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091A76u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091A76u) return; }  // 06091A72 jsr @r0 ; nop
    c.r[8] = c.r[0];  // 06091A76 mov r0,r8
    c.r[0] = ld32(0x06091A9Cu);  // 06091A78 mov.l 0x06091A9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091A7Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091A7Eu) return; }  // 06091A7A jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 06091A7E cmp/pz r0
    { const bool k = !c.t; c.r[8] += 12; if (k) { goto L_06091A88; } }  // 06091A80 bf/s 0x06091A88 ; add #12,r8
    c.r[0] = c.r[8]; goto L_06091A8A;  // 06091A84 bra 0x06091A8A ; mov r8,r0
L_06091A88:
    c.r[0] = 0x0u;  // 06091A88 mov #0,r0
L_06091A8A:
    c.r[15] = c.r[14];  // 06091A8A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091A8C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091A8E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091A90 rts ; mov.l @r15+,r8
}

void f_06091AA4(SH2Context& c) {
    ran[2162] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091AA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091AA6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091AA8 sts.l pr,@-r15
    c.r[8] = c.r[5];  // 06091AAA mov r5,r8
    c.r[1] = ld32(0x06091B08u);  // 06091AAC mov.l 0x06091B08,r1
    c.r[2] = ld32(c.r[1]);  // 06091AAE mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06091B04u);  // 06091AB0 mov.w 0x06091B04,r3
    c.r[1] = c.r[2];  // 06091AB2 mov r2,r1
    c.r[1] += c.r[3];  // 06091AB4 add r3,r1
    c.r[5] = ld32(c.r[1] + 8);  // 06091AB6 mov.l @(8,r1),r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 06091AB8 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06091ACA; } }  // 06091ABA bt/s 0x06091ACA ; mov r15,r14
    c.t = (int32_t)c.r[4] >= 0;  // 06091ABE cmp/pz r4
    if (!c.t) { goto L_06091ACA; }  // 06091AC0 bf 0x06091ACA
    c.r[1] = ld32(c.r[1] + 12);  // 06091AC2 mov.l @(12,r1),r1
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[1];  // 06091AC4 cmp/ge r1,r4
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06091AD0; } }  // 06091AC6 bf/s 0x06091AD0 ; mov r2,r0
L_06091ACA:
    c.r[0] = ld32(0x06091B0Cu);  // 06091ACA mov.l 0x06091B0C,r0
    c.r[4] = 0xFFFFFFF6u; goto L_06091AF6;  // 06091ACC bra 0x06091AF6 ; mov #-10,r4
L_06091AD0:
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06091AD0 mov.l @(r0,r3),r1
    c.r[0] = c.r[1];  // 06091AD2 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06091AD4 cmp/eq #1,r0
    if (!c.t) { goto L_06091ADE; }  // 06091AD6 bf 0x06091ADE
    c.r[0] = ld32(0x06091B10u);  // 06091AD8 mov.l 0x06091B10,r0
    goto L_06091AE0;  // 06091ADA bra 0x06091AE0 ; nop
L_06091ADE:
    c.r[0] = ld32(0x06091B14u);  // 06091ADE mov.l 0x06091B14,r0
L_06091AE0:
    { const uint32_t x = c.r[0]; c.pr = 0x06091AE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091AE4u) return; }  // 06091AE0 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 06091AE4 mov r0,r2
    c.r[1] = ld32(c.r[0]); c.r[0] += 4;  // 06091AE6 mov.l @r0+,r1
    st32(c.r[8], c.r[1]);  // 06091AE8 mov.l r1,@r8
    c.r[1] = ld32(c.r[2] + 4);  // 06091AEA mov.l @(4,r2),r1
    st32(c.r[8] + 4, c.r[1]);  // 06091AEC mov.l r1,@(4,r8)
    c.r[1] = ld32(c.r[0] + 4);  // 06091AEE mov.l @(4,r0),r1
    st32(c.r[8] + 8, c.r[1]);  // 06091AF0 mov.l r1,@(8,r8)
    c.r[0] = ld32(0x06091B0Cu);  // 06091AF2 mov.l 0x06091B0C,r0
    c.r[4] = 0x0u;  // 06091AF4 mov #0,r4
L_06091AF6:
    { const uint32_t x = c.r[0]; c.pr = 0x06091AFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091AFAu) return; }  // 06091AF6 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 06091AFA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091AFC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091AFE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091B00 rts ; mov.l @r15+,r8
}

void f_06091B18(SH2Context& c) {
    ran[2163] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091B18 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091B1A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06091B1C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06091B1E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091B20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091B22 sts.l pr,@-r15
    c.r[1] = ld32(0x06091B7Cu);  // 06091B24 mov.l 0x06091B7C,r1
    c.r[1] = ld32(c.r[1]);  // 06091B26 mov.l @r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06091B76u);  // 06091B28 mov.w 0x06091B76,r8
    c.r[8] += c.r[1];  // 06091B2A add r1,r8
    c.r[1] = ld32(c.r[1]);  // 06091B2C mov.l @r1,r1
    c.r[9] = 0x0u;  // 06091B2E mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06091B30 cmp/ge r1,r9
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06091B66; } }  // 06091B32 bt/s 0x06091B66 ; mov r15,r14
    c.r[11] = ld32(0x06091B80u);  // 06091B36 mov.l 0x06091B80,r11
    c.r[10] = ld32(0x06091B84u);  // 06091B38 mov.l 0x06091B84,r10
L_06091B3A:
    c.r[0] = ld32(c.r[8]);  // 06091B3A mov.l @r8,r0
    c.t = c.r[0] == 0x1u;  // 06091B3C cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06091B56; } }  // 06091B3E bf/s 0x06091B56 ; mov r8,r1
    c.r[1] += 108;  // 06091B42 add #108,r1
    c.r[0] = ld32(c.r[1] + 56);  // 06091B44 mov.l @(56,r1),r0
    c.t = c.r[0] == 0x4u;  // 06091B46 cmp/eq #4,r0
    { const bool k = !c.t; c.r[6] = c.r[8]; if (k) { goto L_06091B52; } }  // 06091B48 bf/s 0x06091B52 ; mov r8,r6
    c.r[5] = ld32(0x06091B88u);  // 06091B4C mov.l 0x06091B88,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06091B52u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091B52u) return; }  // 06091B4E jsr @r11 ; mov r8,r4
L_06091B52:
    { const uint32_t x = c.r[10]; c.pr = 0x06091B56u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091B56u) return; }  // 06091B52 jsr @r10 ; mov r8,r4
L_06091B56:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06091B78u);  // 06091B56 mov.w 0x06091B78,r1
    c.r[8] += c.r[1];  // 06091B58 add r1,r8
    c.r[1] = ld32(0x06091B7Cu);  // 06091B5A mov.l 0x06091B7C,r1
    c.r[1] = ld32(c.r[1]);  // 06091B5C mov.l @r1,r1
    c.r[1] = ld32(c.r[1]);  // 06091B5E mov.l @r1,r1
    c.r[9] += 1;  // 06091B60 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06091B62 cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06091B3A; }  // 06091B64 bf 0x06091B3A
L_06091B66:
    c.r[15] = c.r[14];  // 06091B66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091B68 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091B6A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06091B6C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06091B6E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091B70 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091B72 rts ; mov.l @r15+,r8
}

void f_06091B8C(SH2Context& c) {
    ran[2164] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091B8C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091B8E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06091B90 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091B92 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091B94 sts.l pr,@-r15
    c.r[1] = ld32(0x06091C24u);  // 06091B96 mov.l 0x06091C24,r1
    c.r[8] = ld32(c.r[1]);  // 06091B98 mov.l @r1,r8
    c.r[14] = c.r[15];  // 06091B9A mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06091C22u);  // 06091B9C mov.w 0x06091C22,r1
    c.r[8] += c.r[1];  // 06091B9E add r1,r8
    c.r[1] = ld32(c.r[8] + 8);  // 06091BA0 mov.l @(8,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091BA2 tst r1,r1
    { const bool k = c.t; c.r[9] = c.r[4]; if (k) { goto L_06091BB8; } }  // 06091BA4 bt/s 0x06091BB8 ; mov r4,r9
    c.t = (int32_t)c.r[9] >= 0;  // 06091BA8 cmp/pz r9
    if (!c.t) { goto L_06091BB2; }  // 06091BAA bf 0x06091BB2
    c.r[1] = ld32(c.r[8] + 12);  // 06091BAC mov.l @(12,r8),r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06091BAE cmp/ge r1,r9
    if (!c.t) { goto L_06091BB8; }  // 06091BB0 bf 0x06091BB8
L_06091BB2:
    c.r[0] = ld32(0x06091C28u);  // 06091BB2 mov.l 0x06091C28,r0
    c.r[4] = 0xFFFFFFF6u; goto L_06091BC8;  // 06091BB4 bra 0x06091BC8 ; mov #-10,r4
L_06091BB8:
    c.r[0] = ld32(0x06091C2Cu);  // 06091BB8 mov.l 0x06091C2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091BBEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091BBEu) return; }  // 06091BBA jsr @r0 ; nop
    c.r[10] = c.r[0];  // 06091BBE mov r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06091BC0 tst r10,r10
    { const bool k = !c.t; c.r[4] = 0xFFFFFFEDu; if (k) { goto L_06091BD0; } }  // 06091BC2 bf/s 0x06091BD0 ; mov #-19,r4
    c.r[0] = ld32(0x06091C28u);  // 06091BC6 mov.l 0x06091C28,r0
L_06091BC8:
    { const uint32_t x = c.r[0]; c.pr = 0x06091BCCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091BCCu) return; }  // 06091BC8 jsr @r0 ; nop
    c.r[0] = 0x0u; goto L_06091C14;  // 06091BCC bra 0x06091C14 ; mov #0,r0
L_06091BD0:
    c.r[5] = ld32(c.r[8] + 8);  // 06091BD0 mov.l @(8,r8),r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 06091BD2 tst r5,r5
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06091BEC; } }  // 06091BD4 bt/s 0x06091BEC ; mov #0,r1
    c.r[1] = ld32(c.r[8]);  // 06091BD8 mov.l @r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091BDA tst r1,r1
    if (!c.t) { goto L_06091BE4; }  // 06091BDC bf 0x06091BE4
    c.r[0] = ld32(0x06091C30u);  // 06091BDE mov.l 0x06091C30,r0
    goto L_06091BE6;  // 06091BE0 bra 0x06091BE6 ; nop
L_06091BE4:
    c.r[0] = ld32(0x06091C34u);  // 06091BE4 mov.l 0x06091C34,r0
L_06091BE6:
    { const uint32_t x = c.r[0]; c.pr = 0x06091BEAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091BEAu) return; }  // 06091BE6 jsr @r0 ; mov r9,r4
    c.r[1] = c.r[0];  // 06091BEA mov r0,r1
L_06091BEC:
    c.r[0] = ld32(0x06091C38u);  // 06091BEC mov.l 0x06091C38,r0
    c.r[6] = c.r[9];  // 06091BEE mov r9,r6
    c.r[5] = c.r[1];  // 06091BF0 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06091BF6u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091BF6u) return; }  // 06091BF2 jsr @r0 ; mov r10,r4
    c.r[10] = c.r[0];  // 06091BF6 mov r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06091BF8 tst r10,r10
    if (c.t) { goto L_06091C0C; }  // 06091BFA bt 0x06091C0C
    c.r[0] = ld32(0x06091C28u);  // 06091BFC mov.l 0x06091C28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091C02u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091C02u) return; }  // 06091BFE jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 06091C02 cmp/pz r0
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_06091C14; } }  // 06091C04 bt/s 0x06091C14 ; mov r10,r0
    c.r[0] = 0x0u; goto L_06091C14;  // 06091C08 bra 0x06091C14 ; mov #0,r0
L_06091C0C:
    c.r[0] = ld32(0x06091C28u);  // 06091C0C mov.l 0x06091C28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091C12u; c.r[4] = 0xFFFFFFF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091C12u) return; }  // 06091C0E jsr @r0 ; mov #-10,r4
    c.r[0] = c.r[10];  // 06091C12 mov r10,r0
L_06091C14:
    c.r[15] = c.r[14];  // 06091C14 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091C16 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091C18 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06091C1A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091C1C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091C1E rts ; mov.l @r15+,r8
}

void f_06091C3C(SH2Context& c) {
    ran[2165] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091C3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091C3E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091C40 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 06091C42 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06091C44 tst r8,r8
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06091C56; } }  // 06091C46 bt/s 0x06091C56 ; mov r15,r14
    c.r[1] = ld32(0x06091C68u);  // 06091C4A mov.l 0x06091C68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091C50u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091C50u) return; }  // 06091C4C jsr @r1 ; mov #1,r5
    c.r[1] = ld32(0x06091C6Cu);  // 06091C50 mov.l 0x06091C6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091C56u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091C56u) return; }  // 06091C52 jsr @r1 ; mov r8,r4
L_06091C56:
    c.r[0] = ld32(0x06091C70u);  // 06091C56 mov.l 0x06091C70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091C5Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091C5Cu) return; }  // 06091C58 jsr @r0 ; mov #0,r4
    c.r[15] = c.r[14];  // 06091C5C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091C5E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091C60 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091C62 rts ; mov.l @r15+,r8
}

void f_06091C74(SH2Context& c) {
    ran[2166] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091C74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091C76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06091C78 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06091C7A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091C7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091C7E sts.l pr,@-r15
    c.r[15] -= 4;  // 06091C80 add #-4,r15
    c.r[14] = c.r[15];  // 06091C82 mov r15,r14
    c.r[8] = c.r[5];  // 06091C84 mov r5,r8
    c.t = (c.r[4] & c.r[4]) == 0;  // 06091C86 tst r4,r4
    { const bool k = !c.t; c.r[9] = c.r[6]; if (k) { goto L_06091C96; } }  // 06091C88 bf/s 0x06091C96 ; mov r6,r9
    c.r[0] = ld32(0x06091D1Cu);  // 06091C8C mov.l 0x06091D1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091C92u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091C92u) return; }  // 06091C8E jsr @r0 ; mov #-11,r4
    c.r[14] += 4; goto L_06091D0C;  // 06091C92 bra 0x06091D0C ; add #4,r14
L_06091C96:
    c.r[11] = c.r[4];  // 06091C96 mov r4,r11
    c.r[11] += 12;  // 06091C98 add #12,r11
    c.r[1] = ld32(0x06091D20u);  // 06091C9A mov.l 0x06091D20,r1
    c.r[7] = 0x0u;  // 06091C9C mov #0,r7
    c.r[6] = c.r[14];  // 06091C9E mov r14,r6
    c.r[2] = ld32(c.r[4] + 40);  // 06091CA0 mov.l @(40,r4),r2
    c.r[5] = 0x0u;  // 06091CA2 mov #0,r5
    c.r[10] = ld32(c.r[1]);  // 06091CA4 mov.l @r1,r10
    c.r[2] <<= 2;  // 06091CA6 shll2 r2
    c.r[2] <<= 2;  // 06091CA8 shll2 r2
    c.r[2] += 4;  // 06091CAA add #4,r2
    c.r[1] = ld32(0x06091D24u);  // 06091CAC mov.l 0x06091D24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091CB2u; c.r[10] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091CB2u) return; }  // 06091CAE jsr @r1 ; add r2,r10
    c.r[0] = c.r[9];  // 06091CB2 mov r9,r0
    c.t = c.r[0] == 0x1u;  // 06091CB4 cmp/eq #1,r0
    if (!c.t) { goto L_06091CC2; }  // 06091CB6 bf 0x06091CC2
    c.r[0] = ld32(c.r[10] + 12);  // 06091CB8 mov.l @(12,r10),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091CBEu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091CBEu) return; }  // 06091CBA jsr @r0 ; mov r11,r4
    c.r[8] += c.r[0]; goto L_06091CDC;  // 06091CBE bra 0x06091CDC ; add r0,r8
L_06091CC2:
    c.r[0] = c.r[9];  // 06091CC2 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 06091CC4 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_06091CDA; } }  // 06091CC6 bt/s 0x06091CDA ; mov.l @r14,r1
    c.t = (c.r[9] & c.r[9]) == 0;  // 06091CCA tst r9,r9
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_06091CDE; } }  // 06091CCC bt/s 0x06091CDE ; cmp/pz r8
    c.r[0] = ld32(0x06091D1Cu);  // 06091CD0 mov.l 0x06091D1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091CD6u; c.r[4] = 0xFFFFFFF3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091CD6u) return; }  // 06091CD2 jsr @r0 ; mov #-13,r4
    c.r[14] += 4; goto L_06091D0C;  // 06091CD6 bra 0x06091D0C ; add #4,r14
L_06091CDA:
    c.r[8] += c.r[1];  // 06091CDA add r1,r8
L_06091CDC:
    c.t = (int32_t)c.r[8] >= 0;  // 06091CDC cmp/pz r8
L_06091CDE:
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_06091CE8; } }  // 06091CDE bf/s 0x06091CE8 ; mov.l @r14,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06091CE2 cmp/gt r1,r8
    { const bool k = !c.t; c.r[5] = c.r[8]; if (k) { goto L_06091CF2; } }  // 06091CE4 bf/s 0x06091CF2 ; mov r8,r5
L_06091CE8:
    c.r[0] = ld32(0x06091D1Cu);  // 06091CE8 mov.l 0x06091D1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091CEEu; c.r[4] = 0xFFFFFFF4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091CEEu) return; }  // 06091CEA jsr @r0 ; mov #-12,r4
    c.r[14] += 4; goto L_06091D0C;  // 06091CEE bra 0x06091D0C ; add #4,r14
L_06091CF2:
    c.r[0] = ld32(c.r[10] + 8);  // 06091CF2 mov.l @(8,r10),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091CF8u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091CF8u) return; }  // 06091CF4 jsr @r0 ; mov r11,r4
    c.r[8] = c.r[0];  // 06091CF8 mov r0,r8
    c.r[0] = ld32(0x06091D1Cu);  // 06091CFA mov.l 0x06091D1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091D00u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091D00u) return; }  // 06091CFC jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 06091D00 mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06091D02 cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06091D0A; } }  // 06091D04 bt/s 0x06091D0A ; mov r8,r0
    c.r[0] = c.r[1];  // 06091D08 mov r1,r0
L_06091D0A:
    c.r[14] += 4;  // 06091D0A add #4,r14
L_06091D0C:
    c.r[15] = c.r[14];  // 06091D0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091D0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091D10 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06091D12 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06091D14 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091D16 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091D18 rts ; mov.l @r15+,r8
}

void f_06091D28(SH2Context& c) {
    ran[2167] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091D28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091D2A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091D2C sts.l pr,@-r15
    c.r[2] = c.r[4];  // 06091D2E mov r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06091D30 tst r2,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06091D40; } }  // 06091D32 bf/s 0x06091D40 ; mov r15,r14
    c.r[0] = ld32(0x06091D70u);  // 06091D36 mov.l 0x06091D70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091D3Cu; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091D3Cu) return; }  // 06091D38 jsr @r0 ; mov #-11,r4
    c.r[15] = c.r[14]; goto L_06091D66;  // 06091D3C bra 0x06091D66 ; mov r14,r15
L_06091D40:
    c.r[4] = c.r[2];  // 06091D40 mov r2,r4
    c.r[2] = ld32(c.r[2] + 40);  // 06091D42 mov.l @(40,r2),r2
    c.r[1] = ld32(0x06091D74u);  // 06091D44 mov.l 0x06091D74,r1
    c.r[1] = ld32(c.r[1]);  // 06091D46 mov.l @r1,r1
    c.r[2] <<= 2;  // 06091D48 shll2 r2
    c.r[2] <<= 2;  // 06091D4A shll2 r2
    c.r[2] += 4;  // 06091D4C add #4,r2
    c.r[1] += c.r[2];  // 06091D4E add r2,r1
    c.r[0] = ld32(c.r[1] + 12);  // 06091D50 mov.l @(12,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091D56u; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091D56u) return; }  // 06091D52 jsr @r0 ; add #12,r4
    c.r[8] = c.r[0];  // 06091D56 mov r0,r8
    c.r[0] = ld32(0x06091D70u);  // 06091D58 mov.l 0x06091D70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091D5Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091D5Eu) return; }  // 06091D5A jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 06091D5E cmp/pz r0
    if (!c.t) { goto L_06091D64; }  // 06091D60 bf 0x06091D64
    c.r[0] = c.r[8];  // 06091D62 mov r8,r0
L_06091D64:
    c.r[15] = c.r[14];  // 06091D64 mov r14,r15
L_06091D66:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091D66 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091D68 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091D6A rts ; mov.l @r15+,r8
}

void f_06091D78(SH2Context& c) {
    ran[2168] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091D78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091D7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091D7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091D7E sts.l pr,@-r15
    c.r[15] -= 4;  // 06091D80 add #-4,r15
    c.r[8] = c.r[4];  // 06091D82 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06091D84 tst r8,r8
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06091DAC; } }  // 06091D86 bt/s 0x06091DAC ; mov r15,r14
    c.r[0] = ld32(0x06091DC0u);  // 06091D8A mov.l 0x06091DC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091D90u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091D90u) return; }  // 06091D8C jsr @r0 ; nop
    c.r[9] = c.r[0];  // 06091D90 mov r0,r9
    c.r[1] = ld32(0x06091DC4u);  // 06091D92 mov.l 0x06091DC4,r1
    c.r[7] = 0x0u;  // 06091D94 mov #0,r7
    c.r[6] = c.r[14];  // 06091D96 mov r14,r6
    c.r[5] = 0x0u;  // 06091D98 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06091D9Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091D9Eu) return; }  // 06091D9A jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x06091DC8u);  // 06091D9E mov.l 0x06091DC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091DA4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091DA4u) return; }  // 06091DA0 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(c.r[14]);  // 06091DA4 mov.l @r14,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06091DA6 cmp/ge r1,r9
    c.r[0] = c.t; goto L_06091DB2;  // 06091DA8 bra 0x06091DB2 ; movt r0
L_06091DAC:
    c.r[0] = ld32(0x06091DC8u);  // 06091DAC mov.l 0x06091DC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091DB2u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091DB2u) return; }  // 06091DAE jsr @r0 ; mov #-11,r4
L_06091DB2:
    c.r[14] += 4;  // 06091DB2 add #4,r14
    c.r[15] = c.r[14];  // 06091DB4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091DB6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091DB8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091DBA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091DBC rts ; mov.l @r15+,r8
}

void f_06091DCC(SH2Context& c) {
    ran[2169] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091DCC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091DCE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091DD0 sts.l pr,@-r15
    c.r[15] -= 4;  // 06091DD2 add #-4,r15
    c.r[14] = c.r[15];  // 06091DD4 mov r15,r14
    c.t = (c.r[4] & c.r[4]) == 0;  // 06091DD6 tst r4,r4
    { const bool k = !c.t; c.r[8] = c.r[5]; if (k) { goto L_06091DE6; } }  // 06091DD8 bf/s 0x06091DE6 ; mov r5,r8
    c.r[0] = ld32(0x06091E1Cu);  // 06091DDC mov.l 0x06091E1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091DE2u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091DE2u) return; }  // 06091DDE jsr @r0 ; mov #-11,r4
    c.r[14] += 4; goto L_06091E10;  // 06091DE2 bra 0x06091E10 ; add #4,r14
L_06091DE6:
    c.r[1] = ld32(0x06091E20u);  // 06091DE6 mov.l 0x06091E20,r1
    c.r[7] = 0x0u;  // 06091DE8 mov #0,r7
    c.r[6] = 0x0u;  // 06091DEA mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06091DF0u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091DF0u) return; }  // 06091DEC jsr @r1 ; mov r14,r5
    c.r[1] = ld32(c.r[14]);  // 06091DF0 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06091DF2 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06091E0E; } }  // 06091DF4 bt/s 0x06091E0E ; mov #0,r0
    c.r[0] = ld32(0x06091E1Cu);  // 06091DF8 mov.l 0x06091E1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091DFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091DFEu) return; }  // 06091DFA jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 06091DFE cmp/pz r0
    { const bool k = !c.t; c.r[5] = ld32(c.r[14]); if (k) { goto L_06091E0E; } }  // 06091E00 bf/s 0x06091E0E ; mov.l @r14,r5
    c.r[1] = ld32(0x06091E24u);  // 06091E04 mov.l 0x06091E24,r1
    c.r[8] += c.r[5];  // 06091E06 add r5,r8
    c.r[8] -= 1;  // 06091E08 add #-1,r8
    { const uint32_t x = c.r[1]; c.pr = 0x06091E0Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091E0Eu) return; }  // 06091E0A jsr @r1 ; mov r8,r4
L_06091E0E:
    c.r[14] += 4;  // 06091E0E add #4,r14
L_06091E10:
    c.r[15] = c.r[14];  // 06091E10 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091E12 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091E14 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091E16 rts ; mov.l @r15+,r8
}

void f_06091E28(SH2Context& c) {
    ran[2170] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091E28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091E2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091E2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091E2E sts.l pr,@-r15
    c.r[15] -= 4;  // 06091E30 add #-4,r15
    c.r[14] = c.r[15];  // 06091E32 mov r15,r14
    c.t = (c.r[4] & c.r[4]) == 0;  // 06091E34 tst r4,r4
    { const bool k = !c.t; c.r[8] = c.r[5]; if (k) { goto L_06091E44; } }  // 06091E36 bf/s 0x06091E44 ; mov r5,r8
    c.r[0] = ld32(0x06091E80u);  // 06091E3A mov.l 0x06091E80,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091E40u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091E40u) return; }  // 06091E3C jsr @r0 ; mov #-11,r4
    goto L_06091E6A;  // 06091E40 bra 0x06091E6A ; nop
L_06091E44:
    c.r[4] += 12;  // 06091E44 add #12,r4
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091E46 mov.l r14,@-r15
    c.r[9] = 0x0u;  // 06091E48 mov #0,r9
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091E4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06091E4C mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 06091E4E mov.l r6,@-r15
    c.r[1] = ld32(0x06091E84u);  // 06091E50 mov.l 0x06091E84,r1
    c.r[7] = c.r[8];  // 06091E52 mov r8,r7
    c.r[6] = 0x0u;  // 06091E54 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06091E5Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091E5Au) return; }  // 06091E56 jsr @r1 ; mov #0,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 06091E5A tst r8,r8
    { const bool k = c.t; c.r[15] += 16; if (k) { goto L_06091E6A; } }  // 06091E5C bt/s 0x06091E6A ; add #16,r15
    c.r[0] = ld32(c.r[14]);  // 06091E60 mov.l @r14,r0
    c.r[0] &= 0x18u;  // 06091E62 and #24,r0
    c.t = c.r[0] == 0x18u;  // 06091E64 cmp/eq #24,r0
    if (!c.t) { goto L_06091E6A; }  // 06091E66 bf 0x06091E6A
    st32(c.r[8], c.r[9]);  // 06091E68 mov.l r9,@r8
L_06091E6A:
    c.r[0] = ld32(0x06091E80u);  // 06091E6A mov.l 0x06091E80,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091E70u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091E70u) return; }  // 06091E6C jsr @r0 ; mov #0,r4
    c.r[14] += 4;  // 06091E70 add #4,r14
    c.r[15] = c.r[14];  // 06091E72 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091E74 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091E76 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091E78 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091E7A rts ; mov.l @r15+,r8
}

void f_06091E88(SH2Context& c) {
    ran[2171] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091E88 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091E8A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091E8C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091E8E sts.l pr,@-r15
    c.r[15] -= 8;  // 06091E90 add #-8,r15
    c.r[14] = c.r[15];  // 06091E92 mov r15,r14
    c.r[9] = c.r[7];  // 06091E94 mov r7,r9
    c.t = (c.r[4] & c.r[4]) == 0;  // 06091E96 tst r4,r4
    { const bool k = !c.t; c.r[8] = ld32(c.r[14] + 24); if (k) { goto L_06091EA6; } }  // 06091E98 bf/s 0x06091EA6 ; mov.l @(24,r14),r8
    c.r[0] = ld32(0x06091EF4u);  // 06091E9C mov.l 0x06091EF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091EA2u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091EA2u) return; }  // 06091E9E jsr @r0 ; mov #-11,r4
    goto L_06091EDE;  // 06091EA2 bra 0x06091EDE ; nop
L_06091EA6:
    c.r[4] += 12;  // 06091EA6 add #12,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091EA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 06091EAA mov.l r6,@-r15
    c.r[1] = c.r[14];  // 06091EAC mov r14,r1
    c.r[1] += 4;  // 06091EAE add #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06091EB0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091EB2 mov.l r14,@-r15
    c.r[1] = ld32(0x06091EF8u);  // 06091EB4 mov.l 0x06091EF8,r1
    c.r[7] = 0x0u;  // 06091EB6 mov #0,r7
    { const uint32_t x = c.r[1]; c.pr = 0x06091EBCu; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091EBCu) return; }  // 06091EB8 jsr @r1 ; mov #0,r6
    c.t = (c.r[8] & c.r[8]) == 0;  // 06091EBC tst r8,r8
    { const bool k = c.t; c.r[15] += 16; if (k) { goto L_06091ECA; } }  // 06091EBE bt/s 0x06091ECA ; add #16,r15
    c.r[2] = ld32(c.r[8]);  // 06091EC2 mov.l @r8,r2
    c.r[1] = 0xFFFFFFF9u;  // 06091EC4 mov #-7,r1
    c.r[2] &= c.r[1];  // 06091EC6 and r1,r2
    st32(c.r[8], c.r[2]);  // 06091EC8 mov.l r2,@r8
L_06091ECA:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06091ECA tst r9,r9
    { const bool k = c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_06091EDE; } }  // 06091ECC bt/s 0x06091EDE ; mov.l @r14,r2
    c.r[1] = ld32(c.r[14] + 4);  // 06091ED0 mov.l @(4,r14),r1
    c.r[2] -= 1;  // 06091ED2 add #-1,r2
    c.r[2] <<= 8;  // 06091ED4 shll8 r2
    c.r[2] += c.r[2];  // 06091ED6 add r2,r2
    c.r[2] <<= 2;  // 06091ED8 shll2 r2
    c.r[2] += c.r[1];  // 06091EDA add r1,r2
    st32(c.r[9], c.r[2]);  // 06091EDC mov.l r2,@r9
L_06091EDE:
    c.r[0] = ld32(0x06091EF4u);  // 06091EDE mov.l 0x06091EF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091EE4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091EE4u) return; }  // 06091EE0 jsr @r0 ; mov #0,r4
    c.r[14] += 8;  // 06091EE4 add #8,r14
    c.r[15] = c.r[14];  // 06091EE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091EE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091EEA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091EEC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091EEE rts ; mov.l @r15+,r8
}

void f_06091EFC(SH2Context& c) {
    ran[2172] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091EFC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091EFE sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 06091F00 tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06091F0C; } }  // 06091F02 bt/s 0x06091F0C ; mov r15,r14
    c.r[0] = ld32(0x06091F1Cu);  // 06091F06 mov.l 0x06091F1C,r0
    goto L_06091F10;  // 06091F08 bra 0x06091F10 ; nop
L_06091F0C:
    c.r[0] = ld32(0x06091F20u);  // 06091F0C mov.l 0x06091F20,r0
    c.r[4] = 0xFFFFFFF5u;  // 06091F0E mov #-11,r4
L_06091F10:
    { const uint32_t x = c.r[0]; c.pr = 0x06091F14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091F14u) return; }  // 06091F10 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 06091F14 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091F16 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091F18 rts ; mov.l @r15+,r14
}

void f_06091F24(SH2Context& c) {
    ran[2173] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091F24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091F26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06091F28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06091F2A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06091F2C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091F2E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091F30 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06091F32 mov r15,r14
    c.r[11] = c.r[5];  // 06091F34 mov r5,r11
    c.r[12] = c.r[6];  // 06091F36 mov r6,r12
    c.r[0] = ld32(0x06091FD0u);  // 06091F38 mov.l 0x06091FD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091F3Eu; c.r[10] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091F3Eu) return; }  // 06091F3A jsr @r0 ; mov r7,r10
    c.r[9] = c.r[0];  // 06091F3E mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06091F40 tst r9,r9
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_06091F52; } }  // 06091F42 bf/s 0x06091F52 ; mov #0,r6
    c.r[1] = ld32(0x06091FD4u);  // 06091F46 mov.l 0x06091FD4,r1
    c.r[2] = ld32(c.r[1]);  // 06091F48 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06091FCAu);  // 06091F4A mov.w 0x06091FCA,r1
    c.r[2] += c.r[1];  // 06091F4C add r1,r2
    c.r[0] = ld32(c.r[2] + 8); goto L_06091FB8;  // 06091F4E bra 0x06091FB8 ; mov.l @(8,r2),r0
L_06091F52:
    c.r[0] = ld32(0x06091FD8u);  // 06091F52 mov.l 0x06091FD8,r0
    c.r[5] = c.r[11];  // 06091F54 mov r11,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06091F5Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091F5Au) return; }  // 06091F56 jsr @r0 ; mov r9,r4
    c.t = (int32_t)c.r[0] >= 0;  // 06091F5A cmp/pz r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06091F6A; } }  // 06091F5C bt/s 0x06091F6A ; mov r9,r1
    c.r[0] = ld32(0x06091FDCu);  // 06091F60 mov.l 0x06091FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091F66u; c.r[4] = 0xFFFFFFF1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091F66u) return; }  // 06091F62 jsr @r0 ; mov #-15,r4
    c.r[15] = c.r[14]; goto L_06091FBA;  // 06091F66 bra 0x06091FBA ; mov r14,r15
L_06091F6A:
    c.r[1] += 12;  // 06091F6A add #12,r1
    c.r[5] = ld32(c.r[1] + 16);  // 06091F6C mov.l @(16,r1),r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 06091F6E tst r5,r5
    { const bool k = !c.t; c.r[4] = c.r[5]; if (k) { goto L_06091F78; } }  // 06091F70 bf/s 0x06091F78 ; mov r5,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x06091FCCu);  // 06091F74 mov.w 0x06091FCC,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06091FCEu);  // 06091F76 mov.w 0x06091FCE,r5
L_06091F78:
    c.r[8] = ld32(c.r[1] + 20);  // 06091F78 mov.l @(20,r1),r8
    c.r[0] = c.r[10];  // 06091F7A mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06091F7C cmp/eq #-1,r0
    { const bool k = !c.t; c.r[8] -= c.r[11]; if (k) { goto L_06091F86; } }  // 06091F7E bf/s 0x06091F86 ; sub r11,r8
    c.macl = c.r[8] * c.r[4];  // 06091F82 mul.l r4,r8
    c.r[10] = c.macl;  // 06091F84 sts macl,r10
L_06091F86:
    c.r[4] += c.r[10];  // 06091F86 add r10,r4
    c.r[7] = ld32(0x06091FE0u);  // 06091F88 mov.l 0x06091FE0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06091F8Eu; c.r[4] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091F8Eu) return; }  // 06091F8A jsr @r7 ; add #-1,r4
    c.r[7] = c.r[0];  // 06091F8E mov r0,r7
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 06091F90 cmp/gt r7,r8
    if (!c.t) { goto L_06091F96; }  // 06091F92 bf 0x06091F96
    c.r[8] = c.r[7];  // 06091F94 mov r7,r8
L_06091F96:
    c.r[0] = ld32(0x06091FE4u);  // 06091F96 mov.l 0x06091FE4,r0
    c.r[7] = c.r[10];  // 06091F98 mov r10,r7
    c.r[6] = c.r[12];  // 06091F9A mov r12,r6
    c.r[5] = c.r[8];  // 06091F9C mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06091FA2u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091FA2u) return; }  // 06091F9E jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0];  // 06091FA2 mov r0,r8
    c.r[1] = ld32(0x06091FE8u);  // 06091FA4 mov.l 0x06091FE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06091FAAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091FAAu) return; }  // 06091FA6 jsr @r1 ; mov r9,r4
    c.t = (int32_t)c.r[8] >= 0;  // 06091FAA cmp/pz r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_06091FB8; } }  // 06091FAC bf/s 0x06091FB8 ; mov r8,r0
    c.r[0] = ld32(0x06091FDCu);  // 06091FB0 mov.l 0x06091FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06091FB6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06091FB6u) return; }  // 06091FB2 jsr @r0 ; mov #0,r4
    c.r[0] = c.r[8];  // 06091FB6 mov r8,r0
L_06091FB8:
    c.r[15] = c.r[14];  // 06091FB8 mov r14,r15
L_06091FBA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06091FBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06091FBC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06091FBE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06091FC0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06091FC2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06091FC4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06091FC6 rts ; mov.l @r15+,r8
}

void f_06091FEC(SH2Context& c) {
    ran[2174] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06091FEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06091FEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06091FF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06091FF2 sts.l pr,@-r15
    c.r[15] -= 8;  // 06091FF4 add #-8,r15
    c.r[8] = c.r[4];  // 06091FF6 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06091FF8 tst r8,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06092008; } }  // 06091FFA bf/s 0x06092008 ; mov r15,r14
    c.r[0] = ld32(0x0609206Cu);  // 06091FFE mov.l 0x0609206C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092004u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092004u) return; }  // 06092000 jsr @r0 ; mov #-11,r4
    c.r[14] += 8; goto L_06092060;  // 06092004 bra 0x06092060 ; add #8,r14
L_06092008:
    c.r[0] = ld32(0x06092070u);  // 06092008 mov.l 0x06092070,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609200Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609200Eu) return; }  // 0609200A jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 0609200E mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092010 tst r1,r1
    if (!c.t) { goto L_0609205E; }  // 06092012 bf 0x0609205E
    c.r[5] = ld32(0x06092074u);  // 06092014 mov.l 0x06092074,r5
    c.r[0] = ld32(0x06092078u);  // 06092016 mov.l 0x06092078,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609201Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609201Cu) return; }  // 06092018 jsr @r0 ; mov r8,r4
    c.r[9] = c.r[0];  // 0609201C mov r0,r9
    c.r[0] = ld32(0x0609207Cu);  // 0609201E mov.l 0x0609207C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092024u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092024u) return; }  // 06092020 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 06092024 mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06092026 cmp/pz r1
    { const bool k = !c.t; c.r[6] = c.r[14]; if (k) { goto L_06092048; } }  // 06092028 bf/s 0x06092048 ; mov r14,r6
    c.r[6] += 4;  // 0609202C add #4,r6
    c.r[1] = ld32(0x06092080u);  // 0609202E mov.l 0x06092080,r1
    c.r[5] = c.r[14];  // 06092030 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06092036u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092036u) return; }  // 06092032 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x0609206Cu);  // 06092036 mov.l 0x0609206C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609203Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609203Cu) return; }  // 06092038 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[0];  // 0609203C mov r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609203E cmp/pz r1
    { const bool k = c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { goto L_06092052; } }  // 06092040 bt/s 0x06092052 ; cmp/pz r9
    c.r[14] += 8; goto L_06092060;  // 06092044 bra 0x06092060 ; add #8,r14
L_06092048:
    c.r[0] = ld32(0x0609206Cu);  // 06092048 mov.l 0x0609206C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609204Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609204Eu) return; }  // 0609204A jsr @r0 ; mov r1,r4
    st32(c.r[14] + 4, c.r[0]);  // 0609204E mov.l r0,@(4,r14)
    c.t = (int32_t)c.r[9] >= 0;  // 06092050 cmp/pz r9
L_06092052:
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_0609205C; } }  // 06092052 bf/s 0x0609205C ; mov r9,r5
    c.r[0] = ld32(0x06092078u);  // 06092056 mov.l 0x06092078,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609205Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609205Cu) return; }  // 06092058 jsr @r0 ; mov r8,r4
L_0609205C:
    c.r[0] = ld32(c.r[14] + 4);  // 0609205C mov.l @(4,r14),r0
L_0609205E:
    c.r[14] += 8;  // 0609205E add #8,r14
L_06092060:
    c.r[15] = c.r[14];  // 06092060 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092062 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092064 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092066 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092068 rts ; mov.l @r15+,r8
}

void f_06092084(SH2Context& c) {
    ran[2175] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092084 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092086 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092088 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609208A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609208C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609208E sts.l pr,@-r15
    c.r[15] -= 4;  // 06092090 add #-4,r15
    c.r[14] = c.r[15];  // 06092092 mov r15,r14
    c.r[9] = c.r[4];  // 06092094 mov r4,r9
    c.r[11] = c.r[9];  // 06092096 mov r9,r11
    c.r[11] += 40;  // 06092098 add #40,r11
    c.r[10] = c.r[9];  // 0609209A mov r9,r10
    c.r[10] += 108;  // 0609209C add #108,r10
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609209E mov.l r14,@-r15
    c.r[1] = ld32(0x06092118u);  // 060920A0 mov.l 0x06092118,r1
    c.r[7] = 0x0u;  // 060920A2 mov #0,r7
    c.r[6] = 0x0u;  // 060920A4 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060920AAu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060920AAu) return; }  // 060920A6 jsr @r1 ; mov #0,r5
    c.r[0] = ld32(c.r[14]);  // 060920AA mov.l @r14,r0
    c.r[15] += 4;  // 060920AC add #4,r15
    c.r[0] &= 0x40u;  // 060920AE and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060920B0 tst r0,r0
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_060920B8; } }  // 060920B2 bt/s 0x060920B8 ; mov #0,r8
    c.r[8] = 0xFFFFFFFFu;  // 060920B6 mov #-1,r8
L_060920B8:
    c.r[0] = ld32(0x0609211Cu);  // 060920B8 mov.l 0x0609211C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060920BEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060920BEu) return; }  // 060920BA jsr @r0 ; mov r9,r4
    c.r[3] = c.r[0];  // 060920BE mov r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060920C0 tst r3,r3
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= 0; if (k) { goto L_06092102; } }  // 060920C2 bt/s 0x06092102 ; cmp/pz r3
    if (!c.t) { goto L_06092102; }  // 060920C6 bf 0x06092102
    c.r[0] = ld32(c.r[10] + 52);  // 060920C8 mov.l @(52,r10),r0
    c.t = c.r[0] == 0x6u;  // 060920CA cmp/eq #6,r0
    if (!c.t) { goto L_060920EA; }  // 060920CC bf 0x060920EA
    c.r[1] = ld32(c.r[11]);  // 060920CE mov.l @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060920D0 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06092104; } }  // 060920D2 bf/s 0x06092104 ; mov r3,r0
    c.r[1] = ld32(0x06092120u);  // 060920D6 mov.l 0x06092120,r1
    c.r[2] = ld32(c.r[1]);  // 060920D8 mov.l @r1,r2
    c.r[1] = ld32(c.r[11] + 44);  // 060920DA mov.l @(44,r11),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060920DC cmp/ge r1,r2
    if (!c.t) { goto L_06092104; }  // 060920DE bf 0x06092104
    c.r[1] = ld32(0x06092124u);  // 060920E0 mov.l 0x06092124,r1
    c.r[0] = ld32(c.r[1]);  // 060920E2 mov.l @r1,r0
    c.t = c.r[0] == 0x2u;  // 060920E4 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06092104; } }  // 060920E6 bf/s 0x06092104 ; mov r3,r0
L_060920EA:
    c.r[1] = ld32(c.r[10] + 8);  // 060920EA mov.l @(8,r10),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060920EC tst r1,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { SH2_POLL(c); goto L_060920B8; } }  // 060920EE bf/s 0x060920B8 ; cmp/pz r8
    if (!c.t) { SH2_POLL(c); goto L_060920B8; }  // 060920F2 bf 0x060920B8
    c.r[8] += 1;  // 060920F4 add #1,r8
    c.r[1] = ld32(0x06092128u);  // 060920F6 mov.l 0x06092128,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060920F8 cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = 0xFFFFFFEAu; if (k) { SH2_POLL(c); goto L_060920B8; } }  // 060920FA bf/s 0x060920B8 ; mov #-22,r0
    c.r[14] += 4; goto L_06092106;  // 060920FE bra 0x06092106 ; add #4,r14
L_06092102:
    c.r[0] = c.r[3];  // 06092102 mov r3,r0
L_06092104:
    c.r[14] += 4;  // 06092104 add #4,r14
L_06092106:
    c.r[15] = c.r[14];  // 06092106 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092108 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609210A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609210C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609210E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092110 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092112 rts ; mov.l @r15+,r8
}

void f_0609212C(SH2Context& c) {
    ran[2176] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609212C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609212E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092130 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06092132 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06092134 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06092136 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092138 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609213A sts.l pr,@-r15
    c.r[15] -= 12;  // 0609213C add #-12,r15
    c.r[14] = c.r[15];  // 0609213E mov r15,r14
    c.r[8] = c.r[4];  // 06092140 mov r4,r8
    c.r[11] = c.r[5];  // 06092142 mov r5,r11
    st32(c.r[14] + 4, c.r[6]);  // 06092144 mov.l r6,@(4,r14)
    st32(c.r[14] + 8, c.r[7]);  // 06092146 mov.l r7,@(8,r14)
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092148 tst r8,r8
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_06092154; } }  // 0609214A bf/s 0x06092154 ; mov #0,r13
    c.r[0] = ld32(0x06092218u);  // 0609214E mov.l 0x06092218,r0
    c.r[4] = 0xFFFFFFF5u; goto L_060921FC;  // 06092150 bra 0x060921FC ; mov #-11,r4
L_06092154:
    c.r[12] = c.r[8];  // 06092154 mov r8,r12
    c.r[12] += 12;  // 06092156 add #12,r12
    c.r[10] = c.r[8];  // 06092158 mov r8,r10
    c.r[0] = ld32(0x0609221Cu);  // 0609215A mov.l 0x0609221C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092160u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092160u) return; }  // 0609215C jsr @r0 ; mov r8,r4
    c.r[9] = ld32(c.r[12] + 20);  // 06092160 mov.l @(20,r12),r9
    c.r[9] -= c.r[0];  // 06092162 sub r0,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11];  // 06092164 cmp/gt r11,r9
    { const bool k = !c.t; c.r[10] += 108; if (k) { goto L_0609216C; } }  // 06092166 bf/s 0x0609216C ; add #108,r10
    c.r[9] = c.r[11];  // 0609216A mov r11,r9
L_0609216C:
    c.t = (int32_t)c.r[9] >= 0;  // 0609216C cmp/pz r9
    { const bool k = c.t; c.r[4] = 0xFFFFFFEFu; if (k) { goto L_06092178; } }  // 0609216E bt/s 0x06092178 ; mov #-17,r4
    c.r[0] = ld32(0x06092218u);  // 06092172 mov.l 0x06092218,r0
    goto L_060921FC;  // 06092174 bra 0x060921FC ; nop
L_06092178:
    c.r[1] = ld32(c.r[8] + 4);  // 06092178 mov.l @(4,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609217A tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_06092188; } }  // 0609217C bf/s 0x06092188 ; mov r9,r5
    c.r[1] = ld32(0x06092220u);  // 06092180 mov.l 0x06092220,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092186u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092186u) return; }  // 06092182 jsr @r1 ; mov r12,r4
    c.r[13] = 0x1u;  // 06092186 mov #1,r13
L_06092188:
    c.r[11] = 0x1u;  // 06092188 mov #1,r11
    st32(c.r[8] + 4, c.r[11]);  // 0609218A mov.l r11,@(4,r8)
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609218C mov.l r14,@-r15
    c.r[1] = ld32(0x06092224u);  // 0609218E mov.l 0x06092224,r1
    c.r[7] = 0x0u;  // 06092190 mov #0,r7
    c.r[6] = 0x0u;  // 06092192 mov #0,r6
    c.r[5] = 0x0u;  // 06092194 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609219Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609219Au) return; }  // 06092196 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(c.r[14]);  // 0609219A mov.l @r14,r0
    c.r[0] &= 0x40u;  // 0609219C and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609219E tst r0,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_060921BC; } }  // 060921A0 bt/s 0x060921BC ; add #4,r15
    c.r[1] = ld32(0x06092228u);  // 060921A4 mov.l 0x06092228,r1
    c.r[5] = 0x0u;  // 060921A6 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060921ACu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060921ACu) return; }  // 060921A8 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0609222Cu);  // 060921AC mov.l 0x0609222C,r1
    c.r[7] = c.r[11];  // 060921AE mov r11,r7
    c.r[6] = 0x0u;  // 060921B0 mov #0,r6
    c.r[5] = 0x0u;  // 060921B2 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060921B8u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060921B8u) return; }  // 060921B4 jsr @r1 ; mov r10,r4
    c.t = (c.r[13] & c.r[13]) == 0; goto L_060921E6;  // 060921B8 bra 0x060921E6 ; tst r13,r13
L_060921BC:
    c.r[0] = ld32(c.r[10] + 52);  // 060921BC mov.l @(52,r10),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060921BE tst r0,r0
    { const bool k = c.t; c.t = c.r[0] == 0x6u; if (k) { goto L_060921C8; } }  // 060921C0 bt/s 0x060921C8 ; cmp/eq #6,r0
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_060921E6; } }  // 060921C4 bf/s 0x060921E6 ; tst r13,r13
L_060921C8:
    c.r[1] = ld32(0x06092228u);  // 060921C8 mov.l 0x06092228,r1
    c.r[5] = c.r[9];  // 060921CA mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060921D0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060921D0u) return; }  // 060921CC jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0609222Cu);  // 060921D0 mov.l 0x0609222C,r1
    c.r[6] = ld32(c.r[14] + 8);  // 060921D2 mov.l @(8,r14),r6
    c.r[7] = c.r[11];  // 060921D4 mov r11,r7
    c.r[5] = ld32(c.r[14] + 4);  // 060921D6 mov.l @(4,r14),r5
    { const uint32_t x = c.r[1]; c.pr = 0x060921DCu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060921DCu) return; }  // 060921D8 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x06092230u);  // 060921DC mov.l 0x06092230,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060921E2u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060921E2u) return; }  // 060921DE jsr @r1 ; mov r10,r4
    c.r[13] = c.r[11];  // 060921E2 mov r11,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060921E4 tst r13,r13
L_060921E6:
    { const bool k = c.t; c.r[4] = 0xFFFFFFF0u; if (k) { goto L_060921FA; } }  // 060921E6 bt/s 0x060921FA ; mov #-16,r4
    c.r[1] = ld32(0x06092234u);  // 060921EA mov.l 0x06092234,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060921F0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060921F0u) return; }  // 060921EC jsr @r1 ; mov r8,r4
    c.r[1] = 0x1u;  // 060921F0 mov #1,r1
    st32(c.r[8] + 8, c.r[1]);  // 060921F2 mov.l r1,@(8,r8)
    c.r[0] = ld32(0x06092218u);  // 060921F4 mov.l 0x06092218,r0
    c.r[4] = 0x0u; goto L_060921FC;  // 060921F6 bra 0x060921FC ; mov #0,r4
L_060921FA:
    c.r[0] = ld32(0x06092218u);  // 060921FA mov.l 0x06092218,r0
L_060921FC:
    { const uint32_t x = c.r[0]; c.pr = 0x06092200u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092200u) return; }  // 060921FC jsr @r0 ; nop
    c.r[14] += 12;  // 06092200 add #12,r14
    c.r[15] = c.r[14];  // 06092202 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092204 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092206 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06092208 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609220A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609220C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609220E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092210 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092212 rts ; mov.l @r15+,r8
}

void f_06092238(SH2Context& c) {
    ran[2177] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092238 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609223A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609223C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609223E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092240 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06092242 mov r15,r14
    c.r[8] = c.r[4];  // 06092244 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092246 tst r8,r8
    { const bool k = !c.t; c.r[9] = c.r[5]; if (k) { goto L_06092252; } }  // 06092248 bf/s 0x06092252 ; mov r5,r9
    c.r[0] = ld32(0x0609229Cu);  // 0609224C mov.l 0x0609229C,r0
    c.r[4] = 0xFFFFFFF5u; goto L_0609228A;  // 0609224E bra 0x0609228A ; mov #-11,r4
L_06092252:
    c.r[10] = c.r[8];  // 06092252 mov r8,r10
    c.r[1] = ld32(c.r[8] + 4);  // 06092254 mov.l @(4,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092256 tst r1,r1
    { const bool k = c.t; c.r[10] += 12; if (k) { goto L_06092262; } }  // 06092258 bt/s 0x06092262 ; add #12,r10
    c.r[0] = ld32(0x0609229Cu);  // 0609225C mov.l 0x0609229C,r0
    c.r[4] = 0xFFFFFFF0u; goto L_0609228A;  // 0609225E bra 0x0609228A ; mov #-16,r4
L_06092262:
    c.r[0] = ld32(0x060922A0u);  // 06092262 mov.l 0x060922A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092268u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092268u) return; }  // 06092264 jsr @r0 ; mov r8,r4
    c.r[5] = ld32(c.r[10] + 20);  // 06092268 mov.l @(20,r10),r5
    c.r[5] -= c.r[0];  // 0609226A sub r0,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[9];  // 0609226C cmp/gt r9,r5
    if (!c.t) { goto L_06092272; }  // 0609226E bf 0x06092272
    c.r[5] = c.r[9];  // 06092270 mov r9,r5
L_06092272:
    c.r[1] = ld32(0x060922A4u);  // 06092272 mov.l 0x060922A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092278u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092278u) return; }  // 06092274 jsr @r1 ; mov r10,r4
    c.r[1] = 0x2u;  // 06092278 mov #2,r1
    st32(c.r[8] + 4, c.r[1]);  // 0609227A mov.l r1,@(4,r8)
    c.r[1] = 0x1u;  // 0609227C mov #1,r1
    st32(c.r[8] + 8, c.r[1]);  // 0609227E mov.l r1,@(8,r8)
    c.r[1] = ld32(0x060922A8u);  // 06092280 mov.l 0x060922A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092286u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092286u) return; }  // 06092282 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x0609229Cu);  // 06092286 mov.l 0x0609229C,r0
    c.r[4] = 0x0u;  // 06092288 mov #0,r4
L_0609228A:
    { const uint32_t x = c.r[0]; c.pr = 0x0609228Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609228Eu) return; }  // 0609228A jsr @r0 ; nop
    c.r[15] = c.r[14];  // 0609228E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092290 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092292 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092294 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092296 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092298 rts ; mov.l @r15+,r8
}

void f_060922AC(SH2Context& c) {
    ran[2178] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060922AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060922AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060922B0 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 060922B2 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060922B4 tst r8,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060922C4; } }  // 060922B6 bf/s 0x060922C4 ; mov r15,r14
    c.r[0] = ld32(0x060922E4u);  // 060922BA mov.l 0x060922E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060922C0u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060922C0u) return; }  // 060922BC jsr @r0 ; mov #-11,r4
    c.r[0] = 0x1u; goto L_060922D8;  // 060922C0 bra 0x060922D8 ; mov #1,r0
L_060922C4:
    c.r[0] = ld32(0x060922E4u);  // 060922C4 mov.l 0x060922E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060922CAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060922CAu) return; }  // 060922C6 jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 060922CA cmp/pz r0
    if (!c.t) { goto L_060922D6; }  // 060922CC bf 0x060922D6
    c.r[1] = ld32(c.r[8] + 8);  // 060922CE mov.l @(8,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060922D0 tst r1,r1
    c.r[0] = c.t; goto L_060922D8;  // 060922D2 bra 0x060922D8 ; movt r0
L_060922D6:
    c.r[0] = 0x1u;  // 060922D6 mov #1,r0
L_060922D8:
    c.r[15] = c.r[14];  // 060922D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060922DA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060922DC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060922DE rts ; mov.l @r15+,r8
}

void f_060922E8(SH2Context& c) {
    ran[2179] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060922E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060922EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060922EC sts.l pr,@-r15
    c.r[8] = c.r[4];  // 060922EE mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060922F0 tst r8,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06092300; } }  // 060922F2 bf/s 0x06092300 ; mov r15,r14
    c.r[0] = ld32(0x06092340u);  // 060922F6 mov.l 0x06092340,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060922FCu; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060922FCu) return; }  // 060922F8 jsr @r0 ; mov #-11,r4
    c.r[15] = c.r[14]; goto L_06092336;  // 060922FC bra 0x06092336 ; mov r14,r15
L_06092300:
    c.r[1] = 0x0u;  // 06092300 mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 06092302 mov.l r1,@(4,r8)
    st32(c.r[8] + 8, c.r[1]);  // 06092304 mov.l r1,@(8,r8)
    c.r[1] = ld32(0x06092344u);  // 06092306 mov.l 0x06092344,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609230Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609230Cu) return; }  // 06092308 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x06092348u);  // 0609230C mov.l 0x06092348,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092312u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092312u) return; }  // 0609230E jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092312 tst r0,r0
    { const bool k = !c.t; c.r[5] = 0x1u; if (k) { goto L_0609231A; } }  // 06092314 bf/s 0x0609231A ; mov #1,r5
    c.r[5] = 0x0u;  // 06092318 mov #0,r5
L_0609231A:
    c.r[1] = ld32(0x0609234Cu);  // 0609231A mov.l 0x0609234C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092320u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092320u) return; }  // 0609231C jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x06092350u);  // 06092320 mov.l 0x06092350,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092326u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092326u) return; }  // 06092322 jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0];  // 06092326 mov r0,r8
    c.r[0] = ld32(0x06092340u);  // 06092328 mov.l 0x06092340,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609232Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609232Eu) return; }  // 0609232A jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 0609232E cmp/pz r0
    if (!c.t) { goto L_06092334; }  // 06092330 bf 0x06092334
    c.r[0] = c.r[8];  // 06092332 mov r8,r0
L_06092334:
    c.r[15] = c.r[14];  // 06092334 mov r14,r15
L_06092336:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092336 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092338 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609233A rts ; mov.l @r15+,r8
}

void f_06092354(SH2Context& c) {
    ran[2180] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092354 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092356 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092358 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609235A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609235C sts.l pr,@-r15
    c.r[15] -= 4;  // 0609235E add #-4,r15
    c.r[14] = c.r[15];  // 06092360 mov r15,r14
    c.r[8] = c.r[4];  // 06092362 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092364 tst r8,r8
    { const bool k = !c.t; c.r[9] = c.r[6]; if (k) { goto L_06092374; } }  // 06092366 bf/s 0x06092374 ; mov r6,r9
    c.r[0] = ld32(0x060923C4u);  // 0609236A mov.l 0x060923C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092370u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092370u) return; }  // 0609236C jsr @r0 ; mov #-11,r4
    goto L_060923AC;  // 06092370 bra 0x060923AC ; nop
L_06092374:
    c.r[10] = c.r[8];  // 06092374 mov r8,r10
    c.r[10] += 108;  // 06092376 add #108,r10
    c.r[7] = 0x0u;  // 06092378 mov #0,r7
    c.r[6] = 0x0u;  // 0609237A mov #0,r6
    c.r[1] = ld32(c.r[8] + 4);  // 0609237C mov.l @(4,r8),r1
    c.r[4] = c.r[8];  // 0609237E mov r8,r4
    st32(c.r[5], c.r[1]);  // 06092380 mov.l r1,@r5
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092382 mov.l r14,@-r15
    c.r[1] = ld32(0x060923C8u);  // 06092384 mov.l 0x060923C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609238Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609238Au) return; }  // 06092386 jsr @r1 ; mov #0,r5
    c.r[0] = ld32(c.r[14]);  // 0609238A mov.l @r14,r0
    c.r[0] &= 0x40u;  // 0609238C and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609238E tst r0,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06092398; } }  // 06092390 bt/s 0x06092398 ; add #4,r15
    c.r[1] = 0x0u; goto L_060923AA;  // 06092394 bra 0x060923AA ; mov #0,r1
L_06092398:
    c.r[0] = ld32(c.r[8] + 4);  // 06092398 mov.l @(4,r8),r0
    c.t = c.r[0] == 0x2u;  // 0609239A cmp/eq #2,r0
    if (!c.t) { goto L_060923A8; }  // 0609239C bf 0x060923A8
    c.r[0] = ld32(0x060923CCu);  // 0609239E mov.l 0x060923CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060923A4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060923A4u) return; }  // 060923A0 jsr @r0 ; mov r8,r4
    st32(c.r[9], c.r[0]); goto L_060923AC;  // 060923A4 bra 0x060923AC ; mov.l r0,@r9
L_060923A8:
    c.r[1] = ld32(c.r[10] + 8);  // 060923A8 mov.l @(8,r10),r1
L_060923AA:
    st32(c.r[9], c.r[1]);  // 060923AA mov.l r1,@r9
L_060923AC:
    c.r[0] = ld32(0x060923C4u);  // 060923AC mov.l 0x060923C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060923B2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060923B2u) return; }  // 060923AE jsr @r0 ; mov #0,r4
    c.r[14] += 4;  // 060923B2 add #4,r14
    c.r[15] = c.r[14];  // 060923B4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060923B6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060923B8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060923BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060923BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060923BE rts ; mov.l @r15+,r8
}

void f_060923D0(SH2Context& c) {
    ran[2181] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060923D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060923D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060923D4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060923D6 mov r15,r14
    c.r[8] = c.r[4];  // 060923D8 mov r4,r8
    c.r[1] = ld32(c.r[8] + 40);  // 060923DA mov.l @(40,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060923DC tst r1,r1
    { const bool k = !c.t; c.r[4] += 12; if (k) { goto L_060923F0; } }  // 060923DE bf/s 0x060923F0 ; add #12,r4
    c.r[0] = ld32(0x060923FCu);  // 060923E2 mov.l 0x060923FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060923E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060923E8u) return; }  // 060923E4 jsr @r0 ; nop
    c.t = c.r[0] == 0x2u;  // 060923E8 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_060923F0; } }  // 060923EA bf/s 0x060923F0 ; mov #1,r1
    st32(c.r[8] + 8, c.r[1]);  // 060923EE mov.l r1,@(8,r8)
L_060923F0:
    c.r[15] = c.r[14];  // 060923F0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060923F2 lds.l @r15+,pr
    c.r[0] = ld32(c.r[8] + 8);  // 060923F4 mov.l @(8,r8),r0
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060923F6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060923F8 rts ; mov.l @r15+,r8
}

void f_06092400(SH2Context& c) {
    ran[2182] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092400 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092402 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092404 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092406 sts.l pr,@-r15
    c.r[15] -= 4;  // 06092408 add #-4,r15
    c.r[8] = c.r[4];  // 0609240A mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609240C tst r8,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609241C; } }  // 0609240E bf/s 0x0609241C ; mov r15,r14
    c.r[0] = ld32(0x060924A0u);  // 06092412 mov.l 0x060924A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092418u; c.r[4] = 0xFFFFFFF5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092418u) return; }  // 06092414 jsr @r0 ; mov #-11,r4
    c.r[14] += 4; goto L_06092492;  // 06092418 bra 0x06092492 ; add #4,r14
L_0609241C:
    c.r[1] = ld32(c.r[8] + 8);  // 0609241C mov.l @(8,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609241E tst r1,r1
    if (c.t) { goto L_06092484; }  // 06092420 bt 0x06092484
    c.r[9] = ld32(0x060924A4u);  // 06092422 mov.l 0x060924A4,r9
    c.r[0] = ld32(c.r[9]);  // 06092424 mov.l @r9,r0
    c.t = c.r[0] == 0x1u;  // 06092426 cmp/eq #1,r0
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_06092438; } }  // 06092428 bf/s 0x06092438 ; mov r14,r5
    c.r[0] = ld32(0x060924A8u);  // 0609242C mov.l 0x060924A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092432u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092432u) return; }  // 0609242E jsr @r0 ; mov r8,r4
    c.r[0] = ld32(c.r[9]);  // 06092432 mov.l @r9,r0
    c.t = c.r[0] == 0x1u;  // 06092434 cmp/eq #1,r0
    if (c.t) { goto L_0609248E; }  // 06092436 bt 0x0609248E
L_06092438:
    c.r[0] = ld32(c.r[8] + 8);  // 06092438 mov.l @(8,r8),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609243A cmp/eq #-1,r0
    if (!c.t) { goto L_06092448; }  // 0609243C bf 0x06092448
    c.r[0] = ld32(0x060924ACu);  // 0609243E mov.l 0x060924AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092444u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092444u) return; }  // 06092440 jsr @r0 ; mov r8,r4
    c.r[14] += 4; goto L_06092492;  // 06092444 bra 0x06092492 ; add #4,r14
L_06092448:
    c.r[9] = ld32(0x060924B0u);  // 06092448 mov.l 0x060924B0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0609244Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609244Eu) return; }  // 0609244A jsr @r9 ; mov r8,r4
    c.t = (int32_t)c.r[0] >= 0;  // 0609244E cmp/pz r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06092490; } }  // 06092450 bf/s 0x06092490 ; mov r8,r1
    c.r[1] += 92;  // 06092454 add #92,r1
    c.r[1] = ld32(c.r[1]);  // 06092456 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092458 tst r1,r1
    if (c.t) { goto L_06092484; }  // 0609245A bt 0x06092484
    c.r[0] = ld32(0x060924B4u);  // 0609245C mov.l 0x060924B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092462u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092462u) return; }  // 0609245E jsr @r0 ; mov r8,r4
    c.t = c.r[0] == 0x6u;  // 06092462 cmp/eq #6,r0
    if (!c.t) { goto L_06092484; }  // 06092464 bf 0x06092484
    { const uint32_t x = c.r[9]; c.pr = 0x0609246Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609246Au) return; }  // 06092466 jsr @r9 ; mov r8,r4
    c.t = (int32_t)c.r[0] >= 0;  // 0609246A cmp/pz r0
    if (!c.t) { goto L_06092490; }  // 0609246C bf 0x06092490
    c.r[0] = ld32(0x060924B8u);  // 0609246E mov.l 0x060924B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092474u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092474u) return; }  // 06092470 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092474 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06092484; } }  // 06092476 bt/s 0x06092484 ; mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 0609247A mov.l r1,@(4,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0609247C mov.l r1,@(8,r8)
    c.r[1] = ld32(0x060924BCu);  // 0609247E mov.l 0x060924BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092484u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092484u) return; }  // 06092480 jsr @r1 ; mov r8,r4
L_06092484:
    c.r[0] = ld32(0x060924A0u);  // 06092484 mov.l 0x060924A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609248Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609248Au) return; }  // 06092486 jsr @r0 ; mov #0,r4
    c.t = (int32_t)c.r[0] >= 0;  // 0609248A cmp/pz r0
    if (!c.t) { goto L_06092490; }  // 0609248C bf 0x06092490
L_0609248E:
    c.r[0] = ld32(c.r[8] + 8);  // 0609248E mov.l @(8,r8),r0
L_06092490:
    c.r[14] += 4;  // 06092490 add #4,r14
L_06092492:
    c.r[15] = c.r[14];  // 06092492 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092494 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092496 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092498 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609249A rts ; mov.l @r15+,r8
}

void f_060924C0(SH2Context& c) {
    ran[2183] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060924C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060924C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060924C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060924C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060924C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060924CA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060924CC mov r15,r14
    c.r[1] = ld32(0x0609252Cu);  // 060924CE mov.l 0x0609252C,r1
    c.r[9] = ld32(c.r[1]);  // 060924D0 mov.l @r1,r9
    c.r[10] = c.r[4];  // 060924D2 mov r4,r10
    c.r[9] += 52;  // 060924D4 add #52,r9
    c.r[1] = c.r[9];  // 060924D6 mov r9,r1
    c.r[1] += 96;  // 060924D8 add #96,r1
    c.r[1] = ld32(c.r[1]);  // 060924DA mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060924DC tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060924E6; } }  // 060924DE bf/s 0x060924E6 ; mov #0,r0
    st32(c.r[10], c.r[0]); goto L_0609251A;  // 060924E2 bra 0x0609251A ; mov.l r0,@r10
L_060924E6:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 060924E6 cmp/ge r1,r0
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0609250C; } }  // 060924E8 bt/s 0x0609250C ; mov #0,r8
    c.r[11] = ld32(0x06092530u);  // 060924EC mov.l 0x06092530,r11
L_060924EE:
    c.r[0] = c.r[8];  // 060924EE mov r8,r0
    c.r[0] <<= 2;  // 060924F0 shll2 r0
    { const uint32_t x = c.r[11]; c.pr = 0x060924F6u; c.r[4] = ld32(c.r[0] + c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060924F6u) return; }  // 060924F2 jsr @r11 ; mov.l @(r0,r9),r4
    c.t = (int32_t)c.r[0] >= 0;  // 060924F6 cmp/pz r0
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_0609250C; } }  // 060924F8 bf/s 0x0609250C ; tst r0,r0
    if (!c.t) { goto L_06092500; }  // 060924FC bf 0x06092500
    c.r[8] -= 1;  // 060924FE add #-1,r8
L_06092500:
    c.r[1] = c.r[9];  // 06092500 mov r9,r1
    c.r[1] += 96;  // 06092502 add #96,r1
    c.r[1] = ld32(c.r[1]);  // 06092504 mov.l @r1,r1
    c.r[8] += 1;  // 06092506 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06092508 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_060924EE; }  // 0609250A bf 0x060924EE
L_0609250C:
    c.r[1] = ld32(c.r[9]);  // 0609250C mov.l @r9,r1
    c.t = c.r[0] == 0xFFFFFFECu;  // 0609250E cmp/eq #-20,r0
    { const bool k = !c.t; st32(c.r[10], c.r[1]); if (k) { goto L_0609251A; } }  // 06092510 bf/s 0x0609251A ; mov.l r1,@r10
    c.t = (int32_t)c.r[8] > 0;  // 06092514 cmp/pl r8
    if (!c.t) { goto L_0609251A; }  // 06092516 bf 0x0609251A
    c.r[0] = 0x1u;  // 06092518 mov #1,r0
L_0609251A:
    c.r[15] = c.r[14];  // 0609251A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609251C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609251E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06092520 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092522 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092524 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092526 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
