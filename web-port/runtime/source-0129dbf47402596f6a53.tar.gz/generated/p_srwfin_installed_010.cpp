#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060222B8(SH2Context& c) {
    ran[440] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060222B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060222BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060222BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060222BE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060222C0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060222C2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060222C4 mov.l r14,@-r15
    c.r[15] -= 80;  // 060222C6 add #-80,r15
    c.r[11] = ld32(0x06022410u);  // 060222C8 mov.l 0x06022410,r11
    c.r[1] = ld32(0x06022414u);  // 060222CA mov.l 0x06022414,r1
    c.r[1] = ld32(c.r[1]);  // 060222CC mov.l @r1,r1
    c.r[5] = 0x0u;  // 060222CE mov #0,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060222D0 cmp/ge r1,r5
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060222DA; } }  // 060222D2 bf/s 0x060222DA ; mov r15,r14
    goto L_060223F6;  // 060222D6 bra 0x060223F6 ; nop
L_060222DA:
    c.r[12] = c.r[14];  // 060222DA mov r14,r12
    c.r[12] += 1;  // 060222DC add #1,r12
    c.r[13] = ld32(0x06022418u);  // 060222DE mov.l 0x06022418,r13
    c.r[3] = c.r[5];  // 060222E0 mov r5,r3
L_060222E2:
    c.r[3] += c.r[3];  // 060222E2 add r3,r3
    c.r[0] = c.r[3];  // 060222E4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060222E6 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060222E8 extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602240Cu);  // 060222EA mov.w 0x0602240C,r0
    c.t = c.r[1] == c.r[0];  // 060222EC cmp/eq r0,r1
    { const bool k = c.t; c.r[10] = c.r[5]; if (k) { goto L_06022302; } }  // 060222EE bt/s 0x06022302 ; mov r5,r10
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602240Cu);  // 060222F2 mov.w 0x0602240C,r2
L_060222F4:
    c.r[3] += 2;  // 060222F4 add #2,r3
    c.r[0] = c.r[3];  // 060222F6 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060222F8 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060222FA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060222FC cmp/eq r2,r1
    { const bool k = !c.t; c.r[10] += 1; if (k) { SH2_POLL(c); goto L_060222F4; } }  // 060222FE bf/s 0x060222F4 ; add #1,r10
L_06022302:
    c.r[1] = c.r[10];  // 06022302 mov r10,r1
    c.r[1] += c.r[1];  // 06022304 add r1,r1
    c.r[1] += c.r[11];  // 06022306 add r11,r1
    c.r[1] += 1;  // 06022308 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602230A mov.b @r1,r1
    c.r[6] = 0x0u;  // 0602230C mov #0,r6
    c.r[7] = 0x0u;  // 0602230E mov #0,r7
    c.r[3] = 0x0u;  // 06022310 mov #0,r3
    c.r[9] = c.r[1] & 0xFFu;  // 06022312 extu.b r1,r9
    c.r[1] = c.r[9];  // 06022314 mov r9,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06022316 shar r1
    c.r[8] = c.r[1];  // 06022318 mov r1,r8
    c.r[8] -= 1;  // 0602231A add #-1,r8
    c.r[4] = c.r[1];  // 0602231C mov r1,r4
    c.r[1] = 0x27u;  // 0602231E mov #39,r1
L_06022320:
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06022320 cmp/gt r1,r6
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_0602237C; } }  // 06022322 bt/s 0x0602237C ; cmp/pz r8
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_06022348; } }  // 06022326 bf/s 0x06022348 ; mov r8,r2
    c.r[2] += c.r[5];  // 0602232A add r5,r2
    c.r[2] += c.r[2];  // 0602232C add r2,r2
    c.r[1] = c.r[2];  // 0602232E mov r2,r1
    c.r[1] += c.r[11];  // 06022330 add r11,r1
    c.r[0] = c.r[2];  // 06022332 mov r2,r0
    c.r[1] += 1;  // 06022334 add #1,r1
    c.r[6] += 1;  // 06022336 add #1,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06022338 mov.b @(r0,r11),r2
    c.r[8] -= 1;  // 0602233A add #-1,r8
    c.r[0] = c.r[3];  // 0602233C mov r3,r0
    st8(c.r[0] + c.r[14], c.r[2]);  // 0602233E mov.b r2,@(r0,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022340 mov.b @r1,r1
    c.r[3] += 2;  // 06022342 add #2,r3
    st8(c.r[0] + c.r[12], c.r[1]); goto L_0602234C;  // 06022344 bra 0x0602234C ; mov.b r1,@(r0,r12)
L_06022348:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602240Eu);  // 06022348 mov.w 0x0602240E,r0
    c.r[7] |= c.r[0];  // 0602234A or r0,r7
L_0602234C:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[9];  // 0602234C cmp/ge r9,r4
    { const bool k = c.t; c.r[0] = 0xFu; if (k) { goto L_06022372; } }  // 0602234E bt/s 0x06022372 ; mov #15,r0
    c.r[2] = c.r[4];  // 06022352 mov r4,r2
    c.r[2] += c.r[5];  // 06022354 add r5,r2
    c.r[2] += c.r[2];  // 06022356 add r2,r2
    c.r[1] = c.r[2];  // 06022358 mov r2,r1
    c.r[1] += c.r[11];  // 0602235A add r11,r1
    c.r[0] = c.r[2];  // 0602235C mov r2,r0
    c.r[1] += 1;  // 0602235E add #1,r1
    c.r[6] += 1;  // 06022360 add #1,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06022362 mov.b @(r0,r11),r2
    c.r[4] += 1;  // 06022364 add #1,r4
    c.r[0] = c.r[3];  // 06022366 mov r3,r0
    st8(c.r[0] + c.r[14], c.r[2]);  // 06022368 mov.b r2,@(r0,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602236A mov.b @r1,r1
    c.r[3] += 2;  // 0602236C add #2,r3
    st8(c.r[0] + c.r[12], c.r[1]); goto L_06022374;  // 0602236E bra 0x06022374 ; mov.b r1,@(r0,r12)
L_06022372:
    c.r[7] |= c.r[0];  // 06022372 or r0,r7
L_06022374:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602240Cu);  // 06022374 mov.w 0x0602240C,r0
    c.t = c.r[7] == c.r[0];  // 06022376 cmp/eq r0,r7
    { const bool k = !c.t; c.r[1] = 0x27u; if (k) { SH2_POLL(c); goto L_06022320; } }  // 06022378 bf/s 0x06022320 ; mov #39,r1
L_0602237C:
    c.r[1] = 0x0u;  // 0602237C mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[9];  // 0602237E cmp/ge r9,r1
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_060223E6; } }  // 06022380 bt/s 0x060223E6 ; mov r10,r5
    c.r[0] = ld32(0x0602241Cu);  // 06022384 mov.l 0x0602241C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06022386 mov.w @r0,r1
    c.r[3] = 0x0u;  // 06022388 mov #0,r3
    c.r[5] = c.r[1] & 0xFFFFu;  // 0602238A extu.w r1,r5
    c.r[0] = c.r[3];  // 0602238C mov r3,r0
L_0602238E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0602238E mov.b @(r0,r14),r1
    c.r[6] = c.r[1] & 0xFFu;  // 06022390 extu.b r1,r6
    c.r[0] = c.r[12];  // 06022392 mov r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06022394 mov.b @(r0,r3),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06022396 extu.b r1,r7
    c.r[1] = c.r[7];  // 06022398 mov r7,r1
    c.r[1] <<= 2;  // 0602239A shll2 r1
    c.r[1] <<= 2;  // 0602239C shll2 r1
    c.r[1] <<= 2;  // 0602239E shll2 r1
    c.r[0] = ld32(0x06022420u);  // 060223A0 mov.l 0x06022420,r0
    c.r[1] += c.r[0];  // 060223A2 add r0,r1
    c.r[0] = c.r[1];  // 060223A4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060223A6 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060223A8 extu.b r1,r1
    c.t = c.r[5] >= c.r[1];  // 060223AA cmp/hs r1,r5
    { const bool k = !c.t; c.r[4] = c.r[7]; if (k) { goto L_060223D8; } }  // 060223AC bf/s 0x060223D8 ; mov r7,r4
    c.r[1] = ld32(0x06022424u);  // 060223B0 mov.l 0x06022424,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060223B2 mov.b @r1,r2
    c.r[0] = ld32(0x06022428u);  // 060223B4 mov.l 0x06022428,r0
    c.r[1] = c.r[6];  // 060223B6 mov r6,r1
    c.r[1] += c.r[1];  // 060223B8 add r1,r1
    c.r[4] <<= 2;  // 060223BA shll2 r4
    c.r[4] <<= 2;  // 060223BC shll2 r4
    c.r[4] += c.r[4];  // 060223BE add r4,r4
    c.r[4] <<= 2;  // 060223C0 shll2 r4
    c.r[4] += c.r[0];  // 060223C2 add r0,r4
    c.r[0] = c.r[1];  // 060223C4 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 060223C6 mov.w @(r0,r4),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060223C8 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060223CA extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 060223CC cmp/hs r1,r2
    if (!c.t) { goto L_060223D8; }  // 060223CE bf 0x060223D8
    st32(c.r[13] + 12, c.r[6]);  // 060223D0 mov.l r6,@(12,r13)
    st32(c.r[13] + 16, c.r[7]);  // 060223D2 mov.l r7,@(16,r13)
    c.r[0] = 0x0u; goto L_060223F8;  // 060223D4 bra 0x060223F8 ; mov #0,r0
L_060223D8:
    c.r[3] += 2;  // 060223D8 add #2,r3
    c.r[1] = c.r[9];  // 060223DA mov r9,r1
    c.r[1] += c.r[1];  // 060223DC add r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060223DE cmp/ge r1,r3
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0602238E; } }  // 060223E0 bf/s 0x0602238E ; mov r3,r0
    c.r[5] = c.r[10];  // 060223E4 mov r10,r5
L_060223E6:
    c.r[1] = ld32(0x06022414u);  // 060223E6 mov.l 0x06022414,r1
    c.r[1] = ld32(c.r[1]);  // 060223E8 mov.l @r1,r1
    c.r[5] += 1;  // 060223EA add #1,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060223EC cmp/ge r1,r5
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_060223F6; } }  // 060223EE bt/s 0x060223F6 ; mov r5,r3
    SH2_POLL(c); goto L_060222E2;  // 060223F2 bra 0x060222E2 ; nop
L_060223F6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602240Cu);  // 060223F6 mov.w 0x0602240C,r0
L_060223F8:
    c.r[14] += 80;  // 060223F8 add #80,r14
    c.r[15] = c.r[14];  // 060223FA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060223FC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060223FE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06022400 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06022402 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06022404 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06022406 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06022408 rts ; mov.l @r15+,r8
}

void f_0602242C(SH2Context& c) {
    ran[441] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602242C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602242E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06022430 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06022432 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06022434 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06022436 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06022438 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602243A sts.l pr,@-r15
    c.r[15] -= 80;  // 0602243C add #-80,r15
    c.r[14] = c.r[15];  // 0602243E mov r15,r14
    c.r[11] = c.r[7];  // 06022440 mov r7,r11
    c.r[12] = c.r[4] & 0xFFu;  // 06022442 extu.b r4,r12
    c.r[9] = c.r[5] & 0xFFu;  // 06022444 extu.b r5,r9
    c.r[8] = c.r[6] & 0xFFu;  // 06022446 extu.b r6,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602254Au);  // 06022448 mov.w 0x0602254A,r1
    c.t = c.r[8] == c.r[1];  // 0602244A cmp/eq r1,r8
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06022532; } }  // 0602244C bt/s 0x06022532 ; mov #0,r10
    c.r[0] = ld32(0x0602254Cu);  // 06022450 mov.l 0x0602254C,r0
    c.r[4] = ld32(c.r[0]);  // 06022452 mov.l @r0,r4
    c.r[7] = 0x0u;  // 06022454 mov #0,r7
    c.r[6] = 0xFFFFFFF9u;  // 06022456 mov #-7,r6
    c.r[0] = ld32(0x06022550u);  // 06022458 mov.l 0x06022550,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602245Eu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602245Eu) return; }  // 0602245A jsr @r0 ; mov r14,r5
    c.r[13] = c.r[0];  // 0602245E mov r0,r13
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06022460 mov.l r10,@-r15
    c.r[7] = c.r[8];  // 06022462 mov r8,r7
    c.r[6] = c.r[9];  // 06022464 mov r9,r6
    c.r[4] = ld32(0x06022554u);  // 06022466 mov.l 0x06022554,r4
    c.r[0] = ld32(0x06022558u);  // 06022468 mov.l 0x06022558,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602246Eu; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602246Eu) return; }  // 0602246A jsr @r0 ; mov r12,r5
    c.r[1] = c.r[0];  // 0602246E mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06022470 extu.b r1,r12
    c.r[9] = 0x0u;  // 06022472 mov #0,r9
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[13];  // 06022474 cmp/ge r13,r10
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06022532; } }  // 06022476 bt/s 0x06022532 ; add #4,r15
    c.r[5] = ld32(0x0602254Cu);  // 0602247A mov.l 0x0602254C,r5
    c.r[2] = c.r[9];  // 0602247C mov r9,r2
L_0602247E:
    c.r[1] = ld32(c.r[5]);  // 0602247E mov.l @r5,r1
    c.r[2] <<= 2;  // 06022480 shll2 r2
    c.r[2] <<= 2;  // 06022482 shll2 r2
    c.r[2] += c.r[1];  // 06022484 add r1,r2
    c.r[1] = c.r[2];  // 06022486 mov r2,r1
    c.r[1] += 11;  // 06022488 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602248A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602248C extu.b r1,r1
    c.r[1] >>= 2;  // 0602248E shlr2 r1
    c.r[1] >>= 2;  // 06022490 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06022492 shlr r1
    c.r[1] >>= 2;  // 06022494 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06022496 tst r1,r1
    if (!c.t) { goto L_0602252A; }  // 06022498 bf 0x0602252A
    c.r[2] += 3;  // 0602249A add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602249C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0602249E mov r1,r0
    c.r[0] >>= 2;  // 060224A0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060224A2 shlr r0
    c.r[0] &= 0x3u;  // 060224A4 and #3,r0
    c.t = c.r[0] == 0x2u;  // 060224A6 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_0602252A; } }  // 060224A8 bt/s 0x0602252A ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060224AC mov.b @(r0,r9),r1
    c.r[8] = c.r[1] & 0xFFu;  // 060224AE extu.b r1,r8
    c.r[4] = c.r[8] & 0xFFu;  // 060224B0 extu.b r8,r4
    c.r[1] = ld32(0x0602255Cu);  // 060224B2 mov.l 0x0602255C,r1
    c.r[0] = 0x4Cu;  // 060224B4 mov #76,r0
    c.r[0] += c.r[14];  // 060224B6 add r14,r0
    { const uint32_t x = c.r[1]; c.pr = 0x060224BCu; st32(c.r[0], c.r[5]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060224BCu) return; }  // 060224B8 jsr @r1 ; mov.l r5,@r0
    c.r[0] = 0x4Cu;  // 060224BC mov #76,r0
    c.r[0] += c.r[14];  // 060224BE add r14,r0
    c.r[3] = c.r[8];  // 060224C0 mov r8,r3
    c.r[5] = ld32(c.r[0]);  // 060224C2 mov.l @r0,r5
    c.r[3] <<= 2;  // 060224C4 shll2 r3
    c.r[3] <<= 2;  // 060224C6 shll2 r3
    c.r[7] = ld32(c.r[5]);  // 060224C8 mov.l @r5,r7
    c.r[2] = c.r[3];  // 060224CA mov r3,r2
    c.r[2] += c.r[7];  // 060224CC add r7,r2
    c.r[1] = c.r[2];  // 060224CE mov r2,r1
    c.r[1] += 4;  // 060224D0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060224D2 mov.b @r1,r1
    c.r[0] = 0x1u;  // 060224D4 mov #1,r0
    c.r[1] >>= 2;  // 060224D6 shlr2 r1
    c.r[1] >>= 2;  // 060224D8 shlr2 r1
    c.r[1] >>= 2;  // 060224DA shlr2 r1
    c.r[1] &= c.r[0];  // 060224DC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060224DE tst r1,r1
    if (!c.t) { goto L_0602252A; }  // 060224E0 bf 0x0602252A
    c.r[2] += 1;  // 060224E2 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060224E4 mov.b @r2,r1
    c.r[0] = c.r[3];  // 060224E6 mov r3,r0
    c.r[6] = c.r[1] & 0xFFu;  // 060224E8 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060224EA mov.b @(r0,r7),r1
    c.r[7] = c.r[1] & 0xFFu;  // 060224EC extu.b r1,r7
    c.r[1] = 0x0u;  // 060224EE mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[12];  // 060224F0 cmp/ge r12,r1
    if (c.t) { goto L_0602252A; }  // 060224F2 bt 0x0602252A
    c.r[4] = 0x0u;  // 060224F4 mov #0,r4
    c.r[2] = ld32(0x06022554u);  // 060224F6 mov.l 0x06022554,r2
    c.r[3] = c.r[12];  // 060224F8 mov r12,r3
    c.r[3] += c.r[3];  // 060224FA add r3,r3
    c.r[3] += c.r[2];  // 060224FC add r2,r3
L_060224FE:
    c.r[0] = ld32(0x06022554u);  // 060224FE mov.l 0x06022554,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06022500 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06022502 extu.b r1,r1
    c.t = c.r[7] == c.r[1];  // 06022504 cmp/eq r1,r7
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06022522; } }  // 06022506 bf/s 0x06022522 ; mov r2,r1
    c.r[1] += 1;  // 0602250A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602250C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602250E extu.b r1,r1
    c.t = c.r[6] == c.r[1];  // 06022510 cmp/eq r1,r6
    { const bool k = !c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06022522; } }  // 06022512 bf/s 0x06022522 ; tst r11,r11
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_0602251E; } }  // 06022516 bt/s 0x0602251E ; mov r10,r1
    c.r[0] = c.r[11];  // 0602251A mov r11,r0
    st8(c.r[0] + c.r[10], c.r[8]);  // 0602251C mov.b r8,@(r0,r10)
L_0602251E:
    c.r[1] += 1;  // 0602251E add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06022520 extu.b r1,r10
L_06022522:
    c.r[2] += 2;  // 06022522 add #2,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06022524 cmp/ge r3,r2
    { const bool k = !c.t; c.r[4] += 2; if (k) { SH2_POLL(c); goto L_060224FE; } }  // 06022526 bf/s 0x060224FE ; add #2,r4
L_0602252A:
    c.r[9] += 1;  // 0602252A add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[13];  // 0602252C cmp/ge r13,r9
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { SH2_POLL(c); goto L_0602247E; } }  // 0602252E bf/s 0x0602247E ; mov r9,r2
L_06022532:
    c.r[14] += 80;  // 06022532 add #80,r14
    c.r[15] = c.r[14];  // 06022534 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06022536 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06022538 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602253A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602253C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602253E mov.l @r15+,r11
    c.r[0] = c.r[10];  // 06022540 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06022542 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06022544 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06022546 rts ; mov.l @r15+,r8
}

void f_06022568(SH2Context& c) {
    ran[442] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06022568 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602256A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602256C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602256E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06022570 mov r15,r14
    c.r[9] = c.r[5];  // 06022572 mov r5,r9
    c.r[1] = ld32(0x060225F4u);  // 06022574 mov.l 0x060225F4,r1
    c.r[1] = ld32(c.r[1]);  // 06022576 mov.l @r1,r1
    c.t = (int32_t)c.r[4] >= 0;  // 06022578 cmp/pz r4
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_06022580; } }  // 0602257A bt/s 0x06022580 ; mov r4,r2
    c.r[2] += 7;  // 0602257E add #7,r2
L_06022580:
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06022580 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06022582 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06022584 shar r2
    c.r[2] += c.r[1];  // 06022586 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060225EAu);  // 06022588 mov.w 0x060225EA,r1
    c.r[0] = c.r[2];  // 0602258A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602258C mov.b @(r0,r1),r1
    c.r[8] = c.r[1];  // 0602258E mov r1,r8
    c.r[8] <<= 16;  // 06022590 shll16 r8
    c.r[8] <<= 8;  // 06022592 shll8 r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060225ECu);  // 06022594 mov.w 0x060225EC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022596 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06022598 extu.b r1,r1
    c.r[1] <<= 16;  // 0602259A shll16 r1
    c.r[8] |= c.r[1];  // 0602259C or r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060225EEu);  // 0602259E mov.w 0x060225EE,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060225A0 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060225A2 extu.b r1,r1
    c.r[1] <<= 8;  // 060225A4 shll8 r1
    c.r[8] |= c.r[1];  // 060225A6 or r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060225F0u);  // 060225A8 mov.w 0x060225F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060225AA mov.b @(r0,r1),r1
    c.t = (int32_t)c.r[4] >= 0;  // 060225AC cmp/pz r4
    c.r[1] = c.r[1] & 0xFFu;  // 060225AE extu.b r1,r1
    c.r[8] |= c.r[1];  // 060225B0 or r1,r8
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_060225B8; } }  // 060225B2 bt/s 0x060225B8 ; mov r4,r1
    c.r[1] += 7;  // 060225B6 add #7,r1
L_060225B8:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060225B8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060225BA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060225BC shar r1
    c.r[1] <<= 2;  // 060225BE shll2 r1
    c.r[1] += c.r[1];  // 060225C0 add r1,r1
    c.r[4] -= c.r[1];  // 060225C2 sub r1,r4
    c.r[4] += c.r[9];  // 060225C4 add r9,r4
    c.r[5] = 0u - c.r[4];  // 060225C6 neg r4,r5
    c.r[5] += 32;  // 060225C8 add #32,r5
    c.r[0] = ld32(0x060225F8u);  // 060225CA mov.l 0x060225F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060225D0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060225D0u) return; }  // 060225CC jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0];  // 060225D0 mov r0,r8
    c.r[0] = ld32(0x060225FCu);  // 060225D2 mov.l 0x060225FC,r0
    c.r[5] = c.r[9];  // 060225D4 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060225DAu; c.r[4] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060225DAu) return; }  // 060225D6 jsr @r0 ; mov #-1,r4
    c.r[15] = c.r[14];  // 060225DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060225DC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060225DE mov.l @r15+,r14
    c.r[0] = ~c.r[0];  // 060225E0 not r0,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060225E2 mov.l @r15+,r9
    c.r[0] &= c.r[8];  // 060225E4 and r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060225E6 rts ; mov.l @r15+,r8
}

void f_06022608(SH2Context& c) {
    ran[443] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06022608 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602260A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602260C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602260E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06022610 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06022612 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06022614 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06022616 sts.l pr,@-r15
    c.r[15] -= 16;  // 06022618 add #-16,r15
    c.r[14] = c.r[15];  // 0602261A mov r15,r14
    c.r[11] = c.r[4];  // 0602261C mov r4,r11
    st32(c.r[14], c.r[5]);  // 0602261E mov.l r5,@r14
    c.r[12] = c.r[6];  // 06022620 mov r6,r12
    c.r[0] = ld32(0x06022720u);  // 06022622 mov.l 0x06022720,r0
    c.r[2] = ld32(c.r[0]);  // 06022624 mov.l @r0,r2
    c.t = (int32_t)c.r[11] >= 0;  // 06022626 cmp/pz r11
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602262E; } }  // 06022628 bt/s 0x0602262E ; mov r11,r1
    c.r[1] += 7;  // 0602262C add #7,r1
L_0602262E:
    c.r[13] = c.r[1];  // 0602262E mov r1,r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 06022630 shar r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 06022632 shar r13
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 06022634 shar r13
    c.r[13] += c.r[2];  // 06022636 add r2,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022716u);  // 06022638 mov.w 0x06022716,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0602263A mov.b @(r0,r13),r1
    c.r[10] = c.r[1];  // 0602263C mov r1,r10
    c.r[10] <<= 16;  // 0602263E shll16 r10
    c.r[10] <<= 8;  // 06022640 shll8 r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022718u);  // 06022642 mov.w 0x06022718,r0
    st32(c.r[14] + 4, c.r[0]);  // 06022644 mov.l r0,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06022646 mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06022648 extu.b r1,r1
    c.r[1] <<= 16;  // 0602264A shll16 r1
    c.r[10] |= c.r[1];  // 0602264C or r1,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602271Au);  // 0602264E mov.w 0x0602271A,r0
    st32(c.r[14] + 8, c.r[0]);  // 06022650 mov.l r0,@(8,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06022652 mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06022654 extu.b r1,r1
    c.r[1] <<= 8;  // 06022656 shll8 r1
    c.r[10] |= c.r[1];  // 06022658 or r1,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602271Cu);  // 0602265A mov.w 0x0602271C,r0
    st32(c.r[14] + 12, c.r[0]);  // 0602265C mov.l r0,@(12,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0602265E mov.b @(r0,r13),r1
    c.t = (int32_t)c.r[11] >= 0;  // 06022660 cmp/pz r11
    c.r[1] = c.r[1] & 0xFFu;  // 06022662 extu.b r1,r1
    c.r[10] |= c.r[1];  // 06022664 or r1,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602266C; } }  // 06022666 bt/s 0x0602266C ; mov r11,r1
    c.r[1] += 7;  // 0602266A add #7,r1
L_0602266C:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0602266C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0602266E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06022670 shar r1
    c.r[1] <<= 2;  // 06022672 shll2 r1
    c.r[1] += c.r[1];  // 06022674 add r1,r1
    c.r[8] = c.r[11];  // 06022676 mov r11,r8
    c.r[8] -= c.r[1];  // 06022678 sub r1,r8
    c.r[9] = ld32(0x06022724u);  // 0602267A mov.l 0x06022724,r9
    c.r[0] = ld32(c.r[14]);  // 0602267C mov.l @r14,r0
    c.r[4] = c.r[12];  // 0602267E mov r12,r4
    c.r[8] += c.r[0];  // 06022680 add r0,r8
    c.r[8] = 0u - c.r[8];  // 06022682 neg r8,r8
    c.r[8] += 32;  // 06022684 add #32,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602268Au; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602268Au) return; }  // 06022686 jsr @r9 ; mov r8,r5
    c.r[12] = c.r[0];  // 0602268A mov r0,r12
    c.r[5] = ld32(c.r[14]);  // 0602268C mov.l @r14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06022692u; c.r[4] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022692u) return; }  // 0602268E jsr @r9 ; mov #-1,r4
    c.r[1] = c.r[0];  // 06022692 mov r0,r1
    c.r[4] = ~c.r[1];  // 06022694 not r1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0602269Au; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602269Au) return; }  // 06022696 jsr @r9 ; mov r8,r5
    c.r[1] = c.r[0];  // 0602269A mov r0,r1
    c.r[1] = ~c.r[1];  // 0602269C not r1,r1
    c.r[1] &= c.r[10];  // 0602269E and r10,r1
    c.r[12] |= c.r[1];  // 060226A0 or r1,r12
    c.r[1] = c.r[12];  // 060226A2 mov r12,r1
    c.r[1] >>= 16;  // 060226A4 shlr16 r1
    c.r[1] >>= 8;  // 060226A6 shlr8 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022716u);  // 060226A8 mov.w 0x06022716,r0
    st8(c.r[0] + c.r[13], c.r[1]);  // 060226AA mov.b r1,@(r0,r13)
    c.r[0] = ld32(0x06022720u);  // 060226AC mov.l 0x06022720,r0
    c.r[1] = c.r[11];  // 060226AE mov r11,r1
    c.t = (int32_t)c.r[11] >= 0;  // 060226B0 cmp/pz r11
    { const bool k = c.t; c.r[2] = ld32(c.r[0]); if (k) { goto L_060226B8; } }  // 060226B2 bt/s 0x060226B8 ; mov.l @r0,r2
    c.r[1] += 7;  // 060226B6 add #7,r1
L_060226B8:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226B8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226BA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226BC shar r1
    c.r[2] += c.r[1];  // 060226BE add r1,r2
    c.r[1] = c.r[12];  // 060226C0 mov r12,r1
    c.r[1] >>= 16;  // 060226C2 shlr16 r1
    c.r[0] = ld32(c.r[14] + 4);  // 060226C4 mov.l @(4,r14),r0
    c.t = (int32_t)c.r[11] >= 0;  // 060226C6 cmp/pz r11
    st8(c.r[0] + c.r[2], c.r[1]);  // 060226C8 mov.b r1,@(r0,r2)
    c.r[0] = ld32(0x06022720u);  // 060226CA mov.l 0x06022720,r0
    c.r[2] = ld32(c.r[0]);  // 060226CC mov.l @r0,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060226D4; } }  // 060226CE bt/s 0x060226D4 ; mov r11,r1
    c.r[1] += 7;  // 060226D2 add #7,r1
L_060226D4:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226D4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226D6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226D8 shar r1
    c.r[2] += c.r[1];  // 060226DA add r1,r2
    c.r[1] = c.r[12];  // 060226DC mov r12,r1
    c.r[1] >>= 8;  // 060226DE shlr8 r1
    c.r[0] = ld32(c.r[14] + 8);  // 060226E0 mov.l @(8,r14),r0
    c.r[4] = c.r[11];  // 060226E2 mov r11,r4
    st8(c.r[0] + c.r[2], c.r[1]);  // 060226E4 mov.b r1,@(r0,r2)
    c.r[0] = ld32(0x06022720u);  // 060226E6 mov.l 0x06022720,r0
    c.t = (int32_t)c.r[4] >= 0;  // 060226E8 cmp/pz r4
    { const bool k = c.t; c.r[2] = ld32(c.r[0]); if (k) { goto L_060226F0; } }  // 060226EA bt/s 0x060226F0 ; mov.l @r0,r2
    c.r[4] += 7;  // 060226EE add #7,r4
L_060226F0:
    c.r[1] = c.r[4];  // 060226F0 mov r4,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226F2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226F4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060226F6 shar r1
    c.r[0] = ld32(c.r[14] + 12);  // 060226F8 mov.l @(12,r14),r0
    c.r[2] += c.r[1];  // 060226FA add r1,r2
    st8(c.r[0] + c.r[2], c.r[12]);  // 060226FC mov.b r12,@(r0,r2)
    c.r[14] += 16;  // 060226FE add #16,r14
    c.r[15] = c.r[14];  // 06022700 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06022702 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06022704 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06022706 mov.l @r15+,r13
    c.r[0] = c.r[12];  // 06022708 mov r12,r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602270A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602270C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602270E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06022710 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06022712 rts ; mov.l @r15+,r8
}

void f_06022728(SH2Context& c) {
    ran[444] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06022728 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602272A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602272C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602272E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06022730 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06022732 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06022734 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06022736 sts.l pr,@-r15
    c.r[15] -= 12;  // 06022738 add #-12,r15
    c.r[14] = c.r[15];  // 0602273A mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 0602273C extu.b r4,r13
    c.r[10] = ld32(0x0602284Cu);  // 0602273E mov.l 0x0602284C,r10
    c.r[9] = c.r[13];  // 06022740 mov r13,r9
    c.r[9] <<= 2;  // 06022742 shll2 r9
    c.r[9] <<= 2;  // 06022744 shll2 r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x06022840u);  // 06022746 mov.w 0x06022840,r11
    c.r[1] = ld32(c.r[10]);  // 06022748 mov.l @r10,r1
    c.r[0] = ld32(0x06022850u);  // 0602274A mov.l 0x06022850,r0
    c.r[1] += c.r[9];  // 0602274C add r9,r1
    c.r[1] += 2;  // 0602274E add #2,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022750 mov.b @r1,r8
    c.r[6] = c.r[11];  // 06022752 mov r11,r6
    c.r[4] = ld32(c.r[0]);  // 06022754 mov.l @r0,r4
    c.r[8] = c.r[8] & 0xFFu;  // 06022756 extu.b r8,r8
    c.r[1] = ld32(0x06022854u);  // 06022758 mov.l 0x06022854,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602275Eu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602275Eu) return; }  // 0602275A jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06022858u);  // 0602275E mov.l 0x06022858,r1
    c.r[2] = ld32(c.r[1]);  // 06022760 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06022762 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06022764 mul.l r1,r8
    c.r[3] = c.r[9];  // 06022766 mov r9,r3
    c.r[1] = c.macl;  // 06022768 sts macl,r1
    c.r[1] += c.r[2];  // 0602276A add r2,r1
    c.r[1] += 15;  // 0602276C add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602276E mov.b @r1,r2
    c.r[0] = c.r[9];  // 06022770 mov r9,r0
    c.r[1] = ld32(c.r[10]);  // 06022772 mov.l @r10,r1
    c.r[12] = 0x0u;  // 06022774 mov #0,r12
    c.r[3] += c.r[1];  // 06022776 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022778 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0602277A add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602277C extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0602277E mov.l r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06022780 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06022782 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06022784 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 06022786 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0602285Cu);  // 06022788 mov.l 0x0602285C,r1
    c.r[3] = ld32(c.r[1]);  // 0602278A mov.l @r1,r3
    c.r[1] = c.r[2];  // 0602278C mov r2,r1
    c.r[1] += c.r[1];  // 0602278E add r1,r1
    c.r[1] += c.r[2];  // 06022790 add r2,r1
    c.r[1] <<= 2;  // 06022792 shll2 r1
    c.r[0] = c.r[1];  // 06022794 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06022796 mov.w @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06022842u);  // 06022798 mov.w 0x06022842,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602279A extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0602279C cmp/eq r2,r1
    { const bool k = !c.t; c.r[9] = c.r[11]; if (k) { goto L_060227F6; } }  // 0602279E bf/s 0x060227F6 ; mov r11,r9
    c.r[1] = ld32(0x06022860u);  // 060227A2 mov.l 0x06022860,r1
    c.r[2] = ld32(c.r[1]);  // 060227A4 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06022844u);  // 060227A6 mov.w 0x06022844,r1
    c.r[0] = c.r[2];  // 060227A8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060227AA mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060227AC extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060227AE cmp/ge r1,r12
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_060227F6; } }  // 060227B0 bt/s 0x060227F6 ; mov #0,r7
    c.r[6] = c.r[2];  // 060227B4 mov r2,r6
    c.r[0] = ld32(0x06022850u);  // 060227B6 mov.l 0x06022850,r0
    c.r[4] = ld32(c.r[0]);  // 060227B8 mov.l @r0,r4
    c.r[10] = (uint32_t)(int16_t)ld16(0x06022846u);  // 060227BA mov.w 0x06022846,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06022848u);  // 060227BC mov.w 0x06022848,r8
    c.r[5] = ld32(0x06022864u);  // 060227BE mov.l 0x06022864,r5
    c.r[3] = c.r[6];  // 060227C0 mov r6,r3
    c.r[2] = 0x0u;  // 060227C2 mov #0,r2
L_060227C4:
    c.r[1] = c.r[3];  // 060227C4 mov r3,r1
    c.r[1] += 1;  // 060227C6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060227C8 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060227CA extu.b r1,r9
    c.r[1] = c.r[9];  // 060227CC mov r9,r1
    c.r[1] <<= 2;  // 060227CE shll2 r1
    c.r[1] += c.r[9];  // 060227D0 add r9,r1
    c.r[1] <<= 2;  // 060227D2 shll2 r1
    c.r[1] += c.r[4];  // 060227D4 add r4,r1
    c.r[1] += 44;  // 060227D6 add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060227D8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060227DA extu.w r1,r1
    c.t = c.r[1] == c.r[10];  // 060227DC cmp/eq r10,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[8]; if (k) { goto L_0602283A; } }  // 060227DE bt/s 0x0602283A ; cmp/eq r8,r1
    if (!c.t) { goto L_060227E6; }  // 060227E2 bf 0x060227E6
    st16(c.r[5], c.r[9]);  // 060227E4 mov.w r9,@r5
L_060227E6:
    c.r[3] += 2;  // 060227E6 add #2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022844u);  // 060227E8 mov.w 0x06022844,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060227EA mov.b @(r0,r6),r1
    c.r[7] += 1;  // 060227EC add #1,r7
    c.r[1] = c.r[1] & 0xFFu;  // 060227EE extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 060227F0 cmp/ge r1,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_060227C4; } }  // 060227F2 bf/s 0x060227C4 ; add #2,r2
L_060227F6:
    c.r[7] = ld32(0x06022868u);  // 060227F6 mov.l 0x06022868,r7
    c.r[1] = c.r[7];  // 060227F8 mov r7,r1
    c.r[1] += 24;  // 060227FA add #24,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060227FC mov.w @r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060227FE exts.w r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06022800 cmp/eq #-1,r0
    if (c.t) { goto L_0602286C; }  // 06022802 bt 0x0602286C
    c.r[1] = ld32(0x06022850u);  // 06022804 mov.l 0x06022850,r1
    c.r[3] = ld32(c.r[1]);  // 06022806 mov.l @r1,r3
    c.r[1] = 0x14u;  // 06022808 mov #20,r1
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[2] * (int16_t)c.r[1]);  // 0602280A muls.w r1,r2
    c.r[1] = c.macl;  // 0602280C sts macl,r1
    c.r[3] += c.r[1];  // 0602280E add r1,r3
    c.r[1] = c.r[3];  // 06022810 mov r3,r1
    c.r[1] += 51;  // 06022812 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022814 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06022816 mov r1,r0
    c.r[0] >>= 2;  // 06022818 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602281A shlr r0
    c.r[0] &= 0x1u;  // 0602281C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602281E tst r0,r0
    if (!c.t) { goto L_060228C8; }  // 06022820 bf 0x060228C8
    c.r[3] += 50;  // 06022822 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06022824 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06022826 extu.b r1,r0
    c.r[0] >>= 2;  // 06022828 shlr2 r0
    c.r[0] >>= 2;  // 0602282A shlr2 r0
    c.r[0] >>= 2;  // 0602282C shlr2 r0
    c.t = c.r[0] == 0x2u;  // 0602282E cmp/eq #2,r0
    if (!c.t) { goto L_060228C8; }  // 06022830 bf 0x060228C8
    c.r[7] += 25;  // 06022832 add #25,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06022834 mov.b @r7,r1
    c.r[9] = c.r[1] & 0xFFu; goto L_060228C8;  // 06022836 bra 0x060228C8 ; extu.b r1,r9
L_0602283A:
    c.r[1] = ld32(0x06022864u);  // 0602283A mov.l 0x06022864,r1
    st16(c.r[1], c.r[9]); SH2_POLL(c); goto L_060227F6;  // 0602283C bra 0x060227F6 ; mov.w r9,@r1
L_0602286C:
    c.r[1] = ld32(0x06022994u);  // 0602286C mov.l 0x06022994,r1
    c.r[2] = ld32(c.r[1]);  // 0602286E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602298Eu);  // 06022870 mov.w 0x0602298E,r1
    c.r[0] = c.r[2];  // 06022872 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022874 mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 06022876 mov #0,r7
    c.r[3] = c.r[1] & 0xFFu;  // 06022878 extu.b r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 0602287A cmp/ge r3,r7
    if (c.t) { goto L_060228C8; }  // 0602287C bt 0x060228C8
    c.r[5] = c.r[2];  // 0602287E mov r2,r5
    c.r[1] = ld32(0x06022998u);  // 06022880 mov.l 0x06022998,r1
    c.r[8] = ld32(c.r[1]);  // 06022882 mov.l @r1,r8
    c.r[4] = c.r[3];  // 06022884 mov r3,r4
    c.r[6] = c.r[5];  // 06022886 mov r5,r6
    c.r[3] = 0x0u;  // 06022888 mov #0,r3
L_0602288A:
    c.r[1] = c.r[6];  // 0602288A mov r6,r1
    c.r[1] += 1;  // 0602288C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602288E mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06022890 extu.b r1,r9
    c.r[2] = c.r[9];  // 06022892 mov r9,r2
    c.r[2] <<= 2;  // 06022894 shll2 r2
    c.r[2] += c.r[9];  // 06022896 add r9,r2
    c.r[2] <<= 2;  // 06022898 shll2 r2
    c.r[2] += c.r[8];  // 0602289A add r8,r2
    c.r[1] = c.r[2];  // 0602289C mov r2,r1
    c.r[1] += 51;  // 0602289E add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060228A0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060228A2 mov r1,r0
    c.r[0] >>= 2;  // 060228A4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060228A6 shlr r0
    c.r[0] &= 0x1u;  // 060228A8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060228AA tst r0,r0
    { const bool k = !c.t; c.r[2] += 50; if (k) { goto L_060228BE; } }  // 060228AC bf/s 0x060228BE ; add #50,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060228B0 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060228B2 extu.b r1,r0
    c.r[0] >>= 2;  // 060228B4 shlr2 r0
    c.r[0] >>= 2;  // 060228B6 shlr2 r0
    c.r[0] >>= 2;  // 060228B8 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 060228BA cmp/eq #2,r0
    if (c.t) { goto L_060228C8; }  // 060228BC bt 0x060228C8
L_060228BE:
    c.r[6] += 2;  // 060228BE add #2,r6
    c.r[7] += 1;  // 060228C0 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[4];  // 060228C2 cmp/ge r4,r7
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0602288A; } }  // 060228C4 bf/s 0x0602288A ; add #2,r3
L_060228C8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06022990u);  // 060228C8 mov.w 0x06022990,r1
    c.t = c.r[9] == c.r[1];  // 060228CA cmp/eq r1,r9
    { const bool k = !c.t; c.r[10] = c.r[1]; if (k) { goto L_060228D4; } }  // 060228CC bf/s 0x060228D4 ; mov r1,r10
    goto L_06022B26;  // 060228D0 bra 0x06022B26 ; nop
L_060228D4:
    c.r[1] = ld32(0x06022998u);  // 060228D4 mov.l 0x06022998,r1
    c.r[2] = ld32(c.r[1]);  // 060228D6 mov.l @r1,r2
    c.r[1] = c.r[9];  // 060228D8 mov r9,r1
    c.r[1] <<= 2;  // 060228DA shll2 r1
    c.r[1] += c.r[9];  // 060228DC add r9,r1
    c.r[1] <<= 2;  // 060228DE shll2 r1
    c.r[2] += c.r[1];  // 060228E0 add r1,r2
    c.r[1] = c.r[2];  // 060228E2 mov r2,r1
    c.r[1] += 61;  // 060228E4 add #61,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060228E6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060228E8 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 060228EA mov.l r1,@(8,r14)
    c.r[1] = c.r[2];  // 060228EC mov r2,r1
    c.r[1] += 62;  // 060228EE add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060228F0 mov.b @r1,r1
    c.r[2] += 50;  // 060228F2 add #50,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060228F4 mov.b @r2,r0
    c.r[11] = c.r[1] & 0xFFu;  // 060228F6 extu.b r1,r11
    c.r[0] &= 0x3Fu;  // 060228F8 and #63,r0
    c.r[1] = ld32(0x0602299Cu);  // 060228FA mov.l 0x0602299C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060228FC mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060228FE extu.b r1,r2
    c.r[1] = 0x8u;  // 06022900 mov #8,r1
    c.r[2] -= 1;  // 06022902 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06022904 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602290E; } }  // 06022906 bf/s 0x0602290E ; mov r2,r1
    goto L_06022ADA;  // 0602290A bra 0x06022ADA ; nop
L_0602290E:
    c.r[1] += c.r[1];  // 0602290E add r1,r1
    c.r[0] = 0x0602291Cu;  // 06022910 mova 0x0602291C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06022912 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06022914 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0602292Eu: goto L_0602292E; case 0x06022ADAu: goto L_06022ADA; case 0x060229BCu: goto L_060229BC; case 0x06022A92u: goto L_06022A92; case 0x06022A96u: goto L_06022A96; case 0x06022A9Au: goto L_06022A9A; case 0x06022A9Eu: goto L_06022A9E; case 0x06022AD8u: goto L_06022AD8; default: sh2_call(c, x); return; } }  // 06022916 jmp @r0 ; nop
L_0602292E:
    c.r[1] = ld32(0x060229A0u);  // 0602292E mov.l 0x060229A0,r1
    c.r[2] = c.r[13];  // 06022930 mov r13,r2
    c.r[2] <<= 2;  // 06022932 shll2 r2
    c.r[2] <<= 2;  // 06022934 shll2 r2
    c.r[0] = c.r[2];  // 06022936 mov r2,r0
    c.r[3] = ld32(c.r[1]);  // 06022938 mov.l @r1,r3
    c.r[7] = c.r[11];  // 0602293A mov r11,r7
    c.r[1] = c.r[2];  // 0602293C mov r2,r1
    c.r[1] += c.r[3];  // 0602293E add r3,r1
    c.r[1] += 1;  // 06022940 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022942 mov.b @r1,r6
    c.r[4] = ld32(0x060229A4u);  // 06022944 mov.l 0x060229A4,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06022946 mov.b @(r0,r3),r5
    c.r[6] = c.r[6] & 0xFFu;  // 06022948 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0602294A extu.b r5,r5
    c.r[1] = 0x0u;  // 0602294C mov #0,r1
    c.r[0] = ld32(0x060229A8u);  // 0602294E mov.l 0x060229A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022954u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022954u) return; }  // 06022950 jsr @r0 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 06022954 mov r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06022956 extu.b r1,r5
    c.r[6] = c.r[9];  // 06022958 mov r9,r6
    c.r[0] = ld32(0x060229ACu);  // 0602295A mov.l 0x060229AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022960u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022960u) return; }  // 0602295C jsr @r0 ; mov r13,r4
    c.r[2] = c.r[0];  // 06022960 mov r0,r2
    c.r[1] = 0x1u;  // 06022962 mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06022964 cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0602296E; } }  // 06022966 bt/s 0x0602296E ; mov #0,r0
    goto L_06022B26;  // 0602296A bra 0x06022B26 ; nop
L_0602296E:
    c.r[14] += 12; goto L_06022B34;  // 0602296E bra 0x06022B34 ; add #12,r14
L_06022972:
    c.r[3] = ld32(0x060229B0u);  // 06022972 mov.l 0x060229B0,r3
    c.r[2] = c.r[3];  // 06022974 mov r3,r2
    c.r[2] += 2;  // 06022976 add #2,r2
    st8(c.r[2], c.r[1]);  // 06022978 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0602297A mov.b r1,@r3
    c.r[1] = ld32(0x060229B4u);  // 0602297C mov.l 0x060229B4,r1
    c.r[0] = 0x3u;  // 0602297E mov #3,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06022980 mov.b @(r0,r14),r0
    st8(c.r[1], c.r[0]);  // 06022982 mov.b r0,@r1
    c.r[1] = ld32(0x060229B8u);  // 06022984 mov.l 0x060229B8,r1
    c.r[0] = 0x7u;  // 06022986 mov #7,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06022988 mov.b @(r0,r14),r0
    st8(c.r[1], c.r[0]); goto L_06022A72;  // 0602298A bra 0x06022A72 ; mov.b r0,@r1
L_060229BC:
    c.r[2] = ld32(0x06022AACu);  // 060229BC mov.l 0x06022AAC,r2
    c.r[1] = 0x0u;  // 060229BE mov #0,r1
    st8(c.r[2], c.r[1]);  // 060229C0 mov.b r1,@r2
    c.r[5] = c.r[11];  // 060229C2 mov r11,r5
    c.r[0] = ld32(0x06022AB0u);  // 060229C4 mov.l 0x06022AB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060229CAu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060229CAu) return; }  // 060229C6 jsr @r0 ; mov r13,r4
    c.r[1] = c.r[0];  // 060229CA mov r0,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060229CC extu.w r1,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06022AA8u);  // 060229CE mov.w 0x06022AA8,r9
    c.r[1] = ld32(0x06022AB4u);  // 060229D0 mov.l 0x06022AB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060229D6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060229D6u) return; }  // 060229D2 jsr @r1 ; mov r8,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060229D6 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 060229D8 mov.l r4,@r14
    c.r[0] = c.r[8] & 0xFFu;  // 060229DA extu.b r8,r0
    c.r[2] = c.r[8] & 0xFFFFu;  // 060229DC extu.w r8,r2
    c.r[1] = ld32(0x06022AB8u);  // 060229DE mov.l 0x06022AB8,r1
    c.t = c.r[2] == c.r[1];  // 060229E0 cmp/eq r1,r2
    { const bool k = c.t; st32(c.r[14] + 4, c.r[0]); if (k) { goto L_06022A74; } }  // 060229E2 bt/s 0x06022A74 ; mov.l r0,@(4,r14)
    c.r[2] = ld32(0x06022ABCu);  // 060229E6 mov.l 0x06022ABC,r2
    c.r[3] = c.r[2];  // 060229E8 mov r2,r3
    c.r[3] += 116;  // 060229EA add #116,r3
    c.r[1] = c.r[2];  // 060229EC mov r2,r1
    c.r[1] += 78;  // 060229EE add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060229F0 mov.b @r1,r1
    c.r[0] = c.r[4];  // 060229F2 mov r4,r0
    c.r[0] -= c.r[1];  // 060229F4 sub r1,r0
    c.r[1] = c.r[0];  // 060229F6 mov r0,r1
    st8(c.r[3], c.r[1]);  // 060229F8 mov.b r1,@r3
    c.r[3] = c.r[2];  // 060229FA mov r2,r3
    c.r[2] += 79;  // 060229FC add #79,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060229FE mov.b @r2,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06022A00 mov.l @(4,r14),r0
    c.r[3] += 117;  // 06022A02 add #117,r3
    c.r[0] -= c.r[1];  // 06022A04 sub r1,r0
    c.r[1] = c.r[0];  // 06022A06 mov r0,r1
    st8(c.r[3], c.r[1]);  // 06022A08 mov.b r1,@r3
    c.r[1] = ld32(0x06022AC0u);  // 06022A0A mov.l 0x06022AC0,r1
    c.r[2] = ld32(c.r[1]);  // 06022A0C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06022AAAu);  // 06022A0E mov.w 0x06022AAA,r1
    c.r[0] = c.r[2];  // 06022A10 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022A12 mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 06022A14 mov #0,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06022A16 extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06022A18 cmp/ge r1,r7
    { const bool k = c.t; c.r[4] = c.r[2]; if (k) { goto L_06022A72; } }  // 06022A1A bt/s 0x06022A72 ; mov r2,r4
    c.r[1] = ld32(0x06022AC4u);  // 06022A1E mov.l 0x06022AC4,r1
    c.r[8] = ld32(c.r[1]);  // 06022A20 mov.l @r1,r8
    c.r[5] = c.r[4];  // 06022A22 mov r4,r5
    c.r[6] = 0x0u;  // 06022A24 mov #0,r6
L_06022A26:
    c.r[1] = c.r[5];  // 06022A26 mov r5,r1
    c.r[1] += 1;  // 06022A28 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022A2A mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06022A2C extu.b r1,r9
    c.r[2] = c.r[9];  // 06022A2E mov r9,r2
    c.r[2] <<= 2;  // 06022A30 shll2 r2
    c.r[2] += c.r[9];  // 06022A32 add r9,r2
    c.r[2] <<= 2;  // 06022A34 shll2 r2
    c.r[2] += c.r[8];  // 06022A36 add r8,r2
    c.r[1] = c.r[2];  // 06022A38 mov r2,r1
    c.r[1] += 50;  // 06022A3A add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022A3C mov.b @r1,r1
    c.r[2] += 51;  // 06022A3E add #51,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06022A40 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06022A42 mov.b @r2,r1
    c.r[3] >>= 2;  // 06022A44 shlr2 r3
    c.r[3] >>= 2;  // 06022A46 shlr2 r3
    c.r[3] >>= 2;  // 06022A48 shlr2 r3
    c.r[0] = c.r[1];  // 06022A4A mov r1,r0
    c.r[0] >>= 2;  // 06022A4C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06022A4E shlr r0
    c.r[0] &= 0x1u;  // 06022A50 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06022A52 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06022A5E; } }  // 06022A54 bf/s 0x06022A5E ; mov r3,r0
    c.t = c.r[0] == 0x2u;  // 06022A58 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_06022972; } }  // 06022A5A bt/s 0x06022972 ; mov r9,r1
L_06022A5E:
    c.r[5] += 2;  // 06022A5E add #2,r5
    c.r[1] = ld32(0x06022AC0u);  // 06022A60 mov.l 0x06022AC0,r1
    c.r[1] = ld32(c.r[1]);  // 06022A62 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022AAAu);  // 06022A64 mov.w 0x06022AAA,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022A66 mov.b @(r0,r1),r1
    c.r[7] += 1;  // 06022A68 add #1,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06022A6A extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06022A6C cmp/ge r1,r7
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_06022A26; } }  // 06022A6E bf/s 0x06022A26 ; add #2,r6
L_06022A72:
    c.r[12] = 0xAu;  // 06022A72 mov #10,r12
L_06022A74:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06022AA8u);  // 06022A74 mov.w 0x06022AA8,r1
    c.t = c.r[9] == c.r[1];  // 06022A76 cmp/eq r1,r9
    if (c.t) { goto L_06022A88; }  // 06022A78 bt 0x06022A88
    c.r[1] = ld32(0x06022AC8u);  // 06022A7A mov.l 0x06022AC8,r1
    st8(c.r[1], c.r[13]);  // 06022A7C mov.b r13,@r1
    c.r[1] = ld32(0x06022ACCu);  // 06022A7E mov.l 0x06022ACC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06022A84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022A84u) return; }  // 06022A80 jsr @r1 ; nop
    goto L_06022ADA;  // 06022A84 bra 0x06022ADA ; nop
L_06022A88:
    c.r[1] = ld32(0x06022AD0u);  // 06022A88 mov.l 0x06022AD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06022A8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022A8Eu) return; }  // 06022A8A jsr @r1 ; nop
    goto L_06022ADA;  // 06022A8E bra 0x06022ADA ; nop
L_06022A92:
    c.r[10] = 0x2u; goto L_06022ADA;  // 06022A92 bra 0x06022ADA ; mov #2,r10
L_06022A96:
    c.r[10] = 0x0u; goto L_06022ADA;  // 06022A96 bra 0x06022ADA ; mov #0,r10
L_06022A9A:
    c.r[10] = 0x1u; goto L_06022ADA;  // 06022A9A bra 0x06022ADA ; mov #1,r10
L_06022A9E:
    c.r[0] = ld32(0x06022AD4u);  // 06022A9E mov.l 0x06022AD4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022AA4u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022AA4u) return; }  // 06022AA0 jsr @r0 ; mov r13,r4
    c.r[0] = c.r[0] & 0xFFu; goto L_06022B32;  // 06022AA4 bra 0x06022B32 ; extu.b r0,r0
L_06022AD8:
    c.r[10] = 0x11u;  // 06022AD8 mov #17,r10
L_06022ADA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06022B48u);  // 06022ADA mov.w 0x06022B48,r1
    c.t = c.r[10] == c.r[1];  // 06022ADC cmp/eq r1,r10
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06022B22; } }  // 06022ADE bt/s 0x06022B22 ; mov #1,r1
    c.r[8] = 0x0u;  // 06022AE2 mov #0,r8
    c.r[1] = c.r[8] & 0xFFu;  // 06022AE4 extu.b r8,r1
L_06022AE6:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06022AE6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06022AE8 mov.l r10,@-r15
    c.r[6] = ld32(c.r[14] + 8);  // 06022AEA mov.l @(8,r14),r6
    c.r[5] = ld32(c.r[14] + 4);  // 06022AEC mov.l @(4,r14),r5
    c.r[7] = c.r[11];  // 06022AEE mov r11,r7
    c.r[0] = ld32(0x06022B4Cu);  // 06022AF0 mov.l 0x06022B4C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022AF6u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022AF6u) return; }  // 06022AF2 jsr @r0 ; mov.l @r14,r4
    c.r[1] = c.r[0];  // 06022AF6 mov r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06022AF8 extu.b r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 06022AFA tst r5,r5
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_06022B16; } }  // 06022AFC bt/s 0x06022B16 ; add #8,r15
    c.r[5] = c.r[5] & 0xFFu;  // 06022B00 extu.b r5,r5
    c.r[6] = c.r[9];  // 06022B02 mov r9,r6
    c.r[0] = ld32(0x06022B50u);  // 06022B04 mov.l 0x06022B50,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022B0Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022B0Au) return; }  // 06022B06 jsr @r0 ; mov r13,r4
    c.r[2] = c.r[0];  // 06022B0A mov r0,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[12];  // 06022B0C cmp/gt r12,r2
    if (!c.t) { goto L_06022B16; }  // 06022B0E bf 0x06022B16
    c.r[12] = c.r[2];  // 06022B10 mov r2,r12
    c.r[1] = ld32(0x06022B54u);  // 06022B12 mov.l 0x06022B54,r1
    st8(c.r[1], c.r[8]);  // 06022B14 mov.b r8,@r1
L_06022B16:
    c.r[8] += 1;  // 06022B16 add #1,r8
    c.r[1] = 0x3u;  // 06022B18 mov #3,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06022B1A cmp/gt r1,r8
    { const bool k = !c.t; c.r[1] = c.r[8] & 0xFFu; if (k) { SH2_POLL(c); goto L_06022AE6; } }  // 06022B1C bf/s 0x06022AE6 ; extu.b r8,r1
    c.r[1] = 0x1u;  // 06022B20 mov #1,r1
L_06022B22:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06022B22 cmp/gt r1,r12
    if (c.t) { goto L_06022B2C; }  // 06022B24 bt 0x06022B2C
L_06022B26:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022B48u);  // 06022B26 mov.w 0x06022B48,r0
    c.r[14] += 12; goto L_06022B34;  // 06022B28 bra 0x06022B34 ; add #12,r14
L_06022B2C:
    c.r[1] = ld32(0x06022B54u);  // 06022B2C mov.l 0x06022B54,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022B2E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06022B30 extu.b r1,r0
L_06022B32:
    c.r[14] += 12;  // 06022B32 add #12,r14
L_06022B34:
    c.r[15] = c.r[14];  // 06022B34 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06022B36 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06022B38 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06022B3A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06022B3C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06022B3E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06022B40 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06022B42 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06022B44 rts ; mov.l @r15+,r8
}

void f_06022B58(SH2Context& c) {
    ran[445] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06022B58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06022B5A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06022B5C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06022B5E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06022B60 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06022B62 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06022B64 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06022B66 sts.l pr,@-r15
    c.r[15] -= 28;  // 06022B68 add #-28,r15
    c.r[14] = c.r[15];  // 06022B6A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06022B6C extu.b r4,r4
    st32(c.r[14] + 8, c.r[4]);  // 06022B6E mov.l r4,@(8,r14)
    c.r[7] = c.r[14];  // 06022B70 mov r14,r7
    c.r[7] += 2;  // 06022B72 add #2,r7
    c.r[3] = c.r[14];  // 06022B74 mov r14,r3
    c.r[3] += 4;  // 06022B76 add #4,r3
    c.r[2] = c.r[14];  // 06022B78 mov r14,r2
    c.r[2] += 6;  // 06022B7A add #6,r2
    c.r[0] = 0x0u;  // 06022B7C mov #0,r0
    st32(c.r[14] + 12, c.r[0]);  // 06022B7E mov.l r0,@(12,r14)
    c.r[1] = 0x0u;  // 06022B80 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06022B82 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 06022B84 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 06022B86 mov.w r1,@r7
    st16(c.r[14], c.r[1]);  // 06022B88 mov.w r1,@r14
    c.r[7] = ld32(0x06022CE8u);  // 06022B8A mov.l 0x06022CE8,r7
    c.r[10] = 0x0u;  // 06022B8C mov #0,r10
    c.r[2] = ld32(c.r[14] + 8);  // 06022B8E mov.l @(8,r14),r2
    c.r[8] = 0x0u;  // 06022B90 mov #0,r8
    c.r[1] = ld32(c.r[7]);  // 06022B92 mov.l @r7,r1
    c.r[2] <<= 2;  // 06022B94 shll2 r2
    c.r[2] <<= 2;  // 06022B96 shll2 r2
    c.r[3] = c.r[2];  // 06022B98 mov r2,r3
    c.r[3] += c.r[1];  // 06022B9A add r1,r3
    c.r[0] = c.r[2];  // 06022B9C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022B9E mov.b @(r0,r1),r1
    c.r[3] += 1;  // 06022BA0 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06022BA2 extu.b r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 06022BA4 mov.l r1,@(16,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06022BA6 mov.b @r3,r1
    c.r[13] = c.r[2];  // 06022BA8 mov r2,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06022BAA extu.b r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 06022BAC mov.l r1,@(20,r14)
L_06022BAE:
    c.r[0] = ld32(c.r[14] + 8);  // 06022BAE mov.l @(8,r14),r0
    c.t = c.r[10] == c.r[0];  // 06022BB0 cmp/eq r0,r10
    { const bool k = !c.t; c.r[3] = c.r[8]; if (k) { goto L_06022BBA; } }  // 06022BB2 bf/s 0x06022BBA ; mov r8,r3
    goto L_06022D4E;  // 06022BB6 bra 0x06022D4E ; nop
L_06022BBA:
    c.r[0] = ld32(0x06022CE8u);  // 06022BBA mov.l 0x06022CE8,r0
    c.r[1] = ld32(c.r[0]);  // 06022BBC mov.l @r0,r1
    c.r[3] += c.r[1];  // 06022BBE add r1,r3
    c.r[0] = c.r[8];  // 06022BC0 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06022BC2 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06022CE6u);  // 06022BC4 mov.w 0x06022CE6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06022BC6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06022BC8 cmp/eq r2,r1
    if (!c.t) { goto L_06022BD0; }  // 06022BCA bf 0x06022BD0
    goto L_06022D4E;  // 06022BCC bra 0x06022D4E ; nop
L_06022BD0:
    c.r[2] = ld32(c.r[3] + 4);  // 06022BD0 mov.l @(4,r3),r2
    c.r[1] = ld32(0x06022CECu);  // 06022BD2 mov.l 0x06022CEC,r1
    c.r[2] &= c.r[1];  // 06022BD4 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06022BD6 tst r2,r2
    if (c.t) { goto L_06022BDE; }  // 06022BD8 bt 0x06022BDE
    goto L_06022D4E;  // 06022BDA bra 0x06022D4E ; nop
L_06022BDE:
    c.r[1] = ld32(0x06022CF0u);  // 06022BDE mov.l 0x06022CF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06022BE4u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022BE4u) return; }  // 06022BE0 jsr @r1 ; extu.b r10,r4
    c.r[0] = ld32(0x06022CE8u);  // 06022BE4 mov.l 0x06022CE8,r0
    c.r[3] = ld32(c.r[0]);  // 06022BE6 mov.l @r0,r3
    c.r[2] = c.r[8];  // 06022BE8 mov r8,r2
    c.r[0] = c.r[8];  // 06022BEA mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06022BEC mov.b @(r0,r3),r1
    c.r[2] += c.r[3];  // 06022BEE add r3,r2
    c.r[11] = c.r[1] & 0xFFu;  // 06022BF0 extu.b r1,r11
    c.r[1] = c.r[2];  // 06022BF2 mov r2,r1
    c.r[1] += 1;  // 06022BF4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022BF6 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06022BF8 extu.b r1,r9
    c.r[1] = ld32(c.r[14] + 16);  // 06022BFA mov.l @(16,r14),r1
    c.r[1] -= c.r[11];  // 06022BFC sub r11,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06022BFE cmp/pz r1
    if (c.t) { goto L_06022C04; }  // 06022C00 bt 0x06022C04
    c.r[1] = 0u - c.r[1];  // 06022C02 neg r1,r1
L_06022C04:
    c.r[12] = c.r[1] & 0xFFu;  // 06022C04 extu.b r1,r12
    c.r[1] = ld32(c.r[14] + 20);  // 06022C06 mov.l @(20,r14),r1
    c.r[1] -= c.r[9];  // 06022C08 sub r9,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06022C0A cmp/pz r1
    if (c.t) { goto L_06022C10; }  // 06022C0C bt 0x06022C10
    c.r[1] = 0u - c.r[1];  // 06022C0E neg r1,r1
L_06022C10:
    c.r[1] = c.r[1] & 0xFFu;  // 06022C10 extu.b r1,r1
    st32(c.r[14] + 24, c.r[1]);  // 06022C12 mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06022C14 mov.l @(20,r14),r1
    c.r[1] -= c.r[12];  // 06022C16 sub r12,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[9];  // 06022C18 cmp/ge r9,r1
    { const bool k = !c.t; c.r[3] += c.r[13]; if (k) { goto L_06022C50; } }  // 06022C1A bf/s 0x06022C50 ; add r13,r3
    c.r[3] += 4;  // 06022C1E add #4,r3
    c.r[0] = 0xFu;  // 06022C20 mov #15,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06022C22 mov.b @r3,r1
    c.r[2] += 3;  // 06022C24 add #3,r2
    c.r[3] = c.r[1];  // 06022C26 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06022C28 shlr r3
    c.r[3] &= c.r[0];  // 06022C2A and r0,r3
    c.r[0] = 0x3u;  // 06022C2C mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06022C2E mov.b @r2,r1
    c.r[4] = c.r[3];  // 06022C30 mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06022C32 shlr r1
    c.r[1] &= c.r[0];  // 06022C34 and r0,r1
    c.r[0] = ld32(0x06022CF4u);  // 06022C36 mov.l 0x06022CF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022C3Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022C3Cu) return; }  // 06022C38 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06022C3C mov r0,r1
    c.r[0] = 0x1u;  // 06022C3E mov #1,r0
    c.r[1] &= c.r[0];  // 06022C40 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06022C42 tst r1,r1
    { const bool k = c.t; c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]); if (k) { goto L_06022C4C; } }  // 06022C44 bt/s 0x06022C4C ; mov.w @r14,r1
    c.r[1] += 1; goto L_06022C4E;  // 06022C48 bra 0x06022C4E ; add #1,r1
L_06022C4C:
    c.r[1] -= 2;  // 06022C4C add #-2,r1
L_06022C4E:
    st16(c.r[14], c.r[1]);  // 06022C4E mov.w r1,@r14
L_06022C50:
    c.r[1] = ld32(c.r[14] + 16);  // 06022C50 mov.l @(16,r14),r1
    c.r[0] = ld32(c.r[14] + 24);  // 06022C52 mov.l @(24,r14),r0
    c.r[1] += c.r[0];  // 06022C54 add r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 06022C56 cmp/gt r11,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 20); if (k) { goto L_06022CA2; } }  // 06022C58 bt/s 0x06022CA2 ; mov.l @(20,r14),r0
    c.r[0] = ld32(0x06022CE8u);  // 06022C5C mov.l 0x06022CE8,r0
    c.r[2] = ld32(c.r[0]);  // 06022C5E mov.l @r0,r2
    c.r[1] = c.r[13];  // 06022C60 mov r13,r1
    c.r[1] += c.r[2];  // 06022C62 add r2,r1
    c.r[1] += 4;  // 06022C64 add #4,r1
    c.r[0] = 0xFu;  // 06022C66 mov #15,r0
    c.r[2] += c.r[8];  // 06022C68 add r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022C6A mov.b @r1,r1
    c.r[2] += 3;  // 06022C6C add #3,r2
    c.r[3] = c.r[1];  // 06022C6E mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06022C70 shlr r3
    c.r[3] &= c.r[0];  // 06022C72 and r0,r3
    c.r[0] = 0x3u;  // 06022C74 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06022C76 mov.b @r2,r1
    c.r[4] = c.r[3];  // 06022C78 mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06022C7A shlr r1
    c.r[1] &= c.r[0];  // 06022C7C and r0,r1
    c.r[0] = ld32(0x06022CF4u);  // 06022C7E mov.l 0x06022CF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022C84u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022C84u) return; }  // 06022C80 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06022C84 mov r0,r1
    c.r[0] = 0x1u;  // 06022C86 mov #1,r0
    c.r[1] &= c.r[0];  // 06022C88 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06022C8A tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_06022C98; } }  // 06022C8C bt/s 0x06022C98 ; mov r14,r2
    c.r[2] += 2;  // 06022C90 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06022C92 mov.w @r2,r1
    c.r[1] += 1; goto L_06022C9E;  // 06022C94 bra 0x06022C9E ; add #1,r1
L_06022C98:
    c.r[2] += 2;  // 06022C98 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06022C9A mov.w @r2,r1
    c.r[1] -= 2;  // 06022C9C add #-2,r1
L_06022C9E:
    st16(c.r[2], c.r[1]);  // 06022C9E mov.w r1,@r2
    c.r[0] = ld32(c.r[14] + 20);  // 06022CA0 mov.l @(20,r14),r0
L_06022CA2:
    c.r[12] += c.r[0];  // 06022CA2 add r0,r12
    c.t = (int32_t)c.r[12] > (int32_t)c.r[9];  // 06022CA4 cmp/gt r9,r12
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 16); if (k) { goto L_06022D02; } }  // 06022CA6 bt/s 0x06022D02 ; mov.l @(16,r14),r1
    c.r[0] = ld32(0x06022CE8u);  // 06022CAA mov.l 0x06022CE8,r0
    c.r[2] = ld32(c.r[0]);  // 06022CAC mov.l @r0,r2
    c.r[1] = c.r[13];  // 06022CAE mov r13,r1
    c.r[1] += c.r[2];  // 06022CB0 add r2,r1
    c.r[1] += 4;  // 06022CB2 add #4,r1
    c.r[0] = 0xFu;  // 06022CB4 mov #15,r0
    c.r[2] += c.r[8];  // 06022CB6 add r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022CB8 mov.b @r1,r1
    c.r[2] += 3;  // 06022CBA add #3,r2
    c.r[3] = c.r[1];  // 06022CBC mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06022CBE shlr r3
    c.r[3] &= c.r[0];  // 06022CC0 and r0,r3
    c.r[0] = 0x3u;  // 06022CC2 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06022CC4 mov.b @r2,r1
    c.r[4] = c.r[3];  // 06022CC6 mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06022CC8 shlr r1
    c.r[1] &= c.r[0];  // 06022CCA and r0,r1
    c.r[0] = ld32(0x06022CF4u);  // 06022CCC mov.l 0x06022CF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022CD2u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022CD2u) return; }  // 06022CCE jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06022CD2 mov r0,r1
    c.r[0] = 0x1u;  // 06022CD4 mov #1,r0
    c.r[1] &= c.r[0];  // 06022CD6 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06022CD8 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_06022CF8; } }  // 06022CDA bt/s 0x06022CF8 ; mov r14,r2
    c.r[2] += 4;  // 06022CDE add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06022CE0 mov.w @r2,r1
    c.r[1] += 1; goto L_06022CFE;  // 06022CE2 bra 0x06022CFE ; add #1,r1
L_06022CF8:
    c.r[2] += 4;  // 06022CF8 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06022CFA mov.w @r2,r1
    c.r[1] -= 2;  // 06022CFC add #-2,r1
L_06022CFE:
    st16(c.r[2], c.r[1]);  // 06022CFE mov.w r1,@r2
    c.r[1] = ld32(c.r[14] + 16);  // 06022D00 mov.l @(16,r14),r1
L_06022D02:
    c.r[0] = ld32(c.r[14] + 24);  // 06022D02 mov.l @(24,r14),r0
    c.r[1] -= c.r[0];  // 06022D04 sub r0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[11];  // 06022D06 cmp/ge r11,r1
    { const bool k = !c.t; c.r[1] = c.r[13]; if (k) { goto L_06022D4E; } }  // 06022D08 bf/s 0x06022D4E ; mov r13,r1
    c.r[0] = ld32(0x06022DA0u);  // 06022D0C mov.l 0x06022DA0,r0
    c.r[2] = ld32(c.r[0]);  // 06022D0E mov.l @r0,r2
    c.r[1] += c.r[2];  // 06022D10 add r2,r1
    c.r[1] += 4;  // 06022D12 add #4,r1
    c.r[0] = 0xFu;  // 06022D14 mov #15,r0
    c.r[2] += c.r[8];  // 06022D16 add r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022D18 mov.b @r1,r1
    c.r[2] += 3;  // 06022D1A add #3,r2
    c.r[3] = c.r[1];  // 06022D1C mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06022D1E shlr r3
    c.r[3] &= c.r[0];  // 06022D20 and r0,r3
    c.r[0] = 0x3u;  // 06022D22 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06022D24 mov.b @r2,r1
    c.r[4] = c.r[3];  // 06022D26 mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06022D28 shlr r1
    c.r[1] &= c.r[0];  // 06022D2A and r0,r1
    c.r[0] = ld32(0x06022DA4u);  // 06022D2C mov.l 0x06022DA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06022D32u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022D32u) return; }  // 06022D2E jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06022D32 mov r0,r1
    c.r[0] = 0x1u;  // 06022D34 mov #1,r0
    c.r[1] &= c.r[0];  // 06022D36 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06022D38 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_06022D46; } }  // 06022D3A bt/s 0x06022D46 ; mov r14,r2
    c.r[2] += 6;  // 06022D3E add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06022D40 mov.w @r2,r1
    c.r[1] += 1; goto L_06022D4C;  // 06022D42 bra 0x06022D4C ; add #1,r1
L_06022D46:
    c.r[2] += 6;  // 06022D46 add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06022D48 mov.w @r2,r1
    c.r[1] -= 2;  // 06022D4A add #-2,r1
L_06022D4C:
    st16(c.r[2], c.r[1]);  // 06022D4C mov.w r1,@r2
L_06022D4E:
    c.r[10] += 1;  // 06022D4E add #1,r10
    c.r[1] = 0x49u;  // 06022D50 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06022D52 cmp/gt r1,r10
    { const bool k = c.t; c.r[8] += 16; if (k) { goto L_06022D5C; } }  // 06022D54 bt/s 0x06022D5C ; add #16,r8
    SH2_POLL(c); goto L_06022BAE;  // 06022D58 bra 0x06022BAE ; nop
L_06022D5C:
    c.r[2] = 0x0u;  // 06022D5C mov #0,r2
    c.r[3] = 0x3u;  // 06022D5E mov #3,r3
    c.r[7] = 0x0u;  // 06022D60 mov #0,r7
L_06022D62:
    c.r[0] = c.r[7];  // 06022D62 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06022D64 mov.w @(r0,r14),r1
    c.r[0] = ld32(c.r[14] + 12);  // 06022D66 mov.l @(12,r14),r0
    c.t = (int32_t)c.r[1] > (int32_t)c.r[0];  // 06022D68 cmp/gt r0,r1
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06022D74; } }  // 06022D6A bf/s 0x06022D74 ; mov r7,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06022D6E mov.w @(r0,r14),r0
    c.r[10] = c.r[2];  // 06022D70 mov r2,r10
    st32(c.r[14] + 12, c.r[0]);  // 06022D72 mov.l r0,@(12,r14)
L_06022D74:
    c.r[2] += 1;  // 06022D74 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06022D76 cmp/gt r3,r2
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06022D62; } }  // 06022D78 bf/s 0x06022D62 ; add #2,r7
    c.r[0] = ld32(c.r[14] + 12);  // 06022D7C mov.l @(12,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06022D7E tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[10] & 0xFFFFu; if (k) { goto L_06022D86; } }  // 06022D80 bf/s 0x06022D86 ; extu.w r10,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06022D9Cu);  // 06022D84 mov.w 0x06022D9C,r0
L_06022D86:
    c.r[14] += 28;  // 06022D86 add #28,r14
    c.r[15] = c.r[14];  // 06022D88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06022D8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06022D8C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06022D8E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06022D90 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06022D92 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06022D94 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06022D96 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06022D98 rts ; mov.l @r15+,r8
}

void f_06022DA8(SH2Context& c) {
    ran[446] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06022DA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06022DAA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06022DAC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06022DAE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06022DB0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06022DB2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06022DB4 mov.l r14,@-r15
    c.r[15] -= 12;  // 06022DB6 add #-12,r15
    c.r[14] = c.r[15];  // 06022DB8 mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06022DBA extu.b r4,r9
    c.r[5] = c.r[5] & 0xFFu;  // 06022DBC extu.b r5,r5
    st32(c.r[14] + 8, c.r[5]);  // 06022DBE mov.l r5,@(8,r14)
    c.r[6] = c.r[6] & 0xFFu;  // 06022DC0 extu.b r6,r6
    st32(c.r[14], c.r[6]);  // 06022DC2 mov.l r6,@r14
    c.r[7] = c.r[7] & 0xFFu;  // 06022DC4 extu.b r7,r7
    st32(c.r[14] + 4, c.r[7]);  // 06022DC6 mov.l r7,@(4,r14)
    c.r[13] = ld32(0x06022F9Cu);  // 06022DC8 mov.l 0x06022F9C,r13
    c.r[1] = ld32(c.r[14] + 40);  // 06022DCA mov.l @(40,r14),r1
    c.r[2] = ld32(c.r[14] + 44);  // 06022DCC mov.l @(44,r14),r2
    c.r[3] = c.r[1] & 0xFFu;  // 06022DCE extu.b r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06022DD0 extu.b r2,r2
    c.r[1] = 0x3u;  // 06022DD2 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 06022DD4 cmp/hi r1,r2
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_06022DDE; } }  // 06022DD6 bf/s 0x06022DDE ; mov #0,r10
    goto L_06023416;  // 06022DDA bra 0x06023416 ; nop
L_06022DDE:
    c.r[1] = c.r[2];  // 06022DDE mov r2,r1
    c.r[1] += c.r[1];  // 06022DE0 add r1,r1
    c.r[0] = 0x06022DECu;  // 06022DE2 mova 0x06022DEC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06022DE4 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06022DE6 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06022DF4u: goto L_06022DF4; case 0x06022F70u: goto L_06022F70; case 0x060230F2u: goto L_060230F2; case 0x0602327Eu: goto L_0602327E; default: sh2_call(c, x); return; } }  // 06022DE8 jmp @r0 ; nop
L_06022DF4:
    c.r[0] = c.r[3];  // 06022DF4 mov r3,r0
    c.t = c.r[0] == 0x11u;  // 06022DF6 cmp/eq #17,r0
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_06022EEC; } }  // 06022DF8 bf/s 0x06022EEC ; tst r9,r9
    if (c.t) { goto L_06022E04; }  // 06022DFC bt 0x06022E04
    c.r[1] = c.r[9];  // 06022DFE mov r9,r1
    c.r[1] -= 1; goto L_06022E06;  // 06022E00 bra 0x06022E06 ; add #-1,r1
L_06022E04:
    c.r[1] = 0x0u;  // 06022E04 mov #0,r1
L_06022E06:
    c.r[2] = ld32(c.r[14] + 8);  // 06022E06 mov.l @(8,r14),r2
    c.r[12] = ld32(c.r[14] + 4);  // 06022E08 mov.l @(4,r14),r12
    c.r[11] = c.r[1] & 0xFFu;  // 06022E0A extu.b r1,r11
    c.r[2] -= c.r[12];  // 06022E0C sub r12,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06022E0E exts.b r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06022E10 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06022E18; } }  // 06022E12 bf/s 0x06022E18 ; mov #0,r1
    c.r[1] = c.r[2] & 0xFFu;  // 06022E16 extu.b r2,r1
L_06022E18:
    c.r[2] = ld32(c.r[14] + 8);  // 06022E18 mov.l @(8,r14),r2
    c.r[0] = ld32(c.r[14]);  // 06022E1A mov.l @r14,r0
    c.r[8] = c.r[1];  // 06022E1C mov r1,r8
    c.r[2] -= c.r[0];  // 06022E1E sub r0,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06022E20 exts.b r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06022E22 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06022E2A; } }  // 06022E24 bf/s 0x06022E2A ; mov #0,r1
    c.r[1] = c.r[2] & 0xFFu;  // 06022E28 extu.b r2,r1
L_06022E2A:
    c.t = c.r[8] > c.r[1];  // 06022E2A cmp/hi r1,r8
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06022E34; } }  // 06022E2C bf/s 0x06022E34 ; mov #0,r7
    c.r[1] = 0x0u; goto L_06022E74;  // 06022E30 bra 0x06022E74 ; mov #0,r1
L_06022E34:
    c.r[1] -= c.r[8];  // 06022E34 sub r8,r1
    c.r[1] += 1;  // 06022E36 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06022E38 extu.b r1,r4
    c.r[6] = 0x0u;  // 06022E3A mov #0,r6
    c.r[10] = 0x49u;  // 06022E3C mov #73,r10
L_06022E3E:
    c.r[3] = 0x0u;  // 06022E3E mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06022E40 cmp/ge r4,r3
    if (c.t) { goto L_06022E6A; }  // 06022E42 bt 0x06022E6A
    c.r[5] = c.r[11];  // 06022E44 mov r11,r5
    c.r[5] += c.r[6];  // 06022E46 add r6,r5
L_06022E48:
    c.r[0] = c.r[7];  // 06022E48 mov r7,r0
    c.r[0] += c.r[0];  // 06022E4A add r0,r0
    c.r[2] = c.r[0];  // 06022E4C mov r0,r2
    c.r[2] += c.r[13];  // 06022E4E add r13,r2
    st8(c.r[0] + c.r[13], c.r[5]);  // 06022E50 mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 06022E52 add #1,r2
    c.r[1] = c.r[8];  // 06022E54 mov r8,r1
    c.r[1] += c.r[3];  // 06022E56 add r3,r1
    c.t = c.r[7] > c.r[10];  // 06022E58 cmp/hi r10,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06022E6A; } }  // 06022E5A bt/s 0x06022E6A ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06022E5E mov r7,r1
    c.r[1] += 1;  // 06022E60 add #1,r1
    c.r[3] += 1;  // 06022E62 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06022E64 cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06022E48; } }  // 06022E66 bf/s 0x06022E48 ; extu.b r1,r7
L_06022E6A:
    c.r[6] += 1;  // 06022E6A add #1,r6
    c.r[12] = 0x1u;  // 06022E6C mov #1,r12
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[12];  // 06022E6E cmp/ge r12,r6
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { SH2_POLL(c); goto L_06022E3E; } }  // 06022E70 bf/s 0x06022E3E ; mov r7,r1
L_06022E74:
    c.r[10] = c.r[1] & 0xFFu;  // 06022E74 extu.b r1,r10
    c.r[1] = ld32(c.r[14] + 8);  // 06022E76 mov.l @(8,r14),r1
    c.r[9] += 1;  // 06022E78 add #1,r9
    c.r[0] = ld32(c.r[14] + 4);  // 06022E7A mov.l @(4,r14),r0
    c.r[11] = c.r[9] & 0xFFu;  // 06022E7C extu.b r9,r11
    c.r[1] -= c.r[0];  // 06022E7E sub r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06022E80 exts.b r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06022E82 cmp/pz r1
    c.r[2] = ld32(c.r[14] + 8);  // 06022E84 mov.l @(8,r14),r2
    c.r[12] = ld32(c.r[14]);  // 06022E86 mov.l @r14,r12
    c.r[2] -= c.r[12];  // 06022E88 sub r12,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06022E8A exts.b r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06022E8C cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06022E94; } }  // 06022E8E bf/s 0x06022E94 ; mov #0,r1
    c.r[1] = c.r[2] & 0xFFu;  // 06022E92 extu.b r2,r1
L_06022E94:
    c.r[9] = c.r[10];  // 06022E94 mov r10,r9
    c.r[9] += c.r[9];  // 06022E96 add r9,r9
    c.r[9] += c.r[13];  // 06022E98 add r13,r9
    c.t = c.r[8] > c.r[1];  // 06022E9A cmp/hi r1,r8
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06022EA4; } }  // 06022E9C bf/s 0x06022EA4 ; mov #0,r7
L_06022EA0:
    c.r[1] = 0x0u; goto L_06022EE8;  // 06022EA0 bra 0x06022EE8 ; mov #0,r1
L_06022EA4:
    c.r[13] = 0x1u;  // 06022EA4 mov #1,r13
    c.r[1] -= c.r[8];  // 06022EA6 sub r8,r1
    c.r[1] += 1;  // 06022EA8 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06022EAA extu.b r1,r4
    c.r[6] = 0x0u;  // 06022EAC mov #0,r6
    c.r[3] = 0x0u;  // 06022EAE mov #0,r3
L_06022EB0:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06022EB0 cmp/ge r4,r3
    if (c.t) { goto L_06022EDE; }  // 06022EB2 bt 0x06022EDE
    c.r[5] = c.r[11];  // 06022EB4 mov r11,r5
    c.r[5] += c.r[6];  // 06022EB6 add r6,r5
L_06022EB8:
    c.r[1] = c.r[7];  // 06022EB8 mov r7,r1
    c.r[1] += c.r[1];  // 06022EBA add r1,r1
    c.r[2] = c.r[1];  // 06022EBC mov r1,r2
    c.r[2] += c.r[9];  // 06022EBE add r9,r2
    c.r[0] = c.r[1];  // 06022EC0 mov r1,r0
    st8(c.r[0] + c.r[9], c.r[5]);  // 06022EC2 mov.b r5,@(r0,r9)
    c.r[2] += 1;  // 06022EC4 add #1,r2
    c.r[1] = c.r[8];  // 06022EC6 mov r8,r1
    c.r[1] += c.r[3];  // 06022EC8 add r3,r1
    c.r[12] = 0x49u;  // 06022ECA mov #73,r12
    c.t = c.r[7] > c.r[12];  // 06022ECC cmp/hi r12,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06022EDE; } }  // 06022ECE bt/s 0x06022EDE ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06022ED2 mov r7,r1
    c.r[1] += 1;  // 06022ED4 add #1,r1
    c.r[3] += 1;  // 06022ED6 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06022ED8 cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06022EB8; } }  // 06022EDA bf/s 0x06022EB8 ; extu.b r1,r7
L_06022EDE:
    c.r[6] += 1;  // 06022EDE add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[13];  // 06022EE0 cmp/ge r13,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_06022EB0; } }  // 06022EE2 bf/s 0x06022EB0 ; mov #0,r3
L_06022EE6:
    c.r[1] = c.r[7];  // 06022EE6 mov r7,r1
L_06022EE8:
    c.r[1] += c.r[10]; goto L_06023414;  // 06022EE8 bra 0x06023414 ; add r10,r1
L_06022EEC:
    c.r[1] = c.r[9];  // 06022EEC mov r9,r1
    c.r[1] -= c.r[3];  // 06022EEE sub r3,r1
    c.r[9] += c.r[3];  // 06022EF0 add r3,r9
    c.r[4] = c.r[9] & 0xFFu;  // 06022EF2 extu.b r9,r4
    c.r[2] = ld32(c.r[14] + 8);  // 06022EF4 mov.l @(8,r14),r2
    c.r[10] = c.r[1] & 0xFFu;  // 06022EF6 extu.b r1,r10
    c.r[0] = ld32(c.r[14] + 4);  // 06022EF8 mov.l @(4,r14),r0
    c.r[7] = 0x0u;  // 06022EFA mov #0,r7
    c.r[12] = ld32(c.r[14] + 8);  // 06022EFC mov.l @(8,r14),r12
    c.r[2] -= c.r[0];  // 06022EFE sub r0,r2
    c.r[0] = ld32(c.r[14]);  // 06022F00 mov.l @r14,r0
    c.t = c.r[10] > c.r[4];  // 06022F02 cmp/hi r4,r10
    c.r[12] -= c.r[0];  // 06022F04 sub r0,r12
    st32(c.r[14] + 8, c.r[12]);  // 06022F06 mov.l r12,@(8,r14)
    c.r[12] = 0xBu;  // 06022F08 mov #11,r12
    c.r[12] += c.r[14];  // 06022F0A add r14,r12
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06022F0C mov.b @r12,r12
    c.r[9] = c.r[2] & 0xFFu;  // 06022F0E extu.b r2,r9
    { const bool k = !c.t; c.r[5] = c.r[12] & 0xFFu; if (k) { goto L_06022F18; } }  // 06022F10 bf/s 0x06022F18 ; extu.b r12,r5
    goto L_060233C8;  // 06022F14 bra 0x060233C8 ; nop
L_06022F18:
    c.t = c.r[9] > c.r[5];  // 06022F18 cmp/hi r5,r9
    { const bool k = !c.t; c.r[4] -= c.r[10]; if (k) { goto L_06022F22; } }  // 06022F1A bf/s 0x06022F22 ; sub r10,r4
    goto L_060233C8;  // 06022F1E bra 0x060233C8 ; nop
L_06022F22:
    c.r[4] += 1;  // 06022F22 add #1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06022F24 extu.b r4,r4
    c.r[5] -= c.r[9];  // 06022F26 sub r9,r5
    c.r[5] += 1;  // 06022F28 add #1,r5
    c.r[8] = c.r[5] & 0xFFu;  // 06022F2A extu.b r5,r8
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[4];  // 06022F2C cmp/ge r4,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_06022F36; } }  // 06022F2E bf/s 0x06022F36 ; mov #0,r6
    goto L_06023412;  // 06022F32 bra 0x06023412 ; nop
L_06022F36:
    c.r[11] = 0x49u;  // 06022F36 mov #73,r11
    c.r[3] = 0x0u;  // 06022F38 mov #0,r3
L_06022F3A:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 06022F3A cmp/ge r8,r3
    if (c.t) { goto L_06022F64; }  // 06022F3C bt 0x06022F64
    c.r[5] = c.r[10];  // 06022F3E mov r10,r5
    c.r[5] += c.r[6];  // 06022F40 add r6,r5
L_06022F42:
    c.r[0] = c.r[7];  // 06022F42 mov r7,r0
    c.r[0] += c.r[0];  // 06022F44 add r0,r0
    c.r[2] = c.r[0];  // 06022F46 mov r0,r2
    c.r[2] += c.r[13];  // 06022F48 add r13,r2
    st8(c.r[0] + c.r[13], c.r[5]);  // 06022F4A mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 06022F4C add #1,r2
    c.r[1] = c.r[9];  // 06022F4E mov r9,r1
    c.r[1] += c.r[3];  // 06022F50 add r3,r1
    c.t = c.r[7] > c.r[11];  // 06022F52 cmp/hi r11,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06022F64; } }  // 06022F54 bt/s 0x06022F64 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06022F58 mov r7,r1
    c.r[1] += 1;  // 06022F5A add #1,r1
    c.r[3] += 1;  // 06022F5C add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 06022F5E cmp/ge r8,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06022F42; } }  // 06022F60 bf/s 0x06022F42 ; extu.b r1,r7
L_06022F64:
    c.r[6] += 1;  // 06022F64 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 06022F66 cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_06022F3A; } }  // 06022F68 bf/s 0x06022F3A ; mov #0,r3
    c.r[1] = c.r[7]; goto L_06023414;  // 06022F6C bra 0x06023414 ; mov r7,r1
L_06022F70:
    c.r[0] = c.r[3];  // 06022F70 mov r3,r0
    c.t = c.r[0] == 0x11u;  // 06022F72 cmp/eq #17,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_06023068; } }  // 06022F74 bf/s 0x06023068 ; mov.l @r14,r1
    c.r[1] += c.r[9];  // 06022F78 add r9,r1
    c.r[12] = ld32(c.r[14] + 8);  // 06022F7A mov.l @(8,r14),r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06022F7C tst r12,r12
    { const bool k = c.t; c.r[11] = c.r[1] & 0xFFu; if (k) { goto L_06022F88; } }  // 06022F7E bt/s 0x06022F88 ; extu.b r1,r11
    c.r[1] = c.r[12];  // 06022F82 mov r12,r1
    c.r[1] -= 1; goto L_06022F8A;  // 06022F84 bra 0x06022F8A ; add #-1,r1
L_06022F88:
    c.r[1] = 0x0u;  // 06022F88 mov #0,r1
L_06022F8A:
    c.r[8] = c.r[1] & 0xFFu;  // 06022F8A extu.b r1,r8
    c.r[1] = ld32(c.r[14] + 4);  // 06022F8C mov.l @(4,r14),r1
    c.r[1] += c.r[9];  // 06022F8E add r9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06022F90 extu.b r1,r1
    c.t = c.r[11] > c.r[1];  // 06022F92 cmp/hi r1,r11
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06022FA0; } }  // 06022F94 bf/s 0x06022FA0 ; mov #0,r7
    c.r[1] = 0x0u; goto L_06022FE6;  // 06022F98 bra 0x06022FE6 ; mov #0,r1
L_06022FA0:
    c.r[1] -= c.r[11];  // 06022FA0 sub r11,r1
    c.r[1] += 1;  // 06022FA2 add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06022FA4 extu.b r1,r10
    c.r[6] = 0x0u;  // 06022FA6 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 06022FA8 cmp/ge r10,r6
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_06022FE4; } }  // 06022FAA bt/s 0x06022FE4 ; mov #1,r4
L_06022FAE:
    c.r[3] = 0x0u;  // 06022FAE mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06022FB0 cmp/ge r4,r3
    if (c.t) { goto L_06022FDE; }  // 06022FB2 bt 0x06022FDE
    c.r[5] = c.r[11];  // 06022FB4 mov r11,r5
    c.r[5] += c.r[6];  // 06022FB6 add r6,r5
L_06022FB8:
    c.r[1] = c.r[7];  // 06022FB8 mov r7,r1
    c.r[1] += c.r[1];  // 06022FBA add r1,r1
    c.r[2] = c.r[1];  // 06022FBC mov r1,r2
    c.r[2] += c.r[13];  // 06022FBE add r13,r2
    c.r[0] = c.r[1];  // 06022FC0 mov r1,r0
    st8(c.r[0] + c.r[13], c.r[5]);  // 06022FC2 mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 06022FC4 add #1,r2
    c.r[1] = c.r[8];  // 06022FC6 mov r8,r1
    c.r[1] += c.r[3];  // 06022FC8 add r3,r1
    c.r[12] = 0x49u;  // 06022FCA mov #73,r12
    c.t = c.r[7] > c.r[12];  // 06022FCC cmp/hi r12,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06022FDE; } }  // 06022FCE bt/s 0x06022FDE ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06022FD2 mov r7,r1
    c.r[1] += 1;  // 06022FD4 add #1,r1
    c.r[3] += 1;  // 06022FD6 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06022FD8 cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06022FB8; } }  // 06022FDA bf/s 0x06022FB8 ; extu.b r1,r7
L_06022FDE:
    c.r[6] += 1;  // 06022FDE add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 06022FE0 cmp/ge r10,r6
    if (!c.t) { SH2_POLL(c); goto L_06022FAE; }  // 06022FE2 bf 0x06022FAE
L_06022FE4:
    c.r[1] = c.r[7];  // 06022FE4 mov r7,r1
L_06022FE6:
    c.r[10] = c.r[1] & 0xFFu;  // 06022FE6 extu.b r1,r10
    c.r[8] = c.r[10];  // 06022FE8 mov r10,r8
    c.r[8] += c.r[8];  // 06022FEA add r8,r8
    c.r[8] += c.r[13];  // 06022FEC add r13,r8
    c.r[0] = ld32(c.r[14]);  // 06022FEE mov.l @r14,r0
    c.r[7] = 0x0u;  // 06022FF0 mov #0,r7
    c.r[12] = ld32(c.r[14] + 8);  // 06022FF2 mov.l @(8,r14),r12
    c.r[0] += c.r[9];  // 06022FF4 add r9,r0
    st32(c.r[14], c.r[0]);  // 06022FF6 mov.l r0,@r14
    c.r[12] += 1;  // 06022FF8 add #1,r12
    st32(c.r[14] + 8, c.r[12]);  // 06022FFA mov.l r12,@(8,r14)
    c.r[12] = 0x3u;  // 06022FFC mov #3,r12
    c.r[0] = ld32(c.r[14] + 4);  // 06022FFE mov.l @(4,r14),r0
    c.r[12] += c.r[14];  // 06023000 add r14,r12
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06023002 mov.b @r12,r12
    c.r[9] += c.r[0];  // 06023004 add r0,r9
    c.r[1] = c.r[9] & 0xFFu;  // 06023006 extu.b r9,r1
    c.r[9] = c.r[12] & 0xFFu;  // 06023008 extu.b r12,r9
    c.r[0] = 0xBu;  // 0602300A mov #11,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0602300C mov.b @(r0,r14),r0
    c.t = c.r[9] > c.r[1];  // 0602300E cmp/hi r1,r9
    { const bool k = !c.t; c.r[11] = c.r[0] & 0xFFu; if (k) { goto L_06023018; } }  // 06023010 bf/s 0x06023018 ; extu.b r0,r11
    SH2_POLL(c); goto L_06022EA0;  // 06023014 bra 0x06022EA0 ; nop
L_06023018:
    c.r[1] -= c.r[9];  // 06023018 sub r9,r1
    c.r[1] += 1;  // 0602301A add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0602301C extu.b r1,r4
    c.r[6] = 0x0u;  // 0602301E mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 06023020 cmp/ge r4,r6
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0602302A; } }  // 06023022 bf/s 0x0602302A ; mov r7,r1
    SH2_POLL(c); goto L_06022EE8;  // 06023026 bra 0x06022EE8 ; nop
L_0602302A:
    c.r[13] = 0x49u;  // 0602302A mov #73,r13
    c.r[3] = 0x0u;  // 0602302C mov #0,r3
L_0602302E:
    c.r[12] = 0x1u;  // 0602302E mov #1,r12
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[12];  // 06023030 cmp/ge r12,r3
    if (c.t) { goto L_0602305C; }  // 06023032 bt 0x0602305C
    c.r[5] = c.r[9];  // 06023034 mov r9,r5
    c.r[5] += c.r[6];  // 06023036 add r6,r5
L_06023038:
    c.r[0] = c.r[7];  // 06023038 mov r7,r0
    c.r[0] += c.r[0];  // 0602303A add r0,r0
    c.r[2] = c.r[0];  // 0602303C mov r0,r2
    c.r[2] += c.r[8];  // 0602303E add r8,r2
    st8(c.r[0] + c.r[8], c.r[5]);  // 06023040 mov.b r5,@(r0,r8)
    c.r[2] += 1;  // 06023042 add #1,r2
    c.r[1] = c.r[11];  // 06023044 mov r11,r1
    c.r[1] += c.r[3];  // 06023046 add r3,r1
    c.t = c.r[7] > c.r[13];  // 06023048 cmp/hi r13,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_0602305C; } }  // 0602304A bt/s 0x0602305C ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 0602304E mov r7,r1
    c.r[1] += 1;  // 06023050 add #1,r1
    c.r[3] += 1;  // 06023052 add #1,r3
    c.r[0] = 0x1u;  // 06023054 mov #1,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 06023056 cmp/ge r0,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06023038; } }  // 06023058 bf/s 0x06023038 ; extu.b r1,r7
L_0602305C:
    c.r[6] += 1;  // 0602305C add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0602305E cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_0602302E; } }  // 06023060 bf/s 0x0602302E ; mov #0,r3
    c.r[1] = c.r[7]; SH2_POLL(c); goto L_06022EE8;  // 06023064 bra 0x06022EE8 ; mov r7,r1
L_06023068:
    c.r[12] = ld32(c.r[14]);  // 06023068 mov.l @r14,r12
    c.r[1] = ld32(c.r[14] + 8);  // 0602306A mov.l @(8,r14),r1
    c.r[7] = 0x0u;  // 0602306C mov #0,r7
    c.r[0] = ld32(c.r[14] + 4);  // 0602306E mov.l @(4,r14),r0
    c.r[12] += c.r[9];  // 06023070 add r9,r12
    st32(c.r[14], c.r[12]);  // 06023072 mov.l r12,@r14
    c.r[1] -= c.r[3];  // 06023074 sub r3,r1
    c.r[9] += c.r[0];  // 06023076 add r0,r9
    c.r[4] = c.r[9] & 0xFFu;  // 06023078 extu.b r9,r4
    c.r[0] = 0xBu;  // 0602307A mov #11,r0
    c.r[0] += c.r[14];  // 0602307C add r14,r0
    c.r[12] = ld32(c.r[14] + 8);  // 0602307E mov.l @(8,r14),r12
    c.r[9] = c.r[1] & 0xFFu;  // 06023080 extu.b r1,r9
    c.r[12] += c.r[3];  // 06023082 add r3,r12
    st32(c.r[14] + 8, c.r[12]);  // 06023084 mov.l r12,@(8,r14)
    c.r[12] = 0x3u;  // 06023086 mov #3,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023088 mov.b @r0,r0
    c.r[12] += c.r[14];  // 0602308A add r14,r12
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602308C mov.b @r12,r12
    c.r[10] = c.r[12] & 0xFFu;  // 0602308E extu.b r12,r10
    c.t = c.r[10] > c.r[4];  // 06023090 cmp/hi r4,r10
    { const bool k = !c.t; c.r[2] = c.r[0] & 0xFFu; if (k) { goto L_0602309A; } }  // 06023092 bf/s 0x0602309A ; extu.b r0,r2
    goto L_060233C8;  // 06023096 bra 0x060233C8 ; nop
L_0602309A:
    c.t = c.r[9] > c.r[2];  // 0602309A cmp/hi r2,r9
    { const bool k = !c.t; c.r[4] -= c.r[10]; if (k) { goto L_060230A4; } }  // 0602309C bf/s 0x060230A4 ; sub r10,r4
    goto L_060233C8;  // 060230A0 bra 0x060233C8 ; nop
L_060230A4:
    c.r[4] += 1;  // 060230A4 add #1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060230A6 extu.b r4,r4
    c.r[2] -= c.r[9];  // 060230A8 sub r9,r2
    c.r[2] += 1;  // 060230AA add #1,r2
    c.r[8] = c.r[2] & 0xFFu;  // 060230AC extu.b r2,r8
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[4];  // 060230AE cmp/ge r4,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_060230B8; } }  // 060230B0 bf/s 0x060230B8 ; mov #0,r6
    goto L_06023412;  // 060230B4 bra 0x06023412 ; nop
L_060230B8:
    c.r[11] = 0x49u;  // 060230B8 mov #73,r11
    c.r[3] = 0x0u;  // 060230BA mov #0,r3
L_060230BC:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060230BC cmp/ge r8,r3
    if (c.t) { goto L_060230E6; }  // 060230BE bt 0x060230E6
    c.r[5] = c.r[10];  // 060230C0 mov r10,r5
    c.r[5] += c.r[6];  // 060230C2 add r6,r5
L_060230C4:
    c.r[0] = c.r[7];  // 060230C4 mov r7,r0
    c.r[0] += c.r[0];  // 060230C6 add r0,r0
    c.r[2] = c.r[0];  // 060230C8 mov r0,r2
    c.r[2] += c.r[13];  // 060230CA add r13,r2
    st8(c.r[0] + c.r[13], c.r[5]);  // 060230CC mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 060230CE add #1,r2
    c.r[1] = c.r[9];  // 060230D0 mov r9,r1
    c.r[1] += c.r[3];  // 060230D2 add r3,r1
    c.t = c.r[7] > c.r[11];  // 060230D4 cmp/hi r11,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_060230E6; } }  // 060230D6 bt/s 0x060230E6 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 060230DA mov r7,r1
    c.r[1] += 1;  // 060230DC add #1,r1
    c.r[3] += 1;  // 060230DE add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060230E0 cmp/ge r8,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_060230C4; } }  // 060230E2 bf/s 0x060230C4 ; extu.b r1,r7
L_060230E6:
    c.r[6] += 1;  // 060230E6 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 060230E8 cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_060230BC; } }  // 060230EA bf/s 0x060230BC ; mov #0,r3
    c.r[1] = c.r[7]; goto L_06023414;  // 060230EE bra 0x06023414 ; mov r7,r1
L_060230F2:
    c.r[0] = c.r[3];  // 060230F2 mov r3,r0
    c.t = c.r[0] == 0x11u;  // 060230F4 cmp/eq #17,r0
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060231F4; } }  // 060230F6 bf/s 0x060231F4 ; tst r9,r9
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06023102; } }  // 060230FA bt/s 0x06023102 ; mov r9,r1
    c.r[1] -= 1; goto L_06023104;  // 060230FE bra 0x06023104 ; add #-1,r1
L_06023102:
    c.r[1] = 0x0u;  // 06023102 mov #0,r1
L_06023104:
    c.r[11] = c.r[1] & 0xFFu;  // 06023104 extu.b r1,r11
    c.r[1] = ld32(c.r[14]);  // 06023106 mov.l @r14,r1
    c.r[12] = ld32(c.r[14] + 8);  // 06023108 mov.l @(8,r14),r12
    c.r[1] += c.r[12];  // 0602310A add r12,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0602310C extu.b r1,r8
    c.r[1] = ld32(c.r[14] + 4);  // 0602310E mov.l @(4,r14),r1
    c.r[1] += c.r[12];  // 06023110 add r12,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023112 extu.b r1,r1
    c.t = c.r[8] > c.r[1];  // 06023114 cmp/hi r1,r8
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_0602311E; } }  // 06023116 bf/s 0x0602311E ; mov #0,r7
    c.r[1] = 0x0u; goto L_0602315E;  // 0602311A bra 0x0602315E ; mov #0,r1
L_0602311E:
    c.r[1] -= c.r[8];  // 0602311E sub r8,r1
    c.r[1] += 1;  // 06023120 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06023122 extu.b r1,r4
    c.r[6] = 0x0u;  // 06023124 mov #0,r6
    c.r[10] = 0x49u;  // 06023126 mov #73,r10
L_06023128:
    c.r[3] = 0x0u;  // 06023128 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 0602312A cmp/ge r4,r3
    if (c.t) { goto L_06023154; }  // 0602312C bt 0x06023154
    c.r[5] = c.r[11];  // 0602312E mov r11,r5
    c.r[5] += c.r[6];  // 06023130 add r6,r5
L_06023132:
    c.r[0] = c.r[7];  // 06023132 mov r7,r0
    c.r[0] += c.r[0];  // 06023134 add r0,r0
    c.r[2] = c.r[0];  // 06023136 mov r0,r2
    c.r[2] += c.r[13];  // 06023138 add r13,r2
    st8(c.r[0] + c.r[13], c.r[5]);  // 0602313A mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 0602313C add #1,r2
    c.r[1] = c.r[8];  // 0602313E mov r8,r1
    c.r[1] += c.r[3];  // 06023140 add r3,r1
    c.t = c.r[7] > c.r[10];  // 06023142 cmp/hi r10,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06023154; } }  // 06023144 bt/s 0x06023154 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06023148 mov r7,r1
    c.r[1] += 1;  // 0602314A add #1,r1
    c.r[3] += 1;  // 0602314C add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 0602314E cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06023132; } }  // 06023150 bf/s 0x06023132 ; extu.b r1,r7
L_06023154:
    c.r[6] += 1;  // 06023154 add #1,r6
    c.r[0] = 0x1u;  // 06023156 mov #1,r0
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[0];  // 06023158 cmp/ge r0,r6
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { SH2_POLL(c); goto L_06023128; } }  // 0602315A bf/s 0x06023128 ; mov r7,r1
L_0602315E:
    c.r[10] = c.r[1] & 0xFFu;  // 0602315E extu.b r1,r10
    c.r[1] = c.r[9];  // 06023160 mov r9,r1
    c.r[1] += 1;  // 06023162 add #1,r1
    c.r[9] += 2;  // 06023164 add #2,r9
    c.r[4] = c.r[9] & 0xFFu;  // 06023166 extu.b r9,r4
    c.r[9] = c.r[10];  // 06023168 mov r10,r9
    c.r[9] += c.r[9];  // 0602316A add r9,r9
    c.r[12] = ld32(c.r[14]);  // 0602316C mov.l @r14,r12
    c.r[9] += c.r[13];  // 0602316E add r13,r9
    c.r[0] = ld32(c.r[14] + 8);  // 06023170 mov.l @(8,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06023172 extu.b r1,r1
    c.r[12] += c.r[0];  // 06023174 add r0,r12
    st32(c.r[14], c.r[12]);  // 06023176 mov.l r12,@r14
    c.r[12] = ld32(c.r[14] + 4);  // 06023178 mov.l @(4,r14),r12
    c.r[7] = 0x0u;  // 0602317A mov #0,r7
    c.r[0] += c.r[12];  // 0602317C add r12,r0
    st32(c.r[14] + 8, c.r[0]);  // 0602317E mov.l r0,@(8,r14)
    c.r[0] = 0xBu;  // 06023180 mov #11,r0
    c.r[0] += c.r[14];  // 06023182 add r14,r0
    c.r[12] = 0x3u;  // 06023184 mov #3,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023186 mov.b @r0,r0
    c.r[12] += c.r[14];  // 06023188 add r14,r12
    c.r[2] = c.r[0] & 0xFFu;  // 0602318A extu.b r0,r2
    st32(c.r[14] + 8, c.r[1]);  // 0602318C mov.l r1,@(8,r14)
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602318E mov.b @r12,r12
    c.t = c.r[1] > c.r[4];  // 06023190 cmp/hi r4,r1
    { const bool k = !c.t; c.r[11] = c.r[12] & 0xFFu; if (k) { goto L_0602319A; } }  // 06023192 bf/s 0x0602319A ; extu.b r12,r11
    SH2_POLL(c); goto L_06022EA0;  // 06023196 bra 0x06022EA0 ; nop
L_0602319A:
    c.t = c.r[11] > c.r[2];  // 0602319A cmp/hi r2,r11
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_060231A4; } }  // 0602319C bf/s 0x060231A4 ; mov.l @(8,r14),r0
    SH2_POLL(c); goto L_06022EA0;  // 060231A0 bra 0x06022EA0 ; nop
L_060231A4:
    c.r[2] -= c.r[11];  // 060231A4 sub r11,r2
    c.r[2] += 1;  // 060231A6 add #1,r2
    c.r[8] = c.r[2] & 0xFFu;  // 060231A8 extu.b r2,r8
    c.r[4] -= c.r[0];  // 060231AA sub r0,r4
    c.r[4] += 1;  // 060231AC add #1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060231AE extu.b r4,r4
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[4];  // 060231B0 cmp/ge r4,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_060231BA; } }  // 060231B2 bf/s 0x060231BA ; mov #0,r6
    SH2_POLL(c); goto L_06022EE6;  // 060231B6 bra 0x06022EE6 ; nop
L_060231BA:
    c.r[13] = 0x49u;  // 060231BA mov #73,r13
    c.r[3] = 0x0u;  // 060231BC mov #0,r3
L_060231BE:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060231BE cmp/ge r8,r3
    if (c.t) { goto L_060231E8; }  // 060231C0 bt 0x060231E8
    c.r[5] = ld32(c.r[14] + 8);  // 060231C2 mov.l @(8,r14),r5
    c.r[5] += c.r[6];  // 060231C4 add r6,r5
L_060231C6:
    c.r[0] = c.r[7];  // 060231C6 mov r7,r0
    c.r[0] += c.r[0];  // 060231C8 add r0,r0
    c.r[2] = c.r[0];  // 060231CA mov r0,r2
    c.r[2] += c.r[9];  // 060231CC add r9,r2
    st8(c.r[0] + c.r[9], c.r[5]);  // 060231CE mov.b r5,@(r0,r9)
    c.r[2] += 1;  // 060231D0 add #1,r2
    c.r[1] = c.r[11];  // 060231D2 mov r11,r1
    c.r[1] += c.r[3];  // 060231D4 add r3,r1
    c.t = c.r[7] > c.r[13];  // 060231D6 cmp/hi r13,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_060231E8; } }  // 060231D8 bt/s 0x060231E8 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 060231DC mov r7,r1
    c.r[1] += 1;  // 060231DE add #1,r1
    c.r[3] += 1;  // 060231E0 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060231E2 cmp/ge r8,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_060231C6; } }  // 060231E4 bf/s 0x060231C6 ; extu.b r1,r7
L_060231E8:
    c.r[6] += 1;  // 060231E8 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 060231EA cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_060231BE; } }  // 060231EC bf/s 0x060231BE ; mov #0,r3
    c.r[1] = c.r[7]; SH2_POLL(c); goto L_06022EE8;  // 060231F0 bra 0x06022EE8 ; mov r7,r1
L_060231F4:
    c.r[1] = c.r[9];  // 060231F4 mov r9,r1
    c.r[1] -= c.r[3];  // 060231F6 sub r3,r1
    c.r[9] += c.r[3];  // 060231F8 add r3,r9
    c.r[4] = c.r[9] & 0xFFu;  // 060231FA extu.b r9,r4
    c.r[12] = ld32(c.r[14]);  // 060231FC mov.l @r14,r12
    c.r[10] = c.r[1] & 0xFFu;  // 060231FE extu.b r1,r10
    c.r[0] = ld32(c.r[14] + 8);  // 06023200 mov.l @(8,r14),r0
    c.r[7] = 0x0u;  // 06023202 mov #0,r7
    c.r[12] += c.r[0];  // 06023204 add r0,r12
    st32(c.r[14], c.r[12]);  // 06023206 mov.l r12,@r14
    c.r[12] = ld32(c.r[14] + 4);  // 06023208 mov.l @(4,r14),r12
    c.t = c.r[10] > c.r[4];  // 0602320A cmp/hi r4,r10
    c.r[0] += c.r[12];  // 0602320C add r12,r0
    st32(c.r[14] + 8, c.r[0]);  // 0602320E mov.l r0,@(8,r14)
    c.r[0] = 0xBu;  // 06023210 mov #11,r0
    c.r[0] += c.r[14];  // 06023212 add r14,r0
    c.r[12] = 0x3u;  // 06023214 mov #3,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023216 mov.b @r0,r0
    c.r[12] += c.r[14];  // 06023218 add r14,r12
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602321A mov.b @r12,r12
    c.r[2] = c.r[0] & 0xFFu;  // 0602321C extu.b r0,r2
    { const bool k = !c.t; c.r[9] = c.r[12] & 0xFFu; if (k) { goto L_06023226; } }  // 0602321E bf/s 0x06023226 ; extu.b r12,r9
    goto L_060233C8;  // 06023222 bra 0x060233C8 ; nop
L_06023226:
    c.t = c.r[9] > c.r[2];  // 06023226 cmp/hi r2,r9
    { const bool k = !c.t; c.r[4] -= c.r[10]; if (k) { goto L_06023230; } }  // 06023228 bf/s 0x06023230 ; sub r10,r4
    goto L_060233C8;  // 0602322C bra 0x060233C8 ; nop
L_06023230:
    c.r[4] += 1;  // 06023230 add #1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06023232 extu.b r4,r4
    c.r[2] -= c.r[9];  // 06023234 sub r9,r2
    c.r[2] += 1;  // 06023236 add #1,r2
    c.r[8] = c.r[2] & 0xFFu;  // 06023238 extu.b r2,r8
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[4];  // 0602323A cmp/ge r4,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_06023244; } }  // 0602323C bf/s 0x06023244 ; mov #0,r6
    goto L_06023412;  // 06023240 bra 0x06023412 ; nop
L_06023244:
    c.r[11] = 0x49u;  // 06023244 mov #73,r11
    c.r[3] = 0x0u;  // 06023246 mov #0,r3
L_06023248:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 06023248 cmp/ge r8,r3
    if (c.t) { goto L_06023272; }  // 0602324A bt 0x06023272
    c.r[5] = c.r[10];  // 0602324C mov r10,r5
    c.r[5] += c.r[6];  // 0602324E add r6,r5
L_06023250:
    c.r[0] = c.r[7];  // 06023250 mov r7,r0
    c.r[0] += c.r[0];  // 06023252 add r0,r0
    c.r[2] = c.r[0];  // 06023254 mov r0,r2
    c.r[2] += c.r[13];  // 06023256 add r13,r2
    st8(c.r[0] + c.r[13], c.r[5]);  // 06023258 mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 0602325A add #1,r2
    c.r[1] = c.r[9];  // 0602325C mov r9,r1
    c.r[1] += c.r[3];  // 0602325E add r3,r1
    c.t = c.r[7] > c.r[11];  // 06023260 cmp/hi r11,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06023272; } }  // 06023262 bt/s 0x06023272 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06023266 mov r7,r1
    c.r[1] += 1;  // 06023268 add #1,r1
    c.r[3] += 1;  // 0602326A add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 0602326C cmp/ge r8,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06023250; } }  // 0602326E bf/s 0x06023250 ; extu.b r1,r7
L_06023272:
    c.r[6] += 1;  // 06023272 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 06023274 cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_06023248; } }  // 06023276 bf/s 0x06023248 ; mov #0,r3
    c.r[1] = c.r[7]; goto L_06023414;  // 0602327A bra 0x06023414 ; mov r7,r1
L_0602327E:
    c.r[0] = c.r[3];  // 0602327E mov r3,r0
    c.t = c.r[0] == 0x11u;  // 06023280 cmp/eq #17,r0
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0602328A; } }  // 06023282 bt/s 0x0602328A ; mov r9,r2
    goto L_0602339A;  // 06023286 bra 0x0602339A ; nop
L_0602328A:
    c.r[12] = ld32(c.r[14] + 4);  // 0602328A mov.l @(4,r14),r12
    c.r[2] -= c.r[12];  // 0602328C sub r12,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 0602328E exts.b r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06023290 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06023298; } }  // 06023292 bf/s 0x06023298 ; mov #0,r1
    c.r[1] = c.r[2] & 0xFFu;  // 06023296 extu.b r2,r1
L_06023298:
    c.r[0] = ld32(c.r[14] + 8);  // 06023298 mov.l @(8,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602329A tst r0,r0
    { const bool k = c.t; c.r[11] = c.r[1]; if (k) { goto L_060232A6; } }  // 0602329C bt/s 0x060232A6 ; mov r1,r11
    c.r[1] = c.r[0];  // 060232A0 mov r0,r1
    c.r[1] -= 1; goto L_060232A8;  // 060232A2 bra 0x060232A8 ; add #-1,r1
L_060232A6:
    c.r[1] = 0x0u;  // 060232A6 mov #0,r1
L_060232A8:
    c.r[8] = c.r[1] & 0xFFu;  // 060232A8 extu.b r1,r8
    c.r[12] = ld32(c.r[14]);  // 060232AA mov.l @r14,r12
    c.r[2] = c.r[9];  // 060232AC mov r9,r2
    c.r[2] -= c.r[12];  // 060232AE sub r12,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 060232B0 exts.b r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060232B2 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060232BA; } }  // 060232B4 bf/s 0x060232BA ; mov #0,r1
    c.r[1] = c.r[2] & 0xFFu;  // 060232B8 extu.b r2,r1
L_060232BA:
    c.t = c.r[11] > c.r[1];  // 060232BA cmp/hi r1,r11
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_060232C4; } }  // 060232BC bf/s 0x060232C4 ; mov #0,r7
    c.r[1] = 0x0u; goto L_0602330A;  // 060232C0 bra 0x0602330A ; mov #0,r1
L_060232C4:
    c.r[1] -= c.r[11];  // 060232C4 sub r11,r1
    c.r[1] += 1;  // 060232C6 add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060232C8 extu.b r1,r10
    c.r[4] = 0x1u;  // 060232CA mov #1,r4
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 060232CC cmp/ge r10,r7
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06023308; } }  // 060232CE bt/s 0x06023308 ; mov #0,r6
L_060232D2:
    c.r[3] = 0x0u;  // 060232D2 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 060232D4 cmp/ge r4,r3
    if (c.t) { goto L_06023302; }  // 060232D6 bt 0x06023302
    c.r[5] = c.r[11];  // 060232D8 mov r11,r5
    c.r[5] += c.r[6];  // 060232DA add r6,r5
L_060232DC:
    c.r[1] = c.r[7];  // 060232DC mov r7,r1
    c.r[1] += c.r[1];  // 060232DE add r1,r1
    c.r[2] = c.r[1];  // 060232E0 mov r1,r2
    c.r[2] += c.r[13];  // 060232E2 add r13,r2
    c.r[0] = c.r[1];  // 060232E4 mov r1,r0
    st8(c.r[0] + c.r[13], c.r[5]);  // 060232E6 mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 060232E8 add #1,r2
    c.r[1] = c.r[8];  // 060232EA mov r8,r1
    c.r[1] += c.r[3];  // 060232EC add r3,r1
    c.r[12] = 0x49u;  // 060232EE mov #73,r12
    c.t = c.r[7] > c.r[12];  // 060232F0 cmp/hi r12,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06023302; } }  // 060232F2 bt/s 0x06023302 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 060232F6 mov r7,r1
    c.r[1] += 1;  // 060232F8 add #1,r1
    c.r[3] += 1;  // 060232FA add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 060232FC cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_060232DC; } }  // 060232FE bf/s 0x060232DC ; extu.b r1,r7
L_06023302:
    c.r[6] += 1;  // 06023302 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 06023304 cmp/ge r10,r6
    if (!c.t) { SH2_POLL(c); goto L_060232D2; }  // 06023306 bf 0x060232D2
L_06023308:
    c.r[1] = c.r[7];  // 06023308 mov r7,r1
L_0602330A:
    c.r[10] = c.r[1] & 0xFFu;  // 0602330A extu.b r1,r10
    c.r[0] = ld32(c.r[14] + 4);  // 0602330C mov.l @(4,r14),r0
    c.r[7] = c.r[9];  // 0602330E mov r9,r7
    c.r[7] -= c.r[0];  // 06023310 sub r0,r7
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[7];  // 06023312 exts.b r7,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06023314 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0602331C; } }  // 06023316 bf/s 0x0602331C ; mov #0,r1
    c.r[1] = c.r[7] & 0xFFu;  // 0602331A extu.b r7,r1
L_0602331C:
    c.r[11] = c.r[1];  // 0602331C mov r1,r11
    c.r[0] = 0xBu;  // 0602331E mov #11,r0
    c.r[12] = ld32(c.r[14] + 8);  // 06023320 mov.l @(8,r14),r12
    c.r[0] += c.r[14];  // 06023322 add r14,r0
    c.r[12] += 1;  // 06023324 add #1,r12
    st32(c.r[14] + 8, c.r[12]);  // 06023326 mov.l r12,@(8,r14)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023328 mov.b @r0,r0
    c.r[2] = c.r[9];  // 0602332A mov r9,r2
    c.r[12] = ld32(c.r[14]);  // 0602332C mov.l @r14,r12
    c.r[8] = c.r[0] & 0xFFu;  // 0602332E extu.b r0,r8
    c.r[2] -= c.r[12];  // 06023330 sub r12,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06023332 exts.b r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06023334 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0602333C; } }  // 06023336 bf/s 0x0602333C ; mov #0,r1
    c.r[1] = c.r[2] & 0xFFu;  // 0602333A extu.b r2,r1
L_0602333C:
    c.r[4] = c.r[10];  // 0602333C mov r10,r4
    c.r[4] += c.r[4];  // 0602333E add r4,r4
    c.r[4] += c.r[13];  // 06023340 add r13,r4
    c.t = c.r[11] > c.r[1];  // 06023342 cmp/hi r1,r11
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_0602334C; } }  // 06023344 bf/s 0x0602334C ; mov #0,r7
    SH2_POLL(c); goto L_06022EA0;  // 06023348 bra 0x06022EA0 ; nop
L_0602334C:
    c.r[1] -= c.r[11];  // 0602334C sub r11,r1
    c.r[1] += 1;  // 0602334E add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06023350 extu.b r1,r9
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[9];  // 06023352 cmp/ge r9,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0602335C; } }  // 06023354 bf/s 0x0602335C ; mov #0,r6
    SH2_POLL(c); goto L_06022EE6;  // 06023358 bra 0x06022EE6 ; nop
L_0602335C:
    c.r[13] = 0x49u;  // 0602335C mov #73,r13
    c.r[3] = 0x0u;  // 0602335E mov #0,r3
L_06023360:
    c.r[0] = 0x1u;  // 06023360 mov #1,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 06023362 cmp/ge r0,r3
    if (c.t) { goto L_0602338E; }  // 06023364 bt 0x0602338E
    c.r[5] = c.r[11];  // 06023366 mov r11,r5
    c.r[5] += c.r[6];  // 06023368 add r6,r5
L_0602336A:
    c.r[0] = c.r[7];  // 0602336A mov r7,r0
    c.r[0] += c.r[0];  // 0602336C add r0,r0
    c.r[2] = c.r[0];  // 0602336E mov r0,r2
    c.r[2] += c.r[4];  // 06023370 add r4,r2
    st8(c.r[0] + c.r[4], c.r[5]);  // 06023372 mov.b r5,@(r0,r4)
    c.r[2] += 1;  // 06023374 add #1,r2
    c.r[1] = c.r[8];  // 06023376 mov r8,r1
    c.r[1] += c.r[3];  // 06023378 add r3,r1
    c.t = c.r[7] > c.r[13];  // 0602337A cmp/hi r13,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_0602338E; } }  // 0602337C bt/s 0x0602338E ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06023380 mov r7,r1
    c.r[1] += 1;  // 06023382 add #1,r1
    c.r[3] += 1;  // 06023384 add #1,r3
    c.r[12] = 0x1u;  // 06023386 mov #1,r12
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[12];  // 06023388 cmp/ge r12,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_0602336A; } }  // 0602338A bf/s 0x0602336A ; extu.b r1,r7
L_0602338E:
    c.r[6] += 1;  // 0602338E add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[9];  // 06023390 cmp/ge r9,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_06023360; } }  // 06023392 bf/s 0x06023360 ; mov #0,r3
    c.r[1] = c.r[7]; SH2_POLL(c); goto L_06022EE8;  // 06023396 bra 0x06022EE8 ; mov r7,r1
L_0602339A:
    c.r[0] = ld32(c.r[14] + 4);  // 0602339A mov.l @(4,r14),r0
    c.r[1] = c.r[9];  // 0602339C mov r9,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0602339E mov.l @(8,r14),r2
    c.r[7] = 0x0u;  // 060233A0 mov #0,r7
    c.r[12] = ld32(c.r[14]);  // 060233A2 mov.l @r14,r12
    c.r[1] -= c.r[0];  // 060233A4 sub r0,r1
    c.r[2] -= c.r[3];  // 060233A6 sub r3,r2
    c.r[9] -= c.r[12];  // 060233A8 sub r12,r9
    c.r[4] = c.r[9] & 0xFFu;  // 060233AA extu.b r9,r4
    c.r[12] = 0xBu;  // 060233AC mov #11,r12
    c.r[12] += c.r[14];  // 060233AE add r14,r12
    c.r[10] = c.r[1] & 0xFFu;  // 060233B0 extu.b r1,r10
    c.r[0] = ld32(c.r[14] + 8);  // 060233B2 mov.l @(8,r14),r0
    c.r[9] = c.r[2] & 0xFFu;  // 060233B4 extu.b r2,r9
    c.r[0] += c.r[3];  // 060233B6 add r3,r0
    st32(c.r[14] + 8, c.r[0]);  // 060233B8 mov.l r0,@(8,r14)
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060233BA mov.b @r12,r12
    c.t = c.r[10] > c.r[4];  // 060233BC cmp/hi r4,r10
    { const bool k = c.t; c.r[5] = c.r[12] & 0xFFu; if (k) { goto L_060233C8; } }  // 060233BE bt/s 0x060233C8 ; extu.b r12,r5
    c.t = c.r[9] > c.r[5];  // 060233C2 cmp/hi r5,r9
    { const bool k = !c.t; c.r[4] -= c.r[10]; if (k) { goto L_060233CC; } }  // 060233C4 bf/s 0x060233CC ; sub r10,r4
L_060233C8:
    c.r[1] = 0x0u; goto L_06023414;  // 060233C8 bra 0x06023414 ; mov #0,r1
L_060233CC:
    c.r[4] += 1;  // 060233CC add #1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060233CE extu.b r4,r4
    c.r[5] -= c.r[9];  // 060233D0 sub r9,r5
    c.r[5] += 1;  // 060233D2 add #1,r5
    c.r[8] = c.r[5] & 0xFFu;  // 060233D4 extu.b r5,r8
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[4];  // 060233D6 cmp/ge r4,r7
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06023412; } }  // 060233D8 bt/s 0x06023412 ; mov #0,r6
    c.r[11] = 0x49u;  // 060233DC mov #73,r11
    c.r[3] = 0x0u;  // 060233DE mov #0,r3
L_060233E0:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060233E0 cmp/ge r8,r3
    if (c.t) { goto L_0602340A; }  // 060233E2 bt 0x0602340A
    c.r[5] = c.r[10];  // 060233E4 mov r10,r5
    c.r[5] += c.r[6];  // 060233E6 add r6,r5
L_060233E8:
    c.r[0] = c.r[7];  // 060233E8 mov r7,r0
    c.r[0] += c.r[0];  // 060233EA add r0,r0
    c.r[2] = c.r[0];  // 060233EC mov r0,r2
    c.r[2] += c.r[13];  // 060233EE add r13,r2
    st8(c.r[0] + c.r[13], c.r[5]);  // 060233F0 mov.b r5,@(r0,r13)
    c.r[2] += 1;  // 060233F2 add #1,r2
    c.r[1] = c.r[9];  // 060233F4 mov r9,r1
    c.r[1] += c.r[3];  // 060233F6 add r3,r1
    c.t = c.r[7] > c.r[11];  // 060233F8 cmp/hi r11,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_0602340A; } }  // 060233FA bt/s 0x0602340A ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 060233FE mov r7,r1
    c.r[1] += 1;  // 06023400 add #1,r1
    c.r[3] += 1;  // 06023402 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 06023404 cmp/ge r8,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_060233E8; } }  // 06023406 bf/s 0x060233E8 ; extu.b r1,r7
L_0602340A:
    c.r[6] += 1;  // 0602340A add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0602340C cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_060233E0; } }  // 0602340E bf/s 0x060233E0 ; mov #0,r3
L_06023412:
    c.r[1] = c.r[7];  // 06023412 mov r7,r1
L_06023414:
    c.r[10] = c.r[1] & 0xFFu;  // 06023414 extu.b r1,r10
L_06023416:
    c.r[14] += 12;  // 06023416 add #12,r14
    c.r[15] = c.r[14];  // 06023418 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602341A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602341C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602341E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06023420 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 06023422 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06023424 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06023426 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06023428 rts ; mov.l @r15+,r8
}

void f_0602342C(SH2Context& c) {
    ran[447] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602342C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602342E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06023430 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06023432 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06023434 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06023436 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023438 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602343A sts.l pr,@-r15
    c.r[15] -= 16;  // 0602343C add #-16,r15
    c.r[14] = c.r[15];  // 0602343E mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06023440 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 06023442 mov.l r4,@r14
    c.r[5] = c.r[5] & 0xFFu;  // 06023444 extu.b r5,r5
    st32(c.r[14] + 4, c.r[5]);  // 06023446 mov.l r5,@(4,r14)
    c.r[13] = c.r[6] & 0xFFu;  // 06023448 extu.b r6,r13
    c.r[1] = ld32(0x06023558u);  // 0602344A mov.l 0x06023558,r1
    c.r[2] = c.r[4];  // 0602344C mov r4,r2
    c.r[2] <<= 2;  // 0602344E shll2 r2
    c.r[2] <<= 2;  // 06023450 shll2 r2
    c.r[0] = 0x0u;  // 06023452 mov #0,r0
    c.r[8] = 0x0u;  // 06023454 mov #0,r8
    c.r[1] = ld32(c.r[1]);  // 06023456 mov.l @r1,r1
    c.r[9] = 0x0u;  // 06023458 mov #0,r9
    c.r[2] += c.r[1];  // 0602345A add r1,r2
    c.r[2] += 9;  // 0602345C add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602345E mov.b @r2,r1
    c.r[11] = 0x0u;  // 06023460 mov #0,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06023462 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 06023464 mov.l r1,@(8,r14)
    st32(c.r[14] + 12, c.r[0]);  // 06023466 mov.l r0,@(12,r14)
L_06023468:
    c.r[0] = ld32(c.r[14]);  // 06023468 mov.l @r14,r0
    c.t = c.r[8] == c.r[0];  // 0602346A cmp/eq r0,r8
    if (!c.t) { goto L_06023472; }  // 0602346C bf 0x06023472
    goto L_060235C0;  // 0602346E bra 0x060235C0 ; nop
L_06023472:
    c.r[3] = c.r[11];  // 06023472 mov r11,r3
    c.r[1] = ld32(0x06023558u);  // 06023474 mov.l 0x06023558,r1
    c.r[0] = ld32(c.r[1]);  // 06023476 mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06023552u);  // 06023478 mov.w 0x06023552,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0602347A mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602347C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602347E cmp/eq r2,r1
    { const bool k = !c.t; c.r[3] += c.r[0]; if (k) { goto L_06023488; } }  // 06023480 bf/s 0x06023488 ; add r0,r3
    goto L_060235C0;  // 06023484 bra 0x060235C0 ; nop
L_06023488:
    c.r[2] = ld32(c.r[3] + 4);  // 06023488 mov.l @(4,r3),r2
    c.r[1] = ld32(0x0602355Cu);  // 0602348A mov.l 0x0602355C,r1
    c.r[2] &= c.r[1];  // 0602348C and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602348E tst r2,r2
    if (c.t) { goto L_06023496; }  // 06023490 bt 0x06023496
    goto L_060235C0;  // 06023492 bra 0x060235C0 ; nop
L_06023496:
    c.r[1] = ld32(0x06023560u);  // 06023496 mov.l 0x06023560,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602349Cu; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602349Cu) return; }  // 06023498 jsr @r1 ; extu.b r8,r4
    c.r[0] = ld32(c.r[14] + 4);  // 0602349C mov.l @(4,r14),r0
    c.r[1] = 0x0u;  // 0602349E mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060234A0 cmp/ge r0,r1
    if (!c.t) { goto L_060234A8; }  // 060234A2 bf 0x060234A8
    goto L_060235C0;  // 060234A4 bra 0x060235C0 ; nop
L_060234A8:
    c.r[12] = 0x0u;  // 060234A8 mov #0,r12
    c.r[10] = ld32(0x06023564u);  // 060234AA mov.l 0x06023564,r10
L_060234AC:
    c.r[1] = ld32(0x06023558u);  // 060234AC mov.l 0x06023558,r1
    c.r[7] = c.r[11];  // 060234AE mov r11,r7
    c.r[6] = ld32(c.r[1]);  // 060234B0 mov.l @r1,r6
    c.r[0] = ld32(0x06023564u);  // 060234B2 mov.l 0x06023564,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060234B4 mov.b @(r0,r12),r2
    c.r[0] = c.r[11];  // 060234B6 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060234B8 mov.b @(r0,r6),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060234BA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060234BC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060234BE cmp/eq r1,r2
    { const bool k = !c.t; c.r[7] += c.r[6]; if (k) { goto L_060235AC; } }  // 060234C0 bf/s 0x060235AC ; add r6,r7
    c.r[1] = c.r[10];  // 060234C4 mov r10,r1
    c.r[1] += 1;  // 060234C6 add #1,r1
    c.r[3] = c.r[7];  // 060234C8 mov r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060234CA mov.b @r1,r2
    c.r[3] += 1;  // 060234CC add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060234CE mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060234D0 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060234D2 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060234D4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_060235AC; } }  // 060234D6 bf/s 0x060235AC ; mov.l @r14,r1
    c.r[1] <<= 2;  // 060234DA shll2 r1
    c.r[1] <<= 2;  // 060234DC shll2 r1
    c.r[1] += c.r[6];  // 060234DE add r6,r1
    c.r[1] += 4;  // 060234E0 add #4,r1
    c.r[0] = 0xFu;  // 060234E2 mov #15,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060234E4 mov.b @r1,r1
    c.r[7] += 3;  // 060234E6 add #3,r7
    c.r[2] = c.r[1];  // 060234E8 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060234EA shlr r2
    c.r[2] &= c.r[0];  // 060234EC and r0,r2
    c.r[0] = 0x3u;  // 060234EE mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060234F0 mov.b @r7,r1
    c.r[4] = c.r[2];  // 060234F2 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060234F4 shlr r1
    c.r[1] &= c.r[0];  // 060234F6 and r0,r1
    c.r[0] = ld32(0x06023568u);  // 060234F8 mov.l 0x06023568,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060234FEu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060234FEu) return; }  // 060234FA jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 060234FE mov r0,r1
    c.r[0] = 0x1u;  // 06023500 mov #1,r0
    c.r[1] &= c.r[0];  // 06023502 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06023504 tst r1,r1
    if (c.t) { goto L_06023570; }  // 06023506 bt 0x06023570
    c.r[0] = ld32(0x0602356Cu);  // 06023508 mov.l 0x0602356C,r0
    c.r[3] = ld32(c.r[0]);  // 0602350A mov.l @r0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06023554u);  // 0602350C mov.w 0x06023554,r0
    c.macl = c.r[13] * c.r[0];  // 0602350E mul.l r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06023556u);  // 06023510 mov.w 0x06023556,r1
    c.r[2] = c.macl;  // 06023512 sts macl,r2
    c.r[2] += c.r[3];  // 06023514 add r3,r2
    c.r[0] = c.r[2];  // 06023516 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06023518 mov.b @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0602351A extu.b r1,r7
    c.r[2] = 0x0u;  // 0602351C mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 0602351E cmp/ge r7,r2
    if (c.t) { goto L_060235AC; }  // 06023520 bt 0x060235AC
    c.r[6] = c.r[3];  // 06023522 mov r3,r6
    c.r[3] = 0x0u;  // 06023524 mov #0,r3
L_06023526:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06023554u);  // 06023526 mov.w 0x06023554,r0
    c.macl = c.r[13] * c.r[0];  // 06023528 mul.l r0,r13
    c.r[1] = c.macl;  // 0602352A sts macl,r1
    c.r[1] += c.r[6];  // 0602352C add r6,r1
    c.r[1] += c.r[3];  // 0602352E add r3,r1
    c.r[1] += 4;  // 06023530 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023532 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023534 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06023536 cmp/eq r8,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06023546; } }  // 06023538 bf/s 0x06023546 ; mov.l @(8,r14),r0
    c.t = c.r[8] == c.r[0];  // 0602353C cmp/eq r0,r8
    { const bool k = !c.t; c.r[9] += 1; if (k) { goto L_06023546; } }  // 0602353E bf/s 0x06023546 ; add #1,r9
    c.r[0] = 0x1u;  // 06023542 mov #1,r0
    st32(c.r[14] + 12, c.r[0]);  // 06023544 mov.l r0,@(12,r14)
L_06023546:
    c.r[2] += 1;  // 06023546 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 06023548 cmp/ge r7,r2
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_06023526; } }  // 0602354A bf/s 0x06023526 ; add #8,r3
    c.r[10] += 2; goto L_060235AE;  // 0602354E bra 0x060235AE ; add #2,r10
L_06023570:
    c.r[0] = ld32(0x06023600u);  // 06023570 mov.l 0x06023600,r0
    c.r[3] = ld32(c.r[0]);  // 06023572 mov.l @r0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060235F8u);  // 06023574 mov.w 0x060235F8,r0
    c.macl = c.r[13] * c.r[0];  // 06023576 mul.l r0,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x060235FAu);  // 06023578 mov.w 0x060235FA,r1
    c.r[2] = c.macl;  // 0602357A sts macl,r2
    c.r[2] += c.r[3];  // 0602357C add r3,r2
    c.r[0] = c.r[2];  // 0602357E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06023580 mov.b @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06023582 extu.b r1,r7
    c.r[2] = 0x0u;  // 06023584 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 06023586 cmp/ge r7,r2
    if (c.t) { goto L_060235AC; }  // 06023588 bt 0x060235AC
    c.r[6] = c.r[3];  // 0602358A mov r3,r6
    c.r[3] = 0x0u;  // 0602358C mov #0,r3
L_0602358E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060235F8u);  // 0602358E mov.w 0x060235F8,r0
    c.macl = c.r[13] * c.r[0];  // 06023590 mul.l r0,r13
    c.r[1] = c.macl;  // 06023592 sts macl,r1
    c.r[1] += c.r[6];  // 06023594 add r6,r1
    c.r[1] += c.r[3];  // 06023596 add r3,r1
    c.r[1] += 4;  // 06023598 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602359A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602359C extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0602359E cmp/eq r8,r1
    if (!c.t) { goto L_060235A4; }  // 060235A0 bf 0x060235A4
    c.r[9] -= 2;  // 060235A2 add #-2,r9
L_060235A4:
    c.r[2] += 1;  // 060235A4 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 060235A6 cmp/ge r7,r2
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_0602358E; } }  // 060235A8 bf/s 0x0602358E ; add #8,r3
L_060235AC:
    c.r[10] += 2;  // 060235AC add #2,r10
L_060235AE:
    c.r[1] = ld32(c.r[14] + 4);  // 060235AE mov.l @(4,r14),r1
    c.r[0] = ld32(0x06023604u);  // 060235B0 mov.l 0x06023604,r0
    c.r[1] += c.r[1];  // 060235B2 add r1,r1
    c.r[1] += c.r[0];  // 060235B4 add r0,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060235B6 cmp/ge r1,r10
    { const bool k = c.t; c.r[12] += 2; if (k) { goto L_060235C0; } }  // 060235B8 bt/s 0x060235C0 ; add #2,r12
    SH2_POLL(c); goto L_060234AC;  // 060235BC bra 0x060234AC ; nop
L_060235C0:
    c.r[8] += 1;  // 060235C0 add #1,r8
    c.r[1] = 0x49u;  // 060235C2 mov #73,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060235C4 cmp/gt r1,r8
    { const bool k = c.t; c.r[11] += 16; if (k) { goto L_060235CE; } }  // 060235C6 bt/s 0x060235CE ; add #16,r11
    SH2_POLL(c); goto L_06023468;  // 060235CA bra 0x06023468 ; nop
L_060235CE:
    c.r[0] = ld32(c.r[14] + 8);  // 060235CE mov.l @(8,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060235FCu);  // 060235D0 mov.w 0x060235FC,r1
    c.t = c.r[0] == c.r[1];  // 060235D2 cmp/eq r1,r0
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_060235E2; } }  // 060235D4 bt/s 0x060235E2 ; mov r9,r0
    c.r[0] = ld32(c.r[14] + 12);  // 060235D8 mov.l @(12,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060235DA tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060235E2; } }  // 060235DC bt/s 0x060235E2 ; mov #0,r0
    c.r[0] = c.r[9];  // 060235E0 mov r9,r0
L_060235E2:
    c.r[14] += 16;  // 060235E2 add #16,r14
    c.r[15] = c.r[14];  // 060235E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060235E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060235E8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060235EA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060235EC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060235EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060235F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060235F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060235F4 rts ; mov.l @r15+,r8
}

void f_06023608(SH2Context& c) {
    ran[448] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06023608 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602360A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602360C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602360E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06023610 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06023612 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023614 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06023616 sts.l pr,@-r15
    c.r[15] -= 76;  // 06023618 add #-76,r15
    c.r[14] = c.r[15];  // 0602361A mov r15,r14
    c.r[7] = c.r[5];  // 0602361C mov r5,r7
    c.r[4] = c.r[4] & 0xFFu;  // 0602361E extu.b r4,r4
    st32(c.r[14] + 28, c.r[4]);  // 06023620 mov.l r4,@(28,r14)
    c.r[7] = c.r[7] & 0xFFu;  // 06023622 extu.b r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06023752u);  // 06023624 mov.w 0x06023752,r0
    st32(c.r[14] + 48, c.r[0]);  // 06023626 mov.l r0,@(48,r14)
    c.r[1] = ld32(0x06023754u);  // 06023628 mov.l 0x06023754,r1
    c.r[2] = c.r[4];  // 0602362A mov r4,r2
    c.r[12] = ld32(c.r[14] + 48);  // 0602362C mov.l @(48,r14),r12
    c.r[2] <<= 2;  // 0602362E shll2 r2
    c.r[2] <<= 2;  // 06023630 shll2 r2
    c.r[13] = ld32(c.r[14] + 48);  // 06023632 mov.l @(48,r14),r13
    c.r[4] = ld32(0x06023758u);  // 06023634 mov.l 0x06023758,r4
    c.r[0] = ld32(c.r[14] + 48);  // 06023636 mov.l @(48,r14),r0
    st32(c.r[14] + 44, c.r[12]);  // 06023638 mov.l r12,@(44,r14)
    st32(c.r[14] + 52, c.r[13]);  // 0602363A mov.l r13,@(52,r14)
    st32(c.r[14] + 56, c.r[0]);  // 0602363C mov.l r0,@(56,r14)
    c.r[3] = ld32(c.r[1]);  // 0602363E mov.l @r1,r3
    c.r[0] = c.r[2];  // 06023640 mov r2,r0
    c.r[1] = c.r[2];  // 06023642 mov r2,r1
    c.r[1] += c.r[3];  // 06023644 add r3,r1
    c.r[1] += 1;  // 06023646 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023648 mov.b @r1,r6
    c.r[12] = ld32(0x0602375Cu);  // 0602364A mov.l 0x0602375C,r12
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602364C mov.b @(r0,r3),r5
    c.r[6] = c.r[6] & 0xFFu;  // 0602364E extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06023650 extu.b r5,r5
    c.r[1] = 0x0u;  // 06023652 mov #0,r1
    { const uint32_t x = c.r[12]; c.pr = 0x06023658u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023658u) return; }  // 06023654 jsr @r12 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 06023658 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602365A extu.b r1,r1
    st32(c.r[14] + 40, c.r[1]);  // 0602365C mov.l r1,@(40,r14)
    c.r[13] = 0x0u;  // 0602365E mov #0,r13
    st32(c.r[14] + 36, c.r[13]);  // 06023660 mov.l r13,@(36,r14)
    c.r[0] = 0x0u;  // 06023662 mov #0,r0
    st32(c.r[14] + 32, c.r[0]);  // 06023664 mov.l r0,@(32,r14)
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 06023666 cmp/ge r1,r13
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_06023670; } }  // 06023668 bf/s 0x06023670 ; add #4,r15
    goto L_060237D8;  // 0602366C bra 0x060237D8 ; nop
L_06023670:
    c.r[12] = ld32(0x06023758u);  // 06023670 mov.l 0x06023758,r12
    st32(c.r[14] + 60, c.r[12]);  // 06023672 mov.l r12,@(60,r14)
    c.r[13] = 0x40u;  // 06023674 mov #64,r13
    c.r[13] += c.r[14];  // 06023676 add r14,r13
    st32(c.r[13], c.r[0]);  // 06023678 mov.l r0,@r13
    c.r[12] = 0x40u;  // 0602367A mov #64,r12
L_0602367C:
    c.r[12] += c.r[14];  // 0602367C add r14,r12
    c.r[13] = ld32(0x06023758u);  // 0602367E mov.l 0x06023758,r13
    c.r[1] = ld32(c.r[14] + 60);  // 06023680 mov.l @(60,r14),r1
    c.r[7] = 0x2u;  // 06023682 mov #2,r7
    c.r[0] = ld32(c.r[12]);  // 06023684 mov.l @r12,r0
    c.r[1] += 1;  // 06023686 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023688 mov.b @r1,r6
    c.r[4] = c.r[14];  // 0602368A mov r14,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0602368C mov.b @(r0,r13),r5
    c.r[6] = c.r[6] & 0xFFu;  // 0602368E extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06023690 extu.b r5,r5
    c.r[1] = 0x0u;  // 06023692 mov #0,r1
    c.r[0] = ld32(0x0602375Cu);  // 06023694 mov.l 0x0602375C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602369Au; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602369Au) return; }  // 06023696 jsr @r0 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 0602369A mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602369C extu.b r1,r1
    c.r[12] = 0x44u;  // 0602369E mov #68,r12
    c.r[12] += c.r[14];  // 060236A0 add r14,r12
    st32(c.r[12], c.r[1]);  // 060236A2 mov.l r1,@r12
    c.r[9] = 0x0u;  // 060236A4 mov #0,r9
    c.r[11] = 0x0u;  // 060236A6 mov #0,r11
    c.r[15] += 4;  // 060236A8 add #4,r15
    c.r[10] = 0x0u;  // 060236AA mov #0,r10
L_060236AC:
    c.r[1] = ld32(0x06023760u);  // 060236AC mov.l 0x06023760,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060236B2u; c.r[4] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060236B2u) return; }  // 060236AE jsr @r1 ; extu.b r11,r4
    c.r[13] = ld32(c.r[14] + 28);  // 060236B2 mov.l @(28,r14),r13
    c.t = c.r[11] == c.r[13];  // 060236B4 cmp/eq r13,r11
    { const bool k = c.t; c.r[3] = c.r[10]; if (k) { goto L_0602377C; } }  // 060236B6 bt/s 0x0602377C ; mov r10,r3
    c.r[1] = ld32(0x06023754u);  // 060236BA mov.l 0x06023754,r1
    c.r[0] = ld32(c.r[1]);  // 060236BC mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06023752u);  // 060236BE mov.w 0x06023752,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060236C0 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060236C2 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060236C4 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0602377C; } }  // 060236C6 bt/s 0x0602377C ; add r0,r3
    c.r[2] = ld32(c.r[3] + 4);  // 060236CA mov.l @(4,r3),r2
    c.r[1] = ld32(0x06023764u);  // 060236CC mov.l 0x06023764,r1
    c.r[2] &= c.r[1];  // 060236CE and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060236D0 tst r2,r2
    { const bool k = !c.t; c.r[0] = 0x44u; if (k) { goto L_0602377C; } }  // 060236D2 bf/s 0x0602377C ; mov #68,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060236D6 mov.l @(r0,r14),r0
    c.r[1] = 0x0u;  // 060236D8 mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060236DA cmp/ge r0,r1
    { const bool k = c.t; c.r[12] = 0x48u; if (k) { goto L_0602377C; } }  // 060236DC bt/s 0x0602377C ; mov #72,r12
    c.r[12] += c.r[14];  // 060236E0 add r14,r12
    st32(c.r[12], c.r[10]);  // 060236E2 mov.l r10,@r12
    c.r[8] = 0x0u;  // 060236E4 mov #0,r8
L_060236E6:
    c.r[1] = ld32(0x06023754u);  // 060236E6 mov.l 0x06023754,r1
    c.r[13] = 0x48u;  // 060236E8 mov #72,r13
    c.r[13] += c.r[14];  // 060236EA add r14,r13
    c.r[6] = ld32(c.r[1]);  // 060236EC mov.l @r1,r6
    c.r[0] = c.r[8];  // 060236EE mov r8,r0
    c.r[7] = ld32(c.r[13]);  // 060236F0 mov.l @r13,r7
    c.r[12] = 0x48u;  // 060236F2 mov #72,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060236F4 mov.b @(r0,r14),r2
    c.r[12] += c.r[14];  // 060236F6 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060236F8 mov.l @r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060236FA mov.b @(r0,r6),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060236FC extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060236FE extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06023700 cmp/eq r1,r2
    { const bool k = !c.t; c.r[7] += c.r[6]; if (k) { goto L_0602376E; } }  // 06023702 bf/s 0x0602376E ; add r6,r7
    c.r[1] = c.r[14];  // 06023706 mov r14,r1
    c.r[1] += 1;  // 06023708 add #1,r1
    c.r[3] = c.r[7];  // 0602370A mov r7,r3
    c.r[0] = c.r[1];  // 0602370C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0602370E mov.b @(r0,r8),r2
    c.r[3] += 1;  // 06023710 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023712 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06023714 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06023716 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06023718 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 28); if (k) { goto L_0602376E; } }  // 0602371A bf/s 0x0602376E ; mov.l @(28,r14),r1
    c.r[1] <<= 2;  // 0602371E shll2 r1
    c.r[1] <<= 2;  // 06023720 shll2 r1
    c.r[1] += c.r[6];  // 06023722 add r6,r1
    c.r[1] += 4;  // 06023724 add #4,r1
    c.r[12] = 0xFu;  // 06023726 mov #15,r12
    c.r[7] += 3;  // 06023728 add #3,r7
    c.r[13] = 0x3u;  // 0602372A mov #3,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602372C mov.b @r1,r1
    c.r[0] = ld32(0x06023768u);  // 0602372E mov.l 0x06023768,r0
    c.r[2] = c.r[1];  // 06023730 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06023732 shlr r2
    c.r[2] &= c.r[12];  // 06023734 and r12,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06023736 mov.b @r7,r1
    c.r[4] = c.r[2];  // 06023738 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602373A shlr r1
    c.r[1] &= c.r[13];  // 0602373C and r13,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06023742u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023742u) return; }  // 0602373E jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06023742 mov r0,r1
    c.r[12] = 0x1u;  // 06023744 mov #1,r12
    c.r[1] &= c.r[12];  // 06023746 and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06023748 tst r1,r1
    if (c.t) { goto L_0602376C; }  // 0602374A bt 0x0602376C
    c.r[9] += 1;  // 0602374C add #1,r9
    c.r[13] = 0x44u; goto L_06023770;  // 0602374E bra 0x06023770 ; mov #68,r13
L_0602376C:
    c.r[9] -= 2;  // 0602376C add #-2,r9
L_0602376E:
    c.r[13] = 0x44u;  // 0602376E mov #68,r13
L_06023770:
    c.r[13] += c.r[14];  // 06023770 add r14,r13
    c.r[1] = ld32(c.r[13]);  // 06023772 mov.l @r13,r1
    c.r[8] += 2;  // 06023774 add #2,r8
    c.r[1] += c.r[1];  // 06023776 add r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06023778 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_060236E6; }  // 0602377A bf 0x060236E6
L_0602377C:
    c.r[11] += 1;  // 0602377C add #1,r11
    c.r[1] = 0x49u;  // 0602377E mov #73,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06023780 cmp/gt r1,r11
    { const bool k = !c.t; c.r[10] += 16; if (k) { SH2_POLL(c); goto L_060236AC; } }  // 06023782 bf/s 0x060236AC ; add #16,r10
    c.r[0] = ld32(c.r[14] + 32);  // 06023786 mov.l @(32,r14),r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[9];  // 06023788 cmp/gt r9,r0
    { const bool k = c.t; c.r[12] = 0x40u; if (k) { goto L_060237B6; } }  // 0602378A bt/s 0x060237B6 ; mov #64,r12
    c.r[12] = ld32(c.r[14] + 32);  // 0602378E mov.l @(32,r14),r12
    c.r[13] = ld32(c.r[14] + 44);  // 06023790 mov.l @(44,r14),r13
    c.r[0] = ld32(c.r[14] + 48);  // 06023792 mov.l @(48,r14),r0
    st32(c.r[14] + 36, c.r[12]);  // 06023794 mov.l r12,@(36,r14)
    st32(c.r[14] + 52, c.r[13]);  // 06023796 mov.l r13,@(52,r14)
    st32(c.r[14] + 56, c.r[0]);  // 06023798 mov.l r0,@(56,r14)
    st32(c.r[14] + 32, c.r[9]);  // 0602379A mov.l r9,@(32,r14)
    c.r[12] = 0x40u;  // 0602379C mov #64,r12
    c.r[12] += c.r[14];  // 0602379E add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060237A0 mov.l @r12,r0
    c.r[13] = ld32(0x0602385Cu);  // 060237A2 mov.l 0x0602385C,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060237A4 mov.b @(r0,r13),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060237A6 extu.b r1,r1
    st32(c.r[14] + 44, c.r[1]);  // 060237A8 mov.l r1,@(44,r14)
    c.r[1] = ld32(c.r[14] + 60);  // 060237AA mov.l @(60,r14),r1
    c.r[1] += 1;  // 060237AC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060237AE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060237B0 extu.b r1,r1
    st32(c.r[14] + 48, c.r[1]);  // 060237B2 mov.l r1,@(48,r14)
    c.r[12] = 0x40u;  // 060237B4 mov #64,r12
L_060237B6:
    c.r[0] = ld32(c.r[14] + 60);  // 060237B6 mov.l @(60,r14),r0
    c.r[12] += c.r[14];  // 060237B8 add r14,r12
    c.r[0] += 2;  // 060237BA add #2,r0
    st32(c.r[14] + 60, c.r[0]);  // 060237BC mov.l r0,@(60,r14)
    c.r[13] = ld32(c.r[12]);  // 060237BE mov.l @r12,r13
    c.r[0] = ld32(0x0602385Cu);  // 060237C0 mov.l 0x0602385C,r0
    c.r[13] += 2;  // 060237C2 add #2,r13
    st32(c.r[12], c.r[13]);  // 060237C4 mov.l r13,@r12
    c.r[1] = ld32(c.r[14] + 40);  // 060237C6 mov.l @(40,r14),r1
    c.r[12] = ld32(c.r[14] + 60);  // 060237C8 mov.l @(60,r14),r12
    c.r[1] += c.r[1];  // 060237CA add r1,r1
    c.r[1] += c.r[0];  // 060237CC add r0,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060237CE cmp/ge r1,r12
    { const bool k = c.t; c.r[12] = 0x40u; if (k) { goto L_060237D8; } }  // 060237D0 bt/s 0x060237D8 ; mov #64,r12
    SH2_POLL(c); goto L_0602367C;  // 060237D4 bra 0x0602367C ; nop
L_060237D8:
    c.r[13] = ld32(c.r[14] + 32);  // 060237D8 mov.l @(32,r14),r13
    c.r[1] = 0x2u;  // 060237DA mov #2,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060237DC cmp/gt r1,r13
    { const bool k = !c.t; c.r[12] = ld32(c.r[14] + 44); if (k) { goto L_06023842; } }  // 060237DE bf/s 0x06023842 ; mov.l @(44,r14),r12
    c.r[1] = ld32(0x06023860u);  // 060237E2 mov.l 0x06023860,r1
    c.r[2] = ld32(c.r[1]);  // 060237E4 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 28);  // 060237E6 mov.l @(28,r14),r1
    c.r[1] <<= 2;  // 060237E8 shll2 r1
    c.r[1] <<= 2;  // 060237EA shll2 r1
    c.r[3] = c.r[1];  // 060237EC mov r1,r3
    c.r[0] = c.r[1];  // 060237EE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060237F0 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060237F2 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 060237F4 cmp/eq r12,r1
    { const bool k = !c.t; c.r[3] += c.r[2]; if (k) { goto L_0602382C; } }  // 060237F6 bf/s 0x0602382C ; add r2,r3
    c.r[3] += 1;  // 060237FA add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060237FC mov.b @r3,r1
    c.r[13] = ld32(c.r[14] + 48);  // 060237FE mov.l @(48,r14),r13
    c.r[1] = c.r[1] & 0xFFu;  // 06023800 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06023802 cmp/eq r13,r1
    if (!c.t) { goto L_0602382C; }  // 06023804 bf 0x0602382C
    c.r[0] = ld32(c.r[14] + 36);  // 06023806 mov.l @(36,r14),r0
    c.r[12] = ld32(c.r[14] + 32);  // 06023808 mov.l @(32,r14),r12
    c.t = c.r[0] == c.r[12];  // 0602380A cmp/eq r12,r0
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 52); if (k) { goto L_06023818; } }  // 0602380C bf/s 0x06023818 ; mov.l @(52,r14),r13
    c.r[0] = ld32(c.r[14] + 56);  // 06023810 mov.l @(56,r14),r0
    st32(c.r[14] + 44, c.r[13]);  // 06023812 mov.l r13,@(44,r14)
    st32(c.r[14] + 48, c.r[0]); goto L_0602382C;  // 06023814 bra 0x0602382C ; mov.l r0,@(48,r14)
L_06023818:
    c.r[12] = ld32(c.r[14] + 44);  // 06023818 mov.l @(44,r14),r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 0602381A tst r12,r12
    { const bool k = c.t; c.r[13] = 0x1u; if (k) { goto L_0602382A; } }  // 0602381C bt/s 0x0602382A ; mov #1,r13
    c.r[1] = c.r[12];  // 06023820 mov r12,r1
    c.r[1] -= 1;  // 06023822 add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023824 extu.b r1,r1
    st32(c.r[14] + 44, c.r[1]); goto L_0602382C;  // 06023826 bra 0x0602382C ; mov.l r1,@(44,r14)
L_0602382A:
    st32(c.r[14] + 44, c.r[13]);  // 0602382A mov.l r13,@(44,r14)
L_0602382C:
    c.r[13] = 0x2Eu;  // 0602382C mov #46,r13
    c.r[0] = ld32(c.r[14] + 44);  // 0602382E mov.l @(44,r14),r0
    c.r[13] += c.r[14];  // 06023830 add r14,r13
    c.r[12] = ld32(c.r[14] + 48);  // 06023832 mov.l @(48,r14),r12
    c.r[0] <<= 8;  // 06023834 shll8 r0
    c.r[0] |= c.r[12];  // 06023836 or r12,r0
    st32(c.r[14] + 44, c.r[0]);  // 06023838 mov.l r0,@(44,r14)
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0602383A mov.w @r13,r13
    c.r[1] = c.r[13] & 0xFFFFu;  // 0602383C extu.w r13,r1
    c.r[0] = c.r[1]; goto L_06023844;  // 0602383E bra 0x06023844 ; mov r1,r0
L_06023842:
    c.r[0] = ld32(0x06023864u);  // 06023842 mov.l 0x06023864,r0
L_06023844:
    c.r[14] += 76;  // 06023844 add #76,r14
    c.r[15] = c.r[14];  // 06023846 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06023848 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602384A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602384C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602384E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06023850 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06023852 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06023854 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06023856 rts ; mov.l @r15+,r8
}

void f_06023868(SH2Context& c) {
    ran[449] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023868 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602386A sts.l pr,@-r15
    c.r[1] = ld32(0x06023888u);  // 0602386C mov.l 0x06023888,r1
    c.r[1] = ld32(c.r[1]);  // 0602386E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023870 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06023872 extu.b r1,r0
    c.r[0] <<= 2;  // 06023874 shll2 r0
    c.r[1] = ld32(0x0602388Cu);  // 06023876 mov.l 0x0602388C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06023878 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602387Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602387Eu) return; }  // 0602387A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602387E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06023880 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06023882 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06023884 rts ; extu.w r0,r0
}

void f_06023890(SH2Context& c) {
    ran[450] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06023890 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023892 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06023894 sts.l pr,@-r15
    c.r[1] = ld32(0x06023968u);  // 06023896 mov.l 0x06023968,r1
    c.r[1] = ld32(c.r[1]);  // 06023898 mov.l @r1,r1
    c.r[1] += 1;  // 0602389A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602389C mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0602389E extu.b r1,r8
    c.r[0] = c.r[8];  // 060238A0 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 060238A2 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060238D4; } }  // 060238A4 bt/s 0x060238D4 ; mov r15,r14
    c.r[1] = 0x1u;  // 060238A8 mov #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060238AA cmp/gt r1,r8
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_060238BA; } }  // 060238AC bt/s 0x060238BA ; cmp/eq #2,r0
    c.t = (c.r[8] & c.r[8]) == 0;  // 060238B0 tst r8,r8
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_060238C2; } }  // 060238B2 bt/s 0x060238C2 ; mov #0,r6
    c.r[15] = c.r[14]; goto L_0602395A;  // 060238B6 bra 0x0602395A ; mov r14,r15
L_060238BA:
    if (c.t) { goto L_06023940; }  // 060238BA bt 0x06023940
    c.r[15] = c.r[14];  // 060238BC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0602395C;  // 060238BE bra 0x0602395C ; lds.l @r15+,pr
L_060238C2:
    c.r[4] = ld32(0x0602396Cu);  // 060238C2 mov.l 0x0602396C,r4
    c.r[0] = ld32(0x06023970u);  // 060238C4 mov.l 0x06023970,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060238CAu; c.r[5] = 0xFFFFFFF9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060238CAu) return; }  // 060238C6 jsr @r0 ; mov #-7,r5
    c.r[1] = ld32(0x06023974u);  // 060238CA mov.l 0x06023974,r1
    st32(c.r[1], c.r[0]);  // 060238CC mov.l r0,@r1
    c.r[1] = ld32(0x06023978u);  // 060238CE mov.l 0x06023978,r1
    st32(c.r[1], c.r[8]); goto L_06023958;  // 060238D0 bra 0x06023958 ; mov.l r8,@r1
L_060238D4:
    c.r[1] = ld32(0x0602397Cu);  // 060238D4 mov.l 0x0602397C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060238DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060238DAu) return; }  // 060238D6 jsr @r1 ; nop
    c.r[2] = ld32(0x06023978u);  // 060238DA mov.l 0x06023978,r2
    c.r[0] = ld32(c.r[2]);  // 060238DC mov.l @r2,r0
    c.r[1] = c.r[0];  // 060238DE mov r0,r1
    c.r[1] += 1;  // 060238E0 add #1,r1
    st32(c.r[2], c.r[1]);  // 060238E2 mov.l r1,@r2
    c.r[1] = ld32(0x0602396Cu);  // 060238E4 mov.l 0x0602396C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060238E6 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x06023980u);  // 060238E8 mov.l 0x06023980,r3
    c.r[2] = c.r[1] & 0xFFu;  // 060238EA extu.b r1,r2
    st32(c.r[3], c.r[2]);  // 060238EC mov.l r2,@r3
    c.r[1] = ld32(0x06023984u);  // 060238EE mov.l 0x06023984,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060238F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060238F2 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060238F4 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0602393A; } }  // 060238F6 bt/s 0x0602393A ; shll2 r2
    c.r[1] = ld32(0x06023988u);  // 060238FA mov.l 0x06023988,r1
    c.r[1] = ld32(c.r[1]);  // 060238FC mov.l @r1,r1
    c.r[2] <<= 2;  // 060238FE shll2 r2
    c.r[2] += c.r[1];  // 06023900 add r1,r2
    c.r[1] = c.r[2];  // 06023902 mov r2,r1
    c.r[1] += 11;  // 06023904 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023906 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023908 extu.b r1,r1
    c.r[1] >>= 2;  // 0602390A shlr2 r1
    c.r[1] >>= 2;  // 0602390C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602390E shlr r1
    c.r[1] >>= 2;  // 06023910 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06023912 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602393A; } }  // 06023914 bf/s 0x0602393A ; mov r2,r1
    c.r[1] += 3;  // 06023918 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602391A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602391C mov r1,r0
    c.r[0] >>= 2;  // 0602391E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06023920 shlr r0
    c.r[0] &= 0x3u;  // 06023922 and #3,r0
    c.t = c.r[0] == 0x2u;  // 06023924 cmp/eq #2,r0
    { const bool k = c.t; c.r[2] += 4; if (k) { goto L_0602393A; } }  // 06023926 bt/s 0x0602393A ; add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602392A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0602392C mov r1,r0
    c.r[0] >>= 2;  // 0602392E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06023930 shlr r0
    c.r[0] >>= 2;  // 06023932 shlr2 r0
    c.r[0] &= 0x1u;  // 06023934 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06023936 tst r0,r0
    if (c.t) { goto L_06023958; }  // 06023938 bt 0x06023958
L_0602393A:
    c.r[1] = ld32(0x0602398Cu);  // 0602393A mov.l 0x0602398C,r1
    goto L_06023954;  // 0602393C bra 0x06023954 ; nop
L_06023940:
    c.r[1] = ld32(0x0602398Cu);  // 06023940 mov.l 0x0602398C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06023946u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023946u) return; }  // 06023942 jsr @r1 ; nop
    c.r[1] = ld32(0x06023974u);  // 06023946 mov.l 0x06023974,r1
    c.r[3] = ld32(c.r[1]);  // 06023948 mov.l @r1,r3
    c.r[2] = ld32(0x06023978u);  // 0602394A mov.l 0x06023978,r2
    c.r[1] = ld32(c.r[2]);  // 0602394C mov.l @r2,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602394E cmp/gt r1,r3
    if (c.t) { goto L_06023958; }  // 06023950 bt 0x06023958
    c.r[1] = ld32(0x0602397Cu);  // 06023952 mov.l 0x0602397C,r1
L_06023954:
    { const uint32_t x = c.r[1]; c.pr = 0x06023958u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023958u) return; }  // 06023954 jsr @r1 ; nop
L_06023958:
    c.r[15] = c.r[14];  // 06023958 mov r14,r15
L_0602395A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602395A lds.l @r15+,pr
L_0602395C:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602395C mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06023964u);  // 0602395E mov.w 0x06023964,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06023960 rts ; mov.l @r15+,r8
}

void f_06023990(SH2Context& c) {
    ran[451] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06023990 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06023992 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06023994 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06023996 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06023998 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602399A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602399C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602399E sts.l pr,@-r15
    c.r[15] -= 16;  // 060239A0 add #-16,r15
    c.r[14] = c.r[15];  // 060239A2 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060239FCu);  // 060239A4 mov.w 0x060239FC,r0
    st32(c.r[14] + 12, c.r[0]);  // 060239A6 mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 060239A8 mov.l @(12,r14),r0
    c.r[1] = ld32(0x06023A00u);  // 060239AA mov.l 0x06023A00,r1
    c.r[1] = ld32(c.r[1]);  // 060239AC mov.l @r1,r1
    st32(c.r[14] + 8, c.r[0]);  // 060239AE mov.l r0,@(8,r14)
    c.r[1] += 1;  // 060239B0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060239B2 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060239B4 extu.b r1,r2
    c.r[1] = 0x5u;  // 060239B6 mov #5,r1
    c.t = c.r[2] > c.r[1];  // 060239B8 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060239C2; } }  // 060239BA bf/s 0x060239C2 ; mov r2,r1
    goto L_06023DB4;  // 060239BE bra 0x06023DB4 ; nop
L_060239C2:
    c.r[1] += c.r[1];  // 060239C2 add r1,r1
    c.r[0] = 0x060239D0u;  // 060239C4 mova 0x060239D0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060239C6 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060239C8 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060239DCu: goto L_060239DC; case 0x06023A08u: goto L_06023A08; case 0x06023C40u: goto L_06023C40; case 0x06023C8Au: goto L_06023C8A; case 0x06023CB6u: goto L_06023CB6; case 0x06023D94u: goto L_06023D94; default: sh2_call(c, x); return; } }  // 060239CA jmp @r0 ; nop
L_060239DC:
    c.r[3] = ld32(0x06023A04u);  // 060239DC mov.l 0x06023A04,r3
    c.r[2] = 0xFFFFFFFFu;  // 060239DE mov #-1,r2
    st8(c.r[3], c.r[2]);  // 060239E0 mov.b r2,@r3
    c.r[1] = c.r[3];  // 060239E2 mov r3,r1
    c.r[1] += 1;  // 060239E4 add #1,r1
    st8(c.r[1], c.r[2]);  // 060239E6 mov.b r2,@r1
    c.r[7] = c.r[3];  // 060239E8 mov r3,r7
    c.r[7] += 2;  // 060239EA add #2,r7
    c.r[1] = c.r[3];  // 060239EC mov r3,r1
    c.r[1] += 3;  // 060239EE add #3,r1
    st8(c.r[1], c.r[2]);  // 060239F0 mov.b r2,@r1
    st8(c.r[7], c.r[2]);  // 060239F2 mov.b r2,@r7
    c.r[1] = 0xFFFFFFFFu;  // 060239F4 mov #-1,r1
    st32(c.r[3] + 8, c.r[1]);  // 060239F6 mov.l r1,@(8,r3)
    st32(c.r[3] + 4, c.r[1]); goto L_06023DB4;  // 060239F8 bra 0x06023DB4 ; mov.l r1,@(4,r3)
L_06023A08:
    c.r[1] = ld32(0x06023BECu);  // 06023A08 mov.l 0x06023BEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06023A0Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023A0Eu) return; }  // 06023A0A jsr @r1 ; nop
    c.r[10] = ld32(0x06023BF0u);  // 06023A0E mov.l 0x06023BF0,r10
    c.r[1] = ld32(c.r[10]);  // 06023A10 mov.l @r10,r1
    c.r[1] += 36;  // 06023A12 add #36,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023A14 mov.b @r1,r1
    c.r[2] = ld32(0x06023BF4u);  // 06023A16 mov.l 0x06023BF4,r2
    st8(c.r[2], c.r[1]);  // 06023A18 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06023A1A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06023A1C tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06023A26; } }  // 06023A1E bf/s 0x06023A26 ; mov #0,r1
    goto L_06023C38;  // 06023A22 bra 0x06023C38 ; nop
L_06023A26:
    c.r[9] = ld32(0x06023BF8u);  // 06023A26 mov.l 0x06023BF8,r9
    st32(c.r[9], c.r[1]);  // 06023A28 mov.l r1,@r9
    c.r[8] = ld32(0x06023BFCu);  // 06023A2A mov.l 0x06023BFC,r8
    c.r[2] = ld32(c.r[8]);  // 06023A2C mov.l @r8,r2
    c.r[1] = ld32(0x06023C00u);  // 06023A2E mov.l 0x06023C00,r1
    c.r[3] = ld32(c.r[1]);  // 06023A30 mov.l @r1,r3
    c.r[2] <<= 2;  // 06023A32 shll2 r2
    c.r[2] <<= 2;  // 06023A34 shll2 r2
    c.r[1] = c.r[2];  // 06023A36 mov r2,r1
    c.r[1] += c.r[3];  // 06023A38 add r3,r1
    c.r[1] += 1;  // 06023A3A add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023A3C mov.b @r1,r7
    c.r[0] = c.r[2];  // 06023A3E mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06023A40 mov.b @(r0,r3),r6
    c.r[7] = c.r[7] & 0xFFu;  // 06023A42 extu.b r7,r7
    c.r[1] = ld32(0x06023C04u);  // 06023A44 mov.l 0x06023C04,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023A46 mov.b @r1,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06023A48 extu.b r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06023A4A extu.b r1,r1
    c.r[1] <<= 2;  // 06023A4C shll2 r1
    c.r[1] <<= 2;  // 06023A4E shll2 r1
    c.r[2] = c.r[1];  // 06023A50 mov r1,r2
    c.r[2] += c.r[3];  // 06023A52 add r3,r2
    c.r[2] += 1;  // 06023A54 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023A56 mov.b @r2,r5
    c.r[0] = c.r[1];  // 06023A58 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06023A5A mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06023A5C extu.b r5,r5
    c.r[0] = ld32(0x06023C08u);  // 06023A5E mov.l 0x06023C08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06023A64u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023A64u) return; }  // 06023A60 jsr @r0 ; extu.b r4,r4
    c.t = c.r[0] == 0x1u;  // 06023A64 cmp/eq #1,r0
    { const bool k = !c.t; st32(c.r[14], c.r[0]); if (k) { goto L_06023A6E; } }  // 06023A66 bf/s 0x06023A6E ; mov.l r0,@r14
    goto L_06023C38;  // 06023A6A bra 0x06023C38 ; nop
L_06023A6E:
    c.r[1] = ld32(0x06023C0Cu);  // 06023A6E mov.l 0x06023C0C,r1
    c.r[1] = ld32(c.r[1]);  // 06023A70 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06023BE8u);  // 06023A72 mov.w 0x06023BE8,r2
    c.r[0] = c.r[1];  // 06023A74 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06023A76 mov.b @(r0,r2),r1
    c.r[11] = 0x0u;  // 06023A78 mov #0,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06023A7A extu.b r1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06023A7C cmp/ge r1,r11
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[1]); if (k) { goto L_06023A86; } }  // 06023A7E bf/s 0x06023A86 ; mov.l r1,@(4,r14)
    goto L_06023C38;  // 06023A82 bra 0x06023C38 ; nop
L_06023A86:
    c.r[13] = ld32(0x06023C10u);  // 06023A86 mov.l 0x06023C10,r13
    c.r[12] = c.r[9];  // 06023A88 mov r9,r12
L_06023A8A:
    c.r[1] = ld32(0x06023C0Cu);  // 06023A8A mov.l 0x06023C0C,r1
    c.r[2] = c.r[11];  // 06023A8C mov r11,r2
    c.r[1] = ld32(c.r[1]);  // 06023A8E mov.l @r1,r1
    c.r[2] += c.r[2];  // 06023A90 add r2,r2
    c.r[0] = c.r[1];  // 06023A92 mov r1,r0
    c.r[1] += c.r[2];  // 06023A94 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06023A96 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06023A98 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023A9A mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 06023A9C mov #127,r0
    c.r[3] &= c.r[0];  // 06023A9E and r0,r3
    c.r[3] <<= 8;  // 06023AA0 shll8 r3
    c.r[8] = c.r[1] & 0xFFu;  // 06023AA2 extu.b r1,r8
    c.r[8] |= c.r[3];  // 06023AA4 or r3,r8
    c.r[0] = ld32(0x06023BF0u);  // 06023AA6 mov.l 0x06023BF0,r0
    c.r[1] = c.r[8];  // 06023AA8 mov r8,r1
    c.r[1] <<= 2;  // 06023AAA shll2 r1
    c.r[1] += c.r[8];  // 06023AAC add r8,r1
    c.r[2] = ld32(c.r[0]);  // 06023AAE mov.l @r0,r2
    c.r[1] <<= 2;  // 06023AB0 shll2 r1
    c.r[2] += c.r[1];  // 06023AB2 add r1,r2
    c.r[1] = c.r[2];  // 06023AB4 mov r2,r1
    c.r[1] += 62;  // 06023AB6 add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023AB8 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06023ABA extu.b r1,r7
    c.r[1] = ld32(0x06023BF4u);  // 06023ABC mov.l 0x06023BF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023ABE mov.b @r1,r1
    c.r[0] = ld32(c.r[14]);  // 06023AC0 mov.l @r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06023AC2 extu.b r1,r1
    c.r[1] += c.r[7];  // 06023AC4 add r7,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 06023AC6 cmp/ge r0,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06023AD0; } }  // 06023AC8 bt/s 0x06023AD0 ; mov.l @(4,r14),r0
    goto L_06023BE4;  // 06023ACC bra 0x06023BE4 ; nop
L_06023AD0:
    c.r[1] = 0x11u;  // 06023AD0 mov #17,r1
    c.t = c.r[7] > c.r[1];  // 06023AD2 cmp/hi r1,r7
    { const bool k = !c.t; c.r[2] += 51; if (k) { goto L_06023ADC; } }  // 06023AD4 bf/s 0x06023ADC ; add #51,r2
    goto L_06023BE4;  // 06023AD8 bra 0x06023BE4 ; nop
L_06023ADC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023ADC mov.b @r2,r1
    c.r[0] = c.r[1];  // 06023ADE mov r1,r0
    c.r[0] >>= 2;  // 06023AE0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06023AE2 shlr r0
    c.r[0] >>= 2;  // 06023AE4 shlr2 r0
    c.r[0] &= 0x1u;  // 06023AE6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06023AE8 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06023BE4; } }  // 06023AEA bt/s 0x06023BE4 ; mov.l @(4,r14),r0
    c.r[1] = ld32(0x06023BFCu);  // 06023AEE mov.l 0x06023BFC,r1
    c.r[3] = ld32(c.r[1]);  // 06023AF0 mov.l @r1,r3
    c.r[4] = ld32(0x06023C14u);  // 06023AF2 mov.l 0x06023C14,r4
    c.r[1] = ld32(0x06023C00u);  // 06023AF4 mov.l 0x06023C00,r1
    c.r[2] = ld32(c.r[1]);  // 06023AF6 mov.l @r1,r2
    c.r[3] <<= 2;  // 06023AF8 shll2 r3
    c.r[3] <<= 2;  // 06023AFA shll2 r3
    c.r[1] = c.r[3];  // 06023AFC mov r3,r1
    c.r[1] += c.r[2];  // 06023AFE add r2,r1
    c.r[1] += 1;  // 06023B00 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023B02 mov.b @r1,r6
    c.r[0] = c.r[3];  // 06023B04 mov r3,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06023B06 mov.b @(r0,r2),r5
    c.r[6] = c.r[6] & 0xFFu;  // 06023B08 extu.b r6,r6
    c.r[0] = 0x1u;  // 06023B0A mov #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06023B0C mov.l r0,@-r15
    c.r[0] = ld32(0x06023C18u);  // 06023B0E mov.l 0x06023C18,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06023B14u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023B14u) return; }  // 06023B10 jsr @r0 ; extu.b r5,r5
    c.r[1] = c.r[0];  // 06023B14 mov r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06023B16 extu.b r1,r5
    c.r[6] = ld32(0x06023C1Cu);  // 06023B18 mov.l 0x06023C1C,r6
    c.r[1] = 0x1u;  // 06023B1A mov #1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[5];  // 06023B1C cmp/ge r5,r1
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06023B98; } }  // 06023B1E bt/s 0x06023B98 ; add #4,r15
    c.r[0] = ld32(0x06023BF0u);  // 06023B22 mov.l 0x06023BF0,r0
    c.r[1] = ld32(c.r[0]);  // 06023B24 mov.l @r0,r1
    c.r[1] += 24;  // 06023B26 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06023B28 mov.w @r1,r1
    c.r[3] = ld32(0x06023C14u);  // 06023B2A mov.l 0x06023C14,r3
    c.r[4] = c.r[1] & 0xFFFFu;  // 06023B2C extu.w r1,r4
    c.r[1] = 0x2u;  // 06023B2E mov #2,r1
    c.r[3] += c.r[1];  // 06023B30 add r1,r3
    c.r[7] = c.r[1];  // 06023B32 mov r1,r7
    c.r[0] = ld32(0x06023C14u);  // 06023B34 mov.l 0x06023C14,r0
L_06023B36:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06023B36 mov.b @(r0,r7),r1
    c.r[10] = c.r[1] & 0xFFu;  // 06023B38 extu.b r1,r10
    c.r[1] = c.r[3];  // 06023B3A mov r3,r1
    c.r[1] += 1;  // 06023B3C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023B3E mov.b @r1,r1
    c.r[0] = ld32(0x06023C20u);  // 06023B40 mov.l 0x06023C20,r0
    c.r[9] = c.r[1] & 0xFFu;  // 06023B42 extu.b r1,r9
    c.r[1] = c.r[10];  // 06023B44 mov r10,r1
    c.r[1] += c.r[1];  // 06023B46 add r1,r1
    c.r[2] = c.r[9];  // 06023B48 mov r9,r2
    c.r[2] <<= 2;  // 06023B4A shll2 r2
    c.r[2] <<= 2;  // 06023B4C shll2 r2
    c.r[2] += c.r[2];  // 06023B4E add r2,r2
    c.r[2] <<= 2;  // 06023B50 shll2 r2
    c.r[2] += c.r[0];  // 06023B52 add r0,r2
    c.r[0] = c.r[1];  // 06023B54 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06023B56 mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06023B58 extu.w r1,r2
    c.r[1] = c.r[9];  // 06023B5A mov r9,r1
    c.r[1] <<= 2;  // 06023B5C shll2 r1
    c.r[1] <<= 2;  // 06023B5E shll2 r1
    c.r[1] <<= 2;  // 06023B60 shll2 r1
    c.r[0] = ld32(0x06023C24u);  // 06023B62 mov.l 0x06023C24,r0
    c.r[1] += c.r[0];  // 06023B64 add r0,r1
    c.r[0] = c.r[1];  // 06023B66 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06023B68 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023B6A extu.b r1,r1
    c.t = c.r[4] >= c.r[1];  // 06023B6C cmp/hs r1,r4
    if (!c.t) { goto L_06023B88; }  // 06023B6E bf 0x06023B88
    c.r[1] = ld32(0x06023BF4u);  // 06023B70 mov.l 0x06023BF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023B72 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023B74 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06023B76 cmp/hi r1,r2
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06023B88; } }  // 06023B78 bt/s 0x06023B88 ; tst r2,r2
    { const bool k = c.t; c.t = c.r[6] > c.r[2]; if (k) { goto L_06023B88; } }  // 06023B7C bt/s 0x06023B88 ; cmp/hi r2,r6
    if (!c.t) { goto L_06023B88; }  // 06023B80 bf 0x06023B88
    c.r[6] = c.r[2];  // 06023B82 mov r2,r6
    st32(c.r[14] + 8, c.r[10]);  // 06023B84 mov.l r10,@(8,r14)
    st32(c.r[14] + 12, c.r[9]);  // 06023B86 mov.l r9,@(12,r14)
L_06023B88:
    c.r[3] += 2;  // 06023B88 add #2,r3
    c.r[1] = c.r[5];  // 06023B8A mov r5,r1
    c.r[1] += c.r[1];  // 06023B8C add r1,r1
    c.r[0] = ld32(0x06023C14u);  // 06023B8E mov.l 0x06023C14,r0
    c.r[1] += c.r[0];  // 06023B90 add r0,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06023B92 cmp/ge r1,r3
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06023B36; } }  // 06023B94 bf/s 0x06023B36 ; add #2,r7
L_06023B98:
    c.r[1] = ld32(0x06023C1Cu);  // 06023B98 mov.l 0x06023C1C,r1
    c.t = c.r[6] == c.r[1];  // 06023B9A cmp/eq r1,r6
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06023BE4; } }  // 06023B9C bt/s 0x06023BE4 ; mov.l @(4,r14),r0
    c.r[1] = ld32(0x06023C28u);  // 06023BA0 mov.l 0x06023C28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06023BA6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023BA6u) return; }  // 06023BA2 jsr @r1 ; nop
    c.r[2] = ld32(c.r[12]);  // 06023BA6 mov.l @r12,r2
    c.r[0] = ld32(0x06023C2Cu);  // 06023BA8 mov.l 0x06023C2C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023BAA mov.b @r0,r1
    c.r[2] <<= 2;  // 06023BAC shll2 r2
    c.r[0] = c.r[13];  // 06023BAE mov r13,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06023BB0 mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[12]);  // 06023BB2 mov.l @r12,r1
    c.r[0] = 0xBu;  // 06023BB4 mov #11,r0
    c.r[1] <<= 2;  // 06023BB6 shll2 r1
    c.r[1] += c.r[13];  // 06023BB8 add r13,r1
    c.r[1] += 1;  // 06023BBA add #1,r1
    st8(c.r[1], c.r[8]);  // 06023BBC mov.b r8,@r1
    c.r[1] = ld32(c.r[12]);  // 06023BBE mov.l @r12,r1
    c.r[0] += c.r[14];  // 06023BC0 add r14,r0
    c.r[1] <<= 2;  // 06023BC2 shll2 r1
    c.r[1] += c.r[13];  // 06023BC4 add r13,r1
    c.r[1] += 2;  // 06023BC6 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023BC8 mov.b @r0,r0
    st8(c.r[1], c.r[0]);  // 06023BCA mov.b r0,@r1
    c.r[0] = 0xFu;  // 06023BCC mov #15,r0
    c.r[1] = ld32(c.r[12]);  // 06023BCE mov.l @r12,r1
    c.r[0] += c.r[14];  // 06023BD0 add r14,r0
    c.r[1] <<= 2;  // 06023BD2 shll2 r1
    c.r[1] += c.r[13];  // 06023BD4 add r13,r1
    c.r[1] += 3;  // 06023BD6 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023BD8 mov.b @r0,r0
    st8(c.r[1], c.r[0]);  // 06023BDA mov.b r0,@r1
    c.r[1] = ld32(c.r[12]);  // 06023BDC mov.l @r12,r1
    c.r[1] += 1;  // 06023BDE add #1,r1
    st32(c.r[12], c.r[1]);  // 06023BE0 mov.l r1,@r12
    c.r[0] = ld32(c.r[14] + 4);  // 06023BE2 mov.l @(4,r14),r0
L_06023BE4:
    c.r[11] += 1; goto L_06023C30;  // 06023BE4 bra 0x06023C30 ; add #1,r11
L_06023C30:
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[0];  // 06023C30 cmp/ge r0,r11
    if (c.t) { goto L_06023C38; }  // 06023C32 bt 0x06023C38
    SH2_POLL(c); goto L_06023A8A;  // 06023C34 bra 0x06023A8A ; nop
L_06023C38:
    c.r[2] = ld32(0x06023DD0u);  // 06023C38 mov.l 0x06023DD0,r2
    c.r[1] = 0x0u;  // 06023C3A mov #0,r1
    st32(c.r[2], c.r[1]); goto L_06023DB4;  // 06023C3C bra 0x06023DB4 ; mov.l r1,@r2
L_06023C40:
    c.r[2] = ld32(0x06023DD4u);  // 06023C40 mov.l 0x06023DD4,r2
    c.r[0] = ld32(0x06023DD8u);  // 06023C42 mov.l 0x06023DD8,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023C44 mov.b @r0,r3
    c.r[4] = ld32(0x06023DDCu);  // 06023C46 mov.l 0x06023DDC,r4
    c.r[7] = ld32(c.r[4]);  // 06023C48 mov.l @r4,r7
    c.r[3] = c.r[3] & 0xFFu;  // 06023C4A extu.b r3,r3
    c.r[3] <<= 2;  // 06023C4C shll2 r3
    c.r[3] <<= 2;  // 06023C4E shll2 r3
    c.r[6] = c.r[3];  // 06023C50 mov r3,r6
    c.r[6] += c.r[7];  // 06023C52 add r7,r6
    c.r[0] = c.r[3];  // 06023C54 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06023C56 mov.b @(r0,r7),r1
    c.r[6] += 1;  // 06023C58 add #1,r6
    st8(c.r[2], c.r[1]);  // 06023C5A mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06023C5C mov.b @r6,r1
    c.r[2] = ld32(0x06023DE0u);  // 06023C5E mov.l 0x06023DE0,r2
    st8(c.r[2], c.r[1]);  // 06023C60 mov.b r1,@r2
    c.r[6] = ld32(0x06023DD0u);  // 06023C62 mov.l 0x06023DD0,r6
    c.r[1] = ld32(c.r[6]);  // 06023C64 mov.l @r6,r1
    c.r[5] = ld32(0x06023DE4u);  // 06023C66 mov.l 0x06023DE4,r5
    c.r[1] <<= 2;  // 06023C68 shll2 r1
    c.r[1] += c.r[5];  // 06023C6A add r5,r1
    c.r[1] += 2;  // 06023C6C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023C6E mov.b @r1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06023C70 mov.b r1,@(r0,r7)
    c.r[0] = ld32(0x06023DD8u);  // 06023C72 mov.l 0x06023DD8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06023C74 mov.b @r0,r2
    c.r[1] = ld32(c.r[4]);  // 06023C76 mov.l @r4,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06023C78 extu.b r2,r2
    c.r[2] <<= 2;  // 06023C7A shll2 r2
    c.r[2] <<= 2;  // 06023C7C shll2 r2
    c.r[2] += c.r[1];  // 06023C7E add r1,r2
    c.r[1] = ld32(c.r[6]);  // 06023C80 mov.l @r6,r1
    c.r[1] <<= 2;  // 06023C82 shll2 r1
    c.r[1] += c.r[5];  // 06023C84 add r5,r1
    c.r[1] += 3; goto L_06023CAE;  // 06023C86 bra 0x06023CAE ; add #3,r1
L_06023C8A:
    c.r[6] = ld32(0x06023DD8u);  // 06023C8A mov.l 0x06023DD8,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06023C8C mov.b @r6,r2
    c.r[7] = ld32(0x06023DDCu);  // 06023C8E mov.l 0x06023DDC,r7
    c.r[3] = ld32(c.r[7]);  // 06023C90 mov.l @r7,r3
    c.r[1] = ld32(0x06023DD4u);  // 06023C92 mov.l 0x06023DD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023C94 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06023C96 extu.b r2,r2
    c.r[2] <<= 2;  // 06023C98 shll2 r2
    c.r[2] <<= 2;  // 06023C9A shll2 r2
    c.r[0] = c.r[2];  // 06023C9C mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06023C9E mov.b r1,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06023CA0 mov.b @r6,r2
    c.r[1] = ld32(c.r[7]);  // 06023CA2 mov.l @r7,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06023CA4 extu.b r2,r2
    c.r[2] <<= 2;  // 06023CA6 shll2 r2
    c.r[2] <<= 2;  // 06023CA8 shll2 r2
    c.r[2] += c.r[1];  // 06023CAA add r1,r2
    c.r[1] = ld32(0x06023DE0u);  // 06023CAC mov.l 0x06023DE0,r1
L_06023CAE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023CAE mov.b @r1,r1
    c.r[2] += 1;  // 06023CB0 add #1,r2
    st8(c.r[2], c.r[1]); goto L_06023DB4;  // 06023CB2 bra 0x06023DB4 ; mov.b r1,@r2
L_06023CB6:
    c.r[1] = ld32(0x06023DE8u);  // 06023CB6 mov.l 0x06023DE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06023CBCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023CBCu) return; }  // 06023CB8 jsr @r1 ; nop
    c.r[7] = ld32(0x06023DE4u);  // 06023CBC mov.l 0x06023DE4,r7
    c.r[13] = ld32(0x06023DD0u);  // 06023CBE mov.l 0x06023DD0,r13
    c.r[3] = ld32(0x06023DECu);  // 06023CC0 mov.l 0x06023DEC,r3
    c.r[6] = ld32(c.r[13]);  // 06023CC2 mov.l @r13,r6
    c.r[0] = c.r[7];  // 06023CC4 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023CC6 mov.b @r3,r1
    c.r[6] <<= 2;  // 06023CC8 shll2 r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06023CCA mov.b @(r0,r6),r2
    c.r[1] = c.r[1] & 0xFFu;  // 06023CCC extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06023CCE extu.b r2,r2
    c.t = c.r[2] == c.r[1];  // 06023CD0 cmp/eq r1,r2
    if (!c.t) { goto L_06023D7A; }  // 06023CD2 bf 0x06023D7A
    c.r[1] = ld32(c.r[3] + 4);  // 06023CD4 mov.l @(4,r3),r1
    c.r[11] = ld32(0x06023DF0u);  // 06023CD6 mov.l 0x06023DF0,r11
    c.r[2] = ld32(c.r[11] + 4);  // 06023CD8 mov.l @(4,r11),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06023CDA cmp/ge r2,r1
    { const bool k = !c.t; c.t = c.r[1] == c.r[2]; if (k) { goto L_06023D7A; } }  // 06023CDC bf/s 0x06023D7A ; cmp/eq r2,r1
    if (!c.t) { goto L_06023D44; }  // 06023CE0 bf 0x06023D44
    c.r[1] = ld32(0x06023DD8u);  // 06023CE2 mov.l 0x06023DD8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023CE4 mov.b @r1,r2
    c.r[8] = ld32(0x06023DF4u);  // 06023CE6 mov.l 0x06023DF4,r8
    c.r[2] = c.r[2] & 0xFFu;  // 06023CE8 extu.b r2,r2
    c.r[1] = ld32(0x06023DDCu);  // 06023CEA mov.l 0x06023DDC,r1
    c.r[2] <<= 2;  // 06023CEC shll2 r2
    c.r[2] <<= 2;  // 06023CEE shll2 r2
    c.r[3] = c.r[2];  // 06023CF0 mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 06023CF2 mov.l @r1,r1
    c.r[0] = c.r[2];  // 06023CF4 mov r2,r0
    c.r[3] += c.r[1];  // 06023CF6 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06023CF8 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 06023CFA add #1,r3
    c.r[10] = c.r[1] & 0xFFu;  // 06023CFC extu.b r1,r10
    c.r[2] = c.r[6];  // 06023CFE mov r6,r2
    c.r[2] += c.r[7];  // 06023D00 add r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023D02 mov.b @r3,r1
    c.r[4] = c.r[10];  // 06023D04 mov r10,r4
    c.r[9] = c.r[1] & 0xFFu;  // 06023D06 extu.b r1,r9
    c.r[1] = c.r[2];  // 06023D08 mov r2,r1
    c.r[1] += 3;  // 06023D0A add #3,r1
    c.r[2] += 2;  // 06023D0C add #2,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023D0E mov.b @r1,r7
    c.r[5] = c.r[9];  // 06023D10 mov r9,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023D12 mov.b @r2,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06023D14 extu.b r7,r7
    { const uint32_t x = c.r[8]; c.pr = 0x06023D1Au; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023D1Au) return; }  // 06023D16 jsr @r8 ; extu.b r6,r6
    c.r[12] = c.r[0];  // 06023D1A mov r0,r12
    c.r[1] = c.r[11];  // 06023D1C mov r11,r1
    c.r[1] += 3;  // 06023D1E add #3,r1
    c.r[11] += 2;  // 06023D20 add #2,r11
    c.r[5] = c.r[9];  // 06023D22 mov r9,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023D24 mov.b @r1,r7
    c.r[4] = c.r[10];  // 06023D26 mov r10,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06023D28 mov.b @r11,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06023D2A extu.b r7,r7
    { const uint32_t x = c.r[8]; c.pr = 0x06023D30u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023D30u) return; }  // 06023D2C jsr @r8 ; extu.b r6,r6
    c.r[1] = c.r[0];  // 06023D30 mov r0,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 06023D32 cmp/ge r1,r12
    if (!c.t) { goto L_06023D44; }  // 06023D34 bf 0x06023D44
    c.r[1] = ld32(c.r[13]);  // 06023D36 mov.l @r13,r1
    c.r[2] = ld32(0x06023DF8u);  // 06023D38 mov.l 0x06023DF8,r2
    c.r[1] += 1;  // 06023D3A add #1,r1
    st32(c.r[13], c.r[1]);  // 06023D3C mov.l r1,@r13
    c.r[2] = ld32(c.r[2]);  // 06023D3E mov.l @r2,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2]; goto L_06023D88;  // 06023D40 bra 0x06023D88 ; cmp/ge r2,r1
L_06023D44:
    c.r[7] = ld32(0x06023DF0u);  // 06023D44 mov.l 0x06023DF0,r7
    c.r[2] = ld32(0x06023DECu);  // 06023D46 mov.l 0x06023DEC,r2
    c.r[1] = ld32(c.r[2] + 4);  // 06023D48 mov.l @(4,r2),r1
    c.r[3] = c.r[7];  // 06023D4A mov r7,r3
    st32(c.r[7] + 4, c.r[1]);  // 06023D4C mov.l r1,@(4,r7)
    c.r[1] = ld32(c.r[2] + 8);  // 06023D4E mov.l @(8,r2),r1
    c.r[3] += 1;  // 06023D50 add #1,r3
    st32(c.r[7] + 8, c.r[1]);  // 06023D52 mov.l r1,@(8,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06023D54 mov.b @r2+,r1
    c.r[6] = c.r[7];  // 06023D56 mov r7,r6
    st8(c.r[7], c.r[1]);  // 06023D58 mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023D5A mov.b @r2,r1
    c.r[6] += 2;  // 06023D5C add #2,r6
    st8(c.r[3], c.r[1]);  // 06023D5E mov.b r1,@r3
    c.r[1] = ld32(0x06023DD0u);  // 06023D60 mov.l 0x06023DD0,r1
    c.r[3] = ld32(c.r[1]);  // 06023D62 mov.l @r1,r3
    c.r[2] = ld32(0x06023DE4u);  // 06023D64 mov.l 0x06023DE4,r2
    c.r[3] <<= 2;  // 06023D66 shll2 r3
    c.r[3] += c.r[2];  // 06023D68 add r2,r3
    c.r[1] = c.r[3];  // 06023D6A mov r3,r1
    c.r[1] += 2;  // 06023D6C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023D6E mov.b @r1,r1
    c.r[3] += 3;  // 06023D70 add #3,r3
    st8(c.r[6], c.r[1]);  // 06023D72 mov.b r1,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023D74 mov.b @r3,r1
    c.r[7] += 3;  // 06023D76 add #3,r7
    st8(c.r[7], c.r[1]);  // 06023D78 mov.b r1,@r7
L_06023D7A:
    c.r[1] = ld32(0x06023DD0u);  // 06023D7A mov.l 0x06023DD0,r1
    c.r[2] = ld32(c.r[1]);  // 06023D7C mov.l @r1,r2
    c.r[2] += 1;  // 06023D7E add #1,r2
    st32(c.r[1], c.r[2]);  // 06023D80 mov.l r2,@r1
    c.r[1] = ld32(0x06023DF8u);  // 06023D82 mov.l 0x06023DF8,r1
    c.r[1] = ld32(c.r[1]);  // 06023D84 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06023D86 cmp/ge r1,r2
L_06023D88:
    if (c.t) { goto L_06023DB4; }  // 06023D88 bt 0x06023DB4
    c.r[1] = ld32(0x06023DFCu);  // 06023D8A mov.l 0x06023DFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06023D90u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023D90u) return; }  // 06023D8C jsr @r1 ; nop
    c.r[14] += 16; goto L_06023DB6;  // 06023D90 bra 0x06023DB6 ; add #16,r14
L_06023D94:
    c.r[3] = ld32(0x06023DF0u);  // 06023D94 mov.l 0x06023DF0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023D96 mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06023DCCu);  // 06023D98 mov.w 0x06023DCC,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06023D9A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06023D9C cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06023DB4; } }  // 06023D9E bt/s 0x06023DB4 ; mov r3,r1
    c.r[2] = ld32(0x06023E00u);  // 06023DA2 mov.l 0x06023E00,r2
    c.r[1] += 2;  // 06023DA4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023DA6 mov.b @r1,r1
    c.r[3] += 3;  // 06023DA8 add #3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06023DAA extu.b r1,r1
    st32(c.r[2] + 12, c.r[1]);  // 06023DAC mov.l r1,@(12,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023DAE mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023DB0 extu.b r1,r1
    st32(c.r[2] + 16, c.r[1]);  // 06023DB2 mov.l r1,@(16,r2)
L_06023DB4:
    c.r[14] += 16;  // 06023DB4 add #16,r14
L_06023DB6:
    c.r[15] = c.r[14];  // 06023DB6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06023DB8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06023DBA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06023DBC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06023DBE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06023DC0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06023DC2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06023DC4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06023DCEu);  // 06023DC6 mov.w 0x06023DCE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06023DC8 rts ; mov.l @r15+,r8
}

void f_06023E04(SH2Context& c) {
    ran[452] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023E04 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06023E06 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06023E08 extu.b r4,r4
    c.r[2] = c.r[4];  // 06023E0A mov r4,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06023E0C extu.b r5,r5
    c.r[6] = c.r[6] & 0xFFu;  // 06023E0E extu.b r6,r6
    c.r[1] = c.r[6];  // 06023E10 mov r6,r1
    c.t = c.r[4] >= c.r[6];  // 06023E12 cmp/hs r6,r4
    { const bool k = c.t; c.r[7] = c.r[7] & 0xFFu; if (k) { goto L_06023E1E; } }  // 06023E14 bt/s 0x06023E1E ; extu.b r7,r7
    c.r[6] -= c.r[4];  // 06023E18 sub r4,r6
    c.r[0] = c.r[6] & 0xFFu; goto L_06023E22;  // 06023E1A bra 0x06023E22 ; extu.b r6,r0
L_06023E1E:
    c.r[2] -= c.r[1];  // 06023E1E sub r1,r2
    c.r[0] = c.r[2] & 0xFFu;  // 06023E20 extu.b r2,r0
L_06023E22:
    c.t = c.r[5] >= c.r[7];  // 06023E22 cmp/hs r7,r5
    if (c.t) { goto L_06023E2C; }  // 06023E24 bt 0x06023E2C
    c.r[7] -= c.r[5];  // 06023E26 sub r5,r7
    c.r[5] = c.r[7] & 0xFFu; goto L_06023E30;  // 06023E28 bra 0x06023E30 ; extu.b r7,r5
L_06023E2C:
    c.r[5] -= c.r[7];  // 06023E2C sub r7,r5
    c.r[5] = c.r[5] & 0xFFu;  // 06023E2E extu.b r5,r5
L_06023E30:
    c.r[15] = c.r[14];  // 06023E30 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06023E32 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += c.r[5]; c.pc = x; return; }  // 06023E34 rts ; add r5,r0
}

void f_06023E38(SH2Context& c) {
    ran[453] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06023E38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06023E3A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06023E3C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06023E3E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06023E40 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023E42 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06023E44 sts.l pr,@-r15
    c.r[15] -= 76;  // 06023E46 add #-76,r15
    c.r[14] = c.r[15];  // 06023E48 mov r15,r14
    c.r[8] = ld32(0x06023F64u);  // 06023E4A mov.l 0x06023F64,r8
    c.r[1] = c.r[8];  // 06023E4C mov r8,r1
    c.r[1] += 36;  // 06023E4E add #36,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06023F62u);  // 06023E50 mov.w 0x06023F62,r9
    st8(c.r[1], c.r[9]);  // 06023E52 mov.b r9,@r1
    c.r[1] = ld32(0x06023F68u);  // 06023E54 mov.l 0x06023F68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06023E5Au; c.r[11] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023E5Au) return; }  // 06023E56 jsr @r1 ; mov r9,r11
    c.r[8] += 33;  // 06023E5A add #33,r8
    c.r[0] = ld32(0x06023F6Cu);  // 06023E5C mov.l 0x06023F6C,r0
    c.r[7] = 0x0u;  // 06023E5E mov #0,r7
    c.r[6] = 0xFFFFFFF9u;  // 06023E60 mov #-7,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06023E62 mov.b @r8,r1
    c.r[5] = c.r[14];  // 06023E64 mov r14,r5
    c.r[8] = ld32(0x06023F70u);  // 06023E66 mov.l 0x06023F70,r8
    c.r[4] = ld32(c.r[8]);  // 06023E68 mov.l @r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06023E6Eu; c.r[12] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023E6Eu) return; }  // 06023E6A jsr @r0 ; extu.b r1,r12
    c.r[1] = c.r[12];  // 06023E6E mov r12,r1
    c.r[8] = ld32(c.r[8]);  // 06023E70 mov.l @r8,r8
    c.r[1] <<= 2;  // 06023E72 shll2 r1
    c.r[1] <<= 2;  // 06023E74 shll2 r1
    c.r[1] += c.r[8];  // 06023E76 add r8,r1
    c.r[1] += 9;  // 06023E78 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023E7A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06023E7C extu.b r1,r3
    c.t = c.r[3] == c.r[9];  // 06023E7E cmp/eq r9,r3
    { const bool k = c.t; c.r[10] = c.r[0]; if (k) { goto L_06023EE0; } }  // 06023E80 bt/s 0x06023EE0 ; mov r0,r10
    c.r[2] = c.r[3];  // 06023E84 mov r3,r2
    c.r[2] <<= 2;  // 06023E86 shll2 r2
    c.r[2] <<= 2;  // 06023E88 shll2 r2
    c.r[2] += c.r[8];  // 06023E8A add r8,r2
    c.r[1] = c.r[2];  // 06023E8C mov r2,r1
    c.r[1] += 4;  // 06023E8E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06023E90 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06023E92 mov r1,r0
    c.r[0] >>= 2;  // 06023E94 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06023E96 shlr r0
    c.r[0] >>= 2;  // 06023E98 shlr2 r0
    c.r[0] &= 0x1u;  // 06023E9A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06023E9C tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[3]; if (k) { goto L_06023EAA; } }  // 06023E9E bt/s 0x06023EAA ; mov r3,r7
    c.r[2] += 6;  // 06023EA2 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023EA4 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06023EA6 extu.b r1,r3
    c.r[7] = c.r[3];  // 06023EA8 mov r3,r7
L_06023EAA:
    c.r[7] <<= 2;  // 06023EAA shll2 r7
    c.r[7] <<= 2;  // 06023EAC shll2 r7
    c.r[1] = c.r[7];  // 06023EAE mov r7,r1
    c.r[1] += c.r[8];  // 06023EB0 add r8,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06023EB2 mov.l @(4,r1),r2
    c.r[1] = ld32(0x06023F74u);  // 06023EB4 mov.l 0x06023F74,r1
    c.r[2] &= c.r[1];  // 06023EB6 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06023EB8 tst r2,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06023EC8; } }  // 06023EBA bf/s 0x06023EC8 ; mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06023EBE mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023EC0 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 06023EC2 cmp/eq r9,r1
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06023ECC; } }  // 06023EC4 bf/s 0x06023ECC ; mov #0,r7
L_06023EC8:
    c.r[3] = c.r[9];  // 06023EC8 mov r9,r3
    c.r[7] = 0x0u;  // 06023ECA mov #0,r7
L_06023ECC:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 06023ECC cmp/ge r10,r7
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06023EE0; } }  // 06023ECE bt/s 0x06023EE0 ; mov r14,r0
L_06023ED2:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06023ED2 mov.b @(r0,r7),r2
    c.r[1] = c.r[2] & 0xFFu;  // 06023ED4 extu.b r2,r1
    c.t = c.r[3] == c.r[1];  // 06023ED6 cmp/eq r1,r3
    { const bool k = c.t; c.r[7] += 1; if (k) { goto L_06023F5C; } }  // 06023ED8 bt/s 0x06023F5C ; add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 06023EDC cmp/ge r10,r7
    if (!c.t) { SH2_POLL(c); goto L_06023ED2; }  // 06023EDE bf 0x06023ED2
L_06023EE0:
    c.r[7] = 0x0u;  // 06023EE0 mov #0,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 06023EE2 cmp/ge r10,r7
    if (c.t) { goto L_06023F50; }  // 06023EE4 bt 0x06023F50
    c.r[1] = ld32(0x06023F70u);  // 06023EE6 mov.l 0x06023F70,r1
    c.r[8] = ld32(c.r[1]);  // 06023EE8 mov.l @r1,r8
    c.r[1] = c.r[12];  // 06023EEA mov r12,r1
    c.r[1] <<= 2;  // 06023EEC shll2 r1
    c.r[1] <<= 2;  // 06023EEE shll2 r1
    c.r[2] = c.r[1];  // 06023EF0 mov r1,r2
    c.r[2] += c.r[8];  // 06023EF2 add r8,r2
    c.r[0] = c.r[1];  // 06023EF4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06023EF6 mov.b @(r0,r8),r1
    c.r[2] += 1;  // 06023EF8 add #1,r2
    c.r[4] = c.r[1] & 0xFFu;  // 06023EFA extu.b r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023EFC mov.b @r2,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06023EFE extu.b r1,r5
    c.r[0] = c.r[14];  // 06023F00 mov r14,r0
L_06023F02:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06023F02 mov.b @(r0,r7),r1
    c.r[6] = c.r[1] & 0xFFu;  // 06023F04 extu.b r1,r6
    c.r[1] = c.r[6];  // 06023F06 mov r6,r1
    c.r[1] <<= 2;  // 06023F08 shll2 r1
    c.r[1] <<= 2;  // 06023F0A shll2 r1
    c.r[2] = c.r[1];  // 06023F0C mov r1,r2
    c.r[2] += c.r[8];  // 06023F0E add r8,r2
    c.r[0] = c.r[1];  // 06023F10 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06023F12 mov.b @(r0,r8),r1
    c.r[2] += 1;  // 06023F14 add #1,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06023F16 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06023F18 mov.b @r2,r1
    c.t = c.r[4] >= c.r[3];  // 06023F1A cmp/hs r3,r4
    { const bool k = c.t; c.r[2] = c.r[1] & 0xFFu; if (k) { goto L_06023F26; } }  // 06023F1C bt/s 0x06023F26 ; extu.b r1,r2
    c.r[3] -= c.r[4];  // 06023F20 sub r4,r3
    c.r[1] = c.r[3] & 0xFFu; goto L_06023F2C;  // 06023F22 bra 0x06023F2C ; extu.b r3,r1
L_06023F26:
    c.r[1] = c.r[4];  // 06023F26 mov r4,r1
    c.r[1] -= c.r[3];  // 06023F28 sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023F2A extu.b r1,r1
L_06023F2C:
    c.t = c.r[5] >= c.r[2];  // 06023F2C cmp/hs r2,r5
    { const bool k = c.t; c.r[3] = c.r[1]; if (k) { goto L_06023F38; } }  // 06023F2E bt/s 0x06023F38 ; mov r1,r3
    c.r[2] -= c.r[5];  // 06023F32 sub r5,r2
    c.r[1] = c.r[2] & 0xFFu; goto L_06023F3E;  // 06023F34 bra 0x06023F3E ; extu.b r2,r1
L_06023F38:
    c.r[1] = c.r[5];  // 06023F38 mov r5,r1
    c.r[1] -= c.r[2];  // 06023F3A sub r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06023F3C extu.b r1,r1
L_06023F3E:
    c.r[1] += c.r[3];  // 06023F3E add r3,r1
    c.t = c.r[1] > c.r[11];  // 06023F40 cmp/hi r11,r1
    if (c.t) { goto L_06023F48; }  // 06023F42 bt 0x06023F48
    c.r[11] = c.r[1];  // 06023F44 mov r1,r11
    c.r[9] = c.r[6];  // 06023F46 mov r6,r9
L_06023F48:
    c.r[7] += 1;  // 06023F48 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 06023F4A cmp/ge r10,r7
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06023F02; } }  // 06023F4C bf/s 0x06023F02 ; mov r14,r0
L_06023F50:
    c.r[1] = ld32(0x06023F78u);  // 06023F50 mov.l 0x06023F78,r1
    c.t = c.r[11] == c.r[1];  // 06023F52 cmp/eq r1,r11
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06023F80; } }  // 06023F54 bf/s 0x06023F80 ; mov #-1,r0
    c.r[14] += 76; goto L_06023F88;  // 06023F58 bra 0x06023F88 ; add #76,r14
L_06023F5C:
    c.r[1] = ld32(0x06023F7Cu);  // 06023F5C mov.l 0x06023F7C,r1
    st8(c.r[1], c.r[2]); goto L_06023F84;  // 06023F5E bra 0x06023F84 ; mov.b r2,@r1
L_06023F80:
    c.r[1] = ld32(0x06023F9Cu);  // 06023F80 mov.l 0x06023F9C,r1
    st8(c.r[1], c.r[9]);  // 06023F82 mov.b r9,@r1
L_06023F84:
    c.r[0] = 0x0u;  // 06023F84 mov #0,r0
    c.r[14] += 76;  // 06023F86 add #76,r14
L_06023F88:
    c.r[15] = c.r[14];  // 06023F88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06023F8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06023F8C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06023F8E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06023F90 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06023F92 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06023F94 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06023F96 rts ; mov.l @r15+,r8
}

void f_06023FA0(SH2Context& c) {
    ran[454] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06023FA0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06023FA2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06023FA4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06023FA6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06023FA8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06023FAA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06023FAC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06023FAE sts.l pr,@-r15
    c.r[15] -= 4;  // 06023FB0 add #-4,r15
    c.r[14] = c.r[15];  // 06023FB2 mov r15,r14
    c.r[1] = c.r[5] & 0xFFu;  // 06023FB4 extu.b r5,r1
    c.r[8] = c.r[6] & 0xFFu;  // 06023FB6 extu.b r6,r8
    c.r[12] = 0x0u;  // 06023FB8 mov #0,r12
    c.t = (c.r[8] & c.r[8]) == 0;  // 06023FBA tst r8,r8
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_06024096; } }  // 06023FBC bt/s 0x06024096 ; mov #0,r13
    c.r[9] = ld32(0x060240B0u);  // 06023FC0 mov.l 0x060240B0,r9
    c.r[1] <<= 2;  // 06023FC2 shll2 r1
    c.r[1] <<= 2;  // 06023FC4 shll2 r1
    c.r[3] = c.r[1];  // 06023FC6 mov r1,r3
    c.r[0] = c.r[1];  // 06023FC8 mov r1,r0
    c.r[7] = c.r[8];  // 06023FCA mov r8,r7
    c.r[2] = ld32(c.r[9]);  // 06023FCC mov.l @r9,r2
    c.r[4] = ld32(0x060240B4u);  // 06023FCE mov.l 0x060240B4,r4
    c.r[3] += c.r[2];  // 06023FD0 add r2,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06023FD2 mov.b @(r0,r2),r5
    c.r[3] += 1;  // 06023FD4 add #1,r3
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06023FD6 mov.b @r3,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06023FD8 extu.b r5,r5
    c.r[6] = c.r[6] & 0xFFu;  // 06023FDA extu.b r6,r6
    c.r[0] = ld32(0x060240B8u);  // 06023FDC mov.l 0x060240B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06023FE2u; c.r[15] -= 4; st32(c.r[15], c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06023FE2u) return; }  // 06023FDE jsr @r0 ; mov.l r12,@-r15
    c.r[1] = c.r[0];  // 06023FE2 mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06023FE4 extu.b r1,r11
    c.r[8] <<= 2;  // 06023FE6 shll2 r8
    c.r[10] = ld32(0x060240BCu);  // 06023FE8 mov.l 0x060240BC,r10
    c.r[6] = c.r[11];  // 06023FEA mov r11,r6
    c.r[6] -= c.r[8];  // 06023FEC sub r8,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[11];  // 06023FEE cmp/ge r11,r6
    if (c.t) { goto L_06024084; }  // 06023FF0 bt 0x06024084
    c.r[9] = ld32(c.r[9]);  // 06023FF2 mov.l @r9,r9
    c.r[1] = c.r[6];  // 06023FF4 mov r6,r1
    c.r[1] += c.r[1];  // 06023FF6 add r1,r1
    c.r[4] = ld32(0x060240B4u);  // 06023FF8 mov.l 0x060240B4,r4
    c.r[4] += c.r[1];  // 06023FFA add r1,r4
    c.r[8] = c.r[1];  // 06023FFC mov r1,r8
    c.r[0] = ld32(0x060240B4u);  // 06023FFE mov.l 0x060240B4,r0
L_06024000:
    c.r[3] = 0x0u;  // 06024000 mov #0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06024002 mov.b @(r0,r8),r1
    c.r[5] = 0x1u;  // 06024004 mov #1,r5
    c.r[6] = c.r[1] & 0xFFu;  // 06024006 extu.b r1,r6
    c.r[1] = c.r[4];  // 06024008 mov r4,r1
    c.r[1] += 1;  // 0602400A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602400C mov.b @r1,r1
    c.r[2] = 0x0u;  // 0602400E mov #0,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06024010 extu.b r1,r7
    st32(c.r[14], c.r[9]);  // 06024012 mov.l r9,@r14
L_06024014:
    c.r[0] = c.r[2];  // 06024014 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06024016 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06024018 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602401A cmp/eq r6,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0602403A; } }  // 0602401C bf/s 0x0602403A ; mov.l @r14,r0
    c.r[1] = ld32(c.r[14]);  // 06024020 mov.l @r14,r1
    c.r[1] += 1;  // 06024022 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024024 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06024026 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 06024028 cmp/eq r7,r1
    if (!c.t) { goto L_0602403A; }  // 0602402A bf 0x0602403A
    c.r[1] = ld32(c.r[0] + 4);  // 0602402C mov.l @(4,r0),r1
    c.r[0] = ld32(0x060240C0u);  // 0602402E mov.l 0x060240C0,r0
    c.r[1] &= c.r[0];  // 06024030 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06024032 tst r1,r1
    { const bool k = c.t; c.t = (c.r[5] & c.r[5]) == 0; if (k) { goto L_0602404C; } }  // 06024034 bt/s 0x0602404C ; tst r5,r5
    c.r[0] = ld32(c.r[14]);  // 06024038 mov.l @r14,r0
L_0602403A:
    c.r[2] += 16;  // 0602403A add #16,r2
    c.r[3] += 1;  // 0602403C add #1,r3
    c.r[1] = 0x49u;  // 0602403E mov #73,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06024040 cmp/gt r1,r3
    c.r[0] += 16;  // 06024042 add #16,r0
    { const bool k = !c.t; st32(c.r[14], c.r[0]); if (k) { SH2_POLL(c); goto L_06024014; } }  // 06024044 bf/s 0x06024014 ; mov.l r0,@r14
    c.r[5] = 0x0u;  // 06024048 mov #0,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0602404A tst r5,r5
L_0602404C:
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06024074; } }  // 0602404C bf/s 0x06024074 ; mov r6,r1
    c.r[1] += c.r[1];  // 06024050 add r1,r1
    c.r[2] = c.r[7];  // 06024052 mov r7,r2
    c.r[2] <<= 2;  // 06024054 shll2 r2
    c.r[2] <<= 2;  // 06024056 shll2 r2
    c.r[2] += c.r[2];  // 06024058 add r2,r2
    c.r[2] <<= 2;  // 0602405A shll2 r2
    c.r[0] = ld32(0x060240C4u);  // 0602405C mov.l 0x060240C4,r0
    c.r[2] += c.r[0];  // 0602405E add r0,r2
    c.r[0] = c.r[1];  // 06024060 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06024062 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06024064 extu.w r1,r1
    c.t = c.r[10] > c.r[1];  // 06024066 cmp/hi r1,r10
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06024074; } }  // 06024068 bf/s 0x06024074 ; tst r1,r1
    if (c.t) { goto L_06024074; }  // 0602406C bt 0x06024074
    c.r[10] = c.r[1];  // 0602406E mov r1,r10
    c.r[13] = c.r[6];  // 06024070 mov r6,r13
    c.r[12] = c.r[7];  // 06024072 mov r7,r12
L_06024074:
    c.r[4] += 2;  // 06024074 add #2,r4
    c.r[1] = c.r[11];  // 06024076 mov r11,r1
    c.r[1] += c.r[1];  // 06024078 add r1,r1
    c.r[0] = ld32(0x060240B4u);  // 0602407A mov.l 0x060240B4,r0
    c.r[1] += c.r[0];  // 0602407C add r0,r1
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[1];  // 0602407E cmp/ge r1,r4
    { const bool k = !c.t; c.r[8] += 2; if (k) { SH2_POLL(c); goto L_06024000; } }  // 06024080 bf/s 0x06024000 ; add #2,r8
L_06024084:
    c.r[1] = ld32(0x060240BCu);  // 06024084 mov.l 0x060240BC,r1
    c.t = c.r[10] == c.r[1];  // 06024086 cmp/eq r1,r10
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06024098; } }  // 06024088 bt/s 0x06024098 ; mov #-1,r0
    c.r[1] = ld32(0x060240C8u);  // 0602408C mov.l 0x060240C8,r1
    st32(c.r[1] + 12, c.r[13]);  // 0602408E mov.l r13,@(12,r1)
    st32(c.r[1] + 16, c.r[12]);  // 06024090 mov.l r12,@(16,r1)
    c.r[0] = 0x0u; goto L_06024098;  // 06024092 bra 0x06024098 ; mov #0,r0
L_06024096:
    c.r[0] = 0xFFFFFFFFu;  // 06024096 mov #-1,r0
L_06024098:
    c.r[14] += 4;  // 06024098 add #4,r14
    c.r[15] = c.r[14];  // 0602409A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602409C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602409E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060240A0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060240A2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060240A4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060240A6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060240A8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060240AA rts ; mov.l @r15+,r8
}

void f_060240CC(SH2Context& c) {
    ran[455] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060240CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060240CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060240D0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060240D2 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 060240D4 extu.w r4,r4
    c.r[0] = ld32(0x0602412Cu);  // 060240D6 mov.l 0x0602412C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060240DCu; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060240DCu) return; }  // 060240D8 jsr @r0 ; mov #0,r8
    c.r[2] = c.r[0] & 0xFFu;  // 060240DC extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602412Au);  // 060240DE mov.w 0x0602412A,r1
    c.t = c.r[2] == c.r[1];  // 060240E0 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0602411E; } }  // 060240E2 bt/s 0x0602411E ; shll2 r2
    c.r[1] = ld32(0x06024130u);  // 060240E6 mov.l 0x06024130,r1
    c.r[3] = ld32(c.r[1]);  // 060240E8 mov.l @r1,r3
    c.r[2] <<= 2;  // 060240EA shll2 r2
    c.r[1] = c.r[2];  // 060240EC mov r2,r1
    c.r[1] += c.r[3];  // 060240EE add r3,r1
    c.r[1] += 1;  // 060240F0 add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060240F2 mov.b @r1,r7
    c.r[0] = c.r[2];  // 060240F4 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060240F6 mov.b @(r0,r3),r6
    c.r[7] = c.r[7] & 0xFFu;  // 060240F8 extu.b r7,r7
    c.r[1] = ld32(0x06024134u);  // 060240FA mov.l 0x06024134,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060240FC mov.b @r1,r1
    c.r[6] = c.r[6] & 0xFFu;  // 060240FE extu.b r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06024100 extu.b r1,r1
    c.r[1] <<= 2;  // 06024102 shll2 r1
    c.r[1] <<= 2;  // 06024104 shll2 r1
    c.r[2] = c.r[1];  // 06024106 mov r1,r2
    c.r[2] += c.r[3];  // 06024108 add r3,r2
    c.r[2] += 1;  // 0602410A add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602410C mov.b @r2,r5
    c.r[0] = c.r[1];  // 0602410E mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06024110 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06024112 extu.b r5,r5
    c.r[0] = ld32(0x06024138u);  // 06024114 mov.l 0x06024138,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602411Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602411Au) return; }  // 06024116 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0602411A mov r0,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602411C extu.w r1,r8
L_0602411E:
    c.r[15] = c.r[14];  // 0602411E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024120 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024122 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 06024124 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024126 rts ; mov.l @r15+,r8
}

void f_0602413C(SH2Context& c) {
    ran[456] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602413C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602413E mov r15,r14
    c.r[2] = c.r[4] & 0xFFu;  // 06024140 extu.b r4,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06024142 extu.b r5,r5
    c.r[6] = c.r[6] & 0xFFu;  // 06024144 extu.b r6,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06024146 extu.b r7,r7
    c.r[0] = 0x0u;  // 06024148 mov #0,r0
    c.r[2] -= c.r[6];  // 0602414A sub r6,r2
    c.r[5] -= c.r[7];  // 0602414C sub r7,r5
    c.t = (int32_t)c.r[2] >= 0;  // 0602414E cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0602416E; } }  // 06024150 bt/s 0x0602416E ; mov r5,r1
    c.t = (int32_t)c.r[5] >= 0;  // 06024154 cmp/pz r5
    { const bool k = !c.t; c.r[1] = 0u - c.r[2]; if (k) { goto L_0602415E; } }  // 06024156 bf/s 0x0602415E ; neg r2,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5]; goto L_06024166;  // 0602415A bra 0x06024166 ; cmp/gt r5,r1
L_0602415E:
    c.r[2] = 0u - c.r[2];  // 0602415E neg r2,r2
    c.r[1] = 0u - c.r[5];  // 06024160 neg r5,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06024162 cmp/gt r1,r2
    c.r[0] = 0x2u;  // 06024164 mov #2,r0
L_06024166:
    if (!c.t) { goto L_0602417E; }  // 06024166 bf 0x0602417E
    c.r[0] = 0x1u;  // 06024168 mov #1,r0
    c.r[15] = c.r[14]; goto L_06024180;  // 0602416A bra 0x06024180 ; mov r14,r15
L_0602416E:
    c.t = (int32_t)c.r[5] >= 0;  // 0602416E cmp/pz r5
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[5]; if (k) { goto L_0602417A; } }  // 06024170 bt/s 0x0602417A ; cmp/gt r5,r2
    c.r[1] = 0u - c.r[1];  // 06024174 neg r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06024176 cmp/gt r1,r2
    c.r[0] = 0x2u;  // 06024178 mov #2,r0
L_0602417A:
    if (!c.t) { goto L_0602417E; }  // 0602417A bf 0x0602417E
    c.r[0] = 0x3u;  // 0602417C mov #3,r0
L_0602417E:
    c.r[15] = c.r[14];  // 0602417E mov r14,r15
L_06024180:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024180 rts ; mov.l @r15+,r14
}

void f_06024184(SH2Context& c) {
    ran[457] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024184 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024186 sts.l pr,@-r15
    c.r[1] = ld32(0x060241A4u);  // 06024188 mov.l 0x060241A4,r1
    c.r[1] = ld32(c.r[1]);  // 0602418A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602418C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602418E extu.b r1,r0
    c.r[0] <<= 2;  // 06024190 shll2 r0
    c.r[1] = ld32(0x060241A8u);  // 06024192 mov.l 0x060241A8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06024194 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602419Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602419Au) return; }  // 06024196 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602419A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602419C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602419E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060241A0 rts ; extu.w r0,r0
}

void f_060241AC(SH2Context& c) {
    ran[458] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060241AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060241AE sts.l pr,@-r15
    c.r[1] = ld32(0x060241ECu);  // 060241B0 mov.l 0x060241EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060241B6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060241B6u) return; }  // 060241B2 jsr @r1 ; mov r15,r14
    c.r[2] = 0x0u;  // 060241B6 mov #0,r2
    c.r[7] = 0x2u;  // 060241B8 mov #2,r7
    c.r[1] = ld32(0x060241F0u);  // 060241BA mov.l 0x060241F0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060241E2u);  // 060241BC mov.w 0x060241E2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060241E4u);  // 060241BE mov.w 0x060241E4,r3
    c.r[1] = ld32(c.r[1]);  // 060241C0 mov.l @r1,r1
L_060241C2:
    st16(c.r[0] + c.r[1], c.r[3]);  // 060241C2 mov.w r3,@(r0,r1)
    c.r[2] += 1;  // 060241C4 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060241C6 cmp/gt r7,r2
    { const bool k = !c.t; c.r[1] += 2; if (k) { SH2_POLL(c); goto L_060241C2; } }  // 060241C8 bf/s 0x060241C2 ; add #2,r1
    c.r[1] = ld32(0x060241F0u);  // 060241CC mov.l 0x060241F0,r1
    c.r[4] = ld32(c.r[1]);  // 060241CE mov.l @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x060241E6u);  // 060241D0 mov.w 0x060241E6,r5
    c.r[1] = ld32(0x060241F4u);  // 060241D2 mov.l 0x060241F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060241D8u; c.r[4] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060241D8u) return; }  // 060241D4 jsr @r1 ; add #40,r4
    c.r[15] = c.r[14];  // 060241D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060241DA lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060241E8u);  // 060241DC mov.w 0x060241E8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060241DE rts ; mov.l @r15+,r14
}

void f_060241F8(SH2Context& c) {
    ran[459] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060241F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060241FA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060241FC sts.l pr,@-r15
    c.r[15] -= 76;  // 060241FE add #-76,r15
    c.r[14] = c.r[15];  // 06024200 mov r15,r14
    c.r[1] = ld32(0x06024244u);  // 06024202 mov.l 0x06024244,r1
    c.r[0] = ld32(0x06024248u);  // 06024204 mov.l 0x06024248,r0
    c.r[7] = 0x1u;  // 06024206 mov #1,r7
    c.r[6] = 0xFFFFFFFBu;  // 06024208 mov #-5,r6
    c.r[4] = ld32(c.r[1]);  // 0602420A mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06024210u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024210u) return; }  // 0602420C jsr @r0 ; mov r14,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06024210 mov.b @r14,r1
    c.r[8] = ld32(0x0602424Cu);  // 06024212 mov.l 0x0602424C,r8
    st8(c.r[8], c.r[1]);  // 06024214 mov.b r1,@r8
    c.r[1] = ld32(0x06024250u);  // 06024216 mov.l 0x06024250,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602421Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602421Cu) return; }  // 06024218 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602421C mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602423Eu);  // 0602421E mov.w 0x0602423E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024220 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06024222 cmp/eq r2,r1
    if (!c.t) { goto L_06024230; }  // 06024224 bf 0x06024230
    c.r[1] = ld32(0x06024254u);  // 06024226 mov.l 0x06024254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602422Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602422Cu) return; }  // 06024228 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0602422C mov #0,r1
    st8(c.r[8], c.r[1]);  // 0602422E mov.b r1,@r8
L_06024230:
    c.r[14] += 76;  // 06024230 add #76,r14
    c.r[15] = c.r[14];  // 06024232 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024234 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024236 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024240u);  // 06024238 mov.w 0x06024240,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602423A rts ; mov.l @r15+,r8
}

void f_06024258(SH2Context& c) {
    ran[460] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024258 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602425A mov r15,r14
    c.r[6] = ld32(0x06024280u);  // 0602425C mov.l 0x06024280,r6
    c.r[7] = ld32(0x06024284u);  // 0602425E mov.l 0x06024284,r7
    c.r[1] = ld32(0x06024288u);  // 06024260 mov.l 0x06024288,r1
    c.r[3] = ld32(c.r[1]);  // 06024262 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06024264 mov r3,r1
    c.r[1] += 1;  // 06024266 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024268 mov.b @r1,r2
    c.r[3] += 2;  // 0602426A add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602426C mov.b @r3,r1
    c.r[2] <<= 8;  // 0602426E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024270 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06024272 or r1,r2
    st16(c.r[7], c.r[2]);  // 06024274 mov.w r2,@r7
    st16(c.r[6], c.r[2]);  // 06024276 mov.w r2,@r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602427Eu);  // 06024278 mov.w 0x0602427E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602427A rts ; mov.l @r15+,r14
}

void f_0602428C(SH2Context& c) {
    ran[461] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602428C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602428E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06024290 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024292 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024294 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06024296 mov r15,r14
    c.r[9] = ld32(0x0602436Cu);  // 06024298 mov.l 0x0602436C,r9
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0602429A mov.w @r9,r4
    c.r[0] = ld32(0x06024370u);  // 0602429C mov.l 0x06024370,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060242A2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060242A2u) return; }  // 0602429E jsr @r0 ; extu.w r4,r4
    c.r[8] = c.r[0] & 0xFFu;  // 060242A2 extu.b r0,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06024366u);  // 060242A4 mov.w 0x06024366,r10
    c.t = c.r[8] == c.r[10];  // 060242A6 cmp/eq r10,r8
    if (!c.t) { goto L_06024306; }  // 060242A8 bf 0x06024306
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060242AA mov.w @r9,r4
    c.r[0] = ld32(0x06024374u);  // 060242AC mov.l 0x06024374,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060242B2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060242B2u) return; }  // 060242AE jsr @r0 ; extu.w r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 060242B2 extu.b r0,r2
    c.r[1] = ld32(0x06024378u);  // 060242B4 mov.l 0x06024378,r1
    c.r[3] = c.r[2];  // 060242B6 mov r2,r3
    c.r[3] += c.r[3];  // 060242B8 add r3,r3
    c.r[3] += c.r[2];  // 060242BA add r2,r3
    c.r[1] = ld32(c.r[1]);  // 060242BC mov.l @r1,r1
    c.r[3] <<= 2;  // 060242BE shll2 r3
    c.r[3] += c.r[1];  // 060242C0 add r1,r3
    c.r[3] += 3;  // 060242C2 add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060242C4 mov.b @r3,r1
    c.r[0] = c.r[1];  // 060242C6 mov r1,r0
    c.r[0] >>= 2;  // 060242C8 shlr2 r0
    c.r[0] >>= 2;  // 060242CA shlr2 r0
    c.r[0] &= 0x3u;  // 060242CC and #3,r0
    c.t = c.r[0] == 0x1u;  // 060242CE cmp/eq #1,r0
    if (!c.t) { goto L_06024306; }  // 060242D0 bf 0x06024306
    c.r[1] = ld32(0x0602437Cu);  // 060242D2 mov.l 0x0602437C,r1
    c.r[1] = ld32(c.r[1]);  // 060242D4 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024368u);  // 060242D6 mov.w 0x06024368,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060242D8 mov.w @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060242DA extu.w r1,r8
    c.r[1] = ld32(0x06024380u);  // 060242DC mov.l 0x06024380,r1
    c.r[2] = c.r[8];  // 060242DE mov r8,r2
    c.r[3] = ld32(c.r[1]);  // 060242E0 mov.l @r1,r3
    c.r[2] <<= 2;  // 060242E2 shll2 r2
    c.r[2] <<= 2;  // 060242E4 shll2 r2
    c.r[1] = c.r[2];  // 060242E6 mov r2,r1
    c.r[1] += c.r[3];  // 060242E8 add r3,r1
    c.r[1] += 7;  // 060242EA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060242EC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060242EE mov r1,r0
    c.r[0] >>= 2;  // 060242F0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060242F2 shlr r0
    c.r[0] &= 0x1u;  // 060242F4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060242F6 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06024304; } }  // 060242F8 bf/s 0x06024304 ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060242FC mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060242FE extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06024300 cmp/eq r10,r1
    if (!c.t) { goto L_06024306; }  // 06024302 bf 0x06024306
L_06024304:
    c.r[8] = c.r[10];  // 06024304 mov r10,r8
L_06024306:
    c.r[1] = ld32(0x06024384u);  // 06024306 mov.l 0x06024384,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602430Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602430Cu) return; }  // 06024308 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024366u);  // 0602430C mov.w 0x06024366,r1
    c.t = c.r[8] == c.r[1];  // 0602430E cmp/eq r1,r8
    { const bool k = c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_06024356; } }  // 06024310 bt/s 0x06024356 ; extu.b r8,r5
    c.r[9] = ld32(0x06024388u);  // 06024314 mov.l 0x06024388,r9
    st8(c.r[9], c.r[8]);  // 06024316 mov.b r8,@r9
    c.r[8] = ld32(0x06024380u);  // 06024318 mov.l 0x06024380,r8
    c.r[0] = ld32(0x0602438Cu);  // 0602431A mov.l 0x0602438C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024320u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024320u) return; }  // 0602431C jsr @r0 ; mov.l @r8,r4
    c.r[1] = c.r[0];  // 06024320 mov r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06024322 mov.b @r9,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06024324 extu.b r1,r7
    c.r[3] = ld32(c.r[8]);  // 06024326 mov.l @r8,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06024328 extu.b r2,r2
    c.r[2] <<= 2;  // 0602432A shll2 r2
    c.r[2] <<= 2;  // 0602432C shll2 r2
    c.r[7] <<= 2;  // 0602432E shll2 r7
    c.r[7] <<= 2;  // 06024330 shll2 r7
    c.r[0] = c.r[7];  // 06024332 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06024334 mov.b @(r0,r3),r1
    c.r[0] = c.r[2];  // 06024336 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06024338 mov.b r1,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0602433A mov.b @r9,r2
    c.r[1] = ld32(c.r[8]);  // 0602433C mov.l @r8,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0602433E extu.b r2,r2
    c.r[2] <<= 2;  // 06024340 shll2 r2
    c.r[2] <<= 2;  // 06024342 shll2 r2
    c.r[2] += c.r[1];  // 06024344 add r1,r2
    c.r[7] += c.r[1];  // 06024346 add r1,r7
    c.r[7] += 1;  // 06024348 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602434A mov.b @r7,r1
    c.r[2] += 1;  // 0602434C add #1,r2
    st8(c.r[2], c.r[1]);  // 0602434E mov.b r1,@r2
    c.r[1] = ld32(0x06024390u);  // 06024350 mov.l 0x06024390,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024356u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024356u) return; }  // 06024352 jsr @r1 ; nop
L_06024356:
    c.r[15] = c.r[14];  // 06024356 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024358 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602435A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602435C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602435E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602436Au);  // 06024360 mov.w 0x0602436A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024362 rts ; mov.l @r15+,r8
}

void f_06024394(SH2Context& c) {
    ran[462] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024394 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024396 sts.l pr,@-r15
    c.r[1] = ld32(0x060243DCu);  // 06024398 mov.l 0x060243DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602439Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602439Eu) return; }  // 0602439A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060243E0u);  // 0602439E mov.l 0x060243E0,r1
    c.r[2] = ld32(c.r[1]);  // 060243A0 mov.l @r1,r2
    c.r[0] = ld32(0x060243E4u);  // 060243A2 mov.l 0x060243E4,r0
    c.r[1] = c.r[2];  // 060243A4 mov r2,r1
    c.r[1] += 1;  // 060243A6 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060243A8 mov.b @r1,r4
    c.r[2] += 2;  // 060243AA add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060243AC extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060243AE mov.b @r2,r1
    c.r[4] <<= 8;  // 060243B0 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 060243B2 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060243B8u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060243B8u) return; }  // 060243B4 jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 060243B8 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060243D6u);  // 060243BA mov.w 0x060243D6,r1
    c.t = c.r[0] == c.r[1];  // 060243BC cmp/eq r1,r0
    if (c.t) { goto L_060243CC; }  // 060243BE bt 0x060243CC
    c.r[1] = ld32(0x060243E8u);  // 060243C0 mov.l 0x060243E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060243C6u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060243C6u) return; }  // 060243C2 jsr @r1 ; extu.b r0,r4
    c.r[1] = ld32(0x060243ECu);  // 060243C6 mov.l 0x060243EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060243CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060243CCu) return; }  // 060243C8 jsr @r1 ; nop
L_060243CC:
    c.r[15] = c.r[14];  // 060243CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060243CE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060243D8u);  // 060243D0 mov.w 0x060243D8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060243D2 rts ; mov.l @r15+,r14
}

void f_060243F0(SH2Context& c) {
    ran[463] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060243F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060243F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060243F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060243F6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060243F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060243FA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060243FC mov r15,r14
    c.r[2] = ld32(0x06024488u);  // 060243FE mov.l 0x06024488,r2
    c.r[1] = ld32(0x0602448Cu);  // 06024400 mov.l 0x0602448C,r1
    c.r[10] = 0x0u;  // 06024402 mov #0,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024404 mov.b @r1,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06024484u);  // 06024406 mov.w 0x06024484,r11
    c.r[0] &= 0xEFu;  // 06024408 and #239,r0
    st8(c.r[1], c.r[0]);  // 0602440A mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602440C mov.b @r2,r0
    c.r[9] = 0x0u;  // 0602440E mov #0,r9
    c.r[0] &= 0xEFu;  // 06024410 and #239,r0
    st8(c.r[2], c.r[0]);  // 06024412 mov.b r0,@r2
L_06024414:
    c.r[1] = ld32(0x06024490u);  // 06024414 mov.l 0x06024490,r1
    c.r[0] = ld32(c.r[1]);  // 06024416 mov.l @r1,r0
    c.r[2] = c.r[9];  // 06024418 mov r9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0602441A mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602441C extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 0602441E cmp/eq r11,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06024468; } }  // 06024420 bt/s 0x06024468 ; add r0,r2
    c.r[1] = c.r[2];  // 06024424 mov r2,r1
    c.r[1] += 3;  // 06024426 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024428 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602442A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602442C shlr r0
    c.r[0] &= 0x3u;  // 0602442E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06024430 tst r0,r0
    { const bool k = c.t; c.r[2] += 2; if (k) { goto L_06024468; } }  // 06024432 bt/s 0x06024468 ; add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024436 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06024438 extu.b r1,r8
    c.t = c.r[8] == c.r[11];  // 0602443A cmp/eq r11,r8
    if (c.t) { goto L_06024462; }  // 0602443C bt 0x06024462
    c.r[1] = ld32(0x06024494u);  // 0602443E mov.l 0x06024494,r1
    c.r[2] = ld32(c.r[1]);  // 06024440 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06024442 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06024444 mul.l r1,r8
    c.r[1] = c.macl;  // 06024446 sts macl,r1
    c.r[1] += c.r[2];  // 06024448 add r2,r1
    c.r[1] += 15;  // 0602444A add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602444C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602444E extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06024450 cmp/eq r11,r1
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_0602445C; } }  // 06024452 bt/s 0x0602445C ; extu.b r1,r4
    c.r[1] = ld32(0x06024498u);  // 06024456 mov.l 0x06024498,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602445Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602445Cu) return; }  // 06024458 jsr @r1 ; nop
L_0602445C:
    c.r[0] = ld32(0x0602449Cu);  // 0602445C mov.l 0x0602449C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024462u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024462u) return; }  // 0602445E jsr @r0 ; extu.b r8,r4
L_06024462:
    c.r[1] = ld32(0x060244A0u);  // 06024462 mov.l 0x060244A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024468u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024468u) return; }  // 06024464 jsr @r1 ; extu.b r10,r4
L_06024468:
    c.r[10] += 1;  // 06024468 add #1,r10
    c.r[1] = 0x49u;  // 0602446A mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0602446C cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_06024414; } }  // 0602446E bf/s 0x06024414 ; add #16,r9
    c.r[15] = c.r[14];  // 06024472 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024474 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024476 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06024478 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602447A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602447C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024486u);  // 0602447E mov.w 0x06024486,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024480 rts ; mov.l @r15+,r8
}

void f_060244A4(SH2Context& c) {
    ran[464] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060244A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060244A6 sts.l pr,@-r15
    c.r[1] = ld32(0x060244CCu);  // 060244A8 mov.l 0x060244CC,r1
    c.r[2] = ld32(c.r[1]);  // 060244AA mov.l @r1,r2
    c.r[14] = c.r[15];  // 060244AC mov r15,r14
    c.r[1] = c.r[2];  // 060244AE mov r2,r1
    c.r[1] += 2;  // 060244B0 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060244B2 mov.b @r1,r5
    c.r[2] += 1;  // 060244B4 add #1,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060244B6 mov.b @r2,r4
    c.r[5] = c.r[5] & 0xFFu;  // 060244B8 extu.b r5,r5
    c.r[1] = ld32(0x060244D0u);  // 060244BA mov.l 0x060244D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060244C0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060244C0u) return; }  // 060244BC jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 060244C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060244C2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060244CAu);  // 060244C4 mov.w 0x060244CA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060244C6 rts ; mov.l @r15+,r14
}

void f_060244D4(SH2Context& c) {
    ran[465] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060244D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060244D6 sts.l pr,@-r15
    c.r[1] = ld32(0x060244ECu);  // 060244D8 mov.l 0x060244EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060244DEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060244DEu) return; }  // 060244DA jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060244DE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060244E0 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060244E8u);  // 060244E2 mov.w 0x060244E8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060244E4 rts ; mov.l @r15+,r14
}

void f_060244F0(SH2Context& c) {
    ran[466] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060244F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060244F2 sts.l pr,@-r15
    c.r[1] = ld32(0x06024508u);  // 060244F4 mov.l 0x06024508,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060244FAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060244FAu) return; }  // 060244F6 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060244FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060244FC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024504u);  // 060244FE mov.w 0x06024504,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024500 rts ; mov.l @r15+,r14
}

void f_0602450C(SH2Context& c) {
    ran[467] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602450C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602450E sts.l pr,@-r15
    c.r[1] = ld32(0x06024524u);  // 06024510 mov.l 0x06024524,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024516u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024516u) return; }  // 06024512 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 06024516 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024518 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024520u);  // 0602451A mov.w 0x06024520,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602451C rts ; mov.l @r15+,r14
}

void f_06024528(SH2Context& c) {
    ran[468] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06024528 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602452A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602452C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602452E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024530 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024532 sts.l pr,@-r15
    c.r[1] = ld32(0x060245D8u);  // 06024534 mov.l 0x060245D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602453Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602453Au) return; }  // 06024536 jsr @r1 ; mov r15,r14
    c.r[9] = 0x0u;  // 0602453A mov #0,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x060245D4u);  // 0602453C mov.w 0x060245D4,r11
    c.r[10] = 0x0u;  // 0602453E mov #0,r10
L_06024540:
    c.r[1] = ld32(0x060245DCu);  // 06024540 mov.l 0x060245DC,r1
    c.r[0] = ld32(c.r[1]);  // 06024542 mov.l @r1,r0
    c.r[3] = c.r[10];  // 06024544 mov r10,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06024546 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06024548 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 0602454A cmp/eq r11,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_060245B8; } }  // 0602454C bt/s 0x060245B8 ; add r0,r3
    c.r[1] = c.r[3];  // 06024550 mov r3,r1
    c.r[1] += 3;  // 06024552 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024554 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06024556 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06024558 shlr r0
    c.r[0] &= 0x3u;  // 0602455A and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602455C tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_060245B8; } }  // 0602455E bt/s 0x060245B8 ; mov r3,r2
    c.r[2] += 7;  // 06024562 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024564 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06024566 mov r1,r0
    c.r[0] >>= 2;  // 06024568 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602456A shlr r0
    c.r[0] &= 0x1u;  // 0602456C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602456E tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06024586; } }  // 06024570 bf/s 0x06024586 ; mov r1,r0
    c.r[0] |= 0x8u;  // 06024574 or #8,r0
    st8(c.r[2], c.r[0]);  // 06024576 mov.b r0,@r2
    c.r[1] = ld32(0x060245E0u);  // 06024578 mov.l 0x060245E0,r1
    st8(c.r[1], c.r[9]);  // 0602457A mov.b r9,@r1
    c.r[1] = ld32(0x060245E4u);  // 0602457C mov.l 0x060245E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024582u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024582u) return; }  // 0602457E jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_060245C4;  // 06024582 bra 0x060245C4 ; mov r14,r15
L_06024586:
    c.r[3] += 2;  // 06024586 add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06024588 mov.b @r3,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0602458A extu.b r1,r8
    c.t = c.r[8] == c.r[11];  // 0602458C cmp/eq r11,r8
    if (c.t) { goto L_060245B2; }  // 0602458E bt 0x060245B2
    c.r[1] = ld32(0x060245E8u);  // 06024590 mov.l 0x060245E8,r1
    c.r[2] = ld32(c.r[1]);  // 06024592 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06024594 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06024596 mul.l r1,r8
    c.r[1] = c.macl;  // 06024598 sts macl,r1
    c.r[1] += c.r[2];  // 0602459A add r2,r1
    c.r[1] += 15;  // 0602459C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602459E mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060245A0 extu.b r1,r4
    c.t = c.r[4] == c.r[11];  // 060245A2 cmp/eq r11,r4
    if (c.t) { goto L_060245B2; }  // 060245A4 bt 0x060245B2
    c.r[1] = ld32(0x060245ECu);  // 060245A6 mov.l 0x060245EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060245ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060245ACu) return; }  // 060245A8 jsr @r1 ; nop
    c.r[1] = ld32(0x060245F0u);  // 060245AC mov.l 0x060245F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060245B2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060245B2u) return; }  // 060245AE jsr @r1 ; mov r8,r4
L_060245B2:
    c.r[1] = ld32(0x060245F4u);  // 060245B2 mov.l 0x060245F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060245B8u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060245B8u) return; }  // 060245B4 jsr @r1 ; extu.b r9,r4
L_060245B8:
    c.r[9] += 1;  // 060245B8 add #1,r9
    c.r[1] = 0x49u;  // 060245BA mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060245BC cmp/gt r1,r9
    { const bool k = !c.t; c.r[10] += 16; if (k) { SH2_POLL(c); goto L_06024540; } }  // 060245BE bf/s 0x06024540 ; add #16,r10
    c.r[15] = c.r[14];  // 060245C2 mov r14,r15
L_060245C4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060245C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060245C6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060245C8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060245CA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060245CC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060245D6u);  // 060245CE mov.w 0x060245D6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060245D0 rts ; mov.l @r15+,r8
}

void f_060245F8(SH2Context& c) {
    ran[469] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060245F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060245FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060245FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060245FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06024600 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06024602 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024604 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024606 sts.l pr,@-r15
    c.r[1] = ld32(0x060246E4u);  // 06024608 mov.l 0x060246E4,r1
    c.r[1] = ld32(c.r[1]);  // 0602460A mov.l @r1,r1
    c.r[1] += 1;  // 0602460C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602460E mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06024610 extu.b r1,r11
    c.r[1] = ld32(0x060246E8u);  // 06024612 mov.l 0x060246E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024618u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024618u) return; }  // 06024614 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060246ECu);  // 06024618 mov.l 0x060246EC,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060246DEu);  // 0602461A mov.w 0x060246DE,r2
    st32(c.r[1] + 20, c.r[2]);  // 0602461C mov.l r2,@(20,r1)
    c.r[10] = 0x0u;  // 0602461E mov #0,r10
    c.r[13] = ld32(0x060246F0u);  // 06024620 mov.l 0x060246F0,r13
    c.r[12] = c.r[2];  // 06024622 mov r2,r12
    c.r[9] = 0x0u;  // 06024624 mov #0,r9
L_06024626:
    c.r[0] = ld32(c.r[13]);  // 06024626 mov.l @r13,r0
    c.r[2] = c.r[9];  // 06024628 mov r9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0602462A mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602462C extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0602462E cmp/eq r12,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_060246BE; } }  // 06024630 bt/s 0x060246BE ; add r0,r2
    c.r[7] = c.r[2];  // 06024634 mov r2,r7
    c.r[7] += 3;  // 06024636 add #3,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06024638 mov.b @r7,r3
    c.r[0] = c.r[3];  // 0602463A mov r3,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602463C shlr r0
    c.r[0] &= 0x3u;  // 0602463E and #3,r0
    c.t = c.r[0] == c.r[11];  // 06024640 cmp/eq r11,r0
    { const bool k = !c.t; c.r[2] += 7; if (k) { goto L_060246BE; } }  // 06024642 bf/s 0x060246BE ; add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024646 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06024648 mov r1,r0
    c.r[0] >>= 2;  // 0602464A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602464C shlr r0
    c.r[0] &= 0x1u;  // 0602464E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06024650 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0602467E; } }  // 06024652 bf/s 0x0602467E ; mov r1,r0
    c.r[0] |= 0x8u;  // 06024656 or #8,r0
    st8(c.r[2], c.r[0]);  // 06024658 mov.b r0,@r2
    c.r[1] = ld32(c.r[13]);  // 0602465A mov.l @r13,r1
    c.r[9] += c.r[1];  // 0602465C add r1,r9
    c.r[9] += 4;  // 0602465E add #4,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06024660 mov.b @r9,r0
    c.r[0] &= 0x60u;  // 06024662 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06024664 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06024674; } }  // 06024666 bf/s 0x06024674 ; mov r10,r1
    c.r[3] = ld32(0x060246ECu);  // 0602466A mov.l 0x060246EC,r3
    c.r[2] = ld32(0x060246F4u);  // 0602466C mov.l 0x060246F4,r2
    st8(c.r[2], c.r[1]);  // 0602466E mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024670 extu.b r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 06024672 mov.l r1,@(20,r3)
L_06024674:
    c.r[1] = ld32(0x060246F8u);  // 06024674 mov.l 0x060246F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602467Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602467Au) return; }  // 06024676 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_060246CA;  // 0602467A bra 0x060246CA ; mov r14,r15
L_0602467E:
    c.r[0] = c.r[3];  // 0602467E mov r3,r0
    c.r[0] &= 0x7Fu;  // 06024680 and #127,r0
    c.t = (c.r[11] & c.r[11]) == 0;  // 06024682 tst r11,r11
    { const bool k = c.t; st8(c.r[7], c.r[0]); if (k) { goto L_060246B8; } }  // 06024684 bt/s 0x060246B8 ; mov.b r0,@r7
    c.r[1] = ld32(c.r[13]);  // 06024688 mov.l @r13,r1
    c.r[1] += c.r[9];  // 0602468A add r9,r1
    c.r[1] += 2;  // 0602468C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602468E mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06024690 extu.b r1,r8
    c.t = c.r[8] == c.r[12];  // 06024692 cmp/eq r12,r8
    if (c.t) { goto L_060246B8; }  // 06024694 bt 0x060246B8
    c.r[1] = ld32(0x060246FCu);  // 06024696 mov.l 0x060246FC,r1
    c.r[2] = ld32(c.r[1]);  // 06024698 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602469A mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602469C mul.l r1,r8
    c.r[1] = c.macl;  // 0602469E sts macl,r1
    c.r[1] += c.r[2];  // 060246A0 add r2,r1
    c.r[1] += 15;  // 060246A2 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060246A4 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060246A6 extu.b r1,r4
    c.t = c.r[4] == c.r[12];  // 060246A8 cmp/eq r12,r4
    if (c.t) { goto L_060246B8; }  // 060246AA bt 0x060246B8
    c.r[1] = ld32(0x06024700u);  // 060246AC mov.l 0x06024700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060246B2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060246B2u) return; }  // 060246AE jsr @r1 ; nop
    c.r[1] = ld32(0x06024704u);  // 060246B2 mov.l 0x06024704,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060246B8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060246B8u) return; }  // 060246B4 jsr @r1 ; mov r8,r4
L_060246B8:
    c.r[1] = ld32(0x06024708u);  // 060246B8 mov.l 0x06024708,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060246BEu; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060246BEu) return; }  // 060246BA jsr @r1 ; extu.b r10,r4
L_060246BE:
    c.r[10] += 1;  // 060246BE add #1,r10
    c.r[1] = 0x49u;  // 060246C0 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060246C2 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_06024626; } }  // 060246C4 bf/s 0x06024626 ; add #16,r9
    c.r[15] = c.r[14];  // 060246C8 mov r14,r15
L_060246CA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060246CA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060246CC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060246CE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060246D0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060246D2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060246D4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060246D6 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060246E0u);  // 060246D8 mov.w 0x060246E0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060246DA rts ; mov.l @r15+,r8
}

void f_0602470C(SH2Context& c) {
    ran[470] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602470C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602470E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024710 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024712 sts.l pr,@-r15
    c.r[1] = ld32(0x060247D4u);  // 06024714 mov.l 0x060247D4,r1
    c.r[2] = ld32(c.r[1]);  // 06024716 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06024718 mov r2,r1
    c.r[1] += 1;  // 0602471A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602471C mov.b @r1,r1
    c.r[2] += 2;  // 0602471E add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024720 extu.b r1,r1
    c.r[8] = c.r[1];  // 06024722 mov r1,r8
    c.r[8] <<= 8;  // 06024724 shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024726 mov.b @r2,r1
    c.r[14] = c.r[15];  // 06024728 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0602472A extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602472C or r1,r8
    c.r[1] = ld32(0x060247D8u);  // 0602472E mov.l 0x060247D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024734u; c.r[9] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024734u) return; }  // 06024730 jsr @r1 ; mov r8,r9
    c.r[1] = c.r[8];  // 06024734 mov r8,r1
    c.r[1] >>= 8;  // 06024736 shlr8 r1
    c.r[1] += c.r[1];  // 06024738 add r1,r1
    c.r[1] >>= 8;  // 0602473A shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602473C tst r1,r1
    if (!c.t) { goto L_06024780; }  // 0602473E bf 0x06024780
    c.r[1] = (uint32_t)(int16_t)ld16(0x060247CCu);  // 06024740 mov.w 0x060247CC,r1
    c.r[8] &= c.r[1];  // 06024742 and r1,r8
    c.r[0] = ld32(0x060247DCu);  // 06024744 mov.l 0x060247DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602474Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602474Au) return; }  // 06024746 jsr @r0 ; mov r8,r4
    c.r[6] = c.r[0] & 0xFFu;  // 0602474A extu.b r0,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060247CEu);  // 0602474C mov.w 0x060247CE,r3
    c.t = c.r[6] == c.r[3];  // 0602474E cmp/eq r3,r6
    if (c.t) { goto L_060247BE; }  // 06024750 bt 0x060247BE
    c.r[1] = ld32(0x060247E0u);  // 06024752 mov.l 0x060247E0,r1
    c.r[2] = ld32(c.r[1]);  // 06024754 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06024756 mov #30,r1
    c.macl = c.r[6] * c.r[1];  // 06024758 mul.l r1,r6
    c.r[1] = c.macl;  // 0602475A sts macl,r1
    c.r[1] += c.r[2];  // 0602475C add r2,r1
    c.r[1] += 15;  // 0602475E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024760 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06024762 extu.b r1,r4
    c.t = c.r[4] == c.r[3];  // 06024764 cmp/eq r3,r4
    if (c.t) { goto L_060247BE; }  // 06024766 bt 0x060247BE
    c.r[3] = ld32(0x060247E4u);  // 06024768 mov.l 0x060247E4,r3
    c.r[1] = ld32(0x060247E8u);  // 0602476A mov.l 0x060247E8,r1
    c.r[2] = ld32(c.r[1]);  // 0602476C mov.l @r1,r2
    c.r[7] = c.r[3];  // 0602476E mov r3,r7
    c.r[1] = c.r[4];  // 06024770 mov r4,r1
    c.r[1] += c.r[1];  // 06024772 add r1,r1
    c.r[1] += c.r[4];  // 06024774 add r4,r1
    c.r[1] <<= 2;  // 06024776 shll2 r1
    c.r[0] = c.r[1];  // 06024778 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602477A mov.w @(r0,r2),r1
    c.r[7] += 26; goto L_060247B2;  // 0602477C bra 0x060247B2 ; add #26,r7
L_06024780:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060247CCu);  // 06024780 mov.w 0x060247CC,r1
    c.r[9] &= c.r[1];  // 06024782 and r1,r9
    c.r[0] = ld32(0x060247ECu);  // 06024784 mov.l 0x060247EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602478Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602478Au) return; }  // 06024786 jsr @r0 ; mov r9,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0602478A extu.b r0,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x060247CEu);  // 0602478C mov.w 0x060247CE,r8
    c.t = c.r[4] == c.r[8];  // 0602478E cmp/eq r8,r4
    if (c.t) { goto L_060247BE; }  // 06024790 bt 0x060247BE
    c.r[0] = ld32(0x060247F0u);  // 06024792 mov.l 0x060247F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024798u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024798u) return; }  // 06024794 jsr @r0 ; nop
    c.r[6] = c.r[0] & 0xFFu;  // 06024798 extu.b r0,r6
    c.t = c.r[6] == c.r[8];  // 0602479A cmp/eq r8,r6
    if (c.t) { goto L_060247BE; }  // 0602479C bt 0x060247BE
    c.r[1] = ld32(0x060247E0u);  // 0602479E mov.l 0x060247E0,r1
    c.r[2] = ld32(c.r[1]);  // 060247A0 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060247A2 mov #30,r1
    c.macl = c.r[6] * c.r[1];  // 060247A4 mul.l r1,r6
    c.r[3] = ld32(0x060247E4u);  // 060247A6 mov.l 0x060247E4,r3
    c.r[7] = c.r[3];  // 060247A8 mov r3,r7
    c.r[1] = c.macl;  // 060247AA sts macl,r1
    c.r[0] = c.macl;  // 060247AC sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060247AE mov.w @(r0,r2),r1
    c.r[7] += 28;  // 060247B0 add #28,r7
L_060247B2:
    st16(c.r[7], c.r[1]);  // 060247B2 mov.w r1,@r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 060247B4 extu.w r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 060247B6 mov.l r1,@(20,r3)
    c.r[1] = ld32(0x060247F4u);  // 060247B8 mov.l 0x060247F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060247BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060247BEu) return; }  // 060247BA jsr @r1 ; nop
L_060247BE:
    c.r[15] = c.r[14];  // 060247BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060247C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060247C2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060247C4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060247D0u);  // 060247C6 mov.w 0x060247D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060247C8 rts ; mov.l @r15+,r8
}

void f_060247F8(SH2Context& c) {
    ran[471] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060247F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060247FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060247FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060247FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06024800 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06024802 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024804 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024806 sts.l pr,@-r15
    c.r[15] -= 16;  // 06024808 add #-16,r15
    c.r[14] = c.r[15];  // 0602480A mov r15,r14
    c.r[10] = ld32(0x06024968u);  // 0602480C mov.l 0x06024968,r10
    c.r[2] = ld32(c.r[10]);  // 0602480E mov.l @r10,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024962u);  // 06024810 mov.w 0x06024962,r0
    c.r[1] = c.r[2];  // 06024812 mov r2,r1
    c.r[1] += 1;  // 06024814 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024816 mov.b @r1,r8
    c.r[2] += 2;  // 06024818 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0602481A extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602481C mov.b @r2,r1
    c.r[8] <<= 8;  // 0602481E shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 06024820 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06024822 or r1,r8
    c.r[9] = c.r[8];  // 06024824 mov r8,r9
    st32(c.r[14] + 8, c.r[0]);  // 06024826 mov.l r0,@(8,r14)
    c.r[0] = 0x3u;  // 06024828 mov #3,r0
    c.r[1] = ld32(0x0602496Cu);  // 0602482A mov.l 0x0602496C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024830u; st32(c.r[14] + 12, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024830u) return; }  // 0602482C jsr @r1 ; mov.l r0,@(12,r14)
    c.r[8] >>= 8;  // 06024830 shlr8 r8
    c.r[8] += c.r[8];  // 06024832 add r8,r8
    c.r[8] >>= 8;  // 06024834 shlr8 r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06024836 tst r8,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0602484C; } }  // 06024838 bt/s 0x0602484C ; mov #0,r0
    c.r[1] = ld32(c.r[10]);  // 0602483C mov.l @r10,r1
    c.r[1] += 3;  // 0602483E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024840 mov.b @r1,r1
    c.r[0] = 0x4u;  // 06024842 mov #4,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06024844 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 06024846 mov.l r1,@(8,r14)
    st32(c.r[14] + 12, c.r[0]);  // 06024848 mov.l r0,@(12,r14)
    c.r[0] = 0x0u;  // 0602484A mov #0,r0
L_0602484C:
    st32(c.r[14], c.r[0]);  // 0602484C mov.l r0,@r14
    st32(c.r[14] + 4, c.r[0]);  // 0602484E mov.l r0,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024964u);  // 06024850 mov.w 0x06024964,r1
    c.r[9] &= c.r[1];  // 06024852 and r1,r9
    c.r[0] = ld32(0x06024970u);  // 06024854 mov.l 0x06024970,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602485Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602485Au) return; }  // 06024856 jsr @r0 ; mov r9,r4
    c.r[1] = c.r[0];  // 0602485A mov r0,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0602485C extu.b r1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024962u);  // 0602485E mov.w 0x06024962,r1
    c.t = c.r[13] == c.r[1];  // 06024860 cmp/eq r1,r13
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_0602486A; } }  // 06024862 bf/s 0x0602486A ; mov.l @(12,r14),r0
    goto L_060249C0;  // 06024866 bra 0x060249C0 ; nop
L_0602486A:
    c.r[10] = 0x0u;  // 0602486A mov #0,r10
    c.r[1] = 0x1Eu;  // 0602486C mov #30,r1
L_0602486E:
    c.macl = c.r[10] * c.r[1];  // 0602486E mul.l r1,r10
    c.r[0] = ld32(0x06024974u);  // 06024870 mov.l 0x06024974,r0
    c.r[2] = ld32(c.r[0]);  // 06024872 mov.l @r0,r2
    c.r[8] = c.macl;  // 06024874 sts macl,r8
    c.r[2] += c.r[8];  // 06024876 add r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06024878 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602487A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602487C tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06024886; } }  // 0602487E bf/s 0x06024886 ; mov r10,r1
    goto L_0602498A;  // 06024882 bra 0x0602498A ; nop
L_06024886:
    c.r[1] = c.r[2];  // 06024886 mov r2,r1
    c.r[1] += 15;  // 06024888 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602488A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602488C extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024962u);  // 0602488E mov.w 0x06024962,r1
    c.t = c.r[3] == c.r[1];  // 06024890 cmp/eq r1,r3
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0602498A; } }  // 06024892 bf/s 0x0602498A ; mov r10,r1
    c.r[2] += 16;  // 06024896 add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024898 mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0602489A extu.b r1,r9
    c.t = c.r[9] == c.r[3];  // 0602489C cmp/eq r3,r9
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0602498A; } }  // 0602489E bf/s 0x0602498A ; mov r10,r1
    c.r[0] = ld32(0x06024978u);  // 060248A2 mov.l 0x06024978,r0
    c.r[5] = c.r[13];  // 060248A4 mov r13,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060248AAu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060248AAu) return; }  // 060248A6 jsr @r0 ; mov r10,r4
    c.r[1] = c.r[0] & 0xFFu;  // 060248AA extu.b r0,r1
    c.t = c.r[1] == c.r[9];  // 060248AC cmp/eq r9,r1
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_0602498A; } }  // 060248AE bt/s 0x0602498A ; mov r10,r1
    c.r[0] = ld32(0x06024974u);  // 060248B2 mov.l 0x06024974,r0
    c.r[1] = ld32(c.r[0]);  // 060248B4 mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 060248B6 mov #27,r5
    c.r[0] = c.r[8];  // 060248B8 mov r8,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060248BA mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0602497Cu);  // 060248BC mov.l 0x0602497C,r4
    c.r[0] = ld32(0x06024980u);  // 060248BE mov.l 0x06024980,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060248C4u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060248C4u) return; }  // 060248C0 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060248C4 mov r0,r1
    c.r[5] = c.r[8];  // 060248C6 mov r8,r5
    c.r[0] = ld32(0x06024980u);  // 060248C8 mov.l 0x06024980,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060248CEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060248CEu) return; }  // 060248CA jsr @r0 ; mov r1,r4
    c.r[3] = c.r[0];  // 060248CE mov r0,r3
    c.r[1] = c.r[3];  // 060248D0 mov r3,r1
    c.r[1] += 5;  // 060248D2 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060248D4 mov.b @r1,r2
    c.r[12] = 0xFu;  // 060248D6 mov #15,r12
    c.r[0] = ld32(c.r[14] + 8);  // 060248D8 mov.l @(8,r14),r0
    c.r[12] &= c.r[2];  // 060248DA and r2,r12
    c.r[1] = c.r[3];  // 060248DC mov r3,r1
    c.r[1] += 4;  // 060248DE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060248E0 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060248E2 extu.b r2,r2
    c.r[11] = c.r[1] & 0xFFu;  // 060248E4 extu.b r1,r11
    c.r[11] <<= 8;  // 060248E6 shll8 r11
    c.r[11] |= c.r[2];  // 060248E8 or r2,r11
    c.r[11] >>= 2;  // 060248EA shlr2 r11
    c.r[11] >>= 2;  // 060248EC shlr2 r11
    c.t = c.r[0] == c.r[9];  // 060248EE cmp/eq r9,r0
    { const bool k = c.t; c.r[3] += 25; if (k) { goto L_06024900; } }  // 060248F0 bt/s 0x06024900 ; add #25,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060248F4 mov.b @r3,r1
    c.r[0] = 0xFu;  // 060248F6 mov #15,r0
    c.r[1] &= c.r[0];  // 060248F8 and r0,r1
    c.r[0] = ld32(c.r[14] + 8);  // 060248FA mov.l @(8,r14),r0
    c.t = c.r[1] == c.r[0];  // 060248FC cmp/eq r0,r1
    if (c.t) { goto L_06024988; }  // 060248FE bt 0x06024988
L_06024900:
    c.r[1] = ld32(0x06024984u);  // 06024900 mov.l 0x06024984,r1
    c.r[2] = c.r[13];  // 06024902 mov r13,r2
    c.r[2] += c.r[2];  // 06024904 add r2,r2
    c.r[2] += c.r[13];  // 06024906 add r13,r2
    c.r[2] <<= 2;  // 06024908 shll2 r2
    c.r[0] = c.r[2];  // 0602490A mov r2,r0
    c.r[1] = ld32(c.r[1]);  // 0602490C mov.l @r1,r1
    c.r[5] = 0x1Cu;  // 0602490E mov #28,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06024910 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0602497Cu);  // 06024912 mov.l 0x0602497C,r4
    c.r[0] = ld32(0x06024980u);  // 06024914 mov.l 0x06024980,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602491Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602491Au) return; }  // 06024916 jsr @r0 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602491A mov r0,r1
    c.r[5] = c.r[8];  // 0602491C mov r8,r5
    c.r[0] = ld32(0x06024980u);  // 0602491E mov.l 0x06024980,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024924u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024924u) return; }  // 06024920 jsr @r0 ; mov r1,r4
    c.r[3] = c.r[0];  // 06024924 mov r0,r3
    c.r[3] += 3;  // 06024926 add #3,r3
    c.r[0] = 0xFu;  // 06024928 mov #15,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602492A mov.b @r3,r1
    c.t = (c.r[11] & c.r[11]) == 0;  // 0602492C tst r11,r11
    { const bool k = !c.t; c.r[1] &= c.r[0]; if (k) { goto L_06024988; } }  // 0602492E bf/s 0x06024988 ; and r0,r1
    c.r[0] = c.r[1];  // 06024932 mov r1,r0
    c.t = c.r[0] == 0xFu;  // 06024934 cmp/eq #15,r0
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_06024944; } }  // 06024936 bt/s 0x06024944 ; mov r12,r0
    c.t = c.r[0] == 0xFu;  // 0602493A cmp/eq #15,r0
    { const bool k = c.t; c.t = c.r[1] == c.r[12]; if (k) { goto L_06024944; } }  // 0602493C bt/s 0x06024944 ; cmp/eq r12,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0602498A; } }  // 06024940 bf/s 0x0602498A ; mov r10,r1
L_06024944:
    c.r[1] = 0x1Eu;  // 06024944 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06024946 mul.l r1,r10
    c.r[0] = ld32(0x06024974u);  // 06024948 mov.l 0x06024974,r0
    c.r[2] = ld32(c.r[0]);  // 0602494A mov.l @r0,r2
    c.r[1] = c.macl;  // 0602494C sts macl,r1
    c.r[1] += c.r[2];  // 0602494E add r2,r1
    c.r[1] += 22;  // 06024950 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06024952 mov.w @r1,r1
    c.r[0] = ld32(c.r[14]);  // 06024954 mov.l @r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06024956 extu.w r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06024958 cmp/ge r1,r0
    if (c.t) { goto L_06024988; }  // 0602495A bt 0x06024988
    st32(c.r[14], c.r[1]);  // 0602495C mov.l r1,@r14
    st32(c.r[14] + 4, c.r[10]); goto L_06024988;  // 0602495E bra 0x06024988 ; mov.l r10,@(4,r14)
L_06024988:
    c.r[1] = c.r[10];  // 06024988 mov r10,r1
L_0602498A:
    c.r[1] += 1;  // 0602498A add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0602498C extu.b r1,r10
    c.r[1] = 0x7Fu;  // 0602498E mov #127,r1
    c.t = c.r[10] > c.r[1];  // 06024990 cmp/hi r1,r10
    { const bool k = c.t; c.r[1] = 0x1Eu; if (k) { goto L_0602499A; } }  // 06024992 bt/s 0x0602499A ; mov #30,r1
    SH2_POLL(c); goto L_0602486E;  // 06024996 bra 0x0602486E ; nop
L_0602499A:
    c.r[0] = ld32(c.r[14]);  // 0602499A mov.l @r14,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602499C tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_060249C0; } }  // 0602499E bt/s 0x060249C0 ; mov.l @(12,r14),r0
    c.r[1] = ld32(0x060249E0u);  // 060249A2 mov.l 0x060249E0,r1
    c.r[2] = ld32(c.r[1]);  // 060249A4 mov.l @r1,r2
    c.r[0] = ld32(c.r[14] + 4);  // 060249A6 mov.l @(4,r14),r0
    c.r[1] = 0x1Eu;  // 060249A8 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 060249AA mul.l r1,r0
    c.r[1] = c.macl;  // 060249AC sts macl,r1
    c.r[0] = c.r[1];  // 060249AE mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060249B0 mov.w @(r0,r2),r1
    c.r[3] = ld32(0x060249E4u);  // 060249B2 mov.l 0x060249E4,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 060249B4 extu.w r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 060249B6 mov.l r1,@(20,r3)
    c.r[1] = ld32(0x060249E8u);  // 060249B8 mov.l 0x060249E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060249BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060249BEu) return; }  // 060249BA jsr @r1 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 060249BE mov.l @(12,r14),r0
L_060249C0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060249DEu);  // 060249C0 mov.w 0x060249DE,r1
    c.r[0] |= c.r[1];  // 060249C2 or r1,r0
    st32(c.r[14] + 12, c.r[0]);  // 060249C4 mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 060249C6 mov.l @(12,r14),r0
    c.r[14] += 16;  // 060249C8 add #16,r14
    c.r[15] = c.r[14];  // 060249CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060249CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060249CE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060249D0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060249D2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060249D4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060249D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060249D8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060249DA rts ; mov.l @r15+,r8
}

void f_060249EC(SH2Context& c) {
    ran[472] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060249EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060249EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060249F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060249F2 sts.l pr,@-r15
    c.r[1] = ld32(0x06024AC0u);  // 060249F4 mov.l 0x06024AC0,r1
    c.r[3] = ld32(c.r[1]);  // 060249F6 mov.l @r1,r3
    c.r[1] = c.r[3];  // 060249F8 mov r3,r1
    c.r[1] += 2;  // 060249FA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060249FC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060249FE extu.b r2,r2
    c.r[1] = c.r[3];  // 06024A00 mov r3,r1
    c.r[1] += 3;  // 06024A02 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024A04 mov.b @r1,r1
    c.r[2] <<= 8;  // 06024A06 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024A08 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06024A0A or r1,r2
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06024A0C exts.w r2,r9
    c.r[0] = c.r[9];  // 06024A0E mov r9,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06024A10 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06024A1A; } }  // 06024A12 bf/s 0x06024A1A ; mov r15,r14
    c.r[1] = ld32(0x06024AC4u);  // 06024A16 mov.l 0x06024AC4,r1
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06024A18 mov.w @r1,r9
L_06024A1A:
    c.r[3] += 1;  // 06024A1A add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06024A1C mov.b @r3,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06024A1E extu.b r1,r8
    c.r[1] = ld32(0x06024AC8u);  // 06024A20 mov.l 0x06024AC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024A26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024A26u) return; }  // 06024A22 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024ABCu);  // 06024A26 mov.w 0x06024ABC,r1
    c.r[1] &= c.r[8];  // 06024A28 and r8,r1
    c.r[0] = 0x3u;  // 06024A2A mov #3,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 06024A2C tst r1,r1
    { const bool k = !c.t; c.r[8] &= c.r[0]; if (k) { goto L_06024A68; } }  // 06024A2E bf/s 0x06024A68 ; and r0,r8
    c.r[7] = 0x0u;  // 06024A32 mov #0,r7
    c.r[3] = 0x0u;  // 06024A34 mov #0,r3
L_06024A36:
    c.r[1] = ld32(0x06024ACCu);  // 06024A36 mov.l 0x06024ACC,r1
    c.r[0] = ld32(c.r[1]);  // 06024A38 mov.l @r1,r0
    c.r[2] = c.r[3];  // 06024A3A mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06024A3C mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06024A3E extu.w r1,r1
    c.t = c.r[1] == c.r[9];  // 06024A40 cmp/eq r9,r1
    { const bool k = !c.t; c.r[2] += c.r[0]; if (k) { goto L_06024A5A; } }  // 06024A42 bf/s 0x06024A5A ; add r0,r2
    c.r[2] += 3;  // 06024A46 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024A48 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06024A4A mov r1,r0
    c.r[0] >>= 2;  // 06024A4C shlr2 r0
    c.r[0] >>= 2;  // 06024A4E shlr2 r0
    c.r[0] &= 0x3u;  // 06024A50 and #3,r0
    c.t = c.r[0] == c.r[8];  // 06024A52 cmp/eq r8,r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06024A9A; } }  // 06024A54 bt/s 0x06024A9A ; tst r8,r8
    if (c.t) { goto L_06024A9A; }  // 06024A58 bt 0x06024A9A
L_06024A5A:
    c.r[7] += 1;  // 06024A5A add #1,r7
    c.r[1] = 0x7Fu;  // 06024A5C mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06024A5E cmp/gt r1,r7
    { const bool k = !c.t; c.r[3] += 12; if (k) { SH2_POLL(c); goto L_06024A36; } }  // 06024A60 bf/s 0x06024A36 ; add #12,r3
    c.r[15] = c.r[14]; goto L_06024AB0;  // 06024A64 bra 0x06024AB0 ; mov r14,r15
L_06024A68:
    c.r[0] = ld32(0x06024AD0u);  // 06024A68 mov.l 0x06024AD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024A6Eu; c.r[4] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024A6Eu) return; }  // 06024A6A jsr @r0 ; extu.w r9,r4
    c.r[7] = 0x0u;  // 06024A6E mov #0,r7
    c.r[3] = 0x0u;  // 06024A70 mov #0,r3
L_06024A72:
    c.r[1] = ld32(0x06024AD4u);  // 06024A72 mov.l 0x06024AD4,r1
    c.r[0] = ld32(c.r[1]);  // 06024A74 mov.l @r1,r0
    c.r[2] = c.r[3];  // 06024A76 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06024A78 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06024A7A extu.w r1,r1
    c.t = c.r[1] == c.r[9];  // 06024A7C cmp/eq r9,r1
    { const bool k = !c.t; c.r[2] += c.r[0]; if (k) { goto L_06024AA4; } }  // 06024A7E bf/s 0x06024AA4 ; add r0,r2
    c.r[2] += 2;  // 06024A82 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024A84 mov.b @r2,r2
    c.r[1] = c.r[8] & 0xFFFFu;  // 06024A86 extu.w r8,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06024A88 extu.b r2,r2
    c.r[2] >>= 2;  // 06024A8A shlr2 r2
    c.r[2] >>= 2;  // 06024A8C shlr2 r2
    c.r[2] >>= 2;  // 06024A8E shlr2 r2
    c.t = c.r[2] == c.r[1];  // 06024A90 cmp/eq r1,r2
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06024A9A; } }  // 06024A92 bt/s 0x06024A9A ; tst r8,r8
    { const bool k = !c.t; c.r[7] += 1; if (k) { goto L_06024AA6; } }  // 06024A96 bf/s 0x06024AA6 ; add #1,r7
L_06024A9A:
    c.r[1] = ld32(0x06024AD8u);  // 06024A9A mov.l 0x06024AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024AA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024AA0u) return; }  // 06024A9C jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_06024AB0;  // 06024AA0 bra 0x06024AB0 ; mov r14,r15
L_06024AA4:
    c.r[7] += 1;  // 06024AA4 add #1,r7
L_06024AA6:
    c.r[1] = 0x7Fu;  // 06024AA6 mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06024AA8 cmp/gt r1,r7
    { const bool k = !c.t; c.r[3] += 30; if (k) { SH2_POLL(c); goto L_06024A72; } }  // 06024AAA bf/s 0x06024A72 ; add #30,r3
    c.r[15] = c.r[14];  // 06024AAE mov r14,r15
L_06024AB0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024AB0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024AB2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06024AB4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024ABEu);  // 06024AB6 mov.w 0x06024ABE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024AB8 rts ; mov.l @r15+,r8
}

void f_06024ADC(SH2Context& c) {
    ran[473] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06024ADC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06024ADE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024AE0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024AE2 sts.l pr,@-r15
    c.r[1] = ld32(0x06024BA4u);  // 06024AE4 mov.l 0x06024BA4,r1
    c.r[2] = ld32(c.r[1]);  // 06024AE6 mov.l @r1,r2
    c.r[15] -= 76;  // 06024AE8 add #-76,r15
    c.r[1] = c.r[2];  // 06024AEA mov r2,r1
    c.r[1] += 1;  // 06024AEC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024AEE mov.b @r1,r1
    c.r[2] += 2;  // 06024AF0 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024AF2 extu.b r1,r1
    c.r[8] = c.r[1];  // 06024AF4 mov r1,r8
    c.r[8] <<= 8;  // 06024AF6 shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024AF8 mov.b @r2,r1
    c.r[14] = c.r[15];  // 06024AFA mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06024AFC extu.b r1,r1
    c.r[8] |= c.r[1];  // 06024AFE or r1,r8
    c.r[1] = ld32(0x06024BA8u);  // 06024B00 mov.l 0x06024BA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024B06u; c.r[9] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024B06u) return; }  // 06024B02 jsr @r1 ; mov r8,r9
    c.r[1] = c.r[8];  // 06024B06 mov r8,r1
    c.r[1] >>= 8;  // 06024B08 shlr8 r1
    c.r[1] += c.r[1];  // 06024B0A add r1,r1
    c.r[1] >>= 8;  // 06024B0C shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06024B0E tst r1,r1
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06024B2A; } }  // 06024B10 bf/s 0x06024B2A ; mov #0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024B9Eu);  // 06024B14 mov.w 0x06024B9E,r1
    c.r[8] &= c.r[1];  // 06024B16 and r1,r8
    c.r[1] = ld32(0x06024BACu);  // 06024B18 mov.l 0x06024BAC,r1
    c.r[4] = ld32(c.r[1]);  // 06024B1A mov.l @r1,r4
    c.r[0] = ld32(0x06024BB0u);  // 06024B1C mov.l 0x06024BB0,r0
    c.r[6] = c.r[8];  // 06024B1E mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06024B24u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024B24u) return; }  // 06024B20 jsr @r0 ; mov r14,r5
    c.r[1] = ld32(0x06024BB4u);  // 06024B24 mov.l 0x06024BB4,r1
    st32(c.r[1] + 20, c.r[0]); goto L_06024B82;  // 06024B26 bra 0x06024B82 ; mov.l r0,@(20,r1)
L_06024B2A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024B9Eu);  // 06024B2A mov.w 0x06024B9E,r1
    c.r[9] &= c.r[1];  // 06024B2C and r1,r9
    c.r[8] = ld32(0x06024BACu);  // 06024B2E mov.l 0x06024BAC,r8
    c.r[4] = ld32(c.r[8]);  // 06024B30 mov.l @r8,r4
    c.r[0] = ld32(0x06024BB0u);  // 06024B32 mov.l 0x06024BB0,r0
    c.r[7] = 0x1u;  // 06024B34 mov #1,r7
    c.r[6] = c.r[9];  // 06024B36 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06024B3Cu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024B3Cu) return; }  // 06024B38 jsr @r0 ; mov r14,r5
    c.r[2] = ld32(0x06024BB4u);  // 06024B3C mov.l 0x06024BB4,r2
    st32(c.r[2] + 20, c.r[0]);  // 06024B3E mov.l r0,@(20,r2)
    c.r[3] = c.r[0];  // 06024B40 mov r0,r3
    c.r[0] = 0x0u;  // 06024B42 mov #0,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06024B44 cmp/ge r3,r0
    if (c.t) { goto L_06024B80; }  // 06024B46 bt 0x06024B80
    c.r[4] = ld32(c.r[8]);  // 06024B48 mov.l @r8,r4
    c.r[1] = ld32(0x06024BB8u);  // 06024B4A mov.l 0x06024BB8,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06024BA0u);  // 06024B4C mov.w 0x06024BA0,r5
    c.r[7] = c.r[2];  // 06024B4E mov r2,r7
    c.r[6] = ld32(c.r[1]);  // 06024B50 mov.l @r1,r6
L_06024B52:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06024B52 mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06024B54 extu.b r1,r1
    c.r[1] <<= 2;  // 06024B56 shll2 r1
    c.r[1] <<= 2;  // 06024B58 shll2 r1
    c.r[1] += c.r[4];  // 06024B5A add r4,r1
    c.r[1] += 2;  // 06024B5C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024B5E mov.b @r1,r1
    c.r[2] = 0x1Eu;  // 06024B60 mov #30,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024B62 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06024B64 mul.l r2,r1
    c.r[1] = c.macl;  // 06024B66 sts macl,r1
    c.r[1] += c.r[6];  // 06024B68 add r6,r1
    c.r[1] += 16;  // 06024B6A add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024B6C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06024B6E extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06024B70 cmp/eq r5,r1
    if (c.t) { goto L_06024B7A; }  // 06024B72 bt 0x06024B7A
    c.r[1] = ld32(c.r[7] + 20);  // 06024B74 mov.l @(20,r7),r1
    c.r[1] -= 1;  // 06024B76 add #-1,r1
    st32(c.r[7] + 20, c.r[1]);  // 06024B78 mov.l r1,@(20,r7)
L_06024B7A:
    c.r[0] += 1;  // 06024B7A add #1,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06024B7C cmp/ge r3,r0
    if (!c.t) { SH2_POLL(c); goto L_06024B52; }  // 06024B7E bf 0x06024B52
L_06024B80:
    c.r[1] = ld32(0x06024BB4u);  // 06024B80 mov.l 0x06024BB4,r1
L_06024B82:
    c.r[1] = ld32(c.r[1] + 20);  // 06024B82 mov.l @(20,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06024B84 tst r1,r1
    if (c.t) { goto L_06024B8E; }  // 06024B86 bt 0x06024B8E
    c.r[1] = ld32(0x06024BBCu);  // 06024B88 mov.l 0x06024BBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024B8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024B8Eu) return; }  // 06024B8A jsr @r1 ; nop
L_06024B8E:
    c.r[14] += 76;  // 06024B8E add #76,r14
    c.r[15] = c.r[14];  // 06024B90 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024B92 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024B94 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06024B96 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024BA2u);  // 06024B98 mov.w 0x06024BA2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024B9A rts ; mov.l @r15+,r8
}

void f_06024BC0(SH2Context& c) {
    ran[474] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06024BC0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06024BC2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06024BC4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06024BC6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06024BC8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06024BCA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024BCC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024BCE sts.l pr,@-r15
    c.r[15] -= 88;  // 06024BD0 add #-88,r15
    c.r[14] = c.r[15];  // 06024BD2 mov r15,r14
    c.r[1] = ld32(0x06024CF4u);  // 06024BD4 mov.l 0x06024CF4,r1
    c.r[0] = 0x4Cu;  // 06024BD6 mov #76,r0
    c.r[0] += c.r[14];  // 06024BD8 add r14,r0
    c.r[2] = ld32(c.r[1]);  // 06024BDA mov.l @r1,r2
    c.r[12] = 0x50u;  // 06024BDC mov #80,r12
    c.r[1] = c.r[2];  // 06024BDE mov r2,r1
    c.r[1] += 1;  // 06024BE0 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024BE2 mov.b @r1,r8
    c.r[12] += c.r[14];  // 06024BE4 add r14,r12
    c.r[8] = c.r[8] & 0xFFu;  // 06024BE6 extu.b r8,r8
    c.r[1] = c.r[2];  // 06024BE8 mov r2,r1
    c.r[1] += 2;  // 06024BEA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024BEC mov.b @r1,r1
    c.r[8] <<= 8;  // 06024BEE shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 06024BF0 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06024BF2 or r1,r8
    c.r[1] = c.r[2];  // 06024BF4 mov r2,r1
    c.r[1] += 3;  // 06024BF6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024BF8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06024BFA extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06024BFC mov.l r1,@r0
    c.r[1] = c.r[2];  // 06024BFE mov r2,r1
    c.r[1] += 4;  // 06024C00 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024C02 mov.b @r1,r1
    c.r[0] = 0x54u;  // 06024C04 mov #84,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06024C06 extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 06024C08 mov.l r1,@r12
    c.r[1] = c.r[2];  // 06024C0A mov r2,r1
    c.r[1] += 5;  // 06024C0C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024C0E mov.b @r1,r1
    c.r[2] += 6;  // 06024C10 add #6,r2
    c.r[13] = c.r[1] & 0xFFu;  // 06024C12 extu.b r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024C14 mov.b @r2,r1
    c.r[0] += c.r[14];  // 06024C16 add r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06024C18 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06024C1A mov.l r1,@r0
    c.r[1] = ld32(0x06024CF8u);  // 06024C1C mov.l 0x06024CF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024C22u; c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024C22u) return; }  // 06024C1E jsr @r1 ; exts.w r8,r8
    c.r[2] = ld32(0x06024CFCu);  // 06024C22 mov.l 0x06024CFC,r2
    c.r[1] = 0x0u;  // 06024C24 mov #0,r1
    st32(c.r[2] + 20, c.r[1]);  // 06024C26 mov.l r1,@(20,r2)
    c.r[1] = ld32(0x06024D00u);  // 06024C28 mov.l 0x06024D00,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06024CECu);  // 06024C2A mov.w 0x06024CEC,r10
    c.r[7] = 0x0u;  // 06024C2C mov #0,r7
    c.r[6] = c.r[8];  // 06024C2E mov r8,r6
    c.r[2] = ld32(c.r[1]);  // 06024C30 mov.l @r1,r2
    c.r[5] = c.r[14];  // 06024C32 mov r14,r5
    c.r[1] = 0x0u;  // 06024C34 mov #0,r1
    c.r[0] = c.r[2];  // 06024C36 mov r2,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 06024C38 mov.b r1,@(r0,r10)
    c.r[1] = ld32(0x06024D04u);  // 06024C3A mov.l 0x06024D04,r1
    c.r[12] = ld32(0x06024D08u);  // 06024C3C mov.l 0x06024D08,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06024C42u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024C42u) return; }  // 06024C3E jsr @r12 ; mov.l @r1,r4
    c.r[11] = c.r[0];  // 06024C42 mov r0,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 06024C44 tst r11,r11
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06024CD4; } }  // 06024C46 bt/s 0x06024CD4 ; mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06024C4A cmp/ge r11,r9
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06024CBC; } }  // 06024C4C bt/s 0x06024CBC ; mov r14,r0
L_06024C50:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06024C50 mov.b @(r0,r9),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06024C52 extu.b r1,r8
    c.r[1] = ld32(0x06024D0Cu);  // 06024C54 mov.l 0x06024D0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024C5Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024C5Au) return; }  // 06024C56 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06024D04u);  // 06024C5A mov.l 0x06024D04,r1
    c.r[3] = c.r[8];  // 06024C5C mov r8,r3
    c.r[3] <<= 2;  // 06024C5E shll2 r3
    c.r[3] <<= 2;  // 06024C60 shll2 r3
    c.r[2] = c.r[3];  // 06024C62 mov r3,r2
    c.r[0] = c.r[3];  // 06024C64 mov r3,r0
    c.r[1] = ld32(c.r[1]);  // 06024C66 mov.l @r1,r1
    c.r[12] = 0x4Cu;  // 06024C68 mov #76,r12
    c.r[2] += c.r[1];  // 06024C6A add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06024C6C mov.b @(r0,r1),r1
    c.r[12] += c.r[14];  // 06024C6E add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06024C70 mov.l @r12,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06024C72 extu.b r1,r1
    c.t = c.r[12] > c.r[1];  // 06024C74 cmp/hi r1,r12
    { const bool k = c.t; c.t = c.r[1] > c.r[13]; if (k) { goto L_06024CB4; } }  // 06024C76 bt/s 0x06024CB4 ; cmp/hi r13,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06024CB4; } }  // 06024C7A bt/s 0x06024CB4 ; add #1,r2
    c.r[0] = 0x50u;  // 06024C7E mov #80,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024C80 mov.b @r2,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06024C82 mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06024C84 extu.b r1,r1
    c.t = c.r[0] > c.r[1];  // 06024C86 cmp/hi r1,r0
    { const bool k = c.t; c.r[12] = 0x54u; if (k) { goto L_06024CB4; } }  // 06024C88 bt/s 0x06024CB4 ; mov #84,r12
    c.r[12] += c.r[14];  // 06024C8C add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06024C8E mov.l @r12,r12
    c.t = c.r[1] > c.r[12];  // 06024C90 cmp/hi r12,r1
    if (c.t) { goto L_06024CB4; }  // 06024C92 bt 0x06024CB4
    c.r[1] = ld32(0x06024D00u);  // 06024C94 mov.l 0x06024D00,r1
    c.r[3] = ld32(c.r[1]);  // 06024C96 mov.l @r1,r3
    c.r[0] = c.r[3];  // 06024C98 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06024C9A mov.b @(r0,r10),r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06024CEEu);  // 06024C9C mov.w 0x06024CEE,r12
    c.r[1] = c.r[2];  // 06024C9E mov r2,r1
    c.r[1] += 1;  // 06024CA0 add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 06024CA2 mov.b r1,@(r0,r10)
    c.r[1] = c.r[2] & 0xFFu;  // 06024CA4 extu.b r2,r1
    c.r[1] += c.r[1];  // 06024CA6 add r1,r1
    c.r[3] += c.r[1];  // 06024CA8 add r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06024CAA mov.b @(r0,r1),r2
    c.r[3] += 1;  // 06024CAC add #1,r3
    c.r[2] &= c.r[12];  // 06024CAE and r12,r2
    st8(c.r[0] + c.r[1], c.r[2]);  // 06024CB0 mov.b r2,@(r0,r1)
    st8(c.r[3], c.r[8]);  // 06024CB2 mov.b r8,@r3
L_06024CB4:
    c.r[9] += 1;  // 06024CB4 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06024CB6 cmp/ge r11,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06024C50; } }  // 06024CB8 bf/s 0x06024C50 ; mov r14,r0
L_06024CBC:
    c.r[1] = ld32(0x06024D00u);  // 06024CBC mov.l 0x06024D00,r1
    c.r[1] = ld32(c.r[1]);  // 06024CBE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024CECu);  // 06024CC0 mov.w 0x06024CEC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06024CC2 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x06024CFCu);  // 06024CC4 mov.l 0x06024CFC,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024CC6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06024CC8 tst r1,r1
    { const bool k = c.t; st32(c.r[2] + 20, c.r[1]); if (k) { goto L_06024CD4; } }  // 06024CCA bt/s 0x06024CD4 ; mov.l r1,@(20,r2)
    c.r[1] = ld32(0x06024D10u);  // 06024CCE mov.l 0x06024D10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024CD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024CD4u) return; }  // 06024CD0 jsr @r1 ; nop
L_06024CD4:
    c.r[14] += 88;  // 06024CD4 add #88,r14
    c.r[15] = c.r[14];  // 06024CD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024CD8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024CDA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06024CDC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06024CDE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06024CE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06024CE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06024CE4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024CF0u);  // 06024CE6 mov.w 0x06024CF0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024CE8 rts ; mov.l @r15+,r8
}

void f_06024D14(SH2Context& c) {
    ran[475] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024D14 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024D16 sts.l pr,@-r15
    c.r[1] = ld32(0x06024DA4u);  // 06024D18 mov.l 0x06024DA4,r1
    c.r[2] = ld32(c.r[1]);  // 06024D1A mov.l @r1,r2
    c.r[1] = c.r[2];  // 06024D1C mov r2,r1
    c.r[1] += 1;  // 06024D1E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024D20 mov.b @r1,r1
    c.r[2] += 2;  // 06024D22 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024D24 extu.b r1,r1
    c.r[4] = c.r[1];  // 06024D26 mov r1,r4
    c.r[4] <<= 8;  // 06024D28 shll8 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024D2A mov.b @r2,r1
    c.r[14] = c.r[15];  // 06024D2C mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06024D2E extu.b r1,r1
    c.r[4] |= c.r[1];  // 06024D30 or r1,r4
    c.r[1] = c.r[4];  // 06024D32 mov r4,r1
    c.r[1] >>= 8;  // 06024D34 shlr8 r1
    c.r[1] += c.r[1];  // 06024D36 add r1,r1
    c.r[1] >>= 8;  // 06024D38 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06024D3A tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_06024D66; } }  // 06024D3C bt/s 0x06024D66 ; mov r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024D9Cu);  // 06024D40 mov.w 0x06024D9C,r1
    c.r[0] = ld32(0x06024DA8u);  // 06024D42 mov.l 0x06024DA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024D48u; c.r[4] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024D48u) return; }  // 06024D44 jsr @r0 ; and r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06024D48 extu.b r0,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06024D9Eu);  // 06024D4A mov.w 0x06024D9E,r3
    c.t = c.r[0] == c.r[3];  // 06024D4C cmp/eq r3,r0
    if (c.t) { goto L_06024D92; }  // 06024D4E bt 0x06024D92
    c.r[1] = ld32(0x06024DACu);  // 06024D50 mov.l 0x06024DAC,r1
    c.r[2] = ld32(c.r[1]);  // 06024D52 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06024D54 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 06024D56 mul.l r1,r0
    c.r[1] = c.macl;  // 06024D58 sts macl,r1
    c.r[1] += c.r[2];  // 06024D5A add r2,r1
    c.r[1] += 15;  // 06024D5C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024D5E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06024D60 extu.b r1,r0
    c.t = c.r[0] == c.r[3]; goto L_06024D72;  // 06024D62 bra 0x06024D72 ; cmp/eq r3,r0
L_06024D66:
    c.r[0] = ld32(0x06024DB0u);  // 06024D66 mov.l 0x06024DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024D6Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024D6Cu) return; }  // 06024D68 jsr @r0 ; mov r2,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06024D6C extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024D9Eu);  // 06024D6E mov.w 0x06024D9E,r1
    c.t = c.r[0] == c.r[1];  // 06024D70 cmp/eq r1,r0
L_06024D72:
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_06024D92; } }  // 06024D72 bt/s 0x06024D92 ; mov r0,r2
    c.r[1] = ld32(0x06024DB4u);  // 06024D76 mov.l 0x06024DB4,r1
    c.r[2] += c.r[2];  // 06024D78 add r2,r2
    c.r[2] += c.r[0];  // 06024D7A add r0,r2
    c.r[1] = ld32(c.r[1]);  // 06024D7C mov.l @r1,r1
    c.r[2] <<= 2;  // 06024D7E shll2 r2
    c.r[2] += c.r[1];  // 06024D80 add r1,r2
    c.r[2] += 2;  // 06024D82 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024D84 mov.b @r2,r1
    c.r[3] = ld32(0x06024DB8u);  // 06024D86 mov.l 0x06024DB8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06024D88 extu.b r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 06024D8A mov.l r1,@(20,r3)
    c.r[1] = ld32(0x06024DBCu);  // 06024D8C mov.l 0x06024DBC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024D92u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024D92u) return; }  // 06024D8E jsr @r1 ; nop
L_06024D92:
    c.r[15] = c.r[14];  // 06024D92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024D94 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024DA0u);  // 06024D96 mov.w 0x06024DA0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024D98 rts ; mov.l @r15+,r14
}

void f_06024DC0(SH2Context& c) {
    ran[476] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024DC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024DC2 sts.l pr,@-r15
    c.r[1] = ld32(0x06024E3Cu);  // 06024DC4 mov.l 0x06024E3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024DCAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024DCAu) return; }  // 06024DC6 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06024E40u);  // 06024DCA mov.l 0x06024E40,r1
    c.r[2] = ld32(c.r[1]);  // 06024DCC mov.l @r1,r2
    c.r[0] = ld32(0x06024E44u);  // 06024DCE mov.l 0x06024E44,r0
    c.r[1] = c.r[2];  // 06024DD0 mov r2,r1
    c.r[1] += 1;  // 06024DD2 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024DD4 mov.b @r1,r4
    c.r[2] += 2;  // 06024DD6 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06024DD8 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024DDA mov.b @r2,r1
    c.r[4] <<= 8;  // 06024DDC shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06024DDE extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06024DE4u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024DE4u) return; }  // 06024DE0 jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06024DE4 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024E36u);  // 06024DE6 mov.w 0x06024E36,r1
    c.t = c.r[0] == c.r[1];  // 06024DE8 cmp/eq r1,r0
    { const bool k = c.t; c.r[0] <<= 2; if (k) { goto L_06024E2C; } }  // 06024DEA bt/s 0x06024E2C ; shll2 r0
    c.r[1] = ld32(0x06024E48u);  // 06024DEE mov.l 0x06024E48,r1
    c.r[1] = ld32(c.r[1]);  // 06024DF0 mov.l @r1,r1
    c.r[0] <<= 2;  // 06024DF2 shll2 r0
    c.r[0] += c.r[1];  // 06024DF4 add r1,r0
    c.r[0] += 2;  // 06024DF6 add #2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06024DF8 mov.b @r0,r2
    c.r[1] = ld32(0x06024E4Cu);  // 06024DFA mov.l 0x06024E4C,r1
    c.r[3] = ld32(c.r[1]);  // 06024DFC mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06024DFE extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06024E00 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06024E02 mul.l r1,r2
    c.r[1] = c.macl;  // 06024E04 sts macl,r1
    c.r[1] += c.r[3];  // 06024E06 add r3,r1
    c.r[1] += 15;  // 06024E08 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024E0A mov.b @r1,r1
    c.r[2] = ld32(0x06024E50u);  // 06024E0C mov.l 0x06024E50,r2
    c.r[2] = ld32(c.r[2]);  // 06024E0E mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024E10 extu.b r1,r1
    c.r[3] = c.r[1];  // 06024E12 mov r1,r3
    c.r[3] += c.r[3];  // 06024E14 add r3,r3
    c.r[3] += c.r[1];  // 06024E16 add r1,r3
    c.r[3] <<= 2;  // 06024E18 shll2 r3
    c.r[3] += c.r[2];  // 06024E1A add r2,r3
    c.r[3] += 6;  // 06024E1C add #6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06024E1E mov.w @r3,r1
    c.r[7] = ld32(0x06024E54u);  // 06024E20 mov.l 0x06024E54,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 06024E22 extu.w r1,r1
    st32(c.r[7] + 20, c.r[1]);  // 06024E24 mov.l r1,@(20,r7)
    c.r[1] = ld32(0x06024E58u);  // 06024E26 mov.l 0x06024E58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024E2Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024E2Cu) return; }  // 06024E28 jsr @r1 ; nop
L_06024E2C:
    c.r[15] = c.r[14];  // 06024E2C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024E2E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024E38u);  // 06024E30 mov.w 0x06024E38,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024E32 rts ; mov.l @r15+,r14
}

void f_06024E5C(SH2Context& c) {
    ran[477] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06024E5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06024E5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024E60 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024E62 sts.l pr,@-r15
    c.r[8] = ld32(0x06024EDCu);  // 06024E64 mov.l 0x06024EDC,r8
    c.r[1] = ld32(c.r[8]);  // 06024E66 mov.l @r8,r1
    c.r[1] += 3;  // 06024E68 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024E6A mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06024E6C extu.b r1,r9
    c.r[1] = ld32(0x06024EE0u);  // 06024E6E mov.l 0x06024EE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024E74u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024E74u) return; }  // 06024E70 jsr @r1 ; mov r15,r14
    c.r[2] = ld32(c.r[8]);  // 06024E74 mov.l @r8,r2
    c.r[0] = ld32(0x06024EE4u);  // 06024E76 mov.l 0x06024EE4,r0
    c.r[1] = c.r[2];  // 06024E78 mov r2,r1
    c.r[1] += 1;  // 06024E7A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024E7C mov.b @r1,r4
    c.r[2] += 2;  // 06024E7E add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06024E80 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024E82 mov.b @r2,r1
    c.r[4] <<= 8;  // 06024E84 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06024E86 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06024E8Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024E8Cu) return; }  // 06024E88 jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06024E8C extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06024ED6u);  // 06024E8E mov.w 0x06024ED6,r1
    c.t = c.r[0] == c.r[1];  // 06024E90 cmp/eq r1,r0
    if (c.t) { goto L_06024EC8; }  // 06024E92 bt 0x06024EC8
    c.r[1] = ld32(0x06024EE8u);  // 06024E94 mov.l 0x06024EE8,r1
    c.r[2] = ld32(c.r[1]);  // 06024E96 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06024E98 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 06024E9A mul.l r1,r0
    c.r[3] = c.macl;  // 06024E9C sts macl,r3
    c.r[3] += c.r[2];  // 06024E9E add r2,r3
    c.r[3] += 22;  // 06024EA0 add #22,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06024EA2 mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06024EA4 extu.w r1,r1
    c.macl = c.r[1] * c.r[9];  // 06024EA6 mul.l r9,r1
    c.r[2] = c.macl;  // 06024EA8 sts macl,r2
    c.r[1] = ld32(0x06024EECu);  // 06024EAA mov.l 0x06024EEC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06024EAC dmuls.l r1,r2
    c.r[1] = c.mach;  // 06024EAE sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06024EB0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06024EB2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06024EB4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06024EB6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06024EB8 shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06024EBA shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06024EBC subc r2,r2
    c.r[1] -= c.r[2];  // 06024EBE sub r2,r1
    st16(c.r[3], c.r[1]);  // 06024EC0 mov.w r1,@r3
    c.r[1] = ld32(0x06024EF0u);  // 06024EC2 mov.l 0x06024EF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024EC8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024EC8u) return; }  // 06024EC4 jsr @r1 ; nop
L_06024EC8:
    c.r[15] = c.r[14];  // 06024EC8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06024ECA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06024ECC mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06024ECE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06024ED8u);  // 06024ED0 mov.w 0x06024ED8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06024ED2 rts ; mov.l @r15+,r8
}

void f_06024EF4(SH2Context& c) {
    ran[478] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06024EF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06024EF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06024EF8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06024EFA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06024EFC sts.l pr,@-r15
    c.r[10] = ld32(0x06025028u);  // 06024EFE mov.l 0x06025028,r10
    c.r[2] = ld32(c.r[10]);  // 06024F00 mov.l @r10,r2
    c.r[1] = c.r[2];  // 06024F02 mov r2,r1
    c.r[1] += 1;  // 06024F04 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024F06 mov.b @r1,r1
    c.r[2] += 2;  // 06024F08 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06024F0A extu.b r1,r1
    c.r[8] = c.r[1];  // 06024F0C mov r1,r8
    c.r[8] <<= 8;  // 06024F0E shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06024F10 mov.b @r2,r1
    c.r[14] = c.r[15];  // 06024F12 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06024F14 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06024F16 or r1,r8
    c.r[1] = ld32(0x0602502Cu);  // 06024F18 mov.l 0x0602502C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06024F1Eu; c.r[9] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024F1Eu) return; }  // 06024F1A jsr @r1 ; mov r8,r9
    c.r[0] = c.r[8];  // 06024F1E mov r8,r0
    c.r[0] >>= 8;  // 06024F20 shlr8 r0
    c.r[0] <<= 2;  // 06024F22 shll2 r0
    c.r[0] >>= 8;  // 06024F24 shlr8 r0
    c.r[0] &= 0x1u;  // 06024F26 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06024F28 tst r0,r0
    if (c.t) { goto L_06024F30; }  // 06024F2A bt 0x06024F30
    goto L_06025040;  // 06024F2C bra 0x06025040 ; nop
L_06024F30:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06025024u);  // 06024F30 mov.w 0x06025024,r4
    c.r[0] = ld32(0x06025030u);  // 06024F32 mov.l 0x06025030,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06024F38u; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06024F38u) return; }  // 06024F34 jsr @r0 ; and r8,r4
    c.r[4] = c.r[0] & 0xFFu;  // 06024F38 extu.b r0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025026u);  // 06024F3A mov.w 0x06025026,r1
    c.t = c.r[4] == c.r[1];  // 06024F3C cmp/eq r1,r4
    if (!c.t) { goto L_06024F44; }  // 06024F3E bf 0x06024F44
    goto L_060250A8;  // 06024F40 bra 0x060250A8 ; nop
L_06024F44:
    c.r[1] = ld32(0x06025034u);  // 06024F44 mov.l 0x06025034,r1
    c.r[2] = ld32(c.r[1]);  // 06024F46 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06024F48 mov #30,r1
    c.macl = c.r[4] * c.r[1];  // 06024F4A mul.l r1,r4
    c.r[7] = c.macl;  // 06024F4C sts macl,r7
    c.r[7] += c.r[2];  // 06024F4E add r2,r7
    c.r[1] = c.r[7];  // 06024F50 mov r7,r1
    c.r[1] += 2;  // 06024F52 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024F54 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06024F56 mov r1,r0
    c.r[0] >>= 2;  // 06024F58 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06024F5A shlr r0
    c.r[0] &= 0x3u;  // 06024F5C and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06024F5E tst r0,r0
    if (c.t) { goto L_06024F66; }  // 06024F60 bt 0x06024F66
    goto L_060250A8;  // 06024F62 bra 0x060250A8 ; nop
L_06024F66:
    c.r[3] = ld32(c.r[10]);  // 06024F66 mov.l @r10,r3
    c.r[5] = 0xFu;  // 06024F68 mov #15,r5
    c.r[1] = c.r[3];  // 06024F6A mov r3,r1
    c.r[1] += 3;  // 06024F6C add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024F6E mov.b @r1,r2
    c.r[0] = 0xFu;  // 06024F70 mov #15,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06024F72 extu.b r2,r2
    c.r[2] <<= 8;  // 06024F74 shll8 r2
    c.r[1] = c.r[3];  // 06024F76 mov r3,r1
    c.r[1] += 4;  // 06024F78 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024F7A mov.b @r1,r1
    c.r[3] += 5;  // 06024F7C add #5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06024F7E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06024F80 or r1,r2
    c.r[5] &= c.r[2];  // 06024F82 and r2,r5
    c.r[6] = c.r[2];  // 06024F84 mov r2,r6
    c.r[6] >>= 2;  // 06024F86 shlr2 r6
    c.r[6] >>= 2;  // 06024F88 shlr2 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06024F8A mov.b @r3,r1
    c.r[6] &= c.r[0];  // 06024F8C and r0,r6
    c.r[10] = c.r[1] & 0xFFu;  // 06024F8E extu.b r1,r10
    c.r[9] = c.r[10];  // 06024F90 mov r10,r9
    c.r[3] = c.r[2];  // 06024F92 mov r2,r3
    c.r[3] >>= 8;  // 06024F94 shlr8 r3
    c.r[3] &= c.r[0];  // 06024F96 and r0,r3
    c.r[1] = c.r[2];  // 06024F98 mov r2,r1
    c.r[1] >>= 8;  // 06024F9A shlr8 r1
    c.r[1] >>= 2;  // 06024F9C shlr2 r1
    c.r[1] >>= 2;  // 06024F9E shlr2 r1
    c.r[10] &= c.r[0];  // 06024FA0 and r0,r10
    c.r[0] = c.r[5];  // 06024FA2 mov r5,r0
    c.t = c.r[0] == 0xFu;  // 06024FA4 cmp/eq #15,r0
    if (!c.t) { goto L_06024FAE; }  // 06024FA6 bf 0x06024FAE
    c.r[7] += 5;  // 06024FA8 add #5,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); goto L_06024FD0;  // 06024FAA bra 0x06024FD0 ; mov.b @r7,r1
L_06024FAE:
    c.r[0] = c.r[6];  // 06024FAE mov r6,r0
    c.t = c.r[0] == 0xFu;  // 06024FB0 cmp/eq #15,r0
    if (!c.t) { goto L_06024FC6; }  // 06024FB2 bf 0x06024FC6
    c.r[7] += 4;  // 06024FB4 add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06024FB6 mov.w @r7,r1
    c.r[2] = ld32(0x06025038u);  // 06024FB8 mov.l 0x06025038,r2
    c.r[0] = c.r[1];  // 06024FBA mov r1,r0
    c.r[0] >>= 2;  // 06024FBC shlr2 r0
    c.r[0] >>= 2;  // 06024FBE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06024FC0 shlr r0
    c.r[0] >>= 2; goto L_06024FD8;  // 06024FC2 bra 0x06024FD8 ; shlr2 r0
L_06024FC6:
    c.r[0] = c.r[3];  // 06024FC6 mov r3,r0
    c.t = c.r[0] == 0xFu;  // 06024FC8 cmp/eq #15,r0
    if (!c.t) { goto L_06024FDE; }  // 06024FCA bf 0x06024FDE
    c.r[7] += 4;  // 06024FCC add #4,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06024FCE mov.b @r7,r1
L_06024FD0:
    c.r[2] = ld32(0x06025038u);  // 06024FD0 mov.l 0x06025038,r2
    c.r[0] = c.r[1];  // 06024FD2 mov r1,r0
    c.r[0] >>= 2;  // 06024FD4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06024FD6 shlr r0
L_06024FD8:
    c.r[0] &= 0xFu;  // 06024FD8 and #15,r0
    st32(c.r[2] + 20, c.r[0]); goto L_060250A2;  // 06024FDA bra 0x060250A2 ; mov.l r0,@(20,r2)
L_06024FDE:
    c.r[0] = c.r[1];  // 06024FDE mov r1,r0
    c.t = c.r[0] == 0xFu;  // 06024FE0 cmp/eq #15,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06024FF0; } }  // 06024FE2 bf/s 0x06024FF0 ; mov r7,r1
    c.r[2] = ld32(0x06025038u);  // 06024FE6 mov.l 0x06025038,r2
    c.r[1] += 3;  // 06024FE8 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024FEA mov.b @r1,r0
    c.r[7] += 4; goto L_06024FFE;  // 06024FEC bra 0x06024FFE ; add #4,r7
L_06024FF0:
    c.r[0] = c.r[10];  // 06024FF0 mov r10,r0
    c.t = c.r[0] == 0xFu;  // 06024FF2 cmp/eq #15,r0
    { const bool k = !c.t; c.r[1] += 5; if (k) { goto L_06025014; } }  // 06024FF4 bf/s 0x06025014 ; add #5,r1
    c.r[2] = ld32(0x06025038u);  // 06024FF8 mov.l 0x06025038,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06024FFA mov.b @r1,r0
    c.r[7] += 6;  // 06024FFC add #6,r7
L_06024FFE:
    c.r[0] &= 0x7u;  // 06024FFE and #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06025000 mov.b @r7,r1
    c.r[0] += c.r[0];  // 06025002 add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06025004 extu.b r1,r1
    c.r[1] >>= 2;  // 06025006 shlr2 r1
    c.r[1] >>= 2;  // 06025008 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602500A shlr r1
    c.r[1] >>= 2;  // 0602500C shlr2 r1
    c.r[0] |= c.r[1];  // 0602500E or r1,r0
    st32(c.r[2] + 20, c.r[0]); goto L_060250A2;  // 06025010 bra 0x060250A2 ; mov.l r0,@(20,r2)
L_06025014:
    c.r[8] >>= 8;  // 06025014 shlr8 r8
    c.r[8] += c.r[8];  // 06025016 add r8,r8
    c.r[8] >>= 8;  // 06025018 shlr8 r8
    c.r[1] = ld32(0x0602503Cu);  // 0602501A mov.l 0x0602503C,r1
    c.r[7] = c.r[8];  // 0602501C mov r8,r7
    c.r[6] = c.r[9];  // 0602501E mov r9,r6
    c.r[5] = c.r[2]; goto L_0602509E;  // 06025020 bra 0x0602509E ; mov r2,r5
L_06025040:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060250B8u);  // 06025040 mov.w 0x060250B8,r4
    c.r[0] = ld32(0x060250C0u);  // 06025042 mov.l 0x060250C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06025048u; c.r[4] &= c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025048u) return; }  // 06025044 jsr @r0 ; and r9,r4
    c.r[4] = c.r[0] & 0xFFu;  // 06025048 extu.b r0,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x060250BAu);  // 0602504A mov.w 0x060250BA,r8
    c.t = c.r[4] == c.r[8];  // 0602504C cmp/eq r8,r4
    if (c.t) { goto L_060250A8; }  // 0602504E bt 0x060250A8
    c.r[0] = ld32(0x060250C4u);  // 06025050 mov.l 0x060250C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06025056u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025056u) return; }  // 06025052 jsr @r0 ; nop
    c.r[4] = c.r[0] & 0xFFu;  // 06025056 extu.b r0,r4
    c.t = c.r[4] == c.r[8];  // 06025058 cmp/eq r8,r4
    if (c.t) { goto L_060250A8; }  // 0602505A bt 0x060250A8
    c.r[1] = ld32(0x060250C8u);  // 0602505C mov.l 0x060250C8,r1
    c.r[2] = ld32(c.r[1]);  // 0602505E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06025060 mov #30,r1
    c.macl = c.r[4] * c.r[1];  // 06025062 mul.l r1,r4
    c.r[1] = c.macl;  // 06025064 sts macl,r1
    c.r[1] += c.r[2];  // 06025066 add r2,r1
    c.r[1] += 2;  // 06025068 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602506A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602506C mov r1,r0
    c.r[0] >>= 2;  // 0602506E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06025070 shlr r0
    c.r[0] &= 0x3u;  // 06025072 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025074 tst r0,r0
    if (!c.t) { goto L_060250A8; }  // 06025076 bf 0x060250A8
    c.r[2] = ld32(c.r[10]);  // 06025078 mov.l @r10,r2
    c.r[9] >>= 8;  // 0602507A shlr8 r9
    c.r[9] += c.r[9];  // 0602507C add r9,r9
    c.r[9] >>= 8;  // 0602507E shlr8 r9
    c.r[1] = c.r[2];  // 06025080 mov r2,r1
    c.r[1] += 5;  // 06025082 add #5,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025084 mov.b @r1,r6
    c.r[7] = c.r[9];  // 06025086 mov r9,r7
    c.r[6] = c.r[6] & 0xFFu;  // 06025088 extu.b r6,r6
    c.r[1] = c.r[2];  // 0602508A mov r2,r1
    c.r[1] += 3;  // 0602508C add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602508E mov.b @r1,r5
    c.r[2] += 4;  // 06025090 add #4,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06025092 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025094 mov.b @r2,r1
    c.r[5] <<= 8;  // 06025096 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 06025098 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602509A or r1,r5
    c.r[1] = ld32(0x060250CCu);  // 0602509C mov.l 0x060250CC,r1
L_0602509E:
    { const uint32_t x = c.r[1]; c.pr = 0x060250A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060250A2u) return; }  // 0602509E jsr @r1 ; nop
L_060250A2:
    c.r[1] = ld32(0x060250D0u);  // 060250A2 mov.l 0x060250D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060250A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060250A8u) return; }  // 060250A4 jsr @r1 ; nop
L_060250A8:
    c.r[15] = c.r[14];  // 060250A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060250AA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060250AC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060250AE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060250B0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060250BCu);  // 060250B2 mov.w 0x060250BC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060250B4 rts ; mov.l @r15+,r8
}

void f_060250D4(SH2Context& c) {
    ran[479] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060250D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060250D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060250D8 sts.l pr,@-r15
    c.r[1] = ld32(0x0602518Cu);  // 060250DA mov.l 0x0602518C,r1
    c.r[1] = ld32(c.r[1]);  // 060250DC mov.l @r1,r1
    c.r[1] += 1;  // 060250DE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060250E0 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060250E2 extu.b r1,r8
    c.r[1] = ld32(0x06025190u);  // 060250E4 mov.l 0x06025190,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060250EAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060250EAu) return; }  // 060250E6 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06025194u);  // 060250EA mov.l 0x06025194,r1
    c.r[0] = c.r[8];  // 060250EC mov r8,r0
    c.r[1] = ld32(c.r[1]);  // 060250EE mov.l @r1,r1
    c.r[0] += c.r[0];  // 060250F0 add r0,r0
    c.r[0] += c.r[1];  // 060250F2 add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025184u);  // 060250F4 mov.w 0x06025184,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060250F6 mov.b @(r0,r1),r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06025186u);  // 060250F8 mov.w 0x06025186,r5
    c.r[6] = c.r[1] & 0xFFu;  // 060250FA extu.b r1,r6
    c.t = c.r[6] == c.r[5];  // 060250FC cmp/eq r5,r6
    if (c.t) { goto L_06025178; }  // 060250FE bt 0x06025178
    c.r[1] = ld32(0x06025198u);  // 06025100 mov.l 0x06025198,r1
    c.r[2] = ld32(c.r[1]);  // 06025102 mov.l @r1,r2
    c.r[1] = c.r[6];  // 06025104 mov r6,r1
    c.r[1] <<= 2;  // 06025106 shll2 r1
    c.r[1] <<= 2;  // 06025108 shll2 r1
    c.r[3] = c.r[1];  // 0602510A mov r1,r3
    c.r[0] = c.r[1];  // 0602510C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602510E mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06025110 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06025112 cmp/eq r5,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_06025178; } }  // 06025114 bt/s 0x06025178 ; add r2,r3
    c.r[1] = c.r[3];  // 06025118 mov r3,r1
    c.r[1] += 7;  // 0602511A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602511C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602511E mov r1,r0
    c.r[0] >>= 2;  // 06025120 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06025122 shlr r0
    c.r[0] &= 0x1u;  // 06025124 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025126 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06025178; } }  // 06025128 bf/s 0x06025178 ; mov r3,r1
    c.r[1] += 3;  // 0602512C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602512E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06025130 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06025132 shlr r0
    c.r[0] &= 0x3u;  // 06025134 and #3,r0
    c.t = c.r[0] == c.r[8];  // 06025136 cmp/eq r8,r0
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_06025178; } }  // 06025138 bf/s 0x06025178 ; add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602513C mov.b @r3,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602513E extu.b r1,r3
    c.t = c.r[3] == c.r[5];  // 06025140 cmp/eq r5,r3
    if (c.t) { goto L_06025178; }  // 06025142 bt 0x06025178
    c.r[1] = ld32(0x0602519Cu);  // 06025144 mov.l 0x0602519C,r1
    c.r[2] = ld32(c.r[1]);  // 06025146 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06025148 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602514A mul.l r1,r3
    c.r[1] = c.macl;  // 0602514C sts macl,r1
    c.r[1] += c.r[2];  // 0602514E add r2,r1
    c.r[1] += 15;  // 06025150 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025152 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06025154 extu.b r1,r7
    c.t = c.r[7] == c.r[5];  // 06025156 cmp/eq r5,r7
    if (c.t) { goto L_06025178; }  // 06025158 bt 0x06025178
    c.r[1] = ld32(0x060251A0u);  // 0602515A mov.l 0x060251A0,r1
    c.r[2] = ld32(c.r[1]);  // 0602515C mov.l @r1,r2
    c.r[1] = c.r[7];  // 0602515E mov r7,r1
    c.r[1] += c.r[1];  // 06025160 add r1,r1
    c.r[1] += c.r[7];  // 06025162 add r7,r1
    c.r[1] <<= 2;  // 06025164 shll2 r1
    c.r[0] = c.r[1];  // 06025166 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06025168 mov.w @(r0,r2),r1
    c.r[3] = ld32(0x060251A4u);  // 0602516A mov.l 0x060251A4,r3
    st16(c.r[3], c.r[1]);  // 0602516C mov.w r1,@r3
    c.r[1] = ld32(0x060251A8u);  // 0602516E mov.l 0x060251A8,r1
    st8(c.r[1], c.r[6]);  // 06025170 mov.b r6,@r1
    c.r[1] = ld32(0x060251ACu);  // 06025172 mov.l 0x060251AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025178u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025178u) return; }  // 06025174 jsr @r1 ; nop
L_06025178:
    c.r[15] = c.r[14];  // 06025178 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602517A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602517C mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025188u);  // 0602517E mov.w 0x06025188,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025180 rts ; mov.l @r15+,r8
}

void f_060251B0(SH2Context& c) {
    ran[480] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060251B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060251B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060251B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060251B6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060251B8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060251BA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060251BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060251BE sts.l pr,@-r15
    c.r[15] -= 76;  // 060251C0 add #-76,r15
    c.r[8] = ld32(0x060252D8u);  // 060251C2 mov.l 0x060252D8,r8
    c.r[1] = ld32(c.r[8]);  // 060251C4 mov.l @r8,r1
    c.r[14] = c.r[15];  // 060251C6 mov r15,r14
    c.r[1] += 3;  // 060251C8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060251CA mov.b @r1,r1
    c.r[10] = 0xFu;  // 060251CC mov #15,r10
    c.r[9] = c.r[1] & 0xFFu;  // 060251CE extu.b r1,r9
    c.r[12] = c.r[9];  // 060251D0 mov r9,r12
    c.r[12] >>= 2;  // 060251D2 shlr2 r12
    c.r[12] >>= 2;  // 060251D4 shlr2 r12
    c.r[1] = ld32(0x060252DCu);  // 060251D6 mov.l 0x060252DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060251DCu; c.r[10] &= c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060251DCu) return; }  // 060251D8 jsr @r1 ; and r9,r10
    c.r[0] = ld32(0x060252E0u);  // 060251DC mov.l 0x060252E0,r0
    c.r[7] = 0x0u;  // 060251DE mov #0,r7
    c.r[2] = ld32(c.r[8]);  // 060251E0 mov.l @r8,r2
    c.r[5] = c.r[14];  // 060251E2 mov r14,r5
    c.r[1] = c.r[2];  // 060251E4 mov r2,r1
    c.r[1] += 1;  // 060251E6 add #1,r1
    c.r[2] += 2;  // 060251E8 add #2,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060251EA mov.b @r1,r6
    c.r[8] = ld32(0x060252E4u);  // 060251EC mov.l 0x060252E4,r8
    c.r[4] = ld32(c.r[8]);  // 060251EE mov.l @r8,r4
    c.r[6] = c.r[6] & 0xFFu;  // 060251F0 extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060251F2 mov.b @r2,r1
    c.r[6] <<= 8;  // 060251F4 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 060251F6 extu.b r1,r1
    c.r[6] |= c.r[1];  // 060251F8 or r1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060251FEu; c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060251FEu) return; }  // 060251FA jsr @r0 ; exts.w r6,r6
    c.r[11] = c.r[0];  // 060251FE mov r0,r11
    c.r[9] = 0x0u;  // 06025200 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06025202 cmp/ge r11,r9
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_060252B2; } }  // 06025204 bt/s 0x060252B2 ; mov #3,r0
    c.r[10] &= c.r[0];  // 06025208 and r0,r10
    c.r[13] = c.r[12];  // 0602520A mov r12,r13
    c.r[13] += c.r[13];  // 0602520C add r13,r13
    c.r[12] = c.r[10];  // 0602520E mov r10,r12
    c.r[12] <<= 2;  // 06025210 shll2 r12
    c.r[12] += c.r[12];  // 06025212 add r12,r12
    c.r[0] = c.r[14];  // 06025214 mov r14,r0
L_06025216:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06025216 mov.b @(r0,r9),r7
    c.r[1] = c.r[10];  // 06025218 mov r10,r1
    c.r[2] = ld32(c.r[8]);  // 0602521A mov.l @r8,r2
    c.r[7] = c.r[7] & 0xFFu;  // 0602521C extu.b r7,r7
    c.r[7] <<= 2;  // 0602521E shll2 r7
    c.r[7] <<= 2;  // 06025220 shll2 r7
    c.r[2] += c.r[7];  // 06025222 add r7,r2
    c.r[2] += 3;  // 06025224 add #3,r2
    c.r[1] += c.r[1];  // 06025226 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025228 mov.b @r2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060252CAu);  // 0602522A mov.w 0x060252CA,r0
    c.r[3] &= c.r[0];  // 0602522C and r0,r3
    c.r[3] |= c.r[1];  // 0602522E or r1,r3
    st8(c.r[2], c.r[3]);  // 06025230 mov.b r3,@r2
    c.r[1] = ld32(c.r[8]);  // 06025232 mov.l @r8,r1
    c.r[1] += c.r[7];  // 06025234 add r7,r1
    c.r[1] += 4;  // 06025236 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025238 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060252CCu);  // 0602523A mov.w 0x060252CC,r0
    c.r[2] &= c.r[0];  // 0602523C and r0,r2
    c.r[2] |= c.r[13];  // 0602523E or r13,r2
    st8(c.r[1], c.r[2]);  // 06025240 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06025242 mov.l @r8,r1
    c.r[1] += c.r[7];  // 06025244 add r7,r1
    c.r[1] += 2;  // 06025246 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025248 mov.b @r1,r2
    c.r[1] = ld32(0x060252E8u);  // 0602524A mov.l 0x060252E8,r1
    c.r[3] = ld32(c.r[1]);  // 0602524C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602524E extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06025250 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06025252 mul.l r1,r2
    c.r[1] = c.macl;  // 06025254 sts macl,r1
    c.r[1] += c.r[3];  // 06025256 add r3,r1
    c.r[1] += 2;  // 06025258 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602525A mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060252CEu);  // 0602525C mov.w 0x060252CE,r0
    c.r[2] &= c.r[0];  // 0602525E and r0,r2
    c.r[2] |= c.r[12];  // 06025260 or r12,r2
    st8(c.r[1], c.r[2]);  // 06025262 mov.b r2,@r1
    c.r[2] = ld32(c.r[8]);  // 06025264 mov.l @r8,r2
    c.r[0] = 0x3u;  // 06025266 mov #3,r0
    c.r[2] += c.r[7];  // 06025268 add r7,r2
    c.r[1] = c.r[2];  // 0602526A mov r2,r1
    c.r[1] += 3;  // 0602526C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602526E mov.b @r1,r1
    c.r[2] += 7;  // 06025270 add #7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025272 mov.b @r2,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06025274 shlr r1
    c.r[1] &= c.r[0];  // 06025276 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06025278 tst r1,r1
    c.r[0] = c.t;  // 0602527A movt r0
    c.r[1] = c.r[0];  // 0602527C mov r0,r1
    c.r[1] <<= 2;  // 0602527E shll2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060252D0u);  // 06025280 mov.w 0x060252D0,r0
    c.r[3] &= c.r[0];  // 06025282 and r0,r3
    c.r[3] |= c.r[1];  // 06025284 or r1,r3
    st8(c.r[2], c.r[3]);  // 06025286 mov.b r3,@r2
    c.r[2] = ld32(c.r[8]);  // 06025288 mov.l @r8,r2
    c.r[1] = 0xFFFFFFFFu;  // 0602528A mov #-1,r1
    c.r[2] += c.r[7];  // 0602528C add r7,r2
    c.r[3] = c.r[2];  // 0602528E mov r2,r3
    c.r[3] += 8;  // 06025290 add #8,r3
    c.r[2] += 9;  // 06025292 add #9,r2
    st8(c.r[2], c.r[1]);  // 06025294 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 06025296 mov.b r1,@r3
    c.r[1] = ld32(c.r[8]);  // 06025298 mov.l @r8,r1
    c.r[1] += c.r[7];  // 0602529A add r7,r1
    c.r[1] += 11;  // 0602529C add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602529E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060252D2u);  // 060252A0 mov.w 0x060252D2,r0
    c.r[2] &= c.r[0];  // 060252A2 and r0,r2
    st8(c.r[1], c.r[2]);  // 060252A4 mov.b r2,@r1
    c.r[1] = ld32(0x060252ECu);  // 060252A6 mov.l 0x060252EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060252ACu; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060252ACu) return; }  // 060252A8 jsr @r1 ; add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 060252AC cmp/ge r11,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06025216; } }  // 060252AE bf/s 0x06025216 ; mov r14,r0
L_060252B2:
    c.r[14] += 76;  // 060252B2 add #76,r14
    c.r[15] = c.r[14];  // 060252B4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060252B6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060252B8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060252BA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060252BC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060252BE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060252C0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060252C2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060252D4u);  // 060252C4 mov.w 0x060252D4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060252C6 rts ; mov.l @r15+,r8
}

void f_060252F0(SH2Context& c) {
    ran[481] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060252F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060252F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060252F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060252F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060252F8 sts.l pr,@-r15
    c.r[8] = ld32(0x0602539Cu);  // 060252FA mov.l 0x0602539C,r8
    c.r[1] = ld32(c.r[8]);  // 060252FC mov.l @r8,r1
    c.r[15] -= 76;  // 060252FE add #-76,r15
    c.r[1] += 3;  // 06025300 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025302 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06025304 extu.b r1,r9
    c.r[1] = ld32(0x060253A0u);  // 06025306 mov.l 0x060253A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602530Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602530Cu) return; }  // 06025308 jsr @r1 ; mov r15,r14
    c.r[10] = ld32(0x060253A4u);  // 0602530C mov.l 0x060253A4,r10
    c.r[0] = ld32(0x060253A8u);  // 0602530E mov.l 0x060253A8,r0
    c.r[7] = 0x0u;  // 06025310 mov #0,r7
    c.r[2] = ld32(c.r[8]);  // 06025312 mov.l @r8,r2
    c.r[5] = c.r[14];  // 06025314 mov r14,r5
    c.r[4] = ld32(c.r[10]);  // 06025316 mov.l @r10,r4
    c.r[1] = c.r[2];  // 06025318 mov r2,r1
    c.r[1] += 1;  // 0602531A add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602531C mov.b @r1,r6
    c.r[2] += 2;  // 0602531E add #2,r2
    c.r[6] = c.r[6] & 0xFFu;  // 06025320 extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025322 mov.b @r2,r1
    c.r[6] <<= 8;  // 06025324 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 06025326 extu.b r1,r1
    c.r[6] |= c.r[1];  // 06025328 or r1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0602532Eu; c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602532Eu) return; }  // 0602532A jsr @r0 ; exts.w r6,r6
    c.r[8] = c.r[0];  // 0602532E mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06025330 tst r8,r8
    if (c.t) { goto L_06025384; }  // 06025332 bt 0x06025384
    c.r[1] = ld32(0x060253ACu);  // 06025334 mov.l 0x060253AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602533Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602533Au) return; }  // 06025336 jsr @r1 ; nop
    c.r[3] = 0x0u;  // 0602533A mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 0602533C cmp/ge r8,r3
    { const bool k = c.t; c.r[4] = c.r[10]; if (k) { goto L_06025384; } }  // 0602533E bt/s 0x06025384 ; mov r10,r4
    c.r[6] = c.r[9];  // 06025342 mov r9,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06025344 shlr r6
    c.r[0] = 0x1u;  // 06025346 mov #1,r0
    c.r[6] &= c.r[0];  // 06025348 and r0,r6
    c.r[7] = 0x1u;  // 0602534A mov #1,r7
    c.r[7] &= c.r[9];  // 0602534C and r9,r7
    c.r[7] <<= 2;  // 0602534E shll2 r7
    c.r[7] <<= 2;  // 06025350 shll2 r7
    c.r[7] += c.r[7];  // 06025352 add r7,r7
    c.r[7] <<= 2;  // 06025354 shll2 r7
L_06025356:
    c.r[0] = c.r[14];  // 06025356 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06025358 mov.b @(r0,r3),r1
    c.r[2] = ld32(c.r[4]);  // 0602535A mov.l @r4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602535C extu.b r1,r1
    c.r[1] <<= 2;  // 0602535E shll2 r1
    c.r[1] <<= 2;  // 06025360 shll2 r1
    c.r[1] += c.r[2];  // 06025362 add r2,r1
    c.r[2] = c.r[1];  // 06025364 mov r1,r2
    c.r[2] += 3;  // 06025366 add #3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025396u);  // 06025368 mov.w 0x06025396,r0
    c.r[1] += 4;  // 0602536A add #4,r1
    c.r[3] += 1;  // 0602536C add #1,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602536E mov.b @r2,r5
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 06025370 cmp/ge r8,r3
    c.r[5] &= c.r[0];  // 06025372 and r0,r5
    c.r[5] |= c.r[6];  // 06025374 or r6,r5
    st8(c.r[2], c.r[5]);  // 06025376 mov.b r5,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025378 mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 0602537A mov #127,r0
    c.r[2] &= c.r[0];  // 0602537C and r0,r2
    c.r[2] |= c.r[7];  // 0602537E or r7,r2
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_06025356; } }  // 06025380 bf/s 0x06025356 ; mov.b r2,@r1
L_06025384:
    c.r[14] += 76;  // 06025384 add #76,r14
    c.r[15] = c.r[14];  // 06025386 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025388 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602538A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602538C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602538E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025398u);  // 06025390 mov.w 0x06025398,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025392 rts ; mov.l @r15+,r8
}

void f_060253B0(SH2Context& c) {
    ran[482] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060253B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060253B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060253B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060253B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060253B8 sts.l pr,@-r15
    c.r[15] -= 76;  // 060253BA add #-76,r15
    c.r[1] = ld32(0x06025424u);  // 060253BC mov.l 0x06025424,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060253C2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060253C2u) return; }  // 060253BE jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06025428u);  // 060253C2 mov.l 0x06025428,r1
    c.r[0] = ld32(0x0602542Cu);  // 060253C4 mov.l 0x0602542C,r0
    c.r[7] = 0x0u;  // 060253C6 mov #0,r7
    c.r[2] = ld32(c.r[1]);  // 060253C8 mov.l @r1,r2
    c.r[5] = c.r[14];  // 060253CA mov r14,r5
    c.r[1] = c.r[2];  // 060253CC mov r2,r1
    c.r[1] += 1;  // 060253CE add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060253D0 mov.b @r1,r6
    c.r[2] += 2;  // 060253D2 add #2,r2
    c.r[6] = c.r[6] & 0xFFu;  // 060253D4 extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060253D6 mov.b @r2,r1
    c.r[6] <<= 8;  // 060253D8 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 060253DA extu.b r1,r1
    c.r[6] |= c.r[1];  // 060253DC or r1,r6
    c.r[1] = ld32(0x06025430u);  // 060253DE mov.l 0x06025430,r1
    c.r[4] = ld32(c.r[1]);  // 060253E0 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060253E6u; c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060253E6u) return; }  // 060253E2 jsr @r0 ; exts.w r6,r6
    c.r[9] = c.r[0];  // 060253E6 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060253E8 tst r9,r9
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0602540E; } }  // 060253EA bt/s 0x0602540E ; mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 060253EE cmp/ge r9,r8
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06025408; } }  // 060253F0 bt/s 0x06025408 ; mov r14,r0
    c.r[10] = ld32(0x06025434u);  // 060253F4 mov.l 0x06025434,r10
L_060253F6:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060253F6 mov.b @(r0,r8),r4
    c.r[6] = 0x0u;  // 060253F8 mov #0,r6
    c.r[5] = 0x4u;  // 060253FA mov #4,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06025400u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025400u) return; }  // 060253FC jsr @r10 ; extu.b r4,r4
    c.r[8] += 1;  // 06025400 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06025402 cmp/ge r9,r8
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_060253F6; } }  // 06025404 bf/s 0x060253F6 ; mov r14,r0
L_06025408:
    c.r[1] = ld32(0x06025438u);  // 06025408 mov.l 0x06025438,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602540Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602540Eu) return; }  // 0602540A jsr @r1 ; nop
L_0602540E:
    c.r[14] += 76;  // 0602540E add #76,r14
    c.r[15] = c.r[14];  // 06025410 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025412 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06025414 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06025416 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06025418 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025420u);  // 0602541A mov.w 0x06025420,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602541C rts ; mov.l @r15+,r8
}

void f_0602543C(SH2Context& c) {
    ran[483] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602543C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602543E sts.l pr,@-r15
    c.r[1] = ld32(0x060254C0u);  // 06025440 mov.l 0x060254C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025446u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025446u) return; }  // 06025442 jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x060254C4u);  // 06025446 mov.l 0x060254C4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060254BCu);  // 06025448 mov.w 0x060254BC,r1
    st32(c.r[2] + 20, c.r[1]);  // 0602544A mov.l r1,@(20,r2)
    c.r[6] = 0x0u;  // 0602544C mov #0,r6
    c.r[5] = ld32(0x060254C8u);  // 0602544E mov.l 0x060254C8,r5
    c.r[4] = c.r[2];  // 06025450 mov r2,r4
    c.r[7] = 0x0u;  // 06025452 mov #0,r7
L_06025454:
    c.r[3] = c.r[7];  // 06025454 mov r7,r3
    c.r[0] = ld32(c.r[5]);  // 06025456 mov.l @r5,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x060254BCu);  // 06025458 mov.w 0x060254BC,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602545A mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602545C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602545E cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_060254A8; } }  // 06025460 bt/s 0x060254A8 ; add r0,r3
    c.r[3] += 3;  // 06025464 add #3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06025466 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06025468 extu.b r2,r1
    c.r[0] = c.r[1];  // 0602546A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602546C shlr r0
    c.r[0] &= 0x3u;  // 0602546E and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025470 tst r0,r0
    { const bool k = !c.t; c.r[1] >>= 2; if (k) { goto L_060254A8; } }  // 06025472 bf/s 0x060254A8 ; shlr2 r1
    c.r[1] >>= 2;  // 06025476 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06025478 shlr r1
    c.r[1] >>= 2;  // 0602547A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602547C tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_060254A8; } }  // 0602547E bt/s 0x060254A8 ; mov r2,r0
    c.r[0] &= 0x7Fu;  // 06025482 and #127,r0
    st8(c.r[3], c.r[0]);  // 06025484 mov.b r0,@r3
    c.r[1] = ld32(c.r[5]);  // 06025486 mov.l @r5,r1
    c.r[7] += c.r[1];  // 06025488 add r1,r7
    c.r[7] += 4;  // 0602548A add #4,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602548C mov.b @r7,r0
    c.r[0] &= 0x60u;  // 0602548E and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025490 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0602549E; } }  // 06025492 bf/s 0x0602549E ; mov r6,r1
    c.r[2] = ld32(0x060254CCu);  // 06025496 mov.l 0x060254CC,r2
    st8(c.r[2], c.r[1]);  // 06025498 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602549A extu.b r1,r1
    st32(c.r[4] + 20, c.r[1]);  // 0602549C mov.l r1,@(20,r4)
L_0602549E:
    c.r[1] = ld32(0x060254D0u);  // 0602549E mov.l 0x060254D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060254A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060254A4u) return; }  // 060254A0 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_060254B4;  // 060254A4 bra 0x060254B4 ; mov r14,r15
L_060254A8:
    c.r[6] += 1;  // 060254A8 add #1,r6
    c.r[1] = 0x49u;  // 060254AA mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 060254AC cmp/gt r1,r6
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_06025454; } }  // 060254AE bf/s 0x06025454 ; add #16,r7
    c.r[15] = c.r[14];  // 060254B2 mov r14,r15
L_060254B4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060254B4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060254BEu);  // 060254B6 mov.w 0x060254BE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060254B8 rts ; mov.l @r15+,r14
}

void f_060254D4(SH2Context& c) {
    ran[484] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060254D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060254D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060254D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060254DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060254DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060254DE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060254E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060254E2 sts.l pr,@-r15
    c.r[1] = ld32(0x0602555Cu);  // 060254E4 mov.l 0x0602555C,r1
    c.r[2] = ld32(c.r[1]);  // 060254E6 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060254E8 mov r2,r1
    c.r[1] += 1;  // 060254EA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060254EC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060254EE extu.b r1,r1
    c.r[10] = c.r[1];  // 060254F0 mov r1,r10
    c.r[10] <<= 8;  // 060254F2 shll8 r10
    c.r[1] = c.r[2];  // 060254F4 mov r2,r1
    c.r[1] += 2;  // 060254F6 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060254F8 mov.b @r1,r1
    c.r[15] -= 16;  // 060254FA add #-16,r15
    c.r[1] = c.r[1] & 0xFFu;  // 060254FC extu.b r1,r1
    c.r[10] |= c.r[1];  // 060254FE or r1,r10
    c.r[1] = c.r[2];  // 06025500 mov r2,r1
    c.r[1] += 3;  // 06025502 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025504 mov.b @r1,r1
    c.r[2] += 4;  // 06025506 add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06025508 extu.b r1,r1
    c.r[0] = c.r[1];  // 0602550A mov r1,r0
    c.r[0] <<= 8;  // 0602550C shll8 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602550E mov.b @r2,r1
    c.r[14] = c.r[15];  // 06025510 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06025512 extu.b r1,r1
    c.r[0] |= c.r[1];  // 06025514 or r1,r0
    c.r[1] = ld32(0x06025560u);  // 06025516 mov.l 0x06025560,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602551Cu; st32(c.r[14] + 8, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602551Cu) return; }  // 06025518 jsr @r1 ; mov.l r0,@(8,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025558u);  // 0602551C mov.w 0x06025558,r1
    c.r[4] = c.r[10];  // 0602551E mov r10,r4
    c.r[8] = ld32(c.r[14] + 8);  // 06025520 mov.l @(8,r14),r8
    c.r[13] = ld32(0x06025564u);  // 06025522 mov.l 0x06025564,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06025528u; c.r[8] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025528u) return; }  // 06025524 jsr @r13 ; and r1,r8
    c.r[1] = c.r[0];  // 06025528 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602552A extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0602552C mov.l r1,@(4,r14)
    c.r[9] = (uint32_t)(int16_t)ld16(0x0602555Au);  // 0602552E mov.w 0x0602555A,r9
    c.r[6] = 0x0u;  // 06025530 mov #0,r6
    c.r[1] = ld32(0x06025568u);  // 06025532 mov.l 0x06025568,r1
    c.r[7] = c.r[9];  // 06025534 mov r9,r7
    c.r[3] = ld32(c.r[1]);  // 06025536 mov.l @r1,r3
    c.r[5] = 0x0u;  // 06025538 mov #0,r5
    c.r[2] = c.r[3];  // 0602553A mov r3,r2
L_0602553C:
    c.r[0] = c.r[5];  // 0602553C mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0602553E mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06025540 extu.w r1,r1
    c.t = c.r[1] == c.r[8];  // 06025542 cmp/eq r8,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602556C; } }  // 06025544 bf/s 0x0602556C ; mov r2,r1
    c.r[1] += 15;  // 06025548 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602554A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602554C extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0602554E cmp/eq r7,r1
    { const bool k = !c.t; c.r[2] += 30; if (k) { goto L_0602556E; } }  // 06025550 bf/s 0x0602556E ; add #30,r2
    c.r[9] = c.r[6] & 0xFFu; goto L_06025578;  // 06025554 bra 0x06025578 ; extu.b r6,r9
L_0602556C:
    c.r[2] += 30;  // 0602556C add #30,r2
L_0602556E:
    c.r[6] += 1;  // 0602556E add #1,r6
    c.r[1] = 0x7Fu;  // 06025570 mov #127,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06025572 cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 30; if (k) { SH2_POLL(c); goto L_0602553C; } }  // 06025574 bf/s 0x0602553C ; add #30,r5
L_06025578:
    c.r[13] = ld32(0x0602573Cu);  // 06025578 mov.l 0x0602573C,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0602557Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602557Eu) return; }  // 0602557A jsr @r13 ; mov r10,r4
    c.r[1] = c.r[0];  // 0602557E mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06025580 extu.b r1,r12
    c.r[0] = ld32(c.r[14] + 4);  // 06025582 mov.l @(4,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025732u);  // 06025584 mov.w 0x06025732,r1
    c.t = c.r[0] == c.r[1];  // 06025586 cmp/eq r1,r0
    { const bool k = !c.t; c.t = c.r[9] == c.r[1]; if (k) { goto L_06025590; } }  // 06025588 bf/s 0x06025590 ; cmp/eq r1,r9
    goto L_0602581E;  // 0602558C bra 0x0602581E ; nop
L_06025590:
    { const bool k = !c.t; c.t = c.r[12] == c.r[1]; if (k) { goto L_06025598; } }  // 06025590 bf/s 0x06025598 ; cmp/eq r1,r12
    goto L_0602581E;  // 06025594 bra 0x0602581E ; nop
L_06025598:
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_060255A0; } }  // 06025598 bf/s 0x060255A0 ; mov #0,r13
    goto L_0602581E;  // 0602559C bra 0x0602581E ; nop
L_060255A0:
    st32(c.r[14], c.r[13]);  // 060255A0 mov.l r13,@r14
    c.r[10] = ld32(0x06025740u);  // 060255A2 mov.l 0x06025740,r10
    c.r[11] = 0x1Eu;  // 060255A4 mov #30,r11
    c.r[0] = 0x0u;  // 060255A6 mov #0,r0
    st32(c.r[14] + 12, c.r[0]);  // 060255A8 mov.l r0,@(12,r14)
L_060255AA:
    c.r[1] = ld32(0x06025744u);  // 060255AA mov.l 0x06025744,r1
    c.r[1] = ld32(c.r[1]);  // 060255AC mov.l @r1,r1
    c.r[3] = ld32(c.r[14] + 12);  // 060255AE mov.l @(12,r14),r3
    c.r[0] = ld32(c.r[14] + 12);  // 060255B0 mov.l @(12,r14),r0
    c.r[3] += c.r[1];  // 060255B2 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060255B4 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06025732u);  // 060255B6 mov.w 0x06025732,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060255B8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060255BA cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x49u; if (k) { goto L_060255C4; } }  // 060255BC bf/s 0x060255C4 ; mov #73,r1
    goto L_0602580C;  // 060255C0 bra 0x0602580C ; nop
L_060255C4:
    c.r[1] = c.r[3];  // 060255C4 mov r3,r1
    c.r[1] += 7;  // 060255C6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060255C8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060255CA mov r1,r0
    c.r[0] >>= 2;  // 060255CC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060255CE shlr r0
    c.r[0] &= 0x1u;  // 060255D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060255D2 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_060255DC; } }  // 060255D4 bt/s 0x060255DC ; mov.l @(12,r14),r0
    goto L_0602580A;  // 060255D8 bra 0x0602580A ; nop
L_060255DC:
    c.r[1] = c.r[3];  // 060255DC mov r3,r1
    c.r[1] += 3;  // 060255DE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060255E0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060255E2 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060255E4 shlr r0
    c.r[0] &= 0x3u;  // 060255E6 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060255E8 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_060255F2; } }  // 060255EA bt/s 0x060255F2 ; mov r3,r2
    goto L_06025808;  // 060255EE bra 0x06025808 ; nop
L_060255F2:
    c.r[2] += 2;  // 060255F2 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060255F4 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060255F6 extu.b r1,r1
    c.t = c.r[12] == c.r[1];  // 060255F8 cmp/eq r1,r12
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06025602; } }  // 060255FA bt/s 0x06025602 ; mov.l @(12,r14),r0
    goto L_0602580A;  // 060255FE bra 0x0602580A ; nop
L_06025602:
    c.macl = c.r[12] * c.r[11];  // 06025602 mul.l r11,r12
    c.r[1] = ld32(c.r[10]);  // 06025604 mov.l @r10,r1
    c.r[8] = c.macl;  // 06025606 sts macl,r8
    c.r[1] += c.r[8];  // 06025608 add r8,r1
    c.r[1] += 15;  // 0602560A add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602560C mov.b @r1,r1
    c.r[13] = ld32(c.r[14] + 4);  // 0602560E mov.l @(4,r14),r13
    c.r[1] = c.r[1] & 0xFFu;  // 06025610 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06025612 cmp/eq r13,r1
    { const bool k = c.t; c.r[1] = 0x49u; if (k) { goto L_0602561C; } }  // 06025614 bt/s 0x0602561C ; mov #73,r1
    goto L_0602580C;  // 06025618 bra 0x0602580C ; nop
L_0602561C:
    st8(c.r[2], c.r[9]);  // 0602561C mov.b r9,@r2
    c.r[0] = ld32(c.r[14] + 8);  // 0602561E mov.l @(8,r14),r0
    c.r[0] >>= 8;  // 06025620 shlr8 r0
    c.r[0] += c.r[0];  // 06025622 add r0,r0
    c.r[0] >>= 8;  // 06025624 shlr8 r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025626 tst r0,r0
    { const bool k = !c.t; st32(c.r[14] + 8, c.r[0]); if (k) { goto L_06025630; } }  // 06025628 bf/s 0x06025630 ; mov.l r0,@(8,r14)
    goto L_060257B6;  // 0602562C bra 0x060257B6 ; nop
L_06025630:
    c.r[2] = c.r[8];  // 06025630 mov r8,r2
    c.r[7] = 0x7u;  // 06025632 mov #7,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x06025734u);  // 06025634 mov.w 0x06025734,r13
    c.r[0] = 0x1u;  // 06025636 mov #1,r0
    c.macl = c.r[9] * c.r[11];  // 06025638 mul.l r11,r9
    c.r[1] = ld32(c.r[10]);  // 0602563A mov.l @r10,r1
    c.r[4] = c.r[8];  // 0602563C mov r8,r4
    c.r[2] += c.r[1];  // 0602563E add r1,r2
    c.r[5] = c.macl;  // 06025640 sts macl,r5
    c.r[3] = c.r[5];  // 06025642 mov r5,r3
    c.r[3] += c.r[1];  // 06025644 add r1,r3
    c.r[1] = c.r[2];  // 06025646 mov r2,r1
    c.r[1] += 3;  // 06025648 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602564A mov.b @r1,r1
    c.r[2] += 4;  // 0602564C add #4,r2
    c.r[7] &= c.r[1];  // 0602564E and r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025650 mov.b @r2,r1
    c.r[7] += c.r[7];  // 06025652 add r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06025654 extu.b r1,r1
    c.r[1] >>= 2;  // 06025656 shlr2 r1
    c.r[1] >>= 2;  // 06025658 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602565A shlr r1
    c.r[1] >>= 2;  // 0602565C shlr2 r1
    c.r[7] |= c.r[1];  // 0602565E or r1,r7
    c.r[2] = c.r[7];  // 06025660 mov r7,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06025662 shlr r2
    c.r[1] = c.r[3];  // 06025664 mov r3,r1
    c.r[1] += 3;  // 06025666 add #3,r1
    c.r[7] &= c.r[0];  // 06025668 and r0,r7
    c.r[3] += 4;  // 0602566A add #4,r3
    c.r[7] <<= 2;  // 0602566C shll2 r7
    c.r[7] <<= 2;  // 0602566E shll2 r7
    c.r[7] += c.r[7];  // 06025670 add r7,r7
    c.r[7] <<= 2;  // 06025672 shll2 r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025674 mov.b @r1,r6
    c.r[0] = 0x78u;  // 06025676 mov #120,r0
    c.r[6] &= c.r[13];  // 06025678 and r13,r6
    c.r[6] |= c.r[2];  // 0602567A or r2,r6
    st8(c.r[1], c.r[6]);  // 0602567C mov.b r6,@r1
    c.r[13] = 0x7Fu;  // 0602567E mov #127,r13
    c.r[2] = c.r[5];  // 06025680 mov r5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06025682 mov.b @r3,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06025736u);  // 06025684 mov.w 0x06025736,r6
    c.r[1] &= c.r[13];  // 06025686 and r13,r1
    c.r[1] |= c.r[7];  // 06025688 or r7,r1
    st8(c.r[3], c.r[1]);  // 0602568A mov.b r1,@r3
    c.r[1] = ld32(c.r[10]);  // 0602568C mov.l @r10,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06025738u);  // 0602568E mov.w 0x06025738,r13
    c.r[2] += c.r[1];  // 06025690 add r1,r2
    c.r[1] += c.r[8];  // 06025692 add r8,r1
    c.r[1] += 4;  // 06025694 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025696 mov.b @r1,r1
    c.r[2] += 4;  // 06025698 add #4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602569A mov.b @r2,r3
    c.r[1] &= c.r[0];  // 0602569C and r0,r1
    c.r[3] &= c.r[13];  // 0602569E and r13,r3
    c.r[3] |= c.r[1];  // 060256A0 or r1,r3
    st8(c.r[2], c.r[3]);  // 060256A2 mov.b r3,@r2
    c.r[1] = ld32(c.r[10]);  // 060256A4 mov.l @r10,r1
    c.r[7] = c.r[5];  // 060256A6 mov r5,r7
    c.r[7] += c.r[1];  // 060256A8 add r1,r7
    c.r[4] += c.r[1];  // 060256AA add r1,r4
    c.r[1] = c.r[4];  // 060256AC mov r4,r1
    c.r[1] += 4;  // 060256AE add #4,r1
    c.r[3] = c.r[7];  // 060256B0 mov r7,r3
    c.r[3] += 4;  // 060256B2 add #4,r3
    c.r[4] += 5;  // 060256B4 add #5,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060256B6 mov.w @r1,r1
    c.r[7] += 5;  // 060256B8 add #5,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060256BA mov.w @r3,r2
    c.r[6] &= c.r[1];  // 060256BC and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602573Au);  // 060256BE mov.w 0x0602573A,r1
    c.r[2] &= c.r[1];  // 060256C0 and r1,r2
    c.r[2] |= c.r[6];  // 060256C2 or r6,r2
    st16(c.r[3], c.r[2]);  // 060256C4 mov.w r2,@r3
    c.r[3] = 0x7u;  // 060256C6 mov #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060256C8 mov.b @r4,r1
    c.r[6] = 0x0u;  // 060256CA mov #0,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060256CC mov.b @r7,r2
    c.r[1] &= c.r[0];  // 060256CE and r0,r1
    c.r[2] &= c.r[13];  // 060256D0 and r13,r2
    c.r[2] |= c.r[1];  // 060256D2 or r1,r2
    st8(c.r[7], c.r[2]);  // 060256D4 mov.b r2,@r7
    c.r[2] = c.r[8];  // 060256D6 mov r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025734u);  // 060256D8 mov.w 0x06025734,r0
    c.r[1] = ld32(c.r[10]);  // 060256DA mov.l @r10,r1
    c.r[13] = 0x1u;  // 060256DC mov #1,r13
    c.r[5] += c.r[1];  // 060256DE add r1,r5
    c.r[2] += c.r[1];  // 060256E0 add r1,r2
    c.r[1] = c.r[2];  // 060256E2 mov r2,r1
    c.r[1] += 5;  // 060256E4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060256E6 mov.b @r1,r1
    c.r[2] += 6;  // 060256E8 add #6,r2
    c.r[3] &= c.r[1];  // 060256EA and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060256EC mov.b @r2,r1
    c.r[3] += c.r[3];  // 060256EE add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060256F0 extu.b r1,r1
    c.r[1] >>= 2;  // 060256F2 shlr2 r1
    c.r[1] >>= 2;  // 060256F4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060256F6 shlr r1
    c.r[1] >>= 2;  // 060256F8 shlr2 r1
    c.r[3] |= c.r[1];  // 060256FA or r1,r3
    c.r[2] = c.r[3];  // 060256FC mov r3,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060256FE shlr r2
    c.r[1] = c.r[5];  // 06025700 mov r5,r1
    c.r[1] += 5;  // 06025702 add #5,r1
    c.r[3] &= c.r[13];  // 06025704 and r13,r3
    c.r[5] += 6;  // 06025706 add #6,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025708 mov.b @r1,r7
    c.r[3] <<= 2;  // 0602570A shll2 r3
    c.r[3] <<= 2;  // 0602570C shll2 r3
    c.r[3] += c.r[3];  // 0602570E add r3,r3
    c.r[3] <<= 2;  // 06025710 shll2 r3
    c.r[7] &= c.r[0];  // 06025712 and r0,r7
    c.r[7] |= c.r[2];  // 06025714 or r2,r7
    st8(c.r[1], c.r[7]);  // 06025716 mov.b r7,@r1
    c.r[0] = 0x7Fu;  // 06025718 mov #127,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602571A mov.b @r5,r1
    c.r[7] = 0x7u;  // 0602571C mov #7,r7
    c.r[1] &= c.r[0];  // 0602571E and r0,r1
    c.r[1] |= c.r[3];  // 06025720 or r3,r1
    st8(c.r[5], c.r[1]);  // 06025722 mov.b r1,@r5
L_06025724:
    c.macl = c.r[9] * c.r[11];  // 06025724 mul.l r11,r9
    c.r[1] = ld32(c.r[10]);  // 06025726 mov.l @r10,r1
    c.r[3] = c.macl;  // 06025728 sts macl,r3
    c.r[3] += c.r[1];  // 0602572A add r1,r3
    c.macl = c.r[12] * c.r[11];  // 0602572C mul.l r11,r12
    c.r[3] += c.r[6]; goto L_06025748;  // 0602572E bra 0x06025748 ; add r6,r3
L_06025748:
    c.r[3] += 7;  // 06025748 add #7,r3
    c.r[2] = c.macl;  // 0602574A sts macl,r2
    c.r[2] += c.r[1];  // 0602574C add r1,r2
    c.r[2] += c.r[6];  // 0602574E add r6,r2
    c.r[2] += 7;  // 06025750 add #7,r2
    c.r[6] += 1;  // 06025752 add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025754 mov.b @r2,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 06025756 cmp/gt r7,r6
    { const bool k = !c.t; st8(c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_06025724; } }  // 06025758 bf/s 0x06025724 ; mov.b r1,@r3
    c.r[6] = 0x0u;  // 0602575C mov #0,r6
    c.r[5] = 0x3u;  // 0602575E mov #3,r5
L_06025760:
    c.macl = c.r[9] * c.r[11];  // 06025760 mul.l r11,r9
    c.r[1] = ld32(c.r[10]);  // 06025762 mov.l @r10,r1
    c.r[7] = c.macl;  // 06025764 sts macl,r7
    c.r[2] = c.r[7];  // 06025766 mov r7,r2
    c.r[2] += c.r[1];  // 06025768 add r1,r2
    c.macl = c.r[12] * c.r[11];  // 0602576A mul.l r11,r12
    c.r[2] += c.r[6];  // 0602576C add r6,r2
    c.r[2] += 17;  // 0602576E add #17,r2
    c.r[3] = c.macl;  // 06025770 sts macl,r3
    c.r[1] += c.r[3];  // 06025772 add r3,r1
    c.r[1] += c.r[6];  // 06025774 add r6,r1
    c.r[1] += 17;  // 06025776 add #17,r1
    c.r[6] += 1;  // 06025778 add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602577A mov.b @r1,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[5];  // 0602577C cmp/gt r5,r6
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06025760; } }  // 0602577E bf/s 0x06025760 ; mov.b r1,@r2
    c.r[1] = ld32(c.r[10]);  // 06025782 mov.l @r10,r1
    c.r[2] = c.r[7];  // 06025784 mov r7,r2
    c.r[2] += c.r[1];  // 06025786 add r1,r2
    c.r[1] += c.r[3];  // 06025788 add r3,r1
    c.r[1] += 3;  // 0602578A add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602578C mov.b @r1,r0
    c.r[2] += 3;  // 0602578E add #3,r2
    c.r[1] = 0x78u;  // 06025790 mov #120,r1
    c.r[1] &= c.r[0];  // 06025792 and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025794 mov.b @r2,r0
    c.r[0] &= 0x87u;  // 06025796 and #135,r0
    c.r[0] |= c.r[1];  // 06025798 or r1,r0
    st8(c.r[2], c.r[0]);  // 0602579A mov.b r0,@r2
    c.r[1] = ld32(c.r[10]);  // 0602579C mov.l @r10,r1
    c.r[7] += c.r[1];  // 0602579E add r1,r7
    c.r[2] = c.r[7];  // 060257A0 mov r7,r2
    c.r[2] += 22;  // 060257A2 add #22,r2
    c.r[3] += c.r[1];  // 060257A4 add r1,r3
    c.r[1] = c.r[3];  // 060257A6 mov r3,r1
    c.r[1] += 22;  // 060257A8 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060257AA mov.w @r1,r1
    c.r[3] += 24;  // 060257AC add #24,r3
    st16(c.r[2], c.r[1]);  // 060257AE mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060257B0 mov.w @r3,r1
    c.r[7] += 24;  // 060257B2 add #24,r7
    st16(c.r[7], c.r[1]);  // 060257B4 mov.w r1,@r7
L_060257B6:
    c.r[13] = 0x7u;  // 060257B6 mov #7,r13
    c.r[13] += c.r[14];  // 060257B8 add r14,r13
    c.macl = c.r[12] * c.r[11];  // 060257BA mul.l r11,r12
    c.r[0] = 0x3u;  // 060257BC mov #3,r0
    c.r[1] = ld32(c.r[10]);  // 060257BE mov.l @r10,r1
    c.r[2] = c.macl;  // 060257C0 sts macl,r2
    c.r[2] += c.r[1];  // 060257C2 add r1,r2
    c.r[2] += 15;  // 060257C4 add #15,r2
    c.r[1] = 0xFFFFFFFFu;  // 060257C6 mov #-1,r1
    c.macl = c.r[9] * c.r[11];  // 060257C8 mul.l r11,r9
    st8(c.r[2], c.r[1]);  // 060257CA mov.b r1,@r2
    c.r[1] = ld32(c.r[10]);  // 060257CC mov.l @r10,r1
    c.r[2] = c.macl;  // 060257CE sts macl,r2
    c.r[2] += c.r[1];  // 060257D0 add r1,r2
    c.r[2] += 15;  // 060257D2 add #15,r2
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060257D4 mov.b @r13,r13
    c.r[0] += c.r[14];  // 060257D6 add r14,r0
    st8(c.r[2], c.r[13]);  // 060257D8 mov.b r13,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060257DA mov.b @r0,r0
    c.r[1] = ld32(0x0602583Cu);  // 060257DC mov.l 0x0602583C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060257E2u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060257E2u) return; }  // 060257DE jsr @r1 ; extu.b r0,r4
    c.r[1] = ld32(0x06025840u);  // 060257E2 mov.l 0x06025840,r1
    c.r[1] = ld32(c.r[1]);  // 060257E4 mov.l @r1,r1
    c.r[13] = ld32(c.r[14] + 12);  // 060257E6 mov.l @(12,r14),r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025836u);  // 060257E8 mov.w 0x06025836,r0
    c.r[1] += c.r[13];  // 060257EA add r13,r1
    c.r[1] += 7;  // 060257EC add #7,r1
    c.r[13] = 0x3u;  // 060257EE mov #3,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060257F0 mov.b @r1,r2
    c.r[13] += c.r[14];  // 060257F2 add r14,r13
    c.r[2] &= c.r[0];  // 060257F4 and r0,r2
    st8(c.r[1], c.r[2]);  // 060257F6 mov.b r2,@r1
    c.r[1] = ld32(0x06025844u);  // 060257F8 mov.l 0x06025844,r1
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060257FA mov.b @r13,r13
    st8(c.r[1], c.r[13]);  // 060257FC mov.b r13,@r1
    c.r[1] = ld32(0x06025848u);  // 060257FE mov.l 0x06025848,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025804u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025804u) return; }  // 06025800 jsr @r1 ; nop
    c.r[14] += 16; goto L_06025820;  // 06025804 bra 0x06025820 ; add #16,r14
L_06025808:
    c.r[0] = ld32(c.r[14] + 12);  // 06025808 mov.l @(12,r14),r0
L_0602580A:
    c.r[1] = 0x49u;  // 0602580A mov #73,r1
L_0602580C:
    c.r[13] = ld32(c.r[14]);  // 0602580C mov.l @r14,r13
    c.r[0] += 16;  // 0602580E add #16,r0
    st32(c.r[14] + 12, c.r[0]);  // 06025810 mov.l r0,@(12,r14)
    c.r[13] += 1;  // 06025812 add #1,r13
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 06025814 cmp/gt r1,r13
    { const bool k = c.t; st32(c.r[14], c.r[13]); if (k) { goto L_0602581E; } }  // 06025816 bt/s 0x0602581E ; mov.l r13,@r14
    SH2_POLL(c); goto L_060255AA;  // 0602581A bra 0x060255AA ; nop
L_0602581E:
    c.r[14] += 16;  // 0602581E add #16,r14
L_06025820:
    c.r[15] = c.r[14];  // 06025820 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025822 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06025824 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06025826 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06025828 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602582A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602582C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602582E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025838u);  // 06025830 mov.w 0x06025838,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025832 rts ; mov.l @r15+,r8
}

void f_0602584C(SH2Context& c) {
    ran[485] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602584C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602584E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06025850 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06025852 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025854 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025856 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06025858 mov r15,r14
    c.r[1] = ld32(0x060258F4u);  // 0602585A mov.l 0x060258F4,r1
    c.r[2] = ld32(c.r[1]);  // 0602585C mov.l @r1,r2
    c.r[11] = ld32(0x060258F8u);  // 0602585E mov.l 0x060258F8,r11
    c.r[1] = c.r[2];  // 06025860 mov r2,r1
    c.r[1] += 1;  // 06025862 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025864 mov.b @r1,r8
    c.r[2] += 2;  // 06025866 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 06025868 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602586A mov.b @r2,r1
    c.r[8] <<= 8;  // 0602586C shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602586E extu.b r1,r1
    c.r[8] |= c.r[1];  // 06025870 or r1,r8
    c.r[1] = ld32(0x060258FCu);  // 06025872 mov.l 0x060258FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025878u; c.r[11] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025878u) return; }  // 06025874 jsr @r1 ; and r8,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x060258EEu);  // 06025878 mov.w 0x060258EE,r1
    c.r[8] &= c.r[1];  // 0602587A and r1,r8
    c.r[0] = ld32(0x06025900u);  // 0602587C mov.l 0x06025900,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06025882u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025882u) return; }  // 0602587E jsr @r0 ; mov r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06025882 extu.b r0,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060258F0u);  // 06025884 mov.w 0x060258F0,r10
    c.t = c.r[0] == c.r[10];  // 06025886 cmp/eq r10,r0
    { const bool k = c.t; c.r[0] <<= 2; if (k) { goto L_060258DC; } }  // 06025888 bt/s 0x060258DC ; shll2 r0
    c.r[1] = ld32(0x06025904u);  // 0602588C mov.l 0x06025904,r1
    c.r[1] = ld32(c.r[1]);  // 0602588E mov.l @r1,r1
    c.r[0] <<= 2;  // 06025890 shll2 r0
    c.r[0] += c.r[1];  // 06025892 add r1,r0
    c.r[0] += 2;  // 06025894 add #2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06025896 mov.b @r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06025898 extu.b r1,r9
    c.t = c.r[9] == c.r[10];  // 0602589A cmp/eq r10,r9
    if (c.t) { goto L_060258DC; }  // 0602589C bt 0x060258DC
    c.r[1] = ld32(0x06025908u);  // 0602589E mov.l 0x06025908,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060258A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060258A4u) return; }  // 060258A0 jsr @r1 ; nop
    c.t = (c.r[11] & c.r[11]) == 0;  // 060258A4 tst r11,r11
    { const bool k = c.t; c.r[6] = c.r[10]; if (k) { goto L_060258CA; } }  // 060258A6 bt/s 0x060258CA ; mov r10,r6
    c.r[8] = ld32(0x0602590Cu);  // 060258AA mov.l 0x0602590C,r8
    c.r[1] = ld32(0x06025910u);  // 060258AC mov.l 0x06025910,r1
    c.r[4] = ld32(c.r[8]);  // 060258AE mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060258B4u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060258B4u) return; }  // 060258B0 jsr @r1 ; mov r9,r5
    c.r[1] = ld32(0x06025914u);  // 060258B4 mov.l 0x06025914,r1
    c.r[2] = ld32(c.r[1]);  // 060258B6 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060258B8 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 060258BA mul.l r1,r9
    c.r[3] = c.macl;  // 060258BC sts macl,r3
    c.r[1] = ld32(c.r[8]);  // 060258BE mov.l @r8,r1
    c.r[3] += c.r[2];  // 060258C0 add r2,r3
    c.r[1] += 28;  // 060258C2 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060258C4 mov.w @r1,r1
    c.r[3] += 24; goto L_060258DA;  // 060258C6 bra 0x060258DA ; add #24,r3
L_060258CA:
    c.r[1] = ld32(0x06025914u);  // 060258CA mov.l 0x06025914,r1
    c.r[2] = ld32(c.r[1]);  // 060258CC mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060258CE mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 060258D0 mul.l r1,r9
    c.r[3] = c.macl;  // 060258D2 sts macl,r3
    c.r[3] += c.r[2];  // 060258D4 add r2,r3
    c.r[3] += 24;  // 060258D6 add #24,r3
    c.r[1] = 0x0u;  // 060258D8 mov #0,r1
L_060258DA:
    st16(c.r[3], c.r[1]);  // 060258DA mov.w r1,@r3
L_060258DC:
    c.r[15] = c.r[14];  // 060258DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060258DE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060258E0 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060258E2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060258E4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060258E6 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060258F2u);  // 060258E8 mov.w 0x060258F2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060258EA rts ; mov.l @r15+,r8
}

void f_06025918(SH2Context& c) {
    ran[486] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06025918 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602591A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602591C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602591E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025920 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025922 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06025924 mov r15,r14
    c.r[1] = ld32(0x06025A10u);  // 06025926 mov.l 0x06025A10,r1
    c.r[2] = ld32(c.r[1]);  // 06025928 mov.l @r1,r2
    c.r[11] = ld32(0x06025A14u);  // 0602592A mov.l 0x06025A14,r11
    c.r[1] = c.r[2];  // 0602592C mov r2,r1
    c.r[1] += 1;  // 0602592E add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025930 mov.b @r1,r8
    c.r[2] += 2;  // 06025932 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 06025934 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025936 mov.b @r2,r1
    c.r[8] <<= 8;  // 06025938 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602593A extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602593C or r1,r8
    c.r[1] = ld32(0x06025A18u);  // 0602593E mov.l 0x06025A18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025944u; c.r[11] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025944u) return; }  // 06025940 jsr @r1 ; and r8,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025A0Au);  // 06025944 mov.w 0x06025A0A,r1
    c.r[8] &= c.r[1];  // 06025946 and r1,r8
    c.r[0] = ld32(0x06025A1Cu);  // 06025948 mov.l 0x06025A1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602594Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602594Eu) return; }  // 0602594A jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0] & 0xFFu;  // 0602594E extu.b r0,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06025A0Cu);  // 06025950 mov.w 0x06025A0C,r9
    c.t = c.r[10] == c.r[9];  // 06025952 cmp/eq r9,r10
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_060259F8; } }  // 06025954 bt/s 0x060259F8 ; mov r10,r2
    c.r[1] = ld32(0x06025A20u);  // 06025958 mov.l 0x06025A20,r1
    c.r[1] = ld32(c.r[1]);  // 0602595A mov.l @r1,r1
    c.r[2] <<= 2;  // 0602595C shll2 r2
    c.r[2] <<= 2;  // 0602595E shll2 r2
    c.r[2] += c.r[1];  // 06025960 add r1,r2
    c.r[2] += 2;  // 06025962 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025964 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06025966 extu.b r1,r8
    c.t = c.r[8] == c.r[9];  // 06025968 cmp/eq r9,r8
    if (c.t) { goto L_060259F8; }  // 0602596A bt 0x060259F8
    c.r[1] = ld32(0x06025A24u);  // 0602596C mov.l 0x06025A24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025972u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025972u) return; }  // 0602596E jsr @r1 ; nop
    c.t = (c.r[11] & c.r[11]) == 0;  // 06025972 tst r11,r11
    { const bool k = c.t; c.r[5] = 0x1Bu; if (k) { goto L_0602599E; } }  // 06025974 bt/s 0x0602599E ; mov #27,r5
    c.r[1] = ld32(0x06025A28u);  // 06025978 mov.l 0x06025A28,r1
    c.r[6] = c.r[9];  // 0602597A mov r9,r6
    c.r[4] = ld32(c.r[1]);  // 0602597C mov.l @r1,r4
    c.r[1] = ld32(0x06025A2Cu);  // 0602597E mov.l 0x06025A2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025984u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025984u) return; }  // 06025980 jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06025A30u);  // 06025984 mov.l 0x06025A30,r1
    c.r[2] = ld32(c.r[1]);  // 06025986 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06025988 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602598A mul.l r1,r8
    c.r[1] = c.macl;  // 0602598C sts macl,r1
    c.r[0] = c.r[1];  // 0602598E mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06025990 mov.w @(r0,r2),r5
    c.r[4] = c.r[10];  // 06025992 mov r10,r4
    c.r[1] = ld32(0x06025A34u);  // 06025994 mov.l 0x06025A34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602599Au; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602599Au) return; }  // 06025996 jsr @r1 ; extu.w r5,r5
    c.r[15] = c.r[14]; goto L_060259FA;  // 0602599A bra 0x060259FA ; mov r14,r15
L_0602599E:
    c.r[1] = ld32(0x06025A30u);  // 0602599E mov.l 0x06025A30,r1
    c.r[2] = ld32(c.r[1]);  // 060259A0 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060259A2 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 060259A4 mul.l r1,r8
    c.r[4] = ld32(0x06025A38u);  // 060259A6 mov.l 0x06025A38,r4
    c.r[9] = ld32(0x06025A3Cu);  // 060259A8 mov.l 0x06025A3C,r9
    c.r[1] = c.macl;  // 060259AA sts macl,r1
    c.r[0] = c.macl;  // 060259AC sts macl,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060259AE mov.w @(r0,r2),r8
    { const uint32_t x = c.r[9]; c.pr = 0x060259B4u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060259B4u) return; }  // 060259B0 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060259B4 mov r0,r1
    c.r[5] = c.r[8];  // 060259B6 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060259BCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060259BCu) return; }  // 060259B8 jsr @r9 ; mov r1,r4
    c.r[3] = c.r[0];  // 060259BC mov r0,r3
    c.r[7] = ld32(0x06025A40u);  // 060259BE mov.l 0x06025A40,r7
    c.r[3] += 48;  // 060259C0 add #48,r3
L_060259C2:
    c.r[0] = c.r[3];  // 060259C2 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060259C4 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060259C6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060259C8 mov.b @r0,r1
    c.r[2] <<= 8;  // 060259CA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060259CC extu.b r1,r1
    c.r[2] |= c.r[1];  // 060259CE or r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060259D0 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060259F8; } }  // 060259D2 bt/s 0x060259F8 ; mov r3,r1
    c.r[1] += 2;  // 060259D6 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060259D8 mov.b @r1,r0
    c.r[6] = 0x7Fu;  // 060259DA mov #127,r6
    c.r[6] &= c.r[0];  // 060259DC and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 060259DE tst r6,r6
    if (c.t) { goto L_060259F4; }  // 060259E0 bt 0x060259F4
    c.r[1] = ld32(c.r[7]);  // 060259E2 mov.l @r7,r1
    c.r[2] = c.r[10];  // 060259E4 mov r10,r2
    c.r[2] <<= 2;  // 060259E6 shll2 r2
    c.r[2] <<= 2;  // 060259E8 shll2 r2
    c.r[2] += c.r[1];  // 060259EA add r1,r2
    c.r[2] += c.r[6];  // 060259EC add r6,r2
    c.r[2] += 39;  // 060259EE add #39,r2
    c.r[1] = 0x0u;  // 060259F0 mov #0,r1
    st8(c.r[2], c.r[1]);  // 060259F2 mov.b r1,@r2
L_060259F4:
    c.r[3] += 4; SH2_POLL(c); goto L_060259C2;  // 060259F4 bra 0x060259C2 ; add #4,r3
L_060259F8:
    c.r[15] = c.r[14];  // 060259F8 mov r14,r15
L_060259FA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060259FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060259FC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060259FE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06025A00 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06025A02 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025A0Eu);  // 06025A04 mov.w 0x06025A0E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025A06 rts ; mov.l @r15+,r8
}

void f_06025A44(SH2Context& c) {
    ran[487] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06025A44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06025A46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025A48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025A4A sts.l pr,@-r15
    c.r[1] = ld32(0x06025AD4u);  // 06025A4C mov.l 0x06025AD4,r1
    c.r[2] = ld32(c.r[1]);  // 06025A4E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06025A50 mov r2,r1
    c.r[1] += 3;  // 06025A52 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025A54 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06025A56 extu.b r1,r9
    c.r[1] = c.r[2];  // 06025A58 mov r2,r1
    c.r[1] += 1;  // 06025A5A add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025A5C mov.b @r1,r8
    c.r[2] += 2;  // 06025A5E add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 06025A60 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025A62 mov.b @r2,r1
    c.r[8] <<= 8;  // 06025A64 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 06025A66 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06025A68 or r1,r8
    c.r[1] = ld32(0x06025AD8u);  // 06025A6A mov.l 0x06025AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025A70u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025A70u) return; }  // 06025A6C jsr @r1 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025ACCu);  // 06025A70 mov.w 0x06025ACC,r1
    c.r[8] &= c.r[1];  // 06025A72 and r1,r8
    c.r[0] = ld32(0x06025ADCu);  // 06025A74 mov.l 0x06025ADC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06025A7Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025A7Au) return; }  // 06025A76 jsr @r0 ; mov r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06025A7A extu.b r0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06025ACEu);  // 06025A7C mov.w 0x06025ACE,r2
    c.t = c.r[0] == c.r[2];  // 06025A7E cmp/eq r2,r0
    { const bool k = c.t; c.r[0] <<= 2; if (k) { goto L_06025ABE; } }  // 06025A80 bt/s 0x06025ABE ; shll2 r0
    c.r[1] = ld32(0x06025AE0u);  // 06025A84 mov.l 0x06025AE0,r1
    c.r[1] = ld32(c.r[1]);  // 06025A86 mov.l @r1,r1
    c.r[0] <<= 2;  // 06025A88 shll2 r0
    c.r[0] += c.r[1];  // 06025A8A add r1,r0
    c.r[0] += 2;  // 06025A8C add #2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06025A8E mov.b @r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06025A90 extu.b r1,r8
    c.t = c.r[8] == c.r[2];  // 06025A92 cmp/eq r2,r8
    if (c.t) { goto L_06025ABE; }  // 06025A94 bt 0x06025ABE
    c.r[1] = ld32(0x06025AE4u);  // 06025A96 mov.l 0x06025AE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025A9Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025A9Cu) return; }  // 06025A98 jsr @r1 ; nop
    c.r[1] = ld32(0x06025AE8u);  // 06025A9C mov.l 0x06025AE8,r1
    c.r[2] = ld32(c.r[1]);  // 06025A9E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06025AA0 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06025AA2 mul.l r1,r8
    c.r[3] = c.macl;  // 06025AA4 sts macl,r3
    c.r[3] += c.r[2];  // 06025AA6 add r2,r3
    c.r[3] += 24;  // 06025AA8 add #24,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06025AAA mov.w @r3,r7
    c.r[1] = c.r[9] & 0xFFFFu;  // 06025AAC extu.w r9,r1
    c.r[2] = c.r[7] & 0xFFFFu;  // 06025AAE extu.w r7,r2
    c.t = c.r[2] >= c.r[1];  // 06025AB0 cmp/hs r1,r2
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06025ABA; } }  // 06025AB2 bf/s 0x06025ABA ; mov r7,r1
    c.r[1] -= c.r[9]; goto L_06025ABC;  // 06025AB6 bra 0x06025ABC ; sub r9,r1
L_06025ABA:
    c.r[1] = 0x0u;  // 06025ABA mov #0,r1
L_06025ABC:
    st16(c.r[3], c.r[1]);  // 06025ABC mov.w r1,@r3
L_06025ABE:
    c.r[15] = c.r[14];  // 06025ABE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025AC0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06025AC2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06025AC4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025AD0u);  // 06025AC6 mov.w 0x06025AD0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025AC8 rts ; mov.l @r15+,r8
}

void f_06025AEC(SH2Context& c) {
    ran[488] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025AEC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025AEE sts.l pr,@-r15
    c.r[1] = ld32(0x06025B6Cu);  // 06025AF0 mov.l 0x06025B6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025AF6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025AF6u) return; }  // 06025AF2 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06025B70u);  // 06025AF6 mov.l 0x06025B70,r1
    c.r[2] = ld32(c.r[1]);  // 06025AF8 mov.l @r1,r2
    c.r[0] = ld32(0x06025B74u);  // 06025AFA mov.l 0x06025B74,r0
    c.r[1] = c.r[2];  // 06025AFC mov r2,r1
    c.r[1] += 1;  // 06025AFE add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025B00 mov.b @r1,r4
    c.r[2] += 2;  // 06025B02 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06025B04 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025B06 mov.b @r2,r1
    c.r[4] <<= 8;  // 06025B08 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06025B0A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06025B10u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025B10u) return; }  // 06025B0C jsr @r0 ; or r1,r4
    c.r[2] = c.r[0] & 0xFFu;  // 06025B10 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025B68u);  // 06025B12 mov.w 0x06025B68,r1
    c.t = c.r[2] == c.r[1];  // 06025B14 cmp/eq r1,r2
    { const bool k = c.t; c.r[3] = c.r[2]; if (k) { goto L_06025B5E; } }  // 06025B16 bt/s 0x06025B5E ; mov r2,r3
    c.r[1] = ld32(0x06025B78u);  // 06025B1A mov.l 0x06025B78,r1
    c.r[7] = ld32(c.r[1]);  // 06025B1C mov.l @r1,r7
    c.r[3] <<= 2;  // 06025B1E shll2 r3
    c.r[3] <<= 2;  // 06025B20 shll2 r3
    c.r[3] += c.r[7];  // 06025B22 add r7,r3
    c.r[1] = c.r[3];  // 06025B24 mov r3,r1
    c.r[1] += 4;  // 06025B26 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025B28 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06025B2A mov r1,r0
    c.r[0] >>= 2;  // 06025B2C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06025B2E shlr r0
    c.r[0] >>= 2;  // 06025B30 shlr2 r0
    c.r[0] &= 0x1u;  // 06025B32 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025B34 tst r0,r0
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_06025B42; } }  // 06025B36 bt/s 0x06025B42 ; shll2 r2
    c.r[3] += 6;  // 06025B3A add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06025B3C mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06025B3E extu.b r1,r2
    c.r[2] <<= 2;  // 06025B40 shll2 r2
L_06025B42:
    c.r[2] <<= 2;  // 06025B42 shll2 r2
    c.r[2] += c.r[7];  // 06025B44 add r7,r2
    c.r[2] += 4;  // 06025B46 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025B48 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06025B4A mov r1,r0
    c.r[0] >>= 2;  // 06025B4C shlr2 r0
    c.r[0] >>= 2;  // 06025B4E shlr2 r0
    c.r[0] >>= 2;  // 06025B50 shlr2 r0
    c.r[0] &= 0x1u;  // 06025B52 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06025B54 tst r0,r0
    if (c.t) { goto L_06025B5E; }  // 06025B56 bt 0x06025B5E
    c.r[1] = ld32(0x06025B7Cu);  // 06025B58 mov.l 0x06025B7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025B5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025B5Eu) return; }  // 06025B5A jsr @r1 ; nop
L_06025B5E:
    c.r[15] = c.r[14];  // 06025B5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025B60 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025B6Au);  // 06025B62 mov.w 0x06025B6A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025B64 rts ; mov.l @r15+,r14
}

void f_06025B80(SH2Context& c) {
    ran[489] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06025B80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06025B82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06025B84 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06025B86 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06025B88 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025B8A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025B8C sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06025CE0u);  // 06025B8E mov.w 0x06025CE0,r3
    c.r[8] = ld32(0x06025CE4u);  // 06025B90 mov.l 0x06025CE4,r8
    c.r[1] = ld32(c.r[8]);  // 06025B92 mov.l @r8,r1
    c.r[15] += c.r[3];  // 06025B94 add r3,r15
    c.r[1] += 3;  // 06025B96 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025B98 mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06025B9A extu.b r1,r11
    c.r[1] = ld32(0x06025CE8u);  // 06025B9C mov.l 0x06025CE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025BA2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025BA2u) return; }  // 06025B9E jsr @r1 ; mov r15,r14
    c.r[9] = c.r[11];  // 06025BA2 mov r11,r9
    c.r[9] >>= 2;  // 06025BA4 shlr2 r9
    c.r[9] >>= 2;  // 06025BA6 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06025BA8 shlr r9
    c.r[9] >>= 2;  // 06025BAA shlr2 r9
    c.r[12] = 0x1u;  // 06025BAC mov #1,r12
    c.r[9] ^= c.r[12];  // 06025BAE xor r12,r9
    c.r[2] = ld32(c.r[8]);  // 06025BB0 mov.l @r8,r2
    c.r[0] = ld32(0x06025CECu);  // 06025BB2 mov.l 0x06025CEC,r0
    c.r[1] = c.r[2];  // 06025BB4 mov r2,r1
    c.r[1] += 1;  // 06025BB6 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025BB8 mov.b @r1,r4
    c.r[2] += 2;  // 06025BBA add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06025BBC extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025BBE mov.b @r2,r1
    c.r[4] <<= 8;  // 06025BC0 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06025BC2 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06025BC8u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025BC8u) return; }  // 06025BC4 jsr @r0 ; or r1,r4
    c.r[10] = c.r[0] & 0xFFu;  // 06025BC8 extu.b r0,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025CE2u);  // 06025BCA mov.w 0x06025CE2,r1
    c.t = c.r[10] == c.r[1];  // 06025BCC cmp/eq r1,r10
    if (!c.t) { goto L_06025BD4; }  // 06025BCE bf 0x06025BD4
    goto L_06025E66;  // 06025BD0 bra 0x06025E66 ; nop
L_06025BD4:
    c.r[1] = ld32(0x06025CF0u);  // 06025BD4 mov.l 0x06025CF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025BDAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025BDAu) return; }  // 06025BD6 jsr @r1 ; nop
    c.r[0] = c.r[11];  // 06025BDA mov r11,r0
    c.r[0] &= 0x7Fu;  // 06025BDC and #127,r0
    c.r[1] = 0xAu;  // 06025BDE mov #10,r1
    c.t = c.r[0] > c.r[1];  // 06025BE0 cmp/hi r1,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06025BEA; } }  // 06025BE2 bf/s 0x06025BEA ; mov r0,r1
    goto L_06025E66;  // 06025BE6 bra 0x06025E66 ; nop
L_06025BEA:
    c.r[1] += c.r[1];  // 06025BEA add r1,r1
    c.r[0] = 0x06025BF8u;  // 06025BEC mova 0x06025BF8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06025BEE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06025BF0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06025C0Eu: goto L_06025C0E; case 0x06025C28u: goto L_06025C28; case 0x06025C40u: goto L_06025C40; case 0x06025C58u: goto L_06025C58; case 0x06025C6Eu: goto L_06025C6E; case 0x06025C84u: goto L_06025C84; case 0x06025C98u: goto L_06025C98; case 0x06025CB6u: goto L_06025CB6; case 0x06025CF8u: goto L_06025CF8; case 0x06025D66u: goto L_06025D66; case 0x06025DA2u: goto L_06025DA2; default: sh2_call(c, x); return; } }  // 06025BF2 jmp @r0 ; nop
L_06025C0E:
    c.r[1] = ld32(0x06025CF4u);  // 06025C0E mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C10 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C12 mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C14 shll2 r2
    c.r[2] <<= 2;  // 06025C16 shll2 r2
    c.r[2] += c.r[1];  // 06025C18 add r1,r2
    c.r[2] += 10;  // 06025C1A add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025C1C mov.b @r2,r0
    c.r[9] <<= 2;  // 06025C1E shll2 r9
    c.r[9] <<= 2;  // 06025C20 shll2 r9
    c.r[9] <<= 2;  // 06025C22 shll2 r9
    c.r[0] &= 0xBFu; goto L_06025CB0;  // 06025C24 bra 0x06025CB0 ; and #191,r0
L_06025C28:
    c.r[1] = ld32(0x06025CF4u);  // 06025C28 mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C2A mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C2C mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C2E shll2 r2
    c.r[2] <<= 2;  // 06025C30 shll2 r2
    c.r[2] += c.r[1];  // 06025C32 add r1,r2
    c.r[2] += 10;  // 06025C34 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025C36 mov.b @r2,r0
    c.r[9] <<= 2;  // 06025C38 shll2 r9
    c.r[9] <<= 2;  // 06025C3A shll2 r9
    c.r[0] &= 0xEFu; goto L_06025CB0;  // 06025C3C bra 0x06025CB0 ; and #239,r0
L_06025C40:
    c.r[1] = ld32(0x06025CF4u);  // 06025C40 mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C42 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C44 mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C46 shll2 r2
    c.r[2] <<= 2;  // 06025C48 shll2 r2
    c.r[2] += c.r[1];  // 06025C4A add r1,r2
    c.r[2] += 10;  // 06025C4C add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025C4E mov.b @r2,r0
    c.r[9] <<= 2;  // 06025C50 shll2 r9
    c.r[9] += c.r[9];  // 06025C52 add r9,r9
    c.r[0] &= 0xF7u; goto L_06025CB0;  // 06025C54 bra 0x06025CB0 ; and #247,r0
L_06025C58:
    c.r[1] = ld32(0x06025CF4u);  // 06025C58 mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C5A mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C5C mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C5E shll2 r2
    c.r[2] <<= 2;  // 06025C60 shll2 r2
    c.r[2] += c.r[1];  // 06025C62 add r1,r2
    c.r[2] += 10;  // 06025C64 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025C66 mov.b @r2,r0
    c.r[9] <<= 2;  // 06025C68 shll2 r9
    c.r[0] &= 0xFBu; goto L_06025CB0;  // 06025C6A bra 0x06025CB0 ; and #251,r0
L_06025C6E:
    c.r[1] = ld32(0x06025CF4u);  // 06025C6E mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C70 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C72 mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C74 shll2 r2
    c.r[2] <<= 2;  // 06025C76 shll2 r2
    c.r[2] += c.r[1];  // 06025C78 add r1,r2
    c.r[2] += 10;  // 06025C7A add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025C7C mov.b @r2,r0
    c.r[9] += c.r[9];  // 06025C7E add r9,r9
    c.r[0] &= 0xFDu; goto L_06025CB0;  // 06025C80 bra 0x06025CB0 ; and #253,r0
L_06025C84:
    c.r[1] = ld32(0x06025CF4u);  // 06025C84 mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C86 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C88 mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C8A shll2 r2
    c.r[2] <<= 2;  // 06025C8C shll2 r2
    c.r[2] += c.r[1];  // 06025C8E add r1,r2
    c.r[2] += 10;  // 06025C90 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025C92 mov.b @r2,r0
    c.r[0] &= 0xFEu; goto L_06025CB0;  // 06025C94 bra 0x06025CB0 ; and #254,r0
L_06025C98:
    c.r[1] = ld32(0x06025CF4u);  // 06025C98 mov.l 0x06025CF4,r1
    c.r[2] = c.r[10];  // 06025C9A mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06025C9C mov.l @r1,r1
    c.r[2] <<= 2;  // 06025C9E shll2 r2
    c.r[2] <<= 2;  // 06025CA0 shll2 r2
    c.r[2] += c.r[1];  // 06025CA2 add r1,r2
    c.r[2] += 11;  // 06025CA4 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025CA6 mov.b @r2,r0
    c.r[9] <<= 2;  // 06025CA8 shll2 r9
    c.r[9] += c.r[9];  // 06025CAA add r9,r9
    c.r[9] <<= 2;  // 06025CAC shll2 r9
    c.r[0] &= 0xDFu;  // 06025CAE and #223,r0
L_06025CB0:
    c.r[0] |= c.r[9];  // 06025CB0 or r9,r0
    st8(c.r[2], c.r[0]); goto L_06025E66;  // 06025CB2 bra 0x06025E66 ; mov.b r0,@r2
L_06025CB6:
    c.r[3] = ld32(0x06025CF4u);  // 06025CB6 mov.l 0x06025CF4,r3
    c.r[6] = c.r[10];  // 06025CB8 mov r10,r6
    c.r[6] <<= 2;  // 06025CBA shll2 r6
    c.r[6] <<= 2;  // 06025CBC shll2 r6
    c.r[1] = c.r[9];  // 06025CBE mov r9,r1
    c.r[2] = ld32(c.r[3]);  // 06025CC0 mov.l @r3,r2
    c.r[1] <<= 2;  // 06025CC2 shll2 r1
    c.r[1] <<= 2;  // 06025CC4 shll2 r1
    c.r[2] += c.r[6];  // 06025CC6 add r6,r2
    c.r[2] += 11;  // 06025CC8 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025CCA mov.b @r2,r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 06025CCC tst r9,r9
    c.r[0] &= 0xEFu;  // 06025CCE and #239,r0
    c.r[0] |= c.r[1];  // 06025CD0 or r1,r0
    { const bool k = !c.t; st8(c.r[2], c.r[0]); if (k) { goto L_06025CDA; } }  // 06025CD2 bf/s 0x06025CDA ; mov.b r0,@r2
    goto L_06025E66;  // 06025CD6 bra 0x06025E66 ; nop
L_06025CDA:
    c.r[1] = ld32(c.r[3]);  // 06025CDA mov.l @r3,r1
    c.r[1] += c.r[6]; goto L_06025E5E;  // 06025CDC bra 0x06025E5E ; add r6,r1
L_06025CF8:
    c.r[9] = ld32(0x06025E84u);  // 06025CF8 mov.l 0x06025E84,r9
    c.r[8] = c.r[10];  // 06025CFA mov r10,r8
    c.r[8] <<= 2;  // 06025CFC shll2 r8
    c.r[8] <<= 2;  // 06025CFE shll2 r8
    c.r[1] = ld32(c.r[9]);  // 06025D00 mov.l @r9,r1
    c.r[6] = c.r[10];  // 06025D02 mov r10,r6
    c.r[1] += c.r[8];  // 06025D04 add r8,r1
    c.r[1] += 2;  // 06025D06 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025D08 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06025D0A mov r14,r4
    c.r[1] = ld32(0x06025E88u);  // 06025D0C mov.l 0x06025E88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025D12u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025D12u) return; }  // 06025D0E jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 06025D12 mov r14,r1
    c.r[1] += 26;  // 06025D14 add #26,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06025D16 mov.w @r1,r3
    c.r[1] = 0x1Eu;  // 06025D18 mov #30,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06025D1A mulu.w r1,r3
    c.r[2] = c.macl;  // 06025D1C sts macl,r2
    c.r[1] = ld32(0x06025E8Cu);  // 06025D1E mov.l 0x06025E8C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06025D20 dmuls.l r1,r2
    c.r[3] = c.r[3] & 0xFFFFu;  // 06025D22 extu.w r3,r3
    c.r[7] = c.mach;  // 06025D24 sts mach,r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 06025D26 shar r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 06025D28 shar r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 06025D2A shar r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 06025D2C shar r7
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 06025D2E shar r7
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06025D30 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06025D32 subc r2,r2
    c.r[1] = c.r[14];  // 06025D34 mov r14,r1
    c.r[1] += 22;  // 06025D36 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06025D38 mov.w @r1,r1
    c.r[7] -= c.r[2];  // 06025D3A sub r2,r7
    c.r[2] = c.r[1] & 0xFFFFu;  // 06025D3C extu.w r1,r2
    c.r[1] = c.r[2];  // 06025D3E mov r2,r1
    c.r[1] += c.r[7];  // 06025D40 add r7,r1
    c.t = c.r[1] > c.r[3];  // 06025D42 cmp/hi r3,r1
    if (!c.t) { goto L_06025D4A; }  // 06025D44 bf 0x06025D4A
    c.r[7] = c.r[3];  // 06025D46 mov r3,r7
    c.r[7] -= c.r[2];  // 06025D48 sub r2,r7
L_06025D4A:
    c.r[1] = ld32(c.r[9]);  // 06025D4A mov.l @r9,r1
    c.r[8] += c.r[1];  // 06025D4C add r1,r8
    c.r[8] += 2;  // 06025D4E add #2,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06025D50 mov.b @r8,r2
    c.r[1] = ld32(0x06025E90u);  // 06025D52 mov.l 0x06025E90,r1
    c.r[3] = ld32(c.r[1]);  // 06025D54 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06025D56 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06025D58 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06025D5A mul.l r1,r2
    c.r[1] = c.macl;  // 06025D5C sts macl,r1
    c.r[1] += c.r[3];  // 06025D5E add r3,r1
    c.r[1] += 22;  // 06025D60 add #22,r1
    st16(c.r[1], c.r[7]); goto L_06025E66;  // 06025D62 bra 0x06025E66 ; mov.w r7,@r1
L_06025D66:
    c.r[8] = ld32(0x06025E84u);  // 06025D66 mov.l 0x06025E84,r8
    c.r[9] = c.r[10];  // 06025D68 mov r10,r9
    c.r[9] <<= 2;  // 06025D6A shll2 r9
    c.r[9] <<= 2;  // 06025D6C shll2 r9
    c.r[1] = ld32(c.r[8]);  // 06025D6E mov.l @r8,r1
    c.r[6] = c.r[10];  // 06025D70 mov r10,r6
    c.r[1] += c.r[9];  // 06025D72 add r9,r1
    c.r[1] += 2;  // 06025D74 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025D76 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06025D78 mov r14,r4
    c.r[1] = ld32(0x06025E88u);  // 06025D7A mov.l 0x06025E88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025D80u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025D80u) return; }  // 06025D7C jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[8]);  // 06025D80 mov.l @r8,r1
    c.r[9] += c.r[1];  // 06025D82 add r1,r9
    c.r[9] += 2;  // 06025D84 add #2,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06025D86 mov.b @r9,r2
    c.r[1] = ld32(0x06025E90u);  // 06025D88 mov.l 0x06025E90,r1
    c.r[3] = ld32(c.r[1]);  // 06025D8A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06025D8C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06025D8E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06025D90 mul.l r1,r2
    c.r[2] = c.macl;  // 06025D92 sts macl,r2
    c.r[2] += c.r[3];  // 06025D94 add r3,r2
    c.r[1] = c.r[14];  // 06025D96 mov r14,r1
    c.r[1] += 26;  // 06025D98 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06025D9A mov.w @r1,r1
    c.r[2] += 22;  // 06025D9C add #22,r2
    st16(c.r[2], c.r[1]); goto L_06025E66;  // 06025D9E bra 0x06025E66 ; mov.w r1,@r2
L_06025DA2:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06025DA2 tst r9,r9
    { const bool k = c.t; c.r[8] = c.r[10]; if (k) { goto L_06025E66; } }  // 06025DA4 bt/s 0x06025E66 ; mov r10,r8
    c.r[9] = ld32(0x06025E84u);  // 06025DA8 mov.l 0x06025E84,r9
    c.r[8] <<= 2;  // 06025DAA shll2 r8
    c.r[8] <<= 2;  // 06025DAC shll2 r8
    c.r[1] = ld32(c.r[9]);  // 06025DAE mov.l @r9,r1
    c.r[6] = c.r[10];  // 06025DB0 mov r10,r6
    c.r[1] += c.r[8];  // 06025DB2 add r8,r1
    c.r[1] += 2;  // 06025DB4 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025DB6 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06025DB8 mov r14,r4
    c.r[1] = ld32(0x06025E88u);  // 06025DBA mov.l 0x06025E88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025DC0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025DC0u) return; }  // 06025DBC jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06025E90u);  // 06025DC0 mov.l 0x06025E90,r1
    c.r[6] = ld32(c.r[9]);  // 06025DC2 mov.l @r9,r6
    c.r[3] = 0x1Eu;  // 06025DC4 mov #30,r3
    c.r[7] = ld32(c.r[1]);  // 06025DC6 mov.l @r1,r7
    c.r[6] += c.r[8];  // 06025DC8 add r8,r6
    c.r[6] += 2;  // 06025DCA add #2,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06025DCC mov.b @r6,r2
    c.r[1] = c.r[14];  // 06025DCE mov r14,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06025DD0 extu.b r2,r2
    c.macl = c.r[2] * c.r[3];  // 06025DD2 mul.l r3,r2
    c.r[1] += 26;  // 06025DD4 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06025DD6 mov.w @r1,r1
    c.r[2] = c.macl;  // 06025DD8 sts macl,r2
    c.r[2] += c.r[7];  // 06025DDA add r7,r2
    c.r[2] += 22;  // 06025DDC add #22,r2
    st16(c.r[2], c.r[1]);  // 06025DDE mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06025DE0 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06025DE2 extu.b r1,r1
    c.macl = c.r[1] * c.r[3];  // 06025DE4 mul.l r3,r1
    c.r[1] = c.macl;  // 06025DE6 sts macl,r1
    c.r[1] += c.r[7];  // 06025DE8 add r7,r1
    c.r[1] += 15;  // 06025DEA add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025DEC mov.b @r1,r1
    c.r[2] = ld32(0x06025E94u);  // 06025DEE mov.l 0x06025E94,r2
    c.r[2] = ld32(c.r[2]);  // 06025DF0 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06025DF2 extu.b r1,r1
    c.r[3] = c.r[1];  // 06025DF4 mov r1,r3
    c.r[3] += c.r[3];  // 06025DF6 add r3,r3
    c.r[3] += c.r[1];  // 06025DF8 add r1,r3
    c.r[3] <<= 2;  // 06025DFA shll2 r3
    c.r[3] += c.r[2];  // 06025DFC add r2,r3
    c.r[3] += 9;  // 06025DFE add #9,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06025E00 mov.b @r3,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06025E7Eu);  // 06025E02 mov.w 0x06025E7E,r7
    c.r[1] = c.r[2] & 0xFFu;  // 06025E04 extu.b r2,r1
    c.r[1] += 30;  // 06025E06 add #30,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 06025E08 cmp/gt r7,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06025E14; } }  // 06025E0A bt/s 0x06025E14 ; mov r2,r1
    c.r[1] += 30;  // 06025E0E add #30,r1
    st8(c.r[3], c.r[1]); goto L_06025E16;  // 06025E10 bra 0x06025E16 ; mov.b r1,@r3
L_06025E14:
    st8(c.r[3], c.r[7]);  // 06025E14 mov.b r7,@r3
L_06025E16:
    c.r[3] = ld32(0x06025E84u);  // 06025E16 mov.l 0x06025E84,r3
    c.r[2] = c.r[10];  // 06025E18 mov r10,r2
    c.r[1] = ld32(c.r[3]);  // 06025E1A mov.l @r3,r1
    c.r[2] <<= 2;  // 06025E1C shll2 r2
    c.r[2] <<= 2;  // 06025E1E shll2 r2
    c.r[1] += c.r[2];  // 06025E20 add r2,r1
    c.r[1] += 10;  // 06025E22 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025E24 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06025E26 or #128,r0
    st8(c.r[1], c.r[0]);  // 06025E28 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06025E2A mov.l @r3,r1
    c.r[1] += c.r[2];  // 06025E2C add r2,r1
    c.r[1] += 10;  // 06025E2E add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025E30 mov.b @r1,r0
    c.r[0] |= 0x20u;  // 06025E32 or #32,r0
    st8(c.r[1], c.r[0]);  // 06025E34 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06025E36 mov.l @r3,r1
    c.r[1] += c.r[2];  // 06025E38 add r2,r1
    c.r[1] += 10;  // 06025E3A add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025E3C mov.b @r1,r0
    c.r[0] |= 0x10u;  // 06025E3E or #16,r0
    st8(c.r[1], c.r[0]);  // 06025E40 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06025E42 mov.l @r3,r1
    c.r[1] += c.r[2];  // 06025E44 add r2,r1
    c.r[1] += 10;  // 06025E46 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025E48 mov.b @r1,r0
    c.r[0] |= 0x8u;  // 06025E4A or #8,r0
    st8(c.r[1], c.r[0]);  // 06025E4C mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06025E4E mov.l @r3,r1
    c.r[1] += c.r[2];  // 06025E50 add r2,r1
    c.r[1] += 11;  // 06025E52 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025E54 mov.b @r1,r0
    c.r[0] |= 0x10u;  // 06025E56 or #16,r0
    st8(c.r[1], c.r[0]);  // 06025E58 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06025E5A mov.l @r3,r1
    c.r[1] += c.r[2];  // 06025E5C add r2,r1
L_06025E5E:
    c.r[1] += 10;  // 06025E5E add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025E60 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06025E62 and #191,r0
    st8(c.r[1], c.r[0]);  // 06025E64 mov.b r0,@r1
L_06025E66:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06025E80u);  // 06025E66 mov.w 0x06025E80,r3
    c.r[14] += c.r[3];  // 06025E68 add r3,r14
    c.r[15] = c.r[14];  // 06025E6A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025E6C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06025E6E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06025E70 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06025E72 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06025E74 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06025E76 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025E82u);  // 06025E78 mov.w 0x06025E82,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025E7A rts ; mov.l @r15+,r8
}

void f_06025E98(SH2Context& c) {
    ran[490] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025E98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025E9A sts.l pr,@-r15
    c.r[1] = ld32(0x06025EECu);  // 06025E9C mov.l 0x06025EEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025EA2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025EA2u) return; }  // 06025E9E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06025EF0u);  // 06025EA2 mov.l 0x06025EF0,r1
    c.r[2] = ld32(c.r[1]);  // 06025EA4 mov.l @r1,r2
    c.r[0] = ld32(0x06025EF4u);  // 06025EA6 mov.l 0x06025EF4,r0
    c.r[1] = c.r[2];  // 06025EA8 mov r2,r1
    c.r[1] += 3;  // 06025EAA add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025EAC mov.b @r1,r5
    c.r[6] = 0x0u;  // 06025EAE mov #0,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06025EB0 extu.b r5,r5
    c.r[1] = c.r[2];  // 06025EB2 mov r2,r1
    c.r[1] += 4;  // 06025EB4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025EB6 mov.b @r1,r1
    c.r[5] <<= 8;  // 06025EB8 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 06025EBA extu.b r1,r1
    c.r[5] |= c.r[1];  // 06025EBC or r1,r5
    c.r[1] = c.r[2];  // 06025EBE mov r2,r1
    c.r[1] += 1;  // 06025EC0 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025EC2 mov.b @r1,r4
    c.r[2] += 2;  // 06025EC4 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06025EC6 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025EC8 mov.b @r2,r1
    c.r[4] <<= 8;  // 06025ECA shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06025ECC extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06025ED2u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025ED2u) return; }  // 06025ECE jsr @r0 ; or r1,r4
    c.r[1] = ld32(0x06025EF8u);  // 06025ED2 mov.l 0x06025EF8,r1
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06025ED4 cmp/eq #-1,r0
    { const bool k = c.t; st32(c.r[1] + 20, c.r[0]); if (k) { goto L_06025EE0; } }  // 06025ED6 bt/s 0x06025EE0 ; mov.l r0,@(20,r1)
    c.r[1] = ld32(0x06025EFCu);  // 06025EDA mov.l 0x06025EFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025EE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025EE0u) return; }  // 06025EDC jsr @r1 ; nop
L_06025EE0:
    c.r[15] = c.r[14];  // 06025EE0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025EE2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025EEAu);  // 06025EE4 mov.w 0x06025EEA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025EE6 rts ; mov.l @r15+,r14
}

void f_06025F00(SH2Context& c) {
    ran[491] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025F00 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025F02 sts.l pr,@-r15
    c.r[1] = ld32(0x06025F58u);  // 06025F04 mov.l 0x06025F58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025F0Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025F0Au) return; }  // 06025F06 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06025F5Cu);  // 06025F0A mov.l 0x06025F5C,r1
    c.r[2] = ld32(c.r[1]);  // 06025F0C mov.l @r1,r2
    c.r[0] = ld32(0x06025F60u);  // 06025F0E mov.l 0x06025F60,r0
    c.r[1] = c.r[2];  // 06025F10 mov r2,r1
    c.r[1] += 1;  // 06025F12 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025F14 mov.b @r1,r4
    c.r[2] += 2;  // 06025F16 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06025F18 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025F1A mov.b @r2,r1
    c.r[4] <<= 8;  // 06025F1C shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06025F1E extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06025F24u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025F24u) return; }  // 06025F20 jsr @r0 ; or r1,r4
    c.r[3] = c.r[0] & 0xFFu;  // 06025F24 extu.b r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06025F54u);  // 06025F26 mov.w 0x06025F54,r1
    c.t = c.r[3] == c.r[1];  // 06025F28 cmp/eq r1,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06025F4A; } }  // 06025F2A bt/s 0x06025F4A ; mov r3,r2
    c.r[1] = ld32(0x06025F64u);  // 06025F2E mov.l 0x06025F64,r1
    c.r[1] = ld32(c.r[1]);  // 06025F30 mov.l @r1,r1
    c.r[2] <<= 2;  // 06025F32 shll2 r2
    c.r[2] <<= 2;  // 06025F34 shll2 r2
    c.r[2] += c.r[1];  // 06025F36 add r1,r2
    c.r[2] += 3;  // 06025F38 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025F3A mov.b @r2,r0
    c.r[1] = ld32(0x06025F68u);  // 06025F3C mov.l 0x06025F68,r1
    c.r[0] &= 0x7Fu;  // 06025F3E and #127,r0
    st8(c.r[2], c.r[0]);  // 06025F40 mov.b r0,@r2
    st8(c.r[1], c.r[3]);  // 06025F42 mov.b r3,@r1
    c.r[1] = ld32(0x06025F6Cu);  // 06025F44 mov.l 0x06025F6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025F4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025F4Au) return; }  // 06025F46 jsr @r1 ; nop
L_06025F4A:
    c.r[15] = c.r[14];  // 06025F4A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025F4C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025F56u);  // 06025F4E mov.w 0x06025F56,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025F50 rts ; mov.l @r15+,r14
}

void f_06025F70(SH2Context& c) {
    ran[492] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06025F70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06025F72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06025F74 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06025F76 sts.l pr,@-r15
    c.r[1] = ld32(0x06025FF8u);  // 06025F78 mov.l 0x06025FF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025F7Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025F7Eu) return; }  // 06025F7A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06025FFCu);  // 06025F7E mov.l 0x06025FFC,r1
    c.r[2] = ld32(c.r[1]);  // 06025F80 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06025F82 mov r2,r1
    c.r[1] += 3;  // 06025F84 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025F86 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06025F88 extu.b r1,r8
    c.r[1] = c.r[2];  // 06025F8A mov r2,r1
    c.r[1] += 4;  // 06025F8C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025F8E mov.b @r1,r1
    c.r[0] = ld32(0x06026000u);  // 06025F90 mov.l 0x06026000,r0
    c.r[9] = c.r[1] & 0xFFu;  // 06025F92 extu.b r1,r9
    c.r[1] = c.r[2];  // 06025F94 mov r2,r1
    c.r[1] += 1;  // 06025F96 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025F98 mov.b @r1,r4
    c.r[2] += 2;  // 06025F9A add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06025F9C extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06025F9E mov.b @r2,r1
    c.r[4] <<= 8;  // 06025FA0 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06025FA2 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06025FA8u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025FA8u) return; }  // 06025FA4 jsr @r0 ; or r1,r4
    c.r[3] = c.r[0] & 0xFFu;  // 06025FA8 extu.b r0,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06025FF2u);  // 06025FAA mov.w 0x06025FF2,r6
    c.t = c.r[3] == c.r[6];  // 06025FAC cmp/eq r6,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06025FE4; } }  // 06025FAE bt/s 0x06025FE4 ; mov r3,r2
    c.r[7] = ld32(0x06026004u);  // 06025FB2 mov.l 0x06026004,r7
    c.r[1] = ld32(c.r[7]);  // 06025FB4 mov.l @r7,r1
    c.r[2] <<= 2;  // 06025FB6 shll2 r2
    c.r[2] <<= 2;  // 06025FB8 shll2 r2
    c.r[1] += c.r[2];  // 06025FBA add r2,r1
    c.r[1] += 3;  // 06025FBC add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06025FBE mov.b @r1,r0
    c.t = c.r[8] == c.r[6];  // 06025FC0 cmp/eq r6,r8
    c.r[0] |= 0x80u;  // 06025FC2 or #128,r0
    { const bool k = c.t; st8(c.r[1], c.r[0]); if (k) { goto L_06025FCE; } }  // 06025FC4 bt/s 0x06025FCE ; mov.b r0,@r1
    c.r[1] = ld32(c.r[7]);  // 06025FC8 mov.l @r7,r1
    c.r[0] = c.r[2];  // 06025FCA mov r2,r0
    st8(c.r[0] + c.r[1], c.r[8]);  // 06025FCC mov.b r8,@(r0,r1)
L_06025FCE:
    c.t = c.r[9] == c.r[6];  // 06025FCE cmp/eq r6,r9
    if (c.t) { goto L_06025FDA; }  // 06025FD0 bt 0x06025FDA
    c.r[1] = ld32(c.r[7]);  // 06025FD2 mov.l @r7,r1
    c.r[2] += c.r[1];  // 06025FD4 add r1,r2
    c.r[2] += 1;  // 06025FD6 add #1,r2
    st8(c.r[2], c.r[9]);  // 06025FD8 mov.b r9,@r2
L_06025FDA:
    c.r[1] = ld32(0x06026008u);  // 06025FDA mov.l 0x06026008,r1
    st8(c.r[1], c.r[3]);  // 06025FDC mov.b r3,@r1
    c.r[1] = ld32(0x0602600Cu);  // 06025FDE mov.l 0x0602600C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06025FE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06025FE4u) return; }  // 06025FE0 jsr @r1 ; nop
L_06025FE4:
    c.r[15] = c.r[14];  // 06025FE4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06025FE6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06025FE8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06025FEA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06025FF4u);  // 06025FEC mov.w 0x06025FF4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06025FEE rts ; mov.l @r15+,r8
}

void f_06026010(SH2Context& c) {
    ran[493] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026010 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026012 sts.l pr,@-r15
    c.r[1] = ld32(0x0602607Cu);  // 06026014 mov.l 0x0602607C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602601Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602601Au) return; }  // 06026016 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06026080u);  // 0602601A mov.l 0x06026080,r1
    c.r[2] = ld32(c.r[1]);  // 0602601C mov.l @r1,r2
    c.r[0] = ld32(0x06026084u);  // 0602601E mov.l 0x06026084,r0
    c.r[1] = c.r[2];  // 06026020 mov r2,r1
    c.r[1] += 1;  // 06026022 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026024 mov.b @r1,r4
    c.r[2] += 2;  // 06026026 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06026028 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602602A mov.b @r2,r1
    c.r[4] <<= 8;  // 0602602C shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602602E extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06026034u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026034u) return; }  // 06026030 jsr @r0 ; or r1,r4
    c.r[4] = c.r[0] & 0xFFu;  // 06026034 extu.b r0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026078u);  // 06026036 mov.w 0x06026078,r1
    c.t = c.r[4] == c.r[1];  // 06026038 cmp/eq r1,r4
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_0602606E; } }  // 0602603A bt/s 0x0602606E ; mov r4,r2
    c.r[1] = ld32(0x06026088u);  // 0602603E mov.l 0x06026088,r1
    c.r[1] = ld32(c.r[1]);  // 06026040 mov.l @r1,r1
    c.r[2] <<= 2;  // 06026042 shll2 r2
    c.r[2] <<= 2;  // 06026044 shll2 r2
    c.r[2] += c.r[1];  // 06026046 add r1,r2
    c.r[1] = c.r[2];  // 06026048 mov r2,r1
    c.r[1] += 4;  // 0602604A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602604C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602604E mov r1,r0
    c.r[0] >>= 2;  // 06026050 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026052 shlr r0
    c.r[0] >>= 2;  // 06026054 shlr2 r0
    c.r[0] &= 0x1u;  // 06026056 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026058 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06026062; } }  // 0602605A bt/s 0x06026062 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602605E mov.b @r2,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06026060 extu.b r1,r4
L_06026062:
    c.r[1] = ld32(0x0602608Cu);  // 06026062 mov.l 0x0602608C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026068u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026068u) return; }  // 06026064 jsr @r1 ; nop
    c.r[1] = ld32(0x06026090u);  // 06026068 mov.l 0x06026090,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602606Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602606Eu) return; }  // 0602606A jsr @r1 ; nop
L_0602606E:
    c.r[15] = c.r[14];  // 0602606E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026070 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602607Au);  // 06026072 mov.w 0x0602607A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026074 rts ; mov.l @r15+,r14
}

void f_06026094(SH2Context& c) {
    ran[494] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026094 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06026096 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026098 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602609A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602609C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602609E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060260A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060260A2 sts.l pr,@-r15
    c.r[15] -= 8;  // 060260A4 add #-8,r15
    c.r[1] = ld32(0x060261D4u);  // 060260A6 mov.l 0x060261D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060260ACu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060260ACu) return; }  // 060260A8 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060261D8u);  // 060260AC mov.l 0x060261D8,r1
    c.r[2] = ld32(c.r[1]);  // 060260AE mov.l @r1,r2
    c.r[0] = ld32(0x060261DCu);  // 060260B0 mov.l 0x060261DC,r0
    c.r[1] = c.r[2];  // 060260B2 mov r2,r1
    c.r[1] += 1;  // 060260B4 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060260B6 mov.b @r1,r4
    c.r[2] += 2;  // 060260B8 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060260BA extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060260BC mov.b @r2,r1
    c.r[4] <<= 8;  // 060260BE shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 060260C0 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060260C6u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060260C6u) return; }  // 060260C2 jsr @r0 ; or r1,r4
    c.r[4] = c.r[0] & 0xFFu;  // 060260C6 extu.b r0,r4
    c.r[0] = ld32(0x060261E0u);  // 060260C8 mov.l 0x060261E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060260CEu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060260CEu) return; }  // 060260CA jsr @r0 ; mov #0,r5
    c.r[4] = c.r[0] & 0xFFu;  // 060260CE extu.b r0,r4
    c.r[7] = (uint32_t)(int16_t)ld16(0x060261CEu);  // 060260D0 mov.w 0x060261CE,r7
    c.t = c.r[4] == c.r[7];  // 060260D2 cmp/eq r7,r4
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_060261B6; } }  // 060260D4 bt/s 0x060261B6 ; mov r4,r1
    c.r[6] = ld32(0x060261E4u);  // 060260D8 mov.l 0x060261E4,r6
    c.r[1] <<= 2;  // 060260DA shll2 r1
    c.r[1] <<= 2;  // 060260DC shll2 r1
    c.r[3] = c.r[1];  // 060260DE mov r1,r3
    c.r[2] = ld32(c.r[6]);  // 060260E0 mov.l @r6,r2
    c.r[0] = c.r[1];  // 060260E2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060260E4 mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 060260E6 add r2,r3
    c.r[2] = c.r[1] & 0xFFu;  // 060260E8 extu.b r1,r2
    c.t = c.r[2] == c.r[7];  // 060260EA cmp/eq r7,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060261B6; } }  // 060260EC bt/s 0x060261B6 ; mov r3,r1
    c.r[1] += 7;  // 060260F0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060260F2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060260F4 mov r1,r0
    c.r[0] >>= 2;  // 060260F6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060260F8 shlr r0
    c.r[0] &= 0x1u;  // 060260FA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060260FC tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060261B6; } }  // 060260FE bt/s 0x060261B6 ; mov r3,r1
    c.r[1] += 3;  // 06026102 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026104 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06026106 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026108 shlr r0
    c.r[0] &= 0x3u;  // 0602610A and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602610C tst r0,r0
    { const bool k = !c.t; c.r[13] = c.r[2]; if (k) { goto L_060261B6; } }  // 0602610E bf/s 0x060261B6 ; mov r2,r13
    c.r[1] = c.r[3];  // 06026112 mov r3,r1
    c.r[1] += 1;  // 06026114 add #1,r1
    c.r[3] += 2;  // 06026116 add #2,r3
    c.r[8] = 0x0u;  // 06026118 mov #0,r8
    c.r[9] = 0x0u;  // 0602611A mov #0,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602611C mov.b @r1,r1
    c.r[2] = c.r[6];  // 0602611E mov r6,r2
    c.r[12] = c.r[1] & 0xFFu;  // 06026120 extu.b r1,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06026122 mov.b @r3,r1
    c.r[6] = c.r[7];  // 06026124 mov r7,r6
    c.r[11] = c.r[1] & 0xFFu;  // 06026126 extu.b r1,r11
    c.r[3] = 0x0u;  // 06026128 mov #0,r3
L_0602612A:
    c.r[0] = ld32(c.r[2]);  // 0602612A mov.l @r2,r0
    c.r[7] = c.r[3];  // 0602612C mov r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602612E mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026130 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06026132 cmp/eq r6,r1
    { const bool k = c.t; c.r[7] += c.r[0]; if (k) { goto L_06026160; } }  // 06026134 bt/s 0x06026160 ; add r0,r7
    c.r[1] = c.r[7];  // 06026138 mov r7,r1
    c.r[1] += 4;  // 0602613A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602613C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602613E mov r1,r0
    c.r[0] >>= 2;  // 06026140 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026142 shlr r0
    c.r[0] >>= 2;  // 06026144 shlr2 r0
    c.r[0] &= 0x1u;  // 06026146 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026148 tst r0,r0
    { const bool k = c.t; c.r[7] += 6; if (k) { goto L_06026160; } }  // 0602614A bt/s 0x06026160 ; add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602614E mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026150 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06026152 cmp/eq r4,r1
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06026160; } }  // 06026154 bf/s 0x06026160 ; mov r9,r0
    c.r[1] = c.r[9];  // 06026158 mov r9,r1
    c.r[1] += 1;  // 0602615A add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0602615C extu.b r1,r9
    st8(c.r[0] + c.r[14], c.r[8]);  // 0602615E mov.b r8,@(r0,r14)
L_06026160:
    c.r[8] += 1;  // 06026160 add #1,r8
    c.r[1] = 0x49u;  // 06026162 mov #73,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06026164 cmp/gt r1,r8
    { const bool k = !c.t; c.r[3] += 16; if (k) { SH2_POLL(c); goto L_0602612A; } }  // 06026166 bf/s 0x0602612A ; add #16,r3
    c.r[10] = ld32(0x060261E8u);  // 0602616A mov.l 0x060261E8,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06026170u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026170u) return; }  // 0602616C jsr @r10 ; mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06026170 cmp/ge r9,r8
    { const bool k = c.t; c.r[6] = c.r[11] & 0xFFu; if (k) { goto L_06026188; } }  // 06026172 bt/s 0x06026188 ; extu.b r11,r6
    c.r[0] = c.r[14];  // 06026176 mov r14,r0
L_06026178:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06026178 mov.b @(r0,r8),r4
    { const uint32_t x = c.r[10]; c.pr = 0x0602617Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602617Eu) return; }  // 0602617A jsr @r10 ; extu.b r4,r4
    c.r[8] += 1;  // 0602617E add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06026180 cmp/ge r9,r8
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06026178; } }  // 06026182 bf/s 0x06026178 ; mov r14,r0
    c.r[6] = c.r[11] & 0xFFu;  // 06026186 extu.b r11,r6
L_06026188:
    c.r[0] = ld32(0x060261ECu);  // 06026188 mov.l 0x060261EC,r0
    c.r[7] = 0x2u;  // 0602618A mov #2,r7
    c.r[5] = c.r[12];  // 0602618C mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06026192u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026192u) return; }  // 0602618E jsr @r0 ; mov r13,r4
    c.r[4] = c.r[0] & 0xFFu;  // 06026192 extu.b r0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060261CEu);  // 06026194 mov.w 0x060261CE,r1
    c.t = c.r[4] == c.r[1];  // 06026196 cmp/eq r1,r4
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_060261B6; } }  // 06026198 bt/s 0x060261B6 ; mov r4,r2
    c.r[1] = ld32(0x060261F0u);  // 0602619C mov.l 0x060261F0,r1
    st8(c.r[1], c.r[4]);  // 0602619E mov.b r4,@r1
    c.r[1] = ld32(0x060261E4u);  // 060261A0 mov.l 0x060261E4,r1
    c.r[1] = ld32(c.r[1]);  // 060261A2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060261A4 shll2 r2
    c.r[2] <<= 2;  // 060261A6 shll2 r2
    c.r[2] += c.r[1];  // 060261A8 add r1,r2
    c.r[2] += 3;  // 060261AA add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060261AC mov.b @r2,r0
    c.r[1] = ld32(0x060261F4u);  // 060261AE mov.l 0x060261F4,r1
    c.r[0] |= 0x80u;  // 060261B0 or #128,r0
    { const uint32_t x = c.r[1]; c.pr = 0x060261B6u; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060261B6u) return; }  // 060261B2 jsr @r1 ; mov.b r0,@r2
L_060261B6:
    c.r[14] += 8;  // 060261B6 add #8,r14
    c.r[15] = c.r[14];  // 060261B8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060261BA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060261BC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060261BE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060261C0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060261C2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060261C4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060261C6 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060261D0u);  // 060261C8 mov.w 0x060261D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060261CA rts ; mov.l @r15+,r8
}

void f_060261F8(SH2Context& c) {
    ran[495] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060261F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060261FA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060261FC sts.l pr,@-r15
    c.r[1] = ld32(0x06026274u);  // 060261FE mov.l 0x06026274,r1
    c.r[2] = ld32(c.r[1]);  // 06026200 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06026202 mov r2,r1
    c.r[1] += 1;  // 06026204 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026206 mov.b @r1,r1
    c.r[2] += 2;  // 06026208 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602620A extu.b r1,r1
    c.r[8] = c.r[1];  // 0602620C mov r1,r8
    c.r[8] <<= 8;  // 0602620E shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026210 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026212 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06026214 or r1,r8
    c.r[1] = ld32(0x06026278u);  // 06026216 mov.l 0x06026278,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602621Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602621Cu) return; }  // 06026218 jsr @r1 ; mov r15,r14
    c.r[4] = (uint32_t)(int16_t)ld16(0x0602626Cu);  // 0602621C mov.w 0x0602626C,r4
    c.r[0] = ld32(0x0602627Cu);  // 0602621E mov.l 0x0602627C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06026224u; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026224u) return; }  // 06026220 jsr @r0 ; and r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06026224 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602626Eu);  // 06026226 mov.w 0x0602626E,r1
    c.t = c.r[0] == c.r[1];  // 06026228 cmp/eq r1,r0
    { const bool k = c.t; c.r[8] >>= 8; if (k) { goto L_06026260; } }  // 0602622A bt/s 0x06026260 ; shlr8 r8
    c.r[8] += c.r[8];  // 0602622E add r8,r8
    c.r[8] >>= 8;  // 06026230 shlr8 r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06026232 tst r8,r8
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_0602624A; } }  // 06026234 bt/s 0x0602624A ; mov r0,r2
    c.r[1] = ld32(0x06026280u);  // 06026238 mov.l 0x06026280,r1
    c.r[1] = ld32(c.r[1]);  // 0602623A mov.l @r1,r1
    c.r[2] <<= 2;  // 0602623C shll2 r2
    c.r[2] <<= 2;  // 0602623E shll2 r2
    c.r[2] += c.r[1];  // 06026240 add r1,r2
    c.r[2] += 7;  // 06026242 add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026244 mov.b @r2,r0
    c.r[0] |= 0x40u; goto L_0602625A;  // 06026246 bra 0x0602625A ; or #64,r0
L_0602624A:
    c.r[1] = ld32(0x06026280u);  // 0602624A mov.l 0x06026280,r1
    c.r[1] = ld32(c.r[1]);  // 0602624C mov.l @r1,r1
    c.r[2] <<= 2;  // 0602624E shll2 r2
    c.r[2] <<= 2;  // 06026250 shll2 r2
    c.r[2] += c.r[1];  // 06026252 add r1,r2
    c.r[2] += 7;  // 06026254 add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026256 mov.b @r2,r0
    c.r[0] &= 0xBFu;  // 06026258 and #191,r0
L_0602625A:
    c.r[1] = ld32(0x06026284u);  // 0602625A mov.l 0x06026284,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026260u; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026260u) return; }  // 0602625C jsr @r1 ; mov.b r0,@r2
L_06026260:
    c.r[15] = c.r[14];  // 06026260 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026262 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026264 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026270u);  // 06026266 mov.w 0x06026270,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026268 rts ; mov.l @r15+,r8
}

void f_06026288(SH2Context& c) {
    ran[496] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026288 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602628A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602628C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602628E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026290 sts.l pr,@-r15
    c.r[1] = ld32(0x06026310u);  // 06026292 mov.l 0x06026310,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026298u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026298u) return; }  // 06026294 jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x06026314u);  // 06026298 mov.l 0x06026314,r2
    c.r[1] = ld32(c.r[2]);  // 0602629A mov.l @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602630Au);  // 0602629C mov.w 0x0602630A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602629E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060262A0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060262A2 tst r1,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_060262FA; } }  // 060262A4 bt/s 0x060262FA ; mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060262A8 cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[2]; if (k) { goto L_060262F4; } }  // 060262AA bt/s 0x060262F4 ; mov r2,r9
    c.r[10] = ld32(0x06026318u);  // 060262AE mov.l 0x06026318,r10
    c.r[1] = c.r[8];  // 060262B0 mov r8,r1
L_060262B2:
    c.r[2] = ld32(c.r[9]);  // 060262B2 mov.l @r9,r2
    c.r[1] += c.r[1];  // 060262B4 add r1,r1
    c.r[2] += c.r[1];  // 060262B6 add r1,r2
    c.r[2] += 1;  // 060262B8 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060262BA mov.b @r2,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060262BC extu.b r1,r4
    c.r[1] = ld32(0x0602631Cu);  // 060262BE mov.l 0x0602631C,r1
    c.r[2] = c.r[4];  // 060262C0 mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 060262C2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060262C4 shll2 r2
    c.r[2] <<= 2;  // 060262C6 shll2 r2
    c.r[2] += c.r[1];  // 060262C8 add r1,r2
    c.r[2] += 4;  // 060262CA add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060262CC mov.b @r2,r1
    c.r[0] = c.r[1];  // 060262CE mov r1,r0
    c.r[0] >>= 2;  // 060262D0 shlr2 r0
    c.r[0] >>= 2;  // 060262D2 shlr2 r0
    c.r[0] >>= 2;  // 060262D4 shlr2 r0
    c.r[0] &= 0x1u;  // 060262D6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060262D8 tst r0,r0
    { const bool k = !c.t; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; if (k) { goto L_060262E4; } }  // 060262DA bf/s 0x060262E4 ; exts.w r4,r4
    c.r[6] = 0x0u;  // 060262DE mov #0,r6
    { const uint32_t x = c.r[10]; c.pr = 0x060262E4u; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060262E4u) return; }  // 060262E0 jsr @r10 ; mov #4,r5
L_060262E4:
    c.r[1] = ld32(c.r[9]);  // 060262E4 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602630Au);  // 060262E6 mov.w 0x0602630A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060262E8 mov.b @(r0,r1),r1
    c.r[8] += 1;  // 060262EA add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060262EC extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060262EE cmp/ge r1,r8
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_060262B2; } }  // 060262F0 bf/s 0x060262B2 ; mov r8,r1
L_060262F4:
    c.r[1] = ld32(0x06026320u);  // 060262F4 mov.l 0x06026320,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060262FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060262FAu) return; }  // 060262F6 jsr @r1 ; nop
L_060262FA:
    c.r[15] = c.r[14];  // 060262FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060262FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060262FE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06026300 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06026302 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602630Cu);  // 06026304 mov.w 0x0602630C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026306 rts ; mov.l @r15+,r8
}

void f_06026324(SH2Context& c) {
    ran[497] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026324 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026326 sts.l pr,@-r15
    c.r[15] -= 8;  // 06026328 add #-8,r15
    c.r[1] = ld32(0x060264B0u);  // 0602632A mov.l 0x060264B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026330u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026330u) return; }  // 0602632C jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060264B4u);  // 06026330 mov.l 0x060264B4,r1
    c.r[2] = ld32(c.r[1]);  // 06026332 mov.l @r1,r2
    c.r[0] = ld32(0x060264B8u);  // 06026334 mov.l 0x060264B8,r0
    c.r[1] = c.r[2];  // 06026336 mov r2,r1
    c.r[1] += 1;  // 06026338 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602633A mov.b @r1,r4
    c.r[2] += 2;  // 0602633C add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602633E extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026340 mov.b @r2,r1
    c.r[4] <<= 8;  // 06026342 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06026344 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602634Au; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602634Au) return; }  // 06026346 jsr @r0 ; or r1,r4
    c.r[3] = c.r[0] & 0xFFu;  // 0602634A extu.b r0,r3
    c.r[6] = 0xFFFFFFFFu;  // 0602634C mov #-1,r6
    c.r[1] = c.r[6] & 0xFFu;  // 0602634E extu.b r6,r1
    c.t = c.r[3] == c.r[1];  // 06026350 cmp/eq r1,r3
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0602635A; } }  // 06026352 bf/s 0x0602635A ; mov r3,r2
    goto L_060264A0;  // 06026356 bra 0x060264A0 ; nop
L_0602635A:
    c.r[1] = ld32(0x060264BCu);  // 0602635A mov.l 0x060264BC,r1
    c.r[7] = ld32(c.r[1]);  // 0602635C mov.l @r1,r7
    c.r[2] <<= 2;  // 0602635E shll2 r2
    c.r[2] <<= 2;  // 06026360 shll2 r2
    c.r[2] += c.r[7];  // 06026362 add r7,r2
    c.r[1] = c.r[2];  // 06026364 mov r2,r1
    c.r[1] += 4;  // 06026366 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026368 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602636A mov r1,r0
    c.r[0] >>= 2;  // 0602636C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602636E shlr r0
    c.r[0] >>= 2;  // 06026370 shlr2 r0
    c.r[0] &= 0x1u;  // 06026372 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026374 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0602637E; } }  // 06026376 bt/s 0x0602637E ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602637A mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602637C extu.b r1,r3
L_0602637E:
    c.r[2] = c.r[3];  // 0602637E mov r3,r2
    c.r[2] <<= 2;  // 06026380 shll2 r2
    c.r[2] <<= 2;  // 06026382 shll2 r2
    c.r[2] += c.r[7];  // 06026384 add r7,r2
    c.r[1] = c.r[2];  // 06026386 mov r2,r1
    c.r[1] += 4;  // 06026388 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602638A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602638C mov r1,r0
    c.r[0] >>= 2;  // 0602638E shlr2 r0
    c.r[0] >>= 2;  // 06026390 shlr2 r0
    c.r[0] >>= 2;  // 06026392 shlr2 r0
    c.r[0] &= 0x1u;  // 06026394 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026396 tst r0,r0
    { const bool k = c.t; c.r[2] += 5; if (k) { goto L_060263A0; } }  // 06026398 bt/s 0x060263A0 ; add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602639C mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602639E extu.b r1,r3
L_060263A0:
    c.r[2] = 0x0u;  // 060263A0 mov #0,r2
    c.r[7] = 0x3u;  // 060263A2 mov #3,r7
    c.r[1] = c.r[6];  // 060263A4 mov r6,r1
    c.r[6] = 0x0u;  // 060263A6 mov #0,r6
L_060263A8:
    c.r[0] = c.r[6];  // 060263A8 mov r6,r0
    st8(c.r[0] + c.r[14], c.r[1]);  // 060263AA mov.b r1,@(r0,r14)
    c.r[2] += 1;  // 060263AC add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060263AE cmp/gt r7,r2
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_060263A8; } }  // 060263B0 bf/s 0x060263A8 ; add #2,r6
    c.r[5] = ld32(0x060264BCu);  // 060263B4 mov.l 0x060264BC,r5
    c.r[4] = c.r[3];  // 060263B6 mov r3,r4
    c.r[4] <<= 2;  // 060263B8 shll2 r4
    c.r[4] <<= 2;  // 060263BA shll2 r4
    c.r[2] = ld32(c.r[5]);  // 060263BC mov.l @r5,r2
    c.r[3] = c.r[4];  // 060263BE mov r4,r3
    c.r[3] += c.r[2];  // 060263C0 add r2,r3
    c.r[3] += 1;  // 060263C2 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060263C4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060263C6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060263C8 tst r1,r1
    { const bool k = c.t; c.r[7] = c.r[4]; if (k) { goto L_060263DE; } }  // 060263CA bt/s 0x060263DE ; mov r4,r7
    c.r[0] = c.r[4];  // 060263CE mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060263D0 mov.b @(r0,r2),r1
    st8(c.r[14], c.r[1]);  // 060263D2 mov.b r1,@r14
    c.r[2] = c.r[14];  // 060263D4 mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060263D6 mov.b @r3,r1
    c.r[2] += 1;  // 060263D8 add #1,r2
    c.r[1] -= 1;  // 060263DA add #-1,r1
    st8(c.r[2], c.r[1]);  // 060263DC mov.b r1,@r2
L_060263DE:
    c.r[6] = ld32(0x060264C0u);  // 060263DE mov.l 0x060264C0,r6
    c.r[1] = c.r[6];  // 060263E0 mov r6,r1
    c.r[1] += 76;  // 060263E2 add #76,r1
    c.r[2] = ld32(c.r[5]);  // 060263E4 mov.l @r5,r2
    c.r[0] = c.r[4];  // 060263E6 mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060263E8 mov.b @r1,r1
    c.r[7] += c.r[2];  // 060263EA add r2,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060263EC mov.b @(r0,r2),r3
    c.r[1] = c.r[1] & 0xFFu;  // 060263EE extu.b r1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060263F0 extu.b r3,r2
    c.t = c.r[2] >= c.r[1];  // 060263F2 cmp/hs r1,r2
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_0602640A; } }  // 060263F4 bt/s 0x0602640A ; mov r14,r2
    c.r[2] += 2;  // 060263F8 add #2,r2
    c.r[1] = c.r[3];  // 060263FA mov r3,r1
    c.r[1] += 1;  // 060263FC add #1,r1
    st8(c.r[2], c.r[1]);  // 060263FE mov.b r1,@r2
    c.r[2] = c.r[14];  // 06026400 mov r14,r2
    c.r[7] += 1;  // 06026402 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06026404 mov.b @r7,r1
    c.r[2] += 3;  // 06026406 add #3,r2
    st8(c.r[2], c.r[1]);  // 06026408 mov.b r1,@r2
L_0602640A:
    c.r[7] = c.r[4];  // 0602640A mov r4,r7
    c.r[3] = ld32(c.r[5]);  // 0602640C mov.l @r5,r3
    c.r[6] += 77;  // 0602640E add #77,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06026410 mov.b @r6,r1
    c.r[7] += c.r[3];  // 06026412 add r3,r7
    c.r[7] += 1;  // 06026414 add #1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06026416 mov.b @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06026418 extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0602641A extu.b r2,r2
    c.t = c.r[2] >= c.r[1];  // 0602641C cmp/hs r1,r2
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_06026434; } }  // 0602641E bt/s 0x06026434 ; mov r14,r2
    c.r[0] = c.r[4];  // 06026422 mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06026424 mov.b @(r0,r3),r1
    c.r[2] += 4;  // 06026426 add #4,r2
    st8(c.r[2], c.r[1]);  // 06026428 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0602642A mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602642C mov.b @r7,r1
    c.r[2] += 5;  // 0602642E add #5,r2
    c.r[1] += 1;  // 06026430 add #1,r1
    st8(c.r[2], c.r[1]);  // 06026432 mov.b r1,@r2
L_06026434:
    c.r[3] = c.r[4];  // 06026434 mov r4,r3
    c.r[1] = ld32(c.r[5]);  // 06026436 mov.l @r5,r1
    c.r[0] = c.r[4];  // 06026438 mov r4,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602643A mov.b @(r0,r1),r7
    c.r[3] += c.r[1];  // 0602643C add r1,r3
    c.r[1] = c.r[7] & 0xFFu;  // 0602643E extu.b r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06026440 tst r1,r1
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0602645C; } }  // 06026442 bt/s 0x0602645C ; mov #0,r2
    c.r[2] = c.r[14];  // 06026446 mov r14,r2
    c.r[2] += 6;  // 06026448 add #6,r2
    c.r[1] = c.r[7];  // 0602644A mov r7,r1
    c.r[1] -= 1;  // 0602644C add #-1,r1
    st8(c.r[2], c.r[1]);  // 0602644E mov.b r1,@r2
    c.r[2] = c.r[14];  // 06026450 mov r14,r2
    c.r[3] += 1;  // 06026452 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06026454 mov.b @r3,r1
    c.r[2] += 7;  // 06026456 add #7,r2
    st8(c.r[2], c.r[1]);  // 06026458 mov.b r1,@r2
    c.r[2] = 0x0u;  // 0602645A mov #0,r2
L_0602645C:
    c.r[6] = (uint32_t)(int16_t)ld16(0x060264ACu);  // 0602645C mov.w 0x060264AC,r6
    c.r[3] = 0x0u;  // 0602645E mov #0,r3
L_06026460:
    c.r[0] = c.r[3];  // 06026460 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06026462 mov.b @(r0,r14),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06026464 extu.b r1,r7
    c.t = c.r[7] == c.r[6];  // 06026466 cmp/eq r6,r7
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06026496; } }  // 06026468 bt/s 0x06026496 ; mov r14,r1
    c.r[1] += 1;  // 0602646C add #1,r1
    c.r[0] = c.r[1];  // 0602646E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06026470 mov.b @(r0,r3),r1
    c.r[5] = c.r[1] & 0xFFu;  // 06026472 extu.b r1,r5
    c.r[1] = ld32(0x060264C4u);  // 06026474 mov.l 0x060264C4,r1
    c.r[1] = ld32(c.r[1]);  // 06026476 mov.l @r1,r1
    c.r[5] <<= 2;  // 06026478 shll2 r5
    c.r[5] <<= 2;  // 0602647A shll2 r5
    c.r[5] <<= 2;  // 0602647C shll2 r5
    c.r[5] += c.r[1];  // 0602647E add r1,r5
    c.r[0] = c.r[5];  // 06026480 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06026482 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026484 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06026486 cmp/eq r6,r1
    { const bool k = !c.t; c.r[2] += 1; if (k) { goto L_06026498; } }  // 06026488 bf/s 0x06026498 ; add #1,r2
    c.r[1] = ld32(0x060264C8u);  // 0602648C mov.l 0x060264C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026492u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026492u) return; }  // 0602648E jsr @r1 ; nop
    c.r[14] += 8; goto L_060264A2;  // 06026492 bra 0x060264A2 ; add #8,r14
L_06026496:
    c.r[2] += 1;  // 06026496 add #1,r2
L_06026498:
    c.r[1] = 0x3u;  // 06026498 mov #3,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602649A cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06026460; } }  // 0602649C bf/s 0x06026460 ; add #2,r3
L_060264A0:
    c.r[14] += 8;  // 060264A0 add #8,r14
L_060264A2:
    c.r[15] = c.r[14];  // 060264A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060264A4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060264AEu);  // 060264A6 mov.w 0x060264AE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060264A8 rts ; mov.l @r15+,r14
}

void f_060264CC(SH2Context& c) {
    ran[498] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060264CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060264CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060264D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060264D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060264D4 sts.l pr,@-r15
    c.r[1] = ld32(0x06026530u);  // 060264D6 mov.l 0x06026530,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060264DCu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060264DCu) return; }  // 060264D8 jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x06026534u);  // 060264DC mov.l 0x06026534,r2
    c.r[1] = ld32(c.r[2]);  // 060264DE mov.l @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602652Au);  // 060264E0 mov.w 0x0602652A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060264E2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060264E4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060264E6 tst r1,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0602651A; } }  // 060264E8 bt/s 0x0602651A ; mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060264EC cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[2]; if (k) { goto L_06026514; } }  // 060264EE bt/s 0x06026514 ; mov r2,r9
    c.r[10] = ld32(0x06026538u);  // 060264F2 mov.l 0x06026538,r10
    c.r[1] = c.r[8];  // 060264F4 mov r8,r1
L_060264F6:
    c.r[2] = ld32(c.r[9]);  // 060264F6 mov.l @r9,r2
    c.r[1] += c.r[1];  // 060264F8 add r1,r1
    c.r[2] += c.r[1];  // 060264FA add r1,r2
    c.r[2] += 1;  // 060264FC add #1,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060264FE mov.b @r2,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06026504u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026504u) return; }  // 06026500 jsr @r10 ; extu.b r4,r4
    c.r[1] = ld32(c.r[9]);  // 06026504 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602652Au);  // 06026506 mov.w 0x0602652A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06026508 mov.b @(r0,r1),r1
    c.r[8] += 1;  // 0602650A add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602650C extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0602650E cmp/ge r1,r8
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_060264F6; } }  // 06026510 bf/s 0x060264F6 ; mov r8,r1
L_06026514:
    c.r[1] = ld32(0x0602653Cu);  // 06026514 mov.l 0x0602653C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602651Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602651Au) return; }  // 06026516 jsr @r1 ; nop
L_0602651A:
    c.r[15] = c.r[14];  // 0602651A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602651C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602651E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06026520 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06026522 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602652Cu);  // 06026524 mov.w 0x0602652C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026526 rts ; mov.l @r15+,r8
}

void f_06026540(SH2Context& c) {
    ran[499] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026540 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06026542 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026544 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06026546 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026548 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602654A sts.l pr,@-r15
    c.r[1] = ld32(0x06026658u);  // 0602654C mov.l 0x06026658,r1
    c.r[2] = ld32(c.r[1]);  // 0602654E mov.l @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026550 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06026552 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026650u);  // 06026554 mov.w 0x06026650,r1
    c.t = c.r[3] == c.r[1];  // 06026556 cmp/eq r1,r3
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06026566; } }  // 06026558 bf/s 0x06026566 ; mov r15,r14
    c.r[2] += 1;  // 0602655C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602655E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026560 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06026562 cmp/eq r3,r1
    if (c.t) { goto L_0602663E; }  // 06026564 bt 0x0602663E
L_06026566:
    c.r[1] = ld32(0x06026658u);  // 06026566 mov.l 0x06026658,r1
    c.r[1] = ld32(c.r[1]);  // 06026568 mov.l @r1,r1
    c.r[1] += 1;  // 0602656A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602656C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602656E extu.b r1,r1
    c.r[1] >>= 2;  // 06026570 shlr2 r1
    c.r[1] >>= 2;  // 06026572 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06026574 shlr r1
    c.r[1] >>= 2;  // 06026576 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06026578 tst r1,r1
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06026584; } }  // 0602657A bt/s 0x06026584 ; mov #0,r9
    c.r[9] = 0x1u;  // 0602657E mov #1,r9
    c.r[8] = 0xAu; goto L_06026586;  // 06026580 bra 0x06026586 ; mov #10,r8
L_06026584:
    c.r[8] = 0x5u;  // 06026584 mov #5,r8
L_06026586:
    c.r[10] = ld32(0x06026658u);  // 06026586 mov.l 0x06026658,r10
    c.r[2] = ld32(c.r[10]);  // 06026588 mov.l @r10,r2
    c.r[11] = 0x3Fu;  // 0602658A mov #63,r11
    c.r[1] = c.r[2];  // 0602658C mov r2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602658E mov.b @r1+,r4
    c.r[0] = ld32(0x0602665Cu);  // 06026590 mov.l 0x0602665C,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026592 mov.b @r1,r6
    c.r[4] = c.r[4] & 0xFFu;  // 06026594 extu.b r4,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06026596 extu.b r6,r6
    c.r[1] = c.r[2];  // 06026598 mov r2,r1
    c.r[1] += 2;  // 0602659A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602659C mov.b @r1,r1
    c.r[6] <<= 8;  // 0602659E shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 060265A0 extu.b r1,r1
    c.r[6] |= c.r[1];  // 060265A2 or r1,r6
    c.r[1] = c.r[2];  // 060265A4 mov r2,r1
    c.r[1] += 3;  // 060265A6 add #3,r1
    c.r[2] += 4;  // 060265A8 add #4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060265AA mov.b @r1,r3
    c.r[7] = c.r[6];  // 060265AC mov r6,r7
    c.r[3] = c.r[3] & 0xFFu;  // 060265AE extu.b r3,r3
    c.r[3] <<= 8;  // 060265B0 shll8 r3
    c.r[7] >>= 8;  // 060265B2 shlr8 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060265B4 shlr r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060265B6 mov.b @r2,r1
    c.r[7] &= c.r[11];  // 060265B8 and r11,r7
    c.r[1] = c.r[1] & 0xFFu;  // 060265BA extu.b r1,r1
    c.r[3] |= c.r[1];  // 060265BC or r1,r3
    c.r[5] = c.r[3];  // 060265BE mov r3,r5
    c.r[5] >>= 8;  // 060265C0 shlr8 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060265C2 shlr r5
    c.r[2] = (uint32_t)(int16_t)ld16(0x06026652u);  // 060265C4 mov.w 0x06026652,r2
    c.r[1] = ld32(0x06026660u);  // 060265C6 mov.l 0x06026660,r1
    c.r[1] = ld32(c.r[1]);  // 060265C8 mov.l @r1,r1
    c.r[6] &= c.r[2];  // 060265CA and r2,r6
    c.r[1] += 8;  // 060265CC add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060265CE mov.b @r1,r1
    c.r[3] &= c.r[2];  // 060265D0 and r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060265D2 extu.b r1,r1
    c.r[1] >>= 2;  // 060265D4 shlr2 r1
    c.r[1] >>= 2;  // 060265D6 shlr2 r1
    c.r[1] >>= 2;  // 060265D8 shlr2 r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060265DA mov.l r1,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060265E0u; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060265E0u) return; }  // 060265DC jsr @r0 ; mov.l r3,@-r15
    c.r[0] = c.r[0] & 0xFFu;  // 060265E0 extu.b r0,r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 060265E2 tst r9,r9
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_06026620; } }  // 060265E4 bt/s 0x06026620 ; add #8,r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026650u);  // 060265E8 mov.w 0x06026650,r1
    c.t = c.r[0] == c.r[1];  // 060265EA cmp/eq r1,r0
    if (c.t) { goto L_06026620; }  // 060265EC bt 0x06026620
    c.r[2] = ld32(c.r[10]);  // 060265EE mov.l @r10,r2
    c.r[1] = c.r[2];  // 060265F0 mov r2,r1
    c.r[1] += 9;  // 060265F2 add #9,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060265F4 mov.b @r1,r6
    c.r[7] = 0x0u;  // 060265F6 mov #0,r7
    c.r[6] = c.r[6] & 0xFFu;  // 060265F8 extu.b r6,r6
    c.r[1] = c.r[2];  // 060265FA mov r2,r1
    c.r[1] += 7;  // 060265FC add #7,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060265FE mov.b @r1,r5
    c.r[2] += 8;  // 06026600 add #8,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06026602 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026604 mov.b @r2,r1
    c.r[5] <<= 8;  // 06026606 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 06026608 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602660A or r1,r5
    c.r[1] = ld32(0x06026664u);  // 0602660C mov.l 0x06026664,r1
    c.r[1] = ld32(c.r[1]);  // 0602660E mov.l @r1,r1
    c.r[0] <<= 2;  // 06026610 shll2 r0
    c.r[0] <<= 2;  // 06026612 shll2 r0
    c.r[0] += c.r[1];  // 06026614 add r1,r0
    c.r[0] += 2;  // 06026616 add #2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06026618 mov.b @r0,r4
    c.r[1] = ld32(0x06026668u);  // 0602661A mov.l 0x06026668,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026620u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026620u) return; }  // 0602661C jsr @r1 ; extu.b r4,r4
L_06026620:
    c.r[1] = ld32(0x06026658u);  // 06026620 mov.l 0x06026658,r1
    c.r[0] = ld32(c.r[1]);  // 06026622 mov.l @r1,r0
    c.r[3] = c.r[0];  // 06026624 mov r0,r3
    c.r[3] += c.r[8];  // 06026626 add r8,r3
    st32(c.r[1], c.r[3]);  // 06026628 mov.l r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0602662A mov.b @(r0,r8),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602662C extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026650u);  // 0602662E mov.w 0x06026650,r1
    c.t = c.r[2] == c.r[1];  // 06026630 cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_06026566; } }  // 06026632 bf/s 0x06026566 ; add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06026636 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026638 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602663A cmp/eq r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06026566; }  // 0602663C bf 0x06026566
L_0602663E:
    c.r[15] = c.r[14];  // 0602663E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026640 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026642 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06026644 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06026646 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06026648 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026654u);  // 0602664A mov.w 0x06026654,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602664C rts ; mov.l @r15+,r8
}

void f_0602666C(SH2Context& c) {
    ran[500] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602666C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602666E sts.l pr,@-r15
    c.r[1] = ld32(0x0602668Cu);  // 06026670 mov.l 0x0602668C,r1
    c.r[1] = ld32(c.r[1]);  // 06026672 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026674 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06026676 extu.b r1,r0
    c.r[0] <<= 2;  // 06026678 shll2 r0
    c.r[1] = ld32(0x06026690u);  // 0602667A mov.l 0x06026690,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602667C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06026682u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026682u) return; }  // 0602667E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06026682 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026684 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026686 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06026688 rts ; extu.w r0,r0
}

void f_06026694(SH2Context& c) {
    ran[501] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026694 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026696 sts.l pr,@-r15
    c.r[7] = ld32(0x060266F0u);  // 06026698 mov.l 0x060266F0,r7
    c.r[2] = ld32(c.r[7]);  // 0602669A mov.l @r7,r2
    c.r[3] = ld32(0x060266F4u);  // 0602669C mov.l 0x060266F4,r3
    c.r[1] = c.r[2];  // 0602669E mov r2,r1
    c.r[1] += 1;  // 060266A0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060266A2 mov.b @r1,r1
    c.r[2] += 2;  // 060266A4 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060266A6 extu.b r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 060266A8 mov.l r1,@(20,r3)
    st32(c.r[7], c.r[2]);  // 060266AA mov.l r2,@r7
    st32(c.r[3] + 4, c.r[2]);  // 060266AC mov.l r2,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060266AE mov.b @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060266ECu);  // 060266B0 mov.w 0x060266EC,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060266B2 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060266B4 cmp/eq r3,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060266DA; } }  // 060266B6 bt/s 0x060266DA ; mov r15,r14
    c.r[2] = c.r[7];  // 060266BA mov r7,r2
    c.r[7] = c.r[3];  // 060266BC mov r3,r7
L_060266BE:
    c.r[3] = ld32(c.r[2]);  // 060266BE mov.l @r2,r3
    c.r[1] = c.r[3];  // 060266C0 mov r3,r1
    c.r[1] += 1;  // 060266C2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060266C4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060266C6 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 060266C8 cmp/eq r7,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060266DA; } }  // 060266CA bt/s 0x060266DA ; mov r3,r1
    c.r[1] += 2;  // 060266CE add #2,r1
    st32(c.r[2], c.r[1]);  // 060266D0 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060266D2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060266D4 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 060266D6 cmp/eq r7,r1
    if (!c.t) { SH2_POLL(c); goto L_060266BE; }  // 060266D8 bf 0x060266BE
L_060266DA:
    c.r[0] = ld32(0x060266F8u);  // 060266DA mov.l 0x060266F8,r0
    c.r[5] = 0x2u;  // 060266DC mov #2,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060266E2u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060266E2u) return; }  // 060266DE jsr @r0 ; mov #6,r4
    c.r[15] = c.r[14];  // 060266E2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060266E4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060266EEu);  // 060266E6 mov.w 0x060266EE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060266E8 rts ; mov.l @r15+,r14
}

void f_060266FC(SH2Context& c) {
    ran[502] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060266FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060266FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026700 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06026702 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06026704 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06026706 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026708 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602670A sts.l pr,@-r15
    c.r[3] = ld32(0x060267F8u);  // 0602670C mov.l 0x060267F8,r3
    c.r[1] = ld32(c.r[3]);  // 0602670E mov.l @r3,r1
    c.r[1] += 1;  // 06026710 add #1,r1
    st32(c.r[3], c.r[1]);  // 06026712 mov.l r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026714 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060267ECu);  // 06026716 mov.w 0x060267EC,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06026718 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602671A cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060267D6; } }  // 0602671C bt/s 0x060267D6 ; mov r15,r14
    c.r[11] = c.r[2];  // 06026720 mov r2,r11
    c.r[12] = ld32(0x060267FCu);  // 06026722 mov.l 0x060267FC,r12
L_06026724:
    c.r[2] = ld32(c.r[3]);  // 06026724 mov.l @r3,r2
    c.r[1] = c.r[2];  // 06026726 mov r2,r1
    c.r[1] += 1;  // 06026728 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602672A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602672C extu.b r1,r3
    c.t = c.r[3] == c.r[11];  // 0602672E cmp/eq r11,r3
    if (c.t) { goto L_060267D6; }  // 06026730 bt 0x060267D6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026732 mov.b @r2,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060267EEu);  // 06026734 mov.w 0x060267EE,r10
    c.r[10] &= c.r[3];  // 06026736 and r3,r10
    c.r[0] = c.r[1] & 0xFFu;  // 06026738 extu.b r1,r0
    c.r[1] = c.r[2];  // 0602673A mov r2,r1
    c.r[1] += 2;  // 0602673C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602673E mov.b @r1,r1
    c.r[2] += 3;  // 06026740 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06026742 extu.b r1,r1
    c.r[4] = c.r[1];  // 06026744 mov r1,r4
    c.r[4] <<= 8;  // 06026746 shll8 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026748 mov.b @r2,r1
    c.r[7] = c.r[0];  // 0602674A mov r0,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0602674C extu.b r1,r1
    c.r[4] |= c.r[1];  // 0602674E or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060267EEu);  // 06026750 mov.w 0x060267EE,r1
    c.t = c.r[10] == c.r[1];  // 06026752 cmp/eq r1,r10
    { const bool k = !c.t; c.r[6] = c.r[4]; if (k) { goto L_06026770; } }  // 06026754 bf/s 0x06026770 ; mov r4,r6
    c.r[0] &= 0x3Fu;  // 06026758 and #63,r0
    c.r[0] <<= 2;  // 0602675A shll2 r0
    c.r[0] <<= 2;  // 0602675C shll2 r0
    c.r[0] <<= 2;  // 0602675E shll2 r0
    c.r[13] = 0x3Fu;  // 06026760 mov #63,r13
    c.r[3] &= c.r[13];  // 06026762 and r13,r3
    c.r[3] |= c.r[0];  // 06026764 or r0,r3
    c.r[0] = ld32(0x06026800u);  // 06026766 mov.l 0x06026800,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602676Cu; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602676Cu) return; }  // 06026768 jsr @r0 ; mov r3,r5
    goto L_060267C4;  // 0602676C bra 0x060267C4 ; nop
L_06026770:
    c.r[13] = 0x3Fu;  // 06026770 mov #63,r13
    c.r[3] &= c.r[13];  // 06026772 and r13,r3
    c.r[7] &= c.r[13];  // 06026774 and r13,r7
    c.r[0] = ld32(0x06026804u);  // 06026776 mov.l 0x06026804,r0
    c.r[5] = c.r[3];  // 06026778 mov r3,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602677Eu; c.r[4] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602677Eu) return; }  // 0602677A jsr @r0 ; mov r7,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602677E extu.b r0,r8
    c.r[9] = c.r[8];  // 06026780 mov r8,r9
    c.r[9] <<= 2;  // 06026782 shll2 r9
    c.r[9] <<= 2;  // 06026784 shll2 r9
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06026786 exts.w r8,r4
    c.r[1] = ld32(c.r[12]);  // 06026788 mov.l @r12,r1
    c.r[6] = 0x0u;  // 0602678A mov #0,r6
    c.r[1] += c.r[9];  // 0602678C add r9,r1
    c.r[1] += 3;  // 0602678E add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026790 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06026792 and #127,r0
    st8(c.r[1], c.r[0]);  // 06026794 mov.b r0,@r1
    c.r[1] = ld32(0x06026808u);  // 06026796 mov.l 0x06026808,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602679Cu; c.r[5] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602679Cu) return; }  // 06026798 jsr @r1 ; mov #14,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060267F0u);  // 0602679C mov.w 0x060267F0,r1
    c.t = c.r[10] == c.r[1];  // 0602679E cmp/eq r1,r10
    { const bool k = !c.t; c.t = c.r[8] == c.r[11]; if (k) { goto L_060267C4; } }  // 060267A0 bf/s 0x060267C4 ; cmp/eq r11,r8
    if (c.t) { goto L_060267C4; }  // 060267A4 bt 0x060267C4
    c.r[1] = ld32(c.r[12]);  // 060267A6 mov.l @r12,r1
    c.r[9] += c.r[1];  // 060267A8 add r1,r9
    c.r[9] += 7;  // 060267AA add #7,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060267AC mov.b @r9,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060267AE extu.b r1,r0
    c.r[0] >>= 2;  // 060267B0 shlr2 r0
    c.r[0] >>= 2;  // 060267B2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060267B4 shlr r0
    c.r[0] >>= 2;  // 060267B6 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 060267B8 cmp/eq #1,r0
    if (!c.t) { goto L_060267C4; }  // 060267BA bf 0x060267C4
    c.r[1] = ld32(0x0602680Cu);  // 060267BC mov.l 0x0602680C,r1
    c.r[1] = ld32(c.r[1]);  // 060267BE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060267F2u);  // 060267C0 mov.w 0x060267F2,r0
    st16(c.r[0] + c.r[1], c.r[8]);  // 060267C2 mov.w r8,@(r0,r1)
L_060267C4:
    c.r[1] = ld32(0x060267F8u);  // 060267C4 mov.l 0x060267F8,r1
    c.r[2] = ld32(c.r[1]);  // 060267C6 mov.l @r1,r2
    c.r[3] = c.r[1];  // 060267C8 mov r1,r3
    c.r[2] += 4;  // 060267CA add #4,r2
    st32(c.r[1], c.r[2]);  // 060267CC mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060267CE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060267D0 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 060267D2 cmp/eq r11,r1
    if (!c.t) { SH2_POLL(c); goto L_06026724; }  // 060267D4 bf 0x06026724
L_060267D6:
    c.r[15] = c.r[14];  // 060267D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060267D8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060267DA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060267DC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060267DE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060267E0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060267E2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060267E4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060267F4u);  // 060267E6 mov.w 0x060267F4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060267E8 rts ; mov.l @r15+,r8
}

void f_06026810(SH2Context& c) {
    ran[503] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026810 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06026812 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026814 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06026816 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06026818 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602681A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602681C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602681E sts.l pr,@-r15
    c.r[3] = ld32(0x0602699Cu);  // 06026820 mov.l 0x0602699C,r3
    c.r[2] = ld32(c.r[3]);  // 06026822 mov.l @r3,r2
    c.r[15] -= 20;  // 06026824 add #-20,r15
    c.r[2] += 1;  // 06026826 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026828 mov.b @r2,r1
    c.r[14] = c.r[15];  // 0602682A mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0602682C extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0602682E mov.l r1,@(4,r14)
    st32(c.r[3], c.r[2]);  // 06026830 mov.l r2,@r3
    c.r[2] += 1;  // 06026832 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026834 mov.b @r2,r1
    c.r[7] = 0xFFFFFFFFu;  // 06026836 mov #-1,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06026838 extu.b r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0602683A extu.b r7,r2
    c.t = c.r[1] == c.r[2];  // 0602683C cmp/eq r2,r1
    if (!c.t) { goto L_06026844; }  // 0602683E bf 0x06026844
    goto L_0602697E;  // 06026840 bra 0x0602697E ; nop
L_06026844:
    c.r[3] = ld32(c.r[3]);  // 06026844 mov.l @r3,r3
    c.r[1] = c.r[3];  // 06026846 mov r3,r1
    c.r[1] += 2;  // 06026848 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602684A mov.b @r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0602684C extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602684E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06026850 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0602685A; } }  // 06026852 bf/s 0x0602685A ; mov r3,r1
    goto L_0602697E;  // 06026856 bra 0x0602697E ; nop
L_0602685A:
    c.r[1] += 3;  // 0602685A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602685C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602685E extu.b r1,r1
    c.r[8] = c.r[1];  // 06026860 mov r1,r8
    c.r[8] <<= 8;  // 06026862 shll8 r8
    c.r[1] = c.r[3];  // 06026864 mov r3,r1
    c.r[1] += 4;  // 06026866 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026868 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602686A extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602686C or r1,r8
    c.r[1] = c.r[3];  // 0602686E mov r3,r1
    c.r[1] += 5;  // 06026870 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026872 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026874 extu.b r1,r1
    c.r[13] = c.r[1];  // 06026876 mov r1,r13
    c.r[13] <<= 8;  // 06026878 shll8 r13
    c.r[1] = c.r[3];  // 0602687A mov r3,r1
    c.r[1] += 6;  // 0602687C add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602687E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026880 extu.b r1,r1
    c.r[13] |= c.r[1];  // 06026882 or r1,r13
    c.r[1] = c.r[3];  // 06026884 mov r3,r1
    c.r[1] += 8;  // 06026886 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026888 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602688A extu.b r1,r1
    c.r[2] = c.r[1];  // 0602688C mov r1,r2
    c.r[2] <<= 8;  // 0602688E shll8 r2
    c.r[1] = c.r[3];  // 06026890 mov r3,r1
    c.r[1] += 9;  // 06026892 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026894 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026896 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06026898 or r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0602689A extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602689C tst r1,r1
    { const bool k = c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2]; if (k) { goto L_060268AC; } }  // 0602689E bt/s 0x060268AC ; exts.w r2,r2
    st32(c.r[14], c.r[2]);  // 060268A2 mov.l r2,@r14
    c.r[0] = c.r[2];  // 060268A4 mov r2,r0
    c.r[0] += 8;  // 060268A6 add #8,r0
    c.r[0] += c.r[3]; goto L_060268AE;  // 060268A8 bra 0x060268AE ; add r3,r0
L_060268AC:
    c.r[0] = 0x0u;  // 060268AC mov #0,r0
L_060268AE:
    st32(c.r[14], c.r[0]);  // 060268AE mov.l r0,@r14
    c.r[0] = ld32(0x0602699Cu);  // 060268B0 mov.l 0x0602699C,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x06026996u);  // 060268B2 mov.w 0x06026996,r7
    c.r[6] = c.r[7];  // 060268B4 mov r7,r6
    c.r[6] &= c.r[8];  // 060268B6 and r8,r6
    c.r[7] &= c.r[13];  // 060268B8 and r13,r7
    c.r[3] = ld32(c.r[0]);  // 060268BA mov.l @r0,r3
    c.r[11] = c.r[13];  // 060268BC mov r13,r11
    c.r[1] = c.r[3];  // 060268BE mov r3,r1
    c.r[1] += 10;  // 060268C0 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060268C2 mov.b @r1,r1
    c.r[11] >>= 8;  // 060268C4 shlr8 r11
    c.r[1] = c.r[1] & 0xFFu;  // 060268C6 extu.b r1,r1
    c.r[12] = c.r[1];  // 060268C8 mov r1,r12
    c.r[12] <<= 8;  // 060268CA shll8 r12
    c.r[1] = c.r[3];  // 060268CC mov r3,r1
    c.r[1] += 11;  // 060268CE add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060268D0 mov.b @r1,r1
    c.r[8] >>= 8;  // 060268D2 shlr8 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060268D4 shlr r8
    c.r[1] = c.r[1] & 0xFFu;  // 060268D6 extu.b r1,r1
    c.r[12] |= c.r[1];  // 060268D8 or r1,r12
    c.r[1] = c.r[3];  // 060268DA mov r3,r1
    c.r[1] += 12;  // 060268DC add #12,r1
    c.r[0] = c.r[12];  // 060268DE mov r12,r0
    c.r[0] >>= 8;  // 060268E0 shlr8 r0
    c.r[0] >>= 2;  // 060268E2 shlr2 r0
    c.r[0] >>= 2;  // 060268E4 shlr2 r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060268E6 mov.b @r1,r2
    c.r[10] = c.r[12];  // 060268E8 mov r12,r10
    c.r[2] = c.r[2] & 0xFFu;  // 060268EA extu.b r2,r2
    st32(c.r[14] + 8, c.r[0]);  // 060268EC mov.l r0,@(8,r14)
    c.r[0] = c.r[12];  // 060268EE mov r12,r0
    c.r[0] >>= 8;  // 060268F0 shlr8 r0
    c.r[0] &= 0xFu;  // 060268F2 and #15,r0
    st32(c.r[14] + 12, c.r[0]);  // 060268F4 mov.l r0,@(12,r14)
    c.r[10] >>= 2;  // 060268F6 shlr2 r10
    c.r[10] >>= 2;  // 060268F8 shlr2 r10
    c.r[0] = 0xFu;  // 060268FA mov #15,r0
    c.r[10] &= c.r[0];  // 060268FC and r0,r10
    c.r[12] &= c.r[0];  // 060268FE and r0,r12
    c.r[0] = c.r[2];  // 06026900 mov r2,r0
    c.r[0] &= 0xFu;  // 06026902 and #15,r0
    st32(c.r[14] + 16, c.r[0]);  // 06026904 mov.l r0,@(16,r14)
    c.r[2] >>= 2;  // 06026906 shlr2 r2
    c.r[2] >>= 2;  // 06026908 shlr2 r2
    c.r[0] = 0xEu;  // 0602690A mov #14,r0
    c.r[11] &= c.r[0];  // 0602690C and r0,r11
    c.r[13] >>= 8;  // 0602690E shlr8 r13
    c.r[13] >>= 2;  // 06026910 shlr2 r13
    c.r[13] >>= 2;  // 06026912 shlr2 r13
    c.r[1] = c.r[3];  // 06026914 mov r3,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06026916 mov.l @(4,r14),r0
    c.r[1] += 2;  // 06026918 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602691A mov.b @r1,r5
    c.r[11] |= c.r[0];  // 0602691C or r0,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026998u);  // 0602691E mov.w 0x06026998,r0
    c.r[1] = c.r[3];  // 06026920 mov r3,r1
    c.r[1] += 1;  // 06026922 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026924 mov.b @r1,r4
    c.r[11] &= c.r[0];  // 06026926 and r0,r11
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06026928 mov.l r13,@-r15
    c.r[0] = ld32(c.r[14] + 16);  // 0602692A mov.l @(16,r14),r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0602692C mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602692E mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026930 mov.l r10,@-r15
    c.r[0] = ld32(c.r[14] + 12);  // 06026932 mov.l @(12,r14),r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06026934 mov.l r0,@-r15
    c.r[0] = ld32(c.r[14] + 8);  // 06026936 mov.l @(8,r14),r0
    c.r[5] = c.r[5] & 0xFFu;  // 06026938 extu.b r5,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0602693A mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0602693C mov.l r2,@-r15
    c.r[0] = ld32(c.r[14]);  // 0602693E mov.l @r14,r0
    c.r[3] += 7;  // 06026940 add #7,r3
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06026942 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06026944 mov.l r11,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06026946 mov.b @r3,r1
    c.r[4] = c.r[4] & 0xFFu;  // 06026948 extu.b r4,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602694A extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602694C mov.l r1,@-r15
    c.r[1] = ld32(c.r[14] + 4);  // 0602694E mov.l @(4,r14),r1
    c.r[0] = 0x3u;  // 06026950 mov #3,r0
    c.r[1] &= c.r[0];  // 06026952 and r0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06026954 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06026956 mov.l r7,@-r15
    c.r[0] = ld32(0x060269A0u);  // 06026958 mov.l 0x060269A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602695Eu; c.r[7] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602695Eu) return; }  // 0602695A jsr @r0 ; mov r8,r7
    c.r[0] = ld32(0x0602699Cu);  // 0602695E mov.l 0x0602699C,r0
    c.r[3] = ld32(0x0602699Cu);  // 06026960 mov.l 0x0602699C,r3
    c.r[2] = ld32(c.r[0]);  // 06026962 mov.l @r0,r2
    c.r[7] = 0xFFFFFFFFu;  // 06026964 mov #-1,r7
    c.r[1] = c.r[2];  // 06026966 mov r2,r1
    c.r[1] += 12;  // 06026968 add #12,r1
    st32(c.r[0], c.r[1]);  // 0602696A mov.l r1,@r0
    c.r[2] += 13;  // 0602696C add #13,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602696E mov.b @r2,r2
    c.r[1] = c.r[7] & 0xFFu;  // 06026970 extu.b r7,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06026972 extu.b r2,r2
    c.t = c.r[2] == c.r[1];  // 06026974 cmp/eq r1,r2
    { const bool k = c.t; c.r[15] += 48; if (k) { goto L_0602697E; } }  // 06026976 bt/s 0x0602697E ; add #48,r15
    SH2_POLL(c); goto L_06026844;  // 0602697A bra 0x06026844 ; nop
L_0602697E:
    c.r[14] += 20;  // 0602697E add #20,r14
    c.r[15] = c.r[14];  // 06026980 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026982 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026984 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06026986 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06026988 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602698A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602698C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602698E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602699Au);  // 06026990 mov.w 0x0602699A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026992 rts ; mov.l @r15+,r8
}

void f_060269A4(SH2Context& c) {
    ran[504] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060269A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060269A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060269A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060269AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060269AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060269AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060269B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060269B2 sts.l pr,@-r15
    c.r[15] -= 4;  // 060269B4 add #-4,r15
    c.r[14] = c.r[15];  // 060269B6 mov r15,r14
    c.r[8] = ld32(0x06026AE0u);  // 060269B8 mov.l 0x06026AE0,r8
    c.r[2] = ld32(c.r[8]);  // 060269BA mov.l @r8,r2
    c.r[12] = c.r[14];  // 060269BC mov r14,r12
    c.r[1] = c.r[2];  // 060269BE mov r2,r1
    c.r[1] += 1;  // 060269C0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060269C2 mov.b @r1,r1
    c.r[2] += 2;  // 060269C4 add #2,r2
    st8(c.r[14], c.r[1]);  // 060269C6 mov.b r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060269C8 mov.b @r2,r1
    c.r[12] += 1;  // 060269CA add #1,r12
    st8(c.r[12], c.r[1]);  // 060269CC mov.b r1,@r12
    c.r[1] = ld32(0x06026AE4u);  // 060269CE mov.l 0x06026AE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060269D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060269D4u) return; }  // 060269D0 jsr @r1 ; nop
    c.r[2] = ld32(c.r[8]);  // 060269D4 mov.l @r8,r2
    c.r[0] = ld32(0x06026AE8u);  // 060269D6 mov.l 0x06026AE8,r0
    c.r[1] = c.r[2];  // 060269D8 mov r2,r1
    c.r[1] += 3;  // 060269DA add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060269DC mov.b @r1,r4
    c.r[2] += 4;  // 060269DE add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060269E0 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060269E2 mov.b @r2,r1
    c.r[4] <<= 8;  // 060269E4 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 060269E6 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060269ECu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060269ECu) return; }  // 060269E8 jsr @r0 ; or r1,r4
    c.r[1] = c.r[0];  // 060269EC mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 060269EE extu.b r1,r11
    c.r[0] = 0xFFFFFFFFu;  // 060269F0 mov #-1,r0
    c.r[1] = c.r[0] & 0xFFu;  // 060269F2 extu.b r0,r1
    c.t = c.r[11] == c.r[1];  // 060269F4 cmp/eq r1,r11
    { const bool k = c.t; c.r[10] = c.r[11]; if (k) { goto L_06026AC2; } }  // 060269F6 bt/s 0x06026AC2 ; mov r11,r10
    c.r[13] = ld32(0x06026AECu);  // 060269FA mov.l 0x06026AEC,r13
    c.r[5] = ld32(c.r[13]);  // 060269FC mov.l @r13,r5
    c.r[10] <<= 2;  // 060269FE shll2 r10
    c.r[10] <<= 2;  // 06026A00 shll2 r10
    c.r[5] += c.r[10];  // 06026A02 add r10,r5
    c.r[1] = c.r[5];  // 06026A04 mov r5,r1
    c.r[1] += 4;  // 06026A06 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026A08 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06026A0A mov r1,r0
    c.r[0] >>= 2;  // 06026A0C shlr2 r0
    c.r[0] >>= 2;  // 06026A0E shlr2 r0
    c.r[0] >>= 2;  // 06026A10 shlr2 r0
    c.r[0] &= 0x1u;  // 06026A12 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026A14 tst r0,r0
    { const bool k = c.t; c.r[5] += 2; if (k) { goto L_06026AC2; } }  // 06026A16 bt/s 0x06026AC2 ; add #2,r5
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06026A1A mov.b @r5,r5
    c.r[1] = ld32(0x06026AF0u);  // 06026A1C mov.l 0x06026AF0,r1
    c.r[2] = ld32(c.r[1]);  // 06026A1E mov.l @r1,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06026A20 extu.b r5,r5
    c.r[1] = 0x1Eu;  // 06026A22 mov #30,r1
    c.macl = c.r[5] * c.r[1];  // 06026A24 mul.l r1,r5
    c.r[9] = ld32(0x06026AF4u);  // 06026A26 mov.l 0x06026AF4,r9
    c.r[1] = c.macl;  // 06026A28 sts macl,r1
    c.r[1] += c.r[2];  // 06026A2A add r2,r1
    c.r[1] += 15;  // 06026A2C add #15,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026A2E mov.b @r1,r8
    c.r[6] = c.r[11];  // 06026A30 mov r11,r6
    c.r[4] = ld32(c.r[9]);  // 06026A32 mov.l @r9,r4
    c.r[1] = ld32(0x06026AF8u);  // 06026A34 mov.l 0x06026AF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026A3Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026A3Au) return; }  // 06026A36 jsr @r1 ; extu.b r8,r8
    c.r[1] = ld32(0x06026AFCu);  // 06026A3A mov.l 0x06026AFC,r1
    c.r[4] = ld32(c.r[1]);  // 06026A3C mov.l @r1,r4
    c.r[1] = ld32(0x06026B00u);  // 06026A3E mov.l 0x06026B00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026A44u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026A44u) return; }  // 06026A40 jsr @r1 ; mov r8,r5
    c.r[5] = c.r[12];  // 06026A44 mov r12,r5
    c.r[1] = ld32(c.r[9]);  // 06026A46 mov.l @r9,r1
    c.r[4] = c.r[14];  // 06026A48 mov r14,r4
    c.r[1] += 37;  // 06026A4A add #37,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026A4C mov.b @r1,r6
    c.r[0] = ld32(0x06026B04u);  // 06026A4E mov.l 0x06026B04,r0
    c.r[6] = c.r[6] & 0xFFu;  // 06026A50 extu.b r6,r6
    c.r[6] >>= 2;  // 06026A52 shlr2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x06026A58u; c.r[6] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026A58u) return; }  // 06026A54 jsr @r0 ; shlr2 r6
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06026A58 cmp/eq #-1,r0
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_06026AC2; } }  // 06026A5A bt/s 0x06026AC2 ; mov r0,r2
    c.r[0] = 0x3u;  // 06026A5E mov #3,r0
    c.r[2] &= c.r[0];  // 06026A60 and r0,r2
    c.r[1] = ld32(c.r[13]);  // 06026A62 mov.l @r13,r1
    c.r[2] <<= 2;  // 06026A64 shll2 r2
    c.r[2] += c.r[2];  // 06026A66 add r2,r2
    c.r[1] += c.r[10];  // 06026A68 add r10,r1
    c.r[1] += 3;  // 06026A6A add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026A6C mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026ADAu);  // 06026A6E mov.w 0x06026ADA,r0
    c.r[3] &= c.r[0];  // 06026A70 and r0,r3
    c.r[3] |= c.r[2];  // 06026A72 or r2,r3
    st8(c.r[1], c.r[3]);  // 06026A74 mov.b r3,@r1
    c.r[2] = ld32(c.r[13]);  // 06026A76 mov.l @r13,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06026A78 mov.b @r14,r1
    c.r[0] = c.r[10];  // 06026A7A mov r10,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06026A7C mov.b r1,@(r0,r2)
    c.r[2] = ld32(c.r[13]);  // 06026A7E mov.l @r13,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06026A80 mov.b @r12,r1
    c.r[2] += c.r[10];  // 06026A82 add r10,r2
    c.r[2] += 1;  // 06026A84 add #1,r2
    st8(c.r[2], c.r[1]);  // 06026A86 mov.b r1,@r2
    c.r[1] = ld32(c.r[13]);  // 06026A88 mov.l @r13,r1
    c.r[1] += c.r[10];  // 06026A8A add r10,r1
    c.r[1] += 4;  // 06026A8C add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026A8E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026ADCu);  // 06026A90 mov.w 0x06026ADC,r0
    c.r[2] &= c.r[0];  // 06026A92 and r0,r2
    st8(c.r[1], c.r[2]);  // 06026A94 mov.b r2,@r1
    c.r[1] = ld32(c.r[13]);  // 06026A96 mov.l @r13,r1
    c.r[10] += c.r[1];  // 06026A98 add r1,r10
    c.r[10] += 5;  // 06026A9A add #5,r10
    c.r[0] = 0xFFFFFFFFu;  // 06026A9C mov #-1,r0
    st8(c.r[10], c.r[0]);  // 06026A9E mov.b r0,@r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06026AA0 mov.b @r12,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06026AA2 mov.b @r14,r1
    c.r[3] = ld32(0x06026B08u);  // 06026AA4 mov.l 0x06026B08,r3
    c.r[3] = ld32(c.r[3]);  // 06026AA6 mov.l @r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06026AA8 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06026AAA extu.b r1,r1
    c.r[2] <<= 2;  // 06026AAC shll2 r2
    c.r[2] <<= 2;  // 06026AAE shll2 r2
    c.r[2] <<= 2;  // 06026AB0 shll2 r2
    c.r[2] += c.r[3];  // 06026AB2 add r3,r2
    c.r[0] = c.r[2];  // 06026AB4 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[11]);  // 06026AB6 mov.b r11,@(r0,r1)
    c.r[1] = ld32(0x06026B0Cu);  // 06026AB8 mov.l 0x06026B0C,r1
    st8(c.r[1], c.r[11]);  // 06026ABA mov.b r11,@r1
    c.r[1] = ld32(0x06026B10u);  // 06026ABC mov.l 0x06026B10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026AC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026AC2u) return; }  // 06026ABE jsr @r1 ; nop
L_06026AC2:
    c.r[14] += 4;  // 06026AC2 add #4,r14
    c.r[15] = c.r[14];  // 06026AC4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026AC6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026AC8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06026ACA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06026ACC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06026ACE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06026AD0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06026AD2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026ADEu);  // 06026AD4 mov.w 0x06026ADE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026AD6 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
