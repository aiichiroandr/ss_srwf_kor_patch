#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06034B60(SH2Context& c) {
    ran[771] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06034B60 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06034B62 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06034B64 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06034B66 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06034B68 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034B6A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034B6C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06034B6E mov r15,r14
    c.r[1] = ld32(0x06034D70u);  // 06034B70 mov.l 0x06034D70,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06034D46u);  // 06034B72 mov.w 0x06034D46,r7
    c.r[2] = ld32(0x06034D74u);  // 06034B74 mov.l 0x06034D74,r2
    c.r[0] = c.r[2];  // 06034B76 mov r2,r0
    c.r[6] = 0x0u;  // 06034B78 mov #0,r6
    c.r[3] = ld32(c.r[1]);  // 06034B7A mov.l @r1,r3
    c.r[5] = 0x2u;  // 06034B7C mov #2,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034D48u);  // 06034B7E mov.w 0x06034D48,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06034B80 mov.l @(r0,r1),r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06034D4Au);  // 06034B82 mov.w 0x06034D4A,r4
    c.r[0] = c.r[3];  // 06034B84 mov r3,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 06034B86 mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034D4Cu);  // 06034B88 mov.w 0x06034D4C,r1
    c.r[0] = c.r[2];  // 06034B8A mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06034B8C mov.l @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06034D4Eu);  // 06034B8E mov.w 0x06034D4E,r7
    c.r[0] = c.r[3];  // 06034B90 mov r3,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 06034B92 mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06034D50u);  // 06034B94 mov.w 0x06034D50,r7
L_06034B96:
    c.r[0] = c.r[2];  // 06034B96 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06034B98 mov.w @(r0,r4),r1
    c.r[2] += 2;  // 06034B9A add #2,r2
    c.r[6] += 1;  // 06034B9C add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[5];  // 06034B9E cmp/gt r5,r6
    c.r[0] = c.r[3];  // 06034BA0 mov r3,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 06034BA2 mov.w r1,@(r0,r7)
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06034B96; } }  // 06034BA4 bf/s 0x06034B96 ; add #2,r3
    c.r[7] = ld32(0x06034D70u);  // 06034BA8 mov.l 0x06034D70,r7
    c.r[3] = ld32(0x06034D74u);  // 06034BAA mov.l 0x06034D74,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D52u);  // 06034BAC mov.w 0x06034D52,r0
    c.r[6] = 0x0u;  // 06034BAE mov #0,r6
    c.r[8] = 0x3Fu;  // 06034BB0 mov #63,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x06034D54u);  // 06034BB2 mov.w 0x06034D54,r4
    c.r[2] = ld32(c.r[7]);  // 06034BB4 mov.l @r7,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06034D56u);  // 06034BB6 mov.w 0x06034D56,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06034BB8 mov.w @(r0,r3),r1
    c.r[2] += 14;  // 06034BBA add #14,r2
    st16(c.r[2], c.r[1]);  // 06034BBC mov.w r1,@r2
L_06034BBE:
    c.r[1] = c.r[6];  // 06034BBE mov r6,r1
    c.r[1] += c.r[3];  // 06034BC0 add r3,r1
    c.r[2] = ld32(c.r[7]);  // 06034BC2 mov.l @r7,r2
    c.r[0] = c.r[1];  // 06034BC4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06034BC6 mov.b @(r0,r5),r1
    c.r[2] += c.r[6];  // 06034BC8 add r6,r2
    c.r[0] = c.r[2];  // 06034BCA mov r2,r0
    c.r[6] += 1;  // 06034BCC add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[8];  // 06034BCE cmp/gt r8,r6
    { const bool k = !c.t; st8(c.r[0] + c.r[4], c.r[1]); if (k) { SH2_POLL(c); goto L_06034BBE; } }  // 06034BD0 bf/s 0x06034BBE ; mov.b r1,@(r0,r4)
    c.r[5] = ld32(0x06034D70u);  // 06034BD4 mov.l 0x06034D70,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x06034D58u);  // 06034BD6 mov.w 0x06034D58,r7
    c.r[1] = ld32(0x06034D78u);  // 06034BD8 mov.l 0x06034D78,r1
    c.r[4] = ld32(0x06034D74u);  // 06034BDA mov.l 0x06034D74,r4
    c.r[11] = 0x4u;  // 06034BDC mov #4,r11
    c.r[8] = c.r[5];  // 06034BDE mov r5,r8
    c.r[6] = ld32(c.r[5]);  // 06034BE0 mov.l @r5,r6
    c.r[9] = (uint32_t)(int16_t)ld16(0x06034D5Au);  // 06034BE2 mov.w 0x06034D5A,r9
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034BE4 mov.w @r1+,r3
    c.r[2] = c.r[6];  // 06034BE6 mov r6,r2
    c.r[2] += c.r[7];  // 06034BE8 add r7,r2
    c.r[0] = c.r[6];  // 06034BEA mov r6,r0
    st16(c.r[0] + c.r[7], c.r[3]);  // 06034BEC mov.w r3,@(r0,r7)
    c.r[2] += 2;  // 06034BEE add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034BF0 mov.w @r1+,r3
    c.r[6] += 8;  // 06034BF2 add #8,r6
    st16(c.r[2], c.r[3]);  // 06034BF4 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034BF6 mov.w @r1+,r3
    c.r[2] += 2;  // 06034BF8 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034BFA mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034BFC mov.w @r1+,r3
    c.r[2] += 2;  // 06034BFE add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C00 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C02 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C04 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C06 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C08 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C0A add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C0C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C0E mov.w @r1+,r3
    c.r[2] += 2;  // 06034C10 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C12 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C14 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C16 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C18 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C1A mov.w @r1+,r3
    c.r[2] += 2;  // 06034C1C add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C1E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C20 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C22 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C24 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C26 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C28 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C2A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C2C mov.w @r1+,r3
    c.r[2] += 2;  // 06034C2E add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C30 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C32 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C34 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C36 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C38 mov.w @r1+,r3
    c.r[2] += 2;  // 06034C3A add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C3C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034C3E mov.w @r1+,r3
    c.r[2] += 2;  // 06034C40 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034C42 mov.w r3,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034C44 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D5Cu);  // 06034C46 mov.w 0x06034D5C,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06034C48 mov.b @r6,r3
    c.r[2] &= c.r[0];  // 06034C4A and r0,r2
    c.r[0] = 0x3Fu;  // 06034C4C mov #63,r0
    c.r[3] &= c.r[0];  // 06034C4E and r0,r3
    c.r[3] |= c.r[2];  // 06034C50 or r2,r3
    st8(c.r[6], c.r[3]);  // 06034C52 mov.b r3,@r6
    c.r[0] = 0x30u;  // 06034C54 mov #48,r0
    c.r[2] = ld32(c.r[5]);  // 06034C56 mov.l @r5,r2
    c.r[6] = 0x0u;  // 06034C58 mov #0,r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034C5A mov.b @r1,r3
    c.r[2] += 8;  // 06034C5C add #8,r2
    c.r[3] &= c.r[0];  // 06034C5E and r0,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034C60 mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D5Eu);  // 06034C62 mov.w 0x06034D5E,r0
    c.r[7] &= c.r[0];  // 06034C64 and r0,r7
    c.r[7] |= c.r[3];  // 06034C66 or r3,r7
    st8(c.r[2], c.r[7]);  // 06034C68 mov.b r7,@r2
    c.r[3] = ld32(c.r[1]);  // 06034C6A mov.l @r1,r3
    c.r[0] = c.r[4];  // 06034C6C mov r4,r0
    c.r[7] = ld32(c.r[5]);  // 06034C6E mov.l @r5,r7
    c.r[1] = ld32(0x06034D7Cu);  // 06034C70 mov.l 0x06034D7C,r1
    c.r[3] &= c.r[1];  // 06034C72 and r1,r3
    c.r[2] = c.r[7];  // 06034C74 mov r7,r2
    c.r[2] += 10;  // 06034C76 add #10,r2
    c.r[1] = c.r[3];  // 06034C78 mov r3,r1
    c.r[1] >>= 8;  // 06034C7A shlr8 r1
    st16(c.r[2], c.r[1]);  // 06034C7C mov.w r1,@r2
    c.r[7] += 12;  // 06034C7E add #12,r7
    st8(c.r[7], c.r[3]);  // 06034C80 mov.b r3,@r7
    c.r[1] = ld32(c.r[5]);  // 06034C82 mov.l @r5,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034D60u);  // 06034C84 mov.w 0x06034D60,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06034C86 mov.b @(r0,r2),r2
    c.r[1] += 16;  // 06034C88 add #16,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D62u);  // 06034C8A mov.w 0x06034D62,r0
    c.r[2] &= c.r[0];  // 06034C8C and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034C8E mov.b @r1,r3
    c.r[0] = 0x1u;  // 06034C90 mov #1,r0
    c.r[3] &= c.r[0];  // 06034C92 and r0,r3
    c.r[3] |= c.r[2];  // 06034C94 or r2,r3
    st8(c.r[1], c.r[3]);  // 06034C96 mov.b r3,@r1
L_06034C98:
    c.r[7] = c.r[6];  // 06034C98 mov r6,r7
    c.r[7] <<= 2;  // 06034C9A shll2 r7
    c.r[10] = ld32(0x06034D74u);  // 06034C9C mov.l 0x06034D74,r10
    c.r[5] = c.r[7];  // 06034C9E mov r7,r5
    c.r[5] += c.r[10];  // 06034CA0 add r10,r5
    c.r[0] = c.r[5];  // 06034CA2 mov r5,r0
    c.r[2] = 0x1Fu;  // 06034CA4 mov #31,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06034CA6 mov.b @(r0,r9),r1
    c.r[6] += 1;  // 06034CA8 add #1,r6
    c.r[3] = ld32(c.r[8]);  // 06034CAA mov.l @r8,r3
    c.r[2] &= c.r[1];  // 06034CAC and r1,r2
    c.r[2] <<= 2;  // 06034CAE shll2 r2
    c.r[2] += c.r[2];  // 06034CB0 add r2,r2
    c.r[2] <<= 2;  // 06034CB2 shll2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034D64u);  // 06034CB4 mov.w 0x06034D64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034CB6 mov.b @(r0,r1),r1
    c.r[3] += c.r[7];  // 06034CB8 add r7,r3
    c.r[4] = c.r[1] & 0xFFu;  // 06034CBA extu.b r1,r4
    c.r[4] >>= 2;  // 06034CBC shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 06034CBE shlr r4
    c.r[4] |= c.r[2];  // 06034CC0 or r2,r4
    c.r[2] = c.r[4];  // 06034CC2 mov r4,r2
    c.r[2] >>= 2;  // 06034CC4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06034CC6 shlr r2
    c.r[2] >>= 2;  // 06034CC8 shlr2 r2
    c.r[1] = c.r[3];  // 06034CCA mov r3,r1
    c.r[1] += 22;  // 06034CCC add #22,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D66u);  // 06034CCE mov.w 0x06034D66,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034CD0 mov.b @r1,r12
    c.r[3] += 23;  // 06034CD2 add #23,r3
    c.r[12] &= c.r[0];  // 06034CD4 and r0,r12
    c.r[12] |= c.r[2];  // 06034CD6 or r2,r12
    st8(c.r[1], c.r[12]);  // 06034CD8 mov.b r12,@r1
    c.r[0] = 0x1Fu;  // 06034CDA mov #31,r0
    c.r[4] &= c.r[0];  // 06034CDC and r0,r4
    c.r[4] <<= 2;  // 06034CDE shll2 r4
    c.r[4] += c.r[4];  // 06034CE0 add r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06034CE2 mov.b @r3,r1
    c.r[0] = 0x7u;  // 06034CE4 mov #7,r0
    c.r[1] &= c.r[0];  // 06034CE6 and r0,r1
    c.r[1] |= c.r[4];  // 06034CE8 or r4,r1
    st8(c.r[3], c.r[1]);  // 06034CEA mov.b r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034D68u);  // 06034CEC mov.w 0x06034D68,r1
    c.r[2] = ld32(c.r[8]);  // 06034CEE mov.l @r8,r2
    c.r[0] = c.r[5];  // 06034CF0 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034CF2 mov.b @(r0,r1),r1
    c.r[2] += c.r[7];  // 06034CF4 add r7,r2
    c.r[2] += 20;  // 06034CF6 add #20,r2
    st8(c.r[2], c.r[1]);  // 06034CF8 mov.b r1,@r2
    c.r[2] = ld32(c.r[8]);  // 06034CFA mov.l @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034D6Au);  // 06034CFC mov.w 0x06034D6A,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034CFE mov.b @(r0,r1),r1
    c.r[2] += c.r[7];  // 06034D00 add r7,r2
    c.r[2] += 21;  // 06034D02 add #21,r2
    st8(c.r[2], c.r[1]);  // 06034D04 mov.b r1,@r2
    c.r[1] = ld32(c.r[8]);  // 06034D06 mov.l @r8,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[11];  // 06034D08 cmp/gt r11,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06034D0A mov.b @(r0,r9),r2
    c.r[1] += c.r[7];  // 06034D0C add r7,r1
    c.r[1] += 22;  // 06034D0E add #22,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D5Cu);  // 06034D10 mov.w 0x06034D5C,r0
    c.r[2] &= c.r[0];  // 06034D12 and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034D14 mov.b @r1,r3
    c.r[0] = 0x3Fu;  // 06034D16 mov #63,r0
    c.r[3] &= c.r[0];  // 06034D18 and r0,r3
    c.r[3] |= c.r[2];  // 06034D1A or r2,r3
    st8(c.r[1], c.r[3]);  // 06034D1C mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 06034D1E mov.l @r8,r1
    c.r[0] = c.r[5];  // 06034D20 mov r5,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06034D22 mov.b @(r0,r9),r2
    c.r[1] += c.r[7];  // 06034D24 add r7,r1
    c.r[1] += 22;  // 06034D26 add #22,r1
    c.r[0] = 0x20u;  // 06034D28 mov #32,r0
    c.r[2] &= c.r[0];  // 06034D2A and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034D2C mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034D6Cu);  // 06034D2E mov.w 0x06034D6C,r0
    c.r[3] &= c.r[0];  // 06034D30 and r0,r3
    c.r[3] |= c.r[2];  // 06034D32 or r2,r3
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_06034C98; } }  // 06034D34 bf/s 0x06034C98 ; mov.b r3,@r1
    c.r[4] = ld32(0x06034D80u);  // 06034D38 mov.l 0x06034D80,r4
    c.r[1] = ld32(0x06034D70u);  // 06034D3A mov.l 0x06034D70,r1
    c.r[5] = ld32(c.r[1]);  // 06034D3C mov.l @r1,r5
    c.r[6] = 0x14u;  // 06034D3E mov #20,r6
    c.r[1] = ld32(0x06034D84u);  // 06034D40 mov.l 0x06034D84,r1
    c.r[5] += 20; goto L_06034D88;  // 06034D42 bra 0x06034D88 ; add #20,r5
L_06034D88:
    { const uint32_t x = c.r[1]; c.pr = 0x06034D8Cu; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034D8Cu) return; }  // 06034D88 jsr @r1 ; mov #0,r9
    c.r[11] = 0x7u;  // 06034D8C mov #7,r11
    c.r[8] = ld32(0x06034F98u);  // 06034D8E mov.l 0x06034F98,r8
    c.r[4] = 0x0u;  // 06034D90 mov #0,r4
    c.r[5] = c.r[10];  // 06034D92 mov r10,r5
L_06034D94:
    c.r[6] = 0x0u;  // 06034D94 mov #0,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034F70u);  // 06034D96 mov.w 0x06034F70,r3
L_06034D98:
    c.r[0] = c.r[5];  // 06034D98 mov r5,r0
    c.r[2] = ld32(c.r[8]);  // 06034D9A mov.l @r8,r2
    c.r[0] += c.r[6];  // 06034D9C add r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06034D9E mov.b @(r0,r3),r1
    c.r[2] += c.r[4];  // 06034DA0 add r4,r2
    c.r[2] += c.r[6];  // 06034DA2 add r6,r2
    c.r[2] += 7;  // 06034DA4 add #7,r2
    c.r[6] += 1;  // 06034DA6 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[11];  // 06034DA8 cmp/gt r11,r6
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06034D98; } }  // 06034DAA bf/s 0x06034D98 ; mov.b r1,@r2
    c.r[2] = c.r[4];  // 06034DAE mov r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F72u);  // 06034DB0 mov.w 0x06034F72,r1
    c.r[0] = c.r[5];  // 06034DB2 mov r5,r0
    c.r[6] = 0x0u;  // 06034DB4 mov #0,r6
    c.r[3] = ld32(c.r[8]);  // 06034DB6 mov.l @r8,r3
    c.r[7] = 0x3u;  // 06034DB8 mov #3,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034DBA mov.w @(r0,r1),r1
    c.r[2] += c.r[3];  // 06034DBC add r3,r2
    c.r[0] = c.r[4];  // 06034DBE mov r4,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06034DC0 mov.w r1,@(r0,r3)
    c.r[2] += 15;  // 06034DC2 add #15,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F74u);  // 06034DC4 mov.w 0x06034F74,r1
    c.r[0] = c.r[5];  // 06034DC6 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034DC8 mov.b @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034F76u);  // 06034DCA mov.w 0x06034F76,r3
    st8(c.r[2], c.r[1]);  // 06034DCC mov.b r1,@r2
    c.r[2] = ld32(c.r[8]);  // 06034DCE mov.l @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F78u);  // 06034DD0 mov.w 0x06034F78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034DD2 mov.b @(r0,r1),r1
    c.r[2] += c.r[4];  // 06034DD4 add r4,r2
    c.r[2] += 16;  // 06034DD6 add #16,r2
    st8(c.r[2], c.r[1]);  // 06034DD8 mov.b r1,@r2
L_06034DDA:
    c.r[0] = c.r[5];  // 06034DDA mov r5,r0
    c.r[2] = ld32(c.r[8]);  // 06034DDC mov.l @r8,r2
    c.r[0] += c.r[6];  // 06034DDE add r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06034DE0 mov.b @(r0,r3),r1
    c.r[2] += c.r[4];  // 06034DE2 add r4,r2
    c.r[2] += c.r[6];  // 06034DE4 add r6,r2
    c.r[2] += 17;  // 06034DE6 add #17,r2
    c.r[6] += 1;  // 06034DE8 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 06034DEA cmp/gt r7,r6
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06034DDA; } }  // 06034DEC bf/s 0x06034DDA ; mov.b r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F7Au);  // 06034DF0 mov.w 0x06034F7A,r1
    c.r[0] = c.r[5];  // 06034DF2 mov r5,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034F7Cu);  // 06034DF4 mov.w 0x06034F7C,r3
    c.r[2] = ld32(c.r[8]);  // 06034DF6 mov.l @r8,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06034F7Eu);  // 06034DF8 mov.w 0x06034F7E,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034DFA mov.b @(r0,r1),r1
    c.r[2] += c.r[4];  // 06034DFC add r4,r2
    c.r[2] += 26;  // 06034DFE add #26,r2
    st8(c.r[2], c.r[1]);  // 06034E00 mov.b r1,@r2
    c.r[1] = ld32(c.r[8]);  // 06034E02 mov.l @r8,r1
    c.r[9] += 1;  // 06034E04 add #1,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06034E06 mov.b @(r0,r3),r2
    c.r[1] += c.r[4];  // 06034E08 add r4,r1
    c.r[1] += 2;  // 06034E0A add #2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F80u);  // 06034E0C mov.w 0x06034F80,r0
    c.r[2] &= c.r[0];  // 06034E0E and r0,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034E10 mov.b @r1,r7
    c.r[0] = 0x3Fu;  // 06034E12 mov #63,r0
    c.r[7] &= c.r[0];  // 06034E14 and r0,r7
    c.r[7] |= c.r[2];  // 06034E16 or r2,r7
    st8(c.r[1], c.r[7]);  // 06034E18 mov.b r7,@r1
    c.r[2] = ld32(c.r[8]);  // 06034E1A mov.l @r8,r2
    c.r[0] = c.r[5];  // 06034E1C mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06034E1E mov.b @(r0,r3),r1
    c.r[2] += c.r[4];  // 06034E20 add r4,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06034E22 shlr r1
    c.r[2] += 2;  // 06034E24 add #2,r2
    c.r[0] = 0x18u;  // 06034E26 mov #24,r0
    c.r[1] &= c.r[0];  // 06034E28 and r0,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034E2A mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F82u);  // 06034E2C mov.w 0x06034F82,r0
    c.r[7] &= c.r[0];  // 06034E2E and r0,r7
    c.r[7] |= c.r[1];  // 06034E30 or r1,r7
    st8(c.r[2], c.r[7]);  // 06034E32 mov.b r7,@r2
    c.r[1] = ld32(c.r[8]);  // 06034E34 mov.l @r8,r1
    c.r[0] = c.r[5];  // 06034E36 mov r5,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06034E38 mov.b @(r0,r3),r2
    c.r[1] += c.r[4];  // 06034E3A add r4,r1
    c.r[0] = 0xFu;  // 06034E3C mov #15,r0
    c.r[2] &= c.r[0];  // 06034E3E and r0,r2
    c.r[1] += 3;  // 06034E40 add #3,r1
    c.r[2] <<= 2;  // 06034E42 shll2 r2
    c.r[2] += c.r[2];  // 06034E44 add r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034E46 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F84u);  // 06034E48 mov.w 0x06034F84,r0
    c.r[3] &= c.r[0];  // 06034E4A and r0,r3
    c.r[3] |= c.r[2];  // 06034E4C or r2,r3
    st8(c.r[1], c.r[3]);  // 06034E4E mov.b r3,@r1
    c.r[2] = ld32(c.r[8]);  // 06034E50 mov.l @r8,r2
    c.r[0] = c.r[5];  // 06034E52 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06034E54 mov.b @(r0,r6),r1
    c.r[2] += c.r[4];  // 06034E56 add r4,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06034E58 extu.b r1,r7
    c.r[7] >>= 2;  // 06034E5A shlr2 r7
    c.r[7] >>= 2;  // 06034E5C shlr2 r7
    c.r[3] = c.r[7];  // 06034E5E mov r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06034E60 shlr r3
    c.r[1] = c.r[2];  // 06034E62 mov r2,r1
    c.r[1] += 3;  // 06034E64 add #3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F86u);  // 06034E66 mov.w 0x06034F86,r0
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034E68 mov.b @r1,r10
    c.r[2] += 4;  // 06034E6A add #4,r2
    c.r[10] &= c.r[0];  // 06034E6C and r0,r10
    c.r[10] |= c.r[3];  // 06034E6E or r3,r10
    st8(c.r[1], c.r[10]);  // 06034E70 mov.b r10,@r1
    c.r[0] = 0x1u;  // 06034E72 mov #1,r0
    c.r[7] &= c.r[0];  // 06034E74 and r0,r7
    c.r[7] <<= 2;  // 06034E76 shll2 r7
    c.r[7] <<= 2;  // 06034E78 shll2 r7
    c.r[7] += c.r[7];  // 06034E7A add r7,r7
    c.r[7] <<= 2;  // 06034E7C shll2 r7
    c.r[0] = 0x7Fu;  // 06034E7E mov #127,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034E80 mov.b @r2,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06034F88u);  // 06034E82 mov.w 0x06034F88,r10
    c.r[1] &= c.r[0];  // 06034E84 and r0,r1
    c.r[1] |= c.r[7];  // 06034E86 or r7,r1
    st8(c.r[2], c.r[1]);  // 06034E88 mov.b r1,@r2
    c.r[1] = ld32(c.r[8]);  // 06034E8A mov.l @r8,r1
    c.r[0] = c.r[5];  // 06034E8C mov r5,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06034E8E mov.b @(r0,r6),r2
    c.r[1] += c.r[4];  // 06034E90 add r4,r1
    c.r[0] = 0xFu;  // 06034E92 mov #15,r0
    c.r[2] &= c.r[0];  // 06034E94 and r0,r2
    c.r[1] += 4;  // 06034E96 add #4,r1
    c.r[2] <<= 2;  // 06034E98 shll2 r2
    c.r[2] += c.r[2];  // 06034E9A add r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034E9C mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F84u);  // 06034E9E mov.w 0x06034F84,r0
    c.r[3] &= c.r[0];  // 06034EA0 and r0,r3
    c.r[3] |= c.r[2];  // 06034EA2 or r2,r3
    st8(c.r[1], c.r[3]);  // 06034EA4 mov.b r3,@r1
    c.r[0] = c.r[5];  // 06034EA6 mov r5,r0
    c.r[7] = ld32(c.r[8]);  // 06034EA8 mov.l @r8,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F8Au);  // 06034EAA mov.w 0x06034F8A,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06034EAC mov.b @(r0,r10),r3
    c.r[7] += c.r[4];  // 06034EAE add r4,r7
    c.r[3] = c.r[3] & 0xFFu;  // 06034EB0 extu.b r3,r3
    c.r[6] = c.r[7];  // 06034EB2 mov r7,r6
    c.r[6] += 4;  // 06034EB4 add #4,r6
    c.r[3] >>= 2;  // 06034EB6 shlr2 r3
    c.r[3] >>= 2;  // 06034EB8 shlr2 r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06034EBA mov.w @r6,r2
    c.r[3] <<= 2;  // 06034EBC shll2 r3
    c.r[3] <<= 2;  // 06034EBE shll2 r3
    c.r[3] += c.r[3];  // 06034EC0 add r3,r3
    c.r[3] <<= 2;  // 06034EC2 shll2 r3
    c.r[2] &= c.r[1];  // 06034EC4 and r1,r2
    c.r[2] |= c.r[3];  // 06034EC6 or r3,r2
    st16(c.r[6], c.r[2]);  // 06034EC8 mov.w r2,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06034ECA mov.b @(r0,r10),r1
    c.r[7] += 5;  // 06034ECC add #5,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06034ECE mov.b @r7,r2
    c.r[0] = 0xFu;  // 06034ED0 mov #15,r0
    c.r[1] &= c.r[0];  // 06034ED2 and r0,r1
    c.r[1] <<= 2;  // 06034ED4 shll2 r1
    c.r[1] += c.r[1];  // 06034ED6 add r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F84u);  // 06034ED8 mov.w 0x06034F84,r0
    c.r[2] &= c.r[0];  // 06034EDA and r0,r2
    c.r[2] |= c.r[1];  // 06034EDC or r1,r2
    st8(c.r[7], c.r[2]);  // 06034EDE mov.b r2,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F8Cu);  // 06034EE0 mov.w 0x06034F8C,r1
    c.r[0] = c.r[5];  // 06034EE2 mov r5,r0
    c.r[2] = ld32(c.r[8]);  // 06034EE4 mov.l @r8,r2
    c.r[5] += 22;  // 06034EE6 add #22,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034EE8 mov.b @(r0,r1),r1
    c.r[2] += c.r[4];  // 06034EEA add r4,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06034EEC extu.b r1,r7
    c.r[7] >>= 2;  // 06034EEE shlr2 r7
    c.r[7] >>= 2;  // 06034EF0 shlr2 r7
    c.r[3] = c.r[7];  // 06034EF2 mov r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06034EF4 shlr r3
    c.r[1] = c.r[2];  // 06034EF6 mov r2,r1
    c.r[1] += 5;  // 06034EF8 add #5,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F86u);  // 06034EFA mov.w 0x06034F86,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034EFC mov.b @r1,r6
    c.r[2] += 6;  // 06034EFE add #6,r2
    c.r[6] &= c.r[0];  // 06034F00 and r0,r6
    c.r[6] |= c.r[3];  // 06034F02 or r3,r6
    st8(c.r[1], c.r[6]);  // 06034F04 mov.b r6,@r1
    c.r[0] = 0x1u;  // 06034F06 mov #1,r0
    c.r[7] &= c.r[0];  // 06034F08 and r0,r7
    c.r[7] <<= 2;  // 06034F0A shll2 r7
    c.r[7] <<= 2;  // 06034F0C shll2 r7
    c.r[7] += c.r[7];  // 06034F0E add r7,r7
    c.r[7] <<= 2;  // 06034F10 shll2 r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034F12 mov.b @r2,r1
    c.r[0] = 0x7Fu;  // 06034F14 mov #127,r0
    c.r[1] &= c.r[0];  // 06034F16 and r0,r1
    c.r[1] |= c.r[7];  // 06034F18 or r7,r1
    st8(c.r[2], c.r[1]);  // 06034F1A mov.b r1,@r2
    c.r[1] = ld32(c.r[8]);  // 06034F1C mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034F8Eu);  // 06034F1E mov.w 0x06034F8E,r0
    c.r[1] += c.r[4];  // 06034F20 add r4,r1
    c.r[1] += 2;  // 06034F22 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034F24 mov.b @r1,r2
    c.r[2] &= c.r[0];  // 06034F26 and r0,r2
    st8(c.r[1], c.r[2]);  // 06034F28 mov.b r2,@r1
    c.r[1] = 0x7Fu;  // 06034F2A mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06034F2C cmp/gt r1,r9
    { const bool k = c.t; c.r[4] += 30; if (k) { goto L_06034F36; } }  // 06034F2E bt/s 0x06034F36 ; add #30,r4
    SH2_POLL(c); goto L_06034D94;  // 06034F32 bra 0x06034D94 ; nop
L_06034F36:
    c.r[8] = 0x0u;  // 06034F36 mov #0,r8
    c.r[9] = c.r[1];  // 06034F38 mov r1,r9
    c.r[5] = ld32(0x06034F9Cu);  // 06034F3A mov.l 0x06034F9C,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06034F90u);  // 06034F3C mov.w 0x06034F90,r4
    c.r[6] = 0x0u;  // 06034F3E mov #0,r6
L_06034F40:
    c.r[3] = c.r[6];  // 06034F40 mov r6,r3
    c.r[7] = ld32(0x06034FA0u);  // 06034F42 mov.l 0x06034FA0,r7
    c.r[7] += c.r[6];  // 06034F44 add r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F92u);  // 06034F46 mov.w 0x06034F92,r1
    c.r[0] = c.r[7];  // 06034F48 mov r7,r0
    c.r[2] = ld32(c.r[5]);  // 06034F4A mov.l @r5,r2
    c.r[8] += 1;  // 06034F4C add #1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034F4E mov.w @(r0,r1),r1
    c.r[3] += c.r[2];  // 06034F50 add r2,r3
    c.r[0] = c.r[6];  // 06034F52 mov r6,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06034F54 mov.w r1,@(r0,r2)
    c.r[2] = c.r[3];  // 06034F56 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F94u);  // 06034F58 mov.w 0x06034F94,r1
    c.r[0] = c.r[7];  // 06034F5A mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034F5C mov.w @(r0,r1),r1
    c.r[2] += 4;  // 06034F5E add #4,r2
    st16(c.r[2], c.r[1]);  // 06034F60 mov.w r1,@r2
    c.r[2] = c.r[3];  // 06034F62 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034F96u);  // 06034F64 mov.w 0x06034F96,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034F66 mov.w @(r0,r1),r1
    c.r[2] += 6;  // 06034F68 add #6,r2
    st16(c.r[2], c.r[1]);  // 06034F6A mov.w r1,@r2
    c.r[2] = c.r[3]; goto L_06034FA4;  // 06034F6C bra 0x06034FA4 ; mov r3,r2
L_06034FA4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603502Au);  // 06034FA4 mov.w 0x0603502A,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034FA6 mov.w @(r0,r1),r1
    c.r[2] += 10;  // 06034FA8 add #10,r2
    st16(c.r[2], c.r[1]);  // 06034FAA mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603502Cu);  // 06034FAC mov.w 0x0603502C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034FAE mov.b @(r0,r1),r1
    c.r[3] += 2;  // 06034FB0 add #2,r3
    st8(c.r[3], c.r[1]);  // 06034FB2 mov.b r1,@r3
    c.r[2] = ld32(c.r[5]);  // 06034FB4 mov.l @r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603502Eu);  // 06034FB6 mov.w 0x0603502E,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034FB8 mov.b @(r0,r1),r1
    c.r[2] += c.r[6];  // 06034FBA add r6,r2
    c.r[2] += 8;  // 06034FBC add #8,r2
    st8(c.r[2], c.r[1]);  // 06034FBE mov.b r1,@r2
    c.r[2] = ld32(c.r[5]);  // 06034FC0 mov.l @r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035030u);  // 06034FC2 mov.w 0x06035030,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06034FC4 mov.b @(r0,r1),r1
    c.r[2] += c.r[6];  // 06034FC6 add r6,r2
    c.r[2] += 9;  // 06034FC8 add #9,r2
    st8(c.r[2], c.r[1]);  // 06034FCA mov.b r1,@r2
    c.r[1] = ld32(c.r[5]);  // 06034FCC mov.l @r5,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06034FCE cmp/gt r9,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06034FD0 mov.b @(r0,r4),r2
    c.r[1] += c.r[6];  // 06034FD2 add r6,r1
    c.r[1] += 3;  // 06034FD4 add #3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035032u);  // 06034FD6 mov.w 0x06035032,r0
    c.r[2] &= c.r[0];  // 06034FD8 and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034FDA mov.b @r1,r3
    c.r[0] = 0x3Fu;  // 06034FDC mov #63,r0
    c.r[3] &= c.r[0];  // 06034FDE and r0,r3
    c.r[3] |= c.r[2];  // 06034FE0 or r2,r3
    st8(c.r[1], c.r[3]);  // 06034FE2 mov.b r3,@r1
    c.r[1] = ld32(c.r[5]);  // 06034FE4 mov.l @r5,r1
    c.r[0] = c.r[7];  // 06034FE6 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06034FE8 mov.b @(r0,r4),r2
    c.r[1] += c.r[6];  // 06034FEA add r6,r1
    c.r[1] += 3;  // 06034FEC add #3,r1
    c.r[0] = 0x30u;  // 06034FEE mov #48,r0
    c.r[2] &= c.r[0];  // 06034FF0 and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034FF2 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035034u);  // 06034FF4 mov.w 0x06035034,r0
    c.r[3] &= c.r[0];  // 06034FF6 and r0,r3
    c.r[3] |= c.r[2];  // 06034FF8 or r2,r3
    st8(c.r[1], c.r[3]);  // 06034FFA mov.b r3,@r1
    c.r[1] = ld32(c.r[5]);  // 06034FFC mov.l @r5,r1
    c.r[0] = c.r[7];  // 06034FFE mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06035000 mov.b @(r0,r4),r2
    c.r[1] += c.r[6];  // 06035002 add r6,r1
    c.r[1] += 3;  // 06035004 add #3,r1
    c.r[0] = 0x8u;  // 06035006 mov #8,r0
    c.r[2] &= c.r[0];  // 06035008 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035036u);  // 0603500A mov.w 0x06035036,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603500C mov.b @r1,r3
    c.r[6] += 12;  // 0603500E add #12,r6
    c.r[3] &= c.r[0];  // 06035010 and r0,r3
    c.r[3] |= c.r[2];  // 06035012 or r2,r3
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_06034F40; } }  // 06035014 bf/s 0x06034F40 ; mov.b r3,@r1
    c.r[15] = c.r[14];  // 06035018 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603501A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603501C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603501E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06035020 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06035022 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06035024 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06035026 rts ; mov.l @r15+,r8
}

void f_06035038(SH2Context& c) {
    ran[772] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06035038 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603503A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603503C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603503E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06035040 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06035042 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06035044 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06035046 mov r15,r14
    c.r[9] = ld32(0x06035224u);  // 06035048 mov.l 0x06035224,r9
    c.r[5] = (uint32_t)(int16_t)ld16(0x06035202u);  // 0603504A mov.w 0x06035202,r5
    c.r[1] = ld32(0x06035228u);  // 0603504C mov.l 0x06035228,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06035052u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06035052u) return; }  // 0603504E jsr @r1 ; mov r9,r4
    c.r[8] = 0x0u;  // 06035052 mov #0,r8
    c.r[10] = 0x7u;  // 06035054 mov #7,r10
    c.r[4] = ld32(0x0603522Cu);  // 06035056 mov.l 0x0603522C,r4
    c.r[6] = 0x0u;  // 06035058 mov #0,r6
    c.r[5] = c.r[9];  // 0603505A mov r9,r5
L_0603505C:
    c.r[7] = 0x0u;  // 0603505C mov #0,r7
L_0603505E:
    c.r[1] = ld32(c.r[4]);  // 0603505E mov.l @r4,r1
    c.r[1] += c.r[6];  // 06035060 add r6,r1
    c.r[1] += c.r[7];  // 06035062 add r7,r1
    c.r[1] += 7;  // 06035064 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035066 mov.b @r1,r1
    c.r[0] = c.r[5];  // 06035068 mov r5,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0603506A mov.b r1,@(r0,r7)
    c.r[7] += 1;  // 0603506C add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[10];  // 0603506E cmp/gt r10,r7
    { const bool k = !c.t; c.r[3] = c.r[5]; if (k) { SH2_POLL(c); goto L_0603505E; } }  // 06035070 bf/s 0x0603505E ; mov r5,r3
    c.r[3] += 8;  // 06035074 add #8,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035204u);  // 06035076 mov.w 0x06035204,r0
    c.r[7] = 0xFu;  // 06035078 mov #15,r7
    c.r[11] = 0x7u;  // 0603507A mov #7,r11
    c.r[1] = ld32(c.r[4]);  // 0603507C mov.l @r4,r1
    c.r[8] += 1;  // 0603507E add #1,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06035080 mov.b @r3,r2
    c.r[1] += c.r[6];  // 06035082 add r6,r1
    c.r[1] += 3;  // 06035084 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035086 mov.b @r1,r1
    c.r[7] &= c.r[2];  // 06035088 and r2,r7
    c.r[1] += c.r[1];  // 0603508A add r1,r1
    c.r[1] &= c.r[0];  // 0603508C and r0,r1
    c.r[7] |= c.r[1];  // 0603508E or r1,r7
    st8(c.r[3], c.r[7]);  // 06035090 mov.b r7,@r3
    c.r[2] = ld32(c.r[4]);  // 06035092 mov.l @r4,r2
    c.r[7] &= c.r[0];  // 06035094 and r0,r7
    c.r[2] += c.r[6];  // 06035096 add r6,r2
    c.r[1] = c.r[2];  // 06035098 mov r2,r1
    c.r[1] += 3;  // 0603509A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603509C mov.b @r1,r1
    c.r[2] += 4;  // 0603509E add #4,r2
    c.r[11] &= c.r[1];  // 060350A0 and r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060350A2 mov.b @r2,r1
    c.r[11] += c.r[11];  // 060350A4 add r11,r11
    c.r[1] = c.r[1] & 0xFFu;  // 060350A6 extu.b r1,r1
    c.r[1] >>= 2;  // 060350A8 shlr2 r1
    c.r[1] >>= 2;  // 060350AA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060350AC shlr r1
    c.r[1] >>= 2;  // 060350AE shlr2 r1
    c.r[11] |= c.r[1];  // 060350B0 or r1,r11
    c.r[7] |= c.r[11];  // 060350B2 or r11,r7
    st8(c.r[3], c.r[7]);  // 060350B4 mov.b r7,@r3
    c.r[1] = ld32(c.r[4]);  // 060350B6 mov.l @r4,r1
    c.r[2] = c.r[5];  // 060350B8 mov r5,r2
    c.r[1] += c.r[6];  // 060350BA add r6,r1
    c.r[1] += 4;  // 060350BC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060350BE mov.b @r1,r1
    c.r[2] += 9;  // 060350C0 add #9,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060350C2 mov.b @r2,r3
    c.r[1] += c.r[1];  // 060350C4 add r1,r1
    c.r[1] &= c.r[0];  // 060350C6 and r0,r1
    c.r[0] = 0xFu;  // 060350C8 mov #15,r0
    c.r[3] &= c.r[0];  // 060350CA and r0,r3
    c.r[3] |= c.r[1];  // 060350CC or r1,r3
    st8(c.r[2], c.r[3]);  // 060350CE mov.b r3,@r2
    c.r[1] = ld32(c.r[4]);  // 060350D0 mov.l @r4,r1
    c.r[7] = 0xFu;  // 060350D2 mov #15,r7
    c.r[1] += c.r[6];  // 060350D4 add r6,r1
    c.r[1] += 4;  // 060350D6 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060350D8 mov.w @r1,r1
    c.r[11] = 0x7u;  // 060350DA mov #7,r11
    c.r[1] >>= 2;  // 060350DC shlr2 r1
    c.r[1] >>= 2;  // 060350DE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060350E0 shlr r1
    c.r[1] >>= 2;  // 060350E2 shlr2 r1
    c.r[1] &= c.r[0];  // 060350E4 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035204u);  // 060350E6 mov.w 0x06035204,r0
    c.r[3] &= c.r[0];  // 060350E8 and r0,r3
    c.r[3] |= c.r[1];  // 060350EA or r1,r3
    st8(c.r[2], c.r[3]);  // 060350EC mov.b r3,@r2
    c.r[3] = c.r[5];  // 060350EE mov r5,r3
    c.r[3] += 10;  // 060350F0 add #10,r3
    c.r[1] = ld32(c.r[4]);  // 060350F2 mov.l @r4,r1
    c.r[5] += 11;  // 060350F4 add #11,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060350F6 mov.b @r3,r2
    c.r[1] += c.r[6];  // 060350F8 add r6,r1
    c.r[1] += 5;  // 060350FA add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060350FC mov.b @r1,r1
    c.r[7] &= c.r[2];  // 060350FE and r2,r7
    c.r[1] += c.r[1];  // 06035100 add r1,r1
    c.r[1] &= c.r[0];  // 06035102 and r0,r1
    c.r[7] |= c.r[1];  // 06035104 or r1,r7
    st8(c.r[3], c.r[7]);  // 06035106 mov.b r7,@r3
    c.r[2] = ld32(c.r[4]);  // 06035108 mov.l @r4,r2
    c.r[7] &= c.r[0];  // 0603510A and r0,r7
    c.r[2] += c.r[6];  // 0603510C add r6,r2
    c.r[1] = c.r[2];  // 0603510E mov r2,r1
    c.r[1] += 5;  // 06035110 add #5,r1
    c.r[2] += 6;  // 06035112 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035114 mov.b @r1,r1
    c.r[6] += 30;  // 06035116 add #30,r6
    c.r[11] &= c.r[1];  // 06035118 and r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603511A mov.b @r2,r1
    c.r[11] += c.r[11];  // 0603511C add r11,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0603511E extu.b r1,r1
    c.r[1] >>= 2;  // 06035120 shlr2 r1
    c.r[1] >>= 2;  // 06035122 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06035124 shlr r1
    c.r[1] >>= 2;  // 06035126 shlr2 r1
    c.r[11] |= c.r[1];  // 06035128 or r1,r11
    c.r[7] |= c.r[11];  // 0603512A or r11,r7
    c.r[1] = 0x7Fu;  // 0603512C mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0603512E cmp/gt r1,r8
    { const bool k = !c.t; st8(c.r[3], c.r[7]); if (k) { SH2_POLL(c); goto L_0603505C; } }  // 06035130 bf/s 0x0603505C ; mov.b r7,@r3
    c.r[5] = 0x0u;  // 06035134 mov #0,r5
    c.r[11] = ld32(0x06035230u);  // 06035136 mov.l 0x06035230,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x06035206u);  // 06035138 mov.w 0x06035206,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06035208u);  // 0603513A mov.w 0x06035208,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603520Au);  // 0603513C mov.w 0x0603520A,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603520Cu);  // 0603513E mov.w 0x0603520C,r12
    c.r[3] = c.r[9];  // 06035140 mov r9,r3
    c.r[6] = 0x0u;  // 06035142 mov #0,r6
L_06035144:
    c.r[2] = ld32(c.r[11]);  // 06035144 mov.l @r11,r2
    c.r[2] += c.r[6];  // 06035146 add r6,r2
    c.r[7] = c.r[2];  // 06035148 mov r2,r7
    c.r[7] += 2;  // 0603514A add #2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603514C mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603514E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06035150 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06035170; } }  // 06035152 bt/s 0x06035170 ; mov r2,r1
    c.r[1] += 4;  // 06035156 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035158 mov.w @r1,r1
    c.r[0] = c.r[3];  // 0603515A mov r3,r0
    st16(c.r[0] + c.r[10], c.r[1]);  // 0603515C mov.w r1,@(r0,r10)
    c.r[1] = c.r[2];  // 0603515E mov r2,r1
    c.r[1] += 6;  // 06035160 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035162 mov.w @r1,r1
    c.r[2] += 10;  // 06035164 add #10,r2
    st16(c.r[0] + c.r[8], c.r[1]);  // 06035166 mov.w r1,@(r0,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06035168 mov.w @r2,r1
    st16(c.r[0] + c.r[4], c.r[1]);  // 0603516A mov.w r1,@(r0,r4)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603516C mov.b @r7,r1
    st8(c.r[0] + c.r[12], c.r[1]);  // 0603516E mov.b r1,@(r0,r12)
L_06035170:
    c.r[3] += 8;  // 06035170 add #8,r3
    c.r[5] += 1;  // 06035172 add #1,r5
    c.r[1] = 0x7Fu;  // 06035174 mov #127,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 06035176 cmp/gt r1,r5
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_06035144; } }  // 06035178 bf/s 0x06035144 ; add #12,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603520Eu);  // 0603517C mov.w 0x0603520E,r7
    c.r[3] = ld32(0x06035234u);  // 0603517E mov.l 0x06035234,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035210u);  // 06035180 mov.w 0x06035210,r1
    c.r[2] = ld32(c.r[3]);  // 06035182 mov.l @r3,r2
    c.r[5] = 0x3Fu;  // 06035184 mov #63,r5
    c.r[0] = c.r[2];  // 06035186 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035188 mov.l @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035212u);  // 0603518A mov.w 0x06035212,r6
    c.r[0] = c.r[9];  // 0603518C mov r9,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0603518E mov.l r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035214u);  // 06035190 mov.w 0x06035214,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035216u);  // 06035192 mov.w 0x06035216,r1
    c.r[0] = c.r[2];  // 06035194 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035196 mov.l @(r0,r1),r1
    c.r[2] += 14;  // 06035198 add #14,r2
    c.r[0] = c.r[9];  // 0603519A mov r9,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0603519C mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603519E mov.w @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035218u);  // 060351A0 mov.w 0x06035218,r7
    st16(c.r[0] + c.r[7], c.r[1]);  // 060351A2 mov.w r1,@(r0,r7)
    c.r[7] = 0x0u;  // 060351A4 mov #0,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603521Au);  // 060351A6 mov.w 0x0603521A,r2
L_060351A8:
    c.r[4] = c.r[9];  // 060351A8 mov r9,r4
    c.r[1] = ld32(c.r[3]);  // 060351AA mov.l @r3,r1
    c.r[4] += c.r[7];  // 060351AC add r7,r4
    c.r[1] += c.r[7];  // 060351AE add r7,r1
    c.r[0] = c.r[1];  // 060351B0 mov r1,r0
    c.r[7] += 1;  // 060351B2 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060351B4 mov.b @(r0,r2),r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[5];  // 060351B6 cmp/gt r5,r7
    c.r[0] = c.r[4];  // 060351B8 mov r4,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[6], c.r[1]); if (k) { SH2_POLL(c); goto L_060351A8; } }  // 060351BA bf/s 0x060351A8 ; mov.b r1,@(r0,r6)
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603521Cu);  // 060351BE mov.w 0x0603521C,r6
    c.r[2] = c.r[9];  // 060351C0 mov r9,r2
    c.r[2] += c.r[6];  // 060351C2 add r6,r2
    c.r[1] = ld32(0x06035234u);  // 060351C4 mov.l 0x06035234,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603521Eu);  // 060351C6 mov.w 0x0603521E,r3
    c.r[2] += 2;  // 060351C8 add #2,r2
    c.r[8] = 0x4u;  // 060351CA mov #4,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x06035220u);  // 060351CC mov.w 0x06035220,r4
    c.r[7] = ld32(c.r[1]);  // 060351CE mov.l @r1,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06035222u);  // 060351D0 mov.w 0x06035222,r5
    c.r[1] = c.r[7];  // 060351D2 mov r7,r1
    c.r[1] += c.r[3];  // 060351D4 add r3,r1
    c.r[0] = c.r[7];  // 060351D6 mov r7,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060351D8 mov.w @(r0,r3),r3
    c.r[1] += 2;  // 060351DA add #2,r1
    c.r[0] = c.r[9];  // 060351DC mov r9,r0
    st16(c.r[0] + c.r[6], c.r[3]);  // 060351DE mov.w r3,@(r0,r6)
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060351E0 mov.w @r1+,r3
    c.r[6] = c.r[9];  // 060351E2 mov r9,r6
    st16(c.r[2], c.r[3]);  // 060351E4 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060351E6 mov.w @r1+,r3
    c.r[2] += 2;  // 060351E8 add #2,r2
    st16(c.r[2], c.r[3]);  // 060351EA mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060351EC mov.w @r1+,r3
    c.r[2] += 2;  // 060351EE add #2,r2
    st16(c.r[2], c.r[3]);  // 060351F0 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060351F2 mov.w @r1+,r3
    c.r[2] += 2;  // 060351F4 add #2,r2
    st16(c.r[2], c.r[3]);  // 060351F6 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060351F8 mov.w @r1+,r3
    c.r[2] += 2;  // 060351FA add #2,r2
    st16(c.r[2], c.r[3]);  // 060351FC mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2; goto L_06035238;  // 060351FE bra 0x06035238 ; mov.w @r1+,r3
L_06035238:
    c.r[2] += 2;  // 06035238 add #2,r2
    st16(c.r[2], c.r[3]);  // 0603523A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603523C mov.w @r1+,r3
    c.r[2] += 2;  // 0603523E add #2,r2
    st16(c.r[2], c.r[3]);  // 06035240 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06035242 mov.w @r1+,r3
    c.r[2] += 2;  // 06035244 add #2,r2
    st16(c.r[2], c.r[3]);  // 06035246 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06035248 mov.w @r1+,r3
    c.r[2] += 2;  // 0603524A add #2,r2
    st16(c.r[2], c.r[3]);  // 0603524C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603524E mov.w @r1+,r3
    c.r[2] += 2;  // 06035250 add #2,r2
    st16(c.r[2], c.r[3]);  // 06035252 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06035254 mov.w @r1+,r3
    c.r[2] += 2;  // 06035256 add #2,r2
    st16(c.r[2], c.r[3]);  // 06035258 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603525A mov.w @r1+,r3
    c.r[2] += 2;  // 0603525C add #2,r2
    st16(c.r[2], c.r[3]);  // 0603525E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06035260 mov.w @r1+,r3
    c.r[2] += 2;  // 06035262 add #2,r2
    st16(c.r[2], c.r[3]);  // 06035264 mov.w r3,@r2
    c.r[2] += 2;  // 06035266 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035268 mov.w @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035312u);  // 0603526A mov.w 0x06035312,r3
    st16(c.r[2], c.r[1]);  // 0603526C mov.w r1,@r2
    c.r[1] = c.r[7];  // 0603526E mov r7,r1
    c.r[1] += 10;  // 06035270 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035272 mov.w @r1,r1
    c.r[7] += 12;  // 06035274 add #12,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06035276 mov.b @r7,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06035278 extu.w r1,r1
    c.r[1] <<= 8;  // 0603527A shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603527C extu.b r2,r2
    c.r[2] |= c.r[1];  // 0603527E or r1,r2
    c.r[2] <<= 8;  // 06035280 shll8 r2
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06035282 mov.l @(r0,r3),r1
    c.r[7] = 0x0u;  // 06035284 mov #0,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06035286 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06035288 or r1,r2
    st32(c.r[0] + c.r[3], c.r[2]);  // 0603528A mov.l r2,@(r0,r3)
L_0603528C:
    c.r[2] = c.r[7];  // 0603528C mov r7,r2
    c.r[2] <<= 2;  // 0603528E shll2 r2
    c.r[1] = ld32(0x06035318u);  // 06035290 mov.l 0x06035318,r1
    c.r[10] = 0x1Fu;  // 06035292 mov #31,r10
    c.r[0] = c.r[6];  // 06035294 mov r6,r0
    c.r[3] = ld32(c.r[1]);  // 06035296 mov.l @r1,r3
    c.r[7] += 1;  // 06035298 add #1,r7
    c.r[3] += c.r[2];  // 0603529A add r2,r3
    c.r[1] = c.r[3];  // 0603529C mov r3,r1
    c.r[1] += 22;  // 0603529E add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060352A0 mov.b @r1,r1
    c.r[3] += 23;  // 060352A2 add #23,r3
    c.r[10] &= c.r[1];  // 060352A4 and r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060352A6 mov.b @r3,r1
    c.r[10] <<= 2;  // 060352A8 shll2 r10
    c.r[10] += c.r[10];  // 060352AA add r10,r10
    c.r[10] <<= 2;  // 060352AC shll2 r10
    c.r[2] = c.r[1] & 0xFFu;  // 060352AE extu.b r1,r2
    c.r[2] >>= 2;  // 060352B0 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060352B2 shlr r2
    c.r[2] |= c.r[10];  // 060352B4 or r10,r2
    c.r[1] = c.r[2];  // 060352B6 mov r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060352B8 mov.b @(r0,r4),r3
    c.r[1] >>= 2;  // 060352BA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060352BC shlr r1
    c.r[1] >>= 2;  // 060352BE shlr2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035314u);  // 060352C0 mov.w 0x06035314,r0
    c.r[3] &= c.r[0];  // 060352C2 and r0,r3
    c.r[3] |= c.r[1];  // 060352C4 or r1,r3
    c.r[0] = c.r[6];  // 060352C6 mov r6,r0
    st8(c.r[0] + c.r[4], c.r[3]);  // 060352C8 mov.b r3,@(r0,r4)
    c.r[0] = 0x1Fu;  // 060352CA mov #31,r0
    c.r[2] &= c.r[0];  // 060352CC and r0,r2
    c.r[2] <<= 2;  // 060352CE shll2 r2
    c.r[2] += c.r[2];  // 060352D0 add r2,r2
    c.r[0] = c.r[6];  // 060352D2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060352D4 mov.b @(r0,r5),r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[8];  // 060352D6 cmp/gt r8,r7
    c.r[0] = 0x7u;  // 060352D8 mov #7,r0
    c.r[1] &= c.r[0];  // 060352DA and r0,r1
    c.r[1] |= c.r[2];  // 060352DC or r2,r1
    c.r[0] = c.r[6];  // 060352DE mov r6,r0
    st8(c.r[0] + c.r[5], c.r[1]);  // 060352E0 mov.b r1,@(r0,r5)
    { const bool k = !c.t; c.r[6] += 4; if (k) { SH2_POLL(c); goto L_0603528C; } }  // 060352E2 bf/s 0x0603528C ; add #4,r6
    c.r[7] = 0x0u;  // 060352E6 mov #0,r7
    c.r[6] = 0x7Fu;  // 060352E8 mov #127,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035316u);  // 060352EA mov.w 0x06035316,r2
    c.r[3] = ld32(0x0603531Cu);  // 060352EC mov.l 0x0603531C,r3
L_060352EE:
    c.r[5] = c.r[9];  // 060352EE mov r9,r5
    c.r[5] += c.r[7];  // 060352F0 add r7,r5
    c.r[0] = c.r[7];  // 060352F2 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060352F4 mov.b @(r0,r3),r1
    c.r[7] += 1;  // 060352F6 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[6];  // 060352F8 cmp/gt r6,r7
    c.r[0] = c.r[5];  // 060352FA mov r5,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_060352EE; } }  // 060352FC bf/s 0x060352EE ; mov.b r1,@(r0,r2)
    c.r[15] = c.r[14];  // 06035300 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06035302 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06035304 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06035306 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06035308 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603530A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603530C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603530E rts ; mov.l @r15+,r8
}

void f_06035320(SH2Context& c) {
    ran[773] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06035320 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06035322 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06035324 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06035326 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06035328 mov r15,r14
    c.r[10] = ld32(0x06035550u);  // 0603532A mov.l 0x06035550,r10
    c.r[9] = 0x0u;  // 0603532C mov #0,r9
    c.r[8] = ld32(0x06035554u);  // 0603532E mov.l 0x06035554,r8
    c.r[5] = 0x0u;  // 06035330 mov #0,r5
    c.r[4] = c.r[10];  // 06035332 mov r10,r4
L_06035334:
    c.r[0] = ld32(c.r[8]);  // 06035334 mov.l @r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 06035336 mov.w @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06035338 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603533A tst r1,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06035434; } }  // 0603533C bt/s 0x06035434 ; mov #0,r6
    c.r[3] = 0x7u;  // 06035340 mov #7,r3
L_06035342:
    c.r[2] = ld32(c.r[8]);  // 06035342 mov.l @r8,r2
    c.r[0] = c.r[4];  // 06035344 mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06035346 mov.b @(r0,r6),r1
    c.r[2] += c.r[5];  // 06035348 add r5,r2
    c.r[2] += c.r[6];  // 0603534A add r6,r2
    c.r[2] += 7;  // 0603534C add #7,r2
    c.r[6] += 1;  // 0603534E add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[3];  // 06035350 cmp/gt r3,r6
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06035342; } }  // 06035352 bf/s 0x06035342 ; mov.b r1,@r2
    c.r[3] = c.r[4];  // 06035356 mov r4,r3
    c.r[3] += 8;  // 06035358 add #8,r3
    c.r[2] = ld32(c.r[8]);  // 0603535A mov.l @r8,r2
    c.r[0] = 0x78u;  // 0603535C mov #120,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603535E mov.b @r3,r1
    c.r[2] += c.r[5];  // 06035360 add r5,r2
    c.r[2] += 3;  // 06035362 add #3,r2
    c.r[7] = c.r[1];  // 06035364 mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06035366 shlr r7
    c.r[7] &= c.r[0];  // 06035368 and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603536A mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035530u);  // 0603536C mov.w 0x06035530,r0
    c.r[1] &= c.r[0];  // 0603536E and r0,r1
    c.r[1] |= c.r[7];  // 06035370 or r7,r1
    st8(c.r[2], c.r[1]);  // 06035372 mov.b r1,@r2
    c.r[7] = 0xFu;  // 06035374 mov #15,r7
    c.r[2] = ld32(c.r[8]);  // 06035376 mov.l @r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035532u);  // 06035378 mov.w 0x06035532,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603537A mov.b @r3,r1
    c.r[2] += c.r[5];  // 0603537C add r5,r2
    c.r[7] &= c.r[1];  // 0603537E and r1,r7
    c.r[3] = c.r[7];  // 06035380 mov r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06035382 shlr r3
    c.r[1] = c.r[2];  // 06035384 mov r2,r1
    c.r[1] += 3;  // 06035386 add #3,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035388 mov.b @r1,r6
    c.r[2] += 4;  // 0603538A add #4,r2
    c.r[6] &= c.r[0];  // 0603538C and r0,r6
    c.r[6] |= c.r[3];  // 0603538E or r3,r6
    st8(c.r[1], c.r[6]);  // 06035390 mov.b r6,@r1
    c.r[0] = 0x1u;  // 06035392 mov #1,r0
    c.r[7] &= c.r[0];  // 06035394 and r0,r7
    c.r[7] <<= 2;  // 06035396 shll2 r7
    c.r[7] <<= 2;  // 06035398 shll2 r7
    c.r[7] += c.r[7];  // 0603539A add r7,r7
    c.r[7] <<= 2;  // 0603539C shll2 r7
    c.r[0] = 0x7Fu;  // 0603539E mov #127,r0
    c.r[3] = c.r[4];  // 060353A0 mov r4,r3
    c.r[3] += 9;  // 060353A2 add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060353A4 mov.b @r2,r1
    c.r[6] = 0xFu;  // 060353A6 mov #15,r6
    c.r[1] &= c.r[0];  // 060353A8 and r0,r1
    c.r[1] |= c.r[7];  // 060353AA or r7,r1
    st8(c.r[2], c.r[1]);  // 060353AC mov.b r1,@r2
    c.r[2] = ld32(c.r[8]);  // 060353AE mov.l @r8,r2
    c.r[0] = 0x78u;  // 060353B0 mov #120,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060353B2 mov.b @r3,r1
    c.r[2] += c.r[5];  // 060353B4 add r5,r2
    c.r[2] += 4;  // 060353B6 add #4,r2
    c.r[7] = c.r[1];  // 060353B8 mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060353BA shlr r7
    c.r[7] &= c.r[0];  // 060353BC and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060353BE mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035530u);  // 060353C0 mov.w 0x06035530,r0
    c.r[1] &= c.r[0];  // 060353C2 and r0,r1
    c.r[1] |= c.r[7];  // 060353C4 or r7,r1
    st8(c.r[2], c.r[1]);  // 060353C6 mov.b r1,@r2
    c.r[7] = ld32(c.r[8]);  // 060353C8 mov.l @r8,r7
    c.r[0] = 0x78u;  // 060353CA mov #120,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060353CC mov.b @r3,r1
    c.r[7] += c.r[5];  // 060353CE add r5,r7
    c.r[6] &= c.r[1];  // 060353D0 and r1,r6
    c.r[3] = c.r[7];  // 060353D2 mov r7,r3
    c.r[3] += 4;  // 060353D4 add #4,r3
    c.r[6] <<= 2;  // 060353D6 shll2 r6
    c.r[6] <<= 2;  // 060353D8 shll2 r6
    c.r[6] += c.r[6];  // 060353DA add r6,r6
    c.r[6] <<= 2;  // 060353DC shll2 r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060353DE mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035534u);  // 060353E0 mov.w 0x06035534,r1
    c.r[2] &= c.r[1];  // 060353E2 and r1,r2
    c.r[2] |= c.r[6];  // 060353E4 or r6,r2
    st16(c.r[3], c.r[2]);  // 060353E6 mov.w r2,@r3
    c.r[3] = c.r[4];  // 060353E8 mov r4,r3
    c.r[3] += 10;  // 060353EA add #10,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060353EC mov.b @r3,r1
    c.r[7] += 5;  // 060353EE add #5,r7
    c.r[2] = c.r[1];  // 060353F0 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060353F2 shlr r2
    c.r[2] &= c.r[0];  // 060353F4 and r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060353F6 mov.b @r7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035530u);  // 060353F8 mov.w 0x06035530,r0
    c.r[1] &= c.r[0];  // 060353FA and r0,r1
    c.r[1] |= c.r[2];  // 060353FC or r2,r1
    st8(c.r[7], c.r[1]);  // 060353FE mov.b r1,@r7
    c.r[7] = 0xFu;  // 06035400 mov #15,r7
    c.r[2] = ld32(c.r[8]);  // 06035402 mov.l @r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035532u);  // 06035404 mov.w 0x06035532,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06035406 mov.b @r3,r1
    c.r[2] += c.r[5];  // 06035408 add r5,r2
    c.r[7] &= c.r[1];  // 0603540A and r1,r7
    c.r[3] = c.r[7];  // 0603540C mov r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0603540E shlr r3
    c.r[1] = c.r[2];  // 06035410 mov r2,r1
    c.r[1] += 5;  // 06035412 add #5,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035414 mov.b @r1,r6
    c.r[2] += 6;  // 06035416 add #6,r2
    c.r[6] &= c.r[0];  // 06035418 and r0,r6
    c.r[6] |= c.r[3];  // 0603541A or r3,r6
    st8(c.r[1], c.r[6]);  // 0603541C mov.b r6,@r1
    c.r[0] = 0x1u;  // 0603541E mov #1,r0
    c.r[7] &= c.r[0];  // 06035420 and r0,r7
    c.r[7] <<= 2;  // 06035422 shll2 r7
    c.r[7] <<= 2;  // 06035424 shll2 r7
    c.r[7] += c.r[7];  // 06035426 add r7,r7
    c.r[7] <<= 2;  // 06035428 shll2 r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603542A mov.b @r2,r1
    c.r[0] = 0x7Fu;  // 0603542C mov #127,r0
    c.r[1] &= c.r[0];  // 0603542E and r0,r1
    c.r[1] |= c.r[7];  // 06035430 or r7,r1
    st8(c.r[2], c.r[1]);  // 06035432 mov.b r1,@r2
L_06035434:
    c.r[5] += 30;  // 06035434 add #30,r5
    c.r[9] += 1;  // 06035436 add #1,r9
    c.r[1] = 0x7Fu;  // 06035438 mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0603543A cmp/gt r1,r9
    { const bool k = c.t; c.r[4] += 11; if (k) { goto L_06035444; } }  // 0603543C bt/s 0x06035444 ; add #11,r4
    SH2_POLL(c); goto L_06035334;  // 06035440 bra 0x06035334 ; nop
L_06035444:
    c.r[5] = 0x0u;  // 06035444 mov #0,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06035536u);  // 06035446 mov.w 0x06035536,r4
    c.r[7] = c.r[10];  // 06035448 mov r10,r7
    c.r[6] = 0x0u;  // 0603544A mov #0,r6
L_0603544C:
    c.r[1] = ld32(0x06035558u);  // 0603544C mov.l 0x06035558,r1
    c.r[0] = ld32(c.r[1]);  // 0603544E mov.l @r1,r0
    c.r[3] = c.r[6];  // 06035450 mov r6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06035452 mov.w @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06035454 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06035456 tst r1,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0603548A; } }  // 06035458 bt/s 0x0603548A ; add r0,r3
    c.r[0] = c.r[7];  // 0603545C mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0603545E mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06035460 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06035462 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0603548A; } }  // 06035464 bt/s 0x0603548A ; mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035538u);  // 06035468 mov.w 0x06035538,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603546A mov.w @(r0,r1),r1
    c.r[2] += 4;  // 0603546C add #4,r2
    st16(c.r[2], c.r[1]);  // 0603546E mov.w r1,@r2
    c.r[2] = c.r[3];  // 06035470 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603553Au);  // 06035472 mov.w 0x0603553A,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06035474 mov.w @(r0,r1),r1
    c.r[2] += 6;  // 06035476 add #6,r2
    st16(c.r[2], c.r[1]);  // 06035478 mov.w r1,@r2
    c.r[2] = c.r[3];  // 0603547A mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603553Cu);  // 0603547C mov.w 0x0603553C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603547E mov.w @(r0,r1),r1
    c.r[2] += 10;  // 06035480 add #10,r2
    st16(c.r[2], c.r[1]);  // 06035482 mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06035484 mov.b @(r0,r4),r1
    c.r[3] += 2;  // 06035486 add #2,r3
    st8(c.r[3], c.r[1]);  // 06035488 mov.b r1,@r3
L_0603548A:
    c.r[7] += 8;  // 0603548A add #8,r7
    c.r[5] += 1;  // 0603548C add #1,r5
    c.r[1] = 0x7Fu;  // 0603548E mov #127,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 06035490 cmp/gt r1,r5
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_0603544C; } }  // 06035492 bf/s 0x0603544C ; add #12,r6
    c.r[1] = ld32(0x0603555Cu);  // 06035496 mov.l 0x0603555C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603553Eu);  // 06035498 mov.w 0x0603553E,r2
    c.r[0] = c.r[10];  // 0603549A mov r10,r0
    c.r[6] = 0x0u;  // 0603549C mov #0,r6
    c.r[8] = 0x4u;  // 0603549E mov #4,r8
    c.r[7] = ld32(c.r[1]);  // 060354A0 mov.l @r1,r7
    c.r[4] = c.r[10];  // 060354A2 mov r10,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035540u);  // 060354A4 mov.w 0x06035540,r1
    c.r[3] = c.r[7];  // 060354A6 mov r7,r3
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060354A8 mov.l @(r0,r1),r1
    c.r[3] += 10;  // 060354AA add #10,r3
    c.r[0] = c.r[7];  // 060354AC mov r7,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 060354AE mov.l r1,@(r0,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035542u);  // 060354B0 mov.w 0x06035542,r1
    c.r[0] = c.r[10];  // 060354B2 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060354B4 mov.l @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035544u);  // 060354B6 mov.w 0x06035544,r2
    c.r[0] = c.r[7];  // 060354B8 mov r7,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 060354BA mov.l r1,@(r0,r2)
    c.r[2] = c.r[7];  // 060354BC mov r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035546u);  // 060354BE mov.w 0x06035546,r1
    c.r[0] = c.r[10];  // 060354C0 mov r10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060354C2 mov.w @(r0,r1),r1
    c.r[2] += 14;  // 060354C4 add #14,r2
    st16(c.r[2], c.r[1]);  // 060354C6 mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035548u);  // 060354C8 mov.w 0x06035548,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060354CA mov.l @(r0,r1),r2
    c.r[7] += 12;  // 060354CC add #12,r7
    c.r[1] = c.r[2];  // 060354CE mov r2,r1
    c.r[1] >>= 16;  // 060354D0 shlr16 r1
    st16(c.r[3], c.r[1]);  // 060354D2 mov.w r1,@r3
    c.r[2] >>= 8;  // 060354D4 shlr8 r2
    st8(c.r[7], c.r[2]);  // 060354D6 mov.b r2,@r7
L_060354D8:
    c.r[1] = ld32(0x0603555Cu);  // 060354D8 mov.l 0x0603555C,r1
    c.r[7] = c.r[6];  // 060354DA mov r6,r7
    c.r[7] <<= 2;  // 060354DC shll2 r7
    c.r[0] = c.r[4];  // 060354DE mov r4,r0
    c.r[2] = 0x1Fu;  // 060354E0 mov #31,r2
    c.r[4] += 4;  // 060354E2 add #4,r4
    c.r[3] = ld32(c.r[1]);  // 060354E4 mov.l @r1,r3
    c.r[6] += 1;  // 060354E6 add #1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603554Au);  // 060354E8 mov.w 0x0603554A,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060354EA mov.b @(r0,r1),r1
    c.r[3] += c.r[7];  // 060354EC add r7,r3
    c.r[2] &= c.r[1];  // 060354EE and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603554Cu);  // 060354F0 mov.w 0x0603554C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060354F2 mov.b @(r0,r1),r1
    c.r[2] <<= 2;  // 060354F4 shll2 r2
    c.r[2] += c.r[2];  // 060354F6 add r2,r2
    c.r[2] <<= 2;  // 060354F8 shll2 r2
    c.r[5] = c.r[1] & 0xFFu;  // 060354FA extu.b r1,r5
    c.r[5] >>= 2;  // 060354FC shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060354FE shlr r5
    c.r[5] |= c.r[2];  // 06035500 or r2,r5
    c.r[2] = c.r[5];  // 06035502 mov r5,r2
    c.r[2] >>= 2;  // 06035504 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06035506 shlr r2
    c.r[2] >>= 2;  // 06035508 shlr2 r2
    c.r[1] = c.r[3];  // 0603550A mov r3,r1
    c.r[1] += 22;  // 0603550C add #22,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603554Eu);  // 0603550E mov.w 0x0603554E,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035510 mov.b @r1,r7
    c.r[3] += 23;  // 06035512 add #23,r3
    c.r[7] &= c.r[0];  // 06035514 and r0,r7
    c.r[7] |= c.r[2];  // 06035516 or r2,r7
    st8(c.r[1], c.r[7]);  // 06035518 mov.b r7,@r1
    c.r[0] = 0x1Fu;  // 0603551A mov #31,r0
    c.r[5] &= c.r[0];  // 0603551C and r0,r5
    c.r[5] <<= 2;  // 0603551E shll2 r5
    c.r[5] += c.r[5];  // 06035520 add r5,r5
    c.r[0] = 0x7u;  // 06035522 mov #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06035524 mov.b @r3,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[8];  // 06035526 cmp/gt r8,r6
    c.r[1] &= c.r[0];  // 06035528 and r0,r1
    c.r[1] |= c.r[5];  // 0603552A or r5,r1
    st8(c.r[3], c.r[1]); goto L_06035560;  // 0603552C bra 0x06035560 ; mov.b r1,@r3
L_06035560:
    if (!c.t) { SH2_POLL(c); goto L_060354D8; }  // 06035560 bf 0x060354D8
    c.r[6] = 0x0u;  // 06035562 mov #0,r6
    c.r[7] = 0x7Fu;  // 06035564 mov #127,r7
    c.r[3] = ld32(0x0603558Cu);  // 06035566 mov.l 0x0603558C,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035588u);  // 06035568 mov.w 0x06035588,r2
L_0603556A:
    c.r[1] = c.r[10];  // 0603556A mov r10,r1
    c.r[1] += c.r[6];  // 0603556C add r6,r1
    c.r[0] = c.r[1];  // 0603556E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06035570 mov.b @(r0,r2),r1
    c.r[0] = c.r[6];  // 06035572 mov r6,r0
    c.r[6] += 1;  // 06035574 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 06035576 cmp/gt r7,r6
    { const bool k = !c.t; st8(c.r[0] + c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_0603556A; } }  // 06035578 bf/s 0x0603556A ; mov.b r1,@(r0,r3)
    c.r[15] = c.r[14];  // 0603557C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603557E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06035580 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06035582 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06035584 rts ; mov.l @r15+,r8
}

void f_06035590(SH2Context& c) {
    ran[774] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06035590 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06035592 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06035594 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06035596 mov.l r14,@-r15
    c.r[4] = ld32(0x060357BCu);  // 06035598 mov.l 0x060357BC,r4
    c.r[1] = ld32(c.r[4]);  // 0603559A mov.l @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603579Cu);  // 0603559C mov.w 0x0603579C,r2
    c.r[0] = c.r[1];  // 0603559E mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060355A0 mov.b @(r0,r2),r2
    c.r[3] = 0x1u;  // 060355A2 mov #1,r3
    c.r[3] &= c.r[2];  // 060355A4 and r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603579Eu);  // 060355A6 mov.w 0x0603579E,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060355A8 mov.b @(r0,r2),r7
    c.r[14] = c.r[15];  // 060355AA mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A0u);  // 060355AC mov.w 0x060357A0,r0
    c.r[7] &= c.r[0];  // 060355AE and r0,r7
    c.r[7] |= c.r[3];  // 060355B0 or r3,r7
    c.r[0] = c.r[1];  // 060355B2 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 060355B4 mov.b r7,@(r0,r2)
    c.r[6] = ld32(c.r[4]);  // 060355B6 mov.l @r4,r6
    c.r[7] = ld32(0x060357C0u);  // 060355B8 mov.l 0x060357C0,r7
    c.r[1] = c.r[6];  // 060355BA mov r6,r1
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060355BC mov.l @r1+,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A2u);  // 060355BE mov.w 0x060357A2,r0
    st32(c.r[7], c.r[2]);  // 060355C0 mov.l r2,@r7
    c.r[2] = c.r[7];  // 060355C2 mov r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060355C4 mov.b @r1,r1
    c.r[2] += 4;  // 060355C6 add #4,r2
    st8(c.r[2], c.r[1]);  // 060355C8 mov.b r1,@r2
    c.r[2] = c.r[7];  // 060355CA mov r7,r2
    c.r[1] = c.r[6];  // 060355CC mov r6,r1
    c.r[1] += 5;  // 060355CE add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060355D0 mov.b @r1,r1
    c.r[2] += 5;  // 060355D2 add #5,r2
    st8(c.r[2], c.r[1]);  // 060355D4 mov.b r1,@r2
    c.r[2] = c.r[7];  // 060355D6 mov r7,r2
    c.r[1] = c.r[6];  // 060355D8 mov r6,r1
    c.r[1] += 6;  // 060355DA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060355DC mov.b @r1,r1
    c.r[2] += 6;  // 060355DE add #6,r2
    st8(c.r[2], c.r[1]);  // 060355E0 mov.b r1,@r2
    c.r[2] = c.r[7];  // 060355E2 mov r7,r2
    c.r[1] = c.r[6];  // 060355E4 mov r6,r1
    c.r[1] += 7;  // 060355E6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060355E8 mov.b @r1,r1
    c.r[2] += 7;  // 060355EA add #7,r2
    st8(c.r[2], c.r[1]);  // 060355EC mov.b r1,@r2
    c.r[2] = c.r[6];  // 060355EE mov r6,r2
    c.r[2] += 8;  // 060355F0 add #8,r2
    c.r[1] = c.r[7];  // 060355F2 mov r7,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060355F4 mov.b @r2,r3
    c.r[1] += 8;  // 060355F6 add #8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060355F8 mov.b @r1,r5
    c.r[3] &= c.r[0];  // 060355FA and r0,r3
    c.r[0] = 0x3Fu;  // 060355FC mov #63,r0
    c.r[5] &= c.r[0];  // 060355FE and r0,r5
    c.r[5] |= c.r[3];  // 06035600 or r3,r5
    st8(c.r[1], c.r[5]);  // 06035602 mov.b r5,@r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035604 mov.b @r2,r3
    c.r[8] = 0x30u;  // 06035606 mov #48,r8
    c.r[8] &= c.r[3];  // 06035608 and r3,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x060357A4u);  // 0603560A mov.w 0x060357A4,r3
    c.r[3] &= c.r[5];  // 0603560C and r5,r3
    c.r[3] |= c.r[8];  // 0603560E or r8,r3
    st8(c.r[1], c.r[3]);  // 06035610 mov.b r3,@r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035612 mov.b @r2,r5
    c.r[0] = 0x8u;  // 06035614 mov #8,r0
    c.r[5] &= c.r[0];  // 06035616 and r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A6u);  // 06035618 mov.w 0x060357A6,r0
    c.r[3] &= c.r[0];  // 0603561A and r0,r3
    c.r[3] |= c.r[5];  // 0603561C or r5,r3
    st8(c.r[1], c.r[3]);  // 0603561E mov.b r3,@r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035620 mov.b @r2,r5
    c.r[0] = 0x4u;  // 06035622 mov #4,r0
    c.r[5] &= c.r[0];  // 06035624 and r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A8u);  // 06035626 mov.w 0x060357A8,r0
    c.r[3] &= c.r[0];  // 06035628 and r0,r3
    c.r[3] |= c.r[5];  // 0603562A or r5,r3
    st8(c.r[1], c.r[3]);  // 0603562C mov.b r3,@r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603562E mov.b @r2,r5
    c.r[0] = 0x2u;  // 06035630 mov #2,r0
    c.r[5] &= c.r[0];  // 06035632 and r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357AAu);  // 06035634 mov.w 0x060357AA,r0
    c.r[3] &= c.r[0];  // 06035636 and r0,r3
    c.r[3] |= c.r[5];  // 06035638 or r5,r3
    st8(c.r[1], c.r[3]);  // 0603563A mov.b r3,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603563C mov.b @r2,r2
    c.r[0] = 0x1u;  // 0603563E mov #1,r0
    c.r[2] &= c.r[0];  // 06035640 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A0u);  // 06035642 mov.w 0x060357A0,r0
    c.r[3] &= c.r[0];  // 06035644 and r0,r3
    c.r[3] |= c.r[2];  // 06035646 or r2,r3
    st8(c.r[1], c.r[3]);  // 06035648 mov.b r3,@r1
    c.r[2] = c.r[6];  // 0603564A mov r6,r2
    c.r[2] += 9;  // 0603564C add #9,r2
    c.r[1] = c.r[7];  // 0603564E mov r7,r1
    c.r[1] += 9;  // 06035650 add #9,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035652 mov.b @r2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357ACu);  // 06035654 mov.w 0x060357AC,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035656 mov.b @r1,r5
    c.r[3] &= c.r[0];  // 06035658 and r0,r3
    c.r[0] = 0x7Fu;  // 0603565A mov #127,r0
    c.r[5] &= c.r[0];  // 0603565C and r0,r5
    c.r[5] |= c.r[3];  // 0603565E or r3,r5
    st8(c.r[1], c.r[5]);  // 06035660 mov.b r5,@r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035662 mov.b @r2,r3
    c.r[8] = 0x60u;  // 06035664 mov #96,r8
    c.r[8] &= c.r[3];  // 06035666 and r3,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x060357AEu);  // 06035668 mov.w 0x060357AE,r3
    c.r[3] &= c.r[5];  // 0603566A and r5,r3
    c.r[3] |= c.r[8];  // 0603566C or r8,r3
    st8(c.r[1], c.r[3]);  // 0603566E mov.b r3,@r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035670 mov.b @r2,r5
    c.r[0] = 0x18u;  // 06035672 mov #24,r0
    c.r[5] &= c.r[0];  // 06035674 and r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357B0u);  // 06035676 mov.w 0x060357B0,r0
    c.r[3] &= c.r[0];  // 06035678 and r0,r3
    c.r[3] |= c.r[5];  // 0603567A or r5,r3
    st8(c.r[1], c.r[3]);  // 0603567C mov.b r3,@r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603567E mov.b @r2,r5
    c.r[0] = 0x4u;  // 06035680 mov #4,r0
    c.r[5] &= c.r[0];  // 06035682 and r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A8u);  // 06035684 mov.w 0x060357A8,r0
    c.r[3] &= c.r[0];  // 06035686 and r0,r3
    c.r[3] |= c.r[5];  // 06035688 or r5,r3
    st8(c.r[1], c.r[3]);  // 0603568A mov.b r3,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603568C mov.b @r2,r2
    c.r[0] = 0x3u;  // 0603568E mov #3,r0
    c.r[2] &= c.r[0];  // 06035690 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357B2u);  // 06035692 mov.w 0x060357B2,r0
    c.r[3] &= c.r[0];  // 06035694 and r0,r3
    c.r[3] |= c.r[2];  // 06035696 or r2,r3
    st8(c.r[1], c.r[3]);  // 06035698 mov.b r3,@r1
    c.r[1] = c.r[6];  // 0603569A mov r6,r1
    c.r[1] += 10;  // 0603569C add #10,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603569E mov.w @r1,r3
    c.r[8] = 0x4u;  // 060356A0 mov #4,r8
    c.r[3] = c.r[3] & 0xFFFFu;  // 060356A2 extu.w r3,r3
    c.r[1] = c.r[6];  // 060356A4 mov r6,r1
    c.r[1] += 12;  // 060356A6 add #12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060356A8 mov.b @r1,r2
    c.r[3] <<= 8;  // 060356AA shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 060356AC extu.b r2,r2
    c.r[2] |= c.r[3];  // 060356AE or r3,r2
    c.r[3] = c.r[7];  // 060356B0 mov r7,r3
    c.r[3] += 10;  // 060356B2 add #10,r3
    c.r[1] = c.r[2];  // 060356B4 mov r2,r1
    c.r[1] >>= 8;  // 060356B6 shlr8 r1
    st16(c.r[3], c.r[1]);  // 060356B8 mov.w r1,@r3
    c.r[1] = c.r[7];  // 060356BA mov r7,r1
    c.r[1] += 12;  // 060356BC add #12,r1
    st8(c.r[1], c.r[2]);  // 060356BE mov.b r2,@r1
    c.r[2] = c.r[7];  // 060356C0 mov r7,r2
    c.r[1] = c.r[6];  // 060356C2 mov r6,r1
    c.r[1] += 14;  // 060356C4 add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060356C6 mov.w @r1,r1
    c.r[2] += 14;  // 060356C8 add #14,r2
    st16(c.r[2], c.r[1]);  // 060356CA mov.w r1,@r2
    c.r[1] = c.r[6];  // 060356CC mov r6,r1
    c.r[1] += 16;  // 060356CE add #16,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060356D0 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357A0u);  // 060356D2 mov.w 0x060357A0,r0
    c.r[1] = c.r[7];  // 060356D4 mov r7,r1
    c.r[1] += 16;  // 060356D6 add #16,r1
    c.r[2] &= c.r[0];  // 060356D8 and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060356DA mov.b @r1,r3
    c.r[0] = 0x1u;  // 060356DC mov #1,r0
    c.r[3] &= c.r[0];  // 060356DE and r0,r3
    c.r[3] |= c.r[2];  // 060356E0 or r2,r3
    st8(c.r[1], c.r[3]);  // 060356E2 mov.b r3,@r1
    c.r[1] = ld32(0x060357C4u);  // 060356E4 mov.l 0x060357C4,r1
    c.r[5] = ld32(c.r[1] + 12);  // 060356E6 mov.l @(12,r1),r5
    c.r[3] = ld32(0x060357C8u);  // 060356E8 mov.l 0x060357C8,r3
    c.r[2] = ld32(c.r[6] + 16);  // 060356EA mov.l @(16,r6),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060357B4u);  // 060356EC mov.w 0x060357B4,r1
    c.r[5] &= c.r[1];  // 060356EE and r1,r5
    c.r[5] <<= 8;  // 060356F0 shll8 r5
    c.r[5] += c.r[5];  // 060356F2 add r5,r5
    c.r[5] <<= 2;  // 060356F4 shll2 r5
    c.r[2] &= c.r[3];  // 060356F6 and r3,r2
    c.r[2] |= c.r[5];  // 060356F8 or r5,r2
    st32(c.r[6] + 16, c.r[2]);  // 060356FA mov.l r2,@(16,r6)
    c.r[2] >>= 8;  // 060356FC shlr8 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060356FE shlr r2
    c.r[2] >>= 2;  // 06035700 shlr2 r2
    c.r[2] &= c.r[1];  // 06035702 and r1,r2
    c.r[2] <<= 8;  // 06035704 shll8 r2
    c.r[2] += c.r[2];  // 06035706 add r2,r2
    c.r[2] <<= 2;  // 06035708 shll2 r2
    c.r[6] += 18;  // 0603570A add #18,r6
    c.r[1] = ld32(c.r[7] + 16);  // 0603570C mov.l @(16,r7),r1
    c.r[5] = c.r[7];  // 0603570E mov r7,r5
    c.r[1] &= c.r[3];  // 06035710 and r3,r1
    c.r[2] |= c.r[1];  // 06035712 or r1,r2
    st32(c.r[7] + 16, c.r[2]);  // 06035714 mov.l r2,@(16,r7)
    c.r[3] = c.r[7];  // 06035716 mov r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06035718 mov.w @r6,r1
    c.r[3] += 18;  // 0603571A add #18,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x060357B6u);  // 0603571C mov.w 0x060357B6,r6
    c.r[6] &= c.r[1];  // 0603571E and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06035720 mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060357B8u);  // 06035722 mov.w 0x060357B8,r2
    c.r[1] &= c.r[2];  // 06035724 and r2,r1
    c.r[1] |= c.r[6];  // 06035726 or r6,r1
    st16(c.r[3], c.r[1]);  // 06035728 mov.w r1,@r3
    c.r[6] = 0x0u;  // 0603572A mov #0,r6
L_0603572C:
    c.r[7] = c.r[6];  // 0603572C mov r6,r7
    c.r[7] <<= 2;  // 0603572E shll2 r7
    c.r[3] = 0x1Fu;  // 06035730 mov #31,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060357BAu);  // 06035732 mov.w 0x060357BA,r0
    c.r[2] = ld32(c.r[4]);  // 06035734 mov.l @r4,r2
    c.r[6] += 1;  // 06035736 add #1,r6
    c.r[2] += c.r[7];  // 06035738 add r7,r2
    c.r[1] = c.r[2];  // 0603573A mov r2,r1
    c.r[1] += 22;  // 0603573C add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603573E mov.b @r1,r1
    c.r[2] += 23;  // 06035740 add #23,r2
    c.r[3] &= c.r[1];  // 06035742 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035744 mov.b @r2,r1
    c.r[3] <<= 2;  // 06035746 shll2 r3
    c.r[3] += c.r[3];  // 06035748 add r3,r3
    c.r[3] <<= 2;  // 0603574A shll2 r3
    c.r[2] = c.r[1] & 0xFFu;  // 0603574C extu.b r1,r2
    c.r[2] >>= 2;  // 0603574E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06035750 shlr r2
    c.r[2] |= c.r[3];  // 06035752 or r3,r2
    c.r[1] = c.r[2];  // 06035754 mov r2,r1
    c.r[3] = c.r[5];  // 06035756 mov r5,r3
    c.r[3] += 22;  // 06035758 add #22,r3
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603575A mov.b @r3,r9
    c.r[1] >>= 2;  // 0603575C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603575E shlr r1
    c.r[1] >>= 2;  // 06035760 shlr2 r1
    c.r[9] &= c.r[0];  // 06035762 and r0,r9
    c.r[9] |= c.r[1];  // 06035764 or r1,r9
    st8(c.r[3], c.r[9]);  // 06035766 mov.b r9,@r3
    c.r[0] = 0x1Fu;  // 06035768 mov #31,r0
    c.r[2] &= c.r[0];  // 0603576A and r0,r2
    c.r[1] = c.r[5];  // 0603576C mov r5,r1
    c.r[1] += 23;  // 0603576E add #23,r1
    c.r[2] <<= 2;  // 06035770 shll2 r2
    c.r[2] += c.r[2];  // 06035772 add r2,r2
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035774 mov.b @r1,r9
    c.r[0] = 0x7u;  // 06035776 mov #7,r0
    c.r[9] &= c.r[0];  // 06035778 and r0,r9
    c.r[9] |= c.r[2];  // 0603577A or r2,r9
    st8(c.r[1], c.r[9]);  // 0603577C mov.b r9,@r1
    c.r[1] = ld32(c.r[4]);  // 0603577E mov.l @r4,r1
    c.r[2] = c.r[5];  // 06035780 mov r5,r2
    c.r[1] += c.r[7];  // 06035782 add r7,r1
    c.r[1] += 20;  // 06035784 add #20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035786 mov.b @r1,r1
    c.r[2] += 20;  // 06035788 add #20,r2
    st8(c.r[2], c.r[1]);  // 0603578A mov.b r1,@r2
    c.r[1] = ld32(c.r[4]);  // 0603578C mov.l @r4,r1
    c.r[2] = c.r[5];  // 0603578E mov r5,r2
    c.r[1] += c.r[7];  // 06035790 add r7,r1
    c.r[1] += 21;  // 06035792 add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035794 mov.b @r1,r1
    c.r[2] += 21;  // 06035796 add #21,r2
    st8(c.r[2], c.r[1]); goto L_060357CC;  // 06035798 bra 0x060357CC ; mov.b r1,@r2
L_060357CC:
    c.r[1] = ld32(c.r[4]);  // 060357CC mov.l @r4,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[8];  // 060357CE cmp/gt r8,r6
    c.r[1] += c.r[7];  // 060357D0 add r7,r1
    c.r[1] += 22;  // 060357D2 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060357D4 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035974u);  // 060357D6 mov.w 0x06035974,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060357D8 mov.b @r3,r2
    c.r[1] &= c.r[0];  // 060357DA and r0,r1
    c.r[0] = 0x3Fu;  // 060357DC mov #63,r0
    c.r[2] &= c.r[0];  // 060357DE and r0,r2
    c.r[2] |= c.r[1];  // 060357E0 or r1,r2
    st8(c.r[3], c.r[2]);  // 060357E2 mov.b r2,@r3
    c.r[1] = ld32(c.r[4]);  // 060357E4 mov.l @r4,r1
    c.r[5] += 4;  // 060357E6 add #4,r5
    c.r[1] += c.r[7];  // 060357E8 add r7,r1
    c.r[1] += 22;  // 060357EA add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060357EC mov.b @r1,r1
    c.r[0] = 0x20u;  // 060357EE mov #32,r0
    c.r[1] &= c.r[0];  // 060357F0 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035976u);  // 060357F2 mov.w 0x06035976,r0
    c.r[2] &= c.r[0];  // 060357F4 and r0,r2
    c.r[2] |= c.r[1];  // 060357F6 or r1,r2
    { const bool k = !c.t; st8(c.r[3], c.r[2]); if (k) { SH2_POLL(c); goto L_0603572C; } }  // 060357F8 bf/s 0x0603572C ; mov.b r2,@r3
    c.r[6] = 0x0u;  // 060357FC mov #0,r6
    c.r[5] = 0x2u;  // 060357FE mov #2,r5
    c.r[1] = ld32(0x060359B4u);  // 06035800 mov.l 0x060359B4,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06035978u);  // 06035802 mov.w 0x06035978,r4
    c.r[7] = ld32(c.r[1]);  // 06035804 mov.l @r1,r7
    c.r[3] = ld32(0x060359B8u);  // 06035806 mov.l 0x060359B8,r3
L_06035808:
    c.r[2] = c.r[3];  // 06035808 mov r3,r2
    c.r[2] += 40;  // 0603580A add #40,r2
    c.r[0] = c.r[7];  // 0603580C mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0603580E mov.w @(r0,r4),r1
    c.r[7] += 2;  // 06035810 add #2,r7
    c.r[3] += 2;  // 06035812 add #2,r3
    c.r[6] += 1;  // 06035814 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[5];  // 06035816 cmp/gt r5,r6
    { const bool k = !c.t; st16(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06035808; } }  // 06035818 bf/s 0x06035808 ; mov.w r1,@r2
    c.r[6] = 0x0u;  // 0603581C mov #0,r6
    c.r[5] = 0x5u;  // 0603581E mov #5,r5
    c.r[7] = ld32(0x060359B8u);  // 06035820 mov.l 0x060359B8,r7
    c.r[3] = ld32(0x060359B4u);  // 06035822 mov.l 0x060359B4,r3
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603597Au);  // 06035824 mov.w 0x0603597A,r4
L_06035826:
    c.r[2] = c.r[6];  // 06035826 mov r6,r2
    c.r[2] += c.r[7];  // 06035828 add r7,r2
    c.r[1] = ld32(c.r[3]);  // 0603582A mov.l @r3,r1
    c.r[2] += 46;  // 0603582C add #46,r2
    c.r[1] += c.r[6];  // 0603582E add r6,r1
    c.r[0] = c.r[1];  // 06035830 mov r1,r0
    c.r[6] += 1;  // 06035832 add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06035834 mov.b @(r0,r4),r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[5];  // 06035836 cmp/gt r5,r6
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06035826; } }  // 06035838 bf/s 0x06035826 ; mov.b r1,@r2
    c.r[2] = ld32(0x060359BCu);  // 0603583C mov.l 0x060359BC,r2
    c.r[1] = ld32(0x060359B4u);  // 0603583E mov.l 0x060359B4,r1
    c.r[3] = ld32(c.r[1]);  // 06035840 mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603597Cu);  // 06035842 mov.w 0x0603597C,r1
    c.r[0] = c.r[3];  // 06035844 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035846 mov.l @(r0,r1),r1
    st32(c.r[2], c.r[1]);  // 06035848 mov.l r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603597Eu);  // 0603584A mov.w 0x0603597E,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0603584C mov.l @(r0,r1),r1
    c.r[7] = c.r[3];  // 0603584E mov r3,r7
    st32(c.r[2] + 4, c.r[1]);  // 06035850 mov.l r1,@(4,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035980u);  // 06035852 mov.w 0x06035980,r1
    c.r[7] += c.r[1];  // 06035854 add r1,r7
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035856 mov.l @(r0,r1),r1
    st32(c.r[2] + 8, c.r[1]);  // 06035858 mov.l r1,@(8,r2)
    c.r[1] = ld32(c.r[7] + 4);  // 0603585A mov.l @(4,r7),r1
    st32(c.r[2] + 12, c.r[1]);  // 0603585C mov.l r1,@(12,r2)
    c.r[7] += 8;  // 0603585E add #8,r7
    c.r[1] = ld32(c.r[7]); c.r[7] += 4;  // 06035860 mov.l @r7+,r1
    st32(c.r[2] + 16, c.r[1]);  // 06035862 mov.l r1,@(16,r2)
    c.r[1] = ld32(c.r[7]); c.r[7] += 4;  // 06035864 mov.l @r7+,r1
    st32(c.r[2] + 20, c.r[1]);  // 06035866 mov.l r1,@(20,r2)
    c.r[1] = ld32(c.r[7]);  // 06035868 mov.l @r7,r1
    st32(c.r[2] + 24, c.r[1]);  // 0603586A mov.l r1,@(24,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035982u);  // 0603586C mov.w 0x06035982,r1
    c.r[7] = c.r[3];  // 0603586E mov r3,r7
    c.r[7] += c.r[1];  // 06035870 add r1,r7
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035872 mov.l @(r0,r1),r1
    c.r[6] = 0x0u;  // 06035874 mov #0,r6
    st32(c.r[2] + 28, c.r[1]);  // 06035876 mov.l r1,@(28,r2)
    c.r[1] = ld32(c.r[7] + 4);  // 06035878 mov.l @(4,r7),r1
    c.r[9] = 0x9u;  // 0603587A mov #9,r9
    st32(c.r[2] + 32, c.r[1]);  // 0603587C mov.l r1,@(32,r2)
    c.r[7] += 8;  // 0603587E add #8,r7
    c.r[1] = ld32(c.r[7]); c.r[7] += 4;  // 06035880 mov.l @r7+,r1
    c.r[4] = c.r[2];  // 06035882 mov r2,r4
    st32(c.r[2] + 36, c.r[1]);  // 06035884 mov.l r1,@(36,r2)
    c.r[1] = ld32(c.r[7]); c.r[7] += 4;  // 06035886 mov.l @r7+,r1
    c.r[4] -= 52;  // 06035888 add #-52,r4
    st32(c.r[2] + 40, c.r[1]);  // 0603588A mov.l r1,@(40,r2)
    c.r[1] = ld32(c.r[7]);  // 0603588C mov.l @r7,r1
    c.r[5] = 0x0u;  // 0603588E mov #0,r5
    st32(c.r[2] + 44, c.r[1]);  // 06035890 mov.l r1,@(44,r2)
L_06035892:
    c.r[10] = 0x0u;  // 06035892 mov #0,r10
    c.r[7] = c.r[5];  // 06035894 mov r5,r7
    c.r[3] = c.r[4];  // 06035896 mov r4,r3
    c.r[3] += 100;  // 06035898 add #100,r3
    c.r[8] = ld32(0x060359B4u);  // 0603589A mov.l 0x060359B4,r8
L_0603589C:
    c.r[1] = ld32(c.r[8]);  // 0603589C mov.l @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035984u);  // 0603589E mov.w 0x06035984,r2
    c.r[1] += c.r[7];  // 060358A0 add r7,r1
    c.r[1] += c.r[2];  // 060358A2 add r2,r1
    c.r[0] = c.r[1];  // 060358A4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060358A6 mov.b @(r0,r10),r1
    c.r[0] = c.r[3];  // 060358A8 mov r3,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 060358AA mov.b r1,@(r0,r10)
    c.r[10] += 1;  // 060358AC add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[9];  // 060358AE cmp/gt r9,r10
    if (!c.t) { SH2_POLL(c); goto L_0603589C; }  // 060358B0 bf 0x0603589C
    c.r[4] += 10;  // 060358B2 add #10,r4
    c.r[6] += 1;  // 060358B4 add #1,r6
    c.r[1] = 0x2u;  // 060358B6 mov #2,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 060358B8 cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 10; if (k) { SH2_POLL(c); goto L_06035892; } }  // 060358BA bf/s 0x06035892 ; add #10,r5
    c.r[3] = ld32(0x060359B8u);  // 060358BE mov.l 0x060359B8,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035986u);  // 060358C0 mov.w 0x06035986,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035988u);  // 060358C2 mov.w 0x06035988,r1
    c.r[6] = 0x0u;  // 060358C4 mov #0,r6
    c.r[2] = ld32(c.r[8]);  // 060358C6 mov.l @r8,r2
    c.r[4] = 0x3Fu;  // 060358C8 mov #63,r4
    c.r[0] = c.r[2];  // 060358CA mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060358CC mov.l @(r0,r1),r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603598Au);  // 060358CE mov.w 0x0603598A,r5
    c.r[0] = c.r[3];  // 060358D0 mov r3,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 060358D2 mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603598Cu);  // 060358D4 mov.w 0x0603598C,r1
    c.r[0] = c.r[2];  // 060358D6 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060358D8 mov.l @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603598Eu);  // 060358DA mov.w 0x0603598E,r7
    c.r[0] = c.r[3];  // 060358DC mov r3,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 060358DE mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035990u);  // 060358E0 mov.w 0x06035990,r1
    c.r[0] = c.r[2];  // 060358E2 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060358E4 mov.l @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035992u);  // 060358E6 mov.w 0x06035992,r7
    c.r[0] = c.r[3];  // 060358E8 mov r3,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 060358EA mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035994u);  // 060358EC mov.w 0x06035994,r1
    c.r[0] = c.r[2];  // 060358EE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060358F0 mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035996u);  // 060358F2 mov.w 0x06035996,r7
    c.r[0] = c.r[3];  // 060358F4 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 060358F6 mov.b r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035998u);  // 060358F8 mov.w 0x06035998,r1
    c.r[0] = c.r[2];  // 060358FA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060358FC mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603599Au);  // 060358FE mov.w 0x0603599A,r7
    c.r[0] = c.r[3];  // 06035900 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06035902 mov.b r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603599Cu);  // 06035904 mov.w 0x0603599C,r1
    c.r[0] = c.r[2];  // 06035906 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035908 mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603599Eu);  // 0603590A mov.w 0x0603599E,r7
    c.r[0] = c.r[3];  // 0603590C mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0603590E mov.b r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060359A0u);  // 06035910 mov.w 0x060359A0,r1
    c.r[0] = c.r[2];  // 06035912 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035914 mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060359A2u);  // 06035916 mov.w 0x060359A2,r7
    c.r[0] = c.r[3];  // 06035918 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0603591A mov.b r1,@(r0,r7)
    c.r[2] = c.r[8];  // 0603591C mov r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060359A4u);  // 0603591E mov.w 0x060359A4,r7
L_06035920:
    c.r[8] = c.r[6];  // 06035920 mov r6,r8
    c.r[1] = ld32(c.r[2]);  // 06035922 mov.l @r2,r1
    c.r[8] += c.r[3];  // 06035924 add r3,r8
    c.r[1] += c.r[6];  // 06035926 add r6,r1
    c.r[0] = c.r[1];  // 06035928 mov r1,r0
    c.r[6] += 1;  // 0603592A add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0603592C mov.b @(r0,r7),r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[4];  // 0603592E cmp/gt r4,r6
    c.r[0] = c.r[8];  // 06035930 mov r8,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { SH2_POLL(c); goto L_06035920; } }  // 06035932 bf/s 0x06035920 ; mov.b r1,@(r0,r5)
    c.r[6] = 0x0u;  // 06035936 mov #0,r6
    c.r[4] = 0x1Du;  // 06035938 mov #29,r4
    c.r[5] = ld32(0x060359B8u);  // 0603593A mov.l 0x060359B8,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x060359A6u);  // 0603593C mov.w 0x060359A6,r3
    c.r[7] = ld32(0x060359B4u);  // 0603593E mov.l 0x060359B4,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x060359A8u);  // 06035940 mov.w 0x060359A8,r2
L_06035942:
    c.r[8] = c.r[6];  // 06035942 mov r6,r8
    c.r[1] = ld32(c.r[7]);  // 06035944 mov.l @r7,r1
    c.r[8] += c.r[5];  // 06035946 add r5,r8
    c.r[1] += c.r[6];  // 06035948 add r6,r1
    c.r[0] = c.r[1];  // 0603594A mov r1,r0
    c.r[6] += 1;  // 0603594C add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603594E mov.b @(r0,r2),r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[4];  // 06035950 cmp/gt r4,r6
    c.r[0] = c.r[8];  // 06035952 mov r8,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_06035942; } }  // 06035954 bf/s 0x06035942 ; mov.b r1,@(r0,r3)
    c.r[2] = ld32(0x060359B8u);  // 06035958 mov.l 0x060359B8,r2
    c.r[1] = ld32(0x060359B4u);  // 0603595A mov.l 0x060359B4,r1
    c.r[3] = ld32(c.r[1]);  // 0603595C mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060359AAu);  // 0603595E mov.w 0x060359AA,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x060359ACu);  // 06035960 mov.w 0x060359AC,r1
    c.r[0] = c.r[3];  // 06035962 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035964 mov.l @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060359AEu);  // 06035966 mov.w 0x060359AE,r6
    c.r[0] = c.r[2];  // 06035968 mov r2,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0603596A mov.l r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060359B0u);  // 0603596C mov.w 0x060359B0,r1
    c.r[0] = c.r[3];  // 0603596E mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]); goto L_060359C0;  // 06035970 bra 0x060359C0 ; mov.l @(r0,r1),r1
L_060359C0:
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035A1Au);  // 060359C0 mov.w 0x06035A1A,r7
    c.r[0] = c.r[2];  // 060359C2 mov r2,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 060359C4 mov.l r1,@(r0,r7)
    c.r[0] = c.r[3];  // 060359C6 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060359C8 mov.b @(r0,r6),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035A1Cu);  // 060359CA mov.w 0x06035A1C,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035A1Eu);  // 060359CC mov.w 0x06035A1E,r0
    c.r[1] &= c.r[0];  // 060359CE and r0,r1
    c.r[0] = c.r[2];  // 060359D0 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060359D2 mov.b @(r0,r7),r5
    c.r[0] = 0x3Fu;  // 060359D4 mov #63,r0
    c.r[5] &= c.r[0];  // 060359D6 and r0,r5
    c.r[5] |= c.r[1];  // 060359D8 or r1,r5
    c.r[0] = c.r[2];  // 060359DA mov r2,r0
    st8(c.r[0] + c.r[7], c.r[5]);  // 060359DC mov.b r5,@(r0,r7)
    c.r[0] = c.r[3];  // 060359DE mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060359E0 mov.b @(r0,r6),r1
    c.r[4] = 0x30u;  // 060359E2 mov #48,r4
    c.r[4] &= c.r[1];  // 060359E4 and r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035A20u);  // 060359E6 mov.w 0x06035A20,r1
    c.r[1] &= c.r[5];  // 060359E8 and r5,r1
    c.r[1] |= c.r[4];  // 060359EA or r4,r1
    c.r[0] = c.r[2];  // 060359EC mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 060359EE mov.b r1,@(r0,r7)
    c.r[0] = c.r[3];  // 060359F0 mov r3,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060359F2 mov.b @(r0,r6),r6
    c.r[15] = c.r[14];  // 060359F4 mov r14,r15
    c.r[0] = 0x8u;  // 060359F6 mov #8,r0
    c.r[6] &= c.r[0];  // 060359F8 and r0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035A22u);  // 060359FA mov.w 0x06035A22,r0
    c.r[1] &= c.r[0];  // 060359FC and r0,r1
    c.r[1] |= c.r[6];  // 060359FE or r6,r1
    c.r[0] = c.r[2];  // 06035A00 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06035A02 mov.b r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035A24u);  // 06035A04 mov.w 0x06035A24,r1
    c.r[0] = c.r[3];  // 06035A06 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035A08 mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035A26u);  // 06035A0A mov.w 0x06035A26,r7
    c.r[0] = c.r[2];  // 06035A0C mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06035A0E mov.b r1,@(r0,r7)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06035A10 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06035A12 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06035A14 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06035A16 rts ; mov.l @r15+,r8
}

void f_06035A28(SH2Context& c) {
    ran[775] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06035A28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06035A2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06035A2C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06035A2E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06035A30 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06035A32 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06035A34 sts.l pr,@-r15
    c.r[6] = ld32(0x06035C5Cu);  // 06035A36 mov.l 0x06035C5C,r6
    c.r[5] = ld32(0x06035C60u);  // 06035A38 mov.l 0x06035C60,r5
    c.r[3] = ld32(c.r[6]);  // 06035A3A mov.l @r6,r3
    c.r[1] = c.r[5];  // 06035A3C mov r5,r1
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 06035A3E mov.l @r1+,r2
    st32(c.r[3], c.r[2]);  // 06035A40 mov.l r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A42 mov.b @r1,r1
    c.r[3] += 4;  // 06035A44 add #4,r3
    st8(c.r[3], c.r[1]);  // 06035A46 mov.b r1,@r3
    c.r[1] = c.r[5];  // 06035A48 mov r5,r1
    c.r[1] += 5;  // 06035A4A add #5,r1
    c.r[2] = ld32(c.r[6]);  // 06035A4C mov.l @r6,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035C4Eu);  // 06035A4E mov.w 0x06035C4E,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A50 mov.b @r1,r1
    c.r[2] += 5;  // 06035A52 add #5,r2
    st8(c.r[2], c.r[1]);  // 06035A54 mov.b r1,@r2
    c.r[1] = c.r[5];  // 06035A56 mov r5,r1
    c.r[2] = ld32(c.r[6]);  // 06035A58 mov.l @r6,r2
    c.r[1] += 6;  // 06035A5A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A5C mov.b @r1,r1
    c.r[2] += 6;  // 06035A5E add #6,r2
    st8(c.r[2], c.r[1]);  // 06035A60 mov.b r1,@r2
    c.r[1] = c.r[5];  // 06035A62 mov r5,r1
    c.r[2] = ld32(c.r[6]);  // 06035A64 mov.l @r6,r2
    c.r[1] += 7;  // 06035A66 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A68 mov.b @r1,r1
    c.r[2] += 7;  // 06035A6A add #7,r2
    st8(c.r[2], c.r[1]);  // 06035A6C mov.b r1,@r2
    c.r[2] = c.r[5];  // 06035A6E mov r5,r2
    c.r[1] = ld32(c.r[6]);  // 06035A70 mov.l @r6,r1
    c.r[2] += 8;  // 06035A72 add #8,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035A74 mov.b @r2,r0
    c.r[1] += 8;  // 06035A76 add #8,r1
    c.r[3] &= c.r[0];  // 06035A78 and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A7A mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06035A7C and #63,r0
    c.r[0] |= c.r[3];  // 06035A7E or r3,r0
    st8(c.r[1], c.r[0]);  // 06035A80 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035A82 mov.l @r6,r1
    c.r[3] = 0x30u;  // 06035A84 mov #48,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035A86 mov.b @r2,r0
    c.r[1] += 8;  // 06035A88 add #8,r1
    c.r[3] &= c.r[0];  // 06035A8A and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A8C mov.b @r1,r0
    c.r[0] &= 0xCFu;  // 06035A8E and #207,r0
    c.r[0] |= c.r[3];  // 06035A90 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035A92 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035A94 mov.l @r6,r1
    c.r[3] = 0x8u;  // 06035A96 mov #8,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035A98 mov.b @r2,r0
    c.r[1] += 8;  // 06035A9A add #8,r1
    c.r[3] &= c.r[0];  // 06035A9C and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035A9E mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 06035AA0 and #247,r0
    c.r[0] |= c.r[3];  // 06035AA2 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035AA4 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035AA6 mov.l @r6,r1
    c.r[3] = 0x4u;  // 06035AA8 mov #4,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035AAA mov.b @r2,r0
    c.r[1] += 8;  // 06035AAC add #8,r1
    c.r[3] &= c.r[0];  // 06035AAE and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035AB0 mov.b @r1,r0
    c.r[0] &= 0xFBu;  // 06035AB2 and #251,r0
    c.r[0] |= c.r[3];  // 06035AB4 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035AB6 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035AB8 mov.l @r6,r1
    c.r[3] = 0x2u;  // 06035ABA mov #2,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035ABC mov.b @r2,r0
    c.r[1] += 8;  // 06035ABE add #8,r1
    c.r[3] &= c.r[0];  // 06035AC0 and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035AC2 mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 06035AC4 and #253,r0
    c.r[0] |= c.r[3];  // 06035AC6 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035AC8 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035ACA mov.b @r2,r0
    c.r[1] = ld32(c.r[6]);  // 06035ACC mov.l @r6,r1
    c.r[2] = 0x1u;  // 06035ACE mov #1,r2
    c.r[2] &= c.r[0];  // 06035AD0 and r0,r2
    c.r[1] += 8;  // 06035AD2 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035AD4 mov.b @r1,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035C50u);  // 06035AD6 mov.w 0x06035C50,r3
    c.r[0] &= 0xFEu;  // 06035AD8 and #254,r0
    c.r[0] |= c.r[2];  // 06035ADA or r2,r0
    st8(c.r[1], c.r[0]);  // 06035ADC mov.b r0,@r1
    c.r[2] = c.r[5];  // 06035ADE mov r5,r2
    c.r[1] = ld32(c.r[6]);  // 06035AE0 mov.l @r6,r1
    c.r[2] += 9;  // 06035AE2 add #9,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035AE4 mov.b @r2,r0
    c.r[1] += 9;  // 06035AE6 add #9,r1
    c.r[3] &= c.r[0];  // 06035AE8 and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035AEA mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06035AEC and #127,r0
    c.r[0] |= c.r[3];  // 06035AEE or r3,r0
    st8(c.r[1], c.r[0]);  // 06035AF0 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035AF2 mov.l @r6,r1
    c.r[3] = 0x60u;  // 06035AF4 mov #96,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035AF6 mov.b @r2,r0
    c.r[1] += 9;  // 06035AF8 add #9,r1
    c.r[3] &= c.r[0];  // 06035AFA and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035AFC mov.b @r1,r0
    c.r[0] &= 0x9Fu;  // 06035AFE and #159,r0
    c.r[0] |= c.r[3];  // 06035B00 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035B02 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035B04 mov.l @r6,r1
    c.r[3] = 0x18u;  // 06035B06 mov #24,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035B08 mov.b @r2,r0
    c.r[1] += 9;  // 06035B0A add #9,r1
    c.r[3] &= c.r[0];  // 06035B0C and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035B0E mov.b @r1,r0
    c.r[0] &= 0xE7u;  // 06035B10 and #231,r0
    c.r[0] |= c.r[3];  // 06035B12 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035B14 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06035B16 mov.l @r6,r1
    c.r[3] = 0x4u;  // 06035B18 mov #4,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035B1A mov.b @r2,r0
    c.r[1] += 9;  // 06035B1C add #9,r1
    c.r[3] &= c.r[0];  // 06035B1E and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035B20 mov.b @r1,r0
    c.r[0] &= 0xFBu;  // 06035B22 and #251,r0
    c.r[0] |= c.r[3];  // 06035B24 or r3,r0
    st8(c.r[1], c.r[0]);  // 06035B26 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035B28 mov.b @r2,r0
    c.r[14] = c.r[15];  // 06035B2A mov r15,r14
    c.r[1] = ld32(c.r[6]);  // 06035B2C mov.l @r6,r1
    c.r[2] = 0x3u;  // 06035B2E mov #3,r2
    c.r[2] &= c.r[0];  // 06035B30 and r0,r2
    c.r[1] += 9;  // 06035B32 add #9,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035B34 mov.b @r1,r0
    c.r[11] = 0x4u;  // 06035B36 mov #4,r11
    c.r[0] &= 0xFCu;  // 06035B38 and #252,r0
    c.r[0] |= c.r[2];  // 06035B3A or r2,r0
    st8(c.r[1], c.r[0]);  // 06035B3C mov.b r0,@r1
    c.r[1] = c.r[5];  // 06035B3E mov r5,r1
    c.r[1] += 10;  // 06035B40 add #10,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035B42 mov.w @r1,r3
    c.r[9] = c.r[6];  // 06035B44 mov r6,r9
    c.r[7] = ld32(c.r[6]);  // 06035B46 mov.l @r6,r7
    c.r[3] = c.r[3] & 0xFFFFu;  // 06035B48 extu.w r3,r3
    c.r[1] = c.r[5];  // 06035B4A mov r5,r1
    c.r[1] += 12;  // 06035B4C add #12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035B4E mov.b @r1,r2
    c.r[3] <<= 8;  // 06035B50 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06035B52 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06035B54 or r3,r2
    c.r[3] = c.r[7];  // 06035B56 mov r7,r3
    c.r[3] += 10;  // 06035B58 add #10,r3
    c.r[1] = c.r[2];  // 06035B5A mov r2,r1
    c.r[1] >>= 8;  // 06035B5C shlr8 r1
    st16(c.r[3], c.r[1]);  // 06035B5E mov.w r1,@r3
    c.r[7] += 12;  // 06035B60 add #12,r7
    st8(c.r[7], c.r[2]);  // 06035B62 mov.b r2,@r7
    c.r[1] = c.r[5];  // 06035B64 mov r5,r1
    c.r[2] = ld32(c.r[6]);  // 06035B66 mov.l @r6,r2
    c.r[1] += 14;  // 06035B68 add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035B6A mov.w @r1,r1
    c.r[3] = c.r[2];  // 06035B6C mov r2,r3
    c.r[3] += 14;  // 06035B6E add #14,r3
    st16(c.r[3], c.r[1]);  // 06035B70 mov.w r1,@r3
    c.r[1] = c.r[5];  // 06035B72 mov r5,r1
    c.r[1] += 16;  // 06035B74 add #16,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035B76 mov.b @r1,r0
    c.r[2] += 16;  // 06035B78 add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035C52u);  // 06035B7A mov.w 0x06035C52,r1
    c.r[1] &= c.r[0];  // 06035B7C and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06035B7E mov.b @r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035C54u);  // 06035B80 mov.w 0x06035C54,r3
    c.r[0] &= 0x1u;  // 06035B82 and #1,r0
    c.r[0] |= c.r[1];  // 06035B84 or r1,r0
    st8(c.r[2], c.r[0]);  // 06035B86 mov.b r0,@r2
    c.r[4] = ld32(c.r[5] + 16);  // 06035B88 mov.l @(16,r5),r4
    c.r[1] = ld32(0x06035C64u);  // 06035B8A mov.l 0x06035C64,r1
    c.r[7] = ld32(c.r[6]);  // 06035B8C mov.l @r6,r7
    c.r[4] >>= 8;  // 06035B8E shlr8 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 06035B90 shlr r4
    c.r[4] >>= 2;  // 06035B92 shlr2 r4
    c.r[4] &= c.r[3];  // 06035B94 and r3,r4
    c.r[4] <<= 8;  // 06035B96 shll8 r4
    c.r[4] += c.r[4];  // 06035B98 add r4,r4
    c.r[4] <<= 2;  // 06035B9A shll2 r4
    c.r[2] = ld32(c.r[7] + 16);  // 06035B9C mov.l @(16,r7),r2
    c.r[5] += 18;  // 06035B9E add #18,r5
    c.r[2] &= c.r[1];  // 06035BA0 and r1,r2
    c.r[2] |= c.r[4];  // 06035BA2 or r4,r2
    st32(c.r[7] + 16, c.r[2]);  // 06035BA4 mov.l r2,@(16,r7)
    c.r[1] = ld32(0x06035C68u);  // 06035BA6 mov.l 0x06035C68,r1
    c.r[2] >>= 8;  // 06035BA8 shlr8 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06035BAA shlr r2
    c.r[2] >>= 2;  // 06035BAC shlr2 r2
    c.r[2] &= c.r[3];  // 06035BAE and r3,r2
    st32(c.r[1] + 12, c.r[2]);  // 06035BB0 mov.l r2,@(12,r1)
    c.r[7] += 18;  // 06035BB2 add #18,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035C56u);  // 06035BB4 mov.w 0x06035C56,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 06035BB6 mov.w @r5,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035C58u);  // 06035BB8 mov.w 0x06035C58,r2
    c.r[3] &= c.r[1];  // 06035BBA and r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06035BBC mov.w @r7,r1
    c.r[4] = 0x0u;  // 06035BBE mov #0,r4
    c.r[1] &= c.r[2];  // 06035BC0 and r2,r1
    c.r[1] |= c.r[3];  // 06035BC2 or r3,r1
    st16(c.r[7], c.r[1]);  // 06035BC4 mov.w r1,@r7
L_06035BC6:
    c.r[6] = c.r[4];  // 06035BC6 mov r4,r6
    c.r[6] <<= 2;  // 06035BC8 shll2 r6
    c.r[10] = ld32(0x06035C60u);  // 06035BCA mov.l 0x06035C60,r10
    c.r[7] = c.r[6];  // 06035BCC mov r6,r7
    c.r[7] += c.r[10];  // 06035BCE add r10,r7
    c.r[5] = c.r[7];  // 06035BD0 mov r7,r5
    c.r[5] += 22;  // 06035BD2 add #22,r5
    c.r[2] = 0x1Fu;  // 06035BD4 mov #31,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035C5Au);  // 06035BD6 mov.w 0x06035C5A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06035BD8 mov.b @r5,r1
    c.r[4] += 1;  // 06035BDA add #1,r4
    c.r[3] = ld32(c.r[9]);  // 06035BDC mov.l @r9,r3
    c.r[2] &= c.r[1];  // 06035BDE and r1,r2
    c.r[2] <<= 2;  // 06035BE0 shll2 r2
    c.r[2] += c.r[2];  // 06035BE2 add r2,r2
    c.r[2] <<= 2;  // 06035BE4 shll2 r2
    c.r[1] = c.r[7];  // 06035BE6 mov r7,r1
    c.r[1] += 23;  // 06035BE8 add #23,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035BEA mov.b @r1,r1
    c.r[3] += c.r[6];  // 06035BEC add r6,r3
    c.r[8] = c.r[1] & 0xFFu;  // 06035BEE extu.b r1,r8
    c.r[8] >>= 2;  // 06035BF0 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06035BF2 shlr r8
    c.r[8] |= c.r[2];  // 06035BF4 or r2,r8
    c.r[2] = c.r[8];  // 06035BF6 mov r8,r2
    c.r[2] >>= 2;  // 06035BF8 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06035BFA shlr r2
    c.r[2] >>= 2;  // 06035BFC shlr2 r2
    c.r[1] = c.r[3];  // 06035BFE mov r3,r1
    c.r[1] += 22;  // 06035C00 add #22,r1
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035C02 mov.b @r1,r12
    c.r[3] += 23;  // 06035C04 add #23,r3
    c.r[12] &= c.r[0];  // 06035C06 and r0,r12
    c.r[12] |= c.r[2];  // 06035C08 or r2,r12
    st8(c.r[1], c.r[12]);  // 06035C0A mov.b r12,@r1
    c.r[0] = 0x1Fu;  // 06035C0C mov #31,r0
    c.r[8] &= c.r[0];  // 06035C0E and r0,r8
    c.r[8] <<= 2;  // 06035C10 shll2 r8
    c.r[8] += c.r[8];  // 06035C12 add r8,r8
    c.r[0] = 0x7u;  // 06035C14 mov #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06035C16 mov.b @r3,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[11];  // 06035C18 cmp/gt r11,r4
    c.r[1] &= c.r[0];  // 06035C1A and r0,r1
    c.r[1] |= c.r[8];  // 06035C1C or r8,r1
    st8(c.r[3], c.r[1]);  // 06035C1E mov.b r1,@r3
    c.r[1] = c.r[7];  // 06035C20 mov r7,r1
    c.r[2] = ld32(c.r[9]);  // 06035C22 mov.l @r9,r2
    c.r[1] += 20;  // 06035C24 add #20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035C26 mov.b @r1,r1
    c.r[2] += c.r[6];  // 06035C28 add r6,r2
    c.r[2] += 20;  // 06035C2A add #20,r2
    st8(c.r[2], c.r[1]);  // 06035C2C mov.b r1,@r2
    c.r[2] = ld32(c.r[9]);  // 06035C2E mov.l @r9,r2
    c.r[7] += 21;  // 06035C30 add #21,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06035C32 mov.b @r7,r1
    c.r[2] += c.r[6];  // 06035C34 add r6,r2
    c.r[2] += 21;  // 06035C36 add #21,r2
    st8(c.r[2], c.r[1]);  // 06035C38 mov.b r1,@r2
    c.r[1] = ld32(c.r[9]);  // 06035C3A mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035C4Eu);  // 06035C3C mov.w 0x06035C4E,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06035C3E mov.b @r5,r2
    c.r[1] += c.r[6];  // 06035C40 add r6,r1
    c.r[1] += 22;  // 06035C42 add #22,r1
    c.r[2] &= c.r[0];  // 06035C44 and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035C46 mov.b @r1,r3
    c.r[0] = 0x3Fu;  // 06035C48 mov #63,r0
    c.r[3] &= c.r[0]; goto L_06035C6C;  // 06035C4A bra 0x06035C6C ; and r0,r3
L_06035C6C:
    c.r[3] |= c.r[2];  // 06035C6C or r2,r3
    st8(c.r[1], c.r[3]);  // 06035C6E mov.b r3,@r1
    c.r[1] = ld32(c.r[9]);  // 06035C70 mov.l @r9,r1
    c.r[0] = 0x20u;  // 06035C72 mov #32,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06035C74 mov.b @r5,r2
    c.r[1] += c.r[6];  // 06035C76 add r6,r1
    c.r[1] += 22;  // 06035C78 add #22,r1
    c.r[2] &= c.r[0];  // 06035C7A and r0,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035C7C mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035E1Au);  // 06035C7E mov.w 0x06035E1A,r0
    c.r[3] &= c.r[0];  // 06035C80 and r0,r3
    c.r[3] |= c.r[2];  // 06035C82 or r2,r3
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_06035BC6; } }  // 06035C84 bf/s 0x06035BC6 ; mov.b r3,@r1
    c.r[4] = ld32(0x06035E58u);  // 06035C88 mov.l 0x06035E58,r4
    c.r[8] = ld32(0x06035E5Cu);  // 06035C8A mov.l 0x06035E5C,r8
    c.r[1] = ld32(0x06035E60u);  // 06035C8C mov.l 0x06035E60,r1
    c.r[5] = ld32(c.r[8]);  // 06035C8E mov.l @r8,r5
    c.r[6] = 0x14u;  // 06035C90 mov #20,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06035C96u; c.r[5] += 20; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06035C96u) return; }  // 06035C92 jsr @r1 ; add #20,r5
    c.r[4] = 0x0u;  // 06035C96 mov #0,r4
    c.r[3] = 0x2u;  // 06035C98 mov #2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035E1Cu);  // 06035C9A mov.w 0x06035E1C,r7
    c.r[2] = c.r[10];  // 06035C9C mov r10,r2
    c.r[8] = ld32(c.r[8]);  // 06035C9E mov.l @r8,r8
L_06035CA0:
    c.r[1] = c.r[2];  // 06035CA0 mov r2,r1
    c.r[1] += 40;  // 06035CA2 add #40,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06035CA4 mov.w @r1,r1
    c.r[0] = c.r[8];  // 06035CA6 mov r8,r0
    c.r[2] += 2;  // 06035CA8 add #2,r2
    c.r[8] += 2;  // 06035CAA add #2,r8
    c.r[4] += 1;  // 06035CAC add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[3];  // 06035CAE cmp/gt r3,r4
    { const bool k = !c.t; st16(c.r[0] + c.r[7], c.r[1]); if (k) { SH2_POLL(c); goto L_06035CA0; } }  // 06035CB0 bf/s 0x06035CA0 ; mov.w r1,@(r0,r7)
    c.r[4] = 0x0u;  // 06035CB4 mov #0,r4
    c.r[6] = 0x5u;  // 06035CB6 mov #5,r6
    c.r[7] = ld32(0x06035E5Cu);  // 06035CB8 mov.l 0x06035E5C,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06035E1Eu);  // 06035CBA mov.w 0x06035E1E,r5
    c.r[3] = ld32(0x06035E64u);  // 06035CBC mov.l 0x06035E64,r3
L_06035CBE:
    c.r[1] = c.r[4];  // 06035CBE mov r4,r1
    c.r[1] += c.r[3];  // 06035CC0 add r3,r1
    c.r[2] = ld32(c.r[7]);  // 06035CC2 mov.l @r7,r2
    c.r[1] += 46;  // 06035CC4 add #46,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06035CC6 mov.b @r1,r1
    c.r[2] += c.r[4];  // 06035CC8 add r4,r2
    c.r[0] = c.r[2];  // 06035CCA mov r2,r0
    c.r[4] += 1;  // 06035CCC add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[6];  // 06035CCE cmp/gt r6,r4
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { SH2_POLL(c); goto L_06035CBE; } }  // 06035CD0 bf/s 0x06035CBE ; mov.b r1,@(r0,r5)
    c.r[5] = ld32(0x06035E5Cu);  // 06035CD4 mov.l 0x06035E5C,r5
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035E20u);  // 06035CD6 mov.w 0x06035E20,r2
    c.r[3] = ld32(0x06035E68u);  // 06035CD8 mov.l 0x06035E68,r3
    c.r[4] = 0x0u;  // 06035CDA mov #0,r4
    c.r[10] = 0x9u;  // 06035CDC mov #9,r10
    c.r[7] = ld32(c.r[5]);  // 06035CDE mov.l @r5,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x06035E22u);  // 06035CE0 mov.w 0x06035E22,r9
    c.r[1] = ld32(c.r[3]);  // 06035CE2 mov.l @r3,r1
    c.r[0] = c.r[7];  // 06035CE4 mov r7,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 06035CE6 mov.l r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035E24u);  // 06035CE8 mov.w 0x06035E24,r2
    c.r[1] = ld32(c.r[3] + 4);  // 06035CEA mov.l @(4,r3),r1
    c.r[6] = c.r[7];  // 06035CEC mov r7,r6
    st32(c.r[0] + c.r[2], c.r[1]);  // 06035CEE mov.l r1,@(r0,r2)
    c.r[1] = ld32(c.r[3] + 8);  // 06035CF0 mov.l @(8,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035E26u);  // 06035CF2 mov.w 0x06035E26,r2
    st32(c.r[0] + c.r[2], c.r[1]);  // 06035CF4 mov.l r1,@(r0,r2)
    c.r[1] = ld32(c.r[3] + 12);  // 06035CF6 mov.l @(12,r3),r1
    c.r[6] += c.r[2];  // 06035CF8 add r2,r6
    st32(c.r[6] + 4, c.r[1]);  // 06035CFA mov.l r1,@(4,r6)
    c.r[1] = ld32(c.r[3] + 16);  // 06035CFC mov.l @(16,r3),r1
    c.r[6] += 8;  // 06035CFE add #8,r6
    st32(c.r[6], c.r[1]);  // 06035D00 mov.l r1,@r6
    c.r[1] = ld32(c.r[3] + 20);  // 06035D02 mov.l @(20,r3),r1
    c.r[6] += 4;  // 06035D04 add #4,r6
    st32(c.r[6], c.r[1]);  // 06035D06 mov.l r1,@r6
    c.r[1] = ld32(c.r[3] + 24);  // 06035D08 mov.l @(24,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06035E28u);  // 06035D0A mov.w 0x06035E28,r2
    st32(c.r[6] + 4, c.r[1]);  // 06035D0C mov.l r1,@(4,r6)
    c.r[1] = ld32(c.r[3] + 28);  // 06035D0E mov.l @(28,r3),r1
    c.r[6] = c.r[7];  // 06035D10 mov r7,r6
    st32(c.r[0] + c.r[2], c.r[1]);  // 06035D12 mov.l r1,@(r0,r2)
    c.r[1] = ld32(c.r[3] + 32);  // 06035D14 mov.l @(32,r3),r1
    c.r[6] += c.r[2];  // 06035D16 add r2,r6
    st32(c.r[6] + 4, c.r[1]);  // 06035D18 mov.l r1,@(4,r6)
    c.r[1] = ld32(c.r[3] + 36);  // 06035D1A mov.l @(36,r3),r1
    c.r[6] += 8;  // 06035D1C add #8,r6
    st32(c.r[6], c.r[1]);  // 06035D1E mov.l r1,@r6
    c.r[1] = ld32(c.r[3] + 40);  // 06035D20 mov.l @(40,r3),r1
    c.r[6] += 4;  // 06035D22 add #4,r6
    st32(c.r[6], c.r[1]);  // 06035D24 mov.l r1,@r6
    c.r[1] = ld32(c.r[3] + 44);  // 06035D26 mov.l @(44,r3),r1
    c.r[8] = 0x0u;  // 06035D28 mov #0,r8
    st32(c.r[6] + 4, c.r[1]);  // 06035D2A mov.l r1,@(4,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E2Au);  // 06035D2C mov.w 0x06035E2A,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035D2E mov.b @(r0,r1),r1
    c.r[2] = 0x1u;  // 06035D30 mov #1,r2
    c.r[2] &= c.r[1];  // 06035D32 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E2Cu);  // 06035D34 mov.w 0x06035E2C,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035D36 mov.b @(r0,r1),r6
    c.r[3] -= 52;  // 06035D38 add #-52,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035E2Eu);  // 06035D3A mov.w 0x06035E2E,r0
    c.r[6] &= c.r[0];  // 06035D3C and r0,r6
    c.r[6] |= c.r[2];  // 06035D3E or r2,r6
    c.r[0] = c.r[7];  // 06035D40 mov r7,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06035D42 mov.b r6,@(r0,r1)
L_06035D44:
    c.r[11] = 0x0u;  // 06035D44 mov #0,r11
    c.r[6] = c.r[8];  // 06035D46 mov r8,r6
    c.r[7] = c.r[3];  // 06035D48 mov r3,r7
    c.r[7] += 100;  // 06035D4A add #100,r7
L_06035D4C:
    c.r[2] = ld32(c.r[5]);  // 06035D4C mov.l @r5,r2
    c.r[0] = c.r[7];  // 06035D4E mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06035D50 mov.b @(r0,r11),r1
    c.r[2] += c.r[6];  // 06035D52 add r6,r2
    c.r[2] += c.r[9];  // 06035D54 add r9,r2
    c.r[0] = c.r[2];  // 06035D56 mov r2,r0
    st8(c.r[0] + c.r[11], c.r[1]);  // 06035D58 mov.b r1,@(r0,r11)
    c.r[11] += 1;  // 06035D5A add #1,r11
    c.t = (int32_t)c.r[11] > (int32_t)c.r[10];  // 06035D5C cmp/gt r10,r11
    if (!c.t) { SH2_POLL(c); goto L_06035D4C; }  // 06035D5E bf 0x06035D4C
    c.r[3] += 10;  // 06035D60 add #10,r3
    c.r[4] += 1;  // 06035D62 add #1,r4
    c.r[1] = 0x2u;  // 06035D64 mov #2,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 06035D66 cmp/gt r1,r4
    { const bool k = !c.t; c.r[8] += 10; if (k) { SH2_POLL(c); goto L_06035D44; } }  // 06035D68 bf/s 0x06035D44 ; add #10,r8
    c.r[7] = ld32(0x06035E5Cu);  // 06035D6C mov.l 0x06035E5C,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E30u);  // 06035D6E mov.w 0x06035E30,r6
    c.r[2] = ld32(0x06035E64u);  // 06035D70 mov.l 0x06035E64,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E32u);  // 06035D72 mov.w 0x06035E32,r1
    c.r[0] = c.r[2];  // 06035D74 mov r2,r0
    c.r[4] = 0x0u;  // 06035D76 mov #0,r4
    c.r[3] = ld32(c.r[7]);  // 06035D78 mov.l @r7,r3
    c.r[8] = 0x3Fu;  // 06035D7A mov #63,r8
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035D7C mov.l @(r0,r1),r1
    c.r[5] = c.r[2];  // 06035D7E mov r2,r5
    c.r[0] = c.r[3];  // 06035D80 mov r3,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 06035D82 mov.l r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E34u);  // 06035D84 mov.w 0x06035E34,r1
    c.r[0] = c.r[2];  // 06035D86 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035D88 mov.l @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E36u);  // 06035D8A mov.w 0x06035E36,r6
    c.r[0] = c.r[3];  // 06035D8C mov r3,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 06035D8E mov.l r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E38u);  // 06035D90 mov.w 0x06035E38,r1
    c.r[0] = c.r[2];  // 06035D92 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035D94 mov.l @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E3Au);  // 06035D96 mov.w 0x06035E3A,r6
    c.r[0] = c.r[3];  // 06035D98 mov r3,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 06035D9A mov.l r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E3Cu);  // 06035D9C mov.w 0x06035E3C,r1
    c.r[0] = c.r[2];  // 06035D9E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035DA0 mov.b @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E3Eu);  // 06035DA2 mov.w 0x06035E3E,r6
    c.r[0] = c.r[3];  // 06035DA4 mov r3,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06035DA6 mov.b r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E40u);  // 06035DA8 mov.w 0x06035E40,r1
    c.r[3] = ld32(c.r[7]);  // 06035DAA mov.l @r7,r3
    c.r[0] = c.r[2];  // 06035DAC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035DAE mov.b @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E42u);  // 06035DB0 mov.w 0x06035E42,r6
    c.r[0] = c.r[3];  // 06035DB2 mov r3,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06035DB4 mov.b r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E44u);  // 06035DB6 mov.w 0x06035E44,r1
    c.r[3] = ld32(c.r[7]);  // 06035DB8 mov.l @r7,r3
    c.r[0] = c.r[2];  // 06035DBA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035DBC mov.b @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E46u);  // 06035DBE mov.w 0x06035E46,r6
    c.r[0] = c.r[3];  // 06035DC0 mov r3,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06035DC2 mov.b r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E48u);  // 06035DC4 mov.w 0x06035E48,r1
    c.r[3] = ld32(c.r[7]);  // 06035DC6 mov.l @r7,r3
    c.r[0] = c.r[2];  // 06035DC8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035DCA mov.b @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E4Au);  // 06035DCC mov.w 0x06035E4A,r6
    c.r[0] = c.r[3];  // 06035DCE mov r3,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 06035DD0 mov.b r1,@(r0,r6)
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E4Cu);  // 06035DD2 mov.w 0x06035E4C,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035E4Eu);  // 06035DD4 mov.w 0x06035E4E,r3
L_06035DD6:
    c.r[1] = c.r[4];  // 06035DD6 mov r4,r1
    c.r[1] += c.r[5];  // 06035DD8 add r5,r1
    c.r[2] = ld32(c.r[7]);  // 06035DDA mov.l @r7,r2
    c.r[0] = c.r[1];  // 06035DDC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06035DDE mov.b @(r0,r3),r1
    c.r[2] += c.r[4];  // 06035DE0 add r4,r2
    c.r[0] = c.r[2];  // 06035DE2 mov r2,r0
    c.r[4] += 1;  // 06035DE4 add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[8];  // 06035DE6 cmp/gt r8,r4
    { const bool k = !c.t; st8(c.r[0] + c.r[6], c.r[1]); if (k) { SH2_POLL(c); goto L_06035DD6; } }  // 06035DE8 bf/s 0x06035DD6 ; mov.b r1,@(r0,r6)
    c.r[4] = 0x0u;  // 06035DEC mov #0,r4
    c.r[8] = 0x1Du;  // 06035DEE mov #29,r8
    c.r[5] = ld32(0x06035E5Cu);  // 06035DF0 mov.l 0x06035E5C,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035E50u);  // 06035DF2 mov.w 0x06035E50,r7
    c.r[6] = ld32(0x06035E64u);  // 06035DF4 mov.l 0x06035E64,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035E52u);  // 06035DF6 mov.w 0x06035E52,r3
L_06035DF8:
    c.r[1] = c.r[4];  // 06035DF8 mov r4,r1
    c.r[1] += c.r[6];  // 06035DFA add r6,r1
    c.r[2] = ld32(c.r[5]);  // 06035DFC mov.l @r5,r2
    c.r[0] = c.r[1];  // 06035DFE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06035E00 mov.b @(r0,r3),r1
    c.r[2] += c.r[4];  // 06035E02 add r4,r2
    c.r[0] = c.r[2];  // 06035E04 mov r2,r0
    c.r[4] += 1;  // 06035E06 add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[8];  // 06035E08 cmp/gt r8,r4
    { const bool k = !c.t; st8(c.r[0] + c.r[7], c.r[1]); if (k) { SH2_POLL(c); goto L_06035DF8; } }  // 06035E0A bf/s 0x06035DF8 ; mov.b r1,@(r0,r7)
    c.r[7] = ld32(0x06035E5Cu);  // 06035E0E mov.l 0x06035E5C,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035E54u);  // 06035E10 mov.w 0x06035E54,r6
    c.r[3] = ld32(0x06035E64u);  // 06035E12 mov.l 0x06035E64,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035E56u);  // 06035E14 mov.w 0x06035E56,r1
    c.r[2] = ld32(c.r[7]); goto L_06035E6C;  // 06035E16 bra 0x06035E6C ; mov.l @r7,r2
L_06035E6C:
    c.r[0] = c.r[3];  // 06035E6C mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035E6E mov.l @(r0,r1),r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06035EEAu);  // 06035E70 mov.w 0x06035EEA,r5
    c.r[0] = c.r[2];  // 06035E72 mov r2,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 06035E74 mov.l r1,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035EECu);  // 06035E76 mov.w 0x06035EEC,r1
    c.r[0] = c.r[3];  // 06035E78 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06035E7A mov.l @(r0,r1),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035EEEu);  // 06035E7C mov.w 0x06035EEE,r6
    c.r[0] = c.r[2];  // 06035E7E mov r2,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 06035E80 mov.l r1,@(r0,r6)
    c.r[0] = c.r[3];  // 06035E82 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06035E84 mov.b @(r0,r5),r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035EF0u);  // 06035E86 mov.w 0x06035EF0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035EF2u);  // 06035E88 mov.w 0x06035EF2,r0
    c.r[1] &= c.r[0];  // 06035E8A and r0,r1
    c.r[0] = c.r[2];  // 06035E8C mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06035E8E mov.b @(r0,r6),r4
    c.r[0] = 0x3Fu;  // 06035E90 mov #63,r0
    c.r[4] &= c.r[0];  // 06035E92 and r0,r4
    c.r[4] |= c.r[1];  // 06035E94 or r1,r4
    c.r[0] = c.r[2];  // 06035E96 mov r2,r0
    st8(c.r[0] + c.r[6], c.r[4]);  // 06035E98 mov.b r4,@(r0,r6)
    c.r[0] = c.r[3];  // 06035E9A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06035E9C mov.b @(r0,r5),r2
    c.r[1] = ld32(c.r[7]);  // 06035E9E mov.l @r7,r1
    c.r[0] = 0x30u;  // 06035EA0 mov #48,r0
    c.r[2] &= c.r[0];  // 06035EA2 and r0,r2
    c.r[0] = c.r[1];  // 06035EA4 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06035EA6 mov.b @(r0,r6),r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035EF4u);  // 06035EA8 mov.w 0x06035EF4,r0
    c.r[4] &= c.r[0];  // 06035EAA and r0,r4
    c.r[4] |= c.r[2];  // 06035EAC or r2,r4
    c.r[0] = c.r[1];  // 06035EAE mov r1,r0
    st8(c.r[0] + c.r[6], c.r[4]);  // 06035EB0 mov.b r4,@(r0,r6)
    c.r[0] = c.r[3];  // 06035EB2 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06035EB4 mov.b @(r0,r5),r2
    c.r[1] = ld32(c.r[7]);  // 06035EB6 mov.l @r7,r1
    c.r[0] = 0x8u;  // 06035EB8 mov #8,r0
    c.r[2] &= c.r[0];  // 06035EBA and r0,r2
    c.r[0] = c.r[1];  // 06035EBC mov r1,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06035EBE mov.b @(r0,r6),r5
    c.r[15] = c.r[14];  // 06035EC0 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06035EF6u);  // 06035EC2 mov.w 0x06035EF6,r0
    c.r[5] &= c.r[0];  // 06035EC4 and r0,r5
    c.r[5] |= c.r[2];  // 06035EC6 or r2,r5
    c.r[0] = c.r[1];  // 06035EC8 mov r1,r0
    st8(c.r[0] + c.r[6], c.r[5]);  // 06035ECA mov.b r5,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06035EF8u);  // 06035ECC mov.w 0x06035EF8,r1
    c.r[2] = ld32(c.r[7]);  // 06035ECE mov.l @r7,r2
    c.r[0] = c.r[3];  // 06035ED0 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06035ED2 mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035EFAu);  // 06035ED4 mov.w 0x06035EFA,r7
    c.r[0] = c.r[2];  // 06035ED6 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06035ED8 mov.b r1,@(r0,r7)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06035EDA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06035EDC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06035EDE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06035EE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06035EE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06035EE4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06035EE6 rts ; mov.l @r15+,r8
}

void f_06035EFC(SH2Context& c) {
    ran[776] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06035EFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06035EFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06035F00 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06035F02 mov r15,r14
    c.r[3] = 0x0u;  // 06035F04 mov #0,r3
    c.r[4] = 0x7Fu;  // 06035F06 mov #127,r4
    c.r[5] = ld32(0x06035F40u);  // 06035F08 mov.l 0x06035F40,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035F3Cu);  // 06035F0A mov.w 0x06035F3C,r7
    c.r[6] = ld32(0x06035F44u);  // 06035F0C mov.l 0x06035F44,r6
L_06035F0E:
    c.r[8] = c.r[3];  // 06035F0E mov r3,r8
    c.r[8] += c.r[5];  // 06035F10 add r5,r8
    c.r[0] = c.r[8];  // 06035F12 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06035F14 mov.b @(r0,r7),r1
    c.r[0] = c.r[3];  // 06035F16 mov r3,r0
    c.r[3] += 1;  // 06035F18 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06035F1A mov.b @(r0,r6),r2
    c.t = (int32_t)c.r[3] > (int32_t)c.r[4];  // 06035F1C cmp/gt r4,r3
    c.r[1] |= c.r[2];  // 06035F1E or r2,r1
    c.r[0] = c.r[8];  // 06035F20 mov r8,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[7], c.r[1]); if (k) { SH2_POLL(c); goto L_06035F0E; } }  // 06035F22 bf/s 0x06035F0E ; mov.b r1,@(r0,r7)
    c.r[4] = ld32(0x06035F44u);  // 06035F26 mov.l 0x06035F44,r4
    c.r[5] = ld32(0x06035F48u);  // 06035F28 mov.l 0x06035F48,r5
    c.r[1] = ld32(0x06035F4Cu);  // 06035F2A mov.l 0x06035F4C,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035F3Eu);  // 06035F2C mov.w 0x06035F3E,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06035F32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06035F32u) return; }  // 06035F2E jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06035F32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06035F34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06035F36 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06035F38 rts ; mov.l @r15+,r8
}

void f_06035F50(SH2Context& c) {
    ran[777] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06035F50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06035F52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06035F54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06035F56 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06035F58 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06035F5A mov r15,r14
    c.r[2] = ld32(0x06035FF0u);  // 06035F5C mov.l 0x06035FF0,r2
    c.r[1] = ld32(0x06035FF4u);  // 06035F5E mov.l 0x06035FF4,r1
    c.r[9] = ld32(0x06035FF8u);  // 06035F60 mov.l 0x06035FF8,r9
    c.r[0] = ld32(0x06035FFCu);  // 06035F62 mov.l 0x06035FFC,r0
    c.r[6] = 0x0u;  // 06035F64 mov #0,r6
    c.r[10] = ld32(c.r[2]);  // 06035F66 mov.l @r2,r10
    c.r[5] = ld32(0x06036000u);  // 06035F68 mov.l 0x06036000,r5
    c.r[1] = ld32(c.r[1]);  // 06035F6A mov.l @r1,r1
    c.r[4] = ld32(0x06036004u);  // 06035F6C mov.l 0x06036004,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06035F72u; st32(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06035F72u) return; }  // 06035F6E jsr @r0 ; mov.l r1,@r2
    c.r[4] = ld32(0x06036004u);  // 06035F72 mov.l 0x06036004,r4
    c.r[0] = ld32(0x06036008u);  // 06035F74 mov.l 0x06036008,r0
    c.r[6] = 0x1u;  // 06035F76 mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06035F7Cu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06035F7Cu) return; }  // 06035F78 jsr @r0 ; mov r9,r5
    c.r[8] = c.r[0];  // 06035F7C mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06035F7E tst r8,r8
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_06035FD4; } }  // 06035F80 bf/s 0x06035FD4 ; mov #0,r2
    c.r[7] = 0x4u;  // 06035F84 mov #4,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x06035FE8u);  // 06035F86 mov.w 0x06035FE8,r3
    c.r[0] = c.r[9];  // 06035F88 mov r9,r0
L_06035F8A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06035F8A mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06035F8C extu.b r1,r1
    c.r[7] += 1;  // 06035F8E add #1,r7
    c.t = c.r[7] >= c.r[3];  // 06035F90 cmp/hs r3,r7
    { const bool k = !c.t; c.r[2] += c.r[1]; if (k) { SH2_POLL(c); goto L_06035F8A; } }  // 06035F92 bf/s 0x06035F8A ; add r1,r2
    c.r[7] = ld32(0x06035FF8u);  // 06035F96 mov.l 0x06035FF8,r7
    c.r[1] = ld32(c.r[7]);  // 06035F98 mov.l @r7,r1
    c.t = c.r[1] == c.r[2];  // 06035F9A cmp/eq r2,r1
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06035FA4; } }  // 06035F9C bf/s 0x06035FA4 ; tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06035FA8; } }  // 06035FA0 bf/s 0x06035FA8 ; mov #0,r3
L_06035FA4:
    c.r[8] = 0xFFFFFFFEu; goto L_06035FD4;  // 06035FA4 bra 0x06035FD4 ; mov #-2,r8
L_06035FA8:
    c.r[4] = 0x7Fu;  // 06035FA8 mov #127,r4
    c.r[5] = c.r[7];  // 06035FAA mov r7,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x06035FEAu);  // 06035FAC mov.w 0x06035FEA,r7
    c.r[6] = ld32(0x0603600Cu);  // 06035FAE mov.l 0x0603600C,r6
L_06035FB0:
    c.r[9] = c.r[3];  // 06035FB0 mov r3,r9
    c.r[9] += c.r[5];  // 06035FB2 add r5,r9
    c.r[0] = c.r[9];  // 06035FB4 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06035FB6 mov.b @(r0,r7),r1
    c.r[0] = c.r[3];  // 06035FB8 mov r3,r0
    c.r[3] += 1;  // 06035FBA add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06035FBC mov.b @(r0,r6),r2
    c.t = (int32_t)c.r[3] > (int32_t)c.r[4];  // 06035FBE cmp/gt r4,r3
    c.r[1] |= c.r[2];  // 06035FC0 or r2,r1
    c.r[0] = c.r[9];  // 06035FC2 mov r9,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[7], c.r[1]); if (k) { SH2_POLL(c); goto L_06035FB0; } }  // 06035FC4 bf/s 0x06035FB0 ; mov.b r1,@(r0,r7)
    c.r[1] = ld32(0x06036010u);  // 06035FC8 mov.l 0x06036010,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06035FECu);  // 06035FCA mov.w 0x06035FEC,r6
    c.r[5] = ld32(0x06036014u);  // 06035FCC mov.l 0x06036014,r5
    c.r[4] = ld32(0x0603600Cu);  // 06035FCE mov.l 0x0603600C,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06035FD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06035FD4u) return; }  // 06035FD0 jsr @r1 ; nop
L_06035FD4:
    c.r[1] = ld32(0x06035FF0u);  // 06035FD4 mov.l 0x06035FF0,r1
    st32(c.r[1], c.r[10]);  // 06035FD6 mov.l r10,@r1
    c.r[15] = c.r[14];  // 06035FD8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06035FDA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06035FDC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06035FDE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06035FE0 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06035FE2 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06035FE4 rts ; mov.l @r15+,r8
}

void f_06036018(SH2Context& c) {
    ran[778] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036018 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603601A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603601C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603601E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06036020 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036022 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036024 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06036026 mov r15,r14
    c.r[10] = (uint32_t)(int16_t)ld16(0x060361E2u);  // 06036028 mov.w 0x060361E2,r10
    c.r[9] = ld32(0x060361F4u);  // 0603602A mov.l 0x060361F4,r9
    c.r[8] = ld32(0x060361F8u);  // 0603602C mov.l 0x060361F8,r8
    c.r[5] = 0xCu;  // 0603602E mov #12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06036034u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036034u) return; }  // 06036030 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 06036034 mov r0,r1
    c.r[5] = c.r[10];  // 06036036 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0603603Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603603Cu) return; }  // 06036038 jsr @r8 ; mov r1,r4
    c.r[7] = c.r[0];  // 0603603C mov r0,r7
    c.r[11] = ld32(0x060361FCu);  // 0603603E mov.l 0x060361FC,r11
    c.r[2] = (uint32_t)(int16_t)ld16(0x060361E4u);  // 06036040 mov.w 0x060361E4,r2
    c.r[5] = 0xDu;  // 06036042 mov #13,r5
    c.r[3] = ld32(c.r[11]);  // 06036044 mov.l @r11,r3
    c.r[4] = c.r[9];  // 06036046 mov r9,r4
    c.r[1] = c.r[3];  // 06036048 mov r3,r1
    c.r[1] += c.r[2];  // 0603604A add r2,r1
    c.r[0] = c.r[3];  // 0603604C mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603604E mov.b @(r0,r2),r2
    c.r[1] += 1;  // 06036050 add #1,r1
    st8(c.r[7], c.r[2]);  // 06036052 mov.b r2,@r7
    c.r[2] = c.r[7];  // 06036054 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036056 mov.b @r1+,r3
    c.r[2] += 1;  // 06036058 add #1,r2
    st8(c.r[2], c.r[3]);  // 0603605A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603605C mov.b @r1+,r3
    c.r[2] += 1;  // 0603605E add #1,r2
    st8(c.r[2], c.r[3]);  // 06036060 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036062 mov.b @r1+,r3
    c.r[2] += 1;  // 06036064 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036066 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036068 mov.b @r1+,r3
    c.r[2] += 1;  // 0603606A add #1,r2
    st8(c.r[2], c.r[3]);  // 0603606C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603606E mov.b @r1+,r3
    c.r[2] += 1;  // 06036070 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036072 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036074 mov.b @r1+,r3
    c.r[2] += 1;  // 06036076 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036078 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603607A mov.b @r1+,r3
    c.r[2] += 1;  // 0603607C add #1,r2
    st8(c.r[2], c.r[3]);  // 0603607E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036080 mov.b @r1+,r3
    c.r[2] += 1;  // 06036082 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036084 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036086 mov.b @r1+,r3
    c.r[2] += 1;  // 06036088 add #1,r2
    st8(c.r[2], c.r[3]);  // 0603608A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603608C mov.b @r1+,r3
    c.r[2] += 1;  // 0603608E add #1,r2
    st8(c.r[2], c.r[3]);  // 06036090 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036092 mov.b @r1+,r3
    c.r[2] += 1;  // 06036094 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036096 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036098 mov.b @r1+,r3
    c.r[2] += 1;  // 0603609A add #1,r2
    st8(c.r[2], c.r[3]);  // 0603609C mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603609E mov.b @r1,r1
    c.r[2] += 1;  // 060360A0 add #1,r2
    { const uint32_t x = c.r[8]; c.pr = 0x060360A6u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060360A6u) return; }  // 060360A2 jsr @r8 ; mov.b r1,@r2
    c.r[1] = c.r[0];  // 060360A6 mov r0,r1
    c.r[5] = c.r[10];  // 060360A8 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060360AEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060360AEu) return; }  // 060360AA jsr @r8 ; mov r1,r4
    c.r[7] = c.r[0];  // 060360AE mov r0,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x060361E6u);  // 060360B0 mov.w 0x060361E6,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x060361E8u);  // 060360B2 mov.w 0x060361E8,r10
    c.r[5] = 0xCu;  // 060360B4 mov #12,r5
    c.r[3] = ld32(c.r[11]);  // 060360B6 mov.l @r11,r3
    c.r[4] = c.r[9];  // 060360B8 mov r9,r4
    c.r[1] = c.r[3];  // 060360BA mov r3,r1
    c.r[1] += c.r[2];  // 060360BC add r2,r1
    c.r[0] = c.r[3];  // 060360BE mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060360C0 mov.b @(r0,r2),r2
    c.r[1] += 1;  // 060360C2 add #1,r1
    st8(c.r[7], c.r[2]);  // 060360C4 mov.b r2,@r7
    c.r[2] = c.r[7];  // 060360C6 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060360C8 mov.b @r1+,r3
    c.r[2] += 1;  // 060360CA add #1,r2
    st8(c.r[2], c.r[3]);  // 060360CC mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060360CE mov.b @r1+,r3
    c.r[2] += 1;  // 060360D0 add #1,r2
    st8(c.r[2], c.r[3]);  // 060360D2 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060360D4 mov.b @r1+,r3
    c.r[2] += 1;  // 060360D6 add #1,r2
    st8(c.r[2], c.r[3]);  // 060360D8 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060360DA mov.b @r1+,r3
    c.r[2] += 1;  // 060360DC add #1,r2
    st8(c.r[2], c.r[3]);  // 060360DE mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060360E0 mov.b @r1,r1
    c.r[2] += 1;  // 060360E2 add #1,r2
    { const uint32_t x = c.r[8]; c.pr = 0x060360E8u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060360E8u) return; }  // 060360E4 jsr @r8 ; mov.b r1,@r2
    c.r[1] = c.r[0];  // 060360E8 mov r0,r1
    c.r[5] = c.r[10];  // 060360EA mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060360F0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060360F0u) return; }  // 060360EC jsr @r8 ; mov r1,r4
    c.r[7] = c.r[0];  // 060360F0 mov r0,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x060361EAu);  // 060360F2 mov.w 0x060361EA,r2
    c.r[5] = 0xDu;  // 060360F4 mov #13,r5
    c.r[3] = ld32(c.r[11]);  // 060360F6 mov.l @r11,r3
    c.r[4] = c.r[9];  // 060360F8 mov r9,r4
    c.r[1] = c.r[3];  // 060360FA mov r3,r1
    c.r[1] += c.r[2];  // 060360FC add r2,r1
    c.r[0] = c.r[3];  // 060360FE mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06036100 mov.b @(r0,r2),r2
    c.r[1] += 1;  // 06036102 add #1,r1
    st8(c.r[7], c.r[2]);  // 06036104 mov.b r2,@r7
    c.r[2] = c.r[7];  // 06036106 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036108 mov.b @r1+,r3
    c.r[2] += 1;  // 0603610A add #1,r2
    st8(c.r[2], c.r[3]);  // 0603610C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603610E mov.b @r1+,r3
    c.r[2] += 1;  // 06036110 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036112 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036114 mov.b @r1+,r3
    c.r[2] += 1;  // 06036116 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036118 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603611A mov.b @r1+,r3
    c.r[2] += 1;  // 0603611C add #1,r2
    st8(c.r[2], c.r[3]);  // 0603611E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036120 mov.b @r1+,r3
    c.r[2] += 1;  // 06036122 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036124 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036126 mov.b @r1+,r3
    c.r[2] += 1;  // 06036128 add #1,r2
    st8(c.r[2], c.r[3]);  // 0603612A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603612C mov.b @r1+,r3
    c.r[2] += 1;  // 0603612E add #1,r2
    st8(c.r[2], c.r[3]);  // 06036130 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036132 mov.b @r1+,r3
    c.r[2] += 1;  // 06036134 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036136 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036138 mov.b @r1+,r3
    c.r[2] += 1;  // 0603613A add #1,r2
    st8(c.r[2], c.r[3]);  // 0603613C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603613E mov.b @r1+,r3
    c.r[2] += 1;  // 06036140 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036142 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036144 mov.b @r1+,r3
    c.r[2] += 1;  // 06036146 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036148 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603614A mov.b @r1+,r3
    c.r[2] += 1;  // 0603614C add #1,r2
    st8(c.r[2], c.r[3]);  // 0603614E mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036150 mov.b @r1,r1
    c.r[2] += 1;  // 06036152 add #1,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06036158u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036158u) return; }  // 06036154 jsr @r8 ; mov.b r1,@r2
    c.r[1] = c.r[0];  // 06036158 mov r0,r1
    c.r[5] = c.r[10];  // 0603615A mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06036160u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036160u) return; }  // 0603615C jsr @r8 ; mov r1,r4
    c.r[7] = c.r[0];  // 06036160 mov r0,r7
    c.r[3] = ld32(c.r[11]);  // 06036162 mov.l @r11,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x060361ECu);  // 06036164 mov.w 0x060361EC,r2
    c.r[1] = c.r[3];  // 06036166 mov r3,r1
    c.r[1] += c.r[2];  // 06036168 add r2,r1
    c.r[0] = c.r[3];  // 0603616A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603616C mov.b @(r0,r2),r2
    c.r[1] += 1;  // 0603616E add #1,r1
    st8(c.r[7], c.r[2]);  // 06036170 mov.b r2,@r7
    c.r[2] = c.r[7];  // 06036172 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036174 mov.b @r1+,r3
    c.r[2] += 1;  // 06036176 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036178 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603617A mov.b @r1+,r3
    c.r[2] += 1;  // 0603617C add #1,r2
    st8(c.r[2], c.r[3]);  // 0603617E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036180 mov.b @r1+,r3
    c.r[2] += 1;  // 06036182 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036184 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036186 mov.b @r1+,r3
    c.r[2] += 1;  // 06036188 add #1,r2
    st8(c.r[2], c.r[3]);  // 0603618A mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603618C mov.b @r1,r1
    c.r[2] += 1;  // 0603618E add #1,r2
    st8(c.r[2], c.r[1]);  // 06036190 mov.b r1,@r2
    c.r[1] = ld32(c.r[11]);  // 06036192 mov.l @r11,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060361EEu);  // 06036194 mov.w 0x060361EE,r7
    c.r[0] = c.r[1];  // 06036196 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06036198 mov.b @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060361F0u);  // 0603619A mov.w 0x060361F0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603619C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0603619E cmp/eq r2,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_060361BA; } }  // 060361A0 bf/s 0x060361BA ; mov #0,r2
    c.r[6] = 0x9u;  // 060361A4 mov #9,r6
    c.r[3] = c.r[11];  // 060361A6 mov r11,r3
    c.r[5] = c.r[7];  // 060361A8 mov r7,r5
    c.r[7] = 0x0u;  // 060361AA mov #0,r7
L_060361AC:
    c.r[1] = ld32(c.r[3]);  // 060361AC mov.l @r3,r1
    c.r[1] += c.r[2];  // 060361AE add r2,r1
    c.r[0] = c.r[1];  // 060361B0 mov r1,r0
    c.r[2] += 1;  // 060361B2 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 060361B4 cmp/gt r6,r2
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[7]); if (k) { SH2_POLL(c); goto L_060361AC; } }  // 060361B6 bf/s 0x060361AC ; mov.b r7,@(r0,r5)
L_060361BA:
    c.r[3] = ld32(0x060361FCu);  // 060361BA mov.l 0x060361FC,r3
    c.r[1] = ld32(c.r[3]);  // 060361BC mov.l @r3,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060361F2u);  // 060361BE mov.w 0x060361F2,r5
    c.r[0] = c.r[1];  // 060361C0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060361C2 mov.b @(r0,r5),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060361F0u);  // 060361C4 mov.w 0x060361F0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060361C6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060361C8 cmp/eq r2,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_06036202; } }  // 060361CA bf/s 0x06036202 ; mov #0,r2
    c.r[6] = 0x9u;  // 060361CE mov #9,r6
    c.r[7] = c.r[3];  // 060361D0 mov r3,r7
    c.r[3] = 0x0u;  // 060361D2 mov #0,r3
L_060361D4:
    c.r[1] = ld32(c.r[7]);  // 060361D4 mov.l @r7,r1
    c.r[1] += c.r[2];  // 060361D6 add r2,r1
    c.r[0] = c.r[1];  // 060361D8 mov r1,r0
    st8(c.r[0] + c.r[5], c.r[3]);  // 060361DA mov.b r3,@(r0,r5)
    c.r[2] += 1;  // 060361DC add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6]; goto L_06036200;  // 060361DE bra 0x06036200 ; cmp/gt r6,r2
L_06036200:
    if (!c.t) { SH2_POLL(c); goto L_060361D4; }  // 06036200 bf 0x060361D4
L_06036202:
    c.r[3] = ld32(0x06036288u);  // 06036202 mov.l 0x06036288,r3
    c.r[1] = ld32(c.r[3]);  // 06036204 mov.l @r3,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603627Eu);  // 06036206 mov.w 0x0603627E,r5
    c.r[0] = c.r[1];  // 06036208 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0603620A mov.b @(r0,r5),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06036280u);  // 0603620C mov.w 0x06036280,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603620E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06036210 cmp/eq r2,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_0603622A; } }  // 06036212 bf/s 0x0603622A ; mov #0,r2
    c.r[6] = 0x9u;  // 06036216 mov #9,r6
    c.r[7] = c.r[3];  // 06036218 mov r3,r7
    c.r[3] = 0x0u;  // 0603621A mov #0,r3
L_0603621C:
    c.r[1] = ld32(c.r[7]);  // 0603621C mov.l @r7,r1
    c.r[1] += c.r[2];  // 0603621E add r2,r1
    c.r[0] = c.r[1];  // 06036220 mov r1,r0
    c.r[2] += 1;  // 06036222 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 06036224 cmp/gt r6,r2
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[3]); if (k) { SH2_POLL(c); goto L_0603621C; } }  // 06036226 bf/s 0x0603621C ; mov.b r3,@(r0,r5)
L_0603622A:
    c.r[2] = 0x0u;  // 0603622A mov #0,r2
    c.r[7] = 0x9u;  // 0603622C mov #9,r7
    c.r[12] = ld32(0x06036288u);  // 0603622E mov.l 0x06036288,r12
    c.r[3] = ld32(c.r[12]);  // 06036230 mov.l @r12,r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x06036282u);  // 06036232 mov.w 0x06036282,r11
    c.r[0] = c.r[3];  // 06036234 mov r3,r0
L_06036236:
    c.r[0] += c.r[2];  // 06036236 add r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06036238 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603623A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603623C tst r1,r1
    if (!c.t) { goto L_06036248; }  // 0603623E bf 0x06036248
    c.r[2] += 1;  // 06036240 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 06036242 cmp/gt r7,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_06036236; } }  // 06036244 bf/s 0x06036236 ; mov r3,r0
L_06036248:
    c.r[0] = c.r[2];  // 06036248 mov r2,r0
    c.t = c.r[0] == 0xAu;  // 0603624A cmp/eq #10,r0
    if (!c.t) { goto L_06036252; }  // 0603624C bf 0x06036252
    goto L_060363A2;  // 0603624E bra 0x060363A2 ; nop
L_06036252:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036284u);  // 06036252 mov.w 0x06036284,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06036254 mov.b @(r0,r3),r0
    c.r[0] &= 0x1u;  // 06036256 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036258 tst r0,r0
    { const bool k = !c.t; c.r[5] = 0xBu; if (k) { goto L_06036294; } }  // 0603625A bf/s 0x06036294 ; mov #11,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x06036286u);  // 0603625E mov.w 0x06036286,r9
    c.r[4] = ld32(0x0603628Cu);  // 06036260 mov.l 0x0603628C,r4
    c.r[8] = ld32(0x06036290u);  // 06036262 mov.l 0x06036290,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06036268u; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036268u) return; }  // 06036264 jsr @r8 ; mov #11,r5
    c.r[1] = c.r[0];  // 06036268 mov r0,r1
    c.r[5] = c.r[9];  // 0603626A mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06036270u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036270u) return; }  // 0603626C jsr @r8 ; mov r1,r4
    c.r[2] = ld32(c.r[12]);  // 06036270 mov.l @r12,r2
    c.r[7] = c.r[0];  // 06036272 mov r0,r7
    c.r[1] = c.r[2];  // 06036274 mov r2,r1
    c.r[1] += c.r[11];  // 06036276 add r11,r1
    c.r[0] = c.r[2];  // 06036278 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]); goto L_06036366;  // 0603627A bra 0x06036366 ; mov.b @(r0,r11),r2
L_06036294:
    c.r[8] = (uint32_t)(int16_t)ld16(0x060363B4u);  // 06036294 mov.w 0x060363B4,r8
    c.r[10] = ld32(0x060363C0u);  // 06036296 mov.l 0x060363C0,r10
    c.r[9] = ld32(0x060363C4u);  // 06036298 mov.l 0x060363C4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0603629Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603629Eu) return; }  // 0603629A jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 0603629E mov r0,r1
    c.r[5] = c.r[8];  // 060362A0 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060362A6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060362A6u) return; }  // 060362A2 jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 060362A6 mov r0,r7
    c.r[8] = (uint32_t)(int16_t)ld16(0x060363B6u);  // 060362A8 mov.w 0x060363B6,r8
    c.r[5] = 0xBu;  // 060362AA mov #11,r5
    c.r[2] = ld32(c.r[12]);  // 060362AC mov.l @r12,r2
    c.r[4] = c.r[10];  // 060362AE mov r10,r4
    c.r[1] = c.r[2];  // 060362B0 mov r2,r1
    c.r[1] += c.r[11];  // 060362B2 add r11,r1
    c.r[0] = c.r[2];  // 060362B4 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060362B6 mov.b @(r0,r11),r2
    c.r[1] += 1;  // 060362B8 add #1,r1
    st8(c.r[7], c.r[2]);  // 060362BA mov.b r2,@r7
    c.r[2] = c.r[7];  // 060362BC mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362BE mov.b @r1+,r3
    c.r[2] += 1;  // 060362C0 add #1,r2
    st8(c.r[2], c.r[3]);  // 060362C2 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362C4 mov.b @r1+,r3
    c.r[2] += 1;  // 060362C6 add #1,r2
    st8(c.r[2], c.r[3]);  // 060362C8 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362CA mov.b @r1+,r3
    c.r[2] += 1;  // 060362CC add #1,r2
    st8(c.r[2], c.r[3]);  // 060362CE mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362D0 mov.b @r1+,r3
    c.r[2] += 1;  // 060362D2 add #1,r2
    st8(c.r[2], c.r[3]);  // 060362D4 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362D6 mov.b @r1+,r3
    c.r[2] += 1;  // 060362D8 add #1,r2
    st8(c.r[2], c.r[3]);  // 060362DA mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362DC mov.b @r1+,r3
    c.r[2] += 1;  // 060362DE add #1,r2
    st8(c.r[2], c.r[3]);  // 060362E0 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362E2 mov.b @r1+,r3
    c.r[2] += 1;  // 060362E4 add #1,r2
    st8(c.r[2], c.r[3]);  // 060362E6 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060362E8 mov.b @r1+,r3
    c.r[2] += 1;  // 060362EA add #1,r2
    st8(c.r[2], c.r[3]);  // 060362EC mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060362EE mov.b @r1,r1
    c.r[2] += 1;  // 060362F0 add #1,r2
    { const uint32_t x = c.r[9]; c.pr = 0x060362F6u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060362F6u) return; }  // 060362F2 jsr @r9 ; mov.b r1,@r2
    c.r[1] = c.r[0];  // 060362F6 mov r0,r1
    c.r[5] = c.r[8];  // 060362F8 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060362FEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060362FEu) return; }  // 060362FA jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 060362FE mov r0,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x060363B8u);  // 06036300 mov.w 0x060363B8,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x060363BAu);  // 06036302 mov.w 0x060363BA,r8
    c.r[5] = 0xBu;  // 06036304 mov #11,r5
    c.r[3] = ld32(c.r[12]);  // 06036306 mov.l @r12,r3
    c.r[4] = c.r[10];  // 06036308 mov r10,r4
    c.r[1] = c.r[3];  // 0603630A mov r3,r1
    c.r[1] += c.r[2];  // 0603630C add r2,r1
    c.r[0] = c.r[3];  // 0603630E mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06036310 mov.b @(r0,r2),r2
    c.r[1] += 1;  // 06036312 add #1,r1
    st8(c.r[7], c.r[2]);  // 06036314 mov.b r2,@r7
    c.r[2] = c.r[7];  // 06036316 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036318 mov.b @r1+,r3
    c.r[2] += 1;  // 0603631A add #1,r2
    st8(c.r[2], c.r[3]);  // 0603631C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603631E mov.b @r1+,r3
    c.r[2] += 1;  // 06036320 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036322 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036324 mov.b @r1+,r3
    c.r[2] += 1;  // 06036326 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036328 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603632A mov.b @r1+,r3
    c.r[2] += 1;  // 0603632C add #1,r2
    st8(c.r[2], c.r[3]);  // 0603632E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036330 mov.b @r1+,r3
    c.r[2] += 1;  // 06036332 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036334 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036336 mov.b @r1+,r3
    c.r[2] += 1;  // 06036338 add #1,r2
    st8(c.r[2], c.r[3]);  // 0603633A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603633C mov.b @r1+,r3
    c.r[2] += 1;  // 0603633E add #1,r2
    st8(c.r[2], c.r[3]);  // 06036340 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036342 mov.b @r1+,r3
    c.r[2] += 1;  // 06036344 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036346 mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036348 mov.b @r1,r1
    c.r[2] += 1;  // 0603634A add #1,r2
    { const uint32_t x = c.r[9]; c.pr = 0x06036350u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036350u) return; }  // 0603634C jsr @r9 ; mov.b r1,@r2
    c.r[1] = c.r[0];  // 06036350 mov r0,r1
    c.r[5] = c.r[8];  // 06036352 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06036358u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036358u) return; }  // 06036354 jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 06036358 mov r0,r7
    c.r[3] = ld32(c.r[12]);  // 0603635A mov.l @r12,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x060363BCu);  // 0603635C mov.w 0x060363BC,r2
    c.r[1] = c.r[3];  // 0603635E mov r3,r1
    c.r[1] += c.r[2];  // 06036360 add r2,r1
    c.r[0] = c.r[3];  // 06036362 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06036364 mov.b @(r0,r2),r2
L_06036366:
    c.r[1] += 1;  // 06036366 add #1,r1
    st8(c.r[7], c.r[2]);  // 06036368 mov.b r2,@r7
    c.r[2] = c.r[7];  // 0603636A mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603636C mov.b @r1+,r3
    c.r[2] += 1;  // 0603636E add #1,r2
    st8(c.r[2], c.r[3]);  // 06036370 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036372 mov.b @r1+,r3
    c.r[2] += 1;  // 06036374 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036376 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036378 mov.b @r1+,r3
    c.r[2] += 1;  // 0603637A add #1,r2
    st8(c.r[2], c.r[3]);  // 0603637C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603637E mov.b @r1+,r3
    c.r[2] += 1;  // 06036380 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036382 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036384 mov.b @r1+,r3
    c.r[2] += 1;  // 06036386 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036388 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603638A mov.b @r1+,r3
    c.r[2] += 1;  // 0603638C add #1,r2
    st8(c.r[2], c.r[3]);  // 0603638E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036390 mov.b @r1+,r3
    c.r[2] += 1;  // 06036392 add #1,r2
    st8(c.r[2], c.r[3]);  // 06036394 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06036396 mov.b @r1+,r3
    c.r[2] += 1;  // 06036398 add #1,r2
    st8(c.r[2], c.r[3]);  // 0603639A mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603639C mov.b @r1,r1
    c.r[2] += 1;  // 0603639E add #1,r2
    st8(c.r[2], c.r[1]);  // 060363A0 mov.b r1,@r2
L_060363A2:
    c.r[15] = c.r[14];  // 060363A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060363A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060363A6 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060363A8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060363AA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060363AC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060363AE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060363B0 rts ; mov.l @r15+,r8
}

void f_060363C8(SH2Context& c) {
    ran[779] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060363C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060363CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060363CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060363CE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060363D0 mov r15,r14
    c.r[8] = ld32(0x06036438u);  // 060363D2 mov.l 0x06036438,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060363D8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060363D8u) return; }  // 060363D4 jsr @r8 ; mov #3,r4
    c.r[1] = c.r[0] & 0xFFu;  // 060363D8 extu.b r0,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06036436u);  // 060363DA mov.w 0x06036436,r9
    c.t = c.r[1] == c.r[9];  // 060363DC cmp/eq r9,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0603642A; } }  // 060363DE bt/s 0x0603642A ; mov #0,r0
    { const uint32_t x = c.r[8]; c.pr = 0x060363E6u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060363E6u) return; }  // 060363E2 jsr @r8 ; mov #2,r4
    c.r[8] = c.r[0] & 0xFFu;  // 060363E6 extu.b r0,r8
    c.t = c.r[8] == c.r[9];  // 060363E8 cmp/eq r9,r8
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06036408; } }  // 060363EA bf/s 0x06036408 ; mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060363EE mov.l r1,@-r15
    c.r[0] = ld32(0x0603643Cu);  // 060363F0 mov.l 0x0603643C,r0
    c.r[7] = c.r[8];  // 060363F2 mov r8,r7
    c.r[6] = 0x1u;  // 060363F4 mov #1,r6
    c.r[5] = 0x0u;  // 060363F6 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060363FCu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060363FCu) return; }  // 060363F8 jsr @r0 ; mov #2,r4
    c.r[0] = ld32(0x06036440u);  // 060363FC mov.l 0x06036440,r0
    c.r[5] = 0x2u;  // 060363FE mov #2,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06036404u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036404u) return; }  // 06036400 jsr @r0 ; mov r8,r4
    c.r[0] = 0x1u; goto L_0603642A;  // 06036404 bra 0x0603642A ; mov #1,r0
L_06036408:
    c.r[1] = ld32(0x06036444u);  // 06036408 mov.l 0x06036444,r1
    c.r[2] = ld32(c.r[1]);  // 0603640A mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0603640C mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0603640E mul.l r1,r8
    c.r[1] = c.macl;  // 06036410 sts macl,r1
    c.r[1] += c.r[2];  // 06036412 add r2,r1
    c.r[1] += 16;  // 06036414 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036416 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06036418 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0603641A cmp/eq r9,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0603642A; } }  // 0603641C bt/s 0x0603642A ; mov #0,r0
    c.r[0] = ld32(0x06036440u);  // 06036420 mov.l 0x06036440,r0
    c.r[5] = 0x2u;  // 06036422 mov #2,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06036428u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036428u) return; }  // 06036424 jsr @r0 ; mov r8,r4
    c.r[0] = 0x0u;  // 06036428 mov #0,r0
L_0603642A:
    c.r[15] = c.r[14];  // 0603642A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603642C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603642E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06036430 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06036432 rts ; mov.l @r15+,r8
}

void f_06036448(SH2Context& c) {
    ran[780] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036448 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603644A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603644C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603644E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06036450 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06036452 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036454 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036456 sts.l pr,@-r15
    c.r[15] -= 4;  // 06036458 add #-4,r15
    c.r[14] = c.r[15];  // 0603645A mov r15,r14
    c.r[10] = 0x0u;  // 0603645C mov #0,r10
    c.r[13] = ld32(0x06036540u);  // 0603645E mov.l 0x06036540,r13
    c.r[12] = ld32(0x06036544u);  // 06036460 mov.l 0x06036544,r12
    c.r[11] = ld32(0x06036548u);  // 06036462 mov.l 0x06036548,r11
    c.r[9] = 0x0u;  // 06036464 mov #0,r9
L_06036466:
    c.r[1] = ld32(0x0603654Cu);  // 06036466 mov.l 0x0603654C,r1
    c.r[0] = ld32(c.r[1]);  // 06036468 mov.l @r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0603646A mov.w @(r0,r9),r5
    c.r[4] = 0x0u;  // 0603646C mov #0,r4
    c.r[0] = ld32(0x06036550u);  // 0603646E mov.l 0x06036550,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06036474u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036474u) return; }  // 06036470 jsr @r0 ; extu.w r5,r5
    c.r[7] = c.r[0] & 0xFFFFu;  // 06036474 extu.w r0,r7
    c.r[1] = ld32(0x06036554u);  // 06036476 mov.l 0x06036554,r1
    c.t = c.r[7] == c.r[1];  // 06036478 cmp/eq r1,r7
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_0603651C; } }  // 0603647A bt/s 0x0603651C ; mov r7,r2
    c.r[2] <<= 2;  // 0603647E shll2 r2
    c.r[8] = c.r[2];  // 06036480 mov r2,r8
    c.r[8] += c.r[13];  // 06036482 add r13,r8
    c.r[1] = ld32(c.r[12]);  // 06036484 mov.l @r12,r1
    c.r[6] = c.r[8];  // 06036486 mov r8,r6
    c.r[1] += c.r[2];  // 06036488 add r2,r1
    c.r[1] += 22;  // 0603648A add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603648C mov.b @r1,r0
    c.r[6] += 2;  // 0603648E add #2,r6
    c.r[0] &= 0x3Fu;  // 06036490 and #63,r0
    st8(c.r[1], c.r[0]);  // 06036492 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06036494 mov.b @r6,r0
    c.r[0] &= 0x3Fu;  // 06036496 and #63,r0
    st8(c.r[6], c.r[0]);  // 06036498 mov.b r0,@r6
    c.r[1] = ld32(c.r[12]);  // 0603649A mov.l @r12,r1
    c.r[1] += c.r[2];  // 0603649C add r2,r1
    c.r[4] = c.r[1];  // 0603649E mov r1,r4
    c.r[4] += 22;  // 060364A0 add #22,r4
    c.r[2] = 0x1Fu;  // 060364A2 mov #31,r2
    c.r[3] = c.r[1];  // 060364A4 mov r1,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060364A6 mov.b @r4,r5
    c.r[3] += 23;  // 060364A8 add #23,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060364AA mov.b @r3,r1
    c.r[2] &= c.r[5];  // 060364AC and r5,r2
    c.r[2] <<= 2;  // 060364AE shll2 r2
    c.r[2] += c.r[2];  // 060364B0 add r2,r2
    c.r[2] <<= 2;  // 060364B2 shll2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060364B4 extu.b r1,r1
    c.r[1] >>= 2;  // 060364B6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060364B8 shlr r1
    c.r[1] |= c.r[2];  // 060364BA or r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060364BC tst r1,r1
    { const bool k = !c.t; c.r[7] += c.r[7]; if (k) { goto L_0603651C; } }  // 060364BE bf/s 0x0603651C ; add r7,r7
    c.r[0] = c.r[7];  // 060364C2 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060364C4 mov.w @(r0,r11),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 060364C6 extu.w r1,r2
    c.r[0] = c.r[2];  // 060364C8 mov r2,r0
    c.r[0] >>= 2;  // 060364CA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060364CC shlr r0
    c.r[0] >>= 2;  // 060364CE shlr2 r0
    c.r[0] &= 0x1Fu;  // 060364D0 and #31,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603653Cu);  // 060364D2 mov.w 0x0603653C,r1
    c.r[1] &= c.r[5];  // 060364D4 and r5,r1
    c.r[1] |= c.r[0];  // 060364D6 or r0,r1
    st8(c.r[4], c.r[1]);  // 060364D8 mov.b r1,@r4
    c.r[0] = 0x1Fu;  // 060364DA mov #31,r0
    c.r[2] &= c.r[0];  // 060364DC and r0,r2
    c.r[2] <<= 2;  // 060364DE shll2 r2
    c.r[2] += c.r[2];  // 060364E0 add r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060364E2 mov.b @r3,r1
    c.r[0] = 0x7u;  // 060364E4 mov #7,r0
    c.r[1] &= c.r[0];  // 060364E6 and r0,r1
    c.r[1] |= c.r[2];  // 060364E8 or r2,r1
    st8(c.r[3], c.r[1]);  // 060364EA mov.b r1,@r3
    c.r[0] = c.r[7];  // 060364EC mov r7,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060364EE mov.w @(r0,r11),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603653Eu);  // 060364F0 mov.w 0x0603653E,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060364F2 mov.b @r6,r3
    c.r[2] &= c.r[1];  // 060364F4 and r1,r2
    c.r[1] = c.r[2];  // 060364F6 mov r2,r1
    c.r[1] >>= 2;  // 060364F8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060364FA shlr r1
    c.r[1] >>= 2;  // 060364FC shlr2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603653Cu);  // 060364FE mov.w 0x0603653C,r0
    c.r[3] &= c.r[0];  // 06036500 and r0,r3
    c.r[3] |= c.r[1];  // 06036502 or r1,r3
    st8(c.r[6], c.r[3]);  // 06036504 mov.b r3,@r6
    c.r[0] = 0x1Fu;  // 06036506 mov #31,r0
    c.r[2] &= c.r[0];  // 06036508 and r0,r2
    c.r[1] = c.r[8];  // 0603650A mov r8,r1
    c.r[1] += 3;  // 0603650C add #3,r1
    c.r[2] <<= 2;  // 0603650E shll2 r2
    c.r[2] += c.r[2];  // 06036510 add r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036512 mov.b @r1,r3
    c.r[0] = 0x7u;  // 06036514 mov #7,r0
    c.r[3] &= c.r[0];  // 06036516 and r0,r3
    c.r[3] |= c.r[2];  // 06036518 or r2,r3
    st8(c.r[1], c.r[3]);  // 0603651A mov.b r3,@r1
L_0603651C:
    c.r[10] += 1;  // 0603651C add #1,r10
    c.r[1] = 0x7Fu;  // 0603651E mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06036520 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_06036466; } }  // 06036522 bf/s 0x06036466 ; add #30,r9
    c.r[14] += 4;  // 06036526 add #4,r14
    c.r[15] = c.r[14];  // 06036528 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603652A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603652C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603652E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06036530 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06036532 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06036534 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06036536 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06036538 rts ; mov.l @r15+,r8
}

void f_06036558(SH2Context& c) {
    ran[781] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036558 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603655A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603655C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603655E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06036560 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06036562 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036564 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036566 sts.l pr,@-r15
    c.r[15] -= 4;  // 06036568 add #-4,r15
    c.r[14] = c.r[15];  // 0603656A mov r15,r14
    c.r[12] = c.r[4];  // 0603656C mov r4,r12
    c.r[0] = 0xFFFFFFFFu;  // 0603656E mov #-1,r0
    st32(c.r[14], c.r[0]);  // 06036570 mov.l r0,@r14
    c.r[9] = ld32(0x060366ECu);  // 06036572 mov.l 0x060366EC,r9
    c.r[1] = ld32(0x060366F0u);  // 06036574 mov.l 0x060366F0,r1
    c.r[4] = ld32(0x060366F4u);  // 06036576 mov.l 0x060366F4,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E0u);  // 06036578 mov.w 0x060366E0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0603657Eu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603657Eu) return; }  // 0603657A jsr @r1 ; mov r9,r5
    c.r[2] = ld32(0x060366F8u);  // 0603657E mov.l 0x060366F8,r2
    c.r[1] = ld32(0x060366FCu);  // 06036580 mov.l 0x060366FC,r1
    c.r[8] = 0x1u;  // 06036582 mov #1,r8
    c.r[13] = ld32(c.r[2]);  // 06036584 mov.l @r2,r13
    c.r[5] = c.r[12];  // 06036586 mov r12,r5
    c.r[1] = ld32(c.r[1]);  // 06036588 mov.l @r1,r1
    st32(c.r[2], c.r[1]);  // 0603658A mov.l r1,@r2
    c.r[1] = ld32(0x06036700u);  // 0603658C mov.l 0x06036700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06036592u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036592u) return; }  // 0603658E jsr @r1 ; mov #0,r4
    c.r[6] = c.r[8];  // 06036592 mov r8,r6
    c.r[4] = ld32(0x06036704u);  // 06036594 mov.l 0x06036704,r4
    c.r[0] = ld32(0x06036708u);  // 06036596 mov.l 0x06036708,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603659Cu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603659Cu) return; }  // 06036598 jsr @r0 ; mov r9,r5
    c.r[8] = c.r[0];  // 0603659C mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0603659E tst r8,r8
    if (!c.t) { goto L_060365EC; }  // 060365A0 bf 0x060365EC
    c.r[5] = (uint32_t)(int16_t)ld16(0x060366E2u);  // 060365A2 mov.w 0x060366E2,r5
    c.r[0] = ld32(0x0603670Cu);  // 060365A4 mov.l 0x0603670C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060365AAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060365AAu) return; }  // 060365A6 jsr @r0 ; mov r9,r4
    c.r[11] = ld32(0x06036710u);  // 060365AA mov.l 0x06036710,r11
    c.r[2] = ld32(c.r[11]);  // 060365AC mov.l @r11,r2
    c.r[1] = ld32(c.r[9]); c.r[9] += 4;  // 060365AE mov.l @r9+,r1
    st32(c.r[2], c.r[1]);  // 060365B0 mov.l r1,@r2
    c.r[1] = ld32(0x06036714u);  // 060365B2 mov.l 0x06036714,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060365B8u; c.r[10] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060365B8u) return; }  // 060365B4 jsr @r1 ; mov r0,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060365B8 mov.b @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060366E4u);  // 060365BA mov.w 0x060366E4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060365BC extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060365BE cmp/eq r2,r1
    if (!c.t) { goto L_060365C4; }  // 060365C0 bf 0x060365C4
    c.r[8] = 0xFFFFFFFDu;  // 060365C2 mov #-3,r8
L_060365C4:
    c.r[1] = ld32(c.r[11]);  // 060365C4 mov.l @r11,r1
    c.r[1] = ld32(c.r[1]);  // 060365C6 mov.l @r1,r1
    c.t = c.r[1] == c.r[10];  // 060365C8 cmp/eq r10,r1
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_060365D2; } }  // 060365CA bf/s 0x060365D2 ; tst r10,r10
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060365D6; } }  // 060365CE bf/s 0x060365D6 ; tst r8,r8
L_060365D2:
    c.r[8] = 0xFFFFFFFEu;  // 060365D2 mov #-2,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060365D4 tst r8,r8
L_060365D6:
    if (!c.t) { goto L_060365EC; }  // 060365D6 bf 0x060365EC
    c.r[1] = ld32(0x06036718u);  // 060365D8 mov.l 0x06036718,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060365DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060365DEu) return; }  // 060365DA jsr @r1 ; nop
    c.r[0] = ld32(0x0603671Cu);  // 060365DE mov.l 0x0603671C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060365E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060365E4u) return; }  // 060365E0 jsr @r0 ; nop
    c.r[1] = ld32(0x06036720u);  // 060365E4 mov.l 0x06036720,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060365EAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060365EAu) return; }  // 060365E6 jsr @r1 ; mov #1,r4
    c.t = (c.r[12] & c.r[12]) == 0;  // 060365EA tst r12,r12
L_060365EC:
    c.r[11] = ld32(0x060366F8u);  // 060365EC mov.l 0x060366F8,r11
    c.t = (c.r[8] & c.r[8]) == 0;  // 060365EE tst r8,r8
    { const bool k = c.t; st32(c.r[11], c.r[13]); if (k) { goto L_060365FA; } }  // 060365F0 bt/s 0x060365FA ; mov.l r13,@r11
    c.r[0] = c.r[8];  // 060365F4 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFDu;  // 060365F6 cmp/eq #-3,r0
    if (!c.t) { goto L_06036694; }  // 060365F8 bf 0x06036694
L_060365FA:
    c.r[0] = c.r[8];  // 060365FA mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFDu;  // 060365FC cmp/eq #-3,r0
    if (!c.t) { goto L_06036656; }  // 060365FE bf 0x06036656
    c.r[10] = ld32(0x060366ECu);  // 06036600 mov.l 0x060366EC,r10
    c.r[9] = ld32(0x060366F0u);  // 06036602 mov.l 0x060366F0,r9
    c.r[5] = ld32(0x060366F4u);  // 06036604 mov.l 0x060366F4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E0u);  // 06036606 mov.w 0x060366E0,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0603660Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603660Cu) return; }  // 06036608 jsr @r9 ; mov r10,r4
    c.r[1] = ld32(0x06036724u);  // 0603660C mov.l 0x06036724,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06036612u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036612u) return; }  // 0603660E jsr @r1 ; nop
    c.r[1] = ld32(0x06036728u);  // 06036612 mov.l 0x06036728,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E6u);  // 06036614 mov.w 0x060366E6,r6
    c.r[4] = ld32(c.r[1]);  // 06036616 mov.l @r1,r4
    c.r[5] = ld32(0x0603672Cu);  // 06036618 mov.l 0x0603672C,r5
    c.r[1] = ld32(0x06036730u);  // 0603661A mov.l 0x06036730,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06036620u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036620u) return; }  // 0603661C jsr @r1 ; nop
    c.r[1] = ld32(0x06036734u);  // 06036620 mov.l 0x06036734,r1
    c.r[5] = ld32(0x06036738u);  // 06036622 mov.l 0x06036738,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E8u);  // 06036624 mov.w 0x060366E8,r6
    c.r[8] = ld32(0x06036710u);  // 06036626 mov.l 0x06036710,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0603662Cu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603662Cu) return; }  // 06036628 jsr @r9 ; mov.l @r1,r4
    c.r[5] = ld32(0x0603673Cu);  // 0603662C mov.l 0x0603673C,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E8u);  // 0603662E mov.w 0x060366E8,r6
    c.r[4] = ld32(c.r[8]);  // 06036630 mov.l @r8,r4
    c.r[1] = ld32(0x06036740u);  // 06036632 mov.l 0x06036740,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06036638u; c.r[4] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036638u) return; }  // 06036634 jsr @r9 ; add #40,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0603663Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603663Cu) return; }  // 06036638 jsr @r1 ; nop
    c.r[2] = c.r[10];  // 0603663C mov r10,r2
    c.r[2] += 4;  // 0603663E add #4,r2
    c.r[1] = 0xFFFFFFFFu;  // 06036640 mov #-1,r1
    c.r[3] = ld32(c.r[8]);  // 06036642 mov.l @r8,r3
    c.r[10] += 7;  // 06036644 add #7,r10
    c.r[3] += 4;  // 06036646 add #4,r3
    st8(c.r[2], c.r[1]);  // 06036648 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0603664A mov.b r1,@r3
    c.r[2] = ld32(c.r[8]);  // 0603664C mov.l @r8,r2
    c.r[1] = 0x1u;  // 0603664E mov #1,r1
    c.r[2] += 7;  // 06036650 add #7,r2
    st8(c.r[10], c.r[1]);  // 06036652 mov.b r1,@r10
    st8(c.r[2], c.r[1]);  // 06036654 mov.b r1,@r2
L_06036656:
    c.r[1] = ld32(0x060366FCu);  // 06036656 mov.l 0x060366FC,r1
    c.r[8] = ld32(c.r[11]);  // 06036658 mov.l @r11,r8
    c.r[5] = c.r[12];  // 0603665A mov r12,r5
    c.r[1] = ld32(c.r[1]);  // 0603665C mov.l @r1,r1
    st32(c.r[11], c.r[1]);  // 0603665E mov.l r1,@r11
    c.r[1] = ld32(0x06036700u);  // 06036660 mov.l 0x06036700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06036666u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036666u) return; }  // 06036662 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06036744u);  // 06036666 mov.l 0x06036744,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603666Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603666Cu) return; }  // 06036668 jsr @r1 ; nop
    c.r[0] = ld32(0x0603670Cu);  // 0603666C mov.l 0x0603670C,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x060366E2u);  // 0603666E mov.w 0x060366E2,r5
    c.r[4] = ld32(0x060366ECu);  // 06036670 mov.l 0x060366EC,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06036676u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036676u) return; }  // 06036672 jsr @r0 ; nop
    c.r[1] = ld32(0x06036710u);  // 06036676 mov.l 0x06036710,r1
    c.r[5] = ld32(0x060366ECu);  // 06036678 mov.l 0x060366EC,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E2u);  // 0603667A mov.w 0x060366E2,r6
    c.r[1] = ld32(c.r[1]);  // 0603667C mov.l @r1,r1
    c.r[4] = ld32(0x06036704u);  // 0603667E mov.l 0x06036704,r4
    st32(c.r[5], c.r[0]);  // 06036680 mov.l r0,@r5
    st32(c.r[1], c.r[0]);  // 06036682 mov.l r0,@r1
    c.r[0] = ld32(0x06036748u);  // 06036684 mov.l 0x06036748,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603668Au; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603668Au) return; }  // 06036686 jsr @r0 ; mov #0,r7
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603668A tst r0,r0
    { const bool k = !c.t; st32(c.r[11], c.r[8]); if (k) { goto L_06036694; } }  // 0603668C bf/s 0x06036694 ; mov.l r8,@r11
    c.r[0] = 0x0u;  // 06036690 mov #0,r0
    st32(c.r[14], c.r[0]);  // 06036692 mov.l r0,@r14
L_06036694:
    c.r[4] = ld32(0x060366ECu);  // 06036694 mov.l 0x060366EC,r4
    c.r[8] = ld32(0x060366F0u);  // 06036696 mov.l 0x060366F0,r8
    c.r[5] = ld32(0x060366F4u);  // 06036698 mov.l 0x060366F4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E0u);  // 0603669A mov.w 0x060366E0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060366A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366A0u) return; }  // 0603669C jsr @r8 ; nop
    c.r[1] = ld32(0x06036724u);  // 060366A0 mov.l 0x06036724,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060366A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366A6u) return; }  // 060366A2 jsr @r1 ; nop
    c.r[10] = ld32(0x06036728u);  // 060366A6 mov.l 0x06036728,r10
    c.r[1] = ld32(0x06036730u);  // 060366A8 mov.l 0x06036730,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E6u);  // 060366AA mov.w 0x060366E6,r6
    c.r[5] = ld32(0x0603672Cu);  // 060366AC mov.l 0x0603672C,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060366B2u; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366B2u) return; }  // 060366AE jsr @r1 ; mov.l @r10,r4
    c.r[1] = ld32(0x06036734u);  // 060366B2 mov.l 0x06036734,r1
    c.r[5] = ld32(0x06036738u);  // 060366B4 mov.l 0x06036738,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E8u);  // 060366B6 mov.w 0x060366E8,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060366BCu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366BCu) return; }  // 060366B8 jsr @r8 ; mov.l @r1,r4
    c.r[1] = ld32(0x06036710u);  // 060366BC mov.l 0x06036710,r1
    c.r[5] = ld32(0x0603673Cu);  // 060366BE mov.l 0x0603673C,r5
    c.r[4] = ld32(c.r[1]);  // 060366C0 mov.l @r1,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x060366E8u);  // 060366C2 mov.w 0x060366E8,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060366C8u; c.r[4] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366C8u) return; }  // 060366C4 jsr @r8 ; add #40,r4
    c.r[1] = ld32(0x06036740u);  // 060366C8 mov.l 0x06036740,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060366CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366CEu) return; }  // 060366CA jsr @r1 ; nop
    c.r[1] = ld32(0x06036718u);  // 060366CE mov.l 0x06036718,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060366D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366D4u) return; }  // 060366D0 jsr @r1 ; nop
    c.r[8] = ld32(0x0603674Cu);  // 060366D4 mov.l 0x0603674C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060366DAu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060366DAu) return; }  // 060366D6 jsr @r8 ; mov #3,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x060366E4u);  // 060366DA mov.w 0x060366E4,r9
    c.r[1] = c.r[0] & 0xFFu; goto L_06036750;  // 060366DC bra 0x06036750 ; extu.b r0,r1
L_06036750:
    c.t = c.r[1] == c.r[9];  // 06036750 cmp/eq r9,r1
    if (c.t) { goto L_06036796; }  // 06036752 bt 0x06036796
    { const uint32_t x = c.r[8]; c.pr = 0x06036758u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036758u) return; }  // 06036754 jsr @r8 ; mov #2,r4
    c.r[8] = c.r[0] & 0xFFu;  // 06036758 extu.b r0,r8
    c.t = c.r[8] == c.r[9];  // 0603675A cmp/eq r9,r8
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0603677A; } }  // 0603675C bf/s 0x0603677A ; mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06036760 mov.l r1,@-r15
    c.r[0] = ld32(0x060367B4u);  // 06036762 mov.l 0x060367B4,r0
    c.r[7] = c.r[8];  // 06036764 mov r8,r7
    c.r[6] = 0x1u;  // 06036766 mov #1,r6
    c.r[5] = 0x0u;  // 06036768 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603676Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603676Eu) return; }  // 0603676A jsr @r0 ; mov #2,r4
    c.r[0] = ld32(0x060367B8u);  // 0603676E mov.l 0x060367B8,r0
    c.r[5] = 0x2u;  // 06036770 mov #2,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06036776u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036776u) return; }  // 06036772 jsr @r0 ; mov r8,r4
    c.r[15] += 4; goto L_06036796;  // 06036776 bra 0x06036796 ; add #4,r15
L_0603677A:
    c.r[1] = 0x1Eu;  // 0603677A mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0603677C mul.l r1,r8
    c.r[2] = ld32(c.r[10]);  // 0603677E mov.l @r10,r2
    c.r[1] = c.macl;  // 06036780 sts macl,r1
    c.r[1] += c.r[2];  // 06036782 add r2,r1
    c.r[1] += 16;  // 06036784 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036786 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06036788 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0603678A cmp/eq r9,r1
    { const bool k = c.t; c.r[5] = 0x2u; if (k) { goto L_06036796; } }  // 0603678C bt/s 0x06036796 ; mov #2,r5
    c.r[0] = ld32(0x060367B8u);  // 06036790 mov.l 0x060367B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06036796u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036796u) return; }  // 06036792 jsr @r0 ; mov r8,r4
L_06036796:
    c.r[1] = ld32(0x060367BCu);  // 06036796 mov.l 0x060367BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603679Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603679Cu) return; }  // 06036798 jsr @r1 ; mov #1,r4
    c.r[0] = ld32(c.r[14]); c.r[14] += 4;  // 0603679C mov.l @r14+,r0
    c.r[15] = c.r[14];  // 0603679E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060367A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060367A2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060367A4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060367A6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060367A8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060367AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060367AC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060367AE rts ; mov.l @r15+,r8
}

void f_060367C0(SH2Context& c) {
    ran[782] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060367C0 mov.l r14,@-r15
    c.r[2] = ld32(0x06036810u);  // 060367C2 mov.l 0x06036810,r2
    c.r[1] = ld32(c.r[2]);  // 060367C4 mov.l @r2,r1
    c.r[1] += 1;  // 060367C6 add #1,r1
    st32(c.r[2], c.r[1]);  // 060367C8 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060367CA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060367CC extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060367CE cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060367E6; } }  // 060367D0 bt/s 0x060367E6 ; mov r15,r14
    c.r[1] = 0x1u;  // 060367D4 mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060367D6 cmp/gt r1,r0
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_060367EE; } }  // 060367D8 bt/s 0x060367EE ; tst r0,r0
    { const bool k = !c.t; c.r[2] += 112; if (k) { goto L_060367EE; } }  // 060367DC bf/s 0x060367EE ; add #112,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036806u);  // 060367E0 mov.w 0x06036806,r1
    c.r[2] = ld32(c.r[2]); goto L_060367F4;  // 060367E2 bra 0x060367F4 ; mov.l @r2,r2
L_060367E6:
    c.r[2] += 112;  // 060367E6 add #112,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036808u);  // 060367E8 mov.w 0x06036808,r1
    c.r[2] = ld32(c.r[2]); goto L_060367F4;  // 060367EA bra 0x060367F4 ; mov.l @r2,r2
L_060367EE:
    c.r[1] = ld32(0x06036814u);  // 060367EE mov.l 0x06036814,r1
    c.r[2] = ld32(c.r[1]);  // 060367F0 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603680Au);  // 060367F2 mov.w 0x0603680A,r1
L_060367F4:
    c.t = c.r[2] > c.r[1];  // 060367F4 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06036800; } }  // 060367F6 bt/s 0x06036800 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603680Cu);  // 060367FA mov.w 0x0603680C,r0
    goto L_06036802;  // 060367FC bra 0x06036802 ; nop
L_06036800:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603680Eu);  // 06036800 mov.w 0x0603680E,r0
L_06036802:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06036802 rts ; mov.l @r15+,r14
}

void f_06036818(SH2Context& c) {
    ran[783] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036818 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603681A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603681C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603681E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06036820 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06036822 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036824 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036826 sts.l pr,@-r15
    c.r[1] = ld32(0x060368D8u);  // 06036828 mov.l 0x060368D8,r1
    c.r[2] = ld32(c.r[1]);  // 0603682A mov.l @r1,r2
    c.r[3] = ld32(0x060368DCu);  // 0603682C mov.l 0x060368DC,r3
    c.r[9] = ld32(c.r[3]);  // 0603682E mov.l @r3,r9
    c.r[2] += 1;  // 06036830 add #1,r2
    st32(c.r[1], c.r[2]);  // 06036832 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06036834 mov.b @r2,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06036836 extu.b r1,r11
    c.r[0] = c.r[11];  // 06036838 mov r11,r0
    c.t = c.r[0] == 0x3u;  // 0603683A cmp/eq #3,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06036846; } }  // 0603683C bf/s 0x06036846 ; mov r15,r14
    c.r[1] = ld32(0x060368E0u);  // 06036840 mov.l 0x060368E0,r1
    c.r[1] = ld32(c.r[1]);  // 06036842 mov.l @r1,r1
    st32(c.r[3], c.r[1]);  // 06036844 mov.l r1,@r3
L_06036846:
    c.r[0] = ld32(0x060368E4u);  // 06036846 mov.l 0x060368E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603684Cu; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603684Cu) return; }  // 06036848 jsr @r0 ; mov #0,r10
    c.r[8] = ld32(0x060368E8u);  // 0603684C mov.l 0x060368E8,r8
    c.r[5] = 0x1u;  // 0603684E mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06036854u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036854u) return; }  // 06036850 jsr @r8 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036854 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_06036868; } }  // 06036856 bt/s 0x06036868 ; mov r11,r0
    c.r[5] = 0x0u;  // 0603685A mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06036860u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036860u) return; }  // 0603685C jsr @r8 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036860 tst r0,r0
    if (c.t) { goto L_06036866; }  // 06036862 bt 0x06036866
    c.r[10] = 0x1u;  // 06036864 mov #1,r10
L_06036866:
    c.r[0] = c.r[11];  // 06036866 mov r11,r0
L_06036868:
    c.t = c.r[0] == 0x3u;  // 06036868 cmp/eq #3,r0
    { const bool k = !c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06036874; } }  // 0603686A bf/s 0x06036874 ; tst r11,r11
    c.r[1] = ld32(0x060368DCu);  // 0603686E mov.l 0x060368DC,r1
    st32(c.r[1], c.r[9]); goto L_06036878;  // 06036870 bra 0x06036878 ; mov.l r9,@r1
L_06036874:
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_06036888; } }  // 06036874 bf/s 0x06036888 ; mov #0,r9
L_06036878:
    c.r[10] += c.r[10];  // 06036878 add r10,r10
    c.r[10] += 1;  // 0603687A add #1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x060368D2u);  // 0603687C mov.w 0x060368D2,r1
    c.r[10] |= c.r[1];  // 0603687E or r1,r10
    c.r[0] = c.r[10]; goto L_060368BE;  // 06036880 bra 0x060368BE ; mov r10,r0
L_06036884:
    c.r[9] = 0x1u; goto L_060368A2;  // 06036884 bra 0x060368A2 ; mov #1,r9
L_06036888:
    c.r[4] = 0x0u;  // 06036888 mov #0,r4
    c.r[13] = ld32(0x060368E8u);  // 0603688A mov.l 0x060368E8,r13
    c.r[12] = 0x61u;  // 0603688C mov #97,r12
L_0603688E:
    c.r[8] = c.r[4];  // 0603688E mov r4,r8
    c.r[8] += 1;  // 06036890 add #1,r8
    c.r[4] = c.r[8] & 0xFFu;  // 06036892 extu.b r8,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06036898u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036898u) return; }  // 06036894 jsr @r13 ; mov #1,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036898 tst r0,r0
    { const bool k = c.t; c.r[4] = c.r[8]; if (k) { SH2_POLL(c); goto L_06036884; } }  // 0603689A bt/s 0x06036884 ; mov r8,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[12];  // 0603689E cmp/gt r12,r4
    if (!c.t) { SH2_POLL(c); goto L_0603688E; }  // 060368A0 bf 0x0603688E
L_060368A2:
    c.r[0] = c.r[11];  // 060368A2 mov r11,r0
    c.t = c.r[0] == 0x1u;  // 060368A4 cmp/eq #1,r0
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060368B0; } }  // 060368A6 bf/s 0x060368B0 ; tst r9,r9
    if (!c.t) { goto L_060368B6; }  // 060368AA bf 0x060368B6
    goto L_060368BC;  // 060368AC bra 0x060368BC ; nop
L_060368B0:
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_060368BC; } }  // 060368B0 bt/s 0x060368BC ; tst r10,r10
    if (!c.t) { goto L_060368BC; }  // 060368B4 bf 0x060368BC
L_060368B6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060368D4u);  // 060368B6 mov.w 0x060368D4,r0
    c.r[15] = c.r[14]; goto L_060368C0;  // 060368B8 bra 0x060368C0 ; mov r14,r15
L_060368BC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060368D6u);  // 060368BC mov.w 0x060368D6,r0
L_060368BE:
    c.r[15] = c.r[14];  // 060368BE mov r14,r15
L_060368C0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060368C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060368C2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060368C4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060368C6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060368C8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060368CA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060368CC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060368CE rts ; mov.l @r15+,r8
}

void f_060368F0(SH2Context& c) {
    ran[784] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060368F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060368F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060368F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060368F6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060368F8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060368FA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060368FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060368FE sts.l pr,@-r15
    c.r[15] -= 4;  // 06036900 add #-4,r15
    c.r[1] = ld32(0x06036A48u);  // 06036902 mov.l 0x06036A48,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036904 mov.b @r1,r0
    c.r[14] = c.r[15]; goto L_0603690C;  // 06036906 bra 0x0603690C ; mov r15,r14
L_0603690A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603690A mov.b @r1,r0
L_0603690C:
    c.r[0] &= 0x1u;  // 0603690C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603690E tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_0603690A; }  // 06036910 bf 0x0603690A
    c.r[1] = 0x1u;  // 06036912 mov #1,r1
    c.r[3] = ld32(0x06036A48u);  // 06036914 mov.l 0x06036A48,r3
    st8(c.r[3], c.r[1]);  // 06036916 mov.b r1,@r3
    c.r[2] = ld32(0x06036A4Cu);  // 06036918 mov.l 0x06036A4C,r2
    c.r[1] = 0x19u;  // 0603691A mov #25,r1
    st8(c.r[2], c.r[1]);  // 0603691C mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603691E mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06036920 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036922 tst r0,r0
    if (c.t) { goto L_06036930; }  // 06036924 bt 0x06036930
    c.r[1] = c.r[3];  // 06036926 mov r3,r1
L_06036928:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036928 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603692A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603692C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036928; }  // 0603692E bf 0x06036928
L_06036930:
    c.r[1] = ld32(0x06036A50u);  // 06036930 mov.l 0x06036A50,r1
    c.r[2] = 0x0u;  // 06036932 mov #0,r2
    st8(c.r[1], c.r[2]);  // 06036934 mov.b r2,@r1
    c.r[0] = 0x1u;  // 06036936 mov #1,r0
    st32(c.r[14], c.r[0]);  // 06036938 mov.l r0,@r14
    c.r[1] = ld32(0x06036A54u);  // 0603693A mov.l 0x06036A54,r1
    c.r[1] = ld32(c.r[1]);  // 0603693C mov.l @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06036A42u);  // 0603693E mov.w 0x06036A42,r3
    c.r[13] = 0x0u;  // 06036940 mov #0,r13
    c.r[11] = 0x0u;  // 06036942 mov #0,r11
    c.r[12] = c.r[3];  // 06036944 mov r3,r12
    c.r[0] = c.r[1];  // 06036946 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06036948 mov.b r2,@(r0,r3)
    c.r[9] = 0x0u;  // 0603694A mov #0,r9
L_0603694C:
    c.r[10] = c.r[11];  // 0603694C mov r11,r10
    c.r[10] += 1;  // 0603694E add #1,r10
    c.r[8] = c.r[10] & 0xFFu;  // 06036950 extu.b r10,r8
    c.r[5] = 0x1u;  // 06036952 mov #1,r5
    c.r[6] = ld32(0x06036A58u);  // 06036954 mov.l 0x06036A58,r6
    { const uint32_t x = c.r[6]; c.pr = 0x0603695Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603695Au) return; }  // 06036956 jsr @r6 ; mov r8,r4
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0603695A cmp/eq #-2,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06036964; } }  // 0603695C bf/s 0x06036964 ; mov r0,r1
    goto L_06036A86;  // 06036960 bra 0x06036A86 ; nop
L_06036964:
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036964 tst r1,r1
    { const bool k = !c.t; c.r[6] = 0x7Fu; if (k) { goto L_06036984; } }  // 06036966 bf/s 0x06036984 ; mov #127,r6
    c.r[1] = ld32(0x06036A54u);  // 0603696A mov.l 0x06036A54,r1
    c.r[3] = ld32(c.r[1]);  // 0603696C mov.l @r1,r3
    c.r[0] = c.r[3];  // 0603696E mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06036970 mov.b @(r0,r12),r2
    c.r[9] = 0x1u;  // 06036972 mov #1,r9
    c.r[1] = c.r[2];  // 06036974 mov r2,r1
    c.r[1] += 1;  // 06036976 add #1,r1
    st8(c.r[0] + c.r[12], c.r[1]);  // 06036978 mov.b r1,@(r0,r12)
    c.r[7] = c.r[2] & 0xFFu;  // 0603697A extu.b r2,r7
    c.r[7] += c.r[7];  // 0603697C add r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036A44u);  // 0603697E mov.w 0x06036A44,r1
    c.r[10] |= c.r[1]; goto L_060369AC;  // 06036980 bra 0x060369AC ; or r1,r10
L_06036984:
    c.r[5] = 0x0u;  // 06036984 mov #0,r5
    c.r[6] = ld32(0x06036A58u);  // 06036986 mov.l 0x06036A58,r6
    { const uint32_t x = c.r[6]; c.pr = 0x0603698Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603698Cu) return; }  // 06036988 jsr @r6 ; mov r8,r4
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0603698C cmp/eq #-2,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06036A86; } }  // 0603698E bt/s 0x06036A86 ; mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036992 tst r1,r1
    if (!c.t) { goto L_060369C6; }  // 06036994 bf 0x060369C6
    c.r[6] = 0x7Fu;  // 06036996 mov #127,r6
    c.r[1] = ld32(0x06036A54u);  // 06036998 mov.l 0x06036A54,r1
    c.r[3] = ld32(c.r[1]);  // 0603699A mov.l @r1,r3
    c.r[0] = c.r[3];  // 0603699C mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0603699E mov.b @(r0,r12),r2
    c.r[9] = 0x1u;  // 060369A0 mov #1,r9
    c.r[1] = c.r[2];  // 060369A2 mov r2,r1
    c.r[1] += 1;  // 060369A4 add #1,r1
    st8(c.r[0] + c.r[12], c.r[1]);  // 060369A6 mov.b r1,@(r0,r12)
    c.r[7] = c.r[2] & 0xFFu;  // 060369A8 extu.b r2,r7
    c.r[7] += c.r[7];  // 060369AA add r7,r7
L_060369AC:
    c.r[1] = c.r[10] & 0xFFFFu;  // 060369AC extu.w r10,r1
    c.r[5] = c.r[1];  // 060369AE mov r1,r5
    c.r[5] >>= 8;  // 060369B0 shlr8 r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060369B2 mov.b @(r0,r7),r2
    c.r[5] &= c.r[6];  // 060369B4 and r6,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036A46u);  // 060369B6 mov.w 0x06036A46,r0
    c.r[2] &= c.r[0];  // 060369B8 and r0,r2
    c.r[2] |= c.r[5];  // 060369BA or r5,r2
    c.r[0] = c.r[3];  // 060369BC mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 060369BE mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 060369C0 add r7,r3
    c.r[3] += 1;  // 060369C2 add #1,r3
    st8(c.r[3], c.r[1]);  // 060369C4 mov.b r1,@r3
L_060369C6:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060369C6 tst r9,r9
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_060369D6; } }  // 060369C8 bf/s 0x060369D6 ; tst r13,r13
    { const bool k = !c.t; c.r[6] = c.r[11]; if (k) { goto L_060369D6; } }  // 060369CC bf/s 0x060369D6 ; mov r11,r6
    c.r[6] += 1;  // 060369D0 add #1,r6
    st32(c.r[14], c.r[6]);  // 060369D2 mov.l r6,@r14
    c.r[13] = 0x1u;  // 060369D4 mov #1,r13
L_060369D6:
    c.r[11] += 1;  // 060369D6 add #1,r11
    c.r[1] = 0x61u;  // 060369D8 mov #97,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 060369DA cmp/gt r1,r11
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { SH2_POLL(c); goto L_0603694C; } }  // 060369DC bf/s 0x0603694C ; mov #0,r9
    c.r[1] = ld32(0x06036A48u);  // 060369E0 mov.l 0x06036A48,r1
L_060369E2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060369E2 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060369E4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060369E6 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060369E2; }  // 060369E8 bf 0x060369E2
    c.r[1] = 0x1u;  // 060369EA mov #1,r1
    c.r[3] = ld32(0x06036A48u);  // 060369EC mov.l 0x06036A48,r3
    st8(c.r[3], c.r[1]);  // 060369EE mov.b r1,@r3
    c.r[2] = ld32(0x06036A4Cu);  // 060369F0 mov.l 0x06036A4C,r2
    c.r[1] = 0x19u;  // 060369F2 mov #25,r1
    st8(c.r[2], c.r[1]);  // 060369F4 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060369F6 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060369F8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060369FA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06036A08; } }  // 060369FC bt/s 0x06036A08 ; mov r3,r1
L_06036A00:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036A00 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036A02 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036A04 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036A00; }  // 06036A06 bf 0x06036A00
L_06036A08:
    c.r[2] = ld32(0x06036A50u);  // 06036A08 mov.l 0x06036A50,r2
    c.r[1] = ld32(0x06036A54u);  // 06036A0A mov.l 0x06036A54,r1
    c.r[1] = ld32(c.r[1]);  // 06036A0C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036A42u);  // 06036A0E mov.w 0x06036A42,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06036A10 mov.b @(r0,r1),r1
    c.r[7] = ld32(0x06036A5Cu);  // 06036A12 mov.l 0x06036A5C,r7
    c.r[3] = c.r[1] & 0xFFu;  // 06036A14 extu.b r1,r3
    st32(c.r[7] + 4, c.r[3]);  // 06036A16 mov.l r3,@(4,r7)
    st8(c.r[2], c.r[3]);  // 06036A18 mov.b r3,@r2
    c.r[1] = ld32(0x06036A60u);  // 06036A1A mov.l 0x06036A60,r1
    c.r[2] = ld32(c.r[1]);  // 06036A1C mov.l @r1,r2
    c.r[1] = ld32(0x06036A64u);  // 06036A1E mov.l 0x06036A64,r1
    c.r[1] = ld32(c.r[1]);  // 06036A20 mov.l @r1,r1
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06036A22 dmulu.l r1,r2
    c.r[1] = c.mach;  // 06036A24 sts mach,r1
    c.r[1] >>= 8;  // 06036A26 shlr8 r1
    c.r[1] >>= 2;  // 06036A28 shlr2 r1
    c.r[1] >>= 2;  // 06036A2A shlr2 r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06036A2C exts.w r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06036A2E cmp/pz r2
    if (c.t) { goto L_06036A34; }  // 06036A30 bt 0x06036A34
    c.r[2] = 0x0u;  // 06036A32 mov #0,r2
L_06036A34:
    c.r[2] += c.r[3];  // 06036A34 add r3,r2
    c.r[1] = 0x61u;  // 06036A36 mov #97,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06036A38 cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = 0x62u; if (k) { goto L_06036A68; } }  // 06036A3A bf/s 0x06036A68 ; mov #98,r1
    st32(c.r[7], c.r[1]); goto L_06036A6A;  // 06036A3E bra 0x06036A6A ; mov.l r1,@r7
L_06036A68:
    st32(c.r[7], c.r[2]);  // 06036A68 mov.l r2,@r7
L_06036A6A:
    c.r[1] = ld32(0x06036AFCu);  // 06036A6A mov.l 0x06036AFC,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036A6C mov.b @r1,r7
    c.r[3] = ld32(0x06036B00u);  // 06036A6E mov.l 0x06036B00,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06036A70 mov.w @r3,r1
    c.r[2] = c.r[7] & 0xFFu;  // 06036A72 extu.b r7,r2
    c.r[1] -= c.r[2];  // 06036A74 sub r2,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06036A76 exts.w r1,r2
    c.t = (int32_t)c.r[2] > 0;  // 06036A78 cmp/pl r2
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06036A8C; } }  // 06036A7A bt/s 0x06036A8C ; tst r2,r2
    c.r[1] = c.r[7] & 0xFFu;  // 06036A7E extu.b r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036A80 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06036A8C; } }  // 06036A82 bf/s 0x06036A8C ; tst r2,r2
L_06036A86:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036AF2u);  // 06036A86 mov.w 0x06036AF2,r0
    c.r[14] += 4; goto L_06036ADE;  // 06036A88 bra 0x06036ADE ; add #4,r14
L_06036A8C:
    if (c.t) { goto L_06036ADA; }  // 06036A8C bt 0x06036ADA
    c.r[1] = ld32(0x06036B04u);  // 06036A8E mov.l 0x06036B04,r1
    c.r[1] = ld32(c.r[1]);  // 06036A90 mov.l @r1,r1
    c.r[1] += 6;  // 06036A92 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036A94 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06036A96 extu.b r1,r0
    c.t = c.r[0] == 0x49u;  // 06036A98 cmp/eq #73,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06036AA4; } }  // 06036A9A bt/s 0x06036AA4 ; mov.l @r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036AF4u);  // 06036A9E mov.w 0x06036AF4,r1
    c.r[0] |= c.r[1];  // 06036AA0 or r1,r0
    st32(c.r[14], c.r[0]);  // 06036AA2 mov.l r0,@r14
L_06036AA4:
    c.r[1] = ld32(0x06036B08u);  // 06036AA4 mov.l 0x06036B08,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06036AF6u);  // 06036AA6 mov.w 0x06036AF6,r7
    c.r[3] = ld32(c.r[1]);  // 06036AA8 mov.l @r1,r3
    c.r[6] = 0x2u;  // 06036AAA mov #2,r6
    c.r[0] = c.r[3];  // 06036AAC mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06036AAE mov.b @(r0,r7),r2
    c.r[6] += c.r[14];  // 06036AB0 add r14,r6
    c.r[1] = c.r[2];  // 06036AB2 mov r2,r1
    c.r[1] += 1;  // 06036AB4 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06036AB6 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 06036AB8 extu.b r2,r7
    c.r[7] += c.r[7];  // 06036ABA add r7,r7
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06036ABC mov.w @r6,r6
    c.r[0] = 0x7Fu;  // 06036ABE mov #127,r0
    c.r[1] = c.r[6] & 0xFFFFu;  // 06036AC0 extu.w r6,r1
    c.r[5] = c.r[1];  // 06036AC2 mov r1,r5
    c.r[5] >>= 8;  // 06036AC4 shlr8 r5
    c.r[5] &= c.r[0];  // 06036AC6 and r0,r5
    c.r[0] = c.r[3];  // 06036AC8 mov r3,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x06036AF8u);  // 06036ACA mov.w 0x06036AF8,r6
    c.r[3] += c.r[7];  // 06036ACC add r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06036ACE mov.b @(r0,r7),r2
    c.r[3] += 1;  // 06036AD0 add #1,r3
    c.r[2] &= c.r[6];  // 06036AD2 and r6,r2
    c.r[2] |= c.r[5];  // 06036AD4 or r5,r2
    st8(c.r[0] + c.r[7], c.r[2]);  // 06036AD6 mov.b r2,@(r0,r7)
    st8(c.r[3], c.r[1]);  // 06036AD8 mov.b r1,@r3
L_06036ADA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036AFAu);  // 06036ADA mov.w 0x06036AFA,r0
    c.r[14] += 4;  // 06036ADC add #4,r14
L_06036ADE:
    c.r[15] = c.r[14];  // 06036ADE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06036AE0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06036AE2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06036AE4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06036AE6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06036AE8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06036AEA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06036AEC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06036AEE rts ; mov.l @r15+,r8
}

void f_06036B0C(SH2Context& c) {
    ran[785] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036B0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06036B0E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06036B10 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06036B12 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06036B14 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06036B16 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036B18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036B1A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06036BA0u);  // 06036B1C mov.w 0x06036BA0,r3
    c.r[15] += c.r[3];  // 06036B1E add r3,r15
    c.r[14] = c.r[15];  // 06036B20 mov r15,r14
    c.r[2] = ld32(0x06036BA8u);  // 06036B22 mov.l 0x06036BA8,r2
    c.r[1] = ld32(0x06036BACu);  // 06036B24 mov.l 0x06036BAC,r1
    st32(c.r[2], c.r[1]);  // 06036B26 mov.l r1,@r2
    c.r[1] = ld32(0x06036BB0u);  // 06036B28 mov.l 0x06036BB0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036B2A mov.b @r1,r0
    c.r[11] = c.r[14]; goto L_06036B32;  // 06036B2C bra 0x06036B32 ; mov r14,r11
L_06036B30:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036B30 mov.b @r1,r0
L_06036B32:
    c.r[0] &= 0x1u;  // 06036B32 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036B34 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036B30; }  // 06036B36 bf 0x06036B30
    c.r[1] = 0x1u;  // 06036B38 mov #1,r1
    c.r[3] = ld32(0x06036BB0u);  // 06036B3A mov.l 0x06036BB0,r3
    st8(c.r[3], c.r[1]);  // 06036B3C mov.b r1,@r3
    c.r[2] = ld32(0x06036BB4u);  // 06036B3E mov.l 0x06036BB4,r2
    c.r[1] = 0x1Au;  // 06036B40 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06036B42 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06036B44 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06036B46 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036B48 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06036B56; } }  // 06036B4A bt/s 0x06036B56 ; mov r3,r1
L_06036B4E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036B4E mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036B50 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036B52 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036B4E; }  // 06036B54 bf 0x06036B4E
L_06036B56:
    c.r[10] = 0x0u;  // 06036B56 mov #0,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036BA2u);  // 06036B58 mov.w 0x06036BA2,r0
    st32(c.r[0] + c.r[14], c.r[10]);  // 06036B5A mov.l r10,@(r0,r14)
    c.r[1] = ld32(0x06036BB8u);  // 06036B5C mov.l 0x06036BB8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036BA2u);  // 06036B5E mov.w 0x06036BA2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036B60 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06036B62 mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06036B64 extu.b r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06036B66 cmp/ge r1,r0
    if (!c.t) { goto L_06036B6E; }  // 06036B68 bf 0x06036B6E
    goto L_06036D78;  // 06036B6A bra 0x06036D78 ; nop
L_06036B6E:
    c.r[12] = 0x0u;  // 06036B6E mov #0,r12
    c.r[13] = 0x0u;  // 06036B70 mov #0,r13
L_06036B72:
    c.r[1] = ld32(0x06036BBCu);  // 06036B72 mov.l 0x06036BBC,r1
    c.r[1] = ld32(c.r[1]);  // 06036B74 mov.l @r1,r1
    c.r[10] = 0x7Fu;  // 06036B76 mov #127,r10
    c.r[0] = c.r[1];  // 06036B78 mov r1,r0
    c.r[1] += c.r[13];  // 06036B7A add r13,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06036B7C mov.b @(r0,r13),r2
    c.r[1] += 1;  // 06036B7E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036B80 mov.b @r1,r1
    c.r[2] &= c.r[10];  // 06036B82 and r10,r2
    c.r[2] <<= 8;  // 06036B84 shll8 r2
    c.r[9] = c.r[1] & 0xFFu;  // 06036B86 extu.b r1,r9
    c.r[9] |= c.r[2];  // 06036B88 or r2,r9
    c.r[1] = c.r[9];  // 06036B8A mov r9,r1
    c.r[1] >>= 8;  // 06036B8C shlr8 r1
    c.r[1] <<= 2;  // 06036B8E shll2 r1
    c.r[1] >>= 8;  // 06036B90 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036B92 tst r1,r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06036BC0; } }  // 06036B94 bt/s 0x06036BC0 ; mov #0,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036BA4u);  // 06036B98 mov.w 0x06036BA4,r1
    c.r[9] &= c.r[1];  // 06036B9A and r1,r9
    c.r[10] = 0x1u; goto L_06036BC0;  // 06036B9C bra 0x06036BC0 ; mov #1,r10
L_06036BC0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036D1Au);  // 06036BC0 mov.w 0x06036D1A,r0
    st32(c.r[0] + c.r[14], c.r[10]);  // 06036BC2 mov.l r10,@(r0,r14)
    c.r[4] = c.r[9] & 0xFFu;  // 06036BC4 extu.b r9,r4
    c.r[7] = 0x0u;  // 06036BC6 mov #0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036D1Au);  // 06036BC8 mov.w 0x06036D1A,r0
    c.r[0] += c.r[14];  // 06036BCA add r14,r0
    c.r[5] = c.r[14];  // 06036BCC mov r14,r5
    c.r[10] = ld32(0x06036D24u);  // 06036BCE mov.l 0x06036D24,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06036BD4u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036BD4u) return; }  // 06036BD0 jsr @r10 ; mov.l @r0,r6
    c.r[8] = c.r[0];  // 06036BD4 mov r0,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x06036D1Cu);  // 06036BD6 mov.w 0x06036D1C,r5
    c.r[0] = ld32(0x06036D28u);  // 06036BD8 mov.l 0x06036D28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06036BDEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036BDEu) return; }  // 06036BDA jsr @r0 ; mov r14,r4
    c.r[1] = ld32(c.r[14]);  // 06036BDE mov.l @r14,r1
    c.r[2] = c.r[0];  // 06036BE0 mov r0,r2
    c.t = c.r[2] == c.r[1];  // 06036BE2 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06036BEC; } }  // 06036BE4 bf/s 0x06036BEC ; tst r2,r2
    { const bool k = !c.t; c.r[4] = c.r[9] & 0xFFu; if (k) { goto L_06036BF2; } }  // 06036BE8 bf/s 0x06036BF2 ; extu.b r9,r4
L_06036BEC:
    c.r[10] = 0x1u;  // 06036BEC mov #1,r10
    c.r[8] |= c.r[10];  // 06036BEE or r10,r8
    c.r[4] = c.r[9] & 0xFFu;  // 06036BF0 extu.b r9,r4
L_06036BF2:
    c.r[6] = 0x0u;  // 06036BF2 mov #0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036D1Au);  // 06036BF4 mov.w 0x06036D1A,r0
    c.r[0] += c.r[14];  // 06036BF6 add r14,r0
    c.r[10] = ld32(0x06036D2Cu);  // 06036BF8 mov.l 0x06036D2C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06036BFEu; c.r[5] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036BFEu) return; }  // 06036BFA jsr @r10 ; mov.l @r0,r5
    c.r[1] = c.r[0];  // 06036BFE mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036C00 tst r1,r1
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06036C0C; } }  // 06036C02 bt/s 0x06036C0C ; tst r8,r8
    c.r[0] = 0x2u;  // 06036C06 mov #2,r0
    c.r[8] |= c.r[0];  // 06036C08 or r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06036C0A tst r8,r8
L_06036C0C:
    { const bool k = c.t; c.r[10] = 0x7Fu; if (k) { goto L_06036C14; } }  // 06036C0C bt/s 0x06036C14 ; mov #127,r10
    goto L_06036D3C;  // 06036C10 bra 0x06036D3C ; nop
L_06036C14:
    c.r[1] = ld32(0x06036D30u);  // 06036C14 mov.l 0x06036D30,r1
    c.r[3] = c.r[12];  // 06036C16 mov r12,r3
    c.r[1] = ld32(c.r[1]);  // 06036C18 mov.l @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06036D1Eu);  // 06036C1A mov.w 0x06036D1E,r5
    c.r[0] = c.r[1];  // 06036C1C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06036C1E mov.b @(r0,r13),r2
    c.r[6] = 0x7Fu;  // 06036C20 mov #127,r6
    c.r[2] &= c.r[10];  // 06036C22 and r10,r2
    st8(c.r[0] + c.r[13], c.r[2]);  // 06036C24 mov.b r2,@(r0,r13)
    c.r[0] = ld32(0x06036D34u);  // 06036C26 mov.l 0x06036D34,r0
    c.r[7] = ld32(c.r[0]);  // 06036C28 mov.l @r0,r7
    c.r[2] = ld32(0x06036D38u);  // 06036C2A mov.l 0x06036D38,r2
    c.r[1] = ld32(c.r[2]);  // 06036C2C mov.l @r2,r1
    c.r[0] = c.r[12];  // 06036C2E mov r12,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 06036C30 mov.l r1,@(r0,r7)
    c.r[1] = ld32(c.r[2] + 4);  // 06036C32 mov.l @(4,r2),r1
    c.r[3] += c.r[7];  // 06036C34 add r7,r3
    st32(c.r[3] + 4, c.r[1]);  // 06036C36 mov.l r1,@(4,r3)
    c.r[1] = c.r[11];  // 06036C38 mov r11,r1
    c.r[1] += 10;  // 06036C3A add #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036C3C mov.w @r1,r2
    c.r[10] = ld32(0x06036D34u);  // 06036C3E mov.l 0x06036D34,r10
    c.r[2] = c.r[2] & 0xFFFFu;  // 06036C40 extu.w r2,r2
    c.r[1] = c.r[11];  // 06036C42 mov r11,r1
    c.r[1] += 12;  // 06036C44 add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036C46 mov.b @r1,r1
    c.r[2] <<= 8;  // 06036C48 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06036C4A extu.b r1,r1
    c.r[1] |= c.r[2];  // 06036C4C or r2,r1
    st32(c.r[3] + 8, c.r[1]);  // 06036C4E mov.l r1,@(8,r3)
    c.r[2] = c.r[3];  // 06036C50 mov r3,r2
    c.r[1] = c.r[11];  // 06036C52 mov r11,r1
    c.r[1] += 14;  // 06036C54 add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036C56 mov.w @r1,r1
    c.r[2] += 12;  // 06036C58 add #12,r2
    st16(c.r[2], c.r[1]);  // 06036C5A mov.w r1,@r2
    c.r[2] = c.r[3];  // 06036C5C mov r3,r2
    c.r[1] = c.r[11];  // 06036C5E mov r11,r1
    c.r[1] += 52;  // 06036C60 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036C62 mov.w @r1,r1
    c.r[2] += 14;  // 06036C64 add #14,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06036C66 extu.w r1,r1
    c.r[1] >>= 2;  // 06036C68 shlr2 r1
    c.r[1] >>= 2;  // 06036C6A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06036C6C shlr r1
    c.r[1] >>= 2;  // 06036C6E shlr2 r1
    st16(c.r[2], c.r[1]);  // 06036C70 mov.w r1,@r2
    c.r[1] = c.r[11];  // 06036C72 mov r11,r1
    c.r[1] += 5;  // 06036C74 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036C76 mov.b @r1,r1
    c.r[3] += 36;  // 06036C78 add #36,r3
    st8(c.r[3], c.r[1]);  // 06036C7A mov.b r1,@r3
    c.r[1] = c.r[11];  // 06036C7C mov r11,r1
    c.r[2] = ld32(c.r[10]);  // 06036C7E mov.l @r10,r2
    c.r[1] += 7;  // 06036C80 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036C82 mov.b @r1,r1
    c.r[2] += c.r[12];  // 06036C84 add r12,r2
    c.r[2] += 38;  // 06036C86 add #38,r2
    st8(c.r[2], c.r[1]);  // 06036C88 mov.b r1,@r2
    c.r[1] = c.r[11];  // 06036C8A mov r11,r1
    c.r[2] = ld32(c.r[10]);  // 06036C8C mov.l @r10,r2
    c.r[1] += 6;  // 06036C8E add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036C90 mov.b @r1,r1
    c.r[2] += c.r[12];  // 06036C92 add r12,r2
    c.r[2] += 39;  // 06036C94 add #39,r2
    st8(c.r[2], c.r[1]);  // 06036C96 mov.b r1,@r2
    c.r[2] = ld32(c.r[10]);  // 06036C98 mov.l @r10,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06036D20u);  // 06036C9A mov.w 0x06036D20,r7
    c.r[1] = ld32(c.r[11] + 60);  // 06036C9C mov.l @(60,r11),r1
    c.r[2] += c.r[12];  // 06036C9E add r12,r2
    st32(c.r[2] + 16, c.r[1]);  // 06036CA0 mov.l r1,@(16,r2)
    c.r[1] = c.r[11];  // 06036CA2 mov r11,r1
    c.r[1] += 64;  // 06036CA4 add #64,r1
    c.r[1] = ld32(c.r[1]);  // 06036CA6 mov.l @r1,r1
    c.r[7] += c.r[14];  // 06036CA8 add r14,r7
    st32(c.r[2] + 20, c.r[1]);  // 06036CAA mov.l r1,@(20,r2)
    c.r[1] = c.r[11];  // 06036CAC mov r11,r1
    c.r[1] += 68;  // 06036CAE add #68,r1
    c.r[1] = ld32(c.r[1]);  // 06036CB0 mov.l @r1,r1
    c.r[3] = c.r[2];  // 06036CB2 mov r2,r3
    st32(c.r[2] + 24, c.r[1]);  // 06036CB4 mov.l r1,@(24,r2)
    c.r[1] = c.r[11];  // 06036CB6 mov r11,r1
    c.r[1] += 72;  // 06036CB8 add #72,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036CBA mov.w @r1,r1
    c.r[3] += 28;  // 06036CBC add #28,r3
    st16(c.r[3], c.r[1]);  // 06036CBE mov.w r1,@r3
    c.r[3] = c.r[2];  // 06036CC0 mov r2,r3
    c.r[1] = c.r[11];  // 06036CC2 mov r11,r1
    c.r[1] += 74;  // 06036CC4 add #74,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036CC6 mov.w @r1,r1
    c.r[3] += 30;  // 06036CC8 add #30,r3
    st16(c.r[3], c.r[1]);  // 06036CCA mov.w r1,@r3
    c.r[3] = c.r[2];  // 06036CCC mov r2,r3
    c.r[1] = c.r[11];  // 06036CCE mov r11,r1
    c.r[1] += 76;  // 06036CD0 add #76,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036CD2 mov.w @r1,r1
    c.r[3] += 32;  // 06036CD4 add #32,r3
    st16(c.r[3], c.r[1]);  // 06036CD6 mov.w r1,@r3
    c.r[3] = c.r[2];  // 06036CD8 mov r2,r3
    c.r[3] += 34;  // 06036CDA add #34,r3
    c.r[1] = c.r[11];  // 06036CDC mov r11,r1
    c.r[1] += 78;  // 06036CDE add #78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06036CE0 mov.w @r1,r1
    c.r[2] += 37;  // 06036CE2 add #37,r2
    st16(c.r[3], c.r[1]);  // 06036CE4 mov.w r1,@r3
    c.r[1] = 0x0u;  // 06036CE6 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06036CE8 mov.b r1,@r2
    c.r[2] = 0x0u;  // 06036CEA mov #0,r2
    c.r[3] = 0x0u;  // 06036CEC mov #0,r3
L_06036CEE:
    c.r[4] = c.r[3];  // 06036CEE mov r3,r4
    c.r[0] = c.r[4];  // 06036CF0 mov r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06036CF2 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06036CF4 extu.w r1,r1
    c.t = c.r[1] == c.r[5];  // 06036CF6 cmp/eq r5,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06036D06; } }  // 06036CF8 bt/s 0x06036D06 ; add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 06036CFC cmp/gt r6,r2
    { const bool k = !c.t; c.r[3] += 12; if (k) { SH2_POLL(c); goto L_06036CEE; } }  // 06036CFE bf/s 0x06036CEE ; add #12,r3
    c.r[12] += 40; goto L_06036D5A;  // 06036D02 bra 0x06036D5A ; add #40,r12
L_06036D06:
    c.r[10] = ld32(0x06036D34u);  // 06036D06 mov.l 0x06036D34,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036D22u);  // 06036D08 mov.w 0x06036D22,r1
    c.r[1] += c.r[14];  // 06036D0A add r14,r1
    c.r[2] = ld32(c.r[10]);  // 06036D0C mov.l @r10,r2
    c.r[0] = c.r[1];  // 06036D0E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06036D10 mov.b @(r0,r3),r1
    c.r[2] += c.r[12];  // 06036D12 add r12,r2
    c.r[2] += 37;  // 06036D14 add #37,r2
    st8(c.r[2], c.r[1]); goto L_06036D58;  // 06036D16 bra 0x06036D58 ; mov.b r1,@r2
L_06036D3C:
    c.r[1] = ld32(0x06036DC4u);  // 06036D3C mov.l 0x06036DC4,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06036DBAu);  // 06036D3E mov.w 0x06036DBA,r10
    c.r[1] = ld32(c.r[1]);  // 06036D40 mov.l @r1,r1
    c.r[6] = 0x28u;  // 06036D42 mov #40,r6
    c.r[0] = c.r[1];  // 06036D44 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06036D46 mov.b @(r0,r13),r2
    c.r[5] = 0x0u;  // 06036D48 mov #0,r5
    c.r[2] |= c.r[10];  // 06036D4A or r10,r2
    st8(c.r[0] + c.r[13], c.r[2]);  // 06036D4C mov.b r2,@(r0,r13)
    c.r[0] = ld32(0x06036DC8u);  // 06036D4E mov.l 0x06036DC8,r0
    c.r[4] = ld32(c.r[0]);  // 06036D50 mov.l @r0,r4
    c.r[10] = ld32(0x06036DCCu);  // 06036D52 mov.l 0x06036DCC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06036D58u; c.r[4] += c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036D58u) return; }  // 06036D54 jsr @r10 ; add r12,r4
L_06036D58:
    c.r[12] += 40;  // 06036D58 add #40,r12
L_06036D5A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036DBCu);  // 06036D5A mov.w 0x06036DBC,r0
    c.r[0] += c.r[14];  // 06036D5C add r14,r0
    c.r[10] = ld32(c.r[0]);  // 06036D5E mov.l @r0,r10
    c.r[1] = ld32(0x06036DD0u);  // 06036D60 mov.l 0x06036DD0,r1
    c.r[10] += 1;  // 06036D62 add #1,r10
    st32(c.r[0], c.r[10]);  // 06036D64 mov.l r10,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036DBCu);  // 06036D66 mov.w 0x06036DBC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036D68 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06036D6A mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06036D6C extu.b r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06036D6E cmp/ge r1,r0
    { const bool k = c.t; c.r[13] += 2; if (k) { goto L_06036D78; } }  // 06036D70 bt/s 0x06036D78 ; add #2,r13
    SH2_POLL(c); goto L_06036B72;  // 06036D74 bra 0x06036B72 ; nop
L_06036D78:
    c.r[1] = ld32(0x06036DD4u);  // 06036D78 mov.l 0x06036DD4,r1
L_06036D7A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036D7A mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036D7C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036D7E tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036D7A; }  // 06036D80 bf 0x06036D7A
    c.r[1] = 0x1u;  // 06036D82 mov #1,r1
    c.r[3] = ld32(0x06036DD4u);  // 06036D84 mov.l 0x06036DD4,r3
    st8(c.r[3], c.r[1]);  // 06036D86 mov.b r1,@r3
    c.r[2] = ld32(0x06036DD8u);  // 06036D88 mov.l 0x06036DD8,r2
    c.r[1] = 0x19u;  // 06036D8A mov #25,r1
    st8(c.r[2], c.r[1]);  // 06036D8C mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06036D8E mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06036D90 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036D92 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06036DA0; } }  // 06036D94 bt/s 0x06036DA0 ; mov r3,r1
L_06036D98:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036D98 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036D9A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036D9C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036D98; }  // 06036D9E bf 0x06036D98
L_06036DA0:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06036DBEu);  // 06036DA0 mov.w 0x06036DBE,r3
    c.r[14] += c.r[3];  // 06036DA2 add r3,r14
    c.r[15] = c.r[14];  // 06036DA4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06036DA6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06036DA8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06036DAA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06036DAC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06036DAE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06036DB0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06036DB2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036DC0u);  // 06036DB4 mov.w 0x06036DC0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06036DB6 rts ; mov.l @r15+,r8
}

void f_06036DDC(SH2Context& c) {
    ran[786] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036DDC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06036DDE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06036DE0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06036DE2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06036DE4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06036DE6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036DE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036DEA sts.l pr,@-r15
    c.r[1] = ld32(0x06036ED8u);  // 06036DEC mov.l 0x06036ED8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036DEE mov.b @r1,r1
    c.r[12] = ld32(0x06036EDCu);  // 06036DF0 mov.l 0x06036EDC,r12
    c.r[3] = c.r[1] & 0xFFu;  // 06036DF2 extu.b r1,r3
    c.r[1] = ld32(0x06036EE0u);  // 06036DF4 mov.l 0x06036EE0,r1
    c.r[0] = c.r[3];  // 06036DF6 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06036DF8 mov.b @(r0,r1),r2
    c.r[13] = ld32(0x06036EE4u);  // 06036DFA mov.l 0x06036EE4,r13
    c.r[2] = c.r[2] & 0xFFu;  // 06036DFC extu.b r2,r2
    c.r[2] -= 1;  // 06036DFE add #-1,r2
    c.r[1] = 0x7u;  // 06036E00 mov #7,r1
    c.macl = c.r[2] * c.r[1];  // 06036E02 mul.l r1,r2
    c.r[11] = ld32(0x06036EE8u);  // 06036E04 mov.l 0x06036EE8,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x06036ECAu);  // 06036E06 mov.w 0x06036ECA,r10
    c.r[1] = ld32(0x06036EECu);  // 06036E08 mov.l 0x06036EEC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06036E0A mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06036E0C sts macl,r2
    c.r[2] += c.r[1];  // 06036E0E add r1,r2
    st8(c.r[12], c.r[2]);  // 06036E10 mov.b r2,@r12
    c.r[2] = c.r[2] & 0xFFu;  // 06036E12 extu.b r2,r2
    c.r[1] = ld32(c.r[11]);  // 06036E14 mov.l @r11,r1
    c.r[2] += c.r[2];  // 06036E16 add r2,r2
    c.r[0] = c.r[1];  // 06036E18 mov r1,r0
    c.r[1] += c.r[2];  // 06036E1A add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06036E1C mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06036E1E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036E20 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 06036E22 mov #127,r0
    c.r[3] &= c.r[0];  // 06036E24 and r0,r3
    c.r[3] <<= 8;  // 06036E26 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06036E28 extu.b r1,r1
    c.r[1] |= c.r[3];  // 06036E2A or r3,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06036E2C extu.w r1,r8
    st16(c.r[13], c.r[1]);  // 06036E2E mov.w r1,@r13
    c.r[1] = c.r[8];  // 06036E30 mov r8,r1
    c.r[1] &= c.r[10];  // 06036E32 and r10,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06036E34 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036E36 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06036E44; } }  // 06036E38 bt/s 0x06036E44 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036ECCu);  // 06036E3C mov.w 0x06036ECC,r1
    c.r[8] &= c.r[1];  // 06036E3E and r1,r8
    c.r[9] = 0x1u; goto L_06036E8E;  // 06036E40 bra 0x06036E8E ; mov #1,r9
L_06036E44:
    c.r[1] = ld32(0x06036EF0u);  // 06036E44 mov.l 0x06036EF0,r1
    c.r[1] = ld32(c.r[1]);  // 06036E46 mov.l @r1,r1
    c.r[1] += 6;  // 06036E48 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036E4A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06036E4C extu.b r1,r0
    c.t = c.r[0] == 0x49u;  // 06036E4E cmp/eq #73,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06036E8E; } }  // 06036E50 bt/s 0x06036E8E ; mov #0,r9
    c.r[4] = c.r[8] & 0xFFu;  // 06036E54 extu.b r8,r4
    c.r[0] = ld32(0x06036EF4u);  // 06036E56 mov.l 0x06036EF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06036E5Cu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036E5Cu) return; }  // 06036E58 jsr @r0 ; mov #0,r5
    c.r[3] = c.r[8];  // 06036E5C mov r8,r3
    c.r[3] |= c.r[10];  // 06036E5E or r10,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06036E60 mov.b @r12,r1
    c.r[0] = 0x7Fu;  // 06036E62 mov #127,r0
    c.r[2] = ld32(c.r[11]);  // 06036E64 mov.l @r11,r2
    c.r[6] = c.r[1] & 0xFFu;  // 06036E66 extu.b r1,r6
    c.r[6] += c.r[6];  // 06036E68 add r6,r6
    c.r[1] = c.r[3] & 0xFFFFu;  // 06036E6A extu.w r3,r1
    c.r[5] = c.r[1];  // 06036E6C mov r1,r5
    c.r[5] >>= 8;  // 06036E6E shlr8 r5
    c.r[5] &= c.r[0];  // 06036E70 and r0,r5
    c.r[0] = c.r[2];  // 06036E72 mov r2,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06036E74 mov.b @(r0,r6),r7
    c.r[9] = 0x1u;  // 06036E76 mov #1,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036ECEu);  // 06036E78 mov.w 0x06036ECE,r0
    c.r[7] &= c.r[0];  // 06036E7A and r0,r7
    c.r[7] |= c.r[5];  // 06036E7C or r5,r7
    c.r[0] = c.r[2];  // 06036E7E mov r2,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 06036E80 mov.b r7,@(r0,r6)
    c.r[2] += c.r[6];  // 06036E82 add r6,r2
    c.r[2] += 1;  // 06036E84 add #1,r2
    st8(c.r[2], c.r[1]);  // 06036E86 mov.b r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06036ED0u);  // 06036E88 mov.w 0x06036ED0,r1
    c.r[3] &= c.r[1];  // 06036E8A and r1,r3
    st16(c.r[13], c.r[3]);  // 06036E8C mov.w r3,@r13
L_06036E8E:
    c.r[8] = c.r[8] & 0xFFu;  // 06036E8E extu.b r8,r8
    c.r[0] = ld32(0x06036EF8u);  // 06036E90 mov.l 0x06036EF8,r0
    c.r[5] = c.r[9];  // 06036E92 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06036E98u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036E98u) return; }  // 06036E94 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 06036E98 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036E9A tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_06036EB4; } }  // 06036E9C bf/s 0x06036EB4 ; mov r9,r5
    c.r[0] = ld32(0x06036EFCu);  // 06036EA0 mov.l 0x06036EFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06036EA6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036EA6u) return; }  // 06036EA2 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 06036EA6 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06036EA8 tst r1,r1
    if (!c.t) { goto L_06036EB4; }  // 06036EAA bf 0x06036EB4
    c.r[15] = c.r[14];  // 06036EAC mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036ED2u);  // 06036EAE mov.w 0x06036ED2,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06036EBA;  // 06036EB0 bra 0x06036EBA ; lds.l @r15+,pr
L_06036EB4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06036ED4u);  // 06036EB4 mov.w 0x06036ED4,r0
    c.r[15] = c.r[14];  // 06036EB6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06036EB8 lds.l @r15+,pr
L_06036EBA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06036EBA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06036EBC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06036EBE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06036EC0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06036EC2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06036EC4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06036EC6 rts ; mov.l @r15+,r8
}

void f_06036F04(SH2Context& c) {
    ran[787] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06036F04 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06036F06 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06036F08 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06036F0A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06036F0C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06036F0E sts.l pr,@-r15
    c.r[1] = ld32(0x06037068u);  // 06036F10 mov.l 0x06037068,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036F12 mov.b @r1,r0
    c.r[14] = c.r[15]; goto L_06036F1A;  // 06036F14 bra 0x06036F1A ; mov r15,r14
L_06036F18:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036F18 mov.b @r1,r0
L_06036F1A:
    c.r[0] &= 0x1u;  // 06036F1A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036F1C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036F18; }  // 06036F1E bf 0x06036F18
    c.r[1] = 0x1u;  // 06036F20 mov #1,r1
    c.r[3] = ld32(0x06037068u);  // 06036F22 mov.l 0x06037068,r3
    st8(c.r[3], c.r[1]);  // 06036F24 mov.b r1,@r3
    c.r[2] = ld32(0x0603706Cu);  // 06036F26 mov.l 0x0603706C,r2
    c.r[1] = 0x1Au;  // 06036F28 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06036F2A mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06036F2C mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06036F2E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036F30 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06036F3E; } }  // 06036F32 bt/s 0x06036F3E ; mov r3,r1
L_06036F36:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036F36 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036F38 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036F3A tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036F36; }  // 06036F3C bf 0x06036F36
L_06036F3E:
    c.r[1] = ld32(0x06037070u);  // 06036F3E mov.l 0x06037070,r1
    c.r[2] = ld32(c.r[1]);  // 06036F40 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603705Cu);  // 06036F42 mov.w 0x0603705C,r0
    c.r[11] = ld32(0x06037074u);  // 06036F44 mov.l 0x06037074,r11
    c.r[9] = c.r[0];  // 06036F46 mov r0,r9
    c.r[1] = 0x0u;  // 06036F48 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06036F4A mov.b r1,@(r0,r2)
    c.r[2] = 0x0u;  // 06036F4C mov #0,r2
    c.r[8] = c.r[2];  // 06036F4E mov r2,r8
L_06036F50:
    c.r[8] += 1;  // 06036F50 add #1,r8
    c.r[10] = c.r[8] & 0xFFu;  // 06036F52 extu.b r8,r10
    c.r[5] = 0x1u;  // 06036F54 mov #1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06036F5Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036F5Au) return; }  // 06036F56 jsr @r11 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036F5A tst r0,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_06036F94; } }  // 06036F5C bf/s 0x06036F94 ; mov #0,r5
    c.r[1] = ld32(0x06037070u);  // 06036F60 mov.l 0x06037070,r1
    c.r[3] = ld32(c.r[1]);  // 06036F62 mov.l @r1,r3
    c.r[0] = c.r[3];  // 06036F64 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06036F66 mov.b @(r0,r9),r2
    c.r[1] = c.r[2];  // 06036F68 mov r2,r1
    c.r[1] += 1;  // 06036F6A add #1,r1
    st8(c.r[0] + c.r[9], c.r[1]);  // 06036F6C mov.b r1,@(r0,r9)
    c.r[7] = c.r[2] & 0xFFu;  // 06036F6E extu.b r2,r7
    c.r[7] += c.r[7];  // 06036F70 add r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603705Eu);  // 06036F72 mov.w 0x0603705E,r1
    c.r[1] |= c.r[8];  // 06036F74 or r8,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06036F76 extu.w r1,r1
    c.r[6] = c.r[1];  // 06036F78 mov r1,r6
    c.r[6] >>= 8;  // 06036F7A shlr8 r6
    c.r[0] = 0x7Fu;  // 06036F7C mov #127,r0
    c.r[6] &= c.r[0];  // 06036F7E and r0,r6
    c.r[0] = c.r[3];  // 06036F80 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06036F82 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037060u);  // 06036F84 mov.w 0x06037060,r0
    c.r[2] &= c.r[0];  // 06036F86 and r0,r2
    c.r[2] |= c.r[6];  // 06036F88 or r6,r2
    c.r[0] = c.r[3];  // 06036F8A mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06036F8C mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06036F8E add r7,r3
    c.r[3] += 1;  // 06036F90 add #1,r3
    st8(c.r[3], c.r[1]);  // 06036F92 mov.b r1,@r3
L_06036F94:
    { const uint32_t x = c.r[11]; c.pr = 0x06036F98u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06036F98u) return; }  // 06036F94 jsr @r11 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036F98 tst r0,r0
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_06036FD0; } }  // 06036F9A bf/s 0x06036FD0 ; mov r8,r2
    c.r[1] = ld32(0x06037070u);  // 06036F9E mov.l 0x06037070,r1
    c.r[3] = ld32(c.r[1]);  // 06036FA0 mov.l @r1,r3
    c.r[0] = c.r[3];  // 06036FA2 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06036FA4 mov.b @(r0,r9),r2
    c.r[1] = c.r[2];  // 06036FA6 mov r2,r1
    c.r[1] += 1;  // 06036FA8 add #1,r1
    st8(c.r[0] + c.r[9], c.r[1]);  // 06036FAA mov.b r1,@(r0,r9)
    c.r[7] = c.r[2] & 0xFFu;  // 06036FAC extu.b r2,r7
    c.r[7] += c.r[7];  // 06036FAE add r7,r7
    c.r[1] = c.r[8] & 0xFFFFu;  // 06036FB0 extu.w r8,r1
    c.r[6] = c.r[1];  // 06036FB2 mov r1,r6
    c.r[6] >>= 8;  // 06036FB4 shlr8 r6
    c.r[0] = 0x7Fu;  // 06036FB6 mov #127,r0
    c.r[6] &= c.r[0];  // 06036FB8 and r0,r6
    c.r[0] = c.r[3];  // 06036FBA mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06036FBC mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037060u);  // 06036FBE mov.w 0x06037060,r0
    c.r[2] &= c.r[0];  // 06036FC0 and r0,r2
    c.r[2] |= c.r[6];  // 06036FC2 or r6,r2
    c.r[0] = c.r[3];  // 06036FC4 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06036FC6 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06036FC8 add r7,r3
    c.r[3] += 1;  // 06036FCA add #1,r3
    st8(c.r[3], c.r[1]);  // 06036FCC mov.b r1,@r3
    c.r[2] = c.r[8];  // 06036FCE mov r8,r2
L_06036FD0:
    c.r[1] = 0x61u;  // 06036FD0 mov #97,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06036FD2 cmp/gt r1,r2
    { const bool k = !c.t; c.r[8] = c.r[2]; if (k) { SH2_POLL(c); goto L_06036F50; } }  // 06036FD4 bf/s 0x06036F50 ; mov r2,r8
    c.r[1] = ld32(0x06037068u);  // 06036FD8 mov.l 0x06037068,r1
L_06036FDA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036FDA mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036FDC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036FDE tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036FDA; }  // 06036FE0 bf 0x06036FDA
    c.r[1] = 0x1u;  // 06036FE2 mov #1,r1
    c.r[3] = ld32(0x06037068u);  // 06036FE4 mov.l 0x06037068,r3
    st8(c.r[3], c.r[1]);  // 06036FE6 mov.b r1,@r3
    c.r[2] = ld32(0x0603706Cu);  // 06036FE8 mov.l 0x0603706C,r2
    c.r[1] = 0x19u;  // 06036FEA mov #25,r1
    st8(c.r[2], c.r[1]);  // 06036FEC mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06036FEE mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06036FF0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036FF2 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06037000; } }  // 06036FF4 bt/s 0x06037000 ; mov r3,r1
L_06036FF8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06036FF8 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06036FFA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06036FFC tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06036FF8; }  // 06036FFE bf 0x06036FF8
L_06037000:
    c.r[2] = ld32(0x06037078u);  // 06037000 mov.l 0x06037078,r2
    c.r[1] = ld32(0x06037070u);  // 06037002 mov.l 0x06037070,r1
    c.r[6] = ld32(c.r[1]);  // 06037004 mov.l @r1,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603705Cu);  // 06037006 mov.w 0x0603705C,r5
    c.r[0] = c.r[6];  // 06037008 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0603700A mov.b @(r0,r5),r1
    c.r[7] = ld32(0x0603707Cu);  // 0603700C mov.l 0x0603707C,r7
    c.r[3] = c.r[1] & 0xFFu;  // 0603700E extu.b r1,r3
    st32(c.r[7] + 4, c.r[3]);  // 06037010 mov.l r3,@(4,r7)
    st8(c.r[2], c.r[3]);  // 06037012 mov.b r3,@r2
    c.r[1] = ld32(0x06037080u);  // 06037014 mov.l 0x06037080,r1
    c.r[2] = ld32(c.r[1]);  // 06037016 mov.l @r1,r2
    c.r[1] = ld32(0x06037084u);  // 06037018 mov.l 0x06037084,r1
    c.r[1] = ld32(c.r[1]);  // 0603701A mov.l @r1,r1
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0603701C dmulu.l r1,r2
    c.r[1] = c.mach;  // 0603701E sts mach,r1
    c.r[1] >>= 8;  // 06037020 shlr8 r1
    c.r[1] >>= 2;  // 06037022 shlr2 r1
    c.r[1] >>= 2;  // 06037024 shlr2 r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 06037026 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06037028 cmp/pz r1
    if (c.t) { goto L_0603702E; }  // 0603702A bt 0x0603702E
    c.r[1] = 0x0u;  // 0603702C mov #0,r1
L_0603702E:
    c.r[1] += c.r[3];  // 0603702E add r3,r1
    c.r[2] = 0x62u;  // 06037030 mov #98,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06037032 cmp/gt r2,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_0603703A; } }  // 06037034 bf/s 0x0603703A ; mov.l r1,@r7
    st32(c.r[7], c.r[2]);  // 06037038 mov.l r2,@r7
L_0603703A:
    c.r[0] = c.r[6];  // 0603703A mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0603703C mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603703E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037040 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0603704C; } }  // 06037042 bf/s 0x0603704C ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037062u);  // 06037046 mov.w 0x06037062,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06037050;  // 06037048 bra 0x06037050 ; lds.l @r15+,pr
L_0603704C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037064u);  // 0603704C mov.w 0x06037064,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603704E lds.l @r15+,pr
L_06037050:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06037050 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06037052 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037054 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037056 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037058 rts ; mov.l @r15+,r8
}

void f_06037088(SH2Context& c) {
    ran[788] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037088 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603708A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603708C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603708E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06037090 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06037092 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037094 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037096 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603711Eu);  // 06037098 mov.w 0x0603711E,r3
    c.r[15] += c.r[3];  // 0603709A add r3,r15
    c.r[14] = c.r[15];  // 0603709C mov r15,r14
    c.r[2] = ld32(0x06037124u);  // 0603709E mov.l 0x06037124,r2
    c.r[1] = ld32(0x06037128u);  // 060370A0 mov.l 0x06037128,r1
    st32(c.r[2], c.r[1]);  // 060370A2 mov.l r1,@r2
    c.r[1] = ld32(0x0603712Cu);  // 060370A4 mov.l 0x0603712C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060370A6 mov.b @r1,r0
    c.r[13] = ld32(0x06037130u);  // 060370A8 mov.l 0x06037130,r13
    c.r[10] = c.r[14]; goto L_060370B0;  // 060370AA bra 0x060370B0 ; mov r14,r10
L_060370AE:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060370AE mov.b @r1,r0
L_060370B0:
    c.r[0] &= 0x1u;  // 060370B0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060370B2 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060370AE; }  // 060370B4 bf 0x060370AE
    c.r[1] = 0x1u;  // 060370B6 mov #1,r1
    c.r[3] = ld32(0x0603712Cu);  // 060370B8 mov.l 0x0603712C,r3
    st8(c.r[3], c.r[1]);  // 060370BA mov.b r1,@r3
    c.r[2] = ld32(0x06037134u);  // 060370BC mov.l 0x06037134,r2
    c.r[1] = 0x1Au;  // 060370BE mov #26,r1
    st8(c.r[2], c.r[1]);  // 060370C0 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060370C2 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060370C4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060370C6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060370D4; } }  // 060370C8 bt/s 0x060370D4 ; mov r3,r1
L_060370CC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060370CC mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060370CE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060370D0 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060370CC; }  // 060370D2 bf 0x060370CC
L_060370D4:
    c.r[9] = 0x0u;  // 060370D4 mov #0,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037120u);  // 060370D6 mov.w 0x06037120,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 060370D8 mov.l r9,@(r0,r14)
    c.r[1] = ld32(0x06037138u);  // 060370DA mov.l 0x06037138,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037120u);  // 060370DC mov.w 0x06037120,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060370DE mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060370E0 mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 060370E2 extu.b r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 060370E4 cmp/ge r1,r0
    if (!c.t) { goto L_060370EC; }  // 060370E6 bf 0x060370EC
    goto L_060372F8;  // 060370E8 bra 0x060372F8 ; nop
L_060370EC:
    c.r[11] = 0x0u;  // 060370EC mov #0,r11
    c.r[12] = 0x0u;  // 060370EE mov #0,r12
L_060370F0:
    c.r[1] = ld32(0x0603713Cu);  // 060370F0 mov.l 0x0603713C,r1
    c.r[1] = ld32(c.r[1]);  // 060370F2 mov.l @r1,r1
    c.r[9] = 0x7Fu;  // 060370F4 mov #127,r9
    c.r[0] = c.r[1];  // 060370F6 mov r1,r0
    c.r[1] += c.r[12];  // 060370F8 add r12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060370FA mov.b @(r0,r12),r2
    c.r[1] += 1;  // 060370FC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060370FE mov.b @r1,r1
    c.r[2] &= c.r[9];  // 06037100 and r9,r2
    c.r[2] <<= 8;  // 06037102 shll8 r2
    c.r[8] = c.r[1] & 0xFFu;  // 06037104 extu.b r1,r8
    c.r[8] |= c.r[2];  // 06037106 or r2,r8
    c.r[1] = c.r[8];  // 06037108 mov r8,r1
    c.r[1] >>= 8;  // 0603710A shlr8 r1
    c.r[1] <<= 2;  // 0603710C shll2 r1
    c.r[1] >>= 8;  // 0603710E shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037110 tst r1,r1
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06037140; } }  // 06037112 bt/s 0x06037140 ; mov #0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037122u);  // 06037116 mov.w 0x06037122,r1
    c.r[8] &= c.r[1];  // 06037118 and r1,r8
    c.r[9] = 0x1u; goto L_06037140;  // 0603711A bra 0x06037140 ; mov #1,r9
L_06037140:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603729Au);  // 06037140 mov.w 0x0603729A,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 06037142 mov.l r9,@(r0,r14)
    c.r[4] = c.r[8] & 0xFFu;  // 06037144 extu.b r8,r4
    c.r[7] = 0x0u;  // 06037146 mov #0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603729Au);  // 06037148 mov.w 0x0603729A,r0
    c.r[0] += c.r[14];  // 0603714A add r14,r0
    c.r[5] = c.r[14];  // 0603714C mov r14,r5
    c.r[9] = ld32(0x060372A4u);  // 0603714E mov.l 0x060372A4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06037154u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037154u) return; }  // 06037150 jsr @r9 ; mov.l @r0,r6
    c.r[13] = c.r[0];  // 06037154 mov r0,r13
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603729Cu);  // 06037156 mov.w 0x0603729C,r5
    c.r[0] = ld32(0x060372A8u);  // 06037158 mov.l 0x060372A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603715Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603715Eu) return; }  // 0603715A jsr @r0 ; mov r14,r4
    c.r[1] = ld32(c.r[14]);  // 0603715E mov.l @r14,r1
    c.r[2] = c.r[0];  // 06037160 mov r0,r2
    c.t = c.r[2] == c.r[1];  // 06037162 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0603716C; } }  // 06037164 bf/s 0x0603716C ; tst r2,r2
    { const bool k = !c.t; c.r[4] = c.r[8] & 0xFFu; if (k) { goto L_06037172; } }  // 06037168 bf/s 0x06037172 ; extu.b r8,r4
L_0603716C:
    c.r[9] = 0x1u;  // 0603716C mov #1,r9
    c.r[13] |= c.r[9];  // 0603716E or r9,r13
    c.r[4] = c.r[8] & 0xFFu;  // 06037170 extu.b r8,r4
L_06037172:
    c.r[6] = 0x0u;  // 06037172 mov #0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603729Au);  // 06037174 mov.w 0x0603729A,r0
    c.r[0] += c.r[14];  // 06037176 add r14,r0
    c.r[9] = ld32(0x060372ACu);  // 06037178 mov.l 0x060372AC,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0603717Eu; c.r[5] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603717Eu) return; }  // 0603717A jsr @r9 ; mov.l @r0,r5
    c.r[1] = c.r[0];  // 0603717E mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037180 tst r1,r1
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0603718C; } }  // 06037182 bt/s 0x0603718C ; tst r13,r13
    c.r[0] = 0x2u;  // 06037186 mov #2,r0
    c.r[13] |= c.r[0];  // 06037188 or r0,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 0603718A tst r13,r13
L_0603718C:
    { const bool k = c.t; c.r[9] = 0x7Fu; if (k) { goto L_06037194; } }  // 0603718C bt/s 0x06037194 ; mov #127,r9
    goto L_060372BC;  // 06037190 bra 0x060372BC ; nop
L_06037194:
    c.r[1] = ld32(0x060372B0u);  // 06037194 mov.l 0x060372B0,r1
    c.r[3] = c.r[11];  // 06037196 mov r11,r3
    c.r[1] = ld32(c.r[1]);  // 06037198 mov.l @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603729Eu);  // 0603719A mov.w 0x0603729E,r5
    c.r[0] = c.r[1];  // 0603719C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0603719E mov.b @(r0,r12),r2
    c.r[6] = 0x7Fu;  // 060371A0 mov #127,r6
    c.r[2] &= c.r[9];  // 060371A2 and r9,r2
    st8(c.r[0] + c.r[12], c.r[2]);  // 060371A4 mov.b r2,@(r0,r12)
    c.r[0] = ld32(0x060372B4u);  // 060371A6 mov.l 0x060372B4,r0
    c.r[7] = ld32(c.r[0]);  // 060371A8 mov.l @r0,r7
    c.r[2] = ld32(0x060372B8u);  // 060371AA mov.l 0x060372B8,r2
    c.r[1] = ld32(c.r[2]);  // 060371AC mov.l @r2,r1
    c.r[0] = c.r[11];  // 060371AE mov r11,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 060371B0 mov.l r1,@(r0,r7)
    c.r[1] = ld32(c.r[2] + 4);  // 060371B2 mov.l @(4,r2),r1
    c.r[3] += c.r[7];  // 060371B4 add r7,r3
    st32(c.r[3] + 4, c.r[1]);  // 060371B6 mov.l r1,@(4,r3)
    c.r[1] = c.r[10];  // 060371B8 mov r10,r1
    c.r[1] += 10;  // 060371BA add #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060371BC mov.w @r1,r2
    c.r[9] = ld32(0x060372B4u);  // 060371BE mov.l 0x060372B4,r9
    c.r[2] = c.r[2] & 0xFFFFu;  // 060371C0 extu.w r2,r2
    c.r[1] = c.r[10];  // 060371C2 mov r10,r1
    c.r[1] += 12;  // 060371C4 add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060371C6 mov.b @r1,r1
    c.r[2] <<= 8;  // 060371C8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060371CA extu.b r1,r1
    c.r[1] |= c.r[2];  // 060371CC or r2,r1
    st32(c.r[3] + 8, c.r[1]);  // 060371CE mov.l r1,@(8,r3)
    c.r[2] = c.r[3];  // 060371D0 mov r3,r2
    c.r[1] = c.r[10];  // 060371D2 mov r10,r1
    c.r[1] += 14;  // 060371D4 add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060371D6 mov.w @r1,r1
    c.r[2] += 12;  // 060371D8 add #12,r2
    st16(c.r[2], c.r[1]);  // 060371DA mov.w r1,@r2
    c.r[2] = c.r[3];  // 060371DC mov r3,r2
    c.r[1] = c.r[10];  // 060371DE mov r10,r1
    c.r[1] += 52;  // 060371E0 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060371E2 mov.w @r1,r1
    c.r[2] += 14;  // 060371E4 add #14,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060371E6 extu.w r1,r1
    c.r[1] >>= 2;  // 060371E8 shlr2 r1
    c.r[1] >>= 2;  // 060371EA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060371EC shlr r1
    c.r[1] >>= 2;  // 060371EE shlr2 r1
    st16(c.r[2], c.r[1]);  // 060371F0 mov.w r1,@r2
    c.r[1] = c.r[10];  // 060371F2 mov r10,r1
    c.r[1] += 5;  // 060371F4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060371F6 mov.b @r1,r1
    c.r[3] += 36;  // 060371F8 add #36,r3
    st8(c.r[3], c.r[1]);  // 060371FA mov.b r1,@r3
    c.r[1] = c.r[10];  // 060371FC mov r10,r1
    c.r[2] = ld32(c.r[9]);  // 060371FE mov.l @r9,r2
    c.r[1] += 7;  // 06037200 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037202 mov.b @r1,r1
    c.r[2] += c.r[11];  // 06037204 add r11,r2
    c.r[2] += 38;  // 06037206 add #38,r2
    st8(c.r[2], c.r[1]);  // 06037208 mov.b r1,@r2
    c.r[1] = c.r[10];  // 0603720A mov r10,r1
    c.r[2] = ld32(c.r[9]);  // 0603720C mov.l @r9,r2
    c.r[1] += 6;  // 0603720E add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037210 mov.b @r1,r1
    c.r[2] += c.r[11];  // 06037212 add r11,r2
    c.r[2] += 39;  // 06037214 add #39,r2
    st8(c.r[2], c.r[1]);  // 06037216 mov.b r1,@r2
    c.r[2] = ld32(c.r[9]);  // 06037218 mov.l @r9,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060372A0u);  // 0603721A mov.w 0x060372A0,r7
    c.r[1] = ld32(c.r[10] + 60);  // 0603721C mov.l @(60,r10),r1
    c.r[2] += c.r[11];  // 0603721E add r11,r2
    st32(c.r[2] + 16, c.r[1]);  // 06037220 mov.l r1,@(16,r2)
    c.r[1] = c.r[10];  // 06037222 mov r10,r1
    c.r[1] += 64;  // 06037224 add #64,r1
    c.r[1] = ld32(c.r[1]);  // 06037226 mov.l @r1,r1
    c.r[7] += c.r[14];  // 06037228 add r14,r7
    st32(c.r[2] + 20, c.r[1]);  // 0603722A mov.l r1,@(20,r2)
    c.r[1] = c.r[10];  // 0603722C mov r10,r1
    c.r[1] += 68;  // 0603722E add #68,r1
    c.r[1] = ld32(c.r[1]);  // 06037230 mov.l @r1,r1
    c.r[3] = c.r[2];  // 06037232 mov r2,r3
    st32(c.r[2] + 24, c.r[1]);  // 06037234 mov.l r1,@(24,r2)
    c.r[1] = c.r[10];  // 06037236 mov r10,r1
    c.r[1] += 72;  // 06037238 add #72,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603723A mov.w @r1,r1
    c.r[3] += 28;  // 0603723C add #28,r3
    st16(c.r[3], c.r[1]);  // 0603723E mov.w r1,@r3
    c.r[3] = c.r[2];  // 06037240 mov r2,r3
    c.r[1] = c.r[10];  // 06037242 mov r10,r1
    c.r[1] += 74;  // 06037244 add #74,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037246 mov.w @r1,r1
    c.r[3] += 30;  // 06037248 add #30,r3
    st16(c.r[3], c.r[1]);  // 0603724A mov.w r1,@r3
    c.r[3] = c.r[2];  // 0603724C mov r2,r3
    c.r[1] = c.r[10];  // 0603724E mov r10,r1
    c.r[1] += 76;  // 06037250 add #76,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037252 mov.w @r1,r1
    c.r[3] += 32;  // 06037254 add #32,r3
    st16(c.r[3], c.r[1]);  // 06037256 mov.w r1,@r3
    c.r[3] = c.r[2];  // 06037258 mov r2,r3
    c.r[3] += 34;  // 0603725A add #34,r3
    c.r[1] = c.r[10];  // 0603725C mov r10,r1
    c.r[1] += 78;  // 0603725E add #78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037260 mov.w @r1,r1
    c.r[2] += 37;  // 06037262 add #37,r2
    st16(c.r[3], c.r[1]);  // 06037264 mov.w r1,@r3
    c.r[1] = 0x0u;  // 06037266 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06037268 mov.b r1,@r2
    c.r[2] = 0x0u;  // 0603726A mov #0,r2
    c.r[3] = 0x0u;  // 0603726C mov #0,r3
L_0603726E:
    c.r[4] = c.r[3];  // 0603726E mov r3,r4
    c.r[0] = c.r[4];  // 06037270 mov r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06037272 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06037274 extu.w r1,r1
    c.t = c.r[1] == c.r[5];  // 06037276 cmp/eq r5,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06037286; } }  // 06037278 bt/s 0x06037286 ; add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0603727C cmp/gt r6,r2
    { const bool k = !c.t; c.r[3] += 12; if (k) { SH2_POLL(c); goto L_0603726E; } }  // 0603727E bf/s 0x0603726E ; add #12,r3
    c.r[11] += 40; goto L_060372DA;  // 06037282 bra 0x060372DA ; add #40,r11
L_06037286:
    c.r[9] = ld32(0x060372B4u);  // 06037286 mov.l 0x060372B4,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060372A2u);  // 06037288 mov.w 0x060372A2,r1
    c.r[1] += c.r[14];  // 0603728A add r14,r1
    c.r[2] = ld32(c.r[9]);  // 0603728C mov.l @r9,r2
    c.r[0] = c.r[1];  // 0603728E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06037290 mov.b @(r0,r3),r1
    c.r[2] += c.r[11];  // 06037292 add r11,r2
    c.r[2] += 37;  // 06037294 add #37,r2
    st8(c.r[2], c.r[1]); goto L_060372D8;  // 06037296 bra 0x060372D8 ; mov.b r1,@r2
L_060372BC:
    c.r[1] = ld32(0x06037354u);  // 060372BC mov.l 0x06037354,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0603734Cu);  // 060372BE mov.w 0x0603734C,r9
    c.r[1] = ld32(c.r[1]);  // 060372C0 mov.l @r1,r1
    c.r[6] = 0x28u;  // 060372C2 mov #40,r6
    c.r[0] = c.r[1];  // 060372C4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060372C6 mov.b @(r0,r12),r2
    c.r[5] = 0x0u;  // 060372C8 mov #0,r5
    c.r[2] |= c.r[9];  // 060372CA or r9,r2
    st8(c.r[0] + c.r[12], c.r[2]);  // 060372CC mov.b r2,@(r0,r12)
    c.r[0] = ld32(0x06037358u);  // 060372CE mov.l 0x06037358,r0
    c.r[4] = ld32(c.r[0]);  // 060372D0 mov.l @r0,r4
    c.r[9] = ld32(0x0603735Cu);  // 060372D2 mov.l 0x0603735C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060372D8u; c.r[4] += c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060372D8u) return; }  // 060372D4 jsr @r9 ; add r11,r4
L_060372D8:
    c.r[11] += 40;  // 060372D8 add #40,r11
L_060372DA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603734Eu);  // 060372DA mov.w 0x0603734E,r0
    c.r[0] += c.r[14];  // 060372DC add r14,r0
    c.r[9] = ld32(c.r[0]);  // 060372DE mov.l @r0,r9
    c.r[1] = ld32(0x06037360u);  // 060372E0 mov.l 0x06037360,r1
    c.r[9] += 1;  // 060372E2 add #1,r9
    st32(c.r[0], c.r[9]);  // 060372E4 mov.l r9,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603734Eu);  // 060372E6 mov.w 0x0603734E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060372E8 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060372EA mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 060372EC extu.b r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 060372EE cmp/ge r1,r0
    { const bool k = c.t; c.r[12] += 2; if (k) { goto L_060372F8; } }  // 060372F0 bt/s 0x060372F8 ; add #2,r12
    SH2_POLL(c); goto L_060370F0;  // 060372F4 bra 0x060370F0 ; nop
L_060372F8:
    c.r[1] = ld32(0x06037364u);  // 060372F8 mov.l 0x06037364,r1
L_060372FA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060372FA mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060372FC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060372FE tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060372FA; }  // 06037300 bf 0x060372FA
    c.r[1] = 0x1u;  // 06037302 mov #1,r1
    c.r[3] = ld32(0x06037364u);  // 06037304 mov.l 0x06037364,r3
    st8(c.r[3], c.r[1]);  // 06037306 mov.b r1,@r3
    c.r[2] = ld32(0x06037368u);  // 06037308 mov.l 0x06037368,r2
    c.r[1] = 0x19u;  // 0603730A mov #25,r1
    st8(c.r[2], c.r[1]);  // 0603730C mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603730E mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06037310 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06037312 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06037320; } }  // 06037314 bt/s 0x06037320 ; mov r3,r1
L_06037318:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037318 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603731A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603731C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06037318; }  // 0603731E bf 0x06037318
L_06037320:
    c.r[1] = ld32(0x0603736Cu);  // 06037320 mov.l 0x0603736C,r1
    c.t = c.r[13] == c.r[1];  // 06037322 cmp/eq r1,r13
    if (!c.t) { goto L_0603732C; }  // 06037324 bf 0x0603732C
    c.r[1] = ld32(0x06037370u);  // 06037326 mov.l 0x06037370,r1
    goto L_0603732E;  // 06037328 bra 0x0603732E ; nop
L_0603732C:
    c.r[1] = ld32(0x06037374u);  // 0603732C mov.l 0x06037374,r1
L_0603732E:
    { const uint32_t x = c.r[1]; c.pr = 0x06037332u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037332u) return; }  // 0603732E jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x06037350u);  // 06037332 mov.w 0x06037350,r3
    c.r[14] += c.r[3];  // 06037334 add r3,r14
    c.r[15] = c.r[14];  // 06037336 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06037338 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603733A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603733C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603733E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06037340 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037342 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037344 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037352u);  // 06037346 mov.w 0x06037352,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037348 rts ; mov.l @r15+,r8
}

void f_06037378(SH2Context& c) {
    ran[789] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037378 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603737A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603737C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603737E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037380 sts.l pr,@-r15
    c.r[1] = ld32(0x06037434u);  // 06037382 mov.l 0x06037434,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037384 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06037386 extu.b r1,r7
    c.r[1] = ld32(0x06037438u);  // 06037388 mov.l 0x06037438,r1
    c.r[0] = c.r[7];  // 0603738A mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603738C mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603738E extu.b r2,r2
    c.r[2] -= 1;  // 06037390 add #-1,r2
    c.r[1] = 0x7u;  // 06037392 mov #7,r1
    c.macl = c.r[2] * c.r[1];  // 06037394 mul.l r1,r2
    c.r[3] = ld32(0x0603743Cu);  // 06037396 mov.l 0x0603743C,r3
    c.r[1] = ld32(0x06037440u);  // 06037398 mov.l 0x06037440,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603739A mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0603739C sts macl,r2
    c.r[2] += c.r[1];  // 0603739E add r1,r2
    st8(c.r[3], c.r[2]);  // 060373A0 mov.b r2,@r3
    c.r[1] = ld32(0x06037444u);  // 060373A2 mov.l 0x06037444,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060373A4 extu.b r2,r2
    c.r[1] = ld32(c.r[1]);  // 060373A6 mov.l @r1,r1
    c.r[2] += c.r[2];  // 060373A8 add r2,r2
    c.r[0] = c.r[1];  // 060373AA mov r1,r0
    c.r[1] += c.r[2];  // 060373AC add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060373AE mov.b @(r0,r2),r3
    c.r[1] += 1;  // 060373B0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060373B2 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 060373B4 mov #127,r0
    c.r[3] &= c.r[0];  // 060373B6 and r0,r3
    c.r[3] <<= 8;  // 060373B8 shll8 r3
    c.r[9] = c.r[1] & 0xFFu;  // 060373BA extu.b r1,r9
    c.r[9] |= c.r[3];  // 060373BC or r3,r9
    c.r[1] = c.r[9];  // 060373BE mov r9,r1
    c.r[1] >>= 8;  // 060373C0 shlr8 r1
    c.r[1] <<= 2;  // 060373C2 shll2 r1
    c.r[1] >>= 8;  // 060373C4 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060373C6 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060373D4; } }  // 060373C8 bt/s 0x060373D4 ; mov r15,r14
    c.r[10] = 0x1u;  // 060373CC mov #1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603742Au);  // 060373CE mov.w 0x0603742A,r1
    c.r[9] &= c.r[1]; goto L_060373D6;  // 060373D0 bra 0x060373D6 ; and r1,r9
L_060373D4:
    c.r[10] = 0x0u;  // 060373D4 mov #0,r10
L_060373D6:
    c.r[4] = c.r[9] & 0xFFu;  // 060373D6 extu.b r9,r4
    c.r[0] = ld32(0x06037448u);  // 060373D8 mov.l 0x06037448,r0
    c.r[7] = 0x1u;  // 060373DA mov #1,r7
    c.r[6] = c.r[10];  // 060373DC mov r10,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060373E2u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060373E2u) return; }  // 060373DE jsr @r0 ; mov #0,r5
    c.r[8] = c.r[0];  // 060373E2 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060373E4 tst r8,r8
    { const bool k = !c.t; c.r[2] = 0x48u; if (k) { goto L_06037406; } }  // 060373E6 bf/s 0x06037406 ; mov #72,r2
    c.r[1] = ld32(0x0603744Cu);  // 060373EA mov.l 0x0603744C,r1
    c.r[1] = ld32(c.r[1]);  // 060373EC mov.l @r1,r1
    c.r[1] += 6;  // 060373EE add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060373F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060373F2 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 060373F4 cmp/hi r2,r1
    { const bool k = c.t; c.r[4] = c.r[9] & 0xFFu; if (k) { goto L_06037408; } }  // 060373F6 bt/s 0x06037408 ; extu.b r9,r4
    c.t = (c.r[10] & c.r[10]) == 0;  // 060373FA tst r10,r10
    if (!c.t) { goto L_06037408; }  // 060373FC bf 0x06037408
    c.r[15] = c.r[14];  // 060373FE mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603742Cu);  // 06037400 mov.w 0x0603742C,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06037420;  // 06037402 bra 0x06037420 ; lds.l @r15+,pr
L_06037406:
    c.r[4] = c.r[9] & 0xFFu;  // 06037406 extu.b r9,r4
L_06037408:
    c.r[0] = ld32(0x06037450u);  // 06037408 mov.l 0x06037450,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603740Eu; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603740Eu) return; }  // 0603740A jsr @r0 ; mov r10,r5
    c.r[0] += c.r[8];  // 0603740E add r8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06037410 tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0603741C; } }  // 06037412 bf/s 0x0603741C ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603742Eu);  // 06037416 mov.w 0x0603742E,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06037420;  // 06037418 bra 0x06037420 ; lds.l @r15+,pr
L_0603741C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037430u);  // 0603741C mov.w 0x06037430,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603741E lds.l @r15+,pr
L_06037420:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06037420 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037422 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037424 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037426 rts ; mov.l @r15+,r8
}

void f_06037454(SH2Context& c) {
    ran[790] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037454 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037456 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037458 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603745A mov r15,r14
    c.r[1] = ld32(0x06037548u);  // 0603745C mov.l 0x06037548,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037462u; c.r[8] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037462u) return; }  // 0603745E jsr @r1 ; extu.b r4,r8
    c.r[1] = ld32(0x0603754Cu);  // 06037462 mov.l 0x0603754C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037468u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037468u) return; }  // 06037464 jsr @r1 ; nop
    c.r[1] = ld32(0x06037550u);  // 06037468 mov.l 0x06037550,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603746Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603746Eu) return; }  // 0603746A jsr @r1 ; nop
    c.r[1] = ld32(0x06037554u);  // 0603746E mov.l 0x06037554,r1
    c.r[2] = ld32(c.r[1]);  // 06037470 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037544u);  // 06037472 mov.w 0x06037544,r1
    c.r[0] = c.r[2];  // 06037474 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06037476 mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 06037478 mov #4,r0
    c.r[1] &= c.r[0];  // 0603747A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603747C tst r1,r1
    if (!c.t) { goto L_0603748E; }  // 0603747E bf 0x0603748E
    c.r[0] = c.r[2];  // 06037480 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037546u);  // 06037482 mov.w 0x06037546,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06037484 mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 06037486 mov #4,r0
    c.r[1] &= c.r[0];  // 06037488 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603748A tst r1,r1
    if (c.t) { goto L_06037498; }  // 0603748C bt 0x06037498
L_0603748E:
    c.r[1] = ld32(0x06037558u);  // 0603748E mov.l 0x06037558,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037490 mov.b @r1,r0
    c.r[0] |= 0x28u;  // 06037492 or #40,r0
    c.r[0] &= 0xFBu; goto L_0603749E;  // 06037494 bra 0x0603749E ; and #251,r0
L_06037498:
    c.r[1] = ld32(0x06037558u);  // 06037498 mov.l 0x06037558,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603749A mov.b @r1,r0
    c.r[0] &= 0xD3u;  // 0603749C and #211,r0
L_0603749E:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0603749E tst r8,r8
    { const bool k = c.t; st8(c.r[1], c.r[0]); if (k) { goto L_060374F6; } }  // 060374A0 bt/s 0x060374F6 ; mov.b r0,@r1
    c.r[1] = ld32(0x0603755Cu);  // 060374A4 mov.l 0x0603755C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060374A6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060374A8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060374AA tst r1,r1
    if (!c.t) { goto L_060374D2; }  // 060374AC bf 0x060374D2
    c.r[1] = ld32(0x06037558u);  // 060374AE mov.l 0x06037558,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060374B0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060374B2 mov r1,r0
    c.r[0] >>= 2;  // 060374B4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060374B6 shlr r0
    c.r[0] &= 0x1u;  // 060374B8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060374BA tst r0,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060374C8; } }  // 060374BC bt/s 0x060374C8 ; mov #0,r5
    c.r[6] = ld32(0x06037560u);  // 060374C0 mov.l 0x06037560,r6
    c.r[1] = ld32(0x06037564u);  // 060374C2 mov.l 0x06037564,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060374C8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060374C8u) return; }  // 060374C4 jsr @r1 ; mov #0,r4
L_060374C8:
    c.r[6] = ld32(0x06037568u);  // 060374C8 mov.l 0x06037568,r6
    c.r[1] = ld32(0x06037564u);  // 060374CA mov.l 0x06037564,r1
    c.r[5] = 0x8u;  // 060374CC mov #8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060374D2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060374D2u) return; }  // 060374CE jsr @r1 ; mov #0,r4
L_060374D2:
    c.r[1] = ld32(0x0603755Cu);  // 060374D2 mov.l 0x0603755C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060374D4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060374D6 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060374D8 cmp/eq #1,r0
    { const bool k = c.t; c.r[5] = 0x2u; if (k) { goto L_06037522; } }  // 060374DA bt/s 0x06037522 ; mov #2,r5
    c.r[6] = ld32(0x0603756Cu);  // 060374DE mov.l 0x0603756C,r6
    c.r[8] = ld32(0x06037564u);  // 060374E0 mov.l 0x06037564,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060374E6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060374E6u) return; }  // 060374E2 jsr @r8 ; mov #1,r4
    c.r[6] = ld32(0x06037570u);  // 060374E6 mov.l 0x06037570,r6
    c.r[5] = 0x3u;  // 060374E8 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060374EEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060374EEu) return; }  // 060374EA jsr @r8 ; mov #1,r4
    c.r[6] = ld32(0x06037574u);  // 060374EE mov.l 0x06037574,r6
    c.r[5] = 0x2u;  // 060374F0 mov #2,r5
    c.r[4] = 0x0u; goto L_0603751E;  // 060374F2 bra 0x0603751E ; mov #0,r4
L_060374F6:
    c.r[8] = ld32(0x06037564u);  // 060374F6 mov.l 0x06037564,r8
    c.r[6] = 0x0u;  // 060374F8 mov #0,r6
    c.r[5] = 0x0u;  // 060374FA mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06037500u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037500u) return; }  // 060374FC jsr @r8 ; mov #0,r4
    c.r[6] = 0x0u;  // 06037500 mov #0,r6
    c.r[5] = 0x2u;  // 06037502 mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06037508u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037508u) return; }  // 06037504 jsr @r8 ; mov #0,r4
    c.r[6] = 0x0u;  // 06037508 mov #0,r6
    c.r[5] = 0x8u;  // 0603750A mov #8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06037510u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037510u) return; }  // 0603750C jsr @r8 ; mov #0,r4
    c.r[6] = 0x0u;  // 06037510 mov #0,r6
    c.r[5] = 0x2u;  // 06037512 mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06037518u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037518u) return; }  // 06037514 jsr @r8 ; mov #1,r4
    c.r[6] = 0x0u;  // 06037518 mov #0,r6
    c.r[5] = 0x3u;  // 0603751A mov #3,r5
    c.r[4] = 0x1u;  // 0603751C mov #1,r4
L_0603751E:
    { const uint32_t x = c.r[8]; c.pr = 0x06037522u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037522u) return; }  // 0603751E jsr @r8 ; nop
L_06037522:
    c.r[2] = ld32(0x06037578u);  // 06037522 mov.l 0x06037578,r2
    c.r[1] = 0x0u;  // 06037524 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06037526 mov.l r1,@r2
    c.r[1] = ld32(0x06037558u);  // 06037528 mov.l 0x06037558,r1
    c.r[2] = 0x0u;  // 0603752A mov #0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603752C mov.b @r1,r0
    c.r[15] = c.r[14];  // 0603752E mov r14,r15
    c.r[0] |= 0x2u;  // 06037530 or #2,r0
    st8(c.r[1], c.r[0]);  // 06037532 mov.b r0,@r1
    c.r[1] = ld32(0x0603757Cu);  // 06037534 mov.l 0x0603757C,r1
    st16(c.r[1], c.r[2]);  // 06037536 mov.w r2,@r1
    c.r[1] = ld32(0x06037580u);  // 06037538 mov.l 0x06037580,r1
    st16(c.r[1], c.r[2]);  // 0603753A mov.w r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603753C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603753E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037540 rts ; mov.l @r15+,r8
}

void f_06037584(SH2Context& c) {
    ran[791] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037584 mov.l r14,@-r15
    c.r[1] = ld32(0x060376BCu);  // 06037586 mov.l 0x060376BC,r1
    c.r[2] = ld32(c.r[1]);  // 06037588 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060376ACu);  // 0603758A mov.w 0x060376AC,r1
    c.r[0] = c.r[2];  // 0603758C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603758E mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 06037590 mov #4,r0
    c.r[1] &= c.r[0];  // 06037592 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037594 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603759E; } }  // 06037596 bf/s 0x0603759E ; mov r15,r14
    goto L_06037738;  // 0603759A bra 0x06037738 ; nop
L_0603759E:
    c.r[1] = ld32(0x060376C0u);  // 0603759E mov.l 0x060376C0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060375A0 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060376AEu);  // 060375A2 mov.w 0x060376AE,r2
    c.r[2] &= c.r[1];  // 060375A4 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060375A6 tst r2,r2
    if (c.t) { goto L_060375CC; }  // 060375A8 bt 0x060375CC
    c.r[1] = ld32(0x060376C4u);  // 060375AA mov.l 0x060376C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060375AC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060375AE extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060375B0 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_060375CC; } }  // 060375B2 bf/s 0x060375CC ; mov #1,r0
    c.r[1] = ld32(0x060376C8u);  // 060375B6 mov.l 0x060376C8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060375B8 mov.b @r1,r2
    c.r[3] = c.r[2];  // 060375BA mov r2,r3
    c.r[3] >>= 2;  // 060375BC shlr2 r3
    c.r[3] &= c.r[0];  // 060375BE and r0,r3
    c.r[3] ^= c.r[0];  // 060375C0 xor r0,r3
    c.r[3] <<= 2;  // 060375C2 shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060376B0u);  // 060375C4 mov.w 0x060376B0,r0
    c.r[2] &= c.r[0];  // 060375C6 and r0,r2
    c.r[2] |= c.r[3];  // 060375C8 or r3,r2
    st8(c.r[1], c.r[2]);  // 060375CA mov.b r2,@r1
L_060375CC:
    c.r[1] = ld32(0x060376CCu);  // 060375CC mov.l 0x060376CC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060375CE mov.w @r1,r0
    c.r[0] &= 0x8u;  // 060375D0 and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060375D2 tst r0,r0
    if (c.t) { goto L_060375F4; }  // 060375D4 bt 0x060375F4
    c.r[1] = ld32(0x060376C4u);  // 060375D6 mov.l 0x060376C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060375D8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060375DA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060375DC tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x4u; if (k) { goto L_060375F4; } }  // 060375DE bf/s 0x060375F4 ; mov #4,r0
    c.r[1] = ld32(0x060376C8u);  // 060375E2 mov.l 0x060376C8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060375E4 mov.b @r1,r2
    c.r[3] = c.r[2];  // 060375E6 mov r2,r3
    c.r[3] += c.r[3];  // 060375E8 add r3,r3
    c.r[3] &= c.r[0];  // 060375EA and r0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060376B0u);  // 060375EC mov.w 0x060376B0,r0
    c.r[2] &= c.r[0];  // 060375EE and r0,r2
    c.r[2] |= c.r[3];  // 060375F0 or r3,r2
    st8(c.r[1], c.r[2]);  // 060375F2 mov.b r2,@r1
L_060375F4:
    c.r[3] = ld32(0x060376D0u);  // 060375F4 mov.l 0x060376D0,r3
    c.r[1] = c.r[3];  // 060375F6 mov r3,r1
    c.r[1] += 6;  // 060375F8 add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060375FA mov.w @r1,r0
    c.r[0] &= 0x8u;  // 060375FC and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060375FE tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0603761A; } }  // 06037600 bt/s 0x0603761A ; mov #1,r0
    c.r[1] = ld32(0x060376C8u);  // 06037604 mov.l 0x060376C8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037606 mov.b @r1,r2
    c.r[7] = c.r[2];  // 06037608 mov r2,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0603760A shlr r7
    c.r[7] &= c.r[0];  // 0603760C and r0,r7
    c.r[7] ^= c.r[0];  // 0603760E xor r0,r7
    c.r[7] += c.r[7];  // 06037610 add r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060376B2u);  // 06037612 mov.w 0x060376B2,r0
    c.r[2] &= c.r[0];  // 06037614 and r0,r2
    c.r[2] |= c.r[7];  // 06037616 or r7,r2
    st8(c.r[1], c.r[2]);  // 06037618 mov.b r2,@r1
L_0603761A:
    c.r[3] += 4;  // 0603761A add #4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603761C mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060376B4u);  // 0603761E mov.w 0x060376B4,r2
    c.r[2] &= c.r[1];  // 06037620 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06037622 tst r2,r2
    if (c.t) { goto L_0603764C; }  // 06037624 bt 0x0603764C
    c.r[1] = ld32(0x060376C4u);  // 06037626 mov.l 0x060376C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037628 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603762A extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603762C cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0603764C; } }  // 0603762E bf/s 0x0603764C ; mov #1,r0
    c.r[1] = ld32(0x060376C8u);  // 06037632 mov.l 0x060376C8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037634 mov.b @r1,r2
    c.r[3] = c.r[2];  // 06037636 mov r2,r3
    c.r[3] >>= 2;  // 06037638 shlr2 r3
    c.r[3] >>= 2;  // 0603763A shlr2 r3
    c.r[3] &= c.r[0];  // 0603763C and r0,r3
    c.r[3] ^= c.r[0];  // 0603763E xor r0,r3
    c.r[3] <<= 2;  // 06037640 shll2 r3
    c.r[3] <<= 2;  // 06037642 shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060376B6u);  // 06037644 mov.w 0x060376B6,r0
    c.r[2] &= c.r[0];  // 06037646 and r0,r2
    c.r[2] |= c.r[3];  // 06037648 or r3,r2
    st8(c.r[1], c.r[2]);  // 0603764A mov.b r2,@r1
L_0603764C:
    c.r[1] = ld32(0x060376C8u);  // 0603764C mov.l 0x060376C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603764E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06037650 mov r1,r0
    c.r[0] >>= 2;  // 06037652 shlr2 r0
    c.r[0] &= 0x1u;  // 06037654 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06037656 tst r0,r0
    if (c.t) { goto L_06037710; }  // 06037658 bt 0x06037710
    c.r[7] = ld32(0x060376D4u);  // 0603765A mov.l 0x060376D4,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603765C mov.w @r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060376B8u);  // 0603765E mov.w 0x060376B8,r1
    c.r[3] = c.r[2];  // 06037660 mov r2,r3
    c.r[3] &= c.r[1];  // 06037662 and r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x060376BAu);  // 06037664 mov.w 0x060376BA,r2
    c.r[3] &= c.r[2];  // 06037666 and r2,r3
    st16(c.r[7], c.r[3]);  // 06037668 mov.w r3,@r7
    c.r[1] = ld32(0x060376C4u);  // 0603766A mov.l 0x060376C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603766C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603766E extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06037670 cmp/eq #1,r0
    if (!c.t) { goto L_060376DC; }  // 06037672 bf 0x060376DC
    c.r[2] = ld32(0x060376D0u);  // 06037674 mov.l 0x060376D0,r2
    c.r[1] = c.r[2];  // 06037676 mov r2,r1
    c.r[1] += 4;  // 06037678 add #4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603767A mov.w @r1,r0
    c.r[0] &= 0x8u;  // 0603767C and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603767E tst r0,r0
    { const bool k = !c.t; c.r[2] += 2; if (k) { goto L_0603768C; } }  // 06037680 bf/s 0x0603768C ; add #2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037684 mov.w @r2,r0
    c.r[0] &= 0x80u;  // 06037686 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06037688 tst r0,r0
    if (c.t) { goto L_060376FC; }  // 0603768A bt 0x060376FC
L_0603768C:
    c.r[1] = ld32(0x060376D8u);  // 0603768C mov.l 0x060376D8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603768E mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06037690 or #128,r0
    st8(c.r[1], c.r[0]);  // 06037692 mov.b r0,@r1
    c.r[0] = c.r[3];  // 06037694 mov r3,r0
    c.r[0] >>= 8;  // 06037696 shlr8 r0
    c.r[0] &= 0x1u;  // 06037698 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603769A tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_060376A4; } }  // 0603769C bf/s 0x060376A4 ; mov #1,r0
    c.r[3] |= c.r[0];  // 060376A0 or r0,r3
    st16(c.r[7], c.r[3]);  // 060376A2 mov.w r3,@r7
L_060376A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060376A4 mov.w @r7,r0
    c.r[0] |= 0x20u;  // 060376A6 or #32,r0
    st16(c.r[7], c.r[0]); goto L_06037738;  // 060376A8 bra 0x06037738 ; mov.w r0,@r7
L_060376DC:
    c.r[1] = ld32(0x06037744u);  // 060376DC mov.l 0x06037744,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060376DE mov.w @r1,r0
    c.r[0] &= 0x80u;  // 060376E0 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060376E2 tst r0,r0
    if (c.t) { goto L_060376F8; }  // 060376E4 bt 0x060376F8
    c.r[1] = ld32(0x06037748u);  // 060376E6 mov.l 0x06037748,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060376E8 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603773Eu);  // 060376EA mov.w 0x0603773E,r0
    c.r[2] |= c.r[0];  // 060376EC or r0,r2
    st8(c.r[1], c.r[2]);  // 060376EE mov.b r2,@r1
    c.r[0] = 0x20u;  // 060376F0 mov #32,r0
    c.r[3] |= c.r[0];  // 060376F2 or r0,r3
    st16(c.r[7], c.r[3]); goto L_06037738;  // 060376F4 bra 0x06037738 ; mov.w r3,@r7
L_060376F8:
    c.r[3] &= c.r[2];  // 060376F8 and r2,r3
    st16(c.r[7], c.r[3]);  // 060376FA mov.w r3,@r7
L_060376FC:
    c.r[2] = ld32(0x0603774Cu);  // 060376FC mov.l 0x0603774C,r2
    c.r[1] = ld32(c.r[2]);  // 060376FE mov.l @r2,r1
    c.r[1] -= 1;  // 06037700 add #-1,r1
    st32(c.r[2], c.r[1]);  // 06037702 mov.l r1,@r2
    c.r[1] = ld32(c.r[2]);  // 06037704 mov.l @r2,r1
    c.r[1] = ld32(0x06037748u);  // 06037706 mov.l 0x06037748,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037708 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0603770A and #127,r0
    st8(c.r[1], c.r[0]); goto L_06037738;  // 0603770C bra 0x06037738 ; mov.b r0,@r1
L_06037710:
    c.r[2] = ld32(0x06037750u);  // 06037710 mov.l 0x06037750,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037712 mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06037714 extu.w r1,r0
    c.t = c.r[0] == 0x40u;  // 06037716 cmp/eq #64,r0
    if (!c.t) { goto L_0603771E; }  // 06037718 bf 0x0603771E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603773Eu);  // 0603771A mov.w 0x0603773E,r1
    st16(c.r[2], c.r[1]);  // 0603771C mov.w r1,@r2
L_0603771E:
    c.r[1] = ld32(0x06037748u);  // 0603771E mov.l 0x06037748,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037720 mov.b @r1,r0
    c.r[2] = ld32(0x06037754u);  // 06037722 mov.l 0x06037754,r2
    c.r[0] |= 0x80u;  // 06037724 or #128,r0
    st8(c.r[1], c.r[0]);  // 06037726 mov.b r0,@r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037728 mov.w @r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037740u);  // 0603772A mov.w 0x06037740,r1
    c.r[1] &= c.r[3];  // 0603772C and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603772E tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06037738; } }  // 06037730 bf/s 0x06037738 ; mov r3,r0
    c.r[0] |= 0x21u;  // 06037734 or #33,r0
    st16(c.r[2], c.r[0]);  // 06037736 mov.w r0,@r2
L_06037738:
    c.r[15] = c.r[14];  // 06037738 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603773A rts ; mov.l @r15+,r14
}

void f_06037758(SH2Context& c) {
    ran[792] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037758 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603775A sts.l pr,@-r15
    c.r[1] = ld32(0x06037770u);  // 0603775C mov.l 0x06037770,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037762u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037762u) return; }  // 0603775E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06037774u);  // 06037762 mov.l 0x06037774,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037768u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037768u) return; }  // 06037764 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06037768 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603776A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603776C rts ; mov.l @r15+,r14
}

void f_06037778(SH2Context& c) {
    ran[793] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037778 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603777A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603777C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603777E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06037780 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06037782 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037784 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037786 sts.l pr,@-r15
    c.r[15] -= 36;  // 06037788 add #-36,r15
    c.r[1] = ld32(0x06037970u);  // 0603778A mov.l 0x06037970,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603778C mov.b @r1,r1
    c.r[2] = ld32(0x06037974u);  // 0603778E mov.l 0x06037974,r2
    st8(c.r[2], c.r[1]);  // 06037790 mov.b r1,@r2
    c.r[1] = ld32(0x06037978u);  // 06037792 mov.l 0x06037978,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037794 mov.b @r1,r1
    c.r[2] = ld32(0x0603797Cu);  // 06037796 mov.l 0x0603797C,r2
    st8(c.r[2], c.r[1]);  // 06037798 mov.b r1,@r2
    c.r[1] = ld32(0x06037980u);  // 0603779A mov.l 0x06037980,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603779C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603779E extu.b r1,r1
    c.r[1] >>= 2;  // 060377A0 shlr2 r1
    c.r[1] >>= 2;  // 060377A2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060377A4 shlr r1
    c.r[1] >>= 2;  // 060377A6 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060377A8 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060377B2; } }  // 060377AA bf/s 0x060377B2 ; mov r15,r14
    goto L_06037958;  // 060377AE bra 0x06037958 ; nop
L_060377B2:
    c.r[1] = ld32(0x06037984u);  // 060377B2 mov.l 0x06037984,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060377B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060377B8u) return; }  // 060377B4 jsr @r1 ; nop
    c.r[1] = ld32(0x06037988u);  // 060377B8 mov.l 0x06037988,r1
    c.r[10] = ld32(c.r[1]);  // 060377BA mov.l @r1,r10
    c.r[7] = 0x0u;  // 060377BC mov #0,r7
    st32(c.r[14], c.r[7]);  // 060377BE mov.l r7,@r14
    c.r[7] = c.r[10];  // 060377C0 mov r10,r7
    c.r[7] += 10;  // 060377C2 add #10,r7
    st32(c.r[14] + 4, c.r[7]);  // 060377C4 mov.l r7,@(4,r14)
    c.r[7] = c.r[10];  // 060377C6 mov r10,r7
    c.r[7] += 6;  // 060377C8 add #6,r7
    st32(c.r[14] + 8, c.r[7]);  // 060377CA mov.l r7,@(8,r14)
    c.r[9] = c.r[10];  // 060377CC mov r10,r9
    c.r[9] += 4;  // 060377CE add #4,r9
    c.r[7] = c.r[10];  // 060377D0 mov r10,r7
    c.r[7] += 1;  // 060377D2 add #1,r7
    st32(c.r[14] + 12, c.r[7]);  // 060377D4 mov.l r7,@(12,r14)
    c.r[7] = c.r[10];  // 060377D6 mov r10,r7
    c.r[7] += 54;  // 060377D8 add #54,r7
    st32(c.r[14] + 16, c.r[7]);  // 060377DA mov.l r7,@(16,r14)
    c.r[7] = c.r[10];  // 060377DC mov r10,r7
    c.r[7] += 18;  // 060377DE add #18,r7
    st32(c.r[14] + 20, c.r[7]);  // 060377E0 mov.l r7,@(20,r14)
    c.r[7] = c.r[10];  // 060377E2 mov r10,r7
    c.r[7] += 68;  // 060377E4 add #68,r7
    st32(c.r[14] + 24, c.r[7]);  // 060377E6 mov.l r7,@(24,r14)
    c.r[7] = c.r[10];  // 060377E8 mov r10,r7
    c.r[7] += 16;  // 060377EA add #16,r7
    st32(c.r[14] + 28, c.r[7]);  // 060377EC mov.l r7,@(28,r14)
    c.r[7] = c.r[10];  // 060377EE mov r10,r7
    c.r[7] += 67;  // 060377F0 add #67,r7
    st32(c.r[14] + 32, c.r[7]);  // 060377F2 mov.l r7,@(32,r14)
    c.r[13] = c.r[10];  // 060377F4 mov r10,r13
    c.r[13] += 69;  // 060377F6 add #69,r13
    c.r[12] = c.r[10];  // 060377F8 mov r10,r12
    c.r[12] += 60;  // 060377FA add #60,r12
    c.r[11] = c.r[10];  // 060377FC mov r10,r11
    c.r[11] += 61;  // 060377FE add #61,r11
L_06037800:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06037800 mov.b @r11,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06037802 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037804 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06037810; } }  // 06037806 bt/s 0x06037810 ; mov r2,r1
    c.r[1] -= 1;  // 0603780A add #-1,r1
    st8(c.r[11], c.r[1]); goto L_06037906;  // 0603780C bra 0x06037906 ; mov.b r1,@r11
L_06037810:
    c.r[1] = ld32(c.r[9] + 32);  // 06037810 mov.l @(32,r9),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037812 tst r1,r1
    { const bool k = c.t; c.r[7] = ld32(c.r[14]); if (k) { goto L_06037908; } }  // 06037814 bt/s 0x06037908 ; mov.l @r14,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06037818 mov.b @r12,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0603781A extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603781C tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0603782C; } }  // 0603781E bf/s 0x0603782C ; mov r2,r1
    c.r[0] = ld32(0x0603798Cu);  // 06037822 mov.l 0x0603798C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06037828u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037828u) return; }  // 06037824 jsr @r0 ; mov r10,r4
    st32(c.r[9] + 32, c.r[0]); goto L_06037830;  // 06037828 bra 0x06037830 ; mov.l r0,@(32,r9)
L_0603782C:
    c.r[1] -= 1;  // 0603782C add #-1,r1
    st8(c.r[12], c.r[1]);  // 0603782E mov.b r1,@r12
L_06037830:
    c.r[1] = ld32(c.r[9] + 36);  // 06037830 mov.l @(36,r9),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037832 tst r1,r1
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 12); if (k) { goto L_06037852; } }  // 06037834 bt/s 0x06037852 ; mov.l @(12,r14),r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06037838 mov.b @r13,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0603783A extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603783C tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0603784C; } }  // 0603783E bf/s 0x0603784C ; mov r2,r1
    c.r[0] = ld32(0x06037990u);  // 06037842 mov.l 0x06037990,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06037848u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037848u) return; }  // 06037844 jsr @r0 ; mov r10,r4
    st32(c.r[9] + 36, c.r[0]); goto L_06037850;  // 06037848 bra 0x06037850 ; mov.l r0,@(36,r9)
L_0603784C:
    c.r[1] -= 1;  // 0603784C add #-1,r1
    st8(c.r[13], c.r[1]);  // 0603784E mov.b r1,@r13
L_06037850:
    c.r[7] = ld32(c.r[14] + 12);  // 06037850 mov.l @(12,r14),r7
L_06037852:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06037852 mov.b @r7,r1
    c.r[0] = c.r[1];  // 06037854 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06037856 shlr r0
    c.r[0] &= 0x1u;  // 06037858 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603785A tst r0,r0
    { const bool k = !c.t; c.r[7] = ld32(c.r[14]); if (k) { goto L_06037908; } }  // 0603785C bf/s 0x06037908 ; mov.l @r14,r7
    c.r[7] = ld32(c.r[14] + 28);  // 06037860 mov.l @(28,r14),r7
    c.r[2] = ld32(c.r[9]);  // 06037862 mov.l @r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06037864 mov.w @r7,r1
    c.r[2] += c.r[1];  // 06037866 add r1,r2
    c.r[7] = ld32(c.r[14] + 20);  // 06037868 mov.l @(20,r14),r7
    st32(c.r[9], c.r[2]);  // 0603786A mov.l r2,@r9
    c.r[2] = ld32(c.r[9] + 4);  // 0603786C mov.l @(4,r9),r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603786E mov.w @r7,r1
    c.r[2] += c.r[1];  // 06037870 add r1,r2
    c.r[7] = ld32(c.r[14] + 32);  // 06037872 mov.l @(32,r14),r7
    st32(c.r[9] + 4, c.r[2]);  // 06037874 mov.l r2,@(4,r9)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06037876 mov.b @r7,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06037878 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603787A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06037890; } }  // 0603787C bt/s 0x06037890 ; mov r2,r1
    c.r[1] -= 1;  // 06037880 add #-1,r1
    st8(c.r[7], c.r[1]);  // 06037882 mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 06037884 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037886 tst r1,r1
    { const bool k = !c.t; c.r[7] = ld32(c.r[14] + 28); if (k) { goto L_06037890; } }  // 06037888 bf/s 0x06037890 ; mov.l @(28,r14),r7
    c.r[1] = 0x0u;  // 0603788C mov #0,r1
    st16(c.r[7], c.r[1]);  // 0603788E mov.w r1,@r7
L_06037890:
    c.r[7] = ld32(c.r[14] + 24);  // 06037890 mov.l @(24,r14),r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06037892 mov.b @r7,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06037894 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037896 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060378AC; } }  // 06037898 bt/s 0x060378AC ; mov r2,r1
    c.r[1] -= 1;  // 0603789C add #-1,r1
    st8(c.r[7], c.r[1]);  // 0603789E mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 060378A0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060378A2 tst r1,r1
    { const bool k = !c.t; c.r[7] = ld32(c.r[14] + 20); if (k) { goto L_060378AC; } }  // 060378A4 bf/s 0x060378AC ; mov.l @(20,r14),r7
    c.r[1] = 0x0u;  // 060378A8 mov #0,r1
    st16(c.r[7], c.r[1]);  // 060378AA mov.w r1,@r7
L_060378AC:
    c.r[7] = ld32(c.r[14] + 16);  // 060378AC mov.l @(16,r14),r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060378AE mov.w @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603796Eu);  // 060378B0 mov.w 0x0603796E,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 060378B2 extu.w r3,r2
    c.t = c.r[2] == c.r[1];  // 060378B4 cmp/eq r1,r2
    { const bool k = c.t; c.r[7] = ld32(c.r[14]); if (k) { goto L_06037908; } }  // 060378B6 bt/s 0x06037908 ; mov.l @r14,r7
    c.r[1] = 0x2Cu;  // 060378BA mov #44,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060378BC mulu.w r1,r3
    c.r[8] = c.macl;  // 060378BE sts macl,r8
    c.r[1] = ld32(0x06037994u);  // 060378C0 mov.l 0x06037994,r1
    c.r[8] += c.r[1];  // 060378C2 add r1,r8
    c.r[1] = ld32(0x06037998u);  // 060378C4 mov.l 0x06037998,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060378CAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060378CAu) return; }  // 060378C6 jsr @r1 ; mov r8,r4
    c.r[7] = ld32(c.r[14] + 12);  // 060378CA mov.l @(12,r14),r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060378CC mov.b @r7,r1
    c.r[0] = c.r[1];  // 060378CE mov r1,r0
    c.r[0] >>= 2;  // 060378D0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060378D2 shlr r0
    c.r[0] &= 0x1u;  // 060378D4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060378D6 tst r0,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[14] + 8); if (k) { goto L_060378F6; } }  // 060378D8 bt/s 0x060378F6 ; mov.l @(8,r14),r7
    c.r[1] = c.r[8];  // 060378DC mov r8,r1
    c.r[2] = ld32(c.r[9]);  // 060378DE mov.l @r9,r2
    c.r[1] += 12;  // 060378E0 add #12,r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060378E2 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060378E4 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060378E6 shar r2
    st16(c.r[1], c.r[2]);  // 060378E8 mov.w r2,@r1
    c.r[1] = ld32(c.r[9] + 4);  // 060378EA mov.l @(4,r9),r1
    c.r[8] += 14;  // 060378EC add #14,r8
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060378EE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060378F0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); goto L_06037904;  // 060378F2 bra 0x06037904 ; shar r1
L_060378F6:
    c.r[1] = c.r[8];  // 060378F6 mov r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060378F8 mov.w @r7,r2
    c.r[1] += 12;  // 060378FA add #12,r1
    c.r[7] = ld32(c.r[14] + 4);  // 060378FC mov.l @(4,r14),r7
    st16(c.r[1], c.r[2]);  // 060378FE mov.w r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06037900 mov.w @r7,r1
    c.r[8] += 14;  // 06037902 add #14,r8
L_06037904:
    st16(c.r[8], c.r[1]);  // 06037904 mov.w r1,@r8
L_06037906:
    c.r[7] = ld32(c.r[14]);  // 06037906 mov.l @r14,r7
L_06037908:
    c.r[7] += 1;  // 06037908 add #1,r7
    st32(c.r[14], c.r[7]);  // 0603790A mov.l r7,@r14
    c.r[7] = ld32(c.r[14] + 4);  // 0603790C mov.l @(4,r14),r7
    c.r[7] += 76;  // 0603790E add #76,r7
    st32(c.r[14] + 4, c.r[7]);  // 06037910 mov.l r7,@(4,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 06037912 mov.l @(8,r14),r7
    c.r[7] += 76;  // 06037914 add #76,r7
    st32(c.r[14] + 8, c.r[7]);  // 06037916 mov.l r7,@(8,r14)
    c.r[7] = ld32(c.r[14] + 12);  // 06037918 mov.l @(12,r14),r7
    c.r[7] += 76;  // 0603791A add #76,r7
    st32(c.r[14] + 12, c.r[7]);  // 0603791C mov.l r7,@(12,r14)
    c.r[7] = ld32(c.r[14] + 16);  // 0603791E mov.l @(16,r14),r7
    c.r[9] += 76;  // 06037920 add #76,r9
    c.r[7] += 76;  // 06037922 add #76,r7
    st32(c.r[14] + 16, c.r[7]);  // 06037924 mov.l r7,@(16,r14)
    c.r[7] = ld32(c.r[14] + 20);  // 06037926 mov.l @(20,r14),r7
    c.r[13] += 76;  // 06037928 add #76,r13
    c.r[7] += 76;  // 0603792A add #76,r7
    st32(c.r[14] + 20, c.r[7]);  // 0603792C mov.l r7,@(20,r14)
    c.r[7] = ld32(c.r[14] + 24);  // 0603792E mov.l @(24,r14),r7
    c.r[12] += 76;  // 06037930 add #76,r12
    c.r[7] += 76;  // 06037932 add #76,r7
    st32(c.r[14] + 24, c.r[7]);  // 06037934 mov.l r7,@(24,r14)
    c.r[7] = ld32(c.r[14] + 28);  // 06037936 mov.l @(28,r14),r7
    c.r[11] += 76;  // 06037938 add #76,r11
    c.r[7] += 76;  // 0603793A add #76,r7
    st32(c.r[14] + 28, c.r[7]);  // 0603793C mov.l r7,@(28,r14)
    c.r[7] = ld32(c.r[14] + 32);  // 0603793E mov.l @(32,r14),r7
    c.r[7] += 76;  // 06037940 add #76,r7
    st32(c.r[14] + 32, c.r[7]);  // 06037942 mov.l r7,@(32,r14)
    c.r[7] = ld32(c.r[14]);  // 06037944 mov.l @r14,r7
    c.r[1] = 0x7Fu;  // 06037946 mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06037948 cmp/gt r1,r7
    { const bool k = c.t; c.r[10] += 76; if (k) { goto L_06037952; } }  // 0603794A bt/s 0x06037952 ; add #76,r10
    SH2_POLL(c); goto L_06037800;  // 0603794E bra 0x06037800 ; nop
L_06037952:
    c.r[1] = ld32(0x0603799Cu);  // 06037952 mov.l 0x0603799C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037958u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037958u) return; }  // 06037954 jsr @r1 ; nop
L_06037958:
    c.r[14] += 36;  // 06037958 add #36,r14
    c.r[15] = c.r[14];  // 0603795A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603795C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603795E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06037960 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06037962 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06037964 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037966 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037968 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603796A rts ; mov.l @r15+,r8
}

void f_060379A0(SH2Context& c) {
    ran[794] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060379A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060379A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060379A4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060379A6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060379A8 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 060379AA mov r4,r9
    c.r[2] = c.r[9];  // 060379AC mov r9,r2
    c.r[2] += 60;  // 060379AE add #60,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060379B0 mov.b @r2,r1
    c.r[14] = c.r[15];  // 060379B2 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 060379B4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060379B6 tst r1,r1
    { const bool k = !c.t; c.r[7] = ld32(c.r[9] + 36); if (k) { goto L_06037A02; } }  // 060379B8 bf/s 0x06037A02 ; mov.l @(36,r9),r7
    c.r[10] = ld32(0x06037A14u);  // 060379BC mov.l 0x06037A14,r10
    c.r[8] = c.r[2];  // 060379BE mov r2,r8
L_060379C0:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060379C0 mov.b @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037A12u);  // 060379C2 mov.w 0x06037A12,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060379C4 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 060379C6 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060379EC; } }  // 060379C8 bf/s 0x060379EC ; mov #0,r1
    st8(c.r[10], c.r[1]);  // 060379CC mov.b r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060379CE mov.b @r7,r1
    c.r[5] = c.r[7];  // 060379D0 mov r7,r5
    c.r[0] = c.r[1] & 0xFFu;  // 060379D2 extu.b r1,r0
    c.r[0] <<= 2;  // 060379D4 shll2 r0
    c.r[1] = ld32(0x06037A18u);  // 060379D6 mov.l 0x06037A18,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060379D8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060379DEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060379DEu) return; }  // 060379DA jsr @r0 ; mov r9,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060379DE mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060379E0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060379E2 tst r1,r1
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_060379FA; } }  // 060379E4 bt/s 0x060379FA ; mov r0,r7
    c.r[15] = c.r[14]; goto L_06037A06;  // 060379E8 bra 0x06037A06 ; mov r14,r15
L_060379EC:
    c.r[1] = c.r[3];  // 060379EC mov r3,r1
    c.r[1] -= 1;  // 060379EE add #-1,r1
    st8(c.r[8], c.r[1]);  // 060379F0 mov.b r1,@r8
    c.r[7] += 1;  // 060379F2 add #1,r7
    c.r[1] = 0x1u;  // 060379F4 mov #1,r1
    st8(c.r[10], c.r[1]); goto L_06037A02;  // 060379F6 bra 0x06037A02 ; mov.b r1,@r10
L_060379FA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060379FA mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060379FC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060379FE tst r1,r1
    if (c.t) { SH2_POLL(c); goto L_060379C0; }  // 06037A00 bt 0x060379C0
L_06037A02:
    c.r[0] = c.r[7];  // 06037A02 mov r7,r0
    c.r[15] = c.r[14];  // 06037A04 mov r14,r15
L_06037A06:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06037A06 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06037A08 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037A0A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037A0C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037A0E rts ; mov.l @r15+,r8
}

void f_06037A1C(SH2Context& c) {
    ran[795] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037A1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06037A1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06037A20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037A22 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06037A24 mov r15,r14
    c.r[6] = ld32(c.r[4] + 40);  // 06037A26 mov.l @(40,r4),r6
    c.r[8] = c.r[4];  // 06037A28 mov r4,r8
    c.r[8] += 56;  // 06037A2A add #56,r8
    c.r[5] = c.r[4];  // 06037A2C mov r4,r5
    c.r[5] += 2;  // 06037A2E add #2,r5
    c.r[9] = c.r[4];  // 06037A30 mov r4,r9
    c.r[9] += 70;  // 06037A32 add #70,r9
    c.r[4] += 69;  // 06037A34 add #69,r4
L_06037A36:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06037A36 mov.b @r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037B42u);  // 06037A38 mov.w 0x06037B42,r1
    c.r[2] = 0x7u;  // 06037A3A mov #7,r2
    c.r[3] = c.r[7] & 0xFFu;  // 06037A3C extu.b r7,r3
    c.r[3] -= c.r[1];  // 06037A3E sub r1,r3
    c.t = c.r[3] > c.r[2];  // 06037A40 cmp/hi r2,r3
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06037B22; } }  // 06037A42 bt/s 0x06037B22 ; mov r3,r1
    c.r[1] += c.r[1];  // 06037A46 add r1,r1
    c.r[0] = 0x06037A54u;  // 06037A48 mova 0x06037A54,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06037A4A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06037A4C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06037A64u: goto L_06037A64; case 0x06037ABCu: goto L_06037ABC; case 0x06037AC0u: goto L_06037AC0; case 0x06037ACCu: goto L_06037ACC; case 0x06037ADEu: goto L_06037ADE; case 0x06037AF2u: goto L_06037AF2; case 0x06037AFCu: goto L_06037AFC; case 0x06037B18u: goto L_06037B18; default: sh2_call(c, x); return; } }  // 06037A4E jmp @r0 ; nop
L_06037A64:
    c.r[3] = c.r[6];  // 06037A64 mov r6,r3
    c.r[3] += 1;  // 06037A66 add #1,r3
    c.r[2] = 0x1u;  // 06037A68 mov #1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06037A6A mov.w @r8,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06037B44u);  // 06037A6C mov.w 0x06037B44,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06037A6E mov.b @r3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06037A70 extu.b r1,r1
    c.r[0] &= 0x3Fu;  // 06037A72 and #63,r0
    c.r[0] <<= 8;  // 06037A74 shll8 r0
    c.r[1] |= c.r[0];  // 06037A76 or r0,r1
    st16(c.r[8], c.r[1]);  // 06037A78 mov.w r1,@r8
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06037A7A mov.b @r5,r7
    c.r[6] += 2;  // 06037A7C add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06037A7E mov.b @r3,r1
    c.r[0] = c.r[7];  // 06037A80 mov r7,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06037A82 shlr r0
    c.r[2] &= c.r[0];  // 06037A84 and r0,r2
    c.r[0] = c.r[1];  // 06037A86 mov r1,r0
    c.r[0] >>= 2;  // 06037A88 shlr2 r0
    c.r[0] >>= 2;  // 06037A8A shlr2 r0
    c.r[0] >>= 2;  // 06037A8C shlr2 r0
    c.r[0] &= 0x1u;  // 06037A8E and #1,r0
    c.r[1] = c.r[0];  // 06037A90 mov r0,r1
    c.r[1] |= c.r[2];  // 06037A92 or r2,r1
    c.r[1] += c.r[1];  // 06037A94 add r1,r1
    c.r[7] &= c.r[10];  // 06037A96 and r10,r7
    c.r[7] |= c.r[1];  // 06037A98 or r1,r7
    st8(c.r[5], c.r[7]);  // 06037A9A mov.b r7,@r5
    c.r[2] = 0x1u;  // 06037A9C mov #1,r2
    c.r[2] &= c.r[7];  // 06037A9E and r7,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x06037B46u);  // 06037AA0 mov.w 0x06037B46,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06037AA2 mov.b @r3,r1
    c.r[7] &= c.r[10];  // 06037AA4 and r10,r7
    c.r[0] = c.r[1];  // 06037AA6 mov r1,r0
    c.r[0] >>= 2;  // 06037AA8 shlr2 r0
    c.r[0] >>= 2;  // 06037AAA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06037AAC shlr r0
    c.r[0] >>= 2;  // 06037AAE shlr2 r0
    c.r[0] &= 0x1u;  // 06037AB0 and #1,r0
    c.r[1] = c.r[0];  // 06037AB2 mov r0,r1
    c.r[1] |= c.r[2];  // 06037AB4 or r2,r1
    c.r[7] |= c.r[1];  // 06037AB6 or r1,r7
    st8(c.r[5], c.r[7]); SH2_POLL(c); goto L_06037A36;  // 06037AB8 bra 0x06037A36 ; mov.b r7,@r5
L_06037ABC:
    c.r[6] += 2; SH2_POLL(c); goto L_06037A36;  // 06037ABC bra 0x06037A36 ; add #2,r6
L_06037AC0:
    c.r[1] = c.r[6];  // 06037AC0 mov r6,r1
    c.r[1] += 1;  // 06037AC2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037AC4 mov.b @r1,r1
    c.r[6] += 2;  // 06037AC6 add #2,r6
    st8(c.r[9], c.r[1]); SH2_POLL(c); goto L_06037A36;  // 06037AC8 bra 0x06037A36 ; mov.b r1,@r9
L_06037ACC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06037ACC mov.b @r5,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06037B44u);  // 06037ACE mov.w 0x06037B44,r10
    c.r[6] += 1;  // 06037AD0 add #1,r6
    c.r[0] = c.r[1];  // 06037AD2 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06037AD4 shlr r0
    c.r[0] &= 0x1u;  // 06037AD6 and #1,r0
    c.r[0] ^= 0x1u;  // 06037AD8 xor #1,r0
    c.r[0] += c.r[0]; goto L_06037AEA;  // 06037ADA bra 0x06037AEA ; add r0,r0
L_06037ADE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06037ADE mov.b @r5,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06037B46u);  // 06037AE0 mov.w 0x06037B46,r10
    c.r[6] += 1;  // 06037AE2 add #1,r6
    c.r[0] = c.r[1];  // 06037AE4 mov r1,r0
    c.r[0] &= 0x1u;  // 06037AE6 and #1,r0
    c.r[0] ^= 0x1u;  // 06037AE8 xor #1,r0
L_06037AEA:
    c.r[1] &= c.r[10];  // 06037AEA and r10,r1
    c.r[1] |= c.r[0];  // 06037AEC or r0,r1
    st8(c.r[5], c.r[1]); SH2_POLL(c); goto L_06037A36;  // 06037AEE bra 0x06037A36 ; mov.b r1,@r5
L_06037AF2:
    c.r[1] = c.r[6];  // 06037AF2 mov r6,r1
    c.r[1] += 1;  // 06037AF4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037AF6 mov.b @r1,r1
    c.r[6] += c.r[1]; SH2_POLL(c); goto L_06037A36;  // 06037AF8 bra 0x06037A36 ; add r1,r6
L_06037AFC:
    c.r[1] = c.r[6];  // 06037AFC mov r6,r1
    c.r[1] += 1;  // 06037AFE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037B00 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06037B02 extu.b r2,r2
    c.r[1] = c.r[6];  // 06037B04 mov r6,r1
    c.r[1] += 2;  // 06037B06 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037B08 mov.b @r1,r1
    c.r[2] <<= 8;  // 06037B0A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06037B0C extu.b r1,r1
    c.r[2] |= c.r[1];  // 06037B0E or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06037B10 exts.w r2,r2
    c.r[2] += 1;  // 06037B12 add #1,r2
    c.r[6] += c.r[2]; SH2_POLL(c); goto L_06037A36;  // 06037B14 bra 0x06037A36 ; add r2,r6
L_06037B18:
    c.r[1] = 0x0u;  // 06037B18 mov #0,r1
    st8(c.r[9], c.r[1]);  // 06037B1A mov.b r1,@r9
    st8(c.r[4], c.r[1]);  // 06037B1C mov.b r1,@r4
    c.r[0] = 0x0u; goto L_06037B36;  // 06037B1E bra 0x06037B36 ; mov #0,r0
L_06037B22:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037B48u);  // 06037B22 mov.w 0x06037B48,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06037B24 mov.w @r8,r2
    c.r[6] += 1;  // 06037B26 add #1,r6
    c.r[2] &= c.r[1];  // 06037B28 and r1,r2
    c.r[1] = c.r[7] & 0xFFu;  // 06037B2A extu.b r7,r1
    c.r[2] |= c.r[1];  // 06037B2C or r1,r2
    st16(c.r[8], c.r[2]);  // 06037B2E mov.w r2,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06037B30 mov.b @r9,r1
    c.r[0] = c.r[6];  // 06037B32 mov r6,r0
    st8(c.r[4], c.r[1]);  // 06037B34 mov.b r1,@r4
L_06037B36:
    c.r[15] = c.r[14];  // 06037B36 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06037B38 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037B3A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037B3C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037B3E rts ; mov.l @r15+,r8
}

void f_06037B4C(SH2Context& c) {
    ran[796] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037B4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06037B4E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06037B50 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06037B52 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06037B54 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06037B56 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037B58 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037B5A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06037CE6u);  // 06037B5C mov.w 0x06037CE6,r3
    c.r[15] += c.r[3];  // 06037B5E add r3,r15
    c.r[14] = c.r[15];  // 06037B60 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CE8u);  // 06037B62 mov.w 0x06037CE8,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 06037B64 mov.l r7,@(r0,r14)
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CEAu);  // 06037B66 mov.w 0x06037CEA,r12
    c.r[12] += c.r[14];  // 06037B68 add r14,r12
    c.r[4] = c.r[4] & 0xFFu;  // 06037B6A extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CECu);  // 06037B6C mov.w 0x06037CEC,r0
    c.r[0] += c.r[14];  // 06037B6E add r14,r0
    c.r[1] = ld32(c.r[12]);  // 06037B70 mov.l @r12,r1
    c.r[5] = c.r[5] & 0xFFu;  // 06037B72 extu.b r5,r5
    st32(c.r[0], c.r[4]);  // 06037B74 mov.l r4,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CEEu);  // 06037B76 mov.w 0x06037CEE,r12
    c.r[12] += c.r[14];  // 06037B78 add r14,r12
    st32(c.r[12], c.r[5]);  // 06037B7A mov.l r5,@r12
    c.r[1] = c.r[1] & 0xFFu;  // 06037B7C extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CF0u);  // 06037B7E mov.w 0x06037CF0,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06037B80 mov.l r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CF0u);  // 06037B82 mov.w 0x06037CF0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06037B84 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x2u;  // 06037B86 cmp/eq #2,r0
    { const bool k = !c.t; c.r[13] = c.r[6] & 0xFFFFu; if (k) { goto L_06037B90; } }  // 06037B88 bf/s 0x06037B90 ; extu.w r6,r13
    c.r[2] = 0x0u; goto L_06037B98;  // 06037B8C bra 0x06037B98 ; mov #0,r2
L_06037B90:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CE8u);  // 06037B90 mov.w 0x06037CE8,r12
    c.r[12] += c.r[14];  // 06037B92 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06037B94 mov.l @r12,r0
    c.r[2] = ld32(c.r[0] + 12);  // 06037B96 mov.l @(12,r0),r2
L_06037B98:
    c.r[10] = (uint32_t)(int16_t)ld16(0x06037CF2u);  // 06037B98 mov.w 0x06037CF2,r10
    c.r[7] = c.r[14];  // 06037B9A mov r14,r7
    c.r[7] += c.r[10];  // 06037B9C add r10,r7
    c.r[4] = 0x0u;  // 06037B9E mov #0,r4
    c.r[0] = c.r[14];  // 06037BA0 mov r14,r0
    st8(c.r[0] + c.r[10], c.r[4]);  // 06037BA2 mov.b r4,@(r0,r10)
    c.r[9] = ld32(0x06037CFCu);  // 06037BA4 mov.l 0x06037CFC,r9
    c.r[1] = c.r[9];  // 06037BA6 mov r9,r1
    c.r[1] += 88;  // 06037BA8 add #88,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CF4u);  // 06037BAA mov.w 0x06037CF4,r12
    c.r[12] += c.r[14];  // 06037BAC add r14,r12
    c.r[8] = (uint32_t)(int16_t)ld16(0x06037CF6u);  // 06037BAE mov.w 0x06037CF6,r8
    c.r[6] = c.r[14];  // 06037BB0 mov r14,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CF8u);  // 06037BB2 mov.w 0x06037CF8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037BB4 mov.w @r1,r1
    c.r[0] += c.r[14];  // 06037BB6 add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06037BB8 extu.w r1,r1
    st32(c.r[12], c.r[1]);  // 06037BBA mov.l r1,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06037BBC mov.w @r0,r12
    c.r[6] += c.r[8];  // 06037BBE add r8,r6
    c.r[0] = c.r[14];  // 06037BC0 mov r14,r0
    st16(c.r[0] + c.r[8], c.r[12]);  // 06037BC2 mov.w r12,@(r0,r8)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CECu);  // 06037BC4 mov.w 0x06037CEC,r0
    c.r[0] += c.r[14];  // 06037BC6 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CF8u);  // 06037BC8 mov.w 0x06037CF8,r12
    c.r[11] = ld32(c.r[0]);  // 06037BCA mov.l @r0,r11
    c.r[12] += c.r[14];  // 06037BCC add r14,r12
    c.r[11] += c.r[11];  // 06037BCE add r11,r11
    c.r[11] += c.r[9];  // 06037BD0 add r9,r11
    c.r[11] += 24;  // 06037BD2 add #24,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CE8u);  // 06037BD4 mov.w 0x06037CE8,r0
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06037BD6 mov.w @r12,r12
    c.r[0] += c.r[14];  // 06037BD8 add r14,r0
    st16(c.r[11], c.r[12]);  // 06037BDA mov.w r12,@r11
    c.r[12] = ld32(c.r[0]);  // 06037BDC mov.l @r0,r12
    c.r[1] = ld32(0x06037D00u);  // 06037BDE mov.l 0x06037D00,r1
    c.r[5] = ld32(c.r[1]);  // 06037BE0 mov.l @r1,r5
    c.r[12] += c.r[2];  // 06037BE2 add r2,r12
    st32(c.r[0], c.r[12]);  // 06037BE4 mov.l r12,@r0
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037BE6 mov.l r14,@-r15
    c.r[0] = c.r[14];  // 06037BE8 mov r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CEEu);  // 06037BEA mov.w 0x06037CEE,r12
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06037BEC mov.w @(r0,r8),r3
    c.r[12] += c.r[14];  // 06037BEE add r14,r12
    c.r[1] = ld32(c.r[9] + 16);  // 06037BF0 mov.l @(16,r9),r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06037BF2 extu.w r3,r2
    c.r[2] <<= 2;  // 06037BF4 shll2 r2
    c.r[1] += c.r[2];  // 06037BF6 add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06037BF8 mov.l r1,@-r15
    c.r[1] = 0xAu;  // 06037BFA mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06037BFC mulu.w r1,r3
    c.r[2] = ld32(c.r[9] + 8);  // 06037BFE mov.l @(8,r9),r2
    c.r[1] = c.macl;  // 06037C00 sts macl,r1
    c.r[2] += c.r[1];  // 06037C02 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06037C04 mov.l r2,@-r15
    c.r[1] = ld32(c.r[9] + 4);  // 06037C06 mov.l @(4,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CE8u);  // 06037C08 mov.w 0x06037CE8,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06037C0A mov.l r1,@-r15
    c.r[1] = ld32(c.r[9]);  // 06037C0C mov.l @r9,r1
    c.r[0] += c.r[14];  // 06037C0E add r14,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06037C10 mov.l r1,@-r15
    c.r[12] = ld32(c.r[12]);  // 06037C12 mov.l @r12,r12
    c.r[1] = ld32(0x06037D04u);  // 06037C14 mov.l 0x06037D04,r1
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06037C16 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06037C18 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 06037C1A mov.l r4,@-r15
    c.r[12] = ld32(0x06037D08u);  // 06037C1C mov.l 0x06037D08,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06037C22u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037C22u) return; }  // 06037C1E jsr @r12 ; mov.l @r0,r4
    c.r[15] += 32;  // 06037C22 add #32,r15
    c.r[0] = c.r[14];  // 06037C24 mov r14,r0
    c.r[4] = c.r[13] & 0xFFu;  // 06037C26 extu.b r13,r4
    c.r[5] = c.r[14];  // 06037C28 mov r14,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06037C2A mov.b @(r0,r10),r6
    c.r[12] = ld32(0x06037D0Cu);  // 06037C2C mov.l 0x06037D0C,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06037C32u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037C32u) return; }  // 06037C2E jsr @r12 ; extu.b r6,r6
    c.r[0] = c.r[14];  // 06037C32 mov r14,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06037C34 mov.w @(r0,r8),r2
    c.r[7] = 0x0u;  // 06037C36 mov #0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06037C38 mov.w @r11,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06037C3A extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06037C3C extu.w r1,r1
    c.r[2] -= c.r[1];  // 06037C3E sub r1,r2
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06037C40 cmp/ge r2,r7
    if (c.t) { goto L_06037C88; }  // 06037C42 bt 0x06037C88
    c.r[5] = c.r[9];  // 06037C44 mov r9,r5
    c.r[4] = c.r[11];  // 06037C46 mov r11,r4
    c.r[1] = c.r[5];  // 06037C48 mov r5,r1
L_06037C4A:
    c.r[1] += 88;  // 06037C4A add #88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037C4C mov.w @r1,r1
    c.r[12] = 0x3Fu;  // 06037C4E mov #63,r12
    c.r[6] = ld32(c.r[5] + 20);  // 06037C50 mov.l @(20,r5),r6
    c.r[3] = c.r[1] & 0xFFFFu;  // 06037C52 extu.w r1,r3
    c.r[3] += c.r[7];  // 06037C54 add r7,r3
    c.r[2] = c.r[3];  // 06037C56 mov r3,r2
    c.r[2] <<= 2;  // 06037C58 shll2 r2
    c.r[2] += c.r[3];  // 06037C5A add r3,r2
    c.r[1] = ld32(c.r[5] + 8);  // 06037C5C mov.l @(8,r5),r1
    c.r[2] += c.r[2];  // 06037C5E add r2,r2
    c.r[2] += c.r[1];  // 06037C60 add r1,r2
    c.r[2] += 4;  // 06037C62 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037C64 mov.w @r2,r1
    c.r[0] = c.r[6];  // 06037C66 mov r6,r0
    c.r[1] >>= 2;  // 06037C68 shlr2 r1
    c.r[1] >>= 2;  // 06037C6A shlr2 r1
    c.r[1] &= c.r[12];  // 06037C6C and r12,r1
    c.r[1] += c.r[13];  // 06037C6E add r13,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06037C70 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037CF6u);  // 06037C72 mov.w 0x06037CF6,r1
    c.r[0] = c.r[14];  // 06037C74 mov r14,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06037C76 mov.w @(r0,r1),r2
    c.r[7] += 1;  // 06037C78 add #1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06037C7A mov.w @r4,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06037C7C extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06037C7E extu.w r1,r1
    c.r[2] -= c.r[1];  // 06037C80 sub r1,r2
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06037C82 cmp/ge r2,r7
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { SH2_POLL(c); goto L_06037C4A; } }  // 06037C84 bf/s 0x06037C4A ; mov r5,r1
L_06037C88:
    c.r[3] = ld32(0x06037D10u);  // 06037C88 mov.l 0x06037D10,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06037CF6u);  // 06037C8A mov.w 0x06037CF6,r1
    c.r[0] = c.r[14];  // 06037C8C mov r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CF4u);  // 06037C8E mov.w 0x06037CF4,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06037C90 mov.w @(r0,r1),r1
    c.r[12] += c.r[14];  // 06037C92 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06037C94 mov.l @r12,r12
    c.r[7] = (uint32_t)(int16_t)ld16(0x06037CF2u);  // 06037C96 mov.w 0x06037CF2,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06037C98 mov.w @r3,r2
    c.r[1] -= c.r[12];  // 06037C9A sub r12,r1
    c.r[1] += c.r[2];  // 06037C9C add r2,r1
    st16(c.r[3], c.r[1]);  // 06037C9E mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06037CA0 mov.b @(r0,r7),r1
    c.r[2] = ld32(0x06037D14u);  // 06037CA2 mov.l 0x06037D14,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06037CA4 extu.b r1,r1
    c.r[13] += c.r[1];  // 06037CA6 add r1,r13
    st16(c.r[2], c.r[13]);  // 06037CA8 mov.w r13,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06037CF0u);  // 06037CAA mov.w 0x06037CF0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06037CAC mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 06037CAE cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06037CCE; } }  // 06037CB0 bf/s 0x06037CCE ; mov r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06037CECu);  // 06037CB4 mov.w 0x06037CEC,r12
    c.r[12] += c.r[14];  // 06037CB6 add r14,r12
    c.r[6] = ld32(c.r[12]);  // 06037CB8 mov.l @r12,r6
    c.r[6] += c.r[6];  // 06037CBA add r6,r6
    c.r[3] = ld32(0x06037D18u);  // 06037CBC mov.l 0x06037D18,r3
    c.r[1] = c.r[3];  // 06037CBE mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06037CC0 mov.b @(r0,r7),r2
    c.r[1] -= 2;  // 06037CC2 add #-2,r1
    c.r[0] = c.r[6];  // 06037CC4 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06037CC6 mov.w @(r0,r1),r1
    c.r[2] = c.r[2] & 0xFFu;  // 06037CC8 extu.b r2,r2
    c.r[1] += c.r[2];  // 06037CCA add r2,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 06037CCC mov.w r1,@(r0,r3)
L_06037CCE:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06037CFAu);  // 06037CCE mov.w 0x06037CFA,r3
    c.r[14] += c.r[3];  // 06037CD0 add r3,r14
    c.r[15] = c.r[14];  // 06037CD2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06037CD4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06037CD6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06037CD8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06037CDA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06037CDC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037CDE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037CE0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037CE2 rts ; mov.l @r15+,r8
}

void f_06037D1C(SH2Context& c) {
    ran[797] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037D1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037D1E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06037D20 mov r15,r14
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 06037D22 exts.w r5,r5
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 06037D24 exts.w r6,r3
    c.r[2] = ld32(0x06037D64u);  // 06037D26 mov.l 0x06037D64,r2
    c.r[0] = c.r[4];  // 06037D28 mov r4,r0
    c.r[0] += c.r[0];  // 06037D2A add r0,r0
    c.r[0] += c.r[4];  // 06037D2C add r4,r0
    c.r[0] <<= 2;  // 06037D2E shll2 r0
    c.r[6] = c.r[0];  // 06037D30 mov r0,r6
    c.r[6] += c.r[2];  // 06037D32 add r2,r6
    c.r[1] = c.r[3];  // 06037D34 mov r3,r1
    c.r[1] <<= 16;  // 06037D36 shll16 r1
    st32(c.r[6] + 4, c.r[1]);  // 06037D38 mov.l r1,@(4,r6)
    c.r[1] = c.r[6];  // 06037D3A mov r6,r1
    c.r[1] += 2;  // 06037D3C add #2,r1
    st16(c.r[1], c.r[5]);  // 06037D3E mov.w r5,@r1
    c.t = (c.r[7] & c.r[7]) == 0;  // 06037D40 tst r7,r7
    { const bool k = c.t; st16(c.r[0] + c.r[2], c.r[7]); if (k) { goto L_06037D58; } }  // 06037D42 bt/s 0x06037D58 ; mov.w r7,@(r0,r2)
    c.r[5] -= c.r[3];  // 06037D46 sub r3,r5
    c.r[5] <<= 16;  // 06037D48 shll16 r5
    c.r[4] = c.r[5];  // 06037D4A mov r5,r4
    c.r[5] = c.r[7];  // 06037D4C mov r7,r5
    c.r[7] = ld32(0x06037D68u);  // 06037D4E mov.l 0x06037D68,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06037D54u; c.r[15] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037D54u) return; }  // 06037D50 jsr @r7 ; mov r14,r15
    st32(c.r[6] + 8, c.r[0]); goto L_06037D5C;  // 06037D54 bra 0x06037D5C ; mov.l r0,@(8,r6)
L_06037D58:
    st32(c.r[6] + 8, c.r[7]);  // 06037D58 mov.l r7,@(8,r6)
    c.r[15] = c.r[14];  // 06037D5A mov r14,r15
L_06037D5C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06037D5C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037D5E rts ; mov.l @r15+,r14
}

void f_06037D6C(SH2Context& c) {
    ran[798] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037D6C mov.l r14,@-r15
    c.r[7] = ld32(0x06037DBCu);  // 06037D6E mov.l 0x06037DBC,r7
    c.r[0] = c.r[4];  // 06037D70 mov r4,r0
    c.r[0] += c.r[0];  // 06037D72 add r0,r0
    c.r[0] += c.r[4];  // 06037D74 add r4,r0
    c.r[0] <<= 2;  // 06037D76 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06037D78 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06037D7A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037D7C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06037D96; } }  // 06037D7E bt/s 0x06037D96 ; mov r15,r14
    c.r[1] = c.r[0];  // 06037D82 mov r0,r1
    c.r[1] += c.r[7];  // 06037D84 add r7,r1
    c.r[3] = ld32(c.r[1] + 4);  // 06037D86 mov.l @(4,r1),r3
    c.r[2] = ld32(c.r[1] + 8);  // 06037D88 mov.l @(8,r1),r2
    c.r[3] += c.r[2];  // 06037D8A add r2,r3
    st32(c.r[1] + 4, c.r[3]);  // 06037D8C mov.l r3,@(4,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06037D8E mov.w @(r0,r7),r1
    c.r[1] -= 1;  // 06037D90 add #-1,r1
    st16(c.r[0] + c.r[7], c.r[1]); goto L_06037DA4;  // 06037D92 bra 0x06037DA4 ; mov.w r1,@(r0,r7)
L_06037D96:
    c.r[1] = c.r[0];  // 06037D96 mov r0,r1
    c.r[1] += c.r[7];  // 06037D98 add r7,r1
    c.r[2] = c.r[1];  // 06037D9A mov r1,r2
    c.r[2] += 2;  // 06037D9C add #2,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037D9E mov.w @r2,r2
    c.r[2] <<= 16;  // 06037DA0 shll16 r2
    st32(c.r[1] + 4, c.r[2]);  // 06037DA2 mov.l r2,@(4,r1)
L_06037DA4:
    c.r[1] = ld32(0x06037DBCu);  // 06037DA4 mov.l 0x06037DBC,r1
    c.r[2] = c.r[4];  // 06037DA6 mov r4,r2
    c.r[2] += c.r[2];  // 06037DA8 add r2,r2
    c.r[2] += c.r[4];  // 06037DAA add r4,r2
    c.r[2] <<= 2;  // 06037DAC shll2 r2
    c.r[2] += c.r[1];  // 06037DAE add r1,r2
    c.r[1] = ld32(c.r[2] + 4);  // 06037DB0 mov.l @(4,r2),r1
    c.r[15] = c.r[14];  // 06037DB2 mov r14,r15
    c.r[0] = c.r[1] << 16 | c.r[1] >> 16;  // 06037DB4 swap.w r1,r0
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 06037DB6 exts.w r0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037DB8 rts ; mov.l @r15+,r14
}

void f_06037DC0(SH2Context& c) {
    ran[799] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037DC0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06037DC2 mov r15,r14
    c.r[6] = ld32(0x06037DE8u);  // 06037DC4 mov.l 0x06037DE8,r6
    c.r[0] = c.r[4];  // 06037DC6 mov r4,r0
    c.r[0] += c.r[0];  // 06037DC8 add r0,r0
    c.r[0] += c.r[4];  // 06037DCA add r4,r0
    c.r[0] <<= 2;  // 06037DCC shll2 r0
    c.r[2] = c.r[0];  // 06037DCE mov r0,r2
    c.r[2] += c.r[6];  // 06037DD0 add r6,r2
    c.r[7] = 0x0u;  // 06037DD2 mov #0,r7
    st32(c.r[2] + 4, c.r[7]);  // 06037DD4 mov.l r7,@(4,r2)
    c.r[3] = c.r[2];  // 06037DD6 mov r2,r3
    c.r[3] += 2;  // 06037DD8 add #2,r3
    c.r[1] = 0x0u;  // 06037DDA mov #0,r1
    st16(c.r[3], c.r[1]);  // 06037DDC mov.w r1,@r3
    st16(c.r[0] + c.r[6], c.r[1]);  // 06037DDE mov.w r1,@(r0,r6)
    st32(c.r[2] + 8, c.r[7]);  // 06037DE0 mov.l r7,@(8,r2)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037DE2 rts ; mov.l @r15+,r14
}

void f_06037DEC(SH2Context& c) {
    ran[800] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037DEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06037DEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06037DF0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06037DF2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06037DF4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06037DF6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037DF8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037DFA sts.l pr,@-r15
    c.r[15] -= 32;  // 06037DFC add #-32,r15
    c.r[14] = c.r[15];  // 06037DFE mov r15,r14
    st32(c.r[14] + 24, c.r[5]);  // 06037E00 mov.l r5,@(24,r14)
    c.r[10] = c.r[6] & 0xFFFFu;  // 06037E02 extu.w r6,r10
    c.r[8] = c.r[7] & 0xFFFFu;  // 06037E04 extu.w r7,r8
    c.r[1] = 0xCu;  // 06037E06 mov #12,r1
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06037E08 mulu.w r1,r10
    c.r[3] = ld32(0x06037F24u);  // 06037E0A mov.l 0x06037F24,r3
    c.r[1] = c.macl;  // 06037E0C sts macl,r1
    c.r[1] += c.r[3];  // 06037E0E add r3,r1
    c.r[1] += 2;  // 06037E10 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037E12 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06037E14 extu.w r1,r0
    c.t = c.r[0] == 0x3u;  // 06037E16 cmp/eq #3,r0
    { const bool k = c.t; c.r[2] = c.macl; if (k) { goto L_06037E22; } }  // 06037E18 bt/s 0x06037E22 ; sts macl,r2
    c.r[1] = ld32(0x06037F28u);  // 06037E1C mov.l 0x06037F28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_06037E26;  // 06037E1E bra 0x06037E26 ; mov.w @r1,r1
L_06037E22:
    c.r[1] = ld32(0x06037F2Cu);  // 06037E22 mov.l 0x06037F2C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037E24 mov.w @r1,r1
L_06037E26:
    c.r[0] = c.r[3];  // 06037E26 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06037E28 mov.w r1,@(r0,r2)
    c.r[2] = ld32(0x06037F24u);  // 06037E2A mov.l 0x06037F24,r2
    c.r[1] = 0xCu;  // 06037E2C mov #12,r1
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06037E2E mulu.w r1,r10
    c.r[0] = c.r[2];  // 06037E30 mov r2,r0
    c.r[1] = c.macl;  // 06037E32 sts macl,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06037E34 mov.w @(r0,r1),r1
    c.r[11] = c.r[1] & 0xFFFFu;  // 06037E36 extu.w r1,r11
    c.r[11] <<= 2;  // 06037E38 shll2 r11
    c.r[11] += c.r[11];  // 06037E3A add r11,r11
    c.r[11] <<= 2;  // 06037E3C shll2 r11
    c.r[1] = ld32(0x06037F30u);  // 06037E3E mov.l 0x06037F30,r1
    c.r[11] += c.r[1];  // 06037E40 add r1,r11
    c.r[1] = ld32(0x06037F34u);  // 06037E42 mov.l 0x06037F34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037E44 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06037E46 extu.b r1,r1
    c.r[0] = c.r[1];  // 06037E48 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06037E4A cmp/eq #1,r0
    if (!c.t) { goto L_06037E56; }  // 06037E4C bf 0x06037E56
    c.r[1] = ld32(0x06037F38u);  // 06037E4E mov.l 0x06037F38,r1
    c.t = c.r[11] > c.r[1];  // 06037E50 cmp/hi r1,r11
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06037F0C; } }  // 06037E52 bt/s 0x06037F0C ; mov #-1,r0
L_06037E56:
    c.r[1] = ld32(0x06037F3Cu);  // 06037E56 mov.l 0x06037F3C,r1
    c.r[6] = c.r[14];  // 06037E58 mov r14,r6
    c.r[0] = ld32(0x06037F40u);  // 06037E5A mov.l 0x06037F40,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06037E60u; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037E60u) return; }  // 06037E5C jsr @r0 ; mov.l @r1,r5
    c.r[1] = c.r[14];  // 06037E60 mov r14,r1
    c.r[1] += 4;  // 06037E62 add #4,r1
    c.r[13] = c.r[8];  // 06037E64 mov r8,r13
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037E66 mov.w @r1,r9
    c.r[0] = ld32(0x06037F44u);  // 06037E68 mov.l 0x06037F44,r0
    c.r[5] = ld32(c.r[14] + 8);  // 06037E6A mov.l @(8,r14),r5
    c.r[9] = c.r[9] & 0xFFFFu;  // 06037E6C extu.w r9,r9
    c.r[9] >>= 2;  // 06037E6E shlr2 r9
    c.r[9] >>= 2;  // 06037E70 shlr2 r9
    c.r[13] += c.r[13];  // 06037E72 add r13,r13
    c.r[1] = ld32(0x06037F48u);  // 06037E74 mov.l 0x06037F48,r1
    c.r[1] += c.r[13];  // 06037E76 add r13,r1
    c.r[1] += 1;  // 06037E78 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037E7A mov.b @r1,r4
    c.r[6] = c.r[9];  // 06037E7C mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06037E82u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037E82u) return; }  // 06037E7E jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[14];  // 06037E82 mov r14,r1
    c.r[1] += 6;  // 06037E84 add #6,r1
    c.r[8] = ld32(0x06037F4Cu);  // 06037E86 mov.l 0x06037F4C,r8
    c.r[7] = 0xEu;  // 06037E88 mov #14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06037E8A mov.w @r1,r1
    c.r[5] = c.r[11];  // 06037E8C mov r11,r5
    c.r[12] = c.r[1] & 0xFFFFu;  // 06037E8E extu.w r1,r12
    st32(c.r[14] + 28, c.r[12]);  // 06037E90 mov.l r12,@(28,r14)
    c.r[1] = 0x1u;  // 06037E92 mov #1,r1
    st8(c.r[8], c.r[1]);  // 06037E94 mov.b r1,@r8
    c.r[6] = c.r[12];  // 06037E96 mov r12,r6
    c.r[6] <<= 2;  // 06037E98 shll2 r6
    c.r[6] += c.r[6];  // 06037E9A add r6,r6
    c.r[6] <<= 2;  // 06037E9C shll2 r6
    c.r[1] = ld32(0x06037F50u);  // 06037E9E mov.l 0x06037F50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037EA4u; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037EA4u) return; }  // 06037EA0 jsr @r1 ; mov.l @(16,r14),r4
    c.r[1] = ld32(0x06037F54u);  // 06037EA4 mov.l 0x06037F54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037EAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037EAAu) return; }  // 06037EA6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06037EAA mov #0,r1
    st8(c.r[8], c.r[1]);  // 06037EAC mov.b r1,@r8
    c.r[1] = 0xCu;  // 06037EAE mov #12,r1
    c.r[0] = ld32(0x06037F58u);  // 06037EB0 mov.l 0x06037F58,r0
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06037EB2 mulu.w r1,r10
    c.r[4] = ld32(c.r[14] + 24);  // 06037EB4 mov.l @(24,r14),r4
    c.r[8] = c.macl;  // 06037EB6 sts macl,r8
    c.r[10] = ld32(0x06037F5Cu);  // 06037EB8 mov.l 0x06037F5C,r10
    c.r[6] = c.r[8];  // 06037EBA mov r8,r6
    c.r[1] = ld32(0x06037F60u);  // 06037EBC mov.l 0x06037F60,r1
    c.r[5] = ld32(c.r[1]);  // 06037EBE mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06037EC4u; c.r[6] += c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037EC4u) return; }  // 06037EC0 jsr @r0 ; add r10,r6
    c.r[3] = c.r[0];  // 06037EC4 mov r0,r3
    c.r[2] = ld32(0x06037F48u);  // 06037EC6 mov.l 0x06037F48,r2
    c.r[2] += 2;  // 06037EC8 add #2,r2
    c.r[0] = ld32(0x06037F48u);  // 06037ECA mov.l 0x06037F48,r0
    c.r[10] += c.r[8];  // 06037ECC add r8,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06037ECE mov.w @(r0,r13),r1
    c.r[10] -= 2;  // 06037ED0 add #-2,r10
    c.r[9] += c.r[1];  // 06037ED2 add r1,r9
    c.r[0] = c.r[13];  // 06037ED4 mov r13,r0
    st16(c.r[0] + c.r[2], c.r[9]);  // 06037ED6 mov.w r9,@(r0,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06037ED8 mov.w @r10,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06037EDA extu.w r1,r1
    c.r[0] = c.r[1];  // 06037EDC mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06037EDE cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_06037EEE; } }  // 06037EE0 bf/s 0x06037EEE ; mov.l @(28,r14),r0
    c.r[2] = ld32(0x06037F2Cu);  // 06037EE4 mov.l 0x06037F2C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037EE6 mov.w @r2,r1
    c.r[12] += c.r[1];  // 06037EE8 add r1,r12
    st16(c.r[2], c.r[12]); goto L_06037EFC;  // 06037EEA bra 0x06037EFC ; mov.w r12,@r2
L_06037EEE:
    c.r[2] = ld32(0x06037F28u);  // 06037EEE mov.l 0x06037F28,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06037EF0 mov.w @r2,r1
    c.r[0] += c.r[1];  // 06037EF2 add r1,r0
    st32(c.r[14] + 28, c.r[0]);  // 06037EF4 mov.l r0,@(28,r14)
    c.r[0] = 0x1Eu;  // 06037EF6 mov #30,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06037EF8 mov.w @(r0,r14),r0
    st16(c.r[2], c.r[0]);  // 06037EFA mov.w r0,@r2
L_06037EFC:
    c.r[2] = ld32(0x06037F60u);  // 06037EFC mov.l 0x06037F60,r2
    c.r[3] += 3;  // 06037EFE add #3,r3
    c.r[3] >>= 2;  // 06037F00 shlr2 r3
    c.r[3] <<= 2;  // 06037F02 shll2 r3
    c.r[1] = ld32(c.r[2]);  // 06037F04 mov.l @r2,r1
    c.r[0] = 0x0u;  // 06037F06 mov #0,r0
    c.r[1] += c.r[3];  // 06037F08 add r3,r1
    st32(c.r[2], c.r[1]);  // 06037F0A mov.l r1,@r2
L_06037F0C:
    c.r[14] += 32;  // 06037F0C add #32,r14
    c.r[15] = c.r[14];  // 06037F0E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06037F10 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06037F12 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06037F14 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06037F16 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06037F18 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06037F1A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06037F1C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06037F1E rts ; mov.l @r15+,r8
}

void f_06037F64(SH2Context& c) {
    ran[801] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06037F64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06037F66 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06037F68 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06037F6A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06037F6C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06037F6E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06037F70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06037F72 sts.l pr,@-r15
    c.r[15] -= 12;  // 06037F74 add #-12,r15
    c.r[14] = c.r[15];  // 06037F76 mov r15,r14
    c.r[8] = c.r[5];  // 06037F78 mov r5,r8
    c.r[0] = c.r[8];  // 06037F7A mov r8,r0
    c.r[7] = c.r[8];  // 06037F7C mov r8,r7
    c.r[7] += 4;  // 06037F7E add #4,r7
    c.r[6] = c.r[8];  // 06037F80 mov r8,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06037F82 mov.b @r0+,r1
    c.r[6] += 5;  // 06037F84 add #5,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06037F86 extu.b r1,r1
    c.r[11] = c.r[1];  // 06037F88 mov r1,r11
    c.r[11] <<= 8;  // 06037F8A shll8 r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06037F8C mov.b @r0,r1
    c.r[13] = c.r[8];  // 06037F8E mov r8,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06037F90 extu.b r1,r1
    c.r[11] |= c.r[1];  // 06037F92 or r1,r11
    st32(c.r[14] + 4, c.r[11]);  // 06037F94 mov.l r11,@(4,r14)
    c.r[1] = c.r[8];  // 06037F96 mov r8,r1
    c.r[1] += 2;  // 06037F98 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037F9A mov.b @r1,r1
    c.r[13] += 6;  // 06037F9C add #6,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06037F9E extu.b r1,r1
    c.r[10] = c.r[1];  // 06037FA0 mov r1,r10
    c.r[10] <<= 8;  // 06037FA2 shll8 r10
    c.r[1] = c.r[8];  // 06037FA4 mov r8,r1
    c.r[1] += 3;  // 06037FA6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037FA8 mov.b @r1,r1
    c.r[12] = c.r[8];  // 06037FAA mov r8,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06037FAC extu.b r1,r1
    c.r[10] |= c.r[1];  // 06037FAE or r1,r10
    st32(c.r[14] + 8, c.r[10]);  // 06037FB0 mov.l r10,@(8,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06037FB2 mov.b @r7,r1
    c.r[12] += 7;  // 06037FB4 add #7,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06037FB6 extu.b r1,r1
    c.r[3] = c.r[1];  // 06037FB8 mov r1,r3
    c.r[3] <<= 8;  // 06037FBA shll8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06037FBC mov.b @r6,r1
    c.r[9] = c.r[14];  // 06037FBE mov r14,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06037FC0 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06037FC2 or r1,r3
    st16(c.r[14], c.r[3]);  // 06037FC4 mov.w r3,@r14
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06037FC6 mov.b @r13,r2
    c.r[9] += 2;  // 06037FC8 add #2,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06037FCA mov.b @r12,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06037FCC extu.b r2,r2
    c.r[2] <<= 8;  // 06037FCE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06037FD0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06037FD2 or r1,r2
    st16(c.r[9], c.r[2]);  // 06037FD4 mov.w r2,@r9
    c.r[1] = ld32(0x06038098u);  // 06037FD6 mov.l 0x06038098,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037FD8 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06037FDA extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06037FDC cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0603802C; } }  // 06037FDE bf/s 0x0603802C ; mov r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06037FE2 tst r1,r1
    if (c.t) { goto L_06037FFE; }  // 06037FE4 bt 0x06037FFE
    c.r[0] = ld32(0x0603809Cu);  // 06037FE6 mov.l 0x0603809C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06037FECu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037FECu) return; }  // 06037FE8 jsr @r0 ; mov r14,r4
    c.r[6] = c.r[0] & 0xFFu;  // 06037FEC extu.b r0,r6
    c.r[1] = c.r[14];  // 06037FEE mov r14,r1
    c.r[1] += 1;  // 06037FF0 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06037FF2 mov.b @r1,r5
    c.r[7] = c.r[10];  // 06037FF4 mov r10,r7
    c.r[4] = c.r[11];  // 06037FF6 mov r11,r4
    c.r[1] = ld32(0x060380A0u);  // 06037FF8 mov.l 0x060380A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06037FFEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06037FFEu) return; }  // 06037FFA jsr @r1 ; extu.b r5,r5
L_06037FFE:
    c.r[0] = ld32(0x0603809Cu);  // 06037FFE mov.l 0x0603809C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06038004u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038004u) return; }  // 06038000 jsr @r0 ; mov r9,r4
    c.r[2] = ld32(0x060380A4u);  // 06038004 mov.l 0x060380A4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06038006 mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06038008 cmp/pz r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603800A mov.w @r2,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06038094u);  // 0603800C mov.w 0x06038094,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603800E exts.w r3,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 06038010 exts.w r6,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06038012 cmp/gt r1,r2
    { const bool k = !c.t; c.r[0] = c.r[0] & 0xFFFFu; if (k) { goto L_0603801A; } }  // 06038014 bf/s 0x0603801A ; extu.w r0,r0
    c.r[6] = c.r[3];  // 06038018 mov r3,r6
L_0603801A:
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603801A exts.w r6,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0603801C mov.w @r9,r1
    c.r[5] = c.r[10];  // 0603801E mov r10,r5
    c.r[4] = c.r[11];  // 06038020 mov r11,r4
    c.r[1] <<= 2;  // 06038022 shll2 r1
    c.r[1] <<= 2;  // 06038024 shll2 r1
    c.r[0] += c.r[1];  // 06038026 add r1,r0
    c.r[7] = c.r[0] & 0xFFFFu; goto L_06038076;  // 06038028 bra 0x06038076 ; extu.w r0,r7
L_0603802C:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603802C tst r1,r1
    if (c.t) { goto L_0603804A; }  // 0603802E bt 0x0603804A
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06038030 mov.b @r7,r1
    c.r[4] = c.r[11];  // 06038032 mov r11,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06038034 extu.b r1,r1
    st16(c.r[14], c.r[1]);  // 06038036 mov.w r1,@r14
    c.r[1] = c.r[14];  // 06038038 mov r14,r1
    c.r[1] += 1;  // 0603803A add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0603803C mov.b @r6,r6
    c.r[7] = c.r[10];  // 0603803E mov r10,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038040 mov.b @r1,r5
    c.r[6] = c.r[6] & 0xFFu;  // 06038042 extu.b r6,r6
    c.r[1] = ld32(0x060380A0u);  // 06038044 mov.l 0x060380A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603804Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603804Au) return; }  // 06038046 jsr @r1 ; extu.b r5,r5
L_0603804A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603804A mov.b @r13,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0603804C extu.b r1,r7
    st16(c.r[9], c.r[7]);  // 0603804E mov.w r7,@r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06038050 mov.b @r12,r1
    c.r[2] = ld32(0x060380A4u);  // 06038052 mov.l 0x060380A4,r2
    c.r[0] = c.r[1] & 0xFFu;  // 06038054 extu.b r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06038056 mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06038058 cmp/pz r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603805A mov.w @r2,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06038094u);  // 0603805C mov.w 0x06038094,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603805E exts.w r3,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 06038060 exts.w r6,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06038062 cmp/gt r1,r2
    if (!c.t) { goto L_06038068; }  // 06038064 bf 0x06038068
    c.r[6] = c.r[3];  // 06038066 mov r3,r6
L_06038068:
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 06038068 exts.w r6,r6
    c.r[1] = c.r[7];  // 0603806A mov r7,r1
    c.r[1] <<= 8;  // 0603806C shll8 r1
    c.r[0] += c.r[1];  // 0603806E add r1,r0
    c.r[5] = ld32(c.r[14] + 8);  // 06038070 mov.l @(8,r14),r5
    c.r[7] = c.r[0] & 0xFFFFu;  // 06038072 extu.w r0,r7
    c.r[4] = ld32(c.r[14] + 4);  // 06038074 mov.l @(4,r14),r4
L_06038076:
    c.r[1] = ld32(0x060380A8u);  // 06038076 mov.l 0x060380A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603807Cu; c.r[8] += 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603807Cu) return; }  // 06038078 jsr @r1 ; add #8,r8
    c.r[14] += 12;  // 0603807C add #12,r14
    c.r[15] = c.r[14];  // 0603807E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06038080 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038082 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06038084 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06038086 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06038088 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603808A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603808C mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603808E mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06038090 rts ; mov.l @r15+,r8
}

void f_060380AC(SH2Context& c) {
    ran[802] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060380AC mov.l r14,@-r15
    c.r[0] = c.r[5];  // 060380AE mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060380B0 mov.b @r0,r1
    c.r[6] = ld32(0x060380D8u);  // 060380B2 mov.l 0x060380D8,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060380B4 extu.b r1,r1
    st16(c.r[6], c.r[1]);  // 060380B6 mov.w r1,@r6
    st16(c.r[6], c.r[1]);  // 060380B8 mov.w r1,@r6
    c.r[3] = c.r[1];  // 060380BA mov r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060380D4u);  // 060380BC mov.w 0x060380D4,r7
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 060380BE exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060380C0 exts.w r7,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060380C2 cmp/gt r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060380CA; } }  // 060380C4 bf/s 0x060380CA ; mov r15,r14
    c.r[3] = c.r[7];  // 060380C8 mov r7,r3
L_060380CA:
    st16(c.r[6], c.r[3]);  // 060380CA mov.w r3,@r6
    c.r[15] = c.r[14];  // 060380CC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060380CE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 060380D0 rts ; add #1,r0
}

void f_060380DC(SH2Context& c) {
    ran[803] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060380DC mov.l r14,@-r15
    c.r[0] = c.r[5];  // 060380DE mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060380E0 mov.b @r0,r1
    c.r[7] = ld32(0x06038110u);  // 060380E2 mov.l 0x06038110,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060380E4 mov.w @r7,r2
    c.r[14] = c.r[15];  // 060380E6 mov r15,r14
    c.r[2] += c.r[1];  // 060380E8 add r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060380EA exts.w r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060380EC cmp/pz r1
    { const bool k = c.t; st16(c.r[7], c.r[2]); if (k) { goto L_060380F4; } }  // 060380EE bt/s 0x060380F4 ; mov.w r2,@r7
    c.r[2] = 0x0u;  // 060380F2 mov #0,r2
L_060380F4:
    st16(c.r[7], c.r[2]);  // 060380F4 mov.w r2,@r7
    c.r[3] = c.r[2];  // 060380F6 mov r2,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603810Eu);  // 060380F8 mov.w 0x0603810E,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 060380FA exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060380FC exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060380FE cmp/gt r1,r2
    if (!c.t) { goto L_06038104; }  // 06038100 bf 0x06038104
    c.r[3] = c.r[6];  // 06038102 mov r6,r3
L_06038104:
    st16(c.r[7], c.r[3]);  // 06038104 mov.w r3,@r7
    c.r[15] = c.r[14];  // 06038106 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038108 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603810A rts ; add #1,r0
}

void f_06038114(SH2Context& c) {
    ran[804] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038114 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038116 mov.l r14,@-r15
    c.r[6] = c.r[5];  // 06038118 mov r5,r6
    c.r[0] = c.r[6];  // 0603811A mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603811C mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603811E extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038120 mov.b @r0,r1
    c.r[2] <<= 8;  // 06038122 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038124 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038126 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038128 exts.w r2,r2
    c.r[3] = c.r[2];  // 0603812A mov r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603812C tst r3,r3
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603814C; } }  // 0603812E bf/s 0x0603814C ; mov r15,r14
    c.r[2] = ld32(c.r[4]);  // 06038132 mov.l @r4,r2
    c.r[3] = ld32(0x060381A8u);  // 06038134 mov.l 0x060381A8,r3
    c.r[1] = ld32(0x060381ACu);  // 06038136 mov.l 0x060381AC,r1
    c.r[6] += 2;  // 06038138 add #2,r6
    c.r[0] = c.r[6];  // 0603813A mov r6,r0
    c.r[3] &= c.r[2];  // 0603813C and r2,r3
    c.r[1] &= c.r[2];  // 0603813E and r2,r1
    c.r[3] |= c.r[1];  // 06038140 or r1,r3
    st32(c.r[4], c.r[3]);  // 06038142 mov.l r3,@r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060381A2u);  // 06038144 mov.w 0x060381A2,r1
    st32(c.r[4] + 44, c.r[1]);  // 06038146 mov.l r1,@(44,r4)
    st32(c.r[4] + 48, c.r[1]); goto L_0603819A;  // 06038148 bra 0x0603819A ; mov.l r1,@(48,r4)
L_0603814C:
    c.r[2] = ld32(0x060381ACu);  // 0603814C mov.l 0x060381AC,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060381A2u);  // 0603814E mov.w 0x060381A2,r7
    c.r[1] = ld32(c.r[4]);  // 06038150 mov.l @r4,r1
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[3] * (int16_t)c.r[7]);  // 06038152 muls.w r7,r3
    c.r[0] = c.r[1];  // 06038154 mov r1,r0
    c.r[0] >>= 8;  // 06038156 shlr8 r0
    c.r[0] += c.r[0];  // 06038158 add r0,r0
    c.r[0] >>= 8;  // 0603815A shlr8 r0
    c.r[0] &= 0x3u;  // 0603815C and #3,r0
    c.r[0] |= 0x1u;  // 0603815E or #1,r0
    c.r[0] <<= 8;  // 06038160 shll8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038162 shlr r0
    c.r[0] <<= 8;  // 06038164 shll8 r0
    c.r[2] &= c.r[1];  // 06038166 and r1,r2
    c.r[0] |= c.r[2];  // 06038168 or r2,r0
    st32(c.r[4], c.r[0]);  // 0603816A mov.l r0,@r4
    c.r[8] = c.macl;  // 0603816C sts macl,r8
    st32(c.r[4] + 44, c.r[8]);  // 0603816E mov.l r8,@(44,r4)
    st32(c.r[4] + 48, c.r[8]);  // 06038170 mov.l r8,@(48,r4)
    c.r[1] = ld32(c.r[4] + 44);  // 06038172 mov.l @(44,r4),r1
    c.r[2] = ld32(0x060381B0u);  // 06038174 mov.l 0x060381B0,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06038176 cmp/gt r2,r1
    if (!c.t) { goto L_0603817C; }  // 06038178 bf 0x0603817C
    st32(c.r[4] + 44, c.r[2]);  // 0603817A mov.l r2,@(44,r4)
L_0603817C:
    c.r[1] = ld32(c.r[4] + 44);  // 0603817C mov.l @(44,r4),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060381A4u);  // 0603817E mov.w 0x060381A4,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06038180 cmp/gt r3,r1
    if (c.t) { goto L_06038186; }  // 06038182 bt 0x06038186
    st32(c.r[4] + 44, c.r[7]);  // 06038184 mov.l r7,@(44,r4)
L_06038186:
    c.r[1] = ld32(c.r[4] + 48);  // 06038186 mov.l @(48,r4),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06038188 cmp/gt r2,r1
    if (!c.t) { goto L_0603818E; }  // 0603818A bf 0x0603818E
    st32(c.r[4] + 48, c.r[2]);  // 0603818C mov.l r2,@(48,r4)
L_0603818E:
    c.r[1] = ld32(c.r[4] + 48);  // 0603818E mov.l @(48,r4),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06038190 cmp/gt r3,r1
    if (c.t) { goto L_06038196; }  // 06038192 bt 0x06038196
    st32(c.r[4] + 48, c.r[7]);  // 06038194 mov.l r7,@(48,r4)
L_06038196:
    c.r[6] += 2;  // 06038196 add #2,r6
    c.r[0] = c.r[6];  // 06038198 mov r6,r0
L_0603819A:
    c.r[15] = c.r[14];  // 0603819A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603819C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603819E rts ; mov.l @r15+,r8
}

void f_060381B4(SH2Context& c) {
    ran[805] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060381B4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060381B6 mov r15,r14
    c.r[0] = ld32(c.r[4]);  // 060381B8 mov.l @r4,r0
    c.r[0] >>= 8;  // 060381BA shlr8 r0
    c.r[0] += c.r[0];  // 060381BC add r0,r0
    c.r[0] >>= 8;  // 060381BE shlr8 r0
    c.r[0] &= 0x1u;  // 060381C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060381C2 tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[5]; if (k) { goto L_0603820E; } }  // 060381C4 bt/s 0x0603820E ; mov r5,r6
    c.r[0] = c.r[6];  // 060381C8 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060381CA mov.b @r0+,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06038218u);  // 060381CC mov.w 0x06038218,r7
    c.r[2] = c.r[2] & 0xFFu;  // 060381CE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060381D0 mov.b @r0,r1
    c.r[2] <<= 8;  // 060381D2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060381D4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060381D6 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060381D8 exts.w r2,r2
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[2] * (int16_t)c.r[7]);  // 060381DA muls.w r7,r2
    c.r[2] = ld32(c.r[4] + 44);  // 060381DC mov.l @(44,r4),r2
    c.r[1] = c.macl;  // 060381DE sts macl,r1
    c.r[2] += c.r[1];  // 060381E0 add r1,r2
    st32(c.r[4] + 44, c.r[2]);  // 060381E2 mov.l r2,@(44,r4)
    c.r[2] = ld32(c.r[4] + 48);  // 060381E4 mov.l @(48,r4),r2
    c.r[2] += c.r[1];  // 060381E6 add r1,r2
    st32(c.r[4] + 48, c.r[2]);  // 060381E8 mov.l r2,@(48,r4)
    c.r[1] = ld32(c.r[4] + 44);  // 060381EA mov.l @(44,r4),r1
    c.r[2] = ld32(0x0603821Cu);  // 060381EC mov.l 0x0603821C,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060381EE cmp/gt r2,r1
    if (!c.t) { goto L_060381F4; }  // 060381F0 bf 0x060381F4
    st32(c.r[4] + 44, c.r[2]);  // 060381F2 mov.l r2,@(44,r4)
L_060381F4:
    c.r[1] = ld32(c.r[4] + 44);  // 060381F4 mov.l @(44,r4),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603821Au);  // 060381F6 mov.w 0x0603821A,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 060381F8 cmp/gt r3,r1
    if (c.t) { goto L_060381FE; }  // 060381FA bt 0x060381FE
    st32(c.r[4] + 44, c.r[7]);  // 060381FC mov.l r7,@(44,r4)
L_060381FE:
    c.r[1] = ld32(c.r[4] + 48);  // 060381FE mov.l @(48,r4),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06038200 cmp/gt r2,r1
    if (!c.t) { goto L_06038206; }  // 06038202 bf 0x06038206
    st32(c.r[4] + 48, c.r[2]);  // 06038204 mov.l r2,@(48,r4)
L_06038206:
    c.r[1] = ld32(c.r[4] + 48);  // 06038206 mov.l @(48,r4),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06038208 cmp/gt r3,r1
    if (c.t) { goto L_0603820E; }  // 0603820A bt 0x0603820E
    st32(c.r[4] + 48, c.r[7]);  // 0603820C mov.l r7,@(48,r4)
L_0603820E:
    c.r[6] += 2;  // 0603820E add #2,r6
    c.r[15] = c.r[14];  // 06038210 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038212 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 06038214 rts ; mov r6,r0
}

void f_06038220(SH2Context& c) {
    ran[806] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038220 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038222 mov.l r14,@-r15
    c.r[7] = c.r[5];  // 06038224 mov r5,r7
    c.r[0] = c.r[7];  // 06038226 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038228 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603822A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603822C mov.b @r0,r1
    c.r[2] <<= 8;  // 0603822E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038230 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038232 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038234 exts.w r2,r2
    c.r[3] = c.r[2];  // 06038236 mov r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06038238 tst r3,r3
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06038256; } }  // 0603823A bf/s 0x06038256 ; mov r15,r14
    c.r[2] = ld32(c.r[4]);  // 0603823E mov.l @r4,r2
    c.r[3] = ld32(0x060382A0u);  // 06038240 mov.l 0x060382A0,r3
    c.r[1] = ld32(0x060382A4u);  // 06038242 mov.l 0x060382A4,r1
    c.r[7] += 2;  // 06038244 add #2,r7
    c.r[0] = c.r[7];  // 06038246 mov r7,r0
    c.r[3] &= c.r[2];  // 06038248 and r2,r3
    c.r[1] &= c.r[2];  // 0603824A and r2,r1
    c.r[3] |= c.r[1];  // 0603824C or r1,r3
    st32(c.r[4], c.r[3]);  // 0603824E mov.l r3,@r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603829Au);  // 06038250 mov.w 0x0603829A,r1
    st32(c.r[4] + 44, c.r[1]); goto L_06038292;  // 06038252 bra 0x06038292 ; mov.l r1,@(44,r4)
L_06038256:
    c.r[1] = ld32(c.r[4]);  // 06038256 mov.l @r4,r1
    c.r[2] = ld32(0x060382A4u);  // 06038258 mov.l 0x060382A4,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603829Au);  // 0603825A mov.w 0x0603829A,r6
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[3] * (int16_t)c.r[6]);  // 0603825C muls.w r6,r3
    c.r[0] = c.r[1];  // 0603825E mov r1,r0
    c.r[0] >>= 8;  // 06038260 shlr8 r0
    c.r[0] += c.r[0];  // 06038262 add r0,r0
    c.r[0] >>= 8;  // 06038264 shlr8 r0
    c.r[0] &= 0x3u;  // 06038266 and #3,r0
    c.r[0] |= 0x1u;  // 06038268 or #1,r0
    c.r[0] <<= 8;  // 0603826A shll8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603826C shlr r0
    c.r[0] <<= 8;  // 0603826E shll8 r0
    c.r[2] &= c.r[1];  // 06038270 and r1,r2
    c.r[0] |= c.r[2];  // 06038272 or r2,r0
    st32(c.r[4], c.r[0]);  // 06038274 mov.l r0,@r4
    c.r[8] = c.macl;  // 06038276 sts macl,r8
    c.r[1] = c.macl;  // 06038278 sts macl,r1
    c.r[2] = ld32(0x060382A8u);  // 0603827A mov.l 0x060382A8,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0603827C cmp/gt r2,r1
    { const bool k = !c.t; st32(c.r[4] + 44, c.r[8]); if (k) { goto L_06038284; } }  // 0603827E bf/s 0x06038284 ; mov.l r8,@(44,r4)
    st32(c.r[4] + 44, c.r[2]);  // 06038282 mov.l r2,@(44,r4)
L_06038284:
    c.r[2] = ld32(c.r[4] + 44);  // 06038284 mov.l @(44,r4),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603829Cu);  // 06038286 mov.w 0x0603829C,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06038288 cmp/gt r1,r2
    if (c.t) { goto L_0603828E; }  // 0603828A bt 0x0603828E
    st32(c.r[4] + 44, c.r[6]);  // 0603828C mov.l r6,@(44,r4)
L_0603828E:
    c.r[7] += 2;  // 0603828E add #2,r7
    c.r[0] = c.r[7];  // 06038290 mov r7,r0
L_06038292:
    c.r[15] = c.r[14];  // 06038292 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038294 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06038296 rts ; mov.l @r15+,r8
}

void f_060382AC(SH2Context& c) {
    ran[807] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060382AC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060382AE mov r15,r14
    c.r[0] = ld32(c.r[4]);  // 060382B0 mov.l @r4,r0
    c.r[0] >>= 8;  // 060382B2 shlr8 r0
    c.r[0] += c.r[0];  // 060382B4 add r0,r0
    c.r[0] >>= 8;  // 060382B6 shlr8 r0
    c.r[0] &= 0x1u;  // 060382B8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060382BA tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_060382EE; } }  // 060382BC bt/s 0x060382EE ; mov r5,r7
    c.r[0] = c.r[7];  // 060382C0 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060382C2 mov.b @r0+,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060382F8u);  // 060382C4 mov.w 0x060382F8,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060382C6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060382C8 mov.b @r0,r1
    c.r[2] <<= 8;  // 060382CA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060382CC extu.b r1,r1
    c.r[2] |= c.r[1];  // 060382CE or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060382D0 exts.w r2,r2
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[2] * (int16_t)c.r[3]);  // 060382D2 muls.w r3,r2
    c.r[2] = ld32(c.r[4] + 44);  // 060382D4 mov.l @(44,r4),r2
    c.r[1] = c.macl;  // 060382D6 sts macl,r1
    c.r[2] += c.r[1];  // 060382D8 add r1,r2
    c.r[1] = ld32(0x060382FCu);  // 060382DA mov.l 0x060382FC,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060382DC cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[4] + 44, c.r[2]); if (k) { goto L_060382E4; } }  // 060382DE bf/s 0x060382E4 ; mov.l r2,@(44,r4)
    st32(c.r[4] + 44, c.r[1]);  // 060382E2 mov.l r1,@(44,r4)
L_060382E4:
    c.r[2] = ld32(c.r[4] + 44);  // 060382E4 mov.l @(44,r4),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060382FAu);  // 060382E6 mov.w 0x060382FA,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060382E8 cmp/gt r1,r2
    if (c.t) { goto L_060382EE; }  // 060382EA bt 0x060382EE
    st32(c.r[4] + 44, c.r[3]);  // 060382EC mov.l r3,@(44,r4)
L_060382EE:
    c.r[7] += 2;  // 060382EE add #2,r7
    c.r[15] = c.r[14];  // 060382F0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060382F2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 060382F4 rts ; mov r7,r0
}

void f_06038300(SH2Context& c) {
    ran[808] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038300 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038302 mov.l r14,@-r15
    c.r[7] = c.r[5];  // 06038304 mov r5,r7
    c.r[0] = c.r[7];  // 06038306 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038308 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603830A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603830C mov.b @r0,r1
    c.r[2] <<= 8;  // 0603830E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038310 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038312 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038314 exts.w r2,r2
    c.r[3] = c.r[2];  // 06038316 mov r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06038318 tst r3,r3
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06038336; } }  // 0603831A bf/s 0x06038336 ; mov r15,r14
    c.r[2] = ld32(c.r[4]);  // 0603831E mov.l @r4,r2
    c.r[3] = ld32(0x06038380u);  // 06038320 mov.l 0x06038380,r3
    c.r[1] = ld32(0x06038384u);  // 06038322 mov.l 0x06038384,r1
    c.r[7] += 2;  // 06038324 add #2,r7
    c.r[0] = c.r[7];  // 06038326 mov r7,r0
    c.r[3] &= c.r[2];  // 06038328 and r2,r3
    c.r[1] &= c.r[2];  // 0603832A and r2,r1
    c.r[3] |= c.r[1];  // 0603832C or r1,r3
    st32(c.r[4], c.r[3]);  // 0603832E mov.l r3,@r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603837Au);  // 06038330 mov.w 0x0603837A,r1
    st32(c.r[4] + 48, c.r[1]); goto L_06038372;  // 06038332 bra 0x06038372 ; mov.l r1,@(48,r4)
L_06038336:
    c.r[1] = ld32(c.r[4]);  // 06038336 mov.l @r4,r1
    c.r[2] = ld32(0x06038384u);  // 06038338 mov.l 0x06038384,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603837Au);  // 0603833A mov.w 0x0603837A,r6
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[3] * (int16_t)c.r[6]);  // 0603833C muls.w r6,r3
    c.r[0] = c.r[1];  // 0603833E mov r1,r0
    c.r[0] >>= 8;  // 06038340 shlr8 r0
    c.r[0] += c.r[0];  // 06038342 add r0,r0
    c.r[0] >>= 8;  // 06038344 shlr8 r0
    c.r[0] &= 0x3u;  // 06038346 and #3,r0
    c.r[0] |= 0x1u;  // 06038348 or #1,r0
    c.r[0] <<= 8;  // 0603834A shll8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603834C shlr r0
    c.r[0] <<= 8;  // 0603834E shll8 r0
    c.r[2] &= c.r[1];  // 06038350 and r1,r2
    c.r[0] |= c.r[2];  // 06038352 or r2,r0
    st32(c.r[4], c.r[0]);  // 06038354 mov.l r0,@r4
    c.r[8] = c.macl;  // 06038356 sts macl,r8
    c.r[1] = c.macl;  // 06038358 sts macl,r1
    c.r[2] = ld32(0x06038388u);  // 0603835A mov.l 0x06038388,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0603835C cmp/gt r2,r1
    { const bool k = !c.t; st32(c.r[4] + 48, c.r[8]); if (k) { goto L_06038364; } }  // 0603835E bf/s 0x06038364 ; mov.l r8,@(48,r4)
    st32(c.r[4] + 48, c.r[2]);  // 06038362 mov.l r2,@(48,r4)
L_06038364:
    c.r[2] = ld32(c.r[4] + 48);  // 06038364 mov.l @(48,r4),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603837Cu);  // 06038366 mov.w 0x0603837C,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06038368 cmp/gt r1,r2
    if (c.t) { goto L_0603836E; }  // 0603836A bt 0x0603836E
    st32(c.r[4] + 48, c.r[6]);  // 0603836C mov.l r6,@(48,r4)
L_0603836E:
    c.r[7] += 2;  // 0603836E add #2,r7
    c.r[0] = c.r[7];  // 06038370 mov r7,r0
L_06038372:
    c.r[15] = c.r[14];  // 06038372 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038374 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06038376 rts ; mov.l @r15+,r8
}

void f_0603838C(SH2Context& c) {
    ran[809] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603838C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603838E mov r15,r14
    c.r[0] = ld32(c.r[4]);  // 06038390 mov.l @r4,r0
    c.r[0] >>= 8;  // 06038392 shlr8 r0
    c.r[0] += c.r[0];  // 06038394 add r0,r0
    c.r[0] >>= 8;  // 06038396 shlr8 r0
    c.r[0] &= 0x1u;  // 06038398 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603839A tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_060383CE; } }  // 0603839C bt/s 0x060383CE ; mov r5,r7
    c.r[0] = c.r[7];  // 060383A0 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060383A2 mov.b @r0+,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060383D8u);  // 060383A4 mov.w 0x060383D8,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060383A6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060383A8 mov.b @r0,r1
    c.r[2] <<= 8;  // 060383AA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060383AC extu.b r1,r1
    c.r[2] |= c.r[1];  // 060383AE or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060383B0 exts.w r2,r2
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[2] * (int16_t)c.r[3]);  // 060383B2 muls.w r3,r2
    c.r[2] = ld32(c.r[4] + 48);  // 060383B4 mov.l @(48,r4),r2
    c.r[1] = c.macl;  // 060383B6 sts macl,r1
    c.r[2] += c.r[1];  // 060383B8 add r1,r2
    c.r[1] = ld32(0x060383DCu);  // 060383BA mov.l 0x060383DC,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060383BC cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[4] + 48, c.r[2]); if (k) { goto L_060383C4; } }  // 060383BE bf/s 0x060383C4 ; mov.l r2,@(48,r4)
    st32(c.r[4] + 48, c.r[1]);  // 060383C2 mov.l r1,@(48,r4)
L_060383C4:
    c.r[2] = ld32(c.r[4] + 48);  // 060383C4 mov.l @(48,r4),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060383DAu);  // 060383C6 mov.w 0x060383DA,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060383C8 cmp/gt r1,r2
    if (c.t) { goto L_060383CE; }  // 060383CA bt 0x060383CE
    st32(c.r[4] + 48, c.r[3]);  // 060383CC mov.l r3,@(48,r4)
L_060383CE:
    c.r[7] += 2;  // 060383CE add #2,r7
    c.r[15] = c.r[14];  // 060383D0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060383D2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 060383D4 rts ; mov r7,r0
}

void f_060383E0(SH2Context& c) {
    ran[810] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060383E0 mov.l r14,@-r15
    c.r[7] = c.r[5];  // 060383E2 mov r5,r7
    c.r[1] = c.r[7];  // 060383E4 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060383E6 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060383E8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060383EA mov.b @r1,r1
    c.r[2] <<= 8;  // 060383EC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060383EE extu.b r1,r1
    c.r[2] |= c.r[1];  // 060383F0 or r1,r2
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060383F2 exts.w r2,r3
    c.r[0] = c.r[3];  // 060383F4 mov r3,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060383F6 cmp/eq #-1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06038426; } }  // 060383F8 bt/s 0x06038426 ; mov r15,r14
    c.r[2] = ld32(c.r[4]);  // 060383FC mov.l @r4,r2
    c.r[1] = ld32(0x06038444u);  // 060383FE mov.l 0x06038444,r1
    c.r[7] += 2;  // 06038400 add #2,r7
    c.r[0] = c.r[2];  // 06038402 mov r2,r0
    c.r[0] >>= 8;  // 06038404 shlr8 r0
    c.r[0] += c.r[0];  // 06038406 add r0,r0
    c.r[0] >>= 8;  // 06038408 shlr8 r0
    c.r[0] &= 0x3u;  // 0603840A and #3,r0
    c.r[0] |= 0x2u;  // 0603840C or #2,r0
    c.r[0] <<= 8;  // 0603840E shll8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038410 shlr r0
    c.r[0] <<= 8;  // 06038412 shll8 r0
    c.r[1] &= c.r[2];  // 06038414 and r2,r1
    c.r[0] |= c.r[1];  // 06038416 or r1,r0
    st32(c.r[4], c.r[0]);  // 06038418 mov.l r0,@r4
    c.r[4] += 52;  // 0603841A add #52,r4
    c.r[1] = 0x12u;  // 0603841C mov #18,r1
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[3] * (int16_t)c.r[1]);  // 0603841E muls.w r1,r3
    c.r[0] = c.r[7];  // 06038420 mov r7,r0
    c.r[1] = c.macl; goto L_0603843C;  // 06038422 bra 0x0603843C ; sts macl,r1
L_06038426:
    c.r[2] = ld32(c.r[4]);  // 06038426 mov.l @r4,r2
    c.r[3] = ld32(0x06038448u);  // 06038428 mov.l 0x06038448,r3
    c.r[1] = ld32(0x06038444u);  // 0603842A mov.l 0x06038444,r1
    c.r[7] += 2;  // 0603842C add #2,r7
    c.r[0] = c.r[7];  // 0603842E mov r7,r0
    c.r[3] &= c.r[2];  // 06038430 and r2,r3
    c.r[1] &= c.r[2];  // 06038432 and r2,r1
    c.r[3] |= c.r[1];  // 06038434 or r1,r3
    st32(c.r[4], c.r[3]);  // 06038436 mov.l r3,@r4
    c.r[4] += 52;  // 06038438 add #52,r4
    c.r[1] = 0x0u;  // 0603843A mov #0,r1
L_0603843C:
    st16(c.r[4], c.r[1]);  // 0603843C mov.w r1,@r4
    c.r[15] = c.r[14];  // 0603843E mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06038440 rts ; mov.l @r15+,r14
}

void f_0603844C(SH2Context& c) {
    ran[811] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603844C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603844E mov r15,r14
    c.r[0] = ld32(c.r[4]);  // 06038450 mov.l @r4,r0
    c.r[0] >>= 8;  // 06038452 shlr8 r0
    c.r[0] += c.r[0];  // 06038454 add r0,r0
    c.r[0] >>= 8;  // 06038456 shlr8 r0
    c.r[0] &= 0x2u;  // 06038458 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603845A tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_06038480; } }  // 0603845C bt/s 0x06038480 ; mov r5,r7
    c.r[0] = c.r[7];  // 06038460 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038462 mov.b @r0+,r2
    c.r[3] = c.r[4];  // 06038464 mov r4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06038466 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038468 mov.b @r0,r1
    c.r[2] <<= 8;  // 0603846A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603846C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603846E or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038470 exts.w r2,r2
    c.r[1] = 0x12u;  // 06038472 mov #18,r1
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[2] * (int16_t)c.r[1]);  // 06038474 muls.w r1,r2
    c.r[3] += 52;  // 06038476 add #52,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06038478 mov.w @r3,r1
    c.r[2] = c.macl;  // 0603847A sts macl,r2
    c.r[2] += c.r[1];  // 0603847C add r1,r2
    st16(c.r[3], c.r[2]);  // 0603847E mov.w r2,@r3
L_06038480:
    c.r[7] += 2;  // 06038480 add #2,r7
    c.r[15] = c.r[14];  // 06038482 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038484 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06038486 rts ; mov r7,r0
}

void f_0603848C(SH2Context& c) {
    ran[812] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603848C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603848E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06038490 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06038492 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06038494 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06038496 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038498 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603849A sts.l pr,@-r15
    c.r[15] -= 8;  // 0603849C add #-8,r15
    c.r[14] = c.r[15];  // 0603849E mov r15,r14
    c.r[10] = c.r[4];  // 060384A0 mov r4,r10
    st32(c.r[14], c.r[5]);  // 060384A2 mov.l r5,@r14
    c.r[8] = ld32(0x06038660u);  // 060384A4 mov.l 0x06038660,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060384AAu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060384AAu) return; }  // 060384A6 jsr @r8 ; mov #4,r4
    st32(c.r[14] + 4, c.r[0]);  // 060384AA mov.l r0,@(4,r14)
    { const uint32_t x = c.r[8]; c.pr = 0x060384B0u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060384B0u) return; }  // 060384AC jsr @r8 ; mov #5,r4
    c.r[12] = c.r[0];  // 060384B0 mov r0,r12
    { const uint32_t x = c.r[8]; c.pr = 0x060384B6u; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060384B6u) return; }  // 060384B2 jsr @r8 ; mov #7,r4
    c.r[9] = c.r[0];  // 060384B6 mov r0,r9
    { const uint32_t x = c.r[8]; c.pr = 0x060384BCu; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060384BCu) return; }  // 060384B8 jsr @r8 ; mov #9,r4
    c.r[11] = c.r[0];  // 060384BC mov r0,r11
    { const uint32_t x = c.r[8]; c.pr = 0x060384C2u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060384C2u) return; }  // 060384BE jsr @r8 ; mov #10,r4
    c.r[13] = ld32(c.r[14]);  // 060384C2 mov.l @r14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060384C4 mov.b @r13,r1
    c.r[6] = c.r[0];  // 060384C6 mov r0,r6
    c.r[0] = c.r[1] & 0xFFu;  // 060384C8 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060384CA cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_060384D4; } }  // 060384CC bf/s 0x060384D4 ; mov #1,r1
    goto L_06038604;  // 060384D0 bra 0x06038604 ; nop
L_060384D4:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060384D4 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_060384E4; } }  // 060384D6 bt/s 0x060384E4 ; cmp/eq #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060384DA tst r0,r0
    { const bool k = c.t; c.r[13] += 1; if (k) { goto L_060384F0; } }  // 060384DC bt/s 0x060384F0 ; add #1,r13
    st32(c.r[14], c.r[13]); goto L_06038756;  // 060384E0 bra 0x06038756 ; mov.l r13,@r14
L_060384E4:
    { const bool k = !c.t; c.r[3] = c.r[9]; if (k) { goto L_060384EC; } }  // 060384E4 bf/s 0x060384EC ; mov r9,r3
    goto L_06038684;  // 060384E8 bra 0x06038684 ; nop
L_060384EC:
    c.r[13] = ld32(c.r[14]); goto L_06038752;  // 060384EC bra 0x06038752 ; mov.l @r14,r13
L_060384F0:
    c.r[3] = ld32(0x06038664u);  // 060384F0 mov.l 0x06038664,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060384F2 mov.b @r3,r1
    c.r[0] = c.r[1];  // 060384F4 mov r1,r0
    c.r[0] >>= 2;  // 060384F6 shlr2 r0
    c.r[0] >>= 2;  // 060384F8 shlr2 r0
    c.r[0] >>= 2;  // 060384FA shlr2 r0
    c.r[0] &= 0x1u;  // 060384FC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060384FE tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_06038538; } }  // 06038500 bt/s 0x06038538 ; mov r10,r2
    c.r[2] += 56;  // 06038504 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603864Cu);  // 06038506 mov.w 0x0603864C,r1
    st16(c.r[2], c.r[1]);  // 06038508 mov.w r1,@r2
    c.r[2] = c.r[10];  // 0603850A mov r10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603850C mov.b @r3,r1
    c.r[2] += 2;  // 0603850E add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038510 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038512 mov r1,r0
    c.r[0] >>= 2;  // 06038514 shlr2 r0
    c.r[0] >>= 2;  // 06038516 shlr2 r0
    c.r[0] >>= 2;  // 06038518 shlr2 r0
    c.r[1] >>= 2;  // 0603851A shlr2 r1
    c.r[1] >>= 2;  // 0603851C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603851E shlr r1
    c.r[1] >>= 2;  // 06038520 shlr2 r1
    c.r[0] &= 0x1u;  // 06038522 and #1,r0
    c.t = c.r[1] == c.r[0];  // 06038524 cmp/eq r0,r1
    c.r[13] = c.t;  // 06038526 movt r13
    c.r[1] = c.r[13];  // 06038528 mov r13,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603852A mov.b @r2,r0
    c.r[1] += c.r[1];  // 0603852C add r1,r1
    c.r[0] &= 0xFDu;  // 0603852E and #253,r0
    c.r[0] |= c.r[1];  // 06038530 or r1,r0
    c.r[1] = ld32(0x06038668u);  // 06038532 mov.l 0x06038668,r1
    st8(c.r[2], c.r[0]); goto L_0603856A;  // 06038534 bra 0x0603856A ; mov.b r0,@r2
L_06038538:
    c.r[2] += 56;  // 06038538 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603864Eu);  // 0603853A mov.w 0x0603864E,r1
    st16(c.r[2], c.r[1]);  // 0603853C mov.w r1,@r2
    c.r[2] = c.r[10];  // 0603853E mov r10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038540 mov.b @r3,r1
    c.r[2] += 2;  // 06038542 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038544 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038546 mov r1,r0
    c.r[0] >>= 2;  // 06038548 shlr2 r0
    c.r[0] >>= 2;  // 0603854A shlr2 r0
    c.r[0] >>= 2;  // 0603854C shlr2 r0
    c.r[1] >>= 2;  // 0603854E shlr2 r1
    c.r[1] >>= 2;  // 06038550 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06038552 shlr r1
    c.r[1] >>= 2;  // 06038554 shlr2 r1
    c.r[0] &= 0x1u;  // 06038556 and #1,r0
    c.t = c.r[1] == c.r[0];  // 06038558 cmp/eq r0,r1
    c.r[13] = c.t;  // 0603855A movt r13
    c.r[1] = c.r[13];  // 0603855C mov r13,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603855E mov.b @r2,r0
    c.r[1] += c.r[1];  // 06038560 add r1,r1
    c.r[0] &= 0xFDu;  // 06038562 and #253,r0
    c.r[0] |= c.r[1];  // 06038564 or r1,r0
    st8(c.r[2], c.r[0]);  // 06038566 mov.b r0,@r2
    c.r[1] = ld32(0x0603866Cu);  // 06038568 mov.l 0x0603866C,r1
L_0603856A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603856A mov.b @r1,r1
    c.r[6] += 56;  // 0603856C add #56,r6
    c.r[0] = c.r[1];  // 0603856E mov r1,r0
    c.r[0] >>= 2;  // 06038570 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038572 shlr r0
    c.r[0] >>= 2;  // 06038574 shlr2 r0
    c.r[0] &= 0x3u;  // 06038576 and #3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038650u);  // 06038578 mov.w 0x06038650,r1
    c.r[1] += c.r[0];  // 0603857A add r0,r1
    st16(c.r[6], c.r[1]);  // 0603857C mov.w r1,@r6
    c.r[7] = ld32(0x06038664u);  // 0603857E mov.l 0x06038664,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06038580 mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06038582 extu.b r1,r2
    c.r[3] = c.r[2];  // 06038584 mov r2,r3
    c.r[3] >>= 2;  // 06038586 shlr2 r3
    c.r[3] >>= 2;  // 06038588 shlr2 r3
    c.r[3] >>= 2;  // 0603858A shlr2 r3
    c.r[1] = 0x1u;  // 0603858C mov #1,r1
    c.r[1] &= c.r[3];  // 0603858E and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06038590 tst r1,r1
    c.r[1] = ld32(0x06038670u);  // 06038592 mov.l 0x06038670,r1
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_0603859C; } }  // 06038594 bt/s 0x0603859C ; add #1,r1
    c.r[1] = ld32(0x06038674u);  // 06038598 mov.l 0x06038674,r1
    c.r[1] += 1;  // 0603859A add #1,r1
L_0603859C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603859C mov.b @r1,r0
    c.r[0] &= 0x28u;  // 0603859E and #40,r0
    c.t = c.r[0] == 0x20u;  // 060385A0 cmp/eq #32,r0
    { const bool k = !c.t; c.r[2] >>= 2; if (k) { goto L_060385EA; } }  // 060385A2 bf/s 0x060385EA ; shlr2 r2
    c.r[2] >>= 2;  // 060385A6 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060385A8 shlr r2
    c.r[2] >>= 2;  // 060385AA shlr2 r2
    c.r[13] = 0x1u;  // 060385AC mov #1,r13
    c.r[3] &= c.r[13];  // 060385AE and r13,r3
    c.t = c.r[2] == c.r[3];  // 060385B0 cmp/eq r3,r2
    c.r[13] = c.t;  // 060385B2 movt r13
    c.r[1] = c.r[13];  // 060385B4 mov r13,r1
    c.r[2] = c.r[11];  // 060385B6 mov r11,r2
    c.r[2] += 2;  // 060385B8 add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060385BA mov.b @r2,r0
    c.r[1] += c.r[1];  // 060385BC add r1,r1
    c.r[0] &= 0xFDu;  // 060385BE and #253,r0
    c.r[0] |= c.r[1];  // 060385C0 or r1,r0
    st8(c.r[2], c.r[0]);  // 060385C2 mov.b r0,@r2
    c.r[2] = c.r[11];  // 060385C4 mov r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060385C6 mov.b @r7,r1
    c.r[0] = c.r[1];  // 060385C8 mov r1,r0
    c.r[0] >>= 2;  // 060385CA shlr2 r0
    c.r[0] >>= 2;  // 060385CC shlr2 r0
    c.r[0] >>= 2;  // 060385CE shlr2 r0
    c.r[0] &= 0x1u;  // 060385D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060385D2 tst r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038652u);  // 060385D4 mov.w 0x06038652,r1
    { const bool k = c.t; c.r[2] += 56; if (k) { goto L_060385DC; } }  // 060385D6 bt/s 0x060385DC ; add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038654u);  // 060385DA mov.w 0x06038654,r1
L_060385DC:
    st16(c.r[2], c.r[1]);  // 060385DC mov.w r1,@r2
    c.r[1] = c.r[11];  // 060385DE mov r11,r1
    c.r[1] += 1;  // 060385E0 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060385E2 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 060385E4 or #64,r0
    st8(c.r[1], c.r[0]); goto L_060385F2;  // 060385E6 bra 0x060385F2 ; mov.b r0,@r1
L_060385EA:
    c.r[1] = ld32(0x06038678u);  // 060385EA mov.l 0x06038678,r1
    c.r[5] = 0x9u;  // 060385EC mov #9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060385F2u; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060385F2u) return; }  // 060385EE jsr @r1 ; mov #9,r4
L_060385F2:
    c.r[13] = ld32(c.r[14] + 4);  // 060385F2 mov.l @(4,r14),r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038656u);  // 060385F4 mov.w 0x06038656,r1
    c.r[12] += 72;  // 060385F6 add #72,r12
    c.r[13] += 72;  // 060385F8 add #72,r13
    st32(c.r[14] + 4, c.r[13]);  // 060385FA mov.l r13,@(4,r14)
    st16(c.r[13], c.r[1]);  // 060385FC mov.w r1,@r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038658u);  // 060385FE mov.w 0x06038658,r1
    st16(c.r[12], c.r[1]); goto L_06038750;  // 06038600 bra 0x06038750 ; mov.w r1,@r12
L_06038604:
    c.r[1] = ld32(0x06038664u);  // 06038604 mov.l 0x06038664,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038606 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06038608 mov r1,r0
    c.r[0] >>= 2;  // 0603860A shlr2 r0
    c.r[0] >>= 2;  // 0603860C shlr2 r0
    c.r[0] >>= 2;  // 0603860E shlr2 r0
    c.r[0] &= 0x1u;  // 06038610 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038612 tst r0,r0
    { const bool k = c.t; c.r[7] = 0x10u; if (k) { goto L_0603862C; } }  // 06038614 bt/s 0x0603862C ; mov #16,r7
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603865Au);  // 06038618 mov.w 0x0603865A,r4
    c.r[8] = ld32(0x0603867Cu);  // 0603861A mov.l 0x0603867C,r8
    c.r[6] = 0x0u;  // 0603861C mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06038622u; c.r[5] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038622u) return; }  // 0603861E jsr @r8 ; mov #66,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603865Cu);  // 06038622 mov.w 0x0603865C,r4
    c.r[7] = 0x10u;  // 06038624 mov #16,r7
    c.r[6] = 0x0u;  // 06038626 mov #0,r6
    c.r[5] = 0x43u; goto L_0603863E;  // 06038628 bra 0x0603863E ; mov #67,r5
L_0603862C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603865Au);  // 0603862C mov.w 0x0603865A,r4
    c.r[8] = ld32(0x0603867Cu);  // 0603862E mov.l 0x0603867C,r8
    c.r[6] = 0x0u;  // 06038630 mov #0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06038636u; c.r[5] = 0x46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038636u) return; }  // 06038632 jsr @r8 ; mov #70,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603865Cu);  // 06038636 mov.w 0x0603865C,r4
    c.r[7] = 0x10u;  // 06038638 mov #16,r7
    c.r[6] = 0x0u;  // 0603863A mov #0,r6
    c.r[5] = 0x47u;  // 0603863C mov #71,r5
L_0603863E:
    { const uint32_t x = c.r[8]; c.pr = 0x06038642u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038642u) return; }  // 0603863E jsr @r8 ; nop
    c.r[2] = ld32(0x06038680u);  // 06038642 mov.l 0x06038680,r2
    c.r[1] = 0x1u;  // 06038644 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06038646 mov.w r1,@r2
    c.r[13] = ld32(c.r[14]); goto L_06038752;  // 06038648 bra 0x06038752 ; mov.l @r14,r13
L_06038684:
    c.r[3] += 56;  // 06038684 add #56,r3
    c.r[2] = c.r[6];  // 06038686 mov r6,r2
    c.r[2] += 56;  // 06038688 add #56,r2
    c.r[8] = ld32(0x06038780u);  // 0603868A mov.l 0x06038780,r8
    c.r[9] = ld32(0x06038784u);  // 0603868C mov.l 0x06038784,r9
    c.r[6] = 0x4Cu;  // 0603868E mov #76,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06038690 mov.w @r3,r7
    c.r[5] = c.r[12];  // 06038692 mov r12,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06038694 mov.w @r2,r1
    c.r[4] = c.r[8];  // 06038696 mov r8,r4
    st16(c.r[3], c.r[1]);  // 06038698 mov.w r1,@r3
    { const uint32_t x = c.r[9]; c.pr = 0x0603869Eu; st16(c.r[2], c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603869Eu) return; }  // 0603869A jsr @r9 ; mov.w r7,@r2
    c.r[1] = ld32(0x06038788u);  // 0603869E mov.l 0x06038788,r1
    c.r[4] = c.r[12];  // 060386A0 mov r12,r4
    c.r[5] = c.r[11];  // 060386A2 mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060386A8u; c.r[6] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060386A8u) return; }  // 060386A4 jsr @r1 ; mov #13,r6
    c.r[6] = 0x4Cu;  // 060386A8 mov #76,r6
    c.r[5] = c.r[8];  // 060386AA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060386B0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060386B0u) return; }  // 060386AC jsr @r9 ; mov r11,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060386B0 mov.b @r11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060386B2 mov.b @r12,r2
    st8(c.r[12], c.r[1]);  // 060386B4 mov.b r1,@r12
    st8(c.r[11], c.r[2]);  // 060386B6 mov.b r2,@r11
    c.r[2] = c.r[12];  // 060386B8 mov r12,r2
    c.r[2] += 65;  // 060386BA add #65,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060386BC mov.b @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603876Eu);  // 060386BE mov.w 0x0603876E,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060386C0 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060386C2 cmp/eq r3,r1
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_060386CA; } }  // 060386C4 bt/s 0x060386CA ; mov #4,r1
    st8(c.r[2], c.r[1]);  // 060386C8 mov.b r1,@r2
L_060386CA:
    c.r[2] = c.r[11];  // 060386CA mov r11,r2
    c.r[2] += 65;  // 060386CC add #65,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060386CE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060386D0 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060386D2 cmp/eq r3,r1
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_060386DE; } }  // 060386D4 bt/s 0x060386DE ; mov r10,r1
    c.r[1] = 0x8u;  // 060386D8 mov #8,r1
    st8(c.r[2], c.r[1]);  // 060386DA mov.b r1,@r2
    c.r[1] = c.r[10];  // 060386DC mov r10,r1
L_060386DE:
    c.r[1] += 63;  // 060386DE add #63,r1
    c.r[2] = 0x2u;  // 060386E0 mov #2,r2
    st8(c.r[1], c.r[2]);  // 060386E2 mov.b r2,@r1
    c.r[1] = c.r[11];  // 060386E4 mov r11,r1
    c.r[1] += 63;  // 060386E6 add #63,r1
    st8(c.r[1], c.r[2]);  // 060386E8 mov.b r2,@r1
    c.r[1] = ld32(0x0603878Cu);  // 060386EA mov.l 0x0603878C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060386EC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060386EE mov r1,r0
    c.r[0] >>= 2;  // 060386F0 shlr2 r0
    c.r[0] >>= 2;  // 060386F2 shlr2 r0
    c.r[0] >>= 2;  // 060386F4 shlr2 r0
    c.r[0] &= 0x1u;  // 060386F6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060386F8 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_0603870A; } }  // 060386FA bt/s 0x0603870A ; mov r10,r2
    c.r[2] += 56;  // 060386FE add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038770u);  // 06038700 mov.w 0x06038770,r1
    st16(c.r[2], c.r[1]);  // 06038702 mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038772u);  // 06038704 mov.w 0x06038772,r1
    c.r[2] = ld32(c.r[14] + 4); goto L_06038714;  // 06038706 bra 0x06038714 ; mov.l @(4,r14),r2
L_0603870A:
    c.r[2] += 56;  // 0603870A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038774u);  // 0603870C mov.w 0x06038774,r1
    st16(c.r[2], c.r[1]);  // 0603870E mov.w r1,@r2
    c.r[2] = ld32(c.r[14] + 4);  // 06038710 mov.l @(4,r14),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038776u);  // 06038712 mov.w 0x06038776,r1
L_06038714:
    c.r[2] += 56;  // 06038714 add #56,r2
    st16(c.r[2], c.r[1]);  // 06038716 mov.w r1,@r2
    c.r[1] = 0x10u;  // 06038718 mov #16,r1
    c.r[12] += 72;  // 0603871A add #72,r12
    c.r[10] += 72;  // 0603871C add #72,r10
    c.r[11] += 72;  // 0603871E add #72,r11
    c.r[13] = ld32(c.r[14] + 4);  // 06038720 mov.l @(4,r14),r13
    c.r[2] = ld32(0x0603878Cu);  // 06038722 mov.l 0x0603878C,r2
    c.r[13] += 72;  // 06038724 add #72,r13
    st32(c.r[14] + 4, c.r[13]);  // 06038726 mov.l r13,@(4,r14)
    st16(c.r[13], c.r[1]);  // 06038728 mov.w r1,@r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038778u);  // 0603872A mov.w 0x06038778,r1
    st16(c.r[12], c.r[1]);  // 0603872C mov.w r1,@r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603877Au);  // 0603872E mov.w 0x0603877A,r1
    st16(c.r[10], c.r[1]);  // 06038730 mov.w r1,@r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603877Cu);  // 06038732 mov.w 0x0603877C,r1
    st16(c.r[11], c.r[1]);  // 06038734 mov.w r1,@r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06038736 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06038738 mov r1,r0
    c.r[0] >>= 2;  // 0603873A shlr2 r0
    c.r[0] >>= 2;  // 0603873C shlr2 r0
    c.r[0] >>= 2;  // 0603873E shlr2 r0
    c.r[0] &= 0x1u;  // 06038740 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038742 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0603874C; } }  // 06038744 bt/s 0x0603874C ; mov r1,r0
    c.r[0] |= 0x10u; goto L_0603874E;  // 06038748 bra 0x0603874E ; or #16,r0
L_0603874C:
    c.r[0] |= 0x8u;  // 0603874C or #8,r0
L_0603874E:
    st8(c.r[2], c.r[0]);  // 0603874E mov.b r0,@r2
L_06038750:
    c.r[13] = ld32(c.r[14]);  // 06038750 mov.l @r14,r13
L_06038752:
    c.r[13] += 1;  // 06038752 add #1,r13
    st32(c.r[14], c.r[13]);  // 06038754 mov.l r13,@r14
L_06038756:
    c.r[0] = ld32(c.r[14]);  // 06038756 mov.l @r14,r0
    c.r[14] += 8;  // 06038758 add #8,r14
    c.r[15] = c.r[14];  // 0603875A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603875C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603875E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06038760 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06038762 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06038764 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06038766 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06038768 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603876A rts ; mov.l @r15+,r8
}

void f_06038790(SH2Context& c) {
    ran[813] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038790 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06038792 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06038794 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06038796 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038798 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603879A sts.l pr,@-r15
    c.r[15] -= 12;  // 0603879C add #-12,r15
    c.r[14] = c.r[15];  // 0603879E mov r15,r14
    c.r[11] = c.r[4];  // 060387A0 mov r4,r11
    c.r[8] = c.r[5];  // 060387A2 mov r5,r8
    c.r[1] = 0x0u;  // 060387A4 mov #0,r1
    st16(c.r[14], c.r[1]);  // 060387A6 mov.w r1,@r14
    c.r[2] = c.r[14];  // 060387A8 mov r14,r2
    c.r[2] += 2;  // 060387AA add #2,r2
    c.r[1] = 0x1u;  // 060387AC mov #1,r1
    st16(c.r[2], c.r[1]);  // 060387AE mov.w r1,@r2
    c.r[2] = c.r[14];  // 060387B0 mov r14,r2
    c.r[2] += 4;  // 060387B2 add #4,r2
    c.r[1] = 0x2u;  // 060387B4 mov #2,r1
    st16(c.r[2], c.r[1]);  // 060387B6 mov.w r1,@r2
    c.r[9] = c.r[14];  // 060387B8 mov r14,r9
    c.r[9] += 6;  // 060387BA add #6,r9
    c.r[1] = 0x4u;  // 060387BC mov #4,r1
    st16(c.r[9], c.r[1]);  // 060387BE mov.w r1,@r9
    c.r[2] = c.r[14];  // 060387C0 mov r14,r2
    c.r[2] += 8;  // 060387C2 add #8,r2
    c.r[1] = 0x8u;  // 060387C4 mov #8,r1
    st16(c.r[2], c.r[1]);  // 060387C6 mov.w r1,@r2
    c.r[10] = c.r[14];  // 060387C8 mov r14,r10
    c.r[10] += 10;  // 060387CA add #10,r10
    c.r[1] = 0x10u;  // 060387CC mov #16,r1
    st16(c.r[10], c.r[1]);  // 060387CE mov.w r1,@r10
    c.r[1] = c.r[8];  // 060387D0 mov r8,r1
    c.r[1] += 1;  // 060387D2 add #1,r1
    c.r[3] = 0x60u;  // 060387D4 mov #96,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060387D6 mov.b @r1,r1
    c.r[6] = ld32(0x060388C0u);  // 060387D8 mov.l 0x060388C0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060387DA mov.b @r8,r0
    c.r[7] = c.r[1] & 0xFFu;  // 060387DC extu.b r1,r7
    c.r[4] = c.r[7];  // 060387DE mov r7,r4
    c.r[3] &= c.r[0];  // 060387E0 and r0,r3
    c.r[0] &= 0x80u;  // 060387E2 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060387E4 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060387EC; } }  // 060387E6 bt/s 0x060387EC ; mov #1,r1
    c.r[1] = 0x2u;  // 060387EA mov #2,r1
L_060387EC:
    c.r[5] = c.r[6];  // 060387EC mov r6,r5
    c.r[5] += 1;  // 060387EE add #1,r5
    c.r[1] += c.r[1];  // 060387F0 add r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060387F2 mov.b @r5,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060388BCu);  // 060387F4 mov.w 0x060388BC,r0
    c.r[2] &= c.r[0];  // 060387F6 and r0,r2
    c.r[2] |= c.r[1];  // 060387F8 or r1,r2
    st8(c.r[5], c.r[2]);  // 060387FA mov.b r2,@r5
    c.r[2] = c.r[3];  // 060387FC mov r3,r2
    c.r[2] >>= 2;  // 060387FE shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06038800 shlr r2
    c.r[2] >>= 2;  // 06038802 shlr2 r2
    c.r[2] += c.r[6];  // 06038804 add r6,r2
    c.r[2] += 6;  // 06038806 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06038808 mov.b @r8,r1
    c.r[0] = 0x1Fu;  // 0603880A mov #31,r0
    c.r[1] = ~c.r[1];  // 0603880C not r1,r1
    c.r[1] &= c.r[0];  // 0603880E and r0,r1
    st8(c.r[2], c.r[1]);  // 06038810 mov.b r1,@r2
    c.r[1] = c.r[11];  // 06038812 mov r11,r1
    c.r[1] += 62;  // 06038814 add #62,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038816 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060388BEu);  // 06038818 mov.w 0x060388BE,r0
    c.r[2] |= c.r[0];  // 0603881A or r0,r2
    c.r[3] |= c.r[2];  // 0603881C or r2,r3
    st8(c.r[1], c.r[3]);  // 0603881E mov.b r3,@r1
    c.r[1] = 0x1u;  // 06038820 mov #1,r1
    c.r[1] &= c.r[7];  // 06038822 and r7,r1
    c.r[1] += c.r[1];  // 06038824 add r1,r1
    c.r[0] = c.r[1];  // 06038826 mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06038828 mov.w @(r0,r14),r2
    c.r[1] = 0x2u;  // 0603882A mov #2,r1
    c.r[1] &= c.r[7];  // 0603882C and r7,r1
    c.r[1] += c.r[1];  // 0603882E add r1,r1
    c.r[0] = c.r[1];  // 06038830 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06038832 mov.w @(r0,r14),r1
    c.r[1] |= c.r[2];  // 06038834 or r2,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06038836 extu.w r1,r3
    c.r[0] = 0x4u;  // 06038838 mov #4,r0
    c.r[7] &= c.r[0];  // 0603883A and r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0603883C tst r7,r7
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06038844; } }  // 0603883E bt/s 0x06038844 ; mov r14,r1
    c.r[1] = c.r[9];  // 06038842 mov r9,r1
L_06038844:
    c.r[2] = c.r[3];  // 06038844 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06038846 mov.w @r1,r1
    c.r[0] = c.r[14];  // 06038848 mov r14,r0
    c.r[2] |= c.r[1];  // 0603884A or r1,r2
    c.r[1] = 0x8u;  // 0603884C mov #8,r1
    c.r[1] &= c.r[4];  // 0603884E and r4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06038850 mov.w @(r0,r1),r1
    c.r[2] |= c.r[1];  // 06038852 or r1,r2
    c.r[3] = c.r[2] & 0xFFFFu;  // 06038854 extu.w r2,r3
    c.r[0] = 0x10u;  // 06038856 mov #16,r0
    c.r[4] &= c.r[0];  // 06038858 and r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0603885A tst r4,r4
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06038862; } }  // 0603885C bt/s 0x06038862 ; mov r14,r1
    c.r[1] = c.r[10];  // 06038860 mov r10,r1
L_06038862:
    c.r[2] = c.r[6];  // 06038862 mov r6,r2
    c.r[2] += 2;  // 06038864 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06038866 mov.w @r1,r1
    c.r[6] += 4;  // 06038868 add #4,r6
    c.r[3] |= c.r[1];  // 0603886A or r1,r3
    c.r[1] = 0x40u;  // 0603886C mov #64,r1
    st16(c.r[2], c.r[1]);  // 0603886E mov.w r1,@r2
    st16(c.r[6], c.r[3]);  // 06038870 mov.w r3,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06038872 mov.b @r5,r1
    c.r[0] = c.r[1];  // 06038874 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038876 shlr r0
    c.r[0] &= 0x3u;  // 06038878 and #3,r0
    c.t = c.r[0] == 0x2u;  // 0603887A cmp/eq #2,r0
    if (!c.t) { goto L_06038894; }  // 0603887C bf 0x06038894
    c.r[1] = ld32(0x060388C4u);  // 0603887E mov.l 0x060388C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038880 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038882 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038884 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06038886 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = 0x22u; if (k) { goto L_0603888E; } }  // 06038888 bf/s 0x0603888E ; mov #34,r2
    c.r[2] = c.r[1];  // 0603888C mov r1,r2
L_0603888E:
    c.r[1] = ld32(0x060388C8u);  // 0603888E mov.l 0x060388C8,r1
    c.r[4] = c.r[2]; goto L_060388A4;  // 06038890 bra 0x060388A4 ; mov r2,r4
L_06038894:
    c.r[1] = ld32(0x060388C4u);  // 06038894 mov.l 0x060388C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038896 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06038898 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603889A cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = 0x23u; if (k) { goto L_060388A2; } }  // 0603889C bf/s 0x060388A2 ; mov #35,r4
    c.r[4] = 0x3u;  // 060388A0 mov #3,r4
L_060388A2:
    c.r[1] = ld32(0x060388C8u);  // 060388A2 mov.l 0x060388C8,r1
L_060388A4:
    { const uint32_t x = c.r[1]; c.pr = 0x060388A8u; c.r[8] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060388A8u) return; }  // 060388A4 jsr @r1 ; add #2,r8
    c.r[14] += 12;  // 060388A8 add #12,r14
    c.r[15] = c.r[14];  // 060388AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060388AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060388AE mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060388B0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060388B2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060388B4 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 060388B6 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060388B8 rts ; mov.l @r15+,r8
}

void f_060388CC(SH2Context& c) {
    ran[814] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060388CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060388CE mov r15,r14
    c.r[1] = c.r[5];  // 060388D0 mov r5,r1
    c.r[4] += 62;  // 060388D2 add #62,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060388D4 mov.b @r4,r0
    c.r[0] &= 0x7Fu;  // 060388D6 and #127,r0
    st8(c.r[4], c.r[0]);  // 060388D8 mov.b r0,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060388DA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 060388DC rts ; mov r1,r0
}

void f_060388E0(SH2Context& c) {
    ran[815] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060388E0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060388E2 mov r15,r14
    c.r[0] = c.r[5];  // 060388E4 mov r5,r0
    c.r[4] += 64;  // 060388E6 add #64,r4
    c.r[2] = 0xFu;  // 060388E8 mov #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060388EA mov.b @r0+,r1
    c.r[1] &= c.r[2];  // 060388EC and r2,r1
    st8(c.r[4], c.r[1]);  // 060388EE mov.b r1,@r4
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060388F0 rts ; mov.l @r15+,r14
}

void f_060388F4(SH2Context& c) {
    ran[816] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060388F4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060388F6 mov r15,r14
    c.r[1] = ld32(0x06038944u);  // 060388F8 mov.l 0x06038944,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060388FA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060388FC extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060388FE cmp/eq #1,r0
    { const bool k = !c.t; c.r[7] = c.r[5]; if (k) { goto L_0603891E; } }  // 06038900 bf/s 0x0603891E ; mov r5,r7
    c.r[3] = c.r[7];  // 06038904 mov r7,r3
    c.r[2] = ld32(0x06038948u);  // 06038906 mov.l 0x06038948,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06038908 mov.b @r3+,r1
    c.r[0] = 0x1Fu;  // 0603890A mov #31,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0603890C extu.b r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603890E mov.b @r3,r3
    c.r[1] >>= 2;  // 06038910 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06038912 shlr r1
    c.r[1] >>= 2;  // 06038914 shlr2 r1
    c.r[3] &= c.r[0];  // 06038916 and r0,r3
    c.r[0] = c.r[1];  // 06038918 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]); goto L_06038938;  // 0603891A bra 0x06038938 ; mov.b r3,@(r0,r2)
L_0603891E:
    c.r[2] = c.r[7];  // 0603891E mov r7,r2
    c.r[3] = ld32(0x06038948u);  // 06038920 mov.l 0x06038948,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06038922 mov.b @r2+,r1
    c.r[0] = 0x1Fu;  // 06038924 mov #31,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06038926 extu.b r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06038928 mov.b @r2,r2
    c.r[1] >>= 2;  // 0603892A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603892C shlr r1
    c.r[1] >>= 2;  // 0603892E shlr2 r1
    c.r[2] = ~c.r[2];  // 06038930 not r2,r2
    c.r[2] &= c.r[0];  // 06038932 and r0,r2
    c.r[0] = c.r[1];  // 06038934 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06038936 mov.b r2,@(r0,r3)
L_06038938:
    c.r[7] += 2;  // 06038938 add #2,r7
    c.r[15] = c.r[14];  // 0603893A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603893C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603893E rts ; mov r7,r0
}

void f_0603894C(SH2Context& c) {
    ran[817] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603894C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603894E mov r15,r14
    c.r[1] = ld32(0x060389C4u);  // 06038950 mov.l 0x060389C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038952 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06038954 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06038956 cmp/eq #1,r0
    { const bool k = !c.t; c.r[3] = c.r[5]; if (k) { goto L_0603898E; } }  // 06038958 bf/s 0x0603898E ; mov r5,r3
    c.r[0] = c.r[3];  // 0603895C mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603895E mov.b @r0+,r1
    c.r[6] = ld32(0x060389C8u);  // 06038960 mov.l 0x060389C8,r6
    c.r[7] = c.r[1] & 0xFFu;  // 06038962 extu.b r1,r7
    c.r[1] = c.r[7];  // 06038964 mov r7,r1
    c.r[1] >>= 2;  // 06038966 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06038968 shlr r1
    c.r[1] >>= 2;  // 0603896A shlr2 r1
    c.r[1] += c.r[6];  // 0603896C add r6,r1
    c.r[1] += 6;  // 0603896E add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038970 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06038972 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038974 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038976 extu.b r1,r1
    c.r[2] += c.r[1];  // 06038978 add r1,r2
    c.r[1] = 0x1Eu;  // 0603897A mov #30,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603897C cmp/gt r1,r2
    if (!c.t) { goto L_06038982; }  // 0603897E bf 0x06038982
    c.r[2] = 0x1Fu;  // 06038980 mov #31,r2
L_06038982:
    c.t = (int32_t)c.r[2] > 0;  // 06038982 cmp/pl r2
    if (c.t) { goto L_06038988; }  // 06038984 bt 0x06038988
    c.r[2] = 0x0u;  // 06038986 mov #0,r2
L_06038988:
    c.r[7] += c.r[6];  // 06038988 add r6,r7
    c.r[7] += 6; goto L_060389B8;  // 0603898A bra 0x060389B8 ; add #6,r7
L_0603898E:
    c.r[0] = c.r[3];  // 0603898E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038990 mov.b @r0+,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06038992 extu.b r1,r7
    c.r[7] >>= 2;  // 06038994 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06038996 shlr r7
    c.r[7] >>= 2;  // 06038998 shlr2 r7
    c.r[1] = ld32(0x060389CCu);  // 0603899A mov.l 0x060389CC,r1
    c.r[7] += c.r[1];  // 0603899C add r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603899E mov.b @r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060389A0 mov.b @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060389A2 extu.b r1,r1
    c.r[4] = c.r[1];  // 060389A4 mov r1,r4
    c.r[4] -= c.r[2];  // 060389A6 sub r2,r4
    c.r[2] = c.r[4];  // 060389A8 mov r4,r2
    c.r[1] = 0x1Eu;  // 060389AA mov #30,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060389AC cmp/gt r1,r2
    if (!c.t) { goto L_060389B2; }  // 060389AE bf 0x060389B2
    c.r[2] = 0x1Fu;  // 060389B0 mov #31,r2
L_060389B2:
    c.t = (int32_t)c.r[2] > 0;  // 060389B2 cmp/pl r2
    if (c.t) { goto L_060389B8; }  // 060389B4 bt 0x060389B8
    c.r[2] = 0x0u;  // 060389B6 mov #0,r2
L_060389B8:
    st8(c.r[7], c.r[2]);  // 060389B8 mov.b r2,@r7
    c.r[3] += 2;  // 060389BA add #2,r3
    c.r[15] = c.r[14];  // 060389BC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060389BE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 060389C0 rts ; mov r3,r0
}

void f_060389D0(SH2Context& c) {
    ran[818] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060389D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060389D2 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060389D4 mov r15,r14
    c.r[1] = ld32(0x06038A20u);  // 060389D6 mov.l 0x06038A20,r1
    c.r[3] = c.r[4];  // 060389D8 mov r4,r3
    c.r[3] += 56;  // 060389DA add #56,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06038A1Cu);  // 060389DC mov.w 0x06038A1C,r6
    c.r[8] = (uint32_t)(int16_t)ld16(0x06038A1Eu);  // 060389DE mov.w 0x06038A1E,r8
    c.r[2] = ld32(c.r[1]);  // 060389E0 mov.l @r1,r2
    c.r[7] = c.r[2];  // 060389E2 mov r2,r7
    c.r[7] += 76;  // 060389E4 add #76,r7
    c.r[1] = c.r[7];  // 060389E6 mov r7,r1
    c.r[1] += 56;  // 060389E8 add #56,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060389EA mov.w @r1,r1
    c.r[2] += 78;  // 060389EC add #78,r2
    st16(c.r[3], c.r[1]);  // 060389EE mov.w r1,@r3
    c.r[1] = c.r[4];  // 060389F0 mov r4,r1
    c.r[1] += 2;  // 060389F2 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060389F4 mov.b @r2,r0
    c.r[3] = 0x2u;  // 060389F6 mov #2,r3
    c.r[3] &= c.r[0];  // 060389F8 and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060389FA mov.b @r1,r0
    c.r[7] += 58;  // 060389FC add #58,r7
    c.r[6] &= c.r[0];  // 060389FE and r0,r6
    c.r[6] |= c.r[3];  // 06038A00 or r3,r6
    st8(c.r[1], c.r[6]);  // 06038A02 mov.b r6,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06038A04 mov.b @r2,r0
    c.r[6] &= c.r[8];  // 06038A06 and r8,r6
    c.r[0] &= 0x1u;  // 06038A08 and #1,r0
    c.r[6] |= c.r[0];  // 06038A0A or r0,r6
    st8(c.r[1], c.r[6]);  // 06038A0C mov.b r6,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06038A0E mov.w @r7,r1
    c.r[4] += 58;  // 06038A10 add #58,r4
    st16(c.r[4], c.r[1]);  // 06038A12 mov.w r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038A14 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06038A16 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06038A18 rts ; mov r5,r0
}

void f_06038A24(SH2Context& c) {
    ran[819] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038A24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038A26 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038A28 mov r15,r14
    c.r[1] = ld32(0x06038A78u);  // 06038A2A mov.l 0x06038A78,r1
    c.r[2] = c.r[4];  // 06038A2C mov r4,r2
    c.r[2] += 56;  // 06038A2E add #56,r2
    c.r[7] = 0x2u;  // 06038A30 mov #2,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06038A72u);  // 06038A32 mov.w 0x06038A72,r6
    c.r[3] = ld32(c.r[1]);  // 06038A34 mov.l @r1,r3
    c.r[8] = (uint32_t)(int16_t)ld16(0x06038A74u);  // 06038A36 mov.w 0x06038A74,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038A76u);  // 06038A38 mov.w 0x06038A76,r1
    c.r[3] += c.r[1];  // 06038A3A add r1,r3
    c.r[1] = c.r[3];  // 06038A3C mov r3,r1
    c.r[1] += 56;  // 06038A3E add #56,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06038A40 mov.w @r1,r1
    st16(c.r[2], c.r[1]);  // 06038A42 mov.w r1,@r2
    c.r[2] = c.r[3];  // 06038A44 mov r3,r2
    c.r[2] += 2;  // 06038A46 add #2,r2
    c.r[1] = c.r[4];  // 06038A48 mov r4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06038A4A mov.b @r2,r0
    c.r[1] += 2;  // 06038A4C add #2,r1
    c.r[7] &= c.r[0];  // 06038A4E and r0,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038A50 mov.b @r1,r0
    c.r[3] += 58;  // 06038A52 add #58,r3
    c.r[6] &= c.r[0];  // 06038A54 and r0,r6
    c.r[6] |= c.r[7];  // 06038A56 or r7,r6
    st8(c.r[1], c.r[6]);  // 06038A58 mov.b r6,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06038A5A mov.b @r2,r0
    c.r[6] &= c.r[8];  // 06038A5C and r8,r6
    c.r[0] &= 0x1u;  // 06038A5E and #1,r0
    c.r[6] |= c.r[0];  // 06038A60 or r0,r6
    st8(c.r[1], c.r[6]);  // 06038A62 mov.b r6,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06038A64 mov.w @r3,r1
    c.r[4] += 58;  // 06038A66 add #58,r4
    st16(c.r[4], c.r[1]);  // 06038A68 mov.w r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038A6A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06038A6C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06038A6E rts ; mov r5,r0
}

void f_06038A7C(SH2Context& c) {
    ran[820] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038A7C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038A7E mov r15,r14
    c.r[1] = ld32(0x06038AB8u);  // 06038A80 mov.l 0x06038AB8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038A82 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06038A84 mov r1,r0
    c.r[0] >>= 2;  // 06038A86 shlr2 r0
    c.r[0] >>= 2;  // 06038A88 shlr2 r0
    c.r[0] >>= 2;  // 06038A8A shlr2 r0
    c.r[0] &= 0x1u;  // 06038A8C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038A8E tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06038A9C; } }  // 06038A90 bt/s 0x06038A9C ; mov r5,r3
    c.r[4] += 56;  // 06038A94 add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038AB2u);  // 06038A96 mov.w 0x06038AB2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_06038AA2;  // 06038A98 bra 0x06038AA2 ; mov.b @r3,r1
L_06038A9C:
    c.r[4] += 56;  // 06038A9C add #56,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038A9E mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038AB4u);  // 06038AA0 mov.w 0x06038AB4,r2
L_06038AA2:
    c.r[1] = c.r[1] & 0xFFu;  // 06038AA2 extu.b r1,r1
    c.r[1] |= c.r[2];  // 06038AA4 or r2,r1
    st16(c.r[4], c.r[1]);  // 06038AA6 mov.w r1,@r4
    c.r[3] += 1;  // 06038AA8 add #1,r3
    c.r[15] = c.r[14];  // 06038AAA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038AAC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06038AAE rts ; mov r3,r0
}

void f_06038ABC(SH2Context& c) {
    ran[821] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038ABC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038ABE mov r15,r14
    c.r[1] = ld32(0x06038B1Cu);  // 06038AC0 mov.l 0x06038B1C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038AC2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06038AC4 mov r1,r0
    c.r[0] >>= 2;  // 06038AC6 shlr2 r0
    c.r[0] >>= 2;  // 06038AC8 shlr2 r0
    c.r[0] >>= 2;  // 06038ACA shlr2 r0
    c.r[0] &= 0x1u;  // 06038ACC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038ACE tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06038AEC; } }  // 06038AD0 bt/s 0x06038AEC ; mov r5,r3
    c.r[1] = ld32(0x06038B20u);  // 06038AD4 mov.l 0x06038B20,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06038AD6 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06038AD8 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06038ADA tst r1,r1
    { const bool k = c.t; c.r[4] += 56; if (k) { goto L_06038AE6; } }  // 06038ADC bt/s 0x06038AE6 ; add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038B12u);  // 06038AE0 mov.w 0x06038B12,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_06038B02;  // 06038AE2 bra 0x06038B02 ; mov.b @r3,r1
L_06038AE6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038B14u);  // 06038AE6 mov.w 0x06038B14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_06038B02;  // 06038AE8 bra 0x06038B02 ; mov.b @r3,r1
L_06038AEC:
    c.r[1] = ld32(0x06038B24u);  // 06038AEC mov.l 0x06038B24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06038AEE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06038AF0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06038AF2 tst r1,r1
    { const bool k = c.t; c.r[4] += 56; if (k) { goto L_06038AFE; } }  // 06038AF4 bt/s 0x06038AFE ; add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038B16u);  // 06038AF8 mov.w 0x06038B16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_06038B02;  // 06038AFA bra 0x06038B02 ; mov.b @r3,r1
L_06038AFE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038AFE mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038B18u);  // 06038B00 mov.w 0x06038B18,r2
L_06038B02:
    c.r[1] = c.r[1] & 0xFFu;  // 06038B02 extu.b r1,r1
    c.r[1] |= c.r[2];  // 06038B04 or r2,r1
    st16(c.r[4], c.r[1]);  // 06038B06 mov.w r1,@r4
    c.r[3] += 1;  // 06038B08 add #1,r3
    c.r[15] = c.r[14];  // 06038B0A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038B0C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06038B0E rts ; mov r3,r0
}

void f_06038B28(SH2Context& c) {
    ran[822] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038B28 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038B2A mov r15,r14
    c.r[3] = c.r[4];  // 06038B2C mov r4,r3
    c.r[3] += 1;  // 06038B2E add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038B30 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06038B32 mov r1,r0
    c.r[0] >>= 2;  // 06038B34 shlr2 r0
    c.r[0] &= 0x1u;  // 06038B36 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038B38 tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_06038B98; } }  // 06038B3A bt/s 0x06038B98 ; mov r5,r7
    c.r[0] = c.r[1];  // 06038B3E mov r1,r0
    c.r[0] &= 0xFBu;  // 06038B40 and #251,r0
    st8(c.r[3], c.r[0]);  // 06038B42 mov.b r0,@r3
    c.r[1] = c.r[4];  // 06038B44 mov r4,r1
    c.r[1] += 2;  // 06038B46 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038B48 mov.b @r1,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06038BA0u);  // 06038B4A mov.w 0x06038BA0,r6
    c.r[0] = c.r[2];  // 06038B4C mov r2,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038B4E shlr r0
    c.r[0] &= 0x1u;  // 06038B50 and #1,r0
    c.r[0] ^= 0x1u;  // 06038B52 xor #1,r0
    c.r[0] += c.r[0];  // 06038B54 add r0,r0
    c.r[2] &= c.r[6];  // 06038B56 and r6,r2
    c.r[2] |= c.r[0];  // 06038B58 or r0,r2
    st8(c.r[1], c.r[2]);  // 06038B5A mov.b r2,@r1
    c.r[2] = c.r[4];  // 06038B5C mov r4,r2
    c.r[2] += 16;  // 06038B5E add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06038B60 mov.w @r2,r1
    c.r[1] = 0u - c.r[1];  // 06038B62 neg r1,r1
    st16(c.r[2], c.r[1]);  // 06038B64 mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038B66 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038B68 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038B6A mov r1,r0
    c.r[0] >>= 2;  // 06038B6C shlr2 r0
    c.r[0] >>= 2;  // 06038B6E shlr2 r0
    c.r[0] &= 0x1u;  // 06038B70 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038B72 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06038B80; } }  // 06038B74 bt/s 0x06038B80 ; mov r1,r0
    c.r[1] = ld32(c.r[4] + 4);  // 06038B78 mov.l @(4,r4),r1
    c.r[1] = 0u - c.r[1];  // 06038B7A neg r1,r1
    st32(c.r[4] + 4, c.r[1]); goto L_06038B98;  // 06038B7C bra 0x06038B98 ; mov.l r1,@(4,r4)
L_06038B80:
    c.r[0] >>= 2;  // 06038B80 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038B82 shlr r0
    c.r[0] &= 0x1u;  // 06038B84 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038B86 tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 4); if (k) { goto L_06038B92; } }  // 06038B88 bt/s 0x06038B92 ; mov.l @(4,r4),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038BA2u);  // 06038B8C mov.w 0x06038BA2,r2
    c.r[2] -= c.r[1]; goto L_06038B96;  // 06038B8E bra 0x06038B96 ; sub r1,r2
L_06038B92:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038BA4u);  // 06038B92 mov.w 0x06038BA4,r2
    c.r[2] -= c.r[1];  // 06038B94 sub r1,r2
L_06038B96:
    st32(c.r[4] + 4, c.r[2]);  // 06038B96 mov.l r2,@(4,r4)
L_06038B98:
    c.r[15] = c.r[14];  // 06038B98 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038B9A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06038B9C rts ; mov r7,r0
}

void f_06038BA8(SH2Context& c) {
    ran[823] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038BA8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038BAA mov r15,r14
    c.r[1] = ld32(0x06038BE4u);  // 06038BAC mov.l 0x06038BE4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038BAE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06038BB0 mov r1,r0
    c.r[0] >>= 2;  // 06038BB2 shlr2 r0
    c.r[0] >>= 2;  // 06038BB4 shlr2 r0
    c.r[0] >>= 2;  // 06038BB6 shlr2 r0
    c.r[0] &= 0x1u;  // 06038BB8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038BBA tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06038BC8; } }  // 06038BBC bt/s 0x06038BC8 ; mov r5,r3
    c.r[4] += 56;  // 06038BC0 add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038BDEu);  // 06038BC2 mov.w 0x06038BDE,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); goto L_06038BCE;  // 06038BC4 bra 0x06038BCE ; mov.b @r3,r1
L_06038BC8:
    c.r[4] += 56;  // 06038BC8 add #56,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038BCA mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06038BE0u);  // 06038BCC mov.w 0x06038BE0,r2
L_06038BCE:
    c.r[1] = c.r[1] & 0xFFu;  // 06038BCE extu.b r1,r1
    c.r[1] |= c.r[2];  // 06038BD0 or r2,r1
    st16(c.r[4], c.r[1]);  // 06038BD2 mov.w r1,@r4
    c.r[3] += 1;  // 06038BD4 add #1,r3
    c.r[15] = c.r[14];  // 06038BD6 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038BD8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06038BDA rts ; mov r3,r0
}

void f_06038BE8(SH2Context& c) {
    ran[824] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038BE8 mov.l r14,@-r15
    c.r[6] = c.r[4];  // 06038BEA mov r4,r6
    c.r[6] += 1;  // 06038BEC add #1,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06038BEE mov.b @r6,r7
    c.r[0] = c.r[7];  // 06038BF0 mov r7,r0
    c.r[0] >>= 2;  // 06038BF2 shlr2 r0
    c.r[0] >>= 2;  // 06038BF4 shlr2 r0
    c.r[0] &= 0x1u;  // 06038BF6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038BF8 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06038C38; } }  // 06038BFA bt/s 0x06038C38 ; mov r15,r14
    c.r[1] = c.r[4];  // 06038BFE mov r4,r1
    c.r[1] += 65;  // 06038C00 add #65,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038C02 mov.b @r1,r1
    c.r[2] = 0x4Cu;  // 06038C04 mov #76,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038C06 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06038C08 mul.l r2,r1
    c.r[3] = ld32(0x06038C40u);  // 06038C0A mov.l 0x06038C40,r3
    c.r[3] = ld32(c.r[3]);  // 06038C0C mov.l @r3,r3
    c.r[1] = c.macl;  // 06038C0E sts macl,r1
    c.r[3] += c.r[1];  // 06038C10 add r1,r3
    c.r[1] = c.r[3];  // 06038C12 mov r3,r1
    c.r[1] += 1;  // 06038C14 add #1,r1
    c.r[2] = c.r[4];  // 06038C16 mov r4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038C18 mov.b @r1,r0
    c.r[2] += 62;  // 06038C1A add #62,r2
    c.r[1] = 0x40u;  // 06038C1C mov #64,r1
    c.r[1] &= c.r[0];  // 06038C1E and r0,r1
    c.r[0] = c.r[7];  // 06038C20 mov r7,r0
    c.r[0] &= 0xBFu;  // 06038C22 and #191,r0
    c.r[0] |= c.r[1];  // 06038C24 or r1,r0
    st8(c.r[6], c.r[0]);  // 06038C26 mov.b r0,@r6
    c.r[1] = c.r[3];  // 06038C28 mov r3,r1
    c.r[1] += 62;  // 06038C2A add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038C2C mov.b @r1,r1
    c.r[3] += 63;  // 06038C2E add #63,r3
    st8(c.r[2], c.r[1]);  // 06038C30 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038C32 mov.b @r3,r1
    c.r[4] += 63;  // 06038C34 add #63,r4
    st8(c.r[4], c.r[1]);  // 06038C36 mov.b r1,@r4
L_06038C38:
    c.r[15] = c.r[14];  // 06038C38 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038C3A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06038C3C rts ; mov r5,r0
}

void f_06038C44(SH2Context& c) {
    ran[825] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038C44 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038C46 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038C48 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06038C4A rts ; mov r5,r0
}

void f_06038C50(SH2Context& c) {
    ran[826] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038C50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06038C52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06038C54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06038C56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06038C58 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06038C5A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038C5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06038C5E sts.l pr,@-r15
    c.r[15] -= 4;  // 06038C60 add #-4,r15
    c.r[14] = c.r[15];  // 06038C62 mov r15,r14
    c.r[9] = c.r[4];  // 06038C64 mov r4,r9
    c.r[1] = ld32(0x06038D40u);  // 06038C66 mov.l 0x06038D40,r1
    c.r[3] = ld32(c.r[1]);  // 06038C68 mov.l @r1,r3
    c.r[10] = c.r[5];  // 06038C6A mov r5,r10
    c.r[1] = ld32(c.r[9] + 4);  // 06038C6C mov.l @(4,r9),r1
    c.r[0] = c.r[3];  // 06038C6E mov r3,r0
    c.r[0] -= c.r[1];  // 06038C70 sub r1,r0
    st32(c.r[14], c.r[0]);  // 06038C72 mov.l r0,@r14
    c.t = (int32_t)c.r[0] >= 0;  // 06038C74 cmp/pz r0
    { const bool k = c.t; c.r[12] = ld32(c.r[14]); if (k) { goto L_06038C7E; } }  // 06038C76 bt/s 0x06038C7E ; mov.l @r14,r12
    c.r[0] = 0u - c.r[0];  // 06038C7A neg r0,r0
    st32(c.r[14], c.r[0]);  // 06038C7C mov.l r0,@r14
L_06038C7E:
    c.r[1] = ld32(0x06038D44u);  // 06038C7E mov.l 0x06038D44,r1
    c.r[2] = ld32(c.r[1]);  // 06038C80 mov.l @r1,r2
    c.r[1] = ld32(c.r[9] + 8);  // 06038C82 mov.l @(8,r9),r1
    c.r[8] = c.r[2];  // 06038C84 mov r2,r8
    c.r[8] -= c.r[1];  // 06038C86 sub r1,r8
    c.t = (int32_t)c.r[8] >= 0;  // 06038C88 cmp/pz r8
    { const bool k = c.t; c.r[13] = c.r[8]; if (k) { goto L_06038C90; } }  // 06038C8A bt/s 0x06038C90 ; mov r8,r13
    c.r[8] = 0u - c.r[8];  // 06038C8E neg r8,r8
L_06038C90:
    c.r[0] = ld32(c.r[14]);  // 06038C90 mov.l @r14,r0
    c.r[6] = c.r[8];  // 06038C92 mov r8,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[0];  // 06038C94 cmp/ge r0,r6
    if (c.t) { goto L_06038C9A; }  // 06038C96 bt 0x06038C9A
    c.r[6] = ld32(c.r[14]);  // 06038C98 mov.l @r14,r6
L_06038C9A:
    c.t = (c.r[6] & c.r[6]) == 0;  // 06038C9A tst r6,r6
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_06038D12; } }  // 06038C9C bt/s 0x06038D12 ; mov r10,r0
    c.r[1] = ld32(0x06038D48u);  // 06038CA0 mov.l 0x06038D48,r1
    c.r[7] = ld32(c.r[1]);  // 06038CA2 mov.l @r1,r7
    c.r[4] = c.r[6];  // 06038CA4 mov r6,r4
    c.r[11] = ld32(0x06038D4Cu);  // 06038CA6 mov.l 0x06038D4C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06038CACu; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038CACu) return; }  // 06038CA8 jsr @r11 ; mov r7,r5
    c.r[5] = c.r[0];  // 06038CAC mov r0,r5
    c.macl = c.r[5] * c.r[7];  // 06038CAE mul.l r7,r5
    c.r[0] = c.r[6];  // 06038CB0 mov r6,r0
    c.r[1] = c.macl;  // 06038CB2 sts macl,r1
    c.r[0] -= c.r[1];  // 06038CB4 sub r1,r0
    c.r[1] = c.r[0];  // 06038CB6 mov r0,r1
    c.r[1] += c.r[1];  // 06038CB8 add r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[7];  // 06038CBA cmp/ge r7,r1
    if (!c.t) { goto L_06038CC4; }  // 06038CBC bf 0x06038CC4
    c.r[6] = c.r[5];  // 06038CBE mov r5,r6
    c.r[6] += 1; goto L_06038CD2;  // 06038CC0 bra 0x06038CD2 ; add #1,r6
L_06038CC4:
    c.r[4] = c.r[6];  // 06038CC4 mov r6,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06038CCAu; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038CCAu) return; }  // 06038CC6 jsr @r11 ; mov r7,r5
    c.r[6] = c.r[0];  // 06038CCA mov r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06038CCC tst r6,r6
    if (!c.t) { goto L_06038CD2; }  // 06038CCE bf 0x06038CD2
    c.r[6] = 0x1u;  // 06038CD0 mov #1,r6
L_06038CD2:
    c.t = (int32_t)c.r[12] >= 0;  // 06038CD2 cmp/pz r12
    { const bool k = c.t; c.r[11] = ld32(c.r[9] + 4); if (k) { goto L_06038CE4; } }  // 06038CD4 bt/s 0x06038CE4 ; mov.l @(4,r9),r11
    c.r[4] = ld32(c.r[14]);  // 06038CD8 mov.l @r14,r4
    c.r[7] = ld32(0x06038D4Cu);  // 06038CDA mov.l 0x06038D4C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06038CE0u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038CE0u) return; }  // 06038CDC jsr @r7 ; mov r6,r5
    c.r[11] -= c.r[0]; goto L_06038CEE;  // 06038CE0 bra 0x06038CEE ; sub r0,r11
L_06038CE4:
    c.r[4] = ld32(c.r[14]);  // 06038CE4 mov.l @r14,r4
    c.r[7] = ld32(0x06038D4Cu);  // 06038CE6 mov.l 0x06038D4C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06038CECu; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038CECu) return; }  // 06038CE8 jsr @r7 ; mov r6,r5
    c.r[11] += c.r[0];  // 06038CEC add r0,r11
L_06038CEE:
    st32(c.r[9] + 4, c.r[11]);  // 06038CEE mov.l r11,@(4,r9)
    c.t = (int32_t)c.r[13] >= 0;  // 06038CF0 cmp/pz r13
    { const bool k = c.t; c.r[11] = ld32(c.r[9] + 8); if (k) { goto L_06038D02; } }  // 06038CF2 bt/s 0x06038D02 ; mov.l @(8,r9),r11
    c.r[4] = c.r[8];  // 06038CF6 mov r8,r4
    c.r[7] = ld32(0x06038D4Cu);  // 06038CF8 mov.l 0x06038D4C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06038CFEu; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038CFEu) return; }  // 06038CFA jsr @r7 ; mov r6,r5
    c.r[11] -= c.r[0]; goto L_06038D0C;  // 06038CFE bra 0x06038D0C ; sub r0,r11
L_06038D02:
    c.r[4] = c.r[8];  // 06038D02 mov r8,r4
    c.r[7] = ld32(0x06038D4Cu);  // 06038D04 mov.l 0x06038D4C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06038D0Au; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06038D0Au) return; }  // 06038D06 jsr @r7 ; mov r6,r5
    c.r[11] += c.r[0];  // 06038D0A add r0,r11
L_06038D0C:
    st32(c.r[9] + 8, c.r[11]);  // 06038D0C mov.l r11,@(8,r9)
    c.r[10] += 2; goto L_06038D26;  // 06038D0E bra 0x06038D26 ; add #2,r10
L_06038D12:
    st32(c.r[9] + 4, c.r[3]);  // 06038D12 mov.l r3,@(4,r9)
    st32(c.r[9] + 8, c.r[2]);  // 06038D14 mov.l r2,@(8,r9)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038D16 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06038D18 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038D1A mov.b @r0,r1
    c.r[2] <<= 8;  // 06038D1C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038D1E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038D20 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038D22 exts.w r2,r2
    c.r[10] += c.r[2];  // 06038D24 add r2,r10
L_06038D26:
    c.r[14] += 4;  // 06038D26 add #4,r14
    c.r[15] = c.r[14];  // 06038D28 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06038D2A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038D2C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06038D2E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06038D30 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06038D32 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 06038D34 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06038D36 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06038D38 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06038D3A rts ; mov.l @r15+,r8
}

void f_06038D50(SH2Context& c) {
    ran[827] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038D50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038D52 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038D54 mov r15,r14
    c.r[1] = ld32(0x06038E50u);  // 06038D56 mov.l 0x06038E50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038D58 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06038D5A mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06038D5C extu.b r1,r1
    c.r[2] = c.r[1];  // 06038D5E mov r1,r2
    c.r[2] >>= 2;  // 06038D60 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06038D62 shlr r2
    c.r[2] >>= 2;  // 06038D64 shlr2 r2
    c.r[1] >>= 2;  // 06038D66 shlr2 r1
    c.r[1] >>= 2;  // 06038D68 shlr2 r1
    c.r[1] >>= 2;  // 06038D6A shlr2 r1
    c.r[2] &= c.r[0];  // 06038D6C and r0,r2
    c.r[1] &= c.r[0];  // 06038D6E and r0,r1
    c.t = c.r[2] == c.r[1];  // 06038D70 cmp/eq r1,r2
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_06038D7C; } }  // 06038D72 bt/s 0x06038D7C ; mov r5,r8
    c.r[1] = ld32(0x06038E54u);  // 06038D76 mov.l 0x06038E54,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06038D80;  // 06038D78 bra 0x06038D80 ; mov.b @r1,r1
L_06038D7C:
    c.r[1] = ld32(0x06038E58u);  // 06038D7C mov.l 0x06038E58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038D7E mov.b @r1,r1
L_06038D80:
    c.r[7] = c.r[1] & 0xFFu;  // 06038D80 extu.b r1,r7
    c.r[1] = c.r[4];  // 06038D82 mov r4,r1
    c.r[1] += 65;  // 06038D84 add #65,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038D86 mov.b @r1,r1
    c.r[2] = 0x4Cu;  // 06038D88 mov #76,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038D8A extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06038D8C mul.l r2,r1
    c.r[3] = ld32(0x06038E5Cu);  // 06038D8E mov.l 0x06038E5C,r3
    c.r[3] = ld32(c.r[3]);  // 06038D90 mov.l @r3,r3
    c.r[1] = c.macl;  // 06038D92 sts macl,r1
    c.r[3] += c.r[1];  // 06038D94 add r1,r3
    c.r[1] = ld32(0x06038E60u);  // 06038D96 mov.l 0x06038E60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038D98 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06038D9A extu.b r1,r6
    c.r[1] = ld32(0x06038E64u);  // 06038D9C mov.l 0x06038E64,r1
    c.r[1] = ld32(c.r[1]);  // 06038D9E mov.l @r1,r1
    c.r[7] += c.r[7];  // 06038DA0 add r7,r7
    c.r[7] += c.r[1];  // 06038DA2 add r1,r7
    c.r[7] += 1;  // 06038DA4 add #1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06038DA6 mov.b @r7,r0
    c.r[0] &= 0x80u;  // 06038DA8 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038DAA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_06038E3A; } }  // 06038DAC bt/s 0x06038E3A ; mov r4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038DB0 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06038DB2 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06038DB4 cmp/eq #1,r0
    if (!c.t) { goto L_06038DBA; }  // 06038DB6 bf 0x06038DBA
    c.r[6] >>= 2;  // 06038DB8 shlr2 r6
L_06038DBA:
    c.r[1] = 0x3u;  // 06038DBA mov #3,r1
    c.r[1] &= c.r[6];  // 06038DBC and r6,r1
    c.r[0] = c.r[1];  // 06038DBE mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06038DC0 cmp/eq #2,r0
    { const bool k = c.t; c.t = c.r[0] == 0x1u; if (k) { goto L_06038E38; } }  // 06038DC2 bt/s 0x06038E38 ; cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_06038DDC; } }  // 06038DC6 bf/s 0x06038DDC ; mov r4,r1
    c.r[1] += 1;  // 06038DCA add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038DCC mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06038DCE and #239,r0
    st8(c.r[1], c.r[0]);  // 06038DD0 mov.b r0,@r1
    c.r[1] = ld32(c.r[3] + 4);  // 06038DD2 mov.l @(4,r3),r1
    st32(c.r[4] + 4, c.r[1]);  // 06038DD4 mov.l r1,@(4,r4)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038E4Cu);  // 06038DD6 mov.w 0x06038E4C,r1
    st32(c.r[4] + 8, c.r[1]); goto L_06038DEA;  // 06038DD8 bra 0x06038DEA ; mov.l r1,@(8,r4)
L_06038DDC:
    c.r[1] += 1;  // 06038DDC add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038DDE mov.b @r1,r0
    c.r[0] |= 0x10u;  // 06038DE0 or #16,r0
    st8(c.r[1], c.r[0]);  // 06038DE2 mov.b r0,@r1
    c.r[1] = 0x0u;  // 06038DE4 mov #0,r1
    st32(c.r[4] + 4, c.r[1]);  // 06038DE6 mov.l r1,@(4,r4)
    st32(c.r[4] + 8, c.r[1]);  // 06038DE8 mov.l r1,@(8,r4)
L_06038DEA:
    c.r[5] = c.r[3];  // 06038DEA mov r3,r5
    c.r[5] += 1;  // 06038DEC add #1,r5
    c.r[7] = c.r[4];  // 06038DEE mov r4,r7
    c.r[7] += 1;  // 06038DF0 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06038DF2 mov.b @r5,r1
    c.r[0] = 0x4u;  // 06038DF4 mov #4,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06038DF6 mov.b @r7,r2
    c.r[1] &= c.r[0];  // 06038DF8 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06038E4Eu);  // 06038DFA mov.w 0x06038E4E,r0
    c.r[2] &= c.r[0];  // 06038DFC and r0,r2
    c.r[2] |= c.r[1];  // 06038DFE or r1,r2
    st8(c.r[7], c.r[2]);  // 06038E00 mov.b r2,@r7
    c.r[2] = c.r[4];  // 06038E02 mov r4,r2
    c.r[2] += 62;  // 06038E04 add #62,r2
    c.r[1] = c.r[3];  // 06038E06 mov r3,r1
    c.r[1] += 62;  // 06038E08 add #62,r1
    c.r[4] += 63;  // 06038E0A add #63,r4
    c.r[3] += 63;  // 06038E0C add #63,r3
    c.r[0] = 0x3u;  // 06038E0E mov #3,r0
    c.r[6] &= c.r[0];  // 06038E10 and r0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038E12 mov.b @r1,r1
    c.r[0] = c.r[6];  // 06038E14 mov r6,r0
    st8(c.r[2], c.r[1]);  // 06038E16 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06038E18 mov.b @r3,r1
    c.t = c.r[0] == 0x3u;  // 06038E1A cmp/eq #3,r0
    { const bool k = !c.t; st8(c.r[4], c.r[1]); if (k) { goto L_06038E28; } }  // 06038E1C bf/s 0x06038E28 ; mov.b r1,@r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06038E20 mov.b @r7,r0
    c.r[0] |= 0x40u;  // 06038E22 or #64,r0
    st8(c.r[7], c.r[0]); goto L_06038E42;  // 06038E24 bra 0x06038E42 ; mov.b r0,@r7
L_06038E28:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06038E28 mov.b @r5,r0
    c.r[1] = 0x40u;  // 06038E2A mov #64,r1
    c.r[1] &= c.r[0];  // 06038E2C and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06038E2E mov.b @r7,r0
    c.r[0] &= 0xBFu;  // 06038E30 and #191,r0
    c.r[0] |= c.r[1];  // 06038E32 or r1,r0
    st8(c.r[7], c.r[0]); goto L_06038E42;  // 06038E34 bra 0x06038E42 ; mov.b r0,@r7
L_06038E38:
    c.r[1] = c.r[4];  // 06038E38 mov r4,r1
L_06038E3A:
    c.r[1] += 1;  // 06038E3A add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038E3C mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06038E3E and #191,r0
    st8(c.r[1], c.r[0]);  // 06038E40 mov.b r0,@r1
L_06038E42:
    c.r[15] = c.r[14];  // 06038E42 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038E44 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 06038E46 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06038E48 rts ; mov.l @r15+,r8
}

void f_06038E68(SH2Context& c) {
    ran[828] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038E68 mov.l r14,@-r15
    c.r[3] = c.r[5];  // 06038E6A mov r5,r3
    c.r[1] = c.r[3];  // 06038E6C mov r3,r1
    c.r[1] += 2;  // 06038E6E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038E70 mov.b @r1,r2
    c.r[0] = c.r[3];  // 06038E72 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06038E74 extu.b r2,r2
    c.r[1] = c.r[3];  // 06038E76 mov r3,r1
    c.r[1] += 3;  // 06038E78 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038E7A mov.b @r1,r1
    c.r[2] <<= 8;  // 06038E7C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038E7E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038E80 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038E82 exts.w r2,r2
    st32(c.r[4] + 8, c.r[2]);  // 06038E84 mov.l r2,@(8,r4)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038E86 mov.b @r0+,r2
    c.r[14] = c.r[15];  // 06038E88 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 06038E8A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038E8C mov.b @r0,r1
    c.r[2] <<= 8;  // 06038E8E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038E90 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038E92 or r1,r2
    c.r[1] = ld32(0x06038EF8u);  // 06038E94 mov.l 0x06038EF8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038E96 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038E98 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038E9A mov r1,r0
    c.r[0] >>= 2;  // 06038E9C shlr2 r0
    c.r[0] >>= 2;  // 06038E9E shlr2 r0
    c.r[0] >>= 2;  // 06038EA0 shlr2 r0
    c.r[1] >>= 2;  // 06038EA2 shlr2 r1
    c.r[1] >>= 2;  // 06038EA4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06038EA6 shlr r1
    c.r[1] >>= 2;  // 06038EA8 shlr2 r1
    c.r[0] &= 0x1u;  // 06038EAA and #1,r0
    c.t = c.r[1] == c.r[0];  // 06038EAC cmp/eq r0,r1
    { const bool k = c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2]; if (k) { goto L_06038EE6; } }  // 06038EAE bt/s 0x06038EE6 ; exts.w r2,r2
    c.r[1] = c.r[4];  // 06038EB2 mov r4,r1
    c.r[1] += 1;  // 06038EB4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038EB6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038EB8 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038EBA mov r1,r0
    c.r[0] >>= 2;  // 06038EBC shlr2 r0
    c.r[0] >>= 2;  // 06038EBE shlr2 r0
    c.r[0] &= 0x1u;  // 06038EC0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038EC2 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06038ECE; } }  // 06038EC4 bt/s 0x06038ECE ; mov r1,r0
    c.r[1] = 0u - c.r[2];  // 06038EC8 neg r2,r1
    st32(c.r[4] + 4, c.r[1]); goto L_06038EE8;  // 06038ECA bra 0x06038EE8 ; mov.l r1,@(4,r4)
L_06038ECE:
    c.r[0] >>= 2;  // 06038ECE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038ED0 shlr r0
    c.r[0] &= 0x1u;  // 06038ED2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038ED4 tst r0,r0
    if (c.t) { goto L_06038EDE; }  // 06038ED6 bt 0x06038EDE
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038EF2u);  // 06038ED8 mov.w 0x06038EF2,r1
    c.r[1] -= c.r[2]; goto L_06038EE2;  // 06038EDA bra 0x06038EE2 ; sub r2,r1
L_06038EDE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038EF4u);  // 06038EDE mov.w 0x06038EF4,r1
    c.r[1] -= c.r[2];  // 06038EE0 sub r2,r1
L_06038EE2:
    st32(c.r[4] + 4, c.r[1]); goto L_06038EE8;  // 06038EE2 bra 0x06038EE8 ; mov.l r1,@(4,r4)
L_06038EE6:
    st32(c.r[4] + 4, c.r[2]);  // 06038EE6 mov.l r2,@(4,r4)
L_06038EE8:
    c.r[3] += 4;  // 06038EE8 add #4,r3
    c.r[15] = c.r[14];  // 06038EEA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038EEC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06038EEE rts ; mov r3,r0
}

void f_06038EFC(SH2Context& c) {
    ran[829] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038EFC mov.l r14,@-r15
    c.r[3] = c.r[5];  // 06038EFE mov r5,r3
    c.r[0] = c.r[3];  // 06038F00 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038F02 mov.b @r0+,r2
    c.r[14] = c.r[15];  // 06038F04 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 06038F06 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038F08 mov.b @r0,r1
    c.r[2] <<= 8;  // 06038F0A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038F0C extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038F0E or r1,r2
    c.r[1] = ld32(0x06038F74u);  // 06038F10 mov.l 0x06038F74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038F12 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038F14 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038F16 mov r1,r0
    c.r[0] >>= 2;  // 06038F18 shlr2 r0
    c.r[0] >>= 2;  // 06038F1A shlr2 r0
    c.r[0] >>= 2;  // 06038F1C shlr2 r0
    c.r[1] >>= 2;  // 06038F1E shlr2 r1
    c.r[1] >>= 2;  // 06038F20 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06038F22 shlr r1
    c.r[1] >>= 2;  // 06038F24 shlr2 r1
    c.r[0] &= 0x1u;  // 06038F26 and #1,r0
    c.t = c.r[1] == c.r[0];  // 06038F28 cmp/eq r0,r1
    { const bool k = c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2]; if (k) { goto L_06038F62; } }  // 06038F2A bt/s 0x06038F62 ; exts.w r2,r2
    c.r[1] = c.r[4];  // 06038F2E mov r4,r1
    c.r[1] += 1;  // 06038F30 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038F32 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038F34 extu.b r1,r1
    c.r[0] = c.r[1];  // 06038F36 mov r1,r0
    c.r[0] >>= 2;  // 06038F38 shlr2 r0
    c.r[0] >>= 2;  // 06038F3A shlr2 r0
    c.r[0] &= 0x1u;  // 06038F3C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038F3E tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06038F4A; } }  // 06038F40 bt/s 0x06038F4A ; mov r1,r0
    c.r[1] = 0u - c.r[2];  // 06038F44 neg r2,r1
    st32(c.r[4] + 4, c.r[1]); goto L_06038F64;  // 06038F46 bra 0x06038F64 ; mov.l r1,@(4,r4)
L_06038F4A:
    c.r[0] >>= 2;  // 06038F4A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06038F4C shlr r0
    c.r[0] &= 0x1u;  // 06038F4E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06038F50 tst r0,r0
    if (c.t) { goto L_06038F5A; }  // 06038F52 bt 0x06038F5A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038F6Eu);  // 06038F54 mov.w 0x06038F6E,r1
    c.r[1] -= c.r[2]; goto L_06038F5E;  // 06038F56 bra 0x06038F5E ; sub r2,r1
L_06038F5A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06038F70u);  // 06038F5A mov.w 0x06038F70,r1
    c.r[1] -= c.r[2];  // 06038F5C sub r2,r1
L_06038F5E:
    st32(c.r[4] + 4, c.r[1]); goto L_06038F64;  // 06038F5E bra 0x06038F64 ; mov.l r1,@(4,r4)
L_06038F62:
    st32(c.r[4] + 4, c.r[2]);  // 06038F62 mov.l r2,@(4,r4)
L_06038F64:
    c.r[3] += 2;  // 06038F64 add #2,r3
    c.r[15] = c.r[14];  // 06038F66 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038F68 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06038F6A rts ; mov r3,r0
}

void f_06038F78(SH2Context& c) {
    ran[830] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038F78 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06038F7A mov r15,r14
    c.r[0] = c.r[5];  // 06038F7C mov r5,r0
    c.r[1] = c.r[0];  // 06038F7E mov r0,r1
    c.r[1] += 1;  // 06038F80 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038F82 mov.b @r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038F84 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06038F86 extu.b r2,r2
    c.r[2] <<= 8;  // 06038F88 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038F8A extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038F8C or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038F8E exts.w r2,r2
    st32(c.r[4] + 8, c.r[2]);  // 06038F90 mov.l r2,@(8,r4)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038F92 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 06038F94 rts ; add #2,r0
}

void f_06038F98(SH2Context& c) {
    ran[831] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06038F98 mov.l r14,@-r15
    c.r[3] = c.r[5];  // 06038F9A mov r5,r3
    c.r[1] = c.r[3];  // 06038F9C mov r3,r1
    c.r[1] += 2;  // 06038F9E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038FA0 mov.b @r1,r2
    c.r[0] = c.r[3];  // 06038FA2 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06038FA4 extu.b r2,r2
    c.r[1] = c.r[3];  // 06038FA6 mov r3,r1
    c.r[1] += 3;  // 06038FA8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038FAA mov.b @r1,r1
    c.r[2] <<= 8;  // 06038FAC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038FAE extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038FB0 or r1,r2
    c.r[1] = ld32(c.r[4] + 8);  // 06038FB2 mov.l @(8,r4),r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06038FB4 exts.w r2,r2
    c.r[1] += c.r[2];  // 06038FB6 add r2,r1
    st32(c.r[4] + 8, c.r[1]);  // 06038FB8 mov.l r1,@(8,r4)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06038FBA mov.b @r0+,r2
    c.r[14] = c.r[15];  // 06038FBC mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 06038FBE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06038FC0 mov.b @r0,r1
    c.r[2] <<= 8;  // 06038FC2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06038FC4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06038FC6 or r1,r2
    c.r[1] = ld32(0x06038FF8u);  // 06038FC8 mov.l 0x06038FF8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06038FCA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06038FCC extu.b r1,r1
    c.r[0] = c.r[1];  // 06038FCE mov r1,r0
    c.r[0] >>= 2;  // 06038FD0 shlr2 r0
    c.r[0] >>= 2;  // 06038FD2 shlr2 r0
    c.r[0] >>= 2;  // 06038FD4 shlr2 r0
    c.r[1] >>= 2;  // 06038FD6 shlr2 r1
    c.r[1] >>= 2;  // 06038FD8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06038FDA shlr r1
    c.r[1] >>= 2;  // 06038FDC shlr2 r1
    c.r[0] &= 0x1u;  // 06038FDE and #1,r0
    c.t = c.r[1] == c.r[0];  // 06038FE0 cmp/eq r0,r1
    { const bool k = c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2]; if (k) { goto L_06038FE8; } }  // 06038FE2 bt/s 0x06038FE8 ; exts.w r2,r2
    c.r[2] = 0u - c.r[2];  // 06038FE6 neg r2,r2
L_06038FE8:
    c.r[3] += 4;  // 06038FE8 add #4,r3
    c.r[1] = ld32(c.r[4] + 4);  // 06038FEA mov.l @(4,r4),r1
    c.r[15] = c.r[14];  // 06038FEC mov r14,r15
    c.r[1] += c.r[2];  // 06038FEE add r2,r1
    st32(c.r[4] + 4, c.r[1]);  // 06038FF0 mov.l r1,@(4,r4)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06038FF2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06038FF4 rts ; mov r3,r0
}

void f_06038FFC(SH2Context& c) {
    ran[832] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06038FFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06038FFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039000 mov.l r14,@-r15
    c.r[9] = c.r[5];  // 06039002 mov r5,r9
    c.r[1] = ld32(0x060390F8u);  // 06039004 mov.l 0x060390F8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06039006 mov.b @r9,r0
    c.r[6] = ld32(0x060390FCu);  // 06039008 mov.l 0x060390FC,r6
    c.r[3] = ld32(c.r[1]);  // 0603900A mov.l @r1,r3
    c.r[0] &= 0x1Fu;  // 0603900C and #31,r0
    c.r[0] += c.r[0];  // 0603900E add r0,r0
    c.r[1] = c.r[0];  // 06039010 mov r0,r1
    c.r[1] += c.r[3];  // 06039012 add r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06039014 mov.b @(r0,r3),r2
    c.r[1] += 1;  // 06039016 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039018 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603901A extu.b r2,r2
    c.r[2] <<= 8;  // 0603901C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603901E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039020 or r1,r2
    c.r[0] += c.r[2];  // 06039022 add r2,r0
    c.r[1] = ld32(0x06039100u);  // 06039024 mov.l 0x06039100,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039026 mov.b @r1,r1
    c.r[7] = c.r[0] & 0xFFFFu;  // 06039028 extu.w r0,r7
    c.r[0] = c.r[1];  // 0603902A mov r1,r0
    c.r[0] >>= 2;  // 0603902C shlr2 r0
    c.r[0] >>= 2;  // 0603902E shlr2 r0
    c.r[0] >>= 2;  // 06039030 shlr2 r0
    c.r[0] &= 0x1u;  // 06039032 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039034 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603903C; } }  // 06039036 bt/s 0x0603903C ; mov r15,r14
    c.r[6] = ld32(0x06039104u);  // 0603903A mov.l 0x06039104,r6
L_0603903C:
    c.r[0] = c.r[3];  // 0603903C mov r3,r0
    c.r[8] = ld32(0x06039108u);  // 0603903E mov.l 0x06039108,r8
    c.r[5] = c.r[4];  // 06039040 mov r4,r5
    c.r[5] += 1;  // 06039042 add #1,r5
L_06039044:
    c.r[3] = c.r[7];  // 06039044 mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06039046 mov.b @(r0,r7),r1
    c.r[3] += c.r[0];  // 06039048 add r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603904A extu.b r1,r1
    c.r[2] = c.r[1];  // 0603904C mov r1,r2
    c.r[2] <<= 8;  // 0603904E shll8 r2
    c.r[1] = c.r[3];  // 06039050 mov r3,r1
    c.r[1] += 1;  // 06039052 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039054 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039056 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039058 or r1,r2
    c.t = c.r[2] == c.r[8];  // 0603905A cmp/eq r8,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0603906C; } }  // 0603905C bt/s 0x0603906C ; mov r6,r1
    c.r[1] += 10;  // 06039060 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039062 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039064 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06039066 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_060390E2; } }  // 06039068 bf/s 0x060390E2 ; mov r7,r1
L_0603906C:
    c.r[1] = ld32(0x06039100u);  // 0603906C mov.l 0x06039100,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603906E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039070 extu.b r1,r1
    c.r[0] = c.r[1];  // 06039072 mov r1,r0
    c.r[0] >>= 2;  // 06039074 shlr2 r0
    c.r[0] >>= 2;  // 06039076 shlr2 r0
    c.r[0] >>= 2;  // 06039078 shlr2 r0
    c.r[1] >>= 2;  // 0603907A shlr2 r1
    c.r[1] >>= 2;  // 0603907C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603907E shlr r1
    c.r[1] >>= 2;  // 06039080 shlr2 r1
    c.r[0] &= 0x1u;  // 06039082 and #1,r0
    c.t = c.r[1] == c.r[0];  // 06039084 cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06039098; } }  // 06039086 bt/s 0x06039098 ; mov r3,r1
    c.r[1] += 2;  // 0603908A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603908C mov.b @r1,r1
    c.r[3] += 3;  // 0603908E add #3,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06039090 mov.b @r3,r7
    c.r[1] = 0u - c.r[1];  // 06039092 neg r1,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_060390A0;  // 06039094 bra 0x060390A0 ; exts.w r1,r2
L_06039098:
    c.r[1] += 2;  // 06039098 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603909A mov.b @r1,r2
    c.r[3] += 3;  // 0603909C add #3,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603909E mov.b @r3,r7
L_060390A0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060390A0 mov.b @r5,r1
    c.r[0] = c.r[1];  // 060390A2 mov r1,r0
    c.r[0] >>= 2;  // 060390A4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060390A6 shlr r0
    c.r[0] &= 0x1u;  // 060390A8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060390AA tst r0,r0
    { const bool k = c.t; c.r[3] = ld32(c.r[4] + 4); if (k) { goto L_060390BA; } }  // 060390AC bt/s 0x060390BA ; mov.l @(4,r4),r3
    c.r[1] = c.r[2];  // 060390B0 mov r2,r1
    c.r[1] <<= 2;  // 060390B2 shll2 r1
    c.r[1] += c.r[1];  // 060390B4 add r1,r1
    c.r[1] += c.r[3]; goto L_060390BE;  // 060390B6 bra 0x060390BE ; add r3,r1
L_060390BA:
    c.r[1] = c.r[3];  // 060390BA mov r3,r1
    c.r[1] += c.r[2];  // 060390BC add r2,r1
L_060390BE:
    st32(c.r[4] + 4, c.r[1]);  // 060390BE mov.l r1,@(4,r4)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060390C0 mov.b @r5,r1
    c.r[0] = c.r[1];  // 060390C2 mov r1,r0
    c.r[0] >>= 2;  // 060390C4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060390C6 shlr r0
    c.r[0] &= 0x1u;  // 060390C8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060390CA tst r0,r0
    { const bool k = c.t; c.r[2] = ld32(c.r[4] + 8); if (k) { goto L_060390DA; } }  // 060390CC bt/s 0x060390DA ; mov.l @(8,r4),r2
    c.r[1] = c.r[7];  // 060390D0 mov r7,r1
    c.r[1] <<= 2;  // 060390D2 shll2 r1
    c.r[1] += c.r[1];  // 060390D4 add r1,r1
    c.r[1] += c.r[2]; goto L_060390DE;  // 060390D6 bra 0x060390DE ; add r2,r1
L_060390DA:
    c.r[1] = c.r[2];  // 060390DA mov r2,r1
    c.r[1] += c.r[7];  // 060390DC add r7,r1
L_060390DE:
    st32(c.r[4] + 8, c.r[1]); goto L_060390E8;  // 060390DE bra 0x060390E8 ; mov.l r1,@(8,r4)
L_060390E2:
    c.r[1] += 4;  // 060390E2 add #4,r1
    c.r[7] = c.r[1] & 0xFFFFu; SH2_POLL(c); goto L_06039044;  // 060390E4 bra 0x06039044 ; extu.w r1,r7
L_060390E8:
    c.r[9] += 1;  // 060390E8 add #1,r9
    c.r[15] = c.r[14];  // 060390EA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060390EC mov.l @r15+,r14
    c.r[0] = c.r[9];  // 060390EE mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060390F0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060390F2 rts ; mov.l @r15+,r8
}

void f_0603910C(SH2Context& c) {
    ran[833] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603910C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603910E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06039110 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039112 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039114 mov r15,r14
    c.r[9] = c.r[5];  // 06039116 mov r5,r9
    c.r[1] = ld32(0x06039224u);  // 06039118 mov.l 0x06039224,r1
    c.r[10] = 0x1u;  // 0603911A mov #1,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603911C mov.b @r9,r0
    c.r[6] = ld32(0x06039228u);  // 0603911E mov.l 0x06039228,r6
    c.r[1] = ld32(c.r[1]);  // 06039120 mov.l @r1,r1
    c.r[0] &= 0x1Fu;  // 06039122 and #31,r0
    c.r[0] += c.r[0];  // 06039124 add r0,r0
    c.r[3] = c.r[0];  // 06039126 mov r0,r3
    c.r[3] += c.r[1];  // 06039128 add r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603912A mov.b @(r0,r1),r2
    c.r[3] += 1;  // 0603912C add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603912E extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06039130 mov.b @r3,r1
    c.r[2] <<= 8;  // 06039132 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039134 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039136 or r1,r2
    c.r[0] += c.r[2];  // 06039138 add r2,r0
    c.r[1] = ld32(0x0603922Cu);  // 0603913A mov.l 0x0603922C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603913C mov.b @r1,r1
    c.r[2] = c.r[1];  // 0603913E mov r1,r2
    c.r[2] >>= 2;  // 06039140 shlr2 r2
    c.r[2] >>= 2;  // 06039142 shlr2 r2
    c.r[2] >>= 2;  // 06039144 shlr2 r2
    c.r[2] &= c.r[10];  // 06039146 and r10,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06039148 tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[0] & 0xFFFFu; if (k) { goto L_06039150; } }  // 0603914A bt/s 0x06039150 ; extu.w r0,r0
    c.r[6] = ld32(0x06039230u);  // 0603914E mov.l 0x06039230,r6
L_06039150:
    c.r[1] = c.r[6];  // 06039150 mov r6,r1
    c.r[1] += 6;  // 06039152 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039154 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039156 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039158 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06039164; } }  // 0603915A bf/s 0x06039164 ; tst r2,r2
    c.r[6] = ld32(0x06039234u);  // 0603915E mov.l 0x06039234,r6
    if (c.t) { goto L_06039164; }  // 06039160 bt 0x06039164
    c.r[6] = ld32(0x06039238u);  // 06039162 mov.l 0x06039238,r6
L_06039164:
    c.r[1] = ld32(0x06039224u);  // 06039164 mov.l 0x06039224,r1
    c.r[7] = ld32(c.r[1]);  // 06039166 mov.l @r1,r7
    c.r[8] = ld32(0x0603923Cu);  // 06039168 mov.l 0x0603923C,r8
    c.r[5] = c.r[4];  // 0603916A mov r4,r5
    c.r[5] += 1;  // 0603916C add #1,r5
L_0603916E:
    c.r[3] = c.r[0];  // 0603916E mov r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06039170 mov.b @(r0,r7),r1
    c.r[3] += c.r[7];  // 06039172 add r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06039174 extu.b r1,r1
    c.r[2] = c.r[1];  // 06039176 mov r1,r2
    c.r[2] <<= 8;  // 06039178 shll8 r2
    c.r[1] = c.r[3];  // 0603917A mov r3,r1
    c.r[1] += 1;  // 0603917C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603917E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039180 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039182 or r1,r2
    c.t = c.r[2] == c.r[8];  // 06039184 cmp/eq r8,r2
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06039196; } }  // 06039186 bt/s 0x06039196 ; mov r6,r1
    c.r[1] += 10;  // 0603918A add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603918C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603918E extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06039190 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0603920C; } }  // 06039192 bf/s 0x0603920C ; mov r0,r1
L_06039196:
    c.r[1] = ld32(0x0603922Cu);  // 06039196 mov.l 0x0603922C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039198 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603919A extu.b r1,r1
    c.r[0] = c.r[1];  // 0603919C mov r1,r0
    c.r[0] >>= 2;  // 0603919E shlr2 r0
    c.r[0] >>= 2;  // 060391A0 shlr2 r0
    c.r[0] >>= 2;  // 060391A2 shlr2 r0
    c.r[1] >>= 2;  // 060391A4 shlr2 r1
    c.r[1] >>= 2;  // 060391A6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060391A8 shlr r1
    c.r[1] >>= 2;  // 060391AA shlr2 r1
    c.r[0] &= 0x1u;  // 060391AC and #1,r0
    c.t = c.r[1] == c.r[0];  // 060391AE cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060391C2; } }  // 060391B0 bt/s 0x060391C2 ; mov r3,r1
    c.r[1] += 2;  // 060391B4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060391B6 mov.b @r1,r1
    c.r[3] += 3;  // 060391B8 add #3,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060391BA mov.b @r3,r7
    c.r[1] = 0u - c.r[1];  // 060391BC neg r1,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_060391CA;  // 060391BE bra 0x060391CA ; exts.w r1,r2
L_060391C2:
    c.r[1] += 2;  // 060391C2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060391C4 mov.b @r1,r2
    c.r[3] += 3;  // 060391C6 add #3,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060391C8 mov.b @r3,r7
L_060391CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060391CA mov.b @r5,r1
    c.r[0] = c.r[1];  // 060391CC mov r1,r0
    c.r[0] >>= 2;  // 060391CE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060391D0 shlr r0
    c.r[0] &= 0x1u;  // 060391D2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060391D4 tst r0,r0
    { const bool k = c.t; c.r[3] = ld32(c.r[4] + 4); if (k) { goto L_060391E4; } }  // 060391D6 bt/s 0x060391E4 ; mov.l @(4,r4),r3
    c.r[1] = c.r[2];  // 060391DA mov r2,r1
    c.r[1] <<= 2;  // 060391DC shll2 r1
    c.r[1] += c.r[1];  // 060391DE add r1,r1
    c.r[1] += c.r[3]; goto L_060391E8;  // 060391E0 bra 0x060391E8 ; add r3,r1
L_060391E4:
    c.r[1] = c.r[3];  // 060391E4 mov r3,r1
    c.r[1] += c.r[2];  // 060391E6 add r2,r1
L_060391E8:
    st32(c.r[4] + 4, c.r[1]);  // 060391E8 mov.l r1,@(4,r4)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060391EA mov.b @r5,r1
    c.r[0] = c.r[1];  // 060391EC mov r1,r0
    c.r[0] >>= 2;  // 060391EE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060391F0 shlr r0
    c.r[0] &= 0x1u;  // 060391F2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060391F4 tst r0,r0
    { const bool k = c.t; c.r[2] = ld32(c.r[4] + 8); if (k) { goto L_06039204; } }  // 060391F6 bt/s 0x06039204 ; mov.l @(8,r4),r2
    c.r[1] = c.r[7];  // 060391FA mov r7,r1
    c.r[1] <<= 2;  // 060391FC shll2 r1
    c.r[1] += c.r[1];  // 060391FE add r1,r1
    c.r[1] += c.r[2]; goto L_06039208;  // 06039200 bra 0x06039208 ; add r2,r1
L_06039204:
    c.r[1] = c.r[2];  // 06039204 mov r2,r1
    c.r[1] += c.r[7];  // 06039206 add r7,r1
L_06039208:
    st32(c.r[4] + 8, c.r[1]); goto L_06039212;  // 06039208 bra 0x06039212 ; mov.l r1,@(8,r4)
L_0603920C:
    c.r[1] += 4;  // 0603920C add #4,r1
    c.r[0] = c.r[1] & 0xFFFFu; SH2_POLL(c); goto L_0603916E;  // 0603920E bra 0x0603916E ; extu.w r1,r0
L_06039212:
    c.r[15] = c.r[14];  // 06039212 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039214 mov.l @r15+,r14
    c.r[9] += 1;  // 06039216 add #1,r9
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06039218 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0603921A mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603921C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603921E rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
