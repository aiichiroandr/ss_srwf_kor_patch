#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0607769C(SH2Context& c) {
    ran[1654] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607769C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607769E sts.l pr,@-r15
    c.r[1] = ld32(0x060776BCu);  // 060776A0 mov.l 0x060776BC,r1
    c.r[1] = ld32(c.r[1]);  // 060776A2 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060776A4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060776A6 extu.b r1,r0
    c.r[0] <<= 2;  // 060776A8 shll2 r0
    c.r[1] = ld32(0x060776C0u);  // 060776AA mov.l 0x060776C0,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060776AC mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060776B2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060776B2u) return; }  // 060776AE jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060776B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060776B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060776B6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060776B8 rts ; extu.w r0,r0
}

void f_060776C4(SH2Context& c) {
    ran[1655] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060776C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060776C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060776C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060776CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060776CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060776CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060776D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060776D2 sts.l pr,@-r15
    c.r[1] = ld32(0x06077904u);  // 060776D4 mov.l 0x06077904,r1
    c.r[1] = ld32(c.r[1]);  // 060776D6 mov.l @r1,r1
    c.r[1] += 1;  // 060776D8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060776DA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060776DC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060776DE tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060776EE; } }  // 060776E0 bt/s 0x060776EE ; mov r15,r14
    c.r[1] = ld32(0x06077908u);  // 060776E4 mov.l 0x06077908,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060776E6 mov.b @r1,r1
    c.r[1] += 1;  // 060776E8 add #1,r1
    c.r[2] = c.r[1] & 0xFFu; goto L_06077700;  // 060776EA bra 0x06077700 ; extu.b r1,r2
L_060776EE:
    c.r[0] = ld32(0x0607790Cu);  // 060776EE mov.l 0x0607790C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060776F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060776F4u) return; }  // 060776F0 jsr @r0 ; nop
    c.r[0] >>= 8;  // 060776F4 shlr8 r0
    c.r[0] >>= 2;  // 060776F6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060776F8 shlr r0
    c.r[0] >>= 2;  // 060776FA shlr2 r0
    c.r[0] += 1;  // 060776FC add #1,r0
    c.r[2] = c.r[0] & 0xFFu;  // 060776FE extu.b r0,r2
L_06077700:
    c.r[1] = 0x7u;  // 06077700 mov #7,r1
    c.r[2] -= 1;  // 06077702 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06077704 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0607770E; } }  // 06077706 bf/s 0x0607770E ; mov r2,r1
    goto L_06077A7A;  // 0607770A bra 0x06077A7A ; nop
L_0607770E:
    c.r[1] += c.r[1];  // 0607770E add r1,r1
    c.r[0] = 0x0607771Cu;  // 06077710 mova 0x0607771C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06077712 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06077714 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607772Cu: goto L_0607772C; case 0x06077786u: goto L_06077786; case 0x060777E6u: goto L_060777E6; case 0x06077846u: goto L_06077846; case 0x0607788Au: goto L_0607788A; case 0x06077924u: goto L_06077924; case 0x06077980u: goto L_06077980; case 0x060779FCu: goto L_060779FC; default: sh2_call(c, x); return; } }  // 06077716 jmp @r0 ; nop
L_0607772C:
    c.r[8] = ld32(0x06077910u);  // 0607772C mov.l 0x06077910,r8
    c.r[1] = ld32(c.r[8]);  // 0607772E mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060778E8u);  // 06077730 mov.w 0x060778E8,r3
    c.r[0] = c.r[1];  // 06077732 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077734 mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778EAu);  // 06077736 mov.w 0x060778EA,r0
    c.r[2] &= c.r[0];  // 06077738 and r0,r2
    c.r[0] = c.r[1];  // 0607773A mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 0607773C mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 0607773E mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060778ECu);  // 06077740 mov.w 0x060778EC,r7
    c.r[0] = c.r[2];  // 06077742 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06077744 mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 06077746 mov #127,r6
    c.r[6] &= c.r[1];  // 06077748 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060778EEu);  // 0607774A mov.w 0x060778EE,r1
    c.r[6] |= c.r[1];  // 0607774C or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 0607774E mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077750 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F0u);  // 06077752 mov.w 0x060778F0,r0
    c.r[1] &= c.r[0];  // 06077754 and r0,r1
    c.r[0] = 0x1Cu;  // 06077756 mov #28,r0
    c.r[1] |= c.r[0];  // 06077758 or r0,r1
    c.r[0] = c.r[2];  // 0607775A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0607775C mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 0607775E mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x060778F2u);  // 06077760 mov.w 0x060778F2,r9
    c.r[0] = c.r[3];  // 06077762 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06077764 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06077914u);  // 06077766 mov.l 0x06077914,r2
    c.r[1] &= c.r[2];  // 06077768 and r2,r1
    c.r[2] = ld32(0x06077918u);  // 0607776A mov.l 0x06077918,r2
    c.r[2] |= c.r[1];  // 0607776C or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 0607776E mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06077770 mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F4u);  // 06077772 mov.w 0x060778F4,r0
    c.r[1] &= c.r[0];  // 06077774 and r0,r1
    c.r[0] = c.r[3];  // 06077776 mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06077778 mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 0607777A mov.l @r8,r1
    c.r[0] = c.r[1];  // 0607777C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607777E mov.b @(r0,r9),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F6u);  // 06077780 mov.w 0x060778F6,r0
    c.r[2] &= c.r[0]; goto L_06077A54;  // 06077782 bra 0x06077A54 ; and r0,r2
L_06077786:
    c.r[8] = ld32(0x06077910u);  // 06077786 mov.l 0x06077910,r8
    c.r[1] = ld32(c.r[8]);  // 06077788 mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060778E8u);  // 0607778A mov.w 0x060778E8,r3
    c.r[0] = c.r[1];  // 0607778C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607778E mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778EAu);  // 06077790 mov.w 0x060778EA,r0
    c.r[2] &= c.r[0];  // 06077792 and r0,r2
    c.r[0] = c.r[1];  // 06077794 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06077796 mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 06077798 mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060778ECu);  // 0607779A mov.w 0x060778EC,r7
    c.r[0] = c.r[2];  // 0607779C mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0607779E mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 060777A0 mov #127,r6
    c.r[6] &= c.r[1];  // 060777A2 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060778F8u);  // 060777A4 mov.w 0x060778F8,r1
    c.r[6] |= c.r[1];  // 060777A6 or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 060777A8 mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060777AA mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F0u);  // 060777AC mov.w 0x060778F0,r0
    c.r[1] &= c.r[0];  // 060777AE and r0,r1
    c.r[0] = 0x2Cu;  // 060777B0 mov #44,r0
    c.r[1] |= c.r[0];  // 060777B2 or r0,r1
    c.r[0] = c.r[2];  // 060777B4 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060777B6 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 060777B8 mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x060778F2u);  // 060777BA mov.w 0x060778F2,r9
    c.r[0] = c.r[3];  // 060777BC mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 060777BE mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06077914u);  // 060777C0 mov.l 0x06077914,r2
    c.r[1] &= c.r[2];  // 060777C2 and r2,r1
    c.r[2] = ld32(0x0607791Cu);  // 060777C4 mov.l 0x0607791C,r2
    c.r[2] |= c.r[1];  // 060777C6 or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 060777C8 mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060777CA mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F4u);  // 060777CC mov.w 0x060778F4,r0
    c.r[1] &= c.r[0];  // 060777CE and r0,r1
    c.r[0] = 0x8u;  // 060777D0 mov #8,r0
    c.r[1] |= c.r[0];  // 060777D2 or r0,r1
    c.r[0] = c.r[3];  // 060777D4 mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 060777D6 mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 060777D8 mov.l @r8,r1
    c.r[0] = c.r[1];  // 060777DA mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060777DC mov.b @(r0,r9),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F6u);  // 060777DE mov.w 0x060778F6,r0
    c.r[2] &= c.r[0];  // 060777E0 and r0,r2
    c.r[0] = 0x2u; goto L_06077A52;  // 060777E2 bra 0x06077A52 ; mov #2,r0
L_060777E6:
    c.r[8] = ld32(0x06077910u);  // 060777E6 mov.l 0x06077910,r8
    c.r[1] = ld32(c.r[8]);  // 060777E8 mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060778E8u);  // 060777EA mov.w 0x060778E8,r3
    c.r[0] = c.r[1];  // 060777EC mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060777EE mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778EAu);  // 060777F0 mov.w 0x060778EA,r0
    c.r[2] &= c.r[0];  // 060777F2 and r0,r2
    c.r[0] = c.r[1];  // 060777F4 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 060777F6 mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 060777F8 mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060778ECu);  // 060777FA mov.w 0x060778EC,r7
    c.r[0] = c.r[2];  // 060777FC mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 060777FE mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 06077800 mov #127,r6
    c.r[6] &= c.r[1];  // 06077802 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060778FAu);  // 06077804 mov.w 0x060778FA,r1
    c.r[6] |= c.r[1];  // 06077806 or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 06077808 mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607780A mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F0u);  // 0607780C mov.w 0x060778F0,r0
    c.r[1] &= c.r[0];  // 0607780E and r0,r1
    c.r[0] = 0x14u;  // 06077810 mov #20,r0
    c.r[1] |= c.r[0];  // 06077812 or r0,r1
    c.r[0] = c.r[2];  // 06077814 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06077816 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 06077818 mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x060778F2u);  // 0607781A mov.w 0x060778F2,r9
    c.r[0] = c.r[3];  // 0607781C mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0607781E mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06077914u);  // 06077820 mov.l 0x06077914,r2
    c.r[1] &= c.r[2];  // 06077822 and r2,r1
    c.r[2] = ld32(0x06077920u);  // 06077824 mov.l 0x06077920,r2
    c.r[2] |= c.r[1];  // 06077826 or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06077828 mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607782A mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F4u);  // 0607782C mov.w 0x060778F4,r0
    c.r[1] &= c.r[0];  // 0607782E and r0,r1
    c.r[0] = 0x10u;  // 06077830 mov #16,r0
    c.r[1] |= c.r[0];  // 06077832 or r0,r1
    c.r[0] = c.r[3];  // 06077834 mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06077836 mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 06077838 mov.l @r8,r1
    c.r[0] = c.r[1];  // 0607783A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0607783C mov.b @(r0,r9),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F6u);  // 0607783E mov.w 0x060778F6,r0
    c.r[2] &= c.r[0];  // 06077840 and r0,r2
    c.r[0] = 0x4u; goto L_06077A52;  // 06077842 bra 0x06077A52 ; mov #4,r0
L_06077846:
    c.r[8] = ld32(0x06077910u);  // 06077846 mov.l 0x06077910,r8
    c.r[1] = ld32(c.r[8]);  // 06077848 mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060778E8u);  // 0607784A mov.w 0x060778E8,r3
    c.r[0] = c.r[1];  // 0607784C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607784E mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778EAu);  // 06077850 mov.w 0x060778EA,r0
    c.r[2] &= c.r[0];  // 06077852 and r0,r2
    c.r[0] = c.r[1];  // 06077854 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06077856 mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 06077858 mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060778ECu);  // 0607785A mov.w 0x060778EC,r7
    c.r[0] = c.r[2];  // 0607785C mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0607785E mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 06077860 mov #127,r6
    c.r[6] &= c.r[1];  // 06077862 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060778FCu);  // 06077864 mov.w 0x060778FC,r1
    c.r[6] |= c.r[1];  // 06077866 or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 06077868 mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607786A mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F0u);  // 0607786C mov.w 0x060778F0,r0
    c.r[1] &= c.r[0];  // 0607786E and r0,r1
    c.r[0] = 0xCu;  // 06077870 mov #12,r0
    c.r[1] |= c.r[0];  // 06077872 or r0,r1
    c.r[0] = c.r[2];  // 06077874 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06077876 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 06077878 mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x060778F2u);  // 0607787A mov.w 0x060778F2,r9
    c.r[0] = c.r[3];  // 0607787C mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0607787E mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06077914u);  // 06077880 mov.l 0x06077914,r2
    c.r[1] &= c.r[2];  // 06077882 and r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060778FEu);  // 06077884 mov.w 0x060778FE,r2
    c.r[2] |= c.r[1]; goto L_06077A3E;  // 06077886 bra 0x06077A3E ; or r1,r2
L_0607788A:
    c.r[8] = ld32(0x06077910u);  // 0607788A mov.l 0x06077910,r8
    c.r[1] = ld32(c.r[8]);  // 0607788C mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060778E8u);  // 0607788E mov.w 0x060778E8,r3
    c.r[0] = c.r[1];  // 06077890 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077892 mov.b @(r0,r3),r2
    c.r[0] = 0x40u;  // 06077894 mov #64,r0
    c.r[2] |= c.r[0];  // 06077896 or r0,r2
    c.r[0] = c.r[1];  // 06077898 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 0607789A mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 0607789C mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060778ECu);  // 0607789E mov.w 0x060778EC,r7
    c.r[0] = c.r[2];  // 060778A0 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 060778A2 mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 060778A4 mov #127,r6
    c.r[6] &= c.r[1];  // 060778A6 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077900u);  // 060778A8 mov.w 0x06077900,r1
    c.r[6] |= c.r[1];  // 060778AA or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 060778AC mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060778AE mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F0u);  // 060778B0 mov.w 0x060778F0,r0
    c.r[1] &= c.r[0];  // 060778B2 and r0,r1
    c.r[0] = 0x8u;  // 060778B4 mov #8,r0
    c.r[1] |= c.r[0];  // 060778B6 or r0,r1
    c.r[0] = c.r[2];  // 060778B8 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060778BA mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 060778BC mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x060778F2u);  // 060778BE mov.w 0x060778F2,r9
    c.r[0] = c.r[3];  // 060778C0 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 060778C2 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06077914u);  // 060778C4 mov.l 0x06077914,r2
    c.r[1] &= c.r[2];  // 060778C6 and r2,r1
    c.r[2] = ld32(0x06077920u);  // 060778C8 mov.l 0x06077920,r2
    c.r[2] |= c.r[1];  // 060778CA or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 060778CC mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060778CE mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F4u);  // 060778D0 mov.w 0x060778F4,r0
    c.r[1] &= c.r[0];  // 060778D2 and r0,r1
    c.r[0] = 0x8u;  // 060778D4 mov #8,r0
    c.r[1] |= c.r[0];  // 060778D6 or r0,r1
    c.r[0] = c.r[3];  // 060778D8 mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 060778DA mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 060778DC mov.l @r8,r1
    c.r[0] = c.r[1];  // 060778DE mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060778E0 mov.b @(r0,r9),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060778F6u);  // 060778E2 mov.w 0x060778F6,r0
    c.r[2] &= c.r[0]; goto L_06077A54;  // 060778E4 bra 0x06077A54 ; and r0,r2
L_06077924:
    c.r[8] = ld32(0x060779ECu);  // 06077924 mov.l 0x060779EC,r8
    c.r[1] = ld32(c.r[8]);  // 06077926 mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060779DCu);  // 06077928 mov.w 0x060779DC,r3
    c.r[0] = c.r[1];  // 0607792A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607792C mov.b @(r0,r3),r2
    c.r[0] = 0x40u;  // 0607792E mov #64,r0
    c.r[2] |= c.r[0];  // 06077930 or r0,r2
    c.r[0] = c.r[1];  // 06077932 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06077934 mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 06077936 mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060779DEu);  // 06077938 mov.w 0x060779DE,r7
    c.r[0] = c.r[2];  // 0607793A mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0607793C mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 0607793E mov #127,r6
    c.r[6] &= c.r[1];  // 06077940 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060779E0u);  // 06077942 mov.w 0x060779E0,r1
    c.r[6] |= c.r[1];  // 06077944 or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 06077946 mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077948 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060779E2u);  // 0607794A mov.w 0x060779E2,r0
    c.r[1] &= c.r[0];  // 0607794C and r0,r1
    c.r[0] = 0x4u;  // 0607794E mov #4,r0
    c.r[1] |= c.r[0];  // 06077950 or r0,r1
    c.r[0] = c.r[2];  // 06077952 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06077954 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 06077956 mov.l @r8,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x060779E4u);  // 06077958 mov.w 0x060779E4,r9
    c.r[0] = c.r[2];  // 0607795A mov r2,r0
    c.r[3] = ld32(c.r[0] + c.r[7]);  // 0607795C mov.l @(r0,r7),r3
    c.r[1] = ld32(0x060779F0u);  // 0607795E mov.l 0x060779F0,r1
    c.r[3] |= c.r[1];  // 06077960 or r1,r3
    st32(c.r[0] + c.r[7], c.r[3]);  // 06077962 mov.l r3,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06077964 mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060779E6u);  // 06077966 mov.w 0x060779E6,r0
    c.r[1] &= c.r[0];  // 06077968 and r0,r1
    c.r[0] = 0x10u;  // 0607796A mov #16,r0
    c.r[1] |= c.r[0];  // 0607796C or r0,r1
    c.r[0] = c.r[2];  // 0607796E mov r2,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06077970 mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 06077972 mov.l @r8,r1
    c.r[0] = c.r[1];  // 06077974 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06077976 mov.b @(r0,r9),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060779E8u);  // 06077978 mov.w 0x060779E8,r0
    c.r[2] &= c.r[0];  // 0607797A and r0,r2
    c.r[0] = 0x2u; goto L_06077A52;  // 0607797C bra 0x06077A52 ; mov #2,r0
L_06077980:
    c.r[8] = ld32(0x060779ECu);  // 06077980 mov.l 0x060779EC,r8
    c.r[1] = ld32(c.r[8]);  // 06077982 mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060779DCu);  // 06077984 mov.w 0x060779DC,r3
    c.r[0] = c.r[1];  // 06077986 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077988 mov.b @(r0,r3),r2
    c.r[0] = 0x40u;  // 0607798A mov #64,r0
    c.r[2] |= c.r[0];  // 0607798C or r0,r2
    c.r[0] = c.r[1];  // 0607798E mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06077990 mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 06077992 mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x060779DEu);  // 06077994 mov.w 0x060779DE,r7
    c.r[0] = c.r[2];  // 06077996 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06077998 mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 0607799A mov #127,r6
    c.r[6] &= c.r[1];  // 0607799C and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060779EAu);  // 0607799E mov.w 0x060779EA,r1
    c.r[6] |= c.r[1];  // 060779A0 or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 060779A2 mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060779A4 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060779E2u);  // 060779A6 mov.w 0x060779E2,r0
    c.r[1] &= c.r[0];  // 060779A8 and r0,r1
    c.r[0] = 0x24u;  // 060779AA mov #36,r0
    c.r[1] |= c.r[0];  // 060779AC or r0,r1
    c.r[0] = c.r[2];  // 060779AE mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060779B0 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 060779B2 mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x060779E4u);  // 060779B4 mov.w 0x060779E4,r9
    c.r[0] = c.r[3];  // 060779B6 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 060779B8 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x060779F4u);  // 060779BA mov.l 0x060779F4,r2
    c.r[1] &= c.r[2];  // 060779BC and r2,r1
    c.r[2] = ld32(0x060779F8u);  // 060779BE mov.l 0x060779F8,r2
    c.r[2] |= c.r[1];  // 060779C0 or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 060779C2 mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060779C4 mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060779E6u);  // 060779C6 mov.w 0x060779E6,r0
    c.r[1] &= c.r[0];  // 060779C8 and r0,r1
    c.r[0] = c.r[3];  // 060779CA mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 060779CC mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 060779CE mov.l @r8,r1
    c.r[0] = c.r[1];  // 060779D0 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060779D2 mov.b @(r0,r9),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060779E8u);  // 060779D4 mov.w 0x060779E8,r0
    c.r[2] &= c.r[0];  // 060779D6 and r0,r2
    c.r[0] = 0x4u; goto L_06077A52;  // 060779D8 bra 0x06077A52 ; mov #4,r0
L_060779FC:
    c.r[8] = ld32(0x06077B48u);  // 060779FC mov.l 0x06077B48,r8
    c.r[1] = ld32(c.r[8]);  // 060779FE mov.l @r8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06077B32u);  // 06077A00 mov.w 0x06077B32,r3
    c.r[0] = c.r[1];  // 06077A02 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077A04 mov.b @(r0,r3),r2
    c.r[0] = 0x40u;  // 06077A06 mov #64,r0
    c.r[2] |= c.r[0];  // 06077A08 or r0,r2
    c.r[0] = c.r[1];  // 06077A0A mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06077A0C mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[8]);  // 06077A0E mov.l @r8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06077B34u);  // 06077A10 mov.w 0x06077B34,r7
    c.r[0] = c.r[2];  // 06077A12 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06077A14 mov.w @(r0,r7),r1
    c.r[6] = 0x7Fu;  // 06077A16 mov #127,r6
    c.r[6] &= c.r[1];  // 06077A18 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077B36u);  // 06077A1A mov.w 0x06077B36,r1
    c.r[6] |= c.r[1];  // 06077A1C or r1,r6
    st16(c.r[0] + c.r[7], c.r[6]);  // 06077A1E mov.w r6,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077A20 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077B38u);  // 06077A22 mov.w 0x06077B38,r0
    c.r[1] &= c.r[0];  // 06077A24 and r0,r1
    c.r[0] = 0x10u;  // 06077A26 mov #16,r0
    c.r[1] |= c.r[0];  // 06077A28 or r0,r1
    c.r[0] = c.r[2];  // 06077A2A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06077A2C mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[8]);  // 06077A2E mov.l @r8,r3
    c.r[9] = (uint32_t)(int16_t)ld16(0x06077B3Au);  // 06077A30 mov.w 0x06077B3A,r9
    c.r[0] = c.r[3];  // 06077A32 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06077A34 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06077B4Cu);  // 06077A36 mov.l 0x06077B4C,r2
    c.r[1] &= c.r[2];  // 06077A38 and r2,r1
    c.r[2] = ld32(0x06077B50u);  // 06077A3A mov.l 0x06077B50,r2
    c.r[2] |= c.r[1];  // 06077A3C or r1,r2
L_06077A3E:
    st32(c.r[0] + c.r[7], c.r[2]);  // 06077A3E mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06077A40 mov.b @(r0,r9),r1
    c.r[0] = 0x18u;  // 06077A42 mov #24,r0
    c.r[1] |= c.r[0];  // 06077A44 or r0,r1
    c.r[0] = c.r[3];  // 06077A46 mov r3,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06077A48 mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[8]);  // 06077A4A mov.l @r8,r1
    c.r[0] = c.r[1];  // 06077A4C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06077A4E mov.b @(r0,r9),r2
    c.r[0] = 0x6u;  // 06077A50 mov #6,r0
L_06077A52:
    c.r[2] |= c.r[0];  // 06077A52 or r0,r2
L_06077A54:
    c.r[0] = c.r[1];  // 06077A54 mov r1,r0
    st8(c.r[0] + c.r[9], c.r[2]);  // 06077A56 mov.b r2,@(r0,r9)
    c.r[0] = ld32(0x06077B54u);  // 06077A58 mov.l 0x06077B54,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077A5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077A5Eu) return; }  // 06077A5A jsr @r0 ; nop
    c.r[2] = c.r[0];  // 06077A5E mov r0,r2
    c.r[2] >>= 8;  // 06077A60 shlr8 r2
    c.r[2] += c.r[2];  // 06077A62 add r2,r2
    c.r[2] >>= 8;  // 06077A64 shlr8 r2
    c.r[0] = 0x1u;  // 06077A66 mov #1,r0
    c.r[1] = ld32(c.r[8]);  // 06077A68 mov.l @r8,r1
    c.r[2] &= c.r[0];  // 06077A6A and r0,r2
    c.r[0] = c.r[1];  // 06077A6C mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06077A6E mov.b @(r0,r9),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077B3Cu);  // 06077A70 mov.w 0x06077B3C,r0
    c.r[3] &= c.r[0];  // 06077A72 and r0,r3
    c.r[3] |= c.r[2];  // 06077A74 or r2,r3
    c.r[0] = c.r[1];  // 06077A76 mov r1,r0
    st8(c.r[0] + c.r[9], c.r[3]);  // 06077A78 mov.b r3,@(r0,r9)
L_06077A7A:
    c.r[10] = ld32(0x06077B48u);  // 06077A7A mov.l 0x06077B48,r10
    c.r[13] = (uint32_t)(int16_t)ld16(0x06077B34u);  // 06077A7C mov.w 0x06077B34,r13
    c.r[11] = ld32(0x06077B58u);  // 06077A7E mov.l 0x06077B58,r11
    c.r[9] = ld32(0x06077B5Cu);  // 06077A80 mov.l 0x06077B5C,r9
    c.r[1] = ld32(c.r[10]);  // 06077A82 mov.l @r10,r1
    c.r[5] = 0xCu;  // 06077A84 mov #12,r5
    c.r[0] = c.r[1];  // 06077A86 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06077A88 mov.w @(r0,r13),r8
    c.r[4] = c.r[11];  // 06077A8A mov r11,r4
    c.r[8] = c.r[8] & 0xFFFFu;  // 06077A8C extu.w r8,r8
    c.r[8] >>= 2;  // 06077A8E shlr2 r8
    c.r[8] >>= 2;  // 06077A90 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06077A92 shlr r8
    { const uint32_t x = c.r[9]; c.pr = 0x06077A98u; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077A98u) return; }  // 06077A94 jsr @r9 ; shlr2 r8
    c.r[1] = c.r[0];  // 06077A98 mov r0,r1
    c.r[5] = c.r[8];  // 06077A9A mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06077AA0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077AA0u) return; }  // 06077A9C jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 06077AA0 mov r0,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077B3Eu);  // 06077AA2 mov.w 0x06077B3E,r1
    c.r[5] = 0x1u;  // 06077AA4 mov #1,r5
    c.r[4] = c.r[12];  // 06077AA6 mov r12,r4
    c.r[8] = ld32(c.r[10]);  // 06077AA8 mov.l @r10,r8
    c.r[0] = ld32(0x06077B60u);  // 06077AAA mov.l 0x06077B60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077AB0u; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077AB0u) return; }  // 06077AAC jsr @r0 ; add r1,r8
    c.r[1] = c.r[0];  // 06077AB0 mov r0,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06077AB2 extu.b r1,r6
    c.r[6] += 1;  // 06077AB4 add #1,r6
    c.r[1] = ld32(0x06077B64u);  // 06077AB6 mov.l 0x06077B64,r1
    c.r[5] = c.r[12];  // 06077AB8 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06077ABEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077ABEu) return; }  // 06077ABA jsr @r1 ; mov r8,r4
    c.r[1] = ld32(c.r[10]);  // 06077ABE mov.l @r10,r1
    c.r[5] = 0xDu;  // 06077AC0 mov #13,r5
    c.r[0] = c.r[1];  // 06077AC2 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06077AC4 mov.w @(r0,r13),r8
    c.r[4] = c.r[11];  // 06077AC6 mov r11,r4
    c.r[8] = c.r[8] & 0xFFFFu;  // 06077AC8 extu.w r8,r8
    c.r[8] >>= 2;  // 06077ACA shlr2 r8
    c.r[8] >>= 2;  // 06077ACC shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06077ACE shlr r8
    { const uint32_t x = c.r[9]; c.pr = 0x06077AD4u; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077AD4u) return; }  // 06077AD0 jsr @r9 ; shlr2 r8
    c.r[1] = c.r[0];  // 06077AD4 mov r0,r1
    c.r[5] = c.r[8];  // 06077AD6 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06077ADCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077ADCu) return; }  // 06077AD8 jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 06077ADC mov r0,r12
    c.r[8] = (uint32_t)(int16_t)ld16(0x06077B40u);  // 06077ADE mov.w 0x06077B40,r8
    c.r[6] = 0x5u;  // 06077AE0 mov #5,r6
    c.r[5] = 0x0u;  // 06077AE2 mov #0,r5
    c.r[4] = ld32(c.r[10]);  // 06077AE4 mov.l @r10,r4
    c.r[0] = ld32(0x06077B68u);  // 06077AE6 mov.l 0x06077B68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077AECu; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077AECu) return; }  // 06077AE8 jsr @r0 ; add r8,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06077B42u);  // 06077AEC mov.w 0x06077B42,r3
    c.r[1] = 0xFFFFFFFFu;  // 06077AEE mov #-1,r1
    c.r[6] = 0x5u;  // 06077AF0 mov #5,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x06077B44u);  // 06077AF2 mov.w 0x06077B44,r7
    c.r[2] = ld32(c.r[10]);  // 06077AF4 mov.l @r10,r2
    c.r[5] = c.r[8];  // 06077AF6 mov r8,r5
    c.r[0] = c.r[2];  // 06077AF8 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06077AFA mov.b r1,@(r0,r3)
    c.r[3] = 0x0u;  // 06077AFC mov #0,r3
L_06077AFE:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06077AFE mov.b @r12,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06077B00 extu.b r2,r1
    c.t = c.r[1] == c.r[7];  // 06077B02 cmp/eq r7,r1
    if (c.t) { goto L_06077B16; }  // 06077B04 bt 0x06077B16
    c.r[1] = ld32(c.r[10]);  // 06077B06 mov.l @r10,r1
    c.r[12] += 1;  // 06077B08 add #1,r12
    c.r[1] += c.r[3];  // 06077B0A add r3,r1
    c.r[0] = c.r[1];  // 06077B0C mov r1,r0
    c.r[3] += 1;  // 06077B0E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 06077B10 cmp/gt r6,r3
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[2]); if (k) { SH2_POLL(c); goto L_06077AFE; } }  // 06077B12 bf/s 0x06077AFE ; mov.b r2,@(r0,r5)
L_06077B16:
    c.r[0] = ld32(0x06077B6Cu);  // 06077B16 mov.l 0x06077B6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077B1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077B1Cu) return; }  // 06077B18 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 06077B1C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06077B1E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06077B20 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06077B22 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06077B24 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06077B26 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06077B28 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06077B2A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077B46u);  // 06077B2C mov.w 0x06077B46,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06077B2E rts ; mov.l @r15+,r8
}

void f_06077B70(SH2Context& c) {
    ran[1656] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06077B70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06077B72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06077B74 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06077B76 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06077B78 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06077B7A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06077B7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06077B7E sts.l pr,@-r15
    c.r[1] = ld32(0x06077BA4u);  // 06077B80 mov.l 0x06077BA4,r1
    c.r[1] = ld32(c.r[1]);  // 06077B82 mov.l @r1,r1
    c.r[1] += 1;  // 06077B84 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077B86 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077B88 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077B8A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06077BAC; } }  // 06077B8C bt/s 0x06077BAC ; mov r15,r14
    c.r[1] = ld32(0x06077BA8u);  // 06077B90 mov.l 0x06077BA8,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06077B9Cu);  // 06077B92 mov.w 0x06077B9C,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06077B9Eu);  // 06077B94 mov.w 0x06077B9E,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06077BA0u);  // 06077B96 mov.w 0x06077BA0,r12
    c.r[1] = ld32(c.r[1]); goto L_06077BB6;  // 06077B98 bra 0x06077BB6 ; mov.l @r1,r1
L_06077BAC:
    c.r[1] = ld32(0x06077D28u);  // 06077BAC mov.l 0x06077D28,r1
    c.r[1] = ld32(c.r[1]);  // 06077BAE mov.l @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06077D14u);  // 06077BB0 mov.w 0x06077D14,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06077D16u);  // 06077BB2 mov.w 0x06077D16,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06077D18u);  // 06077BB4 mov.w 0x06077D18,r12
L_06077BB6:
    c.r[9] += c.r[1];  // 06077BB6 add r1,r9
    c.r[13] += c.r[1];  // 06077BB8 add r1,r13
    c.r[4] = ld32(0x06077D2Cu);  // 06077BBA mov.l 0x06077D2C,r4
    c.r[8] = ld32(0x06077D30u);  // 06077BBC mov.l 0x06077D30,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06077BC2u; c.r[5] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077BC2u) return; }  // 06077BBE jsr @r8 ; mov #12,r5
    c.r[5] = c.r[12];  // 06077BC2 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077BC8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077BC8u) return; }  // 06077BC4 jsr @r8 ; mov r0,r4
    c.r[11] = c.r[0];  // 06077BC8 mov r0,r11
    c.r[0] = ld32(0x06077D34u);  // 06077BCA mov.l 0x06077D34,r0
    c.r[5] = 0x1u;  // 06077BCC mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06077BD2u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077BD2u) return; }  // 06077BCE jsr @r0 ; mov r9,r4
    c.r[6] = c.r[0] & 0xFFu;  // 06077BD2 extu.b r0,r6
    c.r[6] += 1;  // 06077BD4 add #1,r6
    c.r[1] = ld32(0x06077D38u);  // 06077BD6 mov.l 0x06077D38,r1
    c.r[5] = c.r[9];  // 06077BD8 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06077BDEu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077BDEu) return; }  // 06077BDA jsr @r1 ; mov r11,r4
    c.r[2] = 0x5u;  // 06077BDE mov #5,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06077D1Au);  // 06077BE0 mov.w 0x06077D1A,r3
    c.r[1] = c.r[9];  // 06077BE2 mov r9,r1
L_06077BE4:
    c.r[1] += c.r[2];  // 06077BE4 add r2,r1
    c.r[1] += 14;  // 06077BE6 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077BE8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077BEA extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06077BEC cmp/eq r3,r1
    if (!c.t) { goto L_06077BF8; }  // 06077BEE bf 0x06077BF8
    c.r[2] -= 1;  // 06077BF0 add #-1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06077BF2 tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_06077BE4; } }  // 06077BF4 bf/s 0x06077BE4 ; mov r9,r1
L_06077BF8:
    c.r[3] = c.r[9];  // 06077BF8 mov r9,r3
    c.r[3] += c.r[2];  // 06077BFA add r2,r3
    c.r[1] = c.r[3];  // 06077BFC mov r3,r1
    c.r[1] += 14;  // 06077BFE add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077C00 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077C02 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077C04 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06077C28; } }  // 06077C06 bf/s 0x06077C28 ; tst r2,r2
    { const bool k = c.t; c.r[7] = 0xFFFFFFFFu; if (k) { goto L_06077C28; } }  // 06077C0A bt/s 0x06077C28 ; mov #-1,r7
    c.r[3] += 14;  // 06077C0E add #14,r3
L_06077C10:
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 06077C10 dt r2
    { const bool k = c.t; st8(c.r[3], c.r[7]); if (k) { goto L_06077C28; } }  // 06077C12 bt/s 0x06077C28 ; mov.b r7,@r3
    c.r[3] = c.r[9];  // 06077C16 mov r9,r3
    c.r[3] += c.r[2];  // 06077C18 add r2,r3
    c.r[1] = c.r[3];  // 06077C1A mov r3,r1
    c.r[1] += 14;  // 06077C1C add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077C1E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077C20 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077C22 tst r1,r1
    { const bool k = c.t; c.r[3] += 14; if (k) { SH2_POLL(c); goto L_06077C10; } }  // 06077C24 bt/s 0x06077C10 ; add #14,r3
L_06077C28:
    c.r[10] = ld32(0x06077D2Cu);  // 06077C28 mov.l 0x06077D2C,r10
    c.r[8] = ld32(0x06077D30u);  // 06077C2A mov.l 0x06077D30,r8
    c.r[5] = 0xDu;  // 06077C2C mov #13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077C32u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C32u) return; }  // 06077C2E jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06077C32 mov r0,r1
    c.r[5] = c.r[12];  // 06077C34 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077C3Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C3Au) return; }  // 06077C36 jsr @r8 ; mov r1,r4
    c.r[11] = c.r[0];  // 06077C3A mov r0,r11
    c.r[9] += 14;  // 06077C3C add #14,r9
    c.r[5] = 0x1u;  // 06077C3E mov #1,r5
    c.r[0] = ld32(0x06077D34u);  // 06077C40 mov.l 0x06077D34,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077C46u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C46u) return; }  // 06077C42 jsr @r0 ; mov r9,r4
    c.r[1] = c.r[0];  // 06077C46 mov r0,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06077C48 extu.b r1,r6
    c.r[6] += 1;  // 06077C4A add #1,r6
    c.r[5] = c.r[9];  // 06077C4C mov r9,r5
    c.r[0] = ld32(0x06077D38u);  // 06077C4E mov.l 0x06077D38,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077C54u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C54u) return; }  // 06077C50 jsr @r0 ; mov r11,r4
    c.r[5] = 0x1Cu;  // 06077C54 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077C5Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C5Au) return; }  // 06077C56 jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06077C5A mov r0,r1
    c.r[5] = c.r[12];  // 06077C5C mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077C62u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C62u) return; }  // 06077C5E jsr @r8 ; mov r1,r4
    c.r[11] = c.r[0];  // 06077C62 mov r0,r11
    c.r[1] = c.r[13];  // 06077C64 mov r13,r1
    c.r[1] += 1;  // 06077C66 add #1,r1
    c.r[0] = 0x2u;  // 06077C68 mov #2,r0
    c.r[13] += 2;  // 06077C6A add #2,r13
    c.r[2] = 0x1u;  // 06077C6C mov #1,r2
    c.r[5] = 0x1Cu;  // 06077C6E mov #28,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077C70 mov.b @r1,r1
    c.r[4] = c.r[10];  // 06077C72 mov r10,r4
    c.r[3] = c.r[1];  // 06077C74 mov r1,r3
    c.r[3] >>= 2;  // 06077C76 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06077C78 shlr r3
    c.r[3] >>= 2;  // 06077C7A shlr2 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06077C7C mov.b @r13,r1
    c.r[3] &= c.r[0];  // 06077C7E and r0,r3
    c.r[2] &= c.r[1];  // 06077C80 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077D1Cu);  // 06077C82 mov.w 0x06077D1C,r1
    c.r[1] += c.r[2];  // 06077C84 add r2,r1
    c.r[3] += c.r[1];  // 06077C86 add r1,r3
    { const uint32_t x = c.r[8]; c.pr = 0x06077C8Cu; c.r[12] = c.r[3] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C8Cu) return; }  // 06077C88 jsr @r8 ; extu.w r3,r12
    c.r[1] = c.r[0];  // 06077C8C mov r0,r1
    c.r[5] = c.r[12];  // 06077C8E mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077C94u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077C94u) return; }  // 06077C90 jsr @r8 ; mov r1,r4
    c.r[13] = c.r[0];  // 06077C94 mov r0,r13
    c.r[12] += 1;  // 06077C96 add #1,r12
    c.r[9] = c.r[12] & 0xFFFFu;  // 06077C98 extu.w r12,r9
    c.r[5] = 0x1Cu;  // 06077C9A mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077CA0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077CA0u) return; }  // 06077C9C jsr @r8 ; mov r10,r4
    c.r[1] = c.r[0];  // 06077CA0 mov r0,r1
    c.r[5] = c.r[9];  // 06077CA2 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077CA8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077CA8u) return; }  // 06077CA4 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06077CA8 mov r0,r1
    c.r[1] -= c.r[13];  // 06077CAA sub r13,r1
    c.r[6] = c.r[1];  // 06077CAC mov r1,r6
    c.r[5] = c.r[13];  // 06077CAE mov r13,r5
    c.r[0] = ld32(0x06077D38u);  // 06077CB0 mov.l 0x06077D38,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06077CB6u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077CB6u) return; }  // 06077CB2 jsr @r0 ; mov r11,r4
    c.r[1] = ld32(0x06077D3Cu);  // 06077CB6 mov.l 0x06077D3C,r1
    c.r[1] = ld32(c.r[1]);  // 06077CB8 mov.l @r1,r1
    c.r[1] += 1;  // 06077CBA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077CBC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077CBE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077CC0 tst r1,r1
    if (!c.t) { goto L_06077DB2; }  // 06077CC2 bf 0x06077DB2
    c.r[7] = ld32(0x06077D28u);  // 06077CC4 mov.l 0x06077D28,r7
    c.r[2] = ld32(c.r[7]);  // 06077CC6 mov.l @r7,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077D1Eu);  // 06077CC8 mov.w 0x06077D1E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06077CCA mov.b @(r0,r2),r1
    c.r[0] = c.r[1];  // 06077CCC mov r1,r0
    c.r[0] >>= 2;  // 06077CCE shlr2 r0
    c.r[0] >>= 2;  // 06077CD0 shlr2 r0
    c.r[0] >>= 2;  // 06077CD2 shlr2 r0
    c.r[0] &= 0x1u;  // 06077CD4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06077CD6 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06077CEA; } }  // 06077CD8 bt/s 0x06077CEA ; mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077D20u);  // 06077CDC mov.w 0x06077D20,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06077CDE mov.b @(r0,r1),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077D22u);  // 06077CE0 mov.w 0x06077D22,r0
    c.r[3] |= c.r[0];  // 06077CE2 or r0,r3
    c.r[0] = c.r[2];  // 06077CE4 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 06077CE6 mov.b r3,@(r0,r1)
    c.r[2] = ld32(c.r[7]);  // 06077CE8 mov.l @r7,r2
L_06077CEA:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06077D24u);  // 06077CEA mov.w 0x06077D24,r3
    c.r[0] = c.r[2];  // 06077CEC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077CEE mov.b @(r0,r3),r1
    c.r[6] = 0x1u;  // 06077CF0 mov #1,r6
    c.r[1] >>= 2;  // 06077CF2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06077CF4 shlr r1
    c.r[0] = 0x3u;  // 06077CF6 mov #3,r0
    c.r[1] &= c.r[0];  // 06077CF8 and r0,r1
    c.t = c.r[1] > c.r[6];  // 06077CFA cmp/hi r6,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06077D0C; } }  // 06077CFC bf/s 0x06077D0C ; mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077D20u);  // 06077D00 mov.w 0x06077D20,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06077D02 mov.b @(r0,r1),r5
    c.r[0] = 0x40u;  // 06077D04 mov #64,r0
    c.r[5] |= c.r[0];  // 06077D06 or r0,r5
    c.r[0] = c.r[2];  // 06077D08 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[5]);  // 06077D0A mov.b r5,@(r0,r1)
L_06077D0C:
    c.r[2] = ld32(c.r[7]);  // 06077D0C mov.l @r7,r2
    c.r[0] = c.r[2];  // 06077D0E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_06077D40;  // 06077D10 bra 0x06077D40 ; mov.b @(r0,r3),r1
L_06077D40:
    c.r[1] >>= 2;  // 06077D40 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06077D42 shlr r1
    c.r[0] = 0x2u;  // 06077D44 mov #2,r0
    c.r[1] &= c.r[0];  // 06077D46 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077D48 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06077D5A; } }  // 06077D4A bt/s 0x06077D5A ; mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077DC8u);  // 06077D4E mov.w 0x06077DC8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06077D50 mov.b @(r0,r1),r5
    c.r[0] = 0x20u;  // 06077D52 mov #32,r0
    c.r[5] |= c.r[0];  // 06077D54 or r0,r5
    c.r[0] = c.r[2];  // 06077D56 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[5]);  // 06077D58 mov.b r5,@(r0,r1)
L_06077D5A:
    c.r[2] = ld32(c.r[7]);  // 06077D5A mov.l @r7,r2
    c.r[0] = c.r[2];  // 06077D5C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077D5E mov.b @(r0,r3),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06077D60 shlr r1
    c.r[0] = 0x3u;  // 06077D62 mov #3,r0
    c.r[1] &= c.r[0];  // 06077D64 and r0,r1
    c.t = c.r[1] > c.r[6];  // 06077D66 cmp/hi r6,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06077D7A; } }  // 06077D68 bf/s 0x06077D7A ; mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077DC8u);  // 06077D6C mov.w 0x06077DC8,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06077D6E mov.b @(r0,r1),r6
    c.r[0] = 0x10u;  // 06077D70 mov #16,r0
    c.r[6] |= c.r[0];  // 06077D72 or r0,r6
    c.r[0] = c.r[2];  // 06077D74 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06077D76 mov.b r6,@(r0,r1)
    c.r[2] = ld32(c.r[7]);  // 06077D78 mov.l @r7,r2
L_06077D7A:
    c.r[0] = c.r[2];  // 06077D7A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077D7C mov.b @(r0,r3),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06077D7E shlr r1
    c.r[0] = 0x2u;  // 06077D80 mov #2,r0
    c.r[1] &= c.r[0];  // 06077D82 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077D84 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06077D96; } }  // 06077D86 bt/s 0x06077D96 ; mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06077DC8u);  // 06077D8A mov.w 0x06077DC8,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06077D8C mov.b @(r0,r1),r6
    c.r[0] = 0x8u;  // 06077D8E mov #8,r0
    c.r[6] |= c.r[0];  // 06077D90 or r0,r6
    c.r[0] = c.r[2];  // 06077D92 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06077D94 mov.b r6,@(r0,r1)
L_06077D96:
    c.r[1] = ld32(c.r[7]);  // 06077D96 mov.l @r7,r1
    c.r[0] = c.r[1];  // 06077D98 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06077D9A mov.b @(r0,r3),r2
    c.r[0] = 0x1u;  // 06077D9C mov #1,r0
    c.r[2] &= c.r[0];  // 06077D9E and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06077DA0 tst r2,r2
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06077DB2; } }  // 06077DA2 bt/s 0x06077DB2 ; mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06077DC8u);  // 06077DA6 mov.w 0x06077DC8,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06077DA8 mov.b @(r0,r2),r3
    c.r[0] = 0x4u;  // 06077DAA mov #4,r0
    c.r[3] |= c.r[0];  // 06077DAC or r0,r3
    c.r[0] = c.r[1];  // 06077DAE mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06077DB0 mov.b r3,@(r0,r2)
L_06077DB2:
    c.r[15] = c.r[14];  // 06077DB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06077DB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06077DB6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06077DB8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06077DBA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06077DBC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06077DBE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06077DC0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06077DCAu);  // 06077DC2 mov.w 0x06077DCA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06077DC4 rts ; mov.l @r15+,r8
}

void f_06077DCC(SH2Context& c) {
    ran[1657] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06077DCC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06077DCE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06077DD0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06077DD2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06077DD4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06077DD6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06077DD8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06077DDA sts.l pr,@-r15
    c.r[1] = ld32(0x06077ED4u);  // 06077DDC mov.l 0x06077ED4,r1
    c.r[1] = ld32(c.r[1]);  // 06077DDE mov.l @r1,r1
    c.r[1] += 1;  // 06077DE0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077DE2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077DE4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077DE6 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06077DF6; } }  // 06077DE8 bt/s 0x06077DF6 ; mov r15,r14
    c.r[1] = ld32(0x06077ED8u);  // 06077DEC mov.l 0x06077ED8,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06077ECCu);  // 06077DEE mov.w 0x06077ECC,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x06077ECEu);  // 06077DF0 mov.w 0x06077ECE,r12
    c.r[1] = ld32(c.r[1]); goto L_06077DFE;  // 06077DF2 bra 0x06077DFE ; mov.l @r1,r1
L_06077DF6:
    c.r[1] = ld32(0x06077ED8u);  // 06077DF6 mov.l 0x06077ED8,r1
    c.r[1] = ld32(c.r[1]);  // 06077DF8 mov.l @r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06077ED0u);  // 06077DFA mov.w 0x06077ED0,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x06077ED2u);  // 06077DFC mov.w 0x06077ED2,r12
L_06077DFE:
    c.r[11] += c.r[1];  // 06077DFE add r1,r11
    c.r[12] += c.r[1];  // 06077E00 add r1,r12
    c.r[1] = ld32(0x06077ED4u);  // 06077E02 mov.l 0x06077ED4,r1
    c.r[3] = ld32(c.r[1]);  // 06077E04 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06077E06 mov r3,r1
    c.r[1] += 2;  // 06077E08 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077E0A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06077E0C extu.b r1,r2
    c.r[1] = 0x6u;  // 06077E0E mov #6,r1
    c.r[2] -= 1;  // 06077E10 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06077E12 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06077E1C; } }  // 06077E14 bf/s 0x06077E1C ; mov r2,r1
    goto L_060781E0;  // 06077E18 bra 0x060781E0 ; nop
L_06077E1C:
    c.r[1] += c.r[1];  // 06077E1C add r1,r1
    c.r[0] = 0x06077E28u;  // 06077E1E mova 0x06077E28,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06077E20 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06077E22 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06077E36u: goto L_06077E36; case 0x06078076u: goto L_06078076; case 0x0607809Au: goto L_0607809A; case 0x060780CAu: goto L_060780CA; case 0x060780F4u: goto L_060780F4; case 0x0607811Cu: goto L_0607811C; case 0x06078142u: goto L_06078142; default: sh2_call(c, x); return; } }  // 06077E24 jmp @r0 ; nop
L_06077E36:
    c.r[2] = ld32(0x06077EDCu);  // 06077E36 mov.l 0x06077EDC,r2
    c.r[1] = 0x0u;  // 06077E38 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06077E3A mov.b r1,@r2
    c.r[10] = ld32(0x06077EE0u);  // 06077E3C mov.l 0x06077EE0,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06077E3E mov.b @r10,r1
    c.r[13] = ld32(0x06077EE4u);  // 06077E40 mov.l 0x06077EE4,r13
    c.r[0] = c.r[1] & 0xFFu;  // 06077E42 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06077E44 mov.b @(r0,r13),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06077E46 extu.b r1,r3
    c.r[1] = 0x4u;  // 06077E48 mov #4,r1
    c.r[2] = c.r[3];  // 06077E4A mov r3,r2
    c.r[2] -= 121;  // 06077E4C add #-121,r2
    c.t = c.r[2] > c.r[1];  // 06077E4E cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06077E58; } }  // 06077E50 bf/s 0x06077E58 ; mov r2,r1
    goto L_06077F7E;  // 06077E54 bra 0x06077F7E ; nop
L_06077E58:
    c.r[1] += c.r[1];  // 06077E58 add r1,r1
    c.r[0] = 0x06077E64u;  // 06077E5A mova 0x06077E64,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06077E5C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06077E5E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06077E6Eu: goto L_06077E6E; case 0x06077E84u: goto L_06077E84; case 0x06078052u: goto L_06078052; case 0x06077E9Au: goto L_06077E9A; case 0x06077EB8u: goto L_06077EB8; default: sh2_call(c, x); return; } }  // 06077E60 jmp @r0 ; nop
L_06077E6E:
    c.r[2] = ld32(0x06077EE8u);  // 06077E6E mov.l 0x06077EE8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06077E70 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077E72 extu.b r1,r1
    c.r[1] -= 1;  // 06077E74 add #-1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06077E76 cmp/pz r1
    if (!c.t) { goto L_06077E7E; }  // 06077E78 bf 0x06077E7E
    goto L_06078058;  // 06077E7A bra 0x06078058 ; nop
L_06077E7E:
    c.r[1] = 0u - c.r[1];  // 06077E7E neg r1,r1
    st8(c.r[2], c.r[1]); goto L_0607805A;  // 06077E80 bra 0x0607805A ; mov.b r1,@r2
L_06077E84:
    c.r[3] = ld32(0x06077EECu);  // 06077E84 mov.l 0x06077EEC,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06077E86 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06077E88 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077E8A tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06077E94; } }  // 06077E8C bf/s 0x06077E94 ; mov r2,r1
    goto L_0607805A;  // 06077E90 bra 0x0607805A ; nop
L_06077E94:
    c.r[1] -= 1;  // 06077E94 add #-1,r1
    st8(c.r[3], c.r[1]); goto L_0607805A;  // 06077E96 bra 0x0607805A ; mov.b r1,@r3
L_06077E9A:
    c.r[1] = ld32(0x06077EECu);  // 06077E9A mov.l 0x06077EEC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077E9C mov.b @r1,r1
    c.r[2] = 0xBu;  // 06077E9E mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06077EA0 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06077EA2 cmp/hi r2,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06077EB0; } }  // 06077EA4 bt/s 0x06077EB0 ; mov #0,r6
    c.r[1] = ld32(0x06077EF0u);  // 06077EA8 mov.l 0x06077EF0,r1
    c.r[5] = c.r[11];  // 06077EAA mov r11,r5
    c.r[4] = 0x0u; goto L_0607804E;  // 06077EAC bra 0x0607804E ; mov #0,r4
L_06077EB0:
    c.r[1] = ld32(0x06077EF0u);  // 06077EB0 mov.l 0x06077EF0,r1
    c.r[5] = c.r[12];  // 06077EB2 mov r12,r5
    c.r[4] = 0x1u; goto L_0607804E;  // 06077EB4 bra 0x0607804E ; mov #1,r4
L_06077EB8:
    c.r[8] = 0x5u;  // 06077EB8 mov #5,r8
    c.r[2] = ld32(0x06077EF4u);  // 06077EBA mov.l 0x06077EF4,r2
    c.r[0] = c.r[2];  // 06077EBC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06077EBE mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077EC0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077EC2 tst r1,r1
    if (!c.t) { goto L_06077F0A; }  // 06077EC4 bf 0x06077F0A
    c.r[8] = 0x4u;  // 06077EC6 mov #4,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]); goto L_06077F00;  // 06077EC8 bra 0x06077F00 ; mov.b @(r0,r8),r1
L_06077EF8:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06077EF8 tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06077F0A; } }  // 06077EFA bt/s 0x06077F0A ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06077EFE mov.b @(r0,r8),r1
L_06077F00:
    c.r[1] = c.r[1] & 0xFFu;  // 06077F00 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077F02 tst r1,r1
    { const bool k = c.t; c.r[8] -= 1; if (k) { SH2_POLL(c); goto L_06077EF8; } }  // 06077F04 bt/s 0x06077EF8 ; add #-1,r8
    c.r[8] += 1;  // 06077F08 add #1,r8
L_06077F0A:
    c.r[8] += 1;  // 06077F0A add #1,r8
    c.r[10] = ld32(0x06078198u);  // 06077F0C mov.l 0x06078198,r10
    c.r[1] = ld32(0x0607819Cu);  // 06077F0E mov.l 0x0607819C,r1
    c.r[6] = c.r[8];  // 06077F10 mov r8,r6
    c.r[5] = c.r[10];  // 06077F12 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06077F18u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077F18u) return; }  // 06077F14 jsr @r1 ; mov r11,r4
    c.r[1] = 0xFFFFFFE3u;  // 06077F18 mov #-29,r1
    c.r[0] = c.r[11];  // 06077F1A mov r11,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 06077F1C mov.b r1,@(r0,r8)
    c.r[8] += 1;  // 06077F1E add #1,r8
    c.r[1] = c.r[10];  // 06077F20 mov r10,r1
    c.r[1] += 12;  // 06077F22 add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077F24 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077F26 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077F28 tst r1,r1
    { const bool k = !c.t; c.r[9] = 0x5u; if (k) { goto L_06077F56; } }  // 06077F2A bf/s 0x06077F56 ; mov #5,r9
    c.r[1] = c.r[10];  // 06077F2E mov r10,r1
    c.r[1] += 11;  // 06077F30 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077F32 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077F34 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077F36 tst r1,r1
    { const bool k = !c.t; c.r[9] = 0x4u; if (k) { goto L_06077F56; } }  // 06077F38 bf/s 0x06077F56 ; mov #4,r9
    c.r[5] = c.r[10];  // 06077F3C mov r10,r5
    c.r[9] -= 1;  // 06077F3E add #-1,r9
L_06077F40:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06077F40 tst r9,r9
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06077F56; } }  // 06077F42 bt/s 0x06077F56 ; mov r9,r1
    c.r[1] += c.r[5];  // 06077F46 add r5,r1
    c.r[1] += 7;  // 06077F48 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077F4A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077F4C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077F4E tst r1,r1
    { const bool k = c.t; c.r[9] -= 1; if (k) { SH2_POLL(c); goto L_06077F40; } }  // 06077F50 bt/s 0x06077F40 ; add #-1,r9
    c.r[9] += 1;  // 06077F54 add #1,r9
L_06077F56:
    c.r[5] = ld32(0x060781A0u);  // 06077F56 mov.l 0x060781A0,r5
    c.r[6] = c.r[9];  // 06077F58 mov r9,r6
    c.r[6] += 1;  // 06077F5A add #1,r6
    c.r[4] = c.r[11];  // 06077F5C mov r11,r4
    c.r[1] = ld32(0x0607819Cu);  // 06077F5E mov.l 0x0607819C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06077F64u; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077F64u) return; }  // 06077F60 jsr @r1 ; add r8,r4
    c.r[8] += c.r[9];  // 06077F64 add r9,r8
    c.r[8] += c.r[11];  // 06077F66 add r11,r8
    c.r[8] += 1;  // 06077F68 add #1,r8
    c.r[1] = 0xFFFFFFFFu;  // 06077F6A mov #-1,r1
    st8(c.r[8], c.r[1]);  // 06077F6C mov.b r1,@r8
    c.r[8] = ld32(0x060781A4u);  // 06077F6E mov.l 0x060781A4,r8
    c.r[0] = ld32(0x060781A8u);  // 06077F70 mov.l 0x060781A8,r0
    c.r[5] = c.r[12];  // 06077F72 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06077F78u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077F78u) return; }  // 06077F74 jsr @r0 ; mov r11,r4
    c.r[0] += 1;  // 06077F78 add #1,r0
    st8(c.r[8], c.r[0]); goto L_0607805A;  // 06077F7A bra 0x0607805A ; mov.b r0,@r8
L_06077F7E:
    c.r[1] = ld32(0x060781ACu);  // 06077F7E mov.l 0x060781AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077F80 mov.b @r1,r1
    c.r[2] = 0xBu;  // 06077F82 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06077F84 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06077F86 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x50u; if (k) { goto L_06077FEC; } }  // 06077F88 bt/s 0x06077FEC ; mov #80,r1
    c.t = c.r[3] > c.r[1];  // 06077F8C cmp/hi r1,r3
    if (!c.t) { goto L_06077FB8; }  // 06077F8E bf 0x06077FB8
    c.r[4] = ld32(0x060781B0u);  // 06077F90 mov.l 0x060781B0,r4
    c.r[8] = ld32(0x060781B4u);  // 06077F92 mov.l 0x060781B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06077F98u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077F98u) return; }  // 06077F94 jsr @r8 ; mov #23,r5
    c.r[5] = 0x1u;  // 06077F98 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077F9Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077F9Eu) return; }  // 06077F9A jsr @r8 ; mov r0,r4
    c.r[2] = c.r[0];  // 06077F9E mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06077FA0 mov.b @r10,r1
    c.r[5] = c.r[11];  // 06077FA2 mov r11,r5
    c.r[0] = c.r[1] & 0xFFu;  // 06077FA4 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06077FA6 mov.b @(r0,r13),r1
    c.r[4] = 0x0u;  // 06077FA8 mov #0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06077FAA extu.b r1,r1
    c.r[2] += c.r[1];  // 06077FAC add r1,r2
    c.r[2] -= 81;  // 06077FAE add #-81,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06077FB0 mov.b @r2,r6
    c.r[1] = ld32(0x060781B8u);  // 06077FB2 mov.l 0x060781B8,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_0607804E;  // 06077FB4 bra 0x0607804E ; extu.b r6,r6
L_06077FB8:
    c.r[1] = ld32(0x060781BCu);  // 06077FB8 mov.l 0x060781BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06077FBA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06077FBC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06077FBE tst r1,r1
    { const bool k = c.t; c.r[9] = 0x22u; if (k) { goto L_06077FC6; } }  // 06077FC0 bt/s 0x06077FC6 ; mov #34,r9
    c.r[9] = 0x21u;  // 06077FC4 mov #33,r9
L_06077FC6:
    c.r[4] = ld32(0x060781B0u);  // 06077FC6 mov.l 0x060781B0,r4
    c.r[8] = ld32(0x060781B4u);  // 06077FC8 mov.l 0x060781B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06077FCEu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077FCEu) return; }  // 06077FCA jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06077FCE mov r0,r1
    c.r[5] = c.r[9];  // 06077FD0 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077FD6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077FD6u) return; }  // 06077FD2 jsr @r8 ; mov r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06077FD6 mov.b @r10,r1
    c.r[2] = c.r[0];  // 06077FD8 mov r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06077FDA extu.b r1,r1
    c.r[0] = c.r[1];  // 06077FDC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06077FDE mov.b @(r0,r13),r1
    c.r[5] = c.r[11];  // 06077FE0 mov r11,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06077FE2 extu.b r1,r1
    c.r[0] = c.r[2];  // 06077FE4 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06077FE6 mov.b @(r0,r1),r6
    c.r[4] = 0x0u; goto L_0607804A;  // 06077FE8 bra 0x0607804A ; mov #0,r4
L_06077FEC:
    c.t = c.r[3] > c.r[1];  // 06077FEC cmp/hi r1,r3
    if (!c.t) { goto L_06078018; }  // 06077FEE bf 0x06078018
    c.r[4] = ld32(0x060781B0u);  // 06077FF0 mov.l 0x060781B0,r4
    c.r[8] = ld32(0x060781B4u);  // 06077FF2 mov.l 0x060781B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06077FF8u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077FF8u) return; }  // 06077FF4 jsr @r8 ; mov #23,r5
    c.r[5] = 0x1u;  // 06077FF8 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06077FFEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06077FFEu) return; }  // 06077FFA jsr @r8 ; mov r0,r4
    c.r[2] = c.r[0];  // 06077FFE mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06078000 mov.b @r10,r1
    c.r[5] = c.r[12];  // 06078002 mov r12,r5
    c.r[0] = c.r[1] & 0xFFu;  // 06078004 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06078006 mov.b @(r0,r13),r1
    c.r[4] = 0x1u;  // 06078008 mov #1,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0607800A extu.b r1,r1
    c.r[2] += c.r[1];  // 0607800C add r1,r2
    c.r[2] -= 81;  // 0607800E add #-81,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06078010 mov.b @r2,r6
    c.r[1] = ld32(0x060781B8u);  // 06078012 mov.l 0x060781B8,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_0607804E;  // 06078014 bra 0x0607804E ; extu.b r6,r6
L_06078018:
    c.r[1] = ld32(0x060781BCu);  // 06078018 mov.l 0x060781BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607801A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607801C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607801E tst r1,r1
    { const bool k = c.t; c.r[9] = 0x22u; if (k) { goto L_06078026; } }  // 06078020 bt/s 0x06078026 ; mov #34,r9
    c.r[9] = 0x21u;  // 06078024 mov #33,r9
L_06078026:
    c.r[4] = ld32(0x060781B0u);  // 06078026 mov.l 0x060781B0,r4
    c.r[8] = ld32(0x060781B4u);  // 06078028 mov.l 0x060781B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607802Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607802Eu) return; }  // 0607802A jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 0607802E mov r0,r1
    c.r[5] = c.r[9];  // 06078030 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06078036u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078036u) return; }  // 06078032 jsr @r8 ; mov r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06078036 mov.b @r10,r1
    c.r[2] = c.r[0];  // 06078038 mov r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607803A extu.b r1,r1
    c.r[0] = c.r[1];  // 0607803C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0607803E mov.b @(r0,r13),r1
    c.r[5] = c.r[12];  // 06078040 mov r12,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06078042 extu.b r1,r1
    c.r[0] = c.r[2];  // 06078044 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078046 mov.b @(r0,r1),r6
    c.r[4] = 0x1u;  // 06078048 mov #1,r4
L_0607804A:
    c.r[6] = c.r[6] & 0xFFu;  // 0607804A extu.b r6,r6
    c.r[1] = ld32(0x060781B8u);  // 0607804C mov.l 0x060781B8,r1
L_0607804E:
    { const uint32_t x = c.r[1]; c.pr = 0x06078052u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078052u) return; }  // 0607804E jsr @r1 ; nop
L_06078052:
    c.r[2] = ld32(0x060781ACu);  // 06078052 mov.l 0x060781AC,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06078054 mov.b @r2,r1
    c.r[1] += 1;  // 06078056 add #1,r1
L_06078058:
    st8(c.r[2], c.r[1]);  // 06078058 mov.b r1,@r2
L_0607805A:
    c.r[7] = ld32(0x060781ACu);  // 0607805A mov.l 0x060781AC,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607805C mov.b @r7,r3
    c.r[1] = ld32(0x060781C0u);  // 0607805E mov.l 0x060781C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078060 mov.b @r1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06078062 extu.b r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06078064 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06078066 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06078070; } }  // 06078068 bt/s 0x06078070 ; mov r3,r1
    goto L_060782AC;  // 0607806C bra 0x060782AC ; nop
L_06078070:
    c.r[1] -= 1;  // 06078070 add #-1,r1
    st8(c.r[7], c.r[1]); goto L_060782AC;  // 06078072 bra 0x060782AC ; mov.b r1,@r7
L_06078076:
    c.r[1] = ld32(0x060781C4u);  // 06078076 mov.l 0x060781C4,r1
    c.r[2] = ld32(c.r[1]);  // 06078078 mov.l @r1,r2
    c.r[1] = ld32(0x060781C8u);  // 0607807A mov.l 0x060781C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607807C mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0607807E extu.b r1,r3
    c.r[1] = ld32(0x060781CCu);  // 06078080 mov.l 0x060781CC,r1
    c.r[0] = c.r[3];  // 06078082 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078084 mov.b @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06078086 extu.b r1,r7
    c.r[7] += 1;  // 06078088 add #1,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078188u);  // 0607808A mov.w 0x06078188,r3
    c.r[0] = 0xFu;  // 0607808C mov #15,r0
    c.r[7] &= c.r[0];  // 0607808E and r0,r7
    c.r[0] = c.r[2];  // 06078090 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078092 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607818Au);  // 06078094 mov.w 0x0607818A,r0
    c.r[7] <<= 2; goto L_060780EA;  // 06078096 bra 0x060780EA ; shll2 r7
L_0607809A:
    c.r[1] = ld32(0x060781C4u);  // 0607809A mov.l 0x060781C4,r1
    c.r[3] = ld32(c.r[1]);  // 0607809C mov.l @r1,r3
    c.r[1] = ld32(0x060781C8u);  // 0607809E mov.l 0x060781C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060780A0 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060780A2 extu.b r1,r2
    c.r[1] = ld32(0x060781CCu);  // 060780A4 mov.l 0x060781CC,r1
    c.r[0] = c.r[2];  // 060780A6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060780A8 mov.b @(r0,r1),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607818Cu);  // 060780AA mov.w 0x0607818C,r7
    c.r[6] = c.r[1] & 0xFFu;  // 060780AC extu.b r1,r6
    c.r[6] += 1;  // 060780AE add #1,r6
    c.r[0] = 0x1Fu;  // 060780B0 mov #31,r0
    c.r[6] &= c.r[0];  // 060780B2 and r0,r6
    c.r[6] <<= 8;  // 060780B4 shll8 r6
    c.r[6] <<= 2;  // 060780B6 shll2 r6
    c.r[6] += c.r[6];  // 060780B8 add r6,r6
    c.r[6] <<= 2;  // 060780BA shll2 r6
    c.r[0] = c.r[3];  // 060780BC mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 060780BE mov.l @(r0,r7),r1
    c.r[2] = ld32(0x060781D0u);  // 060780C0 mov.l 0x060781D0,r2
    c.r[1] &= c.r[2];  // 060780C2 and r2,r1
    c.r[6] |= c.r[1];  // 060780C4 or r1,r6
    st32(c.r[0] + c.r[7], c.r[6]); goto L_060782AC;  // 060780C6 bra 0x060782AC ; mov.l r6,@(r0,r7)
L_060780CA:
    c.r[1] = ld32(0x060781C4u);  // 060780CA mov.l 0x060781C4,r1
    c.r[2] = ld32(c.r[1]);  // 060780CC mov.l @r1,r2
    c.r[1] = ld32(0x060781C8u);  // 060780CE mov.l 0x060781C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060780D0 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060780D2 extu.b r1,r3
    c.r[1] = ld32(0x060781CCu);  // 060780D4 mov.l 0x060781CC,r1
    c.r[0] = c.r[3];  // 060780D6 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060780D8 mov.b @(r0,r1),r1
    c.r[7] = 0x3u;  // 060780DA mov #3,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607818Eu);  // 060780DC mov.w 0x0607818E,r3
    c.r[7] &= c.r[1];  // 060780DE and r1,r7
    c.r[0] = c.r[2];  // 060780E0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060780E2 mov.b @(r0,r3),r1
    c.r[7] <<= 2;  // 060780E4 shll2 r7
    c.r[7] += c.r[7];  // 060780E6 add r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078190u);  // 060780E8 mov.w 0x06078190,r0
L_060780EA:
    c.r[1] &= c.r[0];  // 060780EA and r0,r1
    c.r[1] |= c.r[7];  // 060780EC or r7,r1
    c.r[0] = c.r[2];  // 060780EE mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]); goto L_060782AC;  // 060780F0 bra 0x060782AC ; mov.b r1,@(r0,r3)
L_060780F4:
    c.r[1] = ld32(0x060781C4u);  // 060780F4 mov.l 0x060781C4,r1
    c.r[2] = ld32(c.r[1]);  // 060780F6 mov.l @r1,r2
    c.r[1] = ld32(0x060781C8u);  // 060780F8 mov.l 0x060781C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060780FA mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060780FC extu.b r1,r3
    c.r[1] = ld32(0x060781CCu);  // 060780FE mov.l 0x060781CC,r1
    c.r[0] = c.r[3];  // 06078100 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078102 mov.b @(r0,r1),r1
    c.r[7] = 0x3u;  // 06078104 mov #3,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607818Eu);  // 06078106 mov.w 0x0607818E,r3
    c.r[7] &= c.r[1];  // 06078108 and r1,r7
    c.r[0] = c.r[2];  // 0607810A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607810C mov.b @(r0,r3),r1
    c.r[7] += c.r[7];  // 0607810E add r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078192u);  // 06078110 mov.w 0x06078192,r0
    c.r[1] &= c.r[0];  // 06078112 and r0,r1
    c.r[1] |= c.r[7];  // 06078114 or r7,r1
    c.r[0] = c.r[2];  // 06078116 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]); goto L_060782A6;  // 06078118 bra 0x060782A6 ; mov.b r1,@(r0,r3)
L_0607811C:
    c.r[1] = ld32(0x060781C4u);  // 0607811C mov.l 0x060781C4,r1
    c.r[2] = ld32(c.r[1]);  // 0607811E mov.l @r1,r2
    c.r[1] = ld32(0x060781C8u);  // 06078120 mov.l 0x060781C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078122 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06078124 extu.b r1,r3
    c.r[1] = ld32(0x060781CCu);  // 06078126 mov.l 0x060781CC,r1
    c.r[0] = c.r[3];  // 06078128 mov r3,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607812A mov.b @(r0,r1),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607818Eu);  // 0607812C mov.w 0x0607818E,r1
    c.r[0] = 0x1u;  // 0607812E mov #1,r0
    c.r[3] &= c.r[0];  // 06078130 and r0,r3
    c.r[0] = c.r[2];  // 06078132 mov r2,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078134 mov.b @(r0,r1),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078194u);  // 06078136 mov.w 0x06078194,r0
    c.r[7] &= c.r[0];  // 06078138 and r0,r7
    c.r[7] |= c.r[3];  // 0607813A or r3,r7
    c.r[0] = c.r[2];  // 0607813C mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]); goto L_060782AC;  // 0607813E bra 0x060782AC ; mov.b r7,@(r0,r1)
L_06078142:
    c.r[7] = ld32(0x060781ACu);  // 06078142 mov.l 0x060781AC,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06078144 mov.b @r7,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06078146 extu.b r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06078148 tst r2,r2
    if (!c.t) { goto L_06078150; }  // 0607814A bf 0x06078150
    goto L_060782AC;  // 0607814C bra 0x060782AC ; nop
L_06078150:
    c.r[1] = ld32(0x060781C0u);  // 06078150 mov.l 0x060781C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078152 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078154 extu.b r1,r1
    c.r[1] -= 1;  // 06078156 add #-1,r1
    c.t = c.r[2] == c.r[1];  // 06078158 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_06078168; } }  // 0607815A bf/s 0x06078168 ; mov r12,r1
    c.r[1] += 4;  // 0607815E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078160 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078162 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078164 tst r1,r1
    if (!c.t) { goto L_0607816E; }  // 06078166 bf 0x0607816E
L_06078168:
    c.r[1] = c.r[3];  // 06078168 mov r3,r1
    c.r[1] -= 1;  // 0607816A add #-1,r1
    st8(c.r[7], c.r[1]);  // 0607816C mov.b r1,@r7
L_0607816E:
    c.r[1] = ld32(0x060781ACu);  // 0607816E mov.l 0x060781AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078170 mov.b @r1,r1
    c.r[2] = 0xBu;  // 06078172 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06078174 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06078176 cmp/hi r2,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_060781D4; } }  // 06078178 bt/s 0x060781D4 ; mov #0,r6
    c.r[1] = ld32(0x060781B8u);  // 0607817C mov.l 0x060781B8,r1
    c.r[5] = c.r[11];  // 0607817E mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06078184u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078184u) return; }  // 06078180 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14]; goto L_060782AE;  // 06078184 bra 0x060782AE ; mov r14,r15
L_060781D4:
    c.r[1] = ld32(0x060782D4u);  // 060781D4 mov.l 0x060782D4,r1
    c.r[5] = c.r[12];  // 060781D6 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060781DCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060781DCu) return; }  // 060781D8 jsr @r1 ; mov #1,r4
    c.r[15] = c.r[14]; goto L_060782AE;  // 060781DC bra 0x060782AE ; mov r14,r15
L_060781E0:
    c.r[3] += 1;  // 060781E0 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060781E2 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060781E4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060781E6 tst r1,r1
    if (c.t) { goto L_0607823C; }  // 060781E8 bt 0x0607823C
    c.r[1] = ld32(0x060782D8u);  // 060781EA mov.l 0x060782D8,r1
    c.r[3] = ld32(c.r[1]);  // 060781EC mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060782C2u);  // 060781EE mov.w 0x060782C2,r1
    c.r[0] = c.r[3];  // 060781F0 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060781F2 mov.b @(r0,r1),r1
    c.r[7] = c.r[1];  // 060781F4 mov r1,r7
    c.r[7] >>= 2;  // 060781F6 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060781F8 shlr r7
    c.r[0] = 0x8u;  // 060781FA mov #8,r0
    c.r[7] &= c.r[0];  // 060781FC and r0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x060782C4u);  // 060781FE mov.w 0x060782C4,r1
    c.r[7] += c.r[1];  // 06078200 add r1,r7
    c.r[1] = ld32(0x060782DCu);  // 06078202 mov.l 0x060782DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078204 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06078206 extu.b r1,r2
    c.r[1] = ld32(0x060782E0u);  // 06078208 mov.l 0x060782E0,r1
    c.r[0] = c.r[2];  // 0607820A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607820C mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607820E extu.b r1,r2
    c.r[1] = 0x1u;  // 06078210 mov #1,r1
    c.r[1] &= c.r[2];  // 06078212 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078214 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0607821E; } }  // 06078216 bt/s 0x0607821E ; mov r7,r1
    c.r[1] -= 1; goto L_06078220;  // 0607821A bra 0x06078220 ; add #-1,r1
L_0607821E:
    c.r[1] += 1;  // 0607821E add #1,r1
L_06078220:
    c.r[1] += c.r[2];  // 06078220 add r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060782C6u);  // 06078222 mov.w 0x060782C6,r2
    c.r[0] = c.r[3];  // 06078224 mov r3,r0
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06078226 mov.w @(r0,r2),r7
    c.r[1] <<= 2;  // 06078228 shll2 r1
    c.r[1] <<= 2;  // 0607822A shll2 r1
    c.r[1] += c.r[1];  // 0607822C add r1,r1
    c.r[1] <<= 2;  // 0607822E shll2 r1
    c.r[0] = 0x7Fu;  // 06078230 mov #127,r0
    c.r[7] &= c.r[0];  // 06078232 and r0,r7
    c.r[7] |= c.r[1];  // 06078234 or r1,r7
    c.r[0] = c.r[3];  // 06078236 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[7]); goto L_060782AC;  // 06078238 bra 0x060782AC ; mov.w r7,@(r0,r2)
L_0607823C:
    c.r[1] = ld32(0x060782D8u);  // 0607823C mov.l 0x060782D8,r1
    c.r[3] = ld32(c.r[1]);  // 0607823E mov.l @r1,r3
    c.r[1] = ld32(0x060782DCu);  // 06078240 mov.l 0x060782DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078242 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06078244 extu.b r1,r0
    c.r[1] = ld32(0x060782E0u);  // 06078246 mov.l 0x060782E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078248 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607824A extu.b r1,r2
    c.r[1] = 0x1u;  // 0607824C mov #1,r1
    c.r[1] &= c.r[2];  // 0607824E and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078250 tst r1,r1
    if (c.t) { goto L_0607825A; }  // 06078252 bt 0x0607825A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060782C8u);  // 06078254 mov.w 0x060782C8,r1
    c.r[1] += c.r[2]; goto L_0607825E;  // 06078256 bra 0x0607825E ; add r2,r1
L_0607825A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060782CAu);  // 0607825A mov.w 0x060782CA,r1
    c.r[1] += c.r[2];  // 0607825C add r2,r1
L_0607825E:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060782CCu);  // 0607825E mov.w 0x060782CC,r2
    c.r[0] = c.r[3];  // 06078260 mov r3,r0
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06078262 mov.w @(r0,r2),r7
    c.r[1] <<= 2;  // 06078264 shll2 r1
    c.r[1] <<= 2;  // 06078266 shll2 r1
    c.r[1] += c.r[1];  // 06078268 add r1,r1
    c.r[1] <<= 2;  // 0607826A shll2 r1
    c.r[0] = 0x7Fu;  // 0607826C mov #127,r0
    c.r[7] &= c.r[0];  // 0607826E and r0,r7
    c.r[7] |= c.r[1];  // 06078270 or r1,r7
    c.r[0] = c.r[3];  // 06078272 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[7]);  // 06078274 mov.w r7,@(r0,r2)
    c.r[1] = ld32(0x060782D8u);  // 06078276 mov.l 0x060782D8,r1
    c.r[3] = ld32(c.r[1]);  // 06078278 mov.l @r1,r3
    c.r[1] = ld32(0x060782DCu);  // 0607827A mov.l 0x060782DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607827C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607827E extu.b r1,r2
    c.r[1] = ld32(0x060782E0u);  // 06078280 mov.l 0x060782E0,r1
    c.r[0] = c.r[2];  // 06078282 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078284 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078286 extu.b r1,r1
    c.r[2] = 0x7u;  // 06078288 mov #7,r2
    c.t = c.r[1] > c.r[2];  // 0607828A cmp/hi r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060782CEu);  // 0607828C mov.w 0x060782CE,r2
    c.r[0] = c.t;  // 0607828E movt r0
    c.r[1] = c.r[0];  // 06078290 mov r0,r1
    c.r[0] = c.r[3];  // 06078292 mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078294 mov.b @(r0,r2),r7
    c.r[1] <<= 2;  // 06078296 shll2 r1
    c.r[1] <<= 2;  // 06078298 shll2 r1
    c.r[1] <<= 2;  // 0607829A shll2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060782D0u);  // 0607829C mov.w 0x060782D0,r0
    c.r[7] &= c.r[0];  // 0607829E and r0,r7
    c.r[7] |= c.r[1];  // 060782A0 or r1,r7
    c.r[0] = c.r[3];  // 060782A2 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 060782A4 mov.b r7,@(r0,r2)
L_060782A6:
    c.r[0] = ld32(0x060782E4u);  // 060782A6 mov.l 0x060782E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060782ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060782ACu) return; }  // 060782A8 jsr @r0 ; nop
L_060782AC:
    c.r[15] = c.r[14];  // 060782AC mov r14,r15
L_060782AE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060782AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060782B0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060782B2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060782B4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060782B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060782B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060782BA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060782D2u);  // 060782BC mov.w 0x060782D2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060782BE rts ; mov.l @r15+,r8
}

void f_060782E8(SH2Context& c) {
    ran[1658] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060782E8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060782EA mov r15,r14
    c.r[0] = c.r[4] & 0xFFu;  // 060782EC extu.b r4,r0
    c.t = c.r[0] == 0x1u;  // 060782EE cmp/eq #1,r0
    { const bool k = c.t; c.r[6] = c.r[6] & 0xFFu; if (k) { goto L_060782FC; } }  // 060782F0 bt/s 0x060782FC ; extu.b r6,r6
    c.t = c.r[0] == 0x2u;  // 060782F4 cmp/eq #2,r0
    if (!c.t) { goto L_0607832E; }  // 060782F6 bf 0x0607832E
    goto L_06078324;  // 060782F8 bra 0x06078324 ; nop
L_060782FC:
    c.r[4] = ld32(0x0607834Cu);  // 060782FC mov.l 0x0607834C,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060782FE mov.b @r4,r1
    c.r[7] = 0xFFFFFFFFu;  // 06078300 mov #-1,r7
    c.r[3] = c.r[1] & 0xFFu;  // 06078302 extu.b r1,r3
    c.r[3] += c.r[5];  // 06078304 add r5,r3
    c.r[1] = c.r[3];  // 06078306 mov r3,r1
    c.r[1] -= 12;  // 06078308 add #-12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607830A mov.b @r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0607830C extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607830E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06078310 cmp/eq r2,r1
    { const bool k = !c.t; c.r[3] -= 11; if (k) { goto L_06078318; } }  // 06078312 bf/s 0x06078318 ; add #-11,r3
    st8(c.r[3], c.r[7]);  // 06078316 mov.b r7,@r3
L_06078318:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06078318 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607831A extu.b r1,r1
    c.r[1] += c.r[5];  // 0607831C add r5,r1
    c.r[1] -= 12;  // 0607831E add #-12,r1
    st8(c.r[1], c.r[6]); goto L_06078344;  // 06078320 bra 0x06078344 ; mov.b r6,@r1
L_06078324:
    c.r[1] = ld32(0x0607834Cu);  // 06078324 mov.l 0x0607834C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078326 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06078328 extu.b r1,r0
    st8(c.r[0] + c.r[5], c.r[6]); goto L_06078344;  // 0607832A bra 0x06078344 ; mov.b r6,@(r0,r5)
L_0607832E:
    c.r[1] = ld32(0x0607834Cu);  // 0607832E mov.l 0x0607834C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078330 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06078332 extu.b r1,r0
    c.r[1] = 0x5u;  // 06078334 mov #5,r1
    c.t = c.r[0] > c.r[1];  // 06078336 cmp/hi r1,r0
    if (c.t) { goto L_06078340; }  // 06078338 bt 0x06078340
    c.r[1] = ld32(0x06078350u);  // 0607833A mov.l 0x06078350,r1
    st8(c.r[0] + c.r[1], c.r[6]); goto L_06078344;  // 0607833C bra 0x06078344 ; mov.b r6,@(r0,r1)
L_06078340:
    c.r[1] = ld32(0x06078354u);  // 06078340 mov.l 0x06078354,r1
    st8(c.r[0] + c.r[1], c.r[6]);  // 06078342 mov.b r6,@(r0,r1)
L_06078344:
    c.r[15] = c.r[14];  // 06078344 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06078346 rts ; mov.l @r15+,r14
}

void f_06078358(SH2Context& c) {
    ran[1659] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06078358 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607835A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607835C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607835E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06078360 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06078362 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06078364 sts.l pr,@-r15
    c.r[15] -= 32;  // 06078366 add #-32,r15
    c.r[14] = c.r[15];  // 06078368 mov r15,r14
    c.r[9] = c.r[5];  // 0607836A mov r5,r9
    c.r[8] = 0x1u;  // 0607836C mov #1,r8
    c.r[6] = c.r[14];  // 0607836E mov r14,r6
    c.r[6] += 7;  // 06078370 add #7,r6
    c.r[1] = ld32(0x06078488u);  // 06078372 mov.l 0x06078488,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06078378u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078378u) return; }  // 06078374 jsr @r1 ; mov r14,r5
    c.r[11] = 0x0u;  // 06078378 mov #0,r11
    c.r[0] = c.r[9];  // 0607837A mov r9,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0607837C mov.b @(r0,r11),r2
    c.r[1] = c.r[2] & 0xFFu;  // 0607837E extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078380 tst r1,r1
    { const bool k = !c.t; c.r[7] = 0x5u; if (k) { goto L_060783A0; } }  // 06078382 bf/s 0x060783A0 ; mov #5,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078482u);  // 06078386 mov.w 0x06078482,r3
    c.r[1] = c.r[2] & 0xFFu;  // 06078388 extu.b r2,r1
    c.t = c.r[1] == c.r[3];  // 0607838A cmp/eq r3,r1
L_0607838C:
    if (c.t) { goto L_060783A0; }  // 0607838C bt 0x060783A0
    c.r[11] += 1;  // 0607838E add #1,r11
    c.t = (int32_t)c.r[11] > (int32_t)c.r[7];  // 06078390 cmp/gt r7,r11
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_060783A0; } }  // 06078392 bt/s 0x060783A0 ; mov r9,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06078396 mov.b @(r0,r11),r2
    c.r[1] = c.r[2] & 0xFFu;  // 06078398 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607839A tst r1,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[3]; if (k) { SH2_POLL(c); goto L_0607838C; } }  // 0607839C bt/s 0x0607838C ; cmp/eq r3,r1
L_060783A0:
    c.r[0] = c.r[11];  // 060783A0 mov r11,r0
    c.t = c.r[0] == 0x6u;  // 060783A2 cmp/eq #6,r0
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_060783B4; } }  // 060783A4 bt/s 0x060783B4 ; mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060783A8 mov.b @(r0,r11),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078482u);  // 060783AA mov.w 0x06078482,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060783AC extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060783AE cmp/eq r2,r1
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060783B8; } }  // 060783B0 bf/s 0x060783B8 ; tst r8,r8
L_060783B4:
    c.r[8] = 0x0u;  // 060783B4 mov #0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060783B6 tst r8,r8
L_060783B8:
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0607842C; } }  // 060783B8 bt/s 0x0607842C ; tst r8,r8
    c.r[11] = 0x0u;  // 060783BC mov #0,r11
    c.r[0] = c.r[14];  // 060783BE mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060783C0 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060783C2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060783C4 tst r1,r1
    if (!c.t) { goto L_060783E8; }  // 060783C6 bf 0x060783E8
    c.r[11] = 0x1u;  // 060783C8 mov #1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060783CA mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060783CC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060783CE tst r1,r1
    if (!c.t) { goto L_060783E8; }  // 060783D0 bf 0x060783E8
    c.r[2] = 0x5u;  // 060783D2 mov #5,r2
    c.r[11] += 1;  // 060783D4 add #1,r11
L_060783D6:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[2];  // 060783D6 cmp/gt r2,r11
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_060783E8; } }  // 060783D8 bt/s 0x060783E8 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060783DC mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060783DE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060783E0 tst r1,r1
    { const bool k = c.t; c.r[11] += 1; if (k) { SH2_POLL(c); goto L_060783D6; } }  // 060783E2 bt/s 0x060783D6 ; add #1,r11
    c.r[11] -= 1;  // 060783E6 add #-1,r11
L_060783E8:
    c.r[0] = c.r[11];  // 060783E8 mov r11,r0
    c.t = c.r[0] == 0x6u;  // 060783EA cmp/eq #6,r0
    if (c.t) { goto L_06078428; }  // 060783EC bt 0x06078428
    c.r[2] = c.r[14];  // 060783EE mov r14,r2
    c.r[2] += 7;  // 060783F0 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060783F2 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060783F4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060783F6 tst r1,r1
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_06078420; } }  // 060783F8 bf/s 0x06078420 ; mov #0,r11
    c.r[1] = c.r[14];  // 060783FC mov r14,r1
    c.r[1] += 8;  // 060783FE add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078400 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078402 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078404 tst r1,r1
    { const bool k = !c.t; c.r[11] = 0x1u; if (k) { goto L_06078420; } }  // 06078406 bf/s 0x06078420 ; mov #1,r11
    c.r[3] = 0x5u;  // 0607840A mov #5,r3
    c.r[11] += 1;  // 0607840C add #1,r11
L_0607840E:
    c.t = (int32_t)c.r[11] > (int32_t)c.r[3];  // 0607840E cmp/gt r3,r11
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06078420; } }  // 06078410 bt/s 0x06078420 ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06078414 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078416 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078418 tst r1,r1
    { const bool k = c.t; c.r[11] += 1; if (k) { SH2_POLL(c); goto L_0607840E; } }  // 0607841A bt/s 0x0607840E ; add #1,r11
    c.r[11] -= 1;  // 0607841E add #-1,r11
L_06078420:
    c.r[0] = c.r[11];  // 06078420 mov r11,r0
    c.t = c.r[0] == 0x6u;  // 06078422 cmp/eq #6,r0
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0607842C; } }  // 06078424 bf/s 0x0607842C ; tst r8,r8
L_06078428:
    c.r[8] = 0x0u;  // 06078428 mov #0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0607842A tst r8,r8
L_0607842C:
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_06078434; } }  // 0607842C bf/s 0x06078434 ; mov #0,r11
    goto L_06078644;  // 06078430 bra 0x06078644 ; nop
L_06078434:
    c.r[12] = c.r[14];  // 06078434 mov r14,r12
    c.r[12] += 16;  // 06078436 add #16,r12
L_06078438:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078484u);  // 06078438 mov.w 0x06078484,r2
    c.r[2] += c.r[11];  // 0607843A add r11,r2
    c.r[1] = 0x11u;  // 0607843C mov #17,r1
    c.t = c.r[2] > c.r[1];  // 0607843E cmp/hi r1,r2
    { const bool k = c.t; c.r[10] = c.r[14]; if (k) { goto L_06078448; } }  // 06078440 bt/s 0x06078448 ; mov r14,r10
    goto L_06078630;  // 06078444 bra 0x06078630 ; nop
L_06078448:
    c.r[10] += 23;  // 06078448 add #23,r10
    c.r[9] = c.r[11] & 0xFFFFu;  // 0607844A extu.w r11,r9
    c.r[8] = ld32(0x0607848Cu);  // 0607844C mov.l 0x0607848C,r8
    c.r[4] = ld32(0x06078490u);  // 0607844E mov.l 0x06078490,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06078454u; c.r[5] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078454u) return; }  // 06078450 jsr @r8 ; mov #12,r5
    c.r[1] = c.r[0];  // 06078454 mov r0,r1
    c.r[5] = c.r[9];  // 06078456 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607845Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607845Cu) return; }  // 06078458 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0607845C mov r0,r2
    c.r[1] = ld32(0x06078488u);  // 0607845E mov.l 0x06078488,r1
    c.r[6] = c.r[10];  // 06078460 mov r10,r6
    c.r[5] = c.r[12];  // 06078462 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06078468u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078468u) return; }  // 06078464 jsr @r1 ; mov r2,r4
    c.r[5] = c.r[14];  // 06078468 mov r14,r5
    c.r[6] = c.r[12];  // 0607846A mov r12,r6
    c.r[7] = 0x6u;  // 0607846C mov #6,r7
    c.r[3] = 0x0u;  // 0607846E mov #0,r3
    c.r[0] = c.r[5];  // 06078470 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078472 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078474 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078476 tst r1,r1
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_060784AA; } }  // 06078478 bf/s 0x060784AA ; mov #0,r4
    c.r[3] = 0x1u;  // 0607847C mov #1,r3
    c.r[0] = c.r[14]; goto L_06078494;  // 0607847E bra 0x06078494 ; mov r14,r0
L_06078494:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_060784A0;  // 06078494 bra 0x060784A0 ; mov.b @(r0,r3),r1
L_06078498:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06078498 cmp/ge r7,r3
    if (c.t) { goto L_060784AA; }  // 0607849A bt 0x060784AA
    c.r[0] = c.r[5];  // 0607849C mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607849E mov.b @(r0,r3),r1
L_060784A0:
    c.r[1] = c.r[1] & 0xFFu;  // 060784A0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060784A2 tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_06078498; } }  // 060784A4 bt/s 0x06078498 ; add #1,r3
    c.r[3] -= 1;  // 060784A8 add #-1,r3
L_060784AA:
    c.r[8] = 0x0u;  // 060784AA mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 060784AC cmp/ge r7,r8
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= (int32_t)c.r[7]; if (k) { goto L_060784F2; } }  // 060784AE bt/s 0x060784F2 ; cmp/ge r7,r3
    c.r[0] = c.r[6];  // 060784B2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060784B4 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060784B6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060784B8 tst r1,r1
    if (!c.t) { goto L_060784F0; }  // 060784BA bf 0x060784F0
    c.r[8] = 0x1u;  // 060784BC mov #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 060784BE cmp/ge r7,r8
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= (int32_t)c.r[7]; if (k) { goto L_060784F2; } }  // 060784C0 bt/s 0x060784F2 ; cmp/ge r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]); goto L_060784D0;  // 060784C4 bra 0x060784D0 ; mov.b @(r0,r8),r1
L_060784C8:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 060784C8 cmp/ge r7,r8
    if (c.t) { goto L_060784F0; }  // 060784CA bt 0x060784F0
    c.r[0] = c.r[6];  // 060784CC mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060784CE mov.b @(r0,r8),r1
L_060784D0:
    c.r[1] = c.r[1] & 0xFFu;  // 060784D0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060784D2 tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { SH2_POLL(c); goto L_060784C8; } }  // 060784D4 bt/s 0x060784C8 ; add #1,r8
    c.r[8] -= 1;  // 060784D8 add #-1,r8
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7]; goto L_060784F2;  // 060784DA bra 0x060784F2 ; cmp/ge r7,r3
L_060784DE:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060784DE mov.b @(r0,r3),r2
    c.r[0] = c.r[6];  // 060784E0 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060784E2 mov.b @(r0,r8),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060784E4 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060784E6 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060784E8 cmp/eq r1,r2
    if (!c.t) { goto L_060784FA; }  // 060784EA bf 0x060784FA
    c.r[3] += 1;  // 060784EC add #1,r3
    c.r[8] += 1;  // 060784EE add #1,r8
L_060784F0:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 060784F0 cmp/ge r7,r3
L_060784F2:
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[7]; if (k) { goto L_060784FA; } }  // 060784F2 bt/s 0x060784FA ; cmp/ge r7,r8
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { SH2_POLL(c); goto L_060784DE; } }  // 060784F6 bf/s 0x060784DE ; mov r5,r0
L_060784FA:
    c.r[0] = c.r[3];  // 060784FA mov r3,r0
    c.t = c.r[0] == 0x6u;  // 060784FC cmp/eq #6,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0607850A; } }  // 060784FE bt/s 0x0607850A ; mov r8,r0
    c.t = c.r[0] == 0x6u;  // 06078502 cmp/eq #6,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0607854C; } }  // 06078504 bf/s 0x0607854C ; mov r3,r0
    c.t = c.r[0] == 0x6u;  // 06078508 cmp/eq #6,r0
L_0607850A:
    if (!c.t) { goto L_06078514; }  // 0607850A bf 0x06078514
    c.r[3] = c.r[8];  // 0607850C mov r8,r3
    c.r[2] = c.r[14];  // 0607850E mov r14,r2
    c.r[2] += 16; goto L_06078516;  // 06078510 bra 0x06078516 ; add #16,r2
L_06078514:
    c.r[2] = c.r[5];  // 06078514 mov r5,r2
L_06078516:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06078516 cmp/ge r7,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06078546; } }  // 06078518 bt/s 0x06078546 ; mov r3,r0
    c.r[0] = c.r[2];  // 0607851C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607851E mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078520 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078522 tst r1,r1
    if (!c.t) { goto L_06078544; }  // 06078524 bf 0x06078544
    c.r[3] += 1;  // 06078526 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06078528 cmp/ge r7,r3
    if (c.t) { goto L_06078544; }  // 0607852A bt 0x06078544
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607852C mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu; goto L_0607853C;  // 0607852E bra 0x0607853C ; extu.b r1,r1
L_06078532:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06078532 cmp/ge r7,r3
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06078544; } }  // 06078534 bt/s 0x06078544 ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078538 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607853A extu.b r1,r1
L_0607853C:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607853C tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_06078532; } }  // 0607853E bt/s 0x06078532 ; add #1,r3
    c.r[3] -= 1;  // 06078542 add #-1,r3
L_06078544:
    c.r[0] = c.r[3];  // 06078544 mov r3,r0
L_06078546:
    c.t = c.r[0] == 0x6u;  // 06078546 cmp/eq #6,r0
    if (!c.t) { goto L_0607854C; }  // 06078548 bf 0x0607854C
    c.r[4] = 0x1u;  // 0607854A mov #1,r4
L_0607854C:
    c.r[8] = c.r[4] & 0xFFu;  // 0607854C extu.b r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0607854E tst r8,r8
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_06078630; } }  // 06078550 bt/s 0x06078630 ; mov r14,r5
    c.r[5] += 7;  // 06078554 add #7,r5
    c.r[6] = c.r[14];  // 06078556 mov r14,r6
    c.r[6] += 23;  // 06078558 add #23,r6
    c.r[7] = 0x6u;  // 0607855A mov #6,r7
    c.r[3] = 0x0u;  // 0607855C mov #0,r3
    c.r[0] = c.r[5];  // 0607855E mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078560 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078562 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078564 tst r1,r1
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06078580; } }  // 06078566 bf/s 0x06078580 ; mov #0,r4
    c.r[3] = 0x1u; goto L_06078574;  // 0607856A bra 0x06078574 ; mov #1,r3
L_0607856E:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 0607856E cmp/ge r7,r3
    if (c.t) { goto L_06078580; }  // 06078570 bt 0x06078580
    c.r[0] = c.r[5];  // 06078572 mov r5,r0
L_06078574:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078574 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078576 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078578 tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_0607856E; } }  // 0607857A bt/s 0x0607856E ; add #1,r3
    c.r[3] -= 1;  // 0607857E add #-1,r3
L_06078580:
    c.r[8] = 0x0u;  // 06078580 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 06078582 cmp/ge r7,r8
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= (int32_t)c.r[7]; if (k) { goto L_060785C8; } }  // 06078584 bt/s 0x060785C8 ; cmp/ge r7,r3
    c.r[0] = c.r[6];  // 06078588 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0607858A mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607858C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607858E tst r1,r1
    if (!c.t) { goto L_060785C6; }  // 06078590 bf 0x060785C6
    c.r[8] = 0x1u;  // 06078592 mov #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 06078594 cmp/ge r7,r8
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= (int32_t)c.r[7]; if (k) { goto L_060785C8; } }  // 06078596 bt/s 0x060785C8 ; cmp/ge r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]); goto L_060785A6;  // 0607859A bra 0x060785A6 ; mov.b @(r0,r8),r1
L_0607859E:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 0607859E cmp/ge r7,r8
    if (c.t) { goto L_060785C6; }  // 060785A0 bt 0x060785C6
    c.r[0] = c.r[6];  // 060785A2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060785A4 mov.b @(r0,r8),r1
L_060785A6:
    c.r[1] = c.r[1] & 0xFFu;  // 060785A6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060785A8 tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { SH2_POLL(c); goto L_0607859E; } }  // 060785AA bt/s 0x0607859E ; add #1,r8
    c.r[8] -= 1;  // 060785AE add #-1,r8
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7]; goto L_060785C8;  // 060785B0 bra 0x060785C8 ; cmp/ge r7,r3
L_060785B4:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060785B4 mov.b @(r0,r3),r2
    c.r[0] = c.r[6];  // 060785B6 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060785B8 mov.b @(r0,r8),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060785BA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060785BC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060785BE cmp/eq r1,r2
    if (!c.t) { goto L_060785D0; }  // 060785C0 bf 0x060785D0
    c.r[3] += 1;  // 060785C2 add #1,r3
    c.r[8] += 1;  // 060785C4 add #1,r8
L_060785C6:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 060785C6 cmp/ge r7,r3
L_060785C8:
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[7]; if (k) { goto L_060785D0; } }  // 060785C8 bt/s 0x060785D0 ; cmp/ge r7,r8
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { SH2_POLL(c); goto L_060785B4; } }  // 060785CC bf/s 0x060785B4 ; mov r5,r0
L_060785D0:
    c.r[0] = c.r[3];  // 060785D0 mov r3,r0
    c.t = c.r[0] == 0x6u;  // 060785D2 cmp/eq #6,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060785E0; } }  // 060785D4 bt/s 0x060785E0 ; mov r8,r0
    c.t = c.r[0] == 0x6u;  // 060785D8 cmp/eq #6,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06078624; } }  // 060785DA bf/s 0x06078624 ; mov r3,r0
    c.t = c.r[0] == 0x6u;  // 060785DE cmp/eq #6,r0
L_060785E0:
    if (!c.t) { goto L_060785EA; }  // 060785E0 bf 0x060785EA
    c.r[3] = c.r[8];  // 060785E2 mov r8,r3
    c.r[2] = c.r[14];  // 060785E4 mov r14,r2
    c.r[2] += 23; goto L_060785EE;  // 060785E6 bra 0x060785EE ; add #23,r2
L_060785EA:
    c.r[2] = c.r[14];  // 060785EA mov r14,r2
    c.r[2] += 7;  // 060785EC add #7,r2
L_060785EE:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 060785EE cmp/ge r7,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0607861E; } }  // 060785F0 bt/s 0x0607861E ; mov r3,r0
    c.r[0] = c.r[2];  // 060785F4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060785F6 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060785F8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060785FA tst r1,r1
    if (!c.t) { goto L_0607861C; }  // 060785FC bf 0x0607861C
    c.r[3] += 1;  // 060785FE add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06078600 cmp/ge r7,r3
    if (c.t) { goto L_0607861C; }  // 06078602 bt 0x0607861C
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078604 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06078614;  // 06078606 bra 0x06078614 ; extu.b r1,r1
L_0607860A:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 0607860A cmp/ge r7,r3
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0607861C; } }  // 0607860C bt/s 0x0607861C ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078610 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078612 extu.b r1,r1
L_06078614:
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078614 tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_0607860A; } }  // 06078616 bt/s 0x0607860A ; add #1,r3
    c.r[3] -= 1;  // 0607861A add #-1,r3
L_0607861C:
    c.r[0] = c.r[3];  // 0607861C mov r3,r0
L_0607861E:
    c.t = c.r[0] == 0x6u;  // 0607861E cmp/eq #6,r0
    if (!c.t) { goto L_06078624; }  // 06078620 bf 0x06078624
    c.r[4] = 0x1u;  // 06078622 mov #1,r4
L_06078624:
    c.r[8] = c.r[4] & 0xFFu;  // 06078624 extu.b r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06078626 tst r8,r8
    { const bool k = c.t; c.r[11] += 1; if (k) { goto L_06078632; } }  // 06078628 bt/s 0x06078632 ; add #1,r11
    c.r[8] = 0x0u;  // 0607862C mov #0,r8
    c.r[11] = (uint32_t)(int16_t)ld16(0x0607865Au);  // 0607862E mov.w 0x0607865A,r11
L_06078630:
    c.r[11] += 1;  // 06078630 add #1,r11
L_06078632:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607865Cu);  // 06078632 mov.w 0x0607865C,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06078634 cmp/gt r1,r11
    if (c.t) { goto L_0607863C; }  // 06078636 bt 0x0607863C
    SH2_POLL(c); goto L_06078438;  // 06078638 bra 0x06078438 ; nop
L_0607863C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607865Eu);  // 0607863C mov.w 0x0607865E,r1
    c.t = c.r[11] == c.r[1];  // 0607863E cmp/eq r1,r11
    if (!c.t) { goto L_06078644; }  // 06078640 bf 0x06078644
    c.r[8] = 0x1u;  // 06078642 mov #1,r8
L_06078644:
    c.r[14] += 32;  // 06078644 add #32,r14
    c.r[15] = c.r[14];  // 06078646 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06078648 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607864A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607864C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607864E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06078650 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06078652 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06078654 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06078656 rts ; mov.l @r15+,r8
}

void f_06078660(SH2Context& c) {
    ran[1660] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06078660 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06078662 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06078664 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06078666 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06078668 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607866A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607866C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607866E sts.l pr,@-r15
    c.r[15] -= 16;  // 06078670 add #-16,r15
    c.r[14] = c.r[15];  // 06078672 mov r15,r14
    c.r[0] = 0x0u;  // 06078674 mov #0,r0
    st32(c.r[14] + 12, c.r[0]);  // 06078676 mov.l r0,@(12,r14)
    c.r[1] = ld32(0x06078738u);  // 06078678 mov.l 0x06078738,r1
    c.r[10] = ld32(0x0607873Cu);  // 0607867A mov.l 0x0607873C,r10
    c.r[2] = ld32(c.r[1]);  // 0607867C mov.l @r1,r2
    c.r[5] = 0xBu;  // 0607867E mov #11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078732u);  // 06078680 mov.w 0x06078732,r1
    c.r[0] = c.r[2];  // 06078682 mov r2,r0
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078684 mov.b @(r0,r1),r13
    c.r[4] = ld32(0x06078740u);  // 06078686 mov.l 0x06078740,r4
    c.r[13] >>= 2;  // 06078688 shlr2 r13
    c.r[0] = 0x1u;  // 0607868A mov #1,r0
    c.r[13] &= c.r[0];  // 0607868C and r0,r13
    c.r[1] = ld32(0x06078744u);  // 0607868E mov.l 0x06078744,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078734u);  // 06078690 mov.w 0x06078734,r2
    c.r[8] = c.r[13];  // 06078692 mov r13,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078694 mov.b @r1,r1
    c.r[8] += c.r[2];  // 06078696 add r2,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06078698 extu.b r1,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0607869Eu; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607869Eu) return; }  // 0607869A jsr @r10 ; add r1,r8
    c.r[1] = c.r[0];  // 0607869E mov r0,r1
    c.r[5] = c.r[8];  // 060786A0 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060786A6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060786A6u) return; }  // 060786A2 jsr @r10 ; mov r1,r4
    c.r[1] = ld32(0x06078748u);  // 060786A6 mov.l 0x06078748,r1
    c.r[1] = ld32(c.r[1]);  // 060786A8 mov.l @r1,r1
    c.r[1] += 1;  // 060786AA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060786AC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060786AE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060786B0 tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { goto L_060786C6; } }  // 060786B2 bt/s 0x060786C6 ; mov r0,r8
    c.r[0] = c.r[1];  // 060786B6 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060786B8 cmp/eq #1,r0
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_060786C2; } }  // 060786BA bf/s 0x060786C2 ; mov #0,r12
    goto L_06078A14;  // 060786BE bra 0x06078A14 ; nop
L_060786C2:
    c.t = (c.r[13] & c.r[13]) == 0; goto L_06078A60;  // 060786C2 bra 0x06078A60 ; tst r13,r13
L_060786C6:
    c.r[11] = ld32(0x0607874Cu);  // 060786C6 mov.l 0x0607874C,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060786C8 mov.b @r11,r1
    c.r[12] = ld32(0x06078750u);  // 060786CA mov.l 0x06078750,r12
    c.r[0] = c.r[1] & 0xFFu;  // 060786CC extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060786CE mov.b @(r0,r12),r1
    c.r[3] = c.r[1] & 0xFFu;  // 060786D0 extu.b r1,r3
    c.r[1] = 0x4u;  // 060786D2 mov #4,r1
    c.r[2] = c.r[3];  // 060786D4 mov r3,r2
    c.r[2] -= 121;  // 060786D6 add #-121,r2
    c.t = c.r[2] > c.r[1];  // 060786D8 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = 0x50u; if (k) { goto L_060786E2; } }  // 060786DA bf/s 0x060786E2 ; mov #80,r1
    goto L_06078986;  // 060786DE bra 0x06078986 ; nop
L_060786E2:
    c.r[1] = c.r[2];  // 060786E2 mov r2,r1
    c.r[1] += c.r[1];  // 060786E4 add r1,r1
    c.r[0] = 0x060786F0u;  // 060786E6 mova 0x060786F0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060786E8 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060786EA add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060786FAu: goto L_060786FA; case 0x06078710u: goto L_06078710; case 0x060789E6u: goto L_060789E6; case 0x06078726u: goto L_06078726; case 0x0607875Cu: goto L_0607875C; default: sh2_call(c, x); return; } }  // 060786EC jmp @r0 ; nop
L_060786FA:
    c.r[2] = ld32(0x06078754u);  // 060786FA mov.l 0x06078754,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060786FC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060786FE extu.b r1,r1
    c.r[1] -= 1;  // 06078700 add #-1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06078702 cmp/pz r1
    if (!c.t) { goto L_0607870A; }  // 06078704 bf 0x0607870A
    goto L_060789EC;  // 06078706 bra 0x060789EC ; nop
L_0607870A:
    c.r[1] = 0u - c.r[1];  // 0607870A neg r1,r1
    st8(c.r[2], c.r[1]); goto L_060789EE;  // 0607870C bra 0x060789EE ; mov.b r1,@r2
L_06078710:
    c.r[3] = ld32(0x06078758u);  // 06078710 mov.l 0x06078758,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06078712 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06078714 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078716 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06078720; } }  // 06078718 bf/s 0x06078720 ; mov r2,r1
    goto L_060789EE;  // 0607871C bra 0x060789EE ; nop
L_06078720:
    c.r[1] -= 1;  // 06078720 add #-1,r1
    st8(c.r[3], c.r[1]); goto L_060789EE;  // 06078722 bra 0x060789EE ; mov.b r1,@r3
L_06078726:
    c.r[2] = ld32(0x06078758u);  // 06078726 mov.l 0x06078758,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06078728 mov.b @r2,r1
    c.r[3] = 0x0u;  // 0607872A mov #0,r3
    c.r[0] = c.r[1] & 0xFFu;  // 0607872C extu.b r1,r0
    st8(c.r[0] + c.r[8], c.r[3]); goto L_060789E8;  // 0607872E bra 0x060789E8 ; mov.b r3,@(r0,r8)
L_0607875C:
    c.t = (c.r[13] & c.r[13]) == 0;  // 0607875C tst r13,r13
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_0607876C; } }  // 0607875E bf/s 0x0607876C ; mov #0,r12
    c.t = (int32_t)c.r[12] > 0;  // 06078762 cmp/pl r12
L_06078764:
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_0607876C; } }  // 06078764 bf/s 0x0607876C ; mov #3,r1
    goto L_06078978;  // 06078768 bra 0x06078978 ; nop
L_0607876C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078882u);  // 0607876C mov.w 0x06078882,r1
    c.r[8] = c.r[12];  // 0607876E mov r12,r8
    c.r[8] += c.r[1];  // 06078770 add r1,r8
    c.r[8] += c.r[13];  // 06078772 add r13,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06078774 extu.w r8,r8
    c.r[4] = ld32(0x06078888u);  // 06078776 mov.l 0x06078888,r4
    c.r[9] = ld32(0x0607888Cu);  // 06078778 mov.l 0x0607888C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0607877Eu; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607877Eu) return; }  // 0607877A jsr @r9 ; mov #11,r5
    c.r[5] = c.r[8];  // 0607877E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06078784u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078784u) return; }  // 06078780 jsr @r9 ; mov r0,r4
    c.r[8] = c.r[0];  // 06078784 mov r0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06078786 mov.b @r0+,r1
    c.r[10] = 0x9u;  // 06078788 mov #9,r10
    st8(c.r[14], c.r[1]);  // 0607878A mov.b r1,@r14
    c.r[1] = c.r[14];  // 0607878C mov r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0607878E mov.b @r0+,r2
    c.r[1] += 1;  // 06078790 add #1,r1
    st8(c.r[1], c.r[2]);  // 06078792 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06078794 mov.b @r0+,r2
    c.r[1] += 1;  // 06078796 add #1,r1
    st8(c.r[1], c.r[2]);  // 06078798 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0607879A mov.b @r0+,r2
    c.r[1] += 1;  // 0607879C add #1,r1
    st8(c.r[1], c.r[2]);  // 0607879E mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060787A0 mov.b @r0+,r2
    c.r[1] += 1;  // 060787A2 add #1,r1
    st8(c.r[1], c.r[2]);  // 060787A4 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060787A6 mov.b @r0+,r2
    c.r[1] += 1;  // 060787A8 add #1,r1
    st8(c.r[1], c.r[2]);  // 060787AA mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060787AC mov.b @r0+,r2
    c.r[1] += 1;  // 060787AE add #1,r1
    st8(c.r[1], c.r[2]);  // 060787B0 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060787B2 mov.b @r0+,r2
    c.r[1] += 1;  // 060787B4 add #1,r1
    st8(c.r[1], c.r[2]);  // 060787B6 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060787B8 mov.b @r0+,r2
    c.r[1] += 1;  // 060787BA add #1,r1
    st8(c.r[1], c.r[2]);  // 060787BC mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060787BE mov.b @r0,r2
    c.r[1] += 1;  // 060787C0 add #1,r1
    st8(c.r[1], c.r[2]);  // 060787C2 mov.b r2,@r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078884u);  // 060787C4 mov.w 0x06078884,r2
    c.r[0] = c.r[14];  // 060787C6 mov r14,r0
L_060787C8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060787C8 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060787CA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060787CC tst r1,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[2]; if (k) { goto L_060787D6; } }  // 060787CE bt/s 0x060787D6 ; cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x8u; if (k) { goto L_060787E0; } }  // 060787D2 bf/s 0x060787E0 ; mov #8,r1
L_060787D6:
    c.r[10] -= 1;  // 060787D6 add #-1,r10
    c.t = (int32_t)c.r[10] >= 0;  // 060787D8 cmp/pz r10
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_060787C8; } }  // 060787DA bt/s 0x060787C8 ; mov r14,r0
    c.r[1] = 0x8u;  // 060787DE mov #8,r1
L_060787E0:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060787E0 cmp/gt r1,r10
    { const bool k = c.t; c.r[11] = 0xAu; if (k) { goto L_060787F4; } }  // 060787E2 bt/s 0x060787F4 ; mov #10,r11
    c.r[2] = c.r[14];  // 060787E6 mov r14,r2
    c.r[2] += 1;  // 060787E8 add #1,r2
    c.r[1] = 0xFFFFFFFFu;  // 060787EA mov #-1,r1
    c.r[0] = c.r[2];  // 060787EC mov r2,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 060787EE mov.b r1,@(r0,r10)
    c.r[10] += 1;  // 060787F0 add #1,r10
    c.r[11] = c.r[10] & 0xFFu;  // 060787F2 extu.b r10,r11
L_060787F4:
    c.r[10] = 0x0u;  // 060787F4 mov #0,r10
    c.r[0] = c.r[8];  // 060787F6 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060787F8 mov.b @(r0,r10),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078884u);  // 060787FA mov.w 0x06078884,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060787FC extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060787FE cmp/eq r2,r1
    { const bool k = c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06078830; } }  // 06078800 bt/s 0x06078830 ; tst r1,r1
    if (!c.t) { goto L_06078830; }  // 06078804 bf 0x06078830
    c.r[10] = 0x1u;  // 06078806 mov #1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06078808 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607880A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0607880C cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_06078832; } }  // 0607880E bt/s 0x06078832 ; mov r10,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078812 tst r1,r1
    if (!c.t) { goto L_06078832; }  // 06078814 bf 0x06078832
    c.r[3] = 0x9u;  // 06078816 mov #9,r3
    c.r[10] += 1;  // 06078818 add #1,r10
L_0607881A:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[3];  // 0607881A cmp/gt r3,r10
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06078830; } }  // 0607881C bt/s 0x06078830 ; mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06078820 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078822 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06078824 cmp/eq r2,r1
    { const bool k = c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06078830; } }  // 06078826 bt/s 0x06078830 ; tst r1,r1
    { const bool k = c.t; c.r[10] += 1; if (k) { SH2_POLL(c); goto L_0607881A; } }  // 0607882A bt/s 0x0607881A ; add #1,r10
    c.r[10] -= 1;  // 0607882E add #-1,r10
L_06078830:
    c.r[0] = c.r[10];  // 06078830 mov r10,r0
L_06078832:
    c.t = c.r[0] == 0xAu;  // 06078832 cmp/eq #10,r0
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_0607883C; } }  // 06078834 bf/s 0x0607883C ; mov r8,r0
    goto L_0607895E;  // 06078838 bra 0x0607895E ; nop
L_0607883C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0607883C mov.b @(r0,r10),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078884u);  // 0607883E mov.w 0x06078884,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06078840 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06078842 cmp/eq r2,r1
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0607884C; } }  // 06078844 bf/s 0x0607884C ; mov #0,r10
    goto L_0607895E;  // 06078848 bra 0x0607895E ; nop
L_0607884C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078882u);  // 0607884C mov.w 0x06078882,r1
    c.r[1] += c.r[13];  // 0607884E add r13,r1
    c.r[1] += c.r[12];  // 06078850 add r12,r1
    c.t = c.r[10] == c.r[1];  // 06078852 cmp/eq r1,r10
    { const bool k = c.t; c.r[9] = c.r[10] & 0xFFFFu; if (k) { goto L_0607894C; } }  // 06078854 bt/s 0x0607894C ; extu.w r10,r9
    c.r[8] = ld32(0x0607888Cu);  // 06078858 mov.l 0x0607888C,r8
    c.r[4] = ld32(0x06078888u);  // 0607885A mov.l 0x06078888,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06078860u; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078860u) return; }  // 0607885C jsr @r8 ; mov #11,r5
    c.r[5] = c.r[9];  // 06078860 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06078866u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078866u) return; }  // 06078862 jsr @r8 ; mov r0,r4
    c.r[6] = c.r[14];  // 06078866 mov r14,r6
    c.r[7] = c.r[0];  // 06078868 mov r0,r7
    c.r[5] = 0x0u;  // 0607886A mov #0,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[11];  // 0607886C cmp/ge r11,r5
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_060788AA; } }  // 0607886E bt/s 0x060788AA ; mov #0,r3
    c.r[0] = c.r[14];  // 06078872 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06078874 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078876 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078878 tst r1,r1
    if (!c.t) { goto L_060788AA; }  // 0607887A bf 0x060788AA
    c.r[3] = 0x1u;  // 0607887C mov #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11]; goto L_06078890;  // 0607887E bra 0x06078890 ; cmp/ge r11,r3
L_06078890:
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_060788AC; } }  // 06078890 bt/s 0x060788AC ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_060788A0;  // 06078894 bra 0x060788A0 ; mov.b @(r0,r3),r1
L_06078898:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 06078898 cmp/ge r11,r3
    if (c.t) { goto L_060788AA; }  // 0607889A bt 0x060788AA
    c.r[0] = c.r[6];  // 0607889C mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0607889E mov.b @(r0,r3),r1
L_060788A0:
    c.r[1] = c.r[1] & 0xFFu;  // 060788A0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060788A2 tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_06078898; } }  // 060788A4 bt/s 0x06078898 ; add #1,r3
    c.r[3] -= 1;  // 060788A8 add #-1,r3
L_060788AA:
    c.r[4] = 0x0u;  // 060788AA mov #0,r4
L_060788AC:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[11];  // 060788AC cmp/ge r11,r4
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= (int32_t)c.r[11]; if (k) { goto L_060788F4; } }  // 060788AE bt/s 0x060788F4 ; cmp/ge r11,r3
    c.r[0] = c.r[7];  // 060788B2 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060788B4 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060788B6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060788B8 tst r1,r1
    if (!c.t) { goto L_060788F2; }  // 060788BA bf 0x060788F2
    c.r[4] = 0x1u;  // 060788BC mov #1,r4
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[11];  // 060788BE cmp/ge r11,r4
    { const bool k = c.t; c.t = (int32_t)c.r[3] >= (int32_t)c.r[11]; if (k) { goto L_060788F4; } }  // 060788C0 bt/s 0x060788F4 ; cmp/ge r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]); goto L_060788D0;  // 060788C4 bra 0x060788D0 ; mov.b @(r0,r4),r1
L_060788C8:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[11];  // 060788C8 cmp/ge r11,r4
    if (c.t) { goto L_060788F2; }  // 060788CA bt 0x060788F2
    c.r[0] = c.r[7];  // 060788CC mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060788CE mov.b @(r0,r4),r1
L_060788D0:
    c.r[1] = c.r[1] & 0xFFu;  // 060788D0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060788D2 tst r1,r1
    { const bool k = c.t; c.r[4] += 1; if (k) { SH2_POLL(c); goto L_060788C8; } }  // 060788D4 bt/s 0x060788C8 ; add #1,r4
    c.r[4] -= 1;  // 060788D8 add #-1,r4
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11]; goto L_060788F4;  // 060788DA bra 0x060788F4 ; cmp/ge r11,r3
L_060788DE:
    c.r[0] = c.r[6];  // 060788DE mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060788E0 mov.b @(r0,r3),r2
    c.r[0] = c.r[7];  // 060788E2 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060788E4 mov.b @(r0,r4),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060788E6 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060788E8 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060788EA cmp/eq r1,r2
    if (!c.t) { goto L_060788FA; }  // 060788EC bf 0x060788FA
    c.r[3] += 1;  // 060788EE add #1,r3
    c.r[4] += 1;  // 060788F0 add #1,r4
L_060788F2:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 060788F2 cmp/ge r11,r3
L_060788F4:
    { const bool k = c.t; c.t = (int32_t)c.r[4] >= (int32_t)c.r[11]; if (k) { goto L_060788FA; } }  // 060788F4 bt/s 0x060788FA ; cmp/ge r11,r4
    if (!c.t) { SH2_POLL(c); goto L_060788DE; }  // 060788F8 bf 0x060788DE
L_060788FA:
    c.t = c.r[3] == c.r[11];  // 060788FA cmp/eq r11,r3
    if (c.t) { goto L_06078904; }  // 060788FC bt 0x06078904
    c.t = c.r[4] == c.r[11];  // 060788FE cmp/eq r11,r4
    { const bool k = !c.t; c.t = c.r[3] == c.r[11]; if (k) { goto L_06078942; } }  // 06078900 bf/s 0x06078942 ; cmp/eq r11,r3
L_06078904:
    if (!c.t) { goto L_0607890C; }  // 06078904 bf 0x0607890C
    c.r[3] = c.r[4];  // 06078906 mov r4,r3
    c.r[2] = c.r[7]; goto L_0607890E;  // 06078908 bra 0x0607890E ; mov r7,r2
L_0607890C:
    c.r[2] = c.r[6];  // 0607890C mov r6,r2
L_0607890E:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 0607890E cmp/ge r11,r3
    { const bool k = c.t; c.t = c.r[3] == c.r[11]; if (k) { goto L_0607893E; } }  // 06078910 bt/s 0x0607893E ; cmp/eq r11,r3
    c.r[0] = c.r[2];  // 06078914 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078916 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078918 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607891A tst r1,r1
    if (!c.t) { goto L_0607893C; }  // 0607891C bf 0x0607893C
    c.r[3] += 1;  // 0607891E add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 06078920 cmp/ge r11,r3
    { const bool k = c.t; c.t = c.r[3] == c.r[11]; if (k) { goto L_0607893E; } }  // 06078922 bt/s 0x0607893E ; cmp/eq r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_06078932;  // 06078926 bra 0x06078932 ; mov.b @(r0,r3),r1
L_0607892A:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[11];  // 0607892A cmp/ge r11,r3
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0607893C; } }  // 0607892C bt/s 0x0607893C ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078930 mov.b @(r0,r3),r1
L_06078932:
    c.r[1] = c.r[1] & 0xFFu;  // 06078932 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078934 tst r1,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_0607892A; } }  // 06078936 bt/s 0x0607892A ; add #1,r3
    c.r[3] -= 1;  // 0607893A add #-1,r3
L_0607893C:
    c.t = c.r[3] == c.r[11];  // 0607893C cmp/eq r11,r3
L_0607893E:
    if (!c.t) { goto L_06078942; }  // 0607893E bf 0x06078942
    c.r[5] = 0x1u;  // 06078940 mov #1,r5
L_06078942:
    c.t = (c.r[5] & c.r[5]) == 0;  // 06078942 tst r5,r5
    { const bool k = c.t; c.r[10] += 1; if (k) { goto L_0607894E; } }  // 06078944 bt/s 0x0607894E ; add #1,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06078A48u);  // 06078948 mov.w 0x06078A48,r12
    c.r[10] = c.r[12];  // 0607894A mov r12,r10
L_0607894C:
    c.r[10] += 1;  // 0607894C add #1,r10
L_0607894E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078A4Au);  // 0607894E mov.w 0x06078A4A,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06078950 cmp/gt r1,r10
    if (c.t) { goto L_06078958; }  // 06078952 bt 0x06078958
    SH2_POLL(c); goto L_0607884C;  // 06078954 bra 0x0607884C ; nop
L_06078958:
    c.r[12] += 1;  // 06078958 add #1,r12
    c.t = (c.r[13] & c.r[13]) == 0; goto L_06078964;  // 0607895A bra 0x06078964 ; tst r13,r13
L_0607895E:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06078A48u);  // 0607895E mov.w 0x06078A48,r12
    c.r[12] += 1;  // 06078960 add #1,r12
    c.t = (c.r[13] & c.r[13]) == 0;  // 06078962 tst r13,r13
L_06078964:
    { const bool k = !c.t; c.t = (int32_t)c.r[12] > 0; if (k) { goto L_0607896C; } }  // 06078964 bf/s 0x0607896C ; cmp/pl r12
    SH2_POLL(c); goto L_06078764;  // 06078968 bra 0x06078764 ; nop
L_0607896C:
    c.r[1] = 0x2u;  // 0607896C mov #2,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 0607896E cmp/gt r1,r12
    { const bool k = c.t; c.r[1] = 0x3u; if (k) { goto L_06078978; } }  // 06078970 bt/s 0x06078978 ; mov #3,r1
    SH2_POLL(c); goto L_0607876C;  // 06078974 bra 0x0607876C ; nop
L_06078978:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06078978 cmp/gt r1,r12
    c.r[0] = 0x2u;  // 0607897A mov #2,r0
    { const bool k = !c.t; st32(c.r[14] + 12, c.r[0]); if (k) { goto L_060789EE; } }  // 0607897C bf/s 0x060789EE ; mov.l r0,@(12,r14)
    c.r[0] = 0x1u;  // 06078980 mov #1,r0
    st32(c.r[14] + 12, c.r[0]); goto L_060789EE;  // 06078982 bra 0x060789EE ; mov.l r0,@(12,r14)
L_06078986:
    c.t = c.r[3] > c.r[1];  // 06078986 cmp/hi r1,r3
    if (!c.t) { goto L_060789B0; }  // 06078988 bf 0x060789B0
    c.r[4] = ld32(0x06078A50u);  // 0607898A mov.l 0x06078A50,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06078990u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078990u) return; }  // 0607898C jsr @r10 ; mov #23,r5
    c.r[5] = 0x1u;  // 06078990 mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06078996u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078996u) return; }  // 06078992 jsr @r10 ; mov r0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06078996 mov.b @r11,r1
    c.r[2] = c.r[0];  // 06078998 mov r0,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0607899A extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0607899C mov.b @(r0,r12),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607899E extu.b r1,r1
    c.r[2] += c.r[1];  // 060789A0 add r1,r2
    c.r[1] = ld32(0x06078A54u);  // 060789A2 mov.l 0x06078A54,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060789A4 mov.b @r1,r1
    c.r[2] -= 81;  // 060789A6 add #-81,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060789A8 mov.b @r2,r2
    c.r[0] = c.r[1] & 0xFFu;  // 060789AA extu.b r1,r0
    st8(c.r[0] + c.r[8], c.r[2]); goto L_060789E6;  // 060789AC bra 0x060789E6 ; mov.b r2,@(r0,r8)
L_060789B0:
    c.r[1] = ld32(0x06078A58u);  // 060789B0 mov.l 0x06078A58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060789B2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060789B4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060789B6 tst r1,r1
    { const bool k = c.t; c.r[9] = 0x22u; if (k) { goto L_060789BE; } }  // 060789B8 bt/s 0x060789BE ; mov #34,r9
    c.r[9] = 0x21u;  // 060789BC mov #33,r9
L_060789BE:
    c.r[4] = ld32(0x06078A50u);  // 060789BE mov.l 0x06078A50,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060789C4u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060789C4u) return; }  // 060789C0 jsr @r10 ; mov #23,r5
    c.r[1] = c.r[0];  // 060789C4 mov r0,r1
    c.r[5] = c.r[9];  // 060789C6 mov r9,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060789CCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060789CCu) return; }  // 060789C8 jsr @r10 ; mov r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060789CC mov.b @r11,r1
    c.r[2] = c.r[0];  // 060789CE mov r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060789D0 extu.b r1,r1
    c.r[0] = c.r[1];  // 060789D2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060789D4 mov.b @(r0,r12),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060789D6 extu.b r1,r1
    c.r[0] = c.r[2];  // 060789D8 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060789DA mov.b @(r0,r1),r2
    c.r[1] = ld32(0x06078A54u);  // 060789DC mov.l 0x06078A54,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060789DE mov.b @r1,r1
    c.r[0] = c.r[8];  // 060789E0 mov r8,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060789E2 extu.b r1,r1
    st8(c.r[0] + c.r[1], c.r[2]);  // 060789E4 mov.b r2,@(r0,r1)
L_060789E6:
    c.r[2] = ld32(0x06078A54u);  // 060789E6 mov.l 0x06078A54,r2
L_060789E8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060789E8 mov.b @r2,r1
    c.r[1] += 1;  // 060789EA add #1,r1
L_060789EC:
    st8(c.r[2], c.r[1]);  // 060789EC mov.b r1,@r2
L_060789EE:
    c.r[7] = ld32(0x06078A54u);  // 060789EE mov.l 0x06078A54,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060789F0 mov.b @r7,r3
    c.r[1] = ld32(0x06078A5Cu);  // 060789F2 mov.l 0x06078A5C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060789F4 mov.b @r1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060789F6 extu.b r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060789F8 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060789FA cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06078A04; } }  // 060789FC bf/s 0x06078A04 ; mov r3,r1
    c.r[1] -= 1;  // 06078A00 add #-1,r1
    st8(c.r[7], c.r[1]);  // 06078A02 mov.b r1,@r7
L_06078A04:
    c.r[0] = ld32(c.r[14] + 12);  // 06078A04 mov.l @(12,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078A4Cu);  // 06078A06 mov.w 0x06078A4C,r1
    c.r[0] += c.r[0];  // 06078A08 add r0,r0
    c.r[0] += 2;  // 06078A0A add #2,r0
    c.r[0] |= c.r[1];  // 06078A0C or r1,r0
    st32(c.r[14] + 12, c.r[0]);  // 06078A0E mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12); goto L_06078B12;  // 06078A10 bra 0x06078B12 ; mov.l @(12,r14),r0
L_06078A14:
    c.r[7] = ld32(0x06078A54u);  // 06078A14 mov.l 0x06078A54,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06078A16 mov.b @r7,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06078A18 extu.b r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06078A1A tst r2,r2
    if (c.t) { goto L_06078B10; }  // 06078A1C bt 0x06078B10
    c.r[1] = ld32(0x06078A5Cu);  // 06078A1E mov.l 0x06078A5C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078A20 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078A22 extu.b r1,r1
    c.r[1] -= 1;  // 06078A24 add #-1,r1
    c.t = c.r[2] == c.r[1];  // 06078A26 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06078A36; } }  // 06078A28 bf/s 0x06078A36 ; mov r8,r1
    c.r[1] += 9;  // 06078A2C add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078A2E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078A30 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078A32 tst r1,r1
    if (!c.t) { goto L_06078A3C; }  // 06078A34 bf 0x06078A3C
L_06078A36:
    c.r[1] = c.r[3];  // 06078A36 mov r3,r1
    c.r[1] -= 1;  // 06078A38 add #-1,r1
    st8(c.r[7], c.r[1]);  // 06078A3A mov.b r1,@r7
L_06078A3C:
    c.r[2] = ld32(0x06078A54u);  // 06078A3C mov.l 0x06078A54,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06078A3E mov.b @r2,r2
    c.r[1] = 0x0u;  // 06078A40 mov #0,r1
    c.r[0] = c.r[2] & 0xFFu;  // 06078A42 extu.b r2,r0
    st8(c.r[0] + c.r[8], c.r[1]); goto L_06078B10;  // 06078A44 bra 0x06078B10 ; mov.b r1,@(r0,r8)
L_06078A60:
    if (!c.t) { goto L_06078A66; }  // 06078A60 bf 0x06078A66
L_06078A62:
    c.t = (int32_t)c.r[12] > 0;  // 06078A62 cmp/pl r12
    if (c.t) { goto L_06078B10; }  // 06078A64 bt 0x06078B10
L_06078A66:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078B28u);  // 06078A66 mov.w 0x06078B28,r1
    c.r[8] = c.r[12];  // 06078A68 mov r12,r8
    c.r[8] += c.r[1];  // 06078A6A add r1,r8
    c.r[8] += c.r[13];  // 06078A6C add r13,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06078A6E extu.w r8,r8
    c.r[4] = ld32(0x06078B30u);  // 06078A70 mov.l 0x06078B30,r4
    c.r[9] = ld32(0x06078B34u);  // 06078A72 mov.l 0x06078B34,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06078A78u; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078A78u) return; }  // 06078A74 jsr @r9 ; mov #11,r5
    c.r[5] = c.r[8];  // 06078A78 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06078A7Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078A7Eu) return; }  // 06078A7A jsr @r9 ; mov r0,r4
    c.r[8] = c.r[0];  // 06078A7E mov r0,r8
    c.r[10] = 0x0u;  // 06078A80 mov #0,r10
    c.r[5] = 0x9u;  // 06078A82 mov #9,r5
    c.r[6] = ld32(0x06078B38u);  // 06078A84 mov.l 0x06078B38,r6
    c.r[3] = c.r[12];  // 06078A86 mov r12,r3
    c.r[3] <<= 2;  // 06078A88 shll2 r3
    c.r[3] += c.r[12];  // 06078A8A add r12,r3
    c.r[3] += c.r[3];  // 06078A8C add r3,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078B2Au);  // 06078A8E mov.w 0x06078B2A,r7
L_06078A90:
    c.r[2] = ld32(c.r[6]);  // 06078A90 mov.l @r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 06078A92 mov.b @r8+,r1
    c.r[2] += c.r[3];  // 06078A94 add r3,r2
    c.r[2] += c.r[7];  // 06078A96 add r7,r2
    c.r[0] = c.r[2];  // 06078A98 mov r2,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 06078A9A mov.b r1,@(r0,r10)
    c.r[10] += 1;  // 06078A9C add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[5];  // 06078A9E cmp/gt r5,r10
    if (!c.t) { SH2_POLL(c); goto L_06078A90; }  // 06078AA0 bf 0x06078A90
    c.r[10] = 0xAu;  // 06078AA2 mov #10,r10
    c.r[7] = ld32(0x06078B38u);  // 06078AA4 mov.l 0x06078B38,r7
    c.r[2] = c.r[12];  // 06078AA6 mov r12,r2
    c.r[2] <<= 2;  // 06078AA8 shll2 r2
    c.r[2] += c.r[12];  // 06078AAA add r12,r2
    c.r[2] += c.r[2];  // 06078AAC add r2,r2
    c.r[6] = ld32(c.r[7]);  // 06078AAE mov.l @r7,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078B2Au);  // 06078AB0 mov.w 0x06078B2A,r3
    c.r[6] += c.r[2];  // 06078AB2 add r2,r6
    c.r[6] += c.r[3];  // 06078AB4 add r3,r6
    c.r[0] = c.r[6];  // 06078AB6 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06078AB8 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06078ABA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078ABC tst r1,r1
    if (!c.t) { goto L_06078ADE; }  // 06078ABE bf 0x06078ADE
    c.r[10] = 0x9u;  // 06078AC0 mov #9,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]); goto L_06078AD4;  // 06078AC2 bra 0x06078AD4 ; mov.b @(r0,r10),r1
L_06078AC6:
    c.t = (int32_t)c.r[10] >= 0;  // 06078AC6 cmp/pz r10
    if (!c.t) { goto L_06078ADE; }  // 06078AC8 bf 0x06078ADE
    c.r[1] = ld32(c.r[7]);  // 06078ACA mov.l @r7,r1
    c.r[1] += c.r[2];  // 06078ACC add r2,r1
    c.r[1] += c.r[3];  // 06078ACE add r3,r1
    c.r[0] = c.r[1];  // 06078AD0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06078AD2 mov.b @(r0,r10),r1
L_06078AD4:
    c.r[1] = c.r[1] & 0xFFu;  // 06078AD4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06078AD6 tst r1,r1
    { const bool k = c.t; c.r[10] -= 1; if (k) { SH2_POLL(c); goto L_06078AC6; } }  // 06078AD8 bt/s 0x06078AC6 ; add #-1,r10
    c.r[10] += 1;  // 06078ADC add #1,r10
L_06078ADE:
    c.r[2] = c.r[10];  // 06078ADE mov r10,r2
    c.r[2] += 1;  // 06078AE0 add #1,r2
    c.r[1] = 0x9u;  // 06078AE2 mov #9,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06078AE4 cmp/gt r1,r2
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_06078B06; } }  // 06078AE6 bt/s 0x06078B06 ; tst r13,r13
    c.r[1] = ld32(0x06078B38u);  // 06078AEA mov.l 0x06078B38,r1
    c.r[1] = ld32(c.r[1]);  // 06078AEC mov.l @r1,r1
    c.r[2] = c.r[12];  // 06078AEE mov r12,r2
    c.r[2] <<= 2;  // 06078AF0 shll2 r2
    c.r[2] += c.r[12];  // 06078AF2 add r12,r2
    c.r[2] += c.r[2];  // 06078AF4 add r2,r2
    c.r[2] += c.r[1];  // 06078AF6 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078B2Au);  // 06078AF8 mov.w 0x06078B2A,r1
    c.r[2] += c.r[1];  // 06078AFA add r1,r2
    c.r[2] += c.r[10];  // 06078AFC add r10,r2
    c.r[2] += 1;  // 06078AFE add #1,r2
    c.r[1] = 0xFFFFFFFFu;  // 06078B00 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06078B02 mov.b r1,@r2
    c.t = (c.r[13] & c.r[13]) == 0;  // 06078B04 tst r13,r13
L_06078B06:
    { const bool k = c.t; c.r[12] += 1; if (k) { SH2_POLL(c); goto L_06078A62; } }  // 06078B06 bt/s 0x06078A62 ; add #1,r12
    c.r[1] = 0x2u;  // 06078B0A mov #2,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06078B0C cmp/gt r1,r12
    if (!c.t) { SH2_POLL(c); goto L_06078A66; }  // 06078B0E bf 0x06078A66
L_06078B10:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078B2Cu);  // 06078B10 mov.w 0x06078B2C,r0
L_06078B12:
    c.r[14] += 16;  // 06078B12 add #16,r14
    c.r[15] = c.r[14];  // 06078B14 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06078B16 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06078B18 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06078B1A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06078B1C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06078B1E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06078B20 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06078B22 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06078B24 rts ; mov.l @r15+,r8
}

void f_06078B3C(SH2Context& c) {
    ran[1661] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06078B3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06078B3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06078B40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06078B42 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06078B44 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06078B46 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06078B48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06078B4A sts.l pr,@-r15
    c.r[6] = ld32(0x06078CBCu);  // 06078B4C mov.l 0x06078CBC,r6
    c.r[2] = ld32(c.r[6]);  // 06078B4E mov.l @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078CA2u);  // 06078B50 mov.w 0x06078CA2,r1
    c.r[0] = c.r[2];  // 06078B52 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06078B54 mov.b @(r0,r1),r1
    c.r[3] = c.r[1];  // 06078B56 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06078B58 shlr r3
    c.r[0] = 0x3u;  // 06078B5A mov #3,r0
    c.r[3] &= c.r[0];  // 06078B5C and r0,r3
    c.r[0] = c.r[3];  // 06078B5E mov r3,r0
    c.t = c.r[0] == 0x1u;  // 06078B60 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06078C3C; } }  // 06078B62 bt/s 0x06078C3C ; mov r15,r14
    c.r[1] = 0x1u;  // 06078B66 mov #1,r1
    c.t = c.r[3] >= c.r[1];  // 06078B68 cmp/hs r1,r3
    { const bool k = !c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_06078B78; } }  // 06078B6A bf/s 0x06078B78 ; cmp/eq #2,r0
    if (c.t) { goto L_06078B74; }  // 06078B6E bt 0x06078B74
    goto L_06078DDE;  // 06078B70 bra 0x06078DDE ; nop
L_06078B74:
    goto L_06078D1E;  // 06078B74 bra 0x06078D1E ; nop
L_06078B78:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CA4u);  // 06078B78 mov.w 0x06078CA4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078B7A mov.b @(r0,r2),r1
    c.r[0] = c.r[1];  // 06078B7C mov r1,r0
    c.r[0] >>= 2;  // 06078B7E shlr2 r0
    c.r[0] >>= 2;  // 06078B80 shlr2 r0
    c.r[0] >>= 2;  // 06078B82 shlr2 r0
    c.r[0] &= 0x1u;  // 06078B84 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06078B86 tst r0,r0
    { const bool k = c.t; c.r[5] = 0x7Fu; if (k) { goto L_06078BE6; } }  // 06078B88 bt/s 0x06078BE6 ; mov #127,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078CA6u);  // 06078B8C mov.w 0x06078CA6,r3
    c.r[0] = c.r[2];  // 06078B8E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078B90 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CA8u);  // 06078B92 mov.w 0x06078CA8,r0
    c.r[1] &= c.r[0];  // 06078B94 and r0,r1
    c.r[0] = c.r[2];  // 06078B96 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078B98 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078B9A mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078CAAu);  // 06078B9C mov.w 0x06078CAA,r7
    c.r[0] = c.r[2];  // 06078B9E mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078BA0 mov.w @(r0,r7),r1
    c.r[5] &= c.r[1];  // 06078BA2 and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078CACu);  // 06078BA4 mov.w 0x06078CAC,r1
    c.r[5] |= c.r[1];  // 06078BA6 or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078BA8 mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078BAA mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CAEu);  // 06078BAC mov.w 0x06078CAE,r0
    c.r[1] &= c.r[0];  // 06078BAE and r0,r1
    c.r[0] = 0x14u;  // 06078BB0 mov #20,r0
    c.r[1] |= c.r[0];  // 06078BB2 or r0,r1
    c.r[0] = c.r[2];  // 06078BB4 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078BB6 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078BB8 mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078BBA mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078BBC mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078CC0u);  // 06078BBE mov.l 0x06078CC0,r2
    c.r[1] &= c.r[2];  // 06078BC0 and r2,r1
    c.r[2] = ld32(0x06078CC4u);  // 06078BC2 mov.l 0x06078CC4,r2
    c.r[2] |= c.r[1];  // 06078BC4 or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078BC6 mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078CB0u);  // 06078BC8 mov.w 0x06078CB0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078BCA mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CB2u);  // 06078BCC mov.w 0x06078CB2,r0
    c.r[1] &= c.r[0];  // 06078BCE and r0,r1
    c.r[0] = 0x10u;  // 06078BD0 mov #16,r0
    c.r[1] |= c.r[0];  // 06078BD2 or r0,r1
    c.r[0] = c.r[3];  // 06078BD4 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078BD6 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078BD8 mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078BDA mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078BDC mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CB4u);  // 06078BDE mov.w 0x06078CB4,r0
    c.r[2] &= c.r[0];  // 06078BE0 and r0,r2
    c.r[0] = 0x4u; goto L_06078E4E;  // 06078BE2 bra 0x06078E4E ; mov #4,r0
L_06078BE6:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078CA6u);  // 06078BE6 mov.w 0x06078CA6,r3
    c.r[0] = c.r[2];  // 06078BE8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078BEA mov.b @(r0,r3),r1
    c.r[0] = 0x40u;  // 06078BEC mov #64,r0
    c.r[1] |= c.r[0];  // 06078BEE or r0,r1
    c.r[0] = c.r[2];  // 06078BF0 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078BF2 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078BF4 mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078CAAu);  // 06078BF6 mov.w 0x06078CAA,r7
    c.r[0] = c.r[2];  // 06078BF8 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078BFA mov.w @(r0,r7),r1
    c.r[5] &= c.r[1];  // 06078BFC and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078CB6u);  // 06078BFE mov.w 0x06078CB6,r1
    c.r[5] |= c.r[1];  // 06078C00 or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078C02 mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078C04 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CAEu);  // 06078C06 mov.w 0x06078CAE,r0
    c.r[1] &= c.r[0];  // 06078C08 and r0,r1
    c.r[0] = 0x24u;  // 06078C0A mov #36,r0
    c.r[1] |= c.r[0];  // 06078C0C or r0,r1
    c.r[0] = c.r[2];  // 06078C0E mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078C10 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078C12 mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078C14 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078C16 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078CC0u);  // 06078C18 mov.l 0x06078CC0,r2
    c.r[1] &= c.r[2];  // 06078C1A and r2,r1
    c.r[2] = ld32(0x06078CC8u);  // 06078C1C mov.l 0x06078CC8,r2
    c.r[2] |= c.r[1];  // 06078C1E or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078C20 mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078CB0u);  // 06078C22 mov.w 0x06078CB0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078C24 mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CB2u);  // 06078C26 mov.w 0x06078CB2,r0
    c.r[1] &= c.r[0];  // 06078C28 and r0,r1
    c.r[0] = c.r[3];  // 06078C2A mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078C2C mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078C2E mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078C30 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078C32 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CB4u);  // 06078C34 mov.w 0x06078CB4,r0
    c.r[2] &= c.r[0];  // 06078C36 and r0,r2
    c.r[0] = 0x4u; goto L_06078E4E;  // 06078C38 bra 0x06078E4E ; mov #4,r0
L_06078C3C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CA4u);  // 06078C3C mov.w 0x06078CA4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078C3E mov.b @(r0,r2),r1
    c.r[0] = c.r[1];  // 06078C40 mov r1,r0
    c.r[0] >>= 2;  // 06078C42 shlr2 r0
    c.r[0] >>= 2;  // 06078C44 shlr2 r0
    c.r[0] >>= 2;  // 06078C46 shlr2 r0
    c.r[0] &= 0x1u;  // 06078C48 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06078C4A tst r0,r0
    { const bool k = c.t; c.r[5] = 0x7Fu; if (k) { goto L_06078CCC; } }  // 06078C4C bt/s 0x06078CCC ; mov #127,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078CA6u);  // 06078C50 mov.w 0x06078CA6,r3
    c.r[0] = c.r[2];  // 06078C52 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078C54 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CA8u);  // 06078C56 mov.w 0x06078CA8,r0
    c.r[1] &= c.r[0];  // 06078C58 and r0,r1
    c.r[0] = c.r[2];  // 06078C5A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078C5C mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078C5E mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078CAAu);  // 06078C60 mov.w 0x06078CAA,r7
    c.r[0] = c.r[2];  // 06078C62 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078C64 mov.w @(r0,r7),r1
    c.r[5] &= c.r[1];  // 06078C66 and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078CB8u);  // 06078C68 mov.w 0x06078CB8,r1
    c.r[5] |= c.r[1];  // 06078C6A or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078C6C mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078C6E mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078CAEu);  // 06078C70 mov.w 0x06078CAE,r0
    c.r[1] &= c.r[0];  // 06078C72 and r0,r1
    c.r[0] = 0xCu;  // 06078C74 mov #12,r0
    c.r[1] |= c.r[0];  // 06078C76 or r0,r1
    c.r[0] = c.r[2];  // 06078C78 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078C7A mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078C7C mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078C7E mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078C80 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078CC0u);  // 06078C82 mov.l 0x06078CC0,r2
    c.r[1] &= c.r[2];  // 06078C84 and r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078CBAu);  // 06078C86 mov.w 0x06078CBA,r2
    c.r[2] |= c.r[1];  // 06078C88 or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078C8A mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078CB0u);  // 06078C8C mov.w 0x06078CB0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078C8E mov.b @(r0,r7),r1
    c.r[0] = 0x18u;  // 06078C90 mov #24,r0
    c.r[1] |= c.r[0];  // 06078C92 or r0,r1
    c.r[0] = c.r[3];  // 06078C94 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078C96 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078C98 mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078C9A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078C9C mov.b @(r0,r7),r2
    c.r[0] = 0x6u; goto L_06078E4E;  // 06078C9E bra 0x06078E4E ; mov #6,r0
L_06078CCC:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078E56u);  // 06078CCC mov.w 0x06078E56,r3
    c.r[0] = c.r[2];  // 06078CCE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078CD0 mov.b @(r0,r3),r1
    c.r[0] = 0x40u;  // 06078CD2 mov #64,r0
    c.r[1] |= c.r[0];  // 06078CD4 or r0,r1
    c.r[0] = c.r[2];  // 06078CD6 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078CD8 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078CDA mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E58u);  // 06078CDC mov.w 0x06078E58,r7
    c.r[0] = c.r[2];  // 06078CDE mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078CE0 mov.w @(r0,r7),r1
    c.r[5] &= c.r[1];  // 06078CE2 and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078E5Au);  // 06078CE4 mov.w 0x06078E5A,r1
    c.r[5] |= c.r[1];  // 06078CE6 or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078CE8 mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078CEA mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E5Cu);  // 06078CEC mov.w 0x06078E5C,r0
    c.r[1] &= c.r[0];  // 06078CEE and r0,r1
    c.r[0] = 0x10u;  // 06078CF0 mov #16,r0
    c.r[1] |= c.r[0];  // 06078CF2 or r0,r1
    c.r[0] = c.r[2];  // 06078CF4 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078CF6 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078CF8 mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078CFA mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078CFC mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078E70u);  // 06078CFE mov.l 0x06078E70,r2
    c.r[1] &= c.r[2];  // 06078D00 and r2,r1
    c.r[2] = ld32(0x06078E74u);  // 06078D02 mov.l 0x06078E74,r2
    c.r[2] |= c.r[1];  // 06078D04 or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078D06 mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E5Eu);  // 06078D08 mov.w 0x06078E5E,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078D0A mov.b @(r0,r7),r1
    c.r[0] = 0x18u;  // 06078D0C mov #24,r0
    c.r[1] |= c.r[0];  // 06078D0E or r0,r1
    c.r[0] = c.r[3];  // 06078D10 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078D12 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078D14 mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078D16 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078D18 mov.b @(r0,r7),r2
    c.r[0] = 0x6u; goto L_06078E4E;  // 06078D1A bra 0x06078E4E ; mov #6,r0
L_06078D1E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E60u);  // 06078D1E mov.w 0x06078E60,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078D20 mov.b @(r0,r2),r1
    c.r[0] = c.r[1];  // 06078D22 mov r1,r0
    c.r[0] >>= 2;  // 06078D24 shlr2 r0
    c.r[0] >>= 2;  // 06078D26 shlr2 r0
    c.r[0] >>= 2;  // 06078D28 shlr2 r0
    c.r[0] &= 0x1u;  // 06078D2A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06078D2C tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06078D86; } }  // 06078D2E bt/s 0x06078D86 ; mov r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078E56u);  // 06078D32 mov.w 0x06078E56,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078D34 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E62u);  // 06078D36 mov.w 0x06078E62,r0
    c.r[1] &= c.r[0];  // 06078D38 and r0,r1
    c.r[0] = c.r[2];  // 06078D3A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078D3C mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078D3E mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E58u);  // 06078D40 mov.w 0x06078E58,r7
    c.r[0] = c.r[2];  // 06078D42 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078D44 mov.w @(r0,r7),r1
    c.r[5] = 0x7Fu;  // 06078D46 mov #127,r5
    c.r[5] &= c.r[1];  // 06078D48 and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078E64u);  // 06078D4A mov.w 0x06078E64,r1
    c.r[5] |= c.r[1];  // 06078D4C or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078D4E mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078D50 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E5Cu);  // 06078D52 mov.w 0x06078E5C,r0
    c.r[1] &= c.r[0];  // 06078D54 and r0,r1
    c.r[0] = 0x1Cu;  // 06078D56 mov #28,r0
    c.r[1] |= c.r[0];  // 06078D58 or r0,r1
    c.r[0] = c.r[2];  // 06078D5A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078D5C mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078D5E mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078D60 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078D62 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078E70u);  // 06078D64 mov.l 0x06078E70,r2
    c.r[1] &= c.r[2];  // 06078D66 and r2,r1
    c.r[2] = ld32(0x06078E78u);  // 06078D68 mov.l 0x06078E78,r2
    c.r[2] |= c.r[1];  // 06078D6A or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078D6C mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E5Eu);  // 06078D6E mov.w 0x06078E5E,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078D70 mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E66u);  // 06078D72 mov.w 0x06078E66,r0
    c.r[1] &= c.r[0];  // 06078D74 and r0,r1
    c.r[0] = c.r[3];  // 06078D76 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078D78 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078D7A mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078D7C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078D7E mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E68u);  // 06078D80 mov.w 0x06078E68,r0
    c.r[2] &= c.r[0]; goto L_06078E50;  // 06078D82 bra 0x06078E50 ; and r0,r2
L_06078D86:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078E56u);  // 06078D86 mov.w 0x06078E56,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078D88 mov.b @(r0,r3),r1
    c.r[0] = 0x40u;  // 06078D8A mov #64,r0
    c.r[1] |= c.r[0];  // 06078D8C or r0,r1
    c.r[0] = c.r[2];  // 06078D8E mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078D90 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078D92 mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E58u);  // 06078D94 mov.w 0x06078E58,r7
    c.r[0] = c.r[2];  // 06078D96 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078D98 mov.w @(r0,r7),r1
    c.r[5] = 0x7Fu;  // 06078D9A mov #127,r5
    c.r[5] &= c.r[1];  // 06078D9C and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078E6Au);  // 06078D9E mov.w 0x06078E6A,r1
    c.r[5] |= c.r[1];  // 06078DA0 or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078DA2 mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078DA4 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E5Cu);  // 06078DA6 mov.w 0x06078E5C,r0
    c.r[1] &= c.r[0];  // 06078DA8 and r0,r1
    c.r[0] = 0x8u;  // 06078DAA mov #8,r0
    c.r[1] |= c.r[0];  // 06078DAC or r0,r1
    c.r[0] = c.r[2];  // 06078DAE mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078DB0 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078DB2 mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078DB4 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078DB6 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078E70u);  // 06078DB8 mov.l 0x06078E70,r2
    c.r[1] &= c.r[2];  // 06078DBA and r2,r1
    c.r[2] = ld32(0x06078E7Cu);  // 06078DBC mov.l 0x06078E7C,r2
    c.r[2] |= c.r[1];  // 06078DBE or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078DC0 mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E5Eu);  // 06078DC2 mov.w 0x06078E5E,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078DC4 mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E66u);  // 06078DC6 mov.w 0x06078E66,r0
    c.r[1] &= c.r[0];  // 06078DC8 and r0,r1
    c.r[0] = 0x8u;  // 06078DCA mov #8,r0
    c.r[1] |= c.r[0];  // 06078DCC or r0,r1
    c.r[0] = c.r[3];  // 06078DCE mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078DD0 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078DD2 mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078DD4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078DD6 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E68u);  // 06078DD8 mov.w 0x06078E68,r0
    c.r[2] &= c.r[0]; goto L_06078E50;  // 06078DDA bra 0x06078E50 ; and r0,r2
L_06078DDE:
    c.r[6] = ld32(0x06078E80u);  // 06078DDE mov.l 0x06078E80,r6
    c.r[2] = ld32(c.r[6]);  // 06078DE0 mov.l @r6,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E60u);  // 06078DE2 mov.w 0x06078E60,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078DE4 mov.b @(r0,r2),r1
    c.r[0] = c.r[1];  // 06078DE6 mov r1,r0
    c.r[0] >>= 2;  // 06078DE8 shlr2 r0
    c.r[0] >>= 2;  // 06078DEA shlr2 r0
    c.r[0] >>= 2;  // 06078DEC shlr2 r0
    c.r[0] &= 0x1u;  // 06078DEE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06078DF0 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06078E88; } }  // 06078DF2 bt/s 0x06078E88 ; mov r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078E56u);  // 06078DF6 mov.w 0x06078E56,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078DF8 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E62u);  // 06078DFA mov.w 0x06078E62,r0
    c.r[1] &= c.r[0];  // 06078DFC and r0,r1
    c.r[0] = c.r[2];  // 06078DFE mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078E00 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078E02 mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E58u);  // 06078E04 mov.w 0x06078E58,r7
    c.r[0] = c.r[2];  // 06078E06 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078E08 mov.w @(r0,r7),r1
    c.r[5] = 0x7Fu;  // 06078E0A mov #127,r5
    c.r[5] &= c.r[1];  // 06078E0C and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078E6Cu);  // 06078E0E mov.w 0x06078E6C,r1
    c.r[5] |= c.r[1];  // 06078E10 or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078E12 mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078E14 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E5Cu);  // 06078E16 mov.w 0x06078E5C,r0
    c.r[1] &= c.r[0];  // 06078E18 and r0,r1
    c.r[0] = 0x2Cu;  // 06078E1A mov #44,r0
    c.r[1] |= c.r[0];  // 06078E1C or r0,r1
    c.r[0] = c.r[2];  // 06078E1E mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078E20 mov.b r1,@(r0,r3)
    c.r[3] = ld32(c.r[6]);  // 06078E22 mov.l @r6,r3
    c.r[0] = c.r[3];  // 06078E24 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06078E26 mov.l @(r0,r7),r1
    c.r[2] = ld32(0x06078E70u);  // 06078E28 mov.l 0x06078E70,r2
    c.r[1] &= c.r[2];  // 06078E2A and r2,r1
    c.r[2] = ld32(0x06078E84u);  // 06078E2C mov.l 0x06078E84,r2
    c.r[2] |= c.r[1];  // 06078E2E or r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 06078E30 mov.l r2,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078E5Eu);  // 06078E32 mov.w 0x06078E5E,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078E34 mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E66u);  // 06078E36 mov.w 0x06078E66,r0
    c.r[1] &= c.r[0];  // 06078E38 and r0,r1
    c.r[0] = 0x8u;  // 06078E3A mov #8,r0
    c.r[1] |= c.r[0];  // 06078E3C or r0,r1
    c.r[0] = c.r[3];  // 06078E3E mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06078E40 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[6]);  // 06078E42 mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078E44 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06078E46 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078E68u);  // 06078E48 mov.w 0x06078E68,r0
    c.r[2] &= c.r[0];  // 06078E4A and r0,r2
    c.r[0] = 0x2u;  // 06078E4C mov #2,r0
L_06078E4E:
    c.r[2] |= c.r[0];  // 06078E4E or r0,r2
L_06078E50:
    c.r[0] = c.r[1];  // 06078E50 mov r1,r0
    st8(c.r[0] + c.r[7], c.r[2]); goto L_06078EE2;  // 06078E52 bra 0x06078EE2 ; mov.b r2,@(r0,r7)
L_06078E88:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078FAEu);  // 06078E88 mov.w 0x06078FAE,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078E8A mov.b @(r0,r3),r1
    c.r[0] = 0x40u;  // 06078E8C mov #64,r0
    c.r[1] |= c.r[0];  // 06078E8E or r0,r1
    c.r[0] = c.r[2];  // 06078E90 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078E92 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078E94 mov.l @r6,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078FB0u);  // 06078E96 mov.w 0x06078FB0,r7
    c.r[0] = c.r[2];  // 06078E98 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06078E9A mov.w @(r0,r7),r1
    c.r[5] = 0x7Fu;  // 06078E9C mov #127,r5
    c.r[5] &= c.r[1];  // 06078E9E and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078FB2u);  // 06078EA0 mov.w 0x06078FB2,r1
    c.r[5] |= c.r[1];  // 06078EA2 or r1,r5
    st16(c.r[0] + c.r[7], c.r[5]);  // 06078EA4 mov.w r5,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078EA6 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078FB4u);  // 06078EA8 mov.w 0x06078FB4,r0
    c.r[1] &= c.r[0];  // 06078EAA and r0,r1
    c.r[0] = 0x4u;  // 06078EAC mov #4,r0
    c.r[1] |= c.r[0];  // 06078EAE or r0,r1
    c.r[0] = c.r[2];  // 06078EB0 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078EB2 mov.b r1,@(r0,r3)
    c.r[2] = ld32(c.r[6]);  // 06078EB4 mov.l @r6,r2
    c.r[0] = c.r[2];  // 06078EB6 mov r2,r0
    c.r[3] = ld32(c.r[0] + c.r[7]);  // 06078EB8 mov.l @(r0,r7),r3
    c.r[1] = ld32(0x06078FCCu);  // 06078EBA mov.l 0x06078FCC,r1
    c.r[3] |= c.r[1];  // 06078EBC or r1,r3
    st32(c.r[0] + c.r[7], c.r[3]);  // 06078EBE mov.l r3,@(r0,r7)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078FB6u);  // 06078EC0 mov.w 0x06078FB6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078EC2 mov.b @(r0,r3),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078FB8u);  // 06078EC4 mov.w 0x06078FB8,r0
    c.r[1] &= c.r[0];  // 06078EC6 and r0,r1
    c.r[0] = 0x10u;  // 06078EC8 mov #16,r0
    c.r[1] |= c.r[0];  // 06078ECA or r0,r1
    c.r[0] = c.r[2];  // 06078ECC mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078ECE mov.b r1,@(r0,r3)
    c.r[1] = ld32(c.r[6]);  // 06078ED0 mov.l @r6,r1
    c.r[0] = c.r[1];  // 06078ED2 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06078ED4 mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078FBAu);  // 06078ED6 mov.w 0x06078FBA,r0
    c.r[2] &= c.r[0];  // 06078ED8 and r0,r2
    c.r[0] = 0x2u;  // 06078EDA mov #2,r0
    c.r[2] |= c.r[0];  // 06078EDC or r0,r2
    c.r[0] = c.r[1];  // 06078EDE mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06078EE0 mov.b r2,@(r0,r3)
L_06078EE2:
    c.r[9] = ld32(0x06078FD0u);  // 06078EE2 mov.l 0x06078FD0,r9
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078FBCu);  // 06078EE4 mov.w 0x06078FBC,r2
    c.r[3] = 0x1u;  // 06078EE6 mov #1,r3
    c.r[1] = ld32(c.r[9]);  // 06078EE8 mov.l @r9,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06078FB0u);  // 06078EEA mov.w 0x06078FB0,r13
    c.r[0] = c.r[1];  // 06078EEC mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078EEE mov.b @(r0,r2),r2
    c.r[11] = ld32(0x06078FD4u);  // 06078EF0 mov.l 0x06078FD4,r11
    c.r[3] &= c.r[2];  // 06078EF2 and r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06078FB6u);  // 06078EF4 mov.w 0x06078FB6,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06078EF6 mov.b @(r0,r2),r7
    c.r[10] = ld32(0x06078FD8u);  // 06078EF8 mov.l 0x06078FD8,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078FBEu);  // 06078EFA mov.w 0x06078FBE,r0
    c.r[7] &= c.r[0];  // 06078EFC and r0,r7
    c.r[7] |= c.r[3];  // 06078EFE or r3,r7
    c.r[0] = c.r[1];  // 06078F00 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 06078F02 mov.b r7,@(r0,r2)
    c.r[1] = ld32(c.r[9]);  // 06078F04 mov.l @r9,r1
    c.r[5] = 0xCu;  // 06078F06 mov #12,r5
    c.r[0] = c.r[1];  // 06078F08 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06078F0A mov.w @(r0,r13),r8
    c.r[4] = c.r[11];  // 06078F0C mov r11,r4
    c.r[8] = c.r[8] & 0xFFFFu;  // 06078F0E extu.w r8,r8
    c.r[8] >>= 2;  // 06078F10 shlr2 r8
    c.r[8] >>= 2;  // 06078F12 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06078F14 shlr r8
    { const uint32_t x = c.r[10]; c.pr = 0x06078F1Au; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F1Au) return; }  // 06078F16 jsr @r10 ; shlr2 r8
    c.r[1] = c.r[0];  // 06078F1A mov r0,r1
    c.r[5] = c.r[8];  // 06078F1C mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06078F22u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F22u) return; }  // 06078F1E jsr @r10 ; mov r1,r4
    c.r[12] = c.r[0];  // 06078F22 mov r0,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06078FC0u);  // 06078F24 mov.w 0x06078FC0,r1
    c.r[5] = 0x1u;  // 06078F26 mov #1,r5
    c.r[4] = c.r[12];  // 06078F28 mov r12,r4
    c.r[8] = ld32(c.r[9]);  // 06078F2A mov.l @r9,r8
    c.r[0] = ld32(0x06078FDCu);  // 06078F2C mov.l 0x06078FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06078F32u; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F32u) return; }  // 06078F2E jsr @r0 ; add r1,r8
    c.r[1] = c.r[0];  // 06078F32 mov r0,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06078F34 extu.b r1,r6
    c.r[6] += 1;  // 06078F36 add #1,r6
    c.r[1] = ld32(0x06078FE0u);  // 06078F38 mov.l 0x06078FE0,r1
    c.r[5] = c.r[12];  // 06078F3A mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06078F40u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F40u) return; }  // 06078F3C jsr @r1 ; mov r8,r4
    c.r[1] = ld32(c.r[9]);  // 06078F40 mov.l @r9,r1
    c.r[5] = 0xDu;  // 06078F42 mov #13,r5
    c.r[0] = c.r[1];  // 06078F44 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 06078F46 mov.w @(r0,r13),r8
    c.r[4] = c.r[11];  // 06078F48 mov r11,r4
    c.r[8] = c.r[8] & 0xFFFFu;  // 06078F4A extu.w r8,r8
    c.r[8] >>= 2;  // 06078F4C shlr2 r8
    c.r[8] >>= 2;  // 06078F4E shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06078F50 shlr r8
    { const uint32_t x = c.r[10]; c.pr = 0x06078F56u; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F56u) return; }  // 06078F52 jsr @r10 ; shlr2 r8
    c.r[1] = c.r[0];  // 06078F56 mov r0,r1
    c.r[5] = c.r[8];  // 06078F58 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06078F5Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F5Eu) return; }  // 06078F5A jsr @r10 ; mov r1,r4
    c.r[12] = c.r[0];  // 06078F5E mov r0,r12
    c.r[8] = (uint32_t)(int16_t)ld16(0x06078FC2u);  // 06078F60 mov.w 0x06078FC2,r8
    c.r[6] = 0x5u;  // 06078F62 mov #5,r6
    c.r[5] = 0x0u;  // 06078F64 mov #0,r5
    c.r[4] = ld32(c.r[9]);  // 06078F66 mov.l @r9,r4
    c.r[0] = ld32(0x06078FE4u);  // 06078F68 mov.l 0x06078FE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06078F6Eu; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078F6Eu) return; }  // 06078F6A jsr @r0 ; add r8,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06078FC4u);  // 06078F6E mov.w 0x06078FC4,r3
    c.r[1] = 0xFFFFFFFFu;  // 06078F70 mov #-1,r1
    c.r[6] = 0x5u;  // 06078F72 mov #5,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x06078FC6u);  // 06078F74 mov.w 0x06078FC6,r7
    c.r[2] = ld32(c.r[9]);  // 06078F76 mov.l @r9,r2
    c.r[5] = c.r[8];  // 06078F78 mov r8,r5
    c.r[0] = c.r[2];  // 06078F7A mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06078F7C mov.b r1,@(r0,r3)
    c.r[3] = 0x0u;  // 06078F7E mov #0,r3
L_06078F80:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06078F80 mov.b @r12,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06078F82 extu.b r2,r1
    c.t = c.r[1] == c.r[7];  // 06078F84 cmp/eq r7,r1
    if (c.t) { goto L_06078F98; }  // 06078F86 bt 0x06078F98
    c.r[1] = ld32(c.r[9]);  // 06078F88 mov.l @r9,r1
    c.r[12] += 1;  // 06078F8A add #1,r12
    c.r[1] += c.r[3];  // 06078F8C add r3,r1
    c.r[0] = c.r[1];  // 06078F8E mov r1,r0
    c.r[3] += 1;  // 06078F90 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 06078F92 cmp/gt r6,r3
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[2]); if (k) { SH2_POLL(c); goto L_06078F80; } }  // 06078F94 bf/s 0x06078F80 ; mov.b r2,@(r0,r5)
L_06078F98:
    c.r[15] = c.r[14];  // 06078F98 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06078F9A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06078F9C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06078F9E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06078FA0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06078FA2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06078FA4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06078FA6 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06078FC8u);  // 06078FA8 mov.w 0x06078FC8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06078FAA rts ; mov.l @r15+,r8
}

void f_06078FE8(SH2Context& c) {
    ran[1662] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06078FE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06078FEA sts.l pr,@-r15
    c.r[1] = ld32(0x06079008u);  // 06078FEC mov.l 0x06079008,r1
    c.r[1] = ld32(c.r[1]);  // 06078FEE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06078FF0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06078FF2 extu.b r1,r0
    c.r[0] <<= 2;  // 06078FF4 shll2 r0
    c.r[1] = ld32(0x0607900Cu);  // 06078FF6 mov.l 0x0607900C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06078FF8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06078FFEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06078FFEu) return; }  // 06078FFA jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06078FFE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06079000 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06079002 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06079004 rts ; extu.w r0,r0
}

void f_06079034(SH2Context& c) {
    ran[1663] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079034 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06079036 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06079038 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607903A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607903C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607903E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079040 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06079042 sts.l pr,@-r15
    c.r[1] = ld32(0x060791BCu);  // 06079044 mov.l 0x060791BC,r1
    c.r[1] = ld32(c.r[1]);  // 06079046 mov.l @r1,r1
    c.r[15] -= 20;  // 06079048 add #-20,r15
    c.r[1] += 1;  // 0607904A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607904C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607904E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06079050 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06079096; } }  // 06079052 bt/s 0x06079096 ; mov r15,r14
    c.r[3] = ld32(0x060791C0u);  // 06079056 mov.l 0x060791C0,r3
    c.r[7] = c.r[3];  // 06079058 mov r3,r7
    c.r[7] += 88;  // 0607905A add #88,r7
    c.r[2] = c.r[3];  // 0607905C mov r3,r2
    c.r[2] += 92;  // 0607905E add #92,r2
    c.r[1] = ld32(0x060791C4u);  // 06079060 mov.l 0x060791C4,r1
    st32(c.r[2], c.r[1]);  // 06079062 mov.l r1,@r2
    st32(c.r[7], c.r[1]);  // 06079064 mov.l r1,@r7
    c.r[2] = c.r[3];  // 06079066 mov r3,r2
    c.r[2] += 80;  // 06079068 add #80,r2
    c.r[1] = ld32(0x060791C8u);  // 0607906A mov.l 0x060791C8,r1
    c.r[3] += 84;  // 0607906C add #84,r3
    c.r[8] = ld32(0x060791CCu);  // 0607906E mov.l 0x060791CC,r8
    c.r[6] = ld32(0x060791D0u);  // 06079070 mov.l 0x060791D0,r6
    c.r[5] = ld32(0x060791D4u);  // 06079072 mov.l 0x060791D4,r5
    c.r[1] = ld32(c.r[1]);  // 06079074 mov.l @r1,r1
    c.r[4] = ld32(0x060791D8u);  // 06079076 mov.l 0x060791D8,r4
    st32(c.r[2], c.r[1]);  // 06079078 mov.l r1,@r2
    c.r[1] = ld32(0x060791DCu);  // 0607907A mov.l 0x060791DC,r1
    c.r[1] = ld32(c.r[1]);  // 0607907C mov.l @r1,r1
    st32(c.r[3], c.r[1]);  // 0607907E mov.l r1,@r3
    c.r[1] = 0x1u;  // 06079080 mov #1,r1
    st8(c.r[8], c.r[1]);  // 06079082 mov.b r1,@r8
    c.r[1] = ld32(0x060791E0u);  // 06079084 mov.l 0x060791E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607908Au; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607908Au) return; }  // 06079086 jsr @r1 ; mov #14,r7
    c.r[1] = ld32(0x060791E4u);  // 0607908A mov.l 0x060791E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06079090u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079090u) return; }  // 0607908C jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06079090 mov #0,r1
    st8(c.r[8], c.r[1]); goto L_06079418;  // 06079092 bra 0x06079418 ; mov.b r1,@r8
L_06079096:
    c.r[9] = ld32(0x060791CCu);  // 06079096 mov.l 0x060791CC,r9
    c.r[1] = 0x1u;  // 06079098 mov #1,r1
    st8(c.r[9], c.r[1]);  // 0607909A mov.b r1,@r9
    c.r[6] = ld32(0x060791D0u);  // 0607909C mov.l 0x060791D0,r6
    c.r[5] = ld32(0x060791D8u);  // 0607909E mov.l 0x060791D8,r5
    c.r[8] = ld32(0x060791D4u);  // 060790A0 mov.l 0x060791D4,r8
    c.r[1] = ld32(0x060791E0u);  // 060790A2 mov.l 0x060791E0,r1
    c.r[7] = 0xEu;  // 060790A4 mov #14,r7
    { const uint32_t x = c.r[1]; c.pr = 0x060790AAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060790AAu) return; }  // 060790A6 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060791E4u);  // 060790AA mov.l 0x060791E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060790B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060790B0u) return; }  // 060790AC jsr @r1 ; nop
    c.r[1] = 0x0u;  // 060790B0 mov #0,r1
    st8(c.r[9], c.r[1]);  // 060790B2 mov.b r1,@r9
    c.r[4] = 0x0u;  // 060790B4 mov #0,r4
    c.r[11] = ld32(0x060791C0u);  // 060790B6 mov.l 0x060791C0,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x060791A4u);  // 060790B8 mov.w 0x060791A4,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x060791A6u);  // 060790BA mov.w 0x060791A6,r9
    c.r[5] = (uint32_t)(int16_t)ld16(0x060791A8u);  // 060790BC mov.w 0x060791A8,r5
L_060790BE:
    c.r[6] = 0x0u;  // 060790BE mov #0,r6
    c.r[12] = (uint32_t)(int16_t)ld16(0x060791AAu);  // 060790C0 mov.w 0x060791AA,r12
    c.r[7] = 0x0u;  // 060790C2 mov #0,r7
    c.r[3] = c.r[8];  // 060790C4 mov r8,r3
    c.r[3] += 2;  // 060790C6 add #2,r3
L_060790C8:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060790C8 mov.w @r8,r2
    c.r[0] = c.r[11];  // 060790CA mov r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 060790CC mov.w @(r0,r10),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060790CE extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060790D0 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 060790D2 cmp/eq r1,r2
    if (!c.t) { goto L_060790EC; }  // 060790D4 bf 0x060790EC
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060790D6 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 060790D8 mov.w @(r0,r9),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060790DA extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060790DC extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 060790DE cmp/eq r1,r2
    if (!c.t) { goto L_060790EC; }  // 060790E0 bf 0x060790EC
    c.r[0] = c.r[8];  // 060790E2 mov r8,r0
    st16(c.r[0] + c.r[12], c.r[7]);  // 060790E4 mov.w r7,@(r0,r12)
    st16(c.r[0] + c.r[5], c.r[7]);  // 060790E6 mov.w r7,@(r0,r5)
    st16(c.r[3], c.r[7]);  // 060790E8 mov.w r7,@r3
    st16(c.r[8], c.r[7]);  // 060790EA mov.w r7,@r8
L_060790EC:
    c.r[6] += 1;  // 060790EC add #1,r6
    c.r[3] += 4;  // 060790EE add #4,r3
    c.r[2] = 0x1Fu;  // 060790F0 mov #31,r2
    c.t = (int32_t)c.r[6] > (int32_t)c.r[2];  // 060790F2 cmp/gt r2,r6
    { const bool k = !c.t; c.r[8] += 4; if (k) { SH2_POLL(c); goto L_060790C8; } }  // 060790F4 bf/s 0x060790C8 ; add #4,r8
    c.r[4] += 1;  // 060790F8 add #1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060791ACu);  // 060790FA mov.w 0x060791AC,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 060790FC cmp/gt r1,r4
    { const bool k = !c.t; c.r[8] += c.r[5]; if (k) { SH2_POLL(c); goto L_060790BE; } }  // 060790FE bf/s 0x060790BE ; add r5,r8
    c.r[4] = 0x0u;  // 06079102 mov #0,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x060791AEu);  // 06079104 mov.w 0x060791AE,r12
    c.r[11] = c.r[2];  // 06079106 mov r2,r11
    c.r[9] = (uint32_t)(int16_t)ld16(0x060791A8u);  // 06079108 mov.w 0x060791A8,r9
    c.r[10] = 0x3Fu;  // 0607910A mov #63,r10
    c.r[5] = 0x0u;  // 0607910C mov #0,r5
L_0607910E:
    c.r[6] = 0x0u;  // 0607910E mov #0,r6
L_06079110:
    c.r[1] = ld32(0x060791E8u);  // 06079110 mov.l 0x060791E8,r1
    c.r[0] = ld32(c.r[1]);  // 06079112 mov.l @r1,r0
    c.r[0] += c.r[5];  // 06079114 add r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06079116 mov.b @(r0,r6),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06079118 extu.b r1,r2
    c.t = c.r[2] == c.r[12];  // 0607911A cmp/eq r12,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0607920C; } }  // 0607911C bt/s 0x0607920C ; shll2 r2
    c.r[1] = ld32(0x060791ECu);  // 06079120 mov.l 0x060791EC,r1
    c.r[2] <<= 2;  // 06079122 shll2 r2
    c.r[3] = ld32(c.r[1]);  // 06079124 mov.l @r1,r3
    c.r[7] = c.r[2];  // 06079126 mov r2,r7
    st32(c.r[14] + 16, c.r[2]);  // 06079128 mov.l r2,@(16,r14)
    c.r[7] += c.r[3];  // 0607912A add r3,r7
    c.r[1] = c.r[7];  // 0607912C mov r7,r1
    c.r[1] += 1;  // 0607912E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079130 mov.b @r1,r1
    c.r[8] = ld32(0x060791D4u);  // 06079132 mov.l 0x060791D4,r8
    c.r[2] = c.r[1] & 0xFFu;  // 06079134 extu.b r1,r2
    c.t = c.r[2] > c.r[11];  // 06079136 cmp/hi r11,r2
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 16); if (k) { goto L_06079140; } }  // 06079138 bf/s 0x06079140 ; mov.l @(16,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060791B0u);  // 0607913C mov.w 0x060791B0,r1
    c.r[8] += c.r[1];  // 0607913E add r1,r8
L_06079140:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06079140 mov.b @(r0,r3),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06079142 extu.b r1,r3
    c.t = c.r[3] > c.r[11];  // 06079144 cmp/hi r11,r3
    { const bool k = !c.t; c.r[1] = 0x1Fu; if (k) { goto L_06079150; } }  // 06079146 bf/s 0x06079150 ; mov #31,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x060791B2u);  // 0607914A mov.w 0x060791B2,r1
    c.r[8] += c.r[1];  // 0607914C add r1,r8
    c.r[1] = 0x1Fu;  // 0607914E mov #31,r1
L_06079150:
    c.r[2] &= c.r[1];  // 06079150 and r1,r2
    c.r[3] &= c.r[1];  // 06079152 and r1,r3
    c.r[3] += c.r[3];  // 06079154 add r3,r3
    c.r[7] += 3;  // 06079156 add #3,r7
    c.r[0] = 0xFu;  // 06079158 mov #15,r0
    c.r[0] += c.r[14];  // 0607915A add r14,r0
    c.r[1] = 0xFu;  // 0607915C mov #15,r1
    c.r[1] += c.r[14];  // 0607915E add r14,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06079160 mov.b @r7,r7
    c.macl = c.r[2] * c.r[9];  // 06079162 mul.l r9,r2
    st8(c.r[0], c.r[7]);  // 06079164 mov.b r7,@r0
    c.r[13] = c.macl;  // 06079166 sts macl,r13
    c.r[13] += c.r[3];  // 06079168 add r3,r13
    c.r[13] += c.r[13];  // 0607916A add r13,r13
    c.r[8] += c.r[13];  // 0607916C add r13,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607916E mov.b @r1,r2
    c.r[13] = 0x3u;  // 06079170 mov #3,r13
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06079172 shlr r2
    c.r[2] &= c.r[13];  // 06079174 and r13,r2
    c.r[0] = c.r[2];  // 06079176 mov r2,r0
    c.t = c.r[0] == 0x1u;  // 06079178 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06079198; } }  // 0607917A bt/s 0x06079198 ; mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607917E cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0607918C; } }  // 06079180 bt/s 0x0607918C ; cmp/eq #2,r0
    c.t = (c.r[2] & c.r[2]) == 0;  // 06079184 tst r2,r2
    if (!c.t) { goto L_060791F0; }  // 06079186 bf 0x060791F0
    goto L_06079192;  // 06079188 bra 0x06079192 ; nop
L_0607918C:
    if (!c.t) { goto L_060791F0; }  // 0607918C bf 0x060791F0
    goto L_0607919E;  // 0607918E bra 0x0607919E ; nop
L_06079192:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060791B4u);  // 06079192 mov.w 0x060791B4,r3
    st16(c.r[8], c.r[3]); goto L_060791F4;  // 06079194 bra 0x060791F4 ; mov.w r3,@r8
L_06079198:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060791B6u);  // 06079198 mov.w 0x060791B6,r3
    st16(c.r[8], c.r[3]); goto L_060791F4;  // 0607919A bra 0x060791F4 ; mov.w r3,@r8
L_0607919E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060791B8u);  // 0607919E mov.w 0x060791B8,r3
    st16(c.r[8], c.r[3]); goto L_060791F4;  // 060791A0 bra 0x060791F4 ; mov.w r3,@r8
L_060791F0:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06079394u);  // 060791F0 mov.w 0x06079394,r3
    st16(c.r[8], c.r[3]);  // 060791F2 mov.w r3,@r8
L_060791F4:
    c.r[1] = c.r[8];  // 060791F4 mov r8,r1
    c.r[1] += 2;  // 060791F6 add #2,r1
    c.r[2] = c.r[3];  // 060791F8 mov r3,r2
    c.r[2] += 1;  // 060791FA add #1,r2
    st16(c.r[1], c.r[2]);  // 060791FC mov.w r2,@r1
    c.r[1] = c.r[3];  // 060791FE mov r3,r1
    c.r[1] += 2;  // 06079200 add #2,r1
    c.r[0] = c.r[8];  // 06079202 mov r8,r0
    st16(c.r[0] + c.r[9], c.r[1]);  // 06079204 mov.w r1,@(r0,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079396u);  // 06079206 mov.w 0x06079396,r1
    c.r[3] += 3;  // 06079208 add #3,r3
    st16(c.r[0] + c.r[1], c.r[3]);  // 0607920A mov.w r3,@(r0,r1)
L_0607920C:
    c.r[6] += 1;  // 0607920C add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[10];  // 0607920E cmp/gt r10,r6
    if (c.t) { goto L_06079216; }  // 06079210 bt 0x06079216
    SH2_POLL(c); goto L_06079110;  // 06079212 bra 0x06079110 ; nop
L_06079216:
    c.r[4] += 1;  // 06079216 add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[10];  // 06079218 cmp/gt r10,r4
    { const bool k = c.t; c.r[5] += 64; if (k) { goto L_06079222; } }  // 0607921A bt/s 0x06079222 ; add #64,r5
    SH2_POLL(c); goto L_0607910E;  // 0607921E bra 0x0607910E ; nop
L_06079222:
    c.r[9] = ld32(0x06079398u);  // 06079222 mov.l 0x06079398,r9
    c.r[1] = ld32(0x0607939Cu);  // 06079224 mov.l 0x0607939C,r1
    c.r[0] = 0xCu;  // 06079226 mov #12,r0
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079228 mov.b @r1,r13
    c.r[0] += c.r[14];  // 0607922A add r14,r0
    c.r[1] = 0xCu;  // 0607922C mov #12,r1
    c.r[1] += c.r[14];  // 0607922E add r14,r1
    st8(c.r[1], c.r[13]);  // 06079230 mov.b r13,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06079232 mov.b @r0,r0
    c.r[1] = ld32(0x060793A0u);  // 06079234 mov.l 0x060793A0,r1
    c.r[0] = c.r[0] & 0xFFu;  // 06079236 extu.b r0,r0
    st32(c.r[14] + 4, c.r[0]);  // 06079238 mov.l r0,@(4,r14)
    c.r[4] = c.r[0];  // 0607923A mov r0,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06079240u; c.r[4] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079240u) return; }  // 0607923C jsr @r1 ; add #1,r4
    c.r[2] = c.r[0];  // 06079240 mov r0,r2
    c.r[13] = ld32(0x060793A4u);  // 06079242 mov.l 0x060793A4,r13
    c.r[8] = ld32(0x060793A8u);  // 06079244 mov.l 0x060793A8,r8
    c.r[5] = ld32(c.r[13]);  // 06079246 mov.l @r13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607924Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607924Cu) return; }  // 06079248 jsr @r8 ; mov r2,r4
    c.r[11] = c.r[0];  // 0607924C mov r0,r11
    c.r[0] = ld32(0x060793ACu);  // 0607924E mov.l 0x060793AC,r0
    c.r[13] = 0xCu;  // 06079250 mov #12,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06079252 mov.b @r0,r1
    c.r[13] += c.r[14];  // 06079254 add r14,r13
    c.r[0] = 0xCu;  // 06079256 mov #12,r0
    st8(c.r[0] + c.r[14], c.r[1]);  // 06079258 mov.b r1,@(r0,r14)
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0607925A mov.b @r13,r13
    c.r[0] = ld32(0x060793A0u);  // 0607925C mov.l 0x060793A0,r0
    c.r[13] = c.r[13] & 0xFFu;  // 0607925E extu.b r13,r13
    st32(c.r[14] + 8, c.r[13]);  // 06079260 mov.l r13,@(8,r14)
    c.r[4] = c.r[13];  // 06079262 mov r13,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06079268u; c.r[4] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079268u) return; }  // 06079264 jsr @r0 ; add #1,r4
    c.r[2] = c.r[0];  // 06079268 mov r0,r2
    c.r[1] = ld32(0x060793B0u);  // 0607926A mov.l 0x060793B0,r1
    c.r[5] = ld32(c.r[1]);  // 0607926C mov.l @r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06079272u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079272u) return; }  // 0607926E jsr @r8 ; mov r2,r4
    st32(c.r[14], c.r[0]);  // 06079272 mov.l r0,@r14
    c.r[4] = c.r[11];  // 06079274 mov r11,r4
    c.r[13] = ld32(0x060793B4u);  // 06079276 mov.l 0x060793B4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0607927Cu; c.r[5] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607927Cu) return; }  // 06079278 jsr @r13 ; mov.l @r14,r5
    c.r[2] = c.r[0];  // 0607927C mov r0,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0607927E cmp/pz r2
    if (c.t) { goto L_06079284; }  // 06079280 bt 0x06079284
    c.r[11] = ld32(c.r[14]);  // 06079282 mov.l @r14,r11
L_06079284:
    c.r[8] = c.r[9];  // 06079284 mov r9,r8
    c.r[8] += 88;  // 06079286 add #88,r8
    c.r[0] = ld32(0x060793B8u);  // 06079288 mov.l 0x060793B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607928Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607928Eu) return; }  // 0607928A jsr @r0 ; mov r11,r4
    c.r[4] = c.r[0];  // 0607928E mov r0,r4
    c.r[5] = c.r[1];  // 06079290 mov r1,r5
    c.r[1] = ld32(0x060793BCu);  // 06079292 mov.l 0x060793BC,r1
    c.r[6] = ld32(c.r[1]);  // 06079294 mov.l @r1,r6
    c.r[13] = ld32(0x060793C0u);  // 06079296 mov.l 0x060793C0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0607929Cu; c.r[7] = ld32(c.r[1] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607929Cu) return; }  // 06079298 jsr @r13 ; mov.l @(4,r1),r7
    c.r[4] = c.r[0];  // 0607929C mov r0,r4
    c.r[5] = c.r[1];  // 0607929E mov r1,r5
    c.r[0] = ld32(0x060793C4u);  // 060792A0 mov.l 0x060793C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060792A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792A6u) return; }  // 060792A2 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 060792A6 mov r0,r2
    st32(c.r[8], c.r[2]);  // 060792A8 mov.l r2,@r8
    c.r[8] = c.r[9];  // 060792AA mov r9,r8
    c.r[8] += 92;  // 060792AC add #92,r8
    c.r[1] = ld32(0x060793B8u);  // 060792AE mov.l 0x060793B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060792B4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792B4u) return; }  // 060792B0 jsr @r1 ; mov r11,r4
    c.r[4] = c.r[0];  // 060792B4 mov r0,r4
    c.r[5] = c.r[1];  // 060792B6 mov r1,r5
    c.r[13] = ld32(0x060793BCu);  // 060792B8 mov.l 0x060793BC,r13
    c.r[6] = ld32(c.r[13]);  // 060792BA mov.l @r13,r6
    c.r[0] = ld32(0x060793C0u);  // 060792BC mov.l 0x060793C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060792C2u; c.r[7] = ld32(c.r[13] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792C2u) return; }  // 060792BE jsr @r0 ; mov.l @(4,r13),r7
    c.r[4] = c.r[0];  // 060792C2 mov r0,r4
    c.r[5] = c.r[1];  // 060792C4 mov r1,r5
    c.r[1] = ld32(0x060793C4u);  // 060792C6 mov.l 0x060793C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060792CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792CCu) return; }  // 060792C8 jsr @r1 ; nop
    c.r[2] = c.r[0];  // 060792CC mov r0,r2
    st32(c.r[8], c.r[2]);  // 060792CE mov.l r2,@r8
    c.r[2] = ld32(0x060793C8u);  // 060792D0 mov.l 0x060793C8,r2
    c.r[13] = ld32(0x060793CCu);  // 060792D2 mov.l 0x060793CC,r13
    c.r[0] = ld32(0x060793D0u);  // 060792D4 mov.l 0x060793D0,r0
    c.r[8] = ld32(0x060793D4u);  // 060792D6 mov.l 0x060793D4,r8
    c.r[13] = ld32(c.r[13]);  // 060792D8 mov.l @r13,r13
    c.r[1] = ld32(0x060793D8u);  // 060792DA mov.l 0x060793D8,r1
    st32(c.r[2], c.r[13]);  // 060792DC mov.l r13,@r2
    c.r[0] = ld32(c.r[0]);  // 060792DE mov.l @r0,r0
    c.r[2] = ld32(0x060793DCu);  // 060792E0 mov.l 0x060793DC,r2
    st32(c.r[2], c.r[0]);  // 060792E2 mov.l r0,@r2
    c.r[5] = ld32(c.r[1]);  // 060792E4 mov.l @r1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060792EAu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792EAu) return; }  // 060792E6 jsr @r8 ; mov r11,r4
    c.r[2] = c.r[0];  // 060792EA mov r0,r2
    c.r[13] = ld32(0x060793E0u);  // 060792EC mov.l 0x060793E0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060792F2u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792F2u) return; }  // 060792EE jsr @r13 ; mov r2,r4
    c.r[2] = c.r[0];  // 060792F2 mov r0,r2
    c.r[0] = ld32(0x060793E4u);  // 060792F4 mov.l 0x060793E4,r0
    c.r[9] = ld32(0x060793E8u);  // 060792F6 mov.l 0x060793E8,r9
    c.r[5] = ld32(c.r[0]);  // 060792F8 mov.l @r0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060792FEu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060792FEu) return; }  // 060792FA jsr @r9 ; mov r2,r4
    st32(c.r[14], c.r[0]);  // 060792FE mov.l r0,@r14
    c.r[1] = ld32(0x060793ECu);  // 06079300 mov.l 0x060793EC,r1
    c.r[5] = ld32(c.r[1]);  // 06079302 mov.l @r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06079308u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079308u) return; }  // 06079304 jsr @r9 ; mov r11,r4
    st32(c.r[14] + 16, c.r[0]);  // 06079308 mov.l r0,@(16,r14)
    c.r[13] = ld32(0x060793A0u);  // 0607930A mov.l 0x060793A0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06079310u; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079310u) return; }  // 0607930C jsr @r13 ; mov.l @(4,r14),r4
    c.r[2] = c.r[0];  // 06079310 mov r0,r2
    c.r[4] = ld32(c.r[14] + 16);  // 06079312 mov.l @(16,r14),r4
    { const uint32_t x = c.r[8]; c.pr = 0x06079318u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079318u) return; }  // 06079314 jsr @r8 ; mov r2,r5
    c.r[2] = c.r[0];  // 06079318 mov r0,r2
    c.r[0] = ld32(0x060793D8u);  // 0607931A mov.l 0x060793D8,r0
    c.r[5] = ld32(c.r[0]);  // 0607931C mov.l @r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06079322u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079322u) return; }  // 0607931E jsr @r8 ; mov r2,r4
    c.r[2] = c.r[0];  // 06079322 mov r0,r2
    c.r[1] = ld32(0x060793F0u);  // 06079324 mov.l 0x060793F0,r1
    c.r[5] = ld32(c.r[1]);  // 06079326 mov.l @r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607932Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607932Cu) return; }  // 06079328 jsr @r9 ; mov r2,r4
    c.r[2] = c.r[0];  // 0607932C mov r0,r2
    c.r[4] = ld32(c.r[14]);  // 0607932E mov.l @r14,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06079334u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079334u) return; }  // 06079330 jsr @r8 ; mov r2,r5
    c.r[2] = c.r[0];  // 06079334 mov r0,r2
    c.r[13] = ld32(0x060793B8u);  // 06079336 mov.l 0x060793B8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0607933Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607933Cu) return; }  // 06079338 jsr @r13 ; mov r2,r4
    c.r[4] = c.r[0];  // 0607933C mov r0,r4
    c.r[5] = c.r[1];  // 0607933E mov r1,r5
    c.r[0] = ld32(0x060793BCu);  // 06079340 mov.l 0x060793BC,r0
    c.r[6] = ld32(c.r[0]);  // 06079342 mov.l @r0,r6
    c.r[1] = ld32(0x060793C0u);  // 06079344 mov.l 0x060793C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607934Au; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607934Au) return; }  // 06079346 jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 0607934A mov r0,r4
    c.r[13] = ld32(0x060793C4u);  // 0607934C mov.l 0x060793C4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06079352u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079352u) return; }  // 0607934E jsr @r13 ; mov r1,r5
    c.r[2] = c.r[0];  // 06079352 mov r0,r2
    c.r[0] = ld32(0x060793CCu);  // 06079354 mov.l 0x060793CC,r0
    st32(c.r[0], c.r[2]);  // 06079356 mov.l r2,@r0
    c.r[1] = ld32(0x060793F4u);  // 06079358 mov.l 0x060793F4,r1
    c.r[5] = ld32(c.r[1]);  // 0607935A mov.l @r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06079360u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079360u) return; }  // 0607935C jsr @r9 ; mov r11,r4
    c.r[12] = c.r[0];  // 06079360 mov r0,r12
    c.r[13] = ld32(0x060793A0u);  // 06079362 mov.l 0x060793A0,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06079368u; c.r[4] = ld32(c.r[14] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079368u) return; }  // 06079364 jsr @r13 ; mov.l @(8,r14),r4
    c.r[2] = c.r[0];  // 06079368 mov r0,r2
    c.r[5] = c.r[2];  // 0607936A mov r2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06079370u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079370u) return; }  // 0607936C jsr @r8 ; mov r12,r4
    c.r[2] = c.r[0];  // 06079370 mov r0,r2
    c.r[0] = ld32(0x060793D8u);  // 06079372 mov.l 0x060793D8,r0
    c.r[5] = ld32(c.r[0]);  // 06079374 mov.l @r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607937Au; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607937Au) return; }  // 06079376 jsr @r8 ; mov r2,r4
    c.r[2] = c.r[0];  // 0607937A mov r0,r2
    c.r[1] = ld32(0x060793F0u);  // 0607937C mov.l 0x060793F0,r1
    c.r[5] = ld32(c.r[1]);  // 0607937E mov.l @r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06079384u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079384u) return; }  // 06079380 jsr @r9 ; mov r2,r4
    c.r[2] = c.r[0];  // 06079384 mov r0,r2
    c.r[4] = ld32(c.r[14]);  // 06079386 mov.l @r14,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0607938Cu; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607938Cu) return; }  // 06079388 jsr @r8 ; mov r2,r5
    c.r[2] = c.r[0];  // 0607938C mov r0,r2
    c.r[13] = ld32(0x060793B8u);  // 0607938E mov.l 0x060793B8,r13
    c.r[4] = c.r[2]; goto L_060793F8;  // 06079390 bra 0x060793F8 ; mov r2,r4
L_060793F8:
    { const uint32_t x = c.r[13]; c.pr = 0x060793FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060793FCu) return; }  // 060793F8 jsr @r13 ; nop
    c.r[4] = c.r[0];  // 060793FC mov r0,r4
    c.r[5] = c.r[1];  // 060793FE mov r1,r5
    c.r[0] = ld32(0x06079434u);  // 06079400 mov.l 0x06079434,r0
    c.r[6] = ld32(c.r[0]);  // 06079402 mov.l @r0,r6
    c.r[1] = ld32(0x06079438u);  // 06079404 mov.l 0x06079438,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607940Au; c.r[7] = ld32(c.r[0] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607940Au) return; }  // 06079406 jsr @r1 ; mov.l @(4,r0),r7
    c.r[4] = c.r[0];  // 0607940A mov r0,r4
    c.r[13] = ld32(0x0607943Cu);  // 0607940C mov.l 0x0607943C,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06079412u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079412u) return; }  // 0607940E jsr @r13 ; mov r1,r5
    c.r[2] = c.r[0];  // 06079412 mov r0,r2
    c.r[0] = ld32(0x06079440u);  // 06079414 mov.l 0x06079440,r0
    st32(c.r[0], c.r[2]);  // 06079416 mov.l r2,@r0
L_06079418:
    c.r[14] += 20;  // 06079418 add #20,r14
    c.r[15] = c.r[14];  // 0607941A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607941C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607941E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06079420 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06079422 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06079424 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06079426 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06079428 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079430u);  // 0607942A mov.w 0x06079430,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607942C rts ; mov.l @r15+,r8
}

void f_06079444(SH2Context& c) {
    ran[1664] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079444 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06079446 sts.l pr,@-r15
    c.r[1] = ld32(0x06079464u);  // 06079448 mov.l 0x06079464,r1
    c.r[1] = ld32(c.r[1]);  // 0607944A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607944C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607944E extu.b r1,r0
    c.r[0] <<= 2;  // 06079450 shll2 r0
    c.r[1] = ld32(0x06079468u);  // 06079452 mov.l 0x06079468,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06079454 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607945Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607945Au) return; }  // 06079456 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0607945A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607945C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607945E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06079460 rts ; extu.w r0,r0
}

void f_0607946C(SH2Context& c) {
    ran[1665] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607946C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607946E sts.l pr,@-r15
    c.r[1] = ld32(0x0607949Cu);  // 06079470 mov.l 0x0607949C,r1
    c.r[1] = ld32(c.r[1]);  // 06079472 mov.l @r1,r1
    c.r[14] = c.r[15];  // 06079474 mov r15,r14
    c.r[1] += 18;  // 06079476 add #18,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079478 mov.w @r1,r4
    c.r[0] = ld32(0x060794A0u);  // 0607947A mov.l 0x060794A0,r0
    c.r[4] <<= 16;  // 0607947C shll16 r4
    c.r[4] <<= 2;  // 0607947E shll2 r4
    c.r[4] += c.r[4];  // 06079480 add r4,r4
    c.r[4] <<= 2;  // 06079482 shll2 r4
    c.r[4] >>= 16;  // 06079484 shlr16 r4
    c.r[4] <<= 2;  // 06079486 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607948Cu; c.r[4] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607948Cu) return; }  // 06079488 jsr @r0 ; shlr8 r4
    c.r[1] = ld32(0x060794A4u);  // 0607948C mov.l 0x060794A4,r1
    st8(c.r[1], c.r[0]);  // 0607948E mov.b r0,@r1
    c.r[15] = c.r[14];  // 06079490 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06079492 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607949Au);  // 06079494 mov.w 0x0607949A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079496 rts ; mov.l @r15+,r14
}

void f_060794A8(SH2Context& c) {
    ran[1666] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060794A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060794AA sts.l pr,@-r15
    c.r[1] = ld32(0x060794C8u);  // 060794AC mov.l 0x060794C8,r1
    c.r[1] = ld32(c.r[1]);  // 060794AE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060794B0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060794B2 extu.b r1,r0
    c.r[0] <<= 2;  // 060794B4 shll2 r0
    c.r[1] = ld32(0x060794CCu);  // 060794B6 mov.l 0x060794CC,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060794B8 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060794BEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060794BEu) return; }  // 060794BA jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060794BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060794C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060794C2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060794C4 rts ; extu.w r0,r0
}

void f_060794D0(SH2Context& c) {
    ran[1667] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060794D0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060794D2 mov r15,r14
    c.r[2] = ld32(0x060794E4u);  // 060794D4 mov.l 0x060794E4,r2
    c.r[1] = 0x0u;  // 060794D6 mov #0,r1
    st8(c.r[2], c.r[1]);  // 060794D8 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060794E0u);  // 060794DA mov.w 0x060794E0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060794DC rts ; mov.l @r15+,r14
}

void f_060794E8(SH2Context& c) {
    ran[1668] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060794E8 mov.l r14,@-r15
    c.r[3] = ld32(0x060795A0u);  // 060794EA mov.l 0x060795A0,r3
    c.r[0] = ld32(0x060795A4u);  // 060794EC mov.l 0x060795A4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060794EE mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607959Au);  // 060794F0 mov.w 0x0607959A,r2
    c.r[0] &= c.r[1];  // 060794F2 and r1,r0
    c.r[1] &= c.r[2];  // 060794F4 and r2,r1
    st16(c.r[3], c.r[1]);  // 060794F6 mov.w r1,@r3
    c.r[2] = ld32(0x060795A8u);  // 060794F8 mov.l 0x060795A8,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060794FA mov.b @r2,r3
    c.r[2] = c.r[3] & 0xFFu;  // 060794FC extu.b r3,r2
    c.t = c.r[2] == c.r[1];  // 060794FE cmp/eq r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06079510; } }  // 06079500 bf/s 0x06079510 ; mov r15,r14
    c.t = (c.r[0] & c.r[0]) == 0;  // 06079504 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3] & 0xFFu; if (k) { goto L_06079510; } }  // 06079506 bf/s 0x06079510 ; extu.b r3,r0
    c.r[0] += c.r[0];  // 0607950A add r0,r0
    c.r[0] += 1; goto L_0607951C;  // 0607950C bra 0x0607951C ; add #1,r0
L_06079510:
    c.r[2] = ld32(0x060795ACu);  // 06079510 mov.l 0x060795AC,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079512 mov.b @r2,r2
    c.r[1] = ld32(0x060795A8u);  // 06079514 mov.l 0x060795A8,r1
    st8(c.r[1], c.r[2]);  // 06079516 mov.b r2,@r1
    c.r[0] = c.r[2] & 0xFFu;  // 06079518 extu.b r2,r0
    c.r[0] += c.r[0];  // 0607951A add r0,r0
L_0607951C:
    c.r[2] = ld32(0x060795B0u);  // 0607951C mov.l 0x060795B0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607951E mov.w @r2,r1
    c.r[1] -= 1;  // 06079520 add #-1,r1
    st16(c.r[2], c.r[1]);  // 06079522 mov.w r1,@r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06079524 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06079526 tst r1,r1
    if (!c.t) { goto L_0607955C; }  // 06079528 bf 0x0607955C
    c.r[2] = ld32(0x060795B4u);  // 0607952A mov.l 0x060795B4,r2
    c.r[3] = c.r[2];  // 0607952C mov r2,r3
    c.r[3] += 68;  // 0607952E add #68,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079530 mov.b @r3,r7
    c.r[1] = c.r[7];  // 06079532 mov r7,r1
    c.r[1] += 1;  // 06079534 add #1,r1
    st8(c.r[3], c.r[1]);  // 06079536 mov.b r1,@r3
    c.r[7] = c.r[7] & 0xFFu;  // 06079538 extu.b r7,r7
    c.r[7] <<= 2;  // 0607953A shll2 r7
    c.r[3] = ld32(c.r[2]);  // 0607953C mov.l @r2,r3
    c.r[7] += c.r[2];  // 0607953E add r2,r7
    c.r[1] = c.r[3];  // 06079540 mov r3,r1
    c.r[1] += 3;  // 06079542 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079544 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06079546 extu.b r2,r2
    c.r[2] <<= 8;  // 06079548 shll8 r2
    c.r[1] = c.r[3];  // 0607954A mov r3,r1
    c.r[1] += 4;  // 0607954C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607954E mov.b @r1,r1
    c.r[0] += c.r[0];  // 06079550 add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06079552 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06079554 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06079556 exts.w r2,r2
    c.r[2] += 3; goto L_0607958C;  // 06079558 bra 0x0607958C ; add #3,r2
L_0607955C:
    c.r[2] = ld32(0x060795B4u);  // 0607955C mov.l 0x060795B4,r2
    c.r[3] = c.r[2];  // 0607955E mov r2,r3
    c.r[3] += 68;  // 06079560 add #68,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079562 mov.b @r3,r7
    c.r[1] = c.r[7];  // 06079564 mov r7,r1
    c.r[1] += 1;  // 06079566 add #1,r1
    st8(c.r[3], c.r[1]);  // 06079568 mov.b r1,@r3
    c.r[7] = c.r[7] & 0xFFu;  // 0607956A extu.b r7,r7
    c.r[7] <<= 2;  // 0607956C shll2 r7
    c.r[3] = ld32(c.r[2]);  // 0607956E mov.l @r2,r3
    c.r[7] += c.r[2];  // 06079570 add r2,r7
    c.r[1] = c.r[3];  // 06079572 mov r3,r1
    c.r[1] += 1;  // 06079574 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079576 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06079578 extu.b r2,r2
    c.r[2] <<= 8;  // 0607957A shll8 r2
    c.r[1] = c.r[3];  // 0607957C mov r3,r1
    c.r[1] += 2;  // 0607957E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079580 mov.b @r1,r1
    c.r[0] += c.r[0];  // 06079582 add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06079584 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06079586 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06079588 exts.w r2,r2
    c.r[2] += 1;  // 0607958A add #1,r2
L_0607958C:
    c.r[3] += c.r[2];  // 0607958C add r2,r3
    st32(c.r[7] + 4, c.r[3]);  // 0607958E mov.l r3,@(4,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607959Cu);  // 06079590 mov.w 0x0607959C,r1
    c.r[0] |= c.r[1];  // 06079592 or r1,r0
    c.r[15] = c.r[14];  // 06079594 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079596 rts ; mov.l @r15+,r14
}

void f_060795B8(SH2Context& c) {
    ran[1669] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060795B8 mov.l r14,@-r15
    c.r[1] = ld32(0x060795F4u);  // 060795BA mov.l 0x060795F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060795BC mov.b @r1,r1
    c.r[3] = ld32(0x060795F8u);  // 060795BE mov.l 0x060795F8,r3
    st8(c.r[3], c.r[1]);  // 060795C0 mov.b r1,@r3
    c.r[2] = c.r[1] & 0xFFu;  // 060795C2 extu.b r1,r2
    c.r[1] = ld32(0x060795FCu);  // 060795C4 mov.l 0x060795FC,r1
    c.r[1] = ld32(c.r[1]);  // 060795C6 mov.l @r1,r1
    c.r[2] <<= 2;  // 060795C8 shll2 r2
    c.r[2] <<= 2;  // 060795CA shll2 r2
    c.r[2] += c.r[1];  // 060795CC add r1,r2
    c.r[1] = c.r[2];  // 060795CE mov r2,r1
    c.r[1] += 4;  // 060795D0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060795D2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060795D4 mov r1,r0
    c.r[0] >>= 2;  // 060795D6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060795D8 shlr r0
    c.r[0] >>= 2;  // 060795DA shlr2 r0
    c.r[0] &= 0x1u;  // 060795DC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060795DE tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060795EA; } }  // 060795E0 bt/s 0x060795EA ; mov r15,r14
    c.r[2] += 6;  // 060795E4 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060795E6 mov.b @r2,r1
    st8(c.r[3], c.r[1]);  // 060795E8 mov.b r1,@r3
L_060795EA:
    c.r[15] = c.r[14];  // 060795EA mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060795F2u);  // 060795EC mov.w 0x060795F2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060795EE rts ; mov.l @r15+,r14
}

void f_06079600(SH2Context& c) {
    ran[1670] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079600 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079602 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06079604 sts.l pr,@-r15
    c.r[1] = ld32(0x06079778u);  // 06079606 mov.l 0x06079778,r1
    c.r[2] = ld32(c.r[1]);  // 06079608 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0607960A mov r2,r1
    c.r[1] += 2;  // 0607960C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607960E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079610 extu.b r1,r1
    c.r[5] = c.r[1];  // 06079612 mov r1,r5
    c.r[5] <<= 8;  // 06079614 shll8 r5
    c.r[1] = c.r[2];  // 06079616 mov r2,r1
    c.r[1] += 3;  // 06079618 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607961A mov.b @r1,r1
    c.r[2] += 1;  // 0607961C add #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607961E extu.b r1,r1
    c.r[5] |= c.r[1];  // 06079620 or r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079622 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06079624 extu.b r1,r8
    c.r[0] = c.r[8];  // 06079626 mov r8,r0
    c.t = c.r[0] == 0x2u;  // 06079628 cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607964A; } }  // 0607962A bt/s 0x0607964A ; mov r15,r14
    c.r[1] = 0x2u;  // 0607962E mov #2,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06079630 cmp/gt r1,r8
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0607963E; } }  // 06079632 bt/s 0x0607963E ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 06079636 cmp/eq #1,r0
    if (!c.t) { goto L_060796A2; }  // 06079638 bf 0x060796A2
    goto L_06079644;  // 0607963A bra 0x06079644 ; nop
L_0607963E:
    if (!c.t) { goto L_060796A2; }  // 0607963E bf 0x060796A2
    goto L_06079662;  // 06079640 bra 0x06079662 ; nop
L_06079644:
    c.r[1] = ld32(0x0607977Cu);  // 06079644 mov.l 0x0607977C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_060796DA;  // 06079646 bra 0x060796DA ; mov.b @r1,r1
L_0607964A:
    c.r[1] = ld32(0x06079780u);  // 0607964A mov.l 0x06079780,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607964C mov.b @r1,r7
    c.r[1] = ld32(0x06079784u);  // 0607964E mov.l 0x06079784,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079650 mov.b @r1,r2
    c.r[3] = ld32(0x06079788u);  // 06079652 mov.l 0x06079788,r3
    c.r[1] = ld32(c.r[3]);  // 06079654 mov.l @r3,r1
    c.r[7] <<= 2;  // 06079656 shll2 r7
    c.r[7] <<= 2;  // 06079658 shll2 r7
    c.r[7] <<= 2;  // 0607965A shll2 r7
    c.r[7] += c.r[1];  // 0607965C add r1,r7
    c.r[0] = c.r[7]; goto L_060796D8;  // 0607965E bra 0x060796D8 ; mov r7,r0
L_06079662:
    c.r[3] = ld32(0x0607978Cu);  // 06079662 mov.l 0x0607978C,r3
    c.r[1] = c.r[3];  // 06079664 mov r3,r1
    c.r[1] += 116;  // 06079666 add #116,r1
    c.r[2] = c.r[3];  // 06079668 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607966A mov.b @r1,r1
    c.r[2] += 78;  // 0607966C add #78,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607966E mov.b @r2,r2
    c.r[6] = ld32(0x06079790u);  // 06079670 mov.l 0x06079790,r6
    c.r[1] += c.r[2];  // 06079672 add r2,r1
    st8(c.r[6], c.r[1]);  // 06079674 mov.b r1,@r6
    c.r[1] = c.r[3];  // 06079676 mov r3,r1
    c.r[1] += 117;  // 06079678 add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607967A mov.b @r1,r1
    c.r[3] += 79;  // 0607967C add #79,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607967E mov.b @r3,r2
    c.r[7] = ld32(0x06079794u);  // 06079680 mov.l 0x06079794,r7
    c.r[1] += c.r[2];  // 06079682 add r2,r1
    st8(c.r[7], c.r[1]);  // 06079684 mov.b r1,@r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06079686 mov.b @r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06079688 mov.b @r6,r2
    c.r[1] = ld32(0x06079788u);  // 0607968A mov.l 0x06079788,r1
    c.r[1] = ld32(c.r[1]);  // 0607968C mov.l @r1,r1
    c.r[3] <<= 2;  // 0607968E shll2 r3
    c.r[3] <<= 2;  // 06079690 shll2 r3
    c.r[3] <<= 2;  // 06079692 shll2 r3
    c.r[3] += c.r[1];  // 06079694 add r1,r3
    c.r[0] = c.r[3];  // 06079696 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06079698 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607969A extu.b r1,r1
    c.r[1] += 74;  // 0607969C add #74,r1
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_060796DC;  // 0607969E bra 0x060796DC ; exts.w r1,r4
L_060796A2:
    c.r[3] = ld32(0x0607978Cu);  // 060796A2 mov.l 0x0607978C,r3
    c.r[1] = c.r[3];  // 060796A4 mov r3,r1
    c.r[1] += 116;  // 060796A6 add #116,r1
    c.r[2] = c.r[3];  // 060796A8 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060796AA mov.b @r1,r1
    c.r[2] += 78;  // 060796AC add #78,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060796AE mov.b @r2,r2
    c.r[6] = ld32(0x06079790u);  // 060796B0 mov.l 0x06079790,r6
    c.r[1] += c.r[2];  // 060796B2 add r2,r1
    st8(c.r[6], c.r[1]);  // 060796B4 mov.b r1,@r6
    c.r[1] = c.r[3];  // 060796B6 mov r3,r1
    c.r[1] += 117;  // 060796B8 add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060796BA mov.b @r1,r1
    c.r[3] += 79;  // 060796BC add #79,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060796BE mov.b @r3,r2
    c.r[7] = ld32(0x06079794u);  // 060796C0 mov.l 0x06079794,r7
    c.r[1] += c.r[2];  // 060796C2 add r2,r1
    st8(c.r[7], c.r[1]);  // 060796C4 mov.b r1,@r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060796C6 mov.b @r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060796C8 mov.b @r6,r2
    c.r[1] = ld32(0x06079788u);  // 060796CA mov.l 0x06079788,r1
    c.r[1] = ld32(c.r[1]);  // 060796CC mov.l @r1,r1
    c.r[3] <<= 2;  // 060796CE shll2 r3
    c.r[3] <<= 2;  // 060796D0 shll2 r3
    c.r[3] <<= 2;  // 060796D2 shll2 r3
    c.r[3] += c.r[1];  // 060796D4 add r1,r3
    c.r[0] = c.r[3];  // 060796D6 mov r3,r0
L_060796D8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060796D8 mov.b @(r0,r2),r1
L_060796DA:
    c.r[4] = c.r[1] & 0xFFu;  // 060796DA extu.b r1,r4
L_060796DC:
    c.r[0] = c.r[8];  // 060796DC mov r8,r0
    c.t = c.r[0] == 0x3u;  // 060796DE cmp/eq #3,r0
    if (c.t) { goto L_0607973C; }  // 060796E0 bt 0x0607973C
    c.r[1] = ld32(0x06079798u);  // 060796E2 mov.l 0x06079798,r1
    c.r[2] = ld32(c.r[1]);  // 060796E4 mov.l @r1,r2
    c.r[1] = c.r[4];  // 060796E6 mov r4,r1
    c.r[1] <<= 2;  // 060796E8 shll2 r1
    c.r[1] <<= 2;  // 060796EA shll2 r1
    c.r[0] = c.r[1];  // 060796EC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060796EE mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060796F0 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06079770u);  // 060796F2 mov.w 0x06079770,r2
    c.t = c.r[1] == c.r[2];  // 060796F4 cmp/eq r2,r1
    { const bool k = c.t; c.t = c.r[4] == c.r[2]; if (k) { goto L_0607973A; } }  // 060796F6 bt/s 0x0607973A ; cmp/eq r2,r4
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0607973A; } }  // 060796FA bt/s 0x0607973A ; mov r8,r0
    c.t = c.r[0] == 0x2u;  // 060796FE cmp/eq #2,r0
    if (!c.t) { goto L_0607973C; }  // 06079700 bf 0x0607973C
    c.r[1] = ld32(0x06079784u);  // 06079702 mov.l 0x06079784,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079704 mov.b @r1,r3
    c.r[2] = ld32(0x0607978Cu);  // 06079706 mov.l 0x0607978C,r2
    c.r[1] = c.r[2];  // 06079708 mov r2,r1
    c.r[1] += 74;  // 0607970A add #74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607970C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607970E extu.b r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 06079710 cmp/ge r1,r3
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0607973A; } }  // 06079712 bf/s 0x0607973A ; mov r2,r1
    c.r[1] += 76;  // 06079716 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079718 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607971A extu.b r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0607971C cmp/gt r1,r3
    if (c.t) { goto L_0607973A; }  // 0607971E bt 0x0607973A
    c.r[1] = ld32(0x06079780u);  // 06079720 mov.l 0x06079780,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079722 mov.b @r1,r3
    c.r[1] = c.r[2];  // 06079724 mov r2,r1
    c.r[1] += 75;  // 06079726 add #75,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079728 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607972A extu.b r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0607972C cmp/ge r1,r3
    { const bool k = !c.t; c.r[2] += 77; if (k) { goto L_0607973A; } }  // 0607972E bf/s 0x0607973A ; add #77,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079732 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079734 extu.b r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06079736 cmp/gt r1,r3
    if (!c.t) { goto L_0607973C; }  // 06079738 bf 0x0607973C
L_0607973A:
    c.r[4] = 0xFFFFFFFFu;  // 0607973A mov #-1,r4
L_0607973C:
    c.r[1] = ld32(0x0607979Cu);  // 0607973C mov.l 0x0607979C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06079742u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079742u) return; }  // 0607973E jsr @r1 ; mov #0,r6
    c.r[0] = c.r[8];  // 06079742 mov r8,r0
    c.t = c.r[0] == 0x3u;  // 06079744 cmp/eq #3,r0
    if (!c.t) { goto L_06079764; }  // 06079746 bf 0x06079764
    c.r[1] = ld32(0x060797A0u);  // 06079748 mov.l 0x060797A0,r1
    c.r[2] = ld32(c.r[1]);  // 0607974A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079772u);  // 0607974C mov.w 0x06079772,r1
    c.r[2] += c.r[1];  // 0607974E add r1,r2
    c.r[1] = ld32(0x060797A4u);  // 06079750 mov.l 0x060797A4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079752 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06079754 extu.w r1,r1
    c.r[1] <<= 2;  // 06079756 shll2 r1
    c.r[1] += c.r[1];  // 06079758 add r1,r1
    c.r[2] += c.r[1];  // 0607975A add r1,r2
    c.r[1] = ld32(0x0607977Cu);  // 0607975C mov.l 0x0607977C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607975E mov.b @r1,r1
    c.r[2] += 4;  // 06079760 add #4,r2
    st8(c.r[2], c.r[1]);  // 06079762 mov.b r1,@r2
L_06079764:
    c.r[15] = c.r[14];  // 06079764 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06079766 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06079768 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079774u);  // 0607976A mov.w 0x06079774,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607976C rts ; mov.l @r15+,r8
}

void f_060797A8(SH2Context& c) {
    ran[1671] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060797A8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060797AA mov r15,r14
    c.r[2] = ld32(0x060797BCu);  // 060797AC mov.l 0x060797BC,r2
    c.r[1] = 0x0u;  // 060797AE mov #0,r1
    st16(c.r[2], c.r[1]);  // 060797B0 mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060797B8u);  // 060797B2 mov.w 0x060797B8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060797B4 rts ; mov.l @r15+,r14
}

void f_060797C0(SH2Context& c) {
    ran[1672] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060797C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060797C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060797C4 mov.l r14,@-r15
    c.r[7] = ld32(0x0607992Cu);  // 060797C6 mov.l 0x0607992C,r7
    c.r[6] = c.r[7];  // 060797C8 mov r7,r6
    c.r[6] += 14;  // 060797CA add #14,r6
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[6]);  // 060797CC mov.w @r6,r3
    c.r[1] = ld32(0x06079930u);  // 060797CE mov.l 0x06079930,r1
    c.r[1] &= c.r[3];  // 060797D0 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060797D2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06079808; } }  // 060797D4 bt/s 0x06079808 ; mov r15,r14
    c.r[1] = ld32(c.r[7] + 8);  // 060797D8 mov.l @(8,r7),r1
    c.r[2] = ld32(c.r[7] + 12);  // 060797DA mov.l @(12,r7),r2
    st32(c.r[7], c.r[1]);  // 060797DC mov.l r1,@r7
    st32(c.r[7] + 4, c.r[2]);  // 060797DE mov.l r2,@(4,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079920u);  // 060797E0 mov.w 0x06079920,r1
    c.r[1] &= c.r[3];  // 060797E2 and r3,r1
    st16(c.r[6], c.r[1]);  // 060797E4 mov.w r1,@r6
    c.r[1] = ld32(0x06079934u);  // 060797E6 mov.l 0x06079934,r1
    c.r[3] = ld32(c.r[1]);  // 060797E8 mov.l @r1,r3
    c.r[7] += 4;  // 060797EA add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079922u);  // 060797EC mov.w 0x06079922,r1
    c.r[3] += c.r[1];  // 060797EE add r1,r3
    c.r[2] = c.r[3];  // 060797F0 mov r3,r2
    c.r[3] += 12;  // 060797F2 add #12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060797F4 mov.b @r3,r1
    c.r[2] += 4;  // 060797F6 add #4,r2
    st8(c.r[2], c.r[1]);  // 060797F8 mov.b r1,@r2
    c.r[6] = c.r[1] & 0xFFu;  // 060797FA extu.b r1,r6
    st16(c.r[7], c.r[6]);  // 060797FC mov.w r6,@r7
    c.r[2] = ld32(0x06079938u);  // 060797FE mov.l 0x06079938,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06079800 mov.w @r2,r1
    c.r[1] += 1;  // 06079802 add #1,r1
    st16(c.r[2], c.r[1]); goto L_0607985E;  // 06079804 bra 0x0607985E ; mov.w r1,@r2
L_06079808:
    c.r[1] = ld32(0x06079938u);  // 06079808 mov.l 0x06079938,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607980A mov.w @r1,r1
    c.r[6] = 0x0u;  // 0607980C mov #0,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607980E extu.w r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06079810 cmp/ge r1,r6
    if (c.t) { goto L_0607985E; }  // 06079812 bt 0x0607985E
    c.r[8] = c.r[7];  // 06079814 mov r7,r8
    c.r[9] = c.r[8];  // 06079816 mov r8,r9
    c.r[9] += 6;  // 06079818 add #6,r9
    c.r[4] = 0x8u;  // 0607981A mov #8,r4
    c.r[5] = c.r[8];  // 0607981C mov r8,r5
    c.r[7] = 0x0u;  // 0607981E mov #0,r7
L_06079820:
    c.r[1] = c.r[8];  // 06079820 mov r8,r1
    c.r[1] += 8;  // 06079822 add #8,r1
    c.r[1] += c.r[7];  // 06079824 add r7,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06079826 mov.l @(4,r1),r2
    c.r[1] = ld32(c.r[1]);  // 06079828 mov.l @r1,r1
    st32(c.r[5], c.r[1]);  // 0607982A mov.l r1,@r5
    st32(c.r[5] + 4, c.r[2]);  // 0607982C mov.l r2,@(4,r5)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0607982E mov.w @r9,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06079830 extu.w r1,r0
    c.t = c.r[0] == 0x41u;  // 06079832 cmp/eq #65,r0
    { const bool k = c.t; c.r[5] += 8; if (k) { goto L_0607984E; } }  // 06079834 bt/s 0x0607984E ; add #8,r5
    c.r[1] = ld32(0x06079934u);  // 06079838 mov.l 0x06079934,r1
    c.r[2] = ld32(c.r[1]);  // 0607983A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079922u);  // 0607983C mov.w 0x06079922,r1
    c.r[2] += c.r[1];  // 0607983E add r1,r2
    c.r[3] = c.r[2];  // 06079840 mov r2,r3
    c.r[3] += c.r[7];  // 06079842 add r7,r3
    c.r[2] += c.r[4];  // 06079844 add r4,r2
    c.r[2] += 4;  // 06079846 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079848 mov.b @r2,r1
    c.r[3] += 4;  // 0607984A add #4,r3
    st8(c.r[3], c.r[1]);  // 0607984C mov.b r1,@r3
L_0607984E:
    c.r[4] += 8;  // 0607984E add #8,r4
    c.r[1] = ld32(0x06079938u);  // 06079850 mov.l 0x06079938,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079852 mov.w @r1,r1
    c.r[6] += 1;  // 06079854 add #1,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06079856 extu.w r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06079858 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] += 8; if (k) { SH2_POLL(c); goto L_06079820; } }  // 0607985A bf/s 0x06079820 ; add #8,r7
L_0607985E:
    c.r[1] = ld32(0x06079934u);  // 0607985E mov.l 0x06079934,r1
    c.r[0] = ld32(c.r[1]);  // 06079860 mov.l @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079924u);  // 06079862 mov.w 0x06079924,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06079864 mov.b @(r0,r1),r3
    c.r[2] = c.r[3] & 0xFFu;  // 06079866 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079926u);  // 06079868 mov.w 0x06079926,r1
    c.t = c.r[2] == c.r[1];  // 0607986A cmp/eq r1,r2
    if (c.t) { goto L_06079872; }  // 0607986C bt 0x06079872
    c.r[1] = ld32(0x0607993Cu);  // 0607986E mov.l 0x0607993C,r1
    st8(c.r[1], c.r[3]);  // 06079870 mov.b r3,@r1
L_06079872:
    c.r[3] = ld32(0x0607992Cu);  // 06079872 mov.l 0x0607992C,r3
    c.r[6] = c.r[3];  // 06079874 mov r3,r6
    c.r[6] += 4;  // 06079876 add #4,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06079878 mov.w @r6,r7
    c.r[1] = 0x49u;  // 0607987A mov #73,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0607987C exts.w r7,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607987E cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_060798DA; } }  // 06079880 bf/s 0x060798DA ; mov r7,r1
    c.r[1] -= 74;  // 06079884 add #-74,r1
    st16(c.r[6], c.r[1]);  // 06079886 mov.w r1,@r6
    c.r[3] += 5;  // 06079888 add #5,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607988A mov.b @r3,r1
    c.r[6] = ld32(0x06079940u);  // 0607988C mov.l 0x06079940,r6
    st8(c.r[6], c.r[1]);  // 0607988E mov.b r1,@r6
    c.r[2] = c.r[1] & 0xFFu;  // 06079890 extu.b r1,r2
    c.r[1] = ld32(0x06079944u);  // 06079892 mov.l 0x06079944,r1
    c.r[7] = ld32(c.r[1]);  // 06079894 mov.l @r1,r7
    c.r[2] <<= 2;  // 06079896 shll2 r2
    c.r[2] <<= 2;  // 06079898 shll2 r2
    c.r[2] += c.r[7];  // 0607989A add r7,r2
    c.r[1] = c.r[2];  // 0607989C mov r2,r1
    c.r[1] += 4;  // 0607989E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060798A0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060798A2 mov r1,r0
    c.r[0] >>= 2;  // 060798A4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060798A6 shlr r0
    c.r[0] >>= 2;  // 060798A8 shlr2 r0
    c.r[0] &= 0x1u;  // 060798AA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060798AC tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_060798B6; } }  // 060798AE bt/s 0x060798B6 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060798B2 mov.b @r2,r1
    st8(c.r[6], c.r[1]);  // 060798B4 mov.b r1,@r6
L_060798B6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060798B6 mov.b @r6,r1
    c.r[2] = ld32(0x06079948u);  // 060798B8 mov.l 0x06079948,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060798BA extu.b r1,r1
    c.r[1] <<= 2;  // 060798BC shll2 r1
    c.r[1] <<= 2;  // 060798BE shll2 r1
    c.r[3] = c.r[1];  // 060798C0 mov r1,r3
    c.r[3] += c.r[7];  // 060798C2 add r7,r3
    c.r[0] = c.r[1];  // 060798C4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060798C6 mov.b @(r0,r7),r1
    c.r[3] += 1;  // 060798C8 add #1,r3
    st8(c.r[2], c.r[1]);  // 060798CA mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060798CC mov.b @r3,r1
    c.r[2] = ld32(0x0607994Cu);  // 060798CE mov.l 0x0607994C,r2
    st8(c.r[2], c.r[1]);  // 060798D0 mov.b r1,@r2
    c.r[1] = ld32(0x0607993Cu);  // 060798D2 mov.l 0x0607993C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060798D4 mov.b @r1,r1
    st8(c.r[6], c.r[1]); goto L_060798E2;  // 060798D6 bra 0x060798E2 ; mov.b r1,@r6
L_060798DA:
    c.r[3] += 5;  // 060798DA add #5,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060798DC mov.b @r3,r1
    c.r[2] = ld32(0x06079940u);  // 060798DE mov.l 0x06079940,r2
    st8(c.r[2], c.r[1]);  // 060798E0 mov.b r1,@r2
L_060798E2:
    c.r[3] = ld32(0x06079940u);  // 060798E2 mov.l 0x06079940,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060798E4 mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060798E6 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079926u);  // 060798E8 mov.w 0x06079926,r1
    c.t = c.r[2] == c.r[1];  // 060798EA cmp/eq r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06079916; } }  // 060798EC bt/s 0x06079916 ; mov r14,r15
    c.r[1] = ld32(0x06079944u);  // 060798F0 mov.l 0x06079944,r1
    c.r[1] = ld32(c.r[1]);  // 060798F2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060798F4 shll2 r2
    c.r[2] <<= 2;  // 060798F6 shll2 r2
    c.r[2] += c.r[1];  // 060798F8 add r1,r2
    c.r[1] = c.r[2];  // 060798FA mov r2,r1
    c.r[1] += 4;  // 060798FC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060798FE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06079900 mov r1,r0
    c.r[0] >>= 2;  // 06079902 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06079904 shlr r0
    c.r[0] >>= 2;  // 06079906 shlr2 r0
    c.r[0] &= 0x1u;  // 06079908 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607990A tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06079916; } }  // 0607990C bt/s 0x06079916 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079910 mov.b @r2,r1
    st8(c.r[3], c.r[1]);  // 06079912 mov.b r1,@r3
    c.r[15] = c.r[14];  // 06079914 mov r14,r15
L_06079916:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06079916 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06079918 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079928u);  // 0607991A mov.w 0x06079928,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607991C rts ; mov.l @r15+,r8
}

void f_06079950(SH2Context& c) {
    ran[1673] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079950 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06079952 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06079954 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079956 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06079958 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06079A48u);  // 0607995A mov.w 0x06079A48,r3
    c.r[9] = ld32(0x06079A4Cu);  // 0607995C mov.l 0x06079A4C,r9
    c.r[1] = c.r[9];  // 0607995E mov r9,r1
    c.r[1] += 5;  // 06079960 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079962 mov.b @r1,r1
    c.r[15] += c.r[3];  // 06079964 add r3,r15
    c.r[10] = c.r[1] & 0xFFu;  // 06079966 extu.b r1,r10
    c.r[1] = ld32(0x06079A50u);  // 06079968 mov.l 0x06079A50,r1
    c.r[2] = c.r[10];  // 0607996A mov r10,r2
    c.r[3] = ld32(c.r[1]);  // 0607996C mov.l @r1,r3
    c.r[2] <<= 2;  // 0607996E shll2 r2
    c.r[2] <<= 2;  // 06079970 shll2 r2
    c.r[2] += c.r[3];  // 06079972 add r3,r2
    c.r[1] = c.r[2];  // 06079974 mov r2,r1
    c.r[1] += 4;  // 06079976 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079978 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0607997A mov r1,r0
    c.r[0] >>= 2;  // 0607997C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0607997E shlr r0
    c.r[0] >>= 2;  // 06079980 shlr2 r0
    c.r[0] &= 0x1u;  // 06079982 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06079984 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06079990; } }  // 06079986 bt/s 0x06079990 ; mov r15,r14
    c.r[2] += 6;  // 0607998A add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607998C mov.b @r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0607998E extu.b r1,r10
L_06079990:
    c.r[1] = c.r[10];  // 06079990 mov r10,r1
    c.r[1] <<= 2;  // 06079992 shll2 r1
    c.r[1] <<= 2;  // 06079994 shll2 r1
    c.r[1] += c.r[3];  // 06079996 add r3,r1
    c.r[1] += 2;  // 06079998 add #2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06079A4Au);  // 0607999A mov.w 0x06079A4A,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607999C mov.b @r1,r1
    c.r[4] = c.r[14];  // 0607999E mov r14,r4
    c.r[8] = c.r[1] & 0xFFu;  // 060799A0 extu.b r1,r8
    c.r[1] = ld32(0x06079A54u);  // 060799A2 mov.l 0x06079A54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060799A8u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060799A8u) return; }  // 060799A4 jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06079A58u);  // 060799A8 mov.l 0x06079A58,r1
    c.r[1] = ld32(c.r[1]);  // 060799AA mov.l @r1,r1
    c.r[1] += 1;  // 060799AC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060799AE mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060799B0 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 060799B2 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06079A0A; } }  // 060799B4 bt/s 0x06079A0A ; mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060799B8 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_060799C6; } }  // 060799BA bt/s 0x060799C6 ; cmp/eq #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060799BE tst r0,r0
    if (!c.t) { goto L_06079ABC; }  // 060799C0 bf 0x06079ABC
    goto L_060799CC;  // 060799C2 bra 0x060799CC ; nop
L_060799C6:
    if (!c.t) { goto L_06079ABC; }  // 060799C6 bf 0x06079ABC
    goto L_06079A60;  // 060799C8 bra 0x06079A60 ; nop
L_060799CC:
    c.r[1] = ld32(0x06079A5Cu);  // 060799CC mov.l 0x06079A5C,r1
    c.r[2] = ld32(c.r[1]);  // 060799CE mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060799D0 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 060799D2 mul.l r1,r8
    c.r[1] = c.macl;  // 060799D4 sts macl,r1
    c.r[1] += c.r[2];  // 060799D6 add r2,r1
    c.r[1] += 22;  // 060799D8 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060799DA mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060799DC extu.w r1,r3
    c.r[1] = ld32(c.r[9]);  // 060799DE mov.l @r9,r1
    c.r[3] += c.r[1];  // 060799E0 add r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 060799E2 cmp/pz r3
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060799EC; } }  // 060799E4 bt/s 0x060799EC ; mov r14,r1
    c.r[3] = 0x0u; goto L_060799F8;  // 060799E8 bra 0x060799F8 ; mov #0,r3
L_060799EC:
    c.r[1] += 26;  // 060799EC add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060799EE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060799F0 extu.w r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060799F2 cmp/gt r1,r3
    if (!c.t) { goto L_060799F8; }  // 060799F4 bf 0x060799F8
    c.r[3] = c.r[1];  // 060799F6 mov r1,r3
L_060799F8:
    c.r[1] = ld32(0x06079A5Cu);  // 060799F8 mov.l 0x06079A5C,r1
    c.r[2] = ld32(c.r[1]);  // 060799FA mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060799FC mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 060799FE mul.l r1,r8
    c.r[1] = c.macl;  // 06079A00 sts macl,r1
    c.r[1] += c.r[2];  // 06079A02 add r2,r1
    c.r[1] += 22;  // 06079A04 add #22,r1
    st16(c.r[1], c.r[3]); goto L_06079ABC;  // 06079A06 bra 0x06079ABC ; mov.w r3,@r1
L_06079A0A:
    c.r[1] = ld32(0x06079A5Cu);  // 06079A0A mov.l 0x06079A5C,r1
    c.r[2] = ld32(c.r[1]);  // 06079A0C mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06079A0E mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06079A10 mul.l r1,r8
    c.r[1] = c.macl;  // 06079A12 sts macl,r1
    c.r[1] += c.r[2];  // 06079A14 add r2,r1
    c.r[1] += 24;  // 06079A16 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079A18 mov.w @r1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06079A1A extu.w r1,r3
    c.r[1] = ld32(c.r[9]);  // 06079A1C mov.l @r9,r1
    c.r[3] += c.r[1];  // 06079A1E add r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06079A20 cmp/pz r3
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06079A2A; } }  // 06079A22 bt/s 0x06079A2A ; mov r14,r1
    c.r[3] = 0x0u; goto L_06079A36;  // 06079A26 bra 0x06079A36 ; mov #0,r3
L_06079A2A:
    c.r[1] += 28;  // 06079A2A add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079A2C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06079A2E extu.w r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06079A30 cmp/gt r1,r3
    if (!c.t) { goto L_06079A36; }  // 06079A32 bf 0x06079A36
    c.r[3] = c.r[1];  // 06079A34 mov r1,r3
L_06079A36:
    c.r[1] = ld32(0x06079A5Cu);  // 06079A36 mov.l 0x06079A5C,r1
    c.r[2] = ld32(c.r[1]);  // 06079A38 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06079A3A mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06079A3C mul.l r1,r8
    c.r[1] = c.macl;  // 06079A3E sts macl,r1
    c.r[1] += c.r[2];  // 06079A40 add r2,r1
    c.r[1] += 24;  // 06079A42 add #24,r1
    st16(c.r[1], c.r[3]); goto L_06079ABC;  // 06079A44 bra 0x06079ABC ; mov.w r3,@r1
L_06079A60:
    c.r[1] = ld32(0x06079AD8u);  // 06079A60 mov.l 0x06079AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06079A66u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079A66u) return; }  // 06079A62 jsr @r1 ; mov r10,r4
    c.r[9] = 0x0u;  // 06079A66 mov #0,r9
    c.r[8] = 0x0u;  // 06079A68 mov #0,r8
L_06079A6A:
    c.r[1] = ld32(0x06079ADCu);  // 06079A6A mov.l 0x06079ADC,r1
    c.r[3] = c.r[8];  // 06079A6C mov r8,r3
    c.r[0] = ld32(c.r[1]);  // 06079A6E mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06079AD0u);  // 06079A70 mov.w 0x06079AD0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06079A72 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079A74 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06079A76 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06079AB2; } }  // 06079A78 bt/s 0x06079AB2 ; add r0,r3
    c.r[1] = c.r[3];  // 06079A7C mov r3,r1
    c.r[1] += 7;  // 06079A7E add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079A80 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06079A82 mov r1,r0
    c.r[0] >>= 2;  // 06079A84 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06079A86 shlr r0
    c.r[0] &= 0x1u;  // 06079A88 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06079A8A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06079AB2; } }  // 06079A8C bf/s 0x06079AB2 ; mov r3,r1
    c.r[1] += 4;  // 06079A90 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079A92 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06079A94 mov r1,r0
    c.r[0] >>= 2;  // 06079A96 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06079A98 shlr r0
    c.r[0] >>= 2;  // 06079A9A shlr2 r0
    c.r[0] &= 0x1u;  // 06079A9C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06079A9E tst r0,r0
    { const bool k = c.t; c.r[3] += 6; if (k) { goto L_06079AB2; } }  // 06079AA0 bt/s 0x06079AB2 ; add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079AA4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079AA6 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06079AA8 cmp/eq r10,r1
    if (!c.t) { goto L_06079AB2; }  // 06079AAA bf 0x06079AB2
    c.r[1] = ld32(0x06079AD8u);  // 06079AAC mov.l 0x06079AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06079AB2u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079AB2u) return; }  // 06079AAE jsr @r1 ; extu.b r9,r4
L_06079AB2:
    c.r[9] += 1;  // 06079AB2 add #1,r9
    c.r[1] = 0x49u;  // 06079AB4 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06079AB6 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_06079A6A; } }  // 06079AB8 bf/s 0x06079A6A ; add #16,r8
L_06079ABC:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06079AD2u);  // 06079ABC mov.w 0x06079AD2,r3
    c.r[14] += c.r[3];  // 06079ABE add r3,r14
    c.r[15] = c.r[14];  // 06079AC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06079AC2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06079AC4 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06079AC6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06079AC8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079AD4u);  // 06079ACA mov.w 0x06079AD4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079ACC rts ; mov.l @r15+,r8
}

void f_06079AE0(SH2Context& c) {
    ran[1674] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079AE0 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 06079AE2 extu.b r4,r4
    c.r[1] = ld32(0x06079B50u);  // 06079AE4 mov.l 0x06079B50,r1
    c.r[1] = ld32(c.r[1]);  // 06079AE6 mov.l @r1,r1
    c.r[4] <<= 2;  // 06079AE8 shll2 r4
    c.r[4] <<= 2;  // 06079AEA shll2 r4
    c.r[4] += c.r[1];  // 06079AEC add r1,r4
    c.r[4] += 2;  // 06079AEE add #2,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06079AF0 mov.b @r4,r2
    c.r[1] = ld32(0x06079B54u);  // 06079AF2 mov.l 0x06079B54,r1
    c.r[3] = ld32(c.r[1]);  // 06079AF4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06079AF6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06079AF8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06079AFA mul.l r1,r2
    c.r[1] = c.macl;  // 06079AFC sts macl,r1
    c.r[1] += c.r[3];  // 06079AFE add r3,r1
    c.r[1] += 15;  // 06079B00 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079B02 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06079B04 extu.b r1,r7
    c.r[1] = ld32(0x06079B58u);  // 06079B06 mov.l 0x06079B58,r1
    c.r[2] = c.r[7];  // 06079B08 mov r7,r2
    c.r[2] += c.r[2];  // 06079B0A add r2,r2
    c.r[2] += c.r[7];  // 06079B0C add r7,r2
    c.r[1] = ld32(c.r[1]);  // 06079B0E mov.l @r1,r1
    c.r[2] <<= 2;  // 06079B10 shll2 r2
    c.r[2] += c.r[1];  // 06079B12 add r1,r2
    c.r[2] += 9;  // 06079B14 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079B16 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06079B18 extu.b r1,r3
    c.r[1] = ld32(0x06079B5Cu);  // 06079B1A mov.l 0x06079B5C,r1
    c.r[1] = ld32(c.r[1]);  // 06079B1C mov.l @r1,r1
    c.r[3] += c.r[1];  // 06079B1E add r1,r3
    c.r[1] = 0x31u;  // 06079B20 mov #49,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06079B22 cmp/gt r1,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06079B2C; } }  // 06079B24 bt/s 0x06079B2C ; mov r15,r14
    c.r[3] = 0x32u; goto L_06079B34;  // 06079B28 bra 0x06079B34 ; mov #50,r3
L_06079B2C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079B4Cu);  // 06079B2C mov.w 0x06079B4C,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06079B2E cmp/gt r1,r3
    if (!c.t) { goto L_06079B34; }  // 06079B30 bf 0x06079B34
    c.r[3] = c.r[1];  // 06079B32 mov r1,r3
L_06079B34:
    c.r[1] = ld32(0x06079B58u);  // 06079B34 mov.l 0x06079B58,r1
    c.r[2] = c.r[7];  // 06079B36 mov r7,r2
    c.r[2] += c.r[2];  // 06079B38 add r2,r2
    c.r[2] += c.r[7];  // 06079B3A add r7,r2
    c.r[2] <<= 2;  // 06079B3C shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06079B3E mov.l @r1,r1
    c.r[15] = c.r[14];  // 06079B40 mov r14,r15
    c.r[2] += c.r[1];  // 06079B42 add r1,r2
    c.r[2] += 9;  // 06079B44 add #9,r2
    st8(c.r[2], c.r[3]);  // 06079B46 mov.b r3,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079B48 rts ; mov.l @r15+,r14
}

void f_06079B68(SH2Context& c) {
    ran[1675] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079B68 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06079B6A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06079B6C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06079B6E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06079B70 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06079B72 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079B74 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06079B76 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06079B78 mov r15,r14
    c.r[7] = ld32(0x06079BECu);  // 06079B7A mov.l 0x06079BEC,r7
    c.r[1] = ld32(0x06079BF0u);  // 06079B7C mov.l 0x06079BF0,r1
    c.r[2] = ld32(0x06079BF4u);  // 06079B7E mov.l 0x06079BF4,r2
    c.r[8] = ld32(c.r[1]);  // 06079B80 mov.l @r1,r8
    c.r[7] += 21;  // 06079B82 add #21,r7
    c.r[3] = c.r[8];  // 06079B84 mov r8,r3
    c.r[3] += 1;  // 06079B86 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079B88 mov.b @r3,r1
    c.r[8] += 2;  // 06079B8A add #2,r8
    c.r[1] = 0u - c.r[1];  // 06079B8C neg r1,r1
    st8(c.r[2], c.r[1]);  // 06079B8E mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06079B90 mov.b @r8,r1
    c.r[13] = ld32(0x06079BF8u);  // 06079B92 mov.l 0x06079BF8,r13
    c.r[1] = 0u - c.r[1];  // 06079B94 neg r1,r1
    st8(c.r[7], c.r[1]);  // 06079B96 mov.b r1,@r7
    c.r[2] = ld32(0x06079BFCu);  // 06079B98 mov.l 0x06079BFC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x06079B9Eu; c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079B9Eu) return; }  // 06079B9A jsr @r2 ; mov.b @r3,r4
    c.r[4] = c.r[0];  // 06079B9E mov r0,r4
    c.r[5] = c.r[1];  // 06079BA0 mov r1,r5
    c.r[1] = ld32(0x06079C00u);  // 06079BA2 mov.l 0x06079C00,r1
    c.r[9] = ld32(c.r[1]);  // 06079BA4 mov.l @r1,r9
    c.r[10] = ld32(c.r[1] + 4);  // 06079BA6 mov.l @(4,r1),r10
    c.r[12] = ld32(0x06079C04u);  // 06079BA8 mov.l 0x06079C04,r12
    c.r[6] = c.r[9];  // 06079BAA mov r9,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06079BB0u; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079BB0u) return; }  // 06079BAC jsr @r12 ; mov r10,r7
    c.r[4] = c.r[0];  // 06079BB0 mov r0,r4
    c.r[11] = ld32(0x06079C08u);  // 06079BB2 mov.l 0x06079C08,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06079BB8u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079BB8u) return; }  // 06079BB4 jsr @r11 ; mov r1,r5
    c.r[2] = ld32(0x06079C0Cu);  // 06079BB8 mov.l 0x06079C0C,r2
    st32(c.r[2], c.r[0]);  // 06079BBA mov.l r0,@r2
    c.r[13] += 104;  // 06079BBC add #104,r13
    c.r[2] = ld32(0x06079BFCu);  // 06079BBE mov.l 0x06079BFC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x06079BC4u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079BC4u) return; }  // 06079BC0 jsr @r2 ; mov.b @r8,r4
    c.r[4] = c.r[0];  // 06079BC4 mov r0,r4
    c.r[5] = c.r[1];  // 06079BC6 mov r1,r5
    c.r[6] = c.r[9];  // 06079BC8 mov r9,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06079BCEu; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079BCEu) return; }  // 06079BCA jsr @r12 ; mov r10,r7
    c.r[4] = c.r[0];  // 06079BCE mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06079BD4u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079BD4u) return; }  // 06079BD0 jsr @r11 ; mov r1,r5
    st32(c.r[13], c.r[0]);  // 06079BD4 mov.l r0,@r13
    c.r[15] = c.r[14];  // 06079BD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06079BD8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06079BDA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06079BDC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06079BDE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06079BE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06079BE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06079BE4 mov.l @r15+,r9
    c.r[0] = ld32(0x06079C10u);  // 06079BE6 mov.l 0x06079C10,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079BE8 rts ; mov.l @r15+,r8
}

void f_06079C14(SH2Context& c) {
    ran[1676] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079C14 mov.l r14,@-r15
    c.r[1] = ld32(0x06079C3Cu);  // 06079C16 mov.l 0x06079C3C,r1
    c.r[1] = ld32(c.r[1]);  // 06079C18 mov.l @r1,r1
    c.r[1] += 1;  // 06079C1A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079C1C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06079C1E extu.b r1,r0
    c.r[0] += c.r[0];  // 06079C20 add r0,r0
    c.r[1] = ld32(0x06079C40u);  // 06079C22 mov.l 0x06079C40,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06079C24 mov.w @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06079C26 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06079C32; } }  // 06079C28 bf/s 0x06079C32 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079C3Au);  // 06079C2C mov.w 0x06079C3A,r0
    c.r[15] = c.r[14]; goto L_06079C36;  // 06079C2E bra 0x06079C36 ; mov r14,r15
L_06079C32:
    c.r[0] = 0x0u;  // 06079C32 mov #0,r0
    c.r[15] = c.r[14];  // 06079C34 mov r14,r15
L_06079C36:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079C36 rts ; mov.l @r15+,r14
}

void f_06079C44(SH2Context& c) {
    ran[1677] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079C44 mov.l r14,@-r15
    c.r[1] = ld32(0x06079CA4u);  // 06079C46 mov.l 0x06079CA4,r1
    c.r[3] = ld32(c.r[1]);  // 06079C48 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06079C4A mov r3,r1
    c.r[1] += 2;  // 06079C4C add #2,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079C4E mov.b @r1,r7
    c.r[2] = c.r[7] & 0xFFu;  // 06079C50 extu.b r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079C9Au);  // 06079C52 mov.w 0x06079C9A,r1
    c.t = c.r[2] == c.r[1];  // 06079C54 cmp/eq r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06079C84; } }  // 06079C56 bf/s 0x06079C84 ; mov r15,r14
    c.r[3] += 1;  // 06079C5A add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079C5C mov.b @r3,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06079C5E extu.b r1,r6
    c.r[1] = ld32(0x06079CA8u);  // 06079C60 mov.l 0x06079CA8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079C62 mov.b @r1,r2
    c.r[1] = ld32(0x06079CACu);  // 06079C64 mov.l 0x06079CAC,r1
    c.r[3] = ld32(c.r[1]);  // 06079C66 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06079C68 extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079C9Cu);  // 06079C6A mov.w 0x06079C9C,r1
    c.macl = c.r[2] * c.r[1];  // 06079C6C mul.l r1,r2
    c.r[7] = ld32(0x06079CB0u);  // 06079C6E mov.l 0x06079CB0,r7
    c.r[2] = c.macl;  // 06079C70 sts macl,r2
    c.r[2] += c.r[3];  // 06079C72 add r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079C9Eu);  // 06079C74 mov.w 0x06079C9E,r1
    c.r[0] = c.r[2];  // 06079C76 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06079C78 mov.b @(r0,r1),r1
    c.r[6] += c.r[6];  // 06079C7A add r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06079C7C extu.b r1,r1
    c.r[0] = c.r[6];  // 06079C7E mov r6,r0
    st16(c.r[0] + c.r[7], c.r[1]); goto L_06079C92;  // 06079C80 bra 0x06079C92 ; mov.w r1,@(r0,r7)
L_06079C84:
    c.r[3] += 1;  // 06079C84 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079C86 mov.b @r3,r1
    c.r[2] = ld32(0x06079CB0u);  // 06079C88 mov.l 0x06079CB0,r2
    c.r[0] = c.r[1] & 0xFFu;  // 06079C8A extu.b r1,r0
    c.r[0] += c.r[0];  // 06079C8C add r0,r0
    c.r[1] = c.r[7] & 0xFFu;  // 06079C8E extu.b r7,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06079C90 mov.w r1,@(r0,r2)
L_06079C92:
    c.r[15] = c.r[14];  // 06079C92 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079CA0u);  // 06079C94 mov.w 0x06079CA0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079C96 rts ; mov.l @r15+,r14
}

void f_06079CB4(SH2Context& c) {
    ran[1678] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079CB4 mov.l r14,@-r15
    c.r[1] = ld32(0x06079D28u);  // 06079CB6 mov.l 0x06079D28,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079CB8 mov.b @r1,r2
    c.r[14] = c.r[15];  // 06079CBA mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 06079CBC extu.b r2,r2
    c.r[1] = ld32(0x06079D2Cu);  // 06079CBE mov.l 0x06079D2C,r1
    c.r[2] <<= 2;  // 06079CC0 shll2 r2
    c.r[2] <<= 2;  // 06079CC2 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06079CC4 mov.l @r1,r1
    c.r[3] = c.r[2];  // 06079CC6 mov r2,r3
    c.r[3] += c.r[1];  // 06079CC8 add r1,r3
    c.r[3] += 1;  // 06079CCA add #1,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079CCC mov.b @r3,r7
    c.r[0] = c.r[2];  // 06079CCE mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06079CD0 mov.b @(r0,r1),r2
    c.r[3] = ld32(0x06079D30u);  // 06079CD2 mov.l 0x06079D30,r3
    c.r[1] = c.r[3];  // 06079CD4 mov r3,r1
    c.r[1] += 78;  // 06079CD6 add #78,r1
    c.r[4] = c.r[2] & 0xFFu;  // 06079CD8 extu.b r2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079CDA mov.b @r1,r1
    c.r[3] += 79;  // 06079CDC add #79,r3
    c.r[1] += 18;  // 06079CDE add #18,r1
    c.r[1] -= c.r[2];  // 06079CE0 sub r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06079CE2 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079CE4 mov.b @r3,r1
    c.r[1] += 12;  // 06079CE6 add #12,r1
    c.r[1] -= c.r[7];  // 06079CE8 sub r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079CEA extu.b r1,r1
    c.r[3] = c.r[1];  // 06079CEC mov r1,r3
    c.t = c.r[6] > c.r[3];  // 06079CEE cmp/hi r3,r6
    { const bool k = !c.t; c.r[5] = c.r[7] & 0xFFu; if (k) { goto L_06079D04; } }  // 06079CF0 bf/s 0x06079D04 ; extu.b r7,r5
    c.r[2] = ld32(0x06079D34u);  // 06079CF4 mov.l 0x06079D34,r2
    c.r[1] = c.r[4];  // 06079CF6 mov r4,r1
    c.r[1] += c.r[6];  // 06079CF8 add r6,r1
    st8(c.r[2], c.r[1]);  // 06079CFA mov.b r1,@r2
    c.r[2] = ld32(0x06079D38u);  // 06079CFC mov.l 0x06079D38,r2
    c.r[1] = c.r[5];  // 06079CFE mov r5,r1
    c.r[1] -= c.r[6]; goto L_06079D12;  // 06079D00 bra 0x06079D12 ; sub r6,r1
L_06079D04:
    c.r[2] = ld32(0x06079D34u);  // 06079D04 mov.l 0x06079D34,r2
    c.r[1] = c.r[4];  // 06079D06 mov r4,r1
    c.r[1] += c.r[3];  // 06079D08 add r3,r1
    st8(c.r[2], c.r[1]);  // 06079D0A mov.b r1,@r2
    c.r[2] = ld32(0x06079D38u);  // 06079D0C mov.l 0x06079D38,r2
    c.r[1] = c.r[5];  // 06079D0E mov r5,r1
    c.r[1] -= c.r[3];  // 06079D10 sub r3,r1
L_06079D12:
    st8(c.r[2], c.r[1]);  // 06079D12 mov.b r1,@r2
    c.r[1] = ld32(0x06079D3Cu);  // 06079D14 mov.l 0x06079D3C,r1
    st8(c.r[1], c.r[4]);  // 06079D16 mov.b r4,@r1
    c.r[1] = ld32(0x06079D40u);  // 06079D18 mov.l 0x06079D40,r1
    st8(c.r[1], c.r[5]);  // 06079D1A mov.b r5,@r1
    c.r[15] = c.r[14];  // 06079D1C mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079D24u);  // 06079D1E mov.w 0x06079D24,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079D20 rts ; mov.l @r15+,r14
}

void f_06079D44(SH2Context& c) {
    ran[1679] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079D44 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06079D46 mov r15,r14
    c.r[3] = ld32(0x06079D84u);  // 06079D48 mov.l 0x06079D84,r3
    c.r[2] = ld32(0x06079D88u);  // 06079D4A mov.l 0x06079D88,r2
    c.r[5] = ld32(0x06079D8Cu);  // 06079D4C mov.l 0x06079D8C,r5
    c.r[6] = c.r[2];  // 06079D4E mov r2,r6
    c.r[1] = ld32(c.r[2]);  // 06079D50 mov.l @r2,r1
    c.r[0] = 0x0u;  // 06079D52 mov #0,r0
    c.r[1] += 1;  // 06079D54 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079D56 mov.b @r1,r1
    c.r[7] = 0x2u;  // 06079D58 mov #2,r7
    st8(c.r[3], c.r[1]);  // 06079D5A mov.b r1,@r3
L_06079D5C:
    c.r[3] = ld32(c.r[6]);  // 06079D5C mov.l @r6,r3
    c.r[3] += c.r[0];  // 06079D5E add r0,r3
    c.r[1] = c.r[3];  // 06079D60 mov r3,r1
    c.r[1] += 2;  // 06079D62 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079D64 mov.b @r1,r2
    c.r[3] += 3;  // 06079D66 add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06079D68 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079D6A mov.b @r3,r1
    c.r[2] <<= 8;  // 06079D6C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06079D6E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06079D70 or r1,r2
    st16(c.r[0] + c.r[5], c.r[2]);  // 06079D72 mov.w r2,@(r0,r5)
    c.r[0] += 2;  // 06079D74 add #2,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[7];  // 06079D76 cmp/gt r7,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { SH2_POLL(c); goto L_06079D5C; } }  // 06079D78 bf/s 0x06079D5C ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079D82u);  // 06079D7C mov.w 0x06079D82,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079D7E rts ; mov.l @r15+,r14
}

void f_06079D90(SH2Context& c) {
    ran[1680] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079D90 mov.l r14,@-r15
    c.r[1] = ld32(0x06079E40u);  // 06079D92 mov.l 0x06079E40,r1
    c.r[1] = ld32(c.r[1]);  // 06079D94 mov.l @r1,r1
    c.r[1] += 1;  // 06079D96 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079D98 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06079D9A extu.b r3,r2
    c.r[1] = 0x1u;  // 06079D9C mov #1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06079D9E cmp/ge r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06079E30; } }  // 06079DA0 bf/s 0x06079E30 ; mov r15,r14
    c.r[1] = 0x4u;  // 06079DA4 mov #4,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06079DA6 cmp/gt r1,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06079DB4; } }  // 06079DA8 bf/s 0x06079DB4 ; mov r2,r0
    c.t = c.r[0] == 0x5u;  // 06079DAC cmp/eq #5,r0
    if (!c.t) { goto L_06079E30; }  // 06079DAE bf 0x06079E30
    goto L_06079DBC;  // 06079DB0 bra 0x06079DBC ; nop
L_06079DB4:
    c.r[2] = ld32(0x06079E44u);  // 06079DB4 mov.l 0x06079E44,r2
    c.r[1] = c.r[3];  // 06079DB6 mov r3,r1
    c.r[1] -= 1; goto L_06079E34;  // 06079DB8 bra 0x06079E34 ; add #-1,r1
L_06079DBC:
    c.r[7] = ld32(0x06079E48u);  // 06079DBC mov.l 0x06079E48,r7
    c.r[1] = c.r[7];  // 06079DBE mov r7,r1
    c.r[1] += 116;  // 06079DC0 add #116,r1
    c.r[2] = c.r[7];  // 06079DC2 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079DC4 mov.b @r1,r3
    c.r[2] += 78;  // 06079DC6 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06079DC8 mov.b @r2,r1
    c.r[3] += c.r[1];  // 06079DCA add r1,r3
    c.r[1] = ld32(0x06079E4Cu);  // 06079DCC mov.l 0x06079E4C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079DCE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06079DD0 extu.b r2,r2
    c.r[1] = ld32(0x06079E50u);  // 06079DD2 mov.l 0x06079E50,r1
    c.r[2] <<= 2;  // 06079DD4 shll2 r2
    c.r[2] <<= 2;  // 06079DD6 shll2 r2
    c.r[6] = c.r[2];  // 06079DD8 mov r2,r6
    c.r[1] = ld32(c.r[1]);  // 06079DDA mov.l @r1,r1
    c.r[0] = c.r[2];  // 06079DDC mov r2,r0
    c.r[6] += c.r[1];  // 06079DDE add r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06079DE0 mov.b @(r0,r1),r1
    c.r[6] += 1;  // 06079DE2 add #1,r6
    c.r[3] -= c.r[1];  // 06079DE4 sub r1,r3
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[3];  // 06079DE6 exts.b r3,r3
    c.r[1] = c.r[7];  // 06079DE8 mov r7,r1
    c.r[1] += 117;  // 06079DEA add #117,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079DEC mov.b @r1,r2
    c.r[7] += 79;  // 06079DEE add #79,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06079DF0 mov.b @r7,r1
    c.t = (int32_t)c.r[3] >= 0;  // 06079DF2 cmp/pz r3
    c.r[2] += c.r[1];  // 06079DF4 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06079DF6 mov.b @r6,r1
    c.r[7] = c.r[3];  // 06079DF8 mov r3,r7
    c.r[2] -= c.r[1];  // 06079DFA sub r1,r2
    c.r[6] = ld32(0x06079E44u);  // 06079DFC mov.l 0x06079E44,r6
    { const bool k = c.t; c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[2]; if (k) { goto L_06079E04; } }  // 06079DFE bt/s 0x06079E04 ; exts.b r2,r2
    c.r[7] = 0u - c.r[3];  // 06079E02 neg r3,r7
L_06079E04:
    c.t = (int32_t)c.r[2] >= 0;  // 06079E04 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06079E0C; } }  // 06079E06 bt/s 0x06079E0C ; mov r2,r1
    c.r[1] = 0u - c.r[2];  // 06079E0A neg r2,r1
L_06079E0C:
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06079E0C cmp/gt r1,r7
    { const bool k = !c.t; c.t = (int32_t)c.r[3] > 0; if (k) { goto L_06079E20; } }  // 06079E0E bf/s 0x06079E20 ; cmp/pl r3
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06079E1A; } }  // 06079E12 bf/s 0x06079E1A ; mov #1,r1
    st8(c.r[6], c.r[1]); goto L_06079E36;  // 06079E16 bra 0x06079E36 ; mov.b r1,@r6
L_06079E1A:
    c.r[1] = 0x3u;  // 06079E1A mov #3,r1
    st8(c.r[6], c.r[1]); goto L_06079E36;  // 06079E1C bra 0x06079E36 ; mov.b r1,@r6
L_06079E20:
    c.t = (int32_t)c.r[2] > 0;  // 06079E20 cmp/pl r2
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_06079E2A; } }  // 06079E22 bf/s 0x06079E2A ; mov #2,r1
    st8(c.r[6], c.r[1]); goto L_06079E36;  // 06079E26 bra 0x06079E36 ; mov.b r1,@r6
L_06079E2A:
    c.r[1] = 0x0u;  // 06079E2A mov #0,r1
    st8(c.r[6], c.r[1]); goto L_06079E36;  // 06079E2C bra 0x06079E36 ; mov.b r1,@r6
L_06079E30:
    c.r[2] = ld32(0x06079E44u);  // 06079E30 mov.l 0x06079E44,r2
    c.r[1] = 0x0u;  // 06079E32 mov #0,r1
L_06079E34:
    st8(c.r[2], c.r[1]);  // 06079E34 mov.b r1,@r2
L_06079E36:
    c.r[15] = c.r[14];  // 06079E36 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079E3Eu);  // 06079E38 mov.w 0x06079E3E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079E3A rts ; mov.l @r15+,r14
}

void f_06079E54(SH2Context& c) {
    ran[1681] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079E54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06079E56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06079E58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06079E5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079E5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06079E5E sts.l pr,@-r15
    c.r[15] -= 4;  // 06079E60 add #-4,r15
    c.r[11] = ld32(0x06079F2Cu);  // 06079E62 mov.l 0x06079F2C,r11
    c.r[6] = ld32(c.r[11]);  // 06079E64 mov.l @r11,r6
    c.r[10] = ld32(0x06079F30u);  // 06079E66 mov.l 0x06079F30,r10
    c.r[1] = c.r[6];  // 06079E68 mov r6,r1
    c.r[1] += 1;  // 06079E6A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079E6C mov.b @r1,r1
    c.r[9] = ld32(0x06079F34u);  // 06079E6E mov.l 0x06079F34,r9
    c.r[8] = c.r[1] & 0xFFu;  // 06079E70 extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06079E72 tst r8,r8
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06079EA0; } }  // 06079E74 bt/s 0x06079EA0 ; mov r15,r14
    c.r[7] = ld32(0x06079F38u);  // 06079E78 mov.l 0x06079F38,r7
    c.r[6] += 2;  // 06079E7A add #2,r6
    c.r[8] = ld32(0x06079F3Cu);  // 06079E7C mov.l 0x06079F3C,r8
    c.r[5] = 0xFFFFFFFFu;  // 06079E7E mov #-1,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06079E80 mov.b @r6,r6
    c.r[4] = 0x11u;  // 06079E82 mov #17,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06079E84 extu.b r6,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06079E8Au; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079E8Au) return; }  // 06079E86 jsr @r8 ; mov.l r9,@-r15
    c.r[7] = ld32(0x06079F40u);  // 06079E8A mov.l 0x06079F40,r7
    c.r[1] = ld32(c.r[11]);  // 06079E8C mov.l @r11,r1
    c.r[5] = 0xFFFFFFFFu;  // 06079E8E mov #-1,r5
    c.r[1] += 3;  // 06079E90 add #3,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079E92 mov.b @r1,r6
    c.r[4] = 0x11u;  // 06079E94 mov #17,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06079E96 extu.b r6,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06079E9Cu; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079E9Cu) return; }  // 06079E98 jsr @r8 ; mov.l r9,@-r15
    c.r[14] += 4; goto L_06079F16;  // 06079E9C bra 0x06079F16 ; add #4,r14
L_06079EA0:
    c.r[1] = c.r[6];  // 06079EA0 mov r6,r1
    c.r[1] += 3;  // 06079EA2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079EA4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079EA6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06079EA8 tst r1,r1
    if (c.t) { goto L_06079EB0; }  // 06079EAA bt 0x06079EB0
    c.r[10] = ld32(0x06079F44u);  // 06079EAC mov.l 0x06079F44,r10
    c.r[9] = ld32(0x06079F30u);  // 06079EAE mov.l 0x06079F30,r9
L_06079EB0:
    c.r[6] += 2;  // 06079EB0 add #2,r6
    c.r[0] = ld32(0x06079F3Cu);  // 06079EB2 mov.l 0x06079F3C,r0
    c.r[7] = c.r[10];  // 06079EB4 mov r10,r7
    c.r[5] = 0xFFFFFFFFu;  // 06079EB6 mov #-1,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06079EB8 mov.b @r6,r6
    c.r[4] = 0x11u;  // 06079EBA mov #17,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06079EBC extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06079EC2u; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079EC2u) return; }  // 06079EBE jsr @r0 ; mov.l r9,@-r15
    c.r[2] = ld32(0x06079F48u);  // 06079EC2 mov.l 0x06079F48,r2
    c.r[6] = ld32(0x06079F4Cu);  // 06079EC4 mov.l 0x06079F4C,r6
    c.r[1] = c.r[6];  // 06079EC6 mov r6,r1
    c.r[1] += 88;  // 06079EC8 add #88,r1
    c.r[7] = c.r[14];  // 06079ECA mov r14,r7
    c.r[7] += 2;  // 06079ECC add #2,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079ECE mov.w @r1,r1
    c.r[0] = ld32(0x06079F50u);  // 06079ED0 mov.l 0x06079F50,r0
    c.r[3] = c.r[1] & 0xFFFFu;  // 06079ED2 extu.w r1,r3
    st16(c.r[14], c.r[3]);  // 06079ED4 mov.w r3,@r14
    st16(c.r[2], c.r[1]);  // 06079ED6 mov.w r1,@r2
    c.r[1] = 0x20u;  // 06079ED8 mov #32,r1
    st8(c.r[7], c.r[1]);  // 06079EDA mov.b r1,@r7
    c.r[1] = ld32(0x06079F54u);  // 06079EDC mov.l 0x06079F54,r1
    c.r[2] = ld32(c.r[1]);  // 06079EDE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06079F28u);  // 06079EE0 mov.w 0x06079F28,r1
    c.r[2] += c.r[1];  // 06079EE2 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06079EE4 mov.l r2,@-r15
    c.r[1] = c.r[3];  // 06079EE6 mov r3,r1
    c.r[2] = ld32(c.r[6] + 16);  // 06079EE8 mov.l @(16,r6),r2
    c.r[1] <<= 2;  // 06079EEA shll2 r1
    c.r[2] += c.r[1];  // 06079EEC add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06079EEE mov.l r2,@-r15
    c.r[1] = 0xAu;  // 06079EF0 mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06079EF2 mulu.w r1,r3
    c.r[2] = ld32(c.r[6] + 8);  // 06079EF4 mov.l @(8,r6),r2
    c.r[1] = c.macl;  // 06079EF6 sts macl,r1
    c.r[2] += c.r[1];  // 06079EF8 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06079EFA mov.l r2,@-r15
    c.r[1] = ld32(c.r[6] + 4);  // 06079EFC mov.l @(4,r6),r1
    c.r[5] = c.r[9];  // 06079EFE mov r9,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06079F00 mov.l r1,@-r15
    c.r[1] = ld32(c.r[6]);  // 06079F02 mov.l @r6,r1
    c.r[4] = c.r[10];  // 06079F04 mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06079F06 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079F08 mov.l r8,@-r15
    c.r[1] = ld32(0x06079F58u);  // 06079F0A mov.l 0x06079F58,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06079F0C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06079F0E mov.l r8,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x06079F14u; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06079F14u) return; }  // 06079F10 jsr @r0 ; mov r14,r6
    c.r[14] += 4;  // 06079F14 add #4,r14
L_06079F16:
    c.r[15] = c.r[14];  // 06079F16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06079F18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06079F1A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06079F1C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06079F1E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06079F20 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079F2Au);  // 06079F22 mov.w 0x06079F2A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079F24 rts ; mov.l @r15+,r8
}

void f_06079F60(SH2Context& c) {
    ran[1682] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079F60 mov.l r14,@-r15
    c.r[1] = ld32(0x06079F8Cu);  // 06079F62 mov.l 0x06079F8C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06079F64 mov.w @r1,r2
    c.r[14] = c.r[15];  // 06079F66 mov r15,r14
    c.r[1] = ld32(0x06079F90u);  // 06079F68 mov.l 0x06079F90,r1
    c.r[1] = ld32(c.r[1]);  // 06079F6A mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06079F6C extu.w r2,r2
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06079F6E dmulu.l r1,r2
    c.r[7] = ld32(0x06079F94u);  // 06079F70 mov.l 0x06079F94,r7
    c.r[1] = c.mach;  // 06079F72 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06079F74 shlr r1
    c.r[3] = c.r[1];  // 06079F76 mov r1,r3
    c.r[3] += c.r[3];  // 06079F78 add r3,r3
    c.r[3] += c.r[1];  // 06079F7A add r1,r3
    c.r[2] -= c.r[3];  // 06079F7C sub r3,r2
    c.r[2] += 1;  // 06079F7E add #1,r2
    st8(c.r[7], c.r[2]);  // 06079F80 mov.b r2,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079F88u);  // 06079F82 mov.w 0x06079F88,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079F84 rts ; mov.l @r15+,r14
}

void f_06079F98(SH2Context& c) {
    ran[1683] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079F98 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06079F9A mov r15,r14
    c.r[3] = ld32(0x06079FD8u);  // 06079F9C mov.l 0x06079FD8,r3
    c.r[2] = ld32(0x06079FDCu);  // 06079F9E mov.l 0x06079FDC,r2
    c.r[5] = ld32(0x06079FE0u);  // 06079FA0 mov.l 0x06079FE0,r5
    c.r[6] = c.r[2];  // 06079FA2 mov r2,r6
    c.r[1] = ld32(c.r[2]);  // 06079FA4 mov.l @r2,r1
    c.r[0] = 0x0u;  // 06079FA6 mov #0,r0
    c.r[1] += 1;  // 06079FA8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079FAA mov.b @r1,r1
    c.r[7] = 0x2u;  // 06079FAC mov #2,r7
    st8(c.r[3], c.r[1]);  // 06079FAE mov.b r1,@r3
L_06079FB0:
    c.r[3] = ld32(c.r[6]);  // 06079FB0 mov.l @r6,r3
    c.r[3] += c.r[0];  // 06079FB2 add r0,r3
    c.r[1] = c.r[3];  // 06079FB4 mov r3,r1
    c.r[1] += 2;  // 06079FB6 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079FB8 mov.b @r1,r2
    c.r[3] += 3;  // 06079FBA add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06079FBC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079FBE mov.b @r3,r1
    c.r[2] <<= 8;  // 06079FC0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06079FC2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06079FC4 or r1,r2
    st16(c.r[0] + c.r[5], c.r[2]);  // 06079FC6 mov.w r2,@(r0,r5)
    c.r[0] += 2;  // 06079FC8 add #2,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[7];  // 06079FCA cmp/gt r7,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { SH2_POLL(c); goto L_06079FB0; } }  // 06079FCC bf/s 0x06079FB0 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06079FD6u);  // 06079FD0 mov.w 0x06079FD6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06079FD2 rts ; mov.l @r15+,r14
}

void f_06079FE4(SH2Context& c) {
    ran[1684] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06079FE4 mov.l r14,@-r15
    c.r[1] = ld32(0x0607A23Cu);  // 06079FE6 mov.l 0x0607A23C,r1
    c.r[3] = ld32(c.r[1]);  // 06079FE8 mov.l @r1,r3
    c.r[1] = ld32(0x0607A240u);  // 06079FEA mov.l 0x0607A240,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06079FEC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06079FEE extu.b r1,r1
    c.r[2] = c.r[1];  // 06079FF0 mov r1,r2
    c.r[2] <<= 2;  // 06079FF2 shll2 r2
    c.r[2] += c.r[1];  // 06079FF4 add r1,r2
    c.r[2] <<= 2;  // 06079FF6 shll2 r2
    c.r[3] += c.r[2];  // 06079FF8 add r2,r3
    c.r[3] += 50;  // 06079FFA add #50,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06079FFC mov.b @r3,r0
    c.r[1] = ld32(0x0607A244u);  // 06079FFE mov.l 0x0607A244,r1
    c.r[0] &= 0x3Fu;  // 0607A000 and #63,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A002 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607A004 extu.b r1,r2
    c.r[1] = 0xCu;  // 0607A006 mov #12,r1
    c.r[2] -= 1;  // 0607A008 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0607A00A cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607A078; } }  // 0607A00C bt/s 0x0607A078 ; mov r15,r14
    c.r[1] = c.r[2];  // 0607A010 mov r2,r1
    c.r[1] += c.r[1];  // 0607A012 add r1,r1
    c.r[0] = 0x0607A020u;  // 0607A014 mova 0x0607A020,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607A016 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607A018 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607A03Au: goto L_0607A03A; case 0x0607A230u: goto L_0607A230; case 0x0607A078u: goto L_0607A078; default: sh2_call(c, x); return; } }  // 0607A01A jmp @r0 ; nop
L_0607A03A:
    c.r[1] = ld32(0x0607A248u);  // 0607A03A mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A03C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A03E extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A040 mov.l 0x0607A24C,r1
    c.r[2] <<= 2;  // 0607A042 shll2 r2
    c.r[2] <<= 2;  // 0607A044 shll2 r2
    c.r[7] = c.r[2];  // 0607A046 mov r2,r7
    c.r[1] = ld32(c.r[1]);  // 0607A048 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A04A mov r2,r0
    c.r[7] += c.r[1];  // 0607A04C add r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A04E mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607A250u);  // 0607A050 mov.l 0x0607A250,r3
    st8(c.r[3], c.r[1]);  // 0607A052 mov.b r1,@r3
    c.r[1] = ld32(0x0607A23Cu);  // 0607A054 mov.l 0x0607A23C,r1
    c.r[3] = ld32(c.r[1]);  // 0607A056 mov.l @r1,r3
    c.r[1] = ld32(0x0607A240u);  // 0607A058 mov.l 0x0607A240,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A05A mov.b @r1,r1
    c.r[7] += 1;  // 0607A05C add #1,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0607A05E extu.b r1,r1
    c.r[2] = c.r[1];  // 0607A060 mov r1,r2
    c.r[2] <<= 2;  // 0607A062 shll2 r2
    c.r[2] += c.r[1];  // 0607A064 add r1,r2
    c.r[2] <<= 2;  // 0607A066 shll2 r2
    c.r[3] += c.r[2];  // 0607A068 add r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607A06A mov.b @r7,r1
    c.r[3] += 62;  // 0607A06C add #62,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607A06E mov.b @r3,r2
    c.r[6] = ld32(0x0607A254u);  // 0607A070 mov.l 0x0607A254,r6
    c.r[1] -= c.r[2];  // 0607A072 sub r2,r1
    st8(c.r[6], c.r[1]); goto L_0607A230;  // 0607A074 bra 0x0607A230 ; mov.b r1,@r6
L_0607A078:
    c.r[1] = ld32(0x0607A23Cu);  // 0607A078 mov.l 0x0607A23C,r1
    c.r[6] = ld32(c.r[1]);  // 0607A07A mov.l @r1,r6
    c.r[1] = ld32(0x0607A240u);  // 0607A07C mov.l 0x0607A240,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A07E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607A080 extu.b r1,r1
    c.r[2] = c.r[1];  // 0607A082 mov r1,r2
    c.r[2] <<= 2;  // 0607A084 shll2 r2
    c.r[2] += c.r[1];  // 0607A086 add r1,r2
    c.r[2] <<= 2;  // 0607A088 shll2 r2
    c.r[6] += c.r[2];  // 0607A08A add r2,r6
    c.r[6] += 62;  // 0607A08C add #62,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607A08E mov.b @r6,r7
    c.r[1] = ld32(0x0607A258u);  // 0607A090 mov.l 0x0607A258,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A092 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607A094 extu.b r1,r2
    c.r[0] = c.r[2];  // 0607A096 mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0607A098 cmp/eq #2,r0
    { const bool k = c.t; c.r[5] = c.r[7] & 0xFFu; if (k) { goto L_0607A0DE; } }  // 0607A09A bt/s 0x0607A0DE ; extu.b r7,r5
    c.r[1] = 0x2u;  // 0607A09E mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607A0A0 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0607A0B0; } }  // 0607A0A2 bt/s 0x0607A0B0 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 0607A0A6 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0607A0B8; } }  // 0607A0A8 bt/s 0x0607A0B8 ; mov r5,r0
    goto L_0607A154;  // 0607A0AC bra 0x0607A154 ; nop
L_0607A0B0:
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0607A116; } }  // 0607A0B0 bt/s 0x0607A116 ; mov r5,r0
    goto L_0607A154;  // 0607A0B4 bra 0x0607A154 ; nop
L_0607A0B8:
    c.t = c.r[0] == 0x63u;  // 0607A0B8 cmp/eq #99,r0
    if (!c.t) { goto L_0607A0C6; }  // 0607A0BA bf 0x0607A0C6
    c.r[2] = ld32(0x0607A25Cu);  // 0607A0BC mov.l 0x0607A25C,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A0BE mov.b @r2,r2
    c.r[1] = ld32(0x0607A250u);  // 0607A0C0 mov.l 0x0607A250,r1
    st8(c.r[1], c.r[2]); goto L_0607A13A;  // 0607A0C2 bra 0x0607A13A ; mov.b r2,@r1
L_0607A0C6:
    c.r[1] = ld32(0x0607A248u);  // 0607A0C6 mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A0C8 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A0CA extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A0CC mov.l 0x0607A24C,r1
    c.r[2] <<= 2;  // 0607A0CE shll2 r2
    c.r[2] <<= 2;  // 0607A0D0 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0607A0D2 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A0D4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A0D6 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607A250u);  // 0607A0D8 mov.l 0x0607A250,r3
    c.r[1] += c.r[7]; goto L_0607A138;  // 0607A0DA bra 0x0607A138 ; add r7,r1
L_0607A0DE:
    c.r[1] = ld32(0x0607A248u);  // 0607A0DE mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A0E0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A0E2 extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A0E4 mov.l 0x0607A24C,r1
    c.r[2] <<= 2;  // 0607A0E6 shll2 r2
    c.r[2] <<= 2;  // 0607A0E8 shll2 r2
    c.r[7] = c.r[2];  // 0607A0EA mov r2,r7
    c.r[1] = ld32(c.r[1]);  // 0607A0EC mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A0EE mov r2,r0
    c.r[7] += c.r[1];  // 0607A0F0 add r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A0F2 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607A250u);  // 0607A0F4 mov.l 0x0607A250,r3
    c.r[0] = c.r[5];  // 0607A0F6 mov r5,r0
    c.t = c.r[0] == 0x63u;  // 0607A0F8 cmp/eq #99,r0
    { const bool k = !c.t; st8(c.r[3], c.r[1]); if (k) { goto L_0607A108; } }  // 0607A0FA bf/s 0x0607A108 ; mov.b r1,@r3
    c.r[2] = ld32(0x0607A260u);  // 0607A0FE mov.l 0x0607A260,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A100 mov.b @r2,r2
    c.r[1] = ld32(0x0607A254u);  // 0607A102 mov.l 0x0607A254,r1
    st8(c.r[1], c.r[2]); goto L_0607A1A2;  // 0607A104 bra 0x0607A1A2 ; mov.b r2,@r1
L_0607A108:
    c.r[7] += 1;  // 0607A108 add #1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607A10A mov.b @r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607A10C mov.b @r6,r3
    c.r[1] = ld32(0x0607A254u);  // 0607A10E mov.l 0x0607A254,r1
    c.r[2] += c.r[3];  // 0607A110 add r3,r2
    st8(c.r[1], c.r[2]); goto L_0607A19E;  // 0607A112 bra 0x0607A19E ; mov.b r2,@r1
L_0607A116:
    c.t = c.r[0] == 0x63u;  // 0607A116 cmp/eq #99,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0607A122; } }  // 0607A118 bf/s 0x0607A122 ; mov #0,r1
    c.r[2] = ld32(0x0607A250u);  // 0607A11C mov.l 0x0607A250,r2
    st8(c.r[2], c.r[1]); goto L_0607A13A;  // 0607A11E bra 0x0607A13A ; mov.b r1,@r2
L_0607A122:
    c.r[1] = ld32(0x0607A248u);  // 0607A122 mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A124 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A126 extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A128 mov.l 0x0607A24C,r1
    c.r[2] <<= 2;  // 0607A12A shll2 r2
    c.r[2] <<= 2;  // 0607A12C shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0607A12E mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A130 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A132 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607A250u);  // 0607A134 mov.l 0x0607A250,r3
    c.r[1] -= c.r[7];  // 0607A136 sub r7,r1
L_0607A138:
    st8(c.r[3], c.r[1]);  // 0607A138 mov.b r1,@r3
L_0607A13A:
    c.r[1] = ld32(0x0607A248u);  // 0607A13A mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A13C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A13E extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A140 mov.l 0x0607A24C,r1
    c.r[1] = ld32(c.r[1]);  // 0607A142 mov.l @r1,r1
    c.r[2] <<= 2;  // 0607A144 shll2 r2
    c.r[2] <<= 2;  // 0607A146 shll2 r2
    c.r[2] += c.r[1];  // 0607A148 add r1,r2
    c.r[2] += 1;  // 0607A14A add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A14C mov.b @r2,r1
    c.r[3] = ld32(0x0607A254u);  // 0607A14E mov.l 0x0607A254,r3
    st8(c.r[3], c.r[1]); goto L_0607A19E;  // 0607A150 bra 0x0607A19E ; mov.b r1,@r3
L_0607A154:
    c.r[1] = ld32(0x0607A248u);  // 0607A154 mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A156 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A158 extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A15A mov.l 0x0607A24C,r1
    c.r[2] <<= 2;  // 0607A15C shll2 r2
    c.r[2] <<= 2;  // 0607A15E shll2 r2
    c.r[6] = c.r[2];  // 0607A160 mov r2,r6
    c.r[1] = ld32(c.r[1]);  // 0607A162 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A164 mov r2,r0
    c.r[6] += c.r[1];  // 0607A166 add r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A168 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0607A250u);  // 0607A16A mov.l 0x0607A250,r3
    c.r[0] = c.r[5];  // 0607A16C mov r5,r0
    c.t = c.r[0] == 0x63u;  // 0607A16E cmp/eq #99,r0
    { const bool k = !c.t; st8(c.r[3], c.r[1]); if (k) { goto L_0607A17C; } }  // 0607A170 bf/s 0x0607A17C ; mov.b r1,@r3
    c.r[2] = ld32(0x0607A254u);  // 0607A174 mov.l 0x0607A254,r2
    c.r[1] = 0x0u;  // 0607A176 mov #0,r1
    st8(c.r[2], c.r[1]); goto L_0607A1A2;  // 0607A178 bra 0x0607A1A2 ; mov.b r1,@r2
L_0607A17C:
    c.r[1] = ld32(0x0607A23Cu);  // 0607A17C mov.l 0x0607A23C,r1
    c.r[3] = ld32(c.r[1]);  // 0607A17E mov.l @r1,r3
    c.r[1] = ld32(0x0607A240u);  // 0607A180 mov.l 0x0607A240,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A182 mov.b @r1,r1
    c.r[6] += 1;  // 0607A184 add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0607A186 extu.b r1,r1
    c.r[2] = c.r[1];  // 0607A188 mov r1,r2
    c.r[2] <<= 2;  // 0607A18A shll2 r2
    c.r[2] += c.r[1];  // 0607A18C add r1,r2
    c.r[2] <<= 2;  // 0607A18E shll2 r2
    c.r[3] += c.r[2];  // 0607A190 add r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607A192 mov.b @r6,r1
    c.r[3] += 62;  // 0607A194 add #62,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607A196 mov.b @r3,r2
    c.r[7] = ld32(0x0607A254u);  // 0607A198 mov.l 0x0607A254,r7
    c.r[1] -= c.r[2];  // 0607A19A sub r2,r1
    st8(c.r[7], c.r[1]);  // 0607A19C mov.b r1,@r7
L_0607A19E:
    c.r[0] = c.r[5];  // 0607A19E mov r5,r0
    c.t = c.r[0] == 0x63u;  // 0607A1A0 cmp/eq #99,r0
L_0607A1A2:
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0607A232; } }  // 0607A1A2 bf/s 0x0607A232 ; mov r14,r15
    c.r[1] = ld32(0x0607A248u);  // 0607A1A6 mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A1A8 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A1AA extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A1AC mov.l 0x0607A24C,r1
    c.r[2] <<= 2;  // 0607A1AE shll2 r2
    c.r[2] <<= 2;  // 0607A1B0 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0607A1B2 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A1B4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A1B6 mov.b @(r0,r1),r1
    c.r[7] = ld32(0x0607A250u);  // 0607A1B8 mov.l 0x0607A250,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607A1BA mov.b @r7,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0607A1BC extu.b r1,r2
    c.r[3] -= c.r[2];  // 0607A1BE sub r2,r3
    c.t = (int32_t)c.r[3] >= 0;  // 0607A1C0 cmp/pz r3
    if (c.t) { goto L_0607A1C6; }  // 0607A1C2 bt 0x0607A1C6
    c.r[3] = 0u - c.r[3];  // 0607A1C4 neg r3,r3
L_0607A1C6:
    c.r[1] = 0x4u;  // 0607A1C6 mov #4,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0607A1C8 cmp/gt r1,r3
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0607A1E8; } }  // 0607A1CA bt/s 0x0607A1E8 ; mov r5,r0
    c.r[1] = ld32(0x0607A258u);  // 0607A1CE mov.l 0x0607A258,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A1D0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607A1D2 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0607A1D4 cmp/eq #1,r0
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_0607A1E0; } }  // 0607A1D6 bf/s 0x0607A1E0 ; mov r7,r3
    c.r[1] = c.r[2];  // 0607A1DA mov r2,r1
    c.r[1] += 5; goto L_0607A1E4;  // 0607A1DC bra 0x0607A1E4 ; add #5,r1
L_0607A1E0:
    c.r[1] = c.r[2];  // 0607A1E0 mov r2,r1
    c.r[1] -= 5;  // 0607A1E2 add #-5,r1
L_0607A1E4:
    st8(c.r[3], c.r[1]);  // 0607A1E4 mov.b r1,@r3
    c.r[0] = c.r[5];  // 0607A1E6 mov r5,r0
L_0607A1E8:
    c.t = c.r[0] == 0x63u;  // 0607A1E8 cmp/eq #99,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0607A232; } }  // 0607A1EA bf/s 0x0607A232 ; mov r14,r15
    c.r[1] = ld32(0x0607A248u);  // 0607A1EE mov.l 0x0607A248,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A1F0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A1F2 extu.b r2,r2
    c.r[1] = ld32(0x0607A24Cu);  // 0607A1F4 mov.l 0x0607A24C,r1
    c.r[1] = ld32(c.r[1]);  // 0607A1F6 mov.l @r1,r1
    c.r[2] <<= 2;  // 0607A1F8 shll2 r2
    c.r[2] <<= 2;  // 0607A1FA shll2 r2
    c.r[2] += c.r[1];  // 0607A1FC add r1,r2
    c.r[2] += 1;  // 0607A1FE add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A200 mov.b @r2,r1
    c.r[7] = ld32(0x0607A254u);  // 0607A202 mov.l 0x0607A254,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607A204 mov.b @r7,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0607A206 extu.b r1,r2
    c.r[3] -= c.r[2];  // 0607A208 sub r2,r3
    c.t = (int32_t)c.r[3] >= 0;  // 0607A20A cmp/pz r3
    if (c.t) { goto L_0607A210; }  // 0607A20C bt 0x0607A210
    c.r[3] = 0u - c.r[3];  // 0607A20E neg r3,r3
L_0607A210:
    c.r[1] = 0x4u;  // 0607A210 mov #4,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0607A212 cmp/gt r1,r3
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0607A232; } }  // 0607A214 bt/s 0x0607A232 ; mov r14,r15
    c.r[1] = ld32(0x0607A258u);  // 0607A218 mov.l 0x0607A258,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A21A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607A21C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607A21E tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_0607A22A; } }  // 0607A220 bt/s 0x0607A22A ; mov r7,r3
    c.r[1] = c.r[2];  // 0607A224 mov r2,r1
    c.r[1] += 5; goto L_0607A22E;  // 0607A226 bra 0x0607A22E ; add #5,r1
L_0607A22A:
    c.r[1] = c.r[2];  // 0607A22A mov r2,r1
    c.r[1] -= 5;  // 0607A22C add #-5,r1
L_0607A22E:
    st8(c.r[3], c.r[1]);  // 0607A22E mov.b r1,@r3
L_0607A230:
    c.r[15] = c.r[14];  // 0607A230 mov r14,r15
L_0607A232:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A238u);  // 0607A232 mov.w 0x0607A238,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A234 rts ; mov.l @r15+,r14
}

void f_0607A26C(SH2Context& c) {
    ran[1685] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607A26C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607A26E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607A270 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607A272 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607A274 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607A276 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A278 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A27A sts.l pr,@-r15
    c.r[15] -= 4;  // 0607A27C add #-4,r15
    c.r[14] = c.r[15];  // 0607A27E mov r15,r14
    c.r[3] = ld32(0x0607A330u);  // 0607A280 mov.l 0x0607A330,r3
    c.r[0] = ld32(0x0607A334u);  // 0607A282 mov.l 0x0607A334,r0
    c.r[2] = ld32(c.r[0]);  // 0607A284 mov.l @r0,r2
    c.r[10] = ld32(0x0607A338u);  // 0607A286 mov.l 0x0607A338,r10
    c.r[1] = c.r[2];  // 0607A288 mov r2,r1
    c.r[1] += 1;  // 0607A28A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A28C mov.b @r1,r1
    c.r[0] = ld32(0x0607A33Cu);  // 0607A28E mov.l 0x0607A33C,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0607A290 extu.b r1,r1
    st16(c.r[3], c.r[1]);  // 0607A292 mov.w r1,@r3
    c.r[11] = c.r[1];  // 0607A294 mov r1,r11
    c.r[11] += c.r[11];  // 0607A296 add r11,r11
    c.r[11] += c.r[1];  // 0607A298 add r1,r11
    c.r[11] <<= 2;  // 0607A29A shll2 r11
    c.r[1] = c.r[2];  // 0607A29C mov r2,r1
    c.r[0] = ld32(c.r[0] + 12);  // 0607A29E mov.l @(12,r0),r0
    c.r[1] += 2;  // 0607A2A0 add #2,r1
    st32(c.r[14], c.r[0]);  // 0607A2A2 mov.l r0,@r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A2A4 mov.b @r1,r4
    c.r[2] += 3;  // 0607A2A6 add #3,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0607A2A8 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A2AA mov.b @r2,r1
    c.r[4] <<= 8;  // 0607A2AC shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0607A2AE extu.b r1,r1
    c.r[4] |= c.r[1];  // 0607A2B0 or r1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607A2B6u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A2B6u) return; }  // 0607A2B2 jsr @r10 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0607A2B6 mov r0,r4
    c.r[5] = c.r[1];  // 0607A2B8 mov r1,r5
    c.r[1] = ld32(0x0607A340u);  // 0607A2BA mov.l 0x0607A340,r1
    c.r[8] = ld32(c.r[1]);  // 0607A2BC mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0607A2BE mov.l @(4,r1),r9
    c.r[0] = ld32(0x0607A344u);  // 0607A2C0 mov.l 0x0607A344,r0
    c.r[6] = c.r[8];  // 0607A2C2 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0607A2C8u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A2C8u) return; }  // 0607A2C4 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0607A2C8 mov r0,r4
    c.r[12] = ld32(0x0607A348u);  // 0607A2CA mov.l 0x0607A348,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0607A2D0u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A2D0u) return; }  // 0607A2CC jsr @r12 ; mov r1,r5
    c.r[1] = c.r[0];  // 0607A2D0 mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607A2D2 mov.l @r14,r0
    st32(c.r[0] + c.r[11], c.r[1]);  // 0607A2D4 mov.l r1,@(r0,r11)
    c.r[0] = ld32(0x0607A33Cu);  // 0607A2D6 mov.l 0x0607A33C,r0
    c.r[13] = ld32(c.r[0] + 12);  // 0607A2D8 mov.l @(12,r0),r13
    c.r[0] = ld32(0x0607A334u);  // 0607A2DA mov.l 0x0607A334,r0
    c.r[2] = ld32(c.r[0]);  // 0607A2DC mov.l @r0,r2
    c.r[13] += c.r[11];  // 0607A2DE add r11,r13
    c.r[1] = c.r[2];  // 0607A2E0 mov r2,r1
    c.r[1] += 4;  // 0607A2E2 add #4,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A2E4 mov.b @r1,r4
    c.r[2] += 5;  // 0607A2E6 add #5,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0607A2E8 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A2EA mov.b @r2,r1
    c.r[4] <<= 8;  // 0607A2EC shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0607A2EE extu.b r1,r1
    c.r[4] |= c.r[1];  // 0607A2F0 or r1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607A2F6u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A2F6u) return; }  // 0607A2F2 jsr @r10 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0607A2F6 mov r0,r4
    c.r[5] = c.r[1];  // 0607A2F8 mov r1,r5
    c.r[6] = c.r[8];  // 0607A2FA mov r8,r6
    c.r[0] = ld32(0x0607A344u);  // 0607A2FC mov.l 0x0607A344,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A302u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A302u) return; }  // 0607A2FE jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0607A302 mov r0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0607A308u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A308u) return; }  // 0607A304 jsr @r12 ; mov r1,r5
    c.r[1] = c.r[0];  // 0607A308 mov r0,r1
    st32(c.r[13] + 4, c.r[1]);  // 0607A30A mov.l r1,@(4,r13)
    c.r[0] = ld32(0x0607A33Cu);  // 0607A30C mov.l 0x0607A33C,r0
    c.r[14] += 4;  // 0607A30E add #4,r14
    c.r[1] = ld32(c.r[0] + 12);  // 0607A310 mov.l @(12,r0),r1
    c.r[15] = c.r[14];  // 0607A312 mov r14,r15
    c.r[11] += c.r[1];  // 0607A314 add r1,r11
    c.r[1] = ld32(0x0607A34Cu);  // 0607A316 mov.l 0x0607A34C,r1
    st32(c.r[11] + 8, c.r[1]);  // 0607A318 mov.l r1,@(8,r11)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607A31A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607A31C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607A31E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607A320 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607A322 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607A324 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607A326 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A32Eu);  // 0607A328 mov.w 0x0607A32E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A32A rts ; mov.l @r15+,r8
}

void f_0607A350(SH2Context& c) {
    ran[1686] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607A350 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607A352 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607A354 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607A356 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A358 sts.l pr,@-r15
    c.r[15] -= 4;  // 0607A35A add #-4,r15
    c.r[12] = ld32(0x0607A40Cu);  // 0607A35C mov.l 0x0607A40C,r12
    c.r[11] = ld32(0x0607A410u);  // 0607A35E mov.l 0x0607A410,r11
    c.r[8] = ld32(0x0607A414u);  // 0607A360 mov.l 0x0607A414,r8
    c.r[6] = c.r[8];  // 0607A362 mov r8,r6
    c.r[6] += 88;  // 0607A364 add #88,r6
    c.r[1] = 0x0u;  // 0607A366 mov #0,r1
    st16(c.r[6], c.r[1]);  // 0607A368 mov.w r1,@r6
    c.r[0] = ld32(0x0607A418u);  // 0607A36A mov.l 0x0607A418,r0
    st16(c.r[0], c.r[1]);  // 0607A36C mov.w r1,@r0
    c.r[1] = ld32(0x0607A41Cu);  // 0607A36E mov.l 0x0607A41C,r1
    c.r[7] = c.r[12];  // 0607A370 mov r12,r7
    c.r[5] = 0xFFFFFFFFu;  // 0607A372 mov #-1,r5
    c.r[2] = ld32(c.r[1]);  // 0607A374 mov.l @r1,r2
    c.r[4] = 0x11u;  // 0607A376 mov #17,r4
    c.r[2] += 1;  // 0607A378 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0607A37A mov.b @r2+,r1
    st8(c.r[15], c.r[1]);  // 0607A37C mov.b r1,@r15
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A37E mov.b @r2,r6
    c.r[0] = ld32(0x0607A420u);  // 0607A380 mov.l 0x0607A420,r0
    c.r[6] = c.r[6] & 0xFFu;  // 0607A382 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0607A388u; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A388u) return; }  // 0607A384 jsr @r0 ; mov.l r11,@-r15
    c.r[1] = ld32(0x0607A424u);  // 0607A388 mov.l 0x0607A424,r1
    c.r[9] = 0x0u;  // 0607A38A mov #0,r9
    c.r[2] = ld32(c.r[1]);  // 0607A38C mov.l @r1,r2
    c.r[7] = c.r[15];  // 0607A38E mov r15,r7
    c.r[7] += 4;  // 0607A390 add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A408u);  // 0607A392 mov.w 0x0607A408,r1
    c.r[2] += c.r[1];  // 0607A394 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607A396 mov.l r2,@-r15
    c.r[6] = c.r[8];  // 0607A398 mov r8,r6
    c.r[6] += 88;  // 0607A39A add #88,r6
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0607A39C mov.w @r6,r3
    c.r[1] = ld32(c.r[8] + 16);  // 0607A39E mov.l @(16,r8),r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0607A3A0 extu.w r3,r2
    c.r[2] <<= 2;  // 0607A3A2 shll2 r2
    c.r[1] += c.r[2];  // 0607A3A4 add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607A3A6 mov.l r1,@-r15
    c.r[1] = 0xAu;  // 0607A3A8 mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607A3AA mulu.w r1,r3
    c.r[2] = ld32(c.r[8] + 8);  // 0607A3AC mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 0607A3AE sts macl,r1
    c.r[2] += c.r[1];  // 0607A3B0 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607A3B2 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0607A3B4 mov.l @(4,r8),r1
    c.r[5] = c.r[11];  // 0607A3B6 mov r11,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607A3B8 mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 0607A3BA mov.l @r8,r1
    c.r[4] = c.r[12];  // 0607A3BC mov r12,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607A3BE mov.l r1,@-r15
    c.r[1] = 0x7u;  // 0607A3C0 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607A3C2 mov.l r1,@-r15
    c.r[1] = 0x1u;  // 0607A3C4 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607A3C6 mov.l r1,@-r15
    c.r[1] = ld32(0x0607A428u);  // 0607A3C8 mov.l 0x0607A428,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A3CEu; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A3CEu) return; }  // 0607A3CA jsr @r1 ; mov.l r9,@-r15
    c.r[15] += 40;  // 0607A3CE add #40,r15
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 0607A3D0 stc.l sr,@-r15
    c.r[0] = ld32(0x0607A41Cu);  // 0607A3D2 mov.l 0x0607A41C,r0
    c.r[0] = ld32(c.r[0]);  // 0607A3D4 mov.l @r0,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + 2);  // 0607A3D6 mov.b @(2,r0),r0
    c.t = c.r[0] == 0x61u;  // 0607A3D8 cmp/eq #97,r0
    if (!c.t) { goto L_0607A3E0; }  // 0607A3DA bf 0x0607A3E0
    c.r[9] = 0xCu;  // 0607A3DC mov #12,r9
    c.r[9] <<= 16;  // 0607A3DE shll16 r9
L_0607A3E0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 0607A3E0 ldc.l @r15+,sr
    c.r[1] = ld32(0x0607A418u);  // 0607A3E2 mov.l 0x0607A418,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607A3E4 mov.w @r1,r1
    c.r[2] = ld32(c.r[8] + 12);  // 0607A3E6 mov.l @(12,r8),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607A3E8 extu.w r1,r1
    c.r[3] = c.r[1];  // 0607A3EA mov r1,r3
    c.r[3] += c.r[3];  // 0607A3EC add r3,r3
    c.r[3] += c.r[1];  // 0607A3EE add r1,r3
    c.r[3] <<= 2;  // 0607A3F0 shll2 r3
    c.r[3] += c.r[2];  // 0607A3F2 add r2,r3
    st32(c.r[3], c.r[9]);  // 0607A3F4 mov.l r9,@r3
    c.r[1] = ld32(0x0607A42Cu);  // 0607A3F6 mov.l 0x0607A42C,r1
    st32(c.r[3] + 4, c.r[1]);  // 0607A3F8 mov.l r1,@(4,r3)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607A3FA lds.l @r15+,pr
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607A3FC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607A3FE mov.l @r15+,r11
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607A400 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A40Au);  // 0607A402 mov.w 0x0607A40A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A404 rts ; mov.l @r15+,r8
}

void f_0607A438(SH2Context& c) {
    ran[1687] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607A438 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607A43A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607A43C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607A43E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607A440 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607A442 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A444 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A446 sts.l pr,@-r15
    c.r[15] -= 24;  // 0607A448 add #-24,r15
    c.r[14] = c.r[15];  // 0607A44A mov r15,r14
    c.r[2] = 0xFFFFFF80u;  // 0607A44C mov #-128,r2
    st8(c.r[14], c.r[2]);  // 0607A44E mov.b r2,@r14
    c.r[1] = c.r[14];  // 0607A450 mov r14,r1
    c.r[1] += 1;  // 0607A452 add #1,r1
    c.r[3] = 0xFFFFFF84u;  // 0607A454 mov #-124,r3
    st8(c.r[1], c.r[3]);  // 0607A456 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0607A458 mov r14,r1
    c.r[1] += 2;  // 0607A45A add #2,r1
    st8(c.r[1], c.r[2]);  // 0607A45C mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A45E mov r14,r1
    c.r[1] += 3;  // 0607A460 add #3,r1
    st8(c.r[1], c.r[2]);  // 0607A462 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A464 mov r14,r1
    c.r[1] += 4;  // 0607A466 add #4,r1
    st8(c.r[1], c.r[3]);  // 0607A468 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0607A46A mov r14,r1
    c.r[1] += 5;  // 0607A46C add #5,r1
    st8(c.r[1], c.r[2]);  // 0607A46E mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A470 mov r14,r1
    c.r[1] += 6;  // 0607A472 add #6,r1
    st8(c.r[1], c.r[2]);  // 0607A474 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A476 mov r14,r1
    c.r[1] += 7;  // 0607A478 add #7,r1
    st8(c.r[1], c.r[2]);  // 0607A47A mov.b r2,@r1
    c.r[3] = c.r[14];  // 0607A47C mov r14,r3
    c.r[3] += 8;  // 0607A47E add #8,r3
    c.r[1] = 0xFFFFFF86u;  // 0607A480 mov #-122,r1
    st8(c.r[3], c.r[1]);  // 0607A482 mov.b r1,@r3
    c.r[1] = c.r[14];  // 0607A484 mov r14,r1
    c.r[1] += 9;  // 0607A486 add #9,r1
    st8(c.r[1], c.r[2]);  // 0607A488 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A48A mov r14,r1
    c.r[1] += 10;  // 0607A48C add #10,r1
    st8(c.r[1], c.r[2]);  // 0607A48E mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A490 mov r14,r1
    c.r[1] += 11;  // 0607A492 add #11,r1
    st8(c.r[1], c.r[2]);  // 0607A494 mov.b r2,@r1
    c.r[3] = c.r[14];  // 0607A496 mov r14,r3
    c.r[3] += 12;  // 0607A498 add #12,r3
    c.r[1] = 0xFFFFFF88u;  // 0607A49A mov #-120,r1
    st8(c.r[3], c.r[1]);  // 0607A49C mov.b r1,@r3
    c.r[1] = c.r[14];  // 0607A49E mov r14,r1
    c.r[1] += 13;  // 0607A4A0 add #13,r1
    st8(c.r[1], c.r[2]);  // 0607A4A2 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A4A4 mov r14,r1
    c.r[1] += 14;  // 0607A4A6 add #14,r1
    st8(c.r[1], c.r[2]);  // 0607A4A8 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0607A4AA mov r14,r1
    c.r[1] += 15;  // 0607A4AC add #15,r1
    st8(c.r[1], c.r[2]);  // 0607A4AE mov.b r2,@r1
    c.r[0] = ld32(0x0607A69Cu);  // 0607A4B0 mov.l 0x0607A69C,r0
    st32(c.r[14] + 16, c.r[0]);  // 0607A4B2 mov.l r0,@(16,r14)
    c.r[13] = ld32(0x0607A6A0u);  // 0607A4B4 mov.l 0x0607A6A0,r13
    c.r[8] = 0x0u;  // 0607A4B6 mov #0,r8
    c.r[7] = 0xFu;  // 0607A4B8 mov #15,r7
    c.r[3] = ld32(0x0607A6A4u);  // 0607A4BA mov.l 0x0607A6A4,r3
    c.r[2] = 0xFFFFFFFFu;  // 0607A4BC mov #-1,r2
L_0607A4BE:
    c.r[1] = c.r[8];  // 0607A4BE mov r8,r1
    c.r[1] += c.r[3];  // 0607A4C0 add r3,r1
    c.r[1] += 2;  // 0607A4C2 add #2,r1
    c.r[8] += 1;  // 0607A4C4 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 0607A4C6 cmp/gt r7,r8
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_0607A4BE; } }  // 0607A4C8 bf/s 0x0607A4BE ; mov.b r2,@r1
    c.r[8] = 0x0u;  // 0607A4CC mov #0,r8
    c.r[7] = 0xFu;  // 0607A4CE mov #15,r7
    c.r[3] = ld32(0x0607A6A4u);  // 0607A4D0 mov.l 0x0607A6A4,r3
    c.r[2] = 0xFFFFFFFFu;  // 0607A4D2 mov #-1,r2
L_0607A4D4:
    c.r[1] = c.r[8];  // 0607A4D4 mov r8,r1
    c.r[1] += c.r[3];  // 0607A4D6 add r3,r1
    c.r[1] += 18;  // 0607A4D8 add #18,r1
    c.r[8] += 1;  // 0607A4DA add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 0607A4DC cmp/gt r7,r8
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_0607A4D4; } }  // 0607A4DE bf/s 0x0607A4D4 ; mov.b r2,@r1
    c.r[12] = ld32(0x0607A6A8u);  // 0607A4E2 mov.l 0x0607A6A8,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A68Eu);  // 0607A4E4 mov.w 0x0607A68E,r1
    c.r[0] = c.r[12];  // 0607A4E6 mov r12,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0607A4E8 mov.l @(r0,r1),r4
    c.r[1] = ld32(0x0607A6ACu);  // 0607A4EA mov.l 0x0607A6AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A4F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A4F0u) return; }  // 0607A4EC jsr @r1 ; nop
    c.r[1] = ld32(0x0607A6B0u);  // 0607A4F0 mov.l 0x0607A6B0,r1
    c.r[5] = 0x0u;  // 0607A4F2 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607A4F8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A4F8u) return; }  // 0607A4F4 jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A690u);  // 0607A4F8 mov.w 0x0607A690,r1
    c.r[0] = c.r[12];  // 0607A4FA mov r12,r0
    c.r[6] = 0x0u;  // 0607A4FC mov #0,r6
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0607A4FE mov.l @(r0,r1),r4
    c.r[1] = ld32(0x0607A6B4u);  // 0607A500 mov.l 0x0607A6B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A506u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A506u) return; }  // 0607A502 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x0607A6B8u);  // 0607A506 mov.l 0x0607A6B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A50Cu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A50Cu) return; }  // 0607A508 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x0607A6BCu);  // 0607A50C mov.l 0x0607A6BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A512u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A512u) return; }  // 0607A50E jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x0607A6C0u);  // 0607A512 mov.l 0x0607A6C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A518u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A518u) return; }  // 0607A514 jsr @r1 ; mov #2,r4
    c.r[4] = ld32(0x0607A6C4u);  // 0607A518 mov.l 0x0607A6C4,r4
    c.r[8] = ld32(0x0607A6C8u);  // 0607A51A mov.l 0x0607A6C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607A520u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A520u) return; }  // 0607A51C jsr @r8 ; mov r4,r5
    c.r[5] = 0x0u;  // 0607A520 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607A526u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A526u) return; }  // 0607A522 jsr @r8 ; mov #0,r4
    c.r[1] = ld32(0x0607A6CCu);  // 0607A526 mov.l 0x0607A6CC,r1
    c.r[8] = ld32(c.r[1]);  // 0607A528 mov.l @r1,r8
    c.r[1] = c.r[8];  // 0607A52A mov r8,r1
    c.r[1] += 3;  // 0607A52C add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A52E mov.b @r1,r4
    c.r[0] = ld32(0x0607A6D0u);  // 0607A530 mov.l 0x0607A6D0,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0607A532 extu.b r4,r4
    c.r[1] = c.r[8];  // 0607A534 mov r8,r1
    c.r[1] += 4;  // 0607A536 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A538 mov.b @r1,r1
    c.r[4] <<= 8;  // 0607A53A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0607A53C extu.b r1,r1
    c.r[4] |= c.r[1];  // 0607A53E or r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607A544u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A544u) return; }  // 0607A540 jsr @r0 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0607A544 mov r0,r4
    c.r[5] = c.r[1];  // 0607A546 mov r1,r5
    c.r[1] = ld32(0x0607A6D4u);  // 0607A548 mov.l 0x0607A6D4,r1
    c.r[9] = ld32(c.r[1]);  // 0607A54A mov.l @r1,r9
    c.r[10] = ld32(c.r[1] + 4);  // 0607A54C mov.l @(4,r1),r10
    c.r[0] = ld32(0x0607A6D8u);  // 0607A54E mov.l 0x0607A6D8,r0
    c.r[6] = c.r[9];  // 0607A550 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0607A556u; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A556u) return; }  // 0607A552 jsr @r0 ; mov r10,r7
    c.r[4] = c.r[0];  // 0607A556 mov r0,r4
    c.r[11] = ld32(0x0607A6DCu);  // 0607A558 mov.l 0x0607A6DC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0607A55Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A55Eu) return; }  // 0607A55A jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0607A55E mov r0,r1
    c.r[0] = ld32(0x0607A6E0u);  // 0607A560 mov.l 0x0607A6E0,r0
    st32(c.r[0], c.r[1]);  // 0607A562 mov.l r1,@r0
    c.r[12] += 84;  // 0607A564 add #84,r12
    c.r[1] = c.r[8];  // 0607A566 mov r8,r1
    c.r[1] += 5;  // 0607A568 add #5,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A56A mov.b @r1,r4
    c.r[0] = ld32(0x0607A6D0u);  // 0607A56C mov.l 0x0607A6D0,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0607A56E extu.b r4,r4
    c.r[1] = c.r[8];  // 0607A570 mov r8,r1
    c.r[1] += 6;  // 0607A572 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A574 mov.b @r1,r1
    c.r[4] <<= 8;  // 0607A576 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0607A578 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0607A57A or r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607A580u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A580u) return; }  // 0607A57C jsr @r0 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0607A580 mov r0,r4
    c.r[5] = c.r[1];  // 0607A582 mov r1,r5
    c.r[6] = c.r[9];  // 0607A584 mov r9,r6
    c.r[0] = ld32(0x0607A6D8u);  // 0607A586 mov.l 0x0607A6D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A58Cu; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A58Cu) return; }  // 0607A588 jsr @r0 ; mov r10,r7
    c.r[4] = c.r[0];  // 0607A58C mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0607A592u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A592u) return; }  // 0607A58E jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0607A592 mov r0,r1
    st32(c.r[12], c.r[1]);  // 0607A594 mov.l r1,@r12
    c.r[8] += 2;  // 0607A596 add #2,r8
    c.r[5] = 0xFFFFFFFFu;  // 0607A598 mov #-1,r5
    c.r[4] = 0x11u;  // 0607A59A mov #17,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0607A59C mov.b @r8,r6
    c.r[0] = ld32(0x0607A6E4u);  // 0607A59E mov.l 0x0607A6E4,r0
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607A5A0 mov.l r13,@-r15
    c.r[7] = ld32(c.r[14] + 16);  // 0607A5A2 mov.l @(16,r14),r7
    { const uint32_t x = c.r[0]; c.pr = 0x0607A5A8u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A5A8u) return; }  // 0607A5A4 jsr @r0 ; extu.b r6,r6
    c.r[5] = c.r[13];  // 0607A5A8 mov r13,r5
    c.r[4] = ld32(c.r[14] + 16);  // 0607A5AA mov.l @(16,r14),r4
    c.r[0] = ld32(0x0607A6E8u);  // 0607A5AC mov.l 0x0607A6E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A5B2u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A5B2u) return; }  // 0607A5AE jsr @r0 ; add #4,r4
    c.r[2] = c.r[13];  // 0607A5B2 mov r13,r2
    c.r[2] += 10;  // 0607A5B4 add #10,r2
    c.r[9] = ld32(0x0607A6ECu);  // 0607A5B6 mov.l 0x0607A6EC,r9
    c.r[8] = 0x0u;  // 0607A5B8 mov #0,r8
    c.r[11] = ld32(c.r[13] + 4);  // 0607A5BA mov.l @(4,r13),r11
    c.r[15] += 4;  // 0607A5BC add #4,r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A5BE mov.b @r2,r1
    c.r[11] -= 4;  // 0607A5C0 add #-4,r11
    c.r[6] = c.r[1] & 0xFFu;  // 0607A5C2 extu.b r1,r6
    c.r[1] = c.r[13];  // 0607A5C4 mov r13,r1
    c.r[1] += 11;  // 0607A5C6 add #11,r1
    c.r[11] >>= 2;  // 0607A5C8 shlr2 r11
    c.r[11] <<= 2;  // 0607A5CA shll2 r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A5CC mov.b @r1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0607A5CE extu.b r1,r12
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12];  // 0607A5D0 cmp/ge r12,r8
    { const bool k = c.t; c.r[11] += c.r[13]; if (k) { goto L_0607A5FA; } }  // 0607A5D2 bt/s 0x0607A5FA ; add r13,r11
    c.r[10] = c.r[6];  // 0607A5D6 mov r6,r10
    c.r[10] <<= 2;  // 0607A5D8 shll2 r10
L_0607A5DA:
    c.r[0] = c.r[8];  // 0607A5DA mov r8,r0
    c.t = c.r[0] == 0x40u;  // 0607A5DC cmp/eq #64,r0
    { const bool k = !c.t; c.r[6] = c.r[10]; if (k) { goto L_0607A5E6; } }  // 0607A5DE bf/s 0x0607A5E6 ; mov r10,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A692u);  // 0607A5E2 mov.w 0x0607A692,r0
    c.r[9] += c.r[0];  // 0607A5E4 add r0,r9
L_0607A5E6:
    c.r[5] = c.r[11];  // 0607A5E6 mov r11,r5
    c.r[0] = ld32(0x0607A6F0u);  // 0607A5E8 mov.l 0x0607A6F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A5EEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A5EEu) return; }  // 0607A5EA jsr @r0 ; mov r9,r4
    c.r[8] += 1;  // 0607A5EE add #1,r8
    c.r[11] += c.r[10];  // 0607A5F0 add r10,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A694u);  // 0607A5F2 mov.w 0x0607A694,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[12];  // 0607A5F4 cmp/ge r12,r8
    { const bool k = !c.t; c.r[9] += c.r[1]; if (k) { SH2_POLL(c); goto L_0607A5DA; } }  // 0607A5F6 bf/s 0x0607A5DA ; add r1,r9
L_0607A5FA:
    c.r[9] = ld32(0x0607A6F4u);  // 0607A5FA mov.l 0x0607A6F4,r9
    c.r[11] = 0x1u;  // 0607A5FC mov #1,r11
    st8(c.r[9], c.r[11]);  // 0607A5FE mov.b r11,@r9
    c.r[6] = ld32(0x0607A6F8u);  // 0607A600 mov.l 0x0607A6F8,r6
    c.r[8] = ld32(0x0607A6A8u);  // 0607A602 mov.l 0x0607A6A8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A696u);  // 0607A604 mov.w 0x0607A696,r1
    c.r[0] = c.r[8];  // 0607A606 mov r8,r0
    c.r[4] = ld32(0x0607A6ECu);  // 0607A608 mov.l 0x0607A6EC,r4
    c.r[10] = ld32(0x0607A6FCu);  // 0607A60A mov.l 0x0607A6FC,r10
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0607A60C mov.l @(r0,r1),r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607A612u; c.r[7] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A612u) return; }  // 0607A60E jsr @r10 ; mov #14,r7
    c.r[0] = ld32(0x0607A700u);  // 0607A612 mov.l 0x0607A700,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A618u; c.r[12] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A618u) return; }  // 0607A614 jsr @r0 ; mov #0,r12
    st8(c.r[9], c.r[12]);  // 0607A618 mov.b r12,@r9
    c.r[0] = ld32(0x0607A6CCu);  // 0607A61A mov.l 0x0607A6CC,r0
    c.r[5] = 0xFFFFFFFFu;  // 0607A61C mov #-1,r5
    c.r[1] = ld32(c.r[0]);  // 0607A61E mov.l @r0,r1
    c.r[4] = 0x11u;  // 0607A620 mov #17,r4
    c.r[1] += 1;  // 0607A622 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A624 mov.b @r1,r6
    c.r[0] = ld32(0x0607A6E4u);  // 0607A626 mov.l 0x0607A6E4,r0
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607A628 mov.l r13,@-r15
    c.r[7] = ld32(c.r[14] + 16);  // 0607A62A mov.l @(16,r14),r7
    { const uint32_t x = c.r[0]; c.pr = 0x0607A630u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A630u) return; }  // 0607A62C jsr @r0 ; extu.b r6,r6
    c.r[0] = ld32(c.r[14] + 16);  // 0607A630 mov.l @(16,r14),r0
    c.r[5] = c.r[13];  // 0607A632 mov r13,r5
    c.r[0] += 4;  // 0607A634 add #4,r0
    st32(c.r[14] + 16, c.r[0]);  // 0607A636 mov.l r0,@(16,r14)
    c.r[0] = ld32(0x0607A6E8u);  // 0607A638 mov.l 0x0607A6E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A63Eu; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A63Eu) return; }  // 0607A63A jsr @r0 ; mov.l @(16,r14),r4
    c.r[3] = 0x4u;  // 0607A63E mov #4,r3
    st8(c.r[9], c.r[11]);  // 0607A640 mov.b r11,@r9
    c.r[1] = ld32(0x0607A704u);  // 0607A642 mov.l 0x0607A704,r1
    c.r[4] = c.r[13];  // 0607A644 mov r13,r4
    c.r[4] += c.r[3];  // 0607A646 add r3,r4
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0607A648 mov.w @r13,r6
    c.r[7] = 0xEu;  // 0607A64A mov #14,r7
    c.r[5] = ld32(c.r[1]);  // 0607A64C mov.l @r1,r5
    c.r[6] = c.r[6] & 0xFFFFu;  // 0607A64E extu.w r6,r6
    c.r[6] += c.r[6];  // 0607A650 add r6,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A698u);  // 0607A652 mov.w 0x0607A698,r1
    c.r[5] += c.r[1];  // 0607A654 add r1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607A65Au; st32(c.r[14] + 20, c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A65Au) return; }  // 0607A656 jsr @r10 ; mov.l r3,@(20,r14)
    c.r[2] = c.r[13];  // 0607A65A mov r13,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 0607A65C mov.w @r2+,r1
    c.r[0] = c.r[8];  // 0607A65E mov r8,r0
    c.r[3] = ld32(c.r[14] + 20);  // 0607A660 mov.l @(20,r14),r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607A662 extu.w r1,r1
    c.r[1] += c.r[1];  // 0607A664 add r1,r1
    c.r[3] += c.r[1];  // 0607A666 add r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607A668 mov.w @r2,r1
    c.r[7] = 0xEu;  // 0607A66A mov #14,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607A66C extu.w r1,r1
    c.r[3] += c.r[1];  // 0607A66E add r1,r3
    c.r[2] = 0x20u;  // 0607A670 mov #32,r2
    c.macl = c.r[1] * c.r[2];  // 0607A672 mul.l r2,r1
    c.r[13] += c.r[3];  // 0607A674 add r3,r13
    c.r[4] = c.r[13];  // 0607A676 mov r13,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A690u);  // 0607A678 mov.w 0x0607A690,r1
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0607A67A mov.l @(r0,r1),r5
    { const uint32_t x = c.r[10]; c.pr = 0x0607A680u; c.r[6] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A680u) return; }  // 0607A67C jsr @r10 ; sts macl,r6
    c.r[0] = ld32(0x0607A700u);  // 0607A680 mov.l 0x0607A700,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A686u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A686u) return; }  // 0607A682 jsr @r0 ; nop
    st8(c.r[9], c.r[12]);  // 0607A686 mov.b r12,@r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A69Au);  // 0607A688 mov.w 0x0607A69A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); goto L_0607A708;  // 0607A68A bra 0x0607A708 ; mov.b @r8,r1
L_0607A708:
    c.r[1] |= c.r[0];  // 0607A708 or r0,r1
    st8(c.r[8], c.r[1]);  // 0607A70A mov.b r1,@r8
    c.r[0] = ld32(0x0607A740u);  // 0607A70C mov.l 0x0607A740,r0
    c.r[1] = ld32(c.r[0]);  // 0607A70E mov.l @r0,r1
    c.r[1] += 7;  // 0607A710 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A712 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607A714 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607A716 tst r1,r1
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0607A724; } }  // 0607A718 bt/s 0x0607A724 ; add #4,r15
    c.r[1] = ld32(0x0607A744u);  // 0607A71C mov.l 0x0607A744,r1
    c.r[5] = 0x6u;  // 0607A71E mov #6,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607A724u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A724u) return; }  // 0607A720 jsr @r1 ; mov #5,r4
L_0607A724:
    c.r[14] += 24;  // 0607A724 add #24,r14
    c.r[15] = c.r[14];  // 0607A726 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607A728 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607A72A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607A72C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607A72E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607A730 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607A732 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607A734 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A73Cu);  // 0607A736 mov.w 0x0607A73C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A738 rts ; mov.l @r15+,r8
}

void f_0607A748(SH2Context& c) {
    ran[1688] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A748 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607A74A mov r15,r14
    c.r[6] = ld32(0x0607A78Cu);  // 0607A74C mov.l 0x0607A78C,r6
    c.r[7] = c.r[6];  // 0607A74E mov r6,r7
    c.r[7] += 120;  // 0607A750 add #120,r7
    c.r[1] = ld32(0x0607A790u);  // 0607A752 mov.l 0x0607A790,r1
    c.r[3] = ld32(c.r[1]);  // 0607A754 mov.l @r1,r3
    c.r[6] += 124;  // 0607A756 add #124,r6
    c.r[1] = c.r[3];  // 0607A758 mov r3,r1
    c.r[1] += 1;  // 0607A75A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A75C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A75E extu.b r2,r2
    c.r[1] = c.r[3];  // 0607A760 mov r3,r1
    c.r[1] += 2;  // 0607A762 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A764 mov.b @r1,r1
    c.r[2] <<= 8;  // 0607A766 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607A768 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607A76A or r1,r2
    st16(c.r[7], c.r[2]);  // 0607A76C mov.w r2,@r7
    c.r[1] = c.r[3];  // 0607A76E mov r3,r1
    c.r[1] += 3;  // 0607A770 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A772 mov.b @r1,r2
    c.r[3] += 4;  // 0607A774 add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607A776 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607A778 mov.b @r3,r1
    c.r[2] <<= 8;  // 0607A77A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607A77C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0607A77E or r1,r2
    st16(c.r[6], c.r[2]);  // 0607A780 mov.w r2,@r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A788u);  // 0607A782 mov.w 0x0607A788,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A784 rts ; mov.l @r15+,r14
}

void f_0607A79C(SH2Context& c) {
    ran[1689] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607A79C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607A79E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607A7A0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607A7A2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607A7A4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607A7A6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A7A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A7AA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607A7AC mov r15,r14
    c.r[9] = ld32(0x0607A858u);  // 0607A7AE mov.l 0x0607A858,r9
    c.r[10] = c.r[9];  // 0607A7B0 mov r9,r10
    c.r[10] += 120;  // 0607A7B2 add #120,r10
    c.r[11] = c.r[9];  // 0607A7B4 mov r9,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0607A7B6 mov.w @r10,r1
    c.r[11] += 124;  // 0607A7B8 add #124,r11
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0607A7BA mov.w @r11,r13
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607A7BC tst r1,r1
    { const bool k = c.t; c.r[12] = c.r[1]; if (k) { goto L_0607A7F4; } }  // 0607A7BE bt/s 0x0607A7F4 ; mov r1,r12
    c.r[1] = c.r[9];  // 0607A7C2 mov r9,r1
    c.r[1] += 126;  // 0607A7C4 add #126,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A7C6 mov.b @r1,r4
    c.r[1] = ld32(0x0607A85Cu);  // 0607A7C8 mov.l 0x0607A85C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A7CEu; c.r[8] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A7CEu) return; }  // 0607A7CA jsr @r1 ; mov r9,r8
    c.r[4] = c.r[0];  // 0607A7CE mov r0,r4
    c.r[5] = c.r[1];  // 0607A7D0 mov r1,r5
    c.r[1] = ld32(0x0607A860u);  // 0607A7D2 mov.l 0x0607A860,r1
    c.r[6] = ld32(c.r[1]);  // 0607A7D4 mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0607A7D6 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0607A864u);  // 0607A7D8 mov.l 0x0607A864,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A7DEu; c.r[8] += 80; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A7DEu) return; }  // 0607A7DA jsr @r1 ; add #80,r8
    c.r[4] = c.r[0];  // 0607A7DE mov r0,r4
    c.r[5] = c.r[1];  // 0607A7E0 mov r1,r5
    c.r[0] = ld32(0x0607A868u);  // 0607A7E2 mov.l 0x0607A868,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A7E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A7E8u) return; }  // 0607A7E4 jsr @r0 ; nop
    c.r[1] = ld32(c.r[8]);  // 0607A7E8 mov.l @r8,r1
    c.r[1] += c.r[0];  // 0607A7EA add r0,r1
    st32(c.r[8], c.r[1]);  // 0607A7EC mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0607A7EE mov.w @r10,r1
    c.r[1] -= 1;  // 0607A7F0 add #-1,r1
    st16(c.r[10], c.r[1]);  // 0607A7F2 mov.w r1,@r10
L_0607A7F4:
    c.r[10] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0607A7F4 mov.w @r11,r10
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[10];  // 0607A7F6 exts.w r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607A7F8 tst r1,r1
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0607A830; } }  // 0607A7FA bt/s 0x0607A830 ; tst r12,r12
    c.r[8] = c.r[9];  // 0607A7FE mov r9,r8
    c.r[9] += 127;  // 0607A800 add #127,r9
    c.r[1] = ld32(0x0607A85Cu);  // 0607A802 mov.l 0x0607A85C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A808u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A808u) return; }  // 0607A804 jsr @r1 ; mov.b @r9,r4
    c.r[4] = c.r[0];  // 0607A808 mov r0,r4
    c.r[5] = c.r[1];  // 0607A80A mov r1,r5
    c.r[1] = ld32(0x0607A860u);  // 0607A80C mov.l 0x0607A860,r1
    c.r[6] = ld32(c.r[1]);  // 0607A80E mov.l @r1,r6
    c.r[7] = ld32(c.r[1] + 4);  // 0607A810 mov.l @(4,r1),r7
    c.r[1] = ld32(0x0607A864u);  // 0607A812 mov.l 0x0607A864,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A818u; c.r[8] += 84; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A818u) return; }  // 0607A814 jsr @r1 ; add #84,r8
    c.r[4] = c.r[0];  // 0607A818 mov r0,r4
    c.r[5] = c.r[1];  // 0607A81A mov r1,r5
    c.r[0] = ld32(0x0607A868u);  // 0607A81C mov.l 0x0607A868,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607A822u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A822u) return; }  // 0607A81E jsr @r0 ; nop
    c.r[1] = ld32(c.r[8]);  // 0607A822 mov.l @r8,r1
    c.r[1] += c.r[0];  // 0607A824 add r0,r1
    st32(c.r[8], c.r[1]);  // 0607A826 mov.l r1,@r8
    c.r[1] = c.r[10];  // 0607A828 mov r10,r1
    c.r[1] -= 1;  // 0607A82A add #-1,r1
    st16(c.r[11], c.r[1]);  // 0607A82C mov.w r1,@r11
    c.t = (c.r[12] & c.r[12]) == 0;  // 0607A82E tst r12,r12
L_0607A830:
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0607A83E; } }  // 0607A830 bf/s 0x0607A83E ; tst r13,r13
    if (!c.t) { goto L_0607A83E; }  // 0607A834 bf 0x0607A83E
    c.r[15] = c.r[14];  // 0607A836 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A854u);  // 0607A838 mov.w 0x0607A854,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0607A844;  // 0607A83A bra 0x0607A844 ; lds.l @r15+,pr
L_0607A83E:
    c.r[0] = ld32(0x0607A86Cu);  // 0607A83E mov.l 0x0607A86C,r0
    c.r[15] = c.r[14];  // 0607A840 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607A842 lds.l @r15+,pr
L_0607A844:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607A844 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607A846 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607A848 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607A84A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607A84C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607A84E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A850 rts ; mov.l @r15+,r8
}

void f_0607A870(SH2Context& c) {
    ran[1690] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607A870 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A872 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A874 sts.l pr,@-r15
    c.r[15] -= 4;  // 0607A876 add #-4,r15
    c.r[14] = c.r[15];  // 0607A878 mov r15,r14
    c.r[1] = 0x0u;  // 0607A87A mov #0,r1
    st32(c.r[14], c.r[1]);  // 0607A87C mov.l r1,@r14
    c.r[8] = ld32(0x0607A8C4u);  // 0607A87E mov.l 0x0607A8C4,r8
    c.r[1] = 0x1u;  // 0607A880 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0607A882 mov.b r1,@r8
    c.r[2] = ld32(0x0607A8C8u);  // 0607A884 mov.l 0x0607A8C8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A8BEu);  // 0607A886 mov.w 0x0607A8BE,r0
    c.r[1] = ld32(0x0607A8CCu);  // 0607A888 mov.l 0x0607A8CC,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607A8C0u);  // 0607A88A mov.w 0x0607A8C0,r6
    c.r[1] = ld32(c.r[1]);  // 0607A88C mov.l @r1,r1
    c.r[7] = 0x11u;  // 0607A88E mov #17,r7
    c.r[1] += 1;  // 0607A890 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A892 mov.b @r1,r1
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0607A894 mov.l @(r0,r2),r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607A896 extu.b r1,r1
    c.r[1] <<= 8;  // 0607A898 shll8 r1
    c.r[1] >>= 2;  // 0607A89A shlr2 r1
    c.r[1] <<= 8;  // 0607A89C shll8 r1
    c.r[5] += c.r[1];  // 0607A89E add r1,r5
    c.r[1] = ld32(0x0607A8D0u);  // 0607A8A0 mov.l 0x0607A8D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A8A6u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A8A6u) return; }  // 0607A8A2 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x0607A8D4u);  // 0607A8A6 mov.l 0x0607A8D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A8ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A8ACu) return; }  // 0607A8A8 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0607A8AC mov #0,r1
    st8(c.r[8], c.r[1]);  // 0607A8AE mov.b r1,@r8
    c.r[14] += 4;  // 0607A8B0 add #4,r14
    c.r[15] = c.r[14];  // 0607A8B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607A8B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607A8B6 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A8C2u);  // 0607A8B8 mov.w 0x0607A8C2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A8BA rts ; mov.l @r15+,r8
}

void f_0607A8D8(SH2Context& c) {
    ran[1691] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A8D8 mov.l r14,@-r15
    c.r[1] = ld32(0x0607A904u);  // 0607A8DA mov.l 0x0607A904,r1
    c.r[1] = ld32(c.r[1]);  // 0607A8DC mov.l @r1,r1
    c.r[1] += 1;  // 0607A8DE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A8E0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607A8E2 extu.b r1,r0
    c.r[0] += c.r[0];  // 0607A8E4 add r0,r0
    c.r[1] = ld32(0x0607A908u);  // 0607A8E6 mov.l 0x0607A908,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607A8E8 mov.w @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607A8EA tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607A8F6; } }  // 0607A8EC bf/s 0x0607A8F6 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A8FEu);  // 0607A8F0 mov.w 0x0607A8FE,r0
    c.r[15] = c.r[14]; goto L_0607A8FA;  // 0607A8F2 bra 0x0607A8FA ; mov r14,r15
L_0607A8F6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A900u);  // 0607A8F6 mov.w 0x0607A900,r0
    c.r[15] = c.r[14];  // 0607A8F8 mov r14,r15
L_0607A8FA:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A8FA rts ; mov.l @r15+,r14
}

void f_0607A90C(SH2Context& c) {
    ran[1692] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A90C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607A90E mov r15,r14
    c.r[1] = ld32(0x0607A924u);  // 0607A910 mov.l 0x0607A924,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A912 mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607A914 mov.l @r15+,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0607A916 extu.b r1,r0
    c.r[0] += c.r[0];  // 0607A918 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607A920u);  // 0607A91A mov.w 0x0607A920,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0607A91C rts ; or r1,r0
}

void f_0607A928(SH2Context& c) {
    ran[1693] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A928 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A92A sts.l pr,@-r15
    c.r[1] = ld32(0x0607A9D0u);  // 0607A92C mov.l 0x0607A9D0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A92E mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0607A930 extu.b r2,r2
    c.r[1] = ld32(0x0607A9D4u);  // 0607A932 mov.l 0x0607A9D4,r1
    c.r[2] <<= 2;  // 0607A934 shll2 r2
    c.r[2] <<= 2;  // 0607A936 shll2 r2
    c.r[3] = c.r[2];  // 0607A938 mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0607A93A mov.l @r1,r1
    c.r[0] = c.r[2];  // 0607A93C mov r2,r0
    c.r[3] += c.r[1];  // 0607A93E add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0607A940 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0607A942 add #1,r3
    c.r[4] = c.r[1] & 0xFFu;  // 0607A944 extu.b r1,r4
    c.r[2] = ld32(0x0607A9D8u);  // 0607A946 mov.l 0x0607A9D8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607A948 mov.b @r3,r1
    c.r[4] -= 9;  // 0607A94A add #-9,r4
    c.r[5] = c.r[1] & 0xFFu;  // 0607A94C extu.b r1,r5
    c.r[1] = c.r[2];  // 0607A94E mov r2,r1
    c.r[1] += 78;  // 0607A950 add #78,r1
    st8(c.r[1], c.r[4]);  // 0607A952 mov.b r4,@r1
    c.r[2] += 79;  // 0607A954 add #79,r2
    c.r[5] -= 6;  // 0607A956 add #-6,r5
    st8(c.r[2], c.r[5]);  // 0607A958 mov.b r5,@r2
    c.r[1] = ld32(0x0607A9DCu);  // 0607A95A mov.l 0x0607A9DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A95C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0607A95E extu.b r1,r2
    c.r[1] = 0x3u;  // 0607A960 mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0607A962 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607A9A0; } }  // 0607A964 bt/s 0x0607A9A0 ; mov r15,r14
    c.r[1] = c.r[2];  // 0607A968 mov r2,r1
    c.r[1] += c.r[1];  // 0607A96A add r1,r1
    c.r[0] = 0x0607A978u;  // 0607A96C mova 0x0607A978,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607A96E mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607A970 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607A980u: goto L_0607A980; case 0x0607A988u: goto L_0607A988; case 0x0607A990u: goto L_0607A990; case 0x0607A998u: goto L_0607A998; default: sh2_call(c, x); return; } }  // 0607A972 jmp @r0 ; nop
L_0607A980:
    c.r[2] = ld32(0x0607A9E0u);  // 0607A980 mov.l 0x0607A9E0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A982 mov.b @r2,r1
    c.r[1] -= 5; goto L_0607A99E;  // 0607A984 bra 0x0607A99E ; add #-5,r1
L_0607A988:
    c.r[2] = ld32(0x0607A9E4u);  // 0607A988 mov.l 0x0607A9E4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A98A mov.b @r2,r1
    c.r[1] += 7; goto L_0607A99E;  // 0607A98C bra 0x0607A99E ; add #7,r1
L_0607A990:
    c.r[2] = ld32(0x0607A9E0u);  // 0607A990 mov.l 0x0607A9E0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A992 mov.b @r2,r1
    c.r[1] += 4; goto L_0607A99E;  // 0607A994 bra 0x0607A99E ; add #4,r1
L_0607A998:
    c.r[2] = ld32(0x0607A9E4u);  // 0607A998 mov.l 0x0607A9E4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A99A mov.b @r2,r1
    c.r[1] -= 8;  // 0607A99C add #-8,r1
L_0607A99E:
    st8(c.r[2], c.r[1]);  // 0607A99E mov.b r1,@r2
L_0607A9A0:
    c.r[1] = ld32(0x0607A9E8u);  // 0607A9A0 mov.l 0x0607A9E8,r1
    c.r[5] = 0x0u;  // 0607A9A2 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607A9A8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A9A8u) return; }  // 0607A9A4 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(0x0607A9D8u);  // 0607A9A8 mov.l 0x0607A9D8,r2
    c.r[1] = c.r[2];  // 0607A9AA mov r2,r1
    c.r[1] += 78;  // 0607A9AC add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607A9AE mov.b @r1,r1
    c.r[2] += 79;  // 0607A9B0 add #79,r2
    c.r[1] += 9;  // 0607A9B2 add #9,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0607A9B4 extu.b r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607A9B6 mov.b @r2,r1
    c.r[1] += 6;  // 0607A9B8 add #6,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0607A9BA extu.b r1,r5
    c.r[1] = ld32(0x0607A9ECu);  // 0607A9BC mov.l 0x0607A9EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607A9C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607A9C2u) return; }  // 0607A9BE jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607A9C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607A9C4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607A9CCu);  // 0607A9C6 mov.w 0x0607A9CC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607A9C8 rts ; mov.l @r15+,r14
}

void f_0607A9F0(SH2Context& c) {
    ran[1694] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607A9F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607A9F2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607A9F4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607A9F6 mov r15,r14
    c.r[3] = ld32(0x0607AA68u);  // 0607A9F8 mov.l 0x0607AA68,r3
    c.r[6] = c.r[3];  // 0607A9FA mov r3,r6
    c.r[6] += 88;  // 0607A9FC add #88,r6
    c.r[1] = ld32(0x0607AA6Cu);  // 0607A9FE mov.l 0x0607AA6C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607AA62u);  // 0607AA00 mov.w 0x0607AA62,r0
    c.r[3] += 90;  // 0607AA02 add #90,r3
    c.r[4] = ld32(0x0607AA70u);  // 0607AA04 mov.l 0x0607AA70,r4
    c.r[7] = ld32(c.r[1]);  // 0607AA06 mov.l @r1,r7
    c.r[8] = ld32(0x0607AA74u);  // 0607AA08 mov.l 0x0607AA74,r8
    c.r[7] += 1;  // 0607AA0A add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607AA0C mov.b @r7,r1
    c.r[5] = 0x1Au;  // 0607AA0E mov #26,r5
    c.r[1] &= c.r[0];  // 0607AA10 and r0,r1
    c.r[2] = c.r[1];  // 0607AA12 mov r1,r2
    c.r[2] >>= 2;  // 0607AA14 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607AA16 shlr r2
    c.r[2] >>= 2;  // 0607AA18 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0607AA1A mov.w @r6,r1
    c.r[0] = 0x3u;  // 0607AA1C mov #3,r0
    c.r[1] += c.r[2];  // 0607AA1E add r2,r1
    st16(c.r[6], c.r[1]);  // 0607AA20 mov.w r1,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607AA22 mov.b @r7,r1
    c.r[2] = 0x1Cu;  // 0607AA24 mov #28,r2
    c.r[2] &= c.r[1];  // 0607AA26 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607AA28 mov.b @r3,r1
    c.r[2] >>= 2;  // 0607AA2A shlr2 r2
    c.r[2] += c.r[1];  // 0607AA2C add r1,r2
    st8(c.r[3], c.r[2]);  // 0607AA2E mov.b r2,@r3
    c.r[1] = ld32(0x0607AA78u);  // 0607AA30 mov.l 0x0607AA78,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607AA32 mov.b @r7,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607AA64u);  // 0607AA34 mov.w 0x0607AA64,r2
    c.r[3] &= c.r[0];  // 0607AA36 and r0,r3
    c.r[3] <<= 2;  // 0607AA38 shll2 r3
    c.r[3] <<= 2;  // 0607AA3A shll2 r3
    c.r[3] += 3;  // 0607AA3C add #3,r3
    c.r[0] = c.r[1];  // 0607AA3E mov r1,r0
    { const uint32_t x = c.r[8]; c.pr = 0x0607AA44u; st8(c.r[0] + c.r[2], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AA44u) return; }  // 0607AA40 jsr @r8 ; mov.b r3,@(r0,r2)
    c.r[1] = c.r[0];  // 0607AA44 mov r0,r1
    c.r[5] = 0x0u;  // 0607AA46 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607AA4Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AA4Cu) return; }  // 0607AA48 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0607AA4C mov r0,r2
    c.r[1] = ld32(0x0607AA7Cu);  // 0607AA4E mov.l 0x0607AA7C,r1
    c.r[5] = c.r[2];  // 0607AA50 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607AA56u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AA56u) return; }  // 0607AA52 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0607AA56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607AA58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607AA5A mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607AA66u);  // 0607AA5C mov.w 0x0607AA66,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607AA5E rts ; mov.l @r15+,r8
}

void f_0607AA80(SH2Context& c) {
    ran[1695] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607AA80 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607AA82 mov r15,r14
    c.r[2] = ld32(0x0607AAA8u);  // 0607AA84 mov.l 0x0607AAA8,r2
    c.r[3] = ld32(0x0607AAACu);  // 0607AA86 mov.l 0x0607AAAC,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607AA88 mov.w @r2,r1
    c.r[1] += 1;  // 0607AA8A add #1,r1
    st16(c.r[2], c.r[1]);  // 0607AA8C mov.w r1,@r2
    c.r[0] = c.r[1] & 0xFFFFu;  // 0607AA8E extu.w r1,r0
    c.r[0] <<= 2;  // 0607AA90 shll2 r0
    c.r[0] += c.r[0];  // 0607AA92 add r0,r0
    c.r[2] = c.r[0];  // 0607AA94 mov r0,r2
    c.r[2] += c.r[3];  // 0607AA96 add r3,r2
    c.r[1] = c.r[2];  // 0607AA98 mov r2,r1
    c.r[1] += 4;  // 0607AA9A add #4,r1
    st16(c.r[1], c.r[4]);  // 0607AA9C mov.w r4,@r1
    c.r[2] += 6;  // 0607AA9E add #6,r2
    st16(c.r[2], c.r[5]);  // 0607AAA0 mov.w r5,@r2
    st32(c.r[0] + c.r[3], c.r[6]);  // 0607AAA2 mov.l r6,@(r0,r3)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607AAA4 rts ; mov.l @r15+,r14
}

void f_0607AAB0(SH2Context& c) {
    ran[1696] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607AAB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607AAB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607AAB4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607AAB6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607AAB8 sts.l pr,@-r15
    c.r[15] -= 80;  // 0607AABA add #-80,r15
    c.r[14] = c.r[15];  // 0607AABC mov r15,r14
    c.r[1] = ld32(0x0607ABC4u);  // 0607AABE mov.l 0x0607ABC4,r1
    st32(c.r[14], c.r[1]);  // 0607AAC0 mov.l r1,@r14
    c.r[1] = ld32(0x0607ABC8u);  // 0607AAC2 mov.l 0x0607ABC8,r1
    st32(c.r[14] + 4, c.r[1]);  // 0607AAC4 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0607ABCCu);  // 0607AAC6 mov.l 0x0607ABCC,r1
    st32(c.r[14] + 8, c.r[1]);  // 0607AAC8 mov.l r1,@(8,r14)
    c.r[1] = ld32(0x0607ABD0u);  // 0607AACA mov.l 0x0607ABD0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0607AACC mov.l r1,@(12,r14)
    c.r[1] = ld32(0x0607ABD4u);  // 0607AACE mov.l 0x0607ABD4,r1
    st32(c.r[14] + 16, c.r[1]);  // 0607AAD0 mov.l r1,@(16,r14)
    st32(c.r[14] + 20, c.r[1]);  // 0607AAD2 mov.l r1,@(20,r14)
    st32(c.r[14] + 24, c.r[1]);  // 0607AAD4 mov.l r1,@(24,r14)
    st32(c.r[14] + 28, c.r[1]);  // 0607AAD6 mov.l r1,@(28,r14)
    c.r[1] = c.r[14];  // 0607AAD8 mov r14,r1
    c.r[1] += 32;  // 0607AADA add #32,r1
    c.r[9] = 0x0u;  // 0607AADC mov #0,r9
    st16(c.r[1], c.r[9]);  // 0607AADE mov.w r9,@r1
    c.r[3] = c.r[14];  // 0607AAE0 mov r14,r3
    c.r[3] += 34;  // 0607AAE2 add #34,r3
    st16(c.r[3], c.r[9]);  // 0607AAE4 mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AAE6 mov r14,r3
    c.r[3] += 36;  // 0607AAE8 add #36,r3
    st16(c.r[3], c.r[9]);  // 0607AAEA mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AAEC mov r14,r3
    c.r[3] += 38;  // 0607AAEE add #38,r3
    st16(c.r[3], c.r[9]);  // 0607AAF0 mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AAF2 mov r14,r3
    c.r[3] += 40;  // 0607AAF4 add #40,r3
    st16(c.r[3], c.r[9]);  // 0607AAF6 mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AAF8 mov r14,r3
    c.r[3] += 42;  // 0607AAFA add #42,r3
    st16(c.r[3], c.r[9]);  // 0607AAFC mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AAFE mov r14,r3
    c.r[3] += 44;  // 0607AB00 add #44,r3
    st16(c.r[3], c.r[9]);  // 0607AB02 mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AB04 mov r14,r3
    c.r[3] += 46;  // 0607AB06 add #46,r3
    st16(c.r[3], c.r[9]);  // 0607AB08 mov.w r9,@r3
    c.r[3] = c.r[14];  // 0607AB0A mov r14,r3
    c.r[3] += 48;  // 0607AB0C add #48,r3
    c.r[2] = c.r[14];  // 0607AB0E mov r14,r2
    c.r[2] += 34;  // 0607AB10 add #34,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607ABC0u);  // 0607AB12 mov.w 0x0607ABC0,r1
    st16(c.r[2], c.r[1]);  // 0607AB14 mov.w r1,@r2
    c.r[1] = ld32(0x0607ABD8u);  // 0607AB16 mov.l 0x0607ABD8,r1
    st32(c.r[14] + 48, c.r[1]);  // 0607AB18 mov.l r1,@(48,r14)
    c.r[1] = ld32(0x0607ABDCu);  // 0607AB1A mov.l 0x0607ABDC,r1
    st32(c.r[3] + 4, c.r[1]);  // 0607AB1C mov.l r1,@(4,r3)
    c.r[1] = ld32(0x0607ABE0u);  // 0607AB1E mov.l 0x0607ABE0,r1
    st32(c.r[3] + 8, c.r[1]);  // 0607AB20 mov.l r1,@(8,r3)
    c.r[1] = ld32(0x0607ABE4u);  // 0607AB22 mov.l 0x0607ABE4,r1
    st32(c.r[3] + 12, c.r[1]);  // 0607AB24 mov.l r1,@(12,r3)
    st32(c.r[3] + 16, c.r[1]);  // 0607AB26 mov.l r1,@(16,r3)
    st32(c.r[3] + 20, c.r[1]);  // 0607AB28 mov.l r1,@(20,r3)
    st32(c.r[3] + 24, c.r[1]);  // 0607AB2A mov.l r1,@(24,r3)
    st32(c.r[3] + 28, c.r[1]);  // 0607AB2C mov.l r1,@(28,r3)
    c.r[8] = ld32(0x0607ABE8u);  // 0607AB2E mov.l 0x0607ABE8,r8
    c.r[1] = 0x0u;  // 0607AB30 mov #0,r1
    st32(c.r[8] + 20, c.r[1]);  // 0607AB32 mov.l r1,@(20,r8)
    st32(c.r[8] + 16, c.r[1]);  // 0607AB34 mov.l r1,@(16,r8)
    st32(c.r[8] + 12, c.r[1]);  // 0607AB36 mov.l r1,@(12,r8)
    c.r[3] = c.r[8];  // 0607AB38 mov r8,r3
    c.r[10] = ld32(0x0607ABECu);  // 0607AB3A mov.l 0x0607ABEC,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0607AB3C mov.b @r10,r2
    c.r[3] += 72;  // 0607AB3E add #72,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0607AB40 extu.b r2,r2
    c.r[1] = c.r[2];  // 0607AB42 mov r2,r1
    c.r[1] <<= 2;  // 0607AB44 shll2 r1
    c.r[1] += c.r[14];  // 0607AB46 add r14,r1
    c.r[2] += c.r[2];  // 0607AB48 add r2,r2
    c.r[2] += c.r[14];  // 0607AB4A add r14,r2
    c.r[1] = ld32(c.r[1] + 48);  // 0607AB4C mov.l @(48,r1),r1
    c.r[2] += 32;  // 0607AB4E add #32,r2
    st32(c.r[3], c.r[1]);  // 0607AB50 mov.l r1,@r3
    c.r[3] = c.r[8];  // 0607AB52 mov r8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607AB54 mov.w @r2,r1
    c.r[3] += 76;  // 0607AB56 add #76,r3
    st16(c.r[3], c.r[1]);  // 0607AB58 mov.w r1,@r3
    c.r[2] = c.r[8];  // 0607AB5A mov r8,r2
    c.r[2] += 78;  // 0607AB5C add #78,r2
    c.r[1] = c.r[8];  // 0607AB5E mov r8,r1
    c.r[1] += 80;  // 0607AB60 add #80,r1
    st16(c.r[1], c.r[9]);  // 0607AB62 mov.w r9,@r1
    c.r[1] = ld32(0x0607ABF0u);  // 0607AB64 mov.l 0x0607ABF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607AB6Au; st16(c.r[2], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AB6Au) return; }  // 0607AB66 jsr @r1 ; mov.w r9,@r2
    c.r[2] = c.r[8];  // 0607AB6A mov r8,r2
    c.r[2] += 82;  // 0607AB6C add #82,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607ABC2u);  // 0607AB6E mov.w 0x0607ABC2,r1
    st16(c.r[2], c.r[1]);  // 0607AB70 mov.w r1,@r2
    c.r[2] = c.r[8];  // 0607AB72 mov r8,r2
    c.r[2] += 84;  // 0607AB74 add #84,r2
    c.r[1] = c.r[8];  // 0607AB76 mov r8,r1
    c.r[1] += 86;  // 0607AB78 add #86,r1
    st16(c.r[1], c.r[9]);  // 0607AB7A mov.w r9,@r1
    st16(c.r[2], c.r[9]);  // 0607AB7C mov.w r9,@r2
    c.r[7] = c.r[8];  // 0607AB7E mov r8,r7
    c.r[7] += 88;  // 0607AB80 add #88,r7
    c.r[3] = c.r[8];  // 0607AB82 mov r8,r3
    c.r[3] += 92;  // 0607AB84 add #92,r3
    c.r[2] = c.r[8];  // 0607AB86 mov r8,r2
    c.r[2] += 96;  // 0607AB88 add #96,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0607AB8A mov.b @r10,r1
    c.r[4] = c.r[8];  // 0607AB8C mov r8,r4
    c.r[0] = c.r[1] & 0xFFu;  // 0607AB8E extu.b r1,r0
    c.r[0] <<= 2;  // 0607AB90 shll2 r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0607AB92 mov.l @(r0,r14),r1
    st32(c.r[2], c.r[1]);  // 0607AB94 mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 0607AB96 mov.l r1,@r3
    st32(c.r[7], c.r[1]);  // 0607AB98 mov.l r1,@r7
    c.r[1] = ld32(0x0607ABF4u);  // 0607AB9A mov.l 0x0607ABF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607ABA0u; c.r[4] += 24; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ABA0u) return; }  // 0607AB9C jsr @r1 ; add #24,r4
    c.r[2] = c.r[8];  // 0607ABA0 mov r8,r2
    c.r[2] += 104;  // 0607ABA2 add #104,r2
    c.r[1] = c.r[8];  // 0607ABA4 mov r8,r1
    c.r[1] += 106;  // 0607ABA6 add #106,r1
    c.r[8] += 108;  // 0607ABA8 add #108,r8
    st16(c.r[8], c.r[9]);  // 0607ABAA mov.w r9,@r8
    st16(c.r[1], c.r[9]);  // 0607ABAC mov.w r9,@r1
    st16(c.r[2], c.r[9]);  // 0607ABAE mov.w r9,@r2
    c.r[14] += 80;  // 0607ABB0 add #80,r14
    c.r[15] = c.r[14];  // 0607ABB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607ABB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607ABB6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607ABB8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607ABBA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607ABBC rts ; mov.l @r15+,r8
}

void f_0607ABF8(SH2Context& c) {
    ran[1697] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607ABF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607ABFA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607ABFC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607ABFE mov r15,r14
    c.r[1] = ld32(0x0607AC3Cu);  // 0607AC00 mov.l 0x0607AC3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607AC06u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AC06u) return; }  // 0607AC02 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0607AC40u);  // 0607AC06 mov.l 0x0607AC40,r8
    c.r[1] = c.r[8];  // 0607AC08 mov r8,r1
    c.r[1] += 78;  // 0607AC0A add #78,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AC0C mov.w @r1,r4
    c.r[1] = ld32(0x0607AC44u);  // 0607AC0E mov.l 0x0607AC44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607AC14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AC14u) return; }  // 0607AC10 jsr @r1 ; nop
    c.r[1] = c.r[8];  // 0607AC14 mov r8,r1
    c.r[1] += 76;  // 0607AC16 add #76,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AC18 mov.w @r1,r4
    c.r[1] = ld32(0x0607AC48u);  // 0607AC1A mov.l 0x0607AC48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607AC20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AC20u) return; }  // 0607AC1C jsr @r1 ; nop
    c.r[1] = c.r[8];  // 0607AC20 mov r8,r1
    c.r[1] += 72;  // 0607AC22 add #72,r1
    c.r[0] = ld32(0x0607AC4Cu);  // 0607AC24 mov.l 0x0607AC4C,r0
    c.r[7] = c.r[8];  // 0607AC26 mov r8,r7
    c.r[5] = 0x0u;  // 0607AC28 mov #0,r5
    c.r[6] = ld32(c.r[1]);  // 0607AC2A mov.l @r1,r6
    c.r[4] = 0x0u;  // 0607AC2C mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607AC32u; c.r[6] = 0u - c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AC32u) return; }  // 0607AC2E jsr @r0 ; neg r6,r6
    c.r[15] = c.r[14];  // 0607AC32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607AC34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607AC36 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607AC38 rts ; mov.l @r15+,r8
}

void f_0607AC50(SH2Context& c) {
    ran[1698] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607AC50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607AC52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607AC54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607AC56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607AC58 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607AC5A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607AC5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607AC5E sts.l pr,@-r15
    c.r[15] -= 4;  // 0607AC60 add #-4,r15
    c.r[14] = c.r[15];  // 0607AC62 mov r15,r14
    c.r[12] = ld32(0x0607AE50u);  // 0607AC64 mov.l 0x0607AE50,r12
    c.r[0] = ld32(0x0607AE54u);  // 0607AC66 mov.l 0x0607AE54,r0
    st32(c.r[14], c.r[0]);  // 0607AC68 mov.l r0,@r14
    c.r[1] = ld32(0x0607AE58u);  // 0607AC6A mov.l 0x0607AE58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607AC6C mov.b @r1,r1
    c.r[13] = ld32(0x0607AE5Cu);  // 0607AC6E mov.l 0x0607AE5C,r13
    c.r[2] = c.r[1] & 0xFFu;  // 0607AC70 extu.b r1,r2
    c.r[1] = 0x7u;  // 0607AC72 mov #7,r1
    c.t = c.r[2] > c.r[1];  // 0607AC74 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0607AC7E; } }  // 0607AC76 bf/s 0x0607AC7E ; mov r2,r1
    goto L_0607B14E;  // 0607AC7A bra 0x0607B14E ; nop
L_0607AC7E:
    c.r[1] += c.r[1];  // 0607AC7E add r1,r1
    c.r[0] = 0x0607AC8Cu;  // 0607AC80 mova 0x0607AC8C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0607AC82 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0607AC84 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0607AC9Cu: goto L_0607AC9C; case 0x0607AD58u: goto L_0607AD58; case 0x0607ADA6u: goto L_0607ADA6; case 0x0607ADF4u: goto L_0607ADF4; case 0x0607AE98u: goto L_0607AE98; case 0x0607AF54u: goto L_0607AF54; case 0x0607B010u: goto L_0607B010; case 0x0607B090u: goto L_0607B090; default: sh2_call(c, x); return; } }  // 0607AC86 jmp @r0 ; nop
L_0607AC9C:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607AC9C mov.l r12,@-r15
    c.r[6] = 0x0u;  // 0607AC9E mov #0,r6
    c.r[5] = 0x0u;  // 0607ACA0 mov #0,r5
    c.r[4] = 0x10u;  // 0607ACA2 mov #16,r4
    c.r[0] = ld32(0x0607AE60u);  // 0607ACA4 mov.l 0x0607AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607ACAAu; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ACAAu) return; }  // 0607ACA6 jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607AE64u);  // 0607ACAA mov.l 0x0607AE64,r2
    c.r[1] = ld32(0x0607AE68u);  // 0607ACAC mov.l 0x0607AE68,r1
    c.r[10] = c.r[1];  // 0607ACAE mov r1,r10
    c.r[10] += 100;  // 0607ACB0 add #100,r10
    c.r[0] = c.r[12];  // 0607ACB2 mov r12,r0
    c.r[8] = ld32(0x0607AE6Cu);  // 0607ACB4 mov.l 0x0607AE6C,r8
    c.r[1] += 102;  // 0607ACB6 add #102,r1
    c.r[5] = ld32(0x0607AE70u);  // 0607ACB8 mov.l 0x0607AE70,r5
    c.r[5] += c.r[12];  // 0607ACBA add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607ACBC mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607AE74u);  // 0607ACBE mov.l 0x0607AE74,r9
    st32(c.r[10], c.r[6]);  // 0607ACC0 mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607ACC2 mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607ACC4 mov.w @r1,r1
    c.r[2] += 88;  // 0607ACC6 add #88,r2
    st16(c.r[2], c.r[1]);  // 0607ACC8 mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607ACCA mov.l @r8,r4
    c.r[6] <<= 2;  // 0607ACCC shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607ACD2u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ACD2u) return; }  // 0607ACCE jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607AE78u);  // 0607ACD2 mov.l 0x0607AE78,r1
    c.r[12] += c.r[1];  // 0607ACD4 add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607ACD6 mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607ACD8 mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607ACDA mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607ACDC shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607ACE2u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ACE2u) return; }  // 0607ACDE jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607ACE2 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607ACE4 mov.l r1,@-r15
    c.r[6] = 0x1u;  // 0607ACE6 mov #1,r6
    c.r[5] = 0xFFFFFFFFu;  // 0607ACE8 mov #-1,r5
    c.r[4] = 0x10u;  // 0607ACEA mov #16,r4
    c.r[0] = ld32(0x0607AE60u);  // 0607ACEC mov.l 0x0607AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607ACF2u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ACF2u) return; }  // 0607ACEE jsr @r0 ; mov.l @r14,r7
    c.r[1] = c.r[0];  // 0607ACF2 mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607ACF4 mov.l @r14,r0
    c.r[6] = c.r[1];  // 0607ACF6 mov r1,r6
    c.r[0] |= 0x8Cu;  // 0607ACF8 or #140,r0
    st32(c.r[14], c.r[0]);  // 0607ACFA mov.l r0,@r14
    c.r[5] = ld32(c.r[14]);  // 0607ACFC mov.l @r14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607AD02u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AD02u) return; }  // 0607ACFE jsr @r9 ; mov r13,r4
    c.r[7] = ld32(0x0607AE7Cu);  // 0607AD02 mov.l 0x0607AE7C,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607AE42u);  // 0607AD04 mov.w 0x0607AE42,r2
    c.r[1] = c.r[13];  // 0607AD06 mov r13,r1
    c.r[1] += c.r[2];  // 0607AD08 add r2,r1
    c.r[0] = c.r[13];  // 0607AD0A mov r13,r0
    c.r[1] += 2;  // 0607AD0C add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0607AD0E mov.w @(r0,r2),r2
    st16(c.r[7], c.r[2]);  // 0607AD10 mov.w r2,@r7
    c.r[2] = c.r[7];  // 0607AD12 mov r7,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD14 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD16 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD18 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD1A mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD1C add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD1E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD20 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD22 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD24 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD26 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD28 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD2A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD2C mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD2E add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD30 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD32 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD34 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD36 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD38 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD3A add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD3C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AD3E mov.w @r1+,r3
    c.r[2] += 2;  // 0607AD40 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AD42 mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AD44 mov.w @r1,r1
    c.r[2] += 2;  // 0607AD46 add #2,r2
    st16(c.r[2], c.r[1]);  // 0607AD48 mov.w r1,@r2
    st32(c.r[7], c.r[13]);  // 0607AD4A mov.l r13,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607AE44u);  // 0607AD4C mov.w 0x0607AE44,r1
    c.r[1] += c.r[13];  // 0607AD4E add r13,r1
    st32(c.r[7] + 8, c.r[1]);  // 0607AD50 mov.l r1,@(8,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607AE46u);  // 0607AD52 mov.w 0x0607AE46,r1
    c.r[15] += 8; goto L_0607B14A;  // 0607AD54 bra 0x0607B14A ; add #8,r15
L_0607AD58:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607AD58 mov.l r12,@-r15
    c.r[6] = 0x2u;  // 0607AD5A mov #2,r6
    c.r[5] = 0x0u;  // 0607AD5C mov #0,r5
    c.r[4] = 0x10u;  // 0607AD5E mov #16,r4
    c.r[0] = ld32(0x0607AE60u);  // 0607AD60 mov.l 0x0607AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607AD66u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AD66u) return; }  // 0607AD62 jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607AE80u);  // 0607AD66 mov.l 0x0607AE80,r2
    c.r[1] = ld32(0x0607AE68u);  // 0607AD68 mov.l 0x0607AE68,r1
    c.r[10] = c.r[1];  // 0607AD6A mov r1,r10
    c.r[10] += 100;  // 0607AD6C add #100,r10
    c.r[0] = c.r[12];  // 0607AD6E mov r12,r0
    c.r[8] = ld32(0x0607AE6Cu);  // 0607AD70 mov.l 0x0607AE6C,r8
    c.r[1] += 102;  // 0607AD72 add #102,r1
    c.r[5] = ld32(0x0607AE84u);  // 0607AD74 mov.l 0x0607AE84,r5
    c.r[5] += c.r[12];  // 0607AD76 add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607AD78 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607AE74u);  // 0607AD7A mov.l 0x0607AE74,r9
    st32(c.r[10], c.r[6]);  // 0607AD7C mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607AD7E mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AD80 mov.w @r1,r1
    c.r[2] += 88;  // 0607AD82 add #88,r2
    st16(c.r[2], c.r[1]);  // 0607AD84 mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607AD86 mov.l @r8,r4
    c.r[6] <<= 2;  // 0607AD88 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AD8Eu; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AD8Eu) return; }  // 0607AD8A jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607AE88u);  // 0607AD8E mov.l 0x0607AE88,r1
    c.r[12] += c.r[1];  // 0607AD90 add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607AD92 mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607AD94 mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607AD96 mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607AD98 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AD9Eu; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AD9Eu) return; }  // 0607AD9A jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607AD9E mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607ADA0 mov.l r1,@-r15
    c.r[6] = 0x3u; goto L_0607B0DC;  // 0607ADA2 bra 0x0607B0DC ; mov #3,r6
L_0607ADA6:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607ADA6 mov.l r12,@-r15
    c.r[6] = 0x4u;  // 0607ADA8 mov #4,r6
    c.r[5] = 0x0u;  // 0607ADAA mov #0,r5
    c.r[4] = 0x10u;  // 0607ADAC mov #16,r4
    c.r[0] = ld32(0x0607AE60u);  // 0607ADAE mov.l 0x0607AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607ADB4u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ADB4u) return; }  // 0607ADB0 jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607AE8Cu);  // 0607ADB4 mov.l 0x0607AE8C,r2
    c.r[1] = ld32(0x0607AE68u);  // 0607ADB6 mov.l 0x0607AE68,r1
    c.r[10] = c.r[1];  // 0607ADB8 mov r1,r10
    c.r[10] += 100;  // 0607ADBA add #100,r10
    c.r[0] = c.r[12];  // 0607ADBC mov r12,r0
    c.r[8] = ld32(0x0607AE6Cu);  // 0607ADBE mov.l 0x0607AE6C,r8
    c.r[1] += 102;  // 0607ADC0 add #102,r1
    c.r[5] = ld32(0x0607AE90u);  // 0607ADC2 mov.l 0x0607AE90,r5
    c.r[5] += c.r[12];  // 0607ADC4 add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607ADC6 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607AE74u);  // 0607ADC8 mov.l 0x0607AE74,r9
    st32(c.r[10], c.r[6]);  // 0607ADCA mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607ADCC mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607ADCE mov.w @r1,r1
    c.r[2] += 88;  // 0607ADD0 add #88,r2
    st16(c.r[2], c.r[1]);  // 0607ADD2 mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607ADD4 mov.l @r8,r4
    c.r[6] <<= 2;  // 0607ADD6 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607ADDCu; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ADDCu) return; }  // 0607ADD8 jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607AE94u);  // 0607ADDC mov.l 0x0607AE94,r1
    c.r[12] += c.r[1];  // 0607ADDE add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607ADE0 mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607ADE2 mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607ADE4 mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607ADE6 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607ADECu; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ADECu) return; }  // 0607ADE8 jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607ADEC mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607ADEE mov.l r1,@-r15
    c.r[6] = 0x5u; goto L_0607B0DC;  // 0607ADF0 bra 0x0607B0DC ; mov #5,r6
L_0607ADF4:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607ADF4 mov.l r12,@-r15
    c.r[6] = 0x6u;  // 0607ADF6 mov #6,r6
    c.r[5] = 0x0u;  // 0607ADF8 mov #0,r5
    c.r[4] = 0x10u;  // 0607ADFA mov #16,r4
    c.r[0] = ld32(0x0607AE60u);  // 0607ADFC mov.l 0x0607AE60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607AE02u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AE02u) return; }  // 0607ADFE jsr @r0 ; mov.l @r14,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607AE48u);  // 0607AE02 mov.w 0x0607AE48,r2
    c.r[1] = ld32(0x0607AE68u);  // 0607AE04 mov.l 0x0607AE68,r1
    c.r[10] = c.r[1];  // 0607AE06 mov r1,r10
    c.r[10] += 100;  // 0607AE08 add #100,r10
    c.r[0] = c.r[12];  // 0607AE0A mov r12,r0
    c.r[8] = ld32(0x0607AE6Cu);  // 0607AE0C mov.l 0x0607AE6C,r8
    c.r[1] += 102;  // 0607AE0E add #102,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0607AE4Au);  // 0607AE10 mov.w 0x0607AE4A,r5
    c.r[5] += c.r[12];  // 0607AE12 add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607AE14 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607AE74u);  // 0607AE16 mov.l 0x0607AE74,r9
    st32(c.r[10], c.r[6]);  // 0607AE18 mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607AE1A mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AE1C mov.w @r1,r1
    c.r[2] += 88;  // 0607AE1E add #88,r2
    st16(c.r[2], c.r[1]);  // 0607AE20 mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607AE22 mov.l @r8,r4
    c.r[6] <<= 2;  // 0607AE24 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AE2Au; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AE2Au) return; }  // 0607AE26 jsr @r9 ; add r6,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607AE4Cu);  // 0607AE2A mov.w 0x0607AE4C,r1
    c.r[12] += c.r[1];  // 0607AE2C add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607AE2E mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607AE30 mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607AE32 mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607AE34 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AE3Au; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AE3Au) return; }  // 0607AE36 jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607AE3A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607AE3C mov.l r1,@-r15
    c.r[6] = 0x7u; goto L_0607B0DC;  // 0607AE3E bra 0x0607B0DC ; mov #7,r6
L_0607AE98:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607AE98 mov.l r12,@-r15
    c.r[6] = 0xDu;  // 0607AE9A mov #13,r6
    c.r[5] = 0x0u;  // 0607AE9C mov #0,r5
    c.r[4] = 0x10u;  // 0607AE9E mov #16,r4
    c.r[0] = ld32(0x0607B064u);  // 0607AEA0 mov.l 0x0607B064,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607AEA6u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AEA6u) return; }  // 0607AEA2 jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607B068u);  // 0607AEA6 mov.l 0x0607B068,r2
    c.r[1] = ld32(0x0607B06Cu);  // 0607AEA8 mov.l 0x0607B06C,r1
    c.r[10] = c.r[1];  // 0607AEAA mov r1,r10
    c.r[10] += 100;  // 0607AEAC add #100,r10
    c.r[0] = c.r[12];  // 0607AEAE mov r12,r0
    c.r[8] = ld32(0x0607B070u);  // 0607AEB0 mov.l 0x0607B070,r8
    c.r[1] += 102;  // 0607AEB2 add #102,r1
    c.r[5] = ld32(0x0607B074u);  // 0607AEB4 mov.l 0x0607B074,r5
    c.r[5] += c.r[12];  // 0607AEB6 add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607AEB8 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607B078u);  // 0607AEBA mov.l 0x0607B078,r9
    st32(c.r[10], c.r[6]);  // 0607AEBC mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607AEBE mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AEC0 mov.w @r1,r1
    c.r[2] += 88;  // 0607AEC2 add #88,r2
    st16(c.r[2], c.r[1]);  // 0607AEC4 mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607AEC6 mov.l @r8,r4
    c.r[6] <<= 2;  // 0607AEC8 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AECEu; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AECEu) return; }  // 0607AECA jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607B07Cu);  // 0607AECE mov.l 0x0607B07C,r1
    c.r[12] += c.r[1];  // 0607AED0 add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607AED2 mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607AED4 mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607AED6 mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607AED8 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AEDEu; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AEDEu) return; }  // 0607AEDA jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607AEDE mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607AEE0 mov.l r1,@-r15
    c.r[6] = 0xEu;  // 0607AEE2 mov #14,r6
    c.r[5] = 0xFFFFFFFFu;  // 0607AEE4 mov #-1,r5
    c.r[4] = 0x10u;  // 0607AEE6 mov #16,r4
    c.r[0] = ld32(0x0607B064u);  // 0607AEE8 mov.l 0x0607B064,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607AEEEu; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AEEEu) return; }  // 0607AEEA jsr @r0 ; mov.l @r14,r7
    c.r[1] = c.r[0];  // 0607AEEE mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607AEF0 mov.l @r14,r0
    c.r[6] = c.r[1];  // 0607AEF2 mov r1,r6
    c.r[0] |= 0x8Cu;  // 0607AEF4 or #140,r0
    st32(c.r[14], c.r[0]);  // 0607AEF6 mov.l r0,@r14
    c.r[5] = ld32(c.r[14]);  // 0607AEF8 mov.l @r14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607AEFEu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AEFEu) return; }  // 0607AEFA jsr @r9 ; mov r13,r4
    c.r[7] = ld32(0x0607B080u);  // 0607AEFE mov.l 0x0607B080,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607B05Eu);  // 0607AF00 mov.w 0x0607B05E,r2
    c.r[1] = c.r[13];  // 0607AF02 mov r13,r1
    c.r[1] += c.r[2];  // 0607AF04 add r2,r1
    c.r[0] = c.r[13];  // 0607AF06 mov r13,r0
    c.r[1] += 2;  // 0607AF08 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0607AF0A mov.w @(r0,r2),r2
    st16(c.r[7], c.r[2]);  // 0607AF0C mov.w r2,@r7
    c.r[2] = c.r[7];  // 0607AF0E mov r7,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF10 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF12 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF14 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF16 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF18 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF1A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF1C mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF1E add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF20 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF22 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF24 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF26 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF28 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF2A add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF2C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF2E mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF30 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF32 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF34 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF36 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF38 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AF3A mov.w @r1+,r3
    c.r[2] += 2;  // 0607AF3C add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AF3E mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AF40 mov.w @r1,r1
    c.r[2] += 2;  // 0607AF42 add #2,r2
    st16(c.r[2], c.r[1]);  // 0607AF44 mov.w r1,@r2
    st32(c.r[7], c.r[13]);  // 0607AF46 mov.l r13,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607B060u);  // 0607AF48 mov.w 0x0607B060,r1
    c.r[1] += c.r[13];  // 0607AF4A add r13,r1
    st32(c.r[7] + 8, c.r[1]);  // 0607AF4C mov.l r1,@(8,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607B062u);  // 0607AF4E mov.w 0x0607B062,r1
    c.r[15] += 8; goto L_0607B14A;  // 0607AF50 bra 0x0607B14A ; add #8,r15
L_0607AF54:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607AF54 mov.l r12,@-r15
    c.r[6] = 0xFu;  // 0607AF56 mov #15,r6
    c.r[5] = 0x0u;  // 0607AF58 mov #0,r5
    c.r[4] = 0x10u;  // 0607AF5A mov #16,r4
    c.r[0] = ld32(0x0607B064u);  // 0607AF5C mov.l 0x0607B064,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607AF62u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AF62u) return; }  // 0607AF5E jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607B068u);  // 0607AF62 mov.l 0x0607B068,r2
    c.r[1] = ld32(0x0607B06Cu);  // 0607AF64 mov.l 0x0607B06C,r1
    c.r[10] = c.r[1];  // 0607AF66 mov r1,r10
    c.r[10] += 100;  // 0607AF68 add #100,r10
    c.r[0] = c.r[12];  // 0607AF6A mov r12,r0
    c.r[8] = ld32(0x0607B070u);  // 0607AF6C mov.l 0x0607B070,r8
    c.r[1] += 102;  // 0607AF6E add #102,r1
    c.r[5] = ld32(0x0607B074u);  // 0607AF70 mov.l 0x0607B074,r5
    c.r[5] += c.r[12];  // 0607AF72 add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607AF74 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607B078u);  // 0607AF76 mov.l 0x0607B078,r9
    st32(c.r[10], c.r[6]);  // 0607AF78 mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607AF7A mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AF7C mov.w @r1,r1
    c.r[2] += 88;  // 0607AF7E add #88,r2
    st16(c.r[2], c.r[1]);  // 0607AF80 mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607AF82 mov.l @r8,r4
    c.r[6] <<= 2;  // 0607AF84 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AF8Au; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AF8Au) return; }  // 0607AF86 jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607B07Cu);  // 0607AF8A mov.l 0x0607B07C,r1
    c.r[12] += c.r[1];  // 0607AF8C add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607AF8E mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607AF90 mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607AF92 mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607AF94 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607AF9Au; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AF9Au) return; }  // 0607AF96 jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607AF9A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607AF9C mov.l r1,@-r15
    c.r[6] = 0x10u;  // 0607AF9E mov #16,r6
    c.r[5] = 0xFFFFFFFFu;  // 0607AFA0 mov #-1,r5
    c.r[4] = 0x10u;  // 0607AFA2 mov #16,r4
    c.r[0] = ld32(0x0607B064u);  // 0607AFA4 mov.l 0x0607B064,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607AFAAu; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AFAAu) return; }  // 0607AFA6 jsr @r0 ; mov.l @r14,r7
    c.r[1] = c.r[0];  // 0607AFAA mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607AFAC mov.l @r14,r0
    c.r[6] = c.r[1];  // 0607AFAE mov r1,r6
    c.r[0] |= 0x8Cu;  // 0607AFB0 or #140,r0
    st32(c.r[14], c.r[0]);  // 0607AFB2 mov.l r0,@r14
    c.r[5] = ld32(c.r[14]);  // 0607AFB4 mov.l @r14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607AFBAu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607AFBAu) return; }  // 0607AFB6 jsr @r9 ; mov r13,r4
    c.r[7] = ld32(0x0607B080u);  // 0607AFBA mov.l 0x0607B080,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607B05Eu);  // 0607AFBC mov.w 0x0607B05E,r2
    c.r[1] = c.r[13];  // 0607AFBE mov r13,r1
    c.r[1] += c.r[2];  // 0607AFC0 add r2,r1
    c.r[0] = c.r[13];  // 0607AFC2 mov r13,r0
    c.r[1] += 2;  // 0607AFC4 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0607AFC6 mov.w @(r0,r2),r2
    st16(c.r[7], c.r[2]);  // 0607AFC8 mov.w r2,@r7
    c.r[2] = c.r[7];  // 0607AFCA mov r7,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFCC mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFCE add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFD0 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFD2 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFD4 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFD6 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFD8 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFDA add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFDC mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFDE mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFE0 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFE2 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFE4 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFE6 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFE8 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFEA mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFEC add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFEE mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFF0 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFF2 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFF4 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607AFF6 mov.w @r1+,r3
    c.r[2] += 2;  // 0607AFF8 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607AFFA mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607AFFC mov.w @r1,r1
    c.r[2] += 2;  // 0607AFFE add #2,r2
    st16(c.r[2], c.r[1]);  // 0607B000 mov.w r1,@r2
    st32(c.r[7], c.r[13]);  // 0607B002 mov.l r13,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607B060u);  // 0607B004 mov.w 0x0607B060,r1
    c.r[1] += c.r[13];  // 0607B006 add r13,r1
    st32(c.r[7] + 8, c.r[1]);  // 0607B008 mov.l r1,@(8,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607B062u);  // 0607B00A mov.w 0x0607B062,r1
    c.r[15] += 8; goto L_0607B14A;  // 0607B00C bra 0x0607B14A ; add #8,r15
L_0607B010:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607B010 mov.l r12,@-r15
    c.r[6] = 0x13u;  // 0607B012 mov #19,r6
    c.r[5] = 0x0u;  // 0607B014 mov #0,r5
    c.r[4] = 0x10u;  // 0607B016 mov #16,r4
    c.r[0] = ld32(0x0607B064u);  // 0607B018 mov.l 0x0607B064,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607B01Eu; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B01Eu) return; }  // 0607B01A jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607B084u);  // 0607B01E mov.l 0x0607B084,r2
    c.r[1] = ld32(0x0607B06Cu);  // 0607B020 mov.l 0x0607B06C,r1
    c.r[10] = c.r[1];  // 0607B022 mov r1,r10
    c.r[10] += 100;  // 0607B024 add #100,r10
    c.r[0] = c.r[12];  // 0607B026 mov r12,r0
    c.r[8] = ld32(0x0607B070u);  // 0607B028 mov.l 0x0607B070,r8
    c.r[1] += 102;  // 0607B02A add #102,r1
    c.r[5] = ld32(0x0607B088u);  // 0607B02C mov.l 0x0607B088,r5
    c.r[5] += c.r[12];  // 0607B02E add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607B030 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607B078u);  // 0607B032 mov.l 0x0607B078,r9
    st32(c.r[10], c.r[6]);  // 0607B034 mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607B036 mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B038 mov.w @r1,r1
    c.r[2] += 88;  // 0607B03A add #88,r2
    st16(c.r[2], c.r[1]);  // 0607B03C mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607B03E mov.l @r8,r4
    c.r[6] <<= 2;  // 0607B040 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607B046u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B046u) return; }  // 0607B042 jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607B08Cu);  // 0607B046 mov.l 0x0607B08C,r1
    c.r[12] += c.r[1];  // 0607B048 add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607B04A mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607B04C mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607B04E mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607B050 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607B056u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B056u) return; }  // 0607B052 jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607B056 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607B058 mov.l r1,@-r15
    c.r[6] = 0x14u; goto L_0607B0DC;  // 0607B05A bra 0x0607B0DC ; mov #20,r6
L_0607B090:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607B090 mov.l r12,@-r15
    c.r[6] = 0x15u;  // 0607B092 mov #21,r6
    c.r[5] = 0x0u;  // 0607B094 mov #0,r5
    c.r[4] = 0x10u;  // 0607B096 mov #16,r4
    c.r[0] = ld32(0x0607B170u);  // 0607B098 mov.l 0x0607B170,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607B09Eu; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B09Eu) return; }  // 0607B09A jsr @r0 ; mov.l @r14,r7
    c.r[2] = ld32(0x0607B174u);  // 0607B09E mov.l 0x0607B174,r2
    c.r[1] = ld32(0x0607B178u);  // 0607B0A0 mov.l 0x0607B178,r1
    c.r[10] = c.r[1];  // 0607B0A2 mov r1,r10
    c.r[10] += 100;  // 0607B0A4 add #100,r10
    c.r[0] = c.r[12];  // 0607B0A6 mov r12,r0
    c.r[8] = ld32(0x0607B17Cu);  // 0607B0A8 mov.l 0x0607B17C,r8
    c.r[1] += 102;  // 0607B0AA add #102,r1
    c.r[5] = ld32(0x0607B180u);  // 0607B0AC mov.l 0x0607B180,r5
    c.r[5] += c.r[12];  // 0607B0AE add r12,r5
    c.r[6] = ld32(c.r[0] + c.r[2]);  // 0607B0B0 mov.l @(r0,r2),r6
    c.r[9] = ld32(0x0607B184u);  // 0607B0B2 mov.l 0x0607B184,r9
    st32(c.r[10], c.r[6]);  // 0607B0B4 mov.l r6,@r10
    c.r[2] = c.r[8];  // 0607B0B6 mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B0B8 mov.w @r1,r1
    c.r[2] += 88;  // 0607B0BA add #88,r2
    st16(c.r[2], c.r[1]);  // 0607B0BC mov.w r1,@r2
    c.r[4] = ld32(c.r[8]);  // 0607B0BE mov.l @r8,r4
    c.r[6] <<= 2;  // 0607B0C0 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607B0C6u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B0C6u) return; }  // 0607B0C2 jsr @r9 ; add r6,r6
    c.r[1] = ld32(0x0607B188u);  // 0607B0C6 mov.l 0x0607B188,r1
    c.r[12] += c.r[1];  // 0607B0C8 add r1,r12
    c.r[6] = ld32(c.r[10]);  // 0607B0CA mov.l @r10,r6
    c.r[5] = c.r[12];  // 0607B0CC mov r12,r5
    c.r[4] = ld32(c.r[8] + 4);  // 0607B0CE mov.l @(4,r8),r4
    c.r[6] <<= 2;  // 0607B0D0 shll2 r6
    { const uint32_t x = c.r[9]; c.pr = 0x0607B0D6u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B0D6u) return; }  // 0607B0D2 jsr @r9 ; add r6,r6
    c.r[1] = 0x0u;  // 0607B0D6 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607B0D8 mov.l r1,@-r15
    c.r[6] = 0x16u;  // 0607B0DA mov #22,r6
L_0607B0DC:
    c.r[5] = 0xFFFFFFFFu;  // 0607B0DC mov #-1,r5
    c.r[4] = 0x10u;  // 0607B0DE mov #16,r4
    c.r[0] = ld32(0x0607B170u);  // 0607B0E0 mov.l 0x0607B170,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607B0E6u; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B0E6u) return; }  // 0607B0E2 jsr @r0 ; mov.l @r14,r7
    c.r[1] = c.r[0];  // 0607B0E6 mov r0,r1
    c.r[0] = ld32(c.r[14]);  // 0607B0E8 mov.l @r14,r0
    c.r[6] = c.r[1];  // 0607B0EA mov r1,r6
    c.r[0] |= 0x8Cu;  // 0607B0EC or #140,r0
    st32(c.r[14], c.r[0]);  // 0607B0EE mov.l r0,@r14
    c.r[5] = ld32(c.r[14]);  // 0607B0F0 mov.l @r14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0607B0F6u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B0F6u) return; }  // 0607B0F2 jsr @r9 ; mov r13,r4
    c.r[7] = ld32(0x0607B18Cu);  // 0607B0F6 mov.l 0x0607B18C,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0607B16Au);  // 0607B0F8 mov.w 0x0607B16A,r2
    c.r[1] = c.r[13];  // 0607B0FA mov r13,r1
    c.r[1] += c.r[2];  // 0607B0FC add r2,r1
    c.r[0] = c.r[13];  // 0607B0FE mov r13,r0
    c.r[1] += 2;  // 0607B100 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0607B102 mov.w @(r0,r2),r2
    c.r[15] += 8;  // 0607B104 add #8,r15
    st16(c.r[7], c.r[2]);  // 0607B106 mov.w r2,@r7
    c.r[2] = c.r[7];  // 0607B108 mov r7,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B10A mov.w @r1+,r3
    c.r[2] += 2;  // 0607B10C add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B10E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B110 mov.w @r1+,r3
    c.r[2] += 2;  // 0607B112 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B114 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B116 mov.w @r1+,r3
    c.r[2] += 2;  // 0607B118 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B11A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B11C mov.w @r1+,r3
    c.r[2] += 2;  // 0607B11E add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B120 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B122 mov.w @r1+,r3
    c.r[2] += 2;  // 0607B124 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B126 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B128 mov.w @r1+,r3
    c.r[2] += 2;  // 0607B12A add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B12C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B12E mov.w @r1+,r3
    c.r[2] += 2;  // 0607B130 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B132 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0607B134 mov.w @r1+,r3
    c.r[2] += 2;  // 0607B136 add #2,r2
    st16(c.r[2], c.r[3]);  // 0607B138 mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B13A mov.w @r1,r1
    c.r[2] += 2;  // 0607B13C add #2,r2
    st16(c.r[2], c.r[1]);  // 0607B13E mov.w r1,@r2
    st32(c.r[7], c.r[13]);  // 0607B140 mov.l r13,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607B16Cu);  // 0607B142 mov.w 0x0607B16C,r1
    c.r[1] += c.r[13];  // 0607B144 add r13,r1
    st32(c.r[7] + 8, c.r[1]);  // 0607B146 mov.l r1,@(8,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607B16Eu);  // 0607B148 mov.w 0x0607B16E,r1
L_0607B14A:
    c.r[13] += c.r[1];  // 0607B14A add r1,r13
    st32(c.r[7] + 16, c.r[13]);  // 0607B14C mov.l r13,@(16,r7)
L_0607B14E:
    c.r[1] = ld32(0x0607B190u);  // 0607B14E mov.l 0x0607B190,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B154u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B154u) return; }  // 0607B150 jsr @r1 ; nop
    c.r[14] += 4;  // 0607B154 add #4,r14
    c.r[15] = c.r[14];  // 0607B156 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B158 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B15A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607B15C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607B15E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607B160 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607B162 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B164 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B166 rts ; mov.l @r15+,r8
}

void f_0607B194(SH2Context& c) {
    ran[1699] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B194 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607B196 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607B198 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607B19A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607B19C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607B19E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B1A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B1A2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607B232u);  // 0607B1A4 mov.w 0x0607B232,r3
    c.r[15] += c.r[3];  // 0607B1A6 add r3,r15
    c.r[14] = c.r[15];  // 0607B1A8 mov r15,r14
    c.r[10] = 0x0u;  // 0607B1AA mov #0,r10
    c.r[13] = 0x3u;  // 0607B1AC mov #3,r13
    c.r[12] = ld32(0x0607B238u);  // 0607B1AE mov.l 0x0607B238,r12
    c.r[8] = ld32(0x0607B23Cu);  // 0607B1B0 mov.l 0x0607B23C,r8
    c.r[11] = c.r[8];  // 0607B1B2 mov r8,r11
    c.r[11] += 90;  // 0607B1B4 add #90,r11
    c.r[1] = 0x1u;  // 0607B1B6 mov #1,r1
    st8(c.r[11], c.r[1]);  // 0607B1B8 mov.b r1,@r11
    c.r[9] = c.r[8];  // 0607B1BA mov r8,r9
    c.r[9] += 88;  // 0607B1BC add #88,r9
    c.r[1] = ld32(0x0607B240u);  // 0607B1BE mov.l 0x0607B240,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B1C0 mov.w @r1,r1
    c.r[0] = ld32(0x0607B244u);  // 0607B1C2 mov.l 0x0607B244,r0
    c.r[7] = c.r[12];  // 0607B1C4 mov r12,r7
    c.r[6] = 0xCu;  // 0607B1C6 mov #12,r6
    c.r[5] = 0xFFFFFFFFu;  // 0607B1C8 mov #-1,r5
    c.r[4] = 0x10u;  // 0607B1CA mov #16,r4
    st16(c.r[9], c.r[1]);  // 0607B1CC mov.w r1,@r9
    { const uint32_t x = c.r[0]; c.pr = 0x0607B1D2u; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B1D2u) return; }  // 0607B1CE jsr @r0 ; mov.l r10,@-r15
    c.r[1] = ld32(0x0607B248u);  // 0607B1D2 mov.l 0x0607B248,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B1D4 tst r1,r1
    { const bool k = !c.t; c.r[15] -= 4; st32(c.r[15], c.r[10]); if (k) { goto L_0607B1DC; } }  // 0607B1D6 bf/s 0x0607B1DC ; mov.l r10,@-r15
    c.r[1] = c.r[14];  // 0607B1DA mov r14,r1
L_0607B1DC:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607B1DC mov.l r1,@-r15
    c.r[1] = 0xAu;  // 0607B1DE mov #10,r1
    c.r[3] = 0xDu;  // 0607B1E0 mov #13,r3
    c.r[0] = ld32(0x0607B24Cu);  // 0607B1E2 mov.l 0x0607B24C,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0607B1E4 mov.w @r9,r2
    c.r[7] = c.r[11];  // 0607B1E6 mov r11,r7
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607B1E8 mulu.w r1,r2
    c.r[6] = c.r[9];  // 0607B1EA mov r9,r6
    c.r[2] = ld32(c.r[8] + 8);  // 0607B1EC mov.l @(8,r8),r2
    c.r[1] = c.macl;  // 0607B1EE sts macl,r1
    c.r[2] += c.r[1];  // 0607B1F0 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0607B1F2 mov.l r2,@-r15
    c.r[1] = ld32(c.r[8] + 4);  // 0607B1F4 mov.l @(4,r8),r1
    c.r[5] = ld32(0x0607B250u);  // 0607B1F6 mov.l 0x0607B250,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607B1F8 mov.l r1,@-r15
    c.r[1] = ld32(c.r[8]);  // 0607B1FA mov.l @r8,r1
    c.r[4] = c.r[12];  // 0607B1FC mov r12,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607B1FE mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607B200 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0607B202 mov.l r3,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x0607B208u; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B208u) return; }  // 0607B204 jsr @r0 ; mov.l r10,@-r15
    c.r[1] = ld32(0x0607B254u);  // 0607B208 mov.l 0x0607B254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B20Eu; c.r[15] += 36; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B20Eu) return; }  // 0607B20A jsr @r1 ; add #36,r15
    c.r[1] = ld32(0x0607B258u);  // 0607B20E mov.l 0x0607B258,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B214u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B214u) return; }  // 0607B210 jsr @r1 ; nop
    c.r[1] = ld32(0x0607B25Cu);  // 0607B214 mov.l 0x0607B25C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B21Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B21Au) return; }  // 0607B216 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607B234u);  // 0607B21A mov.w 0x0607B234,r3
    c.r[14] += c.r[3];  // 0607B21C add r3,r14
    c.r[15] = c.r[14];  // 0607B21E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B220 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B222 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607B224 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607B226 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607B228 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607B22A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B22C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B22E rts ; mov.l @r15+,r8
}

void f_0607B260(SH2Context& c) {
    ran[1700] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B260 mov.l r14,@-r15
    c.r[15] -= 32;  // 0607B262 add #-32,r15
    c.r[14] = c.r[15];  // 0607B264 mov r15,r14
    c.r[2] = 0x0u;  // 0607B266 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0607B268 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0607B26A mov.l r2,@(4,r14)
    c.r[1] = ld32(0x0607B2D8u);  // 0607B26C mov.l 0x0607B2D8,r1
    st32(c.r[14] + 8, c.r[1]);  // 0607B26E mov.l r1,@(8,r14)
    c.r[1] = ld32(0x0607B2DCu);  // 0607B270 mov.l 0x0607B2DC,r1
    st32(c.r[14] + 12, c.r[1]);  // 0607B272 mov.l r1,@(12,r14)
    c.r[7] = c.r[14];  // 0607B274 mov r14,r7
    c.r[7] += 16;  // 0607B276 add #16,r7
    st32(c.r[14] + 16, c.r[2]);  // 0607B278 mov.l r2,@(16,r14)
    st32(c.r[14] + 20, c.r[2]);  // 0607B27A mov.l r2,@(20,r14)
    st32(c.r[14] + 24, c.r[2]);  // 0607B27C mov.l r2,@(24,r14)
    st32(c.r[14] + 28, c.r[2]);  // 0607B27E mov.l r2,@(28,r14)
    st32(c.r[7] + 12, c.r[1]);  // 0607B280 mov.l r1,@(12,r7)
    c.r[1] = ld32(0x0607B2E0u);  // 0607B282 mov.l 0x0607B2E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B284 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B286 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B288 tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[14]; if (k) { goto L_0607B290; } }  // 0607B28A bt/s 0x0607B290 ; mov r14,r3
    c.r[3] = c.r[7];  // 0607B28E mov r7,r3
L_0607B290:
    c.r[1] = ld32(c.r[3]);  // 0607B290 mov.l @r3,r1
    c.r[2] = ld32(0x0607B2E4u);  // 0607B292 mov.l 0x0607B2E4,r2
    st32(c.r[2], c.r[1]);  // 0607B294 mov.l r1,@r2
    c.r[1] = ld32(c.r[3] + 4);  // 0607B296 mov.l @(4,r3),r1
    c.r[7] = 0x0u;  // 0607B298 mov #0,r7
    st32(c.r[2] + 4, c.r[1]);  // 0607B29A mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[3] + 8);  // 0607B29C mov.l @(8,r3),r1
    c.r[14] += 32;  // 0607B29E add #32,r14
    st32(c.r[2] + 8, c.r[1]);  // 0607B2A0 mov.l r1,@(8,r2)
    c.r[1] = ld32(c.r[3] + 12);  // 0607B2A2 mov.l @(12,r3),r1
    c.r[15] = c.r[14];  // 0607B2A4 mov r14,r15
    st32(c.r[2] + 12, c.r[1]);  // 0607B2A6 mov.l r1,@(12,r2)
    c.r[1] = c.r[2];  // 0607B2A8 mov r2,r1
    c.r[1] += 80;  // 0607B2AA add #80,r1
    st8(c.r[1], c.r[7]);  // 0607B2AC mov.b r7,@r1
    c.r[3] = c.r[2];  // 0607B2AE mov r2,r3
    c.r[3] += 81;  // 0607B2B0 add #81,r3
    c.r[1] = 0x4u;  // 0607B2B2 mov #4,r1
    st8(c.r[3], c.r[1]);  // 0607B2B4 mov.b r1,@r3
    c.r[1] = c.r[2];  // 0607B2B6 mov r2,r1
    c.r[1] += 82;  // 0607B2B8 add #82,r1
    st8(c.r[1], c.r[7]);  // 0607B2BA mov.b r7,@r1
    c.r[3] = c.r[2];  // 0607B2BC mov r2,r3
    c.r[3] += 83;  // 0607B2BE add #83,r3
    c.r[1] = 0x8u;  // 0607B2C0 mov #8,r1
    st8(c.r[3], c.r[1]);  // 0607B2C2 mov.b r1,@r3
    c.r[1] = c.r[2];  // 0607B2C4 mov r2,r1
    c.r[1] += 84;  // 0607B2C6 add #84,r1
    st8(c.r[1], c.r[7]);  // 0607B2C8 mov.b r7,@r1
    c.r[1] = ld32(0x0607B2E8u);  // 0607B2CA mov.l 0x0607B2E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B2CC mov.b @r1,r1
    c.r[2] += 85;  // 0607B2CE add #85,r2
    c.r[1] += 1;  // 0607B2D0 add #1,r1
    st8(c.r[2], c.r[1]);  // 0607B2D2 mov.b r1,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B2D4 rts ; mov.l @r15+,r14
}

void f_0607B2EC(SH2Context& c) {
    ran[1701] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B2EC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607B2EE mov r15,r14
    c.r[3] = ld32(0x0607B31Cu);  // 0607B2F0 mov.l 0x0607B31C,r3
    c.r[1] = 0x8u;  // 0607B2F2 mov #8,r1
    st8(c.r[3], c.r[1]);  // 0607B2F4 mov.b r1,@r3
    c.r[1] = c.r[3];  // 0607B2F6 mov r3,r1
    c.r[1] += 1;  // 0607B2F8 add #1,r1
    c.r[7] = 0x0u;  // 0607B2FA mov #0,r7
    st8(c.r[1], c.r[7]);  // 0607B2FC mov.b r7,@r1
    c.r[2] = c.r[3];  // 0607B2FE mov r3,r2
    c.r[2] += 2;  // 0607B300 add #2,r2
    c.r[1] = 0x6u;  // 0607B302 mov #6,r1
    st8(c.r[2], c.r[1]);  // 0607B304 mov.b r1,@r2
    c.r[1] = c.r[3];  // 0607B306 mov r3,r1
    c.r[1] += 3;  // 0607B308 add #3,r1
    st8(c.r[1], c.r[7]);  // 0607B30A mov.b r7,@r1
    c.r[3] += 4;  // 0607B30C add #4,r3
    c.r[1] = ld32(0x0607B320u);  // 0607B30E mov.l 0x0607B320,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B310 mov.b @r1,r1
    c.r[1] += 5;  // 0607B312 add #5,r1
    st8(c.r[3], c.r[1]);  // 0607B314 mov.b r1,@r3
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B316 rts ; mov.l @r15+,r14
}

void f_0607B324(SH2Context& c) {
    ran[1702] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B324 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607B326 mov r15,r14
    c.r[3] = ld32(0x0607B33Cu);  // 0607B328 mov.l 0x0607B33C,r3
    c.r[2] = c.r[3];  // 0607B32A mov r3,r2
    c.r[2] += 20;  // 0607B32C add #20,r2
    c.r[1] = ld32(0x0607B340u);  // 0607B32E mov.l 0x0607B340,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B330 mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 0607B332 mov.b r1,@r2
    c.r[1] = 0x0u;  // 0607B334 mov #0,r1
    st32(c.r[3] + 16, c.r[1]);  // 0607B336 mov.l r1,@(16,r3)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B338 rts ; mov.l @r15+,r14
}

void f_0607B344(SH2Context& c) {
    ran[1703] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B344 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607B346 mov r15,r14
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 0607B348 exts.w r4,r4
    c.r[7] = ld32(0x0607B37Cu);  // 0607B34A mov.l 0x0607B37C,r7
    c.r[3] = c.r[7];  // 0607B34C mov r7,r3
    c.r[3] += 80;  // 0607B34E add #80,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607B350 mov.b @r3,r2
    c.r[1] = 0xFu;  // 0607B352 mov #15,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607B354 cmp/gt r1,r2
    { const bool k = c.t; c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5]; if (k) { goto L_0607B374; } }  // 0607B356 bt/s 0x0607B374 ; exts.w r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607B35A mov.b @r3,r1
    c.r[1] <<= 2;  // 0607B35C shll2 r1
    c.r[1] += c.r[7];  // 0607B35E add r7,r1
    c.r[1] += 16;  // 0607B360 add #16,r1
    st16(c.r[1], c.r[4]);  // 0607B362 mov.w r4,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607B364 mov.b @r3,r1
    c.r[1] <<= 2;  // 0607B366 shll2 r1
    c.r[1] += c.r[7];  // 0607B368 add r7,r1
    c.r[1] += 18;  // 0607B36A add #18,r1
    st16(c.r[1], c.r[5]);  // 0607B36C mov.w r5,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607B36E mov.b @r3,r1
    c.r[1] += 1;  // 0607B370 add #1,r1
    st8(c.r[3], c.r[1]);  // 0607B372 mov.b r1,@r3
L_0607B374:
    c.r[15] = c.r[14];  // 0607B374 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B376 rts ; mov.l @r15+,r14
}

void f_0607B380(SH2Context& c) {
    ran[1704] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B380 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607B382 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607B384 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607B386 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607B388 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607B38A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B38C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B38E sts.l pr,@-r15
    c.r[1] = ld32(0x0607B460u);  // 0607B390 mov.l 0x0607B460,r1
    c.r[0] = ld32(c.r[1]);  // 0607B392 mov.l @r1,r0
    c.r[0] &= 0x3u;  // 0607B394 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B396 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607B3A6; } }  // 0607B398 bf/s 0x0607B3A6 ; mov r15,r14
    c.r[1] = ld32(0x0607B464u);  // 0607B39C mov.l 0x0607B464,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B39E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B3A0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B3A2 tst r1,r1
    if (c.t) { goto L_0607B3AE; }  // 0607B3A4 bt 0x0607B3AE
L_0607B3A6:
    c.r[4] = ld32(0x0607B468u);  // 0607B3A6 mov.l 0x0607B468,r4
    c.r[1] = ld32(0x0607B46Cu);  // 0607B3A8 mov.l 0x0607B46C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B3AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B3AEu) return; }  // 0607B3AA jsr @r1 ; nop
L_0607B3AE:
    c.r[3] = ld32(0x0607B470u);  // 0607B3AE mov.l 0x0607B470,r3
    c.r[1] = c.r[3];  // 0607B3B0 mov r3,r1
    c.r[1] += 85;  // 0607B3B2 add #85,r1
    c.r[2] = c.r[3];  // 0607B3B4 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B3B6 mov.b @r1,r1
    c.r[2] += 82;  // 0607B3B8 add #82,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607B3BA mov.b @r2,r2
    c.r[1] += c.r[2];  // 0607B3BC add r2,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0607B3BE extu.b r1,r13
    c.r[2] = c.r[3];  // 0607B3C0 mov r3,r2
    c.r[2] += 80;  // 0607B3C2 add #80,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607B3C4 mov.b @r2,r1
    c.r[12] = 0x0u;  // 0607B3C6 mov #0,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607B3C8 cmp/ge r1,r12
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_0607B44C; } }  // 0607B3CA bt/s 0x0607B44C ; mov r12,r2
L_0607B3CE:
    c.r[2] <<= 2;  // 0607B3CE shll2 r2
    c.r[2] += c.r[3];  // 0607B3D0 add r3,r2
    c.r[1] = c.r[2];  // 0607B3D2 mov r2,r1
    c.r[1] += 16;  // 0607B3D4 add #16,r1
    c.r[2] += 18;  // 0607B3D6 add #18,r2
    c.r[10] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B3D8 mov.w @r1,r10
    c.r[4] = ld32(0x0607B474u);  // 0607B3DA mov.l 0x0607B474,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607B3DC mov.w @r2,r8
    c.r[1] = ld32(0x0607B478u);  // 0607B3DE mov.l 0x0607B478,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B3E4u; c.r[11] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B3E4u) return; }  // 0607B3E0 jsr @r1 ; mov r10,r11
    c.r[1] = ld32(0x0607B47Cu);  // 0607B3E4 mov.l 0x0607B47C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B3E6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B3E8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B3EA tst r1,r1
    { const bool k = !c.t; c.r[9] = c.r[8]; if (k) { goto L_0607B402; } }  // 0607B3EC bf/s 0x0607B402 ; mov r8,r9
    c.r[1] = ld32(0x0607B480u);  // 0607B3F0 mov.l 0x0607B480,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B3F6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B3F6u) return; }  // 0607B3F2 jsr @r1 ; mov r8,r4
    c.r[4] = 0u - c.r[10];  // 0607B3F6 neg r10,r4
    c.r[1] = ld32(0x0607B484u);  // 0607B3F8 mov.l 0x0607B484,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B3FEu; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B3FEu) return; }  // 0607B3FA jsr @r1 ; exts.w r4,r4
    goto L_0607B410;  // 0607B3FE bra 0x0607B410 ; nop
L_0607B402:
    c.r[9] <<= 16;  // 0607B402 shll16 r9
    c.r[11] <<= 16;  // 0607B404 shll16 r11
    c.r[1] = ld32(0x0607B488u);  // 0607B406 mov.l 0x0607B488,r1
    c.r[6] = 0x0u;  // 0607B408 mov #0,r6
    c.r[5] = c.r[9];  // 0607B40A mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607B410u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B410u) return; }  // 0607B40C jsr @r1 ; mov r11,r4
L_0607B410:
    c.r[1] = ld32(0x0607B48Cu);  // 0607B410 mov.l 0x0607B48C,r1
    c.r[1] += 96;  // 0607B412 add #96,r1
    c.r[6] = ld32(c.r[1]);  // 0607B414 mov.l @r1,r6
    c.r[1] = ld32(0x0607B48Cu);  // 0607B416 mov.l 0x0607B48C,r1
    c.r[1] += 92;  // 0607B418 add #92,r1
    c.r[5] = ld32(c.r[1]);  // 0607B41A mov.l @r1,r5
    c.r[7] = ld32(0x0607B490u);  // 0607B41C mov.l 0x0607B490,r7
    c.r[1] = ld32(0x0607B494u);  // 0607B41E mov.l 0x0607B494,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B424u; c.r[4] = ld32(c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B424u) return; }  // 0607B420 jsr @r1 ; mov.l @r7,r4
    c.r[1] = ld32(0x0607B498u);  // 0607B424 mov.l 0x0607B498,r1
    c.r[2] = c.r[13];  // 0607B426 mov r13,r2
    c.r[2] <<= 2;  // 0607B428 shll2 r2
    c.r[2] += c.r[13];  // 0607B42A add r13,r2
    c.r[2] += c.r[2];  // 0607B42C add r2,r2
    c.r[0] = ld32(0x0607B49Cu);  // 0607B42E mov.l 0x0607B49C,r0
    c.r[6] = 0x0u;  // 0607B430 mov #0,r6
    c.r[5] = ld32(c.r[1] + 8);  // 0607B432 mov.l @(8,r1),r5
    c.r[4] = ld32(0x0607B470u);  // 0607B434 mov.l 0x0607B470,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607B43Au; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B43Au) return; }  // 0607B436 jsr @r0 ; add r2,r5
    c.r[1] = c.r[12];  // 0607B43A mov r12,r1
    c.r[1] += 1;  // 0607B43C add #1,r1
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0607B43E exts.w r1,r12
    c.r[7] = ld32(0x0607B4A0u);  // 0607B440 mov.l 0x0607B4A0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0607B442 mov.b @r7,r1
    c.r[3] = ld32(0x0607B470u);  // 0607B444 mov.l 0x0607B470,r3
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0607B446 cmp/ge r1,r12
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { SH2_POLL(c); goto L_0607B3CE; } }  // 0607B448 bf/s 0x0607B3CE ; mov r12,r2
L_0607B44C:
    c.r[15] = c.r[14];  // 0607B44C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B44E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B450 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607B452 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607B454 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607B456 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607B458 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B45A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B45C rts ; mov.l @r15+,r8
}

void f_0607B4A4(SH2Context& c) {
    ran[1705] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B4A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607B4A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607B4A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607B4AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607B4AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607B4AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B4B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B4B2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607B4B4 mov r15,r14
    c.r[1] = ld32(0x0607B58Cu);  // 0607B4B6 mov.l 0x0607B58C,r1
    c.r[0] = ld32(c.r[1]);  // 0607B4B8 mov.l @r1,r0
    c.r[1] = 0x4u;  // 0607B4BA mov #4,r1
    c.r[1] &= c.r[0];  // 0607B4BC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B4BE tst r1,r1
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_0607B4DE; } }  // 0607B4C0 bt/s 0x0607B4DE ; mov #0,r12
    c.r[1] = ld32(0x0607B590u);  // 0607B4C4 mov.l 0x0607B590,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B4C6 mov.b @r1,r1
    c.r[3] = ld32(0x0607B594u);  // 0607B4C8 mov.l 0x0607B594,r3
    c.r[2] = ld32(c.r[3] + 12);  // 0607B4CA mov.l @(12,r3),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607B4CC extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0607B4CE mul.l r2,r1
    c.r[7] = ld32(0x0607B598u);  // 0607B4D0 mov.l 0x0607B598,r7
    c.r[5] = ld32(c.r[3] + 16);  // 0607B4D2 mov.l @(16,r3),r5
    { const uint32_t x = c.r[7]; c.pr = 0x0607B4D8u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B4D8u) return; }  // 0607B4D4 jsr @r7 ; sts macl,r4
    c.r[0] += 1;  // 0607B4D8 add #1,r0
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[0]; goto L_0607B4F0;  // 0607B4DA bra 0x0607B4F0 ; exts.w r0,r12
L_0607B4DE:
    c.r[0] &= 0x8u;  // 0607B4DE and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B4E0 tst r0,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0607B4F2; } }  // 0607B4E2 bt/s 0x0607B4F2 ; mov #0,r9
    c.r[1] = ld32(0x0607B590u);  // 0607B4E6 mov.l 0x0607B590,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B4E8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B4EA extu.b r1,r1
    c.r[1] += 1;  // 0607B4EC add #1,r1
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0607B4EE exts.w r1,r12
L_0607B4F0:
    c.r[9] = 0x0u;  // 0607B4F0 mov #0,r9
L_0607B4F2:
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[12];  // 0607B4F2 cmp/ge r12,r9
    if (c.t) { goto L_0607B578; }  // 0607B4F4 bt 0x0607B578
    c.r[11] = ld32(0x0607B59Cu);  // 0607B4F6 mov.l 0x0607B59C,r11
    c.r[10] = ld32(0x0607B5A0u);  // 0607B4F8 mov.l 0x0607B5A0,r10
L_0607B4FA:
    c.r[1] = ld32(0x0607B5A4u);  // 0607B4FA mov.l 0x0607B5A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B500u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B500u) return; }  // 0607B4FC jsr @r1 ; mov r11,r4
    c.r[1] = c.r[10];  // 0607B500 mov r10,r1
    c.r[1] += 21;  // 0607B502 add #21,r1
    c.r[13] = ld32(0x0607B598u);  // 0607B504 mov.l 0x0607B598,r13
    c.r[6] = c.r[10];  // 0607B506 mov r10,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B508 mov.b @r1,r7
    c.r[6] += 6;  // 0607B50A add #6,r6
    c.r[4] = ld32(c.r[10] + 8);  // 0607B50C mov.l @(8,r10),r4
    c.r[7] = c.r[7] & 0xFFu;  // 0607B50E extu.b r7,r7
    { const uint32_t x = c.r[13]; c.pr = 0x0607B514u; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B514u) return; }  // 0607B510 jsr @r13 ; mov r7,r5
    c.r[13] = ld32(0x0607B5A8u);  // 0607B514 mov.l 0x0607B5A8,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0607B516 mov.w @r13,r1
    c.macl = c.r[0] * c.r[9];  // 0607B518 mul.l r9,r0
    c.r[4] = ld32(c.r[10] + 12);  // 0607B51A mov.l @(12,r10),r4
    c.r[13] = ld32(0x0607B598u);  // 0607B51C mov.l 0x0607B598,r13
    c.r[8] = c.macl;  // 0607B51E sts macl,r8
    { const uint32_t x = c.r[13]; c.pr = 0x0607B524u; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B524u) return; }  // 0607B520 jsr @r13 ; add r1,r8
    c.macl = c.r[0] * c.r[9];  // 0607B524 mul.l r9,r0
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 0607B526 exts.w r8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0607B528 mov.w @r6,r1
    c.r[4] = c.macl;  // 0607B52A sts macl,r4
    c.r[4] += c.r[1];  // 0607B52C add r1,r4
    c.r[1] = ld32(0x0607B5ACu);  // 0607B52E mov.l 0x0607B5AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B534u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B534u) return; }  // 0607B530 jsr @r1 ; exts.w r4,r4
    c.r[8] = 0u - c.r[8];  // 0607B534 neg r8,r8
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 0607B536 exts.w r8,r8
    c.r[1] = ld32(0x0607B5B0u);  // 0607B538 mov.l 0x0607B5B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B53Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B53Eu) return; }  // 0607B53A jsr @r1 ; mov r8,r4
    c.r[1] = c.r[11];  // 0607B53E mov r11,r1
    c.r[1] += 72;  // 0607B540 add #72,r1
    c.r[6] = ld32(c.r[1]);  // 0607B542 mov.l @r1,r6
    c.r[1] = c.r[11];  // 0607B544 mov r11,r1
    c.r[1] += 68;  // 0607B546 add #68,r1
    c.r[5] = ld32(c.r[1]);  // 0607B548 mov.l @r1,r5
    c.r[13] = ld32(0x0607B5B4u);  // 0607B54A mov.l 0x0607B5B4,r13
    c.r[1] = ld32(0x0607B5B8u);  // 0607B54C mov.l 0x0607B5B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B552u; c.r[4] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B552u) return; }  // 0607B54E jsr @r1 ; mov.l @r13,r4
    c.r[3] = ld32(0x0607B5BCu);  // 0607B552 mov.l 0x0607B5BC,r3
    c.r[13] = ld32(0x0607B5C0u);  // 0607B554 mov.l 0x0607B5C0,r13
    c.r[0] = ld32(0x0607B5C4u);  // 0607B556 mov.l 0x0607B5C4,r0
    c.r[6] = 0x0u;  // 0607B558 mov #0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0607B55A mov.b @r13,r1
    c.r[4] = ld32(0x0607B5C8u);  // 0607B55C mov.l 0x0607B5C8,r4
    c.r[5] = ld32(c.r[3] + 8);  // 0607B55E mov.l @(8,r3),r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607B560 extu.b r1,r1
    c.r[2] = c.r[1];  // 0607B562 mov r1,r2
    c.r[2] <<= 2;  // 0607B564 shll2 r2
    c.r[2] += c.r[1];  // 0607B566 add r1,r2
    c.r[2] += c.r[2];  // 0607B568 add r2,r2
    { const uint32_t x = c.r[0]; c.pr = 0x0607B56Eu; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B56Eu) return; }  // 0607B56A jsr @r0 ; add r2,r5
    c.r[1] = c.r[9];  // 0607B56E mov r9,r1
    c.r[1] += 1;  // 0607B570 add #1,r1
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0607B572 exts.w r1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[12];  // 0607B574 cmp/ge r12,r9
    if (!c.t) { SH2_POLL(c); goto L_0607B4FA; }  // 0607B576 bf 0x0607B4FA
L_0607B578:
    c.r[15] = c.r[14];  // 0607B578 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B57A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B57C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607B57E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607B580 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607B582 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607B584 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B586 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B588 rts ; mov.l @r15+,r8
}

void f_0607B5CC(SH2Context& c) {
    ran[1706] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B5CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607B5CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607B5D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607B5D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607B5D4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607B5D6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B5D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B5DA sts.l pr,@-r15
    c.r[15] -= 4;  // 0607B5DC add #-4,r15
    c.r[14] = c.r[15];  // 0607B5DE mov r15,r14
    c.r[1] = ld32(0x0607B6B0u);  // 0607B5E0 mov.l 0x0607B6B0,r1
    c.r[2] = ld32(c.r[1]);  // 0607B5E2 mov.l @r1,r2
    c.r[1] = 0x4u;  // 0607B5E4 mov #4,r1
    c.r[1] &= c.r[2];  // 0607B5E6 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B5E8 tst r1,r1
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_0607B608; } }  // 0607B5EA bt/s 0x0607B608 ; mov #0,r11
    c.r[1] = ld32(0x0607B6B4u);  // 0607B5EE mov.l 0x0607B6B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B5F0 mov.b @r1,r1
    c.r[3] = ld32(0x0607B6B8u);  // 0607B5F2 mov.l 0x0607B6B8,r3
    c.r[2] = ld32(c.r[3] + 24);  // 0607B5F4 mov.l @(24,r3),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607B5F6 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0607B5F8 mul.l r2,r1
    c.r[7] = ld32(0x0607B6BCu);  // 0607B5FA mov.l 0x0607B6BC,r7
    c.r[5] = ld32(c.r[3] + 28);  // 0607B5FC mov.l @(28,r3),r5
    { const uint32_t x = c.r[7]; c.pr = 0x0607B602u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B602u) return; }  // 0607B5FE jsr @r7 ; sts macl,r4
    c.r[0] += 1;  // 0607B602 add #1,r0
    c.r[11] = (uint32_t)(int32_t)(int16_t)c.r[0]; goto L_0607B61C;  // 0607B604 bra 0x0607B61C ; exts.w r0,r11
L_0607B608:
    c.r[0] = 0x8u;  // 0607B608 mov #8,r0
    c.r[2] &= c.r[0];  // 0607B60A and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0607B60C tst r2,r2
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0607B61E; } }  // 0607B60E bt/s 0x0607B61E ; mov #0,r8
    c.r[1] = ld32(0x0607B6B4u);  // 0607B612 mov.l 0x0607B6B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B614 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B616 extu.b r1,r1
    c.r[1] += 1;  // 0607B618 add #1,r1
    c.r[11] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0607B61A exts.w r1,r11
L_0607B61C:
    c.r[8] = 0x0u;  // 0607B61C mov #0,r8
L_0607B61E:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[11];  // 0607B61E cmp/ge r11,r8
    if (c.t) { goto L_0607B69A; }  // 0607B620 bt 0x0607B69A
    c.r[10] = ld32(0x0607B6C0u);  // 0607B622 mov.l 0x0607B6C0,r10
    c.r[9] = ld32(0x0607B6C4u);  // 0607B624 mov.l 0x0607B6C4,r9
    c.r[12] = ld32(0x0607B6BCu);  // 0607B626 mov.l 0x0607B6BC,r12
    c.r[13] = c.r[9];  // 0607B628 mov r9,r13
    c.r[13] += 20;  // 0607B62A add #20,r13
L_0607B62C:
    c.r[1] = ld32(0x0607B6C8u);  // 0607B62C mov.l 0x0607B6C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B632u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B632u) return; }  // 0607B62E jsr @r1 ; mov r10,r4
    c.r[1] = c.r[9];  // 0607B632 mov r9,r1
    c.r[1] += 21;  // 0607B634 add #21,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B636 mov.b @r1,r7
    c.r[4] = ld32(c.r[9] + 8);  // 0607B638 mov.l @(8,r9),r4
    c.r[7] = c.r[7] & 0xFFu;  // 0607B63A extu.b r7,r7
    { const uint32_t x = c.r[12]; c.pr = 0x0607B640u; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B640u) return; }  // 0607B63C jsr @r12 ; mov r7,r5
    c.r[6] = c.r[0];  // 0607B640 mov r0,r6
    c.macl = c.r[6] * c.r[8];  // 0607B642 mul.l r8,r6
    c.r[0] = ld32(c.r[9]);  // 0607B644 mov.l @r9,r0
    c.r[4] = ld32(c.r[9] + 12);  // 0607B646 mov.l @(12,r9),r4
    c.r[1] = c.macl;  // 0607B648 sts macl,r1
    c.r[0] += c.r[1];  // 0607B64A add r1,r0
    { const uint32_t x = c.r[12]; c.pr = 0x0607B650u; st32(c.r[14], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B650u) return; }  // 0607B64C jsr @r12 ; mov.l r0,@r14
    c.r[7] = c.r[0];  // 0607B650 mov r0,r7
    c.macl = c.r[7] * c.r[8];  // 0607B652 mul.l r8,r7
    c.r[5] = ld32(c.r[9] + 4);  // 0607B654 mov.l @(4,r9),r5
    c.r[6] = 0x0u;  // 0607B656 mov #0,r6
    c.r[1] = c.macl;  // 0607B658 sts macl,r1
    c.r[5] += c.r[1];  // 0607B65A add r1,r5
    c.r[1] = ld32(0x0607B6CCu);  // 0607B65C mov.l 0x0607B6CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B662u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B662u) return; }  // 0607B65E jsr @r1 ; mov.l @r14,r4
    c.r[1] = c.r[10];  // 0607B662 mov r10,r1
    c.r[1] += 72;  // 0607B664 add #72,r1
    c.r[6] = ld32(c.r[1]);  // 0607B666 mov.l @r1,r6
    c.r[1] = c.r[10];  // 0607B668 mov r10,r1
    c.r[1] += 68;  // 0607B66A add #68,r1
    c.r[5] = ld32(c.r[1]);  // 0607B66C mov.l @r1,r5
    c.r[0] = ld32(0x0607B6D0u);  // 0607B66E mov.l 0x0607B6D0,r0
    c.r[1] = ld32(0x0607B6D4u);  // 0607B670 mov.l 0x0607B6D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B676u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B676u) return; }  // 0607B672 jsr @r1 ; mov.l @r0,r4
    c.r[3] = ld32(0x0607B6D8u);  // 0607B676 mov.l 0x0607B6D8,r3
    c.r[6] = 0x0u;  // 0607B678 mov #0,r6
    c.r[4] = ld32(0x0607B6DCu);  // 0607B67A mov.l 0x0607B6DC,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0607B67C mov.b @r13,r1
    c.r[0] = ld32(0x0607B6E0u);  // 0607B67E mov.l 0x0607B6E0,r0
    c.r[5] = ld32(c.r[3] + 8);  // 0607B680 mov.l @(8,r3),r5
    c.r[1] = c.r[1] & 0xFFu;  // 0607B682 extu.b r1,r1
    c.r[2] = c.r[1];  // 0607B684 mov r1,r2
    c.r[2] <<= 2;  // 0607B686 shll2 r2
    c.r[2] += c.r[1];  // 0607B688 add r1,r2
    c.r[2] += c.r[2];  // 0607B68A add r2,r2
    { const uint32_t x = c.r[0]; c.pr = 0x0607B690u; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B690u) return; }  // 0607B68C jsr @r0 ; add r2,r5
    c.r[1] = c.r[8];  // 0607B690 mov r8,r1
    c.r[1] += 1;  // 0607B692 add #1,r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0607B694 exts.w r1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[11];  // 0607B696 cmp/ge r11,r8
    if (!c.t) { SH2_POLL(c); goto L_0607B62C; }  // 0607B698 bf 0x0607B62C
L_0607B69A:
    c.r[14] += 4;  // 0607B69A add #4,r14
    c.r[15] = c.r[14];  // 0607B69C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B69E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B6A0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607B6A2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607B6A4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607B6A6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607B6A8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B6AA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B6AC rts ; mov.l @r15+,r8
}

void f_0607B6E4(SH2Context& c) {
    ran[1707] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B6E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607B6E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B6E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B6EA sts.l pr,@-r15
    c.r[15] -= 16;  // 0607B6EC add #-16,r15
    c.r[1] = ld32(0x0607B7A4u);  // 0607B6EE mov.l 0x0607B7A4,r1
    c.r[0] = ld32(c.r[1]);  // 0607B6F0 mov.l @r1,r0
    c.r[0] &= 0x3u;  // 0607B6F2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B6F4 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607B704; } }  // 0607B6F6 bf/s 0x0607B704 ; mov r15,r14
    c.r[1] = ld32(0x0607B7A8u);  // 0607B6FA mov.l 0x0607B7A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B6FC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B6FE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B700 tst r1,r1
    if (c.t) { goto L_0607B70C; }  // 0607B702 bt 0x0607B70C
L_0607B704:
    c.r[4] = ld32(0x0607B7ACu);  // 0607B704 mov.l 0x0607B7AC,r4
    c.r[1] = ld32(0x0607B7B0u);  // 0607B706 mov.l 0x0607B7B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B70Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B70Cu) return; }  // 0607B708 jsr @r1 ; nop
L_0607B70C:
    c.r[2] = ld32(0x0607B7ACu);  // 0607B70C mov.l 0x0607B7AC,r2
    c.r[1] = c.r[2];  // 0607B70E mov r2,r1
    c.r[1] += 4;  // 0607B710 add #4,r1
    c.r[2] += 1;  // 0607B712 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B714 mov.b @r1,r1
    c.r[8] = ld32(0x0607B7B4u);  // 0607B716 mov.l 0x0607B7B4,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607B718 mov.b @r2,r2
    c.r[1] += c.r[2];  // 0607B71A add r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0607B71C extu.b r1,r9
    c.r[1] = ld32(0x0607B7B8u);  // 0607B71E mov.l 0x0607B7B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B724u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B724u) return; }  // 0607B720 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0607B7BCu);  // 0607B724 mov.l 0x0607B7BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B726 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B728 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B72A tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607B744; } }  // 0607B72C bf/s 0x0607B744 ; mov r8,r1
    c.r[1] += 54;  // 0607B730 add #54,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B732 mov.w @r1,r4
    c.r[1] = ld32(0x0607B7C0u);  // 0607B734 mov.l 0x0607B7C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B73Au; c.r[8] += 52; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B73Au) return; }  // 0607B736 jsr @r1 ; add #52,r8
    c.r[1] = ld32(0x0607B7C4u);  // 0607B73A mov.l 0x0607B7C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B740u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B740u) return; }  // 0607B73C jsr @r1 ; mov.w @r8,r4
    goto L_0607B750;  // 0607B740 bra 0x0607B750 ; nop
L_0607B744:
    c.r[1] -= 24;  // 0607B744 add #-24,r1
    c.r[5] = ld32(c.r[1] + 16);  // 0607B746 mov.l @(16,r1),r5
    c.r[4] = ld32(c.r[1] + 12);  // 0607B748 mov.l @(12,r1),r4
    c.r[1] = ld32(0x0607B7C8u);  // 0607B74A mov.l 0x0607B7C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B750u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B750u) return; }  // 0607B74C jsr @r1 ; mov #0,r6
L_0607B750:
    c.r[2] = ld32(0x0607B7CCu);  // 0607B750 mov.l 0x0607B7CC,r2
    c.r[1] = c.r[2];  // 0607B752 mov r2,r1
    c.r[1] += 96;  // 0607B754 add #96,r1
    c.r[6] = ld32(c.r[1]);  // 0607B756 mov.l @r1,r6
    c.r[1] = c.r[2];  // 0607B758 mov r2,r1
    c.r[1] += 92;  // 0607B75A add #92,r1
    c.r[5] = ld32(c.r[1]);  // 0607B75C mov.l @r1,r5
    c.r[2] += 88;  // 0607B75E add #88,r2
    c.r[1] = ld32(0x0607B7D0u);  // 0607B760 mov.l 0x0607B7D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B766u; c.r[4] = ld32(c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B766u) return; }  // 0607B762 jsr @r1 ; mov.l @r2,r4
    c.r[8] = ld32(0x0607B7D4u);  // 0607B766 mov.l 0x0607B7D4,r8
    c.r[6] = ld32(c.r[8] + 8);  // 0607B768 mov.l @(8,r8),r6
    c.r[5] = ld32(c.r[8] + 4);  // 0607B76A mov.l @(4,r8),r5
    c.r[0] = ld32(0x0607B7D8u);  // 0607B76C mov.l 0x0607B7D8,r0
    c.r[4] = ld32(c.r[8]);  // 0607B76E mov.l @r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607B774u; c.r[7] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B774u) return; }  // 0607B770 jsr @r0 ; mov r14,r7
    c.r[1] = 0x0u;  // 0607B774 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 0607B776 mov.l r1,@(4,r14)
    st32(c.r[14], c.r[1]);  // 0607B778 mov.l r1,@r14
    c.r[2] = c.r[9];  // 0607B77A mov r9,r2
    c.r[2] <<= 2;  // 0607B77C shll2 r2
    c.r[2] += c.r[9];  // 0607B77E add r9,r2
    c.r[2] += c.r[2];  // 0607B780 add r2,r2
    c.r[0] = ld32(0x0607B7DCu);  // 0607B782 mov.l 0x0607B7DC,r0
    c.r[1] = ld32(c.r[8] + 12);  // 0607B784 mov.l @(12,r8),r1
    c.r[6] = 0x0u;  // 0607B786 mov #0,r6
    st32(c.r[14] + 12, c.r[1]);  // 0607B788 mov.l r1,@(12,r14)
    c.r[1] = ld32(0x0607B7E0u);  // 0607B78A mov.l 0x0607B7E0,r1
    c.r[5] = ld32(c.r[1] + 8);  // 0607B78C mov.l @(8,r1),r5
    c.r[4] = c.r[14];  // 0607B78E mov r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607B794u; c.r[5] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B794u) return; }  // 0607B790 jsr @r0 ; add r2,r5
    c.r[14] += 16;  // 0607B794 add #16,r14
    c.r[15] = c.r[14];  // 0607B796 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B798 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B79A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B79C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B79E rts ; mov.l @r15+,r8
}

void f_0607B7E4(SH2Context& c) {
    ran[1708] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B7E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B7E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B7E8 sts.l pr,@-r15
    c.r[15] -= 16;  // 0607B7EA add #-16,r15
    c.r[14] = c.r[15];  // 0607B7EC mov r15,r14
    c.r[8] = ld32(0x0607B874u);  // 0607B7EE mov.l 0x0607B874,r8
    c.r[1] = ld32(0x0607B878u);  // 0607B7F0 mov.l 0x0607B878,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B7F6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B7F6u) return; }  // 0607B7F2 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0607B87Cu);  // 0607B7F6 mov.l 0x0607B87C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B7F8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B7FA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B7FC tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0607B816; } }  // 0607B7FE bf/s 0x0607B816 ; mov r8,r1
    c.r[1] += 54;  // 0607B802 add #54,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B804 mov.w @r1,r4
    c.r[1] = ld32(0x0607B880u);  // 0607B806 mov.l 0x0607B880,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B80Cu; c.r[8] += 52; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B80Cu) return; }  // 0607B808 jsr @r1 ; add #52,r8
    c.r[1] = ld32(0x0607B884u);  // 0607B80C mov.l 0x0607B884,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B812u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B812u) return; }  // 0607B80E jsr @r1 ; mov.w @r8,r4
    goto L_0607B822;  // 0607B812 bra 0x0607B822 ; nop
L_0607B816:
    c.r[1] -= 24;  // 0607B816 add #-24,r1
    c.r[5] = ld32(c.r[1] + 16);  // 0607B818 mov.l @(16,r1),r5
    c.r[4] = ld32(c.r[1] + 12);  // 0607B81A mov.l @(12,r1),r4
    c.r[1] = ld32(0x0607B888u);  // 0607B81C mov.l 0x0607B888,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B822u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B822u) return; }  // 0607B81E jsr @r1 ; mov #0,r6
L_0607B822:
    c.r[2] = ld32(0x0607B88Cu);  // 0607B822 mov.l 0x0607B88C,r2
    c.r[1] = c.r[2];  // 0607B824 mov r2,r1
    c.r[1] += 96;  // 0607B826 add #96,r1
    c.r[6] = ld32(c.r[1]);  // 0607B828 mov.l @r1,r6
    c.r[1] = c.r[2];  // 0607B82A mov r2,r1
    c.r[1] += 92;  // 0607B82C add #92,r1
    c.r[5] = ld32(c.r[1]);  // 0607B82E mov.l @r1,r5
    c.r[2] += 88;  // 0607B830 add #88,r2
    c.r[1] = ld32(0x0607B890u);  // 0607B832 mov.l 0x0607B890,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B838u; c.r[4] = ld32(c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B838u) return; }  // 0607B834 jsr @r1 ; mov.l @r2,r4
    c.r[8] = ld32(0x0607B894u);  // 0607B838 mov.l 0x0607B894,r8
    c.r[6] = ld32(c.r[8] + 8);  // 0607B83A mov.l @(8,r8),r6
    c.r[5] = ld32(c.r[8] + 4);  // 0607B83C mov.l @(4,r8),r5
    c.r[0] = ld32(0x0607B898u);  // 0607B83E mov.l 0x0607B898,r0
    c.r[4] = ld32(c.r[8]);  // 0607B840 mov.l @r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607B846u; c.r[7] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B846u) return; }  // 0607B842 jsr @r0 ; mov r14,r7
    c.r[1] = 0x0u;  // 0607B846 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 0607B848 mov.l r1,@(4,r14)
    st32(c.r[14], c.r[1]);  // 0607B84A mov.l r1,@r14
    c.r[3] = ld32(0x0607B89Cu);  // 0607B84C mov.l 0x0607B89C,r3
    c.r[0] = ld32(0x0607B8A0u);  // 0607B84E mov.l 0x0607B8A0,r0
    c.r[1] = ld32(c.r[8] + 12);  // 0607B850 mov.l @(12,r8),r1
    c.r[6] = 0x0u;  // 0607B852 mov #0,r6
    st32(c.r[14] + 12, c.r[1]);  // 0607B854 mov.l r1,@(12,r14)
    c.r[1] = ld32(0x0607B8A4u);  // 0607B856 mov.l 0x0607B8A4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607B858 mov.w @r1,r2
    c.r[4] = c.r[14];  // 0607B85A mov r14,r4
    c.r[1] = 0xAu;  // 0607B85C mov #10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607B85E mulu.w r1,r2
    c.r[5] = ld32(c.r[3] + 8);  // 0607B860 mov.l @(8,r3),r5
    c.r[1] = c.macl;  // 0607B862 sts macl,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0607B868u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B868u) return; }  // 0607B864 jsr @r0 ; add r1,r5
    c.r[14] += 16;  // 0607B868 add #16,r14
    c.r[15] = c.r[14];  // 0607B86A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B86C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B86E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B870 rts ; mov.l @r15+,r8
}

void f_0607B8A8(SH2Context& c) {
    ran[1709] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B8A8 mov.l r14,@-r15
    c.r[3] = c.r[4];  // 0607B8AA mov r4,r3
    c.r[3] += 3;  // 0607B8AC add #3,r3
    c.r[2] = c.r[4];  // 0607B8AE mov r4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607B8B0 mov.b @r3,r1
    c.r[2] += 2;  // 0607B8B2 add #2,r2
    c.r[1] += 1;  // 0607B8B4 add #1,r1
    st8(c.r[3], c.r[1]);  // 0607B8B6 mov.b r1,@r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607B8B8 mov.b @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607B8BA extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607B8BC extu.b r2,r2
    c.t = c.r[1] >= c.r[2];  // 0607B8BE cmp/hs r2,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0607B8DE; } }  // 0607B8C0 bf/s 0x0607B8DE ; mov r15,r14
    c.r[7] = 0x0u;  // 0607B8C4 mov #0,r7
    st8(c.r[3], c.r[7]);  // 0607B8C6 mov.b r7,@r3
    c.r[3] = c.r[4];  // 0607B8C8 mov r4,r3
    c.r[3] += 1;  // 0607B8CA add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0607B8CC mov.b @r3,r2
    c.r[2] += 1;  // 0607B8CE add #1,r2
    st8(c.r[3], c.r[2]);  // 0607B8D0 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0607B8D2 mov.b @r4,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0607B8D4 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607B8D6 extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 0607B8D8 cmp/hs r1,r2
    if (!c.t) { goto L_0607B8DE; }  // 0607B8DA bf 0x0607B8DE
    st8(c.r[3], c.r[7]);  // 0607B8DC mov.b r7,@r3
L_0607B8DE:
    c.r[15] = c.r[14];  // 0607B8DE mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B8E0 rts ; mov.l @r15+,r14
}

void f_0607B8E4(SH2Context& c) {
    ran[1710] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607B8E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607B8E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607B8E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607B8EA sts.l pr,@-r15
    c.r[15] -= 12;  // 0607B8EC add #-12,r15
    c.r[14] = c.r[15];  // 0607B8EE mov r15,r14
    c.r[4] = ld32(0x0607B9B8u);  // 0607B8F0 mov.l 0x0607B9B8,r4
    c.r[1] = ld32(0x0607B9BCu);  // 0607B8F2 mov.l 0x0607B9BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B8F8u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B8F8u) return; }  // 0607B8F4 jsr @r1 ; mov r4,r5
    c.r[9] = ld32(0x0607B9C0u);  // 0607B8F8 mov.l 0x0607B9C0,r9
    c.r[0] = ld32(c.r[9]);  // 0607B8FA mov.l @r9,r0
    c.r[1] = ld32(0x0607B9C4u);  // 0607B8FC mov.l 0x0607B9C4,r1
    st32(c.r[1], c.r[0]);  // 0607B8FE mov.l r0,@r1
    c.r[0] &= 0x1u;  // 0607B900 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B902 tst r0,r0
    if (c.t) { goto L_0607B90C; }  // 0607B904 bt 0x0607B90C
    c.r[1] = ld32(0x0607B9C8u);  // 0607B906 mov.l 0x0607B9C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B90Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B90Cu) return; }  // 0607B908 jsr @r1 ; nop
L_0607B90C:
    c.r[0] = ld32(c.r[9]);  // 0607B90C mov.l @r9,r0
    c.r[0] &= 0x2u;  // 0607B90E and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B910 tst r0,r0
    if (c.t) { goto L_0607B91A; }  // 0607B912 bt 0x0607B91A
    c.r[1] = ld32(0x0607B9CCu);  // 0607B914 mov.l 0x0607B9CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B91Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B91Au) return; }  // 0607B916 jsr @r1 ; nop
L_0607B91A:
    c.r[0] = ld32(c.r[9]);  // 0607B91A mov.l @r9,r0
    c.r[0] &= 0x10u;  // 0607B91C and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B91E tst r0,r0
    if (c.t) { goto L_0607B928; }  // 0607B920 bt 0x0607B928
    c.r[1] = ld32(0x0607B9D0u);  // 0607B922 mov.l 0x0607B9D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B928u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B928u) return; }  // 0607B924 jsr @r1 ; nop
L_0607B928:
    c.r[0] = ld32(c.r[9]);  // 0607B928 mov.l @r9,r0
    c.r[0] &= 0x20u;  // 0607B92A and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B92C tst r0,r0
    if (c.t) { goto L_0607B936; }  // 0607B92E bt 0x0607B936
    c.r[1] = ld32(0x0607B9D4u);  // 0607B930 mov.l 0x0607B9D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B936u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B936u) return; }  // 0607B932 jsr @r1 ; nop
L_0607B936:
    c.r[8] = ld32(0x0607B9D8u);  // 0607B936 mov.l 0x0607B9D8,r8
    c.r[2] = ld32(c.r[8] + 12);  // 0607B938 mov.l @(12,r8),r2
    c.r[1] = ld32(c.r[8]);  // 0607B93A mov.l @r8,r1
    c.r[2] += c.r[1];  // 0607B93C add r1,r2
    st32(c.r[14], c.r[2]);  // 0607B93E mov.l r2,@r14
    c.r[2] = ld32(c.r[8] + 16);  // 0607B940 mov.l @(16,r8),r2
    c.r[1] = ld32(c.r[8] + 4);  // 0607B942 mov.l @(4,r8),r1
    c.r[2] += c.r[1];  // 0607B944 add r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0607B946 mov.l r2,@(4,r14)
    c.r[2] = ld32(c.r[8] + 20);  // 0607B948 mov.l @(20,r8),r2
    c.r[1] = ld32(c.r[8] + 8);  // 0607B94A mov.l @(8,r8),r1
    c.r[4] = 0x0u;  // 0607B94C mov #0,r4
    c.r[2] += c.r[1];  // 0607B94E add r1,r2
    c.r[1] = ld32(0x0607B9DCu);  // 0607B950 mov.l 0x0607B9DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B956u; st32(c.r[14] + 8, c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B956u) return; }  // 0607B952 jsr @r1 ; mov.l r2,@(8,r14)
    c.r[5] = c.r[8];  // 0607B956 mov r8,r5
    c.r[5] += 12;  // 0607B958 add #12,r5
    c.r[1] = ld32(0x0607B9E0u);  // 0607B95A mov.l 0x0607B9E0,r1
    c.r[6] = 0x0u;  // 0607B95C mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607B962u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B962u) return; }  // 0607B95E jsr @r1 ; mov r14,r4
    c.r[8] += 24;  // 0607B962 add #24,r8
    c.r[1] = ld32(0x0607B9E4u);  // 0607B964 mov.l 0x0607B9E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B96Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B96Au) return; }  // 0607B966 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0607B9E8u);  // 0607B96A mov.l 0x0607B9E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B970u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B970u) return; }  // 0607B96C jsr @r1 ; nop
    c.r[1] = ld32(0x0607B9ECu);  // 0607B970 mov.l 0x0607B9EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B976u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B976u) return; }  // 0607B972 jsr @r1 ; nop
    c.r[0] = ld32(c.r[9]);  // 0607B976 mov.l @r9,r0
    c.r[0] &= 0xCu;  // 0607B978 and #12,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B97A tst r0,r0
    if (c.t) { goto L_0607B994; }  // 0607B97C bt 0x0607B994
    c.r[1] = ld32(0x0607B9F0u);  // 0607B97E mov.l 0x0607B9F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607B980 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607B982 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607B984 tst r1,r1
    if (!c.t) { goto L_0607B98E; }  // 0607B986 bf 0x0607B98E
    c.r[1] = ld32(0x0607B9F4u);  // 0607B988 mov.l 0x0607B9F4,r1
    goto L_0607B990;  // 0607B98A bra 0x0607B990 ; nop
L_0607B98E:
    c.r[1] = ld32(0x0607B9F8u);  // 0607B98E mov.l 0x0607B9F8,r1
L_0607B990:
    { const uint32_t x = c.r[1]; c.pr = 0x0607B994u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B994u) return; }  // 0607B990 jsr @r1 ; nop
L_0607B994:
    c.r[1] = ld32(0x0607B9FCu);  // 0607B994 mov.l 0x0607B9FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B99Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B99Au) return; }  // 0607B996 jsr @r1 ; nop
    c.r[1] = ld32(0x0607B9C0u);  // 0607B99A mov.l 0x0607B9C0,r1
    c.r[0] = ld32(c.r[1]);  // 0607B99C mov.l @r1,r0
    c.r[0] &= 0x40u;  // 0607B99E and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607B9A0 tst r0,r0
    if (c.t) { goto L_0607B9AA; }  // 0607B9A2 bt 0x0607B9AA
    c.r[1] = ld32(0x0607BA00u);  // 0607B9A4 mov.l 0x0607BA00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607B9AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607B9AAu) return; }  // 0607B9A6 jsr @r1 ; nop
L_0607B9AA:
    c.r[14] += 12;  // 0607B9AA add #12,r14
    c.r[15] = c.r[14];  // 0607B9AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607B9AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607B9B0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607B9B2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607B9B4 rts ; mov.l @r15+,r8
}

void f_0607BA04(SH2Context& c) {
    ran[1711] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607BA04 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607BA06 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607BA08 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607BA0A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607BA0C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607BA0E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607BA10 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607BA12 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607BA14 mov r15,r14
    c.r[8] = ld32(0x0607BA94u);  // 0607BA16 mov.l 0x0607BA94,r8
    c.r[11] = ld32(0x0607BA98u);  // 0607BA18 mov.l 0x0607BA98,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0607BA1Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA1Eu) return; }  // 0607BA1A jsr @r11 ; mov r8,r4
    c.r[9] = c.r[8];  // 0607BA1E mov r8,r9
    c.r[9] += 58;  // 0607BA20 add #58,r9
    c.r[10] = ld32(0x0607BA9Cu);  // 0607BA22 mov.l 0x0607BA9C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0607BA28u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA28u) return; }  // 0607BA24 jsr @r10 ; mov.w @r9,r4
    c.r[2] = ld32(0x0607BAA0u);  // 0607BA28 mov.l 0x0607BAA0,r2
    c.r[6] = ld32(c.r[2]);  // 0607BA2A mov.l @r2,r6
    c.r[2] = ld32(0x0607BAA4u);  // 0607BA2C mov.l 0x0607BAA4,r2
    c.r[5] = ld32(c.r[2]);  // 0607BA2E mov.l @r2,r5
    c.r[2] = ld32(0x0607BAA8u);  // 0607BA30 mov.l 0x0607BAA8,r2
    c.r[4] = ld32(c.r[2]);  // 0607BA32 mov.l @r2,r4
    c.r[2] = ld32(0x0607BAACu);  // 0607BA34 mov.l 0x0607BAAC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0607BA3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA3Au) return; }  // 0607BA36 jsr @r2 ; nop
    c.r[12] = ld32(0x0607BAB0u);  // 0607BA3A mov.l 0x0607BAB0,r12
    c.r[13] = ld32(0x0607BAB4u);  // 0607BA3C mov.l 0x0607BAB4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0607BA42u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA42u) return; }  // 0607BA3E jsr @r13 ; mov r12,r4
    c.r[1] = ld32(0x0607BAB8u);  // 0607BA42 mov.l 0x0607BAB8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BA44 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0607BA46 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0607BA48 tst r1,r1
    if (!c.t) { goto L_0607BA7C; }  // 0607BA4A bf 0x0607BA7C
    { const uint32_t x = c.r[11]; c.pr = 0x0607BA50u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA50u) return; }  // 0607BA4C jsr @r11 ; mov r8,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0607BA54u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA54u) return; }  // 0607BA50 jsr @r10 ; mov.w @r9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607BA90u);  // 0607BA54 mov.w 0x0607BA90,r4
    c.r[1] = ld32(0x0607BABCu);  // 0607BA56 mov.l 0x0607BABC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BA5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA5Cu) return; }  // 0607BA58 jsr @r1 ; nop
    c.r[4] = ld32(0x0607BAC0u);  // 0607BA5C mov.l 0x0607BAC0,r4
    c.r[1] = ld32(0x0607BAC4u);  // 0607BA5E mov.l 0x0607BAC4,r1
    c.r[6] = 0x0u;  // 0607BA60 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607BA66u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA66u) return; }  // 0607BA62 jsr @r1 ; mov #0,r5
    c.r[2] = ld32(0x0607BAA0u);  // 0607BA66 mov.l 0x0607BAA0,r2
    c.r[6] = ld32(c.r[2]);  // 0607BA68 mov.l @r2,r6
    c.r[2] = ld32(0x0607BAA4u);  // 0607BA6A mov.l 0x0607BAA4,r2
    c.r[5] = ld32(c.r[2]);  // 0607BA6C mov.l @r2,r5
    c.r[2] = ld32(0x0607BAA8u);  // 0607BA6E mov.l 0x0607BAA8,r2
    c.r[4] = ld32(c.r[2]);  // 0607BA70 mov.l @r2,r4
    c.r[2] = ld32(0x0607BAACu);  // 0607BA72 mov.l 0x0607BAAC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0607BA78u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA78u) return; }  // 0607BA74 jsr @r2 ; nop
    { const uint32_t x = c.r[13]; c.pr = 0x0607BA7Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BA7Cu) return; }  // 0607BA78 jsr @r13 ; mov r12,r4
L_0607BA7C:
    c.r[15] = c.r[14];  // 0607BA7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607BA7E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607BA80 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607BA82 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607BA84 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607BA86 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607BA88 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607BA8A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607BA8C rts ; mov.l @r15+,r8
}

void f_0607BAC8(SH2Context& c) {
    ran[1712] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607BAC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607BACA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607BACC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607BACE mov r15,r14
    c.r[8] = c.r[4];  // 0607BAD0 mov r4,r8
    c.r[1] = ld32(0x0607BB24u);  // 0607BAD2 mov.l 0x0607BB24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BAD8u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BAD8u) return; }  // 0607BAD4 jsr @r1 ; extu.b r8,r8
    c.r[1] = ld32(0x0607BB28u);  // 0607BAD8 mov.l 0x0607BB28,r1
    st8(c.r[1], c.r[8]);  // 0607BADA mov.b r8,@r1
    c.r[1] = ld32(0x0607BB2Cu);  // 0607BADC mov.l 0x0607BB2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BAE2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BAE2u) return; }  // 0607BADE jsr @r1 ; nop
    c.r[1] = ld32(0x0607BB30u);  // 0607BAE2 mov.l 0x0607BB30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BAE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BAE8u) return; }  // 0607BAE4 jsr @r1 ; nop
    c.r[5] = ld32(0x0607BB34u);  // 0607BAE8 mov.l 0x0607BB34,r5
    c.r[4] = ld32(0x0607BB38u);  // 0607BAEA mov.l 0x0607BB38,r4
    c.r[1] = ld32(0x0607BB3Cu);  // 0607BAEC mov.l 0x0607BB3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BAF2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BAF2u) return; }  // 0607BAEE jsr @r1 ; nop
    c.r[1] = ld32(0x0607BB40u);  // 0607BAF2 mov.l 0x0607BB40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BAF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BAF8u) return; }  // 0607BAF4 jsr @r1 ; nop
    c.r[1] = ld32(0x0607BB44u);  // 0607BAF8 mov.l 0x0607BB44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BAFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BAFEu) return; }  // 0607BAFA jsr @r1 ; nop
    c.r[3] = ld32(0x0607BB48u);  // 0607BAFE mov.l 0x0607BB48,r3
    c.r[2] = ld32(0x0607BB4Cu);  // 0607BB00 mov.l 0x0607BB4C,r2
    c.r[1] = 0x0u;  // 0607BB02 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0607BB04 mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 0607BB06 mov.l r1,@r3
    c.r[2] = ld32(0x0607BB50u);  // 0607BB08 mov.l 0x0607BB50,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607BB22u);  // 0607BB0A mov.w 0x0607BB22,r1
    st32(c.r[2] + 20, c.r[1]);  // 0607BB0C mov.l r1,@(20,r2)
    c.r[1] = ld32(0x0607BB54u);  // 0607BB0E mov.l 0x0607BB54,r1
    c.r[2] = 0x4u;  // 0607BB10 mov #4,r2
    st32(c.r[1] + 32, c.r[2]);  // 0607BB12 mov.l r2,@(32,r1)
    c.r[1] = ld32(0x0607BB58u);  // 0607BB14 mov.l 0x0607BB58,r1
    st32(c.r[1] + 16, c.r[2]);  // 0607BB16 mov.l r2,@(16,r1)
    c.r[15] = c.r[14];  // 0607BB18 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607BB1A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607BB1C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607BB1E rts ; mov.l @r15+,r8
}

void f_0607BB5C(SH2Context& c) {
    ran[1713] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607BB5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607BB5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607BB60 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607BB62 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607BB64 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607BB66 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607BB68 sts.l pr,@-r15
    c.r[15] -= 16;  // 0607BB6A add #-16,r15
    c.r[14] = c.r[15];  // 0607BB6C mov r15,r14
    c.r[10] = ld32(0x0607BC50u);  // 0607BB6E mov.l 0x0607BC50,r10
    c.r[11] = ld32(0x0607BC54u);  // 0607BB70 mov.l 0x0607BC54,r11
    c.r[1] = ld32(0x0607BC58u);  // 0607BB72 mov.l 0x0607BC58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BB78u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BB78u) return; }  // 0607BB74 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607BC5Cu);  // 0607BB78 mov.l 0x0607BC5C,r1
    c.r[5] = 0x0u;  // 0607BB7A mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607BB80u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BB80u) return; }  // 0607BB7C jsr @r1 ; mov #0,r4
    c.r[6] = ld32(0x0607BC60u);  // 0607BB80 mov.l 0x0607BC60,r6
    c.r[9] = ld32(0x0607BC64u);  // 0607BB82 mov.l 0x0607BC64,r9
    c.r[1] = ld32(0x0607BC68u);  // 0607BB84 mov.l 0x0607BC68,r1
    c.r[5] = 0x0u;  // 0607BB86 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607BB8Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BB8Cu) return; }  // 0607BB88 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x0607BC6Cu);  // 0607BB8C mov.l 0x0607BC6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BB92u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BB92u) return; }  // 0607BB8E jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0607BC70u);  // 0607BB92 mov.l 0x0607BC70,r8
    c.r[1] = ld32(0x0607BC74u);  // 0607BB94 mov.l 0x0607BC74,r1
    c.r[7] = c.r[8];  // 0607BB96 mov r8,r7
    c.r[6] = c.r[8];  // 0607BB98 mov r8,r6
    c.r[5] = c.r[8];  // 0607BB9A mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607BBA0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BBA0u) return; }  // 0607BB9C jsr @r1 ; mov r8,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607BC4Au);  // 0607BBA0 mov.w 0x0607BC4A,r6
    c.r[4] = ld32(0x0607BC78u);  // 0607BBA2 mov.l 0x0607BC78,r4
    c.r[1] = 0x20u;  // 0607BBA4 mov #32,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607BBA6 mov.l r1,@-r15
    c.r[1] = ld32(0x0607BC7Cu);  // 0607BBA8 mov.l 0x0607BC7C,r1
    c.r[7] = 0x0u;  // 0607BBAA mov #0,r7
    { const uint32_t x = c.r[1]; c.pr = 0x0607BBB0u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BBB0u) return; }  // 0607BBAC jsr @r1 ; mov r9,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0607BC4Cu);  // 0607BBB0 mov.w 0x0607BC4C,r6
    c.r[0] = ld32(0x0607BC80u);  // 0607BBB2 mov.l 0x0607BC80,r0
    c.r[5] = 0x0u;  // 0607BBB4 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0607BBBAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BBBAu) return; }  // 0607BBB6 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x0607BC84u);  // 0607BBBA mov.l 0x0607BC84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BBC0u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BBC0u) return; }  // 0607BBBC jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x0607BC88u);  // 0607BBC0 mov.l 0x0607BC88,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607BC4Eu);  // 0607BBC2 mov.w 0x0607BC4E,r1
    st16(c.r[2], c.r[1]);  // 0607BBC4 mov.w r1,@r2
    c.r[1] = ld32(0x0607BC8Cu);  // 0607BBC6 mov.l 0x0607BC8C,r1
    c.r[5] = 0x0u;  // 0607BBC8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607BBCEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BBCEu) return; }  // 0607BBCA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0607BC90u);  // 0607BBCE mov.l 0x0607BC90,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BBD0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607BBD2 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607BBD4 tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0607BBE4; } }  // 0607BBD6 bf/s 0x0607BBE4 ; add #4,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607BBDA mov.l r11,@-r15
    c.r[0] = ld32(0x0607BC94u);  // 0607BBDC mov.l 0x0607BC94,r0
    c.r[7] = c.r[10];  // 0607BBDE mov r10,r7
    c.r[6] = 0x9u; goto L_0607BBF8;  // 0607BBE0 bra 0x0607BBF8 ; mov #9,r6
L_0607BBE4:
    c.t = c.r[0] == 0x1u;  // 0607BBE4 cmp/eq #1,r0
    { const bool k = !c.t; c.r[15] -= 4; st32(c.r[15], c.r[11]); if (k) { goto L_0607BBF2; } }  // 0607BBE6 bf/s 0x0607BBF2 ; mov.l r11,@-r15
    c.r[0] = ld32(0x0607BC94u);  // 0607BBEA mov.l 0x0607BC94,r0
    c.r[7] = c.r[10];  // 0607BBEC mov r10,r7
    c.r[6] = 0xBu; goto L_0607BBF8;  // 0607BBEE bra 0x0607BBF8 ; mov #11,r6
L_0607BBF2:
    c.r[0] = ld32(0x0607BC94u);  // 0607BBF2 mov.l 0x0607BC94,r0
    c.r[7] = c.r[10];  // 0607BBF4 mov r10,r7
    c.r[6] = 0x12u;  // 0607BBF6 mov #18,r6
L_0607BBF8:
    c.r[5] = 0x4u;  // 0607BBF8 mov #4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0607BBFEu; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BBFEu) return; }  // 0607BBFA jsr @r0 ; mov #16,r4
    c.r[15] += 4;  // 0607BBFE add #4,r15
    c.r[1] = c.r[11];  // 0607BC00 mov r11,r1
    c.r[1] += 11;  // 0607BC02 add #11,r1
    c.r[4] = ld32(c.r[11] + 4);  // 0607BC04 mov.l @(4,r11),r4
    c.r[5] = ld32(0x0607BC98u);  // 0607BC06 mov.l 0x0607BC98,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BC08 mov.b @r1,r7
    c.r[4] -= 4;  // 0607BC0A add #-4,r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0607BC0C shlr r4
    c.r[4] += c.r[4];  // 0607BC0E add r4,r4
    c.r[4] += c.r[11];  // 0607BC10 add r11,r4
    c.r[1] = c.r[11];  // 0607BC12 mov r11,r1
    c.r[1] += 10;  // 0607BC14 add #10,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BC16 mov.b @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0607BC18 extu.b r7,r7
    c.r[1] = 0x0u;  // 0607BC1A mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607BC1C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0607BC1E mov.l r1,@-r15
    c.r[1] = ld32(0x0607BC9Cu);  // 0607BC20 mov.l 0x0607BC9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BC26u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BC26u) return; }  // 0607BC22 jsr @r1 ; extu.b r6,r6
    c.r[1] = ld32(0x0607BC90u);  // 0607BC26 mov.l 0x0607BC90,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BC28 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0607BC2A extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607BC2C tst r0,r0
    { const bool k = !c.t; c.r[15] += 8; if (k) { goto L_0607BC3C; } }  // 0607BC2E bf/s 0x0607BC3C ; add #8,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607BC32 mov.l r11,@-r15
    c.r[0] = ld32(0x0607BC94u);  // 0607BC34 mov.l 0x0607BC94,r0
    c.r[7] = c.r[10];  // 0607BC36 mov r10,r7
    c.r[6] = 0x8u; goto L_0607BCA6;  // 0607BC38 bra 0x0607BCA6 ; mov #8,r6
L_0607BC3C:
    c.t = c.r[0] == 0x1u;  // 0607BC3C cmp/eq #1,r0
    { const bool k = !c.t; c.r[15] -= 4; st32(c.r[15], c.r[11]); if (k) { goto L_0607BCA0; } }  // 0607BC3E bf/s 0x0607BCA0 ; mov.l r11,@-r15
    c.r[0] = ld32(0x0607BC94u);  // 0607BC42 mov.l 0x0607BC94,r0
    c.r[7] = c.r[10];  // 0607BC44 mov r10,r7
    c.r[6] = 0xAu; goto L_0607BCA6;  // 0607BC46 bra 0x0607BCA6 ; mov #10,r6
L_0607BCA0:
    c.r[0] = ld32(0x0607BDD8u);  // 0607BCA0 mov.l 0x0607BDD8,r0
    c.r[7] = c.r[10];  // 0607BCA2 mov r10,r7
    c.r[6] = 0x11u;  // 0607BCA4 mov #17,r6
L_0607BCA6:
    c.r[5] = 0x4u;  // 0607BCA6 mov #4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0607BCACu; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BCACu) return; }  // 0607BCA8 jsr @r0 ; mov #16,r4
    c.r[15] += 4;  // 0607BCAC add #4,r15
    c.r[0] = c.r[11];  // 0607BCAE mov r11,r0
    c.r[10] = c.r[14];  // 0607BCB0 mov r14,r10
    c.r[10] += 2;  // 0607BCB2 add #2,r10
    c.r[12] = 0x2u;  // 0607BCB4 mov #2,r12
    c.r[5] = ld32(0x0607BDDCu);  // 0607BCB6 mov.l 0x0607BDDC,r5
    c.r[9] = ld32(0x0607BDE0u);  // 0607BCB8 mov.l 0x0607BDE0,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0]); c.r[0] += 2;  // 0607BCBA mov.w @r0+,r8
    c.r[7] = 0xEu;  // 0607BCBC mov #14,r7
    st16(c.r[14], c.r[8]);  // 0607BCBE mov.w r8,@r14
    c.r[8] = c.r[8] & 0xFFFFu;  // 0607BCC0 extu.w r8,r8
    c.r[8] += c.r[8];  // 0607BCC2 add r8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0607BCC4 mov.w @r0,r1
    c.r[6] = c.r[8];  // 0607BCC6 mov r8,r6
    st16(c.r[10], c.r[1]);  // 0607BCC8 mov.w r1,@r10
    c.r[0] = c.r[11];  // 0607BCCA mov r11,r0
    c.r[0] |= 0x4u;  // 0607BCCC or #4,r0
    st32(c.r[14] + 4, c.r[0]);  // 0607BCCE mov.l r0,@(4,r14)
    c.r[11] = ld32(0x0607BDE4u);  // 0607BCD0 mov.l 0x0607BDE4,r11
    c.r[1] = 0x1u;  // 0607BCD2 mov #1,r1
    st8(c.r[11], c.r[1]);  // 0607BCD4 mov.b r1,@r11
    { const uint32_t x = c.r[9]; c.pr = 0x0607BCDAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BCDAu) return; }  // 0607BCD6 jsr @r9 ; mov r0,r4
    c.r[2] = 0x20u;  // 0607BCDA mov #32,r2
    c.r[4] = ld32(c.r[14] + 4);  // 0607BCDC mov.l @(4,r14),r4
    c.r[7] = 0xEu;  // 0607BCDE mov #14,r7
    c.r[4] += c.r[8];  // 0607BCE0 add r8,r4
    st32(c.r[14] + 8, c.r[4]);  // 0607BCE2 mov.l r4,@(8,r14)
    c.r[8] = ld32(0x0607BDE8u);  // 0607BCE4 mov.l 0x0607BDE8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0607BCE6 mov.w @r10,r1
    c.r[5] = c.r[8];  // 0607BCE8 mov r8,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607BCEA extu.w r1,r1
    c.macl = c.r[1] * c.r[2];  // 0607BCEC mul.l r2,r1
    c.r[4] += c.r[1];  // 0607BCEE add r1,r4
    st32(c.r[14] + 12, c.r[4]);  // 0607BCF0 mov.l r4,@(12,r14)
    { const uint32_t x = c.r[9]; c.pr = 0x0607BCF6u; c.r[6] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BCF6u) return; }  // 0607BCF2 jsr @r9 ; sts macl,r6
    c.r[1] = ld32(0x0607BDECu);  // 0607BCF6 mov.l 0x0607BDEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BCFCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BCFCu) return; }  // 0607BCF8 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0607BCFC mov #0,r1
    st8(c.r[11], c.r[1]);  // 0607BCFE mov.b r1,@r11
    c.r[1] = ld32(0x0607BDF0u);  // 0607BD00 mov.l 0x0607BDF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD06u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD06u) return; }  // 0607BD02 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607BDF4u);  // 0607BD06 mov.l 0x0607BDF4,r1
    c.r[5] = 0x0u;  // 0607BD08 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD0Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD0Eu) return; }  // 0607BD0A jsr @r1 ; mov #0,r4
    c.r[6] = ld32(0x0607BDF8u);  // 0607BD0E mov.l 0x0607BDF8,r6
    c.r[1] = ld32(0x0607BDFCu);  // 0607BD10 mov.l 0x0607BDFC,r1
    c.r[5] = 0x0u;  // 0607BD12 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD18u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD18u) return; }  // 0607BD14 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0607BE00u);  // 0607BD18 mov.l 0x0607BE00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD1Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD1Eu) return; }  // 0607BD1A jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x0607BE04u);  // 0607BD1E mov.l 0x0607BE04,r4
    c.r[1] = ld32(0x0607BE08u);  // 0607BD20 mov.l 0x0607BE08,r1
    c.r[7] = c.r[4];  // 0607BD22 mov r4,r7
    c.r[6] = c.r[4];  // 0607BD24 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD2Au; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD2Au) return; }  // 0607BD26 jsr @r1 ; mov r4,r5
    c.r[4] = ld32(0x0607BE0Cu);  // 0607BD2A mov.l 0x0607BE0C,r4
    c.r[1] = ld32(0x0607BE10u);  // 0607BD2C mov.l 0x0607BE10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD32u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD32u) return; }  // 0607BD2E jsr @r1 ; mov r4,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0607BDD4u);  // 0607BD32 mov.w 0x0607BDD4,r4
    c.r[1] = ld32(0x0607BE14u);  // 0607BD34 mov.l 0x0607BE14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD3Au) return; }  // 0607BD36 jsr @r1 ; nop
    c.r[1] = ld32(0x0607BE18u);  // 0607BD3A mov.l 0x0607BE18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD40u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD40u) return; }  // 0607BD3C jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x0607BE1Cu);  // 0607BD40 mov.l 0x0607BE1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD46u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD46u) return; }  // 0607BD42 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0607BE20u);  // 0607BD46 mov.l 0x0607BE20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD4Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD4Cu) return; }  // 0607BD48 jsr @r1 ; mov r12,r4
    c.r[1] = ld32(0x0607BE24u);  // 0607BD4C mov.l 0x0607BE24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BD4E mov.b @r1,r1
    c.r[2] = 0x1u;  // 0607BD50 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0607BD52 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0607BD54 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0607BD60; } }  // 0607BD56 bt/s 0x0607BD60 ; mov #0,r1
    c.r[2] = ld32(0x0607BE28u);  // 0607BD5A mov.l 0x0607BE28,r2
    c.r[1] = 0xFFFFFFBCu; goto L_0607BD62;  // 0607BD5C bra 0x0607BD62 ; mov #-68,r1
L_0607BD60:
    c.r[2] = ld32(0x0607BE28u);  // 0607BD60 mov.l 0x0607BE28,r2
L_0607BD62:
    st16(c.r[2], c.r[1]);  // 0607BD62 mov.w r1,@r2
    c.r[1] = ld32(0x0607BE28u);  // 0607BD64 mov.l 0x0607BE28,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607BD66 mov.w @r1,r4
    c.r[1] = ld32(0x0607BE2Cu);  // 0607BD68 mov.l 0x0607BE2C,r1
    c.r[6] = c.r[4];  // 0607BD6A mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0607BD70u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD70u) return; }  // 0607BD6C jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x0607BE24u);  // 0607BD70 mov.l 0x0607BE24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607BD72 mov.b @r1,r1
    c.r[9] = 0x1u;  // 0607BD74 mov #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0607BD76 extu.b r1,r1
    c.t = c.r[1] > c.r[9];  // 0607BD78 cmp/hi r9,r1
    { const bool k = c.t; c.r[5] = 0x2u; if (k) { goto L_0607BD8E; } }  // 0607BD7A bt/s 0x0607BD8E ; mov #2,r5
    c.r[8] = ld32(0x0607BE30u);  // 0607BD7E mov.l 0x0607BE30,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0607BD84u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD84u) return; }  // 0607BD80 jsr @r8 ; mov #2,r4
    c.r[5] = 0x7u;  // 0607BD84 mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607BD8Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD8Au) return; }  // 0607BD86 jsr @r8 ; mov r9,r4
    c.r[5] = c.r[9]; goto L_0607BD9E;  // 0607BD8A bra 0x0607BD9E ; mov r9,r5
L_0607BD8E:
    c.r[8] = ld32(0x0607BE30u);  // 0607BD8E mov.l 0x0607BE30,r8
    c.r[5] = c.r[9];  // 0607BD90 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607BD96u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD96u) return; }  // 0607BD92 jsr @r8 ; mov #2,r4
    c.r[5] = 0x7u;  // 0607BD96 mov #7,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607BD9Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BD9Cu) return; }  // 0607BD98 jsr @r8 ; mov r9,r4
    c.r[5] = 0x2u;  // 0607BD9C mov #2,r5
L_0607BD9E:
    { const uint32_t x = c.r[8]; c.pr = 0x0607BDA2u; c.r[4] = 0xFFFFFFF9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BDA2u) return; }  // 0607BD9E jsr @r8 ; mov #-7,r4
    c.r[8] = ld32(0x0607BE30u);  // 0607BDA2 mov.l 0x0607BE30,r8
    c.r[5] = 0x4u;  // 0607BDA4 mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607BDAAu; c.r[4] = 0xFFFFFFF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BDAAu) return; }  // 0607BDA6 jsr @r8 ; mov #-8,r4
    c.r[5] = 0x5u;  // 0607BDAA mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0607BDB0u; c.r[4] = 0xFFFFFFFBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BDB0u) return; }  // 0607BDAC jsr @r8 ; mov #-5,r4
    c.r[4] = ld32(0x0607BE34u);  // 0607BDB0 mov.l 0x0607BE34,r4
    c.r[0] = ld32(0x0607BE38u);  // 0607BDB2 mov.l 0x0607BE38,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0607BDB8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BDB8u) return; }  // 0607BDB4 jsr @r0 ; nop
    c.r[4] = ld32(0x0607BE3Cu);  // 0607BDB8 mov.l 0x0607BE3C,r4
    c.r[1] = ld32(0x0607BE40u);  // 0607BDBA mov.l 0x0607BE40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BDC0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BDC0u) return; }  // 0607BDBC jsr @r1 ; nop
    c.r[14] += 16;  // 0607BDC0 add #16,r14
    c.r[15] = c.r[14];  // 0607BDC2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607BDC4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607BDC6 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607BDC8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607BDCA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607BDCC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607BDCE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607BDD0 rts ; mov.l @r15+,r8
}

void f_0607BE44(SH2Context& c) {
    ran[1714] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607BE44 mov.l r14,@-r15
    c.r[3] = ld32(0x0607BE94u);  // 0607BE46 mov.l 0x0607BE94,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607BE8Au);  // 0607BE48 mov.w 0x0607BE8A,r0
    c.r[6] = ld32(0x0607BE98u);  // 0607BE4A mov.l 0x0607BE98,r6
    c.r[7] = c.r[6];  // 0607BE4C mov r6,r7
    c.r[1] = ld32(0x0607BE9Cu);  // 0607BE4E mov.l 0x0607BE9C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607BE50 mov.w @r1,r2
    c.r[7] += 88;  // 0607BE52 add #88,r7
    c.r[2] += 13;  // 0607BE54 add #13,r2
    st16(c.r[7], c.r[2]);  // 0607BE56 mov.w r2,@r7
    st16(c.r[0] + c.r[3], c.r[2]);  // 0607BE58 mov.w r2,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607BE8Cu);  // 0607BE5A mov.w 0x0607BE8C,r0
    st16(c.r[0] + c.r[3], c.r[2]);  // 0607BE5C mov.w r2,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607BE8Eu);  // 0607BE5E mov.w 0x0607BE8E,r0
    c.r[1] = 0x18u;  // 0607BE60 mov #24,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0607BE62 mov.w r1,@(r0,r3)
    c.r[1] = 0xCu;  // 0607BE64 mov #12,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0607BE66 mulu.w r1,r2
    c.r[3] = ld32(c.r[6] + 12);  // 0607BE68 mov.l @(12,r6),r3
    c.r[1] = c.macl;  // 0607BE6A sts macl,r1
    c.r[3] += c.r[1];  // 0607BE6C add r1,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 0607BE6E extu.w r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607BE90u);  // 0607BE70 mov.w 0x0607BE90,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607BE72 cmp/gt r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0607BE84; } }  // 0607BE74 bt/s 0x0607BE84 ; mov r15,r14
    c.r[7] = ld32(0x0607BEA0u);  // 0607BE78 mov.l 0x0607BEA0,r7
L_0607BE7A:
    st32(c.r[3] + 8, c.r[7]);  // 0607BE7A mov.l r7,@(8,r3)
    c.r[2] += 1;  // 0607BE7C add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0607BE7E cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] += 12; if (k) { SH2_POLL(c); goto L_0607BE7A; } }  // 0607BE80 bf/s 0x0607BE7A ; add #12,r3
L_0607BE84:
    c.r[15] = c.r[14];  // 0607BE84 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607BE86 rts ; mov.l @r15+,r14
}

void f_0607BEA4(SH2Context& c) {
    ran[1715] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607BEA4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0607BEA6 mov r15,r14
    c.r[1] = ld32(0x0607BEC4u);  // 0607BEA8 mov.l 0x0607BEC4,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0607BEAA mov.l @(12,r1),r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0607BEC2u);  // 0607BEAC mov.w 0x0607BEC2,r7
    c.r[3] = ld32(0x0607BEC8u);  // 0607BEAE mov.l 0x0607BEC8,r3
    c.r[1] = 0x0u;  // 0607BEB0 mov #0,r1
L_0607BEB2:
    st32(c.r[2] + 8, c.r[3]);  // 0607BEB2 mov.l r3,@(8,r2)
    c.r[1] += 1;  // 0607BEB4 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0607BEB6 cmp/gt r7,r1
    { const bool k = !c.t; c.r[2] += 12; if (k) { SH2_POLL(c); goto L_0607BEB2; } }  // 0607BEB8 bf/s 0x0607BEB2 ; add #12,r2
    c.r[15] = c.r[14];  // 0607BEBC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607BEBE rts ; mov.l @r15+,r14
}

void f_0607BECC(SH2Context& c) {
    ran[1716] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607BECC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607BECE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607BED0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607BED2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0607BED4 mov r15,r14
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 0607BED6 exts.w r5,r5
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0607BED8 exts.w r6,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0607BEDA extu.b r7,r7
    c.r[4] = 0u - c.r[4];  // 0607BEDC neg r4,r4
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 0607BEDE exts.w r4,r9
    c.r[1] = ld32(0x0607BFF8u);  // 0607BEE0 mov.l 0x0607BFF8,r1
    c.r[8] = ld32(0x0607BFFCu);  // 0607BEE2 mov.l 0x0607BFFC,r8
    c.r[2] = ld32(0x0607C000u);  // 0607BEE4 mov.l 0x0607C000,r2
    c.r[3] = c.r[8];  // 0607BEE6 mov r8,r3
    c.r[0] = ld32(c.r[1]);  // 0607BEE8 mov.l @r1,r0
    c.r[3] += 2;  // 0607BEEA add #2,r3
    c.r[0] |= 0x1u;  // 0607BEEC or #1,r0
    st32(c.r[1], c.r[0]);  // 0607BEEE mov.l r0,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0607BEF0 mov #-1,r1
    st32(c.r[8] + 12, c.r[1]);  // 0607BEF2 mov.l r1,@(12,r8)
    c.r[1] = c.r[2];  // 0607BEF4 mov r2,r1
    c.r[1] += 76;  // 0607BEF6 add #76,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607BEF8 mov.w @r1,r0
    c.t = (c.r[7] & c.r[7]) == 0;  // 0607BEFA tst r7,r7
    st16(c.r[8], c.r[0]);  // 0607BEFC mov.w r0,@r8
    c.r[1] = c.r[2];  // 0607BEFE mov r2,r1
    c.r[1] += 78;  // 0607BF00 add #78,r1
    c.r[2] += 80;  // 0607BF02 add #80,r2
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607BF04 mov.w @r1,r4
    c.r[9] -= c.r[0];  // 0607BF06 sub r0,r9
    st16(c.r[3], c.r[4]);  // 0607BF08 mov.w r4,@r3
    c.r[1] = c.r[8];  // 0607BF0A mov r8,r1
    c.r[1] += 4;  // 0607BF0C add #4,r1
    c.r[3] = c.r[8];  // 0607BF0E mov r8,r3
    c.r[3] += 6;  // 0607BF10 add #6,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607BF12 mov.w @r2,r2
    c.r[5] -= c.r[4];  // 0607BF14 sub r4,r5
    st16(c.r[1], c.r[2]);  // 0607BF16 mov.w r2,@r1
    st16(c.r[3], c.r[9]);  // 0607BF18 mov.w r9,@r3
    c.r[1] = c.r[8];  // 0607BF1A mov r8,r1
    c.r[1] += 8;  // 0607BF1C add #8,r1
    st16(c.r[1], c.r[5]);  // 0607BF1E mov.w r5,@r1
    c.r[1] = c.r[8];  // 0607BF20 mov r8,r1
    c.r[1] += 10;  // 0607BF22 add #10,r1
    c.r[6] -= c.r[2];  // 0607BF24 sub r2,r6
    { const bool k = c.t; st16(c.r[1], c.r[6]); if (k) { goto L_0607BF30; } }  // 0607BF26 bt/s 0x0607BF30 ; mov.w r6,@r1
    c.r[1] = 0x0u;  // 0607BF2A mov #0,r1
    st32(c.r[8] + 16, c.r[1]); goto L_0607BFE4;  // 0607BF2C bra 0x0607BFE4 ; mov.l r1,@(16,r8)
L_0607BF30:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0607BF30 exts.w r9,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607BF32 cmp/pz r1
    if (!c.t) { goto L_0607BF3C; }  // 0607BF34 bf 0x0607BF3C
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607BF36 mov.w @r3,r6
    goto L_0607BF40;  // 0607BF38 bra 0x0607BF40 ; nop
L_0607BF3C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607BF3C mov.w @r3,r1
    c.r[6] = 0u - c.r[1];  // 0607BF3E neg r1,r6
L_0607BF40:
    c.r[2] = ld32(0x0607C004u);  // 0607BF40 mov.l 0x0607C004,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607BF42 mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607BF44 cmp/pz r1
    { const bool k = c.t; c.t = c.r[6] >= c.r[1]; if (k) { goto L_0607BF4E; } }  // 0607BF46 bt/s 0x0607BF4E ; cmp/hs r1,r6
    c.r[1] = 0u - c.r[1];  // 0607BF4A neg r1,r1
    c.t = c.r[6] >= c.r[1];  // 0607BF4C cmp/hs r1,r6
L_0607BF4E:
    if (c.t) { goto L_0607BF52; }  // 0607BF4E bt 0x0607BF52
    c.r[6] = c.r[1];  // 0607BF50 mov r1,r6
L_0607BF52:
    c.r[2] = ld32(0x0607C008u);  // 0607BF52 mov.l 0x0607C008,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607BF54 mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0607BF56 cmp/pz r1
    { const bool k = c.t; c.t = c.r[6] >= c.r[1]; if (k) { goto L_0607BF60; } }  // 0607BF58 bt/s 0x0607BF60 ; cmp/hs r1,r6
    c.r[1] = 0u - c.r[1];  // 0607BF5C neg r1,r1
    c.t = c.r[6] >= c.r[1];  // 0607BF5E cmp/hs r1,r6
L_0607BF60:
    if (c.t) { goto L_0607BF64; }  // 0607BF60 bt 0x0607BF64
    c.r[6] = c.r[1];  // 0607BF62 mov r1,r6
L_0607BF64:
    c.r[1] = ld32(0x0607BFF8u);  // 0607BF64 mov.l 0x0607BFF8,r1
    c.r[0] = ld32(c.r[1]);  // 0607BF66 mov.l @r1,r0
    c.r[0] &= 0x80u;  // 0607BF68 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607BF6A tst r0,r0
    { const bool k = c.t; c.r[4] = c.r[6]; if (k) { goto L_0607BF7A; } }  // 0607BF6C bt/s 0x0607BF7A ; mov r6,r4
    c.r[2] = ld32(0x0607C00Cu);  // 0607BF70 mov.l 0x0607C00C,r2
    c.r[2] = ld32(c.r[2]);  // 0607BF72 mov.l @r2,r2
    c.r[1] = ld32(0x0607BFFCu);  // 0607BF74 mov.l 0x0607BFFC,r1
    st32(c.r[1] + 16, c.r[2]); goto L_0607BF88;  // 0607BF76 bra 0x0607BF88 ; mov.l r2,@(16,r1)
L_0607BF7A:
    c.r[2] = ld32(0x0607BFFCu);  // 0607BF7A mov.l 0x0607BFFC,r2
    c.r[4] <<= 2;  // 0607BF7C shll2 r4
    c.r[1] = ld32(0x0607C010u);  // 0607BF7E mov.l 0x0607C010,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BF84u; c.r[5] = ld32(c.r[2] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BF84u) return; }  // 0607BF80 jsr @r1 ; mov.l @(20,r2),r5
    c.r[0] >>= 2;  // 0607BF84 shlr2 r0
    st32(c.r[2] + 16, c.r[0]);  // 0607BF86 mov.l r0,@(16,r2)
L_0607BF88:
    c.r[2] = ld32(0x0607BFF8u);  // 0607BF88 mov.l 0x0607BFF8,r2
    c.r[1] = 0xFFFFFFF7u;  // 0607BF8A mov #-9,r1
    c.r[0] = ld32(c.r[2]);  // 0607BF8C mov.l @r2,r0
    c.r[3] = ld32(0x0607BFFCu);  // 0607BF8E mov.l 0x0607BFFC,r3
    c.r[0] &= c.r[1];  // 0607BF90 and r1,r0
    c.r[0] |= 0x4u;  // 0607BF92 or #4,r0
    st32(c.r[2], c.r[0]);  // 0607BF94 mov.l r0,@r2
    c.r[2] = c.r[3];  // 0607BF96 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]); c.r[2] += 2;  // 0607BF98 mov.w @r2+,r1
    c.r[7] = ld32(0x0607C014u);  // 0607BF9A mov.l 0x0607C014,r7
    c.r[1] = 0u - c.r[1];  // 0607BF9C neg r1,r1
    st32(c.r[7], c.r[1]);  // 0607BF9E mov.l r1,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607BFA0 mov.w @r2,r1
    st32(c.r[7] + 4, c.r[1]);  // 0607BFA2 mov.l r1,@(4,r7)
    c.r[1] = c.r[3];  // 0607BFA4 mov r3,r1
    c.r[1] += 6;  // 0607BFA6 add #6,r1
    c.r[2] = c.r[6];  // 0607BFA8 mov r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607BFAA mov.w @r1,r1
    c.r[2] <<= 2;  // 0607BFAC shll2 r2
    c.r[1] = 0u - c.r[1];  // 0607BFAE neg r1,r1
    st32(c.r[7] + 8, c.r[1]);  // 0607BFB0 mov.l r1,@(8,r7)
    c.r[1] = c.r[3];  // 0607BFB2 mov r3,r1
    c.r[1] += 8;  // 0607BFB4 add #8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607BFB6 mov.w @r1,r1
    c.r[2] >>= 8;  // 0607BFB8 shlr8 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0607BFBA shlr r2
    c.r[2] >>= 2;  // 0607BFBC shlr2 r2
    st32(c.r[7] + 12, c.r[1]);  // 0607BFBE mov.l r1,@(12,r7)
    c.r[1] = ld32(c.r[3] + 16);  // 0607BFC0 mov.l @(16,r3),r1
    c.r[6] = ld32(0x0607C000u);  // 0607BFC2 mov.l 0x0607C000,r6
    st32(c.r[7] + 16, c.r[1]);  // 0607BFC4 mov.l r1,@(16,r7)
    c.r[7] += 21;  // 0607BFC6 add #21,r7
    st8(c.r[7], c.r[2]);  // 0607BFC8 mov.b r2,@r7
    c.r[2] = c.r[2] & 0xFFu;  // 0607BFCA extu.b r2,r2
    c.r[1] = c.r[6];  // 0607BFCC mov r6,r1
    c.r[1] += 100;  // 0607BFCE add #100,r1
    c.r[1] = ld32(c.r[1]);  // 0607BFD0 mov.l @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0607BFF6u);  // 0607BFD2 mov.w 0x0607BFF6,r3
    c.r[3] -= c.r[1];  // 0607BFD4 sub r1,r3
    c.t = c.r[2] > c.r[3];  // 0607BFD6 cmp/hi r3,r2
    { const bool k = !c.t; c.r[6] += 103; if (k) { goto L_0607BFE4; } }  // 0607BFD8 bf/s 0x0607BFE4 ; add #103,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0607BFDC mov.b @r6,r2
    c.r[1] = 0xFFFFFFF0u;  // 0607BFDE mov #-16,r1
    c.r[1] -= c.r[2];  // 0607BFE0 sub r2,r1
    st8(c.r[7], c.r[1]);  // 0607BFE2 mov.b r1,@r7
L_0607BFE4:
    c.r[1] = ld32(0x0607C018u);  // 0607BFE4 mov.l 0x0607C018,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607BFEAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607BFEAu) return; }  // 0607BFE6 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0607BFEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607BFEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607BFEE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607BFF0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607BFF2 rts ; mov.l @r15+,r8
}

void f_0607C01C(SH2Context& c) {
    ran[1717] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607C01C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607C01E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607C020 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607C022 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607C024 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607C026 sts.l pr,@-r15
    c.r[15] -= 4;  // 0607C028 add #-4,r15
    c.r[9] = ld32(0x0607C134u);  // 0607C02A mov.l 0x0607C134,r9
    c.r[10] = ld32(c.r[9] + 12);  // 0607C02C mov.l @(12,r9),r10
    c.r[14] = c.r[15];  // 0607C02E mov r15,r14
    c.r[11] = ld32(c.r[9] + 16);  // 0607C030 mov.l @(16,r9),r11
    c.r[10] += 1;  // 0607C032 add #1,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[11];  // 0607C034 cmp/ge r11,r10
    { const bool k = c.t; st32(c.r[9] + 12, c.r[10]); if (k) { goto L_0607C096; } }  // 0607C036 bt/s 0x0607C096 ; mov.l r10,@(12,r9)
    c.r[0] = ld32(0x0607C138u);  // 0607C03A mov.l 0x0607C138,r0
    st32(c.r[14], c.r[0]);  // 0607C03C mov.l r0,@r14
    c.r[8] = c.r[0];  // 0607C03E mov r0,r8
    c.r[1] = c.r[9];  // 0607C040 mov r9,r1
    c.r[1] += 6;  // 0607C042 add #6,r1
    c.r[5] = c.r[11];  // 0607C044 mov r11,r5
    c.r[6] = ld32(0x0607C13Cu);  // 0607C046 mov.l 0x0607C13C,r6
    { const uint32_t x = c.r[6]; c.pr = 0x0607C04Cu; c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C04Cu) return; }  // 0607C048 jsr @r6 ; mov.w @r1,r4
    c.r[7] = c.r[0];  // 0607C04C mov r0,r7
    c.macl = c.r[7] * c.r[10];  // 0607C04E mul.l r10,r7
    c.r[8] += 76;  // 0607C050 add #76,r8
    c.r[7] = c.r[9];  // 0607C052 mov r9,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 0607C054 mov.w @r7+,r1
    c.r[2] = c.macl;  // 0607C056 sts macl,r2
    c.r[2] += c.r[1];  // 0607C058 add r1,r2
    st16(c.r[8], c.r[2]);  // 0607C05A mov.w r2,@r8
    c.r[1] = c.r[9];  // 0607C05C mov r9,r1
    c.r[8] = ld32(c.r[14]);  // 0607C05E mov.l @r14,r8
    c.r[1] += 8;  // 0607C060 add #8,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C062 mov.w @r1,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0607C068u; c.r[8] += 78; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C068u) return; }  // 0607C064 jsr @r6 ; add #78,r8
    c.r[5] = c.r[0];  // 0607C068 mov r0,r5
    c.r[0] = ld32(c.r[14]);  // 0607C06A mov.l @r14,r0
    c.macl = c.r[5] * c.r[10];  // 0607C06C mul.l r10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0607C06E mov.w @r7,r1
    c.r[0] += 80;  // 0607C070 add #80,r0
    st32(c.r[14], c.r[0]);  // 0607C072 mov.l r0,@r14
    c.r[7] = c.r[9];  // 0607C074 mov r9,r7
    c.r[7] += 4;  // 0607C076 add #4,r7
    c.r[9] += 10;  // 0607C078 add #10,r9
    c.r[2] = c.macl;  // 0607C07A sts macl,r2
    c.r[2] += c.r[1];  // 0607C07C add r1,r2
    st16(c.r[8], c.r[2]);  // 0607C07E mov.w r2,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0607C080 mov.w @r9,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0607C086u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C086u) return; }  // 0607C082 jsr @r6 ; mov r11,r5
    c.r[6] = c.r[0];  // 0607C086 mov r0,r6
    c.macl = c.r[6] * c.r[10];  // 0607C088 mul.l r10,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0607C08A mov.w @r7,r1
    c.r[0] = ld32(c.r[14]);  // 0607C08C mov.l @r14,r0
    c.r[2] = c.macl;  // 0607C08E sts macl,r2
    c.r[2] += c.r[1];  // 0607C090 add r1,r2
    st16(c.r[0], c.r[2]); goto L_0607C0F0;  // 0607C092 bra 0x0607C0F0 ; mov.w r2,@r0
L_0607C096:
    c.r[7] = ld32(0x0607C138u);  // 0607C096 mov.l 0x0607C138,r7
    c.r[6] = c.r[7];  // 0607C098 mov r7,r6
    c.r[2] = c.r[9];  // 0607C09A mov r9,r2
    c.r[3] = c.r[9];  // 0607C09C mov r9,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]); c.r[3] += 2;  // 0607C09E mov.w @r3+,r1
    c.r[2] += 6;  // 0607C0A0 add #6,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607C0A2 mov.w @r2,r2
    c.r[6] += 76;  // 0607C0A4 add #76,r6
    c.r[1] += c.r[2];  // 0607C0A6 add r2,r1
    st16(c.r[6], c.r[1]);  // 0607C0A8 mov.w r1,@r6
    c.r[6] = c.r[7];  // 0607C0AA mov r7,r6
    c.r[6] += 78;  // 0607C0AC add #78,r6
    c.r[2] = c.r[9];  // 0607C0AE mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607C0B0 mov.w @r3,r1
    c.r[2] += 8;  // 0607C0B2 add #8,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607C0B4 mov.w @r2,r2
    c.r[7] += 80;  // 0607C0B6 add #80,r7
    c.r[1] += c.r[2];  // 0607C0B8 add r2,r1
    st16(c.r[6], c.r[1]);  // 0607C0BA mov.w r1,@r6
    c.r[1] = c.r[9];  // 0607C0BC mov r9,r1
    c.r[1] += 4;  // 0607C0BE add #4,r1
    c.r[2] = c.r[9];  // 0607C0C0 mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C0C2 mov.w @r1,r1
    c.r[2] += 10;  // 0607C0C4 add #10,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0607C0C6 mov.w @r2,r2
    c.r[3] = ld32(0x0607C140u);  // 0607C0C8 mov.l 0x0607C140,r3
    c.r[1] += c.r[2];  // 0607C0CA add r2,r1
    st16(c.r[7], c.r[1]);  // 0607C0CC mov.w r1,@r7
    c.r[1] = 0x0u;  // 0607C0CE mov #0,r1
    st32(c.r[9] + 16, c.r[1]);  // 0607C0D0 mov.l r1,@(16,r9)
    st32(c.r[9] + 12, c.r[1]);  // 0607C0D2 mov.l r1,@(12,r9)
    c.r[2] = 0xFFFFFFFEu;  // 0607C0D4 mov #-2,r2
    c.r[0] = ld32(c.r[3]);  // 0607C0D6 mov.l @r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0607C130u);  // 0607C0D8 mov.w 0x0607C130,r1
    c.r[2] &= c.r[0];  // 0607C0DA and r0,r2
    c.r[2] &= c.r[1];  // 0607C0DC and r1,r2
    c.r[0] &= 0x4u;  // 0607C0DE and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607C0E0 tst r0,r0
    { const bool k = c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0607C0F0; } }  // 0607C0E2 bt/s 0x0607C0F0 ; mov.l r2,@r3
    c.r[1] = 0xFFFFFFFBu;  // 0607C0E6 mov #-5,r1
    c.r[2] &= c.r[1];  // 0607C0E8 and r1,r2
    c.r[0] = 0x8u;  // 0607C0EA mov #8,r0
    c.r[2] |= c.r[0];  // 0607C0EC or r0,r2
    st32(c.r[3], c.r[2]);  // 0607C0EE mov.l r2,@r3
L_0607C0F0:
    c.r[1] = ld32(0x0607C144u);  // 0607C0F0 mov.l 0x0607C144,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C0F6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C0F6u) return; }  // 0607C0F2 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x0607C148u);  // 0607C0F6 mov.l 0x0607C148,r8
    c.r[1] = ld32(0x0607C14Cu);  // 0607C0F8 mov.l 0x0607C14C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C0FEu; c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C0FEu) return; }  // 0607C0FA jsr @r1 ; mov.w @r8,r4
    c.r[1] = c.r[8];  // 0607C0FE mov r8,r1
    c.r[1] -= 2;  // 0607C100 add #-2,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0607C102 mov.w @r1,r4
    c.r[1] = ld32(0x0607C150u);  // 0607C104 mov.l 0x0607C150,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0607C10Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C10Au) return; }  // 0607C106 jsr @r1 ; nop
    c.r[1] = c.r[8];  // 0607C10A mov r8,r1
    c.r[1] -= 6;  // 0607C10C add #-6,r1
    c.r[0] = ld32(0x0607C154u);  // 0607C10E mov.l 0x0607C154,r0
    c.r[7] = c.r[8];  // 0607C110 mov r8,r7
    c.r[7] -= 78;  // 0607C112 add #-78,r7
    c.r[5] = 0x0u;  // 0607C114 mov #0,r5
    c.r[6] = ld32(c.r[1]);  // 0607C116 mov.l @r1,r6
    c.r[4] = 0x0u;  // 0607C118 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0607C11Eu; c.r[6] = 0u - c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607C11Eu) return; }  // 0607C11A jsr @r0 ; neg r6,r6
    c.r[14] += 4;  // 0607C11E add #4,r14
    c.r[15] = c.r[14];  // 0607C120 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607C122 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607C124 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607C126 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607C128 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607C12A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607C12C rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
