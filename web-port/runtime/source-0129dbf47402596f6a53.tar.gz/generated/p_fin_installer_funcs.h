#pragma once
#include "saturn/sh2.h"

namespace p_fin_installer {
void f_0028BFA4(SH2Context& c);
extern uint8_t ran[];
extern const SH2Module module;
}  // namespace p_fin_installer
