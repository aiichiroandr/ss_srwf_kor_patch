#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060B00B8(SH2Context& c) {
    ran[3029] = 1;
    goto L_060B00B8;
L_060B0006:
    c.mach = c.macl = 0;  // 060B0006 clrmac
L_060B0008:
    sh2_mac_l(c, 6, 7);  // 060B0008 mac.l @r7+,@r6+
L_060B000A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B000A mov.w @(8,r7),r0
L_060B000C:
    c.r[5] = c.r[15];  // 060B000C mov r15,r5
L_060B000E:
    sh2_mac_l(c, 6, 7);  // 060B000E mac.l @r7+,@r6+
L_060B0010:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0010 exts.w r0,r1
L_060B0012:
    c.r[1] <<= 2;  // 060B0012 shll2 r1
L_060B0014:
    sh2_mac_l(c, 6, 7);  // 060B0014 mac.l @r7+,@r6+
L_060B0016:
    c.r[6] += 4;  // 060B0016 add #4,r6
L_060B0018:
    c.r[7] -= 12;  // 060B0018 add #-12,r7
L_060B001A:
    c.r[1] <<= 2;  // 060B001A shll2 r1
L_060B001C:
    c.r[0] = c.mach;  // 060B001C sts mach,r0
L_060B001E:
    c.r[13] = c.macl;  // 060B001E sts macl,r13
L_060B0020:
    c.mach = c.macl = 0;  // 060B0020 clrmac
L_060B0022:
    sh2_mac_l(c, 6, 7);  // 060B0022 mac.l @r7+,@r6+
L_060B0024:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B0024 xtrct r0,r13
L_060B0026:
    st32(c.r[5], c.r[13]);  // 060B0026 mov.l r13,@(0,r5)
L_060B0028:
    sh2_mac_l(c, 6, 7);  // 060B0028 mac.l @r7+,@r6+
L_060B002A:
    c.r[1] += c.r[10];  // 060B002A add r10,r1
L_060B002C:
    c.r[4] = 0x4u;  // 060B002C mov #4,r4
L_060B002E:
    sh2_mac_l(c, 6, 7);  // 060B002E mac.l @r7+,@r6+
L_060B0030:
    c.r[6] += 4;  // 060B0030 add #4,r6
L_060B0032:
    c.r[7] -= 12;  // 060B0032 add #-12,r7
L_060B0034:
    c.r[4] += c.r[1];  // 060B0034 add r1,r4
L_060B0036:
    c.r[0] = c.mach;  // 060B0036 sts mach,r0
L_060B0038:
    c.r[2] = c.macl;  // 060B0038 sts macl,r2
L_060B003A:
    c.mach = c.macl = 0;  // 060B003A clrmac
L_060B003C:
    sh2_mac_l(c, 6, 7);  // 060B003C mac.l @r7+,@r6+
L_060B003E:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B003E xtrct r0,r2
L_060B0040:
    st32(c.r[5] + 4, c.r[2]);  // 060B0040 mov.l r2,@(4,r5)
L_060B0042:
    sh2_mac_l(c, 6, 7);  // 060B0042 mac.l @r7+,@r6+
L_060B0044:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B0044 mov.w @r8,r12
L_060B0046:
    c.r[9] = 0x7Fu;  // 060B0046 mov #127,r9
L_060B0048:
    sh2_mac_l(c, 6, 7);  // 060B0048 mac.l @r7+,@r6+
L_060B004A:
    c.r[6] -= 44;  // 060B004A add #-44,r6
L_060B004C:
    c.r[9] &= c.r[12];  // 060B004C and r12,r9
L_060B004E:
    c.r[9] <<= 2;  // 060B004E shll2 r9
L_060B0050:
    c.r[0] = c.mach;  // 060B0050 sts mach,r0
L_060B0052:
    c.r[3] = c.macl;  // 060B0052 sts macl,r3
L_060B0054:
    c.mach = c.macl = 0;  // 060B0054 clrmac
L_060B0056:
    sh2_mac_l(c, 5, 4);  // 060B0056 mac.l @r4+,@r5+
L_060B0058:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B0058 xtrct r0,r3
L_060B005A:
    c.r[0] = 0x060B0104u;  // 060B005A mova 0x060B0104,r0
L_060B005C:
    sh2_mac_l(c, 5, 4);  // 060B005C mac.l @r4+,@r5+
L_060B005E:
    st32(c.r[5], c.r[3]);  // 060B005E mov.l r3,@r5
L_060B0060:
    c.r[9] <<= 2;  // 060B0060 shll2 r9
L_060B0062:
    sh2_mac_l(c, 5, 4);  // 060B0062 mac.l @r4+,@r5+
L_060B0064:
    c.r[9] += c.r[0];  // 060B0064 add r0,r9
L_060B0066:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B0066 mov.w @(10,r8),r0
L_060B0068:
    c.r[7] += 2;  // 060B0068 add #2,r7
L_060B006A:
    c.r[4] = c.mach;  // 060B006A sts mach,r4
L_060B006C:
    st16(c.r[11], c.r[0]);  // 060B006C mov.w r0,@(0,r11)
L_060B006E:
    c.r[0] = ld32(c.gbr + 896);  // 060B006E mov.l @(896,gbr),r0
L_060B0070:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B0070 cmp/ge r0,r4
L_060B0072:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B007E; } }  // 060B0072 bt/s 0x060B007E ; swap.b r12,r0
L_060B0076:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B0076 mov.l @r9+,r4
L_060B0078:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0078 mov.w @r7+,r2
L_060B007A:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00B8u: goto L_060B00B8; case 0x060B00BAu: goto L_060B00BA; case 0x060B00BCu: goto L_060B00BC; case 0x060B00BEu: goto L_060B00BE; case 0x060B00C0u: goto L_060B00C0; case 0x060B00C2u: goto L_060B00C2; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B007A jmp @r4 ; shll2 r2
L_060B007E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B007E tst #1,r0
L_060B0080:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B0096; } }  // 060B0080 bt/s 0x060B0096 ; neg r3,r3
L_060B0084:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B0084 mov.l r3,@-r5
L_060B0086:
    c.r[2] = 0u - c.r[2];  // 060B0086 neg r2,r2
L_060B0088:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B0088 mov.l r2,@-r5
L_060B008A:
    c.r[13] = 0u - c.r[13];  // 060B008A neg r13,r13
L_060B008C:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B008C mov.l r13,@-r5
L_060B008E:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B008E mov.l @r9+,r4
L_060B0090:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0090 mov.w @r7+,r2
L_060B0092:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00B8u: goto L_060B00B8; case 0x060B00BAu: goto L_060B00BA; case 0x060B00BCu: goto L_060B00BC; case 0x060B00BEu: goto L_060B00BE; case 0x060B00C0u: goto L_060B00C0; case 0x060B00C2u: goto L_060B00C2; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B0092 jmp @r4 ; shll2 r2
L_060B0096:
    c.r[7] += 6; goto L_060B00C4;  // 060B0096 bra 0x060B00C4 ; add #6,r7
L_060B00B8:
    c.r[0] = c.r[14];  // 060B00B8 mov r14,r0
L_060B00BA:
    st16(c.r[11] + 30, c.r[0]);  // 060B00BA mov.w r0,@(30,r11)
L_060B00BC:
    c.r[0] = ld32(c.r[15] + 24);  // 060B00BC mov.l @(24,r15),r0
L_060B00BE:
    c.r[11] -= 36;  // 060B00BE add #-36,r11
L_060B00C0:
    c.r[0] += 1;  // 060B00C0 add #1,r0
L_060B00C2:
    st32(c.r[15] + 24, c.r[0]);  // 060B00C2 mov.l r0,@(24,r15)
L_060B00C4:
    c.r[0] = ld32(c.r[15] + 16);  // 060B00C4 mov.l @(16,r15),r0
L_060B00C6:
    c.r[8] += 12;  // 060B00C6 add #12,r8
L_060B00C8:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B00C8 dt r0
L_060B00CA:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B0006; } }  // 060B00CA bf/s 0x060B0006 ; mov.l r0,@(16,r15)
L_060B00CE:
    c.r[0] = c.r[11];  // 060B00CE mov r11,r0
L_060B00D0:
    st32(c.gbr + 48, c.r[0]);  // 060B00D0 mov.l r0,@(48,gbr)
L_060B00D2:
    c.r[15] += 24;  // 060B00D2 add #24,r15
L_060B00D4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D4 mov.l @r15+,r1
L_060B00D6:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D6 mov.l @r15+,r2
L_060B00D8:
    c.r[0] = ld32(c.gbr + 72);  // 060B00D8 mov.l @(72,gbr),r0
L_060B00DA:
    st32(c.r[0] + 8, c.r[1]);  // 060B00DA mov.l r1,@(8,r0)
L_060B00DC:
    c.r[1] = 0x28u;  // 060B00DC mov #40,r1
L_060B00DE:
    st32(c.r[0], c.r[1]);  // 060B00DE mov.l r1,@(0,r0)
L_060B00E0:
    c.r[0] += 16;  // 060B00E0 add #16,r0
L_060B00E2:
    c.r[1] = ld32(0x060B0100u);  // 060B00E2 mov.l 0x060B0100,r1
L_060B00E4:
    st32(c.gbr + 72, c.r[0]);  // 060B00E4 mov.l r0,@(72,gbr)
L_060B00E6:
    st16(c.r[1], c.r[0]);  // 060B00E6 mov.w r0,@r1
L_060B00E8:
    c.r[0] = c.r[2];  // 060B00E8 mov r2,r0
L_060B00EA:
    st32(c.gbr + 116, c.r[0]);  // 060B00EA mov.l r0,@(116,gbr)
L_060B00EC:
    c.r[0] = 0x1u;  // 060B00EC mov #1,r0
L_060B00EE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B00EE mov.l @r15+,r9
L_060B00F0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B00F0 lds.l @r15+,pr
L_060B00F2:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F2 mov.l @r15+,r10
L_060B00F4:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F4 mov.l @r15+,r11
L_060B00F6:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F6 mov.l @r15+,r12
L_060B00F8:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F8 mov.l @r15+,r13
L_060B00FA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B00FA mov.l @r15+,r14
L_060B00FC:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B00FC rts ; mov.l @r15+,r8
}

void f_060B00C4(SH2Context& c) {
    ran[3030] = 1;
    goto L_060B00C4;
L_060B0006:
    c.mach = c.macl = 0;  // 060B0006 clrmac
L_060B0008:
    sh2_mac_l(c, 6, 7);  // 060B0008 mac.l @r7+,@r6+
L_060B000A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B000A mov.w @(8,r7),r0
L_060B000C:
    c.r[5] = c.r[15];  // 060B000C mov r15,r5
L_060B000E:
    sh2_mac_l(c, 6, 7);  // 060B000E mac.l @r7+,@r6+
L_060B0010:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0010 exts.w r0,r1
L_060B0012:
    c.r[1] <<= 2;  // 060B0012 shll2 r1
L_060B0014:
    sh2_mac_l(c, 6, 7);  // 060B0014 mac.l @r7+,@r6+
L_060B0016:
    c.r[6] += 4;  // 060B0016 add #4,r6
L_060B0018:
    c.r[7] -= 12;  // 060B0018 add #-12,r7
L_060B001A:
    c.r[1] <<= 2;  // 060B001A shll2 r1
L_060B001C:
    c.r[0] = c.mach;  // 060B001C sts mach,r0
L_060B001E:
    c.r[13] = c.macl;  // 060B001E sts macl,r13
L_060B0020:
    c.mach = c.macl = 0;  // 060B0020 clrmac
L_060B0022:
    sh2_mac_l(c, 6, 7);  // 060B0022 mac.l @r7+,@r6+
L_060B0024:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B0024 xtrct r0,r13
L_060B0026:
    st32(c.r[5], c.r[13]);  // 060B0026 mov.l r13,@(0,r5)
L_060B0028:
    sh2_mac_l(c, 6, 7);  // 060B0028 mac.l @r7+,@r6+
L_060B002A:
    c.r[1] += c.r[10];  // 060B002A add r10,r1
L_060B002C:
    c.r[4] = 0x4u;  // 060B002C mov #4,r4
L_060B002E:
    sh2_mac_l(c, 6, 7);  // 060B002E mac.l @r7+,@r6+
L_060B0030:
    c.r[6] += 4;  // 060B0030 add #4,r6
L_060B0032:
    c.r[7] -= 12;  // 060B0032 add #-12,r7
L_060B0034:
    c.r[4] += c.r[1];  // 060B0034 add r1,r4
L_060B0036:
    c.r[0] = c.mach;  // 060B0036 sts mach,r0
L_060B0038:
    c.r[2] = c.macl;  // 060B0038 sts macl,r2
L_060B003A:
    c.mach = c.macl = 0;  // 060B003A clrmac
L_060B003C:
    sh2_mac_l(c, 6, 7);  // 060B003C mac.l @r7+,@r6+
L_060B003E:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B003E xtrct r0,r2
L_060B0040:
    st32(c.r[5] + 4, c.r[2]);  // 060B0040 mov.l r2,@(4,r5)
L_060B0042:
    sh2_mac_l(c, 6, 7);  // 060B0042 mac.l @r7+,@r6+
L_060B0044:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B0044 mov.w @r8,r12
L_060B0046:
    c.r[9] = 0x7Fu;  // 060B0046 mov #127,r9
L_060B0048:
    sh2_mac_l(c, 6, 7);  // 060B0048 mac.l @r7+,@r6+
L_060B004A:
    c.r[6] -= 44;  // 060B004A add #-44,r6
L_060B004C:
    c.r[9] &= c.r[12];  // 060B004C and r12,r9
L_060B004E:
    c.r[9] <<= 2;  // 060B004E shll2 r9
L_060B0050:
    c.r[0] = c.mach;  // 060B0050 sts mach,r0
L_060B0052:
    c.r[3] = c.macl;  // 060B0052 sts macl,r3
L_060B0054:
    c.mach = c.macl = 0;  // 060B0054 clrmac
L_060B0056:
    sh2_mac_l(c, 5, 4);  // 060B0056 mac.l @r4+,@r5+
L_060B0058:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B0058 xtrct r0,r3
L_060B005A:
    c.r[0] = 0x060B0104u;  // 060B005A mova 0x060B0104,r0
L_060B005C:
    sh2_mac_l(c, 5, 4);  // 060B005C mac.l @r4+,@r5+
L_060B005E:
    st32(c.r[5], c.r[3]);  // 060B005E mov.l r3,@r5
L_060B0060:
    c.r[9] <<= 2;  // 060B0060 shll2 r9
L_060B0062:
    sh2_mac_l(c, 5, 4);  // 060B0062 mac.l @r4+,@r5+
L_060B0064:
    c.r[9] += c.r[0];  // 060B0064 add r0,r9
L_060B0066:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B0066 mov.w @(10,r8),r0
L_060B0068:
    c.r[7] += 2;  // 060B0068 add #2,r7
L_060B006A:
    c.r[4] = c.mach;  // 060B006A sts mach,r4
L_060B006C:
    st16(c.r[11], c.r[0]);  // 060B006C mov.w r0,@(0,r11)
L_060B006E:
    c.r[0] = ld32(c.gbr + 896);  // 060B006E mov.l @(896,gbr),r0
L_060B0070:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B0070 cmp/ge r0,r4
L_060B0072:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B007E; } }  // 060B0072 bt/s 0x060B007E ; swap.b r12,r0
L_060B0076:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B0076 mov.l @r9+,r4
L_060B0078:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0078 mov.w @r7+,r2
L_060B007A:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B007A jmp @r4 ; shll2 r2
L_060B007E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B007E tst #1,r0
L_060B0080:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B0096; } }  // 060B0080 bt/s 0x060B0096 ; neg r3,r3
L_060B0084:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B0084 mov.l r3,@-r5
L_060B0086:
    c.r[2] = 0u - c.r[2];  // 060B0086 neg r2,r2
L_060B0088:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B0088 mov.l r2,@-r5
L_060B008A:
    c.r[13] = 0u - c.r[13];  // 060B008A neg r13,r13
L_060B008C:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B008C mov.l r13,@-r5
L_060B008E:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B008E mov.l @r9+,r4
L_060B0090:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0090 mov.w @r7+,r2
L_060B0092:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B0092 jmp @r4 ; shll2 r2
L_060B0096:
    c.r[7] += 6; goto L_060B00C4;  // 060B0096 bra 0x060B00C4 ; add #6,r7
L_060B00C4:
    c.r[0] = ld32(c.r[15] + 16);  // 060B00C4 mov.l @(16,r15),r0
L_060B00C6:
    c.r[8] += 12;  // 060B00C6 add #12,r8
L_060B00C8:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B00C8 dt r0
L_060B00CA:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B0006; } }  // 060B00CA bf/s 0x060B0006 ; mov.l r0,@(16,r15)
L_060B00CE:
    c.r[0] = c.r[11];  // 060B00CE mov r11,r0
L_060B00D0:
    st32(c.gbr + 48, c.r[0]);  // 060B00D0 mov.l r0,@(48,gbr)
L_060B00D2:
    c.r[15] += 24;  // 060B00D2 add #24,r15
L_060B00D4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D4 mov.l @r15+,r1
L_060B00D6:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D6 mov.l @r15+,r2
L_060B00D8:
    c.r[0] = ld32(c.gbr + 72);  // 060B00D8 mov.l @(72,gbr),r0
L_060B00DA:
    st32(c.r[0] + 8, c.r[1]);  // 060B00DA mov.l r1,@(8,r0)
L_060B00DC:
    c.r[1] = 0x28u;  // 060B00DC mov #40,r1
L_060B00DE:
    st32(c.r[0], c.r[1]);  // 060B00DE mov.l r1,@(0,r0)
L_060B00E0:
    c.r[0] += 16;  // 060B00E0 add #16,r0
L_060B00E2:
    c.r[1] = ld32(0x060B0100u);  // 060B00E2 mov.l 0x060B0100,r1
L_060B00E4:
    st32(c.gbr + 72, c.r[0]);  // 060B00E4 mov.l r0,@(72,gbr)
L_060B00E6:
    st16(c.r[1], c.r[0]);  // 060B00E6 mov.w r0,@r1
L_060B00E8:
    c.r[0] = c.r[2];  // 060B00E8 mov r2,r0
L_060B00EA:
    st32(c.gbr + 116, c.r[0]);  // 060B00EA mov.l r0,@(116,gbr)
L_060B00EC:
    c.r[0] = 0x1u;  // 060B00EC mov #1,r0
L_060B00EE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B00EE mov.l @r15+,r9
L_060B00F0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B00F0 lds.l @r15+,pr
L_060B00F2:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F2 mov.l @r15+,r10
L_060B00F4:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F4 mov.l @r15+,r11
L_060B00F6:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F6 mov.l @r15+,r12
L_060B00F8:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F8 mov.l @r15+,r13
L_060B00FA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B00FA mov.l @r15+,r14
L_060B00FC:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B00FC rts ; mov.l @r15+,r8
}

void f_060B0904(SH2Context& c) {
    ran[3031] = 1;
    c.mach = c.macl = 0;  // 060B0904 clrmac
    c.r[4] = c.r[15];  // 060B0906 mov r15,r4
    c.r[5] = c.gbr;  // 060B0908 stc gbr,r5
    c.r[5] += 76;  // 060B090A add #76,r5
    sh2_mac_l(c, 5, 4);  // 060B090C mac.l @r4+,@r5+
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 6);  // 060B090E mov.w @(6,r8),r0
    c.r[1] = 0x1Fu;  // 060B0910 mov #31,r1
    c.r[3] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B0912 swap.b r0,r3
    sh2_mac_l(c, 5, 4);  // 060B0914 mac.l @r4+,@r5+
    c.r[3] >>= 2;  // 060B0916 shlr2 r3
    c.r[3] &= c.r[1];  // 060B0918 and r1,r3
    c.r[1] &= c.r[0];  // 060B091A and r0,r1
    sh2_mac_l(c, 5, 4);  // 060B091C mac.l @r4+,@r5+
    c.r[0] >>= 2;  // 060B091E shlr2 r0
    c.r[0] >>= 2;  // 060B0920 shlr2 r0
    c.r[2] = 0x1Fu;  // 060B0922 mov #31,r2
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B0924 shlr r0
    c.r[2] &= c.r[0];  // 060B0926 and r0,r2
    c.r[5] = c.mach;  // 060B0928 sts mach,r5
    c.r[4] = c.macl;  // 060B092A sts macl,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B092C tst r5,r5
    { const bool k = c.t; c.r[0] = ld32(c.gbr + 100); if (k) { goto L_060B0944; } }  // 060B092E bt/s 0x060B0944 ; mov.l @(100,gbr),r0
    c.r[5] += 1;  // 060B0932 add #1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B0934 tst r5,r5
    if (c.t) { goto L_060B0948; }  // 060B0936 bt 0x060B0948
    c.r[4] = 0xFFFFFFFFu;  // 060B0938 mov #-1,r4
    c.t = (int32_t)c.r[5] > 0;  // 060B093A cmp/pl r5
    { const bool k = c.t; c.r[4] = c.r[4] & 0xFFu; if (k) { goto L_060B0950; } }  // 060B093C bt/s 0x060B0950 ; extu.b r4,r4
    goto L_060B0958;  // 060B0940 bra 0x060B0958 ; nop
L_060B0944:
    c.r[5] = 0xFFFFFF80u;  // 060B0944 mov #-128,r5
    c.r[5] = c.r[5] & 0xFFu;  // 060B0946 extu.b r5,r5
L_060B0948:
    c.r[4] >>= 16;  // 060B0948 shlr16 r4
    c.r[4] >>= 8;  // 060B094A shlr8 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B094C shlr r4
    c.r[4] |= c.r[5];  // 060B094E or r5,r4
L_060B0950:
    c.r[5] = 0xFFFFFFF8u;  // 060B0950 mov #-8,r5
    c.r[4] &= c.r[5];  // 060B0952 and r5,r4
    c.r[4] <<= 2;  // 060B0954 shll2 r4
    c.r[0] += c.r[4];  // 060B0956 add r4,r0
L_060B0958:
    c.r[5] = 0x4u;  // 060B0958 mov #4,r5
    c.r[5] <<= 8;  // 060B095A shll8 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060B095C mov.b @(r0,r1),r1
    c.r[0] += c.r[5];  // 060B095E add r5,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060B0960 mov.b @(r0,r2),r2
    c.r[0] += c.r[5];  // 060B0962 add r5,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060B0964 mov.b @(r0,r3),r0
    c.r[0] |= 0x20u;  // 060B0966 or #32,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B0968 swap.b r0,r0
    c.r[2] <<= 2;  // 060B096A shll2 r2
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060B096C shll r2
    c.r[0] += c.r[2];  // 060B096E add r2,r0
    c.r[0] <<= 2;  // 060B0970 shll2 r0
    c.r[1] |= c.r[0];  // 060B0972 or r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 4);  // 060B0974 mov.w @(4,r8),r0
    c.r[1] <<= 16;  // 060B0976 shll16 r1
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B0978 xtrct r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B097A mov.w @(8,r8),r0
    st32(c.r[11] + 4, c.r[1]);  // 060B097C mov.l r1,@(4,r11)
    { const uint32_t x = c.pr; st16(c.r[11] + 28, c.r[0]); c.pc = x; return; }  // 060B097E rts ; mov.w r0,@(28,r11)
}

void f_060B0982(SH2Context& c) {
    ran[3032] = 1;
    c.mach = c.macl = 0;  // 060B0982 clrmac
    c.r[4] = c.r[15];  // 060B0984 mov r15,r4
    c.r[5] = c.gbr;  // 060B0986 stc gbr,r5
    c.r[5] += 76;  // 060B0988 add #76,r5
    sh2_mac_l(c, 5, 4);  // 060B098A mac.l @r4+,@r5+
    sh2_mac_l(c, 5, 4);  // 060B098C mac.l @r4+,@r5+
    c.r[0] = ld32(c.r[8] + 4);  // 060B098E mov.l @(4,r8),r0
    sh2_mac_l(c, 5, 4);  // 060B0990 mac.l @r4+,@r5+
    c.r[1] = 0x7u;  // 060B0992 mov #7,r1
    c.r[5] = c.mach;  // 060B0994 sts mach,r5
    c.r[4] = c.macl;  // 060B0996 sts macl,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B0998 tst r5,r5
    { const bool k = c.t; c.r[5] += 1; if (k) { goto L_060B09A8; } }  // 060B099A bt/s 0x060B09A8 ; add #1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B099E tst r5,r5
    { const bool k = c.t; c.t = (int32_t)c.r[5] >= 0; if (k) { goto L_060B09AA; } }  // 060B09A0 bt/s 0x060B09AA ; cmp/pz r5
    { const bool k = !c.t; c.r[4] = 0xFFFFFFFFu; if (k) { goto L_060B09B6; } }  // 060B09A4 bf/s 0x060B09B6 ; mov #-1,r4
L_060B09A8:
    c.r[5] = 0x8u;  // 060B09A8 mov #8,r5
L_060B09AA:
    c.t = c.r[4] >> 31; c.r[4] = c.r[4] << 1 | c.t;  // 060B09AA rotl r4
    c.t = c.r[4] >> 31; c.r[4] = c.r[4] << 1 | c.t;  // 060B09AC rotl r4
    c.t = c.r[4] >> 31; c.r[4] = c.r[4] << 1 | c.t;  // 060B09AE rotl r4
    c.r[4] &= c.r[1];  // 060B09B0 and r1,r4
    c.r[4] |= c.r[5];  // 060B09B2 or r5,r4
    c.r[0] += c.r[4];  // 060B09B4 add r4,r0
L_060B09B6:
    { const uint32_t x = c.pr; st32(c.r[11] + 4, c.r[0]); c.pc = x; return; }  // 060B09B6 rts ; mov.l r0,@(4,r11)
}

void f_060B09BA(SH2Context& c) {
    ran[3033] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 2);  // 060B09BA mov.w @(2,r8),r0
    c.r[1] = ld32(c.r[15] + 20);  // 060B09BC mov.l @(20,r15),r1
    c.r[0] <<= 2;  // 060B09BE shll2 r0
    c.r[0] += c.r[0];  // 060B09C0 add r0,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060B09C2 mov.l @(r0,r1),r0
    c.mach = c.macl = 0;  // 060B09C4 clrmac
    st32(c.r[11] + 8, c.r[0]);  // 060B09C6 mov.l r0,@(8,r11)
    c.r[4] = c.r[15];  // 060B09C8 mov r15,r4
    c.r[5] = c.gbr;  // 060B09CA stc gbr,r5
    c.r[5] += 76;  // 060B09CC add #76,r5
    sh2_mac_l(c, 5, 4);  // 060B09CE mac.l @r4+,@r5+
    c.r[3] = ld32(c.r[8] + 4);  // 060B09D0 mov.l @(4,r8),r3
    sh2_mac_l(c, 5, 4);  // 060B09D2 mac.l @r4+,@r5+
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060B09D4 swap.w r3,r0
    c.r[0] &= 0x38u;  // 060B09D6 and #56,r0
    sh2_mac_l(c, 5, 4);  // 060B09D8 mac.l @r4+,@r5+
    c.t = c.r[0] == 0x8u;  // 060B09DA cmp/eq #8,r0
    if (c.t) { goto L_060B09E2; }  // 060B09DC bt 0x060B09E2
    c.t = c.r[0] == 0x28u;  // 060B09DE cmp/eq #40,r0
    if (!c.t) { goto L_060B0A16; }  // 060B09E0 bf 0x060B0A16
L_060B09E2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B0A1Eu);  // 060B09E2 mov.w 0x060B0A1E,r0
    c.r[1] = c.mach;  // 060B09E4 sts mach,r1
    c.r[2] = c.macl;  // 060B09E6 sts macl,r2
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B09E8 tst r1,r1
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_060B09F8; } }  // 060B09EA bt/s 0x060B09F8 ; add #1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B09EE tst r1,r1
    { const bool k = c.t; c.t = (int32_t)c.r[1] >= 0; if (k) { goto L_060B09FA; } }  // 060B09F0 bt/s 0x060B09FA ; cmp/pz r1
    { const bool k = !c.t; c.r[2] = 0xFFFFFFFFu; if (k) { goto L_060B0A06; } }  // 060B09F4 bf/s 0x060B0A06 ; mov #-1,r2
L_060B09F8:
    c.r[1] = 0x10u;  // 060B09F8 mov #16,r1
L_060B09FA:
    c.r[2] >>= 16;  // 060B09FA shlr16 r2
    c.r[2] >>= 8;  // 060B09FC shlr8 r2
    c.r[2] >>= 2;  // 060B09FE shlr2 r2
    c.r[2] >>= 2;  // 060B0A00 shlr2 r2
    c.r[2] |= c.r[1];  // 060B0A02 or r1,r2
    c.r[0] += c.r[2];  // 060B0A04 add r2,r0
L_060B0A06:
    c.r[2] = 0xFFFFFFF8u;  // 060B0A06 mov #-8,r2
    st16(c.r[11] + 28, c.r[0]);  // 060B0A08 mov.w r0,@(28,r11)
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060B0A0A swap.w r3,r0
    c.r[0] &= c.r[2];  // 060B0A0C and r2,r0
    c.r[0] |= 0x4u;  // 060B0A0E or #4,r0
    c.r[0] = c.r[0] << 16 | c.r[0] >> 16;  // 060B0A10 swap.w r0,r0
    { const uint32_t x = c.pr; st32(c.r[11] + 4, c.r[0]); c.pc = x; return; }  // 060B0A12 rts ; mov.l r0,@(4,r11)
L_060B0A16:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B0A16 mov.w @(8,r8),r0
    st32(c.r[11] + 4, c.r[3]);  // 060B0A18 mov.l r3,@(4,r11)
    { const uint32_t x = c.pr; st16(c.r[11] + 28, c.r[0]); c.pc = x; return; }  // 060B0A1A rts ; mov.w r0,@(28,r11)
}

void f_060B0A20(SH2Context& c) {
    ran[3034] = 1;
L_060B0A20:
    c.r[0] = ld32(c.gbr + 152);  // 060B0A20 mov.l @(152,gbr),r0
L_060B0A22:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B0A22 mov.l r9,@-r15
L_060B0A24:
    c.r[13] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0A24 exts.w r0,r13
L_060B0A26:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B0A26 swap.w r0,r12
L_060B0A28:
    c.r[0] = ld32(c.r[1] + 4);  // 060B0A28 mov.l @(4,r1),r0
L_060B0A2A:
    c.r[5] = 0x0u;  // 060B0A2A mov #0,r5
L_060B0A2C:
    c.r[1] = ld32(c.r[1]);  // 060B0A2C mov.l @(0,r1),r1
L_060B0A2E:
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[12];  // 060B0A2E exts.w r12,r12
L_060B0A30:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B0A30 shlr r0
L_060B0A32:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B0A4C; } }  // 060B0A32 bf/s 0x060B0A4C ; addc r5,r5
L_060B0A36:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B0A36 mov.w @(142,gbr),r0
L_060B0A38:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B0A38 exts.w r1,r9
L_060B0A3A:
    c.r[9] += c.r[13];  // 060B0A3A add r13,r9
L_060B0A3C:
    c.t = c.r[9] >= c.r[0];  // 060B0A3C cmp/hs r0,r9
L_060B0A3E:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B0ABA; } }  // 060B0A3E bt/s 0x060B0ABA ; swap.w r1,r9
L_060B0A42:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B0A42 mov.w @(140,gbr),r0
L_060B0A44:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B0A44 exts.w r9,r9
L_060B0A46:
    c.r[9] += c.r[12];  // 060B0A46 add r12,r9
L_060B0A48:
    c.t = c.r[9] >= c.r[0];  // 060B0A48 cmp/hs r0,r9
L_060B0A4A:
    { const bool k = c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B0ABA; } }  // 060B0A4A bt/s 0x060B0ABA ; mov.l @(4,r2),r0
    goto L_060B0A4E;
L_060B0A4C:
    c.r[0] = ld32(c.r[2] + 4);  // 060B0A4C mov.l @(4,r2),r0
L_060B0A4E:
    c.r[2] = ld32(c.r[2]);  // 060B0A4E mov.l @(0,r2),r2
L_060B0A50:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B0A50 shlr r0
L_060B0A52:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B0A6C; } }  // 060B0A52 bf/s 0x060B0A6C ; addc r5,r5
L_060B0A56:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B0A56 mov.w @(142,gbr),r0
L_060B0A58:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B0A58 exts.w r2,r9
L_060B0A5A:
    c.r[9] += c.r[13];  // 060B0A5A add r13,r9
L_060B0A5C:
    c.t = c.r[9] >= c.r[0];  // 060B0A5C cmp/hs r0,r9
L_060B0A5E:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B0ABA; } }  // 060B0A5E bt/s 0x060B0ABA ; swap.w r2,r9
L_060B0A62:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B0A62 mov.w @(140,gbr),r0
L_060B0A64:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B0A64 exts.w r9,r9
L_060B0A66:
    c.r[9] += c.r[12];  // 060B0A66 add r12,r9
L_060B0A68:
    c.t = c.r[9] >= c.r[0];  // 060B0A68 cmp/hs r0,r9
L_060B0A6A:
    { const bool k = c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B0ABA; } }  // 060B0A6A bt/s 0x060B0ABA ; mov.l @(4,r3),r0
    goto L_060B0A6E;
L_060B0A6C:
    c.r[0] = ld32(c.r[3] + 4);  // 060B0A6C mov.l @(4,r3),r0
L_060B0A6E:
    c.r[3] = ld32(c.r[3]);  // 060B0A6E mov.l @(0,r3),r3
L_060B0A70:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B0A70 shlr r0
L_060B0A72:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B0A8C; } }  // 060B0A72 bf/s 0x060B0A8C ; addc r5,r5
L_060B0A76:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B0A76 mov.w @(142,gbr),r0
L_060B0A78:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 060B0A78 exts.w r3,r9
L_060B0A7A:
    c.r[9] += c.r[13];  // 060B0A7A add r13,r9
L_060B0A7C:
    c.t = c.r[9] >= c.r[0];  // 060B0A7C cmp/hs r0,r9
L_060B0A7E:
    { const bool k = c.t; c.r[9] = c.r[3] << 16 | c.r[3] >> 16; if (k) { goto L_060B0ABA; } }  // 060B0A7E bt/s 0x060B0ABA ; swap.w r3,r9
L_060B0A82:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B0A82 mov.w @(140,gbr),r0
L_060B0A84:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B0A84 exts.w r9,r9
L_060B0A86:
    c.r[9] += c.r[12];  // 060B0A86 add r12,r9
L_060B0A88:
    c.t = c.r[9] >= c.r[0];  // 060B0A88 cmp/hs r0,r9
L_060B0A8A:
    { const bool k = c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B0ABA; } }  // 060B0A8A bt/s 0x060B0ABA ; mov.l @(4,r4),r0
    goto L_060B0A8E;
L_060B0A8C:
    c.r[0] = ld32(c.r[4] + 4);  // 060B0A8C mov.l @(4,r4),r0
L_060B0A8E:
    c.r[4] = ld32(c.r[4]);  // 060B0A8E mov.l @(0,r4),r4
L_060B0A90:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B0A90 shlr r0
L_060B0A92:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B0AAC; } }  // 060B0A92 bf/s 0x060B0AAC ; addc r5,r5
L_060B0A96:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B0A96 mov.w @(142,gbr),r0
L_060B0A98:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060B0A98 exts.w r4,r9
L_060B0A9A:
    c.r[9] += c.r[13];  // 060B0A9A add r13,r9
L_060B0A9C:
    c.t = c.r[9] >= c.r[0];  // 060B0A9C cmp/hs r0,r9
L_060B0A9E:
    { const bool k = c.t; c.r[9] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B0ABA; } }  // 060B0A9E bt/s 0x060B0ABA ; swap.w r4,r9
L_060B0AA2:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B0AA2 mov.w @(140,gbr),r0
L_060B0AA4:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B0AA4 exts.w r9,r9
L_060B0AA6:
    c.r[9] += c.r[12];  // 060B0AA6 add r12,r9
L_060B0AA8:
    c.t = c.r[9] >= c.r[0];  // 060B0AA8 cmp/hs r0,r9
L_060B0AAA:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060B0ABA; } }  // 060B0AAA bt/s 0x060B0ABA ; mov #0,r5
    goto L_060B0AAE;
L_060B0AAC:
    c.r[5] = 0x0u;  // 060B0AAC mov #0,r5
L_060B0AAE:
    c.r[5] <<= 2;  // 060B0AAE shll2 r5
L_060B0AB0:
    c.r[0] = 0x060B0AC0u;  // 060B0AB0 mova 0x060B0AC0,r0
L_060B0AB2:
    c.r[0] = ld32(c.r[0] + c.r[5]);  // 060B0AB2 mov.l @(r0,r5),r0
L_060B0AB4:
    c.r[5] = 0x1u;  // 060B0AB4 mov #1,r5
L_060B0AB6:
    { const uint32_t x = c.r[0]; c.r[9] = ld32(c.r[15]); switch (x) { case 0x060B7C80u: goto L_060B7C80; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7A48u: goto L_060B7A48; case 0x060B7990u: goto L_060B7990; default: sh2_call(c, x); return; } }  // 060B0AB6 jmp @r0 ; mov.l @r15,r9
L_060B0ABA:
    c.r[15] += 4; { sh2_call(c, 0x060B00C4u); return; }  // 060B0ABA bra 0x060B00C4 ; add #4,r15
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B0A20u: goto L_060B0A20; case 0x060B0A22u: goto L_060B0A22; case 0x060B0A24u: goto L_060B0A24; case 0x060B0A26u: goto L_060B0A26; case 0x060B0A28u: goto L_060B0A28; case 0x060B0A2Au: goto L_060B0A2A; case 0x060B0A2Cu: goto L_060B0A2C; case 0x060B0A2Eu: goto L_060B0A2E; case 0x060B0A30u: goto L_060B0A30; case 0x060B0A32u: goto L_060B0A32; case 0x060B0A36u: goto L_060B0A36; case 0x060B0A38u: goto L_060B0A38; case 0x060B0A3Au: goto L_060B0A3A; case 0x060B0A3Cu: goto L_060B0A3C; case 0x060B0A3Eu: goto L_060B0A3E; case 0x060B0A42u: goto L_060B0A42; case 0x060B0A44u: goto L_060B0A44; case 0x060B0A46u: goto L_060B0A46; case 0x060B0A48u: goto L_060B0A48; case 0x060B0A4Au: goto L_060B0A4A; case 0x060B0A4Eu: goto L_060B0A4E; case 0x060B0A50u: goto L_060B0A50; case 0x060B0A52u: goto L_060B0A52; case 0x060B0A56u: goto L_060B0A56; case 0x060B0A58u: goto L_060B0A58; case 0x060B0A5Au: goto L_060B0A5A; case 0x060B0A5Cu: goto L_060B0A5C; case 0x060B0A5Eu: goto L_060B0A5E; case 0x060B0A62u: goto L_060B0A62; case 0x060B0A64u: goto L_060B0A64; case 0x060B0A66u: goto L_060B0A66; case 0x060B0A68u: goto L_060B0A68; case 0x060B0A6Au: goto L_060B0A6A; case 0x060B0A6Eu: goto L_060B0A6E; case 0x060B0A70u: goto L_060B0A70; case 0x060B0A72u: goto L_060B0A72; case 0x060B0A76u: goto L_060B0A76; case 0x060B0A78u: goto L_060B0A78; case 0x060B0A7Au: goto L_060B0A7A; case 0x060B0A7Cu: goto L_060B0A7C; case 0x060B0A7Eu: goto L_060B0A7E; case 0x060B0A82u: goto L_060B0A82; case 0x060B0A84u: goto L_060B0A84; case 0x060B0A86u: goto L_060B0A86; case 0x060B0A88u: goto L_060B0A88; case 0x060B0A8Au: goto L_060B0A8A; case 0x060B0A8Eu: goto L_060B0A8E; case 0x060B0A90u: goto L_060B0A90; case 0x060B0A92u: goto L_060B0A92; case 0x060B0A96u: goto L_060B0A96; case 0x060B0A98u: goto L_060B0A98; case 0x060B0A9Au: goto L_060B0A9A; case 0x060B0A9Cu: goto L_060B0A9C; case 0x060B0A9Eu: goto L_060B0A9E; case 0x060B0AA2u: goto L_060B0AA2; case 0x060B0AA4u: goto L_060B0AA4; case 0x060B0AA6u: goto L_060B0AA6; case 0x060B0AA8u: goto L_060B0AA8; case 0x060B0AAAu: goto L_060B0AAA; case 0x060B0AAEu: goto L_060B0AAE; case 0x060B0AB0u: goto L_060B0AB0; case 0x060B0AB2u: goto L_060B0AB2; case 0x060B0AB4u: goto L_060B0AB4; case 0x060B0AB6u: goto L_060B0AB6; case 0x060B0ABAu: goto L_060B0ABA; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0A20u: goto L_060B0A20; case 0x060B0A22u: goto L_060B0A22; case 0x060B0A24u: goto L_060B0A24; case 0x060B0A26u: goto L_060B0A26; case 0x060B0A28u: goto L_060B0A28; case 0x060B0A2Au: goto L_060B0A2A; case 0x060B0A2Cu: goto L_060B0A2C; case 0x060B0A2Eu: goto L_060B0A2E; case 0x060B0A30u: goto L_060B0A30; case 0x060B0A32u: goto L_060B0A32; case 0x060B0A36u: goto L_060B0A36; case 0x060B0A38u: goto L_060B0A38; case 0x060B0A3Au: goto L_060B0A3A; case 0x060B0A3Cu: goto L_060B0A3C; case 0x060B0A3Eu: goto L_060B0A3E; case 0x060B0A42u: goto L_060B0A42; case 0x060B0A44u: goto L_060B0A44; case 0x060B0A46u: goto L_060B0A46; case 0x060B0A48u: goto L_060B0A48; case 0x060B0A4Au: goto L_060B0A4A; case 0x060B0A4Eu: goto L_060B0A4E; case 0x060B0A50u: goto L_060B0A50; case 0x060B0A52u: goto L_060B0A52; case 0x060B0A56u: goto L_060B0A56; case 0x060B0A58u: goto L_060B0A58; case 0x060B0A5Au: goto L_060B0A5A; case 0x060B0A5Cu: goto L_060B0A5C; case 0x060B0A5Eu: goto L_060B0A5E; case 0x060B0A62u: goto L_060B0A62; case 0x060B0A64u: goto L_060B0A64; case 0x060B0A66u: goto L_060B0A66; case 0x060B0A68u: goto L_060B0A68; case 0x060B0A6Au: goto L_060B0A6A; case 0x060B0A6Eu: goto L_060B0A6E; case 0x060B0A70u: goto L_060B0A70; case 0x060B0A72u: goto L_060B0A72; case 0x060B0A76u: goto L_060B0A76; case 0x060B0A78u: goto L_060B0A78; case 0x060B0A7Au: goto L_060B0A7A; case 0x060B0A7Cu: goto L_060B0A7C; case 0x060B0A7Eu: goto L_060B0A7E; case 0x060B0A82u: goto L_060B0A82; case 0x060B0A84u: goto L_060B0A84; case 0x060B0A86u: goto L_060B0A86; case 0x060B0A88u: goto L_060B0A88; case 0x060B0A8Au: goto L_060B0A8A; case 0x060B0A8Eu: goto L_060B0A8E; case 0x060B0A90u: goto L_060B0A90; case 0x060B0A92u: goto L_060B0A92; case 0x060B0A96u: goto L_060B0A96; case 0x060B0A98u: goto L_060B0A98; case 0x060B0A9Au: goto L_060B0A9A; case 0x060B0A9Cu: goto L_060B0A9C; case 0x060B0A9Eu: goto L_060B0A9E; case 0x060B0AA2u: goto L_060B0AA2; case 0x060B0AA4u: goto L_060B0AA4; case 0x060B0AA6u: goto L_060B0AA6; case 0x060B0AA8u: goto L_060B0AA8; case 0x060B0AAAu: goto L_060B0AAA; case 0x060B0AAEu: goto L_060B0AAE; case 0x060B0AB0u: goto L_060B0AB0; case 0x060B0AB2u: goto L_060B0AB2; case 0x060B0AB4u: goto L_060B0AB4; case 0x060B0AB6u: goto L_060B0AB6; case 0x060B0ABAu: goto L_060B0ABA; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
L_060B7A48:
    c.r[15] += 4;  // 060B7A48 add #4,r15
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0A20u: goto L_060B0A20; case 0x060B0A22u: goto L_060B0A22; case 0x060B0A24u: goto L_060B0A24; case 0x060B0A26u: goto L_060B0A26; case 0x060B0A28u: goto L_060B0A28; case 0x060B0A2Au: goto L_060B0A2A; case 0x060B0A2Cu: goto L_060B0A2C; case 0x060B0A2Eu: goto L_060B0A2E; case 0x060B0A30u: goto L_060B0A30; case 0x060B0A32u: goto L_060B0A32; case 0x060B0A36u: goto L_060B0A36; case 0x060B0A38u: goto L_060B0A38; case 0x060B0A3Au: goto L_060B0A3A; case 0x060B0A3Cu: goto L_060B0A3C; case 0x060B0A3Eu: goto L_060B0A3E; case 0x060B0A42u: goto L_060B0A42; case 0x060B0A44u: goto L_060B0A44; case 0x060B0A46u: goto L_060B0A46; case 0x060B0A48u: goto L_060B0A48; case 0x060B0A4Au: goto L_060B0A4A; case 0x060B0A4Eu: goto L_060B0A4E; case 0x060B0A50u: goto L_060B0A50; case 0x060B0A52u: goto L_060B0A52; case 0x060B0A56u: goto L_060B0A56; case 0x060B0A58u: goto L_060B0A58; case 0x060B0A5Au: goto L_060B0A5A; case 0x060B0A5Cu: goto L_060B0A5C; case 0x060B0A5Eu: goto L_060B0A5E; case 0x060B0A62u: goto L_060B0A62; case 0x060B0A64u: goto L_060B0A64; case 0x060B0A66u: goto L_060B0A66; case 0x060B0A68u: goto L_060B0A68; case 0x060B0A6Au: goto L_060B0A6A; case 0x060B0A6Eu: goto L_060B0A6E; case 0x060B0A70u: goto L_060B0A70; case 0x060B0A72u: goto L_060B0A72; case 0x060B0A76u: goto L_060B0A76; case 0x060B0A78u: goto L_060B0A78; case 0x060B0A7Au: goto L_060B0A7A; case 0x060B0A7Cu: goto L_060B0A7C; case 0x060B0A7Eu: goto L_060B0A7E; case 0x060B0A82u: goto L_060B0A82; case 0x060B0A84u: goto L_060B0A84; case 0x060B0A86u: goto L_060B0A86; case 0x060B0A88u: goto L_060B0A88; case 0x060B0A8Au: goto L_060B0A8A; case 0x060B0A8Eu: goto L_060B0A8E; case 0x060B0A90u: goto L_060B0A90; case 0x060B0A92u: goto L_060B0A92; case 0x060B0A96u: goto L_060B0A96; case 0x060B0A98u: goto L_060B0A98; case 0x060B0A9Au: goto L_060B0A9A; case 0x060B0A9Cu: goto L_060B0A9C; case 0x060B0A9Eu: goto L_060B0A9E; case 0x060B0AA2u: goto L_060B0AA2; case 0x060B0AA4u: goto L_060B0AA4; case 0x060B0AA6u: goto L_060B0AA6; case 0x060B0AA8u: goto L_060B0AA8; case 0x060B0AAAu: goto L_060B0AAA; case 0x060B0AAEu: goto L_060B0AAE; case 0x060B0AB0u: goto L_060B0AB0; case 0x060B0AB2u: goto L_060B0AB2; case 0x060B0AB4u: goto L_060B0AB4; case 0x060B0AB6u: goto L_060B0AB6; case 0x060B0ABAu: goto L_060B0ABA; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
L_060B7C58:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C58 mov.l @r9+,r5
L_060B7C5A:
    c.r[15] += 4;  // 060B7C5A add #4,r15
L_060B7C5C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7C5C mov.w @(0,r11),r0
L_060B7C5E:
    st32(c.r[11] + 16, c.r[1]);  // 060B7C5E mov.l r1,@(16,r11)
L_060B7C60:
    c.r[0] ^= 0x10u;  // 060B7C60 xor #16,r0
L_060B7C62:
    st16(c.r[11], c.r[0]);  // 060B7C62 mov.w r0,@(0,r11)
L_060B7C64:
    st32(c.r[11] + 12, c.r[2]);  // 060B7C64 mov.l r2,@(12,r11)
L_060B7C66:
    st32(c.r[11] + 24, c.r[3]);  // 060B7C66 mov.l r3,@(24,r11)
L_060B7C68:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0A20u: goto L_060B0A20; case 0x060B0A22u: goto L_060B0A22; case 0x060B0A24u: goto L_060B0A24; case 0x060B0A26u: goto L_060B0A26; case 0x060B0A28u: goto L_060B0A28; case 0x060B0A2Au: goto L_060B0A2A; case 0x060B0A2Cu: goto L_060B0A2C; case 0x060B0A2Eu: goto L_060B0A2E; case 0x060B0A30u: goto L_060B0A30; case 0x060B0A32u: goto L_060B0A32; case 0x060B0A36u: goto L_060B0A36; case 0x060B0A38u: goto L_060B0A38; case 0x060B0A3Au: goto L_060B0A3A; case 0x060B0A3Cu: goto L_060B0A3C; case 0x060B0A3Eu: goto L_060B0A3E; case 0x060B0A42u: goto L_060B0A42; case 0x060B0A44u: goto L_060B0A44; case 0x060B0A46u: goto L_060B0A46; case 0x060B0A48u: goto L_060B0A48; case 0x060B0A4Au: goto L_060B0A4A; case 0x060B0A4Eu: goto L_060B0A4E; case 0x060B0A50u: goto L_060B0A50; case 0x060B0A52u: goto L_060B0A52; case 0x060B0A56u: goto L_060B0A56; case 0x060B0A58u: goto L_060B0A58; case 0x060B0A5Au: goto L_060B0A5A; case 0x060B0A5Cu: goto L_060B0A5C; case 0x060B0A5Eu: goto L_060B0A5E; case 0x060B0A62u: goto L_060B0A62; case 0x060B0A64u: goto L_060B0A64; case 0x060B0A66u: goto L_060B0A66; case 0x060B0A68u: goto L_060B0A68; case 0x060B0A6Au: goto L_060B0A6A; case 0x060B0A6Eu: goto L_060B0A6E; case 0x060B0A70u: goto L_060B0A70; case 0x060B0A72u: goto L_060B0A72; case 0x060B0A76u: goto L_060B0A76; case 0x060B0A78u: goto L_060B0A78; case 0x060B0A7Au: goto L_060B0A7A; case 0x060B0A7Cu: goto L_060B0A7C; case 0x060B0A7Eu: goto L_060B0A7E; case 0x060B0A82u: goto L_060B0A82; case 0x060B0A84u: goto L_060B0A84; case 0x060B0A86u: goto L_060B0A86; case 0x060B0A88u: goto L_060B0A88; case 0x060B0A8Au: goto L_060B0A8A; case 0x060B0A8Eu: goto L_060B0A8E; case 0x060B0A90u: goto L_060B0A90; case 0x060B0A92u: goto L_060B0A92; case 0x060B0A96u: goto L_060B0A96; case 0x060B0A98u: goto L_060B0A98; case 0x060B0A9Au: goto L_060B0A9A; case 0x060B0A9Cu: goto L_060B0A9C; case 0x060B0A9Eu: goto L_060B0A9E; case 0x060B0AA2u: goto L_060B0AA2; case 0x060B0AA4u: goto L_060B0AA4; case 0x060B0AA6u: goto L_060B0AA6; case 0x060B0AA8u: goto L_060B0AA8; case 0x060B0AAAu: goto L_060B0AAA; case 0x060B0AAEu: goto L_060B0AAE; case 0x060B0AB0u: goto L_060B0AB0; case 0x060B0AB2u: goto L_060B0AB2; case 0x060B0AB4u: goto L_060B0AB4; case 0x060B0AB6u: goto L_060B0AB6; case 0x060B0ABAu: goto L_060B0ABA; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C68 jmp @r5 ; mov.l r4,@(20,r11)
L_060B7C6C:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C6C mov.l @r9+,r5
L_060B7C6E:
    c.r[15] += 4;  // 060B7C6E add #4,r15
L_060B7C70:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7C70 mov.w @(0,r11),r0
L_060B7C72:
    st32(c.r[11] + 20, c.r[1]);  // 060B7C72 mov.l r1,@(20,r11)
L_060B7C74:
    c.r[0] ^= 0x30u;  // 060B7C74 xor #48,r0
L_060B7C76:
    st16(c.r[11], c.r[0]);  // 060B7C76 mov.w r0,@(0,r11)
L_060B7C78:
    st32(c.r[11] + 24, c.r[2]);  // 060B7C78 mov.l r2,@(24,r11)
L_060B7C7A:
    st32(c.r[11] + 12, c.r[3]);  // 060B7C7A mov.l r3,@(12,r11)
L_060B7C7C:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0A20u: goto L_060B0A20; case 0x060B0A22u: goto L_060B0A22; case 0x060B0A24u: goto L_060B0A24; case 0x060B0A26u: goto L_060B0A26; case 0x060B0A28u: goto L_060B0A28; case 0x060B0A2Au: goto L_060B0A2A; case 0x060B0A2Cu: goto L_060B0A2C; case 0x060B0A2Eu: goto L_060B0A2E; case 0x060B0A30u: goto L_060B0A30; case 0x060B0A32u: goto L_060B0A32; case 0x060B0A36u: goto L_060B0A36; case 0x060B0A38u: goto L_060B0A38; case 0x060B0A3Au: goto L_060B0A3A; case 0x060B0A3Cu: goto L_060B0A3C; case 0x060B0A3Eu: goto L_060B0A3E; case 0x060B0A42u: goto L_060B0A42; case 0x060B0A44u: goto L_060B0A44; case 0x060B0A46u: goto L_060B0A46; case 0x060B0A48u: goto L_060B0A48; case 0x060B0A4Au: goto L_060B0A4A; case 0x060B0A4Eu: goto L_060B0A4E; case 0x060B0A50u: goto L_060B0A50; case 0x060B0A52u: goto L_060B0A52; case 0x060B0A56u: goto L_060B0A56; case 0x060B0A58u: goto L_060B0A58; case 0x060B0A5Au: goto L_060B0A5A; case 0x060B0A5Cu: goto L_060B0A5C; case 0x060B0A5Eu: goto L_060B0A5E; case 0x060B0A62u: goto L_060B0A62; case 0x060B0A64u: goto L_060B0A64; case 0x060B0A66u: goto L_060B0A66; case 0x060B0A68u: goto L_060B0A68; case 0x060B0A6Au: goto L_060B0A6A; case 0x060B0A6Eu: goto L_060B0A6E; case 0x060B0A70u: goto L_060B0A70; case 0x060B0A72u: goto L_060B0A72; case 0x060B0A76u: goto L_060B0A76; case 0x060B0A78u: goto L_060B0A78; case 0x060B0A7Au: goto L_060B0A7A; case 0x060B0A7Cu: goto L_060B0A7C; case 0x060B0A7Eu: goto L_060B0A7E; case 0x060B0A82u: goto L_060B0A82; case 0x060B0A84u: goto L_060B0A84; case 0x060B0A86u: goto L_060B0A86; case 0x060B0A88u: goto L_060B0A88; case 0x060B0A8Au: goto L_060B0A8A; case 0x060B0A8Eu: goto L_060B0A8E; case 0x060B0A90u: goto L_060B0A90; case 0x060B0A92u: goto L_060B0A92; case 0x060B0A96u: goto L_060B0A96; case 0x060B0A98u: goto L_060B0A98; case 0x060B0A9Au: goto L_060B0A9A; case 0x060B0A9Cu: goto L_060B0A9C; case 0x060B0A9Eu: goto L_060B0A9E; case 0x060B0AA2u: goto L_060B0AA2; case 0x060B0AA4u: goto L_060B0AA4; case 0x060B0AA6u: goto L_060B0AA6; case 0x060B0AA8u: goto L_060B0AA8; case 0x060B0AAAu: goto L_060B0AAA; case 0x060B0AAEu: goto L_060B0AAE; case 0x060B0AB0u: goto L_060B0AB0; case 0x060B0AB2u: goto L_060B0AB2; case 0x060B0AB4u: goto L_060B0AB4; case 0x060B0AB6u: goto L_060B0AB6; case 0x060B0ABAu: goto L_060B0ABA; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C7C jmp @r5 ; mov.l r4,@(16,r11)
L_060B7C80:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C80 mov.l @r9+,r5
L_060B7C82:
    c.r[15] += 4;  // 060B7C82 add #4,r15
L_060B7C84:
    st32(c.r[11] + 24, c.r[4]);  // 060B7C84 mov.l r4,@(24,r11)
L_060B7C86:
    st32(c.r[11] + 20, c.r[3]);  // 060B7C86 mov.l r3,@(20,r11)
L_060B7C88:
    st32(c.r[11] + 16, c.r[2]);  // 060B7C88 mov.l r2,@(16,r11)
L_060B7C8A:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[1]); SH2_POLL(c); switch (x) { case 0x060B0A20u: goto L_060B0A20; case 0x060B0A22u: goto L_060B0A22; case 0x060B0A24u: goto L_060B0A24; case 0x060B0A26u: goto L_060B0A26; case 0x060B0A28u: goto L_060B0A28; case 0x060B0A2Au: goto L_060B0A2A; case 0x060B0A2Cu: goto L_060B0A2C; case 0x060B0A2Eu: goto L_060B0A2E; case 0x060B0A30u: goto L_060B0A30; case 0x060B0A32u: goto L_060B0A32; case 0x060B0A36u: goto L_060B0A36; case 0x060B0A38u: goto L_060B0A38; case 0x060B0A3Au: goto L_060B0A3A; case 0x060B0A3Cu: goto L_060B0A3C; case 0x060B0A3Eu: goto L_060B0A3E; case 0x060B0A42u: goto L_060B0A42; case 0x060B0A44u: goto L_060B0A44; case 0x060B0A46u: goto L_060B0A46; case 0x060B0A48u: goto L_060B0A48; case 0x060B0A4Au: goto L_060B0A4A; case 0x060B0A4Eu: goto L_060B0A4E; case 0x060B0A50u: goto L_060B0A50; case 0x060B0A52u: goto L_060B0A52; case 0x060B0A56u: goto L_060B0A56; case 0x060B0A58u: goto L_060B0A58; case 0x060B0A5Au: goto L_060B0A5A; case 0x060B0A5Cu: goto L_060B0A5C; case 0x060B0A5Eu: goto L_060B0A5E; case 0x060B0A62u: goto L_060B0A62; case 0x060B0A64u: goto L_060B0A64; case 0x060B0A66u: goto L_060B0A66; case 0x060B0A68u: goto L_060B0A68; case 0x060B0A6Au: goto L_060B0A6A; case 0x060B0A6Eu: goto L_060B0A6E; case 0x060B0A70u: goto L_060B0A70; case 0x060B0A72u: goto L_060B0A72; case 0x060B0A76u: goto L_060B0A76; case 0x060B0A78u: goto L_060B0A78; case 0x060B0A7Au: goto L_060B0A7A; case 0x060B0A7Cu: goto L_060B0A7C; case 0x060B0A7Eu: goto L_060B0A7E; case 0x060B0A82u: goto L_060B0A82; case 0x060B0A84u: goto L_060B0A84; case 0x060B0A86u: goto L_060B0A86; case 0x060B0A88u: goto L_060B0A88; case 0x060B0A8Au: goto L_060B0A8A; case 0x060B0A8Eu: goto L_060B0A8E; case 0x060B0A90u: goto L_060B0A90; case 0x060B0A92u: goto L_060B0A92; case 0x060B0A96u: goto L_060B0A96; case 0x060B0A98u: goto L_060B0A98; case 0x060B0A9Au: goto L_060B0A9A; case 0x060B0A9Cu: goto L_060B0A9C; case 0x060B0A9Eu: goto L_060B0A9E; case 0x060B0AA2u: goto L_060B0AA2; case 0x060B0AA4u: goto L_060B0AA4; case 0x060B0AA6u: goto L_060B0AA6; case 0x060B0AA8u: goto L_060B0AA8; case 0x060B0AAAu: goto L_060B0AAA; case 0x060B0AAEu: goto L_060B0AAE; case 0x060B0AB0u: goto L_060B0AB0; case 0x060B0AB2u: goto L_060B0AB2; case 0x060B0AB4u: goto L_060B0AB4; case 0x060B0AB6u: goto L_060B0AB6; case 0x060B0ABAu: goto L_060B0ABA; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C8A jmp @r5 ; mov.l r1,@(12,r11)
}

void f_060B0B00(SH2Context& c) {
    ran[3035] = 1;
L_060B0B00:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060B0B00 mov.l r2,@-r15
L_060B0B02:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B0B02 mov.l r1,@-r15
L_060B0B04:
    c.r[1] = ld32(0x060B0B44u);  // 060B0B04 mov.l 0x060B0B44,r1
L_060B0B06:
    c.r[13] = ld32(c.r[1]);  // 060B0B06 mov.l @(0,r1),r13
L_060B0B08:
    c.r[12] = ld32(c.r[1] + 4);  // 060B0B08 mov.l @(4,r1),r12
L_060B0B0A:
    c.r[5] = c.r[14];  // 060B0B0A mov r14,r5
L_060B0B0C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[5];  // 060B0B0C cmp/ge r5,r13
L_060B0B0E:
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060B0B2A; } }  // 060B0B0E bt/s 0x060B0B2A ; mov #0,r0
L_060B0B12:
    c.r[5] -= c.r[13];  // 060B0B12 sub r13,r5
L_060B0B14:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[12];  // 060B0B14 cmp/ge r12,r5
L_060B0B16:
    { const bool k = c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 10); if (k) { goto L_060B0B2A; } }  // 060B0B16 bt/s 0x060B0B2A ; mov.w @(10,r1),r0
L_060B0B1A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 8);  // 060B0B1A mov.w @(8,r1),r0
L_060B0B1C:
    c.r[2] = c.r[0];  // 060B0B1C mov r0,r2
L_060B0B1E:
    c.t = c.r[0] == 0x0u;  // 060B0B1E cmp/eq #0,r0
L_060B0B20:
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060B0B2A; } }  // 060B0B20 bt/s 0x060B0B2A ; mov r5,r0
L_060B0B24:
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060B0B24 dt r2
L_060B0B26:
    { const bool k = !c.t; c.t = c.r[0] & 1; c.r[0] >>= 1; if (k) { SH2_POLL(c); goto L_060B0B24; } }  // 060B0B26 bf/s 0x060B0B24 ; shlr r0
L_060B0B2A:
    c.r[5] = c.r[0];  // 060B0B2A mov r0,r5
L_060B0B2C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 12);  // 060B0B2C mov.w @(12,r1),r0
L_060B0B2E:
    c.r[0] += c.r[5];  // 060B0B2E add r5,r0
L_060B0B30:
    st16(c.r[8] + 8, c.r[0]);  // 060B0B30 mov.w r0,@(8,r8)
L_060B0B32:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 4);  // 060B0B32 mov.w @(4,r8),r0
L_060B0B34:
    c.r[0] |= 0x4u;  // 060B0B34 or #4,r0
L_060B0B36:
    st16(c.r[8] + 4, c.r[0]);  // 060B0B36 mov.w r0,@(4,r8)
L_060B0B38:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B0B38 mov.l @r15+,r1
L_060B0B3A:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B0B3A mov.l @r15+,r2
L_060B0B3C:
    c.r[0] = ld32(0x060B0B48u);  // 060B0B3C mov.l 0x060B0B48,r0
L_060B0B3E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0B00u: goto L_060B0B00; case 0x060B0B02u: goto L_060B0B02; case 0x060B0B04u: goto L_060B0B04; case 0x060B0B06u: goto L_060B0B06; case 0x060B0B08u: goto L_060B0B08; case 0x060B0B0Au: goto L_060B0B0A; case 0x060B0B0Cu: goto L_060B0B0C; case 0x060B0B0Eu: goto L_060B0B0E; case 0x060B0B12u: goto L_060B0B12; case 0x060B0B14u: goto L_060B0B14; case 0x060B0B16u: goto L_060B0B16; case 0x060B0B1Au: goto L_060B0B1A; case 0x060B0B1Cu: goto L_060B0B1C; case 0x060B0B1Eu: goto L_060B0B1E; case 0x060B0B20u: goto L_060B0B20; case 0x060B0B24u: goto L_060B0B24; case 0x060B0B26u: goto L_060B0B26; case 0x060B0B2Au: goto L_060B0B2A; case 0x060B0B2Cu: goto L_060B0B2C; case 0x060B0B2Eu: goto L_060B0B2E; case 0x060B0B30u: goto L_060B0B30; case 0x060B0B32u: goto L_060B0B32; case 0x060B0B34u: goto L_060B0B34; case 0x060B0B36u: goto L_060B0B36; case 0x060B0B38u: goto L_060B0B38; case 0x060B0B3Au: goto L_060B0B3A; case 0x060B0B3Cu: goto L_060B0B3C; case 0x060B0B3Eu: goto L_060B0B3E; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B0B3E jmp @r0 ; nop
L_060B7958:
    c.r[5] >>= 16;  // 060B7958 shlr16 r5
L_060B795A:
    c.r[5] >>= 2;  // 060B795A shlr2 r5
L_060B795C:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B795C shlr r5
L_060B795E:
    if (!c.t) { goto L_060B7966; }  // 060B795E bf 0x060B7966
L_060B7960:
    c.r[1] = ld32(c.r[1]);  // 060B7960 mov.l @(0,r1),r1
L_060B7962:
    c.r[5] = ld32(c.r[2]); goto L_060B7A08;  // 060B7962 bra 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7966:
    c.r[0] = ld32(c.r[1] + 4);  // 060B7966 mov.l @(4,r1),r0
L_060B7968:
    c.r[1] = ld32(c.r[1]);  // 060B7968 mov.l @(0,r1),r1
L_060B796A:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B796A tst #1,r0
L_060B796C:
    { const bool k = c.t; c.r[5] = ld32(c.r[2]); if (k) { goto L_060B7A08; } }  // 060B796C bt/s 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7970:
    c.r[0] = ld32(c.r[2] + 4);  // 060B7970 mov.l @(4,r2),r0
L_060B7972:
    c.r[2] = c.r[5];  // 060B7972 mov r5,r2
L_060B7974:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7974 tst #1,r0
L_060B7976:
    { const bool k = c.t; c.r[5] = ld32(c.r[3]); if (k) { goto L_060B7A1E; } }  // 060B7976 bt/s 0x060B7A1E ; mov.l @(0,r3),r5
L_060B797A:
    c.r[0] = ld32(c.r[3] + 4);  // 060B797A mov.l @(4,r3),r0
L_060B797C:
    c.r[3] = c.r[5];  // 060B797C mov r5,r3
L_060B797E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B797E tst #1,r0
L_060B7980:
    { const bool k = c.t; c.r[5] = ld32(c.r[4]); if (k) { goto L_060B7A34; } }  // 060B7980 bt/s 0x060B7A34 ; mov.l @(0,r4),r5
L_060B7984:
    c.r[0] = ld32(c.r[4] + 4);  // 060B7984 mov.l @(4,r4),r0
L_060B7986:
    c.r[4] = c.r[5];  // 060B7986 mov r5,r4
L_060B7988:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7988 tst #1,r0
L_060B798A:
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_060B7A4A; } }  // 060B798A bt/s 0x060B7A4A ; mov #1,r5
L_060B798E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B798E mov.l r9,@-r15
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B0B00u: goto L_060B0B00; case 0x060B0B02u: goto L_060B0B02; case 0x060B0B04u: goto L_060B0B04; case 0x060B0B06u: goto L_060B0B06; case 0x060B0B08u: goto L_060B0B08; case 0x060B0B0Au: goto L_060B0B0A; case 0x060B0B0Cu: goto L_060B0B0C; case 0x060B0B0Eu: goto L_060B0B0E; case 0x060B0B12u: goto L_060B0B12; case 0x060B0B14u: goto L_060B0B14; case 0x060B0B16u: goto L_060B0B16; case 0x060B0B1Au: goto L_060B0B1A; case 0x060B0B1Cu: goto L_060B0B1C; case 0x060B0B1Eu: goto L_060B0B1E; case 0x060B0B20u: goto L_060B0B20; case 0x060B0B24u: goto L_060B0B24; case 0x060B0B26u: goto L_060B0B26; case 0x060B0B2Au: goto L_060B0B2A; case 0x060B0B2Cu: goto L_060B0B2C; case 0x060B0B2Eu: goto L_060B0B2E; case 0x060B0B30u: goto L_060B0B30; case 0x060B0B32u: goto L_060B0B32; case 0x060B0B34u: goto L_060B0B34; case 0x060B0B36u: goto L_060B0B36; case 0x060B0B38u: goto L_060B0B38; case 0x060B0B3Au: goto L_060B0B3A; case 0x060B0B3Cu: goto L_060B0B3C; case 0x060B0B3Eu: goto L_060B0B3E; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A08:
    c.r[3] = ld32(c.r[3]);  // 060B7A08 mov.l @(0,r3),r3
L_060B7A0A:
    c.r[2] = c.r[5];  // 060B7A0A mov r5,r2
L_060B7A0C:
    c.r[4] = ld32(c.r[4]);  // 060B7A0C mov.l @(0,r4),r4
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0B00u: goto L_060B0B00; case 0x060B0B02u: goto L_060B0B02; case 0x060B0B04u: goto L_060B0B04; case 0x060B0B06u: goto L_060B0B06; case 0x060B0B08u: goto L_060B0B08; case 0x060B0B0Au: goto L_060B0B0A; case 0x060B0B0Cu: goto L_060B0B0C; case 0x060B0B0Eu: goto L_060B0B0E; case 0x060B0B12u: goto L_060B0B12; case 0x060B0B14u: goto L_060B0B14; case 0x060B0B16u: goto L_060B0B16; case 0x060B0B1Au: goto L_060B0B1A; case 0x060B0B1Cu: goto L_060B0B1C; case 0x060B0B1Eu: goto L_060B0B1E; case 0x060B0B20u: goto L_060B0B20; case 0x060B0B24u: goto L_060B0B24; case 0x060B0B26u: goto L_060B0B26; case 0x060B0B2Au: goto L_060B0B2A; case 0x060B0B2Cu: goto L_060B0B2C; case 0x060B0B2Eu: goto L_060B0B2E; case 0x060B0B30u: goto L_060B0B30; case 0x060B0B32u: goto L_060B0B32; case 0x060B0B34u: goto L_060B0B34; case 0x060B0B36u: goto L_060B0B36; case 0x060B0B38u: goto L_060B0B38; case 0x060B0B3Au: goto L_060B0B3A; case 0x060B0B3Cu: goto L_060B0B3C; case 0x060B0B3Eu: goto L_060B0B3E; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
L_060B7A1E:
    c.r[4] = ld32(c.r[4]);  // 060B7A1E mov.l @(0,r4),r4
L_060B7A20:
    c.r[3] = c.r[5];  // 060B7A20 mov r5,r3
L_060B7A22:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A22 mov.l @r9+,r5
L_060B7A24:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A24 mov.w @(0,r11),r0
L_060B7A26:
    st32(c.r[11] + 16, c.r[1]);  // 060B7A26 mov.l r1,@(16,r11)
L_060B7A28:
    c.r[0] ^= 0x10u;  // 060B7A28 xor #16,r0
L_060B7A2A:
    st16(c.r[11], c.r[0]);  // 060B7A2A mov.w r0,@(0,r11)
L_060B7A2C:
    st32(c.r[11] + 12, c.r[2]);  // 060B7A2C mov.l r2,@(12,r11)
L_060B7A2E:
    st32(c.r[11] + 24, c.r[3]);  // 060B7A2E mov.l r3,@(24,r11)
L_060B7A30:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0B00u: goto L_060B0B00; case 0x060B0B02u: goto L_060B0B02; case 0x060B0B04u: goto L_060B0B04; case 0x060B0B06u: goto L_060B0B06; case 0x060B0B08u: goto L_060B0B08; case 0x060B0B0Au: goto L_060B0B0A; case 0x060B0B0Cu: goto L_060B0B0C; case 0x060B0B0Eu: goto L_060B0B0E; case 0x060B0B12u: goto L_060B0B12; case 0x060B0B14u: goto L_060B0B14; case 0x060B0B16u: goto L_060B0B16; case 0x060B0B1Au: goto L_060B0B1A; case 0x060B0B1Cu: goto L_060B0B1C; case 0x060B0B1Eu: goto L_060B0B1E; case 0x060B0B20u: goto L_060B0B20; case 0x060B0B24u: goto L_060B0B24; case 0x060B0B26u: goto L_060B0B26; case 0x060B0B2Au: goto L_060B0B2A; case 0x060B0B2Cu: goto L_060B0B2C; case 0x060B0B2Eu: goto L_060B0B2E; case 0x060B0B30u: goto L_060B0B30; case 0x060B0B32u: goto L_060B0B32; case 0x060B0B34u: goto L_060B0B34; case 0x060B0B36u: goto L_060B0B36; case 0x060B0B38u: goto L_060B0B38; case 0x060B0B3Au: goto L_060B0B3A; case 0x060B0B3Cu: goto L_060B0B3C; case 0x060B0B3Eu: goto L_060B0B3E; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A30 jmp @r5 ; mov.l r4,@(20,r11)
L_060B7A34:
    c.r[4] = c.r[5];  // 060B7A34 mov r5,r4
L_060B7A36:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A36 mov.l @r9+,r5
L_060B7A38:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A38 mov.w @(0,r11),r0
L_060B7A3A:
    st32(c.r[11] + 20, c.r[1]);  // 060B7A3A mov.l r1,@(20,r11)
L_060B7A3C:
    c.r[0] ^= 0x30u;  // 060B7A3C xor #48,r0
L_060B7A3E:
    st16(c.r[11], c.r[0]);  // 060B7A3E mov.w r0,@(0,r11)
L_060B7A40:
    st32(c.r[11] + 24, c.r[2]);  // 060B7A40 mov.l r2,@(24,r11)
L_060B7A42:
    st32(c.r[11] + 12, c.r[3]);  // 060B7A42 mov.l r3,@(12,r11)
L_060B7A44:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0B00u: goto L_060B0B00; case 0x060B0B02u: goto L_060B0B02; case 0x060B0B04u: goto L_060B0B04; case 0x060B0B06u: goto L_060B0B06; case 0x060B0B08u: goto L_060B0B08; case 0x060B0B0Au: goto L_060B0B0A; case 0x060B0B0Cu: goto L_060B0B0C; case 0x060B0B0Eu: goto L_060B0B0E; case 0x060B0B12u: goto L_060B0B12; case 0x060B0B14u: goto L_060B0B14; case 0x060B0B16u: goto L_060B0B16; case 0x060B0B1Au: goto L_060B0B1A; case 0x060B0B1Cu: goto L_060B0B1C; case 0x060B0B1Eu: goto L_060B0B1E; case 0x060B0B20u: goto L_060B0B20; case 0x060B0B24u: goto L_060B0B24; case 0x060B0B26u: goto L_060B0B26; case 0x060B0B2Au: goto L_060B0B2A; case 0x060B0B2Cu: goto L_060B0B2C; case 0x060B0B2Eu: goto L_060B0B2E; case 0x060B0B30u: goto L_060B0B30; case 0x060B0B32u: goto L_060B0B32; case 0x060B0B34u: goto L_060B0B34; case 0x060B0B36u: goto L_060B0B36; case 0x060B0B38u: goto L_060B0B38; case 0x060B0B3Au: goto L_060B0B3A; case 0x060B0B3Cu: goto L_060B0B3C; case 0x060B0B3Eu: goto L_060B0B3E; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A44 jmp @r5 ; mov.l r4,@(16,r11)
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B0B00u: goto L_060B0B00; case 0x060B0B02u: goto L_060B0B02; case 0x060B0B04u: goto L_060B0B04; case 0x060B0B06u: goto L_060B0B06; case 0x060B0B08u: goto L_060B0B08; case 0x060B0B0Au: goto L_060B0B0A; case 0x060B0B0Cu: goto L_060B0B0C; case 0x060B0B0Eu: goto L_060B0B0E; case 0x060B0B12u: goto L_060B0B12; case 0x060B0B14u: goto L_060B0B14; case 0x060B0B16u: goto L_060B0B16; case 0x060B0B1Au: goto L_060B0B1A; case 0x060B0B1Cu: goto L_060B0B1C; case 0x060B0B1Eu: goto L_060B0B1E; case 0x060B0B20u: goto L_060B0B20; case 0x060B0B24u: goto L_060B0B24; case 0x060B0B26u: goto L_060B0B26; case 0x060B0B2Au: goto L_060B0B2A; case 0x060B0B2Cu: goto L_060B0B2C; case 0x060B0B2Eu: goto L_060B0B2E; case 0x060B0B30u: goto L_060B0B30; case 0x060B0B32u: goto L_060B0B32; case 0x060B0B34u: goto L_060B0B34; case 0x060B0B36u: goto L_060B0B36; case 0x060B0B38u: goto L_060B0B38; case 0x060B0B3Au: goto L_060B0B3A; case 0x060B0B3Cu: goto L_060B0B3C; case 0x060B0B3Eu: goto L_060B0B3E; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
}

void f_060B0CE4(SH2Context& c) {
    ran[3036] = 1;
    goto L_060B0CE4;
L_060B0B4C:
    c.r[0] = ld32(0x060B0E20u);  // 060B0B4C mov.l 0x060B0E20,r0
    c.r[1] = 0x0u;  // 060B0B4E mov #0,r1
L_060B0B50:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[0];  // 060B0B50 cmp/gt r0,r3
    if (!c.t) { goto L_060B0B5C; }  // 060B0B52 bf 0x060B0B5C
    c.r[1] = 0x1u;  // 060B0B54 mov #1,r1
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B0B56 shar r3
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0B50;  // 060B0B58 bra 0x060B0B50 ; shar r5
L_060B0B5C:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 060B0B5C cmp/gt r0,r5
    if (!c.t) { goto L_060B0B68; }  // 060B0B5E bf 0x060B0B68
    c.r[1] = 0x1u;  // 060B0B60 mov #1,r1
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B0B62 shar r3
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0B5C;  // 060B0B64 bra 0x060B0B5C ; shar r5
L_060B0B68:
    c.r[0] = 0u - c.r[0];  // 060B0B68 neg r0,r0
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 060B0B6A cmp/ge r0,r3
    if (c.t) { goto L_060B0B76; }  // 060B0B6C bt 0x060B0B76
    c.r[1] = 0x1u;  // 060B0B6E mov #1,r1
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B0B70 shar r3
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0B68;  // 060B0B72 bra 0x060B0B68 ; shar r5
L_060B0B76:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[0];  // 060B0B76 cmp/ge r0,r5
    if (c.t) { goto L_060B0B82; }  // 060B0B78 bt 0x060B0B82
    c.r[1] = 0x1u;  // 060B0B7A mov #1,r1
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B0B7C shar r3
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0B76;  // 060B0B7E bra 0x060B0B76 ; shar r5
L_060B0B82:
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B0B82 tst r1,r1
    if (!c.t) { goto L_060B0B8A; }  // 060B0B84 bf 0x060B0B8A
    goto L_060B0DAE;  // 060B0B86 bra 0x060B0DAE ; nop
L_060B0B8A:
    c.r[0] = c.r[3];  // 060B0B8A mov r3,r0
    c.r[1] = c.r[5];  // 060B0B8C mov r5,r1
    c.r[4] = c.r[3];  // 060B0B8E mov r3,r4
    c.r[7] = c.r[5];  // 060B0B90 mov r5,r7
    c.t = (int32_t)c.r[0] >= 0;  // 060B0B92 cmp/pz r0
    if (c.t) { goto L_060B0B98; }  // 060B0B94 bt 0x060B0B98
    c.r[0] = 0u - c.r[0];  // 060B0B96 neg r0,r0
L_060B0B98:
    c.t = (int32_t)c.r[1] >= 0;  // 060B0B98 cmp/pz r1
    if (c.t) { goto L_060B0B9E; }  // 060B0B9A bt 0x060B0B9E
    c.r[1] = 0u - c.r[1];  // 060B0B9C neg r1,r1
L_060B0B9E:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060B0B9E cmp/ge r0,r1
    { const bool k = c.t; c.r[0] = 0x4u; if (k) { goto L_060B0BDE; } }  // 060B0BA0 bt/s 0x060B0BDE ; mov #4,r0
    c.t = (int32_t)c.r[3] >= 0;  // 060B0BA4 cmp/pz r3
    if (!c.t) { goto L_060B0BC2; }  // 060B0BA6 bf 0x060B0BC2
    c.r[1] = ld32(0x060B0E20u);  // 060B0BA8 mov.l 0x060B0E20,r1
L_060B0BAA:
    c.r[3] += c.r[4];  // 060B0BAA add r4,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060B0BAC cmp/gt r1,r3
    { const bool k = c.t; c.r[3] -= c.r[4]; if (k) { goto L_060B0BB6; } }  // 060B0BAE bt/s 0x060B0BB6 ; sub r4,r3
    c.r[5] += c.r[7];  // 060B0BB2 add r7,r5
    c.r[3] += c.r[4];  // 060B0BB4 add r4,r3
L_060B0BB6:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B0BB6 shar r7
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0BB8 dt r0
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B0BAA; } }  // 060B0BBA bf/s 0x060B0BAA ; shar r4
    goto L_060B0DAE;  // 060B0BBE bra 0x060B0DAE ; nop
L_060B0BC2:
    c.r[1] = ld32(0x060B0E20u);  // 060B0BC2 mov.l 0x060B0E20,r1
    c.r[1] = 0u - c.r[1];  // 060B0BC4 neg r1,r1
L_060B0BC6:
    c.r[3] += c.r[4];  // 060B0BC6 add r4,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060B0BC8 cmp/ge r1,r3
    { const bool k = !c.t; c.r[3] -= c.r[4]; if (k) { goto L_060B0BD2; } }  // 060B0BCA bf/s 0x060B0BD2 ; sub r4,r3
    c.r[5] += c.r[7];  // 060B0BCE add r7,r5
    c.r[3] += c.r[4];  // 060B0BD0 add r4,r3
L_060B0BD2:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B0BD2 shar r7
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0BD4 dt r0
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B0BC6; } }  // 060B0BD6 bf/s 0x060B0BC6 ; shar r4
    goto L_060B0DAE;  // 060B0BDA bra 0x060B0DAE ; nop
L_060B0BDE:
    c.t = (int32_t)c.r[5] >= 0;  // 060B0BDE cmp/pz r5
    if (!c.t) { goto L_060B0BFC; }  // 060B0BE0 bf 0x060B0BFC
    c.r[1] = ld32(0x060B0E20u);  // 060B0BE2 mov.l 0x060B0E20,r1
L_060B0BE4:
    c.r[5] += c.r[7];  // 060B0BE4 add r7,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060B0BE6 cmp/gt r1,r5
    { const bool k = c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B0BF0; } }  // 060B0BE8 bt/s 0x060B0BF0 ; sub r7,r5
    c.r[3] += c.r[4];  // 060B0BEC add r4,r3
    c.r[5] += c.r[7];  // 060B0BEE add r7,r5
L_060B0BF0:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B0BF0 shar r4
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0BF2 dt r0
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B0BE4; } }  // 060B0BF4 bf/s 0x060B0BE4 ; shar r7
    goto L_060B0DAE;  // 060B0BF8 bra 0x060B0DAE ; nop
L_060B0BFC:
    c.r[1] = ld32(0x060B0E20u);  // 060B0BFC mov.l 0x060B0E20,r1
    c.r[1] = 0u - c.r[1];  // 060B0BFE neg r1,r1
L_060B0C00:
    c.r[5] += c.r[7];  // 060B0C00 add r7,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060B0C02 cmp/ge r1,r5
    { const bool k = !c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B0C0C; } }  // 060B0C04 bf/s 0x060B0C0C ; sub r7,r5
    c.r[3] += c.r[4];  // 060B0C08 add r4,r3
    c.r[5] += c.r[7];  // 060B0C0A add r7,r5
L_060B0C0C:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B0C0C shar r4
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0C0E dt r0
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B0C00; } }  // 060B0C10 bf/s 0x060B0C00 ; shar r7
    goto L_060B0DAE;  // 060B0C14 bra 0x060B0DAE ; nop
L_060B0C18:
    c.r[0] = ld32(0x060B0E20u);  // 060B0C18 mov.l 0x060B0E20,r0
    c.r[1] = 0x0u;  // 060B0C1A mov #0,r1
L_060B0C1C:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[0];  // 060B0C1C cmp/gt r0,r2
    if (!c.t) { goto L_060B0C28; }  // 060B0C1E bf 0x060B0C28
    c.r[1] = 0x1u;  // 060B0C20 mov #1,r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B0C22 shar r2
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0C1C;  // 060B0C24 bra 0x060B0C1C ; shar r5
L_060B0C28:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 060B0C28 cmp/gt r0,r5
    if (!c.t) { goto L_060B0C34; }  // 060B0C2A bf 0x060B0C34
    c.r[1] = 0x1u;  // 060B0C2C mov #1,r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B0C2E shar r2
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0C28;  // 060B0C30 bra 0x060B0C28 ; shar r5
L_060B0C34:
    c.r[0] = 0u - c.r[0];  // 060B0C34 neg r0,r0
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[0];  // 060B0C36 cmp/ge r0,r2
    if (c.t) { goto L_060B0C42; }  // 060B0C38 bt 0x060B0C42
    c.r[1] = 0x1u;  // 060B0C3A mov #1,r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B0C3C shar r2
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0C34;  // 060B0C3E bra 0x060B0C34 ; shar r5
L_060B0C42:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[0];  // 060B0C42 cmp/ge r0,r5
    if (c.t) { goto L_060B0C4E; }  // 060B0C44 bt 0x060B0C4E
    c.r[1] = 0x1u;  // 060B0C46 mov #1,r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B0C48 shar r2
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B0C42;  // 060B0C4A bra 0x060B0C42 ; shar r5
L_060B0C4E:
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B0C4E tst r1,r1
    if (!c.t) { goto L_060B0C56; }  // 060B0C50 bf 0x060B0C56
    goto L_060B0E12;  // 060B0C52 bra 0x060B0E12 ; nop
L_060B0C56:
    c.r[0] = c.r[2];  // 060B0C56 mov r2,r0
    c.r[1] = c.r[5];  // 060B0C58 mov r5,r1
    c.r[4] = c.r[2];  // 060B0C5A mov r2,r4
    c.r[7] = c.r[5];  // 060B0C5C mov r5,r7
    c.t = (int32_t)c.r[0] >= 0;  // 060B0C5E cmp/pz r0
    if (c.t) { goto L_060B0C64; }  // 060B0C60 bt 0x060B0C64
    c.r[0] = 0u - c.r[0];  // 060B0C62 neg r0,r0
L_060B0C64:
    c.t = (int32_t)c.r[1] >= 0;  // 060B0C64 cmp/pz r1
    if (c.t) { goto L_060B0C6A; }  // 060B0C66 bt 0x060B0C6A
    c.r[1] = 0u - c.r[1];  // 060B0C68 neg r1,r1
L_060B0C6A:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060B0C6A cmp/ge r0,r1
    { const bool k = c.t; c.r[0] = 0x4u; if (k) { goto L_060B0CAA; } }  // 060B0C6C bt/s 0x060B0CAA ; mov #4,r0
    c.t = (int32_t)c.r[2] >= 0;  // 060B0C70 cmp/pz r2
    if (!c.t) { goto L_060B0C8E; }  // 060B0C72 bf 0x060B0C8E
    c.r[1] = ld32(0x060B0E20u);  // 060B0C74 mov.l 0x060B0E20,r1
L_060B0C76:
    c.r[2] += c.r[4];  // 060B0C76 add r4,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060B0C78 cmp/gt r1,r2
    { const bool k = c.t; c.r[2] -= c.r[4]; if (k) { goto L_060B0C82; } }  // 060B0C7A bt/s 0x060B0C82 ; sub r4,r2
    c.r[5] += c.r[7];  // 060B0C7E add r7,r5
    c.r[2] += c.r[4];  // 060B0C80 add r4,r2
L_060B0C82:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B0C82 shar r7
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0C84 dt r0
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B0C76; } }  // 060B0C86 bf/s 0x060B0C76 ; shar r4
    goto L_060B0E12;  // 060B0C8A bra 0x060B0E12 ; nop
L_060B0C8E:
    c.r[1] = ld32(0x060B0E20u);  // 060B0C8E mov.l 0x060B0E20,r1
    c.r[1] = 0u - c.r[1];  // 060B0C90 neg r1,r1
L_060B0C92:
    c.r[2] += c.r[4];  // 060B0C92 add r4,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060B0C94 cmp/ge r1,r2
    { const bool k = !c.t; c.r[2] -= c.r[4]; if (k) { goto L_060B0C9E; } }  // 060B0C96 bf/s 0x060B0C9E ; sub r4,r2
    c.r[5] += c.r[7];  // 060B0C9A add r7,r5
    c.r[2] += c.r[4];  // 060B0C9C add r4,r2
L_060B0C9E:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B0C9E shar r7
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0CA0 dt r0
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B0C92; } }  // 060B0CA2 bf/s 0x060B0C92 ; shar r4
    goto L_060B0E12;  // 060B0CA6 bra 0x060B0E12 ; nop
L_060B0CAA:
    c.t = (int32_t)c.r[5] >= 0;  // 060B0CAA cmp/pz r5
    if (!c.t) { goto L_060B0CC8; }  // 060B0CAC bf 0x060B0CC8
    c.r[1] = ld32(0x060B0E20u);  // 060B0CAE mov.l 0x060B0E20,r1
L_060B0CB0:
    c.r[5] += c.r[7];  // 060B0CB0 add r7,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060B0CB2 cmp/gt r1,r5
    { const bool k = c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B0CBC; } }  // 060B0CB4 bt/s 0x060B0CBC ; sub r7,r5
    c.r[2] += c.r[4];  // 060B0CB8 add r4,r2
    c.r[5] += c.r[7];  // 060B0CBA add r7,r5
L_060B0CBC:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B0CBC shar r4
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0CBE dt r0
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B0CB0; } }  // 060B0CC0 bf/s 0x060B0CB0 ; shar r7
    goto L_060B0E12;  // 060B0CC4 bra 0x060B0E12 ; nop
L_060B0CC8:
    c.r[1] = ld32(0x060B0E20u);  // 060B0CC8 mov.l 0x060B0E20,r1
    c.r[1] = 0u - c.r[1];  // 060B0CCA neg r1,r1
L_060B0CCC:
    c.r[5] += c.r[7];  // 060B0CCC add r7,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060B0CCE cmp/ge r1,r5
    { const bool k = !c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B0CD8; } }  // 060B0CD0 bf/s 0x060B0CD8 ; sub r7,r5
    c.r[2] += c.r[4];  // 060B0CD4 add r4,r2
    c.r[5] += c.r[7];  // 060B0CD6 add r7,r5
L_060B0CD8:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B0CD8 shar r4
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0CDA dt r0
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B0CCC; } }  // 060B0CDC bf/s 0x060B0CCC ; shar r7
    goto L_060B0E12;  // 060B0CE0 bra 0x060B0E12 ; nop
L_060B0CE4:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060B0CE4 tst r9,r9
    { const bool k = !c.t; c.r[6] += 32; if (k) { goto L_060B0CEC; } }  // 060B0CE6 bf/s 0x060B0CEC ; add #32,r6
    c.r[0] = ld32(c.gbr + 104); goto L_060B0E1C;  // 060B0CEA bra 0x060B0E1C ; mov.l @(104,gbr),r0
L_060B0CEC:
    c.r[0] = ld32(c.gbr + 104);  // 060B0CEC mov.l @(104,gbr),r0
    c.r[2] = c.r[9];  // 060B0CEE mov r9,r2
    c.r[2] <<= 2;  // 060B0CF0 shll2 r2
    c.r[1] = c.r[2];  // 060B0CF2 mov r2,r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060B0CF4 shll r2
    c.r[2] += c.r[1];  // 060B0CF6 add r1,r2
    c.r[1] <<= 2;  // 060B0CF8 shll2 r1
    c.r[11] += c.r[1];  // 060B0CFA add r1,r11
    c.r[1] = ld32(c.r[11] + 12);  // 060B0CFC mov.l @(12,r11),r1
    c.r[14] = 0xFFFFFFFFu;  // 060B0CFE mov #-1,r14
    c.r[14] <<= 8;  // 060B0D00 shll8 r14
    st32(c.r[14], c.r[1]);  // 060B0D02 mov.l r1,@(0,r14)
    c.r[1] = c.r[0] << 16 | c.r[0] >> 16;  // 060B0D04 swap.w r0,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B0D06 exts.w r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 060B0D08 mov.l r1,@(16,r14)
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0D0A exts.w r0,r3
    st32(c.r[14] + 20, c.r[3]);  // 060B0D0C mov.l r3,@(20,r14)
    c.r[10] += c.r[2];  // 060B0D0E add r2,r10
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060B0D10 mov.l r7,@-r15
    c.r[10] -= 12;  // 060B0D12 add #-12,r10
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B0D14 mov.l r1,@-r15
    c.r[8] = c.r[0];  // 060B0D16 mov r0,r8
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B0D18 mov.l r3,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 173);  // 060B0D1A mov.b @(173,gbr),r0
    c.r[0] += 1;  // 060B0D1C add #1,r0
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B0D1E shlr r8
L_060B0D20:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B0D20 dt r0
    { const bool k = !c.t; c.t = c.r[8] & 1; c.r[8] >>= 1; if (k) { SH2_POLL(c); goto L_060B0D20; } }  // 060B0D22 bf/s 0x060B0D20 ; shlr r8
    c.r[0] = ld32(c.gbr + 132);  // 060B0D26 mov.l @(132,gbr),r0
    c.r[4] = ld32(c.r[11] + 4);  // 060B0D28 mov.l @(4,r11),r4
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B0D2A extu.w r0,r13
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B0D2C swap.w r0,r12
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B0D2E extu.w r12,r12
    c.r[5] = ld32(c.r[11] + 8);  // 060B0D30 mov.l @(8,r11),r5
    c.r[0] = ld32(c.gbr + 904);  // 060B0D32 mov.l @(904,gbr),r0
    c.r[12] += c.r[0];  // 060B0D34 add r0,r12
    c.r[13] += c.r[0];  // 060B0D36 add r0,r13
    c.r[12] += c.r[0];  // 060B0D38 add r0,r12
    c.r[13] += c.r[0];  // 060B0D3A add r0,r13
    c.r[0] = c.r[11];  // 060B0D3C mov r11,r0
    st32(c.gbr + 36, c.r[0]);  // 060B0D3E mov.l r0,@(36,gbr)
    c.r[7] = ld32(c.r[14] + 28);  // 060B0D40 mov.l @(28,r14),r7
L_060B0D42:
    c.mach = c.macl = 0;  // 060B0D42 clrmac
    sh2_mac_l(c, 6, 10);  // 060B0D44 mac.l @r10+,@r6+
    c.r[0] = ld32(c.r[15] + 4);  // 060B0D46 mov.l @(4,r15),r0
    sh2_mac_l(c, 6, 10);  // 060B0D48 mac.l @r10+,@r6+
    c.r[1] = ld32(c.r[6] + 4);  // 060B0D4A mov.l @(4,r6),r1
    sh2_mac_l(c, 6, 10);  // 060B0D4C mac.l @r10+,@r6+
    c.r[6] -= 44;  // 060B0D4E add #-44,r6
    c.r[10] -= 12;  // 060B0D50 add #-12,r10
    c.r[2] = c.mach;  // 060B0D52 sts mach,r2
    c.r[3] = c.macl;  // 060B0D54 sts macl,r3
    st32(c.r[14] + 16, c.r[0]);  // 060B0D56 mov.l r0,@(16,r14)
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B0D58 xtrct r2,r3
    c.r[3] += c.r[1];  // 060B0D5A add r1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060B0D5C cmp/ge r8,r3
    { const bool k = c.t; c.r[0] = ld32(c.r[15]); if (k) { goto L_060B0D64; } }  // 060B0D5E bt/s 0x060B0D64 ; mov.l @(0,r15),r0
    c.r[3] = c.r[8];  // 060B0D62 mov r8,r3
L_060B0D64:
    st32(c.r[14], c.r[3]);  // 060B0D64 mov.l r3,@(0,r14)
    c.r[11] -= 16;  // 060B0D66 add #-16,r11
    st32(c.r[14] + 20, c.r[0]);  // 060B0D68 mov.l r0,@(20,r14)
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B0D6A dmuls.l r4,r7
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 144);  // 060B0D6C mov.w @(144,gbr),r0
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B0D6E shlr r4
    st32(c.r[11] + 12, c.r[3]);  // 060B0D70 mov.l r3,@(12,r11)
    c.r[3] = c.mach;  // 060B0D72 sts mach,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B0D74 dmuls.l r5,r7
    c.r[0] += c.r[3];  // 060B0D76 add r3,r0
    st32(c.r[11] + 24, c.r[5]);  // 060B0D78 mov.l r5,@(24,r11)
    c.r[1] = c.r[0];  // 060B0D7A mov r0,r1
    c.r[0] = ld32(c.gbr + 904);  // 060B0D7C mov.l @(904,gbr),r0
    c.r[0] += c.r[1];  // 060B0D7E add r1,r0
    c.t = c.r[0] >= c.r[12];  // 060B0D80 cmp/hs r12,r0
    { uint64_t s = (uint64_t)c.r[4] + c.r[4] + c.t; c.t = (uint32_t)(s >> 32); c.r[4] = (uint32_t)s; }  // 060B0D82 addc r4,r4
    c.r[5] = c.mach;  // 060B0D84 sts mach,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 146);  // 060B0D86 mov.w @(146,gbr),r0
    c.mach = c.macl = 0;  // 060B0D88 clrmac
    sh2_mac_l(c, 6, 10);  // 060B0D8A mac.l @r10+,@r6+
    c.r[0] += c.r[5];  // 060B0D8C add r5,r0
    c.r[1] = c.r[0];  // 060B0D8E mov r0,r1
    c.r[0] = ld32(c.gbr + 904);  // 060B0D90 mov.l @(904,gbr),r0
    c.r[0] += c.r[1];  // 060B0D92 add r1,r0
    c.t = c.r[0] >= c.r[13];  // 060B0D94 cmp/hs r13,r0
    sh2_mac_l(c, 6, 10);  // 060B0D96 mac.l @r10+,@r6+
    c.r[0] = c.t;  // 060B0D98 movt r0
    c.r[4] |= c.r[0];  // 060B0D9A or r0,r4
    sh2_mac_l(c, 6, 10);  // 060B0D9C mac.l @r10+,@r6+
    st32(c.r[11] + 20, c.r[4]);  // 060B0D9E mov.l r4,@(20,r11)
    c.r[2] = ld32(c.r[6]); c.r[6] += 4;  // 060B0DA0 mov.l @r6+,r2
    c.r[0] = ld32(c.gbr + 888);  // 060B0DA2 mov.l @(888,gbr),r0
    c.r[4] &= c.r[0];  // 060B0DA4 and r0,r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B0DA6 shar r4
    if (!c.t) { goto L_060B0DAE; }  // 060B0DA8 bf 0x060B0DAE
    SH2_POLL(c); goto L_060B0B4C;  // 060B0DAA bra 0x060B0B4C ; nop
L_060B0DAE:
    c.r[5] <<= 16;  // 060B0DAE shll16 r5
    c.r[10] -= 12;  // 060B0DB0 add #-12,r10
    c.r[1] = c.mach;  // 060B0DB2 sts mach,r1
    c.r[4] = c.macl;  // 060B0DB4 sts macl,r4
    c.mach = c.macl = 0;  // 060B0DB6 clrmac
    sh2_mac_l(c, 6, 10);  // 060B0DB8 mac.l @r10+,@r6+
    c.r[5] = c.r[3] << 16 | c.r[5] >> 16;  // 060B0DBA xtrct r3,r5
    st32(c.r[11] + 16, c.r[5]);  // 060B0DBC mov.l r5,@(16,r11)
    sh2_mac_l(c, 6, 10);  // 060B0DBE mac.l @r10+,@r6+
    c.r[4] = c.r[1] << 16 | c.r[4] >> 16;  // 060B0DC0 xtrct r1,r4
    c.r[4] += c.r[2];  // 060B0DC2 add r2,r4
    sh2_mac_l(c, 6, 10);  // 060B0DC4 mac.l @r10+,@r6+
    c.r[2] = ld32(c.r[6]);  // 060B0DC6 mov.l @r6,r2
    c.r[6] += 4;  // 060B0DC8 add #4,r6
    c.r[10] -= 24;  // 060B0DCA add #-24,r10
    c.r[1] = c.mach;  // 060B0DCC sts mach,r1
    c.r[5] = c.macl;  // 060B0DCE sts macl,r5
    c.r[7] = ld32(c.r[14] + 28);  // 060B0DD0 mov.l @(28,r14),r7
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B0DD2 xtrct r1,r5
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060B0DD4 dt r9
    { const bool k = !c.t; c.r[5] += c.r[2]; if (k) { SH2_POLL(c); goto L_060B0D42; } }  // 060B0DD6 bf/s 0x060B0D42 ; add r2,r5
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B0DDA dmuls.l r4,r7
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 144);  // 060B0DDC mov.w @(144,gbr),r0
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B0DDE shlr r4
    st32(c.r[11] + 8, c.r[5]);  // 060B0DE0 mov.l r5,@(8,r11)
    c.r[2] = c.mach;  // 060B0DE2 sts mach,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B0DE4 dmuls.l r5,r7
    c.r[0] += c.r[2];  // 060B0DE6 add r2,r0
    c.r[1] = c.r[0];  // 060B0DE8 mov r0,r1
    c.r[0] = ld32(c.gbr + 904);  // 060B0DEA mov.l @(904,gbr),r0
    c.r[0] += c.r[1];  // 060B0DEC add r1,r0
    c.t = c.r[0] >= c.r[12];  // 060B0DEE cmp/hs r12,r0
    c.r[5] = c.mach;  // 060B0DF0 sts mach,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 146);  // 060B0DF2 mov.w @(146,gbr),r0
    { uint64_t s = (uint64_t)c.r[4] + c.r[4] + c.t; c.t = (uint32_t)(s >> 32); c.r[4] = (uint32_t)s; }  // 060B0DF4 addc r4,r4
    c.r[0] += c.r[5];  // 060B0DF6 add r5,r0
    c.r[1] = c.r[0];  // 060B0DF8 mov r0,r1
    c.r[0] = ld32(c.gbr + 904);  // 060B0DFA mov.l @(904,gbr),r0
    c.r[0] += c.r[1];  // 060B0DFC add r1,r0
    c.t = c.r[0] >= c.r[13];  // 060B0DFE cmp/hs r13,r0
    c.r[0] = c.t;  // 060B0E00 movt r0
    c.r[4] |= c.r[0];  // 060B0E02 or r0,r4
    st32(c.r[11] + 4, c.r[4]);  // 060B0E04 mov.l r4,@(4,r11)
    c.r[0] = ld32(c.gbr + 888);  // 060B0E06 mov.l @(888,gbr),r0
    c.r[4] &= c.r[0];  // 060B0E08 and r0,r4
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B0E0A shar r4
    if (!c.t) { goto L_060B0E12; }  // 060B0E0C bf 0x060B0E12
    SH2_POLL(c); goto L_060B0C18;  // 060B0E0E bra 0x060B0C18 ; nop
L_060B0E12:
    c.r[5] <<= 16;  // 060B0E12 shll16 r5
    c.r[5] = c.r[2] << 16 | c.r[5] >> 16;  // 060B0E14 xtrct r2,r5
    st32(c.r[11], c.r[5]);  // 060B0E16 mov.l r5,@(0,r11)
    c.r[15] += 8;  // 060B0E18 add #8,r15
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060B0E1A mov.l @r15+,r7
L_060B0E1C:
    { const uint32_t x = c.pr; c.r[0] = c.r[11]; c.pc = x; return; }  // 060B0E1C rts ; mov r11,r0
}

void f_060B0E28(SH2Context& c) {
    ran[3037] = 1;
L_060B0E28:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 12);  // 060B0E28 mov.w @(12,r1),r0
L_060B0E2A:
    c.r[2] <<= 2;  // 060B0E2A shll2 r2
L_060B0E2C:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0E2C mov.w @r7+,r3
L_060B0E2E:
    c.r[14] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0E2E exts.w r0,r14
L_060B0E30:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0E30 mov.w @r7+,r4
L_060B0E32:
    c.r[2] += c.r[10];  // 060B0E32 add r10,r2
L_060B0E34:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 12);  // 060B0E34 mov.w @(12,r2),r0
L_060B0E36:
    c.r[3] <<= 2;  // 060B0E36 shll2 r3
L_060B0E38:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B0E38 cmp/gt r0,r14
L_060B0E3A:
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_060B0E40; } }  // 060B0E3A bf/s 0x060B0E40 ; shll2 r3
L_060B0E3E:
    c.r[14] = c.r[0];  // 060B0E3E mov r0,r14
L_060B0E40:
    c.r[3] += c.r[10];  // 060B0E40 add r10,r3
L_060B0E42:
    c.r[4] <<= 2;  // 060B0E42 shll2 r4
L_060B0E44:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 12);  // 060B0E44 mov.w @(12,r3),r0
L_060B0E46:
    c.r[4] <<= 2;  // 060B0E46 shll2 r4
L_060B0E48:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B0E48 cmp/gt r0,r14
L_060B0E4A:
    { const bool k = !c.t; c.r[4] += c.r[10]; if (k) { goto L_060B0E50; } }  // 060B0E4A bf/s 0x060B0E50 ; add r10,r4
L_060B0E4E:
    c.r[14] = c.r[0];  // 060B0E4E mov r0,r14
L_060B0E50:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 12);  // 060B0E50 mov.w @(12,r4),r0
L_060B0E52:
    c.r[12] = ld32(c.r[15] + 12);  // 060B0E52 mov.l @(12,r15),r12
L_060B0E54:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B0E54 cmp/gt r0,r14
L_060B0E56:
    if (!c.t) { goto L_060B0E5A; }  // 060B0E56 bf 0x060B0E5A
L_060B0E58:
    c.r[14] = c.r[0];  // 060B0E58 mov r0,r14
L_060B0E5A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0E5A mov.w @(112,gbr),r0
L_060B0E5C:
    c.r[14] -= c.r[12];  // 060B0E5C sub r12,r14
L_060B0E5E:
    c.t = c.r[14] > c.r[0];  // 060B0E5E cmp/hi r0,r14
L_060B0E60:
    { const bool k = c.t; c.r[14] += c.r[12]; if (k) { goto L_060B0E66; } }  // 060B0E60 bt/s 0x060B0E66 ; add r12,r14
L_060B0E64:
    c.r[9] += 4;  // 060B0E64 add #4,r9
L_060B0E66:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0E66 mov.l @r9+,r0
L_060B0E68:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0E28u: goto L_060B0E28; case 0x060B0E2Au: goto L_060B0E2A; case 0x060B0E2Cu: goto L_060B0E2C; case 0x060B0E2Eu: goto L_060B0E2E; case 0x060B0E30u: goto L_060B0E30; case 0x060B0E32u: goto L_060B0E32; case 0x060B0E34u: goto L_060B0E34; case 0x060B0E36u: goto L_060B0E36; case 0x060B0E38u: goto L_060B0E38; case 0x060B0E3Au: goto L_060B0E3A; case 0x060B0E3Eu: goto L_060B0E3E; case 0x060B0E40u: goto L_060B0E40; case 0x060B0E42u: goto L_060B0E42; case 0x060B0E44u: goto L_060B0E44; case 0x060B0E46u: goto L_060B0E46; case 0x060B0E48u: goto L_060B0E48; case 0x060B0E4Au: goto L_060B0E4A; case 0x060B0E4Eu: goto L_060B0E4E; case 0x060B0E50u: goto L_060B0E50; case 0x060B0E52u: goto L_060B0E52; case 0x060B0E54u: goto L_060B0E54; case 0x060B0E56u: goto L_060B0E56; case 0x060B0E58u: goto L_060B0E58; case 0x060B0E5Au: goto L_060B0E5A; case 0x060B0E5Cu: goto L_060B0E5C; case 0x060B0E5Eu: goto L_060B0E5E; case 0x060B0E60u: goto L_060B0E60; case 0x060B0E64u: goto L_060B0E64; case 0x060B0E66u: goto L_060B0E66; case 0x060B0E68u: goto L_060B0E68; default: sh2_call(c, x); return; } }  // 060B0E68 jmp @r0 ; nop
}

void f_060B0E6C(SH2Context& c) {
    ran[3038] = 1;
L_060B0E6C:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0E6C mov.w @r7+,r3
L_060B0E6E:
    c.r[2] <<= 2;  // 060B0E6E shll2 r2
L_060B0E70:
    c.r[14] = ld32(c.r[1] + 12);  // 060B0E70 mov.l @(12,r1),r14
L_060B0E72:
    c.r[2] += c.r[10];  // 060B0E72 add r10,r2
L_060B0E74:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0E74 mov.w @r7+,r4
L_060B0E76:
    c.r[0] = ld32(c.r[2] + 12);  // 060B0E76 mov.l @(12,r2),r0
L_060B0E78:
    c.r[3] <<= 2;  // 060B0E78 shll2 r3
L_060B0E7A:
    c.r[14] += c.r[0];  // 060B0E7A add r0,r14
L_060B0E7C:
    c.r[3] <<= 2;  // 060B0E7C shll2 r3
L_060B0E7E:
    c.r[3] += c.r[10];  // 060B0E7E add r10,r3
L_060B0E80:
    c.r[4] <<= 2;  // 060B0E80 shll2 r4
L_060B0E82:
    c.r[0] = ld32(c.r[3] + 12);  // 060B0E82 mov.l @(12,r3),r0
L_060B0E84:
    c.r[4] <<= 2;  // 060B0E84 shll2 r4
L_060B0E86:
    c.r[14] += c.r[0];  // 060B0E86 add r0,r14
L_060B0E88:
    c.r[4] += c.r[10];  // 060B0E88 add r10,r4
L_060B0E8A:
    c.r[0] = ld32(c.r[4] + 12);  // 060B0E8A mov.l @(12,r4),r0
L_060B0E8C:
    c.r[14] += c.r[0];  // 060B0E8C add r0,r14
L_060B0E8E:
    c.r[14] >>= 16;  // 060B0E8E shlr16 r14
L_060B0E90:
    c.r[14] = (uint32_t)(int32_t)(int16_t)c.r[14];  // 060B0E90 exts.w r14,r14
L_060B0E92:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B0E92 shar r14
L_060B0E94:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B0E94 shar r14
L_060B0E96:
    c.r[12] = ld32(c.r[15] + 12);  // 060B0E96 mov.l @(12,r15),r12
L_060B0E98:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0E98 mov.w @(112,gbr),r0
L_060B0E9A:
    c.r[14] -= c.r[12];  // 060B0E9A sub r12,r14
L_060B0E9C:
    c.t = c.r[14] > c.r[0];  // 060B0E9C cmp/hi r0,r14
L_060B0E9E:
    { const bool k = c.t; c.r[14] += c.r[12]; if (k) { goto L_060B0EA4; } }  // 060B0E9E bt/s 0x060B0EA4 ; add r12,r14
L_060B0EA2:
    c.r[9] += 4;  // 060B0EA2 add #4,r9
L_060B0EA4:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0EA4 mov.l @r9+,r0
L_060B0EA6:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0E6Cu: goto L_060B0E6C; case 0x060B0E6Eu: goto L_060B0E6E; case 0x060B0E70u: goto L_060B0E70; case 0x060B0E72u: goto L_060B0E72; case 0x060B0E74u: goto L_060B0E74; case 0x060B0E76u: goto L_060B0E76; case 0x060B0E78u: goto L_060B0E78; case 0x060B0E7Au: goto L_060B0E7A; case 0x060B0E7Cu: goto L_060B0E7C; case 0x060B0E7Eu: goto L_060B0E7E; case 0x060B0E80u: goto L_060B0E80; case 0x060B0E82u: goto L_060B0E82; case 0x060B0E84u: goto L_060B0E84; case 0x060B0E86u: goto L_060B0E86; case 0x060B0E88u: goto L_060B0E88; case 0x060B0E8Au: goto L_060B0E8A; case 0x060B0E8Cu: goto L_060B0E8C; case 0x060B0E8Eu: goto L_060B0E8E; case 0x060B0E90u: goto L_060B0E90; case 0x060B0E92u: goto L_060B0E92; case 0x060B0E94u: goto L_060B0E94; case 0x060B0E96u: goto L_060B0E96; case 0x060B0E98u: goto L_060B0E98; case 0x060B0E9Au: goto L_060B0E9A; case 0x060B0E9Cu: goto L_060B0E9C; case 0x060B0E9Eu: goto L_060B0E9E; case 0x060B0EA2u: goto L_060B0EA2; case 0x060B0EA4u: goto L_060B0EA4; case 0x060B0EA6u: goto L_060B0EA6; default: sh2_call(c, x); return; } }  // 060B0EA6 jmp @r0 ; nop
}

void f_060B0EAC(SH2Context& c) {
    ran[3039] = 1;
L_060B0EAC:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0EAC mov.w @r7+,r3
L_060B0EAE:
    c.r[2] <<= 2;  // 060B0EAE shll2 r2
L_060B0EB0:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 12);  // 060B0EB0 mov.w @(12,r1),r0
L_060B0EB2:
    c.r[2] += c.r[10];  // 060B0EB2 add r10,r2
L_060B0EB4:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0EB4 mov.w @r7+,r4
L_060B0EB6:
    c.r[14] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0EB6 exts.w r0,r14
L_060B0EB8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 12);  // 060B0EB8 mov.w @(12,r2),r0
L_060B0EBA:
    c.r[3] <<= 2;  // 060B0EBA shll2 r3
L_060B0EBC:
    c.r[3] <<= 2;  // 060B0EBC shll2 r3
L_060B0EBE:
    c.r[3] += c.r[10];  // 060B0EBE add r10,r3
L_060B0EC0:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B0EC0 cmp/ge r0,r14
L_060B0EC2:
    { const bool k = c.t; c.r[4] <<= 2; if (k) { goto L_060B0EC8; } }  // 060B0EC2 bt/s 0x060B0EC8 ; shll2 r4
L_060B0EC6:
    c.r[14] = c.r[0];  // 060B0EC6 mov r0,r14
L_060B0EC8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 12);  // 060B0EC8 mov.w @(12,r3),r0
L_060B0ECA:
    c.r[4] <<= 2;  // 060B0ECA shll2 r4
L_060B0ECC:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B0ECC cmp/ge r0,r14
L_060B0ECE:
    { const bool k = c.t; c.r[4] += c.r[10]; if (k) { goto L_060B0ED4; } }  // 060B0ECE bt/s 0x060B0ED4 ; add r10,r4
L_060B0ED2:
    c.r[14] = c.r[0];  // 060B0ED2 mov r0,r14
L_060B0ED4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 12);  // 060B0ED4 mov.w @(12,r4),r0
L_060B0ED6:
    c.r[12] = ld32(c.r[15] + 12);  // 060B0ED6 mov.l @(12,r15),r12
L_060B0ED8:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B0ED8 cmp/ge r0,r14
L_060B0EDA:
    if (c.t) { goto L_060B0EDE; }  // 060B0EDA bt 0x060B0EDE
L_060B0EDC:
    c.r[14] = c.r[0];  // 060B0EDC mov r0,r14
L_060B0EDE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0EDE mov.w @(112,gbr),r0
L_060B0EE0:
    c.r[14] -= c.r[12];  // 060B0EE0 sub r12,r14
L_060B0EE2:
    c.t = c.r[14] > c.r[0];  // 060B0EE2 cmp/hi r0,r14
L_060B0EE4:
    { const bool k = c.t; c.r[14] += c.r[12]; if (k) { goto L_060B0EEA; } }  // 060B0EE4 bt/s 0x060B0EEA ; add r12,r14
L_060B0EE8:
    c.r[9] += 4;  // 060B0EE8 add #4,r9
L_060B0EEA:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0EEA mov.l @r9+,r0
L_060B0EEC:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0EACu: goto L_060B0EAC; case 0x060B0EAEu: goto L_060B0EAE; case 0x060B0EB0u: goto L_060B0EB0; case 0x060B0EB2u: goto L_060B0EB2; case 0x060B0EB4u: goto L_060B0EB4; case 0x060B0EB6u: goto L_060B0EB6; case 0x060B0EB8u: goto L_060B0EB8; case 0x060B0EBAu: goto L_060B0EBA; case 0x060B0EBCu: goto L_060B0EBC; case 0x060B0EBEu: goto L_060B0EBE; case 0x060B0EC0u: goto L_060B0EC0; case 0x060B0EC2u: goto L_060B0EC2; case 0x060B0EC6u: goto L_060B0EC6; case 0x060B0EC8u: goto L_060B0EC8; case 0x060B0ECAu: goto L_060B0ECA; case 0x060B0ECCu: goto L_060B0ECC; case 0x060B0ECEu: goto L_060B0ECE; case 0x060B0ED2u: goto L_060B0ED2; case 0x060B0ED4u: goto L_060B0ED4; case 0x060B0ED6u: goto L_060B0ED6; case 0x060B0ED8u: goto L_060B0ED8; case 0x060B0EDAu: goto L_060B0EDA; case 0x060B0EDCu: goto L_060B0EDC; case 0x060B0EDEu: goto L_060B0EDE; case 0x060B0EE0u: goto L_060B0EE0; case 0x060B0EE2u: goto L_060B0EE2; case 0x060B0EE4u: goto L_060B0EE4; case 0x060B0EE8u: goto L_060B0EE8; case 0x060B0EEAu: goto L_060B0EEA; case 0x060B0EECu: goto L_060B0EEC; default: sh2_call(c, x); return; } }  // 060B0EEC jmp @r0 ; nop
}

void f_060B0EF0(SH2Context& c) {
    ran[3040] = 1;
L_060B0EF0:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0EF0 mov.w @(112,gbr),r0
L_060B0EF2:
    c.r[2] <<= 2;  // 060B0EF2 shll2 r2
L_060B0EF4:
    c.t = c.r[14] > c.r[0];  // 060B0EF4 cmp/hi r0,r14
L_060B0EF6:
    { const bool k = c.t; c.r[2] += c.r[10]; if (k) { goto L_060B0F10; } }  // 060B0EF6 bt/s 0x060B0F10 ; add r10,r2
L_060B0EFA:
    c.r[9] += 4;  // 060B0EFA add #4,r9
L_060B0EFC:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0EFC mov.w @r7+,r3
L_060B0EFE:
    c.r[3] <<= 2;  // 060B0EFE shll2 r3
L_060B0F00:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0F00 mov.w @r7+,r4
L_060B0F02:
    c.r[3] <<= 2;  // 060B0F02 shll2 r3
L_060B0F04:
    c.r[3] += c.r[10];  // 060B0F04 add r10,r3
L_060B0F06:
    c.r[4] <<= 2;  // 060B0F06 shll2 r4
L_060B0F08:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0F08 mov.l @r9+,r0
L_060B0F0A:
    c.r[4] <<= 2;  // 060B0F0A shll2 r4
L_060B0F0C:
    { const uint32_t x = c.r[0]; c.r[4] += c.r[10]; SH2_POLL(c); switch (x) { case 0x060B0EF0u: goto L_060B0EF0; case 0x060B0EF2u: goto L_060B0EF2; case 0x060B0EF4u: goto L_060B0EF4; case 0x060B0EF6u: goto L_060B0EF6; case 0x060B0EFAu: goto L_060B0EFA; case 0x060B0EFCu: goto L_060B0EFC; case 0x060B0EFEu: goto L_060B0EFE; case 0x060B0F00u: goto L_060B0F00; case 0x060B0F02u: goto L_060B0F02; case 0x060B0F04u: goto L_060B0F04; case 0x060B0F06u: goto L_060B0F06; case 0x060B0F08u: goto L_060B0F08; case 0x060B0F0Au: goto L_060B0F0A; case 0x060B0F0Cu: goto L_060B0F0C; case 0x060B0F10u: goto L_060B0F10; case 0x060B0F12u: goto L_060B0F12; default: sh2_call(c, x); return; } }  // 060B0F0C jmp @r0 ; add r10,r4
L_060B0F10:
    c.r[0] = ld32(c.r[9]);  // 060B0F10 mov.l @r9,r0
L_060B0F12:
    { const uint32_t x = c.r[0]; c.r[7] += 4; SH2_POLL(c); switch (x) { case 0x060B0EF0u: goto L_060B0EF0; case 0x060B0EF2u: goto L_060B0EF2; case 0x060B0EF4u: goto L_060B0EF4; case 0x060B0EF6u: goto L_060B0EF6; case 0x060B0EFAu: goto L_060B0EFA; case 0x060B0EFCu: goto L_060B0EFC; case 0x060B0EFEu: goto L_060B0EFE; case 0x060B0F00u: goto L_060B0F00; case 0x060B0F02u: goto L_060B0F02; case 0x060B0F04u: goto L_060B0F04; case 0x060B0F06u: goto L_060B0F06; case 0x060B0F08u: goto L_060B0F08; case 0x060B0F0Au: goto L_060B0F0A; case 0x060B0F0Cu: goto L_060B0F0C; case 0x060B0F10u: goto L_060B0F10; case 0x060B0F12u: goto L_060B0F12; default: sh2_call(c, x); return; } }  // 060B0F12 jmp @r0 ; add #4,r7
}

void f_060B0F18(SH2Context& c) {
    ran[3041] = 1;
L_060B0F18:
    c.r[14] = ld32(c.r[1] + 12);  // 060B0F18 mov.l @(12,r1),r14
L_060B0F1A:
    c.r[2] <<= 2;  // 060B0F1A shll2 r2
L_060B0F1C:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0F1C mov.w @r7+,r3
L_060B0F1E:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0F1E mov.w @r7+,r4
L_060B0F20:
    c.r[2] += c.r[10];  // 060B0F20 add r10,r2
L_060B0F22:
    c.r[0] = ld32(c.r[2] + 12);  // 060B0F22 mov.l @(12,r2),r0
L_060B0F24:
    c.r[3] <<= 2;  // 060B0F24 shll2 r3
L_060B0F26:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B0F26 cmp/gt r0,r14
L_060B0F28:
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_060B0F2E; } }  // 060B0F28 bf/s 0x060B0F2E ; shll2 r3
L_060B0F2C:
    c.r[14] = c.r[0];  // 060B0F2C mov r0,r14
L_060B0F2E:
    c.r[3] += c.r[10];  // 060B0F2E add r10,r3
L_060B0F30:
    c.r[4] <<= 2;  // 060B0F30 shll2 r4
L_060B0F32:
    c.r[0] = ld32(c.r[3] + 12);  // 060B0F32 mov.l @(12,r3),r0
L_060B0F34:
    c.r[4] <<= 2;  // 060B0F34 shll2 r4
L_060B0F36:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B0F36 cmp/gt r0,r14
L_060B0F38:
    { const bool k = !c.t; c.r[4] += c.r[10]; if (k) { goto L_060B0F3E; } }  // 060B0F38 bf/s 0x060B0F3E ; add r10,r4
L_060B0F3C:
    c.r[14] = c.r[0];  // 060B0F3C mov r0,r14
L_060B0F3E:
    c.r[0] = ld32(c.r[4] + 12);  // 060B0F3E mov.l @(12,r4),r0
L_060B0F40:
    c.r[12] = ld32(c.r[15] + 12);  // 060B0F40 mov.l @(12,r15),r12
L_060B0F42:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B0F42 cmp/gt r0,r14
L_060B0F44:
    if (!c.t) { goto L_060B0F48; }  // 060B0F44 bf 0x060B0F48
L_060B0F46:
    c.r[14] = c.r[0];  // 060B0F46 mov r0,r14
L_060B0F48:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0F48 mov.w @(112,gbr),r0
L_060B0F4A:
    c.r[12] <<= 16;  // 060B0F4A shll16 r12
L_060B0F4C:
    c.r[0] <<= 16;  // 060B0F4C shll16 r0
L_060B0F4E:
    c.r[0] += c.r[12];  // 060B0F4E add r12,r0
L_060B0F50:
    c.t = c.r[14] > c.r[0];  // 060B0F50 cmp/hi r0,r14
L_060B0F52:
    { const bool k = c.t; c.t = c.r[12] & 1; c.r[12] >>= 1; if (k) { goto L_060B0F5E; } }  // 060B0F52 bt/s 0x060B0F5E ; shlr r12
L_060B0F56:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[12];  // 060B0F56 cmp/gt r12,r14
L_060B0F58:
    if (!c.t) { goto L_060B0F5E; }  // 060B0F58 bf 0x060B0F5E
L_060B0F5A:
    c.r[14] >>= 16; goto L_060B101A;  // 060B0F5A bra 0x060B101A ; shlr16 r14
L_060B0F5E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0F5E mov.l @r9+,r0
L_060B0F60:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0F18u: goto L_060B0F18; case 0x060B0F1Au: goto L_060B0F1A; case 0x060B0F1Cu: goto L_060B0F1C; case 0x060B0F1Eu: goto L_060B0F1E; case 0x060B0F20u: goto L_060B0F20; case 0x060B0F22u: goto L_060B0F22; case 0x060B0F24u: goto L_060B0F24; case 0x060B0F26u: goto L_060B0F26; case 0x060B0F28u: goto L_060B0F28; case 0x060B0F2Cu: goto L_060B0F2C; case 0x060B0F2Eu: goto L_060B0F2E; case 0x060B0F30u: goto L_060B0F30; case 0x060B0F32u: goto L_060B0F32; case 0x060B0F34u: goto L_060B0F34; case 0x060B0F36u: goto L_060B0F36; case 0x060B0F38u: goto L_060B0F38; case 0x060B0F3Cu: goto L_060B0F3C; case 0x060B0F3Eu: goto L_060B0F3E; case 0x060B0F40u: goto L_060B0F40; case 0x060B0F42u: goto L_060B0F42; case 0x060B0F44u: goto L_060B0F44; case 0x060B0F46u: goto L_060B0F46; case 0x060B0F48u: goto L_060B0F48; case 0x060B0F4Au: goto L_060B0F4A; case 0x060B0F4Cu: goto L_060B0F4C; case 0x060B0F4Eu: goto L_060B0F4E; case 0x060B0F50u: goto L_060B0F50; case 0x060B0F52u: goto L_060B0F52; case 0x060B0F56u: goto L_060B0F56; case 0x060B0F58u: goto L_060B0F58; case 0x060B0F5Au: goto L_060B0F5A; case 0x060B0F5Eu: goto L_060B0F5E; case 0x060B0F60u: goto L_060B0F60; case 0x060B101Au: goto L_060B101A; case 0x060B101Cu: goto L_060B101C; case 0x060B101Eu: goto L_060B101E; case 0x060B1022u: goto L_060B1022; case 0x060B1024u: goto L_060B1024; case 0x060B1028u: goto L_060B1028; case 0x060B102Au: goto L_060B102A; case 0x060B102Eu: goto L_060B102E; case 0x060B1030u: goto L_060B1030; case 0x060B1032u: goto L_060B1032; case 0x060B1034u: goto L_060B1034; case 0x060B1036u: goto L_060B1036; case 0x060B103Au: goto L_060B103A; case 0x060B103Cu: goto L_060B103C; case 0x060B103Eu: goto L_060B103E; case 0x060B1040u: goto L_060B1040; case 0x060B1042u: goto L_060B1042; case 0x060B1046u: goto L_060B1046; case 0x060B104Au: goto L_060B104A; case 0x060B104Cu: goto L_060B104C; case 0x060B1050u: goto L_060B1050; case 0x060B1054u: goto L_060B1054; case 0x060B1056u: goto L_060B1056; case 0x060B105Au: goto L_060B105A; case 0x060B105Eu: goto L_060B105E; case 0x060B1060u: goto L_060B1060; case 0x060B1064u: goto L_060B1064; case 0x060B1068u: goto L_060B1068; case 0x060B106Au: goto L_060B106A; case 0x060B106Eu: goto L_060B106E; case 0x060B1072u: goto L_060B1072; case 0x060B1074u: goto L_060B1074; case 0x060B1078u: goto L_060B1078; case 0x060B107Cu: goto L_060B107C; case 0x060B107Eu: goto L_060B107E; case 0x060B1082u: goto L_060B1082; case 0x060B1086u: goto L_060B1086; case 0x060B1088u: goto L_060B1088; case 0x060B108Cu: goto L_060B108C; case 0x060B108Eu: goto L_060B108E; case 0x060B1090u: goto L_060B1090; case 0x060B1092u: goto L_060B1092; case 0x060B1094u: goto L_060B1094; default: sh2_call(c, x); return; } }  // 060B0F60 jmp @r0 ; nop
L_060B101A:
    c.r[0] = ld32(c.r[1] + 4);  // 060B101A mov.l @(4,r1),r0
L_060B101C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B101C shar r0
L_060B101E:
    { const bool k = !c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B1032; } }  // 060B101E bf/s 0x060B1032 ; mov.l @(4,r2),r0
L_060B1022:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B1022 shar r0
L_060B1024:
    { const bool k = !c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B1032; } }  // 060B1024 bf/s 0x060B1032 ; mov.l @(4,r3),r0
L_060B1028:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B1028 shar r0
L_060B102A:
    { const bool k = !c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B1032; } }  // 060B102A bf/s 0x060B1032 ; mov.l @(4,r4),r0
L_060B102E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B102E shar r0
L_060B1030:
    if (c.t) { goto L_060B1092; }  // 060B1030 bt 0x060B1092
L_060B1032:
    c.r[0] = ld32(c.gbr + 888);  // 060B1032 mov.l @(888,gbr),r0
L_060B1034:
    c.t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31;  // 060B1034 rotr r0
L_060B1036:
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.r[14]); if (k) { goto L_060B108E; } }  // 060B1036 bt/s 0x060B108E ; mov.l r14,@-r15
L_060B103A:
    c.r[14] = (uint32_t)(int16_t)ld16(0x060B1098u);  // 060B103A mov.w 0x060B1098,r14
L_060B103C:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B109Au);  // 060B103C mov.w 0x060B109A,r5
L_060B103E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B103E mov.w @(0,r1),r0
L_060B1040:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1040 cmp/gt r5,r0
L_060B1042:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1042 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1046:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 2); if (k) { goto L_060B1090; } }  // 060B1046 bf/s 0x060B1090 ; mov.w @(2,r1),r0
L_060B104A:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B104A cmp/gt r5,r0
L_060B104C:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B104C bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1050:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); if (k) { goto L_060B1090; } }  // 060B1050 bf/s 0x060B1090 ; mov.w @(0,r2),r0
L_060B1054:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1054 cmp/gt r5,r0
L_060B1056:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1056 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B105A:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2); if (k) { goto L_060B1090; } }  // 060B105A bf/s 0x060B1090 ; mov.w @(2,r2),r0
L_060B105E:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B105E cmp/gt r5,r0
L_060B1060:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1060 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1064:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { goto L_060B1090; } }  // 060B1064 bf/s 0x060B1090 ; mov.w @(0,r3),r0
L_060B1068:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1068 cmp/gt r5,r0
L_060B106A:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B106A bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B106E:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 2); if (k) { goto L_060B1090; } }  // 060B106E bf/s 0x060B1090 ; mov.w @(2,r3),r0
L_060B1072:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1072 cmp/gt r5,r0
L_060B1074:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1074 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1078:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { goto L_060B1090; } }  // 060B1078 bf/s 0x060B1090 ; mov.w @(0,r4),r0
L_060B107C:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B107C cmp/gt r5,r0
L_060B107E:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B107E bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1082:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 2); if (k) { goto L_060B1090; } }  // 060B1082 bf/s 0x060B1090 ; mov.w @(2,r4),r0
L_060B1086:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1086 cmp/gt r5,r0
L_060B1088:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1088 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B108C:
    if (!c.t) { goto L_060B1090; }  // 060B108C bf 0x060B1090
L_060B108E:
    c.r[9] += 4;  // 060B108E add #4,r9
L_060B1090:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B1090 mov.l @r15+,r14
L_060B1092:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B1092 mov.l @r9+,r0
L_060B1094:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0F18u: goto L_060B0F18; case 0x060B0F1Au: goto L_060B0F1A; case 0x060B0F1Cu: goto L_060B0F1C; case 0x060B0F1Eu: goto L_060B0F1E; case 0x060B0F20u: goto L_060B0F20; case 0x060B0F22u: goto L_060B0F22; case 0x060B0F24u: goto L_060B0F24; case 0x060B0F26u: goto L_060B0F26; case 0x060B0F28u: goto L_060B0F28; case 0x060B0F2Cu: goto L_060B0F2C; case 0x060B0F2Eu: goto L_060B0F2E; case 0x060B0F30u: goto L_060B0F30; case 0x060B0F32u: goto L_060B0F32; case 0x060B0F34u: goto L_060B0F34; case 0x060B0F36u: goto L_060B0F36; case 0x060B0F38u: goto L_060B0F38; case 0x060B0F3Cu: goto L_060B0F3C; case 0x060B0F3Eu: goto L_060B0F3E; case 0x060B0F40u: goto L_060B0F40; case 0x060B0F42u: goto L_060B0F42; case 0x060B0F44u: goto L_060B0F44; case 0x060B0F46u: goto L_060B0F46; case 0x060B0F48u: goto L_060B0F48; case 0x060B0F4Au: goto L_060B0F4A; case 0x060B0F4Cu: goto L_060B0F4C; case 0x060B0F4Eu: goto L_060B0F4E; case 0x060B0F50u: goto L_060B0F50; case 0x060B0F52u: goto L_060B0F52; case 0x060B0F56u: goto L_060B0F56; case 0x060B0F58u: goto L_060B0F58; case 0x060B0F5Au: goto L_060B0F5A; case 0x060B0F5Eu: goto L_060B0F5E; case 0x060B0F60u: goto L_060B0F60; case 0x060B101Au: goto L_060B101A; case 0x060B101Cu: goto L_060B101C; case 0x060B101Eu: goto L_060B101E; case 0x060B1022u: goto L_060B1022; case 0x060B1024u: goto L_060B1024; case 0x060B1028u: goto L_060B1028; case 0x060B102Au: goto L_060B102A; case 0x060B102Eu: goto L_060B102E; case 0x060B1030u: goto L_060B1030; case 0x060B1032u: goto L_060B1032; case 0x060B1034u: goto L_060B1034; case 0x060B1036u: goto L_060B1036; case 0x060B103Au: goto L_060B103A; case 0x060B103Cu: goto L_060B103C; case 0x060B103Eu: goto L_060B103E; case 0x060B1040u: goto L_060B1040; case 0x060B1042u: goto L_060B1042; case 0x060B1046u: goto L_060B1046; case 0x060B104Au: goto L_060B104A; case 0x060B104Cu: goto L_060B104C; case 0x060B1050u: goto L_060B1050; case 0x060B1054u: goto L_060B1054; case 0x060B1056u: goto L_060B1056; case 0x060B105Au: goto L_060B105A; case 0x060B105Eu: goto L_060B105E; case 0x060B1060u: goto L_060B1060; case 0x060B1064u: goto L_060B1064; case 0x060B1068u: goto L_060B1068; case 0x060B106Au: goto L_060B106A; case 0x060B106Eu: goto L_060B106E; case 0x060B1072u: goto L_060B1072; case 0x060B1074u: goto L_060B1074; case 0x060B1078u: goto L_060B1078; case 0x060B107Cu: goto L_060B107C; case 0x060B107Eu: goto L_060B107E; case 0x060B1082u: goto L_060B1082; case 0x060B1086u: goto L_060B1086; case 0x060B1088u: goto L_060B1088; case 0x060B108Cu: goto L_060B108C; case 0x060B108Eu: goto L_060B108E; case 0x060B1090u: goto L_060B1090; case 0x060B1092u: goto L_060B1092; case 0x060B1094u: goto L_060B1094; default: sh2_call(c, x); return; } }  // 060B1094 jmp @r0 ; nop
}

void f_060B0F64(SH2Context& c) {
    ran[3042] = 1;
L_060B0F64:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0F64 mov.w @r7+,r3
L_060B0F66:
    c.r[2] <<= 2;  // 060B0F66 shll2 r2
L_060B0F68:
    c.r[14] = ld32(c.r[1] + 12);  // 060B0F68 mov.l @(12,r1),r14
L_060B0F6A:
    c.r[2] += c.r[10];  // 060B0F6A add r10,r2
L_060B0F6C:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0F6C mov.w @r7+,r4
L_060B0F6E:
    c.r[0] = ld32(c.r[2] + 12);  // 060B0F6E mov.l @(12,r2),r0
L_060B0F70:
    c.r[3] <<= 2;  // 060B0F70 shll2 r3
L_060B0F72:
    c.r[14] += c.r[0];  // 060B0F72 add r0,r14
L_060B0F74:
    c.r[3] <<= 2;  // 060B0F74 shll2 r3
L_060B0F76:
    c.r[3] += c.r[10];  // 060B0F76 add r10,r3
L_060B0F78:
    c.r[4] <<= 2;  // 060B0F78 shll2 r4
L_060B0F7A:
    c.r[0] = ld32(c.r[3] + 12);  // 060B0F7A mov.l @(12,r3),r0
L_060B0F7C:
    c.r[4] <<= 2;  // 060B0F7C shll2 r4
L_060B0F7E:
    c.r[14] += c.r[0];  // 060B0F7E add r0,r14
L_060B0F80:
    c.r[4] += c.r[10];  // 060B0F80 add r10,r4
L_060B0F82:
    c.r[0] = ld32(c.r[4] + 12);  // 060B0F82 mov.l @(12,r4),r0
L_060B0F84:
    c.r[14] += c.r[0];  // 060B0F84 add r0,r14
L_060B0F86:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B0F86 shar r14
L_060B0F88:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B0F88 shar r14
L_060B0F8A:
    c.r[12] = ld32(c.r[15] + 12);  // 060B0F8A mov.l @(12,r15),r12
L_060B0F8C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0F8C mov.w @(112,gbr),r0
L_060B0F8E:
    c.r[12] <<= 16;  // 060B0F8E shll16 r12
L_060B0F90:
    c.r[0] <<= 16;  // 060B0F90 shll16 r0
L_060B0F92:
    c.r[0] += c.r[12];  // 060B0F92 add r12,r0
L_060B0F94:
    c.t = c.r[14] > c.r[0];  // 060B0F94 cmp/hi r0,r14
L_060B0F96:
    { const bool k = c.t; c.t = c.r[12] & 1; c.r[12] >>= 1; if (k) { goto L_060B0FA2; } }  // 060B0F96 bt/s 0x060B0FA2 ; shlr r12
L_060B0F9A:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[12];  // 060B0F9A cmp/gt r12,r14
L_060B0F9C:
    if (!c.t) { goto L_060B0FA2; }  // 060B0F9C bf 0x060B0FA2
L_060B0F9E:
    c.r[14] >>= 16; goto L_060B101A;  // 060B0F9E bra 0x060B101A ; shlr16 r14
L_060B0FA2:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0FA2 mov.l @r9+,r0
L_060B0FA4:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0F64u: goto L_060B0F64; case 0x060B0F66u: goto L_060B0F66; case 0x060B0F68u: goto L_060B0F68; case 0x060B0F6Au: goto L_060B0F6A; case 0x060B0F6Cu: goto L_060B0F6C; case 0x060B0F6Eu: goto L_060B0F6E; case 0x060B0F70u: goto L_060B0F70; case 0x060B0F72u: goto L_060B0F72; case 0x060B0F74u: goto L_060B0F74; case 0x060B0F76u: goto L_060B0F76; case 0x060B0F78u: goto L_060B0F78; case 0x060B0F7Au: goto L_060B0F7A; case 0x060B0F7Cu: goto L_060B0F7C; case 0x060B0F7Eu: goto L_060B0F7E; case 0x060B0F80u: goto L_060B0F80; case 0x060B0F82u: goto L_060B0F82; case 0x060B0F84u: goto L_060B0F84; case 0x060B0F86u: goto L_060B0F86; case 0x060B0F88u: goto L_060B0F88; case 0x060B0F8Au: goto L_060B0F8A; case 0x060B0F8Cu: goto L_060B0F8C; case 0x060B0F8Eu: goto L_060B0F8E; case 0x060B0F90u: goto L_060B0F90; case 0x060B0F92u: goto L_060B0F92; case 0x060B0F94u: goto L_060B0F94; case 0x060B0F96u: goto L_060B0F96; case 0x060B0F9Au: goto L_060B0F9A; case 0x060B0F9Cu: goto L_060B0F9C; case 0x060B0F9Eu: goto L_060B0F9E; case 0x060B0FA2u: goto L_060B0FA2; case 0x060B0FA4u: goto L_060B0FA4; case 0x060B101Au: goto L_060B101A; case 0x060B101Cu: goto L_060B101C; case 0x060B101Eu: goto L_060B101E; case 0x060B1022u: goto L_060B1022; case 0x060B1024u: goto L_060B1024; case 0x060B1028u: goto L_060B1028; case 0x060B102Au: goto L_060B102A; case 0x060B102Eu: goto L_060B102E; case 0x060B1030u: goto L_060B1030; case 0x060B1032u: goto L_060B1032; case 0x060B1034u: goto L_060B1034; case 0x060B1036u: goto L_060B1036; case 0x060B103Au: goto L_060B103A; case 0x060B103Cu: goto L_060B103C; case 0x060B103Eu: goto L_060B103E; case 0x060B1040u: goto L_060B1040; case 0x060B1042u: goto L_060B1042; case 0x060B1046u: goto L_060B1046; case 0x060B104Au: goto L_060B104A; case 0x060B104Cu: goto L_060B104C; case 0x060B1050u: goto L_060B1050; case 0x060B1054u: goto L_060B1054; case 0x060B1056u: goto L_060B1056; case 0x060B105Au: goto L_060B105A; case 0x060B105Eu: goto L_060B105E; case 0x060B1060u: goto L_060B1060; case 0x060B1064u: goto L_060B1064; case 0x060B1068u: goto L_060B1068; case 0x060B106Au: goto L_060B106A; case 0x060B106Eu: goto L_060B106E; case 0x060B1072u: goto L_060B1072; case 0x060B1074u: goto L_060B1074; case 0x060B1078u: goto L_060B1078; case 0x060B107Cu: goto L_060B107C; case 0x060B107Eu: goto L_060B107E; case 0x060B1082u: goto L_060B1082; case 0x060B1086u: goto L_060B1086; case 0x060B1088u: goto L_060B1088; case 0x060B108Cu: goto L_060B108C; case 0x060B108Eu: goto L_060B108E; case 0x060B1090u: goto L_060B1090; case 0x060B1092u: goto L_060B1092; case 0x060B1094u: goto L_060B1094; default: sh2_call(c, x); return; } }  // 060B0FA4 jmp @r0 ; nop
L_060B101A:
    c.r[0] = ld32(c.r[1] + 4);  // 060B101A mov.l @(4,r1),r0
L_060B101C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B101C shar r0
L_060B101E:
    { const bool k = !c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B1032; } }  // 060B101E bf/s 0x060B1032 ; mov.l @(4,r2),r0
L_060B1022:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B1022 shar r0
L_060B1024:
    { const bool k = !c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B1032; } }  // 060B1024 bf/s 0x060B1032 ; mov.l @(4,r3),r0
L_060B1028:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B1028 shar r0
L_060B102A:
    { const bool k = !c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B1032; } }  // 060B102A bf/s 0x060B1032 ; mov.l @(4,r4),r0
L_060B102E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B102E shar r0
L_060B1030:
    if (c.t) { goto L_060B1092; }  // 060B1030 bt 0x060B1092
L_060B1032:
    c.r[0] = ld32(c.gbr + 888);  // 060B1032 mov.l @(888,gbr),r0
L_060B1034:
    c.t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31;  // 060B1034 rotr r0
L_060B1036:
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.r[14]); if (k) { goto L_060B108E; } }  // 060B1036 bt/s 0x060B108E ; mov.l r14,@-r15
L_060B103A:
    c.r[14] = (uint32_t)(int16_t)ld16(0x060B1098u);  // 060B103A mov.w 0x060B1098,r14
L_060B103C:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B109Au);  // 060B103C mov.w 0x060B109A,r5
L_060B103E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B103E mov.w @(0,r1),r0
L_060B1040:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1040 cmp/gt r5,r0
L_060B1042:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1042 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1046:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 2); if (k) { goto L_060B1090; } }  // 060B1046 bf/s 0x060B1090 ; mov.w @(2,r1),r0
L_060B104A:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B104A cmp/gt r5,r0
L_060B104C:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B104C bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1050:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); if (k) { goto L_060B1090; } }  // 060B1050 bf/s 0x060B1090 ; mov.w @(0,r2),r0
L_060B1054:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1054 cmp/gt r5,r0
L_060B1056:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1056 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B105A:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2); if (k) { goto L_060B1090; } }  // 060B105A bf/s 0x060B1090 ; mov.w @(2,r2),r0
L_060B105E:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B105E cmp/gt r5,r0
L_060B1060:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1060 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1064:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { goto L_060B1090; } }  // 060B1064 bf/s 0x060B1090 ; mov.w @(0,r3),r0
L_060B1068:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1068 cmp/gt r5,r0
L_060B106A:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B106A bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B106E:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 2); if (k) { goto L_060B1090; } }  // 060B106E bf/s 0x060B1090 ; mov.w @(2,r3),r0
L_060B1072:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1072 cmp/gt r5,r0
L_060B1074:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1074 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1078:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { goto L_060B1090; } }  // 060B1078 bf/s 0x060B1090 ; mov.w @(0,r4),r0
L_060B107C:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B107C cmp/gt r5,r0
L_060B107E:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B107E bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1082:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 2); if (k) { goto L_060B1090; } }  // 060B1082 bf/s 0x060B1090 ; mov.w @(2,r4),r0
L_060B1086:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1086 cmp/gt r5,r0
L_060B1088:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1088 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B108C:
    if (!c.t) { goto L_060B1090; }  // 060B108C bf 0x060B1090
L_060B108E:
    c.r[9] += 4;  // 060B108E add #4,r9
L_060B1090:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B1090 mov.l @r15+,r14
L_060B1092:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B1092 mov.l @r9+,r0
L_060B1094:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0F64u: goto L_060B0F64; case 0x060B0F66u: goto L_060B0F66; case 0x060B0F68u: goto L_060B0F68; case 0x060B0F6Au: goto L_060B0F6A; case 0x060B0F6Cu: goto L_060B0F6C; case 0x060B0F6Eu: goto L_060B0F6E; case 0x060B0F70u: goto L_060B0F70; case 0x060B0F72u: goto L_060B0F72; case 0x060B0F74u: goto L_060B0F74; case 0x060B0F76u: goto L_060B0F76; case 0x060B0F78u: goto L_060B0F78; case 0x060B0F7Au: goto L_060B0F7A; case 0x060B0F7Cu: goto L_060B0F7C; case 0x060B0F7Eu: goto L_060B0F7E; case 0x060B0F80u: goto L_060B0F80; case 0x060B0F82u: goto L_060B0F82; case 0x060B0F84u: goto L_060B0F84; case 0x060B0F86u: goto L_060B0F86; case 0x060B0F88u: goto L_060B0F88; case 0x060B0F8Au: goto L_060B0F8A; case 0x060B0F8Cu: goto L_060B0F8C; case 0x060B0F8Eu: goto L_060B0F8E; case 0x060B0F90u: goto L_060B0F90; case 0x060B0F92u: goto L_060B0F92; case 0x060B0F94u: goto L_060B0F94; case 0x060B0F96u: goto L_060B0F96; case 0x060B0F9Au: goto L_060B0F9A; case 0x060B0F9Cu: goto L_060B0F9C; case 0x060B0F9Eu: goto L_060B0F9E; case 0x060B0FA2u: goto L_060B0FA2; case 0x060B0FA4u: goto L_060B0FA4; case 0x060B101Au: goto L_060B101A; case 0x060B101Cu: goto L_060B101C; case 0x060B101Eu: goto L_060B101E; case 0x060B1022u: goto L_060B1022; case 0x060B1024u: goto L_060B1024; case 0x060B1028u: goto L_060B1028; case 0x060B102Au: goto L_060B102A; case 0x060B102Eu: goto L_060B102E; case 0x060B1030u: goto L_060B1030; case 0x060B1032u: goto L_060B1032; case 0x060B1034u: goto L_060B1034; case 0x060B1036u: goto L_060B1036; case 0x060B103Au: goto L_060B103A; case 0x060B103Cu: goto L_060B103C; case 0x060B103Eu: goto L_060B103E; case 0x060B1040u: goto L_060B1040; case 0x060B1042u: goto L_060B1042; case 0x060B1046u: goto L_060B1046; case 0x060B104Au: goto L_060B104A; case 0x060B104Cu: goto L_060B104C; case 0x060B1050u: goto L_060B1050; case 0x060B1054u: goto L_060B1054; case 0x060B1056u: goto L_060B1056; case 0x060B105Au: goto L_060B105A; case 0x060B105Eu: goto L_060B105E; case 0x060B1060u: goto L_060B1060; case 0x060B1064u: goto L_060B1064; case 0x060B1068u: goto L_060B1068; case 0x060B106Au: goto L_060B106A; case 0x060B106Eu: goto L_060B106E; case 0x060B1072u: goto L_060B1072; case 0x060B1074u: goto L_060B1074; case 0x060B1078u: goto L_060B1078; case 0x060B107Cu: goto L_060B107C; case 0x060B107Eu: goto L_060B107E; case 0x060B1082u: goto L_060B1082; case 0x060B1086u: goto L_060B1086; case 0x060B1088u: goto L_060B1088; case 0x060B108Cu: goto L_060B108C; case 0x060B108Eu: goto L_060B108E; case 0x060B1090u: goto L_060B1090; case 0x060B1092u: goto L_060B1092; case 0x060B1094u: goto L_060B1094; default: sh2_call(c, x); return; } }  // 060B1094 jmp @r0 ; nop
}

void f_060B0FA8(SH2Context& c) {
    ran[3043] = 1;
L_060B0FA8:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0FA8 mov.w @r7+,r3
L_060B0FAA:
    c.r[2] <<= 2;  // 060B0FAA shll2 r2
L_060B0FAC:
    c.r[14] = ld32(c.r[1] + 12);  // 060B0FAC mov.l @(12,r1),r14
L_060B0FAE:
    c.r[2] += c.r[10];  // 060B0FAE add r10,r2
L_060B0FB0:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0FB0 mov.w @r7+,r4
L_060B0FB2:
    c.r[0] = ld32(c.r[2] + 12);  // 060B0FB2 mov.l @(12,r2),r0
L_060B0FB4:
    c.r[3] <<= 2;  // 060B0FB4 shll2 r3
L_060B0FB6:
    c.r[3] <<= 2;  // 060B0FB6 shll2 r3
L_060B0FB8:
    c.r[3] += c.r[10];  // 060B0FB8 add r10,r3
L_060B0FBA:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B0FBA cmp/ge r0,r14
L_060B0FBC:
    { const bool k = c.t; c.r[4] <<= 2; if (k) { goto L_060B0FC2; } }  // 060B0FBC bt/s 0x060B0FC2 ; shll2 r4
L_060B0FC0:
    c.r[14] = c.r[0];  // 060B0FC0 mov r0,r14
L_060B0FC2:
    c.r[0] = ld32(c.r[3] + 12);  // 060B0FC2 mov.l @(12,r3),r0
L_060B0FC4:
    c.r[4] <<= 2;  // 060B0FC4 shll2 r4
L_060B0FC6:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B0FC6 cmp/ge r0,r14
L_060B0FC8:
    { const bool k = c.t; c.r[4] += c.r[10]; if (k) { goto L_060B0FCE; } }  // 060B0FC8 bt/s 0x060B0FCE ; add r10,r4
L_060B0FCC:
    c.r[14] = c.r[0];  // 060B0FCC mov r0,r14
L_060B0FCE:
    c.r[0] = ld32(c.r[4] + 12);  // 060B0FCE mov.l @(12,r4),r0
L_060B0FD0:
    c.r[12] = ld32(c.r[15] + 12);  // 060B0FD0 mov.l @(12,r15),r12
L_060B0FD2:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B0FD2 cmp/ge r0,r14
L_060B0FD4:
    if (c.t) { goto L_060B0FD8; }  // 060B0FD4 bt 0x060B0FD8
L_060B0FD6:
    c.r[14] = c.r[0];  // 060B0FD6 mov r0,r14
L_060B0FD8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0FD8 mov.w @(112,gbr),r0
L_060B0FDA:
    c.r[12] <<= 16;  // 060B0FDA shll16 r12
L_060B0FDC:
    c.r[0] <<= 16;  // 060B0FDC shll16 r0
L_060B0FDE:
    c.r[0] += c.r[12];  // 060B0FDE add r12,r0
L_060B0FE0:
    c.t = c.r[14] > c.r[0];  // 060B0FE0 cmp/hi r0,r14
L_060B0FE2:
    { const bool k = c.t; c.t = c.r[12] & 1; c.r[12] >>= 1; if (k) { goto L_060B0FEE; } }  // 060B0FE2 bt/s 0x060B0FEE ; shlr r12
L_060B0FE6:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[12];  // 060B0FE6 cmp/gt r12,r14
L_060B0FE8:
    if (!c.t) { goto L_060B0FEE; }  // 060B0FE8 bf 0x060B0FEE
L_060B0FEA:
    c.r[14] >>= 16; goto L_060B101A;  // 060B0FEA bra 0x060B101A ; shlr16 r14
L_060B0FEE:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B0FEE mov.l @r9+,r0
L_060B0FF0:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0FA8u: goto L_060B0FA8; case 0x060B0FAAu: goto L_060B0FAA; case 0x060B0FACu: goto L_060B0FAC; case 0x060B0FAEu: goto L_060B0FAE; case 0x060B0FB0u: goto L_060B0FB0; case 0x060B0FB2u: goto L_060B0FB2; case 0x060B0FB4u: goto L_060B0FB4; case 0x060B0FB6u: goto L_060B0FB6; case 0x060B0FB8u: goto L_060B0FB8; case 0x060B0FBAu: goto L_060B0FBA; case 0x060B0FBCu: goto L_060B0FBC; case 0x060B0FC0u: goto L_060B0FC0; case 0x060B0FC2u: goto L_060B0FC2; case 0x060B0FC4u: goto L_060B0FC4; case 0x060B0FC6u: goto L_060B0FC6; case 0x060B0FC8u: goto L_060B0FC8; case 0x060B0FCCu: goto L_060B0FCC; case 0x060B0FCEu: goto L_060B0FCE; case 0x060B0FD0u: goto L_060B0FD0; case 0x060B0FD2u: goto L_060B0FD2; case 0x060B0FD4u: goto L_060B0FD4; case 0x060B0FD6u: goto L_060B0FD6; case 0x060B0FD8u: goto L_060B0FD8; case 0x060B0FDAu: goto L_060B0FDA; case 0x060B0FDCu: goto L_060B0FDC; case 0x060B0FDEu: goto L_060B0FDE; case 0x060B0FE0u: goto L_060B0FE0; case 0x060B0FE2u: goto L_060B0FE2; case 0x060B0FE6u: goto L_060B0FE6; case 0x060B0FE8u: goto L_060B0FE8; case 0x060B0FEAu: goto L_060B0FEA; case 0x060B0FEEu: goto L_060B0FEE; case 0x060B0FF0u: goto L_060B0FF0; case 0x060B101Au: goto L_060B101A; case 0x060B101Cu: goto L_060B101C; case 0x060B101Eu: goto L_060B101E; case 0x060B1022u: goto L_060B1022; case 0x060B1024u: goto L_060B1024; case 0x060B1028u: goto L_060B1028; case 0x060B102Au: goto L_060B102A; case 0x060B102Eu: goto L_060B102E; case 0x060B1030u: goto L_060B1030; case 0x060B1032u: goto L_060B1032; case 0x060B1034u: goto L_060B1034; case 0x060B1036u: goto L_060B1036; case 0x060B103Au: goto L_060B103A; case 0x060B103Cu: goto L_060B103C; case 0x060B103Eu: goto L_060B103E; case 0x060B1040u: goto L_060B1040; case 0x060B1042u: goto L_060B1042; case 0x060B1046u: goto L_060B1046; case 0x060B104Au: goto L_060B104A; case 0x060B104Cu: goto L_060B104C; case 0x060B1050u: goto L_060B1050; case 0x060B1054u: goto L_060B1054; case 0x060B1056u: goto L_060B1056; case 0x060B105Au: goto L_060B105A; case 0x060B105Eu: goto L_060B105E; case 0x060B1060u: goto L_060B1060; case 0x060B1064u: goto L_060B1064; case 0x060B1068u: goto L_060B1068; case 0x060B106Au: goto L_060B106A; case 0x060B106Eu: goto L_060B106E; case 0x060B1072u: goto L_060B1072; case 0x060B1074u: goto L_060B1074; case 0x060B1078u: goto L_060B1078; case 0x060B107Cu: goto L_060B107C; case 0x060B107Eu: goto L_060B107E; case 0x060B1082u: goto L_060B1082; case 0x060B1086u: goto L_060B1086; case 0x060B1088u: goto L_060B1088; case 0x060B108Cu: goto L_060B108C; case 0x060B108Eu: goto L_060B108E; case 0x060B1090u: goto L_060B1090; case 0x060B1092u: goto L_060B1092; case 0x060B1094u: goto L_060B1094; default: sh2_call(c, x); return; } }  // 060B0FF0 jmp @r0 ; nop
L_060B101A:
    c.r[0] = ld32(c.r[1] + 4);  // 060B101A mov.l @(4,r1),r0
L_060B101C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B101C shar r0
L_060B101E:
    { const bool k = !c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B1032; } }  // 060B101E bf/s 0x060B1032 ; mov.l @(4,r2),r0
L_060B1022:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B1022 shar r0
L_060B1024:
    { const bool k = !c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B1032; } }  // 060B1024 bf/s 0x060B1032 ; mov.l @(4,r3),r0
L_060B1028:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B1028 shar r0
L_060B102A:
    { const bool k = !c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B1032; } }  // 060B102A bf/s 0x060B1032 ; mov.l @(4,r4),r0
L_060B102E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B102E shar r0
L_060B1030:
    if (c.t) { goto L_060B1092; }  // 060B1030 bt 0x060B1092
L_060B1032:
    c.r[0] = ld32(c.gbr + 888);  // 060B1032 mov.l @(888,gbr),r0
L_060B1034:
    c.t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31;  // 060B1034 rotr r0
L_060B1036:
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.r[14]); if (k) { goto L_060B108E; } }  // 060B1036 bt/s 0x060B108E ; mov.l r14,@-r15
L_060B103A:
    c.r[14] = (uint32_t)(int16_t)ld16(0x060B1098u);  // 060B103A mov.w 0x060B1098,r14
L_060B103C:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B109Au);  // 060B103C mov.w 0x060B109A,r5
L_060B103E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B103E mov.w @(0,r1),r0
L_060B1040:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1040 cmp/gt r5,r0
L_060B1042:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1042 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1046:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 2); if (k) { goto L_060B1090; } }  // 060B1046 bf/s 0x060B1090 ; mov.w @(2,r1),r0
L_060B104A:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B104A cmp/gt r5,r0
L_060B104C:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B104C bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1050:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); if (k) { goto L_060B1090; } }  // 060B1050 bf/s 0x060B1090 ; mov.w @(0,r2),r0
L_060B1054:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1054 cmp/gt r5,r0
L_060B1056:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1056 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B105A:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2); if (k) { goto L_060B1090; } }  // 060B105A bf/s 0x060B1090 ; mov.w @(2,r2),r0
L_060B105E:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B105E cmp/gt r5,r0
L_060B1060:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1060 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1064:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { goto L_060B1090; } }  // 060B1064 bf/s 0x060B1090 ; mov.w @(0,r3),r0
L_060B1068:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1068 cmp/gt r5,r0
L_060B106A:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B106A bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B106E:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 2); if (k) { goto L_060B1090; } }  // 060B106E bf/s 0x060B1090 ; mov.w @(2,r3),r0
L_060B1072:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1072 cmp/gt r5,r0
L_060B1074:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1074 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1078:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { goto L_060B1090; } }  // 060B1078 bf/s 0x060B1090 ; mov.w @(0,r4),r0
L_060B107C:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B107C cmp/gt r5,r0
L_060B107E:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B107E bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B1082:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 2); if (k) { goto L_060B1090; } }  // 060B1082 bf/s 0x060B1090 ; mov.w @(2,r4),r0
L_060B1086:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B1086 cmp/gt r5,r0
L_060B1088:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { goto L_060B1090; } }  // 060B1088 bt/s 0x060B1090 ; cmp/ge r14,r0
L_060B108C:
    if (!c.t) { goto L_060B1090; }  // 060B108C bf 0x060B1090
L_060B108E:
    c.r[9] += 4;  // 060B108E add #4,r9
L_060B1090:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B1090 mov.l @r15+,r14
L_060B1092:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B1092 mov.l @r9+,r0
L_060B1094:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B0FA8u: goto L_060B0FA8; case 0x060B0FAAu: goto L_060B0FAA; case 0x060B0FACu: goto L_060B0FAC; case 0x060B0FAEu: goto L_060B0FAE; case 0x060B0FB0u: goto L_060B0FB0; case 0x060B0FB2u: goto L_060B0FB2; case 0x060B0FB4u: goto L_060B0FB4; case 0x060B0FB6u: goto L_060B0FB6; case 0x060B0FB8u: goto L_060B0FB8; case 0x060B0FBAu: goto L_060B0FBA; case 0x060B0FBCu: goto L_060B0FBC; case 0x060B0FC0u: goto L_060B0FC0; case 0x060B0FC2u: goto L_060B0FC2; case 0x060B0FC4u: goto L_060B0FC4; case 0x060B0FC6u: goto L_060B0FC6; case 0x060B0FC8u: goto L_060B0FC8; case 0x060B0FCCu: goto L_060B0FCC; case 0x060B0FCEu: goto L_060B0FCE; case 0x060B0FD0u: goto L_060B0FD0; case 0x060B0FD2u: goto L_060B0FD2; case 0x060B0FD4u: goto L_060B0FD4; case 0x060B0FD6u: goto L_060B0FD6; case 0x060B0FD8u: goto L_060B0FD8; case 0x060B0FDAu: goto L_060B0FDA; case 0x060B0FDCu: goto L_060B0FDC; case 0x060B0FDEu: goto L_060B0FDE; case 0x060B0FE0u: goto L_060B0FE0; case 0x060B0FE2u: goto L_060B0FE2; case 0x060B0FE6u: goto L_060B0FE6; case 0x060B0FE8u: goto L_060B0FE8; case 0x060B0FEAu: goto L_060B0FEA; case 0x060B0FEEu: goto L_060B0FEE; case 0x060B0FF0u: goto L_060B0FF0; case 0x060B101Au: goto L_060B101A; case 0x060B101Cu: goto L_060B101C; case 0x060B101Eu: goto L_060B101E; case 0x060B1022u: goto L_060B1022; case 0x060B1024u: goto L_060B1024; case 0x060B1028u: goto L_060B1028; case 0x060B102Au: goto L_060B102A; case 0x060B102Eu: goto L_060B102E; case 0x060B1030u: goto L_060B1030; case 0x060B1032u: goto L_060B1032; case 0x060B1034u: goto L_060B1034; case 0x060B1036u: goto L_060B1036; case 0x060B103Au: goto L_060B103A; case 0x060B103Cu: goto L_060B103C; case 0x060B103Eu: goto L_060B103E; case 0x060B1040u: goto L_060B1040; case 0x060B1042u: goto L_060B1042; case 0x060B1046u: goto L_060B1046; case 0x060B104Au: goto L_060B104A; case 0x060B104Cu: goto L_060B104C; case 0x060B1050u: goto L_060B1050; case 0x060B1054u: goto L_060B1054; case 0x060B1056u: goto L_060B1056; case 0x060B105Au: goto L_060B105A; case 0x060B105Eu: goto L_060B105E; case 0x060B1060u: goto L_060B1060; case 0x060B1064u: goto L_060B1064; case 0x060B1068u: goto L_060B1068; case 0x060B106Au: goto L_060B106A; case 0x060B106Eu: goto L_060B106E; case 0x060B1072u: goto L_060B1072; case 0x060B1074u: goto L_060B1074; case 0x060B1078u: goto L_060B1078; case 0x060B107Cu: goto L_060B107C; case 0x060B107Eu: goto L_060B107E; case 0x060B1082u: goto L_060B1082; case 0x060B1086u: goto L_060B1086; case 0x060B1088u: goto L_060B1088; case 0x060B108Cu: goto L_060B108C; case 0x060B108Eu: goto L_060B108E; case 0x060B1090u: goto L_060B1090; case 0x060B1092u: goto L_060B1092; case 0x060B1094u: goto L_060B1094; default: sh2_call(c, x); return; } }  // 060B1094 jmp @r0 ; nop
}

void f_060B0FF4(SH2Context& c) {
    ran[3044] = 1;
L_060B0FF4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B0FF4 mov.w @(112,gbr),r0
L_060B0FF6:
    c.r[2] <<= 2;  // 060B0FF6 shll2 r2
L_060B0FF8:
    c.t = c.r[14] > c.r[0];  // 060B0FF8 cmp/hi r0,r14
L_060B0FFA:
    { const bool k = c.t; c.r[2] += c.r[10]; if (k) { goto L_060B1014; } }  // 060B0FFA bt/s 0x060B1014 ; add r10,r2
L_060B0FFE:
    c.r[9] += 4;  // 060B0FFE add #4,r9
L_060B1000:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B1000 mov.w @r7+,r3
L_060B1002:
    c.r[3] <<= 2;  // 060B1002 shll2 r3
L_060B1004:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B1004 mov.w @r7+,r4
L_060B1006:
    c.r[3] <<= 2;  // 060B1006 shll2 r3
L_060B1008:
    c.r[3] += c.r[10];  // 060B1008 add r10,r3
L_060B100A:
    c.r[4] <<= 2;  // 060B100A shll2 r4
L_060B100C:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B100C mov.l @r9+,r0
L_060B100E:
    c.r[4] <<= 2;  // 060B100E shll2 r4
L_060B1010:
    { const uint32_t x = c.r[0]; c.r[4] += c.r[10]; SH2_POLL(c); switch (x) { case 0x060B0FF4u: goto L_060B0FF4; case 0x060B0FF6u: goto L_060B0FF6; case 0x060B0FF8u: goto L_060B0FF8; case 0x060B0FFAu: goto L_060B0FFA; case 0x060B0FFEu: goto L_060B0FFE; case 0x060B1000u: goto L_060B1000; case 0x060B1002u: goto L_060B1002; case 0x060B1004u: goto L_060B1004; case 0x060B1006u: goto L_060B1006; case 0x060B1008u: goto L_060B1008; case 0x060B100Au: goto L_060B100A; case 0x060B100Cu: goto L_060B100C; case 0x060B100Eu: goto L_060B100E; case 0x060B1010u: goto L_060B1010; case 0x060B1014u: goto L_060B1014; case 0x060B1016u: goto L_060B1016; default: sh2_call(c, x); return; } }  // 060B1010 jmp @r0 ; add r10,r4
L_060B1014:
    c.r[0] = ld32(c.r[9]);  // 060B1014 mov.l @r9,r0
L_060B1016:
    { const uint32_t x = c.r[0]; c.r[7] += 4; SH2_POLL(c); switch (x) { case 0x060B0FF4u: goto L_060B0FF4; case 0x060B0FF6u: goto L_060B0FF6; case 0x060B0FF8u: goto L_060B0FF8; case 0x060B0FFAu: goto L_060B0FFA; case 0x060B0FFEu: goto L_060B0FFE; case 0x060B1000u: goto L_060B1000; case 0x060B1002u: goto L_060B1002; case 0x060B1004u: goto L_060B1004; case 0x060B1006u: goto L_060B1006; case 0x060B1008u: goto L_060B1008; case 0x060B100Au: goto L_060B100A; case 0x060B100Cu: goto L_060B100C; case 0x060B100Eu: goto L_060B100E; case 0x060B1010u: goto L_060B1010; case 0x060B1014u: goto L_060B1014; case 0x060B1016u: goto L_060B1016; default: sh2_call(c, x); return; } }  // 060B1016 jmp @r0 ; add #4,r7
}

void f_060B109C(SH2Context& c) {
    ran[3045] = 1;
    c.r[0] = ld32(0x060B1110u);  // 060B109C mov.l 0x060B1110,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B109E sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060B10A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B10A4u) return; }  // 060B10A0 jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B10A4 lds.l @r15+,pr
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B10A6 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B10A8 mov.l r4,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060B10AA mov.l @(28,gbr),r0
    c.r[1] = c.r[15];  // 060B10AC mov r15,r1
    c.r[7] = ld32(c.r[0]);  // 060B10AE mov.l @(0,r0),r7
    c.r[4] = 0u - c.r[4];  // 060B10B0 neg r4,r4
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B10B2 dmuls.l r5,r7
    c.r[6] = c.r[0];  // 060B10B4 mov r0,r6
    c.r[0] += 4;  // 060B10B6 add #4,r0
    sh2_mac_l(c, 0, 1);  // 060B10B8 mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060B10BA add #-4,r0
    c.r[2] = c.mach;  // 060B10BC sts mach,r2
    c.r[3] = c.macl;  // 060B10BE sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B10C0 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B10C2 xtrct r2,r3
    st32(c.r[6], c.r[3]);  // 060B10C4 mov.l r3,@(0,r6)
    sh2_mac_l(c, 0, 1);  // 060B10C6 mac.l @r1+,@r0+
    c.r[0] += 8;  // 060B10C8 add #8,r0
    c.r[1] = c.r[15];  // 060B10CA mov r15,r1
    c.r[7] = ld32(c.r[0]); c.r[0] += 4;  // 060B10CC mov.l @r0+,r7
    c.r[2] = c.mach;  // 060B10CE sts mach,r2
    c.r[3] = c.macl;  // 060B10D0 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B10D2 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B10D4 xtrct r2,r3
    st32(c.r[6] + 4, c.r[3]);  // 060B10D6 mov.l r3,@(4,r6)
    sh2_mac_l(c, 0, 1);  // 060B10D8 mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060B10DA add #-4,r0
    c.r[2] = c.mach;  // 060B10DC sts mach,r2
    c.r[3] = c.macl;  // 060B10DE sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B10E0 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B10E2 xtrct r2,r3
    st32(c.r[6] + 16, c.r[3]);  // 060B10E4 mov.l r3,@(16,r6)
    sh2_mac_l(c, 0, 1);  // 060B10E6 mac.l @r1+,@r0+
    c.r[0] += 8;  // 060B10E8 add #8,r0
    c.r[7] = ld32(c.r[0]); c.r[0] += 4;  // 060B10EA mov.l @r0+,r7
    c.r[2] = c.mach;  // 060B10EC sts mach,r2
    c.r[3] = c.macl;  // 060B10EE sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B10F0 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B10F2 xtrct r2,r3
    st32(c.r[6] + 20, c.r[3]);  // 060B10F4 mov.l r3,@(20,r6)
    sh2_mac_l(c, 0, 15);  // 060B10F6 mac.l @r15+,@r0+
    c.r[0] -= 4;  // 060B10F8 add #-4,r0
    c.r[2] = c.mach;  // 060B10FA sts mach,r2
    c.r[3] = c.macl;  // 060B10FC sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B10FE dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B1100 xtrct r2,r3
    st32(c.r[6] + 32, c.r[3]);  // 060B1102 mov.l r3,@(32,r6)
    sh2_mac_l(c, 0, 15);  // 060B1104 mac.l @r15+,@r0+
    c.r[2] = c.mach;  // 060B1106 sts mach,r2
    c.r[3] = c.macl;  // 060B1108 sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B110A xtrct r2,r3
    { const uint32_t x = c.pr; st32(c.r[6] + 36, c.r[3]); c.pc = x; return; }  // 060B110C rts ; mov.l r3,@(36,r6)
}

void f_060B1114(SH2Context& c) {
    ran[3046] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B1114 mov.l r0,@-r15
    c.r[0] = ld32(0x060B13FCu);  // 060B1116 mov.l 0x060B13FC,r0
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060B1118 stc.l gbr,@-r15
    c.gbr = c.r[0];  // 060B111A ldc r0,gbr
    c.r[0] = 0x0u;  // 060B111C mov #0,r0
    { uint32_t a = c.gbr + c.r[0]; st8(a, ld8(a) | 0x6u); }  // 060B111E or.b #6,@(r0,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060B1120 ldc.l @r15+,gbr
    { const uint32_t x = c.pr; c.r[0] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B1122 rts ; mov.l @r15+,r0
}

void f_060B1126(SH2Context& c) {
    ran[3047] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B1126 mov.l r0,@-r15
    c.r[0] = ld32(0x060B13FCu);  // 060B1128 mov.l 0x060B13FC,r0
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060B112A stc.l gbr,@-r15
    c.gbr = c.r[0];  // 060B112C ldc r0,gbr
    c.r[0] = 0x1u;  // 060B112E mov #1,r0
    { uint32_t a = c.gbr + c.r[0]; st8(a, ld8(a) | 0x6u); }  // 060B1130 or.b #6,@(r0,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060B1132 ldc.l @r15+,gbr
    { const uint32_t x = c.pr; c.r[0] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B1134 rts ; mov.l @r15+,r0
}

void f_060B1138(SH2Context& c) {
    ran[3048] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B1138 mov.l r0,@-r15
    c.r[0] = ld32(0x060B13FCu);  // 060B113A mov.l 0x060B13FC,r0
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060B113C stc.l gbr,@-r15
    c.gbr = c.r[0];  // 060B113E ldc r0,gbr
    c.r[0] = 0x2u;  // 060B1140 mov #2,r0
    { uint32_t a = c.gbr + c.r[0]; st8(a, ld8(a) | 0x6u); }  // 060B1142 or.b #6,@(r0,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060B1144 ldc.l @r15+,gbr
    { const uint32_t x = c.pr; c.r[0] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B1146 rts ; mov.l @r15+,r0
}

void f_060B114A(SH2Context& c) {
    ran[3049] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B114A mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060B114C mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060B114E mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B1150 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1152 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B1154 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060B1156 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1158 sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B115A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060B115C stc.l gbr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 060B115E sts.l mach,@-r15
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 060B1160 sts.l macl,@-r15
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 060B1162 stc.l sr,@-r15
    c.r[0] = 0x0u;  // 060B1164 mov #0,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 060B1166 ldc r0,sr
    c.r[0] = ld32(0x060B13B4u);  // 060B1168 mov.l 0x060B13B4,r0
    c.r[2] = 0xFFFFFF84u;  // 060B116A mov #-124,r2
    c.r[2] <<= 2;  // 060B116C shll2 r2
    c.gbr = c.r[0];  // 060B116E ldc r0,gbr
    c.r[2] += 2;  // 060B1170 add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B1172 mov.b @r2+,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B1174 mov.b @r2+,r2
    c.r[0] <<= 8;  // 060B1176 shll8 r0
    c.r[2] = c.r[2] & 0xFFu;  // 060B1178 extu.b r2,r2
    c.r[0] |= c.r[2];  // 060B117A or r2,r0
    st16(c.gbr + 182, c.r[0]);  // 060B117C mov.w r0,@(182,gbr)
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060B117E mov.b @(19,gbr),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B1180 tst r0,r0
    if (!c.t) { goto L_060B11E0; }  // 060B1182 bf 0x060B11E0
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 27);  // 060B1184 mov.b @(27,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060B1186 tst #1,r0
    if (!c.t) { goto L_060B11E0; }  // 060B1188 bf 0x060B11E0
    c.r[4] = ld32(0x060B13B8u);  // 060B118A mov.l 0x060B13B8,r4
    c.r[5] = ld32(0x060B13BCu);  // 060B118C mov.l 0x060B13BC,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060B129Cu);  // 060B118E mov.w 0x060B129C,r6
    c.r[3] = 0xFFFFFF90u;  // 060B1190 mov #-112,r3
L_060B1192:
    c.r[0] = ld32(c.r[3] + 12);  // 060B1192 mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060B1194 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060B1196 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060B1192; }  // 060B1198 bt 0x060B1192
    c.r[0] = ld32(c.r[3] + 32);  // 060B119A mov.l @(32,r3),r0
    c.r[0] = 0x0u;  // 060B119C mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060B119E mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060B11A0 mov #-100,r3
    c.r[3] <<= 2;  // 060B11A2 shll2 r3
    st8(c.r[3] + 2, c.r[0]);  // 060B11A4 mov.b r0,@(2,r3)
    c.r[3] = 0xFFFFFF90u;  // 060B11A6 mov #-112,r3
    st32(c.r[3], c.r[4]);  // 060B11A8 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060B11AA mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060B11AC mov.l r6,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B136Eu);  // 060B11AE mov.w 0x060B136E,r0
    st32(c.r[3] + 12, c.r[0]);  // 060B11B0 mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060B11B2 mov #9,r0
    st32(c.r[3] + 32, c.r[0]);  // 060B11B4 mov.l r0,@(32,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 224);  // 060B11B6 mov.w @(224,gbr),r0
    c.t = (c.r[0] & 0x30u) == 0;  // 060B11B8 tst #48,r0
    if (c.t) { goto L_060B11D6; }  // 060B11BA bt 0x060B11D6
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 204);  // 060B11BC mov.b @(204,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060B11BE tst #1,r0
    if (c.t) { goto L_060B11D6; }  // 060B11C0 bt 0x060B11D6
    c.r[0] = ld32(c.gbr + 532);  // 060B11C2 mov.l @(532,gbr),r0
    c.r[4] = ld32(0x060B13C0u);  // 060B11C4 mov.l 0x060B13C0,r4
    c.r[5] = c.r[0];  // 060B11C6 mov r0,r5
    c.pr = 0x060B11CCu; c.r[6] = 0x30u; SH2_POLL(c); sh2_call(c, 0x060B1272u); if (c.pc != 0x060B11CCu) return;  // 060B11C8 bsr 0x060B1272 ; mov #48,r6
    c.r[0] = 0xFFFFFF80u;  // 060B11CC mov #-128,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060B11CE extu.b r0,r0
    c.r[5] += c.r[0];  // 060B11D0 add r0,r5
    c.pr = 0x060B11D6u; c.r[4] += 104; SH2_POLL(c); sh2_call(c, 0x060B1272u); if (c.pc != 0x060B11D6u) return;  // 060B11D2 bsr 0x060B1272 ; add #104,r4
L_060B11D6:
    c.r[1] = 0xFFFFFF90u;  // 060B11D6 mov #-112,r1
L_060B11D8:
    c.r[0] = ld32(c.r[1] + 12);  // 060B11D8 mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060B11DA and #3,r0
    c.t = c.r[0] == 0x1u;  // 060B11DC cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060B11D8; }  // 060B11DE bt 0x060B11D8
L_060B11E0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 26);  // 060B11E0 mov.b @(26,gbr),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B11E2 tst r0,r0
    if (c.t) { goto L_060B1216; }  // 060B11E4 bt 0x060B1216
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 189);  // 060B11E6 mov.b @(189,gbr),r0
L_060B11E8:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B11E8 tst #4,r0
    if (!c.t) { goto L_060B11F6; }  // 060B11EA bf 0x060B11F6
    c.r[0] = 0x30u;  // 060B11EC mov #48,r0
L_060B11EE:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B11EE dt r0
    if (!c.t) { SH2_POLL(c); goto L_060B11EE; }  // 060B11F0 bf 0x060B11EE
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 189); SH2_POLL(c); goto L_060B11E8;  // 060B11F2 bra 0x060B11E8 ; mov.b @(189,gbr),r0
L_060B11F6:
    c.r[3] = ld32(0x060B13C8u);  // 060B11F6 mov.l 0x060B13C8,r3
    c.r[0] = ld32(0x060B13D0u);  // 060B11F8 mov.l 0x060B13D0,r0
    c.r[2] = 0x0u;  // 060B11FA mov #0,r2
    st32(c.r[3] + 16, c.r[2]);  // 060B11FC mov.l r2,@(16,r3)
    c.r[0] = ld32(c.r[0]);  // 060B11FE mov.l @r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B1370u);  // 060B1200 mov.w 0x060B1370,r1
    st32(c.r[3] + 4, c.r[0]);  // 060B1202 mov.l r0,@(4,r3)
    c.r[0] = ld32(0x060B13D4u);  // 060B1204 mov.l 0x060B13D4,r0
    st32(c.r[3] + 12, c.r[1]);  // 060B1206 mov.l r1,@(12,r3)
    st32(c.r[3] + 20, c.r[0]);  // 060B1208 mov.l r0,@(20,r3)
    c.r[0] = 0x8u;  // 060B120A mov #8,r0
    st8(c.gbr + 189, c.r[0]);  // 060B120C mov.b r0,@(189,gbr)
    st32(c.r[3] + 16, c.r[1]);  // 060B120E mov.l r1,@(16,r3)
    c.r[0] = 0x0u;  // 060B1210 mov #0,r0
    st16(c.gbr + 24, c.r[0]);  // 060B1212 mov.w r0,@(24,gbr)
    st8(c.gbr + 26, c.r[0]);  // 060B1214 mov.b r0,@(26,gbr)
L_060B1216:
    c.r[0] = ld32(c.gbr + 20);  // 060B1216 mov.l @(20,gbr),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060B121Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B121Cu) return; }  // 060B1218 jsr @r0 ; nop
    c.r[0] = ld32(0x060B13D8u);  // 060B121C mov.l 0x060B13D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060B1222u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1222u) return; }  // 060B121E jsr @r0 ; nop
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060B1222 mov.b @(19,gbr),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B1224 tst r0,r0
    if (!c.t) { goto L_060B1250; }  // 060B1226 bf 0x060B1250
L_060B1228:
    c.r[2] = 0xFFFFFF84u;  // 060B1228 mov #-124,r2
    c.r[2] <<= 2;  // 060B122A shll2 r2
    c.r[2] += 2;  // 060B122C add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B122E mov.b @r2+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B1230 mov.b @r2+,r2
    c.r[1] <<= 8;  // 060B1232 shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 060B1234 extu.b r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 182);  // 060B1236 mov.w @(182,gbr),r0
    c.r[1] |= c.r[2];  // 060B1238 or r2,r1
    c.r[2] = 0x44u;  // 060B123A mov #68,r2
    c.r[1] -= c.r[0];  // 060B123C sub r0,r1
    c.t = c.r[1] >= c.r[2];  // 060B123E cmp/hs r2,r1
    if (c.t) { goto L_060B124A; }  // 060B1240 bt 0x060B124A
L_060B1242:
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060B1242 dt r2
    if (!c.t) { SH2_POLL(c); goto L_060B1242; }  // 060B1244 bf 0x060B1242
    SH2_POLL(c); goto L_060B1228;  // 060B1246 bra 0x060B1228 ; nop
L_060B124A:
    c.r[0] = ld32(0x060B13DCu);  // 060B124A mov.l 0x060B13DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060B1250u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1250u) return; }  // 060B124C jsr @r0 ; nop
L_060B1250:
    c.r[0] = ld32(c.gbr + 832);  // 060B1250 mov.l @(832,gbr),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060B1256u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1256u) return; }  // 060B1252 jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 060B1256 ldc.l @r15+,sr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 060B1258 lds.l @r15+,macl
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 060B125A lds.l @r15+,mach
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060B125C ldc.l @r15+,gbr
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B125E mov.l @r15+,r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1260 lds.l @r15+,pr
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B1262 mov.l @r15+,r2
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060B1264 mov.l @r15+,r3
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1266 mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B1268 mov.l @r15+,r5
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060B126A mov.l @r15+,r6
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060B126C mov.l @r15+,r7
    { const uint32_t x = c.pr; c.r[0] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B126E rts ; mov.l @r15+,r0
}

void f_060B1272(SH2Context& c) {
    ran[3050] = 1;
    c.r[3] = 0xFFFFFF90u;  // 060B1272 mov #-112,r3
L_060B1274:
    c.r[0] = ld32(c.r[3] + 12);  // 060B1274 mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060B1276 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060B1278 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060B1274; }  // 060B127A bt 0x060B1274
    c.r[0] = ld32(c.r[3] + 32);  // 060B127C mov.l @(32,r3),r0
    c.r[0] = 0x0u;  // 060B127E mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060B1280 mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060B1282 mov #-100,r3
    c.r[3] <<= 2;  // 060B1284 shll2 r3
    st8(c.r[3] + 2, c.r[0]);  // 060B1286 mov.b r0,@(2,r3)
    c.r[3] = 0xFFFFFF90u;  // 060B1288 mov #-112,r3
    st32(c.r[3], c.r[4]);  // 060B128A mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060B128C mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060B128E mov.l r6,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B136Eu);  // 060B1290 mov.w 0x060B136E,r0
    st32(c.r[3] + 12, c.r[0]);  // 060B1292 mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060B1294 mov #9,r0
    st32(c.r[3] + 32, c.r[0]);  // 060B1296 mov.l r0,@(32,r3)
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1298 rts ; nop
}

void f_060B129E(SH2Context& c) {
    ran[3051] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B129E mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B12A0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060B12A2 stc.l gbr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B12A4 sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060B12A6 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060B12A8 mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B12AA mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B12AC mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B12AE mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060B12B0 mov.l r2,@-r15
    c.r[3] = ld32(0x060B13B4u);  // 060B12B2 mov.l 0x060B13B4,r3
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 060B12B4 sts.l mach,@-r15
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 060B12B6 sts.l macl,@-r15
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 060B12B8 stc.l sr,@-r15
    c.r[0] = 0x0u;  // 060B12BA mov #0,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 060B12BC ldc r0,sr
    c.gbr = c.r[3];  // 060B12BE ldc r3,gbr
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060B12C0 mov.b @(176,gbr),r0
    c.r[2] = ld32(0x060B13E4u);  // 060B12C2 mov.l 0x060B13E4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060B12C4 tst #16,r0
    { const bool k = !c.t; c.t = (c.r[0] & 0x80u) == 0; if (k) { goto L_060B131E; } }  // 060B12C6 bf/s 0x060B131E ; tst #128,r0
    { const bool k = !c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 27); if (k) { goto L_060B12F8; } }  // 060B12CA bf/s 0x060B12F8 ; mov.b @(27,gbr),r0
    c.r[3] += 18;  // 060B12CE add #18,r3
    c.t = (c.r[0] & 0x2u) == 0;  // 060B12D0 tst #2,r0
    { const bool k = !c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1; if (k) { goto L_060B137E; } }  // 060B12D2 bf/s 0x060B137E ; mov.b @r3+,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060B12D6 mov.b @r3,r3
    c.t = c.r[0] == 0x1u;  // 060B12D8 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_060B1330; } }  // 060B12DA bt/s 0x060B1330 ; mov #0,r1
    c.r[0] = c.r[3];  // 060B12DE mov r3,r0
    c.r[3] = ld32(0x060B13ECu);  // 060B12E0 mov.l 0x060B13EC,r3
    c.t = c.r[0] == 0x1u;  // 060B12E2 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060B12F4; } }  // 060B12E4 bt/s 0x060B12F4 ; mov #2,r1
    c.t = (int32_t)c.r[0] > 0;  // 060B12E8 cmp/pl r0
    { const bool k = c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]); if (k) { goto L_060B137E; } }  // 060B12EA bt/s 0x060B137E ; mov.b @r3,r0
    c.r[1] = 0x3u;  // 060B12EE mov #3,r1
    st16(c.r[2], c.r[1]); goto L_060B1340;  // 060B12F0 bra 0x060B1340 ; mov.w r1,@r2
L_060B12F4:
    st16(c.r[2], c.r[1]); goto L_060B137E;  // 060B12F4 bra 0x060B137E ; mov.w r1,@r2
L_060B12F8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060B12F8 mov.b @(19,gbr),r0
    c.r[2] += 14;  // 060B12FA add #14,r2
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B12FC tst r0,r0
    { const bool k = !c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 27); if (k) { goto L_060B137E; } }  // 060B12FE bf/s 0x060B137E ; mov.b @(27,gbr),r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060B1302 mov.w @r2,r3
    c.t = (c.r[0] & 0x2u) == 0;  // 060B1304 tst #2,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_060B137E; } }  // 060B1306 bf/s 0x060B137E ; mov r3,r0
    c.r[1] = ld32(0x060B13ECu);  // 060B130A mov.l 0x060B13EC,r1
    c.t = (c.r[0] & 0x2u) == 0;  // 060B130C tst #2,r0
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); if (k) { goto L_060B1372; } }  // 060B130E bt/s 0x060B1372 ; mov.b @r1,r1
    c.r[2] -= 14;  // 060B1312 add #-14,r2
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B1314 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x3u; if (k) { goto L_060B1372; } }  // 060B1316 bt/s 0x060B1372 ; mov #3,r1
    st16(c.r[2], c.r[1]); goto L_060B1340;  // 060B131A bra 0x060B1340 ; mov.w r1,@r2
L_060B131E:
    c.r[1] = ld32(0x060B13E8u);  // 060B131E mov.l 0x060B13E8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 27);  // 060B1320 mov.b @(27,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B1322 mov.w @r1,r1
    c.r[3] = 0x2u;  // 060B1324 mov #2,r3
    c.r[1] &= c.r[3];  // 060B1326 and r3,r1
    c.r[1] += 4;  // 060B1328 add #4,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060B132A shll r1
    c.t = (c.r[0] & 0x2u) == 0;  // 060B132C tst #2,r0
    { const bool k = !c.t; st16(c.r[2], c.r[1]); if (k) { goto L_060B137E; } }  // 060B132E bf/s 0x060B137E ; mov.w r1,@r2
    goto L_060B1332;
L_060B1330:
    st16(c.r[2], c.r[1]);  // 060B1330 mov.w r1,@r2
L_060B1332:
    c.r[2] = ld32(0x060B13ECu);  // 060B1332 mov.l 0x060B13EC,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060B1334 mov.b @(19,gbr),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B1336 mov.b @r2,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B1338 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_060B137E; } }  // 060B133A bf/s 0x060B137E ; tst r1,r1
    { const bool k = c.t; c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 188); if (k) { goto L_060B1372; } }  // 060B133E bt/s 0x060B1372 ; mov.b @(188,gbr),r0
    goto L_060B1342;
L_060B1340:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 188);  // 060B1340 mov.b @(188,gbr),r0
L_060B1342:
    c.r[3] = ld32(0x060B13F0u);  // 060B1342 mov.l 0x060B13F0,r3
L_060B1344:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B1344 tst #4,r0
    { const bool k = !c.t; c.r[1] = 0x30u; if (k) { goto L_060B1352; } }  // 060B1346 bf/s 0x060B1352 ; mov #48,r1
L_060B134A:
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B134A dt r1
    if (!c.t) { SH2_POLL(c); goto L_060B134A; }  // 060B134C bf 0x060B134A
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 188); SH2_POLL(c); goto L_060B1344;  // 060B134E bra 0x060B1344 ; mov.b @(188,gbr),r0
L_060B1352:
    c.r[0] = 0x0u;  // 060B1352 mov #0,r0
    st32(c.r[3] + 16, c.r[0]);  // 060B1354 mov.l r0,@(16,r3)
    st8(c.gbr + 168, c.r[0]);  // 060B1356 mov.b r0,@(168,gbr)
    c.r[0] = ld32(0x060B13F8u);  // 060B1358 mov.l 0x060B13F8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B1370u);  // 060B135A mov.w 0x060B1370,r1
    c.r[0] = ld32(c.r[0]);  // 060B135C mov.l @r0,r0
    c.r[2] = ld32(0x060B13D4u);  // 060B135E mov.l 0x060B13D4,r2
    st32(c.r[3] + 4, c.r[0]);  // 060B1360 mov.l r0,@(4,r3)
    st32(c.r[3] + 12, c.r[1]);  // 060B1362 mov.l r1,@(12,r3)
    st32(c.r[3] + 20, c.r[2]);  // 060B1364 mov.l r2,@(20,r3)
    c.r[0] = 0x8u;  // 060B1366 mov #8,r0
    st8(c.gbr + 188, c.r[0]);  // 060B1368 mov.b r0,@(188,gbr)
    st32(c.r[3] + 16, c.r[1]); goto L_060B137E;  // 060B136A bra 0x060B137E ; mov.l r1,@(16,r3)
L_060B1372:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060B1372 mov.b @(176,gbr),r0
    c.r[0] &= 0x10u;  // 060B1374 and #16,r0
    c.r[0] >>= 2;  // 060B1376 shlr2 r0
    c.r[0] >>= 2;  // 060B1378 shlr2 r0
    c.r[0] += 1;  // 060B137A add #1,r0
    st8(c.gbr + 19, c.r[0]);  // 060B137C mov.b r0,@(19,gbr)
L_060B137E:
    c.r[0] = ld32(0x060B13E0u);  // 060B137E mov.l 0x060B13E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060B1384u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1384u) return; }  // 060B1380 jsr @r0 ; nop
    c.r[2] = ld32(0x060B13E8u);  // 060B1384 mov.l 0x060B13E8,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060B1386 mov.b @(19,gbr),r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 060B1388 ldc.l @r15+,sr
    c.r[0] -= 1;  // 060B138A add #-1,r0
    st8(c.gbr + 19, c.r[0]);  // 060B138C mov.b r0,@(19,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 4);  // 060B138E mov.w @(4,r2),r0
    st16(c.gbr + 196, c.r[0]);  // 060B1390 mov.w r0,@(196,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 34);  // 060B1392 mov.w @(34,gbr),r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 060B1394 lds.l @r15+,macl
    c.r[0] += 1;  // 060B1396 add #1,r0
    st16(c.gbr + 34, c.r[0]);  // 060B1398 mov.w r0,@(34,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 060B139A lds.l @r15+,mach
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B139C mov.l @r15+,r2
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060B139E mov.l @r15+,r3
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B13A0 mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B13A2 mov.l @r15+,r5
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060B13A4 mov.l @r15+,r6
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060B13A6 mov.l @r15+,r7
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B13A8 lds.l @r15+,pr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060B13AA ldc.l @r15+,gbr
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B13AC mov.l @r15+,r1
    { const uint32_t x = c.pr; c.r[0] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B13AE rts ; mov.l @r15+,r0
}

void f_060B1400(SH2Context& c) {
    ran[3052] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060B1400 mov.b @(176,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1402 sts.l pr,@-r15
    c.r[0] &= 0x1Fu;  // 060B1404 and #31,r0
    c.t = (int32_t)c.r[5] >= 0;  // 060B1406 cmp/pz r5
    { const bool k = c.t; c.r[1] = 0x78u; if (k) { goto L_060B1410; } }  // 060B1408 bt/s 0x060B1410 ; mov #120,r1
    c.r[0] |= 0x80u;  // 060B140C or #128,r0
    c.r[5] = 0u - c.r[5];  // 060B140E neg r5,r5
L_060B1410:
    c.t = c.r[5] > c.r[1];  // 060B1410 cmp/hi r1,r5
    { const bool k = !c.t; st8(c.gbr + 176, c.r[0]); if (k) { goto L_060B1416; } }  // 060B1412 bf/s 0x060B1416 ; mov.b r0,@(176,gbr)
L_060B1416:
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B1416 tst r5,r5
    { const bool k = !c.t; c.r[0] = 0x10u; if (k) { goto L_060B141E; } }  // 060B1418 bf/s 0x060B141E ; mov #16,r0
    c.r[5] = 0x1u;  // 060B141C mov #1,r5
L_060B141E:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B141E cmp/ge r0,r4
    if (!c.t) { goto L_060B1428; }  // 060B1420 bf 0x060B1428
    c.r[5] += 1;  // 060B1422 add #1,r5
    c.r[0] = 0xFFFFFFFEu;  // 060B1424 mov #-2,r0
    c.r[5] &= c.r[0];  // 060B1426 and r0,r5
L_060B1428:
    c.r[0] = c.r[5] & 0xFFu;  // 060B1428 extu.b r5,r0
    c.r[5] -= 1;  // 060B142A add #-1,r5
    c.r[0] <<= 8;  // 060B142C shll8 r0
    c.r[0] |= c.r[5];  // 060B142E or r5,r0
    st16(c.gbr + 18, c.r[0]);  // 060B1430 mov.w r0,@(18,gbr)
    c.r[0] = ld32(0x060B1494u);  // 060B1432 mov.l 0x060B1494,r0
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060B1434 mov.l r8,@-r15
    c.r[8] = ld32(c.r[0]);  // 060B1436 mov.l @r0,r8
    c.r[5] = ld32(0x060B1498u);  // 060B1438 mov.l 0x060B1498,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060B143Eu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B143Eu) return; }  // 060B143A jsr @r8 ; mov #64,r4
    c.r[5] = ld32(0x060B149Cu);  // 060B143E mov.l 0x060B149C,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060B1444u; c.r[4] = 0x41u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1444u) return; }  // 060B1440 jsr @r8 ; mov #65,r4
    c.r[5] = ld32(0x060B14A0u);  // 060B1444 mov.l 0x060B14A0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060B144Au; c.r[4] = 0x4Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B144Au) return; }  // 060B1446 jsr @r8 ; mov #75,r4
    c.r[5] = ld32(0x060B14A4u);  // 060B144A mov.l 0x060B14A4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060B1450u; c.r[4] = 0x4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1450u) return; }  // 060B144C jsr @r8 ; mov #74,r4
    c.r[5] = ld32(0x060B14A8u);  // 060B1450 mov.l 0x060B14A8,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060B1456u; c.r[4] = 0x49u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1456u) return; }  // 060B1452 jsr @r8 ; mov #73,r4
    c.r[0] = 0x4u;  // 060B1456 mov #4,r0
    st8(c.gbr + 185, c.r[0]);  // 060B1458 mov.b r0,@(185,gbr)
    st8(c.gbr + 186, c.r[0]);  // 060B145A mov.b r0,@(186,gbr)
    st8(c.gbr + 187, c.r[0]);  // 060B145C mov.b r0,@(187,gbr)
    st8(c.gbr + 188, c.r[0]);  // 060B145E mov.b r0,@(188,gbr)
    st8(c.gbr + 189, c.r[0]);  // 060B1460 mov.b r0,@(189,gbr)
    c.r[0] = 0x0u;  // 060B1462 mov #0,r0
    st32(c.gbr + 852, c.r[0]);  // 060B1464 mov.l r0,@(852,gbr)
    st32(c.gbr + 872, c.r[0]);  // 060B1466 mov.l r0,@(872,gbr)
    c.r[5] = ld32(0x060B14ACu);  // 060B1468 mov.l 0x060B14AC,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060B146Eu; c.r[4] = 0x47u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B146Eu) return; }  // 060B146A jsr @r8 ; mov #71,r4
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B146E mov.l @r15+,r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1470 lds.l @r15+,pr
    c.r[0] = 0x0u;  // 060B1472 mov #0,r0
    st8(c.gbr + 26, c.r[0]);  // 060B1474 mov.b r0,@(26,gbr)
    st16(c.gbr + 24, c.r[0]);  // 060B1476 mov.w r0,@(24,gbr)
    c.r[0] = 0x0u;  // 060B1478 mov #0,r0
    st16(c.gbr + 34, c.r[0]);  // 060B147A mov.w r0,@(34,gbr)
    st8(c.gbr + 27, c.r[0]);  // 060B147C mov.b r0,@(27,gbr)
    c.r[2] = 0xFFFFFF84u;  // 060B147E mov #-124,r2
    c.r[2] <<= 2;  // 060B1480 shll2 r2
    c.r[0] = 0x0u;  // 060B1482 mov #0,r0
    st8(c.r[2] + 1, c.r[0]);  // 060B1484 mov.b r0,@(1,r2)
    c.r[0] = 0x2u;  // 060B1486 mov #2,r0
    st8(c.r[2] + 6, c.r[0]);  // 060B1488 mov.b r0,@(6,r2)
    c.r[0] = 0x060B14B0u;  // 060B148A mova 0x060B14B0,r0
    st32(c.gbr + 832, c.r[0]);  // 060B148C mov.l r0,@(832,gbr)
    st32(c.gbr + 20, c.r[0]);  // 060B148E mov.l r0,@(20,gbr)
    { const uint32_t x = c.pr; st32(c.gbr + 972, c.r[0]); c.pc = x; return; }  // 060B1490 rts ; mov.l r0,@(972,gbr)
}

void f_060B14B0(SH2Context& c) {
    ran[3053] = 1;
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B14B0 rts ; nop
}

void f_060B14B4(SH2Context& c) {
    ran[3054] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060B14B4 mov.w @(232,gbr),r0
    c.r[1] = 0xFFFFFF81u;  // 060B14B6 mov #-127,r1
    c.r[0] &= c.r[1];  // 060B14B8 and r1,r0
    c.r[0] |= c.r[4];  // 060B14BA or r4,r0
    c.r[0] |= c.r[5];  // 060B14BC or r5,r0
    st16(c.gbr + 232, c.r[0]);  // 060B14BE mov.w r0,@(232,gbr)
    c.r[0] = c.r[6];  // 060B14C0 mov r6,r0
    st32(c.gbr + 508, c.r[0]);  // 060B14C2 mov.l r0,@(508,gbr)
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 253);  // 060B14C4 mov.b @(253,gbr),r0
    c.r[6] >>= 16;  // 060B14C6 shlr16 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060B14C8 shlr r6
    c.r[1] = 0xFu;  // 060B14CA mov #15,r1
    c.r[6] &= c.r[1];  // 060B14CC and r1,r6
    c.r[0] &= 0xF0u;  // 060B14CE and #240,r0
    c.r[0] |= c.r[6];  // 060B14D0 or r6,r0
    { const uint32_t x = c.pr; st8(c.gbr + 253, c.r[0]); c.pc = x; return; }  // 060B14D2 rts ; mov.b r0,@(253,gbr)
}

void f_060B14D8(SH2Context& c) {
    ran[3055] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 232);  // 060B14D8 mov.b @(232,gbr),r0
    c.r[1] = 0xFFFFFFC1u;  // 060B14DA mov #-63,r1
    c.r[0] &= c.r[1];  // 060B14DC and r1,r0
    c.r[0] |= c.r[4];  // 060B14DE or r4,r0
    c.r[0] |= c.r[5];  // 060B14E0 or r5,r0
    st8(c.gbr + 232, c.r[0]);  // 060B14E2 mov.b r0,@(232,gbr)
    c.r[0] = c.r[6];  // 060B14E4 mov r6,r0
    st32(c.gbr + 512, c.r[0]);  // 060B14E6 mov.l r0,@(512,gbr)
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 253);  // 060B14E8 mov.b @(253,gbr),r0
    c.r[6] >>= 16;  // 060B14EA shlr16 r6
    c.r[6] <<= 2;  // 060B14EC shll2 r6
    c.t = c.r[6] >> 31; c.r[6] <<= 1;  // 060B14EE shll r6
    c.r[1] = 0xFFFFFFF0u;  // 060B14F0 mov #-16,r1
    c.r[6] &= c.r[1];  // 060B14F2 and r1,r6
    c.r[0] &= 0xFu;  // 060B14F4 and #15,r0
    c.r[0] |= c.r[6];  // 060B14F6 or r6,r0
    { const uint32_t x = c.pr; st8(c.gbr + 253, c.r[0]); c.pc = x; return; }  // 060B14F8 rts ; mov.b r0,@(253,gbr)
}

void f_060B14FC(SH2Context& c) {
    ran[3056] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 060B14FC tst r4,r4
    { const bool k = c.t; c.r[3] = 0xFFFFFF8Cu; if (k) { goto L_060B1516; } }  // 060B14FE bt/s 0x060B1516 ; mov #-116,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 186);  // 060B1502 mov.b @(186,gbr),r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B1504 tst #16,r0
    { const bool k = c.t; c.r[3] = 0xFFFFFF9Cu; if (k) { goto L_060B1526; } }  // 060B1506 bt/s 0x060B1526 ; mov #-100,r3
    c.r[0] = ld32(c.r[3]);  // 060B150A mov.l @r3,r0
    c.r[0] &= 0xFEu;  // 060B150C and #254,r0
    st32(c.r[3], c.r[0]);  // 060B150E mov.l r0,@r3
    c.r[0] = 0x4u;  // 060B1510 mov #4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 186, c.r[0]); c.pc = x; return; }  // 060B1512 rts ; mov.b r0,@(186,gbr)
L_060B1516:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 185);  // 060B1516 mov.b @(185,gbr),r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B1518 tst #16,r0
    if (c.t) { goto L_060B1526; }  // 060B151A bt 0x060B1526
    c.r[0] = ld32(c.r[3]);  // 060B151C mov.l @r3,r0
    c.r[0] &= 0xFEu;  // 060B151E and #254,r0
    st32(c.r[3], c.r[0]);  // 060B1520 mov.l r0,@r3
    c.r[0] = 0x4u;  // 060B1522 mov #4,r0
    st8(c.gbr + 185, c.r[0]);  // 060B1524 mov.b r0,@(185,gbr)
L_060B1526:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1526 rts ; nop
}

void f_060B152C(SH2Context& c) {
    ran[3057] = 1;
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B152C rts ; nop
}

void f_060B1530(SH2Context& c) {
    ran[3058] = 1;
    c.r[6] = ld32(0x060B15C8u);  // 060B1530 mov.l 0x060B15C8,r6
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B1532 tst r5,r5
    if (c.t) { goto L_060B1538; }  // 060B1534 bt 0x060B1538
    c.r[6] += 20;  // 060B1536 add #20,r6
L_060B1538:
    c.r[0] = ld32(c.r[4] + 36);  // 060B1538 mov.l @(36,r4),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060B153A tst #1,r0
    { const bool k = c.t; c.t = (c.r[0] & 0x2u) == 0; if (k) { goto L_060B1544; } }  // 060B153C bt/s 0x060B1544 ; tst #2,r0
    c.r[2] = ld32(c.r[4]);  // 060B1540 mov.l @(0,r4),r2
    st32(c.r[6] + 4, c.r[2]);  // 060B1542 mov.l r2,@(4,r6)
L_060B1544:
    { const bool k = c.t; c.t = (c.r[0] & 0x4u) == 0; if (k) { goto L_060B154C; } }  // 060B1544 bt/s 0x060B154C ; tst #4,r0
    c.r[2] = ld32(c.r[4] + 4);  // 060B1548 mov.l @(4,r4),r2
    st32(c.r[6] + 8, c.r[2]);  // 060B154A mov.l r2,@(8,r6)
L_060B154C:
    { const bool k = c.t; c.t = (c.r[0] & 0x8u) == 0; if (k) { goto L_060B1554; } }  // 060B154C bt/s 0x060B1554 ; tst #8,r0
    c.r[2] = ld32(c.r[4] + 8);  // 060B1550 mov.l @(8,r4),r2
    st32(c.r[6] + 12, c.r[2]);  // 060B1552 mov.l r2,@(12,r6)
L_060B1554:
    c.r[3] = ld32(c.r[6] + 16);  // 060B1554 mov.l @(16,r6),r3
    { const bool k = c.t; c.t = (c.r[0] & 0x10u) == 0; if (k) { goto L_060B1566; } }  // 060B1556 bt/s 0x060B1566 ; tst #16,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15B8u);  // 060B155A mov.w 0x060B15B8,r1
    c.r[2] = ld32(c.r[4] + 12);  // 060B155C mov.l @(12,r4),r2
    c.r[3] &= c.r[1];  // 060B155E and r1,r3
    c.r[2] <<= 16;  // 060B1560 shll16 r2
    c.r[2] >>= 2;  // 060B1562 shlr2 r2
    c.r[3] |= c.r[2];  // 060B1564 or r2,r3
L_060B1566:
    { const bool k = c.t; c.t = (c.r[0] & 0x20u) == 0; if (k) { goto L_060B1578; } }  // 060B1566 bt/s 0x060B1578 ; tst #32,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15BAu);  // 060B156A mov.w 0x060B15BA,r1
    c.r[2] = ld32(c.r[4] + 16);  // 060B156C mov.l @(16,r4),r2
    c.r[3] &= c.r[1];  // 060B156E and r1,r3
    c.r[2] <<= 8;  // 060B1570 shll8 r2
    c.r[2] <<= 2;  // 060B1572 shll2 r2
    c.r[2] <<= 2;  // 060B1574 shll2 r2
    c.r[3] |= c.r[2];  // 060B1576 or r2,r3
L_060B1578:
    { const bool k = c.t; c.t = (c.r[0] & 0x40u) == 0; if (k) { goto L_060B1584; } }  // 060B1578 bt/s 0x060B1584 ; tst #64,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15BCu);  // 060B157C mov.w 0x060B15BC,r1
    c.r[2] = ld32(c.r[4] + 20);  // 060B157E mov.l @(20,r4),r2
    c.r[3] &= c.r[1];  // 060B1580 and r1,r3
    c.r[3] |= c.r[2];  // 060B1582 or r2,r3
L_060B1584:
    { const bool k = c.t; c.t = (c.r[0] & 0x80u) == 0; if (k) { goto L_060B1590; } }  // 060B1584 bt/s 0x060B1590 ; tst #128,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15BEu);  // 060B1588 mov.w 0x060B15BE,r1
    c.r[2] = ld32(c.r[4] + 24);  // 060B158A mov.l @(24,r4),r2
    c.r[3] &= c.r[1];  // 060B158C and r1,r3
    c.r[3] |= c.r[2];  // 060B158E or r2,r3
L_060B1590:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15C0u);  // 060B1590 mov.w 0x060B15C0,r1
    { const bool k = c.t; c.t = (c.r[0] & c.r[1]) == 0; if (k) { goto L_060B159E; } }  // 060B1592 bt/s 0x060B159E ; tst r1,r0
    c.r[1] = 0xFFFFFFFBu;  // 060B1596 mov #-5,r1
    c.r[2] = ld32(c.r[4] + 28);  // 060B1598 mov.l @(28,r4),r2
    c.r[3] &= c.r[1];  // 060B159A and r1,r3
    c.r[3] |= c.r[2];  // 060B159C or r2,r3
L_060B159E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15C2u);  // 060B159E mov.w 0x060B15C2,r1
    { const bool k = c.t; c.r[3] &= c.r[1]; if (k) { goto L_060B15A8; } }  // 060B15A0 bt/s 0x060B15A8 ; and r1,r3
    c.r[1] = 0xFFFFFFFDu;  // 060B15A4 mov #-3,r1
    c.r[3] &= c.r[1];  // 060B15A6 and r1,r3
L_060B15A8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B15C4u);  // 060B15A8 mov.w 0x060B15C4,r1
    st32(c.r[6] + 16, c.r[3]);  // 060B15AA mov.l r3,@(16,r6)
    c.t = (c.r[0] & c.r[1]) == 0;  // 060B15AC tst r1,r0
    if (c.t) { goto L_060B15B4; }  // 060B15AE bt 0x060B15B4
    c.r[0] = ld32(c.r[4] + 32);  // 060B15B0 mov.l @(32,r4),r0
    st8(c.r[6] + 2, c.r[0]);  // 060B15B2 mov.b r0,@(2,r6)
L_060B15B4:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B15B4 rts ; nop
}

void f_060B15CC(SH2Context& c) {
    ran[3059] = 1;
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 060B15CC stc.l sr,@-r15
    c.r[0] = 0xFFFFFFF0u;  // 060B15CE mov #-16,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 060B15D0 ldc r0,sr
    c.t = (c.r[4] & c.r[4]) == 0;  // 060B15D2 tst r4,r4
    { const bool k = c.t; c.r[3] = 0xFFFFFF80u; if (k) { goto L_060B1610; } }  // 060B15D4 bt/s 0x060B1610 ; mov #-128,r3
    c.r[3] = 0xFFFFFF90u;  // 060B15D8 mov #-112,r3
L_060B15DA:
    c.r[0] = ld32(c.r[3] + 12);  // 060B15DA mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060B15DC and #3,r0
    c.t = c.r[0] == 0x1u;  // 060B15DE cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060B15DA; }  // 060B15E0 bt 0x060B15DA
    c.r[0] = ld32(c.r[3] + 32);  // 060B15E2 mov.l @(32,r3),r0
    c.r[0] = 0x0u;  // 060B15E4 mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060B15E6 mov.l r0,@(12,r3)
    c.r[2] = 0xFFFFFF9Cu;  // 060B15E8 mov #-100,r2
    c.r[2] <<= 2;  // 060B15EA shll2 r2
    st8(c.r[2] + 2, c.r[0]);  // 060B15EC mov.b r0,@(2,r2)
    c.r[4] = ld32(0x060B1648u);  // 060B15EE mov.l 0x060B1648,r4
    c.r[0] = ld32(c.r[4] + 24);  // 060B15F0 mov.l @(24,r4),r0
    c.r[1] = ld32(c.r[4] + 28);  // 060B15F2 mov.l @(28,r4),r1
    c.r[2] = ld32(c.r[4] + 32);  // 060B15F4 mov.l @(32,r4),r2
    st32(c.r[3], c.r[0]);  // 060B15F6 mov.l r0,@(0,r3)
    st32(c.r[3] + 4, c.r[1]);  // 060B15F8 mov.l r1,@(4,r3)
    st32(c.r[3] + 8, c.r[2]);  // 060B15FA mov.l r2,@(8,r3)
    c.r[1] = ld32(c.r[4] + 36);  // 060B15FC mov.l @(36,r4),r1
    c.r[2] = 0x1u;  // 060B15FE mov #1,r2
    c.r[1] |= c.r[2];  // 060B1600 or r2,r1
    st32(c.r[3] + 12, c.r[1]);  // 060B1602 mov.l r1,@(12,r3)
    c.r[0] = 0x9u;  // 060B1604 mov #9,r0
    st32(c.r[3] + 32, c.r[0]);  // 060B1606 mov.l r0,@(32,r3)
    c.r[0] = 0x10u;  // 060B1608 mov #16,r0
    st8(c.gbr + 186, c.r[0]);  // 060B160A mov.b r0,@(186,gbr)
    { const uint32_t x = c.pr; { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); } c.pc = x; return; }  // 060B160C rts ; ldc.l @r15+,sr
L_060B1610:
    c.r[0] = ld32(c.r[3] + 12);  // 060B1610 mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060B1612 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060B1614 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060B1610; }  // 060B1616 bt 0x060B1610
    c.r[0] = ld32(c.r[3] + 48);  // 060B1618 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060B161A mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060B161C mov.l r0,@(12,r3)
    c.r[2] = 0xFFFFFF9Cu;  // 060B161E mov #-100,r2
    c.r[2] <<= 2;  // 060B1620 shll2 r2
    st8(c.r[2] + 1, c.r[0]);  // 060B1622 mov.b r0,@(1,r2)
    c.r[4] = ld32(0x060B1648u);  // 060B1624 mov.l 0x060B1648,r4
    c.r[0] = ld32(c.r[4] + 4);  // 060B1626 mov.l @(4,r4),r0
    c.r[1] = ld32(c.r[4] + 8);  // 060B1628 mov.l @(8,r4),r1
    c.r[2] = ld32(c.r[4] + 12);  // 060B162A mov.l @(12,r4),r2
    st32(c.r[3], c.r[0]);  // 060B162C mov.l r0,@(0,r3)
    st32(c.r[3] + 4, c.r[1]);  // 060B162E mov.l r1,@(4,r3)
    st32(c.r[3] + 8, c.r[2]);  // 060B1630 mov.l r2,@(8,r3)
    c.r[1] = ld32(c.r[4] + 16);  // 060B1632 mov.l @(16,r4),r1
    c.r[2] = 0x1u;  // 060B1634 mov #1,r2
    c.r[1] |= c.r[2];  // 060B1636 or r2,r1
    st32(c.r[3] + 12, c.r[1]);  // 060B1638 mov.l r1,@(12,r3)
    c.r[0] = 0x9u;  // 060B163A mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060B163C mov.l r0,@(48,r3)
    c.r[0] = 0x10u;  // 060B163E mov #16,r0
    st8(c.gbr + 185, c.r[0]);  // 060B1640 mov.b r0,@(185,gbr)
    { const uint32_t x = c.pr; { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); } c.pc = x; return; }  // 060B1642 rts ; ldc.l @r15+,sr
}

void f_060B164C(SH2Context& c) {
    ran[3060] = 1;
    c.r[3] = 0xFFFFFFB0u;  // 060B164C mov #-80,r3
    c.r[0] = ld32(c.r[3]);  // 060B164E mov.l @r3,r0
    c.r[1] = 0x2u;  // 060B1650 mov #2,r1
    c.r[1] &= c.r[0];  // 060B1652 and r0,r1
    c.r[0] &= 0x4u;  // 060B1654 and #4,r0
    st32(c.r[4] + 4, c.r[1]);  // 060B1656 mov.l r1,@(4,r4)
    { const uint32_t x = c.pr; st32(c.r[4], c.r[1]); c.pc = x; return; }  // 060B1658 rts ; mov.l r1,@(0,r4)
}

void f_060B165C(SH2Context& c) {
    ran[3061] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 060B165C tst r4,r4
    { const bool k = c.t; c.r[3] = 0xFFFFFF8Cu; if (k) { goto L_060B166E; } }  // 060B165E bt/s 0x060B166E ; mov #-116,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 186);  // 060B1662 mov.b @(186,gbr),r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B1664 tst #16,r0
    if (c.t) { goto L_060B167A; }  // 060B1666 bt 0x060B167A
    c.r[0] = ld32(c.r[3] + 16);  // 060B1668 mov.l @(16,r3),r0
    { const uint32_t x = c.pr; c.r[0] &= 0x2u; c.pc = x; return; }  // 060B166A rts ; and #2,r0
L_060B166E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 185);  // 060B166E mov.b @(185,gbr),r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B1670 tst #16,r0
    if (c.t) { goto L_060B167A; }  // 060B1672 bt 0x060B167A
    c.r[0] = ld32(c.r[3]);  // 060B1674 mov.l @r3,r0
    { const uint32_t x = c.pr; c.r[0] &= 0x2u; c.pc = x; return; }  // 060B1676 rts ; and #2,r0
L_060B167A:
    { const uint32_t x = c.pr; c.r[0] = 0x2u; c.pc = x; return; }  // 060B167A rts ; mov #2,r0
}

void f_060B1680(SH2Context& c) {
    ran[3062] = 1;
    c.r[0] = ld32(0x060B1698u);  // 060B1680 mov.l 0x060B1698,r0
    c.r[1] = ld32(0x060B169Cu);  // 060B1682 mov.l 0x060B169C,r1
    c.r[4] &= c.r[0];  // 060B1684 and r0,r4
    c.r[4] |= c.r[1];  // 060B1686 or r1,r4
    c.r[5] += c.r[4];  // 060B1688 add r4,r5
    c.r[0] = 0x0u;  // 060B168A mov #0,r0
L_060B168C:
    st32(c.r[4], c.r[0]);  // 060B168C mov.l r0,@r4
    c.r[4] += 16;  // 060B168E add #16,r4
    c.t = (int32_t)c.r[5] > (int32_t)c.r[4];  // 060B1690 cmp/gt r4,r5
    if (c.t) { SH2_POLL(c); goto L_060B168C; }  // 060B1692 bt 0x060B168C
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1694 rts ; nop
}

void f_060B16A0(SH2Context& c) {
    ran[3063] = 1;
    c.r[6] = ld32(0x060B16E4u);  // 060B16A0 mov.l 0x060B16E4,r6
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B16A2 tst r5,r5
    { const bool k = c.t; c.r[0] = ld32(c.r[4] + 36); if (k) { goto L_060B16B2; } }  // 060B16A4 bt/s 0x060B16B2 ; mov.l @(36,r4),r0
    c.r[6] += 20;  // 060B16A8 add #20,r6
    c.r[5] -= 1;  // 060B16AA add #-1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B16AC tst r5,r5
    if (c.t) { goto L_060B16B2; }  // 060B16AE bt 0x060B16B2
    c.r[6] += 20;  // 060B16B0 add #20,r6
L_060B16B2:
    c.r[1] = ld32(c.r[4] + 8);  // 060B16B2 mov.l @(8,r4),r1
    c.t = (c.r[0] & 0x1u) == 0;  // 060B16B4 tst #1,r0
    { const bool k = c.t; st32(c.r[6] + 8, c.r[1]); if (k) { goto L_060B16BE; } }  // 060B16B6 bt/s 0x060B16BE ; mov.l r1,@(8,r6)
    c.r[2] = ld32(c.r[4]);  // 060B16BA mov.l @(0,r4),r2
    st32(c.r[6], c.r[2]);  // 060B16BC mov.l r2,@(0,r6)
L_060B16BE:
    c.t = (c.r[0] & 0x2u) == 0;  // 060B16BE tst #2,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 12); if (k) { goto L_060B16C8; } }  // 060B16C0 bt/s 0x060B16C8 ; mov.l @(12,r4),r1
    c.r[2] = ld32(c.r[4] + 4);  // 060B16C4 mov.l @(4,r4),r2
    st32(c.r[6] + 4, c.r[2]);  // 060B16C6 mov.l r2,@(4,r6)
L_060B16C8:
    c.r[2] = ld32(c.r[4] + 16);  // 060B16C8 mov.l @(16,r4),r2
    c.r[0] = ld32(c.r[4] + 24);  // 060B16CA mov.l @(24,r4),r0
    c.r[2] |= c.r[1];  // 060B16CC or r1,r2
    st32(c.r[6] + 12, c.r[2]);  // 060B16CE mov.l r2,@(12,r6)
    c.r[1] = ld32(c.r[4] + 28);  // 060B16D0 mov.l @(28,r4),r1
    c.r[2] = ld32(c.r[4] + 20);  // 060B16D2 mov.l @(20,r4),r2
    c.r[0] <<= 16;  // 060B16D4 shll16 r0
    c.r[2] |= c.r[0];  // 060B16D6 or r0,r2
    c.r[0] = ld32(c.r[4] + 32);  // 060B16D8 mov.l @(32,r4),r0
    c.r[1] <<= 8;  // 060B16DA shll8 r1
    c.r[2] |= c.r[1];  // 060B16DC or r1,r2
    c.r[0] |= c.r[2];  // 060B16DE or r2,r0
    { const uint32_t x = c.pr; st32(c.r[6] + 16, c.r[0]); c.pc = x; return; }  // 060B16E0 rts ; mov.l r0,@(16,r6)
}

void f_060B1724(SH2Context& c) {
    ran[3064] = 1;
    c.r[2] = ld32(0x060B1790u);  // 060B1724 mov.l 0x060B1790,r2
    c.r[2] += c.r[4];  // 060B1726 add r4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B1728 mov.b @r2,r0
L_060B172A:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B172A tst #4,r0
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_060B1748; } }  // 060B172C bf/s 0x060B1748 ; mov r4,r1
    c.r[1] <<= 2;  // 060B1730 shll2 r1
    c.r[0] = 0x060B1794u;  // 060B1732 mova 0x060B1794,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060B1734 mov.l @(r0,r1),r1
    c.r[3] = ld32(0x060B17A0u);  // 060B1736 mov.l 0x060B17A0,r3
    c.r[0] = ld32(c.r[3]);  // 060B1738 mov.l @r3,r0
    c.t = (c.r[0] & c.r[1]) == 0;  // 060B173A tst r1,r0
    { const bool k = c.t; c.r[1] = 0x30u; if (k) { goto L_060B1748; } }  // 060B173C bt/s 0x060B1748 ; mov #48,r1
L_060B1740:
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B1740 dt r1
    if (!c.t) { SH2_POLL(c); goto L_060B1740; }  // 060B1742 bf 0x060B1740
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); SH2_POLL(c); goto L_060B172A;  // 060B1744 bra 0x060B172A ; mov.b @r2,r0
L_060B1748:
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 060B1748 stc.l sr,@-r15
    c.r[0] = 0xFFFFFFF0u;  // 060B174A mov #-16,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 060B174C ldc r0,sr
    c.r[6] = ld32(0x060B17A4u);  // 060B174E mov.l 0x060B17A4,r6
    c.r[3] = ld32(0x060B17A8u);  // 060B1750 mov.l 0x060B17A8,r3
    c.t = (c.r[4] & c.r[4]) == 0;  // 060B1752 tst r4,r4
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_060B1766; } }  // 060B1754 bt/s 0x060B1766 ; mov r4,r1
    c.r[6] += 20;  // 060B1758 add #20,r6
    c.r[3] += 32;  // 060B175A add #32,r3
    c.r[1] -= 1;  // 060B175C add #-1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B175E tst r1,r1
    if (c.t) { goto L_060B1766; }  // 060B1760 bt 0x060B1766
    c.r[6] += 20;  // 060B1762 add #20,r6
    c.r[3] += 32;  // 060B1764 add #32,r3
L_060B1766:
    c.r[0] = 0x0u;  // 060B1766 mov #0,r0
    st32(c.r[3] + 16, c.r[0]);  // 060B1768 mov.l r0,@(16,r3)
    c.r[0] = ld32(c.r[6]);  // 060B176A mov.l @(0,r6),r0
    c.r[1] = ld32(c.r[6] + 4);  // 060B176C mov.l @(4,r6),r1
    c.r[2] = ld32(c.r[6] + 8);  // 060B176E mov.l @(8,r6),r2
    st32(c.r[3], c.r[0]);  // 060B1770 mov.l r0,@(0,r3)
    st32(c.r[3] + 4, c.r[1]);  // 060B1772 mov.l r1,@(4,r3)
    st32(c.r[3] + 8, c.r[2]);  // 060B1774 mov.l r2,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B178Cu);  // 060B1776 mov.w 0x060B178C,r0
    c.r[1] = ld32(c.r[6] + 12);  // 060B1778 mov.l @(12,r6),r1
    c.r[2] = ld32(c.r[6] + 16);  // 060B177A mov.l @(16,r6),r2
    st32(c.r[3] + 12, c.r[1]);  // 060B177C mov.l r1,@(12,r3)
    st32(c.r[3] + 20, c.r[2]);  // 060B177E mov.l r2,@(20,r3)
    st32(c.r[3] + 16, c.r[0]);  // 060B1780 mov.l r0,@(16,r3)
    c.r[0] = ld32(0x060B1790u);  // 060B1782 mov.l 0x060B1790,r0
    c.r[1] = 0x10u;  // 060B1784 mov #16,r1
    st8(c.r[0] + c.r[4], c.r[1]);  // 060B1786 mov.b r1,@(r0,r4)
    { const uint32_t x = c.pr; { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); } c.pc = x; return; }  // 060B1788 rts ; ldc.l @r15+,sr
}

void f_060B17AC(SH2Context& c) {
    ran[3065] = 1;
    c.r[1] = c.r[5] & 0xFFu;  // 060B17AC extu.b r5,r1
    c.r[1] -= 69;  // 060B17AE add #-69,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060B17B0 extu.b r1,r1
    c.r[0] = c.gbr;  // 060B17B2 stc gbr,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060B17B4 mov.b @(r0,r1),r0
    c.t = (c.r[0] & 0x4u) == 0;  // 060B17B6 tst #4,r0
    { const bool k = !c.t; c.r[0] = c.t; if (k) { goto L_060B17CA; } }  // 060B17B8 bf/s 0x060B17CA ; movt r0
    c.r[3] = ld32(0x060B17D0u);  // 060B17BC mov.l 0x060B17D0,r3
    c.r[0] = 0x060B17D4u;  // 060B17BE mova 0x060B17D4,r0
    c.r[5] <<= 2;  // 060B17C0 shll2 r5
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 060B17C2 mov.l @(r0,r5),r1
    c.r[0] = ld32(c.r[3]);  // 060B17C4 mov.l @r3,r0
    c.t = (c.r[0] & c.r[1]) == 0;  // 060B17C6 tst r1,r0
    c.r[0] = c.t;  // 060B17C8 movt r0
L_060B17CA:
    { const uint32_t x = c.pr; st32(c.r[4], c.r[0]); c.pc = x; return; }  // 060B17CA rts ; mov.l r0,@r4
}

void f_060B17E0(SH2Context& c) {
    ran[3066] = 1;
    c.r[1] = 0xFFFFFF80u;  // 060B17E0 mov #-128,r1
    c.r[0] = ld32(c.r[1] + 12);  // 060B17E2 mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060B17E4 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060B17E6 cmp/eq #1,r0
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060B17E8 rts ; movt r0
}

void f_060B17EC(SH2Context& c) {
    ran[3067] = 1;
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B180Au);  // 060B17EC mov.w 0x060B180A,r1
    c.r[0] = sh2_get_sr(c);  // 060B17EE stc sr,r0
    c.r[0] &= c.r[1];  // 060B17F0 and r1,r0
    c.r[1] = 0xFu;  // 060B17F2 mov #15,r1
    c.r[1] &= c.r[4];  // 060B17F4 and r4,r1
    c.r[1] <<= 2;  // 060B17F6 shll2 r1
    c.r[1] <<= 2;  // 060B17F8 shll2 r1
    c.r[0] |= c.r[1];  // 060B17FA or r1,r0
    { const uint32_t x = c.pr; sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c); c.pc = x; return; }  // 060B17FC rts ; ldc r0,sr
}

void f_060B180C(SH2Context& c) {
    ran[3068] = 1;
    goto L_060B180C;
L_060AD3B8:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD3B8 sts.l pr,@-r15
L_060AD3BA:
    c.pr = 0x060AD3BEu; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD3BEu) return;  // 060AD3BA bsr 0x060AC974 ; nop
L_060AD3BE:
    c.t = c.r[0] == 0x0u;  // 060AD3BE cmp/eq #0,r0
L_060AD3C0:
    if (!c.t) { goto L_060AD3FC; }  // 060AD3C0 bf 0x060AD3FC
L_060AD3C2:
    c.r[1] = 0x11u;  // 060AD3C2 mov #17,r1
L_060AD3C4:
    c.t = c.r[4] >= c.r[1];  // 060AD3C4 cmp/hs r1,r4
L_060AD3C6:
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD3F8; } }  // 060AD3C6 bt/s 0x060AD3F8 ; mov #-1,r0
L_060AD3CA:
    c.r[2] = ld32(0x060AD420u);  // 060AD3CA mov.l 0x060AD420,r2
L_060AD3CC:
    c.pr = 0x060AD3D0u; st8(c.r[2], c.r[4]); SH2_POLL(c); sh2_call(c, 0x060ACB2Cu); if (c.pc != 0x060AD3D0u) return;  // 060AD3CC bsr 0x060ACB2C ; mov.b r4,@r2
L_060AD3D0:
    c.r[4] = c.r[0];  // 060AD3D0 mov r0,r4
L_060AD3D2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 3);  // 060AD3D2 mov.b @(3,r4),r0
L_060AD3D4:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AD3D4 tst #1,r0
L_060AD3D6:
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD3F8; } }  // 060AD3D6 bt/s 0x060AD3F8 ; mov #-1,r0
L_060AD3DA:
    c.r[3] = ld32(0x060AD424u);  // 060AD3DA mov.l 0x060AD424,r3
L_060AD3DC:
    c.r[2] = 0xFFFFFFE0u;  // 060AD3DC mov #-32,r2
L_060AD3DE:
    c.r[1] = ld32(c.r[2]);  // 060AD3DE mov.l @r2,r1
L_060AD3E0:
    c.t = (c.r[1] & c.r[3]) == 0;  // 060AD3E0 tst r3,r1
L_060AD3E2:
    if (c.t) { goto L_060AD3EC; }  // 060AD3E2 bt 0x060AD3EC
L_060AD3E4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 3);  // 060AD3E4 mov.b @(3,r4),r0
L_060AD3E6:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AD3E6 tst #2,r0
L_060AD3E8:
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD3F8; } }  // 060AD3E8 bt/s 0x060AD3F8 ; mov #-1,r0
L_060AD3EC:
    c.r[0] = 0x060AD404u;  // 060AD3EC mova 0x060AD404,r0
L_060AD3EE:
    c.r[2] = c.r[0];  // 060AD3EE mov r0,r2
L_060AD3F0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 1);  // 060AD3F0 mov.b @(1,r4),r0
L_060AD3F2:
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 060AD3F2 mov.l @(r0,r2),r1
L_060AD3F4:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD3F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD3F8u) return; }  // 060AD3F4 jsr @r1 ; nop
L_060AD3F8:
    c.pr = 0x060AD3FCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD3FCu) return;  // 060AD3F8 bsr 0x060AC97E ; mov r0,r4
L_060AD3FC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD3FC lds.l @r15+,pr
L_060AD3FE:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD3FE rts ; nop
L_060B180C:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B180C sts.l pr,@-r15
L_060B180E:
    c.r[2] = ld32(0x060B1868u);  // 060B180E mov.l 0x060B1868,r2
L_060B1810:
    c.r[0] = 0x060B1880u;  // 060B1810 mova 0x060B1880,r0
L_060B1812:
    c.r[1] = 0x0u;  // 060B1812 mov #0,r1
L_060B1814:
    st32(c.r[0], c.r[1]);  // 060B1814 mov.l r1,@r0
L_060B1816:
    c.r[5] = 0x1u;  // 060B1816 mov #1,r5
L_060B1818:
    { const uint32_t x = c.r[2]; c.pr = 0x060B181Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B181Cu) return; }  // 060B1818 jsr @r2 ; mov #2,r4
L_060B181C:
    c.r[1] = ld32(0x060B186Cu);  // 060B181C mov.l 0x060B186C,r1
L_060B181E:
    c.r[0] = 0x060B182Cu;  // 060B181E mova 0x060B182C,r0
L_060B1820:
    st32(c.r[1], c.r[0]);  // 060B1820 mov.l r0,@r1
L_060B1822:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1822 lds.l @r15+,pr
L_060B1824:
    c.r[2] = ld32(0x060B1868u);  // 060B1824 mov.l 0x060B1868,r2
L_060B1826:
    c.r[5] = 0x0u;  // 060B1826 mov #0,r5
L_060B1828:
    { const uint32_t x = c.r[2]; c.r[4] = 0x1u; SH2_POLL(c); switch (x) { case 0x060AD3B8u: goto L_060AD3B8; case 0x060AD3BAu: goto L_060AD3BA; case 0x060AD3BEu: goto L_060AD3BE; case 0x060AD3C0u: goto L_060AD3C0; case 0x060AD3C2u: goto L_060AD3C2; case 0x060AD3C4u: goto L_060AD3C4; case 0x060AD3C6u: goto L_060AD3C6; case 0x060AD3CAu: goto L_060AD3CA; case 0x060AD3CCu: goto L_060AD3CC; case 0x060AD3D0u: goto L_060AD3D0; case 0x060AD3D2u: goto L_060AD3D2; case 0x060AD3D4u: goto L_060AD3D4; case 0x060AD3D6u: goto L_060AD3D6; case 0x060AD3DAu: goto L_060AD3DA; case 0x060AD3DCu: goto L_060AD3DC; case 0x060AD3DEu: goto L_060AD3DE; case 0x060AD3E0u: goto L_060AD3E0; case 0x060AD3E2u: goto L_060AD3E2; case 0x060AD3E4u: goto L_060AD3E4; case 0x060AD3E6u: goto L_060AD3E6; case 0x060AD3E8u: goto L_060AD3E8; case 0x060AD3ECu: goto L_060AD3EC; case 0x060AD3EEu: goto L_060AD3EE; case 0x060AD3F0u: goto L_060AD3F0; case 0x060AD3F2u: goto L_060AD3F2; case 0x060AD3F4u: goto L_060AD3F4; case 0x060AD3F8u: goto L_060AD3F8; case 0x060AD3FCu: goto L_060AD3FC; case 0x060AD3FEu: goto L_060AD3FE; case 0x060B180Cu: goto L_060B180C; case 0x060B180Eu: goto L_060B180E; case 0x060B1810u: goto L_060B1810; case 0x060B1812u: goto L_060B1812; case 0x060B1814u: goto L_060B1814; case 0x060B1816u: goto L_060B1816; case 0x060B1818u: goto L_060B1818; case 0x060B181Cu: goto L_060B181C; case 0x060B181Eu: goto L_060B181E; case 0x060B1820u: goto L_060B1820; case 0x060B1822u: goto L_060B1822; case 0x060B1824u: goto L_060B1824; case 0x060B1826u: goto L_060B1826; case 0x060B1828u: goto L_060B1828; default: sh2_call(c, x); return; } }  // 060B1828 jmp @r2 ; mov #1,r4
}

void f_060B182C(SH2Context& c) {
    ran[3069] = 1;
    c.r[0] = 0xFFFFFFF0u;  // 060B182C mov #-16,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 060B182E ldc r0,sr
    c.r[2] = ld32(0x060B1874u);  // 060B1830 mov.l 0x060B1874,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B1862u);  // 060B1832 mov.w 0x060B1862,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x060B1864u);  // 060B1834 mov.w 0x060B1864,r8
    c.r[3] = ld32(0x060B1878u);  // 060B1836 mov.l 0x060B1878,r3
    c.r[0] = 0x0u;  // 060B1838 mov #0,r0
    st16(c.r[1], c.r[0]);  // 060B183A mov.w r0,@r1
    st16(c.r[8], c.r[0]);  // 060B183C mov.w r0,@r8
    c.r[8] -= 80;  // 060B183E add #-80,r8
    c.r[0] = 0x1u;  // 060B1840 mov #1,r0
    st8(c.r[8], c.r[0]);  // 060B1842 mov.b r0,@r8
    { const uint32_t x = c.r[3]; c.pr = 0x060B1848u; c.r[15] = ld32(c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B1848u) return; }  // 060B1844 jsr @r3 ; mov.l @r2,r15
L_060B1848:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8] + 1);  // 060B1848 mov.b @(1,r8),r0
    c.t = (c.r[0] & 0x80u) == 0;  // 060B184A tst #128,r0
    if (c.t) { goto L_060B185E; }  // 060B184C bt 0x060B185E
    c.r[2] = ld32(0x060B1870u);  // 060B184E mov.l 0x060B1870,r2
    c.r[0] = 0x0u;  // 060B1850 mov #0,r0
    c.r[1] = ld32(c.r[2]);  // 060B1852 mov.l @r2,r1
    st8(c.r[8] + 1, c.r[0]);  // 060B1854 mov.b r0,@(1,r8)
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B1856 tst r1,r1
    if (c.t) { goto L_060B185E; }  // 060B1858 bt 0x060B185E
    { const uint32_t x = c.r[1]; c.pr = 0x060B185Eu; st32(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B185Eu) return; }  // 060B185A jsr @r1 ; mov.l r0,@r2
L_060B185E:
    SH2_POLL(c); goto L_060B1848;  // 060B185E bra 0x060B1848 ; nop
}

void f_060B1888(SH2Context& c) {
    ran[3070] = 1;
    c.r[0] = ld32(0x060B18E0u);  // 060B1888 mov.l 0x060B18E0,r0
    c.r[1] = ld32(0x060B18DCu);  // 060B188A mov.l 0x060B18DC,r1
    c.r[2] = ld32(0x060B18E4u);  // 060B188C mov.l 0x060B18E4,r2
    c.r[0] = ld32(c.r[0]);  // 060B188E mov.l @r0,r0
    c.gbr = c.r[1];  // 060B1890 ldc r1,gbr
    c.r[0] |= c.r[2];  // 060B1892 or r2,r0
    st32(c.gbr + 68, c.r[0]);  // 060B1894 mov.l r0,@(68,gbr)
L_060B1896:
    c.r[2] = ld32(0x060B18E8u);  // 060B1896 mov.l 0x060B18E8,r2
    c.r[4] = c.r[0];  // 060B1898 mov r0,r4
    c.r[1] = ld32(c.r[2]);  // 060B189A mov.l @r2,r1
L_060B189C:
    c.t = c.r[1] == c.r[4];  // 060B189C cmp/eq r4,r1
    if (c.t) { goto L_060B18C8; }  // 060B189E bt 0x060B18C8
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060B18A0 mov.l @r4+,r0
    c.r[1] = 0x7Cu;  // 060B18A2 mov #124,r1
    c.r[1] &= c.r[0];  // 060B18A4 and r0,r1
    c.r[0] = 0x060B18ECu;  // 060B18A6 mova 0x060B18EC,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060B18A8 mov.l @(r0,r1),r1
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060B18AA mov.l @r4+,r0
    { const uint32_t x = c.r[1]; c.pr = 0x060B18B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B18B0u) return; }  // 060B18AC jsr @r1 ; nop
    c.r[2] = ld32(0x060B18E8u);  // 060B18B0 mov.l 0x060B18E8,r2
    c.r[0] = c.r[4];  // 060B18B2 mov r4,r0
    c.r[1] = ld32(c.r[2]);  // 060B18B4 mov.l @r2,r1
    st32(c.gbr + 68, c.r[0]);  // 060B18B6 mov.l r0,@(68,gbr)
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[4];  // 060B18B8 cmp/ge r4,r1
    if (c.t) { SH2_POLL(c); goto L_060B189C; }  // 060B18BA bt 0x060B189C
    c.r[0] = ld32(0x060B18E0u);  // 060B18BC mov.l 0x060B18E0,r0
    c.r[1] = ld32(0x060B18E4u);  // 060B18BE mov.l 0x060B18E4,r1
    c.r[0] = ld32(c.r[0]);  // 060B18C0 mov.l @r0,r0
    c.r[0] |= c.r[1];  // 060B18C2 or r1,r0
    st32(c.gbr + 68, c.r[0]); SH2_POLL(c); goto L_060B1896;  // 060B18C4 bra 0x060B1896 ; mov.l r0,@(68,gbr)
L_060B18C8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B18D8u);  // 060B18C8 mov.w 0x060B18D8,r1
L_060B18CA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060B18CA mov.b @r1,r0
    c.t = (c.r[0] & 0x80u) == 0;  // 060B18CC tst #128,r0
    if (c.t) { SH2_POLL(c); goto L_060B18CA; }  // 060B18CE bt 0x060B18CA
    c.r[0] = 0x0u;  // 060B18D0 mov #0,r0
    st8(c.r[1], c.r[0]);  // 060B18D2 mov.b r0,@r1
    c.r[0] = ld32(c.gbr + 68); SH2_POLL(c); goto L_060B1896;  // 060B18D4 bra 0x060B1896 ; mov.l @(68,gbr),r0
}

void f_060B1938(SH2Context& c) {
    ran[3071] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060B1938 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060B193A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060B193C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060B193E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060B1940 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B1942 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060B1944 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1946 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1948 sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060B194Eu; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B194Eu) return; }  // 060B194A jsr @r0 ; mov.l @r4,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B194E lds.l @r15+,pr
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1950 mov.l @r15+,r4
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B1952 mov.l @r15+,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B1954 mov.l @r15+,r9
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B1956 mov.l @r15+,r10
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B1958 mov.l @r15+,r11
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B195A mov.l @r15+,r12
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B195C mov.l @r15+,r13
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B195E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[4] += 4; c.pc = x; return; }  // 060B1960 rts ; add #4,r4
}

void f_060B1964(SH2Context& c) {
    ran[3072] = 1;
    c.r[0] = 0x0u;  // 060B1964 mov #0,r0
    c.r[1] = 0x40u;  // 060B1966 mov #64,r1
L_060B1968:
    st32(c.r[2], c.r[0]);  // 060B1968 mov.l r0,@r2
    st32(c.r[2] + 4, c.r[0]);  // 060B196A mov.l r0,@(4,r2)
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B196C dt r1
    { const bool k = !c.t; c.r[2] += 8; if (k) { SH2_POLL(c); goto L_060B1968; } }  // 060B196E bf/s 0x060B1968 ; add #8,r2
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1972 rts ; nop
}

void f_060B1976(SH2Context& c) {
    ran[3073] = 1;
    c.r[5] = c.r[0];  // 060B1976 mov r0,r5
    c.r[2] = 0x4u;  // 060B1978 mov #4,r2
    c.r[2] <<= 8;  // 060B197A shll8 r2
    c.r[3] = 0x20u;  // 060B197C mov #32,r3
    c.r[7] = 0x1Fu;  // 060B197E mov #31,r7
    c.r[0] = 0x10u;  // 060B1980 mov #16,r0
L_060B1982:
    c.r[0] -= c.r[3];  // 060B1982 sub r3,r0
    c.r[1] = 0x20u;  // 060B1984 mov #32,r1
L_060B1986:
    c.r[6] = 0x0u;  // 060B1986 mov #0,r6
    c.t = (int32_t)c.r[0] > 0;  // 060B1988 cmp/pl r0
    if (!c.t) { goto L_060B1994; }  // 060B198A bf 0x060B1994
    c.r[6] = c.r[0];  // 060B198C mov r0,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[7];  // 060B198E cmp/gt r7,r6
    if (!c.t) { goto L_060B1994; }  // 060B1990 bf 0x060B1994
    c.r[6] = c.r[7];  // 060B1992 mov r7,r6
L_060B1994:
    st8(c.r[5], c.r[6]);  // 060B1994 mov.b r6,@r5
    c.r[5] += c.r[2];  // 060B1996 add r2,r5
    st8(c.r[5], c.r[6]);  // 060B1998 mov.b r6,@r5
    c.r[5] += c.r[2];  // 060B199A add r2,r5
    st8(c.r[5], c.r[6]);  // 060B199C mov.b r6,@r5
    c.r[5] -= c.r[2];  // 060B199E sub r2,r5
    c.r[5] -= c.r[2];  // 060B19A0 sub r2,r5
    c.r[0] += 1;  // 060B19A2 add #1,r0
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B19A4 dt r1
    { const bool k = !c.t; c.r[5] += 1; if (k) { SH2_POLL(c); goto L_060B1986; } }  // 060B19A6 bf/s 0x060B1986 ; add #1,r5
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060B19AA dt r3
    { const bool k = !c.t; c.r[0] = 0x10u; if (k) { SH2_POLL(c); goto L_060B1982; } }  // 060B19AC bf/s 0x060B1982 ; mov #16,r0
    c.r[3] = ld32(0x060B1B00u);  // 060B19B0 mov.l 0x060B1B00,r3
    c.r[0] = 0x0u;  // 060B19B2 mov #0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x060B1B14u);  // 060B19B4 mov.w 0x060B1B14,r2
    c.r[1] = 0x20u;  // 060B19B6 mov #32,r1
L_060B19B8:
    st16(c.r[3], c.r[0]);  // 060B19B8 mov.w r0,@(0,r3)
    st16(c.r[3] + 2, c.r[0]);  // 060B19BA mov.w r0,@(2,r3)
    st16(c.r[3] + 4, c.r[0]);  // 060B19BC mov.w r0,@(4,r3)
    st16(c.r[3] + 6, c.r[0]);  // 060B19BE mov.w r0,@(6,r3)
    c.r[0] += c.r[2];  // 060B19C0 add r2,r0
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B19C2 dt r1
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_060B19B8; } }  // 060B19C4 bf/s 0x060B19B8 ; add #8,r3
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B19C8 rts ; nop
}

void f_060B19CC(SH2Context& c) {
    ran[3074] = 1;
    st8(c.gbr + 173, c.r[0]);  // 060B19CC mov.b r0,@(173,gbr)
    c.r[1] = c.r[0];  // 060B19CE mov r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B19D0 mov.b @(169,gbr),r0
    c.r[3] = ld32(0x060B1C00u);  // 060B19D2 mov.l 0x060B1C00,r3
    c.r[0] &= 0x3u;  // 060B19D4 and #3,r0
    c.r[0] <<= 2;  // 060B19D6 shll2 r0
    c.r[0] += 31;  // 060B19D8 add #31,r0
    c.r[3] += c.r[0];  // 060B19DA add r0,r3
    { const uint32_t x = c.pr; st8(c.r[3], c.r[1]); c.pc = x; return; }  // 060B19DC rts ; mov.b r1,@r3
}

void f_060B19E0(SH2Context& c) {
    ran[3075] = 1;
    st32(c.gbr + 108, c.r[0]);  // 060B19E0 mov.l r0,@(108,gbr)
    c.r[1] = c.r[0];  // 060B19E2 mov r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B19E4 mov.b @(169,gbr),r0
    c.r[3] = ld32(0x060B1C00u);  // 060B19E6 mov.l 0x060B1C00,r3
    c.r[0] &= 0x3u;  // 060B19E8 and #3,r0
    c.r[0] <<= 2;  // 060B19EA shll2 r0
    c.r[0] += 36;  // 060B19EC add #36,r0
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[3], c.r[1]); c.pc = x; return; }  // 060B19EE rts ; mov.l r1,@(r0,r3)
}

void f_060B19F2(SH2Context& c) {
    ran[3076] = 1;
    st32(c.gbr + 88, c.r[0]);  // 060B19F2 mov.l r0,@(88,gbr)
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060B19F4 mov.l @r4+,r0
    st32(c.gbr + 92, c.r[0]);  // 060B19F6 mov.l r0,@(92,gbr)
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060B19F8 mov.l @r4+,r0
    { const uint32_t x = c.pr; st32(c.gbr + 96, c.r[0]); c.pc = x; return; }  // 060B19FA rts ; mov.l r0,@(96,gbr)
}

void f_060B19FE(SH2Context& c) {
    ran[3077] = 1;
    { const uint32_t x = c.pr; st32(c.gbr + 892, c.r[0]); c.pc = x; return; }  // 060B19FE rts ; mov.l r0,@(892,gbr)
}

void f_060B1A02(SH2Context& c) {
    ran[3078] = 1;
    { const uint32_t x = c.pr; st32(c.gbr + 900, c.r[0]); c.pc = x; return; }  // 060B1A02 rts ; mov.l r0,@(900,gbr)
}

void f_060B1A06(SH2Context& c) {
    ran[3079] = 1;
    { const uint32_t x = c.pr; st32(c.gbr + 908, c.r[0]); c.pc = x; return; }  // 060B1A06 rts ; mov.l r0,@(908,gbr)
}

void f_060B1A0A(SH2Context& c) {
    ran[3080] = 1;
    c.r[2] = ld32(0x060B1AF4u);  // 060B1A0A mov.l 0x060B1AF4,r2
    c.r[0] &= 0x7Cu;  // 060B1A0C and #124,r0
    c.r[0] += c.r[2];  // 060B1A0E add r2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0]); c.r[0] += 2;  // 060B1A10 mov.w @r0+,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0]);  // 060B1A12 mov.w @r0,r3
    c.r[5] = ld32(0x060B1AF8u);  // 060B1A14 mov.l 0x060B1AF8,r5
    c.r[7] = ld32(0x060B1B08u);  // 060B1A16 mov.l 0x060B1B08,r7
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060B1A18 swap.w r3,r0
    c.r[0] = c.r[2] << 16 | c.r[0] >> 16;  // 060B1A1A xtrct r2,r0
    st32(c.r[5] + 12, c.r[0]);  // 060B1A1C mov.l r0,@(12,r5)
    st32(c.r[5] + 16, c.r[0]);  // 060B1A1E mov.l r0,@(16,r5)
    st32(c.gbr + 148, c.r[0]);  // 060B1A20 mov.l r0,@(148,gbr)
    c.r[0] += c.r[0];  // 060B1A22 add r0,r0
    st32(c.gbr + 816, c.r[0]);  // 060B1A24 mov.l r0,@(816,gbr)
    c.r[0] = 0u - c.r[2];  // 060B1A26 neg r2,r0
    c.r[1] = 0u - c.r[3];  // 060B1A28 neg r3,r1
    c.r[1] <<= 16;  // 060B1A2A shll16 r1
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B1A2C xtrct r0,r1
    st32(c.r[7] + 12, c.r[1]);  // 060B1A2E mov.l r1,@(12,r7)
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060B1A30 swap.w r2,r0
    st32(c.gbr + 108, c.r[0]);  // 060B1A32 mov.l r0,@(108,gbr)
    c.r[0] = 0xAu;  // 060B1A34 mov #10,r0
    st16(c.r[5] + 4, c.r[0]);  // 060B1A36 mov.w r0,@(4,r5)
    c.r[0] = ld32(0x060B1B0Cu);  // 060B1A38 mov.l 0x060B1B0C,r0
    st32(c.r[5], c.r[0]);  // 060B1A3A mov.l r0,@(0,r5)
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B1AEEu);  // 060B1A3C mov.w 0x060B1AEE,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B1AF0u);  // 060B1A3E mov.w 0x060B1AF0,r0
    c.r[5] += c.r[2];  // 060B1A40 add r2,r5
    c.r[0] += c.r[3];  // 060B1A42 add r3,r0
    c.r[0] <<= 16;  // 060B1A44 shll16 r0
    c.r[0] = c.r[5] << 16 | c.r[0] >> 16;  // 060B1A46 xtrct r5,r0
    st32(c.gbr + 156, c.r[0]);  // 060B1A48 mov.l r0,@(156,gbr)
    c.r[5] = ld32(0x060B1C00u);  // 060B1A4A mov.l 0x060B1C00,r5
    c.r[2] += c.r[2];  // 060B1A4C add r2,r2
    c.r[3] += c.r[3];  // 060B1A4E add r3,r3
    c.r[2] -= 1;  // 060B1A50 add #-1,r2
    c.r[3] -= 1;  // 060B1A52 add #-1,r3
    c.r[3] <<= 16;  // 060B1A54 shll16 r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B1A56 xtrct r2,r3
    st32(c.r[5] + 20, c.r[3]);  // 060B1A58 mov.l r3,@(20,r5)
    st32(c.r[5] + 24, c.r[3]);  // 060B1A5A mov.l r3,@(24,r5)
    st32(c.r[7] + 16, c.r[3]);  // 060B1A5C mov.l r3,@(16,r7)
    c.r[0] = 0x1u;  // 060B1A5E mov #1,r0
    st8(c.gbr + 173, c.r[0]);  // 060B1A60 mov.b r0,@(173,gbr)
    c.r[1] = c.r[5];  // 060B1A62 mov r5,r1
    c.r[1] += 31;  // 060B1A64 add #31,r1
    st8(c.r[1], c.r[0]);  // 060B1A66 mov.b r0,@(0,r1)
    st8(c.r[1] + 4, c.r[0]);  // 060B1A68 mov.b r0,@(4,r1)
    c.r[0] = 0x8u;  // 060B1A6A mov #8,r0
    st16(c.r[5] + 4, c.r[0]);  // 060B1A6C mov.w r0,@(4,r5)
    c.r[0] = ld32(0x060B1B10u);  // 060B1A6E mov.l 0x060B1B10,r0
    st32(c.r[5], c.r[0]);  // 060B1A70 mov.l r0,@(0,r5)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B1AECu);  // 060B1A72 mov.w 0x060B1AEC,r0
    c.r[1] = c.r[5];  // 060B1A74 mov r5,r1
    st16(c.gbr + 160, c.r[0]);  // 060B1A76 mov.w r0,@(160,gbr)
    c.r[1] += 28;  // 060B1A78 add #28,r1
    st16(c.r[1], c.r[0]);  // 060B1A7A mov.w r0,@r1
    st16(c.r[1] + 4, c.r[0]);  // 060B1A7C mov.w r0,@(4,r1)
    c.r[0] = ld32(c.gbr + 108);  // 060B1A7E mov.l @(108,gbr),r0
    st32(c.r[5] + 36, c.r[0]);  // 060B1A80 mov.l r0,@(36,r5)
    st32(c.r[5] + 40, c.r[0]);  // 060B1A82 mov.l r0,@(40,r5)
    c.r[0] = 0x0u;  // 060B1A84 mov #0,r0
    st32(c.r[5] + 12, c.r[0]);  // 060B1A86 mov.l r0,@(12,r5)
    st32(c.r[5] + 16, c.r[0]);  // 060B1A88 mov.l r0,@(16,r5)
    st8(c.gbr + 169, c.r[0]);  // 060B1A8A mov.b r0,@(169,gbr)
    st32(c.gbr + 900, c.r[0]);  // 060B1A8C mov.l r0,@(900,gbr)
    st32(c.gbr + 908, c.r[0]);  // 060B1A8E mov.l r0,@(908,gbr)
    c.r[0] = 0x1u;  // 060B1A90 mov #1,r0
    st32(c.gbr + 892, c.r[0]);  // 060B1A92 mov.l r0,@(892,gbr)
    c.r[0] = ld32(0x060B1C40u);  // 060B1A94 mov.l 0x060B1C40,r0
    c.r[2] = ld32(0x060B1C04u);  // 060B1A96 mov.l 0x060B1C04,r2
    c.r[0] = ld32(c.r[0]);  // 060B1A98 mov.l @r0,r0
    st32(c.gbr + 52, c.r[0]);  // 060B1A9A mov.l r0,@(52,gbr)
    c.r[0] = ld32(c.r[2]);  // 060B1A9C mov.l @r2,r0
    st32(c.gbr + 40, c.r[0]);  // 060B1A9E mov.l r0,@(40,gbr)
    c.r[0] = 0x0u;  // 060B1AA0 mov #0,r0
    st32(c.gbr + 88, c.r[0]);  // 060B1AA2 mov.l r0,@(88,gbr)
    st32(c.gbr + 92, c.r[0]);  // 060B1AA4 mov.l r0,@(92,gbr)
    st32(c.gbr + 64, c.r[0]);  // 060B1AA6 mov.l r0,@(64,gbr)
    c.r[0] = 0xFFFFFFFFu;  // 060B1AA8 mov #-1,r0
    c.r[0] <<= 16;  // 060B1AAA shll16 r0
    st32(c.gbr + 96, c.r[0]);  // 060B1AAC mov.l r0,@(96,gbr)
    c.r[0] = ld32(0x060B1C38u);  // 060B1AAE mov.l 0x060B1C38,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1AB0 sts.l pr,@-r15
    c.r[0] = ld32(c.r[0]);  // 060B1AB2 mov.l @r0,r0
    c.pr = 0x060B1AB8u; c.r[2] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060B1964u); if (c.pc != 0x060B1AB8u) return;  // 060B1AB4 bsr 0x060B1964 ; mov r0,r2
    c.r[0] = c.r[2];  // 060B1AB8 mov r2,r0
    c.pr = 0x060B1ABEu; st32(c.gbr + 56, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1964u); if (c.pc != 0x060B1ABEu) return;  // 060B1ABA bsr 0x060B1964 ; mov.l r0,@(56,gbr)
    c.pr = 0x060B1AC2u; SH2_POLL(c); sh2_call(c, 0x060B1964u); if (c.pc != 0x060B1AC2u) return;  // 060B1ABE bsr 0x060B1964 ; nop
    c.pr = 0x060B1AC6u; SH2_POLL(c); sh2_call(c, 0x060B1964u); if (c.pc != 0x060B1AC6u) return;  // 060B1AC2 bsr 0x060B1964 ; nop
    c.r[0] = ld32(0x060B1AFCu);  // 060B1AC6 mov.l 0x060B1AFC,r0
    c.r[0] = ld32(c.r[0]);  // 060B1AC8 mov.l @r0,r0
    c.pr = 0x060B1ACEu; st32(c.gbr + 100, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1976u); if (c.pc != 0x060B1ACEu) return;  // 060B1ACA bsr 0x060B1976 ; mov.l r0,@(100,gbr)
    c.r[3] = ld32(0x060B1C3Cu);  // 060B1ACE mov.l 0x060B1C3C,r3
    c.r[1] = ld32(0x060B1B04u);  // 060B1AD0 mov.l 0x060B1B04,r1
    c.r[3] = ld32(c.r[3]);  // 060B1AD2 mov.l @r3,r3
    c.r[1] = ld32(c.r[1]);  // 060B1AD4 mov.l @r1,r1
    c.r[0] = ld32(0x060B1C08u);  // 060B1AD6 mov.l 0x060B1C08,r0
    c.r[1] += c.r[3];  // 060B1AD8 add r3,r1
    c.r[2] = 0x1Eu;  // 060B1ADA mov #30,r2
L_060B1ADC:
    st32(c.r[3] + 4, c.r[0]);  // 060B1ADC mov.l r0,@(4,r3)
    st32(c.r[3], c.r[2]);  // 060B1ADE mov.l r2,@(0,r3)
    c.r[3] += 12;  // 060B1AE0 add #12,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060B1AE2 cmp/ge r1,r3
    { const bool k = !c.t; c.r[0] += 32; if (k) { SH2_POLL(c); goto L_060B1ADC; } }  // 060B1AE4 bf/s 0x060B1ADC ; add #32,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060B1C18;  // 060B1AE8 bra 0x060B1C18 ; lds.l @r15+,pr
L_060B1C18:
    c.r[1] = 0xFFFFFFA4u;  // 060B1C18 mov #-92,r1
    c.r[1] <<= 2;  // 060B1C1A shll2 r1
    c.r[0] = 0x11u;  // 060B1C1C mov #17,r0
    st8(c.r[1] + 2, c.r[0]);  // 060B1C1E mov.b r0,@(2,r1)
    ;  // 060B1C20 nop
    ;  // 060B1C22 nop
    ;  // 060B1C24 nop
    ;  // 060B1C26 nop
    ;  // 060B1C28 nop
    ;  // 060B1C2A nop
    ;  // 060B1C2C nop
    ;  // 060B1C2E nop
    ;  // 060B1C30 nop
    ;  // 060B1C32 nop
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1C34 rts ; nop
}

void f_060B1B16(SH2Context& c) {
    ran[3081] = 1;
    st16(c.gbr + 160, c.r[0]);  // 060B1B16 mov.w r0,@(160,gbr)
    c.r[3] = ld32(0x060B1C00u);  // 060B1B18 mov.l 0x060B1C00,r3
    c.r[1] = c.r[0];  // 060B1B1A mov r0,r1
    c.r[0] = c.r[0] << 16 | c.r[0] >> 16;  // 060B1B1C swap.w r0,r0
    st8(c.gbr + 169, c.r[0]);  // 060B1B1E mov.b r0,@(169,gbr)
    c.r[0] &= 0x1u;  // 060B1B20 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B1B22 tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[0]; if (k) { goto L_060B1B32; } }  // 060B1B24 bt/s 0x060B1B32 ; mov r0,r5
    c.r[0] <<= 2;  // 060B1B28 shll2 r0
    c.r[2] = ld32(0x060B1C38u);  // 060B1B2A mov.l 0x060B1C38,r2
    c.r[3] += c.r[0];  // 060B1B2C add r0,r3
    c.r[0] = ld32(c.r[2]);  // 060B1B2E mov.l @r2,r0
    st32(c.gbr + 56, c.r[0]);  // 060B1B30 mov.l r0,@(56,gbr)
L_060B1B32:
    c.r[6] = ld32(c.r[4]); c.r[4] += 4;  // 060B1B32 mov.l @r4+,r6
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060B1B34 mov.l @r4+,r0
    st32(c.r[3] + 12, c.r[6]);  // 060B1B36 mov.l r6,@(12,r3)
    st32(c.r[3] + 20, c.r[0]);  // 060B1B38 mov.l r0,@(20,r3)
    c.r[2] = 0x1u;  // 060B1B3A mov #1,r2
    c.r[2] <<= 16;  // 060B1B3C shll16 r2
    c.r[2] += 1;  // 060B1B3E add #1,r2
    c.r[0] += c.r[2];  // 060B1B40 add r2,r0
    c.r[0] -= c.r[6];  // 060B1B42 sub r6,r0
    st32(c.gbr + 816, c.r[0]);  // 060B1B44 mov.l r0,@(816,gbr)
    c.r[0] = c.r[1];  // 060B1B46 mov r1,r0
    st16(c.r[3] + 28, c.r[0]);  // 060B1B48 mov.w r0,@(28,r3)
    c.r[0] = ld32(c.r[4]); c.r[4] += 4;  // 060B1B4A mov.l @r4+,r0
    c.r[3] += 44;  // 060B1B4C add #44,r3
    st32(c.r[3] + 12, c.r[0]);  // 060B1B4E mov.l r0,@(12,r3)
    c.r[2] = c.r[0];  // 060B1B50 mov r0,r2
    c.r[0] = c.r[6] << 16 | c.r[6] >> 16;  // 060B1B52 swap.w r6,r0
    c.r[1] = c.r[2] << 16 | c.r[2] >> 16;  // 060B1B54 swap.w r2,r1
    c.r[1] -= c.r[0];  // 060B1B56 sub r0,r1
    c.r[0] = c.r[2];  // 060B1B58 mov r2,r0
    c.r[0] -= c.r[6];  // 060B1B5A sub r6,r0
    c.r[0] <<= 16;  // 060B1B5C shll16 r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060B1B5E xtrct r1,r0
    st32(c.gbr + 148, c.r[0]);  // 060B1B60 mov.l r0,@(148,gbr)
    c.r[1] = c.r[0] << 16 | c.r[0] >> 16;  // 060B1B62 swap.w r0,r1
    c.r[0] = ld32(0x060B1C14u);  // 060B1B64 mov.l 0x060B1C14,r0
    c.r[6] = c.r[1] << 16 | c.r[1] >> 16;  // 060B1B66 swap.w r1,r6
    c.r[0] = ld32(c.r[0]);  // 060B1B68 mov.l @r0,r0
    c.r[6] <<= 16;  // 060B1B6A shll16 r6
    c.r[1] += c.r[0];  // 060B1B6C add r0,r1
    c.r[0] += c.r[6];  // 060B1B6E add r6,r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060B1B70 xtrct r1,r0
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B1B72 tst r5,r5
    { const bool k = !c.t; st32(c.gbr + 156, c.r[0]); if (k) { goto L_060B1B86; } }  // 060B1B74 bf/s 0x060B1B86 ; mov.l r0,@(156,gbr)
    c.r[1] = c.r[2] << 16 | c.r[2] >> 16;  // 060B1B78 swap.w r2,r1
    c.r[0] = 0x060B1C44u;  // 060B1B7A mova 0x060B1C44,r0
    c.r[3] = 0u - c.r[2];  // 060B1B7C neg r2,r3
    c.r[1] = 0u - c.r[1];  // 060B1B7E neg r1,r1
    c.r[3] <<= 16;  // 060B1B80 shll16 r3
    c.r[3] = c.r[1] << 16 | c.r[3] >> 16;  // 060B1B82 xtrct r1,r3
    st32(c.r[0] + 12, c.r[3]);  // 060B1B84 mov.l r3,@(12,r0)
L_060B1B86:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1B86 rts ; nop
}

void f_060B1B8A(SH2Context& c) {
    ran[3082] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1B8A sts.l pr,@-r15
    c.r[0] = ld32(0x060B1C04u);  // 060B1B8C mov.l 0x060B1C04,r0
    c.r[4] -= 4;  // 060B1B8E add #-4,r4
    c.r[0] = ld32(c.r[0]);  // 060B1B90 mov.l @r0,r0
    c.r[0] += 16;  // 060B1B92 add #16,r0
    st32(c.gbr + 40, c.r[0]);  // 060B1B94 mov.l r0,@(40,gbr)
    c.r[1] = ld32(0x060B1C40u);  // 060B1B96 mov.l 0x060B1C40,r1
    c.r[0] = ld32(c.gbr + 64);  // 060B1B98 mov.l @(64,gbr),r0
    c.r[1] = ld32(c.r[1]);  // 060B1B9A mov.l @r1,r1
    c.r[0] += c.r[1];  // 060B1B9C add r1,r0
    c.pr = 0x060B1BA2u; st32(c.gbr + 52, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1C18u); if (c.pc != 0x060B1BA2u) return;  // 060B1B9E bsr 0x060B1C18 ; mov.l r0,@(52,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1BA2 lds.l @r15+,pr
    c.r[0] = 0x0u;  // 060B1BA4 mov #0,r0
    st8(c.gbr + 169, c.r[0]);  // 060B1BA6 mov.b r0,@(169,gbr)
    c.r[3] = c.r[0];  // 060B1BA8 mov r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B1BAA mov.b @(169,gbr),r0
    c.r[2] = ld32(0x060B1C00u);  // 060B1BAC mov.l 0x060B1C00,r2
    c.r[0] &= 0xF0u;  // 060B1BAE and #240,r0
    c.r[0] |= c.r[3];  // 060B1BB0 or r3,r0
    st8(c.gbr + 169, c.r[0]);  // 060B1BB2 mov.b r0,@(169,gbr)
    c.r[0] = ld32(0x060B1C38u);  // 060B1BB4 mov.l 0x060B1C38,r0
    c.r[3] <<= 2;  // 060B1BB6 shll2 r3
    c.r[2] += c.r[3];  // 060B1BB8 add r3,r2
    c.t = (c.r[3] & c.r[3]) == 0;  // 060B1BBA tst r3,r3
    { const bool k = !c.t; c.r[0] = ld32(c.r[0]); if (k) { goto L_060B1BC4; } }  // 060B1BBC bf/s 0x060B1BC4 ; mov.l @r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B1BFEu);  // 060B1BC0 mov.w 0x060B1BFE,r1
    c.r[0] += c.r[1];  // 060B1BC2 add r1,r0
L_060B1BC4:
    st32(c.gbr + 56, c.r[0]);  // 060B1BC4 mov.l r0,@(56,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 30);  // 060B1BC6 mov.w @(30,r2),r0
    st8(c.gbr + 173, c.r[0]);  // 060B1BC8 mov.b r0,@(173,gbr)
    c.r[0] = ld32(c.r[2] + 36);  // 060B1BCA mov.l @(36,r2),r0
    st32(c.gbr + 108, c.r[0]);  // 060B1BCC mov.l r0,@(108,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 28);  // 060B1BCE mov.w @(28,r2),r0
    st16(c.gbr + 160, c.r[0]);  // 060B1BD0 mov.w r0,@(160,gbr)
    c.r[0] = ld32(c.r[2] + 20);  // 060B1BD2 mov.l @(20,r2),r0
    c.r[3] = ld32(c.r[2] + 12);  // 060B1BD4 mov.l @(12,r2),r3
    c.r[1] = 0x1u;  // 060B1BD6 mov #1,r1
    c.r[1] <<= 16;  // 060B1BD8 shll16 r1
    c.r[1] += 1;  // 060B1BDA add #1,r1
    c.r[0] += c.r[1];  // 060B1BDC add r1,r0
    c.r[1] = ld32(c.r[2] + 56);  // 060B1BDE mov.l @(56,r2),r1
    c.r[0] -= c.r[3];  // 060B1BE0 sub r3,r0
    st32(c.gbr + 816, c.r[0]);  // 060B1BE2 mov.l r0,@(816,gbr)
    c.r[0] = c.r[1];  // 060B1BE4 mov r1,r0
    c.r[2] = ld32(0x060B1C14u);  // 060B1BE6 mov.l 0x060B1C14,r2
    c.r[0] -= c.r[3];  // 060B1BE8 sub r3,r0
    st32(c.gbr + 148, c.r[0]);  // 060B1BEA mov.l r0,@(148,gbr)
    c.r[1] = c.r[0];  // 060B1BEC mov r0,r1
    c.r[0] = ld32(c.r[2]);  // 060B1BEE mov.l @r2,r0
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 060B1BF0 swap.w r1,r2
    c.r[2] += c.r[0];  // 060B1BF2 add r0,r2
    c.r[1] <<= 16;  // 060B1BF4 shll16 r1
    c.r[0] += c.r[1];  // 060B1BF6 add r1,r0
    c.r[0] = c.r[2] << 16 | c.r[0] >> 16;  // 060B1BF8 xtrct r2,r0
    { const uint32_t x = c.pr; st32(c.gbr + 156, c.r[0]); c.pc = x; return; }  // 060B1BFA rts ; mov.l r0,@(156,gbr)
}

void f_060B1BA8(SH2Context& c) {
    ran[3083] = 1;
    c.r[3] = c.r[0];  // 060B1BA8 mov r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B1BAA mov.b @(169,gbr),r0
    c.r[2] = ld32(0x060B1C00u);  // 060B1BAC mov.l 0x060B1C00,r2
    c.r[0] &= 0xF0u;  // 060B1BAE and #240,r0
    c.r[0] |= c.r[3];  // 060B1BB0 or r3,r0
    st8(c.gbr + 169, c.r[0]);  // 060B1BB2 mov.b r0,@(169,gbr)
    c.r[0] = ld32(0x060B1C38u);  // 060B1BB4 mov.l 0x060B1C38,r0
    c.r[3] <<= 2;  // 060B1BB6 shll2 r3
    c.r[2] += c.r[3];  // 060B1BB8 add r3,r2
    c.t = (c.r[3] & c.r[3]) == 0;  // 060B1BBA tst r3,r3
    { const bool k = !c.t; c.r[0] = ld32(c.r[0]); if (k) { goto L_060B1BC4; } }  // 060B1BBC bf/s 0x060B1BC4 ; mov.l @r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B1BFEu);  // 060B1BC0 mov.w 0x060B1BFE,r1
    c.r[0] += c.r[1];  // 060B1BC2 add r1,r0
L_060B1BC4:
    st32(c.gbr + 56, c.r[0]);  // 060B1BC4 mov.l r0,@(56,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 30);  // 060B1BC6 mov.w @(30,r2),r0
    st8(c.gbr + 173, c.r[0]);  // 060B1BC8 mov.b r0,@(173,gbr)
    c.r[0] = ld32(c.r[2] + 36);  // 060B1BCA mov.l @(36,r2),r0
    st32(c.gbr + 108, c.r[0]);  // 060B1BCC mov.l r0,@(108,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 28);  // 060B1BCE mov.w @(28,r2),r0
    st16(c.gbr + 160, c.r[0]);  // 060B1BD0 mov.w r0,@(160,gbr)
    c.r[0] = ld32(c.r[2] + 20);  // 060B1BD2 mov.l @(20,r2),r0
    c.r[3] = ld32(c.r[2] + 12);  // 060B1BD4 mov.l @(12,r2),r3
    c.r[1] = 0x1u;  // 060B1BD6 mov #1,r1
    c.r[1] <<= 16;  // 060B1BD8 shll16 r1
    c.r[1] += 1;  // 060B1BDA add #1,r1
    c.r[0] += c.r[1];  // 060B1BDC add r1,r0
    c.r[1] = ld32(c.r[2] + 56);  // 060B1BDE mov.l @(56,r2),r1
    c.r[0] -= c.r[3];  // 060B1BE0 sub r3,r0
    st32(c.gbr + 816, c.r[0]);  // 060B1BE2 mov.l r0,@(816,gbr)
    c.r[0] = c.r[1];  // 060B1BE4 mov r1,r0
    c.r[2] = ld32(0x060B1C14u);  // 060B1BE6 mov.l 0x060B1C14,r2
    c.r[0] -= c.r[3];  // 060B1BE8 sub r3,r0
    st32(c.gbr + 148, c.r[0]);  // 060B1BEA mov.l r0,@(148,gbr)
    c.r[1] = c.r[0];  // 060B1BEC mov r0,r1
    c.r[0] = ld32(c.r[2]);  // 060B1BEE mov.l @r2,r0
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 060B1BF0 swap.w r1,r2
    c.r[2] += c.r[0];  // 060B1BF2 add r0,r2
    c.r[1] <<= 16;  // 060B1BF4 shll16 r1
    c.r[0] += c.r[1];  // 060B1BF6 add r1,r0
    c.r[0] = c.r[2] << 16 | c.r[0] >> 16;  // 060B1BF8 xtrct r2,r0
    { const uint32_t x = c.pr; st32(c.gbr + 156, c.r[0]); c.pc = x; return; }  // 060B1BFA rts ; mov.l r0,@(156,gbr)
}

void f_060B1C18(SH2Context& c) {
    ran[3084] = 1;
    c.r[1] = 0xFFFFFFA4u;  // 060B1C18 mov #-92,r1
    c.r[1] <<= 2;  // 060B1C1A shll2 r1
    c.r[0] = 0x11u;  // 060B1C1C mov #17,r0
    st8(c.r[1] + 2, c.r[0]);  // 060B1C1E mov.b r0,@(2,r1)
    ;  // 060B1C20 nop
    ;  // 060B1C22 nop
    ;  // 060B1C24 nop
    ;  // 060B1C26 nop
    ;  // 060B1C28 nop
    ;  // 060B1C2A nop
    ;  // 060B1C2C nop
    ;  // 060B1C2E nop
    ;  // 060B1C30 nop
    ;  // 060B1C32 nop
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B1C34 rts ; nop
}

void f_060B1C58(SH2Context& c) {
    ran[3085] = 1;
    c.r[0] = ld32(0x060B1D5Cu);  // 060B1C58 mov.l 0x060B1D5C,r0
    c.r[1] = ld32(0x060B1D60u);  // 060B1C5A mov.l 0x060B1D60,r1
    c.r[0] = ld32(c.r[0]);  // 060B1C5C mov.l @r0,r0
    c.r[0] |= c.r[1];  // 060B1C5E or r1,r0
    st32(c.gbr + 68, c.r[0]);  // 060B1C60 mov.l r0,@(68,gbr)
    st32(c.gbr + 72, c.r[0]);  // 060B1C62 mov.l r0,@(72,gbr)
    c.r[3] = c.r[0];  // 060B1C64 mov r0,r3
    c.r[7] = ld32(0x060B1D64u);  // 060B1C66 mov.l 0x060B1D64,r7
    c.r[6] = ld32(0x060B1D68u);  // 060B1C68 mov.l 0x060B1D68,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B1D52u);  // 060B1C6A mov.w 0x060B1D52,r0
    st16(c.r[7], c.r[0]);  // 060B1C6C mov.w r0,@r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060B1C6E mov.b @(176,gbr),r0
    c.r[1] = 0x1Fu;  // 060B1C70 mov #31,r1
    c.r[4] &= c.r[1];  // 060B1C72 and r1,r4
    c.r[0] &= 0x80u;  // 060B1C74 and #128,r0
    c.r[0] |= c.r[4];  // 060B1C76 or r4,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B1C78 tst #16,r0
    if (c.t) { goto L_060B1C7E; }  // 060B1C7A bt 0x060B1C7E
    c.r[0] &= 0x7Fu;  // 060B1C7C and #127,r0
L_060B1C7E:
    st8(c.gbr + 176, c.r[0]);  // 060B1C7E mov.b r0,@(176,gbr)
    c.r[0] >>= 2;  // 060B1C80 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B1C82 shlr r0
    c.r[0] &= 0x1u;  // 060B1C84 and #1,r0
    c.r[4] <<= 2;  // 060B1C86 shll2 r4
    st16(c.r[6], c.r[0]);  // 060B1C88 mov.w r0,@(0,r6)
    st32(c.r[3] + 4, c.r[4]);  // 060B1C8A mov.l r4,@(4,r3)
    c.r[1] = 0x8u;  // 060B1C8C mov #8,r1
    st32(c.r[3], c.r[1]);  // 060B1C8E mov.l r1,@(0,r3)
    c.r[0] = c.r[3];  // 060B1C90 mov r3,r0
    c.r[1] = ld32(0x060B1D84u);  // 060B1C92 mov.l 0x060B1D84,r1
    c.r[0] += 8;  // 060B1C94 add #8,r0
    st32(c.gbr + 72, c.r[0]);  // 060B1C96 mov.l r0,@(72,gbr)
    st16(c.r[1], c.r[0]);  // 060B1C98 mov.w r0,@r1
    c.r[0] = c.r[5];  // 060B1C9A mov r5,r0
    st32(c.gbr + 60, c.r[0]);  // 060B1C9C mov.l r0,@(60,gbr)
    c.r[0] = ld32(0x060B1D80u);  // 060B1C9E mov.l 0x060B1D80,r0
    c.r[1] = 0x1u;  // 060B1CA0 mov #1,r1
    c.r[2] = ld32(c.r[0] + c.r[4]);  // 060B1CA2 mov.l @(r0,r4),r2
    c.r[1] <<= 16;  // 060B1CA4 shll16 r1
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060B1CA6 swap.w r2,r0
    c.r[0] <<= 16;  // 060B1CA8 shll16 r0
    st32(c.gbr + 104, c.r[0]);  // 060B1CAA mov.l r0,@(104,gbr)
    c.r[0] = 0u - c.r[2];  // 060B1CAC neg r2,r0
    c.r[0] += c.r[1];  // 060B1CAE add r1,r0
    st32(c.gbr + 120, c.r[0]);  // 060B1CB0 mov.l r0,@(120,gbr)
    c.r[0] = ld32(0x060B1D58u);  // 060B1CB2 mov.l 0x060B1D58,r0
    c.r[1] += 1;  // 060B1CB4 add #1,r1
    c.r[0] += c.r[2];  // 060B1CB6 add r2,r0
    st32(c.gbr + 152, c.r[0]);  // 060B1CB8 mov.l r0,@(152,gbr)
    c.r[0] = c.r[2];  // 060B1CBA mov r2,r0
    st32(c.gbr + 144, c.r[0]);  // 060B1CBC mov.l r0,@(144,gbr)
    c.r[0] -= c.r[1];  // 060B1CBE sub r1,r0
    st32(c.gbr + 124, c.r[0]);  // 060B1CC0 mov.l r0,@(124,gbr)
    c.r[2] += c.r[2];  // 060B1CC2 add r2,r2
    c.r[0] = c.r[2];  // 060B1CC4 mov r2,r0
    st32(c.gbr + 128, c.r[0]);  // 060B1CC6 mov.l r0,@(128,gbr)
    st32(c.gbr + 132, c.r[0]);  // 060B1CC8 mov.l r0,@(132,gbr)
    c.r[0] -= c.r[1];  // 060B1CCA sub r1,r0
    st32(c.r[7] + 20, c.r[0]);  // 060B1CCC mov.l r0,@(20,r7)
    c.r[0] = 0x0u;  // 060B1CCE mov #0,r0
    st32(c.gbr + 896, c.r[0]);  // 060B1CD0 mov.l r0,@(896,gbr)
    st32(c.gbr + 904, c.r[0]);  // 060B1CD2 mov.l r0,@(904,gbr)
    c.r[0] = 0x1u;  // 060B1CD4 mov #1,r0
    st32(c.gbr + 888, c.r[0]);  // 060B1CD6 mov.l r0,@(888,gbr)
    c.r[0] = ld32(0x060B1D54u);  // 060B1CD8 mov.l 0x060B1D54,r0
    st32(c.gbr + 772, c.r[0]);  // 060B1CDA mov.l r0,@(772,gbr)
    c.r[3] <<= 16;  // 060B1CDC shll16 r3
    c.r[3] |= c.r[0];  // 060B1CDE or r0,r3
    c.r[3] += c.r[3];  // 060B1CE0 add r3,r3
    c.r[0] = c.r[2];  // 060B1CE2 mov r2,r0
    c.r[0] += c.r[3];  // 060B1CE4 add r3,r0
    st32(c.gbr + 140, c.r[0]);  // 060B1CE6 mov.l r0,@(140,gbr)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B1D52u);  // 060B1CE8 mov.w 0x060B1D52,r1
    c.r[0] = c.r[7];  // 060B1CEA mov r7,r0
    c.r[0] += 32;  // 060B1CEC add #32,r0
    st16(c.r[0], c.r[1]);  // 060B1CEE mov.w r1,@r0
    c.r[0] = ld32(0x060B1D6Cu);  // 060B1CF0 mov.l 0x060B1D6C,r0
    c.r[1] = ld32(0x060B1D70u);  // 060B1CF2 mov.l 0x060B1D70,r1
    c.r[0] = ld32(c.r[0]);  // 060B1CF4 mov.l @r0,r0
    c.r[1] = ld32(c.r[1]);  // 060B1CF6 mov.l @r1,r1
    c.r[0] -= 36;  // 060B1CF8 add #-36,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060B1CFA shlr r1
    c.r[0] += c.r[1];  // 060B1CFC add r1,r0
    st32(c.gbr + 48, c.r[0]);  // 060B1CFE mov.l r0,@(48,gbr)
    c.r[0] = 0x0u;  // 060B1D00 mov #0,r0
    st32(c.gbr + 64, c.r[0]);  // 060B1D02 mov.l r0,@(64,gbr)
    c.r[1] = ld32(0x060B1D88u);  // 060B1D04 mov.l 0x060B1D88,r1
    st32(c.r[7], c.r[1]);  // 060B1D06 mov.l r1,@r7
    c.r[0] = 0x0u;  // 060B1D08 mov #0,r0
    st16(c.r[6] + 2, c.r[0]);  // 060B1D0A mov.w r0,@(2,r6)
    c.r[0] = 0x2u;  // 060B1D0C mov #2,r0
    st16(c.r[6] + 4, c.r[0]);  // 060B1D0E mov.w r0,@(4,r6)
    c.r[0] = 0x0u;  // 060B1D10 mov #0,r0
    st16(c.gbr + 114, c.r[0]);  // 060B1D12 mov.w r0,@(114,gbr)
    st16(c.r[6] + 6, c.r[0]);  // 060B1D14 mov.w r0,@(6,r6)
    st16(c.r[6] + 8, c.r[0]);  // 060B1D16 mov.w r0,@(8,r6)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B1D4Eu);  // 060B1D18 mov.w 0x060B1D4E,r0
    c.r[1] = ld32(0x060B1D74u);  // 060B1D1A mov.l 0x060B1D74,r1
    c.r[2] = ld32(0x060B1D7Cu);  // 060B1D1C mov.l 0x060B1D7C,r2
    c.r[3] = ld32(0x060B1D78u);  // 060B1D1E mov.l 0x060B1D78,r3
    st16(c.r[6] + 10, c.r[0]);  // 060B1D20 mov.w r0,@(10,r6)
    c.r[0] = ld32(c.r[1]);  // 060B1D22 mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060B1D24 mov.w @r2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060B1D26 mov.w @r3,r3
    st32(c.gbr + 36, c.r[0]);  // 060B1D28 mov.l r0,@(36,gbr)
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060B1D2A swap.w r2,r0
    c.r[0] = c.r[3] << 16 | c.r[0] >> 16;  // 060B1D2C xtrct r3,r0
    st32(c.gbr + 136, c.r[0]);  // 060B1D2E mov.l r0,@(136,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B1D50u);  // 060B1D30 mov.w 0x060B1D50,r0
    st16(c.gbr + 112, c.r[0]);  // 060B1D32 mov.w r0,@(112,gbr)
    c.r[0] = 0x0u;  // 060B1D34 mov #0,r0
    st8(c.gbr + 168, c.r[0]);  // 060B1D36 mov.b r0,@(168,gbr)
    st32(c.gbr + 116, c.r[0]);  // 060B1D38 mov.l r0,@(116,gbr)
    st32(c.gbr + 76, c.r[0]);  // 060B1D3A mov.l r0,@(76,gbr)
    st32(c.gbr + 80, c.r[0]);  // 060B1D3C mov.l r0,@(80,gbr)
    c.r[0] = 0xFFFFFFFFu;  // 060B1D3E mov #-1,r0
    st8(c.gbr + 166, c.r[0]);  // 060B1D40 mov.b r0,@(166,gbr)
    c.r[0] <<= 16;  // 060B1D42 shll16 r0
    st32(c.gbr + 84, c.r[0]);  // 060B1D44 mov.l r0,@(84,gbr)
    c.r[0] = 0x1u;  // 060B1D46 mov #1,r0
    st8(c.gbr + 166, c.r[0]);  // 060B1D48 mov.b r0,@(166,gbr)
    { const uint32_t x = c.pr; st8(c.gbr + 172, c.r[0]); c.pc = x; return; }  // 060B1D4A rts ; mov.b r0,@(172,gbr)
}

void f_060B1D8C(SH2Context& c) {
    ran[3086] = 1;
    c.r[0] = 0xFFFFFFFFu;  // 060B1D8C mov #-1,r0
    st16(c.r[5] + 2, c.r[0]);  // 060B1D8E mov.w r0,@(2,r5)
    st16(c.r[5] + 4, c.r[0]);  // 060B1D90 mov.w r0,@(4,r5)
    { const uint32_t x = c.pr; st16(c.r[5] + 6, c.r[0]); c.pc = x; return; }  // 060B1D92 rts ; mov.w r0,@(6,r5)
}

void f_060B1D96(SH2Context& c) {
    ran[3087] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5] + 2);  // 060B1D96 mov.w @(2,r5),r0
    c.r[1] = ~c.r[4];  // 060B1D98 not r4,r1
    c.r[2] = ~c.r[0];  // 060B1D9A not r0,r2
    c.r[0] &= c.r[1];  // 060B1D9C and r1,r0
    c.r[0] = ~c.r[0];  // 060B1D9E not r0,r0
    st16(c.r[5] + 4, c.r[0]);  // 060B1DA0 mov.w r0,@(4,r5)
    c.r[2] &= c.r[4];  // 060B1DA2 and r4,r2
    c.r[0] = ~c.r[2];  // 060B1DA4 not r2,r0
    st16(c.r[5] + 6, c.r[0]);  // 060B1DA6 mov.w r0,@(6,r5)
    c.r[0] = c.r[4];  // 060B1DA8 mov r4,r0
    { const uint32_t x = c.pr; st16(c.r[5] + 2, c.r[0]); c.pc = x; return; }  // 060B1DAA rts ; mov.w r0,@(2,r5)
}

void f_060B1DAE(SH2Context& c) {
    ran[3088] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1DAE sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1DB0 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1DB2 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1DB4 mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1DB6 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1DD0; } }  // 060B1DB8 bt/s 0x060B1DD0 ; mov.b r1,@(r0,r5)
    c.pr = 0x060B1DC0u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1DC0u) return;  // 060B1DBC bsr 0x060B1D8C ; mov.l r1,@-r15
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060B1DC0 mov.l @r15+,r0
    c.r[4] += 1;  // 060B1DC2 add #1,r4
    c.r[0] &= 0xFu;  // 060B1DC4 and #15,r0
    c.t = c.r[0] == 0x1u;  // 060B1DC6 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_060B1DEE; } }  // 060B1DC8 bt/s 0x060B1DEE ; mov r0,r1
    c.r[4] += 1; goto L_060B1DEE;  // 060B1DCC bra 0x060B1DEE ; add #1,r4
L_060B1DD0:
    c.r[0] = c.r[1];  // 060B1DD0 mov r1,r0
    c.r[0] &= 0xFu;  // 060B1DD2 and #15,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B1DD4 mov.l r0,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1DD6 mov.b @r4+,r1
    c.t = c.r[0] == 0x1u;  // 060B1DD8 cmp/eq #1,r0
    { const bool k = c.t; c.r[2] = 0xFFFFFFFFu; if (k) { goto L_060B1DE0; } }  // 060B1DDA bt/s 0x060B1DE0 ; mov #-1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1DDE mov.b @r4+,r2
L_060B1DE0:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1DE0 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B1DE2 shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B1DE4 extu.b r2,r4
    c.pr = 0x060B1DEAu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B1DEAu) return;  // 060B1DE6 bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1DEA mov.l @r15+,r4
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B1DEC mov.l @r15+,r1
L_060B1DEE:
    c.r[2] = 0x2u;  // 060B1DEE mov #2,r2
    c.t = c.r[1] > c.r[2];  // 060B1DF0 cmp/hi r2,r1
    if (!c.t) { goto L_060B1E02; }  // 060B1DF2 bf 0x060B1E02
    c.r[0] = 0x8u;  // 060B1DF4 mov #8,r0
    c.r[1] -= 2;  // 060B1DF6 add #-2,r1
L_060B1DF8:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1DF8 mov.b @r4+,r2
    st8(c.r[0] + c.r[5], c.r[2]);  // 060B1DFA mov.b r2,@(r0,r5)
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B1DFC dt r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060B1DF8; } }  // 060B1DFE bf/s 0x060B1DF8 ; add #1,r0
L_060B1E02:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1E02 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B1E04 rts ; mov r4,r0
}

void f_060B1E08(SH2Context& c) {
    ran[3089] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1E08 sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1E0A mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E0C mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1E0E mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1E10 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1E1E; } }  // 060B1E12 bt/s 0x060B1E1E ; mov.b r1,@(r0,r5)
    c.pr = 0x060B1E1Au; SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1E1Au) return;  // 060B1E16 bsr 0x060B1D8C ; nop
    c.r[4] += 2; goto L_060B1E2E;  // 060B1E1A bra 0x060B1E2E ; add #2,r4
L_060B1E1E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E1E mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E20 mov.b @r4+,r2
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1E22 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B1E24 shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B1E26 extu.b r2,r4
    c.pr = 0x060B1E2Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B1E2Cu) return;  // 060B1E28 bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1E2C mov.l @r15+,r4
L_060B1E2E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1E2E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B1E30 rts ; mov r4,r0
}

void f_060B1E34(SH2Context& c) {
    ran[3090] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1E34 sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1E36 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E38 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1E3A mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1E3C cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1E4C; } }  // 060B1E3E bt/s 0x060B1E4C ; mov.b r1,@(r0,r5)
    c.r[0] = 0x7Fu;  // 060B1E42 mov #127,r0
    c.pr = 0x060B1E48u; st8(c.r[5] + 8, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1E48u) return;  // 060B1E44 bsr 0x060B1D8C ; mov.b r0,@(8,r5)
    c.r[4] += 3; goto L_060B1E64;  // 060B1E48 bra 0x060B1E64 ; add #3,r4
L_060B1E4C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E4C mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E4E mov.b @r4+,r2
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B1E50 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1E52 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B1E54 shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B1E56 extu.b r2,r4
    c.pr = 0x060B1E5Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B1E5Cu) return;  // 060B1E58 bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1E5C mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B1E5E mov.l @r15+,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E60 mov.b @r4+,r0
    st8(c.r[5] + 8, c.r[0]);  // 060B1E62 mov.b r0,@(8,r5)
L_060B1E64:
    c.r[0] = 0x7Fu;  // 060B1E64 mov #127,r0
    st8(c.r[5] + 9, c.r[0]);  // 060B1E66 mov.b r0,@(9,r5)
    st8(c.r[5] + 10, c.r[0]);  // 060B1E68 mov.b r0,@(10,r5)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1E6A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B1E6C rts ; mov r4,r0
}

void f_060B1E70(SH2Context& c) {
    ran[3091] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1E70 sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1E72 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E74 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1E76 mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1E78 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1E8C; } }  // 060B1E7A bt/s 0x060B1E8C ; mov.b r1,@(r0,r5)
    c.r[0] = 0x7Fu;  // 060B1E7E mov #127,r0
    st8(c.r[5] + 8, c.r[0]);  // 060B1E80 mov.b r0,@(8,r5)
    st8(c.r[5] + 9, c.r[0]);  // 060B1E82 mov.b r0,@(9,r5)
    c.pr = 0x060B1E88u; st8(c.r[5] + 10, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1E88u) return;  // 060B1E84 bsr 0x060B1D8C ; mov.b r0,@(10,r5)
    c.r[4] += 5; goto L_060B1EAC;  // 060B1E88 bra 0x060B1EAC ; add #5,r4
L_060B1E8C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E8C mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1E8E mov.b @r4+,r2
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B1E90 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1E92 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B1E94 shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B1E96 extu.b r2,r4
    c.pr = 0x060B1E9Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B1E9Cu) return;  // 060B1E98 bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1E9C mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B1E9E mov.l @r15+,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1EA0 mov.b @r4+,r0
    st8(c.r[5] + 8, c.r[0]);  // 060B1EA2 mov.b r0,@(8,r5)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1EA4 mov.b @r4+,r0
    st8(c.r[5] + 9, c.r[0]);  // 060B1EA6 mov.b r0,@(9,r5)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1EA8 mov.b @r4+,r0
    st8(c.r[5] + 10, c.r[0]);  // 060B1EAA mov.b r0,@(10,r5)
L_060B1EAC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1EAC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B1EAE rts ; mov r4,r0
}

void f_060B1EB2(SH2Context& c) {
    ran[3092] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060B1EB2 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1EB4 sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1EB6 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1EB8 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1EBA mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1EBC cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1ECE; } }  // 060B1EBE bt/s 0x060B1ECE ; mov.b r1,@(r0,r5)
    c.r[0] ^= c.r[0];  // 060B1EC2 xor r0,r0
    st16(c.r[5] + 8, c.r[0]);  // 060B1EC4 mov.w r0,@(8,r5)
    c.pr = 0x060B1ECAu; st16(c.r[5] + 10, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1ECAu) return;  // 060B1EC6 bsr 0x060B1D8C ; mov.w r0,@(10,r5)
    c.r[4] += 3; goto L_060B1F56;  // 060B1ECA bra 0x060B1F56 ; add #3,r4
L_060B1ECE:
    c.r[0] = 0x060B1F60u;  // 060B1ECE mova 0x060B1F60,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1ED0 mov.b @r4+,r1
    c.r[2] = c.r[0];  // 060B1ED2 mov r0,r2
    c.r[0] = 0xFu;  // 060B1ED4 mov #15,r0
    c.r[0] &= c.r[1];  // 060B1ED6 and r1,r0
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060B1ED8 shll r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060B1EDA mov.w @(r0,r2),r6
    c.r[0] = c.r[1];  // 060B1EDC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1EDE mov.b @r4+,r1
    c.r[2] = 0xFFFFFF80u;  // 060B1EE0 mov #-128,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060B1EE2 extu.b r1,r1
    c.t = (c.r[0] & 0x10u) == 0;  // 060B1EE4 tst #16,r0
    { const bool k = !c.t; c.t = c.r[2] >> 31; c.r[2] <<= 1; if (k) { goto L_060B1EF6; } }  // 060B1EE6 bf/s 0x060B1EF6 ; shll r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060B1F82u);  // 060B1EEA mov.w 0x060B1F82,r3
    c.r[7] = 0x2u;  // 060B1EEC mov #2,r7
    c.t = c.r[1] >= c.r[7];  // 060B1EEE cmp/hs r7,r1
    if (c.t) { goto L_060B1F02; }  // 060B1EF0 bt 0x060B1F02
    c.r[3] ^= c.r[3]; goto L_060B1F02;  // 060B1EF2 bra 0x060B1F02 ; xor r3,r3
L_060B1EF6:
    c.r[1] |= c.r[2];  // 060B1EF6 or r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060B1F84u);  // 060B1EF8 mov.w 0x060B1F84,r3
    c.r[7] = 0xFFFFFFFEu;  // 060B1EFA mov #-2,r7
    c.t = c.r[1] > c.r[7];  // 060B1EFC cmp/hi r7,r1
    if (!c.t) { goto L_060B1F02; }  // 060B1EFE bf 0x060B1F02
    c.r[3] ^= c.r[3];  // 060B1F00 xor r3,r3
L_060B1F02:
    c.r[6] ^= c.r[3];  // 060B1F02 xor r3,r6
    c.t = (c.r[0] & 0x40u) == 0;  // 060B1F04 tst #64,r0
    if (c.t) { goto L_060B1F0C; }  // 060B1F06 bt 0x060B1F0C
    c.r[3] = (uint32_t)(int16_t)ld16(0x060B1F80u);  // 060B1F08 mov.w 0x060B1F80,r3
    c.r[1] ^= c.r[3];  // 060B1F0A xor r3,r1
L_060B1F0C:
    c.r[2] = c.r[0];  // 060B1F0C mov r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5] + 8);  // 060B1F0E mov.w @(8,r5),r0
    c.r[0] += c.r[1];  // 060B1F10 add r1,r0
    st16(c.r[5] + 8, c.r[0]);  // 060B1F12 mov.w r0,@(8,r5)
    c.r[0] = c.r[2];  // 060B1F14 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1F16 mov.b @r4+,r1
    c.r[2] = 0xFFFFFF80u;  // 060B1F18 mov #-128,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060B1F1A extu.b r1,r1
    c.t = (c.r[0] & 0x20u) == 0;  // 060B1F1C tst #32,r0
    { const bool k = !c.t; c.t = c.r[2] >> 31; c.r[2] <<= 1; if (k) { goto L_060B1F2E; } }  // 060B1F1E bf/s 0x060B1F2E ; shll r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060B1F88u);  // 060B1F22 mov.w 0x060B1F88,r3
    c.r[7] = 0x2u;  // 060B1F24 mov #2,r7
    c.t = c.r[1] >= c.r[7];  // 060B1F26 cmp/hs r7,r1
    if (c.t) { goto L_060B1F3A; }  // 060B1F28 bt 0x060B1F3A
    c.r[3] ^= c.r[3]; goto L_060B1F3A;  // 060B1F2A bra 0x060B1F3A ; xor r3,r3
L_060B1F2E:
    c.r[1] |= c.r[2];  // 060B1F2E or r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060B1F86u);  // 060B1F30 mov.w 0x060B1F86,r3
    c.r[7] = 0xFFFFFFFEu;  // 060B1F32 mov #-2,r7
    c.t = c.r[1] > c.r[7];  // 060B1F34 cmp/hi r7,r1
    if (!c.t) { goto L_060B1F3A; }  // 060B1F36 bf 0x060B1F3A
    c.r[3] ^= c.r[3];  // 060B1F38 xor r3,r3
L_060B1F3A:
    c.r[6] ^= c.r[3];  // 060B1F3A xor r3,r6
    c.t = (c.r[0] & 0x80u) == 0;  // 060B1F3C tst #128,r0
    if (c.t) { goto L_060B1F44; }  // 060B1F3E bt 0x060B1F44
    c.r[3] = (uint32_t)(int16_t)ld16(0x060B1F80u);  // 060B1F40 mov.w 0x060B1F80,r3
    c.r[1] ^= c.r[3];  // 060B1F42 xor r3,r1
L_060B1F44:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5] + 10);  // 060B1F44 mov.w @(10,r5),r0
    c.r[0] -= c.r[1];  // 060B1F46 sub r1,r0
    st16(c.r[5] + 10, c.r[0]);  // 060B1F48 mov.w r0,@(10,r5)
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B1F4A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1F4C mov.l r4,@-r15
    c.pr = 0x060B1F52u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B1F52u) return;  // 060B1F4E bsr 0x060B1D96 ; mov r6,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1F52 mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B1F54 mov.l @r15+,r5
L_060B1F56:
    c.r[0] = c.r[4];  // 060B1F56 mov r4,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1F58 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[7] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B1F5A rts ; mov.l @r15+,r7
}

void f_060B1F8A(SH2Context& c) {
    ran[3093] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1F8A sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1F8C mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1F8E mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1F90 mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1F92 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1FA4; } }  // 060B1F94 bt/s 0x060B1FA4 ; mov.b r1,@(r0,r5)
    c.r[0] ^= c.r[0];  // 060B1F98 xor r0,r0
    st16(c.r[5] + 8, c.r[0]);  // 060B1F9A mov.w r0,@(8,r5)
    c.pr = 0x060B1FA0u; st16(c.r[5] + 10, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1FA0u) return;  // 060B1F9C bsr 0x060B1D8C ; mov.w r0,@(10,r5)
    c.r[4] += 5; goto L_060B1FD2;  // 060B1FA0 bra 0x060B1FD2 ; add #5,r4
L_060B1FA4:
    c.r[0] = 0x060B1FD8u;  // 060B1FA4 mova 0x060B1FD8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FA6 mov.b @r4+,r1
    c.r[2] = c.r[0];  // 060B1FA8 mov r0,r2
    c.r[0] = 0x30u;  // 060B1FAA mov #48,r0
    c.r[0] &= c.r[1];  // 060B1FAC and r1,r0
    c.r[0] >>= 2;  // 060B1FAE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B1FB0 shlr r0
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B1FB2 mov.l r4,@-r15
    c.pr = 0x060B1FB8u; c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]); SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B1FB8u) return;  // 060B1FB4 bsr 0x060B1D96 ; mov.w @(r0,r2),r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B1FB8 mov.l @r15+,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FBA mov.b @r4+,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FBC mov.b @r4+,r1
    c.r[0] <<= 8;  // 060B1FBE shll8 r0
    c.r[1] = c.r[1] & 0xFFu;  // 060B1FC0 extu.b r1,r1
    c.r[0] |= c.r[1];  // 060B1FC2 or r1,r0
    st16(c.r[5] + 8, c.r[0]);  // 060B1FC4 mov.w r0,@(8,r5)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FC6 mov.b @r4+,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FC8 mov.b @r4+,r1
    c.r[0] <<= 8;  // 060B1FCA shll8 r0
    c.r[1] = c.r[1] & 0xFFu;  // 060B1FCC extu.b r1,r1
    c.r[0] |= c.r[1];  // 060B1FCE or r1,r0
    st16(c.r[5] + 10, c.r[0]);  // 060B1FD0 mov.w r0,@(10,r5)
L_060B1FD2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B1FD2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B1FD4 rts ; mov r4,r0
}

void f_060B1FE0(SH2Context& c) {
    ran[3094] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B1FE0 sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B1FE2 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FE4 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B1FE6 mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B1FE8 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B1FFC; } }  // 060B1FEA bt/s 0x060B1FFC ; mov.b r1,@(r0,r5)
    c.r[0] = 0x6u;  // 060B1FEE mov #6,r0
    st8(c.r[5] + 8, c.r[0]);  // 060B1FF0 mov.b r0,@(8,r5)
    c.r[0] ^= c.r[0];  // 060B1FF2 xor r0,r0
    c.pr = 0x060B1FF8u; st8(c.r[5] + 9, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B1FF8u) return;  // 060B1FF4 bsr 0x060B1D8C ; mov.b r0,@(9,r5)
    c.r[4] += 4; goto L_060B2018;  // 060B1FF8 bra 0x060B2018 ; add #4,r4
L_060B1FFC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FFC mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B1FFE mov.b @r4+,r2
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B2000 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B2002 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B2004 shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B2006 extu.b r2,r4
    c.pr = 0x060B200Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B200Cu) return;  // 060B2008 bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B200C mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B200E mov.l @r15+,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2010 mov.b @r4+,r0
    st8(c.r[5] + 8, c.r[0]);  // 060B2012 mov.b r0,@(8,r5)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2014 mov.b @r4+,r0
    st8(c.r[5] + 9, c.r[0]);  // 060B2016 mov.b r0,@(9,r5)
L_060B2018:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B2018 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B201A rts ; mov r4,r0
}

void f_060B201E(SH2Context& c) {
    ran[3095] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B201E sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B2020 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2022 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B2024 mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B2026 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B2034; } }  // 060B2028 bt/s 0x060B2034 ; mov.b r1,@(r0,r5)
    c.pr = 0x060B2030u; SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B2030u) return;  // 060B202C bsr 0x060B1D8C ; nop
    c.r[4] += 1; goto L_060B2044;  // 060B2030 bra 0x060B2044 ; add #1,r4
L_060B2034:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2034 mov.b @r4+,r1
    c.r[2] = 0xFFFFFFFFu;  // 060B2036 mov #-1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B2038 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B203A shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B203C extu.b r2,r4
    c.pr = 0x060B2042u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B2042u) return;  // 060B203E bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B2042 mov.l @r15+,r4
L_060B2044:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B2044 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B2046 rts ; mov r4,r0
}

void f_060B204A(SH2Context& c) {
    ran[3096] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B204A sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B204C mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B204E mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B2050 mov.b @(r0,r5),r2
    c.t = c.r[1] == c.r[2];  // 060B2052 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { goto L_060B2060; } }  // 060B2054 bt/s 0x060B2060 ; mov.b r1,@(r0,r5)
    c.pr = 0x060B205Cu; SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B205Cu) return;  // 060B2058 bsr 0x060B1D8C ; nop
    c.r[4] += 2; goto L_060B2070;  // 060B205C bra 0x060B2070 ; add #2,r4
L_060B2060:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2060 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2062 mov.b @r4+,r2
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B2064 mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B2066 shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B2068 extu.b r2,r4
    c.pr = 0x060B206Eu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B206Eu) return;  // 060B206A bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B206E mov.l @r15+,r4
L_060B2070:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B2070 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B2072 rts ; mov r4,r0
}

void f_060B2076(SH2Context& c) {
    ran[3097] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B2076 sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060B2078 mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B207A mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060B207C mov.b @(r0,r5),r2
    st8(c.r[0] + c.r[5], c.r[1]);  // 060B207E mov.b r1,@(r0,r5)
    c.r[0] = 0x1u;  // 060B2080 mov #1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2082 mov.b @r4+,r3
    c.r[3] = c.r[3] & 0xFFu;  // 060B2084 extu.b r3,r3
    c.t = c.r[1] == c.r[2];  // 060B2086 cmp/eq r2,r1
    { const bool k = c.t; st8(c.r[0] + c.r[5], c.r[3]); if (k) { goto L_060B2096; } }  // 060B2088 bt/s 0x060B2096 ; mov.b r3,@(r0,r5)
    c.pr = 0x060B2090u; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B2090u) return;  // 060B208C bsr 0x060B1D8C ; mov.l r3,@-r15
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B2090 mov.l @r15+,r1
    c.r[4] += 2; goto L_060B20AA;  // 060B2092 bra 0x060B20AA ; add #2,r4
L_060B2096:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B2096 mov.l r3,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2098 mov.b @r4+,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B209A mov.b @r4+,r2
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B209C mov.l r4,@-r15
    c.r[1] <<= 8;  // 060B209E shll8 r1
    c.r[4] = c.r[2] & 0xFFu;  // 060B20A0 extu.b r2,r4
    c.pr = 0x060B20A6u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, 0x060B1D96u); if (c.pc != 0x060B20A6u) return;  // 060B20A2 bsr 0x060B1D96 ; or r1,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B20A6 mov.l @r15+,r4
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B20A8 mov.l @r15+,r1
L_060B20AA:
    c.r[2] = 0x2u;  // 060B20AA mov #2,r2
    c.t = c.r[1] > c.r[2];  // 060B20AC cmp/hi r2,r1
    if (!c.t) { goto L_060B20C2; }  // 060B20AE bf 0x060B20C2
    c.r[0] = 0x8u;  // 060B20B0 mov #8,r0
    c.r[1] -= 2;  // 060B20B2 add #-2,r1
L_060B20B4:
    c.t = c.r[0] >= c.r[6];  // 060B20B4 cmp/hs r6,r0
    if (c.t) { goto L_060B20C2; }  // 060B20B6 bt 0x060B20C2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B20B8 mov.b @r4+,r2
    st8(c.r[0] + c.r[5], c.r[2]);  // 060B20BA mov.b r2,@(r0,r5)
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B20BC dt r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060B20B4; } }  // 060B20BE bf/s 0x060B20B4 ; add #1,r0
L_060B20C2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B20C2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B20C4 rts ; mov r4,r0
}

void f_060B20C8(SH2Context& c) {
    ran[3098] = 1;
    { sh2_call(c, 0x060B2076u); return; }  // 060B20C8 bra 0x060B2076 ; nop
}

void f_060B20CC(SH2Context& c) {
    ran[3099] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B20CC sts.l pr,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B20CE mov.b @r4+,r0
    st8(c.r[5], c.r[0]);  // 060B20D0 mov.b r0,@(0,r5)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B20D2 mov.b @r4+,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060B20D4 extu.b r0,r0
    st8(c.r[5] + 1, c.r[0]);  // 060B20D6 mov.b r0,@(1,r5)
    c.pr = 0x060B20DCu; c.r[15] -= 4; st32(c.r[15], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B20DCu) return;  // 060B20D8 bsr 0x060B1D8C ; mov.l r0,@-r15
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B20DC mov.l @r15+,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B20DE tst r1,r1
    if (c.t) { goto L_060B20F2; }  // 060B20E0 bt 0x060B20F2
    c.r[0] = 0x8u;  // 060B20E2 mov #8,r0
L_060B20E4:
    c.t = c.r[0] >= c.r[6];  // 060B20E4 cmp/hs r6,r0
    if (c.t) { goto L_060B20F2; }  // 060B20E6 bt 0x060B20F2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B20E8 mov.b @r4+,r2
    st8(c.r[0] + c.r[5], c.r[2]);  // 060B20EA mov.b r2,@(r0,r5)
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B20EC dt r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060B20E4; } }  // 060B20EE bf/s 0x060B20E4 ; add #1,r0
L_060B20F2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B20F2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B20F4 rts ; mov r4,r0
}

void f_060B20F8(SH2Context& c) {
    ran[3100] = 1;
    { sh2_call(c, 0x060B2076u); return; }  // 060B20F8 bra 0x060B2076 ; nop
}

void f_060B20FC(SH2Context& c) {
    ran[3101] = 1;
    { sh2_call(c, 0x060B2076u); return; }  // 060B20FC bra 0x060B2076 ; nop
}

void f_060B2100(SH2Context& c) {
    ran[3102] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B2100 sts.l pr,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2102 mov.b @r4+,r0
    c.pr = 0x060B2108u; st8(c.r[5], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B2108u) return;  // 060B2104 bsr 0x060B1D8C ; mov.b r0,@(0,r5)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B2108 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B210A rts ; mov r4,r0
}

void f_060B210E(SH2Context& c) {
    ran[3103] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B210E sts.l pr,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060B2110 mov.b @r4+,r0
    c.pr = 0x060B2116u; st8(c.r[5], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060B1D8Cu); if (c.pc != 0x060B2116u) return;  // 060B2112 bsr 0x060B1D8C ; mov.b r0,@(0,r5)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B2116 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060B2118 rts ; mov r4,r0
}

void f_060B220C(SH2Context& c) {
    ran[3104] = 1;
    c.r[2] = ld32(0x060B2260u);  // 060B220C mov.l 0x060B2260,r2
    c.r[3] = ld32(0x060B225Cu);  // 060B220E mov.l 0x060B225C,r3
    c.r[0] = ld32(c.r[2]);  // 060B2210 mov.l @r2,r0
    c.r[0] >>= 8;  // 060B2212 shlr8 r0
    st8(c.r[3] + 4, c.r[0]);  // 060B2214 mov.b r0,@(4,r3)
    c.r[0] >>= 8;  // 060B2216 shlr8 r0
    st8(c.r[3] + 2, c.r[0]);  // 060B2218 mov.b r0,@(2,r3)
    c.r[0] >>= 8;  // 060B221A shlr8 r0
    { const uint32_t x = c.pr; st8(c.r[3], c.r[0]); c.pc = x; return; }  // 060B221C rts ; mov.b r0,@(0,r3)
}

void f_060B2220(SH2Context& c) {
    ran[3105] = 1;
    c.r[2] = ld32(0x060B2264u);  // 060B2220 mov.l 0x060B2264,r2
    c.r[3] = ld32(0x060B225Cu);  // 060B2222 mov.l 0x060B225C,r3
    c.r[0] = ld32(c.r[2]);  // 060B2224 mov.l @r2,r0
    st8(c.r[3] + 6, c.r[0]);  // 060B2226 mov.b r0,@(6,r3)
    c.r[0] >>= 8;  // 060B2228 shlr8 r0
    st8(c.r[3] + 4, c.r[0]);  // 060B222A mov.b r0,@(4,r3)
    c.r[0] >>= 8;  // 060B222C shlr8 r0
    st8(c.r[3] + 2, c.r[0]);  // 060B222E mov.b r0,@(2,r3)
    c.r[0] >>= 8;  // 060B2230 shlr8 r0
    { const uint32_t x = c.pr; st8(c.r[3], c.r[0]); c.pc = x; return; }  // 060B2232 rts ; mov.b r0,@(0,r3)
}

void f_060B2236(SH2Context& c) {
    ran[3106] = 1;
    c.r[2] = ld32(0x060B2268u);  // 060B2236 mov.l 0x060B2268,r2
    c.r[3] = ld32(0x060B225Cu);  // 060B2238 mov.l 0x060B225C,r3
    c.r[0] = ld32(c.r[2]); c.r[2] += 4;  // 060B223A mov.l @r2+,r0
    st8(c.r[3] + 6, c.r[0]);  // 060B223C mov.b r0,@(6,r3)
    c.r[0] >>= 8;  // 060B223E shlr8 r0
    st8(c.r[3] + 4, c.r[0]);  // 060B2240 mov.b r0,@(4,r3)
    c.r[0] >>= 8;  // 060B2242 shlr8 r0
    st8(c.r[3] + 2, c.r[0]);  // 060B2244 mov.b r0,@(2,r3)
    c.r[0] >>= 8;  // 060B2246 shlr8 r0
    st8(c.r[3], c.r[0]);  // 060B2248 mov.b r0,@(0,r3)
    c.r[0] = ld32(c.r[2]); c.r[2] += 4;  // 060B224A mov.l @r2+,r0
    c.r[0] >>= 8;  // 060B224C shlr8 r0
    st8(c.r[3] + 12, c.r[0]);  // 060B224E mov.b r0,@(12,r3)
    c.r[0] >>= 8;  // 060B2250 shlr8 r0
    st8(c.r[3] + 10, c.r[0]);  // 060B2252 mov.b r0,@(10,r3)
    c.r[0] >>= 8;  // 060B2254 shlr8 r0
    { const uint32_t x = c.pr; st8(c.r[3] + 8, c.r[0]); c.pc = x; return; }  // 060B2256 rts ; mov.b r0,@(8,r3)
}

void f_060B226C(SH2Context& c) {
    ran[3107] = 1;
    c.r[0] = 0x1u;  // 060B226C mov #1,r0
    st8(c.gbr + 115, c.r[0]);  // 060B226E mov.b r0,@(115,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 170);  // 060B2270 mov.w @(170,gbr),r0
    c.r[0] += 1;  // 060B2272 add #1,r0
    st16(c.gbr + 170, c.r[0]);  // 060B2274 mov.w r0,@(170,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 136);  // 060B2276 mov.w @(136,gbr),r0
    c.r[7] = c.r[0] & 0xFFFFu;  // 060B2278 extu.w r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 116);  // 060B227A mov.w @(116,gbr),r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 060B227C extu.w r0,r0
    c.t = c.r[0] >= c.r[7];  // 060B227E cmp/hs r7,r0
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_060B22A6; } }  // 060B2280 bt/s 0x060B22A6 ; mov r0,r7
    c.r[0] = ld32(c.gbr + 104);  // 060B2284 mov.l @(104,gbr),r0
    c.r[7] += 1;  // 060B2286 add #1,r7
    c.r[3] = c.r[0];  // 060B2288 mov r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 172);  // 060B228A mov.b @(172,gbr),r0
L_060B228C:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B228C dt r0
    { const bool k = !c.t; c.t = c.r[3] & 1; c.r[3] >>= 1; if (k) { SH2_POLL(c); goto L_060B228C; } }  // 060B228E bf/s 0x060B228C ; shlr r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[2];  // 060B2292 cmp/ge r2,r3
    { const bool k = c.t; c.r[2] -= c.r[3]; if (k) { goto L_060B22A6; } }  // 060B2294 bt/s 0x060B22A6 ; sub r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060B2298 mov.w @(112,gbr),r0
    c.r[0] <<= 16;  // 060B229A shll16 r0
    c.t = (int32_t)c.r[2] > (int32_t)c.r[0];  // 060B229C cmp/gt r0,r2
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_060B22A6; } }  // 060B229E bt/s 0x060B22A6 ; mov r7,r0
    { const uint32_t x = c.pr; st16(c.gbr + 116, c.r[0]); c.pc = x; return; }  // 060B22A2 rts ; mov.w r0,@(116,gbr)
L_060B22A6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B22A6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B22A8 rts ; mov #0,r0
}

void f_060B22F4(SH2Context& c) {
    ran[3108] = 1;
    c.r[0] = (c.r[4] & 0xFFFF0000u) | (c.r[4] & 0xFFu) << 8 | (c.r[4] >> 8 & 0xFFu);  // 060B22F4 swap.b r4,r0
    c.r[0] >>= 2;  // 060B22F6 shlr2 r0
    c.r[0] &= 0x38u;  // 060B22F8 and #56,r0
    c.r[2] = c.r[0];  // 060B22FA mov r0,r2
    c.r[0] = 0x060B2388u;  // 060B22FC mova 0x060B2388,r0
    c.r[2] += c.r[0];  // 060B22FE add r0,r2
    c.r[5] = c.r[4];  // 060B2300 mov r4,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B2302 mov.b @r2+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B2304 mov.b @r2+,r0
    c.r[4] ^= c.r[1];  // 060B2306 xor r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B2334u);  // 060B2308 mov.w 0x060B2334,r1
    c.r[5] ^= c.r[0];  // 060B230A xor r0,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B230C mov.b @r2+,r0
    c.r[4] &= c.r[1];  // 060B230E and r1,r4
    c.r[5] &= c.r[1];  // 060B2310 and r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B2312 mov.b @r2+,r1
    c.r[4] += c.r[0];  // 060B2314 add r0,r4
    c.r[0] = 0x060B23C8u;  // 060B2316 mova 0x060B23C8,r0
    c.r[5] += c.r[1];  // 060B2318 add r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 060B231A mov.w @(r0,r4),r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060B231C mov.w @(r0,r5),r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B231E mov.b @r2+,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B2320 mov.b @r2+,r1
    c.r[4] = c.r[4] & 0xFFFFu;  // 060B2322 extu.w r4,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 060B2324 extu.w r5,r5
    c.r[4] ^= c.r[0];  // 060B2326 xor r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B2328 mov.b @r2+,r0
    c.r[5] ^= c.r[1];  // 060B232A xor r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060B232C mov.b @r2+,r1
    c.r[4] += c.r[0];  // 060B232E add r0,r4
    { const uint32_t x = c.pr; c.r[5] += c.r[1]; c.pc = x; return; }  // 060B2330 rts ; add r1,r5
}

void f_060B63CC(SH2Context& c) {
    ran[3109] = 1;
    c.r[0] = c.r[4];  // 060B63CC mov r4,r0
    st32(c.gbr + 524, c.r[0]);  // 060B63CE mov.l r0,@(524,gbr)
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B63D0 sts.l pr,@-r15
    c.pr = 0x060B63D6u; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, 0x060B645Eu); if (c.pc != 0x060B63D6u) return;  // 060B63D2 bsr 0x060B645E ; mov #2,r5
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B63D6 lds.l @r15+,pr
    c.r[3] = 0xBu;  // 060B63D8 mov #11,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 248);  // 060B63DA mov.w @(248,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B645Cu);  // 060B63DC mov.w 0x060B645C,r1
    c.t = (c.r[0] & c.r[1]) == 0;  // 060B63DE tst r1,r0
    if (!c.t) { goto L_060B63E4; }  // 060B63E0 bf 0x060B63E4
    c.r[3] += 1;  // 060B63E2 add #1,r3
L_060B63E4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 234);  // 060B63E4 mov.w @(234,gbr),r0
    c.r[0] >>= 8;  // 060B63E6 shlr8 r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060B63E8 tst #1,r0
    if (!c.t) { goto L_060B63EE; }  // 060B63EA bf 0x060B63EE
    c.r[3] += 2;  // 060B63EC add #2,r3
L_060B63EE:
    c.r[0] = c.r[3];  // 060B63EE mov r3,r0
    c.r[0] += 6;  // 060B63F0 add #6,r0
    c.r[2] = c.r[4];  // 060B63F2 mov r4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060B63F4 tst #16,r0
    if (c.t) { goto L_060B63FA; }  // 060B63F6 bt 0x060B63FA
    c.r[2] >>= 16;  // 060B63F8 shlr16 r2
L_060B63FA:
    c.t = (c.r[0] & 0x8u) == 0;  // 060B63FA tst #8,r0
    if (c.t) { goto L_060B6400; }  // 060B63FC bt 0x060B6400
    c.r[2] >>= 8;  // 060B63FE shlr8 r2
L_060B6400:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B6400 tst #4,r0
    if (c.t) { goto L_060B6408; }  // 060B6402 bt 0x060B6408
    c.r[2] >>= 2;  // 060B6404 shlr2 r2
    c.r[2] >>= 2;  // 060B6406 shlr2 r2
L_060B6408:
    c.t = (c.r[0] & 0x2u) == 0;  // 060B6408 tst #2,r0
    if (c.t) { goto L_060B640E; }  // 060B640A bt 0x060B640E
    c.r[2] >>= 2;  // 060B640C shlr2 r2
L_060B640E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B640E tst #1,r0
    if (c.t) { goto L_060B6414; }  // 060B6410 bt 0x060B6414
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060B6412 shlr r2
L_060B6414:
    c.r[1] = 0x7u;  // 060B6414 mov #7,r1
    c.r[2] &= c.r[1];  // 060B6416 and r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 255);  // 060B6418 mov.b @(255,gbr),r0
    c.r[0] &= 0xF0u;  // 060B641A and #240,r0
    c.r[0] |= c.r[2];  // 060B641C or r2,r0
    st8(c.gbr + 255, c.r[0]);  // 060B641E mov.b r0,@(255,gbr)
    c.r[0] = c.r[3];  // 060B6420 mov r3,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B6422 tst #16,r0
    if (c.t) { goto L_060B6428; }  // 060B6424 bt 0x060B6428
    c.r[4] >>= 16;  // 060B6426 shlr16 r4
L_060B6428:
    c.t = (c.r[0] & 0x8u) == 0;  // 060B6428 tst #8,r0
    if (c.t) { goto L_060B642E; }  // 060B642A bt 0x060B642E
    c.r[4] >>= 8;  // 060B642C shlr8 r4
L_060B642E:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B642E tst #4,r0
    if (c.t) { goto L_060B6436; }  // 060B6430 bt 0x060B6436
    c.r[4] >>= 2;  // 060B6432 shlr2 r4
    c.r[4] >>= 2;  // 060B6434 shlr2 r4
L_060B6436:
    c.t = (c.r[0] & 0x2u) == 0;  // 060B6436 tst #2,r0
    if (c.t) { goto L_060B643C; }  // 060B6438 bt 0x060B643C
    c.r[4] >>= 2;  // 060B643A shlr2 r4
L_060B643C:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B643C tst #1,r0
    if (c.t) { goto L_060B6442; }  // 060B643E bt 0x060B6442
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B6440 shlr r4
L_060B6442:
    c.r[1] = 0x3Fu;  // 060B6442 mov #63,r1
    c.r[4] &= c.r[1];  // 060B6444 and r1,r4
    c.r[0] = (c.r[4] & 0xFFFF0000u) | (c.r[4] & 0xFFu) << 8 | (c.r[4] >> 8 & 0xFFu);  // 060B6446 swap.b r4,r0
    c.r[0] |= c.r[4];  // 060B6448 or r4,r0
    st16(c.gbr + 272, c.r[0]);  // 060B644A mov.w r0,@(272,gbr)
    st16(c.gbr + 274, c.r[0]);  // 060B644C mov.w r0,@(274,gbr)
    st16(c.gbr + 276, c.r[0]);  // 060B644E mov.w r0,@(276,gbr)
    st16(c.gbr + 278, c.r[0]);  // 060B6450 mov.w r0,@(278,gbr)
    st16(c.gbr + 280, c.r[0]);  // 060B6452 mov.w r0,@(280,gbr)
    st16(c.gbr + 282, c.r[0]);  // 060B6454 mov.w r0,@(282,gbr)
    st16(c.gbr + 284, c.r[0]);  // 060B6456 mov.w r0,@(284,gbr)
    { const uint32_t x = c.pr; st16(c.gbr + 286, c.r[0]); c.pc = x; return; }  // 060B6458 rts ; mov.w r0,@(286,gbr)
}

void f_060B645E(SH2Context& c) {
    ran[3110] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060B645E mov.w @(206,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B6460 mov.l r5,@-r15
    c.r[2] = 0x3u;  // 060B6462 mov #3,r2
    c.r[3] = 0x4u;  // 060B6464 mov #4,r3
    c.r[1] = c.r[0];  // 060B6466 mov r0,r1
L_060B6468:
    c.r[0] = c.r[1];  // 060B6468 mov r1,r0
    c.r[0] &= c.r[2];  // 060B646A and r2,r0
    c.t = c.r[0] == c.r[5];  // 060B646C cmp/eq r5,r0
    if (!c.t) { goto L_060B6474; }  // 060B646E bf 0x060B6474
    c.r[0] = ~c.r[2];  // 060B6470 not r2,r0
    c.r[1] &= c.r[0];  // 060B6472 and r0,r1
L_060B6474:
    c.r[2] <<= 2;  // 060B6474 shll2 r2
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060B6476 dt r3
    { const bool k = !c.t; c.r[5] <<= 2; if (k) { SH2_POLL(c); goto L_060B6468; } }  // 060B6478 bf/s 0x060B6468 ; shll2 r5
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060B647C mov.l @r15+,r5
    c.r[2] = 0x3u;  // 060B647E mov #3,r2
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060B6480 swap.w r4,r0
    c.t = (c.r[0] & 0x4u) == 0;  // 060B6482 tst #4,r0
    if (c.t) { goto L_060B648E; }  // 060B6484 bt 0x060B648E
    c.r[2] <<= 2;  // 060B6486 shll2 r2
    c.r[2] <<= 2;  // 060B6488 shll2 r2
    c.r[5] <<= 2;  // 060B648A shll2 r5
    c.r[5] <<= 2;  // 060B648C shll2 r5
L_060B648E:
    c.t = (c.r[0] & 0x2u) == 0;  // 060B648E tst #2,r0
    if (c.t) { goto L_060B6496; }  // 060B6490 bt 0x060B6496
    c.r[2] <<= 2;  // 060B6492 shll2 r2
    c.r[5] <<= 2;  // 060B6494 shll2 r5
L_060B6496:
    c.r[0] = ~c.r[2];  // 060B6496 not r2,r0
    c.r[0] &= c.r[1];  // 060B6498 and r1,r0
    c.r[0] |= c.r[5];  // 060B649A or r5,r0
    { const uint32_t x = c.pr; st16(c.gbr + 206, c.r[0]); c.pc = x; return; }  // 060B649C rts ; mov.w r0,@(206,gbr)
}

void f_060B6528(SH2Context& c) {
    ran[3111] = 1;
    goto L_060B6528;
L_060B64A0:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[4]);  // 060B64A0 mov.w @r4,r6
L_060B64A2:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 152);  // 060B64A2 mov.w @(152,gbr),r0
L_060B64A4:
    c.r[1] = c.r[6];  // 060B64A4 mov r6,r1
L_060B64A6:
    c.r[1] += c.r[0];  // 060B64A6 add r0,r1
L_060B64A8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B64A8 mov.w @(140,gbr),r0
L_060B64AA:
    c.r[4] = ld32(c.r[4] + 4);  // 060B64AA mov.l @(4,r4),r4
L_060B64AC:
    c.t = c.r[1] > c.r[0];  // 060B64AC cmp/hi r0,r1
L_060B64AE:
    { const bool k = c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 154); if (k) { goto L_060B6524; } }  // 060B64AE bt/s 0x060B6524 ; mov.w @(154,gbr),r0
L_060B64B2:
    c.r[1] = c.r[4];  // 060B64B2 mov r4,r1
L_060B64B4:
    c.r[0] <<= 16;  // 060B64B4 shll16 r0
L_060B64B6:
    c.r[1] += c.r[0];  // 060B64B6 add r0,r1
L_060B64B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B64B8 mov.w @(142,gbr),r0
L_060B64BA:
    c.r[0] <<= 16;  // 060B64BA shll16 r0
L_060B64BC:
    c.t = c.r[1] > c.r[0];  // 060B64BC cmp/hi r0,r1
L_060B64BE:
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_060B6524; } }  // 060B64BE bt/s 0x060B6524 ; mov #3,r0
L_060B64C2:
    c.r[5] ^= c.r[0];  // 060B64C2 xor r0,r5
L_060B64C4:
    c.t = (int32_t)c.r[2] >= 0;  // 060B64C4 cmp/pz r2
L_060B64C6:
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060B64D0; } }  // 060B64C6 bt/s 0x060B64D0 ; mov #1,r1
L_060B64CA:
    c.r[2] = 0u - c.r[2];  // 060B64CA neg r2,r2
L_060B64CC:
    c.r[0] = 0x10u;  // 060B64CC mov #16,r0
L_060B64CE:
    c.r[5] ^= c.r[0];  // 060B64CE xor r0,r5
L_060B64D0:
    c.t = (int32_t)c.r[3] >= 0;  // 060B64D0 cmp/pz r3
L_060B64D2:
    { const bool k = c.t; c.r[1] <<= 16; if (k) { goto L_060B64DC; } }  // 060B64D2 bt/s 0x060B64DC ; shll16 r1
L_060B64D6:
    c.r[3] = 0u - c.r[3];  // 060B64D6 neg r3,r3
L_060B64D8:
    c.r[0] = 0x20u;  // 060B64D8 mov #32,r0
L_060B64DA:
    c.r[5] ^= c.r[0];  // 060B64DA xor r0,r5
L_060B64DC:
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060B64DC cmp/ge r1,r2
L_060B64DE:
    { const bool k = c.t; c.r[2] -= c.r[1]; if (k) { goto L_060B64E4; } }  // 060B64DE bt/s 0x060B64E4 ; sub r1,r2
L_060B64E2:
    c.r[2] = 0x0u;  // 060B64E2 mov #0,r2
L_060B64E4:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060B64E4 cmp/ge r1,r3
L_060B64E6:
    { const bool k = c.t; c.r[3] -= c.r[1]; if (k) { goto L_060B64EC; } }  // 060B64E6 bt/s 0x060B64EC ; sub r1,r3
L_060B64EA:
    c.r[3] = 0x0u;  // 060B64EA mov #0,r3
L_060B64EC:
    c.r[2] = c.r[2] << 16 | c.r[2] >> 16;  // 060B64EC swap.w r2,r2
L_060B64EE:
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B64EE xtrct r2,r3
L_060B64F0:
    st32(c.r[7] + 16, c.r[3]);  // 060B64F0 mov.l r3,@(16,r7)
L_060B64F2:
    c.r[0] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B64F2 swap.b r5,r0
L_060B64F4:
    c.t = (c.r[0] & 0xFu) == 0;  // 060B64F4 tst #15,r0
L_060B64F6:
    if (!c.t) { goto L_060B64FA; }  // 060B64F6 bf 0x060B64FA
L_060B64F8:
    c.r[0] |= 0xAu;  // 060B64F8 or #10,r0
L_060B64FA:
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B64FA swap.b r0,r0
L_060B64FC:
    st16(c.r[7], c.r[0]);  // 060B64FC mov.w r0,@(0,r7)
L_060B64FE:
    c.r[4] = c.r[6] << 16 | c.r[4] >> 16;  // 060B64FE xtrct r6,r4
L_060B6500:
    st32(c.r[7] + 12, c.r[4]);  // 060B6500 mov.l r4,@(12,r7)
L_060B6502:
    c.r[0] = ld32(c.gbr + 72);  // 060B6502 mov.l @(72,gbr),r0
L_060B6504:
    c.r[1] = 0x28u;  // 060B6504 mov #40,r1
L_060B6506:
    st32(c.r[0], c.r[1]);  // 060B6506 mov.l r1,@(0,r0)
L_060B6508:
    st32(c.r[0] + 4, c.r[7]);  // 060B6508 mov.l r7,@(4,r0)
L_060B650A:
    c.r[1] = 0x1u;  // 060B650A mov #1,r1
L_060B650C:
    st32(c.r[0] + 8, c.r[1]);  // 060B650C mov.l r1,@(8,r0)
L_060B650E:
    c.r[1] = 0x0u;  // 060B650E mov #0,r1
L_060B6510:
    st32(c.r[0] + 12, c.r[1]);  // 060B6510 mov.l r1,@(12,r0)
L_060B6512:
    c.r[0] += 16;  // 060B6512 add #16,r0
L_060B6514:
    c.r[1] = ld32(0x060B6704u);  // 060B6514 mov.l 0x060B6704,r1
L_060B6516:
    st32(c.gbr + 72, c.r[0]);  // 060B6516 mov.l r0,@(72,gbr)
L_060B6518:
    st16(c.r[1], c.r[0]);  // 060B6518 mov.w r0,@r1
L_060B651A:
    c.r[7] -= 36;  // 060B651A add #-36,r7
L_060B651C:
    c.r[0] = c.r[7];  // 060B651C mov r7,r0
L_060B651E:
    st32(c.gbr + 48, c.r[0]);  // 060B651E mov.l r0,@(48,gbr)
L_060B6520:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B6520 rts ; mov #1,r0
L_060B6524:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6524 rts ; mov #0,r0
L_060B6528:
    c.t = (c.r[6] & c.r[6]) == 0;  // 060B6528 tst r6,r6
L_060B652A:
    { const bool k = c.t; c.r[0] = (c.r[6] & 0xFFFF0000u) | (c.r[6] & 0xFFu) << 8 | (c.r[6] >> 8 & 0xFFu); if (k) { SH2_POLL(c); goto L_060B64A0; } }  // 060B652A bt/s 0x060B64A0 ; swap.b r6,r0
L_060B652E:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060B652E mov.l r14,@-r15
L_060B6530:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060B6530 mov.l r13,@-r15
L_060B6532:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060B6532 mov.l r12,@-r15
L_060B6534:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060B6534 mov.l r11,@-r15
L_060B6536:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060B6536 mov.l r10,@-r15
L_060B6538:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B6538 mov.l r9,@-r15
L_060B653A:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060B653A mov.l r8,@-r15
L_060B653C:
    c.r[0] >>= 2;  // 060B653C shlr2 r0
L_060B653E:
    c.r[0] >>= 2;  // 060B653E shlr2 r0
L_060B6540:
    c.r[8] = 0xCu;  // 060B6540 mov #12,r8
L_060B6542:
    c.r[8] &= c.r[0];  // 060B6542 and r0,r8
L_060B6544:
    c.r[0] = 0x060B66F4u;  // 060B6544 mova 0x060B66F4,r0
L_060B6546:
    c.r[8] += c.r[0];  // 060B6546 add r0,r8
L_060B6548:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060B6548 mov.b @r8+,r1
L_060B654A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060B654A mov.b @r8+,r0
L_060B654C:
    c.r[13] = c.r[6];  // 060B654C mov r6,r13
L_060B654E:
    c.r[6] ^= c.r[1];  // 060B654E xor r1,r6
L_060B6550:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B66ECu);  // 060B6550 mov.w 0x060B66EC,r1
L_060B6552:
    c.r[13] ^= c.r[0];  // 060B6552 xor r0,r13
L_060B6554:
    c.r[0] = ld32(0x060B66F0u);  // 060B6554 mov.l 0x060B66F0,r0
L_060B6556:
    c.r[6] &= c.r[1];  // 060B6556 and r1,r6
L_060B6558:
    c.r[13] &= c.r[1];  // 060B6558 and r1,r13
L_060B655A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060B655A mov.b @r8+,r1
L_060B655C:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 060B655C mov.w @(r0,r6),r6
L_060B655E:
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 060B655E mov.w @(r0,r13),r13
L_060B6560:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060B6560 mov.b @r8,r0
L_060B6562:
    c.r[6] = c.r[6] & 0xFFFFu;  // 060B6562 extu.w r6,r6
L_060B6564:
    c.r[6] += 2;  // 060B6564 add #2,r6
L_060B6566:
    c.r[6] ^= c.r[1];  // 060B6566 xor r1,r6
L_060B6568:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[6] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6568 dmuls.l r2,r6
L_060B656A:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B656A extu.w r13,r13
L_060B656C:
    c.r[13] += 2;  // 060B656C add #2,r13
L_060B656E:
    c.r[13] ^= c.r[0];  // 060B656E xor r0,r13
L_060B6570:
    c.r[1] = c.mach;  // 060B6570 sts mach,r1
L_060B6572:
    c.r[8] = c.macl;  // 060B6572 sts macl,r8
L_060B6574:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[6] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6574 dmuls.l r3,r6
L_060B6576:
    c.r[0] = ld32(c.gbr + 152);  // 060B6576 mov.l @(152,gbr),r0
L_060B6578:
    c.r[8] = c.r[1] << 16 | c.r[8] >> 16;  // 060B6578 xtrct r1,r8
L_060B657A:
    c.r[11] = c.r[0];  // 060B657A mov r0,r11
L_060B657C:
    c.r[11] <<= 16;  // 060B657C shll16 r11
L_060B657E:
    c.r[1] = c.mach;  // 060B657E sts mach,r1
L_060B6580:
    c.r[9] = c.macl;  // 060B6580 sts macl,r9
L_060B6582:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[13] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6582 dmuls.l r2,r13
L_060B6584:
    c.r[9] = c.r[1] << 16 | c.r[9] >> 16;  // 060B6584 xtrct r1,r9
L_060B6586:
    c.r[10] = c.r[0] << 16 | c.r[0] >> 16;  // 060B6586 swap.w r0,r10
L_060B6588:
    c.r[10] <<= 16;  // 060B6588 shll16 r10
L_060B658A:
    c.r[1] = c.mach;  // 060B658A sts mach,r1
L_060B658C:
    c.r[2] = c.macl;  // 060B658C sts macl,r2
L_060B658E:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[13] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B658E dmuls.l r3,r13
L_060B6590:
    c.r[0] = ld32(c.gbr + 140);  // 060B6590 mov.l @(140,gbr),r0
L_060B6592:
    c.r[2] = c.r[1] << 16 | c.r[2] >> 16;  // 060B6592 xtrct r1,r2
L_060B6594:
    c.r[13] = c.r[0];  // 060B6594 mov r0,r13
L_060B6596:
    c.r[13] <<= 16;  // 060B6596 shll16 r13
L_060B6598:
    c.r[1] = c.mach;  // 060B6598 sts mach,r1
L_060B659A:
    c.r[3] = c.macl;  // 060B659A sts macl,r3
L_060B659C:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B659C swap.w r0,r12
L_060B659E:
    c.r[12] <<= 16;  // 060B659E shll16 r12
L_060B65A0:
    c.r[0] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B65A0 swap.b r5,r0
L_060B65A2:
    c.r[3] = c.r[1] << 16 | c.r[3] >> 16;  // 060B65A2 xtrct r1,r3
L_060B65A4:
    c.r[0] &= 0xFu;  // 060B65A4 and #15,r0
L_060B65A6:
    c.r[0] <<= 2;  // 060B65A6 shll2 r0
L_060B65A8:
    c.r[1] = c.r[0];  // 060B65A8 mov r0,r1
L_060B65AA:
    c.r[0] = 0x060B6708u;  // 060B65AA mova 0x060B6708,r0
L_060B65AC:
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060B65AC mov.l @(r0,r1),r1
L_060B65AE:
    c.r[6] = ld32(c.r[4] + 4);  // 060B65AE mov.l @(4,r4),r6
L_060B65B0:
    { const uint32_t x = c.r[1]; c.r[4] = ld32(c.r[4]); switch (x) { case 0x060B6748u: goto L_060B6748; case 0x060B67E2u: goto L_060B67E2; case 0x060B68D0u: goto L_060B68D0; case 0x060B67DAu: goto L_060B67DA; case 0x060B685Cu: goto L_060B685C; case 0x060B6752u: goto L_060B6752; case 0x060B6854u: goto L_060B6854; case 0x060B67CAu: goto L_060B67CA; case 0x060B68C8u: goto L_060B68C8; case 0x060B67D2u: goto L_060B67D2; default: sh2_call(c, x); return; } }  // 060B65B0 jmp @r1 ; mov.l @(0,r4),r4
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B64A0u: goto L_060B64A0; case 0x060B64A2u: goto L_060B64A2; case 0x060B64A4u: goto L_060B64A4; case 0x060B64A6u: goto L_060B64A6; case 0x060B64A8u: goto L_060B64A8; case 0x060B64AAu: goto L_060B64AA; case 0x060B64ACu: goto L_060B64AC; case 0x060B64AEu: goto L_060B64AE; case 0x060B64B2u: goto L_060B64B2; case 0x060B64B4u: goto L_060B64B4; case 0x060B64B6u: goto L_060B64B6; case 0x060B64B8u: goto L_060B64B8; case 0x060B64BAu: goto L_060B64BA; case 0x060B64BCu: goto L_060B64BC; case 0x060B64BEu: goto L_060B64BE; case 0x060B64C2u: goto L_060B64C2; case 0x060B64C4u: goto L_060B64C4; case 0x060B64C6u: goto L_060B64C6; case 0x060B64CAu: goto L_060B64CA; case 0x060B64CCu: goto L_060B64CC; case 0x060B64CEu: goto L_060B64CE; case 0x060B64D0u: goto L_060B64D0; case 0x060B64D2u: goto L_060B64D2; case 0x060B64D6u: goto L_060B64D6; case 0x060B64D8u: goto L_060B64D8; case 0x060B64DAu: goto L_060B64DA; case 0x060B64DCu: goto L_060B64DC; case 0x060B64DEu: goto L_060B64DE; case 0x060B64E2u: goto L_060B64E2; case 0x060B64E4u: goto L_060B64E4; case 0x060B64E6u: goto L_060B64E6; case 0x060B64EAu: goto L_060B64EA; case 0x060B64ECu: goto L_060B64EC; case 0x060B64EEu: goto L_060B64EE; case 0x060B64F0u: goto L_060B64F0; case 0x060B64F2u: goto L_060B64F2; case 0x060B64F4u: goto L_060B64F4; case 0x060B64F6u: goto L_060B64F6; case 0x060B64F8u: goto L_060B64F8; case 0x060B64FAu: goto L_060B64FA; case 0x060B64FCu: goto L_060B64FC; case 0x060B64FEu: goto L_060B64FE; case 0x060B6500u: goto L_060B6500; case 0x060B6502u: goto L_060B6502; case 0x060B6504u: goto L_060B6504; case 0x060B6506u: goto L_060B6506; case 0x060B6508u: goto L_060B6508; case 0x060B650Au: goto L_060B650A; case 0x060B650Cu: goto L_060B650C; case 0x060B650Eu: goto L_060B650E; case 0x060B6510u: goto L_060B6510; case 0x060B6512u: goto L_060B6512; case 0x060B6514u: goto L_060B6514; case 0x060B6516u: goto L_060B6516; case 0x060B6518u: goto L_060B6518; case 0x060B651Au: goto L_060B651A; case 0x060B651Cu: goto L_060B651C; case 0x060B651Eu: goto L_060B651E; case 0x060B6520u: goto L_060B6520; case 0x060B6524u: goto L_060B6524; case 0x060B6528u: goto L_060B6528; case 0x060B652Au: goto L_060B652A; case 0x060B652Eu: goto L_060B652E; case 0x060B6530u: goto L_060B6530; case 0x060B6532u: goto L_060B6532; case 0x060B6534u: goto L_060B6534; case 0x060B6536u: goto L_060B6536; case 0x060B6538u: goto L_060B6538; case 0x060B653Au: goto L_060B653A; case 0x060B653Cu: goto L_060B653C; case 0x060B653Eu: goto L_060B653E; case 0x060B6540u: goto L_060B6540; case 0x060B6542u: goto L_060B6542; case 0x060B6544u: goto L_060B6544; case 0x060B6546u: goto L_060B6546; case 0x060B6548u: goto L_060B6548; case 0x060B654Au: goto L_060B654A; case 0x060B654Cu: goto L_060B654C; case 0x060B654Eu: goto L_060B654E; case 0x060B6550u: goto L_060B6550; case 0x060B6552u: goto L_060B6552; case 0x060B6554u: goto L_060B6554; case 0x060B6556u: goto L_060B6556; case 0x060B6558u: goto L_060B6558; case 0x060B655Au: goto L_060B655A; case 0x060B655Cu: goto L_060B655C; case 0x060B655Eu: goto L_060B655E; case 0x060B6560u: goto L_060B6560; case 0x060B6562u: goto L_060B6562; case 0x060B6564u: goto L_060B6564; case 0x060B6566u: goto L_060B6566; case 0x060B6568u: goto L_060B6568; case 0x060B656Au: goto L_060B656A; case 0x060B656Cu: goto L_060B656C; case 0x060B656Eu: goto L_060B656E; case 0x060B6570u: goto L_060B6570; case 0x060B6572u: goto L_060B6572; case 0x060B6574u: goto L_060B6574; case 0x060B6576u: goto L_060B6576; case 0x060B6578u: goto L_060B6578; case 0x060B657Au: goto L_060B657A; case 0x060B657Cu: goto L_060B657C; case 0x060B657Eu: goto L_060B657E; case 0x060B6580u: goto L_060B6580; case 0x060B6582u: goto L_060B6582; case 0x060B6584u: goto L_060B6584; case 0x060B6586u: goto L_060B6586; case 0x060B6588u: goto L_060B6588; case 0x060B658Au: goto L_060B658A; case 0x060B658Cu: goto L_060B658C; case 0x060B658Eu: goto L_060B658E; case 0x060B6590u: goto L_060B6590; case 0x060B6592u: goto L_060B6592; case 0x060B6594u: goto L_060B6594; case 0x060B6596u: goto L_060B6596; case 0x060B6598u: goto L_060B6598; case 0x060B659Au: goto L_060B659A; case 0x060B659Cu: goto L_060B659C; case 0x060B659Eu: goto L_060B659E; case 0x060B65A0u: goto L_060B65A0; case 0x060B65A2u: goto L_060B65A2; case 0x060B65A4u: goto L_060B65A4; case 0x060B65A6u: goto L_060B65A6; case 0x060B65A8u: goto L_060B65A8; case 0x060B65AAu: goto L_060B65AA; case 0x060B65ACu: goto L_060B65AC; case 0x060B65AEu: goto L_060B65AE; case 0x060B65B0u: goto L_060B65B0; case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B6748u: goto L_060B6748; case 0x060B674Au: goto L_060B674A; case 0x060B674Cu: goto L_060B674C; case 0x060B674Eu: goto L_060B674E; case 0x060B6750u: goto L_060B6750; case 0x060B6752u: goto L_060B6752; case 0x060B6754u: goto L_060B6754; case 0x060B6756u: goto L_060B6756; case 0x060B6758u: goto L_060B6758; case 0x060B675Au: goto L_060B675A; case 0x060B675Cu: goto L_060B675C; case 0x060B675Eu: goto L_060B675E; case 0x060B6760u: goto L_060B6760; case 0x060B6762u: goto L_060B6762; case 0x060B6764u: goto L_060B6764; case 0x060B6768u: goto L_060B6768; case 0x060B676Au: goto L_060B676A; case 0x060B676Cu: goto L_060B676C; case 0x060B676Eu: goto L_060B676E; case 0x060B6770u: goto L_060B6770; case 0x060B6772u: goto L_060B6772; case 0x060B6774u: goto L_060B6774; case 0x060B6776u: goto L_060B6776; case 0x060B6778u: goto L_060B6778; case 0x060B677Cu: goto L_060B677C; case 0x060B677Eu: goto L_060B677E; case 0x060B6780u: goto L_060B6780; case 0x060B6782u: goto L_060B6782; case 0x060B6784u: goto L_060B6784; case 0x060B6788u: goto L_060B6788; case 0x060B678Au: goto L_060B678A; case 0x060B678Cu: goto L_060B678C; case 0x060B678Eu: goto L_060B678E; case 0x060B6790u: goto L_060B6790; case 0x060B6792u: goto L_060B6792; case 0x060B6796u: goto L_060B6796; case 0x060B6798u: goto L_060B6798; case 0x060B679Au: goto L_060B679A; case 0x060B679Cu: goto L_060B679C; case 0x060B679Eu: goto L_060B679E; case 0x060B67A0u: goto L_060B67A0; case 0x060B67A2u: goto L_060B67A2; case 0x060B67A4u: goto L_060B67A4; case 0x060B67A8u: goto L_060B67A8; case 0x060B67AAu: goto L_060B67AA; case 0x060B67ACu: goto L_060B67AC; case 0x060B67AEu: goto L_060B67AE; case 0x060B67B2u: goto L_060B67B2; case 0x060B67B4u: goto L_060B67B4; case 0x060B67B6u: goto L_060B67B6; case 0x060B67B8u: goto L_060B67B8; case 0x060B67BCu: goto L_060B67BC; case 0x060B67BEu: goto L_060B67BE; case 0x060B67C0u: goto L_060B67C0; case 0x060B67C2u: goto L_060B67C2; case 0x060B67C6u: goto L_060B67C6; case 0x060B67CAu: goto L_060B67CA; case 0x060B67CCu: goto L_060B67CC; case 0x060B67CEu: goto L_060B67CE; case 0x060B67D2u: goto L_060B67D2; case 0x060B67D4u: goto L_060B67D4; case 0x060B67D6u: goto L_060B67D6; case 0x060B67DAu: goto L_060B67DA; case 0x060B67DCu: goto L_060B67DC; case 0x060B67DEu: goto L_060B67DE; case 0x060B67E0u: goto L_060B67E0; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; case 0x060B6854u: goto L_060B6854; case 0x060B6856u: goto L_060B6856; case 0x060B6858u: goto L_060B6858; case 0x060B685Au: goto L_060B685A; case 0x060B685Cu: goto L_060B685C; case 0x060B685Eu: goto L_060B685E; case 0x060B6860u: goto L_060B6860; case 0x060B6862u: goto L_060B6862; case 0x060B6864u: goto L_060B6864; case 0x060B6866u: goto L_060B6866; case 0x060B6868u: goto L_060B6868; case 0x060B686Cu: goto L_060B686C; case 0x060B686Eu: goto L_060B686E; case 0x060B6870u: goto L_060B6870; case 0x060B6872u: goto L_060B6872; case 0x060B6874u: goto L_060B6874; case 0x060B6876u: goto L_060B6876; case 0x060B687Au: goto L_060B687A; case 0x060B687Cu: goto L_060B687C; case 0x060B687Eu: goto L_060B687E; case 0x060B6880u: goto L_060B6880; case 0x060B6882u: goto L_060B6882; case 0x060B6886u: goto L_060B6886; case 0x060B6888u: goto L_060B6888; case 0x060B688Au: goto L_060B688A; case 0x060B688Cu: goto L_060B688C; case 0x060B688Eu: goto L_060B688E; case 0x060B6890u: goto L_060B6890; case 0x060B6894u: goto L_060B6894; case 0x060B6896u: goto L_060B6896; case 0x060B6898u: goto L_060B6898; case 0x060B689Au: goto L_060B689A; case 0x060B689Cu: goto L_060B689C; case 0x060B689Eu: goto L_060B689E; case 0x060B68A0u: goto L_060B68A0; case 0x060B68A2u: goto L_060B68A2; case 0x060B68A6u: goto L_060B68A6; case 0x060B68A8u: goto L_060B68A8; case 0x060B68AAu: goto L_060B68AA; case 0x060B68ACu: goto L_060B68AC; case 0x060B68B0u: goto L_060B68B0; case 0x060B68B2u: goto L_060B68B2; case 0x060B68B4u: goto L_060B68B4; case 0x060B68B6u: goto L_060B68B6; case 0x060B68BAu: goto L_060B68BA; case 0x060B68BCu: goto L_060B68BC; case 0x060B68BEu: goto L_060B68BE; case 0x060B68C0u: goto L_060B68C0; case 0x060B68C4u: goto L_060B68C4; case 0x060B68C8u: goto L_060B68C8; case 0x060B68CAu: goto L_060B68CA; case 0x060B68CCu: goto L_060B68CC; case 0x060B68CEu: goto L_060B68CE; case 0x060B68D0u: goto L_060B68D0; case 0x060B68D2u: goto L_060B68D2; case 0x060B68D4u: goto L_060B68D4; case 0x060B68D6u: goto L_060B68D6; case 0x060B68D8u: goto L_060B68D8; case 0x060B68DAu: goto L_060B68DA; case 0x060B68DCu: goto L_060B68DC; case 0x060B68E0u: goto L_060B68E0; case 0x060B68E2u: goto L_060B68E2; case 0x060B68E4u: goto L_060B68E4; case 0x060B68E6u: goto L_060B68E6; case 0x060B68E8u: goto L_060B68E8; case 0x060B68EAu: goto L_060B68EA; case 0x060B68EEu: goto L_060B68EE; case 0x060B68F0u: goto L_060B68F0; case 0x060B68F2u: goto L_060B68F2; case 0x060B68F4u: goto L_060B68F4; case 0x060B68F6u: goto L_060B68F6; case 0x060B68FAu: goto L_060B68FA; case 0x060B68FCu: goto L_060B68FC; case 0x060B68FEu: goto L_060B68FE; case 0x060B6900u: goto L_060B6900; case 0x060B6902u: goto L_060B6902; case 0x060B6904u: goto L_060B6904; case 0x060B6908u: goto L_060B6908; case 0x060B690Au: goto L_060B690A; case 0x060B690Cu: goto L_060B690C; case 0x060B690Eu: goto L_060B690E; case 0x060B6910u: goto L_060B6910; case 0x060B6912u: goto L_060B6912; case 0x060B6914u: goto L_060B6914; case 0x060B6916u: goto L_060B6916; case 0x060B691Au: goto L_060B691A; case 0x060B691Cu: goto L_060B691C; case 0x060B691Eu: goto L_060B691E; case 0x060B6920u: goto L_060B6920; case 0x060B6924u: goto L_060B6924; case 0x060B6926u: goto L_060B6926; case 0x060B6928u: goto L_060B6928; case 0x060B692Au: goto L_060B692A; case 0x060B692Eu: goto L_060B692E; case 0x060B6930u: goto L_060B6930; case 0x060B6932u: goto L_060B6932; case 0x060B6934u: goto L_060B6934; case 0x060B6938u: goto L_060B6938; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B6748:
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B6748 swap.b r5,r5
L_060B674A:
    c.r[0] = 0xFFFFFFF0u;  // 060B674A mov #-16,r0
L_060B674C:
    c.r[0] &= c.r[5];  // 060B674C and r5,r0
L_060B674E:
    c.r[0] |= 0xAu;  // 060B674E or #10,r0
L_060B6750:
    c.r[5] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B6750 swap.b r0,r5
L_060B6752:
    c.r[0] = c.r[2];  // 060B6752 mov r2,r0
L_060B6754:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6754 shar r0
L_060B6756:
    c.r[4] -= c.r[0];  // 060B6756 sub r0,r4
L_060B6758:
    c.r[0] = c.r[9];  // 060B6758 mov r9,r0
L_060B675A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B675A shar r0
L_060B675C:
    c.r[4] += c.r[0];  // 060B675C add r0,r4
L_060B675E:
    c.r[0] = c.r[4];  // 060B675E mov r4,r0
L_060B6760:
    c.r[0] += c.r[10];  // 060B6760 add r10,r0
L_060B6762:
    c.t = c.r[0] > c.r[12];  // 060B6762 cmp/hi r12,r0
L_060B6764:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B6842; } }  // 060B6764 bt/s 0x060B6842 ; mov r3,r0
L_060B6768:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6768 shar r0
L_060B676A:
    c.r[6] -= c.r[0];  // 060B676A sub r0,r6
L_060B676C:
    c.r[0] = c.r[8];  // 060B676C mov r8,r0
L_060B676E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B676E shar r0
L_060B6770:
    c.r[6] -= c.r[0];  // 060B6770 sub r0,r6
L_060B6772:
    c.r[0] = c.r[6];  // 060B6772 mov r6,r0
L_060B6774:
    c.r[0] += c.r[11];  // 060B6774 add r11,r0
L_060B6776:
    c.t = c.r[0] > c.r[13];  // 060B6776 cmp/hi r13,r0
L_060B6778:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6778 bt/s 0x060B6842 ; swap.w r4,r1
L_060B677C:
    c.r[4] += c.r[2];  // 060B677C add r2,r4
L_060B677E:
    c.r[0] = c.r[4];  // 060B677E mov r4,r0
L_060B6780:
    c.r[0] += c.r[10];  // 060B6780 add r10,r0
L_060B6782:
    c.t = c.r[0] > c.r[12];  // 060B6782 cmp/hi r12,r0
L_060B6784:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B6784 bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6788:
    c.r[5] = c.r[6];  // 060B6788 mov r6,r5
L_060B678A:
    c.r[6] += c.r[8];  // 060B678A add r8,r6
L_060B678C:
    c.r[0] = c.r[6];  // 060B678C mov r6,r0
L_060B678E:
    c.r[0] += c.r[11];  // 060B678E add r11,r0
L_060B6790:
    c.t = c.r[0] > c.r[13];  // 060B6790 cmp/hi r13,r0
L_060B6792:
    { const bool k = c.t; c.r[5] = c.r[1] << 16 | c.r[5] >> 16; if (k) { goto L_060B6842; } }  // 060B6792 bt/s 0x060B6842 ; xtrct r1,r5
L_060B6796:
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060B6796 swap.w r4,r0
L_060B6798:
    c.r[1] = c.r[6];  // 060B6798 mov r6,r1
L_060B679A:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B679A xtrct r0,r1
L_060B679C:
    c.r[4] -= c.r[9];  // 060B679C sub r9,r4
L_060B679E:
    c.r[0] = c.r[4];  // 060B679E mov r4,r0
L_060B67A0:
    c.r[0] += c.r[10];  // 060B67A0 add r10,r0
L_060B67A2:
    c.t = c.r[0] > c.r[12];  // 060B67A2 cmp/hi r12,r0
L_060B67A4:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B67A4 bt/s 0x060B6842 ; add r3,r6
L_060B67A8:
    c.r[0] = c.r[6];  // 060B67A8 mov r6,r0
L_060B67AA:
    c.r[0] += c.r[11];  // 060B67AA add r11,r0
L_060B67AC:
    c.t = c.r[0] > c.r[13];  // 060B67AC cmp/hi r13,r0
L_060B67AE:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67AE bt/s 0x060B6842 ; swap.w r4,r3
L_060B67B2:
    c.r[4] -= c.r[2];  // 060B67B2 sub r2,r4
L_060B67B4:
    c.r[10] += c.r[4];  // 060B67B4 add r4,r10
L_060B67B6:
    c.t = c.r[10] > c.r[12];  // 060B67B6 cmp/hi r12,r10
L_060B67B8:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67B8 bt/s 0x060B6842 ; mov r6,r9
L_060B67BC:
    c.r[6] -= c.r[8];  // 060B67BC sub r8,r6
L_060B67BE:
    c.r[11] += c.r[6];  // 060B67BE add r6,r11
L_060B67C0:
    c.t = c.r[11] > c.r[13];  // 060B67C0 cmp/hi r13,r11
L_060B67C2:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67C2 bt/s 0x060B6842 ; swap.w r4,r4
L_060B67C6:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B67C6 bra 0x060B65B4 ; xtrct r4,r6
L_060B67CA:
    c.r[1] = 0x20u;  // 060B67CA mov #32,r1
L_060B67CC:
    c.r[3] = 0u - c.r[3];  // 060B67CC neg r3,r3
L_060B67CE:
    c.r[9] = 0u - c.r[9]; goto L_060B67E0;  // 060B67CE bra 0x060B67E0 ; neg r9,r9
L_060B67D2:
    c.r[1] = 0x30u;  // 060B67D2 mov #48,r1
L_060B67D4:
    c.r[3] = 0u - c.r[3];  // 060B67D4 neg r3,r3
L_060B67D6:
    c.r[9] = 0u - c.r[9]; goto L_060B67DC;  // 060B67D6 bra 0x060B67DC ; neg r9,r9
L_060B67DA:
    c.r[1] = 0x10u;  // 060B67DA mov #16,r1
L_060B67DC:
    c.r[2] = 0u - c.r[2];  // 060B67DC neg r2,r2
L_060B67DE:
    c.r[8] = 0u - c.r[8];  // 060B67DE neg r8,r8
L_060B67E0:
    c.r[5] ^= c.r[1];  // 060B67E0 xor r1,r5
L_060B67E2:
    c.r[0] = c.r[4];  // 060B67E2 mov r4,r0
L_060B67E4:
    c.r[0] += c.r[10];  // 060B67E4 add r10,r0
L_060B67E6:
    c.t = c.r[0] > c.r[12];  // 060B67E6 cmp/hi r12,r0
L_060B67E8:
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67E8 bt/s 0x060B6842 ; mov r6,r0
L_060B67EC:
    c.r[0] += c.r[11];  // 060B67EC add r11,r0
L_060B67EE:
    c.t = c.r[0] > c.r[13];  // 060B67EE cmp/hi r13,r0
L_060B67F0:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67F0 bt/s 0x060B6842 ; swap.w r4,r1
L_060B67F4:
    c.r[4] += c.r[2];  // 060B67F4 add r2,r4
L_060B67F6:
    c.r[0] = c.r[4];  // 060B67F6 mov r4,r0
L_060B67F8:
    c.r[0] += c.r[10];  // 060B67F8 add r10,r0
L_060B67FA:
    c.t = c.r[0] > c.r[12];  // 060B67FA cmp/hi r12,r0
L_060B67FC:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B67FC bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6800:
    c.r[5] = c.r[6];  // 060B6800 mov r6,r5
L_060B6802:
    c.r[6] += c.r[8];  // 060B6802 add r8,r6
L_060B6804:
    c.r[0] = c.r[6];  // 060B6804 mov r6,r0
L_060B6806:
    c.r[0] += c.r[11];  // 060B6806 add r11,r0
L_060B6808:
    c.t = c.r[0] > c.r[13];  // 060B6808 cmp/hi r13,r0
L_060B680A:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B680A bt/s 0x060B6842 ; swap.w r4,r0
L_060B680E:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B680E xtrct r1,r5
L_060B6810:
    c.r[1] = c.r[6];  // 060B6810 mov r6,r1
L_060B6812:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6812 xtrct r0,r1
L_060B6814:
    c.r[4] -= c.r[9];  // 060B6814 sub r9,r4
L_060B6816:
    c.r[0] = c.r[4];  // 060B6816 mov r4,r0
L_060B6818:
    c.r[0] += c.r[10];  // 060B6818 add r10,r0
L_060B681A:
    c.t = c.r[0] > c.r[12];  // 060B681A cmp/hi r12,r0
L_060B681C:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B681C bt/s 0x060B6842 ; add r3,r6
L_060B6820:
    c.r[0] = c.r[6];  // 060B6820 mov r6,r0
L_060B6822:
    c.r[0] += c.r[11];  // 060B6822 add r11,r0
L_060B6824:
    c.t = c.r[0] > c.r[13];  // 060B6824 cmp/hi r13,r0
L_060B6826:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6826 bt/s 0x060B6842 ; swap.w r4,r3
L_060B682A:
    c.r[4] -= c.r[2];  // 060B682A sub r2,r4
L_060B682C:
    c.r[10] += c.r[4];  // 060B682C add r4,r10
L_060B682E:
    c.t = c.r[10] > c.r[12];  // 060B682E cmp/hi r12,r10
L_060B6830:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B6830 bt/s 0x060B6842 ; mov r6,r9
L_060B6834:
    c.r[6] -= c.r[8];  // 060B6834 sub r8,r6
L_060B6836:
    c.r[11] += c.r[6];  // 060B6836 add r6,r11
L_060B6838:
    c.t = c.r[11] > c.r[13];  // 060B6838 cmp/hi r13,r11
L_060B683A:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B683A bt/s 0x060B6842 ; swap.w r4,r4
L_060B683E:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B683E bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
L_060B6854:
    c.r[1] = 0x10u;  // 060B6854 mov #16,r1
L_060B6856:
    c.r[5] ^= c.r[1];  // 060B6856 xor r1,r5
L_060B6858:
    c.r[2] = 0u - c.r[2];  // 060B6858 neg r2,r2
L_060B685A:
    c.r[8] = 0u - c.r[8];  // 060B685A neg r8,r8
L_060B685C:
    c.r[0] = c.r[9];  // 060B685C mov r9,r0
L_060B685E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B685E shar r0
L_060B6860:
    c.r[4] += c.r[0];  // 060B6860 add r0,r4
L_060B6862:
    c.r[0] = c.r[4];  // 060B6862 mov r4,r0
L_060B6864:
    c.r[0] += c.r[10];  // 060B6864 add r10,r0
L_060B6866:
    c.t = c.r[0] > c.r[12];  // 060B6866 cmp/hi r12,r0
L_060B6868:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B693C; } }  // 060B6868 bt/s 0x060B693C ; mov r3,r0
L_060B686C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B686C shar r0
L_060B686E:
    c.r[6] -= c.r[0];  // 060B686E sub r0,r6
L_060B6870:
    c.r[0] = c.r[6];  // 060B6870 mov r6,r0
L_060B6872:
    c.r[0] += c.r[11];  // 060B6872 add r11,r0
L_060B6874:
    c.t = c.r[0] > c.r[13];  // 060B6874 cmp/hi r13,r0
L_060B6876:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6876 bt/s 0x060B693C ; swap.w r4,r1
L_060B687A:
    c.r[4] += c.r[2];  // 060B687A add r2,r4
L_060B687C:
    c.r[0] = c.r[4];  // 060B687C mov r4,r0
L_060B687E:
    c.r[0] += c.r[10];  // 060B687E add r10,r0
L_060B6880:
    c.t = c.r[0] > c.r[12];  // 060B6880 cmp/hi r12,r0
L_060B6882:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B6882 bt/s 0x060B693C ; mov.w r5,@r7
L_060B6886:
    c.r[5] = c.r[6];  // 060B6886 mov r6,r5
L_060B6888:
    c.r[6] += c.r[8];  // 060B6888 add r8,r6
L_060B688A:
    c.r[0] = c.r[6];  // 060B688A mov r6,r0
L_060B688C:
    c.r[0] += c.r[11];  // 060B688C add r11,r0
L_060B688E:
    c.t = c.r[0] > c.r[13];  // 060B688E cmp/hi r13,r0
L_060B6890:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6890 bt/s 0x060B693C ; swap.w r4,r0
L_060B6894:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6894 xtrct r1,r5
L_060B6896:
    c.r[1] = c.r[6];  // 060B6896 mov r6,r1
L_060B6898:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6898 xtrct r0,r1
L_060B689A:
    c.r[4] -= c.r[9];  // 060B689A sub r9,r4
L_060B689C:
    c.r[0] = c.r[4];  // 060B689C mov r4,r0
L_060B689E:
    c.r[0] += c.r[10];  // 060B689E add r10,r0
L_060B68A0:
    c.t = c.r[0] > c.r[12];  // 060B68A0 cmp/hi r12,r0
L_060B68A2:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B68A2 bt/s 0x060B693C ; add r3,r6
L_060B68A6:
    c.r[0] = c.r[6];  // 060B68A6 mov r6,r0
L_060B68A8:
    c.r[0] += c.r[11];  // 060B68A8 add r11,r0
L_060B68AA:
    c.t = c.r[0] > c.r[13];  // 060B68AA cmp/hi r13,r0
L_060B68AC:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68AC bt/s 0x060B693C ; swap.w r4,r3
L_060B68B0:
    c.r[4] -= c.r[2];  // 060B68B0 sub r2,r4
L_060B68B2:
    c.r[10] += c.r[4];  // 060B68B2 add r4,r10
L_060B68B4:
    c.t = c.r[10] > c.r[12];  // 060B68B4 cmp/hi r12,r10
L_060B68B6:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B68B6 bt/s 0x060B693C ; mov r6,r9
L_060B68BA:
    c.r[6] -= c.r[8];  // 060B68BA sub r8,r6
L_060B68BC:
    c.r[11] += c.r[6];  // 060B68BC add r6,r11
L_060B68BE:
    c.t = c.r[11] > c.r[13];  // 060B68BE cmp/hi r13,r11
L_060B68C0:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68C0 bt/s 0x060B693C ; swap.w r4,r4
L_060B68C4:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B68C4 bra 0x060B65B4 ; xtrct r4,r6
L_060B68C8:
    c.r[1] = 0x20u;  // 060B68C8 mov #32,r1
L_060B68CA:
    c.r[5] ^= c.r[1];  // 060B68CA xor r1,r5
L_060B68CC:
    c.r[3] = 0u - c.r[3];  // 060B68CC neg r3,r3
L_060B68CE:
    c.r[9] = 0u - c.r[9];  // 060B68CE neg r9,r9
L_060B68D0:
    c.r[0] = c.r[2];  // 060B68D0 mov r2,r0
L_060B68D2:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68D2 shar r0
L_060B68D4:
    c.r[4] -= c.r[0];  // 060B68D4 sub r0,r4
L_060B68D6:
    c.r[0] = c.r[4];  // 060B68D6 mov r4,r0
L_060B68D8:
    c.r[0] += c.r[10];  // 060B68D8 add r10,r0
L_060B68DA:
    c.t = c.r[0] > c.r[12];  // 060B68DA cmp/hi r12,r0
L_060B68DC:
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060B693C; } }  // 060B68DC bt/s 0x060B693C ; mov r8,r0
L_060B68E0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68E0 shar r0
L_060B68E2:
    c.r[6] -= c.r[0];  // 060B68E2 sub r0,r6
L_060B68E4:
    c.r[0] = c.r[6];  // 060B68E4 mov r6,r0
L_060B68E6:
    c.r[0] += c.r[11];  // 060B68E6 add r11,r0
L_060B68E8:
    c.t = c.r[0] > c.r[13];  // 060B68E8 cmp/hi r13,r0
L_060B68EA:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68EA bt/s 0x060B693C ; swap.w r4,r1
L_060B68EE:
    c.r[4] += c.r[2];  // 060B68EE add r2,r4
L_060B68F0:
    c.r[0] = c.r[4];  // 060B68F0 mov r4,r0
L_060B68F2:
    c.r[0] += c.r[10];  // 060B68F2 add r10,r0
L_060B68F4:
    c.t = c.r[0] > c.r[12];  // 060B68F4 cmp/hi r12,r0
L_060B68F6:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B68F6 bt/s 0x060B693C ; mov.w r5,@r7
L_060B68FA:
    c.r[5] = c.r[6];  // 060B68FA mov r6,r5
L_060B68FC:
    c.r[6] += c.r[8];  // 060B68FC add r8,r6
L_060B68FE:
    c.r[0] = c.r[6];  // 060B68FE mov r6,r0
L_060B6900:
    c.r[0] += c.r[11];  // 060B6900 add r11,r0
L_060B6902:
    c.t = c.r[0] > c.r[13];  // 060B6902 cmp/hi r13,r0
L_060B6904:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6904 bt/s 0x060B693C ; swap.w r4,r0
L_060B6908:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6908 xtrct r1,r5
L_060B690A:
    c.r[1] = c.r[6];  // 060B690A mov r6,r1
L_060B690C:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B690C xtrct r0,r1
L_060B690E:
    c.r[4] -= c.r[9];  // 060B690E sub r9,r4
L_060B6910:
    c.r[0] = c.r[4];  // 060B6910 mov r4,r0
L_060B6912:
    c.r[0] += c.r[10];  // 060B6912 add r10,r0
L_060B6914:
    c.t = c.r[0] > c.r[12];  // 060B6914 cmp/hi r12,r0
L_060B6916:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B6916 bt/s 0x060B693C ; add r3,r6
L_060B691A:
    c.r[0] = c.r[6];  // 060B691A mov r6,r0
L_060B691C:
    c.r[0] += c.r[11];  // 060B691C add r11,r0
L_060B691E:
    c.t = c.r[0] > c.r[13];  // 060B691E cmp/hi r13,r0
L_060B6920:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6920 bt/s 0x060B693C ; swap.w r4,r3
L_060B6924:
    c.r[4] -= c.r[2];  // 060B6924 sub r2,r4
L_060B6926:
    c.r[10] += c.r[4];  // 060B6926 add r4,r10
L_060B6928:
    c.t = c.r[10] > c.r[12];  // 060B6928 cmp/hi r12,r10
L_060B692A:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B692A bt/s 0x060B693C ; mov r6,r9
L_060B692E:
    c.r[6] -= c.r[8];  // 060B692E sub r8,r6
L_060B6930:
    c.r[11] += c.r[6];  // 060B6930 add r6,r11
L_060B6932:
    c.t = c.r[11] > c.r[13];  // 060B6932 cmp/hi r13,r11
L_060B6934:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6934 bt/s 0x060B693C ; swap.w r4,r4
L_060B6938:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B6938 bra 0x060B65B4 ; xtrct r4,r6
L_060B693C:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B693C mov.l @r15+,r8
L_060B693E:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B693E mov.l @r15+,r9
L_060B6940:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6940 mov.l @r15+,r10
L_060B6942:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6942 mov.l @r15+,r11
L_060B6944:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B6944 mov.l @r15+,r12
L_060B6946:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B6946 mov.l @r15+,r13
L_060B6948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B6948 mov.l @r15+,r14
L_060B694A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B694A rts ; mov #0,r0
}

void f_060B6748(SH2Context& c) {
    ran[3112] = 1;
    goto L_060B6748;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B6748u: goto L_060B6748; case 0x060B674Au: goto L_060B674A; case 0x060B674Cu: goto L_060B674C; case 0x060B674Eu: goto L_060B674E; case 0x060B6750u: goto L_060B6750; case 0x060B6752u: goto L_060B6752; case 0x060B6754u: goto L_060B6754; case 0x060B6756u: goto L_060B6756; case 0x060B6758u: goto L_060B6758; case 0x060B675Au: goto L_060B675A; case 0x060B675Cu: goto L_060B675C; case 0x060B675Eu: goto L_060B675E; case 0x060B6760u: goto L_060B6760; case 0x060B6762u: goto L_060B6762; case 0x060B6764u: goto L_060B6764; case 0x060B6768u: goto L_060B6768; case 0x060B676Au: goto L_060B676A; case 0x060B676Cu: goto L_060B676C; case 0x060B676Eu: goto L_060B676E; case 0x060B6770u: goto L_060B6770; case 0x060B6772u: goto L_060B6772; case 0x060B6774u: goto L_060B6774; case 0x060B6776u: goto L_060B6776; case 0x060B6778u: goto L_060B6778; case 0x060B677Cu: goto L_060B677C; case 0x060B677Eu: goto L_060B677E; case 0x060B6780u: goto L_060B6780; case 0x060B6782u: goto L_060B6782; case 0x060B6784u: goto L_060B6784; case 0x060B6788u: goto L_060B6788; case 0x060B678Au: goto L_060B678A; case 0x060B678Cu: goto L_060B678C; case 0x060B678Eu: goto L_060B678E; case 0x060B6790u: goto L_060B6790; case 0x060B6792u: goto L_060B6792; case 0x060B6796u: goto L_060B6796; case 0x060B6798u: goto L_060B6798; case 0x060B679Au: goto L_060B679A; case 0x060B679Cu: goto L_060B679C; case 0x060B679Eu: goto L_060B679E; case 0x060B67A0u: goto L_060B67A0; case 0x060B67A2u: goto L_060B67A2; case 0x060B67A4u: goto L_060B67A4; case 0x060B67A8u: goto L_060B67A8; case 0x060B67AAu: goto L_060B67AA; case 0x060B67ACu: goto L_060B67AC; case 0x060B67AEu: goto L_060B67AE; case 0x060B67B2u: goto L_060B67B2; case 0x060B67B4u: goto L_060B67B4; case 0x060B67B6u: goto L_060B67B6; case 0x060B67B8u: goto L_060B67B8; case 0x060B67BCu: goto L_060B67BC; case 0x060B67BEu: goto L_060B67BE; case 0x060B67C0u: goto L_060B67C0; case 0x060B67C2u: goto L_060B67C2; case 0x060B67C6u: goto L_060B67C6; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B6748:
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B6748 swap.b r5,r5
L_060B674A:
    c.r[0] = 0xFFFFFFF0u;  // 060B674A mov #-16,r0
L_060B674C:
    c.r[0] &= c.r[5];  // 060B674C and r5,r0
L_060B674E:
    c.r[0] |= 0xAu;  // 060B674E or #10,r0
L_060B6750:
    c.r[5] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B6750 swap.b r0,r5
L_060B6752:
    c.r[0] = c.r[2];  // 060B6752 mov r2,r0
L_060B6754:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6754 shar r0
L_060B6756:
    c.r[4] -= c.r[0];  // 060B6756 sub r0,r4
L_060B6758:
    c.r[0] = c.r[9];  // 060B6758 mov r9,r0
L_060B675A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B675A shar r0
L_060B675C:
    c.r[4] += c.r[0];  // 060B675C add r0,r4
L_060B675E:
    c.r[0] = c.r[4];  // 060B675E mov r4,r0
L_060B6760:
    c.r[0] += c.r[10];  // 060B6760 add r10,r0
L_060B6762:
    c.t = c.r[0] > c.r[12];  // 060B6762 cmp/hi r12,r0
L_060B6764:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B6842; } }  // 060B6764 bt/s 0x060B6842 ; mov r3,r0
L_060B6768:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6768 shar r0
L_060B676A:
    c.r[6] -= c.r[0];  // 060B676A sub r0,r6
L_060B676C:
    c.r[0] = c.r[8];  // 060B676C mov r8,r0
L_060B676E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B676E shar r0
L_060B6770:
    c.r[6] -= c.r[0];  // 060B6770 sub r0,r6
L_060B6772:
    c.r[0] = c.r[6];  // 060B6772 mov r6,r0
L_060B6774:
    c.r[0] += c.r[11];  // 060B6774 add r11,r0
L_060B6776:
    c.t = c.r[0] > c.r[13];  // 060B6776 cmp/hi r13,r0
L_060B6778:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6778 bt/s 0x060B6842 ; swap.w r4,r1
L_060B677C:
    c.r[4] += c.r[2];  // 060B677C add r2,r4
L_060B677E:
    c.r[0] = c.r[4];  // 060B677E mov r4,r0
L_060B6780:
    c.r[0] += c.r[10];  // 060B6780 add r10,r0
L_060B6782:
    c.t = c.r[0] > c.r[12];  // 060B6782 cmp/hi r12,r0
L_060B6784:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B6784 bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6788:
    c.r[5] = c.r[6];  // 060B6788 mov r6,r5
L_060B678A:
    c.r[6] += c.r[8];  // 060B678A add r8,r6
L_060B678C:
    c.r[0] = c.r[6];  // 060B678C mov r6,r0
L_060B678E:
    c.r[0] += c.r[11];  // 060B678E add r11,r0
L_060B6790:
    c.t = c.r[0] > c.r[13];  // 060B6790 cmp/hi r13,r0
L_060B6792:
    { const bool k = c.t; c.r[5] = c.r[1] << 16 | c.r[5] >> 16; if (k) { goto L_060B6842; } }  // 060B6792 bt/s 0x060B6842 ; xtrct r1,r5
L_060B6796:
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060B6796 swap.w r4,r0
L_060B6798:
    c.r[1] = c.r[6];  // 060B6798 mov r6,r1
L_060B679A:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B679A xtrct r0,r1
L_060B679C:
    c.r[4] -= c.r[9];  // 060B679C sub r9,r4
L_060B679E:
    c.r[0] = c.r[4];  // 060B679E mov r4,r0
L_060B67A0:
    c.r[0] += c.r[10];  // 060B67A0 add r10,r0
L_060B67A2:
    c.t = c.r[0] > c.r[12];  // 060B67A2 cmp/hi r12,r0
L_060B67A4:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B67A4 bt/s 0x060B6842 ; add r3,r6
L_060B67A8:
    c.r[0] = c.r[6];  // 060B67A8 mov r6,r0
L_060B67AA:
    c.r[0] += c.r[11];  // 060B67AA add r11,r0
L_060B67AC:
    c.t = c.r[0] > c.r[13];  // 060B67AC cmp/hi r13,r0
L_060B67AE:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67AE bt/s 0x060B6842 ; swap.w r4,r3
L_060B67B2:
    c.r[4] -= c.r[2];  // 060B67B2 sub r2,r4
L_060B67B4:
    c.r[10] += c.r[4];  // 060B67B4 add r4,r10
L_060B67B6:
    c.t = c.r[10] > c.r[12];  // 060B67B6 cmp/hi r12,r10
L_060B67B8:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67B8 bt/s 0x060B6842 ; mov r6,r9
L_060B67BC:
    c.r[6] -= c.r[8];  // 060B67BC sub r8,r6
L_060B67BE:
    c.r[11] += c.r[6];  // 060B67BE add r6,r11
L_060B67C0:
    c.t = c.r[11] > c.r[13];  // 060B67C0 cmp/hi r13,r11
L_060B67C2:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67C2 bt/s 0x060B6842 ; swap.w r4,r4
L_060B67C6:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B67C6 bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
}

void f_060B6752(SH2Context& c) {
    ran[3113] = 1;
    goto L_060B6752;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B6752u: goto L_060B6752; case 0x060B6754u: goto L_060B6754; case 0x060B6756u: goto L_060B6756; case 0x060B6758u: goto L_060B6758; case 0x060B675Au: goto L_060B675A; case 0x060B675Cu: goto L_060B675C; case 0x060B675Eu: goto L_060B675E; case 0x060B6760u: goto L_060B6760; case 0x060B6762u: goto L_060B6762; case 0x060B6764u: goto L_060B6764; case 0x060B6768u: goto L_060B6768; case 0x060B676Au: goto L_060B676A; case 0x060B676Cu: goto L_060B676C; case 0x060B676Eu: goto L_060B676E; case 0x060B6770u: goto L_060B6770; case 0x060B6772u: goto L_060B6772; case 0x060B6774u: goto L_060B6774; case 0x060B6776u: goto L_060B6776; case 0x060B6778u: goto L_060B6778; case 0x060B677Cu: goto L_060B677C; case 0x060B677Eu: goto L_060B677E; case 0x060B6780u: goto L_060B6780; case 0x060B6782u: goto L_060B6782; case 0x060B6784u: goto L_060B6784; case 0x060B6788u: goto L_060B6788; case 0x060B678Au: goto L_060B678A; case 0x060B678Cu: goto L_060B678C; case 0x060B678Eu: goto L_060B678E; case 0x060B6790u: goto L_060B6790; case 0x060B6792u: goto L_060B6792; case 0x060B6796u: goto L_060B6796; case 0x060B6798u: goto L_060B6798; case 0x060B679Au: goto L_060B679A; case 0x060B679Cu: goto L_060B679C; case 0x060B679Eu: goto L_060B679E; case 0x060B67A0u: goto L_060B67A0; case 0x060B67A2u: goto L_060B67A2; case 0x060B67A4u: goto L_060B67A4; case 0x060B67A8u: goto L_060B67A8; case 0x060B67AAu: goto L_060B67AA; case 0x060B67ACu: goto L_060B67AC; case 0x060B67AEu: goto L_060B67AE; case 0x060B67B2u: goto L_060B67B2; case 0x060B67B4u: goto L_060B67B4; case 0x060B67B6u: goto L_060B67B6; case 0x060B67B8u: goto L_060B67B8; case 0x060B67BCu: goto L_060B67BC; case 0x060B67BEu: goto L_060B67BE; case 0x060B67C0u: goto L_060B67C0; case 0x060B67C2u: goto L_060B67C2; case 0x060B67C6u: goto L_060B67C6; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B6752:
    c.r[0] = c.r[2];  // 060B6752 mov r2,r0
L_060B6754:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6754 shar r0
L_060B6756:
    c.r[4] -= c.r[0];  // 060B6756 sub r0,r4
L_060B6758:
    c.r[0] = c.r[9];  // 060B6758 mov r9,r0
L_060B675A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B675A shar r0
L_060B675C:
    c.r[4] += c.r[0];  // 060B675C add r0,r4
L_060B675E:
    c.r[0] = c.r[4];  // 060B675E mov r4,r0
L_060B6760:
    c.r[0] += c.r[10];  // 060B6760 add r10,r0
L_060B6762:
    c.t = c.r[0] > c.r[12];  // 060B6762 cmp/hi r12,r0
L_060B6764:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B6842; } }  // 060B6764 bt/s 0x060B6842 ; mov r3,r0
L_060B6768:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6768 shar r0
L_060B676A:
    c.r[6] -= c.r[0];  // 060B676A sub r0,r6
L_060B676C:
    c.r[0] = c.r[8];  // 060B676C mov r8,r0
L_060B676E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B676E shar r0
L_060B6770:
    c.r[6] -= c.r[0];  // 060B6770 sub r0,r6
L_060B6772:
    c.r[0] = c.r[6];  // 060B6772 mov r6,r0
L_060B6774:
    c.r[0] += c.r[11];  // 060B6774 add r11,r0
L_060B6776:
    c.t = c.r[0] > c.r[13];  // 060B6776 cmp/hi r13,r0
L_060B6778:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6778 bt/s 0x060B6842 ; swap.w r4,r1
L_060B677C:
    c.r[4] += c.r[2];  // 060B677C add r2,r4
L_060B677E:
    c.r[0] = c.r[4];  // 060B677E mov r4,r0
L_060B6780:
    c.r[0] += c.r[10];  // 060B6780 add r10,r0
L_060B6782:
    c.t = c.r[0] > c.r[12];  // 060B6782 cmp/hi r12,r0
L_060B6784:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B6784 bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6788:
    c.r[5] = c.r[6];  // 060B6788 mov r6,r5
L_060B678A:
    c.r[6] += c.r[8];  // 060B678A add r8,r6
L_060B678C:
    c.r[0] = c.r[6];  // 060B678C mov r6,r0
L_060B678E:
    c.r[0] += c.r[11];  // 060B678E add r11,r0
L_060B6790:
    c.t = c.r[0] > c.r[13];  // 060B6790 cmp/hi r13,r0
L_060B6792:
    { const bool k = c.t; c.r[5] = c.r[1] << 16 | c.r[5] >> 16; if (k) { goto L_060B6842; } }  // 060B6792 bt/s 0x060B6842 ; xtrct r1,r5
L_060B6796:
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060B6796 swap.w r4,r0
L_060B6798:
    c.r[1] = c.r[6];  // 060B6798 mov r6,r1
L_060B679A:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B679A xtrct r0,r1
L_060B679C:
    c.r[4] -= c.r[9];  // 060B679C sub r9,r4
L_060B679E:
    c.r[0] = c.r[4];  // 060B679E mov r4,r0
L_060B67A0:
    c.r[0] += c.r[10];  // 060B67A0 add r10,r0
L_060B67A2:
    c.t = c.r[0] > c.r[12];  // 060B67A2 cmp/hi r12,r0
L_060B67A4:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B67A4 bt/s 0x060B6842 ; add r3,r6
L_060B67A8:
    c.r[0] = c.r[6];  // 060B67A8 mov r6,r0
L_060B67AA:
    c.r[0] += c.r[11];  // 060B67AA add r11,r0
L_060B67AC:
    c.t = c.r[0] > c.r[13];  // 060B67AC cmp/hi r13,r0
L_060B67AE:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67AE bt/s 0x060B6842 ; swap.w r4,r3
L_060B67B2:
    c.r[4] -= c.r[2];  // 060B67B2 sub r2,r4
L_060B67B4:
    c.r[10] += c.r[4];  // 060B67B4 add r4,r10
L_060B67B6:
    c.t = c.r[10] > c.r[12];  // 060B67B6 cmp/hi r12,r10
L_060B67B8:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67B8 bt/s 0x060B6842 ; mov r6,r9
L_060B67BC:
    c.r[6] -= c.r[8];  // 060B67BC sub r8,r6
L_060B67BE:
    c.r[11] += c.r[6];  // 060B67BE add r6,r11
L_060B67C0:
    c.t = c.r[11] > c.r[13];  // 060B67C0 cmp/hi r13,r11
L_060B67C2:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67C2 bt/s 0x060B6842 ; swap.w r4,r4
L_060B67C6:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B67C6 bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
}

void f_060B67CA(SH2Context& c) {
    ran[3114] = 1;
    goto L_060B67CA;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B67CAu: goto L_060B67CA; case 0x060B67CCu: goto L_060B67CC; case 0x060B67CEu: goto L_060B67CE; case 0x060B67E0u: goto L_060B67E0; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B67CA:
    c.r[1] = 0x20u;  // 060B67CA mov #32,r1
L_060B67CC:
    c.r[3] = 0u - c.r[3];  // 060B67CC neg r3,r3
L_060B67CE:
    c.r[9] = 0u - c.r[9]; goto L_060B67E0;  // 060B67CE bra 0x060B67E0 ; neg r9,r9
L_060B67E0:
    c.r[5] ^= c.r[1];  // 060B67E0 xor r1,r5
L_060B67E2:
    c.r[0] = c.r[4];  // 060B67E2 mov r4,r0
L_060B67E4:
    c.r[0] += c.r[10];  // 060B67E4 add r10,r0
L_060B67E6:
    c.t = c.r[0] > c.r[12];  // 060B67E6 cmp/hi r12,r0
L_060B67E8:
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67E8 bt/s 0x060B6842 ; mov r6,r0
L_060B67EC:
    c.r[0] += c.r[11];  // 060B67EC add r11,r0
L_060B67EE:
    c.t = c.r[0] > c.r[13];  // 060B67EE cmp/hi r13,r0
L_060B67F0:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67F0 bt/s 0x060B6842 ; swap.w r4,r1
L_060B67F4:
    c.r[4] += c.r[2];  // 060B67F4 add r2,r4
L_060B67F6:
    c.r[0] = c.r[4];  // 060B67F6 mov r4,r0
L_060B67F8:
    c.r[0] += c.r[10];  // 060B67F8 add r10,r0
L_060B67FA:
    c.t = c.r[0] > c.r[12];  // 060B67FA cmp/hi r12,r0
L_060B67FC:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B67FC bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6800:
    c.r[5] = c.r[6];  // 060B6800 mov r6,r5
L_060B6802:
    c.r[6] += c.r[8];  // 060B6802 add r8,r6
L_060B6804:
    c.r[0] = c.r[6];  // 060B6804 mov r6,r0
L_060B6806:
    c.r[0] += c.r[11];  // 060B6806 add r11,r0
L_060B6808:
    c.t = c.r[0] > c.r[13];  // 060B6808 cmp/hi r13,r0
L_060B680A:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B680A bt/s 0x060B6842 ; swap.w r4,r0
L_060B680E:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B680E xtrct r1,r5
L_060B6810:
    c.r[1] = c.r[6];  // 060B6810 mov r6,r1
L_060B6812:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6812 xtrct r0,r1
L_060B6814:
    c.r[4] -= c.r[9];  // 060B6814 sub r9,r4
L_060B6816:
    c.r[0] = c.r[4];  // 060B6816 mov r4,r0
L_060B6818:
    c.r[0] += c.r[10];  // 060B6818 add r10,r0
L_060B681A:
    c.t = c.r[0] > c.r[12];  // 060B681A cmp/hi r12,r0
L_060B681C:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B681C bt/s 0x060B6842 ; add r3,r6
L_060B6820:
    c.r[0] = c.r[6];  // 060B6820 mov r6,r0
L_060B6822:
    c.r[0] += c.r[11];  // 060B6822 add r11,r0
L_060B6824:
    c.t = c.r[0] > c.r[13];  // 060B6824 cmp/hi r13,r0
L_060B6826:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6826 bt/s 0x060B6842 ; swap.w r4,r3
L_060B682A:
    c.r[4] -= c.r[2];  // 060B682A sub r2,r4
L_060B682C:
    c.r[10] += c.r[4];  // 060B682C add r4,r10
L_060B682E:
    c.t = c.r[10] > c.r[12];  // 060B682E cmp/hi r12,r10
L_060B6830:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B6830 bt/s 0x060B6842 ; mov r6,r9
L_060B6834:
    c.r[6] -= c.r[8];  // 060B6834 sub r8,r6
L_060B6836:
    c.r[11] += c.r[6];  // 060B6836 add r6,r11
L_060B6838:
    c.t = c.r[11] > c.r[13];  // 060B6838 cmp/hi r13,r11
L_060B683A:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B683A bt/s 0x060B6842 ; swap.w r4,r4
L_060B683E:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B683E bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
}

void f_060B67D2(SH2Context& c) {
    ran[3115] = 1;
    goto L_060B67D2;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B67D2u: goto L_060B67D2; case 0x060B67D4u: goto L_060B67D4; case 0x060B67D6u: goto L_060B67D6; case 0x060B67DCu: goto L_060B67DC; case 0x060B67DEu: goto L_060B67DE; case 0x060B67E0u: goto L_060B67E0; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B67D2:
    c.r[1] = 0x30u;  // 060B67D2 mov #48,r1
L_060B67D4:
    c.r[3] = 0u - c.r[3];  // 060B67D4 neg r3,r3
L_060B67D6:
    c.r[9] = 0u - c.r[9]; goto L_060B67DC;  // 060B67D6 bra 0x060B67DC ; neg r9,r9
L_060B67DC:
    c.r[2] = 0u - c.r[2];  // 060B67DC neg r2,r2
L_060B67DE:
    c.r[8] = 0u - c.r[8];  // 060B67DE neg r8,r8
L_060B67E0:
    c.r[5] ^= c.r[1];  // 060B67E0 xor r1,r5
L_060B67E2:
    c.r[0] = c.r[4];  // 060B67E2 mov r4,r0
L_060B67E4:
    c.r[0] += c.r[10];  // 060B67E4 add r10,r0
L_060B67E6:
    c.t = c.r[0] > c.r[12];  // 060B67E6 cmp/hi r12,r0
L_060B67E8:
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67E8 bt/s 0x060B6842 ; mov r6,r0
L_060B67EC:
    c.r[0] += c.r[11];  // 060B67EC add r11,r0
L_060B67EE:
    c.t = c.r[0] > c.r[13];  // 060B67EE cmp/hi r13,r0
L_060B67F0:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67F0 bt/s 0x060B6842 ; swap.w r4,r1
L_060B67F4:
    c.r[4] += c.r[2];  // 060B67F4 add r2,r4
L_060B67F6:
    c.r[0] = c.r[4];  // 060B67F6 mov r4,r0
L_060B67F8:
    c.r[0] += c.r[10];  // 060B67F8 add r10,r0
L_060B67FA:
    c.t = c.r[0] > c.r[12];  // 060B67FA cmp/hi r12,r0
L_060B67FC:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B67FC bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6800:
    c.r[5] = c.r[6];  // 060B6800 mov r6,r5
L_060B6802:
    c.r[6] += c.r[8];  // 060B6802 add r8,r6
L_060B6804:
    c.r[0] = c.r[6];  // 060B6804 mov r6,r0
L_060B6806:
    c.r[0] += c.r[11];  // 060B6806 add r11,r0
L_060B6808:
    c.t = c.r[0] > c.r[13];  // 060B6808 cmp/hi r13,r0
L_060B680A:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B680A bt/s 0x060B6842 ; swap.w r4,r0
L_060B680E:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B680E xtrct r1,r5
L_060B6810:
    c.r[1] = c.r[6];  // 060B6810 mov r6,r1
L_060B6812:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6812 xtrct r0,r1
L_060B6814:
    c.r[4] -= c.r[9];  // 060B6814 sub r9,r4
L_060B6816:
    c.r[0] = c.r[4];  // 060B6816 mov r4,r0
L_060B6818:
    c.r[0] += c.r[10];  // 060B6818 add r10,r0
L_060B681A:
    c.t = c.r[0] > c.r[12];  // 060B681A cmp/hi r12,r0
L_060B681C:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B681C bt/s 0x060B6842 ; add r3,r6
L_060B6820:
    c.r[0] = c.r[6];  // 060B6820 mov r6,r0
L_060B6822:
    c.r[0] += c.r[11];  // 060B6822 add r11,r0
L_060B6824:
    c.t = c.r[0] > c.r[13];  // 060B6824 cmp/hi r13,r0
L_060B6826:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6826 bt/s 0x060B6842 ; swap.w r4,r3
L_060B682A:
    c.r[4] -= c.r[2];  // 060B682A sub r2,r4
L_060B682C:
    c.r[10] += c.r[4];  // 060B682C add r4,r10
L_060B682E:
    c.t = c.r[10] > c.r[12];  // 060B682E cmp/hi r12,r10
L_060B6830:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B6830 bt/s 0x060B6842 ; mov r6,r9
L_060B6834:
    c.r[6] -= c.r[8];  // 060B6834 sub r8,r6
L_060B6836:
    c.r[11] += c.r[6];  // 060B6836 add r6,r11
L_060B6838:
    c.t = c.r[11] > c.r[13];  // 060B6838 cmp/hi r13,r11
L_060B683A:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B683A bt/s 0x060B6842 ; swap.w r4,r4
L_060B683E:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B683E bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
}

void f_060B67DA(SH2Context& c) {
    ran[3116] = 1;
    goto L_060B67DA;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B67DAu: goto L_060B67DA; case 0x060B67DCu: goto L_060B67DC; case 0x060B67DEu: goto L_060B67DE; case 0x060B67E0u: goto L_060B67E0; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B67DA:
    c.r[1] = 0x10u;  // 060B67DA mov #16,r1
L_060B67DC:
    c.r[2] = 0u - c.r[2];  // 060B67DC neg r2,r2
L_060B67DE:
    c.r[8] = 0u - c.r[8];  // 060B67DE neg r8,r8
L_060B67E0:
    c.r[5] ^= c.r[1];  // 060B67E0 xor r1,r5
L_060B67E2:
    c.r[0] = c.r[4];  // 060B67E2 mov r4,r0
L_060B67E4:
    c.r[0] += c.r[10];  // 060B67E4 add r10,r0
L_060B67E6:
    c.t = c.r[0] > c.r[12];  // 060B67E6 cmp/hi r12,r0
L_060B67E8:
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67E8 bt/s 0x060B6842 ; mov r6,r0
L_060B67EC:
    c.r[0] += c.r[11];  // 060B67EC add r11,r0
L_060B67EE:
    c.t = c.r[0] > c.r[13];  // 060B67EE cmp/hi r13,r0
L_060B67F0:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67F0 bt/s 0x060B6842 ; swap.w r4,r1
L_060B67F4:
    c.r[4] += c.r[2];  // 060B67F4 add r2,r4
L_060B67F6:
    c.r[0] = c.r[4];  // 060B67F6 mov r4,r0
L_060B67F8:
    c.r[0] += c.r[10];  // 060B67F8 add r10,r0
L_060B67FA:
    c.t = c.r[0] > c.r[12];  // 060B67FA cmp/hi r12,r0
L_060B67FC:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B67FC bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6800:
    c.r[5] = c.r[6];  // 060B6800 mov r6,r5
L_060B6802:
    c.r[6] += c.r[8];  // 060B6802 add r8,r6
L_060B6804:
    c.r[0] = c.r[6];  // 060B6804 mov r6,r0
L_060B6806:
    c.r[0] += c.r[11];  // 060B6806 add r11,r0
L_060B6808:
    c.t = c.r[0] > c.r[13];  // 060B6808 cmp/hi r13,r0
L_060B680A:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B680A bt/s 0x060B6842 ; swap.w r4,r0
L_060B680E:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B680E xtrct r1,r5
L_060B6810:
    c.r[1] = c.r[6];  // 060B6810 mov r6,r1
L_060B6812:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6812 xtrct r0,r1
L_060B6814:
    c.r[4] -= c.r[9];  // 060B6814 sub r9,r4
L_060B6816:
    c.r[0] = c.r[4];  // 060B6816 mov r4,r0
L_060B6818:
    c.r[0] += c.r[10];  // 060B6818 add r10,r0
L_060B681A:
    c.t = c.r[0] > c.r[12];  // 060B681A cmp/hi r12,r0
L_060B681C:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B681C bt/s 0x060B6842 ; add r3,r6
L_060B6820:
    c.r[0] = c.r[6];  // 060B6820 mov r6,r0
L_060B6822:
    c.r[0] += c.r[11];  // 060B6822 add r11,r0
L_060B6824:
    c.t = c.r[0] > c.r[13];  // 060B6824 cmp/hi r13,r0
L_060B6826:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6826 bt/s 0x060B6842 ; swap.w r4,r3
L_060B682A:
    c.r[4] -= c.r[2];  // 060B682A sub r2,r4
L_060B682C:
    c.r[10] += c.r[4];  // 060B682C add r4,r10
L_060B682E:
    c.t = c.r[10] > c.r[12];  // 060B682E cmp/hi r12,r10
L_060B6830:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B6830 bt/s 0x060B6842 ; mov r6,r9
L_060B6834:
    c.r[6] -= c.r[8];  // 060B6834 sub r8,r6
L_060B6836:
    c.r[11] += c.r[6];  // 060B6836 add r6,r11
L_060B6838:
    c.t = c.r[11] > c.r[13];  // 060B6838 cmp/hi r13,r11
L_060B683A:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B683A bt/s 0x060B6842 ; swap.w r4,r4
L_060B683E:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B683E bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
}

void f_060B67E2(SH2Context& c) {
    ran[3117] = 1;
    goto L_060B67E2;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B67E2:
    c.r[0] = c.r[4];  // 060B67E2 mov r4,r0
L_060B67E4:
    c.r[0] += c.r[10];  // 060B67E4 add r10,r0
L_060B67E6:
    c.t = c.r[0] > c.r[12];  // 060B67E6 cmp/hi r12,r0
L_060B67E8:
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67E8 bt/s 0x060B6842 ; mov r6,r0
L_060B67EC:
    c.r[0] += c.r[11];  // 060B67EC add r11,r0
L_060B67EE:
    c.t = c.r[0] > c.r[13];  // 060B67EE cmp/hi r13,r0
L_060B67F0:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67F0 bt/s 0x060B6842 ; swap.w r4,r1
L_060B67F4:
    c.r[4] += c.r[2];  // 060B67F4 add r2,r4
L_060B67F6:
    c.r[0] = c.r[4];  // 060B67F6 mov r4,r0
L_060B67F8:
    c.r[0] += c.r[10];  // 060B67F8 add r10,r0
L_060B67FA:
    c.t = c.r[0] > c.r[12];  // 060B67FA cmp/hi r12,r0
L_060B67FC:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B67FC bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6800:
    c.r[5] = c.r[6];  // 060B6800 mov r6,r5
L_060B6802:
    c.r[6] += c.r[8];  // 060B6802 add r8,r6
L_060B6804:
    c.r[0] = c.r[6];  // 060B6804 mov r6,r0
L_060B6806:
    c.r[0] += c.r[11];  // 060B6806 add r11,r0
L_060B6808:
    c.t = c.r[0] > c.r[13];  // 060B6808 cmp/hi r13,r0
L_060B680A:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B680A bt/s 0x060B6842 ; swap.w r4,r0
L_060B680E:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B680E xtrct r1,r5
L_060B6810:
    c.r[1] = c.r[6];  // 060B6810 mov r6,r1
L_060B6812:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6812 xtrct r0,r1
L_060B6814:
    c.r[4] -= c.r[9];  // 060B6814 sub r9,r4
L_060B6816:
    c.r[0] = c.r[4];  // 060B6816 mov r4,r0
L_060B6818:
    c.r[0] += c.r[10];  // 060B6818 add r10,r0
L_060B681A:
    c.t = c.r[0] > c.r[12];  // 060B681A cmp/hi r12,r0
L_060B681C:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B681C bt/s 0x060B6842 ; add r3,r6
L_060B6820:
    c.r[0] = c.r[6];  // 060B6820 mov r6,r0
L_060B6822:
    c.r[0] += c.r[11];  // 060B6822 add r11,r0
L_060B6824:
    c.t = c.r[0] > c.r[13];  // 060B6824 cmp/hi r13,r0
L_060B6826:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6826 bt/s 0x060B6842 ; swap.w r4,r3
L_060B682A:
    c.r[4] -= c.r[2];  // 060B682A sub r2,r4
L_060B682C:
    c.r[10] += c.r[4];  // 060B682C add r4,r10
L_060B682E:
    c.t = c.r[10] > c.r[12];  // 060B682E cmp/hi r12,r10
L_060B6830:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B6830 bt/s 0x060B6842 ; mov r6,r9
L_060B6834:
    c.r[6] -= c.r[8];  // 060B6834 sub r8,r6
L_060B6836:
    c.r[11] += c.r[6];  // 060B6836 add r6,r11
L_060B6838:
    c.t = c.r[11] > c.r[13];  // 060B6838 cmp/hi r13,r11
L_060B683A:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B683A bt/s 0x060B6842 ; swap.w r4,r4
L_060B683E:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B683E bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
}

void f_060B6854(SH2Context& c) {
    ran[3118] = 1;
    goto L_060B6854;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B6854u: goto L_060B6854; case 0x060B6856u: goto L_060B6856; case 0x060B6858u: goto L_060B6858; case 0x060B685Au: goto L_060B685A; case 0x060B685Cu: goto L_060B685C; case 0x060B685Eu: goto L_060B685E; case 0x060B6860u: goto L_060B6860; case 0x060B6862u: goto L_060B6862; case 0x060B6864u: goto L_060B6864; case 0x060B6866u: goto L_060B6866; case 0x060B6868u: goto L_060B6868; case 0x060B686Cu: goto L_060B686C; case 0x060B686Eu: goto L_060B686E; case 0x060B6870u: goto L_060B6870; case 0x060B6872u: goto L_060B6872; case 0x060B6874u: goto L_060B6874; case 0x060B6876u: goto L_060B6876; case 0x060B687Au: goto L_060B687A; case 0x060B687Cu: goto L_060B687C; case 0x060B687Eu: goto L_060B687E; case 0x060B6880u: goto L_060B6880; case 0x060B6882u: goto L_060B6882; case 0x060B6886u: goto L_060B6886; case 0x060B6888u: goto L_060B6888; case 0x060B688Au: goto L_060B688A; case 0x060B688Cu: goto L_060B688C; case 0x060B688Eu: goto L_060B688E; case 0x060B6890u: goto L_060B6890; case 0x060B6894u: goto L_060B6894; case 0x060B6896u: goto L_060B6896; case 0x060B6898u: goto L_060B6898; case 0x060B689Au: goto L_060B689A; case 0x060B689Cu: goto L_060B689C; case 0x060B689Eu: goto L_060B689E; case 0x060B68A0u: goto L_060B68A0; case 0x060B68A2u: goto L_060B68A2; case 0x060B68A6u: goto L_060B68A6; case 0x060B68A8u: goto L_060B68A8; case 0x060B68AAu: goto L_060B68AA; case 0x060B68ACu: goto L_060B68AC; case 0x060B68B0u: goto L_060B68B0; case 0x060B68B2u: goto L_060B68B2; case 0x060B68B4u: goto L_060B68B4; case 0x060B68B6u: goto L_060B68B6; case 0x060B68BAu: goto L_060B68BA; case 0x060B68BCu: goto L_060B68BC; case 0x060B68BEu: goto L_060B68BE; case 0x060B68C0u: goto L_060B68C0; case 0x060B68C4u: goto L_060B68C4; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B6854:
    c.r[1] = 0x10u;  // 060B6854 mov #16,r1
L_060B6856:
    c.r[5] ^= c.r[1];  // 060B6856 xor r1,r5
L_060B6858:
    c.r[2] = 0u - c.r[2];  // 060B6858 neg r2,r2
L_060B685A:
    c.r[8] = 0u - c.r[8];  // 060B685A neg r8,r8
L_060B685C:
    c.r[0] = c.r[9];  // 060B685C mov r9,r0
L_060B685E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B685E shar r0
L_060B6860:
    c.r[4] += c.r[0];  // 060B6860 add r0,r4
L_060B6862:
    c.r[0] = c.r[4];  // 060B6862 mov r4,r0
L_060B6864:
    c.r[0] += c.r[10];  // 060B6864 add r10,r0
L_060B6866:
    c.t = c.r[0] > c.r[12];  // 060B6866 cmp/hi r12,r0
L_060B6868:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B693C; } }  // 060B6868 bt/s 0x060B693C ; mov r3,r0
L_060B686C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B686C shar r0
L_060B686E:
    c.r[6] -= c.r[0];  // 060B686E sub r0,r6
L_060B6870:
    c.r[0] = c.r[6];  // 060B6870 mov r6,r0
L_060B6872:
    c.r[0] += c.r[11];  // 060B6872 add r11,r0
L_060B6874:
    c.t = c.r[0] > c.r[13];  // 060B6874 cmp/hi r13,r0
L_060B6876:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6876 bt/s 0x060B693C ; swap.w r4,r1
L_060B687A:
    c.r[4] += c.r[2];  // 060B687A add r2,r4
L_060B687C:
    c.r[0] = c.r[4];  // 060B687C mov r4,r0
L_060B687E:
    c.r[0] += c.r[10];  // 060B687E add r10,r0
L_060B6880:
    c.t = c.r[0] > c.r[12];  // 060B6880 cmp/hi r12,r0
L_060B6882:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B6882 bt/s 0x060B693C ; mov.w r5,@r7
L_060B6886:
    c.r[5] = c.r[6];  // 060B6886 mov r6,r5
L_060B6888:
    c.r[6] += c.r[8];  // 060B6888 add r8,r6
L_060B688A:
    c.r[0] = c.r[6];  // 060B688A mov r6,r0
L_060B688C:
    c.r[0] += c.r[11];  // 060B688C add r11,r0
L_060B688E:
    c.t = c.r[0] > c.r[13];  // 060B688E cmp/hi r13,r0
L_060B6890:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6890 bt/s 0x060B693C ; swap.w r4,r0
L_060B6894:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6894 xtrct r1,r5
L_060B6896:
    c.r[1] = c.r[6];  // 060B6896 mov r6,r1
L_060B6898:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6898 xtrct r0,r1
L_060B689A:
    c.r[4] -= c.r[9];  // 060B689A sub r9,r4
L_060B689C:
    c.r[0] = c.r[4];  // 060B689C mov r4,r0
L_060B689E:
    c.r[0] += c.r[10];  // 060B689E add r10,r0
L_060B68A0:
    c.t = c.r[0] > c.r[12];  // 060B68A0 cmp/hi r12,r0
L_060B68A2:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B68A2 bt/s 0x060B693C ; add r3,r6
L_060B68A6:
    c.r[0] = c.r[6];  // 060B68A6 mov r6,r0
L_060B68A8:
    c.r[0] += c.r[11];  // 060B68A8 add r11,r0
L_060B68AA:
    c.t = c.r[0] > c.r[13];  // 060B68AA cmp/hi r13,r0
L_060B68AC:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68AC bt/s 0x060B693C ; swap.w r4,r3
L_060B68B0:
    c.r[4] -= c.r[2];  // 060B68B0 sub r2,r4
L_060B68B2:
    c.r[10] += c.r[4];  // 060B68B2 add r4,r10
L_060B68B4:
    c.t = c.r[10] > c.r[12];  // 060B68B4 cmp/hi r12,r10
L_060B68B6:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B68B6 bt/s 0x060B693C ; mov r6,r9
L_060B68BA:
    c.r[6] -= c.r[8];  // 060B68BA sub r8,r6
L_060B68BC:
    c.r[11] += c.r[6];  // 060B68BC add r6,r11
L_060B68BE:
    c.t = c.r[11] > c.r[13];  // 060B68BE cmp/hi r13,r11
L_060B68C0:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68C0 bt/s 0x060B693C ; swap.w r4,r4
L_060B68C4:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B68C4 bra 0x060B65B4 ; xtrct r4,r6
L_060B693C:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B693C mov.l @r15+,r8
L_060B693E:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B693E mov.l @r15+,r9
L_060B6940:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6940 mov.l @r15+,r10
L_060B6942:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6942 mov.l @r15+,r11
L_060B6944:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B6944 mov.l @r15+,r12
L_060B6946:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B6946 mov.l @r15+,r13
L_060B6948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B6948 mov.l @r15+,r14
L_060B694A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B694A rts ; mov #0,r0
}

void f_060B685C(SH2Context& c) {
    ran[3119] = 1;
    goto L_060B685C;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B685Cu: goto L_060B685C; case 0x060B685Eu: goto L_060B685E; case 0x060B6860u: goto L_060B6860; case 0x060B6862u: goto L_060B6862; case 0x060B6864u: goto L_060B6864; case 0x060B6866u: goto L_060B6866; case 0x060B6868u: goto L_060B6868; case 0x060B686Cu: goto L_060B686C; case 0x060B686Eu: goto L_060B686E; case 0x060B6870u: goto L_060B6870; case 0x060B6872u: goto L_060B6872; case 0x060B6874u: goto L_060B6874; case 0x060B6876u: goto L_060B6876; case 0x060B687Au: goto L_060B687A; case 0x060B687Cu: goto L_060B687C; case 0x060B687Eu: goto L_060B687E; case 0x060B6880u: goto L_060B6880; case 0x060B6882u: goto L_060B6882; case 0x060B6886u: goto L_060B6886; case 0x060B6888u: goto L_060B6888; case 0x060B688Au: goto L_060B688A; case 0x060B688Cu: goto L_060B688C; case 0x060B688Eu: goto L_060B688E; case 0x060B6890u: goto L_060B6890; case 0x060B6894u: goto L_060B6894; case 0x060B6896u: goto L_060B6896; case 0x060B6898u: goto L_060B6898; case 0x060B689Au: goto L_060B689A; case 0x060B689Cu: goto L_060B689C; case 0x060B689Eu: goto L_060B689E; case 0x060B68A0u: goto L_060B68A0; case 0x060B68A2u: goto L_060B68A2; case 0x060B68A6u: goto L_060B68A6; case 0x060B68A8u: goto L_060B68A8; case 0x060B68AAu: goto L_060B68AA; case 0x060B68ACu: goto L_060B68AC; case 0x060B68B0u: goto L_060B68B0; case 0x060B68B2u: goto L_060B68B2; case 0x060B68B4u: goto L_060B68B4; case 0x060B68B6u: goto L_060B68B6; case 0x060B68BAu: goto L_060B68BA; case 0x060B68BCu: goto L_060B68BC; case 0x060B68BEu: goto L_060B68BE; case 0x060B68C0u: goto L_060B68C0; case 0x060B68C4u: goto L_060B68C4; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B685C:
    c.r[0] = c.r[9];  // 060B685C mov r9,r0
L_060B685E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B685E shar r0
L_060B6860:
    c.r[4] += c.r[0];  // 060B6860 add r0,r4
L_060B6862:
    c.r[0] = c.r[4];  // 060B6862 mov r4,r0
L_060B6864:
    c.r[0] += c.r[10];  // 060B6864 add r10,r0
L_060B6866:
    c.t = c.r[0] > c.r[12];  // 060B6866 cmp/hi r12,r0
L_060B6868:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B693C; } }  // 060B6868 bt/s 0x060B693C ; mov r3,r0
L_060B686C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B686C shar r0
L_060B686E:
    c.r[6] -= c.r[0];  // 060B686E sub r0,r6
L_060B6870:
    c.r[0] = c.r[6];  // 060B6870 mov r6,r0
L_060B6872:
    c.r[0] += c.r[11];  // 060B6872 add r11,r0
L_060B6874:
    c.t = c.r[0] > c.r[13];  // 060B6874 cmp/hi r13,r0
L_060B6876:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6876 bt/s 0x060B693C ; swap.w r4,r1
L_060B687A:
    c.r[4] += c.r[2];  // 060B687A add r2,r4
L_060B687C:
    c.r[0] = c.r[4];  // 060B687C mov r4,r0
L_060B687E:
    c.r[0] += c.r[10];  // 060B687E add r10,r0
L_060B6880:
    c.t = c.r[0] > c.r[12];  // 060B6880 cmp/hi r12,r0
L_060B6882:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B6882 bt/s 0x060B693C ; mov.w r5,@r7
L_060B6886:
    c.r[5] = c.r[6];  // 060B6886 mov r6,r5
L_060B6888:
    c.r[6] += c.r[8];  // 060B6888 add r8,r6
L_060B688A:
    c.r[0] = c.r[6];  // 060B688A mov r6,r0
L_060B688C:
    c.r[0] += c.r[11];  // 060B688C add r11,r0
L_060B688E:
    c.t = c.r[0] > c.r[13];  // 060B688E cmp/hi r13,r0
L_060B6890:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6890 bt/s 0x060B693C ; swap.w r4,r0
L_060B6894:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6894 xtrct r1,r5
L_060B6896:
    c.r[1] = c.r[6];  // 060B6896 mov r6,r1
L_060B6898:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6898 xtrct r0,r1
L_060B689A:
    c.r[4] -= c.r[9];  // 060B689A sub r9,r4
L_060B689C:
    c.r[0] = c.r[4];  // 060B689C mov r4,r0
L_060B689E:
    c.r[0] += c.r[10];  // 060B689E add r10,r0
L_060B68A0:
    c.t = c.r[0] > c.r[12];  // 060B68A0 cmp/hi r12,r0
L_060B68A2:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B68A2 bt/s 0x060B693C ; add r3,r6
L_060B68A6:
    c.r[0] = c.r[6];  // 060B68A6 mov r6,r0
L_060B68A8:
    c.r[0] += c.r[11];  // 060B68A8 add r11,r0
L_060B68AA:
    c.t = c.r[0] > c.r[13];  // 060B68AA cmp/hi r13,r0
L_060B68AC:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68AC bt/s 0x060B693C ; swap.w r4,r3
L_060B68B0:
    c.r[4] -= c.r[2];  // 060B68B0 sub r2,r4
L_060B68B2:
    c.r[10] += c.r[4];  // 060B68B2 add r4,r10
L_060B68B4:
    c.t = c.r[10] > c.r[12];  // 060B68B4 cmp/hi r12,r10
L_060B68B6:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B68B6 bt/s 0x060B693C ; mov r6,r9
L_060B68BA:
    c.r[6] -= c.r[8];  // 060B68BA sub r8,r6
L_060B68BC:
    c.r[11] += c.r[6];  // 060B68BC add r6,r11
L_060B68BE:
    c.t = c.r[11] > c.r[13];  // 060B68BE cmp/hi r13,r11
L_060B68C0:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68C0 bt/s 0x060B693C ; swap.w r4,r4
L_060B68C4:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B68C4 bra 0x060B65B4 ; xtrct r4,r6
L_060B693C:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B693C mov.l @r15+,r8
L_060B693E:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B693E mov.l @r15+,r9
L_060B6940:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6940 mov.l @r15+,r10
L_060B6942:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6942 mov.l @r15+,r11
L_060B6944:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B6944 mov.l @r15+,r12
L_060B6946:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B6946 mov.l @r15+,r13
L_060B6948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B6948 mov.l @r15+,r14
L_060B694A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B694A rts ; mov #0,r0
}

void f_060B68C8(SH2Context& c) {
    ran[3120] = 1;
    goto L_060B68C8;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B68C8u: goto L_060B68C8; case 0x060B68CAu: goto L_060B68CA; case 0x060B68CCu: goto L_060B68CC; case 0x060B68CEu: goto L_060B68CE; case 0x060B68D0u: goto L_060B68D0; case 0x060B68D2u: goto L_060B68D2; case 0x060B68D4u: goto L_060B68D4; case 0x060B68D6u: goto L_060B68D6; case 0x060B68D8u: goto L_060B68D8; case 0x060B68DAu: goto L_060B68DA; case 0x060B68DCu: goto L_060B68DC; case 0x060B68E0u: goto L_060B68E0; case 0x060B68E2u: goto L_060B68E2; case 0x060B68E4u: goto L_060B68E4; case 0x060B68E6u: goto L_060B68E6; case 0x060B68E8u: goto L_060B68E8; case 0x060B68EAu: goto L_060B68EA; case 0x060B68EEu: goto L_060B68EE; case 0x060B68F0u: goto L_060B68F0; case 0x060B68F2u: goto L_060B68F2; case 0x060B68F4u: goto L_060B68F4; case 0x060B68F6u: goto L_060B68F6; case 0x060B68FAu: goto L_060B68FA; case 0x060B68FCu: goto L_060B68FC; case 0x060B68FEu: goto L_060B68FE; case 0x060B6900u: goto L_060B6900; case 0x060B6902u: goto L_060B6902; case 0x060B6904u: goto L_060B6904; case 0x060B6908u: goto L_060B6908; case 0x060B690Au: goto L_060B690A; case 0x060B690Cu: goto L_060B690C; case 0x060B690Eu: goto L_060B690E; case 0x060B6910u: goto L_060B6910; case 0x060B6912u: goto L_060B6912; case 0x060B6914u: goto L_060B6914; case 0x060B6916u: goto L_060B6916; case 0x060B691Au: goto L_060B691A; case 0x060B691Cu: goto L_060B691C; case 0x060B691Eu: goto L_060B691E; case 0x060B6920u: goto L_060B6920; case 0x060B6924u: goto L_060B6924; case 0x060B6926u: goto L_060B6926; case 0x060B6928u: goto L_060B6928; case 0x060B692Au: goto L_060B692A; case 0x060B692Eu: goto L_060B692E; case 0x060B6930u: goto L_060B6930; case 0x060B6932u: goto L_060B6932; case 0x060B6934u: goto L_060B6934; case 0x060B6938u: goto L_060B6938; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B68C8:
    c.r[1] = 0x20u;  // 060B68C8 mov #32,r1
L_060B68CA:
    c.r[5] ^= c.r[1];  // 060B68CA xor r1,r5
L_060B68CC:
    c.r[3] = 0u - c.r[3];  // 060B68CC neg r3,r3
L_060B68CE:
    c.r[9] = 0u - c.r[9];  // 060B68CE neg r9,r9
L_060B68D0:
    c.r[0] = c.r[2];  // 060B68D0 mov r2,r0
L_060B68D2:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68D2 shar r0
L_060B68D4:
    c.r[4] -= c.r[0];  // 060B68D4 sub r0,r4
L_060B68D6:
    c.r[0] = c.r[4];  // 060B68D6 mov r4,r0
L_060B68D8:
    c.r[0] += c.r[10];  // 060B68D8 add r10,r0
L_060B68DA:
    c.t = c.r[0] > c.r[12];  // 060B68DA cmp/hi r12,r0
L_060B68DC:
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060B693C; } }  // 060B68DC bt/s 0x060B693C ; mov r8,r0
L_060B68E0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68E0 shar r0
L_060B68E2:
    c.r[6] -= c.r[0];  // 060B68E2 sub r0,r6
L_060B68E4:
    c.r[0] = c.r[6];  // 060B68E4 mov r6,r0
L_060B68E6:
    c.r[0] += c.r[11];  // 060B68E6 add r11,r0
L_060B68E8:
    c.t = c.r[0] > c.r[13];  // 060B68E8 cmp/hi r13,r0
L_060B68EA:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68EA bt/s 0x060B693C ; swap.w r4,r1
L_060B68EE:
    c.r[4] += c.r[2];  // 060B68EE add r2,r4
L_060B68F0:
    c.r[0] = c.r[4];  // 060B68F0 mov r4,r0
L_060B68F2:
    c.r[0] += c.r[10];  // 060B68F2 add r10,r0
L_060B68F4:
    c.t = c.r[0] > c.r[12];  // 060B68F4 cmp/hi r12,r0
L_060B68F6:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B68F6 bt/s 0x060B693C ; mov.w r5,@r7
L_060B68FA:
    c.r[5] = c.r[6];  // 060B68FA mov r6,r5
L_060B68FC:
    c.r[6] += c.r[8];  // 060B68FC add r8,r6
L_060B68FE:
    c.r[0] = c.r[6];  // 060B68FE mov r6,r0
L_060B6900:
    c.r[0] += c.r[11];  // 060B6900 add r11,r0
L_060B6902:
    c.t = c.r[0] > c.r[13];  // 060B6902 cmp/hi r13,r0
L_060B6904:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6904 bt/s 0x060B693C ; swap.w r4,r0
L_060B6908:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6908 xtrct r1,r5
L_060B690A:
    c.r[1] = c.r[6];  // 060B690A mov r6,r1
L_060B690C:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B690C xtrct r0,r1
L_060B690E:
    c.r[4] -= c.r[9];  // 060B690E sub r9,r4
L_060B6910:
    c.r[0] = c.r[4];  // 060B6910 mov r4,r0
L_060B6912:
    c.r[0] += c.r[10];  // 060B6912 add r10,r0
L_060B6914:
    c.t = c.r[0] > c.r[12];  // 060B6914 cmp/hi r12,r0
L_060B6916:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B6916 bt/s 0x060B693C ; add r3,r6
L_060B691A:
    c.r[0] = c.r[6];  // 060B691A mov r6,r0
L_060B691C:
    c.r[0] += c.r[11];  // 060B691C add r11,r0
L_060B691E:
    c.t = c.r[0] > c.r[13];  // 060B691E cmp/hi r13,r0
L_060B6920:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6920 bt/s 0x060B693C ; swap.w r4,r3
L_060B6924:
    c.r[4] -= c.r[2];  // 060B6924 sub r2,r4
L_060B6926:
    c.r[10] += c.r[4];  // 060B6926 add r4,r10
L_060B6928:
    c.t = c.r[10] > c.r[12];  // 060B6928 cmp/hi r12,r10
L_060B692A:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B692A bt/s 0x060B693C ; mov r6,r9
L_060B692E:
    c.r[6] -= c.r[8];  // 060B692E sub r8,r6
L_060B6930:
    c.r[11] += c.r[6];  // 060B6930 add r6,r11
L_060B6932:
    c.t = c.r[11] > c.r[13];  // 060B6932 cmp/hi r13,r11
L_060B6934:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6934 bt/s 0x060B693C ; swap.w r4,r4
L_060B6938:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B6938 bra 0x060B65B4 ; xtrct r4,r6
L_060B693C:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B693C mov.l @r15+,r8
L_060B693E:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B693E mov.l @r15+,r9
L_060B6940:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6940 mov.l @r15+,r10
L_060B6942:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6942 mov.l @r15+,r11
L_060B6944:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B6944 mov.l @r15+,r12
L_060B6946:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B6946 mov.l @r15+,r13
L_060B6948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B6948 mov.l @r15+,r14
L_060B694A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B694A rts ; mov #0,r0
}

void f_060B68D0(SH2Context& c) {
    ran[3121] = 1;
    goto L_060B68D0;
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B68D0u: goto L_060B68D0; case 0x060B68D2u: goto L_060B68D2; case 0x060B68D4u: goto L_060B68D4; case 0x060B68D6u: goto L_060B68D6; case 0x060B68D8u: goto L_060B68D8; case 0x060B68DAu: goto L_060B68DA; case 0x060B68DCu: goto L_060B68DC; case 0x060B68E0u: goto L_060B68E0; case 0x060B68E2u: goto L_060B68E2; case 0x060B68E4u: goto L_060B68E4; case 0x060B68E6u: goto L_060B68E6; case 0x060B68E8u: goto L_060B68E8; case 0x060B68EAu: goto L_060B68EA; case 0x060B68EEu: goto L_060B68EE; case 0x060B68F0u: goto L_060B68F0; case 0x060B68F2u: goto L_060B68F2; case 0x060B68F4u: goto L_060B68F4; case 0x060B68F6u: goto L_060B68F6; case 0x060B68FAu: goto L_060B68FA; case 0x060B68FCu: goto L_060B68FC; case 0x060B68FEu: goto L_060B68FE; case 0x060B6900u: goto L_060B6900; case 0x060B6902u: goto L_060B6902; case 0x060B6904u: goto L_060B6904; case 0x060B6908u: goto L_060B6908; case 0x060B690Au: goto L_060B690A; case 0x060B690Cu: goto L_060B690C; case 0x060B690Eu: goto L_060B690E; case 0x060B6910u: goto L_060B6910; case 0x060B6912u: goto L_060B6912; case 0x060B6914u: goto L_060B6914; case 0x060B6916u: goto L_060B6916; case 0x060B691Au: goto L_060B691A; case 0x060B691Cu: goto L_060B691C; case 0x060B691Eu: goto L_060B691E; case 0x060B6920u: goto L_060B6920; case 0x060B6924u: goto L_060B6924; case 0x060B6926u: goto L_060B6926; case 0x060B6928u: goto L_060B6928; case 0x060B692Au: goto L_060B692A; case 0x060B692Eu: goto L_060B692E; case 0x060B6930u: goto L_060B6930; case 0x060B6932u: goto L_060B6932; case 0x060B6934u: goto L_060B6934; case 0x060B6938u: goto L_060B6938; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B68D0:
    c.r[0] = c.r[2];  // 060B68D0 mov r2,r0
L_060B68D2:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68D2 shar r0
L_060B68D4:
    c.r[4] -= c.r[0];  // 060B68D4 sub r0,r4
L_060B68D6:
    c.r[0] = c.r[4];  // 060B68D6 mov r4,r0
L_060B68D8:
    c.r[0] += c.r[10];  // 060B68D8 add r10,r0
L_060B68DA:
    c.t = c.r[0] > c.r[12];  // 060B68DA cmp/hi r12,r0
L_060B68DC:
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060B693C; } }  // 060B68DC bt/s 0x060B693C ; mov r8,r0
L_060B68E0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68E0 shar r0
L_060B68E2:
    c.r[6] -= c.r[0];  // 060B68E2 sub r0,r6
L_060B68E4:
    c.r[0] = c.r[6];  // 060B68E4 mov r6,r0
L_060B68E6:
    c.r[0] += c.r[11];  // 060B68E6 add r11,r0
L_060B68E8:
    c.t = c.r[0] > c.r[13];  // 060B68E8 cmp/hi r13,r0
L_060B68EA:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68EA bt/s 0x060B693C ; swap.w r4,r1
L_060B68EE:
    c.r[4] += c.r[2];  // 060B68EE add r2,r4
L_060B68F0:
    c.r[0] = c.r[4];  // 060B68F0 mov r4,r0
L_060B68F2:
    c.r[0] += c.r[10];  // 060B68F2 add r10,r0
L_060B68F4:
    c.t = c.r[0] > c.r[12];  // 060B68F4 cmp/hi r12,r0
L_060B68F6:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B68F6 bt/s 0x060B693C ; mov.w r5,@r7
L_060B68FA:
    c.r[5] = c.r[6];  // 060B68FA mov r6,r5
L_060B68FC:
    c.r[6] += c.r[8];  // 060B68FC add r8,r6
L_060B68FE:
    c.r[0] = c.r[6];  // 060B68FE mov r6,r0
L_060B6900:
    c.r[0] += c.r[11];  // 060B6900 add r11,r0
L_060B6902:
    c.t = c.r[0] > c.r[13];  // 060B6902 cmp/hi r13,r0
L_060B6904:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6904 bt/s 0x060B693C ; swap.w r4,r0
L_060B6908:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6908 xtrct r1,r5
L_060B690A:
    c.r[1] = c.r[6];  // 060B690A mov r6,r1
L_060B690C:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B690C xtrct r0,r1
L_060B690E:
    c.r[4] -= c.r[9];  // 060B690E sub r9,r4
L_060B6910:
    c.r[0] = c.r[4];  // 060B6910 mov r4,r0
L_060B6912:
    c.r[0] += c.r[10];  // 060B6912 add r10,r0
L_060B6914:
    c.t = c.r[0] > c.r[12];  // 060B6914 cmp/hi r12,r0
L_060B6916:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B6916 bt/s 0x060B693C ; add r3,r6
L_060B691A:
    c.r[0] = c.r[6];  // 060B691A mov r6,r0
L_060B691C:
    c.r[0] += c.r[11];  // 060B691C add r11,r0
L_060B691E:
    c.t = c.r[0] > c.r[13];  // 060B691E cmp/hi r13,r0
L_060B6920:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6920 bt/s 0x060B693C ; swap.w r4,r3
L_060B6924:
    c.r[4] -= c.r[2];  // 060B6924 sub r2,r4
L_060B6926:
    c.r[10] += c.r[4];  // 060B6926 add r4,r10
L_060B6928:
    c.t = c.r[10] > c.r[12];  // 060B6928 cmp/hi r12,r10
L_060B692A:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B692A bt/s 0x060B693C ; mov r6,r9
L_060B692E:
    c.r[6] -= c.r[8];  // 060B692E sub r8,r6
L_060B6930:
    c.r[11] += c.r[6];  // 060B6930 add r6,r11
L_060B6932:
    c.t = c.r[11] > c.r[13];  // 060B6932 cmp/hi r13,r11
L_060B6934:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6934 bt/s 0x060B693C ; swap.w r4,r4
L_060B6938:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B6938 bra 0x060B65B4 ; xtrct r4,r6
L_060B693C:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B693C mov.l @r15+,r8
L_060B693E:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B693E mov.l @r15+,r9
L_060B6940:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6940 mov.l @r15+,r10
L_060B6942:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6942 mov.l @r15+,r11
L_060B6944:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B6944 mov.l @r15+,r12
L_060B6946:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B6946 mov.l @r15+,r13
L_060B6948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B6948 mov.l @r15+,r14
L_060B694A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B694A rts ; mov #0,r0
}

void f_060B6950(SH2Context& c) {
    ran[3122] = 1;
    c.r[0] = c.r[4];  // 060B6950 mov r4,r0
    st32(c.gbr + 528, c.r[0]);  // 060B6952 mov.l r0,@(528,gbr)
    c.r[0] = ld32(0x060B69ECu);  // 060B6954 mov.l 0x060B69EC,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B6956 sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060B695Cu; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060B695Cu) return; }  // 060B6958 jsr @r0 ; mov #2,r5
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B695C lds.l @r15+,pr
    c.r[3] = 0xBu;  // 060B695E mov #11,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 248);  // 060B6960 mov.w @(248,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B69E8u);  // 060B6962 mov.w 0x060B69E8,r1
    c.t = (c.r[0] & c.r[1]) == 0;  // 060B6964 tst r1,r0
    if (!c.t) { goto L_060B696A; }  // 060B6966 bf 0x060B696A
    c.r[3] += 1;  // 060B6968 add #1,r3
L_060B696A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 234);  // 060B696A mov.w @(234,gbr),r0
    c.r[0] >>= 8;  // 060B696C shlr8 r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060B696E tst #1,r0
    if (!c.t) { goto L_060B6974; }  // 060B6970 bf 0x060B6974
    c.r[3] += 2;  // 060B6972 add #2,r3
L_060B6974:
    c.r[0] = c.r[3];  // 060B6974 mov r3,r0
    c.r[0] += 6;  // 060B6976 add #6,r0
    c.r[2] = c.r[4];  // 060B6978 mov r4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060B697A tst #16,r0
    if (c.t) { goto L_060B6980; }  // 060B697C bt 0x060B6980
    c.r[2] >>= 16;  // 060B697E shlr16 r2
L_060B6980:
    c.t = (c.r[0] & 0x8u) == 0;  // 060B6980 tst #8,r0
    if (c.t) { goto L_060B6986; }  // 060B6982 bt 0x060B6986
    c.r[2] >>= 8;  // 060B6984 shlr8 r2
L_060B6986:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B6986 tst #4,r0
    if (c.t) { goto L_060B698E; }  // 060B6988 bt 0x060B698E
    c.r[2] >>= 2;  // 060B698A shlr2 r2
    c.r[2] >>= 2;  // 060B698C shlr2 r2
L_060B698E:
    c.t = (c.r[0] & 0x2u) == 0;  // 060B698E tst #2,r0
    if (c.t) { goto L_060B6994; }  // 060B6990 bt 0x060B6994
    c.r[2] >>= 2;  // 060B6992 shlr2 r2
L_060B6994:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6994 tst #1,r0
    if (c.t) { goto L_060B699A; }  // 060B6996 bt 0x060B699A
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060B6998 shlr r2
L_060B699A:
    c.r[1] = 0x7u;  // 060B699A mov #7,r1
    c.r[2] &= c.r[1];  // 060B699C and r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 255);  // 060B699E mov.b @(255,gbr),r0
    c.r[2] <<= 2;  // 060B69A0 shll2 r2
    c.r[0] &= 0xFu;  // 060B69A2 and #15,r0
    c.r[2] <<= 2;  // 060B69A4 shll2 r2
    c.r[0] |= c.r[2];  // 060B69A6 or r2,r0
    st8(c.gbr + 255, c.r[0]);  // 060B69A8 mov.b r0,@(255,gbr)
    c.r[0] = c.r[3];  // 060B69AA mov r3,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060B69AC tst #16,r0
    if (c.t) { goto L_060B69B2; }  // 060B69AE bt 0x060B69B2
    c.r[4] >>= 16;  // 060B69B0 shlr16 r4
L_060B69B2:
    c.t = (c.r[0] & 0x8u) == 0;  // 060B69B2 tst #8,r0
    if (c.t) { goto L_060B69B8; }  // 060B69B4 bt 0x060B69B8
    c.r[4] >>= 8;  // 060B69B6 shlr8 r4
L_060B69B8:
    c.t = (c.r[0] & 0x4u) == 0;  // 060B69B8 tst #4,r0
    if (c.t) { goto L_060B69C0; }  // 060B69BA bt 0x060B69C0
    c.r[4] >>= 2;  // 060B69BC shlr2 r4
    c.r[4] >>= 2;  // 060B69BE shlr2 r4
L_060B69C0:
    c.t = (c.r[0] & 0x2u) == 0;  // 060B69C0 tst #2,r0
    if (c.t) { goto L_060B69C6; }  // 060B69C2 bt 0x060B69C6
    c.r[4] >>= 2;  // 060B69C4 shlr2 r4
L_060B69C6:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B69C6 tst #1,r0
    if (c.t) { goto L_060B69CC; }  // 060B69C8 bt 0x060B69CC
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B69CA shlr r4
L_060B69CC:
    c.r[1] = 0x3Fu;  // 060B69CC mov #63,r1
    c.r[4] &= c.r[1];  // 060B69CE and r1,r4
    c.r[0] = c.r[4];  // 060B69D0 mov r4,r0
    c.r[0] <<= 8;  // 060B69D2 shll8 r0
    c.r[0] |= c.r[4];  // 060B69D4 or r4,r0
    st16(c.gbr + 288, c.r[0]);  // 060B69D6 mov.w r0,@(288,gbr)
    st16(c.gbr + 290, c.r[0]);  // 060B69D8 mov.w r0,@(290,gbr)
    st16(c.gbr + 292, c.r[0]);  // 060B69DA mov.w r0,@(292,gbr)
    st16(c.gbr + 294, c.r[0]);  // 060B69DC mov.w r0,@(294,gbr)
    st16(c.gbr + 296, c.r[0]);  // 060B69DE mov.w r0,@(296,gbr)
    st16(c.gbr + 298, c.r[0]);  // 060B69E0 mov.w r0,@(298,gbr)
    st16(c.gbr + 300, c.r[0]);  // 060B69E2 mov.w r0,@(300,gbr)
    { const uint32_t x = c.pr; st16(c.gbr + 302, c.r[0]); c.pc = x; return; }  // 060B69E4 rts ; mov.w r0,@(302,gbr)
}

void f_060B69F0(SH2Context& c) {
    ran[3123] = 1;
    c.r[3] = 0x2u;  // 060B69F0 mov #2,r3
    c.r[0] = 0x0u;  // 060B69F2 mov #0,r0
    c.r[2] = 0x0u;  // 060B69F4 mov #0,r2
    c.r[1] = 0x10u;  // 060B69F6 mov #16,r1
L_060B69F8:
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060B69F8 shll r4
    { uint32_t t = c.r[2] >> 31; c.r[2] = c.r[2] << 1 | c.t; c.t = t; }  // 060B69FA rotcl r2
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060B69FC shll r4
    { uint32_t t = c.r[2] >> 31; c.r[2] = c.r[2] << 1 | c.t; c.t = t; }  // 060B69FE rotcl r2
    c.r[0] += c.r[0];  // 060B6A00 add r0,r0
    c.r[0] += 1;  // 060B6A02 add #1,r0
    c.t = c.r[0] > c.r[2];  // 060B6A04 cmp/hi r2,r0
    { const bool k = c.t; c.r[1] -= 1; c.t = c.r[1] == 0; if (k) { goto L_060B6A14; } }  // 060B6A06 bt/s 0x060B6A14 ; dt r1
    c.r[2] -= c.r[0];  // 060B6A0A sub r0,r2
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060B69F8; } }  // 060B6A0C bf/s 0x060B69F8 ; add #1,r0
    c.r[4] = c.r[5]; goto L_060B6A1A;  // 060B6A10 bra 0x060B6A1A ; mov r5,r4
L_060B6A14:
    { const bool k = !c.t; c.r[0] -= 1; if (k) { SH2_POLL(c); goto L_060B69F8; } }  // 060B6A14 bf/s 0x060B69F8 ; add #-1,r0
    c.r[4] = c.r[5];  // 060B6A18 mov r5,r4
L_060B6A1A:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060B6A1A dt r3
    { const bool k = !c.t; c.r[1] = 0xFu; if (k) { SH2_POLL(c); goto L_060B69F8; } }  // 060B6A1C bf/s 0x060B69F8 ; mov #15,r1
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B6A20 rts ; nop
}

void f_060B6A24(SH2Context& c) {
    ran[3124] = 1;
L_060B6A24:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B6A24 sts.l pr,@-r15
L_060B6A26:
    c.r[10] = ld32(c.r[4]); c.r[4] += 4;  // 060B6A26 mov.l @r4+,r10
L_060B6A28:
    c.r[0] <<= 2;  // 060B6A28 shll2 r0
L_060B6A2A:
    c.r[0] <<= 2;  // 060B6A2A shll2 r0
L_060B6A2C:
    c.r[0] += c.r[10];  // 060B6A2C add r10,r0
L_060B6A2E:
    st32(c.gbr + 40, c.r[0]);  // 060B6A2E mov.l r0,@(40,gbr)
L_060B6A30:
    c.r[1] = 0xFFFFFFA4u;  // 060B6A30 mov #-92,r1
L_060B6A32:
    c.r[1] <<= 2;  // 060B6A32 shll2 r1
L_060B6A34:
    c.r[0] = 0x11u;  // 060B6A34 mov #17,r0
L_060B6A36:
    st8(c.r[1] + 2, c.r[0]);  // 060B6A36 mov.b r0,@(2,r1)
L_060B6A38:
    ;  // 060B6A38 nop
L_060B6A3A:
    ;  // 060B6A3A nop
L_060B6A3C:
    ;  // 060B6A3C nop
L_060B6A3E:
    ;  // 060B6A3E nop
L_060B6A40:
    ;  // 060B6A40 nop
L_060B6A42:
    ;  // 060B6A42 nop
L_060B6A44:
    c.r[0] = 0x060B6D90u;  // 060B6A44 mova 0x060B6D90,r0
L_060B6A46:
    c.r[5] = c.r[4];  // 060B6A46 mov r4,r5
L_060B6A48:
    c.r[5] += 12;  // 060B6A48 add #12,r5
L_060B6A4A:
    c.r[6] = c.r[0];  // 060B6A4A mov r0,r6
L_060B6A4C:
    c.r[0] = ld32(c.r[5]);  // 060B6A4C mov.l @(0,r5),r0
L_060B6A4E:
    c.r[1] = ld32(c.r[5] + 4);  // 060B6A4E mov.l @(4,r5),r1
L_060B6A50:
    c.r[2] = ld32(c.r[5] + 8);  // 060B6A50 mov.l @(8,r5),r2
L_060B6A52:
    st32(c.r[6], c.r[0]);  // 060B6A52 mov.l r0,@(0,r6)
L_060B6A54:
    st32(c.r[6] + 4, c.r[1]);  // 060B6A54 mov.l r1,@(4,r6)
L_060B6A56:
    st32(c.r[6] + 8, c.r[2]);  // 060B6A56 mov.l r2,@(8,r6)
L_060B6A58:
    c.r[0] = ld32(c.r[5] + 16);  // 060B6A58 mov.l @(16,r5),r0
L_060B6A5A:
    c.r[1] = ld32(c.r[5] + 20);  // 060B6A5A mov.l @(20,r5),r1
L_060B6A5C:
    c.r[2] = ld32(c.r[5] + 24);  // 060B6A5C mov.l @(24,r5),r2
L_060B6A5E:
    st32(c.r[6] + 16, c.r[0]);  // 060B6A5E mov.l r0,@(16,r6)
L_060B6A60:
    st32(c.r[6] + 20, c.r[1]);  // 060B6A60 mov.l r1,@(20,r6)
L_060B6A62:
    st32(c.r[6] + 24, c.r[2]);  // 060B6A62 mov.l r2,@(24,r6)
L_060B6A64:
    c.r[0] = ld32(c.r[5] + 32);  // 060B6A64 mov.l @(32,r5),r0
L_060B6A66:
    c.r[1] = ld32(c.r[5] + 36);  // 060B6A66 mov.l @(36,r5),r1
L_060B6A68:
    c.r[2] = ld32(c.r[5] + 40);  // 060B6A68 mov.l @(40,r5),r2
L_060B6A6A:
    st32(c.r[6] + 32, c.r[0]);  // 060B6A6A mov.l r0,@(32,r6)
L_060B6A6C:
    st32(c.r[6] + 36, c.r[1]);  // 060B6A6C mov.l r1,@(36,r6)
L_060B6A6E:
    st32(c.r[6] + 40, c.r[2]);  // 060B6A6E mov.l r2,@(40,r6)
L_060B6A70:
    c.r[6] += 0; goto L_060B6DC4;  // 060B6A70 bra 0x060B6DC4 ; add #0,r6
L_060B6DC4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B6DC4 mov.b @(169,gbr),r0
L_060B6DC6:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6DC6 tst #1,r0
L_060B6DC8:
    { const bool k = !c.t; c.r[1] = 0x20u; if (k) { goto L_060B6DCE; } }  // 060B6DC8 bf/s 0x060B6DCE ; mov #32,r1
L_060B6DCC:
    c.r[1] = 0x10u;  // 060B6DCC mov #16,r1
L_060B6DCE:
    c.r[0] |= c.r[1];  // 060B6DCE or r1,r0
L_060B6DD0:
    st8(c.gbr + 169, c.r[0]);  // 060B6DD0 mov.b r0,@(169,gbr)
L_060B6DD2:
    c.r[0] = ld32(c.gbr + 52);  // 060B6DD2 mov.l @(52,gbr),r0
L_060B6DD4:
    c.r[3] = ld32(c.r[4]); c.r[4] += 4;  // 060B6DD4 mov.l @r4+,r3
L_060B6DD6:
    c.r[7] = ld32(c.r[4]); c.r[4] += 4;  // 060B6DD6 mov.l @r4+,r7
L_060B6DD8:
    c.r[8] = ld32(c.r[4]); c.r[4] += 4;  // 060B6DD8 mov.l @r4+,r8
L_060B6DDA:
    c.r[11] = c.r[0];  // 060B6DDA mov r0,r11
L_060B6DDC:
    c.r[0] = ld32(c.gbr + 60);  // 060B6DDC mov.l @(60,gbr),r0
L_060B6DDE:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B6DDE mov.l r4,@-r15
L_060B6DE0:
    c.r[0] += 4;  // 060B6DE0 add #4,r0
L_060B6DE2:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B6DE2 mov.l r0,@-r15
L_060B6DE4:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B6DE4 mov.l r3,@-r15
L_060B6DE6:
    c.r[0] = ld32(c.gbr + 108);  // 060B6DE6 mov.l @(108,gbr),r0
L_060B6DE8:
    c.r[14] = 0xFFFFFFFFu;  // 060B6DE8 mov #-1,r14
L_060B6DEA:
    c.r[1] = c.r[0];  // 060B6DEA mov r0,r1
L_060B6DEC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 173);  // 060B6DEC mov.b @(173,gbr),r0
L_060B6DEE:
    c.r[1] >>= 16;  // 060B6DEE shlr16 r1
L_060B6DF0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6DF0 dt r0
L_060B6DF2:
    { const bool k = !c.t; c.t = c.r[1] & 1; c.r[1] >>= 1; if (k) { SH2_POLL(c); goto L_060B6DF0; } }  // 060B6DF2 bf/s 0x060B6DF0 ; shlr r1
L_060B6DF6:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B6DF6 mov.l r1,@-r15
L_060B6DF8:
    c.r[15] -= 12;  // 060B6DF8 add #-12,r15
L_060B6DFA:
    c.r[0] = 0x060B6EA8u;  // 060B6DFA mova 0x060B6EA8,r0
L_060B6DFC:
    c.pr = c.r[0];  // 060B6DFC lds r0,pr
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6A24u: goto L_060B6A24; case 0x060B6A26u: goto L_060B6A26; case 0x060B6A28u: goto L_060B6A28; case 0x060B6A2Au: goto L_060B6A2A; case 0x060B6A2Cu: goto L_060B6A2C; case 0x060B6A2Eu: goto L_060B6A2E; case 0x060B6A30u: goto L_060B6A30; case 0x060B6A32u: goto L_060B6A32; case 0x060B6A34u: goto L_060B6A34; case 0x060B6A36u: goto L_060B6A36; case 0x060B6A38u: goto L_060B6A38; case 0x060B6A3Au: goto L_060B6A3A; case 0x060B6A3Cu: goto L_060B6A3C; case 0x060B6A3Eu: goto L_060B6A3E; case 0x060B6A40u: goto L_060B6A40; case 0x060B6A42u: goto L_060B6A42; case 0x060B6A44u: goto L_060B6A44; case 0x060B6A46u: goto L_060B6A46; case 0x060B6A48u: goto L_060B6A48; case 0x060B6A4Au: goto L_060B6A4A; case 0x060B6A4Cu: goto L_060B6A4C; case 0x060B6A4Eu: goto L_060B6A4E; case 0x060B6A50u: goto L_060B6A50; case 0x060B6A52u: goto L_060B6A52; case 0x060B6A54u: goto L_060B6A54; case 0x060B6A56u: goto L_060B6A56; case 0x060B6A58u: goto L_060B6A58; case 0x060B6A5Au: goto L_060B6A5A; case 0x060B6A5Cu: goto L_060B6A5C; case 0x060B6A5Eu: goto L_060B6A5E; case 0x060B6A60u: goto L_060B6A60; case 0x060B6A62u: goto L_060B6A62; case 0x060B6A64u: goto L_060B6A64; case 0x060B6A66u: goto L_060B6A66; case 0x060B6A68u: goto L_060B6A68; case 0x060B6A6Au: goto L_060B6A6A; case 0x060B6A6Cu: goto L_060B6A6C; case 0x060B6A6Eu: goto L_060B6A6E; case 0x060B6A70u: goto L_060B6A70; case 0x060B6DC4u: goto L_060B6DC4; case 0x060B6DC6u: goto L_060B6DC6; case 0x060B6DC8u: goto L_060B6DC8; case 0x060B6DCCu: goto L_060B6DCC; case 0x060B6DCEu: goto L_060B6DCE; case 0x060B6DD0u: goto L_060B6DD0; case 0x060B6DD2u: goto L_060B6DD2; case 0x060B6DD4u: goto L_060B6DD4; case 0x060B6DD6u: goto L_060B6DD6; case 0x060B6DD8u: goto L_060B6DD8; case 0x060B6DDAu: goto L_060B6DDA; case 0x060B6DDCu: goto L_060B6DDC; case 0x060B6DDEu: goto L_060B6DDE; case 0x060B6DE0u: goto L_060B6DE0; case 0x060B6DE2u: goto L_060B6DE2; case 0x060B6DE4u: goto L_060B6DE4; case 0x060B6DE6u: goto L_060B6DE6; case 0x060B6DE8u: goto L_060B6DE8; case 0x060B6DEAu: goto L_060B6DEA; case 0x060B6DECu: goto L_060B6DEC; case 0x060B6DEEu: goto L_060B6DEE; case 0x060B6DF0u: goto L_060B6DF0; case 0x060B6DF2u: goto L_060B6DF2; case 0x060B6DF6u: goto L_060B6DF6; case 0x060B6DF8u: goto L_060B6DF8; case 0x060B6DFAu: goto L_060B6DFA; case 0x060B6DFCu: goto L_060B6DFC; case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6A24u: goto L_060B6A24; case 0x060B6A26u: goto L_060B6A26; case 0x060B6A28u: goto L_060B6A28; case 0x060B6A2Au: goto L_060B6A2A; case 0x060B6A2Cu: goto L_060B6A2C; case 0x060B6A2Eu: goto L_060B6A2E; case 0x060B6A30u: goto L_060B6A30; case 0x060B6A32u: goto L_060B6A32; case 0x060B6A34u: goto L_060B6A34; case 0x060B6A36u: goto L_060B6A36; case 0x060B6A38u: goto L_060B6A38; case 0x060B6A3Au: goto L_060B6A3A; case 0x060B6A3Cu: goto L_060B6A3C; case 0x060B6A3Eu: goto L_060B6A3E; case 0x060B6A40u: goto L_060B6A40; case 0x060B6A42u: goto L_060B6A42; case 0x060B6A44u: goto L_060B6A44; case 0x060B6A46u: goto L_060B6A46; case 0x060B6A48u: goto L_060B6A48; case 0x060B6A4Au: goto L_060B6A4A; case 0x060B6A4Cu: goto L_060B6A4C; case 0x060B6A4Eu: goto L_060B6A4E; case 0x060B6A50u: goto L_060B6A50; case 0x060B6A52u: goto L_060B6A52; case 0x060B6A54u: goto L_060B6A54; case 0x060B6A56u: goto L_060B6A56; case 0x060B6A58u: goto L_060B6A58; case 0x060B6A5Au: goto L_060B6A5A; case 0x060B6A5Cu: goto L_060B6A5C; case 0x060B6A5Eu: goto L_060B6A5E; case 0x060B6A60u: goto L_060B6A60; case 0x060B6A62u: goto L_060B6A62; case 0x060B6A64u: goto L_060B6A64; case 0x060B6A66u: goto L_060B6A66; case 0x060B6A68u: goto L_060B6A68; case 0x060B6A6Au: goto L_060B6A6A; case 0x060B6A6Cu: goto L_060B6A6C; case 0x060B6A6Eu: goto L_060B6A6E; case 0x060B6A70u: goto L_060B6A70; case 0x060B6DC4u: goto L_060B6DC4; case 0x060B6DC6u: goto L_060B6DC6; case 0x060B6DC8u: goto L_060B6DC8; case 0x060B6DCCu: goto L_060B6DCC; case 0x060B6DCEu: goto L_060B6DCE; case 0x060B6DD0u: goto L_060B6DD0; case 0x060B6DD2u: goto L_060B6DD2; case 0x060B6DD4u: goto L_060B6DD4; case 0x060B6DD6u: goto L_060B6DD6; case 0x060B6DD8u: goto L_060B6DD8; case 0x060B6DDAu: goto L_060B6DDA; case 0x060B6DDCu: goto L_060B6DDC; case 0x060B6DDEu: goto L_060B6DDE; case 0x060B6DE0u: goto L_060B6DE0; case 0x060B6DE2u: goto L_060B6DE2; case 0x060B6DE4u: goto L_060B6DE4; case 0x060B6DE6u: goto L_060B6DE6; case 0x060B6DE8u: goto L_060B6DE8; case 0x060B6DEAu: goto L_060B6DEA; case 0x060B6DECu: goto L_060B6DEC; case 0x060B6DEEu: goto L_060B6DEE; case 0x060B6DF0u: goto L_060B6DF0; case 0x060B6DF2u: goto L_060B6DF2; case 0x060B6DF6u: goto L_060B6DF6; case 0x060B6DF8u: goto L_060B6DF8; case 0x060B6DFAu: goto L_060B6DFA; case 0x060B6DFCu: goto L_060B6DFC; case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
}

void f_060B6C0C(SH2Context& c) {
    ran[3125] = 1;
    goto L_060B6C0C;
L_060B6A74:
    c.r[0] = ld32(0x060B6D8Cu);  // 060B6A74 mov.l 0x060B6D8C,r0
L_060B6A76:
    c.r[1] = 0x0u;  // 060B6A76 mov #0,r1
L_060B6A78:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[0];  // 060B6A78 cmp/gt r0,r3
L_060B6A7A:
    if (!c.t) { goto L_060B6A84; }  // 060B6A7A bf 0x060B6A84
L_060B6A7C:
    c.r[1] = 0x1u;  // 060B6A7C mov #1,r1
L_060B6A7E:
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B6A7E shar r3
L_060B6A80:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6A78;  // 060B6A80 bra 0x060B6A78 ; shar r5
L_060B6A84:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 060B6A84 cmp/gt r0,r5
L_060B6A86:
    if (!c.t) { goto L_060B6A90; }  // 060B6A86 bf 0x060B6A90
L_060B6A88:
    c.r[1] = 0x1u;  // 060B6A88 mov #1,r1
L_060B6A8A:
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B6A8A shar r3
L_060B6A8C:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6A84;  // 060B6A8C bra 0x060B6A84 ; shar r5
L_060B6A90:
    c.r[0] = 0u - c.r[0];  // 060B6A90 neg r0,r0
L_060B6A92:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[0];  // 060B6A92 cmp/ge r0,r3
L_060B6A94:
    if (c.t) { goto L_060B6A9E; }  // 060B6A94 bt 0x060B6A9E
L_060B6A96:
    c.r[1] = 0x1u;  // 060B6A96 mov #1,r1
L_060B6A98:
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B6A98 shar r3
L_060B6A9A:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6A90;  // 060B6A9A bra 0x060B6A90 ; shar r5
L_060B6A9E:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[0];  // 060B6A9E cmp/ge r0,r5
L_060B6AA0:
    if (c.t) { goto L_060B6AAA; }  // 060B6AA0 bt 0x060B6AAA
L_060B6AA2:
    c.r[1] = 0x1u;  // 060B6AA2 mov #1,r1
L_060B6AA4:
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060B6AA4 shar r3
L_060B6AA6:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6A9E;  // 060B6AA6 bra 0x060B6A9E ; shar r5
L_060B6AAA:
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B6AAA tst r1,r1
L_060B6AAC:
    if (!c.t) { goto L_060B6AB2; }  // 060B6AAC bf 0x060B6AB2
L_060B6AAE:
    goto L_060B6D14;  // 060B6AAE bra 0x060B6D14 ; nop
L_060B6AB2:
    c.r[0] = c.r[3];  // 060B6AB2 mov r3,r0
L_060B6AB4:
    c.r[1] = c.r[5];  // 060B6AB4 mov r5,r1
L_060B6AB6:
    c.r[4] = c.r[3];  // 060B6AB6 mov r3,r4
L_060B6AB8:
    c.r[7] = c.r[5];  // 060B6AB8 mov r5,r7
L_060B6ABA:
    c.t = (int32_t)c.r[0] >= 0;  // 060B6ABA cmp/pz r0
L_060B6ABC:
    if (c.t) { goto L_060B6AC0; }  // 060B6ABC bt 0x060B6AC0
L_060B6ABE:
    c.r[0] = 0u - c.r[0];  // 060B6ABE neg r0,r0
L_060B6AC0:
    c.t = (int32_t)c.r[1] >= 0;  // 060B6AC0 cmp/pz r1
L_060B6AC2:
    if (c.t) { goto L_060B6AC6; }  // 060B6AC2 bt 0x060B6AC6
L_060B6AC4:
    c.r[1] = 0u - c.r[1];  // 060B6AC4 neg r1,r1
L_060B6AC6:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060B6AC6 cmp/ge r0,r1
L_060B6AC8:
    { const bool k = c.t; c.r[0] = 0x4u; if (k) { goto L_060B6B06; } }  // 060B6AC8 bt/s 0x060B6B06 ; mov #4,r0
L_060B6ACC:
    c.t = (int32_t)c.r[3] >= 0;  // 060B6ACC cmp/pz r3
L_060B6ACE:
    if (!c.t) { goto L_060B6AEA; }  // 060B6ACE bf 0x060B6AEA
L_060B6AD0:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6AD0 mov.l 0x060B6D8C,r1
L_060B6AD2:
    c.r[3] += c.r[4];  // 060B6AD2 add r4,r3
L_060B6AD4:
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060B6AD4 cmp/gt r1,r3
L_060B6AD6:
    { const bool k = c.t; c.r[3] -= c.r[4]; if (k) { goto L_060B6ADE; } }  // 060B6AD6 bt/s 0x060B6ADE ; sub r4,r3
L_060B6ADA:
    c.r[5] += c.r[7];  // 060B6ADA add r7,r5
L_060B6ADC:
    c.r[3] += c.r[4];  // 060B6ADC add r4,r3
L_060B6ADE:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B6ADE shar r7
L_060B6AE0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6AE0 dt r0
L_060B6AE2:
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B6AD2; } }  // 060B6AE2 bf/s 0x060B6AD2 ; shar r4
L_060B6AE6:
    goto L_060B6D14;  // 060B6AE6 bra 0x060B6D14 ; nop
L_060B6AEA:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6AEA mov.l 0x060B6D8C,r1
L_060B6AEC:
    c.r[1] = 0u - c.r[1];  // 060B6AEC neg r1,r1
L_060B6AEE:
    c.r[3] += c.r[4];  // 060B6AEE add r4,r3
L_060B6AF0:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060B6AF0 cmp/ge r1,r3
L_060B6AF2:
    { const bool k = !c.t; c.r[3] -= c.r[4]; if (k) { goto L_060B6AFA; } }  // 060B6AF2 bf/s 0x060B6AFA ; sub r4,r3
L_060B6AF6:
    c.r[5] += c.r[7];  // 060B6AF6 add r7,r5
L_060B6AF8:
    c.r[3] += c.r[4];  // 060B6AF8 add r4,r3
L_060B6AFA:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B6AFA shar r7
L_060B6AFC:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6AFC dt r0
L_060B6AFE:
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B6AEE; } }  // 060B6AFE bf/s 0x060B6AEE ; shar r4
L_060B6B02:
    goto L_060B6D14;  // 060B6B02 bra 0x060B6D14 ; nop
L_060B6B06:
    c.t = (int32_t)c.r[5] >= 0;  // 060B6B06 cmp/pz r5
L_060B6B08:
    if (!c.t) { goto L_060B6B24; }  // 060B6B08 bf 0x060B6B24
L_060B6B0A:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6B0A mov.l 0x060B6D8C,r1
L_060B6B0C:
    c.r[5] += c.r[7];  // 060B6B0C add r7,r5
L_060B6B0E:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060B6B0E cmp/gt r1,r5
L_060B6B10:
    { const bool k = c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B6B18; } }  // 060B6B10 bt/s 0x060B6B18 ; sub r7,r5
L_060B6B14:
    c.r[3] += c.r[4];  // 060B6B14 add r4,r3
L_060B6B16:
    c.r[5] += c.r[7];  // 060B6B16 add r7,r5
L_060B6B18:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B6B18 shar r4
L_060B6B1A:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6B1A dt r0
L_060B6B1C:
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B6B0C; } }  // 060B6B1C bf/s 0x060B6B0C ; shar r7
L_060B6B20:
    goto L_060B6D14;  // 060B6B20 bra 0x060B6D14 ; nop
L_060B6B24:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6B24 mov.l 0x060B6D8C,r1
L_060B6B26:
    c.r[1] = 0u - c.r[1];  // 060B6B26 neg r1,r1
L_060B6B28:
    c.r[5] += c.r[7];  // 060B6B28 add r7,r5
L_060B6B2A:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060B6B2A cmp/ge r1,r5
L_060B6B2C:
    { const bool k = !c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B6B34; } }  // 060B6B2C bf/s 0x060B6B34 ; sub r7,r5
L_060B6B30:
    c.r[3] += c.r[4];  // 060B6B30 add r4,r3
L_060B6B32:
    c.r[5] += c.r[7];  // 060B6B32 add r7,r5
L_060B6B34:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B6B34 shar r4
L_060B6B36:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6B36 dt r0
L_060B6B38:
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B6B28; } }  // 060B6B38 bf/s 0x060B6B28 ; shar r7
L_060B6B3C:
    goto L_060B6D14;  // 060B6B3C bra 0x060B6D14 ; nop
L_060B6B40:
    c.r[0] = ld32(0x060B6D8Cu);  // 060B6B40 mov.l 0x060B6D8C,r0
L_060B6B42:
    c.r[1] = 0x0u;  // 060B6B42 mov #0,r1
L_060B6B44:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[0];  // 060B6B44 cmp/gt r0,r2
L_060B6B46:
    if (!c.t) { goto L_060B6B50; }  // 060B6B46 bf 0x060B6B50
L_060B6B48:
    c.r[1] = 0x1u;  // 060B6B48 mov #1,r1
L_060B6B4A:
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B6B4A shar r2
L_060B6B4C:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6B44;  // 060B6B4C bra 0x060B6B44 ; shar r5
L_060B6B50:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 060B6B50 cmp/gt r0,r5
L_060B6B52:
    if (!c.t) { goto L_060B6B5C; }  // 060B6B52 bf 0x060B6B5C
L_060B6B54:
    c.r[1] = 0x1u;  // 060B6B54 mov #1,r1
L_060B6B56:
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B6B56 shar r2
L_060B6B58:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6B50;  // 060B6B58 bra 0x060B6B50 ; shar r5
L_060B6B5C:
    c.r[0] = 0u - c.r[0];  // 060B6B5C neg r0,r0
L_060B6B5E:
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[0];  // 060B6B5E cmp/ge r0,r2
L_060B6B60:
    if (c.t) { goto L_060B6B6A; }  // 060B6B60 bt 0x060B6B6A
L_060B6B62:
    c.r[1] = 0x1u;  // 060B6B62 mov #1,r1
L_060B6B64:
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B6B64 shar r2
L_060B6B66:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6B5C;  // 060B6B66 bra 0x060B6B5C ; shar r5
L_060B6B6A:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[0];  // 060B6B6A cmp/ge r0,r5
L_060B6B6C:
    if (c.t) { goto L_060B6B76; }  // 060B6B6C bt 0x060B6B76
L_060B6B6E:
    c.r[1] = 0x1u;  // 060B6B6E mov #1,r1
L_060B6B70:
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060B6B70 shar r2
L_060B6B72:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1); SH2_POLL(c); goto L_060B6B6A;  // 060B6B72 bra 0x060B6B6A ; shar r5
L_060B6B76:
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B6B76 tst r1,r1
L_060B6B78:
    if (!c.t) { goto L_060B6B7E; }  // 060B6B78 bf 0x060B6B7E
L_060B6B7A:
    goto L_060B6D7A;  // 060B6B7A bra 0x060B6D7A ; nop
L_060B6B7E:
    c.r[0] = c.r[2];  // 060B6B7E mov r2,r0
L_060B6B80:
    c.r[1] = c.r[5];  // 060B6B80 mov r5,r1
L_060B6B82:
    c.r[4] = c.r[2];  // 060B6B82 mov r2,r4
L_060B6B84:
    c.r[7] = c.r[5];  // 060B6B84 mov r5,r7
L_060B6B86:
    c.t = (int32_t)c.r[0] >= 0;  // 060B6B86 cmp/pz r0
L_060B6B88:
    if (c.t) { goto L_060B6B8C; }  // 060B6B88 bt 0x060B6B8C
L_060B6B8A:
    c.r[0] = 0u - c.r[0];  // 060B6B8A neg r0,r0
L_060B6B8C:
    c.t = (int32_t)c.r[1] >= 0;  // 060B6B8C cmp/pz r1
L_060B6B8E:
    if (c.t) { goto L_060B6B92; }  // 060B6B8E bt 0x060B6B92
L_060B6B90:
    c.r[1] = 0u - c.r[1];  // 060B6B90 neg r1,r1
L_060B6B92:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060B6B92 cmp/ge r0,r1
L_060B6B94:
    { const bool k = c.t; c.r[0] = 0x4u; if (k) { goto L_060B6BD2; } }  // 060B6B94 bt/s 0x060B6BD2 ; mov #4,r0
L_060B6B98:
    c.t = (int32_t)c.r[2] >= 0;  // 060B6B98 cmp/pz r2
L_060B6B9A:
    if (!c.t) { goto L_060B6BB6; }  // 060B6B9A bf 0x060B6BB6
L_060B6B9C:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6B9C mov.l 0x060B6D8C,r1
L_060B6B9E:
    c.r[2] += c.r[4];  // 060B6B9E add r4,r2
L_060B6BA0:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060B6BA0 cmp/gt r1,r2
L_060B6BA2:
    { const bool k = c.t; c.r[2] -= c.r[4]; if (k) { goto L_060B6BAA; } }  // 060B6BA2 bt/s 0x060B6BAA ; sub r4,r2
L_060B6BA6:
    c.r[5] += c.r[7];  // 060B6BA6 add r7,r5
L_060B6BA8:
    c.r[2] += c.r[4];  // 060B6BA8 add r4,r2
L_060B6BAA:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B6BAA shar r7
L_060B6BAC:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6BAC dt r0
L_060B6BAE:
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B6B9E; } }  // 060B6BAE bf/s 0x060B6B9E ; shar r4
L_060B6BB2:
    goto L_060B6D7A;  // 060B6BB2 bra 0x060B6D7A ; nop
L_060B6BB6:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6BB6 mov.l 0x060B6D8C,r1
L_060B6BB8:
    c.r[1] = 0u - c.r[1];  // 060B6BB8 neg r1,r1
L_060B6BBA:
    c.r[2] += c.r[4];  // 060B6BBA add r4,r2
L_060B6BBC:
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060B6BBC cmp/ge r1,r2
L_060B6BBE:
    { const bool k = !c.t; c.r[2] -= c.r[4]; if (k) { goto L_060B6BC6; } }  // 060B6BBE bf/s 0x060B6BC6 ; sub r4,r2
L_060B6BC2:
    c.r[5] += c.r[7];  // 060B6BC2 add r7,r5
L_060B6BC4:
    c.r[2] += c.r[4];  // 060B6BC4 add r4,r2
L_060B6BC6:
    c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1);  // 060B6BC6 shar r7
L_060B6BC8:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6BC8 dt r0
L_060B6BCA:
    { const bool k = !c.t; c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1); if (k) { SH2_POLL(c); goto L_060B6BBA; } }  // 060B6BCA bf/s 0x060B6BBA ; shar r4
L_060B6BCE:
    goto L_060B6D7A;  // 060B6BCE bra 0x060B6D7A ; nop
L_060B6BD2:
    c.t = (int32_t)c.r[5] >= 0;  // 060B6BD2 cmp/pz r5
L_060B6BD4:
    if (!c.t) { goto L_060B6BF0; }  // 060B6BD4 bf 0x060B6BF0
L_060B6BD6:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6BD6 mov.l 0x060B6D8C,r1
L_060B6BD8:
    c.r[5] += c.r[7];  // 060B6BD8 add r7,r5
L_060B6BDA:
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060B6BDA cmp/gt r1,r5
L_060B6BDC:
    { const bool k = c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B6BE4; } }  // 060B6BDC bt/s 0x060B6BE4 ; sub r7,r5
L_060B6BE0:
    c.r[2] += c.r[4];  // 060B6BE0 add r4,r2
L_060B6BE2:
    c.r[5] += c.r[7];  // 060B6BE2 add r7,r5
L_060B6BE4:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B6BE4 shar r4
L_060B6BE6:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6BE6 dt r0
L_060B6BE8:
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B6BD8; } }  // 060B6BE8 bf/s 0x060B6BD8 ; shar r7
L_060B6BEC:
    goto L_060B6D7A;  // 060B6BEC bra 0x060B6D7A ; nop
L_060B6BF0:
    c.r[1] = ld32(0x060B6D8Cu);  // 060B6BF0 mov.l 0x060B6D8C,r1
L_060B6BF2:
    c.r[1] = 0u - c.r[1];  // 060B6BF2 neg r1,r1
L_060B6BF4:
    c.r[5] += c.r[7];  // 060B6BF4 add r7,r5
L_060B6BF6:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060B6BF6 cmp/ge r1,r5
L_060B6BF8:
    { const bool k = !c.t; c.r[5] -= c.r[7]; if (k) { goto L_060B6C00; } }  // 060B6BF8 bf/s 0x060B6C00 ; sub r7,r5
L_060B6BFC:
    c.r[2] += c.r[4];  // 060B6BFC add r4,r2
L_060B6BFE:
    c.r[5] += c.r[7];  // 060B6BFE add r7,r5
L_060B6C00:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B6C00 shar r4
L_060B6C02:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6C02 dt r0
L_060B6C04:
    { const bool k = !c.t; c.t = c.r[7] & 1; c.r[7] = (uint32_t)((int32_t)c.r[7] >> 1); if (k) { SH2_POLL(c); goto L_060B6BF4; } }  // 060B6C04 bf/s 0x060B6BF4 ; shar r7
L_060B6C08:
    goto L_060B6D7A;  // 060B6C08 bra 0x060B6D7A ; nop
L_060B6C0C:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B6C0C sts.l pr,@-r15
L_060B6C0E:
    c.r[9] = c.r[0];  // 060B6C0E mov r0,r9
L_060B6C10:
    c.r[0] = ld32(c.gbr + 40);  // 060B6C10 mov.l @(40,gbr),r0
L_060B6C12:
    c.r[2] = c.r[9];  // 060B6C12 mov r9,r2
L_060B6C14:
    c.r[2] <<= 2;  // 060B6C14 shll2 r2
L_060B6C16:
    c.r[11] = c.r[2];  // 060B6C16 mov r2,r11
L_060B6C18:
    c.r[2] += c.r[11];  // 060B6C18 add r11,r2
L_060B6C1A:
    c.r[2] += c.r[11];  // 060B6C1A add r11,r2
L_060B6C1C:
    c.r[11] <<= 2;  // 060B6C1C shll2 r11
L_060B6C1E:
    c.r[11] += c.r[0];  // 060B6C1E add r0,r11
L_060B6C20:
    c.r[1] = ld32(c.r[11] + 12);  // 060B6C20 mov.l @(12,r11),r1
L_060B6C22:
    c.r[14] = 0xFFFFFFFFu;  // 060B6C22 mov #-1,r14
L_060B6C24:
    c.r[0] = ld32(c.gbr + 108);  // 060B6C24 mov.l @(108,gbr),r0
L_060B6C26:
    c.r[14] <<= 8;  // 060B6C26 shll8 r14
L_060B6C28:
    st32(c.r[14], c.r[1]);  // 060B6C28 mov.l r1,@(0,r14)
L_060B6C2A:
    c.r[5] = c.r[0] << 16 | c.r[0] >> 16;  // 060B6C2A swap.w r0,r5
L_060B6C2C:
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B6C2C exts.w r5,r5
L_060B6C2E:
    st32(c.r[14] + 16, c.r[5]);  // 060B6C2E mov.l r5,@(16,r14)
L_060B6C30:
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6C30 exts.w r0,r7
L_060B6C32:
    st32(c.r[14] + 20, c.r[7]);  // 060B6C32 mov.l r7,@(20,r14)
L_060B6C34:
    c.r[8] = c.r[0];  // 060B6C34 mov r0,r8
L_060B6C36:
    c.r[10] = ld32(c.r[4]); c.r[4] += 4;  // 060B6C36 mov.l @r4+,r10
L_060B6C38:
    c.r[2] -= 12;  // 060B6C38 add #-12,r2
L_060B6C3A:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B6C3A mov.l r4,@-r15
L_060B6C3C:
    c.r[10] += c.r[2];  // 060B6C3C add r2,r10
L_060B6C3E:
    c.r[4] += 12;  // 060B6C3E add #12,r4
L_060B6C40:
    c.r[0] = 0x060B6D90u;  // 060B6C40 mova 0x060B6D90,r0
L_060B6C42:
    c.r[6] = c.r[0];  // 060B6C42 mov r0,r6
L_060B6C44:
    c.r[0] = ld32(c.r[4]);  // 060B6C44 mov.l @(0,r4),r0
L_060B6C46:
    c.r[1] = ld32(c.r[4] + 4);  // 060B6C46 mov.l @(4,r4),r1
L_060B6C48:
    c.r[2] = ld32(c.r[4] + 8);  // 060B6C48 mov.l @(8,r4),r2
L_060B6C4A:
    st32(c.r[6], c.r[0]);  // 060B6C4A mov.l r0,@(0,r6)
L_060B6C4C:
    st32(c.r[6] + 4, c.r[1]);  // 060B6C4C mov.l r1,@(4,r6)
L_060B6C4E:
    st32(c.r[6] + 8, c.r[2]);  // 060B6C4E mov.l r2,@(8,r6)
L_060B6C50:
    c.r[0] = ld32(c.r[4] + 16);  // 060B6C50 mov.l @(16,r4),r0
L_060B6C52:
    c.r[1] = ld32(c.r[4] + 20);  // 060B6C52 mov.l @(20,r4),r1
L_060B6C54:
    c.r[2] = ld32(c.r[4] + 24);  // 060B6C54 mov.l @(24,r4),r2
L_060B6C56:
    st32(c.r[6] + 16, c.r[0]);  // 060B6C56 mov.l r0,@(16,r6)
L_060B6C58:
    st32(c.r[6] + 20, c.r[1]);  // 060B6C58 mov.l r1,@(20,r6)
L_060B6C5A:
    st32(c.r[6] + 24, c.r[2]);  // 060B6C5A mov.l r2,@(24,r6)
L_060B6C5C:
    c.r[0] = ld32(c.r[4] + 32);  // 060B6C5C mov.l @(32,r4),r0
L_060B6C5E:
    c.r[1] = ld32(c.r[4] + 36);  // 060B6C5E mov.l @(36,r4),r1
L_060B6C60:
    c.r[2] = ld32(c.r[4] + 40);  // 060B6C60 mov.l @(40,r4),r2
L_060B6C62:
    st32(c.r[6] + 32, c.r[0]);  // 060B6C62 mov.l r0,@(32,r6)
L_060B6C64:
    st32(c.r[6] + 36, c.r[1]);  // 060B6C64 mov.l r1,@(36,r6)
L_060B6C66:
    st32(c.r[6] + 40, c.r[2]);  // 060B6C66 mov.l r2,@(40,r6)
L_060B6C68:
    c.r[0] = ld32(c.r[4] + 12);  // 060B6C68 mov.l @(12,r4),r0
L_060B6C6A:
    c.r[1] = ld32(c.r[4] + 28);  // 060B6C6A mov.l @(28,r4),r1
L_060B6C6C:
    c.r[2] = ld32(c.r[4] + 44);  // 060B6C6C mov.l @(44,r4),r2
L_060B6C6E:
    st32(c.r[6] + 12, c.r[0]);  // 060B6C6E mov.l r0,@(12,r6)
L_060B6C70:
    st32(c.r[6] + 28, c.r[1]);  // 060B6C70 mov.l r1,@(28,r6)
L_060B6C72:
    st32(c.r[6] + 44, c.r[2]);  // 060B6C72 mov.l r2,@(44,r6)
L_060B6C74:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060B6C74 tst r9,r9
L_060B6C76:
    { const bool k = !c.t; c.r[6] += 32; if (k) { goto L_060B6C7E; } }  // 060B6C76 bf/s 0x060B6C7E ; add #32,r6
L_060B6C7A:
    goto L_060B6D80;  // 060B6C7A bra 0x060B6D80 ; nop
L_060B6C7E:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060B6C7E mov.l r5,@-r15
L_060B6C80:
    c.r[0] = c.r[11];  // 060B6C80 mov r11,r0
L_060B6C82:
    st32(c.gbr + 40, c.r[0]);  // 060B6C82 mov.l r0,@(40,gbr)
L_060B6C84:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 173);  // 060B6C84 mov.b @(173,gbr),r0
L_060B6C86:
    c.r[0] += 1;  // 060B6C86 add #1,r0
L_060B6C88:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6C88 shlr r8
L_060B6C8A:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6C8A dt r0
L_060B6C8C:
    { const bool k = !c.t; c.t = c.r[8] & 1; c.r[8] >>= 1; if (k) { SH2_POLL(c); goto L_060B6C8A; } }  // 060B6C8C bf/s 0x060B6C8A ; shlr r8
L_060B6C90:
    c.r[0] = ld32(c.gbr + 816);  // 060B6C90 mov.l @(816,gbr),r0
L_060B6C92:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060B6C92 mov.l r7,@-r15
L_060B6C94:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B6C94 extu.w r0,r13
L_060B6C96:
    c.r[4] = ld32(c.r[11] + 4);  // 060B6C96 mov.l @(4,r11),r4
L_060B6C98:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B6C98 swap.w r0,r12
L_060B6C9A:
    c.r[5] = ld32(c.r[11] + 8);  // 060B6C9A mov.l @(8,r11),r5
L_060B6C9C:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6C9C extu.w r12,r12
L_060B6C9E:
    c.r[0] = ld32(c.gbr + 908);  // 060B6C9E mov.l @(908,gbr),r0
L_060B6CA0:
    c.r[12] += c.r[0];  // 060B6CA0 add r0,r12
L_060B6CA2:
    c.r[13] += c.r[0];  // 060B6CA2 add r0,r13
L_060B6CA4:
    c.r[12] += c.r[0];  // 060B6CA4 add r0,r12
L_060B6CA6:
    c.r[13] += c.r[0];  // 060B6CA6 add r0,r13
L_060B6CA8:
    c.r[7] = ld32(c.r[14] + 28);  // 060B6CA8 mov.l @(28,r14),r7
L_060B6CAA:
    c.mach = c.macl = 0;  // 060B6CAA clrmac
L_060B6CAC:
    sh2_mac_l(c, 6, 10);  // 060B6CAC mac.l @r10+,@r6+
L_060B6CAE:
    c.r[0] = ld32(c.r[15] + 4);  // 060B6CAE mov.l @(4,r15),r0
L_060B6CB0:
    sh2_mac_l(c, 6, 10);  // 060B6CB0 mac.l @r10+,@r6+
L_060B6CB2:
    c.r[1] = ld32(c.r[6] + 4);  // 060B6CB2 mov.l @(4,r6),r1
L_060B6CB4:
    sh2_mac_l(c, 6, 10);  // 060B6CB4 mac.l @r10+,@r6+
L_060B6CB6:
    c.r[6] -= 44;  // 060B6CB6 add #-44,r6
L_060B6CB8:
    c.r[10] -= 12;  // 060B6CB8 add #-12,r10
L_060B6CBA:
    c.r[2] = c.mach;  // 060B6CBA sts mach,r2
L_060B6CBC:
    c.r[3] = c.macl;  // 060B6CBC sts macl,r3
L_060B6CBE:
    st32(c.r[14] + 16, c.r[0]);  // 060B6CBE mov.l r0,@(16,r14)
L_060B6CC0:
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B6CC0 xtrct r2,r3
L_060B6CC2:
    c.r[3] += c.r[1];  // 060B6CC2 add r1,r3
L_060B6CC4:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 060B6CC4 cmp/ge r8,r3
L_060B6CC6:
    { const bool k = c.t; c.r[0] = ld32(c.r[15]); if (k) { goto L_060B6CCC; } }  // 060B6CC6 bt/s 0x060B6CCC ; mov.l @(0,r15),r0
L_060B6CCA:
    c.r[3] = c.r[8];  // 060B6CCA mov r8,r3
L_060B6CCC:
    st32(c.r[14], c.r[3]);  // 060B6CCC mov.l r3,@(0,r14)
L_060B6CCE:
    c.r[11] -= 16;  // 060B6CCE add #-16,r11
L_060B6CD0:
    st32(c.r[14] + 20, c.r[0]);  // 060B6CD0 mov.l r0,@(20,r14)
L_060B6CD2:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6CD2 dmuls.l r4,r7
L_060B6CD4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 148);  // 060B6CD4 mov.w @(148,gbr),r0
L_060B6CD6:
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B6CD6 shlr r4
L_060B6CD8:
    st32(c.r[11] + 12, c.r[3]);  // 060B6CD8 mov.l r3,@(12,r11)
L_060B6CDA:
    c.r[3] = c.mach;  // 060B6CDA sts mach,r3
L_060B6CDC:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6CDC dmuls.l r5,r7
L_060B6CDE:
    c.r[0] += c.r[3];  // 060B6CDE add r3,r0
L_060B6CE0:
    st32(c.r[11] + 24, c.r[5]);  // 060B6CE0 mov.l r5,@(24,r11)
L_060B6CE2:
    c.r[1] = c.r[0];  // 060B6CE2 mov r0,r1
L_060B6CE4:
    c.r[0] = ld32(c.gbr + 908);  // 060B6CE4 mov.l @(908,gbr),r0
L_060B6CE6:
    c.r[0] += c.r[1];  // 060B6CE6 add r1,r0
L_060B6CE8:
    c.t = c.r[0] >= c.r[12];  // 060B6CE8 cmp/hs r12,r0
L_060B6CEA:
    { uint64_t s = (uint64_t)c.r[4] + c.r[4] + c.t; c.t = (uint32_t)(s >> 32); c.r[4] = (uint32_t)s; }  // 060B6CEA addc r4,r4
L_060B6CEC:
    c.r[5] = c.mach;  // 060B6CEC sts mach,r5
L_060B6CEE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 150);  // 060B6CEE mov.w @(150,gbr),r0
L_060B6CF0:
    c.mach = c.macl = 0;  // 060B6CF0 clrmac
L_060B6CF2:
    sh2_mac_l(c, 6, 10);  // 060B6CF2 mac.l @r10+,@r6+
L_060B6CF4:
    c.r[0] += c.r[5];  // 060B6CF4 add r5,r0
L_060B6CF6:
    c.r[1] = c.r[0];  // 060B6CF6 mov r0,r1
L_060B6CF8:
    c.r[0] = ld32(c.gbr + 908);  // 060B6CF8 mov.l @(908,gbr),r0
L_060B6CFA:
    c.r[0] += c.r[1];  // 060B6CFA add r1,r0
L_060B6CFC:
    c.t = c.r[0] >= c.r[13];  // 060B6CFC cmp/hs r13,r0
L_060B6CFE:
    sh2_mac_l(c, 6, 10);  // 060B6CFE mac.l @r10+,@r6+
L_060B6D00:
    c.r[0] = c.t;  // 060B6D00 movt r0
L_060B6D02:
    c.r[4] |= c.r[0];  // 060B6D02 or r0,r4
L_060B6D04:
    sh2_mac_l(c, 6, 10);  // 060B6D04 mac.l @r10+,@r6+
L_060B6D06:
    st32(c.r[11] + 20, c.r[4]);  // 060B6D06 mov.l r4,@(20,r11)
L_060B6D08:
    c.r[0] = ld32(c.gbr + 892);  // 060B6D08 mov.l @(892,gbr),r0
L_060B6D0A:
    c.r[4] &= c.r[0];  // 060B6D0A and r0,r4
L_060B6D0C:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B6D0C shar r4
L_060B6D0E:
    if (!c.t) { goto L_060B6D14; }  // 060B6D0E bf 0x060B6D14
L_060B6D10:
    SH2_POLL(c); goto L_060B6A74;  // 060B6D10 bra 0x060B6A74 ; nop
L_060B6D14:
    c.r[5] <<= 16;  // 060B6D14 shll16 r5
L_060B6D16:
    c.r[2] = ld32(c.r[6]); c.r[6] += 4;  // 060B6D16 mov.l @r6+,r2
L_060B6D18:
    c.r[10] -= 12;  // 060B6D18 add #-12,r10
L_060B6D1A:
    c.r[1] = c.mach;  // 060B6D1A sts mach,r1
L_060B6D1C:
    c.r[4] = c.macl;  // 060B6D1C sts macl,r4
L_060B6D1E:
    c.mach = c.macl = 0;  // 060B6D1E clrmac
L_060B6D20:
    sh2_mac_l(c, 6, 10);  // 060B6D20 mac.l @r10+,@r6+
L_060B6D22:
    c.r[5] = c.r[3] << 16 | c.r[5] >> 16;  // 060B6D22 xtrct r3,r5
L_060B6D24:
    st32(c.r[11] + 16, c.r[5]);  // 060B6D24 mov.l r5,@(16,r11)
L_060B6D26:
    sh2_mac_l(c, 6, 10);  // 060B6D26 mac.l @r10+,@r6+
L_060B6D28:
    c.r[4] = c.r[1] << 16 | c.r[4] >> 16;  // 060B6D28 xtrct r1,r4
L_060B6D2A:
    c.r[4] += c.r[2];  // 060B6D2A add r2,r4
L_060B6D2C:
    sh2_mac_l(c, 6, 10);  // 060B6D2C mac.l @r10+,@r6+
L_060B6D2E:
    c.r[2] = ld32(c.r[6]);  // 060B6D2E mov.l @r6,r2
L_060B6D30:
    c.r[6] += 4;  // 060B6D30 add #4,r6
L_060B6D32:
    c.r[10] -= 24;  // 060B6D32 add #-24,r10
L_060B6D34:
    c.r[1] = c.mach;  // 060B6D34 sts mach,r1
L_060B6D36:
    c.r[5] = c.macl;  // 060B6D36 sts macl,r5
L_060B6D38:
    c.r[7] = ld32(c.r[14] + 28);  // 060B6D38 mov.l @(28,r14),r7
L_060B6D3A:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6D3A xtrct r1,r5
L_060B6D3C:
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060B6D3C dt r9
L_060B6D3E:
    { const bool k = !c.t; c.r[5] += c.r[2]; if (k) { SH2_POLL(c); goto L_060B6CAA; } }  // 060B6D3E bf/s 0x060B6CAA ; add r2,r5
L_060B6D42:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6D42 dmuls.l r4,r7
L_060B6D44:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 148);  // 060B6D44 mov.w @(148,gbr),r0
L_060B6D46:
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B6D46 shlr r4
L_060B6D48:
    st32(c.r[11] + 8, c.r[5]);  // 060B6D48 mov.l r5,@(8,r11)
L_060B6D4A:
    c.r[2] = c.mach;  // 060B6D4A sts mach,r2
L_060B6D4C:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6D4C dmuls.l r5,r7
L_060B6D4E:
    c.r[0] += c.r[2];  // 060B6D4E add r2,r0
L_060B6D50:
    c.r[1] = c.r[0];  // 060B6D50 mov r0,r1
L_060B6D52:
    c.r[0] = ld32(c.gbr + 908);  // 060B6D52 mov.l @(908,gbr),r0
L_060B6D54:
    c.r[0] += c.r[1];  // 060B6D54 add r1,r0
L_060B6D56:
    c.t = c.r[0] >= c.r[12];  // 060B6D56 cmp/hs r12,r0
L_060B6D58:
    c.r[5] = c.mach;  // 060B6D58 sts mach,r5
L_060B6D5A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 150);  // 060B6D5A mov.w @(150,gbr),r0
L_060B6D5C:
    { uint64_t s = (uint64_t)c.r[4] + c.r[4] + c.t; c.t = (uint32_t)(s >> 32); c.r[4] = (uint32_t)s; }  // 060B6D5C addc r4,r4
L_060B6D5E:
    c.r[0] += c.r[5];  // 060B6D5E add r5,r0
L_060B6D60:
    c.r[1] = c.r[0];  // 060B6D60 mov r0,r1
L_060B6D62:
    c.r[0] = ld32(c.gbr + 908);  // 060B6D62 mov.l @(908,gbr),r0
L_060B6D64:
    c.r[0] += c.r[1];  // 060B6D64 add r1,r0
L_060B6D66:
    c.t = c.r[0] >= c.r[13];  // 060B6D66 cmp/hs r13,r0
L_060B6D68:
    c.r[0] = c.t;  // 060B6D68 movt r0
L_060B6D6A:
    c.r[4] |= c.r[0];  // 060B6D6A or r0,r4
L_060B6D6C:
    st32(c.r[11] + 4, c.r[4]);  // 060B6D6C mov.l r4,@(4,r11)
L_060B6D6E:
    c.r[0] = ld32(c.gbr + 892);  // 060B6D6E mov.l @(892,gbr),r0
L_060B6D70:
    c.r[4] &= c.r[0];  // 060B6D70 and r0,r4
L_060B6D72:
    c.t = c.r[4] & 1; c.r[4] = (uint32_t)((int32_t)c.r[4] >> 1);  // 060B6D72 shar r4
L_060B6D74:
    if (!c.t) { goto L_060B6D7A; }  // 060B6D74 bf 0x060B6D7A
L_060B6D76:
    SH2_POLL(c); goto L_060B6B40;  // 060B6D76 bra 0x060B6B40 ; nop
L_060B6D7A:
    c.r[5] <<= 16;  // 060B6D7A shll16 r5
L_060B6D7C:
    c.r[5] = c.r[2] << 16 | c.r[5] >> 16;  // 060B6D7C xtrct r2,r5
L_060B6D7E:
    st32(c.r[11], c.r[5]);  // 060B6D7E mov.l r5,@(0,r11)
L_060B6D80:
    c.r[10] = c.r[11];  // 060B6D80 mov r11,r10
L_060B6D82:
    c.r[15] += 8;  // 060B6D82 add #8,r15
L_060B6D84:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6D84 mov.l @r15+,r4
L_060B6D86:
    c.r[6] -= 32; goto L_060B6DC4;  // 060B6D86 bra 0x060B6DC4 ; add #-32,r6
L_060B6DC4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B6DC4 mov.b @(169,gbr),r0
L_060B6DC6:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6DC6 tst #1,r0
L_060B6DC8:
    { const bool k = !c.t; c.r[1] = 0x20u; if (k) { goto L_060B6DCE; } }  // 060B6DC8 bf/s 0x060B6DCE ; mov #32,r1
L_060B6DCC:
    c.r[1] = 0x10u;  // 060B6DCC mov #16,r1
L_060B6DCE:
    c.r[0] |= c.r[1];  // 060B6DCE or r1,r0
L_060B6DD0:
    st8(c.gbr + 169, c.r[0]);  // 060B6DD0 mov.b r0,@(169,gbr)
L_060B6DD2:
    c.r[0] = ld32(c.gbr + 52);  // 060B6DD2 mov.l @(52,gbr),r0
L_060B6DD4:
    c.r[3] = ld32(c.r[4]); c.r[4] += 4;  // 060B6DD4 mov.l @r4+,r3
L_060B6DD6:
    c.r[7] = ld32(c.r[4]); c.r[4] += 4;  // 060B6DD6 mov.l @r4+,r7
L_060B6DD8:
    c.r[8] = ld32(c.r[4]); c.r[4] += 4;  // 060B6DD8 mov.l @r4+,r8
L_060B6DDA:
    c.r[11] = c.r[0];  // 060B6DDA mov r0,r11
L_060B6DDC:
    c.r[0] = ld32(c.gbr + 60);  // 060B6DDC mov.l @(60,gbr),r0
L_060B6DDE:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B6DDE mov.l r4,@-r15
L_060B6DE0:
    c.r[0] += 4;  // 060B6DE0 add #4,r0
L_060B6DE2:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B6DE2 mov.l r0,@-r15
L_060B6DE4:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B6DE4 mov.l r3,@-r15
L_060B6DE6:
    c.r[0] = ld32(c.gbr + 108);  // 060B6DE6 mov.l @(108,gbr),r0
L_060B6DE8:
    c.r[14] = 0xFFFFFFFFu;  // 060B6DE8 mov #-1,r14
L_060B6DEA:
    c.r[1] = c.r[0];  // 060B6DEA mov r0,r1
L_060B6DEC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 173);  // 060B6DEC mov.b @(173,gbr),r0
L_060B6DEE:
    c.r[1] >>= 16;  // 060B6DEE shlr16 r1
L_060B6DF0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6DF0 dt r0
L_060B6DF2:
    { const bool k = !c.t; c.t = c.r[1] & 1; c.r[1] >>= 1; if (k) { SH2_POLL(c); goto L_060B6DF0; } }  // 060B6DF2 bf/s 0x060B6DF0 ; shlr r1
L_060B6DF6:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B6DF6 mov.l r1,@-r15
L_060B6DF8:
    c.r[15] -= 12;  // 060B6DF8 add #-12,r15
L_060B6DFA:
    c.r[0] = 0x060B6EA8u;  // 060B6DFA mova 0x060B6EA8,r0
L_060B6DFC:
    c.pr = c.r[0];  // 060B6DFC lds r0,pr
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6A74u: goto L_060B6A74; case 0x060B6A76u: goto L_060B6A76; case 0x060B6A78u: goto L_060B6A78; case 0x060B6A7Au: goto L_060B6A7A; case 0x060B6A7Cu: goto L_060B6A7C; case 0x060B6A7Eu: goto L_060B6A7E; case 0x060B6A80u: goto L_060B6A80; case 0x060B6A84u: goto L_060B6A84; case 0x060B6A86u: goto L_060B6A86; case 0x060B6A88u: goto L_060B6A88; case 0x060B6A8Au: goto L_060B6A8A; case 0x060B6A8Cu: goto L_060B6A8C; case 0x060B6A90u: goto L_060B6A90; case 0x060B6A92u: goto L_060B6A92; case 0x060B6A94u: goto L_060B6A94; case 0x060B6A96u: goto L_060B6A96; case 0x060B6A98u: goto L_060B6A98; case 0x060B6A9Au: goto L_060B6A9A; case 0x060B6A9Eu: goto L_060B6A9E; case 0x060B6AA0u: goto L_060B6AA0; case 0x060B6AA2u: goto L_060B6AA2; case 0x060B6AA4u: goto L_060B6AA4; case 0x060B6AA6u: goto L_060B6AA6; case 0x060B6AAAu: goto L_060B6AAA; case 0x060B6AACu: goto L_060B6AAC; case 0x060B6AAEu: goto L_060B6AAE; case 0x060B6AB2u: goto L_060B6AB2; case 0x060B6AB4u: goto L_060B6AB4; case 0x060B6AB6u: goto L_060B6AB6; case 0x060B6AB8u: goto L_060B6AB8; case 0x060B6ABAu: goto L_060B6ABA; case 0x060B6ABCu: goto L_060B6ABC; case 0x060B6ABEu: goto L_060B6ABE; case 0x060B6AC0u: goto L_060B6AC0; case 0x060B6AC2u: goto L_060B6AC2; case 0x060B6AC4u: goto L_060B6AC4; case 0x060B6AC6u: goto L_060B6AC6; case 0x060B6AC8u: goto L_060B6AC8; case 0x060B6ACCu: goto L_060B6ACC; case 0x060B6ACEu: goto L_060B6ACE; case 0x060B6AD0u: goto L_060B6AD0; case 0x060B6AD2u: goto L_060B6AD2; case 0x060B6AD4u: goto L_060B6AD4; case 0x060B6AD6u: goto L_060B6AD6; case 0x060B6ADAu: goto L_060B6ADA; case 0x060B6ADCu: goto L_060B6ADC; case 0x060B6ADEu: goto L_060B6ADE; case 0x060B6AE0u: goto L_060B6AE0; case 0x060B6AE2u: goto L_060B6AE2; case 0x060B6AE6u: goto L_060B6AE6; case 0x060B6AEAu: goto L_060B6AEA; case 0x060B6AECu: goto L_060B6AEC; case 0x060B6AEEu: goto L_060B6AEE; case 0x060B6AF0u: goto L_060B6AF0; case 0x060B6AF2u: goto L_060B6AF2; case 0x060B6AF6u: goto L_060B6AF6; case 0x060B6AF8u: goto L_060B6AF8; case 0x060B6AFAu: goto L_060B6AFA; case 0x060B6AFCu: goto L_060B6AFC; case 0x060B6AFEu: goto L_060B6AFE; case 0x060B6B02u: goto L_060B6B02; case 0x060B6B06u: goto L_060B6B06; case 0x060B6B08u: goto L_060B6B08; case 0x060B6B0Au: goto L_060B6B0A; case 0x060B6B0Cu: goto L_060B6B0C; case 0x060B6B0Eu: goto L_060B6B0E; case 0x060B6B10u: goto L_060B6B10; case 0x060B6B14u: goto L_060B6B14; case 0x060B6B16u: goto L_060B6B16; case 0x060B6B18u: goto L_060B6B18; case 0x060B6B1Au: goto L_060B6B1A; case 0x060B6B1Cu: goto L_060B6B1C; case 0x060B6B20u: goto L_060B6B20; case 0x060B6B24u: goto L_060B6B24; case 0x060B6B26u: goto L_060B6B26; case 0x060B6B28u: goto L_060B6B28; case 0x060B6B2Au: goto L_060B6B2A; case 0x060B6B2Cu: goto L_060B6B2C; case 0x060B6B30u: goto L_060B6B30; case 0x060B6B32u: goto L_060B6B32; case 0x060B6B34u: goto L_060B6B34; case 0x060B6B36u: goto L_060B6B36; case 0x060B6B38u: goto L_060B6B38; case 0x060B6B3Cu: goto L_060B6B3C; case 0x060B6B40u: goto L_060B6B40; case 0x060B6B42u: goto L_060B6B42; case 0x060B6B44u: goto L_060B6B44; case 0x060B6B46u: goto L_060B6B46; case 0x060B6B48u: goto L_060B6B48; case 0x060B6B4Au: goto L_060B6B4A; case 0x060B6B4Cu: goto L_060B6B4C; case 0x060B6B50u: goto L_060B6B50; case 0x060B6B52u: goto L_060B6B52; case 0x060B6B54u: goto L_060B6B54; case 0x060B6B56u: goto L_060B6B56; case 0x060B6B58u: goto L_060B6B58; case 0x060B6B5Cu: goto L_060B6B5C; case 0x060B6B5Eu: goto L_060B6B5E; case 0x060B6B60u: goto L_060B6B60; case 0x060B6B62u: goto L_060B6B62; case 0x060B6B64u: goto L_060B6B64; case 0x060B6B66u: goto L_060B6B66; case 0x060B6B6Au: goto L_060B6B6A; case 0x060B6B6Cu: goto L_060B6B6C; case 0x060B6B6Eu: goto L_060B6B6E; case 0x060B6B70u: goto L_060B6B70; case 0x060B6B72u: goto L_060B6B72; case 0x060B6B76u: goto L_060B6B76; case 0x060B6B78u: goto L_060B6B78; case 0x060B6B7Au: goto L_060B6B7A; case 0x060B6B7Eu: goto L_060B6B7E; case 0x060B6B80u: goto L_060B6B80; case 0x060B6B82u: goto L_060B6B82; case 0x060B6B84u: goto L_060B6B84; case 0x060B6B86u: goto L_060B6B86; case 0x060B6B88u: goto L_060B6B88; case 0x060B6B8Au: goto L_060B6B8A; case 0x060B6B8Cu: goto L_060B6B8C; case 0x060B6B8Eu: goto L_060B6B8E; case 0x060B6B90u: goto L_060B6B90; case 0x060B6B92u: goto L_060B6B92; case 0x060B6B94u: goto L_060B6B94; case 0x060B6B98u: goto L_060B6B98; case 0x060B6B9Au: goto L_060B6B9A; case 0x060B6B9Cu: goto L_060B6B9C; case 0x060B6B9Eu: goto L_060B6B9E; case 0x060B6BA0u: goto L_060B6BA0; case 0x060B6BA2u: goto L_060B6BA2; case 0x060B6BA6u: goto L_060B6BA6; case 0x060B6BA8u: goto L_060B6BA8; case 0x060B6BAAu: goto L_060B6BAA; case 0x060B6BACu: goto L_060B6BAC; case 0x060B6BAEu: goto L_060B6BAE; case 0x060B6BB2u: goto L_060B6BB2; case 0x060B6BB6u: goto L_060B6BB6; case 0x060B6BB8u: goto L_060B6BB8; case 0x060B6BBAu: goto L_060B6BBA; case 0x060B6BBCu: goto L_060B6BBC; case 0x060B6BBEu: goto L_060B6BBE; case 0x060B6BC2u: goto L_060B6BC2; case 0x060B6BC4u: goto L_060B6BC4; case 0x060B6BC6u: goto L_060B6BC6; case 0x060B6BC8u: goto L_060B6BC8; case 0x060B6BCAu: goto L_060B6BCA; case 0x060B6BCEu: goto L_060B6BCE; case 0x060B6BD2u: goto L_060B6BD2; case 0x060B6BD4u: goto L_060B6BD4; case 0x060B6BD6u: goto L_060B6BD6; case 0x060B6BD8u: goto L_060B6BD8; case 0x060B6BDAu: goto L_060B6BDA; case 0x060B6BDCu: goto L_060B6BDC; case 0x060B6BE0u: goto L_060B6BE0; case 0x060B6BE2u: goto L_060B6BE2; case 0x060B6BE4u: goto L_060B6BE4; case 0x060B6BE6u: goto L_060B6BE6; case 0x060B6BE8u: goto L_060B6BE8; case 0x060B6BECu: goto L_060B6BEC; case 0x060B6BF0u: goto L_060B6BF0; case 0x060B6BF2u: goto L_060B6BF2; case 0x060B6BF4u: goto L_060B6BF4; case 0x060B6BF6u: goto L_060B6BF6; case 0x060B6BF8u: goto L_060B6BF8; case 0x060B6BFCu: goto L_060B6BFC; case 0x060B6BFEu: goto L_060B6BFE; case 0x060B6C00u: goto L_060B6C00; case 0x060B6C02u: goto L_060B6C02; case 0x060B6C04u: goto L_060B6C04; case 0x060B6C08u: goto L_060B6C08; case 0x060B6C0Cu: goto L_060B6C0C; case 0x060B6C0Eu: goto L_060B6C0E; case 0x060B6C10u: goto L_060B6C10; case 0x060B6C12u: goto L_060B6C12; case 0x060B6C14u: goto L_060B6C14; case 0x060B6C16u: goto L_060B6C16; case 0x060B6C18u: goto L_060B6C18; case 0x060B6C1Au: goto L_060B6C1A; case 0x060B6C1Cu: goto L_060B6C1C; case 0x060B6C1Eu: goto L_060B6C1E; case 0x060B6C20u: goto L_060B6C20; case 0x060B6C22u: goto L_060B6C22; case 0x060B6C24u: goto L_060B6C24; case 0x060B6C26u: goto L_060B6C26; case 0x060B6C28u: goto L_060B6C28; case 0x060B6C2Au: goto L_060B6C2A; case 0x060B6C2Cu: goto L_060B6C2C; case 0x060B6C2Eu: goto L_060B6C2E; case 0x060B6C30u: goto L_060B6C30; case 0x060B6C32u: goto L_060B6C32; case 0x060B6C34u: goto L_060B6C34; case 0x060B6C36u: goto L_060B6C36; case 0x060B6C38u: goto L_060B6C38; case 0x060B6C3Au: goto L_060B6C3A; case 0x060B6C3Cu: goto L_060B6C3C; case 0x060B6C3Eu: goto L_060B6C3E; case 0x060B6C40u: goto L_060B6C40; case 0x060B6C42u: goto L_060B6C42; case 0x060B6C44u: goto L_060B6C44; case 0x060B6C46u: goto L_060B6C46; case 0x060B6C48u: goto L_060B6C48; case 0x060B6C4Au: goto L_060B6C4A; case 0x060B6C4Cu: goto L_060B6C4C; case 0x060B6C4Eu: goto L_060B6C4E; case 0x060B6C50u: goto L_060B6C50; case 0x060B6C52u: goto L_060B6C52; case 0x060B6C54u: goto L_060B6C54; case 0x060B6C56u: goto L_060B6C56; case 0x060B6C58u: goto L_060B6C58; case 0x060B6C5Au: goto L_060B6C5A; case 0x060B6C5Cu: goto L_060B6C5C; case 0x060B6C5Eu: goto L_060B6C5E; case 0x060B6C60u: goto L_060B6C60; case 0x060B6C62u: goto L_060B6C62; case 0x060B6C64u: goto L_060B6C64; case 0x060B6C66u: goto L_060B6C66; case 0x060B6C68u: goto L_060B6C68; case 0x060B6C6Au: goto L_060B6C6A; case 0x060B6C6Cu: goto L_060B6C6C; case 0x060B6C6Eu: goto L_060B6C6E; case 0x060B6C70u: goto L_060B6C70; case 0x060B6C72u: goto L_060B6C72; case 0x060B6C74u: goto L_060B6C74; case 0x060B6C76u: goto L_060B6C76; case 0x060B6C7Au: goto L_060B6C7A; case 0x060B6C7Eu: goto L_060B6C7E; case 0x060B6C80u: goto L_060B6C80; case 0x060B6C82u: goto L_060B6C82; case 0x060B6C84u: goto L_060B6C84; case 0x060B6C86u: goto L_060B6C86; case 0x060B6C88u: goto L_060B6C88; case 0x060B6C8Au: goto L_060B6C8A; case 0x060B6C8Cu: goto L_060B6C8C; case 0x060B6C90u: goto L_060B6C90; case 0x060B6C92u: goto L_060B6C92; case 0x060B6C94u: goto L_060B6C94; case 0x060B6C96u: goto L_060B6C96; case 0x060B6C98u: goto L_060B6C98; case 0x060B6C9Au: goto L_060B6C9A; case 0x060B6C9Cu: goto L_060B6C9C; case 0x060B6C9Eu: goto L_060B6C9E; case 0x060B6CA0u: goto L_060B6CA0; case 0x060B6CA2u: goto L_060B6CA2; case 0x060B6CA4u: goto L_060B6CA4; case 0x060B6CA6u: goto L_060B6CA6; case 0x060B6CA8u: goto L_060B6CA8; case 0x060B6CAAu: goto L_060B6CAA; case 0x060B6CACu: goto L_060B6CAC; case 0x060B6CAEu: goto L_060B6CAE; case 0x060B6CB0u: goto L_060B6CB0; case 0x060B6CB2u: goto L_060B6CB2; case 0x060B6CB4u: goto L_060B6CB4; case 0x060B6CB6u: goto L_060B6CB6; case 0x060B6CB8u: goto L_060B6CB8; case 0x060B6CBAu: goto L_060B6CBA; case 0x060B6CBCu: goto L_060B6CBC; case 0x060B6CBEu: goto L_060B6CBE; case 0x060B6CC0u: goto L_060B6CC0; case 0x060B6CC2u: goto L_060B6CC2; case 0x060B6CC4u: goto L_060B6CC4; case 0x060B6CC6u: goto L_060B6CC6; case 0x060B6CCAu: goto L_060B6CCA; case 0x060B6CCCu: goto L_060B6CCC; case 0x060B6CCEu: goto L_060B6CCE; case 0x060B6CD0u: goto L_060B6CD0; case 0x060B6CD2u: goto L_060B6CD2; case 0x060B6CD4u: goto L_060B6CD4; case 0x060B6CD6u: goto L_060B6CD6; case 0x060B6CD8u: goto L_060B6CD8; case 0x060B6CDAu: goto L_060B6CDA; case 0x060B6CDCu: goto L_060B6CDC; case 0x060B6CDEu: goto L_060B6CDE; case 0x060B6CE0u: goto L_060B6CE0; case 0x060B6CE2u: goto L_060B6CE2; case 0x060B6CE4u: goto L_060B6CE4; case 0x060B6CE6u: goto L_060B6CE6; case 0x060B6CE8u: goto L_060B6CE8; case 0x060B6CEAu: goto L_060B6CEA; case 0x060B6CECu: goto L_060B6CEC; case 0x060B6CEEu: goto L_060B6CEE; case 0x060B6CF0u: goto L_060B6CF0; case 0x060B6CF2u: goto L_060B6CF2; case 0x060B6CF4u: goto L_060B6CF4; case 0x060B6CF6u: goto L_060B6CF6; case 0x060B6CF8u: goto L_060B6CF8; case 0x060B6CFAu: goto L_060B6CFA; case 0x060B6CFCu: goto L_060B6CFC; case 0x060B6CFEu: goto L_060B6CFE; case 0x060B6D00u: goto L_060B6D00; case 0x060B6D02u: goto L_060B6D02; case 0x060B6D04u: goto L_060B6D04; case 0x060B6D06u: goto L_060B6D06; case 0x060B6D08u: goto L_060B6D08; case 0x060B6D0Au: goto L_060B6D0A; case 0x060B6D0Cu: goto L_060B6D0C; case 0x060B6D0Eu: goto L_060B6D0E; case 0x060B6D10u: goto L_060B6D10; case 0x060B6D14u: goto L_060B6D14; case 0x060B6D16u: goto L_060B6D16; case 0x060B6D18u: goto L_060B6D18; case 0x060B6D1Au: goto L_060B6D1A; case 0x060B6D1Cu: goto L_060B6D1C; case 0x060B6D1Eu: goto L_060B6D1E; case 0x060B6D20u: goto L_060B6D20; case 0x060B6D22u: goto L_060B6D22; case 0x060B6D24u: goto L_060B6D24; case 0x060B6D26u: goto L_060B6D26; case 0x060B6D28u: goto L_060B6D28; case 0x060B6D2Au: goto L_060B6D2A; case 0x060B6D2Cu: goto L_060B6D2C; case 0x060B6D2Eu: goto L_060B6D2E; case 0x060B6D30u: goto L_060B6D30; case 0x060B6D32u: goto L_060B6D32; case 0x060B6D34u: goto L_060B6D34; case 0x060B6D36u: goto L_060B6D36; case 0x060B6D38u: goto L_060B6D38; case 0x060B6D3Au: goto L_060B6D3A; case 0x060B6D3Cu: goto L_060B6D3C; case 0x060B6D3Eu: goto L_060B6D3E; case 0x060B6D42u: goto L_060B6D42; case 0x060B6D44u: goto L_060B6D44; case 0x060B6D46u: goto L_060B6D46; case 0x060B6D48u: goto L_060B6D48; case 0x060B6D4Au: goto L_060B6D4A; case 0x060B6D4Cu: goto L_060B6D4C; case 0x060B6D4Eu: goto L_060B6D4E; case 0x060B6D50u: goto L_060B6D50; case 0x060B6D52u: goto L_060B6D52; case 0x060B6D54u: goto L_060B6D54; case 0x060B6D56u: goto L_060B6D56; case 0x060B6D58u: goto L_060B6D58; case 0x060B6D5Au: goto L_060B6D5A; case 0x060B6D5Cu: goto L_060B6D5C; case 0x060B6D5Eu: goto L_060B6D5E; case 0x060B6D60u: goto L_060B6D60; case 0x060B6D62u: goto L_060B6D62; case 0x060B6D64u: goto L_060B6D64; case 0x060B6D66u: goto L_060B6D66; case 0x060B6D68u: goto L_060B6D68; case 0x060B6D6Au: goto L_060B6D6A; case 0x060B6D6Cu: goto L_060B6D6C; case 0x060B6D6Eu: goto L_060B6D6E; case 0x060B6D70u: goto L_060B6D70; case 0x060B6D72u: goto L_060B6D72; case 0x060B6D74u: goto L_060B6D74; case 0x060B6D76u: goto L_060B6D76; case 0x060B6D7Au: goto L_060B6D7A; case 0x060B6D7Cu: goto L_060B6D7C; case 0x060B6D7Eu: goto L_060B6D7E; case 0x060B6D80u: goto L_060B6D80; case 0x060B6D82u: goto L_060B6D82; case 0x060B6D84u: goto L_060B6D84; case 0x060B6D86u: goto L_060B6D86; case 0x060B6DC4u: goto L_060B6DC4; case 0x060B6DC6u: goto L_060B6DC6; case 0x060B6DC8u: goto L_060B6DC8; case 0x060B6DCCu: goto L_060B6DCC; case 0x060B6DCEu: goto L_060B6DCE; case 0x060B6DD0u: goto L_060B6DD0; case 0x060B6DD2u: goto L_060B6DD2; case 0x060B6DD4u: goto L_060B6DD4; case 0x060B6DD6u: goto L_060B6DD6; case 0x060B6DD8u: goto L_060B6DD8; case 0x060B6DDAu: goto L_060B6DDA; case 0x060B6DDCu: goto L_060B6DDC; case 0x060B6DDEu: goto L_060B6DDE; case 0x060B6DE0u: goto L_060B6DE0; case 0x060B6DE2u: goto L_060B6DE2; case 0x060B6DE4u: goto L_060B6DE4; case 0x060B6DE6u: goto L_060B6DE6; case 0x060B6DE8u: goto L_060B6DE8; case 0x060B6DEAu: goto L_060B6DEA; case 0x060B6DECu: goto L_060B6DEC; case 0x060B6DEEu: goto L_060B6DEE; case 0x060B6DF0u: goto L_060B6DF0; case 0x060B6DF2u: goto L_060B6DF2; case 0x060B6DF6u: goto L_060B6DF6; case 0x060B6DF8u: goto L_060B6DF8; case 0x060B6DFAu: goto L_060B6DFA; case 0x060B6DFCu: goto L_060B6DFC; case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6A74u: goto L_060B6A74; case 0x060B6A76u: goto L_060B6A76; case 0x060B6A78u: goto L_060B6A78; case 0x060B6A7Au: goto L_060B6A7A; case 0x060B6A7Cu: goto L_060B6A7C; case 0x060B6A7Eu: goto L_060B6A7E; case 0x060B6A80u: goto L_060B6A80; case 0x060B6A84u: goto L_060B6A84; case 0x060B6A86u: goto L_060B6A86; case 0x060B6A88u: goto L_060B6A88; case 0x060B6A8Au: goto L_060B6A8A; case 0x060B6A8Cu: goto L_060B6A8C; case 0x060B6A90u: goto L_060B6A90; case 0x060B6A92u: goto L_060B6A92; case 0x060B6A94u: goto L_060B6A94; case 0x060B6A96u: goto L_060B6A96; case 0x060B6A98u: goto L_060B6A98; case 0x060B6A9Au: goto L_060B6A9A; case 0x060B6A9Eu: goto L_060B6A9E; case 0x060B6AA0u: goto L_060B6AA0; case 0x060B6AA2u: goto L_060B6AA2; case 0x060B6AA4u: goto L_060B6AA4; case 0x060B6AA6u: goto L_060B6AA6; case 0x060B6AAAu: goto L_060B6AAA; case 0x060B6AACu: goto L_060B6AAC; case 0x060B6AAEu: goto L_060B6AAE; case 0x060B6AB2u: goto L_060B6AB2; case 0x060B6AB4u: goto L_060B6AB4; case 0x060B6AB6u: goto L_060B6AB6; case 0x060B6AB8u: goto L_060B6AB8; case 0x060B6ABAu: goto L_060B6ABA; case 0x060B6ABCu: goto L_060B6ABC; case 0x060B6ABEu: goto L_060B6ABE; case 0x060B6AC0u: goto L_060B6AC0; case 0x060B6AC2u: goto L_060B6AC2; case 0x060B6AC4u: goto L_060B6AC4; case 0x060B6AC6u: goto L_060B6AC6; case 0x060B6AC8u: goto L_060B6AC8; case 0x060B6ACCu: goto L_060B6ACC; case 0x060B6ACEu: goto L_060B6ACE; case 0x060B6AD0u: goto L_060B6AD0; case 0x060B6AD2u: goto L_060B6AD2; case 0x060B6AD4u: goto L_060B6AD4; case 0x060B6AD6u: goto L_060B6AD6; case 0x060B6ADAu: goto L_060B6ADA; case 0x060B6ADCu: goto L_060B6ADC; case 0x060B6ADEu: goto L_060B6ADE; case 0x060B6AE0u: goto L_060B6AE0; case 0x060B6AE2u: goto L_060B6AE2; case 0x060B6AE6u: goto L_060B6AE6; case 0x060B6AEAu: goto L_060B6AEA; case 0x060B6AECu: goto L_060B6AEC; case 0x060B6AEEu: goto L_060B6AEE; case 0x060B6AF0u: goto L_060B6AF0; case 0x060B6AF2u: goto L_060B6AF2; case 0x060B6AF6u: goto L_060B6AF6; case 0x060B6AF8u: goto L_060B6AF8; case 0x060B6AFAu: goto L_060B6AFA; case 0x060B6AFCu: goto L_060B6AFC; case 0x060B6AFEu: goto L_060B6AFE; case 0x060B6B02u: goto L_060B6B02; case 0x060B6B06u: goto L_060B6B06; case 0x060B6B08u: goto L_060B6B08; case 0x060B6B0Au: goto L_060B6B0A; case 0x060B6B0Cu: goto L_060B6B0C; case 0x060B6B0Eu: goto L_060B6B0E; case 0x060B6B10u: goto L_060B6B10; case 0x060B6B14u: goto L_060B6B14; case 0x060B6B16u: goto L_060B6B16; case 0x060B6B18u: goto L_060B6B18; case 0x060B6B1Au: goto L_060B6B1A; case 0x060B6B1Cu: goto L_060B6B1C; case 0x060B6B20u: goto L_060B6B20; case 0x060B6B24u: goto L_060B6B24; case 0x060B6B26u: goto L_060B6B26; case 0x060B6B28u: goto L_060B6B28; case 0x060B6B2Au: goto L_060B6B2A; case 0x060B6B2Cu: goto L_060B6B2C; case 0x060B6B30u: goto L_060B6B30; case 0x060B6B32u: goto L_060B6B32; case 0x060B6B34u: goto L_060B6B34; case 0x060B6B36u: goto L_060B6B36; case 0x060B6B38u: goto L_060B6B38; case 0x060B6B3Cu: goto L_060B6B3C; case 0x060B6B40u: goto L_060B6B40; case 0x060B6B42u: goto L_060B6B42; case 0x060B6B44u: goto L_060B6B44; case 0x060B6B46u: goto L_060B6B46; case 0x060B6B48u: goto L_060B6B48; case 0x060B6B4Au: goto L_060B6B4A; case 0x060B6B4Cu: goto L_060B6B4C; case 0x060B6B50u: goto L_060B6B50; case 0x060B6B52u: goto L_060B6B52; case 0x060B6B54u: goto L_060B6B54; case 0x060B6B56u: goto L_060B6B56; case 0x060B6B58u: goto L_060B6B58; case 0x060B6B5Cu: goto L_060B6B5C; case 0x060B6B5Eu: goto L_060B6B5E; case 0x060B6B60u: goto L_060B6B60; case 0x060B6B62u: goto L_060B6B62; case 0x060B6B64u: goto L_060B6B64; case 0x060B6B66u: goto L_060B6B66; case 0x060B6B6Au: goto L_060B6B6A; case 0x060B6B6Cu: goto L_060B6B6C; case 0x060B6B6Eu: goto L_060B6B6E; case 0x060B6B70u: goto L_060B6B70; case 0x060B6B72u: goto L_060B6B72; case 0x060B6B76u: goto L_060B6B76; case 0x060B6B78u: goto L_060B6B78; case 0x060B6B7Au: goto L_060B6B7A; case 0x060B6B7Eu: goto L_060B6B7E; case 0x060B6B80u: goto L_060B6B80; case 0x060B6B82u: goto L_060B6B82; case 0x060B6B84u: goto L_060B6B84; case 0x060B6B86u: goto L_060B6B86; case 0x060B6B88u: goto L_060B6B88; case 0x060B6B8Au: goto L_060B6B8A; case 0x060B6B8Cu: goto L_060B6B8C; case 0x060B6B8Eu: goto L_060B6B8E; case 0x060B6B90u: goto L_060B6B90; case 0x060B6B92u: goto L_060B6B92; case 0x060B6B94u: goto L_060B6B94; case 0x060B6B98u: goto L_060B6B98; case 0x060B6B9Au: goto L_060B6B9A; case 0x060B6B9Cu: goto L_060B6B9C; case 0x060B6B9Eu: goto L_060B6B9E; case 0x060B6BA0u: goto L_060B6BA0; case 0x060B6BA2u: goto L_060B6BA2; case 0x060B6BA6u: goto L_060B6BA6; case 0x060B6BA8u: goto L_060B6BA8; case 0x060B6BAAu: goto L_060B6BAA; case 0x060B6BACu: goto L_060B6BAC; case 0x060B6BAEu: goto L_060B6BAE; case 0x060B6BB2u: goto L_060B6BB2; case 0x060B6BB6u: goto L_060B6BB6; case 0x060B6BB8u: goto L_060B6BB8; case 0x060B6BBAu: goto L_060B6BBA; case 0x060B6BBCu: goto L_060B6BBC; case 0x060B6BBEu: goto L_060B6BBE; case 0x060B6BC2u: goto L_060B6BC2; case 0x060B6BC4u: goto L_060B6BC4; case 0x060B6BC6u: goto L_060B6BC6; case 0x060B6BC8u: goto L_060B6BC8; case 0x060B6BCAu: goto L_060B6BCA; case 0x060B6BCEu: goto L_060B6BCE; case 0x060B6BD2u: goto L_060B6BD2; case 0x060B6BD4u: goto L_060B6BD4; case 0x060B6BD6u: goto L_060B6BD6; case 0x060B6BD8u: goto L_060B6BD8; case 0x060B6BDAu: goto L_060B6BDA; case 0x060B6BDCu: goto L_060B6BDC; case 0x060B6BE0u: goto L_060B6BE0; case 0x060B6BE2u: goto L_060B6BE2; case 0x060B6BE4u: goto L_060B6BE4; case 0x060B6BE6u: goto L_060B6BE6; case 0x060B6BE8u: goto L_060B6BE8; case 0x060B6BECu: goto L_060B6BEC; case 0x060B6BF0u: goto L_060B6BF0; case 0x060B6BF2u: goto L_060B6BF2; case 0x060B6BF4u: goto L_060B6BF4; case 0x060B6BF6u: goto L_060B6BF6; case 0x060B6BF8u: goto L_060B6BF8; case 0x060B6BFCu: goto L_060B6BFC; case 0x060B6BFEu: goto L_060B6BFE; case 0x060B6C00u: goto L_060B6C00; case 0x060B6C02u: goto L_060B6C02; case 0x060B6C04u: goto L_060B6C04; case 0x060B6C08u: goto L_060B6C08; case 0x060B6C0Cu: goto L_060B6C0C; case 0x060B6C0Eu: goto L_060B6C0E; case 0x060B6C10u: goto L_060B6C10; case 0x060B6C12u: goto L_060B6C12; case 0x060B6C14u: goto L_060B6C14; case 0x060B6C16u: goto L_060B6C16; case 0x060B6C18u: goto L_060B6C18; case 0x060B6C1Au: goto L_060B6C1A; case 0x060B6C1Cu: goto L_060B6C1C; case 0x060B6C1Eu: goto L_060B6C1E; case 0x060B6C20u: goto L_060B6C20; case 0x060B6C22u: goto L_060B6C22; case 0x060B6C24u: goto L_060B6C24; case 0x060B6C26u: goto L_060B6C26; case 0x060B6C28u: goto L_060B6C28; case 0x060B6C2Au: goto L_060B6C2A; case 0x060B6C2Cu: goto L_060B6C2C; case 0x060B6C2Eu: goto L_060B6C2E; case 0x060B6C30u: goto L_060B6C30; case 0x060B6C32u: goto L_060B6C32; case 0x060B6C34u: goto L_060B6C34; case 0x060B6C36u: goto L_060B6C36; case 0x060B6C38u: goto L_060B6C38; case 0x060B6C3Au: goto L_060B6C3A; case 0x060B6C3Cu: goto L_060B6C3C; case 0x060B6C3Eu: goto L_060B6C3E; case 0x060B6C40u: goto L_060B6C40; case 0x060B6C42u: goto L_060B6C42; case 0x060B6C44u: goto L_060B6C44; case 0x060B6C46u: goto L_060B6C46; case 0x060B6C48u: goto L_060B6C48; case 0x060B6C4Au: goto L_060B6C4A; case 0x060B6C4Cu: goto L_060B6C4C; case 0x060B6C4Eu: goto L_060B6C4E; case 0x060B6C50u: goto L_060B6C50; case 0x060B6C52u: goto L_060B6C52; case 0x060B6C54u: goto L_060B6C54; case 0x060B6C56u: goto L_060B6C56; case 0x060B6C58u: goto L_060B6C58; case 0x060B6C5Au: goto L_060B6C5A; case 0x060B6C5Cu: goto L_060B6C5C; case 0x060B6C5Eu: goto L_060B6C5E; case 0x060B6C60u: goto L_060B6C60; case 0x060B6C62u: goto L_060B6C62; case 0x060B6C64u: goto L_060B6C64; case 0x060B6C66u: goto L_060B6C66; case 0x060B6C68u: goto L_060B6C68; case 0x060B6C6Au: goto L_060B6C6A; case 0x060B6C6Cu: goto L_060B6C6C; case 0x060B6C6Eu: goto L_060B6C6E; case 0x060B6C70u: goto L_060B6C70; case 0x060B6C72u: goto L_060B6C72; case 0x060B6C74u: goto L_060B6C74; case 0x060B6C76u: goto L_060B6C76; case 0x060B6C7Au: goto L_060B6C7A; case 0x060B6C7Eu: goto L_060B6C7E; case 0x060B6C80u: goto L_060B6C80; case 0x060B6C82u: goto L_060B6C82; case 0x060B6C84u: goto L_060B6C84; case 0x060B6C86u: goto L_060B6C86; case 0x060B6C88u: goto L_060B6C88; case 0x060B6C8Au: goto L_060B6C8A; case 0x060B6C8Cu: goto L_060B6C8C; case 0x060B6C90u: goto L_060B6C90; case 0x060B6C92u: goto L_060B6C92; case 0x060B6C94u: goto L_060B6C94; case 0x060B6C96u: goto L_060B6C96; case 0x060B6C98u: goto L_060B6C98; case 0x060B6C9Au: goto L_060B6C9A; case 0x060B6C9Cu: goto L_060B6C9C; case 0x060B6C9Eu: goto L_060B6C9E; case 0x060B6CA0u: goto L_060B6CA0; case 0x060B6CA2u: goto L_060B6CA2; case 0x060B6CA4u: goto L_060B6CA4; case 0x060B6CA6u: goto L_060B6CA6; case 0x060B6CA8u: goto L_060B6CA8; case 0x060B6CAAu: goto L_060B6CAA; case 0x060B6CACu: goto L_060B6CAC; case 0x060B6CAEu: goto L_060B6CAE; case 0x060B6CB0u: goto L_060B6CB0; case 0x060B6CB2u: goto L_060B6CB2; case 0x060B6CB4u: goto L_060B6CB4; case 0x060B6CB6u: goto L_060B6CB6; case 0x060B6CB8u: goto L_060B6CB8; case 0x060B6CBAu: goto L_060B6CBA; case 0x060B6CBCu: goto L_060B6CBC; case 0x060B6CBEu: goto L_060B6CBE; case 0x060B6CC0u: goto L_060B6CC0; case 0x060B6CC2u: goto L_060B6CC2; case 0x060B6CC4u: goto L_060B6CC4; case 0x060B6CC6u: goto L_060B6CC6; case 0x060B6CCAu: goto L_060B6CCA; case 0x060B6CCCu: goto L_060B6CCC; case 0x060B6CCEu: goto L_060B6CCE; case 0x060B6CD0u: goto L_060B6CD0; case 0x060B6CD2u: goto L_060B6CD2; case 0x060B6CD4u: goto L_060B6CD4; case 0x060B6CD6u: goto L_060B6CD6; case 0x060B6CD8u: goto L_060B6CD8; case 0x060B6CDAu: goto L_060B6CDA; case 0x060B6CDCu: goto L_060B6CDC; case 0x060B6CDEu: goto L_060B6CDE; case 0x060B6CE0u: goto L_060B6CE0; case 0x060B6CE2u: goto L_060B6CE2; case 0x060B6CE4u: goto L_060B6CE4; case 0x060B6CE6u: goto L_060B6CE6; case 0x060B6CE8u: goto L_060B6CE8; case 0x060B6CEAu: goto L_060B6CEA; case 0x060B6CECu: goto L_060B6CEC; case 0x060B6CEEu: goto L_060B6CEE; case 0x060B6CF0u: goto L_060B6CF0; case 0x060B6CF2u: goto L_060B6CF2; case 0x060B6CF4u: goto L_060B6CF4; case 0x060B6CF6u: goto L_060B6CF6; case 0x060B6CF8u: goto L_060B6CF8; case 0x060B6CFAu: goto L_060B6CFA; case 0x060B6CFCu: goto L_060B6CFC; case 0x060B6CFEu: goto L_060B6CFE; case 0x060B6D00u: goto L_060B6D00; case 0x060B6D02u: goto L_060B6D02; case 0x060B6D04u: goto L_060B6D04; case 0x060B6D06u: goto L_060B6D06; case 0x060B6D08u: goto L_060B6D08; case 0x060B6D0Au: goto L_060B6D0A; case 0x060B6D0Cu: goto L_060B6D0C; case 0x060B6D0Eu: goto L_060B6D0E; case 0x060B6D10u: goto L_060B6D10; case 0x060B6D14u: goto L_060B6D14; case 0x060B6D16u: goto L_060B6D16; case 0x060B6D18u: goto L_060B6D18; case 0x060B6D1Au: goto L_060B6D1A; case 0x060B6D1Cu: goto L_060B6D1C; case 0x060B6D1Eu: goto L_060B6D1E; case 0x060B6D20u: goto L_060B6D20; case 0x060B6D22u: goto L_060B6D22; case 0x060B6D24u: goto L_060B6D24; case 0x060B6D26u: goto L_060B6D26; case 0x060B6D28u: goto L_060B6D28; case 0x060B6D2Au: goto L_060B6D2A; case 0x060B6D2Cu: goto L_060B6D2C; case 0x060B6D2Eu: goto L_060B6D2E; case 0x060B6D30u: goto L_060B6D30; case 0x060B6D32u: goto L_060B6D32; case 0x060B6D34u: goto L_060B6D34; case 0x060B6D36u: goto L_060B6D36; case 0x060B6D38u: goto L_060B6D38; case 0x060B6D3Au: goto L_060B6D3A; case 0x060B6D3Cu: goto L_060B6D3C; case 0x060B6D3Eu: goto L_060B6D3E; case 0x060B6D42u: goto L_060B6D42; case 0x060B6D44u: goto L_060B6D44; case 0x060B6D46u: goto L_060B6D46; case 0x060B6D48u: goto L_060B6D48; case 0x060B6D4Au: goto L_060B6D4A; case 0x060B6D4Cu: goto L_060B6D4C; case 0x060B6D4Eu: goto L_060B6D4E; case 0x060B6D50u: goto L_060B6D50; case 0x060B6D52u: goto L_060B6D52; case 0x060B6D54u: goto L_060B6D54; case 0x060B6D56u: goto L_060B6D56; case 0x060B6D58u: goto L_060B6D58; case 0x060B6D5Au: goto L_060B6D5A; case 0x060B6D5Cu: goto L_060B6D5C; case 0x060B6D5Eu: goto L_060B6D5E; case 0x060B6D60u: goto L_060B6D60; case 0x060B6D62u: goto L_060B6D62; case 0x060B6D64u: goto L_060B6D64; case 0x060B6D66u: goto L_060B6D66; case 0x060B6D68u: goto L_060B6D68; case 0x060B6D6Au: goto L_060B6D6A; case 0x060B6D6Cu: goto L_060B6D6C; case 0x060B6D6Eu: goto L_060B6D6E; case 0x060B6D70u: goto L_060B6D70; case 0x060B6D72u: goto L_060B6D72; case 0x060B6D74u: goto L_060B6D74; case 0x060B6D76u: goto L_060B6D76; case 0x060B6D7Au: goto L_060B6D7A; case 0x060B6D7Cu: goto L_060B6D7C; case 0x060B6D7Eu: goto L_060B6D7E; case 0x060B6D80u: goto L_060B6D80; case 0x060B6D82u: goto L_060B6D82; case 0x060B6D84u: goto L_060B6D84; case 0x060B6D86u: goto L_060B6D86; case 0x060B6DC4u: goto L_060B6DC4; case 0x060B6DC6u: goto L_060B6DC6; case 0x060B6DC8u: goto L_060B6DC8; case 0x060B6DCCu: goto L_060B6DCC; case 0x060B6DCEu: goto L_060B6DCE; case 0x060B6DD0u: goto L_060B6DD0; case 0x060B6DD2u: goto L_060B6DD2; case 0x060B6DD4u: goto L_060B6DD4; case 0x060B6DD6u: goto L_060B6DD6; case 0x060B6DD8u: goto L_060B6DD8; case 0x060B6DDAu: goto L_060B6DDA; case 0x060B6DDCu: goto L_060B6DDC; case 0x060B6DDEu: goto L_060B6DDE; case 0x060B6DE0u: goto L_060B6DE0; case 0x060B6DE2u: goto L_060B6DE2; case 0x060B6DE4u: goto L_060B6DE4; case 0x060B6DE6u: goto L_060B6DE6; case 0x060B6DE8u: goto L_060B6DE8; case 0x060B6DEAu: goto L_060B6DEA; case 0x060B6DECu: goto L_060B6DEC; case 0x060B6DEEu: goto L_060B6DEE; case 0x060B6DF0u: goto L_060B6DF0; case 0x060B6DF2u: goto L_060B6DF2; case 0x060B6DF6u: goto L_060B6DF6; case 0x060B6DF8u: goto L_060B6DF8; case 0x060B6DFAu: goto L_060B6DFA; case 0x060B6DFCu: goto L_060B6DFC; case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
}

void f_060B6E94(SH2Context& c) {
    ran[3126] = 1;
    goto L_060B6E94;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6E94u: goto L_060B6E94; case 0x060B6E96u: goto L_060B6E96; case 0x060B6E98u: goto L_060B6E98; case 0x060B6E9Au: goto L_060B6E9A; case 0x060B6E9Cu: goto L_060B6E9C; case 0x060B6E9Eu: goto L_060B6E9E; case 0x060B6EA0u: goto L_060B6EA0; case 0x060B6EA2u: goto L_060B6EA2; case 0x060B6EA4u: goto L_060B6EA4; case 0x060B6EA6u: goto L_060B6EA6; case 0x060B6EA8u: goto L_060B6EA8; case 0x060B6EAAu: goto L_060B6EAA; case 0x060B6EACu: goto L_060B6EAC; case 0x060B6EAEu: goto L_060B6EAE; case 0x060B6EB0u: goto L_060B6EB0; case 0x060B6EB2u: goto L_060B6EB2; case 0x060B6EB4u: goto L_060B6EB4; case 0x060B6EB6u: goto L_060B6EB6; case 0x060B6EB8u: goto L_060B6EB8; case 0x060B6EBAu: goto L_060B6EBA; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6E94u: goto L_060B6E94; case 0x060B6E96u: goto L_060B6E96; case 0x060B6E98u: goto L_060B6E98; case 0x060B6E9Au: goto L_060B6E9A; case 0x060B6E9Cu: goto L_060B6E9C; case 0x060B6E9Eu: goto L_060B6E9E; case 0x060B6EA0u: goto L_060B6EA0; case 0x060B6EA2u: goto L_060B6EA2; case 0x060B6EA4u: goto L_060B6EA4; case 0x060B6EA6u: goto L_060B6EA6; case 0x060B6EA8u: goto L_060B6EA8; case 0x060B6EAAu: goto L_060B6EAA; case 0x060B6EACu: goto L_060B6EAC; case 0x060B6EAEu: goto L_060B6EAE; case 0x060B6EB0u: goto L_060B6EB0; case 0x060B6EB2u: goto L_060B6EB2; case 0x060B6EB4u: goto L_060B6EB4; case 0x060B6EB6u: goto L_060B6EB6; case 0x060B6EB8u: goto L_060B6EB8; case 0x060B6EBAu: goto L_060B6EBA; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6E94:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 2);  // 060B6E94 mov.w @(2,r8),r0
L_060B6E96:
    c.r[5] = ld32(c.r[15] + 20);  // 060B6E96 mov.l @(20,r15),r5
L_060B6E98:
    c.r[0] <<= 2;  // 060B6E98 shll2 r0
L_060B6E9A:
    c.r[0] += c.r[0];  // 060B6E9A add r0,r0
L_060B6E9C:
    c.r[0] = ld32(c.r[0] + c.r[5]);  // 060B6E9C mov.l @(r0,r5),r0
L_060B6E9E:
    st32(c.r[11] + 8, c.r[0]);  // 060B6E9E mov.l r0,@(8,r11)
L_060B6EA0:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B6EA0 mov.w @(8,r8),r0
L_060B6EA2:
    c.r[5] = ld32(c.r[8] + 4);  // 060B6EA2 mov.l @(4,r8),r5
L_060B6EA4:
    st16(c.r[11] + 28, c.r[0]);  // 060B6EA4 mov.w r0,@(28,r11)
L_060B6EA6:
    st32(c.r[11] + 4, c.r[5]);  // 060B6EA6 mov.l r5,@(4,r11)
L_060B6EA8:
    c.r[0] = c.r[14];  // 060B6EA8 mov r14,r0
L_060B6EAA:
    st16(c.r[11] + 30, c.r[0]);  // 060B6EAA mov.w r0,@(30,r11)
L_060B6EAC:
    c.r[0] = ld32(c.gbr + 56);  // 060B6EAC mov.l @(56,gbr),r0
L_060B6EAE:
    c.r[1] = (c.r[14] & 0xFFFF0000u) | (c.r[14] & 0xFFu) << 8 | (c.r[14] >> 8 & 0xFFu);  // 060B6EAE swap.b r14,r1
L_060B6EB0:
    c.r[1] = c.r[1] & 0xFFu;  // 060B6EB0 extu.b r1,r1
L_060B6EB2:
    c.r[1] <<= 2;  // 060B6EB2 shll2 r1
L_060B6EB4:
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060B6EB4 mov.l @(r0,r1),r2
L_060B6EB6:
    st32(c.r[0] + c.r[1], c.r[11]);  // 060B6EB6 mov.l r11,@(r0,r1)
L_060B6EB8:
    st32(c.r[11] + 32, c.r[2]);  // 060B6EB8 mov.l r2,@(32,r11)
L_060B6EBA:
    c.r[11] += 36;  // 060B6EBA add #36,r11
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
}

void f_060B6EA0(SH2Context& c) {
    ran[3127] = 1;
    goto L_060B6EA0;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EA0u: goto L_060B6EA0; case 0x060B6EA2u: goto L_060B6EA2; case 0x060B6EA4u: goto L_060B6EA4; case 0x060B6EA6u: goto L_060B6EA6; case 0x060B6EA8u: goto L_060B6EA8; case 0x060B6EAAu: goto L_060B6EAA; case 0x060B6EACu: goto L_060B6EAC; case 0x060B6EAEu: goto L_060B6EAE; case 0x060B6EB0u: goto L_060B6EB0; case 0x060B6EB2u: goto L_060B6EB2; case 0x060B6EB4u: goto L_060B6EB4; case 0x060B6EB6u: goto L_060B6EB6; case 0x060B6EB8u: goto L_060B6EB8; case 0x060B6EBAu: goto L_060B6EBA; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EA0u: goto L_060B6EA0; case 0x060B6EA2u: goto L_060B6EA2; case 0x060B6EA4u: goto L_060B6EA4; case 0x060B6EA6u: goto L_060B6EA6; case 0x060B6EA8u: goto L_060B6EA8; case 0x060B6EAAu: goto L_060B6EAA; case 0x060B6EACu: goto L_060B6EAC; case 0x060B6EAEu: goto L_060B6EAE; case 0x060B6EB0u: goto L_060B6EB0; case 0x060B6EB2u: goto L_060B6EB2; case 0x060B6EB4u: goto L_060B6EB4; case 0x060B6EB6u: goto L_060B6EB6; case 0x060B6EB8u: goto L_060B6EB8; case 0x060B6EBAu: goto L_060B6EBA; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EA0:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B6EA0 mov.w @(8,r8),r0
L_060B6EA2:
    c.r[5] = ld32(c.r[8] + 4);  // 060B6EA2 mov.l @(4,r8),r5
L_060B6EA4:
    st16(c.r[11] + 28, c.r[0]);  // 060B6EA4 mov.w r0,@(28,r11)
L_060B6EA6:
    st32(c.r[11] + 4, c.r[5]);  // 060B6EA6 mov.l r5,@(4,r11)
L_060B6EA8:
    c.r[0] = c.r[14];  // 060B6EA8 mov r14,r0
L_060B6EAA:
    st16(c.r[11] + 30, c.r[0]);  // 060B6EAA mov.w r0,@(30,r11)
L_060B6EAC:
    c.r[0] = ld32(c.gbr + 56);  // 060B6EAC mov.l @(56,gbr),r0
L_060B6EAE:
    c.r[1] = (c.r[14] & 0xFFFF0000u) | (c.r[14] & 0xFFu) << 8 | (c.r[14] >> 8 & 0xFFu);  // 060B6EAE swap.b r14,r1
L_060B6EB0:
    c.r[1] = c.r[1] & 0xFFu;  // 060B6EB0 extu.b r1,r1
L_060B6EB2:
    c.r[1] <<= 2;  // 060B6EB2 shll2 r1
L_060B6EB4:
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060B6EB4 mov.l @(r0,r1),r2
L_060B6EB6:
    st32(c.r[0] + c.r[1], c.r[11]);  // 060B6EB6 mov.l r11,@(r0,r1)
L_060B6EB8:
    st32(c.r[11] + 32, c.r[2]);  // 060B6EB8 mov.l r2,@(32,r11)
L_060B6EBA:
    c.r[11] += 36;  // 060B6EBA add #36,r11
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
}

void f_060B6EA8(SH2Context& c) {
    ran[3128] = 1;
    goto L_060B6EA8;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EA8u: goto L_060B6EA8; case 0x060B6EAAu: goto L_060B6EAA; case 0x060B6EACu: goto L_060B6EAC; case 0x060B6EAEu: goto L_060B6EAE; case 0x060B6EB0u: goto L_060B6EB0; case 0x060B6EB2u: goto L_060B6EB2; case 0x060B6EB4u: goto L_060B6EB4; case 0x060B6EB6u: goto L_060B6EB6; case 0x060B6EB8u: goto L_060B6EB8; case 0x060B6EBAu: goto L_060B6EBA; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EA8u: goto L_060B6EA8; case 0x060B6EAAu: goto L_060B6EAA; case 0x060B6EACu: goto L_060B6EAC; case 0x060B6EAEu: goto L_060B6EAE; case 0x060B6EB0u: goto L_060B6EB0; case 0x060B6EB2u: goto L_060B6EB2; case 0x060B6EB4u: goto L_060B6EB4; case 0x060B6EB6u: goto L_060B6EB6; case 0x060B6EB8u: goto L_060B6EB8; case 0x060B6EBAu: goto L_060B6EBA; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EA8:
    c.r[0] = c.r[14];  // 060B6EA8 mov r14,r0
L_060B6EAA:
    st16(c.r[11] + 30, c.r[0]);  // 060B6EAA mov.w r0,@(30,r11)
L_060B6EAC:
    c.r[0] = ld32(c.gbr + 56);  // 060B6EAC mov.l @(56,gbr),r0
L_060B6EAE:
    c.r[1] = (c.r[14] & 0xFFFF0000u) | (c.r[14] & 0xFFu) << 8 | (c.r[14] >> 8 & 0xFFu);  // 060B6EAE swap.b r14,r1
L_060B6EB0:
    c.r[1] = c.r[1] & 0xFFu;  // 060B6EB0 extu.b r1,r1
L_060B6EB2:
    c.r[1] <<= 2;  // 060B6EB2 shll2 r1
L_060B6EB4:
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060B6EB4 mov.l @(r0,r1),r2
L_060B6EB6:
    st32(c.r[0] + c.r[1], c.r[11]);  // 060B6EB6 mov.l r11,@(r0,r1)
L_060B6EB8:
    st32(c.r[11] + 32, c.r[2]);  // 060B6EB8 mov.l r2,@(32,r11)
L_060B6EBA:
    c.r[11] += 36;  // 060B6EBA add #36,r11
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
}

void f_060B6ED4(SH2Context& c) {
    ran[3129] = 1;
    goto L_060B6ED4;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6ED4u: goto L_060B6ED4; case 0x060B6ED6u: goto L_060B6ED6; case 0x060B6ED8u: goto L_060B6ED8; case 0x060B6EDAu: goto L_060B6EDA; case 0x060B6EDCu: goto L_060B6EDC; case 0x060B6EDEu: goto L_060B6EDE; case 0x060B6EE0u: goto L_060B6EE0; case 0x060B6EE2u: goto L_060B6EE2; case 0x060B6EE4u: goto L_060B6EE4; case 0x060B6EE6u: goto L_060B6EE6; case 0x060B6EE8u: goto L_060B6EE8; case 0x060B6EEAu: goto L_060B6EEA; case 0x060B6EECu: goto L_060B6EEC; case 0x060B6EEEu: goto L_060B6EEE; case 0x060B6EF0u: goto L_060B6EF0; case 0x060B6EF2u: goto L_060B6EF2; case 0x060B6EF4u: goto L_060B6EF4; case 0x060B6EF6u: goto L_060B6EF6; case 0x060B6EF8u: goto L_060B6EF8; case 0x060B6EFAu: goto L_060B6EFA; case 0x060B6EFCu: goto L_060B6EFC; case 0x060B6EFEu: goto L_060B6EFE; case 0x060B6F00u: goto L_060B6F00; case 0x060B6F02u: goto L_060B6F02; case 0x060B6F04u: goto L_060B6F04; case 0x060B6F06u: goto L_060B6F06; case 0x060B6F0Au: goto L_060B6F0A; case 0x060B6F0Cu: goto L_060B6F0C; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6ED4u: goto L_060B6ED4; case 0x060B6ED6u: goto L_060B6ED6; case 0x060B6ED8u: goto L_060B6ED8; case 0x060B6EDAu: goto L_060B6EDA; case 0x060B6EDCu: goto L_060B6EDC; case 0x060B6EDEu: goto L_060B6EDE; case 0x060B6EE0u: goto L_060B6EE0; case 0x060B6EE2u: goto L_060B6EE2; case 0x060B6EE4u: goto L_060B6EE4; case 0x060B6EE6u: goto L_060B6EE6; case 0x060B6EE8u: goto L_060B6EE8; case 0x060B6EEAu: goto L_060B6EEA; case 0x060B6EECu: goto L_060B6EEC; case 0x060B6EEEu: goto L_060B6EEE; case 0x060B6EF0u: goto L_060B6EF0; case 0x060B6EF2u: goto L_060B6EF2; case 0x060B6EF4u: goto L_060B6EF4; case 0x060B6EF6u: goto L_060B6EF6; case 0x060B6EF8u: goto L_060B6EF8; case 0x060B6EFAu: goto L_060B6EFA; case 0x060B6EFCu: goto L_060B6EFC; case 0x060B6EFEu: goto L_060B6EFE; case 0x060B6F00u: goto L_060B6F00; case 0x060B6F02u: goto L_060B6F02; case 0x060B6F04u: goto L_060B6F04; case 0x060B6F06u: goto L_060B6F06; case 0x060B6F0Au: goto L_060B6F0A; case 0x060B6F0Cu: goto L_060B6F0C; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B6ED4:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6ED4 mov.w @r7+,r3
L_060B6ED6:
    c.r[2] <<= 2;  // 060B6ED6 shll2 r2
L_060B6ED8:
    c.r[14] = ld32(c.r[1] + 12);  // 060B6ED8 mov.l @(12,r1),r14
L_060B6EDA:
    c.r[2] += c.r[10];  // 060B6EDA add r10,r2
L_060B6EDC:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6EDC mov.w @r7+,r4
L_060B6EDE:
    c.r[0] = ld32(c.r[2] + 12);  // 060B6EDE mov.l @(12,r2),r0
L_060B6EE0:
    c.r[3] <<= 2;  // 060B6EE0 shll2 r3
L_060B6EE2:
    c.r[14] += c.r[0];  // 060B6EE2 add r0,r14
L_060B6EE4:
    c.r[3] <<= 2;  // 060B6EE4 shll2 r3
L_060B6EE6:
    c.r[3] += c.r[10];  // 060B6EE6 add r10,r3
L_060B6EE8:
    c.r[4] <<= 2;  // 060B6EE8 shll2 r4
L_060B6EEA:
    c.r[0] = ld32(c.r[3] + 12);  // 060B6EEA mov.l @(12,r3),r0
L_060B6EEC:
    c.r[4] <<= 2;  // 060B6EEC shll2 r4
L_060B6EEE:
    c.r[14] += c.r[0];  // 060B6EEE add r0,r14
L_060B6EF0:
    c.r[4] += c.r[10];  // 060B6EF0 add r10,r4
L_060B6EF2:
    c.r[0] = ld32(c.r[4] + 12);  // 060B6EF2 mov.l @(12,r4),r0
L_060B6EF4:
    c.r[14] += c.r[0];  // 060B6EF4 add r0,r14
L_060B6EF6:
    c.r[14] >>= 16;  // 060B6EF6 shlr16 r14
L_060B6EF8:
    c.r[14] = (uint32_t)(int32_t)(int16_t)c.r[14];  // 060B6EF8 exts.w r14,r14
L_060B6EFA:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B6EFA shar r14
L_060B6EFC:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B6EFC shar r14
L_060B6EFE:
    c.r[5] = ld32(c.r[15] + 12);  // 060B6EFE mov.l @(12,r15),r5
L_060B6F00:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B6F00 mov.w @(160,gbr),r0
L_060B6F02:
    c.r[14] -= c.r[5];  // 060B6F02 sub r5,r14
L_060B6F04:
    c.t = c.r[14] > c.r[0];  // 060B6F04 cmp/hi r0,r14
L_060B6F06:
    { const bool k = c.t; c.r[14] += c.r[5]; if (k) { SH2_POLL(c); goto L_060B6EBC; } }  // 060B6F06 bt/s 0x060B6EBC ; add r5,r14
L_060B6F0A:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6F0A mov.l @r9+,r0
L_060B6F0C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6ED4u: goto L_060B6ED4; case 0x060B6ED6u: goto L_060B6ED6; case 0x060B6ED8u: goto L_060B6ED8; case 0x060B6EDAu: goto L_060B6EDA; case 0x060B6EDCu: goto L_060B6EDC; case 0x060B6EDEu: goto L_060B6EDE; case 0x060B6EE0u: goto L_060B6EE0; case 0x060B6EE2u: goto L_060B6EE2; case 0x060B6EE4u: goto L_060B6EE4; case 0x060B6EE6u: goto L_060B6EE6; case 0x060B6EE8u: goto L_060B6EE8; case 0x060B6EEAu: goto L_060B6EEA; case 0x060B6EECu: goto L_060B6EEC; case 0x060B6EEEu: goto L_060B6EEE; case 0x060B6EF0u: goto L_060B6EF0; case 0x060B6EF2u: goto L_060B6EF2; case 0x060B6EF4u: goto L_060B6EF4; case 0x060B6EF6u: goto L_060B6EF6; case 0x060B6EF8u: goto L_060B6EF8; case 0x060B6EFAu: goto L_060B6EFA; case 0x060B6EFCu: goto L_060B6EFC; case 0x060B6EFEu: goto L_060B6EFE; case 0x060B6F00u: goto L_060B6F00; case 0x060B6F02u: goto L_060B6F02; case 0x060B6F04u: goto L_060B6F04; case 0x060B6F06u: goto L_060B6F06; case 0x060B6F0Au: goto L_060B6F0A; case 0x060B6F0Cu: goto L_060B6F0C; default: sh2_call(c, x); return; } }  // 060B6F0C jmp @r0 ; nop
}

void f_060B6F10(SH2Context& c) {
    ran[3130] = 1;
    goto L_060B6F10;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F10u: goto L_060B6F10; case 0x060B6F12u: goto L_060B6F12; case 0x060B6F14u: goto L_060B6F14; case 0x060B6F16u: goto L_060B6F16; case 0x060B6F18u: goto L_060B6F18; case 0x060B6F1Au: goto L_060B6F1A; case 0x060B6F1Cu: goto L_060B6F1C; case 0x060B6F1Eu: goto L_060B6F1E; case 0x060B6F20u: goto L_060B6F20; case 0x060B6F22u: goto L_060B6F22; case 0x060B6F26u: goto L_060B6F26; case 0x060B6F28u: goto L_060B6F28; case 0x060B6F2Au: goto L_060B6F2A; case 0x060B6F2Cu: goto L_060B6F2C; case 0x060B6F2Eu: goto L_060B6F2E; case 0x060B6F30u: goto L_060B6F30; case 0x060B6F32u: goto L_060B6F32; case 0x060B6F36u: goto L_060B6F36; case 0x060B6F38u: goto L_060B6F38; case 0x060B6F3Au: goto L_060B6F3A; case 0x060B6F3Cu: goto L_060B6F3C; case 0x060B6F3Eu: goto L_060B6F3E; case 0x060B6F40u: goto L_060B6F40; case 0x060B6F42u: goto L_060B6F42; case 0x060B6F44u: goto L_060B6F44; case 0x060B6F46u: goto L_060B6F46; case 0x060B6F48u: goto L_060B6F48; case 0x060B6F4Cu: goto L_060B6F4C; case 0x060B6F4Eu: goto L_060B6F4E; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F10u: goto L_060B6F10; case 0x060B6F12u: goto L_060B6F12; case 0x060B6F14u: goto L_060B6F14; case 0x060B6F16u: goto L_060B6F16; case 0x060B6F18u: goto L_060B6F18; case 0x060B6F1Au: goto L_060B6F1A; case 0x060B6F1Cu: goto L_060B6F1C; case 0x060B6F1Eu: goto L_060B6F1E; case 0x060B6F20u: goto L_060B6F20; case 0x060B6F22u: goto L_060B6F22; case 0x060B6F26u: goto L_060B6F26; case 0x060B6F28u: goto L_060B6F28; case 0x060B6F2Au: goto L_060B6F2A; case 0x060B6F2Cu: goto L_060B6F2C; case 0x060B6F2Eu: goto L_060B6F2E; case 0x060B6F30u: goto L_060B6F30; case 0x060B6F32u: goto L_060B6F32; case 0x060B6F36u: goto L_060B6F36; case 0x060B6F38u: goto L_060B6F38; case 0x060B6F3Au: goto L_060B6F3A; case 0x060B6F3Cu: goto L_060B6F3C; case 0x060B6F3Eu: goto L_060B6F3E; case 0x060B6F40u: goto L_060B6F40; case 0x060B6F42u: goto L_060B6F42; case 0x060B6F44u: goto L_060B6F44; case 0x060B6F46u: goto L_060B6F46; case 0x060B6F48u: goto L_060B6F48; case 0x060B6F4Cu: goto L_060B6F4C; case 0x060B6F4Eu: goto L_060B6F4E; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B6F10:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 12);  // 060B6F10 mov.w @(12,r1),r0
L_060B6F12:
    c.r[2] <<= 2;  // 060B6F12 shll2 r2
L_060B6F14:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6F14 mov.w @r7+,r3
L_060B6F16:
    c.r[14] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6F16 exts.w r0,r14
L_060B6F18:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6F18 mov.w @r7+,r4
L_060B6F1A:
    c.r[2] += c.r[10];  // 060B6F1A add r10,r2
L_060B6F1C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 12);  // 060B6F1C mov.w @(12,r2),r0
L_060B6F1E:
    c.r[3] <<= 2;  // 060B6F1E shll2 r3
L_060B6F20:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B6F20 cmp/gt r0,r14
L_060B6F22:
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_060B6F28; } }  // 060B6F22 bf/s 0x060B6F28 ; shll2 r3
L_060B6F26:
    c.r[14] = c.r[0];  // 060B6F26 mov r0,r14
L_060B6F28:
    c.r[3] += c.r[10];  // 060B6F28 add r10,r3
L_060B6F2A:
    c.r[4] <<= 2;  // 060B6F2A shll2 r4
L_060B6F2C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 12);  // 060B6F2C mov.w @(12,r3),r0
L_060B6F2E:
    c.r[4] <<= 2;  // 060B6F2E shll2 r4
L_060B6F30:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B6F30 cmp/gt r0,r14
L_060B6F32:
    { const bool k = !c.t; c.r[4] += c.r[10]; if (k) { goto L_060B6F38; } }  // 060B6F32 bf/s 0x060B6F38 ; add r10,r4
L_060B6F36:
    c.r[14] = c.r[0];  // 060B6F36 mov r0,r14
L_060B6F38:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 12);  // 060B6F38 mov.w @(12,r4),r0
L_060B6F3A:
    c.r[5] = ld32(c.r[15] + 12);  // 060B6F3A mov.l @(12,r15),r5
L_060B6F3C:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B6F3C cmp/gt r0,r14
L_060B6F3E:
    if (!c.t) { goto L_060B6F42; }  // 060B6F3E bf 0x060B6F42
L_060B6F40:
    c.r[14] = c.r[0];  // 060B6F40 mov r0,r14
L_060B6F42:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B6F42 mov.w @(160,gbr),r0
L_060B6F44:
    c.r[14] -= c.r[5];  // 060B6F44 sub r5,r14
L_060B6F46:
    c.t = c.r[14] > c.r[0];  // 060B6F46 cmp/hi r0,r14
L_060B6F48:
    { const bool k = c.t; c.r[14] += c.r[5]; if (k) { SH2_POLL(c); goto L_060B6EBC; } }  // 060B6F48 bt/s 0x060B6EBC ; add r5,r14
L_060B6F4C:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6F4C mov.l @r9+,r0
L_060B6F4E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F10u: goto L_060B6F10; case 0x060B6F12u: goto L_060B6F12; case 0x060B6F14u: goto L_060B6F14; case 0x060B6F16u: goto L_060B6F16; case 0x060B6F18u: goto L_060B6F18; case 0x060B6F1Au: goto L_060B6F1A; case 0x060B6F1Cu: goto L_060B6F1C; case 0x060B6F1Eu: goto L_060B6F1E; case 0x060B6F20u: goto L_060B6F20; case 0x060B6F22u: goto L_060B6F22; case 0x060B6F26u: goto L_060B6F26; case 0x060B6F28u: goto L_060B6F28; case 0x060B6F2Au: goto L_060B6F2A; case 0x060B6F2Cu: goto L_060B6F2C; case 0x060B6F2Eu: goto L_060B6F2E; case 0x060B6F30u: goto L_060B6F30; case 0x060B6F32u: goto L_060B6F32; case 0x060B6F36u: goto L_060B6F36; case 0x060B6F38u: goto L_060B6F38; case 0x060B6F3Au: goto L_060B6F3A; case 0x060B6F3Cu: goto L_060B6F3C; case 0x060B6F3Eu: goto L_060B6F3E; case 0x060B6F40u: goto L_060B6F40; case 0x060B6F42u: goto L_060B6F42; case 0x060B6F44u: goto L_060B6F44; case 0x060B6F46u: goto L_060B6F46; case 0x060B6F48u: goto L_060B6F48; case 0x060B6F4Cu: goto L_060B6F4C; case 0x060B6F4Eu: goto L_060B6F4E; default: sh2_call(c, x); return; } }  // 060B6F4E jmp @r0 ; nop
}

void f_060B6F54(SH2Context& c) {
    ran[3131] = 1;
    goto L_060B6F54;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F54u: goto L_060B6F54; case 0x060B6F56u: goto L_060B6F56; case 0x060B6F58u: goto L_060B6F58; case 0x060B6F5Au: goto L_060B6F5A; case 0x060B6F5Cu: goto L_060B6F5C; case 0x060B6F5Eu: goto L_060B6F5E; case 0x060B6F60u: goto L_060B6F60; case 0x060B6F62u: goto L_060B6F62; case 0x060B6F64u: goto L_060B6F64; case 0x060B6F66u: goto L_060B6F66; case 0x060B6F68u: goto L_060B6F68; case 0x060B6F6Au: goto L_060B6F6A; case 0x060B6F6Eu: goto L_060B6F6E; case 0x060B6F70u: goto L_060B6F70; case 0x060B6F72u: goto L_060B6F72; case 0x060B6F74u: goto L_060B6F74; case 0x060B6F76u: goto L_060B6F76; case 0x060B6F7Au: goto L_060B6F7A; case 0x060B6F7Cu: goto L_060B6F7C; case 0x060B6F7Eu: goto L_060B6F7E; case 0x060B6F80u: goto L_060B6F80; case 0x060B6F82u: goto L_060B6F82; case 0x060B6F84u: goto L_060B6F84; case 0x060B6F86u: goto L_060B6F86; case 0x060B6F88u: goto L_060B6F88; case 0x060B6F8Au: goto L_060B6F8A; case 0x060B6F8Cu: goto L_060B6F8C; case 0x060B6F90u: goto L_060B6F90; case 0x060B6F92u: goto L_060B6F92; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F54u: goto L_060B6F54; case 0x060B6F56u: goto L_060B6F56; case 0x060B6F58u: goto L_060B6F58; case 0x060B6F5Au: goto L_060B6F5A; case 0x060B6F5Cu: goto L_060B6F5C; case 0x060B6F5Eu: goto L_060B6F5E; case 0x060B6F60u: goto L_060B6F60; case 0x060B6F62u: goto L_060B6F62; case 0x060B6F64u: goto L_060B6F64; case 0x060B6F66u: goto L_060B6F66; case 0x060B6F68u: goto L_060B6F68; case 0x060B6F6Au: goto L_060B6F6A; case 0x060B6F6Eu: goto L_060B6F6E; case 0x060B6F70u: goto L_060B6F70; case 0x060B6F72u: goto L_060B6F72; case 0x060B6F74u: goto L_060B6F74; case 0x060B6F76u: goto L_060B6F76; case 0x060B6F7Au: goto L_060B6F7A; case 0x060B6F7Cu: goto L_060B6F7C; case 0x060B6F7Eu: goto L_060B6F7E; case 0x060B6F80u: goto L_060B6F80; case 0x060B6F82u: goto L_060B6F82; case 0x060B6F84u: goto L_060B6F84; case 0x060B6F86u: goto L_060B6F86; case 0x060B6F88u: goto L_060B6F88; case 0x060B6F8Au: goto L_060B6F8A; case 0x060B6F8Cu: goto L_060B6F8C; case 0x060B6F90u: goto L_060B6F90; case 0x060B6F92u: goto L_060B6F92; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B6F54:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6F54 mov.w @r7+,r3
L_060B6F56:
    c.r[2] <<= 2;  // 060B6F56 shll2 r2
L_060B6F58:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 12);  // 060B6F58 mov.w @(12,r1),r0
L_060B6F5A:
    c.r[2] += c.r[10];  // 060B6F5A add r10,r2
L_060B6F5C:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6F5C mov.w @r7+,r4
L_060B6F5E:
    c.r[14] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6F5E exts.w r0,r14
L_060B6F60:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 12);  // 060B6F60 mov.w @(12,r2),r0
L_060B6F62:
    c.r[3] <<= 2;  // 060B6F62 shll2 r3
L_060B6F64:
    c.r[3] <<= 2;  // 060B6F64 shll2 r3
L_060B6F66:
    c.r[3] += c.r[10];  // 060B6F66 add r10,r3
L_060B6F68:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B6F68 cmp/ge r0,r14
L_060B6F6A:
    { const bool k = c.t; c.r[4] <<= 2; if (k) { goto L_060B6F70; } }  // 060B6F6A bt/s 0x060B6F70 ; shll2 r4
L_060B6F6E:
    c.r[14] = c.r[0];  // 060B6F6E mov r0,r14
L_060B6F70:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 12);  // 060B6F70 mov.w @(12,r3),r0
L_060B6F72:
    c.r[4] <<= 2;  // 060B6F72 shll2 r4
L_060B6F74:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B6F74 cmp/ge r0,r14
L_060B6F76:
    { const bool k = c.t; c.r[4] += c.r[10]; if (k) { goto L_060B6F7C; } }  // 060B6F76 bt/s 0x060B6F7C ; add r10,r4
L_060B6F7A:
    c.r[14] = c.r[0];  // 060B6F7A mov r0,r14
L_060B6F7C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 12);  // 060B6F7C mov.w @(12,r4),r0
L_060B6F7E:
    c.r[5] = ld32(c.r[15] + 12);  // 060B6F7E mov.l @(12,r15),r5
L_060B6F80:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B6F80 cmp/ge r0,r14
L_060B6F82:
    if (c.t) { goto L_060B6F86; }  // 060B6F82 bt 0x060B6F86
L_060B6F84:
    c.r[14] = c.r[0];  // 060B6F84 mov r0,r14
L_060B6F86:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B6F86 mov.w @(160,gbr),r0
L_060B6F88:
    c.r[14] -= c.r[5];  // 060B6F88 sub r5,r14
L_060B6F8A:
    c.t = c.r[14] > c.r[0];  // 060B6F8A cmp/hi r0,r14
L_060B6F8C:
    { const bool k = c.t; c.r[14] += c.r[5]; if (k) { SH2_POLL(c); goto L_060B6EBC; } }  // 060B6F8C bt/s 0x060B6EBC ; add r5,r14
L_060B6F90:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6F90 mov.l @r9+,r0
L_060B6F92:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F54u: goto L_060B6F54; case 0x060B6F56u: goto L_060B6F56; case 0x060B6F58u: goto L_060B6F58; case 0x060B6F5Au: goto L_060B6F5A; case 0x060B6F5Cu: goto L_060B6F5C; case 0x060B6F5Eu: goto L_060B6F5E; case 0x060B6F60u: goto L_060B6F60; case 0x060B6F62u: goto L_060B6F62; case 0x060B6F64u: goto L_060B6F64; case 0x060B6F66u: goto L_060B6F66; case 0x060B6F68u: goto L_060B6F68; case 0x060B6F6Au: goto L_060B6F6A; case 0x060B6F6Eu: goto L_060B6F6E; case 0x060B6F70u: goto L_060B6F70; case 0x060B6F72u: goto L_060B6F72; case 0x060B6F74u: goto L_060B6F74; case 0x060B6F76u: goto L_060B6F76; case 0x060B6F7Au: goto L_060B6F7A; case 0x060B6F7Cu: goto L_060B6F7C; case 0x060B6F7Eu: goto L_060B6F7E; case 0x060B6F80u: goto L_060B6F80; case 0x060B6F82u: goto L_060B6F82; case 0x060B6F84u: goto L_060B6F84; case 0x060B6F86u: goto L_060B6F86; case 0x060B6F88u: goto L_060B6F88; case 0x060B6F8Au: goto L_060B6F8A; case 0x060B6F8Cu: goto L_060B6F8C; case 0x060B6F90u: goto L_060B6F90; case 0x060B6F92u: goto L_060B6F92; default: sh2_call(c, x); return; } }  // 060B6F92 jmp @r0 ; nop
}

void f_060B6F98(SH2Context& c) {
    ran[3132] = 1;
    goto L_060B6F98;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F98u: goto L_060B6F98; case 0x060B6F9Au: goto L_060B6F9A; case 0x060B6F9Cu: goto L_060B6F9C; case 0x060B6F9Eu: goto L_060B6F9E; case 0x060B6FA2u: goto L_060B6FA2; case 0x060B6FA4u: goto L_060B6FA4; case 0x060B6FA6u: goto L_060B6FA6; case 0x060B6FA8u: goto L_060B6FA8; case 0x060B6FAAu: goto L_060B6FAA; case 0x060B6FACu: goto L_060B6FAC; case 0x060B6FAEu: goto L_060B6FAE; case 0x060B6FB0u: goto L_060B6FB0; case 0x060B6FB2u: goto L_060B6FB2; case 0x060B6FB6u: goto L_060B6FB6; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F98u: goto L_060B6F98; case 0x060B6F9Au: goto L_060B6F9A; case 0x060B6F9Cu: goto L_060B6F9C; case 0x060B6F9Eu: goto L_060B6F9E; case 0x060B6FA2u: goto L_060B6FA2; case 0x060B6FA4u: goto L_060B6FA4; case 0x060B6FA6u: goto L_060B6FA6; case 0x060B6FA8u: goto L_060B6FA8; case 0x060B6FAAu: goto L_060B6FAA; case 0x060B6FACu: goto L_060B6FAC; case 0x060B6FAEu: goto L_060B6FAE; case 0x060B6FB0u: goto L_060B6FB0; case 0x060B6FB2u: goto L_060B6FB2; case 0x060B6FB6u: goto L_060B6FB6; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B6F98:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B6F98 mov.w @(160,gbr),r0
L_060B6F9A:
    c.r[2] <<= 2;  // 060B6F9A shll2 r2
L_060B6F9C:
    c.t = c.r[14] > c.r[0];  // 060B6F9C cmp/hi r0,r14
L_060B6F9E:
    { const bool k = c.t; c.r[2] += c.r[10]; if (k) { goto L_060B6FB6; } }  // 060B6F9E bt/s 0x060B6FB6 ; add r10,r2
L_060B6FA2:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6FA2 mov.w @r7+,r3
L_060B6FA4:
    c.r[3] <<= 2;  // 060B6FA4 shll2 r3
L_060B6FA6:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6FA6 mov.w @r7+,r4
L_060B6FA8:
    c.r[3] <<= 2;  // 060B6FA8 shll2 r3
L_060B6FAA:
    c.r[3] += c.r[10];  // 060B6FAA add r10,r3
L_060B6FAC:
    c.r[4] <<= 2;  // 060B6FAC shll2 r4
L_060B6FAE:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6FAE mov.l @r9+,r0
L_060B6FB0:
    c.r[4] <<= 2;  // 060B6FB0 shll2 r4
L_060B6FB2:
    { const uint32_t x = c.r[0]; c.r[4] += c.r[10]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6F98u: goto L_060B6F98; case 0x060B6F9Au: goto L_060B6F9A; case 0x060B6F9Cu: goto L_060B6F9C; case 0x060B6F9Eu: goto L_060B6F9E; case 0x060B6FA2u: goto L_060B6FA2; case 0x060B6FA4u: goto L_060B6FA4; case 0x060B6FA6u: goto L_060B6FA6; case 0x060B6FA8u: goto L_060B6FA8; case 0x060B6FAAu: goto L_060B6FAA; case 0x060B6FACu: goto L_060B6FAC; case 0x060B6FAEu: goto L_060B6FAE; case 0x060B6FB0u: goto L_060B6FB0; case 0x060B6FB2u: goto L_060B6FB2; case 0x060B6FB6u: goto L_060B6FB6; default: sh2_call(c, x); return; } }  // 060B6FB2 jmp @r0 ; add r10,r4
L_060B6FB6:
    c.r[7] += 4; SH2_POLL(c); goto L_060B6EBC;  // 060B6FB6 bra 0x060B6EBC ; add #4,r7
}

void f_060B6FBC(SH2Context& c) {
    ran[3133] = 1;
    goto L_060B6FBC;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6FBCu: goto L_060B6FBC; case 0x060B6FBEu: goto L_060B6FBE; case 0x060B6FC0u: goto L_060B6FC0; case 0x060B6FC2u: goto L_060B6FC2; case 0x060B6FC4u: goto L_060B6FC4; case 0x060B6FC6u: goto L_060B6FC6; case 0x060B6FC8u: goto L_060B6FC8; case 0x060B6FCAu: goto L_060B6FCA; case 0x060B6FCCu: goto L_060B6FCC; case 0x060B6FCEu: goto L_060B6FCE; case 0x060B6FD0u: goto L_060B6FD0; case 0x060B6FD2u: goto L_060B6FD2; case 0x060B6FD4u: goto L_060B6FD4; case 0x060B6FD6u: goto L_060B6FD6; case 0x060B6FD8u: goto L_060B6FD8; case 0x060B6FDAu: goto L_060B6FDA; case 0x060B6FDCu: goto L_060B6FDC; case 0x060B6FDEu: goto L_060B6FDE; case 0x060B6FE0u: goto L_060B6FE0; case 0x060B6FE2u: goto L_060B6FE2; case 0x060B6FE4u: goto L_060B6FE4; case 0x060B6FE6u: goto L_060B6FE6; case 0x060B6FE8u: goto L_060B6FE8; case 0x060B6FEAu: goto L_060B6FEA; case 0x060B6FECu: goto L_060B6FEC; case 0x060B6FEEu: goto L_060B6FEE; case 0x060B6FF2u: goto L_060B6FF2; case 0x060B6FF4u: goto L_060B6FF4; case 0x060B6FF6u: goto L_060B6FF6; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6FBCu: goto L_060B6FBC; case 0x060B6FBEu: goto L_060B6FBE; case 0x060B6FC0u: goto L_060B6FC0; case 0x060B6FC2u: goto L_060B6FC2; case 0x060B6FC4u: goto L_060B6FC4; case 0x060B6FC6u: goto L_060B6FC6; case 0x060B6FC8u: goto L_060B6FC8; case 0x060B6FCAu: goto L_060B6FCA; case 0x060B6FCCu: goto L_060B6FCC; case 0x060B6FCEu: goto L_060B6FCE; case 0x060B6FD0u: goto L_060B6FD0; case 0x060B6FD2u: goto L_060B6FD2; case 0x060B6FD4u: goto L_060B6FD4; case 0x060B6FD6u: goto L_060B6FD6; case 0x060B6FD8u: goto L_060B6FD8; case 0x060B6FDAu: goto L_060B6FDA; case 0x060B6FDCu: goto L_060B6FDC; case 0x060B6FDEu: goto L_060B6FDE; case 0x060B6FE0u: goto L_060B6FE0; case 0x060B6FE2u: goto L_060B6FE2; case 0x060B6FE4u: goto L_060B6FE4; case 0x060B6FE6u: goto L_060B6FE6; case 0x060B6FE8u: goto L_060B6FE8; case 0x060B6FEAu: goto L_060B6FEA; case 0x060B6FECu: goto L_060B6FEC; case 0x060B6FEEu: goto L_060B6FEE; case 0x060B6FF2u: goto L_060B6FF2; case 0x060B6FF4u: goto L_060B6FF4; case 0x060B6FF6u: goto L_060B6FF6; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B6FBC:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6FBC mov.w @r7+,r3
L_060B6FBE:
    c.r[2] <<= 2;  // 060B6FBE shll2 r2
L_060B6FC0:
    c.r[14] = ld32(c.r[1] + 12);  // 060B6FC0 mov.l @(12,r1),r14
L_060B6FC2:
    c.r[2] += c.r[10];  // 060B6FC2 add r10,r2
L_060B6FC4:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6FC4 mov.w @r7+,r4
L_060B6FC6:
    c.r[0] = ld32(c.r[2] + 12);  // 060B6FC6 mov.l @(12,r2),r0
L_060B6FC8:
    c.r[3] <<= 2;  // 060B6FC8 shll2 r3
L_060B6FCA:
    c.r[14] += c.r[0];  // 060B6FCA add r0,r14
L_060B6FCC:
    c.r[3] <<= 2;  // 060B6FCC shll2 r3
L_060B6FCE:
    c.r[3] += c.r[10];  // 060B6FCE add r10,r3
L_060B6FD0:
    c.r[4] <<= 2;  // 060B6FD0 shll2 r4
L_060B6FD2:
    c.r[0] = ld32(c.r[3] + 12);  // 060B6FD2 mov.l @(12,r3),r0
L_060B6FD4:
    c.r[4] <<= 2;  // 060B6FD4 shll2 r4
L_060B6FD6:
    c.r[14] += c.r[0];  // 060B6FD6 add r0,r14
L_060B6FD8:
    c.r[4] += c.r[10];  // 060B6FD8 add r10,r4
L_060B6FDA:
    c.r[0] = ld32(c.r[4] + 12);  // 060B6FDA mov.l @(12,r4),r0
L_060B6FDC:
    c.r[14] += c.r[0];  // 060B6FDC add r0,r14
L_060B6FDE:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B6FDE shar r14
L_060B6FE0:
    c.t = c.r[14] & 1; c.r[14] = (uint32_t)((int32_t)c.r[14] >> 1);  // 060B6FE0 shar r14
L_060B6FE2:
    c.r[5] = ld32(c.r[15] + 12);  // 060B6FE2 mov.l @(12,r15),r5
L_060B6FE4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B6FE4 mov.w @(160,gbr),r0
L_060B6FE6:
    c.r[5] <<= 16;  // 060B6FE6 shll16 r5
L_060B6FE8:
    c.r[0] <<= 16;  // 060B6FE8 shll16 r0
L_060B6FEA:
    c.r[0] += c.r[5];  // 060B6FEA add r5,r0
L_060B6FEC:
    c.t = c.r[14] > c.r[0];  // 060B6FEC cmp/hi r0,r14
L_060B6FEE:
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060B70BE; } }  // 060B6FEE bt/s 0x060B70BE ; shlr r5
L_060B6FF2:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[5];  // 060B6FF2 cmp/gt r5,r14
L_060B6FF4:
    if (!c.t) { goto L_060B70BE; }  // 060B6FF4 bf 0x060B70BE
L_060B6FF6:
    c.r[14] >>= 16; goto L_060B70C2;  // 060B6FF6 bra 0x060B70C2 ; shlr16 r14
L_060B70BC:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B70BC mov.l @r15+,r14
L_060B70BE:
    SH2_POLL(c); goto L_060B6EBC;  // 060B70BE bra 0x060B6EBC ; nop
L_060B70C2:
    c.r[0] = ld32(c.r[1] + 4);  // 060B70C2 mov.l @(4,r1),r0
L_060B70C4:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70C4 shar r0
L_060B70C6:
    { const bool k = !c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B70DA; } }  // 060B70C6 bf/s 0x060B70DA ; mov.l @(4,r2),r0
L_060B70CA:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70CA shar r0
L_060B70CC:
    { const bool k = !c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B70DA; } }  // 060B70CC bf/s 0x060B70DA ; mov.l @(4,r3),r0
L_060B70D0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70D0 shar r0
L_060B70D2:
    { const bool k = !c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B70DA; } }  // 060B70D2 bf/s 0x060B70DA ; mov.l @(4,r4),r0
L_060B70D6:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70D6 shar r0
L_060B70D8:
    if (c.t) { SH2_POLL(c); goto L_060B70BE; }  // 060B70D8 bt 0x060B70BE
L_060B70DA:
    c.r[0] = ld32(c.gbr + 892);  // 060B70DA mov.l @(892,gbr),r0
L_060B70DC:
    c.t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31;  // 060B70DC rotr r0
L_060B70DE:
    if (c.t) { goto L_060B7138; }  // 060B70DE bt 0x060B7138
L_060B70E0:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060B70E0 mov.l r14,@-r15
L_060B70E2:
    c.r[14] = (uint32_t)(int16_t)ld16(0x060B7140u);  // 060B70E2 mov.w 0x060B7140,r14
L_060B70E4:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B7142u);  // 060B70E4 mov.w 0x060B7142,r5
L_060B70E6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B70E6 mov.w @(0,r1),r0
L_060B70E8:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70E8 cmp/gt r5,r0
L_060B70EA:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70EA bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B70EE:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70EE bf/s 0x060B70BC ; mov.w @(2,r1),r0
L_060B70F2:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70F2 cmp/gt r5,r0
L_060B70F4:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70F4 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B70F8:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70F8 bf/s 0x060B70BC ; mov.w @(0,r2),r0
L_060B70FC:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70FC cmp/gt r5,r0
L_060B70FE:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70FE bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7102:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7102 bf/s 0x060B70BC ; mov.w @(2,r2),r0
L_060B7106:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7106 cmp/gt r5,r0
L_060B7108:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7108 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B710C:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B710C bf/s 0x060B70BC ; mov.w @(0,r3),r0
L_060B7110:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7110 cmp/gt r5,r0
L_060B7112:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7112 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7116:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7116 bf/s 0x060B70BC ; mov.w @(2,r3),r0
L_060B711A:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B711A cmp/gt r5,r0
L_060B711C:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B711C bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7120:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7120 bf/s 0x060B70BC ; mov.w @(0,r4),r0
L_060B7124:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7124 cmp/gt r5,r0
L_060B7126:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7126 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B712A:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B712A bf/s 0x060B70BC ; mov.w @(2,r4),r0
L_060B712E:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B712E cmp/gt r5,r0
L_060B7130:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7130 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7134:
    if (!c.t) { SH2_POLL(c); goto L_060B70BC; }  // 060B7134 bf 0x060B70BC
L_060B7136:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B7136 mov.l @r15+,r14
L_060B7138:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B7138 mov.l @r9+,r0
L_060B713A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B6FBCu: goto L_060B6FBC; case 0x060B6FBEu: goto L_060B6FBE; case 0x060B6FC0u: goto L_060B6FC0; case 0x060B6FC2u: goto L_060B6FC2; case 0x060B6FC4u: goto L_060B6FC4; case 0x060B6FC6u: goto L_060B6FC6; case 0x060B6FC8u: goto L_060B6FC8; case 0x060B6FCAu: goto L_060B6FCA; case 0x060B6FCCu: goto L_060B6FCC; case 0x060B6FCEu: goto L_060B6FCE; case 0x060B6FD0u: goto L_060B6FD0; case 0x060B6FD2u: goto L_060B6FD2; case 0x060B6FD4u: goto L_060B6FD4; case 0x060B6FD6u: goto L_060B6FD6; case 0x060B6FD8u: goto L_060B6FD8; case 0x060B6FDAu: goto L_060B6FDA; case 0x060B6FDCu: goto L_060B6FDC; case 0x060B6FDEu: goto L_060B6FDE; case 0x060B6FE0u: goto L_060B6FE0; case 0x060B6FE2u: goto L_060B6FE2; case 0x060B6FE4u: goto L_060B6FE4; case 0x060B6FE6u: goto L_060B6FE6; case 0x060B6FE8u: goto L_060B6FE8; case 0x060B6FEAu: goto L_060B6FEA; case 0x060B6FECu: goto L_060B6FEC; case 0x060B6FEEu: goto L_060B6FEE; case 0x060B6FF2u: goto L_060B6FF2; case 0x060B6FF4u: goto L_060B6FF4; case 0x060B6FF6u: goto L_060B6FF6; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B713A jmp @r0 ; nop
}

}  // namespace p_srwfin_installed
