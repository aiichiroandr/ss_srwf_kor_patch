#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_0609B594(SH2Context& c) {
    ran[2465] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B594 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B596 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B598 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B59A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B59C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B59E mov r15,r14
    c.r[10] = ld32(0x0609B610u);  // 0609B5A0 mov.l 0x0609B610,r10
    c.r[1] = ld32(c.r[10]);  // 0609B5A2 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609B60Cu);  // 0609B5A4 mov.w 0x0609B60C,r9
    c.r[0] = c.r[1];  // 0609B5A6 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[9]);  // 0609B5A8 mov.l @(r0,r9),r2
    c.r[0] = c.r[2];  // 0609B5AA mov r2,r0
    c.t = c.r[0] == 0x1u;  // 0609B5AC cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] = c.r[4]; if (k) { goto L_0609B5D4; } }  // 0609B5AE bf/s 0x0609B5D4 ; mov r4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B60Eu);  // 0609B5B2 mov.w 0x0609B60E,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B5B4 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B614u);  // 0609B5B6 mov.l 0x0609B614,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B5BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B5BCu) return; }  // 0609B5B8 jsr @r0 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609B5BC mov.l @r8,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B5BE tst r0,r0
    c.r[1] += 1;  // 0609B5C0 add #1,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_0609B5CE; } }  // 0609B5C2 bf/s 0x0609B5CE ; mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0609B5C6 mov.l @r10,r2
    c.r[1] = 0x2u;  // 0609B5C8 mov #2,r1
    c.r[0] = c.r[2];  // 0609B5CA mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609B5CC mov.l r1,@(r0,r9)
L_0609B5CE:
    c.r[1] = ld32(0x0609B618u);  // 0609B5CE mov.l 0x0609B618,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B5D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B5D4u) return; }  // 0609B5D0 jsr @r1 ; nop
L_0609B5D4:
    c.r[9] = ld32(0x0609B610u);  // 0609B5D4 mov.l 0x0609B610,r9
    c.r[1] = ld32(c.r[9]);  // 0609B5D6 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609B60Cu);  // 0609B5D8 mov.w 0x0609B60C,r8
    c.r[0] = c.r[1];  // 0609B5DA mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609B5DC mov.l @(r0,r8),r1
    c.r[0] = c.r[1];  // 0609B5DE mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0609B5E0 cmp/eq #2,r0
    if (!c.t) { goto L_0609B5F6; }  // 0609B5E2 bf 0x0609B5F6
    c.r[0] = ld32(0x0609B61Cu);  // 0609B5E4 mov.l 0x0609B61C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B5EAu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B5EAu) return; }  // 0609B5E6 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B5EA tst r0,r0
    if (c.t) { goto L_0609B5F6; }  // 0609B5EC bt 0x0609B5F6
    c.r[2] = ld32(c.r[9]);  // 0609B5EE mov.l @r9,r2
    c.r[1] = 0x0u;  // 0609B5F0 mov #0,r1
    c.r[0] = c.r[2];  // 0609B5F2 mov r2,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609B5F4 mov.l r1,@(r0,r8)
L_0609B5F6:
    c.r[15] = c.r[14];  // 0609B5F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B5F8 lds.l @r15+,pr
    c.r[1] = ld32(0x0609B610u);  // 0609B5FA mov.l 0x0609B610,r1
    c.r[1] = ld32(c.r[1]);  // 0609B5FC mov.l @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B5FE mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B60Cu);  // 0609B600 mov.w 0x0609B60C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609B602 mov.l @(r0,r1),r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B604 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B606 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B608 rts ; mov.l @r15+,r8
}

void f_0609B620(SH2Context& c) {
    ran[2466] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B620 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B622 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B624 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B626 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609B628 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B62A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B62C sts.l pr,@-r15
    c.r[15] -= 8;  // 0609B62E add #-8,r15
    c.r[14] = c.r[15];  // 0609B630 mov r15,r14
    c.r[9] = ld32(0x0609B75Cu);  // 0609B632 mov.l 0x0609B75C,r9
    c.r[1] = ld32(c.r[9]);  // 0609B634 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609B750u);  // 0609B636 mov.w 0x0609B750,r8
    c.r[0] = c.r[1];  // 0609B638 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[8]);  // 0609B63A mov.l @(r0,r8),r2
    c.r[0] = c.r[2];  // 0609B63C mov r2,r0
    c.t = c.r[0] == 0x1u;  // 0609B63E cmp/eq #1,r0
    { const bool k = !c.t; c.r[11] = c.r[4]; if (k) { goto L_0609B6A6; } }  // 0609B640 bf/s 0x0609B6A6 ; mov r4,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B752u);  // 0609B644 mov.w 0x0609B752,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B646 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B760u);  // 0609B648 mov.l 0x0609B760,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B64Eu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B64Eu) return; }  // 0609B64A jsr @r0 ; mov r14,r5
    c.r[1] = ld32(0x0609B764u);  // 0609B64E mov.l 0x0609B764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B654u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B654u) return; }  // 0609B650 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609B654 mov.l @r11,r1
    c.r[1] += 1;  // 0609B656 add #1,r1
    st32(c.r[11], c.r[1]);  // 0609B658 mov.l r1,@r11
    c.r[3] = ld32(c.r[9]);  // 0609B65A mov.l @r9,r3
    c.r[2] = ld32(c.r[14]);  // 0609B65C mov.l @r14,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B754u);  // 0609B65E mov.w 0x0609B754,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609B660 mov.l @(r0,r3),r1
    c.r[2] -= c.r[1];  // 0609B662 sub r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B756u);  // 0609B664 mov.w 0x0609B756,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609B666 mov.l @(r0,r3),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609B668 cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[14], c.r[2]); if (k) { goto L_0609B670; } }  // 0609B66A bf/s 0x0609B670 ; mov.l r2,@r14
    c.r[2] = c.r[1];  // 0609B66E mov r1,r2
L_0609B670:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B758u);  // 0609B670 mov.w 0x0609B758,r1
    c.r[0] = c.r[3];  // 0609B672 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609B674 mov.l @(r0,r1),r1
    st32(c.r[14], c.r[2]);  // 0609B676 mov.l r2,@r14
    st32(c.r[1], c.r[2]);  // 0609B678 mov.l r2,@r1
    c.r[3] = ld32(c.r[9]);  // 0609B67A mov.l @r9,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609B75Au);  // 0609B67C mov.w 0x0609B75A,r7
    c.r[0] = c.r[3];  // 0609B67E mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609B680 mov.l @(r0,r7),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B682 tst r1,r1
    if (!c.t) { goto L_0609B68C; }  // 0609B684 bf 0x0609B68C
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609B686 mov.l r1,@(r0,r8)
    c.r[0] = 0x0u; goto L_0609B73C;  // 0609B688 bra 0x0609B73C ; mov #0,r0
L_0609B68C:
    c.r[1] = ld32(c.r[14]);  // 0609B68C mov.l @r14,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609B68E cmp/pl r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0609B6A2; } }  // 0609B690 bt/s 0x0609B6A2 ; mov #2,r1
    c.r[2] = 0x0u;  // 0609B694 mov #0,r2
    c.r[0] = c.r[3];  // 0609B696 mov r3,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 0609B698 mov.l r2,@(r0,r8)
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609B69A mov.l @(r0,r7),r1
    st32(c.r[1], c.r[2]);  // 0609B69C mov.l r2,@r1
    c.r[0] = 0x0u; goto L_0609B73C;  // 0609B69E bra 0x0609B73C ; mov #0,r0
L_0609B6A2:
    c.r[0] = c.r[3];  // 0609B6A2 mov r3,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609B6A4 mov.l r1,@(r0,r8)
L_0609B6A6:
    c.r[12] = ld32(0x0609B75Cu);  // 0609B6A6 mov.l 0x0609B75C,r12
    c.r[2] = ld32(c.r[12]);  // 0609B6A8 mov.l @r12,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B750u);  // 0609B6AA mov.w 0x0609B750,r10
    c.r[0] = c.r[2];  // 0609B6AC mov r2,r0
    c.r[9] = ld32(c.r[0] + c.r[10]);  // 0609B6AE mov.l @(r0,r10),r9
    c.r[0] = c.r[9];  // 0609B6B0 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 0609B6B2 cmp/eq #2,r0
    if (!c.t) { goto L_0609B6F4; }  // 0609B6B4 bf 0x0609B6F4
    c.r[0] = ld32(c.r[2] + 52);  // 0609B6B6 mov.l @(52,r2),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609B6B8 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0609B6DC; } }  // 0609B6BA bf/s 0x0609B6DC ; mov r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609B752u);  // 0609B6BE mov.w 0x0609B752,r3
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609B6C0 mov.l @(r0,r3),r1
    st32(c.r[2] + 52, c.r[1]);  // 0609B6C2 mov.l r1,@(52,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B758u);  // 0609B6C4 mov.w 0x0609B758,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609B6C6 mov.l @(r0,r1),r1
    c.r[6] = ld32(c.r[1]);  // 0609B6C8 mov.l @r1,r6
    c.r[4] = ld32(c.r[0] + c.r[3]);  // 0609B6CA mov.l @(r0,r3),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B754u);  // 0609B6CC mov.w 0x0609B754,r1
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B6CE mov.l @(r0,r1),r5
    c.r[0] = ld32(0x0609B768u);  // 0609B6D0 mov.l 0x0609B768,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B6D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B6D6u) return; }  // 0609B6D2 jsr @r0 ; nop
    c.r[8] = c.r[0];  // 0609B6D6 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609B6D8 tst r8,r8
    if (c.t) { goto L_0609B6E0; }  // 0609B6DA bt 0x0609B6E0
L_0609B6DC:
    c.r[0] = c.r[9]; goto L_0609B73C;  // 0609B6DC bra 0x0609B73C ; mov r9,r0
L_0609B6E0:
    c.r[1] = ld32(0x0609B764u);  // 0609B6E0 mov.l 0x0609B764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B6E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B6E6u) return; }  // 0609B6E2 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609B6E6 mov.l @r11,r1
    c.r[1] += 1;  // 0609B6E8 add #1,r1
    st32(c.r[11], c.r[1]);  // 0609B6EA mov.l r1,@r11
    c.r[2] = ld32(c.r[12]);  // 0609B6EC mov.l @r12,r2
    c.r[1] = 0x3u;  // 0609B6EE mov #3,r1
    c.r[0] = c.r[2];  // 0609B6F0 mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0609B6F2 mov.l r1,@(r0,r10)
L_0609B6F4:
    c.r[10] = ld32(0x0609B75Cu);  // 0609B6F4 mov.l 0x0609B75C,r10
    c.r[1] = ld32(c.r[10]);  // 0609B6F6 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609B750u);  // 0609B6F8 mov.w 0x0609B750,r9
    c.r[0] = c.r[1];  // 0609B6FA mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609B6FC mov.l @(r0,r9),r1
    c.r[0] = c.r[1];  // 0609B6FE mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0609B700 cmp/eq #3,r0
    { const bool k = !c.t; c.r[4] = c.r[14]; if (k) { goto L_0609B73A; } }  // 0609B702 bf/s 0x0609B73A ; mov r14,r4
    c.r[0] = ld32(0x0609B76Cu);  // 0609B706 mov.l 0x0609B76C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B70Cu; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B70Cu) return; }  // 0609B708 jsr @r0 ; add #4,r4
    c.r[8] = c.r[0];  // 0609B70C mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609B70E tst r8,r8
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609B73C; } }  // 0609B710 bf/s 0x0609B73C ; mov #1,r0
    c.r[1] = ld32(0x0609B764u);  // 0609B714 mov.l 0x0609B764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B71Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B71Au) return; }  // 0609B716 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609B71A mov.l @r11,r1
    c.r[1] += 1;  // 0609B71C add #1,r1
    st32(c.r[11], c.r[1]);  // 0609B71E mov.l r1,@r11
    c.r[1] = ld32(c.r[10]);  // 0609B720 mov.l @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609B75Au);  // 0609B722 mov.w 0x0609B75A,r2
    c.r[0] = c.r[1];  // 0609B724 mov r1,r0
    st32(c.r[0] + c.r[9], c.r[8]);  // 0609B726 mov.l r8,@(r0,r9)
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0609B728 mov.l @(r0,r2),r2
    c.r[1] = ld32(c.r[14] + 4);  // 0609B72A mov.l @(4,r14),r1
    c.r[0] = 0x0u;  // 0609B72C mov #0,r0
    c.r[1] += c.r[1];  // 0609B72E add r1,r1
    st32(c.r[2], c.r[1]);  // 0609B730 mov.l r1,@r2
    c.r[2] = ld32(c.r[10]);  // 0609B732 mov.l @r10,r2
    c.r[1] = 0xFFFFFFFFu;  // 0609B734 mov #-1,r1
    st32(c.r[2] + 52, c.r[1]); goto L_0609B73C;  // 0609B736 bra 0x0609B73C ; mov.l r1,@(52,r2)
L_0609B73A:
    c.r[0] = 0x1u;  // 0609B73A mov #1,r0
L_0609B73C:
    c.r[14] += 8;  // 0609B73C add #8,r14
    c.r[15] = c.r[14];  // 0609B73E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B740 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B742 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609B744 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B746 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B748 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B74A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B74C rts ; mov.l @r15+,r8
}

void f_0609B770(SH2Context& c) {
    ran[2467] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B770 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B772 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B774 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B776 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B778 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B77A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B77C mov r15,r14
    c.r[11] = ld32(0x0609B800u);  // 0609B77E mov.l 0x0609B800,r11
    c.r[1] = ld32(c.r[11]);  // 0609B780 mov.l @r11,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B7F8u);  // 0609B782 mov.w 0x0609B7F8,r10
    c.r[0] = c.r[1];  // 0609B784 mov r1,r0
    c.r[8] = ld32(c.r[0] + c.r[10]);  // 0609B786 mov.l @(r0,r10),r8
    c.r[0] = c.r[8];  // 0609B788 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 0609B78A cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = c.r[4]; if (k) { goto L_0609B7BE; } }  // 0609B78C bf/s 0x0609B7BE ; mov r4,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B7FAu);  // 0609B790 mov.w 0x0609B7FA,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609B792 mov.l @(r0,r1),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B7FCu);  // 0609B794 mov.w 0x0609B7FC,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B796 mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B7FEu);  // 0609B798 mov.w 0x0609B7FE,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B79A mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B804u);  // 0609B79C mov.l 0x0609B804,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B7A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B7A2u) return; }  // 0609B79E jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0609B7A2 mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B7A4 tst r2,r2
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609B7E8; } }  // 0609B7A6 bf/s 0x0609B7E8 ; mov #1,r0
    c.r[1] = ld32(0x0609B808u);  // 0609B7AA mov.l 0x0609B808,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B7B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B7B0u) return; }  // 0609B7AC jsr @r1 ; nop
    c.r[1] = ld32(c.r[9]);  // 0609B7B0 mov.l @r9,r1
    c.r[1] += 1;  // 0609B7B2 add #1,r1
    st32(c.r[9], c.r[1]);  // 0609B7B4 mov.l r1,@r9
    c.r[2] = ld32(c.r[11]);  // 0609B7B6 mov.l @r11,r2
    c.r[1] = 0x2u;  // 0609B7B8 mov #2,r1
    c.r[0] = c.r[2];  // 0609B7BA mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0609B7BC mov.l r1,@(r0,r10)
L_0609B7BE:
    c.r[9] = ld32(0x0609B800u);  // 0609B7BE mov.l 0x0609B800,r9
    c.r[1] = ld32(c.r[9]);  // 0609B7C0 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609B7F8u);  // 0609B7C2 mov.w 0x0609B7F8,r8
    c.r[0] = c.r[1];  // 0609B7C4 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609B7C6 mov.l @(r0,r8),r1
    c.r[0] = c.r[1];  // 0609B7C8 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0609B7CA cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609B7E8; } }  // 0609B7CC bf/s 0x0609B7E8 ; mov #1,r0
    c.r[0] = ld32(0x0609B80Cu);  // 0609B7D0 mov.l 0x0609B80C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B7D6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B7D6u) return; }  // 0609B7D2 jsr @r0 ; mov #0,r4
    c.r[2] = c.r[0];  // 0609B7D6 mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B7D8 tst r2,r2
    if (!c.t) { goto L_0609B7E6; }  // 0609B7DA bf 0x0609B7E6
    c.r[1] = ld32(c.r[9]);  // 0609B7DC mov.l @r9,r1
    c.r[0] = c.r[1];  // 0609B7DE mov r1,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 0609B7E0 mov.l r2,@(r0,r8)
    c.r[0] = 0x0u; goto L_0609B7E8;  // 0609B7E2 bra 0x0609B7E8 ; mov #0,r0
L_0609B7E6:
    c.r[0] = 0x1u;  // 0609B7E6 mov #1,r0
L_0609B7E8:
    c.r[15] = c.r[14];  // 0609B7E8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B7EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7EC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B7F4 rts ; mov.l @r15+,r8
}

void f_0609B810(SH2Context& c) {
    ran[2468] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B810 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B812 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B814 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B816 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B818 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B81A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B81C mov r15,r14
    c.r[8] = c.r[4];  // 0609B81E mov r4,r8
    c.r[11] = ld32(0x0609B928u);  // 0609B820 mov.l 0x0609B928,r11
    c.r[2] = ld32(c.r[11]);  // 0609B822 mov.l @r11,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B824 mov.w 0x0609B91C,r10
    c.r[0] = c.r[2];  // 0609B826 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0609B828 mov.l @(r0,r10),r1
    c.r[0] = c.r[1];  // 0609B82A mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609B82C cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = 0x1u; if (k) { goto L_0609B884; } }  // 0609B82E bf/s 0x0609B884 ; mov #1,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Eu);  // 0609B832 mov.w 0x0609B91E,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609B834 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B836 tst r1,r1
    if (!c.t) { goto L_0609B86A; }  // 0609B838 bf 0x0609B86A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B920u);  // 0609B83A mov.w 0x0609B920,r0
    c.r[0] = ld32(c.r[0] + c.r[2]);  // 0609B83C mov.l @(r0,r2),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609B83E cmp/eq #-1,r0
    if (!c.t) { goto L_0609B86A; }  // 0609B840 bf 0x0609B86A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B922u);  // 0609B842 mov.w 0x0609B922,r0
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0609B844 mov.l @(r0,r2),r5
    c.r[0] = ld32(0x0609B92Cu);  // 0609B846 mov.l 0x0609B92C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B84Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B84Cu) return; }  // 0609B848 jsr @r0 ; mov #0,r4
    c.r[2] = c.r[0];  // 0609B84C mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B84E tst r2,r2
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0609B90C; } }  // 0609B850 bf/s 0x0609B90C ; mov r9,r0
    c.r[1] = ld32(0x0609B930u);  // 0609B854 mov.l 0x0609B930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B85Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B85Au) return; }  // 0609B856 jsr @r1 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609B85A mov.l @r8,r1
    c.r[1] += 1;  // 0609B85C add #1,r1
    st32(c.r[8], c.r[1]);  // 0609B85E mov.l r1,@r8
    c.r[2] = ld32(c.r[11]);  // 0609B860 mov.l @r11,r2
    c.r[1] = 0x4u;  // 0609B862 mov #4,r1
    c.r[0] = c.r[2];  // 0609B864 mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]); goto L_0609B882;  // 0609B866 bra 0x0609B882 ; mov.l r1,@(r0,r10)
L_0609B86A:
    c.r[1] = ld32(0x0609B928u);  // 0609B86A mov.l 0x0609B928,r1
    c.r[2] = ld32(c.r[1]);  // 0609B86C mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B920u);  // 0609B86E mov.w 0x0609B920,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609B870 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B872 tst r1,r1
    if (!c.t) { goto L_0609B87C; }  // 0609B874 bf 0x0609B87C
    c.r[9] = 0x0u;  // 0609B876 mov #0,r9
    goto L_0609B882;  // 0609B878 bra 0x0609B882 ; nop
L_0609B87C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B87C mov.w 0x0609B91C,r0
    c.r[1] = 0x2u;  // 0609B87E mov #2,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609B880 mov.l r1,@(r0,r2)
L_0609B882:
    c.r[11] = ld32(0x0609B928u);  // 0609B882 mov.l 0x0609B928,r11
L_0609B884:
    c.r[1] = ld32(c.r[11]);  // 0609B884 mov.l @r11,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B886 mov.w 0x0609B91C,r10
    c.r[0] = c.r[1];  // 0609B888 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[10]);  // 0609B88A mov.l @(r0,r10),r2
    c.r[0] = c.r[2];  // 0609B88C mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0609B88E cmp/eq #2,r0
    if (!c.t) { goto L_0609B8BC; }  // 0609B890 bf 0x0609B8BC
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B920u);  // 0609B892 mov.w 0x0609B920,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609B894 mov.l @(r0,r1),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Eu);  // 0609B896 mov.w 0x0609B91E,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B898 mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B922u);  // 0609B89A mov.w 0x0609B922,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B89C mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B934u);  // 0609B89E mov.l 0x0609B934,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B8A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8A4u) return; }  // 0609B8A0 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0609B8A4 mov r0,r2
    c.r[1] = ld32(c.r[8]);  // 0609B8A6 mov.l @r8,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B8A8 tst r2,r2
    c.r[1] += 1;  // 0609B8AA add #1,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_0609B8BC; } }  // 0609B8AC bf/s 0x0609B8BC ; mov.l r1,@r8
    c.r[1] = ld32(c.r[11]);  // 0609B8B0 mov.l @r11,r1
    c.r[2] = 0x3u;  // 0609B8B2 mov #3,r2
    c.r[0] = c.r[1];  // 0609B8B4 mov r1,r0
    c.r[1] = ld32(0x0609B930u);  // 0609B8B6 mov.l 0x0609B930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B8BCu; st32(c.r[0] + c.r[10], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8BCu) return; }  // 0609B8B8 jsr @r1 ; mov.l r2,@(r0,r10)
L_0609B8BC:
    c.r[1] = ld32(0x0609B928u);  // 0609B8BC mov.l 0x0609B928,r1
    c.r[1] = ld32(c.r[1]);  // 0609B8BE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B8C0 mov.w 0x0609B91C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609B8C2 mov.l @(r0,r1),r0
    c.t = c.r[0] == 0x3u;  // 0609B8C4 cmp/eq #3,r0
    if (!c.t) { goto L_0609B8D6; }  // 0609B8C6 bf 0x0609B8D6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609B924u);  // 0609B8C8 mov.w 0x0609B924,r4
    c.r[0] = ld32(0x0609B938u);  // 0609B8CA mov.l 0x0609B938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B8D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8D0u) return; }  // 0609B8CC jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B8D0 tst r0,r0
    if (c.t) { goto L_0609B8D6; }  // 0609B8D2 bt 0x0609B8D6
    c.r[9] = 0x0u;  // 0609B8D4 mov #0,r9
L_0609B8D6:
    c.r[1] = ld32(0x0609B928u);  // 0609B8D6 mov.l 0x0609B928,r1
    c.r[1] = ld32(c.r[1]);  // 0609B8D8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B8DA mov.w 0x0609B91C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609B8DC mov.l @(r0,r1),r0
    c.t = c.r[0] == 0x4u;  // 0609B8DE cmp/eq #4,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0609B8F2; } }  // 0609B8E0 bf/s 0x0609B8F2 ; mov r9,r0
    c.r[0] = ld32(0x0609B938u);  // 0609B8E4 mov.l 0x0609B938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B8EAu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8EAu) return; }  // 0609B8E6 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B8EA tst r0,r0
    if (c.t) { goto L_0609B8F0; }  // 0609B8EC bt 0x0609B8F0
    c.r[9] = 0x0u;  // 0609B8EE mov #0,r9
L_0609B8F0:
    c.r[0] = c.r[9];  // 0609B8F0 mov r9,r0
L_0609B8F2:
    c.t = c.r[0] == 0x1u;  // 0609B8F2 cmp/eq #1,r0
    if (c.t) { goto L_0609B90A; }  // 0609B8F4 bt 0x0609B90A
    c.r[1] = ld32(0x0609B93Cu);  // 0609B8F6 mov.l 0x0609B93C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B8FCu; c.r[4] = 0xFFFFFFF7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8FCu) return; }  // 0609B8F8 jsr @r1 ; mov #-9,r4
    c.r[1] = ld32(0x0609B928u);  // 0609B8FC mov.l 0x0609B928,r1
    c.r[2] = ld32(c.r[1]);  // 0609B8FE mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B900 mov.w 0x0609B91C,r0
    c.r[1] = 0x0u;  // 0609B902 mov #0,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609B904 mov.l r1,@(r0,r2)
    c.r[0] = 0x0u; goto L_0609B90C;  // 0609B906 bra 0x0609B90C ; mov #0,r0
L_0609B90A:
    c.r[0] = c.r[9];  // 0609B90A mov r9,r0
L_0609B90C:
    c.r[15] = c.r[14];  // 0609B90C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B90E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B910 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B912 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B914 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B916 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B918 rts ; mov.l @r15+,r8
}

void f_0609B940(SH2Context& c) {
    ran[2469] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B940 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B942 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B944 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B946 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609B948 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609B94A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B94C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B94E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B950 mov r15,r14
    c.r[11] = ld32(0x0609BA8Cu);  // 0609B952 mov.l 0x0609BA8C,r11
    c.r[1] = ld32(c.r[11]);  // 0609B954 mov.l @r11,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609BA7Cu);  // 0609B956 mov.w 0x0609BA7C,r13
    c.r[0] = c.r[1];  // 0609B958 mov r1,r0
    c.r[12] = ld32(c.r[0] + c.r[13]);  // 0609B95A mov.l @(r0,r13),r12
    c.r[0] = c.r[12];  // 0609B95C mov r12,r0
    c.t = c.r[0] == 0x1u;  // 0609B95E cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] = c.r[4]; if (k) { goto L_0609B9A2; } }  // 0609B960 bf/s 0x0609B9A2 ; mov r4,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609BA7Eu);  // 0609B964 mov.w 0x0609BA7E,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609BA80u);  // 0609B966 mov.w 0x0609BA80,r9
    c.r[0] = c.r[1];  // 0609B968 mov r1,r0
    c.r[4] = ld32(c.r[0] + c.r[9]);  // 0609B96A mov.l @(r0,r9),r4
    c.r[0] = ld32(0x0609BA90u);  // 0609B96C mov.l 0x0609BA90,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B972u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B972u) return; }  // 0609B96E jsr @r0 ; add r1,r5
    c.r[1] = ld32(c.r[8]);  // 0609B972 mov.l @r8,r1
    c.r[10] = ld32(0x0609BA94u);  // 0609B974 mov.l 0x0609BA94,r10
    c.r[1] += 1;  // 0609B976 add #1,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0609B97Cu; st32(c.r[8], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B97Cu) return; }  // 0609B978 jsr @r10 ; mov.l r1,@r8
    c.r[1] = ld32(c.r[11]);  // 0609B97C mov.l @r11,r1
    c.r[0] = c.r[1];  // 0609B97E mov r1,r0
    c.r[4] = ld32(c.r[0] + c.r[9]);  // 0609B980 mov.l @(r0,r9),r4
    c.r[0] = ld32(0x0609BA98u);  // 0609B982 mov.l 0x0609BA98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B988u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B988u) return; }  // 0609B984 jsr @r0 ; mov #0,r5
    c.r[1] = c.r[0];  // 0609B988 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B98A tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609BA68; } }  // 0609B98C bf/s 0x0609BA68 ; mov #1,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0609B994u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B994u) return; }  // 0609B990 jsr @r10 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609B994 mov.l @r8,r1
    c.r[1] += 1;  // 0609B996 add #1,r1
    st32(c.r[8], c.r[1]);  // 0609B998 mov.l r1,@r8
    c.r[2] = ld32(c.r[11]);  // 0609B99A mov.l @r11,r2
    c.r[1] = 0x2u;  // 0609B99C mov #2,r1
    c.r[0] = c.r[2];  // 0609B99E mov r2,r0
    st32(c.r[0] + c.r[13], c.r[1]);  // 0609B9A0 mov.l r1,@(r0,r13)
L_0609B9A2:
    c.r[10] = ld32(0x0609BA8Cu);  // 0609B9A2 mov.l 0x0609BA8C,r10
    c.r[1] = ld32(c.r[10]);  // 0609B9A4 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609BA7Cu);  // 0609B9A6 mov.w 0x0609BA7C,r9
    c.r[0] = c.r[1];  // 0609B9A8 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[9]);  // 0609B9AA mov.l @(r0,r9),r2
    c.r[0] = c.r[2];  // 0609B9AC mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0609B9AE cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0609B9EE; } }  // 0609B9B0 bf/s 0x0609B9EE ; mov r1,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA80u);  // 0609B9B4 mov.w 0x0609BA80,r0
    c.r[7] = ld32(c.r[0] + c.r[1]);  // 0609B9B6 mov.l @(r0,r1),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA82u);  // 0609B9B8 mov.w 0x0609BA82,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609B9BA mov.l @(r0,r1),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA84u);  // 0609B9BC mov.w 0x0609BA84,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B9BE mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA86u);  // 0609B9C0 mov.w 0x0609BA86,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B9C2 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609BA9Cu);  // 0609B9C4 mov.l 0x0609BA9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B9CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B9CAu) return; }  // 0609B9C6 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0609B9CA mov r0,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B9CC tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609BA68; } }  // 0609B9CE bf/s 0x0609BA68 ; mov #1,r0
    c.r[1] = ld32(0x0609BA94u);  // 0609B9D2 mov.l 0x0609BA94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B9D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B9D8u) return; }  // 0609B9D4 jsr @r1 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609B9D8 mov.l @r8,r1
    c.r[1] += 1;  // 0609B9DA add #1,r1
    st32(c.r[8], c.r[1]);  // 0609B9DC mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0609B9DE mov.l @r10,r2
    c.r[1] = 0x3u;  // 0609B9E0 mov #3,r1
    c.r[0] = c.r[2];  // 0609B9E2 mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609B9E4 mov.l r1,@(r0,r9)
    c.r[10] = ld32(0x0609BA8Cu);  // 0609B9E6 mov.l 0x0609BA8C,r10
    c.r[1] = ld32(c.r[10]);  // 0609B9E8 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609BA7Cu);  // 0609B9EA mov.w 0x0609BA7C,r9
    c.r[0] = c.r[1];  // 0609B9EC mov r1,r0
L_0609B9EE:
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609B9EE mov.l @(r0,r9),r1
    c.r[0] = c.r[1];  // 0609B9F0 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0609B9F2 cmp/eq #3,r0
    if (!c.t) { goto L_0609BA0A; }  // 0609B9F4 bf 0x0609BA0A
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609BA88u);  // 0609B9F6 mov.w 0x0609BA88,r4
    c.r[0] = ld32(0x0609BAA0u);  // 0609B9F8 mov.l 0x0609BAA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B9FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B9FEu) return; }  // 0609B9FA jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B9FE tst r0,r0
    if (c.t) { goto L_0609BA0A; }  // 0609BA00 bt 0x0609BA0A
    c.r[2] = ld32(c.r[10]);  // 0609BA02 mov.l @r10,r2
    c.r[1] = 0x4u;  // 0609BA04 mov #4,r1
    c.r[0] = c.r[2];  // 0609BA06 mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609BA08 mov.l r1,@(r0,r9)
L_0609BA0A:
    c.r[10] = ld32(0x0609BA8Cu);  // 0609BA0A mov.l 0x0609BA8C,r10
    c.r[1] = ld32(c.r[10]);  // 0609BA0C mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609BA7Cu);  // 0609BA0E mov.w 0x0609BA7C,r9
    c.r[0] = c.r[1];  // 0609BA10 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[9]);  // 0609BA12 mov.l @(r0,r9),r2
    c.r[0] = c.r[2];  // 0609BA14 mov r2,r0
    c.t = c.r[0] == 0x4u;  // 0609BA16 cmp/eq #4,r0
    if (!c.t) { goto L_0609BA3E; }  // 0609BA18 bf 0x0609BA3E
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA7Eu);  // 0609BA1A mov.w 0x0609BA7E,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609BA1C mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA80u);  // 0609BA1E mov.w 0x0609BA80,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609BA20 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609BA98u);  // 0609BA22 mov.l 0x0609BA98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BA28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BA28u) return; }  // 0609BA24 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0609BA28 mov r0,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BA2A tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609BA68; } }  // 0609BA2C bf/s 0x0609BA68 ; mov #1,r0
    c.r[1] = ld32(c.r[8]);  // 0609BA30 mov.l @r8,r1
    c.r[1] += 1;  // 0609BA32 add #1,r1
    st32(c.r[8], c.r[1]);  // 0609BA34 mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0609BA36 mov.l @r10,r2
    c.r[1] = 0x5u;  // 0609BA38 mov #5,r1
    c.r[0] = c.r[2];  // 0609BA3A mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609BA3C mov.l r1,@(r0,r9)
L_0609BA3E:
    c.r[9] = ld32(0x0609BA8Cu);  // 0609BA3E mov.l 0x0609BA8C,r9
    c.r[1] = ld32(c.r[9]);  // 0609BA40 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609BA7Cu);  // 0609BA42 mov.w 0x0609BA7C,r8
    c.r[0] = c.r[1];  // 0609BA44 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609BA46 mov.l @(r0,r8),r1
    c.r[0] = c.r[1];  // 0609BA48 mov r1,r0
    c.t = c.r[0] == 0x5u;  // 0609BA4A cmp/eq #5,r0
    if (!c.t) { goto L_0609BA60; }  // 0609BA4C bf 0x0609BA60
    c.r[0] = ld32(0x0609BAA0u);  // 0609BA4E mov.l 0x0609BAA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BA54u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BA54u) return; }  // 0609BA50 jsr @r0 ; mov #64,r4
    c.t = c.r[0] == 0x1u;  // 0609BA54 cmp/eq #1,r0
    if (!c.t) { goto L_0609BA60; }  // 0609BA56 bf 0x0609BA60
    c.r[2] = ld32(c.r[9]);  // 0609BA58 mov.l @r9,r2
    c.r[1] = 0x0u;  // 0609BA5A mov #0,r1
    c.r[0] = c.r[2];  // 0609BA5C mov r2,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609BA5E mov.l r1,@(r0,r8)
L_0609BA60:
    c.r[1] = ld32(0x0609BA8Cu);  // 0609BA60 mov.l 0x0609BA8C,r1
    c.r[1] = ld32(c.r[1]);  // 0609BA62 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BA7Cu);  // 0609BA64 mov.w 0x0609BA7C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609BA66 mov.l @(r0,r1),r0
L_0609BA68:
    c.r[15] = c.r[14];  // 0609BA68 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BA6A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BA6C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609BA6E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609BA70 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609BA72 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609BA74 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609BA76 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BA78 rts ; mov.l @r15+,r8
}

void f_0609BAA4(SH2Context& c) {
    ran[2470] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BAA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609BAA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609BAA8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609BAAA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BAAC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BAAE sts.l pr,@-r15
    c.r[15] -= 24;  // 0609BAB0 add #-24,r15
    c.r[14] = c.r[15];  // 0609BAB2 mov r15,r14
    c.r[9] = ld32(0x0609BBA4u);  // 0609BAB4 mov.l 0x0609BBA4,r9
    c.r[1] = ld32(c.r[9]);  // 0609BAB6 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609BB9Au);  // 0609BAB8 mov.w 0x0609BB9A,r8
    c.r[0] = c.r[1];  // 0609BABA mov r1,r0
    c.r[10] = ld32(c.r[0] + c.r[8]);  // 0609BABC mov.l @(r0,r8),r10
    c.r[0] = c.r[10];  // 0609BABE mov r10,r0
    c.t = c.r[0] == 0x1u;  // 0609BAC0 cmp/eq #1,r0
    { const bool k = !c.t; c.r[11] = c.r[4]; if (k) { goto L_0609BB46; } }  // 0609BAC2 bf/s 0x0609BB46 ; mov r4,r11
    c.r[6] = c.r[14];  // 0609BAC6 mov r14,r6
    c.r[6] += 20;  // 0609BAC8 add #20,r6
    c.r[5] = c.r[14];  // 0609BACA mov r14,r5
    c.r[5] += 16;  // 0609BACC add #16,r5
    c.r[4] = c.r[14];  // 0609BACE mov r14,r4
    c.r[0] = ld32(0x0609BBA8u);  // 0609BAD0 mov.l 0x0609BBA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BAD6u; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BAD6u) return; }  // 0609BAD2 jsr @r0 ; add #12,r4
    c.r[1] = c.r[0];  // 0609BAD6 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BAD8 tst r1,r1
    if (c.t) { goto L_0609BAEA; }  // 0609BADA bt 0x0609BAEA
    c.r[2] = ld32(c.r[9]);  // 0609BADC mov.l @r9,r2
    c.r[1] = 0x0u;  // 0609BADE mov #0,r1
    c.r[0] = c.r[2];  // 0609BAE0 mov r2,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609BAE2 mov.l r1,@(r0,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609BB9Cu);  // 0609BAE4 mov.w 0x0609BB9C,r1
    c.r[2] = ld32(c.r[0] + c.r[1]); goto L_0609BC4E;  // 0609BAE6 bra 0x0609BC4E ; mov.l @(r0,r1),r2
L_0609BAEA:
    c.r[1] = ld32(c.r[11]);  // 0609BAEA mov.l @r11,r1
    c.r[1] += 1;  // 0609BAEC add #1,r1
    st32(c.r[11], c.r[1]);  // 0609BAEE mov.l r1,@r11
    c.r[2] = ld32(c.r[9]);  // 0609BAF0 mov.l @r9,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609BB9Eu);  // 0609BAF2 mov.w 0x0609BB9E,r3
    c.r[0] = c.r[2];  // 0609BAF4 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0609BAF6 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609BAF8 extu.w r1,r1
    c.t = c.r[1] > c.r[10];  // 0609BAFA cmp/hi r10,r1
    if (!c.t) { goto L_0609BB0E; }  // 0609BAFC bf 0x0609BB0E
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0609BAFE mov.w @(r0,r3),r7
    c.r[3] = ld32(c.r[14] + 12);  // 0609BB00 mov.l @(12,r14),r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 0609BB02 cmp/gt r7,r3
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 16); if (k) { goto L_0609BB16; } }  // 0609BB04 bt/s 0x0609BB16 ; mov.l @(16,r14),r1
    c.r[3] += c.r[1];  // 0609BB08 add r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 0609BB0A cmp/ge r3,r7
    if (c.t) { goto L_0609BB16; }  // 0609BB0C bt 0x0609BB16
L_0609BB0E:
    c.r[1] = 0x3u;  // 0609BB0E mov #3,r1
    c.r[0] = c.r[2];  // 0609BB10 mov r2,r0
    st32(c.r[0] + c.r[8], c.r[1]); goto L_0609BB46;  // 0609BB12 bra 0x0609BB46 ; mov.l r1,@(r0,r8)
L_0609BB16:
    c.r[8] = ld32(0x0609BBA4u);  // 0609BB16 mov.l 0x0609BBA4,r8
    c.r[1] = ld32(c.r[8]);  // 0609BB18 mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BB9Eu);  // 0609BB1A mov.w 0x0609BB9E,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609BB1C mov.w @(r0,r1),r5
    c.r[0] = ld32(0x0609BBACu);  // 0609BB1E mov.l 0x0609BBAC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BB24u; c.r[4] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BB24u) return; }  // 0609BB20 jsr @r0 ; mov #23,r4
    c.r[1] = c.r[0];  // 0609BB24 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BB26 tst r1,r1
    if (c.t) { goto L_0609BB38; }  // 0609BB28 bt 0x0609BB38
    c.r[2] = ld32(c.r[8]);  // 0609BB2A mov.l @r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BB9Au);  // 0609BB2C mov.w 0x0609BB9A,r0
    c.r[1] = 0x0u;  // 0609BB2E mov #0,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609BB30 mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BB9Cu);  // 0609BB32 mov.w 0x0609BB9C,r0
    c.r[2] = ld32(c.r[0] + c.r[2]); goto L_0609BC4E;  // 0609BB34 bra 0x0609BC4E ; mov.l @(r0,r2),r2
L_0609BB38:
    c.r[1] = ld32(c.r[11]);  // 0609BB38 mov.l @r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BB9Au);  // 0609BB3A mov.w 0x0609BB9A,r0
    c.r[1] += 1;  // 0609BB3C add #1,r1
    st32(c.r[11], c.r[1]);  // 0609BB3E mov.l r1,@r11
    c.r[2] = ld32(c.r[8]);  // 0609BB40 mov.l @r8,r2
    c.r[1] = 0x2u;  // 0609BB42 mov #2,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609BB44 mov.l r1,@(r0,r2)
L_0609BB46:
    c.r[8] = ld32(0x0609BBA4u);  // 0609BB46 mov.l 0x0609BBA4,r8
    c.r[1] = ld32(c.r[8]);  // 0609BB48 mov.l @r8,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609BB9Au);  // 0609BB4A mov.w 0x0609BB9A,r9
    c.r[0] = c.r[1];  // 0609BB4C mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609BB4E mov.l @(r0,r9),r1
    c.r[0] = c.r[1];  // 0609BB50 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0609BB52 cmp/eq #2,r0
    if (!c.t) { goto L_0609BBBE; }  // 0609BB54 bf 0x0609BBBE
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609BBA0u);  // 0609BB56 mov.w 0x0609BBA0,r4
    c.r[0] = ld32(0x0609BBB0u);  // 0609BB58 mov.l 0x0609BBB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BB5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BB5Eu) return; }  // 0609BB5A jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BB5E tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[14]; if (k) { goto L_0609BBBE; } }  // 0609BB60 bt/s 0x0609BBBE ; mov r14,r6
    c.r[6] += 20;  // 0609BB64 add #20,r6
    c.r[5] = c.r[14];  // 0609BB66 mov r14,r5
    c.r[5] += 16;  // 0609BB68 add #16,r5
    c.r[4] = c.r[14];  // 0609BB6A mov r14,r4
    c.r[0] = ld32(0x0609BBA8u);  // 0609BB6C mov.l 0x0609BBA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BB72u; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BB72u) return; }  // 0609BB6E jsr @r0 ; add #12,r4
    c.r[1] = c.r[0];  // 0609BB72 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BB74 tst r1,r1
    if (!c.t) { goto L_0609BB8C; }  // 0609BB76 bf 0x0609BB8C
    c.r[1] = ld32(c.r[8]);  // 0609BB78 mov.l @r8,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0609BB7A mov.l @(12,r14),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BB9Eu);  // 0609BB7C mov.w 0x0609BB9E,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609BB7E mov.w @(r0,r1),r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[2];  // 0609BB80 cmp/ge r2,r3
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 16); if (k) { goto L_0609BBB4; } }  // 0609BB82 bt/s 0x0609BBB4 ; mov.l @(16,r14),r1
    c.r[2] += c.r[1];  // 0609BB86 add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0609BB88 cmp/gt r3,r2
    if (c.t) { goto L_0609BBB4; }  // 0609BB8A bt 0x0609BBB4
L_0609BB8C:
    c.r[2] = ld32(c.r[8]);  // 0609BB8C mov.l @r8,r2
    c.r[1] = 0x0u;  // 0609BB8E mov #0,r1
    c.r[0] = c.r[2];  // 0609BB90 mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609BB92 mov.l r1,@(r0,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609BB9Cu);  // 0609BB94 mov.w 0x0609BB9C,r1
    c.r[2] = ld32(c.r[0] + c.r[1]); goto L_0609BC4E;  // 0609BB96 bra 0x0609BC4E ; mov.l @(r0,r1),r2
L_0609BBB4:
    c.r[1] = ld32(0x0609BC84u);  // 0609BBB4 mov.l 0x0609BC84,r1
    c.r[2] = ld32(c.r[1]);  // 0609BBB6 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BC78u);  // 0609BBB8 mov.w 0x0609BC78,r0
    c.r[1] = 0x3u;  // 0609BBBA mov #3,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609BBBC mov.l r1,@(r0,r2)
L_0609BBBE:
    c.r[8] = ld32(0x0609BC84u);  // 0609BBBE mov.l 0x0609BC84,r8
    c.r[1] = ld32(c.r[8]);  // 0609BBC0 mov.l @r8,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609BC78u);  // 0609BBC2 mov.w 0x0609BC78,r9
    c.r[0] = c.r[1];  // 0609BBC4 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609BBC6 mov.l @(r0,r9),r1
    c.r[0] = c.r[1];  // 0609BBC8 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0609BBCA cmp/eq #3,r0
    if (!c.t) { goto L_0609BC0A; }  // 0609BBCC bf 0x0609BC0A
    c.r[0] = ld32(0x0609BC88u);  // 0609BBCE mov.l 0x0609BC88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BBD4u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BBD4u) return; }  // 0609BBD0 jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x0609BC8Cu);  // 0609BBD4 mov.l 0x0609BC8C,r1
    c.r[1] = ld32(c.r[1]);  // 0609BBD6 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BBD8 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0609BC66; } }  // 0609BBDA bf/s 0x0609BC66 ; mov r1,r0
    c.r[1] = ld32(c.r[8]);  // 0609BBDE mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BC7Au);  // 0609BBE0 mov.w 0x0609BC7A,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609BBE2 mov.w @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BC7Cu);  // 0609BBE4 mov.w 0x0609BC7C,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609BBE6 mov.w @(r0,r1),r4
    c.r[0] = ld32(0x0609BC90u);  // 0609BBE8 mov.l 0x0609BC90,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BBEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BBEEu) return; }  // 0609BBEA jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0609BBEE mov r0,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BBF0 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609BC66; } }  // 0609BBF2 bf/s 0x0609BC66 ; mov #1,r0
    c.r[1] = ld32(0x0609BC94u);  // 0609BBF6 mov.l 0x0609BC94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609BBFCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BBFCu) return; }  // 0609BBF8 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609BBFC mov.l @r11,r1
    c.r[1] += 1;  // 0609BBFE add #1,r1
    st32(c.r[11], c.r[1]);  // 0609BC00 mov.l r1,@r11
    c.r[2] = ld32(c.r[8]);  // 0609BC02 mov.l @r8,r2
    c.r[1] = 0x4u;  // 0609BC04 mov #4,r1
    c.r[0] = c.r[2];  // 0609BC06 mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609BC08 mov.l r1,@(r0,r9)
L_0609BC0A:
    c.r[9] = ld32(0x0609BC84u);  // 0609BC0A mov.l 0x0609BC84,r9
    c.r[1] = ld32(c.r[9]);  // 0609BC0C mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609BC78u);  // 0609BC0E mov.w 0x0609BC78,r8
    c.r[0] = c.r[1];  // 0609BC10 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609BC12 mov.l @(r0,r8),r1
    c.r[0] = c.r[1];  // 0609BC14 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 0609BC16 cmp/eq #4,r0
    if (!c.t) { goto L_0609BC5E; }  // 0609BC18 bf 0x0609BC5E
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609BC7Eu);  // 0609BC1A mov.w 0x0609BC7E,r4
    c.r[0] = ld32(0x0609BC98u);  // 0609BC1C mov.l 0x0609BC98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BC22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BC22u) return; }  // 0609BC1E jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BC22 tst r0,r0
    if (c.t) { goto L_0609BC5E; }  // 0609BC24 bt 0x0609BC5E
    c.r[1] = ld32(c.r[9]);  // 0609BC26 mov.l @r9,r1
    c.r[10] = 0x0u;  // 0609BC28 mov #0,r10
    c.r[6] = c.r[14];  // 0609BC2A mov r14,r6
    c.r[6] += 20;  // 0609BC2C add #20,r6
    c.r[5] = c.r[14];  // 0609BC2E mov r14,r5
    c.r[5] += 16;  // 0609BC30 add #16,r5
    c.r[4] = c.r[14];  // 0609BC32 mov r14,r4
    c.r[0] = c.r[1];  // 0609BC34 mov r1,r0
    st32(c.r[0] + c.r[8], c.r[10]);  // 0609BC36 mov.l r10,@(r0,r8)
    c.r[0] = ld32(0x0609BC9Cu);  // 0609BC38 mov.l 0x0609BC9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BC3Eu; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BC3Eu) return; }  // 0609BC3A jsr @r0 ; add #12,r4
    c.r[1] = c.r[0];  // 0609BC3E mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BC40 tst r1,r1
    { const bool k = c.t; c.r[1] = ld32(c.r[9]); if (k) { goto L_0609BC56; } }  // 0609BC42 bt/s 0x0609BC56 ; mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609BC80u);  // 0609BC46 mov.w 0x0609BC80,r2
    c.r[0] = c.r[1];  // 0609BC48 mov r1,r0
    st32(c.r[0] + c.r[8], c.r[10]);  // 0609BC4A mov.l r10,@(r0,r8)
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0609BC4C mov.l @(r0,r2),r2
L_0609BC4E:
    c.r[1] = 0xFFFFFFFFu;  // 0609BC4E mov #-1,r1
    st32(c.r[2], c.r[1]);  // 0609BC50 mov.l r1,@r2
    c.r[0] = 0xFFFFFFF5u; goto L_0609BC66;  // 0609BC52 bra 0x0609BC66 ; mov #-11,r0
L_0609BC56:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BC80u);  // 0609BC56 mov.w 0x0609BC80,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0609BC58 mov.l @(r0,r1),r2
    c.r[1] = ld32(c.r[14] + 16);  // 0609BC5A mov.l @(16,r14),r1
    st32(c.r[2], c.r[1]);  // 0609BC5C mov.l r1,@r2
L_0609BC5E:
    c.r[1] = ld32(0x0609BC84u);  // 0609BC5E mov.l 0x0609BC84,r1
    c.r[1] = ld32(c.r[1]);  // 0609BC60 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BC78u);  // 0609BC62 mov.w 0x0609BC78,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609BC64 mov.l @(r0,r1),r0
L_0609BC66:
    c.r[14] += 24;  // 0609BC66 add #24,r14
    c.r[15] = c.r[14];  // 0609BC68 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BC6A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BC6C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609BC6E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609BC70 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609BC72 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BC74 rts ; mov.l @r15+,r8
}

void f_0609BCA0(SH2Context& c) {
    ran[2471] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BCA0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609BCA2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609BCA4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609BCA6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609BCA8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BCAA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BCAC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609BCAE mov r15,r14
    c.r[3] = ld32(0x0609BDC8u);  // 0609BCB0 mov.l 0x0609BDC8,r3
    c.r[1] = ld32(c.r[3]);  // 0609BCB2 mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609BDBAu);  // 0609BCB4 mov.w 0x0609BDBA,r2
    c.r[0] = c.r[1];  // 0609BCB6 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609BCB8 mov.l @(r0,r2),r1
    c.r[8] = 0x0u;  // 0609BCBA mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609BCBC cmp/ge r1,r8
    { const bool k = c.t; c.r[11] = c.r[4]; if (k) { goto L_0609BD2C; } }  // 0609BCBE bt/s 0x0609BD2C ; mov r4,r11
    c.r[10] = c.r[3];  // 0609BCC2 mov r3,r10
    c.r[12] = ld32(0x0609BDCCu);  // 0609BCC4 mov.l 0x0609BDCC,r12
    c.r[9] = 0x0u;  // 0609BCC6 mov #0,r9
L_0609BCC8:
    c.r[1] = ld32(c.r[3]);  // 0609BCC8 mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609BDBCu);  // 0609BCCA mov.w 0x0609BDBC,r2
    c.r[1] += c.r[9];  // 0609BCCC add r9,r1
    c.r[0] = c.r[1];  // 0609BCCE mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609BCD0 mov.l @(r0,r2),r1
    c.r[0] = c.r[1];  // 0609BCD2 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609BCD4 cmp/eq #-2,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_0609BCE0; } }  // 0609BCD6 bf/s 0x0609BCE0 ; mov #0,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609BDBEu);  // 0609BCDA mov.w 0x0609BDBE,r6
    c.r[1] = ld32(c.r[10]); goto L_0609BCE6;  // 0609BCDC bra 0x0609BCE6 ; mov.l @r10,r1
L_0609BCE0:
    c.r[3] = 0x1u;  // 0609BCE0 mov #1,r3
    c.r[6] = c.r[1];  // 0609BCE2 mov r1,r6
    c.r[1] = ld32(c.r[10]);  // 0609BCE4 mov.l @r10,r1
L_0609BCE6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609BDC0u);  // 0609BCE6 mov.w 0x0609BDC0,r2
    c.r[1] += c.r[9];  // 0609BCE8 add r9,r1
    c.r[0] = c.r[1];  // 0609BCEA mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609BCEC mov.l @(r0,r2),r1
    c.r[0] = c.r[1];  // 0609BCEE mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609BCF0 cmp/eq #-2,r0
    { const bool k = !c.t; c.r[0] = 0x2u; if (k) { goto L_0609BCFC; } }  // 0609BCF2 bf/s 0x0609BCFC ; mov #2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609BDBEu);  // 0609BCF6 mov.w 0x0609BDBE,r2
    goto L_0609BD00;  // 0609BCF8 bra 0x0609BD00 ; nop
L_0609BCFC:
    c.r[3] |= c.r[0];  // 0609BCFC or r0,r3
    c.r[2] = c.r[1];  // 0609BCFE mov r1,r2
L_0609BD00:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BDC2u);  // 0609BD00 mov.w 0x0609BDC2,r0
    c.r[1] = ld32(c.r[10]);  // 0609BD02 mov.l @r10,r1
    c.r[7] = c.r[2];  // 0609BD04 mov r2,r7
    c.r[1] += c.r[9];  // 0609BD06 add r9,r1
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609BD08 mov.l @(r0,r1),r4
    { const uint32_t x = c.r[12]; c.pr = 0x0609BD0Eu; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BD0Eu) return; }  // 0609BD0A jsr @r12 ; mov r3,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BD0E tst r0,r0
    if (!c.t) { goto L_0609BD2C; }  // 0609BD10 bf 0x0609BD2C
    c.r[1] = ld32(0x0609BDD0u);  // 0609BD12 mov.l 0x0609BDD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609BD18u; c.r[9] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BD18u) return; }  // 0609BD14 jsr @r1 ; add #12,r9
    c.r[1] = ld32(c.r[11]);  // 0609BD18 mov.l @r11,r1
    c.r[8] += 1;  // 0609BD1A add #1,r8
    c.r[1] += 1;  // 0609BD1C add #1,r1
    st32(c.r[11], c.r[1]);  // 0609BD1E mov.l r1,@r11
    c.r[1] = ld32(c.r[10]);  // 0609BD20 mov.l @r10,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BDBAu);  // 0609BD22 mov.w 0x0609BDBA,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609BD24 mov.l @(r0,r1),r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609BD26 cmp/ge r1,r8
    { const bool k = !c.t; c.r[3] = c.r[10]; if (k) { SH2_POLL(c); goto L_0609BCC8; } }  // 0609BD28 bf/s 0x0609BCC8 ; mov r10,r3
L_0609BD2C:
    c.r[1] = ld32(0x0609BDC8u);  // 0609BD2C mov.l 0x0609BDC8,r1
    c.r[2] = ld32(c.r[1]);  // 0609BD2E mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609BDBAu);  // 0609BD30 mov.w 0x0609BDBA,r3
    c.r[0] = c.r[2];  // 0609BD32 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609BD34 mov.l @(r0,r3),r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609BD36 cmp/ge r1,r8
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0609BD40; } }  // 0609BD38 bf/s 0x0609BD40 ; mov #0,r1
    st32(c.r[0] + c.r[3], c.r[1]); goto L_0609BD86;  // 0609BD3C bra 0x0609BD86 ; mov.l r1,@(r0,r3)
L_0609BD40:
    c.r[9] = 0x0u;  // 0609BD40 mov #0,r9
    c.r[4] = c.r[2];  // 0609BD42 mov r2,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609BDC2u);  // 0609BD44 mov.w 0x0609BDC2,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609BDBCu);  // 0609BD46 mov.w 0x0609BDBC,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609BDC0u);  // 0609BD48 mov.w 0x0609BDC0,r7
    c.r[10] = c.r[8];  // 0609BD4A mov r8,r10
    c.r[10] += c.r[10];  // 0609BD4C add r10,r10
    c.r[10] += c.r[8];  // 0609BD4E add r8,r10
    c.r[10] <<= 2;  // 0609BD50 shll2 r10
    c.r[10] += c.r[4];  // 0609BD52 add r4,r10
L_0609BD54:
    c.r[0] = c.r[10];  // 0609BD54 mov r10,r0
    c.r[8] += 1;  // 0609BD56 add #1,r8
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 0609BD58 mov.l @(r0,r5),r1
    c.r[9] += 1;  // 0609BD5A add #1,r9
    c.r[0] = c.r[2];  // 0609BD5C mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]);  // 0609BD5E mov.l r1,@(r0,r5)
    c.r[0] = c.r[10];  // 0609BD60 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0609BD62 mov.l @(r0,r6),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609BDBAu);  // 0609BD64 mov.w 0x0609BDBA,r3
    c.r[0] = c.r[2];  // 0609BD66 mov r2,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 0609BD68 mov.l r1,@(r0,r6)
    c.r[0] = c.r[10];  // 0609BD6A mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609BD6C mov.l @(r0,r7),r1
    c.r[10] += 12;  // 0609BD6E add #12,r10
    c.r[0] = c.r[2];  // 0609BD70 mov r2,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0609BD72 mov.l r1,@(r0,r7)
    c.r[0] = c.r[4];  // 0609BD74 mov r4,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609BD76 mov.l @(r0,r3),r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609BD78 cmp/ge r1,r8
    { const bool k = !c.t; c.r[2] += 12; if (k) { SH2_POLL(c); goto L_0609BD54; } }  // 0609BD7A bf/s 0x0609BD54 ; add #12,r2
    c.r[1] = ld32(0x0609BDC8u);  // 0609BD7E mov.l 0x0609BDC8,r1
    c.r[1] = ld32(c.r[1]);  // 0609BD80 mov.l @r1,r1
    c.r[0] = c.r[1];  // 0609BD82 mov r1,r0
    st32(c.r[0] + c.r[3], c.r[9]);  // 0609BD84 mov.l r9,@(r0,r3)
L_0609BD86:
    c.r[0] = ld32(0x0609BDD4u);  // 0609BD86 mov.l 0x0609BDD4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BD8Cu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BD8Cu) return; }  // 0609BD88 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BD8C tst r0,r0
    if (c.t) { goto L_0609BDA0; }  // 0609BD8E bt 0x0609BDA0
    c.r[1] = ld32(0x0609BDC8u);  // 0609BD90 mov.l 0x0609BDC8,r1
    c.r[1] = ld32(c.r[1]);  // 0609BD92 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BDBAu);  // 0609BD94 mov.w 0x0609BDBA,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0609BD96 mov.l @(r0,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609BD98 tst r2,r2
    if (!c.t) { goto L_0609BDA0; }  // 0609BD9A bf 0x0609BDA0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BDC4u);  // 0609BD9C mov.w 0x0609BDC4,r0
    st32(c.r[0] + c.r[1], c.r[2]);  // 0609BD9E mov.l r2,@(r0,r1)
L_0609BDA0:
    c.r[15] = c.r[14];  // 0609BDA0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BDA2 lds.l @r15+,pr
    c.r[1] = ld32(0x0609BDC8u);  // 0609BDA4 mov.l 0x0609BDC8,r1
    c.r[1] = ld32(c.r[1]);  // 0609BDA6 mov.l @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDA8 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BDBAu);  // 0609BDAA mov.w 0x0609BDBA,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609BDAC mov.l @(r0,r1),r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDAE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDB0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDB2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDB4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BDB6 rts ; mov.l @r15+,r8
}

void f_0609BDD8(SH2Context& c) {
    ran[2472] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BDD8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BDDA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BDDC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609BDDE mov r15,r14
    c.r[0] = ld32(0x0609BDF8u);  // 0609BDE0 mov.l 0x0609BDF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BDE6u; c.r[8] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BDE6u) return; }  // 0609BDE2 jsr @r0 ; mov r4,r8
    c.r[8] &= c.r[0];  // 0609BDE6 and r0,r8
    c.r[15] = c.r[14];  // 0609BDE8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BDEA lds.l @r15+,pr
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609BDEC tst r8,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDEE mov.l @r15+,r14
    c.r[0] = c.t;  // 0609BDF0 movt r0
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609BDF2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] ^= 0x1u; c.pc = x; return; }  // 0609BDF4 rts ; xor #1,r0
}

void f_0609BDFC(SH2Context& c) {
    ran[2473] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BDFC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609BDFE mov r15,r14
    c.r[0] = 0x0u;  // 0609BE00 mov #0,r0
    c.r[7] = 0x16u;  // 0609BE02 mov #22,r7
    c.r[3] = ld32(0x0609BE78u);  // 0609BE04 mov.l 0x0609BE78,r3
    c.r[2] = 0x0u;  // 0609BE06 mov #0,r2
L_0609BE08:
    c.r[1] = ld32(c.r[3]);  // 0609BE08 mov.l @r3,r1
    st8(c.r[0] + c.r[1], c.r[2]);  // 0609BE0A mov.b r2,@(r0,r1)
    c.r[1] = ld32(c.r[3]);  // 0609BE0C mov.l @r3,r1
    c.r[1] += c.r[0];  // 0609BE0E add r0,r1
    c.r[1] += 24;  // 0609BE10 add #24,r1
    c.r[0] += 1;  // 0609BE12 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[7];  // 0609BE14 cmp/gt r7,r0
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_0609BE08; } }  // 0609BE16 bf/s 0x0609BE08 ; mov.b r2,@r1
    c.r[1] = ld32(0x0609BE78u);  // 0609BE1A mov.l 0x0609BE78,r1
    c.r[3] = 0x0u;  // 0609BE1C mov #0,r3
    c.r[2] = 0xFFFFFFFFu;  // 0609BE1E mov #-1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE68u);  // 0609BE20 mov.w 0x0609BE68,r0
    c.r[1] = ld32(c.r[1]);  // 0609BE22 mov.l @r1,r1
    c.r[15] = c.r[14];  // 0609BE24 mov r14,r15
    st32(c.r[1] + 48, c.r[3]);  // 0609BE26 mov.l r3,@(48,r1)
    st32(c.r[1] + 52, c.r[2]);  // 0609BE28 mov.l r2,@(52,r1)
    st32(c.r[1] + 56, c.r[2]);  // 0609BE2A mov.l r2,@(56,r1)
    st32(c.r[1] + 60, c.r[3]);  // 0609BE2C mov.l r3,@(60,r1)
    c.r[2] = c.r[1];  // 0609BE2E mov r1,r2
    c.r[2] += 76;  // 0609BE30 add #76,r2
    st32(c.r[2], c.r[3]);  // 0609BE32 mov.l r3,@r2
    c.r[2] = c.r[1];  // 0609BE34 mov r1,r2
    c.r[2] += 80;  // 0609BE36 add #80,r2
    st32(c.r[2], c.r[3]);  // 0609BE38 mov.l r3,@r2
    c.r[2] = c.r[1];  // 0609BE3A mov r1,r2
    c.r[2] += 84;  // 0609BE3C add #84,r2
    st32(c.r[2], c.r[3]);  // 0609BE3E mov.l r3,@r2
    c.r[2] = c.r[1];  // 0609BE40 mov r1,r2
    c.r[2] += 88;  // 0609BE42 add #88,r2
    st32(c.r[2], c.r[3]);  // 0609BE44 mov.l r3,@r2
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE46 mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE6Au);  // 0609BE48 mov.w 0x0609BE6A,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE4A mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE6Cu);  // 0609BE4C mov.w 0x0609BE6C,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE4E mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE6Eu);  // 0609BE50 mov.w 0x0609BE6E,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE52 mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE70u);  // 0609BE54 mov.w 0x0609BE70,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE56 mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE72u);  // 0609BE58 mov.w 0x0609BE72,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE5A mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE74u);  // 0609BE5C mov.w 0x0609BE74,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE5E mov.l r3,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609BE76u);  // 0609BE60 mov.w 0x0609BE76,r0
    st32(c.r[0] + c.r[1], c.r[3]);  // 0609BE62 mov.l r3,@(r0,r1)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BE64 rts ; mov.l @r15+,r14
}

void f_0609BE7C(SH2Context& c) {
    ran[2474] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BE7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BE7E sts.l pr,@-r15
    c.r[15] -= 12;  // 0609BE80 add #-12,r15
    c.r[14] = c.r[15];  // 0609BE82 mov r15,r14
    c.r[0] = ld32(0x0609BEA0u);  // 0609BE84 mov.l 0x0609BEA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BE8Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BE8Au) return; }  // 0609BE86 jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x0609BEA4u);  // 0609BE8A mov.l 0x0609BEA4,r1
    c.r[2] = ld32(c.r[1]);  // 0609BE8C mov.l @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609BE8E mov.b @r14,r1
    c.r[2] += 64;  // 0609BE90 add #64,r2
    st8(c.r[2], c.r[1]);  // 0609BE92 mov.b r1,@r2
    c.r[14] += 12;  // 0609BE94 add #12,r14
    c.r[15] = c.r[14];  // 0609BE96 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BE98 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BE9A rts ; mov.l @r15+,r14
}

void f_0609BEA8(SH2Context& c) {
    ran[2475] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BEA8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609BEAA mov r15,r14
    c.r[1] = ld32(0x0609BEC0u);  // 0609BEAC mov.l 0x0609BEC0,r1
    c.r[2] = ld32(c.r[1]);  // 0609BEAE mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609BEB0 mov r2,r1
    c.r[1] += 76;  // 0609BEB2 add #76,r1
    st32(c.r[1], c.r[4]);  // 0609BEB4 mov.l r4,@r1
    c.r[2] += 80;  // 0609BEB6 add #80,r2
    st32(c.r[2], c.r[5]);  // 0609BEB8 mov.l r5,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BEBA rts ; mov.l @r15+,r14
}

void f_0609BEC4(SH2Context& c) {
    ran[2476] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BEC4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BEC6 sts.l pr,@-r15
    c.r[0] = ld32(0x0609BEE4u);  // 0609BEC8 mov.l 0x0609BEE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609BECEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BECEu) return; }  // 0609BECA jsr @r0 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609BEE2u);  // 0609BECE mov.w 0x0609BEE2,r1
    c.r[0] &= c.r[1];  // 0609BED0 and r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609BED2 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609BEDA; } }  // 0609BED4 bt/s 0x0609BEDA ; mov #0,r0
    c.r[0] = 0x1u;  // 0609BED8 mov #1,r0
L_0609BEDA:
    c.r[15] = c.r[14];  // 0609BEDA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BEDC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BEDE rts ; mov.l @r15+,r14
}

void f_0609BEE8(SH2Context& c) {
    ran[2477] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BEE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BEEA sts.l pr,@-r15
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609BEFCu);  // 0609BEEC mov.w 0x0609BEFC,r4
    c.r[1] = ld32(0x0609BF00u);  // 0609BEEE mov.l 0x0609BF00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609BEF4u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BEF4u) return; }  // 0609BEF0 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0609BEF4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BEF6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BEF8 rts ; mov.l @r15+,r14
}

void f_0609BF04(SH2Context& c) {
    ran[2478] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BF04 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609BF06 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609BF08 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BF0A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BF0C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609BF0E mov r15,r14
    c.r[8] = 0x0u;  // 0609BF10 mov #0,r8
    c.r[9] = ld32(0x0609BF40u);  // 0609BF12 mov.l 0x0609BF40,r9
    c.r[10] = ld32(0x0609BF44u);  // 0609BF14 mov.l 0x0609BF44,r10
L_0609BF16:
    { const uint32_t x = c.r[9]; c.pr = 0x0609BF1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BF1Au) return; }  // 0609BF16 jsr @r9 ; nop
    c.t = c.r[0] == 0x1u;  // 0609BF1A cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] += 1; if (k) { goto L_0609BF28; } }  // 0609BF1C bf/s 0x0609BF28 ; add #1,r8
    { const uint32_t x = c.r[10]; c.pr = 0x0609BF24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BF24u) return; }  // 0609BF20 jsr @r10 ; nop
    c.r[0] = 0x0u; goto L_0609BF30;  // 0609BF24 bra 0x0609BF30 ; mov #0,r0
L_0609BF28:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609BF3Eu);  // 0609BF28 mov.w 0x0609BF3E,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0609BF2A cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { SH2_POLL(c); goto L_0609BF16; } }  // 0609BF2C bf/s 0x0609BF16 ; mov #1,r0
L_0609BF30:
    c.r[15] = c.r[14];  // 0609BF30 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BF32 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BF34 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609BF36 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609BF38 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BF3A rts ; mov.l @r15+,r8
}

void f_0609BF48(SH2Context& c) {
    ran[2479] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BF48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609BF4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BF4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BF4E sts.l pr,@-r15
    c.r[15] -= 12;  // 0609BF50 add #-12,r15
    c.r[14] = c.r[15];  // 0609BF52 mov r15,r14
    c.r[8] = 0x0u;  // 0609BF54 mov #0,r8
    c.r[9] = ld32(0x0609BF88u);  // 0609BF56 mov.l 0x0609BF88,r9
L_0609BF58:
    { const uint32_t x = c.r[9]; c.pr = 0x0609BF5Cu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BF5Cu) return; }  // 0609BF58 jsr @r9 ; mov r14,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609BF5C mov.b @r14,r0
    c.r[1] = 0x1u;  // 0609BF5E mov #1,r1
    c.r[0] &= 0xFu;  // 0609BF60 and #15,r0
    c.r[0] -= 1;  // 0609BF62 add #-1,r0
    c.r[2] = c.r[0] & 0xFFu;  // 0609BF64 extu.b r0,r2
    c.t = c.r[2] > c.r[1];  // 0609BF66 cmp/hi r1,r2
    if (!c.t) { goto L_0609BF7A; }  // 0609BF68 bf 0x0609BF7A
    c.r[1] = ld32(0x0609BF8Cu);  // 0609BF6A mov.l 0x0609BF8C,r1
    c.r[1] = ld32(c.r[1]);  // 0609BF6C mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BF6E tst r1,r1
    { const bool k = !c.t; c.r[8] += 1; if (k) { goto L_0609BF7A; } }  // 0609BF70 bf/s 0x0609BF7A ; add #1,r8
    c.r[1] = ld32(0x0609BF90u);  // 0609BF74 mov.l 0x0609BF90,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0609BF76 cmp/gt r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0609BF58; }  // 0609BF78 bf 0x0609BF58
L_0609BF7A:
    c.r[14] += 12;  // 0609BF7A add #12,r14
    c.r[15] = c.r[14];  // 0609BF7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BF7E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BF80 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609BF82 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609BF84 rts ; mov.l @r15+,r8
}

void f_0609BF94(SH2Context& c) {
    ran[2480] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BF94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BF96 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BF98 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609BF9A add #-16,r15
    c.r[14] = c.r[15];  // 0609BF9C mov r15,r14
    ;  // 0609BF9E nop
L_0609BFA0:
    c.r[4] = c.r[14];  // 0609BFA0 mov r14,r4
    c.r[8] = ld32(0x0609BFCCu);  // 0609BFA2 mov.l 0x0609BFCC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609BFA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609BFA8u) return; }  // 0609BFA4 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609BFA8 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609BFAA mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609BFAC tst r1,r1
    if (!c.t) { goto L_0609BFB4; }  // 0609BFAE bf 0x0609BFB4
    goto L_0609BFB8;  // 0609BFB0 bra 0x0609BFB8 ; nop
L_0609BFB4:
    SH2_POLL(c); goto L_0609BFA0;  // 0609BFB4 bra 0x0609BFA0 ; nop
L_0609BFB8:
    c.r[0] = ld32(c.r[14] + 8);  // 0609BFB8 mov.l @(8,r14),r0
    goto L_0609BFBE;  // 0609BFBA bra 0x0609BFBE ; nop
L_0609BFBE:
    c.r[14] += 16;  // 0609BFBE add #16,r14
    c.r[15] = c.r[14];  // 0609BFC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609BFC2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609BFC4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609BFC6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609BFC8 rts ; nop
}

void f_0609BFD0(SH2Context& c) {
    ran[2481] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609BFD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609BFD2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609BFD4 sts.l pr,@-r15
    c.r[15] -= 20;  // 0609BFD6 add #-20,r15
    c.r[14] = c.r[15];  // 0609BFD8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609BFDA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609BFDC mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609BFDE mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609BFE0 mov.l @(4,r14),r1
    c.r[2] = c.r[14];  // 0609BFE2 mov r14,r2
    c.r[2] += 16;  // 0609BFE4 add #16,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0609BFE6 mov.l r2,@-r15
    c.r[2] = 0x0u;  // 0609BFE8 mov #0,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0609BFEA mov.l r2,@-r15
    c.r[2] = 0x0u;  // 0609BFEC mov #0,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0609BFEE mov.l r2,@-r15
    c.r[2] = c.r[14];  // 0609BFF0 mov r14,r2
    c.r[2] += 12;  // 0609BFF2 add #12,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0609BFF4 mov.l r2,@-r15
    c.r[7] = 0x0u;  // 0609BFF6 mov #0,r7
    c.r[6] = c.r[1];  // 0609BFF8 mov r1,r6
    c.r[5] = 0x0u;  // 0609BFFA mov #0,r5
    c.r[4] = ld32(c.r[14]);  // 0609BFFC mov.l @r14,r4
    c.r[8] = ld32(0x0609C040u);  // 0609BFFE mov.l 0x0609C040,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C004u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C004u) return; }  // 0609C000 jsr @r8 ; nop
    c.r[15] += 16;  // 0609C004 add #16,r15
    c.r[2] = ld32(c.r[14] + 16);  // 0609C006 mov.l @(16,r14),r2
    c.r[1] = 0x6u;  // 0609C008 mov #6,r1
    c.r[1] &= c.r[2];  // 0609C00A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C00C tst r1,r1
    if (!c.t) { goto L_0609C026; }  // 0609C00E bf 0x0609C026
    c.r[1] = ld32(c.r[14] + 8);  // 0609C010 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C012 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0609C014 mov.l @r2,r3
    c.r[7] = ld32(c.r[14] + 12);  // 0609C016 mov.l @(12,r14),r7
    c.r[2] = c.r[3];  // 0609C018 mov r3,r2
    c.r[2] += c.r[7];  // 0609C01A add r7,r2
    c.r[3] = c.r[2];  // 0609C01C mov r2,r3
    c.r[3] -= 1;  // 0609C01E add #-1,r3
    st32(c.r[1], c.r[3]);  // 0609C020 mov.l r3,@r1
    goto L_0609C032;  // 0609C022 bra 0x0609C032 ; nop
L_0609C026:
    c.r[1] = ld32(c.r[14] + 4);  // 0609C026 mov.l @(4,r14),r1
    c.r[2] = ld32(0x0609C044u);  // 0609C028 mov.l 0x0609C044,r2
    st32(c.r[1], c.r[2]);  // 0609C02A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609C02C mov.l @(8,r14),r1
    c.r[2] = ld32(0x0609C044u);  // 0609C02E mov.l 0x0609C044,r2
    st32(c.r[1], c.r[2]);  // 0609C030 mov.l r2,@r1
L_0609C032:
    c.r[14] += 20;  // 0609C032 add #20,r14
    c.r[15] = c.r[14];  // 0609C034 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C036 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C038 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C03A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C03C rts ; nop
}

void f_0609C048(SH2Context& c) {
    ran[2482] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C048 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C04A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C04C sts.l pr,@-r15
    c.r[15] -= 40;  // 0609C04E add #-40,r15
    c.r[14] = c.r[15];  // 0609C050 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C052 mov.l r4,@r14
    c.r[1] = 0x0u;  // 0609C054 mov #0,r1
    st32(c.r[14] + 36, c.r[1]);  // 0609C056 mov.l r1,@(36,r14)
    c.r[1] = ld32(c.r[14]);  // 0609C058 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 0609C05A mov.l @(20,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 0609C05C mov.l r2,@(8,r14)
    c.r[1] = c.r[14];  // 0609C05E mov r14,r1
    c.r[1] += 12;  // 0609C060 add #12,r1
    c.r[2] = c.r[14];  // 0609C062 mov r14,r2
    c.r[2] += 4;  // 0609C064 add #4,r2
    c.r[3] = ld32(c.r[14]);  // 0609C066 mov.l @r14,r3
    c.r[7] = ld32(c.r[3] + 12);  // 0609C068 mov.l @(12,r3),r7
    c.r[3] = ld32(c.r[7] + 20);  // 0609C06A mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 0609C06C mov r1,r6
    c.r[5] = c.r[2];  // 0609C06E mov r2,r5
    c.r[4] = c.r[3];  // 0609C070 mov r3,r4
    c.r[8] = ld32(0x0609C0FCu);  // 0609C072 mov.l 0x0609C0FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C078u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C078u) return; }  // 0609C074 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0609C078 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609C07A mov.l @(8,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0609C07C cmp/ge r2,r1
    if (!c.t) { goto L_0609C0E6; }  // 0609C07E bf 0x0609C0E6
    c.r[1] = 0x1u;  // 0609C080 mov #1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0609C082 mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609C084 mov.l @(8,r14),r1
    st32(c.r[14] + 20, c.r[1]);  // 0609C086 mov.l r1,@(20,r14)
    c.r[1] = 0x1u;  // 0609C088 mov #1,r1
    st32(c.r[14] + 24, c.r[1]);  // 0609C08A mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609C08C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609C08E mov.l @(8,r14),r2
    c.r[1] -= c.r[2];  // 0609C090 sub r2,r1
    c.r[2] = c.r[1];  // 0609C092 mov r1,r2
    c.r[2] += 1;  // 0609C094 add #1,r2
    st32(c.r[14] + 28, c.r[2]);  // 0609C096 mov.l r2,@(28,r14)
    c.r[1] = c.r[14];  // 0609C098 mov r14,r1
    c.r[2] = c.r[14];  // 0609C09A mov r14,r2
    c.r[2] += 16;  // 0609C09C add #16,r2
    c.r[1] = c.r[2];  // 0609C09E mov r2,r1
    c.r[2] += 16;  // 0609C0A0 add #16,r2
    c.r[1] = 0x0u;  // 0609C0A2 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0609C0A4 mov.b r1,@r2
    c.r[1] = ld32(c.r[14]);  // 0609C0A6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609C0A8 mov.l @(52,r1),r2
    c.r[1] = c.r[14];  // 0609C0AA mov r14,r1
    c.r[1] += 16;  // 0609C0AC add #16,r1
    c.r[5] = c.r[2];  // 0609C0AE mov r2,r5
    c.r[4] = c.r[1];  // 0609C0B0 mov r1,r4
    c.r[8] = ld32(0x0609C100u);  // 0609C0B2 mov.l 0x0609C100,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C0B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C0B8u) return; }  // 0609C0B4 jsr @r8 ; nop
    st32(c.r[14] + 36, c.r[0]);  // 0609C0B8 mov.l r0,@(36,r14)
    c.r[0] = ld32(c.r[14] + 36);  // 0609C0BA mov.l @(36,r14),r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 0609C0BC cmp/eq #-13,r0
    if (!c.t) { goto L_0609C0C8; }  // 0609C0BE bf 0x0609C0C8
    c.r[1] = 0xFFFFFFE9u;  // 0609C0C0 mov #-23,r1
    st32(c.r[14] + 36, c.r[1]);  // 0609C0C2 mov.l r1,@(36,r14)
    goto L_0609C0E6;  // 0609C0C4 bra 0x0609C0E6 ; nop
L_0609C0C8:
    c.r[1] = ld32(c.r[14] + 36);  // 0609C0C8 mov.l @(36,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C0CA tst r1,r1
    if (c.t) { goto L_0609C0D6; }  // 0609C0CC bt 0x0609C0D6
    c.r[1] = 0xFFFFFFFFu;  // 0609C0CE mov #-1,r1
    st32(c.r[14] + 36, c.r[1]);  // 0609C0D0 mov.l r1,@(36,r14)
    goto L_0609C0E6;  // 0609C0D2 bra 0x0609C0E6 ; nop
L_0609C0D6:
    c.r[2] = ld32(0x0609C104u);  // 0609C0D6 mov.l 0x0609C104,r2
    c.r[1] = ld32(c.r[2]);  // 0609C0D8 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609C0DA mov.l @(8,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 0609C0DC mov.l r2,@(20,r1)
    c.r[2] = ld32(0x0609C104u);  // 0609C0DE mov.l 0x0609C104,r2
    c.r[1] = ld32(c.r[2]);  // 0609C0E0 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0609C0E2 mov.l @(12,r14),r2
    st32(c.r[1] + 24, c.r[2]);  // 0609C0E4 mov.l r2,@(24,r1)
L_0609C0E6:
    c.r[0] = ld32(c.r[14] + 36);  // 0609C0E6 mov.l @(36,r14),r0
    goto L_0609C0EC;  // 0609C0E8 bra 0x0609C0EC ; nop
L_0609C0EC:
    c.r[14] += 40;  // 0609C0EC add #40,r14
    c.r[15] = c.r[14];  // 0609C0EE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C0F0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C0F2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C0F4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C0F6 rts ; nop
}

void f_0609C108(SH2Context& c) {
    ran[2483] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C108 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C10A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C10C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C10E add #-16,r15
    c.r[14] = c.r[15];  // 0609C110 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C112 mov.l r4,@r14
    c.r[1] = 0x3u;  // 0609C114 mov #3,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609C116 mov.l r1,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0609C118 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609C11A mov.l @(52,r1),r2
    c.r[1] = c.r[14];  // 0609C11C mov r14,r1
    c.r[1] += 4;  // 0609C11E add #4,r1
    c.r[5] = c.r[2];  // 0609C120 mov r2,r5
    c.r[4] = c.r[1];  // 0609C122 mov r1,r4
    c.r[8] = ld32(0x0609C16Cu);  // 0609C124 mov.l 0x0609C16C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C12Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C12Au) return; }  // 0609C126 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609C12A mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 0609C12C mov.l @(12,r14),r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 0609C12E cmp/eq #-13,r0
    if (!c.t) { goto L_0609C13C; }  // 0609C130 bf 0x0609C13C
    c.r[0] = 0xFFFFFFE9u;  // 0609C132 mov #-23,r0
    goto L_0609C15E;  // 0609C134 bra 0x0609C15E ; nop
L_0609C13C:
    c.r[1] = ld32(c.r[14] + 12);  // 0609C13C mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C13E tst r1,r1
    if (c.t) { goto L_0609C148; }  // 0609C140 bt 0x0609C148
    c.r[0] = 0xFFFFFFFFu;  // 0609C142 mov #-1,r0
    goto L_0609C15E;  // 0609C144 bra 0x0609C15E ; nop
L_0609C148:
    c.r[2] = ld32(0x0609C170u);  // 0609C148 mov.l 0x0609C170,r2
    c.r[1] = ld32(c.r[2]);  // 0609C14A mov.l @r2,r1
    c.r[2] = 0xFFFFFFFFu;  // 0609C14C mov #-1,r2
    st32(c.r[1] + 20, c.r[2]);  // 0609C14E mov.l r2,@(20,r1)
    c.r[2] = ld32(0x0609C170u);  // 0609C150 mov.l 0x0609C170,r2
    c.r[1] = ld32(c.r[2]);  // 0609C152 mov.l @r2,r1
    c.r[2] = 0xFFFFFFFFu;  // 0609C154 mov #-1,r2
    st32(c.r[1] + 24, c.r[2]);  // 0609C156 mov.l r2,@(24,r1)
    c.r[0] = ld32(c.r[14] + 12);  // 0609C158 mov.l @(12,r14),r0
    goto L_0609C15E;  // 0609C15A bra 0x0609C15E ; nop
L_0609C15E:
    c.r[14] += 16;  // 0609C15E add #16,r14
    c.r[15] = c.r[14];  // 0609C160 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C162 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C164 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C166 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C168 rts ; nop
}

void f_0609C174(SH2Context& c) {
    ran[2484] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C174 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C176 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C178 sts.l pr,@-r15
    c.r[15] -= 28;  // 0609C17A add #-28,r15
    c.r[14] = c.r[15];  // 0609C17C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C17E mov.l r4,@r14
    c.r[1] = 0x3u;  // 0609C180 mov #3,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609C182 mov.l r1,@(4,r14)
    c.r[1] = 0x3u;  // 0609C184 mov #3,r1
    st32(c.r[14] + 12, c.r[1]);  // 0609C186 mov.l r1,@(12,r14)
    c.r[1] = c.r[14];  // 0609C188 mov r14,r1
    c.r[2] = c.r[14];  // 0609C18A mov r14,r2
    c.r[2] += 4;  // 0609C18C add #4,r2
    c.r[1] = c.r[2];  // 0609C18E mov r2,r1
    c.r[2] += 16;  // 0609C190 add #16,r2
    c.r[1] = 0xFFFFFFFFu;  // 0609C192 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0609C194 mov.b r1,@r2
    c.r[1] = ld32(c.r[14]);  // 0609C196 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609C198 mov.l @(52,r1),r2
    c.r[1] = c.r[14];  // 0609C19A mov r14,r1
    c.r[1] += 4;  // 0609C19C add #4,r1
    c.r[5] = c.r[2];  // 0609C19E mov r2,r5
    c.r[4] = c.r[1];  // 0609C1A0 mov r1,r4
    c.r[8] = ld32(0x0609C1D0u);  // 0609C1A2 mov.l 0x0609C1D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C1A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C1A8u) return; }  // 0609C1A4 jsr @r8 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 0609C1A8 mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0609C1AA mov.l @(24,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C1AC tst r1,r1
    if (c.t) { goto L_0609C1BA; }  // 0609C1AE bt 0x0609C1BA
    c.r[0] = 0xFFFFFFFFu;  // 0609C1B0 mov #-1,r0
    goto L_0609C1C0;  // 0609C1B2 bra 0x0609C1C0 ; nop
L_0609C1BA:
    c.r[0] = 0x0u;  // 0609C1BA mov #0,r0
    goto L_0609C1C0;  // 0609C1BC bra 0x0609C1C0 ; nop
L_0609C1C0:
    c.r[14] += 28;  // 0609C1C0 add #28,r14
    c.r[15] = c.r[14];  // 0609C1C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C1C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C1C6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C1C8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C1CA rts ; nop
}

void f_0609C1D4(SH2Context& c) {
    ran[2485] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C1D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C1D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C1D8 sts.l pr,@-r15
    c.r[15] -= 32;  // 0609C1DA add #-32,r15
    c.r[14] = c.r[15];  // 0609C1DC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C1DE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609C1E0 mov.l r5,@(4,r14)
    c.r[1] = 0x0u;  // 0609C1E2 mov #0,r1
    st32(c.r[14] + 28, c.r[1]);  // 0609C1E4 mov.l r1,@(28,r14)
    c.r[1] = 0x1u;  // 0609C1E6 mov #1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0609C1E8 mov.l r1,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609C1EA mov.l @(4,r14),r1
    st32(c.r[14] + 12, c.r[1]);  // 0609C1EC mov.l r1,@(12,r14)
    c.r[1] = 0x3u;  // 0609C1EE mov #3,r1
    st32(c.r[14] + 16, c.r[1]);  // 0609C1F0 mov.l r1,@(16,r14)
    c.r[1] = c.r[14];  // 0609C1F2 mov r14,r1
    c.r[2] = c.r[14];  // 0609C1F4 mov r14,r2
    c.r[2] += 8;  // 0609C1F6 add #8,r2
    c.r[1] = c.r[2];  // 0609C1F8 mov r2,r1
    c.r[2] += 16;  // 0609C1FA add #16,r2
    c.r[1] = 0x0u;  // 0609C1FC mov #0,r1
    st8(c.r[2], c.r[1]);  // 0609C1FE mov.b r1,@r2
    c.r[1] = ld32(c.r[14]);  // 0609C200 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609C202 mov.l @(52,r1),r2
    c.r[1] = c.r[14];  // 0609C204 mov r14,r1
    c.r[1] += 8;  // 0609C206 add #8,r1
    c.r[5] = c.r[2];  // 0609C208 mov r2,r5
    c.r[4] = c.r[1];  // 0609C20A mov r1,r4
    c.r[8] = ld32(0x0609C24Cu);  // 0609C20C mov.l 0x0609C24C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C212u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C212u) return; }  // 0609C20E jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 0609C212 mov.l r0,@(28,r14)
    c.r[0] = ld32(c.r[14] + 28);  // 0609C214 mov.l @(28,r14),r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 0609C216 cmp/eq #-13,r0
    if (!c.t) { goto L_0609C222; }  // 0609C218 bf 0x0609C222
    c.r[1] = 0xFFFFFFE9u;  // 0609C21A mov #-23,r1
    st32(c.r[14] + 28, c.r[1]);  // 0609C21C mov.l r1,@(28,r14)
    goto L_0609C238;  // 0609C21E bra 0x0609C238 ; nop
L_0609C222:
    c.r[1] = ld32(c.r[14] + 28);  // 0609C222 mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C224 tst r1,r1
    if (c.t) { goto L_0609C230; }  // 0609C226 bt 0x0609C230
    c.r[1] = 0xFFFFFFFFu;  // 0609C228 mov #-1,r1
    st32(c.r[14] + 28, c.r[1]);  // 0609C22A mov.l r1,@(28,r14)
    goto L_0609C238;  // 0609C22C bra 0x0609C238 ; nop
L_0609C230:
    c.r[2] = ld32(0x0609C250u);  // 0609C230 mov.l 0x0609C250,r2
    c.r[1] = ld32(c.r[2]);  // 0609C232 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C234 mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 0609C236 mov.l r2,@(20,r1)
L_0609C238:
    c.r[0] = ld32(c.r[14] + 28);  // 0609C238 mov.l @(28,r14),r0
    goto L_0609C23E;  // 0609C23A bra 0x0609C23E ; nop
L_0609C23E:
    c.r[14] += 32;  // 0609C23E add #32,r14
    c.r[15] = c.r[14];  // 0609C240 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C242 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C244 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C246 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C248 rts ; nop
}

void f_0609C254(SH2Context& c) {
    ran[2486] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C254 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C256 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C258 sts.l pr,@-r15
    c.r[15] -= 32;  // 0609C25A add #-32,r15
    c.r[14] = c.r[15];  // 0609C25C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C25E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609C260 mov.l r5,@(4,r14)
    c.r[1] = 0x0u;  // 0609C262 mov #0,r1
    st32(c.r[14] + 28, c.r[1]);  // 0609C264 mov.l r1,@(28,r14)
    c.r[1] = 0x1u;  // 0609C266 mov #1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0609C268 mov.l r1,@(8,r14)
    c.r[2] = ld32(0x0609C2E4u);  // 0609C26A mov.l 0x0609C2E4,r2
    c.r[1] = ld32(c.r[2]);  // 0609C26C mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 20);  // 0609C26E mov.l @(20,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 0609C270 mov.l r2,@(12,r14)
    c.r[1] = 0x1u;  // 0609C272 mov #1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0609C274 mov.l r1,@(16,r14)
    c.r[2] = ld32(0x0609C2E4u);  // 0609C276 mov.l 0x0609C2E4,r2
    c.r[1] = ld32(c.r[2]);  // 0609C278 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C27A mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[1] + 20);  // 0609C27C mov.l @(20,r1),r3
    c.r[1] = c.r[2];  // 0609C27E mov r2,r1
    c.r[1] -= c.r[3];  // 0609C280 sub r3,r1
    c.r[2] = c.r[1];  // 0609C282 mov r1,r2
    c.r[2] += 1;  // 0609C284 add #1,r2
    st32(c.r[14] + 20, c.r[2]);  // 0609C286 mov.l r2,@(20,r14)
    c.r[1] = c.r[14];  // 0609C288 mov r14,r1
    c.r[2] = c.r[14];  // 0609C28A mov r14,r2
    c.r[2] += 8;  // 0609C28C add #8,r2
    c.r[1] = c.r[2];  // 0609C28E mov r2,r1
    c.r[2] += 16;  // 0609C290 add #16,r2
    c.r[1] = 0xFFFFFFFFu;  // 0609C292 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0609C294 mov.b r1,@r2
    c.r[1] = ld32(c.r[14]);  // 0609C296 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609C298 mov.l @(52,r1),r2
    c.r[1] = c.r[14];  // 0609C29A mov r14,r1
    c.r[1] += 8;  // 0609C29C add #8,r1
    c.r[5] = c.r[2];  // 0609C29E mov r2,r5
    c.r[4] = c.r[1];  // 0609C2A0 mov r1,r4
    c.r[8] = ld32(0x0609C2E8u);  // 0609C2A2 mov.l 0x0609C2E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C2A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C2A8u) return; }  // 0609C2A4 jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 0609C2A8 mov.l r0,@(28,r14)
    c.r[0] = ld32(c.r[14] + 28);  // 0609C2AA mov.l @(28,r14),r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 0609C2AC cmp/eq #-13,r0
    if (!c.t) { goto L_0609C2B8; }  // 0609C2AE bf 0x0609C2B8
    c.r[1] = 0xFFFFFFE9u;  // 0609C2B0 mov #-23,r1
    st32(c.r[14] + 28, c.r[1]);  // 0609C2B2 mov.l r1,@(28,r14)
    goto L_0609C2CE;  // 0609C2B4 bra 0x0609C2CE ; nop
L_0609C2B8:
    c.r[1] = ld32(c.r[14] + 28);  // 0609C2B8 mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C2BA tst r1,r1
    if (c.t) { goto L_0609C2C6; }  // 0609C2BC bt 0x0609C2C6
    c.r[1] = 0xFFFFFFFFu;  // 0609C2BE mov #-1,r1
    st32(c.r[14] + 28, c.r[1]);  // 0609C2C0 mov.l r1,@(28,r14)
    goto L_0609C2CE;  // 0609C2C2 bra 0x0609C2CE ; nop
L_0609C2C6:
    c.r[2] = ld32(0x0609C2E4u);  // 0609C2C6 mov.l 0x0609C2E4,r2
    c.r[1] = ld32(c.r[2]);  // 0609C2C8 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C2CA mov.l @(4,r14),r2
    st32(c.r[1] + 24, c.r[2]);  // 0609C2CC mov.l r2,@(24,r1)
L_0609C2CE:
    c.r[0] = ld32(c.r[14] + 28);  // 0609C2CE mov.l @(28,r14),r0
    goto L_0609C2D4;  // 0609C2D0 bra 0x0609C2D4 ; nop
L_0609C2D4:
    c.r[14] += 32;  // 0609C2D4 add #32,r14
    c.r[15] = c.r[14];  // 0609C2D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C2D8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C2DA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C2DC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C2DE rts ; nop
}

void f_0609C2EC(SH2Context& c) {
    ran[2487] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C2EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C2EE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C2F0 sts.l pr,@-r15
    c.r[15] -= 24;  // 0609C2F2 add #-24,r15
    c.r[14] = c.r[15];  // 0609C2F4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C2F6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609C2F8 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609C2FA mov.l r6,@(8,r14)
    c.r[1] = ld32(0x0609C38Cu);  // 0609C2FC mov.l 0x0609C38C,r1
    c.r[6] = 0x0u;  // 0609C2FE mov #0,r6
    c.r[5] = c.r[1];  // 0609C300 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0609C302 mov.l @r14,r4
    c.r[8] = ld32(0x0609C390u);  // 0609C304 mov.l 0x0609C390,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C30Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C30Au) return; }  // 0609C306 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609C30A mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609C30C mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0609C30E mov.l @(12,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0609C310 cmp/ge r2,r1
    if (!c.t) { goto L_0609C31A; }  // 0609C312 bf 0x0609C31A
    c.r[0] = 0x0u;  // 0609C314 mov #0,r0
    goto L_0609C37C;  // 0609C316 bra 0x0609C37C ; nop
L_0609C31A:
    c.r[1] = c.r[14];  // 0609C31A mov r14,r1
    c.r[1] += 16;  // 0609C31C add #16,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C31E mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14]);  // 0609C320 mov.l @r14,r3
    c.r[7] = c.r[3];  // 0609C322 mov r3,r7
    c.r[7] += 28;  // 0609C324 add #28,r7
    c.r[3] = ld32(c.r[7] + 4);  // 0609C326 mov.l @(4,r7),r3
    c.r[6] = c.r[1];  // 0609C328 mov r1,r6
    c.r[5] = c.r[2];  // 0609C32A mov r2,r5
    c.r[4] = c.r[3];  // 0609C32C mov r3,r4
    c.r[8] = ld32(0x0609C394u);  // 0609C32E mov.l 0x0609C394,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C334u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C334u) return; }  // 0609C330 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0609C334 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0609C336 mov.l @(16,r14),r2
    st32(c.r[1], c.r[2]);  // 0609C338 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609C33A mov.l @(8,r14),r1
    c.r[2] = c.r[14];  // 0609C33C mov r14,r2
    c.r[3] = c.r[14];  // 0609C33E mov r14,r3
    c.r[3] += 20;  // 0609C340 add #20,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609C342 mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 0609C344 extu.b r2,r3
    st32(c.r[1] + 4, c.r[3]);  // 0609C346 mov.l r3,@(4,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0609C348 mov.l @(8,r14),r1
    c.r[2] = c.r[14];  // 0609C34A mov r14,r2
    c.r[3] = c.r[14];  // 0609C34C mov r14,r3
    c.r[3] += 21;  // 0609C34E add #21,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609C350 mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 0609C352 extu.b r2,r3
    st32(c.r[1] + 8, c.r[3]);  // 0609C354 mov.l r3,@(8,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0609C356 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0609C358 mov r1,r2
    c.r[1] += 12;  // 0609C35A add #12,r1
    c.r[2] = c.r[14];  // 0609C35C mov r14,r2
    c.r[3] = c.r[14];  // 0609C35E mov r14,r3
    c.r[3] += 22;  // 0609C360 add #22,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609C362 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609C364 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609C366 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0609C368 mov r1,r2
    c.r[1] += 13;  // 0609C36A add #13,r1
    c.r[2] = c.r[14];  // 0609C36C mov r14,r2
    c.r[3] = c.r[14];  // 0609C36E mov r14,r3
    c.r[3] += 23;  // 0609C370 add #23,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609C372 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609C374 mov.b r2,@r1
    c.r[0] = 0x1u;  // 0609C376 mov #1,r0
    goto L_0609C37C;  // 0609C378 bra 0x0609C37C ; nop
L_0609C37C:
    c.r[14] += 24;  // 0609C37C add #24,r14
    c.r[15] = c.r[14];  // 0609C37E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C380 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C382 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C384 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C386 rts ; nop
}

void f_0609C398(SH2Context& c) {
    ran[2488] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C398 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C39A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C39C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C39E add #-16,r15
    c.r[14] = c.r[15];  // 0609C3A0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C3A2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609C3A4 mov.l r5,@(4,r14)
    c.r[1] = c.r[14];  // 0609C3A6 mov r14,r1
    c.r[1] += 12;  // 0609C3A8 add #12,r1
    c.r[3] = ld32(c.r[14]);  // 0609C3AA mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609C3AC mov r3,r2
    c.r[2] += 28;  // 0609C3AE add #28,r2
    c.r[3] = ld32(c.r[2] + 36);  // 0609C3B0 mov.l @(36,r2),r3
    c.r[7] = ld32(c.r[14] + 4);  // 0609C3B2 mov.l @(4,r14),r7
    c.r[2] = c.r[3];  // 0609C3B4 mov r3,r2
    c.r[2] += c.r[7];  // 0609C3B6 add r7,r2
    c.r[3] = ld32(c.r[14]);  // 0609C3B8 mov.l @r14,r3
    c.r[7] = c.r[3];  // 0609C3BA mov r3,r7
    c.r[7] += 28;  // 0609C3BC add #28,r7
    c.r[3] = ld32(c.r[7] + 4);  // 0609C3BE mov.l @(4,r7),r3
    c.r[7] = c.r[14];  // 0609C3C0 mov r14,r7
    c.r[7] += 8;  // 0609C3C2 add #8,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0609C3C4 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0609C3C6 mov r1,r7
    c.r[6] = 0x1u;  // 0609C3C8 mov #1,r6
    c.r[5] = c.r[2];  // 0609C3CA mov r2,r5
    c.r[4] = c.r[3];  // 0609C3CC mov r3,r4
    c.r[8] = ld32(0x0609C3F8u);  // 0609C3CE mov.l 0x0609C3F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C3D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C3D4u) return; }  // 0609C3D0 jsr @r8 ; nop
    c.r[15] += 4;  // 0609C3D4 add #4,r15
    c.r[8] = ld32(0x0609C3FCu);  // 0609C3D6 mov.l 0x0609C3FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C3DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C3DCu) return; }  // 0609C3D8 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 0609C3DC mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0609C3DE mov r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0609C3E0 shlr r1
    c.r[0] = c.r[1];  // 0609C3E2 mov r1,r0
    goto L_0609C3E8;  // 0609C3E4 bra 0x0609C3E8 ; nop
L_0609C3E8:
    c.r[14] += 16;  // 0609C3E8 add #16,r14
    c.r[15] = c.r[14];  // 0609C3EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C3EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C3EE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C3F0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C3F2 rts ; nop
}

void f_0609C400(SH2Context& c) {
    ran[2489] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C400 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C402 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C404 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C406 add #-16,r15
    c.r[14] = c.r[15];  // 0609C408 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C40A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609C40C mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609C40E mov.l r6,@(8,r14)
    c.r[1] = ld32(0x0609C460u);  // 0609C410 mov.l 0x0609C460,r1
    c.r[6] = 0x0u;  // 0609C412 mov #0,r6
    c.r[5] = c.r[1];  // 0609C414 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0609C416 mov.l @r14,r4
    c.r[8] = ld32(0x0609C464u);  // 0609C418 mov.l 0x0609C464,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C41Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C41Eu) return; }  // 0609C41A jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609C41E mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609C420 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609C422 mov.l @(8,r14),r2
    c.r[1] += c.r[2];  // 0609C424 add r2,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0609C426 mov.l @(12,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0609C428 cmp/gt r2,r1
    if (!c.t) { goto L_0609C434; }  // 0609C42A bf 0x0609C434
    c.r[1] = ld32(c.r[14] + 12);  // 0609C42C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C42E mov.l @(4,r14),r2
    c.r[1] -= c.r[2];  // 0609C430 sub r2,r1
    st32(c.r[14] + 8, c.r[1]);  // 0609C432 mov.l r1,@(8,r14)
L_0609C434:
    c.r[1] = ld32(c.r[14] + 8);  // 0609C434 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0609C436 cmp/pl r1
    if (!c.t) { goto L_0609C452; }  // 0609C438 bf 0x0609C452
    c.r[1] = ld32(c.r[14] + 8);  // 0609C43A mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C43C mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14]);  // 0609C43E mov.l @r14,r3
    c.r[7] = c.r[3];  // 0609C440 mov r3,r7
    c.r[7] += 28;  // 0609C442 add #28,r7
    c.r[3] = ld32(c.r[7] + 4);  // 0609C444 mov.l @(4,r7),r3
    c.r[6] = c.r[1];  // 0609C446 mov r1,r6
    c.r[5] = c.r[2];  // 0609C448 mov r2,r5
    c.r[4] = c.r[3];  // 0609C44A mov r3,r4
    c.r[8] = ld32(0x0609C468u);  // 0609C44C mov.l 0x0609C468,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C452u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C452u) return; }  // 0609C44E jsr @r8 ; nop
L_0609C452:
    c.r[14] += 16;  // 0609C452 add #16,r14
    c.r[15] = c.r[14];  // 0609C454 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C456 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C458 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C45A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C45C rts ; nop
}

void f_0609C46C(SH2Context& c) {
    ran[2490] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C46C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C46E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C470 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C472 add #-16,r15
    c.r[14] = c.r[15];  // 0609C474 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C476 mov.l r4,@r14
    c.r[2] = ld32(c.r[14]);  // 0609C478 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0609C47A mov r2,r1
    c.r[1] += 28;  // 0609C47C add #28,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609C47E mov.l @(4,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 0609C480 mov.l r2,@(4,r14)
L_0609C482:
    c.r[1] = c.r[14];  // 0609C482 mov r14,r1
    c.r[1] += 8;  // 0609C484 add #8,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609C486 mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 0609C488 mov r1,r5
    c.r[4] = c.r[2];  // 0609C48A mov r2,r4
    c.r[8] = ld32(0x0609C4B8u);  // 0609C48C mov.l 0x0609C4B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C492u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C492u) return; }  // 0609C48E jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609C492 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609C494 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C496 tst r1,r1
    if (!c.t) { goto L_0609C49E; }  // 0609C498 bf 0x0609C49E
    goto L_0609C4A2;  // 0609C49A bra 0x0609C4A2 ; nop
L_0609C49E:
    SH2_POLL(c); goto L_0609C482;  // 0609C49E bra 0x0609C482 ; nop
L_0609C4A2:
    c.r[0] = ld32(c.r[14] + 8);  // 0609C4A2 mov.l @(8,r14),r0
    goto L_0609C4A8;  // 0609C4A4 bra 0x0609C4A8 ; nop
L_0609C4A8:
    c.r[14] += 16;  // 0609C4A8 add #16,r14
    c.r[15] = c.r[14];  // 0609C4AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C4AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C4AE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C4B0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C4B2 rts ; nop
}

void f_0609C4BC(SH2Context& c) {
    ran[2491] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C4BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C4BE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C4C0 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C4C2 add #-16,r15
    c.r[14] = c.r[15];  // 0609C4C4 mov r15,r14
    ;  // 0609C4C6 nop
L_0609C4C8:
    c.r[1] = c.r[14];  // 0609C4C8 mov r14,r1
    c.r[1] += 8;  // 0609C4CA add #8,r1
    c.r[2] = c.r[14];  // 0609C4CC mov r14,r2
    c.r[2] += 4;  // 0609C4CE add #4,r2
    c.r[6] = c.r[1];  // 0609C4D0 mov r1,r6
    c.r[5] = c.r[2];  // 0609C4D2 mov r2,r5
    c.r[4] = c.r[14];  // 0609C4D4 mov r14,r4
    c.r[8] = ld32(0x0609C500u);  // 0609C4D6 mov.l 0x0609C500,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C4DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C4DCu) return; }  // 0609C4D8 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609C4DC mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609C4DE mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C4E0 tst r1,r1
    if (!c.t) { goto L_0609C4E8; }  // 0609C4E2 bf 0x0609C4E8
    goto L_0609C4EC;  // 0609C4E4 bra 0x0609C4EC ; nop
L_0609C4E8:
    SH2_POLL(c); goto L_0609C4C8;  // 0609C4E8 bra 0x0609C4C8 ; nop
L_0609C4EC:
    c.r[0] = ld32(c.r[14] + 8);  // 0609C4EC mov.l @(8,r14),r0
    goto L_0609C4F2;  // 0609C4EE bra 0x0609C4F2 ; nop
L_0609C4F2:
    c.r[14] += 16;  // 0609C4F2 add #16,r14
    c.r[15] = c.r[14];  // 0609C4F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C4F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C4F8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C4FA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C4FC rts ; nop
}

void f_0609C504(SH2Context& c) {
    ran[2492] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C504 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609C506 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C508 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C50A sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C50C add #-8,r15
    c.r[14] = c.r[15];  // 0609C50E mov r15,r14
    c.r[4] = 0xFFFFFFFBu;  // 0609C510 mov #-5,r4
    c.r[8] = ld32(0x0609C56Cu);  // 0609C512 mov.l 0x0609C56C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609C518u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C518u) return; }  // 0609C514 jsr @r8 ; nop
    c.r[1] = 0x0u;  // 0609C518 mov #0,r1
    st32(c.r[14], c.r[1]);  // 0609C51A mov.l r1,@r14
L_0609C51C:
    c.r[1] = ld32(c.r[14]);  // 0609C51C mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609C56Au);  // 0609C51E mov.w 0x0609C56A,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0609C520 cmp/gt r2,r1
    if (!c.t) { goto L_0609C528; }  // 0609C522 bf 0x0609C528
    goto L_0609C55A;  // 0609C524 bra 0x0609C55A ; nop
L_0609C528:
    c.r[1] = c.r[14];  // 0609C528 mov r14,r1
    c.r[8] = c.r[14];  // 0609C52A mov r14,r8
    c.r[8] += 4;  // 0609C52C add #4,r8
    c.r[9] = ld32(0x0609C570u);  // 0609C52E mov.l 0x0609C570,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0609C534u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C534u) return; }  // 0609C530 jsr @r9 ; nop
    st16(c.r[8], c.r[0]);  // 0609C534 mov.w r0,@r8
    c.r[1] = c.r[14];  // 0609C536 mov r14,r1
    c.r[2] = c.r[14];  // 0609C538 mov r14,r2
    c.r[2] += 4;  // 0609C53A add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609C53C mov.w @r2,r1
    c.r[2] = 0x4u;  // 0609C53E mov #4,r2
    c.r[2] &= c.r[1];  // 0609C540 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0609C542 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609C544 tst r1,r1
    if (c.t) { goto L_0609C54C; }  // 0609C546 bt 0x0609C54C
    goto L_0609C55A;  // 0609C548 bra 0x0609C55A ; nop
L_0609C54C:
    c.r[2] = ld32(c.r[14]);  // 0609C54C mov.l @r14,r2
    c.r[1] = c.r[2];  // 0609C54E mov r2,r1
    c.r[1] += 1;  // 0609C550 add #1,r1
    c.r[2] = c.r[1];  // 0609C552 mov r1,r2
    st32(c.r[14], c.r[2]);  // 0609C554 mov.l r2,@r14
    SH2_POLL(c); goto L_0609C51C;  // 0609C556 bra 0x0609C51C ; nop
L_0609C55A:
    c.r[14] += 8;  // 0609C55A add #8,r14
    c.r[15] = c.r[14];  // 0609C55C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C55E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C560 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609C562 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609C564 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609C566 rts ; nop
}

void f_0609C574(SH2Context& c) {
    ran[2493] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C574 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C576 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609C578 mov r15,r14
    c.r[0] = ld32(0x0609C588u);  // 0609C57A mov.l 0x0609C588,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C580u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C580u) return; }  // 0609C57C jsr @r0 ; mov #0,r7
    c.r[15] = c.r[14];  // 0609C580 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C582 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C584 rts ; mov.l @r15+,r14
}

void f_0609C58C(SH2Context& c) {
    ran[2494] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C58C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C58E sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C590 add #-8,r15
    c.r[14] = c.r[15];  // 0609C592 mov r15,r14
    c.r[0] = ld32(0x0609C5A8u);  // 0609C594 mov.l 0x0609C5A8,r0
    c.r[7] = 0x1u;  // 0609C596 mov #1,r7
    { const uint32_t x = c.r[0]; c.pr = 0x0609C59Cu; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C59Cu) return; }  // 0609C598 jsr @r0 ; mov r14,r6
    c.r[14] += 8;  // 0609C59C add #8,r14
    c.r[15] = c.r[14];  // 0609C59E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C5A0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C5A2 rts ; mov.l @r15+,r14
}

void f_0609C5AC(SH2Context& c) {
    ran[2495] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C5AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609C5AE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609C5B0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609C5B2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C5B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C5B6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609C5B8 mov r15,r14
    c.r[8] = c.r[6];  // 0609C5BA mov r6,r8
    c.r[0] = ld32(0x0609C610u);  // 0609C5BC mov.l 0x0609C610,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C5C2u; c.r[10] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C5C2u) return; }  // 0609C5BE jsr @r0 ; mov r7,r10
    c.r[9] = c.r[0];  // 0609C5C2 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609C5C4 tst r9,r9
    if (!c.t) { goto L_0609C5FE; }  // 0609C5C6 bf 0x0609C5FE
    c.r[0] = sh2_get_sr(c);  // 0609C5C8 stc sr,r0
    c.r[0] &= 0xF0u;  // 0609C5CA and #240,r0
    c.r[11] = c.r[0];  // 0609C5CC mov r0,r11
    c.r[11] >>= 2;  // 0609C5CE shlr2 r11
    c.r[11] >>= 2;  // 0609C5D0 shlr2 r11
    c.r[0] = sh2_get_sr(c);  // 0609C5D2 stc sr,r0
    c.r[0] |= 0xF0u;  // 0609C5D4 or #240,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 0609C5D6 ldc r0,sr
    c.r[5] = ld32(0x0609C614u);  // 0609C5D8 mov.l 0x0609C614,r5
    c.t = (c.r[10] & c.r[10]) == 0;  // 0609C5DA tst r10,r10
    if (c.t) { goto L_0609C5E8; }  // 0609C5DC bt 0x0609C5E8
    c.r[1] = ld32(0x0609C618u);  // 0609C5DE mov.l 0x0609C618,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609C5E4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C5E4u) return; }  // 0609C5E0 jsr @r1 ; mov r8,r4
    goto L_0609C5EC;  // 0609C5E4 bra 0x0609C5EC ; nop
L_0609C5E8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609C5E8 mov.b @r8,r1
    st8(c.r[5], c.r[1]);  // 0609C5EA mov.b r1,@r5
L_0609C5EC:
    c.r[1] = sh2_get_sr(c);  // 0609C5EC stc sr,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609C60Eu);  // 0609C5EE mov.w 0x0609C60E,r2
    c.r[1] &= c.r[2];  // 0609C5F0 and r2,r1
    c.r[2] = c.r[11];  // 0609C5F2 mov r11,r2
    c.r[2] <<= 2;  // 0609C5F4 shll2 r2
    c.r[2] <<= 2;  // 0609C5F6 shll2 r2
    c.r[1] |= c.r[2];  // 0609C5F8 or r2,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0609C5FA ldc r1,sr
    c.r[0] = c.r[9];  // 0609C5FC mov r9,r0
L_0609C5FE:
    c.r[15] = c.r[14];  // 0609C5FE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C600 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C602 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609C604 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609C606 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609C608 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C60A rts ; mov.l @r15+,r8
}

void f_0609C61C(SH2Context& c) {
    ran[2496] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C61C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609C61E mov r15,r14
    c.r[0] = sh2_get_sr(c);  // 0609C620 stc sr,r0
    c.r[0] &= 0xF0u;  // 0609C622 and #240,r0
    c.r[2] = c.r[0];  // 0609C624 mov r0,r2
    c.r[2] >>= 2;  // 0609C626 shlr2 r2
    c.r[2] >>= 2;  // 0609C628 shlr2 r2
    c.r[0] = sh2_get_sr(c);  // 0609C62A stc sr,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609C654u);  // 0609C62C mov.w 0x0609C654,r3
    c.r[0] |= 0xF0u;  // 0609C62E or #240,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 0609C630 ldc r0,sr
    c.r[1] = ld32(0x0609C658u);  // 0609C632 mov.l 0x0609C658,r1
    c.r[7] = ld32(c.r[1]); c.r[1] += 4;  // 0609C634 mov.l @r1+,r7
    st32(c.r[4], c.r[7]);  // 0609C636 mov.l r7,@r4
    c.r[4] += 4;  // 0609C638 add #4,r4
    c.r[7] = ld32(c.r[1]); c.r[1] += 4;  // 0609C63A mov.l @r1+,r7
    st32(c.r[4], c.r[7]);  // 0609C63C mov.l r7,@r4
    c.r[1] = ld32(c.r[1]);  // 0609C63E mov.l @r1,r1
    st32(c.r[4] + 4, c.r[1]);  // 0609C640 mov.l r1,@(4,r4)
    c.r[1] = sh2_get_sr(c);  // 0609C642 stc sr,r1
    c.r[1] &= c.r[3];  // 0609C644 and r3,r1
    c.r[2] <<= 2;  // 0609C646 shll2 r2
    c.r[2] <<= 2;  // 0609C648 shll2 r2
    c.r[1] |= c.r[2];  // 0609C64A or r2,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0609C64C ldc r1,sr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C64E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609C650 rts ; mov #0,r0
}

void f_0609C65C(SH2Context& c) {
    ran[2497] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C65C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609C65E mov r15,r14
    c.r[2] = c.r[5];  // 0609C660 mov r5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0609C662 mov.b @r4,r1
    c.r[2] += 4;  // 0609C664 add #4,r2
    st8(c.r[5], c.r[1]);  // 0609C666 mov.b r1,@r5
    c.r[1] = c.r[4];  // 0609C668 mov r4,r1
    c.r[1] += 1;  // 0609C66A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C66C mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 0609C66E mov.b r1,@r2
    c.r[2] = c.r[5];  // 0609C670 mov r5,r2
    c.r[1] = c.r[4];  // 0609C672 mov r4,r1
    c.r[1] += 2;  // 0609C674 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C676 mov.b @r1,r1
    c.r[2] += 5;  // 0609C678 add #5,r2
    st8(c.r[2], c.r[1]);  // 0609C67A mov.b r1,@r2
    c.r[2] = c.r[5];  // 0609C67C mov r5,r2
    c.r[2] += 6;  // 0609C67E add #6,r2
    c.r[1] = c.r[4];  // 0609C680 mov r4,r1
    c.r[1] += 3;  // 0609C682 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C684 mov.b @r1,r1
    c.r[4] += 4;  // 0609C686 add #4,r4
    st8(c.r[2], c.r[1]);  // 0609C688 mov.b r1,@r2
    c.r[2] = c.r[5];  // 0609C68A mov r5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0609C68C mov.b @r4,r1
    c.r[2] += 7;  // 0609C68E add #7,r2
    st8(c.r[2], c.r[1]);  // 0609C690 mov.b r1,@r2
    c.r[1] = ld32(c.r[4]);  // 0609C692 mov.l @r4,r1
    c.r[2] = ld32(0x0609C6A0u);  // 0609C694 mov.l 0x0609C6A0,r2
    c.r[1] &= c.r[2];  // 0609C696 and r2,r1
    st32(c.r[5] + 8, c.r[1]);  // 0609C698 mov.l r1,@(8,r5)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C69A rts ; mov.l @r15+,r14
}

void f_0609C6A4(SH2Context& c) {
    ran[2498] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C6A4 mov.l r14,@-r15
    c.r[15] -= 4;  // 0609C6A6 add #-4,r15
    c.r[14] = c.r[15];  // 0609C6A8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609C6AA mov.l r4,@r14
    goto L_0609C6B8;  // 0609C6AC bra 0x0609C6B8 ; nop
L_0609C6B0:
    c.r[1] = ld32(c.r[14]);  // 0609C6B0 mov.l @r14,r1
    c.r[1] -= 1;  // 0609C6B2 add #-1,r1
    st32(c.r[14], c.r[1]);  // 0609C6B4 mov.l r1,@r14
    c.r[1] = ld32(c.r[14]);  // 0609C6B6 mov.l @r14,r1
L_0609C6B8:
    c.r[1] = ld32(c.r[14]);  // 0609C6B8 mov.l @r14,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609C6BA cmp/pl r1
    if (c.t) { SH2_POLL(c); goto L_0609C6B0; }  // 0609C6BC bt 0x0609C6B0
    c.r[14] += 4;  // 0609C6BE add #4,r14
    c.r[15] = c.r[14];  // 0609C6C0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C6C2 rts ; mov.l @r15+,r14
}

void f_0609C6C8(SH2Context& c) {
    ran[2499] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C6C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C6CA sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C6CC add #-8,r15
    c.r[14] = c.r[15];  // 0609C6CE mov r15,r14
    c.r[2] = 0x0u;  // 0609C6D0 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C6D2 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C6D4 mov.l r2,@(4,r14)
    c.r[1] = 0x60u;  // 0609C6D6 mov #96,r1
    st8(c.r[14], c.r[1]);  // 0609C6D8 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C6DA mov r14,r1
    c.r[1] += 1;  // 0609C6DC add #1,r1
    st8(c.r[1], c.r[4]);  // 0609C6DE mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C6E0 mov r14,r1
    c.r[1] += 2;  // 0609C6E2 add #2,r1
    st8(c.r[1], c.r[5]);  // 0609C6E4 mov.b r5,@r1
    c.r[0] = ld32(0x0609C6F8u);  // 0609C6E6 mov.l 0x0609C6F8,r0
    c.r[5] = c.r[14];  // 0609C6E8 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609C6EEu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C6EEu) return; }  // 0609C6EA jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609C6EE add #8,r14
    c.r[15] = c.r[14];  // 0609C6F0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C6F2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C6F4 rts ; mov.l @r15+,r14
}

void f_0609C6FC(SH2Context& c) {
    ran[2500] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C6FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C6FE sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C700 add #-8,r15
    c.r[14] = c.r[15];  // 0609C702 mov r15,r14
    c.r[2] = 0x0u;  // 0609C704 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C706 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C708 mov.l r2,@(4,r14)
    c.r[1] = 0x61u;  // 0609C70A mov #97,r1
    st8(c.r[14], c.r[1]);  // 0609C70C mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C70E mov r14,r1
    c.r[1] += 2;  // 0609C710 add #2,r1
    st16(c.r[1], c.r[5]);  // 0609C712 mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609C714 mov r14,r1
    c.r[1] += 4;  // 0609C716 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C718 mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C71A mov r14,r1
    c.r[1] += 6;  // 0609C71C add #6,r1
    st16(c.r[1], c.r[6]);  // 0609C71E mov.w r6,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609C732u);  // 0609C720 mov.w 0x0609C732,r4
    c.r[0] = ld32(0x0609C734u);  // 0609C722 mov.l 0x0609C734,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C728u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C728u) return; }  // 0609C724 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C728 add #8,r14
    c.r[15] = c.r[14];  // 0609C72A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C72C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C72E rts ; mov.l @r15+,r14
}

void f_0609C738(SH2Context& c) {
    ran[2501] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C738 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C73A sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C73C add #-8,r15
    c.r[14] = c.r[15];  // 0609C73E mov r15,r14
    c.r[2] = 0x0u;  // 0609C740 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C742 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C744 mov.l r2,@(4,r14)
    c.r[1] = 0x62u;  // 0609C746 mov #98,r1
    st8(c.r[14], c.r[1]);  // 0609C748 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C74A mov r14,r1
    c.r[1] += 2;  // 0609C74C add #2,r1
    st16(c.r[1], c.r[5]);  // 0609C74E mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609C750 mov r14,r1
    c.r[1] += 4;  // 0609C752 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C754 mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C756 mov r14,r1
    c.r[1] += 6;  // 0609C758 add #6,r1
    st16(c.r[1], c.r[6]);  // 0609C75A mov.w r6,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609C76Eu);  // 0609C75C mov.w 0x0609C76E,r4
    c.r[0] = ld32(0x0609C770u);  // 0609C75E mov.l 0x0609C770,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C764u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C764u) return; }  // 0609C760 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C764 add #8,r14
    c.r[15] = c.r[14];  // 0609C766 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C768 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C76A rts ; mov.l @r15+,r14
}

void f_0609C774(SH2Context& c) {
    ran[2502] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C774 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C776 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C778 add #-8,r15
    c.r[14] = c.r[15];  // 0609C77A mov r15,r14
    c.r[2] = 0x0u;  // 0609C77C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C77E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C780 mov.l r2,@(4,r14)
    c.r[1] = 0x63u;  // 0609C782 mov #99,r1
    st8(c.r[14], c.r[1]);  // 0609C784 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C786 mov r14,r1
    c.r[1] += 2;  // 0609C788 add #2,r1
    st16(c.r[1], c.r[5]);  // 0609C78A mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609C78C mov r14,r1
    c.r[1] += 4;  // 0609C78E add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C790 mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C792 mov r14,r1
    c.r[1] += 6;  // 0609C794 add #6,r1
    st16(c.r[1], c.r[6]);  // 0609C796 mov.w r6,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609C7AAu);  // 0609C798 mov.w 0x0609C7AA,r4
    c.r[0] = ld32(0x0609C7ACu);  // 0609C79A mov.l 0x0609C7AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C7A0u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C7A0u) return; }  // 0609C79C jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C7A0 add #8,r14
    c.r[15] = c.r[14];  // 0609C7A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C7A4 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C7A6 rts ; mov.l @r15+,r14
}

void f_0609C7B0(SH2Context& c) {
    ran[2503] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C7B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C7B2 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C7B4 add #-8,r15
    c.r[14] = c.r[15];  // 0609C7B6 mov r15,r14
    c.r[2] = 0x0u;  // 0609C7B8 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C7BA mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C7BC mov.l r2,@(4,r14)
    c.r[1] = 0x64u;  // 0609C7BE mov #100,r1
    st8(c.r[14], c.r[1]);  // 0609C7C0 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C7C2 mov r14,r1
    c.r[1] += 4;  // 0609C7C4 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C7C6 mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C7C8 mov r14,r1
    c.r[1] += 6;  // 0609C7CA add #6,r1
    st16(c.r[1], c.r[5]);  // 0609C7CC mov.w r5,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609C7E0u);  // 0609C7CE mov.w 0x0609C7E0,r4
    c.r[0] = ld32(0x0609C7E4u);  // 0609C7D0 mov.l 0x0609C7E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C7D6u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C7D6u) return; }  // 0609C7D2 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C7D6 add #8,r14
    c.r[15] = c.r[14];  // 0609C7D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C7DA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C7DC rts ; mov.l @r15+,r14
}

void f_0609C7E8(SH2Context& c) {
    ran[2504] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C7E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C7EA sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C7EC add #-8,r15
    c.r[14] = c.r[15];  // 0609C7EE mov r15,r14
    c.r[2] = 0x0u;  // 0609C7F0 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C7F2 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C7F4 mov.l r2,@(4,r14)
    c.r[1] = 0x65u;  // 0609C7F6 mov #101,r1
    st8(c.r[14], c.r[1]);  // 0609C7F8 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C7FA mov r14,r1
    c.r[1] += 1;  // 0609C7FC add #1,r1
    st8(c.r[1], c.r[7]);  // 0609C7FE mov.b r7,@r1
    c.r[1] = c.r[14];  // 0609C800 mov r14,r1
    c.r[1] += 2;  // 0609C802 add #2,r1
    st16(c.r[1], c.r[5]);  // 0609C804 mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609C806 mov r14,r1
    c.r[1] += 4;  // 0609C808 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C80A mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C80C mov r14,r1
    c.r[1] += 6;  // 0609C80E add #6,r1
    st16(c.r[1], c.r[6]);  // 0609C810 mov.w r6,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609C824u);  // 0609C812 mov.w 0x0609C824,r4
    c.r[0] = ld32(0x0609C828u);  // 0609C814 mov.l 0x0609C828,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C81Au; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C81Au) return; }  // 0609C816 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C81A add #8,r14
    c.r[15] = c.r[14];  // 0609C81C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C81E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C820 rts ; mov.l @r15+,r14
}

void f_0609C82C(SH2Context& c) {
    ran[2505] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C82C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C82E sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C830 add #-8,r15
    c.r[14] = c.r[15];  // 0609C832 mov r15,r14
    c.r[2] = 0x0u;  // 0609C834 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C836 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C838 mov.l r2,@(4,r14)
    c.r[1] = 0x66u;  // 0609C83A mov #102,r1
    st8(c.r[14], c.r[1]);  // 0609C83C mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C83E mov r14,r1
    c.r[1] += 1;  // 0609C840 add #1,r1
    st8(c.r[1], c.r[7]);  // 0609C842 mov.b r7,@r1
    c.r[1] = c.r[14];  // 0609C844 mov r14,r1
    c.r[1] += 2;  // 0609C846 add #2,r1
    st16(c.r[1], c.r[5]);  // 0609C848 mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609C84A mov r14,r1
    c.r[1] += 4;  // 0609C84C add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C84E mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609C850 mov r14,r1
    c.r[1] += 6;  // 0609C852 add #6,r1
    st16(c.r[1], c.r[6]);  // 0609C854 mov.w r6,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609C868u);  // 0609C856 mov.w 0x0609C868,r4
    c.r[0] = ld32(0x0609C86Cu);  // 0609C858 mov.l 0x0609C86C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609C85Eu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C85Eu) return; }  // 0609C85A jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C85E add #8,r14
    c.r[15] = c.r[14];  // 0609C860 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C862 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C864 rts ; mov.l @r15+,r14
}

void f_0609C870(SH2Context& c) {
    ran[2506] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C870 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C872 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C874 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C876 add #-16,r15
    c.r[14] = c.r[15];  // 0609C878 mov r15,r14
    c.r[8] = c.r[4];  // 0609C87A mov r4,r8
    c.r[2] = 0x0u;  // 0609C87C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C87E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C880 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609C882 mov r14,r6
    c.r[6] += 8;  // 0609C884 add #8,r6
    c.r[1] = 0x67u;  // 0609C886 mov #103,r1
    st8(c.r[14], c.r[1]);  // 0609C888 mov.b r1,@r14
    c.r[0] = ld32(0x0609C8A8u);  // 0609C88A mov.l 0x0609C8A8,r0
    c.r[5] = c.r[14];  // 0609C88C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609C892u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C892u) return; }  // 0609C88E jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609C892 mov r14,r1
    c.r[1] += 9;  // 0609C894 add #9,r1
    c.r[14] += 16;  // 0609C896 add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C898 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609C89A mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0609C89C extu.b r1,r1
    st32(c.r[8], c.r[1]);  // 0609C89E mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C8A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C8A2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C8A4 rts ; mov.l @r15+,r8
}

void f_0609C8AC(SH2Context& c) {
    ran[2507] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C8AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C8AE sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C8B0 add #-8,r15
    c.r[14] = c.r[15];  // 0609C8B2 mov r15,r14
    c.r[2] = 0x0u;  // 0609C8B4 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609C8B6 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609C8B8 mov.l r2,@(4,r14)
    st32(c.r[14], c.r[5]);  // 0609C8BA mov.l r5,@r14
    c.r[1] = 0x40u;  // 0609C8BC mov #64,r1
    st8(c.r[14], c.r[1]);  // 0609C8BE mov.b r1,@r14
    st32(c.r[14] + 4, c.r[6]);  // 0609C8C0 mov.l r6,@(4,r14)
    c.r[1] = c.r[14];  // 0609C8C2 mov r14,r1
    c.r[1] += 4;  // 0609C8C4 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C8C6 mov.b r4,@r1
    c.r[0] = ld32(0x0609C8DCu);  // 0609C8C8 mov.l 0x0609C8DC,r0
    c.r[5] = c.r[14];  // 0609C8CA mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609C8D0u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C8D0u) return; }  // 0609C8CC jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609C8D0 add #8,r14
    c.r[15] = c.r[14];  // 0609C8D2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C8D4 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C8D6 rts ; mov.l @r15+,r14
}

void f_0609C8E0(SH2Context& c) {
    ran[2508] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C8E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609C8E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609C8E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C8E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C8E8 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C8EA add #-16,r15
    c.r[14] = c.r[15];  // 0609C8EC mov r15,r14
    c.r[9] = c.r[5];  // 0609C8EE mov r5,r9
    c.r[10] = c.r[6];  // 0609C8F0 mov r6,r10
    c.r[3] = 0x0u;  // 0609C8F2 mov #0,r3
    st32(c.r[14], c.r[3]);  // 0609C8F4 mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 0609C8F6 mov.l r3,@(4,r14)
    c.r[8] = c.r[14];  // 0609C8F8 mov r14,r8
    c.r[8] += 8;  // 0609C8FA add #8,r8
    c.r[1] = 0x41u;  // 0609C8FC mov #65,r1
    st8(c.r[14], c.r[1]);  // 0609C8FE mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C900 mov r14,r1
    c.r[1] += 4;  // 0609C902 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C904 mov.b r4,@r1
    c.r[0] = ld32(0x0609C930u);  // 0609C906 mov.l 0x0609C930,r0
    c.r[6] = c.r[8];  // 0609C908 mov r8,r6
    c.r[5] = c.r[14];  // 0609C90A mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609C910u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C910u) return; }  // 0609C90C jsr @r0 ; mov #0,r4
    c.r[1] = ld32(c.r[8]);  // 0609C910 mov.l @r8,r1
    c.r[2] = ld32(0x0609C934u);  // 0609C912 mov.l 0x0609C934,r2
    c.r[1] &= c.r[2];  // 0609C914 and r2,r1
    st32(c.r[9], c.r[1]);  // 0609C916 mov.l r1,@r9
    c.r[1] = ld32(c.r[14] + 12);  // 0609C918 mov.l @(12,r14),r1
    c.r[1] &= c.r[2];  // 0609C91A and r2,r1
    st32(c.r[10], c.r[1]);  // 0609C91C mov.l r1,@r10
    c.r[14] += 16;  // 0609C91E add #16,r14
    c.r[15] = c.r[14];  // 0609C920 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C922 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609C924 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609C926 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609C928 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C92A rts ; mov.l @r15+,r8
}

void f_0609C938(SH2Context& c) {
    ran[2509] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C938 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C93A sts.l pr,@-r15
    c.r[15] -= 8;  // 0609C93C add #-8,r15
    c.r[14] = c.r[15];  // 0609C93E mov r15,r14
    c.r[3] = 0x0u;  // 0609C940 mov #0,r3
    st32(c.r[14], c.r[3]);  // 0609C942 mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 0609C944 mov.l r3,@(4,r14)
    c.r[1] = 0x42u;  // 0609C946 mov #66,r1
    st8(c.r[14], c.r[1]);  // 0609C948 mov.b r1,@r14
    c.r[2] = c.r[14];  // 0609C94A mov r14,r2
    c.r[2] += 1;  // 0609C94C add #1,r2
    c.r[1] = c.r[5];  // 0609C94E mov r5,r1
    c.r[1] += 1;  // 0609C950 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C952 mov.b @r1,r1
    c.r[0] = ld32(0x0609C9A4u);  // 0609C954 mov.l 0x0609C9A4,r0
    st8(c.r[2], c.r[1]);  // 0609C956 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0609C958 mov r14,r2
    c.r[1] = c.r[5];  // 0609C95A mov r5,r1
    c.r[1] += 2;  // 0609C95C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C95E mov.b @r1,r1
    c.r[2] += 2;  // 0609C960 add #2,r2
    st8(c.r[2], c.r[1]);  // 0609C962 mov.b r1,@r2
    c.r[2] = c.r[14];  // 0609C964 mov r14,r2
    c.r[1] = c.r[5];  // 0609C966 mov r5,r1
    c.r[1] += 4;  // 0609C968 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C96A mov.b @r1,r1
    c.r[2] += 3;  // 0609C96C add #3,r2
    st8(c.r[2], c.r[1]);  // 0609C96E mov.b r1,@r2
    c.r[1] = c.r[14];  // 0609C970 mov r14,r1
    c.r[1] += 4;  // 0609C972 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C974 mov.b r4,@r1
    c.r[2] = c.r[14];  // 0609C976 mov r14,r2
    c.r[2] += 5;  // 0609C978 add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0609C97A mov.b @r5,r1
    c.r[4] = 0x40u;  // 0609C97C mov #64,r4
    st8(c.r[2], c.r[1]);  // 0609C97E mov.b r1,@r2
    c.r[2] = c.r[14];  // 0609C980 mov r14,r2
    c.r[2] += 6;  // 0609C982 add #6,r2
    c.r[1] = c.r[5];  // 0609C984 mov r5,r1
    c.r[1] += 3;  // 0609C986 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C988 mov.b @r1,r1
    c.r[5] += 5;  // 0609C98A add #5,r5
    st8(c.r[2], c.r[1]);  // 0609C98C mov.b r1,@r2
    c.r[2] = c.r[14];  // 0609C98E mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0609C990 mov.b @r5,r1
    c.r[2] += 7;  // 0609C992 add #7,r2
    st8(c.r[2], c.r[1]);  // 0609C994 mov.b r1,@r2
    { const uint32_t x = c.r[0]; c.pr = 0x0609C99Au; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C99Au) return; }  // 0609C996 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 0609C99A add #8,r14
    c.r[15] = c.r[14];  // 0609C99C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609C99E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609C9A0 rts ; mov.l @r15+,r14
}

void f_0609C9A8(SH2Context& c) {
    ran[2510] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609C9A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609C9AA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609C9AC sts.l pr,@-r15
    c.r[15] -= 16;  // 0609C9AE add #-16,r15
    c.r[14] = c.r[15];  // 0609C9B0 mov r15,r14
    c.r[8] = c.r[5];  // 0609C9B2 mov r5,r8
    c.r[3] = 0x0u;  // 0609C9B4 mov #0,r3
    st32(c.r[14], c.r[3]);  // 0609C9B6 mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 0609C9B8 mov.l r3,@(4,r14)
    c.r[6] = c.r[14];  // 0609C9BA mov r14,r6
    c.r[6] += 8;  // 0609C9BC add #8,r6
    c.r[1] = 0x43u;  // 0609C9BE mov #67,r1
    st8(c.r[14], c.r[1]);  // 0609C9C0 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609C9C2 mov r14,r1
    c.r[1] += 4;  // 0609C9C4 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609C9C6 mov.b r4,@r1
    c.r[0] = ld32(0x0609CA20u);  // 0609C9C8 mov.l 0x0609CA20,r0
    c.r[5] = c.r[14];  // 0609C9CA mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609C9D0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609C9D0u) return; }  // 0609C9CC jsr @r0 ; mov #0,r4
    c.r[2] = c.r[8];  // 0609C9D0 mov r8,r2
    c.r[1] = c.r[14];  // 0609C9D2 mov r14,r1
    c.r[1] += 9;  // 0609C9D4 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C9D6 mov.b @r1,r1
    c.r[2] += 1;  // 0609C9D8 add #1,r2
    st8(c.r[2], c.r[1]);  // 0609C9DA mov.b r1,@r2
    c.r[2] = c.r[8];  // 0609C9DC mov r8,r2
    c.r[1] = c.r[14];  // 0609C9DE mov r14,r1
    c.r[1] += 10;  // 0609C9E0 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C9E2 mov.b @r1,r1
    c.r[2] += 2;  // 0609C9E4 add #2,r2
    st8(c.r[2], c.r[1]);  // 0609C9E6 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0609C9E8 mov r8,r2
    c.r[1] = c.r[14];  // 0609C9EA mov r14,r1
    c.r[1] += 11;  // 0609C9EC add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C9EE mov.b @r1,r1
    c.r[2] += 4;  // 0609C9F0 add #4,r2
    st8(c.r[2], c.r[1]);  // 0609C9F2 mov.b r1,@r2
    c.r[1] = c.r[14];  // 0609C9F4 mov r14,r1
    c.r[1] += 13;  // 0609C9F6 add #13,r1
    c.r[2] = c.r[8];  // 0609C9F8 mov r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609C9FA mov.b @r1,r1
    c.r[2] += 3;  // 0609C9FC add #3,r2
    st8(c.r[8], c.r[1]);  // 0609C9FE mov.b r1,@r8
    c.r[1] = c.r[14];  // 0609CA00 mov r14,r1
    c.r[1] += 14;  // 0609CA02 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CA04 mov.b @r1,r1
    c.r[8] += 5;  // 0609CA06 add #5,r8
    st8(c.r[2], c.r[1]);  // 0609CA08 mov.b r1,@r2
    c.r[1] = c.r[14];  // 0609CA0A mov r14,r1
    c.r[1] += 15;  // 0609CA0C add #15,r1
    c.r[14] += 16;  // 0609CA0E add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CA10 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609CA12 mov r14,r15
    st8(c.r[8], c.r[1]);  // 0609CA14 mov.b r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CA16 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CA18 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CA1A rts ; mov.l @r15+,r8
}

void f_0609CA24(SH2Context& c) {
    ran[2511] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CA24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CA26 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CA28 add #-8,r15
    c.r[14] = c.r[15];  // 0609CA2A mov r15,r14
    c.r[2] = 0x0u;  // 0609CA2C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CA2E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CA30 mov.l r2,@(4,r14)
    c.r[1] = 0x44u;  // 0609CA32 mov #68,r1
    st8(c.r[14], c.r[1]);  // 0609CA34 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CA36 mov r14,r1
    c.r[1] += 1;  // 0609CA38 add #1,r1
    st8(c.r[1], c.r[5]);  // 0609CA3A mov.b r5,@r1
    c.r[1] = c.r[14];  // 0609CA3C mov r14,r1
    c.r[1] += 4;  // 0609CA3E add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CA40 mov.b r4,@r1
    c.r[0] = ld32(0x0609CA54u);  // 0609CA42 mov.l 0x0609CA54,r0
    c.r[5] = c.r[14];  // 0609CA44 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CA4Au; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CA4Au) return; }  // 0609CA46 jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609CA4A add #8,r14
    c.r[15] = c.r[14];  // 0609CA4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CA4E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CA50 rts ; mov.l @r15+,r14
}

void f_0609CA58(SH2Context& c) {
    ran[2512] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CA58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CA5A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CA5C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CA5E add #-16,r15
    c.r[14] = c.r[15];  // 0609CA60 mov r15,r14
    c.r[8] = c.r[5];  // 0609CA62 mov r5,r8
    c.r[2] = 0x0u;  // 0609CA64 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CA66 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CA68 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609CA6A mov r14,r6
    c.r[6] += 8;  // 0609CA6C add #8,r6
    c.r[1] = 0x45u;  // 0609CA6E mov #69,r1
    st8(c.r[14], c.r[1]);  // 0609CA70 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CA72 mov r14,r1
    c.r[1] += 4;  // 0609CA74 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CA76 mov.b r4,@r1
    c.r[0] = ld32(0x0609CA98u);  // 0609CA78 mov.l 0x0609CA98,r0
    c.r[5] = c.r[14];  // 0609CA7A mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CA80u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CA80u) return; }  // 0609CA7C jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609CA80 mov r14,r1
    c.r[1] += 9;  // 0609CA82 add #9,r1
    c.r[14] += 16;  // 0609CA84 add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CA86 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609CA88 mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0609CA8A extu.b r1,r1
    st32(c.r[8], c.r[1]);  // 0609CA8C mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CA8E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CA90 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CA92 rts ; mov.l @r15+,r8
}

void f_0609CA9C(SH2Context& c) {
    ran[2513] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CA9C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CA9E sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CAA0 add #-8,r15
    c.r[14] = c.r[15];  // 0609CAA2 mov r15,r14
    c.r[2] = 0x0u;  // 0609CAA4 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CAA6 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CAA8 mov.l r2,@(4,r14)
    c.r[1] = 0x46u;  // 0609CAAA mov #70,r1
    st8(c.r[14], c.r[1]);  // 0609CAAC mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CAAE mov r14,r1
    c.r[1] += 1;  // 0609CAB0 add #1,r1
    st8(c.r[1], c.r[5]);  // 0609CAB2 mov.b r5,@r1
    c.r[1] = c.r[14];  // 0609CAB4 mov r14,r1
    c.r[1] += 2;  // 0609CAB6 add #2,r1
    st8(c.r[1], c.r[6]);  // 0609CAB8 mov.b r6,@r1
    c.r[1] = c.r[14];  // 0609CABA mov r14,r1
    c.r[1] += 3;  // 0609CABC add #3,r1
    st8(c.r[1], c.r[7]);  // 0609CABE mov.b r7,@r1
    c.r[1] = c.r[14];  // 0609CAC0 mov r14,r1
    c.r[1] += 4;  // 0609CAC2 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CAC4 mov.b r4,@r1
    c.r[0] = ld32(0x0609CAD8u);  // 0609CAC6 mov.l 0x0609CAD8,r0
    c.r[5] = c.r[14];  // 0609CAC8 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CACEu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CACEu) return; }  // 0609CACA jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609CACE add #8,r14
    c.r[15] = c.r[14];  // 0609CAD0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CAD2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CAD4 rts ; mov.l @r15+,r14
}

void f_0609CADC(SH2Context& c) {
    ran[2514] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CADC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CADE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CAE0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CAE2 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CAE4 add #-16,r15
    c.r[14] = c.r[15];  // 0609CAE6 mov r15,r14
    c.r[8] = c.r[5];  // 0609CAE8 mov r5,r8
    c.r[9] = c.r[6];  // 0609CAEA mov r6,r9
    c.r[2] = 0x0u;  // 0609CAEC mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CAEE mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CAF0 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609CAF2 mov r14,r6
    c.r[6] += 8;  // 0609CAF4 add #8,r6
    c.r[1] = 0x47u;  // 0609CAF6 mov #71,r1
    st8(c.r[14], c.r[1]);  // 0609CAF8 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CAFA mov r14,r1
    c.r[1] += 4;  // 0609CAFC add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CAFE mov.b r4,@r1
    c.r[0] = ld32(0x0609CB2Cu);  // 0609CB00 mov.l 0x0609CB2C,r0
    c.r[5] = c.r[14];  // 0609CB02 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CB08u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CB08u) return; }  // 0609CB04 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609CB08 mov r14,r1
    c.r[1] += 10;  // 0609CB0A add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CB0C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609CB0E extu.b r1,r1
    st32(c.r[8], c.r[1]);  // 0609CB10 mov.l r1,@r8
    c.r[1] = c.r[14];  // 0609CB12 mov r14,r1
    c.r[1] += 11;  // 0609CB14 add #11,r1
    c.r[14] += 16;  // 0609CB16 add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CB18 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609CB1A mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0609CB1C extu.b r1,r1
    st32(c.r[9], c.r[1]);  // 0609CB1E mov.l r1,@r9
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CB20 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CB22 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CB24 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CB26 rts ; mov.l @r15+,r8
}

void f_0609CB30(SH2Context& c) {
    ran[2515] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CB30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CB32 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CB34 add #-8,r15
    c.r[14] = c.r[15];  // 0609CB36 mov r15,r14
    c.r[2] = 0x0u;  // 0609CB38 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CB3A mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CB3C mov.l r2,@(4,r14)
    c.r[1] = 0x48u;  // 0609CB3E mov #72,r1
    st8(c.r[14], c.r[1]);  // 0609CB40 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CB42 mov r14,r1
    c.r[1] += 1;  // 0609CB44 add #1,r1
    st8(c.r[1], c.r[4]);  // 0609CB46 mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609CB48 mov r14,r1
    c.r[1] += 4;  // 0609CB4A add #4,r1
    st8(c.r[1], c.r[5]);  // 0609CB4C mov.b r5,@r1
    c.r[0] = ld32(0x0609CB60u);  // 0609CB4E mov.l 0x0609CB60,r0
    c.r[5] = c.r[14];  // 0609CB50 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CB56u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CB56u) return; }  // 0609CB52 jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609CB56 add #8,r14
    c.r[15] = c.r[14];  // 0609CB58 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CB5A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CB5C rts ; mov.l @r15+,r14
}

void f_0609CB64(SH2Context& c) {
    ran[2516] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CB64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CB66 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CB68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CB6A sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CB6C add #-8,r15
    c.r[14] = c.r[15];  // 0609CB6E mov r15,r14
    c.r[8] = c.r[4];  // 0609CB70 mov r4,r8
    c.r[3] = 0x0u;  // 0609CB72 mov #0,r3
    st32(c.r[14], c.r[3]);  // 0609CB74 mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 0609CB76 mov.l r3,@(4,r14)
    c.r[1] = 0x10u;  // 0609CB78 mov #16,r1
    st8(c.r[14], c.r[1]);  // 0609CB7A mov.b r1,@r14
    c.r[5] = c.r[14];  // 0609CB7C mov r14,r5
    c.r[9] = ld32(0x0609CBB0u);  // 0609CB7E mov.l 0x0609CBB0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0609CB84u; c.r[5] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CB84u) return; }  // 0609CB80 jsr @r9 ; add #1,r5
    c.r[2] = c.r[14];  // 0609CB84 mov r14,r2
    c.r[2] += 4;  // 0609CB86 add #4,r2
    c.r[1] = c.r[8];  // 0609CB88 mov r8,r1
    c.r[1] += 16;  // 0609CB8A add #16,r1
    c.r[5] = c.r[14];  // 0609CB8C mov r14,r5
    c.r[5] += 5;  // 0609CB8E add #5,r5
    c.r[8] += 8;  // 0609CB90 add #8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CB92 mov.b @r1,r1
    c.r[4] = c.r[8];  // 0609CB94 mov r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0609CB9Au; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CB9Au) return; }  // 0609CB96 jsr @r9 ; mov.b r1,@r2
    c.r[0] = ld32(0x0609CBB4u);  // 0609CB9A mov.l 0x0609CBB4,r0
    c.r[5] = c.r[14];  // 0609CB9C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CBA2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CBA2u) return; }  // 0609CB9E jsr @r0 ; mov #0,r4
    c.r[14] += 8;  // 0609CBA2 add #8,r14
    c.r[15] = c.r[14];  // 0609CBA4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CBA6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CBA8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CBAA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CBAC rts ; mov.l @r15+,r8
}

void f_0609CBB8(SH2Context& c) {
    ran[2517] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CBB8 mov.l r14,@-r15
    c.r[2] = ld32(c.r[4]);  // 0609CBBA mov.l @r4,r2
    c.r[1] = 0x3u;  // 0609CBBC mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0609CBBE cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609CC1A; } }  // 0609CBC0 bt/s 0x0609CC1A ; mov r15,r14
    c.r[1] = c.r[2];  // 0609CBC4 mov r2,r1
    c.r[1] += c.r[1];  // 0609CBC6 add r1,r1
    c.r[0] = 0x0609CBD4u;  // 0609CBC8 mova 0x0609CBD4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609CBCA mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0609CBCC add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0609CC1Au: goto L_0609CC1A; case 0x0609CBF6u: goto L_0609CBF6; case 0x0609CBDCu: goto L_0609CBDC; case 0x0609CC16u: goto L_0609CC16; default: sh2_call(c, x); return; } }  // 0609CBCE jmp @r0 ; nop
L_0609CBDC:
    c.r[1] = 0x0u;  // 0609CBDC mov #0,r1
    st8(c.r[5], c.r[1]);  // 0609CBDE mov.b r1,@r5
    c.r[2] = c.r[5];  // 0609CBE0 mov r5,r2
    c.r[1] = c.r[4];  // 0609CBE2 mov r4,r1
    c.r[1] += 4;  // 0609CBE4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CBE6 mov.b @r1,r1
    c.r[2] += 1;  // 0609CBE8 add #1,r2
    st8(c.r[2], c.r[1]);  // 0609CBEA mov.b r1,@r2
    c.r[2] = c.r[5];  // 0609CBEC mov r5,r2
    c.r[1] = c.r[4];  // 0609CBEE mov r4,r1
    c.r[1] += 5;  // 0609CBF0 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0609CC26;  // 0609CBF2 bra 0x0609CC26 ; mov.b @r1,r1
L_0609CBF6:
    c.r[1] = c.r[4];  // 0609CBF6 mov r4,r1
    c.r[1] += 5;  // 0609CBF8 add #5,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CBFA mov.b @r1,r0
    c.r[2] = c.r[5];  // 0609CBFC mov r5,r2
    c.r[0] |= 0x80u;  // 0609CBFE or #128,r0
    st8(c.r[5], c.r[0]);  // 0609CC00 mov.b r0,@r5
    c.r[1] = c.r[4];  // 0609CC02 mov r4,r1
    c.r[1] += 6;  // 0609CC04 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CC06 mov.b @r1,r1
    c.r[2] += 1;  // 0609CC08 add #1,r2
    st8(c.r[2], c.r[1]);  // 0609CC0A mov.b r1,@r2
    c.r[2] = c.r[5];  // 0609CC0C mov r5,r2
    c.r[1] = c.r[4];  // 0609CC0E mov r4,r1
    c.r[1] += 7;  // 0609CC10 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0609CC26;  // 0609CC12 bra 0x0609CC26 ; mov.b @r1,r1
L_0609CC16:
    c.r[1] = 0xFFFFFFFFu; goto L_0609CC1C;  // 0609CC16 bra 0x0609CC1C ; mov #-1,r1
L_0609CC1A:
    c.r[1] = 0x0u;  // 0609CC1A mov #0,r1
L_0609CC1C:
    st8(c.r[5], c.r[1]);  // 0609CC1C mov.b r1,@r5
    c.r[2] = c.r[5];  // 0609CC1E mov r5,r2
    c.r[2] += 1;  // 0609CC20 add #1,r2
    st8(c.r[2], c.r[1]);  // 0609CC22 mov.b r1,@r2
    c.r[2] = c.r[5];  // 0609CC24 mov r5,r2
L_0609CC26:
    c.r[2] += 2;  // 0609CC26 add #2,r2
    st8(c.r[2], c.r[1]);  // 0609CC28 mov.b r1,@r2
    c.r[15] = c.r[14];  // 0609CC2A mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CC2C rts ; mov.l @r15+,r14
}

void f_0609CC30(SH2Context& c) {
    ran[2518] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CC30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CC32 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CC34 add #-8,r15
    c.r[14] = c.r[15];  // 0609CC36 mov r15,r14
    c.r[2] = 0x0u;  // 0609CC38 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CC3A mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CC3C mov.l r2,@(4,r14)
    c.r[1] = 0x11u;  // 0609CC3E mov #17,r1
    st8(c.r[14], c.r[1]);  // 0609CC40 mov.b r1,@r14
    c.r[5] = c.r[14];  // 0609CC42 mov r14,r5
    c.r[1] = ld32(0x0609CC5Cu);  // 0609CC44 mov.l 0x0609CC5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609CC4Au; c.r[5] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CC4Au) return; }  // 0609CC46 jsr @r1 ; add #1,r5
    c.r[0] = ld32(0x0609CC60u);  // 0609CC4A mov.l 0x0609CC60,r0
    c.r[5] = c.r[14];  // 0609CC4C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CC52u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CC52u) return; }  // 0609CC4E jsr @r0 ; mov #0,r4
    c.r[14] += 8;  // 0609CC52 add #8,r14
    c.r[15] = c.r[14];  // 0609CC54 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CC56 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CC58 rts ; mov.l @r15+,r14
}

void f_0609CC64(SH2Context& c) {
    ran[2519] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CC64 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CC66 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CC68 add #-8,r15
    c.r[14] = c.r[15];  // 0609CC6A mov r15,r14
    c.r[2] = 0x0u;  // 0609CC6C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CC6E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CC70 mov.l r2,@(4,r14)
    c.r[1] = 0x12u;  // 0609CC72 mov #18,r1
    st8(c.r[14], c.r[1]);  // 0609CC74 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CC76 mov r14,r1
    c.r[1] += 1;  // 0609CC78 add #1,r1
    st8(c.r[1], c.r[4]);  // 0609CC7A mov.b r4,@r1
    c.r[0] = ld32(0x0609CC90u);  // 0609CC7C mov.l 0x0609CC90,r0
    c.r[5] = c.r[14];  // 0609CC7E mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CC84u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CC84u) return; }  // 0609CC80 jsr @r0 ; mov #0,r4
    c.r[14] += 8;  // 0609CC84 add #8,r14
    c.r[15] = c.r[14];  // 0609CC86 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CC88 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CC8A rts ; mov.l @r15+,r14
}

void f_0609CC94(SH2Context& c) {
    ran[2520] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CC94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CC96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609CC98 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CC9A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CC9C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CC9E add #-16,r15
    c.r[14] = c.r[15];  // 0609CCA0 mov r15,r14
    c.r[10] = c.r[4];  // 0609CCA2 mov r4,r10
    c.r[9] = c.r[5];  // 0609CCA4 mov r5,r9
    c.r[8] = c.r[6];  // 0609CCA6 mov r6,r8
    c.r[2] = 0x0u;  // 0609CCA8 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CCAA mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CCAC mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609CCAE mov r14,r6
    c.r[6] += 8;  // 0609CCB0 add #8,r6
    c.r[1] = 0x50u;  // 0609CCB2 mov #80,r1
    st8(c.r[14], c.r[1]);  // 0609CCB4 mov.b r1,@r14
    c.r[0] = ld32(0x0609CCECu);  // 0609CCB6 mov.l 0x0609CCEC,r0
    c.r[5] = c.r[14];  // 0609CCB8 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CCBEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CCBEu) return; }  // 0609CCBA jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609CCBE mov r14,r1
    c.r[1] += 10;  // 0609CCC0 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609CCC2 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609CCC4 extu.w r1,r1
    st32(c.r[8], c.r[1]);  // 0609CCC6 mov.l r1,@r8
    c.r[1] = c.r[14];  // 0609CCC8 mov r14,r1
    c.r[1] += 12;  // 0609CCCA add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CCCC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609CCCE extu.b r1,r1
    st32(c.r[9], c.r[1]);  // 0609CCD0 mov.l r1,@r9
    c.r[1] = c.r[14];  // 0609CCD2 mov r14,r1
    c.r[1] += 14;  // 0609CCD4 add #14,r1
    c.r[14] += 16;  // 0609CCD6 add #16,r14
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609CCD8 mov.w @r1,r1
    c.r[15] = c.r[14];  // 0609CCDA mov r14,r15
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609CCDC extu.w r1,r1
    st32(c.r[10], c.r[1]);  // 0609CCDE mov.l r1,@r10
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CCE0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CCE2 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609CCE4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CCE6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CCE8 rts ; mov.l @r15+,r8
}

void f_0609CCF0(SH2Context& c) {
    ran[2521] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CCF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CCF2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CCF4 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CCF6 add #-16,r15
    c.r[14] = c.r[15];  // 0609CCF8 mov r15,r14
    c.r[8] = c.r[5];  // 0609CCFA mov r5,r8
    c.r[2] = 0x0u;  // 0609CCFC mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CCFE mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CD00 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609CD02 mov r14,r6
    c.r[6] += 8;  // 0609CD04 add #8,r6
    c.r[1] = 0x51u;  // 0609CD06 mov #81,r1
    st8(c.r[14], c.r[1]);  // 0609CD08 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CD0A mov r14,r1
    c.r[1] += 4;  // 0609CD0C add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CD0E mov.b r4,@r1
    c.r[0] = ld32(0x0609CD30u);  // 0609CD10 mov.l 0x0609CD30,r0
    c.r[5] = c.r[14];  // 0609CD12 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CD18u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CD18u) return; }  // 0609CD14 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609CD18 mov r14,r1
    c.r[1] += 14;  // 0609CD1A add #14,r1
    c.r[14] += 16;  // 0609CD1C add #16,r14
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609CD1E mov.w @r1,r1
    c.r[15] = c.r[14];  // 0609CD20 mov r14,r15
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609CD22 extu.w r1,r1
    st32(c.r[8], c.r[1]);  // 0609CD24 mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CD26 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CD28 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CD2A rts ; mov.l @r15+,r8
}

void f_0609CD34(SH2Context& c) {
    ran[2522] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CD34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CD36 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CD38 add #-8,r15
    c.r[14] = c.r[15];  // 0609CD3A mov r15,r14
    c.r[2] = 0x0u;  // 0609CD3C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CD3E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CD40 mov.l r2,@(4,r14)
    c.r[1] = 0x52u;  // 0609CD42 mov #82,r1
    st8(c.r[14], c.r[1]);  // 0609CD44 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CD46 mov r14,r1
    c.r[1] += 2;  // 0609CD48 add #2,r1
    st16(c.r[1], c.r[5]);  // 0609CD4A mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609CD4C mov r14,r1
    c.r[1] += 4;  // 0609CD4E add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CD50 mov.b r4,@r1
    c.r[1] = c.r[14];  // 0609CD52 mov r14,r1
    c.r[1] += 6;  // 0609CD54 add #6,r1
    st16(c.r[1], c.r[6]);  // 0609CD56 mov.w r6,@r1
    c.r[0] = ld32(0x0609CD6Cu);  // 0609CD58 mov.l 0x0609CD6C,r0
    c.r[5] = c.r[14];  // 0609CD5A mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CD60u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CD60u) return; }  // 0609CD5C jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609CD60 add #8,r14
    c.r[15] = c.r[14];  // 0609CD62 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CD64 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CD66 rts ; mov.l @r15+,r14
}

void f_0609CD70(SH2Context& c) {
    ran[2523] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CD70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CD72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CD74 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CD76 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CD78 add #-16,r15
    c.r[14] = c.r[15];  // 0609CD7A mov r15,r14
    c.r[9] = c.r[4];  // 0609CD7C mov r4,r9
    c.r[3] = 0x0u;  // 0609CD7E mov #0,r3
    st32(c.r[14], c.r[3]);  // 0609CD80 mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 0609CD82 mov.l r3,@(4,r14)
    c.r[8] = c.r[14];  // 0609CD84 mov r14,r8
    c.r[8] += 8;  // 0609CD86 add #8,r8
    c.r[1] = 0x53u;  // 0609CD88 mov #83,r1
    st8(c.r[14], c.r[1]);  // 0609CD8A mov.b r1,@r14
    c.r[0] = ld32(0x0609CDACu);  // 0609CD8C mov.l 0x0609CDAC,r0
    c.r[5] = c.r[8];  // 0609CD8E mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CD94u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CD94u) return; }  // 0609CD90 jsr @r0 ; mov r14,r4
    c.r[2] = ld32(0x0609CDB0u);  // 0609CD94 mov.l 0x0609CDB0,r2
    c.r[14] += 16;  // 0609CD96 add #16,r14
    c.r[1] = ld32(c.r[8]);  // 0609CD98 mov.l @r8,r1
    c.r[15] = c.r[14];  // 0609CD9A mov r14,r15
    c.r[1] &= c.r[2];  // 0609CD9C and r2,r1
    st32(c.r[9], c.r[1]);  // 0609CD9E mov.l r1,@r9
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CDA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CDA2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CDA4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CDA6 rts ; mov.l @r15+,r8
}

void f_0609CDB4(SH2Context& c) {
    ran[2524] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CDB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CDB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CDB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CDBA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609CDBC mov r15,r14
    c.r[9] = c.r[4];  // 0609CDBE mov r4,r9
    c.r[0] = ld32(0x0609CDE8u);  // 0609CDC0 mov.l 0x0609CDE8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609CDC6u; c.r[8] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CDC6u) return; }  // 0609CDC2 jsr @r0 ; mov r5,r8
    c.r[0] &= 0x40u;  // 0609CDC6 and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609CDC8 tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_0609CDDA; } }  // 0609CDCA bt/s 0x0609CDDA ; mov r8,r6
    c.r[0] = ld32(0x0609CDECu);  // 0609CDCE mov.l 0x0609CDEC,r0
    c.r[5] = c.r[9];  // 0609CDD0 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CDD6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CDD6u) return; }  // 0609CDD2 jsr @r0 ; mov #0,r4
    c.r[15] = c.r[14]; goto L_0609CDDE;  // 0609CDD6 bra 0x0609CDDE ; mov r14,r15
L_0609CDDA:
    c.r[0] = 0xFFFFFFFFu;  // 0609CDDA mov #-1,r0
    c.r[15] = c.r[14];  // 0609CDDC mov r14,r15
L_0609CDDE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CDDE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CDE0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CDE2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CDE4 rts ; mov.l @r15+,r8
}

void f_0609CDF0(SH2Context& c) {
    ran[2525] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CDF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CDF2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CDF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CDF6 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CDF8 add #-16,r15
    c.r[14] = c.r[15];  // 0609CDFA mov r15,r14
    c.r[8] = c.r[6];  // 0609CDFC mov r6,r8
    c.r[3] = 0x0u;  // 0609CDFE mov #0,r3
    st32(c.r[14], c.r[3]);  // 0609CE00 mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 0609CE02 mov.l r3,@(4,r14)
    c.r[9] = c.r[14];  // 0609CE04 mov r14,r9
    c.r[9] += 8;  // 0609CE06 add #8,r9
    c.r[1] = 0x54u;  // 0609CE08 mov #84,r1
    st8(c.r[14], c.r[1]);  // 0609CE0A mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CE0C mov r14,r1
    c.r[1] += 2;  // 0609CE0E add #2,r1
    st16(c.r[1], c.r[5]);  // 0609CE10 mov.w r5,@r1
    c.r[1] = c.r[14];  // 0609CE12 mov r14,r1
    c.r[1] += 4;  // 0609CE14 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CE16 mov.b r4,@r1
    c.r[0] = ld32(0x0609CE68u);  // 0609CE18 mov.l 0x0609CE68,r0
    c.r[6] = c.r[9];  // 0609CE1A mov r9,r6
    c.r[5] = c.r[14];  // 0609CE1C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CE22u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CE22u) return; }  // 0609CE1E jsr @r0 ; mov #0,r4
    c.r[1] = ld32(c.r[9]);  // 0609CE22 mov.l @r9,r1
    c.r[2] = ld32(0x0609CE6Cu);  // 0609CE24 mov.l 0x0609CE6C,r2
    c.r[1] &= c.r[2];  // 0609CE26 and r2,r1
    st32(c.r[8], c.r[1]);  // 0609CE28 mov.l r1,@r8
    c.r[2] = c.r[8];  // 0609CE2A mov r8,r2
    c.r[1] = c.r[14];  // 0609CE2C mov r14,r1
    c.r[1] += 12;  // 0609CE2E add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CE30 mov.b @r1,r1
    c.r[2] += 4;  // 0609CE32 add #4,r2
    st8(c.r[2], c.r[1]);  // 0609CE34 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0609CE36 mov r8,r2
    c.r[1] = c.r[14];  // 0609CE38 mov r14,r1
    c.r[1] += 13;  // 0609CE3A add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CE3C mov.b @r1,r1
    c.r[2] += 5;  // 0609CE3E add #5,r2
    st8(c.r[2], c.r[1]);  // 0609CE40 mov.b r1,@r2
    c.r[2] = c.r[8];  // 0609CE42 mov r8,r2
    c.r[2] += 6;  // 0609CE44 add #6,r2
    c.r[1] = c.r[14];  // 0609CE46 mov r14,r1
    c.r[1] += 14;  // 0609CE48 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CE4A mov.b @r1,r1
    c.r[8] += 7;  // 0609CE4C add #7,r8
    st8(c.r[2], c.r[1]);  // 0609CE4E mov.b r1,@r2
    c.r[1] = c.r[14];  // 0609CE50 mov r14,r1
    c.r[1] += 15;  // 0609CE52 add #15,r1
    c.r[14] += 16;  // 0609CE54 add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CE56 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609CE58 mov r14,r15
    st8(c.r[8], c.r[1]);  // 0609CE5A mov.b r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CE5C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CE5E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CE60 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CE62 rts ; mov.l @r15+,r8
}

void f_0609CE70(SH2Context& c) {
    ran[2526] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CE70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CE72 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CE74 add #-8,r15
    c.r[14] = c.r[15];  // 0609CE76 mov r15,r14
    c.r[2] = 0x0u;  // 0609CE78 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CE7A mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CE7C mov.l r2,@(4,r14)
    c.r[1] = 0x55u;  // 0609CE7E mov #85,r1
    st8(c.r[14], c.r[1]);  // 0609CE80 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CE82 mov r14,r1
    c.r[1] += 2;  // 0609CE84 add #2,r1
    st16(c.r[1], c.r[5]);  // 0609CE86 mov.w r5,@r1
    st32(c.r[14] + 4, c.r[6]);  // 0609CE88 mov.l r6,@(4,r14)
    c.r[1] = c.r[14];  // 0609CE8A mov r14,r1
    c.r[1] += 4;  // 0609CE8C add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CE8E mov.b r4,@r1
    c.r[0] = ld32(0x0609CEA4u);  // 0609CE90 mov.l 0x0609CEA4,r0
    c.r[5] = c.r[14];  // 0609CE92 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CE98u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CE98u) return; }  // 0609CE94 jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609CE98 add #8,r14
    c.r[15] = c.r[14];  // 0609CE9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CE9C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CE9E rts ; mov.l @r15+,r14
}

void f_0609CEA8(SH2Context& c) {
    ran[2527] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CEA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CEAA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609CEAC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CEAE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CEB0 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CEB2 add #-16,r15
    c.r[14] = c.r[15];  // 0609CEB4 mov r15,r14
    c.r[9] = c.r[4];  // 0609CEB6 mov r4,r9
    c.r[8] = c.r[5];  // 0609CEB8 mov r5,r8
    c.r[10] = c.r[6];  // 0609CEBA mov r6,r10
    c.r[7] = 0x0u;  // 0609CEBC mov #0,r7
    st32(c.r[14], c.r[7]);  // 0609CEBE mov.l r7,@r14
    st32(c.r[14] + 4, c.r[7]);  // 0609CEC0 mov.l r7,@(4,r14)
    c.r[5] = c.r[14];  // 0609CEC2 mov r14,r5
    c.r[5] += 8;  // 0609CEC4 add #8,r5
    c.r[1] = 0x56u;  // 0609CEC6 mov #86,r1
    st8(c.r[14], c.r[1]);  // 0609CEC8 mov.b r1,@r14
    c.r[0] = ld32(0x0609CEFCu);  // 0609CECA mov.l 0x0609CEFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609CED0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CED0u) return; }  // 0609CECC jsr @r0 ; mov r14,r4
    c.r[1] = c.r[14];  // 0609CED0 mov r14,r1
    c.r[1] += 10;  // 0609CED2 add #10,r1
    c.r[3] = c.r[14];  // 0609CED4 mov r14,r3
    c.r[3] += 12;  // 0609CED6 add #12,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609CED8 mov.w @r1,r1
    c.r[2] = ld32(0x0609CF00u);  // 0609CEDA mov.l 0x0609CF00,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609CEDC extu.w r1,r1
    st32(c.r[8], c.r[1]);  // 0609CEDE mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609CEE0 mov.b @r3,r1
    c.r[14] += 16;  // 0609CEE2 add #16,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0609CEE4 extu.b r1,r1
    st32(c.r[9], c.r[1]);  // 0609CEE6 mov.l r1,@r9
    c.r[1] = ld32(c.r[3]);  // 0609CEE8 mov.l @r3,r1
    c.r[15] = c.r[14];  // 0609CEEA mov r14,r15
    c.r[1] &= c.r[2];  // 0609CEEC and r2,r1
    st32(c.r[10], c.r[1]);  // 0609CEEE mov.l r1,@r10
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CEF0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CEF2 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609CEF4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609CEF6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CEF8 rts ; mov.l @r15+,r8
}

void f_0609CF04(SH2Context& c) {
    ran[2528] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CF04 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CF06 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609CF08 add #-8,r15
    c.r[14] = c.r[15];  // 0609CF0A mov r15,r14
    c.r[2] = 0x0u;  // 0609CF0C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CF0E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CF10 mov.l r2,@(4,r14)
    c.r[1] = 0x30u;  // 0609CF12 mov #48,r1
    st8(c.r[14], c.r[1]);  // 0609CF14 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0609CF16 mov r14,r1
    c.r[1] += 4;  // 0609CF18 add #4,r1
    st8(c.r[1], c.r[4]);  // 0609CF1A mov.b r4,@r1
    c.r[0] = ld32(0x0609CF30u);  // 0609CF1C mov.l 0x0609CF30,r0
    c.r[5] = c.r[14];  // 0609CF1E mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CF24u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CF24u) return; }  // 0609CF20 jsr @r0 ; mov #64,r4
    c.r[14] += 8;  // 0609CF24 add #8,r14
    c.r[15] = c.r[14];  // 0609CF26 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CF28 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CF2A rts ; mov.l @r15+,r14
}

void f_0609CF34(SH2Context& c) {
    ran[2529] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CF34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CF36 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CF38 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CF3A add #-16,r15
    c.r[14] = c.r[15];  // 0609CF3C mov r15,r14
    c.r[8] = c.r[4];  // 0609CF3E mov r4,r8
    c.r[2] = 0x0u;  // 0609CF40 mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CF42 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CF44 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609CF46 mov r14,r6
    c.r[6] += 8;  // 0609CF48 add #8,r6
    c.r[1] = 0x31u;  // 0609CF4A mov #49,r1
    st8(c.r[14], c.r[1]);  // 0609CF4C mov.b r1,@r14
    c.r[0] = ld32(0x0609CF6Cu);  // 0609CF4E mov.l 0x0609CF6C,r0
    c.r[5] = c.r[14];  // 0609CF50 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CF56u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CF56u) return; }  // 0609CF52 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609CF56 mov r14,r1
    c.r[1] += 12;  // 0609CF58 add #12,r1
    c.r[14] += 16;  // 0609CF5A add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CF5C mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609CF5E mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0609CF60 extu.b r1,r1
    st32(c.r[8], c.r[1]);  // 0609CF62 mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CF64 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CF66 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CF68 rts ; mov.l @r15+,r8
}

void f_0609CF70(SH2Context& c) {
    ran[2530] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CF70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CF72 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CF74 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609CF76 add #-16,r15
    c.r[14] = c.r[15];  // 0609CF78 mov r15,r14
    c.r[8] = c.r[4];  // 0609CF7A mov r4,r8
    c.r[2] = 0x0u;  // 0609CF7C mov #0,r2
    st32(c.r[14], c.r[2]);  // 0609CF7E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 0609CF80 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 0609CF82 mov r14,r6
    c.r[6] += 8;  // 0609CF84 add #8,r6
    c.r[1] = 0x32u;  // 0609CF86 mov #50,r1
    st8(c.r[14], c.r[1]);  // 0609CF88 mov.b r1,@r14
    c.r[0] = ld32(0x0609CFA8u);  // 0609CF8A mov.l 0x0609CFA8,r0
    c.r[5] = c.r[14];  // 0609CF8C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609CF92u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CF92u) return; }  // 0609CF8E jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 0609CF92 mov r14,r1
    c.r[1] += 12;  // 0609CF94 add #12,r1
    c.r[14] += 16;  // 0609CF96 add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609CF98 mov.b @r1,r1
    c.r[15] = c.r[14];  // 0609CF9A mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0609CF9C extu.b r1,r1
    st32(c.r[8], c.r[1]);  // 0609CF9E mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609CFA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609CFA2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CFA4 rts ; mov.l @r15+,r8
}

void f_0609CFAC(SH2Context& c) {
    ran[2531] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CFAC mov.l r14,@-r15
    c.r[1] = c.r[4];  // 0609CFAE mov r4,r1
    c.r[1] &= c.r[6];  // 0609CFB0 and r6,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 0609CFB2 cmp/gt r6,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609CFC2; } }  // 0609CFB4 bt/s 0x0609CFC2 ; mov r15,r14
L_0609CFB8:
    st32(c.r[4], c.r[5]);  // 0609CFB8 mov.l r5,@r4
    c.r[1] += 4;  // 0609CFBA add #4,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 0609CFBC cmp/gt r6,r1
    { const bool k = !c.t; c.r[4] += 4; if (k) { SH2_POLL(c); goto L_0609CFB8; } }  // 0609CFBE bf/s 0x0609CFB8 ; add #4,r4
L_0609CFC2:
    c.r[15] = c.r[14];  // 0609CFC2 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609CFC4 rts ; mov.l @r15+,r14
}

void f_0609CFC8(SH2Context& c) {
    ran[2532] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609CFC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609CFCA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609CFCC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609CFCE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609CFD0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609CFD2 mov r15,r14
    c.r[10] = ld32(0x0609D014u);  // 0609CFD4 mov.l 0x0609D014,r10
    c.r[5] = 0x1u;  // 0609CFD6 mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0609CFDCu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CFDCu) return; }  // 0609CFD8 jsr @r10 ; mov #4,r4
    c.r[2] = ld32(0x0609D018u);  // 0609CFDC mov.l 0x0609D018,r2
    c.r[1] = 0x2u;  // 0609CFDE mov #2,r1
    st8(c.r[2], c.r[1]);  // 0609CFE0 mov.b r1,@r2
    c.r[8] = ld32(0x0609D01Cu);  // 0609CFE2 mov.l 0x0609D01C,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609D00Eu);  // 0609CFE4 mov.w 0x0609D00E,r6
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609D010u);  // 0609CFE6 mov.w 0x0609D010,r9
    c.r[1] = ld32(0x0609D020u);  // 0609CFE8 mov.l 0x0609D020,r1
    c.r[5] = c.r[9];  // 0609CFEA mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609CFF0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609CFF0u) return; }  // 0609CFEC jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0609D024u);  // 0609CFF0 mov.l 0x0609D024,r1
    st32(c.r[8], c.r[1]);  // 0609CFF2 mov.l r1,@r8
    c.r[8] += c.r[9];  // 0609CFF4 add r9,r8
    c.r[1] = ld32(0x0609D028u);  // 0609CFF6 mov.l 0x0609D028,r1
    st32(c.r[8], c.r[1]);  // 0609CFF8 mov.l r1,@r8
    c.r[5] = 0x1u;  // 0609CFFA mov #1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0609D000u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D000u) return; }  // 0609CFFC jsr @r10 ; mov #3,r4
    c.r[15] = c.r[14];  // 0609D000 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D002 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D004 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D006 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D008 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D00A rts ; mov.l @r15+,r8
}

void f_0609D02C(SH2Context& c) {
    ran[2533] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D02C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D02E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D030 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609D032 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609D034 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609D036 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D038 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D03A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609D03C mov r15,r14
    c.r[13] = c.r[5];  // 0609D03E mov r5,r13
    c.r[8] = c.r[4] & 0xFFFFu;  // 0609D040 extu.w r4,r8
    c.r[9] = (uint32_t)(int32_t)(int8_t)c.r[6];  // 0609D042 exts.b r6,r9
    c.r[12] = 0x0u;  // 0609D044 mov #0,r12
    c.r[0] = ld32(0x0609D124u);  // 0609D046 mov.l 0x0609D124,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D04Cu; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D04Cu) return; }  // 0609D048 jsr @r0 ; mov #15,r4
    c.r[10] = ld32(0x0609D128u);  // 0609D04C mov.l 0x0609D128,r10
    c.r[1] = 0x0u;  // 0609D04E mov #0,r1
    st8(c.r[10], c.r[1]);  // 0609D050 mov.b r1,@r10
    c.r[2] = 0x1Fu;  // 0609D052 mov #31,r2
    c.r[2] &= c.r[8];  // 0609D054 and r8,r2
    c.r[8] = c.r[2];  // 0609D056 mov r2,r8
    c.r[1] = ld32(0x0609D12Cu);  // 0609D058 mov.l 0x0609D12C,r1
    c.r[2] >>= 2;  // 0609D05A shlr2 r2
    c.r[0] = 0x1u;  // 0609D05C mov #1,r0
    c.r[1] = ld32(c.r[1]);  // 0609D05E mov.l @r1,r1
    c.r[2] &= c.r[0];  // 0609D060 and r0,r2
    c.t = c.r[1] == c.r[2];  // 0609D062 cmp/eq r2,r1
    if (c.t) { goto L_0609D070; }  // 0609D064 bt 0x0609D070
    c.r[1] = ld32(0x0609D130u);  // 0609D066 mov.l 0x0609D130,r1
    c.r[1] = ld32(c.r[1]);  // 0609D068 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D06Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D06Eu) return; }  // 0609D06A jsr @r1 ; mov r2,r4
    c.r[12] = 0x1u;  // 0609D06E mov #1,r12
L_0609D070:
    c.r[1] = ld32(0x0609D134u);  // 0609D070 mov.l 0x0609D134,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D076u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D076u) return; }  // 0609D072 jsr @r1 ; nop
    c.r[11] = ld32(0x0609D138u);  // 0609D076 mov.l 0x0609D138,r11
    c.r[5] = 0x0u;  // 0609D078 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0609D07Eu; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D07Eu) return; }  // 0609D07A jsr @r11 ; mov #11,r4
    c.r[1] = ld32(0x0609D13Cu);  // 0609D07E mov.l 0x0609D13C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D084u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D084u) return; }  // 0609D080 jsr @r1 ; nop
    c.r[1] = ld32(0x0609D140u);  // 0609D084 mov.l 0x0609D140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D08Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D08Au) return; }  // 0609D086 jsr @r1 ; nop
    c.r[0] = ld32(0x0609D144u);  // 0609D08A mov.l 0x0609D144,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D090u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D090u) return; }  // 0609D08C jsr @r0 ; mov r8,r4
    c.r[2] = ld32(0x0609D148u);  // 0609D090 mov.l 0x0609D148,r2
    c.r[1] = ld32(0x0609D14Cu);  // 0609D092 mov.l 0x0609D14C,r1
    st32(c.r[2], c.r[1]);  // 0609D094 mov.l r1,@r2
    c.r[5] = c.r[9];  // 0609D096 mov r9,r5
    c.r[0] = ld32(0x0609D150u);  // 0609D098 mov.l 0x0609D150,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D09Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D09Eu) return; }  // 0609D09A jsr @r0 ; mov r8,r4
    c.r[5] = c.r[13];  // 0609D09E mov r13,r5
    c.r[0] = ld32(0x0609D154u);  // 0609D0A0 mov.l 0x0609D154,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D0A6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0A6u) return; }  // 0609D0A2 jsr @r0 ; mov r8,r4
    c.r[2] = ld32(0x0609D158u);  // 0609D0A6 mov.l 0x0609D158,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609D11Eu);  // 0609D0A8 mov.w 0x0609D11E,r1
    st16(c.r[2], c.r[1]);  // 0609D0AA mov.w r1,@r2
    c.r[1] = ld32(0x0609D15Cu);  // 0609D0AC mov.l 0x0609D15C,r1
    c.r[1] = ld32(c.r[1]);  // 0609D0AE mov.l @r1,r1
    c.r[4] = ld32(0x0609D160u);  // 0609D0B0 mov.l 0x0609D160,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0609D0B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0B6u) return; }  // 0609D0B2 jsr @r1 ; nop
    c.r[1] = ld32(0x0609D164u);  // 0609D0B6 mov.l 0x0609D164,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609D120u);  // 0609D0B8 mov.w 0x0609D120,r4
    c.r[1] = ld32(c.r[1]);  // 0609D0BA mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D0C0u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0C0u) return; }  // 0609D0BC jsr @r1 ; mov #0,r5
    c.r[2] = ld32(0x0609D168u);  // 0609D0C0 mov.l 0x0609D168,r2
    c.r[1] = 0x5u;  // 0609D0C2 mov #5,r1
    st8(c.r[2], c.r[1]);  // 0609D0C4 mov.b r1,@r2
    c.r[1] = 0x7Fu;  // 0609D0C6 mov #127,r1
    c.r[4] = 0x0u;  // 0609D0C8 mov #0,r4
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0609D0CA mov.b @r10,r9
    c.r[0] = ld32(0x0609D124u);  // 0609D0CC mov.l 0x0609D124,r0
    c.r[1] &= c.r[9];  // 0609D0CE and r9,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0609D0D4u; st8(c.r[10], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0D4u) return; }  // 0609D0D0 jsr @r0 ; mov.b r1,@r10
    c.r[0] = c.r[12];  // 0609D0D4 mov r12,r0
    c.t = c.r[0] == 0x1u;  // 0609D0D6 cmp/eq #1,r0
    if (!c.t) { goto L_0609D0E0; }  // 0609D0D8 bf 0x0609D0E0
    c.r[1] = ld32(0x0609D16Cu);  // 0609D0DA mov.l 0x0609D16C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D0E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0E0u) return; }  // 0609D0DC jsr @r1 ; nop
L_0609D0E0:
    c.r[1] = ld32(0x0609D170u);  // 0609D0E0 mov.l 0x0609D170,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D0E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0E6u) return; }  // 0609D0E2 jsr @r1 ; nop
    c.r[5] = 0x0u;  // 0609D0E6 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0609D0ECu; c.r[4] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0ECu) return; }  // 0609D0E8 jsr @r11 ; mov #13,r4
    c.r[8] = ld32(0x0609D174u);  // 0609D0EC mov.l 0x0609D174,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609D0F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0F2u) return; }  // 0609D0EE jsr @r8 ; nop
    c.r[5] = 0x0u;  // 0609D0F2 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0609D0F8u; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0F8u) return; }  // 0609D0F4 jsr @r11 ; mov #14,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0609D0FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D0FCu) return; }  // 0609D0F8 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0609D100u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D100u) return; }  // 0609D0FC jsr @r8 ; nop
    c.r[1] = 0xFFFFFF80u;  // 0609D100 mov #-128,r1
    c.r[9] &= c.r[1];  // 0609D102 and r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0609D104 mov.b @r10,r1
    c.r[15] = c.r[14];  // 0609D106 mov r14,r15
    c.r[9] |= c.r[1];  // 0609D108 or r1,r9
    st8(c.r[10], c.r[9]);  // 0609D10A mov.b r9,@r10
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D10C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D10E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609D110 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609D112 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609D114 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D116 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D118 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D11A rts ; mov.l @r15+,r8
}

void f_0609D178(SH2Context& c) {
    ran[2534] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D178 mov.l r14,@-r15
    c.r[15] -= 16;  // 0609D17A add #-16,r15
    c.r[14] = c.r[15];  // 0609D17C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609D17E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609D180 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0609D182 mov.l @r14,r1
    c.r[2] = 0xFFFFFFFCu;  // 0609D184 mov #-4,r2
    c.r[1] &= c.r[2];  // 0609D186 and r2,r1
    st32(c.r[14] + 8, c.r[1]);  // 0609D188 mov.l r1,@(8,r14)
    c.r[2] = ld32(c.r[14]);  // 0609D18A mov.l @r14,r2
    c.r[1] = 0x3u;  // 0609D18C mov #3,r1
    c.r[1] &= c.r[2];  // 0609D18E and r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D190 mov.l @(4,r14),r2
    c.r[3] = c.r[2];  // 0609D192 mov r2,r3
    c.r[3] -= c.r[1];  // 0609D194 sub r1,r3
    c.r[1] = c.r[3];  // 0609D196 mov r3,r1
    c.r[2] = c.r[1];  // 0609D198 mov r1,r2
    c.r[2] >>= 2;  // 0609D19A shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0609D19C shlr r2
    st32(c.r[14] + 12, c.r[2]);  // 0609D19E mov.l r2,@(12,r14)
    c.r[1] = ld32(0x0609D1BCu);  // 0609D1A0 mov.l 0x0609D1BC,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D1A2 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D1A4 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609D1A6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D1A8 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D1AA mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609D1AC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0609D1AE mov.l @(12,r14),r2
    st32(c.r[1] + 4, c.r[2]);  // 0609D1B0 mov.l r2,@(4,r1)
    c.r[14] += 16;  // 0609D1B2 add #16,r14
    c.r[15] = c.r[14];  // 0609D1B4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D1B6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609D1B8 rts ; nop
}

void f_0609D1C0(SH2Context& c) {
    ran[2535] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D1C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D1C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D1C4 sts.l pr,@-r15
    c.r[15] -= 20;  // 0609D1C6 add #-20,r15
    c.r[14] = c.r[15];  // 0609D1C8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609D1CA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609D1CC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0609D1CE mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D1D0 mov.l @(4,r14),r2
    c.macl = c.r[1] * c.r[2];  // 0609D1D2 mul.l r2,r1
    c.r[1] = c.macl;  // 0609D1D4 sts macl,r1
    st32(c.r[14] + 8, c.r[1]);  // 0609D1D6 mov.l r1,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609D1D8 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 0609D1DA mov r1,r4
    c.r[8] = ld32(0x0609D230u);  // 0609D1DC mov.l 0x0609D230,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609D1E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D1E2u) return; }  // 0609D1DE jsr @r8 ; nop
    c.r[1] = c.r[0];  // 0609D1E2 mov r0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0609D1E4 mov.l r1,@(12,r14)
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D1E6 tst r1,r1
    if (!c.t) { goto L_0609D1F4; }  // 0609D1E8 bf 0x0609D1F4
    c.r[0] = 0x0u;  // 0609D1EA mov #0,r0
    goto L_0609D222;  // 0609D1EC bra 0x0609D222 ; nop
L_0609D1F4:
    c.r[1] = 0x0u;  // 0609D1F4 mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 0609D1F6 mov.l r1,@(16,r14)
L_0609D1F8:
    c.r[1] = ld32(c.r[14] + 16);  // 0609D1F8 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D1FA mov.l @(8,r14),r2
    c.t = c.r[1] >= c.r[2];  // 0609D1FC cmp/hs r2,r1
    if (!c.t) { goto L_0609D204; }  // 0609D1FE bf 0x0609D204
    goto L_0609D21C;  // 0609D200 bra 0x0609D21C ; nop
L_0609D204:
    c.r[1] = ld32(c.r[14] + 12);  // 0609D204 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0609D206 mov.l @(16,r14),r2
    c.r[1] += c.r[2];  // 0609D208 add r2,r1
    c.r[2] = 0x0u;  // 0609D20A mov #0,r2
    st8(c.r[1], c.r[2]);  // 0609D20C mov.b r2,@r1
    c.r[2] = ld32(c.r[14] + 16);  // 0609D20E mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 0609D210 mov r2,r1
    c.r[1] += 1;  // 0609D212 add #1,r1
    c.r[2] = c.r[1];  // 0609D214 mov r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 0609D216 mov.l r2,@(16,r14)
    SH2_POLL(c); goto L_0609D1F8;  // 0609D218 bra 0x0609D1F8 ; nop
L_0609D21C:
    c.r[0] = ld32(c.r[14] + 12);  // 0609D21C mov.l @(12,r14),r0
    goto L_0609D222;  // 0609D21E bra 0x0609D222 ; nop
L_0609D222:
    c.r[14] += 20;  // 0609D222 add #20,r14
    c.r[15] = c.r[14];  // 0609D224 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D226 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D228 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609D22A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609D22C rts ; nop
}

void f_0609D234(SH2Context& c) {
    ran[2536] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D234 mov.l r14,@-r15
    c.r[15] -= 12;  // 0609D236 add #-12,r15
    c.r[14] = c.r[15];  // 0609D238 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609D23A mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0609D23C mov.l @r14,r1
    c.r[2] = c.r[1];  // 0609D23E mov r1,r2
    c.r[2] -= 8;  // 0609D240 add #-8,r2
    st32(c.r[14] + 8, c.r[2]);  // 0609D242 mov.l r2,@(8,r14)
    c.r[1] = ld32(0x0609D32Cu);  // 0609D244 mov.l 0x0609D32C,r1
    c.r[2] = ld32(c.r[1]);  // 0609D246 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609D248 mov.l r2,@(4,r14)
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609D24A tst r2,r2
    if (!c.t) { goto L_0609D25E; }  // 0609D24C bf 0x0609D25E
    c.r[1] = ld32(0x0609D32Cu);  // 0609D24E mov.l 0x0609D32C,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D250 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D252 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609D254 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D256 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D258 mov.l r2,@r1
    goto L_0609D320;  // 0609D25A bra 0x0609D320 ; nop
L_0609D25E:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D25E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D260 mov.l @(4,r14),r2
    c.t = c.r[1] > c.r[2];  // 0609D262 cmp/hi r2,r1
    if (!c.t) { goto L_0609D274; }  // 0609D264 bf 0x0609D274
    c.r[1] = ld32(c.r[14] + 4);  // 0609D266 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D268 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0609D26A mov.l @r1,r1
    c.t = c.r[2] >= c.r[1];  // 0609D26C cmp/hs r1,r2
    if (c.t) { goto L_0609D274; }  // 0609D26E bt 0x0609D274
    goto L_0609D2A2;  // 0609D270 bra 0x0609D2A2 ; nop
L_0609D274:
    c.r[1] = ld32(c.r[14] + 4);  // 0609D274 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D276 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0609D278 mov.l @r1,r1
    c.t = c.r[2] >= c.r[1];  // 0609D27A cmp/hs r1,r2
    if (!c.t) { goto L_0609D298; }  // 0609D27C bf 0x0609D298
    c.r[1] = ld32(c.r[14] + 8);  // 0609D27E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D280 mov.l @(4,r14),r2
    c.t = c.r[1] > c.r[2];  // 0609D282 cmp/hi r2,r1
    if (c.t) { goto L_0609D294; }  // 0609D284 bt 0x0609D294
    c.r[1] = ld32(c.r[14] + 4);  // 0609D286 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D288 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0609D28A mov.l @r1,r1
    c.t = c.r[2] >= c.r[1];  // 0609D28C cmp/hs r1,r2
    if (!c.t) { goto L_0609D294; }  // 0609D28E bf 0x0609D294
    goto L_0609D298;  // 0609D290 bra 0x0609D298 ; nop
L_0609D294:
    goto L_0609D2A2;  // 0609D294 bra 0x0609D2A2 ; nop
L_0609D298:
    c.r[1] = ld32(c.r[14] + 4);  // 0609D298 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0609D29A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609D29C mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0609D25E;  // 0609D29E bra 0x0609D25E ; nop
L_0609D2A2:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D2A2 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609D2A4 mov.l @(4,r1),r2
    c.r[1] = c.r[2];  // 0609D2A6 mov r2,r1
    c.r[2] = c.r[1];  // 0609D2A8 mov r1,r2
    c.r[2] <<= 2;  // 0609D2AA shll2 r2
    c.r[2] += c.r[2];  // 0609D2AC add r2,r2
    c.r[3] = ld32(c.r[14] + 8);  // 0609D2AE mov.l @(8,r14),r3
    c.r[1] = c.r[2];  // 0609D2B0 mov r2,r1
    c.r[1] += c.r[3];  // 0609D2B2 add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D2B4 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0609D2B6 mov.l @r2,r3
    c.t = c.r[1] == c.r[3];  // 0609D2B8 cmp/eq r3,r1
    if (!c.t) { goto L_0609D2DA; }  // 0609D2BA bf 0x0609D2DA
    c.r[1] = ld32(c.r[14] + 8);  // 0609D2BC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D2BE mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 0609D2C0 mov.l @(4,r14),r3
    c.r[7] = ld32(c.r[3]);  // 0609D2C2 mov.l @r3,r7
    c.r[2] = ld32(c.r[2] + 4);  // 0609D2C4 mov.l @(4,r2),r2
    c.r[3] = ld32(c.r[7] + 4);  // 0609D2C6 mov.l @(4,r7),r3
    c.r[2] += c.r[3];  // 0609D2C8 add r3,r2
    st32(c.r[1] + 4, c.r[2]);  // 0609D2CA mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0609D2CC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D2CE mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0609D2D0 mov.l @r2,r3
    c.r[2] = ld32(c.r[3]);  // 0609D2D2 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0609D2D4 mov.l r2,@r1
    goto L_0609D2E2;  // 0609D2D6 bra 0x0609D2E2 ; nop
L_0609D2DA:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D2DA mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D2DC mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0609D2DE mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0609D2E0 mov.l r3,@r1
L_0609D2E2:
    c.r[1] = ld32(c.r[14] + 4);  // 0609D2E2 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609D2E4 mov.l @(4,r1),r2
    c.r[1] = c.r[2];  // 0609D2E6 mov r2,r1
    c.r[2] = c.r[1];  // 0609D2E8 mov r1,r2
    c.r[2] <<= 2;  // 0609D2EA shll2 r2
    c.r[2] += c.r[2];  // 0609D2EC add r2,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0609D2EE mov.l @(4,r14),r3
    c.r[1] = c.r[2];  // 0609D2F0 mov r2,r1
    c.r[1] += c.r[3];  // 0609D2F2 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D2F4 mov.l @(8,r14),r2
    c.t = c.r[1] == c.r[2];  // 0609D2F6 cmp/eq r2,r1
    if (!c.t) { goto L_0609D314; }  // 0609D2F8 bf 0x0609D314
    c.r[1] = ld32(c.r[14] + 4);  // 0609D2FA mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D2FC mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 8);  // 0609D2FE mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[2] + 4);  // 0609D300 mov.l @(4,r2),r2
    c.r[3] = ld32(c.r[3] + 4);  // 0609D302 mov.l @(4,r3),r3
    c.r[2] += c.r[3];  // 0609D304 add r3,r2
    st32(c.r[1] + 4, c.r[2]);  // 0609D306 mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0609D308 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D30A mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0609D30C mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0609D30E mov.l r3,@r1
    goto L_0609D31A;  // 0609D310 bra 0x0609D31A ; nop
L_0609D314:
    c.r[1] = ld32(c.r[14] + 4);  // 0609D314 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D316 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D318 mov.l r2,@r1
L_0609D31A:
    c.r[1] = ld32(0x0609D32Cu);  // 0609D31A mov.l 0x0609D32C,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D31C mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D31E mov.l r2,@r1
L_0609D320:
    c.r[14] += 12;  // 0609D320 add #12,r14
    c.r[15] = c.r[14];  // 0609D322 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D324 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609D326 rts ; nop
}

void f_0609D330(SH2Context& c) {
    ran[2537] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D330 mov.l r14,@-r15
    c.r[15] -= 20;  // 0609D332 add #-20,r15
    c.r[14] = c.r[15];  // 0609D334 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609D336 mov.l r4,@r14
    c.r[2] = ld32(c.r[14]);  // 0609D338 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0609D33A mov r2,r1
    c.r[1] += 7;  // 0609D33C add #7,r1
    c.r[2] = c.r[1];  // 0609D33E mov r1,r2
    c.r[2] >>= 2;  // 0609D340 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0609D342 shlr r2
    c.r[1] = c.r[2];  // 0609D344 mov r2,r1
    c.r[1] += 1;  // 0609D346 add #1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609D348 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0609D3FCu);  // 0609D34A mov.l 0x0609D3FC,r1
    c.r[2] = ld32(c.r[1]);  // 0609D34C mov.l @r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 0609D34E mov.l r2,@(12,r14)
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609D350 tst r2,r2
    if (!c.t) { goto L_0609D35E; }  // 0609D352 bf 0x0609D35E
    c.r[0] = 0x0u;  // 0609D354 mov #0,r0
    goto L_0609D3F0;  // 0609D356 bra 0x0609D3F0 ; nop
L_0609D35E:
    c.r[1] = ld32(c.r[14] + 12);  // 0609D35E mov.l @(12,r14),r1
    st32(c.r[14] + 16, c.r[1]);  // 0609D360 mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609D362 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0609D364 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0609D366 mov.l r2,@(8,r14)
L_0609D368:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D368 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609D36A mov.l @(4,r1),r2
    c.r[1] = ld32(c.r[14] + 4);  // 0609D36C mov.l @(4,r14),r1
    c.t = c.r[2] >= c.r[1];  // 0609D36E cmp/hs r1,r2
    if (!c.t) { goto L_0609D3D4; }  // 0609D370 bf 0x0609D3D4
    c.r[1] = ld32(c.r[14] + 8);  // 0609D372 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609D374 mov.l @(4,r1),r2
    c.r[1] = ld32(c.r[14] + 4);  // 0609D376 mov.l @(4,r14),r1
    c.t = c.r[2] == c.r[1];  // 0609D378 cmp/eq r1,r2
    if (!c.t) { goto L_0609D398; }  // 0609D37A bf 0x0609D398
    c.r[1] = ld32(c.r[14] + 12);  // 0609D37C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D37E mov.l @(8,r14),r2
    c.t = c.r[1] == c.r[2];  // 0609D380 cmp/eq r2,r1
    if (!c.t) { goto L_0609D38C; }  // 0609D382 bf 0x0609D38C
    c.r[1] = 0x0u;  // 0609D384 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0609D386 mov.l r1,@(12,r14)
    goto L_0609D394;  // 0609D388 bra 0x0609D394 ; nop
L_0609D38C:
    c.r[1] = ld32(c.r[14] + 12);  // 0609D38C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D38E mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0609D390 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0609D392 mov.l r3,@r1
L_0609D394:
    goto L_0609D3BC;  // 0609D394 bra 0x0609D3BC ; nop
L_0609D398:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D398 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D39A mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2] + 4);  // 0609D39C mov.l @(4,r2),r3
    c.r[2] = ld32(c.r[14] + 4);  // 0609D39E mov.l @(4,r14),r2
    c.r[3] -= c.r[2];  // 0609D3A0 sub r2,r3
    st32(c.r[1] + 4, c.r[3]);  // 0609D3A2 mov.l r3,@(4,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0609D3A4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609D3A6 mov.l @(4,r1),r2
    c.r[1] = c.r[2];  // 0609D3A8 mov r2,r1
    c.r[2] = c.r[1];  // 0609D3AA mov r1,r2
    c.r[2] <<= 2;  // 0609D3AC shll2 r2
    c.r[2] += c.r[2];  // 0609D3AE add r2,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0609D3B0 mov.l @(8,r14),r1
    c.r[2] += c.r[1];  // 0609D3B2 add r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0609D3B4 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609D3B6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609D3B8 mov.l @(4,r14),r2
    st32(c.r[1] + 4, c.r[2]);  // 0609D3BA mov.l r2,@(4,r1)
L_0609D3BC:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D3BC mov.l @(8,r14),r1
    c.r[2] = 0x0u;  // 0609D3BE mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609D3C0 mov.l r2,@r1
    c.r[1] = ld32(0x0609D3FCu);  // 0609D3C2 mov.l 0x0609D3FC,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0609D3C4 mov.l @(12,r14),r2
    st32(c.r[1], c.r[2]);  // 0609D3C6 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609D3C8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0609D3CA mov r2,r1
    c.r[1] += 8;  // 0609D3CC add #8,r1
    c.r[0] = c.r[1];  // 0609D3CE mov r1,r0
    goto L_0609D3F0;  // 0609D3D0 bra 0x0609D3F0 ; nop
L_0609D3D4:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D3D4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0609D3D6 mov.l @(16,r14),r2
    c.t = c.r[1] == c.r[2];  // 0609D3D8 cmp/eq r2,r1
    if (!c.t) { goto L_0609D3E2; }  // 0609D3DA bf 0x0609D3E2
    c.r[0] = 0x0u;  // 0609D3DC mov #0,r0
    goto L_0609D3F0;  // 0609D3DE bra 0x0609D3F0 ; nop
L_0609D3E2:
    c.r[1] = ld32(c.r[14] + 8);  // 0609D3E2 mov.l @(8,r14),r1
    st32(c.r[14] + 12, c.r[1]);  // 0609D3E4 mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609D3E6 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0609D3E8 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0609D3EA mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_0609D368;  // 0609D3EC bra 0x0609D368 ; nop
L_0609D3F0:
    c.r[14] += 20;  // 0609D3F0 add #20,r14
    c.r[15] = c.r[14];  // 0609D3F2 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D3F4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609D3F6 rts ; nop
}

void f_0609D400(SH2Context& c) {
    ran[2538] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D400 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D402 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D404 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609D406 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609D408 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609D40A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D40C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D40E sts.l pr,@-r15
    c.r[15] -= 8;  // 0609D410 add #-8,r15
    st32(c.r[15], c.r[4]);  // 0609D412 mov.l r4,@r15
    st32(c.r[15] + 4, c.r[5]);  // 0609D414 mov.l r5,@(4,r15)
    c.r[14] = c.r[6];  // 0609D416 mov r6,r14
    c.r[13] = ld32(0x0609D4B8u);  // 0609D418 mov.l 0x0609D4B8,r13
    c.r[12] = 0x0u;  // 0609D41A mov #0,r12
    st32(c.r[13], c.r[12]);  // 0609D41C mov.l r12,@r13
    c.r[7] = ld32(0x0609D4BCu);  // 0609D41E mov.l 0x0609D4BC,r7
    st32(c.r[7], c.r[12]);  // 0609D420 mov.l r12,@r7
    c.r[9] = ld32(0x0609D4C0u);  // 0609D422 mov.l 0x0609D4C0,r9
    st32(c.r[9], c.r[12]);  // 0609D424 mov.l r12,@r9
    c.r[8] = ld32(0x0609D4C4u);  // 0609D426 mov.l 0x0609D4C4,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609D4B2u);  // 0609D428 mov.w 0x0609D4B2,r5
    c.r[10] = ld32(0x0609D4C8u);  // 0609D42A mov.l 0x0609D4C8,r10
    c.r[4] = ld32(c.r[15]);  // 0609D42C mov.l @r15,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0609D432u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D432u) return; }  // 0609D42E jsr @r10 ; mov #0,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609D432 tst r0,r0
    { const bool k = c.t; st32(c.r[8], c.r[0]); if (k) { goto L_0609D49C; } }  // 0609D434 bt/s 0x0609D49C ; mov.l r0,@r8
    c.r[11] = ld32(0x0609D4CCu);  // 0609D438 mov.l 0x0609D4CC,r11
    c.r[6] = 0x0u;  // 0609D43A mov #0,r6
    c.r[4] = ld32(c.r[15] + 4);  // 0609D43C mov.l @(4,r15),r4
    { const uint32_t x = c.r[10]; c.pr = 0x0609D442u; c.r[5] = 0x64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D442u) return; }  // 0609D43E jsr @r10 ; mov #100,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609D442 tst r0,r0
    { const bool k = c.t; st32(c.r[11], c.r[0]); if (k) { goto L_0609D490; } }  // 0609D444 bt/s 0x0609D490 ; mov.l r0,@r11
    c.r[8] = ld32(0x0609D4D0u);  // 0609D448 mov.l 0x0609D4D0,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609D4B4u);  // 0609D44A mov.w 0x0609D4B4,r5
    c.r[6] = 0x0u;  // 0609D44C mov #0,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0609D452u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D452u) return; }  // 0609D44E jsr @r10 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609D452 tst r0,r0
    { const bool k = c.t; st32(c.r[8], c.r[0]); if (k) { goto L_0609D488; } }  // 0609D454 bt/s 0x0609D488 ; mov.l r0,@r8
    c.r[7] = ld32(c.r[15] + 4);  // 0609D458 mov.l @(4,r15),r7
    st32(c.r[13], c.r[7]);  // 0609D45A mov.l r7,@r13
    c.r[7] = ld32(c.r[15]);  // 0609D45C mov.l @r15,r7
    c.r[9] = ld32(0x0609D4BCu);  // 0609D45E mov.l 0x0609D4BC,r9
    st32(c.r[9], c.r[7]);  // 0609D460 mov.l r7,@r9
    c.r[9] = ld32(0x0609D4C0u);  // 0609D462 mov.l 0x0609D4C0,r9
    st32(c.r[9], c.r[14]);  // 0609D464 mov.l r14,@r9
    c.r[7] = ld32(c.r[15] + 4);  // 0609D466 mov.l @(4,r15),r7
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[7];  // 0609D468 cmp/ge r7,r12
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_0609D484; } }  // 0609D46A bt/s 0x0609D484 ; mov #0,r3
    c.r[4] = c.r[11];  // 0609D46E mov r11,r4
    c.r[6] = 0x0u;  // 0609D470 mov #0,r6
    c.r[5] = c.r[13];  // 0609D472 mov r13,r5
    c.r[2] = 0x0u;  // 0609D474 mov #0,r2
L_0609D476:
    c.r[0] = ld32(c.r[4]);  // 0609D476 mov.l @r4,r0
    c.r[3] += 1;  // 0609D478 add #1,r3
    st32(c.r[0] + c.r[2], c.r[6]);  // 0609D47A mov.l r6,@(r0,r2)
    c.r[1] = ld32(c.r[5]);  // 0609D47C mov.l @r5,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D47E cmp/ge r1,r3
    { const bool k = !c.t; c.r[2] += 100; if (k) { SH2_POLL(c); goto L_0609D476; } }  // 0609D480 bf/s 0x0609D476 ; add #100,r2
L_0609D484:
    c.r[0] = 0x0u; goto L_0609D49E;  // 0609D484 bra 0x0609D49E ; mov #0,r0
L_0609D488:
    c.r[1] = ld32(0x0609D4D4u);  // 0609D488 mov.l 0x0609D4D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D48Eu; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D48Eu) return; }  // 0609D48A jsr @r1 ; mov.l @r11,r4
    st32(c.r[11], c.r[12]);  // 0609D48E mov.l r12,@r11
L_0609D490:
    c.r[8] = ld32(0x0609D4C4u);  // 0609D490 mov.l 0x0609D4C4,r8
    c.r[1] = ld32(0x0609D4D4u);  // 0609D492 mov.l 0x0609D4D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D498u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D498u) return; }  // 0609D494 jsr @r1 ; mov.l @r8,r4
    c.r[1] = 0x0u;  // 0609D498 mov #0,r1
    st32(c.r[8], c.r[1]);  // 0609D49A mov.l r1,@r8
L_0609D49C:
    c.r[0] = 0xFFFFFFFFu;  // 0609D49C mov #-1,r0
L_0609D49E:
    c.r[15] += 8;  // 0609D49E add #8,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D4A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D4A2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609D4A4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609D4A6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609D4A8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D4AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D4AC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D4AE rts ; mov.l @r15+,r8
}

void f_0609D4D8(SH2Context& c) {
    ran[2539] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D4D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D4DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D4DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609D4DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D4E0 sts.l pr,@-r15
    c.r[1] = ld32(0x0609D52Cu);  // 0609D4E2 mov.l 0x0609D52C,r1
    c.r[8] = 0x0u;  // 0609D4E4 mov #0,r8
    st32(c.r[1], c.r[8]);  // 0609D4E6 mov.l r8,@r1
    c.r[1] = ld32(0x0609D530u);  // 0609D4E8 mov.l 0x0609D530,r1
    st32(c.r[1], c.r[8]);  // 0609D4EA mov.l r8,@r1
    c.r[1] = ld32(0x0609D534u);  // 0609D4EC mov.l 0x0609D534,r1
    st32(c.r[1], c.r[8]);  // 0609D4EE mov.l r8,@r1
    c.r[11] = ld32(0x0609D538u);  // 0609D4F0 mov.l 0x0609D538,r11
    c.r[4] = ld32(c.r[11]);  // 0609D4F2 mov.l @r11,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609D4F4 tst r4,r4
    if (c.t) { goto L_0609D4FE; }  // 0609D4F6 bt 0x0609D4FE
    c.r[1] = ld32(0x0609D53Cu);  // 0609D4F8 mov.l 0x0609D53C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D4FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D4FEu) return; }  // 0609D4FA jsr @r1 ; nop
L_0609D4FE:
    c.r[10] = ld32(0x0609D540u);  // 0609D4FE mov.l 0x0609D540,r10
    c.r[4] = ld32(c.r[10]);  // 0609D500 mov.l @r10,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609D502 tst r4,r4
    if (c.t) { goto L_0609D50C; }  // 0609D504 bt 0x0609D50C
    c.r[1] = ld32(0x0609D53Cu);  // 0609D506 mov.l 0x0609D53C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D50Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D50Cu) return; }  // 0609D508 jsr @r1 ; nop
L_0609D50C:
    c.r[9] = ld32(0x0609D544u);  // 0609D50C mov.l 0x0609D544,r9
    c.r[4] = ld32(c.r[9]);  // 0609D50E mov.l @r9,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609D510 tst r4,r4
    if (c.t) { goto L_0609D51A; }  // 0609D512 bt 0x0609D51A
    c.r[1] = ld32(0x0609D53Cu);  // 0609D514 mov.l 0x0609D53C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D51Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D51Au) return; }  // 0609D516 jsr @r1 ; nop
L_0609D51A:
    st32(c.r[11], c.r[8]);  // 0609D51A mov.l r8,@r11
    st32(c.r[10], c.r[8]);  // 0609D51C mov.l r8,@r10
    st32(c.r[9], c.r[8]);  // 0609D51E mov.l r8,@r9
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D520 lds.l @r15+,pr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609D522 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D524 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D526 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D528 rts ; mov.l @r15+,r8
}

void f_0609D548(SH2Context& c) {
    ran[2540] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D548 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D54A sts.l pr,@-r15
    c.r[1] = ld32(0x0609D5A4u);  // 0609D54C mov.l 0x0609D5A4,r1
    c.r[8] = ld32(c.r[1]);  // 0609D54E mov.l @r1,r8
    c.r[1] = ld32(0x0609D5A8u);  // 0609D550 mov.l 0x0609D5A8,r1
    c.r[1] = ld32(c.r[1]);  // 0609D552 mov.l @r1,r1
    c.r[3] = 0x0u;  // 0609D554 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D556 cmp/ge r1,r3
    if (c.t) { goto L_0609D572; }  // 0609D558 bt 0x0609D572
    c.r[6] = c.r[1];  // 0609D55A mov r1,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609D5A0u);  // 0609D55C mov.w 0x0609D5A0,r7
    c.r[2] = c.r[8];  // 0609D55E mov r8,r2
    c.r[2] += 112;  // 0609D560 add #112,r2
L_0609D562:
    c.r[1] = ld32(c.r[2]);  // 0609D562 mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D564 tst r1,r1
    if (c.t) { goto L_0609D572; }  // 0609D566 bt 0x0609D572
    c.r[3] += 1;  // 0609D568 add #1,r3
    c.r[2] += c.r[7];  // 0609D56A add r7,r2
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[6];  // 0609D56C cmp/ge r6,r3
    { const bool k = !c.t; c.r[8] += c.r[7]; if (k) { SH2_POLL(c); goto L_0609D562; } }  // 0609D56E bf/s 0x0609D562 ; add r7,r8
L_0609D572:
    c.r[1] = ld32(0x0609D5A8u);  // 0609D572 mov.l 0x0609D5A8,r1
    c.r[1] = ld32(c.r[1]);  // 0609D574 mov.l @r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D576 cmp/ge r1,r3
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609D59A; } }  // 0609D578 bt/s 0x0609D59A ; mov #0,r0
    c.r[0] = ld32(0x0609D5ACu);  // 0609D57C mov.l 0x0609D5AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D582u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D582u) return; }  // 0609D57E jsr @r0 ; nop
    c.r[1] = c.r[8];  // 0609D582 mov r8,r1
    c.r[1] += 108;  // 0609D584 add #108,r1
    c.t = (int32_t)c.r[0] >= 0;  // 0609D586 cmp/pz r0
    { const bool k = !c.t; st32(c.r[1], c.r[0]); if (k) { goto L_0609D598; } }  // 0609D588 bf/s 0x0609D598 ; mov.l r0,@r1
    c.r[2] = c.r[8];  // 0609D58C mov r8,r2
    c.r[2] += 112;  // 0609D58E add #112,r2
    c.r[1] = 0x2u;  // 0609D590 mov #2,r1
    st32(c.r[2], c.r[1]);  // 0609D592 mov.l r1,@r2
    c.r[0] = c.r[8]; goto L_0609D59A;  // 0609D594 bra 0x0609D59A ; mov r8,r0
L_0609D598:
    c.r[0] = 0x0u;  // 0609D598 mov #0,r0
L_0609D59A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D59A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D59C rts ; mov.l @r15+,r8
}

void f_0609D5B0(SH2Context& c) {
    ran[2541] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D5B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D5B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D5B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D5B6 sts.l pr,@-r15
    c.r[1] = ld32(0x0609D640u);  // 0609D5B8 mov.l 0x0609D640,r1
    c.r[8] = ld32(c.r[1]);  // 0609D5BA mov.l @r1,r8
    c.r[1] = ld32(0x0609D644u);  // 0609D5BC mov.l 0x0609D644,r1
    c.r[1] = ld32(c.r[1]);  // 0609D5BE mov.l @r1,r1
    c.r[3] = 0x0u;  // 0609D5C0 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D5C2 cmp/ge r1,r3
    { const bool k = c.t; c.r[10] = c.r[5]; if (k) { goto L_0609D5E0; } }  // 0609D5C4 bt/s 0x0609D5E0 ; mov r5,r10
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609D63Cu);  // 0609D5C8 mov.w 0x0609D63C,r7
    c.r[6] = c.r[1];  // 0609D5CA mov r1,r6
    c.r[2] = c.r[8];  // 0609D5CC mov r8,r2
    c.r[2] += 112;  // 0609D5CE add #112,r2
L_0609D5D0:
    c.r[1] = ld32(c.r[2]);  // 0609D5D0 mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D5D2 tst r1,r1
    if (c.t) { goto L_0609D5E0; }  // 0609D5D4 bt 0x0609D5E0
    c.r[3] += 1;  // 0609D5D6 add #1,r3
    c.r[2] += c.r[7];  // 0609D5D8 add r7,r2
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[6];  // 0609D5DA cmp/ge r6,r3
    { const bool k = !c.t; c.r[8] += c.r[7]; if (k) { SH2_POLL(c); goto L_0609D5D0; } }  // 0609D5DC bf/s 0x0609D5D0 ; add r7,r8
L_0609D5E0:
    c.r[1] = ld32(0x0609D644u);  // 0609D5E0 mov.l 0x0609D644,r1
    c.r[1] = ld32(c.r[1]);  // 0609D5E2 mov.l @r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D5E4 cmp/ge r1,r3
    if (c.t) { goto L_0609D5F8; }  // 0609D5E6 bt 0x0609D5F8
    c.r[0] = ld32(0x0609D648u);  // 0609D5E8 mov.l 0x0609D648,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D5EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D5EEu) return; }  // 0609D5EA jsr @r0 ; nop
    c.r[1] = c.r[8];  // 0609D5EE mov r8,r1
    c.r[1] += 108;  // 0609D5F0 add #108,r1
    c.t = (int32_t)c.r[0] >= 0;  // 0609D5F2 cmp/pz r0
    { const bool k = c.t; st32(c.r[1], c.r[0]); if (k) { goto L_0609D5FC; } }  // 0609D5F4 bt/s 0x0609D5FC ; mov.l r0,@r1
L_0609D5F8:
    c.r[8] = 0x0u; goto L_0609D604;  // 0609D5F8 bra 0x0609D604 ; mov #0,r8
L_0609D5FC:
    c.r[2] = c.r[8];  // 0609D5FC mov r8,r2
    c.r[2] += 112;  // 0609D5FE add #112,r2
    c.r[1] = 0x2u;  // 0609D600 mov #2,r1
    st32(c.r[2], c.r[1]);  // 0609D602 mov.l r1,@r2
L_0609D604:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609D604 tst r8,r8
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_0609D630; } }  // 0609D606 bt/s 0x0609D630 ; mov r10,r5
    c.r[0] = ld32(0x0609D64Cu);  // 0609D60A mov.l 0x0609D64C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D610u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D610u) return; }  // 0609D60C jsr @r0 ; mov r8,r4
    c.r[9] = c.r[0];  // 0609D610 mov r0,r9
    c.t = (int32_t)c.r[9] >= 0;  // 0609D612 cmp/pz r9
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0609D622; } }  // 0609D614 bt/s 0x0609D622 ; tst r10,r10
    c.r[1] = ld32(0x0609D650u);  // 0609D618 mov.l 0x0609D650,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D61Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D61Eu) return; }  // 0609D61A jsr @r1 ; mov r8,r4
    c.r[0] = c.r[9]; goto L_0609D632;  // 0609D61E bra 0x0609D632 ; mov r9,r0
L_0609D622:
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_0609D62C; } }  // 0609D622 bt/s 0x0609D62C ; mov r10,r5
    c.r[1] = ld32(0x0609D654u);  // 0609D626 mov.l 0x0609D654,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D62Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D62Cu) return; }  // 0609D628 jsr @r1 ; mov r8,r4
L_0609D62C:
    c.r[0] = c.r[8]; goto L_0609D632;  // 0609D62C bra 0x0609D632 ; mov r8,r0
L_0609D630:
    c.r[0] = 0x0u;  // 0609D630 mov #0,r0
L_0609D632:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D632 lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D634 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D636 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D638 rts ; mov.l @r15+,r8
}

void f_0609D658(SH2Context& c) {
    ran[2542] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D658 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D65A sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609D65C mov r4,r8
    c.r[1] = c.r[8];  // 0609D65E mov r8,r1
    c.r[1] += 112;  // 0609D660 add #112,r1
    c.r[0] = ld32(c.r[1]);  // 0609D662 mov.l @r1,r0
    c.t = c.r[0] == 0x2u;  // 0609D664 cmp/eq #2,r0
    if (!c.t) { goto L_0609D66E; }  // 0609D666 bf 0x0609D66E
    c.r[1] = ld32(0x0609D680u);  // 0609D668 mov.l 0x0609D680,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D66Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D66Eu) return; }  // 0609D66A jsr @r1 ; nop
L_0609D66E:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609D67Eu);  // 0609D66E mov.w 0x0609D67E,r6
    c.r[0] = ld32(0x0609D684u);  // 0609D670 mov.l 0x0609D684,r0
    c.r[5] = 0x0u;  // 0609D672 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609D678u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D678u) return; }  // 0609D674 jsr @r0 ; mov r8,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D678 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D67A rts ; mov.l @r15+,r8
}

void f_0609D68C(SH2Context& c) {
    ran[2543] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D68C mov.l r8,@-r15
    c.r[1] = ld32(0x0609D6D0u);  // 0609D68E mov.l 0x0609D6D0,r1
    c.r[7] = ld32(c.r[1]);  // 0609D690 mov.l @r1,r7
    c.r[2] = ld32(0x0609D6D4u);  // 0609D692 mov.l 0x0609D6D4,r2
    c.r[1] = ld32(c.r[2]);  // 0609D694 mov.l @r2,r1
    c.r[3] = 0x0u;  // 0609D696 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D698 cmp/ge r1,r3
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_0609D6CA; } }  // 0609D69A bt/s 0x0609D6CA ; mov r2,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609D6CEu);  // 0609D69E mov.w 0x0609D6CE,r8
    c.r[2] = c.r[7];  // 0609D6A0 mov r7,r2
    c.r[2] += 64;  // 0609D6A2 add #64,r2
    c.r[6] = 0x0u;  // 0609D6A4 mov #0,r6
L_0609D6A6:
    c.r[1] = ld32(c.r[7]);  // 0609D6A6 mov.l @r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D6A8 tst r1,r1
    if (c.t) { goto L_0609D6BC; }  // 0609D6AA bt 0x0609D6BC
    c.r[1] = ld32(c.r[2] + 4);  // 0609D6AC mov.l @(4,r2),r1
    c.t = c.r[1] == c.r[4];  // 0609D6AE cmp/eq r4,r1
    if (!c.t) { goto L_0609D6BC; }  // 0609D6B0 bf 0x0609D6BC
    c.r[1] = ld32(c.r[2]);  // 0609D6B2 mov.l @r2,r1
    c.r[0] = c.r[1];  // 0609D6B4 mov r1,r0
    c.r[0] += c.r[6];  // 0609D6B6 add r6,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609D6B8 mov.l @(r0,r8),r1
    st32(c.r[2] + 12, c.r[1]);  // 0609D6BA mov.l r1,@(12,r2)
L_0609D6BC:
    c.r[6] += 100;  // 0609D6BC add #100,r6
    c.r[3] += 1;  // 0609D6BE add #1,r3
    c.r[2] += 100;  // 0609D6C0 add #100,r2
    c.r[1] = ld32(c.r[5]);  // 0609D6C2 mov.l @r5,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0609D6C4 cmp/ge r1,r3
    { const bool k = !c.t; c.r[7] += 100; if (k) { SH2_POLL(c); goto L_0609D6A6; } }  // 0609D6C6 bf/s 0x0609D6A6 ; add #100,r7
L_0609D6CA:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D6CA rts ; mov.l @r15+,r8
}

void f_0609D6D8(SH2Context& c) {
    ran[2544] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D6D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D6DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D6DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609D6DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609D6E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609D6E2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609D6E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D6E6 sts.l pr,@-r15
    c.r[12] = c.r[4];  // 0609D6E8 mov r4,r12
    c.r[13] = c.r[5];  // 0609D6EA mov r5,r13
    c.r[9] = c.r[6];  // 0609D6EC mov r6,r9
    c.r[1] = ld32(0x0609D808u);  // 0609D6EE mov.l 0x0609D808,r1
    c.r[11] = ld32(c.r[1]);  // 0609D6F0 mov.l @r1,r11
    c.r[1] = ld32(0x0609D80Cu);  // 0609D6F2 mov.l 0x0609D80C,r1
    c.r[1] = ld32(c.r[1]);  // 0609D6F4 mov.l @r1,r1
    c.r[8] = 0x0u;  // 0609D6F6 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609D6F8 cmp/ge r1,r8
    { const bool k = c.t; c.r[14] = 0x0u; if (k) { goto L_0609D70E; } }  // 0609D6FA bt/s 0x0609D70E ; mov #0,r14
    c.r[2] = c.r[1];  // 0609D6FE mov r1,r2
L_0609D700:
    c.r[1] = ld32(c.r[11]);  // 0609D700 mov.l @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D702 tst r1,r1
    if (c.t) { goto L_0609D70E; }  // 0609D704 bt 0x0609D70E
    c.r[8] += 1;  // 0609D706 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 0609D708 cmp/ge r2,r8
    { const bool k = !c.t; c.r[11] += 100; if (k) { SH2_POLL(c); goto L_0609D700; } }  // 0609D70A bf/s 0x0609D700 ; add #100,r11
L_0609D70E:
    c.r[1] = ld32(0x0609D80Cu);  // 0609D70E mov.l 0x0609D80C,r1
    c.r[1] = ld32(c.r[1]);  // 0609D710 mov.l @r1,r1
    c.t = c.r[8] == c.r[1];  // 0609D712 cmp/eq r1,r8
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0609D7B2; } }  // 0609D714 bt/s 0x0609D7B2 ; tst r13,r13
    if (c.t) { goto L_0609D74E; }  // 0609D718 bt 0x0609D74E
    c.r[1] = ld32(c.r[12] + 4);  // 0609D71A mov.l @(4,r12),r1
    c.r[8] = 0x0u;  // 0609D71C mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609D71E cmp/ge r1,r8
    if (c.t) { goto L_0609D7AC; }  // 0609D720 bt 0x0609D7AC
    c.r[2] = 0x0u;  // 0609D722 mov #0,r2
L_0609D724:
    c.r[10] = c.r[2];  // 0609D724 mov r2,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609D802u);  // 0609D726 mov.w 0x0609D802,r1
    c.r[1] += c.r[10];  // 0609D728 add r10,r1
    c.r[9] = c.r[12];  // 0609D72A mov r12,r9
    c.r[9] += c.r[1];  // 0609D72C add r1,r9
    c.r[4] = c.r[9];  // 0609D72E mov r9,r4
    c.r[4] += 20;  // 0609D730 add #20,r4
    c.r[0] = ld32(0x0609D810u);  // 0609D732 mov.l 0x0609D810,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D738u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D738u) return; }  // 0609D734 jsr @r0 ; mov r13,r5
    c.r[1] = c.r[0];  // 0609D738 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D73A tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_0609D76C; } }  // 0609D73C bt/s 0x0609D76C ; mov r10,r2
    c.r[1] = ld32(c.r[12] + 4);  // 0609D740 mov.l @(4,r12),r1
    c.r[8] += 1;  // 0609D742 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609D744 cmp/ge r1,r8
    { const bool k = !c.t; c.r[2] += 100; if (k) { SH2_POLL(c); goto L_0609D724; } }  // 0609D746 bf/s 0x0609D724 ; add #100,r2
    c.t = (c.r[14] & c.r[14]) == 0; goto L_0609D7AE;  // 0609D74A bra 0x0609D7AE ; tst r14,r14
L_0609D74E:
    c.r[0] = c.r[9];  // 0609D74E mov r9,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609D750 cmp/eq #-1,r0
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0609D778; } }  // 0609D752 bt/s 0x0609D778 ; tst r7,r7
    if (!c.t) { goto L_0609D778; }  // 0609D756 bf 0x0609D778
    c.r[8] = c.r[9];  // 0609D758 mov r9,r8
    c.r[8] -= 1;  // 0609D75A add #-1,r8
    c.r[1] = 0x64u;  // 0609D75C mov #100,r1
    c.macl = c.r[8] * c.r[1];  // 0609D75E mul.l r1,r8
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609D802u);  // 0609D760 mov.w 0x0609D802,r2
    c.r[14] = c.r[12];  // 0609D762 mov r12,r14
    c.r[1] = c.macl;  // 0609D764 sts macl,r1
    c.r[1] += c.r[2];  // 0609D766 add r2,r1
    c.r[14] += c.r[1]; goto L_0609D7AC;  // 0609D768 bra 0x0609D7AC ; add r1,r14
L_0609D76C:
    c.r[14] = c.r[9]; goto L_0609D7AC;  // 0609D76C bra 0x0609D7AC ; mov r9,r14
L_0609D770:
    c.r[1] += c.r[6];  // 0609D770 add r6,r1
    c.r[14] = c.r[12];  // 0609D772 mov r12,r14
    c.r[14] += c.r[1]; goto L_0609D7AC;  // 0609D774 bra 0x0609D7AC ; add r1,r14
L_0609D778:
    { const bool k = c.t; c.t = (int32_t)c.r[9] > 0; if (k) { goto L_0609D7AC; } }  // 0609D778 bt/s 0x0609D7AC ; cmp/pl r9
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_0609D782; } }  // 0609D77C bt/s 0x0609D782 ; mov #0,r3
    c.r[9] = 0x1u;  // 0609D780 mov #1,r9
L_0609D782:
    c.r[1] = ld32(c.r[12] + 4);  // 0609D782 mov.l @(4,r12),r1
    c.r[8] = 0x0u;  // 0609D784 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609D786 cmp/ge r1,r8
    if (c.t) { goto L_0609D7AC; }  // 0609D788 bt 0x0609D7AC
    c.r[4] = 0x64u;  // 0609D78A mov #100,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609D802u);  // 0609D78C mov.w 0x0609D802,r6
    c.r[5] = c.r[1];  // 0609D78E mov r1,r5
    c.r[2] = c.r[12];  // 0609D790 mov r12,r2
L_0609D792:
    c.r[0] = c.r[2];  // 0609D792 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0609D794 mov.l @(r0,r6),r1
    c.t = c.r[1] == c.r[7];  // 0609D796 cmp/eq r7,r1
    { const bool k = !c.t; c.macl = c.r[8] * c.r[4]; if (k) { goto L_0609D7A4; } }  // 0609D798 bf/s 0x0609D7A4 ; mul.l r4,r8
    c.r[3] += 1;  // 0609D79C add #1,r3
    c.t = c.r[3] == c.r[9];  // 0609D79E cmp/eq r9,r3
    { const bool k = c.t; c.r[1] = c.macl; if (k) { SH2_POLL(c); goto L_0609D770; } }  // 0609D7A0 bt/s 0x0609D770 ; sts macl,r1
L_0609D7A4:
    c.r[8] += 1;  // 0609D7A4 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[5];  // 0609D7A6 cmp/ge r5,r8
    { const bool k = !c.t; c.r[2] += 100; if (k) { SH2_POLL(c); goto L_0609D792; } }  // 0609D7A8 bf/s 0x0609D792 ; add #100,r2
L_0609D7AC:
    c.t = (c.r[14] & c.r[14]) == 0;  // 0609D7AC tst r14,r14
L_0609D7AE:
    { const bool k = !c.t; c.r[4] = c.r[11]; if (k) { goto L_0609D7B6; } }  // 0609D7AE bf/s 0x0609D7B6 ; mov r11,r4
L_0609D7B2:
    c.r[0] = 0x0u; goto L_0609D7F0;  // 0609D7B2 bra 0x0609D7F0 ; mov #0,r0
L_0609D7B6:
    c.r[1] = ld32(0x0609D814u);  // 0609D7B6 mov.l 0x0609D814,r1
    c.r[5] = c.r[14];  // 0609D7B8 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609D7BEu; c.r[6] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D7BEu) return; }  // 0609D7BA jsr @r1 ; mov #7,r6
    c.r[2] = c.r[14];  // 0609D7BE mov r14,r2
    c.r[2] += 96;  // 0609D7C0 add #96,r2
    c.r[1] = 0x1u;  // 0609D7C2 mov #1,r1
    st32(c.r[2], c.r[1]);  // 0609D7C4 mov.l r1,@r2
    c.r[1] = c.r[11];  // 0609D7C6 mov r11,r1
    c.r[1] += 64;  // 0609D7C8 add #64,r1
    st32(c.r[1], c.r[12]);  // 0609D7CA mov.l r12,@r1
    c.r[2] = c.r[11];  // 0609D7CC mov r11,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609D804u);  // 0609D7CE mov.w 0x0609D804,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 0609D7D0 mov.l @(r0,r12),r1
    c.r[2] += 68;  // 0609D7D2 add #68,r2
    st32(c.r[2], c.r[1]);  // 0609D7D4 mov.l r1,@r2
    c.r[2] = c.r[11];  // 0609D7D6 mov r11,r2
    c.r[2] += 76;  // 0609D7D8 add #76,r2
    c.r[1] = 0x0u;  // 0609D7DA mov #0,r1
    st32(c.r[2], c.r[1]);  // 0609D7DC mov.l r1,@r2
    st32(c.r[11] + 4, c.r[8]);  // 0609D7DE mov.l r8,@(4,r11)
    c.r[4] = ld32(c.r[0] + c.r[12]);  // 0609D7E0 mov.l @(r0,r12),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609D7E2 tst r4,r4
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_0609D7EE; } }  // 0609D7E4 bt/s 0x0609D7EE ; mov r11,r2
    c.r[1] = ld32(c.r[4] + 32);  // 0609D7E8 mov.l @(32,r4),r1
    c.r[2] += 72;  // 0609D7EA add #72,r2
    st32(c.r[2], c.r[1]);  // 0609D7EC mov.l r1,@r2
L_0609D7EE:
    c.r[0] = c.r[11];  // 0609D7EE mov r11,r0
L_0609D7F0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D7F0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609D7F2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609D7F4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609D7F6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609D7F8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D7FA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D7FC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D7FE rts ; mov.l @r15+,r8
}

void f_0609D818(SH2Context& c) {
    ran[2545] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D818 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D81A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D81C sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609D81E mov r4,r8
    c.r[1] = c.r[8];  // 0609D820 mov r8,r1
    c.r[1] += 64;  // 0609D822 add #64,r1
    c.r[2] = ld32(c.r[1]);  // 0609D824 mov.l @r1,r2
    c.r[6] = 0x64u;  // 0609D826 mov #100,r6
    c.r[1] = ld32(c.r[8] + 4);  // 0609D828 mov.l @(4,r8),r1
    c.r[9] = 0x0u;  // 0609D82A mov #0,r9
    c.macl = c.r[1] * c.r[6];  // 0609D82C mul.l r6,r1
    c.r[1] = c.macl;  // 0609D82E sts macl,r1
    c.r[2] += c.r[1];  // 0609D830 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609D848u);  // 0609D832 mov.w 0x0609D848,r1
    c.r[0] = c.r[2];  // 0609D834 mov r2,r0
    st32(c.r[0] + c.r[1], c.r[9]);  // 0609D836 mov.l r9,@(r0,r1)
    c.r[0] = ld32(0x0609D84Cu);  // 0609D838 mov.l 0x0609D84C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D83Eu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D83Eu) return; }  // 0609D83A jsr @r0 ; mov #0,r5
    st32(c.r[8], c.r[9]);  // 0609D83E mov.l r9,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D840 lds.l @r15+,pr
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D842 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D844 rts ; mov.l @r15+,r8
}

void f_0609D854(SH2Context& c) {
    ran[2546] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D854 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D856 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D858 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D85A sts.l pr,@-r15
    c.r[9] = c.r[4];  // 0609D85C mov r4,r9
    c.r[1] = ld32(0x0609D8B8u);  // 0609D85E mov.l 0x0609D8B8,r1
    c.r[8] = ld32(c.r[1]);  // 0609D860 mov.l @r1,r8
    c.r[1] = ld32(0x0609D8BCu);  // 0609D862 mov.l 0x0609D8BC,r1
    c.r[1] = ld32(c.r[1]);  // 0609D864 mov.l @r1,r1
    c.r[2] = 0x0u;  // 0609D866 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609D868 cmp/ge r1,r2
    { const bool k = c.t; c.r[10] = c.r[5]; if (k) { goto L_0609D880; } }  // 0609D86A bt/s 0x0609D880 ; mov r5,r10
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609D8B2u);  // 0609D86E mov.w 0x0609D8B2,r7
    c.r[3] = c.r[1];  // 0609D870 mov r1,r3
L_0609D872:
    c.r[1] = ld32(c.r[8] + 12);  // 0609D872 mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609D874 tst r1,r1
    if (c.t) { goto L_0609D880; }  // 0609D876 bt 0x0609D880
    c.r[2] += 1;  // 0609D878 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 0609D87A cmp/ge r3,r2
    { const bool k = !c.t; c.r[8] += c.r[7]; if (k) { SH2_POLL(c); goto L_0609D872; } }  // 0609D87C bf/s 0x0609D872 ; add r7,r8
L_0609D880:
    c.r[1] = ld32(0x0609D8BCu);  // 0609D880 mov.l 0x0609D8BC,r1
    c.r[1] = ld32(c.r[1]);  // 0609D882 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609D884 cmp/ge r1,r2
    { const bool k = c.t; c.r[5] = 0x2u; if (k) { goto L_0609D8A6; } }  // 0609D886 bt/s 0x0609D8A6 ; mov #2,r5
    c.r[0] = ld32(0x0609D8C0u);  // 0609D88A mov.l 0x0609D8C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D890u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D890u) return; }  // 0609D88C jsr @r0 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609D890 tst r0,r0
    { const bool k = c.t; st32(c.r[8] + 8, c.r[0]); if (k) { goto L_0609D8A6; } }  // 0609D892 bt/s 0x0609D8A6 ; mov.l r0,@(8,r8)
    st32(c.r[8] + 56, c.r[0]);  // 0609D896 mov.l r0,@(56,r8)
    st32(c.r[8] + 60, c.r[10]);  // 0609D898 mov.l r10,@(60,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609D8B4u);  // 0609D89A mov.w 0x0609D8B4,r1
    st32(c.r[8] + 32, c.r[1]);  // 0609D89C mov.l r1,@(32,r8)
    st32(c.r[8] + 36, c.r[1]);  // 0609D89E mov.l r1,@(36,r8)
    st32(c.r[8] + 12, c.r[9]);  // 0609D8A0 mov.l r9,@(12,r8)
    c.r[0] = c.r[8]; goto L_0609D8A8;  // 0609D8A2 bra 0x0609D8A8 ; mov r8,r0
L_0609D8A6:
    c.r[0] = 0x0u;  // 0609D8A6 mov #0,r0
L_0609D8A8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D8A8 lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D8AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D8AC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D8AE rts ; mov.l @r15+,r8
}

void f_0609D8C4(SH2Context& c) {
    ran[2547] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D8C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D8C6 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609D8C8 mov r4,r8
    c.r[1] = ld32(0x0609D8E4u);  // 0609D8CA mov.l 0x0609D8E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609D8D0u; c.r[4] = ld32(c.r[8] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D8D0u) return; }  // 0609D8CC jsr @r1 ; mov.l @(8,r8),r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609D8E0u);  // 0609D8D0 mov.w 0x0609D8E0,r6
    c.r[0] = ld32(0x0609D8E8u);  // 0609D8D2 mov.l 0x0609D8E8,r0
    c.r[5] = 0x0u;  // 0609D8D4 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609D8DAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D8DAu) return; }  // 0609D8D6 jsr @r0 ; mov r8,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D8DA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D8DC rts ; mov.l @r15+,r8
}

void f_0609D8EC(SH2Context& c) {
    ran[2548] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D8EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D8EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D8F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609D8F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D8F4 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 0609D8F6 mov r4,r9
    c.r[11] = c.r[5];  // 0609D8F8 mov r5,r11
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609D8FA tst r9,r9
    { const bool k = c.t; c.r[10] = c.r[6]; if (k) { goto L_0609D916; } }  // 0609D8FC bt/s 0x0609D916 ; mov r6,r10
    c.r[8] = ld32(c.r[9] + 8);  // 0609D900 mov.l @(8,r9),r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609D924u);  // 0609D902 mov.w 0x0609D924,r6
    c.r[0] = ld32(0x0609D928u);  // 0609D904 mov.l 0x0609D928,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609D90Au; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D90Au) return; }  // 0609D906 jsr @r0 ; mov #0,r5
    st32(c.r[9] + 8, c.r[8]);  // 0609D90A mov.l r8,@(8,r9)
    st32(c.r[9] + 56, c.r[8]);  // 0609D90C mov.l r8,@(56,r9)
    st32(c.r[9] + 60, c.r[10]);  // 0609D90E mov.l r10,@(60,r9)
    st32(c.r[9] + 12, c.r[11]);  // 0609D910 mov.l r11,@(12,r9)
    c.r[0] = 0x1u; goto L_0609D918;  // 0609D912 bra 0x0609D918 ; mov #1,r0
L_0609D916:
    c.r[0] = 0x0u;  // 0609D916 mov #0,r0
L_0609D918:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D918 lds.l @r15+,pr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609D91A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609D91C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609D91E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609D920 rts ; mov.l @r15+,r8
}

void f_0609D938(SH2Context& c) {
    ran[2549] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609D938 tst r4,r4
    { const bool k = c.t; c.r[2] = ld32(c.r[15]); if (k) { goto L_0609D96E; } }  // 0609D93A bt/s 0x0609D96E ; mov.l @r15,r2
    c.r[1] = c.r[4];  // 0609D93E mov r4,r1
    c.r[1] += 46;  // 0609D940 add #46,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609D942 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609D944 extu.w r1,r1
    st32(c.r[5], c.r[1]);  // 0609D946 mov.l r1,@r5
    c.r[1] = ld32(c.r[4] + 48);  // 0609D948 mov.l @(48,r4),r1
    st32(c.r[6], c.r[1]);  // 0609D94A mov.l r1,@r6
    c.r[1] = c.r[4];  // 0609D94C mov r4,r1
    c.r[1] += 44;  // 0609D94E add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609D950 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0609D952 extu.w r1,r0
    c.t = c.r[0] == 0x1u;  // 0609D954 cmp/eq #1,r0
    { const bool k = c.t; st32(c.r[2], c.r[0]); if (k) { goto L_0609D968; } }  // 0609D956 bt/s 0x0609D968 ; mov.l r0,@r2
    c.r[1] = ld32(c.r[5]);  // 0609D95A mov.l @r5,r1
    c.r[2] = ld32(c.r[6]);  // 0609D95C mov.l @r6,r2
    c.r[1] += c.r[1];  // 0609D95E add r1,r1
    c.macl = c.r[2] * c.r[1];  // 0609D960 mul.l r1,r2
    c.r[3] = c.macl;  // 0609D962 sts macl,r3
    st32(c.r[7], c.r[3]); goto L_0609D97E;  // 0609D964 bra 0x0609D97E ; mov.l r3,@r7
L_0609D968:
    c.r[1] = ld32(c.r[4] + 52);  // 0609D968 mov.l @(52,r4),r1
    st32(c.r[7], c.r[1]); goto L_0609D97E;  // 0609D96A bra 0x0609D97E ; mov.l r1,@r7
L_0609D96E:
    c.r[3] = c.t;  // 0609D96E movt r3
    st32(c.r[5], c.r[3]);  // 0609D970 mov.l r3,@r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609D984u);  // 0609D972 mov.w 0x0609D984,r1
    st32(c.r[6], c.r[1]);  // 0609D974 mov.l r1,@r6
    st32(c.r[7], c.r[1]);  // 0609D976 mov.l r1,@r7
    st32(c.r[2], c.r[3]);  // 0609D978 mov.l r3,@r2
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609D97A rts ; mov #0,r0
L_0609D97E:
    c.r[0] = c.r[4];  // 0609D97E mov r4,r0
    { const uint32_t x = c.pr; c.r[0] += 44; c.pc = x; return; }  // 0609D980 rts ; add #44,r0
}

void f_0609D9A0(SH2Context& c) {
    ran[2550] = 1;
    c.r[1] = c.r[4];  // 0609D9A0 mov r4,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609D9B8u);  // 0609D9A2 mov.w 0x0609D9B8,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609D9A4 tst r5,r5
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.pr); if (k) { goto L_0609D9AC; } }  // 0609D9A6 bt/s 0x0609D9AC ; sts.l pr,@-r15
    c.r[4] = ld32(c.r[5] + 48);  // 0609D9AA mov.l @(48,r5),r4
L_0609D9AC:
    c.r[7] = ld32(0x0609D9BCu);  // 0609D9AC mov.l 0x0609D9BC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609D9B2u; c.r[5] = ld32(c.r[1] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D9B2u) return; }  // 0609D9AE jsr @r7 ; mov.l @(8,r1),r5
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609D9B2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609D9B4 rts ; nop
}

void f_0609D9C0(SH2Context& c) {
    ran[2551] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609D9C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609D9C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609D9C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609D9C6 sts.l pr,@-r15
    c.r[2] = c.r[4];  // 0609D9C8 mov r4,r2
    c.r[9] = c.r[7];  // 0609D9CA mov r7,r9
    c.r[8] = ld32(c.r[2] + 8);  // 0609D9CC mov.l @(8,r2),r8
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609D9CE tst r5,r5
    { const bool k = !c.t; st32(c.r[6], c.r[8]); if (k) { goto L_0609D9DA; } }  // 0609D9D0 bf/s 0x0609D9DA ; mov.l r8,@r6
    c.r[1] = 0x0u;  // 0609D9D4 mov #0,r1
    st32(c.r[9], c.r[1]); goto L_0609DA1E;  // 0609D9D6 bra 0x0609DA1E ; mov.l r1,@r9
L_0609D9DA:
    c.r[1] = c.r[5];  // 0609D9DA mov r5,r1
    c.r[1] += 64;  // 0609D9DC add #64,r1
    c.r[1] = ld32(c.r[1]);  // 0609D9DE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609DA28u);  // 0609D9E0 mov.w 0x0609DA28,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609D9E2 mov.l @(r0,r1),r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0609D9E4 tst r6,r6
    { const bool k = c.t; c.t = (c.r[5] & c.r[5]) == 0; if (k) { goto L_0609D9FA; } }  // 0609D9E6 bt/s 0x0609D9FA ; tst r5,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609DA2Au);  // 0609D9EA mov.w 0x0609DA2A,r4
    if (c.t) { goto L_0609D9F0; }  // 0609D9EC bt 0x0609D9F0
    c.r[4] = ld32(c.r[5] + 48);  // 0609D9EE mov.l @(48,r5),r4
L_0609D9F0:
    c.r[7] = ld32(0x0609DA2Cu);  // 0609D9F0 mov.l 0x0609DA2C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609D9F6u; c.r[5] = ld32(c.r[2] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609D9F6u) return; }  // 0609D9F2 jsr @r7 ; mov.l @(8,r2),r5
    c.macl = c.r[0] * c.r[6]; goto L_0609DA1A;  // 0609D9F6 bra 0x0609DA1A ; mul.l r6,r0
L_0609D9FA:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609DA2Au);  // 0609D9FA mov.w 0x0609DA2A,r4
    if (c.t) { goto L_0609DA00; }  // 0609D9FC bt 0x0609DA00
    c.r[4] = ld32(c.r[5] + 48);  // 0609D9FE mov.l @(48,r5),r4
L_0609DA00:
    c.r[7] = ld32(0x0609DA2Cu);  // 0609DA00 mov.l 0x0609DA2C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609DA06u; c.r[5] = ld32(c.r[2] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DA06u) return; }  // 0609DA02 jsr @r7 ; mov.l @(8,r2),r5
    c.r[1] = c.r[8];  // 0609DA06 mov r8,r1
    c.r[1] += c.r[1];  // 0609DA08 add r1,r1
    c.r[1] += c.r[8];  // 0609DA0A add r8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609DA0C cmp/pz r1
    if (c.t) { goto L_0609DA12; }  // 0609DA0E bt 0x0609DA12
    c.r[1] += 3;  // 0609DA10 add #3,r1
L_0609DA12:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609DA12 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609DA14 shar r1
    c.r[1] += 1;  // 0609DA16 add #1,r1
    c.macl = c.r[0] * c.r[1];  // 0609DA18 mul.l r1,r0
L_0609DA1A:
    c.r[10] = c.macl;  // 0609DA1A sts macl,r10
    st32(c.r[9], c.r[10]);  // 0609DA1C mov.l r10,@r9
L_0609DA1E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609DA1E lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609DA20 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609DA22 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609DA24 rts ; mov.l @r15+,r8
}

void f_0609DA30(SH2Context& c) {
    ran[2552] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609DA30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609DA32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609DA34 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609DA36 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609DA38 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609DADCu);  // 0609DA3A mov.w 0x0609DADC,r3
    c.r[15] += c.r[3];  // 0609DA3C add r3,r15
    c.r[9] = c.r[4];  // 0609DA3E mov r4,r9
    c.r[3] = c.r[6];  // 0609DA40 mov r6,r3
    c.r[0] = c.r[5] & 0xFFu;  // 0609DA42 extu.b r5,r0
    c.r[1] = ld32(0x0609DAE0u);  // 0609DA44 mov.l 0x0609DAE0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0609DA46 mov.b @(r0,r1),r0
    c.r[0] &= 0x4u;  // 0609DA48 and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609DA4A tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[7]; if (k) { goto L_0609DA54; } }  // 0609DA4C bt/s 0x0609DA54 ; mov r7,r6
    goto L_0609DBA0;  // 0609DA50 bra 0x0609DBA0 ; nop
L_0609DA54:
    c.t = (int32_t)c.r[6] > 0;  // 0609DA54 cmp/pl r6
    if (c.t) { goto L_0609DA5C; }  // 0609DA56 bt 0x0609DA5C
    goto L_0609DBA0;  // 0609DA58 bra 0x0609DBA0 ; nop
L_0609DA5C:
    c.r[1] = ld32(0x0609DAE4u);  // 0609DA5C mov.l 0x0609DAE4,r1
    c.t = c.r[5] == c.r[1];  // 0609DA5E cmp/eq r1,r5
    { const bool k = c.t; c.t = c.r[5] > c.r[1]; if (k) { goto L_0609DB10; } }  // 0609DA60 bt/s 0x0609DB10 ; cmp/hi r1,r5
    if (c.t) { goto L_0609DA90; }  // 0609DA64 bt 0x0609DA90
    c.r[1] = ld32(0x0609DAE8u);  // 0609DA66 mov.l 0x0609DAE8,r1
    c.t = c.r[5] == c.r[1];  // 0609DA68 cmp/eq r1,r5
    { const bool k = !c.t; c.t = c.r[5] > c.r[1]; if (k) { goto L_0609DA72; } }  // 0609DA6A bf/s 0x0609DA72 ; cmp/hi r1,r5
    goto L_0609DE1A;  // 0609DA6E bra 0x0609DE1A ; nop
L_0609DA72:
    if (c.t) { goto L_0609DA7A; }  // 0609DA72 bt 0x0609DA7A
    c.r[1] = ld32(0x0609DAECu);  // 0609DA74 mov.l 0x0609DAEC,r1
    c.t = c.r[5] == c.r[1]; goto L_0609DAAA;  // 0609DA76 bra 0x0609DAAA ; cmp/eq r1,r5
L_0609DA7A:
    c.r[1] = ld32(0x0609DAF0u);  // 0609DA7A mov.l 0x0609DAF0,r1
    c.t = c.r[5] == c.r[1];  // 0609DA7C cmp/eq r1,r5
    if (c.t) { goto L_0609DACC; }  // 0609DA7E bt 0x0609DACC
    c.r[1] = ld32(0x0609DAF4u);  // 0609DA80 mov.l 0x0609DAF4,r1
    c.t = c.r[5] == c.r[1];  // 0609DA82 cmp/eq r1,r5
    { const bool k = !c.t; c.r[10] = 0x64u; if (k) { goto L_0609DA8C; } }  // 0609DA84 bf/s 0x0609DA8C ; mov #100,r10
    goto L_0609DD24;  // 0609DA88 bra 0x0609DD24 ; nop
L_0609DA8C:
    c.r[0] = 0x0u; goto L_0609DE42;  // 0609DA8C bra 0x0609DE42 ; mov #0,r0
L_0609DA90:
    c.r[1] = ld32(0x0609DAF8u);  // 0609DA90 mov.l 0x0609DAF8,r1
    c.t = c.r[5] == c.r[1];  // 0609DA92 cmp/eq r1,r5
    { const bool k = c.t; c.t = c.r[5] > c.r[1]; if (k) { goto L_0609DAD0; } }  // 0609DA94 bt/s 0x0609DAD0 ; cmp/hi r1,r5
    if (c.t) { goto L_0609DAB2; }  // 0609DA98 bt 0x0609DAB2
    c.r[1] = ld32(0x0609DAFCu);  // 0609DA9A mov.l 0x0609DAFC,r1
    c.t = c.r[5] == c.r[1];  // 0609DA9C cmp/eq r1,r5
    { const bool k = !c.t; c.r[8] = c.r[15]; if (k) { goto L_0609DAA6; } }  // 0609DA9E bf/s 0x0609DAA6 ; mov r15,r8
    goto L_0609DBA4;  // 0609DAA2 bra 0x0609DBA4 ; nop
L_0609DAA6:
    c.r[1] = ld32(0x0609DB00u);  // 0609DAA6 mov.l 0x0609DB00,r1
    c.t = c.r[5] == c.r[1];  // 0609DAA8 cmp/eq r1,r5
L_0609DAAA:
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609DAD0; } }  // 0609DAAA bt/s 0x0609DAD0 ; mov #0,r0
    goto L_0609DE42;  // 0609DAAE bra 0x0609DE42 ; nop
L_0609DAB2:
    c.r[1] = ld32(0x0609DB04u);  // 0609DAB2 mov.l 0x0609DB04,r1
    c.t = c.r[5] == c.r[1];  // 0609DAB4 cmp/eq r1,r5
    if (!c.t) { goto L_0609DABC; }  // 0609DAB6 bf 0x0609DABC
    goto L_0609DE2A;  // 0609DAB8 bra 0x0609DE2A ; nop
L_0609DABC:
    c.r[1] = ld32(0x0609DB08u);  // 0609DABC mov.l 0x0609DB08,r1
    c.t = c.r[5] == c.r[1];  // 0609DABE cmp/eq r1,r5
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0609DAC8; } }  // 0609DAC0 bf/s 0x0609DAC8 ; mov r9,r1
    goto L_0609DE1C;  // 0609DAC4 bra 0x0609DE1C ; nop
L_0609DAC8:
    c.r[0] = 0x0u; goto L_0609DE42;  // 0609DAC8 bra 0x0609DE42 ; mov #0,r0
L_0609DACC:
    c.r[3] += 4;  // 0609DACC add #4,r3
    c.r[6] -= 4;  // 0609DACE add #-4,r6
L_0609DAD0:
    c.r[1] = ld32(0x0609DB0Cu);  // 0609DAD0 mov.l 0x0609DB0C,r1
    c.r[5] = c.r[3];  // 0609DAD2 mov r3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609DAD8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DAD8u) return; }  // 0609DAD4 jsr @r1 ; mov r9,r4
    c.r[0] = 0x0u; goto L_0609DE42;  // 0609DAD8 bra 0x0609DE42 ; mov #0,r0
L_0609DB10:
    c.r[1] = ld32(0x0609DCCCu);  // 0609DB10 mov.l 0x0609DCCC,r1
    c.r[8] = 0x0u;  // 0609DB12 mov #0,r8
    st32(c.r[1], c.r[8]);  // 0609DB14 mov.l r8,@r1
    c.r[1] = ld32(0x0609DCD0u);  // 0609DB16 mov.l 0x0609DCD0,r1
    c.r[6] = 0x38u;  // 0609DB18 mov #56,r6
    c.r[5] = c.r[3];  // 0609DB1A mov r3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609DB20u; c.r[4] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DB20u) return; }  // 0609DB1C jsr @r1 ; mov r15,r4
    c.r[2] = c.r[9];  // 0609DB20 mov r9,r2
    c.r[2] += 116;  // 0609DB22 add #116,r2
    c.r[1] = ld32(c.r[15]);  // 0609DB24 mov.l @r15,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB26 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB28 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB2A swap.b r1,r1
    c.r[3] = c.r[9];  // 0609DB2C mov r9,r3
    c.r[3] += 104;  // 0609DB2E add #104,r3
    st32(c.r[2], c.r[1]);  // 0609DB30 mov.l r1,@r2
    c.r[1] = ld32(c.r[15] + 4);  // 0609DB32 mov.l @(4,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB34 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB36 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB38 swap.b r1,r1
    st32(c.r[2] + 4, c.r[1]);  // 0609DB3A mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[15] + 8);  // 0609DB3C mov.l @(8,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB3E swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB40 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB42 swap.b r1,r1
    st32(c.r[2] + 8, c.r[1]);  // 0609DB44 mov.l r1,@(8,r2)
    c.r[1] = ld32(c.r[15] + 12);  // 0609DB46 mov.l @(12,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB48 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB4A swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB4C swap.b r1,r1
    st32(c.r[2] + 12, c.r[1]);  // 0609DB4E mov.l r1,@(12,r2)
    c.r[1] = ld32(c.r[15] + 16);  // 0609DB50 mov.l @(16,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB52 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB54 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB56 swap.b r1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0609DB58 mov.l r1,@(16,r2)
    st32(c.r[3], c.r[1]);  // 0609DB5A mov.l r1,@r3
    c.r[1] = ld32(c.r[15] + 20);  // 0609DB5C mov.l @(20,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB5E swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB60 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB62 swap.b r1,r1
    st32(c.r[2] + 20, c.r[1]);  // 0609DB64 mov.l r1,@(20,r2)
    c.r[1] = ld32(c.r[15] + 24);  // 0609DB66 mov.l @(24,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB68 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB6A swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB6C swap.b r1,r1
    st32(c.r[2] + 24, c.r[1]);  // 0609DB6E mov.l r1,@(24,r2)
    st32(c.r[9] + 4, c.r[1]);  // 0609DB70 mov.l r1,@(4,r9)
    c.r[1] = ld32(c.r[15] + 28);  // 0609DB72 mov.l @(28,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB74 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB76 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB78 swap.b r1,r1
    c.r[0] = ld32(c.r[2] + 12);  // 0609DB7A mov.l @(12,r2),r0
    st32(c.r[2] + 28, c.r[1]);  // 0609DB7C mov.l r1,@(28,r2)
    c.r[1] = ld32(c.r[15] + 32);  // 0609DB7E mov.l @(32,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB80 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB82 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB84 swap.b r1,r1
    c.r[0] &= 0x10u;  // 0609DB86 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609DB88 tst r0,r0
    st32(c.r[2] + 32, c.r[1]);  // 0609DB8A mov.l r1,@(32,r2)
    c.r[1] = ld32(c.r[15] + 36);  // 0609DB8C mov.l @(36,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB8E swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DB90 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DB92 swap.b r1,r1
    { const bool k = c.t; st32(c.r[2] + 36, c.r[1]); if (k) { goto L_0609DB9C; } }  // 0609DB94 bt/s 0x0609DB9C ; mov.l r1,@(36,r2)
    goto L_0609DE40;  // 0609DB98 bra 0x0609DE40 ; nop
L_0609DB9C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609DCC2u);  // 0609DB9C mov.w 0x0609DCC2,r0
    st32(c.r[0] + c.r[9], c.r[8]);  // 0609DB9E mov.l r8,@(r0,r9)
L_0609DBA0:
    c.r[0] = 0x1u; goto L_0609DE42;  // 0609DBA0 bra 0x0609DE42 ; mov #1,r0
L_0609DBA4:
    c.r[8] += 56;  // 0609DBA4 add #56,r8
    c.r[1] = ld32(0x0609DCD0u);  // 0609DBA6 mov.l 0x0609DCD0,r1
    c.r[6] = 0x40u;  // 0609DBA8 mov #64,r6
    c.r[5] = c.r[3];  // 0609DBAA mov r3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609DBB0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DBB0u) return; }  // 0609DBAC jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0609DCCCu);  // 0609DBB0 mov.l 0x0609DCCC,r1
    c.r[6] = ld32(c.r[1]);  // 0609DBB2 mov.l @r1,r6
    c.r[1] = 0x64u;  // 0609DBB4 mov #100,r1
    c.macl = c.r[6] * c.r[1];  // 0609DBB6 mul.l r1,r6
    c.r[7] = c.r[9];  // 0609DBB8 mov r9,r7
    c.r[2] = c.macl;  // 0609DBBA sts macl,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DCC4u);  // 0609DBBC mov.w 0x0609DCC4,r1
    c.r[3] = c.r[2];  // 0609DBBE mov r2,r3
    c.r[3] += c.r[1];  // 0609DBC0 add r1,r3
    c.r[7] += c.r[3];  // 0609DBC2 add r3,r7
    c.r[2] = c.r[7];  // 0609DBC4 mov r7,r2
    c.r[2] += 88;  // 0609DBC6 add #88,r2
    c.r[1] = c.r[15];  // 0609DBC8 mov r15,r1
    c.r[1] += 76;  // 0609DBCA add #76,r1
    c.r[1] = ld32(c.r[1]);  // 0609DBCC mov.l @r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBCE swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DBD0 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBD2 swap.b r1,r1
    st32(c.r[8] + 20, c.r[1]);  // 0609DBD4 mov.l r1,@(20,r8)
    st32(c.r[2], c.r[1]);  // 0609DBD6 mov.l r1,@r2
    c.r[2] = c.r[7];  // 0609DBD8 mov r7,r2
    c.r[2] += 84;  // 0609DBDA add #84,r2
    c.r[1] = c.r[15];  // 0609DBDC mov r15,r1
    c.r[1] += 80;  // 0609DBDE add #80,r1
    c.r[1] = ld32(c.r[1]);  // 0609DBE0 mov.l @r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBE2 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DBE4 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBE6 swap.b r1,r1
    st32(c.r[8] + 24, c.r[1]);  // 0609DBE8 mov.l r1,@(24,r8)
    st32(c.r[2], c.r[1]);  // 0609DBEA mov.l r1,@r2
    c.r[1] = ld32(c.r[15] + 60);  // 0609DBEC mov.l @(60,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBEE swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DBF0 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBF2 swap.b r1,r1
    c.r[2] = c.r[7];  // 0609DBF4 mov r7,r2
    c.r[2] += 80;  // 0609DBF6 add #80,r2
    st32(c.r[15] + 60, c.r[1]);  // 0609DBF8 mov.l r1,@(60,r15)
    c.r[1] = ld32(c.r[15] + 56);  // 0609DBFA mov.l @(56,r15),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DBFC swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DBFE swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DC00 swap.b r1,r1
    st32(c.r[15] + 56, c.r[1]);  // 0609DC02 mov.l r1,@(56,r15)
    c.r[1] = c.r[15];  // 0609DC04 mov r15,r1
    c.r[1] += 100;  // 0609DC06 add #100,r1
    c.r[1] = ld32(c.r[1]);  // 0609DC08 mov.l @r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DC0A swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DC0C swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DC0E swap.b r1,r1
    st32(c.r[8] + 44, c.r[1]);  // 0609DC10 mov.l r1,@(44,r8)
    st32(c.r[2], c.r[1]);  // 0609DC12 mov.l r1,@r2
    c.r[1] = c.r[15];  // 0609DC14 mov r15,r1
    c.r[1] += 88;  // 0609DC16 add #88,r1
    c.r[1] = ld32(c.r[1]);  // 0609DC18 mov.l @r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DC1A swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DC1C swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DC1E swap.b r1,r1
    st32(c.r[8] + 32, c.r[1]);  // 0609DC20 mov.l r1,@(32,r8)
    st32(c.r[7] + 16, c.r[1]);  // 0609DC22 mov.l r1,@(16,r7)
    c.r[2] = ld32(c.r[15] + 56);  // 0609DC24 mov.l @(56,r15),r2
    c.r[1] = ld32(0x0609DCD4u);  // 0609DC26 mov.l 0x0609DCD4,r1
    c.t = c.r[2] == c.r[1];  // 0609DC28 cmp/eq r1,r2
    if (!c.t) { goto L_0609DCF0; }  // 0609DC2A bf 0x0609DCF0
    c.r[2] = ld32(c.r[15] + 60);  // 0609DC2C mov.l @(60,r15),r2
    c.r[1] = ld32(0x0609DCD8u);  // 0609DC2E mov.l 0x0609DCD8,r1
    c.t = c.r[2] == c.r[1];  // 0609DC30 cmp/eq r1,r2
    if (c.t) { goto L_0609DC46; }  // 0609DC32 bt 0x0609DC46
    c.r[1] = ld32(0x0609DCDCu);  // 0609DC34 mov.l 0x0609DCDC,r1
    c.t = c.r[2] == c.r[1];  // 0609DC36 cmp/eq r1,r2
    if (c.t) { goto L_0609DC46; }  // 0609DC38 bt 0x0609DC46
    c.r[1] = ld32(0x0609DCE0u);  // 0609DC3A mov.l 0x0609DCE0,r1
    c.t = c.r[2] == c.r[1];  // 0609DC3C cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609DC46; } }  // 0609DC3E bt/s 0x0609DC46 ; mov #0,r0
    goto L_0609DE42;  // 0609DC42 bra 0x0609DE42 ; nop
L_0609DC46:
    c.r[6] = c.r[15];  // 0609DC46 mov r15,r6
    c.r[6] += 80;  // 0609DC48 add #80,r6
    c.r[5] = ld32(c.r[6]);  // 0609DC4A mov.l @r6,r5
    c.r[1] = ld32(0x0609DCE4u);  // 0609DC4C mov.l 0x0609DCE4,r1
    c.t = c.r[5] > c.r[1];  // 0609DC4E cmp/hi r1,r5
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_0609DC72; } }  // 0609DC50 bt/s 0x0609DC72 ; mov r7,r2
    c.r[3] = ld32(0x0609DCE8u);  // 0609DC54 mov.l 0x0609DCE8,r3
    c.r[1] = ld32(0x0609DCECu);  // 0609DC56 mov.l 0x0609DCEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609DC5Cu; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DC5Cu) return; }  // 0609DC58 jsr @r1 ; mov r3,r4
    c.r[2] = c.r[15];  // 0609DC5C mov r15,r2
    c.r[2] += 56;  // 0609DC5E add #56,r2
    st32(c.r[2] + 24, c.r[3]);  // 0609DC60 mov.l r3,@(24,r2)
    c.r[1] = c.r[15];  // 0609DC62 mov r15,r1
    c.r[1] += 76;  // 0609DC64 add #76,r1
    c.r[1] = ld32(c.r[1]);  // 0609DC66 mov.l @r1,r1
    c.r[5] = c.r[0];  // 0609DC68 mov r0,r5
    c.macl = c.r[5] * c.r[1];  // 0609DC6A mul.l r1,r5
    c.r[0] = c.macl;  // 0609DC6C sts macl,r0
    st32(c.r[2] + 20, c.r[0]);  // 0609DC6E mov.l r0,@(20,r2)
    c.r[2] = c.r[7];  // 0609DC70 mov r7,r2
L_0609DC72:
    c.r[2] += 84;  // 0609DC72 add #84,r2
    c.r[5] = c.r[15];  // 0609DC74 mov r15,r5
    c.r[1] = ld32(c.r[6]);  // 0609DC76 mov.l @r6,r1
    c.r[5] += 76;  // 0609DC78 add #76,r5
    st32(c.r[2], c.r[1]);  // 0609DC7A mov.l r1,@r2
    c.r[2] = c.r[7];  // 0609DC7C mov r7,r2
    c.r[1] = ld32(c.r[5]);  // 0609DC7E mov.l @r5,r1
    c.r[2] += 88;  // 0609DC80 add #88,r2
    st32(c.r[2], c.r[1]);  // 0609DC82 mov.l r1,@r2
    c.r[3] = ld32(c.r[5]);  // 0609DC84 mov.l @r5,r3
    c.r[1] = 0x1u;  // 0609DC86 mov #1,r1
    c.t = c.r[3] > c.r[1];  // 0609DC88 cmp/hi r1,r3
    { const bool k = !c.t; c.r[2] = c.r[15]; if (k) { goto L_0609DC96; } }  // 0609DC8A bf/s 0x0609DC96 ; mov r15,r2
    c.r[2] += 56;  // 0609DC8E add #56,r2
    c.r[1] = c.r[3];  // 0609DC90 mov r3,r1
    c.r[1] -= 1;  // 0609DC92 add #-1,r1
    st32(c.r[2] + 20, c.r[1]);  // 0609DC94 mov.l r1,@(20,r2)
L_0609DC96:
    c.r[4] = ld32(c.r[6]);  // 0609DC96 mov.l @r6,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609DCC6u);  // 0609DC98 mov.w 0x0609DCC6,r2
    c.r[1] = ld32(0x0609DCECu);  // 0609DC9A mov.l 0x0609DCEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609DCA0u; c.r[5] = ld32(c.r[5]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DCA0u) return; }  // 0609DC9C jsr @r1 ; mov.l @r5,r5
    c.r[1] = c.r[0];  // 0609DCA0 mov r0,r1
    c.r[0] = c.r[9];  // 0609DCA2 mov r9,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609DCA4 mov.l r1,@(r0,r2)
    st32(c.r[7] + 8, c.r[1]);  // 0609DCA6 mov.l r1,@(8,r7)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609DCC8u);  // 0609DCA8 mov.w 0x0609DCC8,r2
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609DCAA mov.l @(r0,r2),r1
    c.r[0] = c.r[1];  // 0609DCAC mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609DCAE cmp/eq #-1,r0
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_0609DCBE; } }  // 0609DCB0 bf/s 0x0609DCBE ; mov #2,r1
    c.r[1] = ld32(0x0609DCCCu);  // 0609DCB4 mov.l 0x0609DCCC,r1
    c.r[1] = ld32(c.r[1]);  // 0609DCB6 mov.l @r1,r1
    c.r[0] = c.r[9];  // 0609DCB8 mov r9,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609DCBA mov.l r1,@(r0,r2)
    c.r[1] = 0x2u;  // 0609DCBC mov #2,r1
L_0609DCBE:
    st32(c.r[7], c.r[1]); goto L_0609DD18;  // 0609DCBE bra 0x0609DD18 ; mov.l r1,@r7
L_0609DCF0:
    c.r[1] = ld32(0x0609DE70u);  // 0609DCF0 mov.l 0x0609DE70,r1
    c.t = c.r[2] == c.r[1];  // 0609DCF2 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = ld32(c.r[15] + 60); if (k) { goto L_0609DD18; } }  // 0609DCF4 bf/s 0x0609DD18 ; mov.l @(60,r15),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609DCF8 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609DD02; } }  // 0609DCFA bt/s 0x0609DD02 ; mov #0,r0
    goto L_0609DE42;  // 0609DCFE bra 0x0609DE42 ; nop
L_0609DD02:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE52u);  // 0609DD02 mov.w 0x0609DE52,r1
    c.r[0] = c.r[9];  // 0609DD04 mov r9,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0609DD06 mov.l @(r0,r1),r2
    c.r[0] = c.r[2];  // 0609DD08 mov r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609DD0A cmp/eq #-1,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0609DD12; } }  // 0609DD0C bf/s 0x0609DD12 ; mov r9,r0
    st32(c.r[0] + c.r[1], c.r[6]);  // 0609DD10 mov.l r6,@(r0,r1)
L_0609DD12:
    c.r[1] = 0x1u;  // 0609DD12 mov #1,r1
    c.r[0] = c.r[9];  // 0609DD14 mov r9,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 0609DD16 mov.l r1,@(r0,r3)
L_0609DD18:
    c.r[2] = ld32(0x0609DE74u);  // 0609DD18 mov.l 0x0609DE74,r2
    c.r[1] = ld32(c.r[2]);  // 0609DD1A mov.l @r2,r1
    c.r[0] = 0x0u;  // 0609DD1C mov #0,r0
    c.r[1] += 1;  // 0609DD1E add #1,r1
    st32(c.r[2], c.r[1]); goto L_0609DE42;  // 0609DD20 bra 0x0609DE42 ; mov.l r1,@r2
L_0609DD24:
    c.r[8] = ld32(0x0609DE74u);  // 0609DD24 mov.l 0x0609DE74,r8
    c.r[1] = ld32(c.r[8]);  // 0609DD26 mov.l @r8,r1
    c.r[1] -= 1;  // 0609DD28 add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0609DD2A mul.l r10,r1
    c.r[2] = c.r[9];  // 0609DD2C mov r9,r2
    c.r[1] = c.macl;  // 0609DD2E sts macl,r1
    c.r[2] += c.r[1];  // 0609DD30 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE54u);  // 0609DD32 mov.w 0x0609DE54,r1
    c.r[0] = c.r[2];  // 0609DD34 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609DD36 mov.l @(r0,r1),r1
    c.r[0] = c.r[1];  // 0609DD38 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609DD3A cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0609DD9C; } }  // 0609DD3C bt/s 0x0609DD9C ; cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609DE42; } }  // 0609DD40 bf/s 0x0609DE42 ; mov #0,r0
    c.r[4] = c.r[15];  // 0609DD44 mov r15,r4
    c.r[4] += 120;  // 0609DD46 add #120,r4
    c.r[1] = ld32(0x0609DE78u);  // 0609DD48 mov.l 0x0609DE78,r1
    c.r[6] = 0x2Cu;  // 0609DD4A mov #44,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0609DD50u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DD50u) return; }  // 0609DD4C jsr @r1 ; mov r3,r5
    c.r[1] = ld32(c.r[8]);  // 0609DD50 mov.l @r8,r1
    c.r[1] -= 1;  // 0609DD52 add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0609DD54 mul.l r10,r1
    c.r[3] = c.r[9];  // 0609DD56 mov r9,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609DE56u);  // 0609DD58 mov.w 0x0609DE56,r2
    c.r[1] = c.macl;  // 0609DD5A sts macl,r1
    c.r[3] += c.r[1];  // 0609DD5C add r1,r3
    c.r[1] = c.r[15];  // 0609DD5E mov r15,r1
    c.r[1] += 124;  // 0609DD60 add #124,r1
    c.r[1] = ld32(c.r[1]);  // 0609DD62 mov.l @r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DD64 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DD66 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DD68 swap.b r1,r1
    c.r[0] = c.r[3];  // 0609DD6A mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0609DD6C mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609DE58u);  // 0609DD6E mov.w 0x0609DE58,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE5Au);  // 0609DD70 mov.w 0x0609DE5A,r1
    c.r[0] = c.r[15];  // 0609DD72 mov r15,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609DD74 mov.l @(r0,r1),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DD76 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DD78 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DD7A swap.b r1,r1
    c.r[0] = c.r[3];  // 0609DD7C mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0609DD7E mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609DE5Cu);  // 0609DD80 mov.w 0x0609DE5C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE5Eu);  // 0609DD82 mov.w 0x0609DE5E,r1
    c.r[0] = c.r[15];  // 0609DD84 mov r15,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609DD86 mov.l @(r0,r1),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DD88 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DD8A swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DD8C swap.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609DD8E tst r1,r1
    c.r[1] = c.t;  // 0609DD90 movt r1
    c.r[0] = 0x1u;  // 0609DD92 mov #1,r0
    c.r[1] ^= c.r[0];  // 0609DD94 xor r0,r1
    c.r[0] = c.r[3];  // 0609DD96 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]); goto L_0609DE40;  // 0609DD98 bra 0x0609DE40 ; mov.w r1,@(r0,r2)
L_0609DD9C:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609DE60u);  // 0609DD9C mov.w 0x0609DE60,r11
    c.r[4] = c.r[15];  // 0609DD9E mov r15,r4
    c.r[4] += c.r[11];  // 0609DDA0 add r11,r4
    c.r[1] = ld32(0x0609DE78u);  // 0609DDA2 mov.l 0x0609DE78,r1
    c.r[6] = 0x14u;  // 0609DDA4 mov #20,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0609DDAAu; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DDAAu) return; }  // 0609DDA6 jsr @r1 ; mov r3,r5
    c.r[2] = ld32(c.r[8]);  // 0609DDAA mov.l @r8,r2
    c.macl = c.r[2] * c.r[10];  // 0609DDAC mul.l r10,r2
    c.r[7] = c.r[9];  // 0609DDAE mov r9,r7
    c.r[0] = c.r[15];  // 0609DDB0 mov r15,r0
    c.r[1] = c.macl;  // 0609DDB2 sts macl,r1
    c.r[1] += 80;  // 0609DDB4 add #80,r1
    c.r[7] += c.r[1];  // 0609DDB6 add r1,r7
    c.r[6] = c.r[7];  // 0609DDB8 mov r7,r6
    c.r[6] += 44;  // 0609DDBA add #44,r6
    c.r[3] = c.r[7];  // 0609DDBC mov r7,r3
    c.r[3] += 62;  // 0609DDBE add #62,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE62u);  // 0609DDC0 mov.w 0x0609DE62,r1
    c.r[2] -= 1;  // 0609DDC2 add #-1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609DDC4 mov.w @(r0,r1),r1
    c.macl = c.r[2] * c.r[10];  // 0609DDC6 mul.l r10,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609DDC8 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DDCA swap.b r1,r1
    st16(c.r[3], c.r[1]);  // 0609DDCC mov.w r1,@r3
    c.r[3] = c.r[7];  // 0609DDCE mov r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE64u);  // 0609DDD0 mov.w 0x0609DE64,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609DDD2 mov.w @(r0,r1),r1
    c.r[3] += 58;  // 0609DDD4 add #58,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609DDD6 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DDD8 swap.b r1,r1
    st16(c.r[3], c.r[1]);  // 0609DDDA mov.w r1,@r3
    c.r[3] = c.r[9];  // 0609DDDC mov r9,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0609DDDE mov.w @(r0,r11),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609DE66u);  // 0609DDE0 mov.w 0x0609DE66,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609DDE2 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DDE4 swap.b r1,r1
    st16(c.r[6], c.r[1]);  // 0609DDE6 mov.w r1,@r6
    c.r[1] = c.macl;  // 0609DDE8 sts macl,r1
    c.r[3] += c.r[1];  // 0609DDEA add r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE68u);  // 0609DDEC mov.w 0x0609DE68,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609DDEE mov.l @(r0,r1),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DDF0 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DDF2 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DDF4 swap.b r1,r1
    c.r[0] = c.r[3];  // 0609DDF6 mov r3,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609DDF8 mov.l r1,@(r0,r2)
    st32(c.r[7] + 48, c.r[1]);  // 0609DDFA mov.l r1,@(48,r7)
    c.r[2] = c.r[7];  // 0609DDFC mov r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE6Au);  // 0609DDFE mov.w 0x0609DE6A,r1
    c.r[0] = c.r[15];  // 0609DE00 mov r15,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609DE02 mov.w @(r0,r1),r1
    c.r[2] += 46;  // 0609DE04 add #46,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609DE06 extu.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DE08 swap.b r1,r1
    st16(c.r[2], c.r[1]);  // 0609DE0A mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609DE6Cu);  // 0609DE0C mov.w 0x0609DE6C,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609DE0E mov.l @(r0,r1),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DE10 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609DE12 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609DE14 swap.b r1,r1
    st32(c.r[7] + 52, c.r[1]); goto L_0609DE40;  // 0609DE16 bra 0x0609DE40 ; mov.l r1,@(52,r7)
L_0609DE1A:
    c.r[1] = c.r[9];  // 0609DE1A mov r9,r1
L_0609DE1C:
    c.r[1] += 108;  // 0609DE1C add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609DE1E mov.l @r1,r4
    c.r[1] = ld32(0x0609DE7Cu);  // 0609DE20 mov.l 0x0609DE7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609DE26u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DE26u) return; }  // 0609DE22 jsr @r1 ; mov r6,r5
    c.r[0] = 0x1u; goto L_0609DE42;  // 0609DE26 bra 0x0609DE42 ; mov #1,r0
L_0609DE2A:
    c.r[1] = ld32(0x0609DE74u);  // 0609DE2A mov.l 0x0609DE74,r1
    c.r[2] = ld32(c.r[1]);  // 0609DE2C mov.l @r1,r2
    c.r[1] = 0x64u;  // 0609DE2E mov #100,r1
    c.macl = c.r[2] * c.r[1];  // 0609DE30 mul.l r1,r2
    c.r[6] = 0x18u;  // 0609DE32 mov #24,r6
    c.r[5] = c.r[3];  // 0609DE34 mov r3,r5
    c.r[4] = c.macl;  // 0609DE36 sts macl,r4
    c.r[4] += c.r[9];  // 0609DE38 add r9,r4
    c.r[1] = ld32(0x0609DE78u);  // 0609DE3A mov.l 0x0609DE78,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609DE40u; c.r[4] += 100; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DE40u) return; }  // 0609DE3C jsr @r1 ; add #100,r4
L_0609DE40:
    c.r[0] = 0x0u;  // 0609DE40 mov #0,r0
L_0609DE42:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609DE6Eu);  // 0609DE42 mov.w 0x0609DE6E,r3
    c.r[15] += c.r[3];  // 0609DE44 add r3,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609DE46 lds.l @r15+,pr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609DE48 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609DE4A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609DE4C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609DE4E rts ; mov.l @r15+,r8
}

void f_0609DE80(SH2Context& c) {
    ran[2553] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609DE80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609DE82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609DE84 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609DE86 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609DE88 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609DE8A sts.l pr,@-r15
    c.r[15] -= 8;  // 0609DE8C add #-8,r15
    c.r[11] = c.r[4];  // 0609DE8E mov r4,r11
    c.r[9] = c.r[6];  // 0609DE90 mov r6,r9
    c.r[1] = 0x8u;  // 0609DE92 mov #8,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0609DE94 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[5]; if (k) { goto L_0609DF1C; } }  // 0609DE96 bf/s 0x0609DF1C ; mov r5,r8
    c.r[10] = c.r[15];  // 0609DE9A mov r15,r10
    c.r[10] += 4;  // 0609DE9C add #4,r10
    c.r[12] = ld32(0x0609DF2Cu);  // 0609DE9E mov.l 0x0609DF2C,r12
    c.r[1] = c.r[8];  // 0609DEA0 mov r8,r1
L_0609DEA2:
    c.r[1] += 4;  // 0609DEA2 add #4,r1
    c.r[2] = c.r[15];  // 0609DEA4 mov r15,r2
    c.r[2] += 1;  // 0609DEA6 add #1,r2
    c.r[6] = c.r[8];  // 0609DEA8 mov r8,r6
    c.r[6] += 5;  // 0609DEAA add #5,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609DEAC mov.b @r1,r1
    c.r[3] = c.r[15];  // 0609DEAE mov r15,r3
    st8(c.r[15], c.r[1]);  // 0609DEB0 mov.b r1,@r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0609DEB2 mov.b @r6,r1
    c.r[3] += 5;  // 0609DEB4 add #5,r3
    st8(c.r[2], c.r[1]);  // 0609DEB6 mov.b r1,@r2
    c.r[6] = c.r[8];  // 0609DEB8 mov r8,r6
    c.r[6] += 6;  // 0609DEBA add #6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0609DEBC mov.b @r6,r1
    c.r[2] += 1;  // 0609DEBE add #1,r2
    st8(c.r[2], c.r[1]);  // 0609DEC0 mov.b r1,@r2
    c.r[6] = c.r[8];  // 0609DEC2 mov r8,r6
    c.r[6] += 7;  // 0609DEC4 add #7,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0609DEC6 mov.b @r6,r1
    c.r[2] += 1;  // 0609DEC8 add #1,r2
    st8(c.r[2], c.r[1]);  // 0609DECA mov.b r1,@r2
    c.r[1] = c.r[8];  // 0609DECC mov r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609DECE mov.b @r1+,r2
    c.r[4] = c.r[11];  // 0609DED0 mov r11,r4
    st8(c.r[10], c.r[2]);  // 0609DED2 mov.b r2,@r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609DED4 mov.b @r1+,r2
    c.r[6] = c.r[8];  // 0609DED6 mov r8,r6
    st8(c.r[3], c.r[2]);  // 0609DED8 mov.b r2,@r3
    c.r[3] = c.r[15];  // 0609DEDA mov r15,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609DEDC mov.b @r1+,r2
    c.r[3] += 6;  // 0609DEDE add #6,r3
    st8(c.r[3], c.r[2]);  // 0609DEE0 mov.b r2,@r3
    c.r[3] = c.r[15];  // 0609DEE2 mov r15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609DEE4 mov.b @r1,r1
    c.r[3] += 7;  // 0609DEE6 add #7,r3
    st8(c.r[3], c.r[1]);  // 0609DEE8 mov.b r1,@r3
    c.r[1] = ld32(c.r[15]);  // 0609DEEA mov.l @r15,r1
    c.r[6] += 8;  // 0609DEEC add #8,r6
    c.r[7] = c.r[1];  // 0609DEEE mov r1,r7
    c.r[7] = (c.r[7] & 0xFFFF0000u) | (c.r[7] & 0xFFu) << 8 | (c.r[7] >> 8 & 0xFFu);  // 0609DEF0 swap.b r7,r7
    c.r[7] = c.r[7] << 16 | c.r[7] >> 16;  // 0609DEF2 swap.w r7,r7
    c.r[7] = (c.r[7] & 0xFFFF0000u) | (c.r[7] & 0xFFu) << 8 | (c.r[7] >> 8 & 0xFFu);  // 0609DEF4 swap.b r7,r7
    c.r[1] = ld32(c.r[15] + 4);  // 0609DEF6 mov.l @(4,r15),r1
    st32(c.r[15], c.r[7]);  // 0609DEF8 mov.l r7,@r15
    c.r[5] = c.r[1];  // 0609DEFA mov r1,r5
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 0609DEFC swap.b r5,r5
    c.r[5] = c.r[5] << 16 | c.r[5] >> 16;  // 0609DEFE swap.w r5,r5
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 0609DF00 swap.b r5,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0609DF06u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DF06u) return; }  // 0609DF02 jsr @r12 ; nop
    c.r[2] = c.r[9];  // 0609DF06 mov r9,r2
    c.r[2] -= 8;  // 0609DF08 add #-8,r2
    c.r[1] = ld32(c.r[15]);  // 0609DF0A mov.l @r15,r1
    c.r[9] = c.r[2];  // 0609DF0C mov r2,r9
    c.r[9] -= c.r[1];  // 0609DF0E sub r1,r9
    c.r[1] += 8;  // 0609DF10 add #8,r1
    c.r[8] += c.r[1];  // 0609DF12 add r1,r8
    c.r[1] = 0x8u;  // 0609DF14 mov #8,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0609DF16 cmp/gt r1,r9
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_0609DEA2; } }  // 0609DF18 bt/s 0x0609DEA2 ; mov r8,r1
L_0609DF1C:
    c.r[15] += 8;  // 0609DF1C add #8,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609DF1E lds.l @r15+,pr
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609DF20 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609DF22 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609DF24 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609DF26 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609DF28 rts ; mov.l @r15+,r8
}

void f_0609DF30(SH2Context& c) {
    ran[2554] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609DF30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609DF32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609DF34 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609DF36 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609DF38 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609DF3A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609DF3C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609DF3E sts.l pr,@-r15
    c.r[15] -= 8;  // 0609DF40 add #-8,r15
    c.r[10] = c.r[4];  // 0609DF42 mov r4,r10
    c.r[9] = c.r[5];  // 0609DF44 mov r5,r9
    c.r[13] = c.r[6];  // 0609DF46 mov r6,r13
    c.r[12] = c.r[7];  // 0609DF48 mov r7,r12
    c.r[11] = c.r[10];  // 0609DF4A mov r10,r11
    c.r[11] += 108;  // 0609DF4C add #108,r11
    c.r[4] = ld32(c.r[11]);  // 0609DF4E mov.l @r11,r4
    c.r[14] = ld32(0x0609E044u);  // 0609DF50 mov.l 0x0609E044,r14
    c.r[6] = 0x8u;  // 0609DF52 mov #8,r6
    { const uint32_t x = c.r[14]; c.pr = 0x0609DF58u; c.r[5] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DF58u) return; }  // 0609DF54 jsr @r14 ; mov r15,r5
    c.t = c.r[0] == 0x8u;  // 0609DF58 cmp/eq #8,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_0609DF66; } }  // 0609DF5A bt/s 0x0609DF66 ; mov r0,r1
L_0609DF5E:
    c.t = (int32_t)c.r[1] >= 0;  // 0609DF5E cmp/pz r1
L_0609DF60:
    if (!c.t) { goto L_0609E02A; }  // 0609DF60 bf 0x0609E02A
L_0609DF62:
    c.r[0] = 0x0u; goto L_0609E02A;  // 0609DF62 bra 0x0609E02A ; mov #0,r0
L_0609DF66:
    c.r[1] = ld32(c.r[15]);  // 0609DF66 mov.l @r15,r1
    c.r[2] = c.r[1];  // 0609DF68 mov r1,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609DF6A swap.b r2,r2
    c.r[2] = c.r[2] << 16 | c.r[2] >> 16;  // 0609DF6C swap.w r2,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609DF6E swap.b r2,r2
    st32(c.r[9], c.r[2]);  // 0609DF70 mov.l r2,@r9
    c.r[1] = ld32(c.r[15] + 4);  // 0609DF72 mov.l @(4,r15),r1
    c.r[8] = c.r[1];  // 0609DF74 mov r1,r8
    c.r[8] = (c.r[8] & 0xFFFF0000u) | (c.r[8] & 0xFFu) << 8 | (c.r[8] >> 8 & 0xFFu);  // 0609DF76 swap.b r8,r8
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16;  // 0609DF78 swap.w r8,r8
    c.r[8] = (c.r[8] & 0xFFFF0000u) | (c.r[8] & 0xFFu) << 8 | (c.r[8] >> 8 & 0xFFu);  // 0609DF7A swap.b r8,r8
    c.r[1] = ld32(0x0609E048u);  // 0609DF7C mov.l 0x0609E048,r1
    c.t = c.r[2] == c.r[1];  // 0609DF7E cmp/eq r1,r2
    if (!c.t) { goto L_0609DFD2; }  // 0609DF80 bf 0x0609DFD2
    c.r[4] = ld32(c.r[11]);  // 0609DF82 mov.l @r11,r4
    c.r[6] = 0x4u;  // 0609DF84 mov #4,r6
    { const uint32_t x = c.r[14]; c.pr = 0x0609DF8Au; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DF8Au) return; }  // 0609DF86 jsr @r14 ; mov r9,r5
    c.t = c.r[0] == 0x4u;  // 0609DF8A cmp/eq #4,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0609DF5E; } }  // 0609DF8C bf/s 0x0609DF5E ; mov r0,r1
    c.r[1] = ld32(c.r[9]);  // 0609DF90 mov.l @r9,r1
    c.r[8] -= 4;  // 0609DF92 add #-4,r8
    c.r[2] = c.r[1];  // 0609DF94 mov r1,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609DF96 swap.b r2,r2
    c.r[2] = c.r[2] << 16 | c.r[2] >> 16;  // 0609DF98 swap.w r2,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609DF9A swap.b r2,r2
    c.r[1] = ld32(0x0609E04Cu);  // 0609DF9C mov.l 0x0609E04C,r1
    c.t = c.r[2] == c.r[1];  // 0609DF9E cmp/eq r1,r2
    { const bool k = !c.t; st32(c.r[9], c.r[2]); if (k) { goto L_0609DFD2; } }  // 0609DFA0 bf/s 0x0609DFD2 ; mov.l r2,@r9
    c.r[14] = ld32(0x0609E050u);  // 0609DFA4 mov.l 0x0609E050,r14
    c.r[6] = c.t;  // 0609DFA6 movt r6
    c.r[4] = ld32(c.r[11]);  // 0609DFA8 mov.l @r11,r4
    { const uint32_t x = c.r[14]; c.pr = 0x0609DFAEu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DFAEu) return; }  // 0609DFAA jsr @r14 ; mov #0,r5
    c.r[1] = c.r[0];  // 0609DFAE mov r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609E03Eu);  // 0609DFB0 mov.w 0x0609E03E,r2
    c.r[1] += 4;  // 0609DFB2 add #4,r1
    c.r[0] = c.r[10];  // 0609DFB4 mov r10,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609DFB6 mov.l r1,@(r0,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E040u);  // 0609DFB8 mov.w 0x0609E040,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609DFBA mov.l @(r0,r1),r1
    c.r[1] += 68;  // 0609DFBC add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609DFBE mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609DFC0 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609E02A; } }  // 0609DFC2 bf/s 0x0609E02A ; mov #0,r0
    c.r[4] = ld32(c.r[11]);  // 0609DFC6 mov.l @r11,r4
    c.r[6] = c.t;  // 0609DFC8 movt r6
    { const uint32_t x = c.r[14]; c.pr = 0x0609DFCEu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DFCEu) return; }  // 0609DFCA jsr @r14 ; mov r8,r5
    goto L_0609E000;  // 0609DFCE bra 0x0609E000 ; nop
L_0609DFD2:
    c.r[2] = ld32(c.r[9]);  // 0609DFD2 mov.l @r9,r2
    c.r[1] = ld32(0x0609E054u);  // 0609DFD4 mov.l 0x0609E054,r1
    c.t = c.r[2] == c.r[1];  // 0609DFD6 cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0609E02A; } }  // 0609DFD8 bt/s 0x0609E02A ; mov r8,r0
    c.r[1] = ld32(0x0609E058u);  // 0609DFDC mov.l 0x0609E058,r1
    c.t = c.r[2] == c.r[1];  // 0609DFDE cmp/eq r1,r2
    if (c.t) { goto L_0609E02A; }  // 0609DFE0 bt 0x0609E02A
    c.r[1] = ld32(0x0609E05Cu);  // 0609DFE2 mov.l 0x0609E05C,r1
    c.t = c.r[2] == c.r[1];  // 0609DFE4 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[8] > (int32_t)c.r[12]; if (k) { goto L_0609E010; } }  // 0609DFE6 bf/s 0x0609E010 ; cmp/gt r12,r8
    c.r[1] = c.r[10];  // 0609DFEA mov r10,r1
    c.r[1] += 108;  // 0609DFEC add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609DFEE mov.l @r1,r4
    c.r[0] = ld32(0x0609E044u);  // 0609DFF0 mov.l 0x0609E044,r0
    c.r[6] = c.r[8];  // 0609DFF2 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609DFF8u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609DFF8u) return; }  // 0609DFF4 jsr @r0 ; mov #0,r5
    c.r[1] = c.r[0];  // 0609DFF8 mov r0,r1
    c.t = c.r[1] == c.r[8];  // 0609DFFA cmp/eq r8,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] >= 0; if (k) { SH2_POLL(c); goto L_0609DF60; } }  // 0609DFFC bf/s 0x0609DF60 ; cmp/pz r1
L_0609E000:
    c.r[0] = ld32(0x0609E060u);  // 0609E000 mov.l 0x0609E060,r0
    c.r[7] = c.r[12];  // 0609E002 mov r12,r7
    c.r[6] = c.r[13];  // 0609E004 mov r13,r6
    c.r[5] = c.r[9];  // 0609E006 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609E00Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E00Cu) return; }  // 0609E008 jsr @r0 ; mov r10,r4
    c.r[15] += 8; goto L_0609E02C;  // 0609E00C bra 0x0609E02C ; add #8,r15
L_0609E010:
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { SH2_POLL(c); goto L_0609DF62; } }  // 0609E010 bt/s 0x0609DF62 ; mov r10,r1
    c.r[1] += 108;  // 0609E014 add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609E016 mov.l @r1,r4
    c.r[0] = ld32(0x0609E044u);  // 0609E018 mov.l 0x0609E044,r0
    c.r[6] = c.r[8];  // 0609E01A mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609E020u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E020u) return; }  // 0609E01C jsr @r0 ; mov r13,r5
    c.r[1] = c.r[0];  // 0609E020 mov r0,r1
    c.t = c.r[1] == c.r[8];  // 0609E022 cmp/eq r8,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] >= 0; if (k) { SH2_POLL(c); goto L_0609DF60; } }  // 0609E024 bf/s 0x0609DF60 ; cmp/pz r1
    c.r[0] = c.r[8];  // 0609E028 mov r8,r0
L_0609E02A:
    c.r[15] += 8;  // 0609E02A add #8,r15
L_0609E02C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E02C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609E02E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609E030 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609E032 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609E034 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609E036 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609E038 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E03A rts ; mov.l @r15+,r8
}

void f_0609E064(SH2Context& c) {
    ran[2555] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E064 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609E066 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609E068 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609E06A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E06C sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609E06E mov r4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E0C2u);  // 0609E070 mov.w 0x0609E0C2,r0
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 0609E072 mov.l @(r0,r8),r4
    c.r[1] = c.r[4];  // 0609E074 mov r4,r1
    c.r[1] += 68;  // 0609E076 add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609E078 mov.l @r1,r1
    c.r[15] -= 4;  // 0609E07A add #-4,r15
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609E07C tst r1,r1
    { const bool k = !c.t; c.r[9] = ld32(c.r[5] + 8); if (k) { goto L_0609E08C; } }  // 0609E07E bf/s 0x0609E08C ; mov.l @(8,r5),r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E0C4u);  // 0609E082 mov.w 0x0609E0C4,r0
    c.r[6] = ld32(c.r[0] + c.r[8]);  // 0609E084 mov.l @(r0,r8),r6
    c.r[1] = ld32(0x0609E0CCu);  // 0609E086 mov.l 0x0609E0CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E08Cu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E08Cu) return; }  // 0609E088 jsr @r1 ; mov r9,r5
L_0609E08C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E0C6u);  // 0609E08C mov.w 0x0609E0C6,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609E08E mov.l @(r0,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609E090 tst r1,r1
    if (!c.t) { goto L_0609E0B4; }  // 0609E092 bf 0x0609E0B4
    c.r[11] = ld32(0x0609E0D0u);  // 0609E094 mov.l 0x0609E0D0,r11
    c.r[10] = ld32(0x0609E0D4u);  // 0609E096 mov.l 0x0609E0D4,r10
L_0609E098:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609E0C8u);  // 0609E098 mov.w 0x0609E0C8,r7
    c.r[6] = c.r[9];  // 0609E09A mov r9,r6
    c.r[5] = c.r[15];  // 0609E09C mov r15,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0609E0A2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E0A2u) return; }  // 0609E09E jsr @r11 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609E0A2 tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_0609E0B4; } }  // 0609E0A4 bt/s 0x0609E0B4 ; mov r0,r7
    c.r[6] = c.r[9];  // 0609E0A8 mov r9,r6
    c.r[5] = ld32(c.r[15]);  // 0609E0AA mov.l @r15,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0609E0B0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E0B0u) return; }  // 0609E0AC jsr @r10 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609E0B0 tst r0,r0
    if (c.t) { SH2_POLL(c); goto L_0609E098; }  // 0609E0B2 bt 0x0609E098
L_0609E0B4:
    c.r[15] += 4;  // 0609E0B4 add #4,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E0B6 lds.l @r15+,pr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609E0B8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609E0BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609E0BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E0BE rts ; mov.l @r15+,r8
}

void f_0609E0D8(SH2Context& c) {
    ran[2556] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E0D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609E0DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609E0DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609E0DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609E0E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609E0E2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E0E4 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609E0E6 add #-16,r15
    c.r[10] = c.r[4];  // 0609E0E8 mov r4,r10
    c.r[11] = c.r[5];  // 0609E0EA mov r5,r11
    c.r[1] = c.r[10];  // 0609E0EC mov r10,r1
    c.r[1] += 108;  // 0609E0EE add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609E0F0 mov.l @r1,r4
    c.r[0] = ld32(0x0609E1A4u);  // 0609E0F2 mov.l 0x0609E1A4,r0
    c.r[6] = 0xCu;  // 0609E0F4 mov #12,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609E0FAu; c.r[5] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E0FAu) return; }  // 0609E0F6 jsr @r0 ; mov r15,r5
    c.t = c.r[0] == 0xCu;  // 0609E0FA cmp/eq #12,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFDu; if (k) { goto L_0609E188; } }  // 0609E0FC bf/s 0x0609E188 ; mov #-3,r0
    c.r[1] = ld32(c.r[15]);  // 0609E100 mov.l @r15,r1
    c.r[2] = c.r[1];  // 0609E102 mov r1,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609E104 swap.b r2,r2
    c.r[2] = c.r[2] << 16 | c.r[2] >> 16;  // 0609E106 swap.w r2,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609E108 swap.b r2,r2
    c.r[1] = ld32(0x0609E1A8u);  // 0609E10A mov.l 0x0609E1A8,r1
    c.t = c.r[2] == c.r[1];  // 0609E10C cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFBu; if (k) { goto L_0609E188; } }  // 0609E10E bf/s 0x0609E188 ; mov #-5,r0
    c.r[1] = ld32(c.r[15] + 8);  // 0609E112 mov.l @(8,r15),r1
    c.r[2] = c.r[1];  // 0609E114 mov r1,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609E116 swap.b r2,r2
    c.r[2] = c.r[2] << 16 | c.r[2] >> 16;  // 0609E118 swap.w r2,r2
    c.r[2] = (c.r[2] & 0xFFFF0000u) | (c.r[2] & 0xFFu) << 8 | (c.r[2] >> 8 & 0xFFu);  // 0609E11A swap.b r2,r2
    c.r[1] = ld32(0x0609E1ACu);  // 0609E11C mov.l 0x0609E1AC,r1
    c.t = c.r[2] == c.r[1];  // 0609E11E cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF9u; if (k) { goto L_0609E188; } }  // 0609E120 bf/s 0x0609E188 ; mov #-7,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609E19Au);  // 0609E124 mov.w 0x0609E19A,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609E19Cu);  // 0609E126 mov.w 0x0609E19C,r3
    c.r[1] = 0xFFFFFFFFu;  // 0609E128 mov #-1,r1
    c.r[0] = c.r[10];  // 0609E12A mov r10,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 0609E12C mov.l r1,@(r0,r3)
    c.t = (c.r[11] & c.r[11]) == 0;  // 0609E12E tst r11,r11
    { const bool k = !c.t; st32(c.r[0] + c.r[2], c.r[1]); if (k) { goto L_0609E140; } }  // 0609E130 bf/s 0x0609E140 ; mov.l r1,@(r0,r2)
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609E19Eu);  // 0609E134 mov.w 0x0609E19E,r4
    c.r[0] = ld32(0x0609E1B0u);  // 0609E136 mov.l 0x0609E1B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609E13Cu; c.r[5] = c.t; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E13Cu) return; }  // 0609E138 jsr @r0 ; movt r5
    c.r[9] = c.r[0]; goto L_0609E148;  // 0609E13C bra 0x0609E148 ; mov r0,r9
L_0609E140:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E1A0u);  // 0609E140 mov.w 0x0609E1A0,r0
    st32(c.r[0] + c.r[10], c.r[11]);  // 0609E142 mov.l r11,@(r0,r10)
    st32(c.r[11], c.r[10]);  // 0609E144 mov.l r10,@r11
    c.r[9] = ld32(c.r[11] + 8);  // 0609E146 mov.l @(8,r11),r9
L_0609E148:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609E148 tst r9,r9
    { const bool k = c.t; c.r[0] = 0xFFFFFFF8u; if (k) { goto L_0609E188; } }  // 0609E14A bt/s 0x0609E188 ; mov #-8,r0
    c.r[13] = ld32(0x0609E1B4u);  // 0609E14E mov.l 0x0609E1B4,r13
    c.r[12] = ld32(0x0609E1B8u);  // 0609E150 mov.l 0x0609E1B8,r12
L_0609E152:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609E19Eu);  // 0609E152 mov.w 0x0609E19E,r7
    c.r[6] = c.r[9];  // 0609E154 mov r9,r6
    c.r[5] = c.r[15];  // 0609E156 mov r15,r5
    c.r[5] += 12;  // 0609E158 add #12,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0609E15Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E15Eu) return; }  // 0609E15A jsr @r13 ; mov r10,r4
    c.r[8] = c.r[0];  // 0609E15E mov r0,r8
    c.t = (int32_t)c.r[8] > 0;  // 0609E160 cmp/pl r8
    { const bool k = !c.t; c.r[5] = ld32(c.r[15] + 12); if (k) { goto L_0609E172; } }  // 0609E162 bf/s 0x0609E172 ; mov.l @(12,r15),r5
    c.r[7] = c.r[8];  // 0609E166 mov r8,r7
    c.r[6] = c.r[9];  // 0609E168 mov r9,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0609E16Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E16Eu) return; }  // 0609E16A jsr @r12 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609E16E tst r0,r0
    if (c.t) { SH2_POLL(c); goto L_0609E152; }  // 0609E170 bt 0x0609E152
L_0609E172:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E1A2u);  // 0609E172 mov.w 0x0609E1A2,r0
    c.t = (c.r[11] & c.r[11]) == 0;  // 0609E174 tst r11,r11
    { const bool k = !c.t; st32(c.r[0] + c.r[10], c.r[8]); if (k) { goto L_0609E180; } }  // 0609E176 bf/s 0x0609E180 ; mov.l r8,@(r0,r10)
    c.r[1] = ld32(0x0609E1BCu);  // 0609E17A mov.l 0x0609E1BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E180u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E180u) return; }  // 0609E17C jsr @r1 ; mov r9,r4
L_0609E180:
    c.t = (int32_t)c.r[8] >= 0;  // 0609E180 cmp/pz r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_0609E188; } }  // 0609E182 bf/s 0x0609E188 ; mov r8,r0
    c.r[0] = 0x0u;  // 0609E186 mov #0,r0
L_0609E188:
    c.r[15] += 16;  // 0609E188 add #16,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E18A lds.l @r15+,pr
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609E18C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609E18E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609E190 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609E192 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609E194 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E196 rts ; mov.l @r15+,r8
}

void f_0609E1C0(SH2Context& c) {
    ran[2557] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E1C0 mov.l r8,@-r15
    c.r[8] = c.r[4];  // 0609E1C2 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609E1C4 tst r8,r8
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.pr); if (k) { goto L_0609E1F6; } }  // 0609E1C6 bt/s 0x0609E1F6 ; sts.l pr,@-r15
    c.r[1] = c.r[8];  // 0609E1CA mov r8,r1
    c.r[1] += 108;  // 0609E1CC add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609E1CE mov.l @r1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0609E1D0 cmp/pz r4
    if (!c.t) { goto L_0609E1DA; }  // 0609E1D2 bf 0x0609E1DA
    c.r[1] = ld32(0x0609E200u);  // 0609E1D4 mov.l 0x0609E200,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E1DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E1DAu) return; }  // 0609E1D6 jsr @r1 ; nop
L_0609E1DA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E1FCu);  // 0609E1DA mov.w 0x0609E1FC,r0
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 0609E1DC mov.l @(r0,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609E1DE tst r4,r4
    if (c.t) { goto L_0609E1E8; }  // 0609E1E0 bt 0x0609E1E8
    c.r[1] = ld32(0x0609E204u);  // 0609E1E2 mov.l 0x0609E204,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E1E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E1E8u) return; }  // 0609E1E4 jsr @r1 ; nop
L_0609E1E8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E1FEu);  // 0609E1E8 mov.w 0x0609E1FE,r0
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 0609E1EA mov.l @(r0,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609E1EC tst r4,r4
    if (c.t) { goto L_0609E1F6; }  // 0609E1EE bt 0x0609E1F6
    c.r[1] = ld32(0x0609E204u);  // 0609E1F0 mov.l 0x0609E204,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E1F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E1F6u) return; }  // 0609E1F2 jsr @r1 ; nop
L_0609E1F6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E1F6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E1F8 rts ; mov.l @r15+,r8
}

void f_0609E208(SH2Context& c) {
    ran[2558] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E208 sts.l pr,@-r15
    c.r[1] = c.r[4];  // 0609E20A mov r4,r1
    c.r[1] += 104;  // 0609E20C add #104,r1
    c.r[2] = c.r[4];  // 0609E20E mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 0609E210 mov.l @r1,r1
    c.r[2] += 100;  // 0609E212 add #100,r2
    c.r[2] = ld32(c.r[2]);  // 0609E214 mov.l @r2,r2
    c.r[1] -= c.r[2];  // 0609E216 sub r2,r1
    c.r[2] = 0x64u;  // 0609E218 mov #100,r2
    c.macl = c.r[1] * c.r[2];  // 0609E21A mul.l r2,r1
    c.r[5] = ld32(c.r[4] + 20);  // 0609E21C mov.l @(20,r4),r5
    c.r[1] = ld32(0x0609E22Cu);  // 0609E21E mov.l 0x0609E22C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E224u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E224u) return; }  // 0609E220 jsr @r1 ; sts macl,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E224 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609E226 rts ; nop
}

void f_0609E234(SH2Context& c) {
    ran[2559] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E234 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609E236 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609E238 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E23A sts.l pr,@-r15
    c.r[7] = c.r[4];  // 0609E23C mov r4,r7
    c.r[6] = c.r[5];  // 0609E23E mov r5,r6
    c.r[4] = ld32(0x0609E2E4u);  // 0609E240 mov.l 0x0609E2E4,r4
    c.r[1] = ld32(c.r[7]);  // 0609E242 mov.l @r7,r1
    c.r[9] = c.r[7];  // 0609E244 mov r7,r9
    c.r[1] += 116;  // 0609E246 add #116,r1
    c.r[5] = ld32(c.r[1]);  // 0609E248 mov.l @r1,r5
    c.r[9] += 92;  // 0609E24A add #92,r9
    c.r[1] = ld32(0x0609E2E8u);  // 0609E24C mov.l 0x0609E2E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E252u; c.r[5] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E252u) return; }  // 0609E24E jsr @r1 ; add #-1,r5
    c.r[1] = 0x0u;  // 0609E252 mov #0,r1
    st32(c.r[9], c.r[1]);  // 0609E254 mov.l r1,@r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E2D8u);  // 0609E256 mov.w 0x0609E2D8,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0609E258 cmp/gt r1,r6
    { const bool k = !c.t; c.r[8] = c.r[0]; if (k) { goto L_0609E282; } }  // 0609E25A bf/s 0x0609E282 ; mov r0,r8
    c.r[2] = c.r[7];  // 0609E25E mov r7,r2
    c.r[1] = c.r[7];  // 0609E260 mov r7,r1
    c.r[1] += 84;  // 0609E262 add #84,r1
    c.r[4] = ld32(c.r[1]);  // 0609E264 mov.l @r1,r4
    c.r[1] = c.r[4];  // 0609E266 mov r4,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 0609E268 rotl r1
    c.r[1] = c.t;  // 0609E26A movt r1
    c.r[1] += c.r[4];  // 0609E26C add r4,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609E26E shar r1
    c.r[4] += c.r[1];  // 0609E270 add r1,r4
    c.r[1] = ld32(0x0609E2ECu);  // 0609E272 mov.l 0x0609E2EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E278u; c.r[2] += 88; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E278u) return; }  // 0609E274 jsr @r1 ; add #88,r2
    c.r[4] <<= 8;  // 0609E278 shll8 r4
    c.r[4] += c.r[4];  // 0609E27A add r4,r4
    c.r[4] <<= 2;  // 0609E27C shll2 r4
    st32(c.r[2], c.r[4]); goto L_0609E2CE;  // 0609E27E bra 0x0609E2CE ; mov.l r4,@r2
L_0609E282:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E2DAu);  // 0609E282 mov.w 0x0609E2DA,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0609E284 cmp/gt r1,r6
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609E2DCu);  // 0609E286 mov.w 0x0609E2DC,r6
    if (!c.t) { goto L_0609E28C; }  // 0609E288 bf 0x0609E28C
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609E2DEu);  // 0609E28A mov.w 0x0609E2DE,r6
L_0609E28C:
    c.r[4] = c.r[6];  // 0609E28C mov r6,r4
    c.r[4] <<= 8;  // 0609E28E shll8 r4
    c.r[4] <<= 2;  // 0609E290 shll2 r4
    c.r[10] = ld32(0x0609E2F0u);  // 0609E292 mov.l 0x0609E2F0,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0609E298u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E298u) return; }  // 0609E294 jsr @r10 ; mov r8,r5
    c.r[4] = c.r[0];  // 0609E298 mov r0,r4
    c.r[2] = ld32(0x0609E2ECu);  // 0609E29A mov.l 0x0609E2EC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0609E2A0u; c.r[4] += c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E2A0u) return; }  // 0609E29C jsr @r2 ; add r4,r4
    c.r[4] <<= 8;  // 0609E2A0 shll8 r4
    c.r[4] += c.r[4];  // 0609E2A2 add r4,r4
    c.r[4] <<= 2;  // 0609E2A4 shll2 r4
    c.macl = c.r[4] * c.r[8];  // 0609E2A6 mul.l r8,r4
    c.r[7] += 88;  // 0609E2A8 add #88,r7
    st32(c.r[7], c.r[4]);  // 0609E2AA mov.l r4,@r7
    c.r[4] = c.macl;  // 0609E2AC sts macl,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0609E2AE cmp/pz r4
    if (c.t) { goto L_0609E2B6; }  // 0609E2B0 bt 0x0609E2B6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E2E0u);  // 0609E2B2 mov.w 0x0609E2E0,r1
    c.r[4] += c.r[1];  // 0609E2B4 add r1,r4
L_0609E2B6:
    { const uint32_t x = c.r[2]; c.pr = 0x0609E2BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E2BAu) return; }  // 0609E2B6 jsr @r2 ; nop
    c.r[1] = c.r[4];  // 0609E2BA mov r4,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0609E2BC cmp/gt r1,r6
    { const bool k = !c.t; c.r[4] = c.r[8]; if (k) { goto L_0609E2CE; } }  // 0609E2BE bf/s 0x0609E2CE ; mov r8,r4
    c.r[4] -= 1;  // 0609E2C2 add #-1,r4
    c.r[5] = c.r[6];  // 0609E2C4 mov r6,r5
    c.r[5] -= c.r[1];  // 0609E2C6 sub r1,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0609E2CCu; c.r[4] += c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E2CCu) return; }  // 0609E2C8 jsr @r10 ; add r5,r4
    st32(c.r[9], c.r[0]);  // 0609E2CC mov.l r0,@r9
L_0609E2CE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E2CE lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609E2D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609E2D2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E2D4 rts ; mov.l @r15+,r8
}

void f_0609E2F4(SH2Context& c) {
    ran[2560] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E2F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609E2F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609E2F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609E2FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609E2FC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609E2FE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609E300 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E302 sts.l pr,@-r15
    c.r[11] = c.r[4];  // 0609E304 mov r4,r11
    c.r[2] = c.r[11];  // 0609E306 mov r11,r2
    c.r[2] += 120;  // 0609E308 add #120,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609E414u);  // 0609E30A mov.w 0x0609E414,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609E416u);  // 0609E30C mov.w 0x0609E416,r7
    c.r[1] = 0x0u;  // 0609E30E mov #0,r1
    c.r[0] = c.r[11];  // 0609E310 mov r11,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 0609E312 mov.l r1,@(r0,r7)
    st32(c.r[0] + c.r[3], c.r[1]);  // 0609E314 mov.l r1,@(r0,r3)
    st32(c.r[2], c.r[1]);  // 0609E316 mov.l r1,@r2
    c.r[2] = 0x0u;  // 0609E318 mov #0,r2
    c.r[4] = 0x3Bu;  // 0609E31A mov #59,r4
    c.r[7] = 0x0u;  // 0609E31C mov #0,r7
    c.r[3] = c.r[11];  // 0609E31E mov r11,r3
L_0609E320:
    c.r[1] = c.r[3];  // 0609E320 mov r3,r1
    c.r[1] += 124;  // 0609E322 add #124,r1
    st32(c.r[1], c.r[7]);  // 0609E324 mov.l r7,@r1
    c.r[2] += 1;  // 0609E326 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[4];  // 0609E328 cmp/gt r4,r2
    { const bool k = !c.t; c.r[3] += 4; if (k) { SH2_POLL(c); goto L_0609E320; } }  // 0609E32A bf/s 0x0609E320 ; add #4,r3
    c.t = (c.r[6] & c.r[6]) == 0;  // 0609E32E tst r6,r6
    if (c.t) { goto L_0609E352; }  // 0609E330 bt 0x0609E352
    c.r[12] = ld32(c.r[11] + 56);  // 0609E332 mov.l @(56,r11),r12
    c.r[2] = 0x0u;  // 0609E334 mov #0,r2
    c.r[3] = 0x9u;  // 0609E336 mov #9,r3
    c.r[1] = c.r[12];  // 0609E338 mov r12,r1
    c.r[1] += 7;  // 0609E33A add #7,r1
L_0609E33C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609E33C mov.b @r1,r0
    c.r[2] += 1;  // 0609E33E add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0609E340 cmp/gt r3,r2
    c.r[0] &= 0xF8u;  // 0609E342 and #248,r0
    st8(c.r[1], c.r[0]);  // 0609E344 mov.b r0,@r1
    { const bool k = !c.t; c.r[1] += 8; if (k) { SH2_POLL(c); goto L_0609E33C; } }  // 0609E346 bf/s 0x0609E33C ; add #8,r1
    c.r[1] = c.r[6];  // 0609E34A mov r6,r1
    c.r[1] += 16;  // 0609E34C add #16,r1
    st32(c.r[11] + 32, c.r[1]); goto L_0609E358;  // 0609E34E bra 0x0609E358 ; mov.l r1,@(32,r11)
L_0609E352:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E418u);  // 0609E352 mov.w 0x0609E418,r1
    st32(c.r[11] + 32, c.r[1]);  // 0609E354 mov.l r1,@(32,r11)
    st32(c.r[11] + 36, c.r[1]);  // 0609E356 mov.l r1,@(36,r11)
L_0609E358:
    c.r[1] = c.r[11];  // 0609E358 mov r11,r1
    c.r[1] += 72;  // 0609E35A add #72,r1
    st32(c.r[1], c.r[5]);  // 0609E35C mov.l r5,@r1
    c.r[10] = c.r[5];  // 0609E35E mov r5,r10
    c.r[10] <<= 2;  // 0609E360 shll2 r10
    c.r[10] += c.r[10];  // 0609E362 add r10,r10
    c.r[2] = ld32(c.r[11]);  // 0609E364 mov.l @r11,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E41Au);  // 0609E366 mov.w 0x0609E41A,r13
    c.r[9] = ld32(c.r[11] + 56);  // 0609E368 mov.l @(56,r11),r9
    c.r[0] = c.r[2];  // 0609E36A mov r2,r0
    c.r[8] = ld32(c.r[0] + c.r[13]);  // 0609E36C mov.l @(r0,r13),r8
    c.r[6] = 0x0u;  // 0609E36E mov #0,r6
    c.r[0] = c.r[9];  // 0609E370 mov r9,r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0609E372 mov.l @(r0,r10),r1
    c.r[2] += 108;  // 0609E374 add #108,r2
    c.r[4] = ld32(c.r[2]);  // 0609E376 mov.l @r2,r4
    c.r[8] += c.r[1];  // 0609E378 add r1,r8
    c.r[8] >>= 8;  // 0609E37A shlr8 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0609E37C shlr r8
    c.r[8] >>= 2;  // 0609E37E shlr2 r8
    c.r[8] <<= 8;  // 0609E380 shll8 r8
    c.r[8] += c.r[8];  // 0609E382 add r8,r8
    c.r[8] <<= 2;  // 0609E384 shll2 r8
    c.r[0] = ld32(0x0609E41Cu);  // 0609E386 mov.l 0x0609E41C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609E38Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E38Cu) return; }  // 0609E388 jsr @r0 ; mov r8,r5
    c.r[0] = c.r[9];  // 0609E38C mov r9,r0
    c.r[3] = ld32(c.r[0] + c.r[10]);  // 0609E38E mov.l @(r0,r10),r3
    c.r[14] = c.r[11];  // 0609E390 mov r11,r14
    c.r[1] = ld32(c.r[11] + 32);  // 0609E392 mov.l @(32,r11),r1
    c.r[2] = c.r[3];  // 0609E394 mov r3,r2
    c.r[2] += c.r[1];  // 0609E396 add r1,r2
    c.r[1] = ld32(c.r[11]);  // 0609E398 mov.l @r11,r1
    c.r[14] += 104;  // 0609E39A add #104,r14
    c.r[0] = c.r[1];  // 0609E39C mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0609E39E mov.l @(r0,r13),r1
    c.r[6] = ld32(0x0609E420u);  // 0609E3A0 mov.l 0x0609E420,r6
    c.r[1] += c.r[3];  // 0609E3A2 add r3,r1
    c.r[8] -= c.r[1];  // 0609E3A4 sub r1,r8
    c.r[2] += c.r[8];  // 0609E3A6 add r8,r2
    st32(c.r[14], c.r[2]);  // 0609E3A8 mov.l r2,@r14
    c.r[8] = c.r[11];  // 0609E3AA mov r11,r8
    c.r[8] += 96;  // 0609E3AC add #96,r8
    c.r[1] = ld32(c.r[11] + 20);  // 0609E3AE mov.l @(20,r11),r1
    c.r[4] = c.r[2];  // 0609E3B0 mov r2,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0609E3B6u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E3B6u) return; }  // 0609E3B2 jsr @r6 ; mov r1,r5
    c.r[3] = c.r[0];  // 0609E3B6 mov r0,r3
    c.macl = c.r[3] * c.r[1];  // 0609E3B8 mul.l r1,r3
    c.r[7] = c.r[2];  // 0609E3BA mov r2,r7
    c.r[0] = c.r[9];  // 0609E3BC mov r9,r0
    c.r[1] = c.macl;  // 0609E3BE sts macl,r1
    c.r[7] -= c.r[1];  // 0609E3C0 sub r1,r7
    st32(c.r[8], c.r[7]);  // 0609E3C2 mov.l r7,@r8
    c.r[2] = ld32(c.r[0] + c.r[10]);  // 0609E3C4 mov.l @(r0,r10),r2
    c.r[1] = ld32(c.r[11] + 32);  // 0609E3C6 mov.l @(32,r11),r1
    c.r[3] = ld32(c.r[11] + 20);  // 0609E3C8 mov.l @(20,r11),r3
    c.r[2] += c.r[1];  // 0609E3CA add r1,r2
    c.r[4] = c.r[2];  // 0609E3CC mov r2,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0609E3D2u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E3D2u) return; }  // 0609E3CE jsr @r6 ; mov r3,r5
    c.r[1] = c.r[0];  // 0609E3D2 mov r0,r1
    c.macl = c.r[1] * c.r[3];  // 0609E3D4 mul.l r3,r1
    c.r[12] = c.r[9];  // 0609E3D6 mov r9,r12
    c.r[12] += c.r[10];  // 0609E3D8 add r10,r12
    c.r[1] = c.macl;  // 0609E3DA sts macl,r1
    c.r[2] -= c.r[1];  // 0609E3DC sub r1,r2
    c.r[1] = c.r[12];  // 0609E3DE mov r12,r1
    c.r[1] += 4;  // 0609E3E0 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609E3E2 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609E3E4 extu.w r1,r1
    c.r[2] += c.r[1];  // 0609E3E6 add r1,r2
    c.t = c.r[2] > c.r[3];  // 0609E3E8 cmp/hi r3,r2
    if (!c.t) { goto L_0609E402; }  // 0609E3EA bf 0x0609E402
    c.r[2] = ld32(c.r[14]);  // 0609E3EC mov.l @r14,r2
    { const uint32_t x = c.r[6]; c.pr = 0x0609E3F2u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E3F2u) return; }  // 0609E3EE jsr @r6 ; mov r2,r4
    c.macl = c.r[0] * c.r[3];  // 0609E3F2 mul.l r3,r0
    c.r[1] = c.macl;  // 0609E3F4 sts macl,r1
    c.r[2] -= c.r[1];  // 0609E3F6 sub r1,r2
    c.t = c.r[7] >= c.r[2];  // 0609E3F8 cmp/hs r2,r7
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0609E402; } }  // 0609E3FA bt/s 0x0609E402 ; mov r7,r1
    c.r[1] += c.r[3];  // 0609E3FE add r3,r1
    st32(c.r[8], c.r[1]);  // 0609E400 mov.l r1,@r8
L_0609E402:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E402 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609E404 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609E406 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609E408 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609E40A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609E40C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609E40E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E410 rts ; mov.l @r15+,r8
}

void f_0609E424(SH2Context& c) {
    ran[2561] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E424 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609E426 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609E428 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609E42A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609E42C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609E42E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609E430 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E432 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609E516u);  // 0609E434 mov.w 0x0609E516,r3
    c.r[15] += c.r[3];  // 0609E436 add r3,r15
    c.r[12] = c.r[4];  // 0609E438 mov r4,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E43A mov.w 0x0609E518,r0
    st32(c.r[0] + c.r[15], c.r[5]);  // 0609E43C mov.l r5,@(r0,r15)
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E51Au);  // 0609E43E mov.w 0x0609E51A,r9
    c.r[9] += c.r[15];  // 0609E440 add r15,r9
    st32(c.r[9], c.r[6]);  // 0609E442 mov.l r6,@r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E51Cu);  // 0609E444 mov.w 0x0609E51C,r11
    c.r[11] += c.r[15];  // 0609E446 add r15,r11
    st32(c.r[11], c.r[7]);  // 0609E448 mov.l r7,@r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E51Eu);  // 0609E44A mov.w 0x0609E51E,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E44C mov.w 0x0609E518,r9
    c.r[9] += c.r[15];  // 0609E44E add r15,r9
    c.r[0] = c.r[1];  // 0609E450 mov r1,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E452 mov.w 0x0609E518,r13
    c.r[13] += c.r[15];  // 0609E454 add r15,r13
    c.r[11] = ld32(c.r[9]);  // 0609E456 mov.l @r9,r11
    c.r[2] = c.r[12];  // 0609E458 mov r12,r2
    st32(c.r[0] + c.r[11], c.r[12]);  // 0609E45A mov.l r12,@(r0,r11)
    c.r[13] = ld32(c.r[13]);  // 0609E45C mov.l @r13,r13
    c.r[2] += 76;  // 0609E45E add #76,r2
    c.r[1] = ld32(c.r[12] + 12);  // 0609E460 mov.l @(12,r12),r1
    st32(c.r[12], c.r[13]);  // 0609E462 mov.l r13,@r12
    st32(c.r[12] + 24, c.r[1]);  // 0609E464 mov.l r1,@(24,r12)
    c.r[1] = 0x0u;  // 0609E466 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0609E468 mov.l r1,@r2
    c.r[1] = ld32(c.r[12] + 8);  // 0609E46A mov.l @(8,r12),r1
    st32(c.r[12] + 28, c.r[1]);  // 0609E46C mov.l r1,@(28,r12)
    c.r[1] = ld32(c.r[12] + 60);  // 0609E46E mov.l @(60,r12),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609E470 tst r1,r1
    { const bool k = !c.t; c.r[10] = 0xFFFFFFFFu; if (k) { goto L_0609E47E; } }  // 0609E472 bf/s 0x0609E47E ; mov #-1,r10
    c.r[1] = c.r[12];  // 0609E476 mov r12,r1
    c.r[1] += 68;  // 0609E478 add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609E47A mov.l @r1,r1
    st32(c.r[12] + 60, c.r[1]);  // 0609E47C mov.l r1,@(60,r12)
L_0609E47E:
    c.r[2] = ld32(c.r[12] + 60);  // 0609E47E mov.l @(60,r12),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E51Au);  // 0609E480 mov.w 0x0609E51A,r0
    c.r[1] = ld32(c.r[12] + 24);  // 0609E482 mov.l @(24,r12),r1
    c.r[2] <<= 2;  // 0609E484 shll2 r2
    c.r[2] += c.r[2];  // 0609E486 add r2,r2
    c.r[1] -= c.r[2];  // 0609E488 sub r2,r1
    c.r[2] = ld32(c.r[12] + 60);  // 0609E48A mov.l @(60,r12),r2
    st32(c.r[12] + 24, c.r[1]);  // 0609E48C mov.l r1,@(24,r12)
    c.r[1] = ld32(c.r[12] + 28);  // 0609E48E mov.l @(28,r12),r1
    c.r[2] <<= 2;  // 0609E490 shll2 r2
    c.r[2] += c.r[2];  // 0609E492 add r2,r2
    c.r[1] += c.r[2];  // 0609E494 add r2,r1
    st32(c.r[12] + 28, c.r[1]);  // 0609E496 mov.l r1,@(28,r12)
    c.r[2] = ld32(c.r[12] + 24);  // 0609E498 mov.l @(24,r12),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E520u);  // 0609E49A mov.w 0x0609E520,r1
    c.r[2] += c.r[1];  // 0609E49C add r1,r2
    c.r[1] = c.r[12];  // 0609E49E mov r12,r1
    c.r[1] += 80;  // 0609E4A0 add #80,r1
    c.r[4] = ld32(c.r[1]);  // 0609E4A2 mov.l @r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E522u);  // 0609E4A4 mov.w 0x0609E522,r1
    c.r[4] += c.r[1];  // 0609E4A6 add r1,r4
    c.r[1] = ld32(0x0609E524u);  // 0609E4A8 mov.l 0x0609E524,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E4AEu; c.r[0] += c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E4AEu) return; }  // 0609E4AA jsr @r1 ; add r15,r0
    c.r[4] <<= 8;  // 0609E4AE shll8 r4
    c.r[4] += c.r[4];  // 0609E4B0 add r4,r4
    c.r[4] <<= 2;  // 0609E4B2 shll2 r4
    c.r[2] -= c.r[4];  // 0609E4B4 sub r4,r2
    st32(c.r[12] + 20, c.r[2]);  // 0609E4B6 mov.l r2,@(20,r12)
    c.r[0] = ld32(c.r[0]);  // 0609E4B8 mov.l @r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609E4BA tst r0,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0609E528; } }  // 0609E4BC bf/s 0x0609E528 ; mov #0,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E4C0 mov.w 0x0609E518,r9
    c.r[9] += c.r[15];  // 0609E4C2 add r15,r9
    c.r[11] = ld32(c.r[9]);  // 0609E4C4 mov.l @r9,r11
    c.r[1] = ld32(c.r[11] + 4);  // 0609E4C6 mov.l @(4,r11),r1
    c.r[6] = 0x0u;  // 0609E4C8 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E4CA cmp/ge r1,r6
    { const bool k = c.t; c.r[7] = ld32(c.r[12] + 56); if (k) { goto L_0609E4EE; } }  // 0609E4CC bt/s 0x0609E4EE ; mov.l @(56,r12),r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E4D0 mov.w 0x0609E518,r5
    c.r[3] = 0x0u;  // 0609E4D2 mov #0,r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E4D4 mov.w 0x0609E518,r13
    c.r[13] += c.r[15];  // 0609E4D6 add r15,r13
    c.r[2] = ld32(c.r[13]);  // 0609E4D8 mov.l @r13,r2
L_0609E4DA:
    c.r[0] = c.r[2];  // 0609E4DA mov r2,r0
    st32(c.r[0] + c.r[5], c.r[3]);  // 0609E4DC mov.l r3,@(r0,r5)
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E518u);  // 0609E4DE mov.w 0x0609E518,r9
    c.r[9] += c.r[15];  // 0609E4E0 add r15,r9
    c.r[11] = ld32(c.r[9]);  // 0609E4E2 mov.l @r9,r11
    c.r[1] = ld32(c.r[11] + 4);  // 0609E4E4 mov.l @(4,r11),r1
    c.r[6] += 1;  // 0609E4E6 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E4E8 cmp/ge r1,r6
    { const bool k = !c.t; c.r[2] += 100; if (k) { SH2_POLL(c); goto L_0609E4DA; } }  // 0609E4EA bf/s 0x0609E4DA ; add #100,r2
L_0609E4EE:
    c.r[3] = c.r[12];  // 0609E4EE mov r12,r3
    c.r[3] += 68;  // 0609E4F0 add #68,r3
    c.r[1] = ld32(c.r[3]);  // 0609E4F2 mov.l @r3,r1
    c.r[6] = 0x0u;  // 0609E4F4 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E4F6 cmp/ge r1,r6
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_0609E500; } }  // 0609E4F8 bf/s 0x0609E500 ; mov r7,r2
    goto L_0609E750;  // 0609E4FC bra 0x0609E750 ; nop
L_0609E500:
    c.r[2] += 7;  // 0609E500 add #7,r2
L_0609E502:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609E502 mov.b @r2,r0
    c.r[6] += 1;  // 0609E504 add #1,r6
    c.r[0] &= 0xFCu;  // 0609E506 and #252,r0
    st8(c.r[2], c.r[0]);  // 0609E508 mov.b r0,@r2
    c.r[1] = ld32(c.r[3]);  // 0609E50A mov.l @r3,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E50C cmp/ge r1,r6
    { const bool k = !c.t; c.r[2] += 8; if (k) { SH2_POLL(c); goto L_0609E502; } }  // 0609E50E bf/s 0x0609E502 ; add #8,r2
    goto L_0609E750;  // 0609E512 bra 0x0609E750 ; nop
L_0609E528:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E5BCu);  // 0609E528 mov.w 0x0609E5BC,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E5BEu);  // 0609E52A mov.w 0x0609E5BE,r13
    c.r[13] += c.r[15];  // 0609E52C add r15,r13
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609E5C0u);  // 0609E52E mov.w 0x0609E5C0,r8
    c.r[6] = c.r[8];  // 0609E530 mov r8,r6
    c.r[4] = c.r[15];  // 0609E532 mov r15,r4
    c.r[0] = ld32(c.r[13]);  // 0609E534 mov.l @r13,r0
    c.r[9] = ld32(0x0609E5CCu);  // 0609E536 mov.l 0x0609E5CC,r9
    c.r[0] += c.r[1];  // 0609E538 add r1,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E5C2u);  // 0609E53A mov.w 0x0609E5C2,r13
    c.r[13] += c.r[15];  // 0609E53C add r15,r13
    { const uint32_t x = c.r[9]; c.pr = 0x0609E542u; st32(c.r[13], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E542u) return; }  // 0609E53E jsr @r9 ; mov.l r0,@r13
    c.r[4] = c.r[15];  // 0609E542 mov r15,r4
    c.r[4] += c.r[8];  // 0609E544 add r8,r4
    c.r[6] = c.r[8];  // 0609E546 mov r8,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0609E54Cu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E54Cu) return; }  // 0609E548 jsr @r9 ; mov #0,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E5BEu);  // 0609E54C mov.w 0x0609E5BE,r11
    c.r[11] += c.r[15];  // 0609E54E add r15,r11
    c.r[13] = ld32(c.r[11]);  // 0609E550 mov.l @r11,r13
    c.r[1] = ld32(c.r[13] + 4);  // 0609E552 mov.l @(4,r13),r1
    c.r[6] = 0x0u;  // 0609E554 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E556 cmp/ge r1,r6
    if (c.t) { goto L_0609E618; }  // 0609E558 bt 0x0609E618
    c.r[14] = 0x64u;  // 0609E55A mov #100,r14
    c.r[10] = ld32(0x0609E5D0u);  // 0609E55C mov.l 0x0609E5D0,r10
    c.r[8] = 0x0u;  // 0609E55E mov #0,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E5C2u);  // 0609E560 mov.w 0x0609E5C2,r0
    c.r[7] = ld32(c.r[0] + c.r[15]);  // 0609E562 mov.l @(r0,r15),r7
    c.r[11] = 0x0u;  // 0609E564 mov #0,r11
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E5C4u);  // 0609E566 mov.w 0x0609E5C4,r9
    c.r[9] += c.r[15];  // 0609E568 add r15,r9
    st32(c.r[9], c.r[11]);  // 0609E56A mov.l r11,@r9
L_0609E56C:
    c.r[1] = c.r[7];  // 0609E56C mov r7,r1
    c.r[1] += 76;  // 0609E56E add #76,r1
    c.r[13] = 0xFFFFFFFFu;  // 0609E570 mov #-1,r13
    st32(c.r[1], c.r[13]);  // 0609E572 mov.l r13,@r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E5C4u);  // 0609E574 mov.w 0x0609E5C4,r9
    c.r[9] += c.r[15];  // 0609E576 add r15,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E5C2u);  // 0609E578 mov.w 0x0609E5C2,r11
    c.r[0] = ld32(c.r[9]);  // 0609E57A mov.l @r9,r0
    c.r[11] += c.r[15];  // 0609E57C add r15,r11
    c.r[13] = ld32(c.r[11]);  // 0609E57E mov.l @r11,r13
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0609E580 mov.l @(r0,r13),r1
    c.r[0] = c.r[1];  // 0609E582 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609E584 cmp/eq #1,r0
    { const bool k = !c.t; c.r[13] = 0xFFFFFFFFu; if (k) { goto L_0609E5FC; } }  // 0609E586 bf/s 0x0609E5FC ; mov #-1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E5C6u);  // 0609E58A mov.w 0x0609E5C6,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E5BEu);  // 0609E58C mov.w 0x0609E5BE,r9
    c.r[9] += c.r[15];  // 0609E58E add r15,r9
    c.r[11] = ld32(c.r[9]);  // 0609E590 mov.l @r9,r11
    c.r[0] = c.r[1];  // 0609E592 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[11]);  // 0609E594 mov.l @(r0,r11),r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[13];  // 0609E596 cmp/gt r13,r2
    if (!c.t) { goto L_0609E5D4; }  // 0609E598 bf 0x0609E5D4
    c.r[1] = ld32(c.r[7] + 8);  // 0609E59A mov.l @(8,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E5C8u);  // 0609E59C mov.w 0x0609E5C8,r0
    c.r[0] = ld32(c.r[0] + c.r[15]);  // 0609E59E mov.l @(r0,r15),r0
    c.macl = c.r[0] * c.r[1];  // 0609E5A0 mul.l r1,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E5C2u);  // 0609E5A2 mov.w 0x0609E5C2,r9
    c.r[4] = c.macl;  // 0609E5A4 sts macl,r4
    c.macl = c.r[2] * c.r[14];  // 0609E5A6 mul.l r14,r2
    c.r[9] += c.r[15];  // 0609E5A8 add r15,r9
    c.r[9] = ld32(c.r[9]);  // 0609E5AA mov.l @r9,r9
    c.r[1] = c.macl;  // 0609E5AC sts macl,r1
    c.r[1] += c.r[9];  // 0609E5AE add r9,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0609E5B4u; c.r[5] = ld32(c.r[1] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E5B4u) return; }  // 0609E5B0 jsr @r10 ; mov.l @(8,r1),r5
    c.r[5] = c.r[0];  // 0609E5B4 mov r0,r5
    c.r[0] = c.r[8];  // 0609E5B6 mov r8,r0
    st32(c.r[0] + c.r[15], c.r[5]); goto L_0609E5DC;  // 0609E5B8 bra 0x0609E5DC ; mov.l r5,@(r0,r15)
L_0609E5D4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E6BAu);  // 0609E5D4 mov.w 0x0609E6BA,r0
    c.r[9] = ld32(c.r[0] + c.r[15]);  // 0609E5D6 mov.l @(r0,r15),r9
    c.r[0] = c.r[8];  // 0609E5D8 mov r8,r0
    st32(c.r[0] + c.r[15], c.r[9]);  // 0609E5DA mov.l r9,@(r0,r15)
L_0609E5DC:
    c.r[1] = c.r[7];  // 0609E5DC mov r7,r1
    c.r[1] += 44;  // 0609E5DE add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609E5E0 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0609E5E2 extu.w r1,r0
    c.t = c.r[0] == 0x1u;  // 0609E5E4 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0609E5FC; } }  // 0609E5E6 bt/s 0x0609E5FC ; mov r7,r1
    c.r[1] += 62;  // 0609E5EA add #62,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609E5EC mov.w @r1,r5
    c.r[0] = c.r[8];  // 0609E5EE mov r8,r0
    c.r[4] = ld32(c.r[0] + c.r[15]);  // 0609E5F0 mov.l @(r0,r15),r4
    { const uint32_t x = c.r[10]; c.pr = 0x0609E5F6u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E5F6u) return; }  // 0609E5F2 jsr @r10 ; extu.w r5,r5
    c.r[5] = c.r[0];  // 0609E5F6 mov r0,r5
    c.r[0] = c.r[8];  // 0609E5F8 mov r8,r0
    st32(c.r[0] + c.r[15], c.r[5]);  // 0609E5FA mov.l r5,@(r0,r15)
L_0609E5FC:
    c.r[8] += 4;  // 0609E5FC add #4,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E6BCu);  // 0609E5FE mov.w 0x0609E6BC,r9
    c.r[9] += c.r[15];  // 0609E600 add r15,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E6BEu);  // 0609E602 mov.w 0x0609E6BE,r13
    c.r[11] = ld32(c.r[9]);  // 0609E604 mov.l @r9,r11
    c.r[13] += c.r[15];  // 0609E606 add r15,r13
    c.r[11] += 100;  // 0609E608 add #100,r11
    st32(c.r[9], c.r[11]);  // 0609E60A mov.l r11,@r9
    c.r[0] = ld32(c.r[13]);  // 0609E60C mov.l @r13,r0
    c.r[1] = ld32(c.r[0] + 4);  // 0609E60E mov.l @(4,r0),r1
    c.r[6] += 1;  // 0609E610 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E612 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] += 100; if (k) { SH2_POLL(c); goto L_0609E56C; } }  // 0609E614 bf/s 0x0609E56C ; add #100,r7
L_0609E618:
    c.r[1] = c.r[12];  // 0609E618 mov r12,r1
    c.r[1] += 68;  // 0609E61A add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609E61C mov.l @r1,r1
    c.r[6] = 0x0u;  // 0609E61E mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E620 cmp/ge r1,r6
    { const bool k = c.t; c.r[2] = ld32(c.r[12] + 56); if (k) { goto L_0609E704; } }  // 0609E622 bt/s 0x0609E704 ; mov.l @(56,r12),r2
    c.r[14] = c.r[2];  // 0609E626 mov r2,r14
    c.r[14] += 4;  // 0609E628 add #4,r14
    c.r[11] = c.r[2];  // 0609E62A mov r2,r11
    c.r[11] += 6;  // 0609E62C add #6,r11
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E6C0u);  // 0609E62E mov.w 0x0609E6C0,r9
    c.r[9] += c.r[15];  // 0609E630 add r15,r9
    st32(c.r[9], c.r[11]);  // 0609E632 mov.l r11,@r9
    c.r[2] += 7;  // 0609E634 add #7,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E6C2u);  // 0609E636 mov.w 0x0609E6C2,r13
    c.r[13] += c.r[15];  // 0609E638 add r15,r13
    st32(c.r[13], c.r[2]);  // 0609E63A mov.l r2,@r13
L_0609E63C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E6C2u);  // 0609E63C mov.w 0x0609E6C2,r0
    c.r[0] += c.r[15];  // 0609E63E add r15,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E6C4u);  // 0609E640 mov.w 0x0609E6C4,r11
    c.r[9] = ld32(c.r[0]);  // 0609E642 mov.l @r0,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E6C2u);  // 0609E644 mov.w 0x0609E6C2,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0609E646 mov.b @r9,r1
    c.r[13] += c.r[15];  // 0609E648 add r15,r13
    c.r[0] = ld32(c.r[13]);  // 0609E64A mov.l @r13,r0
    c.r[1] &= c.r[11];  // 0609E64C and r11,r1
    st8(c.r[0], c.r[1]);  // 0609E64E mov.b r1,@r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E6C0u);  // 0609E650 mov.w 0x0609E6C0,r9
    c.r[9] += c.r[15];  // 0609E652 add r15,r9
    c.r[11] = ld32(c.r[9]);  // 0609E654 mov.l @r9,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0609E656 mov.b @r11,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E6C6u);  // 0609E658 mov.w 0x0609E6C6,r13
    c.r[2] = c.r[1] & 0xFFu;  // 0609E65A extu.b r1,r2
    c.r[1] = 0x64u;  // 0609E65C mov #100,r1
    c.macl = c.r[2] * c.r[1];  // 0609E65E mul.l r1,r2
    c.r[13] += c.r[15];  // 0609E660 add r15,r13
    c.r[13] = ld32(c.r[13]);  // 0609E662 mov.l @r13,r13
    c.r[1] = c.macl;  // 0609E664 sts macl,r1
    c.r[1] += c.r[13];  // 0609E666 add r13,r1
    c.r[10] = c.r[1];  // 0609E668 mov r1,r10
    c.r[10] += 76;  // 0609E66A add #76,r10
    c.r[3] = ld32(c.r[10]);  // 0609E66C mov.l @r10,r3
    c.r[0] = c.r[3];  // 0609E66E mov r3,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609E670 cmp/eq #-1,r0
    if (!c.t) { goto L_0609E6E2; }  // 0609E672 bf 0x0609E6E2
    c.r[0] = ld32(c.r[1]);  // 0609E674 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 0609E676 cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = c.r[2]; if (k) { goto L_0609E6A0; } }  // 0609E678 bf/s 0x0609E6A0 ; mov r2,r9
    c.r[9] <<= 2;  // 0609E67C shll2 r9
    c.r[8] = c.r[9];  // 0609E67E mov r9,r8
    c.r[8] += c.r[15];  // 0609E680 add r15,r8
    c.r[1] += 80;  // 0609E682 add #80,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0609E684 mov.w @r14,r4
    c.r[7] = ld32(0x0609E6CCu);  // 0609E686 mov.l 0x0609E6CC,r7
    c.r[5] = ld32(c.r[1]);  // 0609E688 mov.l @r1,r5
    { const uint32_t x = c.r[7]; c.pr = 0x0609E68Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E68Eu) return; }  // 0609E68A jsr @r7 ; extu.w r4,r4
    c.r[7] = c.r[0];  // 0609E68E mov r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E6C8u);  // 0609E690 mov.w 0x0609E6C8,r0
    c.r[2] = ld32(c.r[0] + c.r[8]);  // 0609E692 mov.l @(r0,r8),r2
    c.r[2] += c.r[7];  // 0609E694 add r7,r2
    st32(c.r[0] + c.r[8], c.r[2]);  // 0609E696 mov.l r2,@(r0,r8)
    c.r[0] = c.r[9];  // 0609E698 mov r9,r0
    c.r[1] = ld32(c.r[0] + c.r[15]);  // 0609E69A mov.l @(r0,r15),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; goto L_0609E6B2;  // 0609E69C bra 0x0609E6B2 ; cmp/gt r1,r2
L_0609E6A0:
    c.r[2] <<= 2;  // 0609E6A0 shll2 r2
    c.r[0] = c.r[2];  // 0609E6A2 mov r2,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E6BAu);  // 0609E6A4 mov.w 0x0609E6BA,r9
    c.r[1] = ld32(c.r[0] + c.r[15]);  // 0609E6A6 mov.l @(r0,r15),r1
    c.r[9] += c.r[15];  // 0609E6A8 add r15,r9
    c.r[1] += 1;  // 0609E6AA add #1,r1
    st32(c.r[0] + c.r[15], c.r[1]);  // 0609E6AC mov.l r1,@(r0,r15)
    c.r[9] = ld32(c.r[9]);  // 0609E6AE mov.l @r9,r9
    c.t = (int32_t)c.r[1] > (int32_t)c.r[9];  // 0609E6B0 cmp/gt r9,r1
L_0609E6B2:
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_0609E6D0; } }  // 0609E6B2 bf/s 0x0609E6D0 ; mov #3,r0
    st32(c.r[10], c.r[6]); goto L_0609E6E2;  // 0609E6B6 bra 0x0609E6E2 ; mov.l r6,@r10
L_0609E6D0:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E79Eu);  // 0609E6D0 mov.w 0x0609E79E,r11
    c.r[11] += c.r[15];  // 0609E6D2 add r15,r11
    c.r[13] = ld32(c.r[11]);  // 0609E6D4 mov.l @r11,r13
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E79Eu);  // 0609E6D6 mov.w 0x0609E79E,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0609E6D8 mov.b @r13,r1
    c.r[9] += c.r[15];  // 0609E6DA add r15,r9
    c.r[11] = ld32(c.r[9]);  // 0609E6DC mov.l @r9,r11
    c.r[1] |= c.r[0];  // 0609E6DE or r0,r1
    st8(c.r[11], c.r[1]);  // 0609E6E0 mov.b r1,@r11
L_0609E6E2:
    c.r[6] += 1;  // 0609E6E2 add #1,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E7A0u);  // 0609E6E4 mov.w 0x0609E7A0,r13
    c.r[13] += c.r[15];  // 0609E6E6 add r15,r13
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E79Eu);  // 0609E6E8 mov.w 0x0609E79E,r9
    c.r[9] += c.r[15];  // 0609E6EA add r15,r9
    c.r[0] = ld32(c.r[13]);  // 0609E6EC mov.l @r13,r0
    c.r[1] = c.r[12];  // 0609E6EE mov r12,r1
    c.r[0] += 8;  // 0609E6F0 add #8,r0
    st32(c.r[13], c.r[0]);  // 0609E6F2 mov.l r0,@r13
    c.r[11] = ld32(c.r[9]);  // 0609E6F4 mov.l @r9,r11
    c.r[1] += 68;  // 0609E6F6 add #68,r1
    c.r[11] += 8;  // 0609E6F8 add #8,r11
    st32(c.r[9], c.r[11]);  // 0609E6FA mov.l r11,@r9
    c.r[1] = ld32(c.r[1]);  // 0609E6FC mov.l @r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E6FE cmp/ge r1,r6
    { const bool k = !c.t; c.r[14] += 8; if (k) { SH2_POLL(c); goto L_0609E63C; } }  // 0609E700 bf/s 0x0609E63C ; add #8,r14
L_0609E704:
    c.r[1] = c.r[12];  // 0609E704 mov r12,r1
    c.r[1] += 68;  // 0609E706 add #68,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E7A2u);  // 0609E708 mov.w 0x0609E7A2,r13
    c.r[13] += c.r[15];  // 0609E70A add r15,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E7A4u);  // 0609E70C mov.w 0x0609E7A4,r0
    c.r[1] = ld32(c.r[1]);  // 0609E70E mov.l @r1,r1
    c.r[0] += c.r[15];  // 0609E710 add r15,r0
    st32(c.r[13], c.r[1]);  // 0609E712 mov.l r1,@r13
    c.r[9] = ld32(c.r[0]);  // 0609E714 mov.l @r0,r9
    c.r[1] = ld32(c.r[9] + 4);  // 0609E716 mov.l @(4,r9),r1
    c.r[6] = 0x0u;  // 0609E718 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E71A cmp/ge r1,r6
    { const bool k = c.t; c.r[10] = 0xFFFFFFFFu; if (k) { goto L_0609E750; } }  // 0609E71C bt/s 0x0609E750 ; mov #-1,r10
    c.r[7] = c.r[10];  // 0609E720 mov r10,r7
    c.r[3] = c.r[1];  // 0609E722 mov r1,r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E7A6u);  // 0609E724 mov.w 0x0609E7A6,r11
    c.r[11] += c.r[15];  // 0609E726 add r15,r11
    c.r[2] = ld32(c.r[11]);  // 0609E728 mov.l @r11,r2
L_0609E72A:
    c.r[1] = c.r[2];  // 0609E72A mov r2,r1
    c.r[1] += 76;  // 0609E72C add #76,r1
    c.r[1] = ld32(c.r[1]);  // 0609E72E mov.l @r1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0609E730 cmp/gt r7,r1
    if (!c.t) { goto L_0609E748; }  // 0609E732 bf 0x0609E748
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E7A2u);  // 0609E734 mov.w 0x0609E7A2,r13
    c.r[13] += c.r[15];  // 0609E736 add r15,r13
    c.r[13] = ld32(c.r[13]);  // 0609E738 mov.l @r13,r13
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0609E73A cmp/gt r1,r13
    { const bool k = !c.t; c.t = (int32_t)c.r[10] >= (int32_t)c.r[1]; if (k) { goto L_0609E744; } }  // 0609E73C bf/s 0x0609E744 ; cmp/ge r1,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E7A2u);  // 0609E740 mov.w 0x0609E7A2,r0
    st32(c.r[0] + c.r[15], c.r[1]);  // 0609E742 mov.l r1,@(r0,r15)
L_0609E744:
    if (c.t) { goto L_0609E748; }  // 0609E744 bt 0x0609E748
    c.r[10] = c.r[1];  // 0609E746 mov r1,r10
L_0609E748:
    c.r[6] += 1;  // 0609E748 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[3];  // 0609E74A cmp/ge r3,r6
    { const bool k = !c.t; c.r[2] += 100; if (k) { SH2_POLL(c); goto L_0609E72A; } }  // 0609E74C bf/s 0x0609E72A ; add #100,r2
L_0609E750:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609E7A8u);  // 0609E750 mov.w 0x0609E7A8,r2
    c.r[1] = ld32(0x0609E7ACu);  // 0609E752 mov.l 0x0609E7AC,r1
    c.r[0] = c.r[12];  // 0609E754 mov r12,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609E756 mov.l r1,@(r0,r2)
    c.r[9] = ld32(0x0609E7B0u);  // 0609E758 mov.l 0x0609E7B0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0609E75Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E75Eu) return; }  // 0609E75A jsr @r9 ; mov r12,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E7AAu);  // 0609E75E mov.w 0x0609E7AA,r0
    c.r[0] = ld32(c.r[0] + c.r[15]);  // 0609E760 mov.l @(r0,r15),r0
    c.t = c.r[0] == 0xFFFFFFFDu;  // 0609E762 cmp/eq #-3,r0
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0609E85A; } }  // 0609E764 bt/s 0x0609E85A ; mov #0,r6
    c.r[1] = ld32(0x0609E7B4u);  // 0609E768 mov.l 0x0609E7B4,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E7A2u);  // 0609E76A mov.w 0x0609E7A2,r9
    c.r[9] += c.r[15];  // 0609E76C add r15,r9
    c.r[5] = ld32(c.r[9]);  // 0609E76E mov.l @r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609E774u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E774u) return; }  // 0609E770 jsr @r1 ; mov r12,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E7AAu);  // 0609E774 mov.w 0x0609E7AA,r0
    c.r[0] = ld32(c.r[0] + c.r[15]);  // 0609E776 mov.l @(r0,r15),r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609E778 cmp/eq #-2,r0
    if (c.t) { goto L_0609E7B8; }  // 0609E77A bt 0x0609E7B8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E7AAu);  // 0609E77C mov.w 0x0609E7AA,r0
    c.r[0] = ld32(c.r[0] + c.r[15]);  // 0609E77E mov.l @(r0,r15),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609E780 cmp/eq #-1,r0
    if (!c.t) { goto L_0609E7C4; }  // 0609E782 bf 0x0609E7C4
    c.r[2] = ld32(c.r[12] + 20);  // 0609E784 mov.l @(20,r12),r2
    c.r[1] = c.r[2];  // 0609E786 mov r2,r1
    c.r[1] += c.r[1];  // 0609E788 add r1,r1
    c.r[1] += c.r[2];  // 0609E78A add r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609E78C cmp/pz r1
    if (c.t) { goto L_0609E792; }  // 0609E78E bt 0x0609E792
    c.r[1] += 3;  // 0609E790 add #3,r1
L_0609E792:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609E792 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609E794 shar r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E7AAu);  // 0609E796 mov.w 0x0609E7AA,r9
    c.r[9] += c.r[15];  // 0609E798 add r15,r9
    st32(c.r[9], c.r[1]); goto L_0609E7C4;  // 0609E79A bra 0x0609E7C4 ; mov.l r1,@r9
L_0609E7B8:
    c.r[2] = ld32(c.r[12] + 20);  // 0609E7B8 mov.l @(20,r12),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609E870u);  // 0609E7BA mov.w 0x0609E870,r1
    c.r[2] += c.r[1];  // 0609E7BC add r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E872u);  // 0609E7BE mov.w 0x0609E872,r11
    c.r[11] += c.r[15];  // 0609E7C0 add r15,r11
    st32(c.r[11], c.r[2]);  // 0609E7C2 mov.l r2,@r11
L_0609E7C4:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E872u);  // 0609E7C4 mov.w 0x0609E872,r13
    c.r[13] += c.r[15];  // 0609E7C6 add r15,r13
    c.r[1] = ld32(0x0609E87Cu);  // 0609E7C8 mov.l 0x0609E87C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E872u);  // 0609E7CA mov.w 0x0609E872,r0
    c.r[0] += c.r[15];  // 0609E7CC add r15,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E872u);  // 0609E7CE mov.w 0x0609E872,r9
    c.r[4] = ld32(c.r[13]);  // 0609E7D0 mov.l @r13,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0609E7D6u; c.r[9] += c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E7D6u) return; }  // 0609E7D2 jsr @r1 ; add r15,r9
    c.r[4] <<= 8;  // 0609E7D6 shll8 r4
    c.r[4] += c.r[4];  // 0609E7D8 add r4,r4
    c.r[4] <<= 2;  // 0609E7DA shll2 r4
    st32(c.r[0], c.r[4]);  // 0609E7DC mov.l r4,@r0
    c.r[9] = ld32(c.r[9]);  // 0609E7DE mov.l @r9,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609E7E0 tst r9,r9
    if (c.t) { goto L_0609E7F0; }  // 0609E7E2 bt 0x0609E7F0
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E872u);  // 0609E7E4 mov.w 0x0609E872,r11
    c.r[11] += c.r[15];  // 0609E7E6 add r15,r11
    c.r[5] = ld32(c.r[11]);  // 0609E7E8 mov.l @r11,r5
    c.r[13] = ld32(0x0609E880u);  // 0609E7EA mov.l 0x0609E880,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0609E7F0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E7F0u) return; }  // 0609E7EC jsr @r13 ; mov r12,r4
L_0609E7F0:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609E874u);  // 0609E7F0 mov.w 0x0609E874,r5
    c.r[1] = ld32(0x0609E884u);  // 0609E7F2 mov.l 0x0609E884,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E7F8u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E7F8u) return; }  // 0609E7F4 jsr @r1 ; mov r12,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E876u);  // 0609E7F8 mov.w 0x0609E876,r0
    c.r[9] = ld32(c.r[0] + c.r[15]);  // 0609E7FA mov.l @(r0,r15),r9
    c.r[2] = ld32(c.r[9] + 4);  // 0609E7FC mov.l @(4,r9),r2
    c.r[1] = 0x1u;  // 0609E7FE mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609E800 cmp/gt r1,r2
    if (!c.t) { goto L_0609E85A; }  // 0609E802 bf 0x0609E85A
    c.r[11] = (uint32_t)(int16_t)ld16(0x0609E878u);  // 0609E804 mov.w 0x0609E878,r11
    c.r[11] += c.r[15];  // 0609E806 add r15,r11
    c.r[11] = ld32(c.r[11]);  // 0609E808 mov.l @r11,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 0609E80A tst r11,r11
    if (c.t) { goto L_0609E85A; }  // 0609E80C bt 0x0609E85A
    c.r[1] = ld32(c.r[12] + 56);  // 0609E80E mov.l @(56,r12),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0609E878u);  // 0609E810 mov.w 0x0609E878,r13
    c.r[13] += c.r[15];  // 0609E812 add r15,r13
    c.r[2] = ld32(c.r[13]);  // 0609E814 mov.l @r13,r2
    c.r[2] <<= 2;  // 0609E816 shll2 r2
    c.r[2] += c.r[2];  // 0609E818 add r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609E878u);  // 0609E81A mov.w 0x0609E878,r0
    c.r[6] = ld32(c.r[0] + c.r[15]);  // 0609E81C mov.l @(r0,r15),r6
    c.r[7] = c.r[1];  // 0609E81E mov r1,r7
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 0609E820 cmp/ge r10,r6
    { const bool k = c.t; c.r[7] += c.r[2]; if (k) { goto L_0609E85A; } }  // 0609E822 bt/s 0x0609E85A ; add r2,r7
    c.r[4] = 0x64u;  // 0609E826 mov #100,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609E876u);  // 0609E828 mov.w 0x0609E876,r5
    c.r[2] = c.r[7];  // 0609E82A mov r7,r2
    c.r[2] += 7;  // 0609E82C add #7,r2
    c.r[3] = c.r[7];  // 0609E82E mov r7,r3
    c.r[3] += 6;  // 0609E830 add #6,r3
L_0609E832:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609E832 mov.b @r3,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609E876u);  // 0609E834 mov.w 0x0609E876,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0609E836 extu.b r1,r1
    c.macl = c.r[1] * c.r[4];  // 0609E838 mul.l r4,r1
    c.r[9] += c.r[15];  // 0609E83A add r15,r9
    c.r[9] = ld32(c.r[9]);  // 0609E83C mov.l @r9,r9
    c.r[1] = c.macl;  // 0609E83E sts macl,r1
    c.r[1] += c.r[9];  // 0609E840 add r9,r1
    c.r[0] = c.r[1];  // 0609E842 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 0609E844 mov.l @(r0,r5),r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609E846 cmp/ge r1,r6
    if (c.t) { goto L_0609E850; }  // 0609E848 bt 0x0609E850
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609E84A mov.b @r2,r0
    c.r[0] |= 0x3u;  // 0609E84C or #3,r0
    st8(c.r[2], c.r[0]);  // 0609E84E mov.b r0,@r2
L_0609E850:
    c.r[6] += 1;  // 0609E850 add #1,r6
    c.r[2] += 8;  // 0609E852 add #8,r2
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 0609E854 cmp/ge r10,r6
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_0609E832; } }  // 0609E856 bf/s 0x0609E832 ; add #8,r3
L_0609E85A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609E87Au);  // 0609E85A mov.w 0x0609E87A,r3
    c.r[15] += c.r[3];  // 0609E85C add r3,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609E85E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609E860 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609E862 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609E864 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609E866 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609E868 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609E86A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609E86C rts ; mov.l @r15+,r8
}

void f_0609E888(SH2Context& c) {
    ran[2562] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609E888 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609E88A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609E88C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609E88E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609E890 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609E892 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609E894 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609E896 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609E898 mov r4,r8
    c.r[11] = c.r[5];  // 0609E89A mov r5,r11
    c.r[2] = ld32(0x0609EA38u);  // 0609E89C mov.l 0x0609EA38,r2
    c.r[1] = ld32(c.r[2]);  // 0609E89E mov.l @r2,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609E8A0 cmp/pl r1
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_0609E8B2; } }  // 0609E8A2 bf/s 0x0609E8B2 ; mov #0,r13
    c.r[1] -= 1;  // 0609E8A6 add #-1,r1
    st32(c.r[2], c.r[1]);  // 0609E8A8 mov.l r1,@r2
    c.r[1] = c.r[8];  // 0609E8AA mov r8,r1
    c.r[1] += 88;  // 0609E8AC add #88,r1
    c.r[0] = ld32(c.r[1]); goto L_0609EB9A;  // 0609E8AE bra 0x0609EB9A ; mov.l @r1,r0
L_0609E8B2:
    c.r[7] = c.r[8];  // 0609E8B2 mov r8,r7
    c.r[7] += 76;  // 0609E8B4 add #76,r7
    c.r[6] = c.r[8];  // 0609E8B6 mov r8,r6
    c.r[2] = ld32(c.r[7]);  // 0609E8B8 mov.l @r7,r2
    c.r[6] += 68;  // 0609E8BA add #68,r6
    c.r[1] = ld32(c.r[6]);  // 0609E8BC mov.l @r6,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609E8BE cmp/ge r1,r2
    if (c.t) { goto L_0609E904; }  // 0609E8C0 bt 0x0609E904
    c.r[1] = ld32(c.r[8] + 56);  // 0609E8C2 mov.l @(56,r8),r1
    c.r[2] <<= 2;  // 0609E8C4 shll2 r2
    c.r[2] += c.r[2];  // 0609E8C6 add r2,r2
    c.r[3] = c.r[1];  // 0609E8C8 mov r1,r3
    c.r[3] += c.r[2];  // 0609E8CA add r2,r3
    c.r[1] = c.r[3];  // 0609E8CC mov r3,r1
    c.r[1] += 7;  // 0609E8CE add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609E8D0 mov.b @r1,r0
    c.r[0] &= 0x3u;  // 0609E8D2 and #3,r0
    c.t = c.r[0] == 0x3u;  // 0609E8D4 cmp/eq #3,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0609E912; } }  // 0609E8D6 bf/s 0x0609E912 ; mov #0,r5
    c.r[3] = c.r[1];  // 0609E8DA mov r1,r3
L_0609E8DC:
    c.r[2] = ld32(c.r[7]);  // 0609E8DC mov.l @r7,r2
    c.r[2] += 1;  // 0609E8DE add #1,r2
    st32(c.r[7], c.r[2]);  // 0609E8E0 mov.l r2,@r7
    c.r[1] = ld32(c.r[6]);  // 0609E8E2 mov.l @r6,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609E8E4 cmp/ge r1,r2
    if (!c.t) { goto L_0609E8F4; }  // 0609E8E6 bf 0x0609E8F4
    c.r[0] = ld32(c.r[8] + 16);  // 0609E8E8 mov.l @(16,r8),r0
    c.t = c.r[0] == 0x1u;  // 0609E8EA cmp/eq #1,r0
    if (!c.t) { goto L_0609E912; }  // 0609E8EC bf 0x0609E912
    st32(c.r[7], c.r[5]);  // 0609E8EE mov.l r5,@r7
    c.r[1] = ld32(c.r[8] + 32); goto L_0609E910;  // 0609E8F0 bra 0x0609E910 ; mov.l @(32,r8),r1
L_0609E8F4:
    c.r[3] += 8;  // 0609E8F4 add #8,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609E8F6 mov.b @r3,r0
    c.r[0] &= 0x3u;  // 0609E8F8 and #3,r0
    c.t = c.r[0] == 0x3u;  // 0609E8FA cmp/eq #3,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_0609E8DC; } }  // 0609E8FC bt/s 0x0609E8DC ; mov r8,r1
    goto L_0609E914;  // 0609E900 bra 0x0609E914 ; nop
L_0609E904:
    c.r[0] = ld32(c.r[8] + 16);  // 0609E904 mov.l @(16,r8),r0
    c.t = c.r[0] == 0x1u;  // 0609E906 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0609E914; } }  // 0609E908 bf/s 0x0609E914 ; mov r8,r1
    st32(c.r[7], c.r[13]);  // 0609E90C mov.l r13,@r7
    c.r[1] = ld32(c.r[8] + 32);  // 0609E90E mov.l @(32,r8),r1
L_0609E910:
    st32(c.r[8] + 36, c.r[1]);  // 0609E910 mov.l r1,@(36,r8)
L_0609E912:
    c.r[1] = c.r[8];  // 0609E912 mov r8,r1
L_0609E914:
    c.r[1] += 76;  // 0609E914 add #76,r1
    c.r[2] = ld32(c.r[1]);  // 0609E916 mov.l @r1,r2
    c.r[7] = c.r[8];  // 0609E918 mov r8,r7
    c.r[3] = ld32(c.r[8] + 56);  // 0609E91A mov.l @(56,r8),r3
    c.r[2] <<= 2;  // 0609E91C shll2 r2
    c.r[2] += c.r[2];  // 0609E91E add r2,r2
    c.r[1] = ld32(c.r[8] + 36);  // 0609E920 mov.l @(36,r8),r1
    c.r[0] = c.r[2];  // 0609E922 mov r2,r0
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 0609E924 mov.l @(r0,r3),r2
    c.r[7] += 100;  // 0609E926 add #100,r7
    c.r[1] += c.r[2];  // 0609E928 add r2,r1
    c.r[1] -= 1;  // 0609E92A add #-1,r1
    st32(c.r[7], c.r[1]);  // 0609E92C mov.l r1,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609EA30u);  // 0609E92E mov.w 0x0609EA30,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 0609E930 cmp/gt r1,r11
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_0609E966; } }  // 0609E932 bt/s 0x0609E966 ; tst r11,r11
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609E93E; } }  // 0609E936 bt/s 0x0609E93E ; mov #0,r0
    goto L_0609EB9A;  // 0609E93A bra 0x0609EB9A ; nop
L_0609E93E:
    c.r[1] = c.r[8];  // 0609E93E mov r8,r1
    c.r[1] += 88;  // 0609E940 add #88,r1
    c.r[7] = c.r[8];  // 0609E942 mov r8,r7
    c.r[11] = ld32(c.r[1]);  // 0609E944 mov.l @r1,r11
    c.r[7] += 92;  // 0609E946 add #92,r7
    c.r[1] = ld32(c.r[7]);  // 0609E948 mov.l @r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609E94A tst r1,r1
    if (c.t) { goto L_0609E966; }  // 0609E94C bt 0x0609E966
    c.r[3] = ld32(0x0609EA3Cu);  // 0609E94E mov.l 0x0609EA3C,r3
    c.r[1] = ld32(c.r[3]);  // 0609E950 mov.l @r3,r1
    c.r[2] = c.r[1];  // 0609E952 mov r1,r2
    c.r[2] += 1;  // 0609E954 add #1,r2
    st32(c.r[3], c.r[2]);  // 0609E956 mov.l r2,@r3
    c.r[2] = ld32(c.r[7]);  // 0609E958 mov.l @r7,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0609E95A cmp/ge r2,r1
    if (!c.t) { goto L_0609E966; }  // 0609E95C bf 0x0609E966
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609EA32u);  // 0609E95E mov.w 0x0609EA32,r1
    c.r[11] += c.r[1];  // 0609E960 add r1,r11
    c.r[1] = 0x0u;  // 0609E962 mov #0,r1
    st32(c.r[3], c.r[1]);  // 0609E964 mov.l r1,@r3
L_0609E966:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609EA34u);  // 0609E966 mov.w 0x0609EA34,r3
    c.r[1] = c.r[11];  // 0609E968 mov r11,r1
    c.r[1] &= c.r[3];  // 0609E96A and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609E96C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[8]; if (k) { goto L_0609E98A; } }  // 0609E96E bt/s 0x0609E98A ; mov r8,r14
    c.r[1] = ld32(0x0609EA40u);  // 0609E972 mov.l 0x0609EA40,r1
    c.r[2] = ld32(c.r[1]);  // 0609E974 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609E976 tst r2,r2
    c.r[2] = c.t;  // 0609E978 movt r2
    c.r[0] = c.t;  // 0609E97A movt r0
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609E97C tst r2,r2
    { const bool k = c.t; st32(c.r[1], c.r[0]); if (k) { goto L_0609E986; } }  // 0609E97E bt/s 0x0609E986 ; mov.l r0,@r1
    c.r[11] += c.r[3]; goto L_0609E98A;  // 0609E982 bra 0x0609E98A ; add r3,r11
L_0609E986:
    c.r[11] -= c.r[3];  // 0609E986 sub r3,r11
    c.r[14] = c.r[8];  // 0609E988 mov r8,r14
L_0609E98A:
    c.r[14] += 104;  // 0609E98A add #104,r14
    c.r[12] = c.r[8];  // 0609E98C mov r8,r12
    c.r[12] += 96;  // 0609E98E add #96,r12
    c.r[1] = c.r[8];  // 0609E990 mov r8,r1
L_0609E992:
    c.r[2] = ld32(c.r[14]);  // 0609E992 mov.l @r14,r2
    c.r[1] += 100;  // 0609E994 add #100,r1
    c.r[1] = ld32(c.r[1]);  // 0609E996 mov.l @r1,r1
    c.r[2] -= c.r[1];  // 0609E998 sub r1,r2
    c.r[1] = ld32(c.r[8] + 20);  // 0609E99A mov.l @(20,r8),r1
    c.r[3] = ld32(c.r[12]);  // 0609E99C mov.l @r12,r3
    c.r[7] = c.r[1];  // 0609E99E mov r1,r7
    c.r[7] -= c.r[2];  // 0609E9A0 sub r2,r7
    c.r[1] = c.r[7];  // 0609E9A2 mov r7,r1
    c.r[2] = ld32(c.r[8] + 24);  // 0609E9A4 mov.l @(24,r8),r2
    c.r[1] += c.r[3];  // 0609E9A6 add r3,r1
    c.t = c.r[1] > c.r[2];  // 0609E9A8 cmp/hi r2,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[7] > (int32_t)c.r[11]; if (k) { goto L_0609E9B4; } }  // 0609E9AA bf/s 0x0609E9B4 ; cmp/gt r11,r7
    c.r[7] = c.r[2];  // 0609E9AE mov r2,r7
    c.r[7] -= c.r[3];  // 0609E9B0 sub r3,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[11];  // 0609E9B2 cmp/gt r11,r7
L_0609E9B4:
    if (!c.t) { goto L_0609E9BC; }  // 0609E9B4 bf 0x0609E9BC
    c.r[7] = c.r[11];  // 0609E9B6 mov r11,r7
    c.r[1] = c.r[7]; goto L_0609E9CC;  // 0609E9B8 bra 0x0609E9CC ; mov r7,r1
L_0609E9BC:
    c.r[1] = ld32(0x0609EA44u);  // 0609E9BC mov.l 0x0609EA44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609E9C2u; c.r[4] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E9C2u) return; }  // 0609E9BE jsr @r1 ; mov r7,r4
    c.r[7] = c.r[4];  // 0609E9C2 mov r4,r7
    c.r[7] <<= 8;  // 0609E9C4 shll8 r7
    c.r[7] += c.r[7];  // 0609E9C6 add r7,r7
    c.r[7] <<= 2;  // 0609E9C8 shll2 r7
    c.r[1] = c.r[7];  // 0609E9CA mov r7,r1
L_0609E9CC:
    c.r[1] += c.r[13];  // 0609E9CC add r13,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[11];  // 0609E9CE cmp/gt r11,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[7] > 0; if (k) { goto L_0609E9DA; } }  // 0609E9D0 bf/s 0x0609E9DA ; cmp/pl r7
    c.r[7] = c.r[11];  // 0609E9D4 mov r11,r7
    c.r[7] -= c.r[13];  // 0609E9D6 sub r13,r7
    c.t = (int32_t)c.r[7] > 0;  // 0609E9D8 cmp/pl r7
L_0609E9DA:
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_0609E9E2; } }  // 0609E9DA bt/s 0x0609E9E2 ; mov r13,r0
    goto L_0609EB9A;  // 0609E9DE bra 0x0609EB9A ; nop
L_0609E9E2:
    c.r[3] = ld32(c.r[12]);  // 0609E9E2 mov.l @r12,r3
    c.r[1] = ld32(c.r[8] + 24);  // 0609E9E4 mov.l @(24,r8),r1
    c.r[2] = c.r[3];  // 0609E9E6 mov r3,r2
    c.r[2] += c.r[7];  // 0609E9E8 add r7,r2
    c.t = c.r[2] > c.r[1];  // 0609E9EA cmp/hi r1,r2
    if (c.t) { goto L_0609EA0A; }  // 0609E9EC bt 0x0609EA0A
    c.r[1] = ld32(c.r[8]);  // 0609E9EE mov.l @r8,r1
    c.r[0] = ld32(0x0609EA48u);  // 0609E9F0 mov.l 0x0609EA48,r0
    c.r[6] = c.r[7];  // 0609E9F2 mov r7,r6
    c.r[5] = ld32(c.r[8] + 28);  // 0609E9F4 mov.l @(28,r8),r5
    c.r[1] += 108;  // 0609E9F6 add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609E9F8 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0609E9FEu; c.r[5] += c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609E9FEu) return; }  // 0609E9FA jsr @r0 ; add r3,r5
    c.r[7] = c.r[0];  // 0609E9FE mov r0,r7
    c.t = (int32_t)c.r[7] >= 0;  // 0609EA00 cmp/pz r7
    if (c.t) { goto L_0609EA0E; }  // 0609EA02 bt 0x0609EA0E
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609EA04 lds.l @r15+,pr
    goto L_0609EB9C;  // 0609EA06 bra 0x0609EB9C ; nop
L_0609EA0A:
    c.r[0] = 0xFFFFFF9Du; goto L_0609EB9A;  // 0609EA0A bra 0x0609EB9A ; mov #-99,r0
L_0609EA0E:
    c.r[1] = ld32(c.r[14]);  // 0609EA0E mov.l @r14,r1
    c.r[4] = c.r[1];  // 0609EA10 mov r1,r4
    c.r[4] += c.r[7];  // 0609EA12 add r7,r4
    st32(c.r[14], c.r[4]);  // 0609EA14 mov.l r4,@r14
    c.r[1] = ld32(c.r[12]);  // 0609EA16 mov.l @r12,r1
    c.r[2] = ld32(c.r[8] + 20);  // 0609EA18 mov.l @(20,r8),r2
    c.r[1] += c.r[7];  // 0609EA1A add r7,r1
    c.t = c.r[1] > c.r[2];  // 0609EA1C cmp/hi r2,r1
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0609EA50; } }  // 0609EA1E bf/s 0x0609EA50 ; mov #0,r10
    c.r[1] = ld32(0x0609EA4Cu);  // 0609EA22 mov.l 0x0609EA4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609EA28u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EA28u) return; }  // 0609EA24 jsr @r1 ; mov r2,r5
    c.macl = c.r[0] * c.r[2];  // 0609EA28 mul.l r2,r0
    c.r[1] = c.macl;  // 0609EA2A sts macl,r1
    c.r[10] = c.r[1]; goto L_0609EA50;  // 0609EA2C bra 0x0609EA50 ; mov r1,r10
L_0609EA50:
    c.r[2] = ld32(c.r[14]);  // 0609EA50 mov.l @r14,r2
    c.r[1] = ld32(0x0609EBB0u);  // 0609EA52 mov.l 0x0609EBB0,r1
    c.r[3] = ld32(c.r[8] + 20);  // 0609EA54 mov.l @(20,r8),r3
    c.r[4] = c.r[2];  // 0609EA56 mov r2,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0609EA5Cu; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EA5Cu) return; }  // 0609EA58 jsr @r1 ; mov r3,r5
    c.macl = c.r[0] * c.r[3];  // 0609EA5C mul.l r3,r0
    c.r[1] = c.macl;  // 0609EA5E sts macl,r1
    c.r[2] -= c.r[1];  // 0609EA60 sub r1,r2
    st32(c.r[12], c.r[2]);  // 0609EA62 mov.l r2,@r12
    c.r[1] = c.r[8];  // 0609EA64 mov r8,r1
    c.r[1] += 72;  // 0609EA66 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0609EA68 mov.l @r1,r1
    c.r[2] = ld32(c.r[8] + 56);  // 0609EA6A mov.l @(56,r8),r2
    c.r[1] <<= 2;  // 0609EA6C shll2 r1
    c.r[1] += c.r[1];  // 0609EA6E add r1,r1
    c.r[3] = c.r[2];  // 0609EA70 mov r2,r3
    c.r[3] += c.r[1];  // 0609EA72 add r1,r3
    c.r[1] = c.r[8];  // 0609EA74 mov r8,r1
    c.r[1] += 68;  // 0609EA76 add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609EA78 mov.l @r1,r1
    c.r[1] <<= 2;  // 0609EA7A shll2 r1
    c.r[1] += c.r[1];  // 0609EA7C add r1,r1
    c.r[2] += c.r[1];  // 0609EA7E add r1,r2
    c.t = c.r[3] > c.r[2];  // 0609EA80 cmp/hi r2,r3
    { const bool k = c.t; c.r[13] += c.r[7]; if (k) { goto L_0609EB36; } }  // 0609EA82 bt/s 0x0609EB36 ; add r7,r13
    c.r[7] = c.r[3];  // 0609EA86 mov r3,r7
    c.r[7] += 7;  // 0609EA88 add #7,r7
    c.r[5] = c.r[3];  // 0609EA8A mov r3,r5
    c.r[5] += 4;  // 0609EA8C add #4,r5
L_0609EA8E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0609EA8E mov.b @r7,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609EBACu);  // 0609EA90 mov.w 0x0609EBAC,r4
    c.r[4] &= c.r[0];  // 0609EA92 and r0,r4
    st8(c.r[7], c.r[4]);  // 0609EA94 mov.b r4,@r7
    c.r[2] = ld32(c.r[3]);  // 0609EA96 mov.l @r3,r2
    c.r[1] = ld32(c.r[8] + 32);  // 0609EA98 mov.l @(32,r8),r1
    c.r[9] = ld32(c.r[14]);  // 0609EA9A mov.l @r14,r9
    c.r[2] += c.r[1];  // 0609EA9C add r1,r2
    c.t = c.r[2] > c.r[9];  // 0609EA9E cmp/hi r9,r2
    if (c.t) { goto L_0609EB36; }  // 0609EAA0 bt 0x0609EB36
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0609EAA2 mov.w @r5,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0609EAA4 extu.w r1,r6
    c.r[1] = c.r[2];  // 0609EAA6 mov r2,r1
    c.r[1] += c.r[6];  // 0609EAA8 add r6,r1
    c.t = c.r[1] >= c.r[9];  // 0609EAAA cmp/hs r9,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0609EAD6; } }  // 0609EAAC bt/s 0x0609EAD6 ; mov #1,r1
    c.r[1] |= c.r[4];  // 0609EAB0 or r4,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 0609EAB2 tst r10,r10
    { const bool k = c.t; st8(c.r[7], c.r[1]); if (k) { goto L_0609EACA; } }  // 0609EAB4 bt/s 0x0609EACA ; mov.b r1,@r7
    c.r[1] = ld32(c.r[3]);  // 0609EAB8 mov.l @r3,r1
    c.r[2] = ld32(c.r[8] + 32);  // 0609EABA mov.l @(32,r8),r2
    c.r[1] += c.r[2];  // 0609EABC add r2,r1
    c.t = c.r[1] >= c.r[10];  // 0609EABE cmp/hs r10,r1
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0609EACC; } }  // 0609EAC0 bf/s 0x0609EACC ; mov r8,r2
    c.r[0] = c.r[4];  // 0609EAC4 mov r4,r0
    c.r[0] |= 0x5u;  // 0609EAC6 or #5,r0
    st8(c.r[7], c.r[0]);  // 0609EAC8 mov.b r0,@r7
L_0609EACA:
    c.r[2] = c.r[8];  // 0609EACA mov r8,r2
L_0609EACC:
    c.r[2] += 72;  // 0609EACC add #72,r2
    c.r[1] = ld32(c.r[2]);  // 0609EACE mov.l @r2,r1
    c.r[1] += 1;  // 0609EAD0 add #1,r1
    st32(c.r[2], c.r[1]); goto L_0609EB1E;  // 0609EAD2 bra 0x0609EB1E ; mov.l r1,@r2
L_0609EAD6:
    c.r[3] = ld32(c.r[8] + 20);  // 0609EAD6 mov.l @(20,r8),r3
    c.r[4] = c.r[2];  // 0609EAD8 mov r2,r4
    c.r[1] = ld32(0x0609EBB0u);  // 0609EADA mov.l 0x0609EBB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609EAE0u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EAE0u) return; }  // 0609EADC jsr @r1 ; mov r3,r5
    c.macl = c.r[0] * c.r[3];  // 0609EAE0 mul.l r3,r0
    c.r[7] = c.r[2];  // 0609EAE2 mov r2,r7
    c.r[1] = c.macl;  // 0609EAE4 sts macl,r1
    c.r[7] -= c.r[1];  // 0609EAE6 sub r1,r7
    c.r[1] = c.r[7];  // 0609EAE8 mov r7,r1
    c.r[1] += c.r[6];  // 0609EAEA add r6,r1
    c.t = c.r[1] >= c.r[3];  // 0609EAEC cmp/hs r3,r1
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0609EB04; } }  // 0609EAEE bf/s 0x0609EB04 ; tst r10,r10
    c.r[1] = c.r[9];  // 0609EAF2 mov r9,r1
    c.r[1] -= c.r[2];  // 0609EAF4 sub r2,r1
    c.r[1] += c.r[7];  // 0609EAF6 add r7,r1
    c.t = c.r[1] >= c.r[3];  // 0609EAF8 cmp/hs r3,r1
    if (!c.t) { goto L_0609EB36; }  // 0609EAFA bf 0x0609EB36
    c.r[1] = ld32(c.r[12]);  // 0609EAFC mov.l @r12,r1
    c.r[1] += c.r[3];  // 0609EAFE add r3,r1
    st32(c.r[12], c.r[1]); goto L_0609EB36;  // 0609EB00 bra 0x0609EB36 ; mov.l r1,@r12
L_0609EB04:
    { const bool k = c.t; c.t = c.r[2] >= c.r[10]; if (k) { goto L_0609EB36; } }  // 0609EB04 bt/s 0x0609EB36 ; cmp/hs r10,r2
    if (!c.t) { goto L_0609EB36; }  // 0609EB08 bf 0x0609EB36
    c.r[4] = ld32(c.r[8] + 28);  // 0609EB0A mov.l @(28,r8),r4
    c.r[6] = c.r[9];  // 0609EB0C mov r9,r6
    c.r[6] -= c.r[2];  // 0609EB0E sub r2,r6
    c.r[1] = ld32(0x0609EBB4u);  // 0609EB10 mov.l 0x0609EBB4,r1
    c.r[4] += c.r[7];  // 0609EB12 add r7,r4
    c.r[5] = c.r[4];  // 0609EB14 mov r4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609EB1Au; c.r[5] += c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EB1Au) return; }  // 0609EB16 jsr @r1 ; add r3,r5
    c.r[1] = c.r[8]; goto L_0609EB38;  // 0609EB1A bra 0x0609EB38 ; mov r8,r1
L_0609EB1E:
    c.r[7] += 8;  // 0609EB1E add #8,r7
    c.r[1] = c.r[8];  // 0609EB20 mov r8,r1
    c.r[1] += 68;  // 0609EB22 add #68,r1
    c.r[2] = ld32(c.r[1]);  // 0609EB24 mov.l @r1,r2
    c.r[3] += 8;  // 0609EB26 add #8,r3
    c.r[1] = ld32(c.r[8] + 56);  // 0609EB28 mov.l @(56,r8),r1
    c.r[2] <<= 2;  // 0609EB2A shll2 r2
    c.r[2] += c.r[2];  // 0609EB2C add r2,r2
    c.r[1] += c.r[2];  // 0609EB2E add r2,r1
    c.t = c.r[3] > c.r[1];  // 0609EB30 cmp/hi r1,r3
    { const bool k = !c.t; c.r[5] += 8; if (k) { SH2_POLL(c); goto L_0609EA8E; } }  // 0609EB32 bf/s 0x0609EA8E ; add #8,r5
L_0609EB36:
    c.r[1] = c.r[8];  // 0609EB36 mov r8,r1
L_0609EB38:
    c.r[1] += 72;  // 0609EB38 add #72,r1
    c.r[2] = c.r[8];  // 0609EB3A mov r8,r2
    c.r[1] = ld32(c.r[1]);  // 0609EB3C mov.l @r1,r1
    c.r[2] += 68;  // 0609EB3E add #68,r2
    c.r[2] = ld32(c.r[2]);  // 0609EB40 mov.l @r2,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0609EB42 cmp/ge r2,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[13] >= (int32_t)c.r[11]; if (k) { goto L_0609EB90; } }  // 0609EB44 bf/s 0x0609EB90 ; cmp/ge r11,r13
    c.r[0] = ld32(c.r[8] + 16);  // 0609EB48 mov.l @(16,r8),r0
    c.t = c.r[0] == 0x1u;  // 0609EB4A cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[13]; if (k) { goto L_0609EB9A; } }  // 0609EB4C bf/s 0x0609EB9A ; mov r13,r0
    c.r[1] = c.r[2];  // 0609EB50 mov r2,r1
    c.r[1] <<= 2;  // 0609EB52 shll2 r1
    c.r[1] += c.r[1];  // 0609EB54 add r1,r1
    c.r[0] = c.r[1];  // 0609EB56 mov r1,r0
    c.r[0] -= 8;  // 0609EB58 add #-8,r0
    c.r[1] = ld32(c.r[8] + 56);  // 0609EB5A mov.l @(56,r8),r1
    c.r[5] = 0x0u;  // 0609EB5C mov #0,r5
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609EB5E mov.l @(r0,r1),r6
    c.r[3] = c.r[1];  // 0609EB60 mov r1,r3
    c.r[1] = ld32(c.r[8] + 32);  // 0609EB62 mov.l @(32,r8),r1
    c.r[3] += c.r[0];  // 0609EB64 add r0,r3
    c.r[6] += c.r[1];  // 0609EB66 add r1,r6
    c.r[1] = c.r[3];  // 0609EB68 mov r3,r1
    c.r[1] += 4;  // 0609EB6A add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609EB6C mov.w @r1,r1
    c.r[4] = c.r[8];  // 0609EB6E mov r8,r4
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609EB70 extu.w r1,r1
    c.r[6] += c.r[1];  // 0609EB72 add r1,r6
    c.r[1] = ld32(0x0609EBB8u);  // 0609EB74 mov.l 0x0609EBB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609EB7Au; c.r[6] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EB7Au) return; }  // 0609EB76 jsr @r1 ; add #1,r6
    c.r[1] = c.r[8];  // 0609EB7A mov r8,r1
    c.r[1] += 108;  // 0609EB7C add #108,r1
    c.r[1] = ld32(c.r[1]);  // 0609EB7E mov.l @r1,r1
    c.r[3] = ld32(0x0609EBBCu);  // 0609EB80 mov.l 0x0609EBBC,r3
    c.r[2] = c.r[1];  // 0609EB82 mov r1,r2
    c.t = c.r[2] >> 31; c.r[2] = c.r[2] << 1 | c.t;  // 0609EB84 rotl r2
    c.r[2] = c.t;  // 0609EB86 movt r2
    c.r[1] += c.r[2];  // 0609EB88 add r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609EB8A shar r1
    st32(c.r[3], c.r[1]); goto L_0609EB98;  // 0609EB8C bra 0x0609EB98 ; mov.l r1,@r3
L_0609EB90:
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609EB98; } }  // 0609EB90 bt/s 0x0609EB98 ; mov r8,r1
    SH2_POLL(c); goto L_0609E992;  // 0609EB94 bra 0x0609E992 ; nop
L_0609EB98:
    c.r[0] = c.r[13];  // 0609EB98 mov r13,r0
L_0609EB9A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609EB9A lds.l @r15+,pr
L_0609EB9C:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609EB9C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609EB9E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609EBA0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609EBA2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609EBA4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609EBA6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609EBA8 rts ; mov.l @r15+,r8
}

void f_0609EBD8(SH2Context& c) {
    ran[2563] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609EBD8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609EBDA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609EBDC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609EBDE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609EBE0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609EBE2 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609EBE4 mov r4,r8
    c.r[3] = c.r[6];  // 0609EBE6 mov r6,r3
    c.r[0] = c.r[3];  // 0609EBE8 mov r3,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609EBEA cmp/eq #-2,r0
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_0609EC04; } }  // 0609EBEC bt/s 0x0609EC04 ; mov #0,r11
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609ECF8u);  // 0609EBF0 mov.w 0x0609ECF8,r2
    c.r[0] = c.r[8];  // 0609EBF2 mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609EBF4 mov.l @(r0,r2),r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 0609EBF6 cmp/ge r3,r1
    { const bool k = !c.t; c.r[1] += 1; if (k) { goto L_0609EC00; } }  // 0609EBF8 bf/s 0x0609EC00 ; add #1,r1
    c.r[0] = 0x0u; goto L_0609ECEA;  // 0609EBFC bra 0x0609ECEA ; mov #0,r0
L_0609EC00:
    st32(c.r[0] + c.r[2], c.r[1]); goto L_0609EC0E;  // 0609EC00 bra 0x0609EC0E ; mov.l r1,@(r0,r2)
L_0609EC04:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609EC04 cmp/eq #-1,r0
    { const bool k = !c.t; c.t = (int32_t)c.r[5] > 0; if (k) { goto L_0609EC10; } }  // 0609EC06 bf/s 0x0609EC10 ; cmp/pl r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ECF8u);  // 0609EC0A mov.w 0x0609ECF8,r0
    st32(c.r[0] + c.r[8], c.r[11]);  // 0609EC0C mov.l r11,@(r0,r8)
L_0609EC0E:
    c.t = (int32_t)c.r[5] > 0;  // 0609EC0E cmp/pl r5
L_0609EC10:
    if (!c.t) { goto L_0609EC1C; }  // 0609EC10 bf 0x0609EC1C
    c.r[0] = ld32(0x0609ED04u);  // 0609EC12 mov.l 0x0609ED04,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609EC18u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EC18u) return; }  // 0609EC14 jsr @r0 ; mov r8,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0609ECEC;  // 0609EC18 bra 0x0609ECEC ; lds.l @r15+,pr
L_0609EC1C:
    c.r[12] = ld32(0x0609ED04u);  // 0609EC1C mov.l 0x0609ED04,r12
    c.r[5] = 0x0u;  // 0609EC1E mov #0,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0609EC24u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EC24u) return; }  // 0609EC20 jsr @r12 ; mov r8,r4
    c.r[10] = c.r[0];  // 0609EC24 mov r0,r10
    c.t = (int32_t)c.r[10] >= 0;  // 0609EC26 cmp/pz r10
    if (!c.t) { goto L_0609ECEA; }  // 0609EC28 bf 0x0609ECEA
    c.r[0] = c.r[8];  // 0609EC2A mov r8,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609ECFAu);  // 0609EC2C mov.w 0x0609ECFA,r6
    c.r[1] = ld32(c.r[0] + c.r[6]);  // 0609EC2E mov.l @(r0,r6),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609EC30 tst r1,r1
    if (c.t) { goto L_0609EC3E; }  // 0609EC32 bt 0x0609EC3E
    c.r[1] = ld32(0x0609ED08u);  // 0609EC34 mov.l 0x0609ED08,r1
    c.r[1] = ld32(c.r[1]);  // 0609EC36 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609EC38 tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[8]; if (k) { goto L_0609EC42; } }  // 0609EC3A bt/s 0x0609EC42 ; mov r8,r3
L_0609EC3E:
    c.r[0] = c.r[10]; goto L_0609ECEA;  // 0609EC3E bra 0x0609ECEA ; mov r10,r0
L_0609EC42:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609ECFCu);  // 0609EC42 mov.w 0x0609ECFC,r7
    c.r[3] += 120;  // 0609EC44 add #120,r3
    c.r[1] = ld32(c.r[3]);  // 0609EC46 mov.l @r3,r1
    c.r[0] = c.r[8];  // 0609EC48 mov r8,r0
    c.r[2] = ld32(c.r[0] + c.r[7]);  // 0609EC4A mov.l @(r0,r7),r2
    c.r[1] <<= 2;  // 0609EC4C shll2 r1
    c.r[1] += c.r[8];  // 0609EC4E add r8,r1
    c.r[1] += 124;  // 0609EC50 add #124,r1
    c.r[1] = ld32(c.r[1]);  // 0609EC52 mov.l @r1,r1
    c.r[2] -= c.r[1];  // 0609EC54 sub r1,r2
    st32(c.r[0] + c.r[7], c.r[2]);  // 0609EC56 mov.l r2,@(r0,r7)
    c.r[1] = ld32(c.r[3]);  // 0609EC58 mov.l @r3,r1
    c.r[1] <<= 2;  // 0609EC5A shll2 r1
    c.r[1] += c.r[8];  // 0609EC5C add r8,r1
    c.r[1] += 124;  // 0609EC5E add #124,r1
    st32(c.r[1], c.r[10]);  // 0609EC60 mov.l r10,@r1
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609EC62 mov.l @(r0,r7),r1
    c.r[5] = c.r[8];  // 0609EC64 mov r8,r5
    c.r[1] += c.r[10];  // 0609EC66 add r10,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 0609EC68 mov.l r1,@(r0,r7)
    c.r[1] = ld32(c.r[3]);  // 0609EC6A mov.l @r3,r1
    c.r[5] += 108;  // 0609EC6C add #108,r5
    c.r[1] += 1;  // 0609EC6E add #1,r1
    st32(c.r[3], c.r[1]);  // 0609EC70 mov.l r1,@r3
    c.r[2] = ld32(c.r[5]);  // 0609EC72 mov.l @r5,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0609EC74 cmp/ge r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0609EC7C; } }  // 0609EC76 bf/s 0x0609EC7C ; mov #0,r1
    st32(c.r[3], c.r[1]);  // 0609EC7A mov.l r1,@r3
L_0609EC7C:
    c.r[2] = ld32(c.r[3]);  // 0609EC7C mov.l @r3,r2
    c.r[1] = 0x1Du;  // 0609EC7E mov #29,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609EC80 cmp/gt r1,r2
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0609EC8A; } }  // 0609EC82 bf/s 0x0609EC8A ; mov r8,r2
    c.r[1] = 0x0u;  // 0609EC86 mov #0,r1
    st32(c.r[3], c.r[1]);  // 0609EC88 mov.l r1,@r3
L_0609EC8A:
    c.r[2] += 116;  // 0609EC8A add #116,r2
    c.r[1] = ld32(c.r[2]);  // 0609EC8C mov.l @r2,r1
    c.r[1] += 1;  // 0609EC8E add #1,r1
    st32(c.r[2], c.r[1]);  // 0609EC90 mov.l r1,@r2
    c.r[5] = ld32(c.r[5]);  // 0609EC92 mov.l @r5,r5
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5];  // 0609EC94 cmp/gt r5,r1
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0609ECE8; } }  // 0609EC96 bf/s 0x0609ECE8 ; mov r11,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609ECFEu);  // 0609EC9A mov.w 0x0609ECFE,r9
    c.r[0] = c.r[8];  // 0609EC9C mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609EC9E mov.l @(r0,r7),r1
    c.r[4] = ld32(0x0609ED0Cu);  // 0609ECA0 mov.l 0x0609ED0C,r4
    c.r[7] = ld32(0x0609ED10u);  // 0609ECA2 mov.l 0x0609ED10,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609ECA8u; c.r[4] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ECA8u) return; }  // 0609ECA4 jsr @r7 ; sub r1,r4
    c.r[7] = c.r[0];  // 0609ECA8 mov r0,r7
    c.r[0] = c.r[8];  // 0609ECAA mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609ECAC mov.l @(r0,r9),r1
    c.r[1] += c.r[7];  // 0609ECAE add r7,r1
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609ECB0 mov.l r1,@(r0,r9)
    c.r[2] = ld32(c.r[0] + c.r[6]);  // 0609ECB2 mov.l @(r0,r6),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0609ECB4 cmp/gt r2,r1
    if (!c.t) { goto L_0609ECBC; }  // 0609ECB6 bf 0x0609ECBC
    st32(c.r[0] + c.r[9], c.r[2]);  // 0609ECB8 mov.l r2,@(r0,r9)
    c.r[0] = c.r[8];  // 0609ECBA mov r8,r0
L_0609ECBC:
    c.r[4] = ld32(c.r[0] + c.r[9]);  // 0609ECBC mov.l @(r0,r9),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609ED00u);  // 0609ECBE mov.w 0x0609ED00,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0609ECC0 cmp/gt r1,r4
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0609ECE8; } }  // 0609ECC2 bf/s 0x0609ECE8 ; mov r11,r0
    c.r[1] = ld32(0x0609ED14u);  // 0609ECC6 mov.l 0x0609ED14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609ECCCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ECCCu) return; }  // 0609ECC8 jsr @r1 ; nop
    c.r[5] = c.r[4];  // 0609ECCC mov r4,r5
    c.r[5] <<= 8;  // 0609ECCE shll8 r5
    c.r[5] += c.r[5];  // 0609ECD0 add r5,r5
    c.r[5] <<= 2;  // 0609ECD2 shll2 r5
    { const uint32_t x = c.r[12]; c.pr = 0x0609ECD8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ECD8u) return; }  // 0609ECD4 jsr @r12 ; mov r8,r4
    c.r[11] = c.r[0];  // 0609ECD8 mov r0,r11
    c.t = (int32_t)c.r[11] >= 0;  // 0609ECDA cmp/pz r11
    if (!c.t) { goto L_0609ECEA; }  // 0609ECDC bf 0x0609ECEA
    c.r[0] = c.r[8];  // 0609ECDE mov r8,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609ECE0 mov.l @(r0,r9),r1
    c.r[1] -= c.r[11];  // 0609ECE2 sub r11,r1
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609ECE4 mov.l r1,@(r0,r9)
    c.r[0] = c.r[11];  // 0609ECE6 mov r11,r0
L_0609ECE8:
    c.r[0] += c.r[10];  // 0609ECE8 add r10,r0
L_0609ECEA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609ECEA lds.l @r15+,pr
L_0609ECEC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609ECEC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609ECEE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609ECF0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609ECF2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609ECF4 rts ; mov.l @r15+,r8
}

void f_0609ED30(SH2Context& c) {
    ran[2564] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609ED30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609ED32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609ED34 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609ED36 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609ED38 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609ED3A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609ED3C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609ED3E sts.l pr,@-r15
    c.r[11] = c.r[5];  // 0609ED40 mov r5,r11
    c.r[13] = c.r[6];  // 0609ED42 mov r6,r13
    c.r[5] = c.r[7];  // 0609ED44 mov r7,r5
    c.r[1] = c.r[4];  // 0609ED46 mov r4,r1
    c.r[9] = ld32(c.r[15] + 32);  // 0609ED48 mov.l @(32,r15),r9
    c.r[1] += 68;  // 0609ED4A add #68,r1
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609ED4C tst r5,r5
    { const bool k = c.t; c.r[8] = ld32(c.r[1]); if (k) { goto L_0609ED5A; } }  // 0609ED4E bt/s 0x0609ED5A ; mov.l @r1,r8
    c.r[0] = c.r[5];  // 0609ED52 mov r5,r0
    c.t = c.r[0] == 0x2u;  // 0609ED54 cmp/eq #2,r0
    { const bool k = !c.t; c.r[14] = c.r[5]; if (k) { goto L_0609ED82; } }  // 0609ED56 bf/s 0x0609ED82 ; mov r5,r14
L_0609ED5A:
    c.r[1] = c.r[4];  // 0609ED5A mov r4,r1
    c.r[1] += 64;  // 0609ED5C add #64,r1
    c.r[2] = ld32(c.r[1]);  // 0609ED5E mov.l @r1,r2
    c.r[3] = ld32(c.r[4] + 4);  // 0609ED60 mov.l @(4,r4),r3
    c.r[1] = 0x64u;  // 0609ED62 mov #100,r1
    c.macl = c.r[3] * c.r[1];  // 0609ED64 mul.l r1,r3
    c.r[7] = c.r[4];  // 0609ED66 mov r4,r7
    c.r[1] = c.macl;  // 0609ED68 sts macl,r1
    c.r[2] += c.r[1];  // 0609ED6A add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609EE46u);  // 0609ED6C mov.w 0x0609EE46,r1
    c.r[0] = c.r[2];  // 0609ED6E mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609ED70 mov.l @(r0,r1),r1
    c.r[7] += 76;  // 0609ED72 add #76,r7
    c.r[0] = c.r[5];  // 0609ED74 mov r5,r0
    c.t = c.r[0] == 0x2u;  // 0609ED76 cmp/eq #2,r0
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_0609ED80; } }  // 0609ED78 bf/s 0x0609ED80 ; mov.l r1,@r7
    c.r[0] = c.r[1]; goto L_0609EE84;  // 0609ED7C bra 0x0609EE84 ; mov r1,r0
L_0609ED80:
    c.r[14] = c.r[5];  // 0609ED80 mov r5,r14
L_0609ED82:
    c.t = (c.r[14] & c.r[14]) == 0;  // 0609ED82 tst r14,r14
    if (!c.t) { goto L_0609ED88; }  // 0609ED84 bf 0x0609ED88
    c.r[14] = c.t;  // 0609ED86 movt r14
L_0609ED88:
    c.r[1] = c.r[4];  // 0609ED88 mov r4,r1
    c.r[1] += 76;  // 0609ED8A add #76,r1
    c.r[6] = ld32(c.r[1]);  // 0609ED8C mov.l @r1,r6
    c.r[0] = c.r[14];  // 0609ED8E mov r14,r0
    c.r[12] = c.r[6];  // 0609ED90 mov r6,r12
    c.r[2] = c.r[6];  // 0609ED92 mov r6,r2
    c.r[2] <<= 2;  // 0609ED94 shll2 r2
    c.r[2] += c.r[2];  // 0609ED96 add r2,r2
    c.r[1] = ld32(c.r[8] + 56);  // 0609ED98 mov.l @(56,r8),r1
    c.t = c.r[0] == 0x1u;  // 0609ED9A cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] += c.r[1]; if (k) { goto L_0609EDAC; } }  // 0609ED9C bf/s 0x0609EDAC ; add r1,r2
    c.r[1] = c.r[8];  // 0609EDA0 mov r8,r1
    c.r[1] += 68;  // 0609EDA2 add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609EDA4 mov.l @r1,r1
    c.r[3] = c.r[1];  // 0609EDA6 mov r1,r3
    c.r[3] -= c.r[6]; goto L_0609EDB0;  // 0609EDA8 bra 0x0609EDB0 ; sub r6,r3
L_0609EDAC:
    c.r[3] = c.r[6];  // 0609EDAC mov r6,r3
    c.r[3] += 1;  // 0609EDAE add #1,r3
L_0609EDB0:
    c.r[1] = c.r[3];  // 0609EDB0 mov r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609EDB2 cmp/pl r1
    { const bool k = !c.t; c.r[3] -= 1; if (k) { goto L_0609EDE0; } }  // 0609EDB4 bf/s 0x0609EDE0 ; add #-1,r3
    c.r[10] = ld32(c.r[4] + 4);  // 0609EDB8 mov.l @(4,r4),r10
    c.r[5] = c.r[14];  // 0609EDBA mov r14,r5
    c.r[5] <<= 2;  // 0609EDBC shll2 r5
    c.r[5] += c.r[5];  // 0609EDBE add r5,r5
    c.r[7] = c.r[2];  // 0609EDC0 mov r2,r7
    c.r[7] += 6;  // 0609EDC2 add #6,r7
L_0609EDC4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0609EDC4 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609EDC6 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0609EDC8 cmp/eq r10,r1
    if (!c.t) { goto L_0609EDD2; }  // 0609EDCA bf 0x0609EDD2
    c.r[9] -= 1;  // 0609EDCC add #-1,r9
    c.t = (int32_t)c.r[9] > 0;  // 0609EDCE cmp/pl r9
    if (!c.t) { goto L_0609EDE0; }  // 0609EDD0 bf 0x0609EDE0
L_0609EDD2:
    c.r[7] += c.r[5];  // 0609EDD2 add r5,r7
    c.r[2] += c.r[5];  // 0609EDD4 add r5,r2
    c.r[6] += c.r[14];  // 0609EDD6 add r14,r6
    c.r[1] = c.r[3];  // 0609EDD8 mov r3,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609EDDA cmp/pl r1
    { const bool k = c.t; c.r[3] -= 1; if (k) { SH2_POLL(c); goto L_0609EDC4; } }  // 0609EDDC bt/s 0x0609EDC4 ; add #-1,r3
L_0609EDE0:
    c.r[3] = c.r[4];  // 0609EDE0 mov r4,r3
    c.r[3] += 76;  // 0609EDE2 add #76,r3
    c.r[1] = c.r[6];  // 0609EDE4 mov r6,r1
    c.r[1] += c.r[14];  // 0609EDE6 add r14,r1
    st32(c.r[3], c.r[1]);  // 0609EDE8 mov.l r1,@r3
    c.r[1] = c.r[8];  // 0609EDEA mov r8,r1
    c.r[1] += 68;  // 0609EDEC add #68,r1
    c.r[1] = ld32(c.r[1]);  // 0609EDEE mov.l @r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 0609EDF0 cmp/ge r1,r6
    if (!c.t) { goto L_0609EE0C; }  // 0609EDF2 bf 0x0609EE0C
    c.r[0] = ld32(c.r[8] + 16);  // 0609EDF4 mov.l @(16,r8),r0
    c.t = c.r[0] == 0x1u;  // 0609EDF6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_0609EE0C; } }  // 0609EDF8 bf/s 0x0609EE0C ; mov #-1,r6
    c.r[1] = c.r[4];  // 0609EDFC mov r4,r1
    c.r[1] += 72;  // 0609EDFE add #72,r1
    c.r[2] = ld32(c.r[8] + 32);  // 0609EE00 mov.l @(32,r8),r2
    c.r[0] = 0xFFFFFFFDu;  // 0609EE02 mov #-3,r0
    st32(c.r[1], c.r[2]);  // 0609EE04 mov.l r2,@r1
    c.r[1] = 0x0u;  // 0609EE06 mov #0,r1
    st32(c.r[3], c.r[1]); goto L_0609EE84;  // 0609EE08 bra 0x0609EE84 ; mov.l r1,@r3
L_0609EE0C:
    c.r[1] = 0x0u;  // 0609EE0C mov #0,r1
    st32(c.r[11], c.r[1]);  // 0609EE0E mov.l r1,@r11
    st32(c.r[13], c.r[1]);  // 0609EE10 mov.l r1,@r13
    c.r[1] = 0xFFFFFFFFu;  // 0609EE12 mov #-1,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0609EE14 cmp/gt r1,r6
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { goto L_0609EE84; } }  // 0609EE16 bf/s 0x0609EE84 ; mov r6,r0
    c.r[7] = c.r[2];  // 0609EE1A mov r2,r7
    c.r[7] += 7;  // 0609EE1C add #7,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0609EE1E mov.b @r7,r3
    c.r[1] = 0x2u;  // 0609EE20 mov #2,r1
    c.r[1] &= c.r[3];  // 0609EE22 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609EE24 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0609EE32; } }  // 0609EE26 bt/s 0x0609EE32 ; mov r4,r1
    c.r[1] += 76;  // 0609EE2A add #76,r1
    st32(c.r[1], c.r[12]);  // 0609EE2C mov.l r12,@r1
    c.r[0] = 0xFFFFFFFCu; goto L_0609EE84;  // 0609EE2E bra 0x0609EE84 ; mov #-4,r0
L_0609EE32:
    c.r[0] = c.r[3];  // 0609EE32 mov r3,r0
    c.r[0] &= 0x1u;  // 0609EE34 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609EE36 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0609EE48; } }  // 0609EE38 bf/s 0x0609EE48 ; mov r2,r1
    c.r[1] = c.r[4];  // 0609EE3C mov r4,r1
    c.r[1] += 76;  // 0609EE3E add #76,r1
    st32(c.r[1], c.r[12]);  // 0609EE40 mov.l r12,@r1
    c.r[0] = 0xFFFFFFFEu; goto L_0609EE84;  // 0609EE42 bra 0x0609EE84 ; mov #-2,r0
L_0609EE48:
    c.r[1] += 4;  // 0609EE48 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609EE4A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609EE4C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609EE4E tst r1,r1
    { const bool k = c.t; st32(c.r[13], c.r[1]); if (k) { goto L_0609EE82; } }  // 0609EE50 bt/s 0x0609EE82 ; mov.l r1,@r13
    c.r[1] = c.r[4];  // 0609EE54 mov r4,r1
    c.r[2] = ld32(c.r[2]);  // 0609EE56 mov.l @r2,r2
    c.r[1] += 72;  // 0609EE58 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0609EE5A mov.l @r1,r1
    c.r[3] = ld32(c.r[8] + 20);  // 0609EE5C mov.l @(20,r8),r3
    c.r[2] += c.r[1];  // 0609EE5E add r1,r2
    c.r[4] = c.r[2];  // 0609EE60 mov r2,r4
    c.r[1] = ld32(0x0609EE98u);  // 0609EE62 mov.l 0x0609EE98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609EE68u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EE68u) return; }  // 0609EE64 jsr @r1 ; mov r3,r5
    c.macl = c.r[0] * c.r[3];  // 0609EE68 mul.l r3,r0
    c.r[1] = c.macl;  // 0609EE6A sts macl,r1
    c.r[2] -= c.r[1];  // 0609EE6C sub r1,r2
    c.r[1] = ld32(c.r[8] + 28);  // 0609EE6E mov.l @(28,r8),r1
    c.r[2] += c.r[1];  // 0609EE70 add r1,r2
    st32(c.r[11], c.r[2]);  // 0609EE72 mov.l r2,@r11
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0609EE74 mov.b @r7,r0
    c.r[0] &= 0x4u;  // 0609EE76 and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609EE78 tst r0,r0
    if (c.t) { goto L_0609EE82; }  // 0609EE7A bt 0x0609EE82
    c.r[1] = ld32(c.r[8] + 20);  // 0609EE7C mov.l @(20,r8),r1
    c.r[1] += c.r[2];  // 0609EE7E add r2,r1
    st32(c.r[11], c.r[1]);  // 0609EE80 mov.l r1,@r11
L_0609EE82:
    c.r[0] = c.r[6];  // 0609EE82 mov r6,r0
L_0609EE84:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609EE84 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609EE86 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609EE88 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609EE8A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609EE8C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609EE8E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609EE90 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609EE92 rts ; mov.l @r15+,r8
}

void f_0609EE9C(SH2Context& c) {
    ran[2565] = 1;
    c.r[1] = 0xFFFFFFFFu;  // 0609EE9C mov #-1,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0609EE9E cmp/gt r1,r5
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_0609EEB4; } }  // 0609EEA0 bf/s 0x0609EEB4 ; mov r5,r1
    c.r[2] = ld32(c.r[4] + 56);  // 0609EEA4 mov.l @(56,r4),r2
    c.r[1] <<= 2;  // 0609EEA6 shll2 r1
    c.r[1] += c.r[1];  // 0609EEA8 add r1,r1
    c.r[1] += c.r[2];  // 0609EEAA add r2,r1
    c.r[1] += 7;  // 0609EEAC add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609EEAE mov.b @r1,r0
    c.r[0] |= 0x2u;  // 0609EEB0 or #2,r0
    st8(c.r[1], c.r[0]);  // 0609EEB2 mov.b r0,@r1
L_0609EEB4:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609EEB4 rts ; nop
}

void f_0609EEB8(SH2Context& c) {
    ran[2566] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609EEB8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609EEBA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609EEBC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609EEBE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609EEC0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609EEC2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609EEC4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609EEC6 sts.l pr,@-r15
    c.r[12] = c.r[4];  // 0609EEC8 mov r4,r12
    c.r[11] = c.r[5];  // 0609EECA mov r5,r11
    c.r[6] = 0x0u;  // 0609EECC mov #0,r6
    c.r[1] = c.r[12];  // 0609EECE mov r12,r1
    c.r[1] += 68;  // 0609EED0 add #68,r1
    c.r[0] = c.r[11];  // 0609EED2 mov r11,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609EED4 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[1]); if (k) { goto L_0609EEE0; } }  // 0609EED6 bf/s 0x0609EEE0 ; mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609EEDA mov r2,r1
    c.r[1] += 68;  // 0609EEDC add #68,r1
    c.r[11] = ld32(c.r[1]);  // 0609EEDE mov.l @r1,r11
L_0609EEE0:
    c.r[0] = ld32(c.r[12]);  // 0609EEE0 mov.l @r12,r0
    c.t = c.r[0] == 0x2u;  // 0609EEE2 cmp/eq #2,r0
    { const bool k = c.t; c.r[2] = ld32(c.r[2] + 56); if (k) { goto L_0609EEF4; } }  // 0609EEE4 bt/s 0x0609EEF4 ; mov.l @(56,r2),r2
    c.r[5] = c.r[12];  // 0609EEE8 mov r12,r5
    c.r[5] += 80;  // 0609EEEA add #80,r5
    c.r[1] = ld32(c.r[5]);  // 0609EEEC mov.l @r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609EEEE tst r1,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[6] >= (int32_t)c.r[11]; if (k) { goto L_0609EF14; } }  // 0609EEF0 bf/s 0x0609EF14 ; cmp/ge r11,r6
L_0609EEF4:
    c.t = (int32_t)c.r[6] > (int32_t)c.r[11];  // 0609EEF4 cmp/gt r11,r6
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0609EF10; } }  // 0609EEF6 bt/s 0x0609EF10 ; mov #0,r7
    c.r[4] = ld32(c.r[12] + 4);  // 0609EEFA mov.l @(4,r12),r4
    c.r[2] += 6;  // 0609EEFC add #6,r2
L_0609EEFE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609EEFE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609EF00 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0609EF02 cmp/eq r4,r1
    if (!c.t) { goto L_0609EF08; }  // 0609EF04 bf 0x0609EF08
    c.r[6] += 1;  // 0609EF06 add #1,r6
L_0609EF08:
    c.r[7] += 1;  // 0609EF08 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[11];  // 0609EF0A cmp/gt r11,r7
    { const bool k = !c.t; c.r[2] += 8; if (k) { SH2_POLL(c); goto L_0609EEFE; } }  // 0609EF0C bf/s 0x0609EEFE ; add #8,r2
L_0609EF10:
    c.r[6] -= 1; goto L_0609EF6A;  // 0609EF10 bra 0x0609EF6A ; add #-1,r6
L_0609EF14:
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0609EF52; } }  // 0609EF14 bt/s 0x0609EF52 ; mov #0,r7
    c.r[14] = ld32(c.r[12] + 4);  // 0609EF18 mov.l @(4,r12),r14
    c.r[13] = c.r[5];  // 0609EF1A mov r5,r13
    c.r[10] = c.r[2];  // 0609EF1C mov r2,r10
    c.r[10] += 4;  // 0609EF1E add #4,r10
    c.r[9] = c.r[2];  // 0609EF20 mov r2,r9
    c.r[9] += 7;  // 0609EF22 add #7,r9
    c.r[8] = c.r[2];  // 0609EF24 mov r2,r8
    c.r[8] += 6;  // 0609EF26 add #6,r8
L_0609EF28:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609EF28 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609EF2A extu.b r1,r1
    c.t = c.r[1] == c.r[14];  // 0609EF2C cmp/eq r14,r1
    if (!c.t) { goto L_0609EF46; }  // 0609EF2E bf 0x0609EF46
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0609EF30 mov.b @r9,r0
    c.r[0] &= 0x2u;  // 0609EF32 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609EF34 tst r0,r0
    if (c.t) { goto L_0609EF52; }  // 0609EF36 bt 0x0609EF52
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0609EF38 mov.w @r10,r4
    c.r[0] = ld32(0x0609EF80u);  // 0609EF3A mov.l 0x0609EF80,r0
    c.r[5] = ld32(c.r[13]);  // 0609EF3C mov.l @r13,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609EF42u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EF42u) return; }  // 0609EF3E jsr @r0 ; extu.w r4,r4
    c.r[5] = c.r[0];  // 0609EF42 mov r0,r5
    c.r[6] += c.r[5];  // 0609EF44 add r5,r6
L_0609EF46:
    c.r[7] += 1;  // 0609EF46 add #1,r7
    c.r[10] += 8;  // 0609EF48 add #8,r10
    c.r[9] += 8;  // 0609EF4A add #8,r9
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[11];  // 0609EF4C cmp/ge r11,r7
    { const bool k = !c.t; c.r[8] += 8; if (k) { SH2_POLL(c); goto L_0609EF28; } }  // 0609EF4E bf/s 0x0609EF28 ; add #8,r8
L_0609EF52:
    c.r[1] = c.r[12];  // 0609EF52 mov r12,r1
    c.r[1] += 44;  // 0609EF54 add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609EF56 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0609EF58 extu.w r1,r0
    c.t = c.r[0] == 0x1u;  // 0609EF5A cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0609EF6A; } }  // 0609EF5C bt/s 0x0609EF6A ; mov r12,r1
    c.r[1] += 62;  // 0609EF60 add #62,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609EF62 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609EF64 extu.w r1,r1
    c.macl = c.r[6] * c.r[1];  // 0609EF66 mul.l r1,r6
    c.r[6] = c.macl;  // 0609EF68 sts macl,r6
L_0609EF6A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609EF6A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF6C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF6E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF70 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF72 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF74 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF76 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609EF78 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0609EF7A rts ; mov r6,r0
}

void f_0609EF84(SH2Context& c) {
    ran[2567] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609EF84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609EF86 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609EF88 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609EF8A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609EF8C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609EF8E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609EF90 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609EF92 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609EF94 add #-16,r15
    c.r[14] = c.r[4];  // 0609EF96 mov r4,r14
    c.r[12] = c.r[6];  // 0609EF98 mov r6,r12
    c.r[13] = 0x0u;  // 0609EF9A mov #0,r13
    st32(c.r[15] + 4, c.r[13]);  // 0609EF9C mov.l r13,@(4,r15)
    c.r[1] = c.r[14];  // 0609EF9E mov r14,r1
    c.r[1] += 68;  // 0609EFA0 add #68,r1
    st32(c.r[1], c.r[13]);  // 0609EFA2 mov.l r13,@r1
    c.r[1] = c.r[14];  // 0609EFA4 mov r14,r1
    c.r[1] += 80;  // 0609EFA6 add #80,r1
    st32(c.r[1], c.r[13]);  // 0609EFA8 mov.l r13,@r1
    st32(c.r[14] + 56, c.r[5]);  // 0609EFAA mov.l r5,@(56,r14)
    c.r[10] = c.r[5];  // 0609EFAC mov r5,r10
    c.r[1] = ld32(c.r[14] + 12);  // 0609EFAE mov.l @(12,r14),r1
    c.r[13] = c.r[10];  // 0609EFB0 mov r10,r13
    c.r[13] += 8;  // 0609EFB2 add #8,r13
    c.r[11] = c.r[1];  // 0609EFB4 mov r1,r11
    c.r[11] -= 16;  // 0609EFB6 add #-16,r11
    c.t = (int32_t)c.r[12] > (int32_t)c.r[11];  // 0609EFB8 cmp/gt r11,r12
    { const bool k = !c.t; st32(c.r[15] + 12, c.r[13]); if (k) { goto L_0609EFD6; } }  // 0609EFBA bf/s 0x0609EFD6 ; mov.l r13,@(12,r15)
    c.r[8] = ld32(0x0609F0DCu);  // 0609EFBE mov.l 0x0609F0DC,r8
L_0609EFC0:
    c.t = c.r[11] & 1; c.r[11] = (uint32_t)((int32_t)c.r[11] >> 1);  // 0609EFC0 shar r11
    c.t = (int32_t)c.r[11] > 0;  // 0609EFC2 cmp/pl r11
    { const bool k = !c.t; c.r[5] = c.t; if (k) { goto L_0609F0C4; } }  // 0609EFC4 bf/s 0x0609F0C4 ; movt r5
    { const uint32_t x = c.r[8]; c.pr = 0x0609EFCCu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EFCCu) return; }  // 0609EFC8 jsr @r8 ; mov r11,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609EFCC tst r0,r0
    { const bool k = c.t; st32(c.r[15] + 12, c.r[0]); if (k) { SH2_POLL(c); goto L_0609EFC0; } }  // 0609EFCE bt/s 0x0609EFC0 ; mov.l r0,@(12,r15)
    c.r[13] = 0x1u;  // 0609EFD2 mov #1,r13
    st32(c.r[15] + 4, c.r[13]);  // 0609EFD4 mov.l r13,@(4,r15)
L_0609EFD6:
    c.t = (int32_t)c.r[12] > 0;  // 0609EFD6 cmp/pl r12
    { const bool k = !c.t; c.r[2] = c.r[14]; if (k) { goto L_0609F0AA; } }  // 0609EFD8 bf/s 0x0609F0AA ; mov r14,r2
    c.r[13] = c.r[14];  // 0609EFDC mov r14,r13
    c.r[13] += 80;  // 0609EFDE add #80,r13
    st32(c.r[15] + 8, c.r[13]);  // 0609EFE0 mov.l r13,@(8,r15)
    c.t = (int32_t)c.r[12] > (int32_t)c.r[11];  // 0609EFE2 cmp/gt r11,r12
L_0609EFE4:
    { const bool k = !c.t; c.r[8] = c.r[12]; if (k) { goto L_0609EFEA; } }  // 0609EFE4 bf/s 0x0609EFEA ; mov r12,r8
    c.r[8] = c.r[11];  // 0609EFE8 mov r11,r8
L_0609EFEA:
    c.r[9] = ld32(c.r[15] + 12);  // 0609EFEA mov.l @(12,r15),r9
    c.r[1] = ld32(c.r[14]);  // 0609EFEC mov.l @r14,r1
    c.r[0] = ld32(0x0609F0E0u);  // 0609EFEE mov.l 0x0609F0E0,r0
    c.r[5] = ld32(c.r[15] + 12);  // 0609EFF0 mov.l @(12,r15),r5
    c.r[1] += 108;  // 0609EFF2 add #108,r1
    c.r[4] = ld32(c.r[1]);  // 0609EFF4 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0609EFFAu; c.r[6] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609EFFAu) return; }  // 0609EFF6 jsr @r0 ; mov r8,r6
    c.t = c.r[0] == c.r[8];  // 0609EFFA cmp/eq r8,r0
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= 0; if (k) { goto L_0609F00A; } }  // 0609EFFC bt/s 0x0609F00A ; cmp/pz r0
    { const bool k = !c.t; c.r[1] = 0xFu; if (k) { goto L_0609F0B8; } }  // 0609F000 bf/s 0x0609F0B8 ; mov #15,r1
    c.r[1] &= c.r[0];  // 0609F004 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F006 tst r1,r1
    if (!c.t) { goto L_0609F0B8; }  // 0609F008 bf 0x0609F0B8
L_0609F00A:
    c.r[12] -= c.r[0];  // 0609F00A sub r0,r12
    c.r[0] >>= 2;  // 0609F00C shlr2 r0
    c.r[0] >>= 2;  // 0609F00E shlr2 r0
    c.r[4] = 0x0u;  // 0609F010 mov #0,r4
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 0609F012 cmp/ge r0,r4
    { const bool k = c.t; st32(c.r[15], c.r[0]); if (k) { goto L_0609F0A2; } }  // 0609F014 bt/s 0x0609F0A2 ; mov.l r0,@r15
    c.r[7] = c.r[9];  // 0609F018 mov r9,r7
    c.r[7] += 4;  // 0609F01A add #4,r7
    c.r[8] = c.r[10];  // 0609F01C mov r10,r8
    c.r[8] += 6;  // 0609F01E add #6,r8
    c.r[5] = c.r[10];  // 0609F020 mov r10,r5
    c.r[5] += 7;  // 0609F022 add #7,r5
    c.r[6] = c.r[10];  // 0609F024 mov r10,r6
    c.r[6] += 4;  // 0609F026 add #4,r6
L_0609F028:
    c.r[1] = ld32(c.r[9]);  // 0609F028 mov.l @r9,r1
    c.r[0] = c.r[1];  // 0609F02A mov r1,r0
    c.r[0] >>= 16;  // 0609F02C shlr16 r0
    c.r[0] >>= 8;  // 0609F02E shlr8 r0
    c.r[1] = ld32(0x0609F0E4u);  // 0609F030 mov.l 0x0609F0E4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0609F032 mov.b @(r0,r1),r0
    c.r[0] &= 0x4u;  // 0609F034 and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F036 tst r0,r0
    if (c.t) { goto L_0609F096; }  // 0609F038 bt 0x0609F096
    c.r[1] = ld32(c.r[7] + 4);  // 0609F03A mov.l @(4,r7),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609F03C swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609F03E swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609F040 swap.b r1,r1
    st32(c.r[10], c.r[1]);  // 0609F042 mov.l r1,@r10
    c.r[1] = ld32(c.r[7] + 8);  // 0609F044 mov.l @(8,r7),r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609F046 swap.b r1,r1
    c.r[1] = c.r[1] << 16 | c.r[1] >> 16;  // 0609F048 swap.w r1,r1
    c.r[1] = (c.r[1] & 0xFFFF0000u) | (c.r[1] & 0xFFu) << 8 | (c.r[1] >> 8 & 0xFFu);  // 0609F04A swap.b r1,r1
    st16(c.r[6], c.r[1]);  // 0609F04C mov.w r1,@r6
    c.r[1] = ld32(c.r[7]);  // 0609F04E mov.l @r7,r1
    c.r[0] = c.r[1];  // 0609F050 mov r1,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 0609F052 swap.b r0,r0
    c.r[0] = c.r[0] << 16 | c.r[0] >> 16;  // 0609F054 swap.w r0,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 0609F056 swap.b r0,r0
    c.r[0] &= 0x10u;  // 0609F058 and #16,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F05A tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x8u; if (k) { goto L_0609F062; } }  // 0609F05C bf/s 0x0609F062 ; mov #8,r1
    c.r[1] = 0x0u;  // 0609F060 mov #0,r1
L_0609F062:
    st8(c.r[5], c.r[1]);  // 0609F062 mov.b r1,@r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0609F064 mov.w @r6,r1
    c.r[13] = ld32(c.r[15] + 8);  // 0609F066 mov.l @(8,r15),r13
    c.r[2] = c.r[1] & 0xFFFFu;  // 0609F068 extu.w r1,r2
    c.r[1] = ld32(c.r[13]);  // 0609F06A mov.l @r13,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609F06C cmp/gt r1,r2
    if (!c.t) { goto L_0609F072; }  // 0609F06E bf 0x0609F072
    st32(c.r[13], c.r[2]);  // 0609F070 mov.l r2,@r13
L_0609F072:
    c.r[3] = ld32(c.r[9]);  // 0609F072 mov.l @r9,r3
    c.r[5] += 8;  // 0609F074 add #8,r5
    c.r[6] += 8;  // 0609F076 add #8,r6
    c.r[10] += 8;  // 0609F078 add #8,r10
    c.r[2] = c.r[3];  // 0609F07A mov r3,r2
    c.r[2] >>= 16;  // 0609F07C shlr16 r2
    c.r[2] >>= 8;  // 0609F07E shlr8 r2
    c.r[2] -= 48;  // 0609F080 add #-48,r2
    c.r[1] = c.r[2];  // 0609F082 mov r2,r1
    c.r[1] <<= 2;  // 0609F084 shll2 r1
    c.r[1] += c.r[2];  // 0609F086 add r2,r1
    c.r[1] += c.r[1];  // 0609F088 add r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609F0D8u);  // 0609F08A mov.w 0x0609F0D8,r2
    c.r[1] += c.r[2];  // 0609F08C add r2,r1
    c.r[3] >>= 16;  // 0609F08E shlr16 r3
    c.r[1] += c.r[3];  // 0609F090 add r3,r1
    st8(c.r[8], c.r[1]);  // 0609F092 mov.b r1,@r8
    c.r[8] += 8;  // 0609F094 add #8,r8
L_0609F096:
    c.r[4] += 1;  // 0609F096 add #1,r4
    c.r[7] += 16;  // 0609F098 add #16,r7
    c.r[13] = ld32(c.r[15]);  // 0609F09A mov.l @r15,r13
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[13];  // 0609F09C cmp/ge r13,r4
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_0609F028; } }  // 0609F09E bf/s 0x0609F028 ; add #16,r9
L_0609F0A2:
    c.t = (int32_t)c.r[12] > 0;  // 0609F0A2 cmp/pl r12
    { const bool k = c.t; c.t = (int32_t)c.r[12] > (int32_t)c.r[11]; if (k) { SH2_POLL(c); goto L_0609EFE4; } }  // 0609F0A4 bt/s 0x0609EFE4 ; cmp/gt r11,r12
    c.r[2] = c.r[14];  // 0609F0A8 mov r14,r2
L_0609F0AA:
    c.r[1] = ld32(c.r[14] + 56);  // 0609F0AA mov.l @(56,r14),r1
    c.r[2] += 68;  // 0609F0AC add #68,r2
    c.r[10] -= c.r[1];  // 0609F0AE sub r1,r10
    c.r[1] = c.r[10];  // 0609F0B0 mov r10,r1
    c.r[1] >>= 2;  // 0609F0B2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0609F0B4 shlr r1
    st32(c.r[2], c.r[1]);  // 0609F0B6 mov.l r1,@r2
L_0609F0B8:
    c.r[13] = ld32(c.r[15] + 4);  // 0609F0B8 mov.l @(4,r15),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 0609F0BA tst r13,r13
    if (c.t) { goto L_0609F0C4; }  // 0609F0BC bt 0x0609F0C4
    c.r[1] = ld32(0x0609F0E8u);  // 0609F0BE mov.l 0x0609F0E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F0C4u; c.r[4] = ld32(c.r[15] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F0C4u) return; }  // 0609F0C0 jsr @r1 ; mov.l @(12,r15),r4
L_0609F0C4:
    c.r[15] += 16;  // 0609F0C4 add #16,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F0C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609F0C8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609F0CA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609F0CC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609F0CE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609F0D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F0D2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F0D4 rts ; mov.l @r15+,r8
}

void f_0609F0EC(SH2Context& c) {
    ran[2568] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F0EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F0EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609F0F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609F0F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F0F4 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0609F0F6 mov r5,r9
    c.r[10] = ld32(0x0609F144u);  // 0609F0F8 mov.l 0x0609F144,r10
    c.r[1] = ld32(0x0609F148u);  // 0609F0FA mov.l 0x0609F148,r1
    st32(c.r[1], c.r[4]);  // 0609F0FC mov.l r4,@r1
    c.r[11] = ld32(0x0609F14Cu);  // 0609F0FE mov.l 0x0609F14C,r11
    c.r[6] = 0x0u;  // 0609F100 mov #0,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0609F106u; c.r[5] = 0x34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F106u) return; }  // 0609F102 jsr @r11 ; mov #52,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F106 tst r0,r0
    { const bool k = c.t; st32(c.r[10], c.r[0]); if (k) { goto L_0609F134; } }  // 0609F108 bt/s 0x0609F134 ; mov.l r0,@r10
    c.r[8] = ld32(0x0609F150u);  // 0609F10C mov.l 0x0609F150,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609F142u);  // 0609F10E mov.w 0x0609F142,r5
    c.r[1] = ld32(0x0609F154u);  // 0609F110 mov.l 0x0609F154,r1
    st32(c.r[1], c.r[9]);  // 0609F112 mov.l r9,@r1
    c.r[6] = 0x0u;  // 0609F114 mov #0,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0609F11Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F11Au) return; }  // 0609F116 jsr @r11 ; mov r9,r4
    st32(c.r[8], c.r[0]);  // 0609F11A mov.l r0,@r8
    c.r[0] = ld32(0x0609F158u);  // 0609F11C mov.l 0x0609F158,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609F122u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F122u) return; }  // 0609F11E jsr @r0 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609F122 mov.l @r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F124 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609F136; } }  // 0609F126 bf/s 0x0609F136 ; mov #0,r0
    c.r[1] = ld32(0x0609F15Cu);  // 0609F12A mov.l 0x0609F15C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F130u; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F130u) return; }  // 0609F12C jsr @r1 ; mov.l @r10,r4
    c.r[1] = 0x0u;  // 0609F130 mov #0,r1
    st32(c.r[10], c.r[1]);  // 0609F132 mov.l r1,@r10
L_0609F134:
    c.r[0] = 0xFFFFFFFFu;  // 0609F134 mov #-1,r0
L_0609F136:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F136 lds.l @r15+,pr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609F138 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609F13A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F13C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F13E rts ; mov.l @r15+,r8
}

void f_0609F160(SH2Context& c) {
    ran[2569] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F160 tst r4,r4
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0609F172; } }  // 0609F162 bt/s 0x0609F172 ; mov r4,r1
    c.r[1] += 50;  // 0609F166 add #50,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609F168 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0609F16A and #127,r0
    st8(c.r[1], c.r[0]);  // 0609F16C mov.b r0,@r1
    c.r[1] = 0x0u;  // 0609F16E mov #0,r1
    st32(c.r[4] + 4, c.r[1]);  // 0609F170 mov.l r1,@(4,r4)
L_0609F172:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609F172 rts ; nop
}

void f_0609F178(SH2Context& c) {
    ran[2570] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F178 mov.l r8,@-r15
    c.r[8] = c.r[4];  // 0609F17A mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609F17C tst r8,r8
    { const bool k = c.t; c.r[15] -= 4; st32(c.r[15], c.pr); if (k) { goto L_0609F1C6; } }  // 0609F17E bt/s 0x0609F1C6 ; sts.l pr,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F1CCu);  // 0609F182 mov.w 0x0609F1CC,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0609F184 mov.b @(r0,r8),r0
    c.r[0] &= 0x80u;  // 0609F186 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F188 tst r0,r0
    if (c.t) { goto L_0609F1C6; }  // 0609F18A bt 0x0609F1C6
    c.r[4] = ld32(c.r[8] + 16);  // 0609F18C mov.l @(16,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F18E tst r4,r4
    if (!c.t) { goto L_0609F19E; }  // 0609F190 bf 0x0609F19E
    c.r[4] = ld32(c.r[8] + 8);  // 0609F192 mov.l @(8,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F194 tst r4,r4
    if (c.t) { goto L_0609F1A4; }  // 0609F196 bt 0x0609F1A4
    c.r[1] = ld32(0x0609F1D0u);  // 0609F198 mov.l 0x0609F1D0,r1
    c.t = c.r[4] == c.r[1];  // 0609F19A cmp/eq r1,r4
    if (c.t) { goto L_0609F1A4; }  // 0609F19C bt 0x0609F1A4
L_0609F19E:
    c.r[1] = ld32(0x0609F1D4u);  // 0609F19E mov.l 0x0609F1D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F1A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F1A4u) return; }  // 0609F1A0 jsr @r1 ; nop
L_0609F1A4:
    c.r[4] = ld32(c.r[8] + 36);  // 0609F1A4 mov.l @(36,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F1A6 tst r4,r4
    if (c.t) { goto L_0609F1B0; }  // 0609F1A8 bt 0x0609F1B0
    c.r[1] = ld32(0x0609F1D4u);  // 0609F1AA mov.l 0x0609F1D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F1B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F1B0u) return; }  // 0609F1AC jsr @r1 ; nop
L_0609F1B0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F1CCu);  // 0609F1B0 mov.w 0x0609F1CC,r1
    c.r[0] = c.r[8];  // 0609F1B2 mov r8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0609F1B4 mov.b @(r0,r1),r2
    c.r[0] = 0x7Fu;  // 0609F1B6 mov #127,r0
    c.r[2] &= c.r[0];  // 0609F1B8 and r0,r2
    c.r[0] = c.r[8];  // 0609F1BA mov r8,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0609F1BC mov.b r2,@(r0,r1)
    c.r[1] = 0x0u;  // 0609F1BE mov #0,r1
    st32(c.r[8] + 16, c.r[1]);  // 0609F1C0 mov.l r1,@(16,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0609F1C2 mov.l r1,@(8,r8)
    st32(c.r[8] + 4, c.r[1]);  // 0609F1C4 mov.l r1,@(4,r8)
L_0609F1C6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F1C6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F1C8 rts ; mov.l @r15+,r8
}

void f_0609F1D8(SH2Context& c) {
    ran[2571] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F1D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F1DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609F1DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609F1DE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609F1E0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F1E2 sts.l pr,@-r15
    c.r[3] = ld32(0x0609F2C4u);  // 0609F1E4 mov.l 0x0609F2C4,r3
    c.r[1] = ld32(c.r[3]);  // 0609F1E6 mov.l @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F1E8 tst r1,r1
    if (c.t) { goto L_0609F228; }  // 0609F1EA bt 0x0609F228
    c.r[9] = 0x0u;  // 0609F1EC mov #0,r9
    c.r[2] = ld32(0x0609F2C8u);  // 0609F1EE mov.l 0x0609F2C8,r2
    c.r[1] = ld32(c.r[2]);  // 0609F1F0 mov.l @r2,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0609F1F2 cmp/ge r1,r9
    { const bool k = c.t; c.r[5] = c.r[3]; if (k) { goto L_0609F21E; } }  // 0609F1F4 bt/s 0x0609F21E ; mov r3,r5
    c.r[6] = 0x0u;  // 0609F1F8 mov #0,r6
    c.r[7] = c.r[2];  // 0609F1FA mov r2,r7
    c.r[3] = 0x0u;  // 0609F1FC mov #0,r3
L_0609F1FE:
    c.r[1] = ld32(c.r[5]);  // 0609F1FE mov.l @r5,r1
    c.r[2] = c.r[3];  // 0609F200 mov r3,r2
    c.r[2] += c.r[1];  // 0609F202 add r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609F204 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0609F214; } }  // 0609F206 bt/s 0x0609F214 ; mov r2,r1
    c.r[1] += 50;  // 0609F20A add #50,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609F20C mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0609F20E and #127,r0
    st8(c.r[1], c.r[0]);  // 0609F210 mov.b r0,@r1
    st32(c.r[2] + 4, c.r[6]);  // 0609F212 mov.l r6,@(4,r2)
L_0609F214:
    c.r[1] = ld32(c.r[7]);  // 0609F214 mov.l @r7,r1
    c.r[9] += 1;  // 0609F216 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0609F218 cmp/ge r1,r9
    { const bool k = !c.t; c.r[3] += 52; if (k) { SH2_POLL(c); goto L_0609F1FE; } }  // 0609F21A bf/s 0x0609F1FE ; add #52,r3
L_0609F21E:
    c.r[1] = ld32(0x0609F2C4u);  // 0609F21E mov.l 0x0609F2C4,r1
    c.r[4] = ld32(c.r[1]);  // 0609F220 mov.l @r1,r4
    c.r[1] = ld32(0x0609F2CCu);  // 0609F222 mov.l 0x0609F2CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F228u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F228u) return; }  // 0609F224 jsr @r1 ; nop
L_0609F228:
    c.r[1] = ld32(0x0609F2D0u);  // 0609F228 mov.l 0x0609F2D0,r1
    c.r[1] = ld32(c.r[1]);  // 0609F22A mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F22C tst r1,r1
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0609F2A6; } }  // 0609F22E bt/s 0x0609F2A6 ; mov #0,r9
    c.r[1] = ld32(0x0609F2D4u);  // 0609F232 mov.l 0x0609F2D4,r1
    c.r[1] = ld32(c.r[1]);  // 0609F234 mov.l @r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0609F236 cmp/ge r1,r9
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0609F29C; } }  // 0609F238 bt/s 0x0609F29C ; mov #0,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x0609F2BEu);  // 0609F23C mov.w 0x0609F2BE,r12
    c.r[11] = ld32(0x0609F2CCu);  // 0609F23E mov.l 0x0609F2CC,r11
L_0609F240:
    c.r[1] = ld32(0x0609F2D0u);  // 0609F240 mov.l 0x0609F2D0,r1
    c.r[1] = ld32(c.r[1]);  // 0609F242 mov.l @r1,r1
    c.r[8] = c.r[10];  // 0609F244 mov r10,r8
    c.r[8] += c.r[1];  // 0609F246 add r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609F248 tst r8,r8
    if (c.t) { goto L_0609F28E; }  // 0609F24A bt 0x0609F28E
    c.r[0] = c.r[8];  // 0609F24C mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0609F24E mov.b @(r0,r12),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F2C0u);  // 0609F250 mov.w 0x0609F2C0,r0
    c.r[1] &= c.r[0];  // 0609F252 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F254 tst r1,r1
    if (c.t) { goto L_0609F28E; }  // 0609F256 bt 0x0609F28E
    c.r[4] = ld32(c.r[8] + 16);  // 0609F258 mov.l @(16,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F25A tst r4,r4
    if (!c.t) { goto L_0609F26A; }  // 0609F25C bf 0x0609F26A
    c.r[4] = ld32(c.r[8] + 8);  // 0609F25E mov.l @(8,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F260 tst r4,r4
    if (c.t) { goto L_0609F26E; }  // 0609F262 bt 0x0609F26E
    c.r[1] = ld32(0x0609F2D8u);  // 0609F264 mov.l 0x0609F2D8,r1
    c.t = c.r[4] == c.r[1];  // 0609F266 cmp/eq r1,r4
    if (c.t) { goto L_0609F26E; }  // 0609F268 bt 0x0609F26E
L_0609F26A:
    { const uint32_t x = c.r[11]; c.pr = 0x0609F26Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F26Eu) return; }  // 0609F26A jsr @r11 ; nop
L_0609F26E:
    c.r[4] = ld32(c.r[8] + 36);  // 0609F26E mov.l @(36,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F270 tst r4,r4
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0609F27C; } }  // 0609F272 bt/s 0x0609F27C ; mov r8,r0
    { const uint32_t x = c.r[11]; c.pr = 0x0609F27Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F27Au) return; }  // 0609F276 jsr @r11 ; nop
    c.r[0] = c.r[8];  // 0609F27A mov r8,r0
L_0609F27C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0609F27C mov.b @(r0,r12),r1
    c.r[0] = 0x7Fu;  // 0609F27E mov #127,r0
    c.r[1] &= c.r[0];  // 0609F280 and r0,r1
    c.r[0] = c.r[8];  // 0609F282 mov r8,r0
    st8(c.r[0] + c.r[12], c.r[1]);  // 0609F284 mov.b r1,@(r0,r12)
    c.r[1] = 0x0u;  // 0609F286 mov #0,r1
    st32(c.r[8] + 16, c.r[1]);  // 0609F288 mov.l r1,@(16,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0609F28A mov.l r1,@(8,r8)
    st32(c.r[8] + 4, c.r[1]);  // 0609F28C mov.l r1,@(4,r8)
L_0609F28E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F2C2u);  // 0609F28E mov.w 0x0609F2C2,r1
    c.r[10] += c.r[1];  // 0609F290 add r1,r10
    c.r[1] = ld32(0x0609F2D4u);  // 0609F292 mov.l 0x0609F2D4,r1
    c.r[1] = ld32(c.r[1]);  // 0609F294 mov.l @r1,r1
    c.r[9] += 1;  // 0609F296 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0609F298 cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_0609F240; }  // 0609F29A bf 0x0609F240
L_0609F29C:
    c.r[1] = ld32(0x0609F2D0u);  // 0609F29C mov.l 0x0609F2D0,r1
    c.r[4] = ld32(c.r[1]);  // 0609F29E mov.l @r1,r4
    c.r[1] = ld32(0x0609F2CCu);  // 0609F2A0 mov.l 0x0609F2CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F2A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F2A6u) return; }  // 0609F2A2 jsr @r1 ; nop
L_0609F2A6:
    c.r[1] = ld32(0x0609F2C4u);  // 0609F2A6 mov.l 0x0609F2C4,r1
    c.r[2] = 0x0u;  // 0609F2A8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609F2AA mov.l r2,@r1
    c.r[1] = ld32(0x0609F2D0u);  // 0609F2AC mov.l 0x0609F2D0,r1
    st32(c.r[1], c.r[2]);  // 0609F2AE mov.l r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F2B0 lds.l @r15+,pr
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609F2B2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609F2B4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609F2B6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F2B8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F2BA rts ; mov.l @r15+,r8
}

void f_0609F2DC(SH2Context& c) {
    ran[2572] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F2DC mov.l r8,@-r15
    c.r[1] = c.r[7];  // 0609F2DE mov r7,r1
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F2E0 tst r4,r4
    { const bool k = !c.t; c.r[8] = ld32(c.r[15] + 4); if (k) { goto L_0609F2EA; } }  // 0609F2E2 bf/s 0x0609F2EA ; mov.l @(4,r15),r8
    c.r[0] = 0xFFFFFFFFu; goto L_0609F35E;  // 0609F2E6 bra 0x0609F35E ; mov #-1,r0
L_0609F2EA:
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609F2EA tst r5,r5
    if (c.t) { goto L_0609F2F0; }  // 0609F2EC bt 0x0609F2F0
    st32(c.r[4] + 4, c.r[5]);  // 0609F2EE mov.l r5,@(4,r4)
L_0609F2F0:
    c.t = (c.r[6] & c.r[6]) == 0;  // 0609F2F0 tst r6,r6
    if (c.t) { goto L_0609F2F6; }  // 0609F2F2 bt 0x0609F2F6
    st32(c.r[4] + 16, c.r[6]);  // 0609F2F4 mov.l r6,@(16,r4)
L_0609F2F6:
    c.r[0] = c.r[1];  // 0609F2F6 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609F2F8 cmp/eq #-1,r0
    { const bool k = c.t; c.r[7] = c.r[4]; if (k) { goto L_0609F328; } }  // 0609F2FA bt/s 0x0609F328 ; mov r4,r7
    c.r[7] += 46;  // 0609F2FE add #46,r7
    c.r[3] = c.r[4];  // 0609F300 mov r4,r3
    c.r[3] += 38;  // 0609F302 add #38,r3
    c.r[2] = c.r[4];  // 0609F304 mov r4,r2
    c.r[2] += 24;  // 0609F306 add #24,r2
    st16(c.r[2], c.r[1]);  // 0609F308 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F30A mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F30C mov.w r1,@r7
    c.r[6] = c.r[4];  // 0609F30E mov r4,r6
    c.r[6] += 34;  // 0609F310 add #34,r6
    c.r[7] = c.r[4];  // 0609F312 mov r4,r7
    c.r[7] += 36;  // 0609F314 add #36,r7
    c.r[3] = c.r[4];  // 0609F316 mov r4,r3
    c.r[3] += 42;  // 0609F318 add #42,r3
    c.r[2] = c.r[4];  // 0609F31A mov r4,r2
    c.r[2] += 44;  // 0609F31C add #44,r2
    c.r[1] = 0x0u;  // 0609F31E mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609F320 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F322 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F324 mov.w r1,@r7
    st16(c.r[6], c.r[1]);  // 0609F326 mov.w r1,@r6
L_0609F328:
    c.r[0] = c.r[8];  // 0609F328 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609F32A cmp/eq #-1,r0
    { const bool k = c.t; c.r[7] = c.r[4]; if (k) { goto L_0609F35C; } }  // 0609F32C bt/s 0x0609F35C ; mov r4,r7
    c.r[7] += 48;  // 0609F330 add #48,r7
    c.r[3] = c.r[4];  // 0609F332 mov r4,r3
    c.r[3] += 40;  // 0609F334 add #40,r3
    c.r[2] = c.r[4];  // 0609F336 mov r4,r2
    c.r[2] += 26;  // 0609F338 add #26,r2
    c.r[1] = c.r[8];  // 0609F33A mov r8,r1
    st16(c.r[2], c.r[1]);  // 0609F33C mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F33E mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F340 mov.w r1,@r7
    c.r[6] = c.r[4];  // 0609F342 mov r4,r6
    c.r[6] += 34;  // 0609F344 add #34,r6
    c.r[7] = c.r[4];  // 0609F346 mov r4,r7
    c.r[7] += 36;  // 0609F348 add #36,r7
    c.r[3] = c.r[4];  // 0609F34A mov r4,r3
    c.r[3] += 42;  // 0609F34C add #42,r3
    c.r[2] = c.r[4];  // 0609F34E mov r4,r2
    c.r[2] += 44;  // 0609F350 add #44,r2
    c.r[1] = 0x0u;  // 0609F352 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609F354 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F356 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F358 mov.w r1,@r7
    st16(c.r[6], c.r[1]);  // 0609F35A mov.w r1,@r6
L_0609F35C:
    c.r[0] = 0x0u;  // 0609F35C mov #0,r0
L_0609F35E:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F35E rts ; mov.l @r15+,r8
}

void f_0609F374(SH2Context& c) {
    ran[2573] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F374 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F376 mov.l r9,@-r15
    c.r[8] = c.r[5];  // 0609F378 mov r5,r8
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0609F37A exts.w r6,r6
    c.r[1] = ld32(0x0609F44Cu);  // 0609F37C mov.l 0x0609F44C,r1
    c.r[5] = ld32(c.r[1]);  // 0609F37E mov.l @r1,r5
    c.r[1] = ld32(0x0609F450u);  // 0609F380 mov.l 0x0609F450,r1
    c.r[1] = ld32(c.r[1]);  // 0609F382 mov.l @r1,r1
    c.r[2] = 0x0u;  // 0609F384 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609F386 cmp/ge r1,r2
    { const bool k = c.t; c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_0609F3A2; } }  // 0609F388 bt/s 0x0609F3A2 ; exts.w r7,r9
    c.r[3] = c.r[5];  // 0609F38C mov r5,r3
    c.r[3] += 50;  // 0609F38E add #50,r3
L_0609F390:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609F390 mov.b @r3,r0
    c.r[0] &= 0x80u;  // 0609F392 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F394 tst r0,r0
    if (c.t) { goto L_0609F3A2; }  // 0609F396 bt 0x0609F3A2
    c.r[2] += 1;  // 0609F398 add #1,r2
    c.r[3] += 52;  // 0609F39A add #52,r3
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609F39C cmp/ge r1,r2
    { const bool k = !c.t; c.r[5] += 52; if (k) { SH2_POLL(c); goto L_0609F390; } }  // 0609F39E bf/s 0x0609F390 ; add #52,r5
L_0609F3A2:
    c.r[1] = ld32(0x0609F450u);  // 0609F3A2 mov.l 0x0609F450,r1
    c.r[1] = ld32(c.r[1]);  // 0609F3A4 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609F3A6 cmp/ge r1,r2
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_0609F3B0; } }  // 0609F3A8 bf/s 0x0609F3B0 ; mov r5,r1
    c.r[0] = 0x0u; goto L_0609F446;  // 0609F3AC bra 0x0609F446 ; mov #0,r0
L_0609F3B0:
    c.r[1] += 50;  // 0609F3B0 add #50,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609F3B2 mov.b @r1,r0
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609F3B4 tst r5,r5
    c.r[0] |= 0x80u;  // 0609F3B6 or #128,r0
    { const bool k = c.t; st8(c.r[1], c.r[0]); if (k) { goto L_0609F430; } }  // 0609F3B8 bt/s 0x0609F430 ; mov.b r0,@r1
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F3BC tst r4,r4
    if (c.t) { goto L_0609F3C2; }  // 0609F3BE bt 0x0609F3C2
    st32(c.r[5] + 4, c.r[4]);  // 0609F3C0 mov.l r4,@(4,r5)
L_0609F3C2:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609F3C2 tst r8,r8
    if (c.t) { goto L_0609F3C8; }  // 0609F3C4 bt 0x0609F3C8
    st32(c.r[5] + 16, c.r[8]);  // 0609F3C6 mov.l r8,@(16,r5)
L_0609F3C8:
    c.r[0] = c.r[6];  // 0609F3C8 mov r6,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609F3CA cmp/eq #-1,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0609F3FC; } }  // 0609F3CC bt/s 0x0609F3FC ; mov r5,r7
    c.r[7] += 46;  // 0609F3D0 add #46,r7
    c.r[3] = c.r[5];  // 0609F3D2 mov r5,r3
    c.r[3] += 38;  // 0609F3D4 add #38,r3
    c.r[2] = c.r[5];  // 0609F3D6 mov r5,r2
    c.r[2] += 24;  // 0609F3D8 add #24,r2
    c.r[1] = c.r[6];  // 0609F3DA mov r6,r1
    st16(c.r[2], c.r[1]);  // 0609F3DC mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F3DE mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F3E0 mov.w r1,@r7
    c.r[6] = c.r[5];  // 0609F3E2 mov r5,r6
    c.r[6] += 34;  // 0609F3E4 add #34,r6
    c.r[7] = c.r[5];  // 0609F3E6 mov r5,r7
    c.r[7] += 36;  // 0609F3E8 add #36,r7
    c.r[3] = c.r[5];  // 0609F3EA mov r5,r3
    c.r[3] += 42;  // 0609F3EC add #42,r3
    c.r[2] = c.r[5];  // 0609F3EE mov r5,r2
    c.r[2] += 44;  // 0609F3F0 add #44,r2
    c.r[1] = 0x0u;  // 0609F3F2 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609F3F4 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F3F6 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F3F8 mov.w r1,@r7
    st16(c.r[6], c.r[1]);  // 0609F3FA mov.w r1,@r6
L_0609F3FC:
    c.r[0] = c.r[9];  // 0609F3FC mov r9,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609F3FE cmp/eq #-1,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0609F430; } }  // 0609F400 bt/s 0x0609F430 ; mov r5,r7
    c.r[7] += 48;  // 0609F404 add #48,r7
    c.r[3] = c.r[5];  // 0609F406 mov r5,r3
    c.r[3] += 40;  // 0609F408 add #40,r3
    c.r[2] = c.r[5];  // 0609F40A mov r5,r2
    c.r[2] += 26;  // 0609F40C add #26,r2
    c.r[1] = c.r[9];  // 0609F40E mov r9,r1
    st16(c.r[2], c.r[1]);  // 0609F410 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F412 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F414 mov.w r1,@r7
    c.r[6] = c.r[5];  // 0609F416 mov r5,r6
    c.r[6] += 34;  // 0609F418 add #34,r6
    c.r[7] = c.r[5];  // 0609F41A mov r5,r7
    c.r[7] += 36;  // 0609F41C add #36,r7
    c.r[3] = c.r[5];  // 0609F41E mov r5,r3
    c.r[3] += 42;  // 0609F420 add #42,r3
    c.r[2] = c.r[5];  // 0609F422 mov r5,r2
    c.r[2] += 44;  // 0609F424 add #44,r2
    c.r[1] = 0x0u;  // 0609F426 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609F428 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F42A mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0609F42C mov.w r1,@r7
    st16(c.r[6], c.r[1]);  // 0609F42E mov.w r1,@r6
L_0609F430:
    c.r[3] = c.r[5];  // 0609F430 mov r5,r3
    c.r[3] += 28;  // 0609F432 add #28,r3
    c.r[2] = c.r[5];  // 0609F434 mov r5,r2
    c.r[2] += 30;  // 0609F436 add #30,r2
    c.r[1] = 0x0u;  // 0609F438 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609F43A mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F43C mov.w r1,@r3
    c.r[1] = 0x0u;  // 0609F43E mov #0,r1
    st32(c.r[5] + 8, c.r[1]);  // 0609F440 mov.l r1,@(8,r5)
    st32(c.r[5] + 20, c.r[1]);  // 0609F442 mov.l r1,@(20,r5)
    c.r[0] = c.r[5];  // 0609F444 mov r5,r0
L_0609F446:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F446 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F448 rts ; mov.l @r15+,r8
}

void f_0609F454(SH2Context& c) {
    ran[2574] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F454 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F456 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F458 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609F45A mov r4,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F5A8u);  // 0609F45C mov.w 0x0609F5A8,r1
    c.r[0] = c.r[8];  // 0609F45E mov r8,r0
    c.r[9] = 0x0u;  // 0609F460 mov #0,r9
    c.r[3] = c.r[8];  // 0609F462 mov r8,r3
    c.r[3] += 32;  // 0609F464 add #32,r3
    c.r[7] = c.r[8];  // 0609F466 mov r8,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0609F468 mov.b @(r0,r1),r2
    c.r[7] += 34;  // 0609F46A add #34,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F5AAu);  // 0609F46C mov.w 0x0609F5AA,r0
    c.r[2] |= c.r[0];  // 0609F46E or r0,r2
    c.r[0] = c.r[8];  // 0609F470 mov r8,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0609F472 mov.b r2,@(r0,r1)
    st32(c.r[8] + 24, c.r[9]);  // 0609F474 mov.l r9,@(24,r8)
    c.r[2] = c.r[8];  // 0609F476 mov r8,r2
    c.r[2] += 66;  // 0609F478 add #66,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F5ACu);  // 0609F47A mov.w 0x0609F5AC,r1
    st16(c.r[2], c.r[1]);  // 0609F47C mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F5AEu);  // 0609F47E mov.w 0x0609F5AE,r1
    c.r[2] = 0x0u;  // 0609F480 mov #0,r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 0609F482 mov.w r2,@(r0,r1)
    c.r[1] = c.r[8];  // 0609F484 mov r8,r1
    c.r[1] += 50;  // 0609F486 add #50,r1
    st16(c.r[1], c.r[2]);  // 0609F488 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0609F48A mov r8,r1
    c.r[1] += 52;  // 0609F48C add #52,r1
    st16(c.r[1], c.r[2]);  // 0609F48E mov.w r2,@r1
    c.r[1] = c.r[8];  // 0609F490 mov r8,r1
    c.r[1] += 72;  // 0609F492 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0609F494 mov.l @r1,r1
    c.r[2] = c.r[8];  // 0609F496 mov r8,r2
    st16(c.r[3], c.r[1]);  // 0609F498 mov.w r1,@r3
    c.r[1] = c.r[8];  // 0609F49A mov r8,r1
    c.r[1] += 76;  // 0609F49C add #76,r1
    c.r[1] = ld32(c.r[1]);  // 0609F49E mov.l @r1,r1
    c.r[2] += 56;  // 0609F4A0 add #56,r2
    st16(c.r[2], c.r[1]);  // 0609F4A2 mov.w r1,@r2
    st16(c.r[7], c.r[1]);  // 0609F4A4 mov.w r1,@r7
    st32(c.r[8] + 20, c.r[9]);  // 0609F4A6 mov.l r9,@(20,r8)
    st32(c.r[8] + 16, c.r[9]);  // 0609F4A8 mov.l r9,@(16,r8)
    c.r[1] = c.r[8];  // 0609F4AA mov r8,r1
    c.r[1] += 117;  // 0609F4AC add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609F4AE mov.b @r1,r1
    c.r[2] = 0x7u;  // 0609F4B0 mov #7,r2
    c.r[1] -= 9;  // 0609F4B2 add #-9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609F4B4 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0609F4B6 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609F530; } }  // 0609F4B8 bt/s 0x0609F530 ; mov r8,r1
    c.r[1] += 98;  // 0609F4BC add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F4BE mov.w @r1,r1
    c.r[0] = 0x1u;  // 0609F4C0 mov #1,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F4C2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F4C4 tst r1,r1
    c.r[1] = c.t;  // 0609F4C6 movt r1
    c.r[1] ^= c.r[0];  // 0609F4C8 xor r0,r1
    st32(c.r[8] + 28, c.r[1]);  // 0609F4CA mov.l r1,@(28,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0609F4CC mov.w @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609F4CE mov.w @r3,r2
    c.r[1] += 1;  // 0609F4D0 add #1,r1
    c.macl = c.r[2] * c.r[1];  // 0609F4D2 mul.l r1,r2
    c.r[0] = c.macl;  // 0609F4D4 sts macl,r0
    st32(c.r[8] + 12, c.r[0]);  // 0609F4D6 mov.l r0,@(12,r8)
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609F4D8 mov.w @r3,r2
    c.r[1] = c.r[2];  // 0609F4DA mov r2,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 0609F4DC rotl r1
    c.r[1] = c.t;  // 0609F4DE movt r1
    c.r[2] += c.r[1];  // 0609F4E0 add r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0609F4E2 shar r2
    st32(c.r[8] + 20, c.r[2]);  // 0609F4E4 mov.l r2,@(20,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0609F4E6 mov.w @r7,r1
    c.r[3] = c.r[1];  // 0609F4E8 mov r1,r3
    c.t = c.r[3] >> 31; c.r[3] = c.r[3] << 1 | c.t;  // 0609F4EA rotl r3
    c.r[3] = c.t;  // 0609F4EC movt r3
    c.r[1] += c.r[3];  // 0609F4EE add r3,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0609F4F0 shar r1
    c.r[1] += 1;  // 0609F4F2 add #1,r1
    c.macl = c.r[2] * c.r[1];  // 0609F4F4 mul.l r1,r2
    c.r[5] = 0x3u;  // 0609F4F6 mov #3,r5
    c.r[0] = c.macl;  // 0609F4F8 sts macl,r0
    st32(c.r[8] + 20, c.r[0]);  // 0609F4FA mov.l r0,@(20,r8)
    c.r[4] = c.macl;  // 0609F4FC sts macl,r4
    c.r[4] <<= 2;  // 0609F4FE shll2 r4
    c.r[1] = ld32(c.r[8] + 12);  // 0609F500 mov.l @(12,r8),r1
    c.r[0] = ld32(0x0609F5B4u);  // 0609F502 mov.l 0x0609F5B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609F508u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F508u) return; }  // 0609F504 jsr @r0 ; add r1,r4
    c.r[2] = c.r[0];  // 0609F508 mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609F50A tst r2,r2
    { const bool k = c.t; st32(c.r[8] + 16, c.r[2]); if (k) { goto L_0609F52C; } }  // 0609F50C bt/s 0x0609F52C ; mov.l r2,@(16,r8)
    c.r[0] = ld32(0x0609F5B8u);  // 0609F510 mov.l 0x0609F5B8,r0
    c.r[5] = 0x0u;  // 0609F512 mov #0,r5
    c.r[6] = ld32(c.r[8] + 20);  // 0609F514 mov.l @(20,r8),r6
    c.r[4] = c.r[2];  // 0609F516 mov r2,r4
    c.r[1] = ld32(c.r[8] + 12);  // 0609F518 mov.l @(12,r8),r1
    c.r[6] <<= 2;  // 0609F51A shll2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609F520u; c.r[6] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F520u) return; }  // 0609F51C jsr @r0 ; add r1,r6
    c.r[2] = ld32(c.r[8] + 20);  // 0609F520 mov.l @(20,r8),r2
    c.r[1] = ld32(c.r[8] + 16);  // 0609F522 mov.l @(16,r8),r1
    c.r[2] <<= 2;  // 0609F524 shll2 r2
    c.r[1] += c.r[2];  // 0609F526 add r2,r1
    st32(c.r[8] + 8, c.r[1]); goto L_0609F588;  // 0609F528 bra 0x0609F588 ; mov.l r1,@(8,r8)
L_0609F52C:
    st32(c.r[8] + 8, c.r[9]); goto L_0609F588;  // 0609F52C bra 0x0609F588 ; mov.l r9,@(8,r8)
L_0609F530:
    c.r[1] += 98;  // 0609F530 add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F532 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F534 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F536 tst r1,r1
    { const bool k = c.t; c.r[6] = 0x2u; if (k) { goto L_0609F556; } }  // 0609F538 bt/s 0x0609F556 ; mov #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0609F53C mov.w @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609F53E mov.w @r3,r2
    c.r[1] += 1;  // 0609F540 add #1,r1
    c.macl = c.r[2] * c.r[1];  // 0609F542 mul.l r1,r2
    c.r[1] = c.macl;  // 0609F544 sts macl,r1
    c.macl = c.r[1] * c.r[6];  // 0609F546 mul.l r6,r1
    c.r[0] = ld32(0x0609F5B4u);  // 0609F548 mov.l 0x0609F5B4,r0
    c.r[5] = 0x3u;  // 0609F54A mov #3,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609F550u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F550u) return; }  // 0609F54C jsr @r0 ; sts macl,r4
    st32(c.r[8] + 8, c.r[0]);  // 0609F550 mov.l r0,@(8,r8)
    c.r[1] = 0x1u; goto L_0609F582;  // 0609F552 bra 0x0609F582 ; mov #1,r1
L_0609F556:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609F556 mov.w @r3,r1
    c.macl = c.r[1] * c.r[6];  // 0609F558 mul.l r6,r1
    c.r[2] = c.macl;  // 0609F55A sts macl,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F5B0u);  // 0609F55C mov.w 0x0609F5B0,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609F55E cmp/gt r1,r2
    { const bool k = c.t; c.r[5] = 0x3u; if (k) { goto L_0609F56A; } }  // 0609F560 bt/s 0x0609F56A ; mov #3,r5
    c.r[1] = ld32(0x0609F5BCu);  // 0609F564 mov.l 0x0609F5BC,r1
    st32(c.r[8] + 8, c.r[1]); goto L_0609F572;  // 0609F566 bra 0x0609F572 ; mov.l r1,@(8,r8)
L_0609F56A:
    c.r[0] = ld32(0x0609F5B4u);  // 0609F56A mov.l 0x0609F5B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609F570u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F570u) return; }  // 0609F56C jsr @r0 ; sts macl,r4
    st32(c.r[8] + 8, c.r[0]);  // 0609F570 mov.l r0,@(8,r8)
L_0609F572:
    c.r[1] = c.r[8];  // 0609F572 mov r8,r1
    c.r[1] += 102;  // 0609F574 add #102,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F576 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F578 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F57A tst r1,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0609F582; } }  // 0609F57C bt/s 0x0609F582 ; mov #0,r1
    c.r[1] = 0x2u;  // 0609F580 mov #2,r1
L_0609F582:
    st32(c.r[8] + 28, c.r[1]);  // 0609F582 mov.l r1,@(28,r8)
    c.r[1] = ld32(c.r[8] + 8);  // 0609F584 mov.l @(8,r8),r1
    st32(c.r[8] + 16, c.r[1]);  // 0609F586 mov.l r1,@(16,r8)
L_0609F588:
    c.r[3] = c.r[8];  // 0609F588 mov r8,r3
    c.r[1] = c.r[8];  // 0609F58A mov r8,r1
    c.r[1] += 96;  // 0609F58C add #96,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F58E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F590 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F592 tst r1,r1
    { const bool k = c.t; c.r[3] += 54; if (k) { goto L_0609F5C0; } }  // 0609F594 bt/s 0x0609F5C0 ; add #54,r3
    c.r[1] = c.r[8];  // 0609F598 mov r8,r1
    c.r[1] += 72;  // 0609F59A add #72,r1
    c.r[2] = ld32(c.r[1]);  // 0609F59C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609F59E mov r2,r1
    c.r[1] += c.r[1];  // 0609F5A0 add r1,r1
    c.r[1] += c.r[2];  // 0609F5A2 add r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1; goto L_0609F5C6;  // 0609F5A4 bra 0x0609F5C6 ; shlr r1
L_0609F5C0:
    c.r[1] = c.r[8];  // 0609F5C0 mov r8,r1
    c.r[1] += 72;  // 0609F5C2 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0609F5C4 mov.l @r1,r1
L_0609F5C6:
    st16(c.r[3], c.r[1]);  // 0609F5C6 mov.w r1,@r3
    c.r[1] = ld32(c.r[8] + 8);  // 0609F5C8 mov.l @(8,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F5CA tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_0609F610; } }  // 0609F5CC bf/s 0x0609F610 ; mov r8,r0
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609F5D0 tst r8,r8
    if (c.t) { goto L_0609F60C; }  // 0609F5D2 bt 0x0609F60C
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609F61Cu);  // 0609F5D4 mov.w 0x0609F61C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0609F5D6 mov.b @(r0,r9),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F61Eu);  // 0609F5D8 mov.w 0x0609F61E,r0
    c.r[1] &= c.r[0];  // 0609F5DA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F5DC tst r1,r1
    if (c.t) { goto L_0609F60C; }  // 0609F5DE bt 0x0609F60C
    c.r[4] = ld32(c.r[8] + 16);  // 0609F5E0 mov.l @(16,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F5E2 tst r4,r4
    if (c.t) { goto L_0609F5EC; }  // 0609F5E4 bt 0x0609F5EC
    c.r[1] = ld32(0x0609F620u);  // 0609F5E6 mov.l 0x0609F620,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F5ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F5ECu) return; }  // 0609F5E8 jsr @r1 ; nop
L_0609F5EC:
    c.r[4] = ld32(c.r[8] + 36);  // 0609F5EC mov.l @(36,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F5EE tst r4,r4
    if (c.t) { goto L_0609F5F8; }  // 0609F5F0 bt 0x0609F5F8
    c.r[1] = ld32(0x0609F620u);  // 0609F5F2 mov.l 0x0609F620,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F5F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F5F8u) return; }  // 0609F5F4 jsr @r1 ; nop
L_0609F5F8:
    c.r[0] = c.r[8];  // 0609F5F8 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0609F5FA mov.b @(r0,r9),r1
    c.r[0] = 0x7Fu;  // 0609F5FC mov #127,r0
    c.r[1] &= c.r[0];  // 0609F5FE and r0,r1
    c.r[0] = c.r[8];  // 0609F600 mov r8,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 0609F602 mov.b r1,@(r0,r9)
    c.r[1] = 0x0u;  // 0609F604 mov #0,r1
    st32(c.r[8] + 16, c.r[1]);  // 0609F606 mov.l r1,@(16,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0609F608 mov.l r1,@(8,r8)
    st32(c.r[8] + 4, c.r[1]);  // 0609F60A mov.l r1,@(4,r8)
L_0609F60C:
    c.r[0] = 0x0u; goto L_0609F614;  // 0609F60C bra 0x0609F614 ; mov #0,r0
L_0609F610:
    c.r[1] = 0x0u;  // 0609F610 mov #0,r1
    st32(c.r[8] + 36, c.r[1]);  // 0609F612 mov.l r1,@(36,r8)
L_0609F614:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F614 lds.l @r15+,pr
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F616 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F618 rts ; mov.l @r15+,r8
}

void f_0609F624(SH2Context& c) {
    ran[2575] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F624 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F626 sts.l pr,@-r15
    c.r[1] = ld32(0x0609F6DCu);  // 0609F628 mov.l 0x0609F6DC,r1
    c.r[8] = ld32(c.r[1]);  // 0609F62A mov.l @r1,r8
    c.r[1] = ld32(0x0609F6E0u);  // 0609F62C mov.l 0x0609F6E0,r1
    c.r[1] = ld32(c.r[1]);  // 0609F62E mov.l @r1,r1
    c.r[2] = 0x0u;  // 0609F630 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609F632 cmp/ge r1,r2
    if (c.t) { goto L_0609F64E; }  // 0609F634 bt 0x0609F64E
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609F6D6u);  // 0609F636 mov.w 0x0609F6D6,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609F6D8u);  // 0609F638 mov.w 0x0609F6D8,r3
L_0609F63A:
    c.r[0] = c.r[8];  // 0609F63A mov r8,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0609F63C mov.b @(r0,r7),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F6DAu);  // 0609F63E mov.w 0x0609F6DA,r0
    c.r[6] &= c.r[0];  // 0609F640 and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0609F642 tst r6,r6
    if (c.t) { goto L_0609F64E; }  // 0609F644 bt 0x0609F64E
    c.r[2] += 1;  // 0609F646 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609F648 cmp/ge r1,r2
    { const bool k = !c.t; c.r[8] += c.r[3]; if (k) { SH2_POLL(c); goto L_0609F63A; } }  // 0609F64A bf/s 0x0609F63A ; add r3,r8
L_0609F64E:
    c.r[1] = ld32(0x0609F6E0u);  // 0609F64E mov.l 0x0609F6E0,r1
    c.r[1] = ld32(c.r[1]);  // 0609F650 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609F652 cmp/ge r1,r2
    { const bool k = !c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_0609F65C; } }  // 0609F654 bf/s 0x0609F65C ; tst r4,r4
L_0609F658:
    c.r[0] = 0x0u; goto L_0609F6D0;  // 0609F658 bra 0x0609F6D0 ; mov #0,r0
L_0609F65C:
    { const bool k = c.t; st32(c.r[8] + 4, c.r[4]); if (k) { goto L_0609F6C2; } }  // 0609F65C bt/s 0x0609F6C2 ; mov.l r4,@(4,r8)
    c.r[5] = c.r[8];  // 0609F660 mov r8,r5
    c.r[0] = ld32(0x0609F6E4u);  // 0609F662 mov.l 0x0609F6E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609F668u; c.r[5] += 68; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F668u) return; }  // 0609F664 jsr @r0 ; add #68,r5
    c.t = (int32_t)c.r[0] > 0;  // 0609F668 cmp/pl r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0609F6B8; } }  // 0609F66A bt/s 0x0609F6B8 ; tst r8,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609F6D0; } }  // 0609F66E bt/s 0x0609F6D0 ; mov #0,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F6D6u);  // 0609F672 mov.w 0x0609F6D6,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0609F674 mov.b @(r0,r8),r0
    c.r[0] &= 0x80u;  // 0609F676 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F678 tst r0,r0
    if (c.t) { SH2_POLL(c); goto L_0609F658; }  // 0609F67A bt 0x0609F658
    c.r[4] = ld32(c.r[8] + 16);  // 0609F67C mov.l @(16,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F67E tst r4,r4
    if (!c.t) { goto L_0609F68E; }  // 0609F680 bf 0x0609F68E
    c.r[4] = ld32(c.r[8] + 8);  // 0609F682 mov.l @(8,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F684 tst r4,r4
    if (c.t) { goto L_0609F694; }  // 0609F686 bt 0x0609F694
    c.r[1] = ld32(0x0609F6E8u);  // 0609F688 mov.l 0x0609F6E8,r1
    c.t = c.r[4] == c.r[1];  // 0609F68A cmp/eq r1,r4
    if (c.t) { goto L_0609F694; }  // 0609F68C bt 0x0609F694
L_0609F68E:
    c.r[1] = ld32(0x0609F6ECu);  // 0609F68E mov.l 0x0609F6EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F694u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F694u) return; }  // 0609F690 jsr @r1 ; nop
L_0609F694:
    c.r[4] = ld32(c.r[8] + 36);  // 0609F694 mov.l @(36,r8),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F696 tst r4,r4
    if (c.t) { goto L_0609F6A0; }  // 0609F698 bt 0x0609F6A0
    c.r[1] = ld32(0x0609F6ECu);  // 0609F69A mov.l 0x0609F6EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F6A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F6A0u) return; }  // 0609F69C jsr @r1 ; nop
L_0609F6A0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F6D6u);  // 0609F6A0 mov.w 0x0609F6D6,r1
    c.r[0] = c.r[8];  // 0609F6A2 mov r8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0609F6A4 mov.b @(r0,r1),r2
    c.r[0] = 0x7Fu;  // 0609F6A6 mov #127,r0
    c.r[2] &= c.r[0];  // 0609F6A8 and r0,r2
    c.r[0] = c.r[8];  // 0609F6AA mov r8,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0609F6AC mov.b r2,@(r0,r1)
    c.r[1] = 0x0u;  // 0609F6AE mov #0,r1
    st32(c.r[8] + 16, c.r[1]);  // 0609F6B0 mov.l r1,@(16,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0609F6B2 mov.l r1,@(8,r8)
    st32(c.r[8] + 4, c.r[1]); SH2_POLL(c); goto L_0609F658;  // 0609F6B4 bra 0x0609F658 ; mov.l r1,@(4,r8)
L_0609F6B8:
    c.r[0] = ld32(0x0609F6F0u);  // 0609F6B8 mov.l 0x0609F6F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609F6BEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F6BEu) return; }  // 0609F6BA jsr @r0 ; mov r8,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0609F6D2;  // 0609F6BE bra 0x0609F6D2 ; lds.l @r15+,pr
L_0609F6C2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F6D6u);  // 0609F6C2 mov.w 0x0609F6D6,r1
    c.r[0] = c.r[8];  // 0609F6C4 mov r8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0609F6C6 mov.b @(r0,r1),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F6DAu);  // 0609F6C8 mov.w 0x0609F6DA,r0
    c.r[2] |= c.r[0];  // 0609F6CA or r0,r2
    c.r[0] = c.r[8];  // 0609F6CC mov r8,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0609F6CE mov.b r2,@(r0,r1)
L_0609F6D0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F6D0 lds.l @r15+,pr
L_0609F6D2:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F6D2 rts ; mov.l @r15+,r8
}

void f_0609F6F4(SH2Context& c) {
    ran[2576] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F6F4 tst r4,r4
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0609F734; } }  // 0609F6F6 bt/s 0x0609F734 ; mov r5,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F738u);  // 0609F6FA mov.w 0x0609F738,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0609F6FC mov.b @(r0,r4),r0
    c.r[0] &= 0x80u;  // 0609F6FE and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F700 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0609F730; } }  // 0609F702 bt/s 0x0609F730 ; mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609F706 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0609F718; } }  // 0609F708 bt/s 0x0609F718 ; mov r4,r1
    c.r[1] += 50;  // 0609F70C add #50,r1
    c.r[2] = 0x0u;  // 0609F70E mov #0,r2
    st16(c.r[1], c.r[2]);  // 0609F710 mov.w r2,@r1
    c.r[1] = c.r[4];  // 0609F712 mov r4,r1
    c.r[1] += 52;  // 0609F714 add #52,r1
    st16(c.r[1], c.r[2]);  // 0609F716 mov.w r2,@r1
L_0609F718:
    c.r[2] = c.r[4];  // 0609F718 mov r4,r2
    c.r[2] += 50;  // 0609F71A add #50,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609F71C mov.w @r2,r1
    c.r[1] += c.r[6];  // 0609F71E add r6,r1
    st16(c.r[2], c.r[1]);  // 0609F720 mov.w r1,@r2
    c.r[2] = c.r[4];  // 0609F722 mov r4,r2
    c.r[2] += 52;  // 0609F724 add #52,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609F726 mov.w @r2,r1
    c.r[0] = 0x0u;  // 0609F728 mov #0,r0
    c.r[1] += c.r[7];  // 0609F72A add r7,r1
    { const uint32_t x = c.pr; st16(c.r[2], c.r[1]); c.pc = x; return; }  // 0609F72C rts ; mov.w r1,@r2
L_0609F730:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 0609F730 rts ; mov #-1,r0
L_0609F734:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFEu; c.pc = x; return; }  // 0609F734 rts ; mov #-2,r0
}

void f_0609F73C(SH2Context& c) {
    ran[2577] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F73C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F73E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609F740 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F742 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609F744 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609F746 tst r8,r8
    { const bool k = c.t; c.r[4] = c.r[5]; if (k) { goto L_0609F7D8; } }  // 0609F748 bt/s 0x0609F7D8 ; mov r5,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609F7E4u);  // 0609F74C mov.w 0x0609F7E4,r2
    c.r[0] = c.r[8];  // 0609F74E mov r8,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0609F750 mov.b @(r0,r2),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F7E6u);  // 0609F752 mov.w 0x0609F7E6,r1
    c.r[1] &= c.r[3];  // 0609F754 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F756 tst r1,r1
    { const bool k = c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_0609F77C; } }  // 0609F758 bt/s 0x0609F77C ; tst r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609F7E8u);  // 0609F75C mov.w 0x0609F7E8,r1
    c.r[1] &= c.r[3];  // 0609F75E and r3,r1
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[1]); if (k) { goto L_0609F768; } }  // 0609F760 bf/s 0x0609F768 ; mov.b r1,@(r0,r2)
    c.r[0] = 0xFFFFFFFDu; goto L_0609F7DA;  // 0609F764 bra 0x0609F7DA ; mov #-3,r0
L_0609F768:
    st32(c.r[8] + 4, c.r[4]);  // 0609F768 mov.l r4,@(4,r8)
    c.r[9] = c.r[8];  // 0609F76A mov r8,r9
    c.r[9] += 88;  // 0609F76C add #88,r9
    c.r[10] = ld32(c.r[9]);  // 0609F76E mov.l @r9,r10
    c.r[5] = c.r[8];  // 0609F770 mov r8,r5
    c.r[0] = ld32(0x0609F7ECu);  // 0609F772 mov.l 0x0609F7EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609F778u; c.r[5] += 68; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F778u) return; }  // 0609F774 jsr @r0 ; add #68,r5
    c.t = (int32_t)c.r[0] >= 0;  // 0609F778 cmp/pz r0
    if (c.t) { goto L_0609F780; }  // 0609F77A bt 0x0609F780
L_0609F77C:
    c.r[0] = 0xFFFFFFFFu; goto L_0609F7DA;  // 0609F77C bra 0x0609F7DA ; mov #-1,r0
L_0609F780:
    c.r[1] = ld32(c.r[9]);  // 0609F780 mov.l @r9,r1
    c.t = c.r[1] == c.r[10];  // 0609F782 cmp/eq r10,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609F796; } }  // 0609F784 bt/s 0x0609F796 ; mov r8,r1
    c.r[1] += 72;  // 0609F788 add #72,r1
    c.r[0] = ld32(0x0609F7F0u);  // 0609F78A mov.l 0x0609F7F0,r0
    c.r[6] = ld32(c.r[1]);  // 0609F78C mov.l @r1,r6
    c.r[5] = 0x0u;  // 0609F78E mov #0,r5
    c.r[4] = ld32(c.r[8] + 16);  // 0609F790 mov.l @(16,r8),r4
    { const uint32_t x = c.r[0]; c.pr = 0x0609F796u; c.r[6] += c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F796u) return; }  // 0609F792 jsr @r0 ; add r6,r6
L_0609F796:
    c.r[2] = c.r[8];  // 0609F796 mov r8,r2
    c.r[2] += 32;  // 0609F798 add #32,r2
    c.r[7] = c.r[8];  // 0609F79A mov r8,r7
    c.r[7] += 72;  // 0609F79C add #72,r7
    c.r[3] = c.r[8];  // 0609F79E mov r8,r3
    c.r[1] = ld32(c.r[7]);  // 0609F7A0 mov.l @r7,r1
    c.r[3] += 34;  // 0609F7A2 add #34,r3
    st16(c.r[2], c.r[1]);  // 0609F7A4 mov.w r1,@r2
    c.r[2] = c.r[8];  // 0609F7A6 mov r8,r2
    c.r[1] = c.r[8];  // 0609F7A8 mov r8,r1
    c.r[1] += 76;  // 0609F7AA add #76,r1
    c.r[1] = ld32(c.r[1]);  // 0609F7AC mov.l @r1,r1
    c.r[2] += 56;  // 0609F7AE add #56,r2
    st16(c.r[2], c.r[1]);  // 0609F7B0 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609F7B2 mov.w r1,@r3
    c.r[3] = c.r[8];  // 0609F7B4 mov r8,r3
    c.r[1] = c.r[8];  // 0609F7B6 mov r8,r1
    c.r[1] += 96;  // 0609F7B8 add #96,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F7BA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F7BC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F7BE tst r1,r1
    { const bool k = c.t; c.r[3] += 54; if (k) { goto L_0609F7D0; } }  // 0609F7C0 bt/s 0x0609F7D0 ; add #54,r3
    c.r[2] = ld32(c.r[7]);  // 0609F7C4 mov.l @r7,r2
    c.r[1] = c.r[2];  // 0609F7C6 mov r2,r1
    c.r[1] += c.r[1];  // 0609F7C8 add r1,r1
    c.r[1] += c.r[2];  // 0609F7CA add r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1; goto L_0609F7D2;  // 0609F7CC bra 0x0609F7D2 ; shlr r1
L_0609F7D0:
    c.r[1] = ld32(c.r[7]);  // 0609F7D0 mov.l @r7,r1
L_0609F7D2:
    st16(c.r[3], c.r[1]);  // 0609F7D2 mov.w r1,@r3
    c.r[0] = 0x0u; goto L_0609F7DA;  // 0609F7D4 bra 0x0609F7DA ; mov #0,r0
L_0609F7D8:
    c.r[0] = 0xFFFFFFFEu;  // 0609F7D8 mov #-2,r0
L_0609F7DA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F7DA lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609F7DC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F7DE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F7E0 rts ; mov.l @r15+,r8
}

void f_0609F7F4(SH2Context& c) {
    ran[2578] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F7F4 tst r4,r4
    if (c.t) { goto L_0609F812; }  // 0609F7F6 bt 0x0609F812
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F816u);  // 0609F7F8 mov.w 0x0609F816,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0609F7FA mov.b @(r0,r4),r0
    c.r[0] &= 0x80u;  // 0609F7FC and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F7FE tst r0,r0
    if (c.t) { goto L_0609F80E; }  // 0609F800 bt 0x0609F80E
    st32(c.r[4] + 24, c.r[5]);  // 0609F802 mov.l r5,@(24,r4)
    c.r[1] = c.r[4];  // 0609F804 mov r4,r1
    c.r[1] += 66;  // 0609F806 add #66,r1
    st16(c.r[1], c.r[6]);  // 0609F808 mov.w r6,@r1
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609F80A rts ; mov #0,r0
L_0609F80E:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 0609F80E rts ; mov #-1,r0
L_0609F812:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFEu; c.pc = x; return; }  // 0609F812 rts ; mov #-2,r0
}

void f_0609F818(SH2Context& c) {
    ran[2579] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F818 tst r4,r4
    { const bool k = c.t; c.r[2] = ld32(c.r[15]); if (k) { goto L_0609F870; } }  // 0609F81A bt/s 0x0609F870 ; mov.l @r15,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F874u);  // 0609F81E mov.w 0x0609F874,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0609F820 mov.b @(r0,r4),r0
    c.r[0] &= 0x80u;  // 0609F822 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F824 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0609F86C; } }  // 0609F826 bt/s 0x0609F86C ; mov r4,r1
    c.r[1] += 50;  // 0609F82A add #50,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F82C mov.w @r1,r1
    st32(c.r[5], c.r[1]);  // 0609F82E mov.l r1,@r5
    c.r[1] = c.r[4];  // 0609F830 mov r4,r1
    c.r[1] += 52;  // 0609F832 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F834 mov.w @r1,r1
    st32(c.r[6], c.r[1]);  // 0609F836 mov.l r1,@r6
    c.r[1] = c.r[4];  // 0609F838 mov r4,r1
    c.r[1] += 54;  // 0609F83A add #54,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F83C mov.w @r1,r1
    st32(c.r[7], c.r[1]);  // 0609F83E mov.l r1,@r7
    c.r[1] = c.r[4];  // 0609F840 mov r4,r1
    c.r[1] += 56;  // 0609F842 add #56,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F844 mov.w @r1,r1
    st32(c.r[2], c.r[1]);  // 0609F846 mov.l r1,@r2
    c.r[1] = c.r[4];  // 0609F848 mov r4,r1
    c.r[1] += 102;  // 0609F84A add #102,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F84C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F84E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F850 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0609F868; } }  // 0609F852 bt/s 0x0609F868 ; mov r4,r1
    c.r[1] += 122;  // 0609F856 add #122,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F858 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F85A extu.w r1,r1
    st32(c.r[7], c.r[1]);  // 0609F85C mov.l r1,@r7
    c.r[1] = c.r[4];  // 0609F85E mov r4,r1
    c.r[1] += 120;  // 0609F860 add #120,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F862 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F864 extu.w r1,r1
    st32(c.r[2], c.r[1]);  // 0609F866 mov.l r1,@r2
L_0609F868:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609F868 rts ; mov #0,r0
L_0609F86C:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 0609F86C rts ; mov #-1,r0
L_0609F870:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFEu; c.pc = x; return; }  // 0609F870 rts ; mov #-2,r0
}

void f_0609F8C8(SH2Context& c) {
    ran[2580] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F8C8 tst r4,r4
    if (c.t) { goto L_0609F8E8; }  // 0609F8CA bt 0x0609F8E8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F8ECu);  // 0609F8CC mov.w 0x0609F8EC,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0609F8CE mov.b @(r0,r4),r0
    c.r[0] &= 0x80u;  // 0609F8D0 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F8D2 tst r0,r0
    if (c.t) { goto L_0609F8E4; }  // 0609F8D4 bt 0x0609F8E4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609F8EEu);  // 0609F8D6 mov.w 0x0609F8EE,r0
    c.r[0] = ld32(c.r[0] + c.r[4]);  // 0609F8D8 mov.l @(r0,r4),r0
    c.t = c.r[0] == 0x3u;  // 0609F8DA cmp/eq #3,r0
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_0609F8F0; } }  // 0609F8DC bt/s 0x0609F8F0 ; mov #3,r0
    { const uint32_t x = c.pr; c.r[0] = 0x2u; c.pc = x; return; }  // 0609F8E0 rts ; mov #2,r0
L_0609F8E4:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 0609F8E4 rts ; mov #-1,r0
L_0609F8E8:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFEu; c.pc = x; return; }  // 0609F8E8 rts ; mov #-2,r0
L_0609F8F0:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609F8F0 rts ; nop
}

void f_0609F928(SH2Context& c) {
    ran[2581] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F928 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F92A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609F92C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609F92E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F930 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0609F932 mov r5,r9
    c.r[10] = ld32(0x0609F974u);  // 0609F934 mov.l 0x0609F974,r10
    c.r[1] = ld32(0x0609F978u);  // 0609F936 mov.l 0x0609F978,r1
    st32(c.r[1], c.r[4]);  // 0609F938 mov.l r4,@r1
    c.r[11] = ld32(0x0609F97Cu);  // 0609F93A mov.l 0x0609F97C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609F940u; c.r[5] = 0x54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F940u) return; }  // 0609F93C jsr @r11 ; mov #84,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F940 tst r0,r0
    { const bool k = c.t; st32(c.r[10], c.r[0]); if (k) { goto L_0609F966; } }  // 0609F942 bt/s 0x0609F966 ; mov.l r0,@r10
    c.r[8] = ld32(0x0609F980u);  // 0609F946 mov.l 0x0609F980,r8
    c.r[1] = ld32(0x0609F984u);  // 0609F948 mov.l 0x0609F984,r1
    st32(c.r[1], c.r[9]);  // 0609F94A mov.l r9,@r1
    c.r[5] = 0x20u;  // 0609F94C mov #32,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0609F952u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F952u) return; }  // 0609F94E jsr @r11 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609F952 tst r0,r0
    { const bool k = c.t; st32(c.r[8], c.r[0]); if (k) { goto L_0609F95C; } }  // 0609F954 bt/s 0x0609F95C ; mov.l r0,@r8
    c.r[0] = 0x0u; goto L_0609F968;  // 0609F958 bra 0x0609F968 ; mov #0,r0
L_0609F95C:
    c.r[1] = ld32(0x0609F988u);  // 0609F95C mov.l 0x0609F988,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F962u; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F962u) return; }  // 0609F95E jsr @r1 ; mov.l @r10,r4
    c.r[1] = 0x0u;  // 0609F962 mov #0,r1
    st32(c.r[10], c.r[1]);  // 0609F964 mov.l r1,@r10
L_0609F966:
    c.r[0] = 0xFFFFFFFFu;  // 0609F966 mov #-1,r0
L_0609F968:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F968 lds.l @r15+,pr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609F96A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609F96C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F96E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F970 rts ; mov.l @r15+,r8
}

void f_0609F98C(SH2Context& c) {
    ran[2582] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F98C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609F98E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F990 sts.l pr,@-r15
    c.r[9] = ld32(0x0609F9C0u);  // 0609F992 mov.l 0x0609F9C0,r9
    c.r[4] = ld32(c.r[9]);  // 0609F994 mov.l @r9,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F996 tst r4,r4
    if (c.t) { goto L_0609F9A0; }  // 0609F998 bt 0x0609F9A0
    c.r[1] = ld32(0x0609F9C4u);  // 0609F99A mov.l 0x0609F9C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F9A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F9A0u) return; }  // 0609F99C jsr @r1 ; nop
L_0609F9A0:
    c.r[8] = ld32(0x0609F9C8u);  // 0609F9A0 mov.l 0x0609F9C8,r8
    c.r[4] = ld32(c.r[8]);  // 0609F9A2 mov.l @r8,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609F9A4 tst r4,r4
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0609F9B2; } }  // 0609F9A6 bt/s 0x0609F9B2 ; mov #0,r1
    c.r[1] = ld32(0x0609F9C4u);  // 0609F9AA mov.l 0x0609F9C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609F9B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609F9B0u) return; }  // 0609F9AC jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0609F9B0 mov #0,r1
L_0609F9B2:
    st32(c.r[9], c.r[1]);  // 0609F9B2 mov.l r1,@r9
    st32(c.r[8], c.r[1]);  // 0609F9B4 mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609F9B6 lds.l @r15+,pr
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609F9B8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609F9BA rts ; mov.l @r15+,r8
}

void f_0609F9CC(SH2Context& c) {
    ran[2583] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609F9CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609F9CE sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0609F9D0 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609F9D2 tst r8,r8
    { const bool k = c.t; c.r[4] = c.r[6]; if (k) { goto L_0609FA18; } }  // 0609F9D4 bt/s 0x0609FA18 ; mov r6,r4
    c.r[1] = ld32(c.r[8] + 24);  // 0609F9D8 mov.l @(24,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609F9DA tst r1,r1
    if (c.t) { goto L_0609FA18; }  // 0609F9DC bt 0x0609FA18
    st32(c.r[8], c.r[5]);  // 0609F9DE mov.l r5,@r8
    st32(c.r[8] + 8, c.r[4]);  // 0609F9E0 mov.l r4,@(8,r8)
    c.r[1] = 0x1u;  // 0609F9E2 mov #1,r1
    st32(c.r[8] + 44, c.r[1]);  // 0609F9E4 mov.l r1,@(44,r8)
    c.r[1] = 0x0u;  // 0609F9E6 mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 0609F9E8 mov.l r1,@(4,r8)
    st32(c.r[8] + 48, c.r[1]);  // 0609F9EA mov.l r1,@(48,r8)
    c.r[1] = c.r[8];  // 0609F9EC mov r8,r1
    c.r[1] += 64;  // 0609F9EE add #64,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609F9F0 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609F9F2 extu.w r1,r1
    c.r[0] = c.r[1];  // 0609F9F4 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609F9F6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0609FA18; } }  // 0609F9F8 bf/s 0x0609FA18 ; mov r8,r2
    c.r[1] = c.r[8];  // 0609F9FC mov r8,r1
    c.r[1] += 78;  // 0609F9FE add #78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FA00 mov.w @r1,r1
    c.r[2] += 66;  // 0609FA02 add #66,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609FA04 mov.w @r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FA06 extu.w r1,r1
    c.r[1] >>= 2;  // 0609FA08 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0609FA0A shlr r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0609FA0C mulu.w r1,r2
    c.r[7] = ld32(0x0609FA20u);  // 0609FA0E mov.l 0x0609FA20,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609FA14u; c.r[5] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FA14u) return; }  // 0609FA10 jsr @r7 ; sts macl,r5
    c.r[7] = c.r[0];  // 0609FA14 mov r0,r7
    st32(c.r[8] + 32, c.r[7]);  // 0609FA16 mov.l r7,@(32,r8)
L_0609FA18:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609FA18 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609FA1A rts ; mov.l @r15+,r8
}

void f_0609FA24(SH2Context& c) {
    ran[2584] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609FA24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609FA26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609FA28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609FA2A sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0609FA2C mov r5,r9
    c.r[8] = c.r[6];  // 0609FA2E mov r6,r8
    c.r[1] = ld32(0x0609FB14u);  // 0609FA30 mov.l 0x0609FB14,r1
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609FA32 tst r4,r4
    { const bool k = c.t; c.r[10] = ld32(c.r[1]); if (k) { goto L_0609FA68; } }  // 0609FA34 bt/s 0x0609FA68 ; mov.l @r1,r10
    c.r[1] = c.r[4];  // 0609FA38 mov r4,r1
    c.r[1] += 2;  // 0609FA3A add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FA3C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FA3E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FA40 tst r1,r1
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0609FA68; } }  // 0609FA42 bt/s 0x0609FA68 ; mov #0,r2
    c.r[1] = ld32(0x0609FB18u);  // 0609FA46 mov.l 0x0609FB18,r1
    c.r[1] = ld32(c.r[1]);  // 0609FA48 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609FA4A cmp/ge r1,r2
    if (c.t) { goto L_0609FA5E; }  // 0609FA4C bt 0x0609FA5E
    c.r[3] = c.r[1];  // 0609FA4E mov r1,r3
L_0609FA50:
    c.r[1] = ld32(c.r[10] + 24);  // 0609FA50 mov.l @(24,r10),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FA52 tst r1,r1
    if (c.t) { goto L_0609FA5E; }  // 0609FA54 bt 0x0609FA5E
    c.r[2] += 1;  // 0609FA56 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 0609FA58 cmp/ge r3,r2
    { const bool k = !c.t; c.r[10] += 84; if (k) { SH2_POLL(c); goto L_0609FA50; } }  // 0609FA5A bf/s 0x0609FA50 ; add #84,r10
L_0609FA5E:
    c.r[1] = ld32(0x0609FB18u);  // 0609FA5E mov.l 0x0609FB18,r1
    c.r[1] = ld32(c.r[1]);  // 0609FA60 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609FA62 cmp/ge r1,r2
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_0609FA6C; } }  // 0609FA64 bf/s 0x0609FA6C ; mov r4,r2
L_0609FA68:
    c.r[0] = 0x0u; goto L_0609FB08;  // 0609FA68 bra 0x0609FB08 ; mov #0,r0
L_0609FA6C:
    c.r[2] += 2;  // 0609FA6C add #2,r2
    c.r[3] = c.r[4];  // 0609FA6E mov r4,r3
    c.r[3] += 18;  // 0609FA70 add #18,r3
    c.r[6] = c.r[10];  // 0609FA72 mov r10,r6
    c.r[6] += 64;  // 0609FA74 add #64,r6
    c.r[5] = c.r[10];  // 0609FA76 mov r10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609FA78 mov.w @r2,r1
    c.r[5] += 66;  // 0609FA7A add #66,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FA7C extu.w r1,r1
    st32(c.r[10] + 24, c.r[1]);  // 0609FA7E mov.l r1,@(24,r10)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609FA80 mov.w @r3,r1
    c.r[7] = c.r[10];  // 0609FA82 mov r10,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FA84 extu.w r1,r1
    st32(c.r[10] + 32, c.r[1]);  // 0609FA86 mov.l r1,@(32,r10)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0609FA88 mov.w @r4,r1
    c.r[7] += 78;  // 0609FA8A add #78,r7
    st16(c.r[6], c.r[1]);  // 0609FA8C mov.w r1,@r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609FA8E mov.w @r2,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 0609FA90 tst r10,r10
    st16(c.r[5], c.r[1]);  // 0609FA92 mov.w r1,@r5
    c.r[2] = c.r[10];  // 0609FA94 mov r10,r2
    c.r[1] = ld32(c.r[4] + 4);  // 0609FA96 mov.l @(4,r4),r1
    c.r[2] += 68;  // 0609FA98 add #68,r2
    st32(c.r[2], c.r[1]);  // 0609FA9A mov.l r1,@r2
    c.r[2] = c.r[10];  // 0609FA9C mov r10,r2
    c.r[1] = ld32(c.r[4] + 8);  // 0609FA9E mov.l @(8,r4),r1
    c.r[2] += 72;  // 0609FAA0 add #72,r2
    st32(c.r[2], c.r[1]);  // 0609FAA2 mov.l r1,@r2
    c.r[2] = c.r[10];  // 0609FAA4 mov r10,r2
    c.r[1] = c.r[4];  // 0609FAA6 mov r4,r1
    c.r[1] += 12;  // 0609FAA8 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FAAA mov.w @r1,r1
    c.r[2] += 76;  // 0609FAAC add #76,r2
    st16(c.r[2], c.r[1]);  // 0609FAAE mov.w r1,@r2
    c.r[1] = c.r[4];  // 0609FAB0 mov r4,r1
    c.r[1] += 14;  // 0609FAB2 add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FAB4 mov.w @r1,r1
    c.r[2] = c.r[10];  // 0609FAB6 mov r10,r2
    st16(c.r[7], c.r[1]);  // 0609FAB8 mov.w r1,@r7
    c.r[1] = c.r[4];  // 0609FABA mov r4,r1
    c.r[1] += 16;  // 0609FABC add #16,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FABE mov.w @r1,r1
    c.r[2] += 80;  // 0609FAC0 add #80,r2
    st16(c.r[2], c.r[1]);  // 0609FAC2 mov.w r1,@r2
    c.r[2] = c.r[10];  // 0609FAC4 mov r10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609FAC6 mov.w @r3,r1
    c.r[2] += 82;  // 0609FAC8 add #82,r2
    { const bool k = c.t; st16(c.r[2], c.r[1]); if (k) { goto L_0609FB06; } }  // 0609FACA bt/s 0x0609FB06 ; mov.w r1,@r2
    c.r[1] = ld32(c.r[10] + 24);  // 0609FACE mov.l @(24,r10),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FAD0 tst r1,r1
    if (c.t) { goto L_0609FB06; }  // 0609FAD2 bt 0x0609FB06
    st32(c.r[10], c.r[9]);  // 0609FAD4 mov.l r9,@r10
    st32(c.r[10] + 8, c.r[8]);  // 0609FAD6 mov.l r8,@(8,r10)
    c.r[1] = 0x1u;  // 0609FAD8 mov #1,r1
    st32(c.r[10] + 44, c.r[1]);  // 0609FADA mov.l r1,@(44,r10)
    c.r[1] = 0x0u;  // 0609FADC mov #0,r1
    st32(c.r[10] + 4, c.r[1]);  // 0609FADE mov.l r1,@(4,r10)
    st32(c.r[10] + 48, c.r[1]);  // 0609FAE0 mov.l r1,@(48,r10)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0609FAE2 mov.w @r6,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FAE4 extu.w r1,r1
    c.r[0] = c.r[1];  // 0609FAE6 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609FAE8 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_0609FB08; } }  // 0609FAEA bf/s 0x0609FB08 ; mov r10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0609FAEE mov.w @r7,r1
    c.r[4] = c.r[8];  // 0609FAF0 mov r8,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0609FAF2 mov.w @r5,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FAF4 extu.w r1,r1
    c.r[1] >>= 2;  // 0609FAF6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0609FAF8 shlr r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0609FAFA mulu.w r1,r2
    c.r[7] = ld32(0x0609FB1Cu);  // 0609FAFC mov.l 0x0609FB1C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609FB02u; c.r[5] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FB02u) return; }  // 0609FAFE jsr @r7 ; sts macl,r5
    c.r[7] = c.r[0];  // 0609FB02 mov r0,r7
    st32(c.r[10] + 32, c.r[7]);  // 0609FB04 mov.l r7,@(32,r10)
L_0609FB06:
    c.r[0] = c.r[10];  // 0609FB06 mov r10,r0
L_0609FB08:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609FB08 lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609FB0A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609FB0C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609FB0E rts ; mov.l @r15+,r8
}

void f_0609FB20(SH2Context& c) {
    ran[2585] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609FB20 tst r4,r4
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0609FB28; } }  // 0609FB22 bt/s 0x0609FB28 ; mov #0,r1
    st32(c.r[4] + 24, c.r[1]);  // 0609FB26 mov.l r1,@(24,r4)
L_0609FB28:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609FB28 rts ; nop
}

void f_0609FB2C(SH2Context& c) {
    ran[2586] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609FB2C mov.l r8,@-r15
    c.r[3] = ld32(c.r[15] + 4);  // 0609FB2E mov.l @(4,r15),r3
    c.r[2] = ld32(c.r[15] + 8);  // 0609FB30 mov.l @(8,r15),r2
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609FB32 tst r4,r4
    { const bool k = c.t; c.r[8] = ld32(c.r[15] + 12); if (k) { goto L_0609FB7C; } }  // 0609FB34 bt/s 0x0609FB7C ; mov.l @(12,r15),r8
    c.r[1] = ld32(c.r[4] + 24);  // 0609FB38 mov.l @(24,r4),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FB3A tst r1,r1
    { const bool k = c.t; c.t = (int32_t)c.r[2] > 0; if (k) { goto L_0609FB7C; } }  // 0609FB3C bt/s 0x0609FB7C ; cmp/pl r2
    if (c.t) { goto L_0609FB44; }  // 0609FB40 bt 0x0609FB44
    c.r[2] = c.r[1];  // 0609FB42 mov r1,r2
L_0609FB44:
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609FB44 tst r5,r5
    if (c.t) { goto L_0609FB4A; }  // 0609FB46 bt 0x0609FB4A
    st32(c.r[4], c.r[5]);  // 0609FB48 mov.l r5,@r4
L_0609FB4A:
    c.t = (c.r[6] & c.r[6]) == 0;  // 0609FB4A tst r6,r6
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0609FB58; } }  // 0609FB4C bf/s 0x0609FB58 ; mov r2,r0
    c.r[1] = ld32(c.r[4] + 24);  // 0609FB50 mov.l @(24,r4),r1
    c.t = c.r[2] == c.r[1];  // 0609FB52 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0609FB62; } }  // 0609FB54 bt/s 0x0609FB62 ; mov #0,r1
L_0609FB58:
    c.t = c.r[0] == 0x2u;  // 0609FB58 cmp/eq #2,r0
    if (c.t) { goto L_0609FB5E; }  // 0609FB5A bt 0x0609FB5E
    c.r[6] = ld32(c.r[4]);  // 0609FB5C mov.l @r4,r6
L_0609FB5E:
    st32(c.r[4] + 4, c.r[6]);  // 0609FB5E mov.l r6,@(4,r4)
    c.r[1] = 0x0u;  // 0609FB60 mov #0,r1
L_0609FB62:
    c.t = (int32_t)c.r[7] > 0;  // 0609FB62 cmp/pl r7
    { const bool k = !c.t; st32(c.r[4] + 12, c.r[1]); if (k) { goto L_0609FB6A; } }  // 0609FB64 bf/s 0x0609FB6A ; mov.l r1,@(12,r4)
    st32(c.r[4] + 8, c.r[7]);  // 0609FB68 mov.l r7,@(8,r4)
L_0609FB6A:
    c.t = (int32_t)c.r[3] > 0;  // 0609FB6A cmp/pl r3
    if (!c.t) { goto L_0609FB70; }  // 0609FB6C bf 0x0609FB70
    st32(c.r[4] + 16, c.r[3]);  // 0609FB6E mov.l r3,@(16,r4)
L_0609FB70:
    c.t = (int32_t)c.r[2] > 0;  // 0609FB70 cmp/pl r2
    if (!c.t) { goto L_0609FB76; }  // 0609FB72 bf 0x0609FB76
    st32(c.r[4] + 24, c.r[2]);  // 0609FB74 mov.l r2,@(24,r4)
L_0609FB76:
    c.t = (int32_t)c.r[8] > 0;  // 0609FB76 cmp/pl r8
    if (!c.t) { goto L_0609FB7C; }  // 0609FB78 bf 0x0609FB7C
    st32(c.r[4] + 28, c.r[8]);  // 0609FB7A mov.l r8,@(28,r4)
L_0609FB7C:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609FB7C rts ; mov.l @r15+,r8
}

void f_0609FB80(SH2Context& c) {
    ran[2587] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609FB80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609FB82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609FB84 mov.l r10,@-r15
    c.r[8] = c.r[7];  // 0609FB86 mov r7,r8
    c.r[7] = ld32(c.r[15] + 12);  // 0609FB88 mov.l @(12,r15),r7
    c.r[9] = ld32(c.r[15] + 16);  // 0609FB8A mov.l @(16,r15),r9
    c.r[1] = ld32(0x0609FC08u);  // 0609FB8C mov.l 0x0609FC08,r1
    c.t = (c.r[7] & c.r[7]) == 0;  // 0609FB8E tst r7,r7
    { const bool k = c.t; c.r[10] = ld32(c.r[1]); if (k) { goto L_0609FBB8; } }  // 0609FB90 bt/s 0x0609FBB8 ; mov.l @r1,r10
    c.r[1] = ld32(0x0609FC0Cu);  // 0609FB94 mov.l 0x0609FC0C,r1
    c.r[1] = ld32(c.r[1]);  // 0609FB96 mov.l @r1,r1
    c.r[2] = 0x0u;  // 0609FB98 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609FB9A cmp/ge r1,r2
    if (c.t) { goto L_0609FBAE; }  // 0609FB9C bt 0x0609FBAE
    c.r[3] = c.r[1];  // 0609FB9E mov r1,r3
L_0609FBA0:
    c.r[1] = ld32(c.r[10] + 24);  // 0609FBA0 mov.l @(24,r10),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FBA2 tst r1,r1
    if (c.t) { goto L_0609FBAE; }  // 0609FBA4 bt 0x0609FBAE
    c.r[2] += 1;  // 0609FBA6 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 0609FBA8 cmp/ge r3,r2
    { const bool k = !c.t; c.r[10] += 32; if (k) { SH2_POLL(c); goto L_0609FBA0; } }  // 0609FBAA bf/s 0x0609FBA0 ; add #32,r10
L_0609FBAE:
    c.r[1] = ld32(0x0609FC0Cu);  // 0609FBAE mov.l 0x0609FC0C,r1
    c.r[1] = ld32(c.r[1]);  // 0609FBB0 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609FBB2 cmp/ge r1,r2
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0609FBBC; } }  // 0609FBB4 bf/s 0x0609FBBC ; tst r10,r10
L_0609FBB8:
    c.r[0] = 0x0u; goto L_0609FC00;  // 0609FBB8 bra 0x0609FC00 ; mov #0,r0
L_0609FBBC:
    st32(c.r[10] + 24, c.r[7]);  // 0609FBBC mov.l r7,@(24,r10)
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_0609FBFE; } }  // 0609FBBE bt/s 0x0609FBFE ; mov r7,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609FBC2 tst r2,r2
    { const bool k = c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_0609FBFE; } }  // 0609FBC4 bt/s 0x0609FBFE ; tst r4,r4
    if (c.t) { goto L_0609FBCC; }  // 0609FBC8 bt 0x0609FBCC
    st32(c.r[10], c.r[4]);  // 0609FBCA mov.l r4,@r10
L_0609FBCC:
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609FBCC tst r5,r5
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0609FBDA; } }  // 0609FBCE bf/s 0x0609FBDA ; mov r2,r0
    c.r[1] = ld32(c.r[10] + 24);  // 0609FBD2 mov.l @(24,r10),r1
    c.t = c.r[2] == c.r[1];  // 0609FBD4 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0609FBE4; } }  // 0609FBD6 bt/s 0x0609FBE4 ; mov #0,r1
L_0609FBDA:
    c.t = c.r[0] == 0x2u;  // 0609FBDA cmp/eq #2,r0
    if (c.t) { goto L_0609FBE0; }  // 0609FBDC bt 0x0609FBE0
    c.r[5] = ld32(c.r[10]);  // 0609FBDE mov.l @r10,r5
L_0609FBE0:
    st32(c.r[10] + 4, c.r[5]);  // 0609FBE0 mov.l r5,@(4,r10)
    c.r[1] = 0x0u;  // 0609FBE2 mov #0,r1
L_0609FBE4:
    c.t = (int32_t)c.r[6] > 0;  // 0609FBE4 cmp/pl r6
    { const bool k = !c.t; st32(c.r[10] + 12, c.r[1]); if (k) { goto L_0609FBEC; } }  // 0609FBE6 bf/s 0x0609FBEC ; mov.l r1,@(12,r10)
    st32(c.r[10] + 8, c.r[6]);  // 0609FBEA mov.l r6,@(8,r10)
L_0609FBEC:
    c.t = (int32_t)c.r[8] > 0;  // 0609FBEC cmp/pl r8
    if (!c.t) { goto L_0609FBF2; }  // 0609FBEE bf 0x0609FBF2
    st32(c.r[10] + 16, c.r[8]);  // 0609FBF0 mov.l r8,@(16,r10)
L_0609FBF2:
    c.t = (int32_t)c.r[2] > 0;  // 0609FBF2 cmp/pl r2
    if (!c.t) { goto L_0609FBF8; }  // 0609FBF4 bf 0x0609FBF8
    st32(c.r[10] + 24, c.r[2]);  // 0609FBF6 mov.l r2,@(24,r10)
L_0609FBF8:
    c.t = (int32_t)c.r[9] > 0;  // 0609FBF8 cmp/pl r9
    if (!c.t) { goto L_0609FBFE; }  // 0609FBFA bf 0x0609FBFE
    st32(c.r[10] + 28, c.r[9]);  // 0609FBFC mov.l r9,@(28,r10)
L_0609FBFE:
    c.r[0] = c.r[10];  // 0609FBFE mov r10,r0
L_0609FC00:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609FC00 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609FC02 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609FC04 rts ; mov.l @r15+,r8
}

void f_0609FC10(SH2Context& c) {
    ran[2588] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609FC10 tst r4,r4
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0609FC18; } }  // 0609FC12 bt/s 0x0609FC18 ; mov #0,r1
    st32(c.r[4] + 24, c.r[1]);  // 0609FC16 mov.l r1,@(24,r4)
L_0609FC18:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609FC18 rts ; nop
}

void f_0609FC1C(SH2Context& c) {
    ran[2589] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609FC1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609FC1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609FC20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609FC22 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609FC24 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609FC26 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609FC28 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609FC2A sts.l pr,@-r15
    c.r[15] -= 16;  // 0609FC2C add #-16,r15
    c.r[8] = c.r[4];  // 0609FC2E mov r4,r8
    c.r[9] = c.r[5];  // 0609FC30 mov r5,r9
    c.r[14] = 0x0u;  // 0609FC32 mov #0,r14
    c.r[0] = 0x0u;  // 0609FC34 mov #0,r0
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609FC36 tst r8,r8
    { const bool k = c.t; st32(c.r[15] + 8, c.r[0]); if (k) { goto L_0609FCC8; } }  // 0609FC38 bt/s 0x0609FCC8 ; mov.l r0,@(8,r15)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609FCF8u);  // 0609FC3C mov.w 0x0609FCF8,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0609FC3E mov.b @(r0,r8),r0
    c.r[0] &= 0x80u;  // 0609FC40 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FC42 tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0609FC60; } }  // 0609FC44 bt/s 0x0609FC60 ; tst r9,r9
    { const bool k = c.t; c.r[10] = c.r[9]; if (k) { goto L_0609FC82; } }  // 0609FC48 bt/s 0x0609FC82 ; mov r9,r10
    c.r[10] += 24;  // 0609FC4C add #24,r10
    c.r[1] = c.r[9];  // 0609FC4E mov r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0609FC50 mov.w @r10,r0
    c.r[1] += 50;  // 0609FC52 add #50,r1
    st32(c.r[15] + 12, c.r[0]);  // 0609FC54 mov.l r0,@(12,r15)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609FC56 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609FCFAu);  // 0609FC58 mov.w 0x0609FCFA,r0
    c.r[1] &= c.r[0];  // 0609FC5A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FC5C tst r1,r1
    if (!c.t) { goto L_0609FC64; }  // 0609FC5E bf 0x0609FC64
L_0609FC60:
    c.r[0] = 0xFFFFFFFEu; goto L_060A005C;  // 0609FC60 bra 0x060A005C ; mov #-2,r0
L_0609FC64:
    c.r[11] = ld32(c.r[9] + 4);  // 0609FC64 mov.l @(4,r9),r11
    c.r[0] = ld32(0x0609FCFCu);  // 0609FC66 mov.l 0x0609FCFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609FC6Cu; c.r[12] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FC6Cu) return; }  // 0609FC68 jsr @r0 ; mov #0,r12
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FC6C tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0609FC8A; } }  // 0609FC6E bt/s 0x0609FC8A ; mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0609FC72 mov.w @r10,r1
    c.r[2] += 72;  // 0609FC74 add #72,r2
    c.r[2] = ld32(c.r[2]);  // 0609FC76 mov.l @r2,r2
    c.t = c.r[1] == c.r[2];  // 0609FC78 cmp/eq r2,r1
    if (!c.t) { goto L_0609FC8A; }  // 0609FC7A bf 0x0609FC8A
    c.r[12] = c.t;  // 0609FC7C movt r12
    c.r[2] = c.r[8]; goto L_0609FC8C;  // 0609FC7E bra 0x0609FC8C ; mov r8,r2
L_0609FC82:
    c.r[0] = 0x0u;  // 0609FC82 mov #0,r0
    st32(c.r[15] + 12, c.r[0]);  // 0609FC84 mov.l r0,@(12,r15)
    c.r[12] = 0x0u;  // 0609FC86 mov #0,r12
    c.r[11] = 0x0u;  // 0609FC88 mov #0,r11
L_0609FC8A:
    c.r[2] = c.r[8];  // 0609FC8A mov r8,r2
L_0609FC8C:
    c.r[2] += 112;  // 0609FC8C add #112,r2
    c.r[1] = 0x10u;  // 0609FC8E mov #16,r1
    st32(c.r[2], c.r[1]);  // 0609FC90 mov.l r1,@r2
    c.r[1] = c.r[8];  // 0609FC92 mov r8,r1
    c.r[1] += 117;  // 0609FC94 add #117,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609FC96 mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0609FC98 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FC9A tst r1,r1
    if (c.t) { goto L_0609FCA6; }  // 0609FC9C bt 0x0609FCA6
    c.r[1] = ld32(c.r[8] + 4);  // 0609FC9E mov.l @(4,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FCA0 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0609FCAA; } }  // 0609FCA2 bf/s 0x0609FCAA ; mov r2,r1
L_0609FCA6:
    c.r[0] = 0x1u; goto L_060A005C;  // 0609FCA6 bra 0x060A005C ; mov #1,r0
L_0609FCAA:
    c.r[1] -= 9;  // 0609FCAA add #-9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609FCAC extu.b r1,r1
    c.r[2] = 0x7u;  // 0609FCAE mov #7,r2
    c.t = c.r[2] >= c.r[1];  // 0609FCB0 cmp/hs r1,r2
    c.r[1] = c.t;  // 0609FCB2 movt r1
    c.r[0] = c.t;  // 0609FCB4 movt r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609FCB6 tst r9,r9
    { const bool k = c.t; st32(c.r[15] + 4, c.r[0]); if (k) { goto L_0609FCCC; } }  // 0609FCB8 bt/s 0x0609FCCC ; mov.l r0,@(4,r15)
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FCBC tst r1,r1
    if (c.t) { goto L_0609FCCC; }  // 0609FCBE bt 0x0609FCCC
    c.r[0] = ld32(c.r[9] + 16);  // 0609FCC0 mov.l @(16,r9),r0
    c.t = c.r[0] == 0x3u;  // 0609FCC2 cmp/eq #3,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[15] + 4); if (k) { goto L_0609FCCE; } }  // 0609FCC4 bt/s 0x0609FCCE ; mov.l @(4,r15),r0
L_0609FCC8:
    c.r[0] = 0xFFFFFFFFu; goto L_060A005C;  // 0609FCC8 bra 0x060A005C ; mov #-1,r0
L_0609FCCC:
    c.r[0] = ld32(c.r[15] + 4);  // 0609FCCC mov.l @(4,r15),r0
L_0609FCCE:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FCCE tst r0,r0
    { const bool k = c.t; c.r[6] = 0x2u; if (k) { goto L_0609FCD6; } }  // 0609FCD0 bt/s 0x0609FCD6 ; mov #2,r6
    c.r[6] = 0x4u;  // 0609FCD4 mov #4,r6
L_0609FCD6:
    c.r[1] = c.r[8];  // 0609FCD6 mov r8,r1
    c.r[1] += 102;  // 0609FCD8 add #102,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FCDA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FCDC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FCDE tst r1,r1
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0609FD78; } }  // 0609FCE0 bt/s 0x0609FD78 ; tst r9,r9
    if (!c.t) { goto L_0609FCEA; }  // 0609FCE4 bf 0x0609FCEA
    goto L_0609FFF6;  // 0609FCE6 bra 0x0609FFF6 ; nop
L_0609FCEA:
    c.r[1] = ld32(c.r[9] + 8);  // 0609FCEA mov.l @(8,r9),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FCEC tst r1,r1
    if (c.t) { goto L_0609FD00; }  // 0609FCEE bt 0x0609FD00
    st32(c.r[9] + 12, c.r[1]);  // 0609FCF0 mov.l r1,@(12,r9)
    c.r[1] = c.r[9];  // 0609FCF2 mov r9,r1
    c.r[1] += 32; goto L_0609FD06;  // 0609FCF4 bra 0x0609FD06 ; add #32,r1
L_0609FD00:
    st32(c.r[9] + 12, c.r[11]);  // 0609FD00 mov.l r11,@(12,r9)
    c.r[1] = c.r[9];  // 0609FD02 mov r9,r1
    c.r[1] += 24;  // 0609FD04 add #24,r1
L_0609FD06:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FD06 mov.w @r1,r1
    st32(c.r[15] + 8, c.r[1]);  // 0609FD08 mov.l r1,@(8,r15)
    c.r[7] = c.r[8];  // 0609FD0A mov r8,r7
    c.r[7] += 52;  // 0609FD0C add #52,r7
    c.r[1] = c.r[9];  // 0609FD0E mov r9,r1
    c.r[1] += 30;  // 0609FD10 add #30,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0609FD12 mov.w @r7,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609FE74u);  // 0609FD14 mov.w 0x0609FE74,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FD16 mov.w @r1,r1
    c.r[0] = c.r[8];  // 0609FD18 mov r8,r0
    c.r[2] += c.r[1];  // 0609FD1A add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 0609FD1C mov.w @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FD1E extu.w r1,r1
    c.r[0] = ld32(c.r[15] + 8);  // 0609FD20 mov.l @(8,r15),r0
    c.r[2] += c.r[1];  // 0609FD22 add r1,r2
    c.macl = c.r[2] * c.r[0];  // 0609FD24 mul.l r0,r2
    c.r[1] = c.r[8];  // 0609FD26 mov r8,r1
    c.r[1] += 50;  // 0609FD28 add #50,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FD2A mov.w @r1,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609FE76u);  // 0609FD2C mov.w 0x0609FE76,r4
    c.r[1] = c.r[9];  // 0609FD2E mov r9,r1
    c.r[1] += 28;  // 0609FD30 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FD32 mov.w @r1,r1
    c.r[0] = c.r[8];  // 0609FD34 mov r8,r0
    c.r[2] += c.r[1];  // 0609FD36 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0609FD38 mov.w @(r0,r4),r1
    c.r[3] = c.macl;  // 0609FD3A sts macl,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FD3C extu.w r1,r1
    c.r[2] += c.r[1];  // 0609FD3E add r1,r2
    c.r[3] += c.r[2];  // 0609FD40 add r2,r3
    c.macl = c.r[3] * c.r[6];  // 0609FD42 mul.l r6,r3
    c.r[1] = ld32(c.r[9] + 12);  // 0609FD44 mov.l @(12,r9),r1
    c.r[2] = c.macl;  // 0609FD46 sts macl,r2
    c.r[1] += c.r[2];  // 0609FD48 add r2,r1
    st32(c.r[9] + 12, c.r[1]);  // 0609FD4A mov.l r1,@(12,r9)
    c.r[1] = c.r[9];  // 0609FD4C mov r9,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 0609FD4E mov.w @(r0,r5),r3
    c.r[1] += 24;  // 0609FD50 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FD52 mov.w @r1,r1
    c.r[3] = c.r[3] & 0xFFFFu;  // 0609FD54 extu.w r3,r3
    c.macl = c.r[3] * c.r[1];  // 0609FD56 mul.l r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 0609FD58 mov.w @(r0,r4),r1
    c.r[2] = c.macl;  // 0609FD5A sts macl,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FD5C extu.w r1,r1
    c.r[2] += c.r[1];  // 0609FD5E add r1,r2
    c.macl = c.r[2] * c.r[6];  // 0609FD60 mul.l r6,r2
    c.r[1] = c.macl;  // 0609FD62 sts macl,r1
    c.r[11] += c.r[1];  // 0609FD64 add r1,r11
    c.r[2] = c.r[9];  // 0609FD66 mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0609FD68 mov.w @r7,r1
    c.r[2] += 26;  // 0609FD6A add #26,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609FD6C mov.w @r2,r2
    c.r[1] += c.r[3];  // 0609FD6E add r3,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0609FD70 cmp/gt r2,r1
    if (!c.t) { goto L_0609FD78; }  // 0609FD72 bf 0x0609FD78
    goto L_0609FFF6;  // 0609FD74 bra 0x0609FFF6 ; nop
L_0609FD78:
    c.r[1] = c.r[8];  // 0609FD78 mov r8,r1
    c.r[1] += 76;  // 0609FD7A add #76,r1
    c.t = (c.r[11] & c.r[11]) == 0;  // 0609FD7C tst r11,r11
    { const bool k = c.t; c.r[13] = ld32(c.r[1]); if (k) { goto L_0609FDB6; } }  // 0609FD7E bt/s 0x0609FDB6 ; mov.l @r1,r13
    c.r[1] = c.r[8];  // 0609FD82 mov r8,r1
    c.r[1] += 52;  // 0609FD84 add #52,r1
    c.r[2] = c.r[9];  // 0609FD86 mov r9,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FD88 mov.w @r1,r3
    c.r[2] += 24;  // 0609FD8A add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609FD8C mov.w @r2,r1
    c.r[2] = c.r[8];  // 0609FD8E mov r8,r2
    c.r[2] += 50;  // 0609FD90 add #50,r2
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[3] * (int16_t)c.r[1]);  // 0609FD92 muls.w r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609FD94 mov.w @r2,r2
    c.r[1] = c.macl;  // 0609FD96 sts macl,r1
    c.r[1] += c.r[2];  // 0609FD98 add r2,r1
    c.macl = c.r[1] * c.r[6];  // 0609FD9A mul.l r6,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0609FD9C exts.w r3,r3
    c.r[2] = c.r[13];  // 0609FD9E mov r13,r2
    c.r[1] = c.macl;  // 0609FDA0 sts macl,r1
    c.r[11] += c.r[1];  // 0609FDA2 add r1,r11
    c.r[1] = c.r[9];  // 0609FDA4 mov r9,r1
    c.r[1] += 26;  // 0609FDA6 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FDA8 mov.w @r1,r1
    c.r[2] += c.r[3];  // 0609FDAA add r3,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609FDAC cmp/gt r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[13] > 0; if (k) { goto L_0609FDB8; } }  // 0609FDAE bf/s 0x0609FDB8 ; cmp/pl r13
    c.r[13] = c.r[1];  // 0609FDB2 mov r1,r13
    c.r[13] -= c.r[3];  // 0609FDB4 sub r3,r13
L_0609FDB6:
    c.t = (int32_t)c.r[13] > 0;  // 0609FDB6 cmp/pl r13
L_0609FDB8:
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609FDC0; } }  // 0609FDB8 bt/s 0x0609FDC0 ; mov r8,r1
    goto L_0609FFF6;  // 0609FDBC bra 0x0609FFF6 ; nop
L_0609FDC0:
    c.r[1] += 106;  // 0609FDC0 add #106,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FDC2 mov.w @r1,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 0609FDC4 extu.w r1,r10
    c.r[1] = ld32(c.r[8] + 4);  // 0609FDC6 mov.l @(4,r8),r1
    c.r[2] = ld32(0x0609FE78u);  // 0609FDC8 mov.l 0x0609FE78,r2
    c.r[1] &= c.r[2];  // 0609FDCA and r2,r1
    c.r[10] += c.r[1];  // 0609FDCC add r1,r10
    st32(c.r[15], c.r[10]);  // 0609FDCE mov.l r10,@r15
    c.r[1] = ld32(c.r[8] + 8);  // 0609FDD0 mov.l @(8,r8),r1
    c.r[4] = c.r[1];  // 0609FDD2 mov r1,r4
    c.r[4] &= c.r[2];  // 0609FDD4 and r2,r4
    c.r[1] = ld32(c.r[8] + 16);  // 0609FDD6 mov.l @(16,r8),r1
    c.r[7] = c.r[1];  // 0609FDD8 mov r1,r7
    c.r[7] &= c.r[2];  // 0609FDDA and r2,r7
    c.r[1] = c.r[8];  // 0609FDDC mov r8,r1
    c.r[1] += 127;  // 0609FDDE add #127,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609FDE0 mov.b @r1,r1
    c.r[2] = c.t;  // 0609FDE2 movt r2
    c.r[1] = c.r[1] & 0xFFu;  // 0609FDE4 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0609FDE6 cmp/hi r2,r1
    { const bool k = c.t; c.r[3] = c.r[8]; if (k) { goto L_0609FE00; } }  // 0609FDE8 bt/s 0x0609FE00 ; mov r8,r3
    c.r[3] += 98;  // 0609FDEC add #98,r3
    c.r[2] = c.r[8];  // 0609FDEE mov r8,r2
    c.r[2] += 102;  // 0609FDF0 add #102,r2
    c.r[1] = 0x0u;  // 0609FDF2 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609FDF4 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0609FDF6 mov.w r1,@r3
    c.r[2] = c.r[8];  // 0609FDF8 mov r8,r2
    c.r[2] += 100;  // 0609FDFA add #100,r2
    c.r[1] = 0x1u;  // 0609FDFC mov #1,r1
    st16(c.r[2], c.r[1]);  // 0609FDFE mov.w r1,@r2
L_0609FE00:
    c.r[1] = c.r[8];  // 0609FE00 mov r8,r1
    c.r[1] += 98;  // 0609FE02 add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FE04 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FE06 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FE08 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0609FE18; } }  // 0609FE0A bf/s 0x0609FE18 ; tst r12,r12
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609FE0E tst r9,r9
    { const bool k = !c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0609FE18; } }  // 0609FE10 bf/s 0x0609FE18 ; tst r12,r12
    goto L_0609FFF6;  // 0609FE14 bra 0x0609FFF6 ; nop
L_0609FE18:
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0609FE2A; } }  // 0609FE18 bt/s 0x0609FE2A ; mov #0,r2
    c.r[1] = c.r[8];  // 0609FE1C mov r8,r1
    c.r[1] += 98;  // 0609FE1E add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FE20 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FE22 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FE24 tst r1,r1
    if (c.t) { goto L_0609FE2A; }  // 0609FE26 bt 0x0609FE2A
    c.r[2] = 0x1u;  // 0609FE28 mov #1,r2
L_0609FE2A:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609FE2A tst r9,r9
    { const bool k = !c.t; c.r[12] = c.r[2]; if (k) { goto L_0609FE32; } }  // 0609FE2C bf/s 0x0609FE32 ; mov r2,r12
    c.r[12] = c.t;  // 0609FE30 movt r12
L_0609FE32:
    c.r[1] = c.r[8];  // 0609FE32 mov r8,r1
    c.r[1] += 102;  // 0609FE34 add #102,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FE36 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FE38 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FE3A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609FE50; } }  // 0609FE3C bt/s 0x0609FE50 ; mov r8,r1
    c.r[1] += 98;  // 0609FE40 add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FE42 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FE44 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FE46 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0609FE50; } }  // 0609FE48 bf/s 0x0609FE50 ; mov r8,r1
    goto L_0609FFFA;  // 0609FE4C bra 0x0609FFFA ; nop
L_0609FE50:
    c.r[1] = c.r[8];  // 0609FE50 mov r8,r1
    c.r[1] += 100;  // 0609FE52 add #100,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FE54 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FE56 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FE58 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0609FEDC; } }  // 0609FE5A bf/s 0x0609FEDC ; mov r8,r1
    c.r[1] += 72;  // 0609FE5E add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0609FE60 mov.l @r1,r1
    c.r[1] >>= 2;  // 0609FE62 shlr2 r1
    c.r[1] += 7;  // 0609FE64 add #7,r1
    c.r[14] = c.r[1];  // 0609FE66 mov r1,r14
    c.r[14] >>= 2;  // 0609FE68 shlr2 r14
    c.t = c.r[14] & 1; c.r[14] >>= 1;  // 0609FE6A shlr r14
    c.r[1] = c.r[8];  // 0609FE6C mov r8,r1
    c.r[1] += 76;  // 0609FE6E add #76,r1
    c.r[1] = ld32(c.r[1]); goto L_0609FE7C;  // 0609FE70 bra 0x0609FE7C ; mov.l @r1,r1
L_0609FE7C:
    c.r[1] >>= 2;  // 0609FE7C shlr2 r1
    c.macl = c.r[14] * c.r[1];  // 0609FE7E mul.l r1,r14
    c.r[1] = c.macl;  // 0609FE80 sts macl,r1
    c.r[10] += c.r[1];  // 0609FE82 add r1,r10
    c.r[1] = c.r[8];  // 0609FE84 mov r8,r1
    c.r[1] += 88;  // 0609FE86 add #88,r1
    c.r[1] = ld32(c.r[1]);  // 0609FE88 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FE8A tst r1,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[15] + 4); if (k) { goto L_0609FEB6; } }  // 0609FE8C bf/s 0x0609FEB6 ; mov.l @(4,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FE90 tst r0,r0
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0609FE9E; } }  // 0609FE92 bt/s 0x0609FE9E ; tst r12,r12
    c.r[6] = ld32(0x060A0070u);  // 0609FE96 mov.l 0x060A0070,r6
    c.r[5] = ld32(0x060A0074u);  // 0609FE98 mov.l 0x060A0074,r5
    goto L_0609FF30;  // 0609FE9A bra 0x0609FF30 ; nop
L_0609FE9E:
    { const bool k = c.t; c.r[7] = 0x1u; if (k) { goto L_0609FEAC; } }  // 0609FE9E bt/s 0x0609FEAC ; mov #1,r7
    c.r[6] = ld32(0x060A0078u);  // 0609FEA2 mov.l 0x060A0078,r6
    c.r[5] = ld32(0x060A007Cu);  // 0609FEA4 mov.l 0x060A007C,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FEA6 mov.l 0x060A0080,r1
    goto L_0609FF6C;  // 0609FEA8 bra 0x0609FF6C ; nop
L_0609FEAC:
    c.r[6] = ld32(0x060A0084u);  // 0609FEAC mov.l 0x060A0084,r6
    c.r[5] = ld32(0x060A0088u);  // 0609FEAE mov.l 0x060A0088,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FEB0 mov.l 0x060A0080,r1
    c.r[7] = c.t; goto L_0609FF6C;  // 0609FEB2 bra 0x0609FF6C ; movt r7
L_0609FEB6:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FEB6 tst r0,r0
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0609FEC4; } }  // 0609FEB8 bt/s 0x0609FEC4 ; tst r12,r12
    c.r[6] = ld32(0x060A008Cu);  // 0609FEBC mov.l 0x060A008C,r6
    c.r[5] = ld32(0x060A0090u);  // 0609FEBE mov.l 0x060A0090,r5
    goto L_0609FF30;  // 0609FEC0 bra 0x0609FF30 ; nop
L_0609FEC4:
    { const bool k = c.t; c.r[7] = 0x1u; if (k) { goto L_0609FED2; } }  // 0609FEC4 bt/s 0x0609FED2 ; mov #1,r7
    c.r[6] = ld32(0x060A0094u);  // 0609FEC8 mov.l 0x060A0094,r6
    c.r[5] = ld32(0x060A0098u);  // 0609FECA mov.l 0x060A0098,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FECC mov.l 0x060A0080,r1
    goto L_0609FF6C;  // 0609FECE bra 0x0609FF6C ; nop
L_0609FED2:
    c.r[6] = ld32(0x060A009Cu);  // 0609FED2 mov.l 0x060A009C,r6
    c.r[5] = ld32(0x060A00A0u);  // 0609FED4 mov.l 0x060A00A0,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FED6 mov.l 0x060A0080,r1
    c.r[7] = c.t; goto L_0609FF6C;  // 0609FED8 bra 0x0609FF6C ; movt r7
L_0609FEDC:
    c.r[1] += 88;  // 0609FEDC add #88,r1
    c.r[1] = ld32(c.r[1]);  // 0609FEDE mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FEE0 tst r1,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[15] + 4); if (k) { goto L_0609FF26; } }  // 0609FEE2 bf/s 0x0609FF26 ; mov.l @(4,r15),r0
    c.r[1] = c.r[8];  // 0609FEE6 mov r8,r1
    c.r[1] += 96;  // 0609FEE8 add #96,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FEEA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FEEC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FEEE tst r1,r1
    if (c.t) { goto L_0609FEFE; }  // 0609FEF0 bt 0x0609FEFE
    c.r[7] = 0x0u;  // 0609FEF2 mov #0,r7
    c.r[6] = ld32(0x060A00A4u);  // 0609FEF4 mov.l 0x060A00A4,r6
    c.r[5] = ld32(0x060A00A8u);  // 0609FEF6 mov.l 0x060A00A8,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FEF8 mov.l 0x060A0080,r1
    goto L_0609FF6C;  // 0609FEFA bra 0x0609FF6C ; nop
L_0609FEFE:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FEFE tst r0,r0
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_0609FF0C; } }  // 0609FF00 bt/s 0x0609FF0C ; tst r12,r12
    c.r[6] = ld32(0x060A00ACu);  // 0609FF04 mov.l 0x060A00AC,r6
    c.r[5] = ld32(0x060A00B0u);  // 0609FF06 mov.l 0x060A00B0,r5
    goto L_0609FF30;  // 0609FF08 bra 0x0609FF30 ; nop
L_0609FF0C:
    { const bool k = c.t; c.r[7] = 0x1u; if (k) { goto L_0609FF1A; } }  // 0609FF0C bt/s 0x0609FF1A ; mov #1,r7
    c.r[6] = ld32(0x060A00B4u);  // 0609FF10 mov.l 0x060A00B4,r6
    c.r[5] = ld32(0x060A00B8u);  // 0609FF12 mov.l 0x060A00B8,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FF14 mov.l 0x060A0080,r1
    goto L_0609FF6C;  // 0609FF16 bra 0x0609FF6C ; nop
L_0609FF1A:
    c.r[1] = c.r[8];  // 0609FF1A mov r8,r1
    c.r[1] += 98;  // 0609FF1C add #98,r1
    c.r[6] = ld32(0x060A00BCu);  // 0609FF1E mov.l 0x060A00BC,r6
    c.r[5] = ld32(0x060A00C0u);  // 0609FF20 mov.l 0x060A00C0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0609FF60;  // 0609FF22 bra 0x0609FF60 ; mov.w @r1,r1
L_0609FF26:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FF26 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609FF40; } }  // 0609FF28 bt/s 0x0609FF40 ; mov r8,r1
    c.r[6] = ld32(0x060A00C4u);  // 0609FF2C mov.l 0x060A00C4,r6
    c.r[5] = ld32(0x060A00C8u);  // 0609FF2E mov.l 0x060A00C8,r5
L_0609FF30:
    c.r[1] = ld32(0x060A00CCu);  // 0609FF30 mov.l 0x060A00CC,r1
    c.r[1] += c.r[8];  // 0609FF32 add r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609FF34 mov.l r1,@-r15
    c.r[1] = ld32(0x060A00D0u);  // 0609FF36 mov.l 0x060A00D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609FF3Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FF3Cu) return; }  // 0609FF38 jsr @r1 ; nop
    c.r[15] += 4; goto L_0609FF70;  // 0609FF3C bra 0x0609FF70 ; add #4,r15
L_0609FF40:
    c.r[1] += 96;  // 0609FF40 add #96,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FF42 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FF44 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FF46 tst r1,r1
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0609FF56; } }  // 0609FF48 bt/s 0x0609FF56 ; mov #0,r7
    c.r[6] = ld32(0x060A00D4u);  // 0609FF4C mov.l 0x060A00D4,r6
    c.r[5] = ld32(0x060A00D8u);  // 0609FF4E mov.l 0x060A00D8,r5
    c.r[1] = ld32(0x060A0080u);  // 0609FF50 mov.l 0x060A0080,r1
    goto L_0609FF6C;  // 0609FF52 bra 0x0609FF6C ; nop
L_0609FF56:
    c.r[1] = c.r[8];  // 0609FF56 mov r8,r1
    c.r[1] += 98;  // 0609FF58 add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FF5A mov.w @r1,r1
    c.r[6] = ld32(0x060A00DCu);  // 0609FF5C mov.l 0x060A00DC,r6
    c.r[5] = ld32(0x060A00E0u);  // 0609FF5E mov.l 0x060A00E0,r5
L_0609FF60:
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FF60 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FF62 tst r1,r1
    c.r[0] = c.t;  // 0609FF64 movt r0
    c.r[0] ^= 0x1u;  // 0609FF66 xor #1,r0
    c.r[1] = ld32(0x060A0080u);  // 0609FF68 mov.l 0x060A0080,r1
    c.r[7] = c.r[0];  // 0609FF6A mov r0,r7
L_0609FF6C:
    { const uint32_t x = c.r[1]; c.pr = 0x0609FF70u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FF70u) return; }  // 0609FF6C jsr @r1 ; nop
L_0609FF70:
    c.r[1] = c.r[8];  // 0609FF70 mov r8,r1
    c.r[1] += 98;  // 0609FF72 add #98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609FF74 mov.w @r1,r1
    c.r[0] = 0x1u;  // 0609FF76 mov #1,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0609FF78 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609FF7A tst r1,r1
    c.r[1] = c.t;  // 0609FF7C movt r1
    c.r[1] ^= c.r[0];  // 0609FF7E xor r0,r1
    st32(c.r[8] + 28, c.r[1]);  // 0609FF80 mov.l r1,@(28,r8)
    c.r[0] = ld32(c.r[15] + 4);  // 0609FF82 mov.l @(4,r15),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609FF84 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0609FFB2; } }  // 0609FF86 bt/s 0x0609FFB2 ; mov r8,r1
    c.r[1] += 72;  // 0609FF8A add #72,r1
    c.r[7] = ld32(c.r[1]);  // 0609FF8C mov.l @r1,r7
    c.r[0] = ld32(c.r[15] + 12);  // 0609FF8E mov.l @(12,r15),r0
    c.r[5] = c.r[11];  // 0609FF90 mov r11,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609FF92 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609FF94 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609FF96 mov.l r14,@-r15
    c.r[1] = c.r[8];  // 0609FF98 mov r8,r1
    c.r[0] = ld32(c.r[15] + 12);  // 0609FF9A mov.l @(12,r15),r0
    c.r[1] += 84;  // 0609FF9C add #84,r1
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609FF9E mov.l r0,@-r15
    c.r[1] = ld32(c.r[1]);  // 0609FFA0 mov.l @r1,r1
    c.r[4] = c.r[10];  // 0609FFA2 mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609FFA4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609FFA6 mov.l r13,@-r15
    c.r[1] = ld32(0x060A00E4u);  // 0609FFA8 mov.l 0x060A00E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609FFAEu; c.r[6] = ld32(c.r[15] + 36); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FFAEu) return; }  // 0609FFAA jsr @r1 ; mov.l @(36,r15),r6
    c.r[15] += 24; goto L_0609FFF6;  // 0609FFAE bra 0x0609FFF6 ; add #24,r15
L_0609FFB2:
    c.r[9] = c.r[8];  // 0609FFB2 mov r8,r9
    c.r[9] += 72;  // 0609FFB4 add #72,r9
    c.r[7] = ld32(c.r[9]);  // 0609FFB6 mov.l @r9,r7
    c.r[0] = ld32(c.r[15] + 12);  // 0609FFB8 mov.l @(12,r15),r0
    c.r[1] += 84;  // 0609FFBA add #84,r1
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609FFBC mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609FFBE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609FFC0 mov.l r14,@-r15
    c.r[0] = ld32(c.r[15] + 12);  // 0609FFC2 mov.l @(12,r15),r0
    c.r[5] = c.r[11];  // 0609FFC4 mov r11,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609FFC6 mov.l r0,@-r15
    c.r[1] = ld32(c.r[1]);  // 0609FFC8 mov.l @r1,r1
    c.r[4] = c.r[10];  // 0609FFCA mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609FFCC mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609FFCE mov.l r13,@-r15
    c.r[1] = ld32(0x060A00E8u);  // 0609FFD0 mov.l 0x060A00E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609FFD6u; c.r[6] = ld32(c.r[15] + 36); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FFD6u) return; }  // 0609FFD2 jsr @r1 ; mov.l @(36,r15),r6
    c.t = (c.r[12] & c.r[12]) == 0;  // 0609FFD6 tst r12,r12
    { const bool k = c.t; c.r[15] += 24; if (k) { goto L_0609FFF6; } }  // 0609FFD8 bt/s 0x0609FFF6 ; add #24,r15
    c.t = (c.r[11] & c.r[11]) == 0;  // 0609FFDC tst r11,r11
    { const bool k = c.t; c.r[0] = ld32(c.r[15] + 12); if (k) { goto L_0609FFF6; } }  // 0609FFDE bt/s 0x0609FFF6 ; mov.l @(12,r15),r0
    c.macl = c.r[13] * c.r[0];  // 0609FFE2 mul.l r0,r13
    c.r[5] = ld32(c.r[9]);  // 0609FFE4 mov.l @r9,r5
    c.r[1] = ld32(c.r[8] + 8);  // 0609FFE6 mov.l @(8,r8),r1
    c.r[6] = c.macl;  // 0609FFE8 sts macl,r6
    c.r[6] += c.r[6];  // 0609FFEA add r6,r6
    c.r[5] += c.r[5];  // 0609FFEC add r5,r5
    c.r[5] += c.r[1];  // 0609FFEE add r1,r5
    c.r[1] = ld32(0x060A00ECu);  // 0609FFF0 mov.l 0x060A00EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609FFF6u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609FFF6u) return; }  // 0609FFF2 jsr @r1 ; mov r11,r4
L_0609FFF6:
    c.r[0] = 0x0u; goto L_060A005C;  // 0609FFF6 bra 0x060A005C ; mov #0,r0
L_0609FFFA:
    c.r[1] += 72;  // 0609FFFA add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0609FFFC mov.l @r1,r1
    c.r[1] >>= 2;  // 0609FFFE shlr2 r1
    c.r[1] += 3;  // 060A0000 add #3,r1
    c.r[14] = c.r[1];  // 060A0002 mov r1,r14
    c.r[14] >>= 2;  // 060A0004 shlr2 r14
    c.r[1] = c.r[8];  // 060A0006 mov r8,r1
    c.r[1] += 76;  // 060A0008 add #76,r1
    c.r[1] = ld32(c.r[1]);  // 060A000A mov.l @r1,r1
    c.r[0] = ld32(c.r[8] + 24);  // 060A000C mov.l @(24,r8),r0
    c.r[1] >>= 2;  // 060A000E shlr2 r1
    c.macl = c.r[14] * c.r[1];  // 060A0010 mul.l r1,r14
    c.t = c.r[0] == 0x1u;  // 060A0012 cmp/eq #1,r0
    c.r[1] = c.macl;  // 060A0014 sts macl,r1
    { const bool k = !c.t; c.r[10] += c.r[1]; if (k) { goto L_060A0022; } }  // 060A0016 bf/s 0x060A0022 ; add r1,r10
    c.r[6] = ld32(0x060A00F0u);  // 060A001A mov.l 0x060A00F0,r6
    c.r[5] = ld32(0x060A00F4u);  // 060A001C mov.l 0x060A00F4,r5
    goto L_060A0026;  // 060A001E bra 0x060A0026 ; nop
L_060A0022:
    c.r[6] = ld32(0x060A00F8u);  // 060A0022 mov.l 0x060A00F8,r6
    c.r[5] = ld32(0x060A00FCu);  // 060A0024 mov.l 0x060A00FC,r5
L_060A0026:
    c.r[1] = ld32(0x060A0080u);  // 060A0026 mov.l 0x060A0080,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060A002Cu; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A002Cu) return; }  // 060A0028 jsr @r1 ; mov #0,r7
    c.r[1] = 0x2u;  // 060A002C mov #2,r1
    st32(c.r[8] + 28, c.r[1]);  // 060A002E mov.l r1,@(28,r8)
    c.r[1] = c.r[8];  // 060A0030 mov r8,r1
    c.r[0] = ld32(c.r[15] + 8);  // 060A0032 mov.l @(8,r15),r0
    c.r[1] += 72;  // 060A0034 add #72,r1
    c.r[7] = ld32(c.r[1]);  // 060A0036 mov.l @r1,r7
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060A0038 mov.l r0,@-r15
    c.r[1] = ld32(c.r[9] + 12);  // 060A003A mov.l @(12,r9),r1
    c.r[5] = c.r[11];  // 060A003C mov r11,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060A003E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060A0040 mov.l r14,@-r15
    c.r[1] = c.r[8];  // 060A0042 mov r8,r1
    c.r[0] = ld32(c.r[15] + 12);  // 060A0044 mov.l @(12,r15),r0
    c.r[1] += 84;  // 060A0046 add #84,r1
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060A0048 mov.l r0,@-r15
    c.r[1] = ld32(c.r[1]);  // 060A004A mov.l @r1,r1
    c.r[4] = c.r[10];  // 060A004C mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060A004E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060A0050 mov.l r13,@-r15
    c.r[1] = ld32(0x060A00E8u);  // 060A0052 mov.l 0x060A00E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060A0058u; c.r[6] = ld32(c.r[15] + 36); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060A0058u) return; }  // 060A0054 jsr @r1 ; mov.l @(36,r15),r6
    c.r[0] = 0x0u;  // 060A0058 mov #0,r0
    c.r[15] += 24;  // 060A005A add #24,r15
L_060A005C:
    c.r[15] += 16;  // 060A005C add #16,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060A005E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060A0060 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060A0062 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060A0064 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060A0066 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060A0068 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060A006A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060A006C rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
