#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06092938(SH2Context& c) {
    ran[2195] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092938 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609293A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609293C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609293E rts ; mov #0,r0
}

void f_06092944(SH2Context& c) {
    ran[2196] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092944 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06092946 mov r15,r14
    c.r[1] = ld32(0x06092964u);  // 06092948 mov.l 0x06092964,r1
    c.r[2] = ld32(c.r[1]);  // 0609294A mov.l @r1,r2
    c.r[3] = c.r[2];  // 0609294C mov r2,r3
    c.r[3] += 4;  // 0609294E add #4,r3
    c.r[1] = ld32(0x06092968u);  // 06092950 mov.l 0x06092968,r1
    st32(c.r[2] + 4, c.r[1]);  // 06092952 mov.l r1,@(4,r2)
    c.r[1] = ld32(0x0609296Cu);  // 06092954 mov.l 0x0609296C,r1
    st32(c.r[3] + 4, c.r[1]);  // 06092956 mov.l r1,@(4,r3)
    c.r[1] = ld32(0x06092970u);  // 06092958 mov.l 0x06092970,r1
    st32(c.r[3] + 8, c.r[1]);  // 0609295A mov.l r1,@(8,r3)
    c.r[1] = ld32(0x06092974u);  // 0609295C mov.l 0x06092974,r1
    st32(c.r[3] + 12, c.r[1]);  // 0609295E mov.l r1,@(12,r3)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092960 rts ; mov.l @r15+,r14
}

void f_06092978(SH2Context& c) {
    ran[2197] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092978 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609297A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609297C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609297E sts.l pr,@-r15
    c.r[8] = ld32(0x06092A14u);  // 06092980 mov.l 0x06092A14,r8
    c.r[1] = ld32(c.r[8]);  // 06092982 mov.l @r8,r1
    c.r[9] = c.r[4];  // 06092984 mov r4,r9
    st32(c.r[1], c.r[9]);  // 06092986 mov.l r9,@r1
    c.r[1] = ld32(0x06092A18u);  // 06092988 mov.l 0x06092A18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609298Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609298Eu) return; }  // 0609298A jsr @r1 ; mov r15,r14
    c.r[2] = 0x0u;  // 0609298E mov #0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06092A00u);  // 06092990 mov.w 0x06092A00,r6
    c.r[3] = ld32(c.r[8]);  // 06092992 mov.l @r8,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06092A02u);  // 06092994 mov.w 0x06092A02,r7
    c.r[1] = c.r[3];  // 06092996 mov r3,r1
    c.r[1] += 52;  // 06092998 add #52,r1
    c.r[1] += 96;  // 0609299A add #96,r1
    st32(c.r[1], c.r[2]);  // 0609299C mov.l r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092A04u);  // 0609299E mov.w 0x06092A04,r1
    c.r[0] = c.r[3];  // 060929A0 mov r3,r0
    st32(c.r[0] + c.r[1], c.r[2]);  // 060929A2 mov.l r2,@(r0,r1)
    st32(c.r[0] + c.r[6], c.r[2]);  // 060929A4 mov.l r2,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092A06u);  // 060929A6 mov.w 0x06092A06,r1
    st32(c.r[0] + c.r[1], c.r[2]);  // 060929A8 mov.l r2,@(r0,r1)
    st32(c.r[0] + c.r[7], c.r[2]);  // 060929AA mov.l r2,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092A08u);  // 060929AC mov.w 0x06092A08,r1
    st32(c.r[0] + c.r[1], c.r[2]);  // 060929AE mov.l r2,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092A0Au);  // 060929B0 mov.w 0x06092A0A,r1
    st32(c.r[0] + c.r[1], c.r[2]);  // 060929B2 mov.l r2,@(r0,r1)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06092A0Cu);  // 060929B4 mov.w 0x06092A0C,r2
    c.r[1] = 0x0u;  // 060929B6 mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[9];  // 060929B8 cmp/ge r9,r1
    { const bool k = c.t; c.r[2] += c.r[3]; if (k) { goto L_060929CC; } }  // 060929BA bt/s 0x060929CC ; add r3,r2
    c.r[7] = 0x0u;  // 060929BE mov #0,r7
    c.r[3] = c.r[6];  // 060929C0 mov r6,r3
L_060929C2:
    st32(c.r[2], c.r[7]);  // 060929C2 mov.l r7,@r2
    c.r[1] += 1;  // 060929C4 add #1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[9];  // 060929C6 cmp/ge r9,r1
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { SH2_POLL(c); goto L_060929C2; } }  // 060929C8 bf/s 0x060929C2 ; add r3,r2
L_060929CC:
    c.r[1] = ld32(0x06092A14u);  // 060929CC mov.l 0x06092A14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06092A0Eu);  // 060929CE mov.w 0x06092A0E,r2
    c.r[3] = ld32(c.r[1]);  // 060929D0 mov.l @r1,r3
    c.r[15] = c.r[14];  // 060929D2 mov r14,r15
    c.r[7] = c.r[3];  // 060929D4 mov r3,r7
    c.r[7] += c.r[2];  // 060929D6 add r2,r7
    c.r[1] = 0x0u;  // 060929D8 mov #0,r1
    c.r[0] = c.r[3];  // 060929DA mov r3,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 060929DC mov.l r1,@(r0,r2)
    st32(c.r[7] + 12, c.r[1]);  // 060929DE mov.l r1,@(12,r7)
    st32(c.r[7] + 8, c.r[1]);  // 060929E0 mov.l r1,@(8,r7)
    st32(c.r[7] + 4, c.r[1]);  // 060929E2 mov.l r1,@(4,r7)
    st32(c.r[7] + 16, c.r[1]);  // 060929E4 mov.l r1,@(16,r7)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06092A10u);  // 060929E6 mov.w 0x06092A10,r2
    c.r[7] = c.r[3];  // 060929E8 mov r3,r7
    c.r[7] += c.r[2];  // 060929EA add r2,r7
    st32(c.r[0] + c.r[2], c.r[1]);  // 060929EC mov.l r1,@(r0,r2)
    st32(c.r[7] + 12, c.r[1]);  // 060929EE mov.l r1,@(12,r7)
    st32(c.r[7] + 8, c.r[1]);  // 060929F0 mov.l r1,@(8,r7)
    st32(c.r[7] + 4, c.r[1]);  // 060929F2 mov.l r1,@(4,r7)
    st32(c.r[7] + 16, c.r[1]);  // 060929F4 mov.l r1,@(16,r7)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060929F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060929F8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060929FA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060929FC rts ; mov.l @r15+,r8
}

void f_06092A1C(SH2Context& c) {
    ran[2198] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092A1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092A1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092A20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06092A22 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092A24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092A26 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 06092A28 mov r4,r9
    c.r[1] = ld32(c.r[9] + 4);  // 06092A2A mov.l @(4,r9),r1
    c.r[8] = 0x0u;  // 06092A2C mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06092A2E cmp/ge r1,r8
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06092A5C; } }  // 06092A30 bt/s 0x06092A5C ; mov r15,r14
    c.r[11] = ld32(0x06092A78u);  // 06092A34 mov.l 0x06092A78,r11
    c.r[10] = ld32(0x06092A7Cu);  // 06092A36 mov.l 0x06092A7C,r10
L_06092A38:
    c.r[1] = ld32(c.r[9]);  // 06092A38 mov.l @r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092A3A tst r1,r1
    { const bool k = !c.t; c.r[5] = ld32(c.r[9] + 8); if (k) { goto L_06092A48; } }  // 06092A3C bf/s 0x06092A48 ; mov.l @(8,r9),r5
    { const uint32_t x = c.r[11]; c.pr = 0x06092A44u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092A44u) return; }  // 06092A40 jsr @r11 ; mov r8,r4
    c.r[0] &= 0x1u; goto L_06092A4E;  // 06092A44 bra 0x06092A4E ; and #1,r0
L_06092A48:
    { const uint32_t x = c.r[10]; c.pr = 0x06092A4Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092A4Cu) return; }  // 06092A48 jsr @r10 ; mov r8,r4
    c.r[0] &= 0x1u;  // 06092A4C and #1,r0
L_06092A4E:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092A4E tst r0,r0
    if (!c.t) { goto L_06092A5A; }  // 06092A50 bf 0x06092A5A
    c.r[1] = ld32(c.r[9] + 4);  // 06092A52 mov.l @(4,r9),r1
    c.r[8] += 1;  // 06092A54 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06092A56 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06092A38; }  // 06092A58 bf 0x06092A38
L_06092A5A:
    c.r[1] = ld32(c.r[9] + 4);  // 06092A5A mov.l @(4,r9),r1
L_06092A5C:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06092A5C cmp/gt r1,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06092A66; } }  // 06092A5E bt/s 0x06092A66 ; mov #0,r0
    c.r[8] += 1;  // 06092A62 add #1,r8
    c.r[0] = c.r[8];  // 06092A64 mov r8,r0
L_06092A66:
    c.r[15] = c.r[14];  // 06092A66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092A68 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092A6A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06092A6C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092A6E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092A70 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092A72 rts ; mov.l @r15+,r8
}

void f_06092A80(SH2Context& c) {
    ran[2199] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092A80 mov.l r14,@-r15
    c.r[1] = ld32(0x06092AC4u);  // 06092A82 mov.l 0x06092AC4,r1
    c.r[1] = ld32(c.r[1]);  // 06092A84 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092AC0u);  // 06092A86 mov.w 0x06092AC0,r0
    c.r[0] += c.r[1];  // 06092A88 add r1,r0
    c.r[1] = ld32(c.r[1]);  // 06092A8A mov.l @r1,r1
    c.r[2] = 0x0u;  // 06092A8C mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06092A8E cmp/ge r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06092AA6; } }  // 06092A90 bt/s 0x06092AA6 ; mov r15,r14
    c.r[7] = (uint32_t)(int16_t)ld16(0x06092AC2u);  // 06092A94 mov.w 0x06092AC2,r7
    c.r[3] = c.r[1];  // 06092A96 mov r1,r3
L_06092A98:
    c.r[1] = ld32(c.r[0]);  // 06092A98 mov.l @r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092A9A tst r1,r1
    if (c.t) { goto L_06092AA6; }  // 06092A9C bt 0x06092AA6
    c.r[2] += 1;  // 06092A9E add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06092AA0 cmp/ge r3,r2
    { const bool k = !c.t; c.r[0] += c.r[7]; if (k) { SH2_POLL(c); goto L_06092A98; } }  // 06092AA2 bf/s 0x06092A98 ; add r7,r0
L_06092AA6:
    c.r[1] = ld32(0x06092AC4u);  // 06092AA6 mov.l 0x06092AC4,r1
    c.r[1] = ld32(c.r[1]);  // 06092AA8 mov.l @r1,r1
    c.r[1] = ld32(c.r[1]);  // 06092AAA mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 06092AAC cmp/eq r1,r2
    if (!c.t) { goto L_06092AB6; }  // 06092AAE bf 0x06092AB6
    c.r[0] = 0x0u;  // 06092AB0 mov #0,r0
    c.r[15] = c.r[14]; goto L_06092ABC;  // 06092AB2 bra 0x06092ABC ; mov r14,r15
L_06092AB6:
    c.r[1] = 0x1u;  // 06092AB6 mov #1,r1
    st32(c.r[0], c.r[1]);  // 06092AB8 mov.l r1,@r0
    c.r[15] = c.r[14];  // 06092ABA mov r14,r15
L_06092ABC:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092ABC rts ; mov.l @r15+,r14
}

void f_06092AC8(SH2Context& c) {
    ran[2200] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092AC8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06092ACA mov r15,r14
    c.r[1] = 0x0u;  // 06092ACC mov #0,r1
    st32(c.r[4], c.r[1]);  // 06092ACE mov.l r1,@r4
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092AD0 rts ; mov.l @r15+,r14
}

void f_06092AD4(SH2Context& c) {
    ran[2201] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092AD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092AD6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092AD8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06092ADA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092ADC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092ADE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06092AE0 mov r15,r14
    c.r[9] = c.r[4];  // 06092AE2 mov r4,r9
    c.r[10] = c.r[5];  // 06092AE4 mov r5,r10
    c.r[11] = c.r[9];  // 06092AE6 mov r9,r11
    c.r[8] = ld32(0x06092B48u);  // 06092AE8 mov.l 0x06092B48,r8
    c.r[2] = ld32(c.r[8]);  // 06092AEA mov.l @r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092B42u);  // 06092AEC mov.w 0x06092B42,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06092AEE mov.l @(r0,r2),r1
    c.t = c.r[1] == c.r[9];  // 06092AF0 cmp/eq r9,r1
    { const bool k = !c.t; c.r[11] += 12; if (k) { goto L_06092B00; } }  // 06092AF2 bf/s 0x06092B00 ; add #12,r11
    c.r[1] = 0x0u;  // 06092AF6 mov #0,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06092AF8 mov.l r1,@(r0,r2)
    c.r[1] = ld32(0x06092B4Cu);  // 06092AFA mov.l 0x06092B4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092B00u; c.r[5] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092B00u) return; }  // 06092AFC jsr @r1 ; mov #-1,r5
L_06092B00:
    c.r[1] = ld32(c.r[8]);  // 06092B00 mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092B44u);  // 06092B02 mov.w 0x06092B44,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06092B04 mov.l @(r0,r1),r2
    c.t = c.r[2] == c.r[9];  // 06092B06 cmp/eq r9,r2
    { const bool k = c.t; c.r[3] = ld32(c.r[9] + 40); if (k) { goto L_06092B14; } }  // 06092B08 bt/s 0x06092B14 ; mov.l @(40,r9),r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06092B0C tst r3,r3
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06092B32; } }  // 06092B0E bt/s 0x06092B32 ; tst r2,r2
    if (!c.t) { goto L_06092B32; }  // 06092B12 bf 0x06092B32
L_06092B14:
    c.r[8] = 0x0u;  // 06092B14 mov #0,r8
    st32(c.r[0] + c.r[1], c.r[8]);  // 06092B16 mov.l r8,@(r0,r1)
    c.r[3] <<= 2;  // 06092B18 shll2 r3
    c.r[3] <<= 2;  // 06092B1A shll2 r3
    c.r[3] += 4;  // 06092B1C add #4,r3
    c.r[1] += c.r[3];  // 06092B1E add r3,r1
    c.r[1] = ld32(c.r[1] + 4);  // 06092B20 mov.l @(4,r1),r1
    c.r[5] = c.r[10];  // 06092B22 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06092B28u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092B28u) return; }  // 06092B24 jsr @r1 ; mov r11,r4
    c.r[1] = c.r[9];  // 06092B28 mov r9,r1
    c.r[1] += 92;  // 06092B2A add #92,r1
    st32(c.r[1], c.r[8]);  // 06092B2C mov.l r8,@r1
    c.r[9] += 100;  // 06092B2E add #100,r9
    st32(c.r[9], c.r[8]);  // 06092B30 mov.l r8,@r9
L_06092B32:
    c.r[15] = c.r[14];  // 06092B32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092B34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092B36 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06092B38 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092B3A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092B3C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092B3E rts ; mov.l @r15+,r8
}

void f_06092B50(SH2Context& c) {
    ran[2202] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092B50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092B52 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092B54 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06092B56 mov r15,r14
    c.r[1] = ld32(0x06092BCCu);  // 06092B58 mov.l 0x06092BCC,r1
    c.r[2] = ld32(c.r[1]);  // 06092B5A mov.l @r1,r2
    c.r[1] = 0x10u;  // 06092B5C mov #16,r1
    c.r[2] += 16;  // 06092B5E add #16,r2
    c.t = c.r[2] > c.r[1];  // 06092B60 cmp/hi r1,r2
    { const bool k = c.t; c.r[8] = c.r[4]; if (k) { goto L_06092BA0; } }  // 06092B62 bt/s 0x06092BA0 ; mov r4,r8
    c.r[1] = c.r[2];  // 06092B66 mov r2,r1
    c.r[1] += c.r[1];  // 06092B68 add r1,r1
    c.r[0] = 0x06092B74u;  // 06092B6A mova 0x06092B74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06092B6C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06092B6E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06092B9Eu: goto L_06092B9E; case 0x06092BA0u: goto L_06092BA0; case 0x06092B9Au: goto L_06092B9A; case 0x06092B96u: goto L_06092B96; default: sh2_call(c, x); return; } }  // 06092B70 jmp @r0 ; nop
L_06092B96:
    c.r[8] = 0xFFFFFFE9u; goto L_06092BA0;  // 06092B96 bra 0x06092BA0 ; mov #-23,r8
L_06092B9A:
    c.r[8] = 0xFFFFFFFEu; goto L_06092BA0;  // 06092B9A bra 0x06092BA0 ; mov #-2,r8
L_06092B9E:
    c.r[8] = 0xFFFFFFE7u;  // 06092B9E mov #-25,r8
L_06092BA0:
    c.r[1] = ld32(0x06092BD0u);  // 06092BA0 mov.l 0x06092BD0,r1
    c.r[1] = ld32(c.r[1]);  // 06092BA2 mov.l @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06092BCAu);  // 06092BA4 mov.w 0x06092BCA,r3
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092BA6 tst r8,r8
    c.r[2] = c.r[1];  // 06092BA8 mov r1,r2
    c.r[2] += c.r[3];  // 06092BAA add r3,r2
    { const bool k = c.t; st32(c.r[2] + 8, c.r[8]); if (k) { goto L_06092BBE; } }  // 06092BAC bt/s 0x06092BBE ; mov.l r8,@(8,r2)
    c.r[0] = c.r[1];  // 06092BB0 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06092BB2 mov.l @(r0,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092BB4 tst r1,r1
    if (c.t) { goto L_06092BBE; }  // 06092BB6 bt 0x06092BBE
    c.r[4] = ld32(c.r[2] + 4);  // 06092BB8 mov.l @(4,r2),r4
    { const uint32_t x = c.r[1]; c.pr = 0x06092BBEu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092BBEu) return; }  // 06092BBA jsr @r1 ; mov r8,r5
L_06092BBE:
    c.r[15] = c.r[14];  // 06092BBE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092BC0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092BC2 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 06092BC4 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092BC6 rts ; mov.l @r15+,r8
}

void f_06092BD4(SH2Context& c) {
    ran[2203] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092BD4 mov.l r14,@-r15
    c.r[1] = ld32(0x06092C10u);  // 06092BD6 mov.l 0x06092C10,r1
    c.r[3] = ld32(c.r[1]);  // 06092BD8 mov.l @r1,r3
    c.r[3] += 52;  // 06092BDA add #52,r3
    c.r[1] = c.r[3];  // 06092BDC mov r3,r1
    c.r[1] += 96;  // 06092BDE add #96,r1
    c.r[1] = ld32(c.r[1]);  // 06092BE0 mov.l @r1,r1
    c.r[6] = 0x0u;  // 06092BE2 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06092BE4 cmp/ge r1,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06092BFE; } }  // 06092BE6 bt/s 0x06092BFE ; mov r15,r14
    c.r[7] = c.r[1];  // 06092BEA mov r1,r7
    c.r[2] = 0x0u;  // 06092BEC mov #0,r2
L_06092BEE:
    c.r[0] = c.r[2];  // 06092BEE mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06092BF0 mov.l @(r0,r3),r1
    c.t = c.r[4] == c.r[1];  // 06092BF2 cmp/eq r1,r4
    if (c.t) { goto L_06092BFE; }  // 06092BF4 bt 0x06092BFE
    c.r[6] += 1;  // 06092BF6 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[7];  // 06092BF8 cmp/ge r7,r6
    { const bool k = !c.t; c.r[2] += 4; if (k) { SH2_POLL(c); goto L_06092BEE; } }  // 06092BFA bf/s 0x06092BEE ; add #4,r2
L_06092BFE:
    c.r[3] += 96;  // 06092BFE add #96,r3
    c.r[1] = ld32(c.r[3]);  // 06092C00 mov.l @r3,r1
    c.t = c.r[6] == c.r[1];  // 06092C02 cmp/eq r1,r6
    if (!c.t) { goto L_06092C08; }  // 06092C04 bf 0x06092C08
    c.r[6] = 0xFFFFFFFFu;  // 06092C06 mov #-1,r6
L_06092C08:
    c.r[15] = c.r[14];  // 06092C08 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092C0A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 06092C0C rts ; mov r6,r0
}

void f_06092C14(SH2Context& c) {
    ran[2204] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092C14 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092C16 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092C18 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06092C1A mov r15,r14
    c.r[0] = ld32(0x06092C48u);  // 06092C1C mov.l 0x06092C48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092C22u; c.r[8] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092C22u) return; }  // 06092C1E jsr @r0 ; mov r4,r8
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06092C22 cmp/eq #-1,r0
    if (!c.t) { goto L_06092C3C; }  // 06092C24 bf 0x06092C3C
    c.r[1] = ld32(0x06092C4Cu);  // 06092C26 mov.l 0x06092C4C,r1
    c.r[2] = ld32(c.r[1]);  // 06092C28 mov.l @r1,r2
    c.r[2] += 52;  // 06092C2A add #52,r2
    c.r[1] = c.r[2];  // 06092C2C mov r2,r1
    c.r[1] += 96;  // 06092C2E add #96,r1
    c.r[0] = ld32(c.r[1]);  // 06092C30 mov.l @r1,r0
    c.r[0] <<= 2;  // 06092C32 shll2 r0
    st32(c.r[0] + c.r[2], c.r[8]);  // 06092C34 mov.l r8,@(r0,r2)
    c.r[2] = ld32(c.r[1]);  // 06092C36 mov.l @r1,r2
    c.r[2] += 1;  // 06092C38 add #1,r2
    st32(c.r[1], c.r[2]);  // 06092C3A mov.l r2,@r1
L_06092C3C:
    c.r[15] = c.r[14];  // 06092C3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092C3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092C40 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092C42 rts ; mov.l @r15+,r8
}

void f_06092C50(SH2Context& c) {
    ran[2205] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092C50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092C52 sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 06092C54 tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06092C9A; } }  // 06092C56 bt/s 0x06092C9A ; mov r15,r14
    c.r[0] = ld32(0x06092CA4u);  // 06092C5A mov.l 0x06092CA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092C60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092C60u) return; }  // 06092C5C jsr @r0 ; nop
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06092C60 cmp/eq #-1,r0
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_06092C9A; } }  // 06092C62 bt/s 0x06092C9A ; mov r0,r7
    c.r[1] = ld32(0x06092CA8u);  // 06092C66 mov.l 0x06092CA8,r1
    c.r[6] = ld32(c.r[1]);  // 06092C68 mov.l @r1,r6
    c.r[6] += 52;  // 06092C6A add #52,r6
    c.r[1] = c.r[6];  // 06092C6C mov r6,r1
    c.r[1] += 96;  // 06092C6E add #96,r1
    c.r[2] = ld32(c.r[1]);  // 06092C70 mov.l @r1,r2
    c.r[2] -= 1;  // 06092C72 add #-1,r2
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06092C74 cmp/ge r2,r7
    { const bool k = c.t; st32(c.r[1], c.r[2]); if (k) { goto L_06092C92; } }  // 06092C76 bt/s 0x06092C92 ; mov.l r2,@r1
    c.r[0] <<= 2;  // 06092C7A shll2 r0
    c.r[3] = c.r[0];  // 06092C7C mov r0,r3
    c.r[3] += c.r[6];  // 06092C7E add r6,r3
    c.r[5] = c.r[0];  // 06092C80 mov r0,r5
L_06092C82:
    c.r[1] = ld32(c.r[3] + 4);  // 06092C82 mov.l @(4,r3),r1
    c.r[0] = c.r[5];  // 06092C84 mov r5,r0
    c.r[5] += 4;  // 06092C86 add #4,r5
    c.r[7] += 1;  // 06092C88 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06092C8A cmp/ge r2,r7
    st32(c.r[0] + c.r[6], c.r[1]);  // 06092C8C mov.l r1,@(r0,r6)
    { const bool k = !c.t; c.r[3] += 4; if (k) { SH2_POLL(c); goto L_06092C82; } }  // 06092C8E bf/s 0x06092C82 ; add #4,r3
L_06092C92:
    c.r[7] <<= 2;  // 06092C92 shll2 r7
    c.r[1] = 0x0u;  // 06092C94 mov #0,r1
    c.r[0] = c.r[7];  // 06092C96 mov r7,r0
    st32(c.r[0] + c.r[6], c.r[1]);  // 06092C98 mov.l r1,@(r0,r6)
L_06092C9A:
    c.r[15] = c.r[14];  // 06092C9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092C9C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092C9E rts ; mov.l @r15+,r14
}

void f_06092CAC(SH2Context& c) {
    ran[2206] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092CAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092CAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092CB0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092CB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092CB4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06092CB6 mov r15,r14
    c.r[8] = c.r[4];  // 06092CB8 mov r4,r8
    c.r[10] = c.r[5];  // 06092CBA mov r5,r10
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092CBC tst r8,r8
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_06092CE6; } }  // 06092CBE bt/s 0x06092CE6 ; mov r6,r9
    c.r[4] = c.r[8];  // 06092CC2 mov r8,r4
    c.r[0] = ld32(0x06092CF8u);  // 06092CC4 mov.l 0x06092CF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092CCAu; c.r[4] += 108; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092CCAu) return; }  // 06092CC6 jsr @r0 ; add #108,r4
    c.r[4] = c.r[8];  // 06092CCA mov r8,r4
    c.r[4] += 12;  // 06092CCC add #12,r4
    c.r[0] = ld32(0x06092CFCu);  // 06092CCE mov.l 0x06092CFC,r0
    c.r[6] = c.r[9];  // 06092CD0 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06092CD6u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092CD6u) return; }  // 06092CD2 jsr @r0 ; mov r10,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092CD6 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06092CE8; } }  // 06092CD8 bt/s 0x06092CE8 ; mov #0,r0
    c.r[1] = 0x0u;  // 06092CDC mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 06092CDE mov.l r1,@(4,r8)
    st32(c.r[8] + 8, c.r[1]);  // 06092CE0 mov.l r1,@(8,r8)
    c.r[0] = c.r[8]; goto L_06092CE8;  // 06092CE2 bra 0x06092CE8 ; mov r8,r0
L_06092CE6:
    c.r[0] = 0x0u;  // 06092CE6 mov #0,r0
L_06092CE8:
    c.r[15] = c.r[14];  // 06092CE8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092CEA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092CEC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092CEE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092CF0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092CF2 rts ; mov.l @r15+,r8
}

void f_06092D08(SH2Context& c) {
    ran[2207] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092D08 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092D0A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092D0C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06092D0E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092D10 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092D12 sts.l pr,@-r15
    c.r[15] -= 24;  // 06092D14 add #-24,r15
    c.r[14] = c.r[15];  // 06092D16 mov r15,r14
    c.r[0] = ld32(0x06092DB0u);  // 06092D18 mov.l 0x06092DB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092D1Eu; c.r[11] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D1Eu) return; }  // 06092D1A jsr @r0 ; mov r4,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092DAAu);  // 06092D1E mov.w 0x06092DAA,r1
    c.r[0] += c.r[1];  // 06092D20 add r1,r0
    st32(c.r[14], c.r[0]);  // 06092D22 mov.l r0,@r14
    c.r[10] = (uint32_t)(int16_t)ld16(0x06092DACu);  // 06092D24 mov.w 0x06092DAC,r10
    st32(c.r[14] + 4, c.r[10]);  // 06092D26 mov.l r10,@(4,r14)
    c.r[1] = c.r[14];  // 06092D28 mov r14,r1
    c.r[1] += 10;  // 06092D2A add #10,r1
    c.r[2] = 0x0u;  // 06092D2C mov #0,r2
    st8(c.r[1], c.r[2]);  // 06092D2E mov.b r2,@r1
    c.r[1] = c.r[14];  // 06092D30 mov r14,r1
    c.r[1] += 11;  // 06092D32 add #11,r1
    st8(c.r[1], c.r[2]);  // 06092D34 mov.b r2,@r1
    c.r[1] = c.r[14];  // 06092D36 mov r14,r1
    c.r[1] += 8;  // 06092D38 add #8,r1
    st8(c.r[1], c.r[2]);  // 06092D3A mov.b r2,@r1
    c.r[1] = c.r[14];  // 06092D3C mov r14,r1
    c.r[1] += 9;  // 06092D3E add #9,r1
    c.r[0] = ld32(0x06092DB4u);  // 06092D40 mov.l 0x06092DB4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092D46u; st8(c.r[1], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D46u) return; }  // 06092D42 jsr @r0 ; mov.b r2,@r1
    c.r[9] = c.r[0];  // 06092D46 mov r0,r9
    c.r[0] = ld32(0x06092DB8u);  // 06092D48 mov.l 0x06092DB8,r0
    c.r[6] = 0x0u;  // 06092D4A mov #0,r6
    c.r[5] = c.r[14];  // 06092D4C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06092D52u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D52u) return; }  // 06092D4E jsr @r0 ; mov r9,r4
    c.r[9] = c.r[0];  // 06092D52 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06092D54 tst r9,r9
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06092D98; } }  // 06092D56 bt/s 0x06092D98 ; mov #-1,r0
    c.r[0] = ld32(0x06092DBCu);  // 06092D5A mov.l 0x06092DBC,r0
    c.r[7] = c.r[10];  // 06092D5C mov r10,r7
    c.r[6] = c.r[11];  // 06092D5E mov r11,r6
    c.r[5] = 0x1u;  // 06092D60 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06092D66u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D66u) return; }  // 06092D62 jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0];  // 06092D66 mov r0,r8
    c.t = c.r[8] == c.r[10];  // 06092D68 cmp/eq r10,r8
    { const bool k = c.t; c.r[8] = c.r[14]; if (k) { goto L_06092D72; } }  // 06092D6A bt/s 0x06092D72 ; mov r14,r8
    c.r[0] = 0xFFFFFFFFu; goto L_06092D98;  // 06092D6E bra 0x06092D98 ; mov #-1,r0
L_06092D72:
    c.r[8] += 12;  // 06092D72 add #12,r8
    c.r[1] = ld32(0x06092DC0u);  // 06092D74 mov.l 0x06092DC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092D7Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D7Au) return; }  // 06092D76 jsr @r1 ; mov r8,r4
    c.r[8] = ld32(c.r[8] + 8);  // 06092D7A mov.l @(8,r8),r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092D7C tst r8,r8
    { const bool k = !c.t; c.r[6] = 0x6u; if (k) { goto L_06092D90; } }  // 06092D7E bf/s 0x06092D90 ; mov #6,r6
    c.r[5] = ld32(0x06092DC4u);  // 06092D82 mov.l 0x06092DC4,r5
    c.r[0] = ld32(0x06092DC8u);  // 06092D84 mov.l 0x06092DC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092D8Au; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D8Au) return; }  // 06092D86 jsr @r0 ; mov r11,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092D8A tst r0,r0
    if (c.t) { goto L_06092D90; }  // 06092D8C bt 0x06092D90
    c.r[8] = 0xFFFFFFFDu;  // 06092D8E mov #-3,r8
L_06092D90:
    c.r[1] = ld32(0x06092DCCu);  // 06092D90 mov.l 0x06092DCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092D96u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092D96u) return; }  // 06092D92 jsr @r1 ; mov r9,r4
    c.r[0] = c.r[8];  // 06092D96 mov r8,r0
L_06092D98:
    c.r[14] += 24;  // 06092D98 add #24,r14
    c.r[15] = c.r[14];  // 06092D9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092D9C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092D9E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06092DA0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092DA2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092DA4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092DA6 rts ; mov.l @r15+,r8
}

void f_06092DD0(SH2Context& c) {
    ran[2208] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092DD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092DD2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092DD4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092DD6 sts.l pr,@-r15
    c.r[15] -= 4;  // 06092DD8 add #-4,r15
    c.r[8] = c.r[4];  // 06092DDA mov r4,r8
    c.r[9] = ld32(0x06092EB8u);  // 06092DDC mov.l 0x06092EB8,r9
    c.r[4] = ld32(c.r[9]);  // 06092DDE mov.l @r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092EA8u);  // 06092DE0 mov.w 0x06092EA8,r0
    c.r[0] = ld32(c.r[0] + c.r[4]);  // 06092DE2 mov.l @(r0,r4),r0
    c.r[0] &= 0x1u;  // 06092DE4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092DE6 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06092DF0; } }  // 06092DE8 bf/s 0x06092DF0 ; mov r15,r14
    c.r[0] = 0xFFFFFFFEu; goto L_06092E9A;  // 06092DEC bra 0x06092E9A ; mov #-2,r0
L_06092DF0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092EAAu);  // 06092DF0 mov.w 0x06092EAA,r1
    c.r[0] = ld32(0x06092EBCu);  // 06092DF2 mov.l 0x06092EBC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092DF8u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092DF8u) return; }  // 06092DF4 jsr @r0 ; add r1,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092DF8 tst r0,r0
    if (!c.t) { goto L_06092E9A; }  // 06092DFA bf 0x06092E9A
    c.r[3] = ld32(c.r[9]);  // 06092DFC mov.l @r9,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092EACu);  // 06092DFE mov.w 0x06092EAC,r1
    c.r[3] += c.r[1];  // 06092E00 add r1,r3
    c.r[1] = c.r[3];  // 06092E02 mov r3,r1
    c.r[1] += 6;  // 06092E04 add #6,r1
    c.r[2] = c.r[3];  // 06092E06 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06092E08 mov.b @r1,r1
    c.r[2] += 7;  // 06092E0A add #7,r2
    st8(c.r[8], c.r[1]);  // 06092E0C mov.b r1,@r8
    c.r[1] = c.r[8];  // 06092E0E mov r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06092E10 mov.b @r2,r2
    c.r[1] += 1;  // 06092E12 add #1,r1
    st8(c.r[1], c.r[2]);  // 06092E14 mov.b r2,@r1
    c.r[2] = c.r[3];  // 06092E16 mov r3,r2
    c.r[2] += 8;  // 06092E18 add #8,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06092E1A mov.b @r2,r2
    c.r[1] += 1;  // 06092E1C add #1,r1
    st8(c.r[1], c.r[2]);  // 06092E1E mov.b r2,@r1
    c.r[2] = c.r[3];  // 06092E20 mov r3,r2
    c.r[2] += 9;  // 06092E22 add #9,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06092E24 mov.b @r2,r2
    c.r[1] += 1;  // 06092E26 add #1,r1
    st8(c.r[1], c.r[2]);  // 06092E28 mov.b r2,@r1
    c.r[2] = ld32(c.r[8]);  // 06092E2A mov.l @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092EAEu);  // 06092E2C mov.w 0x06092EAE,r1
    c.r[2] += c.r[1];  // 06092E2E add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092EB0u);  // 06092E30 mov.w 0x06092EB0,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06092E32 cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[8], c.r[2]); if (k) { goto L_06092E64; } }  // 06092E34 bf/s 0x06092E64 ; mov.l r2,@r8
    c.r[1] = c.r[3];  // 06092E38 mov r3,r1
    c.r[1] += 14;  // 06092E3A add #14,r1
    c.r[2] = c.r[3];  // 06092E3C mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06092E3E mov.b @r1,r1
    c.r[2] += 15;  // 06092E40 add #15,r2
    st8(c.r[14], c.r[1]);  // 06092E42 mov.b r1,@r14
    c.r[1] = c.r[14];  // 06092E44 mov r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06092E46 mov.b @r2,r2
    c.r[1] += 1;  // 06092E48 add #1,r1
    st8(c.r[1], c.r[2]);  // 06092E4A mov.b r2,@r1
    c.r[1] += 1;  // 06092E4C add #1,r1
    c.r[2] = c.r[3];  // 06092E4E mov r3,r2
    c.r[2] += 16;  // 06092E50 add #16,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06092E52 mov.b @r2,r2
    c.r[3] += 17;  // 06092E54 add #17,r3
    st8(c.r[1], c.r[2]);  // 06092E56 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06092E58 mov.b @r3,r2
    c.r[1] += 1;  // 06092E5A add #1,r1
    st8(c.r[1], c.r[2]);  // 06092E5C mov.b r2,@r1
    c.r[4] = ld32(c.r[14]);  // 06092E5E mov.l @r14,r4
    c.t = (int32_t)c.r[4] > 0;  // 06092E60 cmp/pl r4
    if (c.t) { goto L_06092E68; }  // 06092E62 bt 0x06092E68
L_06092E64:
    c.r[0] = 0xFFFFFFFDu; goto L_06092E9A;  // 06092E64 bra 0x06092E9A ; mov #-3,r0
L_06092E68:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092EB2u);  // 06092E68 mov.w 0x06092EB2,r1
    c.r[4] += c.r[1];  // 06092E6A add r1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 06092E6C cmp/pz r4
    if (c.t) { goto L_06092E72; }  // 06092E6E bt 0x06092E72
    c.r[4] += c.r[1];  // 06092E70 add r1,r4
L_06092E72:
    c.r[1] = ld32(0x06092EC0u);  // 06092E72 mov.l 0x06092EC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092E78u; c.r[2] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092E78u) return; }  // 06092E74 jsr @r1 ; mov #0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06092EB4u);  // 06092E78 mov.w 0x06092EB4,r1
    c.r[3] = c.r[8];  // 06092E7A mov r8,r3
    c.macl = c.r[4] * c.r[1];  // 06092E7C mul.l r1,r4
    c.r[3] += 11;  // 06092E7E add #11,r3
    c.r[0] = 0x0u;  // 06092E80 mov #0,r0
    c.r[7] = c.macl;  // 06092E82 sts macl,r7
    st32(c.r[8] + 4, c.r[7]);  // 06092E84 mov.l r7,@(4,r8)
    c.r[1] = c.r[8];  // 06092E86 mov r8,r1
    c.r[1] += 10;  // 06092E88 add #10,r1
    st8(c.r[1], c.r[2]);  // 06092E8A mov.b r2,@r1
    c.r[1] = 0xFFFFFF80u;  // 06092E8C mov #-128,r1
    st8(c.r[3], c.r[1]);  // 06092E8E mov.b r1,@r3
    c.r[1] = c.r[8];  // 06092E90 mov r8,r1
    c.r[1] += 8;  // 06092E92 add #8,r1
    st8(c.r[1], c.r[2]);  // 06092E94 mov.b r2,@r1
    c.r[8] += 9;  // 06092E96 add #9,r8
    st8(c.r[8], c.r[2]);  // 06092E98 mov.b r2,@r8
L_06092E9A:
    c.r[14] += 4;  // 06092E9A add #4,r14
    c.r[15] = c.r[14];  // 06092E9C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092E9E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092EA0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092EA2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092EA4 rts ; mov.l @r15+,r8
}

void f_06092EC4(SH2Context& c) {
    ran[2209] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092EC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092EC6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092EC8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092ECA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092ECC sts.l pr,@-r15
    c.r[15] -= 12;  // 06092ECE add #-12,r15
    c.r[14] = c.r[15];  // 06092ED0 mov r15,r14
    c.r[10] = c.r[4];  // 06092ED2 mov r4,r10
    c.r[0] = ld32(0x06092F38u);  // 06092ED4 mov.l 0x06092F38,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092EDAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092EDAu) return; }  // 06092ED6 jsr @r0 ; mov r14,r4
    c.r[9] = c.r[0];  // 06092EDA mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06092EDC tst r9,r9
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06092EF6; } }  // 06092EDE bf/s 0x06092EF6 ; mov #0,r8
    c.r[0] = ld32(0x06092F3Cu);  // 06092EE2 mov.l 0x06092F3C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06092EE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092EE8u) return; }  // 06092EE4 jsr @r0 ; nop
    c.r[8] = c.r[0];  // 06092EE8 mov r0,r8
    c.r[0] = ld32(0x06092F40u);  // 06092EEA mov.l 0x06092F40,r0
    c.r[6] = 0x0u;  // 06092EEC mov #0,r6
    c.r[5] = c.r[14];  // 06092EEE mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06092EF4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092EF4u) return; }  // 06092EF0 jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0];  // 06092EF4 mov r0,r8
L_06092EF6:
    c.r[1] = ld32(0x06092F44u);  // 06092EF6 mov.l 0x06092F44,r1
    c.r[1] = ld32(c.r[1]);  // 06092EF8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092F34u);  // 06092EFA mov.w 0x06092F34,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06092EFC mov.l @(r0,r1),r0
    c.r[0] &= 0x1u;  // 06092EFE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06092F00 tst r0,r0
    { const bool k = c.t; c.r[6] = ld32(c.r[14] + 4); if (k) { goto L_06092F0E; } }  // 06092F02 bt/s 0x06092F0E ; mov.l @(4,r14),r6
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092F06 tst r8,r8
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_06092F24; } }  // 06092F08 bt/s 0x06092F24 ; mov r9,r0
    c.r[6] = ld32(c.r[14] + 4);  // 06092F0C mov.l @(4,r14),r6
L_06092F0E:
    c.r[0] = ld32(0x06092F48u);  // 06092F0E mov.l 0x06092F48,r0
    c.r[5] = c.r[10];  // 06092F10 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06092F16u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092F16u) return; }  // 06092F12 jsr @r0 ; mov r8,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 06092F16 tst r8,r8
    { const bool k = c.t; c.r[9] = c.r[0]; if (k) { goto L_06092F22; } }  // 06092F18 bt/s 0x06092F22 ; mov r0,r9
    c.r[1] = ld32(0x06092F4Cu);  // 06092F1C mov.l 0x06092F4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06092F22u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092F22u) return; }  // 06092F1E jsr @r1 ; mov r8,r4
L_06092F22:
    c.r[0] = c.r[9];  // 06092F22 mov r9,r0
L_06092F24:
    c.r[14] += 12;  // 06092F24 add #12,r14
    c.r[15] = c.r[14];  // 06092F26 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092F28 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092F2A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092F2C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092F2E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092F30 rts ; mov.l @r15+,r8
}

void f_06092F50(SH2Context& c) {
    ran[2210] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092F50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06092F52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06092F54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092F56 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092F58 sts.l pr,@-r15
    c.r[15] -= 4;  // 06092F5A add #-4,r15
    c.r[14] = c.r[15];  // 06092F5C mov r15,r14
    c.r[8] = c.r[4];  // 06092F5E mov r4,r8
    c.r[10] = c.r[8];  // 06092F60 mov r8,r10
    c.r[1] = c.r[8];  // 06092F62 mov r8,r1
    c.r[1] += 92;  // 06092F64 add #92,r1
    c.r[1] = ld32(c.r[1]);  // 06092F66 mov.l @r1,r1
    c.r[0] = c.r[1];  // 06092F68 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 06092F6A cmp/eq #4,r0
    { const bool k = c.t; c.r[10] += 12; if (k) { goto L_06092FD0; } }  // 06092F6C bt/s 0x06092FD0 ; add #12,r10
    c.r[1] = ld32(0x06092FE8u);  // 06092F70 mov.l 0x06092FE8,r1
    c.r[1] = ld32(c.r[1]);  // 06092F72 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092FE0u);  // 06092F74 mov.w 0x06092FE0,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06092F76 mov.l @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06092F78 tst r1,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[8]; if (k) { goto L_06092F82; } }  // 06092F7A bt/s 0x06092F82 ; cmp/eq r8,r1
    { const bool k = !c.t; c.r[0] = 0x7u; if (k) { goto L_06092FD0; } }  // 06092F7E bf/s 0x06092FD0 ; mov #7,r0
L_06092F82:
    c.r[1] = ld32(c.r[10] + 28);  // 06092F82 mov.l @(28,r10),r1
    c.r[9] = ld32(0x06092FE8u);  // 06092F84 mov.l 0x06092FE8,r9
    c.r[2] = ld32(c.r[9]);  // 06092F86 mov.l @r9,r2
    c.r[1] <<= 2;  // 06092F88 shll2 r1
    c.r[1] <<= 2;  // 06092F8A shll2 r1
    c.r[1] += 4;  // 06092F8C add #4,r1
    c.r[0] = c.r[2];  // 06092F8E mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06092F90 mov.l @(r0,r1),r1
    c.r[4] = c.r[10];  // 06092F92 mov r10,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06092F98u; st32(c.r[14], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092F98u) return; }  // 06092F94 jsr @r1 ; mov.l r1,@r14
    c.t = c.r[0] == 0x1u;  // 06092F98 cmp/eq #1,r0
    { const bool k = !c.t; c.r[7] = c.r[0]; if (k) { goto L_06092FA6; } }  // 06092F9A bf/s 0x06092FA6 ; mov r0,r7
    c.r[1] = ld32(c.r[9]);  // 06092F9E mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06092FE0u);  // 06092FA0 mov.w 0x06092FE0,r0
    st32(c.r[0] + c.r[1], c.r[8]); goto L_06092FC4;  // 06092FA2 bra 0x06092FC4 ; mov.l r8,@(r0,r1)
L_06092FA6:
    c.r[0] = c.r[7];  // 06092FA6 mov r7,r0
    c.t = c.r[0] == 0x4u;  // 06092FA8 cmp/eq #4,r0
    if (!c.t) { goto L_06092FC4; }  // 06092FAA bf 0x06092FC4
    c.r[2] = ld32(c.r[9]);  // 06092FAC mov.l @r9,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06092FE0u);  // 06092FAE mov.w 0x06092FE0,r3
    c.r[0] = c.r[2];  // 06092FB0 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06092FB2 mov.l @(r0,r3),r1
    c.t = c.r[1] == c.r[8];  // 06092FB4 cmp/eq r8,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06092FC4; } }  // 06092FB6 bf/s 0x06092FC4 ; mov #0,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 06092FBA mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06092FE2u);  // 06092FBC mov.w 0x06092FE2,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06092FE4u);  // 06092FBE mov.w 0x06092FE4,r6
    st32(c.r[0] + c.r[6], c.r[1]);  // 06092FC0 mov.l r1,@(r0,r6)
    st32(c.r[0] + c.r[3], c.r[1]);  // 06092FC2 mov.l r1,@(r0,r3)
L_06092FC4:
    c.r[10] += 80;  // 06092FC4 add #80,r10
    st32(c.r[10], c.r[7]);  // 06092FC6 mov.l r7,@r10
    c.r[0] = ld32(0x06092FECu);  // 06092FC8 mov.l 0x06092FEC,r0
    c.r[5] = c.r[7];  // 06092FCA mov r7,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06092FD0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06092FD0u) return; }  // 06092FCC jsr @r0 ; mov r8,r4
L_06092FD0:
    c.r[14] += 4;  // 06092FD0 add #4,r14
    c.r[15] = c.r[14];  // 06092FD2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06092FD4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06092FD6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06092FD8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06092FDA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06092FDC rts ; mov.l @r15+,r8
}

void f_06092FF0(SH2Context& c) {
    ran[2211] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06092FF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06092FF2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06092FF4 sts.l pr,@-r15
    c.r[15] -= 8;  // 06092FF6 add #-8,r15
    c.r[1] = ld32(0x06093088u);  // 06092FF8 mov.l 0x06093088,r1
    c.r[1] = ld32(c.r[1]);  // 06092FFA mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06093084u);  // 06092FFC mov.w 0x06093084,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06092FFE mov.l @(r0,r1),r1
    c.r[8] = c.r[4];  // 06093000 mov r4,r8
    c.t = c.r[1] == c.r[8];  // 06093002 cmp/eq r8,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609300E; } }  // 06093004 bt/s 0x0609300E ; mov r15,r14
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093008 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06093078; } }  // 0609300A bf/s 0x06093078 ; mov #1,r0
L_0609300E:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609300E mov.l r14,@-r15
    c.r[1] = ld32(0x0609308Cu);  // 06093010 mov.l 0x0609308C,r1
    c.r[7] = 0x0u;  // 06093012 mov #0,r7
    c.r[6] = 0x0u;  // 06093014 mov #0,r6
    c.r[5] = 0x0u;  // 06093016 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609301Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609301Cu) return; }  // 06093018 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(c.r[14]);  // 0609301C mov.l @r14,r0
    c.r[0] &= 0x40u;  // 0609301E and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06093020 tst r0,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0609302A; } }  // 06093022 bt/s 0x0609302A ; add #4,r15
    c.r[0] = 0x6u; goto L_06093078;  // 06093026 bra 0x06093078 ; mov #6,r0
L_0609302A:
    c.r[4] = c.r[8];  // 0609302A mov r8,r4
    c.r[0] = ld32(0x06093090u);  // 0609302C mov.l 0x06093090,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06093032u; c.r[4] += 108; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093032u) return; }  // 0609302E jsr @r0 ; add #108,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06093032 tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_06093042; } }  // 06093034 bf/s 0x06093042 ; mov r14,r5
    c.r[0] = ld32(0x06093094u);  // 06093038 mov.l 0x06093094,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609303Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609303Eu) return; }  // 0609303A jsr @r0 ; mov r8,r4
    c.r[3] = c.r[0]; goto L_0609304C;  // 0609303E bra 0x0609304C ; mov r0,r3
L_06093042:
    c.r[5] += 4;  // 06093042 add #4,r5
    c.r[0] = ld32(0x06093098u);  // 06093044 mov.l 0x06093098,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609304Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609304Au) return; }  // 06093046 jsr @r0 ; mov r8,r4
    c.r[3] = c.r[0];  // 0609304A mov r0,r3
L_0609304C:
    c.r[0] = c.r[3];  // 0609304C mov r3,r0
    c.t = c.r[0] == 0x6u;  // 0609304E cmp/eq #6,r0
    if (!c.t) { goto L_06093066; }  // 06093050 bf 0x06093066
    c.r[1] = ld32(0x06093088u);  // 06093052 mov.l 0x06093088,r1
    c.r[2] = ld32(c.r[1]);  // 06093054 mov.l @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06093084u);  // 06093056 mov.w 0x06093084,r7
    c.r[0] = c.r[2];  // 06093058 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609305A mov.l @(r0,r7),r1
    c.t = c.r[1] == c.r[8];  // 0609305C cmp/eq r8,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06093076; } }  // 0609305E bf/s 0x06093076 ; mov #0,r1
    st32(c.r[0] + c.r[7], c.r[1]); goto L_06093076;  // 06093062 bra 0x06093076 ; mov.l r1,@(r0,r7)
L_06093066:
    c.r[1] = ld32(0x06093088u);  // 06093066 mov.l 0x06093088,r1
    c.r[2] = ld32(c.r[1]);  // 06093068 mov.l @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06093084u);  // 0609306A mov.w 0x06093084,r7
    c.r[0] = c.r[2];  // 0609306C mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609306E mov.l @(r0,r7),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093070 tst r1,r1
    if (!c.t) { goto L_06093076; }  // 06093072 bf 0x06093076
    st32(c.r[0] + c.r[7], c.r[8]);  // 06093074 mov.l r8,@(r0,r7)
L_06093076:
    c.r[0] = c.r[3];  // 06093076 mov r3,r0
L_06093078:
    c.r[14] += 8;  // 06093078 add #8,r14
    c.r[15] = c.r[14];  // 0609307A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609307C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609307E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06093080 rts ; mov.l @r15+,r8
}

void f_0609309C(SH2Context& c) {
    ran[2212] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609309C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609309E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060930A0 sts.l pr,@-r15
    c.r[15] -= 12;  // 060930A2 add #-12,r15
    c.r[14] = c.r[15];  // 060930A4 mov r15,r14
    c.r[8] = c.r[5];  // 060930A6 mov r5,r8
    c.r[0] = ld32(0x060930ECu);  // 060930A8 mov.l 0x060930EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060930AEu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060930AEu) return; }  // 060930AA jsr @r0 ; mov r14,r5
    c.t = (int32_t)c.r[0] >= 0;  // 060930AE cmp/pz r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_060930DE; } }  // 060930B0 bf/s 0x060930DE ; mov r14,r1
    c.r[1] += 8;  // 060930B4 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060930B6 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 060930B8 extu.b r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 060930BA tst r6,r6
    { const bool k = c.t; c.r[4] = c.r[8]; if (k) { goto L_060930DA; } }  // 060930BC bt/s 0x060930DA ; mov r8,r4
    c.r[7] = ld32(0x060930F0u);  // 060930C0 mov.l 0x060930F0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x060930C6u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060930C6u) return; }  // 060930C2 jsr @r7 ; mov r6,r5
    c.r[1] = c.r[14];  // 060930C6 mov r14,r1
    c.r[1] += 9;  // 060930C8 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060930CA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060930CC extu.b r1,r1
    c.r[6] += c.r[1];  // 060930CE add r1,r6
    c.macl = c.r[0] * c.r[6];  // 060930D0 mul.l r6,r0
    c.r[0] = ld32(c.r[14]);  // 060930D2 mov.l @r14,r0
    c.r[1] = c.macl;  // 060930D4 sts macl,r1
    c.r[0] += c.r[1]; goto L_060930DE;  // 060930D6 bra 0x060930DE ; add r1,r0
L_060930DA:
    c.r[0] = ld32(c.r[14]);  // 060930DA mov.l @r14,r0
    c.r[0] += c.r[8];  // 060930DC add r8,r0
L_060930DE:
    c.r[14] += 12;  // 060930DE add #12,r14
    c.r[15] = c.r[14];  // 060930E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060930E2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060930E4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060930E6 rts ; mov.l @r15+,r8
}

void f_060930F4(SH2Context& c) {
    ran[2213] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060930F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060930F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060930F8 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 060930FA mov r4,r8
    c.r[1] = ld32(c.r[8] + 28);  // 060930FC mov.l @(28,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060930FE tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609310E; } }  // 06093100 bf/s 0x0609310E ; mov r15,r14
    c.r[1] = ld32(0x0609312Cu);  // 06093104 mov.l 0x0609312C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609310Au; c.r[8] += 80; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609310Au) return; }  // 06093106 jsr @r1 ; add #80,r8
    c.r[1] = 0x0u; goto L_06093120;  // 0609310A bra 0x06093120 ; mov #0,r1
L_0609310E:
    c.r[1] = c.r[8];  // 0609310E mov r8,r1
    c.r[1] += 84;  // 06093110 add #84,r1
    st32(c.r[1], c.r[5]);  // 06093112 mov.l r5,@r1
    c.r[2] = c.r[8];  // 06093114 mov r8,r2
    c.r[2] += 88;  // 06093116 add #88,r2
    c.r[1] = 0x0u;  // 06093118 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0609311A mov.l r1,@r2
    c.r[8] += 80;  // 0609311C add #80,r8
    c.r[1] = 0x0u;  // 0609311E mov #0,r1
L_06093120:
    st32(c.r[8], c.r[1]);  // 06093120 mov.l r1,@r8
    c.r[15] = c.r[14];  // 06093122 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093124 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093126 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06093128 rts ; mov.l @r15+,r8
}

void f_06093130(SH2Context& c) {
    ran[2214] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093130 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06093132 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093134 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093136 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06093138 mov r15,r14
    c.r[3] = ld32(c.r[14] + 16);  // 0609313A mov.l @(16,r14),r3
    c.r[9] = ld32(c.r[14] + 20);  // 0609313C mov.l @(20,r14),r9
    c.r[2] = ld32(c.r[14] + 24);  // 0609313E mov.l @(24,r14),r2
    c.r[8] = c.r[4];  // 06093140 mov r4,r8
    c.r[1] = ld32(c.r[14] + 28);  // 06093142 mov.l @(28,r14),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06093144 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06093146 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06093148 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609314A mov.l r1,@-r15
    c.r[1] = ld32(0x0609316Cu);  // 0609314C mov.l 0x0609316C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06093152u; c.r[15] -= 4; st32(c.r[15], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093152u) return; }  // 0609314E jsr @r1 ; mov.l r3,@-r15
    c.t = (c.r[9] & c.r[9]) == 0;  // 06093152 tst r9,r9
    if (c.t) { goto L_0609315E; }  // 06093154 bt 0x0609315E
    c.r[2] = ld32(c.r[8] + 16);  // 06093156 mov.l @(16,r8),r2
    c.r[1] = ld32(c.r[8] + 24);  // 06093158 mov.l @(24,r8),r1
    c.r[2] -= c.r[1];  // 0609315A sub r1,r2
    st32(c.r[9], c.r[2]);  // 0609315C mov.l r2,@r9
L_0609315E:
    c.r[15] = c.r[14];  // 0609315E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093160 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093162 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06093164 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06093166 rts ; mov.l @r15+,r8
}

void f_06093170(SH2Context& c) {
    ran[2215] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093170 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06093172 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093174 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093176 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 06093178 mov r4,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609317A tst r9,r9
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06093194; } }  // 0609317C bt/s 0x06093194 ; mov r15,r14
    c.r[8] = c.r[9];  // 06093180 mov r9,r8
    c.r[1] = ld32(0x060931A0u);  // 06093182 mov.l 0x060931A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06093188u; c.r[8] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093188u) return; }  // 06093184 jsr @r1 ; add #40,r8
    c.r[1] = ld32(0x060931A4u);  // 06093188 mov.l 0x060931A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609318Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609318Eu) return; }  // 0609318A jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x060931A8u);  // 0609318E mov.l 0x060931A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06093194u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093194u) return; }  // 06093190 jsr @r1 ; mov r8,r4
L_06093194:
    c.r[15] = c.r[14];  // 06093194 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093196 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093198 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609319A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609319C rts ; mov.l @r15+,r8
}

void f_060931AC(SH2Context& c) {
    ran[2216] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060931AC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060931AE mov r15,r14
    c.r[4] += 88;  // 060931B0 add #88,r4
    c.r[0] = ld32(c.r[4]);  // 060931B2 mov.l @r4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060931B4 rts ; mov.l @r15+,r14
}

void f_060931B8(SH2Context& c) {
    ran[2217] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060931B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060931BA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060931BC sts.l pr,@-r15
    c.r[15] -= 4;  // 060931BE add #-4,r15
    c.r[14] = c.r[15];  // 060931C0 mov r15,r14
    c.r[8] = c.r[4];  // 060931C2 mov r4,r8
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060931C4 mov.l r14,@-r15
    c.r[1] = ld32(0x06093204u);  // 060931C6 mov.l 0x06093204,r1
    c.r[7] = 0x0u;  // 060931C8 mov #0,r7
    c.r[6] = 0x0u;  // 060931CA mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060931D0u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060931D0u) return; }  // 060931CC jsr @r1 ; mov #0,r5
    c.r[1] = c.r[8];  // 060931D0 mov r8,r1
    c.r[1] += 92;  // 060931D2 add #92,r1
    c.r[0] = ld32(c.r[1]);  // 060931D4 mov.l @r1,r0
    c.t = c.r[0] == 0x4u;  // 060931D6 cmp/eq #4,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_060931F6; } }  // 060931D8 bf/s 0x060931F6 ; add #4,r15
    c.r[0] = ld32(0x06093208u);  // 060931DC mov.l 0x06093208,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060931E2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060931E2u) return; }  // 060931DE jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060931E2 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_060931F8; } }  // 060931E4 bt/s 0x060931F8 ; mov #1,r0
    c.r[0] = ld32(c.r[14]);  // 060931E8 mov.l @r14,r0
    c.r[0] &= 0x40u;  // 060931EA and #64,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060931EC tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060931F8; } }  // 060931EE bt/s 0x060931F8 ; mov #0,r0
    c.r[0] = 0x1u; goto L_060931F8;  // 060931F2 bra 0x060931F8 ; mov #1,r0
L_060931F6:
    c.r[0] = 0x0u;  // 060931F6 mov #0,r0
L_060931F8:
    c.r[14] += 4;  // 060931F8 add #4,r14
    c.r[15] = c.r[14];  // 060931FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060931FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060931FE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06093200 rts ; mov.l @r15+,r8
}

void f_0609320C(SH2Context& c) {
    ran[2218] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609320C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609320E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093210 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06093212 mov r15,r14
    c.r[1] = 0x6u;  // 06093214 mov #6,r1
    c.r[5] -= 3;  // 06093216 add #-3,r5
    c.t = c.r[5] > c.r[1];  // 06093218 cmp/hi r1,r5
    { const bool k = c.t; c.r[8] = c.r[4]; if (k) { goto L_06093264; } }  // 0609321A bt/s 0x06093264 ; mov r4,r8
    c.r[1] = c.r[5];  // 0609321E mov r5,r1
    c.r[1] += c.r[1];  // 06093220 add r1,r1
    c.r[0] = 0x0609322Cu;  // 06093222 mova 0x0609322C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06093224 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06093226 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0609324Eu: goto L_0609324E; case 0x06093264u: goto L_06093264; case 0x06093242u: goto L_06093242; case 0x06093246u: goto L_06093246; case 0x0609324Au: goto L_0609324A; case 0x0609323Eu: goto L_0609323E; case 0x0609323Au: goto L_0609323A; default: sh2_call(c, x); return; } }  // 06093228 jmp @r0 ; nop
L_0609323A:
    c.r[4] = 0xFFFFFFE7u; goto L_0609325A;  // 0609323A bra 0x0609325A ; mov #-25,r4
L_0609323E:
    c.r[4] = 0xFFFFFFFFu; goto L_0609325A;  // 0609323E bra 0x0609325A ; mov #-1,r4
L_06093242:
    c.r[4] = 0xFFFFFFE9u; goto L_0609325A;  // 06093242 bra 0x0609325A ; mov #-23,r4
L_06093246:
    c.r[4] = 0xFFFFFFFEu; goto L_0609325A;  // 06093246 bra 0x0609325A ; mov #-2,r4
L_0609324A:
    c.r[4] = 0xFFFFFFECu; goto L_0609325A;  // 0609324A bra 0x0609325A ; mov #-20,r4
L_0609324E:
    c.r[0] = ld32(0x06093274u);  // 0609324E mov.l 0x06093274,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06093254u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093254u) return; }  // 06093250 jsr @r0 ; mov r8,r4
    c.t = c.r[0] == 0x1u;  // 06093254 cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = 0xFFFFFFE8u; if (k) { goto L_06093268; } }  // 06093256 bf/s 0x06093268 ; mov #-24,r4
L_0609325A:
    c.r[0] = ld32(0x06093278u);  // 0609325A mov.l 0x06093278,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06093260u; st32(c.r[8] + 8, c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093260u) return; }  // 0609325C jsr @r0 ; mov.l r4,@(8,r8)
    c.r[15] = c.r[14]; goto L_0609326C;  // 06093260 bra 0x0609326C ; mov r14,r15
L_06093264:
    c.r[1] = 0x1u;  // 06093264 mov #1,r1
    st32(c.r[8] + 8, c.r[1]);  // 06093266 mov.l r1,@(8,r8)
L_06093268:
    c.r[0] = 0x0u;  // 06093268 mov #0,r0
    c.r[15] = c.r[14];  // 0609326A mov r14,r15
L_0609326C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609326C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609326E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06093270 rts ; mov.l @r15+,r8
}

void f_0609327C(SH2Context& c) {
    ran[2219] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609327C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609327E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093280 sts.l pr,@-r15
    c.r[15] -= 16;  // 06093282 add #-16,r15
    c.r[14] = c.r[15];  // 06093284 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093286 mov.l r4,@r14
    c.r[1] = 0x0u;  // 06093288 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609328A mov.l r1,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060932FEu);  // 0609328C mov.w 0x060932FE,r1
    c.r[4] = c.r[1];  // 0609328E mov r1,r4
    c.r[8] = ld32(0x06093300u);  // 06093290 mov.l 0x06093300,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093296u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093296u) return; }  // 06093292 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093296 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093298 tst r1,r1
    if (!c.t) { goto L_060932B0; }  // 0609329A bf 0x060932B0
    c.r[4] = 0xFFFFFFF5u;  // 0609329C mov #-11,r4
    c.r[8] = ld32(0x06093304u);  // 0609329E mov.l 0x06093304,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060932A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060932A4u) return; }  // 060932A0 jsr @r8 ; nop
    c.r[8] = ld32(0x06093308u);  // 060932A4 mov.l 0x06093308,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060932AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060932AAu) return; }  // 060932A6 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF5u;  // 060932AA mov #-11,r0
    goto L_060932F0;  // 060932AC bra 0x060932F0 ; nop
L_060932B0:
    ;  // 060932B0 nop
    c.r[1] = ld32(c.r[14]);  // 060932B2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 060932B4 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 060932B6 mov.l r2,@(8,r14)
L_060932B8:
    c.r[1] = ld32(c.r[14] + 8);  // 060932B8 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060932BA tst r1,r1
    if (!c.t) { goto L_060932C2; }  // 060932BC bf 0x060932C2
    goto L_060932D6;  // 060932BE bra 0x060932D6 ; nop
L_060932C2:
    c.r[2] = ld32(c.r[14] + 4);  // 060932C2 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060932C4 mov r2,r1
    c.r[1] += 1;  // 060932C6 add #1,r1
    c.r[2] = c.r[1];  // 060932C8 mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 060932CA mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060932CC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 060932CE mov.l @(8,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 060932D0 mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_060932B8;  // 060932D2 bra 0x060932B8 ; nop
L_060932D6:
    c.r[8] = ld32(0x0609330Cu);  // 060932D6 mov.l 0x0609330C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060932DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060932DCu) return; }  // 060932D8 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 060932DC mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 060932DE mov.l @(12,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060932E0 cmp/pz r1
    if (c.t) { goto L_060932EA; }  // 060932E2 bt 0x060932EA
    c.r[0] = ld32(c.r[14] + 12);  // 060932E4 mov.l @(12,r14),r0
    goto L_060932F0;  // 060932E6 bra 0x060932F0 ; nop
L_060932EA:
    c.r[0] = ld32(c.r[14] + 4);  // 060932EA mov.l @(4,r14),r0
    goto L_060932F0;  // 060932EC bra 0x060932F0 ; nop
L_060932F0:
    c.r[14] += 16;  // 060932F0 add #16,r14
    c.r[15] = c.r[14];  // 060932F2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060932F4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060932F6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060932F8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060932FA rts ; nop
}

void f_06093310(SH2Context& c) {
    ran[2220] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093310 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093312 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093314 sts.l pr,@-r15
    c.r[15] -= 20;  // 06093316 add #-20,r15
    c.r[14] = c.r[15];  // 06093318 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609331A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609331C mov.l r5,@(4,r14)
    c.r[1] = 0x0u;  // 0609331E mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 06093320 mov.l r1,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060933BEu);  // 06093322 mov.w 0x060933BE,r1
    c.r[4] = c.r[1];  // 06093324 mov r1,r4
    c.r[8] = ld32(0x060933C0u);  // 06093326 mov.l 0x060933C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609332Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609332Cu) return; }  // 06093328 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 0609332C mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609332E tst r1,r1
    if (!c.t) { goto L_06093346; }  // 06093330 bf 0x06093346
    c.r[4] = 0xFFFFFFF5u;  // 06093332 mov #-11,r4
    c.r[8] = ld32(0x060933C4u);  // 06093334 mov.l 0x060933C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609333Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609333Au) return; }  // 06093336 jsr @r8 ; nop
    c.r[8] = ld32(0x060933C8u);  // 0609333A mov.l 0x060933C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093340u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093340u) return; }  // 0609333C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06093340 mov #0,r0
    goto L_060933B0;  // 06093342 bra 0x060933B0 ; nop
L_06093346:
    c.r[1] = ld32(c.r[14] + 4);  // 06093346 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093348 cmp/pz r1
    if (c.t) { goto L_06093360; }  // 0609334A bt 0x06093360
    c.r[4] = 0xFFFFFFF2u;  // 0609334C mov #-14,r4
    c.r[8] = ld32(0x060933C4u);  // 0609334E mov.l 0x060933C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093354u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093354u) return; }  // 06093350 jsr @r8 ; nop
    c.r[8] = ld32(0x060933C8u);  // 06093354 mov.l 0x060933C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609335Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609335Au) return; }  // 06093356 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0609335A mov #0,r0
    goto L_060933B0;  // 0609335C bra 0x060933B0 ; nop
L_06093360:
    ;  // 06093360 nop
    c.r[1] = 0x0u;  // 06093362 mov #0,r1
    st32(c.r[14] + 8, c.r[1]);  // 06093364 mov.l r1,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 06093366 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06093368 mov.l @r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 0609336A mov.l r2,@(12,r14)
L_0609336C:
    c.r[1] = ld32(c.r[14] + 8);  // 0609336C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609336E mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06093370 cmp/ge r2,r1
    if (c.t) { goto L_0609337E; }  // 06093372 bt 0x0609337E
    c.r[1] = ld32(c.r[14] + 12);  // 06093374 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093376 tst r1,r1
    if (!c.t) { goto L_06093382; }  // 06093378 bf 0x06093382
    goto L_0609337E;  // 0609337A bra 0x0609337E ; nop
L_0609337E:
    goto L_06093396;  // 0609337E bra 0x06093396 ; nop
L_06093382:
    c.r[2] = ld32(c.r[14] + 8);  // 06093382 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093384 mov r2,r1
    c.r[1] += 1;  // 06093386 add #1,r1
    c.r[2] = c.r[1];  // 06093388 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0609338A mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609338C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 0609338E mov.l @(8,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 06093390 mov.l r2,@(12,r14)
    SH2_POLL(c); goto L_0609336C;  // 06093392 bra 0x0609336C ; nop
L_06093396:
    c.r[8] = ld32(0x060933CCu);  // 06093396 mov.l 0x060933CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609339Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609339Cu) return; }  // 06093398 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0609339C mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0609339E mov.l @(16,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060933A0 cmp/pz r1
    if (c.t) { goto L_060933AA; }  // 060933A2 bt 0x060933AA
    c.r[0] = 0x0u;  // 060933A4 mov #0,r0
    goto L_060933B0;  // 060933A6 bra 0x060933B0 ; nop
L_060933AA:
    c.r[0] = ld32(c.r[14] + 12);  // 060933AA mov.l @(12,r14),r0
    goto L_060933B0;  // 060933AC bra 0x060933B0 ; nop
L_060933B0:
    c.r[14] += 20;  // 060933B0 add #20,r14
    c.r[15] = c.r[14];  // 060933B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060933B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060933B6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060933B8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060933BA rts ; nop
}

void f_060933D0(SH2Context& c) {
    ran[2221] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060933D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060933D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060933D4 sts.l pr,@-r15
    c.r[15] -= 16;  // 060933D6 add #-16,r15
    c.r[14] = c.r[15];  // 060933D8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060933DA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060933DC mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 060933DE mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 060933E0 mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093454u);  // 060933E2 mov.w 0x06093454,r1
    c.r[4] = c.r[1];  // 060933E4 mov r1,r4
    c.r[8] = ld32(0x06093458u);  // 060933E6 mov.l 0x06093458,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060933ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060933ECu) return; }  // 060933E8 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 060933EC mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060933EE tst r1,r1
    if (!c.t) { goto L_06093404; }  // 060933F0 bf 0x06093404
    c.r[4] = 0xFFFFFFF5u;  // 060933F2 mov #-11,r4
    c.r[8] = ld32(0x0609345Cu);  // 060933F4 mov.l 0x0609345C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060933FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060933FAu) return; }  // 060933F6 jsr @r8 ; nop
    c.r[8] = ld32(0x06093460u);  // 060933FA mov.l 0x06093460,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093400u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093400u) return; }  // 060933FC jsr @r8 ; nop
    goto L_06093446;  // 06093400 bra 0x06093446 ; nop
L_06093404:
    c.r[1] = ld32(c.r[14] + 8);  // 06093404 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093406 cmp/pz r1
    if (c.t) { goto L_0609341C; }  // 06093408 bt 0x0609341C
    c.r[4] = 0xFFFFFFF2u;  // 0609340A mov #-14,r4
    c.r[8] = ld32(0x0609345Cu);  // 0609340C mov.l 0x0609345C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093412u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093412u) return; }  // 0609340E jsr @r8 ; nop
    c.r[8] = ld32(0x06093460u);  // 06093412 mov.l 0x06093460,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093418u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093418u) return; }  // 06093414 jsr @r8 ; nop
    goto L_06093446;  // 06093418 bra 0x06093446 ; nop
L_0609341C:
    c.r[1] = ld32(c.r[14] + 4);  // 0609341C mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609341E tst r1,r1
    if (c.t) { goto L_06093428; }  // 06093420 bt 0x06093428
    c.r[1] = ld32(c.r[14] + 4);  // 06093422 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093424 mov.l @(4,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06093426 mov.l r2,@(4,r14)
L_06093428:
    c.r[1] = ld32(c.r[14]);  // 06093428 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609342A mov.l @(4,r14),r2
    st32(c.r[1] + 28, c.r[2]);  // 0609342C mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14]);  // 0609342E mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06093430 mov.l @(8,r14),r2
    st32(c.r[1] + 32, c.r[2]);  // 06093432 mov.l r2,@(32,r1)
    c.r[1] = ld32(c.r[14]);  // 06093434 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 12);  // 06093436 mov.l @(12,r14),r2
    st32(c.r[1] + 36, c.r[2]);  // 06093438 mov.l r2,@(36,r1)
    c.r[1] = ld32(c.r[14]);  // 0609343A mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 28);  // 0609343C mov.l @(28,r14),r2
    st32(c.r[1] + 40, c.r[2]);  // 0609343E mov.l r2,@(40,r1)
    c.r[8] = ld32(0x06093464u);  // 06093440 mov.l 0x06093464,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093446u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093446u) return; }  // 06093442 jsr @r8 ; nop
L_06093446:
    c.r[14] += 16;  // 06093446 add #16,r14
    c.r[15] = c.r[14];  // 06093448 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609344A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609344C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609344E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093450 rts ; nop
}

void f_06093468(SH2Context& c) {
    ran[2222] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093468 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609346A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609346C sts.l pr,@-r15
    c.r[15] -= 36;  // 0609346E add #-36,r15
    c.r[14] = c.r[15];  // 06093470 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093472 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093474 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06093476 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06093478 mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060935A4u);  // 0609347A mov.w 0x060935A4,r1
    c.r[4] = c.r[1];  // 0609347C mov r1,r4
    c.r[8] = ld32(0x060935A8u);  // 0609347E mov.l 0x060935A8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093484u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093484u) return; }  // 06093480 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093484 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093486 tst r1,r1
    if (!c.t) { goto L_0609349E; }  // 06093488 bf 0x0609349E
    c.r[4] = 0xFFFFFFF5u;  // 0609348A mov #-11,r4
    c.r[8] = ld32(0x060935ACu);  // 0609348C mov.l 0x060935AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093492u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093492u) return; }  // 0609348E jsr @r8 ; nop
    c.r[8] = ld32(0x060935B0u);  // 06093492 mov.l 0x060935B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093498u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093498u) return; }  // 06093494 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06093498 mov #0,r0
    goto L_06093638;  // 0609349A bra 0x06093638 ; nop
L_0609349E:
    c.r[1] = ld32(c.r[14]);  // 0609349E mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060934A0 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 060934A2 mov.l r2,@r14
    c.r[1] = c.r[14];  // 060934A4 mov r14,r1
    c.r[1] += 16;  // 060934A6 add #16,r1
    c.r[2] = ld32(c.r[14] + 8);  // 060934A8 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 060934AA mov.l @(4,r14),r3
    c.r[7] = ld32(c.r[14]);  // 060934AC mov.l @r14,r7
    c.r[4] = ld32(c.r[7] + 20);  // 060934AE mov.l @(20,r7),r4
    c.r[7] = 0x0u;  // 060934B0 mov #0,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060934B2 mov.l r7,@-r15
    c.r[7] = 0x0u;  // 060934B4 mov #0,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060934B6 mov.l r7,@-r15
    c.r[7] = 0x0u;  // 060934B8 mov #0,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060934BA mov.l r7,@-r15
    c.r[6] = ld32(c.r[14] + 8);  // 060934BC mov.l @(8,r14),r6
    c.r[7] = c.r[6];  // 060934BE mov r6,r7
    c.r[7] += 4;  // 060934C0 add #4,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060934C2 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 060934C4 mov r1,r7
    c.r[6] = c.r[2];  // 060934C6 mov r2,r6
    c.r[5] = c.r[3];  // 060934C8 mov r3,r5
    c.r[8] = ld32(0x060935B4u);  // 060934CA mov.l 0x060935B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060934D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060934D0u) return; }  // 060934CC jsr @r8 ; nop
    c.r[15] += 16;  // 060934D0 add #16,r15
    c.r[1] = ld32(c.r[14] + 4);  // 060934D2 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060934D4 mov.l @r1,r2
    c.r[1] = ld32(0x060935B8u);  // 060934D6 mov.l 0x060935B8,r1
    c.t = c.r[2] == c.r[1];  // 060934D8 cmp/eq r1,r2
    if (!c.t) { goto L_060934E2; }  // 060934DA bf 0x060934E2
    c.r[1] = ld32(c.r[14] + 4);  // 060934DC mov.l @(4,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 060934DE mov #-1,r2
    st32(c.r[1], c.r[2]);  // 060934E0 mov.l r2,@r1
L_060934E2:
    c.r[1] = ld32(c.r[14]);  // 060934E2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 060934E4 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 060934E6 mov r2,r1
    c.r[1] += 28;  // 060934E8 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 060934EA mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060934EC tst r2,r2
    if (c.t) { goto L_060934F4; }  // 060934EE bt 0x060934F4
    goto L_060935C0;  // 060934F0 bra 0x060935C0 ; nop
L_060934F4:
    c.r[1] = ld32(c.r[14] + 12);  // 060934F4 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14]);  // 060934F6 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 20);  // 060934F8 mov.l @(20,r2),r3
    c.r[2] = c.r[3];  // 060934FA mov r3,r2
    c.r[2] += 28;  // 060934FC add #28,r2
    c.r[3] = ld32(c.r[2] + 4);  // 060934FE mov.l @(4,r2),r3
    st32(c.r[1], c.r[3]);  // 06093500 mov.l r3,@r1
    c.r[1] = ld32(c.r[14]);  // 06093502 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06093504 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06093506 mov r2,r1
    c.r[1] += 28;  // 06093508 add #28,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0609350A mov.l @(12,r1),r2
    st32(c.r[14] + 24, c.r[2]);  // 0609350C mov.l r2,@(24,r14)
    c.r[1] = c.r[14];  // 0609350E mov r14,r1
    c.r[1] += 28;  // 06093510 add #28,r1
    c.r[2] = c.r[14];  // 06093512 mov r14,r2
    c.r[2] += 20;  // 06093514 add #20,r2
    c.r[3] = ld32(c.r[14] + 24);  // 06093516 mov.l @(24,r14),r3
    c.r[6] = c.r[1];  // 06093518 mov r1,r6
    c.r[5] = c.r[2];  // 0609351A mov r2,r5
    c.r[4] = c.r[3];  // 0609351C mov r3,r4
    c.r[8] = ld32(0x060935BCu);  // 0609351E mov.l 0x060935BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093524u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093524u) return; }  // 06093520 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 48);  // 06093524 mov.l @(48,r14),r1
    c.r[2] = c.r[14];  // 06093526 mov r14,r2
    c.r[3] = c.r[14];  // 06093528 mov r14,r3
    c.r[3] += 28;  // 0609352A add #28,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609352C mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 0609352E extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 06093530 mov.w r3,@r1
    c.r[1] = ld32(c.r[14] + 48);  // 06093532 mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 06093534 mov r1,r2
    c.r[1] += 2;  // 06093536 add #2,r1
    c.r[2] = c.r[14];  // 06093538 mov r14,r2
    c.r[3] = c.r[14];  // 0609353A mov r14,r3
    c.r[3] += 28;  // 0609353C add #28,r3
    c.r[2] = c.r[3];  // 0609353E mov r3,r2
    c.r[3] += 1;  // 06093540 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06093542 mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 06093544 extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 06093546 mov.w r3,@r1
    c.r[1] = ld32(c.r[14] + 48);  // 06093548 mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 0609354A mov r1,r2
    c.r[1] += 4;  // 0609354C add #4,r1
    c.r[2] = c.r[14];  // 0609354E mov r14,r2
    c.r[3] = c.r[14];  // 06093550 mov r14,r3
    c.r[3] += 28;  // 06093552 add #28,r3
    c.r[2] = c.r[3];  // 06093554 mov r3,r2
    c.r[3] += 2;  // 06093556 add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06093558 mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 0609355A extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 0609355C mov.w r3,@r1
    c.r[1] = ld32(c.r[14] + 48);  // 0609355E mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 06093560 mov r1,r2
    c.r[1] += 6;  // 06093562 add #6,r1
    c.r[2] = c.r[14];  // 06093564 mov r14,r2
    c.r[3] = c.r[14];  // 06093566 mov r14,r3
    c.r[3] += 28;  // 06093568 add #28,r3
    c.r[2] = c.r[3];  // 0609356A mov r3,r2
    c.r[3] += 3;  // 0609356C add #3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609356E mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 06093570 extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 06093572 mov.w r3,@r1
    c.r[1] = ld32(c.r[14] + 48);  // 06093574 mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 06093576 mov r1,r2
    c.r[1] += 8;  // 06093578 add #8,r1
    c.r[2] = c.r[14];  // 0609357A mov r14,r2
    c.r[3] = c.r[14];  // 0609357C mov r14,r3
    c.r[3] += 28;  // 0609357E add #28,r3
    c.r[2] = c.r[3];  // 06093580 mov r3,r2
    c.r[3] += 4;  // 06093582 add #4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06093584 mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 06093586 extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 06093588 mov.w r3,@r1
    c.r[1] = ld32(c.r[14] + 48);  // 0609358A mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 0609358C mov r1,r2
    c.r[1] += 10;  // 0609358E add #10,r1
    c.r[2] = c.r[14];  // 06093590 mov r14,r2
    c.r[3] = c.r[14];  // 06093592 mov r14,r3
    c.r[3] += 28;  // 06093594 add #28,r3
    c.r[2] = c.r[3];  // 06093596 mov r3,r2
    c.r[3] += 5;  // 06093598 add #5,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609359A mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 0609359C extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 0609359E mov.w r3,@r1
    goto L_060935CA;  // 060935A0 bra 0x060935CA ; nop
L_060935C0:
    c.r[1] = 0x0u;  // 060935C0 mov #0,r1
    st32(c.r[14] + 20, c.r[1]);  // 060935C2 mov.l r1,@(20,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 060935C4 mov.l @(12,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 060935C6 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 060935C8 mov.l r2,@r1
L_060935CA:
    c.r[2] = ld32(c.r[14] + 20);  // 060935CA mov.l @(20,r14),r2
    c.r[1] = 0x1u;  // 060935CC mov #1,r1
    c.r[1] &= c.r[2];  // 060935CE and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060935D0 tst r1,r1
    if (!c.t) { goto L_060935DA; }  // 060935D2 bf 0x060935DA
    c.r[1] = ld32(c.r[14] + 48);  // 060935D4 mov.l @(48,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 060935D6 mov #-1,r2
    st16(c.r[1], c.r[2]);  // 060935D8 mov.w r2,@r1
L_060935DA:
    c.r[2] = ld32(c.r[14] + 20);  // 060935DA mov.l @(20,r14),r2
    c.r[1] = 0x2u;  // 060935DC mov #2,r1
    c.r[1] &= c.r[2];  // 060935DE and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060935E0 tst r1,r1
    if (!c.t) { goto L_060935EE; }  // 060935E2 bf 0x060935EE
    c.r[2] = ld32(c.r[14] + 48);  // 060935E4 mov.l @(48,r14),r2
    c.r[1] = c.r[2];  // 060935E6 mov r2,r1
    c.r[2] += 2;  // 060935E8 add #2,r2
    c.r[1] = 0xFFFFFFFFu;  // 060935EA mov #-1,r1
    st16(c.r[2], c.r[1]);  // 060935EC mov.w r1,@r2
L_060935EE:
    c.r[2] = ld32(c.r[14] + 20);  // 060935EE mov.l @(20,r14),r2
    c.r[1] = 0x4u;  // 060935F0 mov #4,r1
    c.r[1] &= c.r[2];  // 060935F2 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060935F4 tst r1,r1
    if (!c.t) { goto L_0609360C; }  // 060935F6 bf 0x0609360C
    c.r[1] = ld32(c.r[14] + 48);  // 060935F8 mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 060935FA mov r1,r2
    c.r[1] += 4;  // 060935FC add #4,r1
    c.r[3] = ld32(c.r[14] + 48);  // 060935FE mov.l @(48,r14),r3
    c.r[2] = c.r[3];  // 06093600 mov r3,r2
    c.r[3] += 6;  // 06093602 add #6,r3
    c.r[2] = 0xFFFFFFFFu;  // 06093604 mov #-1,r2
    st16(c.r[3], c.r[2]);  // 06093606 mov.w r2,@r3
    c.r[2] = 0xFFFFFFFFu;  // 06093608 mov #-1,r2
    st16(c.r[1], c.r[2]);  // 0609360A mov.w r2,@r1
L_0609360C:
    c.r[2] = ld32(c.r[14] + 20);  // 0609360C mov.l @(20,r14),r2
    c.r[1] = 0x8u;  // 0609360E mov #8,r1
    c.r[1] &= c.r[2];  // 06093610 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093612 tst r1,r1
    if (!c.t) { goto L_0609362A; }  // 06093614 bf 0x0609362A
    c.r[1] = ld32(c.r[14] + 48);  // 06093616 mov.l @(48,r14),r1
    c.r[2] = c.r[1];  // 06093618 mov r1,r2
    c.r[1] += 8;  // 0609361A add #8,r1
    c.r[3] = ld32(c.r[14] + 48);  // 0609361C mov.l @(48,r14),r3
    c.r[2] = c.r[3];  // 0609361E mov r3,r2
    c.r[3] += 10;  // 06093620 add #10,r3
    c.r[2] = 0xFFFFFFFFu;  // 06093622 mov #-1,r2
    st16(c.r[3], c.r[2]);  // 06093624 mov.w r2,@r3
    c.r[2] = 0xFFFFFFFFu;  // 06093626 mov #-1,r2
    st16(c.r[1], c.r[2]);  // 06093628 mov.w r2,@r1
L_0609362A:
    c.r[8] = ld32(0x06093648u);  // 0609362A mov.l 0x06093648,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093630u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093630u) return; }  // 0609362C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093630 mov.l @r14,r1
    c.r[0] = ld32(c.r[1]);  // 06093632 mov.l @r1,r0
    goto L_06093638;  // 06093634 bra 0x06093638 ; nop
L_06093638:
    c.r[14] += 36;  // 06093638 add #36,r14
    c.r[15] = c.r[14];  // 0609363A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609363C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609363E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093640 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093642 rts ; nop
}

void f_0609364C(SH2Context& c) {
    ran[2223] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609364C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609364E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093650 sts.l pr,@-r15
    c.r[15] -= 16;  // 06093652 add #-16,r15
    c.r[14] = c.r[15];  // 06093654 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093656 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093658 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060936F2u);  // 0609365A mov.w 0x060936F2,r1
    c.r[4] = c.r[1];  // 0609365C mov r1,r4
    c.r[8] = ld32(0x060936F8u);  // 0609365E mov.l 0x060936F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093664u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093664u) return; }  // 06093660 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093664 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093666 tst r1,r1
    if (!c.t) { goto L_0609367C; }  // 06093668 bf 0x0609367C
    c.r[4] = 0xFFFFFFF5u;  // 0609366A mov #-11,r4
    c.r[8] = ld32(0x060936FCu);  // 0609366C mov.l 0x060936FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093672u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093672u) return; }  // 0609366E jsr @r8 ; nop
    c.r[8] = ld32(0x06093700u);  // 06093672 mov.l 0x06093700,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093678u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093678u) return; }  // 06093674 jsr @r8 ; nop
    goto L_060936E4;  // 06093678 bra 0x060936E4 ; nop
L_0609367C:
    c.r[1] = ld32(c.r[14]);  // 0609367C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609367E mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093680 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 06093682 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093684 tst r1,r1
    if (!c.t) { goto L_06093690; }  // 06093686 bf 0x06093690
    c.r[1] = (uint32_t)(int16_t)ld16(0x060936F4u);  // 06093688 mov.w 0x060936F4,r1
    st32(c.r[14] + 8, c.r[1]);  // 0609368A mov.l r1,@(8,r14)
    goto L_060936A2;  // 0609368C bra 0x060936A2 ; nop
L_06093690:
    c.r[1] = ld32(c.r[14] + 4);  // 06093690 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093692 mov.l @(4,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06093694 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06093696 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06093698 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 0609369A mov r2,r1
    c.r[1] += 28;  // 0609369C add #28,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609369E mov.l @(4,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 060936A0 mov.l r2,@(8,r14)
L_060936A2:
    c.r[1] = ld32(c.r[14]);  // 060936A2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 060936A4 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 060936A6 mov r2,r1
    c.r[1] += 28;  // 060936A8 add #28,r1
    c.r[2] = ld32(c.r[14] + 8);  // 060936AA mov.l @(8,r14),r2
    st32(c.r[1] + 4, c.r[2]);  // 060936AC mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 060936AE mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 060936B0 mov.l @r14,r2
    c.r[7] = ld32(c.r[2] + 20);  // 060936B2 mov.l @(20,r2),r7
    c.r[3] = c.r[7];  // 060936B4 mov r7,r3
    c.r[3] += 28;  // 060936B6 add #28,r3
    c.r[2] = ld32(c.r[3] + 12);  // 060936B8 mov.l @(12,r3),r2
    c.r[6] = 0xFFFFFFFEu;  // 060936BA mov #-2,r6
    c.r[5] = c.r[1];  // 060936BC mov r1,r5
    c.r[4] = c.r[2];  // 060936BE mov r2,r4
    c.r[8] = ld32(0x06093704u);  // 060936C0 mov.l 0x06093704,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060936C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060936C6u) return; }  // 060936C2 jsr @r8 ; nop
    c.r[8] = ld32(0x06093708u);  // 060936C6 mov.l 0x06093708,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060936CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060936CCu) return; }  // 060936C8 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 060936CC mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 060936CE mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060936D0 tst r1,r1
    if (c.t) { goto L_060936E4; }  // 060936D2 bt 0x060936E4
    c.r[1] = ld32(c.r[14] + 12);  // 060936D4 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 060936D6 mov r1,r4
    c.r[8] = ld32(0x0609370Cu);  // 060936D8 mov.l 0x0609370C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060936DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060936DEu) return; }  // 060936DA jsr @r8 ; nop
    c.r[8] = ld32(0x06093700u);  // 060936DE mov.l 0x06093700,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060936E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060936E4u) return; }  // 060936E0 jsr @r8 ; nop
L_060936E4:
    c.r[14] += 16;  // 060936E4 add #16,r14
    c.r[15] = c.r[14];  // 060936E6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060936E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060936EA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060936EC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060936EE rts ; nop
}

void f_06093710(SH2Context& c) {
    ran[2224] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093710 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093712 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093714 sts.l pr,@-r15
    c.r[15] -= 20;  // 06093716 add #-20,r15
    c.r[14] = c.r[15];  // 06093718 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609371A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609371C mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609371E mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06093720 mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060937E0u);  // 06093722 mov.w 0x060937E0,r1
    c.r[4] = c.r[1];  // 06093724 mov r1,r4
    c.r[8] = ld32(0x060937E4u);  // 06093726 mov.l 0x060937E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609372Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609372Cu) return; }  // 06093728 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 0609372C mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609372E tst r1,r1
    if (c.t) { goto L_0609373C; }  // 06093730 bt 0x0609373C
    c.r[1] = ld32(c.r[14] + 12);  // 06093732 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093734 tst r1,r1
    if (!c.t) { goto L_0609374E; }  // 06093736 bf 0x0609374E
    goto L_0609373C;  // 06093738 bra 0x0609373C ; nop
L_0609373C:
    c.r[4] = 0xFFFFFFF5u;  // 0609373C mov #-11,r4
    c.r[8] = ld32(0x060937E8u);  // 0609373E mov.l 0x060937E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093744u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093744u) return; }  // 06093740 jsr @r8 ; nop
    c.r[8] = ld32(0x060937ECu);  // 06093744 mov.l 0x060937EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609374Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609374Au) return; }  // 06093746 jsr @r8 ; nop
    goto L_060937D2;  // 0609374A bra 0x060937D2 ; nop
L_0609374E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609374E mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093750 cmp/pz r1
    if (!c.t) { goto L_0609375E; }  // 06093752 bf 0x0609375E
    c.r[1] = ld32(c.r[14] + 8);  // 06093754 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093756 cmp/pz r1
    if (!c.t) { goto L_0609375E; }  // 06093758 bf 0x0609375E
    goto L_06093770;  // 0609375A bra 0x06093770 ; nop
L_0609375E:
    c.r[4] = 0xFFFFFFF2u;  // 0609375E mov #-14,r4
    c.r[8] = ld32(0x060937E8u);  // 06093760 mov.l 0x060937E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093766u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093766u) return; }  // 06093762 jsr @r8 ; nop
    c.r[8] = ld32(0x060937ECu);  // 06093766 mov.l 0x060937EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609376Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609376Cu) return; }  // 06093768 jsr @r8 ; nop
    goto L_060937D2;  // 0609376C bra 0x060937D2 ; nop
L_06093770:
    c.r[1] = ld32(c.r[14]);  // 06093770 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093772 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093774 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 12);  // 06093776 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093778 mov.l @(4,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 0609377A mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609377C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609377E mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14]);  // 06093780 mov.l @r14,r3
    c.r[6] = ld32(c.r[3] + 20);  // 06093782 mov.l @(20,r3),r6
    c.r[7] = c.r[6];  // 06093784 mov r6,r7
    c.r[7] += 28;  // 06093786 add #28,r7
    c.r[3] = ld32(c.r[7] + 4);  // 06093788 mov.l @(4,r7),r3
    c.r[7] = ld32(c.r[14] + 12);  // 0609378A mov.l @(12,r14),r7
    c.r[6] = ld32(c.r[7] + 20);  // 0609378C mov.l @(20,r7),r6
    c.r[7] = c.r[6];  // 0609378E mov r6,r7
    c.r[7] += 28;  // 06093790 add #28,r7
    c.r[4] = ld32(c.r[7] + 4);  // 06093792 mov.l @(4,r7),r4
    c.r[7] = c.r[1];  // 06093794 mov r1,r7
    c.r[6] = c.r[2];  // 06093796 mov r2,r6
    c.r[5] = c.r[3];  // 06093798 mov r3,r5
    c.r[8] = ld32(0x060937F0u);  // 0609379A mov.l 0x060937F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060937A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060937A0u) return; }  // 0609379C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 060937A0 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 060937A2 mov r1,r2
    c.r[1] += 44;  // 060937A4 add #44,r1
    c.r[3] = ld32(c.r[14] + 12);  // 060937A6 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 060937A8 mov r3,r2
    c.r[3] += 44;  // 060937AA add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060937AC mov.b @r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060937E2u);  // 060937AE mov.w 0x060937E2,r3
    c.r[3] &= c.r[2];  // 060937B0 and r2,r3
    st8(c.r[1], c.r[3]);  // 060937B2 mov.b r3,@r1
    c.r[8] = ld32(0x060937F4u);  // 060937B4 mov.l 0x060937F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060937BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060937BAu) return; }  // 060937B6 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 060937BA mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 060937BC mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060937BE tst r1,r1
    if (c.t) { goto L_060937D2; }  // 060937C0 bt 0x060937D2
    c.r[1] = ld32(c.r[14] + 16);  // 060937C2 mov.l @(16,r14),r1
    c.r[4] = c.r[1];  // 060937C4 mov r1,r4
    c.r[8] = ld32(0x060937F8u);  // 060937C6 mov.l 0x060937F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060937CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060937CCu) return; }  // 060937C8 jsr @r8 ; nop
    c.r[8] = ld32(0x060937ECu);  // 060937CC mov.l 0x060937EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060937D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060937D2u) return; }  // 060937CE jsr @r8 ; nop
L_060937D2:
    c.r[14] += 20;  // 060937D2 add #20,r14
    c.r[15] = c.r[14];  // 060937D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060937D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060937D8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060937DA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060937DC rts ; nop
}

void f_060937FC(SH2Context& c) {
    ran[2225] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060937FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060937FE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093800 sts.l pr,@-r15
    c.r[15] -= 16;  // 06093802 add #-16,r15
    c.r[14] = c.r[15];  // 06093804 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093806 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093808 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609380A mov.l r6,@(8,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060938D8u);  // 0609380C mov.w 0x060938D8,r1
    c.r[4] = c.r[1];  // 0609380E mov r1,r4
    c.r[8] = ld32(0x060938DCu);  // 06093810 mov.l 0x060938DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093816u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093816u) return; }  // 06093812 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093816 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093818 tst r1,r1
    if (!c.t) { goto L_0609382E; }  // 0609381A bf 0x0609382E
    c.r[4] = 0xFFFFFFF5u;  // 0609381C mov #-11,r4
    c.r[8] = ld32(0x060938E0u);  // 0609381E mov.l 0x060938E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093824u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093824u) return; }  // 06093820 jsr @r8 ; nop
    c.r[8] = ld32(0x060938E4u);  // 06093824 mov.l 0x060938E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609382Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609382Au) return; }  // 06093826 jsr @r8 ; nop
    goto L_060938CA;  // 0609382A bra 0x060938CA ; nop
L_0609382E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609382E mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093830 cmp/pz r1
    if (!c.t) { goto L_0609383E; }  // 06093832 bf 0x0609383E
    c.r[1] = ld32(c.r[14] + 8);  // 06093834 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093836 cmp/pz r1
    if (!c.t) { goto L_0609383E; }  // 06093838 bf 0x0609383E
    goto L_06093850;  // 0609383A bra 0x06093850 ; nop
L_0609383E:
    c.r[4] = 0xFFFFFFF2u;  // 0609383E mov #-14,r4
    c.r[8] = ld32(0x060938E0u);  // 06093840 mov.l 0x060938E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093846u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093846u) return; }  // 06093842 jsr @r8 ; nop
    c.r[8] = ld32(0x060938E4u);  // 06093846 mov.l 0x060938E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609384Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609384Cu) return; }  // 06093848 jsr @r8 ; nop
    goto L_060938CA;  // 0609384C bra 0x060938CA ; nop
L_06093850:
    c.r[1] = ld32(c.r[14]);  // 06093850 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093852 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093854 mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 06093856 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06093858 mov.l @(16,r1),r2
    c.r[5] = 0x0u;  // 0609385A mov #0,r5
    c.r[4] = c.r[2];  // 0609385C mov r2,r4
    c.r[8] = ld32(0x060938E8u);  // 0609385E mov.l 0x060938E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093864u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093864u) return; }  // 06093860 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093864 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06093866 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06093868 mov r2,r1
    c.r[1] += 108;  // 0609386A add #108,r1
    c.r[2] = 0x0u;  // 0609386C mov #0,r2
    st32(c.r[1] + 52, c.r[2]);  // 0609386E mov.l r2,@(52,r1)
    c.r[1] = ld32(c.r[14]);  // 06093870 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06093872 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06093874 mov r2,r1
    c.r[1] += 28;  // 06093876 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06093878 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609387A tst r2,r2
    if (!c.t) { goto L_060938B4; }  // 0609387C bf 0x060938B4
    c.r[1] = ld32(c.r[14] + 8);  // 0609387E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093880 mov.l @(4,r14),r2
    c.r[7] = ld32(c.r[14]);  // 06093882 mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 20);  // 06093884 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06093886 mov r1,r6
    c.r[5] = c.r[2];  // 06093888 mov r2,r5
    c.r[4] = c.r[3];  // 0609388A mov r3,r4
    c.r[8] = ld32(0x060938ECu);  // 0609388C mov.l 0x060938EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093892u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093892u) return; }  // 0609388E jsr @r8 ; nop
    c.r[8] = ld32(0x060938F0u);  // 06093892 mov.l 0x060938F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093898u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093898u) return; }  // 06093894 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06093898 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609389A mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609389C tst r1,r1
    if (c.t) { goto L_060938B0; }  // 0609389E bt 0x060938B0
    c.r[1] = ld32(c.r[14] + 12);  // 060938A0 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 060938A2 mov r1,r4
    c.r[8] = ld32(0x060938F4u);  // 060938A4 mov.l 0x060938F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060938AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060938AAu) return; }  // 060938A6 jsr @r8 ; nop
    c.r[8] = ld32(0x060938E4u);  // 060938AA mov.l 0x060938E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060938B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060938B0u) return; }  // 060938AC jsr @r8 ; nop
L_060938B0:
    goto L_060938CA;  // 060938B0 bra 0x060938CA ; nop
L_060938B4:
    c.r[2] = ld32(c.r[14]);  // 060938B4 mov.l @r14,r2
    c.r[1] = ld32(c.r[2] + 16);  // 060938B6 mov.l @(16,r2),r1
    c.r[6] = 0x0u;  // 060938B8 mov #0,r6
    c.r[5] = 0x0u;  // 060938BA mov #0,r5
    c.r[4] = c.r[1];  // 060938BC mov r1,r4
    c.r[8] = ld32(0x060938F8u);  // 060938BE mov.l 0x060938F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060938C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060938C4u) return; }  // 060938C0 jsr @r8 ; nop
    c.r[8] = ld32(0x060938FCu);  // 060938C4 mov.l 0x060938FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060938CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060938CAu) return; }  // 060938C6 jsr @r8 ; nop
L_060938CA:
    c.r[14] += 16;  // 060938CA add #16,r14
    c.r[15] = c.r[14];  // 060938CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060938CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060938D0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060938D2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060938D4 rts ; nop
}

void f_06093900(SH2Context& c) {
    ran[2226] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093900 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093902 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093904 sts.l pr,@-r15
    c.r[15] -= 16;  // 06093906 add #-16,r15
    c.r[14] = c.r[15];  // 06093908 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609390A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609390C mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093996u);  // 0609390E mov.w 0x06093996,r1
    c.r[4] = c.r[1];  // 06093910 mov r1,r4
    c.r[8] = ld32(0x06093998u);  // 06093912 mov.l 0x06093998,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093918u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093918u) return; }  // 06093914 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093918 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609391A tst r1,r1
    if (!c.t) { goto L_06093932; }  // 0609391C bf 0x06093932
    c.r[4] = 0xFFFFFFF5u;  // 0609391E mov #-11,r4
    c.r[8] = ld32(0x0609399Cu);  // 06093920 mov.l 0x0609399C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093926u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093926u) return; }  // 06093922 jsr @r8 ; nop
    c.r[8] = ld32(0x060939A0u);  // 06093926 mov.l 0x060939A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609392Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609392Cu) return; }  // 06093928 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF5u;  // 0609392C mov #-11,r0
    goto L_06093988;  // 0609392E bra 0x06093988 ; nop
L_06093932:
    c.r[1] = ld32(c.r[14] + 4);  // 06093932 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093934 cmp/pz r1
    if (c.t) { goto L_0609394C; }  // 06093936 bt 0x0609394C
    c.r[4] = 0xFFFFFFF2u;  // 06093938 mov #-14,r4
    c.r[8] = ld32(0x0609399Cu);  // 0609393A mov.l 0x0609399C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093940u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093940u) return; }  // 0609393C jsr @r8 ; nop
    c.r[8] = ld32(0x060939A0u);  // 06093940 mov.l 0x060939A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093946u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093946u) return; }  // 06093942 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF2u;  // 06093946 mov #-14,r0
    goto L_06093988;  // 06093948 bra 0x06093988 ; nop
L_0609394C:
    c.r[1] = ld32(c.r[14]);  // 0609394C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609394E mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093950 mov.l r2,@r14
    c.r[1] = c.r[14];  // 06093952 mov r14,r1
    c.r[1] += 8;  // 06093954 add #8,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093956 mov.l @(4,r14),r2
    c.r[7] = ld32(c.r[14]);  // 06093958 mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 16);  // 0609395A mov.l @(16,r7),r3
    c.r[6] = c.r[1];  // 0609395C mov r1,r6
    c.r[5] = c.r[2];  // 0609395E mov r2,r5
    c.r[4] = c.r[3];  // 06093960 mov r3,r4
    c.r[8] = ld32(0x060939A4u);  // 06093962 mov.l 0x060939A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093968u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093968u) return; }  // 06093964 jsr @r8 ; nop
    c.r[8] = ld32(0x060939A8u);  // 06093968 mov.l 0x060939A8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609396Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609396Eu) return; }  // 0609396A jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609396E mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 06093970 mov.l @(12,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093972 cmp/pz r1
    if (c.t) { goto L_0609397C; }  // 06093974 bt 0x0609397C
    c.r[0] = ld32(c.r[14] + 12);  // 06093976 mov.l @(12,r14),r0
    goto L_06093988;  // 06093978 bra 0x06093988 ; nop
L_0609397C:
    c.r[2] = ld32(c.r[14] + 8);  // 0609397C mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0609397E mov r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06093980 shlr r1
    c.r[0] = c.r[1];  // 06093982 mov r1,r0
    goto L_06093988;  // 06093984 bra 0x06093988 ; nop
L_06093988:
    c.r[14] += 16;  // 06093988 add #16,r14
    c.r[15] = c.r[14];  // 0609398A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609398C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609398E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093990 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093992 rts ; nop
}

void f_060939AC(SH2Context& c) {
    ran[2227] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060939AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060939AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060939B0 sts.l pr,@-r15
    c.r[15] -= 24;  // 060939B2 add #-24,r15
    c.r[14] = c.r[15];  // 060939B4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060939B6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060939B8 mov.l r5,@(4,r14)
    c.r[1] = 0x0u;  // 060939BA mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 060939BC mov.l r1,@(16,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093ACEu);  // 060939BE mov.w 0x06093ACE,r1
    c.r[4] = c.r[1];  // 060939C0 mov r1,r4
    c.r[8] = ld32(0x06093AD0u);  // 060939C2 mov.l 0x06093AD0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060939C8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060939C8u) return; }  // 060939C4 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 060939C8 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060939CA tst r1,r1
    if (!c.t) { goto L_060939E2; }  // 060939CC bf 0x060939E2
    c.r[4] = 0xFFFFFFF5u;  // 060939CE mov #-11,r4
    c.r[8] = ld32(0x06093AD4u);  // 060939D0 mov.l 0x06093AD4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060939D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060939D6u) return; }  // 060939D2 jsr @r8 ; nop
    c.r[8] = ld32(0x06093AD8u);  // 060939D6 mov.l 0x06093AD8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060939DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060939DCu) return; }  // 060939D8 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF5u;  // 060939DC mov #-11,r0
    goto L_06093B14;  // 060939DE bra 0x06093B14 ; nop
L_060939E2:
    c.r[1] = ld32(c.r[14] + 4);  // 060939E2 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060939E4 cmp/pz r1
    if (c.t) { goto L_060939FC; }  // 060939E6 bt 0x060939FC
    c.r[4] = 0xFFFFFFF2u;  // 060939E8 mov #-14,r4
    c.r[8] = ld32(0x06093AD4u);  // 060939EA mov.l 0x06093AD4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060939F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060939F0u) return; }  // 060939EC jsr @r8 ; nop
    c.r[8] = ld32(0x06093AD8u);  // 060939F0 mov.l 0x06093AD8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060939F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060939F6u) return; }  // 060939F2 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF2u;  // 060939F6 mov #-14,r0
    goto L_06093B14;  // 060939F8 bra 0x06093B14 ; nop
L_060939FC:
    c.r[1] = ld32(c.r[14]);  // 060939FC mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060939FE mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093A00 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 06093A02 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093A04 tst r1,r1
    if (!c.t) { goto L_06093A0E; }  // 06093A06 bf 0x06093A0E
    c.r[0] = 0x0u;  // 06093A08 mov #0,r0
    goto L_06093B14;  // 06093A0A bra 0x06093B14 ; nop
L_06093A0E:
    c.r[1] = ld32(c.r[14]);  // 06093A0E mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06093A10 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06093A12 mov r2,r1
    c.r[1] += 28;  // 06093A14 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06093A16 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06093A18 tst r2,r2
    if (c.t) { goto L_06093A20; }  // 06093A1A bt 0x06093A20
    goto L_06093A84;  // 06093A1C bra 0x06093A84 ; nop
L_06093A20:
    c.r[1] = ld32(0x06093ADCu);  // 06093A20 mov.l 0x06093ADC,r1
    c.r[3] = ld32(c.r[14]);  // 06093A22 mov.l @r14,r3
    c.r[2] = ld32(c.r[3] + 20);  // 06093A24 mov.l @(20,r3),r2
    c.r[6] = 0x0u;  // 06093A26 mov #0,r6
    c.r[5] = c.r[1];  // 06093A28 mov r1,r5
    c.r[4] = c.r[2];  // 06093A2A mov r2,r4
    c.r[8] = ld32(0x06093AE0u);  // 06093A2C mov.l 0x06093AE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093A32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093A32u) return; }  // 06093A2E jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06093A32 mov.l r0,@(12,r14)
    c.r[1] = 0x0u;  // 06093A34 mov #0,r1
    st32(c.r[14] + 8, c.r[1]);  // 06093A36 mov.l r1,@(8,r14)
L_06093A38:
    c.r[1] = ld32(c.r[14] + 8);  // 06093A38 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06093A3A mov.l @(12,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06093A3C cmp/ge r2,r1
    if (!c.t) { goto L_06093A44; }  // 06093A3E bf 0x06093A44
    goto L_06093A80;  // 06093A40 bra 0x06093A80 ; nop
L_06093A44:
    c.r[1] = ld32(c.r[14] + 8);  // 06093A44 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06093A46 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 20);  // 06093A48 mov.l @(20,r2),r3
    c.r[5] = c.r[1];  // 06093A4A mov r1,r5
    c.r[4] = c.r[3];  // 06093A4C mov r3,r4
    c.r[8] = ld32(0x06093AE4u);  // 06093A4E mov.l 0x06093AE4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093A54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093A54u) return; }  // 06093A50 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 06093A54 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 06093A56 mov r1,r2
    c.r[2] += c.r[0];  // 06093A58 add r0,r2
    st32(c.r[14] + 16, c.r[2]);  // 06093A5A mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 06093A5C mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093A5E mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06093A60 cmp/ge r2,r1
    if (!c.t) { goto L_06093A72; }  // 06093A62 bf 0x06093A72
    c.r[2] = ld32(c.r[14] + 8);  // 06093A64 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093A66 mov r2,r1
    c.r[1] += 1;  // 06093A68 add #1,r1
    c.r[2] = c.r[1];  // 06093A6A mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06093A6C mov.l r2,@(8,r14)
    goto L_06093A80;  // 06093A6E bra 0x06093A80 ; nop
L_06093A72:
    c.r[2] = ld32(c.r[14] + 8);  // 06093A72 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093A74 mov r2,r1
    c.r[1] += 1;  // 06093A76 add #1,r1
    c.r[2] = c.r[1];  // 06093A78 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06093A7A mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06093A38;  // 06093A7C bra 0x06093A38 ; nop
L_06093A80:
    goto L_06093AFA;  // 06093A80 bra 0x06093AFA ; nop
L_06093A84:
    c.r[1] = 0x1u;  // 06093A84 mov #1,r1
    st32(c.r[14] + 8, c.r[1]);  // 06093A86 mov.l r1,@(8,r14)
L_06093A88:
    c.r[1] = c.r[14];  // 06093A88 mov r14,r1
    c.r[1] += 16;  // 06093A8A add #16,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06093A8C mov.l @(8,r14),r2
    c.r[7] = ld32(c.r[14]);  // 06093A8E mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 16);  // 06093A90 mov.l @(16,r7),r3
    c.r[6] = c.r[1];  // 06093A92 mov r1,r6
    c.r[5] = c.r[2];  // 06093A94 mov r2,r5
    c.r[4] = c.r[3];  // 06093A96 mov r3,r4
    c.r[8] = ld32(0x06093AE8u);  // 06093A98 mov.l 0x06093AE8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093A9Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093A9Eu) return; }  // 06093A9A jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06093A9E mov.l r0,@(12,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 06093AA0 mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 06093AA2 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06093AA4 shlr r1
    st32(c.r[14] + 16, c.r[1]);  // 06093AA6 mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 06093AA8 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093AAA mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06093AAC cmp/ge r2,r1
    if (!c.t) { goto L_06093AB4; }  // 06093AAE bf 0x06093AB4
    goto L_06093AFA;  // 06093AB0 bra 0x06093AFA ; nop
L_06093AB4:
    c.r[1] = ld32(c.r[14] + 8);  // 06093AB4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06093AB6 mov.l @(12,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06093AB8 cmp/gt r2,r1
    if (c.t) { goto L_06093AC0; }  // 06093ABA bt 0x06093AC0
    goto L_06093AEC;  // 06093ABC bra 0x06093AEC ; nop
L_06093AC0:
    c.r[2] = ld32(c.r[14] + 8);  // 06093AC0 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093AC2 mov r2,r1
    c.r[1] -= 1;  // 06093AC4 add #-1,r1
    c.r[2] = c.r[1];  // 06093AC6 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06093AC8 mov.l r2,@(8,r14)
    goto L_06093AFA;  // 06093ACA bra 0x06093AFA ; nop
L_06093AEC:
    c.r[2] = ld32(c.r[14] + 8);  // 06093AEC mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093AEE mov r2,r1
    c.r[1] += 1;  // 06093AF0 add #1,r1
    c.r[2] = c.r[1];  // 06093AF2 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06093AF4 mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06093A88;  // 06093AF6 bra 0x06093A88 ; nop
L_06093AFA:
    c.r[8] = ld32(0x06093B24u);  // 06093AFA mov.l 0x06093B24,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093B00u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093B00u) return; }  // 06093AFC jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06093B00 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06093B02 mov.l @(20,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093B04 cmp/pz r1
    if (c.t) { goto L_06093B0E; }  // 06093B06 bt 0x06093B0E
    c.r[0] = ld32(c.r[14] + 20);  // 06093B08 mov.l @(20,r14),r0
    goto L_06093B14;  // 06093B0A bra 0x06093B14 ; nop
L_06093B0E:
    c.r[0] = ld32(c.r[14] + 8);  // 06093B0E mov.l @(8,r14),r0
    goto L_06093B14;  // 06093B10 bra 0x06093B14 ; nop
L_06093B14:
    c.r[14] += 24;  // 06093B14 add #24,r14
    c.r[15] = c.r[14];  // 06093B16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093B18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093B1A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093B1C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093B1E rts ; nop
}

void f_06093B28(SH2Context& c) {
    ran[2228] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093B28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093B2A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093B2C sts.l pr,@-r15
    c.r[15] -= 16;  // 06093B2E add #-16,r15
    c.r[14] = c.r[15];  // 06093B30 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093B32 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093B34 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093BEAu);  // 06093B36 mov.w 0x06093BEA,r1
    c.r[4] = c.r[1];  // 06093B38 mov r1,r4
    c.r[8] = ld32(0x06093BECu);  // 06093B3A mov.l 0x06093BEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093B40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093B40u) return; }  // 06093B3C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093B40 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093B42 tst r1,r1
    if (!c.t) { goto L_06093B5A; }  // 06093B44 bf 0x06093B5A
    c.r[4] = 0xFFFFFFF5u;  // 06093B46 mov #-11,r4
    c.r[8] = ld32(0x06093BF0u);  // 06093B48 mov.l 0x06093BF0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093B4Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093B4Eu) return; }  // 06093B4A jsr @r8 ; nop
    c.r[8] = ld32(0x06093BF4u);  // 06093B4E mov.l 0x06093BF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093B54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093B54u) return; }  // 06093B50 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06093B54 mov #0,r0
    goto L_06093BDC;  // 06093B56 bra 0x06093BDC ; nop
L_06093B5A:
    c.r[2] = ld32(c.r[14] + 4);  // 06093B5A mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06093B5C mov r2,r1
    c.r[2] += 45;  // 06093B5E add #45,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06093B60 mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06093B62 extu.b r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093B64 tst r1,r1
    if (!c.t) { goto L_06093B6E; }  // 06093B66 bf 0x06093B6E
    c.r[0] = 0x0u;  // 06093B68 mov #0,r0
    goto L_06093BDC;  // 06093B6A bra 0x06093BDC ; nop
L_06093B6E:
    ;  // 06093B6E nop
    c.r[1] = 0x0u;  // 06093B70 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 06093B72 mov.l r1,@(12,r14)
    c.r[2] = ld32(0x06093BF8u);  // 06093B74 mov.l 0x06093BF8,r2
    c.r[1] = ld32(c.r[2]);  // 06093B76 mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06093B78 mov.l @(8,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06093B7A mov.l r2,@(8,r14)
L_06093B7C:
    c.r[2] = ld32(0x06093BF8u);  // 06093B7C mov.l 0x06093BF8,r2
    c.r[1] = ld32(c.r[2]);  // 06093B7E mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 12);  // 06093B80 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[1] + 12);  // 06093B82 mov.l @(12,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06093B84 cmp/ge r1,r2
    if (!c.t) { goto L_06093B8C; }  // 06093B86 bf 0x06093B8C
    goto L_06093BCA;  // 06093B88 bra 0x06093BCA ; nop
L_06093B8C:
    c.r[2] = ld32(c.r[14] + 8);  // 06093B8C mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093B8E mov r2,r1
    c.r[2] += 45;  // 06093B90 add #45,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06093B92 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06093B94 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06093B96 cmp/eq #1,r0
    if (!c.t) { goto L_06093BB2; }  // 06093B98 bf 0x06093BB2
    c.r[1] = ld32(c.r[14] + 8);  // 06093B9A mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093B9C mov.l @(4,r14),r2
    c.t = c.r[1] == c.r[2];  // 06093B9E cmp/eq r2,r1
    if (c.t) { goto L_06093BB2; }  // 06093BA0 bt 0x06093BB2
    c.r[1] = ld32(c.r[14] + 8);  // 06093BA2 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093BA4 mov.l @(4,r1),r2
    c.r[1] = ld32(c.r[14] + 4);  // 06093BA6 mov.l @(4,r14),r1
    c.t = c.r[2] == c.r[1];  // 06093BA8 cmp/eq r1,r2
    if (!c.t) { goto L_06093BB2; }  // 06093BAA bf 0x06093BB2
    c.r[0] = 0x0u;  // 06093BAC mov #0,r0
    goto L_06093BDC;  // 06093BAE bra 0x06093BDC ; nop
L_06093BB2:
    c.r[2] = ld32(c.r[14] + 12);  // 06093BB2 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 06093BB4 mov r2,r1
    c.r[1] += 1;  // 06093BB6 add #1,r1
    c.r[2] = c.r[1];  // 06093BB8 mov r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 06093BBA mov.l r2,@(12,r14)
    c.r[2] = ld32(c.r[14] + 8);  // 06093BBC mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093BBE mov r2,r1
    c.r[1] += 48;  // 06093BC0 add #48,r1
    c.r[2] = c.r[1];  // 06093BC2 mov r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06093BC4 mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06093B7C;  // 06093BC6 bra 0x06093B7C ; nop
L_06093BCA:
    c.r[1] = ld32(c.r[14]);  // 06093BCA mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093BCC mov.l @(4,r14),r2
    st32(c.r[1] + 4, c.r[2]);  // 06093BCE mov.l r2,@(4,r1)
    c.r[8] = ld32(0x06093BFCu);  // 06093BD0 mov.l 0x06093BFC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093BD6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093BD6u) return; }  // 06093BD2 jsr @r8 ; nop
    c.r[0] = 0x1u;  // 06093BD6 mov #1,r0
    goto L_06093BDC;  // 06093BD8 bra 0x06093BDC ; nop
L_06093BDC:
    c.r[14] += 16;  // 06093BDC add #16,r14
    c.r[15] = c.r[14];  // 06093BDE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093BE0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093BE2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093BE4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093BE6 rts ; nop
}

void f_06093C00(SH2Context& c) {
    ran[2229] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093C00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093C02 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093C04 sts.l pr,@-r15
    c.r[15] -= 4;  // 06093C06 add #-4,r15
    c.r[14] = c.r[15];  // 06093C08 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093C0A mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093C48u);  // 06093C0C mov.w 0x06093C48,r1
    c.r[4] = c.r[1];  // 06093C0E mov r1,r4
    c.r[8] = ld32(0x06093C4Cu);  // 06093C10 mov.l 0x06093C4C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C16u) return; }  // 06093C12 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093C16 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093C18 tst r1,r1
    if (!c.t) { goto L_06093C2E; }  // 06093C1A bf 0x06093C2E
    c.r[4] = 0xFFFFFFF5u;  // 06093C1C mov #-11,r4
    c.r[8] = ld32(0x06093C50u);  // 06093C1E mov.l 0x06093C50,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C24u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C24u) return; }  // 06093C20 jsr @r8 ; nop
    c.r[8] = ld32(0x06093C54u);  // 06093C24 mov.l 0x06093C54,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C2Au) return; }  // 06093C26 jsr @r8 ; nop
    goto L_06093C3A;  // 06093C2A bra 0x06093C3A ; nop
L_06093C2E:
    c.r[1] = ld32(c.r[14]);  // 06093C2E mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06093C30 mov.l @r14,r2
    st32(c.r[1] + 4, c.r[2]);  // 06093C32 mov.l r2,@(4,r1)
    c.r[8] = ld32(0x06093C58u);  // 06093C34 mov.l 0x06093C58,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C3Au) return; }  // 06093C36 jsr @r8 ; nop
L_06093C3A:
    c.r[14] += 4;  // 06093C3A add #4,r14
    c.r[15] = c.r[14];  // 06093C3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093C3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093C40 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093C42 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093C44 rts ; nop
}

void f_06093C5C(SH2Context& c) {
    ran[2230] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093C5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093C5E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093C60 sts.l pr,@-r15
    c.r[15] -= 8;  // 06093C62 add #-8,r15
    c.r[14] = c.r[15];  // 06093C64 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093C66 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093C68 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093CD2u);  // 06093C6A mov.w 0x06093CD2,r1
    c.r[4] = c.r[1];  // 06093C6C mov r1,r4
    c.r[8] = ld32(0x06093CD8u);  // 06093C6E mov.l 0x06093CD8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C74u) return; }  // 06093C70 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093C74 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093C76 tst r1,r1
    if (!c.t) { goto L_06093C8C; }  // 06093C78 bf 0x06093C8C
    c.r[4] = 0xFFFFFFF5u;  // 06093C7A mov #-11,r4
    c.r[8] = ld32(0x06093CDCu);  // 06093C7C mov.l 0x06093CDC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C82u) return; }  // 06093C7E jsr @r8 ; nop
    c.r[8] = ld32(0x06093CE0u);  // 06093C82 mov.l 0x06093CE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093C88u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093C88u) return; }  // 06093C84 jsr @r8 ; nop
    goto L_06093CC4;  // 06093C88 bra 0x06093CC4 ; nop
L_06093C8C:
    c.r[1] = ld32(c.r[14]);  // 06093C8C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093C8E mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093C90 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 06093C92 mov.l @(4,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06093CD4u);  // 06093C94 mov.w 0x06093CD4,r2
    c.t = c.r[1] == c.r[2];  // 06093C96 cmp/eq r2,r1
    if (!c.t) { goto L_06093CAE; }  // 06093C98 bf 0x06093CAE
    c.r[1] = ld32(c.r[14]);  // 06093C9A mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06093C9C mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06093C9E mov r2,r1
    c.r[1] += 108;  // 06093CA0 add #108,r1
    c.r[4] = c.r[1];  // 06093CA2 mov r1,r4
    c.r[8] = ld32(0x06093CE4u);  // 06093CA4 mov.l 0x06093CE4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093CAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093CAAu) return; }  // 06093CA6 jsr @r8 ; nop
    goto L_06093CBE;  // 06093CAA bra 0x06093CBE ; nop
L_06093CAE:
    c.r[1] = ld32(c.r[14]);  // 06093CAE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06093CB0 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06093CB2 mov r2,r1
    c.r[1] += 108;  // 06093CB4 add #108,r1
    c.r[4] = c.r[1];  // 06093CB6 mov r1,r4
    c.r[8] = ld32(0x06093CE8u);  // 06093CB8 mov.l 0x06093CE8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093CBEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093CBEu) return; }  // 06093CBA jsr @r8 ; nop
L_06093CBE:
    c.r[8] = ld32(0x06093CECu);  // 06093CBE mov.l 0x06093CEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093CC4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093CC4u) return; }  // 06093CC0 jsr @r8 ; nop
L_06093CC4:
    c.r[14] += 8;  // 06093CC4 add #8,r14
    c.r[15] = c.r[14];  // 06093CC6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093CC8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093CCA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093CCC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093CCE rts ; nop
}

void f_06093CF0(SH2Context& c) {
    ran[2231] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093CF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093CF2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093CF4 sts.l pr,@-r15
    c.r[15] -= 8;  // 06093CF6 add #-8,r15
    c.r[14] = c.r[15];  // 06093CF8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093CFA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093CFC mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093D66u);  // 06093CFE mov.w 0x06093D66,r1
    c.r[4] = c.r[1];  // 06093D00 mov r1,r4
    c.r[8] = ld32(0x06093D68u);  // 06093D02 mov.l 0x06093D68,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D08u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D08u) return; }  // 06093D04 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093D08 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093D0A tst r1,r1
    if (!c.t) { goto L_06093D20; }  // 06093D0C bf 0x06093D20
    c.r[4] = 0xFFFFFFF5u;  // 06093D0E mov #-11,r4
    c.r[8] = ld32(0x06093D6Cu);  // 06093D10 mov.l 0x06093D6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D16u) return; }  // 06093D12 jsr @r8 ; nop
    c.r[8] = ld32(0x06093D70u);  // 06093D16 mov.l 0x06093D70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D1Cu) return; }  // 06093D18 jsr @r8 ; nop
    goto L_06093D58;  // 06093D1C bra 0x06093D58 ; nop
L_06093D20:
    c.r[1] = ld32(c.r[14] + 4);  // 06093D20 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093D22 cmp/pz r1
    if (c.t) { goto L_06093D38; }  // 06093D24 bt 0x06093D38
    c.r[4] = 0xFFFFFFF2u;  // 06093D26 mov #-14,r4
    c.r[8] = ld32(0x06093D6Cu);  // 06093D28 mov.l 0x06093D6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D2Eu) return; }  // 06093D2A jsr @r8 ; nop
    c.r[8] = ld32(0x06093D70u);  // 06093D2E mov.l 0x06093D70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D34u) return; }  // 06093D30 jsr @r8 ; nop
    goto L_06093D58;  // 06093D34 bra 0x06093D58 ; nop
L_06093D38:
    c.r[1] = ld32(c.r[14]);  // 06093D38 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093D3A mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093D3C mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 06093D3E mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06093D40 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 16);  // 06093D42 mov.l @(16,r2),r3
    c.r[2] = c.r[3];  // 06093D44 mov r3,r2
    c.r[2] += 108;  // 06093D46 add #108,r2
    c.r[5] = c.r[1];  // 06093D48 mov r1,r5
    c.r[4] = c.r[2];  // 06093D4A mov r2,r4
    c.r[8] = ld32(0x06093D74u);  // 06093D4C mov.l 0x06093D74,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D52u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D52u) return; }  // 06093D4E jsr @r8 ; nop
    c.r[8] = ld32(0x06093D78u);  // 06093D52 mov.l 0x06093D78,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D58u) return; }  // 06093D54 jsr @r8 ; nop
L_06093D58:
    c.r[14] += 8;  // 06093D58 add #8,r14
    c.r[15] = c.r[14];  // 06093D5A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093D5C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093D5E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093D60 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093D62 rts ; nop
}

void f_06093D7C(SH2Context& c) {
    ran[2232] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093D7C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093D7E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093D80 sts.l pr,@-r15
    c.r[15] -= 8;  // 06093D82 add #-8,r15
    c.r[14] = c.r[15];  // 06093D84 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093D86 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093D88 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093E04u);  // 06093D8A mov.w 0x06093E04,r1
    c.r[4] = c.r[1];  // 06093D8C mov r1,r4
    c.r[8] = ld32(0x06093E08u);  // 06093D8E mov.l 0x06093E08,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093D94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093D94u) return; }  // 06093D90 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093D94 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093D96 tst r1,r1
    if (!c.t) { goto L_06093DAC; }  // 06093D98 bf 0x06093DAC
    c.r[4] = 0xFFFFFFF5u;  // 06093D9A mov #-11,r4
    c.r[8] = ld32(0x06093E0Cu);  // 06093D9C mov.l 0x06093E0C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093DA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093DA2u) return; }  // 06093D9E jsr @r8 ; nop
    c.r[8] = ld32(0x06093E10u);  // 06093DA2 mov.l 0x06093E10,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093DA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093DA8u) return; }  // 06093DA4 jsr @r8 ; nop
    goto L_06093DF6;  // 06093DA8 bra 0x06093DF6 ; nop
L_06093DAC:
    c.r[1] = ld32(c.r[14] + 4);  // 06093DAC mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093DAE tst r1,r1
    if (c.t) { goto L_06093DD6; }  // 06093DB0 bt 0x06093DD6
    c.r[0] = ld32(c.r[14] + 4);  // 06093DB2 mov.l @(4,r14),r0
    c.t = c.r[0] == 0x1u;  // 06093DB4 cmp/eq #1,r0
    if (c.t) { goto L_06093DD6; }  // 06093DB6 bt 0x06093DD6
    c.r[0] = ld32(c.r[14] + 4);  // 06093DB8 mov.l @(4,r14),r0
    c.t = c.r[0] == 0x2u;  // 06093DBA cmp/eq #2,r0
    if (c.t) { goto L_06093DD6; }  // 06093DBC bt 0x06093DD6
    c.r[0] = ld32(c.r[14] + 4);  // 06093DBE mov.l @(4,r14),r0
    c.t = c.r[0] == 0x3u;  // 06093DC0 cmp/eq #3,r0
    if (c.t) { goto L_06093DD6; }  // 06093DC2 bt 0x06093DD6
    c.r[4] = 0xFFFFFFEFu;  // 06093DC4 mov #-17,r4
    c.r[8] = ld32(0x06093E0Cu);  // 06093DC6 mov.l 0x06093E0C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093DCCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093DCCu) return; }  // 06093DC8 jsr @r8 ; nop
    c.r[8] = ld32(0x06093E10u);  // 06093DCC mov.l 0x06093E10,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093DD2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093DD2u) return; }  // 06093DCE jsr @r8 ; nop
    goto L_06093DF6;  // 06093DD2 bra 0x06093DF6 ; nop
L_06093DD6:
    c.r[1] = ld32(c.r[14]);  // 06093DD6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093DD8 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093DDA mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 06093DDC mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06093DDE mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 16);  // 06093DE0 mov.l @(16,r2),r3
    c.r[2] = c.r[3];  // 06093DE2 mov r3,r2
    c.r[2] += 108;  // 06093DE4 add #108,r2
    c.r[5] = c.r[1];  // 06093DE6 mov r1,r5
    c.r[4] = c.r[2];  // 06093DE8 mov r2,r4
    c.r[8] = ld32(0x06093E14u);  // 06093DEA mov.l 0x06093E14,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093DF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093DF0u) return; }  // 06093DEC jsr @r8 ; nop
    c.r[8] = ld32(0x06093E18u);  // 06093DF0 mov.l 0x06093E18,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093DF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093DF6u) return; }  // 06093DF2 jsr @r8 ; nop
L_06093DF6:
    c.r[14] += 8;  // 06093DF6 add #8,r14
    c.r[15] = c.r[14];  // 06093DF8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093DFA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093DFC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093DFE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093E00 rts ; nop
}

void f_06093E1C(SH2Context& c) {
    ran[2233] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093E1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093E1E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093E20 sts.l pr,@-r15
    c.r[15] -= 16;  // 06093E22 add #-16,r15
    c.r[14] = c.r[15];  // 06093E24 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093E26 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093E28 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06093E2A mov.l r6,@(8,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093EF2u);  // 06093E2C mov.w 0x06093EF2,r1
    c.r[4] = c.r[1];  // 06093E2E mov r1,r4
    c.r[8] = ld32(0x06093EF4u);  // 06093E30 mov.l 0x06093EF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093E36u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093E36u) return; }  // 06093E32 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093E36 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093E38 tst r1,r1
    if (!c.t) { goto L_06093E50; }  // 06093E3A bf 0x06093E50
    c.r[4] = 0xFFFFFFF5u;  // 06093E3C mov #-11,r4
    c.r[8] = ld32(0x06093EF8u);  // 06093E3E mov.l 0x06093EF8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093E44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093E44u) return; }  // 06093E40 jsr @r8 ; nop
    c.r[8] = ld32(0x06093EFCu);  // 06093E44 mov.l 0x06093EFC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093E4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093E4Au) return; }  // 06093E46 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06093E4A mov #0,r0
    goto L_06093EE4;  // 06093E4C bra 0x06093EE4 ; nop
L_06093E50:
    c.r[1] = ld32(c.r[14] + 4);  // 06093E50 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093E52 cmp/pz r1
    if (c.t) { goto L_06093E6A; }  // 06093E54 bt 0x06093E6A
    c.r[4] = 0xFFFFFFF2u;  // 06093E56 mov #-14,r4
    c.r[8] = ld32(0x06093EF8u);  // 06093E58 mov.l 0x06093EF8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093E5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093E5Eu) return; }  // 06093E5A jsr @r8 ; nop
    c.r[8] = ld32(0x06093EFCu);  // 06093E5E mov.l 0x06093EFC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093E64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093E64u) return; }  // 06093E60 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06093E64 mov #0,r0
    goto L_06093EE4;  // 06093E66 bra 0x06093EE4 ; nop
L_06093E6A:
    c.r[1] = ld32(c.r[14]);  // 06093E6A mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06093E6C mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06093E6E mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 06093E70 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06093E72 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06093E74 mov r2,r1
    c.r[1] += 28;  // 06093E76 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06093E78 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06093E7A tst r2,r2
    if (!c.t) { goto L_06093E98; }  // 06093E7C bf 0x06093E98
    c.r[1] = ld32(c.r[14] + 8);  // 06093E7E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06093E80 mov.l @(4,r14),r2
    c.r[7] = ld32(c.r[14]);  // 06093E82 mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 20);  // 06093E84 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06093E86 mov r1,r6
    c.r[5] = c.r[2];  // 06093E88 mov r2,r5
    c.r[4] = c.r[3];  // 06093E8A mov r3,r4
    c.r[8] = ld32(0x06093F00u);  // 06093E8C mov.l 0x06093F00,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093E92u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093E92u) return; }  // 06093E8E jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06093E92 mov.l r0,@(12,r14)
    goto L_06093ED8;  // 06093E94 bra 0x06093ED8 ; nop
L_06093E98:
    c.r[4] = ld32(c.r[14]);  // 06093E98 mov.l @r14,r4
    c.r[8] = ld32(0x06093F04u);  // 06093E9A mov.l 0x06093F04,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093EA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093EA0u) return; }  // 06093E9C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 06093EA0 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 06093EA2 cmp/ge r0,r1
    if (c.t) { goto L_06093ED4; }  // 06093EA4 bt 0x06093ED4
    c.r[1] = ld32(c.r[14] + 8);  // 06093EA6 mov.l @(8,r14),r1
    c.r[2] = ld32(0x06093F08u);  // 06093EA8 mov.l 0x06093F08,r2
    st32(c.r[1], c.r[2]);  // 06093EAA mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 06093EAC mov.l @(8,r14),r1
    c.r[2] = 0x0u;  // 06093EAE mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 06093EB0 mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06093EB2 mov.l @(8,r14),r1
    c.r[2] = 0x0u;  // 06093EB4 mov #0,r2
    st32(c.r[1] + 8, c.r[2]);  // 06093EB6 mov.l r2,@(8,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 06093EB8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093EBA mov r2,r1
    c.r[2] += 12;  // 06093EBC add #12,r2
    c.r[1] = 0x0u;  // 06093EBE mov #0,r1
    st8(c.r[2], c.r[1]);  // 06093EC0 mov.b r1,@r2
    c.r[2] = ld32(c.r[14] + 8);  // 06093EC2 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06093EC4 mov r2,r1
    c.r[2] += 13;  // 06093EC6 add #13,r2
    c.r[1] = 0x0u;  // 06093EC8 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06093ECA mov.b r1,@r2
    c.r[1] = 0x1u;  // 06093ECC mov #1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06093ECE mov.l r1,@(12,r14)
    goto L_06093ED8;  // 06093ED0 bra 0x06093ED8 ; nop
L_06093ED4:
    c.r[1] = 0x0u;  // 06093ED4 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 06093ED6 mov.l r1,@(12,r14)
L_06093ED8:
    c.r[8] = ld32(0x06093F0Cu);  // 06093ED8 mov.l 0x06093F0C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093EDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093EDEu) return; }  // 06093EDA jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 06093EDE mov.l @(12,r14),r0
    goto L_06093EE4;  // 06093EE0 bra 0x06093EE4 ; nop
L_06093EE4:
    c.r[14] += 16;  // 06093EE4 add #16,r14
    c.r[15] = c.r[14];  // 06093EE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093EE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093EEA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093EEC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093EEE rts ; nop
}

void f_06093F10(SH2Context& c) {
    ran[2234] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093F10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093F12 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093F14 sts.l pr,@-r15
    c.r[15] -= 8;  // 06093F16 add #-8,r15
    c.r[14] = c.r[15];  // 06093F18 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093F1A mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06093F6Au);  // 06093F1C mov.w 0x06093F6A,r1
    c.r[4] = c.r[1];  // 06093F1E mov r1,r4
    c.r[8] = ld32(0x06093F6Cu);  // 06093F20 mov.l 0x06093F6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093F26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093F26u) return; }  // 06093F22 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093F26 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093F28 tst r1,r1
    if (!c.t) { goto L_06093F40; }  // 06093F2A bf 0x06093F40
    c.r[4] = 0xFFFFFFF5u;  // 06093F2C mov #-11,r4
    c.r[8] = ld32(0x06093F70u);  // 06093F2E mov.l 0x06093F70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093F34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093F34u) return; }  // 06093F30 jsr @r8 ; nop
    c.r[8] = ld32(0x06093F74u);  // 06093F34 mov.l 0x06093F74,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093F3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093F3Au) return; }  // 06093F36 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF5u;  // 06093F3A mov #-11,r0
    goto L_06093F5C;  // 06093F3C bra 0x06093F5C ; nop
L_06093F40:
    c.r[8] = ld32(0x06093F78u);  // 06093F40 mov.l 0x06093F78,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093F46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093F46u) return; }  // 06093F42 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06093F46 mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06093F48 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093F4A cmp/pz r1
    if (c.t) { goto L_06093F54; }  // 06093F4C bt 0x06093F54
    c.r[0] = ld32(c.r[14] + 4);  // 06093F4E mov.l @(4,r14),r0
    goto L_06093F5C;  // 06093F50 bra 0x06093F5C ; nop
L_06093F54:
    c.r[1] = ld32(c.r[14]);  // 06093F54 mov.l @r14,r1
    c.r[0] = ld32(c.r[1] + 48);  // 06093F56 mov.l @(48,r1),r0
    goto L_06093F5C;  // 06093F58 bra 0x06093F5C ; nop
L_06093F5C:
    c.r[14] += 8;  // 06093F5C add #8,r14
    c.r[15] = c.r[14];  // 06093F5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06093F60 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06093F62 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06093F64 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06093F66 rts ; nop
}

void f_06093F7C(SH2Context& c) {
    ran[2235] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06093F7C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06093F7E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06093F80 sts.l pr,@-r15
    c.r[15] -= 16;  // 06093F82 add #-16,r15
    c.r[14] = c.r[15];  // 06093F84 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06093F86 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06093F88 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609402Au);  // 06093F8A mov.w 0x0609402A,r1
    c.r[4] = c.r[1];  // 06093F8C mov r1,r4
    c.r[8] = ld32(0x0609402Cu);  // 06093F8E mov.l 0x0609402C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093F94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093F94u) return; }  // 06093F90 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06093F94 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093F96 tst r1,r1
    if (!c.t) { goto L_06093FAE; }  // 06093F98 bf 0x06093FAE
    c.r[4] = 0xFFFFFFF5u;  // 06093F9A mov #-11,r4
    c.r[8] = ld32(0x06094030u);  // 06093F9C mov.l 0x06094030,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093FA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093FA2u) return; }  // 06093F9E jsr @r8 ; nop
    c.r[8] = ld32(0x06094034u);  // 06093FA2 mov.l 0x06094034,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093FA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093FA8u) return; }  // 06093FA4 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF5u;  // 06093FA8 mov #-11,r0
    goto L_0609401C;  // 06093FAA bra 0x0609401C ; nop
L_06093FAE:
    c.r[2] = ld32(0x06094038u);  // 06093FAE mov.l 0x06094038,r2
    c.r[1] = ld32(c.r[2]);  // 06093FB0 mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06093FB2 mov.l @(16,r1),r2
    c.r[1] = ld32(c.r[14]);  // 06093FB4 mov.l @r14,r1
    c.t = c.r[2] == c.r[1];  // 06093FB6 cmp/eq r1,r2
    if (!c.t) { goto L_06093FF8; }  // 06093FB8 bf 0x06093FF8
    c.r[2] = ld32(c.r[14]);  // 06093FBA mov.l @r14,r2
    c.r[1] = c.r[2];  // 06093FBC mov r2,r1
    c.r[2] += 56;  // 06093FBE add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06093FC0 mov.w @r2,r1
    c.r[2] = 0x2u;  // 06093FC2 mov #2,r2
    c.r[2] &= c.r[1];  // 06093FC4 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06093FC6 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093FC8 tst r1,r1
    if (c.t) { goto L_06093FF8; }  // 06093FCA bt 0x06093FF8
    c.r[2] = ld32(c.r[14]);  // 06093FCC mov.l @r14,r2
    c.r[1] = c.r[2];  // 06093FCE mov r2,r1
    c.r[2] += 56;  // 06093FD0 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06093FD2 mov.w @r2,r1
    c.r[2] = 0x4u;  // 06093FD4 mov #4,r2
    c.r[2] &= c.r[1];  // 06093FD6 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06093FD8 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06093FDA tst r1,r1
    if (c.t) { goto L_06093FF8; }  // 06093FDC bt 0x06093FF8
    c.r[1] = c.r[14];  // 06093FDE mov r14,r1
    c.r[1] += 8;  // 06093FE0 add #8,r1
    c.r[5] = 0x0u;  // 06093FE2 mov #0,r5
    c.r[4] = c.r[1];  // 06093FE4 mov r1,r4
    c.r[8] = ld32(0x0609403Cu);  // 06093FE6 mov.l 0x0609403C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06093FECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06093FECu) return; }  // 06093FE8 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06093FEC mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06093FEE cmp/pz r1
    if (!c.t) { goto L_06093FF8; }  // 06093FF0 bf 0x06093FF8
    c.r[1] = ld32(c.r[14]);  // 06093FF2 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06093FF4 mov.l @(8,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06093FF6 mov.l r2,@(20,r1)
L_06093FF8:
    c.r[1] = ld32(c.r[14] + 4);  // 06093FF8 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06093FFA mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 20);  // 06093FFC mov.l @(20,r2),r3
    st32(c.r[1], c.r[3]);  // 06093FFE mov.l r3,@r1
    c.r[8] = ld32(0x06094040u);  // 06094000 mov.l 0x06094040,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094006u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094006u) return; }  // 06094002 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06094006 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 06094008 mov.l @(12,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609400A cmp/pz r1
    if (c.t) { goto L_06094014; }  // 0609400C bt 0x06094014
    c.r[0] = ld32(c.r[14] + 12);  // 0609400E mov.l @(12,r14),r0
    goto L_0609401C;  // 06094010 bra 0x0609401C ; nop
L_06094014:
    c.r[1] = ld32(c.r[14]);  // 06094014 mov.l @r14,r1
    c.r[0] = ld32(c.r[1] + 24);  // 06094016 mov.l @(24,r1),r0
    goto L_0609401C;  // 06094018 bra 0x0609401C ; nop
L_0609401C:
    c.r[14] += 16;  // 0609401C add #16,r14
    c.r[15] = c.r[14];  // 0609401E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094020 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094022 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094024 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094026 rts ; nop
}

void f_06094044(SH2Context& c) {
    ran[2236] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094044 mov.l r14,@-r15
    c.r[15] -= 8;  // 06094046 add #-8,r15
    c.r[14] = c.r[15];  // 06094048 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609404A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0609404C mov.l r5,@(4,r14)
    c.r[1] = ld32(0x0609407Cu);  // 0609404E mov.l 0x0609407C,r1
    c.r[2] = ld32(c.r[1]);  // 06094050 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06094052 mov r2,r1
    c.r[1] += 28;  // 06094054 add #28,r1
    c.r[2] = 0x0u;  // 06094056 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094058 mov.l r2,@r1
    c.r[1] = ld32(0x0609407Cu);  // 0609405A mov.l 0x0609407C,r1
    c.r[2] = ld32(c.r[1]);  // 0609405C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609405E mov r2,r1
    c.r[1] += 28;  // 06094060 add #28,r1
    c.r[2] = ld32(c.r[14]);  // 06094062 mov.l @r14,r2
    st32(c.r[1] + 8, c.r[2]);  // 06094064 mov.l r2,@(8,r1)
    c.r[1] = ld32(0x0609407Cu);  // 06094066 mov.l 0x0609407C,r1
    c.r[2] = ld32(c.r[1]);  // 06094068 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609406A mov r2,r1
    c.r[1] += 28;  // 0609406C add #28,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609406E mov.l @(4,r14),r2
    st32(c.r[1] + 12, c.r[2]);  // 06094070 mov.l r2,@(12,r1)
    c.r[14] += 8;  // 06094072 add #8,r14
    c.r[15] = c.r[14];  // 06094074 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094076 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094078 rts ; nop
}

void f_06094080(SH2Context& c) {
    ran[2237] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094080 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094082 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094084 sts.l pr,@-r15
    c.r[15] -= 4;  // 06094086 add #-4,r15
    c.r[14] = c.r[15];  // 06094088 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609408A mov.l r4,@r14
    c.r[1] = ld32(0x060940B0u);  // 0609408C mov.l 0x060940B0,r1
    c.r[2] = ld32(c.r[1]);  // 0609408E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06094090 mov r2,r1
    c.r[1] += 28;  // 06094092 add #28,r1
    c.r[6] = 0x10u;  // 06094094 mov #16,r6
    c.r[5] = c.r[1];  // 06094096 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06094098 mov.l @r14,r4
    c.r[8] = ld32(0x060940B4u);  // 0609409A mov.l 0x060940B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060940A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060940A0u) return; }  // 0609409C jsr @r8 ; nop
    c.r[14] += 4;  // 060940A0 add #4,r14
    c.r[15] = c.r[14];  // 060940A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060940A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060940A6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060940A8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060940AA rts ; nop
}

void f_060940B8(SH2Context& c) {
    ran[2238] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060940B8 mov.l r14,@-r15
    c.r[15] -= 8;  // 060940BA add #-8,r15
    c.r[14] = c.r[15];  // 060940BC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060940BE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060940C0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 060940C2 mov.l @(8,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060940C4 tst r2,r2
    if (c.t) { goto L_060940CE; }  // 060940C6 bt 0x060940CE
    c.r[0] = 0x0u;  // 060940C8 mov #0,r0
    goto L_06094104;  // 060940CA bra 0x06094104 ; nop
L_060940CE:
    ;  // 060940CE nop
    c.r[1] = ld32(c.r[14]);  // 060940D0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 060940D2 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 060940D4 mov.l r2,@(4,r14)
L_060940D6:
    c.r[1] = ld32(c.r[14] + 4);  // 060940D6 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060940D8 tst r1,r1
    if (!c.t) { goto L_060940E0; }  // 060940DA bf 0x060940E0
    goto L_060940FE;  // 060940DC bra 0x060940FE ; nop
L_060940E0:
    c.r[1] = ld32(c.r[14] + 4);  // 060940E0 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 060940E2 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 060940E4 mov r2,r1
    c.r[1] += 28;  // 060940E6 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 060940E8 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060940EA tst r2,r2
    if (!c.t) { goto L_060940F4; }  // 060940EC bf 0x060940F4
    c.r[0] = 0x0u;  // 060940EE mov #0,r0
    goto L_06094104;  // 060940F0 bra 0x06094104 ; nop
L_060940F4:
    c.r[1] = ld32(c.r[14] + 4);  // 060940F4 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 060940F6 mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 060940F8 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_060940D6;  // 060940FA bra 0x060940D6 ; nop
L_060940FE:
    c.r[0] = 0x1u;  // 060940FE mov #1,r0
    goto L_06094104;  // 06094100 bra 0x06094104 ; nop
L_06094104:
    c.r[14] += 8;  // 06094104 add #8,r14
    c.r[15] = c.r[14];  // 06094106 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094108 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609410A rts ; nop
}

void f_06094110(SH2Context& c) {
    ran[2239] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094110 mov.l r14,@-r15
    c.r[15] -= 8;  // 06094112 add #-8,r15
    c.r[14] = c.r[15];  // 06094114 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094116 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06094118 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 0609411A mov.l @(8,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609411C tst r2,r2
    if (c.t) { goto L_06094126; }  // 0609411E bt 0x06094126
    c.r[0] = 0x0u;  // 06094120 mov #0,r0
    goto L_0609416E;  // 06094122 bra 0x0609416E ; nop
L_06094126:
    c.r[1] = ld32(c.r[14]);  // 06094126 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06094128 mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609412A tst r2,r2
    if (c.t) { goto L_06094134; }  // 0609412C bt 0x06094134
    c.r[0] = 0x0u;  // 0609412E mov #0,r0
    goto L_0609416E;  // 06094130 bra 0x0609416E ; nop
L_06094134:
    ;  // 06094134 nop
    c.r[1] = ld32(c.r[14]);  // 06094136 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06094138 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609413A mov.l r2,@(4,r14)
L_0609413C:
    c.r[1] = ld32(c.r[14] + 4);  // 0609413C mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609413E tst r1,r1
    if (!c.t) { goto L_06094146; }  // 06094140 bf 0x06094146
    goto L_06094168;  // 06094142 bra 0x06094168 ; nop
L_06094146:
    c.r[2] = ld32(c.r[14] + 4);  // 06094146 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06094148 mov r2,r1
    c.r[2] += 44;  // 0609414A add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609414C mov.b @r2,r1
    c.r[2] = 0x2u;  // 0609414E mov #2,r2
    c.r[2] &= c.r[1];  // 06094150 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06094152 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094154 tst r1,r1
    if (!c.t) { goto L_0609415E; }  // 06094156 bf 0x0609415E
    c.r[0] = 0x0u;  // 06094158 mov #0,r0
    goto L_0609416E;  // 0609415A bra 0x0609416E ; nop
L_0609415E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609415E mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094160 mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06094162 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0609413C;  // 06094164 bra 0x0609413C ; nop
L_06094168:
    c.r[0] = 0x1u;  // 06094168 mov #1,r0
    goto L_0609416E;  // 0609416A bra 0x0609416E ; nop
L_0609416E:
    c.r[14] += 8;  // 0609416E add #8,r14
    c.r[15] = c.r[14];  // 06094170 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094172 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094174 rts ; nop
}

void f_06094178(SH2Context& c) {
    ran[2240] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094178 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609417A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609417C sts.l pr,@-r15
    c.r[15] -= 8;  // 0609417E add #-8,r15
    c.r[14] = c.r[15];  // 06094180 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094182 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06094184 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094186 mov r1,r2
    c.r[1] += 56;  // 06094188 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 0609418A mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609418C mov r3,r2
    c.r[3] += 56;  // 0609418E add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094190 mov.w @r3,r2
    c.r[3] = 0x4u;  // 06094192 mov #4,r3
    c.r[3] |= c.r[2];  // 06094194 or r2,r3
    st16(c.r[1], c.r[3]);  // 06094196 mov.w r3,@r1
    c.r[1] = ld32(c.r[14]);  // 06094198 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 36);  // 0609419A mov.l @(36,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609419C tst r2,r2
    if (c.t) { goto L_06094200; }  // 0609419E bt 0x06094200
    c.r[1] = ld32(c.r[14]);  // 060941A0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 28);  // 060941A2 mov.l @(28,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060941A4 tst r2,r2
    if (!c.t) { goto L_060941D2; }  // 060941A6 bf 0x060941D2
    c.r[8] = ld32(0x06094210u);  // 060941A8 mov.l 0x06094210,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060941AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060941AEu) return; }  // 060941AA jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060941AE mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060941B0 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060941B2 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1] + 32);  // 060941B4 mov.l @(32,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060941B6 cmp/ge r1,r2
    if (c.t) { goto L_060941CE; }  // 060941B8 bt 0x060941CE
    c.r[1] = ld32(c.r[14]);  // 060941BA mov.l @r14,r1
    c.r[2] = c.r[1];  // 060941BC mov r1,r2
    c.r[1] += 56;  // 060941BE add #56,r1
    c.r[3] = ld32(c.r[14]);  // 060941C0 mov.l @r14,r3
    c.r[2] = c.r[3];  // 060941C2 mov r3,r2
    c.r[3] += 56;  // 060941C4 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060941C6 mov.w @r3,r2
    c.r[3] = 0x8u;  // 060941C8 mov #8,r3
    c.r[3] |= c.r[2];  // 060941CA or r2,r3
    st16(c.r[1], c.r[3]);  // 060941CC mov.w r3,@r1
L_060941CE:
    goto L_06094200;  // 060941CE bra 0x06094200 ; nop
L_060941D2:
    c.r[1] = ld32(c.r[14]);  // 060941D2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 28);  // 060941D4 mov.l @(28,r1),r2
    c.r[1] = ld32(c.r[2] + 20);  // 060941D6 mov.l @(20,r2),r1
    c.r[4] = c.r[1];  // 060941D8 mov r1,r4
    c.r[8] = ld32(0x06094214u);  // 060941DA mov.l 0x06094214,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060941E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060941E0u) return; }  // 060941DC jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060941E0 mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060941E2 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060941E4 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1] + 32);  // 060941E6 mov.l @(32,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060941E8 cmp/ge r1,r2
    if (!c.t) { goto L_06094200; }  // 060941EA bf 0x06094200
    c.r[1] = ld32(c.r[14]);  // 060941EC mov.l @r14,r1
    c.r[2] = c.r[1];  // 060941EE mov r1,r2
    c.r[1] += 56;  // 060941F0 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 060941F2 mov.l @r14,r3
    c.r[2] = c.r[3];  // 060941F4 mov r3,r2
    c.r[3] += 56;  // 060941F6 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060941F8 mov.w @r3,r2
    c.r[3] = 0x8u;  // 060941FA mov #8,r3
    c.r[3] |= c.r[2];  // 060941FC or r2,r3
    st16(c.r[1], c.r[3]);  // 060941FE mov.w r3,@r1
L_06094200:
    c.r[14] += 8;  // 06094200 add #8,r14
    c.r[15] = c.r[14];  // 06094202 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094204 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094206 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094208 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609420A rts ; nop
}

void f_06094218(SH2Context& c) {
    ran[2241] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094218 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609421A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609421C sts.l pr,@-r15
    c.r[15] -= 12;  // 0609421E add #-12,r15
    c.r[14] = c.r[15];  // 06094220 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094222 mov.l r4,@r14
    c.r[1] = 0x0u;  // 06094224 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06094226 mov.l r1,@(4,r14)
    c.r[0] = ld32(c.r[14]);  // 06094228 mov.l @r14,r0
    c.t = c.r[0] == 0x3u;  // 0609422A cmp/eq #3,r0
    if (!c.t) { goto L_06094236; }  // 0609422C bf 0x06094236
    c.r[1] = 0xFFFFFFE9u;  // 0609422E mov #-23,r1
    st32(c.r[14] + 4, c.r[1]);  // 06094230 mov.l r1,@(4,r14)
    goto L_0609427C;  // 06094232 bra 0x0609427C ; nop
L_06094236:
    c.r[0] = ld32(c.r[14]);  // 06094236 mov.l @r14,r0
    c.t = c.r[0] == 0x4u;  // 06094238 cmp/eq #4,r0
    if (!c.t) { goto L_06094264; }  // 0609423A bf 0x06094264
    c.r[2] = ld32(0x0609429Cu);  // 0609423C mov.l 0x0609429C,r2
    c.r[1] = ld32(c.r[2]);  // 0609423E mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06094240 mov.l @(16,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06094242 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06094244 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094246 tst r1,r1
    if (c.t) { goto L_0609425C; }  // 06094248 bt 0x0609425C
    c.r[1] = ld32(c.r[14] + 8);  // 0609424A mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 0609424C mov r1,r4
    c.r[8] = ld32(0x060942A0u);  // 0609424E mov.l 0x060942A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094254u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094254u) return; }  // 06094250 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 06094254 tst r0,r0
    if (!c.t) { goto L_06094260; }  // 06094256 bf 0x06094260
    goto L_0609425C;  // 06094258 bra 0x0609425C ; nop
L_0609425C:
    c.r[1] = 0xFFFFFFFEu;  // 0609425C mov #-2,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609425E mov.l r1,@(4,r14)
L_06094260:
    goto L_0609427C;  // 06094260 bra 0x0609427C ; nop
L_06094264:
    c.r[0] = ld32(c.r[14]);  // 06094264 mov.l @r14,r0
    c.t = c.r[0] == 0x6u;  // 06094266 cmp/eq #6,r0
    if (!c.t) { goto L_06094272; }  // 06094268 bf 0x06094272
    c.r[1] = 0xFFFFFFE7u;  // 0609426A mov #-25,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609426C mov.l r1,@(4,r14)
    goto L_0609427C;  // 0609426E bra 0x0609427C ; nop
L_06094272:
    c.r[0] = ld32(c.r[14]);  // 06094272 mov.l @r14,r0
    c.t = c.r[0] == 0x5u;  // 06094274 cmp/eq #5,r0
    if (!c.t) { goto L_0609427C; }  // 06094276 bf 0x0609427C
    c.r[1] = 0xFFFFFFFFu;  // 06094278 mov #-1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609427A mov.l r1,@(4,r14)
L_0609427C:
    c.r[1] = ld32(c.r[14] + 4);  // 0609427C mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609427E tst r1,r1
    if (c.t) { goto L_0609428C; }  // 06094280 bt 0x0609428C
    c.r[1] = ld32(c.r[14] + 4);  // 06094282 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 06094284 mov r1,r4
    c.r[8] = ld32(0x060942A4u);  // 06094286 mov.l 0x060942A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609428Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609428Cu) return; }  // 06094288 jsr @r8 ; nop
L_0609428C:
    c.r[14] += 12;  // 0609428C add #12,r14
    c.r[15] = c.r[14];  // 0609428E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094290 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094292 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094294 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094296 rts ; nop
}

void f_060942A8(SH2Context& c) {
    ran[2242] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060942A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060942AA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060942AC sts.l pr,@-r15
    c.r[15] -= 48;  // 060942AE add #-48,r15
    c.r[14] = c.r[15];  // 060942B0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060942B2 mov.l r4,@r14
    c.r[1] = 0x1u;  // 060942B4 mov #1,r1
    st32(c.r[14] + 44, c.r[1]);  // 060942B6 mov.l r1,@(44,r14)
    c.r[1] = ld32(c.r[14]);  // 060942B8 mov.l @r14,r1
    st32(c.r[14] + 4, c.r[1]);  // 060942BA mov.l r1,@(4,r14)
    c.r[2] = ld32(0x060944B0u);  // 060942BC mov.l 0x060944B0,r2
    c.r[1] = ld32(c.r[2]);  // 060942BE mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 060942C0 mov.l @(16,r1),r2
    c.r[1] = ld32(c.r[14] + 4);  // 060942C2 mov.l @(4,r14),r1
    c.t = c.r[2] == c.r[1];  // 060942C4 cmp/eq r1,r2
    if (!c.t) { goto L_060942CC; }  // 060942C6 bf 0x060942CC
    goto L_06094510;  // 060942C8 bra 0x06094510 ; nop
L_060942CC:
    c.r[2] = ld32(0x060944B0u);  // 060942CC mov.l 0x060944B0,r2
    c.r[1] = ld32(c.r[2]);  // 060942CE mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 060942D0 mov.l @(16,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 060942D2 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060942D4 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060942D6 tst r1,r1
    if (!c.t) { goto L_060942DE; }  // 060942D8 bf 0x060942DE
    goto L_060943FE;  // 060942DA bra 0x060943FE ; nop
L_060942DE:
    c.r[1] = c.r[14];  // 060942DE mov r14,r1
    c.r[1] += 20;  // 060942E0 add #20,r1
    c.r[5] = 0x0u;  // 060942E2 mov #0,r5
    c.r[4] = c.r[1];  // 060942E4 mov r1,r4
    c.r[8] = ld32(0x060944B4u);  // 060942E6 mov.l 0x060944B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060942ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060942ECu) return; }  // 060942E8 jsr @r8 ; nop
    st32(c.r[14] + 32, c.r[0]);  // 060942EC mov.l r0,@(32,r14)
    c.r[1] = ld32(c.r[14] + 32);  // 060942EE mov.l @(32,r14),r1
    c.r[4] = c.r[1];  // 060942F0 mov r1,r4
    c.r[8] = ld32(0x060944B8u);  // 060942F2 mov.l 0x060944B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060942F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060942F8u) return; }  // 060942F4 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 060942F8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 060942FA mov r2,r1
    c.r[2] += 56;  // 060942FC add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060942FE mov.w @r2,r1
    c.r[2] = 0x2u;  // 06094300 mov #2,r2
    c.r[2] &= c.r[1];  // 06094302 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094304 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094306 tst r1,r1
    if (c.t) { goto L_0609434C; }  // 06094308 bt 0x0609434C
    c.r[2] = ld32(c.r[14] + 8);  // 0609430A mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0609430C mov r2,r1
    c.r[2] += 56;  // 0609430E add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094310 mov.w @r2,r1
    c.r[2] = 0x10u;  // 06094312 mov #16,r2
    c.r[2] &= c.r[1];  // 06094314 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094316 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094318 tst r1,r1
    if (!c.t) { goto L_0609434C; }  // 0609431A bf 0x0609434C
    c.r[1] = ld32(c.r[14] + 8);  // 0609431C mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 0609431E mov r1,r4
    c.r[8] = ld32(0x060944BCu);  // 06094320 mov.l 0x060944BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094326u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094326u) return; }  // 06094322 jsr @r8 ; nop
    st32(c.r[14] + 36, c.r[0]);  // 06094326 mov.l r0,@(36,r14)
    c.r[1] = ld32(c.r[14] + 36);  // 06094328 mov.l @(36,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609432A tst r1,r1
    if (c.t) { goto L_06094338; }  // 0609432C bt 0x06094338
    c.r[1] = ld32(c.r[14] + 36);  // 0609432E mov.l @(36,r14),r1
    c.r[4] = c.r[1];  // 06094330 mov r1,r4
    c.r[8] = ld32(0x060944C0u);  // 06094332 mov.l 0x060944C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094338u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094338u) return; }  // 06094334 jsr @r8 ; nop
L_06094338:
    c.r[1] = ld32(c.r[14] + 8);  // 06094338 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0609433A mov r1,r2
    c.r[1] += 56;  // 0609433C add #56,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0609433E mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 06094340 mov r3,r2
    c.r[3] += 56;  // 06094342 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094344 mov.w @r3,r2
    c.r[3] = 0x10u;  // 06094346 mov #16,r3
    c.r[3] |= c.r[2];  // 06094348 or r2,r3
    st16(c.r[1], c.r[3]);  // 0609434A mov.w r3,@r1
L_0609434C:
    c.r[1] = ld32(c.r[14] + 8);  // 0609434C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609434E mov.l @(52,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06094350 cmp/pz r2
    if (!c.t) { goto L_06094370; }  // 06094352 bf 0x06094370
    c.r[1] = ld32(c.r[14] + 8);  // 06094354 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 52);  // 06094356 mov.l @(52,r1),r2
    c.r[4] = c.r[2];  // 06094358 mov r2,r4
    c.r[8] = ld32(0x060944C4u);  // 0609435A mov.l 0x060944C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094360u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094360u) return; }  // 0609435C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06094360 mov.l @(8,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094362 mov #-1,r2
    st32(c.r[1] + 52, c.r[2]);  // 06094364 mov.l r2,@(52,r1)
    c.r[5] = 0x0u;  // 06094366 mov #0,r5
    c.r[4] = 0x0u;  // 06094368 mov #0,r4
    c.r[8] = ld32(0x060944C8u);  // 0609436A mov.l 0x060944C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094370u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094370u) return; }  // 0609436C jsr @r8 ; nop
L_06094370:
    c.r[1] = ld32(c.r[14] + 8);  // 06094370 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 24);  // 06094372 mov.l @(24,r1),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060944A8u);  // 06094374 mov.w 0x060944A8,r1
    c.t = c.r[2] == c.r[1];  // 06094376 cmp/eq r1,r2
    if (c.t) { goto L_06094380; }  // 06094378 bt 0x06094380
    c.r[1] = ld32(c.r[14] + 8);  // 0609437A mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060944AAu);  // 0609437C mov.w 0x060944AA,r2
    st32(c.r[1] + 24, c.r[2]);  // 0609437E mov.l r2,@(24,r1)
L_06094380:
    c.r[1] = ld32(c.r[14] + 32);  // 06094380 mov.l @(32,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094382 tst r1,r1
    if (c.t) { goto L_0609438A; }  // 06094384 bt 0x0609438A
    goto L_060943FE;  // 06094386 bra 0x060943FE ; nop
L_0609438A:
    c.r[1] = ld32(c.r[14] + 8);  // 0609438A mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 0609438C mov.l @(16,r1),r2
    st32(c.r[14] + 40, c.r[2]);  // 0609438E mov.l r2,@(40,r14)
    c.r[1] = ld32(c.r[14] + 40);  // 06094390 mov.l @(40,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094392 tst r1,r1
    if (c.t) { goto L_060943B0; }  // 06094394 bt 0x060943B0
    c.r[1] = ld32(c.r[14] + 40);  // 06094396 mov.l @(40,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06094398 mov.l @(16,r1),r2
    c.r[5] = 0xFFFFFFFFu;  // 0609439A mov #-1,r5
    c.r[4] = c.r[2];  // 0609439C mov r2,r4
    c.r[8] = ld32(0x060944CCu);  // 0609439E mov.l 0x060944CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060943A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060943A4u) return; }  // 060943A0 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 40);  // 060943A4 mov.l @(40,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 060943A6 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 060943A8 mov r2,r1
    c.r[1] += 108;  // 060943AA add #108,r1
    c.r[2] = 0x0u;  // 060943AC mov #0,r2
    st32(c.r[1] + 52, c.r[2]);  // 060943AE mov.l r2,@(52,r1)
L_060943B0:
    c.r[2] = ld32(c.r[14] + 8);  // 060943B0 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 060943B2 mov r2,r1
    c.r[2] += 56;  // 060943B4 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060943B6 mov.w @r2,r1
    c.r[2] = 0x10u;  // 060943B8 mov #16,r2
    c.r[2] &= c.r[1];  // 060943BA and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 060943BC extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060943BE tst r1,r1
    if (c.t) { goto L_060943E6; }  // 060943C0 bt 0x060943E6
    c.r[1] = ld32(c.r[14] + 8);  // 060943C2 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 060943C4 mov r1,r4
    c.r[8] = ld32(0x060944D0u);  // 060943C6 mov.l 0x060944D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060943CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060943CCu) return; }  // 060943C8 jsr @r8 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 060943CC mov.l r0,@(24,r14)
    c.r[8] = ld32(0x060944D4u);  // 060943CE mov.l 0x060944D4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060943D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060943D4u) return; }  // 060943D0 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 060943D4 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060943D6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 060943D8 mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 24);  // 060943DA mov.l @(24,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060943DC cmp/gt r1,r2
    if (c.t) { goto L_060943E6; }  // 060943DE bt 0x060943E6
    c.r[1] = ld32(c.r[14] + 8);  // 060943E0 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 20);  // 060943E2 mov.l @(20,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 060943E4 mov.l r2,@(20,r1)
L_060943E6:
    c.r[1] = ld32(c.r[14] + 8);  // 060943E6 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 060943E8 mov r1,r2
    c.r[1] += 56;  // 060943EA add #56,r1
    c.r[3] = ld32(c.r[14] + 8);  // 060943EC mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 060943EE mov r3,r2
    c.r[3] += 56;  // 060943F0 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060943F2 mov.w @r3,r2
    c.r[3] = ld32(0x060944D8u);  // 060943F4 mov.l 0x060944D8,r3
    c.r[2] &= c.r[3];  // 060943F6 and r3,r2
    st16(c.r[1], c.r[2]);  // 060943F8 mov.w r2,@r1
    c.r[1] = 0x0u;  // 060943FA mov #0,r1
    st32(c.r[14] + 8, c.r[1]);  // 060943FC mov.l r1,@(8,r14)
L_060943FE:
    c.r[1] = ld32(c.r[14] + 8);  // 060943FE mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094400 tst r1,r1
    if (c.t) { goto L_06094408; }  // 06094402 bt 0x06094408
    goto L_0609450C;  // 06094404 bra 0x0609450C ; nop
L_06094408:
    c.r[1] = ld32(c.r[14] + 4);  // 06094408 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609440A tst r1,r1
    if (!c.t) { goto L_06094412; }  // 0609440C bf 0x06094412
    goto L_060944FC;  // 0609440E bra 0x060944FC ; nop
L_06094412:
    c.r[1] = ld32(c.r[14] + 4);  // 06094412 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 52);  // 06094414 mov.l @(52,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06094416 cmp/pz r2
    if (c.t) { goto L_0609443C; }  // 06094418 bt 0x0609443C
    c.r[8] = ld32(0x060944DCu);  // 0609441A mov.l 0x060944DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094420u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094420u) return; }  // 0609441C jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06094420 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06094422 mov.l @(28,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06094424 cmp/pz r1
    if (!c.t) { goto L_0609442E; }  // 06094426 bf 0x0609442E
    c.r[1] = ld32(c.r[14] + 4);  // 06094428 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0609442A mov.l @(28,r14),r2
    st32(c.r[1] + 52, c.r[2]);  // 0609442C mov.l r2,@(52,r1)
L_0609442E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609442E mov.l @(4,r14),r1
    c.r[2] = ld32(0x060944E0u);  // 06094430 mov.l 0x060944E0,r2
    c.r[5] = c.r[1];  // 06094432 mov r1,r5
    c.r[4] = c.r[2];  // 06094434 mov r2,r4
    c.r[8] = ld32(0x060944C8u);  // 06094436 mov.l 0x060944C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609443Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609443Cu) return; }  // 06094438 jsr @r8 ; nop
L_0609443C:
    c.r[1] = ld32(c.r[14] + 4);  // 0609443C mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609443E mov.l @(52,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06094440 cmp/pz r2
    if (c.t) { goto L_06094448; }  // 06094442 bt 0x06094448
    goto L_060944F4;  // 06094444 bra 0x060944F4 ; nop
L_06094448:
    c.r[1] = ld32(c.r[14] + 4);  // 06094448 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609444A mov.l @(4,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 0609444C mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609444E mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094450 tst r1,r1
    if (c.t) { goto L_06094464; }  // 06094452 bt 0x06094464
    c.r[1] = ld32(c.r[14] + 12);  // 06094454 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094456 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06094458 mov r2,r1
    c.r[1] += 28;  // 0609445A add #28,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0609445C mov.l @(12,r1),r2
    st32(c.r[14] + 16, c.r[2]);  // 0609445E mov.l r2,@(16,r14)
    goto L_06094468;  // 06094460 bra 0x06094468 ; nop
L_06094464:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060944ACu);  // 06094464 mov.w 0x060944AC,r1
    st32(c.r[14] + 16, c.r[1]);  // 06094466 mov.l r1,@(16,r14)
L_06094468:
    c.r[1] = ld32(c.r[14] + 4);  // 06094468 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609446A mov.l @(52,r1),r2
    c.r[1] = ld32(c.r[14] + 16);  // 0609446C mov.l @(16,r14),r1
    c.r[5] = c.r[2];  // 0609446E mov r2,r5
    c.r[4] = c.r[1];  // 06094470 mov r1,r4
    c.r[8] = ld32(0x060944E4u);  // 06094472 mov.l 0x060944E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094478u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094478u) return; }  // 06094474 jsr @r8 ; nop
    c.r[8] = ld32(0x060944E8u);  // 06094478 mov.l 0x060944E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609447Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609447Eu) return; }  // 0609447A jsr @r8 ; nop
    st32(c.r[14] + 36, c.r[0]);  // 0609447E mov.l r0,@(36,r14)
    c.r[1] = ld32(c.r[14] + 36);  // 06094480 mov.l @(36,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094482 tst r1,r1
    if (c.t) { goto L_06094490; }  // 06094484 bt 0x06094490
    c.r[1] = ld32(c.r[14] + 36);  // 06094486 mov.l @(36,r14),r1
    c.r[4] = c.r[1];  // 06094488 mov r1,r4
    c.r[8] = ld32(0x060944ECu);  // 0609448A mov.l 0x060944EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094490u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094490u) return; }  // 0609448C jsr @r8 ; nop
L_06094490:
    c.r[1] = ld32(c.r[14] + 4);  // 06094490 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 06094492 mov r1,r2
    c.r[1] += 56;  // 06094494 add #56,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06094496 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06094498 mov r3,r2
    c.r[3] += 56;  // 0609449A add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609449C mov.w @r3,r2
    c.r[3] = ld32(0x060944F0u);  // 0609449E mov.l 0x060944F0,r3
    c.r[2] &= c.r[3];  // 060944A0 and r3,r2
    st16(c.r[1], c.r[2]);  // 060944A2 mov.w r2,@r1
    goto L_060944FC;  // 060944A4 bra 0x060944FC ; nop
L_060944F4:
    c.r[4] = 0xFFFFFFECu;  // 060944F4 mov #-20,r4
    c.r[8] = ld32(0x06094524u);  // 060944F6 mov.l 0x06094524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060944FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060944FCu) return; }  // 060944F8 jsr @r8 ; nop
L_060944FC:
    c.r[2] = ld32(0x06094528u);  // 060944FC mov.l 0x06094528,r2
    c.r[1] = ld32(c.r[2]);  // 060944FE mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094500 mov.l @(4,r14),r2
    st32(c.r[1] + 16, c.r[2]);  // 06094502 mov.l r2,@(16,r1)
    c.r[1] = 0x1u;  // 06094504 mov #1,r1
    st32(c.r[14] + 44, c.r[1]);  // 06094506 mov.l r1,@(44,r14)
    goto L_06094510;  // 06094508 bra 0x06094510 ; nop
L_0609450C:
    c.r[1] = 0x0u;  // 0609450C mov #0,r1
    st32(c.r[14] + 44, c.r[1]);  // 0609450E mov.l r1,@(44,r14)
L_06094510:
    c.r[0] = ld32(c.r[14] + 44);  // 06094510 mov.l @(44,r14),r0
    goto L_06094516;  // 06094512 bra 0x06094516 ; nop
L_06094516:
    c.r[14] += 48;  // 06094516 add #48,r14
    c.r[15] = c.r[14];  // 06094518 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609451A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609451C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609451E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094520 rts ; nop
}

void f_0609452C(SH2Context& c) {
    ran[2243] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609452C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609452E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094530 sts.l pr,@-r15
    c.r[15] -= 4;  // 06094532 add #-4,r15
    c.r[14] = c.r[15];  // 06094534 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094536 mov.l r4,@r14
    c.r[1] = ld32(0x06094578u);  // 06094538 mov.l 0x06094578,r1
    c.r[2] = ld32(c.r[1]);  // 0609453A mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609453C tst r2,r2
    if (c.t) { goto L_06094546; }  // 0609453E bt 0x06094546
    c.r[0] = 0x0u;  // 06094540 mov #0,r0
    goto L_06094568;  // 06094542 bra 0x06094568 ; nop
L_06094546:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06094576u);  // 06094546 mov.w 0x06094576,r1
    c.r[4] = c.r[1];  // 06094548 mov r1,r4
    c.r[8] = ld32(0x0609457Cu);  // 0609454A mov.l 0x0609457C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094550u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094550u) return; }  // 0609454C jsr @r8 ; nop
    c.r[1] = ld32(0x06094578u);  // 06094550 mov.l 0x06094578,r1
    c.r[2] = ld32(0x06094580u);  // 06094552 mov.l 0x06094580,r2
    st32(c.r[1], c.r[2]);  // 06094554 mov.l r2,@r1
    c.r[1] = ld32(0x06094578u);  // 06094556 mov.l 0x06094578,r1
    c.r[2] = ld32(c.r[14]);  // 06094558 mov.l @r14,r2
    st32(c.r[1] + 4, c.r[2]);  // 0609455A mov.l r2,@(4,r1)
    c.r[8] = ld32(0x06094584u);  // 0609455C mov.l 0x06094584,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094562u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094562u) return; }  // 0609455E jsr @r8 ; nop
    c.r[0] = 0x1u;  // 06094562 mov #1,r0
    goto L_06094568;  // 06094564 bra 0x06094568 ; nop
L_06094568:
    c.r[14] += 4;  // 06094568 add #4,r14
    c.r[15] = c.r[14];  // 0609456A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609456C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609456E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094570 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094572 rts ; nop
}

void f_06094588(SH2Context& c) {
    ran[2244] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094588 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609458A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609458C sts.l pr,@-r15
    c.r[15] -= 12;  // 0609458E add #-12,r15
    c.r[14] = c.r[15];  // 06094590 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094592 mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 06094594 mov.l @r14,r4
    c.r[8] = ld32(0x060945DCu);  // 06094596 mov.l 0x060945DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609459Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609459Cu) return; }  // 06094598 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0609459C mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609459E mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060945A0 tst r1,r1
    if (!c.t) { goto L_060945AA; }  // 060945A2 bf 0x060945AA
    c.r[0] = 0x0u;  // 060945A4 mov #0,r0
    goto L_060945CA;  // 060945A6 bra 0x060945CA ; nop
L_060945AA:
    ;  // 060945AA nop
L_060945AC:
    c.r[8] = ld32(0x060945E0u);  // 060945AC mov.l 0x060945E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060945B2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060945B2u) return; }  // 060945AE jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 060945B2 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060945B4 mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060945D8u);  // 060945B6 mov.w 0x060945D8,r2
    c.t = c.r[1] == c.r[2];  // 060945B8 cmp/eq r2,r1
    if (!c.t) { goto L_060945C0; }  // 060945BA bf 0x060945C0
    goto L_060945C4;  // 060945BC bra 0x060945C4 ; nop
L_060945C0:
    SH2_POLL(c); goto L_060945AC;  // 060945C0 bra 0x060945AC ; nop
L_060945C4:
    c.r[0] = 0x1u;  // 060945C4 mov #1,r0
    goto L_060945CA;  // 060945C6 bra 0x060945CA ; nop
L_060945CA:
    c.r[14] += 12;  // 060945CA add #12,r14
    c.r[15] = c.r[14];  // 060945CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060945CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060945D0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060945D2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060945D4 rts ; nop
}

void f_060945E4(SH2Context& c) {
    ran[2245] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060945E4 mov.l r14,@-r15
    c.r[15] -= 8;  // 060945E6 add #-8,r15
    c.r[14] = c.r[15];  // 060945E8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060945EA mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060945EC mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 060945EE mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 060945F0 mov r2,r1
    c.r[1] += 108;  // 060945F2 add #108,r1
    c.r[2] = ld32(c.r[1] + 12);  // 060945F4 mov.l @(12,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060945F6 tst r2,r2
    if (c.t) { goto L_06094602; }  // 060945F8 bt 0x06094602
    c.r[1] = 0x1u;  // 060945FA mov #1,r1
    st32(c.r[14] + 4, c.r[1]);  // 060945FC mov.l r1,@(4,r14)
    goto L_06094606;  // 060945FE bra 0x06094606 ; nop
L_06094602:
    c.r[1] = 0x0u;  // 06094602 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06094604 mov.l r1,@(4,r14)
L_06094606:
    c.r[0] = ld32(c.r[14] + 4);  // 06094606 mov.l @(4,r14),r0
    goto L_0609460C;  // 06094608 bra 0x0609460C ; nop
L_0609460C:
    c.r[14] += 8;  // 0609460C add #8,r14
    c.r[15] = c.r[14];  // 0609460E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094610 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094612 rts ; nop
}

void f_06094618(SH2Context& c) {
    ran[2246] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094618 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609461A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609461C sts.l pr,@-r15
    c.r[15] -= 8;  // 0609461E add #-8,r15
    c.r[14] = c.r[15];  // 06094620 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094622 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06094672u);  // 06094624 mov.w 0x06094672,r1
    c.r[4] = c.r[1];  // 06094626 mov r1,r4
    c.r[8] = ld32(0x06094674u);  // 06094628 mov.l 0x06094674,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609462Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609462Eu) return; }  // 0609462A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 0609462E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094630 tst r1,r1
    if (!c.t) { goto L_06094648; }  // 06094632 bf 0x06094648
    c.r[4] = 0xFFFFFFF5u;  // 06094634 mov #-11,r4
    c.r[8] = ld32(0x06094678u);  // 06094636 mov.l 0x06094678,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609463Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609463Cu) return; }  // 06094638 jsr @r8 ; nop
    c.r[8] = ld32(0x0609467Cu);  // 0609463C mov.l 0x0609467C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094642u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094642u) return; }  // 0609463E jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06094642 mov #0,r0
    goto L_06094664;  // 06094644 bra 0x06094664 ; nop
L_06094648:
    c.r[1] = ld32(c.r[14]);  // 06094648 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609464A mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 0609464C mov.l r2,@r14
    c.r[4] = ld32(c.r[14]);  // 0609464E mov.l @r14,r4
    c.r[8] = ld32(0x06094680u);  // 06094650 mov.l 0x06094680,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094656u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094656u) return; }  // 06094652 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06094656 mov.l r0,@(4,r14)
    c.r[8] = ld32(0x06094684u);  // 06094658 mov.l 0x06094684,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609465Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609465Eu) return; }  // 0609465A jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 4);  // 0609465E mov.l @(4,r14),r0
    goto L_06094664;  // 06094660 bra 0x06094664 ; nop
L_06094664:
    c.r[14] += 8;  // 06094664 add #8,r14
    c.r[15] = c.r[14];  // 06094666 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094668 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609466A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609466C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609466E rts ; nop
}

void f_06094688(SH2Context& c) {
    ran[2247] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094688 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609468A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609468C sts.l pr,@-r15
    c.r[15] -= 20;  // 0609468E add #-20,r15
    c.r[14] = c.r[15];  // 06094690 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094692 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06094694 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094696 mov.l @(20,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06094698 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0609469A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0609469C mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0609469E mov.l r2,@(8,r14)
L_060946A0:
    c.r[1] = ld32(c.r[14] + 8);  // 060946A0 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060946A2 tst r1,r1
    if (!c.t) { goto L_060946AA; }  // 060946A4 bf 0x060946AA
    goto L_060946F0;  // 060946A6 bra 0x060946F0 ; nop
L_060946AA:
    c.r[1] = c.r[14];  // 060946AA mov r14,r1
    c.r[1] += 16;  // 060946AC add #16,r1
    c.r[2] = c.r[14];  // 060946AE mov r14,r2
    c.r[2] += 12;  // 060946B0 add #12,r2
    c.r[7] = ld32(c.r[14] + 8);  // 060946B2 mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 060946B4 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 060946B6 mov r1,r6
    c.r[5] = c.r[2];  // 060946B8 mov r2,r5
    c.r[4] = c.r[3];  // 060946BA mov r3,r4
    c.r[8] = ld32(0x06094700u);  // 060946BC mov.l 0x06094700,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060946C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060946C2u) return; }  // 060946BE jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 060946C2 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 060946C4 mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060946C6 cmp/gt r2,r1
    if (!c.t) { goto L_060946E6; }  // 060946C8 bf 0x060946E6
    c.r[1] = ld32(c.r[14] + 8);  // 060946CA mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 060946CC mov.l @(16,r1),r2
    c.r[1] = 0x0u;  // 060946CE mov #0,r1
    st32(c.r[2] + 8, c.r[1]);  // 060946D0 mov.l r1,@(8,r2)
    c.r[1] = ld32(c.r[14] + 8);  // 060946D2 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 060946D4 mov r1,r2
    c.r[1] += 44;  // 060946D6 add #44,r1
    c.r[3] = ld32(c.r[14] + 8);  // 060946D8 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 060946DA mov r3,r2
    c.r[3] += 44;  // 060946DC add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060946DE mov.b @r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060946FEu);  // 060946E0 mov.w 0x060946FE,r3
    c.r[3] &= c.r[2];  // 060946E2 and r2,r3
    st8(c.r[1], c.r[3]);  // 060946E4 mov.b r3,@r1
L_060946E6:
    c.r[1] = ld32(c.r[14] + 8);  // 060946E6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 060946E8 mov.l @(8,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 060946EA mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_060946A0;  // 060946EC bra 0x060946A0 ; nop
L_060946F0:
    c.r[14] += 20;  // 060946F0 add #20,r14
    c.r[15] = c.r[14];  // 060946F2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060946F4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060946F6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060946F8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060946FA rts ; nop
}

void f_06094704(SH2Context& c) {
    ran[2248] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094704 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094706 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094708 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609470A add #-8,r15
    c.r[14] = c.r[15];  // 0609470C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609470E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06094710 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06094712 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06094714 mov.l r2,@(4,r14)
L_06094716:
    c.r[1] = ld32(c.r[14] + 4);  // 06094716 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094718 tst r1,r1
    if (!c.t) { goto L_06094720; }  // 0609471A bf 0x06094720
    goto L_06094744;  // 0609471C bra 0x06094744 ; nop
L_06094720:
    c.r[2] = ld32(c.r[14] + 4);  // 06094720 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[2] + 16);  // 06094722 mov.l @(16,r2),r1
    c.r[6] = 0x0u;  // 06094724 mov #0,r6
    c.r[5] = 0x0u;  // 06094726 mov #0,r5
    c.r[4] = c.r[1];  // 06094728 mov r1,r4
    c.r[8] = ld32(0x06094754u);  // 0609472A mov.l 0x06094754,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094730u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094730u) return; }  // 0609472C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 06094730 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 06094732 mov r1,r4
    c.r[8] = ld32(0x06094758u);  // 06094734 mov.l 0x06094758,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609473Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609473Au) return; }  // 06094736 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0609473A mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 0609473C mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 0609473E mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_06094716;  // 06094740 bra 0x06094716 ; nop
L_06094744:
    c.r[14] += 8;  // 06094744 add #8,r14
    c.r[15] = c.r[14];  // 06094746 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094748 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609474A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609474C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609474E rts ; nop
}

void f_0609475C(SH2Context& c) {
    ran[2249] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609475C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609475E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094760 sts.l pr,@-r15
    c.r[15] -= 8;  // 06094762 add #-8,r15
    c.r[14] = c.r[15];  // 06094764 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094766 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06094768 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0609476A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609476C mov.l r2,@(4,r14)
L_0609476E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609476E mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094770 tst r1,r1
    if (!c.t) { goto L_06094778; }  // 06094772 bf 0x06094778
    goto L_060947CC;  // 06094774 bra 0x060947CC ; nop
L_06094778:
    c.r[1] = ld32(c.r[14] + 4);  // 06094778 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0609477A mov r1,r2
    c.r[1] += 44;  // 0609477C add #44,r1
    c.r[3] = ld32(c.r[14] + 4);  // 0609477E mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06094780 mov r3,r2
    c.r[3] += 44;  // 06094782 add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06094784 mov.b @r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060947DAu);  // 06094786 mov.w 0x060947DA,r3
    c.r[3] &= c.r[2];  // 06094788 and r2,r3
    st8(c.r[1], c.r[3]);  // 0609478A mov.b r3,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 0609478C mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0609478E mov r1,r2
    c.r[1] += 44;  // 06094790 add #44,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06094792 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06094794 mov r3,r2
    c.r[3] += 44;  // 06094796 add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06094798 mov.b @r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060947DCu);  // 0609479A mov.w 0x060947DC,r3
    c.r[3] &= c.r[2];  // 0609479C and r2,r3
    st8(c.r[1], c.r[3]);  // 0609479E mov.b r3,@r1
    c.r[2] = ld32(c.r[14] + 4);  // 060947A0 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060947A2 mov r2,r1
    c.r[2] += 44;  // 060947A4 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060947A6 mov.b @r2,r1
    c.r[2] = 0x2u;  // 060947A8 mov #2,r2
    c.r[2] &= c.r[1];  // 060947AA and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060947AC extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060947AE tst r1,r1
    if (c.t) { goto L_060947C2; }  // 060947B0 bt 0x060947C2
    c.r[2] = ld32(c.r[14] + 4);  // 060947B2 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[2] + 16);  // 060947B4 mov.l @(16,r2),r1
    c.r[6] = 0x0u;  // 060947B6 mov #0,r6
    c.r[5] = 0x0u;  // 060947B8 mov #0,r5
    c.r[4] = c.r[1];  // 060947BA mov r1,r4
    c.r[8] = ld32(0x060947E0u);  // 060947BC mov.l 0x060947E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060947C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060947C2u) return; }  // 060947BE jsr @r8 ; nop
L_060947C2:
    c.r[1] = ld32(c.r[14] + 4);  // 060947C2 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 060947C4 mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 060947C6 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0609476E;  // 060947C8 bra 0x0609476E ; nop
L_060947CC:
    c.r[14] += 8;  // 060947CC add #8,r14
    c.r[15] = c.r[14];  // 060947CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060947D0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060947D2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060947D4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060947D6 rts ; nop
}

void f_060947E4(SH2Context& c) {
    ran[2250] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060947E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060947E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060947E8 sts.l pr,@-r15
    c.r[15] -= 16;  // 060947EA add #-16,r15
    c.r[14] = c.r[15];  // 060947EC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060947EE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060947F0 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 060947F2 mov.l r6,@(8,r14)
    c.r[1] = 0x1u;  // 060947F4 mov #1,r1
    st32(c.r[14] + 12, c.r[1]);  // 060947F6 mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14]);  // 060947F8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 24);  // 060947FA mov.l @(24,r1),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060948E2u);  // 060947FC mov.w 0x060948E2,r1
    c.t = c.r[2] == c.r[1];  // 060947FE cmp/eq r1,r2
    if (!c.t) { goto L_06094812; }  // 06094800 bf 0x06094812
    c.r[4] = ld32(c.r[14]);  // 06094802 mov.l @r14,r4
    c.r[8] = ld32(0x060948E4u);  // 06094804 mov.l 0x060948E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609480Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609480Au) return; }  // 06094806 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 0609480A mov.l @r14,r4
    c.r[8] = ld32(0x060948E8u);  // 0609480C mov.l 0x060948E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094812u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094812u) return; }  // 0609480E jsr @r8 ; nop
L_06094812:
    c.r[0] = ld32(c.r[14] + 4);  // 06094812 mov.l @(4,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06094814 cmp/eq #-1,r0
    if (!c.t) { goto L_06094878; }  // 06094816 bf 0x06094878
    c.r[1] = ld32(c.r[14]);  // 06094818 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0609481A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609481C mov.l r2,@(4,r14)
L_0609481E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609481E mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094820 tst r1,r1
    if (!c.t) { goto L_06094828; }  // 06094822 bf 0x06094828
    goto L_0609485A;  // 06094824 bra 0x0609485A ; nop
L_06094828:
    c.r[2] = ld32(c.r[14] + 4);  // 06094828 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0609482A mov r2,r1
    c.r[2] += 44;  // 0609482C add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609482E mov.b @r2,r1
    c.r[2] = 0x8u;  // 06094830 mov #8,r2
    c.r[2] &= c.r[1];  // 06094832 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06094834 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094836 tst r1,r1
    if (!c.t) { goto L_06094850; }  // 06094838 bf 0x06094850
    c.r[2] = ld32(c.r[14] + 4);  // 0609483A mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0609483C mov r2,r1
    c.r[2] += 44;  // 0609483E add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06094840 mov.b @r2,r1
    c.r[2] = 0x2u;  // 06094842 mov #2,r2
    c.r[2] &= c.r[1];  // 06094844 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06094846 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094848 tst r1,r1
    if (!c.t) { goto L_06094850; }  // 0609484A bf 0x06094850
    goto L_0609485A;  // 0609484C bra 0x0609485A ; nop
L_06094850:
    c.r[1] = ld32(c.r[14] + 4);  // 06094850 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094852 mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06094854 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0609481E;  // 06094856 bra 0x0609481E ; nop
L_0609485A:
    c.r[1] = ld32(c.r[14]);  // 0609485A mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609485C mov.l @(4,r14),r2
    st32(c.r[1] + 8, c.r[2]);  // 0609485E mov.l r2,@(8,r1)
    c.r[1] = ld32(c.r[14]);  // 06094860 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094862 mov r1,r2
    c.r[1] += 56;  // 06094864 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06094866 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06094868 mov r3,r2
    c.r[3] += 56;  // 0609486A add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609486C mov.w @r3,r2
    c.r[3] = ld32(0x060948ECu);  // 0609486E mov.l 0x060948EC,r3
    c.r[2] &= c.r[3];  // 06094870 and r3,r2
    st16(c.r[1], c.r[2]);  // 06094872 mov.w r2,@r1
    goto L_060948C2;  // 06094874 bra 0x060948C2 ; nop
L_06094878:
    c.r[1] = ld32(c.r[14] + 4);  // 06094878 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609487A tst r1,r1
    if (c.t) { goto L_06094894; }  // 0609487C bt 0x06094894
    c.r[2] = ld32(c.r[14] + 4);  // 0609487E mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06094880 mov r2,r1
    c.r[2] += 44;  // 06094882 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06094884 mov.b @r2,r1
    c.r[2] = 0x2u;  // 06094886 mov #2,r2
    c.r[2] &= c.r[1];  // 06094888 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0609488A extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609488C tst r1,r1
    if (!c.t) { goto L_060948BE; }  // 0609488E bf 0x060948BE
    goto L_06094894;  // 06094890 bra 0x06094894 ; nop
L_06094894:
    c.r[1] = ld32(c.r[14] + 4);  // 06094894 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094896 tst r1,r1
    if (c.t) { goto L_060948A0; }  // 06094898 bt 0x060948A0
    c.r[1] = ld32(c.r[14] + 4);  // 0609489A mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609489C mov.l @(4,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 0609489E mov.l r2,@(4,r14)
L_060948A0:
    c.r[1] = ld32(c.r[14]);  // 060948A0 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060948A2 mov.l @(4,r14),r2
    st32(c.r[1] + 8, c.r[2]);  // 060948A4 mov.l r2,@(8,r1)
    c.r[1] = ld32(c.r[14]);  // 060948A6 mov.l @r14,r1
    c.r[2] = c.r[1];  // 060948A8 mov r1,r2
    c.r[1] += 56;  // 060948AA add #56,r1
    c.r[3] = ld32(c.r[14]);  // 060948AC mov.l @r14,r3
    c.r[2] = c.r[3];  // 060948AE mov r3,r2
    c.r[3] += 56;  // 060948B0 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060948B2 mov.w @r3,r2
    c.r[3] = 0x1u;  // 060948B4 mov #1,r3
    c.r[3] |= c.r[2];  // 060948B6 or r2,r3
    st16(c.r[1], c.r[3]);  // 060948B8 mov.w r3,@r1
    goto L_060948C2;  // 060948BA bra 0x060948C2 ; nop
L_060948BE:
    c.r[1] = 0x0u;  // 060948BE mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 060948C0 mov.l r1,@(12,r14)
L_060948C2:
    c.r[1] = ld32(c.r[14]);  // 060948C2 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 8);  // 060948C4 mov.l @(8,r14),r2
    st32(c.r[1] + 44, c.r[2]);  // 060948C6 mov.l r2,@(44,r1)
    c.r[1] = ld32(c.r[14]);  // 060948C8 mov.l @r14,r1
    c.r[2] = 0x0u;  // 060948CA mov #0,r2
    st32(c.r[1] + 48, c.r[2]);  // 060948CC mov.l r2,@(48,r1)
    c.r[0] = ld32(c.r[14] + 12);  // 060948CE mov.l @(12,r14),r0
    goto L_060948D4;  // 060948D0 bra 0x060948D4 ; nop
L_060948D4:
    c.r[14] += 16;  // 060948D4 add #16,r14
    c.r[15] = c.r[14];  // 060948D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060948D8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060948DA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060948DC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060948DE rts ; nop
}

void f_060948F0(SH2Context& c) {
    ran[2251] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060948F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060948F2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060948F4 sts.l pr,@-r15
    c.r[15] -= 16;  // 060948F6 add #-16,r15
    c.r[14] = c.r[15];  // 060948F8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060948FA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060948FC mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 060948FE mov.l r6,@(8,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609496Au);  // 06094900 mov.w 0x0609496A,r1
    c.r[4] = c.r[1];  // 06094902 mov r1,r4
    c.r[8] = ld32(0x0609496Cu);  // 06094904 mov.l 0x0609496C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609490Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609490Au) return; }  // 06094906 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 0609490A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609490C tst r1,r1
    if (!c.t) { goto L_06094924; }  // 0609490E bf 0x06094924
    c.r[4] = 0xFFFFFFF5u;  // 06094910 mov #-11,r4
    c.r[8] = ld32(0x06094970u);  // 06094912 mov.l 0x06094970,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094918u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094918u) return; }  // 06094914 jsr @r8 ; nop
    c.r[8] = ld32(0x06094974u);  // 06094918 mov.l 0x06094974,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609491Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609491Eu) return; }  // 0609491A jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0609491E mov #0,r0
    goto L_0609495C;  // 06094920 bra 0x0609495C ; nop
L_06094924:
    c.r[1] = ld32(c.r[14] + 8);  // 06094924 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06094926 cmp/pz r1
    if (c.t) { goto L_0609493E; }  // 06094928 bt 0x0609493E
    c.r[4] = 0xFFFFFFF2u;  // 0609492A mov #-14,r4
    c.r[8] = ld32(0x06094970u);  // 0609492C mov.l 0x06094970,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094932u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094932u) return; }  // 0609492E jsr @r8 ; nop
    c.r[8] = ld32(0x06094974u);  // 06094932 mov.l 0x06094974,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094938u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094938u) return; }  // 06094934 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06094938 mov #0,r0
    goto L_0609495C;  // 0609493A bra 0x0609495C ; nop
L_0609493E:
    c.r[1] = ld32(c.r[14] + 8);  // 0609493E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094940 mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 06094942 mov r1,r6
    c.r[5] = c.r[2];  // 06094944 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 06094946 mov.l @r14,r4
    c.r[8] = ld32(0x06094978u);  // 06094948 mov.l 0x06094978,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609494Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609494Eu) return; }  // 0609494A jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609494E mov.l r0,@(12,r14)
    c.r[8] = ld32(0x0609497Cu);  // 06094950 mov.l 0x0609497C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094956u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094956u) return; }  // 06094952 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 06094956 mov.l @(12,r14),r0
    goto L_0609495C;  // 06094958 bra 0x0609495C ; nop
L_0609495C:
    c.r[14] += 16;  // 0609495C add #16,r14
    c.r[15] = c.r[14];  // 0609495E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094960 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094962 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094964 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094966 rts ; nop
}

void f_06094980(SH2Context& c) {
    ran[2252] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094980 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094982 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094984 sts.l pr,@-r15
    c.r[15] -= 20;  // 06094986 add #-20,r15
    c.r[14] = c.r[15];  // 06094988 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609498A mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0609498C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 0609498E mov.l @(20,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06094990 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06094992 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06094994 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06094996 mov.l r2,@(8,r14)
L_06094998:
    c.r[1] = ld32(c.r[14] + 8);  // 06094998 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609499A tst r1,r1
    if (!c.t) { goto L_060949A2; }  // 0609499C bf 0x060949A2
    goto L_06094A14;  // 0609499E bra 0x06094A14 ; nop
L_060949A2:
    c.r[1] = c.r[14];  // 060949A2 mov r14,r1
    c.r[1] += 16;  // 060949A4 add #16,r1
    c.r[2] = c.r[14];  // 060949A6 mov r14,r2
    c.r[2] += 12;  // 060949A8 add #12,r2
    c.r[7] = ld32(c.r[14] + 8);  // 060949AA mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 060949AC mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 060949AE mov r1,r6
    c.r[5] = c.r[2];  // 060949B0 mov r2,r5
    c.r[4] = c.r[3];  // 060949B2 mov r3,r4
    c.r[8] = ld32(0x06094A24u);  // 060949B4 mov.l 0x06094A24,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060949BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060949BAu) return; }  // 060949B6 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 060949BA mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 060949BC mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 060949BE cmp/ge r2,r1
    if (!c.t) { goto L_060949D8; }  // 060949C0 bf 0x060949D8
    c.r[2] = ld32(c.r[14] + 8);  // 060949C2 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 060949C4 mov r2,r1
    c.r[2] += 44;  // 060949C6 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060949C8 mov.b @r2,r1
    c.r[2] = 0x8u;  // 060949CA mov #8,r2
    c.r[2] &= c.r[1];  // 060949CC and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060949CE extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060949D0 tst r1,r1
    if (!c.t) { goto L_060949D8; }  // 060949D2 bf 0x060949D8
    goto L_060949EE;  // 060949D4 bra 0x060949EE ; nop
L_060949D8:
    c.r[2] = ld32(c.r[14] + 8);  // 060949D8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 060949DA mov r2,r1
    c.r[2] += 44;  // 060949DC add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060949DE mov.b @r2,r1
    c.r[2] = 0x2u;  // 060949E0 mov #2,r2
    c.r[2] &= c.r[1];  // 060949E2 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060949E4 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060949E6 tst r1,r1
    if (!c.t) { goto L_060949EE; }  // 060949E8 bf 0x060949EE
    goto L_06094A0A;  // 060949EA bra 0x06094A0A ; nop
L_060949EE:
    c.r[1] = ld32(c.r[14] + 8);  // 060949EE mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 060949F0 mov r1,r2
    c.r[1] += 44;  // 060949F2 add #44,r1
    c.r[3] = ld32(c.r[14] + 8);  // 060949F4 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 060949F6 mov r3,r2
    c.r[3] += 44;  // 060949F8 add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060949FA mov.b @r3,r2
    c.r[3] = 0x1u;  // 060949FC mov #1,r3
    c.r[3] |= c.r[2];  // 060949FE or r2,r3
    st8(c.r[1], c.r[3]);  // 06094A00 mov.b r3,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 06094A02 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06094A04 mov.l @(16,r1),r2
    c.r[1] = 0x1u;  // 06094A06 mov #1,r1
    st32(c.r[2] + 8, c.r[1]);  // 06094A08 mov.l r1,@(8,r2)
L_06094A0A:
    c.r[1] = ld32(c.r[14] + 8);  // 06094A0A mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094A0C mov.l @(8,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06094A0E mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06094998;  // 06094A10 bra 0x06094998 ; nop
L_06094A14:
    c.r[14] += 20;  // 06094A14 add #20,r14
    c.r[15] = c.r[14];  // 06094A16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094A18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094A1A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094A1C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094A1E rts ; nop
}

void f_06094A28(SH2Context& c) {
    ran[2253] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094A28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094A2A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094A2C sts.l pr,@-r15
    c.r[15] -= 28;  // 06094A2E add #-28,r15
    c.r[14] = c.r[15];  // 06094A30 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094A32 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06094A34 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094A36 mov.l @(20,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06094A38 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06094A3A mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06094A3C mov.l @(4,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06094A3E mov.l r2,@(8,r14)
L_06094A40:
    c.r[1] = ld32(c.r[14] + 8);  // 06094A40 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094A42 tst r1,r1
    if (!c.t) { goto L_06094A4A; }  // 06094A44 bf 0x06094A4A
    goto L_06094AF2;  // 06094A46 bra 0x06094AF2 ; nop
L_06094A4A:
    c.r[1] = c.r[14];  // 06094A4A mov r14,r1
    c.r[1] += 16;  // 06094A4C add #16,r1
    c.r[2] = c.r[14];  // 06094A4E mov r14,r2
    c.r[2] += 12;  // 06094A50 add #12,r2
    c.r[7] = ld32(c.r[14] + 8);  // 06094A52 mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06094A54 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06094A56 mov r1,r6
    c.r[5] = c.r[2];  // 06094A58 mov r2,r5
    c.r[4] = c.r[3];  // 06094A5A mov r3,r4
    c.r[8] = ld32(0x06094B00u);  // 06094A5C mov.l 0x06094B00,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094A62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094A62u) return; }  // 06094A5E jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 06094A62 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094A64 mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06094A66 cmp/ge r2,r1
    if (c.t) { goto L_06094AE8; }  // 06094A68 bt 0x06094AE8
    c.r[2] = ld32(c.r[14] + 8);  // 06094A6A mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06094A6C mov r2,r1
    c.r[2] += 44;  // 06094A6E add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06094A70 mov.b @r2,r1
    c.r[2] = 0x1u;  // 06094A72 mov #1,r2
    c.r[2] &= c.r[1];  // 06094A74 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06094A76 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094A78 tst r1,r1
    if (c.t) { goto L_06094AE8; }  // 06094A7A bt 0x06094AE8
    c.r[2] = ld32(c.r[14] + 8);  // 06094A7C mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06094A7E mov r2,r1
    c.r[2] += 44;  // 06094A80 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06094A82 mov.b @r2,r1
    c.r[2] = 0x4u;  // 06094A84 mov #4,r2
    c.r[2] &= c.r[1];  // 06094A86 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06094A88 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094A8A tst r1,r1
    if (c.t) { goto L_06094AE8; }  // 06094A8C bt 0x06094AE8
    c.r[1] = ld32(c.r[14] + 8);  // 06094A8E mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06094A90 mov r1,r2
    c.r[1] += 44;  // 06094A92 add #44,r1
    c.r[3] = ld32(c.r[14] + 8);  // 06094A94 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 06094A96 mov r3,r2
    c.r[3] += 44;  // 06094A98 add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06094A9A mov.b @r3,r2
    c.r[3] = 0x8u;  // 06094A9C mov #8,r3
    c.r[3] |= c.r[2];  // 06094A9E or r2,r3
    st8(c.r[1], c.r[3]);  // 06094AA0 mov.b r3,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 06094AA2 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06094AA4 mov r1,r4
    c.r[8] = ld32(0x06094B04u);  // 06094AA6 mov.l 0x06094B04,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094AACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094AACu) return; }  // 06094AA8 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06094AAC mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094AAE mov.l @(8,r1),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06094AB0 mov.l @(8,r14),r1
    c.t = c.r[2] == c.r[1];  // 06094AB2 cmp/eq r1,r2
    if (!c.t) { goto L_06094AD6; }  // 06094AB4 bf 0x06094AD6
    c.r[1] = ld32(c.r[14]);  // 06094AB6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 44);  // 06094AB8 mov.l @(44,r1),r2
    st32(c.r[14] + 20, c.r[2]);  // 06094ABA mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14]);  // 06094ABC mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 48);  // 06094ABE mov.l @(48,r1),r2
    st32(c.r[14] + 24, c.r[2]);  // 06094AC0 mov.l r2,@(24,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06094AC2 mov.l @(20,r14),r1
    c.r[6] = c.r[1];  // 06094AC4 mov r1,r6
    c.r[5] = 0xFFFFFFFFu;  // 06094AC6 mov #-1,r5
    c.r[4] = ld32(c.r[14]);  // 06094AC8 mov.l @r14,r4
    c.r[8] = ld32(0x06094B08u);  // 06094ACA mov.l 0x06094B08,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094AD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094AD0u) return; }  // 06094ACC jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06094AD0 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 24);  // 06094AD2 mov.l @(24,r14),r2
    st32(c.r[1] + 48, c.r[2]);  // 06094AD4 mov.l r2,@(48,r1)
L_06094AD6:
    c.r[1] = ld32(c.r[14]);  // 06094AD6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 12);  // 06094AD8 mov.l @(12,r1),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06094ADA mov.l @(8,r14),r1
    c.t = c.r[2] == c.r[1];  // 06094ADC cmp/eq r1,r2
    if (!c.t) { goto L_06094AE8; }  // 06094ADE bf 0x06094AE8
    c.r[4] = ld32(c.r[14]);  // 06094AE0 mov.l @r14,r4
    c.r[8] = ld32(0x06094B0Cu);  // 06094AE2 mov.l 0x06094B0C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094AE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094AE8u) return; }  // 06094AE4 jsr @r8 ; nop
L_06094AE8:
    c.r[1] = ld32(c.r[14] + 8);  // 06094AE8 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 06094AEA mov.l @(12,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06094AEC mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06094A40;  // 06094AEE bra 0x06094A40 ; nop
L_06094AF2:
    c.r[14] += 28;  // 06094AF2 add #28,r14
    c.r[15] = c.r[14];  // 06094AF4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094AF6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094AF8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094AFA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094AFC rts ; nop
}

void f_06094B10(SH2Context& c) {
    ran[2254] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094B10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094B12 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094B14 sts.l pr,@-r15
    c.r[15] -= 20;  // 06094B16 add #-20,r15
    c.r[14] = c.r[15];  // 06094B18 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094B1A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06094B1C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06094B1E mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094B20 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1] + 20);  // 06094B22 mov.l @(20,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06094B24 cmp/ge r1,r2
    if (c.t) { goto L_06094B2E; }  // 06094B26 bt 0x06094B2E
    c.r[1] = ld32(c.r[14]);  // 06094B28 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094B2A mov.l @(20,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06094B2C mov.l r2,@(4,r14)
L_06094B2E:
    ;  // 06094B2E nop
    c.r[1] = ld32(c.r[14]);  // 06094B30 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06094B32 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06094B34 mov.l r2,@(8,r14)
L_06094B36:
    c.r[1] = ld32(c.r[14] + 8);  // 06094B36 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094B38 tst r1,r1
    if (!c.t) { goto L_06094B40; }  // 06094B3A bf 0x06094B40
    goto L_06094B96;  // 06094B3C bra 0x06094B96 ; nop
L_06094B40:
    c.r[2] = ld32(c.r[14] + 8);  // 06094B40 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06094B42 mov r2,r1
    c.r[2] += 44;  // 06094B44 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06094B46 mov.b @r2,r1
    c.r[2] = 0x8u;  // 06094B48 mov #8,r2
    c.r[2] &= c.r[1];  // 06094B4A and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06094B4C extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094B4E tst r1,r1
    if (!c.t) { goto L_06094B8C; }  // 06094B50 bf 0x06094B8C
    c.r[1] = c.r[14];  // 06094B52 mov r14,r1
    c.r[1] += 16;  // 06094B54 add #16,r1
    c.r[2] = c.r[14];  // 06094B56 mov r14,r2
    c.r[2] += 12;  // 06094B58 add #12,r2
    c.r[7] = ld32(c.r[14] + 8);  // 06094B5A mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06094B5C mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06094B5E mov r1,r6
    c.r[5] = c.r[2];  // 06094B60 mov r2,r5
    c.r[4] = c.r[3];  // 06094B62 mov r3,r4
    c.r[8] = ld32(0x06094BACu);  // 06094B64 mov.l 0x06094BAC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094B6Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094B6Au) return; }  // 06094B66 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 06094B6A mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094B6C mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06094B6E cmp/gt r2,r1
    if (c.t) { goto L_06094B7E; }  // 06094B70 bt 0x06094B7E
    c.r[1] = ld32(c.r[14] + 16);  // 06094B72 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094B74 mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06094B76 cmp/ge r2,r1
    if (!c.t) { goto L_06094B7E; }  // 06094B78 bf 0x06094B7E
    goto L_06094B96;  // 06094B7A bra 0x06094B96 ; nop
L_06094B7E:
    c.r[1] = ld32(c.r[14] + 12);  // 06094B7E mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094B80 mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06094B82 cmp/gt r2,r1
    if (!c.t) { goto L_06094B8C; }  // 06094B84 bf 0x06094B8C
    c.r[0] = ld32(c.r[14] + 12);  // 06094B86 mov.l @(12,r14),r0
    goto L_06094B9C;  // 06094B88 bra 0x06094B9C ; nop
L_06094B8C:
    c.r[1] = ld32(c.r[14] + 8);  // 06094B8C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094B8E mov.l @(8,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06094B90 mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06094B36;  // 06094B92 bra 0x06094B36 ; nop
L_06094B96:
    c.r[0] = 0xFFFFFFFFu;  // 06094B96 mov #-1,r0
    goto L_06094B9C;  // 06094B98 bra 0x06094B9C ; nop
L_06094B9C:
    c.r[14] += 20;  // 06094B9C add #20,r14
    c.r[15] = c.r[14];  // 06094B9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094BA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094BA2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094BA4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094BA6 rts ; nop
}

void f_06094BB0(SH2Context& c) {
    ran[2255] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094BB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094BB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094BB4 sts.l pr,@-r15
    c.r[15] -= 12;  // 06094BB6 add #-12,r15
    c.r[14] = c.r[15];  // 06094BB8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094BBA mov.l r4,@r14
    c.r[1] = c.r[14];  // 06094BBC mov r14,r1
    c.r[1] += 8;  // 06094BBE add #8,r1
    c.r[2] = c.r[14];  // 06094BC0 mov r14,r2
    c.r[2] += 4;  // 06094BC2 add #4,r2
    c.r[3] = ld32(c.r[14]);  // 06094BC4 mov.l @r14,r3
    c.r[7] = ld32(c.r[3] + 8);  // 06094BC6 mov.l @(8,r3),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06094BC8 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06094BCA mov r1,r6
    c.r[5] = c.r[2];  // 06094BCC mov r2,r5
    c.r[4] = c.r[3];  // 06094BCE mov r3,r4
    c.r[8] = ld32(0x06094BECu);  // 06094BD0 mov.l 0x06094BEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094BD6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094BD6u) return; }  // 06094BD2 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 4);  // 06094BD6 mov.l @(4,r14),r0
    goto L_06094BDC;  // 06094BD8 bra 0x06094BDC ; nop
L_06094BDC:
    c.r[14] += 12;  // 06094BDC add #12,r14
    c.r[15] = c.r[14];  // 06094BDE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094BE0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094BE2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094BE4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094BE6 rts ; nop
}

void f_06094BF0(SH2Context& c) {
    ran[2256] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094BF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094BF2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094BF4 sts.l pr,@-r15
    c.r[15] -= 24;  // 06094BF6 add #-24,r15
    c.r[14] = c.r[15];  // 06094BF8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094BFA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06094BFC mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06094BFE mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06094C00 mov.l r7,@(12,r14)
    c.r[1] = 0x0u;  // 06094C02 mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 06094C04 mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14]);  // 06094C06 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06094C08 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 48);  // 06094C0A mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[2] + 44);  // 06094C0C mov.l @(44,r2),r2
    c.t = c.r[1] == c.r[2];  // 06094C0E cmp/eq r2,r1
    if (!c.t) { goto L_06094C7C; }  // 06094C10 bf 0x06094C7C
    c.r[1] = ld32(c.r[14]);  // 06094C12 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094C14 mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06094C16 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06094C18 cmp/gt r1,r2
    if (!c.t) { goto L_06094C36; }  // 06094C1A bf 0x06094C36
    c.r[1] = ld32(c.r[14] + 36);  // 06094C1C mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094C1E mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094C20 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 40);  // 06094C22 mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094C24 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094C26 mov.l r2,@r1
    c.r[1] = 0x1u;  // 06094C28 mov #1,r1
    st32(c.r[14] + 16, c.r[1]);  // 06094C2A mov.l r1,@(16,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 06094C2C mov.l @(16,r14),r0
    goto L_06094F02;  // 06094C2E bra 0x06094F02 ; nop
L_06094C36:
    c.r[1] = ld32(c.r[14] + 12);  // 06094C36 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094C38 tst r1,r1
    if (!c.t) { goto L_06094C78; }  // 06094C3A bf 0x06094C78
    c.r[5] = 0x0u;  // 06094C3C mov #0,r5
    c.r[4] = 0x0u;  // 06094C3E mov #0,r4
    c.r[8] = ld32(0x06094E3Cu);  // 06094C40 mov.l 0x06094E3C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094C46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094C46u) return; }  // 06094C42 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06094C46 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06094C48 mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 06094C4A mov r1,r4
    c.r[8] = ld32(0x06094E40u);  // 06094C4C mov.l 0x06094E40,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094C52u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094C52u) return; }  // 06094C4E jsr @r8 ; nop
    c.r[2] = ld32(0x06094E44u);  // 06094C52 mov.l 0x06094E44,r2
    c.r[1] = ld32(c.r[2]);  // 06094C54 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094C56 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1] + 24);  // 06094C58 mov.l @(24,r1),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06094C5A cmp/gt r1,r2
    if (!c.t) { goto L_06094C78; }  // 06094C5C bf 0x06094C78
    c.r[8] = ld32(0x06094E48u);  // 06094C5E mov.l 0x06094E48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094C64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094C64u) return; }  // 06094C60 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06094C64 mov.l @r14,r1
    st32(c.r[1] + 20, c.r[0]);  // 06094C66 mov.l r0,@(20,r1)
    c.r[2] = ld32(c.r[14]);  // 06094C68 mov.l @r14,r2
    c.r[1] = ld32(c.r[14]);  // 06094C6A mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06094C6C mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 48);  // 06094C6E mov.l @(48,r2),r3
    c.r[2] = c.r[3];  // 06094C70 mov r3,r2
    c.r[2] -= 1;  // 06094C72 add #-1,r2
    c.r[3] = c.r[2];  // 06094C74 mov r2,r3
    st32(c.r[1] + 48, c.r[3]);  // 06094C76 mov.l r3,@(48,r1)
L_06094C78:
    goto L_06094CDA;  // 06094C78 bra 0x06094CDA ; nop
L_06094C7C:
    c.r[1] = ld32(c.r[14]);  // 06094C7C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094C7E mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06094C80 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06094C82 cmp/gt r1,r2
    if (!c.t) { goto L_06094C9C; }  // 06094C84 bf 0x06094C9C
    c.r[2] = ld32(c.r[14]);  // 06094C86 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06094C88 mov r2,r1
    c.r[2] += 56;  // 06094C8A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094C8C mov.w @r2,r1
    c.r[2] = 0x2u;  // 06094C8E mov #2,r2
    c.r[2] &= c.r[1];  // 06094C90 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094C92 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094C94 tst r1,r1
    if (!c.t) { goto L_06094C9C; }  // 06094C96 bf 0x06094C9C
    goto L_06094CA8;  // 06094C98 bra 0x06094CA8 ; nop
L_06094C9C:
    c.r[1] = ld32(c.r[14]);  // 06094C9C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06094C9E mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06094CA0 tst r2,r2
    if (!c.t) { goto L_06094CDA; }  // 06094CA2 bf 0x06094CDA
    goto L_06094CA8;  // 06094CA4 bra 0x06094CA8 ; nop
L_06094CA8:
    c.r[1] = ld32(c.r[14]);  // 06094CA8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094CAA mov.l @(8,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06094CAC tst r2,r2
    if (!c.t) { goto L_06094CC6; }  // 06094CAE bf 0x06094CC6
    c.r[1] = ld32(c.r[14] + 36);  // 06094CB0 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094CB2 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094CB4 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 40);  // 06094CB6 mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094CB8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094CBA mov.l r2,@r1
    c.r[1] = 0x1u;  // 06094CBC mov #1,r1
    st32(c.r[14] + 16, c.r[1]);  // 06094CBE mov.l r1,@(16,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 06094CC0 mov.l @(16,r14),r0
    goto L_06094F02;  // 06094CC2 bra 0x06094F02 ; nop
L_06094CC6:
    c.r[4] = ld32(c.r[14]);  // 06094CC6 mov.l @r14,r4
    c.r[8] = ld32(0x06094E4Cu);  // 06094CC8 mov.l 0x06094E4C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094CCEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094CCEu) return; }  // 06094CCA jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06094CCE mov.l @r14,r1
    st32(c.r[1] + 20, c.r[0]);  // 06094CD0 mov.l r0,@(20,r1)
    c.r[4] = ld32(c.r[14]);  // 06094CD2 mov.l @r14,r4
    c.r[8] = ld32(0x06094E50u);  // 06094CD4 mov.l 0x06094E50,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094CDAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094CDAu) return; }  // 06094CD6 jsr @r8 ; nop
L_06094CDA:
    c.r[2] = ld32(c.r[14]);  // 06094CDA mov.l @r14,r2
    c.r[1] = c.r[2];  // 06094CDC mov r2,r1
    c.r[2] += 56;  // 06094CDE add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094CE0 mov.w @r2,r1
    c.r[2] = 0x2u;  // 06094CE2 mov #2,r2
    c.r[2] &= c.r[1];  // 06094CE4 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094CE6 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094CE8 tst r1,r1
    if (c.t) { goto L_06094CF0; }  // 06094CEA bt 0x06094CF0
    goto L_06094D44;  // 06094CEC bra 0x06094D44 ; nop
L_06094CF0:
    c.r[1] = ld32(c.r[14]);  // 06094CF0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 06094CF2 mov.l @(52,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06094CF4 cmp/pz r2
    if (c.t) { goto L_06094CFC; }  // 06094CF6 bt 0x06094CFC
    goto L_06094D34;  // 06094CF8 bra 0x06094D34 ; nop
L_06094CFC:
    c.r[1] = ld32(c.r[14]);  // 06094CFC mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094CFE mov.l @(20,r1),r2
    c.r[5] = c.r[2];  // 06094D00 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 06094D02 mov.l @r14,r4
    c.r[8] = ld32(0x06094E54u);  // 06094D04 mov.l 0x06094E54,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094D0Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094D0Au) return; }  // 06094D06 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 36);  // 06094D0A mov.l @(36,r14),r1
    st32(c.r[1], c.r[0]);  // 06094D0C mov.l r0,@r1
    c.r[1] = ld32(c.r[14] + 36);  // 06094D0E mov.l @(36,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06094D10 mov.l @r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06094D12 cmp/pz r2
    if (!c.t) { goto L_06094D1E; }  // 06094D14 bf 0x06094D1E
    c.r[1] = ld32(c.r[14]);  // 06094D16 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 36);  // 06094D18 mov.l @(36,r14),r2
    c.r[3] = ld32(c.r[2]);  // 06094D1A mov.l @r2,r3
    st32(c.r[1] + 20, c.r[3]);  // 06094D1C mov.l r3,@(20,r1)
L_06094D1E:
    c.r[1] = ld32(c.r[14] + 40);  // 06094D1E mov.l @(40,r14),r1
    c.r[2] = 0x1u;  // 06094D20 mov #1,r2
    st32(c.r[1], c.r[2]);  // 06094D22 mov.l r2,@r1
    c.r[1] = ld32(c.r[14]);  // 06094D24 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06094E38u);  // 06094D26 mov.w 0x06094E38,r2
    st32(c.r[1] + 24, c.r[2]);  // 06094D28 mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14] + 36);  // 06094D2A mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094D2C mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094D2E mov.l r2,@r1
    goto L_06094D40;  // 06094D30 bra 0x06094D40 ; nop
L_06094D34:
    c.r[1] = ld32(c.r[14] + 36);  // 06094D34 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094D36 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094D38 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 40);  // 06094D3A mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094D3C mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094D3E mov.l r2,@r1
L_06094D40:
    goto L_06094EFC;  // 06094D40 bra 0x06094EFC ; nop
L_06094D44:
    c.r[2] = ld32(c.r[14]);  // 06094D44 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06094D46 mov r2,r1
    c.r[2] += 56;  // 06094D48 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094D4A mov.w @r2,r1
    c.r[2] = 0x4u;  // 06094D4C mov #4,r2
    c.r[2] &= c.r[1];  // 06094D4E and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094D50 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094D52 tst r1,r1
    if (!c.t) { goto L_06094D5A; }  // 06094D54 bf 0x06094D5A
    goto L_06094EF0;  // 06094D56 bra 0x06094EF0 ; nop
L_06094D5A:
    c.r[1] = ld32(c.r[14] + 4);  // 06094D5A mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06094D5C mov.l @(8,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06094D5E cmp/gt r2,r1
    if (!c.t) { goto L_06094D66; }  // 06094D60 bf 0x06094D66
    goto L_06094E60;  // 06094D62 bra 0x06094E60 ; nop
L_06094D66:
    c.r[5] = 0x0u;  // 06094D66 mov #0,r5
    c.r[4] = 0x0u;  // 06094D68 mov #0,r4
    c.r[8] = ld32(0x06094E3Cu);  // 06094D6A mov.l 0x06094E3C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094D70u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094D70u) return; }  // 06094D6C jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06094D70 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06094D72 mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 06094D74 mov r1,r4
    c.r[8] = ld32(0x06094E40u);  // 06094D76 mov.l 0x06094E40,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094D7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094D7Cu) return; }  // 06094D78 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 06094D7C mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094D7E tst r1,r1
    if (c.t) { goto L_06094D86; }  // 06094D80 bt 0x06094D86
    goto L_06094DBA;  // 06094D82 bra 0x06094DBA ; nop
L_06094D86:
    c.r[2] = ld32(0x06094E44u);  // 06094D86 mov.l 0x06094E44,r2
    c.r[1] = ld32(c.r[2]);  // 06094D88 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094D8A mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1] + 24);  // 06094D8C mov.l @(24,r1),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06094D8E cmp/gt r1,r2
    if (c.t) { goto L_06094D96; }  // 06094D90 bt 0x06094D96
    goto L_06094DBA;  // 06094D92 bra 0x06094DBA ; nop
L_06094D96:
    c.r[1] = ld32(c.r[14]);  // 06094D96 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094D98 mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06094D9A mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14]);  // 06094D9C mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094D9E mov r1,r2
    c.r[1] += 56;  // 06094DA0 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06094DA2 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06094DA4 mov r3,r2
    c.r[3] += 56;  // 06094DA6 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094DA8 mov.w @r3,r2
    c.r[3] = ld32(0x06094E58u);  // 06094DAA mov.l 0x06094E58,r3
    c.r[2] &= c.r[3];  // 06094DAC and r3,r2
    st16(c.r[1], c.r[2]);  // 06094DAE mov.w r2,@r1
    c.r[1] = ld32(c.r[14] + 36);  // 06094DB0 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094DB2 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094DB4 mov.l r2,@r1
    goto L_06094E2E;  // 06094DB6 bra 0x06094E2E ; nop
L_06094DBA:
    c.r[1] = ld32(c.r[14]);  // 06094DBA mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094DBC mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06094DBE mov.l r2,@(20,r1)
    c.r[2] = ld32(c.r[14]);  // 06094DC0 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06094DC2 mov r2,r1
    c.r[2] += 56;  // 06094DC4 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094DC6 mov.w @r2,r1
    c.r[2] = 0x20u;  // 06094DC8 mov #32,r2
    c.r[2] &= c.r[1];  // 06094DCA and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094DCC extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094DCE tst r1,r1
    if (c.t) { goto L_06094DD6; }  // 06094DD0 bt 0x06094DD6
    goto L_06094E0A;  // 06094DD2 bra 0x06094E0A ; nop
L_06094DD6:
    c.r[1] = ld32(c.r[14] + 4);  // 06094DD6 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06094DD8 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06094DDA mov.l @r14,r4
    c.r[8] = ld32(0x06094E54u);  // 06094DDC mov.l 0x06094E54,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094DE2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094DE2u) return; }  // 06094DDE jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 36);  // 06094DE2 mov.l @(36,r14),r1
    st32(c.r[1], c.r[0]);  // 06094DE4 mov.l r0,@r1
    c.r[1] = ld32(c.r[14] + 36);  // 06094DE6 mov.l @(36,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06094DE8 mov.l @r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06094DEA cmp/pz r2
    if (c.t) { goto L_06094DF2; }  // 06094DEC bt 0x06094DF2
    goto L_06094E06;  // 06094DEE bra 0x06094E06 ; nop
L_06094DF2:
    c.r[1] = ld32(c.r[14]);  // 06094DF2 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094DF4 mov r1,r2
    c.r[1] += 56;  // 06094DF6 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06094DF8 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06094DFA mov r3,r2
    c.r[3] += 56;  // 06094DFC add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094DFE mov.w @r3,r2
    c.r[3] = 0x20u;  // 06094E00 mov #32,r3
    c.r[3] |= c.r[2];  // 06094E02 or r2,r3
    st16(c.r[1], c.r[3]);  // 06094E04 mov.w r3,@r1
L_06094E06:
    goto L_06094E2E;  // 06094E06 bra 0x06094E2E ; nop
L_06094E0A:
    c.r[0] = ld32(c.r[14] + 12);  // 06094E0A mov.l @(12,r14),r0
    c.t = c.r[0] == 0x2u;  // 06094E0C cmp/eq #2,r0
    if (!c.t) { goto L_06094E14; }  // 06094E0E bf 0x06094E14
    goto L_06094E28;  // 06094E10 bra 0x06094E28 ; nop
L_06094E14:
    c.r[1] = ld32(c.r[14]);  // 06094E14 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094E16 mov r1,r2
    c.r[1] += 56;  // 06094E18 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06094E1A mov.l @r14,r3
    c.r[2] = c.r[3];  // 06094E1C mov r3,r2
    c.r[3] += 56;  // 06094E1E add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094E20 mov.w @r3,r2
    c.r[3] = ld32(0x06094E5Cu);  // 06094E22 mov.l 0x06094E5C,r3
    c.r[2] &= c.r[3];  // 06094E24 and r3,r2
    st16(c.r[1], c.r[2]);  // 06094E26 mov.w r2,@r1
L_06094E28:
    c.r[1] = ld32(c.r[14] + 36);  // 06094E28 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094E2A mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094E2C mov.l r2,@r1
L_06094E2E:
    c.r[1] = ld32(c.r[14] + 40);  // 06094E2E mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094E30 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094E32 mov.l r2,@r1
    goto L_06094EEC;  // 06094E34 bra 0x06094EEC ; nop
L_06094E60:
    c.r[1] = ld32(c.r[14] + 12);  // 06094E60 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094E62 tst r1,r1
    if (c.t) { goto L_06094E6A; }  // 06094E64 bt 0x06094E6A
    goto L_06094EE0;  // 06094E66 bra 0x06094EE0 ; nop
L_06094E6A:
    c.r[1] = ld32(c.r[14]);  // 06094E6A mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094E6C mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06094E6E mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14]);  // 06094E70 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094E72 mov r1,r2
    c.r[1] += 56;  // 06094E74 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06094E76 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06094E78 mov r3,r2
    c.r[3] += 56;  // 06094E7A add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094E7C mov.w @r3,r2
    c.r[3] = ld32(0x06094F10u);  // 06094E7E mov.l 0x06094F10,r3
    c.r[2] &= c.r[3];  // 06094E80 and r3,r2
    st16(c.r[1], c.r[2]);  // 06094E82 mov.w r2,@r1
    c.r[4] = ld32(c.r[14]);  // 06094E84 mov.l @r14,r4
    c.r[8] = ld32(0x06094F14u);  // 06094E86 mov.l 0x06094F14,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094E8Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094E8Cu) return; }  // 06094E88 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 06094E8C mov.l @r14,r4
    c.r[8] = ld32(0x06094F18u);  // 06094E8E mov.l 0x06094F18,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094E94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094E94u) return; }  // 06094E90 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 06094E94 tst r0,r0
    if (c.t) { goto L_06094E9C; }  // 06094E96 bt 0x06094E9C
    goto L_06094EAC;  // 06094E98 bra 0x06094EAC ; nop
L_06094E9C:
    c.r[2] = ld32(c.r[14]);  // 06094E9C mov.l @r14,r2
    c.r[1] = ld32(c.r[14]);  // 06094E9E mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06094EA0 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 48);  // 06094EA2 mov.l @(48,r2),r3
    c.r[2] = c.r[3];  // 06094EA4 mov r3,r2
    c.r[2] += 1;  // 06094EA6 add #1,r2
    c.r[3] = c.r[2];  // 06094EA8 mov r2,r3
    st32(c.r[1] + 48, c.r[3]);  // 06094EAA mov.l r3,@(48,r1)
L_06094EAC:
    c.r[1] = ld32(c.r[14] + 40);  // 06094EAC mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094EAE mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094EB0 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 36);  // 06094EB2 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094EB4 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094EB6 mov.l r2,@r1
    c.r[1] = ld32(c.r[14]);  // 06094EB8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06094EBA mov.l @(8,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06094EBC tst r2,r2
    if (!c.t) { goto L_06094EC4; }  // 06094EBE bf 0x06094EC4
    goto L_06094ED8;  // 06094EC0 bra 0x06094ED8 ; nop
L_06094EC4:
    c.r[1] = ld32(c.r[14]);  // 06094EC4 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06094EC6 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 48);  // 06094EC8 mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[2] + 44);  // 06094ECA mov.l @(44,r2),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06094ECC cmp/ge r2,r1
    if (!c.t) { goto L_06094ED4; }  // 06094ECE bf 0x06094ED4
    goto L_06094ED8;  // 06094ED0 bra 0x06094ED8 ; nop
L_06094ED4:
    goto L_06094EDC;  // 06094ED4 bra 0x06094EDC ; nop
L_06094ED8:
    c.r[1] = 0x1u;  // 06094ED8 mov #1,r1
    st32(c.r[14] + 16, c.r[1]);  // 06094EDA mov.l r1,@(16,r14)
L_06094EDC:
    goto L_06094EEC;  // 06094EDC bra 0x06094EEC ; nop
L_06094EE0:
    c.r[1] = ld32(c.r[14] + 36);  // 06094EE0 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094EE2 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094EE4 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 40);  // 06094EE6 mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094EE8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094EEA mov.l r2,@r1
L_06094EEC:
    goto L_06094EFC;  // 06094EEC bra 0x06094EFC ; nop
L_06094EF0:
    c.r[1] = ld32(c.r[14] + 36);  // 06094EF0 mov.l @(36,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06094EF2 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 06094EF4 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 40);  // 06094EF6 mov.l @(40,r14),r1
    c.r[2] = 0x0u;  // 06094EF8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06094EFA mov.l r2,@r1
L_06094EFC:
    c.r[0] = ld32(c.r[14] + 16);  // 06094EFC mov.l @(16,r14),r0
    goto L_06094F02;  // 06094EFE bra 0x06094F02 ; nop
L_06094F02:
    c.r[14] += 24;  // 06094F02 add #24,r14
    c.r[15] = c.r[14];  // 06094F04 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094F06 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094F08 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094F0A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094F0C rts ; nop
}

void f_06094F1C(SH2Context& c) {
    ran[2257] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094F1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094F1E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094F20 sts.l pr,@-r15
    c.r[15] -= 20;  // 06094F22 add #-20,r15
    c.r[14] = c.r[15];  // 06094F24 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094F26 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06094F28 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06094F2A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06094F2C mov.l r7,@(12,r14)
    c.r[1] = 0x0u;  // 06094F2E mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 06094F30 mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06094F32 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06094F34 cmp/pz r1
    if (!c.t) { goto L_06094F50; }  // 06094F36 bf 0x06094F50
    c.r[1] = ld32(c.r[14] + 4);  // 06094F38 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06094F3A mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06094F3C mov.l @r14,r4
    c.r[8] = ld32(0x06094FB4u);  // 06094F3E mov.l 0x06094FB4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094F44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094F44u) return; }  // 06094F40 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 06094F44 mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14]);  // 06094F46 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06094F48 mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06094F4A mov.l r2,@(20,r1)
    goto L_06094F9E;  // 06094F4C bra 0x06094F9E ; nop
L_06094F50:
    c.r[1] = ld32(c.r[14]);  // 06094F50 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06094F52 mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06094F54 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06094F56 cmp/gt r1,r2
    if (c.t) { goto L_06094F9E; }  // 06094F58 bt 0x06094F9E
    c.r[0] = ld32(c.r[14] + 12);  // 06094F5A mov.l @(12,r14),r0
    c.t = c.r[0] == 0x1u;  // 06094F5C cmp/eq #1,r0
    if (!c.t) { goto L_06094F9E; }  // 06094F5E bf 0x06094F9E
    c.r[2] = ld32(c.r[14]);  // 06094F60 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06094F62 mov r2,r1
    c.r[2] += 56;  // 06094F64 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094F66 mov.w @r2,r1
    c.r[2] = 0x2u;  // 06094F68 mov #2,r2
    c.r[2] &= c.r[1];  // 06094F6A and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094F6C extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094F6E tst r1,r1
    if (!c.t) { goto L_06094F9E; }  // 06094F70 bf 0x06094F9E
    c.r[4] = ld32(c.r[14]);  // 06094F72 mov.l @r14,r4
    c.r[8] = ld32(0x06094FB8u);  // 06094F74 mov.l 0x06094FB8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094F7Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094F7Au) return; }  // 06094F76 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 06094F7A mov.l @r14,r4
    c.r[8] = ld32(0x06094FBCu);  // 06094F7C mov.l 0x06094FBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094F82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094F82u) return; }  // 06094F7E jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 06094F82 mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 06094F84 mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094F86 tst r1,r1
    if (!c.t) { goto L_06094F9E; }  // 06094F88 bf 0x06094F9E
    c.r[1] = ld32(c.r[14]);  // 06094F8A mov.l @r14,r1
    c.r[2] = c.r[1];  // 06094F8C mov r1,r2
    c.r[1] += 56;  // 06094F8E add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06094F90 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06094F92 mov r3,r2
    c.r[3] += 56;  // 06094F94 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06094F96 mov.w @r3,r2
    c.r[3] = 0x2u;  // 06094F98 mov #2,r3
    c.r[3] |= c.r[2];  // 06094F9A or r2,r3
    st16(c.r[1], c.r[3]);  // 06094F9C mov.w r3,@r1
L_06094F9E:
    c.r[0] = ld32(c.r[14] + 16);  // 06094F9E mov.l @(16,r14),r0
    goto L_06094FA4;  // 06094FA0 bra 0x06094FA4 ; nop
L_06094FA4:
    c.r[14] += 20;  // 06094FA4 add #20,r14
    c.r[15] = c.r[14];  // 06094FA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06094FA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06094FAA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06094FAC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06094FAE rts ; nop
}

void f_06094FC0(SH2Context& c) {
    ran[2258] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06094FC0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06094FC2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06094FC4 sts.l pr,@-r15
    c.r[15] -= 32;  // 06094FC6 add #-32,r15
    c.r[14] = c.r[15];  // 06094FC8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06094FCA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06094FCC mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06094FCE mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06094FD0 mov.l r7,@(12,r14)
    c.r[4] = ld32(c.r[14]);  // 06094FD2 mov.l @r14,r4
    c.r[8] = ld32(0x060950ACu);  // 06094FD4 mov.l 0x060950AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06094FDAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06094FDAu) return; }  // 06094FD6 jsr @r8 ; nop
    c.t = c.r[0] == 0x1u;  // 06094FDA cmp/eq #1,r0
    if (!c.t) { goto L_06095048; }  // 06094FDC bf 0x06095048
    c.r[1] = ld32(c.r[14]);  // 06094FDE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 24);  // 06094FE0 mov.l @(24,r1),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060950A6u);  // 06094FE2 mov.w 0x060950A6,r1
    c.t = c.r[2] == c.r[1];  // 06094FE4 cmp/eq r1,r2
    if (c.t) { goto L_06094FFE; }  // 06094FE6 bt 0x06094FFE
    c.r[2] = ld32(c.r[14]);  // 06094FE8 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06094FEA mov r2,r1
    c.r[2] += 56;  // 06094FEC add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06094FEE mov.w @r2,r1
    c.r[2] = 0x40u;  // 06094FF0 mov #64,r2
    c.r[2] &= c.r[1];  // 06094FF2 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06094FF4 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06094FF6 tst r1,r1
    if (!c.t) { goto L_06094FFE; }  // 06094FF8 bf 0x06094FFE
    goto L_06095042;  // 06094FFA bra 0x06095042 ; nop
L_06094FFE:
    c.r[1] = ld32(c.r[14]);  // 06094FFE mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06095000 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095002 tst r2,r2
    if (c.t) { goto L_06095042; }  // 06095004 bt 0x06095042
    c.r[1] = ld32(c.r[14]);  // 06095006 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06095008 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 48);  // 0609500A mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[2] + 44);  // 0609500C mov.l @(44,r2),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0609500E cmp/ge r2,r1
    if (c.t) { goto L_06095042; }  // 06095010 bt 0x06095042
    c.r[4] = ld32(c.r[14]);  // 06095012 mov.l @r14,r4
    c.r[8] = ld32(0x060950B0u);  // 06095014 mov.l 0x060950B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609501Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609501Au) return; }  // 06095016 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 0609501A mov.l @r14,r4
    c.r[8] = ld32(0x060950B4u);  // 0609501C mov.l 0x060950B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095022u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095022u) return; }  // 0609501E jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06095022 mov.l @r14,r1
    c.r[2] = ld32(0x060950B8u);  // 06095024 mov.l 0x060950B8,r2
    st32(c.r[1] + 20, c.r[2]);  // 06095026 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14]);  // 06095028 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060950A8u);  // 0609502A mov.w 0x060950A8,r2
    st32(c.r[1] + 24, c.r[2]);  // 0609502C mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14]);  // 0609502E mov.l @r14,r1
    c.r[2] = c.r[1];  // 06095030 mov r1,r2
    c.r[1] += 56;  // 06095032 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06095034 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06095036 mov r3,r2
    c.r[3] += 56;  // 06095038 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609503A mov.w @r3,r2
    c.r[3] = ld32(0x060950BCu);  // 0609503C mov.l 0x060950BC,r3
    c.r[2] &= c.r[3];  // 0609503E and r3,r2
    st16(c.r[1], c.r[2]);  // 06095040 mov.w r2,@r1
L_06095042:
    c.r[0] = 0x1u;  // 06095042 mov #1,r0
    goto L_06095098;  // 06095044 bra 0x06095098 ; nop
L_06095048:
    c.r[1] = ld32(c.r[14] + 12);  // 06095048 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609504A mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 0609504C mov.l @(4,r14),r3
    c.r[7] = c.r[14];  // 0609504E mov r14,r7
    c.r[7] += 20;  // 06095050 add #20,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06095052 mov.l r7,@-r15
    c.r[7] = c.r[14];  // 06095054 mov r14,r7
    c.r[7] += 16;  // 06095056 add #16,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06095058 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0609505A mov r1,r7
    c.r[6] = c.r[2];  // 0609505C mov r2,r6
    c.r[5] = c.r[3];  // 0609505E mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06095060 mov.l @r14,r4
    c.r[8] = ld32(0x060950C0u);  // 06095062 mov.l 0x060950C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095068u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095068u) return; }  // 06095064 jsr @r8 ; nop
    c.r[15] += 8;  // 06095068 add #8,r15
    st32(c.r[14] + 24, c.r[0]);  // 0609506A mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 0609506C mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0609506E mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 16);  // 06095070 mov.l @(16,r14),r3
    c.r[7] = c.r[1];  // 06095072 mov r1,r7
    c.r[6] = c.r[2];  // 06095074 mov r2,r6
    c.r[5] = c.r[3];  // 06095076 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06095078 mov.l @r14,r4
    c.r[8] = ld32(0x060950C4u);  // 0609507A mov.l 0x060950C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095080u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095080u) return; }  // 0609507C jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06095080 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06095082 mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095084 tst r1,r1
    if (c.t) { goto L_06095092; }  // 06095086 bt 0x06095092
    c.r[1] = ld32(c.r[14] + 28);  // 06095088 mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 0609508A mov r1,r4
    c.r[8] = ld32(0x060950C8u);  // 0609508C mov.l 0x060950C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095092u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095092u) return; }  // 0609508E jsr @r8 ; nop
L_06095092:
    c.r[0] = ld32(c.r[14] + 24);  // 06095092 mov.l @(24,r14),r0
    goto L_06095098;  // 06095094 bra 0x06095098 ; nop
L_06095098:
    c.r[14] += 32;  // 06095098 add #32,r14
    c.r[15] = c.r[14];  // 0609509A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609509C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609509E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060950A0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060950A2 rts ; nop
}

void f_060950CC(SH2Context& c) {
    ran[2259] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060950CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060950CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060950D0 sts.l pr,@-r15
    c.r[15] -= 12;  // 060950D2 add #-12,r15
    c.r[14] = c.r[15];  // 060950D4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060950D6 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060950D8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 060950DA mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 060950DC mov r2,r1
    c.r[1] += 28;  // 060950DE add #28,r1
    c.r[2] = ld32(c.r[1]);  // 060950E0 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060950E2 tst r2,r2
    if (!c.t) { goto L_06095144; }  // 060950E4 bf 0x06095144
    c.r[1] = c.r[14];  // 060950E6 mov r14,r1
    c.r[1] += 4;  // 060950E8 add #4,r1
    c.r[2] = ld32(0x06095168u);  // 060950EA mov.l 0x06095168,r2
    c.r[3] = ld32(c.r[14]);  // 060950EC mov.l @r14,r3
    c.r[6] = ld32(c.r[3] + 20);  // 060950EE mov.l @(20,r3),r6
    c.r[7] = c.r[6];  // 060950F0 mov r6,r7
    c.r[7] += 28;  // 060950F2 add #28,r7
    c.r[3] = ld32(c.r[7] + 4);  // 060950F4 mov.l @(4,r7),r3
    c.r[7] = 0x0u;  // 060950F6 mov #0,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060950F8 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 060950FA mov r1,r7
    c.r[6] = c.r[2];  // 060950FC mov r2,r6
    c.r[5] = 0x0u;  // 060950FE mov #0,r5
    c.r[4] = c.r[3];  // 06095100 mov r3,r4
    c.r[8] = ld32(0x0609516Cu);  // 06095102 mov.l 0x0609516C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095108u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095108u) return; }  // 06095104 jsr @r8 ; nop
    c.r[15] += 4;  // 06095108 add #4,r15
    st32(c.r[14] + 8, c.r[0]);  // 0609510A mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609510C mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609510E tst r1,r1
    if (c.t) { goto L_06095122; }  // 06095110 bt 0x06095122
    c.r[1] = ld32(c.r[14] + 8);  // 06095112 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06095114 mov r1,r4
    c.r[8] = ld32(0x06095170u);  // 06095116 mov.l 0x06095170,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609511Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609511Cu) return; }  // 06095118 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0609511C mov #0,r0
    goto L_06095158;  // 0609511E bra 0x06095158 ; nop
L_06095122:
    c.r[8] = ld32(0x06095174u);  // 06095122 mov.l 0x06095174,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095128u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095128u) return; }  // 06095124 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06095128 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609512A mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609512C tst r1,r1
    if (c.t) { goto L_06095140; }  // 0609512E bt 0x06095140
    c.r[1] = ld32(c.r[14] + 8);  // 06095130 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06095132 mov r1,r4
    c.r[8] = ld32(0x06095170u);  // 06095134 mov.l 0x06095170,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609513Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609513Au) return; }  // 06095136 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0609513A mov #0,r0
    goto L_06095158;  // 0609513C bra 0x06095158 ; nop
L_06095140:
    goto L_06095152;  // 06095140 bra 0x06095152 ; nop
L_06095144:
    c.r[1] = ld32(c.r[14]);  // 06095144 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095146 mov.l @(16,r1),r2
    c.r[4] = c.r[2];  // 06095148 mov r2,r4
    c.r[8] = ld32(0x06095178u);  // 0609514A mov.l 0x06095178,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095150u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095150u) return; }  // 0609514C jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06095150 mov.l r0,@(4,r14)
L_06095152:
    c.r[0] = ld32(c.r[14] + 4);  // 06095152 mov.l @(4,r14),r0
    goto L_06095158;  // 06095154 bra 0x06095158 ; nop
L_06095158:
    c.r[14] += 12;  // 06095158 add #12,r14
    c.r[15] = c.r[14];  // 0609515A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609515C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609515E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095160 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095162 rts ; nop
}

void f_0609517C(SH2Context& c) {
    ran[2260] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609517C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609517E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095180 sts.l pr,@-r15
    c.r[15] -= 12;  // 06095182 add #-12,r15
    c.r[14] = c.r[15];  // 06095184 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095186 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060951E4u);  // 06095188 mov.w 0x060951E4,r1
    c.r[4] = c.r[1];  // 0609518A mov r1,r4
    c.r[8] = ld32(0x060951E8u);  // 0609518C mov.l 0x060951E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095192u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095192u) return; }  // 0609518E jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06095192 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095194 tst r1,r1
    if (!c.t) { goto L_060951AC; }  // 06095196 bf 0x060951AC
    c.r[4] = 0xFFFFFFF5u;  // 06095198 mov #-11,r4
    c.r[8] = ld32(0x060951ECu);  // 0609519A mov.l 0x060951EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060951A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060951A0u) return; }  // 0609519C jsr @r8 ; nop
    c.r[8] = ld32(0x060951F0u);  // 060951A0 mov.l 0x060951F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060951A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060951A6u) return; }  // 060951A2 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFF5u;  // 060951A6 mov #-11,r0
    goto L_060951D6;  // 060951A8 bra 0x060951D6 ; nop
L_060951AC:
    c.r[1] = ld32(c.r[14]);  // 060951AC mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060951AE mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 060951B0 mov.l r2,@r14
    c.r[4] = ld32(c.r[14]);  // 060951B2 mov.l @r14,r4
    c.r[8] = ld32(0x060951F4u);  // 060951B4 mov.l 0x060951F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060951BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060951BAu) return; }  // 060951B6 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060951BA mov.l r0,@(4,r14)
    c.r[8] = ld32(0x060951F8u);  // 060951BC mov.l 0x060951F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060951C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060951C2u) return; }  // 060951BE jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 060951C2 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060951C4 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060951C6 cmp/pz r1
    if (c.t) { goto L_060951D0; }  // 060951C8 bt 0x060951D0
    c.r[0] = ld32(c.r[14] + 8);  // 060951CA mov.l @(8,r14),r0
    goto L_060951D6;  // 060951CC bra 0x060951D6 ; nop
L_060951D0:
    c.r[0] = ld32(c.r[14] + 4);  // 060951D0 mov.l @(4,r14),r0
    goto L_060951D6;  // 060951D2 bra 0x060951D6 ; nop
L_060951D6:
    c.r[14] += 12;  // 060951D6 add #12,r14
    c.r[15] = c.r[14];  // 060951D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060951DA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060951DC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060951DE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060951E0 rts ; nop
}

void f_060951FC(SH2Context& c) {
    ran[2261] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060951FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060951FE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095200 sts.l pr,@-r15
    c.r[15] -= 32;  // 06095202 add #-32,r15
    c.r[14] = c.r[15];  // 06095204 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095206 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06095208 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609520A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0609520C mov.l r7,@(12,r14)
    c.r[1] = ld32(c.r[14]);  // 0609520E mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06095210 mov.l @r1,r2
    c.r[1] = ld32(c.r[2] + 20);  // 06095212 mov.l @(20,r2),r1
    st32(c.r[14] + 16, c.r[1]);  // 06095214 mov.l r1,@(16,r14)
    c.r[2] = ld32(c.r[14]);  // 06095216 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06095218 mov r2,r1
    c.r[2] += 44;  // 0609521A add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609521C mov.b @r2,r1
    c.r[2] = 0x8u;  // 0609521E mov #8,r2
    c.r[2] &= c.r[1];  // 06095220 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06095222 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095224 tst r1,r1
    if (c.t) { goto L_06095234; }  // 06095226 bt 0x06095234
    c.r[1] = ld32(c.r[14] + 12);  // 06095228 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609522A tst r1,r1
    if (!c.t) { goto L_06095234; }  // 0609522C bf 0x06095234
    c.r[0] = (uint32_t)(int16_t)ld16(0x06095300u);  // 0609522E mov.w 0x06095300,r0
    goto L_0609536C;  // 06095230 bra 0x0609536C ; nop
L_06095234:
    c.r[1] = ld32(c.r[14] + 16);  // 06095234 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06095236 mov.l @(8,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06095238 cmp/gt r2,r1
    if (!c.t) { goto L_06095240; }  // 0609523A bf 0x06095240
    goto L_060952C2;  // 0609523C bra 0x060952C2 ; nop
L_06095240:
    c.r[1] = ld32(c.r[14]);  // 06095240 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06095242 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06095244 mov r2,r1
    c.r[1] += 28;  // 06095246 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06095248 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609524A tst r2,r2
    if (c.t) { goto L_06095252; }  // 0609524C bt 0x06095252
    goto L_060952C2;  // 0609524E bra 0x060952C2 ; nop
L_06095252:
    c.r[2] = ld32(c.r[14]);  // 06095252 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06095254 mov r2,r1
    c.r[2] += 44;  // 06095256 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06095258 mov.b @r2,r1
    c.r[2] = 0x1u;  // 0609525A mov #1,r2
    c.r[2] &= c.r[1];  // 0609525C and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0609525E extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095260 tst r1,r1
    if (!c.t) { goto L_0609527A; }  // 06095262 bf 0x0609527A
    c.r[2] = ld32(c.r[14]);  // 06095264 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06095266 mov r2,r1
    c.r[2] += 44;  // 06095268 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609526A mov.b @r2,r1
    c.r[2] = 0x4u;  // 0609526C mov #4,r2
    c.r[2] &= c.r[1];  // 0609526E and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06095270 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095272 tst r1,r1
    if (!c.t) { goto L_060952B8; }  // 06095274 bf 0x060952B8
    goto L_0609527A;  // 06095276 bra 0x0609527A ; nop
L_0609527A:
    c.r[1] = c.r[14];  // 0609527A mov r14,r1
    c.r[1] += 24;  // 0609527C add #24,r1
    c.r[5] = c.r[1];  // 0609527E mov r1,r5
    c.r[4] = 0x0u;  // 06095280 mov #0,r4
    c.r[8] = ld32(0x06095308u);  // 06095282 mov.l 0x06095308,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095288u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095288u) return; }  // 06095284 jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06095288 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 0609528A mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 0609528C mov r1,r4
    c.r[8] = ld32(0x0609530Cu);  // 0609528E mov.l 0x0609530C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095294u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095294u) return; }  // 06095290 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 24);  // 06095294 mov.l @(24,r14),r2
    c.r[1] = 0x8u;  // 06095296 mov #8,r1
    c.r[1] &= c.r[2];  // 06095298 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609529A tst r1,r1
    if (!c.t) { goto L_060952A8; }  // 0609529C bf 0x060952A8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06095302u);  // 0609529E mov.w 0x06095302,r0
    goto L_0609536C;  // 060952A0 bra 0x0609536C ; nop
L_060952A8:
    c.r[1] = ld32(c.r[14] + 12);  // 060952A8 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060952AA tst r1,r1
    if (!c.t) { goto L_060952B4; }  // 060952AC bf 0x060952B4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06095304u);  // 060952AE mov.w 0x06095304,r0
    goto L_0609536C;  // 060952B0 bra 0x0609536C ; nop
L_060952B4:
    goto L_060952BE;  // 060952B4 bra 0x060952BE ; nop
L_060952B8:
    c.r[0] = 0x20u;  // 060952B8 mov #32,r0
    goto L_0609536C;  // 060952BA bra 0x0609536C ; nop
L_060952BE:
    goto L_060952E0;  // 060952BE bra 0x060952E0 ; nop
L_060952C2:
    c.r[2] = ld32(c.r[14]);  // 060952C2 mov.l @r14,r2
    c.r[1] = c.r[2];  // 060952C4 mov r2,r1
    c.r[2] += 44;  // 060952C6 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060952C8 mov.b @r2,r1
    c.r[2] = 0x1u;  // 060952CA mov #1,r2
    c.r[2] &= c.r[1];  // 060952CC and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060952CE extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060952D0 tst r1,r1
    if (c.t) { goto L_060952E0; }  // 060952D2 bt 0x060952E0
    c.r[1] = ld32(c.r[14] + 12);  // 060952D4 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060952D6 tst r1,r1
    if (!c.t) { goto L_060952E0; }  // 060952D8 bf 0x060952E0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06095300u);  // 060952DA mov.w 0x06095300,r0
    goto L_0609536C;  // 060952DC bra 0x0609536C ; nop
L_060952E0:
    c.r[1] = ld32(c.r[14]);  // 060952E0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 40);  // 060952E2 mov.l @(40,r1),r2
    c.r[1] = ld32(0x06095310u);  // 060952E4 mov.l 0x06095310,r1
    c.t = c.r[2] == c.r[1];  // 060952E6 cmp/eq r1,r2
    if (c.t) { goto L_060952EE; }  // 060952E8 bt 0x060952EE
    goto L_06095318;  // 060952EA bra 0x06095318 ; nop
L_060952EE:
    c.r[1] = ld32(c.r[14]);  // 060952EE mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 060952F0 mov.l @r1,r2
    c.r[4] = c.r[2];  // 060952F2 mov r2,r4
    c.r[8] = ld32(0x06095314u);  // 060952F4 mov.l 0x06095314,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060952FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060952FAu) return; }  // 060952F6 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 060952FA mov.l r0,@(20,r14)
    goto L_0609531E;  // 060952FC bra 0x0609531E ; nop
L_06095318:
    c.r[1] = ld32(c.r[14]);  // 06095318 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 40);  // 0609531A mov.l @(40,r1),r2
    st32(c.r[14] + 20, c.r[2]);  // 0609531C mov.l r2,@(20,r14)
L_0609531E:
    c.r[1] = ld32(c.r[14]);  // 0609531E mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095320 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06095322 mov r2,r1
    c.r[1] += 108;  // 06095324 add #108,r1
    c.r[2] = ld32(c.r[1] + 48);  // 06095326 mov.l @(48,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095328 tst r2,r2
    if (!c.t) { goto L_06095330; }  // 0609532A bf 0x06095330
    goto L_06095360;  // 0609532C bra 0x06095360 ; nop
L_06095330:
    c.r[1] = ld32(c.r[14] + 16);  // 06095330 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06095332 mov.l @(4,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06095334 cmp/ge r2,r1
    if (c.t) { goto L_0609533C; }  // 06095336 bt 0x0609533C
    goto L_0609534C;  // 06095338 bra 0x0609534C ; nop
L_0609533C:
    c.r[1] = ld32(c.r[14] + 16);  // 0609533C mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 20);  // 0609533E mov.l @(20,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06095340 cmp/ge r2,r1
    if (c.t) { goto L_06095348; }  // 06095342 bt 0x06095348
    goto L_06095360;  // 06095344 bra 0x06095360 ; nop
L_06095348:
    goto L_0609534C;  // 06095348 bra 0x0609534C ; nop
L_0609534C:
    c.r[4] = ld32(c.r[14]);  // 0609534C mov.l @r14,r4
    c.r[8] = ld32(0x06095380u);  // 0609534E mov.l 0x06095380,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095354u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095354u) return; }  // 06095350 jsr @r8 ; nop
    c.t = c.r[0] == 0x1u;  // 06095354 cmp/eq #1,r0
    if (!c.t) { goto L_0609535C; }  // 06095356 bf 0x0609535C
    goto L_06095360;  // 06095358 bra 0x06095360 ; nop
L_0609535C:
    goto L_06095366;  // 0609535C bra 0x06095366 ; nop
L_06095360:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609537Au);  // 06095360 mov.w 0x0609537A,r0
    goto L_0609536C;  // 06095362 bra 0x0609536C ; nop
L_06095366:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609537Cu);  // 06095366 mov.w 0x0609537C,r0
    goto L_0609536C;  // 06095368 bra 0x0609536C ; nop
L_0609536C:
    c.r[14] += 32;  // 0609536C add #32,r14
    c.r[15] = c.r[14];  // 0609536E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095370 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095372 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095374 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095376 rts ; nop
}

void f_06095384(SH2Context& c) {
    ran[2262] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095384 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095386 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095388 sts.l pr,@-r15
    c.r[15] -= 12;  // 0609538A add #-12,r15
    c.r[14] = c.r[15];  // 0609538C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609538E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06095390 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095392 mov.l @(16,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06095394 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06095396 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 24);  // 06095398 mov.l @(24,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609539A tst r2,r2
    if (!c.t) { goto L_060953AE; }  // 0609539C bf 0x060953AE
    c.r[2] = ld32(c.r[14] + 4);  // 0609539E mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060953A0 mov r2,r1
    c.r[1] += 108;  // 060953A2 add #108,r1
    c.r[2] = ld32(c.r[1]);  // 060953A4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060953A6 tst r2,r2
    if (!c.t) { goto L_060953AE; }  // 060953A8 bf 0x060953AE
    goto L_060953D4;  // 060953AA bra 0x060953D4 ; nop
L_060953AE:
    c.r[2] = ld32(c.r[14] + 4);  // 060953AE mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060953B0 mov r2,r1
    c.r[1] += 108;  // 060953B2 add #108,r1
    c.r[4] = c.r[1];  // 060953B4 mov r1,r4
    c.r[8] = ld32(0x060953ECu);  // 060953B6 mov.l 0x060953EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060953BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060953BCu) return; }  // 060953B8 jsr @r8 ; nop
    c.t = (int32_t)c.r[0] > 0;  // 060953BC cmp/pl r0
    if (!c.t) { goto L_060953D4; }  // 060953BE bf 0x060953D4
    c.r[1] = c.r[14];  // 060953C0 mov r14,r1
    c.r[1] += 8;  // 060953C2 add #8,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060953C4 mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 060953C6 mov r1,r5
    c.r[4] = c.r[2];  // 060953C8 mov r2,r4
    c.r[8] = ld32(0x060953F0u);  // 060953CA mov.l 0x060953F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060953D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060953D0u) return; }  // 060953CC jsr @r8 ; nop
    goto L_060953D8;  // 060953D0 bra 0x060953D8 ; nop
L_060953D4:
    c.r[1] = 0x0u;  // 060953D4 mov #0,r1
    st32(c.r[14] + 8, c.r[1]);  // 060953D6 mov.l r1,@(8,r14)
L_060953D8:
    c.r[0] = ld32(c.r[14] + 8);  // 060953D8 mov.l @(8,r14),r0
    goto L_060953DE;  // 060953DA bra 0x060953DE ; nop
L_060953DE:
    c.r[14] += 12;  // 060953DE add #12,r14
    c.r[15] = c.r[14];  // 060953E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060953E2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060953E4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060953E6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060953E8 rts ; nop
}

void f_060953F4(SH2Context& c) {
    ran[2263] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060953F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060953F6 sts.l pr,@-r15
    c.r[15] -= 4;  // 060953F8 add #-4,r15
    c.r[14] = c.r[15];  // 060953FA mov r15,r14
    st32(c.r[14], c.r[4]);  // 060953FC mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060953FE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 36);  // 06095400 mov.l @(36,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095402 tst r2,r2
    if (c.t) { goto L_0609543A; }  // 06095404 bt 0x0609543A
    c.r[2] = ld32(c.r[14]);  // 06095406 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06095408 mov r2,r1
    c.r[2] += 56;  // 0609540A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609540C mov.w @r2,r1
    c.r[2] = 0x8u;  // 0609540E mov #8,r2
    c.r[2] &= c.r[1];  // 06095410 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06095412 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095414 tst r1,r1
    if (c.t) { goto L_0609543A; }  // 06095416 bt 0x0609543A
    c.r[1] = ld32(c.r[14]);  // 06095418 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 0609541A mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 40);  // 0609541C mov.l @(40,r2),r3
    c.r[1] = ld32(c.r[1] + 36);  // 0609541E mov.l @(36,r1),r1
    c.r[4] = c.r[3];  // 06095420 mov r3,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06095426u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095426u) return; }  // 06095422 jsr @r1 ; nop
    c.r[1] = ld32(c.r[14]);  // 06095426 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06095428 mov r1,r2
    c.r[1] += 56;  // 0609542A add #56,r1
    c.r[3] = ld32(c.r[14]);  // 0609542C mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609542E mov r3,r2
    c.r[3] += 56;  // 06095430 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06095432 mov.w @r3,r2
    c.r[3] = ld32(0x06095448u);  // 06095434 mov.l 0x06095448,r3
    c.r[2] &= c.r[3];  // 06095436 and r3,r2
    st16(c.r[1], c.r[2]);  // 06095438 mov.w r2,@r1
L_0609543A:
    c.r[14] += 4;  // 0609543A add #4,r14
    c.r[15] = c.r[14];  // 0609543C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609543E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095440 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095442 rts ; nop
}

void f_0609544C(SH2Context& c) {
    ran[2264] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609544C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609544E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06095450 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06095452 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06095454 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095456 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095458 sts.l pr,@-r15
    c.r[15] -= 56;  // 0609545A add #-56,r15
    c.r[14] = c.r[15];  // 0609545C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609545E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06095460 mov.l r5,@(4,r14)
    c.r[8] = c.r[6];  // 06095462 mov r6,r8
    st32(c.r[14] + 12, c.r[7]);  // 06095464 mov.l r7,@(12,r14)
    c.r[9] = c.r[14];  // 06095466 mov r14,r9
    c.r[10] = c.r[14];  // 06095468 mov r14,r10
    c.r[10] += 8;  // 0609546A add #8,r10
    st8(c.r[10], c.r[8]);  // 0609546C mov.b r8,@r10
    c.r[1] = 0x1u;  // 0609546E mov #1,r1
    st32(c.r[14] + 44, c.r[1]);  // 06095470 mov.l r1,@(44,r14)
    c.r[1] = 0x0u;  // 06095472 mov #0,r1
    st32(c.r[14] + 48, c.r[1]);  // 06095474 mov.l r1,@(48,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 06095476 mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 06095478 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609547A mov.l r2,@r1
    c.r[1] = ld32(c.r[14]);  // 0609547C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0609547E mov.l @(16,r1),r2
    st32(c.r[14] + 20, c.r[2]);  // 06095480 mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06095482 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06095484 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06095486 mov r2,r1
    c.r[1] += 28;  // 06095488 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 0609548A mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609548C tst r2,r2
    if (!c.t) { goto L_060954AC; }  // 0609548E bf 0x060954AC
    c.r[1] = c.r[14];  // 06095490 mov r14,r1
    c.r[1] += 36;  // 06095492 add #36,r1
    c.r[2] = c.r[14];  // 06095494 mov r14,r2
    c.r[2] += 32;  // 06095496 add #32,r2
    c.r[7] = ld32(c.r[14] + 20);  // 06095498 mov.l @(20,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 0609549A mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 0609549C mov r1,r6
    c.r[5] = c.r[2];  // 0609549E mov r2,r5
    c.r[4] = c.r[3];  // 060954A0 mov r3,r4
    c.r[11] = ld32(0x060955A4u);  // 060954A2 mov.l 0x060955A4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060954A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060954A8u) return; }  // 060954A4 jsr @r11 ; nop
    goto L_060954B4;  // 060954A8 bra 0x060954B4 ; nop
L_060954AC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060955A0u);  // 060954AC mov.w 0x060955A0,r1
    st32(c.r[14] + 36, c.r[1]);  // 060954AE mov.l r1,@(36,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060955A0u);  // 060954B0 mov.w 0x060955A0,r1
    st32(c.r[14] + 32, c.r[1]);  // 060954B2 mov.l r1,@(32,r14)
L_060954B4:
    c.r[2] = c.r[14];  // 060954B4 mov r14,r2
    c.r[1] = c.r[14];  // 060954B6 mov r14,r1
    c.r[1] += 52;  // 060954B8 add #52,r1
    c.r[3] = ld32(c.r[14] + 20);  // 060954BA mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 060954BC mov r3,r2
    c.r[3] += 44;  // 060954BE add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060954C0 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060954C2 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 20);  // 060954C4 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 060954C6 mov.l @(40,r1),r2
    c.r[1] = ld32(0x060955A8u);  // 060954C8 mov.l 0x060955A8,r1
    c.t = c.r[2] == c.r[1];  // 060954CA cmp/eq r1,r2
    if (!c.t) { goto L_060954DC; }  // 060954CC bf 0x060954DC
    c.r[4] = ld32(c.r[14]);  // 060954CE mov.l @r14,r4
    c.r[11] = ld32(0x060955ACu);  // 060954D0 mov.l 0x060955AC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060954D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060954D6u) return; }  // 060954D2 jsr @r11 ; nop
    st32(c.r[14] + 40, c.r[0]);  // 060954D6 mov.l r0,@(40,r14)
    goto L_060954E2;  // 060954D8 bra 0x060954E2 ; nop
L_060954DC:
    c.r[1] = ld32(c.r[14] + 20);  // 060954DC mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 060954DE mov.l @(40,r1),r2
    st32(c.r[14] + 40, c.r[2]);  // 060954E0 mov.l r2,@(40,r14)
L_060954E2:
    c.r[1] = c.r[14];  // 060954E2 mov r14,r1
    c.r[2] = c.r[14];  // 060954E4 mov r14,r2
    c.r[2] += 52;  // 060954E6 add #52,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060954E8 mov.b @r2,r1
    c.r[2] = 0x10u;  // 060954EA mov #16,r2
    c.r[2] &= c.r[1];  // 060954EC and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060954EE extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060954F0 tst r1,r1
    if (!c.t) { goto L_0609551C; }  // 060954F2 bf 0x0609551C
    c.r[1] = ld32(c.r[14]);  // 060954F4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 060954F6 mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 32);  // 060954F8 mov.l @(32,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060954FA cmp/gt r1,r2
    if (!c.t) { goto L_0609551C; }  // 060954FC bf 0x0609551C
    c.r[1] = ld32(c.r[14]);  // 060954FE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06095500 mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 40);  // 06095502 mov.l @(40,r14),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06095504 cmp/ge r1,r2
    if (!c.t) { goto L_0609551C; }  // 06095506 bf 0x0609551C
    c.r[1] = ld32(c.r[14] + 20);  // 06095508 mov.l @(20,r14),r1
    c.r[2] = c.r[1];  // 0609550A mov r1,r2
    c.r[1] += 44;  // 0609550C add #44,r1
    c.r[3] = ld32(c.r[14] + 20);  // 0609550E mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 06095510 mov r3,r2
    c.r[3] += 44;  // 06095512 add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06095514 mov.b @r3,r2
    c.r[3] = 0x10u;  // 06095516 mov #16,r3
    c.r[3] |= c.r[2];  // 06095518 or r2,r3
    st8(c.r[1], c.r[3]);  // 0609551A mov.b r3,@r1
L_0609551C:
    c.r[1] = c.r[14];  // 0609551C mov r14,r1
    c.r[2] = c.r[14];  // 0609551E mov r14,r2
    c.r[2] += 52;  // 06095520 add #52,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06095522 mov.b @r2,r1
    c.r[2] = 0x20u;  // 06095524 mov #32,r2
    c.r[2] &= c.r[1];  // 06095526 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06095528 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609552A tst r1,r1
    if (!c.t) { goto L_06095556; }  // 0609552C bf 0x06095556
    c.r[1] = ld32(c.r[14]);  // 0609552E mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06095530 mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 36);  // 06095532 mov.l @(36,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06095534 cmp/gt r1,r2
    if (!c.t) { goto L_06095556; }  // 06095536 bf 0x06095556
    c.r[1] = ld32(c.r[14]);  // 06095538 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 0609553A mov.l @(20,r1),r2
    c.r[1] = ld32(c.r[14] + 40);  // 0609553C mov.l @(40,r14),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609553E cmp/ge r1,r2
    if (!c.t) { goto L_06095556; }  // 06095540 bf 0x06095556
    c.r[1] = ld32(c.r[14] + 20);  // 06095542 mov.l @(20,r14),r1
    c.r[2] = c.r[1];  // 06095544 mov r1,r2
    c.r[1] += 44;  // 06095546 add #44,r1
    c.r[3] = ld32(c.r[14] + 20);  // 06095548 mov.l @(20,r14),r3
    c.r[2] = c.r[3];  // 0609554A mov r3,r2
    c.r[3] += 44;  // 0609554C add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609554E mov.b @r3,r2
    c.r[3] = 0x20u;  // 06095550 mov #32,r3
    c.r[3] |= c.r[2];  // 06095552 or r2,r3
    st8(c.r[1], c.r[3]);  // 06095554 mov.b r3,@r1
L_06095556:
    c.r[1] = c.r[14];  // 06095556 mov r14,r1
    c.r[2] = c.r[14];  // 06095558 mov r14,r2
    c.r[2] += 52;  // 0609555A add #52,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609555C mov.b @r2,r1
    c.r[2] = 0x20u;  // 0609555E mov #32,r2
    c.r[2] &= c.r[1];  // 06095560 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06095562 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095564 tst r1,r1
    if (!c.t) { goto L_060955B8; }  // 06095566 bf 0x060955B8
    c.r[2] = ld32(c.r[14] + 20);  // 06095568 mov.l @(20,r14),r2
    c.r[1] = c.r[2];  // 0609556A mov r2,r1
    c.r[2] += 44;  // 0609556C add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609556E mov.b @r2,r1
    c.r[2] = 0x20u;  // 06095570 mov #32,r2
    c.r[2] &= c.r[1];  // 06095572 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06095574 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095576 tst r1,r1
    if (c.t) { goto L_060955B8; }  // 06095578 bt 0x060955B8
    c.r[1] = ld32(c.r[14] + 20);  // 0609557A mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 0609557C mov.l @(16,r1),r2
    c.r[4] = c.r[2];  // 0609557E mov r2,r4
    c.r[11] = ld32(0x060955B0u);  // 06095580 mov.l 0x060955B0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06095586u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095586u) return; }  // 06095582 jsr @r11 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06095586 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06095588 mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[14] + 20);  // 0609558A mov.l @(20,r14),r2
    c.r[3] = ld32(c.r[2] + 16);  // 0609558C mov.l @(16,r2),r3
    c.r[2] = c.r[3];  // 0609558E mov r3,r2
    c.r[2] += 108;  // 06095590 add #108,r2
    c.r[5] = c.r[1];  // 06095592 mov r1,r5
    c.r[4] = c.r[2];  // 06095594 mov r2,r4
    c.r[11] = ld32(0x060955B4u);  // 06095596 mov.l 0x060955B4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609559Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609559Cu) return; }  // 06095598 jsr @r11 ; nop
    goto L_060955F0;  // 0609559C bra 0x060955F0 ; nop
L_060955B8:
    c.r[1] = c.r[14];  // 060955B8 mov r14,r1
    c.r[2] = c.r[14];  // 060955BA mov r14,r2
    c.r[2] += 52;  // 060955BC add #52,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060955BE mov.b @r2,r1
    c.r[2] = 0x10u;  // 060955C0 mov #16,r2
    c.r[2] &= c.r[1];  // 060955C2 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060955C4 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060955C6 tst r1,r1
    if (!c.t) { goto L_060955F0; }  // 060955C8 bf 0x060955F0
    c.r[2] = ld32(c.r[14] + 20);  // 060955CA mov.l @(20,r14),r2
    c.r[1] = c.r[2];  // 060955CC mov r2,r1
    c.r[2] += 44;  // 060955CE add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060955D0 mov.b @r2,r1
    c.r[2] = 0x10u;  // 060955D2 mov #16,r2
    c.r[2] &= c.r[1];  // 060955D4 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060955D6 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060955D8 tst r1,r1
    if (c.t) { goto L_060955F0; }  // 060955DA bt 0x060955F0
    c.r[1] = ld32(0x060957BCu);  // 060955DC mov.l 0x060957BC,r1
    c.r[2] = ld32(c.r[14] + 20);  // 060955DE mov.l @(20,r14),r2
    c.r[3] = ld32(c.r[2] + 16);  // 060955E0 mov.l @(16,r2),r3
    c.r[2] = c.r[3];  // 060955E2 mov r3,r2
    c.r[2] += 108;  // 060955E4 add #108,r2
    c.r[5] = c.r[1];  // 060955E6 mov r1,r5
    c.r[4] = c.r[2];  // 060955E8 mov r2,r4
    c.r[11] = ld32(0x060957C0u);  // 060955EA mov.l 0x060957C0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060955F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060955F0u) return; }  // 060955EC jsr @r11 ; nop
L_060955F0:
    c.r[1] = ld32(c.r[14] + 20);  // 060955F0 mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 060955F2 mov r1,r4
    c.r[11] = ld32(0x060957C4u);  // 060955F4 mov.l 0x060957C4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060955FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060955FAu) return; }  // 060955F6 jsr @r11 ; nop
    c.r[1] = ld32(c.r[14] + 20);  // 060955FA mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 060955FC mov r1,r4
    c.r[11] = ld32(0x060957C8u);  // 060955FE mov.l 0x060957C8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06095604u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095604u) return; }  // 06095600 jsr @r11 ; nop
    c.t = c.r[0] == 0x1u;  // 06095604 cmp/eq #1,r0
    if (c.t) { goto L_0609560C; }  // 06095606 bt 0x0609560C
    goto L_06095634;  // 06095608 bra 0x06095634 ; nop
L_0609560C:
    c.r[1] = ld32(c.r[14] + 12);  // 0609560C mov.l @(12,r14),r1
    c.r[2] = 0x1u;  // 0609560E mov #1,r2
    st32(c.r[1], c.r[2]);  // 06095610 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 36);  // 06095612 mov.l @(36,r14),r1
    c.r[2] = ld32(c.r[14] + 32);  // 06095614 mov.l @(32,r14),r2
    c.r[3] = ld32(c.r[14] + 20);  // 06095616 mov.l @(20,r14),r3
    c.r[7] = 0x1u;  // 06095618 mov #1,r7
    c.r[6] = c.r[1];  // 0609561A mov r1,r6
    c.r[5] = c.r[2];  // 0609561C mov r2,r5
    c.r[4] = c.r[3];  // 0609561E mov r3,r4
    c.r[11] = ld32(0x060957CCu);  // 06095620 mov.l 0x060957CC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06095626u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095626u) return; }  // 06095622 jsr @r11 ; nop
    c.r[12] = 0x54u;  // 06095626 mov #84,r12
    c.r[12] += c.r[14];  // 06095628 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 0609562A mov.l @r12,r1
    st32(c.r[1], c.r[0]);  // 0609562C mov.l r0,@r1
    c.r[0] = 0x0u;  // 0609562E mov #0,r0
    goto L_06095802;  // 06095630 bra 0x06095802 ; nop
L_06095634:
    c.r[1] = ld32(c.r[14] + 20);  // 06095634 mov.l @(20,r14),r1
    st32(c.r[14] + 24, c.r[1]);  // 06095636 mov.l r1,@(24,r14)
    c.r[1] = 0x0u;  // 06095638 mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 0609563A mov.l r1,@(16,r14)
L_0609563C:
    c.r[1] = ld32(c.r[14] + 16);  // 0609563C mov.l @(16,r14),r1
    c.r[2] = 0x1u;  // 0609563E mov #1,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06095640 cmp/gt r2,r1
    if (!c.t) { goto L_06095648; }  // 06095642 bf 0x06095648
    goto L_06095656;  // 06095644 bra 0x06095656 ; nop
L_06095648:
    c.r[0] = ld32(c.r[14] + 48);  // 06095648 mov.l @(48,r14),r0
    c.t = c.r[0] == 0x1u;  // 0609564A cmp/eq #1,r0
    if (c.t) { goto L_06095652; }  // 0609564C bt 0x06095652
    goto L_0609565A;  // 0609564E bra 0x0609565A ; nop
L_06095652:
    goto L_06095656;  // 06095652 bra 0x06095656 ; nop
L_06095656:
    goto L_060957D8;  // 06095656 bra 0x060957D8 ; nop
L_0609565A:
    c.r[1] = ld32(c.r[14] + 20);  // 0609565A mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 0609565C mov.l @(8,r1),r2
    st32(c.r[14] + 20, c.r[2]);  // 0609565E mov.l r2,@(20,r14)
L_06095660:
    c.r[1] = ld32(c.r[14] + 20);  // 06095660 mov.l @(20,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095662 tst r1,r1
    if (c.t) { goto L_0609566A; }  // 06095664 bt 0x0609566A
    goto L_06095670;  // 06095666 bra 0x06095670 ; nop
L_0609566A:
    c.r[1] = ld32(c.r[14]);  // 0609566A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0609566C mov.l @r1,r2
    st32(c.r[14] + 20, c.r[2]);  // 0609566E mov.l r2,@(20,r14)
L_06095670:
    c.r[1] = ld32(c.r[14] + 20);  // 06095670 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06095672 mov.l @(4,r14),r2
    c.t = c.r[1] == c.r[2];  // 06095674 cmp/eq r2,r1
    if (c.t) { goto L_0609567C; }  // 06095676 bt 0x0609567C
    goto L_06095682;  // 06095678 bra 0x06095682 ; nop
L_0609567C:
    c.r[1] = ld32(c.r[14] + 12);  // 0609567C mov.l @(12,r14),r1
    c.r[2] = 0x1u;  // 0609567E mov #1,r2
    st32(c.r[1], c.r[2]);  // 06095680 mov.l r2,@r1
L_06095682:
    c.r[1] = ld32(c.r[14] + 20);  // 06095682 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095684 mov.l @(16,r1),r2
    c.r[4] = c.r[2];  // 06095686 mov r2,r4
    c.r[11] = ld32(0x060957D0u);  // 06095688 mov.l 0x060957D0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609568Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609568Eu) return; }  // 0609568A jsr @r11 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 0609568E mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06095690 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06095692 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06095694 mov r2,r1
    c.r[1] += 28;  // 06095696 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06095698 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609569A tst r2,r2
    if (c.t) { goto L_060956A2; }  // 0609569C bt 0x060956A2
    goto L_060956BE;  // 0609569E bra 0x060956BE ; nop
L_060956A2:
    c.r[1] = c.r[14];  // 060956A2 mov r14,r1
    c.r[1] += 36;  // 060956A4 add #36,r1
    c.r[2] = c.r[14];  // 060956A6 mov r14,r2
    c.r[2] += 32;  // 060956A8 add #32,r2
    c.r[7] = ld32(c.r[14] + 20);  // 060956AA mov.l @(20,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 060956AC mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 060956AE mov r1,r6
    c.r[5] = c.r[2];  // 060956B0 mov r2,r5
    c.r[4] = c.r[3];  // 060956B2 mov r3,r4
    c.r[11] = ld32(0x060957D4u);  // 060956B4 mov.l 0x060957D4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060956BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060956BAu) return; }  // 060956B6 jsr @r11 ; nop
    goto L_060956C6;  // 060956BA bra 0x060956C6 ; nop
L_060956BE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060957B4u);  // 060956BE mov.w 0x060957B4,r1
    st32(c.r[14] + 36, c.r[1]);  // 060956C0 mov.l r1,@(36,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060957B4u);  // 060956C2 mov.w 0x060957B4,r1
    st32(c.r[14] + 32, c.r[1]);  // 060956C4 mov.l r1,@(32,r14)
L_060956C6:
    c.r[1] = ld32(c.r[14] + 28);  // 060956C6 mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[14] + 36);  // 060956C8 mov.l @(36,r14),r2
    c.r[3] = ld32(c.r[14] + 32);  // 060956CA mov.l @(32,r14),r3
    c.r[4] = ld32(c.r[14] + 20);  // 060956CC mov.l @(20,r14),r4
    c.r[7] = c.r[1];  // 060956CE mov r1,r7
    c.r[6] = c.r[2];  // 060956D0 mov r2,r6
    c.r[5] = c.r[3];  // 060956D2 mov r3,r5
    c.r[11] = ld32(0x060957CCu);  // 060956D4 mov.l 0x060957CC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060956DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060956DAu) return; }  // 060956D6 jsr @r11 ; nop
    c.r[12] = 0x54u;  // 060956DA mov #84,r12
    c.r[12] += c.r[14];  // 060956DC add r14,r12
    c.r[1] = ld32(c.r[12]);  // 060956DE mov.l @r12,r1
    st32(c.r[1], c.r[0]);  // 060956E0 mov.l r0,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 060956E2 mov.l @(28,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 060956E4 cmp/pl r1
    if (!c.t) { goto L_060956EC; }  // 060956E6 bf 0x060956EC
    goto L_06095714;  // 060956E8 bra 0x06095714 ; nop
L_060956EC:
    c.r[1] = c.r[14];  // 060956EC mov r14,r1
    c.r[2] = c.r[14];  // 060956EE mov r14,r2
    c.r[2] += 8;  // 060956F0 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060956F2 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060956F4 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 060956F6 cmp/eq #2,r0
    if (!c.t) { goto L_060956FE; }  // 060956F8 bf 0x060956FE
    goto L_06095714;  // 060956FA bra 0x06095714 ; nop
L_060956FE:
    c.r[1] = c.r[14];  // 060956FE mov r14,r1
    c.r[2] = c.r[14];  // 06095700 mov r14,r2
    c.r[2] += 8;  // 06095702 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06095704 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06095706 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06095708 cmp/eq #1,r0
    if (!c.t) { goto L_06095710; }  // 0609570A bf 0x06095710
    goto L_06095714;  // 0609570C bra 0x06095714 ; nop
L_06095710:
    goto L_06095760;  // 06095710 bra 0x06095760 ; nop
L_06095714:
    c.r[1] = ld32(c.r[14] + 16);  // 06095714 mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095716 tst r1,r1
    if (c.t) { goto L_0609571E; }  // 06095718 bt 0x0609571E
    goto L_06095734;  // 0609571A bra 0x06095734 ; nop
L_0609571E:
    c.r[12] = 0x54u;  // 0609571E mov #84,r12
    c.r[12] += c.r[14];  // 06095720 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 06095722 mov.l @r12,r1
    c.r[2] = ld32(c.r[1]);  // 06095724 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060957B6u);  // 06095726 mov.w 0x060957B6,r1
    c.t = c.r[2] == c.r[1];  // 06095728 cmp/eq r1,r2
    if (!c.t) { goto L_06095730; }  // 0609572A bf 0x06095730
    goto L_06095754;  // 0609572C bra 0x06095754 ; nop
L_06095730:
    goto L_06095734;  // 06095730 bra 0x06095734 ; nop
L_06095734:
    c.r[0] = ld32(c.r[14] + 16);  // 06095734 mov.l @(16,r14),r0
    c.t = c.r[0] == 0x1u;  // 06095736 cmp/eq #1,r0
    if (c.t) { goto L_0609573E; }  // 06095738 bt 0x0609573E
    goto L_06095760;  // 0609573A bra 0x06095760 ; nop
L_0609573E:
    c.r[12] = 0x54u;  // 0609573E mov #84,r12
    c.r[12] += c.r[14];  // 06095740 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 06095742 mov.l @r12,r1
    c.r[2] = ld32(c.r[1]);  // 06095744 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060957B8u);  // 06095746 mov.w 0x060957B8,r1
    c.t = c.r[2] == c.r[1];  // 06095748 cmp/eq r1,r2
    if (!c.t) { goto L_06095750; }  // 0609574A bf 0x06095750
    goto L_06095754;  // 0609574C bra 0x06095754 ; nop
L_06095750:
    goto L_06095760;  // 06095750 bra 0x06095760 ; nop
L_06095754:
    c.r[1] = 0x0u;  // 06095754 mov #0,r1
    st32(c.r[14] + 44, c.r[1]);  // 06095756 mov.l r1,@(44,r14)
    c.r[1] = 0x1u;  // 06095758 mov #1,r1
    st32(c.r[14] + 48, c.r[1]);  // 0609575A mov.l r1,@(48,r14)
    goto L_060957A6;  // 0609575C bra 0x060957A6 ; nop
L_06095760:
    c.r[12] = 0x54u;  // 06095760 mov #84,r12
    c.r[12] += c.r[14];  // 06095762 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 06095764 mov.l @r12,r1
    c.r[2] = ld32(c.r[1]);  // 06095766 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060957B6u);  // 06095768 mov.w 0x060957B6,r1
    c.t = c.r[2] == c.r[1];  // 0609576A cmp/eq r1,r2
    if (!c.t) { goto L_06095772; }  // 0609576C bf 0x06095772
    goto L_06095788;  // 0609576E bra 0x06095788 ; nop
L_06095772:
    c.r[12] = 0x54u;  // 06095772 mov #84,r12
    c.r[12] += c.r[14];  // 06095774 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 06095776 mov.l @r12,r1
    c.r[2] = ld32(c.r[1]);  // 06095778 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060957B8u);  // 0609577A mov.w 0x060957B8,r1
    c.t = c.r[2] == c.r[1];  // 0609577C cmp/eq r1,r2
    if (!c.t) { goto L_06095784; }  // 0609577E bf 0x06095784
    goto L_06095788;  // 06095780 bra 0x06095788 ; nop
L_06095784:
    goto L_0609578C;  // 06095784 bra 0x0609578C ; nop
L_06095788:
    c.r[1] = 0x0u;  // 06095788 mov #0,r1
    st32(c.r[14] + 44, c.r[1]);  // 0609578A mov.l r1,@(44,r14)
L_0609578C:
    c.r[1] = ld32(c.r[14] + 20);  // 0609578C mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[14] + 24);  // 0609578E mov.l @(24,r14),r2
    c.t = c.r[1] == c.r[2];  // 06095790 cmp/eq r2,r1
    if (c.t) { goto L_06095798; }  // 06095792 bt 0x06095798
    goto L_0609579C;  // 06095794 bra 0x0609579C ; nop
L_06095798:
    goto L_060957A6;  // 06095798 bra 0x060957A6 ; nop
L_0609579C:
    c.r[1] = ld32(c.r[14] + 20);  // 0609579C mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 0609579E mov.l @(8,r1),r2
    st32(c.r[14] + 20, c.r[2]);  // 060957A0 mov.l r2,@(20,r14)
    SH2_POLL(c); goto L_06095660;  // 060957A2 bra 0x06095660 ; nop
L_060957A6:
    c.r[2] = ld32(c.r[14] + 16);  // 060957A6 mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 060957A8 mov r2,r1
    c.r[1] += 1;  // 060957AA add #1,r1
    c.r[2] = c.r[1];  // 060957AC mov r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 060957AE mov.l r2,@(16,r14)
    SH2_POLL(c); goto L_0609563C;  // 060957B0 bra 0x0609563C ; nop
L_060957D8:
    c.r[1] = ld32(c.r[14]);  // 060957D8 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 20);  // 060957DA mov.l @(20,r14),r2
    st32(c.r[1] + 16, c.r[2]);  // 060957DC mov.l r2,@(16,r1)
    c.r[1] = ld32(c.r[14] + 48);  // 060957DE mov.l @(48,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060957E0 tst r1,r1
    if (c.t) { goto L_060957E8; }  // 060957E2 bt 0x060957E8
    goto L_060957FC;  // 060957E4 bra 0x060957FC ; nop
L_060957E8:
    c.r[1] = ld32(c.r[14] + 44);  // 060957E8 mov.l @(44,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060957EA tst r1,r1
    if (c.t) { goto L_060957F2; }  // 060957EC bt 0x060957F2
    goto L_060957FC;  // 060957EE bra 0x060957FC ; nop
L_060957F2:
    c.r[12] = 0x54u;  // 060957F2 mov #84,r12
    c.r[12] += c.r[14];  // 060957F4 add r14,r12
    c.r[1] = ld32(c.r[12]);  // 060957F6 mov.l @r12,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095818u);  // 060957F8 mov.w 0x06095818,r2
    st32(c.r[1], c.r[2]);  // 060957FA mov.l r2,@r1
L_060957FC:
    c.r[0] = ld32(c.r[14] + 44);  // 060957FC mov.l @(44,r14),r0
    goto L_06095802;  // 060957FE bra 0x06095802 ; nop
L_06095802:
    c.r[14] += 56;  // 06095802 add #56,r14
    c.r[15] = c.r[14];  // 06095804 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095806 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095808 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609580A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609580C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609580E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06095810 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095812 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095814 rts ; nop
}

void f_0609581C(SH2Context& c) {
    ran[2265] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609581C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609581E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095820 sts.l pr,@-r15
    c.r[15] -= 8;  // 06095822 add #-8,r15
    c.r[14] = c.r[15];  // 06095824 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095826 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06095828 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0609582A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609582C mov.l r2,@(4,r14)
L_0609582E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609582E mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095830 tst r1,r1
    if (!c.t) { goto L_06095838; }  // 06095832 bf 0x06095838
    goto L_06095852;  // 06095834 bra 0x06095852 ; nop
L_06095838:
    c.r[2] = ld32(c.r[14] + 4);  // 06095838 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[2] + 16);  // 0609583A mov.l @(16,r2),r1
    c.r[6] = 0x0u;  // 0609583C mov #0,r6
    c.r[5] = 0x0u;  // 0609583E mov #0,r5
    c.r[4] = c.r[1];  // 06095840 mov r1,r4
    c.r[8] = ld32(0x06095860u);  // 06095842 mov.l 0x06095860,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095848u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095848u) return; }  // 06095844 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 06095848 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 0609584A mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 0609584C mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0609582E;  // 0609584E bra 0x0609582E ; nop
L_06095852:
    c.r[14] += 8;  // 06095852 add #8,r14
    c.r[15] = c.r[14];  // 06095854 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095856 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095858 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609585A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609585C rts ; nop
}

void f_06095864(SH2Context& c) {
    ran[2266] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095864 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06095866 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06095868 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609586A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609586C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609586E sts.l pr,@-r15
    c.r[15] -= 28;  // 06095870 add #-28,r15
    c.r[14] = c.r[15];  // 06095872 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095874 mov.l r4,@r14
    c.r[9] = c.r[5];  // 06095876 mov r5,r9
    c.r[8] = c.r[14];  // 06095878 mov r14,r8
    c.r[10] = c.r[14];  // 0609587A mov r14,r10
    c.r[10] += 4;  // 0609587C add #4,r10
    st8(c.r[10], c.r[9]);  // 0609587E mov.b r9,@r10
    c.r[1] = ld32(c.r[14]);  // 06095880 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095882 mov.l @(16,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095884 tst r2,r2
    if (!c.t) { goto L_06095890; }  // 06095886 bf 0x06095890
    c.r[1] = ld32(c.r[14]);  // 06095888 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 0609588A mov.l @r14,r2
    c.r[3] = ld32(c.r[2]);  // 0609588C mov.l @r2,r3
    st32(c.r[1] + 16, c.r[3]);  // 0609588E mov.l r3,@(16,r1)
L_06095890:
    c.r[1] = ld32(c.r[14]);  // 06095890 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095892 mov.l @(16,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 06095894 mov.l r2,@(12,r14)
L_06095896:
    c.r[1] = ld32(c.r[14]);  // 06095896 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095898 mov.l @(16,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 0609589A mov.l r2,@(8,r14)
    c.r[1] = c.r[14];  // 0609589C mov r14,r1
    c.r[1] += 20;  // 0609589E add #20,r1
    c.r[2] = c.r[14];  // 060958A0 mov r14,r2
    c.r[3] = c.r[14];  // 060958A2 mov r14,r3
    c.r[3] += 4;  // 060958A4 add #4,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060958A6 mov.b @r3,r7
    c.r[2] = c.r[7] & 0xFFu;  // 060958A8 extu.b r7,r2
    c.r[3] = ld32(c.r[14] + 12);  // 060958AA mov.l @(12,r14),r3
    c.r[7] = c.r[14];  // 060958AC mov r14,r7
    c.r[7] += 16;  // 060958AE add #16,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060958B0 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 060958B2 mov r1,r7
    c.r[6] = c.r[2];  // 060958B4 mov r2,r6
    c.r[5] = c.r[3];  // 060958B6 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 060958B8 mov.l @r14,r4
    c.r[11] = ld32(0x0609597Cu);  // 060958BA mov.l 0x0609597C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060958C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060958C0u) return; }  // 060958BC jsr @r11 ; nop
    c.r[15] += 4;  // 060958C0 add #4,r15
    st32(c.r[14] + 24, c.r[0]);  // 060958C2 mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 060958C4 mov.l @(20,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060958C6 tst r1,r1
    if (c.t) { goto L_060958CE; }  // 060958C8 bt 0x060958CE
    goto L_060958D2;  // 060958CA bra 0x060958D2 ; nop
L_060958CE:
    SH2_POLL(c); goto L_06095896;  // 060958CE bra 0x06095896 ; nop
L_060958D2:
    c.r[1] = ld32(c.r[14] + 16);  // 060958D2 mov.l @(16,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095976u);  // 060958D4 mov.w 0x06095976,r2
    c.t = c.r[1] == c.r[2];  // 060958D6 cmp/eq r2,r1
    if (c.t) { goto L_060958E8; }  // 060958D8 bt 0x060958E8
    c.r[1] = ld32(c.r[14]);  // 060958DA mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 24);  // 060958DC mov.l @(24,r1),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06095976u);  // 060958DE mov.w 0x06095976,r1
    c.t = c.r[2] == c.r[1];  // 060958E0 cmp/eq r1,r2
    if (c.t) { goto L_060958E8; }  // 060958E2 bt 0x060958E8
    goto L_060958F2;  // 060958E4 bra 0x060958F2 ; nop
L_060958E8:
    c.r[1] = ld32(c.r[14]);  // 060958E8 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 16);  // 060958EA mov.l @(16,r14),r2
    st32(c.r[1] + 24, c.r[2]);  // 060958EC mov.l r2,@(24,r1)
    goto L_0609595C;  // 060958EE bra 0x0609595C ; nop
L_060958F2:
    c.r[4] = ld32(c.r[14]);  // 060958F2 mov.l @r14,r4
    c.r[11] = ld32(0x06095980u);  // 060958F4 mov.l 0x06095980,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060958FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060958FAu) return; }  // 060958F6 jsr @r11 ; nop
    c.t = c.r[0] == 0x1u;  // 060958FA cmp/eq #1,r0
    if (!c.t) { goto L_0609595C; }  // 060958FC bf 0x0609595C
    c.r[1] = ld32(c.r[14]);  // 060958FE mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06095900 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 48);  // 06095902 mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[2] + 44);  // 06095904 mov.l @(44,r2),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06095906 cmp/ge r2,r1
    if (c.t) { goto L_0609593E; }  // 06095908 bt 0x0609593E
    c.r[1] = ld32(c.r[14] + 16);  // 0609590A mov.l @(16,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095978u);  // 0609590C mov.w 0x06095978,r2
    c.t = c.r[1] == c.r[2];  // 0609590E cmp/eq r2,r1
    if (!c.t) { goto L_06095936; }  // 06095910 bf 0x06095936
    c.r[2] = ld32(c.r[14]);  // 06095912 mov.l @r14,r2
    c.r[1] = ld32(c.r[14]);  // 06095914 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06095916 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 48);  // 06095918 mov.l @(48,r2),r3
    c.r[2] = c.r[3];  // 0609591A mov r3,r2
    c.r[2] += 1;  // 0609591C add #1,r2
    c.r[3] = c.r[2];  // 0609591E mov r2,r3
    st32(c.r[1] + 48, c.r[3]);  // 06095920 mov.l r3,@(48,r1)
    c.r[1] = ld32(c.r[14]);  // 06095922 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06095924 mov r1,r2
    c.r[1] += 56;  // 06095926 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 06095928 mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609592A mov r3,r2
    c.r[3] += 56;  // 0609592C add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0609592E mov.w @r3,r2
    c.r[3] = 0x40u;  // 06095930 mov #64,r3
    c.r[3] |= c.r[2];  // 06095932 or r2,r3
    st16(c.r[1], c.r[3]);  // 06095934 mov.w r3,@r1
L_06095936:
    c.r[1] = 0x0u;  // 06095936 mov #0,r1
    st32(c.r[14] + 24, c.r[1]);  // 06095938 mov.l r1,@(24,r14)
    goto L_0609595C;  // 0609593A bra 0x0609595C ; nop
L_0609593E:
    c.r[1] = ld32(c.r[14]);  // 0609593E mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609597Au);  // 06095940 mov.w 0x0609597A,r2
    st32(c.r[1] + 20, c.r[2]);  // 06095942 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14]);  // 06095944 mov.l @r14,r1
    c.r[2] = c.r[1];  // 06095946 mov r1,r2
    c.r[1] += 56;  // 06095948 add #56,r1
    c.r[3] = ld32(c.r[14]);  // 0609594A mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609594C mov r3,r2
    c.r[3] += 56;  // 0609594E add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06095950 mov.w @r3,r2
    c.r[3] = 0x40u;  // 06095952 mov #64,r3
    c.r[3] |= c.r[2];  // 06095954 or r2,r3
    st16(c.r[1], c.r[3]);  // 06095956 mov.w r3,@r1
    c.r[1] = 0x1u;  // 06095958 mov #1,r1
    st32(c.r[14] + 24, c.r[1]);  // 0609595A mov.l r1,@(24,r14)
L_0609595C:
    c.r[0] = ld32(c.r[14] + 24);  // 0609595C mov.l @(24,r14),r0
    goto L_06095962;  // 0609595E bra 0x06095962 ; nop
L_06095962:
    c.r[14] += 28;  // 06095962 add #28,r14
    c.r[15] = c.r[14];  // 06095964 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095966 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095968 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609596A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609596C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609596E mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095970 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095972 rts ; nop
}

void f_06095984(SH2Context& c) {
    ran[2267] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095984 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095986 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095988 sts.l pr,@-r15
    c.r[15] -= 32;  // 0609598A add #-32,r15
    c.r[14] = c.r[15];  // 0609598C mov r15,r14
    c.r[1] = ld32(0x06095A8Cu);  // 0609598E mov.l 0x06095A8C,r1
    c.r[2] = ld32(c.r[1]);  // 06095990 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095992 tst r2,r2
    if (c.t) { goto L_060959C6; }  // 06095994 bt 0x060959C6
    c.r[1] = ld32(0x06095A8Cu);  // 06095996 mov.l 0x06095A8C,r1
    c.r[2] = ld32(0x06095A8Cu);  // 06095998 mov.l 0x06095A8C,r2
    c.r[3] = ld32(c.r[2] + 4);  // 0609599A mov.l @(4,r2),r3
    c.r[1] = ld32(c.r[1]);  // 0609599C mov.l @r1,r1
    c.r[4] = c.r[3];  // 0609599E mov r3,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060959A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060959A4u) return; }  // 060959A0 jsr @r1 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 060959A4 mov.l r0,@(24,r14)
    c.r[0] = ld32(c.r[14] + 24);  // 060959A6 mov.l @(24,r14),r0
    c.t = c.r[0] == 0x1u;  // 060959A8 cmp/eq #1,r0
    if (!c.t) { goto L_060959B8; }  // 060959AA bf 0x060959B8
    c.r[1] = ld32(0x06095A8Cu);  // 060959AC mov.l 0x06095A8C,r1
    c.r[2] = 0x0u;  // 060959AE mov #0,r2
    st32(c.r[1], c.r[2]);  // 060959B0 mov.l r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06095A86u);  // 060959B2 mov.w 0x06095A86,r0
    goto L_06095B36;  // 060959B4 bra 0x06095B36 ; nop
L_060959B8:
    c.r[1] = ld32(0x06095A90u);  // 060959B8 mov.l 0x06095A90,r1
    c.r[2] = ld32(c.r[1]);  // 060959BA mov.l @r1,r2
    c.r[1] = c.r[2];  // 060959BC mov r2,r1
    c.r[1] += 28;  // 060959BE add #28,r1
    c.r[0] = ld32(c.r[1] + 4);  // 060959C0 mov.l @(4,r1),r0
    goto L_06095B36;  // 060959C2 bra 0x06095B36 ; nop
L_060959C6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06095A88u);  // 060959C6 mov.w 0x06095A88,r1
    c.r[4] = c.r[1];  // 060959C8 mov r1,r4
    c.r[8] = ld32(0x06095A94u);  // 060959CA mov.l 0x06095A94,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060959D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060959D0u) return; }  // 060959CC jsr @r8 ; nop
    c.r[2] = ld32(0x06095A90u);  // 060959D0 mov.l 0x06095A90,r2
    c.r[1] = ld32(c.r[2]);  // 060959D2 mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 060959D4 mov.l @(16,r1),r2
    st32(c.r[14], c.r[2]);  // 060959D6 mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 060959D8 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060959DA tst r1,r1
    if (!c.t) { goto L_060959E2; }  // 060959DC bf 0x060959E2
    goto L_06095B2C;  // 060959DE bra 0x06095B2C ; nop
L_060959E2:
    c.r[1] = ld32(c.r[14]);  // 060959E2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 060959E4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060959E6 tst r2,r2
    if (!c.t) { goto L_060959EE; }  // 060959E8 bf 0x060959EE
    goto L_06095B2C;  // 060959EA bra 0x06095B2C ; nop
L_060959EE:
    c.r[2] = ld32(0x06095A90u);  // 060959EE mov.l 0x06095A90,r2
    c.r[1] = ld32(c.r[2]);  // 060959F0 mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 44);  // 060959F2 mov.l @(44,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060959F4 tst r2,r2
    if (c.t) { goto L_060959FC; }  // 060959F6 bt 0x060959FC
    goto L_06095B0C;  // 060959F8 bra 0x06095B0C ; nop
L_060959FC:
    c.r[2] = ld32(0x06095A90u);  // 060959FC mov.l 0x06095A90,r2
    c.r[1] = ld32(c.r[2]);  // 060959FE mov.l @r2,r1
    c.r[2] = 0x1u;  // 06095A00 mov #1,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095A02 mov.l r2,@(44,r1)
    c.r[1] = ld32(0x06095A98u);  // 06095A04 mov.l 0x06095A98,r1
    c.r[0] = ld32(c.r[1]);  // 06095A06 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06095A08 cmp/eq #1,r0
    if (!c.t) { goto L_06095A4C; }  // 06095A0A bf 0x06095A4C
    c.r[1] = c.r[14];  // 06095A0C mov r14,r1
    c.r[1] += 20;  // 06095A0E add #20,r1
    c.r[2] = ld32(c.r[14]);  // 06095A10 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 16);  // 06095A12 mov.l @(16,r2),r3
    c.r[2] = ld32(c.r[3] + 16);  // 06095A14 mov.l @(16,r3),r2
    c.r[5] = c.r[1];  // 06095A16 mov r1,r5
    c.r[4] = c.r[2];  // 06095A18 mov r2,r4
    c.r[8] = ld32(0x06095A9Cu);  // 06095A1A mov.l 0x06095A9C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095A20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095A20u) return; }  // 06095A1C jsr @r8 ; nop
    c.r[1] = ld32(0x06095A98u);  // 06095A20 mov.l 0x06095A98,r1
    c.r[0] = ld32(c.r[1]);  // 06095A22 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06095A24 cmp/eq #1,r0
    if (!c.t) { goto L_06095A4C; }  // 06095A26 bf 0x06095A4C
    c.r[2] = ld32(0x06095A90u);  // 06095A28 mov.l 0x06095A90,r2
    c.r[1] = ld32(c.r[2]);  // 06095A2A mov.l @r2,r1
    c.r[2] = 0x0u;  // 06095A2C mov #0,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095A2E mov.l r2,@(44,r1)
    c.r[8] = ld32(0x06095AA0u);  // 06095A30 mov.l 0x06095AA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095A36u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095A36u) return; }  // 06095A32 jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06095A36 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06095A38 mov.l @(28,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06095A3A cmp/pz r1
    if (c.t) { goto L_06095A44; }  // 06095A3C bt 0x06095A44
    c.r[0] = ld32(c.r[14] + 28);  // 06095A3E mov.l @(28,r14),r0
    goto L_06095B36;  // 06095A40 bra 0x06095B36 ; nop
L_06095A44:
    c.r[1] = ld32(c.r[14]);  // 06095A44 mov.l @r14,r1
    c.r[0] = ld32(c.r[1] + 24);  // 06095A46 mov.l @(24,r1),r0
    goto L_06095B36;  // 06095A48 bra 0x06095B36 ; nop
L_06095A4C:
    c.r[4] = ld32(c.r[14]);  // 06095A4C mov.l @r14,r4
    c.r[8] = ld32(0x06095AA4u);  // 06095A4E mov.l 0x06095AA4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095A54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095A54u) return; }  // 06095A50 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06095A54 mov r14,r1
    c.r[1] += 4;  // 06095A56 add #4,r1
    c.r[5] = 0x0u;  // 06095A58 mov #0,r5
    c.r[4] = c.r[1];  // 06095A5A mov r1,r4
    c.r[8] = ld32(0x06095AA8u);  // 06095A5C mov.l 0x06095AA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095A62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095A62u) return; }  // 06095A5E jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06095A62 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06095A64 mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 06095A66 mov r1,r4
    c.r[8] = ld32(0x06095AACu);  // 06095A68 mov.l 0x06095AAC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095A6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095A6Eu) return; }  // 06095A6A jsr @r8 ; nop
    c.r[1] = ld32(0x06095A90u);  // 06095A6E mov.l 0x06095A90,r1
    c.r[2] = ld32(c.r[1]);  // 06095A70 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06095A72 mov r2,r1
    c.r[1] += 28;  // 06095A74 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06095A76 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095A78 tst r2,r2
    if (c.t) { goto L_06095AB4; }  // 06095A7A bt 0x06095AB4
    c.r[8] = ld32(0x06095AB0u);  // 06095A7C mov.l 0x06095AB0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095A82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095A82u) return; }  // 06095A7E jsr @r8 ; nop
    goto L_06095B04;  // 06095A82 bra 0x06095B04 ; nop
L_06095AB4:
    c.r[4] = ld32(c.r[14]);  // 06095AB4 mov.l @r14,r4
    c.r[8] = ld32(0x06095B48u);  // 06095AB6 mov.l 0x06095B48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095ABCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095ABCu) return; }  // 06095AB8 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06095ABC mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06095ABE mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06095AC0 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 06095AC2 mov.l @(4,r14),r3
    c.r[7] = c.r[1];  // 06095AC4 mov r1,r7
    c.r[6] = c.r[2];  // 06095AC6 mov r2,r6
    c.r[5] = c.r[3];  // 06095AC8 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06095ACA mov.l @r14,r4
    c.r[8] = ld32(0x06095B4Cu);  // 06095ACC mov.l 0x06095B4C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095AD2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095AD2u) return; }  // 06095ACE jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 06095AD2 mov.l r0,@(16,r14)
    c.r[1] = c.r[14];  // 06095AD4 mov r14,r1
    c.r[2] = c.r[14];  // 06095AD6 mov r14,r2
    c.r[2] += 31;  // 06095AD8 add #31,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06095ADA mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06095ADC extu.b r3,r1
    c.r[5] = c.r[1];  // 06095ADE mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06095AE0 mov.l @r14,r4
    c.r[8] = ld32(0x06095B50u);  // 06095AE2 mov.l 0x06095B50,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095AE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095AE8u) return; }  // 06095AE4 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06095AE8 mov.l r0,@(20,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 06095AEA mov.l @(16,r14),r0
    c.t = c.r[0] == 0x1u;  // 06095AEC cmp/eq #1,r0
    if (!c.t) { goto L_06095B04; }  // 06095AEE bf 0x06095B04
    c.r[0] = ld32(c.r[14] + 20);  // 06095AF0 mov.l @(20,r14),r0
    c.t = c.r[0] == 0x1u;  // 06095AF2 cmp/eq #1,r0
    if (!c.t) { goto L_06095B04; }  // 06095AF4 bf 0x06095B04
    c.r[1] = ld32(c.r[14]);  // 06095AF6 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095B44u);  // 06095AF8 mov.w 0x06095B44,r2
    st32(c.r[1] + 24, c.r[2]);  // 06095AFA mov.l r2,@(24,r1)
    c.r[4] = ld32(c.r[14]);  // 06095AFC mov.l @r14,r4
    c.r[8] = ld32(0x06095B54u);  // 06095AFE mov.l 0x06095B54,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095B04u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095B04u) return; }  // 06095B00 jsr @r8 ; nop
L_06095B04:
    c.r[2] = ld32(0x06095B58u);  // 06095B04 mov.l 0x06095B58,r2
    c.r[1] = ld32(c.r[2]);  // 06095B06 mov.l @r2,r1
    c.r[2] = 0x0u;  // 06095B08 mov #0,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095B0A mov.l r2,@(44,r1)
L_06095B0C:
    c.r[8] = ld32(0x06095B5Cu);  // 06095B0C mov.l 0x06095B5C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095B12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095B12u) return; }  // 06095B0E jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06095B12 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06095B14 mov.l @(28,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06095B16 cmp/pz r1
    if (c.t) { goto L_06095B22; }  // 06095B18 bt 0x06095B22
    c.r[1] = ld32(c.r[14] + 28);  // 06095B1A mov.l @(28,r14),r1
    st32(c.r[14] + 12, c.r[1]);  // 06095B1C mov.l r1,@(12,r14)
    goto L_06095B28;  // 06095B1E bra 0x06095B28 ; nop
L_06095B22:
    c.r[1] = ld32(c.r[14]);  // 06095B22 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 24);  // 06095B24 mov.l @(24,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 06095B26 mov.l r2,@(12,r14)
L_06095B28:
    goto L_06095B30;  // 06095B28 bra 0x06095B30 ; nop
L_06095B2C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06095B46u);  // 06095B2C mov.w 0x06095B46,r1
    st32(c.r[14] + 12, c.r[1]);  // 06095B2E mov.l r1,@(12,r14)
L_06095B30:
    c.r[0] = ld32(c.r[14] + 12);  // 06095B30 mov.l @(12,r14),r0
    goto L_06095B36;  // 06095B32 bra 0x06095B36 ; nop
L_06095B36:
    c.r[14] += 32;  // 06095B36 add #32,r14
    c.r[15] = c.r[14];  // 06095B38 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095B3A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095B3C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095B3E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095B40 rts ; nop
}

void f_06095B60(SH2Context& c) {
    ran[2268] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095B60 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095B62 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095B64 sts.l pr,@-r15
    c.r[15] -= 28;  // 06095B66 add #-28,r15
    c.r[14] = c.r[15];  // 06095B68 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095B6A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06095B6C mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06095C7Au);  // 06095B6E mov.w 0x06095C7A,r1
    c.r[4] = c.r[1];  // 06095B70 mov r1,r4
    c.r[8] = ld32(0x06095C80u);  // 06095B72 mov.l 0x06095C80,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095B78u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095B78u) return; }  // 06095B74 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06095B78 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095B7A tst r1,r1
    if (!c.t) { goto L_06095B90; }  // 06095B7C bf 0x06095B90
    c.r[4] = 0xFFFFFFF5u;  // 06095B7E mov #-11,r4
    c.r[8] = ld32(0x06095C84u);  // 06095B80 mov.l 0x06095C84,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095B86u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095B86u) return; }  // 06095B82 jsr @r8 ; nop
    c.r[8] = ld32(0x06095C88u);  // 06095B86 mov.l 0x06095C88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095B8Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095B8Cu) return; }  // 06095B88 jsr @r8 ; nop
    goto L_06095C6C;  // 06095B8C bra 0x06095C6C ; nop
L_06095B90:
    c.r[1] = ld32(c.r[14]);  // 06095B90 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06095B92 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06095B94 mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 06095B96 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06095B98 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06095B9A mov.l r2,@(8,r14)
    c.r[2] = ld32(0x06095C8Cu);  // 06095B9C mov.l 0x06095C8C,r2
    c.r[1] = ld32(c.r[2]);  // 06095B9E mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095BA0 mov.l @(16,r1),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06095BA2 mov.l @(8,r14),r1
    c.t = c.r[2] == c.r[1];  // 06095BA4 cmp/eq r1,r2
    if (!c.t) { goto L_06095C30; }  // 06095BA6 bf 0x06095C30
    c.r[2] = ld32(c.r[14] + 8);  // 06095BA8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06095BAA mov r2,r1
    c.r[2] += 56;  // 06095BAC add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06095BAE mov.w @r2,r1
    c.r[2] = 0x2u;  // 06095BB0 mov #2,r2
    c.r[2] &= c.r[1];  // 06095BB2 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06095BB4 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095BB6 tst r1,r1
    if (c.t) { goto L_06095BDE; }  // 06095BB8 bt 0x06095BDE
    c.r[1] = ld32(c.r[14]);  // 06095BBA mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06095BBC mov.l @r1,r2
    c.r[4] = c.r[2];  // 06095BBE mov r2,r4
    c.r[8] = ld32(0x06095C90u);  // 06095BC0 mov.l 0x06095C90,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095BC6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095BC6u) return; }  // 06095BC2 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06095BC6 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06095BC8 mov.l @(20,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095BCA tst r1,r1
    if (c.t) { goto L_06095BD8; }  // 06095BCC bt 0x06095BD8
    c.r[1] = ld32(c.r[14] + 20);  // 06095BCE mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 06095BD0 mov r1,r4
    c.r[8] = ld32(0x06095C84u);  // 06095BD2 mov.l 0x06095C84,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095BD8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095BD8u) return; }  // 06095BD4 jsr @r8 ; nop
L_06095BD8:
    c.r[1] = ld32(c.r[14] + 8);  // 06095BD8 mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095C7Cu);  // 06095BDA mov.w 0x06095C7C,r2
    st32(c.r[1] + 24, c.r[2]);  // 06095BDC mov.l r2,@(24,r1)
L_06095BDE:
    c.r[1] = c.r[14];  // 06095BDE mov r14,r1
    c.r[1] += 12;  // 06095BE0 add #12,r1
    c.r[5] = 0x0u;  // 06095BE2 mov #0,r5
    c.r[4] = c.r[1];  // 06095BE4 mov r1,r4
    c.r[8] = ld32(0x06095C94u);  // 06095BE6 mov.l 0x06095C94,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095BECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095BECu) return; }  // 06095BE8 jsr @r8 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 06095BEC mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 06095BEE mov.l @(24,r14),r1
    c.r[4] = c.r[1];  // 06095BF0 mov r1,r4
    c.r[8] = ld32(0x06095C98u);  // 06095BF2 mov.l 0x06095C98,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095BF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095BF8u) return; }  // 06095BF4 jsr @r8 ; nop
    c.r[1] = ld32(0x06095C8Cu);  // 06095BF8 mov.l 0x06095C8C,r1
    c.r[2] = ld32(c.r[1]);  // 06095BFA mov.l @r1,r2
    c.r[1] = c.r[2];  // 06095BFC mov r2,r1
    c.r[1] += 28;  // 06095BFE add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06095C00 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095C02 tst r2,r2
    if (c.t) { goto L_06095C10; }  // 06095C04 bt 0x06095C10
    c.r[8] = ld32(0x06095C88u);  // 06095C06 mov.l 0x06095C88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095C0Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095C0Cu) return; }  // 06095C08 jsr @r8 ; nop
    goto L_06095C6C;  // 06095C0C bra 0x06095C6C ; nop
L_06095C10:
    c.r[1] = ld32(c.r[14] + 12);  // 06095C10 mov.l @(12,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06095C12 cmp/pz r1
    if (!c.t) { goto L_06095C1C; }  // 06095C14 bf 0x06095C1C
    c.r[1] = ld32(c.r[14] + 8);  // 06095C16 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06095C18 mov.l @(12,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06095C1A mov.l r2,@(20,r1)
L_06095C1C:
    c.r[1] = ld32(c.r[14] + 8);  // 06095C1C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06095C1E mov r1,r2
    c.r[1] += 56;  // 06095C20 add #56,r1
    c.r[3] = ld32(c.r[14] + 8);  // 06095C22 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 06095C24 mov r3,r2
    c.r[3] += 56;  // 06095C26 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06095C28 mov.w @r3,r2
    c.r[3] = ld32(0x06095C9Cu);  // 06095C2A mov.l 0x06095C9C,r3
    c.r[2] &= c.r[3];  // 06095C2C and r3,r2
    st16(c.r[1], c.r[2]);  // 06095C2E mov.w r2,@r1
L_06095C30:
    c.r[1] = ld32(c.r[14] + 8);  // 06095C30 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06095C32 mov r1,r4
    c.r[8] = ld32(0x06095CA0u);  // 06095C34 mov.l 0x06095CA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095C3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095C3Au) return; }  // 06095C36 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06095C3A mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06095C3C mov r1,r4
    c.r[8] = ld32(0x06095CA4u);  // 06095C3E mov.l 0x06095CA4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095C44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095C44u) return; }  // 06095C40 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06095C44 mov r14,r1
    c.r[1] += 16;  // 06095C46 add #16,r1
    c.r[2] = c.r[14];  // 06095C48 mov r14,r2
    c.r[2] += 12;  // 06095C4A add #12,r2
    c.r[7] = ld32(c.r[14]);  // 06095C4C mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 20);  // 06095C4E mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06095C50 mov r1,r6
    c.r[5] = c.r[2];  // 06095C52 mov r2,r5
    c.r[4] = c.r[3];  // 06095C54 mov r3,r4
    c.r[8] = ld32(0x06095CA8u);  // 06095C56 mov.l 0x06095CA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095C5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095C5Cu) return; }  // 06095C58 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06095C5C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06095C5E mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 06095C60 mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 06095C62 add r3,r2
    st32(c.r[1] + 20, c.r[2]);  // 06095C64 mov.l r2,@(20,r1)
    c.r[8] = ld32(0x06095CACu);  // 06095C66 mov.l 0x06095CAC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095C6Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095C6Cu) return; }  // 06095C68 jsr @r8 ; nop
L_06095C6C:
    c.r[14] += 28;  // 06095C6C add #28,r14
    c.r[15] = c.r[14];  // 06095C6E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095C70 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095C72 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095C74 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095C76 rts ; nop
}

void f_06095CB0(SH2Context& c) {
    ran[2269] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095CB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095CB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095CB4 sts.l pr,@-r15
    c.r[15] -= 8;  // 06095CB6 add #-8,r15
    c.r[14] = c.r[15];  // 06095CB8 mov r15,r14
    c.r[2] = ld32(0x06095CF0u);  // 06095CBA mov.l 0x06095CF0,r2
    c.r[1] = ld32(c.r[2]);  // 06095CBC mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095CBE mov.l @(16,r1),r2
    c.r[4] = c.r[2];  // 06095CC0 mov r2,r4
    c.r[8] = ld32(0x06095CF4u);  // 06095CC2 mov.l 0x06095CF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095CC8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095CC8u) return; }  // 06095CC4 jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 06095CC8 mov.l r0,@r14
    c.r[8] = ld32(0x06095CF8u);  // 06095CCA mov.l 0x06095CF8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095CD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095CD0u) return; }  // 06095CCC jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06095CD0 mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06095CD2 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06095CD4 cmp/pz r1
    if (c.t) { goto L_06095CDC; }  // 06095CD6 bt 0x06095CDC
    c.r[1] = ld32(c.r[14] + 4);  // 06095CD8 mov.l @(4,r14),r1
    st32(c.r[14], c.r[1]);  // 06095CDA mov.l r1,@r14
L_06095CDC:
    c.r[0] = ld32(c.r[14]);  // 06095CDC mov.l @r14,r0
    goto L_06095CE2;  // 06095CDE bra 0x06095CE2 ; nop
L_06095CE2:
    c.r[14] += 8;  // 06095CE2 add #8,r14
    c.r[15] = c.r[14];  // 06095CE4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095CE6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095CE8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095CEA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095CEC rts ; nop
}

void f_06095CFC(SH2Context& c) {
    ran[2270] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095CFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095CFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095D00 sts.l pr,@-r15
    c.r[15] -= 20;  // 06095D02 add #-20,r15
    c.r[14] = c.r[15];  // 06095D04 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095D06 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06095DAEu);  // 06095D08 mov.w 0x06095DAE,r1
    c.r[4] = c.r[1];  // 06095D0A mov r1,r4
    c.r[8] = ld32(0x06095DB4u);  // 06095D0C mov.l 0x06095DB4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D12u) return; }  // 06095D0E jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06095D12 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095D14 tst r1,r1
    if (!c.t) { goto L_06095D2C; }  // 06095D16 bf 0x06095D2C
    c.r[4] = 0xFFFFFFF5u;  // 06095D18 mov #-11,r4
    c.r[8] = ld32(0x06095DB8u);  // 06095D1A mov.l 0x06095DB8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D20u) return; }  // 06095D1C jsr @r8 ; nop
    c.r[8] = ld32(0x06095DBCu);  // 06095D20 mov.l 0x06095DBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D26u) return; }  // 06095D22 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06095D26 mov #0,r0
    goto L_06095DA0;  // 06095D28 bra 0x06095DA0 ; nop
L_06095D2C:
    c.r[1] = ld32(c.r[14]);  // 06095D2C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06095D2E mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06095D30 mov.l r2,@r14
    c.r[4] = ld32(c.r[14]);  // 06095D32 mov.l @r14,r4
    c.r[8] = ld32(0x06095DC0u);  // 06095D34 mov.l 0x06095DC0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D3Au) return; }  // 06095D36 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06095D3A mov.l r0,@(4,r14)
    c.r[1] = c.r[14];  // 06095D3C mov r14,r1
    c.r[1] += 16;  // 06095D3E add #16,r1
    c.r[2] = c.r[14];  // 06095D40 mov r14,r2
    c.r[2] += 12;  // 06095D42 add #12,r2
    c.r[7] = ld32(c.r[14]);  // 06095D44 mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 20);  // 06095D46 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06095D48 mov r1,r6
    c.r[5] = c.r[2];  // 06095D4A mov r2,r5
    c.r[4] = c.r[3];  // 06095D4C mov r3,r4
    c.r[8] = ld32(0x06095DC4u);  // 06095D4E mov.l 0x06095DC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D54u) return; }  // 06095D50 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 06095D54 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 06095D56 mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[14] + 12);  // 06095D58 mov.l @(12,r14),r3
    c.r[7] = c.r[1];  // 06095D5A mov r1,r7
    c.r[6] = c.r[2];  // 06095D5C mov r2,r6
    c.r[5] = c.r[3];  // 06095D5E mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06095D60 mov.l @r14,r4
    c.r[8] = ld32(0x06095DC8u);  // 06095D62 mov.l 0x06095DC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D68u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D68u) return; }  // 06095D64 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06095D68 mov.l r0,@(8,r14)
    c.r[8] = ld32(0x06095DCCu);  // 06095D6A mov.l 0x06095DCC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095D70u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095D70u) return; }  // 06095D6C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06095D70 mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095DB0u);  // 06095D72 mov.w 0x06095DB0,r2
    c.t = c.r[1] == c.r[2];  // 06095D74 cmp/eq r2,r1
    if (!c.t) { goto L_06095D7E; }  // 06095D76 bf 0x06095D7E
    c.r[0] = 0x1u;  // 06095D78 mov #1,r0
    goto L_06095DA0;  // 06095D7A bra 0x06095DA0 ; nop
L_06095D7E:
    c.r[1] = ld32(c.r[14] + 8);  // 06095D7E mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095DB2u);  // 06095D80 mov.w 0x06095DB2,r2
    c.t = c.r[1] == c.r[2];  // 06095D82 cmp/eq r2,r1
    if (!c.t) { goto L_06095D9A; }  // 06095D84 bf 0x06095D9A
    c.r[1] = ld32(c.r[14]);  // 06095D86 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095D88 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06095D8A mov r2,r1
    c.r[1] += 108;  // 06095D8C add #108,r1
    c.r[2] = ld32(c.r[1] + 48);  // 06095D8E mov.l @(48,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095D90 tst r2,r2
    if (!c.t) { goto L_06095D9A; }  // 06095D92 bf 0x06095D9A
    c.r[0] = 0x1u;  // 06095D94 mov #1,r0
    goto L_06095DA0;  // 06095D96 bra 0x06095DA0 ; nop
L_06095D9A:
    c.r[0] = 0x0u;  // 06095D9A mov #0,r0
    goto L_06095DA0;  // 06095D9C bra 0x06095DA0 ; nop
L_06095DA0:
    c.r[14] += 20;  // 06095DA0 add #20,r14
    c.r[15] = c.r[14];  // 06095DA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095DA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095DA6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095DA8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095DAA rts ; nop
}

void f_06095DD0(SH2Context& c) {
    ran[2271] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095DD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095DD2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095DD4 sts.l pr,@-r15
    c.r[15] -= 16;  // 06095DD6 add #-16,r15
    c.r[14] = c.r[15];  // 06095DD8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095DDA mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06095EAEu);  // 06095DDC mov.w 0x06095EAE,r1
    c.r[4] = c.r[1];  // 06095DDE mov r1,r4
    c.r[8] = ld32(0x06095EB0u);  // 06095DE0 mov.l 0x06095EB0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095DE6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095DE6u) return; }  // 06095DE2 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06095DE6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095DE8 tst r1,r1
    if (!c.t) { goto L_06095E00; }  // 06095DEA bf 0x06095E00
    c.r[4] = 0xFFFFFFF5u;  // 06095DEC mov #-11,r4
    c.r[8] = ld32(0x06095EB4u);  // 06095DEE mov.l 0x06095EB4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095DF4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095DF4u) return; }  // 06095DF0 jsr @r8 ; nop
    c.r[8] = ld32(0x06095EB8u);  // 06095DF4 mov.l 0x06095EB8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095DFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095DFAu) return; }  // 06095DF6 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06095DFA mov #0,r0
    goto L_06095EA0;  // 06095DFC bra 0x06095EA0 ; nop
L_06095E00:
    c.r[2] = ld32(0x06095EBCu);  // 06095E00 mov.l 0x06095EBC,r2
    c.r[1] = ld32(c.r[2]);  // 06095E02 mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 44);  // 06095E04 mov.l @(44,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06095E06 tst r2,r2
    if (!c.t) { goto L_06095E90; }  // 06095E08 bf 0x06095E90
    c.r[2] = ld32(0x06095EBCu);  // 06095E0A mov.l 0x06095EBC,r2
    c.r[1] = ld32(c.r[2]);  // 06095E0C mov.l @r2,r1
    c.r[2] = 0x1u;  // 06095E0E mov #1,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095E10 mov.l r2,@(44,r1)
    c.r[1] = ld32(c.r[14]);  // 06095E12 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06095E14 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06095E16 mov.l r2,@r14
    c.r[1] = ld32(0x06095EC0u);  // 06095E18 mov.l 0x06095EC0,r1
    c.r[0] = ld32(c.r[1]);  // 06095E1A mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06095E1C cmp/eq #1,r0
    if (!c.t) { goto L_06095E48; }  // 06095E1E bf 0x06095E48
    c.r[1] = c.r[14];  // 06095E20 mov r14,r1
    c.r[1] += 12;  // 06095E22 add #12,r1
    c.r[2] = ld32(c.r[14]);  // 06095E24 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 16);  // 06095E26 mov.l @(16,r2),r3
    c.r[5] = c.r[1];  // 06095E28 mov r1,r5
    c.r[4] = c.r[3];  // 06095E2A mov r3,r4
    c.r[8] = ld32(0x06095EC4u);  // 06095E2C mov.l 0x06095EC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095E32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095E32u) return; }  // 06095E2E jsr @r8 ; nop
    c.r[1] = ld32(0x06095EC0u);  // 06095E32 mov.l 0x06095EC0,r1
    c.r[0] = ld32(c.r[1]);  // 06095E34 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06095E36 cmp/eq #1,r0
    if (!c.t) { goto L_06095E48; }  // 06095E38 bf 0x06095E48
    c.r[2] = ld32(0x06095EBCu);  // 06095E3A mov.l 0x06095EBC,r2
    c.r[1] = ld32(c.r[2]);  // 06095E3C mov.l @r2,r1
    c.r[2] = 0x0u;  // 06095E3E mov #0,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095E40 mov.l r2,@(44,r1)
    c.r[0] = ld32(c.r[14] + 12);  // 06095E42 mov.l @(12,r14),r0
    goto L_06095EA0;  // 06095E44 bra 0x06095EA0 ; nop
L_06095E48:
    c.r[1] = ld32(c.r[14]);  // 06095E48 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06095E4A mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06095E4C mov r2,r1
    c.r[1] += 108;  // 06095E4E add #108,r1
    st32(c.r[14] + 8, c.r[1]);  // 06095E50 mov.l r1,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06095E52 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06095E54 mov r1,r4
    c.r[8] = ld32(0x06095EC8u);  // 06095E56 mov.l 0x06095EC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095E5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095E5Cu) return; }  // 06095E58 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06095E5C mov.l r0,@(4,r14)
    c.r[1] = ld32(0x06095ECCu);  // 06095E5E mov.l 0x06095ECC,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06095E60 mov.l @(8,r14),r2
    c.r[5] = c.r[1];  // 06095E62 mov r1,r5
    c.r[4] = c.r[2];  // 06095E64 mov r2,r4
    c.r[8] = ld32(0x06095ED0u);  // 06095E66 mov.l 0x06095ED0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095E6Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095E6Cu) return; }  // 06095E68 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 06095E6C mov.l @r14,r4
    c.r[8] = ld32(0x06095ED4u);  // 06095E6E mov.l 0x06095ED4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095E74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095E74u) return; }  // 06095E70 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06095E74 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06095E76 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06095E78 mov.l @(8,r14),r2
    c.r[5] = c.r[1];  // 06095E7A mov r1,r5
    c.r[4] = c.r[2];  // 06095E7C mov r2,r4
    c.r[8] = ld32(0x06095ED0u);  // 06095E7E mov.l 0x06095ED0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095E84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095E84u) return; }  // 06095E80 jsr @r8 ; nop
    c.r[2] = ld32(0x06095EBCu);  // 06095E84 mov.l 0x06095EBC,r2
    c.r[1] = ld32(c.r[2]);  // 06095E86 mov.l @r2,r1
    c.r[2] = 0x0u;  // 06095E88 mov #0,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095E8A mov.l r2,@(44,r1)
    goto L_06095E94;  // 06095E8C bra 0x06095E94 ; nop
L_06095E90:
    c.r[1] = 0x0u;  // 06095E90 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 06095E92 mov.l r1,@(12,r14)
L_06095E94:
    c.r[8] = ld32(0x06095ED8u);  // 06095E94 mov.l 0x06095ED8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095E9Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095E9Au) return; }  // 06095E96 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 06095E9A mov.l @(12,r14),r0
    goto L_06095EA0;  // 06095E9C bra 0x06095EA0 ; nop
L_06095EA0:
    c.r[14] += 16;  // 06095EA0 add #16,r14
    c.r[15] = c.r[14];  // 06095EA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095EA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095EA6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095EA8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095EAA rts ; nop
}

void f_06095EFC(SH2Context& c) {
    ran[2272] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06095EFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095EFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06095F00 sts.l pr,@-r15
    c.r[15] -= 16;  // 06095F02 add #-16,r15
    c.r[14] = c.r[15];  // 06095F04 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06095F06 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06095F08 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06095F0A mov.l r6,@(8,r14)
    c.r[1] = ld32(0x06095FC4u);  // 06095F0C mov.l 0x06095FC4,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06095F0E mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 06095F10 mov.l r2,@r1
    c.r[1] = ld32(c.r[14]);  // 06095F12 mov.l @r14,r1
    c.r[2] = 0x3Cu;  // 06095F14 mov #60,r2
    c.macl = c.r[1] * c.r[2];  // 06095F16 mul.l r2,r1
    c.r[1] = c.macl;  // 06095F18 sts macl,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06095F1A mov.l @(4,r14),r2
    c.r[3] = 0x30u;  // 06095F1C mov #48,r3
    c.macl = c.r[2] * c.r[3];  // 06095F1E mul.l r3,r2
    c.r[2] = c.macl;  // 06095F20 sts macl,r2
    c.r[3] = c.r[2];  // 06095F22 mov r2,r3
    c.r[3] += 48;  // 06095F24 add #48,r3
    c.r[1] += c.r[3];  // 06095F26 add r3,r1
    c.r[3] = ld32(0x06095FC4u);  // 06095F28 mov.l 0x06095FC4,r3
    c.r[2] = ld32(c.r[3]);  // 06095F2A mov.l @r3,r2
    c.r[6] = c.r[1];  // 06095F2C mov r1,r6
    c.r[5] = 0x0u;  // 06095F2E mov #0,r5
    c.r[4] = c.r[2];  // 06095F30 mov r2,r4
    c.r[8] = ld32(0x06095FC8u);  // 06095F32 mov.l 0x06095FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06095F38u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06095F38u) return; }  // 06095F34 jsr @r8 ; nop
    c.r[2] = ld32(0x06095FC4u);  // 06095F38 mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F3A mov.l @r2,r1
    c.r[2] = ld32(0x06095FC4u);  // 06095F3C mov.l 0x06095FC4,r2
    c.r[3] = ld32(c.r[2]);  // 06095F3E mov.l @r2,r3
    c.r[2] = c.r[3];  // 06095F40 mov r3,r2
    c.r[2] += 48;  // 06095F42 add #48,r2
    st32(c.r[1], c.r[2]);  // 06095F44 mov.l r2,@r1
    c.r[2] = ld32(0x06095FC4u);  // 06095F46 mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F48 mov.l @r2,r1
    c.r[2] = ld32(c.r[14]);  // 06095F4A mov.l @r14,r2
    st32(c.r[1] + 4, c.r[2]);  // 06095F4C mov.l r2,@(4,r1)
    c.r[2] = ld32(0x06095FC4u);  // 06095F4E mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F50 mov.l @r2,r1
    c.r[3] = ld32(0x06095FC4u);  // 06095F52 mov.l 0x06095FC4,r3
    c.r[2] = ld32(c.r[3]);  // 06095F54 mov.l @r3,r2
    c.r[3] = ld32(c.r[14]);  // 06095F56 mov.l @r14,r3
    c.r[7] = 0x3Cu;  // 06095F58 mov #60,r7
    c.macl = c.r[3] * c.r[7];  // 06095F5A mul.l r7,r3
    c.r[3] = c.macl;  // 06095F5C sts macl,r3
    c.r[2] = ld32(c.r[2]);  // 06095F5E mov.l @r2,r2
    c.r[3] += c.r[2];  // 06095F60 add r2,r3
    st32(c.r[1] + 8, c.r[3]);  // 06095F62 mov.l r3,@(8,r1)
    c.r[2] = ld32(0x06095FC4u);  // 06095F64 mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F66 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06095F68 mov.l @(4,r14),r2
    st32(c.r[1] + 12, c.r[2]);  // 06095F6A mov.l r2,@(12,r1)
    c.r[2] = ld32(0x06095FC4u);  // 06095F6C mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F6E mov.l @r2,r1
    c.r[2] = 0xFFFFFFFFu;  // 06095F70 mov #-1,r2
    st32(c.r[1] + 20, c.r[2]);  // 06095F72 mov.l r2,@(20,r1)
    c.r[2] = ld32(0x06095FC4u);  // 06095F74 mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F76 mov.l @r2,r1
    c.r[2] = 0xFFFFFFFFu;  // 06095F78 mov #-1,r2
    st32(c.r[1] + 24, c.r[2]);  // 06095F7A mov.l r2,@(24,r1)
    c.r[2] = ld32(0x06095FC4u);  // 06095F7C mov.l 0x06095FC4,r2
    c.r[1] = ld32(c.r[2]);  // 06095F7E mov.l @r2,r1
    c.r[2] = 0x0u;  // 06095F80 mov #0,r2
    st32(c.r[1] + 44, c.r[2]);  // 06095F82 mov.l r2,@(44,r1)
    c.r[1] = ld32(0x06095FCCu);  // 06095F84 mov.l 0x06095FCC,r1
    c.r[2] = 0x0u;  // 06095F86 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06095F88 mov.l r2,@r1
    c.r[1] = ld32(0x06095FCCu);  // 06095F8A mov.l 0x06095FCC,r1
    c.r[2] = 0x0u;  // 06095F8C mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 06095F8E mov.l r2,@(4,r1)
    c.r[1] = ld32(0x06095FC4u);  // 06095F90 mov.l 0x06095FC4,r1
    c.r[2] = ld32(c.r[1]);  // 06095F92 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06095F94 mov r2,r1
    c.r[1] += 28;  // 06095F96 add #28,r1
    st32(c.r[14] + 12, c.r[1]);  // 06095F98 mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 06095F9A mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 06095F9C mov #0,r2
    st32(c.r[1], c.r[2]);  // 06095F9E mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 06095FA0 mov.l @(12,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06095FC0u);  // 06095FA2 mov.w 0x06095FC0,r2
    st32(c.r[1] + 4, c.r[2]);  // 06095FA4 mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 06095FA6 mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 06095FA8 mov #0,r2
    st32(c.r[1] + 8, c.r[2]);  // 06095FAA mov.l r2,@(8,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 06095FAC mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 06095FAE mov #0,r2
    st32(c.r[1] + 12, c.r[2]);  // 06095FB0 mov.l r2,@(12,r1)
    c.r[14] += 16;  // 06095FB2 add #16,r14
    c.r[15] = c.r[14];  // 06095FB4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06095FB6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06095FB8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06095FBA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06095FBC rts ; nop
}

void f_06095FD0(SH2Context& c) {
    ran[2273] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06095FD0 mov.l r14,@-r15
    c.r[15] -= 8;  // 06095FD2 add #-8,r15
    c.r[14] = c.r[15];  // 06095FD4 mov r15,r14
    ;  // 06095FD6 nop
    c.r[1] = 0x0u;  // 06095FD8 mov #0,r1
    st32(c.r[14], c.r[1]);  // 06095FDA mov.l r1,@r14
    c.r[2] = ld32(0x0609609Cu);  // 06095FDC mov.l 0x0609609C,r2
    c.r[1] = ld32(c.r[2]);  // 06095FDE mov.l @r2,r1
    c.r[2] = ld32(c.r[1]);  // 06095FE0 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06095FE2 mov.l r2,@(4,r14)
L_06095FE4:
    c.r[2] = ld32(0x0609609Cu);  // 06095FE4 mov.l 0x0609609C,r2
    c.r[1] = ld32(c.r[2]);  // 06095FE6 mov.l @r2,r1
    c.r[2] = ld32(c.r[14]);  // 06095FE8 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 4);  // 06095FEA mov.l @(4,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06095FEC cmp/ge r1,r2
    if (!c.t) { goto L_06095FF4; }  // 06095FEE bf 0x06095FF4
    goto L_06096088;  // 06095FF0 bra 0x06096088 ; nop
L_06095FF4:
    c.r[2] = ld32(c.r[14] + 4);  // 06095FF4 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06095FF6 mov r2,r1
    c.r[2] += 58;  // 06095FF8 add #58,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06095FFA mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06095FFC extu.b r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06095FFE tst r1,r1
    if (!c.t) { goto L_06096070; }  // 06096000 bf 0x06096070
    c.r[1] = ld32(c.r[14] + 4);  // 06096002 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 06096004 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06096006 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 06096008 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0609600A mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 0609600C mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0609600E mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 06096010 mov #0,r2
    st32(c.r[1] + 8, c.r[2]);  // 06096012 mov.l r2,@(8,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096014 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 06096016 mov #0,r2
    st32(c.r[1] + 12, c.r[2]);  // 06096018 mov.l r2,@(12,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0609601A mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0609601C mov #0,r2
    st32(c.r[1] + 16, c.r[2]);  // 0609601E mov.l r2,@(16,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096020 mov.l @(4,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06096098u);  // 06096022 mov.w 0x06096098,r2
    st32(c.r[1] + 20, c.r[2]);  // 06096024 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096026 mov.l @(4,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609609Au);  // 06096028 mov.w 0x0609609A,r2
    st32(c.r[1] + 24, c.r[2]);  // 0609602A mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0609602C mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0609602E mov #0,r2
    st32(c.r[1] + 28, c.r[2]);  // 06096030 mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096032 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 06096034 mov #0,r2
    st32(c.r[1] + 32, c.r[2]);  // 06096036 mov.l r2,@(32,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096038 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0609603A mov #0,r2
    st32(c.r[1] + 36, c.r[2]);  // 0609603C mov.l r2,@(36,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0609603E mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 06096040 mov #0,r2
    st32(c.r[1] + 40, c.r[2]);  // 06096042 mov.l r2,@(40,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096044 mov.l @(4,r14),r1
    c.r[2] = ld32(0x060960A0u);  // 06096046 mov.l 0x060960A0,r2
    st32(c.r[1] + 44, c.r[2]);  // 06096048 mov.l r2,@(44,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0609604A mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0609604C mov #0,r2
    st32(c.r[1] + 48, c.r[2]);  // 0609604E mov.l r2,@(48,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06096050 mov.l @(4,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 06096052 mov #-1,r2
    st32(c.r[1] + 52, c.r[2]);  // 06096054 mov.l r2,@(52,r1)
    c.r[2] = ld32(c.r[14] + 4);  // 06096056 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096058 mov r2,r1
    c.r[2] += 56;  // 0609605A add #56,r2
    c.r[1] = 0x0u;  // 0609605C mov #0,r1
    st16(c.r[2], c.r[1]);  // 0609605E mov.w r1,@r2
    c.r[2] = ld32(c.r[14] + 4);  // 06096060 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096062 mov r2,r1
    c.r[2] += 58;  // 06096064 add #58,r2
    c.r[1] = 0x1u;  // 06096066 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06096068 mov.b r1,@r2
    c.r[0] = ld32(c.r[14] + 4);  // 0609606A mov.l @(4,r14),r0
    goto L_0609608E;  // 0609606C bra 0x0609608E ; nop
L_06096070:
    c.r[2] = ld32(c.r[14]);  // 06096070 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096072 mov r2,r1
    c.r[1] += 1;  // 06096074 add #1,r1
    c.r[2] = c.r[1];  // 06096076 mov r1,r2
    st32(c.r[14], c.r[2]);  // 06096078 mov.l r2,@r14
    c.r[2] = ld32(c.r[14] + 4);  // 0609607A mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0609607C mov r2,r1
    c.r[1] += 60;  // 0609607E add #60,r1
    c.r[2] = c.r[1];  // 06096080 mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096082 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_06095FE4;  // 06096084 bra 0x06095FE4 ; nop
L_06096088:
    c.r[0] = 0x0u;  // 06096088 mov #0,r0
    goto L_0609608E;  // 0609608A bra 0x0609608E ; nop
L_0609608E:
    c.r[14] += 8;  // 0609608E add #8,r14
    c.r[15] = c.r[14];  // 06096090 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096092 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096094 rts ; nop
}

void f_060960A4(SH2Context& c) {
    ran[2274] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060960A4 mov.l r14,@-r15
    c.r[15] -= 8;  // 060960A6 add #-8,r15
    c.r[14] = c.r[15];  // 060960A8 mov r15,r14
    ;  // 060960AA nop
    c.r[1] = 0x0u;  // 060960AC mov #0,r1
    st32(c.r[14], c.r[1]);  // 060960AE mov.l r1,@r14
    c.r[2] = ld32(0x06096104u);  // 060960B0 mov.l 0x06096104,r2
    c.r[1] = ld32(c.r[2]);  // 060960B2 mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 8);  // 060960B4 mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 060960B6 mov.l r2,@(4,r14)
L_060960B8:
    c.r[2] = ld32(0x06096104u);  // 060960B8 mov.l 0x06096104,r2
    c.r[1] = ld32(c.r[2]);  // 060960BA mov.l @r2,r1
    c.r[2] = ld32(c.r[14]);  // 060960BC mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 12);  // 060960BE mov.l @(12,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060960C0 cmp/ge r1,r2
    if (!c.t) { goto L_060960C8; }  // 060960C2 bf 0x060960C8
    goto L_060960F4;  // 060960C4 bra 0x060960F4 ; nop
L_060960C8:
    c.r[2] = ld32(c.r[14] + 4);  // 060960C8 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060960CA mov r2,r1
    c.r[2] += 45;  // 060960CC add #45,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060960CE mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 060960D0 extu.b r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060960D2 tst r1,r1
    if (!c.t) { goto L_060960DC; }  // 060960D4 bf 0x060960DC
    c.r[0] = ld32(c.r[14] + 4);  // 060960D6 mov.l @(4,r14),r0
    goto L_060960FA;  // 060960D8 bra 0x060960FA ; nop
L_060960DC:
    c.r[2] = ld32(c.r[14]);  // 060960DC mov.l @r14,r2
    c.r[1] = c.r[2];  // 060960DE mov r2,r1
    c.r[1] += 1;  // 060960E0 add #1,r1
    c.r[2] = c.r[1];  // 060960E2 mov r1,r2
    st32(c.r[14], c.r[2]);  // 060960E4 mov.l r2,@r14
    c.r[2] = ld32(c.r[14] + 4);  // 060960E6 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060960E8 mov r2,r1
    c.r[1] += 48;  // 060960EA add #48,r1
    c.r[2] = c.r[1];  // 060960EC mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 060960EE mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_060960B8;  // 060960F0 bra 0x060960B8 ; nop
L_060960F4:
    c.r[0] = 0x0u;  // 060960F4 mov #0,r0
    goto L_060960FA;  // 060960F6 bra 0x060960FA ; nop
L_060960FA:
    c.r[14] += 8;  // 060960FA add #8,r14
    c.r[15] = c.r[14];  // 060960FC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060960FE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096100 rts ; nop
}

void f_06096108(SH2Context& c) {
    ran[2275] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096108 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609610A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609610C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609610E add #-16,r15
    c.r[14] = c.r[15];  // 06096110 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096112 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06096114 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 12);  // 06096116 mov.l @(12,r1),r2
    st32(c.r[14] + 12, c.r[2]);  // 06096118 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0609611A mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609611C tst r1,r1
    if (!c.t) { goto L_0609612A; }  // 0609611E bf 0x0609612A
    c.r[0] = (uint32_t)(int16_t)ld16(0x06096156u);  // 06096120 mov.w 0x06096156,r0
    goto L_06096148;  // 06096122 bra 0x06096148 ; nop
L_0609612A:
    c.r[1] = c.r[14];  // 0609612A mov r14,r1
    c.r[1] += 8;  // 0609612C add #8,r1
    c.r[2] = c.r[14];  // 0609612E mov r14,r2
    c.r[2] += 4;  // 06096130 add #4,r2
    c.r[7] = ld32(c.r[14] + 12);  // 06096132 mov.l @(12,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06096134 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06096136 mov r1,r6
    c.r[5] = c.r[2];  // 06096138 mov r2,r5
    c.r[4] = c.r[3];  // 0609613A mov r3,r4
    c.r[8] = ld32(0x06096158u);  // 0609613C mov.l 0x06096158,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096142u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096142u) return; }  // 0609613E jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 8);  // 06096142 mov.l @(8,r14),r0
    goto L_06096148;  // 06096144 bra 0x06096148 ; nop
L_06096148:
    c.r[14] += 16;  // 06096148 add #16,r14
    c.r[15] = c.r[14];  // 0609614A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609614C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609614E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06096150 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096152 rts ; nop
}

void f_0609615C(SH2Context& c) {
    ran[2276] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609615C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609615E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096160 sts.l pr,@-r15
    c.r[15] -= 8;  // 06096162 add #-8,r15
    c.r[14] = c.r[15];  // 06096164 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096166 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06096168 mov.l @r14,r1
    c.r[3] = 0xEu;  // 0609616A mov #14,r3
    c.r[2] = 0xFFFFFFF0u;  // 0609616C mov #-16,r2
    c.r[1] -= c.r[2];  // 0609616E sub r2,r1
    c.t = c.r[1] > c.r[3];  // 06096170 cmp/hi r3,r1
    if (c.t) { goto L_060961C6; }  // 06096172 bt 0x060961C6
    c.r[1] += c.r[1];  // 06096174 add r1,r1
    c.r[0] = 0x06096180u;  // 06096176 mova 0x06096180,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06096178 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0609617A add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060961B6u: goto L_060961B6; case 0x060961AEu: goto L_060961AE; case 0x060961A6u: goto L_060961A6; case 0x0609619Eu: goto L_0609619E; case 0x060961BEu: goto L_060961BE; case 0x060961C6u: goto L_060961C6; default: sh2_call(c, x); return; } }  // 0609617C jmp @r0 ; nop
L_0609619E:
    c.r[1] = 0xFFFFFFEAu;  // 0609619E mov #-22,r1
    st32(c.r[14] + 4, c.r[1]);  // 060961A0 mov.l r1,@(4,r14)
    goto L_060961CA;  // 060961A2 bra 0x060961CA ; nop
L_060961A6:
    c.r[1] = 0xFFFFFFE9u;  // 060961A6 mov #-23,r1
    st32(c.r[14] + 4, c.r[1]);  // 060961A8 mov.l r1,@(4,r14)
    goto L_060961CA;  // 060961AA bra 0x060961CA ; nop
L_060961AE:
    c.r[1] = 0xFFFFFFFEu;  // 060961AE mov #-2,r1
    st32(c.r[14] + 4, c.r[1]);  // 060961B0 mov.l r1,@(4,r14)
    goto L_060961CA;  // 060961B2 bra 0x060961CA ; nop
L_060961B6:
    c.r[1] = 0xFFFFFFE7u;  // 060961B6 mov #-25,r1
    st32(c.r[14] + 4, c.r[1]);  // 060961B8 mov.l r1,@(4,r14)
    goto L_060961CA;  // 060961BA bra 0x060961CA ; nop
L_060961BE:
    c.r[1] = 0xFFFFFFFFu;  // 060961BE mov #-1,r1
    st32(c.r[14] + 4, c.r[1]);  // 060961C0 mov.l r1,@(4,r14)
    goto L_060961CA;  // 060961C2 bra 0x060961CA ; nop
L_060961C6:
    c.r[1] = 0x0u;  // 060961C6 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 060961C8 mov.l r1,@(4,r14)
L_060961CA:
    c.r[1] = ld32(c.r[14] + 4);  // 060961CA mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 060961CC mov r1,r4
    c.r[8] = ld32(0x060961E4u);  // 060961CE mov.l 0x060961E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060961D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060961D4u) return; }  // 060961D0 jsr @r8 ; nop
    c.r[14] += 8;  // 060961D4 add #8,r14
    c.r[15] = c.r[14];  // 060961D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060961D8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060961DA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060961DC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060961DE rts ; nop
}

void f_060961E8(SH2Context& c) {
    ran[2277] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060961E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060961EA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060961EC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060961EE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060961F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060961F2 sts.l pr,@-r15
    c.r[15] -= 40;  // 060961F4 add #-40,r15
    c.r[14] = c.r[15];  // 060961F6 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060961F8 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060961FA mov.l r5,@(4,r14)
    c.r[9] = c.r[6];  // 060961FC mov r6,r9
    c.r[8] = c.r[14];  // 060961FE mov r14,r8
    c.r[10] = c.r[14];  // 06096200 mov r14,r10
    c.r[10] += 8;  // 06096202 add #8,r10
    st8(c.r[10], c.r[9]);  // 06096204 mov.b r9,@r10
    c.r[1] = c.r[14];  // 06096206 mov r14,r1
    c.r[1] += 24;  // 06096208 add #24,r1
    c.r[2] = c.r[14];  // 0609620A mov r14,r2
    c.r[2] += 20;  // 0609620C add #20,r2
    c.r[7] = ld32(c.r[14] + 4);  // 0609620E mov.l @(4,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06096210 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06096212 mov r1,r6
    c.r[5] = c.r[2];  // 06096214 mov r2,r5
    c.r[4] = c.r[3];  // 06096216 mov r3,r4
    c.r[11] = ld32(0x060963BCu);  // 06096218 mov.l 0x060963BC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609621Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609621Eu) return; }  // 0609621A jsr @r11 ; nop
    c.r[1] = ld32(c.r[14]);  // 0609621E mov.l @r14,r1
    st32(c.r[14] + 12, c.r[1]);  // 06096220 mov.l r1,@(12,r14)
L_06096222:
    c.r[1] = ld32(c.r[14] + 12);  // 06096222 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06096224 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096226 tst r2,r2
    if (!c.t) { goto L_0609622E; }  // 06096228 bf 0x0609622E
    goto L_06096262;  // 0609622A bra 0x06096262 ; nop
L_0609622E:
    c.r[1] = c.r[14];  // 0609622E mov r14,r1
    c.r[1] += 32;  // 06096230 add #32,r1
    c.r[2] = c.r[14];  // 06096232 mov r14,r2
    c.r[2] += 28;  // 06096234 add #28,r2
    c.r[3] = ld32(c.r[14] + 12);  // 06096236 mov.l @(12,r14),r3
    c.r[7] = ld32(c.r[3]);  // 06096238 mov.l @r3,r7
    c.r[3] = ld32(c.r[7] + 20);  // 0609623A mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 0609623C mov r1,r6
    c.r[5] = c.r[2];  // 0609623E mov r2,r5
    c.r[4] = c.r[3];  // 06096240 mov r3,r4
    c.r[11] = ld32(0x060963BCu);  // 06096242 mov.l 0x060963BC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096248u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096248u) return; }  // 06096244 jsr @r11 ; nop
    c.r[1] = ld32(c.r[14] + 20);  // 06096248 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0609624A mov.l @(28,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0609624C cmp/gt r2,r1
    if (c.t) { goto L_06096254; }  // 0609624E bt 0x06096254
    goto L_06096262;  // 06096250 bra 0x06096262 ; nop
L_06096254:
    c.r[1] = ld32(c.r[14] + 12);  // 06096254 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06096256 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06096258 mov r2,r1
    c.r[1] += 8;  // 0609625A add #8,r1
    st32(c.r[14] + 12, c.r[1]);  // 0609625C mov.l r1,@(12,r14)
    SH2_POLL(c); goto L_06096222;  // 0609625E bra 0x06096222 ; nop
L_06096262:
    c.r[1] = ld32(c.r[14] + 4);  // 06096262 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06096264 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2]);  // 06096266 mov.l @r2,r3
    st32(c.r[1] + 8, c.r[3]);  // 06096268 mov.l r3,@(8,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0609626A mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609626C mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0609626E mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 06096270 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06096272 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06096274 mov r2,r1
    c.r[1] += 28;  // 06096276 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06096278 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609627A tst r2,r2
    if (c.t) { goto L_06096282; }  // 0609627C bt 0x06096282
    goto L_06096366;  // 0609627E bra 0x06096366 ; nop
L_06096282:
    c.r[4] = ld32(c.r[14]);  // 06096282 mov.l @r14,r4
    c.r[11] = ld32(0x060963C0u);  // 06096284 mov.l 0x060963C0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609628Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609628Au) return; }  // 06096286 jsr @r11 ; nop
    st32(c.r[14] + 32, c.r[0]);  // 0609628A mov.l r0,@(32,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0609628C mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 32);  // 0609628E mov.l @(32,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06096290 cmp/gt r2,r1
    if (!c.t) { goto L_0609629A; }  // 06096292 bf 0x0609629A
    c.r[1] = ld32(c.r[14]);  // 06096294 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06096296 mov.l @(4,r14),r2
    st32(c.r[1] + 12, c.r[2]);  // 06096298 mov.l r2,@(12,r1)
L_0609629A:
    c.r[1] = 0x0u;  // 0609629A mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 0609629C mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14]);  // 0609629E mov.l @r14,r1
    c.r[2] = c.r[1];  // 060962A0 mov r1,r2
    c.r[2] += 4;  // 060962A2 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 060962A4 mov.l r2,@(12,r14)
L_060962A6:
    c.r[1] = ld32(c.r[14] + 12);  // 060962A6 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060962A8 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060962AA tst r2,r2
    if (!c.t) { goto L_060962B2; }  // 060962AC bf 0x060962B2
    goto L_060962C6;  // 060962AE bra 0x060962C6 ; nop
L_060962B2:
    c.r[1] = ld32(c.r[14] + 12);  // 060962B2 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060962B4 mov.l @r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 060962B6 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 060962B8 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060962BA mov.l @r1,r2
    c.r[1] = c.r[2];  // 060962BC mov r2,r1
    c.r[1] += 12;  // 060962BE add #12,r1
    st32(c.r[14] + 12, c.r[1]);  // 060962C0 mov.l r1,@(12,r14)
    SH2_POLL(c); goto L_060962A6;  // 060962C2 bra 0x060962A6 ; nop
L_060962C6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060963B8u);  // 060962C6 mov.w 0x060963B8,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060962C8 mov.l @(4,r14),r2
    c.r[7] = ld32(c.r[2] + 20);  // 060962CA mov.l @(20,r2),r7
    c.r[3] = c.r[7];  // 060962CC mov r7,r3
    c.r[3] += 28;  // 060962CE add #28,r3
    c.r[2] = ld32(c.r[3] + 4);  // 060962D0 mov.l @(4,r3),r2
    c.r[3] = ld32(c.r[14] + 4);  // 060962D2 mov.l @(4,r14),r3
    c.r[6] = ld32(c.r[3] + 20);  // 060962D4 mov.l @(20,r3),r6
    c.r[7] = c.r[6];  // 060962D6 mov r6,r7
    c.r[7] += 28;  // 060962D8 add #28,r7
    c.r[3] = ld32(c.r[7] + 12);  // 060962DA mov.l @(12,r7),r3
    c.r[6] = c.r[1];  // 060962DC mov r1,r6
    c.r[5] = c.r[2];  // 060962DE mov r2,r5
    c.r[4] = c.r[3];  // 060962E0 mov r3,r4
    c.r[11] = ld32(0x060963C4u);  // 060962E2 mov.l 0x060963C4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060962E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060962E8u) return; }  // 060962E4 jsr @r11 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 060962E8 mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060962EA tst r1,r1
    if (c.t) { goto L_0609631C; }  // 060962EC bt 0x0609631C
    c.r[1] = ld32(c.r[14] + 4);  // 060962EE mov.l @(4,r14),r1
    c.r[3] = ld32(c.r[1] + 20);  // 060962F0 mov.l @(20,r1),r3
    c.r[2] = c.r[3];  // 060962F2 mov r3,r2
    c.r[2] += 28;  // 060962F4 add #28,r2
    c.r[1] = ld32(c.r[2] + 4);  // 060962F6 mov.l @(4,r2),r1
    c.r[2] = ld32(c.r[14] + 16);  // 060962F8 mov.l @(16,r14),r2
    c.r[7] = ld32(c.r[2] + 20);  // 060962FA mov.l @(20,r2),r7
    c.r[3] = c.r[7];  // 060962FC mov r7,r3
    c.r[3] += 28;  // 060962FE add #28,r3
    c.r[2] = ld32(c.r[3] + 4);  // 06096300 mov.l @(4,r3),r2
    c.r[3] = ld32(c.r[14] + 16);  // 06096302 mov.l @(16,r14),r3
    c.r[6] = ld32(c.r[3] + 20);  // 06096304 mov.l @(20,r3),r6
    c.r[7] = c.r[6];  // 06096306 mov r6,r7
    c.r[7] += 28;  // 06096308 add #28,r7
    c.r[3] = ld32(c.r[7] + 12);  // 0609630A mov.l @(12,r7),r3
    c.r[6] = c.r[1];  // 0609630C mov r1,r6
    c.r[5] = c.r[2];  // 0609630E mov r2,r5
    c.r[4] = c.r[3];  // 06096310 mov r3,r4
    c.r[11] = ld32(0x060963C4u);  // 06096312 mov.l 0x060963C4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096318u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096318u) return; }  // 06096314 jsr @r11 ; nop
    goto L_0609633C;  // 06096318 bra 0x0609633C ; nop
L_0609631C:
    c.r[1] = ld32(c.r[14]);  // 0609631C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 0609631E mov.l @(52,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06096320 cmp/pz r2
    if (!c.t) { goto L_0609633C; }  // 06096322 bf 0x0609633C
    c.r[2] = ld32(c.r[14]);  // 06096324 mov.l @r14,r2
    c.r[1] = ld32(c.r[2] + 52);  // 06096326 mov.l @(52,r2),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06096328 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2] + 20);  // 0609632A mov.l @(20,r2),r3
    c.r[2] = c.r[3];  // 0609632C mov r3,r2
    c.r[2] += 28;  // 0609632E add #28,r2
    c.r[3] = ld32(c.r[2] + 12);  // 06096330 mov.l @(12,r2),r3
    c.r[5] = c.r[1];  // 06096332 mov r1,r5
    c.r[4] = c.r[3];  // 06096334 mov r3,r4
    c.r[11] = ld32(0x060963C8u);  // 06096336 mov.l 0x060963C8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609633Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609633Cu) return; }  // 06096338 jsr @r11 ; nop
L_0609633C:
    c.r[1] = ld32(c.r[14] + 12);  // 0609633C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609633E mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 06096340 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 06096342 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 06096344 mov #0,r2
    st32(c.r[1] + 12, c.r[2]);  // 06096346 mov.l r2,@(12,r1)
    c.r[11] = ld32(0x060963CCu);  // 06096348 mov.l 0x060963CC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609634Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609634Eu) return; }  // 0609634A jsr @r11 ; nop
    st32(c.r[14] + 36, c.r[0]);  // 0609634E mov.l r0,@(36,r14)
    c.r[1] = ld32(c.r[14] + 36);  // 06096350 mov.l @(36,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096352 tst r1,r1
    if (c.t) { goto L_06096366; }  // 06096354 bt 0x06096366
    c.r[1] = ld32(c.r[14] + 36);  // 06096356 mov.l @(36,r14),r1
    c.r[4] = c.r[1];  // 06096358 mov r1,r4
    c.r[11] = ld32(0x060963D0u);  // 0609635A mov.l 0x060963D0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096360u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096360u) return; }  // 0609635C jsr @r11 ; nop
    c.r[0] = 0x0u;  // 06096360 mov #0,r0
    goto L_060963A4;  // 06096362 bra 0x060963A4 ; nop
L_06096366:
    c.r[2] = ld32(c.r[14]);  // 06096366 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096368 mov r2,r1
    c.r[2] += 56;  // 0609636A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609636C mov.w @r2,r1
    c.r[2] = 0x1u;  // 0609636E mov #1,r2
    c.r[2] &= c.r[1];  // 06096370 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06096372 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096374 tst r1,r1
    if (c.t) { goto L_0609637C; }  // 06096376 bt 0x0609637C
    goto L_0609639E;  // 06096378 bra 0x0609639E ; nop
L_0609637C:
    c.r[1] = c.r[14];  // 0609637C mov r14,r1
    c.r[2] = c.r[14];  // 0609637E mov r14,r2
    c.r[2] += 8;  // 06096380 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06096382 mov.b @r2,r1
    c.r[2] = 0x2u;  // 06096384 mov #2,r2
    c.r[2] &= c.r[1];  // 06096386 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06096388 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609638A tst r1,r1
    if (!c.t) { goto L_0609639E; }  // 0609638C bf 0x0609639E
    c.r[1] = ld32(c.r[14]);  // 0609638E mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06096390 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1]);  // 06096392 mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 06096394 cmp/eq r1,r2
    if (!c.t) { goto L_0609639E; }  // 06096396 bf 0x0609639E
    c.r[1] = ld32(c.r[14]);  // 06096398 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609639A mov.l @(4,r14),r2
    st32(c.r[1] + 8, c.r[2]);  // 0609639C mov.l r2,@(8,r1)
L_0609639E:
    c.r[0] = 0x1u;  // 0609639E mov #1,r0
    goto L_060963A4;  // 060963A0 bra 0x060963A4 ; nop
L_060963A4:
    c.r[14] += 40;  // 060963A4 add #40,r14
    c.r[15] = c.r[14];  // 060963A6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060963A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060963AA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060963AC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060963AE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060963B0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060963B2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060963B4 rts ; nop
}

void f_060963D4(SH2Context& c) {
    ran[2278] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060963D4 mov.l r14,@-r15
    c.r[15] -= 8;  // 060963D6 add #-8,r15
    c.r[14] = c.r[15];  // 060963D8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060963DA mov.l r4,@r14
    c.r[1] = 0x40u;  // 060963DC mov #64,r1
    st32(c.r[14] + 4, c.r[1]);  // 060963DE mov.l r1,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060963E0 mov.l @r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060963E2 mov.w @r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060963E4 cmp/eq #-1,r0
    if (c.t) { goto L_060963F0; }  // 060963E6 bt 0x060963F0
    c.r[1] = ld32(c.r[14] + 4);  // 060963E8 mov.l @(4,r14),r1
    c.r[2] = 0x1u;  // 060963EA mov #1,r2
    c.r[2] |= c.r[1];  // 060963EC or r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 060963EE mov.l r2,@(4,r14)
L_060963F0:
    c.r[2] = ld32(c.r[14]);  // 060963F0 mov.l @r14,r2
    c.r[1] = c.r[2];  // 060963F2 mov r2,r1
    c.r[2] += 2;  // 060963F4 add #2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060963F6 mov.w @r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060963F8 cmp/eq #-1,r0
    if (c.t) { goto L_06096404; }  // 060963FA bt 0x06096404
    c.r[1] = ld32(c.r[14] + 4);  // 060963FC mov.l @(4,r14),r1
    c.r[2] = 0x2u;  // 060963FE mov #2,r2
    c.r[2] |= c.r[1];  // 06096400 or r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096402 mov.l r2,@(4,r14)
L_06096404:
    c.r[2] = ld32(c.r[14]);  // 06096404 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096406 mov r2,r1
    c.r[2] += 4;  // 06096408 add #4,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609640A mov.w @r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609640C cmp/eq #-1,r0
    if (c.t) { goto L_06096418; }  // 0609640E bt 0x06096418
    c.r[1] = ld32(c.r[14] + 4);  // 06096410 mov.l @(4,r14),r1
    c.r[2] = 0x4u;  // 06096412 mov #4,r2
    c.r[2] |= c.r[1];  // 06096414 or r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096416 mov.l r2,@(4,r14)
L_06096418:
    c.r[2] = ld32(c.r[14]);  // 06096418 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0609641A mov r2,r1
    c.r[2] += 8;  // 0609641C add #8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609641E mov.w @r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06096420 cmp/eq #-1,r0
    if (c.t) { goto L_0609642C; }  // 06096422 bt 0x0609642C
    c.r[1] = ld32(c.r[14] + 4);  // 06096424 mov.l @(4,r14),r1
    c.r[2] = 0x8u;  // 06096426 mov #8,r2
    c.r[2] |= c.r[1];  // 06096428 or r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0609642A mov.l r2,@(4,r14)
L_0609642C:
    c.r[0] = ld32(c.r[14] + 4);  // 0609642C mov.l @(4,r14),r0
    goto L_06096432;  // 0609642E bra 0x06096432 ; nop
L_06096432:
    c.r[14] += 8;  // 06096432 add #8,r14
    c.r[15] = c.r[14];  // 06096434 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096436 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096438 rts ; nop
}

void f_0609643C(SH2Context& c) {
    ran[2279] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609643C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609643E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096440 sts.l pr,@-r15
    c.r[15] -= 16;  // 06096442 add #-16,r15
    c.r[14] = c.r[15];  // 06096444 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096446 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06096448 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609644A mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609644C mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14]);  // 0609644E mov.l @r14,r3
    c.r[2] = c.r[3];  // 06096450 mov r3,r2
    c.r[3] += 1;  // 06096452 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06096454 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06096456 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 06096458 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0609645A mov r1,r2
    c.r[1] += 1;  // 0609645C add #1,r1
    c.r[3] = ld32(c.r[14]);  // 0609645E mov.l @r14,r3
    c.r[2] = c.r[3];  // 06096460 mov r3,r2
    c.r[3] += 2;  // 06096462 add #2,r3
    c.r[2] = c.r[3];  // 06096464 mov r3,r2
    c.r[3] += 1;  // 06096466 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06096468 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609646A mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0609646C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0609646E mov r1,r2
    c.r[1] += 2;  // 06096470 add #2,r1
    c.r[3] = ld32(c.r[14]);  // 06096472 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06096474 mov r3,r2
    c.r[3] += 4;  // 06096476 add #4,r3
    c.r[2] = c.r[3];  // 06096478 mov r3,r2
    c.r[3] += 1;  // 0609647A add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609647C mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609647E mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 06096480 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06096482 mov r1,r2
    c.r[1] += 3;  // 06096484 add #3,r1
    c.r[3] = ld32(c.r[14]);  // 06096486 mov.l @r14,r3
    c.r[2] = c.r[3];  // 06096488 mov r3,r2
    c.r[3] += 6;  // 0609648A add #6,r3
    c.r[2] = c.r[3];  // 0609648C mov r3,r2
    c.r[3] += 1;  // 0609648E add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06096490 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06096492 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 06096494 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06096496 mov r1,r2
    c.r[1] += 4;  // 06096498 add #4,r1
    c.r[3] = ld32(c.r[14]);  // 0609649A mov.l @r14,r3
    c.r[2] = c.r[3];  // 0609649C mov r3,r2
    c.r[3] += 8;  // 0609649E add #8,r3
    c.r[2] = c.r[3];  // 060964A0 mov r3,r2
    c.r[3] += 1;  // 060964A2 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060964A4 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060964A6 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 060964A8 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 060964AA mov r1,r2
    c.r[1] += 5;  // 060964AC add #5,r1
    c.r[3] = ld32(c.r[14]);  // 060964AE mov.l @r14,r3
    c.r[2] = c.r[3];  // 060964B0 mov r3,r2
    c.r[3] += 10;  // 060964B2 add #10,r3
    c.r[2] = c.r[3];  // 060964B4 mov r3,r2
    c.r[3] += 1;  // 060964B6 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060964B8 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060964BA mov.b r2,@r1
    c.r[4] = ld32(c.r[14]);  // 060964BC mov.l @r14,r4
    c.r[8] = ld32(0x060964DCu);  // 060964BE mov.l 0x060964DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060964C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060964C4u) return; }  // 060964C0 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 060964C4 mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 060964C6 mov.l @(12,r14),r0
    goto L_060964CC;  // 060964C8 bra 0x060964CC ; nop
L_060964CC:
    c.r[14] += 16;  // 060964CC add #16,r14
    c.r[15] = c.r[14];  // 060964CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060964D0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060964D2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060964D4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060964D6 rts ; nop
}

void f_060964E0(SH2Context& c) {
    ran[2280] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060964E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060964E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060964E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060964E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060964E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060964EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060964EC sts.l pr,@-r15
    c.r[15] -= 64;  // 060964EE add #-64,r15
    c.r[14] = c.r[15];  // 060964F0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060964F2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060964F4 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 060964F6 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 060964F8 mov.l r7,@(12,r14)
    c.r[12] = 0x60u;  // 060964FA mov #96,r12
    c.r[12] += c.r[14];  // 060964FC add r14,r12
    c.r[9] = ld32(c.r[12]);  // 060964FE mov.l @r12,r9
    c.r[8] = c.r[14];  // 06096500 mov r14,r8
    c.r[10] = c.r[14];  // 06096502 mov r14,r10
    c.r[10] += 16;  // 06096504 add #16,r10
    st8(c.r[10], c.r[9]);  // 06096506 mov.b r9,@r10
    c.r[1] = ld32(c.r[14] + 8);  // 06096508 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0609650A mov r1,r2
    c.r[2] += 12;  // 0609650C add #12,r2
    st32(c.r[14] + 20, c.r[2]);  // 0609650E mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06096510 mov.l @(20,r14),r1
    st32(c.r[14] + 24, c.r[1]);  // 06096512 mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 06096514 mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06096516 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06096518 mov r2,r1
    c.r[1] -= 1;  // 0609651A add #-1,r1
    c.r[2] = ld32(c.r[14] + 24);  // 0609651C mov.l @(24,r14),r2
    c.r[5] = c.r[1];  // 0609651E mov r1,r5
    c.r[4] = c.r[2];  // 06096520 mov r2,r4
    c.r[11] = ld32(0x060966F8u);  // 06096522 mov.l 0x060966F8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096528u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096528u) return; }  // 06096524 jsr @r11 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06096528 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0609652A mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0609652C mov.l @(28,r14),r2
    c.r[3] = c.r[2];  // 0609652E mov r2,r3
    c.r[3] += 1;  // 06096530 add #1,r3
    st32(c.r[1] + 20, c.r[3]);  // 06096532 mov.l r3,@(20,r1)
    c.r[1] = ld32(c.r[14] + 24);  // 06096534 mov.l @(24,r14),r1
    c.r[2] = 0x0u;  // 06096536 mov #0,r2
    st32(c.r[1] + 24, c.r[2]);  // 06096538 mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14]);  // 0609653A mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0609653C mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0609653E mov.l r2,@r1
    c.r[1] = ld32(c.r[14]);  // 06096540 mov.l @r14,r1
    c.r[2] = ld32(c.r[14]);  // 06096542 mov.l @r14,r2
    st32(c.r[1] + 4, c.r[2]);  // 06096544 mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14]);  // 06096546 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06096548 mov.l @(8,r14),r2
    st32(c.r[1] + 16, c.r[2]);  // 0609654A mov.l r2,@(16,r1)
    c.r[1] = ld32(c.r[14]);  // 0609654C mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 20);  // 0609654E mov.l @(20,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 06096550 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14]);  // 06096552 mov.l @r14,r1
    c.r[2] = 0x0u;  // 06096554 mov #0,r2
    st32(c.r[1] + 24, c.r[2]);  // 06096556 mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14]);  // 06096558 mov.l @r14,r1
    c.r[2] = 0x0u;  // 0609655A mov #0,r2
    st32(c.r[1] + 28, c.r[2]);  // 0609655C mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14]);  // 0609655E mov.l @r14,r1
    c.r[2] = c.r[1];  // 06096560 mov r1,r2
    c.r[1] += 44;  // 06096562 add #44,r1
    c.r[2] = c.r[14];  // 06096564 mov r14,r2
    c.r[3] = c.r[14];  // 06096566 mov r14,r3
    c.r[3] += 16;  // 06096568 add #16,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609656A mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609656C mov.b r2,@r1
    c.r[1] = c.r[14];  // 0609656E mov r14,r1
    c.r[1] += 36;  // 06096570 add #36,r1
    c.r[2] = c.r[14];  // 06096572 mov r14,r2
    c.r[2] += 32;  // 06096574 add #32,r2
    c.r[3] = ld32(c.r[14] + 20);  // 06096576 mov.l @(20,r14),r3
    c.r[6] = c.r[1];  // 06096578 mov r1,r6
    c.r[5] = c.r[2];  // 0609657A mov r2,r5
    c.r[4] = c.r[3];  // 0609657C mov r3,r4
    c.r[11] = ld32(0x060966FCu);  // 0609657E mov.l 0x060966FC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096584u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096584u) return; }  // 06096580 jsr @r11 ; nop
    c.r[2] = ld32(c.r[14] + 4);  // 06096584 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096586 mov r2,r1
    c.r[2] += 56;  // 06096588 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0609658A mov.w @r2,r1
    c.r[2] = 0x2u;  // 0609658C mov #2,r2
    c.r[2] &= c.r[1];  // 0609658E and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06096590 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096592 tst r1,r1
    if (c.t) { goto L_060965B4; }  // 06096594 bt 0x060965B4
    c.r[1] = ld32(c.r[14] + 4);  // 06096596 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 32);  // 06096598 mov.l @(32,r14),r2
    c.r[1] = ld32(c.r[1] + 20);  // 0609659A mov.l @(20,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0609659C cmp/ge r1,r2
    if (!c.t) { goto L_060965B4; }  // 0609659E bf 0x060965B4
    c.r[1] = ld32(c.r[14]);  // 060965A0 mov.l @r14,r1
    c.r[2] = c.r[1];  // 060965A2 mov r1,r2
    c.r[1] += 44;  // 060965A4 add #44,r1
    c.r[3] = ld32(c.r[14]);  // 060965A6 mov.l @r14,r3
    c.r[2] = c.r[3];  // 060965A8 mov r3,r2
    c.r[3] += 44;  // 060965AA add #44,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060965AC mov.b @r3,r2
    c.r[3] = 0x1u;  // 060965AE mov #1,r3
    c.r[3] |= c.r[2];  // 060965B0 or r2,r3
    st8(c.r[1], c.r[3]);  // 060965B2 mov.b r3,@r1
L_060965B4:
    c.r[2] = ld32(c.r[14]);  // 060965B4 mov.l @r14,r2
    c.r[1] = c.r[2];  // 060965B6 mov r2,r1
    c.r[2] += 45;  // 060965B8 add #45,r2
    c.r[1] = 0x1u;  // 060965BA mov #1,r1
    st8(c.r[2], c.r[1]);  // 060965BC mov.b r1,@r2
    c.r[2] = ld32(c.r[14] + 8);  // 060965BE mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 060965C0 mov r2,r1
    c.r[1] += 108;  // 060965C2 add #108,r1
    c.r[2] = 0x6u;  // 060965C4 mov #6,r2
    st32(c.r[1] + 52, c.r[2]);  // 060965C6 mov.l r2,@(52,r1)
    c.r[1] = ld32(c.r[14]);  // 060965C8 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060966F4u);  // 060965CA mov.w 0x060966F4,r2
    st32(c.r[1] + 40, c.r[2]);  // 060965CC mov.l r2,@(40,r1)
    c.r[1] = ld32(c.r[14]);  // 060965CE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 060965D0 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 060965D2 mov r2,r1
    c.r[1] += 28;  // 060965D4 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 060965D6 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060965D8 tst r2,r2
    if (!c.t) { goto L_06096646; }  // 060965DA bf 0x06096646
    c.r[1] = c.r[14];  // 060965DC mov r14,r1
    c.r[1] += 52;  // 060965DE add #52,r1
    c.r[2] = ld32(c.r[14] + 12);  // 060965E0 mov.l @(12,r14),r2
    c.r[6] = c.r[1];  // 060965E2 mov r1,r6
    c.r[5] = c.r[2];  // 060965E4 mov r2,r5
    c.r[12] = 0x5Cu;  // 060965E6 mov #92,r12
    c.r[12] += c.r[14];  // 060965E8 add r14,r12
    c.r[4] = ld32(c.r[12]);  // 060965EA mov.l @r12,r4
    c.r[11] = ld32(0x06096700u);  // 060965EC mov.l 0x06096700,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060965F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060965F2u) return; }  // 060965EE jsr @r11 ; nop
    st32(c.r[14] + 40, c.r[0]);  // 060965F2 mov.l r0,@(40,r14)
    c.r[2] = ld32(c.r[14] + 24);  // 060965F4 mov.l @(24,r14),r2
    c.r[1] = ld32(c.r[2] + 4);  // 060965F6 mov.l @(4,r2),r1
    c.r[2] = c.r[14];  // 060965F8 mov r14,r2
    c.r[2] += 52;  // 060965FA add #52,r2
    c.r[3] = ld32(c.r[14] + 40);  // 060965FC mov.l @(40,r14),r3
    c.r[6] = ld32(c.r[14] + 20);  // 060965FE mov.l @(20,r14),r6
    c.r[7] = c.r[6];  // 06096600 mov r6,r7
    c.r[7] += 28;  // 06096602 add #28,r7
    c.r[4] = ld32(c.r[7] + 12);  // 06096604 mov.l @(12,r7),r4
    c.r[7] = ld32(c.r[14] + 24);  // 06096606 mov.l @(24,r14),r7
    c.r[6] = ld32(c.r[7] + 20);  // 06096608 mov.l @(20,r7),r6
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 0609660A mov.l r6,@-r15
    c.r[7] = c.r[1];  // 0609660C mov r1,r7
    c.r[6] = c.r[2];  // 0609660E mov r2,r6
    c.r[5] = c.r[3];  // 06096610 mov r3,r5
    c.r[11] = ld32(0x06096704u);  // 06096612 mov.l 0x06096704,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096618u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096618u) return; }  // 06096614 jsr @r11 ; nop
    c.r[15] += 4;  // 06096618 add #4,r15
    c.r[11] = ld32(0x06096708u);  // 0609661A mov.l 0x06096708,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096620u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096620u) return; }  // 0609661C jsr @r11 ; nop
    st32(c.r[14] + 44, c.r[0]);  // 06096620 mov.l r0,@(44,r14)
    c.r[1] = ld32(c.r[14] + 44);  // 06096622 mov.l @(44,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096624 tst r1,r1
    if (c.t) { goto L_06096638; }  // 06096626 bt 0x06096638
    c.r[1] = ld32(c.r[14] + 44);  // 06096628 mov.l @(44,r14),r1
    c.r[4] = c.r[1];  // 0609662A mov r1,r4
    c.r[11] = ld32(0x0609670Cu);  // 0609662C mov.l 0x0609670C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096632u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096632u) return; }  // 0609662E jsr @r11 ; nop
    c.r[0] = 0x0u;  // 06096632 mov #0,r0
    goto L_060966DE;  // 06096634 bra 0x060966DE ; nop
L_06096638:
    c.r[1] = ld32(0x06096710u);  // 06096638 mov.l 0x06096710,r1
    c.r[2] = ld32(c.r[14] + 20);  // 0609663A mov.l @(20,r14),r2
    c.r[5] = c.r[1];  // 0609663C mov r1,r5
    c.r[4] = c.r[2];  // 0609663E mov r2,r4
    c.r[11] = ld32(0x06096714u);  // 06096640 mov.l 0x06096714,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096646u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096646u) return; }  // 06096642 jsr @r11 ; nop
L_06096646:
    c.r[1] = c.r[14];  // 06096646 mov r14,r1
    c.r[2] = c.r[14];  // 06096648 mov r14,r2
    c.r[2] += 16;  // 0609664A add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609664C mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0609664E extu.b r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 06096650 mov.l @(4,r14),r1
    c.r[6] = c.r[2];  // 06096652 mov r2,r6
    c.r[5] = ld32(c.r[14]);  // 06096654 mov.l @r14,r5
    c.r[4] = c.r[1];  // 06096656 mov r1,r4
    c.r[11] = ld32(0x06096718u);  // 06096658 mov.l 0x06096718,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609665Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609665Eu) return; }  // 0609665A jsr @r11 ; nop
    st32(c.r[14] + 48, c.r[0]);  // 0609665E mov.l r0,@(48,r14)
    c.r[1] = ld32(c.r[14] + 48);  // 06096660 mov.l @(48,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096662 tst r1,r1
    if (!c.t) { goto L_0609666C; }  // 06096664 bf 0x0609666C
    c.r[0] = 0x0u;  // 06096666 mov #0,r0
    goto L_060966DE;  // 06096668 bra 0x060966DE ; nop
L_0609666C:
    c.r[2] = ld32(c.r[14] + 4);  // 0609666C mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0609666E mov r2,r1
    c.r[2] += 56;  // 06096670 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06096672 mov.w @r2,r1
    c.r[2] = 0x2u;  // 06096674 mov #2,r2
    c.r[2] &= c.r[1];  // 06096676 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06096678 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609667A tst r1,r1
    if (c.t) { goto L_060966D8; }  // 0609667C bt 0x060966D8
    c.r[2] = ld32(c.r[14] + 4);  // 0609667E mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096680 mov r2,r1
    c.r[2] += 56;  // 06096682 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06096684 mov.w @r2,r1
    c.r[2] = 0x20u;  // 06096686 mov #32,r2
    c.r[2] &= c.r[1];  // 06096688 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0609668A extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609668C tst r1,r1
    if (!c.t) { goto L_060966D8; }  // 0609668E bf 0x060966D8
    c.r[1] = ld32(c.r[14] + 4);  // 06096690 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 06096692 mov.l @(12,r1),r2
    c.r[1] = ld32(c.r[14]);  // 06096694 mov.l @r14,r1
    c.t = c.r[2] == c.r[1];  // 06096696 cmp/eq r1,r2
    if (!c.t) { goto L_060966D8; }  // 06096698 bf 0x060966D8
    c.r[1] = c.r[14];  // 0609669A mov r14,r1
    c.r[1] += 60;  // 0609669C add #60,r1
    c.r[5] = 0x0u;  // 0609669E mov #0,r5
    c.r[4] = c.r[1];  // 060966A0 mov r1,r4
    c.r[11] = ld32(0x0609671Cu);  // 060966A2 mov.l 0x0609671C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060966A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060966A8u) return; }  // 060966A4 jsr @r11 ; nop
    c.r[2] = ld32(0x06096720u);  // 060966A8 mov.l 0x06096720,r2
    c.r[1] = ld32(c.r[2]);  // 060966AA mov.l @r2,r1
    c.r[2] = ld32(c.r[1] + 24);  // 060966AC mov.l @(24,r1),r2
    c.r[1] = c.r[2];  // 060966AE mov r2,r1
    c.r[1] -= 10;  // 060966B0 add #-10,r1
    c.r[2] = ld32(c.r[14] + 60);  // 060966B2 mov.l @(60,r14),r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060966B4 cmp/ge r1,r2
    if (c.t) { goto L_060966D8; }  // 060966B6 bt 0x060966D8
    c.r[1] = ld32(c.r[14] + 36);  // 060966B8 mov.l @(36,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 060966BA mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 060966BC mov r1,r5
    c.r[4] = c.r[2];  // 060966BE mov r2,r4
    c.r[11] = ld32(0x06096724u);  // 060966C0 mov.l 0x06096724,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060966C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060966C6u) return; }  // 060966C2 jsr @r11 ; nop
    st32(c.r[14] + 44, c.r[0]);  // 060966C6 mov.l r0,@(44,r14)
    c.r[1] = ld32(c.r[14] + 44);  // 060966C8 mov.l @(44,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060966CA tst r1,r1
    if (c.t) { goto L_060966D8; }  // 060966CC bt 0x060966D8
    c.r[1] = ld32(c.r[14] + 44);  // 060966CE mov.l @(44,r14),r1
    c.r[4] = c.r[1];  // 060966D0 mov r1,r4
    c.r[11] = ld32(0x06096728u);  // 060966D2 mov.l 0x06096728,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060966D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060966D8u) return; }  // 060966D4 jsr @r11 ; nop
L_060966D8:
    c.r[0] = ld32(c.r[14]);  // 060966D8 mov.l @r14,r0
    goto L_060966DE;  // 060966DA bra 0x060966DE ; nop
L_060966DE:
    c.r[14] += 64;  // 060966DE add #64,r14
    c.r[15] = c.r[14];  // 060966E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060966E2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060966E4 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060966E6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060966E8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060966EA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060966EC mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060966EE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060966F0 rts ; nop
}

void f_0609672C(SH2Context& c) {
    ran[2281] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609672C mov.l r14,@-r15
    c.r[15] -= 4;  // 0609672E add #-4,r15
    c.r[14] = c.r[15];  // 06096730 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096732 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06096734 mov.l @r14,r1
    c.r[2] = 0x0u;  // 06096736 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06096738 mov.l r2,@r1
    c.r[1] = ld32(c.r[14]);  // 0609673A mov.l @r14,r1
    c.r[2] = 0x0u;  // 0609673C mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 0609673E mov.l r2,@(4,r1)
    c.r[2] = ld32(c.r[14]);  // 06096740 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096742 mov r2,r1
    c.r[2] += 58;  // 06096744 add #58,r2
    c.r[1] = 0x0u;  // 06096746 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06096748 mov.b r1,@r2
    c.r[14] += 4;  // 0609674A add #4,r14
    c.r[15] = c.r[14];  // 0609674C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609674E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096750 rts ; nop
}

void f_06096754(SH2Context& c) {
    ran[2282] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096754 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096756 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096758 sts.l pr,@-r15
    c.r[15] -= 24;  // 0609675A add #-24,r15
    c.r[14] = c.r[15];  // 0609675C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609675E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06096760 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06096762 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06096764 mov r2,r1
    c.r[1] += 28;  // 06096766 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06096768 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609676A tst r2,r2
    if (c.t) { goto L_06096772; }  // 0609676C bt 0x06096772
    goto L_0609683E;  // 0609676E bra 0x0609683E ; nop
L_06096772:
    c.r[1] = ld32(c.r[14]);  // 06096772 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06096774 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096776 mov.l r2,@(4,r14)
    c.r[1] = 0x0u;  // 06096778 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0609677A mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609677C mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0609677E mov r1,r2
    c.r[2] += 4;  // 06096780 add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 06096782 mov.l r2,@(8,r14)
L_06096784:
    c.r[1] = ld32(c.r[14] + 8);  // 06096784 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06096786 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096788 tst r2,r2
    if (c.t) { goto L_0609679A; }  // 0609678A bt 0x0609679A
    c.r[1] = ld32(c.r[14] + 8);  // 0609678C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0609678E mov.l @r1,r2
    c.r[1] = ld32(c.r[14]);  // 06096790 mov.l @r14,r1
    c.t = c.r[2] == c.r[1];  // 06096792 cmp/eq r1,r2
    if (!c.t) { goto L_0609679E; }  // 06096794 bf 0x0609679E
    goto L_0609679A;  // 06096796 bra 0x0609679A ; nop
L_0609679A:
    goto L_060967B2;  // 0609679A bra 0x060967B2 ; nop
L_0609679E:
    c.r[1] = ld32(c.r[14] + 8);  // 0609679E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060967A0 mov.l @r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 060967A2 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 060967A4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060967A6 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060967A8 mov r2,r1
    c.r[1] += 12;  // 060967AA add #12,r1
    st32(c.r[14] + 8, c.r[1]);  // 060967AC mov.l r1,@(8,r14)
    SH2_POLL(c); goto L_06096784;  // 060967AE bra 0x06096784 ; nop
L_060967B2:
    c.r[1] = ld32(c.r[14] + 8);  // 060967B2 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060967B4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060967B6 tst r2,r2
    if (!c.t) { goto L_060967BE; }  // 060967B8 bf 0x060967BE
    goto L_0609683E;  // 060967BA bra 0x0609683E ; nop
L_060967BE:
    c.r[1] = ld32(c.r[14] + 8);  // 060967BE mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 060967C0 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 12);  // 060967C2 mov.l @(12,r2),r3
    st32(c.r[1], c.r[3]);  // 060967C4 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 060967C6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060967C8 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060967CA tst r2,r2
    if (!c.t) { goto L_060967D6; }  // 060967CC bf 0x060967D6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06096852u);  // 060967CE mov.w 0x06096852,r1
    st32(c.r[14] + 16, c.r[1]);  // 060967D0 mov.l r1,@(16,r14)
    goto L_060967E4;  // 060967D2 bra 0x060967E4 ; nop
L_060967D6:
    c.r[1] = ld32(c.r[14] + 8);  // 060967D6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060967D8 mov.l @r1,r2
    c.r[3] = ld32(c.r[2] + 20);  // 060967DA mov.l @(20,r2),r3
    c.r[1] = c.r[3];  // 060967DC mov r3,r1
    c.r[1] += 28;  // 060967DE add #28,r1
    c.r[2] = ld32(c.r[1] + 12);  // 060967E0 mov.l @(12,r1),r2
    st32(c.r[14] + 16, c.r[2]);  // 060967E2 mov.l r2,@(16,r14)
L_060967E4:
    c.r[1] = ld32(c.r[14] + 12);  // 060967E4 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060967E6 tst r1,r1
    if (!c.t) { goto L_060967FE; }  // 060967E8 bf 0x060967FE
    c.r[1] = ld32(c.r[14] + 4);  // 060967EA mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 52);  // 060967EC mov.l @(52,r1),r2
    c.r[1] = ld32(c.r[14] + 16);  // 060967EE mov.l @(16,r14),r1
    c.r[5] = c.r[2];  // 060967F0 mov r2,r5
    c.r[4] = c.r[1];  // 060967F2 mov r1,r4
    c.r[8] = ld32(0x06096854u);  // 060967F4 mov.l 0x06096854,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060967FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060967FAu) return; }  // 060967F6 jsr @r8 ; nop
    goto L_06096820;  // 060967FA bra 0x06096820 ; nop
L_060967FE:
    c.r[1] = ld32(c.r[14] + 16);  // 060967FE mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06096800 mov.l @(12,r14),r2
    c.r[7] = ld32(c.r[2] + 20);  // 06096802 mov.l @(20,r2),r7
    c.r[3] = c.r[7];  // 06096804 mov r7,r3
    c.r[3] += 28;  // 06096806 add #28,r3
    c.r[2] = ld32(c.r[3] + 4);  // 06096808 mov.l @(4,r3),r2
    c.r[3] = ld32(c.r[14] + 12);  // 0609680A mov.l @(12,r14),r3
    c.r[6] = ld32(c.r[3] + 20);  // 0609680C mov.l @(20,r3),r6
    c.r[7] = c.r[6];  // 0609680E mov r6,r7
    c.r[7] += 28;  // 06096810 add #28,r7
    c.r[3] = ld32(c.r[7] + 12);  // 06096812 mov.l @(12,r7),r3
    c.r[6] = c.r[1];  // 06096814 mov r1,r6
    c.r[5] = c.r[2];  // 06096816 mov r2,r5
    c.r[4] = c.r[3];  // 06096818 mov r3,r4
    c.r[8] = ld32(0x06096858u);  // 0609681A mov.l 0x06096858,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096820u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096820u) return; }  // 0609681C jsr @r8 ; nop
L_06096820:
    c.r[8] = ld32(0x0609685Cu);  // 06096820 mov.l 0x0609685C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096826u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096826u) return; }  // 06096822 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06096826 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06096828 mov.l @(20,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609682A tst r1,r1
    if (c.t) { goto L_0609683E; }  // 0609682C bt 0x0609683E
    c.r[1] = ld32(c.r[14] + 20);  // 0609682E mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 06096830 mov r1,r4
    c.r[8] = ld32(0x06096860u);  // 06096832 mov.l 0x06096860,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096838u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096838u) return; }  // 06096834 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06096838 mov #0,r0
    goto L_06096844;  // 0609683A bra 0x06096844 ; nop
L_0609683E:
    c.r[0] = 0x1u;  // 0609683E mov #1,r0
    goto L_06096844;  // 06096840 bra 0x06096844 ; nop
L_06096844:
    c.r[14] += 24;  // 06096844 add #24,r14
    c.r[15] = c.r[14];  // 06096846 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06096848 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609684A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609684C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609684E rts ; nop
}

void f_06096864(SH2Context& c) {
    ran[2283] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096864 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096866 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096868 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609686A add #-16,r15
    c.r[14] = c.r[15];  // 0609686C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609686E mov.l r4,@r14
    c.r[1] = 0x1u;  // 06096870 mov #1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06096872 mov.l r1,@(12,r14)
    c.r[2] = ld32(c.r[14]);  // 06096874 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096876 mov r2,r1
    c.r[2] += 45;  // 06096878 add #45,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609687A mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0609687C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0609687E cmp/eq #1,r0
    if (!c.t) { goto L_060968EC; }  // 06096880 bf 0x060968EC
    c.r[2] = ld32(c.r[14]);  // 06096882 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096884 mov r2,r1
    c.r[2] += 45;  // 06096886 add #45,r2
    c.r[1] = 0x0u;  // 06096888 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0609688A mov.b r1,@r2
    c.r[1] = ld32(c.r[14]);  // 0609688C mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0609688E mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096890 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06096892 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096894 tst r1,r1
    if (!c.t) { goto L_0609689E; }  // 06096896 bf 0x0609689E
    c.r[0] = ld32(c.r[14] + 12);  // 06096898 mov.l @(12,r14),r0
    goto L_060968F2;  // 0609689A bra 0x060968F2 ; nop
L_0609689E:
    ;  // 0609689E nop
    c.r[1] = ld32(c.r[14] + 4);  // 060968A0 mov.l @(4,r14),r1
    st32(c.r[14] + 8, c.r[1]);  // 060968A2 mov.l r1,@(8,r14)
L_060968A4:
    c.r[1] = ld32(c.r[14] + 8);  // 060968A4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060968A6 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060968A8 tst r2,r2
    if (c.t) { goto L_060968BA; }  // 060968AA bt 0x060968BA
    c.r[1] = ld32(c.r[14] + 8);  // 060968AC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060968AE mov.l @r1,r2
    c.r[1] = ld32(c.r[14]);  // 060968B0 mov.l @r14,r1
    c.t = c.r[2] == c.r[1];  // 060968B2 cmp/eq r1,r2
    if (!c.t) { goto L_060968BE; }  // 060968B4 bf 0x060968BE
    goto L_060968BA;  // 060968B6 bra 0x060968BA ; nop
L_060968BA:
    goto L_060968CC;  // 060968BA bra 0x060968CC ; nop
L_060968BE:
    c.r[1] = ld32(c.r[14] + 8);  // 060968BE mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060968C0 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060968C2 mov r2,r1
    c.r[1] += 8;  // 060968C4 add #8,r1
    st32(c.r[14] + 8, c.r[1]);  // 060968C6 mov.l r1,@(8,r14)
    SH2_POLL(c); goto L_060968A4;  // 060968C8 bra 0x060968A4 ; nop
L_060968CC:
    c.r[1] = ld32(c.r[14] + 8);  // 060968CC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 060968CE mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060968D0 tst r2,r2
    if (c.t) { goto L_060968DC; }  // 060968D2 bt 0x060968DC
    c.r[1] = ld32(c.r[14] + 8);  // 060968D4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 060968D6 mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 8);  // 060968D8 mov.l @(8,r2),r3
    st32(c.r[1], c.r[3]);  // 060968DA mov.l r3,@r1
L_060968DC:
    c.r[4] = ld32(c.r[14]);  // 060968DC mov.l @r14,r4
    c.r[8] = ld32(0x06096900u);  // 060968DE mov.l 0x06096900,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060968E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060968E4u) return; }  // 060968E0 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 060968E4 mov.l r0,@(12,r14)
    c.r[1] = ld32(c.r[14]);  // 060968E6 mov.l @r14,r1
    c.r[2] = 0x0u;  // 060968E8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 060968EA mov.l r2,@r1
L_060968EC:
    c.r[0] = ld32(c.r[14] + 12);  // 060968EC mov.l @(12,r14),r0
    goto L_060968F2;  // 060968EE bra 0x060968F2 ; nop
L_060968F2:
    c.r[14] += 16;  // 060968F2 add #16,r14
    c.r[15] = c.r[14];  // 060968F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060968F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060968F8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060968FA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060968FC rts ; nop
}

void f_06096904(SH2Context& c) {
    ran[2284] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096904 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096906 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096908 sts.l pr,@-r15
    c.r[15] -= 24;  // 0609690A add #-24,r15
    c.r[14] = c.r[15];  // 0609690C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609690E mov.l r4,@r14
    c.r[1] = 0x0u;  // 06096910 mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 06096912 mov.l r1,@(16,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609697Cu);  // 06096914 mov.w 0x0609697C,r1
    st32(c.r[14] + 20, c.r[1]);  // 06096916 mov.l r1,@(20,r14)
    c.r[1] = ld32(c.r[14]);  // 06096918 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609691A mov.l @(4,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 0609691C mov.l r2,@(4,r14)
L_0609691E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609691E mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096920 tst r1,r1
    if (!c.t) { goto L_06096928; }  // 06096922 bf 0x06096928
    goto L_06096968;  // 06096924 bra 0x06096968 ; nop
L_06096928:
    c.r[1] = ld32(c.r[14] + 4);  // 06096928 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 0609692A mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 0609692C mov r2,r1
    c.r[1] += 28;  // 0609692E add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06096930 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096932 tst r2,r2
    if (!c.t) { goto L_0609695E; }  // 06096934 bf 0x0609695E
    c.r[1] = c.r[14];  // 06096936 mov r14,r1
    c.r[1] += 12;  // 06096938 add #12,r1
    c.r[2] = c.r[14];  // 0609693A mov r14,r2
    c.r[2] += 8;  // 0609693C add #8,r2
    c.r[7] = ld32(c.r[14] + 4);  // 0609693E mov.l @(4,r14),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06096940 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06096942 mov r1,r6
    c.r[5] = c.r[2];  // 06096944 mov r2,r5
    c.r[4] = c.r[3];  // 06096946 mov r3,r4
    c.r[8] = ld32(0x06096980u);  // 06096948 mov.l 0x06096980,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609694Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609694Eu) return; }  // 0609694A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 20);  // 0609694E mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06096950 mov.l @(12,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06096952 cmp/ge r2,r1
    if (c.t) { goto L_0609695E; }  // 06096954 bt 0x0609695E
    c.r[1] = ld32(c.r[14] + 12);  // 06096956 mov.l @(12,r14),r1
    st32(c.r[14] + 20, c.r[1]);  // 06096958 mov.l r1,@(20,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0609695A mov.l @(4,r14),r1
    st32(c.r[14] + 16, c.r[1]);  // 0609695C mov.l r1,@(16,r14)
L_0609695E:
    c.r[1] = ld32(c.r[14] + 4);  // 0609695E mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 06096960 mov.l @(12,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06096962 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0609691E;  // 06096964 bra 0x0609691E ; nop
L_06096968:
    c.r[1] = ld32(c.r[14]);  // 06096968 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0609696A mov.l @(16,r14),r2
    st32(c.r[1] + 12, c.r[2]);  // 0609696C mov.l r2,@(12,r1)
    c.r[14] += 24;  // 0609696E add #24,r14
    c.r[15] = c.r[14];  // 06096970 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06096972 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096974 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06096976 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096978 rts ; nop
}

void f_06096984(SH2Context& c) {
    ran[2285] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096984 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096986 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096988 sts.l pr,@-r15
    c.r[15] -= 12;  // 0609698A add #-12,r15
    c.r[14] = c.r[15];  // 0609698C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609698E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06096990 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06096992 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06096994 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096996 tst r1,r1
    if (!c.t) { goto L_060969A4; }  // 06096998 bf 0x060969A4
    c.r[0] = 0x0u;  // 0609699A mov #0,r0
    goto L_060969C0;  // 0609699C bra 0x060969C0 ; nop
L_060969A4:
    c.r[1] = ld32(c.r[14] + 8);  // 060969A4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 060969A6 mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 060969A8 mov r1,r6
    c.r[5] = c.r[2];  // 060969AA mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 060969AC mov.l @r14,r4
    c.r[8] = ld32(0x060969D0u);  // 060969AE mov.l 0x060969D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060969B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060969B4u) return; }  // 060969B0 jsr @r8 ; nop
    c.r[0] = 0x1u;  // 060969B4 mov #1,r0
    goto L_060969C0;  // 060969B6 bra 0x060969C0 ; nop
L_060969C0:
    c.r[14] += 12;  // 060969C0 add #12,r14
    c.r[15] = c.r[14];  // 060969C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060969C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060969C6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060969C8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060969CA rts ; nop
}

void f_060969D8(SH2Context& c) {
    ran[2286] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060969D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060969DA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060969DC sts.l pr,@-r15
    c.r[15] -= 8;  // 060969DE add #-8,r15
    c.r[14] = c.r[15];  // 060969E0 mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06096A28u);  // 060969E2 mov.w 0x06096A28,r1
    c.r[4] = c.r[1];  // 060969E4 mov r1,r4
    c.r[8] = ld32(0x06096A2Cu);  // 060969E6 mov.l 0x06096A2C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060969ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060969ECu) return; }  // 060969E8 jsr @r8 ; nop
    c.r[8] = ld32(0x06096A30u);  // 060969EC mov.l 0x06096A30,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060969F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060969F2u) return; }  // 060969EE jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 060969F2 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 060969F4 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060969F6 tst r1,r1
    if (!c.t) { goto L_06096A00; }  // 060969F8 bf 0x06096A00
    c.r[0] = 0x0u;  // 060969FA mov #0,r0
    goto L_06096A1A;  // 060969FC bra 0x06096A1A ; nop
L_06096A00:
    c.r[8] = ld32(0x06096A34u);  // 06096A00 mov.l 0x06096A34,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096A06u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096A06u) return; }  // 06096A02 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06096A06 mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06096A08 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06096A0A cmp/pz r1
    if (c.t) { goto L_06096A14; }  // 06096A0C bt 0x06096A14
    c.r[0] = 0x0u;  // 06096A0E mov #0,r0
    goto L_06096A1A;  // 06096A10 bra 0x06096A1A ; nop
L_06096A14:
    c.r[0] = ld32(c.r[14]);  // 06096A14 mov.l @r14,r0
    goto L_06096A1A;  // 06096A16 bra 0x06096A1A ; nop
L_06096A1A:
    c.r[14] += 8;  // 06096A1A add #8,r14
    c.r[15] = c.r[14];  // 06096A1C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06096A1E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096A20 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06096A22 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096A24 rts ; nop
}

void f_06096A38(SH2Context& c) {
    ran[2287] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096A38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096A3A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096A3C sts.l pr,@-r15
    c.r[15] -= 32;  // 06096A3E add #-32,r15
    c.r[14] = c.r[15];  // 06096A40 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096A42 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06096A44 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06096A46 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06096A48 mov.l r2,@(8,r14)
    c.r[2] = ld32(c.r[14]);  // 06096A4A mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096A4C mov r2,r1
    c.r[2] += 45;  // 06096A4E add #45,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06096A50 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06096A52 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06096A54 cmp/eq #1,r0
    if (c.t) { goto L_06096A5C; }  // 06096A56 bt 0x06096A5C
    goto L_06096BB2;  // 06096A58 bra 0x06096BB2 ; nop
L_06096A5C:
    c.r[1] = ld32(c.r[14] + 8);  // 06096A5C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06096A5E mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 8);  // 06096A60 mov.l @(8,r1),r1
    c.t = c.r[2] == c.r[1];  // 06096A62 cmp/eq r1,r2
    if (!c.t) { goto L_06096AB8; }  // 06096A64 bf 0x06096AB8
    c.r[1] = ld32(c.r[14] + 8);  // 06096A66 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06096A68 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096A6A mov.l r2,@(4,r14)
L_06096A6C:
    c.r[1] = ld32(c.r[14] + 4);  // 06096A6C mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096A6E tst r1,r1
    if (!c.t) { goto L_06096A76; }  // 06096A70 bf 0x06096A76
    goto L_06096A9E;  // 06096A72 bra 0x06096A9E ; nop
L_06096A76:
    c.r[1] = ld32(c.r[14] + 4);  // 06096A76 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06096A78 mov.l @r14,r2
    c.t = c.r[1] == c.r[2];  // 06096A7A cmp/eq r2,r1
    if (c.t) { goto L_06096A94; }  // 06096A7C bt 0x06096A94
    c.r[2] = ld32(c.r[14] + 4);  // 06096A7E mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096A80 mov r2,r1
    c.r[2] += 44;  // 06096A82 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06096A84 mov.b @r2,r1
    c.r[2] = 0x2u;  // 06096A86 mov #2,r2
    c.r[2] &= c.r[1];  // 06096A88 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06096A8A extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096A8C tst r1,r1
    if (!c.t) { goto L_06096A94; }  // 06096A8E bf 0x06096A94
    goto L_06096A9E;  // 06096A90 bra 0x06096A9E ; nop
L_06096A94:
    c.r[1] = ld32(c.r[14] + 4);  // 06096A94 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 06096A96 mov.l @(8,r1),r2
    st32(c.r[14] + 4, c.r[2]);  // 06096A98 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_06096A6C;  // 06096A9A bra 0x06096A6C ; nop
L_06096A9E:
    c.r[1] = ld32(c.r[14] + 8);  // 06096A9E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06096AA0 mov.l @(4,r14),r2
    st32(c.r[1] + 8, c.r[2]);  // 06096AA2 mov.l r2,@(8,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096AA4 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06096AA6 mov r1,r2
    c.r[1] += 56;  // 06096AA8 add #56,r1
    c.r[3] = ld32(c.r[14] + 8);  // 06096AAA mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 06096AAC mov r3,r2
    c.r[3] += 56;  // 06096AAE add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06096AB0 mov.w @r3,r2
    c.r[3] = ld32(0x06096D0Cu);  // 06096AB2 mov.l 0x06096D0C,r3
    c.r[2] &= c.r[3];  // 06096AB4 and r3,r2
    st16(c.r[1], c.r[2]);  // 06096AB6 mov.w r2,@r1
L_06096AB8:
    c.r[1] = ld32(c.r[14] + 8);  // 06096AB8 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06096ABA mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 16);  // 06096ABC mov.l @(16,r1),r1
    c.t = c.r[2] == c.r[1];  // 06096ABE cmp/eq r1,r2
    if (!c.t) { goto L_06096B04; }  // 06096AC0 bf 0x06096B04
    c.r[1] = ld32(c.r[14]);  // 06096AC2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06096AC4 mov.l @(16,r1),r2
    c.r[5] = 0xFFFFFFFFu;  // 06096AC6 mov #-1,r5
    c.r[4] = c.r[2];  // 06096AC8 mov r2,r4
    c.r[8] = ld32(0x06096D10u);  // 06096ACA mov.l 0x06096D10,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096AD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096AD0u) return; }  // 06096ACC jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06096AD0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06096AD2 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06096AD4 mov r2,r1
    c.r[1] += 108;  // 06096AD6 add #108,r1
    c.r[2] = 0x0u;  // 06096AD8 mov #0,r2
    st32(c.r[1] + 52, c.r[2]);  // 06096ADA mov.l r2,@(52,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096ADC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06096ADE mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 8);  // 06096AE0 mov.l @(8,r2),r3
    st32(c.r[1] + 16, c.r[3]);  // 06096AE2 mov.l r3,@(16,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096AE4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06096AE6 mov.l @(16,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096AE8 tst r2,r2
    if (!c.t) { goto L_06096AF4; }  // 06096AEA bf 0x06096AF4
    c.r[1] = ld32(c.r[14] + 8);  // 06096AEC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06096AEE mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2]);  // 06096AF0 mov.l @r2,r3
    st32(c.r[1] + 16, c.r[3]);  // 06096AF2 mov.l r3,@(16,r1)
L_06096AF4:
    c.r[1] = ld32(c.r[14] + 8);  // 06096AF4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06096AF6 mov.l @(16,r1),r2
    c.r[1] = ld32(c.r[14]);  // 06096AF8 mov.l @r14,r1
    c.t = c.r[2] == c.r[1];  // 06096AFA cmp/eq r1,r2
    if (!c.t) { goto L_06096B04; }  // 06096AFC bf 0x06096B04
    c.r[1] = ld32(c.r[14] + 8);  // 06096AFE mov.l @(8,r14),r1
    c.r[2] = 0x0u;  // 06096B00 mov #0,r2
    st32(c.r[1] + 16, c.r[2]);  // 06096B02 mov.l r2,@(16,r1)
L_06096B04:
    c.r[1] = ld32(c.r[14]);  // 06096B04 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06096B06 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06096B08 mov r2,r1
    c.r[1] += 28;  // 06096B0A add #28,r1
    c.r[2] = ld32(c.r[14]);  // 06096B0C mov.l @r14,r2
    c.r[3] = ld32(c.r[2] + 20);  // 06096B0E mov.l @(20,r2),r3
    c.r[2] = c.r[3];  // 06096B10 mov r3,r2
    c.r[2] += 28;  // 06096B12 add #28,r2
    c.r[3] = ld32(c.r[2] + 12);  // 06096B14 mov.l @(12,r2),r3
    st32(c.r[1] + 4, c.r[3]);  // 06096B16 mov.l r3,@(4,r1)
    c.r[4] = ld32(c.r[14]);  // 06096B18 mov.l @r14,r4
    c.r[8] = ld32(0x06096D14u);  // 06096B1A mov.l 0x06096D14,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096B20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096B20u) return; }  // 06096B1C jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 06096B20 mov.l @r14,r2
    c.r[1] = ld32(c.r[2] + 20);  // 06096B22 mov.l @(20,r2),r1
    c.r[2] = c.r[14];  // 06096B24 mov r14,r2
    c.r[2] += 24;  // 06096B26 add #24,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06096B28 mov.l r2,@-r15
    c.r[2] = 0x0u;  // 06096B2A mov #0,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06096B2C mov.l r2,@-r15
    c.r[2] = 0x0u;  // 06096B2E mov #0,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06096B30 mov.l r2,@-r15
    c.r[2] = 0x0u;  // 06096B32 mov #0,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06096B34 mov.l r2,@-r15
    c.r[7] = 0x0u;  // 06096B36 mov #0,r7
    c.r[6] = 0x0u;  // 06096B38 mov #0,r6
    c.r[5] = 0x0u;  // 06096B3A mov #0,r5
    c.r[4] = c.r[1];  // 06096B3C mov r1,r4
    c.r[8] = ld32(0x06096D18u);  // 06096B3E mov.l 0x06096D18,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096B44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096B44u) return; }  // 06096B40 jsr @r8 ; nop
    c.r[15] += 16;  // 06096B44 add #16,r15
    c.r[2] = ld32(c.r[14] + 8);  // 06096B46 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06096B48 mov r2,r1
    c.r[2] += 56;  // 06096B4A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06096B4C mov.w @r2,r1
    c.r[2] = 0x2u;  // 06096B4E mov #2,r2
    c.r[2] &= c.r[1];  // 06096B50 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06096B52 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096B54 tst r1,r1
    if (!c.t) { goto L_06096B5C; }  // 06096B56 bf 0x06096B5C
    goto L_06096BA6;  // 06096B58 bra 0x06096BA6 ; nop
L_06096B5C:
    c.r[2] = ld32(c.r[14] + 24);  // 06096B5C mov.l @(24,r14),r2
    c.r[1] = 0x40u;  // 06096B5E mov #64,r1
    c.r[1] &= c.r[2];  // 06096B60 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096B62 tst r1,r1
    if (!c.t) { goto L_06096BA6; }  // 06096B64 bf 0x06096BA6
    c.r[1] = c.r[14];  // 06096B66 mov r14,r1
    c.r[1] += 16;  // 06096B68 add #16,r1
    c.r[2] = c.r[14];  // 06096B6A mov r14,r2
    c.r[2] += 12;  // 06096B6C add #12,r2
    c.r[7] = ld32(c.r[14]);  // 06096B6E mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 20);  // 06096B70 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06096B72 mov r1,r6
    c.r[5] = c.r[2];  // 06096B74 mov r2,r5
    c.r[4] = c.r[3];  // 06096B76 mov r3,r4
    c.r[8] = ld32(0x06096D1Cu);  // 06096B78 mov.l 0x06096D1C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096B7Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096B7Eu) return; }  // 06096B7A jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06096B7E mov r14,r1
    c.r[1] += 20;  // 06096B80 add #20,r1
    c.r[5] = 0x0u;  // 06096B82 mov #0,r5
    c.r[4] = c.r[1];  // 06096B84 mov r1,r4
    c.r[8] = ld32(0x06096D20u);  // 06096B86 mov.l 0x06096D20,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096B8Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096B8Cu) return; }  // 06096B88 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 06096B8C mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 06096B8E mov r2,r1
    c.r[1] -= 10;  // 06096B90 add #-10,r1
    c.r[2] = ld32(c.r[14] + 20);  // 06096B92 mov.l @(20,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06096B94 cmp/ge r2,r1
    if (c.t) { goto L_06096BA6; }  // 06096B96 bt 0x06096BA6
    c.r[1] = ld32(c.r[14] + 20);  // 06096B98 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 06096B9A mov.l @(16,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06096B9C cmp/gt r2,r1
    if (c.t) { goto L_06096BA6; }  // 06096B9E bt 0x06096BA6
    c.r[8] = ld32(0x06096D24u);  // 06096BA0 mov.l 0x06096D24,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096BA6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096BA6u) return; }  // 06096BA2 jsr @r8 ; nop
L_06096BA6:
    c.r[1] = ld32(c.r[14]);  // 06096BA6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06096BA8 mov.l @(16,r1),r2
    c.r[4] = c.r[2];  // 06096BAA mov r2,r4
    c.r[8] = ld32(0x06096D28u);  // 06096BAC mov.l 0x06096D28,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096BB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096BB2u) return; }  // 06096BAE jsr @r8 ; nop
L_06096BB2:
    c.r[1] = ld32(c.r[14] + 8);  // 06096BB2 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 06096BB4 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 12);  // 06096BB6 mov.l @(12,r1),r1
    c.t = c.r[2] == c.r[1];  // 06096BB8 cmp/eq r1,r2
    if (c.t) { goto L_06096BC0; }  // 06096BBA bt 0x06096BC0
    goto L_06096C82;  // 06096BBC bra 0x06096C82 ; nop
L_06096BC0:
    c.r[1] = ld32(c.r[14] + 8);  // 06096BC0 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06096BC2 mov r1,r4
    c.r[8] = ld32(0x06096D2Cu);  // 06096BC4 mov.l 0x06096D2C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096BCAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096BCAu) return; }  // 06096BC6 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06096BCA mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 06096BCC mov.l @(12,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096BCE tst r2,r2
    if (!c.t) { goto L_06096BD6; }  // 06096BD0 bf 0x06096BD6
    goto L_06096C82;  // 06096BD2 bra 0x06096C82 ; nop
L_06096BD6:
    c.r[2] = ld32(c.r[14] + 8);  // 06096BD6 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06096BD8 mov r2,r1
    c.r[2] += 56;  // 06096BDA add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06096BDC mov.w @r2,r1
    c.r[2] = 0x2u;  // 06096BDE mov #2,r2
    c.r[2] &= c.r[1];  // 06096BE0 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06096BE2 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096BE4 tst r1,r1
    if (!c.t) { goto L_06096BEC; }  // 06096BE6 bf 0x06096BEC
    goto L_06096C82;  // 06096BE8 bra 0x06096C82 ; nop
L_06096BEC:
    c.r[1] = c.r[14];  // 06096BEC mov r14,r1
    c.r[1] += 16;  // 06096BEE add #16,r1
    c.r[2] = c.r[14];  // 06096BF0 mov r14,r2
    c.r[2] += 12;  // 06096BF2 add #12,r2
    c.r[3] = ld32(c.r[14] + 8);  // 06096BF4 mov.l @(8,r14),r3
    c.r[7] = ld32(c.r[3] + 12);  // 06096BF6 mov.l @(12,r3),r7
    c.r[3] = ld32(c.r[7] + 20);  // 06096BF8 mov.l @(20,r7),r3
    c.r[6] = c.r[1];  // 06096BFA mov r1,r6
    c.r[5] = c.r[2];  // 06096BFC mov r2,r5
    c.r[4] = c.r[3];  // 06096BFE mov r3,r4
    c.r[8] = ld32(0x06096D1Cu);  // 06096C00 mov.l 0x06096D1C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096C06u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096C06u) return; }  // 06096C02 jsr @r8 ; nop
    c.r[2] = ld32(0x06096D30u);  // 06096C06 mov.l 0x06096D30,r2
    c.r[1] = ld32(c.r[2]);  // 06096C08 mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 16);  // 06096C0A mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[1] + 20);  // 06096C0C mov.l @(20,r1),r3
    c.r[1] = c.r[2];  // 06096C0E mov r2,r1
    c.r[1] -= c.r[3];  // 06096C10 sub r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06096C12 cmp/pz r1
    if (c.t) { goto L_06096C1A; }  // 06096C14 bt 0x06096C1A
    goto L_06096C2E;  // 06096C16 bra 0x06096C2E ; nop
L_06096C1A:
    c.r[1] = ld32(c.r[14] + 16);  // 06096C1A mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06096C1C mov.l @(8,r14),r2
    c.r[5] = c.r[1];  // 06096C1E mov r1,r5
    c.r[4] = c.r[2];  // 06096C20 mov r2,r4
    c.r[8] = ld32(0x06096D34u);  // 06096C22 mov.l 0x06096D34,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096C28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096C28u) return; }  // 06096C24 jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06096C28 mov.l r0,@(28,r14)
    goto L_06096C6E;  // 06096C2A bra 0x06096C6E ; nop
L_06096C2E:
    c.r[1] = ld32(c.r[14] + 8);  // 06096C2E mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06096C30 mov r1,r4
    c.r[8] = ld32(0x06096D38u);  // 06096C32 mov.l 0x06096D38,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096C38u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096C38u) return; }  // 06096C34 jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06096C38 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06096C3A mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06096C3C mov r1,r4
    c.r[8] = ld32(0x06096D3Cu);  // 06096C3E mov.l 0x06096D3C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096C44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096C44u) return; }  // 06096C40 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 06096C44 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06096C46 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06096C48 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2] + 48);  // 06096C4A mov.l @(48,r2),r3
    c.r[2] = c.r[3];  // 06096C4C mov r3,r2
    c.r[2] += 1;  // 06096C4E add #1,r2
    c.r[3] = c.r[2];  // 06096C50 mov r2,r3
    st32(c.r[1] + 48, c.r[3]);  // 06096C52 mov.l r3,@(48,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096C54 mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06096D0Au);  // 06096C56 mov.w 0x06096D0A,r2
    st32(c.r[1] + 20, c.r[2]);  // 06096C58 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096C5A mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06096C5C mov r1,r2
    c.r[1] += 56;  // 06096C5E add #56,r1
    c.r[3] = ld32(c.r[14] + 8);  // 06096C60 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 06096C62 mov r3,r2
    c.r[3] += 56;  // 06096C64 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06096C66 mov.w @r3,r2
    c.r[3] = ld32(0x06096D40u);  // 06096C68 mov.l 0x06096D40,r3
    c.r[2] &= c.r[3];  // 06096C6A and r3,r2
    st16(c.r[1], c.r[2]);  // 06096C6C mov.w r2,@r1
L_06096C6E:
    c.r[1] = ld32(c.r[14] + 28);  // 06096C6E mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096C70 tst r1,r1
    if (!c.t) { goto L_06096C78; }  // 06096C72 bf 0x06096C78
    goto L_06096C82;  // 06096C74 bra 0x06096C82 ; nop
L_06096C78:
    c.r[1] = ld32(c.r[14] + 28);  // 06096C78 mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 06096C7A mov r1,r4
    c.r[8] = ld32(0x06096D44u);  // 06096C7C mov.l 0x06096D44,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096C82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096C82u) return; }  // 06096C7E jsr @r8 ; nop
L_06096C82:
    c.r[1] = ld32(c.r[14] + 8);  // 06096C82 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 06096C84 mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096C86 tst r2,r2
    if (c.t) { goto L_06096C8E; }  // 06096C88 bt 0x06096C8E
    goto L_06096CFC;  // 06096C8A bra 0x06096CFC ; nop
L_06096C8E:
    c.r[2] = ld32(c.r[14] + 8);  // 06096C8E mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 06096C90 mov r2,r1
    c.r[2] += 56;  // 06096C92 add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06096C94 mov.w @r2,r1
    c.r[2] = 0x2u;  // 06096C96 mov #2,r2
    c.r[2] &= c.r[1];  // 06096C98 and r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06096C9A extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096C9C tst r1,r1
    if (!c.t) { goto L_06096CA4; }  // 06096C9E bf 0x06096CA4
    goto L_06096CFC;  // 06096CA0 bra 0x06096CFC ; nop
L_06096CA4:
    c.r[1] = ld32(c.r[14] + 8);  // 06096CA4 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06096CA6 mov r1,r4
    c.r[8] = ld32(0x06096D38u);  // 06096CA8 mov.l 0x06096D38,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096CAEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096CAEu) return; }  // 06096CAA jsr @r8 ; nop
    st32(c.r[14] + 28, c.r[0]);  // 06096CAE mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06096CB0 mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096CB2 tst r1,r1
    if (!c.t) { goto L_06096CBA; }  // 06096CB4 bf 0x06096CBA
    goto L_06096CC8;  // 06096CB6 bra 0x06096CC8 ; nop
L_06096CBA:
    c.r[1] = ld32(c.r[14] + 28);  // 06096CBA mov.l @(28,r14),r1
    c.r[4] = c.r[1];  // 06096CBC mov r1,r4
    c.r[8] = ld32(0x06096D44u);  // 06096CBE mov.l 0x06096D44,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096CC4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096CC4u) return; }  // 06096CC0 jsr @r8 ; nop
    goto L_06096CFC;  // 06096CC4 bra 0x06096CFC ; nop
L_06096CC8:
    c.r[1] = ld32(c.r[14] + 8);  // 06096CC8 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 06096CCA mov r1,r4
    c.r[8] = ld32(0x06096D3Cu);  // 06096CCC mov.l 0x06096D3C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096CD2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096CD2u) return; }  // 06096CCE jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 06096CD2 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[14] + 8);  // 06096CD4 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06096CD6 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2] + 48);  // 06096CD8 mov.l @(48,r2),r3
    c.r[2] = c.r[3];  // 06096CDA mov r3,r2
    c.r[2] += 1;  // 06096CDC add #1,r2
    c.r[3] = c.r[2];  // 06096CDE mov r2,r3
    st32(c.r[1] + 48, c.r[3]);  // 06096CE0 mov.l r3,@(48,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096CE2 mov.l @(8,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06096D0Au);  // 06096CE4 mov.w 0x06096D0A,r2
    st32(c.r[1] + 20, c.r[2]);  // 06096CE6 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 06096CE8 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06096CEA mov r1,r2
    c.r[1] += 56;  // 06096CEC add #56,r1
    c.r[3] = ld32(c.r[14] + 8);  // 06096CEE mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 06096CF0 mov r3,r2
    c.r[3] += 56;  // 06096CF2 add #56,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06096CF4 mov.w @r3,r2
    c.r[3] = ld32(0x06096D40u);  // 06096CF6 mov.l 0x06096D40,r3
    c.r[2] &= c.r[3];  // 06096CF8 and r3,r2
    st16(c.r[1], c.r[2]);  // 06096CFA mov.w r2,@r1
L_06096CFC:
    c.r[14] += 32;  // 06096CFC add #32,r14
    c.r[15] = c.r[14];  // 06096CFE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06096D00 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096D02 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06096D04 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096D06 rts ; nop
}

void f_06096D48(SH2Context& c) {
    ran[2288] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096D48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096D4A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096D4C sts.l pr,@-r15
    c.r[15] -= 8;  // 06096D4E add #-8,r15
    c.r[14] = c.r[15];  // 06096D50 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096D52 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06096DF6u);  // 06096D54 mov.w 0x06096DF6,r1
    c.r[4] = c.r[1];  // 06096D56 mov r1,r4
    c.r[8] = ld32(0x06096DF8u);  // 06096D58 mov.l 0x06096DF8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096D5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096D5Eu) return; }  // 06096D5A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06096D5E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096D60 tst r1,r1
    if (!c.t) { goto L_06096D76; }  // 06096D62 bf 0x06096D76
    c.r[4] = 0xFFFFFFF5u;  // 06096D64 mov #-11,r4
    c.r[8] = ld32(0x06096DFCu);  // 06096D66 mov.l 0x06096DFC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096D6Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096D6Cu) return; }  // 06096D68 jsr @r8 ; nop
    c.r[8] = ld32(0x06096E00u);  // 06096D6C mov.l 0x06096E00,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096D72u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096D72u) return; }  // 06096D6E jsr @r8 ; nop
    goto L_06096DE8;  // 06096D72 bra 0x06096DE8 ; nop
L_06096D76:
    ;  // 06096D76 nop
L_06096D78:
    c.r[1] = ld32(c.r[14]);  // 06096D78 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06096D7A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096D7C mov.l r2,@(4,r14)
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096D7E tst r2,r2
    if (!c.t) { goto L_06096D86; }  // 06096D80 bf 0x06096D86
    goto L_06096D94;  // 06096D82 bra 0x06096D94 ; nop
L_06096D86:
    c.r[1] = ld32(c.r[14] + 4);  // 06096D86 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 06096D88 mov r1,r4
    c.r[8] = ld32(0x06096E04u);  // 06096D8A mov.l 0x06096E04,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096D90u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096D90u) return; }  // 06096D8C jsr @r8 ; nop
    SH2_POLL(c); goto L_06096D78;  // 06096D90 bra 0x06096D78 ; nop
L_06096D94:
    c.r[1] = ld32(c.r[14]);  // 06096D94 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 06096D96 mov.l @(52,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06096D98 cmp/pz r2
    if (!c.t) { goto L_06096DC6; }  // 06096D9A bf 0x06096DC6
    c.r[2] = ld32(0x06096E08u);  // 06096D9C mov.l 0x06096E08,r2
    c.r[1] = ld32(c.r[2]);  // 06096D9E mov.l @r2,r1
    c.r[2] = 0x0u;  // 06096DA0 mov #0,r2
    st32(c.r[1] + 16, c.r[2]);  // 06096DA2 mov.l r2,@(16,r1)
    c.r[1] = ld32(c.r[14]);  // 06096DA4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 52);  // 06096DA6 mov.l @(52,r1),r2
    c.r[4] = c.r[2];  // 06096DA8 mov r2,r4
    c.r[8] = ld32(0x06096E0Cu);  // 06096DAA mov.l 0x06096E0C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096DB0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096DB0u) return; }  // 06096DAC jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06096DB0 mov.l @r14,r1
    c.r[2] = 0xFFFFFFFFu;  // 06096DB2 mov #-1,r2
    st32(c.r[1] + 52, c.r[2]);  // 06096DB4 mov.l r2,@(52,r1)
    c.r[5] = 0x0u;  // 06096DB6 mov #0,r5
    c.r[4] = 0x0u;  // 06096DB8 mov #0,r4
    c.r[8] = ld32(0x06096E10u);  // 06096DBA mov.l 0x06096E10,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096DC0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096DC0u) return; }  // 06096DBC jsr @r8 ; nop
    c.r[8] = ld32(0x06096E14u);  // 06096DC0 mov.l 0x06096E14,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096DC6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096DC6u) return; }  // 06096DC2 jsr @r8 ; nop
L_06096DC6:
    c.r[4] = ld32(c.r[14]);  // 06096DC6 mov.l @r14,r4
    c.r[8] = ld32(0x06096E18u);  // 06096DC8 mov.l 0x06096E18,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096DCEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096DCEu) return; }  // 06096DCA jsr @r8 ; nop
    c.r[1] = ld32(0x06096E08u);  // 06096DCE mov.l 0x06096E08,r1
    c.r[2] = ld32(c.r[1]);  // 06096DD0 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06096DD2 mov r2,r1
    c.r[1] += 28;  // 06096DD4 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06096DD6 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096DD8 tst r2,r2
    if (c.t) { goto L_06096DE2; }  // 06096DDA bt 0x06096DE2
    c.r[8] = ld32(0x06096E00u);  // 06096DDC mov.l 0x06096E00,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096DE2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096DE2u) return; }  // 06096DDE jsr @r8 ; nop
L_06096DE2:
    c.r[8] = ld32(0x06096E1Cu);  // 06096DE2 mov.l 0x06096E1C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096DE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096DE8u) return; }  // 06096DE4 jsr @r8 ; nop
L_06096DE8:
    c.r[14] += 8;  // 06096DE8 add #8,r14
    c.r[15] = c.r[14];  // 06096DEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06096DEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096DEE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06096DF0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096DF2 rts ; nop
}

void f_06096E20(SH2Context& c) {
    ran[2289] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096E20 mov.l r14,@-r15
    c.r[15] -= 8;  // 06096E22 add #-8,r15
    c.r[14] = c.r[15];  // 06096E24 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096E26 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06096E28 mov.l r5,@(4,r14)
    c.r[0] = 0x0u;  // 06096E2A mov #0,r0
    goto L_06096E30;  // 06096E2C bra 0x06096E30 ; nop
L_06096E30:
    c.r[14] += 8;  // 06096E30 add #8,r14
    c.r[15] = c.r[14];  // 06096E32 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096E34 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096E36 rts ; nop
}

void f_06096E3C(SH2Context& c) {
    ran[2290] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096E3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096E3E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096E40 sts.l pr,@-r15
    c.r[15] -= 12;  // 06096E42 add #-12,r15
    c.r[14] = c.r[15];  // 06096E44 mov r15,r14
    ;  // 06096E46 nop
    c.r[1] = 0x0u;  // 06096E48 mov #0,r1
    st32(c.r[14], c.r[1]);  // 06096E4A mov.l r1,@r14
    c.r[2] = ld32(0x06096EE0u);  // 06096E4C mov.l 0x06096EE0,r2
    c.r[1] = ld32(c.r[2]);  // 06096E4E mov.l @r2,r1
    c.r[2] = ld32(c.r[1]);  // 06096E50 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096E52 mov.l r2,@(4,r14)
L_06096E54:
    c.r[2] = ld32(0x06096EE0u);  // 06096E54 mov.l 0x06096EE0,r2
    c.r[1] = ld32(c.r[2]);  // 06096E56 mov.l @r2,r1
    c.r[2] = ld32(c.r[14]);  // 06096E58 mov.l @r14,r2
    c.r[1] = ld32(c.r[1] + 4);  // 06096E5A mov.l @(4,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06096E5C cmp/ge r1,r2
    if (!c.t) { goto L_06096E64; }  // 06096E5E bf 0x06096E64
    goto L_06096ECA;  // 06096E60 bra 0x06096ECA ; nop
L_06096E64:
    c.r[2] = ld32(c.r[14] + 4);  // 06096E64 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096E66 mov r2,r1
    c.r[2] += 58;  // 06096E68 add #58,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06096E6A mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06096E6C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06096E6E cmp/eq #1,r0
    if (!c.t) { goto L_06096EB2; }  // 06096E70 bf 0x06096EB2
    c.r[1] = ld32(c.r[14] + 4);  // 06096E72 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06096E74 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 06096E76 mov.l r2,@(8,r14)
L_06096E78:
    c.r[1] = ld32(c.r[14] + 8);  // 06096E78 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096E7A tst r1,r1
    if (!c.t) { goto L_06096E82; }  // 06096E7C bf 0x06096E82
    goto L_06096EA8;  // 06096E7E bra 0x06096EA8 ; nop
L_06096E82:
    c.r[1] = ld32(c.r[14] + 8);  // 06096E82 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 24);  // 06096E84 mov.l @(24,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096E86 tst r2,r2
    if (c.t) { goto L_06096E9E; }  // 06096E88 bt 0x06096E9E
    c.r[1] = ld32(c.r[14] + 8);  // 06096E8A mov.l @(8,r14),r1
    c.r[2] = ld32(0x06096EE4u);  // 06096E8C mov.l 0x06096EE4,r2
    c.r[7] = ld32(c.r[14] + 8);  // 06096E8E mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[7] + 16);  // 06096E90 mov.l @(16,r7),r3
    c.r[6] = c.r[1];  // 06096E92 mov r1,r6
    c.r[5] = c.r[2];  // 06096E94 mov r2,r5
    c.r[4] = c.r[3];  // 06096E96 mov r3,r4
    c.r[8] = ld32(0x06096EE8u);  // 06096E98 mov.l 0x06096EE8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096E9Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096E9Eu) return; }  // 06096E9A jsr @r8 ; nop
L_06096E9E:
    c.r[1] = ld32(c.r[14] + 8);  // 06096E9E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 8);  // 06096EA0 mov.l @(8,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06096EA2 mov.l r2,@(8,r14)
    SH2_POLL(c); goto L_06096E78;  // 06096EA4 bra 0x06096E78 ; nop
L_06096EA8:
    c.r[1] = ld32(c.r[14] + 4);  // 06096EA8 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 06096EAA mov r1,r4
    c.r[8] = ld32(0x06096EECu);  // 06096EAC mov.l 0x06096EEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096EB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096EB2u) return; }  // 06096EAE jsr @r8 ; nop
L_06096EB2:
    c.r[2] = ld32(c.r[14]);  // 06096EB2 mov.l @r14,r2
    c.r[1] = c.r[2];  // 06096EB4 mov r2,r1
    c.r[1] += 1;  // 06096EB6 add #1,r1
    c.r[2] = c.r[1];  // 06096EB8 mov r1,r2
    st32(c.r[14], c.r[2]);  // 06096EBA mov.l r2,@r14
    c.r[2] = ld32(c.r[14] + 4);  // 06096EBC mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06096EBE mov r2,r1
    c.r[1] += 60;  // 06096EC0 add #60,r1
    c.r[2] = c.r[1];  // 06096EC2 mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06096EC4 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_06096E54;  // 06096EC6 bra 0x06096E54 ; nop
L_06096ECA:
    c.r[8] = ld32(0x06096EF0u);  // 06096ECA mov.l 0x06096EF0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06096ED0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096ED0u) return; }  // 06096ECC jsr @r8 ; nop
    c.r[14] += 12;  // 06096ED0 add #12,r14
    c.r[15] = c.r[14];  // 06096ED2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06096ED4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06096ED6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06096ED8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06096EDA rts ; nop
}

void f_06096EF4(SH2Context& c) {
    ran[2291] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06096EF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06096EF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06096EF8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06096EFA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06096EFC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06096EFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06096F00 sts.l pr,@-r15
    c.r[15] -= 44;  // 06096F02 add #-44,r15
    c.r[14] = c.r[15];  // 06096F04 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06096F06 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06096F08 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06096F0A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06096F0C mov.l r7,@(12,r14)
    c.r[12] = 0x48u;  // 06096F0E mov #72,r12
    c.r[12] += c.r[14];  // 06096F10 add r14,r12
    c.r[9] = ld32(c.r[12]);  // 06096F12 mov.l @r12,r9
    c.r[8] = c.r[14];  // 06096F14 mov r14,r8
    c.r[10] = c.r[14];  // 06096F16 mov r14,r10
    c.r[10] += 16;  // 06096F18 add #16,r10
    st8(c.r[10], c.r[9]);  // 06096F1A mov.b r9,@r10
    c.r[11] = ld32(0x06097078u);  // 06096F1C mov.l 0x06097078,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F22u) return; }  // 06096F1E jsr @r11 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06096F22 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06096F24 mov.l @(20,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096F26 tst r1,r1
    if (!c.t) { goto L_06096F3E; }  // 06096F28 bf 0x06096F3E
    c.r[4] = 0xFFFFFFEDu;  // 06096F2A mov #-19,r4
    c.r[11] = ld32(0x0609707Cu);  // 06096F2C mov.l 0x0609707C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F32u) return; }  // 06096F2E jsr @r11 ; nop
    c.r[11] = ld32(0x06097080u);  // 06096F32 mov.l 0x06097080,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F38u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F38u) return; }  // 06096F34 jsr @r11 ; nop
    c.r[0] = 0x0u;  // 06096F38 mov #0,r0
    goto L_06097062;  // 06096F3A bra 0x06097062 ; nop
L_06096F3E:
    c.r[11] = ld32(0x06097084u);  // 06096F3E mov.l 0x06097084,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F44u) return; }  // 06096F40 jsr @r11 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 06096F44 mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 06096F46 mov.l @(24,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096F48 tst r1,r1
    if (!c.t) { goto L_06096F6A; }  // 06096F4A bf 0x06096F6A
    c.r[1] = ld32(c.r[14] + 20);  // 06096F4C mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 06096F4E mov r1,r4
    c.r[11] = ld32(0x06097088u);  // 06096F50 mov.l 0x06097088,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F56u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F56u) return; }  // 06096F52 jsr @r11 ; nop
    c.r[4] = 0xFFFFFFEDu;  // 06096F56 mov #-19,r4
    c.r[11] = ld32(0x0609707Cu);  // 06096F58 mov.l 0x0609707C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F5Eu) return; }  // 06096F5A jsr @r11 ; nop
    c.r[11] = ld32(0x06097080u);  // 06096F5E mov.l 0x06097080,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F64u) return; }  // 06096F60 jsr @r11 ; nop
    c.r[0] = 0x0u;  // 06096F64 mov #0,r0
    goto L_06097062;  // 06096F66 bra 0x06097062 ; nop
L_06096F6A:
    c.r[1] = ld32(c.r[14] + 8);  // 06096F6A mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06096F6C mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 24);  // 06096F6E mov.l @(24,r14),r3
    c.r[6] = c.r[1];  // 06096F70 mov r1,r6
    c.r[5] = c.r[2];  // 06096F72 mov r2,r5
    c.r[4] = c.r[3];  // 06096F74 mov r3,r4
    c.r[11] = ld32(0x0609708Cu);  // 06096F76 mov.l 0x0609708C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096F7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096F7Cu) return; }  // 06096F78 jsr @r11 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 06096F7C mov.l r0,@(24,r14)
    c.r[2] = ld32(c.r[14] + 4);  // 06096F7E mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 24);  // 06096F80 mov.l @(24,r14),r3
    c.r[1] = ld32(c.r[14] + 20);  // 06096F82 mov.l @(20,r14),r1
    c.r[7] = c.r[14];  // 06096F84 mov r14,r7
    c.r[6] = c.r[14];  // 06096F86 mov r14,r6
    c.r[6] += 16;  // 06096F88 add #16,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06096F8A mov.b @r6,r5
    c.r[7] = c.r[5] & 0xFFu;  // 06096F8C extu.b r5,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06096F8E mov.l r7,@-r15
    c.r[7] = ld32(c.r[14] + 12);  // 06096F90 mov.l @(12,r14),r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06096F92 mov.l r7,@-r15
    c.r[7] = c.r[2];  // 06096F94 mov r2,r7
    c.r[6] = c.r[3];  // 06096F96 mov r3,r6
    c.r[5] = ld32(c.r[14]);  // 06096F98 mov.l @r14,r5
    c.r[4] = c.r[1];  // 06096F9A mov r1,r4
    c.r[11] = ld32(0x06097090u);  // 06096F9C mov.l 0x06097090,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096FA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096FA2u) return; }  // 06096F9E jsr @r11 ; nop
    c.r[15] += 8;  // 06096FA2 add #8,r15
    st32(c.r[14] + 28, c.r[0]);  // 06096FA4 mov.l r0,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 06096FA6 mov.l @(28,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096FA8 tst r1,r1
    if (!c.t) { goto L_06096FB8; }  // 06096FAA bf 0x06096FB8
    c.r[11] = ld32(0x06097080u);  // 06096FAC mov.l 0x06097080,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096FB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096FB2u) return; }  // 06096FAE jsr @r11 ; nop
    c.r[0] = 0x0u;  // 06096FB2 mov #0,r0
    goto L_06097062;  // 06096FB4 bra 0x06097062 ; nop
L_06096FB8:
    c.r[1] = c.r[14];  // 06096FB8 mov r14,r1
    c.r[2] = c.r[14];  // 06096FBA mov r14,r2
    c.r[2] += 16;  // 06096FBC add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06096FBE mov.b @r2,r1
    c.r[2] = 0x2u;  // 06096FC0 mov #2,r2
    c.r[2] &= c.r[1];  // 06096FC2 and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06096FC4 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06096FC6 tst r1,r1
    if (c.t) { goto L_06096FD6; }  // 06096FC8 bt 0x06096FD6
    c.r[1] = ld32(c.r[14] + 24);  // 06096FCA mov.l @(24,r14),r1
    c.r[5] = 0x1u;  // 06096FCC mov #1,r5
    c.r[4] = c.r[1];  // 06096FCE mov r1,r4
    c.r[11] = ld32(0x06097094u);  // 06096FD0 mov.l 0x06097094,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096FD6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096FD6u) return; }  // 06096FD2 jsr @r11 ; nop
L_06096FD6:
    c.r[1] = ld32(c.r[14] + 20);  // 06096FD6 mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1] + 20);  // 06096FD8 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06096FDA mov r2,r1
    c.r[1] += 28;  // 06096FDC add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06096FDE mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06096FE0 tst r2,r2
    if (c.t) { goto L_0609703E; }  // 06096FE2 bt 0x0609703E
    c.r[2] = c.r[14];  // 06096FE4 mov r14,r2
    c.r[2] += 36;  // 06096FE6 add #36,r2
    c.r[1] = ld32(c.r[14] + 24);  // 06096FE8 mov.l @(24,r14),r1
    c.r[7] = 0x0u;  // 06096FEA mov #0,r7
    c.r[6] = c.r[2];  // 06096FEC mov r2,r6
    c.r[5] = 0x0u;  // 06096FEE mov #0,r5
    c.r[4] = c.r[1];  // 06096FF0 mov r1,r4
    c.r[11] = ld32(0x06097098u);  // 06096FF2 mov.l 0x06097098,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06096FF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06096FF8u) return; }  // 06096FF4 jsr @r11 ; nop
    c.r[1] = ld32(c.r[14] + 36);  // 06096FF8 mov.l @(36,r14),r1
    c.r[2] = ld32(c.r[14] + 24);  // 06096FFA mov.l @(24,r14),r2
    c.r[5] = c.r[1];  // 06096FFC mov r1,r5
    c.r[4] = c.r[2];  // 06096FFE mov r2,r4
    c.r[11] = ld32(0x0609709Cu);  // 06097000 mov.l 0x0609709C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06097006u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097006u) return; }  // 06097002 jsr @r11 ; nop
L_06097006:
    goto L_0609700E;  // 06097006 bra 0x0609700E ; nop
L_0609700E:
    c.r[1] = ld32(c.r[14] + 24);  // 0609700E mov.l @(24,r14),r1
    c.r[4] = c.r[1];  // 06097010 mov r1,r4
    c.r[11] = ld32(0x060970A0u);  // 06097012 mov.l 0x060970A0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06097018u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097018u) return; }  // 06097014 jsr @r11 ; nop
    c.r[1] = c.r[14];  // 06097018 mov r14,r1
    c.r[1] += 40;  // 0609701A add #40,r1
    c.r[2] = c.r[14];  // 0609701C mov r14,r2
    c.r[2] += 32;  // 0609701E add #32,r2
    c.r[3] = ld32(c.r[14] + 24);  // 06097020 mov.l @(24,r14),r3
    c.r[6] = c.r[1];  // 06097022 mov r1,r6
    c.r[5] = c.r[2];  // 06097024 mov r2,r5
    c.r[4] = c.r[3];  // 06097026 mov r3,r4
    c.r[11] = ld32(0x060970A4u);  // 06097028 mov.l 0x060970A4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609702Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609702Eu) return; }  // 0609702A jsr @r11 ; nop
    c.r[1] = ld32(c.r[14] + 40);  // 0609702E mov.l @(40,r14),r1
    c.r[2] = ld32(c.r[14] + 36);  // 06097030 mov.l @(36,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06097032 cmp/ge r2,r1
    if (!c.t) { goto L_0609703A; }  // 06097034 bf 0x0609703A
    goto L_0609703E;  // 06097036 bra 0x0609703E ; nop
L_0609703A:
    SH2_POLL(c); goto L_06097006;  // 0609703A bra 0x06097006 ; nop
L_0609703E:
    c.r[1] = ld32(c.r[14] + 28);  // 0609703E mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06097040 mov.l @(16,r1),r2
    c.r[1] = 0x1u;  // 06097042 mov #1,r1
    st32(c.r[2] + 4, c.r[1]);  // 06097044 mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[14] + 28);  // 06097046 mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06097048 mov.l @(16,r1),r2
    c.r[1] = 0x1u;  // 0609704A mov #1,r1
    st32(c.r[2] + 8, c.r[1]);  // 0609704C mov.l r1,@(8,r2)
    c.r[2] = ld32(c.r[14] + 24);  // 0609704E mov.l @(24,r14),r2
    c.r[1] = c.r[2];  // 06097050 mov r2,r1
    c.r[1] += 108;  // 06097052 add #108,r1
    c.r[4] = c.r[1];  // 06097054 mov r1,r4
    c.r[11] = ld32(0x060970A8u);  // 06097056 mov.l 0x060970A8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0609705Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609705Cu) return; }  // 06097058 jsr @r11 ; nop
    c.r[0] = ld32(c.r[14] + 28);  // 0609705C mov.l @(28,r14),r0
    goto L_06097062;  // 0609705E bra 0x06097062 ; nop
L_06097062:
    c.r[14] += 44;  // 06097062 add #44,r14
    c.r[15] = c.r[14];  // 06097064 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097066 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097068 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609706A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609706C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609706E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06097070 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06097072 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097074 rts ; nop
}

}  // namespace p_srwfin_installed
