#pragma once
#include "saturn/sh2.h"

namespace p_fin_low {
void f_00200000(SH2Context& c);
void f_0024B2F0(SH2Context& c);
void f_0024B4FC(SH2Context& c);
void f_00288AC8(SH2Context& c);
void f_00288B74(SH2Context& c);
void f_00288BA4(SH2Context& c);
void f_00288BD0(SH2Context& c);
void f_00288CB0(SH2Context& c);
void f_00288D04(SH2Context& c);
void f_00288FB2(SH2Context& c);
void f_00289A94(SH2Context& c);
void f_00289B58(SH2Context& c);
void f_00289B78(SH2Context& c);
void f_00289D78(SH2Context& c);
void f_00289DAC(SH2Context& c);
void f_00289F18(SH2Context& c);
void f_0028AE78(SH2Context& c);
void f_0028AEE2(SH2Context& c);
void f_0028AF1E(SH2Context& c);
void f_0028AF38(SH2Context& c);
void f_0028AF4E(SH2Context& c);
void f_0028B172(SH2Context& c);
void f_0028B200(SH2Context& c);
void f_0028B20C(SH2Context& c);
void f_0028B210(SH2Context& c);
void f_0028B2F6(SH2Context& c);
void f_0028BE2A(SH2Context& c);
extern uint8_t ran[];
extern const SH2Module module;
}  // namespace p_fin_low
